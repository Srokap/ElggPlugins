<?php
	/**
	 * tidypics CSS extender
	 */
?>
	/*  --- independent view for image/album SHARED --- */
	
#tidypics_title{
	font-size:1.2em;
	font-weight:bold;
}
#tidypics_desc{
	padding:0 20px;
	font-style:italic;
}
#tidypics_info{
	padding:20px;
	line-height:1.5em;
}

#tidypics_controls{	margin-bottom:10px; 	/*border: 1px solid #EFBE3B; background:#FFDC7F;*/ padding:2px;}
#tidypics_controls h3 {margin-top:12px;}
#tidypics_controls ul {list-style:nome; list-style-type:none; margin:0px; padding:8px;}
#tidypics_controls ul li {padding:2px 10px 2px 22px;/* border:1px solid #EFCA68; */margin:2px 0px; display:inline;}
#tidypics_controls ul li.item-tag {background:transparent url(<?php echo $vars['url']; ?>mod/tidypics/graphics/tag.png) no-repeat 3px center;}
#tidypics_controls ul li.item-download {background:transparent url(<?php echo $vars['url']; ?>mod/tidypics/graphics/disk.png) no-repeat 3px center;}
#tidypics_controls ul li.item-edit{background:transparent url(<?php echo $vars['url']; ?>mod/tidypics/graphics/pencil.png) no-repeat 3px center;}
#tidypics_controls ul li.item-remove{background:transparent url(<?php echo $vars['url']; ?>mod/tidypics/graphics/delete.png) no-repeat 3px center;}
#tidypics_controls ul li.item-remove-tag{background:transparent url(<?php echo $vars['url']; ?>mod/tidypics/graphics/tag_blue_delete.png) no-repeat 3px center;}
#tidypics_controls ul li a{margin:0px; padding:0px;}
#tidypics_controls ul li a:hover{color:#004A6F;}

#tidypics_phototags {margin-bottom:10px; }
#tidypics_phototags img {position:absolute;}
#tidypics_phototags ul {list-style:nome; list-style-type:none; margin:0px; padding:8px;}
#tidypics_phototags ul li {padding:2px; margin:1px 0px; display:inline;}
#tidypics_phototags ul li a span{padding:2px 0px 0px 20px;}

#tidypics_controls a{
	margin:10px;
}

	/* independent album view only */
	
.album_images{
	float:left;
	width:160px; 
	height:160px;
	margin:4px;
	padding:5px;
	border:1px solid #ccc;	
	text-align:center;
}

	/* independent image view only */

#image_full{
	text-align:center;
	margin:10px;
}
/*#image_full img{ 	background:white none repeat scroll 0 0; border:1px solid #DDDDDD; margin:10px;}*/



#tagging_instructions {background:#FFFBE2 none repeat scroll 0 0; border:1px solid #FFE222; margin:10px; padding:10px;  display:none;}
#tagging_instructions table {-moz-box-sizing:border-box; border-collapse:separate; border-spacing:2px; display:table; margin-bottom:0; margin-top:0; text-indent:0;}
#tagging_instructions button.submit_button {margin:0px;}
#tagging_instructions #instructions_default_message {padding:4px;}

#cont-image {margin:0px auto; background:white none repeat scroll 0 0; border:1px solid #DDDDDD; padding:10px; overflow:hidden;} 

div#cont-menu {border:1px solid #3B5999; width:200px; position:absolute;z-index:10000; display:none; background:#fff; padding:5px; font-size:12px; text-align:left; }
div#cont-menu p {padding:0px; margin:0px; color:gray; font-weight:bold; font-size:11px;}
div#cont-menu input.input-filtro {width:180px;}
div#cont-menu ul {height:150px; overflow:auto; list-style:none; padding:0px; margin:0px; background:#EEEEEE; padding:5px 3px;}

div#cont-menu ul li {margin:1px 0px; padding:2px 0px;}
div#cont-menu ul li.owner {border-bottom:1px solid gray;}
div#cont-menu ul li a {color:black; text-decoration:none; padding-left;5px;}
div#cont-menu ul li a:hover {font-weight:bolder;}
div#cont-menu ul li a.selected {background:transparent url(<?php echo $vars['url']; ?>mod/tidypics/graphics/selected.gif) no-repeat scroll 0 0; padding-left:18px;}

div#cont-menu fieldset {border:none; margin:0px; padding:8px 3px 0px 0px; text-align:center;}
div#cont-menu fieldset button {margin:0px; width:200px;}


div.phototag {height:140px; position:absolute; text-align:center;}
div.phototag span {margin:0px; display:block; text-indent:-9999px; background:transparent url(img/blank.gif);}
/*div.phototag span:hover {border:1px solid white;}*/
div.phototag em {background:#EFFEFF; border:none; color: #61A6DF; opacity:0.8;position: relative;text-align: center; z-index: 2; display: none; font-size:10px; font-style:normal; padding:3px 0px; margin:-20px auto 0px; font-weight:bolder; -moz-border-radius:2px;}




/*  --- albums gallery view --- */

.album_cover{
	padding:2px;
	/*border:1px solid #ccc;*/
	margin: 4px 0;
}


/* ------ album WIDGET VIEW ------  */

#album_widget_container{
	text-align:center;
}

.album_widget_single_item{

}
.album_widget_title{

}
.album_widget_timestamp {
	color:#666666;
	margin:0;
}
.collapsable_box #album_widget_layout {
	margin:0;
}

/* ---------  image upload/edit forms  ------------   */

#image_upload_list li{
	margin:3px 0;
}
.edit_image_container{
	padding:5px;
	margin:5px 0;
	overflow:auto;
}
.edit_images{
	float:right;
	width:160px; 
	height:160px;
	margin:4px;
	padding:5px;
	border:1px solid #ccc;	
	text-align:center;
}
.image_info{
	float:left;
	width:60%;
}
.image_info label{
	font-size:1em;
}
.edit_image{
	float:right;
	border:1px solid #ccc; 
	width:153px; 
	height:153px;
}

/* ---------  tidypics river items ------------   */

.river_image_create {
	background: url(<?php echo $vars['url']; ?>mod/tidypics/graphics/icons/river_icon_image.gif) no-repeat left 0px;
}
.river_album_create {
	background: url(<?php echo $vars['url']; ?>mod/tidypics/graphics/icons/river_icon_album.gif) no-repeat left 0px;
}

.pagination {
	clear:both !important;
}
	