<?php
	/**
	 * Elgg blog: add post action
	 * 
	 * @package ElggBlog
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.org/
	 */

		gatekeeper();
		action_gatekeeper();
		
		$user_id = get_input('user_id', null);
		$entity_guid = get_input('entity_guid', null);
		$word = get_input('word');
		$coordinates_str = get_input('coordinates');
		
		if(is_null($entity_guid) && empty($entity_guid))
			forward($_SERVER['HTTP_REFERER']);
		else $entity = get_entity($entity_guid);
			
		if(!$entity)
		{
			forward($_SERVER['HTTP_REFERER']);
			register_error(elgg_echo("image:phototagging:notexists"));
		}
			
		if(!is_null($user_id))
		{
			$relationships_type = 'user';
			$value = $user_id;
		}
		else
		{
			$relationships_type = 'word';
			$value = $word;
		}
		
		if(empty($value))
			if($relationships_type == 'user')
				register_error(elgg_echo("image:phototagging:emptyuser"));
			else
				register_error(elgg_echo("image:phototagging:emptyword"));
		
		 

		$coordinates = explode('/',substr($coordinates_str,0,-1));
		$new_coordinates = array();
		if($coordinates) foreach($coordinates as $coordinate)
		{
			$aux = explode(':',$coordinate);
			if(is_array($aux))
				$new_coordinates[$aux[0]] = $aux[1];
		}
		
		$data = (object)$new_coordinates;
		
		$data->type = $relationships_type;
		$data->value = $value;  
		
		
		$access_id = $entity->getAccessID();
		$owner_id = get_loggedin_userid();

		//Save annotation
		if($entity->annotate('phototag', serialize($data), $access_id, $owner_id))
		{
			if($relationships_type == 'user')
			{
				if(!check_entity_relationship($value,'phototag',$entity_guid))
					add_entity_relationship($value, 'phototag', $entity_guid);
			}
			system_message(elgg_echo("image:tagged"));
		}
		
		forward($_SERVER['HTTP_REFERER']);
?>