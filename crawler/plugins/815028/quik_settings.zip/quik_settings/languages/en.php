<?php

	$english = array(
			
		'quik:language:title' => "Change Language",
		'quik:tip' => "Quick Settings",
		'quik:user:name' => "Change Your Name",
		'quik:user:email' => "Change Your Email",
		'quik:settings:link' => "See All Settings",
		
	);
					
	add_translation("en",$english);

?>