<?php

$chinese = array( 
		'quik:language:title' => "换语言",
		'quik:tip' => "快速设置",
		'quik:user:name' => "换你的名字",
		'quik:user:email' => "换你的邮件",
		'quik:settings:link' => "看所有设置",
		
	); 

add_translation('zh', $chinese); 

?>