<?php

/**
 * Elgg members plugin
 * This plugin has some interesting options for users; see who is online, site members, 
 * 
 * @package Elggmembers
 */

register_elgg_event_handler('init', 'system', 'quik_settings_init');

function quik_settings_init() {
	global $CONFIG;
	
	elgg_extend_view('css', 'quik_settings/css');
	elgg_extend_view('header_contents/extend', 'quik_settings/quik_settings');
}


// Register actions
		global $CONFIG;
		register_action("quik_settings/name",false,$CONFIG->pluginspath . "quik_settings/actions/name.php");
		register_action("quik_settings/email",false,$CONFIG->pluginspath . "quik_settings/actions/email.php");
