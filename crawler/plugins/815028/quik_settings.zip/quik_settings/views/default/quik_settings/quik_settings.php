<script src="<?php echo $vars['url'];?>mod/quik_settings/js/jquery.tabSlideOut.v1.3.js"></script>
<script type="text/javascript">
		$(function(){
		$(".quiktipclass").tipTip({defaultPosition: "right"});
		});
	</script>         
         <script>
         $(function(){
             $('.slide-out-div').tabSlideOut({
                 tabHandle: '.handle',                              //class of the element that will be your tab
                 pathToTabImage: '<?php echo $vars['url'];?>mod/quik_settings/graphics/settings_tab.gif',          //path to the image for the tab (optionaly can be set using css)
                 imageHeight: '40px',                               //height of tab image
                 imageWidth: '40px',                               //width of tab image    
                 tabLocation: 'left',                               //side of screen where tab lives, top, right, bottom, or left
                 speed: 300,                                        //speed of animation
                 action: 'click',                                   //options: 'click' or 'hover', action to trigger animation
                 topPos: '200px',                                   //position from the top
                 fixedPosition: true                               //options: true makes it stick(fixed position) on scroll
             });
         });

         </script>

<?php
	// Get the user
	$user = get_loggedin_user();
	$ts = time();
	$token = generate_action_token($ts);
	$loader = "<img style='width:15px;height:15px;' src='{$vars['url']}mod/embed/images/loading.gif'>";
	if(isloggedin()){
?>

 <div class="slide-out-div">
 	<a class="handle quiktipclass" title='<?php echo elgg_echo("quik:tip");?>' href="http://link-for-non-js-users">Settings</a>
 	<?php      
 	
 		// Universal guid input for each action
 		echo "<input type='hidden' id='guid' value='{$user->guid}' />";
 		
 		// Option to change user's name
 		echo "<h3>" . elgg_echo('quik:user:name') . "</h3>";
 		echo "<input type='text' id='myname' name='myname' value='{$user->name}' />";
 		echo "<a class='submit_button' id='change_name' onclick='change_my_name();'>Go</a>";
 		echo "<span id='name_done' style='display:none;'><img style='width:15px;height:15px;' src='{$vars['url']}mod/quik_settings/graphics/correct.jpg'></span>";
 		echo "<span id='name_loader' style='display:none;'><img style='width:15px;height:15px;' src='{$vars['url']}mod/embed/images/loading.gif'></span>";
 		echo "<br>";

 		// Option to change user's email 		 		
 		echo "<h3>" . elgg_echo('quik:user:email') . "</h3>";
 		echo "<input type='text' id='myemail' name='myemail' value='{$user->email}' />";
 		echo "<a class='submit_button' id='change_email' onclick='change_email();'>Go</a>";
  		echo "<span id='email_done' style='display:none;'><img style='width:15px;height:15px;' src='{$vars['url']}mod/quik_settings/graphics/correct.jpg'></span>";
 		echo "<span id='email_loader' style='display:none;'><img style='width:15px;height:15px;' src='{$vars['url']}mod/embed/images/loading.gif'></span>";
		echo "<br><br>";
		
	
		
		if(is_plugin_enabled("language_selector")){
	 		echo "<h3>" . elgg_echo('quik:language:title') . "</h3><br>";
	 		echo elgg_view("language_selector/default");
	 		echo "<br><br>";
 		}
 		
		echo "<a class='submit_button' href='{$vars['url']}pg/settings/user/{$user->username}'>" . elgg_echo('quik:settings:link') . "</a>";
 		
 		
 		
 	?>
 	
 	
 </div>

<script>
$.ajaxSetup ({
cache: false
});


function change_my_name(){
		var guid = $("#guid").attr('value');
		var myname = $("#myname").attr('value');
		var token = "<?php echo $token; ?>";
		var ts = "<?php echo $ts; ?>";
		datastr = "&myname=" + myname;
		datastr += "&guid=" + guid;
		datastr += "&__elgg_token=" + token;
		datastr += "&__elgg_ts=" + ts;
		$("#change_name").hide();
		$("#name_loader").show();
		$.ajax({
			type: "POST",
			url: "<?php echo $vars['url']; ?>action/quik_settings/name",
			data: datastr,
			success: function(msg){
				$("#name_loader").hide();
				$("#name_done").show();
				$("#name_done").delay(5000).hide();
				$("#change_name").show();
				$("#myname").val(msg);
			}
		});
}

function change_email(){
		var guid = $("#guid").attr('value');
		var myemail = $("#myemail").attr('value');
		var token = "<?php echo $token; ?>";
		var ts = "<?php echo $ts; ?>";
		datastr = "&myemail=" + myemail;
		datastr += "&guid=" + guid;
		datastr += "&__elgg_token=" + token;
		datastr += "&__elgg_ts=" + ts;
		$("#change_email").hide();
		$("#email_loader").show();
		$.ajax({
			type: "POST",
			url: "<?php echo $vars['url']; ?>action/quik_settings/email",
			data: datastr,
			success: function(msg){
				$("#email_loader").hide();
				$("#email_done").show();
				$("#email_done").delay(5000).hide();
				$("#change_email").show();
				$("#myemail").val(msg);
			}
		});
}
</script> 
 
 
 
 
  
<?php
} // Check if user is logged in
?>

