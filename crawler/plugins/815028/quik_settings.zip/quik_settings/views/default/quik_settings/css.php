<?php

	/**
	 * Elgg Quik Settings
	 * 
	 * @package Quik Settings
	 */

?>

.slide-out-div {
   padding: 10px;
    width: 250px;
    background: #f2f2f2;
    border: #0357a6 2px solid;
    z-index: 201;
}
.handle {
	margin-top: -3px;
	margin-left: 2px;
	z-index: 200;
}