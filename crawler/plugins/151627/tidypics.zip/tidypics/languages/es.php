<?php
	/**
	 * Elgg tidypics plugin language pack
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$spanish = array(
			
		// Menu items and titles
			 
			'image' => "Imagen",
			'images' => "Imagenes",
			'caption' => "Titulo",		
			'photos' => "Fotos",
			'images:upload' => "Subir Imagenes",
			'album' => "Albums de Fotos",
			'albums' => "Albums de Fotos",
			'album:yours' => "Tus albums de fotos",
			'album:yours:friends' => "Albums de fotos de tus amigos",
			'album:user' => "Albums de fotos de %s",
			'album:friends' => "Albums de fotos de los amigos de %s",
			'album:all' => "Todos los albums de fotos",
			'album:group' => "Albums de grupo",
	
		//actions
		
			'album:create' => "Crear Album",
			'album:add' => "Añadir Album de Fotos",
			'album:addpix' => "Añadir fotos",		
			'album:edit' => "Editar album",			
			'album:delete' => "Borrar album",		

			'image:edit' => "Editar imagen",
			'image:delete' => "Borrar imagen",
		
		//forms
		
			'album:title' => "Titulo",
			'album:desc' => "Descripcion",
			'album:tags' => "Tags",
			'album:cover' => "Hacer de esta foto la caratula del album?",
			'image:access:note' => "(Permisos de vision heredados del album)",
			
		//views 
		
			'image:total' => "Imagenes en album:",
			'image:by' => "Imagen añadida por",
			'album:by' => "Album creado por",
			'image:none' => "Ninguna imagen añadida.",
			'image:back' => "Anterior",
			'image:next' => "Siguente",
		
		//widgets
		
			'album:widget' => "Albums de Fotos",
			'album:more' => "Ver todos los albumns",
			'album:widget:description' => "Mostrar los ultimos albums de fotos",
			'album:display:number' => "Numero de albums a mostrar",
			'album:num_albums' => "Numero de albums a mostrar",
			
		//  river
		
			//images
			'image:river:created' => "%s ha añadido",
			'image:river:item' => "una imagen",
			'image:river:annotate' => "%s hizo un comentario en",	
		
			//albums
			'album:river:created' => "%s ha creado",
			'album:river:item' => "un album",
			'album:river:annotate' => "%s hizo un comentatio en",				
				
		//  Status messages
			
			'images:saved' => "Imagen grabada correctamente.",
			'images:saved' => "Todas las imagentes se grabaron correctamente.",
			'image:deleted' => "Imagen borrada correctamente.",			
			'image:delete:confirm' => "Desea borrar esta imagen?",
			
			'images:edited' => "Imagenes actualizadas correctamente.",
			'album:edited' => "Album actualizado correctamente.",
			'album:saved' => "Album grabado correctamente.",
			'album:deleted' => "Album borrado correctamente.",	
			'album:delete:confirm' => "Desea borrar este album?",
				
		//Error messages
				 
			'image:none' => "No se ha encontrado ninguna imagen.",
			'image:uploadfailed' => "Archivos no subidos:",
			'image:deletefailed' => "La imagen no se ha podido borrar.",
			
			'image:notimage' => 'Solo se aceptan los formatos jpeg, gif, o png.',
			'images:notedited' => 'No se han podido actualizar todas las imagenes',
		 
			'album:none' => "No se ha encontrado ningun album.",
			'album:uploadfailed' => "Disculpe; no se ha podido grabar el album.",
			'album:deletefailed' => "No se ha podido borrar el album.",
	
	);
					
	add_translation("es",$spanish);
?>