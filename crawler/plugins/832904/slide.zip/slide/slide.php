<?php
if (isloggedin()) forward('activity');
?>
<html>
<head>
<?php
//Title configuration below
?>
<title>Welcome!</title>
        <?php
        //Favicon configuration below. Allows you to use a custom favicon for the HOMEPAGE only.
        ?>
        <link rel="shortcut icon" href=<?php echo $site_url; ?>"mod/slide/icon.ico" type="image/x-icon"/>
    </head>
<?php $messages = system_messages();	
	$message = $messages['messages'];
	
	if(count($message) > 0){ 
		echo '<div  style="color: white;" class="messages">';
		echo '<span class="closeMessages"><a  style="color: white;" href="#">dismiss</a></span>';
			foreach($message as $message1)
					{
					echo '<p  style="color: white;">';
					echo $message1;
					echo '</p>';
					}
		echo '</div>';
	}

	$errors = register_error();
	$error = $errors['errors'];
	if(count($error) > 0){ 
		echo '<div class="messages_error">';
		echo '<span class="closeMessages"><a href="#">dismiss</a></span>';
			foreach($error as $error1)
					{
					echo '<p>';
					echo $error1;
					echo '</p>';
					}
		echo '</div>';
	}


////////////////////////////////////////////////////////////////////////////////////////////////
?>
<body>
<table width="100%" style="height: 100%;" cellpadding="10" cellspacing="0" border="0">
<tr>

<!-- ============ HEADER SECTION ============== -->
<td colspan="3" style="height: 100px;" bgcolor="#CCFFCC"><center><img src="http://t0.gstatic.com/images?q=tbn:ANd9GcQPk2K7GEuISG7Q5EZrtCVN4ctuuTT7cBQ3V9C1w_-EHCl1qdoX" width="200" height="100"></center></td></tr>
<tr><td colspan="3" valign="middle" height="30" bgcolor="#A9F5A9"><marquee><font face="Times New Roman">Welcome to our network. This is sliding text that needs actual content.</font></td></tr>

<tr>
<td width="20%" valign="top" bgcolor="#999f8e">
<font face="Times New Roman">This is a good place for an about us or site description. If you are a webmaster, edit this at yoursite/mod/slide/slide.php.</font>
</td>
<td width="30%" valign="top" bgcolor="#8181F7">
<font face="Times New Roman"><?php
/**
 * Elgg register form
 *
 * @package Elgg
 * @subpackage Core
 */

$password = $password2 = '';
$username = get_input('u');
$email = get_input('e');
$name = get_input('n');

if (elgg_is_sticky_form('register')) {
	extract(elgg_get_sticky_values('register'));
	elgg_clear_sticky_form('register');
}

?>
<div class="mtm">
	<label><?php echo elgg_echo('name'); ?></label><br />
	<?php
	echo elgg_view('input/text', array(
		'name' => 'name',
		'value' => $name,
		'class' => 'elgg-autofocus',
	));
	?>
</div>
<div>
	<label><?php echo elgg_echo('email'); ?></label><br />
	<?php
	echo elgg_view('input/text', array(
		'name' => 'email',
		'value' => $email,
	));
	?>
</div>
<div>
	<label><?php echo elgg_echo('username'); ?></label><br />
	<?php
	echo elgg_view('input/text', array(
		'name' => 'username',
		'value' => $username,
	));
	?>
</div>
<div>
	<label><?php echo elgg_echo('password'); ?></label><br />
	<?php
	echo elgg_view('input/password', array(
		'name' => 'password',
		'value' => $password,
	));
	?>
</div>
<div>
	<label><?php echo elgg_echo('passwordagain'); ?></label><br />
	<?php
	echo elgg_view('input/password', array(
		'name' => 'password2',
		'value' => $password2,
	));
	?>
</div>

<?php
// view to extend to add more fields to the registration form
echo elgg_view('register/extend');

// Add captcha hook
echo elgg_view('input/captcha');

echo '<div class="elgg-foot">';
echo elgg_view('input/hidden', array('name' => 'friend_guid', 'value' => $vars['friend_guid']));
echo elgg_view('input/hidden', array('name' => 'invitecode', 'value' => $vars['invitecode']));
echo elgg_view('input/submit', array('name' => 'submit', 'value' => elgg_echo('register')));
echo '</div>';
?></font></td>

<td width="25%" valign="top" bgcolor="#E3CEF6"><font face="Times New Roman"><?php
/**
 * Elgg login box
 *
 * @package Elgg
 * @subpackage Core
 *
 * @uses $vars['module'] The module name. Default: aside
 */

$module = elgg_extract('module', $vars, 'aside');

$login_url = elgg_get_site_url();
if (elgg_get_config('https_login')) {
	$login_url = str_replace("http:", "https:", $login_url);
}

$title = elgg_echo('login');
$body = elgg_view_form('login', array('action' => "{$login_url}action/login"));

echo elgg_view_module($module, $title, $body);
?></font>
</td>

</tr>

<!-- ============ FOOTER SECTION ============== -->
<tr><td colspan="3" align="center" height="20" bgcolor="#777d6a">Copyright © 2011, YourCompany</td></tr>
</table>










