<?php

	$french = array(

		/**
		 * Misc
		 */

			"profile:name" => "Nom",
			"profile:age" => "Age",
			"profile:dateofbirth" => "Date de naissance",
			"profile:age:unit" => "ans",
			"profile:description:none" => "...",

			"profile:gender" => "Genre",
			"profile:gender:n" => "Sélectionner",
			"profile:gender:m" => "Homme",
			"profile:gender:f" => "Femme",

			"profile:birthdate" => "Date de naissance",
			
			"date:day" => "jour",
			"date:month" => "mois",
			"date:year" => "année",

			"month:1" => "Janvier",
			"month:2" => "Février",
			"month:3" => "Mars",
			"month:4" => "Avril",
			"month:5" => "Mai",
			"month:6" => "Juin",
			"month:7" => "Juillet",
			"month:8" => "Août",
			"month:9" => "Septembre",
			"month:10" => "Octobre",
			"month:11" => "Novembre",
			"month:12" => "Décembre",
	);
	
	add_translation("fr",$french);

?>
