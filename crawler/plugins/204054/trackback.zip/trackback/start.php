<?php

	/**
	 * Simple trackback plugin
	 * Cash Costello
	 *
	 * See http://www.sixapart.com/pronet/docs/trackback_spec
	 */
	 
	 
	function trackback_init()
	{
		global $CONFIG;
		
		register_page_handler('trackback','trackback_page_handler');
		
		register_entity_type('object','trackback');
		
		extend_view('css','trackback/css');
		
		register_plugin_hook('permissions_check', 'all', 'trackback_permission_override');
	}
	
	
	// Tracks take the form of http://example.org/pg/trackback/<username>
	// Should be extended for security to http://example.org/pg/trackback/<username>/<security code>
	function trackback_page_handler($page) 
	{
		global $CONFIG;
		
		if (isset($page[0])) {
			set_input('username',$page[0]);
		}
		
		include($CONFIG->pluginspath . "trackback/receive.php"); 
	}
	
	
	function trackback_permission_override($hook, $entity_type, $returnvalue, $params)
	{
		if (get_context() == 'trackback')
			return true;
	}
	
	
	register_elgg_event_handler('init','system','trackback_init');
?>