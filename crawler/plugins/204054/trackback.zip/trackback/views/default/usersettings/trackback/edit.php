<p>
<?php 
	echo elgg_echo('trackback:instructions');
	echo "<br /><br />";
	echo "{$vars['url']}pg/trackback/{$vars['user']->username}";
?>
</p>