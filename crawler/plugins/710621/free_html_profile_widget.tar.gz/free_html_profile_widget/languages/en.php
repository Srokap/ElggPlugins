<?php
$english = array(
	'widgets:free_html:settings:title' => "Free HTML",
	'widgets:free_html:settings:widget_title' => "Title (optional)",
	'widgets:free_html:settings:html_content' => "HTML content",
);
				
add_translation("en",$english);
?>