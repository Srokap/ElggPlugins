<?php 

function free_html_profile_widget_init() {
	
	add_widget_type('free_html',"Free HTML","Widget for Free HTML in Profiles");	
}

register_elgg_event_handler('init','system','free_html_profile_widget_init');

?>