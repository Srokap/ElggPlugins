Please note always make backup copies of the original files first

drop custom_index.php in mod/custom_index/views/default/page/layouts/

ensure that this theme is directly above the custom_index in your plugins via admin, this needs to be done in order to display the main page correctly, if you have to move the custom index plugin to the bottom make sure this theme is directly above it, if you are using the custom_index included. Also the custom index can be edited directly between the body tags for altering the main page texts and links. Please check out the screen shot showing settings in the admin panel.

enjoy

