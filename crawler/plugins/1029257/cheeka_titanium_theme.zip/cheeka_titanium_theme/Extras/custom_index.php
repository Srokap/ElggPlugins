
<?php
/**
 * Elgg custom index layout
 * 
 * You can edit the layout of this page with your own layout and style. 
 * Whatever you put in this view will appear on the front page of your site.
 * 
 */

$mod_params = array('class' => 'elgg-module-highlight');

?>

<div class="custom-index elgg-main elgg-grid clearfix">
	<div class="elgg-col elgg-col-1of5">
		<div class="elgg-inner pvm prl">
<?php
// left column

// Top box for login or welcome message
if (elgg_is_logged_in()) {
	$top_box = "<h2>" . elgg_echo("welcome") . " ";
	$top_box .= elgg_get_logged_in_user_entity()->name;
	$top_box .= "</h2>";
} else {
	$top_box = $vars['login'];
}
echo elgg_view_module('featured',  '', $top_box, $mod_params);

// a view for plugins to extend
echo elgg_view("index/lefthandside");


?>

		</div>
	</div>
	<div class="elgg-col elgg-col-4of5">
		<div class="elgg-inner pvm">
<?php

//code here

?>
<body bgcolor="white" text="black" link="#0033CC" vlink="purple" alink="red" leftmargin="0" marginwidth="0" topmargin="0" marginheight="0">
<div align="left">
<table width="805" cellpadding="0" cellspacing="0" bordercolordark="white" bordercolorlight="black">
        <tr>
            <td width="288" height="331" align="left" valign="top">
         
         
                <p>&nbsp;</p>
                <p>Elgg is an award-winning open source social networking engine that 
provides a robust framework on which to build all kinds of social 
environments, from a campus wide social network for your university, 
school or college or an internal collaborative platform for your 
organization through to a brand-building communications tool for your 
company and its clients.<br><b><u><font color="#26478E"><br>LINKS</font></u></b><br><a href="http://www.favicon.co.uk/index.php" target="_blank">Favicon generator<br></a><a href="http://www.google.com" target="_blank">Google<br></a><a href="http://www.bbc.co.uk/news/world/" target="_blank">BBC News</a></p>
            </td>
            <td width="16" height="331" align="left" valign="top">&nbsp;</td>
            <td width="501" height="331" align="center" valign="top">
                <p align="left"><iframe width="420" height="315" src="http://www.youtube.com/embed/PtdcdxvNI1o" frameborder="0" allowfullscreen></iframe></p>
                <p align="left">&nbsp;</p>
                <p align="left">&nbsp;</p>
                <p align="left">&nbsp;</p>
                <p align="left">&nbsp;</p>
            </td>        </tr>
        <tr>
            <td width="805" height="10" align="left" valign="top" colspan="3">
                <p><font color="#999999">____________________________________</font><span style="font-size:11pt;"><u><font color="#999999">Copyright Cheekaboo 2010_</font></u><font color="#999999">____________________________________</font></span></p>
            </td>
        </tr>
</table>
</div>

</body>

<?php
//more code here

?>



		</div>
	</div>
</div>

