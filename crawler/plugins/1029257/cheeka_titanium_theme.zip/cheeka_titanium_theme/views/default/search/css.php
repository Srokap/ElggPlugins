<?php
/**
 * Elgg Search css
 * 
 */
?>

/**********************************
Search plugin
***********************************/
.elgg-page-header .elgg-search {
	bottom: 57px;
	height: 31px;
	position: absolute;
	right: 10px;
	background:url(<?php echo $vars['url']; ?>mod/cheeka_titanium_theme/graphics/search.png) no-repeat;
	padding-right:60px;
}
.front_left {
	width:420px;
	margin-left:50px;
	}
.front_right {
	width:420px;
	margin-right:50px;
	}
.search-input {
	border:none;
	}
.elgg-page-header .elgg-search input[type=text] {
	width: 166px;
}
.elgg-page-header .elgg-search input[type=submit] {
	display: none;
}
.elgg-search input[type=text] {
	color: #000000;
	font-size: 12px;
	font-weight: bold;
	padding: 2px 4px 2px 26px;
	background: transparent url(<?php echo elgg_get_site_url(); ?>_graphics/elgg_sprites.png) no-repeat 2px -718px;
	margin-top:6px;
	margin-left:6px;
}
.elgg-search input[type=text]:focus, .elgg-search input[type=text]:active {
	background-position: 2px -700px;
	color: #000000;
	border:none;
}

.search-list li {
	padding: 5px 0 0;
}
.search-heading-category {
	margin-top: 20px;
	color: #000000;
}

.search-highlight {
	background-color: ;
}
.search-highlight-color1 {
	background-color: ;
}
.search-highlight-color2 {
	background-color: ;
}
.search-highlight-color3 {
	background-color: ;
}
.search-highlight-color4 {
	background-color: ;
}
.search-highlight-color5 {
	background-color: ;
}
