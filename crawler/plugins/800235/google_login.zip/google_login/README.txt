This plugin uses  LightOpenID Library (http://code.google.com/p/lightopenid/)
and is based on "Facebook Connect Login for Elgg 1.8" from Chetan Varshney
(http://community.elgg.org/pg/plugins/release/797592/developer/chetanvarshney/facebook-connect-login-for-elgg-18)