<?php
		
	/**
	 * Elgg manage multiple users -  start page
	 * 
	 * @package Elgg manage_multi_users
	 * @author Cubet Technologies
	 * @copyright Cubet Technologies 2009-2010
	 * @link http://elgghub.com
	 */ 
	 
	// Load system configuration
		global $CONFIG;

	function manage_multi_users_init() {
	    // Load system configuration
		global $CONFIG;
		// Extend CSS
		extend_view("css", "manage_multi_users/css");
		
		// Admin user list view
    	// Page handler
	  	register_page_handler('admin','admin_settings_page_handler_list_user');
		
   }
   
   // Admin page handler
	function admin_settings_page_handler_list_user($page)
	{
		global $CONFIG;
		
		$path = $CONFIG->path . "admin/index.php";
		
		if ($page[0])
		{
			switch ($page[0])
			{
				case 'user' : $path = $CONFIG->path . "mod/manage_multi_users/user.php"; break;
				case 'statistics' : $path = $CONFIG->path . "admin/statistics.php"; break;
				case 'plugins' : $path = $CONFIG->path . "admin/plugins.php"; break;
				case 'site' : $path = $CONFIG->path . "admin/site.php"; break;
			}
		}
		
		if ($page[1])
			set_input('username', $page[1]);
			
		include($path);
	}
   	// Admin, users mass action 
	register_action("manage_multi_users/user_batchaction/",false,$CONFIG->pluginspath . "manage_multi_users/actions/admin_user_action.php"); 
	
   // Make sure test_init is called on initialisation
	register_elgg_event_handler('init','system','manage_multi_users_init');
   	
?>