<?php

	$english = array(
	
         /**
	     * manage_multi_users plugin
	     **/
	        //generic terms to use
		'manage_multi_users:admin:batachaction:success'=>'Action Completed',
		'manage_multi_users:admin:batachaction:failer'=>'Action Failed',
	);
					
	add_translation("en",$english);

?>
