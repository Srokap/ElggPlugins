<?php

	/**
	 * Elgg blog CSS extender
	 * 
	 * @package ElggBlog
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

?>

.user_list_chk{
	float:right;
	margin-top:10px;
	margin-right:10px;
}
input[type="button"]:hover {
	background:#0054A7 none repeat scroll 0 0;
	border-color:#0054A7;
}
input[type="button"] {
	-moz-border-radius-bottomleft:4px;
	-moz-border-radius-bottomright:4px;
	-moz-border-radius-topleft:4px;
	-moz-border-radius-topright:4px;
	-x-system-font:none;
	border-color:#4690D6;
	background:#4690D6 none repeat scroll 0 0;
	color:#FFFFFF;
	cursor:pointer;
	font-family:Arial,Helvetica,sans-serif;
	font-size:12px;
	font-size-adjust:none;
	font-stretch:normal;
	font-style:normal;
	font-variant:normal;
	font-weight:bold;
	height:25px;
	line-height:100%;
	margin:10px 0;
	padding:2px 6px;
	width:auto;
}		