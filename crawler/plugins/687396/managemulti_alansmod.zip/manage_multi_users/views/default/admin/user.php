<?php

	/**
	 * Elgg administration user main screen
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @author Curverider Ltd
	 * @link http://elgg.org/
	 */

	// Description of what's going on
		echo "<div class=\"contentWrapper\"><span class=\"contentIntro\">" . elgg_view('output/longtext', array('value' => elgg_echo("admin:user:description"))) . "</span></div>";
	
		echo elgg_view("admin/user_opt/adduser");
		
		echo elgg_view("admin/user_opt/search");
		
		
		// Over write for display the users with mass action
		$limit = get_input('limit', 10);
		$offset = get_input('offset', 0);
		$count = get_entities('user', '', 0, "", $limit, '', true);
		$entities = get_entities('user', '', 0, "", $limit, $offset);	
			
		$baseurl = $_SERVER['REQUEST_URI'];
		$nav = elgg_view('navigation/pagination',array(
														'baseurl' => $baseurl,
														'offset' => $offset,
														'count' => $count,
														'limit' => $limit,
														));
		$html = "";
		if($count>0){				
			$html .= "<form name ='user_list'>";
			$html .= "<div style='float:top;margin-top:25px;'>&nbsp;<input type='button' id='btnBan' value='Ban' disabled onclick=\"javascript:submit_action('ban');\">&nbsp;<input type='button' id='btnDel' value='Delete' disabled onclick=\"javascript:submit_action('delete');\" >&nbsp;Click to Select All >>> <input type=\"checkbox\" id=\"chk_select_all\" value=\"selectall\" onclick=\"javascript:select_all();\"></input></div>";
			$html .="<div class='clear'></div>";
			
			$index = 0; 			
			foreach($entities as $user_entity){
					$html .= elgg_view('admin/user_listing',array('entity'=>$user_entity,'index'=>$index));
					$banned = $user_entity->isBanned();
					if(!$banned){
						$index++;
					}	
			}
			$html .= elgg_view('input/securitytoken');
			$html .="</form>";
			$html .= $nav;
		}		
		echo $html;			
?>
<script language="javascript" type="text/javascript">
			function select_all(){						
				var index = <?php echo $index;?>*1;
				index = index*1;
				for(i=0;i<index;i++){
					if(document.getElementById('chk_select_all').checked == true){
						if(document.getElementById('user_array'+i)){
							document.getElementById('user_array'+i).checked = true;
							document.getElementById('btnBan').disabled = false;
							document.getElementById('btnDel').disabled = false;						
							
						}
					}else{
						if(document.getElementById('user_array'+i)){
							document.getElementById('user_array'+i).checked = false;
							document.getElementById('btnBan').disabled = true;
							document.getElementById('btnDel').disabled = true;				
						}
					}			
				}	
			}
			function selectButton(){
				var max = <?php echo $index;?>*1;
				btnflg = false;
				var count = 0;
				for(i=0;i<max;i++){
					if(document.getElementById('user_array'+i)){
						if(document.getElementById('user_array'+i).checked == true){
							btnflg = true;
							count++;
						}
					}	
				}
				if(btnflg === true){
					document.getElementById('btnBan').disabled = false;
					document.getElementById('btnDel').disabled = false;					
				}else{
					document.getElementById('btnBan').disabled = true;
					document.getElementById('btnDel').disabled = true;					
				}
				if(parseInt(count) == parseInt(max)){
					document.getElementById('chk_select_all').checked = true;
				}else{
					document.getElementById('chk_select_all').checked = false;
				}				
			}
			function submit_action(type){
				if(type=='ban' || type=='delete') {
					if(confirm('Are you sure?')){				
						document.user_list.method = "post";
						document.user_list.action = "<?php echo $CONFIG->wwwroot?>action/manage_multi_users/user_batchaction/?type="+type;
						document.user_list.submit();
					}else{
						return false;
					}	
				}
			}
</script>