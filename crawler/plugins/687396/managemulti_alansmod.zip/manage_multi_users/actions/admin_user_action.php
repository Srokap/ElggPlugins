<?php

	/**
	 * Elgg Essays 
	 * 
	 * @package ElggEssay
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Cubettech Ltd 
	 * @copyright Cubettech Ltd 2008-2009
	 * @link http://cubettech.com/
	 */
	require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
	// block non-admin users
	admin_gatekeeper();
	//action_gatekeeper();
	
	// Get the user 
	$type = get_input('type');
	$user_guids = get_input('user_guid');
	$error_user = "";
	$success_user ="";	
	foreach($user_guids as $user_guid){
		$obj = get_entity($user_guid);
		if($type == "delete") {
			if ( ($obj instanceof ElggUser) && ($obj->canEdit()))
			{
				if ($obj->delete()){
					$success_user .= $obj->name."<br>";
					$action_type = "deletion";
					//(elgg_echo('admin:user:delete:yes'));
				}else{
					$error_user .= $obj->name."<br>";
					$action_type = "deletion";
					//register_error(elgg_echo('admin:user:delete:no'));
				}	
			}
			
		}else if($type == "ban") {	
			if ( ($obj instanceof ElggUser) && ($obj->canEdit()))
			{
				// Now actually disable it
				if ($obj->ban('banned')) {
					$success_user .= $obj->name."<br>";
					$action_type = "ban";
					//system_message(elgg_echo('admin:user:ban:yes'));
				}
				else{
					$error_user .= $obj->name."<br>";
					$action_type = "ban";
				}	
			}	
		}	
	}	
	if($success_user!=""){
		$success_user_msg = sprintf(elgg_echo("manage_multi_users:admin:batachaction:success"),$action_type).$success_user;
	}
	if($error_user!=""){
		$error_user_msg = sprintf(elgg_echo("manage_multi_users:admin:batachaction:failer"),$action_type).$error_user;
	}
	system_message($success_user_msg."<br>".$error_user_msg);	
	forward($_SERVER['HTTP_REFERER']);