<?php
//megaprofile es.php
//diseñado por www.floops.com.ar
//la red social argentina
//para la comunidad elgg.org

$spanish = array(

	
	'megaprofile:profile:blog' => "Blog",
	'megaprofile:profile:pages' => "Paginas",
	'megaprofile:profile:wall' => "Actividad",
	'megaprofile:profile:video' => "videos",
	'megaprofile:profile:friends' => "Amigos",
	'megaprofile:profile:bookmarks' => "Marcadores",
	'megaprofile:profile:photo' => "Fotos",
	'megaprofile:profile:groups' => "grupos",
	
	'megaprofile:privacy:blog' => "quien puede ver mis blogs en el perfil",
	'megaprofile:privacy:pages' => "quien puede ver mis paginas en el perfil",
	'megaprofile:privacy:wall' => "quien puede ver mi muro en el perfil",
	'megaprofile:privacy:videos' => "quien puede ver mis videos en el perfil",
	'megaprofile:privacy:friends' => "quien puede ver mis amigos en el perfil",
	'megaprofile:privacy:bookmarks' => "quien puede ver mis favoritos en el perfil",
	'megaprofile:privacy:photo' => "quien puede ver mis fotos en el perfil",
	'megaprofile:privacy:groups' => "quien puede ver mis grupos en el perfil",
	'megaprofile:privacy:status' => "quien puede ver mi ultimo estado en el perfil",
	
);

add_translation("es", $spanish);