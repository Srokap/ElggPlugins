<?php

//megaprofile star.php
//megaprofile v1.1
//diseñado por www.floops.com.ar
//la red social argentina
//para la comunidad elgg.org

function megaprofile_init(){}
extend_view('css', 'megaprofile/css');
register_elgg_event_handler('init','system','megaprofile_init');

?>
