<?php

//megaprofile v1.1 userdetails.php
//diseñado por www.floops.com.ar
//la red social argentina
//para la comunidad elgg.org


if (isloggedin()){
if ($vars['entity']->canEdit()) {
?>
<div class="profile_info_edit_buttons">
<a href="<?php echo $vars['url']; ?>pg/profile/<?php echo $vars['entity']->username; ?>/edit/"><?php echo elgg_echo("profile:edit"); ?></a>
</div></br></br>
<?php
}
}
?>

<?php
echo "<h2><a href=\"" . $vars['entity']->getUrl() . "\" rel=\"$rel\">" . $vars['entity']->name . "</a></h2>";
if ($vars['full'] == true) {
$iconsize = "large";
} else {
$iconsize = "medium";
}
// wrap all profile info
echo "<div>";
?>


<?php
if (isloggedin()){
?>

<?php
$photo_url = $vars['url']."pg/photos/owned/".$vars['entity']->username;
echo "<a href=\"$photo_url\">".elgg_view( "profile/icon", array('entity' => $vars['entity'],'size' => $iconsize,'override' => true,))."</a>";
if (!isloggedin()){
echo "<div><b>El Usuario " .$vars['entity']->username." se encuentra en nuestra red registrate para poder ser su amigo.</b></div>";
}
echo "<div class=\"clearfloat\"></div>";
echo elgg_view("profile/profilelinks", array("entity" => $vars['entity']));
?>

<?php
}
?>

<?php
if (!isloggedin()){
?>

<?php
echo "<div>".elgg_view("profile/icon", array('entity' => $vars['entity'],'size' => $iconsize,'override' => true,))."</div>";
if (!isloggedin()){
echo "<div><b>El Usuario " .$vars['entity']->username." se encuentra en nuestra red registrate para poder ser su amigo.</b></div>";
}
echo "<div class=\"clearfloat\"></div>";
echo elgg_view("profile/profilelinks", array("entity" => $vars['entity']));
?>

<?php
}
?>

<?php
if (isloggedin()){
$rel_type = "";
if (get_loggedin_userid() == $vars['entity']->guid) {
$rel_type = 'me';
} elseif (check_entity_relationship(get_loggedin_userid(), 'friend', $vars['entity']->guid)) {
$rel_type = 'friend';
}
if ($rel_type) {
$rel = "rel=\"$rel_type\"";
}
}
if ($vars['full'] == true) {
?>

<?php
if (isloggedin()){
$even_odd = null;
if (is_array($vars['config']->profile) && sizeof($vars['config']->profile) > 0)
foreach($vars['config']->profile as $shortname => $valtype) {
if ($shortname != "description") {
$value = $vars['entity']->$shortname;
if (!empty($value)) {
$even_odd = ( 'odd' != $even_odd ) ? 'odd' : 'even';
?>

<p class="<?php echo $even_odd; ?>">
<b><?php
echo elgg_echo("profile:{$shortname}");
?>: </b>
<?php
$options = array(
'value' => $vars['entity']->$shortname
);

if ($valtype == 'tags') {
$options['tag_names'] = $shortname;
}

echo elgg_view("output/{$valtype}", $options);

?>

</p>

<?php
}
}
}
}
}
?>
<!-- /#profile_info_column_middle -->

<?php if (!get_plugin_setting('user_defined_fields', 'profile')) {?>
<?php if ($vars['entity']->isBanned()) { ?>
<div id="profile_banned">
<?php
echo elgg_echo('profile:banned');
?>
</div><!-- /#profile_info_column_right -->
<?php } else { ?>
<?php
echo elgg_view('output/longtext', array('value' => $vars['entity']->description));
//echo autop(filter_tags($vars['entity']->description));
?>
<?php } ?>
<!-- /#profile_info_column_right -->
<?php } ?>
<!-- /#profile_info -->
