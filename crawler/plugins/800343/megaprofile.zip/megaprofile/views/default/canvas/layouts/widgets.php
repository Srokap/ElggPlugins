<?php

//megaprofile widegets.php
//diseñado por MARIANO TOMASINI www.floops.com.ar
//la red social argentina
//para la comunidad elgg.org

$widgettypes = get_widget_types();
$owner = page_owner_entity();
$user_id = get_loggedin_userid();
$area1widgets = get_widgets(page_owner(),get_context(),1);
$area2widgets = get_widgets(page_owner(),get_context(),2);
$area3widgets = get_widgets(page_owner(),get_context(),3);
if (empty($area1widgets) && empty($area2widgets) && empty($area3widgets)) {
if (isset($vars['area3'])) {
$vars['area1'] = $vars['area3'];
}
if (isset($vars['area4'])) {
$vars['area2'] = $vars['area4'];
}
}
{
?>

<table width="100%">
<tbody id="main">
<tr>
<td>
<div id="plusriver_sidebar_left" style="padding-right:5px;">

<?php 
if (isset($vars['area1'])) {
echo $vars['area1'];
}
?>

<?php
if (isloggedin()){
?>


<?php
//FRIENDS
$friends_show = false;
$friends_shows_beta = get_plugin_usersetting("friends_shows_beta", $owner->guid, "megaprofile");
if(!empty($friends_shows_beta)) {
if($friends_shows_beta == "none") {
if(($owner->guid == get_loggedin_userid())){
$friends_show = true;	
}
}
if($friends_shows_beta == "all") {
$allowed = true; 
}elseif($friends_shows_beta == "friends"){
if(($owner->guid == get_loggedin_userid())){
$friends_show = true;	
}
elseif(user_is_friend($owner->guid, get_loggedin_userid())){
$friends_show = true;
}
}
}else{
$friends_show = true;
}
if($friends_show) {
echo "<div class='widget_title'>" .elgg_echo('megaprofile:profile:friends').  "</div>";
echo "<div class='sidebarBox'>";
echo list_entities_from_relationship('friend',  $owner->guid, FALSE, 'user', '', 0, 20, FALSE,FALSE,FALSE);
echo "<div class='clearfloat'></div>";
echo "</div>";
}	
?>

<?php
//PAGES
if(is_plugin_enabled('pages'))
{ 
$paginas_show = false;
$paginas_shows_beta = get_plugin_usersetting("paginas_shows_beta", $owner->guid, "megaprofile");
if(!empty($paginas_shows_beta)) {
if($paginas_shows_beta == "none") {
if(($owner->guid == get_loggedin_userid())){
$paginas_show = true;	
}
}
if($paginas_shows_beta == "all") {
$paginas_show = true; 
}elseif($paginas_shows_beta == "friends"){
if(($owner->guid == get_loggedin_userid())){
$paginas_show = true;	
}
elseif(user_is_friend($owner->guid, get_loggedin_userid())){
$paginas_show = true;
}
}
}else{
$paginas_show = true;
}
if($paginas_show) {
echo "<div class='widget_title'>" .elgg_echo('megaprofile:profile:pages').  "</div>";
echo "<div class='sidebarBox'>";
echo elgg_list_entities(array('types' => 'object', 'subtypes' => 'page_top', 'container_guid' => $owner->guid, 'limit' => 4, 'full_view' => FALSE, 'pagination' => FALSE)); 
echo "<div class='clearfloat'></div>";
echo "</div>";
}
}
?>

<?php
}
?>

</div>

</td>
<td>

<div id="plusriver_sidebar_main"  style="padding-left:5px; border-left:1px solid #d2d2d2;width:500px;">

<?php
//STATUS
$estado_show = false;
$estado_shows_beta = get_plugin_usersetting("estado_shows_beta", $owner->guid, "megaprofile");
if(!empty($estado_shows_beta)) {
if($estado_shows_beta == "none") {
if(($owner->guid == get_loggedin_userid())){
$estado_show = true;	
}
}
if($estado_shows_beta == "all") {
$estado_show = true; 
}elseif($estado_shows_beta == "friends"){
if(($owner->guid == get_loggedin_userid())){
$estado_show = true;	
}
elseif(user_is_friend($owner->guid, get_loggedin_userid())){				
$estado_show = true;					
}				
}		
}else{
$estado_show = true;
}	
if($estado_show) {
$latest_wire = get_entities("object", "thewire", $owner->guid, "", 1, 0, false, 0, null); 
if($latest_wire){
foreach($latest_wire as $lw){
$desc = "<div  style='font-size:15px;'>". $lw->description . "</div>";
$time = "<span>(" . friendly_time($lw->time_created) . ")</span>";
}
}
$wire_user = get_input('wire_username');
if (!empty($wire_user)) { $msg = '@' . $wire_user . ' '; } else { $msg = ''; }
echo elgg_view("output/longtext",array("value" => parse_urls($desc)));
}	
?>

<?php
//PHOTO
if(is_plugin_enabled('tidypics'))
{ 
$fotos_show = false;
$fotos_shows_beta = get_plugin_usersetting("fotos_shows_beta", $owner->guid, "megaprofile");
if(!empty($fotos_shows_beta)) {
if($fotos_shows_beta == "none") {
if(($owner->guid == get_loggedin_userid())){
$fotos_show = true;	
}			
}
if($fotos_shows_beta == "all") {
$fotos_show = true; 
}elseif($fotos_shows_beta == "friends"){
if(($owner->guid == get_loggedin_userid())){
$fotos_show = true;	
}
elseif(user_is_friend($owner->guid, get_loggedin_userid())){					
$fotos_show = true;					
}				
}			
}else{
$fotos_show = true;
}	
if($fotos_show) {	
echo tp_get_latest_photos(4, $owner->guid);	
}
}
?>

<?php
//THEWIRE
if(is_plugin_enabled('thewire'))
{ 
$wire_show = false;
$wire_shows_beta = get_plugin_usersetting("wire_shows_beta", $owner->guid, "megaprofile");
if(!empty($wire_shows_beta)) {
if($wire_shows_beta == "none") {
if(($owner->guid == get_loggedin_userid())){
$wire_show = true;	
}
}
if($wire_shows_beta == "all") {
$wire_show = true; 
} elseif($wire_shows_beta == "friends"){
if(($owner->guid == get_loggedin_userid())){
$wire_show = true;	
}
elseif(user_is_friend($owner->guid, get_loggedin_userid())){
$wire_show = true;
}
}
}else{
$wire_show = true;
}
if($wire_show) {
echo "<div class='widget_title'>" .elgg_echo('megaprofile:profile:wall').  "</div>";
echo "<div class='sidebarBox'>";
echo elgg_view_river_items($owner->guid, 0, $content_type, $content[0], $content[1], '', 15, 0, 0, FALSE,FALSE,FALSE);
echo "<div class='clearfloat'></div>";
echo "</div>";
}
}
?>

</div>
</td>
<td>

<div style="float:right; width:230px;  padding-left:5px;">

<?php
//VIDEO, VIDEOLIST PLUGIN 
if(is_plugin_enabled('videolist'))
{ 
$videos_show = false;
$videos_shows_beta = get_plugin_usersetting("videos_shows_beta", $owner->guid, "megaprofile");
if(!empty($videos_shows_beta)) {
if($videos_shows_beta == "none") {
if(($owner->guid == get_loggedin_userid())){
$videos_show = true;	
}
}
if($videos_shows_beta == "all") {
$videos_show = true; 
}elseif($videos_shows_beta == "friends"){
if(($owner->guid == get_loggedin_userid())){
$videos_show = true;	
}elseif(user_is_friend($owner->guid, get_loggedin_userid())){
$videos_show = true;
}
}
}else{
$videos_show = true;
}
if($videos_show) {
echo "<div class='widget_title'>" .elgg_echo('megaprofile:profile:video').  "</div>";
echo "<div class='sidebarBox'>";
echo elgg_list_entities(array('types' => 'object', 'subtypes' => 'videolist', 'container_guid' => $owner->guid, 'limit' => 5, 'full_view' => FALSE, 'pagination' => FALSE));
echo "<div class='clearfloat'></div>";
echo "</div>";
}
}
?>

<?php
//BLOG
if(is_plugin_enabled('blog')){ 
$blog_show = false;
$blog_shows_beta = get_plugin_usersetting("blog_shows_beta", $owner->guid, "megaprofile");
if(!empty($blog_shows_beta)) {
if($blog_shows_beta == "none") {
if(($owner->guid == get_loggedin_userid())){
$blog_show = true;	
}
}
if($blog_shows_beta == "all") {
$blog_show = true; 
}elseif($fotos_shows_beta == "friends"){
if(($owner->guid == get_loggedin_userid())){
$blog_show = true;	
}elseif(user_is_friend($owner->guid, get_loggedin_userid())){
$blog_show = true;
}
}
}else{
$blog_show = true;
}
if($blog_show) {
echo "<div class='widget_title'>" .elgg_echo('megaprofile:profile:blog').  "</div>";
echo "<div class='sidebarBox'>";
$context = get_context();
set_context('search');
echo elgg_list_entities(array('types' => 'object', 'subtypes' => 'blog', 'container_guid' => $owner->guid, 'limit' => 5, 'full_view' => FALSE, 'pagination' => FALSE));
echo "<div class='clearfloat'></div>";
echo "</div>";
}
}
?>

<?php
//BOOKMARKS
if(is_plugin_enabled('bookmarks')){ 
$allowed = false;
$marcadores_shows_beta = get_plugin_usersetting("marcadores_shows_beta", $owner->guid, "megaprofile");
if(!empty($marcadores_shows_beta)) {
if($marcadores_shows_beta == "none") {
if(($owner->guid == get_loggedin_userid())){
$allowed = true;	
}
}
if($marcadores_shows_beta == "all") {
$allowed = true; 
}elseif($marcadores_shows_beta == "friends"){
if(($owner->guid == get_loggedin_userid())){
$allowed = true;	
}
elseif(user_is_friend($owner->guid, get_loggedin_userid())){
$allowed = true;
}
}
}else{
$allowed = true;
}
if($allowed) {
echo "<div class='widget_title'>" .elgg_echo('megaprofile:profile:bookmarks').  "</div>";
echo "<div class='sidebarBox'>";
echo elgg_list_entities(array('types' => 'object', 'subtypes' => 'bookmarks', 'container_guid' => $owner->guid, 'limit' => 5, 'full_view' => FALSE, 'pagination' => FALSE));
echo "<div class='clearfloat'></div>";
echo "</div>";
}
}
?>

<?php
if(is_plugin_enabled('groups')){ 
?>

<?php
//GROUPS
$number = (int) $vars['entity']->num_display;
if (!$number) {
$number = 4;
}
if ($owner === false || is_null($owner)) {
set_page_owner($page_owner->getGUID());
}
$groups = elgg_get_entities(array('types' => 'group', 'container_guid' => $owner->guid, 'limit' => $number, 'offset' =>  0));
?>

<?php
$allowed = false;
$grupos_shows_beta = get_plugin_usersetting("grupos_shows_beta", $owner->guid, "megaprofile");
if(!empty($grupos_shows_beta)) {
if($grupos_shows_beta == "none") {
if(($owner->guid == get_loggedin_userid())){
$allowed = true;	
}
}
if($grupos_shows_beta == "all") {
$allowed = true; 
}elseif($grupos_shows_beta == "friends"){
if(($owner->guid == get_loggedin_userid())){
$allowed = true;	
}elseif(user_is_friend($owner->guid, get_loggedin_userid())){
$allowed = true;
}
}
}else{
$allowed = true;
}
if($allowed) {
echo "<div class='widget_title'>" .elgg_echo('megaprofile:profile:groups').  "</div>";
echo "<div class='sidebarBox'>";
if ($groups) {
foreach ($groups as $group) {
$icon = elgg_view(
"groups/icon", array(
'entity' => $group,
'size' => 'small',
)
);
$group_link = $group->getURL();
echo <<<___END
<div class="plusriver_groups_icon">		
$icon
</div>
<div class="plusriver_groups_info">
<span><a href="$group_link">$group->name</a></span><br />
$group->briefdescription
<br>
</div>
<div class="clearfloat"></div>
___END;
}	
}
echo "</div>"; 
echo "</div>";	
echo "<div class='clearfloat'></div>";
echo "</div>";		
}
?>

<?php
}
?>

<?php
}
?>
</div>
</td>
</tr>
</tbody>
</table>