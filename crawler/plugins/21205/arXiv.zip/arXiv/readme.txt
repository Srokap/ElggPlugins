 Licence: GNU General Public License (GPL) version 2

* Elgg arXiv Recent Eprints Widget
*
* @package arxiv
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author Matthew Saul Leifer
* @link http://mattleifer.info/code/elgg-arxiv

-----

This is a widget for displaying the results of an arXiv search on your profile or dashboard.  Example uses would include displaying a list of your recent eprints on your profile, or a search for terms you are interested in on your dashboard.

INSTALLATION
------------

Place the arxiv folder into the mod directory and enable it from your
administration panel.

RELEASE NOTES
-------------

arXiv Recent Eprints Widget 0.1
- First release