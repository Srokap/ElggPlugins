<?php
	/**
	 * Elgg groups plugin
	 * 
	 * @package ElggGroups
	 */
	 
	// If there are any topics to view, view them
		echo $vars['topics'];
?>