<?php

	$english = array(
			
		'members:members' => "Members",
	    'members:online' => "Users active now",
	    'members:active' => "site users",
	    'members:searchtag' => "User search via tag",
	    'members:searchname' => "User search via name",
	   
		'members:label:newest' => 'Newest',
		'members:label:popular' => 'Popular',
		'members:label:active' => 'Active',
		'members:search:name' => 'Users name',
		'members:search:tags' => 'Tags',
		
	);
					
	add_translation("en",$english);

?>