<?php
/**
 * Translation manager CSS
 *
 * License: GNU Public License version 2
 *          http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * Author:  Patrick Lai
 * Copyright 2010 Patrick Lai
 */
?>
#xlatmgr-submenu .plugin-select .status-online {
	color: black;
}
#xlatmgr-submenu .plugin-select .status-offline {
	color: black;
	font-style: italic;
}
#xlatmgr-submenu .plugin-select .status-unavailable {
	color: grey;
}
#xlatmgr-submenu .plugin-select .status-defunct {
	color: red;
}
#xlatmgr-submenu .language-select {
}
#xlatmgr-submenu .language-input {
	width: 30px;
	margin-right: 3px;
}
#xlatmgr-submenu div.submenu-separator {
	/*
	height: 3px;
	color: #cccccc;
	*/
	margin: 3px;
	border: 1px solid #cccccc;
}
#xlatmgr-submenu div.submenu-block {
	margin: 0px;
	padding: 0px;
	/*
	margin: 0px 0 10px 0;
	padding: 5px;
	-webkit-border-radius: 8px;
	-moz-border-radius: 8px;
	border: 1px solid #cccccc;
	*/
}
#xlatmgr-submenu div.submenu-block p.status-offline {
	color: red;
	font-weight: bold;
}
#xlatmgr-submenu div.submenu-block input[type="button"] {
	margin-left: 5px;
}
#xlatmgr-editor {
	margin-left: 5px;
}
#xlatmgr-editor input[type="submit"] {
	margin-left: 5px;
	margin-top: 2px;
}
#xlatmgr-editor input[type="button"] {
	margin-left: 5px;
	margin-top: 2px;
}
#xlatmgr-editor input[type="reset"] {
	margin-left: 5px;
}
#xlatmgr-editor input[type="text"] {
	margin-top: 1px;
	margin-bottom: 1px;
	width: 95%;
}
#xlatmgr-editor input[type="image"] {
	border: 0;
	padding: 2px;
}
#xlatmgr-editor textarea {
	margin-top: 1px;
	margin-bottom: 1px;
	width: 95%;
}
#xlatmgr-editor table {
	width: 98%;
}
#xlatmgr-editor th {
	font-weight: bold;
}
#xlatmgr-editor tr {
	padding-top: 0px;
	padding-bottom: 0px;
	padding-left: 10px;
	padding-right: 10px;
	/*
	vertical-align: center;
	border: 1px solid black;
	*/
}
#xlatmgr-editor td {
	padding: 0px;
	/*
	vertical-align: center;
	border: 1px solid black;
	*/
}
/*
#xlatmgr-editor td div.actions {
	width: 64px;
}
*/
#xlatmgr-editor div.scrollable {
	overflow: auto;
	height: 220px;
	border-top: 2px solid #cccccc;
	border-bottom: 2px solid #cccccc;
	padding-top: 4px;
	margin: 4px 0px 0px 0px;
}
#xlatmgr-editor div.key-new {
	color: blue;
}
#xlatmgr-editor div.key-stock {
	color: black;
	font-style: italic;
}
#xlatmgr-editor div.key-custom {
	color: black;
}
#xlatmgr-editor div.action-buttons {
	float: left;
	padding-top: 3px;
	padding-right: 5px;
}
#xlatmgr-editor div.commit-buttons {
	float: right;
	padding-top: 3px;
	padding-right: 5px;
}
<?php
// vim: set ai ts=4 noexpandtab syntax=php fdm=marker binary noeol:
?>