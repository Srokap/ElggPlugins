<?php
/**
 * Translation manager main page
 *
 * License: GNU Public License version 2
 *          http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * Author:  Patrick Lai
 * Copyright 2010 Patrick Lai
 */

$scratch = isset($vars['scratch']) ? $vars['scratch'] : null;
$callback = isset($vars['callback']) ? $vars['callback'] : false;
$singleline = $scratch ? $scratch->singleline : true;

$security_hdr = elgg_view('input/securitytoken');

$id_prefix_entry = 'xlatmgr-entry';
$id_prefix_key = 'xlatmgr-key';
$id_prefix_key_display = 'xlatmgr-key-display';
$id_prefix_value = 'xlatmgr-val';

$delete_label = elgg_echo('xlatmgr:delete');
$restore_label = elgg_echo('xlatmgr:restore');
$multi_label = elgg_echo('xlatmgr:multi-line');
$delete_icon = $vars['url'].'mod/xlatmgr/graphics/icons/delete.png';
$restore_icon = $vars['url'].'mod/xlatmgr/graphics/icons/restore.png';
$multi_icon = $vars['url'].'mod/xlatmgr/graphics/icons/text.png';

if (!$callback) {
$value_sentinel = '@@@VALUE@@@';
$index_sentinel = '@@@INDEX@@@';
$delete_help = elgg_echo('xlatmgr:help:delete-entry');
$restore_help_tmpl =
	htmlspecialchars(
		sprintf( elgg_echo('xlatmgr:help:restore'), $value_sentinel));
$multi_help = elgg_echo('xlatmgr:help:multi-line');
$template_value_single =
	elgg_view(
		'input/text',
		array(
			'internalname'=>"val$index_sentinel",
			'internalid'=>"$id_prefix_value$index_sentinel",
			'value'=>$value_sentinel,
			'js'=>
			"onchange=\"xlatmgr_editor_value_changed($index_sentinel,this);\"",
		)
	);
$template_value_multi =
	'<textarea rows="1"'
	. " name=\"val$index_sentinel\""
	. " id=\"$id_prefix_value$index_sentinel\""
	. " onblur=\"xlatmgr_editor_value_check($index_sentinel,this);\">"
	. "\n"	// HACK: first empty line of text area is ignored
	. $value_sentinel
	. '</textarea>'
	;
$template_key =
	elgg_view(
		'input/hidden',
		array(
			'internalname'=>"key$index_sentinel",
			'internalid'=>"$id_prefix_key$index_sentinel",
			'value'=>$value_sentinel,
		)
	);
$template_delete =<<<EOF
<input type="image"
	name="del_entry$index_sentinel"
	value="$delete_label"
	title="$delete_help"
	alt="$delete_label"
	src="$delete_icon"
	onclick="xlatmgr_editor_del_entry($index_sentinel,this);"
/>
EOF;
$template_restore =<<<EOF
<input type="image"
	name="restore$index_sentinel"
	value="$restore_label"
	title="$restore_help_tmpl"
	alt="$restore_label"
	src="$restore_icon"
	onclick="xlatmgr_editor_restore($index_sentinel,this);"
/>
EOF;
$template_multi =<<<EOF
<input type="image"
	name="multi$index_sentinel"
	value="$multi_label"
	title="$multi_help"
	alt="$multi_label"
	src="$multi_icon"
	onclick="xlatmgr_editor_multi_line($index_sentinel,this);"
/>
EOF;
?>
<script type="text/javascript">
	function xlatmgr_html_esc(s) {
		if (s == null)
			return s;

		return s
			.replace(/&/gm, '&amp;')
			.replace(/</gm, '&lt;')
			.replace(/>/gm, '&gt;')
			.replace(/"/gm, '&quot;')
			;
	}
	function xlatmgr_editor_append_entry(index, key, val) {
		var html = xlatmgr_editor_make_entry(index, key, val);
		$("#xlatmgr-mapping tbody").append(html);

		XLATMGR_CURR.keys[key] = true;
		return true;
	}
	function xlatmgr_editor_key_new(key) {
		return typeof(XLATMGR_CURR.stock[key]) == 'undefined';
	}
	function xlatmgr_editor_same_value(v1, v2) {
		if (v1 == v2)
			return true;

		if (v1.search(/[\n\r]/) < 0)
			return false;

		// handle line separator differences
		//
		v1 = v1.replace(/\r\n/g, "\n");
		v2 = v2.replace(/\r\n/g, "\n");
		if (v1 == v2)
			return true;

		v1 = v1.replace(/\r/g, "\n");
		v2 = v2.replace(/\r/g, "\n");
		if (v1 == v2)
			return true;

		return false;
	}
	function xlatmgr_editor_key_status(key, val) {
		if (xlatmgr_editor_key_new(key))
			return 'new';
		if (xlatmgr_editor_same_value(XLATMGR_CURR.stock[key], val))
			return 'stock';
		return 'custom';
	}
	function xlatmgr_editor_key_display_class(key, val) {
		var sts = xlatmgr_editor_key_status(key, val);
		return 'key-' + sts;
	}
	function xlatmgr_editor_value_abbrev(val) {
		var MAX = 15;
		if (val.length > MAX)
			val = val.substring(0,MAX) + '...';
		return val;
	}
	function xlatmgr_editor_make_entry(index, key, val) {
		if (key == '')
			return false;

		var multi_line =
		<?php if ($singleline) { ?>
			(val != null && val.search(/[\n\r]/) >= 0)
		<?php } else { ?>
			true
		<?php } ?>
			;
		var template_value = multi_line
			? <?=json_encode($template_value_multi)?>
			: <?=json_encode($template_value_single)?>
			;

		var template_key = <?=json_encode($template_key)?>;
		var template_delete = <?=json_encode($template_delete)?>;
		var template_restore = <?=json_encode($template_restore)?>;
		var template_multi = <?=json_encode($template_multi)?>;

		var new_id = '<?=$id_prefix_entry?>'+index;

		var key_input = template_key
				.replace(/<?=$index_sentinel?>/gm, index)
				.replace(/<?=$value_sentinel?>/gm, xlatmgr_html_esc(key))
				;
		var val_input = template_value
				.replace(/<?=$index_sentinel?>/gm, index)
				.replace(/<?=$value_sentinel?>/gm, xlatmgr_html_esc(val))
				;
		var del_button = template_delete
				.replace(/<?=$index_sentinel?>/gm, index)
				;
		var mul_button = multi_line
			? ''
			: template_multi.replace(/<?=$index_sentinel?>/gm, index)
			;
		var rst_button = xlatmgr_editor_key_new(key)
			? ''
			: template_restore
				.replace(/<?=$index_sentinel?>/gm, index)
				.replace(/<?=$value_sentinel?>/gm,
							xlatmgr_html_esc(
								xlatmgr_editor_value_abbrev(
									XLATMGR_CURR.stock[key])))
			;

		var key_attrs = 'id="<?=$id_prefix_key_display?>' + index + '"'
				+ ' class="'+ xlatmgr_editor_key_display_class(key, val) +'"';

		return '<tr id="' + new_id + '">'
		+	'<td>'
			+ '<div class="actions">'+del_button+rst_button+mul_button+'</div>'
			+ '</td>'
		+	'<td>'
			+ '<div '+key_attrs+'">' + xlatmgr_html_esc(key) + '</div>'
			+ key_input
			+ '</td>'
		+	'<td>'+val_input+'</td>'
		+	'</tr>'
		;
	}
	function xlatmgr_editor_add_entry(form) {
		var new_key = form.elements['new_key'];
		var new_val = form.elements['new_val'];

		var key = new_key.value;
		var val = new_val.value;

		if (XLATMGR_CURR.keys[key]) {
			alert('<?=elgg_echo('xlatmgr:dup:key')?>');
			return false;
		}

		var keycount = form.elements['keycount'];
		var index = +(keycount.value);

		if (!xlatmgr_editor_append_entry(index, key, val))
			return false;
		keycount.value = index + 1;

		new_val.value = new_key.value = '';
		return xlatmgr_editor_mark_dirty(form);
	}
	function xlatmgr_editor_del_entry(index, input) {
		var form = input.form;

		var key = $('#<?=$id_prefix_key?>'+index).val();
		XLATMGR_CURR.keys[key] = false;

		$('#<?=$id_prefix_entry?>'+index).empty().remove();
		return xlatmgr_editor_mark_dirty(form);
	}
	function xlatmgr_editor_mark_dirty(form) {
		form.elements['dirty'].value = '1';
		return true;
	}
	function xlatmgr_editor_multi_line(index, button) {
		var val = $('#<?=$id_prefix_value?>' + index);
		var row = val.parent();

		var new_input = <?=json_encode($template_value_multi)?>
				.replace(/<?=$index_sentinel?>/gm, index)
				.replace(/<?=$value_sentinel?>/gm, xlatmgr_html_esc(val.val()))
				;
		val.empty().remove();
		row.append(new_input);

		$(button).empty().remove();
		return false;
	}
	function xlatmgr_editor_restore(index, button) {
		var key = $('#<?=$id_prefix_key?>' + index).val();
		if (xlatmgr_editor_key_new(key))
			return false;

		var orig = XLATMGR_CURR.stock[key];

		var input = $('#<?=$id_prefix_value?>' + index).get(0);
		if (xlatmgr_editor_same_value(input.value, orig))
			return false;

		input.value = orig;
		return xlatmgr_editor_value_changed(index, input);
	}
	function xlatmgr_editor_value_check(index, input) {
		var form = input.form;

		var key = $('#<?=$id_prefix_key?>' + index).val();
		if (typeof(XLATMGR_CURR.orig[key]) == 'undefined')
			return xlatmgr_editor_value_changed(index, input);

		if (xlatmgr_editor_same_value(input.value, XLATMGR_CURR.orig[key]))
			return false;

		return xlatmgr_editor_value_changed(index, input);
	}
	function xlatmgr_editor_value_changed(index, input) {
		var form = input.form;

		var key = $('#<?=$id_prefix_key?>' + index).val();
		var cls = xlatmgr_editor_key_display_class(key, input.value);
		$('#<?=$id_prefix_key_display?>' + index).attr('class', cls);

		return xlatmgr_editor_mark_dirty(form);
	}
	function xlatmgr_editor_clear_dirty(form) {
		form.elements['dirty'].value = '0';
		return true;
	}
	function xlatmgr_editor_reset(form) {
		if (!xlatmgr_editor_confirm_discard())
			return false;
		return xlatmgr_editor_action(form, 'reset');
	}
	function xlatmgr_editor_update(submit) {
		var form = submit.form;
		form.elements['persist'].value = '1';
		return xlatmgr_editor_action(form, 'update');
	}
	function xlatmgr_editor_action(form, action) {
		form.action = "<?=$vars['url'].'pg/xlatmgr'?>";
		form.elements['cmd'].value = action;
		form.submit();
		return false;
	}
	function xlatmgr_editor_confirm_discard() {
		var dirty = $("#xlatmgr-dirty").val();
		if (dirty == '0' || !dirty)
			return true;
		return confirm("<?=elgg_echo('xlatmgr:confirm:discard')?>");
	}
</script>
<div id="xlatmgr-editor">
<?php
}
if (!empty($scratch)) {
$stock = xlatmgr_get_plugin_translation($scratch->plug, $scratch->lang);
if (!is_array($stock))
	$stock = array();
?>
<script type="text/javascript">
	if (typeof(XLATMGR_CURR) == 'undefined') {
		var XLATMGR_CURR = {};
	}
	XLATMGR_CURR.stock = <?=json_encode($stock)?>;
	XLATMGR_CURR.orig = <?=json_encode($scratch->mapping)?>;
	XLATMGR_CURR.keys = {};
</script>
<form action="javascript:void(0);" method="POST">
	<?=$security_hdr?>
	<?php
	echo elgg_view('input/hidden', array('internalname'=>'cmd'));
	echo elgg_view('input/hidden', array('internalname'=>'persist'));
	echo elgg_view(	
			'input/hidden',
			array(
				'internalid'=>'xlatmgr-dirty',
				'internalname'=>'dirty',
				'value'=>($scratch->dirty ? '1' : '0'),
			)
		);
	/*
	echo elgg_view(	
			'input/hidden',
			array('internalname'=>'plug', 'value'=>$scratch->plug));
	echo elgg_view(	
			'input/hidden',
			array('internalname'=>'lang', 'value'=>$scratch->lang));
	*/
	?>
	<table>
	<thead>
	<tr>
		<th><?=elgg_echo('xlatmgr:header:key')?></th>
		<th><?=elgg_echo('xlatmgr:header:text')?></th>
		<th></th>
	</tr>
	<tr>
		<td style="width:40%;">
			<?=elgg_view('input/text', array('internalname'=>'new_key'))?>
		</td>
		<td style="width:40%;">
			<textarea rows="2" name="new_val"></textarea>
		</td>
		<td style="width:15%;">
			<?php
			echo elgg_view(	
					'input/button',
					array(
						'internalname'=>'add_entry',
						'value'=>elgg_echo('xlatmgr:add'),
						'type'=>'button',
						'js'=>'onclick="xlatmgr_editor_add_entry(this.form);"',
					)
				);
			?>
		</td>
	</tr>
	</thead>
	</table>
	<div class="scrollable">
	<table id="xlatmgr-mapping">
	<tbody>
	</tbody>
	</table>
	</div>
	<script type="text/javascript">
		$(document).ready(function() {
		<?php
		$keycount = 0;
		foreach ($scratch->mapping as $key => $val) {
			$key = json_encode($key);
			$val = json_encode($val);
			?>
			xlatmgr_editor_append_entry(<?=$keycount?>, <?=$key?>, <?=$val?>);
			<?php
			++$keycount;
		}
		?>
		});
	</script>
	<?=
		elgg_view(	
			'input/hidden',
			array(
				'internalname'=>'keycount',
				'value'=>$keycount,
			)
		)
	?>
	<div class="commit-buttons">
	<?=
		elgg_view(	
			'input/submit',
			array(
				'internalname'=>'reset',
				'value'=>elgg_echo('xlatmgr:reset'),
				'js'=>'onclick="xlatmgr_editor_reset(this.form);"',
			)
		)
	?>
	<?=
		elgg_view(	
			'input/submit',
			array(
				'internalname'=>'save',
				'value'=>elgg_echo('xlatmgr:save'),
				'js'=>'onclick="xlatmgr_editor_update(this);"',
			)
		)
	?>
	</div>
	<div class="action-buttons">
	<?=
		elgg_view(	
			'input/submit',
			array(
				'internalname'=>'sync',
				'value'=>elgg_echo('xlatmgr:sync'),
				'js'=>'onclick="xlatmgr_editor_action(this.form, \'sync\');"',
			)
		)
	?>
	<?=
		elgg_view(	
			'input/submit',
			array(
				'internalname'=>'compact',
				'value'=>elgg_echo('xlatmgr:compact'),
				'js'=>'onclick="xlatmgr_editor_action(this.form,\'compact\');"',
			)
		)
	?>
	</div>
</form>
<?php
}
if (!$callback) {
?>
</div>
<?
}

// vim: set ai ts=4 noexpandtab syntax=php fdm=marker binary noeol:
?>