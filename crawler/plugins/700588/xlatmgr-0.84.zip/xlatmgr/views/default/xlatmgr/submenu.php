<?php
/**
 * Translation manager submenu
 *
 * License: GNU Public License version 2
 *          http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * Author:  Patrick Lai
 * Copyright 2010 Patrick Lai
 */

$curr_plug = isset($vars['plug']) ? $vars['plug'] : '';
$curr_lang = isset($vars['lang']) ? $vars['lang'] : '';
$call_back = isset($vars['callback']) ? $vars['callback'] : false;

$details = new stdClass;
$plugins = xlatmgr_get_plugins_with_status($details);
if (!empty($plugins))
	ksort($plugins);
else if (!is_array($plugins))
	$plugins = array();

$managed = new stdClass;
if (isset($details->managed)) {
	foreach ($details->managed as $plug)
		$managed->$plug = true;
}

$security_hdr = elgg_view('input/securitytoken');

if (!$call_back) {
	?>
	<script type="text/javascript">
		function xlatmgr_plug_changed(sel, orig) {
			var form = sel.form;
			var restore = false;

			if (!restore && !xlatmgr_editor_confirm_discard())
				restore = true;
			if (!restore) {
				var plug = sel.options[sel.selectedIndex].value;
				if (XLATMGR_CURR.plugins[plug] == 'unavailable')
					if (confirm("<?=elgg_echo('xlatmgr:confirm:plug_add')?>"))
						form.elements['create'].value = 1;
					else
						restore = true;
			}

			if (restore) {
				var i;
				for (i = 0; i < sel.length; ++i)
					if (sel.options[i].value == orig) {
						sel.selectedIndex = i;
						break;
					}
				return false;
			}

			form.submit();
			return false;
		}
		function xlatmgr_lang_changed(sel, orig) {
			if (!xlatmgr_editor_confirm_discard()) {
				var i;
				for (i = 0; i < sel.length; ++i)
					if (sel.options[i].value == orig) {
						sel.selectedIndex = i;
						break;
					}
				return false;
			}

			var form = sel.form;
			form.submit();

			return false;
		}
		function xlatmgr_add_plug(form) {
			if (!confirm("<?=elgg_echo('xlatmgr:confirm:plug_add')?>"))
				return false;

			form.elements['create'].value = 1;
			form.submit();
			return false;
		}
		function xlatmgr_del_plug(form) {
			if (!confirm("<?=elgg_echo('xlatmgr:confirm:plug_del')?>"))
				return false;

			form.action = "<?=$vars['url'].'action/xlatmgr/plug/del'?>";
			form.submit();
			return false;
		}
		function xlatmgr_toggle_plug(form, flag) {
			var op = flag ? 'plug.activate' : 'plug.deactivate';
			var url = "<?=$vars['url'].'action/xlatmgr/ajax'?>"
					+ '?func=' + op
					+ '&__elgg_ts=' + form.elements['__elgg_ts'].value
					+ '&__elgg_token=' + form.elements['__elgg_token'].value
					;
			$("#xlatmgr-submenu").load(url);
			return false;
		}
		function xlatmgr_add_lang(form, name) {
			if (!xlatmgr_editor_confirm_discard())
				return false;

			// TODO: check for valid language code
			//
			var text = form.elements[name];
			var lang = text.value;

			var lang_sel = $('#xlatmgr-submenu select[name="lang"]').get(0);
			var i;
			for (i = 0; i < lang_sel.length; ++i)
				if (lang_sel.options[i].value == lang) {
					alert('<?=elgg_echo('xlatmgr:dup:lang')?>');
					return false;
				}

			form.action = "<?=$vars['url'].'action/xlatmgr/lang/add'?>";
			form.submit();
			return false;
		}
		function xlatmgr_del_lang(form) {
			if (!confirm("<?=elgg_echo('xlatmgr:confirm:lang_del')?>"))
				return false;

			form.action = "<?=$vars['url'].'action/xlatmgr/lang/del'?>";
			form.submit();
			return false;
		}
	</script>

	<div id="xlatmgr-submenu">
	<?php
}
?>
<script type="text/javascript">
	if (typeof(XLATMGR_CURR) == 'undefined') {
		var XLATMGR_CURR = {};
	}
	XLATMGR_CURR.plugins = <?=json_encode($plugins)?>;
	XLATMGR_CURR.managed = <?=json_encode($managed)?>;
</script>
<form action="<?=$vars['url'].'pg/xlatmgr'?>" method="POST">
	<?=$security_hdr?>
	<?=
	elgg_view('input/hidden', array('internalname'=>'create','value'=>'0'))
	?>
	<!-- ================================================================ -->
	<div class="submenu-block">
	<label><?=elgg_echo('xlatmgr:plugin.label')?></label>
	<br>
	<select name="plug" class="input-pulldown plugin-select"
			onchange="xlatmgr_plug_changed(this, '<?=htmlspecialchars($curr_plug, ENT_QUOTES)?>');">
	<?php
	foreach ($plugins as $plug => $sts) {
		$attrs = 'class="status-' . $sts . '"';
		if ($plug == $curr_plug)
			$attrs .= ' selected="selected"';
		/*
		if ($sts == XLATMGR_PLUGIN_STATUS_DEFUNCT)
			$attrs .= ' disabled="disabled"';
		*/

		$value = htmlentities($plug, ENT_QUOTES, 'UTF-8');
		$name = htmlspecialchars(xlatmgr_get_plugin_name($plug));
		?><option value="<?=$value?>" <?=$attrs?>><?=$name?></option><?
	}
	?>
	</select>
	<?php
	if (array_search($curr_plug, $details->available) === false)
		echo elgg_view(	
				'input/button',
				array(
					'internalname'=>'plug_add',
					'type'=>'button',
					'value'=>elgg_echo('xlatmgr:add'),
					'js'=>'onclick="xlatmgr_add_plug(this.form);"',
				)
			);
	else {
		echo elgg_view(	
				'input/button',
				array(
					'internalname'=>'plug_del',
					'type'=>'button',
					'value'=>elgg_echo('xlatmgr:delete'),
					'js'=>'onclick="xlatmgr_del_plug(this.form);"',
				)
			);

		if ($plugins[$curr_plug] == XLATMGR_PLUGIN_STATUS_ONLINE)
			echo elgg_view(	
					'input/button',
					array(
						'internalname'=>'plug_off',
						'type'=>'button',
						'value'=>elgg_echo('xlatmgr:deactivate'),
						'js'=>'onclick="xlatmgr_toggle_plug(this.form,false);"',
					)
				);
		else if (array_search($curr_plug, $details->disabled) === false
				&& array_search($curr_plug, $details->known) !== false)
			echo elgg_view(	
					'input/button',
					array(
						'internalname'=>'plug_on',
						'type'=>'button',
						'value'=>elgg_echo('xlatmgr:activate'),
						'js'=>'onclick="xlatmgr_toggle_plug(this.form, true);"',
					)
				);
	}

	?>
	</div>
	<div class="submenu-separator"></div>
	<!-- ================================================================ -->
	<div class="submenu-block">
	<label><?=elgg_echo('xlatmgr:language.label')?></label>
	<br>
	<select name="lang" class="input-pulldown language-select"
			onchange="xlatmgr_lang_changed(this, '<?=htmlspecialchars($curr_lang, ENT_QUOTES)?>');">
	<?php
	$languages = xlatmgr_get_languages($curr_plug);
	if (empty($languages) && !is_array($languages))
		$languages = array();

	foreach ($languages as $lang) {
		$attrs = '';
		if ($lang == $curr_lang)
			$attrs .= ' selected="selected"';
		?><option <?=$attrs?>><?=htmlspecialchars($lang)?></option><?
	}
	?>
	</select>
	<?php
	if (!empty($curr_lang)) {
		echo elgg_view(	
				'input/button',
				array(
					'internalname'=>'lang_del',
					'type'=>'button',
					'value'=>elgg_echo('xlatmgr:delete'),
					'js'=>'onclick="xlatmgr_del_lang(this.form);"',
				)
			);
	}
	?>
	<br>
	<?php
	echo elgg_view(
			'input/text',
			array(
				'internalname'=>'new_lang',
				'class'=>'language-input',
			)
		);
	echo elgg_view(	
			'input/button',
			array(
				'internalname'=>'lang_add',
				'type'=>'button',
				'value'=>elgg_echo('xlatmgr:add'),
				'js'=>'onclick="xlatmgr_add_lang(this.form, \'new_lang\');"',
			)
		);
	?>
	</div>
	<div class="submenu-separator"></div>
	<!-- ================================================================ -->
	<div class="submenu-block">
	<p class="status-<?=$plugins[$curr_plug]?>">
		<?=elgg_echo('xlatmgr:status.label')?>:
		<?=elgg_echo("xlatmgr:status:{$plugins[$curr_plug]}")?>
	</p>
	</div>
</form>
<?php
if (!$call_back) {
	?></div><?php
}

// vim: set ai ts=4 noexpandtab syntax=php fdm=marker binary noeol:
?>