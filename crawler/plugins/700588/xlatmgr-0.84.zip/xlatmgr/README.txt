XLATMGR - Elgg custom translation plugin

   Author: Patrick Lai <2010.PLai@gmail.com>
Copyright: Copyright 2010,2011 Patrick Lai
  License: GNU Public License version 2
 Donation: US$5 suggested, via PayPal to 2010.PLai@gmail.com

This plugin can be used to manage custom text translations of plugins and
even Elgg itself.  It is written for Elgg 1.7.0 and has been tested against
Firefox 3.6.

Language localization in Elgg is achieved by PHP scripts that add text
translations.  By convention these scripts are under "languages" directories,
and named with country codes.  So for example, Japanese text for the blog
plugin would be in mod/blog/languages/ja.php.

This approach works fine, except that any translation related customization
would require manual script changes.  The "languages" scripts can become
difficult to maintain when a site gets updated with new versions of plugins
or Elgg.  The solution here is to have a special plugin to manage all custom
translations.

This plugin adds a link to the admin submenu for the translation manager
page.  That page has two parts, a panel to specify plugin and language, and
an editor to define custom translation text for the selected plugin and
language.  Here are some details about the two.

- Panel
  - Select plugin for customization.
  - Select language for customization.
  - Customization may be deactivated.

- Editor
  - Input for new key and text.
  - List of custom key/text pairs.
    - Key in blue if it is not recognized (i.e. not in unmodified or stock
      translation).
    - Key in italic if the text is the same as the stock translation.
      (The "Compact" button would remove such keys.)
    - Delete button to remove a key/text pair.
    - Restore button to set text back to stock.
    - Multi-line button to allow multi-line text.
  - Sync button.
    - Pull stock translation text into the editor.  To start a new translation,
      for example, one would first do a sync, and then modify the text.  Sync
      would also be a useful tool for plugin upgrade -- do
      a sync and it should be obvious which keys are new and which are defunct.
  - Compact button.
    - Remove translations from the editor that are the same as stock.

=========================================================
To-Do/Wish List
- Polish UI (e.g. spinner when loading page).
- Verify with other Elgg verions.
- Verify with more browsers.
- Export, i.e. download consolidated translations as drop-in replacement
  of "languages" scripts.
- Sorting of translation keys.
- Option to hide disabled plugins.
- Search plugins for translation text.
- Non-admin role to manage translation.

=========================================================
Known Issues
- Page should be reloaded when a custom translation comes into or goes
  out of effect (e.g. through "activate"/"deactivate").
- Translation being edited is saved as a session variable.

# vim: set ai ts=2 expandtab:
