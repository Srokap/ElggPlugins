<?php
/**
 * Translation manager main page
 *
 * License: GNU Public License version 2
 *          http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * Author:  Patrick Lai
 * Copyright 2010 Patrick Lai
 */

admin_gatekeeper();

$creating = get_input('create', false);
$any_lang = $creating ? false : true;
$scratch = xlatmgr_get_scratch_pad($creating, $any_lang);
$plug = empty($scratch) ? '' : $scratch->plug;
$lang = empty($scratch) ? '' : $scratch->lang;

$page_title = elgg_echo('xlatmgr:manage_trans');
$area_title = sprintf(
				elgg_echo('xlatmgr:custom_tran'),
				xlatmgr_get_plugin_name($plug),
				$lang,
				xlatmgr_get_language_name($lang)
				);

$area1 = elgg_view('xlatmgr/submenu', array('plug'=>$plug, 'lang'=>$lang));
$area2 = elgg_view_title(htmlspecialchars($area_title))
		.elgg_view('xlatmgr/editor', array('scratch'=>$scratch))
		;

page_draw(
	$page_title,
	elgg_view_layout('two_column_left_sidebar', $area1, $area2)
);

// vim: set ai ts=4 noexpandtab syntax=php fdm=marker binary noeol:
?>