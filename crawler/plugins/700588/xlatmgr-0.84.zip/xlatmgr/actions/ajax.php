<?php
/**
 * Translation manager ajax handler
 *
 * License: GNU Public License version 2
 *          http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * Author:  Patrick Lai
 * Copyright 2010 Patrick Lai
 */

admin_gatekeeper();

$func = get_input('func');
$plug = get_input('plug');

switch ($func) {
case 'plug.activate':
	if (($scratch = xlatmgr_get_scratch_pad(false, true))
		&& xlatmgr_activate_plugin($scratch->plug)) {
		$scratch->status = xlatmgr_get_plugin_status($scratch->plug);
		echo elgg_view(
				'xlatmgr/submenu',
				array(
					'plug'=>$scratch->plug,
					'lang'=>$scratch->lang,
					'callback'=>true,
				)
			);
	}
	break;
case 'plug.deactivate':
	if (($scratch = xlatmgr_get_scratch_pad(false, true))
		&& xlatmgr_deactivate_plugin($scratch->plug)) {
		$scratch->status = xlatmgr_get_plugin_status($scratch->plug);
		echo elgg_view(
				'xlatmgr/submenu',
				array(
					'plug'=>$scratch->plug,
					'lang'=>$scratch->lang,
					'callback'=>true,
				)
			);
	}
	break;
default:
	error_log("xlatmgr: unknown ajax function <$func>");
	break;
}
exit;

// vim: set ai ts=4 noexpandtab syntax=php fdm=marker binary noeol:
?>