<?php
/**
 * Translation manager compact translation action
 *
 * License: GNU Public License version 2
 *          http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * Author:  Patrick Lai
 * Copyright 2010 Patrick Lai
 */

admin_gatekeeper();

$okay = false;
if ($scratch = xlatmgr_get_scratch_pad()) {
	$mapping = xlatmgr_receive_mapping();
	$vanilla = xlatmgr_get_plugin_translation($scratch->plug, $scratch->lang);

	if (is_array($mapping) && is_array($vanilla)) {
		foreach ($mapping as $key => $val) {
			if (isset($vanilla[$key])
				&& xlatmgr_same_text_value($vanilla[$key], $val)) {
				unset($mapping[$key]);
				$scratch->dirty = true;
			}
		}

		$scratch->mapping = $mapping;
		$okay = true;
	}
}

if ($okay)
	system_message(elgg_echo('xlatmgr:succ:compact'));
else
	register_error(elgg_echo('xlatmgr:fail:compact'));

if (!get_input('no-forward')) {
	forward('pg/xlatmgr');
	exit;
}

// vim: set ai ts=4 noexpandtab syntax=php fdm=marker binary noeol:
?>