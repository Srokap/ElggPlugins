<?php
/**
 * Translation manager delete language from custom translation
 *
 * License: GNU Public License version 2
 *          http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * Author:  Patrick Lai
 * Copyright 2010 Patrick Lai
 */

admin_gatekeeper();

global $CONFIG;
$xlatmgr = $CONFIG->xlatmgr;

$plug = get_input('plug');
$lang = get_input('lang');
if ($xlatmgr->deleteTranslation($plug, $lang)) {
	xlatmgr_reload_scratch_pad(false, true);
	system_message(elgg_echo('xlatmgr:succ:plug_del'));
}
else
	register_error(elgg_echo('xlatmgr:fail:plug_del'));

forward('pg/xlatmgr');
exit;

// vim: set ai ts=4 noexpandtab syntax=php fdm=marker binary noeol:
?>