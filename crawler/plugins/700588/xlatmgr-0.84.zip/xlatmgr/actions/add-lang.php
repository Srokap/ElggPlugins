<?php
/**
 * Translation manager add language action
 *
 * License: GNU Public License version 2
 *          http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * Author:  Patrick Lai
 * Copyright 2010 Patrick Lai
 */

admin_gatekeeper();

$new_lang = trim(get_input('new_lang', get_current_language()));
$plug = get_input('plug');

set_input('lang', $new_lang);
if (xlatmgr_get_scratch_pad(true))
	system_message(elgg_echo('xlatmgr:succ:lang_add'));
else
	register_error(elgg_echo('xlatmgr:fail:lang_add'));

forward('pg/xlatmgr');
exit;

// vim: set ai ts=4 noexpandtab syntax=php fdm=marker binary noeol:
?>