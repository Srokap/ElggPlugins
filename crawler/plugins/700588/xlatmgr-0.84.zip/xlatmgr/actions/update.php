<?php
/**
 * Translation manager add language action
 *
 * License: GNU Public License version 2
 *          http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * Author:  Patrick Lai
 * Copyright 2010 Patrick Lai
 */

admin_gatekeeper();

$persist = get_input('persist');
$dirty = (bool)get_input('dirty');

global $CONFIG;
$xlatmgr = $CONFIG->xlatmgr;

if ($scratch = xlatmgr_get_scratch_pad()) {
	$plug = $scratch->plug;
	$lang = $scratch->lang;
}

$mapping = xlatmgr_receive_mapping();
if ($scratch) {
	if (!$persist) {
		$scratch->dirty = $dirty;
		$scratch->mapping = $mapping;
	}
	else if ($xlatmgr->saveTranslation($plug, $lang, $mapping)) {
		system_message(elgg_echo('xlatmgr:succ:update'));
		xlatmgr_reload_scratch_pad();
	}
}
else
	register_error(elgg_echo('xlatmgr:fail:update'));

if (!get_input('no-forward')) {
	forward('pg/xlatmgr');
	exit;
}

// vim: set ai ts=4 noexpandtab syntax=php fdm=marker binary noeol:
?>