<?php
/**
 * Translation manager add language action
 *
 * License: GNU Public License version 2
 *          http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * Author:  Patrick Lai
 * Copyright 2010 Patrick Lai
 */

admin_gatekeeper();

xlatmgr_reload_scratch_pad();

if (!get_input('no-forward')) {
	forward('pg/xlatmgr');
	exit;
}

// vim: set ai ts=4 noexpandtab syntax=php fdm=marker binary noeol:
?>