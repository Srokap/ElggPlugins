<?php
/**
 * Translation manager plugin
 *
 * License: GNU Public License version 2
 *          http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * Author:  Patrick Lai
 * Copyright 2010,2011 Patrick Lai
 */

require_once(dirname(__FILE__) . '/models/xlatmgr.php');

//                            translations
//    status      plugin    managed defined
//    ----------- --------- ------- -------
//    online      enabled   Yes     Yes
//    unavailable enabled   Yes     No
//    offline     enabled   No      Yes
//    unavailable enabled   No      No
//    offline     disabled  Yes     Yes
//    unavailable disabled  Yes     No
//    offline     disabled  No      Yes
//    unavailable disabled  No      No
//    defunct     missing   Yes     Yes
//    defunct     missing   Yes     No
//    defunct     missing   No      Yes
//    <void>      missing   No      No
//
define('XLATMGR_PLUGIN_STATUS_ONLINE', 'online');
define('XLATMGR_PLUGIN_STATUS_OFFLINE', 'offline');
define('XLATMGR_PLUGIN_STATUS_UNAVAILABLE', 'unavailable');
define('XLATMGR_PLUGIN_STATUS_DEFUNCT', 'defunct');

define('XLATMGR_PSEUDO_PLUGIN_PREFIX', '*pseudo-');
define('XLATMGR_ELGG_PSEUDO_PLUGIN', XLATMGR_PSEUDO_PLUGIN_PREFIX.'elgg');

class ElggXlatMgr extends XlatMgr {
	function __construct($config_override=null)
	{
		parent::__construct($config_override);
	}

	public function getElggTranslations($module)
	{
		// TODO: this assumes the knowledge that XlatMgr puts
		// translations in <lang>.php scripts in a directory
		// like Elgg does
		return $this->buildPath($module) . '/';
	}
}

global $CONFIG;
if (isset($CONFIG)) {
	if (!isset($CONFIG->xlatmgr)) {
		$CONFIG->xlatmgr =
			new ElggXlatMgr(
					array(
						'data_dir' => "{$CONFIG->dataroot}xlatmgr/",
						'load_hook' => 'xlatmgr_load_hook',
					)
				);
		if (isset($CONFIG->xlatmgr_options))
			$CONFIG->xlatmgr->overrideConfig($CONFIG->xlatmgr_options);
		XlatMgr::setInstance($CONFIG->xlatmgr);
	}
}

function xlatmgr_same_text_value($t1, $t2)
{
	if ($t1 == $t2)
		return true;

	$normalized_t1 = preg_replace("/\r\n|\r/", "\n", $t1);
	$normalized_t2 = preg_replace("/\r\n|\r/", "\n", $t2);
	return $normalized_t1 == $normalized_t2;
}

function xlatmgr_debug_dump($lang, $prefix='')
{
	global $CONFIG;
	if (empty($CONFIG->translations))
		return '';
	if (empty($CONFIG->translations[$lang]))
		return '';

	$prefix_len = strlen($prefix);

	ob_start();
	foreach ($CONFIG->translations[$lang] as $key => $text) {
		if (strncmp($key, $prefix, $prefix_len) !== 0)
			continue;
		var_export($key);
		echo '=>';
		var_export($text);
		echo PHP_EOL;
	}
	return ob_get_clean();
}

function xlatmgr_load_hook($loaded)
{
	return add_translation($loaded->lang, $loaded->mapping);
}

function xlatmgr_get_plugin_translation($plugin, $lang='')
{
	if (empty($lang))
		$lang = get_current_language();

	// save current translations that include all plugins
	//
	// TODO: it is an implementation detail of Elgg that translations
	// are stored in $CONFIG->translations
	//
	global $CONFIG;
	if ($trans_set = isset($CONFIG->translations)) {
		$trans_bak = $CONFIG->translations;
		unset($CONFIG->translations);
	}

	// load translations for the plugin
	//
	// TODO: it is by convention that a plugin would have its
	// language translations under the 'languages' directory;
	// it's also the case that when looking up a translation,
	// Elgg tries the language and then falls back to 'en';
	// note that we can't just call register_translations()
	// because it uses include_once()
	//
	$path = ($plugin == XLATMGR_ELGG_PSEUDO_PLUGIN)
				? "{$CONFIG->path}languages"
				: "{$CONFIG->pluginspath}$plugin/languages"
				;
	$lang_list = ($lang == 'en') ? array('en') : array('en', $lang);
	foreach ($lang_list as $code) {
		$script = "$path/$code.php";
		if (!file_exists($script))
			continue;

		// TODO: we assume it is safe to load the language script again
		//
		include($script);
	}

	// collect all translations for the plugin; note that
	// order of $lang_list is from generic to specific
	//
	$mappings = array();
	if (isset($CONFIG->translations)) {
		foreach ($lang_list as $code) {
			if (!isset($CONFIG->translations[$code]))
				continue;
			foreach ($CONFIG->translations[$code] as $k => $v)
				$mappings[$k] = $v;
		}
	}

	// restore translations
	//
	if ($trans_set)
		$CONFIG->translations = $trans_bak;

	return $mappings;
}

function xlatmgr_activate_plugin($plugin)
{
	$managed = xlatmgr_get_managed_plugins(true);
	if (!is_array($managed))
		return false;

	if (!isset($managed[$plugin]))
		$managed[] = $plugin;
	return xlatmgr_set_managed_plugins($managed);
}

function xlatmgr_deactivate_plugin($plugin)
{
	$managed = xlatmgr_get_managed_plugins(true);
	if (!is_array($managed))
		return false;

	if (($index = array_search($plugin, $managed)) === false)
		return false;
	unset($managed[$index]);
	return xlatmgr_set_managed_plugins($managed);
}

function xlatmgr_set_managed_plugins($plugins)
{
	if (is_array($plugins))
		$plugins = implode(',', $plugins);
	return set_plugin_setting('managed', $plugins, 'xlatmgr');
}

function xlatmgr_get_managed_plugins($raw=false)
{
	global $CONFIG;

	$xlatmgr = $CONFIG->xlatmgr;

	$managed = get_plugin_setting('managed', 'xlatmgr');
	/*
	if ($managed == '*')
		return $xlatmgr->getAvailableModules();
	*/

	$managed = preg_replace('/[[:space:],]/', ',', $managed);
	$plugin_list = array();
	foreach (explode(',', $managed) as $plugin) {
		if (empty($plugin))
			continue;
		$plugin_list[] = $plugin;
	}
	if ($raw)
		return $plugin_list;

	$available = $xlatmgr->getAvailableModules();
	if (!empty($available))
		$plugin_list = array_intersect($plugin_list, $available);
	return $plugin_list;
}

function xlatmgr_is_pseudo_plugin($plugin)
{
	return strpos($plugin, XLATMGR_PSEUDO_PLUGIN_PREFIX) === 0;
}

function xlatmgr_is_plugin_enabled($plugin)
{
	if (xlatmgr_is_pseudo_plugin($plugin))
		return true;
	return is_plugin_enabled($plugin);
}

function xlatmgr_get_plugin_list()
{
	$pseudo = array(
					XLATMGR_ELGG_PSEUDO_PLUGIN,
				);

	$plugins = get_plugin_list();
	if (empty($plugins))
		return $pseudo;

	sort($plugins);
	return array_merge($pseudo, $plugins);
}

function xlatmgr_get_plugin_name($plugin)
{
	if (xlatmgr_is_pseudo_plugin($plugin))
		return elgg_echo("xlatmgr:name:$plugin");

	return $plugin;
}

function xlatmgr_get_language_name($lang)
{
	// TODO: this isn't very good
	//
	return elgg_echo($lang);
}

function xlatmgr_get_plugins_online()
{
	$plugin_list = xlatmgr_get_managed_plugins();
	if (empty($plugin_list))
		return $plugin_list;

	$result = array();
	foreach ($plugin_list as $plugin) {
		if (!xlatmgr_is_plugin_enabled($plugin))
			continue;
		$result[] = $plugin;
	}
	return $result;
}

function xlatmgr_get_plugin_status($plugin, $details=null)
{
	global $CONFIG;
	$xlatmgr = $CONFIG->xlatmgr;

	$known = in_array($plugin, xlatmgr_get_plugin_list());
	$available = $xlatmgr->checkModule($plugin);
	$disabled = $known ? !xlatmgr_is_plugin_enabled($plugin) : true;
	$mnanaged = xlatmgr_get_managed_plugins(true);
	$mnanaged = empty($managed) ? false : in_array($plugin, $managed);

	if (!empty($details)) {
		$details->known = $known;
		$details->available = $available;
		$details->disabled = $disabled;
		$details->managed = $managed;
	}

	if (!$known) {
		if (!$managed && !$available)
			return false;
		return XLATMGR_PLUGIN_STATUS_DEFUNCT;
	}

	if ($disabled) {
		if ($available)
			return XLATMGR_PLUGIN_STATUS_OFFLINE;
		else
			return XLATMGR_PLUGIN_STATUS_UNAVAILABLE;
	}

	if (!$available)
		return XLATMGR_PLUGIN_STATUS_UNAVAILABLE;

	if (!$managed)
		return XLATMGR_PLUGIN_STATUS_OFFLINE;

	return XLATMGR_PLUGIN_STATUS_ONLINE;
}

function xlatmgr_get_plugins_with_status($details=null)
{
	global $CONFIG;

	$xlatmgr = $CONFIG->xlatmgr;

	$known = xlatmgr_get_plugin_list();
	if (empty($known) && !is_array($known))
		$known = array();

	$available = $xlatmgr->getAvailableModules();
	if (empty($available) && !is_array($available))
		$available = array();

	$managed = xlatmgr_get_managed_plugins(true);
	if (empty($managed) && !is_array($managed))
		$managed = array();

	$result = array();
	$disabled = array();
	$all = array_unique(array_merge($known, $available, $managed));
	foreach ($all as $plugin) {
		if (!in_array($plugin, $known)) {
			$result[$plugin] = XLATMGR_PLUGIN_STATUS_DEFUNCT;
		}
		else if (xlatmgr_is_plugin_enabled($plugin)) {
			if (!in_array($plugin, $available))
				$result[$plugin] = XLATMGR_PLUGIN_STATUS_UNAVAILABLE;
			else if (in_array($plugin, $managed))
				$result[$plugin] = XLATMGR_PLUGIN_STATUS_ONLINE;
			else
				$result[$plugin] = XLATMGR_PLUGIN_STATUS_OFFLINE;
		}
		else {
			$disabled[] = $plugin;
			if (in_array($plugin, $available))
				$result[$plugin] = XLATMGR_PLUGIN_STATUS_OFFLINE;
			else
				$result[$plugin] = XLATMGR_PLUGIN_STATUS_UNAVAILABLE;
		}
	}

	if ($details instanceof stdClass) {
		$details->known = $known;
		$details->disabled = $disabled;
		$details->available = $available;
		$details->managed = $managed;
	}
	return $result;
}

function xlatmgr_get_languages($plugin)
{
	global $CONFIG;
	$xlatmgr = $CONFIG->xlatmgr;

	$trans = $xlatmgr->getAvailableTranslations($plugin, false);
	if (empty($trans))
		return $trans;

	sort($trans[$plugin]);
	return $trans[$plugin];
}

function xlatmgr_load_translations($load_all=false)
{
	global $CONFIG;

	$xlatmgr = $CONFIG->xlatmgr;

	$plugin_list = xlatmgr_get_plugins_online();
	if (empty($plugin_list))
		return;

	$curr_lang = get_current_language();

	$elgg_xlatmgr = ($xlatmgr instanceof ElggXlatMgr) ? $xlatmgr : null;
	if (!$elgg_xlatmgr)
		error_log("xlatmgr: translations not loaded with ElggXlatMgr");

	foreach ($plugin_list as $plugin) {
		if ($elgg_xlatmgr) {
			$xlat_path = $elgg_xlatmgr->getElggTranslations($plugin);
			register_translations($xlat_path);
			continue;
		}

		// The rest of this block is pretty much dead code since we
		// expect ElggXlatMgr to be used.  The old way of loading
		// translation had the issue that get_installed_translations()
		// would not report translations managed by xlatmgr.

		$trans = $xlatmgr->getAvailableTranslations($plugin);
		if (empty($trans))
			continue;

		foreach ($trans[$plugin] as $lang) {
			if ($load_all || $lang == 'en' || $lang == $curr_lang) {
				$xlatmgr->loadTranslation($plugin, $lang);
				// Note: add_translation() is done through load hook
			}
		}
	}
}

function xlatmgr_receive_mapping($key='key', $val='val', $count='keycount')
{
	$keycount = get_input($count, 0);

	$mapping = array();
	for ($index = 0; $index < $keycount; ++$index) {
		// can't use get_input(), which trims input
		//
		$name = $_REQUEST["$key$index"];
		$value = $_REQUEST["$val$index"];

		if ($name === '')
			continue;
		$mapping[$name] = $value;
	}

	return $mapping;
}

function xlatmgr_get_state($create=false)
{
	if (!isset($_SESSION['xlatmgr-state'])) {
		if (!$create)
			return null;
		$_SESSION['xlatmgr-state'] = new stdClass;
	}

	return $_SESSION['xlatmgr-state'];
}

function xlatmgr_scratch_pad_receive($mapping)
{
	$state = xlatmgr_get_state(true);
	if (empty($state))
		return false;

	if (!isset($state->scratch))
		return false;
	$scratch = $state->scratch;

	return $scratch;
}

function xlatmgr_set_scratch_pad_options($target, $src=null)
{
	static $OPTIONS;
	if (!isset($OPTIONS))
		$OPTIONS = array(
						'singleline' => true,	// allow single line value
					);

	if (isset($src))
		foreach ($OPTIONS as $opt => $val)
			$target->$opt = $src->$opt;
	else
		foreach ($OPTIONS as $opt => $val)
			$target->$opt = $val;

	return $target;
}

function xlatmgr_reload_scratch_pad($create=false, $any_lang=false)
{
	if ($old = xlatmgr_wipe_scratch_pad()) {
		set_input('plug', $old->plug);
		set_input('lang', $old->lang);
	}

	$scratch = xlatmgr_get_scratch_pad();
	if ($scratch && $old)
		xlatmgr_set_scratch_pad_options($scratch, $old);

	return $scratch;
}

function xlatmgr_wipe_scratch_pad()
{
	$state = xlatmgr_get_state();
	if (empty($state))
		return false;

	if (!isset($state->scratch))
		return false;

	$wiped = $state->scratch;
	unset($state->scratch);
	return $wiped;
}

function xlatmgr_get_scratch_pad($create=false, $any_lang=false)
{
	$state = xlatmgr_get_state(true);
	if (empty($state))
		return false;

	if (isset($state->scratch)) {
		$scratch = $state->scratch;

		$plug = get_input('plug', $scratch->plug);
		$lang = get_input('lang', $scratch->lang);
		if ($plug == $scratch->plug && $lang == $scratch->lang)
			return $scratch;
	}
	else {
		if (!($plug = get_input('plug', XLATMGR_ELGG_PSEUDO_PLUGIN)))
			return false;
		if (!($lang = get_input('lang')))
			$any_lang = true;

		$scratch = $state->scratch = new stdClass;
	}

	global $CONFIG;
	$xlatmgr = $CONFIG->xlatmgr;

	for (;;) {
		$scratch->mapping = empty($lang)
							? false
							: $xlatmgr->loadTranslation($plug, $lang, false);
		if (!empty($scratch->mapping) || is_array($scratch->mapping))
			break;

		if ($any_lang && ($languages = xlatmgr_get_languages($plug))) {
			$lang = $languages[0];
			$any_lang = false;
			continue;
		}

		if ($create) {
			if (empty($lang))
				$lang = get_current_language();
			$scratch->mapping = array();
			if ($xlatmgr->saveTranslation($plug, $lang, $scratch->mapping))
				break;
		}

		unset($state->scratch);
		return false;
	}

	$scratch->plug = $plug;
	$scratch->lang = $lang;
	$scratch->dirty = false;
	$scratch->status = xlatmgr_get_plugin_status($plug);
	xlatmgr_set_scratch_pad_options($scratch);

	$state->scratch = $scratch;
	return $scratch;
}

function xlatmgr_pagesetup()
{
	if (get_context() != 'admin')
		return;
	if (!isadminloggedin())
		return;

	global $CONFIG;
	add_submenu_item(
		elgg_echo('xlatmgr:manage_trans'),
		"{$CONFIG->wwwroot}pg/xlatmgr/");
}

function xlatmgr_page_handler($page)
{
	switch ($cmd = get_input('cmd')) {
	case 'update':
	case 'reset':
	case 'sync':
	case 'compact':
		set_input('cmd', '');
		set_input('no-forward', '1');
		include(dirname(__FILE__)."/actions/$cmd.php");
		break;
	default:
		break;
	}

	include(dirname(__FILE__) . '/index.php');
	return true;
}

function xlatmgr_boot()
{
	xlatmgr_load_translations();
}

function xlatmgr_init()
{
	if (isadminloggedin()) {
		register_page_handler('xlatmgr', 'xlatmgr_page_handler');
	}

	extend_view('css', 'xlatmgr/css');
}

register_elgg_event_handler('plugins_boot', 'system', 'xlatmgr_boot');
register_elgg_event_handler('init', 'system', 'xlatmgr_init');
register_elgg_event_handler('pagesetup', 'system', 'xlatmgr_pagesetup');

$actions = dirname(__FILE__) . '/actions';
register_action('xlatmgr/ajax',        false, "$actions/ajax.php",        true);
register_action('xlatmgr/lang/add',    false, "$actions/add-lang.php",    true);
register_action('xlatmgr/lang/del',    false, "$actions/del-lang.php",    true);
register_action('xlatmgr/plug/del',    false, "$actions/del-plug.php",    true);
register_action('xlatmgr/update',  	   false, "$actions/update.php",      true);
register_action('xlatmgr/reset',  	   false, "$actions/reset.php",       true);
register_action('xlatmgr/sync',  	   false, "$actions/sync.php",        true);
register_action('xlatmgr/compact',     false, "$actions/compact.php",     true);

// vim: set ai ts=4 noexpandtab syntax=php fdm=marker binary noeol:
?>