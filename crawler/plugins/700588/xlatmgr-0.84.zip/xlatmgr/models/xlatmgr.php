<?php
/**
 * Translation manager model
 *
 * License: GNU Public License version 2
 *          http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * Author:  Patrick Lai
 * Copyright 2010 Patrick Lai
 */

if (!define('XLATMGR_FORMAT_VERSION', 1))
	error_log("cannot define XLATMGR_FORMAT_VERSION");

class XlatMgr {
	protected $data_dir;
	protected $umask = 0770;
	protected $load_hook = '';
	protected $load_hook_enabled = true;
	protected static $THE_INSTANCE = null;

	function __construct($config_override=null)
	{
		$this->data_dir = dirname($__FILE__) . 'xlatmgr/data/';

		if (!empty($config_override))
			$this->overrideConfig($config_override);
	}

	protected static function encodeModuleName($module)
	{
		return urlencode($module);
	}

	protected static function decodeModuleName($encoded)
	{
		return urldecode($encoded);
	}

	protected static function encodeLanguageName($lang)
	{
		return urlencode($lang);
	}

	protected static function decodeLanguageName($encoded)
	{
		return urldecode($encoded);
	}

	protected function buildPath($module, $lang='')
	{
		$path = $this->data_dir . XlatMgr::encodeModuleName($module);
		if (!empty($lang))
			$path .= '/' . XlatMgr::encodeLanguageName($lang) . '.php';
		return $path;
	}

	public static function getInstance()
	{
		if (empty(XlatMgr::$THE_INSTANCE))
			XlatMgr::$THE_INSTANCE = new XlatMgr();
		return XlatMgr::$THE_INSTANCE;
	}

	public static function setInstance($inst)
	{
		XlatMgr::$THE_INSTANCE = $inst;
	}

	public function overrideConfig($override)
	{
		if (empty($override))
			return;

		foreach ($override as $key => $val)
			$this->$key = $val;
	}

	public function loadHookEnabled()
	{
		return $this->load_hook_enabled;
	}

	public function enableLoadHook($on=true)
	{
		$was_on = $this->load_hook_enabled;
		$this->load_hook_enabled = $on;
		return $was_on;
	}

	public function saveTranslation($module, $lang, $mapping)
	{
		$module = (string)$module;
		$lang = (string)$lang;
		if ($module === '' || $lang === '')
			return false;

		$path = $this->buildPath($module, $lang);

		// make sure directory exists
		//
		$dir = dirname($path);
		if (!file_exists($dir)) {
			if (!mkdir($dir, $this->umask, true)) {
				error_log("XlatMgr: cannot create directory <$dir>");
				return false;
			}
		}
		if (!($f = fopen($path, 'wb'))) {
			error_log("XlatMgr: cannot create file <$path>");
			return false;
		}

		ob_start();
		echo
			'<?php
				// THIS IS A GENERATED SCRIPT.  DO NOT EDIT!
				//
				$xlatmgr_tmp = new stdClass;
				$xlatmgr_tmp->format = '.XLATMGR_FORMAT_VERSION.';
				$xlatmgr_tmp->module = '.var_export($module,true).';
				$xlatmgr_tmp->lang = '.var_export($lang,true).';
				$xlatmgr_tmp->mapping = '.var_export($mapping,true).';

				if (empty($xlatmgr)) $xlatmgr = XlatMgr::getInstance();
				$xlatmgr->triggerLoadHook($xlatmgr_tmp);
			?>';
		$script = ob_get_clean();

		$okay = true;
		if (!fwrite($f, $script))
			$okay = false;
		if (!fclose($f))
			$okay = false;

		if (!$okay) {
			error_log("XlatMgr: cannot save translation to file <$path>");
			unlink($path);
		}
		return $okay;
	}

	public function loadTranslation($module, $lang, $hook=true)
	{
		$path = $this->buildPath($module, $lang);
		if (!file_exists($path))
			return false;

		// script expects $xlatmgr
		//
		$xlatmgr = $this;

		$hook_was_on = $this->enableLoadHook($hook);
		$okay = include($path);
		$this->enableLoadHook($hook_was_on);
		if (!$okay)
			return false;

		// $xlatmgr_tmp should be defined by the script loaded
		//
		if (!isset($xlatmgr_tmp))
			return false;

		// version specific handling
		//
		switch ($xlatmgr_tmp->format) {
		case 1:
			// version 1:
			//
			if (!is_array($xlatmgr_tmp->mapping)) {
				error_log("corrupted xlatmgr translation script ($path)");
				return false;
			}
			return $xlatmgr_tmp->mapping;

		default:
			error_log(
				"unsupported xlatmgr format version '{$xlatmgr_tmp->format}'"
				. " ($path)");
			return false;
		}

		// unreachable
		//
		return false;
	}

	public function deleteTranslation($module, $lang)
	{
		$path = $this->buildPath($module, $lang);
		if (!file_exists($path))
			return true;

		if (!unlink($path)) {
			error_log("XlatMgr: cannot delete translation file <$path>");
			return false;
		}

		// try to remove the module directory
		//
		//@rmdir($this->buildPath($module));

		return true;
	}

	public function deleteModule($module)
	{
		$okay = true;

		$trans = $this->getAvailableTranslations($module);
		if (!empty($trans)) {
			foreach ($trans as $mod => $lang_list) {
				if ($module != '*' && $module != $mod)
					continue;
				$mod_dir = $this->buildPath($mod);

				foreach ($lang_list as $lang) {
					$lang_script = $this->buildPath($mod, $lang);
					if (!unlink($lang_script)) {
						error_log(
							"XlatMgr: failed to delete script <$lang_script>");
						$okay = false;
					}
				}
				if (!@rmdir($mod_dir)) {
					error_log(
						"XlatMgr: failed to delete module <$mod_dir>");
					$okay = false;
				}
			}
		}

		return $okay;
	}

	public function triggerLoadHook($loaded)
	{
		if (!$this->load_hook_enabled)
			return false;

		$func = $this->load_hook;
		if (empty($func))
			return false;
		if (!is_callable($func)) {
			error_log("XlatMgr::triggerLoadHook(): <$func> not callable");
			return false;
		}

		return $func($loaded);
	}

	public function getAvailableModules()
	{
		$pattern = $this->data_dir . "*/.";

		$matches = glob($pattern);
		if (empty($matches))
			return $matches;

		$regex = '#^.*/([%-_[:alnum:]]+)/\\.$#';
		$result = array();
		foreach ($matches as $path) {
			$segs = array();
			if (!preg_match($regex, $path, $segs))
				continue;
			$result[] = XlatMgr::decodeModuleName($segs[1]);
		}

		return $result;
	}

	public function getAvailableTranslations($module='*', $load=false)
	{
		if ($module == '*')
			$pattern = $this->data_dir . "*/*.php";
		else
			$pattern = $this->buildPath($module) . '/*.php';

		$matches = glob($pattern);
		if (empty($matches))
			return $matches;

		$regex = '#^.*/([%-_[:alnum:]]+)/([-_[:alpha:]]+)\\.php$#';
		$result = array();
		foreach ($matches as $path) {
			$segs = array();
			if (!preg_match($regex, $path, $segs))
				continue;
			$module = XlatMgr::decodeModuleName($segs[1]);
			$lang = XlatMgr::decodeLanguageName($segs[2]);

			if ($load) {
				$trans = $this->loadTranslation($module, $lang, false);
				if (!is_array($trans))
					continue;
			}
			else
				$trans = true;

			if (!isset($result[$module]))
				$result[$module] = array();
			if ($load)
				$result[$module][$lang] = $trans;
			else
				$result[$module][] = $lang;
		}

		return $result;
	}

	public function checkModule($module)
	{
		$pattern = $this->buildPath($module) . '/*.php';

		$matches = glob($pattern);
		return !empty($matches);
	}

	public function checkTranslation($module, $lang)
	{
		$path = $this->buildPath($module, $lang);

		return file_exists($path);
	}
}

// vim: set ai ts=4 noexpandtab syntax=php fdm=marker binary noeol:
?>