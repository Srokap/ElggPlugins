<?php
	/**
	 * Elgg customindex plugin
	 * This plugin substitutes the frontpage with a custom one
	 * 
	 * @package NewUsers
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Jonathan Rico
	 * @copyright Peesco 2008
	 * @link www.peesco.com
	 */
 ?>
 
<div id="newest-members">
    <h2><?php echo elgg_echo('item:user'); ?></h2>
    <?php $users = get_entities('user', '', 0, '', 20, 0, false, 0, null);
    if($users){
        foreach($users as $user){
            echo "<div class=\"member_icon\">" . elgg_view("profile/icon",array('entity' => $user, 'size' => 'small')) . "</div>";
        }
    }
    ?>
</div>