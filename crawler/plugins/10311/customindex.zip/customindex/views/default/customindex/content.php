<?php
	/**
	 * Elgg customindex plugin
	 * This plugin substitutes the frontpage with a custom one
	 * 
	 * @package Customdash
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Jonathan Rico
	 * @copyright Peesco 2008
	 * @link www.peesco.com
	 */

 
    // Put your content below 
   

//http://community.elgg.org/mod/groups/topicposts.php?topic=3786&group_guid=761

//http://community.elgg.org/pg/plugins/traveljunkie/read/2653/custom-index


 ?>
 <a target="_blank" href="http://www.peesco.com">
 <img width="560" height="150" border="0" alt="bannerpeesco.jpg" src="http://itmparatodos.itm.edu.co/images/Header/bannerpeesco.jpg"/>
 </a>