<?php
	/**
	 * Elgg customindex plugin
	 * This plugin substitutes the frontpage with a custom one
	 * 
	 * @package LastContent
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Jonathan Rico
	 * @copyright Peesco 2008
	 * @link www.peesco.com
	 */
 ?>
 
 <?php

	// Load the last content
        $title = elgg_view_title(elgg_echo('content:latest'));
        set_context('search');
        $content = list_registered_entities(0,10,true,false,array('object','group'));
		echo $title . $content;
		
?>