<?php
	/**
	 * Elgg customindex plugin
	 * This plugin substitutes the frontpage with a custom one
	 * 
	 * @package forum discussion
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Jonathan Rico
	 * @copyright Peesco 2008
	 * @link www.peesco.com
	 */
 ?>
 
 <div id="latest_discussion_widget">
<?php
	echo elgg_view_title(elgg_echo("groups:alldiscussion"));
	
	$forum = get_entities_from_annotations("object", "groupforumtopic", "group_topic_post", "", 0, $vars['entity']->guid, 8, 0, "asc", false);
	if($forum){
		foreach($forum as $f){
		
		$count_annotations = $f->countAnnotations("group_topic_post");
		
		echo "<div class=\"search_listing\">";
		echo "<div class=\"search_listing_icon\">" . elgg_view('profile/icon',array('entity' => $f->getOwnerEntity(), 'size' => 'small')) . "</div>";
		echo "<div class=\"search_listing_info\"><p><a href=\"{$vars['url']}mod/groups/topicposts.php?topic={$f->guid}&group_guid={$f->container_guid}\">" . $f->title . "</a></p> <p class=\"topic_replies\"><small>".elgg_echo('group:replies').": " . $count_annotations . "</small></p></div>";
		
		echo "</div>";
		
		}
	}else{
		
		echo elgg_echo("grouptopic:notcreated");
	}
?>
</div>