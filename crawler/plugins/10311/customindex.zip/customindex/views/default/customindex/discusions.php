<?php
	/**
	 * Elgg customindex plugin
	 * This plugin substitutes the frontpage with a custom one
	 * 
	 * @package Group discusion (in develoup)
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Jonathan Rico
	 * @copyright Peesco 2008
	 * @link www.peesco.com
	 */
 ?>
 <?php

        $title = elgg_view_title(elgg_echo("groups:alldiscussion"));
        set_context('search');
	    $content = list_entities_from_annotations("object", "groupforumtopic", "group_topic_post", "", 40, 0, 0, false, true);	
		echo $title . $content;
		
?>