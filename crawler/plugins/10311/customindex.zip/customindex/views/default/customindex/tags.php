<?php
	/**
	 * Elgg customindex plugin
	 * This plugin substitutes the frontpage with a custom one
	 * 
	 * @package TagCloud
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Jonathan Rico
	 * @copyright Peesco 2008
	 * @link www.peesco.com
	 */
 ?>
    
<div id="tags">
<h2>Tags</h2>
<p>
<?php

	$notags = 100;
	if ( $vars['entity']->notags ) {
        	$notags = $vars['entity']->notags;
	}
	
	echo display_tagcloud( 1, $notags, "tags" );
?>
</p>
</div><!-- end of tagcloud_widget_container -->