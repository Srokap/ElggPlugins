<?php
	/**
	 * Elgg customindex plugin
	 * This plugin substitutes the frontpage with a custom one
	 * 
	 * @package Customdash
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Jonathan Rico
	 * @copyright Peesco 2008
	 * @link www.peesco.com
	 */

 
	//Put some extra CSS below if needed
?>

#newest-members h2, #latest-groups h2, #tags > h2 {
    background:transparent url(<?php echo $vars['url']; ?>mod/theme_mimundo/graphics/boxtop_210.gif) no-repeat scroll left top;
    color:black;
    font-size:1.25em;
    height:25px;
    margin:0 0 10px;
    padding:5px 0 0 30px;
}

#newest-members, #latest-groups,  #tags {
	float:left;
    width: 210px;
}