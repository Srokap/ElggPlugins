<?php
	/**
	 * Elgg customindex plugin
	 * This plugin substitutes the frontpage with a custom one
	 * 
	 * @package NewsGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Jonathan Rico
	 * @copyright Peesco 2008
	 * @link www.peesco.com
	 */
 ?>
 
 <div id="latest-groups">
    <h2><?php echo elgg_echo('groups'); ?></h2>
    <?php $groups = get_entities('group', '', 0, '', 10, 0, false, 0, null);
    if($groups){
        foreach($groups as $group){
            echo "<div class=\"member_icon\">" . elgg_view("profile/icon",array('entity' => $group, 'size' => 'small')) . "</div>";
        }
    }
    ?>
</div>