<?php
	/**
	 * Elgg customindex plugin
	 * This plugin substitutes the frontpage with a custom one
	 * 
	 * @package Customdash
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Boris Glumpler - coauthor: Jonathan Rico
	 * @copyright Boris Glumpler 2008 - Peesco 2008
	 * @link www.peesco.com
	 */
	 
	// Load Elgg engine
	require_once(dirname(dirname(dirname(__FILE__))) . '/engine/start.php');


			/**
		      * Check to see if user is logged in, if not display login form
		      **/
				
				if (isloggedin()) forward('pg/dashboard');
				
				$body = "";
				$bleft = "";
			


//----------------- Left -----------------------//

				// Loguin
				$bleft .= elgg_view("account/forms/login");
				
				// Nuevos miembros
				$bleft .= elgg_view('customindex/newuser', $vars);
				
				// Nuevos grupos
				$bleft .= elgg_view('customindex/newgroup', $vars);
				
				// Nube de tags
				$bleft .= elgg_view('customindex/tags', $vars);


// ---------------- main ------------------------//

			// Custom modulo
				$body .= elgg_view('customindex/content', $vars);
		
			// Ultimas Noticias
	        	$body .= elgg_view('customindex/latest', $vars);
				
			// ultimos discusiones
				$body .= $title . elgg_view('customindex/newforum', $vars);
				
				
			// Get view
				//$body .= elgg_view('customindex/content', $vars);
				
				
//----------------end ------------------------------//
				
	        	
		        set_context('main');
		        global $autofeed;
		        $autofeed = false;
				
				
		// Format
		//$content = elgg_view_layout('one_column', $area1);
		$content = elgg_view_layout('two_column_left_sidebar', '', $body, $bleft);
				
				
		// Draw page
		echo page_draw(null, $content);


?>