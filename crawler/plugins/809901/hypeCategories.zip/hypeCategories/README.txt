hypeCategories is part of the hypeJunction bundle

hypeCategories allows you to create a traverse tree of categories to organize your content.

Main features include:
A full-blown categories plugin for Elgg. Main features include:

- Categories can have their own icons
- Unlimited depth of the category tree
- Support for blogs, bookmarks, files, pages, izap_videos, tidypics photos
- Groups can have their own categories
- Ajax powered administration
- Different access levels

Bug reports:
www.hypeJunction/trac

INSTALLATION
1. Download and install hype Framework from www.elgg.org or www.hypeJunction.com
2. Download and install hype Categories
3. Customize hype Categories settings in Tools Administration
4. Create categories using Manage categories list in the Admin sidebar
