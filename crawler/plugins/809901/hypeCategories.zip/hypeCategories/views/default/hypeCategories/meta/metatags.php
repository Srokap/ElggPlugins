<script type="text/javascript" src="<?php echo $vars['url'] ?>mod/hypeCategories/views/default/hypeCategories/js/fg.menu.js"></script>
<script type="text/javascript" src="<?php echo $vars['url'] ?>mod/hypeCategories/views/default/hypeCategories/js/jquery.treeview.js"></script>

<link type="text/css" href="<?php echo $vars['url'] ?>mod/hypeCategories/views/default/hypeCategories/js/fg.menu.css" media="screen" rel="stylesheet" />
<link type="text/css" href="<?php echo $vars['url'] ?>mod/hypeCategories/views/default/hypeCategories/js/jquery.treeview.css" media="screen" rel="stylesheet" />



