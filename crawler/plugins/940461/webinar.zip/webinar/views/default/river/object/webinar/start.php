<?php
/**
 * Webinar river view.
 */

echo elgg_view('river/elements/layout', array(
	'item' => $vars['item'],
));