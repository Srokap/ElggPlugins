Webinar
Copyright (c) 2011 See COPYRIGHT.txt

See CONTRIBUTORS.txt for development credits.

The webinar project was started in 2011 by:
Simon Bouland <simon.bouland@gmail.com>

The project site can be found at http://www.elgg.org/

Webinar is released under the GNU Public License (GPL) Version 2 and the 
Massachusetts Institute of Technology (MIT) License. See LICENSE.txt 
in the root of the package you downloaded.

Install: Just drop it into the mod directory and that should be it.