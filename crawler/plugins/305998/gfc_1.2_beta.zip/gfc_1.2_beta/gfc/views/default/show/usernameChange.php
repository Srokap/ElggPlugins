<?php
/**
 * Google Friend Connect(GFC) Integration
 *
 * @package ElggGFC
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Arunoda Susiripala
 * @copyright Arunoda Susiripala 2009
 * @link http://elgggfc.googlecode.com
 */

$fcauth=$_COOKIE['fcauth'.$CONFIG->GFC_SITE_ID];
$gfcOffUsername=datalist_get('gfcOffUsername');

if(isset($fcauth) && isloggedin() && $gfcOffUsername!='on'){
	$action=$CONFIG->url . "action/gfc/usernameChange";
	$redirect=$CONFIG->url ."pg/settings/user";
	$user=get_loggedin_user();
	if($user->gfcUsernameChanged!='changed'){
?>

<div id='gfc_username_box' style=''>
	<div id='message' ></div>
	<div id='content'>
		You've not assigned an username to this profile. Plese choose an username. | 
		<b>username: </b>
		<input type='text' id='username' name='username' ></input>
		<button id='submit'>Choose Username</button>
	</div>
</div>

<script type="text/javascript">
	$('#gfc_username_box #submit').click(function(){
		function foo(val){
			if(val=='username_exists'){
				$('#gfc_username_box #message').text("username exists! please try another one");
				setTimeout('content_back()',2000);
			}
			else if(val=='username_changed'){
				$('#gfc_username_box #message').html("usename changed succussfully! Please change the password now "
					+ "<a href='<?php echo $redirect;?>'>click here</a>"
						);				
			}
			else{
				$('#gfc_username_box #message').text("Some error ocurred!");
				setTimeout('content_back()',5000);
			}
		}

		var res=confirm("Do you want to proceed with this username\nYou can only do this once!");
		if(res){
			var username=$('#gfc_username_box #username').val();
			if(username){
				
				$.get('<?php echo $action;?>',"username=" + username ,foo);
				$('#gfc_username_box #content').fadeOut(200);
				$('#gfc_username_box #message').text("Processing...");
				$('#gfc_username_box #message').fadeIn(500);
			}
			else{
				alert("Please enter a username");
			}
		}

	});

	function content_back(){
		$('#gfc_username_box #message').fadeOut(500);
		$('#gfc_username_box #content').fadeIn(1000);
	}

</script>

<?php 
	}
}

?>
