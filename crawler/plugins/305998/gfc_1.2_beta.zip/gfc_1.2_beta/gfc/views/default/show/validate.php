<?php
/**
 * Google Friend Connect(GFC) Integration
 *
 * @package ElggGFC
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Arunoda Susiripala
 * @copyright Arunoda Susiripala 2009
 * @link http://elgggfc.googlecode.com
 */
?>
<div id='gfc_validate' style='display:none;'>
	<h3>Validate GFC User Requests</h3>
	<div id='content' style=''>
		<?php 
			$userList=get_entities_from_metadata("gfcValidation","need","user");
			foreach ($userList as $user){
					$action="{$CONFIG->url}action/gfc/validate?username={$user->username}";
					echo "<div id='{$user->username}'>{$user->name} | <a href='javascript:send_it(\"$action\")'>validate</a></div>";
			}
			if(count($userList)<=0){
				echo "No more GFC User requests";
			}
		?>
	</div>
	<div id="close>"><a href='javascript:close_it();' id='close_btn'>Close</a></div>
</div>

<script type="text/javascript">
	function send_it(url){
		$.get(url,"",delete_it);
	}

	function delete_it(json){
		var res;
		eval("res=" + json);
		if(res.action=='OK'){
			$('#gfc_validate #content #'+res.username).fadeOut(500);
		}
	}
	
	function close_it(){
			$('#gfc_validate').fadeOut(600);
	}
</script>