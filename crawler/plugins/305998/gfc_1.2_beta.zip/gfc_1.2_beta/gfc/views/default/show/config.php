<?php 
/**
 * Google Friend Connect(GFC) Integration
 *
 * @package ElggGFC
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Arunoda Susiripala
 * @copyright Arunoda Susiripala 2009
 * @link http://elgggfc.googlecode.com
 */
		
		$form = "<p></p>";
		
		$form .= "<p>" . elgg_echo('GFC Site ID:');
		$form .= elgg_view('input/text',array(
														'internalname' => 'gfcSiteID',
														'value' => $vars['gfcSiteID'] 
													)) . "</p>";
		$checked=($vars['gfcOnSocialBar']=='on')?"checked='checked'":"";
		$checked_validation=($vars['gfcOnValidation']=='on')?"checked='checked'":"";
		$checked_username=($vars['gfcOffUsername']=='on')?"checked='checked'":"";
		
		$form .= "<p>" . elgg_echo('Enable Social Bar:');
		$form.="<input name='gfcOnSocialBar' id='gfcOnSocialBar' ".$checked." type='checkbox'></p>";
		$form .= "<p>" . elgg_echo('Enable User Validation');
		$form.="<input name='gfcOnValidation' id='gfcOnValidation' ".$checked_validation." type='checkbox'></p>";
		$form .= "<p>" . elgg_echo('Disable Username creation');
		$form.="<input name='gfcOffUsername' id='gfcOffUsername' ".$checked_username." type='checkbox'></p>";										

		$form .= "<p>" . elgg_echo('GFC login icon alignment');
		$form.= elgg_view('input/pulldown', array(
                        'internalname' => 'loginIconAlign',
                        'options_values' => array("left"=>"left","center"=>"center","right"=>"right"),
                        'value' => $vars['loginIconAlign']
                ));
        $form.="</p>";
		
		$form .= elgg_view('input/submit',array(
														'value' => elgg_echo('update'),
														'internalname' => 'submit',
													))."";
													
		$wrappedform = elgg_view('input/form',array(
														'body' => $form,
														'method' => 'get',
														'action' => $vars['url'] . "mod/gfc/config.php"
										));
										
										
?>
      

		<div class="jconnectContainer" ><?php echo $wrappedform; ?>
			<?php 
				if(datalist_get('gfcOnValidation')=='on'){
			?>
			<a href='javascript:open_gfc_validator();'><h3>Validate User Requests<h3></a>
			<?php 
			}
			?>
		</div>
	    <script type="text/javascript">
	    	function open_gfc_validator(){
	    		$('#gfc_validate').fadeIn(1000);
	    	}
	    </script>