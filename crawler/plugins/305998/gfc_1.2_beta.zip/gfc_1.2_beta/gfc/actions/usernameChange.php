<?php
/**
 * Google Friend Connect(GFC) Integration
 *
 * @package ElggGFC
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Arunoda Susiripala
 * @copyright Arunoda Susiripala 2009
 * @link http://elgggfc.googlecode.com
 */

gatekeeper();
include_once '../lib.php';

$username=get_input("username");
$user=get_user_by_username($username);
if($user->guid){
	echo "username_exists";
}
else{
	$fcauth=$_COOKIE['fcauth'.$CONFIG->GFC_SITE_ID];
	if(isset($fcauth)){
		$user=$_SESSION['user'];
		if($user->gfcUsernameChanged!='changed'){
			$username=get_input('username');
			$user->gfc_id=$user->username;
			$user->username=$username;
			$user->gfcUsernameChanged='changed';
			
			//to backward compatibility
			//(older users with elgggfc doesn't have below codes)
			$elgg_user->admin_created = true;
			$elgg_user->created_by_guid = 2;
			$res=$user->save();
			
			//save the icon to this username
			icon_save($user->gfc_icon,true);
			if($res) echo "username_changed";
		}
	}
	else{
		echo "You r not an gfc user";
	}
}

