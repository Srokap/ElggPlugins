<?php
/**
 * Google Friend Connect(GFC) Integration
 *
 * @package ElggGFC
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Arunoda Susiripala
 * @copyright Arunoda Susiripala 2009
 * @link http://elgggfc.googlecode.com
 */
include_once 'lib.php';
$CONFIG->GFC_SITE_ID=datalist_get('gfcSiteID');

function gfc_init(){
	global $CONFIG;
	//add the GFC login button...
	extend_view('account/forms/login','show/login');
	extend_view('page_elements/footer','show/bar');
	extend_view('usersettings/user','show/settings');
	extend_view('metatags','show/gfcLoad');
	extend_view('css','show/css');
	extend_view('page_elements/elgg_topbar','show/usernameChange');
	extend_view('page_elements/elgg_topbar','show/validate');
	
	//register action
	register_action('gfc/usernameChange', false, $CONFIG->pluginspath . 'gfc/actions/usernameChange.php');
	register_action('gfc/validate', false, $CONFIG->pluginspath . 'gfc/actions/validate.php');

	//gfc login work start
	gfc_login();
}

function gfc_login(){
	global $CONFIG;
	if(!isloggedin()){
		$fcauth=$_COOKIE['fcauth'.$CONFIG->GFC_SITE_ID];
		if(isset($fcauth)){
			//call the rest apt for details..
			$rest_call="http://www.google.com/friendconnect/api/people/@me/@self?fcauth=$fcauth";
			$res=file($rest_call);
			$res=implode("\n",$res);
			$gfc_user=json_decode($res)->entry;
				
			//do the login stuff...
			$elgg_user=login_locally($gfc_user);
			
			
		}
	}
}

function login_locally($gfc_user){
	$username="gfc_".$gfc_user->id;
	$elgg_user=get_entities_from_metadata('gfc_id',$username,'user');
	$elgg_user=$elgg_user[0];
	//var_dump($elgg_user->guid);
	//for the backward dependancy
	if(!$elgg_user->guid){
		$elgg_user=get_user_by_username($username);
	}
	
	if(!$elgg_user->guid){
		$res=register_user($username,md5(rand()),$gfc_user->displayName,
		$gfc_user->id."@change-this.com");
		if($res){
			$elgg_user=get_user($res);
			$elgg_user->admin_created = true;
			$elgg_user->created_by_guid = 2;
			//add the meta tags..
			$elgg_user->gfc_id=$username;
			//add need validation  info if that setting is enabled
			if(datalist_get('gfcOnValidation')=='on'){
				/**
				 *  gfcValidation:need | OK 
				 */
				$elgg_user->setMetaData('gfcValidation',"need");
				$elgg_user->save();
			}
		}
		
	}
	
	//check here for validation....
	//if not logout from here
	
	
	if($elgg_user->getMetaData('gfcValidation')=='need'){
		system_message("Please wait!, until administrator approve you");
		icon_save($gfc_user->thumbnailUrl,true,$elgg_user);
		//logout from gfc
		gfc_logout();
		global $CONFIG;
		$url=$CONFIG->url;
		$elgg_user=null;
	}
	
	if($elgg_user) {
		if(login($elgg_user)){
			//save the icon;
			icon_save($gfc_user->thumbnailUrl);
			return $elgg_user;
		}
	}
	return false;
}

function gfc_logout(){
//	if(is_bool(strpos($_SESSION-[],'gfc_'))) return;
	global $CONFIG;
	
	$url=$CONFIG->url;
	//$path=preg_replace(array('//'),'',$url)
	$host=preg_replace(array('/http(s)*:\/\//','/\/.*/'),'',$url);
	$path=preg_replace(array('/http(s)*:\/\//',"/$host/"),'',$url);
	$path.=(substr($path,-1,1)!='/')?"/":"";
	//echo $path;
	setcookie("fcauth$CONFIG->GFC_SITE_ID",null,time()-3600,$path);
}

function gfc_pagesetup(){
	if (get_context() == 'admin' && isadminloggedin()) {
		global $CONFIG;
		add_submenu_item(elgg_echo('GFC Administration'), $CONFIG->wwwroot . 'mod/gfc/config.php');
	}
} 

// Initialise GFC....
//register_plugin_hook('entity:icon:url','user','gfc_icon_url');
register_elgg_event_handler('init','system','gfc_init');
register_elgg_event_handler('logout','user','gfc_logout');

//add the configuration page to the admin menu..
register_elgg_event_handler('pagesetup','system','gfc_pagesetup');


?>
