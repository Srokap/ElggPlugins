<?php
		function irc_chat_init() 
		{
		global $CONFIG;
		add_menu(elgg_echo('Flash Chat'), $CONFIG->wwwroot . "mod/flash_irc_chat/");
		}

	register_elgg_event_handler('init','system','irc_chat_init');

?>