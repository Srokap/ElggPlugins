open up config.xml

change the irc server to a server that is flashpolicy enabled on port 843

change the channel to something you like