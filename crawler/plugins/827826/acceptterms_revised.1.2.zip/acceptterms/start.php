<?php
/**
********************************************************************************
*
* Elgg
* PlugIn		acceptterms.1.1
*				Version 1.1
* Description	Accept Registration terms of the Site
*
* License		GPL2
*
* Author		Moni
* Revised by	SpeedySnail6 2011 December 13th.
* WebSite		http://kidspacex.com/
* EMail			SpeedySnail6@SpeedySnail6.Com
*
* Code Review	::DC::2011_12_13::
*
********************************************************************************
**/
////////////////////////////////////////////////////////////////////////////////
elgg_register_event_handler('init','system','acceptterms_init');
////////////////////////////////////////////////////////////////////////////////
function acceptterms_init()
{
	//global $CONFIG;
	//put the check at the very end
	elgg_extend_view('register/extend','acceptterms/register',1000);
}//function acceptterms_init()
////////////////////////////////////////////////////////////////////////////////
	/**
	::DC::2011_12_13::
	````````````````````````````````````````````````````````````````````````````````
	THIS function acceptterms_register_hook() 
	--> * CAN BE DELETED - NOT NEEDED *
	-- because the JS Code in the View Form
		<a onclick ="javascript:ShowHide('HiddenDiv')" href="javascript:;" >I agree to</a>
	Already takes care of the Missing Accept Terms Input.
	````````````````````````````````````````````````````````````````````````````````
	**/
/**function acceptterms_register_hook()
{
	if (get_input('acptrms',false) != 'true') {
		register_error(elgg_echo('acceptterms:required'));
		forward($_SERVER['HTTP_REFERER']);
	}
}**/
////////////////////////////////////////////////////////////////////////////////
?>