<?php
/**
* Elgg register form
*
* @package Elgg
* @subpackage Core
*/
////////////////////////////////////////////////////////////////////////////////
$password = $password2 = '';
$username = get_input('u');
$email    = get_input('e');
$name     = get_input('n');
////////////////////////////////////////////////////////////////////////////////
if (elgg_is_sticky_form('register')) {
	extract(elgg_get_sticky_values('register'));
	elgg_clear_sticky_form('register');
}
////////////////////////////////////////////////////////////////////////////////
?>
<div class="mtm">
	<label><?php echo elgg_echo('name'); ?></label><br />
	<?php
	echo elgg_view('input/text',array(
		'name' => 'name',
		'value' => $name,
	));
	?>
</div>
<div>
	<label><?php echo elgg_echo('email'); ?></label><br />
	<?php
	echo elgg_view('input/text',array(
		'name' => 'email',
		'value' => $email,
	));
	?>
</div>
<div>
	<label><?php echo elgg_echo('username'); ?></label><br />
	<?php
	echo elgg_view('input/text',array(
		'name' => 'username',
		'value' => $username,
	));
	?>
</div>
<div>
	<label><?php echo elgg_echo('password'); ?></label><br />
	<?php
	echo elgg_view('input/password',array(
		'name' => 'password',
		'value' => $password,
	));
	?>
</div>
<div>
	<label><?php echo elgg_echo('passwordagain'); ?></label><br />
	<?php
	echo elgg_view('input/password',array(
		'name' => 'password2',
		'value' => $password2,
	));
	?>
</div>
<!-- -------------------------------------------------------------------------------- -->
<span title="Check Here to ACCEPT the Site's TERMS">
<input type='checkbox' onclick ="javascript:ShowHide('HiddenDiv')">
I Agree to the 
</span>
<?php
	/**
	::DC::2011_12_13::
	````````````````````````````````````````````````````````````````````````````````
	URL for Terms e.g. http://localhost/elgg1801/terms :-
		echo elgg_get_site_url()	=> the URL for the Site.
		/terms						=> the Elgg Page for Terms.
	Site Name :-
		elgg_get_site_entity()->name
	````````````````````````````````````````````````````````````````````````````````
	**/
	$site = elgg_get_site_entity(); //::DC::
	$site_name = $site->name; //::DC::
	$site_url = elgg_get_site_url()//::DC::
?>
<!-- ::DC:: -->
<a href="<?php echo $site_url;?>terms" target="_blank" title="Click here to READ the Site's TERMS"> <?php echo $site_name;?> Terms</a><br><br>
<script language="JavaScript">
function ShowHide(divId)
{
	if(document.getElementById(divId).style.display == 'none')
	{
		document.getElementById(divId).style.display = 'block';
	}
	else
	{
		document.getElementById(divId).style.display = 'none';
	}
}
</script>
<!-- -------------------------------------------------------------------------------- -->
<div class="mid" id="HiddenDiv" style="DISPLAY: none" >
	<?php
	// view to extend to add more fields to the registration form
	echo elgg_view('register/extend');
	// Add captcha hook
	echo elgg_view('input/captcha');
	echo elgg_view('input/hidden',array('name' => 'friend_guid','value' => $vars['friend_guid']));
	echo elgg_view('input/hidden',array('name' => 'invitecode','value' => $vars['invitecode']));
	echo elgg_view(
		 'input/submit'
		,array(
			 'name' => 'submit','value' => elgg_echo('register')
			,'display' => 'none' //::DC::
		)
	);
?>
</div>
<script type="text/javascript">
$(function() {
	$('input[name=name]').focus();
});
</script>
<!-- -------------------------------------------------------------------------------- -->