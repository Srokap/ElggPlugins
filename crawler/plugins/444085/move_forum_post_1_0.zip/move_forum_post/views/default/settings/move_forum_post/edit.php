<p>
<?php

echo elgg_echo('mfp:display_instruct');

if (!isset($vars['entity']->display)) {
	// default is to display the control box
	$vars['entity']->display = 'yes';
}
$options = array('yes', 'no');
echo elgg_view('input/pulldown', array('options' => $options,
										'value' => $vars['entity']->display,
										'internalname' => 'params[display]'));
?>
</p>