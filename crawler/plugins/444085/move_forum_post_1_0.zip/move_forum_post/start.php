<?php

/**
 * Move a forum post
 *
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Cash Costello
 * @copyright Cash Costello 2010
 */

register_action('move_post', false, $CONFIG->pluginspath . 'move_forum_post/actions/move.php', true);
