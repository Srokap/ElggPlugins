<?php

$english = array(

	'mfp:move_instruct' => "Move post to the group:",
	'mfp:display_instruct' => "Do you want to display the move forum post box?",
	'mfp:success' => "Successfully moved the forum post",

);

add_translation("en",$english);

?>