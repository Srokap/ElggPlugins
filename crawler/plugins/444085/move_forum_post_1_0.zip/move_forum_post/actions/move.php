<?php

/**
 * Move a forum post
 *
 * This moves the post to another group regardless of whether the posters belong
 * to that group
 *
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Cash Costello
 * @copyright Cash Costello 2010
 */

$group_guid = get_input('group_guid');
$post_guid = get_input('post_guid');

$post = get_entity($post_guid);

if (!$post) {
	register_error('move forum post error 1');
	forward($_SERVER['HTTP_REFERER']);
}

if ($group_guid == 0) {
	register_error('move forum post error 2');
	forward($_SERVER['HTTP_REFERER']);
}

$orig_group_guid = $post->container_guid;

$post->container_guid = $group_guid;
$post->save();

system_message(elgg_echo('mfp:success'));
forward($CONFIG->url . "pg/groups/forum/{$orig_group_guid}/");

?>