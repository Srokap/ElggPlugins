<?php
$english = array(
	'agerestriction:confirmation' => "I swear to high heaven that I'm of full age (18 years or older).<br>",

	'agerestriction:required' => "You must confirm to be of full age (18 years or older) to join.",
);

add_translation("en",$english);