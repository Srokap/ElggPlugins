<?php
/**
 * User picker instead of friend picker
 * 
 */

