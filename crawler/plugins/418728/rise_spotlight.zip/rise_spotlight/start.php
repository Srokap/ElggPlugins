<?php
	/**
	 * Rise Software Inc. - Spotlight plugin
	 * 
	 * The spotlight plugin implements the views needed to override the default 
	 * Spotlight text.  You just need to edit the language pack to suit your taste.
	 * 
	 * 
	 * @package Rise_Spotlight
	 * @license http://www.gnu.org/licenses/oFld-licenses/gpl-2.0.html GNU Public License version 2
	 * @author I_Artist
	 * @copyright Rise Software Inc. 2009-2010
	 * @link http://www.risesoftware.com/
	 */

	/**
	 * Initialise the spotlight plugin.
	 * 
	 * Nothing to do.
	 */
	function rs_spotlight_init() {
    	global $CONFIG;
		
	}
	
	// Make sure the spotlight initialisation function is called on initialisation
	register_elgg_event_handler('init', 'system', 'rs_spotlight_init');
?>
