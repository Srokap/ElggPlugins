<?php
	/**
	 * Rise Software - Spotlight plugin language pack
	 * 
	 * @package RiseReviewGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Rise Software Inc.
	 * @copyright Rise Software Inc. 2009
	 * @link http://www.risesoftware.com/
	 */

	$english = array(


   'spotlight:title' => 'Help Desk',

   /*
    * Dashboard
    */
   'spotlight:dashboard:lhs:title' => 'Dashboard',
   'spotlight:dashboard:lhs:description' => "Your Dashboard is your main page where you will see most of your goodies.  By customizing this page
   using the <i>Edit Page</i> button you can add your prefered widgets.  You can choose your widgets to keep you up to date on all the site's updates, view your
   friends, see your Twitter feed, and more.",
   
   'spotlight:dashboard:rhs:title' => 'Dashboard Help',
   'spotlight:dashboard:rhs:description' => "
      <li>You can change the layout of your Dashboard with the <i>Edit Page</i> link</li>
         <ul>
            <li>Hover your mouse over the blue information icons to see the description of the widget</li>
            <li>Drag and drop widgets from the Widget Gallery to your Dashboard by clicking on the '4 arrows' icon.</li>
            <li>Don't forget to click <i>Save</i> when you are done.</li>
        </ul>
     <li>Once back on your Dashboard adjust the settings of your widgets by clicking on their <i>Edit</i> button</li>",
   
	
   /*
    * Blog
    */
   'spotlight:blog:lhs:title' => 'Blog',
   'spotlight:blog:lhs:description' => "
      <li>A normal web log.</li>
      <li>Members can create their own blogs for free!</li>",
   
   'spotlight:blog:rhs:title' => 'Help',
   'spotlight:blog:rhs:description' => "
      <li>You can subscribe to a member's blog RRS feed to be notified of changes</li>
      <li>You can bookmark a blog to gain easy access to it</li>",

   
   /*
    * Pages
    */
   'spotlight:pages:rhs:title' => 'Help',
   'spotlight:pages:rhs:description' => "
      <li>You can subscribe to a Pages' RRS feed to be notified of changes</li>
      <li>You can bookmark a Page to gain easy access to it</li>",

	'spotlight:pages:lhs:title' => 'Pages',
   'spotlight:pages:lhs:description' => "
      <li>Pages are blank sheets that you can turn into whatever you want.</li>
      <li>Pages can be public, or shown only to logged on users, your friends, groups </li>
      <li>You can even allow people to write on your Pages.</li>,",
      
	/*
	 * Friends
	 */
   'spotlight:friends:lhs:title' => 'Friends',
   'spotlight:friends:lhs:description' => "
      <li>Here are your friends on Rise.</li>
      <li>You can give special permissions to your friends, such as letting them view personal information</li>
      <li>You can see your friends and invite folks.</li>
      <li>You can also see who considers you a friend.</li>
      <li>Don't be a stranger!</li>",
      
   'spotlight:friends:rhs:title' => 'Help',
   'spotlight:friends:rhs:description' => "
      <li>Howevering over a person's photo will show you a menu where you can add them as a friend.</li>
      <li>Or click on a person to go to their profile and add them.</li>
      <li>Being friends isn't mutual so Joe can be your friend but you may not be his!</li>",

	/*
	 * Groups
	 */
   'spotlight:groups:lhs:title' => 'Groups',
   'spotlight:groups:lhs:description' => "
      <li>A Group brings together people around a certain topic.<li>
      <li>You can attach blogs, files, comments, discussions and fun within each Group!</li>
      <li>Use this area to discuss anything Rise Software or Android related.<li>
      <li>Say hi and please feel welcome to contribute.</li>",

	'spotlight:groups:rhs:title' => 'Help',
   'spotlight:groups:rhs:description' => "
      <li>View all the discussions on the Rise page.</li>
      <li>Newest, Popular, and Latest Discussion tabs are at the top for ease of use.</li>
   <li>To create your Group:</li>
      <ul>
         <li>Give it a name and description.  These will be seen throughout the site.</li>
         <li>Decide if you have a public (open) or private (closed) group with Membership Permissions.</li>
         <li>Enable or disable the features that you want in your group.</li>
         </ul>",

   /*
	 * Bookmarks
	 */
   'spotlight:bookmarks:lhs:title' => 'Bookmarks',
   'spotlight:bookmarks:lhs:description' => "
      <li>Here are your favorite links and pages on Rise.<li>
      <li>You can also add bookmarks to webpages on other sites.<li>
      <li>Add as many as you like.</li>
      <li>You can share your bookmarks also view your friends bookmarks!</li>
      <li>There can be many uses for this feature...</li>",
	
   'spotlight:bookmarks:rhs:title' => 'Help',
   'spotlight:bookmarks:rhs:description' => "
      <li>To add sites to this page, click the <i>Bookmark This</i> link in the top left of the site. </li>
      <li>To remove bookmarks, select <i>View Bookmark</i> and then select <i>Delete</i>.</li>
      <li>Use the <i>Get Bookmarklet</i> to easily bookmark any website you visit!</li>",

   /*
    *  Files
    */
   'spotlight:file:lhs:title' => 'Files',
   'spotlight:file:lhs:description' => "
      <li>On the Files page you can upload anything from pictures to audio files.<li>
      <li>Use this area to upload pictures for your blogs, pages, reviews or groups!</li>
      <li>You can also view your friends files!</li>",

   'spotlight:file:rhs:title' => 'Help',
   'spotlight:file:rhs:description' => "
      <li>Use the <i>". elgg_echo('file:upload') ."</i> link and fill out the requested fields!</li>
      <li>Please no viruses or anything malicious!</li>",

   
  /*
    *  Messages
    */
   'spotlight:messages:lhs:title' => 'Files',
   'spotlight:messages:lhs:description' => "
      <li>On the Files page you can upload anything from pictures to audio files.<li>
      <li>Use this area to upload pictures for your blogs, pages, reviews or groups!</li>
      <li>You can also view your friends files!</li>",

   'spotlight:messages:rhs:title' => 'Help',
   'spotlight:messages:rhs:description' => "
      <li>Use the <i>". elgg_echo('file:upload') ."</i> link and fill out the requested fields!</li>
      <li>Please no viruses or anything malicious!</li>",

   
	/*
    * Profile
    */
   'spotlight:profile:lhs:title' => 'Profile',
   'spotlight:profile:lhs:description' => "
      <li>It's all about you!<li>
      <li>This is your public profile, tell everyone about yourself. Show us that pretty mug of yours.</li>
      <li>Please configure the layout and widgets to your liking.</li>",
      
   'spotlight:profile:rhs:title' => 'Help',
   'spotlight:profile:rhs:description' => "
      <li>You can change your profile information with the <i>Edit profile</i> link</li>
         <ul>
            <li>Fill in the <i>About me</i> section</li>
            <li>You can set your privacy settings for each field</li>
         </ul>
      <li>You can change your layout to however you'd like through the <i>Edit page</i> link</li>
         <ul>
            <li>Hover your mouse over the blue information icons to see the description of the widget</li>
            <li>Drag and drop widgets from the Widget Gallery to your Profile Page by clicking on the '4 arrows' icon.</li>
            <li>Don't forget to click <i>Save</i> when you are done.</li>
        </ul>
     <li>Once back on your Profile Page adjust the settings of your widgets by clicking on their <i>Edit</i> button</li>",
   

   
   /*
    * Settings
    */
   'spotlight:settings:lhs:title' => 'Settings',
   'spotlight:settings:lhs:description' => "
      <li>Here you can configure your personal settings and see your statisticsfor the site.<li>
      <li>Configure your twitter settings<li>
      <li>You must configure your Notification settings if you want to be notified of changes on the site<li>
      <li>You may also receive notifications when your friends create content on the site
      <li>We will be adding more languages soon!</li>",
      
   'spotlight:settings:rhs:title' => 'Help',
   'spotlight:settings:rhs:description' => "
      <li>Click on to <i>" . elgg_echo('usersettings:user:opt:linktext') . "</i> to change your password.</li>
      <li>Click on to <i>" . elgg_echo('usersettings:plugins:opt:linktext') . "</i> to change your twitter information.</li>
      <li>Your notifications can be sent to two destinations:</li>
         <ul>
            <li>Email: notifications are sent to the email you registered.</li>
            <li>Site: notifications are sent you your account on the site.</li>
        </ul>
     <li>Don't forget to click on the <i>Save</i> button at the bottom of the page.</li>",
   
	/*
	 * Expages
	 */
   'spotlight:expages:lhs:title' => 'Welcome to the' . elgg_echo('spotlight:title') . '!',
   'spotlight:expages:lhs:description' => "If you are lost, the spotlight guide you.  
    Here you will find information about where you are in the site, what you can do, where to go, and so on. 
    You can also close the Spotlight by clicking on the 'minus' sign on the right side Spotlight title bar.",
   
	'spotlight:expages:rhs:title' => 'Home page Help',
   'spotlight:expages:rhs:description' => "
	<li>The most used menu items show just under the Rise logo</li>
	<li>Once logged in you will see more options in the upper black bar under the Tools menu</li>
	  <li>The android logo in the upper left corner shows your logged in status:
	  <ul>
	     <li>Green: you are logged in</li>
	      <li>Yellow: not logged in</li>
	     <li>Red: logged in as administrator</li>
	  </ul>
	</li>",

  /*
	* Custom Index (main)
	*/   
   'rise_custom_index:spotlight:lhs:title' => 'Welcome to the Help Desk !',
	'rise_custom_index:spotlight:lhs:description' => "Our site may be a little different to what you are accustomed to.  This guide will assist you while you are learning the ropes.  
    Here you will find information about where you are on the site, what you can do, where to go, and so on.  The left side will contain a description of the section you are in
    while the right side will contain help on how to use the section. 
    Once you feel comfortable on the site you can minimize the Help Desk by clicking on the 'minus' sign on the right side Help Desk title bar.",
   
   'rise_custom_index:spotlight:rhs:title' => "Home page help",
   'rise_custom_index:spotlight:rhs:description' => "
	   <li>The most used menu items show just under the Rise logo</li>
	   <li>Once logged in you will see more options in the button menu and in the upper black bar under the Tools menu</li>
	   <li>The android logo in the upper left corner shows your logged in status:
	      <ul>
	         <li>Green: you are logged in</li>
	         <li>Yellow: not logged in</li>
	         <li>Red: logged in as administrator</li>
	      </ul>
	   </li>",
   
	
	);
					
	add_translation("en",$english);
?>
