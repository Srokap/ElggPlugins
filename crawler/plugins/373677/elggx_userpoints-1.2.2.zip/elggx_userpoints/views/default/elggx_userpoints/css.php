<?php
	/**
	 * userpoint CSS
	 */
?>

.userpoints_profile{
    font-weight: bold; 
    padding: 3px 0 3px 5px;
    margin-top: 10px;
    background:white;
}

/* ------ userpoints widgets ------  */

#userpoints_mypoints_widget_container {
    text-align:left;
}

#userpoints_toppoints_widget_container {
    text-align:left;
    /* background-color:#00ffff; */
}
    
.elggx_userpoints_actions h3 {
    color:#4690D6;
}
.elggx_userpoints_actions label {
    font-size:12px;
}
