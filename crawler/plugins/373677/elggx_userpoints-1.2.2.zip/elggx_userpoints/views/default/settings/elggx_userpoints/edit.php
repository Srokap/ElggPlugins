<?
	global $CONFIG;  
	$settings_url = $CONFIG->wwwroot . 'mod/elggx_userpoints/admin.php?tab=settings';
?>

<p>
<a href="<?php echo $settings_url; ?>"><?php echo elgg_echo('elggx_userpoints:admin_settings'); ?></a>
</p>
