<?php
/**
 * publication_form arrays
 */

$prizes = array(
 'top10' =>  elgg_echo('resume:publication:prizes:top10'),
 'top5' =>  elgg_echo('resume:publication:prizes:top5'),
 'nobel' =>  elgg_echo('resume:publication:prizes:nobel'),
 'fieldint' =>  elgg_echo('resume:publication:prizes:fieldint'),
 'subfieldint' =>  elgg_echo('resume:publication:prizes:subfieldint'),
 'fieldnat' =>  elgg_echo('resume:publication:prizes:fieldnat'),
 'subfieldnat' =>  elgg_echo('resume:publication:prizes:subfieldnat'),
 'fieldreg' =>  elgg_echo('resume:publication:prizes:fieldreg'),
 'subfieldreg' =>  elgg_echo('resume:publication:prizes:subfieldreg'),
 'academynat' =>  elgg_echo('resume:publication:prizes:academynat'),
 'academyreg' =>  elgg_echo('resume:publication:prizes:academyreg'),
);
