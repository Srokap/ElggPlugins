<?php
/**
 * research_form arrays
 */

$prizes = array(
 'top10' =>  elgg_echo('resume:research:prizes:top10'),
 'top20' =>  elgg_echo('resume:research:prizes:top20'),
 'nobel' =>  elgg_echo('resume:research:prizes:nobel'),
 'fields' =>  elgg_echo('resume:research:prizes:fields'),
 'gairdner' =>  elgg_echo('resume:research:prizes:gairdner'),
 'lasker' =>  elgg_echo('resume:research:prizes:lasker'),
 'turing' =>  elgg_echo('resume:research:prizes:turing'),
 'engineering1' =>  elgg_echo('resume:research:prizes:engineering1'),
 'engineering2' =>  elgg_echo('resume:research:prizes:engineering2'),
 'engineering3' =>  elgg_echo('resume:research:prizes:engineering3'),
 'economics' =>  elgg_echo('resume:research:prizes:economics'),
 'fieldint' =>  elgg_echo('resume:research:prizes:fieldint'),
 'subfieldint' =>  elgg_echo('resume:research:prizes:subfieldint'),
 'fieldnat' =>  elgg_echo('resume:research:prizes:fieldnat'),
 'subfieldnat' =>  elgg_echo('resume:research:prizes:subfieldnat'),
 'fieldreg' =>  elgg_echo('resume:research:prizes:fieldreg'),
 'subfieldreg' =>  elgg_echo('resume:research:prizes:subfieldreg'),
 'academynat' =>  elgg_echo('resume:research:prizes:academynat'),
 'academyreg' =>  elgg_echo('resume:research:prizes:academyreg'),
);
