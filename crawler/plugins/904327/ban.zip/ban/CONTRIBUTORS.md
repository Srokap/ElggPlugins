Contributors to this plugin
============================
 * Cash Costello http://community.elgg.org/pg/profile/costelloc
 * Brett Profitt http://community.elgg.org/pg/profile/brett.profitt
 * Liang Lee http://community.elgg.org/pg/profile/arsalanlee