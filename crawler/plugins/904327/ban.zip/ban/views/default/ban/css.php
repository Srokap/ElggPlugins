.ban-column {
	float: left;
	margin-right: 1%;
}
.ban-name {
	width: 20%;
}
.ban-reason {
	width: 28%;
}
.ban-count {
	width: 4%;
	text-align: right;
	margin-right: 2%;
}
.ban-date {
	width: 24%;
}
.ban-release {
	width: 18%;
	text-align: right;
}
