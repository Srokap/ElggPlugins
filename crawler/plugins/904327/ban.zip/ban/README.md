Elgg plugin for banning users
