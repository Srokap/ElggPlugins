<?php
	/**
	 * Elgg plugin to turn URLs posted to the river into links
	 * 
	 * @author  Lenny Urbanowski
	 * @link	http://www.itslennysfault.com
	 * @package ElggRiverLinks
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 *
	 * Created for Pixel Brothers Interactive (http://www.pixbros.com)
	 */
	 
		function riverlinks_init() {
			global $CONFIG;
		}
		
		register_elgg_event_handler('init','system','riverlinks_init');
?>