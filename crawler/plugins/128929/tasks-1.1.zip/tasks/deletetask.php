<?php
/**
 *	Tasks Plugin
 *	@package Tasks
 *	@author Liran Tal <liran@enginx.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 **/

set_context('Tasks');

$username = get_input('username');
$taskTitle = get_input('taskTitle');
$taskId = get_input('taskId');

if ($taskId && ($myObject = get_entity($taskId)) ) {

	$title = elgg_echo('tasks:deletetask');
	
	
	$body = elgg_view('forms/tasks/deletetask', array('entity' => $myObject, 
													'full' => true)
						);
	$body = elgg_view_layout('two_column_left_sidebar','', elgg_view_title($title) . $body);
	
	echo page_draw($title, $body);

} else {

	register_error(elgg_echo("tasks:error:objectnotfound"));
	forward();
}


?>
