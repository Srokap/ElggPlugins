<?php
/**
 *	Tasks Plugin
 *	@package Tasks
 *	@author Liran Tal <liran@enginx.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 **/
 
global $CONFIG;
gatekeeper();

// get object guid from URL
$object_guid = get_input('object_guid');

// grab the object 
$myObject = new ElggObject($object_guid);
if(!$myObject->delete()) {
	register_error(elgg_echo('tasks:error:deletetask'));
	forward($vars['url'] . 'pg/tasks/' . $_SESSION['user']->username . '/viewtasks');
}

system_message(elgg_echo('tasks:success:deleted'));
forward($vars['url'] . 'pg/tasks/' . $_SESSION['user']->username . '/viewtasks');

?>
