<?php
/**
 *	Tasks Plugin
 *	@package Tasks
 *	@author Liran Tal <liran@enginx.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 **/

// making sure the user is logged in
gatekeeper();

// grab all our post input into local variables
$object_guid = get_input('object_guid');
$name = get_input('name');
$long_description = get_input('long_description');
$enddate = get_input('enddate');
$startdate = get_input('startdate');
$access = get_input('access', ACCESS_PRIVATE);
$priority = get_input('priority');
$assignedto = get_input('assignedto');
$tags = string_to_tag_array(get_input('tags'));

if (empty($name)) {
	// if a name for the object hasn't been provided then we are not
	// going to save it, thus we redirect to an error page
	register_error(elgg_echo("tasks:error:nameempty"));
	forward($_SERVER['HTTP_REFERER']);
} else {
	// otherwise, if a name for the object was provided then
	// we create an ElggObject entity with a unique subtype
	// of our objects name 
	
	// if this is an editing of an existing object then we create
	// a new object based on an existing guid
	// otherwise we simply create a new object instance
	if ($object_guid)
		$myObject = new ElggObject($object_guid);
	else
		$myObject = new ElggObject();
		
	$myObject->title = $name;
	$myObject->access_id = $access;
	$myObject->subtype = "tasks";
	$myObject->owner_guid = $_SESSION['user']->getGUID();

	// attempting to save the object
	if (!$myObject->save()) {
		// if saving was at fault we redirect to an error page
		register_error(elgg_echo("tasks:error:objectnotfound"));
		forward($_SERVER['HTTP_REFERER']);
	} else {
		// if saving of the object was successful
		// we create and assign metadata for this object based
		// on the post input we received
		$myObject->name = $name;
		$myObject->long_description = $long_description;
		$myObject->startdate = $startdate;
		$myObject->enddate = $enddate;
		$myObject->priority = $priority;
		$myObject->assignedto = $assignedto;
		$myObject->tags = $tags;

		// Now see if we have a file icon
		if ((isset($_FILES['icon'])) && (substr_count($_FILES['icon']['type'],'image/')))
		{
			$prefix = "tasks/".$myObject->guid;
			
			$filehandler = new ElggFile();
			$filehandler->owner_guid = $myObject->owner_guid;
			$filehandler->setFilename($prefix . ".jpg");
			$filehandler->open("write");
			$filehandler->write(get_uploaded_file('icon'));
			$filehandler->close();
			
			$thumbtiny = get_resized_image_from_existing_file($filehandler->getFilenameOnFilestore(),25,25, true);
			$thumbsmall = get_resized_image_from_existing_file($filehandler->getFilenameOnFilestore(),40,40, true);
			$thumbmedium = get_resized_image_from_existing_file($filehandler->getFilenameOnFilestore(),100,100, true);
			$thumblarge = get_resized_image_from_existing_file($filehandler->getFilenameOnFilestore(),200,200, false);
			if ($thumbtiny) {
				
				$thumb = new ElggFile();
				$thumb->owner_guid = $myObject->owner_guid;
				$thumb->setMimeType('image/jpeg');
				
				$thumb->setFilename($prefix."tiny.jpg");
				$thumb->open("write");
				$thumb->write($thumbtiny);
				$thumb->close();
				
				$thumb->setFilename($prefix."small.jpg");
				$thumb->open("write");
				$thumb->write($thumbsmall);
				$thumb->close();
				
				$thumb->setFilename($prefix."medium.jpg");
				$thumb->open("write");
				$thumb->write($thumbmedium);
				$thumb->close();
				
				$thumb->setFilename($prefix."large.jpg");
				$thumb->open("write");
				$thumb->write($thumblarge);
				$thumb->close();
					
			}
		}

		system_message(elgg_echo("tasks:success:saved"));
		
		//forward($myObject->getURL());
		forward($vars['url'] . 'pg/tasks/' . $_SESSION['user']->username . '/viewtasks');
	}
}
?>
