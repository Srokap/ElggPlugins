<?php
/**
 *	Tasks Plugin
 *	@package Tasks
 *	@author Liran Tal <liran@enginx.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 **/
 
 
set_context('Tasks');

require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

// forcing viewtype (gallery or listing)
set_input("search_viewtype", "list");
$filterBy = get_input("filter", "");

// add side menu navigation links
add_submenu_item(elgg_echo('tasks:createtask'), 
	$CONFIG->wwwroot."pg/tasks/".$_SESSION['user']->username."/createtask/");
	
$title = elgg_echo("tasks:taskslist");

$body .= "<br/>";


// get possible values for each filter type from configuration options
$assignedto = explode(",", get_plugin_setting('configAssignedTo', 'tasks'));
$priority = explode(",", get_plugin_setting('configPriority', 'tasks'));

// iterate through option values and create an HTML <option> element
$filterPriorityOption = "";
foreach($priority as $val)
	$filterPriorityOption .= "<option value='".trim($val)."'>".trim($val)."</option>";
	
$filterAssignedToOption = "";
foreach($assignedto as $val)
	$filterAssignedToOption .= "<option value='".trim($val)."'>".trim($val)."</option>";

$filterPriority = " ".elgg_echo('tasks:filterbypriority')." ". 
	" <select name='filter[priority]'>".
	"<option value=''>".elgg_echo('tasks:all')."</option>".
	$filterPriorityOption.
	"</select>";

$filterAssignedTo = " ".elgg_echo('tasks:filterbyassignedto')." ". 
	"<select name='filter[assignedto]'>".
	"<option value=''>".elgg_echo('tasks:all')."</option>".
	$filterAssignedToOption.
	"</select>";

$filters = "<form action='".$CONFIG->wwwroot."pg/tasks/".$_SESSION['user']->username."/viewtasks' method='post'>".
			$filterPriority.
			$filterAssignedTo.
			"<input type='hidden' value='' name='filterBy' />".
			" <input type='submit' value='".elgg_echo('tasks:filter')."' />".
			"</form><br/>";
	
$body .= $filters;


if ($filterBy['priority'] == "" && $filterBy['assignedto'] == "")
	$filterOn = false;
else if ($filterBy['priority'] || $filterBy['assignedto'])
		$filterOn = true;
	
if ($filterOn)
	$body .= list_entities_from_metadata_multi($filterBy,'object','tasks', 0, 15, true, true, true);
else
	$body .= list_entities('object','tasks', 0, 15, true, true, true);

$body = elgg_view_layout('two_column_left_sidebar', '', elgg_view_title($title) . $body);

page_draw($title, $body);

?>
