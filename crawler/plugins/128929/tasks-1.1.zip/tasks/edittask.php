<?php
/**
 *	Tasks Plugin
 *	@package Tasks
 *	@author Liran Tal <liran@enginx.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 **/

gatekeeper();
global $CONFIG;

set_context('Tasks');

$username = get_input('username');
$taskTitle = get_input('taskTitle');
$taskId = get_input('taskId');

if ($taskId && ($myObject = get_entity($taskId)) ) {

	$body = elgg_view("forms/tasks/createtask", array('entity' => $myObject));
	$title = $myObject->title;
	page_draw($title, elgg_view_layout("two_column_left_sidebar", '', elgg_view_title($title) . $body));
} else {
	register_error("tasks:error:objectnotfound");
	forward();
}

?>
