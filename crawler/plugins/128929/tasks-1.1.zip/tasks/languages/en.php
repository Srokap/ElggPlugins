<?php
/**
 *	Tasks Plugin
 *	@package Tasks
 *	@author Liran Tal <liran@enginx.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 **/

	$english = array(

		// General Items

			'tasks:tasks' => "Tasks",
			'tasks:owner' => "Task Owner",
			
			'tasks:taskslist' => "Tasks List",
			'tasks:viewtasks' => "View Tasks",
			
			'tasks:name' => "Task Name",
			'tasks:name:helper' => "Provide a friendly name describing this task in short",

			'tasks:description' => "Task Description",
			'tasks:description:helper' => "Provide a full description of this task",

			'tasks:priority' => "Task Priority",
			'tasks:priority:helper' => "Choose priority for this task",
			'tasks:settings:priority:helper' => "Provide values for the Select box's Priority field, separate different".
											"options by the use of a comma",
			'tasks:priority:high' => "High",
			'tasks:priority:medium' => "Medium",
			'tasks:priority:low' => "Low",

			'tasks:assignedto' => "Assigned To",
			'tasks:settings:assignedto:helper' => "Provide values for the Select box's Assigned To field, separate different".
											"options by the use of a comma",

			'tasks:startdate' => "Starting Date",
			'tasks:startdate:helper' => "Starting date for this task. Date format example: Jan 1, 2009",
			
			'tasks:enddate' => "Ending Date",
			'tasks:enddate:helper' => "Ending date (due date/deadline) for this task. Date format example: Feb 28, 2009",

			'tasks:tags' => "Task Tags",
			'tasks:description:tags' => "You may add tags separated by comma which relate to this task",

			'tasks:taskdue' => "Task Due",
			
			'tasls:unavailable' => "unavailable",
			'tasks:due' => "due",
			'tasks:overdue' => "overdue",
			'tasks:days' => "days",
			
			
			'tasks:filterbyassignedto' => "Filter by Assigned To",
			'tasks:filterbypriority' => "Filter by Priority",
			'tasks:filter' => "Filter",
			'tasks:all' => "All",
			
			'tasks:icon' => "Icon",
			'tasks:lastupdate' => "last updated",

		// CRUD Items

			'tasks:createtask' => "Create Task",
			'tasks:edittask' => "Edit Task",
			'tasks:deletetask' => "Delete Task",
			
			'tasks:delete:ask' => "Proceed with task deletion?",
			'tasks:delete:confirm' => "Confirm Delete?",
			
		// Success/Error Messages

			'tasks:success:saved' => "Successfully saved task",
			'tasks:success:deleted' => "Successfully deleted task",
			
			'tasks:error:deletetask' => "Failure deleting task",
			'tasks:error:objectnotfound' => "Error, object not found",
			'tasks:error:nameempty' => "Error, name parameter is empty",

	);
					
	add_translation("en",$english);

?>
