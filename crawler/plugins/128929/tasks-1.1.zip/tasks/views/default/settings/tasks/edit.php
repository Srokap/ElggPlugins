<?php
/**
 *	Tasks Plugin
 *	@package Tasks
 *	@author Liran Tal <liran@enginx.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 **/

	$assignedto = get_plugin_setting('configAssignedTo', 'tasks');
	if (!$assignedto) 
		$assignedto = 'person1, person2, person3';
	
	$priority = get_plugin_setting('configPriority', 'tasks');
	if (!$priority) 
		$priority = elgg_echo('tasks:priority:high').','.elgg_echo('tasks:priority:medium').','.
					elgg_echo('tasks:priority:low');
?>


<a title="PayPal - The safer, easier way to pay online." 
	href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&amp;hosted_button_id=5786512">
	<img border="0" src="https://www.paypal.com/en_GB/i/btn/btn_donate_SM.gif"/>
</a>

<p>
	<label>
	<?php echo elgg_echo('tasks:assignedto'); ?>
	<?php echo elgg_view('input/text', array('internalname' => 'params[configAssignedTo]',
												'value' => $assignedto,
												)); ?>
	<p class="description"><?php echo elgg_echo('tasks:settings:assignedto:helper') ?> </p>
	</label>
</p>

<p>
	<label>
	<?php echo elgg_echo('tasks:priority'); ?>
	<?php echo elgg_view('input/text', array('internalname' => 'params[configPriority]',
												'value' => $priority,
												)); ?>
	<p class="description"><?php echo elgg_echo('tasks:settings:priority:helper') ?> </p>
	</label>
</p>

