<?php
/**
 *	Tasks Plugin
 *	@package Tasks
 *	@author Liran Tal <liran@enginx.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 **/

$tasks = $vars['entity'];
$time_created = $vars['entity']->time_created;
$startdate = $vars['entity']->startdate;
$enddate = $vars['entity']->enddate;
$priority = $vars['entity']->priority;
$assignedto = $vars['entity']->assignedto;

if ( ($startdate) && ($enddate) ) {
	$isTaskOverdue = false;
	
	// task length calcs
	$dateDiffTask = (strtotime($enddate) - strtotime($startdate));
															// task length (unix timestamp)
	$taskLength = ($dateDiffTask/(60*60*24));				// task length in days
	
	// task due calcs
	$dateDiffDue = (strtotime($enddate) - time());		// deadline for the task (unix timestamp)
	// if task is overdue let's treat it this way
	if ($dateDiffDue < 0) {
		$isTaskOverdue = true;
		$dateDiffDue = (time() - strtotime($enddate));
	}
	
	$taskDue = floor($dateDiffDue/(60*60*24));			// task due in days, for an 'over due'
															// it is required to append the $taskOverDue string
	$taskDue .= " ".elgg_echo('tasks:days');
}

$icon = elgg_view(
		"tasks/icon", array(
		'entity' => $vars['entity'],
		'size' => 'small',
	  )
	);

$info .= "<p><b><a href=\"" . $vars['entity']->getUrl() . "\">" . $vars['entity']->title . "</a></b></p>";
//$info .= "<p><b>".elgg_echo('tasks:enddate')."</b>".$enddate.": </p>";



if ( (!$enddate) || (!$startdate) ) {
	$info .= "".
			"
			<div class='groupdetails'>
				<div class='search_listing_info_green'>
				<p>
					<b>".elgg_echo('tasks:enddate')."</b>: ".elgg_echo('tasls:unavailable')."
	
				</p></div>

			</div>
			<p>
				<b>".elgg_echo('tasks:priority')."</b>: ".$priority." 
			</p>
			<p>
				<b>".elgg_echo('tasks:assignedto')."</b>: ".$assignedto." 
			</p>
			";

} else {
	if ($isTaskOverdue) {
		$info .= "".
				"
				<div class='groupdetails'>

					<div class='search_listing_box_red'>
					<p>
						<b>".elgg_echo('tasks:enddate')."</b>: ".$enddate." 
						(<b>".elgg_echo('tasks:overdue')."</b>: $taskDue ".elgg_echo('tasks:days').")
					</p></div>
					
				</div>
				<p>
					<b>".elgg_echo('tasks:priority')."</b>: ".$priority." 
				</p>
				<p>
					<b>".elgg_echo('tasks:assignedto')."</b>: ".$assignedto." 
				</p>
				";
	} else {
		$info .= "".
				"
				<div class='groupdetails'>

					<div class='search_listing_box_green'>
					<p>
						<b>".elgg_echo('tasks:enddate')."</b>: ".$enddate." 
						(".elgg_echo('tasks:due').": $taskDue)
					</p></div>
				
				</div>
				<p>
					<b>".elgg_echo('tasks:priority')."</b>: ".$priority." 
				</p>
				<p>
					<b>".elgg_echo('tasks:assignedto')."</b>: ".$assignedto." 
				</p>
				";
	}
}
		
		
//$info .= "<p><b>".elgg_echo('tasks:startdate')."</b>".": ".($startdate)."</p>";
//$info .= "<p><b>".elgg_echo('tasks:priority')."</b>".$priority.": </p>";
$info .= "<p>".elgg_echo('tasks:lastupdate')." ".friendly_time($vars['entity']->time_created)."</p>";


echo elgg_view_listing($icon, $info);


?>
