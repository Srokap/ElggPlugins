<?php
/**
 *	Tasks Plugin
 *	@package Tasks
 *	@author Liran Tal <liran@enginx.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 **/

$tasks = $vars['entity'];
$time_created = $vars['entity']->time_created;

$icon = elgg_view(
		"tasks/icon", array(
		'entity' => $vars['entity'],
		'size' => 'small',
	  )
	);


$info .= "<p><b><a href=\"" . $vars['entity']->getUrl() . "\">" . $vars['entity']->title . "</a></b></p>";
$info .= "<p>".elgg_echo('tasks:lastupdate')." ".friendly_time($vars['entity']->time_created)."</p>";


echo elgg_view_listing($icon, $info);


?>
