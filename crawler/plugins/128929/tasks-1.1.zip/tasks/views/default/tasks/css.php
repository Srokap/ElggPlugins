<?php
/**
 *	Tasks Plugin
 *	@package Tasks
 *	@author Liran Tal <liran@enginx.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 **/
?>

.search_listing_box_green {
	display: table-cell;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	
	margin:0 10px 5px 10px;
	padding:1px;
	color:black;
}


.search_listing_box_red {
	display: table-cell;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;

	margin:0 10px 5px 10px;
	padding:1px;
	color:red;
}


<?php
/*
.search_listing_box_green {
	display: table-cell;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	background:green;
	margin:0 10px 5px 10px;
	padding:1px;
	color:white;
}


.search_listing_box_red {
	display: table-cell;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	background:red;
	margin:0 10px 5px 10px;
	padding:1px;
	color:white;
}
*/
?>

