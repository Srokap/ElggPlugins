<?php
/**
 *	Tasks Plugin
 *	@package Tasks
 *	@author Liran Tal <liran@enginx.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 *
 *  borrowed from Kevin Jardine's <kevin@radagast.biz> event calendar
 *  plugin. Works the same but with a different format type for the date
 *  for easy compatibility with PHP dates as well as to eliminate any
 *  dependency on the event calendar plugin. 
 **/
?>

<script language="javascript">
$(document).ready(function(){
$("#<?php echo $vars['internalname']; ?>").datepicker({
	dateFormat: "M d, yy",
    <?php 
		// dateFormat: "mm/dd/yy",
		// dateFormat: "DD, MM d, yy", 
	?> 
    showOn: "both", 
    buttonImage: "<?php echo $vars['url']; ?>mod/tasks/images/calendar.gif", 
    buttonImageOnly: true 
})
});
</script>
<input type="text" size="30" value="<?php echo $vars['value']; ?>" name="<?php echo $vars['internalname']; ?>" id="<?php echo $vars['internalname']; ?>"/>
