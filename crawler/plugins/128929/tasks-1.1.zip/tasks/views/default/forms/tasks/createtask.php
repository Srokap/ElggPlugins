<?php
/**
 *	Tasks Plugin
 *	@package Tasks
 *	@author Liran Tal <liran@enginx.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 **/
?>

<?php

	// get plugin settings of Assigned To field to fill options for selectbox
	$configAssignedTo = get_plugin_setting('configAssignedTo', 'tasks');
	$optionsAssignedTo = array();
	if ($configAssignedTo) {
		$optionsArray = explode(",", $configAssignedTo);
		foreach($optionsArray as $option) {
			$option = trim($option);
			$optionsAssignedTo[$option] = $option;
		}
	}

	// get plugin settings of Priority field to fill options for selectbox
	$configPriority = get_plugin_setting('configPriority', 'tasks');
	$optionsPriority = array();
	if ($configPriority) {
		$optionsArray = explode(",", $configPriority);
		foreach($optionsArray as $option) {
			$option = trim($option);
			$optionsPriority[$option] = $option;
		}
	}
?>	

<div class="contentWrapper">
<form action="<?php echo $vars['url']; ?>action/tasks/createtask" enctype="multipart/form-data" method="post">
 
<p>
	<label>
		<?php echo elgg_echo("tasks:name"); ?><br />
		<?php echo elgg_view('input/text', array('internalname' => 'name',
												'value' => $vars['entity']->name,
												)); ?>
		<p class="description"><?php echo elgg_echo('tasks:name:helper') ?> </p>
	</label>
</p>


<?php
	// get starting date if exist, otherwise we use today as the default
	if ($vars['entity']->startdate)
			$startingDate = $vars['entity']->startdate;
	else {
			$startingDate = date("M j, Y", time());
		}
?>

<p>
	<label>
		<?php echo elgg_echo("tasks:startdate"); ?><br />
		<?php echo elgg_view('input/datepicker_formatted', array('internalname' => 'startdate',
												'value' => $startingDate,
												)); ?>
		<p class="description"><?php echo elgg_echo('tasks:startdate:helper') ?> </p>
	</label>
</p>

<p>
	<label>
		<?php echo elgg_echo("tasks:enddate"); ?><br />
		<?php echo elgg_view('input/datepicker_formatted', array('internalname' => 'enddate',
												'value' => $vars['entity']->enddate,
												)); ?>
		<p class="description"><?php echo elgg_echo('tasks:enddate:helper') ?> </p>
	</label>
</p>

<p>
	<label>
		<?php echo elgg_echo("tasks:description"); ?><br />
		<?php echo elgg_view('input/longtext', array('internalname' => 'long_description',
												'value' => $vars['entity']->long_description,
												)); ?>
		<p class="description"><?php echo elgg_echo('tasks:description:helper') ?> </p>
	</label>
</p>

<p>
	<label>
		<?php echo elgg_echo("tasks:priority"); ?><br />
        <?php
                echo elgg_view('input/pulldown', array(
                        'internalname' => 'priority',
                        'options_values' => $optionsPriority,
                        'value' => $vars['entity']->priority
                ));
        ?>
	</label>
</p>

<p>
	<label>
		<?php echo elgg_echo("tasks:assignedto"); ?><br />
        <?php
                echo elgg_view('input/pulldown', array(
                        'internalname' => 'assignedto',
                        'options_values' => $optionsAssignedTo,
                        'value' => $vars['entity']->assignedto
                ));
        ?>
	</label>
</p>

<p>
	<label><?php echo elgg_echo("tasks:icon"); ?><br />
	<?php

		echo elgg_view("input/file",array('internalname' => 'icon'));
	
	?>
	</label>
</p>

<p>
	<label>
		<?php echo elgg_echo("tasks:tags"); ?><br />
		<?php echo elgg_view('input/tags', array('internalname' => 'tags',
												'value' => $vars['entity']->tags,
												)); ?>
	</label>
</p>

<p>
	<label>
		<?php echo elgg_echo("access"); ?><br />
		<?php echo elgg_view('input/access', array('internalname' => 'access',
												'value' => $vars['entity']->access_id,
												)); ?>
	</label>
</p>



<?php

	// if we're editing an existing task then we need to provide the object's guid
	if ($vars['entity']->guid)
		echo '<input type="hidden" name="object_guid" value="'.$vars['entity']->guid.'" />';
?>

<p><input type="submit" value="<?php echo elgg_echo('save'); ?>" /></p>
 
</form>
</div>
