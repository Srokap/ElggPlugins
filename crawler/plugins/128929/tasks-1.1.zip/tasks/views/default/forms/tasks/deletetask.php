<?php
/**
 *	Tasks Plugin
 *	@package Tasks
 *	@author Liran Tal <liran@enginx.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 **/
?>

<div class="contentWrapper">
<form action="<?php echo $vars['url']; ?>action/tasks/deletetask" enctype="multipart/form-data" method="post">

<p>
	<label>
		<?php echo elgg_echo("tasks:delete:ask"); ?><br />
	</label>
</p>


<?php
	// if we're editing an existing task then we need to provide the object's guid
	if ($vars['entity']->guid)
		echo '<input type="hidden" name="object_guid" value="'.$vars['entity']->guid.'" />';
?>

<p><input type="submit" value="<?php echo elgg_echo('delete'); ?>" /></p>
 
</form>
</div>
