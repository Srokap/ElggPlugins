<?php
/**
 *	Tasks Plugin
 *	@package Tasks
 *	@author Liran Tal <liran@enginx.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 **/
?>

<?php

	$id = $vars['entity']->guid;
	$title = $vars['entity']->title;
	
	$name = $vars['entity']->name;
	$long_description = $vars['entity']->long_description;
	$enddate = $vars['entity']->enddate;
	$startdate = $vars['entity']->startdate;
	$priority = $vars['entity']->priority;
	$assignedto = $vars['entity']->assignedto;
	$tags = implode(", ", $vars['entity']->tags);

	$taskDue = elgg_echo('task:unavailable');
	if ( ($startdate) && ($enddate) ) {
		$isTaskOverdue = false;
		
		// task length calcs
		$dateDiffTask = (strtotime($enddate) - strtotime($startdate));
																// task length (unix timestamp)
		$taskLength = ($dateDiffTask/(60*60*24));				// task length in days
		
		// task due calcs
		$dateDiffDue = (strtotime($enddate) - time());		// deadline for the task (unix timestamp)
		// if task is overdue let's treat it this way
		if ($dateDiffDue < 0) {
			$isTaskOverdue = true;
			$dateDiffDue = (time() - strtotime($enddate));
		}
		
		$taskDue = floor($dateDiffDue/(60*60*24));			// task due in days, for an 'over due'
																// it is required to append the $taskOverDue string
		$taskDue .= " ".elgg_echo('tasks:days');

	}

?>

<p>

<?php 
	// add side menu navigation links
	add_submenu_item(elgg_echo('tasks:edittask'), 
		$CONFIG->wwwroot."pg/tasks/".$_SESSION['user']->username."/edittask/".$id."/".$title);

	// add side menu navigation links
	add_submenu_item(elgg_echo('tasks:deletetask'), 
		$CONFIG->wwwroot."pg/tasks/".$_SESSION['user']->username."/deletetask/$id/$title");

	// add side menu navigation links
	add_submenu_item(elgg_echo('tasks:viewtasks'), 
	$CONFIG->wwwroot."pg/tasks/".$_SESSION['user']->username."/viewtasks/");

?>



<div id="groups_info_column_right">
    <div id="groups_icon_wrapper"><!-- start of groups_icon_wrapper -->
		<div class="groupicon">
			<a href="<?php echo $vars['entity']->getURL(); ?>" class="icon" >
				<img src="<?php echo $vars['entity']->getIcon('large'); ?>" border="0" />
			</a>
		</div>
	</div>
	
	<div id="group_stats"><!-- start of group_stats -->
		<p><b><?php echo elgg_echo('tasks:owner'); ?>: </b>
			<a href="<?php echo get_user($vars['entity']->owner_guid)->getURL(); ?>">
			<?php echo get_user($vars['entity']->owner_guid)->name ?></a>
		</p>
    </div><!-- end of group_stats -->

</div>



<div id="groups_info_column_left">

	<p class="odd"><b><?php echo elgg_echo('tasks:name'); ?>: </b>
	<?php echo $name; ?>
	</p>
	
	<p class="odd"><b><?php echo elgg_echo('tasks:description'); ?>: </b></p>
	<p> <?php echo $long_description; ?> </p>

	<p class="odd"><b><?php echo elgg_echo('tasks:assignedto'); ?>: </b>
	<?php echo $assignedto; ?>
	</p>

	<p class="odd"><b><?php echo elgg_echo('tasks:priority'); ?>: </b>
	<?php echo $priority; ?>
	</p>

	<p class="odd"><b><?php echo elgg_echo('tasks:startdate'); ?>: </b>
	<?php echo $startdate; ?>
	</p>
	
	<p class="odd"><b><?php echo elgg_echo('tasks:enddate'); ?>: </b>
	<?php echo $enddate; ?>
	</p>

	<p class="odd"><b><?php echo elgg_echo('tasks:taskdue'); ?>: </b>
	<?php echo $taskDue; ?>
	</p>

	<p class="odd"><b><?php echo elgg_echo('tasks:tags'); ?>: </b>
	<?php echo $tags; ?>
	</p>
	
</div>



<div id="groups_info_wide">
</div>




<div class="clearfloat"/>
</div>

</p>
