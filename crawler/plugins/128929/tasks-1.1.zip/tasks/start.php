<?php
/**
 *	Tasks Plugin
 *	@package Tasks
 *	@author Liran Tal <liran@enginx.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 **/
 
global $CONFIG;

/**
 * Tasks page handler
 *
 * @param array $page Array of page elements, forwarded by the page handling mechanism
 */
function tasks_page_handler($page) {
	global $CONFIG;
	
	// URLs $page array:
	//		0 = <username>
	//		1 = <action>
	//		2 = <entityId>
	//		3 = <entityTitle>
	// URLs Syntax Format:  /pg/tasks/<user>/<action>
	// URLs Syntax Example: /pg/tasks/lirantal/viewtasks
	
	// The first component of the URL is the username
	if (isset($page[0]) && $page[0]) {
		set_input('username',$page[0]);
	}
	
	// The second component of the URL is the action
	if (isset($page[1]) && $page[1]) {
		switch ($page[1]) {
			case "createtask":
				include(dirname(__FILE__) . "/createtask.php");
				break;
			case "deletetask":
				set_input('username', $page[0]);
				set_input('taskId', $page[2]);
				set_input('taskTitle', $page[3]);
				include(dirname(__FILE__) . "/deletetask.php");
				break;
			case "viewtasks":
				include(dirname(__FILE__) . "/viewtasks.php");
				break;
			case "edittask":
				set_input('username', $page[0]);
				set_input('taskId', $page[2]);
				set_input('taskTitle', $page[3]);			
				include(dirname(__FILE__) . "/edittask.php");
				break;
			case "viewtask":
				set_input('username', $page[0]);
				set_input('taskId', $page[2]);
				set_input('taskTitle', $page[3]);
				include(dirname(__FILE__) . "/viewtask.php");
				break;				
			default:
				include(dirname(__FILE__) . "/viewtasks.php");
				break;
		}
	} else {
		include(dirname(__FILE__) . "/viewtasks.php");
	}
	
	return true;
}



function tasks_url($entity) {

	global $CONFIG;

	// causes hebrew problems
	//$title = friendly_title($entity->question);
	$title = $entity->title;

	$userObj = get_user($entity->owner_guid);
	$username = $userObj->username;
	$id = $entity->guid;
	return $CONFIG->url . "pg/tasks/".$username."/viewtask/".$id."/".$title."/";
	
}


/**
 * This hooks into the getIcon API and provides nice user icons for users where possible.
 *
 * @param unknown_type $hook
 * @param unknown_type $entity_type
 * @param unknown_type $returnvalue
 * @param unknown_type $params
 * @return unknown
 */
function tasks_tasksicon_hook($hook, $entity_type, $returnvalue, $params)
{
	global $CONFIG;
	
	if ((!$returnvalue) && ($hook == 'entity:icon:url'))
	{
		$entity = $params['entity'];
		$type = $entity->type;
		$viewtype = $params['viewtype'];
		$size = $params['size'];
		
		if ($icontime = $entity->icontime) {
			$icontime = "{$icontime}";
		} else {
			$icontime = "default";
		}
		
		$filehandler = new ElggFile();
		$filehandler->owner_guid = $entity->owner_guid;
		$filehandler->setFilename("tasks/" . $entity->guid . $size . ".jpg");
		
		if ($filehandler->exists()) {
			$url = $CONFIG->url . "pg/tasksicon/{$entity->guid}/$size/$icontime.jpg";
		
			return $url;
		}
	}
}


/**
 * Handle object icons view icons.
 *
 * @param unknown_type $page
 */
function tasks_icon_handler($page) {
		
	global $CONFIG;
	
	// The username should be the file we're getting
	if (isset($page[0])) {
		set_input('object_guid',$page[0]);
	}
	if (isset($page[1])) {
		set_input('size',$page[1]);
	}
	// Include the standard profile index
	include($CONFIG->pluginspath . "tasks/graphics/icon.php");
	
}


function task_init() {
	global $CONFIG;
	// register a page handler for the /pg/ urls
	register_page_handler('tasks','tasks_page_handler');
	
	// sets up the URL handler for the object view 
	register_entity_url_handler('tasks_url', 'object', 'tasks');
	
	// Register an icon handler for this object
	register_page_handler('tasksicon','tasks_icon_handler');
	
	// Now override icons
	register_plugin_hook('entity:icon:url', 'object', 'tasks_tasksicon_hook');
	
	// extending css with more 
	extend_view('css', 'tasks/css');
	
	add_menu(elgg_echo('tasks:tasks'), $CONFIG->wwwroot . "pg/tasks/" . $_SESSION['user']->username);	
}

// plugin init hook
register_elgg_event_handler('init','system','task_init');

// register tasks CRUD
register_action("tasks/createtask", false, $CONFIG->pluginspath . "tasks/actions/createtask.php");
register_action("tasks/deletetask", false, $CONFIG->pluginspath . "tasks/actions/deletetask.php");

?>
