<?php
/**
 *	Tasks Plugin
 *	@package Tasks
 *	@author Liran Tal <liran@enginx.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 **/
 
set_context('Tasks');

$title = "Create Task";
$body = elgg_view('forms/tasks/createtask');
$body = elgg_view_layout('two_column_left_sidebar','', elgg_view_title($title) . $body);

echo page_draw($title, $body);
	
?>
