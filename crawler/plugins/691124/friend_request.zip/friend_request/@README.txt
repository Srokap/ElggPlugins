Use this piece of code into the index page of your theme to integrate friend_request (and also group requests).
Don't forget to add the corresponding block into the layout canvas OR attach string result to a valid area.


Example using $area8 :

// Current requests
// Demandes d'adhésion à des groupes
if (isloggedin()) {
  $area8 = "";
  $group_received_count = get_entities_from_relationship("invited", $_SESSION['user']->guid, true, "group", "", 0, "", 0, 0, true);
  $group_received_requests = get_entities_from_relationship("invited", $_SESSION['user']->guid, true, "group", "", 0, "", $group_received_count);
  $group_received = elgg_view("groups/received", array("entities" => $group_received_requests, "request_count" => $group_received_count));
  if($group_received_count > 0) { $area8 .= $group_received; }
  // Demandes de mises en relation
  if (is_plugin_enabled('friend_request')) {
    $user_received_count = get_entities_from_relationship('friendrequest', $_SESSION['guid'], true, 'user', '', 0, "", 10, 0, true);
    $user_received_requests = get_entities_from_relationship('friendrequest', $_SESSION['guid'], true, 'user', '', 0, "", 10, 0);
    $user_received = elgg_view('friend_request/entity_list', array(
        'entities' => $user_received_requests, 'count' => $user_received_count,
        'offset' => get_input('offset',0), 'limit' => get_input('limit',10),
        'baseurl' => $_SERVER['REQUEST_URI'], 'fullview' => false, 'context' => get_context(), 
        'viewtypetoggle' => false, 'viewtype' => get_input('search_viewtype','list'), 'pagination' => true
      ));
    if ($user_received_count > 0) $area8 .= '<h3 class="settings">' . sprintf(elgg_echo("friendrequests")) . '</h3>' . $user_received;
  }
}


//display the contents in our new canvas layout
$body = elgg_view_layout('formavia_index',$login, $files, $newest_members, $blogs, $groups, $bookmarks, $area7, $area8);

page_draw($title, $body);