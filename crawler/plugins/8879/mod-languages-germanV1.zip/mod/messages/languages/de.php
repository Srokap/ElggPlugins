<?php

	$german = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messages' => "Persönliche Posteingang",
            'messages:back' => "Zurück zum Posteingang",
			'messages:user' => "Dein Posteingang",
			'messages:sentMessages' => "Gesendete Nachrichten",
			'messages:posttitle' => "%s's Nachrichten: %s",
			'messages:inbox' => "Nachrichten Posteingang",
			'messages:send' => "Sende eine persönliche Nachricht",
			'messages:sent' => "Gesendete Nachrichten",
			'messages:message' => "Nachricht",
			'messages:title' => "Titel",
			'messages:to' => "An",
            'messages:from' => "Von",
			'messages:fly' => "Ab die Post...",
			'messages:replying' => "Antwort an",
			'messages:inbox' => "Nachrichten Posteingang",
			'messages:sendmessage' => "Sende eine persönliche Nachricht",
			'messages:compose' => "Sende eine persönliche Nachricht",
			'messages:sentmessages' => "Gesendete Nachrichten",
			'messages:recent' => "Neuste persönliche Nachrichten",
            'messages:original' => "Original Nachricht",
            'messages:yours' => "Deine Nachricht",
            'messages:answer' => "Antwort",
			
			'item:object:messages' => 'Persönliche Nachrichten',
	
		/**
		 * Status messages
		 */
	
			'messages:posted' => "Deine Nachricht wurde erfolgreich gesendet.",
			'messages:deleted' => "Die Nachricht wurde erfolgreich gelöscht.",
	
		/**
		 * Email messages
		 */
	
			'messages:email:subject' => 'Du hast eine neue persönliche Nachricht!',
			'messages:email:body' => "Du hast eine neue persönliche Nachricht %s. Es steht:

			
%s


Um die Nachricht anzusehen, klicke hier:

	%s

Um %s eine Nachricht zu senden, klicke hier:

	%s

Bitte nicht auf dieses E-Mail antworten.",
	
		/**
		 * Error messages
		 */
	
			'messages:blank' => "Du musst schon etwas schreiben =).",
			'messages:notfound' => "Diese Nachricht konnte leider nicht gefunden werden.",
			'messages:notdeleted' => "Diese Nachricht konnte leider nicht gelöscht werden.",
			'messages:nopermission' => "Diese Nachricht konnte leider nicht gelöscht werden, da du keine Berechtigung dazu hast.",
			'messages:nomessages' => "Es sind keine Nachrichten vorhanden.",
			'messages:user:nonexist' => "Der Empfänger konnte nicht gefunden werden.",
	
	);
					
	add_translation("de",$german);

?>