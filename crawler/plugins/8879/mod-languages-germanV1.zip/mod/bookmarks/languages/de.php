<?php

	$german = array(
	
		/**
		 * Menu items and titles
		 */
	
			'bookmarks' => "Bookmarks",
			'bookmarks:add' => "Bookmarke etwas",
			'bookmarks:read' => "Bookmarked Links",
			'bookmarks:friends' => "Bookmarks von Freunden",
			'bookmarks:everyone' => "Alle Bookmarks",
			'bookmarks:this' => "In die Bookmarks",
			'bookmarks:bookmarklet' => "Bookmarklet",
			'bookmarks:inbox' => "Bookmarks Eingang",
			'bookmarks:more' => "Mehr Bookmarks",
			'bookmarks:shareditem' => "Bookmarked Link",
			'bookmarks:with' => "Teilen mit",
	
			'bookmarks:address' => "Adresse",
	
			'bookmarks:delete:confirm' => "Willst du das wirklich löschen?",
	
			'bookmarks:shared' => "Bookmarked",
			'bookmarks:visit' => "Link anschauen",
			'bookmarks:recent' => "Neuste Bookmarks",
	
			'bookmarks:river:created' => '%s bookmarkte',
			'bookmarks:river:annotate' => '%s kommentierte',
			'bookmarks:river:item' => 'ein Link',
	
			'item:object:bookmarks' => 'Bookmarked Links',
	
	
		/**
		 * More text
		 */
		    
		    'bookmarks:widget:description' => 
		            "Widget für Startseite. Zeigt deine neusten Bookmarks.",
	
			'bookmarks:bookmarklet:description' =>
					"Das Bookmark-Bookmarklet hilft dir, Links direkt vom Browser in die Community zu speichern. Um es zu verwenden, musst du nur den folgenden Button in deine Link Bar ziehen:",

	        'bookmarks:bookmarklet:descriptionie' =>
					"Wenn du den Internet Explorer verwendest, musst du mit der rechten Maustast auf das Bookmarklet klicken und 'zu Favoriten hinzufügen' wählen.",

			'bookmarks:bookmarklet:description:conclusion' =>
					"Du kannst nun jede Seite Bookmarken indem du auf dieses Bookmarklet im Browser klickst.",
	
		/**
		 * Status messages
		 */
	
			'bookmarks:save:success' => "Der Link wurde erfolgreich den Bookmarks hinzugefügt.",
			'bookmarks:delete:success' => "Der Link wurde erfolgreich aus den Bookmarks gelöscht.",
	
		/**
		 * Error messages
		 */
	
			'bookmarks:save:failed' => "Der Link konnte leider nicht gespeichert werden.",
			'bookmarks:delete:failed' => "Der Link konnte leider nicht gelöscht werden.",
	
	
	);
					
	add_translation("de",$german);

?>