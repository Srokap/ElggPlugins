<?php

	$german = array(
	
		/**
		 * Menu items and titles
		 */
	
			'thewire' => "Kurznachrichten",
			'thewire:user' => "%s's Kurznachrichten",
			'thewire:posttitle' => "%s's Eintrag in den Kurznachrichten: %s",
			'thewire:everyone' => "Alle Kurznachrichten",
	
			'thewire:read' => "Deine Kurznachrichten",
			
			'thewire:strapline' => "%s",
	
			'thewire:add' => "Eintragen in Kurznachrichten",
		  'thewire:text' => "Eintrag in Kurznachrichten",
			'thewire:reply' => "Antwort",
			'thewire:via' => "via",
			'thewire:wired' => "Geschrieben in Kurznachrichten",
			'thewire:charleft' => "Zeichen übrig",
			'item:object:thewire' => "Kurznachrichten Einträge",
	
        /**
	     * Blog river
	     **/
	        
	        //generic terms to use
	        'thewire:river:created' => "%s schrieb",
	        
	        //these get inserted into the river links to take the user to the entity
	        'thewire:river:create' => "in den Kurznachrichten.",
	        
	    /**
	     * Wire widget
	     **/
	     
	        'thewire:sitedesc' => 'Alle neusten Kurznachrichten anzeigen',
	        'thewire:yourdesc' => 'Alle deine neusten Kurznachrichten anzeigen',
	        'thewire:friendsdesc' => 'Alle neuesten Kurznachrichten deiner Freunde anzeigen',
	        'thewire:friends' => 'Deine Frunden in den Kurznachrichten',
	        'thewire:num' => 'Anzahl Kurznachrichten anzeigen',
	        
	        
	
		/**
		 * Status messages
		 */
	
			'thewire:posted' => "Deine Kurznachricht wurde erfolgreich gespeichert.",
			'thewire:deleted' => "Deine Kurznachricht wurde erfolgreich gelöscht.",
	
		/**
		 * Error messages
		 */
	
			'thewire:blank' => "Es muss schon etwas geschrieben werden =).",
			'thewire:notfound' => "Diese Kurznachricht konnte nicht gefunden werden.",
			'thewire:notdeleted' => "Diese Kurznachricht konnte nicht gelöscht werden.",
	
	
		/**
		 * Settings
		 */
			'thewire:smsnumber' => "Your SMS number if different from your mobile number (mobile number must be set to public for the wire to be able to use it). All phone numbers must be in international format.",
			'thewire:channelsms' => "The number to send SMS messages to is <b>%s</b>",
			
	);
					
	add_translation("de",$german);

?>