<?php
	$german = array(
	    'everybody' => "Mitgliederliste",
	    'memberlist' => "Mitgliederliste",
	    'memberlistdescription' => "Finde deine Freunde...",
	);
					
	add_translation("de",$german);
?>
