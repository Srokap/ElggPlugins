<?php
	/**
	 * Mass Mail outs.
	 * 
	 * @package mass_mailouts
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Brucepro
	 * @copyright Brucepro 2008
	 * @link http://brucepro.net/
	 */

	$german = array(
	
		/**
		 * Menu items and titles
		 */
	
			'mass_mailouts' => 'Mailing',
			'mass_mailouts:email_text' => 'Nachricht:',
			'mass_mailouts:subject' => 'Betreff:',
			'mass_mailouts:success' => 'Das E-Mail wurde versendet.',

 			'mass_mailouts:failure' => 'Das E-Mail konnte leider nicht versendet werden.',

			'mass_mailouts:browse' => 'Durchsuchen ',
			'mass_mailouts:search' => 'Suchen',
			'mass_mailouts:user' => 'Nach Benutzername suchen',
			'mass_mailouts:starttime' => 'Startzeit (z.B. "last monday", "1 hour ago")',
			'mass_mailouts:endtime' => 'Endzeit',
	
			'mass_mailouts:explore' => 'Mailing durchsuchen',
	
	);
					
	add_translation("de",$german);
?>