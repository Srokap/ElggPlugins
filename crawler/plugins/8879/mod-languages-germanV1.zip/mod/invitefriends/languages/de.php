<?php

	/**
	 * Elgg invite page
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @link http://elgg.org/
	 */

	$german = array(

		'friends:invite' => 'Freunde einladen',
		'invitefriends:introduction' => 'Gib die E-Mail Adressen deiner Freunde ein, um sie zu dieser Community einzuladen (eine pro Zeile):',
		'invitefriends:message' => 'Schreib eine Nachricht für deine Freunde:',
		'invitefriends:subject' => 'Einladung um %s beizutreten',
	
		'invitefriends:success' => 'Deine Freunde wurden erfolgreich eingeladen.',
		'invitefriends:failure' => 'Deine Freunde konnten leider nicht eingeladen werden. Es trat ein Fehler auf.',
	
		'invitefriends:message:default' => '
Hallo

Ich möchte dich zur %s Community einladen.',
		'invitefriends:email' => '
Du wurdest von %s eingeladen, %s beizutreten. Folgende Nachricht wurde geschrieben:

%s

Um beizutreten, klicke auf folgenden Link:

	%s

Du wirst automatisch zum Freundesnetzwerk hinzugefügt.',
	
	);
					
	add_translation("de",$german);
?>