<?php
	/**
	 * Elgg tidypics plugin language pack
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$german = array(
			
		// Menu items and titles
			 
 			'image' => "Foto",
			'images' => "Fotos",
			'caption' => "Beschreibung",		
			'photos' => "Fotos",
			'images:upload' => "Fotos hinaufladen",
			'album' => "Foto Album",
			'albums' => "Foto Alben",
			'album:yours' => "Deine Foto Alben",
			'album:yours:friends' => "Foto Alben deiner Freunde",
			'album:user' => "%s's Fotos Album",
			'album:friends' => "Foto Alben von %s's Freunde",
			'album:all' => "Alle Foto Alben",
			'album:group' => "Gruppen Foto Alben",
	
		//actions
		
			'album:create' => "Neues Album",
			'album:add' => "Neues Foto Album",
			'album:addpix' => "Foto hinzufügen",		
			'album:edit' => "Album editieren",			
			'album:delete' => "Album löschen",		

			'image:edit' => "Foto bearbeiten",
			'image:delete' => "Foto löschen",
		
		//forms
		
			'album:title' => "Titel",
			'album:desc' => "Beschreibung",
			'album:tags' => "Tags",
			'album:cover' => "Foto als Album Cover?",
			'image:access:note' => "(Zugangsberechtigung wird von Album übernommen)",
			
		//views 
		
			'image:total' => "Fotos im Album:",
			'image:by' => "Foto hinzugefügt von",
			'album:by' => "Album erstellt von",
			'image:none' => "Es wurden noch keine Fotos hinzugefügt.",
			'image:back' => "Zurück",
			'image:next' => "Weiter",
		
		//widgets
		
			'album:widget' => "Foto Alben",
			'album:more' => "Alle Alben ansehen",
			'album:widget:description' => "Zeige deine neusten Foto Alben",
			'album:display:number' => "Wieviele Alben anzeigen?",
			'album:num_albums' => "Wieviele Alben anzeigen?",
			
		//  river
		
			//images
			'image:river:created' => "%s hinaufgeladen",
			'image:river:item' => "ein Foto",
			'image:river:annotate' => "%s kommentierte",	
		
			//albums
			'album:river:created' => "%s erstellt",
			'album:river:item' => "ein Album",
			'album:river:annotate' => "%s kommentierte",				
				
		//  Status messages
			
			'image:saved' => "Dein Foto wurde erfolgreich gespeichert.",
			'images:saved' => "Alle Fotos erfolgreich gespeichert.",
			'image:deleted' => "Das Foto wurde erfolgreich gelöscht.",			
			'image:delete:confirm' => "Willst du es wirklich löschen?",
			
			'images:edited' => "Deine Fotos wurden erfolgreich editiert.",
			'album:edited' => "Dein Album wurde erfolgreich editiert.",
			'album:created' => "Dein Album wurde erfolgreich erstellt.",
			'album:saved' => "Dein Album wurde erfolgreich gespeichert.",
			'album:deleted' => "Dein Album wurde erfolgreich gelöscht.",	
			'album:delete:confirm' => "Willst du es wirklich löschen?",
				
		//Error messages
				 
			'image:none' => "Es konnten leider keine Fotos gefunden werden.",
			'image:uploadfailed' => "Foto nicht hinaufgeladen:",
			'image:deletefailed' => "Das Foto konnte leider nicht gelöscht werden.",
			
			'image:notimage' => "Nur JPG, GIF oder PNG Fotos zugelassen.",
			'images:notedited' => "Es wurden nicht alle Fotos erfolgreich bearbeitet",
		 
			'album:none' => "Es konnten leider keine Foto Alben gefunden werden.",
			'album:uploadfailed' => "Das Album konnte leider nicht gespeichert werden.",
			'album:deletefailed' => "Das Album konnte leider nicht gelöscht werden.",
	
	);
					
	add_translation('de', $german);
?>
