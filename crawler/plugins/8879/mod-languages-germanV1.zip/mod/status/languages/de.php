<?php

	$german = array(
	
		/**
		 * Menu items and titles
		 */
	
			'status' => "Status",
			'status:user' => "%s's Status",
			'status:current'=> "Aktueller Status",
			'status:desc'=> "Dieses Status Widget zeigt dein momentaner Status.",
			'status:posttitle' => "%s's Status: %s",
			'status:everyone' => "Alle Statuser",
			'status:strapline' => "%s",
			'status:addstatus' => "Gib deinen Status an",
		  'status:messages' => "Status Nachrichten",
			'status:text' => "Status:",
			'status:set' => "gesetzt ",
			'status:clear' => "Status leeren",
			'status:delete' => "Status löschen",
			'status:nostatus' => "Es wurde kein Status angegeben.",
			'status:viewhistory' => "zurückblicken",
	
			'item:object:status' => 'Status Nachricht',
	
	
        /**
	     * Status river
	     **/
	        
	        //generic terms to use
	        'status:river:created' => "%s hat seinen",
	        
	        //these get inserted into the river links to take the user to the entity
	        'status:river:create' => "Status geändert.",
	        
	        
	
		/**
		 * Status messages
		 */
	
			'status:posted' => "Dein neuer Status wurde erfolgreich gesetzt.",
			'status:deleted' => "Dein Status wurde erfolgreich gelöscht.",
	
		/**
		 * Error messages
		 */
	
			'status:blank' => "Du musst schon etwas schreiben =).",
			'status:notfound' => "Dieser Status konnte leider nicht gefunden werden.",
			'status:notdeleted' => "Dieser Status konnte leider nicht gelöscht werden.",
			'status:notsaved' => "Dieser Status konnte leider nicht gespeichert werden.",
			'status:problem' => "Dieser Status konnte leider nicht geändert werden.",
	
	);
					
	add_translation("en",$german);

?>