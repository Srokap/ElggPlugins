<?php

	$german = array(
	
		/**
		 * Friends widget
		 */
			'friends:widget:description' => "Zeigt deine Freunde an.",
	        
		
	);
					
	add_translation("de",$german);

?>