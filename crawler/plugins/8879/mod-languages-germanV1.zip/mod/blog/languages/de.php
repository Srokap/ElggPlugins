<?php

	$german = array(
	
		/**
		 * Menu items and titles
		 */
	
			'blog' => "Blog",
			'blogs' => "Blogs",
			'blog:user' => "%s's -blog",
			'blog:user:friends' => "Blog von %s's Freunden",
			'blog:your' => "Dein Blog",
			'blog:posttitle' => "%s's Blog: %s",
			'blog:friends' => "Blogs deiner Freunde",
			'blog:yourfriends' => "Neuste Blogs deiner Freunde",
			'blog:everyone' => "Alle Blogs",
	
			'blog:read' => "Blog lesen",
	
			'blog:addpost' => "Einen Blog Eintrag schreiben",
			'blog:editpost' => "Blog Eintrag bearbeiten",
	
			'blog:text' => "Blog Text",
	
			'blog:strapline' => "%s",
			
			'item:object:blog' => 'Blog Einträge',
	
			
         /**
	     * Blog river
	     **/
	        
	        //generic terms to use
	        'blog:river:created' => "%s erstellte",
	        'blog:river:updated' => "%s aktualisierte",
	        'blog:river:posted' => "%s schrieb",
	        
	        //these get inserted into the river links to take the user to the entity
	        'blog:river:create' => "einen neuen Blog Eintrag.",
	        'blog:river:update' => "einen Blog Eintrag.",
	        'blog:river:annotate:create' => "ein Kommentar zu einem Blog Eintrag.",
			
	
		/**
		 * Status messages
		 */
	
			'blog:posted' => "Dein Blog Eintrag wurde erfolgreich gespeichert.",
			'blog:deleted' => "Dein Blog Eintrag wurde erfolgreich gelöscht.",
	
		/**
		 * Error messages
		 */
	
			'blog:save:failure' => "Dein Blog Eintrag konnte leider nicht gespeichert werden.",
			'blog:blank' => "Du musst schon etwas schreiben =).",
			'blog:notfound' => "Dieser Blog Eintrag konnte leider nicht gefunden werden.",
			'blog:notdeleted' => "Dieser Blog Eintrag konnte leider nicht gelöscht werden.",
	
	);
					
	add_translation("de",$german);

?>