<?php

	$german = array(
		"tagcloud:widget:title" => "Tag Cloud",
		"tagcloud:widget:description" => "Tag Cloud",
		"tagcloud:widget:notags" => "Anzahl Tags"
	);
					
	add_translation("de",$german);

?>
