<?php
	/**
	 * Elgg file plugin language pack
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$german = array(
	
		/**
		 * Menu items and titles
		 */
	
			'file' => "Dateien",
			'files' => "Dateien",
			'file:yours' => "Deine Dateien",
			'file:yours:friends' => "Dateien von deinen Freunden",
			'file:user' => "%s's Dateien",
			'file:friends' => "Dateien von %s's Freunden",
			'file:all' => "Alle Dateien",
			'file:edit' => "Date bearbeiten",
			'file:more' => "mehr Dateien",
			'file:list' => "Listen Ansicht",
			'file:group' => "Gruppen Dateien",
			'file:gallery' => "Gallerie Ansicht",
			'file:gallery_list' => "Gallerie oder Listen Ansicht",
			'file:num_files' => "Anzahl Dateien",
			'file:user:gallery'=>'%s Gallerie anzeigen', 
	
			'file:upload' => "Datei hinaufladen",
			
			'file:file' => "Datei",
			'file:title' => "Titel",
			'file:desc' => "Beschreibung",
			'file:tags' => "Tags",
	
			'file:types' => "Hinaufgeladene Datei Typen",
	
			'file:type:all' => "Alle Dateien",
			'file:type:video' => "Video",
			'file:type:document' => "Dokument",
			'file:type:audio' => "Musik",
			'file:type:image' => "Bild",
			'file:type:general' => "Diverse",
	
			'file:user:type:video' => "%s's Videos",
			'file:user:type:document' => "%s's Dokumente",
			'file:user:type:audio' => "%s's Musik",
			'file:user:type:image' => "%s's Bilder",
			'file:user:type:general' => "%s's diverse Dateien",
	
			'file:friends:type:video' => "Videos deiner Freunde",
			'file:friends:type:document' => "Dokumente deiner Freunde",
			'file:friends:type:audio' => "Musik deiner Freunde",
			'file:friends:type:image' => "Bilder deiner Freunde",
			'file:friends:type:general' => "Diverse Dateien deiner Freunde",
	
			'file:widget' => "Dateien",
			'file:widget:description' => "Zeige deine neusten Dateien",
	
			'file:download' => "Diese Datei herunterladen",
	
			'file:delete:confirm' => "Willst du diese Datei wirklich löschen",
			
			'file:tagcloud' => "Tag cloud",
	
			'file:display:number' => "Anzahl Dateien",
	
			'file:river:created' => "%s hat eine Datei",
			'file:river:item' => "hinaufgeladen",
			'file:river:annotate' => "%s schrieb einen Kommentar zu",

			'item:object:file' => 'Dateien',
			
	    /**
		 * Embed media
		 **/
		 
		    'file:embed' => "Datei einbetten",
		    'file:embedall' => "Alle",
	
		/**
		 * Status messages
		 */
	
			'file:saved' => "Deine Datei wurde erfolgreich gespeichert.",
			'file:deleted' => "Deine Datei wurde erfolgreich gelöscht.",
	
		/**
		 * Error messages
		 */
	
			'file:none' => "Es konnten leider keine Dateien gefunden werden.",
			'file:uploadfailed' => "Die Datei konnte leider nicht gespeichert werden.",
			'file:downloadfailed' => "Die Datei ist Zurzeit nicht verfügbar.",
			'file:deletefailed' => "Deine Datei konnte leider nicht gelöscht werden.",
	
	);
					
	add_translation("de",$german);
?>