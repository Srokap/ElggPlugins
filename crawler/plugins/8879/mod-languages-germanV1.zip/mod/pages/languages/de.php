<?php
	/**
	 * Elgg pages plugin language pack
	 * 
	 * @package ElggPages
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$german = array(
	
		/**
		 * Menu items and titles
		 */
			
			'pages' => "Seiten",
			'pages:yours' => "Deine Seiten",
			'pages:user' => "Seiten Übersicht",
			'pages:group' => "%s's Seiten",
			'pages:all' => "Alle Seiten",
			'pages:new' => "Neue Seite",
			'pages:groupprofile' => "Gruppen Seiten",
			'pages:edit' => "Diese Seite bearbeiten",
			'pages:delete' => "Diese Seite löschen",
			'pages:history' => "Seitenvergangenheit",
			'pages:view' => "Seite ansehen",
			'pages:welcome' => "Willkommensnachricht bearbeiten",
			'pages:welcomeerror' => "Die Willkommensnachricht konnte leider nicht gespeichert werden",
			'pages:welcomeposted' => "Die Willkommensnachricht wurde gespeichert",
			'pages:navigation' => "Seiten Navigation",
	
			'item:object:page_top' => 'Top-level Seiten',
			'item:object:page' => 'Seiten',
			'item:object:pages_welcome' => 'Seiten Willkommensblock',
	
	
		/**
		 * Form fields
		 */
	
			'pages:title' => 'Seitentitel',
			'pages:description' => 'Dein Seiten Eintrag',
			'pages:tags' => 'Tags',	
			'pages:access_id' => 'Zugang',
			'pages:write_access_id' => 'Schreibberechtigung',
		
		/**
		 * Status and error messages
		 */
			'pages:noaccess' => 'Kein Zugang zur Seite',
			'pages:cantedit' => 'Du kannst diese Seite nicht bearbeiten',
			'pages:saved' => 'Seiten gespeichert',
			'pages:notsaved' => 'Seite konnte leider nicht gespeichert werden',
			'pages:notitle' => 'Du musst einen Titel angeben.',
			'pages:delete:success' => 'Seite wurde erfolgreich gelöscht.',
			'pages:delete:failure' => 'Die Seite konnte leider nicht gelöscht werden.',
	
		/**
		 * Page
		 */
			'pages:strapline' => 'Letztes Update am %s von %s',
	
		/**
		 * History
		 */
			'pages:revision' => 'Revision erstellt am %s von %s',
			
		/**
		 * Wdiget
		 **/
		 
		    'pages:num' => 'Anzahl Seiten anzeigen',
	
		/**
		 * Submenu items
		 */
			'pages:label:view' => "Seite anzeigen",
			'pages:label:edit' => "Seite bearbeiten",
			'pages:label:history' => "Seitenvergangeneheit",
	
		/**
		 * Sidebar items
		 */
			'pages:sidebar:this' => "Diese Seite",
			'pages:sidebar:children' => "Unterseiten",
			'pages:sidebar:parent' => "Oberseite",
	
			'pages:newchild' => "Eine Unterseite erstellen",
			'pages:backtoparent' => "Zurück zu '%s'",
	);
					
	add_translation("de",$german);
?>