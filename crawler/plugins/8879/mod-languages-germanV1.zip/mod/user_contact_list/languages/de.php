<?php
	/**
	 * User Contact List - Plugin
	 * 
	 * @package User Contact List
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Michael T Jones
	 * @copyright Michael T Jones 2008
	 * @link http://www.facebake.com/
	 */

$german = array(
		'userclist:title' => 'Benutzerliste',
		'userclist:lastpage' => '<< Letzte Seite',
		'userclist:nextpage' => 'Nächste Seite >>',
		'userclist:totalpages' => 'Total Benuter:',
		'userclist:onpage1' => 'Seite',
		'userclist:onpage2' => 'von',
		'userclist:onpage3' => 'Seiten',
		);

add_translation("de",$german);
?>