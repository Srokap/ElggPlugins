<?php

	$german = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messageboard:board' => "Gästebuch",
			'messageboard:messageboard' => "Gästebuch",
			'messageboard:viewall' => "Alle anzeigen",
			'messageboard:postit' => "schreiben",
			'messageboard:history' => "alte Einträge",
			'messageboard:none' => "Das Gästebuch hat noch keinen Eintrag",
			'messageboard:num_display' => "Anzahl Einträge anzeigen",
			'messageboard:desc' => "Das ist ein Gästebuch. Du kannst das deinem Profil hinzufügen.",
			
         /**
	     * Message board widget river
	     **/
	        
	        'messageboard:river:annotate' => "%s hat im eigenen Gästebuch einen neuen Eintrag Gästebuch geschrieben.",
	        'messageboard:river:create' => "%s hat das Gästebuch Widget seinem Profil hinzugefügt.",
	        'messageboard:river:update' => "%s hat sein Gästebuch Widget geändert.",
			
		/**
		 * Status messages
		 */
	
			'messageboard:posted' => "Dein Eintrag im Gästebuch wurde erfolgreich erstellt.",
			'messageboard:deleted' => "Der Eintrag wurde erfolgreich gelöscht.",
	
		/**
		 * Email messages
		 */
	
			'messageboard:email:subject' => 'Du hast einen neuen Gästebuch Eintrag!',
			'messageboard:email:body' => "Du hast einen neuen Gästebuch Eintrag von %s. Es steht:

			
%s


Um dein Gästebuch Eintrag anzuzeigen, klicke hier:

	%s

Um das Profil von %s anzuzeigen, klicke hier:

	%s

Bitte nicht auf dieses E-Mail antworten.",
	
		/**
		 * Error messages
		 */
	
			'messageboard:blank' => "Du musst schon etwas schreiben =).",
			'messageboard:notfound' => "Dieser Gästebuch Eintrag konnte leider nicht gefunden worden.",
			'messageboard:notdeleted' => "Dieser Gästebuch Eintrag konnte leider nicht gelöscht werden.",
	     
			'messageboard:failure' => "Dein Gästebuch Eintrag konnte leider nicht geschrieben werden, es ist ein Fehler aufgetreten.",
	
	);
					
	add_translation("de",$german);

?>