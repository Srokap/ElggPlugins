<?php
  
	echo '	<link rel="stylesheet" type="text/css" href="'. $vars['url'] . 'mod/hu_skawa_genusers/js/1.7/css/redmond/jquery-ui-1.7.3.custom.css" />'.PHP_EOL;
	echo '	<link rel="stylesheet" type="text/css" href="'. $vars['url'] . 'mod/hu_skawa_genusers/css/progressbar.css" />'.PHP_EOL;
	echo '	<link rel="stylesheet" type="text/css" href="'. $vars['url'] . 'mod/hu_skawa_genusers/css/genusers.css" />'.PHP_EOL;
 	echo '	<script type="text/javascript" src="'. $vars['url'] . 'mod/hu_skawa_genusers/js/1.7/js/jquery.tabs.js" ></script>'.PHP_EOL; 
 	echo '	<script type="text/javascript" src="'. $vars['url'] . 'mod/hu_skawa_genusers/js/Timer.js" ></script>'.PHP_EOL; 
 	echo '	<script type="text/javascript" src="'. $vars['url'] . 'mod/hu_skawa_genusers/js/jquery.form.js" ></script>'.PHP_EOL; 
 	echo '	<script type="text/javascript" src="'. $vars['url'] . 'mod/hu_skawa_genusers/js/1.7/jquery.progressbar/js/jquery.progressbar.js" ></script>'.PHP_EOL; 
 
?>
