<?php
	/**
	 * Create a input button
	 * Use this view for forms rather than creating a submit/reset button tag in the wild as it provides
	 * extra security which help prevent CSRF attacks.
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.org/
	 * 
	 * @uses $vars['value'] The current value, if any
	 * @uses $vars['js'] Any Javascript to enter into the input tag
	 * @uses $vars['internalname'] The name of the input field
	 * @uses $vars['type'] Submit or reset, defaults to submit.
	 * @uses $vars['src'] Src of an image
	 * 
	 */

	global $CONFIG;
	
	if (isset($vars['class'])) $class = $vars['class'];
	if (!$class) $class = "submit_button";

	if (isset($vars['type'])) { $type = strtolower($vars['type']); } else { $type = 'submit'; }
	switch ($type)
	{
		case 'button' : $type='button'; break;
		case 'reset' : $type='reset'; break;
		case 'submit':
		default: $type = 'submit';
	}
	
	$value = htmlentities($vars['value'], null, 'UTF-8');
	if (isset($vars['internalname'])) $name = $vars['internalname'];
	if (isset($vars['internalid'])) $id = $vars['internalid'];
	if (isset($vars['src'])) $src = $vars['src'];
	if (strpos($src,$vars['url'])===false) $src = ""; // blank src if trying to access an offsite image.
?>
<input id="<?php echo $id; ?>" type="<?php echo $type; ?>" class="<?php echo $type; ?>_button" <?php echo $vars['js']; ?> value="<?php echo $value; ?>" src="<?php echo $src; ?>" />