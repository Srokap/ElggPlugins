<?php
/**
 * Elgg header contents
 * This file holds the header output that a user will see
 *
 * @package Elgg
 * @subpackage Core
 * @author Curverider Ltd
 * @link http://elgg.org/
 **/

?>

<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/theme_666/js/ddsmoothmenu.js">
/***********************************************
* Smooth Navigational Menu- (c) Dynamic Drive DHTML code library (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit Dynamic Drive at http://www.dynamicdrive.com/ for full source code
***********************************************/
</script>

<div id="layout_header">
<div id="wrapper_header">

<!-- display the logo image -->
<h1><a href="<?php echo $vars['url']; ?>"><img src="<?php echo $vars['url']; ?>mod/theme_666/graphics/logo.png"></a></h1>


<?php
	if (isloggedin()) {
?>
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/theme_666/js/config.js"></script>	
	<div id="elgg_topbar_container_left">
		<div class="toolbarlinks2">	
		<?php
		//allow people to extend this top menu
		echo elgg_view('elgg_topbar/extend', $vars);
		?>
		<a href="<?php echo $vars['url']; ?>pg/settings/" class="usersettings"><?php echo elgg_echo('settings'); ?></a>

		<?php

			// The administration link is for admin or site admin users only
			if ($vars['user']->isAdmin()) {

		?>

			<a href="<?php echo $vars['url']; ?>pg/admin/" class="usersettings"><?php echo elgg_echo("admin"); ?></a>

		<?php

				}

		?>
		</div>	
	
	</div>
<?php
	}
?>
</div><!-- /#wrapper_header -->
</div><!-- /#layout_header -->
<?php
	if (isloggedin()) {
?>

<div id="menu_top">

<div id="menu_nav">
<div id="smoothmenu" class="ddsmoothmenu">
<ul>

	<li><a href="<?php echo $vars['url']; ?>pg/dashboard/"><?php echo elgg_echo('dashboard'); ?></a></li>
	
	<li><a href="<?php echo $_SESSION['user']->getURL(); ?>">Profile</a>
		<ul>
		<li><a href="<?php echo $vars['url']; ?>mod/profile/edit.php?username=<?php echo $_SESSION['user']->username; ?>">Edit Profile</a></li>
		<li><a href="<?php echo $vars['url']; ?>pg/profile/<?php echo $_SESSION['user']->username; ?>/editicon/">Edit Profile picture</a></li>
		</ul>
	</li>	
	
	<li><a href="<?php echo $vars['url']; ?>pg/messageboard/<?php echo $_SESSION['user']->username; ?>"><?php echo elgg_echo("Messageboard"); ?></a></li>
	<li><a href="<?php echo $vars['url']; ?>pg/photos/world/">Photos</a>
		<ul>
		<li><a href="<?php echo $vars['url']; ?>pg/photos/owned/<?php echo $_SESSION['user']->username ?>">My Photos</a></li>
		<li><a href="<?php echo $vars['url']; ?>pg/photos/friends/<?php echo $_SESSION['user']->username ?>">Friends Photo Albums</a></li>
		<li><a href="<?php echo $vars['url']; ?>pg/photos/mostrecent">Recent Photos</a></li>
		<li><a href="<?php echo $vars['url']; ?>pg/photos/new/<?php echo $_SESSION['user']->username ?>">New Photo Album</a></li>  
		</ul>
	</li>	
	
	<li><a href="<?php echo $vars['url']; ?>pg/izap_videos">Videos</a>
		<ul>
		<li><a href="<?php echo $vars['url']; ?>pg/izap_videos/<?php echo $_SESSION['user']->username ?>">My Videos</a></li>
		<li><a href="<?php echo $vars['url']; ?>pg/izap_videos/<?php echo $_SESSION['user']->username ?>/frnd">My Friends Videos</a></li>
		<li><a href="<?php echo $vars['url']; ?>pg/izap_videos/<?php echo $_SESSION['user']->username ?>/add">Add New Video</a></li>
		</ul>
	</li>
	<li><a href="<?php echo $vars['url']; ?>pg/groups/world/">Groups</a>
		<ul>
		<li><a href="<?php echo $vars['url']; ?>pg/groups/member/<?php echo $_SESSION['user']->username ?>">My Groups</a></li>
        <li><a href="<?php echo $vars['url']; ?>pg/groups/new/">Create New Group</a></li>
		</ul>
	</li>	
	
</ul>
<?php

			echo elgg_view("navigation/topbar_tools");

		?>

<br style="clear: left" />
</div>

<div id="elgg_topbar_container_search">
<?php echo elgg_view('page_elements/searchbox'); ?>
</div> 
<div id="elgg_topbar_container_right">
		<small>
			<?php echo elgg_view('output/url', array('href' => "{$vars['url']}action/logout", 'text' => elgg_echo('logout'), 'is_action' => TRUE)); ?>
		</small>
</div>
</div>
<?php
	}
?>
<div id="header_bottom"></div>
<div id="page_container">
<div id="page_wrapper">