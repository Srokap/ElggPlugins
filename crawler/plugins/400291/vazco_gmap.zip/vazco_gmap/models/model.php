<?php 
	require_once(dirname(__FILE__)."/location.php");
	require_once(dirname(__FILE__)."/reverse_geocode.php");
	require_once(dirname(__FILE__)."/profilemanager.php");
	
/**
 *
 * @global Array $CONFIG
 * @param Array $meta_array Is a multidimensional array with the list of
metadata to filter.
 * For each metadata you have to provide 3 values:
 * - name of metadata
 * - value of metadata
 * - operand ( <, >, <=, >=, =, like)
 * For example
 *      $meta_array = array(
 *              array(
 *                  'name'=>'my_metadatum',
 *                  'operand'=>'>=',
 *                  'value'=>'my value'
 *              )
 *      )
 * @param String $entity_type
 * @param String $entity_subtype
 * @param Boolean $count
 * @param Integer $owner_guid
 * @param Integer $container_guid
 * @param Integer $limit
 * @param Integer $offset
 * @param String $order_by "Order by" SQL string. If you want to sort by
metadata string,
 * possible values are vN.string, where N is the first index of $meta_array,
 * hence our example is $order by = 'v1.string ASC'
 * @param Integer $site_guid
 * @return Mixed Array of entities or false
 *
 */
function vazco_gmap_get_entities_from_metadata_by_relationship(
	$meta_array
	,$entity_type = ""
	,$entity_subtype = ""
	,$count = false
	,$owner_guid = 0
	,$container_guid = 0
	,$limit = 10
	,$offset = 0
	,$order_by = ""
	,$site_guid = 0,
	$order_by_relationship = false,
	$inverse_relationship = true)
    {
        global $CONFIG;
		return false;
    }
?>