<?php 
class vazco_profile_field{
	public $field;
	public $name;
	public function getOptions(){
		$options = explode(',',$this->field->metadata_options);
		foreach($options as $option){
			$option = trim($option);
		}
		return $options;
	}
	
	public function vazco_profile_field($name){
		$this->name = $name;
		$fieldsArray = get_entities_from_metadata("metadata_name", $name, "object", CUSTOM_PROFILE_FIELDS_PROFILE_SUBTYPE);
   		$this->field = $fieldsArray[0];
	}
}
?>