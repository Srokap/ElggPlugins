<?php 

class vazco_gmap{
	function getPoint($entity){
		$point = "({$entity->getLatitude()}, {$entity->getLongitude()})";
		return $point;
	}
	
	public function parseLocationString($location){
		$pattern = '/\([ \t]*([\+\-]?[0-9]+(\.[0-9]*)?)[ \t]*,[ \t]*([\+\-]?[0-9]+(\.[0-9]*)?)[ \t]*\)/';
		if (preg_match($pattern, trim($vars['location']), $matches)) {
		  $lat = (float)$matches[1];
		  $lng = (float)$matches[3];
		  $location = "{lat:$lat,lng:$lng}";
		}
		return $location;
	}
}
	/*
  	 * @package Elgg
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Michal Zacher [michal.zacher@gmail.com]
	 * @remarks In case you need any help with this plugin, geocoding or reverse geocoding, please contact me and I may be able to help.
	*/

	//set the default parameters for the location array and pass it to request
	function set_location_in_request($currLocation, $zoom, $elementId, $canEdit = true, $controls = 'GLargeMapControl3D'){
		//if zoom or location not provided, set them to default
		$zoom = isset($zoom)?$zoom:GMAP_DEFAULT_ZOOM;
		$focus_on_location = $_SESSION['VAZCO_GMAP_DEFAULT_LOCATION'];
		if (isset($currLocation) && $currLocation != '')
			$focus_on_location = $currLocation;

		$location = create_location_table($focus_on_location, $zoom,$elementId, $canEdit);
		//change the canedit to int to avoid type misinterpretation
		if (!$canEdit)
			$canEdit = 0;
		else
			$canEdit = 1;
		$location['canEdit']			= $canEdit;

		if (!isset($_REQUEST['location_edit_maps']))
			$_REQUEST['location_edit_maps'] = array();
		array_push($_REQUEST['location_edit_maps'], $location);
				
		return $location;
	}
	
	function create_location_table($focus_on_location, $zoom, $internalName, $canEdit = false, $vars = null){
		global $CONFIG;
		//set unique prefix for the element
		$prefix			= 'vgmap-'.$internalName;
		if ($canEdit)
			$prefix .= "-e";


		//create links for AJAX. Those links need to be unique, that's why we use prefix.

		//TODO: we could check in request if element with given ID not exists. If it does, change it's ID. This would help when
		//two edits for one parameter would appear on one page. Still, giving two edits on one page would cause other problems probably, so should be avoided anyway.
		$location = array();
		$location['location'] 			= $focus_on_location;
		$location['zoom'] 				= $zoom;
		$location['prefix'] 			= $prefix;
		$location['eid']				= $prefix.'-eid';
		$location['elementId'] 			= $prefix.'-edit';
		$location['addressElementId'] 	= $prefix.'-addr-edit';
		$location['linkId'] 			= $prefix.'-link';
		$location['jumpId']				= $prefix.'-jump';
		$location['addressId']			= $prefix.'-addr';
		
		
		if ($vars['controls'])
			$location['controls'] 			= $vars['controls'];
		else
			$location['controls'] 			= 'GLargeMapControl3D';

		if ($vars['entitylink'])
			$location['entitylink'] = $vars['entitylink'];
		else
			$location['entitylink']				= $CONFIG->wwwroot.'mod/vazco_gmap/viewentity.php';

		if ($vars['listlink'])
			$location['listlink'] = $vars['listlink'];
		else
			$location['listlink']				= $CONFIG->wwwroot.'mod/vazco_gmap/listentities.php';

		$location['listparams'] = "";
		if ($vars['listparams'])
			$location['listparams'] = $vars['listparams'];
			
		$location['mapparams'] = "";
		if ($vars['mapparams'])
			$location['mapparams'] = $vars['mapparams'];
			
		$location['entityparams'] = "";
		if ($vars['entityparams'])
			$location['entityparams'] = $vars['entityparams'];
		
		if ($vars['zoom'])
			$location['zoom'] = $vars['zoom'];
			
		$location['listviewtype'] = "list";
		if ($vars['listviewtype'])
			$location['listviewtype'] = $vars['listviewtype'];
		return $location;
	}	
	
	function user_cache_location_all($limit = 100, $offset = 0){
		$users = get_entities("user","",0,"",$limit,$offset,false);		
		foreach ($users as $user){
			user_cache_location($user,5);
		}
	}
	
	//set address, latitude and longitude based on user's location field
	function user_cache_location($object, $timeout = 5){
		if (($object) && ($object instanceof ElggUser)) {
			$location = $object->location;//get_input('location');
			if ($location && $location != ''){
				$longlatString = get_longlat_string($location);
				$longlat_array =  split(",", $longlatString);

				$longitude = $longlat_array[1];
				$latitude = $longlat_array[0];
				$address = get_address($longlatString, $timeout);
				
				$locMetadata = get_metadata_byname($object->guid, 'location');
				$access = $locMetadata->access_id;

				$user = $object;
				$user->setLatLong($latitude, $longitude);
				$_SESSION['VAZCO_GMAP_DEFAULT_LOCATION'] = $address;
				$user->save();
				if ($address)
					create_metadata($object->guid, 'vaz_addr', $address,'', $object->guid, $access);
				return true;
			}
		}
		return false;
	}

	//latitude and longitude based on user's location field
	function entity_cache_location($object, $location = null, $timeout = 5){
		if (($object)) {
			//by default set location's address access to public
			$access = ACCESS_PUBLIC;
			if ($location == null){
				$location = $object->location;
				$locMetadata = get_metadata_byname($object->guid, 'location');
				$access = $locMetadata->access_id;
			}

			if ($location && $location != ''){
				$object->location = $location;
				
				$longlatString = get_longlat_string($location);
				$longlat_array =  split(",", $longlatString);

				$longitude = $longlat_array[1];
				$latitude = $longlat_array[0];
				$address = get_address($longlatString, $timeout);
				
				$object->setLatLong($latitude, $longitude);

				$object->save();
				if ($address)
					create_metadata($object->guid, 'vaz_addr', $address,'', $object->guid, $access);
				return true;
			}
		}
		return false;
	}
	
	function vazco_gmap_elgg_view_entities($entities, $type = null, $view="xml"){
		$content = "";
		switch($view){
			case "xml":
				$content = vazco_gmap_wrap_xml(vazco_gmap_elgg_view_entities_xml($entities, $type));
				break;
			case "xml-element":
				$content = vazco_gmap_elgg_view_entities_xml($entities, $type);
				break;				
			case "list":				
				$content = vazco_gmap_elgg_view_entities_list($entities, $type);
				break;
			case "galleryview":
				$content = vazco_gmap_elgg_view_entities_gallery($entities, $type);
				$content .= "<div class='clearfloat'></div>";
				break;	
			default:
				register_error('wrong viewtype: '.$view);
				break;
		}
		return $content;		
	}
	/**
	 * Return XML document with entities
	 *
	 */
	function vazco_gmap_wrap_xml($content){
		$document = '<?xml version="1.0" encoding="UTF-8" ?>';
		$document .= '<entities>';
		$document .= $content;
		$document .= '</entities>';
		return $document;	
	}

	/*
	 * Convert element to XML
	 * */
	function vazco_gmap_elgg_view_entities_xml($entities, $type = null){
		foreach ($entities as $entity){
			if (!$type)
				$type = $entity->getType();
			$document .= elgg_view('vazco_gmap/map/xml/'.$type,array('entity'=>$entity));
		}
		return $document;
	}
	/**
	 * Return list of entities with links to the map
	 *
	 */
	function vazco_gmap_elgg_view_entities_list($entities, $type = null, $showLocation = false){
		
		$document = "";
		foreach ($entities as $entity){
			if (!$type)
				$type = $entity->getType();
			$document .= elgg_view('vazco_gmap/map/listview/'.$type,array('entity'=>$entity, 'showLocation' => $showLocation));
		}
		return $document;
	}
	
	function vazco_gmap_elgg_view_entities_gallery($entities, $type = null, $showLocation = false){
		$document = "";
		foreach ($entities as $entity){
			if (!$type)
				$type = $entity->getType();
			$document .= elgg_view('vazco_gmap/map/galleryview/'.$type,array('entity'=>$entity, 'showLocation' => $showLocation));
		}
		return $document;
	}	
	
	function vazco_escape_xml_string($string){
		return str_replace('&','&amp;',$string);
	}
	
	function vazco_unescape_xml_string($string){
		return str_replace('&amp;','&',$string);
	}

	function vazco_get_entities_in_area_by_relationship($lat_max, $long_max, $lat_min, $long_min, $relationship = "friend", $inverse_relationship, $user_guid = 0, $order_by = "", $limit = 10, $offset = 0, $count = false, $site_guid = 0, $container_guid)
	{
		$type = "user";
		$subtype = ""; 
		global $CONFIG;
		//how much map should be loaded around the borders
		$safetyRadius = 0;
		
		$lat_max = $lat_max + $safetyRadius;
		$lat_min = $lat_min - $safetyRadius;
		$long_max = $long_max + $safetyRadius;
		$long_min = $long_min - $safetyRadius;
		
		if ($subtype === false || $subtype === null || $subtype === 0)
			return false;

		$order_by = sanitise_string($order_by);
		$limit = (int)$limit;
		$offset = (int)$offset;
		$site_guid = (int) $site_guid;
		if ($site_guid == 0)
			$site_guid = $CONFIG->site_guid;
			
		$where = array();
		
		if (is_array($type)) {			
			$tempwhere = "";
			if (sizeof($type))
			foreach($type as $typekey => $subtypearray) {
				foreach($subtypearray as $subtypeval) {
					$typekey = sanitise_string($typekey);
					if (!empty($subtypeval)) {
						$subtypeval = (int) get_subtype_id($typekey, $subtypeval);
					} else {
						$subtypeval = 0;
					}
					if (!empty($tempwhere)) $tempwhere .= " or ";
					$tempwhere .= "(e.type = '{$typekey}' and e.subtype = {$subtypeval})";
				}								
			}
			if (!empty($tempwhere)) $where[] = "({$tempwhere})";
			
		} else {
		
			$type = sanitise_string($type);
			$subtype = get_subtype_id($type, $subtype);
			
			if ($type != "")
				$where[] = "e.type='$type'";
			if ($subtype!=="")
				$where[] = "e.subtype=$subtype";
				
		}
		//in case user_guid is given, make sure only friends of this user are shown
		if ($user_guid != "") {
			$where[] = "e.owner_guid = '$owner_guid'";
		}
		
		if ($site_guid > 0)
			$where[] = "e.site_guid = {$site_guid}";
			
		if (!is_null($container_guid)) {
			if (is_array($container_guid)) {
				foreach($container_guid as $key => $val) $container_guid[$key] = (int) $val;
				$where[] = "e.container_guid in (" . implode(",",$container_guid) . ")";
			} else {
				$container_guid = (int) $container_guid;
				$where[] = "e.container_guid = {$container_guid}";
			}
		}	
	
		// Add the calendar stuff
		$loc_join = "
			JOIN {$CONFIG->dbprefix}metadata loc_start on e.guid=loc_start.entity_guid
			JOIN {$CONFIG->dbprefix}metastrings loc_start_name on loc_start.name_id=loc_start_name.id
			JOIN {$CONFIG->dbprefix}metastrings loc_start_value on loc_start.value_id=loc_start_value.id
			
			JOIN {$CONFIG->dbprefix}metadata loc_end on e.guid=loc_end.entity_guid
			JOIN {$CONFIG->dbprefix}metastrings loc_end_name on loc_end.name_id=loc_end_name.id
			JOIN {$CONFIG->dbprefix}metastrings loc_end_value on loc_end.value_id=loc_end_value.id
		";

		if ($inverse_relationship) {
			$on = 'e.guid = r.guid_two';
		} else {
			$on = 'e.guid = r.guid_one';
		}
	    if ($relationship){
	    	$loc_join .= " JOIN {$CONFIG->dbprefix}entity_relationships r on {$on}";
    	}
		$where[] = "loc_start_name.string='geo:lat'";
		$where[] = "loc_start_value.string>=$lat_min";
		$where[] = "loc_start_value.string<=$lat_max";
		$where[] = "loc_end_name.string='geo:long'";
		$where[] = "loc_end_value.string >= $long_min";
		$where[] = "loc_end_value.string <= $long_max";
		
		if ($relationship){
        	$where[] = "r.relationship = '{$relationship}'";
        	if ($inverse_relationship){
        		$where[] = "r.guid_one = {$user_guid}";
        	}else{
        		$where[] = "r.guid_two = {$user_guid}";
        	}
        }

		if (!$count) {
			$query = "SELECT e.* from {$CONFIG->dbprefix}entities e $loc_join where ";
		} else {
			$query = "SELECT count(e.guid) as total from {$CONFIG->dbprefix}entities e $loc_join where ";
		}
		foreach ($where as $w)
			$query .= " $w and ";
			
		$query .= get_access_sql_suffix('e'); // Add access controls

		if (!$count) {
			if ($order_by != "")
				$query .= " order by $order_by";
			if ($limit) $query .= " limit $offset, $limit"; // Add order and limit
			$dt = get_data($query, "entity_row_to_elggstar");
			return $dt;
		} else {
			$total = get_data_row($query);
			return $total->total;
		}	
	}
	
	/**
	 * Return entities within a given geographic area.
	 *
	 * @param real $lat Latitude
	 * @param real $long Longitude
	 * @param real $radius The radius
	 * @param string $type The type of entity (eg "user", "object" etc)
	 * @param string $subtype The arbitrary subtype of the entity
	 * @param int $owner_guid The GUID of the owning user
	 * @param string $order_by The field to order by; by default, time_created desc
	 * @param int $limit The number of entities to return; 10 by default
	 * @param int $offset The indexing offset, 0 by default
	 * @param boolean $count Set to true to get a count rather than the entities themselves (limits and offsets don't apply in this context). Defaults to false.
	 * @param int $site_guid The site to get entities for. Leave as 0 (default) for the current site; -1 for all sites.
	 * @param int|array $container_guid The container or containers to get entities from (default: all containers).
	 * @return array A list of entities. 
	 */
	
	
	function vazco_get_entities_in_area($meta_array, $lat_max, $long_max, $lat_min, $long_min, $type = "", $subtype = "", $owner_guid = 0, $order_by = "", $limit = 10, $offset = 0, $count = false, $site_guid = 0, $container_guid)
	{
		global $CONFIG;
		//how much map should be loaded around the borders
		$safetyRadius = 0;
		
		$lat_max = $lat_max + $safetyRadius;
		$lat_min = $lat_min - $safetyRadius;
		$long_max = $long_max + $safetyRadius;
		$long_min = $long_min - $safetyRadius;
		
		if ($subtype === false || $subtype === null || $subtype === 0)
			return false;

		$order_by = sanitise_string($order_by);
		$limit = (int)$limit;
		$offset = (int)$offset;
		$site_guid = (int) $site_guid;
		if ($site_guid == 0)
			$site_guid = $CONFIG->site_guid;
			
		$where = array();
		
		
		// Filetr by metadata
        $mindex = 1; // Starting index of joined metadata/metastring tables
        $join_meta = "";
        $query_access = "";
        if (is_array($meta_array)){
	        foreach($meta_array as $meta) {
	            $join_meta .= "JOIN {$CONFIG->dbprefix}metadata m{$mindex} on e.guid = m{$mindex}.entity_guid ";
	            $join_meta .= "JOIN {$CONFIG->dbprefix}metastrings v{$mindex} on v{$mindex}.id = m{$mindex}.value_id ";
	
	            $meta_n = get_metastring_id($meta['name']);
	            $where[] = "m{$mindex}.name_id='$meta_n'";
	
	            if (strtolower($meta['operand']) == "like"){
	                // "LIKE" search
	                $where[] = "v{$mindex}.string LIKE ('".$meta['value']."') ";
	            }elseif(strtolower($meta['operand']) == "in"){
	                // TO DO - "IN" search
	            }elseif($meta['operand'] != ''){
	                // Simple operand search
	                $where[] = "v{$mindex}.string".$meta['operand']."'".$meta['value']."'";
	            }
				//Add access controls
	            $query_access .= ' and ' . get_access_sql_suffix("m{$mindex}");
	            $mindex++;
	        }
        }
		if (is_array($type)) {			
			$tempwhere = "";
			if (sizeof($type))
			foreach($type as $typekey => $subtypearray) {
				foreach($subtypearray as $subtypeval) {
					$typekey = sanitise_string($typekey);
					if (!empty($subtypeval)) {
						$subtypeval = (int) get_subtype_id($typekey, $subtypeval);
					} else {
						$subtypeval = 0;
					}
					if (!empty($tempwhere)) $tempwhere .= " or ";
					$tempwhere .= "(e.type = '{$typekey}' and e.subtype = {$subtypeval})";
				}								
			}
			if (!empty($tempwhere)) $where[] = "({$tempwhere})";
			
		} else {
		
			$type = sanitise_string($type);
			$subtype = get_subtype_id($type, $subtype);
			
			if ($type != "")
				$where[] = "e.type='$type'";
			if ($subtype!=="")
				$where[] = "e.subtype=$subtype";
				
		}

		if ($owner_guid != "") {
			if (!is_array($owner_guid)) {
				$owner_array = array($owner_guid);
				$owner_guid = (int) $owner_guid;
				$where[] = "e.owner_guid = '$owner_guid'";
			} else if (sizeof($owner_guid) > 0) {
				$owner_array = array_map('sanitise_int', $owner_guid);
				// Cast every element to the owner_guid array to int
				$owner_guid = implode(",",$owner_guid); //
				$where[] = "e.owner_guid in ({$owner_guid})" ; //
			}
			if (is_null($container_guid)) {
				$container_guid = $owner_array;
			}
		}
		
		if ($site_guid > 0)
			$where[] = "e.site_guid = {$site_guid}";
			
		if (!is_null($container_guid)) {
			if (is_array($container_guid)) {
				foreach($container_guid as $key => $val) $container_guid[$key] = (int) $val;
				$where[] = "e.container_guid in (" . implode(",",$container_guid) . ")";
			} else {
				$container_guid = (int) $container_guid;
				$where[] = "e.container_guid = {$container_guid}";
			}
		}	
	
		// Add the calendar stuff
		$loc_join = "
			JOIN {$CONFIG->dbprefix}metadata loc_start on e.guid=loc_start.entity_guid
			JOIN {$CONFIG->dbprefix}metastrings loc_start_name on loc_start.name_id=loc_start_name.id
			JOIN {$CONFIG->dbprefix}metastrings loc_start_value on loc_start.value_id=loc_start_value.id
			
			JOIN {$CONFIG->dbprefix}metadata loc_end on e.guid=loc_end.entity_guid
			JOIN {$CONFIG->dbprefix}metastrings loc_end_name on loc_end.name_id=loc_end_name.id
			JOIN {$CONFIG->dbprefix}metastrings loc_end_value on loc_end.value_id=loc_end_value.id
		";
		$loc_join .= $join_meta;
		$where[] = "loc_start_name.string='geo:lat'";
		$where[] = "loc_start_value.string>=$lat_min";
		$where[] = "loc_start_value.string<=$lat_max";
		$where[] = "loc_end_name.string='geo:long'";
		$where[] = "loc_end_value.string >= $long_min";
		$where[] = "loc_end_value.string <= $long_max";
		
		
		if (!$count) {
			$query = "SELECT e.* from {$CONFIG->dbprefix}entities e $loc_join where ";
		} else {
			$query = "SELECT count(e.guid) as total from {$CONFIG->dbprefix}entities e $loc_join where ";
		}
		foreach ($where as $w)
			$query .= " $w and ";
			
		$query .= get_access_sql_suffix('e'); // Add access controls
		$query .= $query_access;
		if (!$count) {
			if ($order_by != "")
				$query .= " order by $order_by";
			if ($limit) $query .= " limit $offset, $limit"; // Add order and limit
			$dt = get_data($query, "entity_row_to_elggstar");
//dumpdie($query);
			return $dt;
		} else {
			$total = get_data_row($query);
			return $total->total;
		}	
	}	
	
	
?>