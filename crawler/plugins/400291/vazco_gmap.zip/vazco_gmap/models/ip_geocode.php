<?php 
// class geocodeReverse
	class ipGeolocation {
			private $status;
			private $coutryCode;
			private $contryName;
			private $regionCode;
			private $regionName;
			private $city;
			private $zip;
			private $lat;
			private $long;
			private $timeout;
		

		function __construct($ip = null, $timeout = 1) {
			//if no IP address was provided, use the current user's address 
			if ($ip == null)
				$ip = Getenv("REMOTE_ADDR");
			
			$this->timeout = $timeout;
			$this->status = "";
			$this->coutryCode = "";
			$this->contryName = "";
			$this->regionCode = "";
			$this->regionName = "";
			$this->city = "";
			$this->zip = "";
			$this->lat = "";
			$this->long = "";
			$this->getAddress($ip);
		}
		public function getLong() {
			return $this->long;
		}
		public function getLat() {
			return $this->lat;
		}
		public function getCountryCode() {
			return $this->countryCode;
		}
		public function getCountryName() {
			return $this->countryName;
		}
		
		public function getStatus() {
			return $this->status;
		}
		public function getRegionCode() {
			return $this->status;
		}
		public function getRegionName() {
			return $this->status;
		}
		public function getCity() {
			return $this->city;
		}
		public function getZip() {
			return $this->zip;
		}
					
		public function getAddress($ip) {
			//set sockettimeout for opening file
			$old = ini_set('default_socket_timeout', $this->timeout);
			
			$url="http://www.geobytes.com/IpLocator.htm?GetLocation&template=xml.txt&ipaddress=".$ip;
			try{
				$string = file_get_contents('http://www.wp.pl');
				$xmlCode = simplexml_load_string($string);
				//reset socket timeout to default
				ini_set('default_socket_timeout', $old);
				// create an object from XML file (string)
				$this->coutryCode 	= $xmlCode->iso3;
				$this->contryName 	= $xmlCode->country;
				$this->regionName 	= $xmlCode->region;
				$this->city 		= $xmlCode->city;
				$this->lat 			= $xmlCode->latitude;
				$this->long 		= $xmlCode->longitude;
			}
			//in case file is not opened on time, show timeout
			catch(Exception $e){
				$this->status = "Timeout with limit of seconds: ".$timeout;
			}	
		}
		public function get_coordinates(){
			if ($this->status == "OK" && $this->lat != '' && $this->long != 0)
	    		return '('.$this->lat.','.$this->long.')';
	    	else
	    		return '';
		}	
	}; // end of class	

?>