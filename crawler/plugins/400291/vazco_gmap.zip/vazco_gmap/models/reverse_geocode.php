<?php 
// class geocodeReverse
	class geocodeReverse {
			private $x;
			private $y;
			private $countryCode;
			private $contryName;
			private $city;
			private $xmlCode;
			private $street;
			private $address;
			private $state;
		
		function __construct($longitude, $latitude, $timeout = 1) {
			$this->timeout = $timeout;
			$this->address = "";
			$this->street = "";
			$this->city = "";
			$this->state = "";
			
			$settings = find_plugin_settings('google-map');
			$this->apiKey = $settings->api_key;
			
			$this->changeLocation($longitude, $latitude);
		}
		public function getCity() {
			return $this->city;
		}
		public function getXpos() {
			return $this->x;
		}
		public function getYpos() {
			return $this->y;
		}
		public function getLng() {
			return $this->x;
		}
		public function getLat() {
			return $this->y;
		}
		public function getCountryCode() {
			return $this->countryCode;
		}
		public function getCountryName() {
			return $this->countryName;
		}
		public function getAddress() {
			return $this->address;
		}
		public function getStreet() {
			return $this->street;
		}	
		
		public function getState(){
			return $this->state;
		}
		public function changeLocation($longitude, $latitude) {
			$this->x = $longitude;
			$this->y = $latitude;
			//this reverse geocode service is not working correctly
			//$url = 'http://ws.geonames.org/findNearby?lat='.$y.'&lng='.$x.'&maxRows='.$this->maxRows.'&featureCode=PPLA&style='.$this->style;
			$url="http://maps.google.com/maps/geo?q=".$this->y.",".$this->x."&output=xml&oe=utf8&sensor=false&key=".$this->apiKey;
			//set sockettimeout for opening file
			$old = ini_set('default_socket_timeout', $this->timeout);
			//open file
//echo $url;die();
			$this->xmlCode = simplexml_load_file($url);

			//reset socket timeout to default
			ini_set('default_socket_timeout', $old);


			try{
				// create an object from XML file (string)
				$placemarkKey = 0;
				$this->address 		= (string)$this->xmlCode->Response->Placemark[$placemarkKey]->address;
				$this->x 			= (float)$this->xmlCode->geoname->lng;
				$this->y 			= (float)$this->xmlCode->geoname->lat;
				$this->countryCode 	= (string)$this->xmlCode->Response->Placemark[$placemarkKey]->AddressDetails->Country->CountryNameCode;
				$this->countryName 	= (string)$this->xmlCode->Response->Placemark[$placemarkKey]->AddressDetails->Country->CountryName;
				$this->state	 	= (string)$this->xmlCode->Response->Placemark[$placemarkKey]->AddressDetails->Country->AdministrativeArea->AdministrativeAreaName;

				if (isset($this->xmlCode->Response->Placemark[$placemarkKey]->AddressDetails->Country->AdministrativeArea->SubAdministrativeArea))
					$administrativeAreaElement = $this->xmlCode->Response->Placemark[$placemarkKey]->AddressDetails->Country->AdministrativeArea->SubAdministrativeArea;
				else if (isset($this->xmlCode->Response->Placemark[$placemarkKey]->AddressDetails->Country->SubAdministrativeArea))
					$administrativeAreaElement = $this->xmlCode->Response->Placemark[$placemarkKey]->AddressDetails->Country->SubAdministrativeArea;
				else if (isset($this->xmlCode->Response->Placemark[$placemarkKey]->AddressDetails->Locality))
					$administrativeAreaElement 	= $this->xmlCode->Response->Placemark[$placemarkKey]->AddressDetails;
				else
					$administrativeAreaElement = $this->xmlCode->Response->Placemark[$placemarkKey]->AddressDetails->Country->AdministrativeArea;
				$this->city 		= $administrativeAreaElement->Locality->LocalityName;
				if (isset($administrativeAreaElement->Locality->Thoroughfare->ThoroughfareName))
					$this->street 	= $administrativeAreaElement->Locality->Thoroughfare->ThoroughfareName;

			}
			//in case file is not opened on time, show timeout
			catch(Exception $e){
				$this->city = "";
				$this->countryCode = "";
				$this->countryName = "";
				$this->state = "";
				$this->distance = 0;
			}	
		}
		public function getXMLCode() {
			return $this->xmlCode;
		}
	}; // end of class	
	
	
	//Methods related to geocode reversing
	
	function get_longlat_string($point){
		$longlat = substr($point,1,strlen($point)-2);
    	return str_replace(' ', '',$longlat);
	}
	
	//retrieves address from object. If it's unsuccessfull, tries to cache the address
	function get_address_from_object($object){
		if (isset($object->vaz_addr)){
			return $object->vaz_addr;
		}
		else{
			user_cache_location($object, 1);
		}
	}

	//get address from longlat in format "longitude,latitude" by using geocode object and geocode webservice
	function get_address($longlat, $timeout = 5,$type="stcocity"){
		$longlat_array =  split(",", $longlat);
		$address = "";
		
	    if (sizeof($longlat_array) == 2){
	    	$geo = new geocodeReverse($longlat_array[1],$longlat_array[0],$timeout);		
	    	switch($type){
	    		case "full":
	    						$address = $geo->getAddress();
	    						break;
	    		case "city":
	    						$address = $geo->getCity();
	    						break;
	    		case "cocity":
	    						$country = $geo->getCountry();
	    						$city = $geo->getCity();
	    						if ($city!= "" && $country!="")
	    							$address.=$country.', '.$city;
	    						break;				
	    		case "stcocity":
	    						$country = $geo->getCountryName();
								$countryCode = $geo->getCountryCode();
								$state = $geo->getState();
	    						$city = $geo->getCity();
								if ($countryCode == "US"){
									if ($city!= "" && $state!="")
										$address.= $city.', '.$state;
								}else{
									if ($city!= "" && $country!="")
										$address.= $city.', '.$country;
								}
	    						break;								
	    		default:
	    						$address = sprintf(elgg_echo('form:location:address:notsupported'),$type);
	    	}

			return $address;	    	
	    }
	}
?>