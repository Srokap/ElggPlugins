<?php
if (is_plugin_enabled('form')){

	form_custom_field_type_manager(
		//type	
			'location',
		//label
			elgg_echo('form:location'),
		//input_view
			'input/location',
		//output view
			'output/address'
	);
	
	form_custom_field_type_manager(
		//type	
			'privlocation',
		//label
			elgg_echo('form:location:private'),
		//input_view
			'input/location',
		//output view
			'output/privaddress'
	);
	
	form_custom_field_type_manager(
		//type	
			'maplocation',
		//label
			elgg_echo('form:location:map'),
		//input_view
			'input/location',
		//output view
			'output/map'
	);
	
	form_custom_field_type_manager(
		//type	
			'privmaplocation',
		//label
			elgg_echo('form:location:map:private'),
		//input_view
			'input/location',
		//output view
			'output/privmap'
	);
	
	
	form_custom_field_type_manager(
		//type	
			'maplocation_wide',
		//label
			elgg_echo('form:location:map:wide'),
		//input_view
			'input/location',
		//output view
			'output/map_wide'
	);
	
	form_custom_field_type_manager(
		//type	
			'privmaplocation_wide',
		//label
			elgg_echo('form:location:map:private:wide'),
		//input_view
			'input/location',
		//output view
			'output/privmap_wide'
	);
	
	form_custom_field_type_manager(
		//type	
			'location_picker_demo',
		//label
			'Location picker demo',
		//input_view
			'input/demo_option',
		//output view
			'output/picker_demo'
	);
	

}
?>