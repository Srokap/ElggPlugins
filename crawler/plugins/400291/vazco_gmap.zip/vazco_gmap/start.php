<?php

	/*
  	 * @package Elgg
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Michal Zacher [michal.zacher@gmail.com]
	 * @remarks In case you need any help with this plugin, geocoding or reverse geocoding, please contact me and I may be able to help.
	*/
	
	function vazco_gmap_init() {
		//extend form fields
		require_once(dirname(__FILE__)."/models/model.php");
		require_once(dirname(__FILE__)."/models/ip_geocode.php");
		require_once(dirname(__FILE__) . "/models/field_types_extended.php");

		//extend css and metatags
		extend_view('css','vazco_gmap/css');
		extend_view('metatags','vazco_gmap/metatags',1);

		//add lightbox select in case location picker was set in the request
		extend_view('page_elements/footer','vazco_gmap/select_location_lightbox', 1);
		
		register_elgg_event_handler('profileupdate', 'all', 'handler_user_cache_location',1);
		register_elgg_event_handler('create', 'user', 'handler_user_cache_location');
		register_page_handler('vazco_gmap','vazco_gmap_page_handler');
		
		set_default_location();
		if (function_exists('add_custom_field_type')){
			vazco_add_location_profile_field();
		}
	}


	function vazco_add_location_profile_field(){
		$profileoptions = array();
		$profileoptions["show_on_register"] = true;
		$profileoptions["mandatory"] = true;
		$profileoptions["user_editable"] = true;
		$profileoptions["output_as_tags"] = true;
		$profileoptions["admin_only"] = true;
		$profileoptions["simple_search"] = true;
		$profileoptions["advanced_search"] = true;		

		$groupoptions = array();
		$groupoptions["output_as_tags"] = true;
		$groupoptions["admin_only"] = true;		

		// registering profile field types
		add_custom_field_type("custom_profile_field_types", 'address', elgg_echo('form:location'), $profileoptions);
		add_custom_field_type("custom_profile_field_types", 'privaddress', elgg_echo('form:location:private'), $profileoptions);
		add_custom_field_type("custom_profile_field_types", 'map', elgg_echo('form:location:map'), $profileoptions);
		add_custom_field_type("custom_profile_field_types", 'privmap', elgg_echo('form:location:map:private'), $profileoptions);
		add_custom_field_type("custom_profile_field_types", 'map_wide', elgg_echo('form:location:map:wide'), $profileoptions);
		add_custom_field_type("custom_profile_field_types", 'privmap_wide', elgg_echo('form:location:map:private:wide'), $profileoptions);
		
		//registering group field types
		add_custom_field_type("custom_group_field_types", 'address', elgg_echo('form:location'), $groupoptions);
		add_custom_field_type("custom_group_field_types", 'privaddress', elgg_echo('form:location:private'), $groupoptions);
		add_custom_field_type("custom_group_field_types", 'map', elgg_echo('form:location:map'), $groupoptions);
		add_custom_field_type("custom_group_field_types", 'privmap', elgg_echo('form:location:map:private'), $groupoptions);
		add_custom_field_type("custom_group_field_types", 'map_wide', elgg_echo('form:location:map:wide'), $groupoptions);
		add_custom_field_type("custom_group_field_types", 'privmap_wide', elgg_echo('form:location:map:private:wide'), $groupoptions);		
	}

	//default location needs to be run here, since the one from google-map plugin can't be extended.
	function set_default_location(){
		if (!isset($_SESSION['VAZCO_GMAP_DEFAULT_LOCATION'])){
			$defaultLocation = 'Elgg, Switzerland';
			if (get_plugin_setting('deflocation','vazco_gmap'))
				$defaultLocation = get_plugin_setting('deflocation','vazco_gmap');
			$ipGeolocation = new ipGeolocation();
			$coordinates = $ipGeolocation->get_coordinates();
	
			if ($coordinates != ''){
				$_SESSION['VAZCO_GMAP_DEFAULT_LOCATION']=$coordinates;
			}
			else if (isset($_SESSION['user']) && $_SESSION['user']->location) {
				$_SESSION['VAZCO_GMAP_DEFAULT_LOCATION']=$_SESSION['user']->location;
			}
			else{
				$_SESSION['VAZCO_GMAP_DEFAULT_LOCATION']=$defaultLocation;
			}
		}
	}

	//set latitude and longitude based on user's location field
	function handler_user_cache_location($event, $object_type, $object) {		
		user_cache_location($object);
	}

	function vazco_gmap_page_handler($page) {
		
		global $CONFIG;
		
		if (isset($page[0])) 
		{
			switch($page[0]) 
			{
				case "members":  //view list of albums owned by container
					if (isset($page[1])){						
						switch($page[1]){ 
							case "map":
								set_input('filter','map');
								echo elgg_view('vazco_gmap/members');
						}
					}
					break;
				case "cache":
					if (isset($page[1])){						
						switch($page[1]){ 
							case "users":
								if (isadminloggedin()){
									$limit = 100000;
									$offset = 0;
									if (isset($page[2])){
										$offset = $page[2];
									}
									user_cache_location_all($limit, $offset);
									system_message(elgg_echo('vazco_gmap:user:cache:success'));
								}
								forward(get_input('forward_url', $_SERVER['HTTP_REFERER']));								
						}
					}
					break;
			}
		}
	}
	register_elgg_event_handler('init','system','vazco_gmap_init');
?>