WHAT PLUGIN'S DEMO VERSION DOES:

    * It adds location select capabilities to google-map, form and related plugins
    * It adds reverse geotagging capability
    * It displays locations on forms, group and user profile
    * it can be easily adopted to add location to any content
    * It can be easily used to add geotagging to any Elgg element (photo, event etc.)

- Widget displaying all groups members on the map
- Widget displaying all user's friends on the map


WHAT PLUGIN'S COMMERCIAL EXTENSIONS CAN DO:

    * guess user's location by his IP address
    * display maps straight on the user/group/custom form
    * display all users on a map
    * take user's location on registration
    * work on a large sites

You can view the plugin's demo, and a full description at this page: http://elggdev.com/pg/groups/27/vazco_gmap/

REQUIREMENTS: 

    * Elgg 1.5
    * google-map plugin, ver. 0.92
    * form plugin and related (flexgroupprofile, flexprofile), ver 0.82
    * siteaccess plugin (only for the 'location on registration' extension)

INSTALL:

    * install the required plugins from the list above
    * place this plugin below the required plugins, and enable.
    * go to the Administration->Forms management, and create user or group form
    * add a field to this form, and name it 'location'. Choose the type of this field as 'Google Maps'
    * save the form, and edit your group/user profile. You will see a location selector on edit page
    * in case of any trouble, please refer to the forms documentation

IN CONSTRUCTION:
- search objects by location
- route selecting and displaying capabilities



You may want to:
- change the way user locations are displayed on the listings. Go to views/default/profile/listings.php, and find line:

$info .= "<p class=\"owner_timestamp\">" . elgg_echo("profile:location") . ": " . elgg_view("output/privaddress",array('value' => $vars['entity']->location)) . "</p>";


change it to:

$info .= "<p class=\"owner_timestamp\">" . elgg_echo("profile:location") . ": " . elgg_view("output/address",array('value' => $vars['entity']->location)) . "</p>";

This will make user's location on the listings to be displayed with the marker.