<?php
	/*
  	 * @package Elgg
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Michal Zacher [michal.zacher@gmail.com]
	 * @remarks In case you need any help with this plugin, geocoding or reverse geocoding, please contact me and I may be able to help.
	*/
echo elgg_view('google-map/metatags');

/*
$settings = find_plugin_settings('google-map');
$key = $settings->api_key;

echo "<script src='http://maps.google.com/maps?file=api&v=2&key={$key}' type-='text/javascript'></script>"; 
echo "<script type='text/javascript'>";
echo "var IMAGES='{$CONFIG->url}mod/google-map/images/';";
include($CONFIG->pluginspath . '/google-map/js/gmap.php');
echo "</script>";
*/
?>