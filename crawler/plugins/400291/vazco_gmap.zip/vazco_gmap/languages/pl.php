<?php

	$polish = array(
		'location:select:notifier' => "Musisz najpierw wybrać lokację",
		'vazco_gmap:location:reselect' => 'Zmień lokację',
		'location:mapnotloaded' => "Ładowanie mapy...",
		'thickbox:oresc' => "lub wciśnij Esc",
		'thickbox:close' => "Zamknij",
		'location:save' => 'Zapisz lokację',
		'location:jump' => 'Przeskocz',
		'location:search:noaddress' => "Nie znaleziono adresu: ",
		'location:select:cancel' => "Wyczyść",
		'address:link:description' => "Zobacz dokładny adres na mapie",
		'map:location:notset' => 'Nie ustawiono lokacji',

		'members:map' =>'Mapa członków',
		
		'vazco_gmap:user:cache:success' => 'Lokacje wszystkich użytkowników zostały z sukcesem zapisane do bazy',
		'vazco_gmap:user:cache' => 'Zapisz do bazy lokacje obiektów. Ta operacja jest wymagana po włączeniu cachowania lokacji na już działającym serwisie. ( Uwaga: ta operacja może potrwać do paru minut )',
		'vazco_gmap:user:cache:save' => 'Zapisz lokacje użytkowników do bazy',
	
		'vazco_gmap:entitiesonmap' => "Liczba obiektów wywietlana na raz na mapie",	
		'vazco_gmap:map:viewprofile' => 'Przejdź do profilu użytkownika',
		'vazco_gmap:map:loading' => 'Proszę czekać...',
		'vazco_gmap:map:user:list' => 'Obecnie na mapie',
		'vazco_gmap:map:user:mostpopular' => 'Najpopularniejsi',
		'form:profile_birthdate_label' => "Data urodzenia - dropdown",
		'form:birthdate:age' => "(Wybierz swoją datę urodzenia)",
		'form:birthdate:years' => "lat",
		'form:no_title_display_field' => "Pole tekstowe nie wyświetlające tytułu",
		'form:location:select' => "Wybierz lokację",
		'form:location:select:desc' => "Zaznacz kliknięciem lokację na mapie.",
		'form:location:address:desc' => "Skocz do adresu",
		'form:location:address:unknown' => "Zobacz na mapie",
		'form:location:address:notsupported' => "Typ adresu %s nie jest wspierany",
		'form:location' => "Lokacja Google Maps, link z markerem",
		'form:location:map' => 'Lokacja Google Maps, mapa z markerem',
		'form:location:private' => 'Lokacja Google Maps, link bez markera',
		'form:location:map:private' => 'Lokacja Google Maps, mapa bez markera',
		'form:location:map:wide' => 'Lokacja Google Maps, szeroka mapa z markerem',
		'form:location:map:private:wide' => 'Lokacja Google Maps, szeroka mapa bez markera',
		
		'date:select:day' => 'Wybierz dzień',
		'date:select:month' => 'Wybierz miesiąc',
		'date:select:year' => 'Wybierz rok',
		'siteaccess:month:1' => 'Styczeń',
		'siteaccess:month:2' => 'Luty',
		'siteaccess:month:3' => 'Marzec',
		'siteaccess:month:4' => 'Kwiecień',
		'siteaccess:month:5' => 'Maj',
		'siteaccess:month:6' => 'Czerwiec',
		'siteaccess:month:7' => 'Lipiec',
		'siteaccess:month:8' => 'Sierpień',
		'siteaccess:month:9' => 'Wrzesień',
		'siteaccess:month:10' => 'Październik',
		'siteaccess:month:11' => 'Listopad',
		'siteaccess:month:12' => 'Grudzień',
		
		/*Members map*/
		'members:sort:newest'	=> "Najnowsi",
		'members:sort:popular'	=> "Najpopularniejsi",
		'members:sort:active'	=> "Zalogowani",
		'members:name'	=> 	"Imię użytkownika",
		'members:tag'	=> 	"Tagi użytkownika",
		'members:go'	=> "Szukaj",
	
		/*images map*/
		'vazco_gmap:imagefromalbum' => 'Image from album:',
		'vazco_gmap:map:viewimage' => 'View image', 
		'vazco_gmap_tidypics:album' => 'Album',
		'vazco_gmap_tidypics:image' => 'Image',
		'vazco_gmap_t:fromalbum' => 'from album',
		'vazco_gmap_t:withnoname' => 'unnamed',
	);

	add_translation("pl",$polish);

?>