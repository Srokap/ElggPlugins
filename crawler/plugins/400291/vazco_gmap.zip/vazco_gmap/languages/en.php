<?php

	$english = array(
		'location:select:notifier' => "You have to select location first",
		'vazco_gmap:location:reselect' => 'Change location',
		'location:mapnotloaded' => "Loading map...",
		'thickbox:oresc' => "or press Esc",
		'thickbox:close' => "Close",
		'location:save' => 'Save location',
		'location:jump' => 'Jump',
		'location:search:noaddress' => "Address not found: ",
		'location:select:cancel' => "Clear and close",
		'map:location:notset' => 'Location not chosen yet',	
		'address:link:description' => "Show exact address on map",
		
		'vazco_gmap:entitiesonmap' => "Number of entities to be displayed on a map at once",
		'vazco_gmap:map:viewprofile' => 'View user\'s profile',
		'vazco_gmap:map:loading' => 'Loading...',
		'vazco_gmap:map:user:list' => 'Currently on the map',
		'vazco_gmap:map:user:mostpopular' => 'Most popular',

		'vazco_gmap:user:cache:success' => 'All user locations were succesfully saved to database',
		'vazco_gmap:user:cache' => 'Save locations of entities to database. This operation is required after installing location caching on a system that already used user locations. ( Notice: this operation may take up to a few minutes )',
		'vazco_gmap:user:cache:save' => 'Save locations of users to database',	
	
		'form:location:address:unknown' => "Show address on map",
		'form:location:address:notsupported' => "Address type %s not supported",
		'form:location' => "Google Maps location, link with a marker",
		'form:location:map' => 'Google Maps location, map with a marker',
		'form:location:private' => 'Google Maps location, link without a marker',
		'form:location:map:private' => 'Google Maps location, map without a marker',
		'form:location:map:private:wide' => 'Google Maps location, wide map without a marker',
		'form:location:map:wide' => 'Google Maps location, wide map with a marker',
		'form:profile_birthdate_label' => "Birthday date dropdown",
		'form:birthdate:age' => "(Choose your birth date)",
		'form:birthdate:years' => "year old",
		'form:no_title_display_field' => "Text field without title on display",
		'form:location:select' => "Select location",
		'form:location:select:desc' => "Mark location on map by click.",
		'form:location:address:desc' => "Jump to address",
		
		'date:select:day' => 'Select day',
		'date:select:month' => 'Select month',
		'date:select:year' => 'Select year',
		'siteaccess:month:1' => 'January',
		'siteaccess:month:2' => 'February',
		'siteaccess:month:3' => 'March',
		'siteaccess:month:4' => 'April',
		'siteaccess:month:5' => 'May',
		'siteaccess:month:6' => 'June',
		'siteaccess:month:7' => 'July',
		'siteaccess:month:8' => 'August',
		'siteaccess:month:9' => 'September',
		'siteaccess:month:10' => 'October',
		'siteaccess:month:11' => 'November',
		'siteaccess:month:12' => 'December',
		
		/*Members map*/
		'members:sort:newest'	=> "Newest",
		'members:sort:popular'	=> "Popular",
		'members:sort:active'	=> "Logged in",
		'members:name'	=> 	"Member name",
		'members:tag'	=> 	"Member tag",
		'members:go'	=> "go",
		'members:active'=> 'Active',
		'members:map'=> 'Map of users',
	
		/*images map*/
		'vazco_gmap:imagefromalbum' => 'Image from album:',
		'vazco_gmap:map:viewimage' => 'View image', 
		'vazco_gmap_tidypics:album' => 'Album',
		'vazco_gmap_tidypics:image' => 'Image',	
		'vazco_gmap_t:fromalbum' => 'from album',
		'vazco_gmap_t:withnoname' => 'unnamed',
	
		/*Search box for big map*/
		'location:jumptoaddr' => 'Jump to address or zip code',
	
		/*Custom profile fields*/
		'vazco_gmap:location' => 'Location',
	);
					
	add_translation("en",$english);
?>