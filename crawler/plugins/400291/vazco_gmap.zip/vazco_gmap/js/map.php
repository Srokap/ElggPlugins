<?php 
	require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
	global $CONFIG;
	$entitylink = $location['entitylink'];
	$listlink = $location['listlink']; 
	$mapparams = $location['mapparams']; //parameters that are passed both to list and map
	$searchparams = get_input('mapsearch');
	foreach ($searchparams as $param => $value){
		$value = urlencode($value);
		$mapparams .= "&mapsearch[{$param}]={$value}";
	}
	$listviewtype = $location['listviewtype']; //type of the list view, default is list, can be galleryview or anything defined in vazco_gmap/map/#Viewtypename#
	$entityparams = $location['entityparams'];
?>
//shows on the map the location passed to the method
function showThisLocation(currloc, map, priv){
	var point = GLatLng.fromUrlValue(currloc.substring(1));
	if (point && point.toString().search('NaN') == -1){
		map.setCenter(point);
		map.clearOverlays();
		if (!priv)
			map.addOverlay(new GMarker(point));
		return true;
	}
	return false;
}

//shows address closest to this location on map
function markThisAddress(map, address){
	$.gmap.geocoder.getLatLng(address, function(point) {
		if (point && point.toString().search('NaN') == -1) {
			map.clearOverlays();
			map.setCenter(point);
			map.addOverlay(new GMarker(point));
			return true;
		}
		return false;
	});
}

//mark point on map
function setMarker(map, point){
	if (point) {
		map.addOverlay(new GMarker(point));
		return true;
	}
	return false;
}

//shows address closest to this location on map, no marker
function showThisAddress(map, address){
	$.gmap.geocoder.getLatLng(address, function(point) {
		if (point && point.toString().search('NaN') == -1) {
			map.clearOverlays();
			map.setCenter(point);
			return true;
		}
		return false;
	});
}
