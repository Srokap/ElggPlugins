<?php
	$entitiesonmap = $vars['entity']->entitiesonmap;
	if (!$entitiesonmap) $entitiesonmap = (int) 10; //set the default
	$defzoom = 5;
	if ($vars['entity']->defzoom)
		$defzoom = $vars['entity']->defzoom;
	$deflocation = 'Elgg, Switzerland';
	if ($vars['entity']->deflocation)
		$deflocation = $vars['entity']->deflocation;
?>
<p>
	<?php echo elgg_echo('vazco_gmap:entitiesonmap'); ?>
	
	<?php echo elgg_view('input/text', array('internalname' => 'params[entitiesonmap]', 'value' => $entitiesonmap)); ?>
</p>
<p>
	<?php echo elgg_echo('vazco_gmap:user:cache');?>
</p><p>
	<a href="<?php echo $vars['url'];?>pg/vazco_gmap/cache/users"><?php echo elgg_echo('vazco_gmap:user:cache:save');?></a>
</p>
<p><span><?php echo elgg_echo('vazco_gmap:deflocation'); ?></span>
	<?php echo elgg_view('input/text', array('internalname' => 'params[deflocation]','class' => ' ', 'value' => $deflocation)); ?>
</p>
<p><span><?php echo elgg_echo('vazco_gmap:defzoom'); ?></span>
	<?php echo elgg_view('input/text', array('internalname' => 'params[defzoom]','class' => ' ', 'value' => $defzoom)); ?>
</p>