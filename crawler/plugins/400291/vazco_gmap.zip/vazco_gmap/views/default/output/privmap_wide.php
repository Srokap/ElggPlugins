<?php
$vars['private'] = true;
$vars['width'] = 670;
$vars['height'] = 250;
echo elgg_view('vazco_gmap/output/map',$vars);
?>