<?php
echo elgg_view('vazco_gmap/output/maplinkaddress',$vars);
?>