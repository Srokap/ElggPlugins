<?php
$vars['private'] = true;
echo elgg_view('vazco_gmap/output/address',$vars);
?>