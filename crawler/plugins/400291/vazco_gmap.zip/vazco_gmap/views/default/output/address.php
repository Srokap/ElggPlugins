<?php

$vars['private'] = false;
echo elgg_view('vazco_gmap/output/address',$vars);
?>