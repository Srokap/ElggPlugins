<?php
	if ($vars['value'] && $vars['value'] != '')
		echo elgg_view('input/location',array('value' => null, 'zoom'=>14, 'internalname'=>'picker_demo'));
?>
