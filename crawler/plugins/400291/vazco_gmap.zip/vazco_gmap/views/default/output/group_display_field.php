<?php

/**
	 * @package Elgg
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Michal Zacher [michal.zacher@gmail.com]
	 * @remarks In case you need any help with this plugin, geocoding or reverse geocoding, please contact me and I may be able to help.
 */
	 $value = $vars['value'];
	 $title = $vars['title'];
	 $odd_even = $vars['odd_even'];
	 
	 $body = '<p class="'.$odd_even.'"><label>'.$title.':</label> '.$value.'</p>';
    echo $body;
?>