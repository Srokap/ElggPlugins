<?php
  /**
	 * @package Elgg
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Michal Zacher [michal.zacher@gmail.com]
	 * @remarks In case you need any help with this plugin, geocoding or reverse geocoding, please contact me and I may be able to help.
   */

$eid = isset($vars['eid'])?$vars['eid']:"gmap-".$vars['guid'];
$pattern = '/\([ \t]*([\+\-]?[0-9]+(\.[0-9]*)?)[ \t]*,[ \t]*([\+\-]?[0-9]+(\.[0-9]*)?)[ \t]*\)/';
if (preg_match($pattern, trim($vars['location']), $matches)) {
  $lat = (float)$matches[1];
  $lng = (float)$matches[3];
  $location = "{lat:$lat,lng:$lng}";
}
else {
  $location = $vars['location'];
  if (!preg_match('/^".*"$/', $location)) {
    $location = '"' . $location . '"';
  }
}
$zoom = intval($vars['zoom']);

if ($vars['controls'] == 'none') {
  $controls = "[]";
}
else {
  // TODO: allow more flexibility with controls
  $controls = "['GSmallMapControl']";
}

$mapOptions = '{';
if (is_array($vars['mapOptions'])) {
  $comma = '';
  foreach ($vars['mapOptions'] as $key => $value) {
    $mapOptions .= $comma . $key . ":{$value}";
    $comma = ',';
  }
}
$mapOptions .= '}';

$options = "{";
// FIXME $.gmap.center called twice w/default if address not set
if ($location) {
  $options .= "address:{$location},";
}
if ($zoom) {
  $options .= "zoom:{$zoom},";
}
$options .= "controls:{$controls},mapOptions:{$mapOptions},";
$options .= "autoPopulate:".(($vars['autoPopulate'] === false)?'false':'true');
$options .= "}";

// Uncomment to list users above map
//echo list_entities('user');

echo <<<EOT
<div id="{$eid}" style="overflow:hidden">
  <noscript>
  Map is unavailable
  </noscript>
</div>

<script type='text/javascript'>
// Delayed load is required, or elgg page continually reloads
$(document).ready(function() {
    var el = $('#{$eid}');
    el.width($("#{$eid}-container").width());
    if (el.height() < 100) {
      el.height(300);
    }
    el.gmap({$options});
    var map = $.gmap.maps["{$eid}"];
    if (map && map.autoPopulate) {
      $('.gmapped').each(function() {
          $.gmap.mark(map, this);
      });
       // Catch dynamically loaded content
      $(document).bind('ajaxComplete', function() {
          $('.gmapped').each(function() {
              $.gmap.mark(map, this);
            });
        });
    }
  });
</script>
EOT;
?>