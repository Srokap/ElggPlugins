<?php	

	/*
  	 * @package Elgg
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Michal Zacher [michal.zacher@gmail.com]
	 * @remarks In case you need any help with this plugin, geocoding or reverse geocoding, please contact me and I may be able to help.
	*/

	$entity = $vars['entity'];
	$location = set_location_in_request($entity->location, $vars['zoom'], $vars['entity']->guid);

?>
	<input id="<?php echo $location['elementId'];?>" name="<?php echo $vars['internalname']; ?>" type="text" class="hidden_input" value="<?php echo $location['location'];?>">

	<a class="widget_location_select" id="<?php echo $location['linkId'];?>" href="#"><?php echo elgg_echo('form:location:select')?></a>
	<br/>