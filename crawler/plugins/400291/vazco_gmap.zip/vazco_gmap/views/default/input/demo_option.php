<?php
$selected = ""; 
if (isset($vars['value']) && $vars['value'])
	$selected = "checked=\"checked\"";
?>
<input type="checkbox" name="<?php echo $vars['internalname']; ?>" <?php echo $selected;?>/>Show demo button 