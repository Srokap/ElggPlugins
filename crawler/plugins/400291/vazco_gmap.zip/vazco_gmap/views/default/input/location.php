<?php
	$location = set_location_in_request($vars['value'], $vars['zoom'], $vars['internalname']);
	$name = $vars['internalname'];
	if (isset($vars['fieldname']))
		$name = $vars['fieldname'];
?>
	<input id="<?php echo $location['elementId'];?>" name="<?php echo $name; ?>" type="text" class="hidden_input" value="<?php echo $vars['value'];?>">
	<a class="location_select<?php if ($vars['value']){echo " location_selected";}?>" id="<?php echo $location['linkId'];?>" href="#"><?php echo elgg_echo('form:location:select')?></a>