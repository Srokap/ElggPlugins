<?php
	echo elgg_view('input/location', $vars);
?>