/*
map styling
*/

.miniprof{

}

#location_search .wide{
	width:400px;
}
#location_search .widebutton{
	width: 180px;	
}
#location_search{
	-moz-border-radius:8px;
	background:white;
	margin:10px 150px;
	padding:10px;
	width: 620px;
}

.map_entities_content{
	margin: 5px 0;
	padding: 10px 0;	
}

.map_entities{
	margin: 10px;
}


a.toggle_box {
	color:#4690D6;
	cursor:pointer;
	float:right;
	font-family:Arial,Helvetica,sans-serif;
	font-size:20px;
	font-weight:bold;
	margin:-7px 0 0;
	text-decoration:none;
}
.group_bottom{
	float:left;
}

.map_entities_header{
	height: 20px;
	border-bottom: #CCCCCC 1px solid;
}
/*
Forms - styling of fields
*/

a.location_select:hover {
	background:#C8C8C8;
	color:white;
	text-decoration:none;
}
a.address_inactive,
a.address_inactive:hover{
	text-decoration: none;
	color: #000000;
	cursor:default;
	background: none;
}
a.location_select{
	-moz-border-radius:5px;
	text-align: center;
	display: block;
	background:#B5B5B5;
	border:medium none;
	color:white;
	cursor:pointer;
	font-size:12px;
	font-weight:bold;
	height:15px;
	width: 120px;
	margin:10px 0;
	padding:3px 6px;
}

.gmaps_container{
	background:white;
	-moz-border-radius:8px;
	border:2px solid #CCCCCC;
	margin:0 auto;
	overflow:hidden;
	padding:10px;
	width:640px;
}
.gmaps_centerer{
	position:fixed;
	z-index:10001;
	top:-40000px;
	position:fixed;
	width:100%;
	left:0;
}
.address_link{
	background: url("<?php echo$vars['url'];?>mod/vazco_gmap/images/globus.gif") no-repeat right;
	padding-right: 18px;
}
.gmaps_lbox_bckg{
	background: black;
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	text-align: center;
	z-index:10000;
	top:-40000px;
}

.location_button:hover{
	background:#0054A7;
	color:white;
	text-decoration:none;
}
.location_button{
	-moz-border-radius:5px;
	-x-system-font:none;
	background:#4690D6;
	color:white;
	cursor:pointer;
	font-family:Arial,Helvetica,sans-serif;
	font-size:12px;
	font-weight:bold;
	height:14px;
	line-height:100%;
	margin:0 0 0 10px;
	padding:3px 6px;
	width:89px;
	text-align: center;
}
p.location_address{
	margin: 5px 0 0 0;
}
.right{
	float:right;
	margin-top:5px;
}

.left{
	float:left;
	margin-top:5px;
}

input.location_address{
	width: 180px;
	padding: 2px;
}

.location_notifier{
	display: none;
	color: #FA7247;
	margin-left: 30px;
}

.hidden_input{
	display: none;
}

a.location_selected{
	background:#4690D6;
}

a.location_selected:hover{
	background:#0054A7;
}