<?php
	/**
	 * 
	 * @package Elgg
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Michal Zacher [michal.zacher@gmail.com]
	 * @remarks In case you need any help with this plugin, please contact me and I may be able to help. 
	 */

	//This view is used to display location on listings below the map, linking address with action on the map 

	//get vars passed to this view from the parent view's vars
	require_once(dirname(dirname(dirname(dirname(dirname(__FILE__)))))."/models/reverse_geocode.php");	

    //get address from user's metadata. If it's not there, get it from webservice and save to metadata.
    $address = get_address_from_object($vars['entity']);
	$location = $vars['entity']->location;
    $longlat_string = get_longlat_string($location);    
	if (!$address)
    	$address = get_address($longlat_string);
	if (!$address)
		$address = elgg_echo('form:location:address:unknown');
    $link = "http://maps.google.com/?ie=UTF8&ll=".$longlat_string."&spn=".$longlat_string."&z=14";	
?>
<a class='gmap-link' latlng='<?php echo $location;?>' href="#members_sort" title="<?php echo elgg_echo('address:link:description');?>"><?php echo $address;?></a>

