<?php 
	$location 	= $vars['location'];
	$width 		= $vars['width'];
	$height 	= $vars['height'];
	$private	= false;
	if (isset($vars['private']))
		$private = $vars['private'];
?>
<div id="<?php echo $location['eid']; ?>" >
	<?php echo elgg_echo('location:mapnotloaded');?>
	<noscript>
	</noscript>
</div>
<script type='text/javascript'>
	<?php
	 	//include map libraries
		require_once($CONFIG->pluginspath.'vazco_gmap/js/map.php');
	?>
	$(document).ready(function() {
		<?php //get parameters ?>
	    var address = '<?php echo $location['location']; ?>';
	    var zoom = <?php echo $location['zoom']; ?>;
		var id = '<?php echo $location['eid']; ?>';
	    var el = $('#' + id);

	    el.height(<?php echo $height;?>);
	    el.width(<?php echo $width;?>);
	    
		<?php //setting controls here stopped working after google-maps ver. 0.9, so it's set in init_additions as well ?>		
	    el.gmap(address, zoom, {
	        controls: ['<?php echo $location['controls'];?>']
	    });
	    
	    var map = $.gmap.maps[id];
	    map.addControl(new <?php echo $location['controls'];?>());
		<?php //add satelite/hybrid views?>
	    map.addControl(new GMapTypeControl());
	    map.setZoom(zoom);

	    <?php if ($private){?>
	    	showThisLocation(address, map, true);
		<?php }else{?>
			showThisLocation(address, map, false);
		<?php }?>
	});
</script>