<?php

	/**
	 * 
	 * @package Elgg
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Michal Zacher [michal.zacher@gmail.com]
	 * @remarks In case you need any help with this plugin, geocoding or reverse geocoding, please contact me and I may be able to help. 
	 */
	
//This view is used to display map on forms and related plugins, and in a places user choosaes to (then entity is passed to view)
	require_once(dirname(dirname(dirname(dirname(dirname(__FILE__)))))."/models/reverse_geocode.php");
	require_once($CONFIG->pluginspath.'vazco_gmap/gmapslibrary.php');
	
	$private = false;
	if (isset($vars['private']))
    	$private = $vars['private'];

	//In case entity is passed, take location from entity. Otherwise, use vars value, used by forms and related plugins.
	if (isset($vars['entity'])){
		$location = $vars['entity']->location;
		$address = get_address_from_object($vars['entity']);
	}
	else{
		$location = $vars['value'];
		$address = null;
	}
	
	//get address from user's metadata. If it's not there, get it from webservice and save to metadata.
	$longlat_string = get_longlat_string($location);
    if (!$address)
    	$address = get_address($longlat_string);
	if (!$address)
		$address = elgg_echo('form:location:address:unknown');
    $link = "http://maps.google.com/?ie=UTF8&ll=".$longlat_string."&spn=".$longlat_string."&z=14";
?>
<a href="<?php echo $link;?>" class="address_link address_inactive" onclick="return false;" title="<?php echo elgg_echo('address:link:description');?>" rel="gmap<?php if ($private){?>-p<?php }?>"><?php echo $address;?></a>

