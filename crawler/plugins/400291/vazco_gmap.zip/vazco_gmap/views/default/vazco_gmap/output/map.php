<?php

	/**
	 * 
	 * @package Elgg
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Michal Zacher [michal.zacher@gmail.com]
	 * @remarks In case you need any help with this plugin, geocoding or reverse geocoding, please contact me and I may be able to help. 
	 */
	//This view is used to display map on forms and related plugins, and in a places user choosaes to (then entity is passed to view)
	
	require_once(dirname(dirname(dirname(dirname(dirname(__FILE__)))))."/models/reverse_geocode.php");
	require_once($CONFIG->pluginspath.'vazco_gmap/gmapslibrary.php');

	//get vars passed to this view from the parent view's vars
    $address = $vars['value'];
    if ($address){
	    $location = create_location_table($address,14,$vars['internalname']);
	    $location['controls'] = 'GSmallZoomControl3D';
	    $height = 350;
		$width = 300;
	    if (isset($vars['width']))
	    	$width = $vars['width'];
	    if (isset($vars['height']))
	    	$height = $vars['height'];
	    
	    $private = false;
	    if (isset($vars['private']))
	    	$private = $vars['private'];
	    		
	    //display map, and pass parameters to it
	    echo elgg_view('vazco_gmap/show_map',array('width' => $width, 'height' => $height, 'location' => $location, 'private' =>$private));
    }
    else{
    	echo elgg_echo('map:location:notset');
    }
?>

