<?php

	/*
	 * @package Elgg
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Michal Zacher [michal.zacher@gmail.com]
	 * @remarks In case you need any help with this plugin, geocoding or reverse geocoding, please contact me and I may be able to help.
	 */

	if (isset($_REQUEST['location_edit_maps'])){
		//include all the Google Maps libraries
		//this should be included already in header, but in case it's not, includ it here
		global $CONFIG;
		require_once($CONFIG->pluginspath.'vazco_gmap/gmapslibrary.php');

		foreach ($_REQUEST['location_edit_maps'] as $location){

			$prefix			= $location['prefix'];

			$location['centererId'] 	= $prefix.'-cent';
			$location['bckgId'] 		= $prefix.'-background';
			$location['saveId'] 		= $prefix.'-save';
			$location['addressId']		= $prefix.'-addr';
			$location['jumpId']			= $prefix.'-jump';
			$location['notifierId']		= $prefix.'-notify';
			$location['cancelId']		= $prefix.'-cancel';
			$location['containerId']	= $prefix.'-cont';

			$controls = 'GLargeMapControl3D';
			if (isset($location['controls']))
				$controls = $location['controls'];
			
			if ($location['canEdit']){
?>
	<div id="<?php echo $location['bckgId'];?>" class="gmaps_lbox_bckg">
	</div>

		<div id="<?php echo $location['centererId']; ?>" class="gmaps_centerer">
			<div id="<?php echo $location['containerId'];?>" class="gmaps_container">
				<?php echo elgg_echo('form:location:select:desc');?> <span id="<?php echo $location['notifierId'];?>" class="location_notifier"><?php echo elgg_echo('location:select:notifier');?></span>
				<div id="<?php echo $location['eid']; ?>" >
					<?php echo elgg_echo('location:mapnotloaded');?>
					<noscript>
					</noscript>
				</div>
				
				<p class="location_address left"><?php echo elgg_echo('form:location:address:desc');?>: </p>
				<input id="<?php echo $location['addressId'];?>" type="text" name="address" value=""  class="location_address left"/>			
				<a id="<?php echo $location['jumpId'];?>" href="#" class="location_button left"><?php echo elgg_echo('location:jump');?></a>
				<a id="<?php echo $location['saveId'];?>" href="#" class="location_button right"><?php echo elgg_echo('location:save');?></a>
				<a id="<?php echo $location['cancelId'];?>" href="#" class="location_button right"><?php echo elgg_echo('location:select:cancel');?></a>
			</div>
		</div>
		<script type='text/javascript'>			
		
		<?php
		 	//include map libraries
			require_once($CONFIG->pluginspath.'vazco_gmap/js/map.php');
		?>
		<?php // Delayed load is required, or elgg page continually reloads ?>
		$(document).ready(function() {
			$("#<?php echo $location['bckgId'];?>").fadeTo(0, 0);
			<?php //get parameters ?>
		    var address = '<?php echo $location['location']; ?>';
		    var zoom = <?php echo $location['zoom']; ?>;
			var id = '<?php echo $location['eid']; ?>';
		    var el = $('#' + id);

		    if (el.height() < 100) {
			      el.height(300);
			}
			
		    el.gmap({address:address, zoom:zoom});

		    <?php //setting controls here stopped working after google-maps ver. 0.9, so it's set in init_additions as well?>
		    var map = $.gmap.maps['<?php echo $location['eid']; ?>'];

		    init_additions(map);
		    $(document).bind('ajaxComplete', function() {
		          $('.gmapped').each(function() {
		              $.gmap.mark(map, this);
		            });
		    });
		    
		    <?php //GMAP-related functions ?>		    	
				<?php //Sets on-click listener on the map ?>
				function init_additions(map){
					<?php //add on-click listener to the map, which sets longitude and latitude of the click to the form field ?>
				    map.addControl(new <?php echo $controls;?>());
				    map.addControl(new GMapTypeControl());

				    GEvent.addListener(map, "click",
				            function(overlay, point){
				              map.clearOverlays();
				              if (point) {
				            	  mark_point(map, point);
				              }
				    		}
				           );
				}
				
				  <?php //jumps to selected address ?>
				    function jumpToAddress(address, map){
				    	$.gmap.geocoder.getLatLng(address, function(point) {
				    		  if (point) {
				    			  map.setCenter(point);
				    			  map.clearOverlays();
				    			  mark_point(map, point);
				    		  }
				    		  else {
				    			if ($.gmap.debug) {
				    			  alert('<?php echo elgg_echo('location:search:noaddress');?>' + address);
				    			}
				    		  }
				    	  });
				    }  
				<?php //changes the look of the select location button ?>    
				function setAsMarked(){
					$('#vgmap-location-e-link').text('<?php echo elgg_echo('vazco_gmap:location:reselect');?>');
					$('#vgmap-location-e-link').attr('class','location_select location_selected');
				}
				function setAsUnmarked(){
					$('#vgmap-location-e-link').text('<?php echo elgg_echo('form:location:select');?>');
					$('#vgmap-location-e-link').attr('class','location_select');
				}

				<?php //marks point on the map, and sends it's value to form's element ?>		
				function mark_point(map, point){
						document.getElementById('<?php echo $location['elementId'];?>').value = point; //models field name
						setAsMarked();
						map.addOverlay(new GMarker(point));
				}
					
			<?php //interface-related functions ?>
		    function showLocationPicker(){
		    	currloc = $("#<?php echo $location['elementId'];?>").val();
		    	if (currloc == ''){
			    	currloc = address;
			    	document.getElementById('<?php echo $location['elementId'];?>').value = address;
		    	}
			    if (!showThisLocation(currloc,map,false))
			    	jumpToAddress(currloc,map);

		    	$("#<?php echo $location['bckgId'];?>").fadeTo(0, 0.6);
		    	$("#<?php echo $location['centererId']; ?>").css('top','100px');
		    	$("#<?php echo $location['bckgId'];?>").css('top',0);
				return false;
		    }

		    function hideLocationPicker(){
		    	$("#<?php echo $location['bckgId'];?>").fadeTo(0, 0);
		    	$("#<?php echo $location['centererId']; ?>").css('top','-40000px');
		    	$("#<?php echo $location['bckgId'];?>").css('top','-40000px');
		    	$("#<?php echo $location['notifierId'];?>").hide();
				return false;			    
		    }

		    function showLocationSelectNotifier(){
		    	$("#<?php echo $location['notifierId'];?>").show();
		    }

			function jumpToSelectedAddress(){
				var value = $('#<?php echo $location['addressId'];?>').val();
				if ( value !='')
					jumpToAddress(value,map);
			}
		    
		    $('#<?php echo $location['linkId'];?>').click(function() {
		    		return showLocationPicker();
			   });
			$('#<?php echo $location['bckgId'];?>').click(function() {
					return hideLocationPicker();
			});

		    $('#<?php echo $location['cancelId'];?>').click(function() {
				map.clearOverlays();
				$("#<?php echo $location['elementId'];?>").val('');
				setAsUnmarked();
		    	return hideLocationPicker();
		   });
		    $('#<?php echo $location['saveId'];?>').click(function() {
			    if ( $('#<?php echo $location['elementId'];?>').val()!='')
					return hideLocationPicker();
			    else
				    return showLocationSelectNotifier();
		   		});
			$('#<?php echo $location['addressId'];?>').keypress(function (e) {
					if (e.which == 13){ //in case enter is pressed
						jumpToSelectedAddress();
						e.stopPropagation();
					}
				});
		    $('#<?php echo $location['jumpId'];?>').click(function() {
			    jumpToSelectedAddress();
			    return false;
		   		});
				
			$('#<?php echo $location['containerId'];?>').click(function(e) {
				e.stopPropagation();
			});

			$('#<?php echo $location['centererId'];?>').click(function(e) {
				return hideLocationPicker();
		   	});
		  });
		</script>
	<?php
			}//end of if canEdit
		}//end of request loop
	}//enf of if request set
	?>