<?php
global $CONFIG;

$title = $vars['title'];
$limit = $vars['limit'];
$type = $vars['type']; // type of displayed entity. It defines which view file from map/$viewtype/ is being used

if (!$limit)
	$limit = 10;

//by default, set to galleryview. Other view types are: list, xml, xml-element
if (!$viewtype)
	$viewtype = 'galleryview';
/*
 * those are set by URL's of objects in a gallery
 * 
$viewtype = $vars['viewtype'];
$longitudeMin = $vars['longMin'];
$longitudeMax = $vars['longMax'];
$latitudeMin = $vars['latMin'];
$latitudeMax = $vars['latMax'];

set_input('lat_max', $latitudeMax);
set_input('long_max', $longitudeMax);
set_input('lat_min', $latitudeMin);
set_input('long_min', $longitudeMin);
set_input('viewtype',$viewtype);
*/
set_input('limit', $limit);
set_input('type', $type);
//set 0 radius for exact matches
set_input('radius', 0);

/*
 * List of objects displayed by location
 * 
 * */ 
?>
<script type='text/javascript'>
	$(document).ready(function() {	
		$("#toggle_map_selected").click(function() {
		    	var elem = $("#toggle_map_selected");
				var content = $("#map_entities_content");
		    	animateBox(elem, content);
		});
	});
</script>
<div id="map_entities" class="map_entities">
	<div class="map_entities_header">
		<div class="group_count group_bottom"><?php echo $title;?></div>
		<a id="toggle_map_selected" class="toggle_box" href="javascript:void(0);">-</a>
	</div>
	<div id="map_entities_content" class="map_entities_content">
		<?php require_once($CONFIG->pluginspath.'vazco_gmap/listentities.php');?>
	</div>
</div>