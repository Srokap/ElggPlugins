<?php

	/*
  	 * @package Elgg
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Michal Zacher [michal.zacher@gmail.com]
	 * @remarks In case you need any help with this plugin, geocoding or reverse geocoding, please contact me and I may be able to help.
	*/

?>
<p>
<?php
echo elgg_view('vazco_gmap/input/location', array('internalname'=>'params[location]',
                                   'entity'=>$vars['entity'], 'controls'=>'GLargeMapControl3D'));

echo elgg_echo("gmap:zoom"); 
$zoom = GMAP_DEFAULT_ZOOM;
if (isset($vars['entity']->zoom)) {
  $zoom = $vars['entity']->zoom;
}
echo elgg_view('input/pulldown', array('internalname'=>'params[zoom]',
                                       'value'=>$zoom,
                                       'options'=>array(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,18,19,20)));
echo "<br />";

echo elgg_echo("gmap:id"); 
echo elgg_view('input/text', array('internalname'=>'params[id]',
                                   'value'=>$vars['entity']->id));
?>
</p>