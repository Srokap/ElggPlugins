<?php
require_once(dirname(dirname(__FILE__)).'/models/model.php');

openid_client_handle_login();
