<?php
	/**
	 * Init.
	 *
	 */
	require_once(dirname(__FILE__)."/models/model.php");

	function vazco_subscriber_init()
	{
		//group plugin disabled : no need to go further...
        if (!is_plugin_enabled("groups"))
            return;
        
        global $CONFIG;

        //Listen to user registration
	    register_elgg_event_handler('create', 'user', 'vazco_subscriber_group_join',502); 
		
		// Add some widgets
		if (is_plugin_enabled('file')){
			add_widget_type('subscribed_files',elgg_echo('vazco_subscriber:files'), elgg_echo('vazco_subscriber:files:description'),'dashboard');
		}
		
		register_action("vazco_subscriber/add",false,$CONFIG->pluginspath . "vazco_subscriber/actions/add.php");
		register_action("vazco_subscriber/remove",false,$CONFIG->pluginspath . "vazco_subscriber/actions/remove.php");
		register_action("vazco_subscriber/relate",false,$CONFIG->pluginspath . "vazco_subscriber/actions/relate.php");
		register_action("vazco_subscriber/unrelate",false,$CONFIG->pluginspath . "vazco_subscriber/actions/unrelate.php");
		extend_view('css','vazco_subscriber/css');

	}
    
    /**
    *auto join group define in plugin settings
    *
    */
    function vazco_subscriber_group_join($event, $object_type, $object){
        global $CONFIG;
        
        if (($object instanceof ElggUser) && ($event == 'create') && ($object_type == 'user')) {
            //auto submit relashionships between user & groups
            
            //retrieve groups ids from plugin
            $groups = get_plugin_setting('systemgroups');
            $groups = split(',',$groups);
        
            //for each group ids
            foreach ($groups as $groupId){
            
                //if group exist : submit to group
                if ($groupEnt = get_entity($groupId)){
                
                    //join group succeed ?
                    if ($groupEnt->join($object))
                    {
                        // Remove any invite or join request flags
                        remove_metadata($object->guid, 'group_invite', $groupEnt->guid);
                        remove_metadata($object->guid, 'group_join_request', $groupEnt->guid);
                        
                    }
					
                }
            }
            vazco_subscriber::subscribe($object);
        }
        
    }
   
   register_elgg_event_handler('init', 'system', 'vazco_subscriber_init');
    
?>