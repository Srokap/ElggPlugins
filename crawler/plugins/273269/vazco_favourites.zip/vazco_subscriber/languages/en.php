<?php
	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'autosubscribe' => 'Auto-subscription to group',
			'autosubscribe:list' => "ID's of a groups for which new users should be automatically subscribed: (separated by comma)",
			'vazco_subscriber:files' => 'Bookmarked files',
			'vazco_subscriber:pages' => 'Bookmarked pages',
			'vazco_subscriber:events' => 'Bookmarked events',
			'vazco_subscriber:events:description' => 'Displays events that administrator or you marked as important',
			'vazco_subscriber:files:description' => 'Displays files that administrator or you marked as important',
			'vazco_subscriber:pages:description' => 'Displays pages that administrator or you marked as important',
			'vazco_subscriber:title' => 'Subscriber plugin',
			'vazco_subscriber:added' => 'Added to featured',
			'vazco_subscriber:notadded' => 'Not added to featured',
			'vazco_subscriber:removed' => 'Removed from featured',
			'vazco_subscriber:notremoved' => 'Not removed',
			'vazco_subscriber:makefeatured' => 'Feature',
			'vazco_subscriber:removefeatured' => 'Unfeature',
			'vazco_subscriber:limit' => 'Number of items to display',
	
			'vazco_subscriber:related' => 'Added to bookmarked',
			'vazco_subscriber:notrelated' => 'Not added to bookmarked',
			'vazco_subscriber:unrelated' => 'Removed from bookmarked',
			'vazco_subscriber:notunrelated' => 'Not removed from featured',
			'vazco_subscriber:relate' => 'Bookmark',
			'vazco_subscriber:unrelate' => 'Unbookmark',
			'vazco_karma:settings:favourite' => 'Favourite content',
	
			/*Widget*/
			'vazco_subscriber:all' => 'All',
			'vazco_subscriber:featured' => 'Featured',
			'vazco_subscriber:notfeatured' => 'Mine',
	);
    
	add_translation("en",$english);
?>