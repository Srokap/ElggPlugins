<?php

admin_gatekeeper();
$guid = get_input('guid',0);

if (vazco_subscriber::unfeature($guid)){
	system_message(elgg_echo('vazco_subscriber:removed'));
}else{
	register_error(elgg_echo('vazco_subscriber:notremoved'));
}
forward($_SERVER['HTTP_REFERER']);
?>