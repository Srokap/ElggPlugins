<?php 
$entity_guid = get_input('guid',0);
if (vazco_subscriber::subscribeTo(get_loggedin_userid(),$entity_guid)){
	system_message(elgg_echo('vazco_subscriber:related'));
}else{
	register_error(elgg_echo('vazco_subscriber:notrelated'));
}
forward($_SERVER['HTTP_REFERER']);
?>