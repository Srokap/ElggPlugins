<?php 
$entity_guid = get_input('guid',0);
if (vazco_subscriber::unsubscribe(get_loggedin_userid(),$entity_guid)){
	system_message(elgg_echo('vazco_subscriber:unrelated'));
}else{
	register_error(elgg_echo('vazco_subscriber:notunrelated'));
}
forward($_SERVER['HTTP_REFERER']);
?>