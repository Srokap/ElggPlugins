<?php
admin_gatekeeper();
$guid = get_input('guid',0);

if (vazco_subscriber::makeFeatured($guid)){
	system_message(elgg_echo('vazco_subscriber:added'));
}else{
	register_error(elgg_echo('vazco_subscriber:notadded'));
}
forward($_SERVER['HTTP_REFERER']);
?>