<?php
	/**
	 * Edit the widget
	 * 
	 * @package ElggGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */
?>
<p>
	<?php echo elgg_echo('vazco_subscriber:limit'); ?>
	
	<select name="params[limit]">
		<option value="3" <?php if ($vars['entity']->limit == 3) echo " selected=\"yes\" "; ?>>3</option>
		<option value="4" <?php if ((!$vars['entity']->limit) || ($vars['entity']->limit == 4)) echo " selected=\"yes\" "; ?>>4</option>
		<option value="6" <?php if ($vars['entity']->limit == 6) echo " selected=\"yes\" "; ?>>6</option>
		<option value="8" <?php if ($vars['entity']->limit == 8) echo " selected=\"yes\" "; ?>>8</option>
	</select>
</p>