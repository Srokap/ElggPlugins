.pages_makefeatured{
	float: right;
}

.pages_makefeatured a{
	margin: 0 5px;
}

.subscrbuttons{
	margin:0;
}

.vs_controls .cont div{
	cursor:pointer;
	border: #0054A7 1px solid;
	background: white;
	float: left;
	margin: 0 10px 0 0;
	padding:2px 5px;
}

.vs_controls div:hover{
	background:#4690D6;
}
.vs_controls{
	margin: 0px;
	padding: 5px 15px;
}

.vs_controls .cont div.vs_c_active{
	background:#7BB4EB;
}