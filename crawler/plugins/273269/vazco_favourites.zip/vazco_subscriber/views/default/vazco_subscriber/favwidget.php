<?php
	/**
	 * View the widget
	 * 
	 * @package ElggGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */
	$owner_guid = page_owner();
	$limit = $vars['$limit'];
	if (!$limit)
		$limit = 8;
	$type = $vars['type'];
	
	if ($vars['entity']->limit)
		$limit = $vars['entity']->limit;

	//get ALL featured entities
	$entities = get_entities_from_relationship('featured',$owner_guid,true,'object',$type,0,"",99);
	$featured = vazco_subscriber::getFeaturedFrom($entities);
	$notFeatured = vazco_subscriber::getNotFeaturedFrom($entities);
	
	$context = get_context();
	set_context('search');
	
	//show limited amount
	$list = elgg_view_entity_list($entities,false,0,$limit, false);
	$featuredList  = elgg_view_entity_list($featured,false,0,$limit, false);
	$notFeaturedList  = elgg_view_entity_list($notFeatured,false,0,$limit, false);
	
	set_context($context);
?>

<script language="JavaScript">
	function vs_c_removeClass<?php echo $type;?>(){
		$("#vs_c_all<?php echo $type;?>").removeClass("vs_c_active");
		$("#vs_c_featured<?php echo $type;?>").removeClass("vs_c_active");
		$("#vs_c_notfeatured<?php echo $type;?>").removeClass("vs_c_active");
	}
	function vs_c_1<?php echo $type;?>() {
		$("#vs_all<?php echo $type;?>").animate({ height: 'show', opacity: 'show' }, 'slow');
		$("#vs_featured<?php echo $type;?>").animate({ height: 'hide', opacity: 'hide' }, 'slow');
		$("#vs_notfeatured<?php echo $type;?>").animate({ height: 'hide', opacity: 'hide' }, 'slow');
		vs_c_removeClass<?php echo $type;?>();
		$("#vs_c_all<?php echo $type;?>").addClass("vs_c_active");			
	}
	function vs_c_2<?php echo $type;?>() {
		$("#vs_all<?php echo $type;?>").animate({ height: 'hide', opacity: 'hide' }, 'slow');
		$("#vs_featured<?php echo $type;?>").animate({ height: 'show', opacity: 'show' }, 'slow');
		$("#vs_notfeatured<?php echo $type;?>").animate({ height: 'hide', opacity: 'hide' }, 'slow');
		vs_c_removeClass<?php echo $type;?>();
		$("#vs_c_featured<?php echo $type;?>").addClass("vs_c_active");
	}
	
	function vs_c_3<?php echo $type;?>() {
		$("#vs_all<?php echo $type;?>").animate({ height: 'hide', opacity: 'hide' }, 'slow');
		$("#vs_featured<?php echo $type;?>").animate({ height: 'hide', opacity: 'hide' }, 'slow');
		$("#vs_notfeatured<?php echo $type;?>").animate({ height: 'show', opacity: 'show' }, 'slow');
		vs_c_removeClass<?php echo $type;?>();
		$("#vs_c_notfeatured<?php echo $type;?>").addClass("vs_c_active");
	}
</script>



<div class="vs_controls">
	<div  class="cont">
		<div id="vs_c_featured<?php echo $type;?>" onclick="javascritp:vs_c_2<?php echo $type;?>();"  class="vs_c_active">
			<?php echo elgg_echo('vazco_subscriber:featured');?>
		</div>
		<div id="vs_c_notfeatured<?php echo $type;?>" onclick="javascritp:vs_c_3<?php echo $type;?>();">
			<?php echo elgg_echo('vazco_subscriber:notfeatured');?>
		</div>
		<div id="vs_c_all<?php echo $type;?>" onclick="javascritp:vs_c_1<?php echo $type;?>();">
			<?php echo elgg_echo('vazco_subscriber:all');?>
		</div>		
	</div>
	<div class="clearfloat"></div>
</div>


<div id="vs_featured<?php echo $type;?>" style="display:none;">
	<?php echo $featuredList;?>
</div>
<div id="vs_notfeatured<?php echo $type;?>">
	<?php echo $notFeaturedList;?>
</div>
<div id="vs_all<?php echo $type;?>" style="display:none;">
	<?php echo $list;?>
</div>