<?php 
	$entity = $vars['entity'];
	$dontclearfloat = $vars['dontclearfloat'];
	$clearfloat = "";
	if (!$dontclearfloat)
		$clearfloat = "<div class='clearfloat subscrbuttons'></div>";
	if (isloggedin()){
		if (vazco_subscriber::belongsTo(get_loggedin_userid(), $entity->guid)){
			$actionButton1 = "<a href='".$CONFIG->wwwroot."action/vazco_subscriber/unrelate?guid=".$entity->guid."'>".elgg_echo('vazco_subscriber:unrelate')."</a>";		
		}else{
			$actionButton1 = "<a href='".$CONFIG->wwwroot."action/vazco_subscriber/relate?guid=".$entity->guid."'>".elgg_echo('vazco_subscriber:relate')."</a>";
		}
	}
	$actionButton2 = "";
	if (isadminloggedin()){
		if ($entity->featured){
			$actionButton2 = "<a href='".$CONFIG->wwwroot."action/vazco_subscriber/remove?guid=".$entity->guid."'>".elgg_echo('vazco_subscriber:removefeatured')."</a>";		
		}else{
			$actionButton2 = "<a href='".$CONFIG->wwwroot."action/vazco_subscriber/add?guid=".$entity->guid."'>".elgg_echo('vazco_subscriber:makefeatured')."</a>";
		}
	}
	
	$buttons .= "<span class='pages_makefeatured'>".$actionButton1.$actionButton2."</span>{$clearfloat}";

	echo $buttons;
?>