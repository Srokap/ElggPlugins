<?php

	/**
	 * Elgg autosubscribegroup plugin
	 * This plugin allows new user to join a group when registering
	 * 
	 * @package autosubscribegroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author RONNEL J�r�my
	 * @copyright (c) Elbee 2008
	 * @link /www.notredeco.com
	 */

?>	 

	<p>
	<?php echo elgg_echo('autosubscribe:list'); ?>:
	<?php
		echo elgg_view('input/text', array('internalname' => 'params[systemgroups]', 'value' => $vars['entity']->systemgroups));
		echo "<p>&nbsp;</p>"
	?>
    </p>