<?php

	/**
	* Flyers
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	function flyers_init() {
		//Event to act!
		register_elgg_event_handler('login', 'user', 'flyer_clear_user_meta');
		
		//Page Handler
		register_page_handler('flyer','flyer_page_handler');
		extend_view('page_elements/header_contents', 'flyer/js/lbfunctions_js', 1);
		
		extend_view('css', 'flyer/css');
		
		//Print the plugin version
		extend_view('metatags', 'flyer/version');
	}
	
	function flyers_setup() {
		global $CONFIG;
		if (get_context()=='admin') {
    		add_submenu_item(elgg_echo("flyer"), $CONFIG->wwwroot . "pg/flyer/setup" );
		}
		
		if (isloggedin()) {
			$site = get_entity(datalist_get('default_site'));
			$user = get_loggedin_user();
						
			if($user->show_welcome_flyer && $site->show_welcome_flyer && !$user->flyerwelcomeseen) {
				//Show the flyer
				extend_view('page_elements/header_contents', 'flyer/show_flyer', 2);
			}
			
			if (!$user->show_welcome_flyer && $site->showflyer && !($user->flyerseen)) {
				//Show the flyer
				extend_view('page_elements/header_contents', 'flyer/show_flyer', 2);
				$user->flyerseen = true;
				
				if($site->showonlyonetime) {
					$user->flyertime = $site->showonlyonetime;
				}
			}
		}
	}
	
	function flyer_page_handler($page) {
		global $CONFIG;
		if (isset($page[0])) {
			switch($page[0]) {
				case "setup":
					!@include_once(dirname(__FILE__) . "/flyer_setup.php");
					return false;
          			break;
			}
		}
	}
	
	/**
	 * This function clear the metadata flyerseen, when a user is loggin in.
	 * @param String $event
	 * @param String $object_type
	 * @param Object $object
	 */
	function flyer_clear_user_meta($event, $object_type, $object) {
		
		if($event == 'login' && $object_type=='user' && $object instanceof ElggUser) {
			//Clear metadata.
			$site = get_entity(datalist_get('default_site'));
			
			if(!$site->showonlyonetime || ($site->showonlyonetime && $object->flyertime != $site->showonlyonetime)) {
				$object->clearMetadata('flyerseen');
			}

			if(!$object->prev_last_action) {
				$object->show_welcome_flyer = true;
				
			} else if($object->show_welcome_flyer) {
				//Clear metadata.
				$object->clearMetadata('show_welcome_flyer');
				$object->clearMetadata('flyerwelcomeseen');
			}
		}
		
		return true;
	}
	
	function flyer_ping_home() {
    	$NOTIFICATION_SERVER = "http://www.keetup.com/services/api/rest/php/";
    	// Get version information
		$version = get_version();
		$release = get_version(true);	
		
		$site = get_entity(datalist_get('default_site'));
		$sitename = $site->name;
//		if (is_callable('mb_encode_mimeheader')) {
//			$sitename = mb_encode_mimeheader($site->name,"UTF-8", "B");
//		}
		
		
		send_api_get_call(
			$NOTIFICATION_SERVER,
			array(
				'method' => 'keetup.system.ping',
			
				'pluginname' => 'flyer',
				'sitename' => $sitename,
				'url'	  => $site->url,
				'version' => $version,
				'release' => $release,
			),
			array()
		);
    }
    
    function flyer_get_version($humanreadable = false){
	    if (include(dirname(__FILE__) . "/version.php")) {
			return (!$humanreadable) ? $version : $release;
		}
		return FALSE;
    }
	
	// Initialise Flyers Mod
	register_elgg_event_handler('init','system','flyers_init');
	register_elgg_event_handler('pagesetup','system','flyers_setup', 1);

	//	Flyer Actions
	register_action("flyer/toggle", false, $CONFIG->pluginspath . "flyers/actions/flyer_toggle.php");
	register_action("flyer/set_content", false, $CONFIG->pluginspath . "flyers/actions/flyer_set_content.php");