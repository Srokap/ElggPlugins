<?php

	/**
	* Flyers
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
	
	admin_gatekeeper();
	
	$site = get_entity(datalist_get('default_site'));
	$content_saved = false;

//Welcome Flyer
	$show_welcome_flyer	= get_input('show_welcome_flyer');
	$flyer_welcome_content = get_input('flyer_welcome_content');
	 
//Main Flyer
	$showflyer	= get_input('showflyer');
	$flyer_content = get_input('flyer_content');
	$siteannouncement = get_input('siteannouncement');
	$showonlyonetime = get_input('showonlyonetime');
	
	
	if ($site) {
	//Welcome Flyer
		if($show_welcome_flyer == 'yes') {
			$site->show_welcome_flyer = true;
		} else {
			remove_metadata($site->guid, 'show_welcome_flyer');
		}
		
		//Flyer Content
		if ($flyer_welcome_content && !empty($flyer_content)) {
			$site->flyer_welcome_content = $flyer_welcome_content;
		}
	
	//Main Flyer		
		if($showflyer == 'yes') {
			$site->showflyer = true;
		} else {
			remove_metadata($site->guid, 'showflyer');
		}

		//If the content is get from siteannouncement
		if ($siteannouncement) {
			$site->flyer_siteannouncement = $siteannouncement;
		} 
		
		//Flyer Content
		if ($flyer_content && !empty($flyer_content)) {
			$site->flyer_content = $flyer_content;
		}
			
		//Show only one time
		if($showonlyonetime == "yes") {
			//Set the time of the content.
			$site->showonlyonetime = time();
		} else {
			$site->showonlyonetime = null;
		}
		
		$content_saved = true; 
	}
	
	if ($content_saved) {
		system_messages(elgg_echo('flyer:contentsaved'));
	} else {
		system_messages(elgg_echo('flyer:contenterror'));
	}
	forward($_SERVER['HTTP_REFERER']);
?>