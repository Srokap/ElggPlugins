<?php
	/**
	* Flyers
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	$spanish = array(
		
	//Submenu
		'flyer' => 'Flyer',
	
	//Button
		'flyer:disable' => "Esconder el flyer",
		'flyer:enable' => "Mostrar el flyer",
		'flyer:showsiteannounces' => "Mostrar los anuncios del sitio en el mensaje en vez del mensaje superior.",
		'flyer:showonlyonetime' => "Mostrar el flyer por unica vez.",
	
	//Status
		'flyer:enabled' => "Mostrar el flyer",
		'flyer:disabled' => "Ocultar el flyer",
		'flyer:contentsaved' => 'El contenido ha sido guardado con éxito.',
		'flyer:contenterror' => 'Hubo un problema al intentar guardar el contenido, por favor inténtelo nuevamente.',
		
	//Other Stuff
		'flyer:description' => 'Necesita mostrar/ocultar el flyer?',
		'flyer:putacontent' => 'Por favor ingrese el mensaje que se mostrará en el flyer.',
	);
					
	add_translation("es",$spanish);