<?php

	/**
	* Flyers
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	// Get the Elgg engine
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	
	admin_gatekeeper();
	
	set_context('admin');
	$site = get_entity(datalist_get('default_site'));
	$flyer_content = $site->flyer_content;
	$flyer_welcome_content = $site->flyer_welcome_content;	
	
	//if ($site->showflyer) {
		//$flyer_activate_btn .= elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('flyer:disable')));

	//Welcome flyer
		$fwelcome_main_title = elgg_echo('flyer:welcome');
		$fwelcome_title = elgg_echo('flyer:welcome:title');
		$fwelcome_longtext = elgg_view('input/longtext', array('value' => $flyer_welcome_content, 'internalname' => 'flyer_welcome_content'));
		
		$fwelcome_enalbed_title = elgg_echo('flyer:welcome_enable:title');
		$fwelcome_enabled_pulldown =  "
			<select name=\"show_welcome_flyer\">
				<option value=\"yes\"" . (($site->show_welcome_flyer == "yes")? "selected=\"yes\"" : "") . ">" . elgg_echo('option:yes') . "</option>
				<option value=\"no\"" . (($site->show_welcome_flyer == "no" || is_null($site->show_welcome_flyer))? "selected=\"yes\"" : "") . ">" . elgg_echo('option:no') . "</option> 
			</select>";

	//Main Flyer	
		$flyer_main_title = elgg_echo('flyer');	
		$form2_description = elgg_echo('flyer:putacontent');
		$form2_longtext = elgg_view('input/longtext', array('value' => $flyer_content, 'internalname' => 'flyer_content'));

		$flyer_main_enable_title = elgg_echo('flyer:enable:title');
		$flyer_main_enabled_pulldown =  "
			<select name=\"showflyer\">
				<option value=\"yes\"" . (($site->showflyer == "yes")? "selected=\"yes\"" : "") . ">" . elgg_echo('option:yes') . "</option>
				<option value=\"no\"" . (($site->showflyer == "no" || is_null($site->showflyer))? "selected=\"yes\"" : "") . ">" . elgg_echo('option:no') . "</option> 
			</select>";
		
		$form2_description2 = elgg_echo('flyer:showsiteannounces');
		$yes_option = ($site->flyer_siteannouncement == 'yes') ? " selected=\"yes\"" : "";
		$no_option = ($site->flyer_siteannouncement == 'no' || is_null($site->flyer_siteannouncement)) ? " selected=\"yes\"" : "";
		$pulldown =  "
			<select name=\"siteannouncement\">
				<option value=\"yes\"" . $yes_option . ">" . elgg_echo('option:yes') . "</option>
				<option value=\"no\"" . $no_option . ">" . elgg_echo('option:no') . "</option> 
			</select>";

		$pulldown2_description = elgg_echo('flyer:showonlyonetime');
		
		$showonlyonetime_yes = ($site->showonlyonetime) ? " selected=\"yes\"" : "";
		$showonlyonetime_no = (is_null($site->showonlyonetime)) ? " selected=\"yes\"" : "";
		
		$pulldown2 =  "
			<select name=\"showonlyonetime\">
				<option value=\"yes\"" . $showonlyonetime_yes . ">" . elgg_echo('option:yes') . "</option>
				<option value=\"no\"" . $showonlyonetime_no . ">" . elgg_echo('option:no') . "</option> 
			</select>";
		
		$form_body2 .= <<<EOT
			<h3>$fwelcome_main_title</h3>
			<p>$fwelcome_title</p>
			$fwelcome_longtext
			<p> $fwelcome_enalbed_title : $fwelcome_enabled_pulldown	</p>
			<hr />
			<h3>$flyer_main_title</h3>			
			<p>$form2_description</p>
			$form2_longtext
			<p> $flyer_main_enable_title : $flyer_main_enabled_pulldown </p>
			<p>$form2_description2 : $pulldown </p>
			<p>$pulldown2_description : $pulldown2 </p>
EOT;
		$form_body2 .= elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('save')));
		$content2 = elgg_view('input/form', array('action' => "{$CONFIG->url}action/flyer/set_content", 'body' => $form_body2));
/*	} else {
		$flyer_activate_btn .= elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('flyer:enable')));	
	}

	$flyer_description = elgg_echo('flyer:description');
	$form_body = "<p>$flyer_description</p> $flyer_activate_btn";	
	
	$toggle_form = elgg_view('input/form', array('action' => "{$CONFIG->url}action/flyer/toggle", 'body' => $form_body));
*/	
	$content = <<<EOT
		<div class='flyer_container'>
			<!--$toggle_form--> 
			$content2
		</div>
	
EOT;
	$body = elgg_view_layout('two_column_left_sidebar', '', $content . elgg_view('developed_by_keetup'));
	page_draw($title, $body);
?>