<?php
	run_function_once("flyer_ping_home");