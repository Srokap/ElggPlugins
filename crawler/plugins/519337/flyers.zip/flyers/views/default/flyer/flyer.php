<?php
	/**
	* Flyers
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	
?>	

	<script type="text/javascript">
        jQuery(document).ready(
            function() {
				$('.lbHome .lightbox-content').html("<?php echo $vars['content'] ?>").addClass('flyer-content');
                showLB('.lbHome');
            }
        );
	</script>