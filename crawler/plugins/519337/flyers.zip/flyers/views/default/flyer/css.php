<?php
	/**
	* Flyers
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/
?>
	/*Flyer*/
    .flyer_container {
    	padding: 10px;
    }
    
    
	/* lightbox */
    #fonLB {
        width: 100%;
        height: 100%;
        background: #000;
        position: absolute;
        top: 0;
        left: 0;
        z-index: 12345;
        display: none;
    }
    .lb {
        display: none;
        position: absolute;
        top: 50px;
        left: 25%;
        z-index: 123456;
    }
    .lbHome {
       	background: #FFF;
    	border: 10px solid #999;
        padding: 30px 10px 10px;
        width: 580px;
    }
    .lbHome img {
        display: block;
        position: relative;
        z-index: 1;
        top: 0;
        left: 0;
    }
    .lbHome .cerrar {
        background: red;
        border: 1px solid #CCC;
        color: #FFF;
        cursor: pointer;
        font-family: Arial, Lucida, Lucida Sans;
        font-size: 11px;
        font-weight: bold;
        height: 16px;
        line-height: 17px;
        padding: 0 0 1px 1px;
        position: absolute;
        right: 3px;
        text-align: center;
        top: 3px;
        width: 16px;
        z-index: 123;
    }
    /* end of lightbox */