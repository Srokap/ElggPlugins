<?php
	/**
	* Flyers
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	$site = get_entity(datalist_get('default_site'));
	
	$user = get_loggedin_user();
	
	if($user->show_welcome_flyer && $site->show_welcome_flyer && !$user->flyerwelcomeseen) {
		$flyer_content = $site->flyer_welcome_content;
		$user->flyerwelcomeseen = true;
	} else {
		if ($site->flyer_siteannouncement == 'yes') {
			$site_message = get_entities("object", "sitemessage", 0, "", 1);
			foreach($site_message as $mes){
				$flyer_content = $mes->description;
			}
				
		
		} else {
			$flyer_content = $site->flyer_content;
		}
	}
	
	
	if (!$flyer_content) {
		$flyer_content = <<< EOT
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas aliquam, dui at rutrum porta, nisi lectus elementum leo, a egestas mauris libero tempor arcu.
			   Aliquam vel velit at urna mollis euismod vel adipiscing neque. Nulla tempus nibh nec neque ultricies nec faucibus risus lacinia. Aliquam ultrices gravida nisl, quis euismod turpis semper nec.
			</p> 
			<p>
				Nullam varius iaculis odio in ornare. Nulla augue diam, posuere ut fringilla eu, elementum nec sem. Aliquam erat volutpat. Nullam malesuada risus condimentum velit ultrices at dignissim sapien pharetra. 
				In hac habitasse platea dictumst. Vivamus et libero a odio tempus vehicula in eget arcu. Pellentesque egestas massa ac lectus egestas molestie.
			</p>  
EOT;
	}
	echo elgg_view('flyer/flyer', array('content' => $flyer_content));