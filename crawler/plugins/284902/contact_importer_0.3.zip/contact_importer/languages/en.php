<?php

    /**
    * Contact Importer Plugin (using OpenInviter)
    *
    * @package ElggContactImporter
    * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
    * @author Prashant Juvekar
    * @copyright SocialTrak, 2009
    * @link http://www.socialtrak.com
    */

	$english = array(

		'contact_importer:plugin:name' => 'Import Contacts',
		'contact_importer:title' => 'Import Contacts',

		'contact_importer:email:subject' => 'Invitation to join %s',
		'contact_importer:email:mailbody' => '
You have been invited to join %s by %s. 
To join, click the following link:

	%s',
	
	);
					
	add_translation("en",$english);
?>