<?php
$openinviter_settings=array(
'username'=>"pjuvekar",
'private_key'=>"a72c5cff8f92dab96232502e105e60fd",
'cookie_path'=>"/tmp",
'message_body'=>"You are invited to ...",
'message_subject'=>" is inviting you to ...",
'transport'=>"curl",
'local_debug'=>"on_error",
'remote_debug'=>false,
'plugins_cache_time'=>"1800",
'update_files'=>true,
'hosted'=>false,
'proxies'=>array(),
'stats'=>false,
'stats_user'=>"",
'stats_password'=>""
);
?>