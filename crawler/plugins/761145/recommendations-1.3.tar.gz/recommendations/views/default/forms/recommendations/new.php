<?php
/**
 *	Recommendations Plugin
 *
 *	@package recommendations
 *	@author Liran Tal <liran.tal@gmail.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 */

?>

<?php
	// get entity_id of which we want to recommend
	// if it isn't set, -1 is set by default and we handle that error
	$entity_id = get_input("entity_id", 0);
	if ($entity_id) {
		$recommended_user = get_entity($entity_id);
		$value = $recommended_user->name;
	} else {
		$value = elgg_echo('recommendations:typefriend');
	}

?>

<h3>
	<?php echo elgg_echo('recommendations:new_recommendation'); ?>
</h3>

<div class="contentWrapper">
<form action="<?php echo $vars['url']; ?>action/recommendations/new" enctype="multipart/form-data" method="post">
<?php echo elgg_view('input/securitytoken'); ?>


<p>
	<label>
		
		<?php
			if (is_plugin_enabled('custom_inputs')):
				$javascript = "onclick=\"if (this.value=='".elgg_echo('recommendations:typefriend')."') { this.value='' }\"";
				echo elgg_view("input/autocomplete_myfriends_images_guid", 
								array(
									'noredirect' => true,
									'internalname' => 'recommendation_to',
									'value' => $value,
									'javascript' => $javascript,
								)
							); 
						
				if ($entity_id):
				?>

					<script type="text/javascript">
						$('input[name="recommendation_to"]').val('<?php echo $entity_id; ?>');
					</script>
		
				<?php 
				endif;

			else: 
		?>
		
				<select name="recommendation_to">
				<?php if ($entity_id): ?>
					<option value="<?=$recommended_user->guid?>"><?=$recommended_user->name?></option>
					<option value=""></option>
				<?php else: ?>
					<option value=""><?=elgg_echo('recommendations:selectfriend');?></option>
				<?php endif; ?>
				<?php
					$friends = get_user_friends($_SESSION['user']->getGUID(), null, 1000, 0);
					foreach($friends as $friend):
				?>	
					<option value="<?=$friend->guid?>"><?=$friend->name?></option>
				<?php endforeach; ?>
				</select>
				
		<?php endif; ?>

	</label>
</p>


	

<p>
	<label>
		<?php echo elgg_echo("recommendations:title"); ?><br />
		<?php echo elgg_view('input/text', array('internalname' => 'recommendation_title',
												'value' => $vars['entity']->title,
												)); ?>
		<p class="description"><?php echo elgg_echo('recommendations:title:helper') ?> </p>
	</label>
</p>

<p>
	<label>
		<?php echo elgg_echo("recommendations:text"); ?><br />
		<?php echo elgg_view('input/longtext', array('internalname' => 'recommendation_text',
												'value' => $vars['entity']->description,
												)); ?>
		<p class="description"><?php echo elgg_echo('recommendations:text:helper') ?> </p>
	</label>
</p>


<p><input type="submit" value="<?php echo elgg_echo('recommendations:send'); ?>" /></p>
 
</form>
</div>
