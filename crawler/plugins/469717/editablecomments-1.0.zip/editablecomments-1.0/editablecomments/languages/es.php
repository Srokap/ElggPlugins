<?php

// Generado por translationbrowser 

$spanish = array( 
	 'comment:edited'  =>  "Comentario editado",
	 'comment:error'  =>  "Error grabando el comentario"
); 

add_translation('es', $spanish); 

?>
