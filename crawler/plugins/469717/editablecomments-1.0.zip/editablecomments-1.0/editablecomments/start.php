<?php

function editable_comments_init() {
	global $CONFIG;
        register_action('comments/edit', false, $CONFIG->pluginspath . "editablecomments/actions/edit.php");
}

register_elgg_event_handler('init','system','editable_comments_init');

?>
