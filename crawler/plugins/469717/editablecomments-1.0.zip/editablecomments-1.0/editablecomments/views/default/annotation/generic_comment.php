<?php
/**
 * Elgg generic comment
 *
 * @package Elgg
 * @subpackage Core
 * @author Curverider Ltd
 * @link http://elgg.org/
 *
 */

$owner = get_user($vars['annotation']->owner_guid);

?>
<div class="generic_comment"><!-- start of generic_comment div -->

	<div class="generic_comment_icon">
		<?php
			echo elgg_view("profile/icon",
				array(
					'entity' => $owner,
					'size' => 'small'
				)
			);
		?>
	</div>
	<div class="generic_comment_details">

		<!-- output the actual comment -->
		<?php echo elgg_view("output/longtext",array("value" => $vars['annotation']->value)); ?>

		<p class="generic_comment_owner">
			<a href="<?php echo $owner->getURL(); ?>"><?php echo $owner->name; ?></a> <?php echo friendly_time($vars['annotation']->time_created); ?>
		</p>

		<?php

			// if the user looking at the comment can edit, show the delete link
			if ($vars['annotation']->canEdit()) {

			?>
		<p>
			<?php

				echo elgg_view("output/confirmlink",array(
					'href' => $vars['url'] . "action/comments/delete?annotation_id=" . $vars['annotation']->id,
					'text' => elgg_echo('delete'),
					'confirm' => elgg_echo('deleteconfirm'),
				));
                                        //display an edit link that will open up an edit area                                                   
                                        echo " <a class=\"collapsibleboxlink\">".elgg_echo('edit')."</a>";
                                        echo "<div class=\"collapsible_box\">";
                                        //get the edit form and details
                                        $submit_input = elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('save')));
                                        $text_textarea = elgg_view('input/longtext', array('internalname' => 'postComment'.$vars['annotation']->id, 'value' => $vars['annotation']->value));
                        $post = elgg_view('input/hidden', array('internalname' => 'annotation_id', 'value' => $vars['annotation']->id));
                                        $field = elgg_view('input/hidden', array('internalname' => 'field_num', 'value' => $vars['annotation']->id));
                        $topic = elgg_view('input/hidden', array('internalname' => 'topic', 'value' => get_input('topic')));
                                        $group = elgg_view('input/hidden', array('internalname' => 'group', 'value' => get_input('group_guid')));

                                        $form_body = <<<EOT

                                        <div class='edit_forum_comments'>
                                        <p class='longtext_editarea'>
                                                $text_textarea
                                        </p>
                                        $post
                                        $topic
                                        $group
                                        $field
                                        <p>
                                                $submit_input
                                        </p>

                                        </div>

EOT;

                                        echo elgg_view('input/form', array('action' => "{$vars['url']}action/comments/edit", 'body' => $form_body, 'internalid' => 'editforumpostForm'));
                                ?>
                                        </div>

		</p>

			<?php
			} //end of can edit if statement
		?>
	</div><!-- end of generic_comment_details -->
</div><!-- end of generic_comment div -->
