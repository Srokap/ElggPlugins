<?php
/*****************************************************************************
 * Phloor Body Background                                                    *
 *                                                                           *
 * Copyright (C) 2012 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php

$german = array(
/*
	"phloor_body_background" => "Hintergrundbild",
	'admin:appearance:phloor_body_background' => 'Hintergrundbild',

	'phloor_body_background:title' => "Hintergrundbild Upload",

	'phloor_body_background:description' => "Hier können Sie Ihr eigenes Hintergrundbild hochladen. Unterstütze Mimetypes sind 'image/gif', 'image/jpg', 'image/jpeg', 'image/pjpeg' und 'image/png'. ",

	'phloor_body_background:save:success' => 'Einstellungen erfolgreich gespeichert. ',
	'phloor_body_background:save:failure' => 'Einstellungen konnten nicht gespeichert werden. ',

	'phloor_body_background:form:section:background_image' => 'Hintergrundbild',

	'phloor_body_background:image:label' => 'Laden Sie Ihr Hintergrundbild hoch',
	'phloor_body_background:image:description' => 'Wählen Sie die Datei die Sie als Hintergrundbild einstellen wollen. ',

	'phloor_body_background:image_delete:label' => 'Aktuelles Hintergrundbild entfernen',
	'phloor_body_background:image_delete:description' => 'Bei Aktivierung dieser Checkbox wird der momentane Hintergrund entfernt. ',

	'phloor_body_background:repeat:label'           => "Wiederholung",
	'phloor_body_background:repeat:description'     => "Die 'background-repeat'-Option left fest, ob oder wie ein Bild wiederholt wird - standardmäßig wird das Bild vertikal und horizontal wiederholt. ",
	'phloor_body_background:position:label'         => "Position",
	'phloor_body_background:position:description'   => "Die 'background-position'-Option left die Startposition des Hintergrundbildes fest. ",
	'phloor_body_background:attachment:label'       => "Fixierung",
	'phloor_body_background:attachment:description' => "Die 'background-attachment'-Option legt fest, ob das Hintergrundbild fixiert ist, oder mit dem Rest der Seite mitscrollt. ",
	'phloor_body_background:color:label'            => "Color",
	'phloor_body_background:color:description'      => "Die 'background-color'-Option stellt die Farbe des Hintgrunds ein (wenn nicht vom Bild überdeckt). ",
*/
);

add_translation("de", $german);
