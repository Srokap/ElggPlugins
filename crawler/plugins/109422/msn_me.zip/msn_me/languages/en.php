<?php

	$english = array(
	    		
		'msnme:widget:name' => 'Talk me in MSN',
		'msnme:widget:desc' => 'MSN Me Widget',
		'msnme:widget:msnusername' => 'Your MSN ID:<br>To get Live Invitee ID go to <a href="http://settings.messenger.live.com/applications/CreateHtml.aspx" target"_blank">this link</a> and copy the text string between invitee= & @apps.messenger..., this is your MSN ID',
		'msnme:widget:usernameerror' => 'You need to set your MSN IDby editing the properties of this widget.',
		'msnme:widget:webstatuswarning' => 'You need to ensure your MSN privacy settings allow your status to be shown on the web, do it at the following link.',
		'msnme:widget:webstatuswarning2' => 'Select the Allow websites to see your Messenger status and send you messages check box and click Save.',
		'msnme:widget:webstatuslink' => 'Show your MSN status on the web',
        'msnme:widget:refreshratemessage' => 'This widget auto-refreshes to update your status.  You may change the refresh interval by selecting a value here:',
        'msnme:widget:defaultrefreshrate' => 'Default refresh interval',
        'msnme:widget:nocontact' => 'User has disabled msn contact',
        'msnme:widget:contact' => 'Contact me by clicking here: ',
        'msnme:widget:options:norefresh' => 'No Refresh',
        'msnme:widget:options:15seconds' => '15 seconds',
        'msnme:widget:options:30seconds' => '30 seconds',
        'msnme:widget:options:60seconds' => '60 seconds',
        'msnme:widget:options:1hour' => '1 Hour',
        'msnme:widget:options:3hours' => '3 Hours',

        'msnme:widget:action:message' => 'You can control what happens when the MSN Me button is pressed by selecting an action: ',        
        'msnme:widget:options:action:embed' => 'Embeded page',
        'msnme:widget:options:action:new' => 'Pop-up page',
        'msnme:widget:options:action:widget' => 'Widget',
        
        'msnme:widget:showmsnstatus' => 'Allow users to contact me?',
        'msnme:widget:showmsnstatus:options:yes' => 'Yes',
        'msnme:widget:showmsnstatus:options:no' => 'No',
        'msnme:widget:showmsnstatus:refreshmessage' => '<b>Note:</b> When you don\'t allow contact, the widget will not be refreshed.',
		'msnme:settings' => 'Setup MSN Me plugin',
		'msnme:settings:explanation' => 'Setup MSN Me plugin',
		'msnme:save:success' => 'Saved',
		'msnme:settings:configColors' => 'Setup colors',
		'msnme:settings:LanguageOption' => 'Select language',
		'msnme:settings:foreColor' => 'Fore color',
		'msnme:settings:backColor' => 'Background color',
		'msnme:settings:linkColor' => 'Link color',
		'msnme:settings:borderColor' => 'Border color',
		'msnme:settings:buttonForeColor' => 'Button fore color',
		'msnme:settings:buttonBackColor' => 'Button back color',
		'msnme:settings:buttonBorderColor' => 'Button border color',
		'msnme:settings:buttonDisabledColor' => 'Button disabled color',
		'msnme:settings:headerForeColor' => 'Header fore color',
		'msnme:settings:headerBackColor' => 'Header back color',
		'msnme:settings:menuForeColor' => 'Menu fore color',
		'msnme:settings:menuBackColor' => 'Menu back color',
		'msnme:settings:chatForeColor' => 'Chat fore color',
		'msnme:settings:chatBackColor' => 'Chat back color',
		'msnme:settings:chatDisabledColor' => 'Chat disabled color',
		'msnme:settings:chatErrorColor' => 'Chat error color',
		'msnme:settings:chatLabelColor' => 'Chat label color',
		
	);
					
	add_translation("en",$english);

?>