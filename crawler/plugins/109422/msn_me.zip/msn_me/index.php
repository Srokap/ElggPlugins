<?php
	// Load Elgg engine
		require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
		$menu = get_register('menu');
		
		if (is_array($menu) && sizeof($menu) > 0) {
			$alphamenu = array();
			foreach($menu as $item) {
				$alphamenu[$item->name] = $item;
			}
			ksort($alphamenu);
		}
		foreach($alphamenu as $item) {
			add_submenu_item(sprintf($item->name), $item->value, 'msnmelinksgeneral');
		} 
		

	// Get the specified username
		$msnUser = page_owner_entity();
		$msnUser = get_input('username');
		$title = elgg_echo('msnme:widget:name');
		$body = elgg_view("msn_me/msn", array('username' => $msnUser));
		$body = elgg_view_layout('two_column_left_sidebar', '', $body);
		page_draw($title,$body);
?>

