<?php
action_gatekeeper();
global $CONFIG;
$msnmevars = array(
'LanguageOption' => get_input('LanguageOption'),
'foreColor' => get_input('foreColor'),
'backColor' => get_input('backColor'),
'linkColor' => get_input('linkColor'),
'borderColor' => get_input('borderColor'),
'buttonForeColor' => get_input('buttonForeColor'),
'buttonBackColor' => get_input('buttonBackColor'),
'buttonBorderColor' => get_input('buttonBorderColor'),
'buttonDisabledColor' => get_input('buttonDisabledColor'),
'headerForeColor' => get_input('headerForeColor'),
'headerBackColor' => get_input('headerBackColor'),
'menuForeColor' => get_input('menuForeColor'),
'menuBackColor' => get_input('menuBackColor'),
'chatForeColor' => get_input('chatForeColor'),
'chatBackColor' => get_input('chatBackColor'),
'chatDisabledColor' => get_input('chatDisabledColor'),
'chatErrorColor' => get_input('chatErrorColor'),
'chatLabelColor' => get_input('chatLabelColor'),
);

$site = $CONFIG->site;
$site->msnme = $msnmevars;
system_message(elgg_echo('msnme:save:success'));

forward($_SERVER['HTTP_REFERER']);
?>