<?php

	echo elgg_view_title(elgg_echo('msnme:settings'));

?>

	<div class="contentWrapper">
		<p>
			<?php echo elgg_echo('msnme:settings:explanation'); ?>
		</p>
	

<?php

	echo elgg_view(
						'input/form',
						array(
							'action' => $vars['url'] . 'action/msnme/save',
							'method' => 'post',
							'body' => elgg_view('msn_me/settingsform',$vars)
						)
					);

?>

</div>