<?php
$msnmett = $vars['config']->site->msnme;
if (!$msnmett[17]) {
	$msnmett[17] = "en-US";
}
if (!$msnmett[16]) {
	$msnmett[16] = "333333";
}
if (!$msnmett[15]) {
	$msnmett[15] = "FDC098";
}
if (!$msnmett[14]) {
	$msnmett[14] = "333333";
}
if (!$msnmett[13]) {
	$msnmett[13] = "FB8233";
}
if (!$msnmett[12]) {
	$msnmett[12] = "333333";
}
if (!$msnmett[11]) {
	$msnmett[11] = "FFC9A5";
}
if (!$msnmett[10]) {
	$msnmett[10] = "FB8233";
}
if (!$msnmett[9]) {
	$msnmett[9] = "FFC9A5";
}
if (!$msnmett[8]) {
	$msnmett[8] = "333333";
}
if (!$msnmett[7]) {
	$msnmett[7] = "FC9E60";
}
if (!$msnmett[6]) {
	$msnmett[6] = "333333";
}
if (!$msnmett[5]) {
	$msnmett[5] = "FFFFFF";
}
if (!$msnmett[4]) {
	$msnmett[4] = "333333";
}
if (!$msnmett[3]) {
	$msnmett[3] = "FFFFFF";
}
if (!$msnmett[2]) {
	$msnmett[2] = "F6F6F6";
}
if (!$msnmett[1]) {
	$msnmett[1] = "760502";
}
if (!$msnmett[0]) {
	$msnmett[0] = "6E6C6C";
}

//Asignamos variables de las opciones
$LanguageOption = $msnmett[17];
$foreColor = $msnmett[16];
$backColor = $msnmett[15];
$linkColor = $msnmett[14];
$borderColor = $msnmett[13];
$buttonForeColor = $msnmett[12];
$buttonBackColor = $msnmett[11];
$buttonBorderColor = $msnmett[10];
$buttonDisabledColor = $msnmett[9];
$headerForeColor = $msnmett[8];
$headerBackColor = $msnmett[7];
$menuForeColor = $msnmett[6];
$menuBackColor = $msnmett[5];
$chatForeColor = $msnmett[4];
$chatBackColor = $msnmett[3];
$chatDisabledColor = $msnmett[2];
$chatErrorColor = $msnmett[1];
$chatLabelColor = $msnmett[0];
$input_LanguageOption = array( 'es-ES','en-US','nl-NL','it-IT','de-DE','fr-FR','uk-RO');
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td valign="middle" nowrap="nowrap"><?php echo elgg_echo('msnme:settings:LanguageOption');?>&nbsp;</td>
    <td nowrap="nowrap">&nbsp;</td>
    <td nowrap="nowrap">&nbsp;</td>
  </tr>
  <tr>
    <td nowrap="nowrap"><select name="LanguageOption">
      <?php
	foreach($input_LanguageOption as $item) {
		if ($item == $LanguageOption) {
			echo '<option value"'.$item.'" selected="yes">'.$item.'</option>';
		} else {
			echo '<option value"'.$item.'">'.$item.'</option>';
		}
	}
?>
    </select></td>
    <td nowrap="nowrap">&nbsp;</td>
    <td nowrap="nowrap">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3" nowrap="nowrap">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3" nowrap="nowrap"><strong><?php echo elgg_echo('msnme:settings:configColors');?></strong></td>
  </tr>
  <tr>
    <td width="33%" nowrap="nowrap"><?php echo elgg_echo('msnme:settings:foreColor');?></td>
    <td width="34%" nowrap="nowrap"><?php echo elgg_echo('msnme:settings:backColor');?></td>
    <td width="33%" nowrap="nowrap"><?php echo elgg_echo('msnme:settings:linkColor');?></td>
  </tr>
  <tr>
    <td width="33%" nowrap="nowrap"><input type="text" name="foreColor" value="<?php echo $foreColor;?>" /></td>
    <td width="34%" nowrap="nowrap"><input type="text" name="backColor" value="<?php echo $backColor;?>" /></td>
    <td width="33%" nowrap="nowrap"><input type="text" name="linkColor" value="<?php echo $linkColor;?>" /></td>
  </tr>
  <tr>
    <td width="33%" nowrap="nowrap"><?php echo elgg_echo('msnme:settings:borderColor');?></td>
    <td width="34%" nowrap="nowrap"><?php echo elgg_echo('msnme:settings:buttonForeColor');?></td>
    <td width="33%" nowrap="nowrap"><?php echo elgg_echo('msnme:settings:buttonBackColor');?></td>
  </tr>
  <tr>
    <td width="33%" nowrap="nowrap"><input type="text" name="borderColor" value="<?php echo $borderColor;?>" /></td>
    <td width="34%" nowrap="nowrap"><input type="text" name="buttonForeColor" value="<?php echo $buttonForeColor;?>" /></td>
    <td width="33%" nowrap="nowrap"><input type="text" name="buttonBackColor" value="<?php echo $buttonBackColor;?>" /></td>
  </tr>
  <tr>
    <td width="33%" nowrap="nowrap"><?php echo elgg_echo('msnme:settings:buttonBorderColor');?></td>
    <td width="34%" nowrap="nowrap"><?php echo elgg_echo('msnme:settings:buttonDisabledColor');?></td>
    <td width="33%" nowrap="nowrap"><?php echo elgg_echo('msnme:settings:headerForeColor');?></td>
  </tr>
  <tr>
    <td width="33%" nowrap="nowrap"><input type="text" name="buttonBorderColor" value="<?php echo $buttonBorderColor;?>" /></td>
    <td width="34%" nowrap="nowrap"><input type="text" name="buttonDisabledColor" value="<?php echo $buttonDisabledColor;?>" /></td>
    <td width="33%" nowrap="nowrap"><input type="text" name="headerForeColor" value="<?php echo $headerForeColor;?>" /></td>
  </tr>
  <tr>
    <td width="33%" nowrap="nowrap"><?php echo elgg_echo('msnme:settings:headerBackColor');?></td>
    <td width="34%" nowrap="nowrap"><?php echo elgg_echo('msnme:settings:menuForeColor');?></td>
    <td width="33%" nowrap="nowrap"><?php echo elgg_echo('msnme:settings:menuBackColor');?></td>
  </tr>
  <tr>
    <td width="33%" nowrap="nowrap"><input type="text" name="headerBackColor" value="<?php echo $headerBackColor;?>" /></td>
    <td width="34%" nowrap="nowrap"><input type="text" name="menuForeColor" value="<?php echo $menuForeColor;?>" /></td>
    <td width="33%" nowrap="nowrap"><input type="text" name="menuBackColor" value="<?php echo $menuBackColor;?>" /></td>
  </tr>
  <tr>
    <td width="33%" nowrap="nowrap"><?php echo elgg_echo('msnme:settings:chatForeColor');?></td>
    <td width="34%" nowrap="nowrap"><?php echo elgg_echo('msnme:settings:chatBackColor');?></td>
    <td width="33%" nowrap="nowrap"><?php echo elgg_echo('msnme:settings:chatDisabledColor');?></td>
  </tr>
  <tr>
    <td width="33%" nowrap="nowrap"><input type="text" name="chatForeColor" value="<?php echo $chatForeColor;?>" /></td>
    <td width="34%" nowrap="nowrap"><input type="text" name="chatBackColor" value="<?php echo $chatBackColor;?>" /></td>
    <td width="33%" nowrap="nowrap"><input type="text" name="chatDisabledColor" value="<?php echo $chatDisabledColor;?>" /></td>
  </tr>
  <tr>
    <td width="33%" nowrap="nowrap"><?php echo elgg_echo('msnme:settings:chatErrorColor');?></td>
    <td width="34%" nowrap="nowrap"><?php echo elgg_echo('msnme:settings:chatLabelColor');?></td>
    <td width="33%" nowrap="nowrap">&nbsp;</td>
  </tr>
  <tr>
    <td width="33%" nowrap="nowrap"><input type="text" name="chatErrorColor" value="<?php echo $chatErrorColor;?>" /></td>
    <td width="34%" nowrap="nowrap"><input type="text" name="chatLabelColor" value="<?php echo $chatLabelColor;?>" /></td>
    <td width="33%" nowrap="nowrap">&nbsp;</td>
  </tr>
  <tr>
    <td nowrap="nowrap">&nbsp;</td>
    <td align="center" nowrap="nowrap"><input type="submit" name="button" id="button" value="<?php echo elgg_echo('save');?>" /></td>
    <td nowrap="nowrap">&nbsp;</td>
  </tr>
</table>
