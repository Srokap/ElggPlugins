<?php
//	global $CONFIG;
//	require($CONFIG->pluginspath . "msn_me/lib/msnme.inc" );
    // Get the default refresh rate
    $defaultmsnmeRefreshRate = intval(get_plugin_setting('defaultmsnmeRefreshRate', 'msnme'));

    // if no value then the admin didn't set a value, so default to an hour    
    if (! $defaultmsnmeRefreshRate)
        $defaultmsnmeRefreshRate = 3600000;
    
    /* Set the actual refresh rate, if the user hasn't specified one, for example
     if this is the first time that they have used the widget, use the default setting */
    $actualRefreshRate = ($vars['entity']->msnmeRefreshRate)? $vars['entity']->msnmeRefreshRate : $defaultmsnmeRefreshRate;
    
    // Has the user selected an action?  If not, it should be 'embed'
    $msnmeAction = ($vars['entity']->msnmeAction)? $vars['entity']->msnmeAction : 'embed';
    
    //  Has the user selected an Status option? If not, it should be show status
    $msnmeShowStatus = ($vars['entity']->msnmeShowStatus)? $vars['entity']->msnmeShowStatus : 'yes';
    
    $msnme_username = ($vars['entity']->msnUserName)? $vars['entity']->msnUserName: "";
	 
	if ("" == $msnme_username)
        echo "<div class=\"contentWrapper\"><p>" . elgg_echo("msnme:widget:usernameerror") . ".</p></div>";  
	else
	{ 
        $msnCode = getMSNCode($msnme_username, $msnmeAction, $msnmeShowStatus, $vars);
        ?>
		<div id="msnmewidgetdiv" align="center"><?php echo $msnCode;?></div>


<script language="javascript" type="text/javascript">
    
    function refreshmsnmePanel(firstTime)
    {
      
        if (false == firstTime) {
            document.getElementById('msnmebutton').src = "<?php echo getMSNImageURL($msnme_username, $msnmeAction, $msnmeShowStatus, $vars);?>?date=" + (new Date()).getTime();
        }
        
        <?php if (intval($actualRefreshRate) > 0) {
            echo " msnmeTimer = setTimeout('refreshmsnmePanel(false)', " . $actualRefreshRate .");";
        }
        else
        {
            echo " clearTimeout(msnmeTimer)";
        } ?>    
    }
    
    <?php 
    // Only refresh if Status is shown.
    if ('yes' == $msnmeShowStatus)
    { ?>
        refreshmsnmePanel(true);		
    <?php } ?>
    function widgetmsnme(url)
    {
		document.getElementById('msnmewidgetdiv').innerHTML = "<iframe src='"+url+"' allowtransparency='allowtransparency' width='95%' height='400' frameborder='0' hspace='0' vspace='0'></iframe>";
    }

</script>

<?php } ?> 
