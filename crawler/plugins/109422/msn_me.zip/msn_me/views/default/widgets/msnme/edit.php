    <p>
    <?php echo elgg_echo('msnme:widget:action:message'); 
    
    // if the user hasn't previously set an action, use the default of Embed.
    $msnmeAction = ($vars['entity']->msnmeAction) ? $vars['entity']->msnmeAction : 'embed';
        $msnmeActionOptions = array(
            'internalname' => 'params[msnmeAction]', 
            'value' => $msnmeAction,
            'options_values' => array('embed' => elgg_echo("msnme:widget:options:action:embed"),
                    'new' => elgg_echo("msnme:widget:options:action:new"),
					'widget' => elgg_echo("msnme:widget:options:action:widget"))
        );
       
        echo elgg_view('input/pulldown', $msnmeActionOptions);
?>
    
    </p>
    
    <p>
    
    <?php echo elgg_echo('msnme:widget:showmsnstatus'); 
    
    // if the user hasn't previously select whether to show their stats, use the default of yes.
    $msnmeShowStatus = ($vars['entity']->msnmeShowStatus) ? $vars['entity']->msnmeShowStatus : 'yes';
        $msnmeShowStatusOptions = array(
            'internalname' => 'params[msnmeShowStatus]', 
            'value' => $msnmeShowStatus,
            'options_values' => array('yes' => elgg_echo("msnme:widget:showmsnstatus:options:yes"),
                    'no' => elgg_echo("msnme:widget:showmsnstatus:options:no"))
        );
       
        echo elgg_view('input/pulldown', $msnmeShowStatusOptions);
?>
    
    </p>
    
    <p>
    
    <?php echo elgg_echo("msnme:widget:refreshratemessage");
    
    // Get the default refresh rate
    $defaultmsnmeRefreshRate = intval(get_plugin_setting('defaultmsnmeRefreshRate', 'msnme'));    
    
    // if no value then neither the admin nor the user set a value, so default to an hour    
    if (! $defaultmsnmeRefreshRate)
        $defaultmsnmeRefreshRate = 3600000;
    
    // if the user hasn't previously set a refresh rate, use the default one.
    $msnmeRefreshRate = ($vars['entity']->msnmeRefreshRate) ? $vars['entity']->msnmeRefreshRate : $defaultmsnmeRefreshRate;
        $msnmeRefreshRateOptions = array(
            'internalname' => 'params[msnmeRefreshRate]', 
            'value' => $msnmeRefreshRate,
            'options_values' => array(-1 => elgg_echo("msnme:widget:options:norefresh"),
                    15000 => elgg_echo("msnme:widget:options:15seconds"),
                    30000 => elgg_echo("msnme:widget:options:30seconds"),
                    60000 => elgg_echo("msnme:widget:options:60seconds"),
                    3600000 => elgg_echo("msnme:widget:options:1hour"),
                    10800000 => elgg_echo("msnme:widget:options:3hours")
            )
        );
       
        echo elgg_view('input/pulldown', $msnmeRefreshRateOptions);
        ?>
        </p>
        <p>
        <?php 
        echo elgg_echo("msnme:widget:showmsnstatus:refreshmessage");
        
        ?>
    </p>
    <p>
	
		<label><?php echo elgg_echo("msnme:widget:msnusername");?></label>
        <?php 
        $msnUserName = ($vars['entity']->msnUserName)?$vars['entity']->msnUserName:"";
        echo elgg_view('input/text',array(
                                'internalname' => 'params[msnUserName]',
                                'value' => $msnUserName)
                                );
                                
        ?> 
    </p>
    <?php echo elgg_echo("msnme:widget:webstatuswarning")?><br /><a href="http://settings.messenger.live.com/applications/WebSettings.aspx" target="_blank"><?php echo elgg_echo('msnme:widget:webstatuslink');?></a><br /><?php echo elgg_echo("msnme:widget:webstatuswarning2")?>

    
