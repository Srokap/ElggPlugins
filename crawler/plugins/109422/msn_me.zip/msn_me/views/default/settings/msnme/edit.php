<p>
<br />
<h3><?php echo elgg_echo('msnme:widget:defaultrefreshrate'); ?>: </h3>
<?php
        $defaultmsnmeRefreshRate = ($vars['entity']->defaultmsnmeRefreshRate) ? $vars['entity']->defaultmsnmeRefreshRate : 3600000;
        
        $defaultmsnmeRefreshRateOptions = array(
            'internalname' => 'params[defaultmsnmeRefreshRate]', 
            'value' => $defaultmsnmeRefreshRate,
            'options_values' => array(-1 => elgg_echo("msnme:widget:options:norefresh"),
                    15000 => elgg_echo("msnme:widget:options:15seconds"),
                    30000 => elgg_echo("msnme:widget:options:30seconds"),
                    60000 => elgg_echo("msnme:widget:options:60seconds"),
                    3600000 => elgg_echo("msnme:widget:options:1hour"),
                    10800000 => elgg_echo("msnme:widget:options:3hours")
            )
        );
       
        echo elgg_view('input/pulldown', $defaultmsnmeRefreshRateOptions);
?>
</p>
<br />