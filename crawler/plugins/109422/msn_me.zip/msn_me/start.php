<?php
     
		function msnme_init() {
			global $CONFIG;
			register_translations($CONFIG->pluginspath . "msn_me/languages/");			
    		//add the widget
			add_widget_type('msnme',elgg_echo('msnme:widget:name'),elgg_echo('msnme:widget:desc'));
			//register_entity_type('object','msn_me');
		}
		function msnme_handler($page) {
			if (isset($page)) {
				set_input('username',$page);
				include(dirname(__FILE__) . "/index.php");
				return true;
			}
		}

		function msnme_pagesetup()
		{
			if (get_context() == 'admin' && isadminloggedin()) {
				global $CONFIG;
				add_submenu_item(elgg_echo('msnme:settings'), $CONFIG->wwwroot . 'mod/msn_me/settings.php');
			}
		}
		
        global $CONFIG;
		register_elgg_event_handler('init','system','msnme_init');
		register_elgg_event_handler('pagesetup','system','msnme_pagesetup');
		register_page_handler('msn','msnme_handler');
		register_action('msnme/save',false,$CONFIG->pluginspath . 'msn_me/actions/save.php',true);
        
		require_once($CONFIG->pluginspath . "msn_me/lib/msnme.inc" );  
        
?>