/**
 * Adds a custom link to the topbar
 * 
 * @package custom_topbar_link
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Headshift <james.dellow@headshift.com>
 * @copyright Headshift 2010
 * @link http://www.headshift.com/
 * 
 */
 
Version: 1.2

Requires: Tested with the default theme and Elgg 1.7

*Description*

This simple plugin adds a customisable link to the 'topbar'. The link appears between the default Tools menu and Settings link and is visible to all users. The link (including settings for the URL, link text, html attribute(s) and colours) is configured through the administration screen.

*Admin settings*

Mandatory: Enter the link text, URL.
Optional: Enter link HTML attribute(s), link colour (HTML colour or hex code), mouse over colour (HTML colour or hex code). Note: To activate the custom colour options, class=customtopbarlink must be entered as a link attribute.

Attribute Tips:
- Set the link attribute to class=usersettings and your link will blend in better with the default navigation bar without the need to configure colours.
- If you need to use a special character in the link attribute, like a quote character, please enter it using a special entity code, e.g. &quot;
- Set the link attribute to target=&quot;_blank&quot; to open the link in a new window/tab.
- You can add more that one attribute, just separate each with a space, e.g. 'class=customtopbarlink target=&quot;_blank&quot;'

Notes:
- The link style can be configured manually by editing the css.php file.
- When changing settings, you will need to re-enter attribute settings that include special entity codes.

*Release notes*

Changes: Added a CSS extension, to allow the link colours to be configured.