<?php
	$english = array(
		'customtopbarlink:adminsettings' => "Enter the link text and URL for the custom topbar link. If you need to use a special character in the link attribute, like a quote character, please enter it using a special entity code, e.g. &amp;quot;. Enter <i>class=customtopbarlink</i> as the attribute to apply the custom colour configuration.",
		'customtopbarlink:admintext' => "Link text:",
		'customtopbarlink:adminurl' => "Link URL:",
		'customtopbarlink:adminparam' => "(Optional) Other link attribute (e.g. target):",
		'customtopbarlink:admincolour' => "(Optional) HTML link colour (e.g. #999999):",
		'customtopbarlink:adminhover' => "(Optional) HTML link mouse over colour (e.g. #eeeeee):",
	);
	add_translation("en",$english);
?>