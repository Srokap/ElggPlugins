<p>
	<?php echo elgg_echo('customtopbarlink:adminsettings'); ?>
	<ul><li><?php echo elgg_echo('customtopbarlink:admintext'); ?> <input type="text" value="<?php echo $vars['entity']->linktext; ?>" name="params[linktext]" /></li>
	<li><?php echo elgg_echo('customtopbarlink:adminurl'); ?> <input type="text" value="<?php echo $vars['entity']->linkurl; ?>" name="params[linkurl]" /></li>
	<li><?php echo elgg_echo('customtopbarlink:adminparam'); ?> <input type="text" value="<?php echo $vars['entity']->linkparam; ?>" name="params[linkparam]" /></li>
	<li><?php echo elgg_echo('customtopbarlink:admincolour'); ?> <input type="text" value="<?php echo $vars['entity']->linkcolour; ?>" name="params[linkcolour]" /></li>
	<li><?php echo elgg_echo('customtopbarlink:adminhover'); ?> <input type="text" value="<?php echo $vars['entity']->linkhover; ?>" name="params[linkhover]" /></li>
	</ul>
</p>
