<?php

	/**
	 * (Optional) custom topbar link CSS
	 * 
	 * @package custom_topbar_link
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Headshift <james.dellow@headshift.com>
	 * @copyright Headshift 2010
	 * @link http://www.headshift.com/
	 */

?>

#elgg_topbar_container_left a.customtopbarlink {
	margin:0 0 0 20px;
	color:<?php echo get_plugin_setting('linkcolour','custom_topbar_link');?>;
	padding:3px;
}
#elgg_topbar_container_left a.customtopbarlink:hover {
	color:<?php echo get_plugin_setting('linkhover','custom_topbar_link');?>;
}
