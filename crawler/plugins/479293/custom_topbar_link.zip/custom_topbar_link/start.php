<?php
	// Custom Topbar Link Plugin

	function customtopbarlink_init()
	{
		global $CONFIG;
		$CONFIG->customtopbarlink_config = array(
			'linktext' => true,
			'linkurl' => true,
			'linkparam' => true,
			'linkcolour' => true,
			'linkhover' => true
		);
	}
	
	// Initialise
	register_elgg_event_handler('init','system','customtopbarlink_init');
	
	// Extend CSS
	elgg_extend_view('css','custom_topbar_link/css');
        
?>
