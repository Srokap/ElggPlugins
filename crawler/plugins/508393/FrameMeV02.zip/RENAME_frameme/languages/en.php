<?php

	$english = array(
	
		'help' => "RENAME_SHORT_OR_ACTION_TITLE",
		
		'RENAME_frameme:RENAME' => "RENAME_FRAME_TITLE",
	);

	add_translation("en",$english);

?>
