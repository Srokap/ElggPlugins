FrameMe plugin, version 0.2, by Casey (porchcat _AT- arthurslegacy -D0T_ com, http://arthurslegacy.com/). Based on the Facebook Inside plugin by maslinux (http://community.elgg.org/pg/plugins/maslinux/read/395981/facebook-inside).

Casey can be found as P.Casey on the Elgg community website.

This plugin is released under the GNU General Public License version 3.

Note 1. Obviously, where you have replaced a RENAME with something else, use the replacement name instead of RENAME when following the instructions.

Step 1. Replace all the "RENAME"s with an appropriate name. This includes file names and directory names, as well as the functions & variables inside the RENAME.php, start.php, /languages/en.php, and views/default/RENAME/css.php files. 

Step 2. Change the variables inside the RENAME.PHP in the main folder. Border, height, width, and scrolling have preset options. See below. The URL should be entered WITHOUT the http:// prefix. 

Notes 2. You may wish to adjust the width and height of the iframe. See http://www.w3.org/TR/html4/present/frames.html#edef-IFRAME and http://www.blooberry.com/indexdot/html/tagpages/i/iframe.htm for more information about iframe options.

Notes 3. You may wish to use a two column, instead of one column format. If so, in the main RENAME.php file, find:
$body = elgg_view_layout("one_column", $area2);
and replace it with:
$body = elgg_view_layout("two_column_left_sidebar", $area1, $area2); 

Step 3. Zip archive the RENAME_frameme folder.

Step 4. Install the plugin, as normal.

Step 5. Now you need a menu link. I used a theme with an additional header menu and placing the link in the header area. Go into your themes folder to views/default/page_elements/. 
You want to find the links following:
<div id="layout_header">
<div id="wrapper_header">

The line opening may look something like this:
<li><a href="<?php echo $vars['url']; ?>mod/file/world.php">

Or like this:
<li class="navlist"><a class="files-icon" href="<?php echo $vars['url']; ?>mod/file/world.php">

These are the header area menu links. You do not want to replace a line. Copy one of the lines and paste it where you'd like to put your new link in the menu. In the second example, in a theme that uses menu icons, you may wish to edit the icon name. If you wish to use a customized image, you will need to make a new entry in the icons area of your theme's css file. If the link uses a SPAN tag or similar means to display a name instead of an image, replace the name appropriately.

**In the \copied/ line** replace the equivalent of 
mod/file/world.php
with
mod/RENAME_frameme/RENAME.php

The string may also be something like pg/dashboard/ or account/register.php. What copied line you modify is relatively unimportant. You are just using it to integrate your link into your theme. You are simply plugging in the new internal link using the menu/link framework already provided.

Other menu and internal links may be modified in this way, leaving the possibilities for imbedding a FrameMe link wide open. The link could be added to the dropdown menu, topbar, sidebar, or so on by adding a link in the same format as the existing internal links. 

Live functioning example:
http://arthurslegacy.com/mod/bforum_frameme/bforum.php