<?php

	include_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	$title = elgg_echo('RENAME_frameme:RENAME');
	$area2 = elgg_view_title($title);
	$area2 .= elgg_view('RENAME/RENAME');
	
	$body = elgg_view_layout("one_column", $area2);
	
	$frame_link = "INSERT_YOUR_URL_WITHOUT_HTTP";
	$frame_border = "0";
	$frame_width = "100%";
	$frame_height = "600";
	$frame_scrolling = "auto";

	page_draw($title, $body);
?>