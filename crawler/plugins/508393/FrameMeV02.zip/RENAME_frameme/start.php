<?php

	function RENAME_frameme_init() 
	{
		extend_view('css', 'RENAME/css');
		
		register_page_handler('RENAME_frameme','RENAME_frameme_page_handler');
	}


	function RENAME_frameme_page_handler($page) 
	{
		
		if ($page[0])
		{
			switch ($page[0])
			{
				case "RENAME":
					include(dirname(__FILE__) . "/RENAME.php");
					break;
				default: 
					break;
			}
		}
	}

	register_elgg_event_handler('init','system','RENAME_frameme_plugin_init');
?>