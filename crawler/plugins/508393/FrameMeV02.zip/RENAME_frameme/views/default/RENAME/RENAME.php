<?PHP
print('<div align="center"><iframe src="http://' .$frame_link. '" frameborder="' .$frameborder. '" width="' .$frame_width. '" height="' .$frame_height. '" scrolling="' .$frame_scrolling '"></iframe></div>');
?>