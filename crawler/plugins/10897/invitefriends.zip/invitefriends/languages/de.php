<?php
	/**
	 * Elgg invite page
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @link http://elgg.org/
	 */

	$german = array(

		'friends:invite' => "Freunde einladen",
		'invitefriends:fail:mailaddress' => "Die eMail-Adresse %s scheint nicht korrekt zu sein und wurde übersprungen !",
		'invitefriends:fail:registered' => "Es existiert bereits ein Anwender mit der eMail-Adresse %s !",
		'invitefriends:fail:nomail' => "Keine eMail-Adressen zum senden vorhanden !",
		'invitefriends:fail:send' => "Es konnte keine Einladung an %s gesendet werden !",
		'invitefriends:label:introduction' => "Trage bitte die eMail-Adressen Deiner Freunde ein, die Du einladen möchtest (mit Komma getrennt):",
		'invitefriends:label:message' => "Trage eine Nachricht ein, die Du Deinen Freunden mit der Einladung senden möchtest:",
		'invitefriends:message:default' => "Hallo, Ich möchte Dich einladen der Community %s beizutreten.",
		'invitefriends:success' => "Es wurde eine Einladung an die eMail-Adresse(n) %s verschickt !",
		
		'invitefriends:subject' => "%s hat Dich eingeladen der Community %s beizutreten",
		'invitefriends:body' => "
Du wurdest eingeladen der Community %s beizutreten.
Diese Einladung wurde Dir von %s mit folgender Nachricht geschickt :

%s

Verwende bitte den folgenden Link um der Community beizutreten:

	%s
	
	"
	
	);
	add_translation('de',$german);
		if (isadminloggedin()) {
	
		$german = array(
		
			/**
			* Admin-Only translations
			*/

			'invitefriends:users' => "Welche Anwender dürfen Freunde einladen",
			'invitefriends:users:all' => "Alle Anwender",
			'invitefriends:users:admins' => "Nur Administratoren"
			
		);
		add_translation('de', $german);
	
	}

?>