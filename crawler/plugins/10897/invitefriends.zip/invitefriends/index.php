<?php
	/**
	 * Elgg inviteFriends
	 * 
	 * @package ElggInviteFriends
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @link http://elgg.org/
	 */

	require_once(dirname(dirname(dirname(__FILE__))) . '/engine/start.php');
	
	gatekeeper();
	
	set_context('friends');
	set_page_owner($_SESSION['guid']);
	
	$title = elgg_view_title(elgg_echo('friends:invite'));
	$body = elgg_view('invitefriends/forms/invite');
	page_draw(elgg_echo('friends:invite'), elgg_view_layout('two_column_left_sidebar', '', $title . $body));
	
?>