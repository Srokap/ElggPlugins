<?php
	/**
	 * Elgg inviteFriends
	 * 
	 * @package ElggInviteFriends
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @link http://elgg.org/
	 */

?>	 
<p>
<br />
<h3><?php echo elgg_echo('invitefriends:users'); ?>: </h3>
<?php

		$allowedUsers = ($vars['entity']->allowedUsers ? $vars['entity']->allowedUsers : 'all');
		$myOptions = array(
			'internalname' => 'params[allowedUsers]', 
			'value' => $allowedUsers,
			'options_values' => array(
				'all' => elgg_echo('invitefriends:users:all'),
				'admins' => elgg_echo('invitefriends:users:admins')
			)
		);
		echo elgg_view('input/pulldown', $myOptions);
		
?>
<br />&nbsp;<br />
</p>
