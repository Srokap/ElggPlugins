<?php
	/**
	 * Elgg inviteFriends
	 * 
	 * @package ElggInviteFriends
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @link http://elgg.org/
	 */

	$body .= '<p>';
	$body .= '<label>';
	$body .= elgg_echo('invitefriends:label:introduction');
	$body .= '</label>';
	$body .= elgg_view('input/email', array('internalname' => 'emails'));
	$body .= '</p>';
	$body .= '<p>';
	$body .= '<label>';
	$body .= elgg_echo('invitefriends:label:message');
	$body .= '</label>';
	$body .= elgg_view('input/longtext', array('internalname' => 'emailmessage', 'value' => sprintf(elgg_echo('invitefriends:message:default'), $CONFIG->site->name)));
	$body .= '</p>';
	$body .= elgg_view('input/submit', array('value' => elgg_echo('invite')));

	echo elgg_view('input/form', array(	'action' => $vars['url'] . 'action/invitefriends/invite', 'body' => $body, 'method' => 'post'));

?>