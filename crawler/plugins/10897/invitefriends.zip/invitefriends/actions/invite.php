<?php
	/**
	 * Elgg inviteFriends
	 * 
	 * @package ElggInviteFriends
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @link http://elgg.org/
	 */

	gatekeeper();
	global $CONFIG;
	action_gatekeeper();
	$emails = get_input('emails');
	$emailmessage = get_input('emailmessage');
	
	
	// For each given mail-address
	$emails = explode(',', $emails);
	if (sizeof($emails)) {
	
		foreach($emails as $email) {
		
			$email = trim($email);
			if (!empty($email)) {
			
				// check if the mail-address is valid
				if (is_email_address($email)) {
				
					if (!get_user_by_email($email)) {
					
						$mailmessage = str_replace('<br>', "\r\n", $mailmessage);
						$mailmessage = str_replace('<br/>', "\r\n", $mailmessage);
						$mailmessage = str_replace('<br />', "\r\n", $mailmessage);
						$link = $CONFIG->wwwroot . 'account/register.php?friend_guid=' . $_SESSION['guid'] . '&invitecode=' . generate_invite_code($_SESSION['user']->username);
						$message = sprintf(elgg_echo('invitefriends:body'), $CONFIG->site->name, $_SESSION['user']->name, html_entity_decode(strip_tags($emailmessage), ENT_NOQUOTES, 'UTF-8'), $link);
						$subject = sprintf(elgg_echo('invitefriends:subject'), $_SESSION['user']->name, $CONFIG->site->name);
				
						$headers = "From: \"{$CONFIG->site->name}\" <{$CONFIG->site->email}>\r\n"
						. "Content-Type: text/plain; charset=UTF-8; format=flowed\r\n"
						. "MIME-Version: 1.0\r\n"
						. "Content-Transfer-Encoding: 8bit\r\n";
						if (!mail($email, $subject, wordwrap($message), $headers)) {

							$error = TRUE;
							register_error(sprintf(elgg_echo('invitefriends:fail:send'), $email));
				
						} else {
				
							$success .= $email . ', ';
					
						}
					} else {
					
						$error = TRUE;
						register_error(sprintf(elgg_echo('invitefriends:fail:registered'), $email));
					
					}
				} else {
				
					$error = TRUE;
					register_error(sprintf(elgg_echo('invitefriends:fail:mailaddress'), $email));
				}
			}
		}
		if (!$error) {
		
			system_message(sprintf(elgg_echo('invitefriends:success'), $success));
			
		} else {
		
			if ($success) {
			
				register_error(sprintf(elgg_echo('invitefriends:success'), $success));
		
			}
		}
	} else {
	
		register_error(elgg_echo('invitefriends:fail:nomail'));
		
	}
	forward($_SERVER['HTTP_REFERER']);

?>