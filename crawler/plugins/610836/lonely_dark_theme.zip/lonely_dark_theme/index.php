﻿

<?php
    if(!is_plugin_enabled('custom_index')){
?> 

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<title><?php echo $vars['config']->sitename; ?></title>
<body>

  <div align="left" id="site_logo" style="width: 225px; height:80px; margin-left:230px; padding-top:10px"> 
    <a href="<?php echo $vars['url']; ?>"> <img src="<?php echo $vars['url']; ?>mod/lonely_dark_theme/graphics/site_logo.png" border="0" /></a> 
  </div>
  <!--  /#site_logo-->

<div id="wrap" style="width:1072px; margin:0 auto; padding:0">
<div id="wrap_canvas" style="margin:10px 0 20px 0;
	padding:20px;
	min-height: 400px;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	background:url(<?php echo $vars['url']; ?>mod/lonely_dark_theme/graphics/contentbg.png);border-bottom:1px solid #cccccc;
	border-right:1px solid #cccccc;
	border-left:1px solid #cccccc;
	border-top:1px solid #cccccc">

<div id="register" style="width:250px;float:left;margin:0 0 30px 0;padding:0 0px 20px 5px">
   <h2> <p style="padding-left:15px;"><font color="#FF6600">REGISTER NOW</font></p></h2>

            
</div>
    <div id="login" style=" widht:250px;float:right;height:auto;background:yellow;padding:5px 10px 10px 10px"> 
      <div align="center"><font color="#990000" face="sans-serif">Already a member</font> 
      </div>
      <h1 align="center"><font color="#FF6600">LOGIN</font></h1>
      <?php
				$form_body = "<p><label>" . elgg_echo('username') . "<br />" . elgg_view('input/text', array('internalname' => 'username', 'class' => 'login-textarea')) . "</label><br />";
				$form_body .= "<label>" . elgg_echo('password') . "<br />" . elgg_view('input/password', array('internalname' => 'password', 'class' => 'login-textarea')) . "</label><br /><br />";
				$form_body .= elgg_view('input/submit', array('value' => elgg_echo('login'))) . "</p>";
				$form_body .= "<p><a href=\"". $vars['url'] ."account/forgotten_password.php\">" . elgg_echo('user:password:lost') . "</a></p>";

				echo elgg_view('input/form', array('body' => $form_body, 'action' => "". $vars['url'] ."action/login"));

	  ?>
    </div>
    <div id="index_ad" align="center" style="float:left;width:532px;height:314px;margin-left:20px">
	 <img src="<?php echo $vars['url']; ?>mod/lonely_dark_theme/graphics/intro.png" border="0" /> 
    </div>
	
<!--footer-->
    <div id="footer" style="height:100px;
	background-color:#0000cc;
	background: transparent;
	background-repeat:repeat-x;
	clear:both;
	position:relative;
	width:952px;
	margin: auto;
	color:#FFFFFF"> 
      <table width="100%" height="79" border="0" cellpadding="0" cellspacing="0">
        <tr> 
          <td width="685" height="50"> <a href="http://www.crazytrench.tk" target="_blank"> 
            <img src="<?php echo $vars['url']; ?>mod/lonely_dark_theme/graphics/banner_left.gif" border="0" /></a> 
          </td>
          <td width="267" height="50" align="right"> <p class="footer_toolbar_links"> 
              <?php
			echo elgg_view('footer/links');
		?>
            </p></td>
        </tr>
      </table>
    </div>
    <!--footer-->
</div><!--wrap_canvas-->
</div> <!--wrap-->

</body>
<?php
} else{
?>
<?php
}
?>  


