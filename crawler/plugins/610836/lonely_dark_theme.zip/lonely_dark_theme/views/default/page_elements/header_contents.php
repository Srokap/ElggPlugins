<?php

/**
	 * Lonely dark theme for Elgg
	 * @package: Lonely dark theme for Elgg
	 * @author azycraze
	 */
	 
?> 
<div id="layout_header">
  <div id="wrapper_header"> 
    <!-- display the page title -->
    <div id="site_logo">  
     <a href="<?php echo $vars['url'];?>dashboard/index.php"><img src="<?php echo $vars['url']; ?>mod/lonely_dark_theme/graphics/site_logo.png" border="0" /></a>
    </div>
    <!--  /#site_logo-->
  </div>
  <div id="elgg_topbar_container_search">
<?php echo elgg_view('page_elements/searchbox'); ?>
</div>
 </div> <!-- /#wrapper_header -->
</div><!-- /#layout_header -->