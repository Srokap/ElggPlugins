﻿<?php

	/**
	 * lonely dark theme for Elgg
	 * @package: lonely dark theme for Elgg
	 * @author azycraze
	 */

?>

<div class="clearfloat"></div>
<div id="layout_ad_canvas">

   
  <table width="100%" height="79" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr> 
      <td width="468" height="60"> 
   			<a href="http://www.crazytrench.tk" target="_blank">
		    <img src="<?php echo $vars['url']; ?>mod/lonely_dark_theme/graphics/banner_left.gif" border="0" /></a>
	  </td>
      <td width="468" height="60">
	       <a href="http://www.tm-in.blogspot.com" target="_blank">
		    <img src="<?php echo $vars['url']; ?>mod/lonely_dark_theme/graphics/banner_right.gif" border="0" /></a>

	  </td>
  </table>
</div>

<div class="clearfloat"></div>

</div><!-- /#page_wrapper -->
</div><!-- /#page_container -->
		