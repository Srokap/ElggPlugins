<?php

	/**
	 * Lonely dark theme for Elgg
	 * @package: Lonely dark theme for Elgg
	 * @author azycraze
	 */

 
    function lonely_dark_theme_init()
    {
	    // Extend system CSS with our own styles
    extend_view('css','pluginname/css');
    // Replace the default index page
    register_plugin_hook('index','system','new_index');	
 	}
	function new_index() {
    if (!include_once(dirname(dirname(__FILE__)) . "/lonely_dark_theme/index.php"))
        return false;
 
    return true;

}

 
    register_elgg_event_handler('init','system','lonely_dark_theme_init');
 
?>