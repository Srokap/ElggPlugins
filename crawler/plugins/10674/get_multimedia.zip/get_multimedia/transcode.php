<?php

/**
 * Transcode clips
 * 
 * @package get_multimedia
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2008
 * @link http://radagast.biz/
 * 
 */

// Load Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

// Load model
require_once(dirname(__FILE__) . "/models/model.php");

// Load getID3 library
require_once(dirname(__FILE__) . "/lib/getid3/getid3/getid3.php");

// Load get_multimedia config file
include(dirname(__FILE__) . "/config/config.php");

if (!isset($multimedia_upload_directory)) {
	// uh oh, the get_multimedia configuration file has not been set
	throw new ConfigurationException(elgg_echo('get_multimedia:configuration_exception'));
}

set_context('get_multimedia');

$suffix_lookup = array( 'video/x-flv' => 'flv',
                        'video/flv' => 'flv',
                        'video/3gpp'=>'3gpp',
                        'video/3gp'=>'3gp',
                        'video/avi'=>'avi',
                        'video/mp4'=>'mp4',
                        'video/mov'=>'mov',
                        'video/wmv'=>'wmv');

$command = $shell . ' ' . dirname(__FILE__).'/lib/transcode_to_flv.sh %s %s "%s" "%s"';

$records = get_multimedia_successful_uploads();
if ($records) {
	// Initialize getID3 engine
	$getID3 = new getID3;
    foreach($records as $record) {
        $id = $record->getGUID();
        if (array_key_exists($record->file_type,$suffix_lookup)) {
            $suffix = $suffix_lookup[$record->file_type];
            $transcoded_clip = dirname(__FILE__).'/clips/'.$id.'.flv';
            $full_command = sprintf($command,$multimedia_upload_directory.$id.'.'.$suffix,$transcoded_clip,$ffmpeg,$convert);
            print($full_command."\n");
            exec($full_command);
            // analyze file 
            $info = $getID3->analyze($transcoded_clip);
            if (isset($info['playtime_seconds'])) {
		        $record->runtime = (int) $info['playtime_seconds'];        
		    }
            $record->status = 'transcoded';
   
            if (($record->owner_guid == 0) && isset($get_multimedia_anonymous_clip_owner_guid)) {
            	$record->owner_guid = $get_multimedia_anonymous_clip_owner_guid;
            }
            $record->save();
            
            trigger_elgg_event("publish","object",$record);                
        }
    }
}

?>