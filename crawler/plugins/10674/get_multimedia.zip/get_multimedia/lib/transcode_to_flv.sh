# transcode the video clip to 176x144 FLV file
"$3" -i "$1" -ar 44100 -r 15 -f flv -s 176x144 -y "$2"
# extract a single frame for video wall display
"$3" -i "$1" -itsoffset -0 -vframes 1 -f image2 -s 176x144 -y "$2".jpg
# use imagemagick to create a thumbnail image for video wall display
"$4" "$2".jpg -resize 88x72 -crop +4+0 +repage -crop -4+0 +repage "$2".thumb.jpg