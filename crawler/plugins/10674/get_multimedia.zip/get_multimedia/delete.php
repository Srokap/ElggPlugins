<?php

// Load Elgg framework
@require_once("../../includes.php");
require_once('html_template.php');

$cn = optional_param('cn',0,PARAM_INT);

$cn_bit = '?cn='.$cn;

if (isloggedin() && run("users:flags:get", array("admin", $_SESSION['userid']))) {
   $mdir = '/var/www/vhosts/tenpoundsworthofchange.org/httpdocs/multimedia/';
   $obj = new StdClass;
   $obj->ident = $cn;
   $obj->outcome = 'deleted';
   update_record('multimedia_uploads',$obj);
   destroy_metadata("get_multimedia::clip",$cn);
   unlink($mdir.$cn.'.flv');
   unlink($mdir.$cn.'.flv.jpg');
   unlink($mdir.$cn.'.flv.thumb.jpg');
   $message='<p>This video has been deleted. You can <a href="http://tenpoundsworthofchange.org/elgg/mod/get_multimedia/wall.php">return to the video wall</a>.</p>';
   standard_wall_template("Video deletion",$message);
} else {
    // this person has no admin permission, so redirect back to the video wall
    header("Location: http://tenpoundsworthofchange.org/elgg/mod/get_multimedia/wall.php$cn_bit");
}

?>