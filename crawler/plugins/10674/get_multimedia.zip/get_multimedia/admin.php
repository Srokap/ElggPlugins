<?php

/**
	 * Admin form
	 * 
	 * @package get_multimedia
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Kevin Jardine <kevin@radagast.biz>
	 * @copyright Radagast Solutions 2008
	 * @link http://radagast.biz/
	 * 
	 */
 
// Load Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

// Load model
require_once(dirname(__FILE__) . "/models/model.php");

// Define context
set_context('get_multimedia');
$cn = get_input('cn');

if (isadminloggedin()) {
    
	$stats = get_multimedia_stats();
	
	$body = elgg_view('get_multimedia/forms/admin',array('cn'=>$cn,'stats'=>$stats));
	
	$title = elgg_echo('get_multimedia:admin_title');
	
	page_draw($title,elgg_view_layout("two_column_left_sidebar", '', elgg_view_title($title) . $body));
} else {
	// the user should not be here, so bounce back to the video wall
	$wall = $CONFIG->wwwroot.'mod/get_multimedia/wall.php';
	if ($cn) {
		$wall .= '?cn='.$cn;		
	}
	forward($wall);
}

?>