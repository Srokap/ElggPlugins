<?php
/**
 * Get clips from mbox-format mailbox
 * 
 * @package get_multimedia
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2008
 * @link http://radagast.biz/
 * 
 */

// Load Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

// Load get_multimedia config file
include(dirname(__FILE__) . "/config/config.php");

if (!isset($mailattachment_directory)) {
	// uh oh, the get_multimedia configuration file has not been set
	throw new ConfigurationException(elgg_echo('get_multimedia:configuration_exception'));
}

function removeDir($dir, $DeleteMe) {
    if(!$dh = @opendir($dir)) return;
    while (false !== ($obj = readdir($dh))) {
        if($obj=='.' || $obj=='..') continue;
        if (!@unlink($dir.'/'.$obj)) removeDir($dir.'/'.$obj, true);
    }
    if ($DeleteMe){
        closedir($dh);
        @rmdir($dir);
    }
}

function get_multimedia_process_message($s,$i,$subject, $from_header, $date) {
	global $multimedia_upload_directory, $mailattachment_directory;
    global $start, $legal_suffixes, $command;
    $dirname = $start.'_'.$i;
    $fulldir = $mailattachment_directory.$dirname;
    mkdir($fulldir);
    print('<br />Making '.$fulldir.'<br />');
    $gp = fopen($mailattachment_directory.$dirname.'/message.eml','wb');
    fwrite($gp,$s);
    fclose($gp);
    print('<br />'.sprintf($command, $dirname).'<br />');
    exec(sprintf($command, $dirname));
    
    // process directory
    
    $dir = scandir($fulldir);
    if ($dir) {
        foreach ($dir as $fn) {
            $suffix_pos = strrpos($fn,'.');
            if ($suffix_pos !== false) {
                $suffix = strtolower(substr($fn,$suffix_pos+1));
                if (in_array($suffix,$legal_suffixes)) {
                    // found a file to register                            
    
                    $obj = new ElggObject();
					$obj->subtype = 'get_multimedia_clip';
					$obj->access_id = ACCESS_PUBLIC;
					$obj->owner_guid = 0;
                    $obj->title = $subject;
                    $obj->runtime = 0;
                    $obj->pubDate = $date;
                    $obj->thumbnail = '';
                    $obj->source = 'email: '.$from_header;
                    $obj->uploadtime = time();
                    $obj->file_type = 'video/'.$suffix;
                    $obj->url = 'file://'.$fulldir.'/'.$fn;
                    $obj->height = 0;
                    $obj->width = 0;
                    $obj->priority = 0;
                    if ($obj->save()) {
	                    $id = $obj->getGUID();
	                    
	                    // copy the file attachment to the multimedia upload directory	                    
	                    // and record success or failure

	                    if (copy($fulldir.'/'.$fn,$multimedia_upload_directory.$id.'.'.$suffix)) {
	                        $obj->status = 'upload_succeeded';
	                    }  else {
	                        $obj->status = 'upload_failed';
	                    }
	        
	                    $obj->save();
                    }
                }
            }
        }
    }
    
    removeDir($fulldir,true);
}

$command = $munpack . ' -C '.$mailattachment_directory . '%s -fq message.eml';
print('<br />'.$command.'<br />');
$start = time();
$legal_suffixes = array('avi','3gp','3gpp','wmv','mov','mp4','flv');

if (is_readable($mailbox)) {
	$fp = fopen($mailbox,'r');
	$s = '';
	$subject = '';
	$from_header = '';
	$date = '';
	$line = fgets($fp);
	print('<br />First line: '.$line.'<br />');
	$i = 1;
	while ($line) {
		// assumes that either the message starts with an envelope "From " or a "Return-Path: "
		// your system may vary
	    if ((substr($line,0,5) == 'From ') || (substr($line,0,13) == 'Return-Path: ')) {
	        if ($s) {
	            get_multimedia_process_message($s,$i,$subject,$from_header, $date);
	            $s = '';
	            $subject = '';
	            $from_header = '';
	            $date = '';
	            $i += 1;
	        }
	    } else if (substr($line,0,9) == 'Subject: ') {
	        if (!$subject) {
	            $subject = trim(substr($line,9));
	            print('<br />Subject:'.$subject.'<br />');
	        }
	    } else if (substr($line,0,6) == 'From: ') {
	        if (!$from_header) {
	            $from_header = trim(substr($line,6));
	        }
	    } else if (substr($line,0,6) == 'Date: ') {
	        if (!$date) {
	            $date = substr($line,6);
	        }
	    }
	    $s .= $line;
	    $line = fgets($fp);
	}
	
	fclose($fp);
	
	if ($s) {
	    get_multimedia_process_message($s,$i,$subject,$from_header, $date);
	
	    # delete the mails processed
	
	    $command = $mail.' -f ' . $mailbox . ' < ' . $mailattachment_directory.'mailcommands.txt';
	    print('<br />'.$command.'<br />');
	    $gp = fopen($mailattachment_directory.'mailcommands.txt','wb');
	    fwrite($gp,'d 1-'.$i);
	    fclose($gp);
	    exec($command);
	}
} else {
	print sprintf(elgg_echo('get_multimedia:mailbox_not_readable_error'),$mailbox);
}
    
?>