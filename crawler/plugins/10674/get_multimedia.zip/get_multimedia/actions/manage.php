<?php

/**
 * get_multimedia manage action
 * 
 * @package get_multimedia
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2008
 * @link http://radagast.biz/
 */

// Load get_multimedia model
require_once(dirname(dirname(__FILE__)) . "/models/model.php");

// Define context
set_context('get_multimedia');
        
$get_multimedia_action = get_input('get_multimedia_action','');
if ($get_multimedia_action == 'upload') {
	$title = elgg_echo('get_multimedia:upload_title');
    if (get_multimedia_handle_upload()) {
    	$body = elgg_view('get_multimedia/upload_response');
    } else {
    	$body = elgg_view('get_multimedia/forms/upload',array('error'=>elgg_echo('get_multimedia:upload_error')));
    }
} else if ($get_multimedia_action == 'edit') {
	admin_gatekeeper();
	$cn = get_input('cn',0);
	if ($cn && $clip = get_entity($cn)) {
		$clip->title = get_input('title','');
		// insert clip tags
	            
        // KJ - I reverse the array to fix an annoying Elgg tag order bug
        // I will remove this workaround when the bug is fixed
		$clip->tags = array_reverse(string_to_tag_array(get_input('tags','')));
		
		$clip->save();
	}
	system_message(elgg_echo('get_multimedia:edit_response'));
	forward($CONFIG->wwwroot.'mod/get_multimedia/admin.php?cn='.$cn);
} else if ($get_multimedia_action == 'set_priority') {
	admin_gatekeeper();
	$cn = get_input('cn',0);
	if ($cn && $clip = get_entity($cn)) {
		$clip->priority = get_input('pri',0);		
		$clip->save();
	}
	system_message(elgg_echo('get_multimedia:edit_response'));
	forward($CONFIG->wwwroot.'mod/get_multimedia/admin.php?cn='.$cn);
} else if ($get_multimedia_action == 'delete') {
	admin_gatekeeper();
	$cn = get_input('cn',0);
	if ($cn) {
		get_multimedia_delete($cn);
	}
	$title = elgg_echo('get_multimedia:delete_title');
	$body = elgg_view('get_multimedia/delete_response');
} else if ($get_multimedia_action == 'report_problem') {
	$title = elgg_echo('get_multimedia:report_problem_title');
	$cn = get_input('cn',0);
	$comment = get_input('comment','');
	if (get_multimedia_report_problem($cn,$comment)) {
		$body = elgg_view('get_multimedia/report_problem_response');
	} else {
		register_error(elgg_echo('get_multimedia:report_problem_error'));
		$body = elgg_view('get_multimedia/forms/report_problem',array('cn'=>$cn,'comment'=>$comment));
	}	
} else if ($get_multimedia_action == 'send_to_friend') {
	$title = elgg_echo('get_multimedia:send_to_a_friend_title');
	$cn = get_input('cn',0);
	$your_name = get_input('your_name','');
	$your_email = get_input('your_email','');
	$friend_name = get_input('friend_name','');
	$friend_email = get_input('friend_email','');
	$comment = get_input('comment','');
	if (get_multimedia_send_to_friend($cn,$your_name,$your_email,$friend_name,$friend_email,$comment)) {
		system_message(elgg_echo('get_multimedia:send_to_a_friend_response'));
		$vars = array (	'cn' => $cn,
						'your_name' => $your_name,
						'your_email' => $your_email,
						'friend_name' => '',
						'friend_email' => '',
						'comment' => $comment
		);
	} else {
		register_error(elgg_echo('get_multimedia:send_to_a_friend_error'));
		$vars = array (	'cn' => $cn,
						'your_name' => $your_name,
						'your_email' => $your_email,
						'friend_name' => $friend_name,
						'friend_email' => $friend_email,
						'comment' => $comment
		);
	}
	$body = elgg_view('get_multimedia/forms/sendtofriend',$vars);	
} else if ($get_multimedia_action == 'recommend') {
	$cn = get_input('cn',0);
    if (($clip = get_entity($cn)) && get_multimedia_recommend($cn)) {
        system_message(elgg_echo('get_multimedia:recommend_response'));
        forward($clip->getUrl());
    } else {
        register_error(elgg_echo('get_multimedia:recommend_error'));
        forward();
    }
}


page_draw($title,elgg_view_layout("two_column_left_sidebar", '', elgg_view_title($title) . $body));

?>