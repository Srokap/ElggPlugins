<?php

/**
 * Elgg get_multimedia individual video clip view
 *
 * @package Elgg get_multimedia
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2008
 * @link http://radagast.biz/
 *
 * @uses $vars['entity'] The clip to view
 */

if (isset($vars['entity'])) {

	if (get_context() == "search") {

		//display the correct layout depending on gallery or list view
		if (get_input('search_viewtype') == "gallery") {

			//display the gallery view
			echo elgg_view("get_multimedia/gallery",$vars);

		} else {

			echo elgg_view("get_multimedia/listing",$vars);

		}


	} else {
		$cn = $vars['entity']->getGUID();
		echo elgg_view('get_multimedia/video_player',array('cn' => $cn));
		//display comments and recommendations bit
		$num_comments = elgg_count_comments($vars['entity']);
		$num_recommendations = get_multimedia_count_recommendations($vars['entity']);
		if (isloggedin() && !get_multimedia_has_recommended($vars['entity'])){
			$recommendation_template = '<p><a href="%s">'.elgg_echo('get_multimedia:recommend_this'). '</a></p>';
			echo sprintf($recommendation_template,$vars['url'].'action/get_multimedia/manage?get_multimedia_action=recommend&cn='.$cn);
		}
		?>
<a href="<?php echo $vars['entity']->getURL(); ?>"><?php echo elgg_echo("get_multimedia:recommendations") . " (" . $num_recommendations . ") ".elgg_echo("comments") . " (" . $num_comments . ")"; ?></a>
<br />
</p>
<!-- display tags -->
<p class="tags"><?php

echo elgg_view('output/tags', array('tags' => $vars['entity']->tags));

?></p>

<?php

// If we've been asked to display the full view
if (isset($vars['full']) && $vars['full'] == true) {
	echo elgg_view_comments($vars['entity']);
}

	}

}

?>