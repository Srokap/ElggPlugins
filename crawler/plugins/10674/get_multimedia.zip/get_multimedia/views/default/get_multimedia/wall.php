<?php
/**
 * Elgg get_multimedia wall view
 * View to show Flash video wall
 * 
 * @package Elgg get_multimedia
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2008
 * @link http://radagast.biz/
 */
// Load get_multimedia config file
include(dirname(dirname(dirname(dirname(__FILE__)))) . "/config/config.php");

$cn = get_input('cn',0);
$last = get_input('last',0);
$find_a_video_text = elgg_echo('get_multimedia:find_a_video_text');
$go_text = elgg_echo('get_multimedia:go');
$flash_error_text1 = elgg_echo('get_multimedia:flash_error_text1');
$flash_error_text2 = elgg_echo('get_multimedia:flash_error_text2');

$content = <<<END
<div id="get_multimedia_video_wall">
<!--form method="post" action="{$vars['url']}mod/get_multimedia/search.php">
<label>$find_a_video_text <input type="text" style="height:15px;" name="text" value=""/></label>
 <input type="submit" value="$go_text" />
</form><br /-->
</div>
<div>
<script type="text/javascript" src="{$vars['url']}mod/get_multimedia/lib/swfobject.js"></script>
<div id="flashcontent">
		<p><strong>$flash_error_text1</strong><br /><br />$flash_error_text2</p>
</div>

<script type="text/javascript">
	// <![CDATA[
	
	var so = new SWFObject("{$vars['url']}mod/get_multimedia/flash/video_wall.swf", "VideoWall", "685", "420", "7","$get_multimedia_colour_background");
	so.addVariable("admin", "1");
	so.addVariable("cn", "$cn");
	so.addVariable("last", "$last");
	so.addVariable("x", "9");
	so.addVariable("y", "5");
	so.addVariable("site_url", "{$vars['url']}");
	
END;
echo $content;
?>
	so.addVariable("video_problem_text", "<?php echo elgg_echo('get_multimedia:video_problem_text'); ?>");
	so.addVariable("show_me_more_text", "<?php echo elgg_echo('get_multimedia:show_me_more_text'); ?>");
	so.addVariable("join_in_text", "<?php echo elgg_echo('get_multimedia:join_in_text'); ?>");
	so.addVariable("send_to_a_friend_text", "<?php echo elgg_echo('get_multimedia:send_to_a_friend_text'); ?>");
	so.addVariable("comment_text", "<?php echo elgg_echo('get_multimedia:comment_text'); ?>");
	so.addVariable("loading_text", "<?php echo elgg_echo('get_multimedia:loading_text'); ?>");
	so.addVariable("single_recommendation_text", "<?php echo elgg_echo('get_multimedia:single_recommendation_text'); ?>");
	so.addVariable("multiple_recommendations_text", "<?php echo elgg_echo('get_multimedia:multiple_recommendations_text'); ?>");
	so.addVariable("single_comment_text", "<?php echo elgg_echo('get_multimedia:single_comment_text'); ?>");
	so.addVariable("multiple_comments_text", "<?php echo elgg_echo('get_multimedia:multiple_comments_text'); ?>");
	
	// colours
	
	so.addVariable("colour_wall","<?php echo $get_multimedia_colour_wall ?>");
	so.addVariable("colour_wall_text","<?php echo $get_multimedia_colour_wall_text ?>");
	so.addVariable("colour_wall_text_rollover","<?php echo $get_multimedia_colour_wall_text_rollover ?>");
    so.addVariable("colour_popup","<?php echo $get_multimedia_colour_popup ?>");
	so.addVariable("colour_popup_text","<?php echo $get_multimedia_colour_popup_text ?>");
	so.addVariable("colour_popup_text_rollover","<?php echo $get_multimedia_colour_popup_text_rollover ?>");
	so.addVariable("colour_mainclip","<?php echo $get_multimedia_colour_mainclip ?>");
	so.addVariable("colour_mainclip_text","<?php echo $get_multimedia_colour_mainclip_text ?>");
	so.addVariable("colour_mainclip_text_rollover","<?php echo $get_multimedia_colour_mainclip_text_rollover ?>");
	so.addVariable("colour_mainclip_cover","<?php echo $get_multimedia_mainclip_cover ?>");
	so.write("flashcontent");
	
	// ]]>
</script>
</div>