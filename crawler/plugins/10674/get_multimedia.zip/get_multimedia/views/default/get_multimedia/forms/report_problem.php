<?php

/**
 * Report problem form view
 * 
 * @package get_multimedia
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2008
 * @link http://radagast.biz/
 * 
 */

$cn = $vars['cn'];

$body = elgg_view('get_multimedia/video_player',array('cn' => $cn));

$body .= '<p>'.elgg_echo('get_multimedia:report_problem_explanation').'</p>';
$body .= '<form enctype="multipart/form-data" action="'.$vars['url'].'action/get_multimedia/manage" method="POST">';
$body .= elgg_view('input/hidden',array('internalname'=>'get_multimedia_action', 'value'=>'report_problem'));
$body .= elgg_view('input/hidden',array('internalname'=>'cn', 'value'=>$cn));

$body .= elgg_view('input/longtext',array('internalname'=>'comment'));
$body .= '<br /><br />';
$body .= elgg_view('input/submit', array('internalname'=>'submit','value'=>elgg_echo('get_multimedia:submit')));
$body .= '</form>';

echo $body;

?>