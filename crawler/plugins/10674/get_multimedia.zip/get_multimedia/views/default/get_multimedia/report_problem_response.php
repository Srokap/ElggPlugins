<?php

/**
 * Elgg get_multimedia report_problem_response
 * View to acknowledge a successful problem report
 * 
 * @package Elgg get_multimedia
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2008
 * @link http://radagast.biz/
 */

echo '<p>'.elgg_echo('get_multimedia:report_problem_response').'</p>';

?>