<?php

/**
 * Send to friend form view
 * 
 * @package get_multimedia
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2008
 * @link http://radagast.biz/
 * 
 */

$cn = $vars['cn'];

$body = elgg_view('get_multimedia/video_player',array('cn' => $cn));

$body .= '<p>'.elgg_echo('get_multimedia:send_to_friend_explanation').'</p>';
$body .= '<form enctype="multipart/form-data" action="'.$vars['url'].'action/get_multimedia/manage" method="POST">';
$body .= elgg_view('input/hidden',array('internalname'=>'get_multimedia_action', 'value'=>'send_to_friend'));
$body .= elgg_view('input/hidden',array('internalname'=>'cn', 'value'=>$cn));

$body .= '<p><label for="your_name">'.elgg_echo('get_multimedia:your_name_label');
$body .= elgg_view('input/text',array('internalname'=>'your_name', 'value'=>$vars['your_name']));
$body .= '</label></p>';

$body .= '<p><label for="your_email">'.elgg_echo('get_multimedia:your_email_label');
$body .= elgg_view('input/text',array('internalname'=>'your_email', 'value'=>$vars['your_email']));
$body .= '</label></p>';

$body .= '<p><label for="friend_name">'.elgg_echo('get_multimedia:friend_name_label');
$body .= elgg_view('input/text',array('internalname'=>'friend_name', 'value'=>$vars['friend_name']));
$body .= '</label></p>';

$body .= '<p><label for="friend_email">'.elgg_echo('get_multimedia:friend_email_label');
$body .= elgg_view('input/text',array('internalname'=>'friend_email', 'value'=>$vars['friend_email']));
$body .= '</label></p>';

$body .= '<p><label for="comment">'.elgg_echo('get_multimedia:comment_label');
$body .= elgg_view('input/longtext',array('internalname'=>'comment', 'value'=>$vars['comment']));
$body .= '</label></p>';

$body .= elgg_view('input/submit', array('internalname'=>'submit','value'=>elgg_echo('get_multimedia:submit')));
$body .= '</form>';

echo $body;

?>