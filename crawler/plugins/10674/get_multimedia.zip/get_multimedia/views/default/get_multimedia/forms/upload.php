<?php

/**
 * Elgg get_multimedia upload form
 * 
 * @package Elgg get_multimedia
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2008
 * @link http://radagast.biz/
 */

$body = '';
if ($vars['error']) {
	$body = '<p>'.$vars['error'].'</p>';
}

$name = get_input('name',$vars['name']);
$location = get_input('location',$vars['location']);
$tags = get_input('tags','');
$email = get_input('email',$vars['email']);
if ($vars['user_guid']) {
	$user_guid = $vars['user_guid'];
} else {
	$user_guid = get_input('user_guid',0);
}

if ($user_guid) {
	$email_bit = elgg_view('input/hidden',array('internalname'=>'email', 'value'=>$email));
	$email_explanation = '';	
} else {
	$email_bit = '<p><label for="email">'.elgg_echo('get_multimedia:email_label');
	$email_bit .= elgg_view('input/text',array('internalname'=>'email', 'value'=>$email));
	$email_bit .= '</label></p>';
	$email_explanation = elgg_echo('get_multimedia:email_explanation').'<br /><br />';
}

$body .= '<div id="get_multimedia_uploadform">';
$body .= '<p>';
$body .= $email_explanation;
$body .= elgg_echo('get_multimedia:uploaded_file_explanation');
$body .= '<br /><br />';
$body .= elgg_echo('get_multimedia:tag_explanation');
$body .= '</p>';

$body .= '<form enctype="multipart/form-data" action="'.$vars['url'].'action/get_multimedia/manage" method="POST">';
$body .= elgg_view('input/hidden',array('internalname'=>'get_multimedia_action', 'value'=>'upload'));
$body .= elgg_view('input/hidden',array('internalname'=>'user_guid', 'value'=>$user_guid));
$body .= elgg_view('input/hidden',array('internalname'=>'MAX_FILE_SIZE', 'value'=>60000000));

$body .= '<p><label for="name">'.elgg_echo('get_multimedia:name_label');
$body .= elgg_view('input/text',array('internalname'=>'name', 'value'=>$name));
$body .= '</label></p>';
$body .= '<p><label for="name">'.elgg_echo('get_multimedia:location_label');
$body .= elgg_view('input/text',array('internalname'=>'location', 'value'=>$location));
$body .= '</label></p>';
$body .= '<p><label for="name">'.elgg_echo('get_multimedia:tags_label');
$body .= elgg_view('input/text',array('internalname'=>'tags', 'value'=>$tags));
$body .= '</label></p>';

$body .= $email_bit;

$body .= '<p><label for="uploaded_file">'.elgg_echo('get_multimedia:uploaded_file_label');
$body .= elgg_view('input/file',array('internalname'=>'uploaded_file'));
$body .= '</label></p>';
$body .= '<p>';
$body .= elgg_echo('get_multimedia:allowable_types_explanation');
$body .= '</p>';
$body .= elgg_view('input/submit', array('internalname'=>'submit','value'=>elgg_echo('get_multimedia:submit')));
$body .= '</form>';
$body .= '</div>';

echo $body;

?>