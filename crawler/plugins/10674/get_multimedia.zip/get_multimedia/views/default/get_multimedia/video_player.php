<?php

/**
 * Video player view
 * 
 * @package get_multimedia
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2008
 * @link http://radagast.biz/
 * 
 */

// Load get_multimedia config file
include(dirname(dirname(dirname(dirname(__FILE__)))) . "/config/config.php");

$flash_error_text1 = elgg_echo('get_multimedia:flash_error_text1');
$flash_error_text2 = elgg_echo('get_multimedia:flash_error_text2');

$cn = $vars['cn'];

$body = <<<END
<script type="text/javascript" src="{$vars['url']}mod/get_multimedia/lib/swfobject.js"></script>
<div id="flashcontent">
		<p><strong>$flash_error_text1</strong><br /><br />$flash_error_text2</p>
</div>

<script type="text/javascript">
	// <![CDATA[
	
	var so = new SWFObject("{$vars['url']}mod/get_multimedia/flash/video_player.swf", "VideoDisplay", "180", "180", "7", "#FFFFFF");
	so.addVariable("cn", "$cn");
	so.addVariable("site_url", "{$vars['url']}");
	so.addVariable("colour_mainclip","$get_multimedia_colour_mainclip");
	so.addVariable("colour_mainclip_text","$get_multimedia_colour_mainclip_text");
	so.addVariable("colour_mainclip_text_rollover","$get_multimedia_colour_mainclip_text_rollover");
	so.write("flashcontent");
	
	// ]]>
</script>
END;

echo $body;

?>