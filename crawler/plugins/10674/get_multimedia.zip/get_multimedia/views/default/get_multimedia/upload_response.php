<?php

/**
 * Elgg get_multimedia upload_response
 * View to acknowledge a successful upload
 * 
 * @package Elgg get_multimedia
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2008
 * @link http://radagast.biz/
 */

echo '<p>'.sprintf(elgg_echo('get_multimedia:upload_response'),$vars['url'].'mod/get_multimedia/wall.php').'</p>';

?>