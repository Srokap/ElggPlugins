<?php

// Load Elgg framework
@require_once("../../includes.php");
require_once('html_template.php');

// get the top ten video clips

$query = <<< END
SELECT m.title, m.ident, q1.rating AS total_rating FROM (
    SELECT r.object_id, sum(rating) AS rating, count(distinct ratedby) AS rating_count
    FROM {$CFG->prefix}ratingsdetails d
    INNER JOIN {$CFG->prefix}ratings r
    ON (r.ident = d.rating_ident)
    WHERE r.object_type = 'get_multimedia::clip'
    GROUP BY object_id
) AS q1
INNER JOIN {$CFG->prefix}multimedia_uploads m
ON (m.ident = q1.object_id AND m.outcome = 'transcoded') 
ORDER by total_rating DESC
LIMIT 10
END;

$body = '';

$results = get_records_sql($query);

if ($results) {
    foreach($results AS $item) {
        $body .= '<p><a href="'.$CFG->wwwroot.'mod/get_multimedia/clip_page.php?cn='.$item->ident.'"><img border="0" style="text-align: left; vertical-align: middle; margin-right: 5px; padding-right: 5px;" src="http://tenpoundsworthofchange.org/multimedia/'.$item->ident.'.flv.jpg" /></a>';
        $body .= '<a href="'.$CFG->wwwroot.'mod/get_multimedia/clip_page.php?cn='.$item->ident.'">'.$item->title.'</a>'."\n";
        $annotation = "<div id=\"ratings\">";
        $rating = get_record('ratings','object_id', $item->ident, 'object_type', 'get_multimedia::clip');
		$annotation .= ratings_drawrating($rating);
		$annotation .= '</div>';
        $body .= $annotation.'</p><br />'."\n";
    }
}

standard_wall_template("Top ten videos",$body);

?>