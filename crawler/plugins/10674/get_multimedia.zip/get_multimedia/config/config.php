<?php

// Please setup all the values below to configure the get_multimedia plugin

// Set the directory for multimedia uploads
// This directory should be accessible by PHP
// but not by your web server.
// It *must* end in a slash ("/").

$multimedia_upload_directory = '';

// The location of a bash-compatible shell

$shell = '';

// the location of your ffmpeg executable

$ffmpeg = '';

// the location of your ImageMagick convert executable

$convert = '';

// the email address to which video problem reports should be sent

$video_problem_reports = '';

// The owner_guid of anonymous clips
// This really should be 0 but Elgg 1.1 won't let people
// comment on clips owned by nobody (well it will, but then
// generates an error)
// See: http://trac.elgg.org/elgg/ticket/597
// Probably best to create a special video_owner account until
// this bug is fixed

$get_multimedia_anonymous_clip_owner_guid = 2;

// configure Flash wall background colour
// Should be an HTML colour

$get_multimedia_colour_background = "#F4F4F4";

// configure Flash animation colour scheme
// you can set the colours for the wall, the main clip,
// the thumbnail popup and the main clip cover rectangle 
// that briefly appears over the main clip while it is loading

// note that the Flash colours are just the same as HTML
// colours with "#" replaced by "0x"

$get_multimedia_colour_wall = "0xF4F4F4";
$get_multimedia_colour_wall_text = "0x000000";
$get_multimedia_colour_wall_text_rollover = "0x0000FF";

$get_multimedia_colour_mainclip = "0xDFDFDF";
$get_multimedia_colour_mainclip_text = "0x000000";
$get_multimedia_colour_mainclip_text_rollover = "0x888888";

$get_multimedia_colour_popup = "0xFFFFFF";
$get_multimedia_colour_popup_text = "0x000000";
$get_multimedia_colour_popup_text_rollover = "0xAAAAAA";

$get_multimedia_mainclip_cover = "0xFFFFFF";

?>