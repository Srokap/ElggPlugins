<?php

/**
 * Show clip page
 * 
 * @package get_multimedia
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2008
 * @link http://radagast.biz/
 * 
 */

// Load Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

// Define context
set_context('get_multimedia');

// Get the specified clip
$cn = (int) get_input('cn');

// If we can get out the clip ...
if ($clip = get_entity($cn)) {
		
	// Get any comments
	$comments = $clip->getAnnotations('comments');

	// Set the page owner
	if ($owner_guid = $clip->getOwner()) {
		set_page_owner($owner_guid);
	}
		
	// Display it
	$body = elgg_view("object/get_multimedia_clip",array(
											'entity' => $clip,
											'comments' => $comments,
											'full' => true
	));
		
	// Set the title appropriately
	$title = sprintf(elgg_echo('get_multimedia:clip_title'),$clip->title);
		
	// If we're not allowed to see the clip
} else {
		
	// Display the 'clip not found' page instead
	$body = elgg_view("get_multimedia/notfound");
	$title = elgg_echo('get_multimedia:notfound_title');
		
}

// Display page
page_draw($title,elgg_view_layout("two_column_left_sidebar", '', elgg_view_title($title) . $body));

?>