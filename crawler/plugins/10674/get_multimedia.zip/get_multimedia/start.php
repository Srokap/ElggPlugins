<?php

	/**
	 * Elgg get_multimedia plugin
	 * 
	 * @package get_multimedia
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Kevin Jardine <kevin@radagast.biz>
	 * @copyright Radagast Solutions 2008
	 * @link http://radagast.biz/
	 */
	// Load get_multimedia model
	require_once(dirname(__FILE__) . "/models/model.php");
	
	/**
	 * get_multimedia initialisation
	 *
	 * These parameters are required for the event API, but we won't use them:
	 * 
	 * @param unknown_type $event
	 * @param unknown_type $object_type
	 * @param unknown_type $object
	 */

	function get_multimedia_init() {
		
		// Load system configuration
			global $CONFIG;
			
		// Load the language files
			register_translations($CONFIG->pluginspath . "get_multimedia/languages/");
		
		// Register a URL handler for get_multimedia clips
			register_entity_url_handler('get_multimedia_url','object','get_multimedia_clip');

	}
	
	function get_multimedia_pagesetup() {
		global $CONFIG;
		
		// set the admin side menu links
		if (get_context() == 'get_multimedia') {
			$cn = get_input('cn',0);
			$get_multimedia_action = get_input('get_multimedia_action','');
			if ($cn && $get_multimedia_action != 'delete') {
				add_submenu_item(elgg_echo('get_multimedia:wall_title'),$CONFIG->wwwroot . 'mod/get_multimedia/wall.php?cn='.$cn);
				if (isadminloggedin()) {
					$clip = get_entity($cn);
					if ($clip->priority) {
						$priority_bit = '&pri=0';
					    $priority_text = elgg_echo('get_multimedia:non_priority_option');
					} else {
					    $priority_bit = '&pri=1';
					    $priority_text = elgg_echo('get_multimedia:priority_option');
					}
					add_submenu_item(elgg_echo('get_multimedia:admin_title'),$CONFIG->wwwroot . 'mod/get_multimedia/admin.php?cn='.$cn);	
					add_submenu_item(elgg_echo('get_multimedia:delete_option'),$CONFIG->wwwroot . 'action/get_multimedia/manage?get_multimedia_action=delete&cn='.$cn);
					add_submenu_item($priority_text,$CONFIG->wwwroot . 'action/get_multimedia/manage?get_multimedia_action=set_priority&cn='.$cn.$priority_bit);
				}
			} else {
				add_submenu_item(elgg_echo('get_multimedia:wall_title'),$CONFIG->wwwroot . 'mod/get_multimedia/wall.php');				
			}
							add_submenu_item(elgg_echo('get_multimedia:upload_title'),$CONFIG->wwwroot . 'mod/get_multimedia/upload.php');				
		}
	}
	
	// make sure that this plugin can edit get_multimedia clips
	// no matter who owns them
	
	function get_multimedia_can_edit($hook_name, $entity_type, $return_value, $parameters) {
         
         $entity = $parameters['entity'];
         $context = get_context();
         if ($context == 'get_multimedia' && $entity->getSubtype() == "get_multimedia_clip") {
             // should be able to do anything with get_multimedia clips
             return true;
         }
         return null;  
     }
     
     /**
	 * Populates the ->getUrl() method for get_multimedia clips
	 *
	 * @param ElggEntity $clip 
	 * @return string Clip URL
	 */
	function get_multimedia_url($clip) {
		
		global $CONFIG;
		return $CONFIG->url . "mod/get_multimedia/clip_page.php?cn=" . $clip->getGUID();
		
	}

      register_plugin_hook('permissions_check','object','get_multimedia_can_edit');
	
		
// Make sure the get_multimedia functions are called
	register_elgg_event_handler('init','system','get_multimedia_init');
	register_elgg_event_handler('pagesetup','system','get_multimedia_pagesetup');
	register_elgg_event_handler('publish','object','get_multimedia_notify_by_email');
	
// Register actions

	global $CONFIG;
	register_action("get_multimedia/manage",false,$CONFIG->pluginspath . "get_multimedia/actions/manage.php");

?>