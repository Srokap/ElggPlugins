<?php
/**
 * Receive clips from smskaufen MMS gateway
 * 
 * @package get_multimedia
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2008
 * @link http://radagast.biz/
 * 
 */

// Load Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

// Load get_multimedia config file
include(dirname(__FILE__) . "/config/config.php");

$legal_suffixes = array('avi','3gp','3gpp','wmv','mov','mp4','flv');

$key1 = get_input('key1');
$key2 = get_input('key2');
$text = get_input('text');
$absender = get_input('absender');
$nummer = get_input('nummer');
$sendzeit = get_input('sendezeit');
$dateiname_org = get_input('dateiname_orginal');
$dateiname = get_input('dateiname');
$datei = get_input('datei');

$suffix_pos = strrpos($dateiname_org,'.');
if ($suffix_pos !== false) {
	$suffix = strtolower(substr($$dateiname_org,$suffix_pos+1));
	if (in_array($suffix,$legal_suffixes)) {
		// found a file to register

		$obj = new ElggObject();
		$obj->subtype = 'get_multimedia_clip';
		$obj->access_id = ACCESS_PUBLIC;
		$obj->owner_guid = 0;
		$obj->title = $text;
		$obj->runtime = 0;
		$obj->pubDate = $date;
		$obj->thumbnail = '';
		$obj->source = 'MMS:smskaufen: '.$absender;
		$obj->uploadtime = time();
		$obj->file_type = 'video/'.$suffix;
		$obj->url = 'file://'.$dateiname_org;
		$obj->height = 0;
		$obj->width = 0;
		$obj->priority = 0;
		$obj->key1 = $key1;
		$obj->key2 = $key2;
		$obj->nummer = $nummer;
	 	$obj->sendezeit = $sendezeit;
		$obj->dateiname_org = $dateiname_org;
		$obj->dateiname = $dateiname;
		if ($obj->save()) {
			$id = $obj->getGUID();

			// decode and save the MMS data to the multimedia upload directory
			// and record success or failure

			if (file_put_contents($multimedia_upload_directory.$id.'.'.$suffix,base64_decode($datei))) {
				$obj->status = 'upload_succeeded';
			}  else {
				$obj->status = 'upload_failed';
			}

			$obj->save();
		}
	}
}

?>