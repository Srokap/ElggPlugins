<?php

/**
 * Get data
 * 
 * Called by the video wall Flash application.
 * This function returns a set of priority clips added to by
 * any additional non-priority clips required to fill up the wall.
 * You can optionally specify the first clip to display.
 * 
 * @package get_multimedia
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2008
 * @link http://radagast.biz/
 * 
 */

// Load Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

// Load model
require_once(dirname(__FILE__) . "/models/model.php");

$number_of_clips = get_input('nclips',0);

$first_clip_id = get_input('cn',0);

if ($first_clip_id) {
	$first_clip = get_entity($first_clip_id);
}

$all_clips = array();

$priority_clips = get_multimedia_priority_clips($number_of_clips);
$non_priority_clips = get_multimedia_non_priority_clips($number_of_clips-count($priority_clips));

if ($priority_clips) {
	foreach($priority_clips as $clip) {
		if ($clip->getGUID() != $first_clip_id) {
			$all_clips[] = $clip;
		}
	}
}

if ($non_priority_clips) {
	foreach($non_priority_clips as $clip) {
		if ($clip->getGUID() != $first_clip_id) {
			$all_clips[] = $clip;
		}
	}
}

// display the clips in random order led by a first clip if requested

shuffle($all_clips);

if ($first_clip_id) {
    array_unshift($all_clips,$first_clip);
}

$data = '';

if ($all_clips) {
    foreach ($all_clips as $clip) {
        $number_of_recommendations = get_multimedia_number_of_recommendations($clip);
        $number_of_comments = get_multimedia_number_of_comments($clip);
            
        $data .= $clip->getGUID().'|'.$clip->runtime.'|'.$clip->title.'|'.$number_of_recommendations.'|'.$number_of_comments."\n";
    }
}

print $data

?>