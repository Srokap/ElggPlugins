<?php

// Load Elgg framework
@require_once("../../includes.php");
require_once('html_template.php');

$cn = optional_param('cn',0,PARAM_INT);

$cn_bit = '?cn='.$cn;

$title = optional_param('title','');
if (!$title) {
    $record = get_record('multimedia_uploads','ident',$cn);
    $title = $record->title;
}

$keywords .= display_input_field(array("keywords","","keywords","get_multimedia::clip",$cn));
$action = optional_param('action','');

$form_template = <<<END
<script type="text/javascript" src="swfobject.js"></script>
<div id="flashcontent">
		<p><strong>You need to upgrade your Flash Player</strong><br /><br />
		You cannot view this video clip because either you do not have the correct version of Flash
		or Javascript is turned off in your browser.</p>
</div>

<script type="text/javascript">
	// <![CDATA[
	
	var so = new SWFObject("video_player4.swf", "VideoDisplay", "180", "180", "7", "#FFFFFF");
	so.addVariable("cn", "$cn");
	so.write("flashcontent");
	
	// ]]>
</script>
<br style="clear: both;"/><br style="clear: both;"/>
<form method="POST" action="{$CFG->wwwroot}mod/get_multimedia/edit.php">
<input type="hidden" name="action" value="edit">
<input type="hidden" name="cn" value="$cn">
<label for="title">Title:</label> <input type="text" style="width:350px;" name="title" value="$title"><br style="clear: both;"/><br style="clear: both;"/>
<label for="keywords">Keywords:</label>
$keywords
<input type="submit" name="submit" value="Change">
</form>
END;

if (isloggedin() && run("users:flags:get", array("admin", $_SESSION['userid']))) {
    if ($action == 'edit') {
        if ($cn) {
            $obj = new stdClass;
            $obj->ident = $cn;
            $obj->title = $title;
            update_record('multimedia_uploads',$obj);
            set_metadata_field("get_multimedia::clip",$cn,'title',$title);
            delete_records('tags','tagtype','get_multimedia::clip','ref',$cn);
            $keywords = trim(optional_param('keywords'));
            insert_tags_from_string ($keywords, 'get_multimedia::clip', $cn, 'PUBLIC', 1);
            $body = '<p>The keywords have been saved and the title has been changed to "'.$title.'"</p>';
        } else {
            $body = '<p>An error has occured.</p>';
        }
        standard_wall_template("Edit title and keywords",$body);
    } else {
        standard_wall_template("Edit title and keywords",$form_template);
    }
} else {
    // this person has no admin permission, so redirect back to the video wall
    header("Location: http://tenpoundsworthofchange.org/elgg/mod/get_multimedia/wall.php$cn_bit");
}

?>