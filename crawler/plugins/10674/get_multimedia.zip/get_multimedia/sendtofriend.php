<?php

/**
	 * Send to friend form
	 * 
	 * @package get_multimedia
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Kevin Jardine <kevin@radagast.biz>
	 * @copyright Radagast Solutions 2008
	 * @link http://radagast.biz/
	 * 
	 */
 
// Load Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

// Load model
require_once(dirname(__FILE__) . "/models/model.php");
    
// Define context
set_context('get_multimedia');

global $CONFIG;

$cn = get_input('cn',0);

if (isloggedin()) {
	$vars = array (	'cn' => $cn,
					'your_name' => $_SESSION['user']->name,
					'your_email' => $_SESSION['user']->email,
					'friend_name' => '',
					'friend_email' => '',
					'comment' => ''
		);
} else {
	$vars = array (	'cn' => $cn,
					'your_name' => '',
					'your_email' => '',
					'friend_name' => '',
					'friend_email' => '',
					'comment' => ''
		);
}

$body = elgg_view('get_multimedia/forms/sendtofriend', $vars);
$title = elgg_echo('get_multimedia:send_to_a_friend_title');

page_draw($title,elgg_view_layout("two_column_left_sidebar", '', elgg_view_title($title) . $body));

?>