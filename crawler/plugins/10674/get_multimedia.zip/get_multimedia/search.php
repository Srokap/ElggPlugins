<?php

// Load Elgg framework
@require_once("../../includes.php");
require_once('html_template.php');

$text = optional_param('text','');
$total = optional_param('total',0,PARAM_INT);
$offset = optional_param('offset',0,PARAM_INT);
$items_per_page = 8;

$body = '';

if ($text) {
    // create a LIKE clause
    
    // protect against evil injections
    if (get_magic_quotes_gpc())
    {
      // If magic quotes is enabled - turn the string back into an unsafe string
      $text = stripslashes($text);
    }
    
    // Now convert the unsafe string into a MySQL safe string
    $text = mysql_real_escape_string($text);
    
    $text_array = explode(" ",$text);
    if (count($text_array) > 1) {
        $where_array = array();
        foreach ($text_array as $s) {
            $where_array[] = "title LIKE '%$s%'";
        }
        $where = implode(" AND ",$where_array);
    } else {
        $where = "title LIKE '%".$text_array[0]."%'";
    }
    
    $query = "SELECT ident,runtime,title FROM ".$CFG->prefix."multimedia_uploads WHERE outcome = 'transcoded' AND $where ORDER BY title ASC";
    $cquery = "SELECT count(ident) AS total FROM ".$CFG->prefix."multimedia_uploads WHERE outcome = 'transcoded' AND $where";
    
    if ($total == 0) {
        $result = get_record_sql($cquery);
        $total = $result->total;
    }
    
    if ($total) {
    
        $paginator = '';
        
        if ($offset > 0) {
            $new_offset = $offset - $items_per_page;
            if ($new_offset < 0) {
                $new_offset = 0;
            }
            $paginator .= "<a href=\"search.php?text=".urlencode($text)."&total=$total&offset=$new_offset\">Previous</a>";
        }
        
        if ($offset < $total - $items_per_page + 1) {
            $new_offset = $offset + $items_per_page;
            if ($new_offset > $total - $items_per_page + 1) {
                $new_offset = $total - $items_per_page +1;
            }
            if ($paginator) {
                $paginator .= ' | ';
            }
            $paginator .= "<a href=\"search.php?text=".urlencode($text)."&total=$total&offset=$new_offset\">Next</a>";
        }
            
        
        $records = get_records_sql($query." LIMIT $offset,$items_per_page");
        if ($records) {
            $body .= '<p>'.$paginator.'</p><br style="clear: both;"/>';
            foreach($records AS $item) {
                $body .= '<p><a href="'.$CFG->wwwroot.'mod/get_multimedia/wall.php?cn='.$item->ident.'"><img border="0" style="text-align: left; vertical-align: middle; margin-right: 5px; padding-right: 5px;" src="http://tenpoundsworthofchange.org/multimedia/'.$item->ident.'.flv.thumb.jpg" width="40" height="36" /></a>';
                $body .= '<a href="'.$CFG->wwwroot.'mod/get_multimedia/wall.php?cn='.$item->ident.'">'.$item->title.'</a></p>'."\n";
            }
            $body .= '<br style="clear: both;"/><p>'.$paginator.'</p>';
        } else {
            $body .= '<p>There are no search results for "'.$text.'".</p>';
        }
    } else {
        $body .= '<p>There are no search results for "'.$text.'".</p>';
    }
    //$body .= "<p>Query: $query</p>";
    $body .= '<br />';
    $body .= '<form method="GET" action="search.php">';
    $body .= 'Search: <input type="text" name="text" value=""> ';
    $body .= '<input type="submit" name="submit" value="Go">';
    $body .= '</form>'."\n";
    
    standard_wall_template("Video search results",$body);
        
} else {
    // no text, so redirect back to the video wall
    header("Location: http://tenpoundsworthofchange.org/index.php$cn_bit");
}

?>