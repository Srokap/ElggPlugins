<?php

/**
 * Get clip info
 * Provides basic clip information to the Flash video player
 * 
 * @package get_multimedia
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2008
 * @link http://radagast.biz/
 * 
 */
 
// Load Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

$data = '';

$cn = get_input('cn',0);
if ($cn && $clip = get_entity($cn)) {

    $data .= $cn.'|'.$clip->runtime.'|'.$clip->title."\n";
}

print $data;

?>