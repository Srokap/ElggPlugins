<?php

/**
 * File upload form
 * 
 * @package get_multimedia
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2008
 * @link http://radagast.biz/
 * 
 */
 
// Load Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

// Load model
require_once(dirname(__FILE__) . "/models/model.php");
    
// Define context
set_context('get_multimedia');

global $CONFIG;

if (isloggedin()) {
	// save the user information if available
	$user_guid = $_SESSION['user']->getGUID();
	$name = $_SESSION['user']->name;
	$location = $_SESSION['user']->location;
	$email = $_SESSION['user']->email;
} else {
	$user_guid = 0;
	$email = '';
	$name = '';
	$location = '';
}

$body = elgg_view('get_multimedia/forms/upload', array('user_guid'=>$user_guid,'email'=>$email,'name'=>$name,'location'=>$location));
$title = elgg_echo('get_multimedia:upload_title');

page_draw($title,elgg_view_layout("two_column_left_sidebar", '', elgg_view_title($title) . $body));

?>