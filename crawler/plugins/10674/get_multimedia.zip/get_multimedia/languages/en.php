<?php
$english = array(
	'get_multimedia:upload_title' => "Video upload",
	'get_multimedia:email_explanation' => "We need your email address so that we can inform you when "
		."your video has been put on the site. We won't reveal it publicly.",
	'get_multimedia:tag_explanation' => "You can also optionally add a list of comma-separated "
		."tags to further describe your video clip.",
	'get_multimedia:name_label' => "Name",
	'get_multimedia:location_label' => "Town or City",
	'get_multimedia:tags_label' => "Tags",
	'get_multimedia:email_label' => "Email",
	'get_multimedia:uploaded_file_label' =>	"Choose a video clip to upload",
	'get_multimedia:allowable_types_explanation' => "Allowable file types: mov,mp4,avi,3gp,wmv,flv",
	'get_multimedia:uploaded_file_explanation' => "Your video should be 176x144 pixels in size - "
		."we'll try to automatically resize it if you upload a different size. Please do not upload "
		."any files larger than 5 megabytes.",
	'get_multimedia:submit' => "Submit",
	'get_multimedia:configuration_exception' => "Error: the configuration file in "
		."mod/get_multimedia/config/config.php has not been set up properly.",
	'get_multimedia:upload_error' => "Error: Could not upload your file. Please make sure that it has one of the valid formats "
		."and that you've supplied all the required information.",
	'get_multimedia:upload_response' => "Your file has been uploaded. "
		."It should appear on the <a href=\"%s\">video wall</a> "
		."in about ten minutes. You'll be sent an email message when it is ready.",
    'get_multimedia:notification_subject' => "Video processed",
    'get_multimedia:notification_message' => "Your video:\n%s\ncan be seen here:\n%s",
    'get_multimedia:find_a_video_text' => "Find a clip",
    'get_multimedia:go' => "Go",
    'get_multimedia:flash_error_text1' => "You need to upgrade your Flash Player",
    'get_multimedia:flash_error_text2' => "You cannot view this video wall because either you do not have the correct version "
    	."of Flash or Javascript is turned off in your browser.",
    'get_multimedia:wall_title' => "Video wall",  
    'get_multimedia:priority_video_text' => "Currently this is a priority clip.",
    'get_multimedia:not_priority_video_text' => "Currently this is <b>not</b> a priority clip.",
    'get_multimedia:published_label' => "Published",
    'get_multimedia:source_label' => "Source",
    'get_multimedia:stats_text' => "So far, %s video clips have been uploaded, with the following categories:",
    'get_multimedia:delete_option' => "Delete this clip",
    'get_multimedia:priority_option' => "Make priority clip",
    'get_multimedia:non_priority_option' => "Make non-priority clip",
    'get_multimedia:admin_title' => "Edit clip", 
    'get_multimedia:title_label' => "Title",
    'get_multimedia:edit_response' => "Your change has been made.",
    'get_multimedia:delete_response' => "This clip has been deleted.",
    'get_multimedia:delete_title' => "Clip deletion",
    'get_multimedia:report_problem_explanation' => "Thank you for your help in reporting this problem. "
    	."Please give us a comment describing the problem:",
    'get_multimedia:send_to_friend_explanation' => "Please provide the details below and add an optional comment. "
    	."A link to this video clip will be sent to your friend.",
    'get_multimedia:comment_label' => "Comment",
    'get_multimedia:your_name_label' => "Your name",
    'get_multimedia:your_email_label' => "Your email",
    'get_multimedia:friend_name_label' => "Friend name",
    'get_multimedia:friend_email_label' => "Friend email",
    'get_multimedia:problem_report_subject' => "Video problem report",
    'get_multimedia:problem_report_message' => "A problem has been reported for the following video clip:\n\n%s"
    	."\n\nThe problem report is:\n\n%s",
    'get_multimedia:send_to_a_friend_subject' => "%s has sent you a video clip",
    'get_multimedia:send_to_a_friend_message' => "%s has sent you the following video clip:\n\n%s",
    'get_multimedia:send_to_a_friend_comment_bit' => "\n\nand has added the comment:\n\n%s",
    'get_multimedia:report_problem_title' => "Report video clip problem",
    'get_multimedia:send_to_a_friend_title' => "Send to a friend",
    'get_multimedia:send_to_a_friend_error' => "Error: Please check to make sure that you have entered the "
    	."required information (including valid email addresses) and try again.",
    'get_multimedia:send_to_a_friend_response' => "Your message has been sent to your friend. You can send "
    	."this clip to another friend or return to the video wall by clicking on the link at the left.",
    'get_multimedia:report_problem_error' => "Error: please include a comment describing the problem.",
    'get_multimedia:report_problem_response' => "Thank your for reporting this video clip problem. "
    	."You can return to the video wall by clicking on the link at the left.",
    'get_multimedia:join_in_explanation' => "Video explanation would go here",
    'get_multimedia:join_in_title' => "Join In!",
    'get_multimedia:clip_title' => "Video clip :: %s",
    'get_multimedia:recommendations' => "recommendations",
    'get_multimedia:recommend_this' => "Recommend this",
    'get_multimedia:recommend_response' => "You have recommended this clip.",
    'get_multimedia:recommend_error' => "Error: Please try again later.",
    'get_multimedia:notfound_title' => "Clip not found",
    'get_multimedia:notfound_explanation' => "Either this video clip does not exist or you do not have the right to see it.",
    'get_multimedia:mailbox_not_readable_error' => "Error: mailbox %s is not readable by PHP.",
    
    /* The following bits of text are passed to the Video wall Flash application */
    
    'get_multimedia:video_problem_text' => "REPORT VIDEO PROBLEM",
	'get_multimedia:show_me_more_text' => "SHOW ME MORE",
	'get_multimedia:join_in_text' => "Join in",
	'get_multimedia:send_to_a_friend_text' => "Send to a friend",
	'get_multimedia:comment_text' => "Comment",
	'get_multimedia:loading_text' => "... Loading ...",
	'get_multimedia:single_recommendation_text' => " recommendation",
	'get_multimedia:multiple_recommendations_text' => " recommendations",
	'get_multimedia:single_comment_text' => " comment",
	'get_multimedia:multiple_comments_text' => " comments",

    );
    	
    add_translation("en",$english);
    ?>