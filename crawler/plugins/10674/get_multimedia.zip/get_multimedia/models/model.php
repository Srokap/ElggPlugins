<?php
/**
 * Elgg get_multimedia model
 * Functions to save and display video clips
 *
 * @package Elgg get_multimedia
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2008
 * @link http://radagast.biz/
 */

function get_multimedia_count_recommendations($clip) {
	return count_annotations($clip->getGUID(), 'object', 'get_multimedia_clip', 'get_multimedia:recommendation', "","", 0);
}

function get_multimedia_has_recommended($clip) {
	return count_annotations($clip->getGUID(), 'object', 'get_multimedia_clip', 'get_multimedia:recommendation', "","", $_SESSION['user']->getGUID());
}

function get_multimedia_recommend($cn) {
    if (isloggedin()) {
        $user_guid = $_SESSION['user']->getGUID();
        $number_of_my_recommendations = count_annotations($cn, 'object', 'get_multimedia_clip', 'get_multimedia:recommendation', "","", $user_guid);

        if ($number_of_my_recommendations == 0) {
            create_annotation($cn, 'get_multimedia:recommendation', 1, 'integer', $user_guid, ACCESS_PUBLIC);
            return true;
        } else {
            return false;
        }
    }
    return false; 
}

function get_multimedia_notify_by_email($event,$entity_type,$entity) {
	global $CONFIG;

	if ($event == 'publish' && $entity_type == "object" && $entity->getSubtype() == 'get_multimedia_clip') {
		$to = '';

		if (substr($entity->source,0,4) == 'web:') {
			$to = substr($entity->source,5);
		} else if (substr($entity->source,0,6) == 'email:') {
			$to = substr($entity->source,7);
		}

		if ($to) {
			$id = $entity->getGUID();
			$subject = elgg_echo('get_multimedia:notification_subject');
			$message = sprintf(elgg_echo('get_multimedia:notification_message'),$entity->title, $CONFIG->wwwroot.'mod/get_multimedia/wall.php?cn='.$id);
			get_multimedia_send_email($to,$subject,$message);
		}
	}
	return $entity;
}

function get_multimedia_send_email($to,$subject,$message) {
	global $CONFIG;
	
	$site = get_entity($CONFIG->site_guid);
	if ($site->email) {
		// this should be defined as of Elgg 1.1
		$from = $site->email;
	} else {
		// Elgg 1.0 fall back
		$from = 'noreply@' . get_site_domain($CONFIG->site_guid);
	}
	$headers = 'From: '.$from . "\r\n" .
	                'X-Mailer: PHP/' . phpversion();
	//print "Would email to: $to, subject: $subject <br />message: $message";
	mail ( $to, $subject, $message, $headers);
}

function get_multimedia_successful_uploads() {
	return get_entities_from_metadata('status','upload_succeeded','object','get_multimedia_clip',0,500,0,"");
}

function get_multimedia_stats() {
	$stats = new stdClass();
	$stats->total = get_entities("object", "get_multimedia_clip", 0, "", 10, 0, true);
	$cats = array();
	$cats['upload_succeeded'] = get_entities_from_metadata('status', 'upload_succeeded', "object", "get_multimedia_clip", 0, 10, 0, "", 0, true);
	$cats['upload_failed'] = get_entities_from_metadata('status', 'upload_failed', "object", "get_multimedia_clip", 0, 10, 0, "", 0, true);
	$cats['transcoded'] = get_entities_from_metadata('status', 'transcoded', "object", "get_multimedia_clip", 0, 10, 0, "", 0, true);
	$cats['deleted'] = get_entities_from_metadata('status', 'deleted', "object", "get_multimedia_clip", 0, 10, 0, "", 0, true);
	$stats->categories = $cats;

	return $stats;
}

function get_multimedia_priority_clips($number_of_clips) {
	$metadata = array('status' => 'transcoded', 'priority'=>1);
	$clips =  get_entities_from_metadata_multi($metadata,'object','get_multimedia_clip',0,$number_of_clips);
	if ($clips) {
		return $clips;
	} else {
		return array();
	}
}

function get_multimedia_non_priority_clips($number_of_clips) {
	$metadata = array('status' => 'transcoded', 'priority'=>0);
	$clips = get_entities_from_metadata_multi($metadata,'object','get_multimedia_clip',0,$number_of_clips);
	if ($clips) {
		return $clips;
	} else {
		return array();
	}
}

function get_multimedia_number_of_recommendations($clip) {
	return count_annotations($clip->getGUID(), "object", "get_multimedia_clip", "recommendation");
}

function get_multimedia_number_of_comments($clip) {
	return count_annotations($clip->getGUID(), "object", "get_multimedia_clip", "generic_comment");
}

function get_multimedia_handle_upload() {

	// Load get_multimedia config file
	include(dirname(dirname(__FILE__)) . "/config/config.php");

	if (!isset($multimedia_upload_directory)) {
		// uh oh, the get_multimedia configuration file has not been set
		throw new ConfigurationException(elgg_echo('get_multimedia:configuration_exception'));
	}

	$legal_suffixes = array('avi','3gp','3gpp','wmv','mov','mp4','flv');

	$name = get_input('name','');
	$location = get_input('location','');
	$tags = get_input('tags','');
	$email = get_input('email','');
	$user_guid = get_input('user_guid',0);
	if ($email) {
		if (is_email_address($email)) {
			if ($location) {
				$subject = $name . ' - '.$location;
			} else {
				$subject = $name;
			}
			 
			$basename = basename( $_FILES['uploaded_file']['name']);
			//print $basename;
			$suffix_pos = strrpos($basename,'.');
			$suffix = strtolower(substr($basename,$suffix_pos+1));
			if (in_array($suffix,$legal_suffixes)) {
				// OK, everything looks good
				 
				// save clip data object
				 
				$obj = new ElggObject();
				$obj->subtype = 'get_multimedia_clip';
				$obj->access_id = ACCESS_PUBLIC;
				$obj->owner_guid = $user_guid;
				$obj->title = $subject;
				$obj->runtime = 0;
				$obj->pubDate = date('r');
				$obj->thumbnail = '';
				$obj->source = 'web: '.$name.' <'.$email.'>';
				$obj->uploadtime = time();
				$obj->file_type = 'video/'.$suffix;
				$obj->url =  $_FILES['uploadedfile']['name'];
				$obj->priority = 0;
				$obj->height = 0;
				$obj->width = 0;
				$obj->status = 'upload_failed';
				 
				// insert clip tags
				 
				// KJ - I reverse the array to fix an annoying Elgg tag order bug
				// I will remove this workaround when the bug is fixed
				$obj->tags = array_reverse(string_to_tag_array($tags));

				if (!$obj->save()) {
					return false;
				}
				 
				$target_path = $multimedia_upload_directory.$obj->getGUID().'.'.$suffix;
				 
				//print '|'.$target_path;
				 
				if(!move_uploaded_file($_FILES['uploaded_file']['tmp_name'], $target_path)) {
					//print 'file move failed';
					$obj->status = 'upload_failed';
					$obj->save();
					return false;
				}

			} else {
				//print 'illegal file suffix';
				return false;
			}
			 
		} else {
			//print 'email address validation error';
			return false;
		}
	} else {
		//print 'no email address';
		return false;
	}

	$obj->status = 'upload_succeeded';
	$obj->save();

	return true;
}

function get_multimedia_delete($cn) {
	global $CONFIG;

	$clip = get_entity($cn);

	if ($clip && $clip->getSubtype() == "get_multimedia_clip") {

		$mdir = dirname(dirname(__FILE__)).'/clips/';
		unlink($mdir.$cn.'.flv');
		unlink($mdir.$cn.'.flv.jpg');
		unlink($mdir.$cn.'.flv.thumb.jpg');
		$clip->status = 'deleted';
		$clip->save();
	}
}

function get_multimedia_report_problem($cn,$comment) {
	global $CONFIG;
	
	// Load get_multimedia config file
	include(dirname(dirname(__FILE__)) . "/config/config.php");

	if (!isset($video_problem_reports)) {
		// uh oh, the get_multimedia configuration file has not been set
		throw new ConfigurationException(elgg_echo('get_multimedia:configuration_exception'));
	}

	$comment = trim($comment);

	if ($comment && $cn) {
		$subject = elgg_echo('get_multimedia:problem_report_subject');
		$to = $video_problem_reports;
		$clip_url = $CONFIG->wwwroot.'mod/get_multimedia/clip_page.php?cn='.$cn;
		$message = sprintf(elgg_echo('get_multimedia:problem_report_message'),$clip_url,$comment);
		get_multimedia_send_email($to,$subject,$message);
		return true;
	}
	return false;
}

function get_multimedia_send_to_friend($cn,$your_name,$your_email,$friend_name,$friend_email,$comment) {
	global $CONFIG;
	
	$your_name = trim($your_name);
	$your_email = trim($your_email);
	$friend_name = trim($friend_name);
	$friend_email = trim($friend_email);
	$comment = trim($comment);
	if ($your_name && is_email_address($your_email) && $friend_name && is_email_address($friend_email)) {
		$subject = sprintf(elgg_echo('get_multimedia:send_to_a_friend_subject'),$your_name);
		$to = $friend_name ." <$friend_email>";
		$sender = $your_name ." <$your_email>";
		$clip_url = $CONFIG->wwwroot.'mod/get_multimedia/clip_page.php?cn='.$cn;
		$message = sprintf(elgg_echo('get_multimedia:send_to_a_friend_message'),$sender,$clip_url);
		if ($comment) {
			$message .= sprintf(elgg_echo('get_multimedia:send_to_a_friend_comment_bit'),$comment);
		}
		get_multimedia_send_email($to,$subject,$message);
		return true;
	}
	return false;	
}

?>