/**
 * Get, display and manage video clips
 * 
 * @package get_multimedia
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2008
 * @link http://radagast.biz/
 * 
 */
 
Thank you to Rene Kanzler from http://cosmomill.de for funding the
conversion of this plugin to Elgg 1.x.
 
The Elgg 1.x get_multimedia plugin gets video clips from a variety of
sources, transcodes them to the Flash video (flv) format, displays them
on a video wall and allows your site visitors to recommend them, comment
on them, sent them to friends, and report problems.
 
Site administrators can edit the title and tags associated with a video,
delete them, and set their priority status. Priority videos are more likely
to be displayed on the video wall, giving admins the ability to promote 
higher quality videos.
 
get_multimedia depends upon ffmpeg (http://ffmpeg.mplayerhq.hu/) to transcode
the videos to Flash format and the Imagemagick convert utility 
(http://www.imagemagick.org) to produce video thumbnails.

Compiling ffmpeg to properly support mobile phone or other video and audio 
formats is a complex subject and will not be dealt with here.

Videos can be uploaded using a web form or extracted from attachments to
email messages sent to an mbox format email box.

Note that the get_email.php routine currently supports only mbox email
box formats. Other formats are not currently supported.

Interfaces to various MMS providers are also under development.

Configuring get_multimedia

Text can be configured in the usual Elgg 1.x way by editing the file(s) in the
mod/get_multimedia/languages directory.

In addition, you must configure get_multimedia before running it by setting
the values in the mod/get_multimedia/config/config.php file. This file
contains its own documentation.

Clip options

When viewing the video wall, users can use a small menu below the active clip
to send the clip to a friend, go to a page to comment on or recommend a clip,
and visit a join-in page. Additionally, when the active clip stops running,
the user can click on a "Report video problem" link to report objectionable
or unwatchable videos.

Anyone can read clip comments. Users must be logged-in to recommend or comment
on a clip. The default join-in text does not say very much. You may want to
change this text or replace the mod/get_multimedia/join_in.php page entirely.

If you are logged-in as a site administrator, you can click on the active
clip to edit the title and tags, set the clip priority, or delete the clip.

Deleting the clip removes the related data in the clips directory and sets the
Elgg get_multimedia_clip status to "deleted". It does not remove the original
upload file in the multimedia uploads directory, so in principal you could
"undelete" a clip by setting the status to "upload_succeeded" and running the
transcoder. There is no user interface for editing the clip status however.

Cron jobs

You should run mod/get_multimedia/transcode.php and (if using email submission)
mod/get_multimedia/get_email.php in frequent cron jobs - I recommend about every 
five or ten minutes.

Video clips will not be transcoded or retrieved from email queues if these jobs
are not run.

Customising get_multimedia

The Actionscript and XML sources for the Flash resources are included in
the mod/get_multimedia/flash directory.

The Actionscript routines communicate with the get_multimedia plugin using the
mod/get_multimedia/get_data.php file for the video wall and the
mod/get_multimedia/get_clip_info.php file for individual video clips.

You can compile the two supplied Actionscript files using 
mtasc (http://www.mtasc.org/). The command lines are:

mtasc -v  -main -header 685:420:15 -swf video_wall2.swf Video_wall.as

mtasc -v  -main -header 180:180:15 -swf video_player.swf Video_player.as

You can compile the two required swfml resource files using 
swfmill (http://swfmill.org/). These require arial.ttf and 
arialbd.ttf fonts which are not included here but are widely available
if not already installed on your computer.

You can also change the transcoding parameters by editing the
mod/get_multimedia/lib/transcode_to_flv.sh shell file.

(Remember that most shells will not properly interpret files
that do not have standard Unix line endings, so be careful when
editing this file on non-Unix operating systems.)
