/**
	 * Elgg readme
	 * 
	 * @package ElggMessages
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dave Tosh <dave@elgg.com>
	 * @modified Dimentox
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
*/

1. Install folder to the mods directory.

2. move the recmail.php.move.to.site.root to your root of the elgg install and rename it to recmail.php

3. Configure your domain to have a catch all user/email address basically a *@domain.com. 

4. install/copy the procmailrc-dist to the users home directory as .procmailrc

5. edit the procmailrc to point to the proper location of the recmail.php

6. Profit? LOL After that you should be live!



todo:
Add replying instead of forcing a new message.
Tidy up the headers.
Fix the message content so its parsed and just not the raw message.
Add attachment parsing.
Fix saving to sent items.
Add pop3 sub server for remote mail.
add smtp server for remote mail (avoid using regular)
