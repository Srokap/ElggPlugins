<?php
	/**
	 * Elgg garbage collector language pack.
	 * 
	 * @package ElggGarbageCollector
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$basque = array(
	
		/**
		 * Menu items and titles
		 */
	
			'garbagecollector:period' => 'Zer maiztasunarekin exekutatu behar da Elgg-en zabor biltzailea?',
	
			'garbagecollector:weekly' => 'Astean behin',
			'garbagecollector:monthly' => 'Hilean behin',
			'garbagecollector:yearly' => 'Urtean behin',
	
			'garbagecollector' => "ZABOR BILTZAILEA\n",
			'garbagecollector:done' => "EGINDA\n",
			'garbagecollector:optimize' => "%s optimizatzen ",
	
			'garbagecollector:error' => "ERROREA",
			'garbagecollector:ok' => "ONDO",
	
			'garbagecollector:gc:metastrings' => 'Lotuta ez dauden metastring-ak garbitzen: ',
	
	);
					
	add_translation("eu",$basque);
?>