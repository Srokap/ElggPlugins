<?php

	$basque = array(
	
		/**
		 * Menu items and titles
		 */
	
			'expages' => "Kanpo orriak",	
                        'expages:frontpage' => "Hasiera orria",
                        'expages:about' => "Honi buruz",
                        'expages:terms' => "Baldintzak",
                        'expages:privacy' => "Pribatutasuna",
                        'expages:analytics' => "Estatistikak",
                        'expages:contact' => "Kontaktua",
                        'expages:nopreview' => "Ez dago aurrebistarik oraindik",
                        'expages:preview' => "Aurrebista",
                        'expages:notset' => "Orri hau ez dago konfiguraturik oraindik.",
                        'expages:lefthand' => "Ezker informazio-panela",
                        'expages:righthand' => "Eskuin informazio-panela",
			'expages:addcontent' => "Edukia gehitu dezakezu hemen kudeaktea gunetik. Kanpoko orriak atala bilatu kudeaketa guenan..",
			'item:object:front' => 'Hasiera orriko elementuak',
	
		/**
		 * Status messages
		 */
	
			'expages:posted' => "Zure orriko mezua ondo argitaratu da.",
			'expages:deleted' => "Zure orriko mezua ezabatua izan da.",
	
		/**
		 * Error messages
		 */
	
			'expages:deleteerror' => "Arazo bat egon da orri zahar bat ezabatzean",
			'expages:error' => "Errore bat egon da, saiatu berriro eta arazoak jarraitzen badu, kudeatzailearekin kontaktuan jarri",
	
	);
					
	add_translation("eu",$basque);

?>
