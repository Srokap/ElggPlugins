<?php

	$basque = array(
	
		/**
		 * Manifest
		 */
		
	
		'river:widget:noactivity' => 'Ez dugu aktibitaterik aurkitu.',
		'river:widget:title' => "Aktibitatea",
		'river:widget:description' => "Zure aktibitaterik berriena erakutsi.",
		'river:widget:title:friends' => "Lagunen aktibitatea",
		'river:widget:description:friends' => "Erakutsi zertan ari diren zure lagunak.",
	
		'river:widget:label:displaynum' => "Erakutsi beharreko sarrera kopurua:",
	);
					
	add_translation("eu",$basque);

?>
