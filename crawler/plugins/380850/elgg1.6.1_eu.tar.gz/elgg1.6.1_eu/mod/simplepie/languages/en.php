<?php

	$english = array(	
      'simplepie:widget' => 'Blog',
      'simplepie:description' => 'Add an external blog to your profile',
      'simplepie:notset' => 'Feed url is not set',
      'simplepie:notfind' => 'Cannot find feed. Check the feed url.',
      'simplepie:feed_url' => 'Feed URL',
      'simplepie:num_items' => 'Number of items',
      'simplepie:excerpt' => 'Include excerpt',	
      'simplepie:post_date' => 'Include post date',	
	);
					
	add_translation("en",$english);

?>
