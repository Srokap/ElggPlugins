<?php

	$basque = array(	
      'simplepie:widget' => 'Bloga',
      'simplepie:description' => 'Kanpoko blog bat gehitu zure profilera',
      'simplepie:notset' => 'Jarioaren URLa ez dago finkatua',
      'simplepie:notfind' => 'Ezin da jarioa aurkitu. Konprobatu jarioaren URL.',
      'simplepie:feed_url' => 'Jarioaren URL',
      'simplepie:num_items' => 'Artikulu kopurua',
      'simplepie:excerpt' => 'Erantsi pasartea',	
      'simplepie:post_date' => 'Erantsi sarreraren data',	
	);
					
	add_translation("eu",$basque);

?>
