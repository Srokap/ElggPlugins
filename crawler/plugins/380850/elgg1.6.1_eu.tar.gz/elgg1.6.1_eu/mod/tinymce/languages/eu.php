<?php

	$basque = array(
	
		/**
		 * Menu items and titles
		 */
	
		'tinymce:remove' => "Gehitu/Kendu editorea",
	
	);
					
	add_translation("eu",$basque);

?>
