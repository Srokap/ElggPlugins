<?php

	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
		'tinymce:remove' => "Add/Remove editor",
	
	);
					
	add_translation("en",$english);

?>