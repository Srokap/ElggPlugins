<?php

	$basque = array(
	
		/**
		 * Site info details
		 */
		
		'members:members' => "Guneko erabiltzaileak",
	    'members:online' => "Gunean aktibo dauden erabiltzaileak",
	    'members:active' => "guneko erabiltzaileak",
	    'members:searchtag' => "Erabiltzaileak etiketa bidez bilatu",
	    'members:searchname' => "Erabiltzaileak izenez bilatu",
	   
		'members:label:newest' => 'Berriena',
		'members:label:popular' => 'Ezagunena',
		'members:label:active' => 'Aktiboa',
		
	);
					
	add_translation("eu",$basque);

?>
