<?php
	/**
	 * Elgg file plugin language pack
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$basque = array(
	
		/**
		 * Menu items and titles
		 */
	
			'file' => "Fitxategiak",
			'files' => "Fitxategiak",
			'file:yours' => "Zure fitxategiak",
			'file:yours:friends' => "Zure lagunen fitxategiak",
			'file:user' => "%s-(r)en fitxategiak",
			'file:friends' => "%s-(r)en lagunen fitxategiak",
			'file:all' => "Fitxategi guztiak",
			'file:edit' => "Editatu fitxategia",
			'file:more' => "fitxategi gehiago",
			'file:list' => "zerrenda ikuspegia",
			'file:group' => "Fitxategiak taldekatu",
			'file:gallery' => "galeria ikuspegia",
			'file:gallery_list' => "Galeria edo zerrenda ikuspegia",
			'file:num_files' => "Erakutsi beharreko fitxategi kopurua",
			'file:user:gallery'=>'Ikusi %s galeria', 
	                'file:via' => 'fitxategien bidez',
                        'file:upload' => "Fitxategi bat igo",

                        'file:newupload' => 'Fitxategi berri bat igo',	
			
			'file:file' => "Fitxategia",
			'file:title' => "Izenburua",
			'file:desc' => "Deskribapena",
			'file:tags' => "Etiketak",
	
			'file:types' => "Igotako fitxategi motak",
	
			'file:type:all' => "Fitxategi guztiak",
			'file:type:video' => "Bideoak",
			'file:type:document' => "Dokumentuak",
			'file:type:audio' => "Audioa",
			'file:type:image' => "Irudiak",
			'file:type:general' => "Orokorra",
	
			'file:user:type:video' => "%s-(r)en bideoak",
			'file:user:type:document' => "%s-(r)en dokumentuak",
			'file:user:type:audio' => "%s-(r)en audioa",
			'file:user:type:image' => "%s-(r)en irudiak",
			'file:user:type:general' => "%s-(r)en fitxategi orokorrak",
	
			'file:friends:type:video' => "Zure lagunenbideoak",
			'file:friends:type:document' => "Zure lagunen dokumentuak",
			'file:friends:type:audio' => "Zure lagunen audioa",
			'file:friends:type:image' => "Zure lagunen irudiak",
			'file:friends:type:general' => "Zure lagunen fitxategi orokorrak",
	
			'file:widget' => "Fitxategi-widgeta",
			'file:widget:description' => "Zure fitxategi berrien bitrina",
	
			'file:download' => "Hau deskargatu",
	
			'file:delete:confirm' => "Ziur fitxategi hau ezabatu nahi duzula?",
			
			'file:tagcloud' => "Etiketen hodeia",
	
			'file:display:number' => "Erakutsi beharreko fitxategi kopurua",
	
			'file:river:created' => "%s-(e)k igo du",
			'file:river:item' => "fitxategi bat",
			'file:river:annotate' => "%s-(e)k komentatu du",

			'item:object:file' => 'Fitxategiak',
			
	    /**
		 * Embed media
		 **/
		 
		    'file:embed' => "Lotutako multimedia",
		    'file:embedall' => "Guztiak",
	
		/**
		 * Status messages
		 */
	
			'file:saved' => "Zure fitxategia gorde egin da.",
			'file:deleted' => "Zure fitxategia ezabatu egin da.",
	
		/**
		 * Error messages
		 */
	
			'file:none' => "Ezin izan dugu fitxategirik aurkitu momentu honetan.",
			'file:uploadfailed' => "Barkatu, baina ezin izan dugu zure fitxategia gorde.",
			'file:downloadfailed' => "Barkatu, baina fitxategi hau ez dago eskuragarri momentu honetan.",
			'file:deletefailed' => "Zure fitxategia ezin izan da ezabatu.",
	
	);
					
	add_translation("eu",$basque);
?>
