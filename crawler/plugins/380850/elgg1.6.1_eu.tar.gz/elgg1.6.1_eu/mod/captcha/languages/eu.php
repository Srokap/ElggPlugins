<?php

	$basque = array(
	
		'captcha:entercaptcha' => 'Sartu irudian agertzen den testua',
		'captcha:captchafail' => 'Barkatu, sartutako testua ez dator bat irudiko testuarekin.',
	
	);
					
	add_translation("eu",$basque);
?>
