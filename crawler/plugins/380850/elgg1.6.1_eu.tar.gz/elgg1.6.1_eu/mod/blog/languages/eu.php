<?php

	$basque = array(

  'blog' => 'Bloga',
  'blogs' => 'Blogak',
  'blog:user' => '%s-(r)en bloga',
  'blog:user:friends' => '%s-(r)en lagunen bloga',
  'blog:your' => 'Zure bloga',
  'blog:posttitle' => '%s-(r)en bloga: %s',
  'blog:friends' => 'Lagunen blogak',
  'blog:yourfriends' => 'Zure lagunen azkenengo blogak',
  'blog:everyone' => 'Blog guztiak',
  'blog:newpost' => 'Blog mezu berria',
  'blog:via' => 'blog bidez',
  'blog:read' => 'Bloga irakurri',
  'blog:addpost' => 'Mezua idatzi blogan',
  'blog:editpost' => 'Mezua editatu blogan',
  'blog:text' => 'Blogaren testua',
  'blog:strapline' => '%s',
  'item:object:blog' => 'Blog mezuak',
  'blog:never' => 'inoiz',
  'blog:preview' => 'Aurrebista',
  'blog:draft:save' => 'Zirriborroa gorde',
  'blog:draft:saved' => 'Zirriborroa azken aldiz gorde da',
  'blog:comments:allow' => 'Iruzkinak baimendu',
  'blog:preview:description' => 'Zure blog mezu baten gorde bateko aurrebista bat da.',
  'blog:preview:description:link' => 'Mezua gorde edo editatzen jarraitzeko, egin klik.',
  'blog:enableblog' => 'Taldeko bloga gaitu',
  'blog:group' => 'Taldeko bloga',
  'blog:river:created' => '%s-(e)k sortu du',
  'blog:river:updated' => '%s-(e)k eguneratu du',
  'blog:river:posted' => '%s-(e)k idatzi du',
  'blog:river:create' => 'blog mezu berria.',
  'blog:river:update' => 'blog mezua.',
  'blog:river:annotate' => 'iruzkina blog mezu batean.',
  'blog:posted' => 'Zure blog mezua bidali da.',
  'blog:deleted' => 'Zure blog mezua ezabatu da.',
  'blog:error' => 'Zerbait gaizki atera da. Mesedez saiatu berriro.',
  'blog:save:failure' => 'Zure blog mezua ezin izan da gorde. Saiatu berriro, mesedez.',
  'blog:blank' => 'Barkatu, baina bai izenburua, bai gorputza bete behar dituzu mezua bidali aurretik.',
  'blog:notfound' => 'Barkatu, baina ezin izan dugu zehaztutako blog mezua aurkitu.',
  'blog:notdeleted' => 'Barkatu, baina ezin izan dugu blog mezu hau.',

	);
	
	add_translation("eu",$basque);

?>
