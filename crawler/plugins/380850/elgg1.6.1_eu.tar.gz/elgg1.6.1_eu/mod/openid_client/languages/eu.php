<?php

	$basque = array(	
			
		'openid_client_login_title'                     => "OpenID erabiliz saioa hasi",
		'openid_client_login_service'                   => "Zerbitzua",
		'openid_client_logon'                           => "Saio-hasiera",
		'openid_client_go'                              => "Hasi",
		'openid_client_remember_login'                  => "Gogoratu",
		'openid_client:already_loggedin'                => "Saioa hasi duzu jada.",
		'openid_client:login_success'                   => "Saio hasi duzu.",
		'openid_client:login_failure'                   => "Erabiltzailea ez duzu espezifikatu. Ezin duzu sartu.",
		'openid_client:disallowed'                      => "Guneak ez du sartu duzun OpenIDa onartzen."
			."Saiatu beste OpenID bat erabiliz edo guenaren kudeatzailearekin harremanetan jarri.",
		'openid_client:redirect_error'                  => "Ezin izan da zerbitzarira berbideratu: %s",
		'openid_client:authentication_failure'          => "OpenID autentikazioak huts egin du: %s OpenID url baliagarri bat.",
		'openid_client:authentication_cancelled'        => "OpenID autentikazioa ezeztatua.",
		'openid_client:authentication_failed'           => "OpenID autentikazioak huts egin du (egoera: %s, mezua: %s )",
		'openid_client:banned'                          => "Sistematik kanporatua izan zara!",
		'openid_client:email_in_use'                    => "Ezin duzu zure posta elektronikoa %s -ra aldatu, sisteman erabiltzen da eta.",
		'openid_client:email_updated'                   => "Zure posta elektronikoa %s izatera pasa da",
		'openid_client:information_title'               => "OpenID informazioa",
		'openid_client:activate_confirmation'           => "Baieztapen mezu bat bidali da %s helbidera ."
		        ." Klik egin mezu horretako loturan zure kontuak gaitzeko."
		        ." Hemendik aurrera OpenID horrekin saioa hasteko aukera izango duzu.",
        'openid_client:change_confirmation'             => "Zure posta elektronikoa aldatu da. Baieztapen mezu bat bidali da"
                ." zure helbide berrira, %s -(t)an . Egin klik mezu horretako loturan zure posta elektronikoa baieztatzeko.",
        'openid_client:activate_confirmation_subject'   => "%s kontu egiaztapena",
        'openid_client:activate_confirmation_body'      => "Kaixo %s,\n\nEskerrik asko %s erabiliz saioa hasteagatik.\n\n"
            ."Zure izen ematearekin amaitzeko, URL hau bisitatu:\n\n\t%s\n\n hurrengo zazpi egunetan zehar.\n\nEsker mila,\n\n 
%s taldea.",
        'openid_client:change_confirmation_subject'     => "%s posta elektronikoa aldatua",
        'openid_client:change_confirmation_body'        => "Kaixo %s,\n\nZure posta elektronikoa aldatzeko eskari bat jaso dugu."
            ." %s erabiltzaiearentzat.\n\nZure posta elektronikoa aldatzeko {%s}, URL hau bisitatu:\n\n\t%s\n\nhurrengo zazpi egunetan."
            ."\n\nEsker mila,\n\n%s taldea.",				
	    'openid_client:email_label'                     => "Email:",
	    'openid_client:name_label'                      => "Izena:",
	    'openid_client:submit_label'                    => "Bidali",
	    'openid_client:cancel_label'                    => "Ezeztatu",
	    'openid_client:nosync_label'                    => "Ez jakinarazi berriro sisteman dagoen informazioa zerbitzariko"
	        ." berdina ez bada.",
	    'openid_client:sync_instructions'               => "Zure Open ID zerbitzariko informazioa ez da sistema honen berdina."
	        ." Markatu eguneratu nahi duzun informazioaren ondoan dauden kontrol-laukiak (nahi baduzu) eta bidali sakatu.",
	    'openid_client:missing_title'					=> "Falta den informazioa bete",
	    'openid_client:sync_title'						=> "Sinkronizatu zure informazioa",
	    'openid_client:missing_email'                   => "email helbide baliagarri bat",
	    'openid_client:missing_name'                    => "zure izen osoa",
	    'openid_client:and'                             => "eta",
	    'openid_client:missing_info_instructions'       => "Gune honetan kontu bat sortzeko %s bat behar duzu."
	        ." Sartu informazioa ondoren.",
	    'openid_client:create_email_in_use'             => "Ezin da kontu bat sortu posta elektroniko horrekin %s ,sisteman erabilita 
dagoelako.",
	    'openid_client:missing_name_error'              => "Izen bat sartu behar duzu.",
	    'openid_client:invalid_email_error'             => "Posta elektroniko baliagarri bat sartu behar duzu.",
	    'openid_client:invalid_code_error'              => "Formulario kodea akatsduna dirudi. Kodeek zazpi egunetako epea dute;"
	        ." zurea zaharragoa izan daiteke.",
	    'openid_client:user_creation_failed'            => "Ezinezkoa OpenID kontu bat sortzea.",
	    'openid_client:created_openid_account'          => "OpenID kontua sortua, posta elektronikoa %s eta izena %s Open ID zerbitzaritik ekarri 
dira.",
	    'openid_client:name_updated'                    => "Zure izena %s -ra aldatu da.",
	    'openid_client:missing_confirmation_code'       => "Zure konfirmazio kodea falta da. Lotura egiaztatu eta saiatu berriro.",
	    'openid_client:at_least_13'                     => "13 urte baino gehiago dituzula markatu behar duzu.",
	    'openid_client:account_created'                 => "Zure kontua sortu da! Eman duzun OpenID (%s -a) erabiliz sar zaitezke orain.",
	    'openid_client:email_changed'                   => "Zure posta elektroniko helbidea {%s -ra} aldatu da . "
		    ."Saioa hasieratu ez baduzu orain zure OpenIDa erabiliz sar zaitezke",
            'openid_client:thankyou'                        => "Eskerrik asko %s erabiliz izen emateagatik!"
	        ." Izen ematena doan da, baina zure datuak baieztatu aurretik,"
	        ." dokumentu hauek irakurtzeko denbora bat hartu:",
	    'openid_client:terms'                           => "baldintzak",
	    'openid_client:privacy'                         => "pribatutasun politika",
	    'openid_client:acceptance'                      => "Formulario hau bidaltzeak baldintza hauen onarpena adierazten du. "
	        ."Kontutan hartu 13 urte baino gehiago izan behar dituzula izena emateko.",
	    'openid_client:correct_age'                     => "Hamahiru urte baino gehiago ditut.",
	    'openid_client:join_button_label'               => "Sartu",
	    'openid_client:confirmation_title'              => "OpenID baieztapena",
	    'openid_client:admin_title'                     => "Konfiguratu OpenID bezeroa",
	    'openid_client:default_server_title'             => "Zerbitzari lehenetsia",
	    'openid_client:default_server_instructions1'     => "OpenID bidezko saio hasieraketa erraztu dezakezu OpenID zerbitzari lehenetsi bat aukeratuz."
            ." OpenID erabiliz izen arrunt bat sartzen duten erabiltzaileak (eg. \"susan\") OpenID helbide oso bat izango dute,"
	        ." zerbitzari bat definituz gero. Jarri\"%s\" kontuaren izena jarri nahi duzun tokian. Adibidez, sartu"
	        ." \"http://openidserver.com/%s/\" OpenID helbide hau lortu nahi baduzu \"http://openidserver.com/susan/\" edo"
	        ." \"http://%s.openidserver.com/\" OpenID helbide hau lortu nahi baduzu \"http://susan.openidserver.com/\"",
	    'openid_client:default_server_instructions2'    => " (\".\"-ak) erabiltzen dira OpenID URL helbideak erabiltzaile kontu arruntetik"
	        ." bereizteko, kontu izenetan puntuak onartzen ez dituzten zerbitzarietan bakarrik erabiltzeko .",
	    'openid_client:server_sync_title'               => "Zerbitzari sinkronizazioa",
	    'openid_client:server_sync_instructions'        => "Markatu aukera hau automatikoki eguneratu nahi badituzu erabiltzailearen datuak"
	        ." posta elektronikoa edota izena OpenID zerbitzarikoekin ezberdinak badira. Utzi aukera hau markatu gabe"
	        ." erabiltzaileak izen eta posta elektroniko ezberdin batzuk izatea nahi baduzu sisteman."
	        ." OpenID zerbitzarikoekin konparatuz.",
	    'openid_client:server_sync_label'               => "Automatikoki eguneratu OpenID zerbitzaritik.",
	    'openid_client:lists_title'                     => "OpenID zerrenda",
	    'openid_client:lists_instruction1'              => "Onartzen diren OpenID zerbitzarien zerrenda berdeak, horiak edo gorriak defini daitezke.",
	    'openid_client:lists_instruction2'              => "Zerrenda berdeak identifikazio osorako onartzen diren OpenID zerbitzariak daude."
	        ." Zerbitzari horrek posta elektroniko helbide baliagarri bat eman dezake.",
	    'openid_client:lists_instruction3'              => "Zerrenda horiak identifikaziorako bakarrik onartzen diren OpenID zerbitzariak daude."
	        ." Posta elektroniko bat ematean, mezu bat bidaliko da helbide horretara konfirmazio eske izen eman baino lehen.",
	    'openid_client:lists_instruction4'              => "Zerrenda gorriak baztertuak izango diren OpenID zerbitzariak daude.",
	    'openid_client:lists_instruction5'              => "Zerrenda gorririk, horirik edo berderik definitzen ez bada, OpenID zerbitzari"
	        ." guztiek berde izaera izango dute (identifikazorako onartuko dira eta emandako posta elektronikoa onartuko da konfirmaziorik"
	        ." konfirmaziorik eskatu gabe).",
	    'openid_client:lists_instruction6'              => "Jarri OpenID zerbitzari bat lerroko.\"*\" erabili dezakezu"
	        ." OpenID eta OpenID zerbitzari posibleak identifikatzeko. OpenID bakoitza http:// edo https:// batez hasi"
	        ." eta slash (\"/\") batekin amaitu behar du- adib. http://*.myopenid.com/",
	    'openid_client:green_list_title'                => "Zerrenda berdea",
	    'openid_client:yellow_list_title'               => "Zerrenda horia",
	    'openid_client:red_list_title'                  => "Zerrenda gorria",
	    'openid_client:ok_button_label'                 => "OK",
	    'openid_client:admin_response'                  => "OpenID bezeroaren konfigurazioa gordea."
	    
	);
					
	add_translation("eu",$basque);

?>
