<?php

	$english = array(
	
		/**
		 * twitter widget details
		 */
		
	
		'twitter:username' => 'Enter your twitter username.',
		'twitter:num' => 'The number of tweets to show.',
		'twitter:visit' => 'visit my twitter',
		'twitter:notset' => 'This Twitter widget is not yet set to go. To display your latest tweets, click on - edit - and fill in your details',
		
		
		 /**
	     * twitter widget river
	     **/
	        
	        //generic terms to use
	        'twitter:river:created' => "%s added the twitter widget.",
	        'twitter:river:updated' => "%s updated their twitter widget.",
	        'twitter:river:delete' => "%s removed their twitter widget.",
	        
		
	);
					
	add_translation("en",$english);

?>