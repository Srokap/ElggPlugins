<?php

	$basque = array(
	
		/**
		 * twitter widget details
		 */
		
	
		'twitter:username' => 'Zure twitter erabiltzailea sartu.',
		'twitter:num' => 'Erakutsiko diren twitter mezu kopurua.',
		'twitter:visit' => 'Nire twitter ikusi',
		'twitter:notset' => 'Twitter widget hau ez dago prest oraindik. Zure azken twitter mezuak erakusteko, editatu botoian sakatu eta 
bete informazioa',
		
		
		 /**
	     * twitter widget river
	     **/
	        
	        //generic terms to use
	        'twitter:river:created' => "%s-ek twitter widget-a gehitu du.",
	        'twitter:river:updated' => "%s-ek twitter widget-a aldatu du.",
	        'twitter:river:delete' => "%s-ek twitter widget-a ezabatu du.",
	        
		
	);
					
	add_translation("eu",$basque);

?>
