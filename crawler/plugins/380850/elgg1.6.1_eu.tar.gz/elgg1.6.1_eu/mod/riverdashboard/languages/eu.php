<?php

	$basque = array(

  'mine' => 'Nirea',
  'filter' => 'Iragazkia',
  'riverdashboard:useasdashboard' => 'Ordeztu aginte-panel lehenetsia ekintza zerrenda honekin?',
  'activity' => 'Ekintza',
  'riverdashboard:recentmembers' => 'Duela gutxiko kideak',
  'sitemessages:announcements' => 'Gune oharrak',
  'sitemessages:posted' => 'Argitaratua',
  'sitemessages:river:created' => 'Gune kudeatzailea, %s,',
  'sitemessages:river:create' => 'argitaratu gune osorako mezu bat',
  'sitemessages:add' => 'Gehitu gune osorako mezu bat',
  'sitemessage:deleted' => 'Guneko mezu bat ezabatua',
  'river:widget:noactivity' => 'Ez dugu ekintzarik aurkitu.',
  'river:widget:title' => 'Ekintza',
  'river:widget:description' => 'Erakutsi zure azken ekintzak.',
  'river:widget:title:friends' => 'Lagunen ekintzak',
  'river:widget:description:friends' => 'Erakutsi zure lagunak zertan ari diren.',
  'river:widgets:friends' => 'Lagunak',
  'river:widgets:mine' => 'Nirea',
  'river:widget:label:displaynum' => 'Erakutsiko diren sarrera kopurua:',
  'river:widget:type' => 'Zein da erakutsi nahi duzun ekintza zerrenda? Zure ekintzak edo zure lagunenak erakutsiko dituena?',
  'item:object:sitemessage' => 'Guneko mezuak',


	);
	
	add_translation("eu",$basque);

?>
