<?php
	/**
	 * Elgg GUID Tool
	 * 
	 * @package ElggGUIDTool
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$basque = array(
	
		/**
		 * Menu items and titles
		 */
	
			'guidtool' => 'GUID tresna',
			'guidtool:browse' => 'GUID-ak arakatu',
			'guidtool:import' => 'Inportatu',
			'guidtool:import:desc' => 'Itsatsi leiho honetan inportatu nahi duzun informazioa. "%s" formatuan egon behar du.',
	
			'guidtool:pickformat' => 'Aukeratu zer formatutan inportatu edo esportatu nahi duzun.',
	
			'guidbrowser:export' => 'Esportatu',
	);
					
	add_translation("eu",$basque);
?>