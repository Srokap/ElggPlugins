<?php
	$basque = array(
		'twitterservice' => 'Twitter Zerbitzua',
		'twitterservice:postwire' => 'Hariko mezu publikoak Twitterren argitaratu nahi dituzu?',
		'twitterservice:twittername' => 'Twitter erabiltzailea',
		'twitterservice:twitterpass' => 'Twitter pasahitza',
	);
					
	add_translation("eu",$basque);
?>
