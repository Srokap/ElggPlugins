<?php
	/**
	 * Elgg log rotator language pack.
	 * 
	 * @package ElggLogRotate
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$basque = array(
		'logrotate:period' => 'Zein maiztasunez artxibatu behar da sistemaren loga?',
	
		'logrotate:weekly' => 'Astean behin',
		'logrotate:monthly' => 'Hilean behin',
		'logrotate:yearly' => 'Urtean behin',
	
		'logrotate:logrotated' => "Loga errotatuta\n",
		'logrotate:lognotrotated' => "Errorea loga errotatzen\n",
	);
					
	add_translation("eu",$basque);
?>