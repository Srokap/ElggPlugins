<?php
	/**
	 * API Admin language pack.
	 * 
	 * @package ElggAPIAdmin
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */


	$basque = array(
	
		/**
		 * Menu items and titles
		 */
	
			'apiadmin' => 'API Kudeaketa',
	
	
			'apiadmin:keyrevoked' => 'API gakoa errebokatu da',
			'apiadmin:keynotrevoked' => 'Ezin izan da API gakoa errebokatu',
			'apiadmin:generated' => 'API gakoa sortu da',
	
			'apiadmin:yourref' => 'Zure erreferentzia',
			'apiadmin:generate' => 'Gako-bikote berria sortu',
	
			'apiadmin:noreference' => 'Gako berrirako erreferentzia eman behar duzu.',
			'apiadmin:generationfail' => 'Arazo bat egon da gako-bikote berria sortzerakoan',
			'apiadmin:generated' => 'Gako-bikote berria sortu da',
	
			'apiadmin:revoke' => 'Gakoa errebokatu',
			'apiadmin:public' => 'Publikoa',
			'apiadmin:private' => 'Pribatua',

	
			'item:object:api_key' => 'API gakoak',
	);
					
	add_translation("eu",$basque);
?>
