<?php

	$basque = array(
	
		/**
		 * Menu items and titles
		 */
	
			'status' => "Egoera",
			'status:user' => "%s-(r)en egoera",
			'status:current'=> "Oraingo egoera",
			'status:desc'=> "Egoera widget-ak zure egoerarik berrienak erakusten ditu.",
			'status:posttitle' => "%s-(r)en egoera: %s",
			'status:everyone' => "Egoera guztiak",
			'status:strapline' => "%s",
			'status:addstatus' => "Zure egoera ezarri",
		    'status:messages' => "egoera mezuak",
			'status:text' => "Egoera:",
			'status:set' => "ezarri ",
			'status:clear' => "egoera garbitu",
			'status:delete' => "egoera ezabatu",
			'status:nostatus' => "Ez da egoerarik ezarri.",
			'status:viewhistory' => "historia ikusi",
	
			'item:object:status' => 'egoera mezuak',
	
	
        /**
	     * Status river
	     **/
	        
	        //generic terms to use
	        'status:river:created' => "%s-(e)k eguneratu du",
	        
	        //these get inserted into the river links to take the user to the entity
	        'status:river:create' => "bere egoera.",
	        
	        
	
		/**
		 * Status messages
		 */
	
			'status:posted' => "Zure egoera berria bidali da.",
			'status:deleted' => "Zure egoera ezabatu egin da.",
	
		/**
		 * Error messages
		 */
	
			'status:blank' => "Barkatu, baina egoera mezua idatzi behar duzu gorde aurretik.",
			'status:notfound' => "Barkatu, baina ezin izan dugu zehaztutako egoera mezua aurkitu.",
			'status:notdeleted' => "Barkatu, baina ezin izan dugu egoera mezua ezabatu.",
			'status:notsaved' => "Zerbaitek huts egin du gordetzarakoan. Saiatu berriro edo jarri harremanetan administradorearekin.",
			'status:problem' => "Arazo bat egon da. Badirudi ezin duzula egoera hau aldatu.",
	
	);
					
	add_translation("eu",$basque);

?>