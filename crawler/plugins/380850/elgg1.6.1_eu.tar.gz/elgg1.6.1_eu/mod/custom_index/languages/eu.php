<?php

	$basque = array(
	
			'custom:bookmarks' => "Azken loturak",
			'custom:groups' => "Azken taldeak",
			'custom:files' => "Azken fitxategiak",
			'custom:blogs' => "Azken blog mezuak",
			'custom:members' => "Erabiltzaile berrienak",
			'custom:nofiles' => "Ez dago fitxategirik oraindik",
			'custom:nogroups' => "Ez dago talderik oraindik",	
	
	);
					
	add_translation("eu",$basque);

?>
