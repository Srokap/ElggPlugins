<?php
	/**
	 * Elgg reported content plugin language pack
	 * 
	 * @package ElggReportedContent
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$basque = array(
	
		/**
		 * Menu items and titles
		 */
	
			'item:object:reported_content' => 'Salatutako elementuak',
			'reportedcontent' => 'Salatutako edukia',
			'reportedcontent:this' => 'Salaketa egin',
			'reportedcontent:none' => 'Ez dago salatutako edukirik',
			'reportedcontent:report' => 'Berri eman administradoreari',
			'reportedcontent:title' => 'Orrialdearen izenburua',
			'reportedcontent:deleted' => 'Salatutako edukia ezabatu egin da',
			'reportedcontent:notdeleted' => 'Ezin izan dugu hori ezabatu',
			'reportedcontent:delete' => 'Ezabatu',
			'reportedcontent:areyousure' => 'Ziur ezabatu nahi duzula?',
			'reportedcontent:archive' => 'Artxibatu',
			'reportedcontent:archived' => 'Salaketa artxibatu egin da',
			'reportedcontent:visit' => 'Bisitatu salatutako elementua',
			'reportedcontent:by' => 'Nork eman du berri:',
			'reportedcontent:objecttitle' => 'Objektuaren izenburua',
			'reportedcontent:objecturl' => 'Objektuaren URLa',
			'reportedcontent:reason' => 'Salaketa egiteko arrazoia',
			'reportedcontent:description' => 'Zergatik ari zara salaketa hau egiten?',
			'reportedcontent:address' => 'Elementuaren kokapena',
			'reportedcontent:success' => 'Administradoreari honi buruz berri eman zaio',
			'reportedcontent:failing' => 'Ezin izan da salaketa bidali',
			'reportedcontent:report' => 'Salaketa egin',
			'reportedcontent:moreinfo' => 'Informazio gehiago',
	
			'reportedcontent:failed' => 'Barkatu, baina eduki honi buruz berri emateak huts egin du.',
			'reportedcontent:notarchived' => 'Ezin izan da salaketa gorde',
	);
					
	add_translation("eu",$basque);
?>
