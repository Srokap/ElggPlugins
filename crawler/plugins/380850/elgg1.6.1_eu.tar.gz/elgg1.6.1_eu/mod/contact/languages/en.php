<?php

	/**
	 * Elgg contact plugin
	 * This plugin allows to send message to custom email you specify at module configuration area
	 * 
	 * @package ElggContact
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @author Tim Timalsina <info@timalsina.com>
	 * @copyright Curverider Ltd 2008
	 * @copyright TIMALSINA 2008
	 * @link http://elgg.com/
	 */
		
		$english = array(
	
		/**
		 * Plugin button, menu title, page title, default email, settings
		 */
	
			'contact:plugin:name' => "Contact",
			'contact:page:title' => "Contact Us",			
			'contact:button:send' => "Send Message",
			'contact:setting:captcha' => "Enable Captcha? <span style=\"color: red;\">(Do not enable this option unless you have the captcha plugin installed!)</span>",
			'contact:setting:htmlemail' => "Do you want you email sent as HTML or Plaintext?",
			'contact:default:email' => "Default contact email address",
			'contact:setting:toolsmenu' => "Would you like the contact page to appear in the Tools menu?",
			'contact:setting:subjects' => "Please enter your email subjects here. (format: subject 1, subject 2, subject 3)",
			
		/**
		 * Input Form elements
		 */
			
			'contact:level:name' => "Your Name",	
			'contact:level:email' => "Email Address",
			'contact:level:subject' => "Subject",
			'contact:level:message' => "Message",			
			 
		/**
		 * Plugin action feedback
		 */
	
			'contact:send:successful' => "Your message was successfully sent. We will get back with you within next 24 hours. Thank you.",
			'contact:send:unsuccessful' => "Your message could not be sent. Make sure all the fields are filled in.",
			'contact:name:invalid' => "Our system could not accept the name you've entered. A valid name can only have alphabets, numbers and punctuation marks. Please gry again.",
			'contact:email:invalid' => "Our system could not accept the email you've entered. Please try again with valid email address.",			
			'contact:message:invalid' => "Message can't be blank.",
			
	
	);
					
	add_translation("en",$english);

?>