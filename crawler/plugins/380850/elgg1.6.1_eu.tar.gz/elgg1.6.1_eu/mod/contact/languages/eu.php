<?php

	/**
	 * Elgg contact plugin
	 * This plugin allows to send message to custom email you specify at module configuration area
	 * 
	 * @package ElggContact
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @author Tim Timalsina <info@timalsina.com>
	 * @copyright Curverider Ltd 2008
	 * @copyright TIMALSINA 2008
	 * @link http://elgg.com/
	 */
		
		$basque = array(
	
		/**
		 * Plugin button, menu title, page title, default email, settings
		 */
	
			'contact:plugin:name' => "Kontaktua",
			'contact:page:title' => "Kontaktatu gurekin",			
			'contact:button:send' => "Mezua bidali",
			'contact:setting:captcha' => "Captcha gaitu? <span style=\"color: red;\">(Ez gaitu aukera hau ez baduzu captcha plugina 
instalatuta!)</span>",
			'contact:setting:htmlemail' => "Emaila HTML edo testu planoan bidali nahi duzu?",
			'contact:default:email' => "Lehenetsitako kontaktuen posta helbidea",
			'contact:setting:toolsmenu' => "Nahi ahal duzu kontaktu orria tresnen menuan agertzea?",
			'contact:setting:subjects' => "Mesedez, sartu emailaren gaia hemen. (formatua: gaia 1, gaia 2, gaia 3)",
			
		/**
		 * Input Form elements
		 */
			
			'contact:level:name' => "Zure izena",	
			'contact:level:email' => "Posta helbidea",
			'contact:level:subject' => "Gaia",
			'contact:level:message' => "Mezua",			
			 
		/**
		 * Plugin action feedback
		 */
	
			'contact:send:successful' => "Zure mezua arrakastaz bidali da. Ahal dugun bezain laster jarriko gara zurekin kontaktuan. 
Eskerrik asko.",
			'contact:send:unsuccessful' => "Zure mezua ezin izan da bidali. Ziurtatu eremu guztiak bete dituzula.",
			'contact:name:invalid' => "Gure sistemak ezin du onartu sartu duzun izena. Baliozko batek letrak, zenbakiak eta puntuazio 
markak bakarrik izan litzake. Mesedez saiatu berriz.",
			'contact:email:invalid' => "Gure sistemak ezin du onartu sartu duzun emaila. Mesedez saiatu berriz baliozko email 
helbide batekin.",			
			'contact:message:invalid' => "Mezua ezin da hutsik egon.",
			
	
	);
					
	add_translation("eu",$basque);

?>
