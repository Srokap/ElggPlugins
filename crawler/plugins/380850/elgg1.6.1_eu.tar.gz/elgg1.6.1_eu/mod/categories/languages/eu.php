<?php

	$basque = array(
	
		'categories' => 'Atalak',
		'categories:settings' => 'Ezarri guneko atalak',	
		'categories:explanation' => 'Gune osoan erabiliko diren atalak definitzeko, sartu hemen, komaz bananduta. Bateragarriak diren tresnek 
erakutsiko dituzte edukiak sortu edo editatzean.',	
		'categories:save:success' => 'Guneko atalak ondo gorde dira.',
	
	);
					
	add_translation("eu",$basque);

?>
