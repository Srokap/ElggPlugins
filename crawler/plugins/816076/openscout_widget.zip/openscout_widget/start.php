<?php

function openscout_widget_init() {
	add_widget_type('openscout',"OpenScout Search","Search open content repositories in management education and training");
}

register_elgg_event_handler('init', 'system', 'openscout_widget_init');

?>
