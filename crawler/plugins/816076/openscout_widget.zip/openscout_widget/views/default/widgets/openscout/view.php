<p>
<div style="text-align:center">
<iframe frameborder="no" scrolling="no" src="http://role-demo.de/gadgets/ifr?container=default&mid=1&nocache=1&country=ALL&lang=ALL&view=default&parent=http://role-demo.de&url=http://www.role-demo.de/binocsGadget_FESTO/gadget_Openscout.xml" style="width:100%; height: 550px;"> </iframe>
</div>
</p>