<?php

$english = array(
	'groupmemberriver:option:all' => 'All member activities',
	'groupmemberriver:option:justgroup' => 'Member activities within this group',
	'groupmemberriver:option:notgroup' => 'Member activities outside this group',
    'groupmemberriver:widget:title' => 'Member activity',
    'groupmemberriver:widget:description' => 'Group member activity',
	'groupmemberriver:widget:settings:activity_count' => 'How many to show?',
	'groupmemberriver:widget:settings:subset' => 'Which activities to show?',
 );

add_translation('en',$english);
