<?php

require_once(dirname(dirname(dirname(__FILE__))) . '/engine/start.php');

$body = elgg_view('welcomer/viewmessage');
$body = elgg_view_layout('one_column', $body);
page_draw(elgg_echo('Welcomer'),$body);

?>
