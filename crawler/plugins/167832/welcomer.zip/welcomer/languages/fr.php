<?php

// Generate By translationbrowser. 

$french = array( 
	 'welcomer:message:edit'  =>  "Edition du message de prochaine connexion" , 
	 'welcomer:welcome:edit'  =>  "Edition du message de première connexion" , 
	 'welcomer:switcher'  =>  "Page de contrôle" , 
	 'welcomer:validate:message'  =>  "Vérifier votre message" , 
	 'welcomer:validate:select_check'  =>  "Ajouter une boite de validation obligatoire" , 
	 'welcomer:message:editmessage'  =>  "Editer le message de prochaine connexion" , 
	 'welcomer:submit'  =>  "Continuer" , 
	 'welcomer:welcome:editmessage'  =>  "Editer le message de première connexion" , 
	 'welcomer:message:switchmessage'  =>  "Activer / Désactiver les messages de connexion " , 
	 'welcomer:message:on'  =>  "Le message de prochaine connexion est ACTIVE " , 
	 'welcomer:message:desactivate'  =>  "Désactiver" , 
	 'welcomer:message:off'  =>  "Le message de prochaine connexion est DESACTIVE " , 
	 'welcomer:message:activate'  =>  "Activer" , 
	 'welcomer:welcome:on'  =>  "Le message de première connexion est ACTIVE " , 
	 'welcomer:desactivate'  =>  "Désactiver" , 
	 'welcomer:welcome:off'  =>  "Le message de première connexion est DESACTIVE " , 
	 'welcomer:activate'  =>  "Activer" , 
	 'welcomer:message:check_message'  =>  "J'ai lu et je suis d'accord" , 
	 'welcomer:validate:message:ok'  =>  "Le message de prochaine connexion a été activé" , 
	 'welcomer:validate:welcome:ok'  =>  "Le message de première connexion a été activé" , 
	 'welcomer:message:save_ok'  =>  "Le brouillon de message a été sauvegarder. Vous devez l'activer pour le mettre en service" , 
	 'welcomer:welcome:save_ok'  =>  "Le brouillon de message a été sauvegarder. Vous devez l'activer pour le mettre en service" , 
	 'welcomer:message:desactivate_ok'  =>  "La fonction de message de prochaine connexion a été désactivée" , 
	 'welcomer:message:activate_ok'  =>  "La fonction de message de prochaine connexion a été activée" , 
	 'welcomer:welcome:desactivate_ok'  =>  "La fonction de message de première connexion a été désactivée" , 
	 'welcomer:welcome:activate_ok'  =>  "La fonction de message de première connexion a été activée" , 
	 'welcomer:mandatory:message'  =>  "Vous devez obligatoirement valider le message" , 
	 'welcomer:menu:welcome:switch'  =>  "Page de contrôle" , 
	 'welcomer:menu:welcome:edit'  =>  "Première connexion -> Editer" , 
	 'welcomer:menu:welcome:activate'  =>  "Première connexion -> Activer" , 
	 'welcomer:menu:welcome:view'  =>  "Première connexion -> Voir" , 
	 'welcomer:menu:message:edit'  =>  "Prochaine connexion -> Editer" , 
	 'welcomer:menu:message:activate'  =>  "Prochaine connexion -> Activer" , 
	 'welcomer:menu:message:view'  =>  "Prochaine connexion -> Voir" , 
	 'welcomer:modifier'  =>  "modifier" , 
	 'welcomer:valider'  =>  "valider" , 
	 'welcomer:admin:menu'  =>  "Gestion du welcomer",
	 'welcomer:message:about' => "Vous pouvez activer / désactiver les messages du welcomer
	 <ul><li>Le message de prochaine connexion s'affichera lors de la prochaine connexion des membres</li><li>Le message de première connexion s'affichera lors de la première connexion d'un membre</li></ul>"
); 

add_translation('fr', $french); 

?>