<?php
/**
	 * Elgg add_to_any plugin
	 * 
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette fabrice.collette@free.fr
	 * @copyright Fabrice Collette
	 * @link http://www.meleze-online.net
	 */

?>

#welcomer_main_content {
  margin:0 15px 20px 15px;
	padding:10px 30px 0 30px;
	min-height:150px;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	background: white;
}
#welcomer_main_content ul li {
  list-style-type:disc;
	padding-bottom:2px;
}
#welcomer_title {
	font-weight:bold;
	font-size:1.1em;
	padding-bottom:10px;
}
#welcomer_validate{
  margin:30px 0 0 0;
  padding:5px 30px 0 30px;
  border-top:1px solid #000000;
}

