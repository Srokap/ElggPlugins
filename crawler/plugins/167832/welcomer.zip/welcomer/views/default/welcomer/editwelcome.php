<?php
/**
	 * Elgg welcomer plugin
	 * Main view
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette fabrice.collette@free.fr
	 * @copyright Fabrice Collette
	 * @link http://www.meleze-online.net
	 */
global $CONFIG;
$site = $CONFIG->site;
$id = $site->guid;
$action = $action = $vars['url']."mod/welcomer/actions/editwelcome.php";

$name = "welcomer_welcome_draft_".$id;
$message = get_metadata_byname($id, $name)->value;


?>
<div class="contentWrapper">
<?php
$form_body = "<h3>".elgg_echo('welcomer:welcome:editmessage')."</h3>";
$form_body .= elgg_view('input/longtext', array('internalname' => 'message', 'value' => $message));
$form_body .= elgg_view('input/submit', array('value' => elgg_echo('welcomer:submit')));
	
echo elgg_view('input/form', array('body' => $form_body, 'action' => $action));
?>
</div>

