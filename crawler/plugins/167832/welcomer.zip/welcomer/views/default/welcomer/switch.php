<?php
/**
	 * Elgg welcomer plugin
	 * Main view
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette fabrice.collette@free.fr
	 * @copyright Fabrice Collette
	 * @link http://www.meleze-online.net
	 */
global $CONFIG;
$site = $CONFIG->site;
$id = $site->guid;
$action = $action = $vars['url']."mod/welcomer/actions/switch.php";
$name_message = "welcomer_switcher_message_".$id;
$name_welcome = "welcomer_switcher_".$id;
$message = get_metadata_byname($id, $name_message)->value;
$welcome = get_metadata_byname($id, $name_welcome)->value;


?>
<div class="contentWrapper">
<?php
$form_body .= elgg_echo('welcomer:message:about')."<br><br>";
$form_body .= "<h4>".elgg_echo('welcomer:message:switchmessage')."</h4>";
if ($message == true) {
  $form_body .= elgg_echo('welcomer:message:on');
  $form_body .= " : ".elgg_view('input/submit', array('internalname' => 'message_status','value' => elgg_echo('welcomer:message:desactivate')));
  } else {
  $form_body .= elgg_echo('welcomer:message:off');
  $form_body .= " : ".elgg_view('input/submit', array('internalname' => 'message_status','value' => elgg_echo('welcomer:message:activate')));
  }
if ($welcome == true) {
  $form_body .= "<br>".elgg_echo('welcomer:welcome:on');
  $form_body .= " : ".elgg_view('input/submit', array('internalname' => 'welcome_status','value' => elgg_echo('welcomer:desactivate')));
  } else {
  $form_body .= "<br>".elgg_echo('welcomer:welcome:off');
  $form_body .= " : ".elgg_view('input/submit', array('internalname' => 'welcome_status','value' => elgg_echo('welcomer:activate')));
  }
	
echo elgg_view('input/form', array('body' => $form_body, 'action' => $action));
?>
</div>

