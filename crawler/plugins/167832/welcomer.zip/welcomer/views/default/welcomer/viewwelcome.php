<?php
/**
	 * Elgg welcomer plugin
	 * Main view
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette fabrice.collette@free.fr
	 * @copyright Fabrice Collette
	 * @link http://www.meleze-online.net
	 */
global $CONFIG;
$site = $CONFIG->site;
$id = $site->guid;
$action = $vars['url']."mod/welcomer/actions/welcomerforward.php";
$name = "welcomer_welcome_".$id;
$message = get_metadata_byname($id, $name)->value;


?>
<div id="topmargin" style="min-height:15px;"></div>
<div id="welcomer_main_content">
<?php
$form_body = $message;
$form_body .= elgg_view('input/submit', array('value' => elgg_echo('welcomer:submit')));
	
echo elgg_view('input/form', array('body' => $form_body, 'action' => $action));
?>
</div>

