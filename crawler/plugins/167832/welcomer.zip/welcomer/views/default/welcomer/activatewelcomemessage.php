<?php
/**
	 * Elgg welcomer plugin
	 * Main view
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette fabrice.collette@free.fr
	 * @copyright Fabrice Collette
	 * @link http://www.meleze-online.net
	 */
global $CONFIG;
$site = $CONFIG->site;
$id = $site->guid;
$name = "welcomer_welcome_draft_".$id;
$message =get_metadata_byname($id, $name)->value;
$action = $vars['url']."mod/welcomer/actions/activatewelcomemessage.php";


?>
<div id="topmargin" style="min-height:15px;"></div>
<div id="welcomer_main_content">

<?php
 $form_body = $message."</div>";
 $form_body .= "<div id=\"welcomer_validate\"><div style=\"padding-bottom:10px;\">".elgg_echo('welcomer:validate:message')."</div>";
 $form_body .= "<input name=\"check\" type=\"checkbox\">".elgg_echo('welcomer:validate:select_check')."<br>";
 $form_body .=  "<input name=\"validation\" value=\"".elgg_echo('welcomer:valider')."\" type=\"submit\"> <input name=\"validation\" value=\"".elgg_echo('welcomer:modifier')."\" type=\"submit\"><br>";
 
 echo elgg_view('input/form', array('body' => $form_body, 'action' => $action));
?>
</div>
