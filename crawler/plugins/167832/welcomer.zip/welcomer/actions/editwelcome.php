<?php
/**
	 * Elgg welcomer plugin
	 * Main view
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette fabrice.collette@free.fr
	 * @copyright Fabrice Collette
	 * @link http://www.meleze-online.net
	 */

require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/engine/start.php');
global $CONFIG;
$message = get_input('message');
$user = $_SESSION['user'];
$site = $CONFIG->site;
$id = $site->guid;

$name = "welcomer_welcome_draft_".$id;
create_metadata($id, $name, $message, '', 0, 1, false);

system_message(elgg_echo('welcomer:welcome:save_ok'));

forward ("mod/welcomer/editwelcome.php");

  

?>
