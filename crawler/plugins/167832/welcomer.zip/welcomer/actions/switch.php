<?php
/**
	 * Elgg welcomer plugin
	 * Main view
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette fabrice.collette@free.fr
	 * @copyright Fabrice Collette
	 * @link http://www.meleze-online.net
	 */

require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/engine/start.php');
global $CONFIG;
$message = get_input('message_status');
$welcome = get_input('welcome_status');
$site = $CONFIG->site;
$id = $site->guid;


$name_message = "welcomer_switcher_message_".$id;
$name_welcome = "welcomer_switcher_".$id;

if (!empty($message)) {
    if ($message == elgg_echo('welcomer:message:desactivate')) {
      create_metadata($id, $name_message, false, '', 0, 1, false);
      system_message(elgg_echo('welcomer:message:desactivate_ok'));
    } else {
      create_metadata($id, $name_message, true, '', 0, 1, false);
      system_message(elgg_echo('welcomer:message:activate_ok'));
    }
  }

if (!empty($welcome)) {
    if ($welcome == elgg_echo('welcomer:desactivate')) {
      create_metadata($id, $name_welcome, false, '', 0, 1, false);
      system_message(elgg_echo('welcomer:welcome:desactivate_ok'));
    } else {
      create_metadata($id, $name_welcome, true, '', 0, 1, false);
      system_message(elgg_echo('welcomer:welcome:activate_ok'));
    }
  }  

  forward ("mod/welcomer/switchwelcomer.php"); 

?>
