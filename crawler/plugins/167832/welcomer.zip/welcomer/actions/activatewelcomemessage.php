<?php
/**
	 * Elgg welcomer plugin
	 * action validate message
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette fabrice.collette@free.fr
	 * @copyright Fabrice Collette
	 * @link http://www.meleze-online.net
	 */

require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/engine/start.php');
global $CONFIG;
$id = $CONFIG->site_guid;
$multisite = is_plugin_enabled('multisite', $id);

function reset_message_metadata() {
global $id;
$limit = 50;
$offset = 0;
$j=0;
$count = get_entities('user', '', 0, '', $limit, $offset, true, 0, null);
while ($offset<$count){
    $users = get_entities('user', '', 0, '', $limit, $offset, false, 0, null);
    $metaname = "welcome_message_tag_".$id;
    $metavalue = false;
    foreach($users as $u){
      create_metadata($u->guid, $metaname, $metavalue, '', 0, 1, false);
	   }  
	   $offset = $offset + $limit;
  } 

}

function reset_message_metadata_multisite() {
global $id;
$limit = 50;
$offset = 0;
$j=0;
$count = get_entities_from_relationship("member_of_site", $id, true, "user", "", 0, "", $limit, $offset, true, -1);
system_message("nombre = ".$count);

while ($offset<$count){
    $users = get_entities_from_relationship("member_of_site", $id, true, "user", "", 0, "", $limit, $offset, false, -1);
    $metaname = "welcome_message_tag_".$id;
    $metavalue = false;
    foreach($users as $u){
      create_metadata($u->guid, $metaname, $metavalue, '', 0, 1, false);
	   }  
	   $offset = $offset + $limit;
  } 
}

$valid = get_input('validation');
$check = get_input('check');
$user = $_SESSION['user'];
$site = $CONFIG->site;
$name_draft = "welcomer_welcome_draft_".$id;
$name = "welcomer_welcome_".$id;
$message = get_metadata_byname($id, $name_draft)->value;




if ($valid == elgg_echo('welcomer:modifier')){
    forward ("mod/welcomer/editwelcome.php");
  }
if ($check == 'on') { 
    $message .= "<div style=\"padding-top:25px;\"><input name=\"confirm\" type=\"checkbox\">".elgg_echo('welcomer:message:check_message')."</div>";
    } else {
    $message .= "<div style=\"padding-top:25px;\"><input name=\"confirm\" type=\"hidden\" value=\"on\"></div>";
    }
    
if ($valid == elgg_echo('welcomer:valider')){
    create_metadata($id, $name, $message, '', 0, 1, false);
    
    system_message(elgg_echo('welcomer:validate:welcome:ok'));
    forward ("mod/welcomer/switchwelcomer.php");
  }
  

?>
