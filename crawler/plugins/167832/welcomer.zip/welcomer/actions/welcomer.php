<?php
/**
	 * Elgg welcomer plugin
	 * Main view
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette fabrice.collette@free.fr
	 * @copyright Fabrice Collette
	 * @link http://www.meleze-online.net
	 */

require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/engine/start.php');
global $CONFIG;
$id = $CONFIG->site_guid;

$valid = get_input('confirm');
$userid = $_SESSION['user']->guid;
$name = "welcome_tag_".$id;
$message = true;

if ($valid == 'on') {
          create_metadata($userid, $name, $message, '', 0, 1, false);
          forward ();
  } else {
    system_message(elgg_echo('welcomer:mandatory:message'));
    $body = elgg_view('welcomer/welcomer');
    $body = elgg_view_layout('one_column', $body);
    page_draw(elgg_echo('Welcomer'),$body);
  }
  

?>
