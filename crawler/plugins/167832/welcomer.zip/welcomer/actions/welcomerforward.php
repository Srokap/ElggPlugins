<?php
/**
	 * Elgg welcomer plugin
	 * Main view
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette fabrice.collette@free.fr
	 * @copyright Fabrice Collette
	 * @link http://www.meleze-online.net
	 */

require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/engine/start.php');
global $CONFIG;


  forward ("mod/welcomer/switchwelcomer.php"); 

?>
