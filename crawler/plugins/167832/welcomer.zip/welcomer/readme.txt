Welcomer 1.0

Features :
- add a page that members will get at their first connexion to the site, immediatly after the login process
- add a page that members will get at their next connexion to the site, immediatly after the login process
- activate / desactivate first connexion and/or next connexion message
- Edit welcome messages with tinyMCE (need to be activated in your site)
- Preview
- Optionnaly add a mandatory check button
- full compatible with multisite environnement (need multisite plugin)

Intallation :
- Download
- unzipp in your mod folder
- activate the plugin
- enable / disable simplecache in your admin site page
- run upgrade.php

 
