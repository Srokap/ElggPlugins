<?php

	/**
	 * Elgg welcomer plugin
	 * 
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette fabrice.collette@free.fr
	 * @copyright Fabrice Collette
	 * @link http://www.meleze-online.net
	 */

		
		function welcomer_init() {
		  //add custom css if needed
			extend_view('css','welcomer/css');
			global $CONFIG;
			// Load the language file
			register_translations($CONFIG->pluginspath . "welcomer/languages/");
			//Add the welcome tag
			register_elgg_event_handler('user', 'user', 'user_create_welcome',902);
			//make sure that the welcome page will be the last one in the login process
			register_elgg_event_handler('login', 'user', 'userlogin_welcome',900);
			register_elgg_event_handler('login', 'user', 'userlogin_message',901);
			// Register some actions
		  register_action("welcomer/welcomer",false, $CONFIG->pluginspath . "welcomer/actions/welcomer.php");
		}
		
		// handler for page setup, registered to add menu items for page menu
  function welcomer_pagesetup(){
	global $CONFIG;
	if (get_context() == 'admin' && isadminloggedin()) {
				add_submenu_item(elgg_echo('welcomer:admin:menu'), $CONFIG->wwwroot . "mod/welcomer/switchwelcomer.php");
				}
			//add submenu to local admin of multisite
      if (get_context() == 'localmultisite'){
				add_submenu_item(elgg_echo('welcomer:admin:menu'), $CONFIG->wwwroot . "mod/welcomer/switchwelcomer.php");
				}			
			if (get_context() == 'welcomer') {
			  add_submenu_item(elgg_echo('welcomer:menu:welcome:switch'), $CONFIG->wwwroot . "mod/welcomer/switchwelcomer.php");
			  add_submenu_item(elgg_echo('welcomer:menu:welcome:edit'), $CONFIG->wwwroot . "mod/welcomer/editwelcome.php");
			  add_submenu_item(elgg_echo('welcomer:menu:welcome:activate'), $CONFIG->wwwroot . "mod/welcomer/activatewelcomemessage.php");
			  add_submenu_item(elgg_echo('welcomer:menu:welcome:view'), $CONFIG->wwwroot . "mod/welcomer/viewwelcome.php");
				add_submenu_item(elgg_echo('welcomer:menu:message:edit'), $CONFIG->wwwroot . "mod/welcomer/editmessage.php");
				add_submenu_item(elgg_echo('welcomer:menu:message:activate'), $CONFIG->wwwroot . "mod/welcomer/activatemessage.php");
				add_submenu_item(elgg_echo('welcomer:menu:message:view'), $CONFIG->wwwroot . "mod/welcomer/viewmessage.php");
				}
}

   /**
	 * Init the welcome and message tag and set to false
	 */
	function user_create_welcome($event, $object_type, $object)
	{
	  global $CONFIG;
	  $id = $CONFIG->site_guid;
	  $name_welcome = "welcome_tag_".$id;
	  $name_message = "welcome_message_tag_".$id;
	  $value = false;
	  
		if (($object) && ($object instanceof ElggUser))
		{
			create_metadata($object->guid, $name_welcome, $value, '', 0, 1, false);
			create_metadata($object->guid, $name_message, $value, '', 0, 1, false);
			return true;
		}
		return true;
	}

   /**
	 * Send to a welcome page at the first time login
	 */
  function userlogin_welcome($event, $object_type, $object)
	{
	  global $CONFIG;
	  $id = $CONFIG->site_guid;
	  $name_welcome = "welcome_tag_".$id;
	  $welcome_switcher = "welcomer_switcher_".$id;
	  if (get_metadata_byname($id, $welcome_switcher)->value == true) 
    {
	  
    		if (($object) && ($object instanceof ElggUser))
    		{
    			if (get_metadata_byname($object->guid, $name_welcome)->value == true) {
    			     return true;
    		    } else { forward ($CONFIG->wwwroot . "mod/welcomer/welcomer.php"); }
    		}
    }
		return true;
	}
	
	/**
	 * Send to a message page at the next time login and do it once
	 */
	function userlogin_message($event, $object_type, $object)
	{
	  global $CONFIG;
	  $id = $CONFIG->site_guid;
	  $name_message = "welcome_message_tag_".$id;
	  $welcome_switcher = "welcomer_switcher_message_".$id;
	  if (get_metadata_byname($id, $welcome_switcher)->value == true) 
    {
    		if (($object) && ($object instanceof ElggUser))
    		{
    			if (get_metadata_byname($object->guid, $name_message)->value == true) {
    			     return true;
    		    } else { forward ($CONFIG->wwwroot . "mod/welcomer/welcomemessage.php"); }
    		}
    }
		return true;
	}
	

		register_elgg_event_handler('init','system','welcomer_init');
		// register plugin event handler for page setup
    register_elgg_event_handler('pagesetup', 'system', 'welcomer_pagesetup');
				
		
?>