<?php
/**
    start.php, part of Friend_invitation
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
*/

// unique function for plugin initialization

function friend_invitation_init(){

    global $CONFIG;
    // registering languages translation constants
    register_translations($CONFIG->pluginspath . "friend_invitation/languages/");
    // register handler for invitation setup page
    register_page_handler('friend_invitation_setup', 'friend_invitation_setup_handler');
    // registering action for saving customized information
    register_action('friend_invitation/save', false, $CONFIG->pluginspath . 'friend_invitation/actions/save.php');
    // register plugin widget
    add_widget_type('friend_invitation', elgg_echo('friend_invitation:widget:title'), elgg_echo('friend_invitation:widget:description'));
    // registering css styles
    extend_view('css','friend_invitation/css');

}


function friend_invitation_pagesetup(){
	// if requested admin area by logged admin
	if ( get_context() == 'admin' && isadminloggedin() ){
		global $CONFIG;
		add_submenu_item( elgg_echo('friend_invitation:setup'), $CONFIG->wwwroot . 'pg/friend_invitation_setup/');
	}
}

// handler for setup page
function friend_invitation_setup_handler($page){
	global $CONFIG;
	include($CONFIG->pluginspath . 'friend_invitation/index.php');
}

// register plugin event handler for plugin initialization
register_elgg_event_handler('init', 'system', 'friend_invitation_init');

// register plugin page setup handler
register_elgg_event_handler('pagesetup', 'system', 'friend_invitation_pagesetup');

?>
