<?php
/**
    nl.php, part of Friend_invitation
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
*/

$language_array_nl = array(
    'friend_invitation' => 'Kennisen uitnodigen',
    'friend_invitation:setup' => 'Bericht aan uw kennis(sen)',
    'friend_invitation:description' => 'Kennisen uitnodigen',
    'friend_invitation:widget' => 'Zoek kennissen widget',
    'friend_invitation:widget:send' => 'Verstuur uitnodiging',
    'friend_invitation:widget:description' => 'Met deze widget kunt u kennissen uitnodige lid te worden van Hepicon',
    'friend_invitation:widget:title' => 'Kennissen uitnodigen',
    'friend_invitation:widget:no_results' => 'Geen leden gevonden',
    'friend_invitation:setup:default_subject' => 'Default subject',
    'friend_invitation:setup:default_message' => 'Default message',
    'friend_invitation:setup:save' => 'Save settings',
    'friend_invitation:process:sended' => '"%s" is uitgenodigd <br/>',
    'friend_invitation:process:failed' => 'Uitnodiging aan "%s" kon niet verzonden worden<br/>',
    'friend_invitation:process:exists' => '"%s" is al lid<br/>',
    'friend_invitation:process:not_email' => '"%s" is geen geldig email adres<br/>',
    'friend_invitation:process:receivers_empty' => 'Ontvangers regels is leeg<br/>',
    'friend_invitation:default_message' => '%MEMBER% nodigt u uit deel te nemen aan HEPICON - Health Professionals in Contact',
    'friend_invitation:default_subject' => '%MEMBER% nodigt u uit'

);

// register constants for dutch version of elgg site
add_translation('nl', $language_array_nl);

?>