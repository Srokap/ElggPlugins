<?php
/**
    en.php, part of Friend_invitation
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
*/

$language_array_en = array(
    'friend_invitation' => 'Friend invitation',
    'friend_invitation:setup' => 'Friend invitation message',
    'friend_invitation:description' => 'Friend invite',
    'friend_invitation:widget' => 'Search members widget',
    'friend_invitation:widget:send' => 'Send Invitation',
    'friend_invitation:widget:description' => 'This widget allows invite friend into SN',
    'friend_invitation:widget:title' => 'Friend invitation',
    'friend_invitation:widget:no_results' => 'No members found',
    'friend_invitation:setup:default_subject' => 'Default subject',
    'friend_invitation:setup:default_message' => 'Default message',
    'friend_invitation:setup:save' => 'Save settings',
    'friend_invitation:process:sended' => 'Invitation for "%s" sended <br/>',
    'friend_invitation:process:failed' => 'Failed sending invitation to "%s" <br/>',
    'friend_invitation:process:exists' => '"%s" is already member<br/>',
    'friend_invitation:process:not_email' => '"%s" is not valid email<br/>',
    'friend_invitation:process:receivers_empty' => 'Receivers list empty<br/>',
    'friend_invitation:default_message' => '%MEMBER% inviting you to participate new social network',
    'friend_invitation:default_subject' => '%MEMBER% inviting you'

);

// register constants for english version of elgg site
add_translation('en', $language_array_en);

?>