<?php
/**
    setup.php, part of Friend_invitation
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
*/

	$subject = get_plugin_setting('friend_invitation_default_subject', "friend_invitation");
	$message = get_plugin_setting('friend_invitation_default_message', "friend_invitation");

	if ( ! $subject )
	    $subject = elgg_echo('friend_invitation:default_subject');

	if ( ! $message )
	    $message = elgg_echo('friend_invitation:default_message');

    $form_body = elgg_echo('friend_invitation:setup:default_subject');
	$form_body .= elgg_view('input/text', array('internalname' => 'subject', 'value' => $subject));
	$form_body .= elgg_echo('friend_invitation:setup:default_message');
	$form_body .= elgg_view('input/longtext', array('internalname' => 'message', 'value' => $message));
	$form_body .= elgg_view('input/submit', array('value' => elgg_echo('friend_invitation:setup:save')));
	
	echo elgg_view('input/form', array('body' => $form_body, 'action' => $CONFIG->url . "actions/friend_invitation/save"));

?>