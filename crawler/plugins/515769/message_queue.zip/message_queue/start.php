<?php
// Load model
require_once(dirname(__FILE__) . "/models/model.php");

register_plugin_hook('cron', 'fiveminute', 'message_queue_send_emails');
?>