<?php
function message_queue_create_message($subject,$body) {
	$message = new ElggObject();
	$message->subtype = "message_queue_message";
	$message->access_id = ACCESS_PUBLIC;
	$message->title = $subject;
	$message->description = $body;
	$message->status = 'unsent';
	if ($message->save()) {
		return $message;
	} else {
		return false;
	}
}

function message_queue_add($message_id,$user_id) {
	add_entity_relationship($user_id, 'message_queue', $message_id);
}

function message_queue_send_emails() {
	
	// This could take a while, so ask for more time
	// current request is 4 minutes
	
	set_time_limit(240);
	
	// get the site email address
 	
 	$max_emails = 200; // pessimistic quota per cron run - could be increased
 	$emails_sent = 0;
 	
 	// start with current jobs (left over from previous cron run)
 	
 	$emails_sent = message_queue_send_message_type('sending',$emails_sent,$max_emails);
 	
 	$message_limit = $max_emails-$emails_sent;
 	
 	// if still within quota, start new jobs
 	if ($message_limit > 0) { 	
		message_queue_send_message_type('unsent',$emails_sent,$max_emails);
 	}
}

function message_queue_send_message_type($type,$emails_sent,$max_emails) {
	global $CONFIG;
	
	$site = get_entity($CONFIG->site_guid);
	$messages = get_entities_from_metadata('status',$type,'object','message_queue_message');
 	if ($messages) {
 		foreach ($messages as $message) {
 			// lock the message to avoid the small chance that another cron job might
 			// try sending it
 			$message_limit = $max_emails-$emails_sent;
 			if ($message_limit <= 0) {
 				break;
 			}
 			$message->status = "locked";
 			$users = get_entities_from_relationship('message_queue', $message->getGUID(), true, 'user', '', 0, "", $message_limit);
 			if ($users) {
 				$subject = $message->title;
 				$body = $message->description;
 				$message_id = $message->getGUID();
 				foreach ($users as $to) {
 					email_notify_handler($site, $to, $subject, $body);
 					remove_entity_relationship($to->getGUID(), 'message_queue', $message_id);
 				}
 				$user_count = count($users);
 				$emails_sent += $user_count;
 				if ($user_count < $message_limit) {
 					$message->status = "sending";
 				} else {
 					$message->status = "sent";
 				}
 			} else {
 				$message->status = "sent";
 			}
 		}
 	}
 	
 	return $emails_sent;
}
?>