= Credits =

Thanks to Dhrup for kind advice, as always.
Dhrup Chand (embrache) - http://embrache.com/
2012.03.01

Ismayil Khayredinov - http://hypejunction.com/
showed the method to add real-time (ajaxed) updates
to the river through his hype plugins, thank you.
2012.08.19