<?php
/**
 * Latest Members module
 *
 */

elgg_push_context('widgets');

$title = elgg_view('output/url', array(
	'href' => "/members",
	'text' => elgg_echo('river_addon:latest:members'),
	'is_trusted' => true,
));

$options = array(
	'type' => 'user', 
	'full_view' => false,
	'pagination' => FALSE,
	'limit' => 21,
	'list_type' => 'gallery'
);
$content = elgg_get_entities($options);

if ($content) {
	$items = '';
	foreach ($content as $user) {
		$items .= elgg_view_entity_icon($user, 'tiny');
	}
}

elgg_pop_context();

echo elgg_view_module('featured', $title, $items);
