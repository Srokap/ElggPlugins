<?php
/**
 * Friends
 *
 */

elgg_set_context('friends');

$owner = elgg_get_page_owner_entity();
$friends = elgg_get_logged_in_user_entity()->getFriends('', 0);

$title = elgg_view('output/url', array(
	'href' => "/friends/$owner->username",
	'text' => elgg_echo('friends'),
	'is_trusted' => true,
));    
	
$num = (int) elgg_get_plugin_setting('num_friends', 'river_addon');

$options = array(
	'type' => 'user',
	"limit" => $num,
	'relationship' => 'friend',
	'relationship_guid' => elgg_get_logged_in_user_guid(),
	'inverse_relationship' => false,
	'full_view' => false,
	'pagination' => false,
	'list_type' => 'gallery',
	'order_by' => 'rand()' 
);
$content = elgg_get_entities_from_relationship($options);

if ($content) {
	$items = '';
	foreach ($content as $friend) {
		$count = count($content);
		$items .= elgg_view_entity_icon($friend, 'tiny');
	}
}

elgg_pop_context();

$title .= '<span> (' . $count . ')</span>';
echo elgg_view_module('featured', $title, $items);
