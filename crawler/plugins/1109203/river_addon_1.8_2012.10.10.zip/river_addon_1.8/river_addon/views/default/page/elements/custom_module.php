<?php 
/**
 * Demo 
 *
 */

$title = elgg_echo("river_addon:demo:title"); 
$text = elgg_echo("river_addon:demo:text");

echo elgg_view_module('aside', $title, $text);

?>

