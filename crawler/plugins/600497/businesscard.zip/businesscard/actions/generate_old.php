<?php 
	global $CONFIG;
	gatekeeper();

	$name = get_input('name');
	$institution = get_input('institution');
	$adress = get_input('address');
	$postalcode = get_input('postalcode');
	$city = get_input('city');
	$country = get_input('country');
	$phone = get_input('phone');
	$email = get_input('email');
	$website = get_input('website');
	$type = get_input('card_type');
	
	require_once($CONFIG->pluginspath . 'businesscard/vendors/fpdf/fpdf.php');
	
	// Create QR-code image
	$imagepath = "http://chart.apis.google.com/chart?cht=qr&chs=600x480&chl='" . $website . "'";
	$image = imagecreatefrompng($imagepath);
	
	// Save the QR code image
	$image_file = new ElggFile();
	$image_file->owner_guid = get_loggedin_userid();
	$image_file->setFilename("businesscard.png");
	$image_location = $image_file->getFilenameOnFilestore();
	imagepng($image, $image_location);
	

if ($type == 'code') {
// Create PDF
	$pdf = new FPDF();
	$pdf->AddPage();
	$pdf->SetFont('Arial', 'B', 10);
	$pdf->Image($image_location, 1, 16, 66);
	$pdf->Cell(200);
//	$pdf->Cell(100, 5, $name, 0, 1);
	$pdf->Cell(35);
//	$pdf->Cell(100, 5, $institution, 0, 1);
	$pdf->Cell(35);
//	$pdf->Cell(100, 5, $address, 0, 1);
	$pdf->Cell(35);
//	$pdf->Cell(100, 5, $postalcode, 0, 1);
	$pdf->Cell(35);
//	$pdf->Cell(100, 5, $city . ', ' . $country, 0, 1);
	$pdf->Cell(35);
//	$pdf->Cell(100, 5, elgg_echo("phone") . ": " . $phone, 0, 1);
	$pdf->Cell(35);
//	$pdf->Cell(150, 5, elgg_echo("email") . ": " . $email, 0, 1);
	$pdf->Cell(35);
//	$pdf->Cell(100, 5, elgg_echo("website") . ": " . $website, 0, 1);
//	$pdf->Cell(35);
	$pdf->Output('businesscard.pdf','D');
}

if ($type == 'both') {
	// Create PDF
	$pdf = new FPDF();
	$pdf->AddPage();
	$pdf->SetFont('Arial', 'B', 10);
	$pdf->Image($image_location, 1, 16, 66);
	$pdf->Cell(200);
	$pdf->Cell(100, 5, $name, 0, 1);
	$pdf->Cell(35);
	$pdf->Cell(100, 5, $institution, 0, 1);
	$pdf->Cell(35);
	$pdf->Cell(100, 5, $address, 0, 1);
	$pdf->Cell(35);
	$pdf->Cell(100, 5, $postalcode, 0, 1);
	$pdf->Cell(35);

if(isset($city) and isset($country)){
	$pdf->Cell(100, 5, $city . ', ' . $country, 0, 1);
	}
//elseif((isset($city) and !isset($country))){ 	
//	$pdf->Cell(100, 5, $city);
//}
	$pdf->Cell(35);
	$pdf->Cell(100, 5, elgg_echo("phone") . ": " . $phone, 0, 1);
	$pdf->Cell(35);
	$pdf->Cell(150, 5, elgg_echo("email") . ": " . $email, 0, 1);
	$pdf->Cell(35);
	$pdf->Cell(100, 5, elgg_echo("website") . ": " . $website, 0, 1);
	$pdf->Cell(35);
	$pdf->Output('businesscard.pdf','D');
}

if ($type == 'text') {
	// Create PDF
	header('Pragma: public');	
	$pdf = new FPDF();
	$pdf->AddPage();
	$pdf->SetFont('Arial', 'B', 10);
//	$pdf->Image($image_location, 1, 16, 66);
	$pdf->Cell(200);
	$pdf->Cell(100, 5, $name, 0, 1);
	$pdf->Cell(35);
	$pdf->Cell(100, 5, $institution, 0, 1);
	$pdf->Cell(35);
	$pdf->Cell(100, 5, $address, 0, 1);
	$pdf->Cell(35);
	$pdf->Cell(100, 5, $postalcode, 0, 1);
	$pdf->Cell(35);
	$pdf->Cell(100, 5, $city . ', ' . $country, 0, 1);
	$pdf->Cell(35);
	$pdf->Cell(100, 5, elgg_echo("phone") . ": " . $phone, 0, 1);
	$pdf->Cell(35);
	$pdf->Cell(150, 5, elgg_echo("email") . ": " . $email, 0, 1);
	$pdf->Cell(35);
	$pdf->Cell(100, 5, elgg_echo("website") . ": " . $website, 0, 1);
	$pdf->Cell(35);
	$pdf->Output('businesscard.pdf','D');
}

$image_file->delete();
	
?>