<?php 
	global $CONFIG;
	gatekeeper();

	$name = get_input('name');
	$institution = get_input('institution');
	$department = get_input('department');
	$lab = get_input('lab');
	$room = get_input('room');
	$phone = get_input('phone');
	$sein = get_input('sein');
	$skype_username = get_input('skype_username');
	$email = get_input('email');
	$website = get_input('website');

	
	// Save the vCard
	$vCard = new ElggFile();
	$vCard->owner_guid = get_loggedin_userid(); 
	$vCard->access_id = "1";
	$vCard->setFilename("vcard.vcf");
	$vCard->setMimeType("text/x-vcard");
	$vCard_location = $vCard->getFilenameOnFilestore();
	$vCard->open("write");

$vCard->write(
"BEGIN:VCARD
VERSION:2.1
");
if(!empty($name))
{
$vCard->write("N:$name"."\n");
$vCard->write("FN:$name"."\n");
}

if(!empty($institution))
{
$vCard->write("ORG:$institution;$department"."\n");
}
if(!empty($lab))
{
$vCard->write("ADR;WORK:;$lab"."\n");
$vCard->write("LABEL;WORK:$lab"."\n");
}

$vCard->write("ADR;POSTAL:;Room $room;Meibergdreef 9;Amsterdam;;1105 AZ;The Netherlands"."\n");
$vCard->write("LABEL;POSTAL;ENCODING=QUOTED-PRINTABLE:Meibergdreef 9=0D=0AAmsterdam 1105 AZ=0D=0AThe Netherlands"."\n");

if(!empty($phone))
{
$vCard->write("TEL;WORK;VOICE:$phone"."\n");
}

if(!empty($sein))
{
$vCard->write("TEL;PAGER;VOICE:$sein"."\n");
}

if(!empty($email))
{
$vCard->write("EMAIL;PREF;INTERNET:$email"."\n");
}
if(!empty($skype_username))
{
$vCard->write("X-SKYPE-USERNAME:$skype_username"."\n");
}
if(!empty($website))
{
$vCard->write("URL;HOME:$website"."\n");
}
$vCard->write(
"END:VCARD"."\n");
$vCard->close();

$myLink = $CONFIG->wwwroot."pg/businesscard/".$vCard->owner_guid;

// Create QR-code image
$imagepath = "http://chart.apis.google.com/chart?cht=qr&chs=600x480&chl=$myLink";
$image = imagecreatefrompng($imagepath);

// Save the QR code image
$image_file = new ElggFile();
$image_file->owner_guid = get_loggedin_userid();
$image_file->setFilename("vcard.png");
$image_location = $image_file->getFilenameOnFilestore();
imagepng($image, $image_location);
$image_file->close();

//Send the location of the ElggFile so the image can downloaded
$file = "$image_location";
$contents = $image_file->grabFile();

//download dan de png die er als gevolg uitkomt
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename='.basename($file));
    header('Content-Transfer-Encoding: binary');
    header('Expires: 0');
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Pragma: public');
    header('Content-Length: ' . filesize($file));
    echo $contents;
    exit;
?>