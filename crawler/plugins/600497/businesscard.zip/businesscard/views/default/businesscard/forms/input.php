<?php

	$user = get_loggedin_user();
	
	$form_body = "<div class='businesscard_form_label'>" . elgg_echo("businesscard:form:name") . "</div>";
	$form_body .= elgg_view('input/text', array('internalname' => 'name', 'value' => $user->name));

	$form_body .= "<div class='businesscard_form_label'>" . elgg_echo("businesscard:form:institution") . "</div>";
	$form_body .= elgg_view('input/radio', array('alignment' => 'horizontal',
												'internalname' => 'institution', 
												'options' => array(
													elgg_echo("businesscard:form:institution:AMC") => 'AMC',
													//elgg_echo("businesscard:form:institution:Sanquin") => 'Sanquin',
													//elgg_echo("businesscard:form:institution:NKI") => 'NKI'
												),
												'value' => $vars['options']->institution));

	//$form_body .= "<div class='businesscard_form_label'>" . elgg_echo("businesscard:form:address") . "</div>";
	//$form_body .= elgg_view('input/text', array('internalname' => 'address', 'value' => $user->address));

	$form_body .= "<div class='businesscard_form_label'>" . elgg_echo("businesscard:form:department") . "</div>";
	$form_body .= elgg_view('input/text', array('internalname' => 'department', 'value' => $user->department));
	
	$form_body .= "<div class='businesscard_form_label'>" . elgg_echo("businesscard:form:lab") . "</div>";
	$form_body .= elgg_view('input/text', array('internalname' => 'lab', 'value' => $user->lab));

	$form_body .= "<div class='businesscard_form_label'>" . elgg_echo("businesscard:form:room") . "</div>";
	$form_body .= elgg_view('input/text', array('internalname' => 'room', 'value' => $user->room));
	
	//$form_body .= "<div class='businesscard_form_label'>" . elgg_echo("businesscard:form:postalcode") . "</div>";
	//$form_body .= elgg_view('input/text', array('internalname' => 'postalcode', 'value' => $user->postalcode));
	
	//$form_body .= "<div class='businesscard_form_label'>" . elgg_echo("businesscard:form:city") . "</div>";
	//$form_body .= elgg_view('input/text', array('internalname' => 'city', 'value' => $user->city));
	
	//$form_body .= "<div class='businesscard_form_label'>" . elgg_echo("businesscard:form:country") . "</div>";
	//$form_body .= elgg_view('input/text', array('internalname' => 'country', 'value' => $user->country));
	
	$form_body .= "<div class='businesscard_form_label'>" . elgg_echo("businesscard:form:phone") . "</div>";
	$form_body .= elgg_view('input/text', array('internalname' => 'phone', 'value' => $user->phone));
	
	$form_body .= "<div class='businesscard_form_label'>" . elgg_echo("businesscard:form:sein") . "</div>";
	$form_body .= elgg_view('input/text', array('internalname' => 'sein', 'value' => $user->sein));

	$form_body .= "<div class='businesscard_form_label'>" . elgg_echo("businesscard:form:skype") . "</div>";
	$form_body .= elgg_view('input/text', array('internalname' => 'skype_username', 'value' => $user->skype_username));

	$form_body .= "<div class='businesscard_form_label'>" . elgg_echo("businesscard:form:email") . "</div>";
	$form_body .= elgg_view('input/text', array('internalname' => 'email', 'value' => $user->email));
	
	$form_body .= "<div class='businesscard_form_label'>" . elgg_echo("businesscard:form:website") . "</div>";
	$form_body .= elgg_view('input/text', array('internalname' => 'website', 'value' => $user->getURL()));
	
	$form_body .= elgg_view('input/submit', array('value' => elgg_echo('businesscard:form:submit')));
	
	$form = elgg_view("input/form", array(
							"body" => $form_body,
							"action" => $vars["url"] . "action/businesscard/generate"));
?>
<div class="contentWrapper">
	<?php echo $form;?>
</div>