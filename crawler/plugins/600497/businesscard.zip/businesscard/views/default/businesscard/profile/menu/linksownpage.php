<?php

	/**
	 * Elgg hoverover extender for bcard
	 * 
	 * @package ElggFile
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

?>

	<p class="user_menu_file">
		<a href="<?php echo $vars['url']; ?>pg/businesscard/"><?php echo elgg_echo("businesscard:profile_links:create"); ?></a>	
	</p>

