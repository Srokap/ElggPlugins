<?php
	$english = array(
	
		'businesscard:menu:index' => "My Businesscard",

		'businesscard:profile_links:create' => "Download your vCard",
	
		'businesscard:title' => "Create your QR-code vCard",
		'businesscard:menu:information' => "Information",
		'businesscard:information' => "Information about the plugin",
		
		'businesscard:pagetitle' => 'Business card generator',
		'businesscard:success' => 'Your action was successful',
		'businesscard:failure' => 'Your action failed',
	
		// Form
		'businesscard:form:name' => "Name",
		//'businesscard:form:institution' => "Institution",
		'businesscard:form:department' => "Department",
		'businesscard:form:lab' => "Laboratory",
		'businesscard:form:address' => "Address",
		'businesscard:form:room' => "Room",
		'businesscard:form:postalcode' => "Postal code",
		'businesscard:form:city' => "City",
		'businesscard:form:sein' => "Sein number",
		'businesscard:form:country' => "Country",
		'businesscard:form:skype' => "Skype username",
		'businesscard:form:phone' => "Phone number",
		'businesscard:form:email' => "E-mail address",
		'businesscard:form:website' => "Website",
		'businesscard:form:card_type' => "Card type",
		'businesscard:form:card_type:code' => "Code only",
		'businesscard:form:card_type:both' => "Code and text",
		'businesscard:form:card_type:text' => "Text only",
		'businesscard:form:institution' => "Institution",
		'businesscard:form:institution:AMC'=> "AMC",
		'businesscard:form:institution:NKI' => "NKI",
		'businesscard:form:institution:Sanquin' => "Sanquin",

		'businesscard:form:submit' => "Create my business cards!",
	);
	
	add_translation("en", $english);
?>