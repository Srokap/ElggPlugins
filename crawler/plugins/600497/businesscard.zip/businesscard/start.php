<?php
/*******************************************************************************
 * Syn@ps QR-code businesscard plugin
 *
 * @author Drs. M.R.A. Welkers
 ******************************************************************************/

function businesscard_init(){
		global $CONFIG;

		// Register pagehandler for nice url's
		register_page_handler('businesscard', 'businesscard_page_handler');

		// Extend hover-over menu on our own page
		extend_view('profile/menu/linksownpage', 'businesscard/profile/menu/linksownpage');
	}


	function businesscard_page_handler($page)
		{
		if (!isset($page[0])) 
					{
				include dirname(__FILE__) . '/index.php';
				break;
	     			}
     
		elseif($page[0])
				{
			$time_created = date('Y/m/d', get_user($page[0])->time_created);
        	$file_location = datalist_get('dataroot')."$time_created/".$page[0]."/vcard.vcf";
			$size = filesize($file_location);
			
			$fh = fopen($file_location, 'r');
			$theData = fread($fh, $size);
			fclose($fh);
	
			header('Content-Type: text/x-vcard');
			header("Content-Disposition: attachment; filename=\"vcard.vcf\"");
			header("Content-Transfer-Encoding: binary");
			header("Pragma: public");
			header("Expires: 0");
			header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
			header("Cache-Control: public");
			header("Content-Description: File Transfer");
			header("Content-Length: ".$size);			    
				ob_clean();
			    flush();
				echo $theData;
			    exit;
				}
		}
	
	function businesscard_submenus(){
		global $CONFIG;

		if (get_context() == 'businesscard'){
			add_submenu_item(elgg_echo("businesscard:menu:index"), $CONFIG->wwwroot . 'pg/businesscard/');
		}
	
	}

	// Register default Elgg events
	register_elgg_event_handler('init', 'system', 'businesscard_init');
	register_elgg_event_handler('pagesetup','system','businesscard_submenus');
		
	// Register actions
	register_action('businesscard/generate', false, $CONFIG->pluginspath . 'businesscard/actions/generate.php');

?>