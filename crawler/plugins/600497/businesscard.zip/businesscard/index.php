<?php
    // make sure only logged in users can see this page	
    gatekeeper();
 
    // Set pageowner
    set_page_owner(get_loggedin_userid());
    
    // set the title
    $title = elgg_echo("businesscard:title");
 
    // start building the main column of the page
    $area2 = elgg_view_title($title);
 
    // Add the form to this section
    $area2 .= elgg_view("businesscard/forms/input");
 
    // layout the page
    $body = elgg_view_layout('two_column_left_sidebar', '', $area2);
 
    // draw the page
    page_draw($title, $body);
?>