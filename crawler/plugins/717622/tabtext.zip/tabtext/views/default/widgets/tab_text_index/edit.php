<?php
$widget_title = $vars['entity']->widget_title;
$ttt1=$vars['entity']->title1;
$ttt2=$vars['entity']->title2;
$ttt3=$vars['entity']->title3;
$ttd1=$vars['entity']->description1;
$ttd2=$vars['entity']->description2;
$ttd3=$vars['entity']->description3;
?>
<p>
  <?php echo elgg_echo('custom_index_widgets:widget_title'); ?>:
  <?php
	echo elgg_view('input/text', array(
			'internalname' => 'params[widget_title]',                        
			'value' => $widget_title
		));
	?>
</p>
<p><?php echo elgg_echo("tabtext:instructions"); ?></p>
<p>
<!--	<input type="text" name="params[title1]" value="<?php echo $ttt1; ?>" /> -->
<p>
  <?php
	echo elgg_view('input/text', array(
			'internalname' => 'params[title1]',                        
			'value' => $ttt1
		));
	?>
</p>
		<?php echo elgg_view('input/longtext', array('internalname'=>'params[description1]', 'value'=>$ttd1)); ?>
 
<p>
  <?php
	echo elgg_view('input/text', array(
			'internalname' => 'params[title2]',                        
			'value' => $ttt2
		));
	?>
</p>

		<?php echo elgg_view('input/longtext', array('internalname'=>'params[description2]', 'value'=>$ttd2)); ?>
<p>
  <?php
	echo elgg_view('input/text', array(
			'internalname' => 'params[title3]',                        
			'value' => $ttt3
		));
	?>
</p>

			<?php echo elgg_view('input/longtext', array('internalname'=>'params[description3]', 'value'=>$ttd3)); ?>

			
</p>

	
