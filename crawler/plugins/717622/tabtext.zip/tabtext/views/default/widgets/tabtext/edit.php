<?php
/**
 * tabtext plugin.
 * Allows users to enter any text or html into a widget
 * 
 * @package tabtext
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Brett Profitt <brett.profitt@eschoolconsultants.com>
 * @copyright Brett Profitt 2008
 * @link http://www.eschoolconsultants.com
 * @requires xtabs
 * modified by Jon Dron, Athabasca University, 2011
 * depends on xtabs
 *
 * <textarea name="params[description]"><?php echo $vars['entity']->description; ?></textarea>
 * 
 */

/*
// this will seriously break with tinymce installed.
echo elgg_view('input/longtext', array('internalname'=>'params[description]', 'value'=>$vars['entity']->description, 'editor_view'=>'none')); 
 <?php echo elgg_view('input/longtext', array('internalname'=>'params[description]', 'value'=>$vars['entity']->description, 'editor_view'=>'none')); ?>
<textarea name="params[description]"><?php echo $vars['entity']->description; ?></textarea>
*/

$numtabs=3;

?>
<p> <?php echo elgg_echo("tabtext:instructions"); ?></p>
<p>
	<input type="text" name="params[title1]" value="<?php echo htmlentities($vars['entity']->title1); ?>" />
		<?php echo elgg_view('input/longtext', array('internalname'=>'params[description1]', 'value'=>$vars['entity']->description1)); ?>
 
	<input type="text" name="params[title2]" value="<?php echo htmlentities($vars['entity']->title2); ?>" />
		<?php echo elgg_view('input/longtext', array('internalname'=>'params[description2]', 'value'=>$vars['entity']->description2)); ?>
		<input type="text" name="params[title3]" value="<?php echo htmlentities($vars['entity']->title3); ?>" />	
			<?php echo elgg_view('input/longtext', array('internalname'=>'params[description3]', 'value'=>$vars['entity']->description3)); ?>

			
</p>

	
