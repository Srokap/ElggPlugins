<?php
/**
 * tabtext plugin.
 * Allows users to enter any text or html into a widget
 * 
 * @package tabtext
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Brett Profitt <brett.profitt@eschoolconsultants.com>
 * @copyright Brett Profitt 2008
 * @link http://www.eschoolconsultants.com
 * @requires xtabs
 * modified by Jon Dron, Athabasca University, 2011
 */

$page_owner = page_owner_entity();
if ($page_owner === false || is_null($page_owner)) {
	$page_owner = $_SESSION['user'];
    set_page_owner($page_owner->getGUID());
}

if (isset($vars['entity'])) {
	if (!$title1 = $vars['entity']->title1) {
		$title1 = elgg_echo('tabtext:no_title');
	}
if (!$title2 = $vars['entity']->title2) {
		$title2 = elgg_echo('tabtext:no_title');
	}
	if (!$title3 = $vars['entity']->title3) {
		$title3 = elgg_echo('tabtext:no_title');
	}
	if (!$body1 = $vars['entity']->description1) {
		$body1 = elgg_echo('tabtext:no_body');
	}
	if (!$body2 = $vars['entity']->description2) {
		$body2 = elgg_echo('tabtext:no_body');
	}
	if (!$body3 = $vars['entity']->description3) {
		$body3 = elgg_echo('tabtext:no_body');
	}

$id1=$vars['entity']->guid.'tab_1';
$id2=$vars['entity']->guid.'tab_2';
$id3=$vars['entity']->guid.'tab_3';
$widgetid =$vars['entity']->guid;
	
         $TabsArray = array(
 $id1 => array('id' => $id1, 'name' => $title1, 'view' => 'output/longtext', 'vars' => array('value'=>$body1)),
 $id2 => array('id' => $id2, 'name' => $title2, 'view' => 'output/longtext', 'vars' => array('value'=>$body2)),
 $id3 => array('id' => $id3, 'name' => $title3, 'view' => 'output/longtext', 'vars' => array('value'=>$body3))
        );
 
        $body = elgg_view('page_elements/tabs', array('tabs' => $TabsArray, widgetid=>$widgetid));	
	
	
	echo '<div class="tabtext_container">';
	//echo '<div class="tabtext_title">' . $title . '<div>';
	echo '<div class="tabtext_body">' . $body . '<div>';
	echo '</div>';
}

?>