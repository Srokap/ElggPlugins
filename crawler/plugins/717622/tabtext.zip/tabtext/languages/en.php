<?php
/**
 * tabtext plugin.
 * Allows users to enter any text or html into a widget
 * 
 * @package tabtext
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Brett Profitt <brett.profitt@eschoolconsultants.com>
 * @copyright Brett Profitt 2008
 * @link http://www.eschoolconsultants.com
 * modified by Jon Dron, Athabasca University, 2011
 */

$english = array(
	'tabtext:instructions' => ' Fill in all of three boxes ',
	'tabtext:title' => '3-tab Text Box',
	'tabtext:no_title' => "No Title",
	'tabtext:no_body' => "No Content.",
);
				
add_translation("en",$english);