<?php
/**
 * Tabtext plugin.
 * Allows users to enter any text or html into a widget with exactly 3 tabs
 * Based mainly on Anytext by Brett Profitt
 * @package TabText
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Brett Profitt <brett.profitt@eschoolconsultants.com>
 * @copyright Brett Profitt 2008
 * @link http://www.eschoolconsultants.com
 * modified in quick and very dirty way by Jon Dron, 2011, to provide primitive 3-tab view using
 * xtabs  (see http://community.elgg.org/pg/plugins/project/713783/developer/ihayredinov/ajax-tabs-for-developers) 
* if installed, it will  work with custom_index_widgets (heavily modifies a bit of code from that too - see http://community.elgg.org/pg/plugins/project/385113/developer/FxNion/custom-index-with-widgets)
 * @author Jon Dron <jond@athabascau.ca>
 * @copyright Brett Profitt 2008, Jon Dron 2011
 */

function tabtext_init() {
		//needs xtab plugin
		if(is_plugin_enabled('xtabs')){
			//note can only add one per page and it goes horridly wrong if you don't
			add_widget_type('tabtext', elgg_echo('tabtext:title'), elgg_echo('tabtext:description'), 'all', false);
			//make it work with custom index widgets. Note there's a different widget for this
			if (is_plugin_enabled('custom_index_widgets')){	
				add_widget_type('tab_text_index',elgg_echo ('tabtext:title'),elgg_echo ('tabtext:title'), "custom_index_widgets",true);
			}	
		}
}

register_elgg_event_handler('init','system','tabtext_init');
?>