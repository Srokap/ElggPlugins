<?php
/*
 * Satheesh PM, BARC Mumbai
 * www.satheesh.anushaktinagar.net
 * 
 */
?>

/* ***************************************
	Ads
*****************************************/

#ads-footer{
margin-top: 75px;
width : auto;
padding : 3px ;
overflow: hidden;
text-align : center;
}

#ads-sidebar {
padding : 3px ;
text-align : center;
width : auto;
overflow: hidden;
}

#ads-header {
width : auto;
height : 100px;
padding : 3px ;
border-bottom : 1px solid #4690D6;
overflow: hidden;
position: relative;
	}


        .eddie {
	float: right;
	padding: 15px 20px 15px 20px;
	}
.jshowoff p.jshowoff-slidelinks {
	position: absolute;
	bottom: 3px;
	right: 3px;
	margin: 0;
	padding: 0;
	}
.jshowoff-slidelinks a, .jshowoff-controls a {
	display: block;
	background-color: #4690D6;
	color: white;
	padding: 5px 7px 5px;
	margin: 5px 0 0 5px;
	float: left;
	text-decoration: none;
	-moz-border-radius: 4px;
	-webkit-border-radius: 4px;
	outline: none;
	font-size: 11px;
	line-height: 14px;
	}
.jshowoff-slidelinks a:hover, .jshowoff-controls a:hover {
	color: red;
	}
.jshowoff-slidelinks a.jshowoff-active, .jshowoff-slidelinks a.jshowoff-active:hover {
	background-color: #DEDEDE;
	color: #000;
	}
p.jshowoff-controls {
	overflow: auto;
	height: 1%;
        background : none;
	padding: 0 0 3px 3px;
	margin: 0px;
       	}
.jshowoff-controls a {
	margin: 5px 5px 0 0;
	font-size: 12px;
	padding: 4px 8px 5px;
	}

.jshowoff-pausetext {
	color: blue;
	}

