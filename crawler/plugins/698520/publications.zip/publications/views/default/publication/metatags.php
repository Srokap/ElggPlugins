<script type="text/javascript" src="<?php echo $vars['url'];?>mod/publications/javascript/publications.js"></script>
<script type="text/javscript">
var wwwroot = <?php echo $vars['url'];?>; 
</script>
