<?php
/**
 * Elgg Facebook Connect CSS
 */
?>

#facebookservice_site_settings .text_input {
	width: 350px;
}

#facebook_connect {
	padding: 0px 0 0 0;
}