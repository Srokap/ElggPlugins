<?php

	$spanish = array(
	
		/**
		 * twitter widget details
		 */
		
	
		'twitter:username' => 'Usuario',
		'twitter:num' => 'Cuántos -tweets- quieres mostrar?',
		'twitter:visit' => 'Visitar mi twitter',
		'twitter:notset' => 'Este componente aún no esta configurado para poder funcionar. 
Para mostrar los &uacute;ltimos -tweets-, pulsa editar y rellena los datos necesarios para su activación. 

Con este widget podrás tener control de tu twitter desde la red social',
		
		
		 /**
	     * twitter widget river
	     **/
	        
	        //generic terms to use
	        'twitter:river:created' => "%s a&ntilde;adido al componente twitter",
	        'twitter:river:updated' => "%s actualizado al componente twitter",
	        'twitter:river:delete' => "%s eliminados al componente twitter",
	        
		
	);
					
	add_translation("es",$spanish);

?>
