<?php
	/**
	 * Elgg Candidate Profile Plugin
	 * This plugin allows users to create custom candidate profile
	 * 
	 * @package ElggProfile
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Prateek Choudhary <synapticfield@gmail.com>
	 * @copyright Prateek Choudhary
	 */
	$spanish = array(

		"videolist" => "Videos",
		
		"videolist:home" => 'Videos de %s',
		"videolist:new" => 'Agregar un Video',
		"videolist:find" => 'Videos de toda la red',
		"videolist:search" => "Videos de toda la red",
		"videolist:title_videourl" => 'Meter Url de YouTube',
		"videolist:submit" => 'Aceptar',
		"videolist:error" => 'Hubo un error guardando el video, intentalo de nuevo tras unos segundos o ponte en contacto con el administrador',
		"videolist:posted" => 'El video se ha guardado satisfactoriamente!',
		"video:more" => "Ver todos los videos",
		"video:none" => "No hemos encontrado encontrado ningún video",
		"candidateprofile:candidatevideo" => "Mis videos",
		"videos:deleted" => "Su video se ha eliminado satisfactoriamente!",
		"videos:notdeleted" => "El video no puede ser eliminado ahora. Intentalo tras unos segundos o ponte en contacto con el administrador",
		"videolist:widget" => "Videos",
		"videolist:widget:description" => "Tu -playlist- personal",
		"videolist:num_videos" => "Número de videos a mostrar",
		'videolist:widget' => "Mis Videos",
		"videolist:widget:description" => "Puedes compartir tus galerias de videos de Youtube con el resto de la red a través del siguiente widget",
		"profile:videoheader" => "Mi galería de videos",
		"videolist:title_access" => "Acceso",
		"item:object:videolist" => "Videos",
		"videolist:tags" => "Poner etiquetas",
	);
					
	add_translation("es",$spanish);

?>
