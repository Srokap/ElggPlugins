<?php

// Generado por translationbrowser 

$spanish = array( 
	 'friends_of_friends'  =>  "Amig@s de amig@s" , 
	 'friendsoffriends'  =>  "Amig@s de amig@s" , 
	 'friends_of_friends:setting:hidefriendsof'  =>  "Ocultar Amig@s de" , 
	 'friends_of_friends:setting:showfriendsof'  =>  "Mostrar Amig@s de"
); 

add_translation('es', $spanish); 

?>
