<?php
	$spanish = array(
		// main titles
		'avatar_wall' => "Mural .:ALD:.",
		'avatar_wall:title' => "Mural de Avatares de la red .:ALD:.",
		'avatar_wall:shorttitle' => "Mural",
		'avatar_wall:description' => "El mural mostrará todos los avatares de los usuari@s en una sola página",
		
		'avatar_wall:settings:onlywithavatar' => "Mostrar solo los usuari@s que han configurado la foto de su perfil",
		'avatar_wall:settings:tiny' => "Diminuto",
		'avatar_wall:settings:small' => "Pequeño",
		'avatar_wall:settings:iconsize' => "Elegir tamaño del icono",
		'avatar_wall:settings:maxicons' => "Elegir el máximo de iconos a mostrar",
		
		
	);
	
	add_translation("es", $spanish);
?>
