<?php

// Generado por translationbrowser 

$spanish = array( 
	 'blog'  =>  "Blog" , 
	 'blogs'  =>  "Blogs" , 
	 'blog:user'  =>  "Blog de %s" , 
	 'blog:user:friends'  =>  "Blogs de los amig@s de %s" , 
	 'blog:your'  =>  "Blog Personal" , 
	 'blog:posttitle'  =>  "Blog de %s: %s" , 
	 'blog:friends'  =>  "Blogs de tus amig@s" , 
	 'blog:yourfriends'  =>  "Blogs recientes de tus amig@s" , 
	 'blog:everyone'  =>  "Todos los blogs de la red" , 
	 'blog:read'  =>  "Leer blog" , 
	 'blog:addpost'  =>  "Escribir noticia en el blog" , 
	 'blog:editpost'  =>  "Editar una respuesta en el blog" , 
	 'blog:text'  =>  "Texto del blog" , 
	 'blog:strapline'  =>  "%s" , 
	 'item:object:blog'  =>  "Comentarios en el blog" , 
	 'blog:never'  =>  "nunca" , 
	 'blog:preview'  =>  "Previsualizar" , 
	 'blog:draft:save'  =>  "Guardar borrador" , 
	 'blog:draft:saved'  =>  "&Uacute;ltimo borrador" , 
	 'blog:comments:allow'  =>  "Permitir comentarios" , 
	 'blog:preview:description'  =>  "Este una previsualizaci&oacute;n de su env&iacute;o." , 
	 'blog:preview:description:link'  =>  "Continuar editando o guardar su env&iacute;o, pulseme." , 
	 'blog:river:created'  =>  "%s ha escrito" , 
	 'blog:river:updated'  =>  "%s ha actualizado" , 
	 'blog:river:posted'  =>  "%s ha dejado" , 
	 'blog:river:create'  =>  "una nueva entrada titulada:" , 
	 'blog:river:update'  =>  "la entrada:" , 
	 'blog:river:annotate'  =>  "un comentario en el post:" , 
	 'blog:posted'  =>  "La noticia ha sido escrita en el blog" , 
	 'blog:deleted'  =>  "La noticia ha sido eliminada del blog" , 
	 'blog:save:failure'  =>  "El blog no puede ser guardado. Intentalo de nuevo o ponte en contacto con el administrador" , 
	 'blog:blank'  =>  "Pero te has fijado?. Tienes que rellenar el título y el cuerpo del mensaje para poder enviarlo" , 
	 'blog:notfound'  =>  "No triunfas. No encontramos ningún envio a ese blog. Prueba con otra búsqueda." , 
	 'blog:notdeleted'  =>  "Ops!, No podemos borrar este envío" , 
	 'blog:newpost'  =>  "Nuevo blog post" , 
	 'blog:via'  =>  "via blogs" , 
	 'blog:enableblog'  =>  "Habilitar blog del grupo" , 
	 'blog:group'  =>  "Blog del grupo" , 
	 'blog:error'  =>  "Algo ha ido mal, intentalo de nuevo."
); 

add_translation('es', $spanish); 

?>