<?php
/**
 * Omni Inviter -- Offers multiple, extendable ways of inviting new users
 * 
 * @package Omni Inviter
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Brett Profitt <brett.profitt@gmail.com>
 * translation by psy
 */

$blurb = "Hola!, en primer lugar tienes que configurar el mensaje a enviar: cada cu&aacute;nto tiempo quieres que se envie 
y cu&aacute;ntas veces quieres que sea enviado<br /><br />

El asunto, el cuerpo y los campos de emails se rellenan de forma autom&aacute;tica por nuestro sistema:<br />
<ul>
	<li>%USER_NAME% -- Pon tu nick de usuario</li>
	<li>%USER_FULLNAME% -- Pon tu nombre y apellidos</li>
	<li>%USER_EMAIL% -- Pon tu direcci&oacute;n de email</li>
	<li>%USER_MESSAGE% -- Ahora, escribe un mensaje de invitaci&oacute;n</li>
	
	<li>%INVITED_NAME% -- Nombre de la persona a la que invitas</li>
	<li>%INVITED_EMAIL% -- Direcci&oacute;n de email del invitado</li>
	
	<li>%SITE_EMAIL% -- Direcci&oacute;n de email con la que te has registrado en este sistema</li>
	<li>%SITE_NAME% -- Nombre de la plataforma desde la que haces la invitaci&oacute;n</li>
	<li>%SITE_DOMAIN_SHORTENED% -- Versi&oacute;n actual del sistema Elgg</li>
	
	<li>%OI_JOIN_LINK% -- Link que los usuarios invitados deber&iacute;an clickar al registrarse</li>
	<li>%OI_INVITATION_ID% -- ID de invitaci&oacute;n</li>
	<li>%OI_INVITATION_CODE% -- C&oacute;digo de invitaci&oacute;n</li>
</ul>

Para una mayor compatibilidad con los clientes de email, deshabilita todos los editores de HTML
";

// the weird formatting is because we use wordwrap to wrap at 75 chars.
// can't do that here because of the vars, but long lines annoy me.
$body = "Hey!!! %INVITED_NAME%,

%USER_FULLNAME% te ha invitado a entrar en la %SITE_NAME%! <br /> Haz click en " .  
"el link que tienes a continuación para comenzar con el proceso  registro! " .

"(Ésta línea es únicamente para ti. No dejes que la vea nadie!!) <br /> %OI_JOIN_LINK%i".

"Si por alguna razón no se muestra el link o al hacer -Click- no funciona, puedes".
"utiliza la información que tienes a continuación para crearte un usuario invitado de forma manual.<br />  En primer lugar, visita http://%SITE_DOMAIN_SHORTENED% " .
"y haz -Click- en el botón de REGISTRO.<br /> ".
"En la parte inferior tienes un enlace que te lleva a introducir un ID de Invitación y un Código <br />".

"ID de la Invitación: %OI_INVITATION_ID%
Código Invitación: %OI_INVITATION_CODE%

La invitación de %USER_FULLNAME% dice: <br />
%USER_MESSAGE%

Política de Privacidad: Tu dirección de email se encuentra dentro " . 
"de nuestro sistema como %USER_FULLNAME%. La %SITE_NAME% se compromete a no distribuir " . 
"dicho contacto con ningún tercero sin tu consentimiento " . 
"La información es usada para crear una cuenta nueva en el sistema de la %SITE_NAME% <br />" .
"No dudes en ponerte en contacto con el Administrador si desear borrar tus datos.
";

$default_user_message = '"Quiero que conozcas ésta red social de código libre... Es una pasada!!!" ;)';


$spanish = array(
	'oi:settings:rename' => 'Renombrar',
	'oi:settings:blurb' => $blurb,
	'oi:settings:installed_methods' => 'Métodos instalados',
	
	'oi:settings:message_subject_default' => '%USER_FULLNAME% te ha invitado a %SITE_NAME%!',
	//'oi:settings:message_from_default' => '%SITE_NAME% <%SITE_EMAIL%>',
	'oi:settings:message_from_default' => '%SITE_EMAIL%',
	'oi:settings:message_body_default' => $body,
	'oi:settings:message_rate' => 'Envia %s invitaciones cada %s',
	'oi:settings:message_subject' => 'Asunto de la Invitación',
	'oi:settings:message_from' => 'Remitente del mensaje',
	'oi:settings:message_body' => 'Texto de la Invitación',
	
	'oi:settings:disabled' => 'Deshabilitado -- Permitido solo el envío manual',
	'oi:settings:minute' => 'Minuto',
	'oi:settings:fiveminute' => '5 Minutos',
	'oi:settings:fifteenminute' => '15 Minutos',
	'oi:settings:halfhour' => '30 Minutos',
	'oi:settings:hourly' => 'Hora',
	'oi:settings:daily' => 'Día',
	'oi:settings:weekly' => 'Semana',

	'oi:settings:enable_widget' => 'Habilitar el modulo Omni Inviter?',

	'oi:settings:max_send_attempts' => 'Máximo de avisos de envio antes de una invitación deshabilitado!',
	
	/* User Settings */
	'oi:usersettings:notify_on_invite_use' => 'Notificarme cuando alguien me invite',

	'oi:message:invited_join_subject' => '%s ha entrado en %s!',
	'oi:message:invited_join_body' => '%s ha utilizado tu invitación para entrar a %s!  Lo suyo es que saludes a tu invitado no crees?',

	'oi:invite:i_want_to_invite' => 'Quiero invitar a mis:',
	'oi:invite:default_user_message' => $default_user_message,
	'oi:invite:user_message' => 'Texto de la invitación:',

	'oi:invite:invitations_created' => '%s invitaciones han sido creadas y serán enviadas pronto.., no te impacientes, ya llegarán ;)',
	'oi:invite:invitations_created_singular' => '%s invitación ha sido creada y será enviada pronto... no te impacientes, ya llegará ;)',

	'oi:invite' => 'Invitador Masivo',
	'oi:invite:inviting' => 'Has invitado a %s usuari@s',
	'oi:invite:inviting_singular' => 'Has invitado a %s',
		'oi:invite:send_invitations' => 'Invitar',
	'oi:invite:send_success' => 'Invitación enviada!',
	'oi:invite:delete_success' => 'La Invitación ha sido borrada!', 

	'oi:send' => 'Enviar',
	'oi:name' => 'Nombre de tu amig@',
	'oi:method' => 'Método',
	'oi:log' => 'Log',
	'oi:add' => 'Añadir usuari@',
	'oi:done' => 'Añadir lista',
	'oi:added_users' => 'Has añadido usuari@s a tu lista pero aún no has enviado ninguna invitación!, a qué esperas?!  Puedes intentar buscar usuarios o presionar en Enviar Invitaciones para comenzar a hacerlo',
	
	'oi:have_invitation' => 'Introducir ID y Código de Invitaci&oacute;n',
	'oi:invitation_id' => '<br />ID de Invitación <br />',
	'oi:invitation_code' => '<br />Código de Invitación <br />',
	'oi:invitation_info_accepted' => 'ID y Código de Invitación confirmados!!!  Ya puedes comenzar con el registro!...Bienvenid@',

	/* WIDGET */
	'oi:widget:name' => 'Mis Invitados',
	'oi:widget:description' => 'No mostrar al resto que has sido invitado?',
	'oi:widget:i_invited' => 'He invitado a %s usuarios!',
	'oi:widget:i_invited_singular' => 'He invitado a %s!',
	'oi:widget:link_msg' => 'Voy a invitar a más peña! ;=)',
	'oi:widget:my_invited_users' => 'Mi lista de invitados',
	'oi:widget:num_display' => 'Número de invitados a mostrar',
	'oi:widget:icon_size' => 'Tamaño del icono de los usuarios invitados',
	'oi:widget:small' => 'Pequeño',
	'oi:widget:tiny' => 'Diminuto',
	'oi:widget:disabled' => '0',


	/* ERRORS */
	'oi:errors:unknown_method' => 'Error en alguno de los m&eacute;todos. No podemos continuar. Intentalo de nuevo o ponte en contacto con el administrador',
	'oi:errors:cannot_create_all_invitations' => 'Ops!, solo %s de tus %s invitaciones han podido ser creadas. Tienes m&aacute;s detalles de los sucedido en la secci&oacute;n Invitaciones',
	'oi:errors:used_code' => 'El C&oacute;digo de invitaci&oacute;n que has introducido ya ha sido usado!!!! Enredando!?  Revisa la invitaci&oacute;n original que has recibido e intentalo de nuevo. Si tienes problemas ponte en contacto con el administrador. Si lo que quieres es entrar en la red social, puedes registrarte a trav&eacute;s del link de abajo',
	'oi:errors:invalid_code' => 'El ID y el C&oacute;digo de invitaci&oacute;n no son v&aacute;lidos!! Revisa la invitaci&oacute;n original que has recibido e intentalo de nuevo. Si tienes problemas ponte en contacto con el administrador. Si lo que quieres es entrar en la red social, puedes registrarse a trav&eacute;s del link de debajo',
	'oi:errors:method_error' => 'Hay un error con el m&eacute;todo que has seleccionado!. Elige otro diferente',
	'oi:errors:unknown_user' => 'Usuario desconocido',
	'oi:errors:send_fail' => 'No puedo enviar invitaciones. Revisa que los detalles de configuraci&oacute;n son correctos, que el m&eacute;todo que usas es correcto y que el m&aacute;ximo de envios no es superado',

	/* ADMIN */
	'oi:omni_inviter' => 'Invitador masivo',
	'oi:admin:stats' => 'Estadísticas',
	'oi:admin:invitations' => 'Lista de Invitaciones',
	'oi:admin:no_invitations' => 'No hay ninguna invitación',

	'oi:admin:invites:list_user' => 'Invitaciones enviadas por %s',
	'oi:admin:invites:list_all' => 'Todas las Invitaciones',

	'oi:admin:sent_status' => 'Estado del envío:',
	'oi:admin:not_sent' => 'En camino',
	'oi:admin:sent_error' => 'No puedo enviar!! (Intentos: %s, Último intento: %s)',
	'oi:admin:sent_stalled' => 'Stalled!.  (Intentos: %s, Último intento:  %s)',
	'oi:admin:sent_status_value' => 'Último envio de %s (Intentos: %s, Correcto: %s)',
	
	'oi:admin:used_status' => 'Estado del uso:',
	'oi:admin:not_used' => 'Sin usar!',
	'oi:admin:used_status_value' => 'Usado por %s en %s',

	'oi:admin:clicked_status' => 'Estado del enlace:',
	'oi:admin:not_clicked' => 'Sin clickar!',
	'oi:admin:clicked_status_value' => 'Clickado en %s',

	'oi:admin:created_by' => 'Creado por',
	'oi:admin:created_by_value' => '%s en %s',
	'oi:admin:invited_name' => 'Nombre de los invitados',

	'oi:admin:log' => 'Log',

	/* Stats */

	// section headers
	'oi:stats' => 'Estadísticas',
	'oi:stats:sent_invitations' => 'Invitaciones enviadas',
	'oi:stats:all_invitations' => 'Todas las invitaciones',
	'oi:stats:used_invitations' => 'Invitaciones usadas',
	'oi:stats:total' => 'Total',


	// types
	'oi:stats:sent' => 'Enviado',
	'oi:stats:unsent' => 'No enviados:',
	'oi:stats:error' => 'Errores enviando:',
	'oi:stats:used' => 'Usado:',
	'oi:stats:ignored' => 'Ignorado:',
	'oi:stats:clicked_and_ignored' => 'Clickado e Ignorado:',
	'oi:stats:sent' => 'Enviados:',
	'oi:stats:error_sending' => 'Error enviando',


	

	


	
	

	'item:object:invitation' => 'Invitaciones'
);

add_translation("es", $spanish);
