<?php
	/**
	 * Elgg garbage collector language pack.
	 * 
	 * @package ElggGarbageCollector
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'garbagecollector:period' => 'Cada cuánto debería el sistema limpiar la "basura"?',
	
			'garbagecollector:weekly' => 'Una vez a la semana',
			'garbagecollector:monthly' => 'Una vez al mes',
			'garbagecollector:yearly' => 'Una vez al año',
	
			'garbagecollector' => "RCOLECTOR de Basura\n",
			'garbagecollector:done' => "HECHO\n",
			'garbagecollector:optimize' => "Optimizando %s ",
	
			'garbagecollector:error' => "ERROR",
			'garbagecollector:ok' => "OK",
	
			'garbagecollector:gc:metastrings' => 'Limpiando los metastrings que no tienen link. Huérfanos los pobres: ',
	
	);
					
	add_translation("es",$spanish);
?>
