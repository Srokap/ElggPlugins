<?php

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messageboard:board' => "Bandeja de Mensajes",
			'messageboard:messageboard' => "",
			'messageboard:viewall' => "Ver todos",
			'messageboard:postit' => "Escribir",
			'messageboard:history' => "Historial",
			'messageboard:none' => "No tienes ningún mensaje en tu bandeja de entrada",
			'messageboard:num_display' => "Número de mensajes a mostrar",
			'messageboard:desc' => "Ésta es la bandeja de mensajes, cualquiera, incluído tu mismo puede dejar un mensaje en tu perfil",
	
			'messageboard:user' => "en la bandeja personal de %s",
	
			'messageboard:history' => "Historial",
			'messageboard:replyon' => 'responder a',	
         /**
	     * Message board widget river
	     **/
	        
	        'messageboard:river:annotate' => "%s tiene un comentario nuevo en su bandeja de mensajes",
	        'messageboard:river:create' => "%s ha añadido el widget de la bandeja de mensajes",
	        'messageboard:river:update' => "%s ha actualizado su widget de bandeja de mensajes",
	        'messageboard:river:added' => "%s ha escrito un mensaje a",
		    'messageboard:river:messageboard' => "en su bandeja personal",

			
		/**
		 * Status messages
		 */
	
			'messageboard:posted' => "El comentario ha sido escrito con éxito!",

			'messageboard:deleted' => "El comentario ha sido borrado!",
	
		/**
		 * Email messages
		 */
	
			'messageboard:email:subject' => 'Tienes un mensaje nuevo en la bandeja de mensajes!',
			'messageboard:email:body' => "%s te ha dejado el siguiente comentario:

			
%s


Para ver los comentarios en tu bandeja de mensajes, haz click en el siguiente link:

	%s

Para consultar el perfil  de %s, haz click en este link:

	%s

No respondas a este email!, recuerda que es el sistema el que te lo ha enviado de forma -automágica-. Si tienes algún problema, ponte en contacto con el administrador",
	
		/**
		 * Error messages
		 */
	
			'messageboard:blank' => "Necesitas poner algo en la bandeja de mensajes para enviarlo, no crees!??",
			'messageboard:notfound' => "W0ps!, no encuentro lo que buscas. Intentalo de nuevo o ponte en contacto con el administrador",
			'messageboard:notdeleted' => "El mensaje no ha podido ser borrado!, intentelo de nuevo o ponte en contacto con el administrador",
			'messageboard:somethingwentwrong' => "Buggg!!, algo extraño a sucedido. Intentalo de nuevo o ponte en contacto con el adminitrador",
	     
			'messageboard:failure' => "Fallazo!!, el sistema no tiene ni idea de que sucede. Intentalo de nuevo o ponte en contacto con el administrador",
	
	);
					
	add_translation("es",$spanish);

?>
