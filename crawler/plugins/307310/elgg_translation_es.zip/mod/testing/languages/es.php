<?php
global $CONFIG;

$spanish = array(
                 'testing' => 'Testeando',
                 'testing:desc' => 'Proporciona siporte para hacer test a unidades sin el entorno de Elgg',
                 'testing:autoscan'=>"Auto-escanear en búsqueda de todas las unidades<br/><em>(todos los filleros llamados XXXTest.php debajo {$CONFIG->path})</em>",
                 'testing:additional'=>"Directorio adicionales para escanear<br/><em>(relativos al Elgg root {$CONFIG->path})</em>",
                 'testing:enabled'=>'Escanear test en estos plugins',

                 'testing:verbose'=>'Salida Verbose',
                 'testing:convertErrorsToExceptions'=>'Convertir errores en excepciones',
                 'testing:convertWarningsToExceptions'=>'Convertir avisos en excepciones',
                 'testing:convertNoticesToExceptions'=>'Convertir noticias en excepciones',
                 'testing:options'=>'Opciones del Tester',
                 'testing:tests'=>'Tests que están corriendon',
                 'testing:find'=>'Especificar donde buscar los tests',
                 );

add_translation("es",$spanish);
?>
