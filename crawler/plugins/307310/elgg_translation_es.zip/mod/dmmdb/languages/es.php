<?php
/**
 *      Tasks Plugin
 *      @package Tasks
 *      @author Liran Tal <liran@enginx.com>
 *      @license GNU General Public License (GPL) version 2
 *      @copyright (c) Liran Tal of Enginx 2009
 *      @link http://www.enginx.com
 **/

        $spanish = array(
                  'dmmdb:channel' => 'Canal dmmdb',
                  'dmmdb:embed_id' => 'Id del canal',
                  'dmmdb:widget:configure' => 'configure id for channel',
                  'dmmdb:widget:description' => 'Widget para embeber un canal de giss'

                  );
        add_translation("es",$spanish);
?>
