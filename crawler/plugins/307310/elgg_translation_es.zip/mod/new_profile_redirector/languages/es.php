<?php
	$spanish = array(
		// Main title
		'new_profile_redirector' => "New Profile Redirector",
		
		// Admin configuration
		'new_profile_redirector:admin:config' => "Selecciona la página donde irán los usuarios después de salvar su primer perfil:",
		'new_profile_redirector:admin:option:custom_redirect' => "Utilizar redirección propia",
	
		'new_profile_redirector:admin:custom_redirect' => "Introduce la dirección aquí",
		'new_profile_redirector:admin:custom_redirect_info' => "Para redireccionar a un usuario a un sitio o una página que tu quieras.<br/>Introduce la URL completa (incluyendo http y https) o utiliza alguno de los siguientes enlaces rápidos (incluyendo comillas):",
		
	);
	
	add_translation("es", $spanish);
?>
