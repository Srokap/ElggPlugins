<?php
	/**
	 * Elgg log rotator language pack.
	 * 
	 * @package ElggLogRotate
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	$spanish = array(
		'logrotate:period' => 'Cada cuanto debería el sistema guardar los ficheros de log?',
	
		'logrotate:weekly' => 'Una vez a la semana',
		'logrotate:monthly' => 'Una vez al mes',
		'logrotate:yearly' => 'Una vez al año',
	
		'logrotate:logrotated' => "Log rotado\n",
		'logrotate:lognotrotated' => "Error rotando log\n",
	);
					
	add_translation("es",$spanish);
?>
