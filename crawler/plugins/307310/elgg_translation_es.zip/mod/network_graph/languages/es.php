<?php
	$spanish = array(
		// main titles
		'network_graph:title' => "Gráficas",
                'network_graph:shorttitle' => "Gráfica de la red",
                'network_graph:you' => "Gráfica de tus amigas",
                'network_graph:world' => "Gráfica de toda la red"
	);
	
	add_translation("es", $spanish);
?>
