<?php

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
		'tinymce:remove' => "Mostrar/Ocultar Editor",
	
	);
					
	add_translation("es",$spanish);

?>
