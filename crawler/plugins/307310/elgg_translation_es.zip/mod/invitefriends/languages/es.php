<?php

	/**
	 * Elgg invite page
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @link http://elgg.org/
	 */

	$spanish = array(

		'friends:invite' => 'Invitar amigos',
		'invitefriends:introduction' => 'Para invitar a tus amigos a entrar en la red social, introduce sus direcciones de email en la parte de abajo. Una dirección de email para cada línea:',
		'invitefriends:message' => 'Introduce un mensaje de invitación:',
		'invitefriends:subject' => 'Invitación para %s',
	
		'invitefriends:success' => 'Las invitaciones han sido enviadas con éxito. Gracias por hacer crecer nuestra familia.',
		'invitefriends:failure' => 'Algo falla!, tus amigos ni puedes ser invitados. Intentalo de nuevo o ponte en contacto con el administrador',
	
		'invitefriends:message:default' => '
Hey,

Quiero invitarte a que entres a la red social .:ALD:. (Arte Libre Digital) en %s.',
		'invitefriends:email' => '
Has sido invitad@ a participar en %s por %s. Te ha enviado el siguiente mensaje:

%s

Para comenzar a tomar parte de la red social, haz "clicl" en el siguiente enlace:

	%s

Automáticamente el sistema te pondrá como amigo de la persona que te ha invitado, nada mas tengas creada la cuenta. El resto es comenzar a conocer gente y a compartir información. Bienvenid@ a la red social .:ALD:.',
	
	);
					
	add_translation("es",$spanish);
?>
