<?php

	$spanish = array(
	
		'shortlink:insert' => 'Insertar link acortado',
		'shortlink:modaltitle' => 'Mostrar URL via TinyURL',
		'shortlink:link' => 'URL',
		
	);
					
	add_translation("es",$spanish);

?>
