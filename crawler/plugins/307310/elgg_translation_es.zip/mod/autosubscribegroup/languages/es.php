<?php
	/**
	 * Elgg autosubscribegroup plugin
	 * This plugin allows new user to join a group when registering
	 * 
	 * @package autosubscribegroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author RONNEL Jérémy
	 * @copyright (c) Elbee 2008
	 * @link /www.notredeco.com
	 */


	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'autosubscribe' => 'Autosuscribir al grupo',
			'autosubscribe:list' => "IDs de los grupos (separado por comas)",
	);
    
	add_translation("es",$spanish);
?>
