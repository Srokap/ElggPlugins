<?php
	/**
	 * Elgg reported content plugin language pack
	 * 
	 * @package ElggReportedContent
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'item:object:reported_content' => 'Objetos compartidos',
			'reportedcontent' => 'Contenido reportado',
			'reportedcontent:this' => 'Avisar al administrador',
			'reportedcontent:none' => 'No hay contenido reportado',
			'reportedcontent:report' => 'Avisar al administrador',
			'reportedcontent:title' => 'Título de la página',
			'reportedcontent:deleted' => 'El contenido reportado ha sido borrado',
			'reportedcontent:notdeleted' => 'No podemos borrar el contenido',
			'reportedcontent:delete' => 'Borrar',
			'reportedcontent:areyousure' => 'Seguro que quieres borrarlo?',
			'reportedcontent:archive' => 'Archivar',
			'reportedcontent:archived' => 'El contenido ha sido archivado',
			'reportedcontent:visit' => 'Visitar el contenido del informe',
			'reportedcontent:by' => 'Reportado por',
			'reportedcontent:objecttitle' => 'Título del objeto',
			'reportedcontent:objecturl' => 'URL del objeto',
			'reportedcontent:reason' => 'Razón para informar',
			'reportedcontent:description' => 'Explica al administrador porqué estas reportando éste contenido:',
			'reportedcontent:address' => 'Localización del objeto',
			'reportedcontent:success' => 'El informe ha sido enviado al administrador del sitio',
			'reportedcontent:failing' => 'El informe no puede ser enviado. Intentalo de nuevo o ponte en contacto con el administrador por otros medios. Via email por ejemplo',
			'reportedcontent:report' => 'Avisar al administrador', 
			'reportedcontent:moreinfo' => 'Más información',
	
			'reportedcontent:failed' => 'El intento de reportar el contenido ha fallado. Intentalo de nuevo o ponte en contacto con el administrador por otros medios. Via email por ejemplo',
			'reportedcontent:notarchived' => 'No podemos archivar el contenido reportado. Intentalo de nuevo o ponte en contacto con el administrador',
	);
					
	add_translation("es",$spanish);
?>
