<?php
  $spanish = array(
    /**
     * identica widget details
     */
    'identica:username' => 'Introduce tu usuario de identi.ca',
    'identica:num'      => 'Número de mensajes que quieres mostrar',
    'identica:visit'    => 'Visita mi identi.ca',
    'identica:notset'   => 'Este modulo para identi.ca todavia no ha sido configurado. Haz en click en -Editar- y sigue las instrucciones',
    
    /**
     * identica widget river
     */
    'identica:river:created'  => "%s ha añadido el modulo de identi.ca",
    'identica:river:updated'  => "%s ha actualizado su modulo de identi.ca",
    'identica:river:delete'   => "%s ha borrado su modulo de identi.ca",
  );


add_translation("es",$spanish);
