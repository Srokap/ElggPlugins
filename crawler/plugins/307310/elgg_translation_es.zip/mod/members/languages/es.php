<?php

	$spanish = array(
	
		/**
		 * Site info details
		 */
		
		'members:members' => "Miembros registrados en la red social",
	    'members:online' => "Miembros online",
	    'members:active' => "Miembros registrados",
	    'members:searchtag' => "Buscar miembros por etiquetas",
	    'members:searchname' => "Buscar miembros por nombre",
	   
		'members:label:newest' => 'Nuevos',
		'members:label:popular' => 'Populares',
		'members:label:active' => 'Conectados',
		
	);
					
	add_translation("es",$spanish);

?>
