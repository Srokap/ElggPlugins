<?php

// Generado por translationbrowser 

$spanish = array( 
	 'People_you_might_know'  =>  "Personas que quizá conozcas" , 
	 'peopleyoumightknow'  =>  "Interéses Similares" ,
	 'peopleyoumightknow:seeall' => 'Ver tod@s', 
); 

add_translation('es', $spanish); 

?>
