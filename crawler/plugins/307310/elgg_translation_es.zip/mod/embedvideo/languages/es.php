<?php

  $spanish = array(
  
    'embedvideo:widget' => 'Video',
    'embedvideo:url' => 'Video URL',
    'embedvideo:title' => 'Título',
    'embedvideo:comment' => 'Comentario',
    'embedvideo:description' => 'Añadir video externos a tu perfil',
    'embedvideo:width' => 'Video con',
    'embedvideo:sites' => 'youtube, google, vimeo, metacafe, veoh, daily motion, blip.tv',
    'embedvideo:tags_instruct' => ' (las etiquetas html están permitidas)',
        
    'embedvideo:novideo' => 'Sin video',
    'embedvideo:unrecognized' => 'El enlace al video no es reconocible, Intentalo de nuevo o ponte en contacto con el administrador',
    'embedvideo:parseerror' => 'Imposible confirmrar la url %s',
    
    'embedvideo:river:updated' => "%s ha subido un nuevo video a su perfil de usuario",
    
  );
          
  add_translation("es",$spanish);

?>
