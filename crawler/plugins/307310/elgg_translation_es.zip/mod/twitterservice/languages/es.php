<?php
	$spanish = array(
		'twitterservice' => 'Servicio de twitter integrado',
		'twitterservice:postwire' => 'Quiéres que el sistema publique tus posts desde la red hacia twitter?',
		'twitterservice:twittername' => 'Usuario de twitter',
		'twitterservice:twitterpass' => 'Password de twitter <br>',
	);
					
	add_translation("es",$spanish);
?>
