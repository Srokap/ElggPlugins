<?php
/**
 *	Desktop Plugin
 *	@package Tasks
 *	@author Liran Tal <liran@enginx.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 **/

	$spanish = array(
            'desktop:desktop' => 'Escritorio',
            'desktop:edit:default' => 'Escritorio por defecto',
	);
					
	add_translation("es", $spanish);

?>
