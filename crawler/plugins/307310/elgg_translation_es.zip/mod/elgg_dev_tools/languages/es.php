<?php

// Generado por translationbrowser 

$spanish = array( 
	 'elgg_dev_tools:title'  =>  "Herramientas de desarrollo de Elgg" , 
	 'elgg_dev_tools:adminlink'  =>  "Herramientas para desarrolladores de Elgg" , 
	 'elgg_dev_tools:yes'  =>  "Si" , 
	 'elgg_dev_tools:no'  =>  "No" , 
	 'elgg_dev_tools:settings'  =>  "Configuraciones" , 
	 'elgg_dev_tools:message:successfulupdate'  =>  "Las configuraciones han sido actualizadas" , 
	 'elgg_dev_tools:settings:explanation'  =>  "Controla los parametros de desarrollo y debugging debajo. Algunos están disponibles en la sección Administración del sitio." , 
	 'elgg_dev_tools:settings:formbutton'  =>  "Settings actualizados" , 
	 'elgg_dev_tools:simplecache:question'  =>  "Utilizar cache simple?" , 
	 'elgg_dev_tools:simplecache:explanation'  =>  "La cache simple cachea los ficheros javascript y css. Generalmente lo deberías tener \"off\" cuando comiences a desarrollar un plugin." , 
	 'elgg_dev_tools:viewscache:question'  =>  "Usar vistas a la cache de filepath?" , 
	 'elgg_dev_tools:viewscache:explanation'  =>  "Las cache guarda la localización de cada vista. Si estas añadiendo vistas a un plugin, lo mejor es que lo pongas \"off\"" , 
	 'elgg_dev_tools:displayerrors:question'  =>  "Mostrar errores?
" , 
	 'elgg_dev_tools:displayerrors:explanation'  =>  "Esto controla que PHP warnings y que errores son escritos en la pantalla. Normalmente se configura en php.ini y se sobreescribe en el fichero .htaccess de Elgg. Te recomiendo dejarlo \"off\"" , 
	 'elgg_dev_tools:enablefirephp:question'  =>  "Habilitar logging FirePHP?" , 
	 'elgg_dev_tools:enablefirephp:explanation'  =>  " Habilitar la clase logging FirePHP. Muy útil para desarrollo con ajax o para mostrar información en FireBug. " , 
	 'elgg_dev_tools:enablefirephp:warning'  =>  "No tienes la extensión para Firefox FirePHP. Si es cierto, necesitas instalarla, sino pasa del mensaje :)" , 
	 'elgg_dev_tools:debug:question'  =>  "Habilitar debugger?" , 
	 'elgg_dev_tools:debug:explanation'  =>  "Ésto escribe un montón de datos en los servidores de logs que guardan los errores y tienen que ver con queries SQL. No se suele utilizar, pero quizás lo necesites en algún momento." , 
	 'elgg_dev_tools:timing:question'  =>  "Habilitar tiempo de creación de página?" , 
	 'elgg_dev_tools:timing:explanation'  =>  "Escribe un montón de datos sobre los procesos de creación de página en tu sistema de logs." , 
	 'elgg_dev_tools:showviews:question'  =>  "Mostrar vistas con elementos \"div\" ?" , 
	 'elgg_dev_tools:showviews:explanation'  =>  "Muestra todas las vista con un nombre de contenedor div para cada vista" , 
	 'elgg_dev_tools:builder'  =>  "Constructor" , 
	 'elgg_dev_tools:message:successfulbuild'  =>  "El plugin %s ha sido creado :)" , 
	 'elgg_dev_tools:error:nopluginname'  =>  "Necesitas poner un nombre al plugin" , 
	 'elgg_dev_tools:error:dir_error'  =>  "Error creando el directorio %s" , 
	 'elgg_dev_tools:error:file_error'  =>  "Error creando el fichero %s" , 
	 'elgg_dev_tools:builder:explanation'  =>  "Construye el esqueleto del plugin introduciendo los parámetros de debajo." , 
	 'elgg_dev_tools:builder:formbutton'  =>  "Construir Plugin" , 
	 'elgg_dev_tools:plugin_name'  =>  "nombre del plugin" , 
	 'elgg_dev_tools:plugin_name:explanation'  =>  "Nombre del directorio del plugin. No utilices caracteres especiales o espacios." , 
	 'elgg_dev_tools:pages'  =>  "páginas primarias" , 
	 'elgg_dev_tools:pages:explanation'  =>  "separa con comas para crear una lista de páginas primarias. Por ejemplo: index, amigos, usuarios" , 
	 'elgg_dev_tools:page_handler'  =>  "Conector de página" , 
	 'elgg_dev_tools:page_handler:explanation'  =>  "Si quieres un conector de página, introduce el identificador aquí. Por ejemplo:  \"test\" utiliza el conector http://ejemplo.com/pg/test/" , 
	 'elgg_dev_tools:actions'  =>  "Acciones" , 
	 'elgg_dev_tools:actions:explanation'  =>  "Separa con comas para listas diferentes acciones que quieres que se registren con el sistema" , 
	 'elgg_dev_tools:plugin_settings'  =>  "Configuración del plugin" , 
	 'elgg_dev_tools:plugin_settings:explanation'  =>  "Tiene el plugin alguna opción de configuración para el administrador?" , 
	 'elgg_dev_tools:user_settings'  =>  "Configuración del usuario" , 
	 'elgg_dev_tools:user_settings:explanation'  =>  "Tiene el plugin alguna opción de configuración para el usuario?" , 
	 'elgg_dev_tools:widget'  =>  "Widget" , 
	 'elgg_dev_tools:widget:explanation'  =>  "Debería el plugin tener un Widget en el perfil del usuario o en su escritorio?" , 
	 'elgg_dev_tools:css'  =>  "CSS Extendido" , 
	 'elgg_dev_tools:css:explanation'  =>  "Necesita el plugin añadir algo a los CSS?" , 
	 'elgg_dev_tools:inspect'  =>  "Inspeccionar" , 
	 'elgg_dev_tools:inspect:explanation'  =>  "Inspeccionar variables globales del entorno de Elgg"
); 

add_translation('es', $spanish); 

?>