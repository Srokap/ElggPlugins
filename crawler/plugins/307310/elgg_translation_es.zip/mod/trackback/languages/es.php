<?php

	$spanish = array(
		'trackback:wrote' => "%s ha escrito un nuevo post titulado %s en su blog %s",
		'trackback:instructions' => "Para poder usar un trackback desde tu blog externo y añadirlo al stream de Actividadesm debes utulizar la siguiente url",
	);
					
	add_translation("es",$spanish);
?>
