<?php

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'expages' => "Páginas externas",
			'expages:frontpage' => "Página principal",
			'expages:about' => "Acerca de",
			'expages:terms' => "Términos",
			'expages:privacy' => "Privacidad",
			'expages:analytics' => "Análisis",
			'expages:contact' => "Contacto",
			'expages:nopreview' => "No está disponible la previsualización",
			'expages:preview' => "Previsualizar",
			'expages:notset' => "La página no ha sido iniciada.",
			'expages:lefthand' => "Informacion del panel izquierdo",
			'expages:righthand' => "Informacion del panel derecho",
			'expages:addcontent' => "",
			'item:object:front' => 'Objetos de la pagina principal',
	
		/**
		 * Status messages
		 */
	
			'expages:posted' => "Su página ha sido enviada correctamente",
			'expages:deleted' => "Su página ha sido borrada correctamente",
	
		/**
		 * Error messages
		 */
	
			'expages:deleteerror' => "Hay problemas en el borrado de antiguas páginas. Intentalo de nuevo o ponte en contacto con el administrador",
			'expages:error' => "Bug!!!, intentalo de nuevo o ponte en contacto con el administrador detallando el problema",
	
	);
					
	add_translation("es",$spanish);

?>
