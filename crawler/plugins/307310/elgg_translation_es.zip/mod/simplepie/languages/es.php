<?php

	$spanish = array(	
      'simplepie:widget' => 'Blog',
      'simplepie:description' => 'Añadir blog externo a tu perfil',
      'simplepie:notset' => 'La url del Feed no está configurada',
      'simplepie:notfind' => 'No encuentro el feed!. Revisa la url de la configuración.',
      'simplepie:feed_url' => 'URL Feed',
      'simplepie:num_items' => 'Número de objetos',
      'simplepie:excerpt' => 'Incluir excerpt',	
      'simplepie:post_date' => 'Incluir fecha del post',	
	);
					
	add_translation("es",$spanish);

?>
