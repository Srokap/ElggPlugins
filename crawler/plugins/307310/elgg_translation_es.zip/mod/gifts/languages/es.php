<?php

$spanish = array( 
	 'gifts:menu'  =>  "Regalos" , 
	 'gifts:yourgifts'  =>  "Mis Regalos",
     'gifts:allgifts'  =>  "Todos los regalos",
     'gifts:sendgifts' => "Regalar algo",
     'gifts:friend' => "Amig@",
     'gifts:selectgift' => "Elige un regalo",
     'gifts:gift' => "Regalo",
     'gifts:send' => "Enviar regalo",     
     'gifts:object' => "%s ha recibido %s de %s",
     'gifts:river' => "%s ha recibido un regalo de %s",
     'gifts:blank' => "Elige un amig@!",
     'item:object:gift' => 'Regalos',
     'gifts:settings:number' => "Cuántos regalos quieres mostrar",
     'gifts:settings:title' =>  "Regalos"
); 
	
	add_translation("es",$spanish);
?>
