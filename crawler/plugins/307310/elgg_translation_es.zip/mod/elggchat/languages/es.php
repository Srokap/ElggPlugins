<?php

// Generado por translationbrowser 

$spanish = array( 
	 'elggchat'  =>  "Chat" , 
	 'elggchat:title'  =>  "Chat" , 
	 'elggchat:chat:profile:invite'  =>  "Invitar a chatear" , 
	 'elggchat:chat:send'  =>  "Enviar" , 
	 'elggchat:friendspicker:info'  =>  "Amig@s online" , 
	 'elggchat:chat:invite'  =>  "Invitar" , 
	 'elggchat:chat:leave'  =>  "Dejar" , 
	 'elggchat:chat:leave:confirm'  =>  "Estas segur@ de que quieres dejar la sesión?" , 
	 'elggchat:chat:info'  =>  "Info" , 
	 'elggchat:action:invite'  =>  "<b>%s</b> invita a <b>%s</b>" , 
	 'elggchat:action:invite_friends'  =>  "Invitar amigos" , 
	 'elggchat:action:leave'  =>  "<b>%s</b> deja la sesión" , 
	 'elggchat:action:join'  =>  "<b>%s</b> entra en la sala" , 
	 'elggchat:session_info:title'  =>  "Información de la sesión" , 
	 'elggchat:session_info:id'  =>  "ID:" , 
	 'elggchat:session_info:started'  =>  "comenzada:" , 
	 'elggchat:session_info:members'  =>  "Miembros" , 
	 'elggchat:session_info:invitations'  =>  "Obteniendo Invitaciones" , 
	 'elggchat:session:name:default'  =>  "Sesión de Chat (%s)" , 
	 'elggchat:session:onlinestatus'  =>  "Última acción: %s" , 
	 'elggchat:admin:settings:hours'  =>  "%s hora(s)" , 
	 'elggchat:admin:settings:maxsessionage'  =>  "Volver -idle- el tiempo m&aacute;ximo de sesi&oacute;n antes de limpiar" , 
	 'elggchat:admin:settings:chatupdateinterval'  =>  "Intervalo de Polling (segundos) de la ventana de chat" , 
	 'elggchat:admin:settings:maxchatupdateinterval'  =>  "Cada 10 intervalos de polling sin datos devueltos el intervalo de polling se multiplicar&aacute; hasta que llege a su m&aacute;ximo (segundos)" , 
	 'elggchat:admin:settings:monitorupdateinterval'  =>  "El intervalo de Polling (segundos) de la sesi&oacute;n de chat del monitor, chequear&aacute; en busca de nuevas peticiones de chat" , 
	 'elggchat:admin:settings:online_status:active'  =>  "M&aacute;ximo n&uacute;mero de segundos para poner en modo -idle- a un usuario" , 
	 'elggchat:admin:settings:online_status:inactive'  =>  "M&aacute;ximo n&uacute;mero de segundos para poner a un usuario como inactivo" , 
	 'elggchat:usersettings:enable_chat'  =>  "Habilitar la barra de Chat" , 
	 'elggchat:toolbar:minimize'  =>  "Minimizar la barra del Chat" , 
	 'elggchat:toolbar:maximize'  =>  "Maximizar la barra del Chat" , 
	 'elggchat:chat:minimize'  =>  "Minimizar"
); 

add_translation('es', $spanish); 

?>