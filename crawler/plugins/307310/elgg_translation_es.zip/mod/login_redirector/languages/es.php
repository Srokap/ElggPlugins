<?php
	$spanish = array(
		// Main title
		'login_redirector' => "Login Redirector",
		
		// Admin configuration
		'login_redirector:admin:config' => "Selecciona la página que quieres que visiten los usuarios después de loguearse:",
		'login_redirector:admin:option:profile' => "Su perfil de usuari@",
		'login_redirector:admin:option:dashboard' => "Escritorio",
		'login_redirector:admin:option:custom_redirect' => "Una dirección propia",
	
		'login_redirector:admin:useroverride' => "Pueden los usuarios sobreescribir esta característica?",
	
		'login_redirector:admin:custom_redirect' => "Introduce la redirección que quieras aquí",
		'login_redirector:admin:custom_redirect_info' => "Para redireccionar a un usuario a un sitio o una página que tú quieras, introduce la URL aquí. Utilizando esta opción quedará prohibida la sobreescritura por parte de los usuarios.<br />Introduce la URL completa (incluyendo http o https) o usa alguna de las siguientes ruta rápidas (incluyendo comillas):",
		
		'login_redirector:user:config' => "Selecciona la página a la que quieres ir después de loguearte:",
		
	);
	
	add_translation("es", $spanish);
?>
