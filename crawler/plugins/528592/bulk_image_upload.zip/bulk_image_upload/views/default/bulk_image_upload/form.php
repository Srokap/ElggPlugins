
<div id="profile_picture_form">
	<form action="<?php echo $vars['url']; ?>action/bulk_image_upload/upload" method="get" enctype="multipart/form-data">
	<?php echo elgg_view('input/securitytoken'); ?>
	<input type="hidden" name="username" value="<?php echo $currentuser->username; ?>" />
	
           
		<br /><input type="submit" class="submit_button" value="<?php echo elgg_echo('bulk_images:assign'); ?>" />
	
	</form>
</div>

