
<p>
 

<?php echo elgg_echo('bulk_images:allowoverwrite'); ?><br />
<select name="params[overwrite]">
    <option value="yes" <?php if ($vars['entity']->overwrite == 'yes') echo " selected=\"yes\" "; ?>>yes</option>
    <option value="no" <?php if ($vars['entity']->overwrite == 'no') echo " selected=\"yes\" "; ?>>no</option>
    </select>


</p>


