<?php
include_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
 admin_gatekeeper();
?>

<?php
set_context('admin');




$area2 ='<div class="contentWrapper">';
$area2 .= "<h3>".elgg_echo('bulk_images:warning')."</h3>";
$area2 .= "<p>". elgg_echo('bulk_images:notice') ."</p>";
$area2 .= "<p>" . elgg_echo('bulk_images:allowoverwrite') . "<strong style=\"font-weight:bold;\"> " . get_plugin_setting("overwrite", "bulk_image_upload") ."</strong></p>";
$area2 .= elgg_view("bulk_image_upload/form");
$area2 .='</div>';
$body = elgg_view_layout("two_column_left_sidebar", '', $area1 . $area2);
page_draw(sprintf(elgg_echo('resume:user'),$page_owner->name),$body);




?>

