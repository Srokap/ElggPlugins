<?php


// Init plugin
function bulk_image_upload_init() {

	// Load global config
	global $CONFIG;

	// Add menu to logged user
      

	// Extend profile menu to include bulk_image_upload
	
}




//Config bulk_image_upload page
function bulk_image_upload_pagesetup() {
	if (get_context() == 'admin' && isadminloggedin()) {
			global $CONFIG;
			add_submenu_item(elgg_echo('bulk_images'), $CONFIG->wwwroot . 'pg/bulk_image_uploads/');
		}
	
	
               


}

function bulk_image_upload_page_handler($page) {
	// The first component of a publication URL is the username
	if (isset($page[0])) {
		set_input('username',$page[0]);
	}
	if (isset($page[2])) {
		set_input('param2',$page[2]);
	}
	if (isset($page[3])) {
		set_input('param3',$page[3]);
	}
	if (isset($page[1])) {
		switch($page[1]) {

		}

	} else {
		@include(dirname(__FILE__) . "/index.php");
		return true;
	}

	return false;



}

// ********************REGISTER ACTIONS ******************

register_action("bulk_image_upload/upload", false, $CONFIG->pluginspath . "bulk_image_upload/actions/upload.php");

// *********************************************

// Register a page handler
register_page_handler('bulk_image_uploads','bulk_image_upload_page_handler');


// Regiser event handlers

register_elgg_event_handler('pagesetup','system','bulk_image_upload_pagesetup');
register_elgg_event_handler('init','system','bulk_image_upload_init');



?>