<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
admin_gatekeeper();
global $CONFIG;


/*
 * Function used to validate if an image exist with a given extension
 */

function validate_image($archivo) {


    $medium = get_resized_image_from_existing_file($archivo, 100, 100, true);


    if ($medium == false
    ) {

        return false;
    } else {
        return true;
    }
}
?>

<?php

$user = page_owner_entity();


if (!$user

    )$user = $_SESSION['user'];







//$logFile = $CONFIG->pluginspath . 'bulk_image_upload/log/log.txt';
//$log = fopen($logFile, 'w') or die("can't open file");
//fwrite($log, elgg_echo("START OF LOG_FILE\r\n\r\n"));




//Get the users
$users = get_entities("user", "", 0, "", 0);
$cont = 0;

//For each user, check if there is an image file to assign
foreach ($users as $userx) {




    //fwrite($log, elgg_echo("\r\nGetting FILES for USER: " . $userx->username . "\r\n"));
    // $log->write("Getting FILES for USER: " . $userx->username);

    $archivo = $CONFIG->pluginspath . 'bulk_image_upload/tmp/' . $userx->username . ".jpg";

    // validate if the user already has an image
    $filecheck = new ElggFile();
    $filecheck->owner_guid = $userx->getGUID();
    $filecheck->setFilename("profile/" . $userx->username . "medium.jpg");

    // validate if image overwriting is allowed
    $overwrite = get_plugin_setting("overwrite", "bulk_image_upload");
    if ($filecheck->exists() == true && $overwrite == 'no') {

      //  fwrite($log, elgg_echo("Image already exist\r\n"));
    } else {
        //Validate that the image exist with a given extension, else change the extension
        $valid_image = validate_image($archivo);
        //JPG
        if ($valid_image == false) {
        //    fwrite($log, elgg_echo("JPG image does not exist\r\n"));
            //$log->write("Valid file: " . $archivo . " does not exist");
            $archivo = $CONFIG->pluginspath . 'bulk_image_upload/tmp/' . $userx->username . ".gif";
            $valid_image = validate_image($archivo);
        }
        //GIF
        if ($valid_image == false) {
          //  fwrite($log, elgg_echo("GIF image does not exist\r\n"));
            //$log->write("Valid file: " . $archivo . " does not exist");
            $archivo = $CONFIG->pluginspath . 'bulk_image_upload/tmp/' . $userx->username . ".png";
            $valid_image = validate_image($archivo);
        }
        //PGN
        if ($valid_image == false) {
            //fwrite($log, elgg_echo("PNG image does not exist\r\n"));
            //fwrite($log, elgg_echo("No IMAGES for given USER\r\n"));
            //$log->write("Valid file: " . $archivo . " does not exist");
            //$log->write("No IMAGES for USER: " . $userx->username);
        } else {



            $topbar = get_resized_image_from_existing_file($archivo, 16, 16, true);
            $tiny = get_resized_image_from_existing_file($archivo, 25, 25, true);
            $small = get_resized_image_from_existing_file($archivo, 40, 40, true);
            $medium = get_resized_image_from_existing_file($archivo, 100, 100, true);
            $large = get_resized_image_from_existing_file($archivo, 200, 200);
            $master = get_resized_image_from_existing_file($archivo, 550, 550);


            $filehandler = new ElggFile();
            $filehandler->owner_guid = $userx->getGUID();
            $filehandler->setFilename("profile/" . $userx->username . "large.jpg");
            $filehandler->open("write");
            $filehandler->write($large);
            $filehandler->close();
            $filehandler->setFilename("profile/" . $userx->username . "medium.jpg");
            $filehandler->open("write");
            $filehandler->write($medium);
            $filehandler->close();
            $filehandler->setFilename("profile/" . $userx->username . "small.jpg");
            $filehandler->open("write");
            $filehandler->write($small);
            $filehandler->close();
            $filehandler->setFilename("profile/" . $userx->username . "tiny.jpg");
            $filehandler->open("write");
            $filehandler->write($tiny);
            $filehandler->close();
            $filehandler->setFilename("profile/" . $userx->username . "topbar.jpg");
            $filehandler->open("write");
            $filehandler->write($topbar);
            $filehandler->close();
            $filehandler->setFilename("profile/" . $userx->username . "master.jpg");
            $filehandler->open("write");
            $filehandler->write($master);
            $filehandler->close();

            $user->icontime = time();

            fwrite($log, elgg_echo("Picture updated for user\r\n"));
            $cont++;
        }
    }
}

//fclose($log);
system_message(sprintf(elgg_echo('bulk_images:succes'),$cont));


//forward the user back to the upload page to crop



forward($CONFIG->wwwroot.'pg/admin/');
?>

