<?php
	
	

	$english = array(

	

		'bulk_images' => "Bulk profile images upload",
		'bulk_images:warning' => "WARNING!",
                'bulk_images:notice' => "<br />Remember to put image files in your /elgg_directory/mod/bulk_image_upload/tmp/  directory (jpg, gif & png formats supported) named with the usernames from the users that you want to change/update profile pictures.<br /><br />Please check plugin settings before proceeding:",
                'bulk_images:allowoverwrite' => "Allow user image overwrite:",
                'bulk_images:assign' => "Assign images",
                'bulk_images:succes' => "Succesfully updated  %s user images\r\n",


	
	);

	add_translation("en",$english);