<?php

	$english = array(
	
		'help' => "Online Games",
		
		'onlinegames_frameme:onlinegames' => "Online Games",
	);

	add_translation("en",$english);

?>
