Instructions:

   1. Download plugin
   2. Put it in directory ELGG_ROOT/mod
   3. Enable it in "Tool Administration"
   4. Check permission to directory ELGG_ROOT/mod/translationbrowser/data
   5. Open "Translation Browser" as admin
   6. Select "Language"
   7. Select file to edit
   8. Save

