<?php

	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'updates' => "Classroom Updates",
			'updates:add' => "update something",
			'updates:read' => "%s's updated items",
			'updates:friends' => "Friends' Classroom Updates",
			'updates:everyone' => "All site Classroom Updates",
			'updates:this' => "Add an update",
			'updates:this:group' => "update in %s",

			'updates:more' => "More",
			'updates:shareditem' => "update",
			'updates:with' => "Share with",
			'updates:new' => "A new updated item",
			'updates:via' => "via updates",
	
			'updates:delete:confirm' => "Are you sure you want to delete this resource?",
	
			'updates:numbertodisplay' => 'Number of updated items to display',
	
			'updates:shared' => "updated",
			'updates:visit' => "Visit resource",
			'updates:recent' => "Recent Classroom Updates",
	
			'updates:river:created' => '%s created a classroom update named: ',
			'updates:river:annotate' => 'a comment on this classroom update item: ',
			'updates:river:item' => 'an item',
	
			'item:object:updates' => 'Classroom Updates',
	
			'updates:group' => 'Group updates',
			'updates:enableupdates' => 'Enable group updates',
	
		/**
		 * Classroom text options
		 */
		
			'updates:class:k' => "Kindergarten Updates",
			'updates:class:b' => "Beginner's Updates",
			'updates:class:1' => "Grade One Updates",
			'updates:class:2' => "Grade Two Updates",
			'updates:class:3' => "Grade Three Updates",
			'updates:class:4' => "Grade Four Updates",
			'updates:class:5' => "Grade Five Updates",
			'updates:class:6' => "Grade Six Updates",
	        'updates:class:7' => "Grade Seven Updates",
	        'updates:class:8' => "Grade Eight Updates",
	        
	        'updates:class:current:ke' => "Current Kindergarten East Update",
	        'updates:class:current:kw' => "Current Kindergarten West Update",
			'updates:class:current:bn' => "Current Beginner's North Update",
			'updates:class:current:bs' => "Current Beginner's South Update",
			'updates:class:current:1s' => "Current Grade One South Update",
			'updates:class:current:1n' => "Current Grade One North Update",
			'updates:class:current:2e' => "Current Grade Two East Update",
			'updates:class:current:2w' => "Current Grade Two West Update",
			'updates:class:current:31' => "Current Grade Three 1 Update",
			'updates:class:current:32' => "Current Grade Three 2 Update",
			'updates:class:current:33' => "Current Grade Three 3 Update",
			'updates:class:current:41' => "Current Grade Four 1 Update",
			'updates:class:current:42' => "Current Grade Four 2 Update",
			'updates:class:current:43' => "Current Grade Four 3 Update",
			'updates:class:current:51' => "Current Grade Five 1 Update",
			'updates:class:current:52' => "Current Grade Five 2 Update",
			'updates:class:current:53' => "Current Grade Five 3 Update",
			'updates:class:current:61' => "Current Grade Six 1 Update",
			'updates:class:current:62' => "Current Grade Six 2 Update",
			'updates:class:current:63' => "Current Grade Six 3 Update",
			'updates:class:current:64' => "Current Grade Six 4 Update",
	        'updates:class:current:71' => "Current Grade Seven 1 Update",
	        'updates:class:current:72' => "Current Grade Seven 2 Update",
	        'updates:class:current:73' => "Current Grade Seven 3 Update",
	        'updates:class:current:74' => "Current Grade Seven 4 Update",
	        'updates:class:current:81' => "Current Grade Eight 1 Update",
	        'updates:class:current:82' => "Current Grade Eight 2 Update",
	        'updates:class:current:83' => "Current Grade Eight 3 Update",
	        'updates:class:current:84' => "Current Grade Eight 4 Update",
	        
	        'updates:class:past' => "Past Updates",
	        
	        
	        'updates:bnteach' => "Beginner's North Teachers",
	        'updates:bsteach' => "Beginner's South Teachers",
	        'updates:keteach' => "Kindergarten East Teachers",
	        'updates:kwteach' => "Kindergarten West Teachers",
	        'updates:osteach' => "One South Teachers",
	        'updates:onteach' => "One North Teachers",
	        'updates:teteach' => "Two East Teachers",
	        'updates:twteach' => "Two West Teachers",
	        'updates:t1teach' => "Three 1 Teachers",
	        'updates:t2teach' => "Three 2 Teachers",
	        'updates:t3teach' => "Three 3 Teachers",
	        'updates:f1teach' => "Four 1 Teachers",
	        'updates:f2teach' => "Four 2 Teachers",
	        'updates:f3teach' => "Four 3 Teachers",
	        'updates:ff1teach' => "Five 1 Teachers",
	        'updates:ff2teach' => "Five 2 Teachers",
	        'updates:ff3teach' => "Five 3 Teachers",
	        'updates:s1teach' => "Six 1 Teachers",
	        'updates:s2teach' => "Six 2 Teachers",
	        'updates:s3teach' => "Six 3 Teachers",
	        'updates:s4teach' => "Six 4 Teachers",
	        'updates:ss1teach' => "Seven 1 Teachers",
	        'updates:ss2teach' => "Seven 2 Teachers",
	        'updates:ss3teach' => "Seven 3 Teachers",
	        'updates:ss4teach' => "Seven 4 Teachers",
	        'updates:e1teach' => "Eight 1 Teachers",
	        'updates:e2teach' => "Eight 2 Teachers",
	        'updates:e3teach' => "Eight 3 Teachers",
	        'updates:e4teach' => "Eight 4 Teachers",
	    
		
		/**
		 * More text
		 */
		    
		    'updates:widget:description' => 
		            "This widget is designed for your dashboard and will show you the latest items in your updates inbox.",
	
			'updates:updatelet:description' =>
					"The updates updatelet allows you to share any resource you find on the web with your friends, or just update it for yourself. To use it, simply drag the following button to your browser's links bar:",

	        'updates:updatelet:descriptionie' =>
					"If you are using Internet Explorer, you will need to right click on the updatelet icon, select 'add to favorites', and then the Links bar.",

			'updates:updatelet:description:conclusion' =>
					"You can then save any page you visit by clicking it at any time.",
	
		/**
		 * Status messages
		 */
	
			'updates:save:success' => "Your item was successfully updated.",
			'updates:delete:success' => "Your updated item was successfully deleted.",
	
		/**
		 * Error messages
		 */
	
			'updates:save:failed' => "Your updated item could not be saved. Please try again.",
			'updates:delete:failed' => "Your updated item could not be deleted. Please try again.",
	
			'updates:add' => "Add an update",
			
			 'updates:start_date' => "Start",
			 'updates:end_date' => "End",
			 'updates:percent_done' => " done",
			 'updates:work_remaining' => "Remain.",
			 
		
			 'updates:update_type' => 'Classroom:',
			 'updates:status' => 'Status',
			 'updates:assigned_to' => 'Main Teacher',
			 
			 'updates:update_type_'=>"",
			 'updates:update_type_0'=>"Beginners South",
			 'updates:update_type_1'=>"Beginners North",
			 'updates:update_type_2'=>"Kindergarten East",
			 'updates:update_type_3'=>"Kindergarten West",
			 'updates:update_type_4'=>"One South",
			 'updates:update_type_5'=>"One North",
			 'updates:update_type_6'=>"Two West",
			 'updates:update_type_7'=>"Two East",
			 'updates:update_type_8'=>"III DeloRusso",
			 'updates:update_type_9'=>"III Hopkins",
			 'updates:update_type_10'=>"III Jones/Leahy",
			 'updates:update_type_11'=>"IV One",
			 'updates:update_type_12'=>"IV Two",
			 'updates:update_type_13'=>"IV Three",
			 'updates:update_type_14'=>"V One",
			 'updates:update_type_15'=>"V Two",
			 'updates:update_type_16'=>"V Three",
			 'updates:update_type_17'=>"VI One",
			 'updates:update_type_18'=>"VI Two",
			 'updates:update_type_19'=>"VI Three",
			 'updates:update_type_20'=>"VI Four",
			 'updates:update_type_21'=>"VII One",
			 'updates:update_type_22'=>"VII Two",
			 'updates:update_type_23'=>"VII Three",
			 'updates:update_type_24'=>"VII Four",
			 'updates:update_type_25'=>"VIII One",
			 'updates:update_type_26'=>"VIII Two",
			 'updates:update_type_27'=>"VIII Three",
			 'updates:update_type_28'=>"VIII Four",
			 'updates:update_type_29'=>"Studio 1",
			 'updates:update_type_30'=>"Studio 2",
			 'updates:update_type_31'=>"Science 1",
			 'updates:update_type_32'=>"Science 2",
			 'updates:update_type_33'=>"Science 3",
			 'updates:update_type_34'=>"Science 4",
			 'updates:update_type_35'=>"Lower School Music",
			 'updates:update_type_36'=>"Middle School Music",
			 'updates:update_type_37'=>"Shop 1",
			 'updates:update_type_38'=>"Shop 2",
			 'updates:update_type_39'=>"Lower School Athletics",
			 'updates:update_type_40'=>"Middle School Athletics",
			 'updates:update_type_41'=>"Library",
			 'updates:update_type_42'=>"Entire School",
			 'updates:update_type_43'=>"",
			 
			 'updates:update_status_'=>"",
			 'updates:update_status_0'=>"Current",
			 'updates:update_status_1'=>"Completed",
			 'updates:update_status_2'=>"Closed",
			 
			 'updates:update_percent_done_'=>"0%",
			 'updates:update_percent_done_0'=>"0%",
			 'updates:update_percent_done_1'=>"25%",
			 'updates:update_percent_done_2'=>"50%",
			 'updates:update_percent_done_3'=>"75%",
			 'updates:update_percent_done_4'=>"100%",
			 
			 'updates:access' => "Access",
			 'updates:write_access' => "Write access",
			 
			 'updates:updatesboard'=>"updatesBoard",
			 'updates:updatesmanage'=>"Details",
			 'updates:updatesmanageone'=>"Details for an update",
	);
					
	add_translation("en",$english);

?>