<?php

	/**
	 * Classroom Updates Plugin
	 * @package updates
	 * @Original author Justin Kenyon
	 * website http://elgg.justinkenyon.com
	 * elgg.justinkenyon.com
	 */

		$guid = get_input('update_guid',0);
		if ($entity = get_entity($guid)) {
			
			if ($entity->canEdit()) {
				
				if ($entity->delete()) {
					
					system_message(elgg_echo("updates:delete:success"));
					forward("pg/updates/");					
					
				}
				
			}
			
		}
		
		register_error(elgg_echo("updates:delete:failed"));
		forward("pg/updates/");

?>