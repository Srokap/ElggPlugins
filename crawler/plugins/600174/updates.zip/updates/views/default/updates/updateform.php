<?php

	/**
	 * Classroom Updates Plugin
	 * @package updates
	 * @Original author Justin Kenyon
	 * website http://elgg.justinkenyon.com
	 * elgg.justinkenyon.com
	 */

	// Have we been supplied with an entity?
		if (isset($vars['entity'])) {
			
			$guid = $vars['entity']->getGUID();
			$title = $vars['entity']->title;
			$description = $vars['entity']->description;
			
			$tags = $vars['entity']->tags;
			$access_id = $vars['entity']->access_id;
			
			$owner = $vars['entity']->getOwnerEntity();
			$highlight = 'default';
			
			$start_date = $vars['entity']->start_date;
			$end_date = $vars['entity']->end_date;
			$update_type = $vars['entity']->update_type;
			$status = $vars['entity']->status;
			$assigned_to = $vars['entity']->assigned_to;
			$percent_done = $vars['entity']->percent_done;
			$work_remaining = $vars['entity']->work_remaining;
			$write_access_id = $vars['entity']->write_access_id;
			
			$container_id = $vars['entity']->getContainer();
			$container = get_entity($container_id);

			
		} else {
			
			$guid = 0;
			$title = get_input('title',"");
			$description = "";

			$highlight = 'all';
			
			if ($address == "previous")
				$address = $_SERVER['HTTP_REFERER'];
			$tags = array();
			
			// bootstrap the access permissions in the entity array so we can use defaults
			if (defined('ACCESS_DEFAULT')) {
				$vars['entity']->access_id = ACCESS_DEFAULT;
				$vars['entity']->write_access_id = ACCESS_DEFAULT;
			} else {
				$vars['entity']->access_id = 0;
				$vars['entity']->write_access_id = 0;
			}
			
			$shares = array();
			$owner = $vars['user'];
			
			//$container_id = $vars['container_guid'];
			$container_id = get_input('container_guid');
			$container = get_entity($container_id);
			
		}
		
	
?>
<?php
		$assign_list = array(
								elgg_echo('updates:update_type_0'),
								elgg_echo('updates:update_type_1'),
								elgg_echo('updates:update_type_2'),
								elgg_echo('updates:update_type_3'),
								elgg_echo('updates:update_type_4'),
								elgg_echo('updates:update_type_5'),
								elgg_echo('updates:update_type_6'),
								elgg_echo('updates:update_type_7'),
								elgg_echo('updates:update_type_8'),
								elgg_echo('updates:update_type_9'),
								elgg_echo('updates:update_type_10'),
								elgg_echo('updates:update_type_11'),
								elgg_echo('updates:update_type_12'),
								elgg_echo('updates:update_type_13'),
								elgg_echo('updates:update_type_14'),
								elgg_echo('updates:update_type_15'),
								elgg_echo('updates:update_type_16'),
								elgg_echo('updates:update_type_17'),
								elgg_echo('updates:update_type_18'),
								elgg_echo('updates:update_type_19'),
								elgg_echo('updates:update_type_20'),
								elgg_echo('updates:update_type_21'),
								elgg_echo('updates:update_type_22'),
								elgg_echo('updates:update_type_23'),
								elgg_echo('updates:update_type_24'),
								elgg_echo('updates:update_type_25'),
								elgg_echo('updates:update_type_26'),
								elgg_echo('updates:update_type_27'),
								elgg_echo('updates:update_type_28'),
								elgg_echo('updates:update_type_29'),
								elgg_echo('updates:update_type_30'),
								elgg_echo('updates:update_type_31'),
								elgg_echo('updates:update_type_32'),
								elgg_echo('updates:update_type_33'),
								elgg_echo('updates:update_type_34'),
								elgg_echo('updates:update_type_35'),
								elgg_echo('updates:update_type_36'),
								elgg_echo('updates:update_type_37'),
								elgg_echo('updates:update_type_38'),
								elgg_echo('updates:update_type_39'),
								elgg_echo('updates:update_type_40'),
								elgg_echo('updates:update_type_41'),
								elgg_echo('updates:update_type_42'),
								elgg_echo('updates:update_type_43')
							);		
?>		
		<table class="updates" width="100%">
			<tr>
				<td width="33%">
					<label>
						<?php echo elgg_echo('updates:start_date'); ?>
						<?php
		
								echo elgg_view('input/text',array(
										'internalname' => 'start_date',
										'value' => $start_date,
										'class' => 'tiny date',
								)); 
						
						?>
					</label>
					</td>
					<td width="33%">
					<label>
						<?php 	echo elgg_echo('updates:end_date'); ?>
						<?php
		
								echo elgg_view('input/text',array(
										'internalname' => 'end_date',
										'value' => $end_date,
										'class' => 'tiny date',
		
								)); 
						
						?>
					</label>
					</td>
					<td width="30%">
					<label>
				<?php /* echo elgg_echo('updates:status'); */?>	
				<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'status',
							'options_values' => array( '0' => elgg_echo('updates:update_status_0'),
													   '1' => elgg_echo('updates:update_status_1'),
							                         ),
							'value' => 0
						));
				?>
				</label>
					<label>
						
						<?php
						/**
							echo elgg_echo('updates:percent_done'); 
							
						*/
						?>
						<?php
						/**
							echo elgg_view('input/pulldown', array(
								'internalname' => 'percent_done',
								'options_values' => array( '0' => elgg_echo('updates:update_percent_done_0'),
															   '1' => elgg_echo('updates:update_percent_done_1'),
															   '2' => elgg_echo('updates:update_percent_done_2'),
						                                	   '3' => elgg_echo('updates:update_percent_done_3'),
									                           '4' => elgg_echo('updates:update_percent_done_4'),
									                         ),
									'value' => $percent_done
								));
						*/
						?>
					</label>
					<label>
						<?php 
						/**
						echo elgg_echo('updates:work_remaining'); 
						*/
						?>
						<?php
						/*
								echo elgg_view('input/text',array(
										'internalname' => 'work_remaining',
										'value' => $work_remaining,
										'class' => 'number',
								)); 
						
						*/
						?>
					</label>
					</td>
				</tr>
				<tr>
				<td width="33%">
				<label>
				<?php
	
				
				
	
	//Beginners North Teachers
	
	$bnname = "Beginners North";
	
	$bn1 = get_plugin_setting('bnteach1', 'updates');
	$bn2 = get_plugin_setting('bnteach2', 'updates');
	$bn3 = get_plugin_setting('bnteach3', 'updates');
	$bn4 = get_plugin_setting('bnteach4', 'updates');
	
	//Beginners South Teachers
	
	$bsname = "Beginners South";
	
	$bs1 = get_plugin_setting('bsteach1', 'updates');
	$bs2 = get_plugin_setting('bsteach2', 'updates');
	$bs3 = get_plugin_setting('bsteach3', 'updates');
	$bs4 = get_plugin_setting('bsteach4', 'updates');
	
	//Kindergarten East Teachers
	
	$kename = "Kindergarten East";
	
	$ke1 = get_plugin_setting('keteach1', 'updates');
	$ke2 = get_plugin_setting('keteach2', 'updates');
	$ke3 = get_plugin_setting('keteach3', 'updates');
	$ke4 = get_plugin_setting('keteach4', 'updates');
	
	//Kindergarten West Teachers
	
	$kwname = "Kindergarten West";
	
	$ke1 = get_plugin_setting('kwteach1', 'updates');
	$ke2 = get_plugin_setting('kwteach2', 'updates');
	$ke3 = get_plugin_setting('kwteach3', 'updates');
	$ke4 = get_plugin_setting('kwteach4', 'updates');
	
	//One North Teachers
	
	$onname = "One North";
	
	$on1 = get_plugin_setting('onteach1', 'updates');
	$on2 = get_plugin_setting('onteach2', 'updates');
	$on3 = get_plugin_setting('onteach3', 'updates');
	$on4 = get_plugin_setting('onteach4', 'updates');
	
	//One South Teachers
	
	$osname = "One South";
	
	$os1 = get_plugin_setting('osteach1', 'updates');
	$os2 = get_plugin_setting('osteach2', 'updates');
	$os3 = get_plugin_setting('osteach3', 'updates');
	$os4 = get_plugin_setting('osteach4', 'updates');
	
	//Two West Teachers
	
	$twname = "Two West";
	
	$tw1 = get_plugin_setting('twteach1', 'updates');
	$tw2 = get_plugin_setting('twteach2', 'updates');
	$tw3 = get_plugin_setting('twteach3', 'updates');
	$tw4 = get_plugin_setting('twteach4', 'updates');
	
	//Two East Teachers
	
	$tename = "Two East";
	
	$te1 = get_plugin_setting('teteach1', 'updates');
	$te2 = get_plugin_setting('teteach2', 'updates');
	$te3 = get_plugin_setting('teteach3', 'updates');
	$te4 = get_plugin_setting('teteach4', 'updates');
	
	//31 Teachers
	
	$t31name = "Grade 3 Classroom 1";
	
	$t311 = get_plugin_setting('t1teach1', 'updates');
	$t312 = get_plugin_setting('t1teach2', 'updates');
	$t313 = get_plugin_setting('t1teach3', 'updates');
	$t314 = get_plugin_setting('t1teach4', 'updates');
	
	//32 Teachers
	
	$t32name = "Grade 3 Classroom 2";
	
	$t321 = get_plugin_setting('t2teach1', 'updates');
	$t322 = get_plugin_setting('t2teach2', 'updates');
	$t323 = get_plugin_setting('t2teach3', 'updates');
	$t324 = get_plugin_setting('t2teach4', 'updates');
	
	//33 Teachers
	
	$t33name = "Grade 3 Classroom 3";
	
	$t331 = get_plugin_setting('t3teach1', 'updates');
	$t332 = get_plugin_setting('t3teach2', 'updates');
	$t333 = get_plugin_setting('t3teach3', 'updates');
	$t334 = get_plugin_setting('t3teach4', 'updates');
	
	//41 Teachers
	
	$t34name = "Grade 4 Classroom 1";
	
	$t411 = get_plugin_setting('f1teach1', 'updates');
	$t412 = get_plugin_setting('f1teach2', 'updates');
	$t413 = get_plugin_setting('f1teach3', 'updates');
	$t414 = get_plugin_setting('f1teach4', 'updates');
	
	//42 Teachers
	
	$t42name = "Grade 4 Classroom 2";
	
	$t421 = get_plugin_setting('f2teach1', 'updates');
	$t422 = get_plugin_setting('f2teach2', 'updates');
	$t423 = get_plugin_setting('f2teach3', 'updates');
	$t424 = get_plugin_setting('f2teach4', 'updates');
	
	//43 Teachers
	
	$t43name = "Grade 4 Classroom 3";
	
	$t431 = get_plugin_setting('f3teach1', 'updates');
	$t432 = get_plugin_setting('f3teach2', 'updates');
	$t433 = get_plugin_setting('f3teach3', 'updates');
	$t434 = get_plugin_setting('f3teach4', 'updates');
	
	//51 Teachers
	
	$t51name = "Grade 5 Classroom 1";
	
	$t511 = get_plugin_setting('ff1teach1', 'updates');
	$t512 = get_plugin_setting('ff1teach2', 'updates');
	$t513 = get_plugin_setting('ff1teach3', 'updates');
	$t514 = get_plugin_setting('ff1teach4', 'updates');
	
	//52 Teachers
	
	$t52name = "Grade 5 Classroom 2";
	
	$t521 = get_plugin_setting('ff2teach1', 'updates');
	$t522 = get_plugin_setting('ff2teach2', 'updates');
	$t523 = get_plugin_setting('ff2teach3', 'updates');
	$t524 = get_plugin_setting('ff2teach4', 'updates');
	
	//53 Teachers
	
	$t53name = "Grade 5 Classroom 3";
	
	$t531 = get_plugin_setting('ff3teach1', 'updates');
	$t532 = get_plugin_setting('ff3teach2', 'updates');
	$t533 = get_plugin_setting('ff3teach3', 'updates');
	$t534 = get_plugin_setting('ff3teach4', 'updates');
	
	//61 Teachers
	
	$t61name = "Grade 6 Classroom 1";
	
	$t611 = get_plugin_setting('s1teach1', 'updates');
	$t612 = get_plugin_setting('s1teach2', 'updates');
	$t613 = get_plugin_setting('s1teach3', 'updates');
	$t614 = get_plugin_setting('s1teach4', 'updates');
	
	//62 Teachers
	
	$t62name = "Grade 6 Classroom 2";
	
	$t621 = get_plugin_setting('s2teach1', 'updates');
	$t622 = get_plugin_setting('s2teach2', 'updates');
	$t623 = get_plugin_setting('s2teach3', 'updates');
	$t624 = get_plugin_setting('s2teach4', 'updates');
	
	//63 Teachers
	
	$t63name = "Grade 6 Classroom 3";
	
	$t631 = get_plugin_setting('s3teach1', 'updates');
	$t632 = get_plugin_setting('s3teach2', 'updates');
	$t633 = get_plugin_setting('s3teach3', 'updates');
	$t634 = get_plugin_setting('s3teach4', 'updates');
	
	//64 Teachers
	
	$t64name = "Grade 6 Classroom 4";
	
	$t641 = get_plugin_setting('s4teach1', 'updates');
	$t642 = get_plugin_setting('s4teach2', 'updates');
	$t643 = get_plugin_setting('s4teach3', 'updates');
	$t644 = get_plugin_setting('s4teach4', 'updates');
	
	//71 Teachers
	
	$t71name = "Grade 7 Classroom 1";
	
	$t711 = get_plugin_setting('ss1teach1', 'updates');
	$t712 = get_plugin_setting('ss1teach2', 'updates');
	$t713 = get_plugin_setting('ss1teach3', 'updates');
	$t714 = get_plugin_setting('ss1teach4', 'updates');
	
	//72 Teachers
	
	$t72name = "Grade 7 Classroom 2";
	
	$t721 = get_plugin_setting('ss2teach1', 'updates');
	$t722 = get_plugin_setting('ss2teach2', 'updates');
	$t723 = get_plugin_setting('ss2teach3', 'updates');
	$t724 = get_plugin_setting('ss2teach4', 'updates');
	
	//73 Teachers
	
	$t73name = "Grade 7 Classroom 3";
	
	$t731 = get_plugin_setting('ss3teach1', 'updates');
	$t732 = get_plugin_setting('ss3teach2', 'updates');
	$t733 = get_plugin_setting('ss3teach3', 'updates');
	$t734 = get_plugin_setting('ss3teach4', 'updates');
	
	//74 Teachers
	
	$t74name = "Grade 7 Classroom 4";
	
	$t741 = get_plugin_setting('ss4teach1', 'updates');
	$t742 = get_plugin_setting('ss4teach2', 'updates');
	$t743 = get_plugin_setting('ss4teach3', 'updates');
	$t744 = get_plugin_setting('ss4teach4', 'updates');
	
	//81 Teachers
	
	$t81name = "Grade 8 Classroom 1";
	
	$t811 = get_plugin_setting('e1teach1', 'updates');
	$t812 = get_plugin_setting('e1teach2', 'updates');
	$t813 = get_plugin_setting('e1teach3', 'updates');
	$t814 = get_plugin_setting('e1teach4', 'updates');
	
	//82 Teachers
	
	$t82name = "Grade 8 Classroom 2";
	
	$t821 = get_plugin_setting('e2teach1', 'updates');
	$t822 = get_plugin_setting('e2teach2', 'updates');
	$t823 = get_plugin_setting('e2teach3', 'updates');
	$t824 = get_plugin_setting('e2teach4', 'updates');
	
	//83 Teachers
	
	$t83name = "Grade 8 Classroom 3";
	
	$t831 = get_plugin_setting('e3teach1', 'updates');
	$t832 = get_plugin_setting('e3teach2', 'updates');
	$t833 = get_plugin_setting('e3teach3', 'updates');
	$t834 = get_plugin_setting('e3teach4', 'updates');
	
	//84 Teachers
	
	$t84name = "Grade 8 Classroom 4";
	
	$t841 = get_plugin_setting('e4teach1', 'updates');
	$t842 = get_plugin_setting('e4teach2', 'updates');
	$t843 = get_plugin_setting('e4teach3', 'updates');
	$t844 = get_plugin_setting('e4teach4', 'updates');
	
	
	
	
	// DO NOT EDIT BELOW THIS LINE, UNLESS YOU KNOW WHAT YOU ARE DOING!
	
	$current_user_id = $_SESSION['id'];
	
	switch ($current_user_id) {
    
    case $bn1:
    case $bn2:
    case $bn3:
    case $bn4:
    	$picked_value = 1;
        break;
    
    case $bs1:
    case $bs2:
    case $bs3:
    case $bs4:
        $picked_value = 0;
       
        break;
    
    case $ke1:
    case $ke2:
    case $ke3:
    case $ke4:
        $picked_value = 2;
	   
        break;
        
    case $kw1:
    case $kw2:
    case $kw3:
    case $kw4:
        $picked_value = 3;
	  
        break;
    
    case $on1:
    case $on2:
    case $on3:
    case $on4:
        $picked_value = 5;
       
        break;
    
    case $os1:
    case $os2:
    case $os3:
    case $os4:
        $picked_value = 4;
       
        break;
    
    case $tw1:
    case $tw2:
    case $tw3:
    case $tw4:
        $picked_value = 6;
       
       
        break;
        
    case $te1:
    case $te2:
    case $te3:
    case $te4:
        $picked_value = 7;
       
        break;
        
    case $t311:
    case $t312:
    case $t313:
    case $t314:
        $picked_value = 8;
       
        break;
    
    case $t321:
    case $t322:
    case $t323:
    case $t324:
        $picked_value = 9;
		
        break;
    
    case $t331:
    case $t332:
    case $t333:
    case $t334:
        $picked_value = 10;
		
        break;
    
    case $t411:
    case $t412:
    case $t413:
    case $t414:
        $picked_value = 11;
		
        break;
    
    case $t421:
    case $t422:
    case $t423:
    case $t424:
        $picked_value = 12;
		
        break;
    
    case $t431:
    case $t432:
    case $t433:
    case $t434:
    	$picked_value = 13;
		
        break;
    
    case $t511:
    case $t512:
    case $t513:
    case $t514:
        $picked_value = 14;
		
        break;
    
    case $t521:
    case $t522:
    case $t523:
    case $t524:
        $picked_value = 15;
		
        break;
    
    case $t531:
    case $t532:
    case $t533:
    case $t534:
        $picked_value = 16;
		
        break;
    
    case $t611:
    case $t612:
    case $t613:
    case $t614:
        $picked_value = 17;
		
        break;
    
    case $t621:
    case $t622:
    case $t623:
    case $t624:
        $picked_value = 18;
		
        break;
    
    case $t631:
    case $t632:
    case $t633:
    case $t634:
        $picked_value = 19;
		
        break;
    
    case $t641:
    case $t642:
    case $t643:
    case $t644:
        $picked_value = 20;
		
        break;
    
    case $t711:
    case $t712:
    case $t713:
    case $t714:
        $picked_value = 21;
		
        break;
    
    case $t721:
    case $t722:
    case $t723:
    case $t724:
        $picked_value = 22;
		
        break;
    
    case $t731:
    case $t732:
    case $t733:
    case $t734:
        $picked_value = 23;
		
        break;
    
    case $t741:
    case $t742:
    case $t743:
    case $t744:
        $picked_value = 24;
		
        break;
    
    case $t811:
    case $t812:
    case $t813:
    case $t814:
        $picked_value = 25;
		
        break;
    
    case $t821:
    case $t822:
    case $t823:
    case $t824:
        $picked_value = 26;
		
        break;
    
    case $t831:
    case $t832:
    case $t833:
    case $t834:
        $picked_value = 27;
		
        break;
    
    case $t841:
    case $t842:
    case $t843:
    case $t844:
        $picked_value = 28;
		
        break;
    
    default:
    	$picked_value = 42;
		break;
		
	
    }
    echo elgg_view('input/pulldown', array(
						'internalname' => 'update_type',
						'options_values' => $assign_list,
						'value' => $picked_value
						));
   
	?>
				</label>
				</td>
				<td width="33%">
				
				</td>
				<td width="30%">
				<label>
				<?php 
				
				?>	
				
				</label>
			</td>
			</tr>
		</table>
		
