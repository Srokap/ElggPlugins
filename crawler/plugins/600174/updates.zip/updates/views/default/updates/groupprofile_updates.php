<?php
 
    // pages on the group index page

    //check to make sure this group forum has been activated
    if($vars['entity']->pages_enable != 'no'){

?>

<div id="group_updates_widget">
<h2><?php echo elgg_echo("updates:group"); ?></h2>
<?php

	set_context('search');
    $objects = list_entities("object", "updates", page_owner(), 5, false);
	set_context('updates');
	$users_updates_url = $vars['url'] . "pg/updates/" . page_owner_entity()->username;

    if($objects){
		echo $objects;
		echo "<div class=\"forum_latest\"><a href=\"{$users_updates_url}\">" . elgg_echo('updates:more') . "</a></div>";
	}
	else
		echo "<div class=\"forum_latest\">" . elgg_echo("updates:nogroup") . "</div>";
	
?>
<br class="clearfloat" />
</div>

<?php
    }
?>