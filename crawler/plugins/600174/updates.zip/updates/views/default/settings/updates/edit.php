<style type="text/css">
table.sample {
	border-width: thick;
	border-spacing: ;
	border-style: double;
	border-color: blue;
	border-collapse: separate;
	background-color: white;
}
table.sample th {
	border-width: 1px;
	padding: 1px;
	border-style: inset;
	border-color: gray;
	background-color: white;
	-moz-border-radius: ;
}
table.sample td {
	border-width: 1px;
	padding: 1px;
	border-style: inset;
	border-color: gray;
	background-color: white;
	-moz-border-radius: ;
}
</style>
<p>
   <?php
   
			
			$bnteach1 = $vars['entity']->bnteach1;
    		$bnteach2 = $vars['entity']->bnteach2;
    		$bnteach3 = $vars['entity']->bnteach3;
    		$bnteach4 = $vars['entity']->bnteach4;
   			$bsteach1 = $vars['entity']->bsteach1;
  		  	$bsteach2 = $vars['entity']->bsteach2;
  		  	$bsteach3 = $vars['entity']->bsteach3;
  		  	$bsteach4 = $vars['entity']->bsteach4;
  		  	$keteach1 = $vars['entity']->keteach1;
    		$keteach2 = $vars['entity']->keteach2;
    		$keteach3 = $vars['entity']->keteach3;
    		$keteach4 = $vars['entity']->keteach4;
    		$kwteach1 = $vars['entity']->kwteach1;
    		$kwteach2 = $vars['entity']->kwteach2;
    		$kwteach3 = $vars['entity']->kwteach3;
    		$kwteach4 = $vars['entity']->kwteach4;
    		$osteach1 = $vars['entity']->osteach1;
   			$osteach2 = $vars['entity']->osteach2;
    		$osteach3 = $vars['entity']->osteach3;
    		$osteach4 = $vars['entity']->osteach4;
    		$onteach1 = $vars['entity']->onteach1;
    		$onteach2 = $vars['entity']->onteach2;
    		$onteach3 = $vars['entity']->onteach3;
    		$onteach4 = $vars['entity']->onteach4;
    		$teteach1 = $vars['entity']->teteach1;
    		$teteach2 = $vars['entity']->teteach2;
    		$teteach3 = $vars['entity']->teteach3;
    		$teteach4 = $vars['entity']->teteach4;
    		$twteach1 = $vars['entity']->twteach1;
    		$twteach2 = $vars['entity']->twteach2;
    		$twteach3 = $vars['entity']->twteach3;
    		$twteach4 = $vars['entity']->twteach4;
    		$t1teach1 = $vars['entity']->t1teach1;
    		$t1teach2 = $vars['entity']->t1teach2;
    		$t1teach3 = $vars['entity']->t1teach3;
    		$t1teach4 = $vars['entity']->t1teach4;
    		$t2teach1 = $vars['entity']->t2teach1;
    		$t2teach2 = $vars['entity']->t2teach2;
    		$t2teach3 = $vars['entity']->t2teach3;
    		$t2teach4 = $vars['entity']->t2teach4;
		    $t3teach1 = $vars['entity']->t3teach1;
		    $t3teach2 = $vars['entity']->t3teach2;
		    $t3teach3 = $vars['entity']->t3teach3;
		    $t3teach4 = $vars['entity']->t3teach4;
		    $f1teach1 = $vars['entity']->f1teach1;
		    $f1teach2 = $vars['entity']->f1teach2;
		    $f1teach3 = $vars['entity']->f1teach3;
		    $f1teach4 = $vars['entity']->f1teach4;
		    $f2teach1 = $vars['entity']->f2teach1;
		    $f2teach2 = $vars['entity']->f2teach2;
		    $f2teach3 = $vars['entity']->f2teach3;
		    $f2teach4 = $vars['entity']->f2teach4;
		    $f3teach1 = $vars['entity']->f3teach1;
		    $f3teach2 = $vars['entity']->f3teach2;
		    $f3teach3 = $vars['entity']->f3teach3;
		    $f3teach4 = $vars['entity']->f3teach4;
		    $ff1teach1 = $vars['entity']->ff1teach1;
		    $ff1teach2 = $vars['entity']->ff1teach2;
		    $ff1teach3 = $vars['entity']->ff1teach3;
		    $ff1teach4 = $vars['entity']->ff1teach4;
		    $ff2teach1 = $vars['entity']->ff2teach1;
		    $ff2teach2 = $vars['entity']->ff2teach2;
		    $ff2teach3 = $vars['entity']->ff2teach3;
		    $ff2teach4 = $vars['entity']->ff2teach4;
		    $ff3teach1 = $vars['entity']->ff3teach1;
		    $ff3teach2 = $vars['entity']->ff3teach2;
		    $ff3teach3 = $vars['entity']->ff3teach3;
		    $ff3teach4 = $vars['entity']->ff3teach4;
		    $s1teach1 = $vars['entity']->s1teach1;
		    $s1teach2 = $vars['entity']->s1teach2;
		    $s1teach3 = $vars['entity']->s1teach3;
		    $s1teach4 = $vars['entity']->s1teach4;
		    $s2teach1 = $vars['entity']->s2teach1;
		    $s2teach2 = $vars['entity']->s2teach2;
		    $s2teach3 = $vars['entity']->s2teach3;
		    $s2teach4 = $vars['entity']->s2teach4;
		    $s3teach1 = $vars['entity']->s3teach1;
		    $s3teach2 = $vars['entity']->s3teach2;
		    $s3teach3 = $vars['entity']->s3teach3;
		    $s3teach4 = $vars['entity']->s3teach4;
		    $s4teach1 = $vars['entity']->s4teach1;
		    $s4teach2 = $vars['entity']->s4teach2;
		    $s4teach3 = $vars['entity']->s4teach3;
		    $s4teach4 = $vars['entity']->s4teach4;
		    $ss1teach1 = $vars['entity']->ss1teach1;
		    $ss1teach2 = $vars['entity']->ss1teach2;
		    $ss1teach3 = $vars['entity']->ss1teach3;
		    $ss1teach4 = $vars['entity']->ss1teach4;
		    $ss2teach1 = $vars['entity']->ss2teach1;
		    $ss2teach2 = $vars['entity']->ss2teach2;
		    $ss2teach3 = $vars['entity']->ss2teach3;
		    $ss2teach4 = $vars['entity']->ss2teach4;
		    $ss3teach1 = $vars['entity']->ss3teach1;
		    $ss3teach2 = $vars['entity']->ss3teach2;
		    $ss3teach3 = $vars['entity']->ss3teach3;
		    $ss3teach4 = $vars['entity']->ss3teach4;	
		    $ss4teach1 = $vars['entity']->ss4teach1;
		    $ss4teach2 = $vars['entity']->ss4teach2;
		    $ss4teach3 = $vars['entity']->ss4teach3;
		    $ss4teach4 = $vars['entity']->ss4teach4;
		    $e1teach1 = $vars['entity']->e1teach1;
		    $e1teach2 = $vars['entity']->e1teach2;
		    $e1teach3 = $vars['entity']->e1teach3;
		    $e1teach4 = $vars['entity']->e1teach4;
		    $e2teach1 = $vars['entity']->e2teach1;
		    $e2teach2 = $vars['entity']->e2teach2;
		    $e2teach3 = $vars['entity']->e2teach3;
		    $e2teach4 = $vars['entity']->e2teach4;
		    $e3teach1 = $vars['entity']->e3teach1;
		    $e3teach2 = $vars['entity']->e3teach2;
		    $e3teach3 = $vars['entity']->e3teach3;
		    $e3teach4 = $vars['entity']->e3teach4;
		    $e4teach1 = $vars['entity']->e4teach1;
		    $e4teach2 = $vars['entity']->e4teach2;
		    $e4teach3 = $vars['entity']->e4teach3;
		    $e4teach4 = $vars['entity']->e4teach4;
		    
		    
    $assign_list = array();
		$assign_list[0] = "";
		$assign_list[$_SESSION['user']->getGUID()] = $_SESSION['user']->name;
		if($container instanceof ElggGroup){

			$assign_list1 = $container->getMembers(300);
			
			foreach($assign_list1 as $members)
				$assign_list[$members->getGUID()] = $members->name;
				
		}else{
     
      $assign_list1 = $_SESSION['user']->getFriends("", 300, $offset = 0);
      
			
			foreach($assign_list1 as $friends)
				$assign_list[$friends->getGUID()] = $friends->name;
    }
    $user_list = array();
		$user_list[0] = "";
		$user_list[$_SESSION['user']->getGUID()] = $_SESSION['user']->name;
	    $user_list1 = $_SESSION['user']->getFriends("", 300, $offset = 0);
      		foreach($user_list1 as $friends)
      		{
				$user_list[$friends->getGUID()] = $friends->name;
    		}
    ?>
    
    <em>Please do not have duplicates. If a duplicate is found, the last match found will be respected.</em>
    <br /><br />
    <table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:keteach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[keteach1]',
							'options_values' => $assign_list,
							'value' => $keteach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[keteach2]',
							'options_values' => $assign_list,
							'value' => $keteach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[keteach3]',
							'options_values' => $assign_list,
							'value' => $keteach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[keteach4]',
							'options_values' => $assign_list,
							'value' => $keteach4
						));
				?>
	</td>
	</tr>
	</table>
	<br />
	<table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:kwteach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[kwteach1]',
							'options_values' => $assign_list,
							'value' => $kwteach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[kwteach2]',
							'options_values' => $assign_list,
							'value' => $kwteach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[kwteach3]',
							'options_values' => $assign_list,
							'value' => $kwteach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[kwteach4]',
							'options_values' => $assign_list,
							'value' => $kwteach4
						));
				?>
	</td>
	</tr>
	</table>
	<br /><table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:bnteach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[bnteach1]',
							'options_values' => $assign_list,
							'value' => $bnteach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[bnteach2]',
							'options_values' => $assign_list,
							'value' => $bnteach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[bnteach3]',
							'options_values' => $assign_list,
							'value' => $bnteach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[bnteach4]',
							'options_values' => $assign_list,
							'value' => $bnteach4
						));
				?>
	</td>
	</tr>
	</table>
	<br /><table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:bsteach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[bsteach1]',
							'options_values' => $assign_list,
							'value' => $bsteach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[bsteach2]',
							'options_values' => $assign_list,
							'value' => $bsteach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[bsteach3]',
							'options_values' => $assign_list,
							'value' => $bsteach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[bsteach4]',
							'options_values' => $assign_list,
							'value' => $bsteach4
						));
				?>
	</td>
	</tr>
	</table>
	<br /><table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:onteach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[onteach1]',
							'options_values' => $assign_list,
							'value' => $onteach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[onteach2]',
							'options_values' => $assign_list,
							'value' => $onteach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[onteach3]',
							'options_values' => $assign_list,
							'value' => $onteach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[onteach4]',
							'options_values' => $assign_list,
							'value' => $onteach4
						));
				?>
	</td>
	</tr>
	</table>
	<br /><table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:osteach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[osteach1]',
							'options_values' => $assign_list,
							'value' => $osteach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[osteach2]',
							'options_values' => $assign_list,
							'value' => $osteach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[osteach3]',
							'options_values' => $assign_list,
							'value' => $osteach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[osteach4]',
							'options_values' => $assign_list,
							'value' => $osteach4
						));
				?>
	</td>
	</tr>
	</table>
	<br /><table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:teteach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[teteach1]',
							'options_values' => $assign_list,
							'value' => $teteach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[teteach2]',
							'options_values' => $assign_list,
							'value' => $teteach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[teteach3]',
							'options_values' => $assign_list,
							'value' => $teteach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[teteach4]',
							'options_values' => $assign_list,
							'value' => $teteach4
						));
				?>
	</td>
	</tr>
	</table>
	<br /><table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:twteach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[twteach1]',
							'options_values' => $assign_list,
							'value' => $twteach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[twteach2]',
							'options_values' => $assign_list,
							'value' => $twteach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[twteach3]',
							'options_values' => $assign_list,
							'value' => $twteach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[twteach4]',
							'options_values' => $assign_list,
							'value' => $twteach4
						));
				?>
	</td>
	</tr>
	</table>
	<br /><table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:t1teach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[t1teach1]',
							'options_values' => $assign_list,
							'value' => $t1teach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[t1teach2]',
							'options_values' => $assign_list,
							'value' => $t1teach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[t1teach3]',
							'options_values' => $assign_list,
							'value' => $t1teach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[t1teach4]',
							'options_values' => $assign_list,
							'value' => $t1teach4
						));
				?>
	</td>
	</tr>
	</table>
	<br /><table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:t2teach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[t2teach1]',
							'options_values' => $assign_list,
							'value' => $t2teach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[t2teach2]',
							'options_values' => $assign_list,
							'value' => $t2teach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[t2teach3]',
							'options_values' => $assign_list,
							'value' => $t2teach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[t2teach4]',
							'options_values' => $assign_list,
							'value' => $t2teach4
						));
				?>
	</td>
	</tr>
	</table>
	<br /><table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:t3teach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[t3teach1]',
							'options_values' => $assign_list,
							'value' => $t3teach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[t3teach2]',
							'options_values' => $assign_list,
							'value' => $t3teach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[t3teach3]',
							'options_values' => $assign_list,
							'value' => $t3teach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[t3teach4]',
							'options_values' => $assign_list,
							'value' => $t3teach4
						));
				?>
	</td>
	</tr>
	</table>
	<br /><table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:f1teach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[f1teach1]',
							'options_values' => $assign_list,
							'value' => $f1teach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[f1teach2]',
							'options_values' => $assign_list,
							'value' => $f1teach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[f1teach3]',
							'options_values' => $assign_list,
							'value' => $f1teach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[f1teach4]',
							'options_values' => $assign_list,
							'value' => $f1teach4
						));
				?>
	</td>
	</tr>
	</table>
	<br /><table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:f2teach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[f2teach1]',
							'options_values' => $assign_list,
							'value' => $f2teach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[f2teach2]',
							'options_values' => $assign_list,
							'value' => $f2teach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[f2teach3]',
							'options_values' => $assign_list,
							'value' => $f2teach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[f2teach4]',
							'options_values' => $assign_list,
							'value' => $f2teach4
						));
				?>
	</td>
	</tr>
	</table>
	<br /><table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:f3teach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[f3teach1]',
							'options_values' => $assign_list,
							'value' => $f3teach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[f3teach2]',
							'options_values' => $assign_list,
							'value' => $f3teach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[f3teach3]',
							'options_values' => $assign_list,
							'value' => $f3teach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[f3teach4]',
							'options_values' => $assign_list,
							'value' => $f3teach4
						));
				?>
	</td>
	</tr>
	</table>
	<br /><table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:ff1teach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[ff1teach1]',
							'options_values' => $assign_list,
							'value' => $ff1teach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[ff1teach2]',
							'options_values' => $assign_list,
							'value' => $ff1teach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[ff1teach3]',
							'options_values' => $assign_list,
							'value' => $ff1teach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[ff1teach4]',
							'options_values' => $assign_list,
							'value' => $ff1teach4
						));
				?>
	</td>
	</tr>
	</table>
	<br /><table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:ff2teach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[ff2teach1]',
							'options_values' => $assign_list,
							'value' => $ff2teach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[ff2teach2]',
							'options_values' => $assign_list,
							'value' => $ff2teach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[ff2teach3]',
							'options_values' => $assign_list,
							'value' => $ff2teach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[ff2teach4]',
							'options_values' => $assign_list,
							'value' => $ff2teach4
						));
				?>
	</td>
	</tr>
	</table>
	<br /><table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:ff3teach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[ff3teach1]',
							'options_values' => $assign_list,
							'value' => $ff3teach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[ff3teach2]',
							'options_values' => $assign_list,
							'value' => $ff3teach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[ff3teach3]',
							'options_values' => $assign_list,
							'value' => $ff3teach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[ff3teach4]',
							'options_values' => $assign_list,
							'value' => $ff3teach4
						));
				?>
	</td>
	</tr>
	</table>
	<br /><table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:s1teach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[s1teach1]',
							'options_values' => $assign_list,
							'value' => $s1teach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[s1teach2]',
							'options_values' => $assign_list,
							'value' => $s1teach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[s1teach3]',
							'options_values' => $assign_list,
							'value' => $s1teach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[s1teach4]',
							'options_values' => $assign_list,
							'value' => $s1teach4
						));
				?>
	</td>
	</tr>
	</table>
	<br /><table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:s2teach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[s2teach1]',
							'options_values' => $assign_list,
							'value' => $s2teach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[s2teach2]',
							'options_values' => $assign_list,
							'value' => $s2teach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[s2teach3]',
							'options_values' => $assign_list,
							'value' => $s2teach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[s2teach4]',
							'options_values' => $assign_list,
							'value' => $s2teach4
						));
				?>
	</td>
	</tr>
	</table>
	<br /><table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:s3teach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[s3teach1]',
							'options_values' => $assign_list,
							'value' => $s3teach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[s3teach2]',
							'options_values' => $assign_list,
							'value' => $s3teach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[s3teach3]',
							'options_values' => $assign_list,
							'value' => $s3teach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[s3teach4]',
							'options_values' => $assign_list,
							'value' => $s3teach4
						));
				?>
	</td>
	</tr>
	</table>
	<br /><table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:s4teach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[s4teach1]',
							'options_values' => $assign_list,
							'value' => $s4teach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[s4teach2]',
							'options_values' => $assign_list,
							'value' => $s4teach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[s4teach3]',
							'options_values' => $assign_list,
							'value' => $s4teach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[s4teach4]',
							'options_values' => $assign_list,
							'value' => $s4teach4
						));
				?>
	</td>
	</tr>
	</table>
	<br /><table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:ss1teach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[ss1teach1]',
							'options_values' => $assign_list,
							'value' => $ss1teach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[ss1teach2]',
							'options_values' => $assign_list,
							'value' => $ss1teach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[ss1teach3]',
							'options_values' => $assign_list,
							'value' => $ss1teach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[ss1teach4]',
							'options_values' => $assign_list,
							'value' => $ss1teach4
						));
				?>
	</td>
	</tr>
	</table>
	<br /><table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:ss2teach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[ss2teach1]',
							'options_values' => $assign_list,
							'value' => $ss2teach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[ss2teach2]',
							'options_values' => $assign_list,
							'value' => $ss2teach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[ss2teach3]',
							'options_values' => $assign_list,
							'value' => $ss2teach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[ss2teach4]',
							'options_values' => $assign_list,
							'value' => $ss2teach4
						));
				?>
	</td>
	</tr>
	</table>
	<br /><table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:ss3teach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[ss3teach1]',
							'options_values' => $assign_list,
							'value' => $ss3teach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[ss3teach2]',
							'options_values' => $assign_list,
							'value' => $ss3teach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[ss3teach3]',
							'options_values' => $assign_list,
							'value' => $ss3teach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[ss3teach4]',
							'options_values' => $assign_list,
							'value' => $ss3teach4
						));
				?>
	</td>
	</tr>
	</table>
	<br /><table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:ss4teach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[ss4teach1]',
							'options_values' => $assign_list,
							'value' => $ss4teach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[ss4teach2]',
							'options_values' => $assign_list,
							'value' => $ss4teach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[ss4teach3]',
							'options_values' => $assign_list,
							'value' => $ss4teach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[ss4teach4]',
							'options_values' => $assign_list,
							'value' => $ss4teach4
						));
				?>
	</td>
	</tr>
	</table>
	<br /><table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:e1teach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[e1teach1]',
							'options_values' => $assign_list,
							'value' => $e1teach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[e1teach2]',
							'options_values' => $assign_list,
							'value' => $e1teach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[e1teach3]',
							'options_values' => $assign_list,
							'value' => $e1teach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[e1teach4]',
							'options_values' => $assign_list,
							'value' => $e1teach4
						));
				?>
	</td>
	</tr>
	</table>
	<br /><table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:e2teach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[e2teach1]',
							'options_values' => $assign_list,
							'value' => $e2teach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[e2teach2]',
							'options_values' => $assign_list,
							'value' => $e2teach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[e2teach3]',
							'options_values' => $assign_list,
							'value' => $e2teach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[e2teach4]',
							'options_values' => $assign_list,
							'value' => $e2teach4
						));
				?>
	</td>
	</tr>
	</table>
	<br /><table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:e3teach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[e3teach1]',
							'options_values' => $assign_list,
							'value' => $e3teach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[e3teach2]',
							'options_values' => $assign_list,
							'value' => $e3teach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[e3teach3]',
							'options_values' => $assign_list,
							'value' => $e3teach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[e3teach4]',
							'options_values' => $assign_list,
							'value' => $e3teach4
						));
				?>
	</td>
	</tr>
	</table>
	<br /><table class="sample" cellspacing="3" cellpadding="3">
    <tr>
    <td colspan="4">
    <center>
	<?php echo elgg_echo('updates:e4teach'); ?><hr />
	</center>
	</td>
	</tr>
	<tr>
	<td>
	1.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[e4teach1]',
							'options_values' => $assign_list,
							'value' => $e4teach1
						));
				?>
	</td>
	<td>
	2.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[e4teach2]',
							'options_values' => $assign_list,
							'value' => $e4teach2
						));
				?>
	</td>
	<td>
	3.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[e4teach3]',
							'options_values' => $assign_list,
							'value' => $e4teach3
						));
				?>
	</td>
	<td>
	4.
	<?php
					echo elgg_view('input/pulldown', array(
							'internalname' => 'params[e4teach4]',
							'options_values' => $assign_list,
							'value' => $e4teach4
						));
				?>
	</td>
	</tr>
	</table>
	<br />