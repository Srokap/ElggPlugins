<?php
/* Lets you choose your theme more easily
 */

function thematic_available_themes() {
  $plugins = get_plugin_list();
  $themes = array();
  foreach ($plugins as $key => $plugin) {
    if (strpos($plugin, 'theme_') === 0) {
      $themes[] = $plugin;
    }
  }
  return $themes;
}

function thematic_init() {
  $config = find_plugin_settings('thematic');
  $theme = isset($config->theme) ? $config->theme : 'default';
  $themes = thematic_available_themes();

  $changed = false;
  foreach($themes as $plugin) {
    if ($plugin != $theme && is_plugin_enabled($plugin)) {
      disable_plugin($plugin);
      error_log("disabled $plugin");
      $changed = true;
    }
  }
  if ($theme != 'default') {
    if (!is_plugin_enabled($theme)) {
      enable_plugin($theme);
      error_log("enabled $theme");
      $changed = true;
      // Workaround for elgg 1.5 bug (cache not updated)
      if (!is_plugin_enabled($theme)) {
        global $ENABLED_PLUGINS_CACHE;
        $ENABLED_PLUGINS_CACHE[] = $theme;
      }
    }
    $plugins = get_plugin_list();
    $key = array_search($theme, $plugins);
    if (!isset($plugins[$key])) {
      register_error(sprintf(elgg_echo('thematic:notexist'), $theme));
      unset($config->theme);
      $changed = true;
    }
    else {
      $keys = array_keys($plugins);
      if ($key < $keys[count($keys)-1]) {
        unset($plugins[$key]);
        $key = $keys[count($keys)-1] + 1;
        $plugins[$key] = $theme;
        if (!regenerate_plugin_list($plugins)) {
          register_error(sprintf(elgg_echo('admin:plugins:reorder:no'), $plugin));		
        }
        $changed = true;
      }
    }
  }
  if ($changed) {
    // Workaround for elgg 1.5 bug (view cache not updated)
    elgg_view_regenerate_simplecache();
    $cache = elgg_get_filepath_cache();
    $cache->delete('view_paths');

    system_message(elgg_echo('thematic:flush'));
    $count = $_SESSION['thematic-count'];
    $_SESSION['thematic-count'] = ++$count;
    if ($count < 3) {
      forward(current_page_url());
    }
    else {
      error_log("Too many forwards");
    }
  }
  else {
    unset($_SESSION['thematic-count']);
  }
}

register_elgg_event_handler('init','system','thematic_init');
?>