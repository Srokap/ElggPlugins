<?php

$english = array('thematic' => 'Thematic',
                 'thematic:desc' => 'Facilitates changing your Elgg theme.',
                 'thematic:modify' => "Select your theme.  Themes must be installed in your 'mod' directory and be named with a 'theme_' prefix.",
                 'thematic:default' => 'default',
                 'thematic:notexist' => 'Theme "%s" does not exist',
                 'thematic:flush' => "You may need to flush your browser's cache to see the new theme",
                 );

add_translation("en",$english);
?>