<p>
<?php
$themes = thematic_available_themes();
$themes = array_merge(array(elgg_echo('thematic:default')), $themes);

echo elgg_echo('thematic:modify'); 
echo elgg_view('input/pulldown', array('internalname'=>'params[theme]',
                                       'value'=>$vars['entity']->theme,
                                       'options'=>$themes));
?>
</p>