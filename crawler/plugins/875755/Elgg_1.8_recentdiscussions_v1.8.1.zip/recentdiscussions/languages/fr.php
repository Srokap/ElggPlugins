<?php

$french = array(
  'recentdiscussions:title' => "Discussions récentes",
  'recentdiscussions:widget:description' => "Discussions récentes",
  'recentdiscussions:widget:numberdiscussions' => "Nombre de sujets des dernières discussions à afficher",
);

add_translation("fr",$french);
