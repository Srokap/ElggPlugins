<?php

$german = array(
  'recentdiscussions:title' => "Neueste Diskussionsbeiträge",
  'recentdiscussions:widget:description' => "Neueste Diskussionsbeiträge",
  'recentdiscussions:widget:numberdiscussions' => "Anzahl der anzuzeigenden neuesten Diskussionsbeiträge",
);

add_translation("de",$german);
