<?php

$english = array(
  'recentdiscussions:title' => "Recent discussions",
  'recentdiscussions:widget:description' => "Recent discussions",
  'recentdiscussions:widget:numberdiscussions' => "Number of recent discussion topics to display",
);

add_translation("en",$english);
