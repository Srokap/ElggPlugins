<?php 
/*****************************************************************************
 * Phloor Menu Sooperfish Theme Theme5                                       *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php

elgg_register_event_handler('init',  'system', 'phloor_menu_sooperfish_theme_theme5_init');


/**
 * Phloor Menu Sooperfish THEME5 Initialization
 */
function phloor_menu_sooperfish_theme_theme5_init() {
	/**
	 * CSS
	 */	
	$css_url = 'mod/phloor_menu_sooperfish_theme_theme5/views/default/phloor_menu_sooperfish_theme_theme5/css/theme5.css';
	elgg_register_css('sooperfish-theme-theme5', $css_url, 720);	
		
	elgg_load_css('sooperfish-theme-theme5');
	
	/**
	 * Plugin Hooks
	 */
	// hook into 'phloor_menu_sooperfish_theme_register' and register the new theme
	elgg_register_plugin_hook_handler('phloor_menu_sooperfish_theme_register', 'all', 'phloor_menu_sooperfish_theme_theme5_register_theme', 2);
}

/**
 * Register theme hook
 * 
 * Here the 'theme5' theme gets registered to be
 * available for choosing from the 'theme' dropbox 
 * on the 'phloor_menu_sooperfish' settings page.
 * 
 * @param unknown_type $hook
 * @param unknown_type $entity_type
 * @param unknown_type $return_value
 * @param unknown_type $params
 */
function phloor_menu_sooperfish_theme_theme5_register_theme($hook, $entity_type, $return_value, $params) {
	// [theme-css-class] => [theme-display-name]
	$theme = array(
	 	'theme5-class' => elgg_echo('phloor_menu_sooperfish_theme_theme5:theme5'),
	);
	
	// merge it with the return value array
	$return_value = array_merge($theme, $return_value);
	
	return $return_value;
}


