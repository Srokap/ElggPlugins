<?php
/**
 * Highlight content plugin
 *
 * This plugin add a view for show a higlighted content and let admin users determine
 * what would be highlighted
 *
 * @package ElggHighlightContent
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Diego Andrés Ramírez Aragón
 * @copyright Corporación Somos más - 2009
 * @link http://www.somosmas.org
 */

/**
 * Highlight content initialization
 *
 * Register css extensions, page handlers and actions
 */
function highlightcontent_init(){
  extend_view('css','highlight/css');
  register_page_handler('highlight','highlight_page_handler');
  register_action("highlight",false,dirname(__FILE__)."/actions/hightlight.php",true);
}

/**
 * Configure the menu items that give you access to this plugin
 *
 */
function highlightcontent_pagesetup(){
  global $CONFIG;
  $config = array("blog");
  if(file_exists(dirname(__FILE__)."/config.php")){
    include dirname(__FILE__)."/config.php";
  }
  if (isadminloggedin() && in_array(get_context(),$config)) {
    add_submenu_item(sprintf(elgg_echo('highlight:title'),elgg_echo(get_context())), $CONFIG->wwwroot . "pg/highlight/".get_context(),"z");
  }
}

/**
 * Highlight content page handler
 *
 * @param mixed $page
 * @return boolean
 */
function highlight_page_handler($page){
  set_context($page[0]);
  @include(dirname(__FILE__) . "/index.php");
  return true;
}

register_elgg_event_handler('init','system','highlightcontent_init');
register_elgg_event_handler('pagesetup','system','highlightcontent_pagesetup');

?>