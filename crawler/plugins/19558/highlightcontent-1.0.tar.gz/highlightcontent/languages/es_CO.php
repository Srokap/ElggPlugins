<?php
$language = array(
  'highlight:title'=>"%s destacados",
  'hightlight:explanation:message'=>"En esta página podrás seleccionar alguno de los %s disponibles para ser mostrado en una vista especial que podrá ser usada en cualquier parte de tu sitio.
  <p>Del siguiente listado seleccione el item que quiere destacar.</p>",
  "hightlight:highlight"=>"Destacar",
  "highlight:highlighted"=>"El item seleccionado ha sido marcado como destacado",
  "highlight:cant:highlight"=>"El item seleccionado no pudo ser marcado como destacado",
  "hightlight:empty"=>"En el momento no hay ningún item destacado",
);
add_translation("es_CO",$language);
?>