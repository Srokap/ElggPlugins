<?php
$language = array(
  'highlight:title'=>"Highlighted %s",
  'hightlight:explanation:message'=>"In this page you can select one of the available %s for be showed in an special view that you can use at any part of your site.
  <p>From the following list select the one you wants to be highlighted.</p>",
  "hightlight:highlight"=>"Highlight",
  "highlight:highlighted"=>"The selected item was highlighted",
  "highlight:cant:highlight"=>"The selected item can't be highlighted",
  "hightlight:empty"=>"At the moment there is not any highlighted item"
);
add_translation("en",$language);

?>