<?php
/**
 * Highlight content action processing
 *
 * @package ElggHighlightContent
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Diego Andrés Ramírez Aragón
 * @copyright Corporación Somos más - 2009
 * @link http://www.somosmas.org
 *
 */

global $CONFIG;

admin_gatekeeper();

$context = get_input("context","blog");
$guid = get_input("highlight");

$forward_url = $CONFIG->url."pg/highlight/$context";

if(!empty($context) && !empty($guid)){
  $highlighted = get_entities_from_metadata("highlighted","","object",get_context(),0);
  if(!empty($highlighted)){
    $highlighted[0]->clearMetadata("highlighted");
    $highlighted[0]->save();
  }
  $entity = get_entity($guid);
  $entity->set("highlighted",true);
  if(!$entity->save()){
    register_error(elgg_echo("highlight:cant:highlight"));
  }
  else{
    system_message(elgg_echo("highlight:highlighted"));
  }
}

forward($forward_url);

?>