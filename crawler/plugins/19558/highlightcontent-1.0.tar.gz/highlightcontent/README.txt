Highlight content plugin
=======================

Features:
      - Let you mark as highlighted a blog post
      - Provides a view for show highligted content in any part of your site
  
Install
-------

Just drop it on your mod directory and then go to the admin panel and activate it. 

How to extend this plugin for highlight another kind of contents?
-----------------------------------------------------------------
For add a new kind of content that could be highlighted you must:

  1) Create a config file and define an array called $config that specifies
     what kind of objects you want to highlight.
  2) Create the views need to show your object in the hightligh list form and
     in the highlight view.
     Those views are:
       object/<object>_tiny.php
       object/<object>_highlight.php    