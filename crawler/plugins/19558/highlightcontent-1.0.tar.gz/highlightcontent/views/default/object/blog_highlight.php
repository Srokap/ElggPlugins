<?php
/**
 * Elgg blog individual hightlighted post view
 *
 * @package ElggHighlightContent
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Diego Andrés Ramírez Aragón
 * @copyright Corporación Somos más - 2009
 * @link http://www.somosmas.org
 *
 * @uses $vars['entity']
 * @uses $vars['words']
 *
 */

if (isset($vars['entity'])) {
  $wowds = (!empty($vars["words"]))?$vars["words"]:40;

  $body = explode(" ", preg_replace( "|\w{3,10}://[\w\.\-_]+(:\d+)?[^\s\"\'<>\(\)\{\}]*|", "", strip_tags(autop($vars['entity']->description))), $words);
  $body = implode(" ", array_slice($body,0,sizeof($body) - 1)) . " ... ";
?>

<div class="blog_post">
<h3><a href="<?php echo $vars['entity']->getURL(); ?>"><?php echo $vars['entity']->title; ?></a></h3>
<!-- Blog type -->
<p>
<?php echo elgg_view('output/tags', array('tags' => elgg_echo($vars["entity"]->blog_type))); ?>
</p>
<p>
<?php echo $body; ?>
</p>
<p style="float:right"><a href="<?php echo $vars['entity']->getURL(); ?>"><?php echo elgg_echo("more"); ?></a></p>
<div class="clearfloat"></div>
</div>
<?php
}
?>