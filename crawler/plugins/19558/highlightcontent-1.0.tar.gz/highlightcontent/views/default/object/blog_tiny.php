<?php
/**
 * Elgg blog individual post view using a tiny presentation
 *
 * @package ElggHighlightContent
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Diego Andrés Ramírez Aragón
 * @copyright Corporación Somos más - 2009
 * @link http://www.somosmas.org
 *
 * @uses $vars['entity']
 * @uses $vars['home']
 *
 */

if (isset($vars['entity'])) {
?>

<div class="blog_post">
<!-- display the user icon -->
<div class="blog_post_icon"><?php
echo elgg_view("home/icon",array('entity' => $vars['entity']->getOwnerEntity(), 'size' => 'small','home'=>$vars['home']));
?></div>
<div class="search_listing_info">
<p><b><a href="<?php echo $vars['entity']->getURL(); ?>"><?php echo $vars['entity']->title; ?></a></b></p>
<!-- Blog type -->
<p>
<?php echo elgg_view('output/tags', array('tags' => elgg_echo($vars["entity"]->blog_type))); ?>
</p>
<p ><?php echo friendly_time($vars['entity']->time_created);?>&nbsp;
<?php echo elgg_echo('by'); ?> <a href="<?php echo $vars['url']; ?>pg/blog/<?php echo $vars['entity']->getOwnerEntity()->username; ?>"><?php echo $vars['entity']->getOwnerEntity()->name; ?></a>
&nbsp;
</p>
</div>
<div class="clearfloat"></div>
</div>
<?php
}
?>