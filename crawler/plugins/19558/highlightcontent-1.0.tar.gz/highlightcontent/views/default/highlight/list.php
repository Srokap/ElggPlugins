<?php
/**
 * View that show the list of items that could be highlighted
 *
 * @package ElggHighlightContent
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Diego Andrés Ramírez Aragón
 * @copyright Corporación Somos más - 2009
 * @link http://www.somosmas.org
 */

$value = "";
$objects = get_entities("object",get_context(),0,"time_created desc",10);
$highlighted = get_entities_from_metadata("highlighted","","object",get_context(),0);
if(!empty($highlighted)){
  $value = $highlighted[0]->getGUID();
}

$html=sprintf(elgg_echo("hightlight:explanation:message"),get_context());
$html.="<div style=\"float:right\"><b>".elgg_echo("hightlight:highlight")."</b></div>";
$html.="<div class=\"clearfloat\"></div>";
if(!empty($objects)){
  foreach($objects as $entity){
     $html.= elgg_view("highlight/form_item",array("entity_id"=>$entity->getGUID(),"selected"=>$value));
     $html.= elgg_view("object/".get_context()."_tiny",array('entity' => $entity,'home'=>true));
  }

  $html.=elgg_view("input/hidden",array("internalname"=>"context","value"=>get_context()));
  $html.=elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('save')));

  echo elgg_view('input/form', array('action' => "{$vars['url']}action/highlight", 'body' => $html));
}
else{
  echo elgg_echo("hightlight:empty");
}
?>
