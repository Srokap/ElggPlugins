<?php
/**
 * CSS properties
 *
 * @package ElggHighlightContent
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Diego Andrés Ramírez Aragón
 * @copyright Corporación Somos más - 2009
 * @link http://www.somosmas.org
 */

$package = basename(dirname(dirname(dirname(dirname(dirname(__FILE__))))));
$vars['mod_path']=basename(dirname(dirname(dirname(dirname(dirname(dirname(__FILE__)))))));
if($package!="highlightcontent"){
  $vars['mod_path'].="/".$package;
}

?>
#highlight {
	border:1px solid;
	padding:10px;
	-moz-border-radius-bottomleft:10px;
	-moz-border-radius-bottomright:10px;
	-moz-border-radius-topleft:10px;
	-moz-border-radius-topright:10px;
	-webkit-border-top-left-radius:10px;
	-webkit-border-top-right-radius:10px;
	-webkit-border-bottom-left-radius:10px;
	-webkit-border-bottom-right-radius:10px;
}

#highlight h2 {
	border-bottom: 1px dashed;
	padding: 0pt 0pt 5px;
	margin: 0px 0pt 15px;
}