<?php
/**
 * View that show the highlighted content
 *
 * @package ElggHighlightContent
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Diego Andrés Ramírez Aragón
 * @copyright Corporación Somos más - 2009
 * @link http://www.somosmas.org
 *
 * @uses $vars['context']
 */

$context = (!empty($vars["context"]))?$vars["context"]:"blog";

$highlighted = get_entities_from_metadata("highlighted","","object",$context,0);
if(!empty($highlighted)){
  $highlighted = $highlighted[0];
  $body = elgg_view("object/".$context."_highlight",array('entity' => $highlighted,"words"=>40));
}
else{
  $body = elgg_echo("hightlight:empty");
}
?>
<div id="highlight">
  <h2><?php echo sprintf(elgg_echo('highlight:title'),elgg_echo($context));?></h2>
  <?php echo $body;?>
</div>
