<?php
/**
 * View that shows the form chuck that let you select the highlighted item
 *
 * @package ElggHighlightContent
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Diego Andrés Ramírez Aragón
 * @copyright Corporación Somos más - 2009
 * @link http://www.somosmas.org
 *
 * @uses $vars['selected']
 * @uses $vars['entity_id']
 *
 */

?>
<div style="float:right;margin-right:20px;padding:5px">
<?php echo elgg_view("input/radio",array("internalname"=>"highlight",
                                         "value"=>$vars["selected"],
										 "options"=>array(""=>$vars["entity_id"])));
?>
</div>