******************************************
 *                                      *
  *         Access Type Groups          *
 *                                      *
******************************************

Designed and Coded by: Krishna Shetty
Supported for Elgg 1.8.x

Goal:
When creating an object, have list of groups(which the user is a member) as access type.