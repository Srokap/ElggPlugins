<?php

	/**
	 * Update client language pack.
	 * 
	 * @package ElggUpdateClient
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */	

	$english = array(
	
		'compactor:settings:info' => 'The compactor applies several levels of compression on the output of the and you may wish to turn them on or off, or just enable specific features.',
		
		'compactor:settings:label:yes' => 'Enabled',
		'compactor:settings:label:no' => 'Disabled',
		
		'compactor:settings:inline_options' => 'Inline Options',
		
		'compactor:settings:css_inline' => 'Optimise Inline CSS',
		'compactor:settings:css_inline:info' => 'Strip all the unnecessary white space and comments from any inline css style declarations. ',
		'compactor:settings:css_inline:move' => 'Move CSS all style declarations to the &lt;head&gt;.',
		'compactor:settings:css_inline:join' => 'Join all inline css.',
		
		'compactor:settings:js_inline' => 'Optimise Inline Javascript',
		'compactor:settings:js_inline:info' => 'Strip all the unnecessary white space and comments from any inline javascript script declarations. Note: In order for this to correctly work all your Javascript line endings must be properly terminated with ";" otherwise you WILL get javascript errors.',
		'compactor:settings:js_inline:move' => 'Move all javascript declarations just before &lt;/body&gt;.',
		'compactor:settings:js_inline:join' => 'Join all inline javascript.',
		
		'compactor:settings:html_inline' => 'Optimise HTML',
		'compactor:settings:html_inline:info' => 'Remove white space and comments from HTML. Note: If this is disabled so is the whitespace stripping optimisation of the inline CSS and inline Javascript.',
		
		'compactor:settings:external_options' => 'External Resource Options',
		
		'compactor:settings:compact_css_resources' => 'Compact CSS Resources',
		'compactor:settings:compact_css_resources:info' => 'Remove whitespace and comments from external CSS resources.',
		'compactor:settings:join_css_resources:info' => 'Attempt to join any external CSS files into one file.',
		
		'compactor:settings:compact_js_resources' => 'Compact Javascript Resources',
		'compactor:settings:compact_js_resources:info' => 'Remove whitespace and comments from external Javascript resources. Note: In order for this to correctly work all your Javascript line endings must be properly terminated with ";" otherwise you WILL get javascript errors.',
		'compactor:settings:join_js_resources:info' => 'Attempt to join any external Javascript files into one file.',
		
		'compactor:settings:deflate_options' => 'Deflate/Gzip Options',
		'compactor:settings:deflate_options:info' => 'Enabling gzip/deflate of any item will vastly shrink their size by about 500%. IMPORTANT: This should be disabled if the web-server is deflating the output. ALSO: This can increase the load on the webserver so should be used only if you know your server can handle it.',
		
		'compactor:settings:deflate_html' => 'Deflate HTML',
		
		'compactor:settings:deflate_css_resources' => 'Deflate CSS Resources',
		
		'compactor:settings:deflate_js_resources' => 'Deflate Javascript Resources',
		
		'compactor:settings:cache_options' => 'Cache Options',
		'compactor:settings:cache_options:info' => 'If you enable caching options please make sure the directory "mod/compactor/cache" is read/writable by the webserver.',
		'compactor:settings:cache_options:cleaning_mode:info' => 'It is important to periodically wipe your cache directory as it will grow very large depending on the size of your community. The purge can be done at different intervals.',
		'compactor:settings:cache_options:server_cache_age:info' => 'When purging the cache you probably don\'t want to remove a freshly cached item so decide how long the cache file should live before before it becomes classed as "old". The value below is in seconds.',
		
		'compactor:settings:debug_options' => 'Debug Options',
		'compactor:settings:debug_options:info' => 'If after enabling compactor your install behaves unpredictably or runs slow, you may wish to turn on debugging. For debugging to be enabled you will need to have <a href="http://www.getfirebug.com/" target="_blank">Firebug</a> and <a href="http://www.firephp.org/" target="_blank">FirePHP</a> installed in Firefox. Debugging can reveal sensitive information and should not be left on, however that said it is only enabled for users who are logged-in as admin.',
		
		'compactor:settings:clean_now_options' => 'Clear Cache Directory',
		'compactor:settings:clean_now_options:info' => 'This will result in the removal of all cached files.',
		'compactor:settings:clean_now_options:click' => 'Click here to clear the cache directory.',
		'compactor:settings:clean_now_options:wiped' => 'The cache directory has been emptied.',
		
	);
					
	add_translation("en", $english);
?>