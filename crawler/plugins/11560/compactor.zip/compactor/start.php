<?php

	/**
	 * Elgg Compactor Plugin
	 * This plugin compresses and compacts the output of Elgg HTML.
	 * 
	 * @package Compactor
	 * @license BSD
	 * @author buggedcom <publicmail@buggedcom.co.uk>
	 * @copyright buggedcom 2008
	 * @link http://www.buggedcom.co.uk
	 */
	
	function compactor_microtime_float()
	{
	    list($usec, $sec) = explode(" ", microtime());
	    return ((float) $usec + (float) $sec);
	}
	
	
	function compactor_log()
	{
		if(COMPACTOR_LOG === true)
		{
			global $is_admin;
			if($is_admin === true)
			{
				global $CONFIG;
				require_once $CONFIG->pluginspath.'compactor/includes/FirePHPCore/FirePHP.class.php';
				$FB = FirePHP::getInstance(true);
				$args = func_get_args();
				call_user_func_array(array($FB, 'log'), $args);
			}
		}
	}
	
	$_compactor_timers = array();
	function compactor_log_measure($id, $end=false, $estimated=false)
	{
		if(COMPACTOR_LOG === true)
		{
			global $is_admin;
			if($is_admin === true)
			{
				global $_compactor_timers;
				if($end === false)
				{
					$_compactor_timers[$measure] = compactor_microtime_float();
				}
				else if($end === true && isset($_compactor_timers[$measure]))
				{
					$_compactor_timers[$measure] = compactor_microtime_float() - $_compactor_timers[$measure];
					return $_compactor_timers[$measure];
				}
			}
		}
		return 0;
	}

// 	the default settings
	$COMPACTOR_SETTINGS = array(
		'compactor_caching' => 'yes',
		'compactor_cleaning_mode' => 'weekly',
		'compactor__last_cleaned' => 0,
		'compactor_server_cache_age' => 360,
		'compactor_compacting_css_resource' => 'yes',
		'compactor_compacting_js_resource' => 'yes',
		'compactor_deflate_css' => 'yes',
		'compactor_deflate_html' => 'yes',
		'compactor_deflate_js' => 'yes',
		'compactor_join_external_css' => 'yes',
		'compactor_join_external_js' => 'yes',
		'compactor_join_inline_css' => 'no',
		'compactor_join_inline_js' => 'no',
		'compactor_move_inline_css' => 'no',
		'compactor_move_inline_js' => 'no',
		'compactor_optimise_html' => 'yes',
		'compactor_optimise_inline_css' => 'yes',
		'compactor_optimise_inline_js' => 'yes',
		'compactor_etags' => 'yes',
		'compactor_debugging' => 'no'
	);
	
	function compactor_init()
	{
		global $CONFIG, $COMPACTOR_SETTINGS;
		$access = get_access_sql_suffix('e');
		$md_access = get_access_sql_suffix('e');

		$query = 'SELECT n.string AS name, v.string AS value 
				  FROM '.$CONFIG->dbprefix.'metadata AS m 
				  	JOIN '.$CONFIG->dbprefix.'entities AS e ON e.guid = m.entity_guid 
					JOIN '.$CONFIG->dbprefix.'metastrings AS v ON m.value_id = v.id 
					JOIN '.$CONFIG->dbprefix.'metastrings AS n ON m.name_id = n.id 
				  WHERE n.string IN ("compactor_caching","compactor_cleaning_mode","compactor__last_cleaned","compactor_server_cache_age","compactor_optimise_html","compactor_optimise_inline_css","compactor_move_inline_css","compactor_join_inline_css","compactor_join_external_css","compactor_optimise_inline_js","compactor_move_inline_js","compactor_join_inline_js","compactor_join_external_js","compactor_compacting_js_resource","compactor_etags","compactor_compacting_css_resource","compactor_deflate_html","compactor_deflate_js","compactor_deflate_css","compactor_debugging") &&
				 	'.$access.' && '.$md_access.';';
		if($data = get_data($query))
		{
			foreach ($data as $key => $row)
			{
				$COMPACTOR_SETTINGS[$row->name] = $row->value;
			}
		}
		
// 		are we debugging?
		define('COMPACTOR_LOG', $COMPACTOR_SETTINGS['compactor_debugging'] === 'yes');
		
// 		carry out the cache directory cleaning
		compactor_cleanCache();
		
// 		are we caching content?
		$caching = $COMPACTOR_SETTINGS['compactor_caching'] === 'yes';
// 		if so check for sever cache
		if($caching === true)
		{
			compactor_checkServerCache();
//<-p		exits 			
		}

// 		check if it is running
		$running = 
			$COMPACTOR_SETTINGS['compactor_caching'] == 'yes' ||
			$COMPACTOR_SETTINGS['compactor_compacting_css_resource'] == 'yes' ||
			$COMPACTOR_SETTINGS['compactor_compacting_js_resource'] == 'yes' ||
			$COMPACTOR_SETTINGS['compactor_deflate_css'] == 'yes' ||
			$COMPACTOR_SETTINGS['compactor_deflate_html'] == 'yes' ||
			$COMPACTOR_SETTINGS['compactor_deflate_js'] == 'yes' ||
			$COMPACTOR_SETTINGS['compactor_join_external_css'] == 'yes' ||
			$COMPACTOR_SETTINGS['compactor_join_external_js'] == 'yes' ||
			$COMPACTOR_SETTINGS['compactor_join_inline_css'] == 'yes' ||
			$COMPACTOR_SETTINGS['compactor_join_inline_js'] == 'yes' ||
			$COMPACTOR_SETTINGS['compactor_move_inline_css'] == 'yes' ||
			$COMPACTOR_SETTINGS['compactor_move_inline_js'] == 'yes' ||
			$COMPACTOR_SETTINGS['compactor_optimise_html'] == 'yes' ||
			$COMPACTOR_SETTINGS['compactor_optimise_inline_css'] == 'yes' ||
			$COMPACTOR_SETTINGS['compactor_optimise_inline_js'] == 'yes' ||
			$COMPACTOR_SETTINGS['compactor_etags'] == 'yes' ||
			$COMPACTOR_SETTINGS['compactor_debugging'] == 'yes';
		
		if($running === true)
		{
// 			start output buffering ONLY if required we can capture the page
			ob_start();
			register_shutdown_function('compactor_spinIntoAction');
		}
	}
	
	function compactor_cleanCache($force=false)
	{
		global $COMPACTOR_SETTINGS, $is_admin;
// 		do we carry out period cache cleans?
		$cleaning_mode = $COMPACTOR_SETTINGS['compactor_cleaning_mode'];
		$last_cleaned = (float) $COMPACTOR_SETTINGS['compactor__last_cleaned'];
		if($force === false)
		{
			switch($cleaning_mode)
			{
				case 'hourly' :
					$clean_me_please = $_SERVER['REQUEST_TIME'] > $last_cleaned + 360;
					break;
				case 'daily' :
					$clean_me_please = $_SERVER['REQUEST_TIME'] > $last_cleaned + 86400;
					break;
				case false :
				case null :
				case 'weekly' :
					$clean_me_please = $_SERVER['REQUEST_TIME'] > $last_cleaned + 604800;
					break;
				case 'monthly' :
					$clean_me_please = $_SERVER['REQUEST_TIME'] > $last_cleaned + 2419200;
					break;
				case 'bi-monthly' :
					$clean_me_please = $_SERVER['REQUEST_TIME'] > $last_cleaned + 4838400;
					break;
			}
		}
		else
		{
			$clean_me_please = true;
		}
// 		so do wee need a clean?
		if($clean_me_please === true || (isset($_GET['compactor']) && $_GET['compactor'] == 'clean' && $is_admin === true))
		{
			compactor_log_measure('cache_clean');
// 			update the last_cleaned
			set_plugin_setting('_last_cleaned', $_SERVER['REQUEST_TIME'], 'compactor');
			$file_count = 0;
// 			get the max age
			$max_age = (int) $COMPACTOR_SETTINGS['compactor_server_cache_age'];
			$older_than = $_SERVER['REQUEST_TIME'] - $max_age;
// 			get the files
			global $CONFIG;
			$files = glob($CONFIG->pluginspath.'compactor/cache/*');
			foreach ($files as $file)
			{
// 				file is older than the max age
				if($force !== false || filemtime($file) < $older_than)
				{
					@unlink($file);
					$file_count += 1;
				}
			}
			$time = compactor_log_measure('cache_clean', true);
			compactor_log('Cleaned cache repository. Files removed = '.$file_count.' ('.$time.')');
		}
	}
	
	function compactor_spinIntoAction()
	{
		compactor_log_measure('spin');
		global $CONFIG, $COMPACTOR_SETTINGS;
		$source = ob_get_clean();
		$content_type = compactor_contentType();
		switch($content_type)
		{
			case 'text/html' :
			
// 				we have source so check the browser cache, it is irrelavent that the sources sent are compacted and deflated
				$etag_hash = compactor_checkBrowserCache($source);
//<-p			exits 	
		
				compactor_log('Processing HTML...');
				
// 				gather the applicable configs
				$optimise_html 			= $COMPACTOR_SETTINGS['compactor_optimise_html'] === 'yes';
				
				$optimise_css_inline	= $COMPACTOR_SETTINGS['compactor_optimise_inline_css'] === 'yes';
				$move_css_inline 		= $COMPACTOR_SETTINGS['compactor_move_inline_css'] === 'yes';
				$join_inline_css 		= $COMPACTOR_SETTINGS['compactor_join_inline_css'] === 'yes';
				$join_external_css 		= $COMPACTOR_SETTINGS['compactor_join_external_css'] === 'yes';
				
				$optimise_js_inline 	= $COMPACTOR_SETTINGS['compactor_optimise_inline_js'] === 'yes';
				$move_js_inline 		= $COMPACTOR_SETTINGS['compactor_move_inline_js'] === 'yes';
				$join_inline_js 		= $COMPACTOR_SETTINGS['compactor_join_inline_js'] === 'yes';
				$join_external_js 		= $COMPACTOR_SETTINGS['compactor_join_external_js'] === 'yes';
				
				$deflate_html		 	= $COMPACTOR_SETTINGS['compactor_deflate_html'] === 'yes';
				
// 				are we going to optimise the html output?
				if($optimise_html === true)
				{
					$compact_options = array();
				
// 					are we going to be compressing the inline css?
					if($optimise_css_inline === true)
					{
						compactor_log('...will compact inline CSS');
						require $CONFIG->pluginspath.'compactor/includes/minify/min/lib/Minify/CSS.php';
						$compact_options['cssMinifier'] = array('Minify_CSS', 'minify');
					}
				
// 					are we going to be compressing the inline js?
					if($optimise_js_inline === true)
					{
						compactor_log('...will compact inline Javascript');
						require $CONFIG->pluginspath.'compactor/includes/minify/min/lib/JSMin.php';
						require $CONFIG->pluginspath.'compactor/includes/minify/min/lib/Minify/Javascript.php';
						$compact_options['jsMinifier'] = array('Minify_Javascript', 'minify');
					}
				
// 					compact the html
					compactor_log('...compacting');
					require $CONFIG->pluginspath.'compactor/includes/minify/min/lib/Minify/HTML.php';
					$source = Minify_HTML::minify($source, $compact_options);
				}
				
// 				are we going to join anything or move anything?
				if($join_inline_css === true || $move_css_inline === true || $join_external_css === true)
				{
					$source = compactor_processHTMLCSS($source, $join_inline_css, $move_css_inline, $join_external_css);
				}
				if($join_inline_js === true || $move_js_inline === true || $join_external_js === true)
				{
					$source = compactor_processHTMLJs($source, $join_inline_js, $move_js_inline, $join_external_js);
				}
 				
// 				global $dbcalls;
// 				$source = '<!-- '.round(memory_get_usage()/1024/1024, 2).'MB -->
// <!-- '.$dbcalls.' queries -->'.$source;
				
// 				deflate the html
				if($deflate_html === true)
				{
					$source = compactor_deflate($source);
				}
				
				break;
				
			case 'text/javascript' :
				
// 				we have source so check the browser cache, it is irrelavent that the sources sent are compacted and deflated
				$etag_hash = compactor_checkBrowserCache($source);
//<-p			exits 	
		
				compactor_log('Processing Javascript...');
			
// 				gather the applicable configs
				$compacting_js_resource = $COMPACTOR_SETTINGS['compactor_compacting_js_resource'] === 'yes';
				$deflate_js		 		= $COMPACTOR_SETTINGS['compactor_deflate_js'] === 'yes';
				$caching 				= $COMPACTOR_SETTINGS['compactor_caching'] === 'yes';
				$etags	 				= $COMPACTOR_SETTINGS['compactor_etags'] === 'yes';
				
// 				compact the js
				if($compacting_js_resource === true)
				{
					compactor_log('...compacting');
					require $CONFIG->pluginspath.'compactor/includes/minify/min/lib/JSMin.php';
					require $CONFIG->pluginspath.'compactor/includes/minify/min/lib/Minify/Javascript.php';
					$source = Minify_Javascript::minify($source);
				}
				
				$source = '/* generated '.date('Y-m-d H:i:s').' */ '.$source;
				
// 				deflate the js
				if($deflate_js === true)
				{
					$source = compactor_deflate($source);
				}
				
// 				cache the js
				if($caching === true)
				{
					compactor_cache($source, $etag_hash);
				}
				
				break;
				
			case 'text/css' :
				
// 				we have source so check the browser cache, it is irrelavent that the sources sent are compacted and deflated
				$etag_hash = compactor_checkBrowserCache($source);
//<-p			exits 			
				
				compactor_log('Processing CSS...');
			
// 				gather the applicable configs
				$compacting_css_resource = $COMPACTOR_SETTINGS['compactor_compacting_css_resource'] === 'yes';
				$deflate_css		 	 = $COMPACTOR_SETTINGS['compactor_deflate_css'] === 'yes';
				$caching 				 = $COMPACTOR_SETTINGS['compactor_caching'] === 'yes';
				
// 				compact the CSS
				if($compacting_css_resource === true)
				{
					compactor_log('...compacting');
					require $CONFIG->pluginspath.'compactor/includes/minify/min/lib/Minify/CSS.php';
					$source = Minify_CSS::minify($source, array(
						'preserveComments' => false
					));
				}
// 				print_r($CONFIG);
				
				$source = '/* generated '.date('Y-m-d H:i:s').' */ '.$source;
				
// 				deflate the css
				if($deflate_css === true)
				{
					$source = compactor_deflate($source);
				}
				
// 				cache the css
				if($caching === true)
				{
					compactor_cache($source, $etag_hash);
				}
				
				break;
				
			case 'image/jpeg' :
			case 'image/gif' :
			case 'image/png' :
			
// 				we have source so check the browser cache, it is irrelavent that the sources sent are compacted and deflated
				$etag_hash = compactor_checkBrowserCache($source);
//<-p			exits 			
				
				compactor_log('Processing Image...');
			
				$caching = $COMPACTOR_SETTINGS['compactor_caching'] === 'yes';
				
// 				cache the image?
				if($caching)
				{
					compactor_cache($source, $etag_hash);
				}
				
				break;
				
			default :
			
// 				check browser cache etag
				compactor_checkBrowserCache($source);
					
				compactor_log('!! Found other content type: '.$content_type.', perhaps we should use compactor to cache these?');
		}
		
		echo $source;
// 		$time = compactor_log_measure('spin', true);
// 		compactor_log('Compactor all done. Total processing time for page: '.$time);
	}
	
	function compactor_processHTMLCSS($source, $join_inline_css, $move_css_inline, $join_external_css)
	{
		compactor_log_measure('optimise_css');
		preg_match_all('/\\s*(<style\\b[^>]*?>)([\\s\\S]*?)<\\/style>\\s*/i', $source, $matches);
		compactor_log('...found '.count($matches).' css style declarations');
		preg_match_all('!(<link.*?>)!is', $source, $link_matches); // need a better regex so we can get rid of second regex
		$joined = false;
		$to_adjust_find = array();
		$to_adjust_replace = array();
		$to_move = array();
// 		process the joining of scripts
		if($join_inline_css === true)
		{
			compactor_log('...joining inline css');
			$to_join = array();
			$last_join_tag = false;
			if(count($matches[0]) > 0)
			{
				foreach ($matches[0] as $key=>$match)
				{
					$content = trim($matches[2][$key]);
					if(!empty($content))
					{
						array_push($to_adjust_find, $match);
						array_push($to_adjust_replace, '');
						array_push($to_join, $content);
						$last_join_tag = $match;
						unset($matches[0][$key]);
					}
				}
			}
// 			are there any to actually join?
			if(($count = count($to_join)) > 0)
			{
// 				yup, so join
				$joined = '<style type="text/css">'.implode(';', $to_join).'</style>';
// 				are we moving it to the bottom, if so then we have some other stuff to add to the list
				if($move_js_inline === true)
				{
					$to_move[999999999] = $joined;
				}
				else
				{
// 					we're not moving so we will adjust the last tag
					array_push($to_adjust_find, $last_join_tag);
					array_push($to_adjust_replace, $joined);
				}
			}
			compactor_log('...joined '.$count.' css declarations');
		}
		if($join_external_css === true)
		{
			$to_join = array();
			$last_join_tag = false;
			global $CONFIG;
			if(count($link_matches[0]) > 0)
			{
				$css_link_count = 0;
				foreach ($link_matches[0] as $key=>$match)
				{
// 					do we have a src?
					if(preg_match('!type="text/css"!is', $link_matches[1][$key]) > 0)
					{
						if(preg_match('!href="([^"]*)?"!is', $link_matches[1][$key], $src_matches) > 0)
						{
							$src = trim($src_matches[1]);
// 							make sure it's not the main css file
							if($src !== $CONFIG->wwwroot.'_css/css.css' && strpos($src, 'tinymce') === false)
							{
								if(strpos($src, $CONFIG->wwwroot) === 0)
								{
									$src = str_replace($CONFIG->wwwroot, '', $src);
									array_push($to_adjust_find, $match);
									array_push($to_adjust_replace, '');
									array_push($to_join, $src);
									unset($link_matches[0][$key]);
									compactor_log('......adding "'.$src.'" to css join');
								}
							}
						}
						$css_link_count += 1;
					}
				}
				compactor_log('...found '.$css_link_count.' css links');
			}
			compactor_log('...joining external css');
// 			do we have some src's to join?
			if(($count = count($to_join)) > 0)
			{
// 				yup, so join
				$joined = '<link rel="stylesheet" type="text/css" href="'.$CONFIG->wwwroot.'mod/compactor/compress.php?type=css&files='.implode(',', $to_join).'" />';
// 				are we moving it to the bottom, if so then we have some other stuff to add to the list
				if($move_css_inline === true)
				{
// 					push it to front as these files need to load before any other content
					$to_move[0] = $joined;
				}
				else
				{
// 					we're not moving so we will adjust the last tag
					array_push($to_adjust_find, $last_join_tag);
					array_push($to_adjust_replace, $joined);
				}
			}
			compactor_log('...joined '.$count.' css links');
		}
		if($move_css_inline === true)
		{
			compactor_log('...moving css items');
			if(count($matches[0]) > 0)
			{
				foreach ($matches[0] as $key=>$match)
				{
					$to_move[$key+1] = $match;
					array_push($to_adjust_find, $match);
					array_push($to_adjust_replace, '');
				}
			}
			if(count($link_matches[0]) > 0)
			{
				foreach ($link_matches[0] as $key=>$match)
				{
					$to_move[$key+1] = $match;
					array_push($to_adjust_find, $match);
					array_push($to_adjust_replace, '');
				}
			}
		}
		if(($count = count($to_move)) > 0)
		{
			ksort($to_move);
			array_push($to_adjust_find, '<head>');
			array_push($to_adjust_replace, '<head>'.implode('', $to_move));
			compactor_log('...moved '.$count.' css items');
		}
// 		print_r($to_adjust);exit;
// 		are we adjusting any scripts?
		if(($count = count($to_adjust_find)) > 0)
		{
			$source = str_replace($to_adjust_find, $to_adjust_replace, $source);
			compactor_log('...removing '.$count.' unrequired css items');
		}
		$time = compactor_log_measure('optimise_css', true);
		compactor_log('...inline css optimisation complete ('.$time.')');
		return $source;
	}
	
	function compactor_processHTMLJs($source, $join_inline_js, $move_js_inline, $join_external_js)
	{
		compactor_log_measure('optimise_js');
		preg_match_all('/\\s*(<script\\b[^>]*?>)([\\s\\S]*?)<\\/script>\\s*/i', $source, $matches);
		compactor_log('...found '.count($matches[0]).' javascript elements');
		$joined = false;
		$to_adjust_find = array();
		$to_adjust_replace = array();
		$to_move = array();
// 		process the joining of scripts
		if($join_inline_js === true)
		{
			compactor_log('...joining inline javscript');
			$to_join = array();
			$last_join_tag = false;
			if(count($matches[0]) > 0)
			{
				foreach ($matches[0] as $key=>$match)
				{
					$content = trim($matches[2][$key]);
					if(!empty($content))
					{
						array_push($to_adjust_find, $match);
						array_push($to_adjust_replace, '');
						array_push($to_join, $content);
						$last_join_tag = $match;
						unset($matches[0][$key]);
					}
				}
			}
// 			are there any to actually join?
			if(($count = count($to_join)) > 0)
			{
// 				yup, so join
				$joined = '<script type="text/javascript">'.implode(';', $to_join).'</script>';
// 				are we moving it to the bottom, if so then we have some other stuff to add to the list
				if($move_js_inline === true)
				{
					$to_move[999999999] = $joined;
				}
				else
				{
// 					we're not moving so we will adjust the last tag
					array_push($to_adjust_find, $last_join_tag);
					array_push($to_adjust_replace, $joined);
				}
			}
			compactor_log('...joined '.$count.' javascript declarations');
		}
// 		are we joining external resources?
		if($join_external_js === true)
		{
			$to_join = array();
			$last_join_tag = false;
			global $CONFIG;
			if(count($matches[0]) > 0)
			{
				foreach ($matches[0] as $key=>$match)
				{
					$content = trim($matches[2][$key]);
					if(empty($content))
					{
// 						do we have a src?
						if(preg_match('!src="([^"]*)?"!is', $matches[1][$key], $src_matches) > 0)
						{
							$src = trim($src_matches[1]);
// 							make sure it is local
							if(strpos($src, $CONFIG->wwwroot) === 0 && strpos($src, 'tinymce') === false)
							{
								$src = str_replace($CONFIG->wwwroot, '', $src);
// 				 				can't collect pg srcs as they are dynamic
								if(substr($src, 0, 3) !== 'pg/')
								{
// 									check for packed already
// 									if(substr($src, -7) !== 'pack.js' && substr($src, -9) !== 'packed.js')
// 									{
										array_push($to_adjust_find, $match);
										array_push($to_adjust_replace, '');
										array_push($to_join, $src);
										unset($matches[0][$key]);
										compactor_log('......adding "'.$src.'" to javascript join');
// 									}
								}
							}
						}
					}
				}
			}
// 			do we have some src's to join?
			if(($count = count($to_join)) > 0)
			{
// 				yup, so join
				$joined = '<script type="text/javascript" src="'.$CONFIG->wwwroot.'mod/compactor/compress.php?type=js&files='.implode(',', $to_join).'"></script>';
// 				are we moving it to the bottom, if so then we have some other stuff to add to the list
				if($move_js_inline === true)
				{
// 					push it to front as these files need to load before any other content
					$to_move[0] = $joined;
				}
				else
				{
// 					we're not moving so we will adjust the last tag
					array_push($to_adjust_find, '<head>');
					array_push($to_adjust_replace, '<head>'.$joined);
				}
			}
			compactor_log('...joined '.$count.' external javascript sources');
		}
// 		check for moving items
		if($move_js_inline === true)
		{
			compactor_log('...moving javascript items');
			if(count($matches[0]) > 0)
			{
				foreach ($matches[0] as $key=>$match)
				{
					$to_move[$key+1] = $match;
					array_push($to_adjust_find, $match);
					array_push($to_adjust_replace, '');
				}
			}
		}
		if(count($to_move) > 0)
		{
			ksort($to_move);
			array_push($to_adjust_find, '</body>');
			array_push($to_adjust_replace, implode('', $to_move).'</body>');
			compactor_log('...moved '.$count.' javascript items');
		}
// 		print_r($to_adjust);exit;
// 		are we adjusting any scripts?
		if(($count = count($to_adjust_find)) > 0)
		{
			$source = str_replace($to_adjust_find, $to_adjust_replace, $source);
			compactor_log('...removing '.$count.' un-required javascript items');
		}
		$time = compactor_log_measure('optimise_js', true);
		compactor_log('...inline javascript optimisation complete ('.$time.')');
		return $source;
	}
	
	function compactor_deflate($source)
	{
		compactor_log_measure('deflate');
// 		get the sent content type header.
		$content_type = compactor_contentType();
		$content_type = $content_type === false ? 'text/plain' : $content_type;
		
// 		load the deflater
		global $CONFIG;
		require $CONFIG->pluginspath.'compactor/includes/minify/min/lib/HTTP/Encoder.php';
		$he = new HTTP_Encoder(array(
		    'content' => $source,
			'type' => $content_type
		));
// 		encode...
		$he->encode(7);
// 		...and output headers
		$he->sendHeaders();	
// 		return the encoded buffer for possible caching
		$content = $he->getContent();
		$time = compactor_log_measure('deflate', true);
		compactor_log('...deflated ('.$time.')');
		return $content;
	}
	
	function compactor_checkBrowserCache($source, $source_is_etag_hash=false)
	{
		compactor_log_measure('browser_cache');
		compactor_log('Checking browser cache...');
		global $CONFIG;
// 		first valid a browser cache
        require_once $CONFIG->pluginspath.'compactor/includes/minify/min/lib/HTTP/ConditionalGet.php';
		$hash = $source_is_etag_hash === true ? $source : md5($source);
		$cg = new HTTP_ConditionalGet(array(
			'contentHash' => $hash,
			'isPublic' => true,
			'maxAge' => 360
		));
		$cg->sendHeaders();
		$headers = $cg->getHeaders();
		compactor_log($headers, '...sending cache headers');
		if ($cg->cacheIsValid)
		{
			$time = compactor_log_measure('browser_cache', true);
			compactor_log('...browser has valid cache so sending 304 not modified. ('.$time.')');
			exit;
//<-		exits 			
		}
		$time = compactor_log_measure('browser_cache', true);
		compactor_log('...the output is not cached in the browser :-(  ('.$time.')');
		return $hash;
	}
	
	function compactor_checkServerCache()
	{
// 		can't cache html so quite function
		$content_type = compactor_contentType();
		if($content_type === 'text/html')
		{
			return;
		}
		compactor_log('Checking server cache...');
		
		compactor_log_measure('server_cache');

// 		no browser cache the get cached file?
		global $CONFIG, $COMPACTOR_SETTINGS;
		require $CONFIG->pluginspath.'compactor/includes/minify/min/lib/Minify/Cache/File.php';
		$cache = new Minify_Cache_File($CONFIG->pluginspath.'compactor/cache', false);
// 		build cache file id
		$cache_id = md5($_SERVER['PHP_SELF'].$_SERVER['QUERY_STRING']);
		compactor_log('...looking for cache, cache id = '.$cache_id);
// 		check cache
		if($cache->isValid($cache_id, $max_age))
		{
			compactor_log('...server has cache file');
			$data = $cache->fetch($cache_id);
			$data = unserialize($data);
			$content_type = $data['type'];
			$source = base64_decode($data['source']);
			compactor_log('...cache content type = '.$content_type);
			
// 			we have source so check the browser cache
			compactor_checkBrowserCache($data['hash'], true);
//<-p		exits 			
			
// 			$source = $data['source'];
// 			is this cache deflated?
			$deflated = false;
			switch($content_type)
			{
				case 'text/html' :
					$deflated = $COMPACTOR_SETTINGS['compactor_deflate_html'] === 'yes';
					break;
				
				case 'text/javascript' :
					$deflated = $COMPACTOR_SETTINGS['compactor_deflate_js'] === 'yes';
					break;
				
				case 'text/css' :
					$deflated = $COMPACTOR_SETTINGS['compactor_deflate_css'] === 'yes';
					break;
					
			}
// 			die($source);
			if($deflated === true)
			{
				compactor_log('...cache file is deflated');
// 				it is deflated so output headers
				require $CONFIG->pluginspath.'compactor/includes/minify/min/lib/HTTP/Encoder.php';
				$encoding = HTTP_Encoder::getAcceptedEncoding();
				header('Content-Length: '.strlen($source));
				header('Content-Encoding: '.$encoding[1]);
				header('Vary: Accept-Encoding');
			}
			header('Content-Type: '.$content_type);
// 			now output the source
			echo $source;
			$time = compactor_log_measure('server_cache', true);
			compactor_log('...server cache outputted ('.$time.')');
			exit;
//<-		exits 			
		}
		$time = compactor_log_measure('server_cache', true);
		compactor_log('...no cache exists. :-(  ('.$time.')');
	}
	
	function compactor_cache($source, $etag_hash)
	{
		compactor_log_measure('caching');
// 		build cache file id
		$content_type = compactor_contentType();
		$cache_id = md5($_SERVER['PHP_SELF'].$_SERVER['QUERY_STRING']);
// 		save file
		global $CONFIG;
		$cache = new Minify_Cache_File($CONFIG->pluginspath.'compactor/cache', true);
		$result = $cache->store($cache_id, serialize(array(
			'hash' => $etag_hash,  
			'source' => base64_encode($source),  
			'type' => $content_type
		)));
		$time = compactor_log_measure('caching', true);
		compactor_log('...caching, cache id = '.$cache_id.' ('.$time.')');
	}
	
	function compactor_contentType()
	{
		static $content_type;
		if($content_type)
		{
			return $content_type;
		}
		$content_type = false;
		$headers = headers_list();
		foreach ($headers as $header)
		{
			$header = strtolower($header);
			preg_match('/content\-type: (.*)/', $header, $matches);
			if(count($matches))
			{
				$parts = explode(';', $matches[1]);
				$content_type = strtolower($parts[0]);
				break;
			}
		}
		return $content_type;
	}
	
	register_elgg_event_handler('init', 'system', 'compactor_init');
	register_action('compactor/wipe', false, $CONFIG->pluginspath . 'compactor/actions/wipe.php');
	
