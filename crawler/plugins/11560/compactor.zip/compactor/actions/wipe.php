<?php

	global $CONFIG;
	
	admin_gatekeeper();
	
	$files = glob($CONFIG->pluginspath.'compactor/cache/*');
	foreach ($files as $file)
	{
		@unlink($file);
	}
	
	system_message(elgg_echo('compactor:settings:clean_now_options:wiped'));
	
	forward($CONFIG->wwwroot.'pg/admin/plugins/');
	
