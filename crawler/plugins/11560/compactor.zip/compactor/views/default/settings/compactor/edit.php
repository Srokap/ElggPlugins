<?php

	global $COMPACTOR_SETTINGS;

// 	html
	$optimise_html 			= $COMPACTOR_SETTINGS['compactor_optimise_html'] === 'yes';
	
	$optimise_css_inline	= $COMPACTOR_SETTINGS['compactor_optimise_inline_css'] === 'yes';
	$move_inline_css 		= $COMPACTOR_SETTINGS['compactor_move_inline_css'] === 'yes';
	$join_inline_css 		= $COMPACTOR_SETTINGS['compactor_join_inline_css'] === 'yes';
	
	$optimise_js_inline 	= $COMPACTOR_SETTINGS['compactor_optimise_inline_js'] === 'yes';
	$move_js_inline 		= $COMPACTOR_SETTINGS['compactor_move_inline_js'] === 'yes';
	$join_inline_js 		= $COMPACTOR_SETTINGS['compactor_join_inline_js'] === 'yes';
	
	$deflate_html		 	= $COMPACTOR_SETTINGS['compactor_deflate_html'] === 'yes';

// 	js
	$compacting_js_resource = $COMPACTOR_SETTINGS['compactor_compacting_js_resource'] === 'yes';
	$deflate_js		 		= $COMPACTOR_SETTINGS['compactor_deflate_js'] === 'yes';
	$join_external_js 		= $COMPACTOR_SETTINGS['compactor_join_external_js'] === 'yes';

// 	css 
	$compacting_css_resource = $COMPACTOR_SETTINGS['compactor_compacting_css_resource'] === 'yes';
	$deflate_css		 	 = $COMPACTOR_SETTINGS['compactor_deflate_css'] === 'yes';
	$join_external_css 		= $COMPACTOR_SETTINGS['compactor_join_external_css'] === 'yes';
	
// 	shared
	$caching 				 = $COMPACTOR_SETTINGS['compactor_caching'] === 'yes';
	
// 	etags for everybody
	$cleaning_mode 			= $COMPACTOR_SETTINGS['compactor_cleaning_mode'];
	$server_cache_age 		= (int) $COMPACTOR_SETTINGS['compactor_server_cache_age'];
	
	$debugging 				= $COMPACTOR_SETTINGS['compactor_debugging'] === 'yes';
	
?><p>
	<?php echo elgg_echo('compactor:settings:info'); ?>
	<br />
	<br />
</p>
<p>
	<h3><?php echo elgg_echo('compactor:settings:inline_options'); ?>: </h3>
</p>
<p>
	<h4><?php echo elgg_echo('compactor:settings:css_inline'); ?>: </h4>
	<?php echo elgg_echo('compactor:settings:css_inline:info'); ?><br />
	<input type="radio" name="params[compactor_optimise_inline_css]" id="optimise_inline_css-yes" class="input-radio" value="yes" <?php echo $optimise_css_inline === true ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="optimise_inline_css-yes"><?php echo elgg_echo('compactor:settings:label:yes');?></label>
	<input type="radio" name="params[compactor_optimise_inline_css]" id="optimise_inline_css-no" class="input-radio" value="no" <?php echo $optimise_css_inline === false ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="optimise_inline_css-no"><?php echo elgg_echo('compactor:settings:label:no');?></label><br />
	<br />
	<?php echo elgg_echo('compactor:settings:css_inline:move'); ?><br />
	<input type="radio" name="params[compactor_move_inline_css]" id="move_inline_css-yes" class="input-radio" value="yes" <?php echo $move_inline_css === true ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="move_inline_css-yes"><?php echo elgg_echo('compactor:settings:label:yes');?></label>
	<input type="radio" name="params[compactor_move_inline_css]" id="move_inline_css-no" class="input-radio" value="no" <?php echo $move_inline_css === false ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="move_inline_css-no"><?php echo elgg_echo('compactor:settings:label:no');?></label><br />
	<br />
	<?php echo elgg_echo('compactor:settings:css_inline:join'); ?><br />
	<input type="radio" name="params[compactor_join_inline_css]" id="join_inline_css-yes" class="input-radio" value="yes" <?php echo $join_inline_css === true ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="join_inline_css-yes"><?php echo elgg_echo('compactor:settings:label:yes');?></label>
	<input type="radio" name="params[compactor_join_inline_css]" id="join_inline_css-no" class="input-radio" value="no" <?php echo $join_inline_css === false ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="join_inline_css-no"><?php echo elgg_echo('compactor:settings:label:no');?></label><br />
	<br />
</p>
<p>
	<h4><?php echo elgg_echo('compactor:settings:js_inline'); ?>: </h4>
	<?php echo elgg_echo('compactor:settings:js_inline:info'); ?><br />
	<input type="radio" name="params[compactor_optimise_inline_js]" id="optimise_inline_js-yes" class="input-radio" value="yes" <?php echo $optimise_js_inline === true ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="optimise_inline_js-yes"><?php echo elgg_echo('compactor:settings:label:yes');?></label>
	<input type="radio" name="params[compactor_optimise_inline_js]" id="optimise_inline_js-no" class="input-radio" value="no" <?php echo $optimise_js_inline === false ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="optimise_inline_js-no"><?php echo elgg_echo('compactor:settings:label:no');?></label><br />
	<br />
	<?php echo elgg_echo('compactor:settings:js_inline:move'); ?><br />
	<input type="radio" name="params[compactor_move_inline_js]" id="move_inline_js-yes" class="input-radio" value="yes" <?php echo $move_js_inline === true ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="move_inline_js-yes"><?php echo elgg_echo('compactor:settings:label:yes');?></label>
	<input type="radio" name="params[compactor_move_inline_js]" id="move_inline_js-no" class="input-radio" value="no" <?php echo $move_js_inline === false ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="move_inline_js-no"><?php echo elgg_echo('compactor:settings:label:no');?></label><br />
	<br />
	<?php echo elgg_echo('compactor:settings:js_inline:join'); ?><br />
	<input type="radio" name="params[compactor_join_inline_js]" id="join_inline_js-yes" class="input-radio" value="yes" <?php echo $join_inline_js === true ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="join_inline_js-yes"><?php echo elgg_echo('compactor:settings:label:yes');?></label>
	<input type="radio" name="params[compactor_join_inline_js]" id="join_inline_js-no" class="input-radio" value="no" <?php echo $join_inline_js === false ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="join_inline_js-no"><?php echo elgg_echo('compactor:settings:label:no');?></label><br />
	<br />
</p>
<p>
	<h4><?php echo elgg_echo('compactor:settings:html_inline'); ?>: </h4>
	<?php echo elgg_echo('compactor:settings:html_inline:info'); ?><br />
	<input type="radio" name="params[compactor_optimise_html]" id="optimise_html-yes" class="input-radio" value="yes" <?php echo $optimise_html === true ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="optimise_html-yes"><?php echo elgg_echo('compactor:settings:label:yes');?></label>
	<input type="radio" name="params[compactor_optimise_html]" id="optimise_html-no" class="input-radio" value="no" <?php echo $optimise_html === false ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="optimise_html-no"><?php echo elgg_echo('compactor:settings:label:no');?></label><br />
	<br />
</p>
<p>
	<h3><?php echo elgg_echo('compactor:settings:external_options'); ?>: </h3>
</p>
<p>
	<h4><?php echo elgg_echo('compactor:settings:compact_css_resources'); ?>: </h4>
	<?php echo elgg_echo('compactor:settings:compact_css_resources:info'); ?><br />
	<input type="radio" name="params[compactor_compacting_css_resource]" id="compacting_css_resource-yes" class="input-radio" value="yes" <?php echo $compacting_css_resource === true ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="compacting_css_resource-yes"><?php echo elgg_echo('compactor:settings:label:yes');?></label>
	<input type="radio" name="params[compactor_compacting_css_resource]" id="compacting_css_resource-no" class="input-radio" value="no" <?php echo $compacting_css_resource === false ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="compacting_css_resource-no"><?php echo elgg_echo('compactor:settings:label:no');?></label><br />
	<br />
	<?php echo elgg_echo('compactor:settings:join_css_resources:info'); ?><br />
	<input type="radio" name="params[compactor_join_external_css]" id="join_external_css-yes" class="input-radio" value="yes" <?php echo $join_external_css === true ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="join_external_css-yes"><?php echo elgg_echo('compactor:settings:label:yes');?></label>
	<input type="radio" name="params[compactor_join_external_css]" id="join_external_css-no" class="input-radio" value="no" <?php echo $join_external_css === false ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="join_external_css-no"><?php echo elgg_echo('compactor:settings:label:no');?></label><br />
	<br />
</p>
<p>
	<h4><?php echo elgg_echo('compactor:settings:compact_js_resources'); ?>: </h4>
	<?php echo elgg_echo('compactor:settings:compact_js_resources:info'); ?><br />
	<input type="radio" name="params[compactor_compacting_js_resource]" id="compacting_js_resource-yes" class="input-radio" value="yes" <?php echo $compacting_js_resource === true ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="compacting_js_resource-yes"><?php echo elgg_echo('compactor:settings:label:yes');?></label>
	<input type="radio" name="params[compactor_compacting_js_resource]" id="compacting_js_resource-no" class="input-radio" value="no" <?php echo $compacting_js_resource === false ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="compacting_js_resource-no"><?php echo elgg_echo('compactor:settings:label:no');?></label><br />
	<br />
	<?php echo elgg_echo('compactor:settings:join_js_resources:info'); ?><br />
	<input type="radio" name="params[compactor_join_external_js]" id="join_external_js-yes" class="input-radio" value="yes" <?php echo $join_external_js === true ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="join_external_js-yes"><?php echo elgg_echo('compactor:settings:label:yes');?></label>
	<input type="radio" name="params[compactor_join_external_js]" id="join_external_js-no" class="input-radio" value="no" <?php echo $join_external_js === false ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="join_external_js-no"><?php echo elgg_echo('compactor:settings:label:no');?></label><br />
	<br />
</p>
<p>
	<h3><?php echo elgg_echo('compactor:settings:deflate_options'); ?>: </h3>
</p>
<p>
	<?php echo elgg_echo('compactor:settings:deflate_options:info'); ?><br />
	<br />
	<h4><?php echo elgg_echo('compactor:settings:deflate_html'); ?>: </h4>
	<input type="radio" name="params[compactor_deflate_html]" id="deflate_html-yes" class="input-radio" value="yes" <?php echo $deflate_html === true ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="deflate_html-yes"><?php echo elgg_echo('compactor:settings:label:yes');?></label>
	<input type="radio" name="params[compactor_deflate_html]" id="deflate_html-no" class="input-radio" value="no" <?php echo $deflate_html === false ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="deflate_html-no"><?php echo elgg_echo('compactor:settings:label:no');?></label><br />
	<br />
	<h4><?php echo elgg_echo('compactor:settings:deflate_css_resources'); ?>: </h4>
	<input type="radio" name="params[compactor_deflate_css]" id="deflate_css-yes" class="input-radio" value="yes" <?php echo $deflate_css === true ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="deflate_css-yes"><?php echo elgg_echo('compactor:settings:label:yes');?></label>
	<input type="radio" name="params[compactor_deflate_css]" id="deflate_css-no" class="input-radio" value="no" <?php echo $deflate_css === false ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="deflate_css-no"><?php echo elgg_echo('compactor:settings:label:no');?></label><br />
	<br />
	<h4><?php echo elgg_echo('compactor:settings:deflate_js_resources'); ?>: </h4>
	<input type="radio" name="params[compactor_deflate_js]" id="deflate_js-yes" class="input-radio" value="yes" <?php echo $deflate_js === true ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="deflate_js-yes"><?php echo elgg_echo('compactor:settings:label:yes');?></label>
	<input type="radio" name="params[compactor_deflate_js]" id="deflate_js-no" class="input-radio" value="no" <?php echo $deflate_js === false ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="deflate_js-no"><?php echo elgg_echo('compactor:settings:label:no');?></label><br />
	<br />
</p>
<p>
	<h3><?php echo elgg_echo('compactor:settings:cache_options'); ?>: </h3>
</p>
<p>
	<?php echo elgg_echo('compactor:settings:cache_options:info'); ?><br />
	<input type="radio" name="params[compactor_caching]" id="caching-yes" class="input-radio" value="yes" <?php echo $caching === true ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="caching-yes"><?php echo elgg_echo('compactor:settings:label:yes');?></label>
	<input type="radio" name="params[compactor_caching]" id="caching-no" class="input-radio" value="no" <?php echo $caching === false ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="caching-no"><?php echo elgg_echo('compactor:settings:label:no');?></label><br />
	<br />
	<?php echo elgg_echo('compactor:settings:cache_options:cleaning_mode:info'); ?><br />
	<?php echo elgg_view('input/pulldown', array('value'=>$cleaning_mode, 'options_values'=>array('hourly'=>'hourly', 'daily'=>'daily', 'weekly'=>'weekly', 'monthly'=>'monthly', 'bi-monthly'=>'bi-monthly'), 'internalname'=>'params[compactor_cleaning_mode]')); ?><br />
	<br />
	<?php echo elgg_echo('compactor:settings:cache_options:server_cache_age:info'); ?><br />
	<?php echo elgg_view('input/text', array('value'=>$server_cache_age, 'internalname'=>'params[compactor_server_cache_age]')); ?><br />
	<br />
</p>
<p>
	<h3><?php echo elgg_echo('compactor:settings:clean_now_options'); ?>: </h3>
</p>
<p>
	<a href="<?php echo $CONFIG->wwwroot; ?>action/compactor/wipe"><?php echo elgg_echo('compactor:settings:clean_now_options:click'); ?></a> <?php echo elgg_echo('compactor:settings:clean_now_options:info'); ?><br />
	<br />
</p>
<p>
	<h3><?php echo elgg_echo('compactor:settings:debug_options'); ?>: </h3>
</p>
<p>
	<?php echo elgg_echo('compactor:settings:debug_options:info'); ?><br />
	<input type="radio" name="params[compactor_debugging]" id="debugging-yes" class="input-radio" value="yes" <?php echo $debugging === true ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="debugging-yes"><?php echo elgg_echo('compactor:settings:label:yes');?></label>
	<input type="radio" name="params[compactor_debugging]" id="debugging-no" class="input-radio" value="no" <?php echo $debugging === false ? 'checked="checked" ' : ''; ?> /><label style="font-size:12px;"for="debugging-no"><?php echo elgg_echo('compactor:settings:label:no');?></label><br />
	<br />
</p>
