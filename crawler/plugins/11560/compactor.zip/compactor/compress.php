<?php

	switch($_GET['type'])
	{
		case 'js' :
			$sep = ';';
			header('Content-Type: text/javascript');
			break;
		case 'css' :
			$sep = '';
			header('Content-Type: text/css');
			break;
		default :
		 	echo 'dude seriously wtf?!';
			exit;
	}
	
	require_once dirname(dirname(dirname(__FILE__))) . '/engine/start.php';
	
	global $is_admin;
	
// 	get the incoming files
	$files = explode(',', $_GET['files']);
	$contents = '';
	foreach ($files as $file)
	{
		if(substr($file, 0, 3) !== 'pg/')
		{
// 			get realpath
			$filepath = realpath($CONFIG->path.$file);
			if($filepath !== false)
			{
// 				check file is under root as some system falsley report realpath not as 
// 				false even though the file doesn't exit
				if(strpos($filepath, $CONFIG->path) === 0)
				{
// 					get the contents of the file
					if(is_file($filepath))
					{
						$file_contents = file_get_contents($filepath);
						if($_GET['type'] === 'css')
						{
							require_once $CONFIG->pluginspath.'compactor/includes/minify/min/lib/Minify/CSS/UriRewriter.php';
							$file_contents = Minify_CSS_UriRewriter::rewrite($file_contents, dirname($filepath));
						}
						$contents .= $file_contents.$sep;
					}
// 					else
// 					{
// 						if($_GET['type'] == 'js' && $is_admin)
// 						{
// 							$contents .= 'alert("'.$file.' is missing!")';
// 						}
// 					}
				}
			}
		}
		else
		{
// 			translate the pg files, we have to eval them as php
// 			print_r(array($file));
		}
	}
	
// 	echo out the js to be picked up and processed by the start file
	echo $contents;
	