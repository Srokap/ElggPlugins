<?php 
	global $CONFIG;
	echo '<script type="text/javascript" src="'. $CONFIG->wwwroot .'mod/embedit/js/swfobject/swfobject.js"></script>';
?>