<?php 

	global $CONFIG;
	echo '<link rel="stylesheet" type="text/css" href="'.$vars['url'].'mod/smartfiles/css/admin.css" />';

?>