<?php

global $CONFIG;

$username = get_input('username');
$user = get_user_by_username($username);

$title = sprintf(elgg_echo('hypePortfolio:emailof'), $user->name);
$header = elgg_view('page_elements/title', array('title' => $title));

if (is_plugin_enabled('phpmailer')) { 
$body = elgg_view('hypePortfolio/forms/email', array('entity' => $user));
$body = elgg_view('page_elements/contentwrapper', array('body' => $body));
$body = elgg_view_layout('two_column_left_sidebar', $area1, $header . $body, $area3);
} else {
	$body = elgg_echo('hypePortfolio:phpmailerrequired');
}

page_draw($title, $body);

?>
