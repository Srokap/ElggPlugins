<?php

global $CONFIG;

$username = get_input('username');
if ($username) {
    $user = get_user_by_username($username);
} else {
    $user = get_loggedin_user();
}
$area3 = elgg_view('hypePortfolio/userdetails', array('entity' => $user));
$area2 = elgg_view('hypePortfolio/portfolio', array('entity' => $user));

$area4 = elgg_view('profile/menu/links', array('entity' => $user));
$area4 = elgg_view('hypeFramework/wrappers/horizontalmenu', array('body' => $area4));

$title = sprintf(elgg_echo('hypePortfolio:portfolio'), $user->name);

$body = elgg_view_layout('hypeFramework/two_column', $area1, $area2, $area3, $area4);
$body = elgg_view('hypeFramework/wrappers/body', array('body' => $body));

$body = elgg_view_layout('widgets', $body);

//Wrap around profile widgets
//$body = elgg_view('hypeFramework/two_column', array('area1' => $area1, 'area2' => $body, 'area3' => $area3));
//$body = elgg_view_layout('widgets', $body);

page_draw($title, $body);
?>
