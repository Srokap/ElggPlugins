<?php

/* hype Portfolio
 *
 * User Portfolio for hype
 * @package hype
 * @subpackage Portfolio
 *
 * @author Ismayil Khayredinov <ismayil.khayredinov@gmail.com>
 * @copyright Copyrigh (c) 2011, Ismayil Khayredinov
 */

function hypePortfolio_init() {

    global $CONFIG;

    if (!is_plugin_enabled('hypeFramework')) {
        register_error('hypeFramework is not enabled. hypePortfolio will not work properly. Visit www.hypeJunction.com for details');
    }

    register_action('portfolio/actions', true, $CONFIG->pluginspath . 'hypePortfolio/actions/actions.php', false);
    register_action('portfolio/save', false, $CONFIG->pluginspath . 'hypePortfolio/actions/save.php', false);
    register_action('portfolio/email', false, $CONFIG->pluginspath . 'hypePortfolio/actions/email.php', false);

    register_page_handler('portfolio', 'hypePortfolio_page_handler');
    $replace_profile = get_plugin_setting('hj_portfolio_replace_profile', 'hypePortfolio');
    if (empty($replace_profile) || $replace_profile == 'replace') {
        register_entity_url_handler('hypePortfolio_profile_url', 'user', 'all');
    } else {
        add_menu(elgg_echo('hypePortfolio:menu'), $CONFIG->wwwroot . 'pg/portfolio/' . get_loggedin_user()->username);
    }

    elgg_extend_view('css', 'hypePortfolio/css');
    elgg_extend_view('hypePortfolio/portfolio', 'hypePortfolio/js/portfolio');

    if (isloggedin ())
        elgg_extend_view('hypePortfolio/portfolio', 'hypePortfolio/menu');
}

function hypePortfolio_page_handler($page) {
    global $CONFIG;

    if (isset($page[0])) {
        set_input('username', $page[0]);
        if ($page[1] == 'print') {
            include($CONFIG->pluginspath . 'hypePortfolio/print.php');
        } else if ($page[1] == 'email') {
            include($CONFIG->pluginspath . 'hypePortfolio/email.php');
        } else {
            include($CONFIG->pluginspath . 'hypePortfolio/portfolio.php');
        }
    } elseif (isloggedin ()) {
        set_input('username', $_SESSION['user']->username);
        include($CONFIG->pluginspath . 'hypePortfolio/portfolio.php');
    } else {
        register_error(elgg_echo('hypePortfolio:cannotdisplay'));
        forward($_SERVER['HTTP_REFERER']);
    }
}

function hypePortfolio_profile_url($user) {
    global $CONFIG;
    return $CONFIG->wwwroot . "pg/portfolio/" . $user->username;
}

function file_referencing($event, $object_type, $object) {
    if ($object instanceof ElggFile) {
        if (get_input('reference'))
            $object->reference = get_input('reference');
    }
}

register_elgg_event_handler('init', 'system', 'hypePortfolio_init');
register_elgg_event_handler('create', 'object', 'file_referencing');
register_elgg_event_handler('update', 'object', 'file_referencing');

include_once(dirname(__FILE__) . '/models/model.php');
?>