hypePortfolio is part of the hype bundle

hypePortfolio is a replacement for a standard Elgg profile that allows your users to showcase various aspects of their professional or academic career

Main features include:
    - Easy and user-friendly navigation
    - AJAX-powered content loading (does not require page reloading)
    - Relatively easy customization of sections and fields / Scalable data model
    - Support for dropdown fields
- Default sections are:
    Work Experience
    Educational Background
    Awards and Achievements
    Skills
Files (requires core File plugin)
    - Possibility to extend the portfolio with custom views
    - Updates are fed to the activity
    - Printer-friendly Portfolio
    - Feature to send Portfolio as an email with file attachments - requires PHPmailer by Cash *http://community.elgg.org/pg/plugins/project/384769/developer/costelloc/phpmailer

INSTALLATION
1. Download and install hype Framework from www.hypeFramework.com
2. Load the archive folder to your server: your-elgg-installation.com/mod/
3. Ensure that the unarchived folder is not nested, that is the filepath to start.php is as follow:
your-elgg-installation.com/mod/hypePortfolio/start.php
4. Go to your Elgg site -> Administration -> Tool Administration.
5. Find hype Portfolio and enable it.
6. Ensure that the hype Portfolio is below profile, file, profile_manager on the plugin list.

CONFIGURATION
1. The plugin is integrated with Profile Manager plugin by Jeroen (no modifications were made to the profile_manager files, so process for updating details is standard)
2. To enable the emailing feature, you will need installed and configured PHPmailer plugin by Cash. You do not necessarily need to replace Elgg's default mailer function.
3. To enable the widgets, uncomment line 22 in portfolio.php
4. To add new buttons and views, refer to views/default/hypePortfolio/navigation_extras.php and testview.php.