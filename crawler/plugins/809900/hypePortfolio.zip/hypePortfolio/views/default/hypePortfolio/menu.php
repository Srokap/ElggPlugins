<div class="portfolio_extras">
    <?php
    if (isloggedin ()) {
        if ($_SESSION['user']->getGUID() != $vars['entity']->getGUID()) {

            $ts = time();
            $token = generate_action_token($ts);

            if ($vars['entity']->isFriend()) {
                echo "<p class=\"right\"><a class=\"button\" href=\"{$vars['url']}action/friends/remove?friend={$vars['entity']->getGUID()}&__elgg_token=$token&__elgg_ts=$ts\">Remove from friends</a></p>";
            } else {
                echo "<p class=\"right\"><a class=\"button\" href=\"{$vars['url']}action/friends/add?friend={$vars['entity']->getGUID()}&__elgg_token=$token&__elgg_ts=$ts\">Add as friend</a></p>";
            }
        }
    }
    ?>
    <p class="portfolio_print right">
        <?php
        echo '<a class="button" href="' . $vars['url'] . 'pg/portfolio/' . $vars['entity']->username . '/print">' . elgg_echo('hypePortfolio:print') . '</a>';
        ?>
    </p>
    <?php if (is_plugin_enabled('phpmailer')) {
    ?>
            <p class="portfolio_email right">
        <?php
            echo '<a class="button" href="' . $vars['url'] . 'pg/portfolio/' . $vars['entity']->username . '/email">' . elgg_echo('hypePortfolio:email') . '</a>';
        ?>
        </p>

    <?php } ?>
    <?php echo elgg_view('hypePortfolio/portfolioextras', $vars); ?>
</div>
<div class="clearfloat"></div>