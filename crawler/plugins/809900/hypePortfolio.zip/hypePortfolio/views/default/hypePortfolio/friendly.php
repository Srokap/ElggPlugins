<div id="print_container" style="width:100%;max-width:650px;margin:0 auto;">
    <?php
    $username = $vars['username'];
    $user = get_user_by_username($username);

    $hypePortfolio_data = get_hypePortfolio_settings();
    ?>
    <table style="font-size:12px;width:100%;max-width:650px;">
    <tr>
    <td>
    <div class="details" style="margin:20px 0 10px;padding-bottom:10px;border-bottom:3px solid #ccc;min-height:45px;">
        <div style="float:left">
            <div class="name" style="font-size:30px;font-weight:bold;"><?php echo $user->name ?></div>
            <div class="email"><?php echo $user->email ?></div>
        </div>
        <div class="icon" style="float:right;margin:10px 10px 0 0;"><?php echo elgg_view('profile/icon', array('entity' => $user, 'size' => 'small', 'override' => true)); ?></div>
        <div style="clear:both"></div>
    </div>
    </td>
    </tr>
	<tr>
    <td>
    <div class="portfolio" style="margin:20px;">
        <?php
        foreach ($hypePortfolio_data as $subtype => $ePortfilio_items) {
            if ($subtype !== 'file') {
                echo '<div class="section" style="font-size:14px;font-weight:bold;padding:3px;border-bottom:1px solid #ccc;margin:10px 0;">' . $ePortfilio_items['river'] . '</div>';
                $subtypes = $ePortfilio_items['subtypes'];
                foreach ($subtypes as $ref => $value) {
					$metasort = NULL;
					if (in_array('start_year', $value['fields'])) $metasort = array('name' => 'start_year', 'direction' => DESC, 'as' => text);
                    $options = array(
                        'metadata_name' => 'reference',
                        'metadata_value' => $ref,
                        'type' => 'object',
                        'subtype' => $subtype,
                        'owner_guid' => $user->guid,
                        'limit' => 500,
                        'order_by_metadata' => $metasort
                    );
                    $objects = elgg_get_entities_from_metadata($options);
                    echo '<div ref="' . $ref . '" class="subnavigation_content">';
                    if ($objects) {
                        echo '<div class="subsection" style="font-style:italic;margin-bottom:10px;">' . $value['display_name'] . '</div>';
                        foreach ($objects as $object) {
                            echo '<div class="portfolio_item" style="margin:0 10px 20px;color:#222;">' . elgg_view_entity($object) . '</div>';
                        }
                    }
                    echo '</div>';
                }
            }
        }
        ?>
    </div>
    </td>
    </tr>
    </table>
</div>