<script type="text/javascript">
    function check_mandatory_fields(form_container) {
        var check = true;
        $('.mandatory', form_container).each(function(){
            if ($(this).val() == '') {
                check = false;
            }
        });
        if (!check) alert('<?php echo elgg_echo('portfolio:mandatoryfieldmissing') ?>');
        return check;
    }
</script>
<form action="<?php echo $vars['url']; ?>action/portfolio/save" method="post" enctype="multipart/form-data" onsubmit="return check_mandatory_fields($(this));">
    <?php
    if ($vars['subtype']) {
        $subtype = $vars['subtype'];
    } else {
        $subtype = $vars['entity']->getSubtype();
    }
    if ($vars['reference']) {
        $reference = $vars['reference'];
    } else {
        $reference = $vars['entity']->reference;
    }

    $hypePortfolio_items = get_hypePortfolio_settings();
    $hypePortfolio_items = $hypePortfolio_items[$subtype]['subtypes'][$reference];
    $hypePortfolio_fields_details = get_fields_by_subtype($reference, $hypePortfolio_items['fields']);

    if (!$vars['entity']) {
        foreach ($hypePortfolio_fields_details as $ref => $value) {
            $vars['entity']->$ref = '';
        }
    }

    echo '<div id="formWrapper">';
    echo elgg_view('input/securitytoken');
    foreach ($hypePortfolio_fields_details as $ref => $value) {
        echo '<div><label>' . elgg_echo($value['display_name']) . '</label>' . elgg_view('input/' . $value['type'], array('value' => $vars['entity']->$ref,
            'internalname' => $ref, 'options' => $value['options'], 'class' => $value['class'])) . '</div>';
    }

    echo '<p><label>' . elgg_echo('hypePortfolio:access') . '</label>' . elgg_view('input/access', array('internalname' => 'access_id', 'value' => $vars['entity']->access_id)) . '</p>';
    echo elgg_view('input/hidden', array('value' => $vars['entity']->guid, 'internalname' => 'object_guid'));
    echo elgg_view('input/hidden', array('value' => $vars['user']->guid, 'internalname' => 'user_guid'));
    echo elgg_view('input/hidden', array('value' => $subtype, 'internalname' => 'subtype'));
    echo elgg_view('input/hidden', array('value' => $reference, 'internalname' => 'reference'));

    echo elgg_view('input/submit', array('value' => 'save', 'internalname' => 'save'));
    echo '</div>';
    ?>
</form>