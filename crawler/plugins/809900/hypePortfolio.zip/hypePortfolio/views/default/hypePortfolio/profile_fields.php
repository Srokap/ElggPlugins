<?php
// display the users name
//echo "<h2><a href=\"" . $vars['entity']->getUrl() . "\" $rel>" . $vars['entity']->name . "</a></h2>";

//insert a view that can be extended
//echo elgg_view("profile/status", array("entity" => $vars['entity']));

if ($vars['full'] == true) {
?>
<?php
    $even_odd = null;

    if (is_array($vars['config']->profile) && sizeof($vars['config']->profile) > 0)
        foreach ($vars['config']->profile as $shortname => $valtype) {
            if ($shortname != "description") {
                $value = $vars['entity']->$shortname;
                if (!empty($value)) {

                    //This function controls the alternating class
                    $even_odd = ( 'odd' != $even_odd ) ? 'odd' : 'even';
?>
                    <p class="<?php echo $even_odd; ?>">
                        <b><?php
                    echo elgg_echo("profile:{$shortname}");
?>: </b>
<?php
                    $options = array(
                        'value' => $vars['entity']->$shortname
                    );

                    if ($valtype == 'tags') {
                        $options['tag_names'] = $shortname;
                    }

                    echo elgg_view("output/{$valtype}", $options);
?>

                </p>

    <?php
                }
            }
        }
}
    ?>