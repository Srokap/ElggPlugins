<?php

//echo $vars['varname'];
//echo $vars['entity']->username;

?>
