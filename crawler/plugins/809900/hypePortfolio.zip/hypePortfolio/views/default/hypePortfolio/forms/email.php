<?php

$user = $vars['entity'];

$form_body = '<div><label>' . elgg_echo('hypePortfolio:email:from') . '</label>' . elgg_view('input/email', array('value' => $_SESSION['user']->email,
        'internalname' => 'email_from', 'disabled' => 'disabled')) . '</div>';

$form_body .= '<div><label>' . elgg_echo('hypePortfolio:email:to') . '</label>' . elgg_view('input/email', array('internalname' => 'email_to')) . '</div>';

$form_body .= '<div><label>' . elgg_echo('hypePortfolio:email:subjectlabel') . '</label>' . elgg_view('input/text', array('value' => sprintf(elgg_echo('hypePortfolio:email:subject'), $user->name), 'internalname' => 'email_subject')) . '</div>';

$form_body .= '<div><label>' . elgg_echo('hypePortfolio:email:body') . '</label>' . elgg_view('input/longtext', array('internalname' => 'email_body')) . '</div>';

$form_body .= '<div><label>' . elgg_echo('hypePortfolio:email:portfolio') . '</label>' . elgg_view('input/longtext', array('value' => elgg_view('hypePortfolio/friendly', array('username' => $user->username)), 'internalname' => 'email_portfolio', 'disabled' => 'disabled')) . '</div>';

$form_body .= '<div><label>' . elgg_echo('hypePortfolio:email:attachments') . '</label></div>';

$form_body .= elgg_view('hypePortfolio/forms/email_files', array('entity' => $user));

$form_body .= elgg_view('input/hidden', array('value' => $user->name, 'internalname' => 'email_subject_name'));

$form_body .= elgg_view('input/submit', array('value' => 'Send'));

$form = elgg_view('input/form', array('body' => $form_body, 'action' => $vars['url'] . 'action/portfolio/email'));

echo $form;

?>
