<?php
global $CONFIG;

$user = $vars['entity'];
?>

<div id="hypenavigation">
    <div id="hypePortfolio_header">
        <div id="page_header" class="left page_header">
        </div>
        <div class="right navigation_items">
            <ul id="navigation_items" class="navigation_items">
                <?php echo elgg_view('hypePortfolio/navigation'); ?>
            </ul>
        </div>
    </div>
    <div class="clearfloat"></div>
    <div id="portfoliocontent"></div>
</div>
<div class="clearfloat"></div>

<div class="clearfloat"></div>

<div id="modal_container_result" style="display:none">
    <div id="modal_result_wrapper"></div>
</div>