<!--
<li id="input_your_id" view="hypePortfolio/testview" title="Input Your Page Title" class="portfolio_nav_extras left">
    IMG/CSS
</li>
-->

<?php

// pass the variables you need in the view
//$_SESSION['hypePortfolio']['input_your_id'] = array('varname' => 'varvalue');

?>
