<?php
$hypePortfolio_items = get_hypePortfolio_settings();
foreach ($hypePortfolio_items as $ref => $hypePortfolio_item) {
    echo '#' . $ref . '{';
    echo 'background:transparent url(' . $CONFIG->wwwroot . 'mod/hypePortfolio/graphics/' . $ref . '.png) no-repeat 50% 50%;
          height:50px;
          width:30px;
          display:block;
          float:left;
          margin-left:8px;
          cursor:pointer;}';
}
?>

.navigation_items, .subnavigation_items {
list-style:none;
}

.navigation_items {
margin-right:25px;
}

.subnavigation_edit_button {
background:transparent url(<?php echo $vars['url'] ?>mod/hypePortfolio/graphics/edit_button.png);
}

.page_header {
font-size:2em;
color:<?php echo $maincolor ?>;
padding:15px 0 0 25px;
}

#subnavigation_items_container {
min-height:400px;
}

#portfoliocontent {
margin:10px;
}


.dates {
font-weight:bold;
}

.institution {
font-weight:bold;
font-size:1.2em;
}

.location {
font-weight:normal;
font-size:0.9em;
}

.degree, .stats {
margin-left:25px;
color:#666666;
}
.rank, .sat {
margin-left:15px;
}

.edit_button {
width:16px;
height:16px;
display:block;
background:transparent url(<?php echo $vars['url'] ?>mod/hypePortfolio/graphics/edit.png) no-repeat;
cursor:pointer;
}

.delete_button {
width:16px;
height:16px;
display:block;
background:transparent url(<?php echo $vars['url'] ?>mod/hypePortfolio/graphics/delete.png) no-repeat;
cursor:pointer;
}

.download_button {
width:16px;
height:16px;
display:block;
background:transparent url(<?php echo $vars['url'] ?>mod/hypePortfolio/graphics/download.png) no-repeat;
cursor:pointer;
}

.user_name {
font-size:1.8em;
line-height:normal;
color:<?php echo $maincolor ?>;
margin-top:10px;
}

.user_jobs, .user_status, .user_docs_count {
text-align:center;
font-size:1em;
margin-top:10px;
}

.file_icon {
padding-right:10px;
}

p.user_menu_admin {
border:0;
}

p.user_menu_admin a {
float:left;
padding:0 10px;
}

#profile_info_column_middle {
width:100%;
}

.hypePortfolio_folder {
font-size:0.9em;
color:#666;
}

.portfolio_extras p {
margin-right:25px;
}

.river_object_academic_create,
.river_object_academic_update,
.river_object_achievements_create,
.river_object_achievements_update,
.river_object_skills_create,
.river_object_skills_update,
.river_object_work_create,
.river_object_work_update {
background:url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_profile.gif) no-repeat left -1px;
}

#modal_container_result {
width:300px;
height:400px;
}