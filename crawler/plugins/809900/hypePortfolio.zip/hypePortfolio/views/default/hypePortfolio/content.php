<?php
$user = $vars['entity'];
$subtype = $vars['subtype'];

$hypePortfolio_items = get_hypePortfolio_settings();

$hypePortfolio_items = $hypePortfolio_items[$subtype];
?>

<div id="hidden_header" style="display:none">
    <?php echo $hypePortfolio_items['display_name'] ?>
</div>

<div id="subnavigation_items_container">
    <ul id="subnavigation_items" class="subnavigation_items">
        <?php
        foreach ($hypePortfolio_items['subtypes'] as $ref => $value) {
            echo '<li ref="' . $ref . '" class="subnavigation_item"><a href="#tab_'. $ref . '" >' . $value['display_name'] . '</a></li>';
        }
        ?>
    </ul>

    <?php
        foreach ($hypePortfolio_items['subtypes'] as $ref => $value) {
            $metasort = NULL;
			if (in_array('start_year', $value['fields'])) $metasort = array('name' => 'start_year', 'direction' => DESC, 'as' => text);
			$options = array(
                'metadata_names' => 'reference',
                'metadata_values' => $ref,
                'types' => 'object',
                'subtypes' => $subtype,
                'owner_guids' => $user->guid,
                'limit' => 500,
               	'order_by_metadata' => $metasort
            );
            $objects = elgg_get_entities_from_metadata($options);
            echo '<div id="tab_' . $ref . '" ref="' . $ref . '" class="subnavigation_content">';
            set_context('portfolio');
			if ($objects) {
                foreach ($objects as $object) {
                    echo elgg_view_entity($object);
                }
            } else {
                echo elgg_echo('hypePortfolio:noitemstodisplay');
            }

            if ($_SESSION['user'] == $user) {
                echo '<p></p>';
                echo '<div subtype="' . $subtype . '" ref="' . $ref . '" id="add_new_item" class="button">' . elgg_echo('hypePortfolio:addnew') . '</div>';
            }

            echo '</div>';
        }
    ?>
</div>