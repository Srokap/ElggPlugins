<?php
global $CONFIG;

$user = $vars['entity'];
$subtype = 'file';

$hypePortfolio_items = get_hypePortfolio_settings();
$hypePortfolio_items = $hypePortfolio_items[$subtype]['subtypes'];

foreach ($hypePortfolio_items as $ref => $value) {
    $ref_for_metadata[] = $ref;
}

$options = array(
    'metadata_names' => 'reference',
    'metadata_values' => $ref_for_metadata,
    'types' => 'object',
    'subtypes' => $subtype,
    'owner_guids' => $user->guid,
    'limit' => 500
);

$files = elgg_get_entities_from_metadata($options);

if ($files) {

    echo '<div><label>' . elgg_echo('hypePortfolio:email:attachments') . '</label></div>';

    set_context('search');
    $options = NULL;
    foreach ($files as $file) {
        $options[$file->guid] = array('option' => $file->guid, 'display_value' => elgg_view_entity($file));
    }

    echo '<div>';
    echo elgg_view('input/checkboxes', array(
        'selected' => true,
        'options' => $options,
        'internalname' => 'attached_files',
    ));
    echo '</div>';
}
?>

<script type="javascript/text">
    $(document).ready(function(){
        var listing = new Array();
        <?php foreach($options as $label => $option) { ?>
            listing['<?php echo $label ?>'] = '<?php $listing = get_entity((int)$label); echo elgg_view_entity(($listing)); ?>';
        <?php } ?>
        $('input[type=checkbox][name=attached_files[]]').each(function(){
            var new_value = listing[$(this).attr('value')];
            $(this).html(new_value);
        });
    };
</script>