<?php

$hypePortfolio_items = get_hypePortfolio_settings();

foreach ($hypePortfolio_items as $subtype => $hypePortfolio_item) {
    echo '<a title="' . $hypePortfolio_item['display_name'] . '"><li id="' . $subtype . '" class="portfolio_nav left"></li></a>';
}

echo elgg_view('hypePortfolio/navigation_extras', $vars);

?>