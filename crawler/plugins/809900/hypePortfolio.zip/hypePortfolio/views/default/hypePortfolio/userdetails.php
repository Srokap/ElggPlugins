<?php
global $CONFIG;

$user = $vars['entity'];

$user_icon = elgg_view('profile/icon', array('entity' => $user, 'size' => 'large', 'override' => true));
$file_ref_types = get_hypePortfolio_settings();
$file_ref_types = $file_ref_types['file']['subtypes'];
$metadata_values = array();
foreach ($file_ref_types as $key => $file_ref_type) {
    $metadata_values[] = $key;
}
$options = array(
    'metadata_names' => 'reference',
    'metadata_values' => $metadata_values,
    'type' => 'object',
    'subtype' => 'file',
    'owner_guid' => $user->guid,
    'count' => true
);
$objects = elgg_get_entities_from_metadata($options);
$user_docs = 'Supporting Documents: ' . $objects;
if (is_plugin_enabled('profile_manager')) {
    $user_type = get_entity($user->custom_profile_type);
    if ($user_type) {
        $user_type = $user_type->getTitle();
    }
}
?>
<div class="hj-padding-ten">
    <div class="user_icon"> <?php echo $user_icon ?> </div>
    <div class="user_name"> <?php echo $user->name ?> </div>
    <div class="user_type"> <?php if ($user_type)
    echo $user_type ?> </div>
    <div id="profile_info_column_middle"> </div>
    <br />
    <div class="userdetails">
        <?php
        set_context('profile');
        if (is_plugin_enabled('profile_manager')) {
            echo elgg_view('profile_manager/profile/userdetails', array('entity' => $user));
        } else {
            echo elgg_view('hypePortfolio/profile_fields', array('entity' => $user, 'full' => true));
        }
        ?>
    </div>
    <?php
        if (isloggedin ()) {
            if ($_SESSION['user']->getGUID() == $vars['entity']->getGUID()) {
                echo "<a class=\"button\" href=\"{$vars['url']}pg/profile/{$vars['entity']->username}/edit\">Edit details</a>";
            }
        }
    ?>
        <div class="user_docs_count"> <?php echo $user_docs ?> </div>
        <p></p>

    <?php echo elgg_view('hypePortfolio/userdetails/extend'); ?>
    <div class="clearfloat"></div>
</div>