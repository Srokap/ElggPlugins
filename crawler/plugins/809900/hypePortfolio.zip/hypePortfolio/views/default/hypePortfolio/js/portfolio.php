<script type="text/javascript">

    //Add new Porfolio item bind
    function add_new(container, user_guid) {
        var add_new_button          = $('#add_new_item', container),
        modal_container         = $('#modal_container_result'),
        modal_result            = $('#modal_result_wrapper', modal_container);
        var ajax_loader          = '<div class="hj-ajax-loader hj-loader-circle"></div>';

        add_new_button.each(function(){
            $(this).click(function() {
                modal_result.html(ajax_loader);
                modal_container.dialog({width:700, height:400, modal:true});
                $.ajax ({
                    url: '<?php echo elgg_add_action_tokens_to_url($vars['url'] . 'action/portfolio/actions') ?>',
                    type: 'POST',
                    dataType: 'html',
                    data: {
                        user_guid: user_guid,
                        subtype: $(this).attr('subtype'),
                        reference: $(this).attr('ref'),
                        action_type: 'new'
                    },
                    success: function(data) {
                        modal_result.html(data);
                    }
                });
            });
        });

    }

    //Function to bind with the Edit Button
    function edit_item(container, user_guid) {
        var edit_button          = $('div.edit_button', container),
        modal_container         = $('#modal_container_result'),
        modal_result            = $('#modal_result_wrapper', modal_container);

        var ajax_loader          = '<div class="hj-ajax-loader hj-loader-circle"></div>';

        edit_button.each(function(){
            $(this).click(function() {
                modal_result.html(ajax_loader);
                modal_container.dialog({modal:true, height:400});
                $.ajax ({
                    url: '<?php echo elgg_add_action_tokens_to_url($vars['url'] . 'action/portfolio/actions') ?>',
                    type: 'POST',
                    dataType: 'html',
                    data: {
                        user_guid: user_guid,
                        object_guid: $(this).attr('object'),
                        action_type: 'edit'
                    },
                    success: function(data) {
                        modal_result.html(data);
                    }
                });
            });
        });
    }

    function delete_item(container, user_guid, parent) {
        var delete_button          = $('div.delete_button', container);

        delete_button.each(function(){
            $(this).click(function() {
                $.ajax ({
                    beforeSend: function(){
                        var confirm_delete = confirm('<?php echo elgg_echo('hypePortfolio:confirmdelete') ?>');
                        return confirm_delete;
                    },
                    url: '<?php echo elgg_add_action_tokens_to_url($vars['url'] . 'action/portfolio/actions') ?>',
                    type: 'POST',
                    dataType: 'html',
                    data: {
                        object_guid: $(this).attr('object'),
                        user_guid: user_guid,
                        action_type: 'delete'
                    },
                    success: function(data) {
                        parent.trigger('click');
                    }
                });
            });
        });
    }

    $(document).ready(function(){
        var result_container     = $('#portfoliocontent'),
        page_header          = $('#page_header');

        var ajax_loader          = '<div class="hj-ajax-loader hj-loader-circle"></div>';

        var user_guid            = '<?php echo $user->guid ?>';

        $('ul#navigation_items li.portfolio_nav').each(function(){

            $(this).click(function() {
                result_container.html(ajax_loader);
                var subtype = $(this).attr('id');
                var current_nav = $(this);
                $.ajax ({
                    url: '<?php echo elgg_add_action_tokens_to_url($vars['url'] . 'action/portfolio/actions') ?>',
                    type: 'POST',
                    dataType: 'html',
                    contentType: 'application/x-www-form-urlencoded',
                    data: {
                        user_guid: user_guid,
                        subtype: subtype,
                        action_type: 'get_details'
                    },
                    success: function(data) {
                        result_container.html(data);
                        page_header.html($('#hidden_header').html());
                        $('#subnavigation_items_container').tabs();
                        add_new(result_container, user_guid);
                        edit_item(result_container, user_guid);
                        delete_item(result_container, user_guid, current_nav);
<?php
echo trigger_plugin_hook('hype:portfolio:ajaxsuccess:getdetails', 'all', '', '');
?>
                    }
                });
            });
        });

        $('ul#navigation_items li.portfolio_nav_extras').each(function(){
            $(this).click(function() {
                result_container.html(ajax_loader);
                var display_view = $(this).attr('view');
                var title = $(this).attr('title');
                var id_for_vars = $(this).attr('id');
                var current_nav = $(this);
                $.ajax ({
                    url: '<?php echo elgg_add_action_tokens_to_url($vars['url'] . 'action/portfolio/actions') ?>',
                    type: 'POST',
                    dataType: 'html',
                    contentType: 'application/x-www-form-urlencoded',
                    data: {
                        user_guid: user_guid,
                        display_view: display_view,
                        id_for_vars: id_for_vars,
                        action_type: 'get_view'
                    },
                    success: function(data) {
                        result_container.html(data);
                        page_header.html(title);
                        $('#subnavigation_items_container').tabs();
<?php
echo trigger_plugin_hook('hype:portfolio:ajaxsuccess:getdetails', 'all', '', '');
?>
                    }
                });
            });
        });

        if (result_container.html()=="") {
            $('ul#navigation_items li:first').trigger('click');
        }
    });
</script>
