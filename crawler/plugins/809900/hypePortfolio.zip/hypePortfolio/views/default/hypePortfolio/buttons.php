<?php

if ($vars['entity']->owner_guid == $vars['user']->guid) {

    echo '<span id="edit_button" obj="' . $$vars['entity']->guid . '">' . elgg_echo('edit') . '</span>';

}

?>
