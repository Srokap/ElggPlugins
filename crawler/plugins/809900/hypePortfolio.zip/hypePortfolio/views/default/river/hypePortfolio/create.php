<?php

$performed_by = get_entity($vars['item']->subject_guid); // $statement->getSubject();
$object = get_entity($vars['item']->object_guid);

$url = "<a href=\"{$performed_by->getURL()}\">{$performed_by->name}</a>";

$hypePortfolio_items = get_hypePortfolio_settings();
$subtype = $hypePortfolio_items[$object->getSubtype()]['river'];
$reference = $hypePortfolio_items[$object->getSubtype()]['subtypes'][$object->reference]['display_name'];

$string .= sprintf(elgg_echo("hypePortfolio:river:created"), $url, $subtype) . " ";
$string .= "<div class=\"river_content_display\">";
if ($object->institution) {
    $string .= $object->start_year . ' - ' . $object->end_year . ' <b>' . $object->institution . '</b> (' . $reference . ')';
} else {
    $string .= $object->skills . ' (' . $reference . ')';
}
$string .= "</div>";

echo $string;
?>