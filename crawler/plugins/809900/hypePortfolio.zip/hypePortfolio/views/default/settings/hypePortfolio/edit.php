<?php

global $CONFIG;

echo '<p>Replace default profile with hypePortfolio</p>';
echo elgg_view('input/pulldown', array(
    'internalname' => 'params[hj_portfolio_replace_profile]',
    'value' => $vars['entity']->hj_portfolio_replace_profile,
    'options_values' => array(
        'replace' => 'Replace',
        'leave' => 'Leave'
    )
));
?>