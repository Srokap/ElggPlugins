<?php
if (isset($vars['entity'])) {

    $portfolio = $vars['entity'];
?>

    <div id="hypePortfolio_item_wrapper" class="search_listing">
    <?php if ($portfolio->canEdit()) {
 ?>
        <div id="item_buttons" class="right"><a title="Edit"><div class="edit_button" object="<?php echo $portfolio->guid ?>"></div></a><a title="Delete"><div class="delete_button" object="<?php echo $portfolio->guid ?>"></div></a></div>
<?php } ?>
    <div class="dates"><span class="start_year">
<?php echo $portfolio->start_year ?></span> -
        <span class="end_year">
<?php echo $portfolio->end_year ?></span></div>
    <div class="institution">
<?php echo $portfolio->institution ?>
        <span class="location">(<?php echo $portfolio->location ?>)</span></div>

    <?php
    if ($portfolio->achievement) {
        echo '<div class="degree">' . $portfolio->achievement . ', ' . $portfolio->field . '</div>';
    }
    echo '<div class="stats">';
    if ($portfolio->gpa) {
        echo '<span class="gpa"><span class="label">GPA:</span> ' . $portfolio->gpa . '</span>';
    }
    if ($portfolio->rank) {
        echo '<span class="rank"><span class="label">Rank:</span> ' . $portfolio->rank . '</span>';
    }
    if ($portfolio->sat) {
        echo '<span class="sat"><span class="label">SAT:</span> ' . $portfolio->sat . '</span>';
    }
    echo '</div>';
    ?>
</div>

<?php
} else {
    register_error(elgg_echo('hypePortfolio:nothingtodisplay'));
}
?>
