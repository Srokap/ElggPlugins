<?php
if (isset($vars['entity'])) {

    $portfolio = $vars['entity'];
?>

    <div id="hypePortfolio_item_wrapper" class="search_listing">
    <?php if ($portfolio->canEdit()) {
 ?>
        <div id="item_buttons" class="right"><a title="delete"><div class="edit_button" object="<?php echo $portfolio->guid ?>"></div></a><a title="delete"><div class="delete_button" object="<?php echo $portfolio->guid ?>"></div><a/></div>
<?php } ?>
    <div class="skills">
        <?php
            echo $portfolio->skills;
        ?>
    </div></div>
<?php
} else {
    register_error(elgg_echo('hypePortfolio:nothingtodisplay'));
}
?>

