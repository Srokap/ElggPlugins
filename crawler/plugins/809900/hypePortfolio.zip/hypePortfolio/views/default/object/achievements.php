<?php
if (isset($vars['entity'])) {

    $portfolio = $vars['entity'];
?>

    <div id="hypePortfolio_item_wrapper" class="search_listing">
    <?php if ($portfolio->canEdit()) {
 ?>
        <div id="item_buttons" class="right"><a title="edit"><div class="edit_button" object="<?php echo $portfolio->guid ?>"></div></a><a title="delete"><div class="delete_button" object="<?php echo $portfolio->guid ?>"></div></a></div>
<?php } ?>
    <div class="dates">
        <span class="end_year">
<?php echo $portfolio->end_year ?></span></div>
    <div class="institution">
<?php echo $portfolio->name ?></div>
<?php
    echo '<div class="stats">';
    if ($portfolio->institution) {
        echo '<span class="description">' . $portfolio->institution . '</span>';
    }
    echo '</div>';
    ?>
    </div>
<?php
} else {
    register_error(elgg_echo('hypePortfolio:nothingtodisplay'));
}
?>
