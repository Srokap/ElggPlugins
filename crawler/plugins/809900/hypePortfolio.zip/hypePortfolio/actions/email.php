<?php

global $CONFIG;
gatekeeper();

$from = get_input('email_from');
$user = get_user_by_email($from);
$from_name = $user->name;
$to = get_input('email_to');
$body = sprintf(elgg_echo('hypePortfolio:email:append'), $CONFIG->sitename);
$body .= get_input('email_body');
$body .= get_input('email_portfolio');
$subject = get_input('email_subject');

$file_attachments = get_input('attached_files');

$attachments = NULL;
foreach ($file_attachments as $file_guid) {
    $file = get_entity((int)$file_guid);
    $attachments[] = array('path' => $file->getFilenameonFilestore());
}


if (phpmailer_send($from, $from_name, $to, '', $subject, $body, NULL, true, $attachments, NULL)) {
    system_message(elgg_echo('hypePortfolio:email:success'));
} else {
    system_message(elgg_echo('hypePortfolio:email:error'));
}

forward('pg/portfolio/' . $user->username);
?>
