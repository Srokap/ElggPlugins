<?php

global $CONFIG;
gatekeeper();

$user_guid = get_input('user_guid');
$user = get_entity($user_guid);

if ($user->canEdit()) {
    $object_guid = (int) get_input('object_guid');
    if ($object_guid == '')
        $object_guid = NULL;
    $subtype = get_input('subtype');
    $reference = get_input('reference');
    $access_id = (int) get_input('access_id');

    $hypePortfolio = new ElggObject($object_guid);
    $hypePortfolio->subtype = $subtype;
    $hypePortfolio->reference = $reference;
    $hypePortfolio->owner_guid = $user_guid;
    $hypePortfolio->access_id = get_input('access_id');

    $hypePortfolio_items = get_hypePortfolio_settings();
    $hypePortfolio_items = $hypePortfolio_items[$subtype]['subtypes'][$reference];
    $hypePortfolio_fields_details = get_fields_by_subtype($reference, $hypePortfolio_items['fields']);

    foreach ($hypePortfolio_fields_details as $ref => $value) {
        if (get_input($ref)) {
            $hypePortfolio->$ref = get_input($ref);
        }
    }

    $result = $hypePortfolio->save();

    if ($result) {
        system_message(elgg_echo('hypePortfolio:savesuccess'));
        if ($object_guid == NULL) {
            add_to_river('river/hypePortfolio/create', 'create', $user->guid, $hypePortfolio->guid);
        } else {
            add_to_river('river/hypePortfolio/create', 'update', $user->guid, $hypePortfolio->guid);
        }
    }

    forward($_SERVER['HTTP_REFERER']);
} else {
    register_error('ePorfolio:noprivileges');
    forward($_SERVER['HTTP_REFERER']);
}
?>