<?php
action_gatekeeper();

$user_guid = get_input('user_guid');
$user = get_entity($user_guid);

$object_guid = (int) get_input('object_guid');
$object = get_entity($object_guid);

$subtype = get_input('subtype');
$reference = get_input('reference');

$view = get_input('display_view');
$action = get_input('action_type');

$return = elgg_view('hypeFramework/ajax/metatags');

if ($action !== 'get_details' && !$user->canEdit()) {
    $return .= elgg_echo('hypePortfolio:noprivileges');
    die();
}

if ($action == 'get_details') {
    $return .= elgg_view('hypePortfolio/content', array('entity' => $user, 'subtype' => $subtype));
}
if ($action == 'get_view') {
    $id_vars = get_input('id_for_vars');
    $pass_vars = $_SESSION['hypePortfolio'][$id_vars];
    $pass_vars['entity'] = $user;
    $return .= elgg_view($view, $pass_vars);
}

if ($action == 'edit') {
    if ($object->getSubtype() !== 'file') {
        $return .= elgg_view('hypePortfolio/forms/edit', array('entity' => $object, 'user' => $user));
    } else {
        $return .= elgg_view('file/upload', array('entity' => $object, 'user' => $user));
    }
}

if ($action == 'new') {
    if ($subtype !== 'file') {
        $return .= elgg_view('hypePortfolio/forms/edit', array('user' => $user, 'subtype' => $subtype, 'reference' => $reference));
    } else {
        $return .= elgg_view('file/upload', array('reference' => $reference));
    }
}

if ($action == 'delete') {
    if ($object instanceof ElggEntity) {
        if ($object->delete()) {
            $return = 'true';
        } else {
            $return = 'false';
        }
    } else {
        $return = 'false';
    }
}
echo $return;
die();
?>