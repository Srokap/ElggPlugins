<?php

function get_fields_array() {

    $fields = array(
        'name' => array('type' => 'text', 'class' => 'mandatory'),
        'institution' => array('type' => 'text', 'class' => 'mandatory'),
        'location' => array('type' => 'tags'),
        'start_year' => array('type' => 'text', 'class' => 'mandatory'),
        'end_year' => array('type' => 'text', 'class' => 'mandatory'),
        'rank' => array('type' => 'text'),
        'gpa' => array('type' => 'text'),
        'sat' => array('type' => 'text'),
        'field' => array('type' => 'text'),
        'achievement' => array('type' => 'text'),
        'description' => array('type' => 'longtext'),
        'skills' => array('type' => 'text'),
            //This array can also take 'options' for pulldowns
            //'degree' => array('type' => 'pulldown', 'options' => get_degrees())
    );
    $fields = trigger_plugin_hook('hypePortfolio:custom:fields', 'all', array('current' => $fields), $fields);
    return $fields;
}

function get_fields_array_details($subtype) {

    $fields = get_fields_array();

    foreach ($fields as $field => $type) {
        $field_details[$field] = array(
            'ref' => $field,
            'display_name' => elgg_echo('hypePortfolio:' . $subtype . ':' . $field),
            'type' => $type['type'],
            'options' => $type['options'],
            'class' => $type['class']
        );
    }

    return $field_details;
}

function get_fields_by_subtype($subtype, $subtype_fields) {

    $fields = get_fields_array_details($subtype);

    foreach ($fields as $field => $details) {
        if (in_array($field, $subtype_fields)) {
            $subtype_fields_details[$field] = $details;
        }
    }

    return $subtype_fields_details;
}

function get_hypePortfolio_settings() {

    $hypePortfolio_items['work'] = array(
        'display_name' => elgg_echo('portfolio:display:work'),
        'river' => elgg_echo('portfolio:river:work'),
        'subtypes' => array(
            'jobs' => array(
                'display_name' => elgg_echo('portfolio:display:employment'),
                'fields' => array('institution', 'location', 'name', 'field', 'start_year', 'end_year', 'description')),
            'internships' => array(
                'display_name' => elgg_echo('portfolio:display:internships'),
                'fields' => array('institution', 'location', 'name', 'field', 'start_year', 'end_year', 'description'))));

    $hypePortfolio_items['academic'] = array(
        'display_name' => elgg_echo('portfolio:display:academichistory'),
        'river' => elgg_echo('portfolio:river:academichistory'),
        'subtypes' => array(
            'university' => array(
                'display_name' => elgg_echo('portfolio:display:university'),
                'fields' => array('institution', 'location', 'field', 'start_year', 'end_year', 'gpa', 'achievement')),
            'techschool' => array(
                'display_name' => elgg_echo('portfolio:display:techschool'),
                'fields' => array('institution', 'location', 'field', 'start_year', 'end_year', 'achievement')),
            'high_school' => array(
                'display_name' => elgg_echo('portfolio:display:highschool'),
                'fields' => array('institution', 'location', 'start_year', 'end_year', 'rank', 'gpa', 'sat'))));

    $hypePortfolio_items['achievements'] = array(
        'display_name' => elgg_echo('portfolio:display:achievements'),
        'river' => elgg_echo('portfolio:river:achievements'),
        'subtypes' => array(
            'achievements' => array(
                'display_name' => elgg_echo('portfolio:display:honors'),
                'fields' => array('name', 'institution', 'end_year'))));

    $hypePortfolio_items['skills'] = array(
        'display_name' => elgg_echo('portfolio:display:skills'),
        'river' => elgg_echo('portfolio:river:skills'),
        'subtypes' => array(
            'languages' => array(
                'display_name' => elgg_echo('portfolio:display:languages'),
                'fields' => array('skills')),
            'computers' => array(
                'display_name' => elgg_echo('portfolio:display:computers'),
                'fields' => array('skills')),
            'hobbies' => array(
                'display_name' => elgg_echo('portfolio:display:hobbies'),
                'fields' => array('skills')),
            'ethics' => array(
                'display_name' => elgg_echo('portfolio:display:ethics'),
                'fields' => array('skills')),
            ));

    if (is_plugin_enabled('file')) {
        $hypePortfolio_items['file'] = array(
            'display_name' => elgg_echo('portfolio:display:files'),
            'subtypes' => array(
                'supporting' => array(
                    'display_name' => elgg_echo('portfolio:display:supportingdocs'),
                    'fields' => array()),
                'creative' => array(
                    'display_name' => elgg_echo('portfolio:display:creativeportfolio'),
                    'fields' => array())));
    }

    $hypePortfolio_items = trigger_plugin_hook('hypePortfolio:customfields', 'all', array('current' => $hypePortfolio_items), $hypePortfolio_items);

    return $hypePortfolio_items;
}

?>
