<?php
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
global $CONFIG;
$username = get_input('username');
?>

<body style="font-family:Tahoma;font-size:12px;" onload="window.print()">
    <?php
    echo elgg_view('hypePortfolio/friendly', array('username' => $username));
    ?>
</body>