<?php
	
	$english = array(
		'maintenance:settings:activate' => 'Activate maintenance mode',
		'maintenance:settings:text' => 'Enter optional extra text for maintenance message',
		'maintenance:info' => 'Site temporarily down for maintenance.',
		'maintenance:adminlogin' => 'login %shere%s if you are a siteadmin',
		
	);
					
	add_translation("en",$english);
?>