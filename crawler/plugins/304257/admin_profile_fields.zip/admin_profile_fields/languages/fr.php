<?php

	$french = array(
	
	 'profile:admin_service_name'  =>  "Service" , 
	 'profile:admin_manager'  =>  "Manager" , 
	 'profile:admin_office_address'  =>  "Adresse professionnelle" , 
	 'profile:admin_office_phone'  =>  "Numéro de téléphone bureau" , 
	 'profile:admin_office_interests'  =>  "Missions" , 

	);
					
	add_translation("fr",$french);

?>
