<?php

	$english = array(
	
	 'profile:admin_service_name'  =>  "Service Name" , 
	 'profile:admin_manager'  =>  "Manager" , 
	 'profile:admin_office_address'  =>  "Office adress" , 
	 'profile:admin_office_phone'  =>  "Office phone" , 
	 'profile:admin_office_interests'  =>  "Office interests" , 
	
	);
					
	add_translation("en",$english);

?>
