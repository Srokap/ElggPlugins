<?php 

	global $CONFIG;
	echo '<link rel="stylesheet" type="text/css" href="'.$vars['url'].'mod/entity_browser/_css/admin.css" />';
	echo '<link rel="stylesheet" type="text/css" href="'.$vars['url'].'mod/entity_browser/js/poshytip-1.0/src/tip-green/tip-green.css" />';
	echo '<script type="text/javascript" src="'.$vars['url'].'mod/entity_browser/js/jquery.jstree/jquery.jstree.js"></script>';
	echo '<script type="text/javascript" src="'.$vars['url'].'mod/entity_browser/js/layout/jquery.layout.min-1.2.0.js"></script>';
	echo '<script type="text/javascript" src="'.$vars['url'].'mod/entity_browser/js/jquery.hoverIntent.js"></script>';
	echo '<script type="text/javascript" src="'.$vars['url'].'mod/entity_browser/js/jquery.livequery-1.1.1/jquery.livequery.min.js"></script>';
	echo '<script type="text/javascript" src="'.$vars['url'].'mod/entity_browser/js/poshytip-1.0/src/jquery.poshytip.js"></script>';
	
?>