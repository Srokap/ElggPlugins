<?php
	/**
	 * Example 3la url shortner, providing a url shortning service for Elgg using 3la.cc
	 * 
	 * @package Elgg3laShortner
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Marcus Povey
	 * @copyright Marcus Povey 2009
	 * @link http://elgg.com/
	 */

	/**
	 * Init.
	 */
	function threelashortener_init()
	{
		global $CONFIG;
		
		// Extend CSS
		extend_view('css','3lashortener/css');
		
		// Shorten url action
		register_action("3lashortener/shorten",false, $CONFIG->pluginspath . "3lashortener/actions/3lashortener/shorten.php");
	}
	
	register_elgg_event_handler('init','system','threelashortener_init');
?>