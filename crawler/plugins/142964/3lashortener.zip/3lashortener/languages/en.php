<?php
	$english = array(
	
		'3lashortener:shorten' => 'Shorten URL',
	
	);
					
	add_translation("en",$english);
?>