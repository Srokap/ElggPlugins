<script type="text/JavaScript">
 $(document).ready(function(){  
   $("#3la_submit").click(function(){
     $("#shortened_url p").load("<?php echo $vars['url']; ?>action/3lashortener/shorten", { query:$("#3la_url").val()});
   });
    
 });
</script>
<div class='contentWrapper'>
	<div class="urlshortener">
		<div id="shortened_url"><p></p></div>
		<input type="text" id="3la_url" value="http://" class="input-url" /><br />
	   	<input type="submit" id="3la_submit" value="<?php echo elgg_echo('3lashortener:shorten'); ?>" class="submit_button">
		
	</div>
</div>