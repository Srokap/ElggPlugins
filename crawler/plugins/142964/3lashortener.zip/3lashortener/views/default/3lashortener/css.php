#shortened_url p {
	color:red;
	font-family: Arial, 'Trebuchet MS','Lucida Grande', sans-serif;
	font-size: 140%;
	width: 100%;
	
}