<?php
	$url = get_input('query');
	if ($url)
		echo file_get_contents("http://3la.cc/q/?query=".urlencode($url));
?>