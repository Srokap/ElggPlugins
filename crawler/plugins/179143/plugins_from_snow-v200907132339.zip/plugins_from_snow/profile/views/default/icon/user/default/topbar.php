<?php
	echo $vars['url'] . "mod/profile/graphics/defaulttopbar.gif";
?>