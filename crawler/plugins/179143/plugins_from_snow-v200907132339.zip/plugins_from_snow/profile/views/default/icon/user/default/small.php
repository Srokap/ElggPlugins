<?php
	echo $vars['url'] . "mod/profile/graphics/defaultsmall.gif";
?>