<?php
	echo $vars['url'] . "mod/profile/graphics/defaultmaster.gif";
?>