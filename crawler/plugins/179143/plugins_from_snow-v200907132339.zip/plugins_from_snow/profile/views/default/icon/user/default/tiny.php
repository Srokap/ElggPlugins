<?php
	echo $vars['url'] . "mod/profile/graphics/defaulttiny.gif";
?>