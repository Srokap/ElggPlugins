<?php
	/**
	 * 
	 *
	 * @package PackOfARoamingCat
	 */
	/**
	 * @author Snow.Hellsing <snow.hellsing@firebloom.cc>
	 * @copyright FireBloom Studio
	 * @link http://firebloom.cc
	 */
	 global $CONFIG;
?>
/* friends picker*/
.friends_picker_icon a,
.friends_picker_name a{
	cursor: pointer;
}
/* IE6 */
* .friends_picker_icon a,
* .friends_picker_name a{
	cursor: hand;
}
/* */
.preload,
.js_meta {
	display: none;
}
/* IE6 */
* html .mceLayout{
	width: 675px !important;
}