<?php
	/**
	 * @author Snow.Hellsing <snow@firebloom.cc>
	 * @copyright FireBloom Studio
	 * @link http://firebloom.cc
	 */
?>
<img src="<?php echo $vars['url'];?>_graphics/ajax_loader.gif" class="preload" />