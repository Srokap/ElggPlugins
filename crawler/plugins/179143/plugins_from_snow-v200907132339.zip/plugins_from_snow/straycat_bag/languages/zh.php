<?php

	$chinese = array(
		'exception' => '非常抱歉,我们遇到了技术问题。烦请告诉网站管理员下面显示的错误信息:',
		'toggle_details' => '详细信息',
	);
					
	add_translation("zh",$chinese);

?>