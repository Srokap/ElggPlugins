<?php

	$english = array(
		'exception' => 'Very sorry,we met a technological problem.Please tell the site administrator the error message below:',
		'toggle_details' => 'Details',
	);

	add_translation ( "en", $english );

?>