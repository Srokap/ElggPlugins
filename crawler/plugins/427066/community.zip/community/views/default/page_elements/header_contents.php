<?php

	/**
	 * Elgg header contents
	 * This file holds the header output that a user will see
	 * 
	 * @package Elgg
	 * @subpackage Core

	 * @author Curverider Ltd

	 * @link http://elgg.org/
	 **/
	 
?>

<div id="page_container">
<div id="page_wrapper">

<div id="layout_header">

<div id="wrapper_header"><div id="stat"></div>

</div><!-- /#wrapper_header -->
</div><!-- /#layout_header -->
<div id="header_bar"> <div><span id="login_noborder">
</span></div></div> 
<div id="header_bar2"> <div id="menu_bar2"><a href="<?php echo $vars['url']; ?>" >Home</a>
<div id="menu_bar3"> <?php
     if (isloggedin()) {
?>  
<?php

	/**
	 * Elgg standard tools drop down
	 * This will be populated depending on the plugins active - only plugin navigation will appear here
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @author Curverider Ltd
	 * @link http://elgg.org/
	 * 
	 */
	 
		$menu = get_register('menu');
		
		//var_export($menu);

		if (is_array($menu) && sizeof($menu) > 0) {
			$alphamenu = array();
			foreach($menu as $item) {
				$alphamenu[$item->name] = $item;
			}
			ksort($alphamenu);
		
?>

<ul class="topbardropdownmenu">
    <li class="drop">	<a href="#">Profil / Tools</a> 
	  <ul>   	<li><a href="<?php echo $_SESSION['user']->getURL(); ?>">Mein Profil</a> </li>
      <?php
			foreach($alphamenu as $item) {
    			echo "<li><a href=\"{$item->value}\">" . $item->name . "</a></li>";
			} 
     ?>
      </ul>
    </li>
</ul>

<script type="text/javascript">
  $(function() {
    $('ul.topbardropdownmenu').elgg_topbardropdownmenu();
  });
</script>



    


<?php
    } else {
?>

 <?php
	}
?>
<?php
		}
?> </div>   </div>  </div>
<div id="header_bar3">   </div>      