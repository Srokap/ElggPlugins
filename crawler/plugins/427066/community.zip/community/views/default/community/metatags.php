		<!--<?php echo $vars['config']->sitename; ?> powered by Elgg.-->
        