<?php
 
    function community_init()
    {
			extend_view('metatags','community/metatags');
			extend_view('css','community/css');
			extend_view('page_elements/spotlight','community/elgg_topbar');
			extend_view('page_elements/spotlight','community/footer');
    }
 
    register_elgg_event_handler('init','system','community_init');
 
?>