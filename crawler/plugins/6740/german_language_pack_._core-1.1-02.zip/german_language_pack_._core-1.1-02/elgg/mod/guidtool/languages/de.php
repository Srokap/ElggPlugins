<?php
	/**
	 * Elgg GUID Tool
	 * 
	 * @package ElggGUIDTool
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$german = array(
	
		/**
		 * Menu items and titles
		 */
	
			'guidtool' => "GUID Werkzeug",
			'guidtool:browse' => "GUIDs durchsuchen",
			'guidtool:import' => "Importieren",
			'guidtool:import:desc' => "Füge die Daten die Du importieren möchtest in das folgende Fenster ein. Diese müssen im '%s' Format vorliegen.",
			'guidtool:pickformat' => "Bitte wähle das Format, das Du importieren oder exportieren möchtest.",
		
			'guidbrowser:export' => "Exportieren",
		
	);
	add_translation('de', $german);
	
?>