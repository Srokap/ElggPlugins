<?php
	/**
	 * Elgg garbage collector language pack.
	 * 
	 * @package ElggGarbageCollector
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$german = array(
	
		/**
		 * Menu items and titles
		 */
	
			'garbagecollector' => "SPEICHER OPTIMIERUNG\n",
			'garbagecollector:done' => "ERLEDGIT\n",
			'garbagecollector:error' => "FEHLER",
			'garbagecollector:gc:metastrings' => "Bereinige nicht verwendete Metastrings: ",
			'garbagecollector:monthly' => "monatlich",
			'garbagecollector:ok' => "OK",
			'garbagecollector:optimize' => "Optimiere %s ",
			'garbagecollector:period' => "Wie oft soll die Speicheroptimierung laufen?",
			'garbagecollector:weekly' => "wöchentlich",
			'garbagecollector:yearly' => "jährlich",
	
	);
	add_translation('de', $german);
	
?>