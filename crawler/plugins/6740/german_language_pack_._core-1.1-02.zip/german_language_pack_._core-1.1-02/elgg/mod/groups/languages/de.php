<?php
	/**
	 * Elgg groups plugin language pack
	 * 
	 * @package ElggGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$german = array(
	
		/**
		 * Menu items and titles
		 */
			
			'groups' => "Gruppen",
			'groups:access' => "Zugriffsbeschränkungen",
			'groups:all' => "Alle Gruppen",
			'groups:briefdescription' => "Kurzbeschreibung",
			'groups:cantedit' => "Du kannst diese Gruppe nicht bearbeiten",
			'groups:description' => "Beschreibung",
			'groups:edit' => "Gruppe bearbeiten",
			'groups:group' => "Gruppe",
			'groups:icon' => "Gruppen Bild (leer lassen, sofern nichts geändert werden soll)",
			'groups:interests' => "Interessen",
			'groups:invite' => "Freunde einladen",
			'groups:inviteto' => "Freunde einladen zu '%s'",
			'groups:join' => "Gruppe beitreten",
			'groups:joinrequest' => "Mitgliedschaft beantragen",
			'groups:leave' => "Gruppe verlassen",
			'groups:members' => "Gruppen Mitglieder",
			'groups:membership' => "Mitgliedschaft",
			'groups:name' => "Gruppen Name",
			'groups:new' => "Neue Gruppe anlegen",
			'groups:noaccess' => "Kein Zugriff zu dieser Gruppe",
			'groups:nofriends' => "Du hast bereits alle Deine Freunde zu dieser Gruppe eingeladen.",
			'groups:owned' => "Eigene Gruppen",
			'groups:owner' => "Eigentümer",
			'groups:saved' => "Gruppe gespeichert",
			'groups:user' => "Gruppen von %s",
			'groups:username' => "Gruppen Kurzname (wird in URLs angezeigt, nur alphanumerische Zeichen erlaubt)",
			'groups:website' => "Webseite",
			'groups:widget:membership' => "Gruppen Mitgliedschaft",
			'groups:widget:num_display' => "Anzahl der Gruppen die angezeigt werden sollen",
			'groups:widgets:description' => "Gruppen bei denen ich Mitglied bin in meinem Profil anzeigen",
			'groups:yours' => "Deine Gruppen",
			
			'item:object:groupforumtopic' => "Themen des Forums",
	
        /**
		 * Group forum strings
         */
			
			'groups:addedtogroup' => "Nutzer erfolgreich der Gruppe hinzugefügt",
			'groups:addtopic' => "Thema hinzufügen",
			'groups:alldiscussion' => "Letzte Diskussion",
			'groups:alreadymember' => "Du bist bereits ein Mitglied der Gruppe!",
			'groups:cantjoin' => "Der Gruppe konnte nicht beigetreten werden",
			'groups:cantleave' => "Die Gruppe konnte nicht verlassen werden",
			'groups:edittopic' => "Thema bearbeiten",
			'groups:forum' => "Gruppen Forum",
			'groups:forumlatest' => "Forum latest",
			'groups:forumtopic:edited' => "Foren-Thema erfolgreich bearbeitet.",
			'groups:joined' => "Erfolgreich der Gruppe beigetreten!",
			'groups:joinrequestmade' => "Anfrage zum Gruppenbeitritt erfolgreich erstellt",
			'groups:joinrequestnotmade' => "Anfrage zum Gruppenbeitritt konnte nicht erstellt werden",
			'groups:lastperson' => "Letzte Person",
			'groups:latestdiscussion' => "Letzte Diskussionen",
			'groups:left' => "Gruppe erfolgreich verlassen",
			'groups:notitle' => "Gruppen müssen einen Titel haben",
			'groups:notowner' => "Leider bist Du nicht der Eigentümer der Gruppe.",
			'groups:nowidgets' => "Für diese Gruppe sind keine Widgets definiert.",
			'groups:posts' => "Kommentare",
			'groups:privategroup' => "Diese Gruppe ist Privat, es ist Mitgliedschaft erforderlich.",
			'groups:reply' => "Kommentar hinzufügen",
			'groups:river:member' => "ist nun ein Mitglied von ",
			'groups:topic' => "Thema",
			'groups:topicclosed' => "geschlossen",
			'groups:topiccloseddesc' => "Das Thema wurde gerade schlossen. Kommentare sind nicht mehr erlaubt.",
			'groups:topicisclosed' => "Das Thema ist geschlossen.",
			'groups:topicmessage' => "Topic message",
			'groups:topicopen' => "offen",
			'groups:topicreplies' => "Antworten",
			'groups:topicresolved' => "Resolved",
			'groups:topicstatus' => "Themen status",
			'groups:topicsticky' => "Sticky",
			'groups:userinvited' => "Nutzer wurde eingeladen.",
			'groups:usernotinvited' => "Nutzer konnte nicht eingeladen werden.",
			'groups:when' => "Wann",
			'groups:widgets:entities:description' => "Zeigt die gespeicherten Objekte der Gruppe an",
			'groups:widgets:entities:label:displaynum' => "Zeigt die Objekte einer Gruppe an.",
			'groups:widgets:entities:label:pleaseedit' => "Bitte konfiguriere das Widget.",
			'groups:widgets:entities:title' => "Objekte der Gruppe",
			'groups:widgets:members:description' => "Zeigt die Mitglieder der Gruppe an.",
			'groups:widgets:members:label:displaynum' => "Zeigt die Mitglieder einer Gruppe an.",
			'groups:widgets:members:label:pleaseedit' => "Bitte Konfiguriere das Widget.",
			'groups:widgets:members:title' => "Mitglieder der Gruppe",
			
			'groupspost:success' => "Dein Kommentar wurde erfolgreich hinzugefügt",
			
			'grouptopic:created' => "Dein Thema wurde erstellt.",
			'grouptopic:deleted' => "Das Thema wurde gelöscht.",
			'grouptopic:error' => "Dein Gruppen-Thema konnte nicht erstellt werden. Bitte versuche es erneut oder wende Dich an den Administrator.",
			'grouptopic:notcreated' => "Es wurde kein Thema erstellt.",
			'grouptopic:notdeleted' => "Das Thema konnte nicht gelöscht werden.",
		
        /**
		 * Groups invitation
         */

			'groups:invite:subject' => "%s Du wurdest eingeladen der Gruppe %s beizutreten!",
			'groups:invite:body' => "
Hallo %s,

Du wurdest eingeladen der Gruppe '%s' beizutreten. Verwende den folgenden Link zur:

%s",

			'groups:request:subject' => "%s möchte gerne der Gruppe %s beitreten",
			'groups:request:body' => "
Hallo %s,

%s möchte gerne der Gruppe '%s' beitreten. Über den folgenden Link kannst Du sein Profil aufrufen:

%s

oder Aktzeptiere den Beitritt über den folgenden Link:

%s",
	
			'groups:welcome:subject' => "Wilkommen zur Gruppe %s !",
			'groups:welcome:body' => "
Hallo %s!
		
Du bist nun ein Mitglied der Gruppe '%s' ! Verwende den folgenden Link um einen Eintrag zu erstellen!

%s",
	
	);
	add_translation('de', $german);
	
?>