<?php
	/**
	 * Email user validation plugin language pack.
	 * 
	 * @package ElggUserValidationByEmail
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$german = array(
	
		/**
		 * Menu items and titles
		 */
	
			'email:validate:subject' => "%s Bitte bestätige Deine Mail-Adresse!",
			'email:validate:body' => "
Hallo %s,

Bitte bestätige Deine Mail-Adresse in dem Du den folgenden Link verwendest:

%s",

			'email:validate:success:subject' => "Email-Adresse überprüft %s!",
			'email:validate:success:body' => "
Hallo %s,
			
Glückwunsch, Deine Mail-Adresse wurde erfolgreich überprüft.",
	
			'uservalidationbyemail:registerok' => "Zur Aktivierung Deines Nutzerkontos verwende Bitte den Link den wir Dir per Mail senden."
	
	);
	add_translation('de', $german);
	
?>