<?php
	/**
	 * Elgg diagnostics language pack.
	 * 
	 * @package ElggDiagnostics
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$german = array(
	
		/**
		 * Menu items and titles
		 */

			'diagnostics' => "System Diagnose",
			'diagnostics:description' => "Der folgende Diagnose-Report ist bei allen Fehler-Diagnosen in Elgg hilfreich und sollte bei Fehlermeldungen mit angehängt werden.",
			'diagnostics:download' => "Download .txt",
	
			'diagnostics:header' => "
========================================================================
Elgg Diagnose Report
Erstellt %s von %s
========================================================================",

			'diagnostics:report:basic' => "
Elgg Release %s, version %s

------------------------------------------------------------------------",

			'diagnostics:report:globals' => "
Global Variablen:

%s
------------------------------------------------------------------------",
	
			'diagnostics:report:md5' => "
Installierte Dateien mit Prüfsummen:

%s
------------------------------------------------------------------------",

			'diagnostics:report:php' => "
PHP informationen:
			
%s
------------------------------------------------------------------------",

			'diagnostics:report:plugins' => "
Installierte Erweiterungen und Details:

%s
------------------------------------------------------------------------",

	);
	add_translation('de', $german);

?>