<?php
	/**
	 * Elgg reported content plugin language pack
	 * 
	 * @package ElggReportedContent
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$german = array(
	
		/**
		 * Menu items and titles
		 */
	
			'item:object:reported_content' => "gemeldete Verstöße",
			
			'reportedcontent' => "Verstöße",
			'reportedcontent:address' => "Adresse des Vertoßes",
			'reportedcontent:archive' => "Archivieren",
			'reportedcontent:archived' => "Der Verstoß wurde Archiviert",
			'reportedcontent:areyousure' => "Bist Du sicher, das Du diesen Verstoß entfernen möchtest?",
			'reportedcontent:by' => "gemeldet von",
			'reportedcontent:delete' => "Entfernen",
			'reportedcontent:deleted' => "Der gemeldete Verstoß wurde entfernt.",
			'reportedcontent:description' => "Warum möchtest Du einen Verstoß melden?",
			'reportedcontent:failed' => "Leider ist beim Versuch einen Vertoß zu melden ein Fehler aufgetreten.",
			'reportedcontent:failing' => "Deine Meldung konnte nicht gesendet werden",
			'reportedcontent:none' => "Es gibt keine gemeldeten Verstöße",
			'reportedcontent:notdeleted' => "Der gemeldete Verstoß kann nicht entfernt werden.",
			'reportedcontent:objecttitle' => "Objekt Titel",
			'reportedcontent:objecturl' => "Objekt url",
			'reportedcontent:reason' => "Grund der Meldung",
			'reportedcontent:report' => "An den Administrator melden",
			'reportedcontent:report' => "Verstoß melden", 
			'reportedcontent:success' => "Deine Meldung wurde an den Administrator gesendet",
			'reportedcontent:this' => "Verstoß melden",
			'reportedcontent:title' => "Seiten Titel",
			'reportedcontent:visit' => "gemeldeten Verstoß besuchen",

	);
	add_translation('de', $german);
	
?>