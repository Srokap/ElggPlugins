<?php
	/**
	 * Elgg log rotator language pack.
	 * 
	 * @package ElggLogRotate
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$german = array(
	
		'logrotate:lognotrotated' => "Fehler beim Archivieren des Ereignissprotokolles\n",
		'logrotate:logrotated' => "Ereignissprotokoll wurde archiviert\n",
		'logrotate:monthly' => "monatlich",
		'logrotate:period' => "Wie oft soll das Ereignissprotokoll archiviert werden?",
		'logrotate:weekly' => "wöchentlich",
		'logrotate:yearly' => "jährlich",
		
	);
	add_translation('de', $german);
	
?>