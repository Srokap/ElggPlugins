<?php
	/**
	 * API Admin language pack.
	 * 
	 * @package ElggAPIAdmin
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$german = array(
	
		/**
		 * Menu items and titles
		 */
	
			'apiadmin' => "API Administration",
			'apiadmin:generate' => "Neues Schlüsselpaar generieren",
			'apiadmin:generated' => "API Schlüssel erfolgreich generiert",
			'apiadmin:generationfail' => "Bei generierung des neuen Schküsselpaares ist ein Problem aufgetreten",
			'apiadmin:keynotrevoked' => "API Schlüssel konnte nicht wiederrufen werden",
			'apiadmin:keyrevoked' => "API Schlüssel wiederrufen",
			'apiadmin:noreference' => "Du mußt eine Referenz für Deinen neuen Schlüssel angeben",
			'apiadmin:revoke' => "Schlüssel wiederrufen",
			'apiadmin:yourref' => "Deine Referenz",
			
			'item:object:api_key' => "API Schlüssel",
		
	);
	add_translation('de', $german);
	
?>