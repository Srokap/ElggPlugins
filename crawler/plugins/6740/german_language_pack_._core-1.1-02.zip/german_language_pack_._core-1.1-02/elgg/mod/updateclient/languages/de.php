<?php
	/**
	 * Update client language pack.
	 * 
	 * @package ElggUpdateClient
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */	

	$german = array(
	
		/**
		 * Menu items and titles
		 */
	
			'updateclient:days' => "Tage",
			'updateclient:label:core' => "Kern",
			'updateclient:label:plugins' => "Erweiterungen",
			'updateclient:message:title' => "Eine neue Version von Elgg ist verfügbar!",
			'updateclient:message:body' => "
Eine neue Version von Elgg (%s %s) Kodename '%s' wurde veröffentlicht!
		
Zum Download hier klicken: %s

Oder die Informationen zur Version lesen:

%s",

			'updateclient:settings:days' => "Auf Updates prüfen alle",
			'updateclient:settings:server' => "Update Server",

	);
	add_translation('de', $german);
	
?>