<?php
	/**
	 * Language pack.
	 * 
	 * @package ElggCore
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

    $german = array(

        /**
        * Sites
        */
     
			'item:site' => "Seiten",

        /**
        * Sessions
        */

			'login' => "Anmelden",
			'loginerror' => "Wir konnten Dich nicht anmelden. Vielleicht hast Du dein Nutzerkonto noch nicht bestätigt oder die angegeben Daten waren nicht korrekt. Überprüfe bitte, ob Du alle Daten richtig eingegeben hast und versuche es noch einmal.",
			'loginok' => "Du wurdest angemeldet.",
			'logout' => "Abmelden",
			'logouterror' => "Fehler beim Abmelden. Bitte versuche es noch einmal.",
			'logoutok' => "Du wurdest abgemeldet.",

        /**
        * Errors
        */
     
			'actionloggedout' => "Du kannst diese Aktion nicht durchführen, wenn Du abgemeldet bist.",
			'actionundefined' => "Die gewählte Aktion(%s) ist im System nicht registriert.",
			
			'APIException:AlgorithmNotSupported' => "Der Algorythmus '%s' wird nicht unterstützt oder wurde deaktiviert.",
			'APIException:ApiResultUnknown' => "Die API Anfrage lieferte als Ergebnis einen unbekannten Typ. Dies sollte nicht geschehen.",
			'APIException:FunctionNoReturn' => "%s(%s) hat keinen Wert zurückgegeben.",
			'APIException:FunctionParseError' => "%s(%s) führte zu einem Parserfehler.",
			'APIException:InvalidParameter' => "Ungültiger Parameter für '%s' in der Methode '%s' gefunden.",
			'APIException:MethodCallNotImplemented' => "Der Methodenaufruf '%s' wurde nicht implementiert.",
			'APIException:MissingAPIKey' => "Fehlender X-Elgg-apikey HTTP header",
			'APIException:MissingContentType' => "Fehlender Inhaltstyp für Post-Daten.",
			'APIException:MissingHmac' => "Fehlender X-Elgg-hmac header",
			'APIException:MissingHmacAlgo' => "Fehlender X-Elgg-hmac-algo header",
			'APIException:MissingParameterInMethod' => "Fehlender Parameter %s in Methode %s",
			'APIException:MissingPOSTAlgo' => "Fehlender X-Elgg-posthash_algo header",
			'APIException:MissingPOSTHash' => "Fehlender X-Elgg-posthash header",
			'APIException:MissingTime' => "Fehlender X-Elgg-time header",
			'APIException:NoQueryString' => "Keine Daten im Query String",
			'APIException:NotGetOrPost' => "Die Requestmethode muss GET oder POST sein",
			'APIException:ParameterNotArray' => "%s scheint kein Array zu sein.",
			'APIException:TemporalDrift' => "X-Elgg-time liegt zu weit in der Vergangenheit oder in der Zukunft.",
			'APIException:UnrecognisedTypeCast' => "Falscher Typ in Cast %s für die Variable '%s' in Methode '%s'",
			
			'CallException:InvalidCallMethod' => "%s muss mit '%s' aufgerufen werden",
			'CallException:NotRPCCall' => "Der Aufruf scheint kein gültiger XML-RPC Aufruf zu sein.",
			
			'ClassException:ClassnameNotClass' => "%s ist kein %s.",
			
			'ClassNotFoundException:MissingClass' => "Die Klasse '%s' wurde nicht gefunden. Fehlendes Plugin?",
			'ClassNotFoundException:NotFoundNotSavedWithFile' => "Gespeicherte Datei wurde nicht gefunden, oder die Klasse wurde nicht mit Datei gespeichert!",
			
			'ConfigurationException:BadDatabaseVersion' => "Der installierte Datenbankserver erfüllt nicht die für Elgg erforlichen Anforderungen. Schaue bitte in Deine Dokumentation.",
			'ConfigurationException:BadPHPVersion' => "Zum Ausführen von Elgg benötigts Du mindestens PHP Version 5.2.",
			'ConfigurationException:CacheDirNotSet' => "Das Cacheverzeichnis 'cache_path' wurde nicht gesetzt.",
			'ConfigurationException:NoCachePath' => "Cache Pfad nicht gesetzt!",
			'ConfigurationException:NoSiteID' => "Es wurde kein Site ID angegeben.",
			
			'ConfigurationWarning:phpversion' => "Zum Ausführen von Elgg ist mindestens PHP Version 5.2 erforderlich. Eine installation von Elgg ist jedoch mit Einschränkungen auch unter PHP Version 5.1.6 m&ooml;glich. Einige Funktionen von Elgg werden aber nicht oder nicht korrekt Funktionieren.",
			
			'CronException:unknownperiod' => "%s ist keine gültige Periode.",
			
			'DatabaseException:DBSetupIssues' => "Folgende Fehler sind aufgetreten: ",
			'DatabaseException:NoACL' => "Zu der Abfrage wurde keine Zugangskontrolle angegeben.",
			'DatabaseException:NoConnect' => "Elgg konnte nicht auf die Datenbank '%s' zugreifen. Bitte überprüfe, ob die Datenbank richtig eingerichtet wurde und ob Du Zugang zu ihr hast.",
			'DatabaseException:NoTablesSpecified' => "Für die Abfrage wurden keine Tabellen angegeben.",
			'DatabaseException:ScriptNotFound' => "Elgg konnte das benötigte Daktenbankskript %s nicht finden.",
			'DatabaseException:SelectFieldsMissing' => "Fehlende Felder in der Select-Abfrage",
			'DatabaseException:UnspecifiedQueryType' => "Nicht erkannter oder nicht angegebener Abfragetyp.",
			'DatabaseException:WhereSetNonQuery' => "Die Where Abfrage enthält eine Nicht-WhereQueryComponent",
			'DatabaseException:WrongCredentials' => "Elgg konnte mit den angegebenen Daten %s@%s (pw: %s) keine Verbindung zur Datenbank aufbauen.",
			
			'exception:title' => "Willkommen bei Elgg.",
			
			'ExportException:NoSuchEntity' => "Kein solcher GUID für die Entität vorhanden: %d",
			
			'ImportException:GUIDNotFound' => "Die Entität '%d' konnte nicht gefunden werden.",
			'ImportException:ImportFailed' => "Das Element %d konnte nicht importiert werden",
			'ImportException:NoGUID' => "Neue Entität wurde ohne GUID angelegt. Das sollte nicht passieren.",
			'ImportException:NoODDElements' => "Beim Datenimport konnten keine OpenDD Elemente gefunden werden. Import fehlgeschlagen.",
			'ImportException:NotAllImported' => "Es wurden nicht alle Elemente importiert.",
			'ImportException:ProblemSaving' => "Beim Speichern von %s ist ein Problem aufgetreten.",
			'ImportException:ProblemUpdatingMeta' => "Beim Update von '%s' zur Entität '%d' ist ein Fehler aufgetreten.",
			
			'InstallationException:CantCreateSite' => "Fehler beim Einrichten der Elgg Seite mit dem Namen:%s, Url: %s",
			'InstallationException:DatarootBlank' => "Du hast kein Daten-Verzeichnis angegeben.",
			'InstallationException:DatarootNotWritable' => "Dein Daten-Verzeichnis %s erlaubt keinen Schreibzugriff.",
			'InstallationException:DatarootUnderPath' => "Dein Daten-Verzeichnis %s muss sich ausßerhalb des Installtions-Verzeichnisses befinden.",
			'InstallationException:TypeNotSupported' => "Der Typ %s wurd nicht unterstützt. Das kann an einem Fehler in der Installation liegen, der wahrscheinlich durch ein unvollständiges Update verursacht wurde.",
			
			'InvalidClassException:NotValidElggStar' => "GUID:%d ist kein gültiger %s",
			
			'InvalidParameterException:CanNotExportType' => "Der Exporttyp für '%s' ist nicht klar.",
			'InvalidParameterException:DoesNotBelong' => "Gehört nicht zur Entität.",
			'InvalidParameterException:DoesNotBelongOrRefer' => "Gehört nicht oder bezieht sich nicht auf die Entität.",
			'InvalidParameterException:EntityTypeNotSet' => "Der Typ der Entität muss gestetzt sein.",
			'InvalidParameterException:GUIDNotForExport' => "GUID wurde beim Export nicht angegeben, das sollte nie passieren.",
			'InvalidParameterException:GUIDNotFound' => "GUID:%s wurde nicht gefunden oder Du hast keinen Zugang.",
			'InvalidParameterException:IdNotExistForGUID' => "'%s' gibt es fÃºr GUID:%d nicht",
			'InvalidParameterException:MissingOwner' => "Für alle Dateien muss ein Eigentümer angegeben werden!",
			'InvalidParameterException:MissingParameter' => "Fehlender Parameter, Du musst einen GUID angeben.",
			'InvalidParameterException:NoDataFound' => "Es wurden keine Daten gefunden.",
			'InvalidParameterException:NoEntityFound' => "Keine Entität gefunden. Entweder gibt es keine oder Du hast keine Zugangsberechtigung.",
			'InvalidParameterException:NonArrayReturnValue' => "Die Funtion der Serialisierung der Entität gab als Rückgabeparameter einen Nicht-Array aus",
			'InvalidParameterException:NonElggGroup' => "Eine Nicht-ElggGroup wurde and en ElggGroup Constructor übergeben!",
			'InvalidParameterException:NonElggObject' => "Ein Nicht-ElggObject wurde an den ElggObject Constructor übergeben!",
			'InvalidParameterException:NonElggSite' => "Eine Nicht-ElggSite wurde an den ElggSite Constructor übergeben!",
			'InvalidParameterException:NonElggUser' => "Ein Nicht-ElggUser wurde and den ElggUser Constructor übergeben!",
			'InvalidParameterException:UnexpectedODDClass' => "import() hatt eine unerwartete ODD Klasse übergeben",
			'InvalidParameterException:UnexpectedReturnFormat' => "Der Aufruf der Methode '%s' gab ein unerwartetes Ergebnis zurück.",
			'InvalidParameterException:UnrecognisedFileMode' => "Der Dateimodus '%s' wurde nicht erkannt.",
			'InvalidParameterException:UnrecognisedMethod' => "Nicht erkannter Methodenaufruf '%s'",
			'InvalidParameterException:UnrecognisedValue' => "Der an den Constructor übergebene Wert konnte nicht erkannt werden.",
			
			'IOException:BaseEntitySaveFailed' => "Die Base Entity Information des neuen Objekts konnte nicht gespeichert werden!",
			'IOException:CouldNotMake' => "%s konnte nicht durchgeführt werden.",
			'IOException:FailedToLoadGUID' => " %s konnte vom GUID:%d nicht erneut geladen werden.",
			'IOException:MissingFileName' => "Du musst den Namen der Datei angeben, die Du öffnen willst.",
			'IOException:NotDirectory' => "%s ist kein Verzeichnis.",
			'IOException:UnableToSaveNew' => "Fehler beim Speichern von %s .",
			
			'memcache:noaddserver' => "Die Untersützung von mehreren Servern ist deaktiviert. Du must Dein PECL-Memcache-Library updaten.",
			'memcache:notinstalled' => "PHP-Memcache Modul nicht installiert; Du must php5-memcache installieren.",
			'memcache:noservers' => "Kein Memcache-Server definiert; Bitte fülle und aktiviere die Variable {$CONFIG->memcache_servers}.",
			'memcache:versiontoolow' => "Memcache benötigt mindestens Version %s; Du hast Version %s",

			'notfound' => "Die Seite wurde nicht gefunden oder Du hast keine Zugangsberechtigung.",
			
			'NotificationException:ErrorNotifyingGuid' => "Bei der Benachrichtigung von %d ist ein Fehler aufgetreten.",
			'NotificationException:MissingParameter' => "Fehlender Parameter '%s'",
			'NotificationException:NoEmailAddress' => "Für GUID:%d konnte keine Emailadresse gefunden werden",
			'NotificationException:NoHandlerFound' => "Keiner oder nicht aufrufbarer Handler '%s' .",
			'NotificationException:NoNotificationMethod' => "Keine Methode zur Benachrichtigung angegeben.",
			
			'NotImplementedException:CallMethodNotImplemented' => "Die Aufrufmethode '%s' wird gegenwärtig nicht unterstützt.",
			'NotImplementedException:XMLRPCMethodNotImplemented' => "XML-RPC Methodenaufruf '%s' ist nicht implementiert.",
			
			'PluginException:MisconfiguredPlugin' => "%s ist ein falsch konfiguriertes Plugin.",
			'PluginException:NoPluginName' => "Der Pluginname konnte nicht gefunden werden.",
			
			'SecurityException:APIAccessDenied' => "Der API-Zugang wurde vom Administrator abgeschaltet.",
			'SecurityException:authenticationfailed' => "Nutzer kann nicht Autentifiziert werden.",
			'SecurityException:AuthTokenExpired' => "Fehlender, ungültiger oder abgelaufener Token bei der Authentifizierung.",
			'SecurityException:Codeblock' => "Du hast keine Berechtigung den Programmcode auszuführen",
			'SecurityException:deletedisablecurrentsite' => "Du kannst die Seite, die Du gerade angezeigt hast, nicht l&ooml;schen!",
			'SecurityException:DupePacket' => "Paketsignatur schon benutzt.",
			'SecurityException:FunctionDenied' => "Die Ausführung der Funktion '%s' ist nicht erlaubt.",
			'SecurityException:InvalidAPIKey' => "Ungültiger oder fehlender API Key.",
			'SecurityException:InvalidPostHash' => "POST Daten Hash is ungültig - Erwartet wurde %s angegeben wurde %s.",
			'SecurityException:NoAuthMethods' => "Für diese API-Anfrage wurde keine Authentifikationsmethode angegeben.",

        /**
        * API
        */

			'auth.gettoken' => "This API call lets a user log in, returning an authentication token which can be used in leu of a username and password for authenticating further calls.",
			'system.api.list' => "Übersicht aller verfügbaren API Aufrufe dieses Systems.",
	
        /**
        * User details
        */

			'admin_option' => "Dem Nutzer Administratorenrechte erteilen?",
			'email' => "Emailadresse",
			'name' => "Angezeigter Name",
			'password' => "Passwort",
			'passwordagain' => "Passwort (Wiederholung)",
			'username' => "Nutzername",

        /**
        * Access
        */

			'access' => "Zugang",
			'ACCESS_LOGGED_IN' => "Eingeloggte Nutzer",
			'ACCESS_PRIVATE' => "Privat",
			'ACCESS_PUBLIC' => "Öffentlich",
			'LOGGED_IN' => "Eingeloggte Nutzer",
			'PRIVATE' => "Privat",
			'PUBLIC' => "Öffentlich",

        /**
        * Dashboard and widgets
        */

			'dashboard' => "Startseite",
			'dashboard:configure' => "Seite Anpassen", 
			'dashboard:nowidgets' => "Deine Startseite ist der Eingang zur Community. Klicke 'Seite bearbeiten' um Widgets hinzuzufügen, die Inhalte und Deine Aktivität in diesem System dokumentieren.",
			
			'item:object:widget' => "Widgets",
			
			'layout:customise' => "Layout ändern",
			
			'widget' => "Widget",
			'widgets' => "Widgets",
			'widgets:add' => "Widgets zu Deiner Seite hinzufügen",
			'widgets:add:description' => "
Wähle aus der <b>Widget Gallerie</b> rechts aus, welche Elemente Du zu Deiner Seite hinzufügen willst und ziehe diese mit der Maus in eine der drei unteren Widgetzonen. Du kannst die Widgets in der Position einordnen, in welcher sie dann auf Deiner Seite angezeigt werden sollen.

Um ein Widget wieder zu entfernen, ziehst Du es einfach zurück in die <b>Widget Gallerie</b>.",

			'widgets:fixed' => "Feste Position",
			'widgets:gallery' => "Widget Gallerie",
			'widgets:leftcolumn' => "Widgets Links",
			'widgets:middlecolumn' => "Widgets Mitte",
			'widgets:panel:save:failure' => "Beim Speichern der Widgets trat ein Fehler auf. Bitte versuche es noch einmal.",
			'widgets:panel:save:success' => "Deine Widgets wurden erfolgreich gespeichert.",
			'widgets:position:fixed' => "(Feste Position auf der Seite)",
			'widgets:profilebox' => "Profilbox",
			'widgets:rightcolumn' => "Widgets Rechts",
			'widgets:save:failure' => "Beim Speichern des Widgets trat ein Fehler auf. Bitte versuche es noch einmal.",
			'widgets:save:success' => "Das Widget wurde erfolgreich gespeichert.",

        /**
        * Groups
        */

			'item:group' => "Gruppen",

        /**
        * Profile
        */

			'item:user' => "Nutzer",
			
			'profile' => "Profil",
			'profile:edit:default' => "Profildetails bearbeiten",
			
			'riveritem:single:user' => "ein Nutzer",
			'riveritem:plural:user' => "mehrere Nutzer",

			'user' => "Nutzer",
			
        /**
        * Profile menu items and titles
        */

			'profile:aboutme' => "Über mich",
			'profile:briefdescription' => "Kurzbeschreibung",
			'profile:contactemail' => "Emailadresse",
			'profile:createicon' => "Profilbild erstellen",
			'profile:createicon:header' => "Profilbild",
			'profile:createicon:instructions' => "Klicke auf das Bild und ziehe mit der Maus ein Quadrat, um dann den gewünschten Ausschnitt zu wählen. Eine Vorschau des Ausschnitts wird auf der rechten Seite angezeigt. Wenn Du mit dem Bildausschnitt zufrieden bist, klicke bitte auf 'Avatar erstellen'. Der Bildausschnitt wird dann auf der ganzen Seite als Dein Avatar benutzt. ",
			'profile:currentavatar' => "Dein Profilbild",
			'profile:defaultprofile:reset' => "Systemdetails wiederherstellen",
			'profile:description' => "Über mich",
			'profile:edit' => "Profil bearbeiten",
			'profile:editdefault:delete:fail' => "Fehler beim l&ooml;schen des Detaileintrages!",
			'profile:editdefault:delete:success' => "Detaileintrag efolgreich gel&ooml;scht.",
			'profile:editdefault:fail' => "Detaileintrag konnte nicht gespeichert werden!",
			'profile:editdefault:success' => "Detail erfolgreich zum Profil hinzugefügt.",
			'profile:editdetails' => "Details bearbeiten",
			'profile:editicon' => "Profilbild bearbeiten",
			'profile:icon' => "Profilbild",
			'profile:interests' => "Interessen",
			'profile:label' => "Detail Bezeichnung",
			'profile:location' => "Wohnort",
			'profile:mobile' => "Handy",
			'profile:phone' => "Telefon",
			'profile:profilepicturecroppingtool' => "Profilbild ausschneiden",
			'profile:profilepictureinstructions' => "Das Profilbild ist das Bild, das auf Deiner Profilseite angezeigt wird. <br /> Du kannst es ändern, so oft Du willst. (Erlaubte Formate: GIF, JPG oder PNG)",
			'profile:resetdefault' => "Profildetails wiederherstellen",
			'profile:river:iconupdate' => "Der Avatar von %s wurde bearbeitet.",
			'profile:river:update' => "Das Profil von %s wurde bearbeitet.",
			'profile:skills' => "Was ich kann.",
			'profile:type' => "Datentyp",
			'profile:user' => "Profil von %s",
			'profile:website' => "Webseite",
			'profile:yours' => "Dein Profil",

        /**
        * Profile status messages
        */

			'profile:icon:uploaded' => "Dein Profilbild wurde erfolgreich hochgeladen.",
			'profile:saved' => "Dein Profil wurde erfolgreich gespeichert.",

        /**
        * Profile error messages
        */

			'profile:cantedit' => "Du bist nicht berechtigt, dieses Profil zu bearbeiten.",
			'profile:icon:notfound' => "Leider gab es ein Problem beim Hochladen von Deinem Profilbild.",
			'profile:noaccess' => "Du bist nicht berechtigt, dieses Profil zu bearbeiten.",
			'profile:notfound' => "Leider konnten wir das angegebene Profil nicht finden.",

        /**
        * Friends
        */

			'friend:add' => "Als Freund hinzufügen",
			'friend:remove' => "Freund entfernen",
			
			'friends' => "Freunde",
			'friends:add:failure' => "Beim Versuch %s als ein Freund hinzuzufügen ist ein Fehler aufgetreten. Bitte versuche es noch einmal.",
			'friends:add:successful' => "Du hast %s erfolgreich als Freund hinzugefügt.",
			'friends:addfriends' => "Freunde hinzufügen",
			'friends:collectionadded' => "Die neue Freundesgruppe wurde eingerichtet.",
			'friends:collectiondeleted' => "Die Freundesgruppe wurde gelöscht.",
			'friends:collectiondeletefailed' => "Die Freundesgruppe konnte leider nicht gelöscht werden. Entweder bist Du dazu nicht berechtigt oder es ist ein Fehler aufgetreten.",
			'friends:collectionedit' => "Freundesgruppe bearbeiten",
			'friends:collectionfriends' => "Freunde in dieser Gruppe",
			'friends:collectionname' => "Name der Freundesgruppe",
			'friends:collections' => "Freundesgruppen",
			'friends:collections:add' => "Neue Freundesgruppe",
			'friends:collections:closeall' => "alle zuklappen",
			'friends:collections:edit' => "Freundesgruppe bearbeiten",
			'friends:collections:expandall' => "alle aufklappen",
			'friends:collections:members' => "Freundesgruppen Mitglieder",
			'friends:icon_size' => "Icongröße",
			'friends:nocollectionname' => "Um eine Freundesgruppe einzurichten musst Du einen Namen angeben.",
			'friends:nocollections' => "Du hast noch keine Freundesgruppen.",
			'friends:none' => "Dieser Nutzer hat bisher noch keine Freunde hinzugefügt.",
			'friends:none:found' => "Es wurden keine Freunde gefunden.",
			'friends:none:you' => "Du hast noch keine Freunde hinzugefügt! Suchen andere Nutzer mit ähnlichen Interessen auf der Seite.",
			'friends:num_display' => "Anzahl der Freunde, die angezeigt werden sollen",
			'friends:of' => "Freunde von",
			'friends:of:none' => "Bisher hat keiner diesen Nutzer als Freund hinzugefügt.",
			'friends:of:none:you' => "Bisher hat Dich niemand als Freund hinzugefügt. Gestalte Deine Profilseite, damit andere Dich finden können.!",
			'friends:of:owned' => "Leute, die %s als Freund haben.",
			'friends:owned' => "Freunde von %s",
			'friends:remove:failure' => "Beim Versuch %s aus der Liste Deiner Freunde zu löschen, ist ein Fehler aufgetreten. Bitte versuche es noch einmal.",
			'friends:remove:successful' => "Du hast %s erfolgreich aus der Liste Deiner Freunde gelöscht.",
			'friends:river:add' => "%s hat einen Freund hinzugefügt.",
			'friends:river:created' => "%s hat ein Freunde-Widget hinzugefügt.",
			'friends:river:delete' => "%s hat das Freunde-Widget entfernt.",
			'friends:river:updated' => "%s hat das Freunde-Widget aktualisiert.",
			'friends:small' => "klein",
			'friends:tiny' => "winzig",
			'friends:yours' => "Deine Freunde",

        /**
        * Feeds
        */
     
			'feed:odd' => "OpenDD abonniert",
			'feed:rss' => "Feed abonnieren",

        /**
        * Links
        **/

			'link:text' => "Link anzeigen",
			'link:view' => "Link anzeigen",

        /**
        * River
        */
     
			'river' => "River",
			'river:relationship:friend' => "ist jetzt befreundet mit",

        /**
        * Plugins
        */
     
			'plugins:settings:save:fail' => "Beim Speichern der Einstellungen für das %s Plugin ist ist ein Fehler aufgetreten.",
			'plugins:settings:save:ok' => "Die Einstellungen für das %s Plugin wurden erfolgreich gespeichert.",
			'plugins:usersettings:save:fail' => "Beim Speichern der Nutzereinstellungen für das %s Plugin ist ist ein Fehler aufgetreten.",
			'plugins:usersettings:save:ok' => "Die Nutzereinstellungen für das %s Plugin wurden erfolgreich gespeichert.",

			'item:object:plugin' => "Plugin Konfigurationseinstellungen",

        /**
        * Notifications
        */
     
			'notifications:methods' => "Bitte gebe an, welche Methoden Du erlauben willst...",
			'notifications:usersettings' => "Einstellungen für Benachrichtigungen",
			'notifications:usersettings:save:fail' => "Beim Speichern der  Einstellungen für Benachrichtigungen ist ist ein Fehler aufgetreten.",
			'notifications:usersettings:save:ok' => "Die Einstellungen für Benachrichtigungen wurden erfolgreich gespeichert.",
			
			'user.notification.get' => "Liefert die Benachrichtigungseinstellungen für einen Nutzer.",
			'user.notification.set' => "Setzt die Benachrichtigungseinstellungen für einen Nutzer.",

        /**
        * Search
        */

			'advancedsearchtitle' => "%s kombiniert mit den Suchergebnissen %s",
			'next' => "Weiter",
			'notfound' => "Es wurden leider keine Ergebnisse gefunden.",
			'previous' => "Zurück",
			'search' => "Suche",
			'searchtitle' => "Suche: %s",
			
			'tag:search:startblurb' => "Elemente, die auf das Tag '%s' passen:",
			
			'user:search:finishblurb' => "Um mehr anzuzeigen, hier klicken.",
			'user:search:startblurb' => "Nutzer die zu '%s' gefunden wurden:",
			
			'users:searchtitle' => "Nutzersuche: %s",
			
			'viewtype:change' => "Ansicht ändern",
			'viewtype:gallery' => "Galerie",
			'viewtype:list' => "Listenansicht",

        /**
        * Account
        */

			'account' => "Nutzerkonto",
			'adduser' => "Nutzer hinzufügen",
			'adduser:bad' => "Der neue Nutzer konnte nicht eingerichtet werden.",
			'adduser:ok' => "Du hast erfolgreich einen neuen Nutzer hinzugefügt.",
			'register' => "Registrieren",
			'registerbad' => "Deine Registrierung war nicht erfolgreich. Mögliche Gründe: Den Nutzernamen gibt es schon, die Passwörter waren nicht gleich oder aber der Nutzernamen oder das Passwort waren zu kurz.",
			'registerdisabled' => "Die Registrierung wurde vom Systemadministrator abgeschaltet.",
			'registerok' => "Du wurdest bei %s erfolgreich registriert. Um Dein Nutzerkonto zu aktivieren, bestätige bitte Deine Emailadresse, indem Du auf den Link in der Email klickst, die Dir soeben geschickt wurde.",
			
			'registration:dupeemail' => "Diese Emailadresse wurde bereits für ein Nutzerkonto angegeben.",
			'registration:emailnotvalid' => "Leider ist die eingetragene Mail-Adresse nicht bekannt.",
			'registration:invalidchars' => "Dein Nutzername enthält nicht zulässige Zeichen.",
			'registration:notemail' => "Die angegebene Emailadresse scheint nicht gültig zu sein...",
			'registration:passwordnotvalid' => "Leider ist das eingetragene Kennwort nicht bekannt.",
			'registration:passwordtooshort' => "Das Passwort muss mindestens sechs Buchstaben lang sein.",
			'registration:userexists' => "Diesen Nutzernamen gibt es leider bereits",
			'registration:usernamenotvalid' => "Leider ist der eingetragene Nutzer nicht bekannt.",
			'registration:usernametooshort' => "Der Nutzername muss mindestens vier Buchstaben lang sein.",
			
			'settings' => "Einstellungen",
			
			'tools' => "Werkzeuge",
			'tools:yours' => "Deine Werkzeuge",
			
			'user:language:fail' => "Deine Spracheinstellungen konnten nicht geändert werden.",
			'user:language:label' => "Deine Sprache",
			'user:language:success' => "Deine Spracheinstellungen wurden geändert.",
			'user:name:fail' => "Dein Nutzername konnte nicht geändert werden.",
			'user:name:label' => "Dein Name",
			'user:name:success' => "Dein Nutzername wurde im System erfolgreich geändert.",
			'user:password:fail' => "Dein Passwort konnte nicht geändert werden.",
			'user:password:fail:notsame' => "Die beiden Passwörter stimmen nicht überein!",
			'user:password:fail:tooshort' => "Das Passwort ist zu kurz!",
			'user:password:label' => "Dein neues Passwort",
			'user:password:lost' => "Passwort vergessen",
			'user:password:resetreq:fail' => "Das Passwort konnte nicht neu erstellt werden.",
			'user:password:resetreq:success' => "Dir wurde soeben eine Email mit dem neuen Passwort geschickt.",
			'user:password:success' => "Das Passwort wurde geändert.",
			'user:password:text' => "Für ein neues Passwort gibst Du bitte Deinen Nutzernamen ein. Wir schicken Dir per Email dann einen Link, mit dem Du die Anfrage eines neuen Passworts bestätigen musst. Danach erhältst Du eine Mail mit Deinem neuen Passwort.",
			'user:password2:label' => "Neues Passwort wiederholen",
			'user:persistent' => "Angemeldet bleiben",
			'user:set:language' => "Spracheinstellungen",
			'user:set:name' => "Einstellungen zum Nutzernamen",
			'user:set:password' => "Passwort für das Nutzerkonto",
			'user:username:notfound' => "Der Nutzername %s wurde nicht gefunden.",

        /**
        * Administration
        */

			'admin' => "Administration",
			'admin:configuration:fail' => "Deine Einstellungen konnten nicht gespeichert werden.",
			'admin:configuration:success' => "Deine Einstellungen wurden gespeichert.",
			'admin:description' => "Die Admin-Seite erlaubt es Dir, alle Einstellungen des Systems von der Nutzerverwaltung bis hin zum Verhalten der Plugins zu kontrollieren. Wähle unten eine Option um zu beginnen.",
			'admin:plugins' => "Werkzeug Verwaltung",
			'admin:plugins:description' => "Diese Adminseite erlaubt Dir, die auf der Seite installierten Werkzeuge und Erweiterungen zu kontrollieren.",
			'admin:plugins:disable:no' => "Das Plugin %s konnte nicht deaktiviert werden.",
			'admin:plugins:disable:yes' => "Das Plugin %s wurde erfolgreich deaktiviert.",
			'admin:plugins:enable:no' => "Das Plugin %s konnte nicht aktiviert werden.",
			'admin:plugins:enable:yes' => "Das Plugin %s wurde erfolgreich aktiviert.",
			'admin:plugins:label:author' => "Autor",
			'admin:plugins:label:copyright' => "Copyright",
			'admin:plugins:label:licence' => "Lizenz",
			'admin:plugins:label:website' => "URL",
			'admin:plugins:opt:description' => "Konfiguriere die Anwendungen, welche auf der Seite installiert sind... ",
			'admin:plugins:opt:linktext' => "Anwendungen konfigurieren...",
			'admin:plugins:reorder:no' => "Reihenfolge von Plugin %s konnte nicht geändert werden.",
			'admin:plugins:reorder:yes' => "Reihenfolge von Plugin %s wurde erfolgreich geändert.",
			'admin:site' => "Seitenadministration",
			'admin:site:description' => "Diese Adminseite erlaubt Dir die globlalen Einstellungen der Seite zu kontrollieren. Wähle eine Option unten um zu beginnen.",
			'admin:site:opt:description' => "Kontrolliere technische und nichttechnische Einstellungen. ",
			'admin:site:opt:linktext' => "Seite konfigurieren...",
			'admin:statistics' => "Statistik",
			'admin:statistics:description' => "Auf dieser Seite erhälst Du einen Statistiküberblick. Falls Du detailliertere Statistiken brauchst, steht Dir auch ein professionelles Administrations-Feature zur Verfügung.",
			'admin:statistics:label:basic' => "Allgemeine Statistik der Seite",
			'admin:statistics:label:numentities' => "Einheiten auf der Seite",
			'admin:statistics:label:numonline' => "Nutzer online",
			'admin:statistics:label:numusers' => "Zahl der Nutzer",
			'admin:statistics:label:onlineusers' => "Jetzt online",
			'admin:statistics:label:version' => "Elgg Version",
			'admin:statistics:label:version:release' => "Release",
			'admin:statistics:label:version:version' => "Version",
			'admin:statistics:opt:description' => "Statistische Informationen über Nutzer und Objekte auf Deiner Seite.",
			'admin:statistics:opt:linktext' => "Statistiken einsehen...",
			'admin:user' => "Nutzerverwaltung",
			'admin:user:adduser:label' => "Klicke hier, um einen neuen Nutzer hinzuzufügen...",
			'admin:user:ban:no' => "Nutzerkonto kann nicht gesperrt werden",
			'admin:user:ban:yes' => "Nutzerkonto gesperrt.",
			'admin:user:delete:no' => "Nutzerkonto kann nicht gelöscht werden",
			'admin:user:delete:yes' => "Nutzerkonto gelöscht",
			'admin:user:description' => "Diese Adminseite erlaubt Dir die Nutzereinstellungen auf der Seite zu kontrollieren. Wähle eine Option unten um zu beginnen.",
			'admin:user:label:seachbutton' => "Suche",
			'admin:user:label:search' => "Nutzer suchen:",
			'admin:user:makeadmin:no' => "Dem Nutzer konnten keine Administratorenrechte erteilt werden.",
			'admin:user:makeadmin:yes' => "Der Nutzer hat nun Administratorenrechte.",
			'admin:user:opt:description' => "Nutzereinstellungen und Informationen zu Nutzerkonten. ",
			'admin:user:opt:linktext' => "Nutzereinstellungen...",
			'admin:user:resetpassword:no' => "Das Passwort konnte nicht neu gesetzt werden.",
			'admin:user:resetpassword:yes' => "Das Passwort wurde neu gesetzt, der Nutzer wurde benachrichtigt.",
			'admin:user:unban:no' => "Nutzerkonto kann nicht freigeschaltet werden",
			'admin:user:unban:yes' => "Nutzerkonto freigeschaltet.",

        /**
        * User settings
        */
     
			'usersettings:description' => "Unter Nutzereinstellungen kannst Du alle persönlichen Einstellungen vom Nutzermanagment bis zum Verhalten der Plugins kontrollieren. Wähle unten eine der Optionen.",
			'usersettings:plugins' => "Anwendungen",
			'usersettings:plugins:description' => "Auf dieser Seite kannst Du die persönlichen Einstellungen für die Tools, die vom Administrator für Dich installiert wurden, kontrollieren und konfigurieren.",
			'usersettings:plugins:opt:description' => "Einstellungen für die aktiven Anwendungen.",
			'usersettings:plugins:opt:linktext' => "Konfiguriere Deine Anwendungen...",
			'usersettings:statistics' => "Deine Statistik",
			'usersettings:statistics:label:email' => "Emailadresse",
			'usersettings:statistics:label:lastlogin' => "Zuletzt online",
			'usersettings:statistics:label:membersince' => "Angemeldet seit",
			'usersettings:statistics:label:name' => "Voller Name",
			'usersettings:statistics:label:numentities' => "Deine Objekte",
			'usersettings:statistics:opt:description' => "Statistische Information über Nutzer und Objekte auf Deiner Seite.",
			'usersettings:statistics:opt:linktext' => "Statistik für das Nutzerkonto",
			'usersettings:statistics:yourdetails' => "Deine Details",
			'usersettings:user' => "Deine Einstellungen",
			'usersettings:user:opt:description' => "Hier kannst Du die Nutzereinstellungen kontrollieren.",
			'usersettings:user:opt:linktext' => "Einstellungen ändern",

        /**
        * Generic action words
        */

			'active' => "Aktiv",
			'ban' => "Sperren",
			'bottom' => "letzter",
			'cancel' => "Abbrechen",
			'close' => "Schließen",
			'complete' => "Vervollständigen",
			'content' => "Inhalt",
			'content:latest' => "Neuste Aktivitäten",
			'content:latest:blurb' => "Alternativ kannst Du hier die neusten Inhalte der ganzen Seite sehen.",
			'delete' => "Löschen",
			'disable' => "Deaktivieren",
			'down' => "runter",
			'edit' => "Bearbeiten",
			'enable' => "Aktivieren",
			'invite' => "Einladung",
			'learnmore' => "Mehr Informationen.",
			'load' => "Laden",
			'makeadmin' => "Adminrechte geben",
			'moreinfo' => "mehr Informationen",
			'open' => "Öffnen",
			'option:no' => "Nein",
			'option:yes' => "Ja",
			'reply' => "Antworten",
			'request' => "Anfrage",
			'resetpassword' => "Passwort ändern",
			'save' => "Speichern",
			'saving' => "Speichern ...",
			'top' => "erster",
			'total' => "Gesamt",
			'unban' => "Freischalten",
			'unknown' => "Unbekannt",
			'up' => "hoch",
			'update' => "Aktualisieren",
			'upload' => "Hochladen",

        /**
        * Generic data words
        */

			'all' => "Alle",
			'annotations' => "Anmerkungen",
			'by' => "von",
			'description' => "Beschreibung",
			'metadata' => "Metadaten",
			'relationships' => "Beziehungen",
			'spotlight' => "Spotlight",
			'tags' => "Tags",
			'title' => "Titel",

        /**
        * Input / output strings
        */

			'deleteconfirm' => "Bist du sicher, dass Du diesen Eintrag löschen willst?",
			'fileexists' => "Die Datei wurde bereits hochgeladen. Wähle unten, welche ersetzt werden soll:",

        /**
        * System messages
        **/

			'systemmessages:dismiss' => "Klicken zum Verwerfen.",

        /**
        * Import / export
        */
     
			'importfail' => "OpenDD Import der Daten ist fehlgeschlagen.",
			'importsuccess' => "Die Daten wurden erfolgreich importiert.",

        /**
        * Time
        */

			'friendlytime:days' => "vor %s Tagen",
			'friendlytime:days:singular' => "gestern",
			'friendlytime:hours' => "vor %s Stunden",
			'friendlytime:hours:singular' => "vor einer Stunde",
			'friendlytime:justnow' => "jetzt gerade",
			'friendlytime:minutes' => "vor %s Minuten",
			'friendlytime:minutes:singular' => "vor einer Minute",

        /**
        * Installation und Systemeinstellungen
        */

			'installation' => "Installation",
			'installation:configuration:success' => "Die Einstellungen wurden gespeichert. Melde nun den ersten Nutzer an. Er wird auch der erste Administrator der Seite sein.",
			'installation:dataroot' => "Kompletter Pfad zum Verzeichnis in dem die hochgeladenen Dateien gespeichert werden, abgeschlossen mit einem Schrägstrich:",
			'installation:dataroot:warning' => "Du must dieses Verzeichnis manuell erstellen. Es darf sich nicht innerhalb des Elgg-Verzeichnisses befinden.",
			'installation:debug' => "Der Debug-Modus gibt Dir zusätzliche Informationen, die bei der Behebung von Fehlern hilfreich sein können. Allerdings läuft Dein System dadurch langsamer. Daher sollte dieser Modus nur aktiviert werden, wenn Du Probleme hast:",
			'installation:debug:label' => "Debug Modus aktivieren",
			'installation:disableapi' => "Elgg verfügt über eine flexible und erweiterbare Schnittstellenarchitektur, die es anderen Anwendungen erlaubt Funktionen von Elgg zu benutzen",
			'installation:disableapi:label' => "Schnitstelle (RESTful API) aktivieren",
			'installation:error:configuration' => "Korrigiere die Einstellungen und aktualisiere die Seite.",
			'installation:error:htaccess' => "
Elgg braucht eine Datei mit dem Namen .htaccess im Root-Verzeichnis der Installation. Das Installationsprogramm hat versucht diese Datei einzurichten, aber Elgg hat keine Schreibrechte in dem Verzeichnis.

Du kannst diese Datei leicht einrichten. Kopiere den Inhalt aus dem Textfeld unten in einen Texteditor und speicher die Datei als .htaccess in deinem Root-Verzeichnis.",

			'installation:error:settings' => "
Elgg konnte die Datei mit den Einstellungen nicht finden. Die meisten Einstellungen von Elgg kannst Du persönlich steuern, aber wir brauchen die Details für Deine Datenbankverbindung. Mache bitte folgendes:

1. Änder den Namen der Datei engine/settings.example.php in Deiner Elgg-Installation zu settings.php.

2. Öffne die Datei in einem Texteditor und gebe die Daten für Deine MySQL Datenbank ein. Wenn Du diese nicht kennst, frage Deinen Systemadministrator oder bitte den technischen Support um Hilfe.

Alternativ kannst Du die Datenbankverbindung unten eingeben und das Installationsprogramm versucht diesen Schritt für Dich durchzuführen ...",

			'installation:language' => "Sprache für Deine Seite:",
			'installation:path' => "Kompletter Pfad zu Deiner Installation, abgeschlossen mit einem Schrägstrich:",
			'installation:settings' => "Systemeinstellungen",
			'installation:settings:dbwizard:label:dbname' => "Elggdatenbank",
			'installation:settings:dbwizard:label:host' => "Datenbankhost (normalerweise 'localhost')",
			'installation:settings:dbwizard:label:pass' => "Datenbankpasswort",
			'installation:settings:dbwizard:label:prefix' => "Datenbanktabellenpräfix (normalerweise 'elgg')",
			'installation:settings:dbwizard:label:user' => "Datenbanknutzer",
			'installation:settings:dbwizard:prompt' => "Gebe die Datenbankverbindung ein und klicke speichern:",
			'installation:settings:dbwizard:savefail' => "Die neue Datei settings.php konnte nicht gespeichert werden. Bitte speicher die folgende Datei als engine/settings.php in einem Texteditor.",
			'installation:settings:description' => "Die Elgg-Datenbank wurde erfolgreich installiert. Nun musst Du noch einige weitere Informationen eingeben, um die Seite vollständig einzurichten. Das Installationsprogramm versucht, die notwendigen Daten selbst herauszufinden, aber vielleicht müssen einige der Details korrigiert werden.",
			'installation:sitedescription' => "Kurzbeschreibung für Deine Seite (optional)",
			'installation:siteemail' => "Mail-Adresse Deiner Seite (wird für Mail's verwendet, die über Deine Seite verschickt werden)",
			'installation:sitename' => "Name für Deine Seite (z.B. \"Mein soziales Netzwerk\"):",
			'installation:success' => "Die Datenbank von Elgg wurde erfolgreich installiert.",
			'installation:usage' => "Diese Option erlaubt es Elgg anonyme Statistiken über die Nutzung an Curverider zu übermitteln.",
			'installation:usage:label' => "Anonyme Statistiken über die Nutzung übermitteln",
			'installation:view' => "Gib an, welche Standardansicht für Deine Seite benutzt werden soll (z.B mobil) oder lassen den Eintrag leer, um die Standardansicht zu verwenden:",
			'installation:wwwroot' => "URL zu Deiner Seite, abgeschlossen mit einem Schrägstrich:",
			
			'upgrade:core' => "Deine Elgg-Installation wurde aktualisiert.",
			'upgrade:db' => "Deine Datenbank wurde aktualisert.",
			'upgrading' => "Aktualisierung",

        /**
        * Welcome
        */

			'welcome' => "Wilkommen %s",
			'welcome_message' => "Wilkommen zur Installation von Elgg.",

        /**
        * Emails
        */
     
			'email:address:label' => "Deine Emailadresse",
			'email:confirm:fail' => "Die angegebene Emailadresse konnte nicht bestätigt werden ...",
			'email:confirm:success' => "Die Emailadresse wurde bestätigt!",
			'email:resetpassword:subject' => "Neues Passwort!",
			'email:resetpassword:body' => "
Hallo %s,

Dein neues Passwort ist: %s",

			'email:resetreq:subject' => "Anfrage für ein neues Passwort.",
			'email:resetreq:body' => "
Hallo %s,

Jemand hat (von der IP Adresse %s aus) ein neuese Passwort für Dein Nutzerkonto angefordert.

Wenn Du dieses Passwort angefordert hast, klicke den Link unten und es wird Dir erneut eine Email mit einem vorläufigen Passwort geschickt. 
Ansonsten mache bitte nichts weiter.

%s",

			'email:settings' => "Emaileinstellungen",
			'email:save:fail' => "Deine neue Emailadresse konnte nicht gespeichert werden.",
			'email:save:success' => "Die neue Emailadresse wurde gespeichert, eine Bestätigungsanfrage wurde verschickt.",

			'friend:newfriend:subject' => "%s hat Dich als Freund hinzugefügt!",
			'friend:newfriend:body' => "
%s hat Dich als Freund hinzugefügt!

Hier kommst Du zur Profilseite:

          %s

Nicht auf diese Email antworten.",

        /**
        * XML-RPC
        */
        
			'xmlrpc:noinputdata' => "Keine Daten",

        /**
        * Comments
        */

			'comments:count' => "%s Kommentare",
			'generic_comment:blank' => "Entschuldigung, aber Du musst erst etwas schreiben, bevor Du den Kommentar speichern kannst.",
			'generic_comment:email:subject' => "Du hast einen neuen Kommentar!",
			'generic_comment:email:body' => "
Du hast zum Eintrag '%s' einen neuen Kommentar von %s bekommen. Hier der Text:

%s

Wenn Du antworten oder den Orginaleintrag sehen willst, klicke bitte hier:

          %s

Um das Profil von %s zu sehen, klicke bitte hier:

          %s

Bitte nicht auf diese Mail anworten!",

			'generic_comment:deleted' => "Dein Kommentar wurde gelöscht.",
			'generic_comment:failure' => "Beim Speichern des Kommentars ist ein Fehler aufgetreten. Bitte versuche es nochmal.",
			'generic_comment:notdeleted' => "Der Kommentar konnte leider nicht gelöscht werden.",
			'generic_comment:notfound' => "Wir konnten den angegebenen Eintrag leider nicht finden.",
			'generic_comment:posted' => "Dein Kommentar wurde abgeschickt.",
			'generic_comments:add' => "Einen Kommentar schreiben",
			'generic_comments:text' => "Kommentar",
			
			'riveraction:annotation:generic_comment' => "%s Kommentiert am %s",

        /**
        * Entities
        */
     
			'entity:default:missingsupport:popup' => "Dieser Eintrag kann nicht angezeigt werden. Das könnte daran liegen, dass ein Plugin benötigt wird, das deinstalliert wurde..",
			'entity:default:strapline' => "%s geschrieben von %s",
			'entity:delete:fail' => "Der Eintrag %s konnte nicht gelöscht werden",
			'entity:delete:success' => "Der Eintrag %s wurde gelöscht",

        /**
        * Action gatekeeper
        */
     
			'actiongatekeeper:missingfields' => "Im Formular fehlen die Felder __token oder __ts ",
			'actiongatekeeper:pluginprevents' => "Eine Erweiterung verhindert, dass das Formular korrekt abgeschickt werden kann.",
			'actiongatekeeper:timeerror' => "Das Formular ist abgelaufen. Bitte aktualisiere die Seite und versuche es noch einmal.",
			'actiongatekeeper:tokeninvalid' => "Der im Formular mitgeschickte Schlüssel entspricht nicht dem auf dem Server hinterlegten.",

        /**
        * Word blacklists
        */
	 
			'word:blacklist' => "and, the, then, but, she, his, her, him, one, not, also, about, now, hence, however, still, likewise, otherwise, therefore, conversely, rather, consequently, furthermore, nevertheless, instead, meanwhile, accordingly, this, seems, what, whom, whose, whoever, whomever",
	
		/**
		 * Languages according to ISO 639-1
		 * Only translate and uncomment the line for your language
		 */
		 
			//'aa' => "Afar",
			//'ab' => "Abkhazian",
			//'af' => "Afrikaans",
			//'am' => "Amharic",
			//'ar' => "Arabic",
			//'as' => "Assamese",
			//'ay' => "Aymara",
			//'az' => "Azerbaijani",
			//'ba' => "Bashkir",
			//'be' => "Byelorussian",
			//'bg' => "Bulgarian",
			//'bh' => "Bihari",
			//'bi' => "Bislama",
			//'bn' => "Bengali; Bangla",
			//'bo' => "Tibetan",
			//'br' => "Breton",
			//'ca' => "Catalan",
			//'co' => "Corsican",
			//'cs' => "Czech",
			//'cy' => "Welsh",
			//'da' => "Danish",
			'de' => "Deutsch",
			//'dz' => "Bhutani",
			//'el' => "Greek",
			//'en' => "English",
			//'eo' => "Esperanto",
			//'es' => "Spanish",
			//'et' => "Estonian",
			//'eu' => "Basque",
			//'fa' => "Persian",
			//'fi' => "Finnish",
			//'fj' => "Fiji",
			//'fo' => "Faeroese",
			//'fr' => "French",
			//'fy' => "Frisian",
			//'ga' => "Irish",
			//'gd' => "Scots / Gaelic",
			//'gl' => "Galician",
			//'gn' => "Guarani",
			//'gu' => "Gujarati",
			//'he' => "Hebrew",
			//'ha' => "Hausa",
			//'hi' => "Hindi",
			//'hr' => "Croatian",
			//'hu' => "Hungarian",
			//'hy' => "Armenian",
			//'ia' => "Interlingua",
			//'id' => "Indonesian",
			//'ie' => "Interlingue",
			//'ik' => "Inupiak",
			//'in' => "Indonesian",
			//'is' => "Icelandic",
			//'it' => "Italian",
			//'iu' => "Inuktitut",
			//'iw' => "Hebrew (obsolete)",
			//'ja' => "Japanese",
			//'ji' => "Yiddish (obsolete)",
			//'jw' => "Javanese",
			//'ka' => "Georgian",
			//'kk' => "Kazakh",
			//'kl' => "Greenlandic",
			//'km' => "Cambodian",
			//'kn' => "Kannada",
			//'ko' => "Korean",
			//'ks' => "Kashmiri",
			//'ku' => "Kurdish",
			//'ky' => "Kirghiz",
			//'la' => "Latin",
			//'ln' => "Lingala",
			//'lo' => "Laothian",
			//'lt' => "Lithuanian",
			//'lv' => "Latvian/Lettish",
			//'mg' => "Malagasy",
			//'mi' => "Maori",
			//'mk' => "Macedonian",
			//'ml' => "Malayalam",
			//'mn' => "Mongolian",
			//'mo' => "Moldavian",
			//'mr' => "Marathi",
			//'ms' => "Malay",
			//'mt' => "Maltese",
			//'my' => "Burmese",
			//'na' => "Nauru",
			//'ne' => "Nepali",
			//'nl' => "Dutch",
			//'no' => "Norwegian",
			//'oc' => "Occitan",
			//'om' => "(Afan) Oromo",
			//'or' => "Oriya",
			//'pa' => "Punjabi",
			//'pl' => "Polish",
			//'ps' => "Pashto / Pushto",
			//'pt' => "Portuguese",
			//'qu' => "Quechua",
			//'rm' => "Rhaeto-Romance",
			//'rn' => "Kirundi",
			//'ro' => "Romanian",
			//'ru' => "Russian",
			//'rw' => "Kinyarwanda",
			//'sa' => "Sanskrit",
			//'sd' => "Sindhi",
			//'sg' => "Sangro",
			//'sh' => "Serbo-Croatian",
			//'si' => "Singhalese",
			//'sk' => "Slovak",
			//'sl' => "Slovenian",
			//'sm' => "Samoan",
			//'sn' => "Shona",
			//'so' => "Somali",
			//'sq' => "Albanian",
			//'sr' => "Serbian",
			//'ss' => "Siswati",
			//'st' => "Sesotho",
			//'su' => "Sundanese",
			//'sv' => "Swedish",
			//'sw' => "Swahili",
			//'ta' => "Tamil",
			//'te' => "Tegulu",
			//'tg' => "Tajik",
			//'th' => "Thai",
			//'ti' => "Tigrinya",
			//'tk' => "Turkmen",
			//'tl' => "Tagalog",
			//'tn' => "Setswana",
			//'to' => "Tonga",
			//'tr' => "Turkish",
			//'ts' => "Tsonga",
			//'tt' => "Tatar",
			//'tw' => "Twi",
			//'ug' => "Uigur",
			//'uk' => "Ukrainian",
			//'ur' => "Urdu",
			//'uz' => "Uzbek",
			//'vi' => "Vietnamese",
			//'vo' => "Volapuk",
			//'wo' => "Wolof",
			//'xh' => "Xhosa",
			//'yi' => "Yiddish",
			//'yo' => "Yoruba",
			//'za' => "Zuang",
			//'zh' => "Chinese",
			//'zu' => "Zulu",
        
	);
	add_translation('de', $german);

?>