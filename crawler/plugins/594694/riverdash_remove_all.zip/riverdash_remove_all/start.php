<?php

	/**
	 * Riverdashboard Remove "All" tab
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Damir Gasparlin
	 * @copyright juipo.com 2009-2010
	 * @link http://juipo.com/
	 */

		function riverdash_remove_all_init() {
		
			global $CONFIG;

					
		
			
			
		}
		
	
		
		register_elgg_event_handler('init','system','riverdash_remove_all_init');

	
?>