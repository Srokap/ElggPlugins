For Support and Questions please go to http://juipo.com/plugins/elgg-plugins/remove-all-tab-in-riverdashboard/ and post a comment or contact us.

How to install

    * Unzip riverdash_remove_all.zip onto your PC.
    * Upload riverdash_remove_all folder to your mod/ directory on your server
    * Make sure plugin is at the bottom of the plugin list and �Enable� it.

    * If you wish to display �friends� updates as default, upload index.php from riverdashboard folder inside the zip file and replace existing index.php in mod/riverdashboard/ directory on your server.
