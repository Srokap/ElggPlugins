<?php
/**
 * 
 */
?>
<label>
	<input type="checkbox" name="agreetoterms" value="true">
	<?php echo elgg_echo('agreetoterms')." <a href=\"{$vars['url']}pg/expages/read/Terms/\" target=\"_blank\">".elgg_echo('terms')."</a>".e."<a href=\"{$vars['url']}pg/expages/read/Privacy/\" target=\"_blank\">".elgg_echo('privacy')."</a>"; ?>
</label><br/>