<?php
$english = array(
	'agreetoterms' => "I have read and agree to the",
	'terms' => 'Terms',

	'agreetoterms:required' => "You must first agree to the terms",
);

add_translation("en",$english);
?>