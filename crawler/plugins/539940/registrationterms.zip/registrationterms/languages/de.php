<?php
$german = array(
	'agreetoterms' => "Ich akzeptiere die ",
	'terms' => 'AGB&nbsp;',
	'privacy' => '&nbsp;Datenschutzerkl&auml;rung',

	'agreetoterms:required' => "Bitte akzeptiere die AGB und Datenschutzerkl&auml;rung!",
);

add_translation("de",$german);
?>