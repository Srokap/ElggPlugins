<?php
$italian = array(
	'agreetoterms' => "Ho letto e accettato i termini d'uso della piattaforma ",
	'terms' => 'Terms ',
  'privacy' => '  Privacy ',
	'agreetoterms:required' => "Devi accettare le condizioni d'uso prima di iscriverti",
);

add_translation("it",$italian);
?>