<?php
  function mymusic_init() {        
    add_widget_type('player', elgg_echo('mymusic:widget_name'), 'Music player widget');
  }
 
  register_elgg_event_handler('init','system','mymusic_init');       
?>