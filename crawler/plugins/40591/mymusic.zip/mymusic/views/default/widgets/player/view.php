<?

$files = get_user_objects($vars['entity']->owner_guid, "file", $number, 0);

$lk="";
$tl="";

	if ($files) {
    	
        	
            //display in gallery mode
            foreach($files as $f){
           	
           	
                $mime = $f->mimetype;
                $filename = $f->originalfilename;
                $type = substr($filename, strlen($filename)-3, strlen($filename));
                //echo $type.'<BR>'.$filename.'<BR><BR>'; 
            	//if ($mime == "audio/mpeg"){
            	if ($type == "mp3" || $type == "MP3"){
                    $file = get_entity($f->guid);  	
                    $lk = $lk . '/action/file/download?file_guid=' . $f->guid . "|";
                    $tl = $tl . $f->title . "|";
                }            				
            }
        $lk = substr($lk, 0, strlen($lk)-1);            
        $tl = substr($tl, 0, strlen($tl)-1);
            	
        echo '
            <object type="application/x-shockwave-flash" data="' . $vars['url'] . 'mod/mymusic/audioplayer/player_mp3_multi.swf" width="300" height="300">
                <param name="movie" value="' . $vars['url'] . 'mod/mymusic/audioplayer/player_mp3_multi.swf" />
                <param name="bgcolor" value="#ffffff" />
                <param name="FlashVars" value="mp3=' . $lk . '&amp;title=' . $tl . '&amp;width=300&amp;height=300&amp;volume=200" />
            </object>
        ';                       				
	} 
?>

