<?php
 
  $russian = array(	
      'mymusic:widget_name' => 'Плеер',	
	);
 
  add_translation("ru",$russian);
 
?>