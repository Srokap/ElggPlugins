<?php
 
  $english = array(	
      'mymusic:widget_name' => 'My music!',	
	);
 
  add_translation("en",$english);
 
?>