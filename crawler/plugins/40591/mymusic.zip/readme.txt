For correct work edit a file .htaccess

<IfModule mod_php5.c>
	# default memory limit to 64Mb
	php_value memory_limit 64M
	# to make sure register global is off
	php_value register_globals 0
	# max post size to 60Mb
	php_value post_max_size 60388608
	# upload size limit to 60Mb	
	php_value upload_max_filesize 60242880
	# hide errors, enable only if debug enabled
	php_value display_errors 0
</IfModule>