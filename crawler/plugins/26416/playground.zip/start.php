<?php

	/**
	 * Elgg playgroud widget
	 * This plugin allows users to pull in their Lastest playgrouddisplay 
	 * 
	 * @package Elgg playgroud
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Bubu <webmaster@lungkao.com>
	 * @Skype konlungkao
	 * @twitter lungkao
	 * @copyright Laithai 2008-2009
	 * @link http://elgg.in.th/
	 */
	
		function playgroud_init() {
    		
    		
    		//add a widget
			    add_widget_type('playgroud',"Playgroud","This is your Lastest playgroud feed");
			
		}
		
		register_elgg_event_handler('init','system','playgroud_init');

?>