<?php

/**
	 * Elgg playgroud widget
	 * This plugin allows users to pull in their Lastest playgrouddisplay 
	 * 
	 * @package Elgg playgroud
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Bubu <webmaster@lungkao.com>
	 * @Skype konlungkao
	 * @twitter lungkao
	 * @copyright Laithai 2008-2009
	 * @link http://elgg.in.th/
	 */

?>
	<p>
		<?php echo elgg_echo("playgroud:id"); ?>
		<input type="text" name="params[playgroud_id]" value="<?php echo htmlentities($vars['entity']->playgroud_id); ?>" />	
		<br /><?php echo elgg_echo("playgroud:num"); ?>
		<input type="text" name="params[playgroud_num]" value="<?php echo htmlentities($vars['entity']->playgroud_num); ?>" />	
	
	</p>