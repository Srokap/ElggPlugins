<?php

	$english = array(
	
		/**
		 * playgroud widget details
		 */
		
	
		'playgroud:id' => 'Enter your playgroud ID.',
		'playgroud:num' => 'The number of playgroud to show.',
		'playgroud:visit' => 'visit my playgroud',
		'playgroud:notset' => 'This playgroud widget is not yet set to go. To display your latest Image, click on - edit - and fill in your details',
		
		
		 /**
	     * playgroud widget river
	     **/
	        
	        //generic terms to use
	        'playgroud:river:created' => "%s added the playgroud widget.",
	        'playgroud:river:updated' => "%s updated their playgroud widget.",
	        'playgroud:river:delete' => "%s removed their playgroud widget.",
	        
		
	);
					
	add_translation("en",$english);

?>