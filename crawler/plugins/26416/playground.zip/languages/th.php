<?php

	$thai = array(
	
		/**
		 * playgroud widget details
		 */
		
	
		'playgroud:id' => 'ใส่ playgroud ID.',
		'playgroud:num' => 'จำนวนรูปที่ต้องการแสดง',
		'playgroud:notset' => 'ตรงนี้จะแสดงรูปล่าสุดในของคุณในเว็บ Playground คลิ๊ก แก้ไขเพื่อใส่รายละเอียด',
		
		
		 /**
	     * playgroud widget river
	     **/
	        
	        //generic terms to use
	        'playgroud:river:created' => "%s เพิ่ม Playground วิดเจ็ต",
	        'playgroud:river:updated' => "%s อัพเดตPlayground วิดเจ็ต",
	        'playgroud:river:delete' => "%s ลบ Playground วิดเจ็ต",
	        
		
	);
					
	add_translation("th",$thai);

?>