<?php

$english = array(
	'expirationdate:minute' => '1 minute',
	'expirationdate:fiveminute' => '5 minutes',
	'expirationdate:fifteenminute' => '15 minutes',
	'expirationdate:halfhour' => '30 minutes',
	'expirationdate:hourly' => '1 hour',
	'expirationdate:daily' => '1 day',
	'expirationdate:weekly' => '1 week',
	'expirationdate:monthly' => '1 month',
	'expirationdate:yearly' => '1 year',
	'expirationdate:period' => 'Check for expired entities every: ',

);

add_translation("en", $english);
