<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Cargando ...</title>
<style type="text/css">
#fuera { margin-top: 10%; margin-left: 30%;}+
#f {font-family:"Myriad Pro", Arial; font-size:12px; color:#CCC; padding: 5px;}

#publi {
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	height: auto;
	width: 500px;
	background-color: #B7B7B7;
	padding: 10px;
	text-align: center;
}
.texpat {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color:#CCC;
	padding: 5px;
}
.anuntexpat {
	color:#C00;
	}
.anu { -webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	background:#FFF;
	padding:5px;
	font:Arial, Helvetica, sans-serif;
	}
body {
	background-color: #F8F8F8;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
a:active {
	text-decoration: none;
}
</style>

</head>

<body>
<div class="fuera" id="fuera"><div class="publi" id="publi">
  <div align="center" class="anu" id="anu">
/** CODIGO GOOGLE ADS **/
  </div>
</div>
<div class="texpat" id="f">Anuncio de <span id="counter" style="color: rgb(255, 0, 0); "></span>
  <script src="./load/mootools-1.2.3-core.js" type="text/javascript"></script>
<script src="./load/mootools-1.2.3.1-more.js" type="text/javascript"></script>
<script src="./load/Countdown.js" type="text/javascript"></script>
<script type="text/javascript">
	var pagina = 'index.php';
    new Countdown($('counter'), {
      'decimals' : '3',
      'onComplete' : function() {document.location.href=pagina;},
      'onStep' : function(target, show) {
        if(show < 5) {
           target.setStyle('color', '#f00');
         }
         else {
           target.setStyle('color', '#000');
         }
       }
     }).start();
</script> segundos | <strong class="anuntexpat">¡Bienvenido/a!</strong></div>
</div>

</body>
</html>
