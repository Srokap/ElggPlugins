<?php
/**
 *	RATE PLUGIN
 *	@package rate
 *	@author Miguel Montes mmontesp@gmail.com
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Miguel Montes 2008
 *	@link http://community.elgg.org/pg/profile/mmontesp
 **/

	$english = array(
		'rate:rates' => "Ocena",
		'rate:rateit' => "Oceń",
		'rate:text' => "Jak ci się podoba?",
		'rate:rated' => "Już oceniałeś.",
		'rate:badguid' => "Błąd! Nie znaleziono pozycji do ocenienia.",
		'rate:badrate' => "Ocena między 0 a 5.",
		'rate:saved' => "Twoja ocena zapisana.",
		'rate:error' => "Twoja ocena nie została zapisana. Noże później?.",
		'rate:0' => "Porażka(0)",  
		'rate:1' => "Słabo (1)",
		'rate:2' => "Norma (2)",
		'rate:3' => "OK(3)",
		'rate:4' => "Dobrze (4)",
		'rate:5' => "Yup pierdziu (5)",
	);
	add_translation("pl",$polish);
?>