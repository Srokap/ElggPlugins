<?php
	echo $vars['url'] . "mod/theme_bluerounded/graphics/group_icons/defaultsmall.gif";
?>