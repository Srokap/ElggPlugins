<?php
	echo $vars['url'] . "mod/theme_bluerounded/graphics/user_icons/defaultlarge.gif";
?>