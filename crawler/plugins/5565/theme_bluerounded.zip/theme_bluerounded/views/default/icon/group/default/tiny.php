<?php
	echo $vars['url'] . "mod/theme_bluerounded/graphics/group_icons/defaulttiny.gif";
?>