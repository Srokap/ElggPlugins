<?php

    /**
     * BlueRounded theme
     **/
     
     /**
	 * Initialise the theme 
	 *
	 */
	function bluerounded_init(){
	
    }
	
	// Initialise log browser
	register_elgg_event_handler('init','system','bluerounded_init');
	
?>