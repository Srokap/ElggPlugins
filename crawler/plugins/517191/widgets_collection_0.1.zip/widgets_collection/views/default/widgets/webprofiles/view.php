<style type="text/css">
#widgets_collection_widget .pagination { display:none; }
</style>
<?php
/**
* Widgets_collection widget edit
*
* @package Elggwidgets_collection
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author Facyla <admin@facyla.fr>
* @copyright Facyla 2010
* @link http://id.facyla.net/
*/

$doyoubuzz = $vars['entity']->widgets_collection_doyoubuzz;
$delicious = $vars['entity']->widgets_collection_delicious;
$facebook = $vars['entity']->widgets_collection_facebook;
$linkedin = $vars['entity']->widgets_collection_linkedin;
$skype = $vars['entity']->widgets_collection_skype;
$twitter = $vars['entity']->widgets_collection_twitter;
$viadeo = $vars['entity']->widgets_collection_viadeo;

$rss = $vars['entity']->widgets_collection_rss;
$rss2 = $vars['entity']->widgets_collection_rss2;
$rss3 = $vars['entity']->widgets_collection_rss3;

$site = $vars['entity']->widgets_collection_site;
$site2 = $vars['entity']->widgets_collection_site2;
$site3 = $vars['entity']->widgets_collection_site3;

$mail = $vars['entity']->widgets_collection_mail;
$mail2 = $vars['entity']->widgets_collection_mail2;
$mail3 = $vars['entity']->widgets_collection_mail3;

$widgets_collection = '<div id="widgets_collection_widget">'; // Wrapper start

// Delicious
if ($delicious) { $widgets_collection .= '<a href="http://delicious.com/' . $delicious . '/" title=""><img src="' . $vars['url'] . 'mod/widgets_collection/graphics/delicious-32.png" title="' . $delicious . ' sur Delicious" alt="Delicious" /></a> '; }
// DOYouBuzz
if ($doyoubuzz) { $widgets_collection .= '<a href="http://www.doyoubuzz.com/' . $doyoubuzz . '/" title=""><img src="' . $vars['url'] . 'mod/widgets_collection/graphics/doyoubuzz-32.png" title="' . $doyoubuzz . ' sur Do You Buzz" alt="DoYouBuzz" /></a> '; }
// Facebook
if ($facebook) { $widgets_collection .= '<a href="http://www.facebook.com/' . $facebook . '" title=""><img src="' . $vars['url'] . 'mod/widgets_collection/graphics/facebook-32.png" title="Facebook" alt="Facebook" /></a> '; }
// Linkedin
if ($linkedin) { $widgets_collection .= '<a href="http://fr.linkedin.com/in/' . $linkedin . '" title="' . $linkedin . ' sur Linkedin"><img src="' . $vars['url'] . 'mod/widgets_collection/graphics/linkedin-32.png" title ="Linkedin" alt="Linkedin" /></a> '; }
// Skype
if ($skype) { $widgets_collection .= '<a href="callto://' . $skype . '" title=""><img src="' . $vars['url'] . 'mod/widgets_collection/graphics/skype-32.png" title="' . $skype . ' sur Skype" alt="Skype" /></a> '; }
// Twitter
if ($twitter) { $widgets_collection .= '<a href="http://twitter.com/' . $twitter . '" title=""><img src="' . $vars['url'] . 'mod/widgets_collection/graphics/twitter-32.png" title="' . $twitter . ' sur Twitter" alt="Twitter" /></a> '; }
// Viadeo
if ($viadeo) { $widgets_collection .= '<a href="http://www.viadeo.com/fr/profile/' . $viadeo . '" title=""><img src="' . $vars['url'] . 'mod/widgets_collection/graphics/viadeo-32.png" title="' . $viadeo . ' sur Viadeo" alt="Viadeo" /></a> '; }

/* Syndication - Fils RSS */
if ($rss) { $widgets_collection .= '<a href="' . $rss . '" title="' . $rss . '"><img src="' . $vars['url'] . 'mod/widgets_collection/graphics/rss-32.png" alt="' . $rss . '" /></a> '; }
if ($rss2) { $widgets_collection .= '<a href="' . $rss2 . '"  title="' . $rss2 . '"><img src="' . $vars['url'] . 'mod/widgets_collection/graphics/rss-32.png" alt="' . $rss2 . '" /></a> '; }
if ($rss3) { $widgets_collection .= '<a href="' . $rss3 . '"  title="' . $rss3 . '"><img src="' . $vars['url'] . 'mod/widgets_collection/graphics/rss-32.png" alt="' . $rss3 . '" /></a> '; }

/* Websites */
if ($site) { $widgets_collection .= '<a href="' . $site . '" title="' . $site . '"><img src="' . $vars['url'] . 'mod/widgets_collection/graphics/site-32.png" alt="' . $site . '" /></a> '; }
if ($site2) { $widgets_collection .= '<a href="' . $site2 . '" title="' . $site2 . '"><img src="' . $vars['url'] . 'mod/widgets_collection/graphics/site-32.png" alt="' . $site2 . '" /></a> '; }
if ($site3) { $widgets_collection .= '<a href="' . $site3 . '" title="' . $site3 . '"><img src="' . $vars['url'] . 'mod/widgets_collection/graphics/site-32.png" alt="' . $site3 . '" /></a> '; }

/* Mail */
if ($mail) { $widgets_collection .= '<a href="mailto:' . $mail . '" title="' . $mail . '"><img src="' . $vars['url'] . 'mod/widgets_collection/graphics/mail-32.png" alt="' . $mail . '" /></a> '; }
if ($mail2) { $widgets_collection .= '<a href="mailto:' . $mail2 . '" title="' . $mail2 . '"><img src="' . $vars['url'] . 'mod/widgets_collection/graphics/mail-32.png" alt="' . $mail2 . '" /></a> '; }
if ($mail3) { $widgets_collection .= '<a href="mailto:' . $mail3 . '" title="' . $mail3 . '"><img src="' . $vars['url'] . 'mod/widgets_collection/graphics/mail-32.png" alt="' . $mail3 . '" /></a> '; }

// $widgets_collection .= '<div class="widgets_collection_widget_singleitem_more"><a href="">' . elgg_echo('widgets_collection:webprofiles') . '</a></div>';

$widgets_collection .= '</div>';  // Wrapper end

echo $widgets_collection; // Displays the widget

