<?php
    /**
	 * Elgg widgets_collection widget edit
	 *
	 * @package Elggwidgets_collection
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Facyla
	 * @copyright Facyla 2010
	 * @link http://id.facyla.net/
	 */
	 
	 /* TODO
	 * paramétrages pour rendre le widget le plus générique possible :
   *  choix du owner ou des owners (array),
   *  multiselect des types de contenus à lister,
   *  ordre de tri
   *  tuples : Sujet, prédicat, valeur (=> nom affiché, nom du service, URL)
	 */

?>
	<p>
		<?php echo elgg_echo('widgets_collection:delicious'); ?>
		<input type="text" name="params[widgets_collection_delicious]" value="<?php echo htmlentities($vars['entity']->widgets_collection_delicious); ?>" />	
  </p>
	<p>
		<?php echo elgg_echo('widgets_collection:doyoubuzz'); ?>
		<input type="text" name="params[widgets_collection_doyoubuzz]" value="<?php echo htmlentities($vars['entity']->widgets_collection_doyoubuzz); ?>" />	
  </p>
	<p>
		<?php echo elgg_echo('widgets_collection:facebook'); ?>
		<input type="text" name="params[widgets_collection_facebook]" value="<?php echo htmlentities($vars['entity']->widgets_collection_facebook); ?>" />	
  </p>
	<p>
		<?php echo elgg_echo('widgets_collection:linkedin'); ?>
		<input type="text" name="params[widgets_collection_linkedin]" value="<?php echo htmlentities($vars['entity']->widgets_collection_linkedin); ?>" />	
  </p>
	<p>
		<?php echo elgg_echo('widgets_collection:skype'); ?>
		<input type="text" name="params[widgets_collection_skype]" value="<?php echo htmlentities($vars['entity']->widgets_collection_skype); ?>" />	
  </p>
	<p>
		<?php echo elgg_echo('widgets_collection:twitter'); ?>
		<input type="text" name="params[widgets_collection_twitter]" value="<?php echo htmlentities($vars['entity']->widgets_collection_twitter); ?>" />	
  </p>
	<p>
		<?php echo elgg_echo('widgets_collection:viadeo'); ?>
		<input type="text" name="params[widgets_collection_viadeo]" value="<?php echo htmlentities($vars['entity']->widgets_collection_viadeo); ?>" />	
  </p>
  
	<?php echo elgg_echo('widgets_collection:syndication'); ?>
	<p>
		<?php echo elgg_echo('widgets_collection:rss'); ?>
		<input type="text" name="params[widgets_collection_rss]" value="<?php echo htmlentities($vars['entity']->widgets_collection_rss); ?>" />	
  </p>
	<p>
		<?php echo elgg_echo('widgets_collection:rss'); ?>
		<input type="text" name="params[widgets_collection_rss2]" value="<?php echo htmlentities($vars['entity']->widgets_collection_rss2); ?>" />	
  </p>
	<p>
		<?php echo elgg_echo('widgets_collection:rss'); ?>
		<input type="text" name="params[widgets_collection_rss3]" value="<?php echo htmlentities($vars['entity']->widgets_collection_rss3); ?>" />	
  </p>

	<?php echo elgg_echo('widgets_collection:sites'); ?>
	<p>
		<?php echo elgg_echo('widgets_collection:site'); ?>
		<input type="text" name="params[widgets_collection_site]" value="<?php echo htmlentities($vars['entity']->widgets_collection_site); ?>" />	
  </p>
	<p>
		<?php echo elgg_echo('widgets_collection:site'); ?>
		<input type="text" name="params[widgets_collection_site2]" value="<?php echo htmlentities($vars['entity']->widgets_collection_site2); ?>" />	
  </p>
	<p>
		<?php echo elgg_echo('widgets_collection:site'); ?>
		<input type="text" name="params[widgets_collection_site3]" value="<?php echo htmlentities($vars['entity']->widgets_collection_site3); ?>" />	
  </p>
  
	<?php echo elgg_echo('widgets_collection:mails'); ?>
	<p>
		<?php echo elgg_echo('widgets_collection:mail'); ?>
		<input type="text" name="params[widgets_collection_mail]" value="<?php echo htmlentities($vars['entity']->widgets_collection_mail); ?>" />	
  </p>
	<p>
		<?php echo elgg_echo('widgets_collection:mail'); ?>
		<input type="text" name="params[widgets_collection_mail2]" value="<?php echo htmlentities($vars['entity']->widgets_collection_mail2); ?>" />	
  </p>
	<p>
		<?php echo elgg_echo('widgets_collection:mail'); ?>
		<input type="text" name="params[widgets_collection_mail3]" value="<?php echo htmlentities($vars['entity']->widgets_collection_mail3); ?>" />	
  </p>
