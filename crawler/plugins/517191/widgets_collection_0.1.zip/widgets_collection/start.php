<?php
	/* Widgets collection */
	
	/* Initialise le thème */
	function widgets_collection_init() {
    // Ajouts au menu pour utilisateurs enregistrés
    if (isloggedin()) {
    // add_menu(elgg_echo('Titre ou clé du titre si internationalisé'), $CONFIG->wwwroot . "../chemin/relatif/");
    }
    // extend_view('css','widgets_collection/css');
    
		//add a widget
	    add_widget_type('webprofiles',elgg_echo('widgets_collection:webprofiles'),elgg_echo('widgets_collection:webprofiles:description'));
	    add_widget_type('publications',elgg_echo('widgets_collection:publications'),elgg_echo('widgets_collection:publications:description'));
	    
    // Remplace la page d'accueil
//    register_plugin_hook('index','system','widgets_collection');
    
		// Register a page handler, so we can have nice URLs
//		register_page_handler('login','obsipaca_login_page_handler');

	}

/*
  function widgets_collection() {
    if (!@include_once(dirname(__FILE__) . "/index.php")) return false;
    return true;
  }
  
  function obsipaca_login_page_handler($page) {
    global $CONFIG;
    @include(dirname(__FILE__) . "/login.php");
    return true;
  }
*/
  
	// Initialise log browser
	register_elgg_event_handler('init','system','widgets_collection_init');
	
?>