<?php
  
  $french = array(
  
  'widgets_collection:description' => "Collection de widgets",
  'widgets_collection:webprofiles' => "Profils en ligne",
  'widgets_collection:webprofiles:description' => "Affiche un bloc avec des liens vers vos contacts et profils en ligne",
  'widgets_collection:publications' => "Publications",
  'widgets_collection:publications:description' => "Affiche l'ensemble de vos productions, par type de contenu",

  'widgets_collection:delicious' => "Delicious",
  'widgets_collection:doyoubuzz' => "Do You Buzz",
  'widgets_collection:facebook' => "Facebook",
  'widgets_collection:linkedin' => "Linkedin",
  'widgets_collection:skype' => "Skype",
  'widgets_collection:twitter' => "Twitter",
  'widgets_collection:viadeo' => "Viadeo",
  
  'widgets_collection:syndication' => "Fils RSS (syndication)",
  'widgets_collection:rss' => "Fil RSS",
  
  'widgets_collection:sites' => "Sites web",
  'widgets_collection:site' => "Site web",
  
  'widgets_collection:mails' => "Adresse de messagerie",
  'widgets_collection:mail' => "Mail",

  );
  
  add_translation("fr",$french);
  
?>