<?php
$english = array(
	'chat:step2' => 'Step 2: Have you done the chat installation? Turn this on only after you finish the installation.',
	'chat:admin' => 'Access admin panel of chat',
	'chat:install' => ' Install the chat',
);

add_translation('en', $english);
