<div align="center">
  <table width="240" border="1">
    <tr>
      <th scope="row">Google adsense</th>
      <td><iframe src="http://www.eastrolog.com/webmaster-new/daily-horoscope/webmaster-horoscope-1.php" name="Daily_Horoscopes_240x255" width="240" height="255" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" title="Daily Horoscopes 240x255"></iframe>
  </td>
      <td>Google adsense</td>
    </tr>
  </table>
</div>
