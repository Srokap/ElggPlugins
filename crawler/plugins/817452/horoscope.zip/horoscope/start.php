<?php


	function horoscope_init() 
	{
		global $CONFIG;
		add_menu('Horoscope', $CONFIG->wwwroot ."horoscope/dailyhoroscopes");	
		register_page_handler('horoscope','horoscope_page_handler');	
	}


	function horoscope_page_handler($page) 
	{

		global $CONFIG;
		if (!isset($page[0])) {
		      forward();
		}

		$base_dir = elgg_get_plugins_path() . 'horoscope/pages/horoscope';

		switch ($page[0]) {

			case 'dailyhoroscopes':
				include "$base_dir/dailyhoroscopes.php";
				break;
			default:
				include "$base_dir/dailyhoroscopes.php";
				break;
		}

		
	}
	register_elgg_event_handler('init','system','horoscope_init');
?>