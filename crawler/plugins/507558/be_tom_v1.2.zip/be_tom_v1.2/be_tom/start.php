<?php

/* Be Tom - Elgg plugin to maintain a friendship between a designated user and
 * every other site user.
 * 
 * Instructions:
 * *************
 * 1) Change ELGG_BE_TOM_USERNAME's value (in the define below) to the username of "Tom"
 * 2) Enable the plugin
 * 
 * Version 1.2 - Steve Clay: rewrote to maintain the friendship on every login
 * rather than registration. Also, non-admins cannot remove the tom user from friends.
 *
 * Version 1.1 - Zac
 * (version 1.1 fixes an issue where it works with the latest svn version, but not the 'stable' 1.0 release)
 * It's a low priority, but a future todo item will be a page in the admin interface to allow you to 
 * configure this plugin easily w/o messing with code. It's a very low priority, but if there is a lot
 * of interest I will start on it.
 */

define('ELGG_BE_TOM_USERNAME', 'onlinesupport');

function betom_init()
{
	global $CONFIG;
    register_elgg_event_handler('login', 'user', 'betom_handleUserLogin', 501);
    register_elgg_event_handler('delete', 'friend', 'betom_handleFriendDelete', 400);
}

function betom_handleUserLogin($event, $object_type, $object)
{
	global $CONFIG;
    $user = $object;
    $userGuid = $user->get('guid');
	$username = $user->get('username');
	
    if ($username == ELGG_BE_TOM_USERNAME) {
        // this is tom
        return true;
    }
    
    if (! ($tom = get_user_by_username(ELGG_BE_TOM_USERNAME))) { // assignment intentional
        return true;
    }

    $tomGuid = $tom->get('guid');
    if (user_is_friend($userGuid, $tomGuid)) {
        // already friends
        return true;
    }

    // temporarily disable friend creation events
    $createFriendEvents = array();
    if (isset($CONFIG->events['create']['friend'])) {
        $createFriendEvents = $CONFIG->events['create']['friend'];
        $CONFIG->events['create']['friend'] = array();
    }

    // Add both directions. Necessary? Used in Post User Login Update Plugin
    try {
        $user->addFriend($tomGuid);
    } catch (Exception $e) {}
	try {
        $tom->addFriend($userGuid);
    } catch (Exception $e) {}

    if ($createFriendEvents) {
        $CONFIG->events['create']['friend'] = $createFriendEvents;
    }
	return true;
}

function betom_handleFriendDelete($event, $object_type, $object) {
    global $CONFIG;
    static $messageSent = false;

    if (isadminloggedin()) {
        // makes sure that user deletes initiated by an admin can continue
        return true;
    }

    if (isset($object->guid_one) && isset($object->guid_two)) {

        if (! ($tom = get_user_by_username(ELGG_BE_TOM_USERNAME))) { // assignment intentional
            return true;
        }

        $tomGuid = $tom->get('guid');
        if ($tomGuid == $object->guid_one || $tomGuid == $object->guid_two) {
            // due to the friends_request mod, this event handler might be called twice
            if (! $messageSent) {
                system_message(sprintf(elgg_echo('be_tom:removeFailed'), $tom->get('name')));
            }
            $messageSent = true;
            return false;
        }
    }
    return true;
}

register_elgg_event_handler('init', 'system', 'betom_init');
