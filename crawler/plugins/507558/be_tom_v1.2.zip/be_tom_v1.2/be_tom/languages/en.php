<?php

add_translation("en", array(
    /**
     * Status messages
     */
        'be_tom:removeFailed' => "Sorry, the system requires you to remain friends with %s.",
));

