<?php
	/*
	 * View to show a template foot page (spotlight)
	 * 
	 * */

	echo elgg_view('spotlight/default');
?>
<div class="contentWrapper" align="right" style="font-size:10px;">
    <?php echo elgg_echo('mycase:developed');?><a href="http://hextlearn.eu" target="_blank"><?php echo elgg_echo('mycase:community');?></a>
</div>
