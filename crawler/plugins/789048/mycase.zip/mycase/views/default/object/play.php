<?php

	/*
	* It is a view used from play.php to display the good practice information
	* 
	* */

//A practice?
if (isset($vars['entity']) and $vars['entity']->getSubtype() == 'mycase'){
	
	//Set from plugin settings Reviewer Group
	
	$page_owner = page_owner_entity();
	$group_Reviewers = get_plugin_setting('groupReviewersParam','mycase');

	//Check if the viewer user is a Reviewer Group member to show Submit Review Practice Link or Interest to Review Practice
	if(isset($vars['full']) && $vars['full'] == true && isloggedin() && ($page_owner->guid != $group_Reviewers)){
		$ts = time();
		$token = generate_action_token($ts);
		$Add = '<div class="contentWrapper"><h3 align="center"><a href="' . $vars['url'] .  'pg/mycase/' . $_SESSION['user']->username . '/copy/' . $vars['entity']->getGUID() .'&'. $val{$sep}.'__elgg_token='. $token . '&__elgg_ts='. $ts . '">' . elgg_echo('mycase:toReviewers') . '</a></h3></div>';
	}
	elseif(isset($vars['full']) && $vars['full'] == true && isloggedin() && ($page_owner->guid == $group_Reviewers)){
		$ts = time();
		$token = generate_action_token($ts);
		$Add = '<div class="contentWrapper"><h3 align="center"><a href="' . $CONFIG->wwwroot . 'action/mycase/send?username=' . $_SESSION['user']->username . '&case_id=' . $vars['entity']->getGUID() .'&' . '__elgg_ts='. $ts . '&__elgg_token='. $token . '">' . elgg_echo('mycase:toReview') . '</a></h3></div>';
	}

?>
	
<div>

<?php

	if(empty($vars['entity']->aux))	
		$practice_name = $vars['entity']->title;
	else
		$practice_name = $vars['entity']->aux;
	//Show Practice Title, Icon, Owner,Date
	echo elgg_view_title(elgg_echo($vars['entity']->title));
	echo $Add;
?>
    
	<div class="contentWrapper">
		<div class="generic_comment">
			<div class="generic_comment_icon">
<?php
	        echo elgg_view("profile/icon",array('entity' => $vars['entity']->getOwnerEntity(), 'size' => 'small'));
?>
				<div style="background:#DEDEDE;color:#0054A7;text-align:center"><h3>
		<?php echo ((!$vars['entity']->views) ? '0' : $vars['entity']->views)?></h3>
				</div>
			</div>
			<div class="generic_comment_details">
		<p>
<?php               
		if(get_language()=='es'){
			$months = array ("enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre","octubre","noviembre","diciembre");		
			$theDate = " " .  date('j') ." de ";
			$theDate .= $months[date('n',$vars['entity']->time_created)-1];
			$theDate .= " de ". date('Y'). " ";
			echo sprintf(elgg_echo("mycase:time"),$theDate);
		}
		else{
			echo sprintf(elgg_echo("mycase:time"), date("F j, Y",$vars['entity']->time_created) );
		}
?>


		
		<?php echo elgg_echo('mycase:by'); ?> <a href="<?php echo $vars['url']; ?>pg/mycase/<?php echo $vars['entity']->getOwnerEntity()->username; ?>">
		<?php echo $vars['entity']->getOwnerEntity()->name; ?></a> &nbsp; 


		<!-- display the comments link -->
<?php 
		//Comments count, Links to delete or Edi
		echo sprintf(elgg_echo('mycase:comment')) . " (" . elgg_count_comments($vars['entity']) . ")";
		if ($vars['entity']->canEdit()){
			$DeleteEdit .= '<br />';
			$DeleteEdit .= elgg_view("output/confirmlink", array(
				'href' => $vars['url'] . "action/mycase/delete?case_id=" . $vars['entity']->getGUID(),
				'text' => elgg_echo('mycase:delete'),
				'confirm' => elgg_echo('mycase:remove'),
				));
			$DeleteEdit .= '&nbsp;&nbsp;';
			$DeleteEdit .= '<a href="' . $vars['url']  . 'pg/mycase/' . $vars['entity']->getOwnerEntity()->username . '/edit/' . $vars['entity']->getGUID() . '">' . elgg_echo('mycase:edit') . '</a>';
		}
		else{
			$DeleteEdit = '<br />';
		}
		echo $DeleteEdit;
?>
<?php	//Tags for a practice
                $tags = elgg_view('output/tags', array('tags' => $vars['entity']->tags));
                if(!empty($tags))
			echo '<p class="generic_comment_owner">' . elgg_echo('mycase:tags') . ': ' . $tags . '</p>';
?>
		</p> 
			 </div>
		</div><br><br>
		<div>
	<p style="text-align:justify"><spam style="font-weight:bold">
		<?php echo elgg_echo('mycase:elements');?></spam> 

<?php
	//Show fields from form.php
	$mycase_elements = $vars['entity']->elements;
	$mycase_territory = $vars['entity']->territory;


	if (is_array($mycase_elements))
	{
		foreach($mycase_elements as $e)
		{	   
		   echo '<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
		   if ($e == 1)
			echo elgg_echo('mycase:elements:item_0') ;
		   elseif ($e == 2)
			echo elgg_echo('mycase:elements:item_1') ;
	  	   elseif ($e == 3)
			echo elgg_echo('mycase:elements:item_2') ;
		   elseif ($e == 4)
			echo elgg_echo('mycase:elements:item_3') ;
		   elseif ($e == 5)
			echo elgg_echo('mycase:elements:item_4') ;
		   elseif ($e == 6)
			echo elgg_echo('mycase:elements:item_5') ;
		}
	} else {

	   if ($mycase_elements == 1)
		echo elgg_echo('mycase:elements:item_0') ;
	   elseif ($mycase_elements == 2)
		echo elgg_echo('mycase:elements:item_1') ;
  	   elseif ($mycase_elements == 3)
		echo elgg_echo('mycase:elements:item_2') ;
	   elseif ($mycase_elements == 4)
		echo elgg_echo('mycase:elements:item_3') ;
	   elseif ($mycase_elements == 5)
		echo elgg_echo('mycase:elements:item_4') ;
	   elseif ($mycase_elements == 6)
		echo elgg_echo('mycase:elements:item_5') ;
	}

?>
</p> 
	<p style="text-align:justify"><spam style="font-weight:bold">
		<?php echo elgg_echo('mycase:territory') ;?></spam> 
<?php
	if (is_array($mycase_territory))
	{
		foreach($mycase_territory as $t)
		{
		   echo '<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
		   if ($t == 1)
			echo elgg_echo('mycase:territory:item_0') ;
		   elseif ($t == 2)
			echo elgg_echo('mycase:territory:item_1') ;
	  	   elseif ($t == 3)
			echo elgg_echo('mycase:territory:item_2') ;
		   elseif ($t == 4)
			echo elgg_echo('mycase:territory:item_3') ;
		   elseif ($t == 5)
			echo elgg_echo('mycase:territory:item_4') ;
		   elseif ($t == 6)
			echo elgg_echo('mycase:territory:item_5') ;
		   elseif ($t == 7)
			echo elgg_echo('mycase:territory:item_6') ;
		   elseif ($t == 8)
			echo elgg_echo('mycase:territory:item_7') ;
		   elseif ($t == 9)
			echo elgg_echo('mycase:territory:item_8') ;
		}
	} else {
	   if ($mycase_territory == 1)
		echo elgg_echo('mycase:territory:item_0') ;
	   elseif ($mycase_territory == 2)
		echo elgg_echo('mycase:territory:item_1') ;
  	   elseif ($mycase_territory == 3)
		echo elgg_echo('mycase:territory:item_2') ;
	   elseif ($mycase_territory == 4)
		echo elgg_echo('mycase:territory:item_3') ;
	   elseif ($mycase_territory == 5)
		echo elgg_echo('mycase:territory:item_4') ;
	   elseif ($mycase_territory == 6)
		echo elgg_echo('mycase:territory:item_5') ;
	   elseif ($mycase_territory == 7)
		echo elgg_echo('mycase:territory:item_6') ;
	   elseif ($mycase_territory == 8)
		echo elgg_echo('mycase:territory:item_7') ;
	   elseif ($mycase_territory == 9)
		echo elgg_echo('mycase:territory:item_8') ;
	}


	if(empty($vars['entity']->descript))	
		$description = $vars['entity']->description;
	else
		$description = $vars['entity']->descript;

?>


</p> 


	<p style="text-align:justify"><spam style="font-weight:bold">
		<?php echo elgg_echo('mycase:description');?></spam> <?php echo $vars['entity']->description;?></p> 
	<p style="text-align:justify"><spam style="font-weight:bold">
		<?php echo elgg_echo('mycase:institution');?></spam> <?php echo $vars['entity']->institution;?></p> 
	<p style="text-align:justify"><spam style="font-weight:bold">
		<?php echo elgg_echo('mycase:contact');?></spam> <?php echo $vars['entity']->contact;?></p> 
	<p style="text-align:justify"><spam style="font-weight:bold">
		<?php echo elgg_echo('mycase:weblink');?></spam> <?php echo $vars['entity']->weblink;?></p> 
	<p style="text-align:justify"><spam style="font-weight:bold">
		<?php echo elgg_echo('mycase:references');?></spam> <?php echo $vars['entity']->references;?></p> 
	<p style="text-align:justify"><spam style="font-weight:bold">
		<?php echo elgg_echo('mycase:filledby');?></spam> <?php echo $vars['entity']->filledby;?></p> 
		 </div>
        </div>

</div>

<?php
	/*Check if is a new view or a comment/rate
	 * 	 check the referer url
	 * */
	if($_SERVER['HTTP_REFERER'] != current_page_url()){
		//Increase viewer count(with a sql update because the visitor of a practice haven't access to other users metadata practice )
		
		$newView = $vars['entity']->views + 1;
		$valueId = add_metastring($newView);
		$row = get_data("SELECT m.id FROM " . $CONFIG->dbprefix . "metadata AS m JOIN " . $CONFIG->dbprefix . "entities e ON e.guid = m.entity_guid JOIN " . $CONFIG->dbprefix . "metastrings ms ON ms.id = m.name_id WHERE e.guid = '" . $vars['entity']->getGUID() . "' AND ms.string = 'views'");
		$mdId = $row[0]->id;
		$in = update_data("UPDATE " . $CONFIG->dbprefix . "metadata SET value_id = '" . $valueId . "' WHERE id = '" . $mdId . "'");
	
		//Create an annotation to registrate a visit to practice (the user and the moment)		
		create_annotation($vars['entity']->guid, "viewed", "1", "integer", $_SESSION['user']->username , ACCESS_PUBLIC);
	}

	echo elgg_view_comments($vars['entity']);
}
?>

<div id="caseSrc" class="contentWrapper"> 
	<?php echo elgg_view('rate/rate', array('entity'=> $vars['entity'])); ?>
	<?php //Check if the practice has been rated to show or not the possibility to change the rate if exists
			 if (isloggedin()){
				$annotations = $vars['entity']->getAnnotations('generic_rate');//Get all practice rates
				foreach ($annotations as $annotation){//Get each rate
					if ($annotation->owner_guid == $_SESSION['guid']){//Check if this is the user's rate 
						//Show link to delete the rate
						   echo elgg_view("output/confirmlink", array(
						'href' =>  $vars['url'] . "action/mycase/reRate?annotation_id=" . $annotation->id . "&practice_guid=" . $vars['entity']->guid . "&user_name=" . $vars['entity']->getOwnerEntity()->username . "&type_view=mycase",
						'text' => elgg_echo('mycase:reRate'),
						'confirm' => elgg_echo('mycase:removeRate'),
						));	
						
						break;
					}
				}
			
			}	
			 
			 
	?> 
</div>
