<?php

		/*
		 * Show by default mycase objects when functions are called. 
		 * */
	global $CONFIG;

if (isset($vars['entity'])){
		$mycase_image = $vars['entity']->imagesrc;

		//Choose view, depends on context
		if (get_context() == "search") {
			if (get_input('search_viewtype') == "gallery") {
				echo elgg_view("mycase/gallery",$vars);
			} else {
				echo elgg_view("mycase/listing",$vars);
			}
		} 
		else {
			?>
			<?php 	//Check if access (owner, admin)
					if ($vars['entity']->canEdit()){
							//Prepare links to delete or edit a practice
							$DeleteEdit .= elgg_view("output/confirmlink", array(
								'href' => $vars['url'] . "action/mycase/delete?case_id=" . $vars['entity']->getGUID(),
								'text' => elgg_echo('mycase:delete'),
								'confirm' => elgg_echo('mycase:remove'),
								));
							$DeleteEdit .= '&nbsp;&nbsp;';

						$DeleteEdit .= '<a href="' . $vars['url']  . 'pg/mycase/' . $vars['entity']->getOwnerEntity()->username . '/edit/' . $vars['entity']->getGUID() . '">' . elgg_echo('mycase:edit') . '</a>';
					}
					else{
						$DeleteEdit = '<br />';
					}

					?>
					<div class="contentWrapper">
							
							<?php
							//Show Title, Icon, date, owner and options (delete, edit)	
							$practice_name = $vars['entity']->title;
							if (empty($vars['entity']->title)){
								$practice_name = $vars['entity']->aux;
							}
							echo '<h3><a href="' . $vars['entity']->getUrl() . '" class="contentWrapper" rel="' . $mycase_image . '">' .elgg_echo($practice_name). '</a></h3>';
							?>
									
							<div class="generic_comment">
											<div class="generic_comment_icon">

												<!--img src="<?php  echo $mycase_image?>" height="40" width="40" />
												<img src="/hextlearn/mod/mycase/graphics/hextlearn.gif"/>-->

												<img src="<?php  echo $CONFIG->wwwroot . 'mod/mycase/_graphics/hextlearn.gif';?>" />

												<div style="background:#DEDEDE;color:#0054A7;text-align:center;">
													<h3><?php echo ((!$vars['entity']->views) ? '0' : $vars['entity']->views)?></h3>
												</div>

											</div>
											<div class="generic_comment_details">
												<?php
												if(get_language()=='es'){
														$months = array ("enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre","octubre","noviembre","diciembre");		
														$theDate = " " .  date('j') ." de ";
														$theDate .= $months[date('n',$vars['entity']->time_created)-1];
														$theDate .= " de ". date('Y'). " ";
														echo sprintf(elgg_echo("mycase:time"),$theDate);
												}
													else{
														echo sprintf(elgg_echo("mycase:time"), date("F j, Y",$vars['entity']->time_created) );
													}	
												?>
																
												<?php echo elgg_echo('mycase:by'); ?> <a href="<?php echo $vars['url']; ?>pg/mycase/<?php echo $vars['entity']->getOwnerEntity()->username; ?>"><?php echo $vars['entity']->getOwnerEntity()->name; ?></a> &nbsp; 

												<!-- display the comments link -->
												<a href="<?php echo $vars['entity']->getURL(); ?>"><?php echo sprintf(elgg_echo('mycase:comment')) . " (" . elgg_count_comments($vars['entity']) . ")"; ?></a>

													
												<?php echo '<p class="generic_comment_owner">' . $DeleteEdit . '</p>';?>
											</div>
											<?php //Show the possibility to rate a practice
											 echo elgg_view('rate/rate', array('entity'=> $vars['entity']));?>
														
											<?php //Check if the practice has been rated to show or not the possibility to change the rate if exists
											if (isloggedin()){
													$annotations = $vars['entity']->getAnnotations('generic_rate');//Get all practice rates
													foreach ($annotations as $annotation){//Get each rate
														if ($annotation->owner_guid == $_SESSION['guid']){//Check if this is the user's rate 
															//Show link to delete the rate
															echo elgg_view("output/confirmlink", array(
															'href' =>  $vars['url'] . "action/mycase/reRate?annotation_id=" . $annotation->id . "&practice_guid=" . $vars['entity']->guid . "&user_name=" . $vars['entity']->getOwnerEntity()->username . "&type_view=all",
															'text' => elgg_echo('mycase:reRate'),
															'confirm' => elgg_echo('mycase:removeRate'),
															));	
															echo "<BR></BR><BR>";
																	
															break;
														}
													}
														
											}									 
														 
									?>
							</div>		
					</div>
			<?php
				
		}
}
?>
