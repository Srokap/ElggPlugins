<?php

	/*
	 * View for river create entry
	 * */
	
	$item  = $vars['item'];
	
	$performed_by = get_entity($item->subject_guid); 
	$object = get_entity($item->object_guid);
	$url = $object->getURL();
	$caseTitle .= '<a href="' . $url . '">' . $object->title . '</a>';
	$url = "<a href=\"{$performed_by->getURL()}\">{$performed_by->name}</a>";
	$string .= sprintf(elgg_echo('mycase:river:titled'),$url,$caseTitle);

	echo $string;

?>
