<?php 

	/*
	 * View for display a tag cloud
	 * */
	 
	global $CONFIG;
	$area3 = null;
	//Get the site tags for mycase type objects  
    $distint_tags =get_tags(0, 50, 'tags', 'object', 'mycase', '');
    
	if($distint_tags){ 
		 $area3 .= '<div class="contentWrapper">' . elgg_view_title(elgg_echo('mycase:tagcloud')); 
	}
	else{
		$area3 .= '<div>';
	}

	//Establish a rating for the importance of labels when displaying

	foreach($distint_tags as $tag) {
		if ($tag->total > $max_val) {
				$max_val = $tag->total;
		}

	}

	//For each tag you create your link with html tags and assign it the size 		
	foreach ($distint_tags AS $tag){

		// protecting against division by zero warnings
		$size = round((log($tag->total) / log($max_val + .0001)) * 100) + 30;

		if ($size < 60) {
				$size = 60;
		}
		//Create the cloud with the tags and the links
		$all_tags[]= "<a href=\"". $CONFIG->wwwroot ."pg/mycase/sorted/casesByTag/". $tag->tag ."\" style=\"font-size:". $size ."%\" title=\"".$tag->tag. "(". $tag->total . ")"."\";". $tag->tag ."\ >".$tag->tag."</a>";		
	}
	
	$area3 .= implode(", ",$all_tags);

	$area3 .= '</div>';
		
	echo $area3;


?>
