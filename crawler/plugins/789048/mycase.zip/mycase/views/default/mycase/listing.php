<?php	

	/*
	 * Displayed when the system presents the best practices from one context to search, if the search type is so stipulated.
	 *
	 * */
		
		$thumb = $CONFIG->wwwroot . $vars['entity']->imagesrc;
		if(substr_count($vars['entity']->imagesrc,"images") == 0)
			$thumb = $CONFIG->wwwroot . "mod/mycase/thumbs.php?&id=" . $vars['entity']->getGUID();
		
		$owner = $vars['entity']->getOwnerEntity();
		$friendlytime = friendly_time($vars['entity']->time_created);
		$icon = '<img src="'.$thumb.'">';
		
		$info = elgg_echo('cases') . " : ";
		$info .= '<a href="' . $vars['entity']->getURL() . '"  class="screenshot" rel="' . $thumb . '">' . $vars['entity']->title . '</a>';
		$info .= "<br />";
		//crush--------
		$info .= "<a href=\"{$owner->getURL()}\">{$owner->name}</a> {$friendlytime}";
		echo elgg_view_listing($icon,$info);
?>
