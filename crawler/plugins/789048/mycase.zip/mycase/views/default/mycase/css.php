<?php
?>


	
.mycase_selected {
    background:#ef7d18;
}

.rms-input-radio {
  font-size: 1em;
}

#mycase_widget_layout {
-webkit-border-radius: 8px;
-moz-border-radius: 8px;
background:#FFFFFF none repeat scroll 0 0;
margin:0 0 20px;
border:1px solid #ccc;
padding:0 0 5px;
}

.mycase_shares_widget_wrapper {
	background: white;
	margin:0 10px 5px 10px;
	padding:5px;
	-webkit-border-radius: 8px;
	-moz-border-radius: 8px;
}

.shares_title {
	float: left;
	margin-right: 10px;
}

.river_object_mycase_comment{
	background:transparent url(<?php echo $CONFIG->wwwroot; ?>mod/mycase/_graphics/river_icon_comment.gif) no-repeat scroll left -1px;

}

.river_object_mycase_create{
	background:transparent url(<?php echo $CONFIG->wwwroot; ?>mod/mycase/_graphics/river_icon_mycase.gif) no-repeat scroll left -1px;
}

.customIndexIcon {
    margin:4px;
    float:left;
}

.shares_title2 {
	float: left;
	margin-right: 20px;
}


