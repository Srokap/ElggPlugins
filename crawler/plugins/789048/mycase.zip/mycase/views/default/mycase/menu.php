<?php
	/*
	 * Indicate that you use the view menu displays links to the good practices of the user
	 * */

?>
<p class="user_menu_profile">
	<a href="<?php echo $vars['url'] . 'pg/mycase/' . $vars['entity']->username;?> "><?php echo elgg_echo('cases');?></a>
</p>
