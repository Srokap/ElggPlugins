<?php

	/*
	 * View used to show group practices
	 * 
	 * */

        if($vars['entity']->mycase_enable != 'no'){
            echo '<div id="mycase_widget_layout">';
            echo '<a href="' .  $CONFIG->wwwroot . "pg/mycase/" . page_owner_entity()->username . '"><h2>' . elgg_echo('mycase:groupcases') . '</h2></a>';

            global $CONFIG;
            $num = 10;
            $shares = get_entities('object', 'mycase',page_owner(), "", $num, 0, false);

            if($shares){
					foreach($shares as $s){
						$mycase_image = $s->imagesrc;
						$owner = $s->getOwnerEntity();
						$friendlytime = friendly_time($s->time_created);
						$icon = '<img src="'.$mycase_image.'" height="40" width="40">';
									
						echo "<div class=\"forum_latest\">";
						echo "<div class=\"shares_widget_icon\">" . "</div><div>";

						$practice_name = $s->title;
						if (empty($s->title)){
							$practice_name = $s->aux;
						}

						
						?>
						<p class="shares_title"><a href="<?php echo $s->getUrl();?>" class="shares_title" rel="<?php echo $mycase_image; ?>"><?php echo substr(htmlentities($practice_name,ENT_QUOTES,'UTF-8'),0,17); ?>..</a></p>

						<p class="shares_timestamp" align="right"><small><?php echo $friendlytime; ?></small></p>

						<?php
						echo "</div><div class='clearfloat'></div>";
						echo "</div>";
					}

                $user_inbox = $vars['url'] . "pg/mycase/" . page_owner_entity()->username;
				echo '<div class="forum_latest" align="right"><a href="'.$user_inbox.'">'.elgg_echo('mycase:everyone').'</a></div>';
            }
            else{
                echo '<div class="forum_latest">' . elgg_echo('mycase:notfound') . '</div>';
            }
	
			echo '<div class="clearfloat"></div></div>';
        }
?>
