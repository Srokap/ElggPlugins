<?php

	/*
	* It is a view used from pages/classifiedByTerritories to display check boxes to select affected territories for a search
	* Start the actions showCasesByTerritories.
	* 
	* */

$pageOwner = page_owner_entity();
$mycaseTerritory = array();

$labelTerritory = elgg_echo('mycase:territory');
$checkboxesTerritory = elgg_view('input/checkboxes', array('internalname' => 'mycaseTerritory', 'class' => 'rms-input-checkboxes', 'options' => array(
			elgg_echo('mycase:territory:item_0') => 1,
			elgg_echo('mycase:territory:item_1') => 2,
			elgg_echo('mycase:territory:item_2') => 3,
			elgg_echo('mycase:territory:item_3') => 4,
			elgg_echo('mycase:territory:item_4') => 5,
			elgg_echo('mycase:territory:item_5') => 6,
			elgg_echo('mycase:territory:item_6') => 7,
			elgg_echo('mycase:territory:item_7') => 8,
			elgg_echo('mycase:territory:item_8') => 9), 'value' => $mycaseTerritory));

$submitInput = elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('mycase:viewPractices')));	

$form .= '</p>';		

$form .= '<p><center><label>' . $labelTerritory . '</label></center><br /><span class="rms-input-checkboxes">' . $checkboxesTerritory . '</span></p>';

$form .= '<p><center><label>' . $submitInput . '</label></center></p>';

$form .= '<input type="hidden" name="page_owner" value="' . $pageOwner->getGUID() . '">';

echo '<div class="contentWrapper">'. elgg_view('input/form', array('action' => "{$vars['url']}action/mycase/showCasesByTerritories", 'body' => $form, 'enctype' => 'multipart/form-data')) . '</div>';

?>
