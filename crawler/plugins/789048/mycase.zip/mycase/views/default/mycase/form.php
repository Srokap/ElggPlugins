<?php

	/*
	* It is a view used from add.php and edit.php to display text boxes and fields to introduce information about good practices
	* Start the actions add, edit and recommendTags. Includes Javascript Code.
	* 
	* */

	if(isset($vars['entity']))
	{
		$mycase_title = $vars['entity']->title;	
		$mycase_elements = $vars['entity']->elements;


		$mycase_territory = $vars['entity']->territory;
		$mycase_description = $vars['entity']->description;
		$mycase_institution = $vars['entity']->institution;
		$mycase_contact = $vars['entity']->contact;
		$mycase_weblink = $vars['entity']->weblink;
		$mycase_references = $vars['entity']->references;
		$mycase_filledby = $vars['entity']->filledby;		$mycase_tags = implode(', ',$vars['entity']->tags);
		$mycaseaccessid = $vars['entity']->access_id;
		if(empty($mycase_tags))
			$mycase_tags = $vars['entity']->tags;
		$action = 'mycase/edit';
		$input_action = 'edit';
		if(get_context() == 'mycase_copy')
		{
			$input_action = 'copy';
			$action = 'mycase/add';
	        $readonly = 'readonly'; 
		}
	}
	else
	{

		$mycase_title = '';
		$mycase_elements = array();
		$mycase_territory = array();
		$mycase_description = '';
		$mycase_institution = '';
		$mycase_contact = '';
	  	$mycase_weblink = '';
		$mycase_references = '';
		$mycase_filledby = '';
		$mycase_tags = '';
		$mycaseaccessid = 2;
		$action = 'mycase/add';
		$input_action = 'add';
	}
	
	$page_owner = page_owner_entity();
	$page_owner->getGUID();
	if($page_owner instanceof ElggGroup)
		$mycaseaccessid = 1;
			
	$label_title = elgg_echo('mycase:title');
	$title_text = elgg_view('input/text', array('internalname' => 'mycasetitle', 'js' => 'onBlur="getText(this)"','value' => $mycase_title));

	$label_elements = elgg_echo('mycase:elements');


	$checkboxes_elements = elgg_view('input/checkboxes', array('internalname' => 'mycase_elements', 'class' => 'rms-input-checkboxes', 'options' => 			array(
			elgg_echo('mycase:elements:item_0') => 1,
			elgg_echo('mycase:elements:item_1') => 2,
			elgg_echo('mycase:elements:item_2') => 3,
			elgg_echo('mycase:elements:item_3') => 4,
			elgg_echo('mycase:elements:item_4') => 5,
			elgg_echo('mycase:elements:item_5') => 6), 'value' => $mycase_elements));

	$label_territory = elgg_echo('mycase:territory');
	$checkboxes_territory = elgg_view('input/checkboxes', array('internalname' => 'mycase_territory', 'class' => 'rms-input-checkboxes', 'options' => 			array(
			elgg_echo('mycase:territory:item_0') => 1,
			elgg_echo('mycase:territory:item_1') => 2,
			elgg_echo('mycase:territory:item_2') => 3,
			elgg_echo('mycase:territory:item_3') => 4,
			elgg_echo('mycase:territory:item_4') => 5,
			elgg_echo('mycase:territory:item_5') => 6,
			elgg_echo('mycase:territory:item_6') => 7,
			elgg_echo('mycase:territory:item_7') => 8,
			elgg_echo('mycase:territory:item_8') => 9), 'value' => $mycase_territory));


	$label_description = elgg_echo('mycase:description');
	$description_text = elgg_view('input/longtext', array('internalname' => 'mycasedescription', 'value' => $mycase_description));
	$label_institution = elgg_echo('mycase:institution');
	$institution_text = elgg_view('input/text', array('internalname' => 'mycaseinstitution', 'value' => $mycase_institution));
	$label_contact = elgg_echo('mycase:contact');
	$contact_text = elgg_view('input/text', array('internalname' => 'mycasecontact', 'value' => $mycase_contact));
	$label_weblink = elgg_echo('mycase:weblink');
	$weblink_text = elgg_view('input/text', array('internalname' => 'mycaseweblink', 'value' => $mycase_weblink, 'js' => $readonly));	
	$label_references = elgg_echo('mycase:references');
	$references_text = elgg_view('input/longtext', array('internalname' => 'mycasereferences', 'value' => $mycase_references));
	$label_filledby = elgg_echo('mycase:filledby');
	$filledby_text = elgg_view('input/text', array('internalname' => 'mycasefilledby', 'value' => $mycase_filledby));

	$label_access = elgg_echo('mycase:access');
	$access_input = elgg_view('input/access', array('internalname' => 'mycaseaccessid', 'value' => $mycaseaccessid));
	$label_tags = elgg_echo('mycase:tags');
	$tags_text = elgg_view('input/tags', array('internalname' => 'mycasetags', 'js' => 'id="etiquetas"', 'value' => $mycase_tags));


	if ($input_action == 'copy')
		$submit_input = elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('mycase:button:submit')));	 
	elseif ($action == 'mycase/add')
		$submit_input = elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('mycase:getcase')));
	elseif ($action == 'mycase/edit')
		$submit_input = elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('mycase:save')));	
				
	$form .= '</p>';
		
	$form .= '<p><label>' . $label_title . '<br />' . $title_text . '</label></p>';
	$form .= '<p><label>' . $label_elements . '</label><br /><span class="rms-input-checkboxes">' . $checkboxes_elements . '</span></p>';
	$form .= '<p><label>' . $label_territory . '</label><br /><span class="rms-input-checkboxes">' . $checkboxes_territory . '</span></p>';
	$form .= '<p><label>' . $label_description . '<br />' . $description_text . '</label></p>';
	$form .= '<p><label>' . $label_institution . '<br />' . $institution_text . '</label></p>';
	$form .= '<p><label>' . $label_contact . '<br />' . $contact_text . '</label></p>';
	$form .= '<p><label>' . $label_weblink . '<br />' . $weblink_text . '</label></p>';
	$form .= '<p><label>' . $label_references . '<br />' . $references_text . '</label></p>';
	$form .= '<p><label>' . $label_filledby . '<br />' . $filledby_text . '</label></p>';
	$form .= '<p><label>' . $label_tags . '<br />' . $tags_text . '</label></p>';

	if ($input_action != 'copy')
		$form .= '<p><label>' . $label_access . '<br />' . $access_input . '</label></p>';
	else
		$form .= '<p><label>' . $label_access . '</label> By default the Reviewers Group</p>';
	$form .= $categories;
	$form .= elgg_echo('mycase:required');
	$form .= '<p><label>' . $submit_input . '</label></p>';
		
	if($action == 'mycase/edit')
	{
		$form .= '<input type="hidden" name="mycase_id" value="' . $vars['entity']->getGUID() . '">';
	}

	$form .= '<input type="hidden" name="page_owner" value="' . $page_owner->getGUID() . '"><input type="hidden" name="input_action" value="' . $input_action . '">';
	echo '<div class="contentWrapper">'. elgg_view('input/form', array('action' => "{$vars['url']}action/$action", 'body' => $form, 'enctype' => 'multipart/form-data')) . '</div>';

?>

<script language="javascript">	


function getText(texto){	
	$(document).ready(function(){
			var currentForm = $(this);
			if ($.trim($("[name='mycasetitle']").val())){
				var form_text = encodeURIComponent($("[name='mycasetitle']").val());
				var form_tags = encodeURIComponent($("[name='mycasetags']").val());
							
				$.ajaxSetup({
					  async: true
				});
				$.post("<?php $ts = time();	$token = generate_action_token($ts); echo "{$vars['url']}action/mycase/recommendTags" . '?__elgg_ts='. $ts . '&'.'__elgg_token='. $token;?>", {text:form_text}, function(data){  currentForm.find("[name='mycasetags']").val(data);});
			}
		return true;
	});

}


</script>
