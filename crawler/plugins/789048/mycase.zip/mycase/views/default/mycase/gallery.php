<?php
	/*
	 * Displayed when the system presents the best practices from one context to search, if the search type is so stipulated.
	 *
	 * */

	echo list_entities('object','mycase','',1,true,true,false);	
?>
