<?php

    global $CONFIG;
    echo autop(filter_tags($vars['value']));
?>
