<?php

	/*
	 * View to show mycase widget
	 * 
	 * */

	global $CONFIG;
	$id = $vars['entity']->selected_case;
	$vars['entity']->num_display;

	$ary = explode("/",$_GET['page']);
	if(count($ary) > 1)
	{
		$id = $ary[2];
	}

	if(!$id)
	{
		$vid = get_entities('object', 'mycase',$vars['entity']->owner_guid, "", 1, 0, false);
	}
	$cases = get_entity($id);
	if($cases){
		$owner = $cases->getOwnerEntity();
		$friendlytime = friendly_time($cases->time_created);
								
        $thumb = $CONFIG->wwwroot . 'mod/mycase/_graphics/hextlearn.gif';
        $icon = '<img src="'.$thumb.'" height="40" width="40">';
?>
	 <div class="shares_widget_wrapper">
			<div class="shares_title"><?php echo $icon?></div>
				 <div class="shares_title"><a href="<?php echo $vars['url']; ?>pg/mycase/<?php echo $owner->name . "/play/". $cases->guid;?>"><?php echo substr(htmlentities($cases->title,ENT_QUOTES,'UTF-8'),0,17); ?>..</a></div>
		<p></p><class="shares_timestamp" align="right"><small><a href="<?php $owner->getURL();?>"> <?php echo elgg_echo('mycase:by'); ?> : <?php echo $owner->name; ?></a> <?php echo "<BR>" .$friendlytime; ?></small></p>
	</div>

<?php
	}
	
	$num = $vars['entity']->num_display;
	if(!$num){
		$num = 4;
	}	
	$shares = get_entities('object', 'mycase',$vars['entity']->owner_guid, "", $num, 0, false);
	if($shares){
		foreach($shares as $s)
		{
			if($s->getGUID() != $id){
		        $thumb = $CONFIG->wwwroot.'mod/mycase/_graphics/hextlearn.gif';
	
				$owner = $s->getOwnerEntity();
				$friendlytime = friendly_time($s->time_created);
				$icon = '<img src="'.$thumb.'" height="40" width="40">';
?> 
        <div class="shares_widget_wrapper">
			<div class="shares_title"><?php echo $icon?></div>
				 <div class="shares_title"><a href="<?php echo $vars['url']; ?>pg/mycase/<?php echo $owner->name . "/play/". $s->guid;?>"><?php echo substr(htmlentities($s->title,ENT_QUOTES,'UTF-8'),0,11); ?>..</a></div>
				 

	<p class="shares_timestamp" align="right"><small><a href="<?php $owner->getURL();?>"> <?php echo elgg_echo('mycase:by'); ?> : <?php echo $owner->name; ?></a> <?php echo "<BR>" .$friendlytime; ?></small></p>
	<BR>
	</div><div class="clearfloat"></div>
        </div>
<?php					
			}
		}

		$user_inbox = $vars['url'] . "pg/mycase/" . $vars['entity']->getOwnerEntity()->username;
		echo '<div class="contentWrapper" align="right"><a href="'.$user_inbox.'">'.elgg_echo('mycase:everyone').'</a></div>';

	}
	else
	{
		echo '<div class="contentWrapper">' . elgg_echo('mycase:notfound') . '</div>';
	}
	
	
?>
