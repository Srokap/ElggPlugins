<?php

	
	/*
	 * View to config show mycase widget
	 * 
	 * */


?>
	<p>
		<?php echo elgg_echo('mycase:numbertodisplay'); ?>:
		<select name="params[num_display]">
		    <option value="1" <?php if($vars['entity']->num_display == 1) echo "SELECTED"; ?>>1</option>
		    <option value="2" <?php if($vars['entity']->num_display == 2) echo "SELECTED"; ?>>2</option>
		    <option value="3" <?php if($vars['entity']->num_display == 3) echo "SELECTED"; ?>>3</option>
		    <option value="4" <?php if($vars['entity']->num_display == 4) echo "SELECTED"; ?>>4</option>
		    <option value="5" <?php if($vars['entity']->num_display == 5) echo "SELECTED"; ?>>5</option>
		    <option value="6" <?php if($vars['entity']->num_display == 6) echo "SELECTED"; ?>>6</option>
		    <option value="7" <?php if($vars['entity']->num_display == 7) echo "SELECTED"; ?>>7</option>
		    <option value="8" <?php if($vars['entity']->num_display == 8) echo "SELECTED"; ?>>8</option>
		    <option value="9" <?php if($vars['entity']->num_display == 9) echo "SELECTED"; ?>>9</option>
		    <option value="10" <?php if($vars['entity']->num_display == 10) echo "SELECTED"; ?>>10</option>
		</select>
	</p>
	
<?php
	$total = get_entities('object', 'mycase',$vars['entity']->owner_guid, "", $num, 0, true);
	$cases = get_entities('object', 'mycase',$vars['entity']->owner_guid, "", $total, 0, false);
?>
	<p>
		<?php echo elgg_echo('mycase:chosecase'); ?>:
		<select name="params[selected_case]">
<?php
			foreach($cases as $c){
				
				echo '<option value = "' . $c->guid . '"';
				if($vars['entity']->selected_case == $c->guid){
					 echo 'SELECTED';
				}
				echo '>' . substr($c->title,0,30) . ' ...</option>';
			}
?>
		</select>
	</p>
