<?php

	/*
	 * View for plugin settings
	 * */


global $CONFIG;  
$system_url = $CONFIG->wwwroot . 'mod/mycase/pages/stats.php';
?>

<p>
<h3><a href="<?php echo $system_url; ?>"><?php echo elgg_echo('mycase:viewStats')?></a></h3>
</p>


<?php echo  "<BR>"; ?>
<h3><?php echo elgg_echo('mycase:RGroup'); ?>: </h3>
<?php
		$entities = array();
		//Get the group site
		$query = "SELECT name,guid FROM "  . $CONFIG->dbprefix .  "groups_entity ORDER BY name ASC ";
		$result = get_data($query);		
		//Get Group Guid and name
		foreach ($result AS $anGuid){
			$entities[$anGuid->guid] = $anGuid->name;
		}
		//By default admin guid (always exists)
		$groupReviewersParam = ($vars['entity']->groupReviewersParam ? $vars['entity']->groupReviewersParam : 2);
		$optionsR = array(
			'internalname' => 'params[groupReviewersParam]', 
			'value' => $groupReviewersParam,
			'options_values' => $entities
		);
		echo elgg_view('input/pulldown', $optionsR);		


		echo "<BR></BR><h3>" .elgg_echo('mycase:SCGroup') .":</h3>";
		
		//By default admin guid (always exists)
		$steeringCommitteeParam = ($vars['entity']->steeringCommitteeParam ? $vars['entity']->steeringCommitteeParam : 2);
		$myOptionsSC = array(
			'internalname' => 'params[steeringCommitteeParam]', 
			'value' => $steeringCommitteeParam,
			'options_values' => $entities
		);
		echo elgg_view('input/pulldown', $myOptionsSC);
		
		
		
		//GET Id access from reviewers group
		$query = "SELECT id FROM "  . $CONFIG->dbprefix .  "access_collections WHERE owner_guid= ". $groupReviewersParam;
		$result = get_data($query);		
		//By default private access
		$vars['entity']->accessIdReviewersParam = $result[0]->id ? $result[0]->id : ACCESS_PRIVATE;
?>




