<?php

/*
 * It is a view used in views/default/mycase/form.php to display text boxes for short fields
 * 
 * */
	
	$class = $vars['class'];
	if (!$class) $class = "input-text";
	
?>
<input type="text" <?php if ($vars['disabled']) echo ' disabled="yes" '; ?> <?php echo $vars['js']; ?> name="<?php echo $vars['internalname']; ?>" value="<?php echo htmlentities($vars['value'], null, 'UTF-8'); ?>" class="<?php echo $class ?>"/> 
