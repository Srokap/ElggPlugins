<?php

	/*
	 * Show Thumbs images for practices
	 * */
	 
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	
	$guid = get_input("id");

	$mycase = get_entity($guid);

	$filename = $mycase->imagesrc;

	header('Content-Type: image/gif');
	
	$img = imagecreatefromgif($filename);
	echo imagegif($img);
	
?>
