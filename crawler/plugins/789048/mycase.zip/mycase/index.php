<?php
	/*
	 * Show the cases of the site
	 * 
	 * */

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	$page_owner = page_owner_entity();

	if ($page_owner === false || is_null($page_owner)){
		$page_owner = $_SESSION['user'];
		set_page_owner($_SESSION['guid']);
	}

	if($page_owner == $_SESSION['user']){
		$area2 = elgg_view_title(elgg_echo('mycase:cases'));
	}
	else{
		$area2 = elgg_view_title(sprintf(elgg_echo('mycase:user'),$page_owner->name));
	}
		
	if($page_owner instanceof ElggGroup){
		$area2 = elgg_view_title(sprintf(elgg_echo('mycase:user'),$page_owner->name));
	}
	//Show cases from 10 to 10 sorted by order of creation
	$list .= list_user_objects(page_owner(),'mycase',10,false);
        
	if(empty($list) || $list == '')
        	$area2 .= '<div class="contentWrapper">' . elgg_echo('mycase:notfound') . '</div>';
        else
	        $area2 .= $list;

        global $CONFIG;
        $categories = elgg_view('categories/list', array('baseurl' => $CONFIG->wwwroot . 'search/?subtype=mycase&tagtype=universal_categories&tag=', 'owner_guid' => $page_owner->guid));
        if(!empty($categories))
        {
             $area3 .= '<div class="contentWrapper">' . $categories . '</div>';
        }		
	
    //Show Tag Cloud
	$area3 .= elgg_view('mycase/cloudTag');	

	$body = elgg_view_layout("two_column_left_sidebar", '', $area2, $area3);
	page_draw(sprintf(elgg_echo('mycase:user'),$page_owner->name),$body);
		
?>
