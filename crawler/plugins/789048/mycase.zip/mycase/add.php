<?php

	/*
	 * To create a good practice
	 * */

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	gatekeeper();

	$page_owner = page_owner_entity();

	if ($page_owner === false || is_null($page_owner)) 
	{
		$page_owner = $_SESSION['user'];
		set_page_owner($_SESSION['guid']);
	}
	//Show Form for introducing good practice information
	$area2 = elgg_view_title(elgg_echo('mycase:add'));
	$area2 .= elgg_view('mycase/form');

	global $CONFIG;
	$categories = elgg_view('categories/list', array('baseurl' => $CONFIG->wwwroot . 'search/?subtype=mycase&tagtype=universal_categories&tag=', 'owner_guid' => $page_owner->guid));
	if(!empty($categories))
	{
		$area3 .= '<div class="contentWrapper">' . $categories . '</div>';
	}
	
	//Show Tag Cloud	$area3 .= elgg_view('mycase/cloudTag');

	$body = elgg_view_layout("two_column_left_sidebar", '', $area2, $area3);
				
	page_draw(sprintf(elgg_echo('mycase:user'),$page_owner->name),$body);
		
?>
