<?php
	global $CONFIG;
	$english = array (
		
	'mycase' => "\"My Practices\" Upload",
	'cases' => "Practices",
	'mycase:submit' => "Submit this Practice to the Reviewers Group",
	'mycase:cases' => "My Practices",
	'mycase:add' => "Add a new Practice",
	'mycase:addgroup' => "Add new group Practices",
	'mycase:user' => "%s's \"My Practices\"",
	'mycase:getcase' => "Add practice",
	'mycase:button:submit' => "Submit My Practice",
	'mycase:access' => "Access",
	'mycase:tags' => "Practice's tags",
	'mycase:blank' => "Please enter the valid url",
	'mycase:blanktitle' => "Please enter the title",
	'mycase:saveerror' => "Sorry, practice can not be saved",
	'mycase:saved' => "Your practice has been saved",
	'mycase:everyone' => "All Practices",
	'mycase:time' => "Added on %s",
	'mycase:remove' => "Do you want to remove this practice?",
	'mycase:deleted' => "Practice has been deleted successfully",
	'mycase:notdeleted' => "Practice was not deleted",
	'mycase:wrongid' => "Sorry, practice is either removed or wrong practice id",
	'mycase:frnd' => "My friend's Practices",
	'mycase:userfrnd' => "%s's friends Practices",
	'mycase:all' => "All {$CONFIG->sitename} Practices",
	'mycase:river:added' => "%s added a new ",
	'mycase:river:case' => "Practice",
	'mycase:river:annotate' => " a comment on ",
	'mycase:widget' => "List of the latest Practices add by users",
	'item:object:mycase' => "Practices",
	'mycase:numbertodisplay' => "Number of Practices to be displayed.",
	'mycase:play' => "Read you chosen practice",
	'mycase:play:widget' => "This widget will show your chosen practice. One at a time",
	'mycase:chosecase' => "Choose a practice to read",
	'mycase:notfound' => "No practice has been added yet, or you don't have access to this information.",
	'mycase:error' => "Error fetching data from remote url. Either wrong url or practice not found.",
	'mycase:toReviewers' => "Submit this Practice to Reviewers Group",
	'mycase:toReview' => "Submit your interest in review this practice",
	'mycase:condition' => "* Above title, tags, description and other fields will overwrite the original information.<br>",
	'mycase:geterror' => "Can't get file from {$CONFIG->sitename}. {$CONFIG->sitename} is not responding.",
	'mycase:title' => "* Name/Title of the good practice:",
        'mycase:elements' => "Elements that potentially qualify the practice as \"good practice\":",
        'mycase:elements:item_0' => "Scale of operation",
        'mycase:elements:item_1' => "Available evaluation of results/impact",
        'mycase:elements:item_2' => "International/national reputation/visibility",
        'mycase:elements:item_3' => "Transferability (demonstrated or hypothetical)",
        'mycase:elements:item_4' => "Quality assurance in place",
        'mycase:elements:item_5' => "Degree of innovation",
        'mycase:territory' => "eLearning territory of reference:",
        'mycase:territory:item_0' => "Campus education",
        'mycase:territory:item_1' => "Corporate training",
        'mycase:territory:item_2' => "Continuous professional development",
        'mycase:territory:item_3' => "Adult education",
        'mycase:territory:item_4' => "Local and regional development",
        'mycase:territory:item_5' => "Schools teachers's training",
        'mycase:territory:item_6' => "Distance education",
        'mycase:territory:item_7' => "International virtual mobility",
        'mycase:territory:item_8' => "PLA guidance and employment",
	'mycase:description' => "Short description",
	'mycase:institution' => "Coordinating institution",
	'mycase:contact' => "Contact person",
	'mycase:weblink' => "Web link(s)",
	'mycase:references' => "Additional references",
	'mycase:filledby' => "Filled by [{$CONFIG->sitename} Partner]",
	'mycase:comment' => "Comments",
	'mycase:edit' => "Edit",
	'mycase:blank:title' => "Title can't be left blank",
	'mycase:save' => "Save",
	'mycase:missingfields' => "Required fields are missing.",
	'mycase:views' => "Total views",
	'mycase:tagcloud' => "Top Practices tags",
	'mycase:top' => "Top Practices",
	'mycase:latest' => "Latest Practices",
	'mycase:groups' => "%s's Practices",
        'mycase:group:enablecases' => "Enable Group Practices",
	'mycase:groupcases' => "Group Practices",
	'mycase:rmsUploadOption' => "Grupo de opciones:",
	'mycase:upload' => "Upload file",
	'mycase:river:titled' => '%s added a new practice titled %s',
        'mycase:latestcases' => "Latest",
        'mycase:topViewed' => "Top viewed",
        'mycase:topCommented' => "Top commented",
        'mycase:Gal' => "My Practices folder",
        'mycase:noTag' => "No Practices for this tag.",
        
        
    'mycase:stats' => "Stats",
    'mycase:viewStats' => "View Mycase Statistics",
    'mycase:statsPractices' => "Practices: ",
	'mycase:statsRates' => "Rates: ",
	'mycase:statsTotalViews' => "Total Practice Views: ",  
	'mycase:statsAverageViews' => "Average Practice Views: ",
	'mycase:statsTags' => "Tags: ",
	'mycase:statsUniqueTags' => "Unique Tags: ",
	'mycase:mostViewed' => "Most viewed Practices",
	'mycase:recentlyViewed' => "Most recently viewed Practices",
	'mycase:recentlyCommented' => "Most recently commented Practices",
	'mycase:viewAllTags' => "Tag Practice Cloud",
	'mycase:mostRated' => "Most rated Practices",
	'mycase:mostHighRated' => "Highest rating Practices",
	'mycase:classifiedByTerritories' => "Practices sorted by Territories",
	'mycase:classifiedByTerritoriesWelcome' => "Choose the territory/ies of reference from which you want to review good Practices:",
	'mycase:classifiedByTerritoriesShow' => "%s Practices",
	'mycase:viewPractices' => "View",
	'mycase:noTerritories' => "No Territories selected",
	'mycase:noTerritoriesSelect' => "Please select at least one Territory",
	'mycase:viewByFriends' => "Practices most recently seen by friends",
	'mycase:friendsCloud' => "Friend Practice Cloud",
	'mycase:caseFriend' => "%s Practices",
	'mycase:reRate' => "Change your rate",
	'mycase:removeRate' => "Do you want to change your rate?",
	'mycase:RateDeleted' => "Your Rate has been deleted successfully",
	'mycase:RateNotDeleted' => "Your Rate was not deleted",
	
	'mycase:SCGroup' => "Steering Site Committee Group",
	'mycase:RGroup' => "Reviewers Site Group",
	
		'mycase:delete' => "Delete",
	'mycase:by' => "by",
	'mycase:copyright' => "<h3><b>COPYRIGHT AND CONFIDENCIALITY</B></h3>
	<P LANG=\"en-GB\" CLASS=\"western\" ALIGN=JUSTIFY STYLE=\"margin-bottom: 0cm\">
<BR>
</P>
<P>The Sharing Practice is a <B>committing and valuable exercise</B>.
It does imply an exchange of information that involves copyright and
confidentiality aspects. Publicity will be restricted to the
community that you allow to do so, that is, confidentiality will be
set by yourself. It can be Public, Restricted to Logged in Users,
friends, groups, even private. However commenting and rating will be
restricted at least to Logged in users.</SPAN></FONT></FONT></P>

<P><FONT COLOR=\"#800000\"><FONT FACE=\"Tahoma, sans-serif\"><B>Disclaimer:</B></FONT></FONT>
This project has been funded with support from the European Commission.
This communication reflects the views only of the author, and the
Commission cannot be held responsible for any use which may be made
of the information contained therein.</P>

		<br>",
	'mycase:byReviewer' => "By default the Reviewers Group",
	'mycase:required' => "* Required Field",
	
	'mycase:messageTitle' => "Interest in Review a Case",
	'mycase:message1' => "<p>The user <span style=\"color:#ee7d1c;\">",
	'mycase:message2' => "</span> has expressed interest in review the following <a href=\"",
	'mycase:message3' => "\">Practice</a>.<br>Remember that it belongs to the Reviewer Group and you will need the right access to see it.</p>Please consider this member for further <span style=\"color:#ee7d1c;\">Virtual Peer Reviews</span>.",
	'mycase:developed' => " MyCase Plugin, originally developed for ",
	'mycase:community' => "the HEXTLEARN Community",
	
	);
	add_translation("en",$english);
?>
