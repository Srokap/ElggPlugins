<?php
	global $CONFIG;
	$spanish = array (
		
	'mycase' => "\"Mis Prácticas\" Subida",
	'cases' => "Prácticas",
	'mycase:submit' => "Enviar esta Práctica al Grupo de revisores",
	'mycase:cases' => "Mis Prácticas",
	'mycase:add' => "Añadir una nueva Práctica",
	'mycase:addgroup' => "Añadir nuevo Grupo de Prácticas",
	'mycase:user' => "Prácticas de %s",
	'mycase:getcase' => "Añadir Práctica",
	'mycase:button:submit' => "Enviar mi Práctica",
	'mycase:access' => "Acceso",
	'mycase:tags' => "Etiquetas para la Práctica",
	'mycase:blank' => "Por favor introduzca una url válida",
	'mycase:blanktitle' => "Por favor introduzca un título",
	'mycase:saveerror' => "Lo sentimos, la Práctica no puede ser almacenada",
	'mycase:saved' => "Su Práctica ha sido almacenada",
	'mycase:everyone' => "Todas las Prácticas",
	'mycase:time' => "Añadida el %s",
	'mycase:remove' => "¿Desea eliminar esta Práctica?",
	'mycase:deleted' => "La Práctica ha sido eliminada correctamente",
	'mycase:notdeleted' => "La Práctica no ha sido eliminada",
	'mycase:wrongid' => "Lo sentimos, la Práctica ha sido eliminada o su identificador es incorrecto",
	'mycase:frnd' => "Prácticas de mis amigos",
	'mycase:userfrnd' => "Prácticas de los amigos de %s ",
	'mycase:all' => "Todas las Prácticas de {$CONFIG->sitename}",
	'mycase:river:added' => "%s añadió una nueva ",
	'mycase:river:case' => "Práctica",
	'mycase:river:annotate' => " un comentario en ",
	'mycase:widget' => "Listado de las últimas Prácticas añadidas por los usuarios",
	'item:object:mycase' => "Prácticas",
	'mycase:numbertodisplay' => "Número de Prácticas a mostrar.",
	'mycase:play' => "Lee la Práctica que ha seleccionado",
	'mycase:play:widget' => "Este widget le mostrará la Práctica seleccionada. Una cada vez",
	'mycase:chosecase' => "Elija una Práctica para leer",
	'mycase:notfound' => "Todavía no se ha añadido ninguna Práctica, o no tiene acceso a esta información.",
	'mycase:error' => "Fallo al captura los datos de la Url remota. Url errónea o Práctica no encontrada.",
	'mycase:toReviewers' => "Enviar esta Práctica al Grupo de Revisores",
	'mycase:toReview' => "Manifestar interés en revisar esta Práctica",
	'mycase:condition' => "* El título, etiquetas, descripción y otros campos serán sobreescritos con la información original.<br>",
	'mycase:geterror' => "No puedo acceder al archivo solicitado de {$CONFIG->sitename}. {$CONFIG->sitename} no ofrece respuesta.",
	'mycase:title' => "* Nombre/Título de la buena Práctica:",
        'mycase:elements' => "Elementos que potencialmente caracterizan a una Práctica como una \"Buena Práctica\":",
        'mycase:elements:item_0' => "Escala de operación",
        'mycase:elements:item_1' => "Evaluación de impacto/resultados disponible",
        'mycase:elements:item_2' => "Reputación/Visibilidad nacional/internaciona",
        'mycase:elements:item_3' => "Transferibilidad (demostrada o hipotética)",
        'mycase:elements:item_4' => "Sistema integrado de control de calidad",
        'mycase:elements:item_5' => "Grado de innovación",
        'mycase:territory' => "Territorios de elearning \"afectados\":",
        'mycase:territory:item_0' => "Educación Universitaria",
        'mycase:territory:item_1' => "Formación corporativa",
        'mycase:territory:item_2' => "Desarrollo profesional continuado",
        'mycase:territory:item_3' => "Educación de adultos",
        'mycase:territory:item_4' => "Desarrollo local y regional",
        'mycase:territory:item_5' => "Formación del profesorado",
        'mycase:territory:item_6' => "Educación a distancia",
        'mycase:territory:item_7' => "Movilidad internacional (virtual)",
        'mycase:territory:item_8' => "Reconocimiento del aprendizaje previo (PLA) para la orientación y el empleo",
	'mycase:description' => "Breve descripción de la Práctica",
	'mycase:institution' => "Institución coordinadora",
	'mycase:contact' => "Persona de contacto",
	'mycase:weblink' => "Enlace a la web de la Práctica",
	'mycase:references' => "Referencias adicionales",
	'mycase:filledby' => "Cumplimentada por [Miembro de {$CONFIG->sitename}]",
	'mycase:comment' => "Comentarios",
	'mycase:edit' => "Editar",
	'mycase:blank:title' => "El título no se puede dejar en blanco",
	'mycase:save' => "Guardar",
	'mycase:missingfields' => "Faltan campos requeridos.",
	'mycase:views' => "Número total de vistas",
	'mycase:tagcloud' => "Etiquetas para Prácticas más utilizadas",
	'mycase:top' => "Prácticas Top",
	'mycase:latest' => "Últimas Prácticas publicadas",
	'mycase:groups' => "Prácticas de %s",
        'mycase:group:enablecases' => "Habilitar las Prácticas para el Grupo",
	'mycase:groupcases' => "Prácticas del Grupo",
	'mycase:rmsUploadOption' => "Grupo de opciones:",
	'mycase:upload' => "Subir un archivo",
	'mycase:river:titled' => '%s añadió una nueva Práctica titulada %s',
        'mycase:latestcases' => "Las últimas",
        'mycase:topViewed' => "Las más vistas",
        'mycase:topCommented' => "Las más comentadas",
        'mycase:Gal' => "Directorio de \"Mis Prácticas\"",
        'mycase:noTag' => "No hay ninguna Práctica para esta etiqueta.",
        
        
    'mycase:stats' => "Estadísticas",
    'mycase:viewStats' => "Ver estadísticas de Mycase",
    'mycase:statsPractices' => "Prácticas: ",
	'mycase:statsRates' => "Valoraciones: ",
	'mycase:statsTotalViews' => "Número de visitas a Prácticas: ",  
	'mycase:statsAverageViews' => "Media de visitas por Práctica: ",
	'mycase:statsTags' => "Etiquetas: ",
	'mycase:statsUniqueTags' => "Etiquetas únicas: ",
	'mycase:mostViewed' => "Prácticas más vistas",
	'mycase:recentlyViewed' => "Prácticas recientemente vistas",
	'mycase:recentlyCommented' => "Prácticas recientemente comentadas",
	'mycase:viewAllTags' => "Nube de etiquetas de Prácticas",
	'mycase:mostRated' => "Prácticas con más valoraciones",
	'mycase:mostHighRated' => "Prácticas mejor valoradas",
	'mycase:classifiedByTerritories' => "Prácticas clasificadas por territorios",
	'mycase:classifiedByTerritoriesWelcome' => "Elige el territorio/s de referencia que se ve/n afectado/s en las buenas Prácticas:",
	'mycase:classifiedByTerritoriesShow' => "Prácticas de %s",
	'mycase:viewPractices' => "Ver",
	'mycase:noTerritories' => "No hay sido seleccionado ningún territorio",
	'mycase:noTerritoriesSelect' => "Por favor, selecciona al menos un territorio",
	'mycase:viewByFriends' => "Prácticas recientemente vistas por amigos",
	'mycase:friendsCloud' => "Nube de amigos con Prácticas",
	'mycase:caseFriend' => "Prácticas de %s",
	'mycase:reRate' => "Cambiar su valoración",
	'mycase:removeRate' => "¿Desea eliminar su valoración?",
	'mycase:RateDeleted' => "Su valoración ha sido eliminada",
	'mycase:RateNotDeleted' => "Su valoración no ha sido eliminada",
	
	'mycase:SCGroup' => "Grupo del Comité Directivo",
	'mycase:RGroup' => "Grupo de Revisores",
	
	'mycase:delete' => "Eliminar",
	'mycase:by' => "por",
	'mycase:copyright' => "<h3><b>DERECHOS DE AUTOR Y CONFIDENCIALIDAD</B></h3>
	<P LANG=\"en-GB\" CLASS=\"western\" ALIGN=JUSTIFY STYLE=\"margin-bottom: 0cm\">
<BR>
</P>
<P>El compartir una práctica es un <B>ejercicio comprometido y valioso</B>.
Implica un intercambio de información que conlleva aspectos relativos al derecho de autor
y la confidencialidad. La publicación se limitará al ámbito de la comunidad en la forma que establezca el propio autor. 
Podrá ser pública, restringida a usuarios registrados, amigos, grupos o incluso privada.
Sin embargo, los comentarios y valoraciones estarán restringidos al menos para usuarios registrados.</SPAN></FONT></FONT></P>

<P><FONT COLOR=\"#800000\"><FONT FACE=\"Tahoma, sans-serif\"><B>Descargo de responsabilidad:</B></FONT></FONT>
Este proyecto ha sido financiado con el apoyo de la Comisión Europea.
Esta publicación es responsabilidad exculsiva de su autor, y la Comisión no se hace responsable del uso que pueda hacerse
de la información contenida en él.</P>

		<br>",
	
	'mycase:byReviewer' => "Por defecto, el Grupo de Revisores",
	'mycase:required' => "* Campo Obligatorio",
	
	'mycase:messageTitle' => "Interés en la revisión de un caso",
	'mycase:message1' => "<p>El usuario <span style=\"color:#ee7d1c;\">",
	'mycase:message2' => "</span> ha expresado su interés en revisar la siguiente <a href=\"",
	'mycase:message3' => "\">Práctica</a>.<br> Recuerde que la Práctica pertenece al Grupo de Revisores y necesitará tener acceso para poder verla.</p>Por favor, tenga en cuenta a este miembro para futuras <span style=\"color:#ee7d1c;\">Virtual Peer Reviews</span>.",
	'mycase:developed' => " Módulo MyCase, originalmente desarrollado para ",
	'mycase:community' => "la Comunidad HEXTLEARN",

	
	);
	add_translation("es",$spanish);
?>
