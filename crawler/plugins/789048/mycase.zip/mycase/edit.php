<?php

	/*
	 * To edit an existing good practice
	 * 
	 * */
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	gatekeeper();
		
	$page_owner = page_owner_entity();
		
	if ($page_owner === false || is_null($page_owner)) 
	{
		$page_owner = $_SESSION['user'];
		set_page_owner($_SESSION['guid']);
	}
	//The practice id is fetched to get entity for editing
	$id = (int)get_input('id');
	$case = get_entity($id);
		
	if(!$case){
		forward('pg/dashboard');
	}
		
	if($page_owner == $_SESSION['user']){
		$area2 = elgg_view_title(elgg_echo('mycase:cases'));
	}
	else{
		$area2 = elgg_view_title(sprintf(elgg_echo('mycase:groups'), $page_owner->name));
	}
	
	//Call to mycase/form with with the practice guid		
	$area2 .= elgg_view('mycase/form',array('entity' => $case));
        
	global $CONFIG;
	$categories = elgg_view('categories/list', array('baseurl' => $CONFIG->wwwroot . 'search/?subtype=mycase&tagtyif(pe=universal_categories&tag=', 'owner_guid' => $page_owner->guid));
	if(!empty($categories)){
		$area3 .= '<div class="contentWrapper">' . $categories . '</div>';
	}
	
	
	//Show Tag Cloud
	$area3 .= elgg_view('mycase/cloudTag');	

	$body = elgg_view_layout("two_column_left_sidebar", '', $area2, $area3);	
			
	page_draw(sprintf(elgg_echo('mycase:user'),$page_owner->name),$body);
		
?>
