<?php

	/*
	 * To show practice info
	 * */

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	//Fetch as parameter practice id
	$case = (int) get_input('mycase_instance');
	//Check if exist a practice with the fetched id 
	if ($mycase_instance = get_entity($case)) {
		$title = $mycase_instance->title;
		$comments = $mycase_instance->getAnnotations('comments');
		set_page_owner($mycase_instance->getOwner());
		$page_owner = get_entity($mycase_instance->getOwner());

		//Call View to show practice info
		$area2 = elgg_view("object/play",array(
				'entity' => $mycase_instance,
				'entity_owner' => $page_owner,
				'comments' => $comments,
				'full' => true
		));


		// Category printing
		global $CONFIG;
		$categories = elgg_view('categories/list', array('baseurl' => $CONFIG->wwwroot . 'search/?subtype=mycase&tagtype=universal_categories&tag=', 'owner_guid' => $page_owner->guid));
		if(!empty($categories)){
			$area3 .= '<div class="contentWrapper">' . $categories . '</div>';
		}
		
		//Show Tag Cloud
		$area3 .= elgg_view('mycase/cloudTag');
	
		
		$body = elgg_view_layout("two_column_left_sidebar", '', $area2, $area3);
					
	} 
	else {
		forward($CONFIG->wwwroot . 'pg/mycase/' . $_SESSION['username']);
	}
		
	page_draw($title,$body);		
?>
