<?php

	/*
	* Action to delete a good practice, call from delete.php
	* */
	
	gatekeeper();
	action_gatekeeper();
	//Fetch as parameter practice id
	$guid = (int) get_input('case_id');
	$mycase = get_entity($guid);
	//If the user has access, delete the practice
	if ($mycase->getSubtype() == "mycase" && $mycase->canEdit()){
		$owner = get_entity($mycase->getOwner());
		$owner_guid = $owner->getGUID();
		$imagesrc = $mycase->imagesrc;
  
  
		if ($mycase->delete()){
			
		  	system_message(elgg_echo("mycase:deleted"));
		} 
		else{
			register_error(elgg_echo("mycase:notdeleted"));
		}
		forward("pg/mycase/");
	}
?>
