
<?php

	/*
	* Action to send a message to Steering Committee to report interest in reviewing a practice, call from views/default/object/play.php
	* */
	
	 // Make sure we're logged in (send us to the front page if not)
	if (!isloggedin()) forward();

	// Get input data
	$user = get_input("username");
	$case_id = (int) get_input("case_id");
	$case_title = 'My Practice ' . $case_id->title;//Initializing
	
	//Fetch params Readed from plugin settings, reviewer and steering committee Groups
	$send_to_SC_group = get_plugin_setting('steeringCommitteeParam','mycase') ; 
	$group_R = get_plugin_setting('groupReviewersParam','mycase'); 
	$case_url = $CONFIG->wwwroot . 'pg/mycase/group:' . $group_R . '/play/' . $case_id ;


	$reply = get_input('reply',0); // this is the guid of the message replying to
		
	// Cache to the session to make form sticky
	$_SESSION['msg_to_group'] = $send_to_SC_group; 
	$_SESSION['msg_title'] = $title;
	$_SESSION['msg_contents'] = $message_contents;


        $group = get_group_members($send_to_SC_group, 9999, 0, 0 , false); 

	// 'send' the message
    foreach ($group as $member){
			
        	if ($member->guid != $_SESSION['user']->getGUID()){
				
				//Send the message in the preferred language by each member
				$title = elgg_echo('mycase:messageTitle',$member->language); // message title
				$message_contents = elgg_echo('mycase:message1',$member->language) . $user . elgg_echo('mycase:message2',$member->language) . $case_url . elgg_echo('mycase:message3',$member->language) ; // the message
					
				$result += messages_send($title,$message_contents,$member->guid,0,$reply);
			}
    }			
			
	// Save 'send' the message
	if (!$result) {
		register_error(elgg_echo("messages:error"));
		forward($CONFIG->wwwroot . 'pg/groups/'.$group_R .'/');
	}



	// successful so uncache form values
	unset($_SESSION['msg_to_group']);
	unset($_SESSION['msg_title']);
	unset($_SESSION['msg_contents']);
			
	// Success message
	system_message(elgg_echo("messages:posted"));
	

	// Forward to the reviewer group
	forward($CONFIG->wwwroot . 'pg/groups/'.$group_R .'/');

?>
