<?php

	/*
	* Action to show good practices in function of affected territories, call from views/default/mycase/formTerritories.php
	* */

	gatekeeper();
	action_gatekeeper();
	
	//Fetch as parameter a string with affected territories
	$territory = get_input("mycaseTerritory");
	
	
	if(empty($territory)){
		
			register_error(elgg_echo('mycase:noTerritoriesSelect'));
			forward("pg/mycase/sorted/classifiedByTerritories");
			exit;
	}
	else{
		//Generate a string with the selected territories in form and is sending to showClassifiedByTerritories to display goog practices 
		forward('pg/mycase/sorted/showClassifiedByTerritories/'.implode("-",$territory));
	}
?>
