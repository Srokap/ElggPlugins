<?php

	/*
	* Action to add a good practice, call from add.php or copy.php 
	* */

	gatekeeper();
	action_gatekeeper();
	//Fetch params from plugin settings 
	$group_Reviewers = get_plugin_setting('groupReviewersParam','mycase');
	$access_id_Reviewers = get_plugin_setting('accessIdReviewersParam','mycase') ; 

	//Fetch params from a existing practice (copy)
	$accessid = get_input("mycaseaccessid");
	$title = get_input("mycasetitle");
	$description = get_input("mycasedescription");
	$elements = (array) get_input("mycase_elements");
	$territory = (array) get_input("mycase_territory");
	$institution = get_input("mycaseinstitution");
	$contact = get_input("mycasecontact");
	$weblink = get_input("mycaseweblink");
	$references = get_input("mycasereferences");
	$filledby = get_input("mycasefilledby");

	$tags = get_input("mycasetags");

	$input_action = get_input("input_action");
	//Choose between add or copy from input_action fetched
	if ($input_action == 'add'){
		$owner = $_SESSION['user']->getGUID();
		$page_owner = get_entity($owner);
	}

	if ($input_action == 'copy'){
		$page_owner->guid = $group_Reviewers;
		$owner = $group_Reviewers;
		$accessid = $access_id_Reviewers;
	}
	//Create Elgg Object and start to assign metadata
	$mycase = new ElggObject();
	$mycase->subtype = "mycase";
	$mycase->owner_guid = $owner;
	$mycase->container_guid = $owner;
	$mycase->access_id = $accessid;

	
	if ($input_action == 'add')
	{
		if(empty($title)){//Title is mandatory
			register_error(elgg_echo('mycase:blanktitle'));
			forward("pg/mycase/" . $page_owner->username . "/add");
			exit;
		}

		$mycase->title = $title;
		$mycase->description = $description;
		$mycase->elements = $elements;
		$mycase->territory = $territory;
		$mycase->institution = $institution;
		$mycase->contact = $contact;
		$mycase->weblink = $weblink;
		$mycase->references = $references;
		$mycase->filledby = $filledby;
		$mycase->views = 0;
		$mycase->imagesrc =  $CONFIG->wwwroot . 'mod/mycase/_graphics/hextlearn.gif';			
		$mycase->aux = $title;
		$mycase->descript = $description;
	
	}
	elseif ($input_action == 'copy'){
		$mycase->title = $title;
		$mycase->description = $description;
		$mycase->elements = $elements;
		$mycase->territory = $territory;
		$mycase->institution = $institution;
		$mycase->contact = $contact;
		$mycase->weblink = $weblink;
		$mycase->references = $references;
		$mycase->filledby = $filledby;
		$mycase->views = 0;
		$mycase->imagesrc =  $CONFIG->wwwroot . 'mod/mycase/_graphics/hextlearn.gif';
		$mycase->aux = $title;
		$mycase->descript = $description;

	}
	//Title is mandatory
	if(empty($mycase->title)){
		register_error(elgg_echo('mycase:missingfields'));
		forward($_SERVER['HTTP_REFERER']);
		exit;
	}
	//Check tag array
	if(isset($tags) and !empty($tags)){
		$tagsarray = string_to_tag_array($tags);
	}

	if(is_array($tagsarray)){
		$mycase->tags = $tagsarray;
	}
	//Save the practice
	if ($input_action == 'add'){
		if(!$mycase->save()){			register_error(elgg_echo('mycase:saveerror'));
			forward("pg/mycase/" . $page_owner->username);
			exit;
		}
		//Add to River
	    add_to_river('river/object/mycase/create', 'create', $_SESSION['user']->guid, $mycase->guid);

		system_message(elgg_echo('mycase:saved'));
		forward($mycase->getUrl());
	}		
	else{
		
		//Set owner and user access in order to save the good practice
		$mycase->owner_guid =  $_SESSION['user']->getGUID();
		$mycase->container_guid =  $_SESSION['user']->getGUID();
		$mycase->access_id = ACCESS_PUBLIC;

		$guidMycase = $mycase->save();
		if(!$guidMycase){
			register_error(elgg_echo('mycase:saveerror'));
			forward("pg/mycase/" . $page_owner->username);
			exit;
		}
		//Insert the right values for owner and access ​​in the database  
		$time = time();
		$ret=update_data("UPDATE {$CONFIG->dbprefix}entities set owner_guid='{$owner}', access_id='{$accessid}', container_guid='{$owner}', time_updated='{$time}' WHERE guid={$guidMycase}");
		system_message(elgg_echo('mycase:saved'));
		forward('pg/mycase');
	}
?>


