<?php

	/*
	* Action to edit a good practice, call from edit.php
	* */

	gatekeeper();
	action_gatekeeper();
	
	//Fetch params from a existing practice 
	$guid = (int) get_input('mycase_id');
	$accessid = get_input("mycaseaccessid");
	$title = get_input("mycasetitle");
	$description = get_input("mycasedescription");
	$elements = (array) get_input("mycase_elements");
	$territory = (array) get_input("mycase_territory");
	$institution = get_input("mycaseinstitution");
	$contact = get_input("mycasecontact");
	$weblink = get_input("mycaseweblink");
	$references = get_input("mycasereferences");
	$filledby = get_input("mycasefilledby");
	$tags = get_input("mycasetags");



	//Check tag array
	if(isset($tags) and !empty($tags)){
		$tagsarray = string_to_tag_array($tags);
	}
	else{
		$tagsarray = "";
	}
	//Title is mandatory
	if(empty($title)){
		register_error(elgg_echo('mycase:blank:title'));
		forward("pg/mycase/" . $_SESSION['user']->username . "/edit/" . $guid);
	}

	$mycase = get_entity($guid);
	//If the user has access, edit the practice
	if($mycase->getSubtype() == 'mycase' && $mycase->canEdit()){
		$mycase->title = $title;
		$mycase->description = $description;
		$mycase->elements = $elements;
		$mycase->territory = $territory;
		$mycase->institution = $institution;
		$mycase->contact = $contact;
		$mycase->weblink = $weblink;
		$mycase->references = $references;
		$mycase->filledby = $filledby;
		$mycase->access_id = $accessid;
		$mycase->tags = $tagsarray;
		$mycase->aux = $title;
		$mycase->descript = $description;

		if(!$mycase->save()){
			
			register_error(elgg_echo('mycase:saveerror'));
			forward($_SERVER['HTTP_REFERER']);
		}
		else{
			
			system_message(elgg_echo('mycase:saved'));
			forward($mycase->getUrl());			
		}
	}
	else
	{
		forward('pg/dashboard');	
	}
?>
