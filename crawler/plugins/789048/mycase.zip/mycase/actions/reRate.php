<?php

	/*
	* Action to delete a good practice rate, call from views/default/object/mycase.php or views/default/object/play.php
	* */
	
	gatekeeper();
	action_gatekeeper();
	 
	 

	//The annotation id, username, practice guid and the referer page are fetched from views/default/object/mycase.php or views/default/object/play.php
	$id =(int) get_input('annotation_id');
	$username = get_input('user_name');
	$practiceGuid = (int) get_input('practice_guid');	
	$typeView = get_input('type_view');
	
	
	//Check if the request to remove rate comes from views/default/object/mycase.php or views/default/object/play.php to show back the referere page when rate had been deleted
	if($typeView == 'all'){//objects/mycase

		if (delete_annotation($id) 	) {
			system_message(elgg_echo("mycase:RateDeleted"));
			forward("pg/mycase/");			
		} 
		else{
			register_error(elgg_echo("mycase:RateNoDeleted"));
		}
	}
	else{//objects/play
		if (delete_annotation($id) 	) {
		system_message(elgg_echo("mycase:RateDeleted"));
		forward("pg/mycase/". $username . "/play/" . $practiceGuid );	
		}
		else{
		register_error(elgg_echo("mycase:RateNoDeleted"));
		}
		
	}
	
		

?>
