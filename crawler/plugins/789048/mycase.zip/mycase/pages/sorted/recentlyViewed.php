<?php

	/*
	* Page to show the most recently viewed practices, call from menu
	* */

	global $CONFIG;
	gatekeeper();
	require_once(dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "/engine/start.php");
	
	$entities = array();
	$anArray = array ('views' => NULL);
	$limit = 150; //only display the first 150 entries, with such sufficient
	$showed = 10; //number of practices to display per page	
	
	
	//Get mycase guid entities with a view
	$query = "SELECT distinct ent.guid, ann1.time_created
			FROM " . $CONFIG->dbprefix . "entities ent
			INNER JOIN " . $CONFIG->dbprefix . "entity_subtypes sub ON ent.subtype = sub.id
			AND sub.subtype = 'mycase'
			INNER JOIN " . $CONFIG->dbprefix . "annotations ann1 ON ann1.entity_guid = ent.guid
			INNER JOIN " . $CONFIG->dbprefix . "metastrings ms ON ms.id = ann1.name_id
			AND ms.string = 'viewed'
			ORDER BY ann1.id DESC
			LIMIT $limit";


	$result = get_data($query);
	
		
	//For each subtype myCASE entity, get it
	foreach ($result as $entity) {
		if (!$entities[$entity->guid]) {
			$entities[$entity->guid] = get_entity($entity->guid);
		}
		if (count($entities) >= $showed) {
			break;
	}
}
	

	$page_owner = page_owner_entity();
		
	if ($page_owner === false || is_null($page_owner)) {
		$page_owner = $_SESSION['user'];
		set_page_owner($_SESSION['guid']);
	}

	$area2 = elgg_view_title(elgg_echo('mycase:recentlyViewed'));	
	//Ready to show the 10 most recently viewed practices	
	$area2 .= elgg_view_entity_list($entities, count($entities), 0, 10, FALSE, TRUE, FALSE);	

      
	set_context('search');
		
	global $CONFIG;
	$categories = elgg_view('categories/list', array('baseurl' => $CONFIG->wwwroot . 'search/?subtype=mycase&tagtype=universal_categories&tag=', 'owner_guid' => $page_owner->guid));
	if(!empty($categories))
	{
		$area3 .= '<div class="contentWrapper">' . $categories . '</div>';
	}
		
    //Show Tag Cloud
	$area3 .= elgg_view('mycase/cloudTag');
	
	$body = elgg_view_layout("two_column_left_sidebar", '', $area2, $area3);		
	set_context('mycase');
	page_draw(elgg_echo('mycase:recentlyViewed'),$body);
		
?>
