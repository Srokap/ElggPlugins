<?php

	/*
	* Page to show territories availables to select them, call from the menu
	* */

	global $CONFIG;
	gatekeeper();
	
	require_once(dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "/engine/start.php");
	
	//The offset is fetched to page through the results, if none set to 0
	if(isset($_GET['offset'])){
		$offset=$_GET['offset'];
	}
	else{
		$offset=0;
	}

	$entities = array();
	$entitiesPag = array();
	$showed = 10; //number of practices to display per page
	$texto = "";
	$territories = array();

	// Territories String is fetched being printed and stored as array elements
	$inputTerritories = get_input('territories');
	$territories = (array) explode("-", $inputTerritories);
	
	
	//Get mycase guid entities with a view sorted by count of views
	$query = "SELECT e.guid FROM " . $CONFIG->dbprefix . "metadata AS m JOIN " . $CONFIG->dbprefix . "entities e ON e.guid = m.entity_guid  JOIN " . $CONFIG->dbprefix . "entity_subtypes st ON e.subtype=st.id AND st.subtype='mycase' JOIN " . $CONFIG->dbprefix . "metastrings ms ON ms.id = m.name_id WHERE ms.string = 'views'  ORDER BY e.time_created  DESC";
	$result = get_data($query);
	
	
	//For each subtype entity myCASE, get their territories and add if necessary
	foreach ($result AS $anGuid){
		$entidad = get_entity($anGuid->guid);
		//Entity territories
		$territoriesEntity = (array) $entidad->territory;
		
		//If the intersection between the territories of the wanted and one entity is not empty (the entity is related to one of the searched territories) is added
		if(count(array_intersect($territories,$territoriesEntity))>0){
			$entities[] = get_entity($anGuid->guid);
		}
	}
		
	//Prepare the result to page through	
	$entitiesPag=array_slice($entities, $offset, $offset+$showed);
	

	$page_owner = page_owner_entity();
		
	if ($page_owner === false || is_null($page_owner)) {
		$page_owner = $_SESSION['user'];
		set_page_owner($_SESSION['guid']);
	}
	
	//Set page titles based on which selected areas are 
	if( !empty($territories) ){//If there are territories
		
	for($i = 0; $i < count($territories)-1; $i++){
		$texto .= elgg_echo('mycase:territory:item_'. ((int)$territories[$i]-1)). " & ";		
	}
	
	$texto .= elgg_echo('mycase:territory:item_'. ((int)$territories[count($territories)-1]-1));
	
	}
	else{
		$texto .= elgg_echo('mycase:noTerritories');	
		
	}
	
	if($texto!=elgg_echo('mycase:noTerritories')){
		$area2 = elgg_view_title(sprintf(elgg_echo('mycase:classifiedByTerritoriesShow'),$texto));	
	}
	else{
		$area2 = elgg_view_title(texto);
	}	
	//Ready to show the practices affected by the selected territories commented practices
	$area2 .= elgg_view_entity_list($entitiesPag, count($entities), $offset, $showed, FALSE, TRUE, TRUE);

	      
	set_context('search');
		
	global $CONFIG;
	$categories = elgg_view('categories/list', array('baseurl' => $CONFIG->wwwroot . 'search/?subtype=mycase&tagtype=universal_categories&tag=', 'owner_guid' => $page_owner->guid));
	if(!empty($categories))
	{
		$area3 .= '<div class="contentWrapper">' . $categories . '</div>';
	}
		
    //Show Tag Cloud
	$area3 .= elgg_view('mycase/cloudTag');	

	$body = elgg_view_layout("two_column_left_sidebar", '', $area2, $area3);		
	set_context('mycase');
	page_draw($texto ,$body);
		
?>
