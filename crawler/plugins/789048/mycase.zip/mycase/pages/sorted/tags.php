<?php

	/*
	* Page to show a tag cloud, call from menu
	* */

	global $CONFIG;
	gatekeeper();
	require_once(dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "/engine/start.php");
	

	$distintTags = array();
	$valorMax=0;
	$valorMin=0;
	$maxInt32bits = 2147483647-1;	

	//Get tags from practices
	$distintTags = get_tags(0, $maxInt32bits, 'tags', 'object', 'mycase', '');
	
	// Compare Function
	function cmp($a, $b) {
		
		return strnatcasecmp($a->tag,$b->tag) ;
	}
	uasort($distintTags, 'cmp');//alphabetically sorted
	
	if(isset($distintTags[0])){
		$valorMax = $distintTags[0]->total;
		$valorMin = $distintTags[0]->total;		
	}

	//Set a importance value to display tags	
	foreach($distintTags as $tag) {
		if ($tag->total > $valorMax) {
			$valorMax = $tag->total;
		}
		if ($tag->total < $valorMin) {
			$valorMin = $tag->total;
		}
	}
	
	
	$diferencia = $valorMax - $valorMin;
	if($diferencia == 0){
		
		$valorMin = 0;
		$diferencia = 1;
		
	}
	
	
	//For each tag you create a link with html tags and assign it the size you will look	
	foreach ($distintTags AS $tag){
		$valorRelativo = round((($tag->total - $valorMin) / $diferencia) * 10);//tamaño en funcion de la valoracion
		$allTags[]= "<a href=\" " . $CONFIG->wwwroot ."pg/mycase/sorted/casesByTag/". $tag->tag ."\" style=\"font-size:". (130+15*$valorRelativo) ."%\" title=\"".$tag->tag. "(". $tag->total . ")"."\";". $tag->tag ."\ >".$tag->tag."</a> ";
		
	}
	
	

	$page_owner = page_owner_entity();
		
	if ($page_owner === false || is_null($page_owner)) {
		$page_owner = $_SESSION['user'];
		set_page_owner($_SESSION['guid']);
	}
	
	$area2 = elgg_view_title(elgg_echo('mycase:viewAllTags'));
	//Ready to show Tags cloud	
	$area2 .= implode(", ",$allTags); 
	
	$allTags = array();
      
	set_context('search');
		
	global $CONFIG;
	$categories = elgg_view('categories/list', array('baseurl' => $CONFIG->wwwroot . 'search/?subtype=mycase&tagtype=universal_categories&tag=', 'owner_guid' => $page_owner->guid));
	if(!empty($categories))
	{
		$area3 .= '<div class="contentWrapper">' . $categories . '</div>';
	}
		
	//Show Tag Cloud
	$area3 .= elgg_view('mycase/cloudTag');
	
	$body = elgg_view_layout("two_column_left_sidebar", '', $area2, $area3);		
	set_context('mycase');
	page_draw(elgg_echo('mycase:viewAllTags'),$body);
		
?>
