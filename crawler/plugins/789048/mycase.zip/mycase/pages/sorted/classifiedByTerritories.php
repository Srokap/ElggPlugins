<?php

	/*
	* Page to show affected available territories for a good practice, call from menu
	* */
	
	require_once(dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "/engine/start.php");
	gatekeeper();	

	$page_owner = page_owner_entity();
		
	if ($page_owner === false || is_null($page_owner)) {
		$page_owner = $_SESSION['user'];
		set_page_owner($_SESSION['guid']);
	}
	
	$area2 = elgg_view_title(elgg_echo('mycase:classifiedByTerritoriesWelcome'));
	
	//Call formTerritoriesView
	$area2 .= elgg_view('mycase/formTerritories');
		
	global $CONFIG;
	$categories = elgg_view('categories/list', array('baseurl' => $CONFIG->wwwroot . 'search/?subtype=mycase&tagtype=universal_categories&tag=', 'owner_guid' => $page_owner->guid));
	if(!empty($categories))
	{
		$area3 .= '<div class="contentWrapper">' . $categories . '</div>';
	}
	
	//Show Tag Cloud
	$area3 .= elgg_view('mycase/cloudTag');

	$body = elgg_view_layout("two_column_left_sidebar", '', $area2, $area3);		
	page_draw(elgg_echo('mycase:classifiedByTerritories'),$body);
		
?>
