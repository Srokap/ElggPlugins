<?php

	/*
	* Page to show a friend with practices cloud, call from menu
	* */

	global $CONFIG;
	gatekeeper();
	require_once(dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "/engine/start.php");
	
	$maxInt32bits = 2147483647-1;
	$showed = 10; //number of practices to display per page		
	$entities = array();	
	$entitiesPag = array();
	$friendsOfMe = array();
	$friendsWithCases = array();
	$friendsWithCasesG = array();
	$friendsWithCasesN = array();	
	$allFriends = array();
	$valorMax=0;
	$valorMin=0;

	
	$page_owner = page_owner_entity();	
	if ($page_owner === false || is_null($page_owner)) 
	{
		$page_owner = $_SESSION['user'];
		set_page_owner($_SESSION['guid']);
	}

	
	//Get the people (friend_of)
	$friendsOfMe = get_user_friends_of( $page_owner->getGUID());
	//For every friend you check if he has practices
	foreach($friendsOfMe AS $friend){	
		if(get_user_objects($friend->guid, 'mycase', $maxInt32bits,0)){//Yes-> Save name and guid
			$nCasos = count(get_user_objects($friend->guid, 'mycase', $maxInt32bits,0));			
			$friendsWithCases[$friend->guid]=$friend->username;//Yes-> Save name and count practtices			
			$friendsWithCasesG[$friend->username]=$friend->guid;//Yes-> Save name and count practtices		
			$friendsWithCasesN[$friend->username]=$nCasos;
			
		}	
	}
	
	natcasesort($friendsWithCases);//Is alphabetically sorted
	
	//Set a importance value to display tags
	$valorMax = max($friendsWithCasesN);	
	$valorMin = min($friendsWithCasesN);
	$diferencia = $valorMax - $valorMin;	


	//For each tag you create a link with html tags and assign it the size you will look	
	foreach ($friendsWithCases AS $friend){


		$valorRelativo = round((($friendsWithCasesN[$friend] - $valorMin) / $diferencia) * 10);//size as a function of the valuation
		$allFriends[]= "<a href=\" " . $CONFIG->wwwroot ."pg/mycase/sorted/casesByFriend/". $friendsWithCasesG[$friend] ."\" style=\"font-size:". (110+15*$valorRelativo) ."%\" title=\"".$friend. "(". $friendsWithCasesN[$friend] . ")"."\";". $friend."\ >".$friend."</a> ";
		
	}
				

	//Ready to show Friend with practices cloud
	$area2 = elgg_view_title(elgg_echo('mycase:friendsCloud'));		
	$area2 .= implode(", ",$allFriends); 

      
	set_context('search');
		
	global $CONFIG;
	$categories = elgg_view('categories/list', array('baseurl' => $CONFIG->wwwroot . 'search/?subtype=mycase&tagtype=universal_categories&tag=', 'owner_guid' => $page_owner->guid));
	if(!empty($categories))
	{
		$area3 .= '<div class="contentWrapper">' . $categories . '</div>';
	}

	//Show Tag Cloud
	$area3 .= elgg_view('mycase/cloudTag');

	$body = elgg_view_layout("two_column_left_sidebar", '', $area2, $area3);		
	set_context('mycase');
	page_draw(elgg_echo('mycase:friendsCloud'),$body);
		
?>
