<?php

	/*
	 * Show Mycase Site Stats
	 * */
	global $CONFIG;

	include_once dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php";

	admin_gatekeeper();//Admin Access

	set_page_owner($_SESSION['user']->guid);

	// Category printing		

	$title = elgg_echo('mycase:stats');

	$area2 = elgg_view_title($title);

	$area2 .= elgg_view("mycase/stats");

	$categories = elgg_view('categories/list', array('baseurl' => $CONFIG->wwwroot . 'search/?subtype=mycase&tagtype=universal_categories&tag=', 'owner_guid' => $page_owner->guid));

	if(!empty($categories)){
				$area3 .= '<div class="contentWrapper">' . $categories . '</div>';
	}
	//Show Form for introducing good practice information
	$area3 .= elgg_view('mycase/cloudtag');
		
	$body = elgg_view_layout("two_column_left_sidebar", '', $area2, $area3);

	page_draw($title,$body);
?>
