<?php

function mycase_init()
{	
	global $CONFIG;
	
	// Add a menu entry
	if (isloggedin()) {
			add_menu(elgg_echo('cases'), $CONFIG->wwwroot . "pg/mycase/");			
	}
					
	// lets extend some views
	extend_view('css','mycase/css');
	extend_view('metatags','mycase/javascript');
	extend_view('profile/menu/links','mycase/menu');
	extend_view('groups/menu/links','mycase/menu');
	extend_view('groups/left_column', 'mycase/groupprofile');


	// asking group to include the "mycase"
	add_group_tool_option('mycase', elgg_echo('mycase:group:enablecases'), true);

	// registere some settings
	register_entity_url_handler('mycase_urlhandler','object','mycase');
	register_page_handler('mycase','mycase_pagehandler');

	// register the actions
	register_action('mycase/add',false,$CONFIG->pluginspath . "mycase/actions/add.php");
	register_action('mycase/edit',false,$CONFIG->pluginspath . "mycase/actions/edit.php");
	register_action('mycase/delete',false,$CONFIG->pluginspath . "mycase/actions/delete.php");
	register_action('mycase/send',false,$CONFIG->pluginspath . "mycase/actions/send.php");
	register_action('mycase/showCasesByTerritories',false,$CONFIG->pluginspath . "mycase/actions/showCasesByTerritories.php");
	register_action('mycase/recommendTags', false, $CONFIG->pluginspath . "mycase/actions/recommendTags.php");
	register_action('mycase/reRate', false, $CONFIG->pluginspath . "mycase/actions/reRate.php");
	
	// adding the widget
	add_widget_type('mycase',elgg_echo('mycase:cases'),elgg_echo('mycase:widget'));

	// finally lets register the object
	register_entity_type('object','mycase');
}

function mycase_pagehandler($page)
{

	if(isset($page[0])  && $page[0] != '')
	{
		set_input('username',$page[0]);
	}
	else
	{	
    	@include(dirname(__FILE__) . "/all.php");
		return true;
  	}
	// To control the page flow with the submenu entries links and the actions
	if(isset($page[1]))
	{
		switch($page[1])
		{		
			case "add":
			@include(dirname(__FILE__) . "/add.php");
			return true;
			
			case "play":
			set_input('mycase_instance',$page[2]);
			@include(dirname(__FILE__) . "/play.php");
			return true;
			
			case "all":
			@include(dirname(__FILE__) . "/all.php");
			return true;
			
			case "frnd":
			@include(dirname(__FILE__) . "/frnd.php");
			return true;
			
			case "copy":
			set_input('id',$page[2]);
			set_context('mycase_copy');
			@include(dirname(__FILE__) . "/copy.php");
			return true;
			
			case "edit":
			set_input('id',$page[2]);
			set_context('mycase_edit');
			@include(dirname(__FILE__) . "/edit.php");
			return true;

            case "embed":
			@include(dirname(__FILE__) . "/embed.php");
			return true;
			
			case "mostViewed":			
			@include(dirname(__FILE__) . "/pages/sorted/mostViewed.php");
			break;
			
			case "recentlyViewed":			
			@include(dirname(__FILE__) . "/pages/sorted/recentlyViewed.php");
			break;
			
			case "recentlyCommented":			
			@include(dirname(__FILE__) . "/pages/sorted/recentlyCommented.php");
			break;
			
			case "viewAllTags":			
			@include(dirname(__FILE__) . "/pages/sorted/tags.php");
			break;			
			
			case "mostRated":			
			@include(dirname(__FILE__) . "/pages/sorted/mostRated.php");
			break;
						
			case "mostHighRated":			
			@include(dirname(__FILE__) . "/pages/sorted/mostHighRated.php");
			break;			
						
			case "classifiedByTerritories":			
			@include(dirname(__FILE__) . "/pages/sorted/classifiedByTerritories.php");
			break;
									
			case "viewByFriends":			
			@include(dirname(__FILE__) . "/pages/sorted/viewByFriends.php");
			break;		
									
			case "friendsCloud":			
			@include(dirname(__FILE__) . "/pages/sorted/friends.php");
			break;
			
			case "showClassifiedByTerritories":
			set_input('territories',$page[2]);			
			@include(dirname(__FILE__) . "/pages/sorted/showClassifiedByTerritories.php");
			break;			
			
			case "casesByTag":
			set_input('tag',$page[2]);			
			@include(dirname(__FILE__) . "/pages/sorted/casesByTag.php");
			break;
			
			case "casesByFriend":
			set_input('friend',$page[2]);			
			@include(dirname(__FILE__) . "/pages/sorted/casesByFriend.php");
			break;
			
						
			default:
			@include(dirname(__FILE__) . "/index.php");
			return true;
		}
	}
	else
	{
		@include(dirname(__FILE__) . "/index.php");
		return true;
	}
	
	return false;
}

function mycase_pagesetup()
{
	global $CONFIG;
	
	$pageowner = page_owner_entity();

	$context = get_context();
	$allowedContext = array('mycase', 'mycase_copy', 'mycase_edit');

	//for mycase only
	if(in_array($context, $allowedContext)){
		
		//------ for mycase only, for users
		if(isloggedin() && get_loggedin_userid() == $pageowner->guid){
			
        		if($pageowner instanceof ElggUser){ // only for users
        			add_submenu_item(sprintf(elgg_echo('mycase:frnd'),$pageowner->name), $CONFIG->wwwroot . "pg/mycase/" . $pageowner->username . "/frnd", 'mycase:frnd');
        			add_submenu_item(elgg_echo('mycase:viewByFriends'), $CONFIG->wwwroot . "pg/mycase/sorted/viewByFriends", 'mycase:frnd');
				    add_submenu_item(elgg_echo('mycase:friendsCloud'), $CONFIG->wwwroot . "pg/mycase/sorted/friendsCloud", 'mycase:frnd');	
				}
    		}
		
		if($pageowner){
			
      		// if not logged in and we have page owner
        	add_submenu_item(sprintf(elgg_echo('mycase:user'),$pageowner->name), $CONFIG->wwwroot . "pg/mycase/" . $pageowner->username, 'mycase');
        		
    	}

		// logged in user can add cases
		if(can_write_to_container(get_loggedin_userid(), page_owner())){
			add_submenu_item(elgg_echo('mycase:add'), $CONFIG->wwwroot . "pg/mycase/" . $pageowner->username . "/add", 'mycase');
		}
		

    	// for all we are in the plugin
		add_submenu_item(elgg_echo('mycase:all'), $CONFIG->wwwroot . "pg/mycase", 'mycase');
		
		// menu to display the information sorted, classified by territories, most viewed, most recently viewed, recently commented/rated, high rated, tag cloud
		add_submenu_item(elgg_echo('mycase:classifiedByTerritories'), $CONFIG->wwwroot . "pg/mycase/sorted/classifiedByTerritories", 'mycase:special');
		add_submenu_item(elgg_echo('mycase:mostViewed'), $CONFIG->wwwroot . "pg/mycase/sorted/mostViewed", 'mycase:rated-viewed');
		add_submenu_item(elgg_echo('mycase:recentlyViewed'), $CONFIG->wwwroot . "pg/mycase/sorted/recentlyViewed", 'mycase:rated-viewed');
		add_submenu_item(elgg_echo('mycase:recentlyCommented'), $CONFIG->wwwroot . "pg/mycase/sorted/recentlyCommented", 'mycase:rated-viewed');
		add_submenu_item(elgg_echo('mycase:mostRated'), $CONFIG->wwwroot . "pg/mycase/sorted/mostRated", 'mycase:rated-viewed');
		add_submenu_item(elgg_echo('mycase:mostHighRated'), $CONFIG->wwwroot . "pg/mycase/sorted/mostHighRated", 'mycase:rated-viewed');
		add_submenu_item(elgg_echo('mycase:viewAllTags'), $CONFIG->wwwroot . "pg/mycase/sorted/viewAllTags", 'mycase:special');
	
  	}

	// for groups
	if($pageowner instanceof ElggGroup && $context == 'groups')
	{
		if($pageowner->mycase_enable != 'no')
		{
			add_submenu_item(sprintf(elgg_echo('mycase:user'),$pageowner->name), $CONFIG->wwwroot . "pg/mycase/" . $pageowner->username, 'mycase');
    		}
	}

}


function mycase_urlhandler($mycase_instance)
{
	global $CONFIG;
	return $CONFIG->url . "pg/mycase/" . $mycase_instance->getOwnerEntity()->username . "/play/" . $mycase_instance->getGUID();
}

// finally register every thing with the elgg system
register_elgg_event_handler('pagesetup','system','mycase_pagesetup');
register_elgg_event_handler('init','system','mycase_init', 1000);


?>
