<?php
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	$maxInt32bits = 2147483647-1;
	$showed = 10; //number of practices to display per page	
	$entities = array();	
	$entitiesPag = array();
	$friendsOfMe = array();
	
	$list='';
	//The offset is fetched to page through the results, if none set to 0
	if(isset($_GET['offset'])){
		$offset=$_GET['offset'];
	}
	else{
		$offset=0;
	}
	
	$page_owner = page_owner_entity();
		
	if ($page_owner === false || is_null($page_owner)) 
	{
		$page_owner = $_SESSION['user'];
		set_page_owner($_SESSION['guid']);
	}
	
	$area2 = elgg_view_title(sprintf(elgg_echo('mycase:userfrnd'),$page_owner->name));
			
	

	
	//Also get the people for that is his friend (friend_of)
	$friendsOfMe=get_user_friends_of ( $page_owner->getGUID());	
	foreach($friendsOfMe AS $friend){	
		if(get_user_objects($friend->guid, 'mycase', $maxInt32bits,0)){//If the user has cases, add them to show
			$entities=array_merge($entities,get_user_objects($friend->guid, 'mycase', $maxInt32bits,0));
		}			
	}
	
	
	//Prepare the result to page through
	$entitiesPag=array_slice($entities, $offset, $offset+$showed);
	$list = elgg_view_entity_list($entitiesPag,count($entities), $offset, $showed, FALSE, TRUE, TRUE );
	
	
    if(!empty($list) && $list != ''){		
		$area2 .= $list;		
	}   
	set_context('search');
        
	global $CONFIG;
	$categories = elgg_view('categories/list', array('baseurl' => $CONFIG->wwwroot . 'search/?subtype=mycase&tagtype=universal_categories&tag=', 'owner_guid' => $page_owner->guid));
	if(!empty($categories))
	{
		$area3 .= '<div class="contentWrapper">' . $categories . '</div>';
	}
	
	//Show Tag Cloud
	$area3 .= elgg_view('mycase/cloudTag');
			
	$body = elgg_view_layout("two_column_left_sidebar", '', $area2, $area3);		
	set_context('mycase');
	page_draw(sprintf(elgg_echo('mycase:frnd'),$page_owner->name),$body);
		
?>
