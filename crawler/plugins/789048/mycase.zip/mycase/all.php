<?php

	/*
	 * Show the cases of the site
	 * 
	 * */
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	$page_owner = page_owner_entity();
		
	if ($page_owner === false || is_null($page_owner)) {
		$page_owner = $_SESSION['user'];
		set_page_owner($_SESSION['guid']);
	}
	//Show cases from 10 to 10 sorted by order of creation
	$area2 = elgg_view_title(elgg_echo('mycase:all'));
	$area2 .= list_entities('object','mycase',0,10, FALSE, TRUE, TRUE);
        
	set_context('search');
	//Show categories	
	global $CONFIG;
	$categories = elgg_view('categories/list', array('baseurl' => $CONFIG->wwwroot . 'search/?subtype=mycase&tagtype=universal_categories&tag=', 'owner_guid' => $page_owner->guid));
	if(!empty($categories))
	{
		$area3 .= '<div class="contentWrapper">' . $categories . '</div>';
	}
	
		//Show Tag Cloud
	$area3 .= elgg_view('mycase/cloudTag');

	$body = elgg_view_layout("two_column_left_sidebar", '', $area2, $area3);		
	set_context('mycase');
	page_draw(sprintf(elgg_echo('mycase:all'),$page_owner->name),$body);
		
?>
