<?php

/**
 * Elgg profile plugin extended javascript file.
 * 
 * @package ElggProfile
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Curverider Ltd Dieter Konrad aka alfalive
 * @copyright Curverider Ltd 2008-2009
 * @link http://community.elgg.org/pg/profile/alfalive
 */
 
	global $CONFIG;
	function iconmouseovermenu_init(){
	
		register_elgg_event_handler('init','system','iconmouseovermenu_init');
		
		elgg_extend_view('css', 'css/css');
		elgg_extend_view('profile/javascript', 'profile/javascript');

	}
