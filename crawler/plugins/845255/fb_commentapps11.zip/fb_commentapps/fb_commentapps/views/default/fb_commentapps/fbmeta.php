<?php
    $appID = elgg_get_plugin_setting('fbAppID', 'fb_commentapps');
?>	

<meta property="fb:app_id" content="<?php echo $appID; ?>" />