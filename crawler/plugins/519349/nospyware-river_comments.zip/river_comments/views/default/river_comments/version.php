<?php

	$version = river_comments_get_version();
	$release = river_comments_get_version(true);
?>	

	<meta name="river_comment_release" content="<?php echo $release; ?>" />
	<meta name="river_comment_version" content="<?php echo $version; ?>" />