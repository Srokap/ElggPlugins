<?php
/**
 * XMPP Login
 *
 * @package XMPPLogin
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fernando Vega fvega@ugto.mx
 * @copyright Universidad de Guanajuato México
 * @link http://www.ugto.mx
 */
?>
<p>
  <label for="params[domain]"><?php echo elgg_echo('xmpplogin:settings:domain');?></label><br/>
  <p> <?php echo elgg_echo('xmpplogin:domainexplanation'); ?></p>
  <input type="text" size="50" name="params[domain]" value="<?php echo $vars['entity']->domain;?>"/><br/>
</p>
<p>
  <label for="params[host]"><?php echo elgg_echo('xmpplogin:settings:host');?></label><br/>
  <p> <?php echo elgg_echo('xmpplogin:hostexplanation'); ?></p>
  <input type="text" size="50" name="params[host]" value="<?php echo $vars['entity']->host;?>"/><br/>
</p>
<p>
  <label for="params[port]"><?php echo elgg_echo('xmpplogin:settings:port');?></label><br/>
  <p> <?php echo elgg_echo('xmpplogin:portexplanation'); ?></p>
  <input type="text" size="10" name="params[port]" value="<?php echo $vars['entity']->port;?>"/><br/>
</p>

<p>
  <label for="params[urlpasswordchange]"><?php echo elgg_echo('xmpplogin:settings:urlpasswordchange');?></label><br/>
  <p> <?php echo elgg_echo('xmpplogin:passwordexplanation'); ?></p>
  <input type="text" size="50" name="params[urlpasswordchange]" value="<?php echo $vars['entity']->urlpasswordchange;?>"/><br/>
</p>
<p>
  <label for="params[fogottenpassword]"><?php echo elgg_echo('xmpplogin:settings:fogottenpassword');?></label><br/>
  <p> <?php echo elgg_echo('xmpplogin:fogottenpasswordexplanation'); ?></p>
  <textarea rows="2" cols="50" name="params[fogottenpassword]"><?php echo $vars['entity']->fogottenpassword;?></textarea>
<br/>
</p>