<?php 
/**
 * XMPP Login
 *
 * @package XMPPLogin
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fernando Vega fvega@ugto.mx
 * @copyright Universidad de Guanajuato México
 * @link http://www.ugto.mx
 */
?>
<div id="register-box">
<h2><?php echo elgg_echo('register'); ?></h2><br />
    <?php echo elgg_echo('xmpplogin:disabled'); ?><br />
    <?php echo elgg_echo('xmpplogin:disabled:alternative'); ?>
</div>
    
