<?php
/**
 * XMPP Login
 *
 * @package XMPPLogin
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fernando Vega fvega@ugto.mx
 * @copyright Universidad de Guanajuato México
 * @link http://www.ugto.mx
 */

$user = page_owner_entity();

if ($user) {
?>
<h3><?php echo elgg_echo('email:settings'); ?></h3>
<p>
	<?php echo elgg_echo('email:address:label'); ?>:
        <b><?php

		echo $user->email;

	?>
        </b>
</p>

<?php
}