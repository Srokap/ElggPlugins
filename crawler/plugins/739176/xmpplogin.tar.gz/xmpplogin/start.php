<?php

/**
 * XMPP Login
 *
 * @package XMPPLogin
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fernando Vega fvega@ugto.mx
 * @copyright Universidad de Guanajuato México
 * @link http://www.ugto.mx
 */
require_once 'XMPPHP/XMPP.php';

function xmpplogin_init() {
    
    global $CONFIG;

    // Register the authentication handler
    register_pam_handler('xmpplogin_auth_handler');
}

function xmpplogin_auth_handler($credentials=null) {

    $username = null;
    $password = null;
    $domain = get_plugin_setting("domain", "xmpplogin");
    $host = get_plugin_setting("host", "xmpplogin");
    $port = get_plugin_setting("port", "xmpplogin");

    
    if (is_array($credentials) && ($credentials['username']) && ($credentials['password'])) {

        $username = $credentials['username'];
        $password = $credentials['password'];

        //Handle the "@" character

        if (strpos($username, "@") != false) {

            $email = $username;
            $pieces = explode("@", $username);
            $username = $pieces [0];
        } else {

            $email = $username . "@" . $domain;
        }

        //Let's create the authentication object and try to stablish a connection

        if (is_null($domain) || $domain == "") {

            // No domain has been set yet to authenticate
            return false;
        } else {
        
            $auth = false;
            $conn = new XMPPHP_XMPP($domain,
                                    $port, 
                                    $username,
                                    $password, 
                                    $host);
            try {
                $conn->connect();                
                if($conn->processUntil('session_start'))
                    $auth = true;                
                
            } catch(XMPPHP_Exception $e) {
                error_log($e->getMessage());
                $auth = false;
            }            
            
            if ($auth) {
                echo 'ok';
                if ($user = get_user_by_username($username)) {
                    system_message(elgg_echo('xmpplogin:OK'));
                    return login($user);
                } else {
                    //Create user, if the user has never logged in
                    //register_error(elgg_echo("entro a la vista de creacion de usuario"));
                    $name = $username;
                    $userentity = register_user($username, $password, $name, $email, false);
                    $new_user = get_entity($userentity);
                    $new_user->access_id = 2;
                    $new_user->admin_created = true;
                    $new_user->enable(); 

                    $user = get_user_by_username($username);
                    system_message(elgg_echo('xmpplogin:nologinbefore'));
                    return login($user);
                }
            } else {
                //Username/passwrod combination incorrect.
                register_error(elgg_echo("xmpplogin:error"));
                return false;
            }            
            
        }
    }
}

// ******************** REGISTER EVENT HANDLERS ******************


register_elgg_event_handler('init', 'system', 'xmpplogin_init');
