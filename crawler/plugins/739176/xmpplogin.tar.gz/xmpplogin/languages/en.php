<?php

/**
 * XMPP Login
 *
 * @package XMPPLogin
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fernando Vega fvega@ugto.mx
 * @copyright Universidad de Guanajuato México
 * @link http://www.ugto.mx
 */
$english = array(
//FOR SETTINGS
    'xmpplogin:settings:domain' => "Domain XMPP",
    'xmpplogin:domainexplanation' => "The domain of your XMPP server. I.E. : ugto.mx, jabber.net, company.org, etc.",
    'xmpplogin:settings:host' => "Host XMPP",
    'xmpplogin:hostexplanation' => "The host of your XMPP server. I.E. : siidti.ugto.mx, chat.jabber.net, company.org, etc.",
    'xmpplogin:settings:port' => "Port ",
    'xmpplogin:portexplanation' => "The port of your service XMPP. I.E. : 5222",
    'xmpplogin:settings:urlpasswordchange' => "Password change URL",
    'xmpplogin:passwordexplanation' => "URL of site where the user change password XMPP ",
    'xmpplogin:changepasswordtext' => "If you want change your password, please go to next URL", 
    'xmpplogin:fogottenpasswordexplanation' => "Text for forget password", 
    'xmpplogin:settings:fogottenpassword' => "Forget Password", 
// FOR MESSAGES
    'xmpplogin:nologinbefore' => "You have succesfully authenticated and a user account has been created via your XMPP Apps account.",
    'xmpplogin:OK' => "You have succesfully authenticated via your XMPP account.",
    'xmpplogin:error' => "Wrong username and/or password",
    'xmpplogin:disabled' => "Sorry; Registrations for this site is currently closed.",
    'xmpplogin:disabled:alternative' => "Specify an alternative way for users to get registered here..",
        );

add_translation('en', $english);