<?php

/**
 * XMPP Login
 *
 * @package XMPPLogin
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fernando Vega fvega@ugto.mx
 * @copyright Universidad de Guanajuato México
 * @link http://www.ugto.mx
 */
$spanish = array(
//FOR SETTINGS
    'xmpplogin:settings:domain' => "Dominio XMPP",
    'xmpplogin:domainexplanation' => "El dominio donde esta instalado tu servidor XMPP. Ejem: ugto.mx, jabber.net, company.org, etc.",
    'xmpplogin:settings:host' => "Host XMPP",
    'xmpplogin:hostexplanation' => "El host donde esta instalado tu Servidor XMPP. Ejem: siidti.ugto.mx, chat.jabber.net, company.org, etc.",
    'xmpplogin:settings:port' => "Puerto",
    'xmpplogin:portexplanation' => "El puerto del servicio XMPP. Ejem: 5222",
    'xmpplogin:settings:urlpasswordchange' => "URL cambio contraseña",
    'xmpplogin:passwordexplanation' => "URL donde el usuario puede cambiar la contraseña del servicio XMPP",        
    'xmpplogin:changepasswordtext' => "Para cambiar tu contraseña ve a  la siguiente URL", 
    'xmpplogin:fogottenpasswordexplanation' => "Texto explicación si el usuario olvido su contraseña", 
    'xmpplogin:settings:fogottenpassword' => "Contraseña olvidada", 
// FOR MESSAGES
    'xmpplogin:nologinbefore' => "Tu cuenta ha sido creada y un nuevo usuario ha sido creado en nuestra red social via XMPP",
    'xmpplogin:OK' => "Te has autenticado correctamente",
    'xmpplogin:error' => "Usuario y/o contraseña incorrectos",    
);

add_translation('es', $spanish);