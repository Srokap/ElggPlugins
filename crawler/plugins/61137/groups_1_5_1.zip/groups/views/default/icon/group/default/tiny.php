<?php
	echo $vars['url'] . "mod/groups/graphics/defaulttiny.gif";
?>