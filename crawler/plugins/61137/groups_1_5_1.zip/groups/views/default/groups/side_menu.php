<div class="sidebarBox">
<div id="owner_block_submenu"><ul>
<?php
	if(isloggedin()){
		echo "<li><a href=\"{$vars['url']}pg/groups/new/\">". elgg_echo('groups:new') ."</a></li>";
		echo "<li><a href=\"{$vars['url']}pg/groups/member/{$_SESSION['user']->username}\">". elgg_echo('groups:yours') ."</a></li>";
		echo "<li><a href=\"{$vars['url']}pg/groups/owned/{$_SESSION['user']->username}\">". elgg_echo('groups:owned') ."</a></li>";
		echo "<li class=\"selected\"><a href=\"{$vars['url']}pg/groups/world/\">". elgg_echo('groups:all') ."</a></li>";
	}
?>
</ul></div></div>