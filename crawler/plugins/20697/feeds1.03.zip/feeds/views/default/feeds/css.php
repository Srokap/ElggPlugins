<?php

	/**
	 * Elgg Feeds css extender
	 *
	 * @package ElggFeeds
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

?>


/**
   * Set a very small font size for the control and constrain
   * it's width to 225px
   *
   * Note: the page has a single FeedControl that
   * is drawn in the <div> element whose id is "feedControl".
   */
  #feedControl {
    width : 470px;
  }

  /**
   * Suppress everything except for title
   */
  #feedControl .gf-snippet,
  #feedControl .gf-author,
  #feedControl .gf-spacer,
  #feedControl .gf-relativePublishedDate {
    /* display : none; */
  }

  /**
   * 1em Padding at the bottom of each collection of entries
   */
  #feedControl .gfc-results {
    padding-bottom : 1em;
  }

  /**
   * no padding between entries
   */
  #feedControl .gfc-result {
    margin-bottom : 10px;
  }


/* section title */
#feedControl .gfc-resultsHeader .gfc-title,
#displayFeeds .gfc-resultsHeader .gfc-title {
	font-size : 1.4em;
	font-weight: bold;
	line-height: normal;
}
/* individual feeds title */
#displayFeeds .gfc-resultsHeader {
	border-bottom:1px solid #cccccc;
	padding-bottom:4px;
	margin-bottom:10px;
	width:100%;
}
/* post title */
.gf-result .gf-title {
	font-size : 1.2em;
	font-weight: bold;
	line-height: normal;
}
.gf-relativePublishedDate,
.gf-author,
.gf-spacer {
	font-size:90%;
}
/* wraps each post */
#displayFeeds .gfc-result {
	padding:5px 0 10px 0;
	border-bottom:1px solid #cccccc;
}


/* sidebar list */

.add_feed {
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #ffffff;
	background:#000000;
	-webkit-border-radius: 3px;
	-moz-border-radius: 3px;
	padding: 2px 6px 2px 6px;
	margin:20px 0 10px 0;
	cursor: pointer;
}

.add_feed:hover {
	background: #8b000b;
	color: #ffffff;
	text-decoration: none;
}

a.add_feed {
    margin:10px 0 0 0;
}

#open_feed_form {
    margin:10px 0 0 0;
}

#feeds_delete {
	height:10px;
}

#feeds ul {
	margin: 0;
	padding: 0;
	border-top:1px solid #cccccc;
}

#feeds li.feed_item {
  border-bottom:1px solid #cccccc;
  padding:2px;
  margin:0;
  list-style:none;
}

#feeds .feed_button {
  cursor:pointer;
  text-align:left;
  padding:0 6px 0 0;
}

#feeds .feed_button:hover {
  /* background:#efefef;*/
}

#feeds .delete_feed {
  cursor:pointer;
  color:#999999;
  font-size: 90%;
}

#add_new_feed {
  display:none;
  margin:20px 0 0 0;
}
.feed_item:hover {
	background:#efefef;
	text-decoration:none;
}

#add_new_feed input {
    padding:2px;
    width:180px;
}

#feeds_list {
    margin:2px;
}






