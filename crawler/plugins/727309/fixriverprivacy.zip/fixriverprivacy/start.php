<?php

  /**
   * Activity River privacy
	* modifies the river so that it
	* only shows objects - no relationships, profile changes etc
	*based on 1.7.8 Elgg code
	*@author Jon Dron
	* Athabasca University
   */

  function fixriverprivacy_init() {

	// just a placeholder
  }


  register_elgg_event_handler('init', 'system', 'fixriverprivacy_init');

?>
