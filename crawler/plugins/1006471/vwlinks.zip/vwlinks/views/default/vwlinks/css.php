<?php
 
    /**
	 * Elgg vwlinks CSS
	 * 
	 * @package Elggvwlinks
	 */
     
?>

#vwlinks_widget {
    margin:0 10px 0 10px;
}

#vwlinks_widget ul {
	margin:0;
	padding:0;
}

#vwlinks_widget li {
	background: url(<?php echo $vars['url']; ?>mod/vwlinks/graphics/thewire_speech_bubble.gif) no-repeat right bottom;
	list-style-image:none;
	list-style-position:outside;
	list-style-type:none;
	margin:0 0 5px 0;
	padding:0;
	overflow-x: hidden;
}

#vwlinks_widget li span {
	color:#666666;
	background:white;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	padding:5px;
	display:block;
}

p.visit_vwlinks a {
    background:url(<?php echo $vars['url']; ?>mod/vwlinks/graphics/vwlinks.png) left no-repeat;
    padding:0 0 0 20px;
    margin:0;
}
.visit_vwlinks {
	background:white;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	padding:2px;
	margin:0 0 5px 0;
}

#vwlinks_widget li a {
	display:block;
	margin:0 0 0 4px;
}

#vwlinks_widget li span a {
	display:inline !important;
}