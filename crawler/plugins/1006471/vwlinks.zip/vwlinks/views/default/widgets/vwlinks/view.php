<div style="margin:0 10px 0 10px; -webkit-border-radius: 8px; -moz-border-radius: 8px; background: #cccccc; margin-bottom:5px;">
Copy and paste this code to your site/blog :<br />
<textarea cols=31 rows=4>
<script language="JavaScript" src="<?php echo $CONFIG->wwwroot; ?>mod/vwlinks/myrooms.js.php?id=<?php $ver=explode('.', get_version(true));	if ($ver[1]>7) echo elgg_get_logged_in_user_entity()->guid; else echo get_loggedin_user()->guid; ?>"></script>
</textarea></div>
