<?php

    /**
	 * Elgg vwlinks edit page
	 *
	 * @package Elggvwlinks
	 */

?>
