<?php
	// Load Elgg engine
		require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
		$id = get_input('id');

$sql = "SELECT ".$CONFIG->dbprefix."objects_entity.description, ".
			 $CONFIG->dbprefix."objects_entity.title ".
			 "FROM ( ".$CONFIG->dbprefix."entities ".$CONFIG->dbprefix."entities ".
       "INNER JOIN ".
       $CONFIG->dbprefix."entity_subtypes ".$CONFIG->dbprefix."entity_subtypes ".
       "ON (".$CONFIG->dbprefix."entities.subtype = ".$CONFIG->dbprefix."entity_subtypes.id)) ".
       "INNER JOIN ".
       $CONFIG->dbprefix."objects_entity ".$CONFIG->dbprefix."objects_entity ".
       "ON (".$CONFIG->dbprefix."objects_entity.guid = ".$CONFIG->dbprefix."entities.guid) ".
			 "WHERE ".$CONFIG->dbprefix."entity_subtypes.subtype = 'videowhisper' AND ".
			 $CONFIG->dbprefix."entities.owner_guid = '".$id."' ORDER BY ".$CONFIG->dbprefix."objects_entity.guid DESC LIMIT 5;";

			//echo 'document.write("<p>'.$sql.'</p>");';
	if ($rows = get_data($sql)) {
		foreach($rows as $row) {
$sqlliveusercount = "SELECT ".$CONFIG->dbprefix."objects_entity.description, ".
			 $CONFIG->dbprefix."objects_entity.guid ".
			 "FROM ( ".$CONFIG->dbprefix."entities ".$CONFIG->dbprefix."entities ".
       "INNER JOIN ".
       $CONFIG->dbprefix."entity_subtypes ".$CONFIG->dbprefix."entity_subtypes ".
       "ON (".$CONFIG->dbprefix."entities.subtype = ".$CONFIG->dbprefix."entity_subtypes.id)) ".
       "INNER JOIN ".
       $CONFIG->dbprefix."objects_entity ".$CONFIG->dbprefix."objects_entity ".
       "ON (".$CONFIG->dbprefix."objects_entity.guid = ".$CONFIG->dbprefix."entities.guid) ".
			 "WHERE ".$CONFIG->dbprefix."entity_subtypes.subtype = 'videowhisper' AND ".
			 $CONFIG->dbprefix."objects_entity.title = '".$row->title."' AND ".
			 $CONFIG->dbprefix."entities.owner_guid = '".$id."' ORDER BY ".$CONFIG->dbprefix."objects_entity.guid DESC;";
	$count = 0;
	$ztime = time();
	$exptime=$ztime-30;
	$users = "";
	
	if ($rows2 = get_data($sqlliveusercount)) {
		foreach($rows2 as $row2) {
			$descriptionx = $row2->description; 
			$guid = $row2->guid;
			//echo $descriptionx."<br />";
			$nilai = explode(":", $descriptionx);
			$newdescription = "";
			if ($nilai[3] < $exptime) {	// if last access time < exptime
				for ($i = 0; $i <= 2; $i++) {
					if ($i == 1) 
						$newdescription .= "0:"; // set status as 0 ( logout )
					else
						$newdescription .= $nilai[$i].":";
				}
				$newdescription .= $nilai[3];
				// $result = update_data("UPDATE {$CONFIG->dbprefix}objects_entity 
				// set description='$newdescription' 
				// where guid=$guid ;");
			} else {
				$count = $count + 1;
				if ($count <= 5) {
					$users .= $nilai[2].', ';
				}
			}
			
		}
		$users = substr($users, 0, (strlen($users) - 2));
	}	
		if (substr($row->description, 0, 1) == '1') {
			echo 'document.write("<a href=\"'.$CONFIG->wwwroot.'pg/videoconference/'.$row->title.'\">'.$row->title.'</a>&nbsp;(&nbsp;'.$count.'&nbsp;)<br />");';
		}
		elseif (substr($row->description, 0, 1) == '2') {
			echo 'document.write("<a href=\"'.$CONFIG->wwwroot.'pg/videochat/'.$row->title.'\">'.$row->title.'</a>&nbsp;(&nbsp;'.$count.'&nbsp;)<br />");';
		}
		elseif (substr($row->description, 0, 1) == '3') {
			echo 'document.write("<a href=\"'.$CONFIG->wwwroot.'pg/videoconsultation/'.$row->title.'\">'.$row->title.'</a>&nbsp;(&nbsp;'.$count.'&nbsp;)<br />");';
		}
		elseif (substr($row->description, 0, 1) == '4') {
			echo 'document.write("<a href=\"'.$CONFIG->wwwroot.'pg/livestreaming/'.$row->title.'\">'.$row->title.'</a>&nbsp;(&nbsp;'.$count.'&nbsp;)<br />");';
		}
		}
	}
?>
