<?php
/**
 * vwlinks widget language file
 */

$english = array(

	'vwlinks:title' => 'Links to the your rooms',
	'vwlinks:info' => 'Display your elgg videowhisper rooms on your site',
	'vwlinks:username' => 'Enter your vwlinks username.',
	'vwlinks:num' => 'The number of tweets to show.',
	'vwlinks:visit' => 'visit my vwlinks',
	'vwlinks:notset' => 'This vwlinks widget is not yet set to go. To display your latest tweets, click on - edit - and fill in your details',		
);
					
add_translation("en", $english);
