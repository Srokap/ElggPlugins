<?php
/**
 * Elgg vwlinks widget
 * This plugin allows users to pull in their vwlinks feed to display on their profile
 * 
 * @package Elggvwlinks
 */

register_elgg_event_handler('init', 'system', 'vwlinks_init');

function vwlinks_init() {
	elgg_extend_view('css', 'vwlinks/css');
	add_widget_type('vwlinks', elgg_echo('vwlinks:title'), elgg_echo('vwlinks:info'));
}
