<?php
if (isset($vars['twitterlist']))
{
$twitterlist = $vars['twitterlist'];
$qtytweets = $vars['qtytweets'];
$twitterheader = $vars['twitterheader'];
}
else
{
	$twitterlist = (string) get_plugin_setting('twitterlist', 'sitetwitter');
	$qtytweets = (string) get_plugin_setting('qtytweets', 'sitetwitter');	
	$twitterheader = (string) get_plugin_setting('twitterheader', 'sitetwitter');		
}
	if ($twitterlist=="") {$twitterlist="elgg";}
	if ($qtytweets=="") {$qtytweets="10";}	
	
?>
<div id="twitter_sizer"><div id="twitter_div">
<?php if (twitterheader!="") { ?>
<h2 class="twitter_title"><?php echo $twitterheader ?></h2>
<?php } ?>
<ul id="twitter_update_list"></ul>
</div></div>
<script type="text/javascript" src="/mod/sitetwitter/vendors/twitter/blogger_mod.js"></script>
<script type="text/javascript" src="http://twitter.com/statuses/user_timeline/<?php echo $twitterlist ?>.json?callback=twitterCallback2&count=<?php echo $qtytweets ?>"></script>