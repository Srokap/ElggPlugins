<?php
/*
 * Css for sitetwitter
 
 */
?>
.sitetwitter_div {
	color: #000000;
}

#twitter_sizer {  }

#twitter_div {
	margin:0 0 0 0; 
}

#twitter_div  h2.twitter_title { font-size:110%; color: #000000;}


#twitter_div ul {
	margin: 0;
	padding: 0;
}
 
#twitter_div li {
	margin: 0 0 10px 0;
	padding: 10px 10px 10px 10px;
	background-color: #ebf5ff;
	background2:#ebf5ff url(http://news.elgg.org/mod/standaloneblog/graphics/twitter_arrow.gif) no-repeat right bottom;
} 

#twitter_div ol,
#twitter_div ul {
	list-style: none;
}

.tweet_status {}
SPAN.tweet_link_ago { display: block;}
SPAN.tweet_link_ago a { font-size:90%; color:red;}
