<div class="contentWrapper">
<?php
	echo "You have selected " . (int)$vars['entity']->param . " as your widget parameter";
?>
</div>