<p>
<?php 

	// set default value if user hasn't set it
	$qtytweets = $vars['entity']->qtytweets;
	$twitterlist = $vars['entity']->twitterlist;
	$twitterheader = $vars['entity']->twitterheader;
	if (!isset($qtytweets)) $qtytweets = 5;
	if (!isset($twitterlist)) $twitterlist = "elgg";	
	if (!isset($twitterheader)) $twitterheader = "Site Twitter";	


	echo elgg_echo('sitetwitter:param_twitterheader_label'); 
	
	echo elgg_view('input/text', array('value'=>$twitterheader, 'internalname'=>'params[twitterheader]'));		

	echo "<br />";
	
		
	echo elgg_echo('sitetwitter:param_twitterlist_label'); 
	
	echo elgg_view('input/text', array('value'=>$twitterlist, 'internalname'=>'params[twitterlist]'));		

	echo "<br />";
		
	echo elgg_echo('sitetwitter:param_nooftweets_label'); 
		
	echo elgg_view('input/pulldown', array(
		'internalname' => 'params[qtytweets]',
		'options_values' => array(	'1' => '1',
									'2' => '2',
									'3' => '3',
									'4' => '4',
									'5' => '5',
									'6' => '6',										
									'7' => '7',										
									'8' => '8',										
									'9' => '9',										
									'10' => '10',																																								
								),
		'value' => $qtytweets
		));

	
?>
</p>