<?php
/*
 * Css for sitetwitter
 
 TAKEN FROM SEAOFCLOUDS
 
 */
?>
.sitetwitter_div {
	color: #000000;
}




.twitter_container{

color:#444;
font-size:12px;
width:600px;
margin: 0 auto;

}
.twitter_container a{

color:#0066CC;
font-weight:bold;

}
.twitter_status{

height:60px;
padding:6px;
border-bottom:solid 1px #DEDEDE;

}
.twitter_image{

float:left;
margin-right:14px;
border:solid 2px #DEDEDE;
width:50px;
height:50px;

}
.twitter_posted_at{

font-size:11px;
padding-top:4px;
color:#999;

}









.query {
  font-family: Arial, serif;
  font-size: 90%;
  color: #085258; }
  .query .tweet_list {
    -webkit-border-radius: .5em;
    list-style-type: none;
    margin: 0;
    padding: 0;
    background-color: #8ADEE2; }
    .query .tweet_list li {
      overflow: auto;
      padding: .5em; }
      .query .tweet_list li a {
        color: #0C717A; }
    .query .tweet_list .tweet_even {
      background-color: #91E5E7; }
    .query .tweet_list .tweet_avatar {
      padding-right: .5em;
      float: left; }
      .query .tweet_list .tweet_avatar img {
        vertical-align: middle; }
		
	.tweet {
  font-family: Georgia, serif;
  font-size: 120%;
  color: #085258; }
  .tweet .tweet_list {
    -webkit-border-radius: .5em;
    list-style-type: none;
    margin: 0;
    padding: 0;
    background-color: #8ADEE2; }
    .tweet .tweet_list li {
      overflow: auto;
      padding: .5em; }
      .tweet .tweet_list li a {
        color: #0C717A; }
    .tweet .tweet_list .tweet_even {
      background-color: #91E5E7; }
    .tweet .tweet_list .tweet_avatar {
      padding-right: .5em;
      float: left; }
      .tweet .tweet_list .tweet_avatar img {
        vertical-align: middle; }
	
	
	
	
	
	
	
	
	
	
	
	#twitter_widget {
	MARGIN: 0px 10px
}
#twitter_widget UL {
	PADDING-BOTTOM: 0px; MARGIN: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; PADDING-TOP: 0px
}
#twitter_widget LI {
	LIST-STYLE: none none outside; PADDING-BOTTOM: 0px; OVERFLOW-X: hidden; MARGIN: 0px 0px 5px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; BACKGROUND: url(http://community.elgg.org/mod/twitter/graphics/thewire_speech_bubble.gif) no-repeat right bottom; PADDING-TOP: 0px
}
#twitter_widget LI SPAN {
	PADDING-BOTTOM: 5px; PADDING-LEFT: 5px; PADDING-RIGHT: 5px; DISPLAY: block; BACKGROUND: white; COLOR: #666666; PADDING-TOP: 5px; -webkit-border-radius: 8px; -moz-border-radius: 8px
}
P.visit_twitter A {
	PADDING-BOTTOM: 0px; MARGIN: 0px; PADDING-LEFT: 20px; PADDING-RIGHT: 0px; BACKGROUND: url(http://community.elgg.org/mod/twitter/graphics/twitter.png) no-repeat left 50%; PADDING-TOP: 0px
}
.visit_twitter {
	PADDING-BOTTOM: 2px; MARGIN: 0px 0px 5px; PADDING-LEFT: 2px; PADDING-RIGHT: 2px; BACKGROUND: white; PADDING-TOP: 2px; -webkit-border-radius: 8px; -moz-border-radius: 8px
}
#twitter_widget LI A {
	MARGIN: 0px 0px 0px 4px; DISPLAY: block
}
#twitter_widget LI SPAN A {
	DISPLAY: inline !important
}
