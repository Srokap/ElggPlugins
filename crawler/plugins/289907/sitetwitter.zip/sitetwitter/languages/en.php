<?php
$english = array(
	'sitetwitter:pagetitle'	=> 'Site Twitter',
	'sitetwitter:param_twitterheader_label'	=> 'Site Twitter Headline',	
	'sitetwitter:param_nooftweets_label'	=> 'Number of Tweets',
	'sitetwitter:param_twitterlist_label'	=> 'Site Twitters',	

);

add_translation("en",$english);
?>