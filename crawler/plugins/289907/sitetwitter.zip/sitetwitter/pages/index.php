<?php

	// include the Elgg engine
	include_once dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php"; 

	// maybe logged in users only?
	//gatekeeper();
	
	// get any input
	//$param = get_input('param');
	
	// if username or owner_guid was not set as input variable, we need to set page owner
	// Get the current page's owner
	$page_owner = page_owner_entity();
	if (!$page_owner) {
		$page_owner_guid = get_loggedin_userid();
		if ($page_owner_guid)
			set_page_owner($page_owner_guid);
	}	

	$title = elgg_echo('sitetwitter:pagetitle');
	
	// create content for main column
	$content = elgg_view_title($title);
	
	//$twitterlist = (string) get_plugin_setting('twitterlist', 'sitetwitter');
	//if ($twitterlist=="") {$twitterlist="elgg";}
	//$qtytweets = (string) get_plugin_setting('qtytweets', 'sitetwitter');	
	//if ($qtytweets=="") {$qtytweets="10";}	
	//$twitterheader = (string) get_plugin_setting('twitterheader', 'sitetwitter');
	//if ($twitterheader=="") {$twitterheader="Site Twitter";}		
		
	//$content .= elgg_view("sitetwitter/twitterlist", array('twitterlist'=>$twitterlist, 'qtytweets'=>$qtytweets, 'twitterheader'=>$twitterheader));
	
	
	$content_twitter = elgg_view("sitetwitter/twitterlist");
	
	// layout the sidebar and main column using the default sidebar
	$body = elgg_view_layout('two_column_left_sidebar', '', $content . $content_twitter );

	// create the complete html page and send to browser
	page_draw($title, $body);
?>