<?php
/*******************************************************************************
 * sitetwitter
 *
 * @author admin
 ******************************************************************************/

	function sitetwitter_init()
	{
		global $CONFIG;

		extend_view('css','sitetwitter/css');


		//add_widget_type('sitetwitter', 'My Widget', 'Description of my widget');


		//register_page_handler('sitetwitter','sitetwitter_page_handler');


		add_menu(sitetwitter, $CONFIG->wwwroot . 'pg/sitetwitter/index/');


		register_elgg_event_handler('pagesetup','system','sitetwitter_submenus');


		
		
		return true;
	}


	function sitetwitter_page_handler($page)
	{
		global $CONFIG;

		
		switch ($page[0])
		{
			case 'index':
				include $CONFIG->pluginspath . 'sitetwitter/pages/index.php';
				break;
		
		}
		
		return true;
	}


	function sitetwitter_submenus()
	{
		global $CONFIG;

		
		if (get_context() == 'sitetwitter')
		{
			add_submenu_item('index', $CONFIG->wwwroot . 'pg/sitetwitter/index/');
		}
		
	}


	
	register_elgg_event_handler('init', 'system', 'sitetwitter_init');
?>