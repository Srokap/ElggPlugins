<?php
/*******************************************************************************
 * videoplayer
 *
 * @author Robert S. Robbins
 ******************************************************************************/

	function videoplayer_init()
	{
		global $CONFIG;

		return true;
	}

	register_elgg_event_handler('init', 'system', 'videoplayer_init');
?>