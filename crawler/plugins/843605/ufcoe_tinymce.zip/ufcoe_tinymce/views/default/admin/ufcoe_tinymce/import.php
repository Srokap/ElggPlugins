<?php

echo elgg_view_form('ufcoe_tinymce/import');