<?php

$english = array(
	'admin:ufcoe_tinymce' => 'UFCOE TinyMCE Options',
    'admin:ufcoe_tinymce:import' => 'Import',
    'admin:ufcoe_tinymce:export' => 'Export',
);

add_translation("en", $english);