**Note!** This directory must be named `ufcoe_tinymce` in your mod folder.

Provides the following features:

* Full configuration of up to 3 tinyMCE button rows
* Control (bundled) tinyMCE plugins
* Control native browser spellcheck
* Links to helpful TinyMCE reference pages
* Export/import options in JSON format
* Preview of current settings after saving