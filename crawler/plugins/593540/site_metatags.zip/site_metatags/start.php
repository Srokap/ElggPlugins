<?php

	function site_metatags_init() {
		extend_view('metatags', 'site_metatags/metatags');
	}

	register_elgg_event_handler('init', 'system', 'site_metatags_init');

?>