<p>
	Define the keywords (comma-separated):
	<!-- input type="text" name="params[keywords]" value="<?php echo get_plugin_setting('keywords', 'site_metatags'); ?>" / -->
	<?php echo elgg_view('input/text', array('internalname' => "params[keywords]", 'value' => $vars['entity']->keywords)); ?>
</p>