<?php
$keywords = explode(',', get_plugin_setting('keywords', 'site_metatags'));
foreach($keywords as $key){ ?>
<meta name="keywords" content="<?php echo trim($key); ?>" />
<? } ?>