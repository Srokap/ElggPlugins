<?php
/**
 * dislikes CSS
 */
?>

/* ***************************************
	disikes
*************************************** */
.elgg-dislikes {
	width: 345px;
	position: absolute;
}

.elgg-menu .elgg-menu-item-dislikes-count {
	margin-left: 3px;
}
