<?php
	/**
	 * 
	 *
	 * @package PackOfARoamingCat
	 */
	/**
	 * @author Snow.Hellsing <snow.hellsing@firebloom.cc>
	 * @copyright FireBloom Studio
	 * @link http://firebloom.cc
	 */
?>
//for IE6
.mceLayout{
	width:670px !important;
}