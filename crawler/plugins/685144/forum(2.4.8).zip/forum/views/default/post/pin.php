<?php
	/**
	 * @file views/default/post/pin.php
	 * @brief Displays a pin icon for sticked topics
	 */
?>

<img class="pin_icon topic_icon" alt="<?php echo elgg_echo('forum:sticky'); ?>" title="<?php echo elgg_echo('forum:sticky'); ?>" src="<?php echo $vars['url']; ?>mod/forum/graphics/pingreen.png" />