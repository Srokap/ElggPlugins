<?php
	/**
	 * @file views/default/forum/wrong_url.php
	 * @brief Displays the wrong url page view
	 */

	echo elgg_echo('forum:errors:url_not_exists');
?>