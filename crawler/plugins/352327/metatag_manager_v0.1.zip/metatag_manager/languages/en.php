<?php
	$english = array(
	
		// admin settings
		'metatag_manager:settings:title' => "Configure your metatags",
		'metatag_manager:settings:keywords' => "Keywords",
		'metatag_manager:settings:description' => "Description",
		'metatag_manager:settings:robots' => "Robots",
		'metatag_manager:settings:author' => "Author",
		
		// saved
		'metatag_manager:settings:save' => "Successfully saved metatags settings",
		
		
	
	);
	
	add_translation("en", $english);
?>
