#<?php echo get_plugin_setting('trick_field_name', 'uncaptcha'); ?> {
	position: absolute;
	top: -2000px;
	left: -2000px;
}