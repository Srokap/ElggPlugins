<?php

$english = array (

	/**
	 * Plugin settings items
	 */
	'ajaxactiontoken:refresh:time' => "The amount of time (in minutes) before the token gets refreshed",
	'ajaxactiontoken:expiry:time' => "The amount of time (in minutes) before the token gets expired",
	'ajaxactiontoken:warning:time' => "WARNING: The expiry time must be greater than the refresh time",
);

add_translation ( "en", $english );

?>