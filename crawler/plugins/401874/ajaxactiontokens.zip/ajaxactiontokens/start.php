<?php

function ajaxactiontokens_init() {
	extend_view ( "js/initialise_elgg", "js/regenerate_token" );
	extend_view ( 'metatags', 'js/initialize_token' );
}

register_elgg_event_handler ( 'init', 'system', 'ajaxactiontokens_init' );

global $CONFIG;
register_action ( 'generate/token', true, $CONFIG->pluginspath . "ajaxactiontokens/actions/generate.php" );

?>