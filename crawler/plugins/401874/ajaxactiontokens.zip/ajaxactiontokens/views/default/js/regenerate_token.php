<?php
global $CONFIG;
$time = get_plugin_setting('refreshTime', 'ajaxactiontokens');
if (is_numeric($time)) {
	$refresh_time = ($time * 60) * 1000; // some minutes
} else {
	$refresh_time = 50 * 60000; // 50 minutes
}
?>
var elgg_generate_token_interval = <?php echo $refresh_time; ?>;

function generate_action_token(ts, token) {

	$.getJSON("<?php echo $CONFIG->wwwroot; ?>action/generate/token", { __elgg_token: token, __elgg_ts: ts }, 
		function(data){
			setElggTimeStamp(data.ts);
			setElggToken(data.token);
			console.log('Elgg action token will be regenerated in: '+elgg_generate_token_interval+'ms ...');
        });
	
}

function setElggTimeStamp(ts) {
	console.log("Setting action timestamp: " + ts);
	window.elgg_action_timestamp = ts;
	
}

function getElggTimeStamp() {
	console.log("Getting action timestamp: " + window.elgg_action_timestamp);
	return window.elgg_action_timestamp;
}

function setElggToken(token) {
	console.log("Setting action token: " + token);
	window.elgg_action_token = token;
}

function getElggToken() {
	console.log("Getting action token: " + window.elgg_action_token);
	return window.elgg_action_token;
}

$(document).ready(function () {	
	setInterval( "generate_action_token(getElggTimeStamp(), getElggToken())", elgg_generate_token_interval );
}); /* end document ready function */