<?php 
	// get the time in minutes that we want this token to live from now
	$time = get_plugin_setting('expiryTime', 'ajaxactiontokens');
	
	// test the variable
	if (!is_numeric($time)) {
		$time = 5; // minutes
	}
	
	// the time 1 hour ago i.e. a token generated with this time will expire now 
	$ts = time() - 3600;
	
	// calculate the time to add to the expiry timestamp 
	$time = $time * 60;
	
	// this is when the token will expire
	$ts = $ts + $time;
	
	$token = generate_action_token($ts);
?>
<script type="text/javascript">

	setElggToken('<?php echo $token; ?>');
	setElggTimeStamp('<?php echo $ts; ?>');

</script>