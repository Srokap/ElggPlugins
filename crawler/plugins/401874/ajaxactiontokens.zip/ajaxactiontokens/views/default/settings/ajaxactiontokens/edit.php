<p>
<?php 
if ($vars['entity']->refreshTime) {
	$refreshTime = $vars['entity']->refreshTime;
} else {
	$refreshTime = 4;
}

if ($vars['entity']->expiryTime) {
	$expiryTime = $vars['entity']->expiryTime;
} else {
	$expiryTime = 5;
}

?>

    <b><?php echo elgg_echo('ajaxactiontoken:warning:time'); ?></b><br />
 
    <?php echo elgg_echo('ajaxactiontoken:expiry:time'); ?>
 
 	<input name="params[expiryTime]" size="80" value="<?php echo $expiryTime; ?>" /> 

    <?php echo elgg_echo('ajaxactiontoken:refresh:time'); ?>
 
 	<input name="params[refreshTime]" size="80" value="<?php echo $refreshTime; ?>" />
 
</p>

<?php elgg_echo(); ?>