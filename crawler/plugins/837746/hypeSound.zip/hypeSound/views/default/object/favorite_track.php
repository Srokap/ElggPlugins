<?php

echo elgg_view('hj/sound/oembed', $vars);