<?php
$user = elgg_get_page_owner_entity();

if (!$user) {
    $handler = 'all';
} else {
    $handler = 'owner';
}

// content links
$content_menu = elgg_view_menu('soundcloud', array(
	'entity' => elgg_get_page_owner_entity(),
        'handler' => $handler,
	'class' => 'profile-content-menu',
        'sort_by' => 'priority'
));

echo $content_menu;