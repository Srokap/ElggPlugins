<?php

$user = elgg_extract('entity', $vars);
$section = elgg_extract('section', $vars);

switch ($section) {
    default :
    case 'tracks' :
        $subtype = 'track';
        break;
    case 'playlists' :
        $subtype = 'playlist';
        break;
    case 'favorites' :
        $subtype = 'favorite_track';
        break;
}

echo elgg_list_entities(array(
    'type' => 'object',
    'subtype' => $subtype,
    'owner_guid' => $user->guid,
    'limit' => 10,
    'pagination' => true
        ));
