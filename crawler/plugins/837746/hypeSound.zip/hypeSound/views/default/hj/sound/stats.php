<?php

$user = elgg_extract('entity', $vars);

if (!$user) {
    return true;
}

$title = elgg_echo('hj:sound:usercontent:stats');

if ($user->canEdit()) {
    $html = '<p>' . elgg_view('output/url', array(
                'text' => elgg_echo('hj:sound:usercontent:importpersonaldata'),
                'href' => 'action/sound/import_me',
                'is_action' => true,
                'class' => 'elgg-button elgg-button-action'
            )) . '</p>';

    $html .= '<p>' . elgg_view('output/url', array(
                'text' => elgg_echo('hj:sound:usercontent:importtracks'),
                'href' => 'action/sound/import?subtype=track',
                'is_action' => true,
                'class' => 'elgg-button elgg-button-action'
            )) . '</p>';

    $html .= '<p>' . elgg_view('output/url', array(
                'text' => elgg_echo('hj:sound:usercontent:importplaylists'),
                'href' => 'action/sound/import?subtype=playlist',
                'is_action' => true,
                'class' => 'elgg-button elgg-button-action'
            )) . '</p>';

    $html .= '<p>' . elgg_view('output/url', array(
                'text' => elgg_echo('hj:sound:usercontent:importfavorites'),
                'href' => 'action/sound/import?subtype=favorite_track',
                'is_action' => true,
                'class' => 'elgg-button elgg-button-action'
            )) . '</p>';
}

//if ($user->soundcloud_id && $user->canEdit()) {
//    $html .= '<p>' . elgg_view('output/url', array(
//                'text' => elgg_echo('hj:sound:usercontent:refreshpersonaldata'),
//                'href' => 'action/sound/import_me',
//                'is_action' => true,
//                'class' => 'elgg-button elgg-button-action'
//            )) . '</p>';
//}

if ($user->soundcloud_accessToken && $user->canEdit()) {
    $html .= '<p>' . elgg_view('output/url', array(
                'text' => elgg_echo('hj:sound:usercontent:deauthorize'),
                'href' => 'action/sound/deauthorize',
                'is_action' => true,
                'class' => 'elgg-button elgg-button-action'
            )) . '</p>';
}

if ($user->soundcloud_id) {
    $meta = array(
        //'description' => elgg_echo('description'),
        'track_count' => elgg_echo('hj:sound:usercontent:track_count'),
        'playlist_count' => elgg_echo('hj:sound:usercontent:playlist_count'),
        'followers_count' => elgg_echo('hj:sound:usercontent:followers_count'),
        'public_favorites_count' => elgg_echo('hj:sound:usercontent:public_favorites_count')
    );

    foreach ($meta as $key => $value) {
        $meta_append = "soundcloud_$key";
        $meta_value = $user->$meta_append;
        //if ($meta_value) {
        $meta_html .= <<<HTML
            <div class="hj-sound-soundcloud-meta">
                <span class="hj-sound-soundcloud-metaname">
                    {$value}
                </span>
                <span class="hj-sound-soundcloud-metavalue">
                    {$meta_value}
                </span>
            </div>
HTML;
        //}
    }

    $html .= <<<HTML
            <div class="hj-sound-soundcloud-name">
                <a href="$user->soundcloud_permalink_url" target="_blank">$user->soundcloud_permalink</a>
            </div>
            $meta_html
       </div>
HTML;
}

$html = elgg_view_module('info', $title, $html);

echo $html;