<?php

$user = elgg_extract('entity', $vars);

if (!$user) {
    return true;
}

$intro = elgg_echo('hj:sound:auth:intro');

$siteURL = elgg_get_config('url');
$callbackURL = "{$siteURL}sounds/authorize/";
$client_id = elgg_get_plugin_setting('client_id', 'hypeSound');
$client_secret = elgg_get_plugin_setting('client_secret', 'hypeSound');

$soundcloud = new hjSound($client_id, $client_secret, $callbackURL);
$authorizeURL = $soundcloud->getAuthorizeUrl(array('scope' => 'non-expiring'));

$html = <<<HTML
    <p>$intro</p>
    <a href="$authorizeURL" title="Authorize your SoundCloud Account">
        <img src="{$siteURL}mod/hypeSound/graphics/soundcloud.gif" align="center" alt="SoundCloud" />
    </a>
HTML;

echo $html;

