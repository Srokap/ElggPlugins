<?php

$entity = elgg_extract('entity', $vars, false);

if (!$entity)
    return true;

if (!$entity->embed) {
    if (!$url = $entity->uri) {
        $url = $entity->permalink_url;
    }
    $ombed = new SimpleOEmbed('http://soundcloud.com/oembed', $url, 'json');
    $data = $ombed->getOEmbedObject();
    if ($data) {
        $entity->embed = $data->html;
    }
}

echo '<div class="hj-padding-ten">';
echo $entity->embed;
echo '<div class="clearfix">';
echo elgg_view_menu('entity', array(
    'entity' => $entity,
    'sort_by' => 'priority',
    'class' => 'elgg-menu-hz'
));
echo '</div>';
echo '</div>';