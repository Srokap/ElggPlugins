<?php

$api_intro = 'To run this plugin, you need to acquire a Client ID and Client Secret. <br />
    You can do so at <a href="http://soundcloud.com/you/apps/" target="_blank">http://soundcloud.com/you/apps/</a>.<br /><br />
    You must set your App\'s Redirect URI to <b>http://path-to-your-elgg-installation/sounds/authorize/</b><br /><br />';

$client_id_label = 'Your Client ID';
$client_id = elgg_view('input/text', array(
    'name' => 'params[client_id]',
    'value' => $vars['entity']->client_id,
        ));

$client_secret_label = 'Client Secret';
$client_secret = elgg_view('input/text', array(
    'name' => 'params[client_secret]',
    'value' => $vars['entity']->client_secret,
        ));

$settings = <<<__HTML

    <h3>SoundCloud</h3>
    <div>
        <p>$api_intro</p>
        <p><i>$client_id_label</i><br>$client_id</p>
        <p><i>$client_secret_label</i><br>$client_secret</p>
    </div>
    <hr>
</div>
__HTML;

echo $settings;