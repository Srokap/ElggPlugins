<?php

/* hypeSound
 *
 * SoundCloud Integration for Elgg
 * @package hypeJunction
 * @subpackage hypeSound
 *
 * @author Ismayil Khayredinov <ismayil.khayredinov@gmail.com>
 * @copyright Copyrigh (c) 2011, Ismayil Khayredinov
 */

elgg_register_event_handler('init', 'system', 'hj_sound_init');

function hj_sound_init() {

    $plugin = 'hypeSound';

    $client_id = elgg_get_plugin_setting('client_id', 'hypeSound');
    $client_secret = elgg_get_plugin_setting('client_secret', 'hypeSound');

    if (!$client_id || !$client_secret) {
        elgg_add_admin_notice('hj_sound_no_client_id', 'Please configure your SoundCloud settings before proceeding to use hypeSound');
        return true;
    } else {
        elgg_delete_admin_notice('hj_sound_no_client_id');
    }

    if (!elgg_is_active_plugin('hypeFramework')) {
        register_error(elgg_echo('hj:framework:disabled', array($plugin, $plugin)));
        disable_plugin($plugin);
    }

    $shortcuts = hj_framework_path_shortcuts($plugin);

    // Helper Classes
    elgg_register_classes($shortcuts['classes']);

    elgg_register_library('hj:sound:exception', $shortcuts['lib'] . 'vendors/soundcloud/Exception.php');
    elgg_register_library('hj:sound:version', $shortcuts['lib'] . 'vendors/soundcloud/Version.php');
    elgg_load_library('hj:sound:exception');
    elgg_load_library('hj:sound:version');

    elgg_register_library('hj:sound:base', $shortcuts['lib'] . 'sound/base.php');
    elgg_load_library('hj:sound:base');

    elgg_register_menu_item('site', array(
        'name' => 'sounds',
        'text' => elgg_echo('hj:sound:sounds'),
        'href' => 'sounds/all'
    ));

    elgg_register_page_handler('sounds', 'hj_sound_page_handler');

    elgg_register_action('sound/deauthorize', $shortcuts['actions'] . 'hj/sound/deauthorize.php');
    elgg_register_action('sound/import_me', $shortcuts['actions'] . 'hj/sound/import_me.php');
    elgg_register_action('sound/import', $shortcuts['actions'] . 'hj/sound/import.php');

    elgg_register_plugin_hook_handler('register', 'menu:soundcloud', 'hj_sound_user_menu');
    elgg_register_plugin_hook_handler('register', 'menu:owner_block', 'hj_sound_owner_block_menu');

    $user = elgg_get_logged_in_user_entity();

    if ($user->soundcloud_accessToken) {
        elgg_register_widget_type('tracks', elgg_echo('hj:sound:widget:tracks'), elgg_echo('hj:sound:widget:tracks:description'), 'profile');
        elgg_register_widget_type('playlists', elgg_echo('hj:sound:widget:playlists'), elgg_echo('hj:sound:widget:tracks:description'), 'profile');
        elgg_register_widget_type('favorite_tracks', elgg_echo('hj:sound:widget:favorites'), elgg_echo('hj:sound:widget:favorites:description'), 'profile');
    }
}

function hj_sound_page_handler($page) {
    $type = elgg_extract(0, $page, 'all');


    $plugin = "hypeSound";
    $shortcuts = hj_framework_path_shortcuts($plugin);
    $pages = $shortcuts['pages'] . 'sounds/';
    elgg_push_breadcrumb(elgg_echo('hj:sound:sounds'));

    if ($type == "authorize") {
        $user = elgg_get_logged_in_user_entity();
        $accessCode = get_input('code');

        $soundcloud = hj_sound_new_soundcloud_object();
        $accessToken = $soundcloud->accessToken($accessCode);

        if ($accessToken) {
            $user->soundcloud_accessToken = $accessToken['access_token'];
            system_message(elgg_echo('hj:sound:usercontent:accesstoken:success'));
        } else {
            register_error(elgg_echo('hj:sound:usercontent:accesstoken:error'));
        }

        $type = 'owner';
        $page[1] = $user->username;

        forward("sounds/owner/$user->username");
    }

    switch ($type) {
        default :
            include "{$pages}all.php";
            return true;
            break;

        case "owner" :
            $username = $page[1];
            set_input('username', $username);

            $section = elgg_extract(2, $page, 'tracks');
            set_input('section', $section);

            $user = get_user_by_username($username);
            elgg_set_page_owner_guid($user->guid);

            include "{$pages}owner.php";
            return true;
            break;
    }
    return false;
}

function hj_sound_user_menu($type, $hook, $return, $params) {
    $user = elgg_extract('entity', $params, false);
    $handler = elgg_extract('handler', $params, 'owner');

    if ($handler == 'all') {
        $all = array(
            'name' => 'all',
            'text' => elgg_echo('hj:sound:sitecontent:all'),
            'href' => "sounds/all",
            'is_action' => false,
            'priority' => 100
        );
        $return[] = ElggMenuItem::factory($all);

        $logged = elgg_get_logged_in_user_entity();
        if ($logged) {
            $mine = array(
                'name' => 'mine',
                'text' => elgg_echo('hj:sound:sitecontent:mine'),
                'href' => "sounds/owner/{$logged->username}",
                'is_action' => false,
                'priority' => 100
            );
            $return[] = ElggMenuItem::factory($mine);
        }
    } else {
        $tracks = array(
            'name' => 'tracks',
            'text' => elgg_echo('hj:sound:usercontent:tracks'),
            'href' => "sounds/owner/$user->username/tracks",
            'is_action' => false,
            'priority' => 100
        );
        $return[] = ElggMenuItem::factory($tracks);

        $playlists = array(
            'name' => 'playlists',
            'text' => elgg_echo('hj:sound:usercontent:playlists'),
            'href' => "sounds/owner/$user->username/playlists",
            'is_action' => false,
            'priority' => 300
        );
        $return[] = ElggMenuItem::factory($playlists);

        $favorites = array(
            'name' => 'favorites',
            'text' => elgg_echo('hj:sound:usercontent:favorites'),
            'href' => "sounds/owner/$user->username/favorites",
            'is_action' => false,
            'priority' => 500
        );
        $return[] = ElggMenuItem::factory($favorites);
    }
    return $return;
}

function hj_sound_owner_block_menu($hook, $type, $return, $params) {
    if (elgg_instanceof($params['entity'], 'user')) {
        $url = "sounds/owner/{$params['entity']->username}";
        $return[] = new ElggMenuItem('sounds', elgg_echo('hj:sounds:menu:owner_block'), $url);
        return $return;
    }
    return false;
}