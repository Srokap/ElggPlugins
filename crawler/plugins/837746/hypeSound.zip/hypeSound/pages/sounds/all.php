<?php

$section = get_input('section');

$user = elgg_get_logged_in_user_entity();

$title = elgg_echo('hj:sound:page:all');
elgg_push_breadcrumb($title);

$content = elgg_list_entities(array(
    'types' => 'object',
    'subtypes' => array('track', 'playlist', 'favorite_track'),
    'limit' => 10,
    'pagination' => true
        ));

$sidebar = elgg_view('hj/sound/sidebar');
$module = elgg_view_module('aside', $title, $content);

$content = elgg_view_layout('hj/profile', array(
    'content' => $module,
    'sidebar' => $sidebar,
        ));

$body = elgg_view_layout('one_column', array('content' => $content));

echo elgg_view_page($title, $body);
