<?php

$username = get_input('username');
$owner = get_user_by_username($username);
$section = get_input('section');

if (!$owner) {
    return false;
}
$user = elgg_get_logged_in_user_entity();

$title = elgg_echo('hj:sound:page:owner', array($owner->name));
elgg_push_breadcrumb($title);

if (!$owner->soundcloud_accessToken && $owner->canEdit()) {
    $content = elgg_view('hj/sound/auth_form', array('entity' => $owner));
} else {
    $content = elgg_view('hj/sound/sounds_list', array('entity' => $owner, 'section' => $section));
    $stats = elgg_view('hj/sound/stats', array('entity' => $owner));
    $content = elgg_view_layout('hj/dynamic', array('content' => array($content, $stats), 'grid' => array('8', '4')));
}

$sidebar = elgg_view('hj/sound/sidebar', $params);
$module = elgg_view_module('aside', $title, $content);

$content = elgg_view_layout('hj/profile', array(
    'content' => $module,
    'sidebar' => $sidebar,
        ));

$body = elgg_view_layout('one_column', array('content' => $content));

echo elgg_view_page($title, $body);
