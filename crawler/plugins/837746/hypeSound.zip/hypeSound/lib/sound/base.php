<?php

function hj_sound_new_soundcloud_object() {
    $siteURL = elgg_get_config('url');
    $callbackURL = "{$siteURL}sounds/authorize/";
    $client_id = elgg_get_plugin_setting('client_id', 'hypeSound');
    $client_secret = elgg_get_plugin_setting('client_secret', 'hypeSound');

    $soundcloud = new hjSound($client_id, $client_secret, $callbackURL);

    return $soundcloud;
}

function hj_sound_get_user_details_from_soundcloud($user = null) {
    $soundcloud = hj_sound_new_soundcloud_object();

    if (!$user) {
        $user = elgg_get_logged_in_user_entity();
    }

    $accessToken = $user->soundcloud_accessToken;

    $user_data = json_decode($soundcloud->get('me', array('oauth_token' => $accessToken)), true);
    foreach ($user_data as $key => $value) {
        $meta = "soundcloud_$key";
        $user->$meta = $value;
    }

    return true;
}

function hj_sound_get_user_resources_from_soundcloud($user = null, $subtype = 'track') {
    $soundcloud = hj_sound_new_soundcloud_object();

    if (!$user) {
        $user = elgg_get_logged_in_user_entity();
    }

    $accessToken = $user->soundcloud_accessToken;

    switch ($subtype) {
        default :
            $url = "me/tracks";
            break;

        case "playtlist" :
            $url = "me/playlists";
            break;

        case "favorite_track" :
            $url = "me/favorites";
            break;
    }
    $resources = json_decode($soundcloud->get($url, array('oauth_token' => $accessToken)), true);

    if ($resources) {
        foreach ($resources as $resource) {
            $guid = hj_sound_resource_exists($resource['id'], $subtype, $user);
            if (!$guid) {
                $obj = new ElggObject();
                $obj->subtype = $subtype;
                $obj->owner_guid = $user->guid;
                $obj->access_id = ACCESS_PUBLIC;
                foreach ($resource as $key => $value) {
                    $obj->$key = $value;
                }
                if ($new_guid = $obj->save()) {
                    add_to_river('river/soundcloud', 'create', $user->guid, $new_guid);
                }
            }
        }
    }
    return true;
}

function hj_sound_resource_exists($resource_id, $subtype = 'track', $user = null) {
    $resource = elgg_get_entities_from_metadata(array(
        'type' => 'object',
        'subtype' => $subtype,
        'owner_guid' => $user->guid,
        'limit' => 1,
        'metadata_name' => 'id',
        'metadata_value' => $resource_id
            ));
    if ($resource) {
        $resource = $resource[0];
        return $resource->guid;
    }
    return null;
}