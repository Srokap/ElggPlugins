<?php

$user = elgg_get_logged_in_user_entity();

$user->soundcloud_accessToken = null;
$user->soundcloud_id = null;

system_message(elgg_echo('hj:sound:usercontent:deauthorize:success'));
forward(REFERER);
