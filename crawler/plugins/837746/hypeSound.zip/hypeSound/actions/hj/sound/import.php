<?php

elgg_load_library('hj:sound:base');

$subtype = get_input('subtype');

hj_sound_get_user_resources_from_soundcloud(null, $subtype);

forward(REFERER);
