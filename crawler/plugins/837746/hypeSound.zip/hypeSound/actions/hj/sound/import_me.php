<?php

elgg_load_library('hj:sound:base');

hj_sound_get_user_details_from_soundcloud();
hj_sound_get_user_resources_from_soundcloud(null, 'track');
hj_sound_get_user_resources_from_soundcloud(null, 'playlist');
hj_sound_get_user_resources_from_soundcloud(null, 'favorite_track');

forward(REFERER);
