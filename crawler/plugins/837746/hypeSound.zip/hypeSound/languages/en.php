<?php

$english = array(

    'hj:sound:sounds' => 'Sounds',
    'hj:sound:page:owner' => '%s\'s Sounds',
    'hj:sound:usercontent:noaccesstoken' => 'This user has no sounds yet',
    'hj:sound:usercontent:accesstoken:success' => 'You have successfully authorized your SoundCloud account',
    'hj:sound:usercontent:accesstoken:error' => 'There was a problem with authorizing your SoundCloud account',
    'hj:sound:usercontent:stats'  => 'SoundCloud Stats',
    'hj:sound:usercontent:importpersonaldata' => 'Import Stats',
    'hj:sound:usercontent:importtracks' => 'Import Tracks',
    'hj:sound:usercontent:importplaylists' => 'Import Playlists',
    'hj:sound:usercontent:importfavorites' => 'Import Favorite Tracks',
    'hj:sound:usercontent:refreshpersonaldata' => 'Refresh',
    'hj:sound:usercontent:deauthorize' => 'Deauthorize SoundCloud',
    'hj:sound:usercontent:deauthorize:success' => 'Your account has been successfully deauthorized',

    'hj:sound:auth:intro' => 'Weather at SoundCloud is sunny, as usual. Let\'s get started! Click on the image below to authorize your SoundCloud account',

    'hj:sound:usercontent:track_count' => 'Tracks',
    'hj:sound:usercontent:playlist_count' => 'Playlists',
    'hj:sound:usercontent:followers_count' => 'Followers',
    'hj:sound:usercontent:public_favorites_count' => 'Favorite Tracks',

    'hj:sound:usercontent:tracks' => 'Tracks',
    'hj:sound:usercontent:playlists' => 'Playlists',
    'hj:sound:usercontent:favorites' => 'Favorite Tracks',

    'hj:sound:widget:favorites' => 'Favorite Tracks',
    'hj:sound:widget:tracks' => 'My Tracks',
    'hj:sound:widget:playlists' => 'My Playlists',

    'hj:sound:moretracks' => 'More Tracks',
    'hj:sound:moreplaylists' => 'More Playlists',

    'hj:sound:page:all' => 'All Sounds',
    'hj:sound:sitecontent:mine' => 'My Sounds',
    'hj:sound:sitecontent:all' => 'All Site Sounds',

    'hj:sounds:menu:owner_block' => 'Sounds',

    'river:create:object:favorite_track' => '%s imported a new favorite track from SoundCloud | %s',
    'river:create:object:track' => '%s imported a new track from SoundCloud | %s',
    'river:create:object:playlist' => '%s imported a new playlist from SoundCloud | %s',
);


add_translation("en", $english);
?>