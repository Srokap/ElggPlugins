hypeSound is part of the hypeJunction plugin bundle

============
www.hypeJunction.com
hypeJunction is here for you to connect, innovate, integrate, collaborate and indulge.
hypeJunction is a bundle of plugins that will help you kick start your Elgg-based social network and spice it up with cool features and functionalities.
============

PLUGIN DESCRIPTION
------------------
hypeSound provides a bridge between SoundCloud.com and Elgg.

Main Features include:
- Authorize your Elgg application at SoundCloud via oAuth
- Elgg users can import SoundCloud profile data (all information is stored in the DB, only limited information is displayed; can be accessed via $user->soundcloud_{property_name})
- Elgg users can import their tracks, playlists and favorite tracks from SoundCloud
- New imports are added to the river
- Profile widgets with Latest Tracks, Playlists and Favorite Tracks

REQUIREMENTS
------------
1) Elgg 1.8.3+
2) hypeFramework 1.8.5+

INTEGRATION / COMPATIBILITY
---------------------------


INSTALLATION
------------
1. Upload and enable hypeFramework
2. Place hypeSound below hypeFramework and enable
3. Register your application with SoundCloud and enter required Client Id and Client Secret into the plugin settings

UPGRADING FROM PREVIOUS VERSION
-------------------------------
-- Disable all hype plugins, except hypeFramework
-- Disable hypeFramework
-- Backup your database and files
-- Remove all hype plugins from your server and upload the new version
-- Enable hypeFramework
-- Enable other hype plugins

USER GUIDE
----------


NOTES / WARNINGS
----------------
- Import operations might be lengthy and users may encounter php timeouts if the import queue is too long
- This will conflict with any other plugin using SimpleOEmbed PHP class (if you encounter such conflicts, remove SimpleOEmbed.php from classes folder)

TODO
----
- Allow users to add tracks to SoundCloud favorites
- Look into a possibility of exporting/importing groups
- Look into a possibility of friending SoundCloud followers/followees
- Allow users to upload Elgg files to SoundCloud


BUG REPORTS
-----------
Bugs and feature requests can be submitted at:
http://hypeJunction.com/trac

