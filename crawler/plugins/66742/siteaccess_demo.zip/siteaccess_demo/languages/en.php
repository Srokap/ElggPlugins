<?php

	$english = array(
	  'siteaccess:demo:register:dob' => 'Date of Birth',
	  'siteaccess:demo:register:checkbox' => 'Check this box to register',
	  'siteaccess:demo:login:checkbox' => 'Check here',
	  'siteaccess:demo:register:error' => 'You must select the checkbox to register or you did not enter your date of birth!',
	  'siteaccess:demo:login:error' => 'You must select the checkbox to login!'
	);
	
	add_translation("en",$english);
?>