<?php
  echo elgg_view('input/checkboxes' , array('internalname' => 'login_checkbox', 'options' => array(elgg_echo('siteaccess:demo:login:checkbox')), 'value' => '1', 'class' => "general-textarea"))
?>