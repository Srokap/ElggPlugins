<script type="text/javascript">
$(document).ready(function () {
  $("#datepicker").datepicker();
});
</script>

<p>
<?php
  echo elgg_view('input/checkboxes' , array('internalname' => 'register_checkbox', 'options' => array(elgg_echo('siteaccess:demo:register:checkbox')), 'value' => '1', 'class' => "general-textarea"));
?>
</p>

<p><label>Date of Birth</label> <input id="datepicker" name="datepicker" type="text" class="general-textarea"></p>



