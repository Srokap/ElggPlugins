<?php 
	echo elgg_view('css/elgg');
?>