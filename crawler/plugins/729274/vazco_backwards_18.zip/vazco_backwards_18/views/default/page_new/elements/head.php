<?php 
	echo elgg_view('page/elements/head', $vars);
?>