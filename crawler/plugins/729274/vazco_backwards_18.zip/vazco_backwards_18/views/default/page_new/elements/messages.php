<?php 
	echo elgg_view('page/elements/messages', $vars);
?>