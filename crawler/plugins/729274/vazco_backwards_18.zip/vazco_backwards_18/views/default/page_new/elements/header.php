<?php 
	echo elgg_view('page/elements/header', $vars);
?>