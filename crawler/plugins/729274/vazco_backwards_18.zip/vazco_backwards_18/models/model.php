<?php

if (!function_exists('elgg_register_action')){
	function elgg_register_action($action, $filename = "", $public = false, $admin_only = false) {
		return register_action($action, $public, $filename, $admin_only);
	}
}

if (!function_exists('elgg_register_event_handler')){
	function elgg_register_event_handler($event, $object_type, $function) {
		return register_elgg_event_handler($event, $object_type, $function);
	}
}

if (!function_exists('elgg_is_active_plugin')){
	function elgg_is_active_plugin($plugin, $site_guid = 0) {
		return is_plugin_enabled($plugin, $site_guid);
	}
}
if (!function_exists('elgg_get_metadata')){
	function elgg_get_metadata($options){
		$guid = $options['guid'];
		return get_metadata_for_entity($guid);
	}
}
if (!function_exists('elgg_unregister_menu_item')){
	function elgg_unregister_menu_item($type, $options) {
		return true;
	}
}

if (!function_exists('elgg_view_image_block')){
	function elgg_view_image_block($icon, $info, $vars = array()) {
		return elgg_view_listing($icon, $info);
	}
}

if (!function_exists('elgg_get_page_owner_guid')){
	function elgg_get_page_owner_guid() {
		return page_owner();
	}
}


if (!function_exists('elgg_register_page_handler')){
	function elgg_register_page_handler($handler, $function) {
		return register_page_handler($handler, $function);
	}
}

if (!function_exists('elgg_set_context')){
	function elgg_set_context($context) {
		return set_context($context);
	}
}
if (!function_exists('elgg_register_plugin_hook_handler')){
	function elgg_register_plugin_hook_handler($hook, $entity_type, $function){
		register_plugin_hook($hook, $entity_type, $function);
	}
}


/**
 * Trigger a Plugin Hook and run all handler callbacks registered to that hook:type.
 *
 * This function runs all handlers regsitered to $hook, $type or
 * the special keyword 'all' for either or both.
 *
 * Use $params to send additional information to the handler callbacks.
 *
 * $returnvalue Is the initial value to pass to the handlers, which can
 * then change it.  It is useful to use $returnvalue to set defaults.
 * If no handlers are registered, $returnvalue is immediately returned.
 *
 * $hook is usually a verb: import, get_views, output.
 *
 * $type is usually a noun: user, ecml, page.
 *
 * @tip Like Elgg Events, $hook and $type can use the special keyword 'all'.
 * Handler callbacks registered with $hook = all will be called for all hooks
 * of type $type.  Similarly, handlers registered with $type = all will be
 * called for all hooks of type $event, regardless of $object_type.  If $hook
 * and $type both are 'all', the handler will be called for all hooks.
 *
 * @internal The checks for $hook and/or $type not being equal to 'all' is to
 * prevent a plugin hook being registered with an 'all' being called more than
 * once if the trigger occurs with an 'all'. An example in core of this is in
 * actions.php:
 * elgg_trigger_plugin_hook('action_gatekeeper:permissions:check', 'all', ...)
 *
 * @see elgg_register_plugin_hook_handler()
 *
 * @param string $hook        The name of the hook to trigger ("all" will
 *                            trigger for all $types regardless of $hook value)
 * @param string $type        The type of the hook to trigger ("all" will
 *                            trigger for all $hooks regardless of $type value)
 * @param mixed  $params      Additional parameters to pass to the handlers
 * @param mixed  $returnvalue An initial return value
 *
 * @return mixed|null The return value of the last handler callback called
 *
 * @example hooks/trigger/basic.php    Trigger a hook that determins if execution
 *                                     should continue.
 * @example hooks/trigger/advanced.php Trigger a hook with a default value and use
 *                                     the results to populate a menu.
 * @example hooks/basic.php            Trigger and respond to a basic plugin hook.
 * @link http://docs.elgg.org/Tutorials/Plugins/Hooks
 *
 * @since 1.8.0
 */
if (!function_exists('elgg_trigger_plugin_hook')){
function elgg_trigger_plugin_hook($hook, $type, $params = null, $returnvalue = null) {
	global $CONFIG;

	$hooks = array();
	if (isset($CONFIG->hooks[$hook][$type])) {
		if ($hook != 'all' && $type != 'all') {
			$hooks[] = $CONFIG->hooks[$hook][$type];
		}
	}
	if (isset($CONFIG->hooks['all'][$type])) {
		if ($type != 'all') {
			$hooks[] = $CONFIG->hooks['all'][$type];
		}
	}
	if (isset($CONFIG->hooks[$hook]['all'])) {
		if ($hook != 'all') {
			$hooks[] = $CONFIG->hooks[$hook]['all'];
		}
	}
	if (isset($CONFIG->hooks['all']['all'])) {
		$hooks[] = $CONFIG->hooks['all']['all'];
	}

	foreach ($hooks as $callback_list) {
		if (is_array($callback_list)) {
			foreach ($callback_list as $hookcallback) {
				$args = array($hook, $type, $returnvalue, $params);
				$temp_return_value = call_user_func_array($hookcallback, $args);
				if (!is_null($temp_return_value)) {
					$returnvalue = $temp_return_value;
				}
			}
		}
	}

	return $returnvalue;
}
}

if (!function_exists('elgg_get_plugin_setting')){
	function elgg_get_plugin_setting($name, $plugin_id = "") {
		return get_plugin_setting($name, $plugin_id);
	}
}

if (!function_exists('elgg_get_logged_in_user_entity')){
	function elgg_get_logged_in_user_entity() {
		return get_loggedin_user();
	}
}

if (!function_exists('elgg_is_admin_logged_in')){
	function elgg_is_admin_logged_in() {
		return isadminloggedin();
	}
}

if (!function_exists('elgg_view_page')){
	function elgg_view_page($title, $body, $page_shell = 'default', $vars = array()) {
		$messages = null;
		if (count_messages()) {
			// get messages - try for errors first
			$messages = system_messages(NULL, "error");
			if (count($messages["error"]) == 0) {
				// no errors so grab rest of messages
				$messages = system_messages(null, "");
			} else {
				// we have errors - clear out remaining messages
				system_messages(null, "");
			}
		}

		$vars['title'] = $title;
		$vars['body'] = $body;
		$vars['sysmessages'] = $messages;
		
		// check for deprecated view
		if ($page_shell == 'default' && elgg_view_exists('pageshells/pageshell')) {
			global $CONFIG;
			$vars['config'] = $CONFIG;
			$output = elgg_view('pageshells/pageshell', $vars);
		} else {
			$output = elgg_view("page/$page_shell", $vars);
		}

		$vars['page_shell'] = $page_shell;

		// Allow plugins to mod output
		
		return elgg_trigger_plugin_hook('output', 'page', $vars, $output);
	}
}

if (!function_exists('elgg_register_menu_item')){
	function elgg_register_menu_item($menu_name, $menu_item){
		if ($menu_name == 'site'){
			add_menu($menu_item['name'], $menu_item['href'], '', $menu_item['contexts']);
		}else{
			add_submenu_item($menu_item['name'], $menu_item['href'], $menu_item['contexts'], '', false);
		}
	}
}

if (!function_exists('elgg_get_context')){
	function elgg_get_context() {
		global $CONFIG;
	
		if (!$CONFIG->context) {
			return null;
		}
	
		return $CONFIG->context[count($CONFIG->context) - 1];
	}
}

?>