<?php //ł ?><?php
$english = array(
	//general
	'vazco_backwards_18:menu:title'	=> '',



);

add_translation("en",$english
 	
			
);
?>