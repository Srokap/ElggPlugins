<?php //ł ?><?php
$polish = array(
	//general
	'vazco_backwards_18:menu:title'	=> '',



);

add_translation("pl",$polish);
?>