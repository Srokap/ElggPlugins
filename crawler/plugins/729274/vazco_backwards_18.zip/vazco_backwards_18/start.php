<?php //ł ?><?php
/*******************************************************************************
 * vazco_backwards_18
 *
 * @author Michal Zacher, Elggdev, Elggdev
 * @copyright Elggdev
 * @licence per-site commercial licence: http://elggdev.com/pg/license
 ******************************************************************************/

 	require_once(dirname(__FILE__)."/models/model.php");

	function vazco_backwards_18_init(){
		global $CONFIG;
		elgg_extend_view('css','vazco_backwards_18/css');
		elgg_extend_view('page_elements/footer','page_new/elements/footer');
		elgg_extend_view('page_elements/header','page_new/elements/header');
		elgg_extend_view('metatags','page_new/elements/head');
		elgg_extend_view('css','css_new/elgg');
		elgg_extend_view('css','vazco_backwards_18/css');
		elgg_extend_view('pageshells/pageshell','page_new/default');
		elgg_extend_view('page_elements/header','page_new/elements/messages');
			

		register_page_handler('backwards','vazco_backwards_18_page_handler');
		register_elgg_event_handler('pagesetup','system','vazco_backwards_18_pagesetup');
		return true;
	}

	function vazco_backwards_18_page_handler($page){
		global $CONFIG;
		
		return true;
	}

	register_elgg_event_handler('init', 'system', 'vazco_backwards_18_init');
?>