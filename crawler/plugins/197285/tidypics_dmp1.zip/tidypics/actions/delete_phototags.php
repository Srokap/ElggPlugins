<?php

	/**
	 * Elgg file delete
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	//if not logged in, see world pictures instead
	gatekeeper();
	
	$guid = (int) get_input('file');
	$forward_url	= $_SERVER['HTTP_REFERER'];//forward to world pictures if there is an unknown error

	if ($photoObject = get_entity($guid)) 
	{
		if ($photoObject->canEdit()) 
		{
			if($photoObject->clearAnnotations('phototag'))
			{
				system_message(elgg_echo("phototags:deleted"));
			}else
			{
				register_error(elgg_echo("phototags:deletefailed"));
			}
		}
	}
		
	forward($forward_url);

?>