<?php
	/**
	 * Elgg image  uploader action
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	global $CONFIG;
	
	
	// Get variables
	//$title = get_input("title");
	$desc = get_input("description");
	$tags = get_input("tags");
	$access_id = (int) get_input("access_id");
	$mime = $_FILES['upload']['type'];
	$container_guid = (int) get_input('container_guid', 0);
	if (!$container_guid)
		$container_guid == $_SESSION['user']->getGUID();

	//make sure this is an image
	if($mime != 'image/jpeg' && $mime != 'image/gif' && $mime != 'image/png' && $mime != 'image/pjpeg')
	{
		register_error(elgg_echo('image:notimage'));	
		forward($CONFIG->wwwroot . 'pg/photos/upload/' .$container_guid);
		die();
	}		

	//this will save to users folder in /image/ and organize by photo album
	$prefix = "image/$container_guid/";
	$file = new FilePluginFile();
	$filestorename = strtolower(time().$_FILES['upload']['name']);
	$file->setFilename($prefix.$filestorename);
	$file->setMimeType($_FILES['upload']['type']);
	
	$file->originalfilename = $_FILES['upload']['name'];
	
	$file->subtype="image";
	
	$file->access_id = $access_id;
	
	$file->open("write");
	$file->write(get_uploaded_file('upload'));
	$file->close();
	
	//$file->title = $title;
	$file->description = $desc;
	if ($container_guid)
		$file->container_guid = $container_guid;
	
	// Save tags
	$tags = explode(",", $tags);
	$file->tags = $tags;
	
	// i may not need this - i think its only for searching based on type (in file plugin)
	//$file->simpletype = 'image';
	
	$result = $file->save();

		if ($result)
		{		
			// Generate thumbnail
			$thumbnail = get_resized_image_from_existing_file($file->getFilenameOnFilestore(),60,60, true);
			$thumbsmall = get_resized_image_from_existing_file($file->getFilenameOnFilestore(),153,153, true);
			$thumblarge = get_resized_image_from_existing_file($file->getFilenameOnFilestore(),600,600, false);
			if ($thumbnail) {
				$thumb = new ElggFile();
				$thumb->setMimeType($_FILES['upload']['type']);
				
				$thumb->setFilename($prefix."thumb".$filestorename);
				$thumb->open("write");
				$thumb->write($thumbnail);
				$thumb->close();				
				$file->thumbnail = $prefix."thumb".$filestorename;
				
				$thumb->setFilename($prefix."smallthumb".$filestorename);
				$thumb->open("write");
				$thumb->write($thumbsmall);
				$thumb->close();
				$file->smallthumb = $prefix."smallthumb".$filestorename;
				
				$thumb->setFilename($prefix."largethumb".$filestorename);
				$thumb->open("write");
				$thumb->write($thumblarge);
				$thumb->close();
				$file->largethumb = $prefix."largethumb".$filestorename;
					
			}

		}
		
	if ($result)
		system_message(elgg_echo("image:saved"));
	else
		register_error(elgg_echo("image:uploadfailed"));
		
	forward($CONFIG->wwwroot . 'pg/photos/album/' .$container_guid);

?>