<?php

	/**
	 * Elgg file delete
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$guid = (int) get_input('file');
	if ($file = get_entity($guid)) 
	{

		if ($file->canEdit()) 
		{
			
			$subtype = $file->getSubtype();
			$container = get_entity($file->container_guid);
				
			if($subtype == 'image'){
				
				$forward_url = $container->getURL();
			  
				$thumbnail = $file->thumbnail;
				$smallthumb = $file->smallthumb;
				$largethumb = $file->largethumb;
				if ($thumbnail) {

					$delfile = new ElggFile();
					$delfile->owner_guid = $file->owner_guid;
					$delfile->setFilename($thumbnail);
					$delfile->delete();

				}
				if ($smallthumb) {

					$delfile = new ElggFile();
					$delfile->owner_guid = $file->owner_guid;
					$delfile->setFilename($smallthumb);
					$delfile->delete();

				}
				if ($largethumb) {

					$delfile = new ElggFile();
					$delfile->owner_guid = $file->owner_guid;
					$delfile->setFilename($largethumb);
					$delfile->delete();

				}
				
			}
			else{
			  ///--------------------deleting an album 
				$forward_url = 'pg/photos/owned/' . $container->username;
				
				//get all the images from this album 
				$images = get_entities("object","image", $guid, '', 999);
				/*
				deletes the image entities, but not the actual images
				 i dont think delete() is stable yet. make sure to check that it deletes
				 metadata/annotations/comments/ associated with the entity
				*/
				foreach($images as $im){
					$im->delete();
				}
			
			}
		
			if (!$file->delete()) {
					register_error(elgg_echo("file:deletefailed"));
				} else {
					system_message(elgg_echo("file:deleted"));
				}
		}
		else 
		{			
			$container = $_SESSION['user'];
			register_error(elgg_echo("file:deletefailed"));			
		}

	}
	else 
	{
		register_error(elgg_echo("file:deletefailed"));			
	}
		
	forward($forward_url);

?>