<?php
/*
	$entity_guid = get_input('file_guid',0);
	$file = get_entity($entity_guid );
	
	if(!empty($entity_guid))
	{
?>

	<div id="tidypics_controls">
		<h3> <?= elgg_echo('image:tools') ?></h3>
		<ul>
			<li class="item-tag"><a href="javascript:void(0)" onclick="showInfoTag()"><?= elgg_echo('image:tagthisphoto') ?></a></li>
			<li class="item-download"><a target="_new" href="<?php echo $vars['url']; ?>action/tidypics/download?file_guid=<?php echo $file->getGUID(); ?>"><?php echo elgg_echo("image:download"); ?></a></li>
			
			<?php if ($file->canEdit()): 
				//If is owner or admin
			?>
					
					<li class="item-edit"><a href="<?php echo $vars['url']; ?>mod/tidypics/edit.php?file_guid=<?php echo $file->getGUID(); ?>"><?php echo elgg_echo('image:edit'); ?></a></li> 
					<li class="item-remove"><?php echo elgg_view('output/confirmlink',array(
							'href' => $vars['url'] . "action/tidypics/delete?file=" . $file->getGUID(),
							'class' => 'item-remove',
							'text' => elgg_echo("image:delete"),
							'confirm' => elgg_echo("image:delete:confirm"),
					)) . "</li>";
					
			endif;	?>
	</ul>
</div>


	
<?php	
		$photo_tags = get_annotations($entity_guid,'object','image','phototag','',0,20,0);
		
		if ($photo_tags)
		{
?>	
			<div id="tidypics_phototags">
				<h3> <?= elgg_echo('image:inthisphoto') ?></h3>
				<ul>
<?php
			$users = array();
			$objects = array();
			
			if ($photo_tags) foreach ($photo_tags as $photo_tag)
			{
				$data_tag = unserialize($photo_tag->value);
				
				$name = "";
				
				$object = new stdClass();
				
				if($data_tag->type == 'user')
				{
					$data_tag->data = get_entity($data_tag->value);
					$object->img = elgg_view("profile/icon",array('entity' => $data_tag->data, 'size' => 'topbar',  'override' => true));
					$object->name = $data_tag->data->name;
					$object->rel = $data_tag->data->getUrl();
				}else
				{
					$data_tag->data = $data_tag->value;
					$object->img = "<img border='0' title='object' src='{$vars['url']}mod/tidypics/graphics/tag_yellow.png' />";
					$object->name = $data_tag->data;
					$object->rel = "#";
				}
				
				$object->html = "<li><a class='phototag-links' href='{$object->rel}' rel='{$photo_tag->id}'>$object->img<span>{$object->name}</span></a></li>";
				
				if($data_tag->type == 'user')
					$users[] = $object;
					
				else
					$objects[] = $object;
			}
			
			if(!empty($users)) foreach ($users as $user)
				echo $user->html;
				
			if(!empty($objects)) foreach ($objects as $object)
				echo $object->html;
			
?>
			</ul>
		</div>
<?php		
		}
	}
*/
?>