<?php
	/**
	 * Elgg file browser uploader
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */
	global $CONFIG;
	
	//this is for image uploads only. Image edits are handled by edit.php form
	
		$container_guid = get_input('container_guid');
		$access_id = get_entity($vars['album'])->access_id;

?>
<form action="<?php echo $vars['url']; ?>action/tidypics/upload" enctype="multipart/form-data" method="post">
		<p>
			<label><?php echo elgg_echo("image"); ?></label>
			<?php  echo elgg_view("input/file",array('internalname' => 'upload')); ?>
		</p>
			<label><?php echo elgg_echo("caption"); ?></label>
			<?php echo elgg_view("input/text",array("internalname" => "description","value" => $description));?>			
		<p>
			<label><?php echo elgg_echo("tags"); ?></label>
			<?php echo elgg_view("input/tags", array("internalname" => "tags","value" => $tags,));?>
		</p>
		
			<label><?php echo sprintf(elgg_echo('access'), 'image'); ?></label>
			<?php echo elgg_view('input/accessRead', array('internalname' => 'access_id','value' => $access_id)); ?>			
			
		<p>
			<?php				
				if ($container_guid)
					echo '<input type="hidden" name="container_guid" value="'.$container_guid.'" />';
	
			?>
			<input type="submit" value="<?php echo elgg_echo("save"); ?>" />
		</p>

</form>