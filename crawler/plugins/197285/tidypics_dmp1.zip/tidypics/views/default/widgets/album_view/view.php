<?php

	
	//the number of files to display
	$number = (int) $vars['entity']->num_display;
	if (!$number)
		$number = 5;
	
	$owner = page_owner_entity();	
	$owner_albums = get_entities("object", "album", page_owner(), $number);

	if ($owner_albums) {
			
    	echo '<div id="album_widget_container">';
        	 
		foreach($owner_albums as $album){
	
			//get album cover if one was set 
			if($album->cover)
				$album_cover = '<img src="'.$vars['url'].'mod/tidypics/thumbnail.php?file_guid='.$album->cover.'&size=small" border="0" class="album_cover"  alt="album cover"/>';
			else
				$album_cover = '<img src="'.$vars['url'].'mod/tidypics/graphics/img_error.jpg" class="album_cover" alt="new album">';

			?>
			<div class="album_widget_single_item">			
				<div class="album_widget_title"><a href="<?php echo $album->getURL();?>"><?php echo $album->title;?></a></div>
				<div class="album_widget_timestamp">created <?php echo friendly_time($album->time_created);?></div>
				<?php
				//get the number of comments
				$numcomments = elgg_count_comments($album);
				if ($numcomments)
					echo "<a href=\"{$album->getURL()}\">" . sprintf(elgg_echo("comments")) . " (" . $numcomments . ")</a><br>";
				?>
				<a href="<?php echo $album->getURL();?>"><?php echo $album_cover;?></a>
			</div>
		<?
		}
        	      	
        //get a link to the users album
        $users_album_url = $vars['url'] . "pg/photos/owned/" . $owner->username;
        echo "<a href=\"{$users_album_url}\">" . elgg_echo('album:more') . "</a>";
		echo "</div>";
        		
	} else {
		
		echo elgg_echo("album:none");
		
	}

?>