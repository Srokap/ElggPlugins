<?php
	/**
	 * Elgg file browser
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	
	$username = get_input('username');
	
	if(page_owner() == $_SESSION['guid'])
		$area2 = elgg_view_title($title = elgg_echo('album:yours:friends'));
	else
		$area2 = elgg_view_title($title = sprintf(elgg_echo('album:friends'), "$username"));
	
	set_context('search');
	set_input('search_viewtype', 'gallery');
	$area2 .= list_user_friends_objects(page_owner(), 'album');
	
	set_context('photos');
	$body = elgg_view_layout('two_column_left_sidebar', '', $area2);
	
	// Finally draw the page
	page_draw(sprintf(elgg_echo("album:friends"),$_SESSION['user']->name), $body);
?>