<?php

	/**
	 * Elgg file browser
	 * 
	 * @package ElggFile
	 * @author Nudge Digital
	 * @copyright Nudge Digital 2010
	 * @link http://www.nudgedigital.co.uk/
	 */
	
	
	// Initialization of the plugin.
	// We clear out all previously included CSS views that other plugins have put in (using elgg_extend_view)
	function custom_theme_init() {
		global $CONFIG;
		
		// For backward compatibility, we'll check if the elgg_extend_view() function exists (Elgg 1.7+) or the extend_view() function exists (Elgg 1.6.1 - Elgg 1.7)
		// *** extend_view may exist in previous version of Elgg as well.
		// *** We haven't used any previous versions though so to be safe, we've put 1.6.1 as min version
		if (function_exists('elgg_extend_view') || function_exists('extend_view')) {
			// As we see form the elgglib.php file in the elgg_extend_view() function, the views are saved in this array
			// Having our plugin run last means we can reset the array and then just use our own CSS file to extend the view
			if (isset($CONFIG->views->extensions['css'])) {
				// Clearing the actual array of views
				$CONFIG->views->extensions['css'] = array();
			}
			
			// Adding our CSS file. Add all your CSS to the {ELGG_ROOT}/mod/custom_theme/views/default/custom_theme/css.php file
			if (function_exists('elgg_extend_view')) {
				elgg_extend_view('css', 'custom_theme/css');
			} else if (function_exists('extend_view')) {
				extend_view('css', 'custom_theme/css');
			}
		}
	}
	
	// Register our initialization function. We put a huge priority number to ensure that it runs last and can clear out all existing CSS
	register_elgg_event_handler('init','system','custom_theme_init', 9999999999999);
	
?>