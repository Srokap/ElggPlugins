<?php
	
	/**
	 *	Magyar forditas.
	 *	A hibauzenetek nagy resze es az installacio szovegei nincsenek leforditva.
	 *	Ez utobbit amugy is csak a rendszeradminisztrator latja, ugyhogy jobb, ha angol marad szerintem.
	 *	
	 *	Elgg verzio: 1.5
	 *		 
	 *	History:
	 *
	 *	16-02-2009 22:35:42
	 *	Fixed a missing comma in the language file.
	 *		 	 	 
	 *	08-02-2009 16:32:08
	 *	Updated to Elgg 1.2, added language translations according to http://hu.wikipedia.org/wiki/ISO_639-1	 
	 *		 
	 *	25-04-2009 21:08:08
	 *	Updated to Elgg 1.5, modified the translations to be more user friendly and consistent	 
	 *		 
	 *	@author	bothy4g
	 *	@author	maschek (adam.maschek at gmail)
	 *	@author	balatonl (bl at mcse.hu)
	 *	@license	GPLv2	 
	 */

	$hungarian = array(

		/**
		 * Sites
		 */
	
			'item:site' => 'Site-ok',
	
		/**
		 * Sessions
		 */
			
			'login' => "Bejelentkezés",
			'loginok' => "Sikeres bejelentkezés.",
			'loginerror' => "Sikertelen bejelentkezés. Lehetséges oka, hogy nem erősítette meg a regisztrációját, a megadott adatai helytelenek, vagy egymás után többször próbálkozott sikertelenül a belépéssel. Kérjük, bizonyosodjon meg, hogy a bejelentkezési adatai helyesek, s próbálja újra.",
	
			'logout' => "Kijelentkezés",
			'logoutok' => "Sikeres kijelentkezés.",
			'logouterror' => "Sikertelen kijelentkezés. Kérem, próbálja újból.",
	
		/**
		 * Errors
		 */
			'exception:title' => "Köszöntjük az Elgg közösségépítő rendszerében.",
	
			'InstallationException:CantCreateSite' => "Nem sikerült az alapértelmezett ElggOldal létrehozása a szolgáltatott adatokkal: Név:%s, Url: %s",
		
			'actionundefined' => "A kért művelet (%s) nem értelmezett a rendszerben.",
			'actionloggedout' => "Kijelentkezett állapotban nem végezheti el ezt a műveletet.",
	
			'notfound' => "Az igényelt erőforrás nem található, vagy nincs hozzáférési joga.",
			
			'SecurityException:Codeblock' => "A kódblokk futtatása letiltva.",
			'DatabaseException:WrongCredentials' => "Sikertelen adatbáziskapcsolódás a megadott adatokkal.",
			'DatabaseException:NoConnect' => "Nem sikerült a(z) '%s' adatbázist kiválasztani. Kérem, ellenőrizze, hogy az adatbázis létezik és van hozzáférése.",
			'SecurityException:FunctionDenied' => "'%s' funkcióhoz való hozzáférés letiltva.",
			'DatabaseException:DBSetupIssues' => "Néhány gond merült fel: ",
			'DatabaseException:ScriptNotFound' => "A rendszer nem találta a(z) %s adatbázis szkriptet.",
			
			'IOException:FailedToLoadGUID' => "Nem sikerült az új  %s betöltése from GUID:%d",
			'InvalidParameterException:NonElggObject' => "Passing a non-ElggObject to an ElggObject constructor!",
			'InvalidParameterException:UnrecognisedValue' => "Unrecognised value passed to constuctor.",
			
			'InvalidClassException:NotValidElggStar' => "GUID:%d nem egy érvényes %s",
			
			'PluginException:MisconfiguredPlugin' => "%s helytelenül beállított plugin.",
			
			'InvalidParameterException:NonElggUser' => "Passing a non-ElggUser to an ElggUser constructor!",
			
			'InvalidParameterException:NonElggSite' => "Passing a non-ElggSite to an ElggSite constructor!",
			
			'InvalidParameterException:NonElggGroup' => "Passing a non-ElggGroup to an ElggGroup constructor!",
	
			'IOException:UnableToSaveNew' => "Nem sikerült az új %s mentése",
			
			'InvalidParameterException:GUIDNotForExport' => "GUID has not been specified during export, this should never happen.",
			'InvalidParameterException:NonArrayReturnValue' => "Entity serialisation function passed a non-array returnvalue parameter",
			
			'ConfigurationException:NoCachePath' => "Nincs cache(gyorstár) útvonal!",
			'IOException:NotDirectory' => "%s nem egy mappa(könyvtár).",
			
			'IOException:BaseEntitySaveFailed' => "Nem sikerült elmenteni az új objektum alapentitásának információit!",
			'InvalidParameterException:UnexpectedODDClass' => "import() passed an unexpected ODD class",
			'InvalidParameterException:EntityTypeNotSet' => "Az entitás típusát kötelező beállítani.",
			
			'ClassException:ClassnameNotClass' => "%s nem egy %s.",
			'ClassNotFoundException:MissingClass' => "'%s' osztály nem található, hiányzó plugin?",
			'InstallationException:TypeNotSupported' => " %s típus nem támogatott. Ez egy hibát jelöl a telepítésben, valószínű egy nem teljes rendszerfrissítés miatt.",

			'ImportException:ImportFailed' => "Nem sikerült %d elem importálása",
			'ImportException:ProblemSaving' => "Hiba lépett fel %s mentésekor",
			'ImportException:NoGUID' => "Új entitás létrehozva, azonban nincs azonosítója. Ez nem szabadna megtörténjen.",
			
			'ImportException:GUIDNotFound' => "'%d' entitás nem található.",
			'ImportException:ProblemUpdatingMeta' => "Hiba lépett fel '%s' frissítésekor a '%d' entitáson.",
			
			'ExportException:NoSuchEntity' => "Nincs ilyen entitásazonosító:%d", 
			
			'ImportException:NoODDElements' => "Nem található OpenDD elem az importált adatok között. Az importálás nem sikerült.",
			'ImportException:NotAllImported' => "Nem sikerült az összes elem importálása.",
			
			'InvalidParameterException:UnrecognisedFileMode' => "Fel nem ismert '%s' file mód.",
			'InvalidParameterException:MissingOwner' => "Minden file-nak kell legyen egy tulajdonosa!",
			'IOException:CouldNotMake' => "Nem sikerült %s megvalósítása",
			'IOException:MissingFileName' => "Határozzon meg egy nevet egy file megnyitása előtt.",
			'ClassNotFoundException:NotFoundNotSavedWithFile' => "Filestore not found or class not saved with file!",
			'NotificationException:NoNotificationMethod' => "Nincs értesítési mód beállítva.",
			'NotificationException:NoHandlerFound' => "No handler found for '%s' or it was not callable.",
			'NotificationException:ErrorNotifyingGuid' => "Hiba történt az értesítéskor: %d",
			'NotificationException:NoEmailAddress' => "Nem található a következő azonosító e-mail címe:%d",
			'NotificationException:MissingParameter' => "Hiányzó szükséges paraméter, '%s'",
			
			'DatabaseException:WhereSetNonQuery' => "Where set contains non WhereQueryComponent",
			'DatabaseException:SelectFieldsMissing' => "Fields missing on a select style query",
			'DatabaseException:UnspecifiedQueryType' => "Unrecognised or unspecified query type.",
			'DatabaseException:NoTablesSpecified' => "No tables specified for query.",
			'DatabaseException:NoACL' => "No access control was provided on query",
			
			'InvalidParameterException:NoEntityFound' => "No entity found, it either doesn't exist or you don't have access to it.",
			
			'InvalidParameterException:GUIDNotFound' => "GUID:%s could not be found, or you can not access it.",
			'InvalidParameterException:IdNotExistForGUID' => "Sorry, '%s' does not exist for guid:%d",
			'InvalidParameterException:CanNotExportType' => "Sorry, I don't know how to export '%s'",
			'InvalidParameterException:NoDataFound' => "Could not find any data.",
			'InvalidParameterException:DoesNotBelong' => "Does not belong to entity.",
			'InvalidParameterException:DoesNotBelongOrRefer' => "Does not belong to entity or refer to entity.",
			'InvalidParameterException:MissingParameter' => "Missing parameter, you need to provide a GUID.",
			
			'SecurityException:APIAccessDenied' => "Sorry, API access has been disabled by the administrator.",
			'SecurityException:NoAuthMethods' => "No authentication methods were found that could authenticate this API request.",
			'APIException:ApiResultUnknown' => "API Result is of an unknown type, this should never happen.", 
			
			'ConfigurationException:NoSiteID' => "No site ID has been specified.",
			'InvalidParameterException:UnrecognisedMethod' => "Unrecognised call method '%s'",
			'APIException:MissingParameterInMethod' => "Missing parameter %s in method %s",
			'APIException:ParameterNotArray' => "%s does not appear to be an array.",
			'APIException:UnrecognisedTypeCast' => "Unrecognised type in cast %s for variable '%s' in method '%s'",
			'APIException:InvalidParameter' => "Invalid parameter found for '%s' in method '%s'.",
			'APIException:FunctionParseError' => "%s(%s) has a parsing error.",
			'APIException:FunctionNoReturn' => "%s(%s) returned no value.",
			'SecurityException:AuthTokenExpired' => "Authentication token either missing, invalid or expired.",
			'CallException:InvalidCallMethod' => "%s must be called using '%s'",
			'APIException:MethodCallNotImplemented' => "Method call '%s' has not been implemented.",
			'APIException:AlgorithmNotSupported' => "Algorithm '%s' is not supported or has been disabled.",
			'ConfigurationException:CacheDirNotSet' => "Cache directory 'cache_path' not set.",
			'APIException:NotGetOrPost' => "Request method must be GET or POST",
			'APIException:MissingAPIKey' => "Missing X-Elgg-apikey HTTP header",
			'APIException:MissingHmac' => "Missing X-Elgg-hmac header",
			'APIException:MissingHmacAlgo' => "Missing X-Elgg-hmac-algo header",
			'APIException:MissingTime' => "Missing X-Elgg-time header",
			'APIException:TemporalDrift' => "X-Elgg-time is too far in the past or future. Epoch fail.",
			'APIException:NoQueryString' => "No data on the query string",
			'APIException:MissingPOSTHash' => "Missing X-Elgg-posthash header",
			'APIException:MissingPOSTAlgo' => "Missing X-Elgg-posthash_algo header",
			'APIException:MissingContentType' => "Missing content type for post data",
			'SecurityException:InvalidPostHash' => "POST data hash is invalid - Expected %s but got %s.",
			'SecurityException:DupePacket' => "Packet signature already seen.",
			'SecurityException:InvalidAPIKey' => "Invalid or missing API Key.",
			'NotImplementedException:CallMethodNotImplemented' => "Call method '%s' is currently not supported.",
	
			'NotImplementedException:XMLRPCMethodNotImplemented' => "XML-RPC method call '%s' not implemented.",
			'InvalidParameterException:UnexpectedReturnFormat' => "Call to method '%s' returned an unexpected result.",
			'CallException:NotRPCCall' => "Call does not appear to be a valid XML-RPC call",
	
			'PluginException:NoPluginName' => "The plugin name could not be found",
	
			'ConfigurationException:BadDatabaseVersion' => "The database backend you have installed doesn't meet the basic requirements to run Elgg. Please consult your documentation.",
			'ConfigurationException:BadPHPVersion' => "You need at least PHP version 5.2 to run Elgg.",
			'configurationwarning:phpversion' => "Elgg requires at least PHP version 5.2, you can install it on 5.1.6 but some features may not work. Use at your own risk.",
	
	
			'InstallationException:DatarootNotWritable' => "Your data directory %s is not writable.",
			'InstallationException:DatarootUnderPath' => "Your data directory %s must be outside of your install path.",
			'InstallationException:DatarootBlank' => "You have not specified a data directory.",
	
			'SecurityException:authenticationfailed' => "User could not be authenticated",
	
			'CronException:unknownperiod' => '%s is not a recognised period.',
	
			'SecurityException:deletedisablecurrentsite' => 'You can not delete or disable the site you are currently viewing!',
	
			'memcache:notinstalled' => 'PHP memcache module not installed, you must install php5-memcache',
			'memcache:noservers' => 'No memcache servers defined, please populate the $CONFIG->memcache_servers variable',
			'memcache:versiontoolow' => 'Memcache needs at least version %s to run, you are running %s',
			'memcache:noaddserver' => 'Multiple server support disabled, you may need to upgrade your PECL memcache library',

			'deprecatedfunction' => 'Figyelem: A script nem támogatott funkciókat használ (\'%s\'), ezért nem kompatibilis az Elgg jelen verziójával.',
		/**
		 * API
		 */
			'system.api.list' => "Az összes API hívás listázása.",
			'auth.gettoken' => "This API call lets a user log in, returning an authentication token which can be used in lieu of a username and password for authenticating further calls.",
	
		/**
		 * User details
		 */

			'name' => "Név",
			'email' => "Email cím",
			'username' => "Felhasználónév",
			'password' => "Jelszó",
			'passwordagain' => "Jelszó még egyszer (ellenőrzés)",
			'admin_option' => "Adminisztrátor legyen a felhasználó?",
	
		/**
		 * Access
		 */
	
			'PRIVATE' => "Privát",
			'LOGGED_IN' => "Bejelentkezett felhasználók",
			'PUBLIC' => "Nyilvános",
			'access:friends:label' => "Ismerősök",
			'access' => "Hozzáférés",
	
		/**
		 * Dashboard and widgets
		 */
	
			'dashboard' => "Főoldal",
			'dashboard:configure' => "Oldal szerkesztése",
			'dashboard:nowidgets' => "Kattintson az 'Oldal szerkesztése' linkre modulok hozzáadásához.",

			'widgets:add' => 'Modulok hozzáadása az oldalhoz.',
			'widgets:add:description' => "Válasszon a szolgáltatások közül a jobb oldalon lévő <b>Modul galériából</b>, s helyezze el őket a három lehetséges helyek egyikében áthúzással.

A modul eltávolításához húzza vissza a modult a <b>Modul galériába</b>.",
			'widgets:position:fixed' => '(Rögzített)',
	
			'widgets' => "Modulok",
			'widget' => "Modul",
			'item:object:widget' => "Modulok",
			'layout:customise' => "Elrendezés testreszabása",
			'widgets:gallery' => "Modul galéria",
			'widgets:leftcolumn' => "Bal oldali modulok",
			'widgets:fixed' => "Rögzített pozíció",
			'widgets:middlecolumn' => "Középső modulok",
			'widgets:rightcolumn' => "Jobb oldali modulok",
			'widgets:profilebox' => "Adatlap doboz",
			'widgets:panel:save:success' => "A modulok sikeresen mentésre kerültek.",
			'widgets:panel:save:failure' => "Nem sikerült a modulok elmentése. Kérem, próbálja meg még egyszer.",
			'widgets:save:success' => "A modul sikeresen mentésre került.",
			'widgets:save:failure' => "Nem sikerült elmenteni a modult. Kérem, próbálja meg még egyszer.",
			'widgets:handlernotfound' => 'A modul hibás, vagy az adminisztrátor által letiltásra került.',			
	
		/**
		 * Groups
		 */
	
			'group' => "Csoport", 
			'item:group' => "Csoportok",
	
		/**
		 * Profile
		 */
	
			'profile' => "Adatlap",
			'profile:edit:default' => 'Profil mezőinek módosítása',
			'user' => "Felhasználó",
			'item:user' => "Felhasználók",
			'riveritem:single:user' => 'egy felhasználó',
			'riveritem:plural:user' => 'néhány felhasználó',
			

		/**
		 * Profile menu items and titles
		 */
	
			'profile:yours' => "Adatlapom",
			'profile:user' => "%s adatlapja",
	
			'profile:edit' => "Adatlap módosítása",
			'profile:profilepictureinstructions' => "Az adatlap képe az a kép, amely az adatlapon jelenik meg. <br /> Bármikor lecserélhető. (Támogatott fájlformátumok: GIF, JPG vagy PNG)",
			'profile:icon' => "Adatlap kép",
			'profile:createicon' => "Saját avatar létrehozása",
			'profile:currentavatar' => "Jelenlegi avatar",
			'profile:createicon:header' => "Adatlap képe",
			'profile:profilepicturecroppingtool' => "Adatlap képének körülvágása",
			'profile:createicon:instructions' => "Kattints és jelölj ki egy négyzetet, ami alapján szeretnéd a képet körülvágni. A jobb oldali részen egy előkép fogja mutatni a vágás eredményét. Ha elégedett az előképpel, kattintson az 'Avatar' létrehozása'-ra. Ezt a körülvágott képet fogja a rendszer megjeleníteni a továbbiakban avatarként.",
	
			'profile:editdetails' => "Adatok módosítása",
			'profile:editicon' => "Avatar módosítása",
	
			'profile:aboutme' => "Rólam", 
			'profile:description' => "Rólam",
			'profile:briefdescription' => "Rövid leírás",
			'profile:location' => "Lakhely",
			'profile:skills' => "Készségeim",  
			'profile:interests' => "Érdeklődési területeim", 
			'profile:contactemail' => "Kapcsolattartásra szolgáló e-mail cím",
			'profile:phone' => "Telefonszám",
			'profile:mobile' => "Mobiltelefonszám",
			'profile:website' => "Weboldal",

			'profile:banned' => 'A felhasználói fiók felfüggesztésre került.', // TODO

			'profile:river:update' => "%s frissítette adatlapját",
			'profile:river:iconupdate' => "%s frissítette adatlap avatarját",

			'profile:label' => "Adatlap címke",
			'profile:type' => "Adatlap típus",
	
			'profile:editdefault:fail' => 'Az alapértelmezett adatlapot nem lehet elmenteni',
			'profile:editdefault:success' => 'Sikeresen hozzáadva az alapértelmezett profilhoz',
	
			
			'profile:editdefault:delete:fail' => 'Adatlap elem eltávolítása sikertelen',
			'profile:editdefault:delete:success' => 'Adatlap elem eltávolítva!',
	
			'profile:defaultprofile:reset' => 'Alapértelmezett rendszer adatlap visszaállítása',
	
			'profile:resetdefault' => 'Alapértelmezett adatlap visszaállítása',
	
		/**
		 * Profile status messages
		 */
	
			'profile:saved' => "Sikeres adatlapmentés.",
			'profile:icon:uploaded' => "Adatlap képe sikeresen feltöltve.",
	
		/**
		 * Profile error messages
		 */
	
			'profile:noaccess' => "Nincs hozzáférése ezen adatlaphoz.",
			'profile:notfound' => "A kért adatlap nem található.",
			'profile:cantedit' => "Nincs joga ezen adatlapot módosítani.",
			'profile:icon:notfound' => "Adatlap képének feltöltésekor hiba lépett fel.",
	
		/**
		 * Friends
		 */
	
			'friends' => "Ismerősök",
			'friends:yours' => "Ismerőseim",
			'friends:owned' => "%s ismerősei",
			'friend:add' => "Ismerősként megjelöl",
			'friend:remove' => "Ismerős eltávolítása",
	
			'friends:add:successful' => "%s sikeresen hozzá lett adva az ismerősök listájához.",
			'friends:add:failure' => "Nem sikerült %st hozzáadni a ismerősök listájához. Kérem, próbálja meg még egyszer.",
	
			'friends:remove:successful' => "A(z) %s nevű felhasználó sikeresen törlésre került ismerősök listájáról.",
			'friends:remove:failure' => "Nem sikerült %s törlése a ismerősök listájáról. Kérem, próbálja meg még egyszer.",
	
			'friends:none' => "Ez a felhasználó még nem adott senkit az ismeretségi listájához.",
			'friends:none:you' => "Eddig még senkit sem vett fel az ismerősei listájára! Javasoljuk, használja a keresés funkciót!",
	
			'friends:none:found' => "Nem talált ismerőst.",
	
			'friends:of:none' => "Még senki nem adta ezt a felhasználót az ismerősök listájához.",
			'friends:of:none:you' => "Senki sem adta még önt hozzá az ismeretségi listájához. Javasoljuk, töltse ki az adatlapját, hogy más felhasználók nagyobb eséllyel találják meg Önt!",
	
			'friends:of:owned' => "Felhasználók, akik %st ismerősként elfogadták",

			 'friends:num_display' => "Feltüntetendő ismerősök száma",
			 'friends:icon_size' => "Ikon mérete",
			 'friends:tiny' => "nagyon kicsi",
			 'friends:small' => "kicsi",
			 'friends:of' => "Ismerősök",
			 'friends:collections' => "Ismerősök gyűjteménye",
			 'friends:collections:add' => "Új ismerősi gyűjtemény",
			 'friends:addfriends' => "Ismerősök hozzáadása",
			 'friends:collectionname' => "Gyűjtemény neve",
			 'friends:collectionfriends' => "Ismerősök a gyűjteményben",
			 'friends:collectionedit' => "Gyűjtemény módosítása",
			 'friends:nocollections' => "Még nincs egyetlen gyűjteménye sem.",
			 'friends:collectiondeleted' => "Gyűjteménye törlésre került.",
			 'friends:collectiondeletefailed' => "Nem sikerült törölni a gyűjteményt. Vagy nincs joga ehhez, vagy egy más probléma lépett fel.",
			 'friends:collectionadded' => "A gyűjtemény létrehozása sikerült.",
			 'friends:nocollectionname' => "Adja meg a gyűjtemény nevét a létrehozáshoz!",
			'friends:collections:members' => "A gyűjtemény tagjai",
			'friends:collections:edit' => "A gyűjtemény szerkesztése",
		
	        'friends:river:created' => "%s hozzáadta az ismerősök widgetet.",
	        'friends:river:updated' => "%s frissítette az ismerősök widgetet.",
	        'friends:river:delete' => "%s eltávolította az ismerősök widgetet.",
	        'friends:river:add' => "%s ismerősként jelölte be",

			'friendspicker:chararray' => 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', // TODO
	
		/**
		 * Feeds
		 */
			'feed:rss' => 'Feliratkozás a hírszolgáltatásra',
			'feed:odd' => 'OpenDD hírszolgáltatás',
		/**
          * links
		 **/

			'link:view' => 'link megtekintése',
	
		/**
		 * River
		 */
			'river' => "River",			 // TODO
			'river:relationship:friend' => 'mostantól a következő ismerőse:',
			'river:noaccess' => 'Nincs jogosultsága az elem megtekintésére.',
			'river:posted:generic' => '%s beküldte', // TODO

		/**
		 * Plugins
		 */
			'plugins:settings:save:ok' => "A(z) %s eszköz beállításai sikeresen mentésre kerültek.",
			'plugins:settings:save:fail' => "Hiba lépett fel a(z) %s eszköz beállításainak mentésekor.",
			'plugins:usersettings:save:ok' => "A(z) %s eszköz felhasználói beállításai sikeresen mentésre kerültek.",
			'plugins:usersettings:save:fail' => "Hiba lépett fel a(z) %s plugin felhasználói beállításainak mentésekor.",
			
			'admin:plugins:label:version' => "Verzió",
			'item:object:plugin' => 'Eszköz konfigurációs beállítások',
			
		/**
		 * Notifications
		 */
			'notifications:usersettings' => "Értesítés beállítások",
			'notifications:methods' => "Kérem, jelölje meg, milyen értesítési módszereket engedélyez.",
	
			'notifications:usersettings:save:ok' => "Értesítési beállításai sikeresen mentésre kerültek.",
			'notifications:usersettings:save:fail' => "Hiba lépett fel az értesítési beállítások mentésekor.",
			'user.notification.get' => 'Adott felhasználóhoz tartozó értesítések.',
			'user.notification.set' => 'Adott felhasználóhoz tartozó értesítések beállítása.',
		/**
		 * Search
		 */
	
			'search' => "Keresés",
			'searchtitle' => "Keresés: %s",
			'users:searchtitle' => "Felhasználó keresése: %s",
			'advancedsearchtitle' => "%s a következő találatokkal %s",
			'notfound' => "Nincs találat.",
			'next' => "Következő",
			'previous' => "Előző",
	
			'viewtype:change' => "Listázási típus váltása",
			'viewtype:list' => "Listakénti megtekintés",
			'viewtype:gallery' => "Galéria",
	
			'tag:search:startblurb' => "A(z) '%s' címkével rendelkező elemek listája:",

			'user:search:startblurb' => "A(z) '%s' keresési kulcsszóra illeszkedő felhasználók listája:",
			'user:search:finishblurb' => "További találatok...",
	
		/**
		 * Account
		 */
	
			'account' => "Adatlap",
			'settings' => "Beállítások",
			'tools' => "Eszközök",
			'tools:yours' => "Eszközeim",
	
			'register' => "Regisztrálás",
			'registerok' => "Sikeresen regisztrált a %s közösségi portálon. Az adatlap aktiválásához kérem, igazolja vissza e-mail címét a küldött linkre kattintva.",
			'registerbad' => "Sikertelen regisztráció. A választott felhasználónév már létezik, a két megadott jelszó nem egyezik, vagy a megadott felhasználónév / jelszó túl rövid.",
			'registerdisabled' => "A regisztráció lehetősége le van tiltva.",
			'firstadminlogininstructions' => 'Az új Elgg honlap telepítése sikeresen megtörtént. Létrehozásra került egy adminisztrátori fiók. A következő lépések során lehetősége van a honlap konfigurálására, eszközök, modulok installálásán és aktiválásán keresztül.',	
			'registration:notemail' => 'A megadott e-mail cím nem valós.',
			'registration:userexists' => 'A választott felhasználónév már létezik',
			'registration:usernametooshort' => 'A felhasználónév legalább 4 karakterből kell álljon.',
			'registration:passwordtooshort' => 'A jelszó legalább 6 karakterből kell álljon.',
			'registration:dupeemail' => 'Ez az e-mail cím már regisztrálva van.',
			'registration:invalidchars' => 'A felhasználónév érvénytelen karaktert tartalmaz.',
			'registration:emailnotvalid' => 'Az email cím érvénytelen.',
			'registration:passwordnotvalid' => 'A jelszó érvénytelen.',
			'registration:usernamenotvalid' => 'A felhasználónév érvénytelen.',
	
			'adduser' => "Felhasználó hozzáadása",
			'adduser:ok' => "Felhasználó sikeresen létrehozva.",
			'adduser:bad' => "Nem sikerült az új felhasználó létrehozása",
			
			'item:object:reported_content' => "Jelentett cikkek",
	
			'user:set:name' => "Felhasználói név beállításai",
			'user:name:label' => "Név",
			'user:name:success' => "Sikeres névváltoztatás.",
			'user:name:fail' => "Sikertelen névváltoztatás.",
	
			'user:set:password' => "Jelszó",
			'user:password:label' => "Új jelszó",
			'user:password2:label' => "Új jelszó még egyszer",
			'user:password:success' => "Jelszó sikeresen megváltoztatva",
			'user:password:fail' => "Nem sikerült megváltoztatni a jelszót.",
			'user:password:fail:notsame' => "A két megadott jelszó nem egyezik meg!",
			'user:password:fail:tooshort' => "Túl rövid jelszó!",
	
			'user:set:language' => "Nyelvi beállítások",
			'user:language:label' => "Használt nyelv",
			'user:language:success' => "Nyelvi beállítások sikeresen frissítve.",
			'user:language:fail' => "Nem sikerült a nyelvi beállításokat frissíteni.",
	
			'user:username:notfound' => '%s nevű felhasználó nem található.',
	
			'user:password:lost' => 'Elvesztett jelszó',
			'user:password:resetreq:success' => 'Jelszó kérés sikeres, e-mail elküldve',
			'user:password:resetreq:fail' => 'Nem sikerült az új jelszó kérése.',
			'user:password:text' => 'Új jelszó generálásához kérjük adja meg a felhasználónevét. Ezt követően elküldünk Önnek egy emailt, benne egy linket, amelyre kattintva a kért új jelszót elküldjük Önnek.',
	
			'user:persistent' => 'Emlékezz rám',
		/**
		 * Administration
		 */

			'admin:configuration:success' => "Beállításai sikeresen elmentve.",
			'admin:configuration:fail' => "Nem sikerült a beállításainak elmentése.",
	
			'admin' => "Adminisztráció",
			'admin:description' => "Az adminisztrációs felület a rendszer minden aspektusának kezelését teszi lehetővé a felhasználókezeléstől a bővítmények működéséig.",
			
			'admin:user' => "Felhasználókezelés",
			'admin:user:description' => "Ez az adminisztrációs felület a felhasználói beállítások kezelését teszi lehetővé.",
			'admin:user:adduser:label' => "Kattintson ide egy új felhasználó hozzáadásához...",
			'admin:user:opt:linktext' => "Felhasználók beállításai...",
			'admin:user:opt:description' => "Felhasználók és adatlapinformációik beállításai.. ",
			
			'admin:site' => "Oldal adminisztráció",
			'admin:site:description' => "Ez az adminisztrációs felület az oldal globális beállításainak kezelését teszi lehetővé. A kezdéshez válasszon egyet az alábbiak közül.",
			'admin:site:opt:linktext' => "Oldal beállításai...",
			'admin:site:opt:description' => "Az oldal tehnikai és nem tehnikai beállításai. ",

			'admin:site:access:warning' => "A hozzáférési szint változtatása csak a jövőben létrejövő tartalmakat érinti.",
			
			'admin:plugins' => "Eszközök kezelése",
			'admin:plugins:description' => "Ez az adminisztrációs felület a telepített bővítmények kezelését és beállításait teszi lehetővé.",
			'admin:plugins:opt:linktext' => "Eszközök beállítása...",
			'admin:plugins:opt:description' => "A telepített eszközök beállítása.",
			'admin:plugins:label:author' => "Szerző",
			'admin:plugins:label:copyright' => "Szerzői jog",
			'admin:plugins:label:licence' => "Licensz",
			'admin:plugins:label:website' => "URL",
			'admin:plugins:label:moreinfo' => "bővebben",
			'admin:plugins:label:version' => 'Verzió',
			'admin:plugins:warning:elggversionunknown' => 'Figyelem: Ez az eszköz nem kompatibilis az Elgg jelenlegi verziójával.',
			'admin:plugins:warning:elggtoolow' => 'Figyelem: ez az eszköz az Elgg újabb verzióját igényli!',
			'admin:plugins:reorder:yes' => "%s bővítmény átrendezve.",
			'admin:plugins:reorder:no' => "%s bővítmény átrendezése sikertelen.",
			'admin:plugins:disable:yes' => "%s bővítmény sikeresen letiltva.",
			'admin:plugins:disable:no' => "Nem sikerült a(z) %s bővítmény letiltása.",
			'admin:plugins:enable:yes' => "%s bővítmény sikeresen engedélyezve.",
			'admin:plugins:enable:no' => "Nem sikerült a(z) %s bővítmény engedélyezése.",
	
			'admin:statistics' => "Statisztikák",
			'admin:statistics:description' => "Ez egy áttekintő az oldal statisztikai adatairól. Ha részletesebb statisztikát szeretne, egy professzionálisabb adminisztrációs lehetőség is igénybe vehető.",
			'admin:statistics:opt:description' => "Objektumokról és felhasználókról készült statisztikai adatok megtekintése.",
			'admin:statistics:opt:linktext' => "Statisztikai adatok megtekintése...",
			'admin:statistics:label:basic' => "Alap oldalstatisztikák",
			'admin:statistics:label:numentities' => "Entitások az oldalon",
			'admin:statistics:label:numusers' => "Felhasználók száma",
			'admin:statistics:label:numonline' => "Online felhasználók száma",
			'admin:statistics:label:onlineusers' => "Online felhasználók",
			'admin:statistics:label:version' => "Elgg verzió",
			'admin:statistics:label:version:release' => "Kiadás",
			'admin:statistics:label:version:version' => "Verzió",
	
			'admin:user:label:search' => "Felhasználók keresése:",
			'admin:user:label:seachbutton' => "Keresés", 
	
			'admin:user:ban:no' => "Nem lehetséges a felhasználó kitiltása",
			'admin:user:ban:yes' => "Felhasználó kitiltva.",
			'admin:user:unban:no' => "Nem lehetséges a felhasználó kitiltásának visszavonása",
			'admin:user:unban:yes' => "Felhasználó kitiltása visszavonva.",
			'admin:user:delete:no' => "Nem lehetséges a felhasználó törlése",
			'admin:user:delete:yes' => "Felhasználó törölve",
	
			'admin:user:resetpassword:yes' => "Jelszó frissítve, felhasználó értesítve.",
			'admin:user:resetpassword:no' => "Nem sikerült a jelszó frissítése.",
	
			'admin:user:makeadmin:yes' => "A felhasználó mostantól adminisztrátori jogosultságokkal rendelkezik.",
			'admin:user:makeadmin:no' => "Nem sikerült a felhasználót adminisztrátorrá minősíteni.",
			'admin:user:removeadmin:yes' => "A felhasználó mostantól nem adminisztrátor.",
			'admin:user:removeadmin:no' => "Nem sikerült az adminisztrátori jogok visszavonása a felhasználótól.",
			
		/**
		 * User settings
		 */
			'usersettings:description' => "A felhasználó beállításai panel az ön személyes beállításainak kezelését teszi lehetővé a felhasználókezeléstől a bővítmények működéséig. A folytatáshoz válasszon egyet az alábbiak közül.",
	
			'usersettings:statistics' => "Az Ön statisztikái",
			'usersettings:statistics:opt:description' => "Az oldalon lévő objektumokkal és felhasználókkal kapcsolatos statisztikai adatok megtekintése.",
			'usersettings:statistics:opt:linktext' => "Adatlapom statisztikái",
	
			'usersettings:user' => "Adataim",
			'usersettings:user:opt:description' => "Ez a felhasználói beállítások kezelését teszi lehetővé.",
			'usersettings:user:opt:linktext' => "Adataim változtatása",
	
			'usersettings:plugins' => "Eszközök",
			'usersettings:plugins:opt:description' => "Az aktivált eszközök beállításai.",
			'usersettings:plugins:opt:linktext' => "Eszközeim beállítása...",
	
			'usersettings:plugins:description' => "Ez a panel a rendszeradminisztrátor által telepített eszközök személyreszabott beállítását és kezelését teszi lehetővé.",
			'usersettings:statistics:label:numentities' => "Entitásaim",
	
			'usersettings:statistics:yourdetails' => "Adataim",
			'usersettings:statistics:label:name' => "Teljes név",
			'usersettings:statistics:label:email' => "E-mail",
			'usersettings:statistics:label:membersince' => "Tagság kezdete",
			'usersettings:statistics:label:lastlogin' => "Utolsó bejelentkezés ideje",
	
			
	
		/**
		 * Generic action words
		 */
	
			'save' => "Ment",
			'publish' => "Publikál",
			'cancel' => "Mégsem",
			'saving' => "Mentés...",
			'update' => "Frissít",
			'edit' => "Módosít",
			'delete' => "Töröl",
			'accept' => "Elfogad",
			'load' => "Betölt",
			'upload' => "Feltölt",
			'ban' => "Kitilt",
			'unban' => "Tiltást visszavon",
			'enable' => "Engedélyez",
			'disable' => "Letilt",
			'request' => "Igényel",
			'complete' => "Kész",
			'open' => 'Megnyit',
			'close' => 'Bezár',
			'reply' => "Válasz",

			'more' => 'Több',
			'comments' => 'Hozzászólások',
			'import' => 'Importálás',
			'export' => 'Exportálás',
	
			'up' => 'Fel',
			'down' => 'Le',
			'top' => 'Tetejére',
			'bottom' => 'Aljára',
	
			'invite' => "Meghív",
	
			'resetpassword' => "Jelszó visszaállítása",
			'makeadmin' => "Admin jogok megadása",
			
			'removeadmin' => "Admin jogok eltávolítása",
				
			'option:yes' => "Igen",
			'option:no' => "Nem",
	
			'unknown' => 'Nem értelmezett',
	
			'active' => 'Aktív',
			'total' => 'Összes',

			'learnmore' => "Kattintson ide további információkért.",
	
			'content' => "tartalom",
			'content:latest' => 'Legújabb aktivitás',
			'content:latest:blurb' => 'Alternatív lehetőség: kattintson ide az oldalon megjelent legfrissebb tartalmak listázásához.',
			'link:text' => 'link megtekintése',

			'enableall' => 'Összes aktiválása',
			'disableall' => 'Összes inaktiválása',

		/**
		 * Generic questions
		 */
	
			'question:areyousure' => 'Biztos benne?',
	
		/**
		 * Generic data words
		 */
	
			'title' => "Cím",
			'description' => "Leírás",
			'tags' => "Címkék",
			'spotlight' => "Spotlight",
			'all' => "Mind",
	
			'by' => 'by',
	
			'annotations' => "Kommentárok",
			'relationships' => "Kapcsolatok",
			'metadata' => "Metaadat",
	
		/**
		 * Input / output strings
		 */

			'deleteconfirm' => "Biztosan törölni akarja?",
			'fileexists' => "Egy fájl korábban már feltöltésre került. A fájl lecseréléséhez válasszon az alábbiak közül:",
	    /**
         * System messages
         **/

			'systemmessages:dismiss' => "katt az eltűntetéshez",

		/**
		 * User add
		 */

			'useradd:subject' => 'Felhasználói fiók létrehozása',
			'useradd:body' => '
Kedves %s,

A megadott adatok alapján létrejött a felhasználói fiókja a(z) %s honlapon. A bejelentkezéshez kattintson ide:

	%s

A bejelentkezéshez szükséges adatok:

	Felhasználói név: %s
	Jelszó: %s
	
A bejelentkezést követően kérjük változtassa meg a jelszavát.
',
	
		/**
		 * Import / export
		 */
			'importsuccess' => "Az adatok importálása sikeres volt",
			'importfail' => "OpenDD adatimportálás nem sikerült.",
	
		/**
		 * Time
		 */
	
			'friendlytime:justnow' => "épp most",
			'friendlytime:minutes' => "%s perce",
			'friendlytime:minutes:singular' => "egy perce",
			'friendlytime:hours' => "%s órája",
			'friendlytime:hours:singular' => "egy órája",
			'friendlytime:days' => "%s napja",
			'friendlytime:days:singular' => "tegnap",

			'date:month:01' => 'január %s',
			'date:month:02' => 'február %s',
			'date:month:03' => 'március %s',
			'date:month:04' => 'április %s',
			'date:month:05' => 'május %s',
			'date:month:06' => 'június %s',
			'date:month:07' => 'július %s',
			'date:month:08' => 'augusztus %s',
			'date:month:09' => 'szeptember %s',
			'date:month:10' => 'október %s',
			'date:month:11' => 'november %s',
			'date:month:12' => 'december %s',
	
		/**
		 * Installation and system settings
		 */
	
			'installation:error:htaccess' => "Elgg requires a file called .htaccess to be set in the root directory of its installation. We tried to create it for you, but Elgg doesn't have permission to write to that directory. 

Creating this is easy. Copy the contents of the textbox below into a text editor and save it as .htaccess

",
			'installation:error:settings' => "Elgg couldn't find its settings file. Most of Elgg's settings will be handled for you, but we need you to supply your database details. To do this:

1. Rename engine/settings.example.php to settings.php in your Elgg installation.

2. Open it with a text editor and enter your MySQL database details. If you don't know these, ask your system administrator or technical support for help.

Alternatively, you can enter your database settings below and we will try and do this for you...",
	
			'installation:error:configuration' => "Once you've corrected any configuration issues, press reload to try again.",
	
			'installation' => "Installation",
			'installation:success' => "Elgg's database was installed successfully.",
			'installation:configuration:success' => "Your initial configuration settings have been saved. Now register your initial user; this will be your first system administrator.",
	
			'installation:settings' => "System settings",
			'installation:settings:description' => "Now that the Elgg database has been successfully installed, you need to enter a couple of pieces of information to get your site fully up and running. We've tried to guess where we could, but <b>you should check these details.</b>",
	
			'installation:settings:dbwizard:prompt' => "Enter your database settings below and hit save:",
			'installation:settings:dbwizard:label:user' => "Database user",
			'installation:settings:dbwizard:label:pass' => "Database password",
			'installation:settings:dbwizard:label:dbname' => "Elgg database",
			'installation:settings:dbwizard:label:host' => "Database hostname (usually 'localhost')",
			'installation:settings:dbwizard:label:prefix' => "Database table prefix (usually 'elgg')",
	
			'installation:settings:dbwizard:savefail' => "We were unable to save the new settings.php. Please save the following file as engine/settings.php using a text editor.",
	
			'installation:sitename' => "The name of your site (eg \"My social networking site\"):",
			'installation:sitedescription' => "Short description of your site (optional)",
			'installation:wwwroot' => "The site URL, followed by a trailing slash:",
			'installation:path' => "The full path to your site root on your disk, followed by a trailing slash:",
			'installation:dataroot' => "The full path to the directory where uploaded files will be stored, followed by a trailing slash:",
			'installation:dataroot:warning' => "You must create this directory manually. It should sit in a different directory to your Elgg installation.",
			'installation:sitepermissions' => "The default access permissions:",
			'installation:language' => "The default language for your site:",
			'installation:debug' => "Debug mode provides extra information which can be used to diagnose faults, however it can slow your system down so should only be used if you are having problems:",
			'installation:debug:label' => "Turn on debug mode",
			'installation:usage' => "This option lets Elgg send anonymous usage statistics back to Curverider.",
			'installation:usage:label' => "Send anonymous usage statistics",
			'installation:httpslogin' => "Enable this to have user logins performed over HTTPS. You will need to have https enabled on your server for this to work.",
			'installation:httpslogin:label' => "Enable HTTPS logins",
			'installation:view' => "Enter the view which will be used as the default for your site or leave this blank for the default view (if in doubt, leave as default):",

			'installation:siteemail' => "Site email address (used when sending system emails)",
	
			'installation:disableapi' => "The RESTful API is a flexible and extensible interface that enables applications to use certain Elgg features remotely.",
			'installation:disableapi:label' => "Enable the RESTful API",

			'installation:allow_user_default_access:description' => "If checked, individual users will be allowed to set their own default access level that can over-ride the system default access level.",
			'installation:allow_user_default_access:label' => "Allow user default access",
	
			'installation:simplecache:description' => "The simple cache increases performance by caching static content including some CSS and JavaScript files. Normally you will want this on.",
			'installation:simplecache:label' => "Use simple cache",

			'upgrading' => 'Upgrading',
			'upgrade:db' => 'Your database was upgraded.',
			'upgrade:core' => 'Your elgg installation was upgraded',
	
		/**
		 * Welcome
		 */
	
			'welcome' => "Üdvözöljük!",
			'welcome_message' => "Üdvözli Önt az Elgg!",
	
		/**
		 * Emails
		 */
			'email:settings' => "E-mail beállítások",
			'email:address:label' => "E-mail címem",
			
			'email:save:success' => "Az új e-mail címet elmentettük, további megerősítés szükséges.",
			'email:save:fail' => "Az új e-mail címét nem sikerült elmenteni.",
	
			'friend:newfriend:subject' => "%s visszaigazolta, hogy az ismerőse vagy!",
			'friend:newfriend:body' => "%s visszaigazolta, hogy az ismerőse vagy!

Adatlapja megtekintéséhez kattintson ide:

	%s

Kérem, ne válaszoljon erre a levélre.",
	
	
			'email:validate:subject' => "%s, kérem, erősítse meg az e-mail címét!",
			'email:validate:body' => "Üdvözöljük, %s,

Kérem, erősítse meg e-mail címét a következő linkre kattintva:

%s
",
			'email:validate:success:subject' => "e-mail cím megerősítve, %s!",
			'email:validate:success:body' => "Üdvözöljük, %s,
			
Gratulálunk, sikeresen megerősítette az e-mail címét.",
	
	
			'email:resetpassword:subject' => "Jelszó frissítve!",
			'email:resetpassword:body' => "Üdvözöljük, %s,
			
Jelszavát frissítettük a következőre: %s",
	
	
			'email:resetreq:subject' => "Új jelszó kérése.",
			'email:resetreq:body' => "Üdvözöljük, %s,
			
Valaki ( %s IP címről ) új jelszót kért a felhasználójához.

Ha ön kérte, akkor kattintson az alábbi linkre, egyébként hagyja figyelmen kívül ezt az e-mailt.

%s
",

		/**
		 * user default access
		 */
	
		'default_access:settings' => "Az Ön alapértelmezett hozzáférési szintje",
		'default_access:label' => "Hozzáférési szint",
		'user:default_access:success' => "Az új hozzáférési szint mentésre került.",
		'user:default_access:failure' => "Az új hozzáférési szint mentése nem sikerült.",
	
		/**
		 * XML-RPC
		 */
			'xmlrpc:noinputdata'	=>	"Hiányzik a bemeneti adat",
	
		/**
		 * Comments
		 */
	
			'comments:count' => "%s kommentálja",
			
			'riveraction:annotation:generic_comment' => '%s hozzászólást fűzött az alábbihoz: %s',
	
			'generic_comments:add' => "Hozzászólás hozzáadása",
			'generic_comments:text' => "Hozzászólás szövege",
			'generic_comment:posted' => "Hozzászólása sikeresen elküldésre került.",
			'generic_comment:deleted' => "Hozzászólása sikeresen törölve.",
			'generic_comment:blank' => "Kérem, a mentéshez adja meg a hozzászólás szövegét.",
			'generic_comment:notfound' => "Nem található a kért elem.",
			'generic_comment:notdeleted' => "Nem sikerült a hozzászólás törlése.",
			'generic_comment:failure' => "Hiba történt a hozzászólás elküldésekor. Kérem, próbálja meg újból.",
			'generic_comment:email:subject' => 'Új hozzászólás érkezett!',
			'generic_comment:email:body' => "Új hozzászólás érkezett a következőhöz: \"%s\", feladója: %s. A hozzászólás szövege:

			
%s


A válaszadáshoz vagy az eredeti hozzászólás megtekintéséhez kérem, kattintson ide:

	%s

%s adatlapjának megtekintéséhez kattintson ide:

	%s

Kérem, ne válaszoljon erre az e-mailre.",
	
		/**
		 * Entities
		 */
			'entity:default:strapline' => 'Létrehozva %s %s által',
			'entity:default:missingsupport:popup' => 'Ezt az elemet nem lehet helyesen megjeleníteni. Lehetséges oka, hogy olyan plugint igényel, amely nincs telepítve.',
	
			'entity:delete:success' => '%s sikeresen törölve',
			'entity:delete:fail' => 'Nem sikerült %s törlése',
	
	
		/**
		 * Action gatekeeper
		 */
			'actiongatekeeper:missingfields' => 'Form is missing __token or __ts fields',
			'actiongatekeeper:tokeninvalid' => 'Az űrlap jelzése nem egyezik a szerver által generálttal.',
			'actiongatekeeper:timeerror' => 'Az úrlap lejárt, kérem, frissítse az oldalt és próbálkozzon újra.',
			'actiongatekeeper:pluginprevents' => 'Egy kiterjesztés megakadályozta, hogy az űrlap elküldésre kerüljön.',
		/**
		 * Word blacklists
		 */
			'word:blacklist' => 'and, the, then, but, she, his, her, him, one, not, also, about, now, hence, however, still, likewise, otherwise, therefore, conversely, rather, consequently, furthermore, nevertheless, instead, meanwhile, accordingly, this, seems, what, whom, whose, whoever, whomever',
	
		/**
		 * Languages according to ISO 639-1
		 */
			"aa" => "Afar",
			"ab" => "Abház",
			"af" => "Afrikaans",
			"am" => "Amhara",
			"ar" => "Arab",
			"as" => "Asszámi",
			"ay" => "Ajmara",
			"az" => "Azeri",
			"ba" => "Baskír",
			"be" => "Belarusz",
			"bg" => "Bolgár",
			"bh" => "Bhojpuri",
			"bi" => "Bislama",
			"bn" => "Bengáli",
			"bo" => "Tibeti",
			"br" => "Breton",
			"ca" => "Katalán",
			"co" => "Korzikai",
			"cs" => "Cseh",
			"cy" => "Wales-i",
			"da" => "Dán",
			"de" => "Német",
			"dz" => "Dzongkha",
			"el" => "Görög",
			"en" => "Angol",
			"eo" => "Eszperantó",
			"es" => "Spanyol",
			"et" => "Észt",
			"eu" => "Baszk",
			"fa" => "Perzsa",
			"fi" => "Finn",
			"fj" => "Fidzsi",
			"fo" => "Feröeri",
			"fr" => "Francia",
			"fy" => "Fríz",
			"ga" => "Ír",
			"gd" => "Skót-gael",
			"gl" => "Galíciai",
			"gn" => "Guarani",
			"gu" => "Gujarati",
			"he" => "Héber",
			"ha" => "Hausa",
			"hi" => "Hindi",
			"hr" => "Horvát",
			"hu" => "Magyar",
			"hy" => "Örmény",
			"ia" => "Interlingva",
			"id" => "Indonéz",
			"ie" => "Interlingue",
			"ik" => "Inupiak",
			//"in" => "Indonesian",
			"is" => "Izlandi",
			"it" => "Olasz",
			"iu" => "Inuktitut",
			"iw" => "Héber (elavult)",
			"ja" => "Japán",
			"ji" => "Jiddis (elavult)",
			"jw" => "Jávai",
			"ka" => "Grúz",
			"kk" => "Kazah",
			"kl" => "Grönlandi",
			"km" => "Khmer",
			"kn" => "Kannada",
			"ko" => "Koreai",
			"ks" => "Kasmiri",
			"ku" => "Kurd",
			"ky" => "Kirgiz",
			"la" => "Latin",
			"ln" => "Lingala",
			"lo" => "Laoszi",
			"lt" => "Litván",
			"lv" => "Lett",
			"mg" => "Malagasy",
			"mi" => "Maori",
			"mk" => "Macedón",
			"ml" => "Malayalam",
			"mn" => "Mongol",
			"mo" => "Moldáv",
			"mr" => "Marathi",
			"ms" => "Maláj",
			"mt" => "Máltai",
			"my" => "Birmani",
			"na" => "Naurui",
			"ne" => "Nepáli",
			"nl" => "Holland",
			"no" => "Norvég",
			"oc" => "Okcitán",
			"om" => "Oromo",
			"or" => "Oriya",
			"pa" => "Pandzsábi",
			"pl" => "Lengyel",
			"ps" => "Pastu",
			"pt" => "Portugál",
			"qu" => "Kecsua",
			"rm" => "Rétoromán",
			"rn" => "Kirundi",
			"ro" => "Román",
			"ru" => "Orosz",
			"rw" => "Kinyarwanda",
			"sa" => "Szanszkrit",
			"sd" => "Sindhi",
			"sg" => "Sangro",
			"sh" => "Szerbhorvát",
			"si" => "Szingaléz",
			"sk" => "Szlovák",
			"sl" => "Szlovén",
			"sm" => "Szamoai",
			"sn" => "Shona",
			"so" => "Szomáli",
			"sq" => "Albán",
			"sr" => "Szerb",
			"ss" => "Siswati",
			"st" => "Sesotho",
			"su" => "Szundanéz",
			"sv" => "Svéd",
			"sw" => "Szuahéli",
			"ta" => "Tamil",
			"te" => "Tegulu",
			"tg" => "Tadzsik",
			"th" => "Thaiföldi",
			"ti" => "Tigrinja",
			"tk" => "Türkmén",
			"tl" => "Tagalog",
			"tn" => "Setswana",
			"to" => "Tongai",
			"tr" => "Török",
			"ts" => "Tsonga",
			"tt" => "Tatár",
			"tw" => "Twi",
			"ug" => "Ujgur",
			"uk" => "Ukrán",
			"ur" => "Urdu",
			"uz" => "Üzbég",
			"vi" => "Vietnami",
			"vo" => "Volapük",
			"wo" => "Wolof",
			"xh" => "Xhosa",
			"yi" => "Jiddis",
			"yo" => "Yoruba",
			"za" => "Zuang",
			"zh" => "Kínai",
			"zu" => "Zulu",
	);
	
	add_translation("hu",$hungarian);

?>
