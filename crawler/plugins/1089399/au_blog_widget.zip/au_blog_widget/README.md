AU-Blog-Widget-1.8.x
====================

Makes the blog widget more configurable for Elgg 1.8

Plugin should reside in mod/au_blog_widget