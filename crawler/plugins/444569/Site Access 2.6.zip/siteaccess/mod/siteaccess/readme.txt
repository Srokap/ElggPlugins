http://community.elgg.org/pg/pages/view/62228/
