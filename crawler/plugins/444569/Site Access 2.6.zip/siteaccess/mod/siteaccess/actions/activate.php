<?php

    require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");

    global $CONFIG;

// block non-admin users
admin_gatekeeper ();
action_gatekeeper ();

$access_status = access_get_show_hidden_status ();
access_show_hidden_entities ( true );

// Get the user
$guid = get_input ( 'guid' );
$obj = get_entity ( $guid );

if (($obj instanceof ElggUser) && ($obj->canEdit ())) {
	$obj->enable();
	set_user_validation_status ( $guid, true, 'admin' );
	system_message ( elgg_echo ( 'siteaccess:admin:validate:success' ) );
	siteaccess_notify_user ( $obj, 'admin_activated' );
	siteaccess_add_to_river ( $obj, 'admin' );
} else {
	register_error ( elgg_echo ( 'siteaccess:admin:validate:error' ) );
}

access_show_hidden_entities ( $access_status );

forward ( $_SERVER ['HTTP_REFERER'] );
exit ();
?>