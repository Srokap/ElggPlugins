<?php
    mt_srand ((double)microtime()*1000000);
    $maxran = 1000000;
    $random = mt_rand(0, $maxran);
    
    $ts = time();
    $token = generate_action_token($ts);

    $html = "";
    $html .= "<div id=\"siteaccess-code\"><table><tr><td><img src='". $vars['url'] ."action/siteaccess/code?c=$random&__elgg_ts=$ts&__elgg_token=$token'></td> ";
    $html .= "<td><input type=\"text\" name=\"code\" maxlength=\"6\" /></td></tr></table></div>";
    $html .= elgg_view('input/hidden', array('internalname' => 'random', 'value' => $random));
    
    echo $html;
?>
