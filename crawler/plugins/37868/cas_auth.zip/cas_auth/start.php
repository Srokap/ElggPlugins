<?php
error_reporting("E_ERROR");


// standard Elgg module callse
register_elgg_event_handler('init','system','cas_auth_init');
register_action('cas_auth/login', true, $CONFIG->pluginspath . 'cas_auth/login.php');


//supprting functions

function cas_auth_init() {
  global $CONFIG;
    
  register_pam_handler('cas_auth_authenticate');
 
  register_translations($CONFIG->pluginspath . "cas_auth/languages/");

}


function cas_auth_authenticate($credentials) {

	$config = find_plugin_settings('cas_auth');
        // Perform the authentication
    return authCAS($config, $credentials);
        
   
        

}

?>