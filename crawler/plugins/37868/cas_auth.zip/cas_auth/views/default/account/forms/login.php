<?php

     /**
	 * Elgg login form
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.org/
	 */
	 
	global $CONFIG;
	$config = find_plugin_settings('cas_auth');
	$ts = time();
	$token = generate_action_token($ts);
    
	$form_body = "<p><label>" . elgg_echo('username') . "<br />" . elgg_view('input/text', array('internalname' => 'username', 'class' => 'login-textarea')) . "</label>";
	$form_body .= "<br />";
	$form_body .= "<label>" . elgg_echo('password') . "<br />" . elgg_view('input/password', array('internalname' => 'password', 'class' => 'login-textarea')) . "</label><br />";
//	$form_body .= "<input type='hidden' name='username' value='" . $vars['url'] . "'/>";
//	$form_body .= "<input type='hidden' name='password' value='" . $vars['url'] . "'/>";

	$form_body .= "<input type='hidden' name='passthru_url' value='" . $vars['url'] . "'/>";
	$form_body .= elgg_view('input/submit', array('value' => elgg_echo('login'))) . "</p>";
	$form_body .= "<p>";
	//<input name=\"username\" type=\"text\" class="general-textarea" /></label>
?>
	
	<div id="login-box">
	<h2><?php echo elgg_echo('login'); ?></h2>
		<?php echo elgg_view('input/form', array('body' => $form_body, 'method'=>'POST', 'action' => "https://" . $config->cashostname . ":" . $config->casport . $config->casbaseuri . "/login?service=" . $vars['url'] .  "action/cas_auth/login")); ?>
		
	</div>