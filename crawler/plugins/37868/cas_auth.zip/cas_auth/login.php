<?php

ini_set('display_errors','1');

    // Elgg obliterates the &ticket query paramter; we need
    // to reinstate it from the $vals variable.
    $_REQUEST['ticket'] = $vals[1]; 


 global $CONFIG, $messages, $vars;
     require_once('lib.php');    
    
	// get module configuration

	$config = find_plugin_settings('cas_auth');
    $NetUsername = authCAS($config);


    // get user details out of LDAP.
    $attr = cas_ldapSearch($NetUsername);
 
    if (!empty($attr['textuid'])) {
        $username = $attr['textuid'];
    } else {
        $username = $NetUsername;
    }
 
    $user = get_user_by_username($username);
    
    if (!$user) {
      $user_guid = cas_insertUser($username, $attr, $config);
      $user = get_user_by_username($username);
      $result = cas_do_login($user, false);
    } else {
      $result = cas_do_login($user, false);
    }



 if ($result) {
            system_message(elgg_echo('loginok'));
            if ($_SESSION['last_forward_from'])
            {
            	$forward_url = $_SESSION['last_forward_from'];
            	$_SESSION['last_forward_from'] = "";
            	forward($forward_url);
            }
            else
            {
            	if (
            		(isadminloggedin()) &&
            		(!datalist_get('first_admin_login'))
            	) 
            	{
            		system_message(elgg_echo('firstadminlogininstructions'));
            		
            		datalist_set('first_admin_login', time());
            		
            		forward('pg/admin/plugins');
            	} else	
            		forward("pg/dashboard/");
            }
        } else {
        	$error_msg = elgg_echo('loginerror');
        	// figure out why the login failed
        	if (!empty($username) && !empty($password)) {
        		// See if it exists and is disabled
				$access_status = access_get_show_hidden_status();
				access_show_hidden_entities(true);
        		if (($user = get_user_by_username($username)) && !$user->validated) {
        			// give plugins a chance to respond
        			if (!trigger_plugin_hook('unvalidated_login_attempt','user',array('entity'=>$user))) {
        				// if plugins have not registered an action, the default action is to
        				// trigger the validation event again and assume that the validation
        				// event will display an appropriate message
						trigger_elgg_event('validate', 'user', $user);
        			}
        		} else {
        			 register_error(elgg_echo('loginerror'));
        		}
        		access_show_hidden_entities($access_status);
        	} else {
            	register_error(elgg_echo('loginerror'));
        	}
        }
    
    
    

    // check to see if user exists in Elgg
    
    
?>