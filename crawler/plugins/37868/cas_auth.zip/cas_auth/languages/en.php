<?php

    /**
	 * Elgg LDAP authentication
	 * 
	 * @package ElggLDAPAuth
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Misja Hoebe <misja@elgg.com>
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com
	 */

    $en = array(
        'cas:settings:cas:label:host' => "CAS Settings",
        'cas:settings:cas:label:hostname'=>"CAS Hostname",
        'cas:settings:cas:help:hostname' => "The hostname for the CAS server.  For example, cas.domain.com",
        'cas:settings:cas:label:port'=>"CAS Port",
        'cas:settings:cas:help:port' => "The port CAS communicates on.  The default value is 443",
        'cas:settings:cas:label:baseuri' => "Base URI for CAS",
        'cas:settings:cas:adminuser' => "CAS User to set as admin",
        'cas:settings:cas:help:casadminuser' => "When this user logs in for the first time, they will be made admin.",
        'cas:settings:cas:help:baseuri' => "The directory CAS can be accessed in.  The default value is /cas",
        'cas:settings:cas:label:createuser' => "Create user in ELGG database",
        'cas:settings:cas:help:createuser' => "When logging in for the first time, a user account will be created in the Elgg database if this is enabled.",
        'cas:settings:cas:label:logout' => "Logout from CAS when logging out",
        'cas:settings:cas:help:logout' => "If enabled, Elgg will log the user out of CAS when logging out of the system.",
        'cas:settings:cas:settings' => "CAS-specific settings",
        'cas:settings:ldap:label:host' => "Host settings",
        'cas:settings:ldap:label:connection_search' => "LDAP settings",
        'cas:settings:ldap:label:hostname' => "LDAP Hostname",
        'cas:settings:ldap:help:hostname' => "Enter the canonical hostname, for example <i>ldap.yourcompany.com</i>",
        'cas:settings:ldap:label:port' => "The LDAP server port",
    	'cas:settings:ldap:help:port' => "The LDAP server port. Defaults is 389, which mosts hosts will use.",
        'cas:settings:ldap:label:version' => "LDAP protocol version",
        'cas:settings:ldap:help:version' => "LDAP protocol version. Defaults to 3, which most current LDAP hosts will use.",
        'cas:settings:ldap:label:ldap_bind_dn' => "LDAP bind DN",
        'cas:settings:ldap:help:ldap_bind_dn' => "Which DN to use for a non-anonymous bind, for exampe <i>cn=admin,dc=yourcompany,dc=com</i>",
        'cas:settings:ldap:label:ldap_bind_pwd' => "LDAP bind password",
        'cas:settings:ldap:help:ldap_bind_pwd' => "Which password to use when performing a non-anonymous bind.",
        'cas:settings:ldap:label:basedn' => "Base DN",
        'cas:settings:ldap:help:basedn' => "The base DN. Separate with a colon (:) to enter multiple DNs, for example <i>dc=yourcompany,dc=com : dc=othercompany,dc=com</i>",
        'cas:settings:ldap:label:filter_attr' => "Username filter attribute",
        'cas:settings:ldap:help:filter_attr' => "The filter to use for the username, common are <i>cn</i>, <i>uid</i> or <i>sAMAccountName</i>.",
        'cas:settings:ldap:label:search_attr' => "Search attributes",
        'cas:settings:ldap:help:search_attr' => "Enter search attibutes as key, value pairs with the key being the attribute description, and the value being the actual LDAP attribute.
         <i>firstname</i>, <i>lastname</i> and <i>mail</i> are used to create the Elgg user profile. The following example will work for ActiveDirectory:
         <p><br/>&nbsp;&nbsp; <i>firstname:givenname, lastname:sn, mail:mail</i></p><br/>",
        'cas:settings:ldap:label:user_create' => "Create users",
        'cas:settings:ldap:help:user_create' => "Optionally, an account can get created when a LDAP authentication was succesful.",
        'cas:errors:ldap:no_account' => "Your credentials are valid, but no account was found - please contact the system administrator",
        'cas:errors:ldap:no_register' => 'An account could not get created for you - please contact the system administrator.'
    );
    
    add_translation('en', $en);
?>
