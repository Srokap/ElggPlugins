<?php

/* ***********************************************************************
 * Custom System Messages Plugin
 *
 * @author : Robert Rebich
 * @link http://community.elgg.org/pg/profile/robtotoreb
 * @link http://www.climbnrun.com/
 *
 * Please reccomend if you like the plugin
 * Please report any comment or bugs to the plugin page where you download this from.
 * Hope you enjoy!!!
 *
 * ***********************************************************************/

elgg_register_event_handler('init', 'system', 'custom_system_message_init', 1001);

function custom_system_message_init() {

	// Extend system message CSS with our own styles
	elgg_extend_view('css/elgg', 'custom_system_message/css');
	
	
	// Extend system message javascript with our own styles
	elgg_extend_view('js/elgg', 'custom_system_message/js');
	
}

