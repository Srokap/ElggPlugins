<?php

/* ***********************************************************************
 * Custom System Messages Plugin
 *
 * @author : Robert Rebich
 * @link http://community.elgg.org/pg/profile/robtotoreb
 *
 * Extend system message CSS
 *
 * ***********************************************************************/


// get plugin settings
$success_background = elgg_get_plugin_setting('success_background',  'custom_system_message');
$error_background = elgg_get_plugin_setting('error_background',  'custom_system_message');
$notice_background = elgg_get_plugin_setting('notice_background',  'custom_system_message');
$success_text = elgg_get_plugin_setting('success_text',  'custom_system_message');
$error_text = elgg_get_plugin_setting('error_text',  'custom_system_message');
$notice_text = elgg_get_plugin_setting('notice_text',  'custom_system_message');



?>

/*******************************
	Custom System Message
********************************/

.elgg-message {
	font-weight: bold;
	display: block;
	padding: 3px 10px;
	cursor: pointer;
	opacity: 0.9;
	
	-webkit-box-shadow: 0 2px 5px rgba(0, 0, 0, 0.45);
	-moz-box-shadow: 0 2px 5px rgba(0, 0, 0, 0.45);
	box-shadow: 0 2px 5px rgba(0, 0, 0, 0.45);
	
	-webkit-border-radius: 8px;
	-moz-border-radius: 8px;
	border-radius: 8px;
	
	text-align:left;
	padding:10px;
	z-index: 2000;
}
.elgg-state-success {
	color: <? echo $success_text; ?>;
	background-color: <? echo $success_background; ?>;
}
.elgg-state-error {
	color: <? echo $error_text; ?>;
	background-color: <? echo $error_background; ?>;
}
.elgg-state-notice {
	color: <? echo $notice_text; ?>;
	background-color: <? echo $notice_background; ?>;
}



