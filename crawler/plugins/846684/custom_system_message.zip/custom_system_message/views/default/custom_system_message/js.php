<?php 

/* ***********************************************************************
 * Custom System Messages Plugin
 *
 * @author : Robert Rebich
 * @link http://community.elgg.org/pg/profile/robtotoreb
 *
 * Extend system message javascript in js/lib/elgglib.js
 *
 * ***********************************************************************/

// get plugin settings
$delay_time = elgg_get_plugin_setting('delay_time',  'custom_system_message');
$delay_opacity = elgg_get_plugin_setting('delay_opacity',  'custom_system_message');

// convert to miliseconds 
$delay_time = $delay_time*1000;

?>
   
elgg.provide('elgg.custom_system_message');

elgg.custom_system_message.init = function() {
	$('.elgg-system-messages li').stop().animate({opacity: <? echo $delay_opacity; ?>}, <? echo $delay_time; ?>);
	$('.elgg-system-messages li').stop().fadeOut('slow');
}

elgg.register_hook_handler('init', 'system', elgg.custom_system_message.init);