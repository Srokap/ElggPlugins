<?php

/* ***********************************************************************
 * @author : Robert Rebich
 * @link http://community.elgg.org/pg/profile/robtotoreb
 * Under this agreement, No one has rights to sell this script further.
 * ***********************************************************************/


$english = array(
	// titles
	'custom_system_message:delaytime' => 'System message display time [seconds, default 6].',
	'custom_system_message:delayopacity' => 'Fade opacity [number, 0 to 1, default 0.8].',
	'custom_system_message:success_background' => 'Color of success message background [hex, default #41FF3A].',
	'custom_system_message:error_background' => 'Color of error message background [hex, default #FF0000].',
	'custom_system_message:notice_background' => 'Color of notice message background [hex, default #4690D6].',
	'custom_system_message:success_text' => 'Color of success message text [hex, default #000000].',
	'custom_system_message:error_text' => 'Color of error message text [hex, default #FFFFFF].',
	'custom_system_message:notice_text' => 'Color of notice message text [hex, default #FFFFFF].',
	'custom_system_message:delay_title' => 'General Message Settings',
	'custom_system_message:success_title' => 'Success Message Settings',
	'custom_system_message:error_title' => 'Error Message Settings',
	'custom_system_message:notice_title' => 'Notice Message Settings',
);

add_translation("en", $english);
