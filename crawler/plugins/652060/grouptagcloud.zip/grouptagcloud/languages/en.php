<?php 
	$english = array(
	
		// grouptagcloud widget - add-in to group custom layout plugin
		//settings
		'group_custom_layout:widgets:tagcloud:settings:title' => "Group tagcloud settings",
		'group_custom_layout:widgets:tagcloud:settings:tag_count' => "Number of tags to display",
		'group_custom_layout:widgets:tagcloud:settings:name' => "Widget title to display",
		'group_custom_layout:widgets:tagcloud:settings:tag_sort' => "Sort order",

		//widget
		'group_custom_layout:widgets:tagcloud:title' => "Group tagcloud",
		'group_custom_layout:widgets:tagcloud:description' => "Show the group tagcloud",
	);
	
	add_translation("en", $english);
?>
