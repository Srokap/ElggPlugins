<?php
	// addin to group custom layout to provide a tag cloud: Jon Dron
	// Default event handlers for plugin functionality
	if(is_plugin_enabled("group_custom_layout")){  
		
		function grouptagcloud_init(){
		
			add_group_widget("tagcloud", elgg_echo("group_custom_layout:widgets:tagcloud:description"));	
		}	
		register_elgg_event_handler('init', 'system', 'grouptagcloud_init');
	}

?>