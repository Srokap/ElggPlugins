<?php 
	$entity = $vars["entity"];
	
	if(!empty($entity) && $entity instanceof ElggObject && $entity->getSubtype() == GROUP_CUSTOM_LAYOUT_WIDGET){
		$widget_name = $entity->guid;
		$tag_count = $entity->tag_count;
		$tag_sort=$entity->tag_sort;
	} else {
		$widget_name = $vars["widget_name"];
		$tag_count = 10;
		$tag_sort="random"; // can't figure out how to make this work - code commented out below till I can
	}
	//create option list for number of tags to show
	$options = "";
	for($i = 5; $i <= 100; $i+=5){
		if($i == $tag_count){
			$options .= "<option value='" . $i . "' selected='yes'>" . $i . "</option>\n";
		} else {
			$options .= "<option value='" . $i . "'>" . $i . "</option>\n";
		}
	}
	// create option list for sorting of tag cloud
/* commented out for now

	$sort=array("alpha","random","count");
	$sortoptions="";
	foreach($sort as $cloudtype){
		if($cloudtype==$tag_sort){
			$sortoptions .= "<option value='" . $cloudtype . "' selected='yes'>" . $cloudtype . "</option>\n";
		}else{
			$sortoptions .= "<option value='" . $cloudtype . "'>" . $cloudtype . "</option>\n";	
		}
	}
*/	
?>
<h3 class="settings"><?php echo elgg_echo("group_custom_layout:widgets:tagcloud:settings:title"); ?></h3>
<div>
	<?php echo elgg_echo("group_custom_layout:widgets:tagcloud:settings:name"); ?><br />
	<input type="text" name="group_widgets_<?php echo $widget_name; ?>_settings[widget_title]" value="<?php echo $entity->widget_title; ?>" size="40" maxlength="250"/><br />
	<?php echo elgg_echo("group_custom_layout:widgets:tagcloud:settings:tag_count"); ?>
	<select name="group_widgets_<?php echo $widget_name; ?>_settings[tag_count]">
		<?php echo $options; ?>
	</select>
	<?php /* commented out for now...
	 echo elgg_echo("group_custom_layout:widgets:tagcloud:settings:tag_sort"); ?>
	<select name="group_widgets_<?php echo $widget_name; ?>_settings[tag_sort]">
		<?php echo $sortoptions; ?>
	</select>
	*/
	?>	
</div>