<div class="group_widget">
<?php
	$group = $vars["group"];
	$widget=$vars["widget"];
	$widget_name=filter_tags($widget->widget_title);
	$num_items= $widget->tag_count;
//sortable tags are available in the tagcloud plugin but I can't work out how to implement them
// code left in just in case it becomes clear later - Jon Dron
//	$tag_sort=$widget->tag_sort;
	
if(!empty($widget_name)){
	echo "<h2>" . $widget_name . "</h2>";
}else{
?>
	<h2><?php echo elgg_echo('group_custom_layout:widgets:tagcloud:title'); ?></h2>
<?php
}
?>
    <?php
		$threshold = 1;
		if (!isset($num_items)){
			$num_items=30;
		}	
		$metadata_name="tags";
		$maintype = "object";
		$subtype="";
		if (is_plugin_enabled("tagcloud")){
/* this is for the sort option, not currently available	- Jon Dron		
			echo tagcloud/tagcloud_create_cloud($num_items, $group->guid,0,$tag_sort,1);
		}else{
*/		
	 		echo display_tagcloud($threshold, $num_items, $metadata_name, $maintype, $subtype, $group->guid, -1);
		}

    ?>

    <div class="clearfloat">
	</div>
</div>

