<?php

	$backwardsenglish = array(
	
	'blog' => 'golB',
  'blogs' => 'sgolB',
  'blog:user' => 'golb s\'%s',
  'blog:user:friends' => 'golb \'sdneirf s\'%s',
  'blog:your' => 'golb ruoY',
  'blog:posttitle' => '%s :golb %s\'s',
  'blog:friends' => 'sgolb  \'sdneirF',
  'blog:yourfriends' => 'sgolb etis llA',
  'blog:everyone' => 'sgolb etis llA',
  'blog:newpost' => 'tsop golb weN',
  'blog:via' => 'golb aiv',
  'blog:read' => 'golb daeR',
  'blog:addpost' => 'tsop golb a etirW',
  'blog:editpost' => 'tsop golb tidE',
  'blog:text' => 'txet golB',
  'blog:strapline' => '%s',
  'item:object:blog' => 'stsop golB',
  'blog:never' => 'reven',
  'blog:preview' => 'weiverP',
  'blog:draft:save' => 'tfard evaS',
  'blog:draft:saved' => 'devas tsal tfarD',
  'blog:comments:allow' => 'stnemmoc wollA',
  'blog:preview:description' => '.tsop golb ruoy fo weiverp devasnu na si sihT',
  'blog:preview:description:link' => '.ereh kcilc ,tsop ruoy evas ro gnitide eunitnoc oT',
  'blog:enableblog' => 'golb puorg elbanE',
  'blog:group' => 'golb puorG',
  'blog:river:created' => 'etorw %s',
  'blog:river:updated' => 'detadpu %s',
  'blog:river:posted' => 'detsop %s',
  'blog:river:create' => 'deltit tsop golb wen a',
  'blog:river:update' => 'deltit tsop golb a',
  'blog:river:annotate' => 'tsop golb siht no tnemmoc a',
  'blog:posted' => '.detsop yllufsseccus saw tsop golb ruoY',
  'blog:deleted' => '.deteled yllufsseccus saw tsop golb ruoY',
  'blog:error' => '.niaga yrt esaelP .gnorw tnew gnihtemoS',
  'blog:save:failure' => '.niaga yrt esaelP .devas eb ton dluoc tsop golb ruoY',
  'blog:blank' => '.tsop a ekam nac uoy erofeb ydob dna eltit eht htob ni llif ot deen uoy ;yrroSyrroS',
  'blog:notfound' => '.tsop golb deificeps eht dnif ton dluoc ew ;yrroS',
  'blog:notdeleted' => '.tsop golb siht eteled ton dluoc ew ;yrroS',
	
	);
					
	add_translation("eb",$backwardsenglish);

?>