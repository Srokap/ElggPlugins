<?php

$backwardsenglish = array( 'ckeditor:admin_title' => "rotidEKC erugifnoC");	
add_translation("eb",$backwardsenglish);

?>
