<?php

	$simplifiedchinese = array(

		/**
		 * Sites
		 */
	
			'item:site' => 'Sites',
	
		/**
		 * Sessions
		 */
			
			'login' => "登录",
			'loginok' => "你已成功登录。",
			'loginerror' => "登录失败。这可能是因为你没有有效帐号，也可能是你提供的帐号或密码错误，请确认后重新操作。",
	
			'logout' => "登出",
			'logoutok' => "你已成功登出。",
			'logouterror' => "登出失败，请重新操作。",
	
		/**
		 * Errors
		 */
			'exception:title' => "欢迎来到ShowUp.me",
	
			'InstallationException:CantCreateSite' => "Unable to create a default ElggSite with credentials Name:%s, Url: %s",
		
			'actionundefined' => "系统未定义你访问的动作 (%s) 。",
			'actionloggedout' => "对不起，未登录不能执行这个动作。",
	
			'notfound' => "请求的资源不存在，或者你没有访问权限。",
			
			'SecurityException:Codeblock' => "Denied access to execute privileged code block",
			'DatabaseException:WrongCredentials' => "Elgg couldn't connect to the database using the given credentials %s@%s (pw: %s).",
			'DatabaseException:NoConnect' => "Elgg couldn't select the database '%s', please check that the database is created and you have access to it.",
			'SecurityException:FunctionDenied' => "Access to privileged function '%s' is denied.",
			'DatabaseException:DBSetupIssues' => "There were a number of issues: ",
			'DatabaseException:ScriptNotFound' => "Elgg couldn't find the requested database script at %s.",
			
			'IOException:FailedToLoadGUID' => "Failed to load new %s from GUID:%d",
			'InvalidParameterException:NonElggObject' => "Passing a non-ElggObject to an ElggObject constructor!",
			'InvalidParameterException:UnrecognisedValue' => "Unrecognised value passed to constuctor.",
			
			'InvalidClassException:NotValidElggStar' => "GUID:%d is not a valid %s",
			
			'PluginException:MisconfiguredPlugin' => "%s is a misconfigured plugin.",
			
			'InvalidParameterException:NonElggUser' => "Passing a non-ElggUser to an ElggUser constructor!",
			
			'InvalidParameterException:NonElggSite' => "Passing a non-ElggSite to an ElggSite constructor!",
			
			'InvalidParameterException:NonElggGroup' => "Passing a non-ElggGroup to an ElggGroup constructor!",
	
			'IOException:UnableToSaveNew' => "Unable to save new %s",
			
			'InvalidParameterException:GUIDNotForExport' => "GUID has not been specified during export, this should never happen.",
			'InvalidParameterException:NonArrayReturnValue' => "Entity serialisation function passed a non-array returnvalue parameter",
			
			'ConfigurationException:NoCachePath' => "Cache path set to nothing!",
			'IOException:NotDirectory' => "%s is not a directory.",
			
			'IOException:BaseEntitySaveFailed' => "Unable to save new object's base entity information!",
			'InvalidParameterException:UnexpectedODDClass' => "import() passed an unexpected ODD class",
			'InvalidParameterException:EntityTypeNotSet' => "Entity type must be set.",
			
			'ClassException:ClassnameNotClass' => "%s is not a %s.",
			'ClassNotFoundException:MissingClass' => "Class '%s' was not found, missing plugin?",
			'InstallationException:TypeNotSupported' => "Type %s is not supported. This indicates an error in your installation, most likely caused by an incomplete upgrade.",

			'ImportException:ImportFailed' => "Could not import element %d",
			'ImportException:ProblemSaving' => "There was a problem saving %s",
			'ImportException:NoGUID' => "New entity created but has no GUID, this should not happen.",
			
			'ImportException:GUIDNotFound' => "Entity '%d' could not be found.",
			'ImportException:ProblemUpdatingMeta' => "There was a problem updating '%s' on entity '%d'",
			
			'ExportException:NoSuchEntity' => "No such entity GUID:%d", 
			
			'ImportException:NoODDElements' => "No OpenDD elements found in import data, import failed.",
			'ImportException:NotAllImported' => "Not all elements were imported.",
			
			'InvalidParameterException:UnrecognisedFileMode' => "Unrecognised file mode '%s'",
			'InvalidParameterException:MissingOwner' => "All files must have an owner!",
			'IOException:CouldNotMake' => "Could not make %s",
			'IOException:MissingFileName' => "You must specify a name before opening a file.",
			'ClassNotFoundException:NotFoundNotSavedWithFile' => "Filestore not found or class not saved with file!",
			'NotificationException:NoNotificationMethod' => "No notification method specified.",
			'NotificationException:NoHandlerFound' => "No handler found for '%s' or it was not callable.",
			'NotificationException:ErrorNotifyingGuid' => "There was an error while notifying %d",
			'NotificationException:NoEmailAddress' => "Could not get the email address for GUID:%d",
			'NotificationException:MissingParameter' => "Missing a required parameter, '%s'",
			
			'DatabaseException:WhereSetNonQuery' => "Where set contains non WhereQueryComponent",
			'DatabaseException:SelectFieldsMissing' => "Fields missing on a select style query",
			'DatabaseException:UnspecifiedQueryType' => "Unrecognised or unspecified query type.",
			'DatabaseException:NoTablesSpecified' => "No tables specified for query.",
			'DatabaseException:NoACL' => "No access control was provided on query",
			
			'InvalidParameterException:NoEntityFound' => "No entity found, it either doesn't exist or you don't have access to it.",
			
			'InvalidParameterException:GUIDNotFound' => "GUID:%s could not be found, or you can not access it.",
			'InvalidParameterException:IdNotExistForGUID' => "Sorry, '%s' does not exist for guid:%d",
			'InvalidParameterException:CanNotExportType' => "Sorry, I don't know how to export '%s'",
			'InvalidParameterException:NoDataFound' => "Could not find any data.",
			'InvalidParameterException:DoesNotBelong' => "Does not belong to entity.",
			'InvalidParameterException:DoesNotBelongOrRefer' => "Does not belong to entity or refer to entity.",
			'InvalidParameterException:MissingParameter' => "Missing parameter, you need to provide a GUID.",
			
			'SecurityException:APIAccessDenied' => "Sorry, API access has been disabled by the administrator.",
			'SecurityException:NoAuthMethods' => "No authentication methods were found that could authenticate this API request.",
			'APIException:ApiResultUnknown' => "API Result is of an unknown type, this should never happen.", 
			
			'ConfigurationException:NoSiteID' => "No site ID has been specified.",
			'InvalidParameterException:UnrecognisedMethod' => "Unrecognised call method '%s'",
			'APIException:MissingParameterInMethod' => "Missing parameter %s in method %s",
			'APIException:ParameterNotArray' => "%s does not appear to be an array.",
			'APIException:UnrecognisedTypeCast' => "Unrecognised type in cast %s for variable '%s' in method '%s'",
			'APIException:InvalidParameter' => "Invalid parameter found for '%s' in method '%s'.",
			'APIException:FunctionParseError' => "%s(%s) has a parsing error.",
			'APIException:FunctionNoReturn' => "%s(%s) returned no value.",
			'SecurityException:AuthTokenExpired' => "Authentication token either missing, invalid or expired.",
			'CallException:InvalidCallMethod' => "%s must be called using '%s'",
			'APIException:MethodCallNotImplemented' => "Method call '%s' has not been implemented.",
			'APIException:AlgorithmNotSupported' => "Algorithm '%s' is not supported or has been disabled.",
			'ConfigurationException:CacheDirNotSet' => "Cache directory 'cache_path' not set.",
			'APIException:NotGetOrPost' => "Request method must be GET or POST",
			'APIException:MissingAPIKey' => "Missing X-Elgg-apikey HTTP header",
			'APIException:MissingHmac' => "Missing X-Elgg-hmac header",
			'APIException:MissingHmacAlgo' => "Missing X-Elgg-hmac-algo header",
			'APIException:MissingTime' => "Missing X-Elgg-time header",
			'APIException:TemporalDrift' => "X-Elgg-time is too far in the past or future. Epoch fail.",
			'APIException:NoQueryString' => "No data on the query string",
			'APIException:MissingPOSTHash' => "Missing X-Elgg-posthash header",
			'APIException:MissingPOSTAlgo' => "Missing X-Elgg-posthash_algo header",
			'APIException:MissingContentType' => "Missing content type for post data",
			'SecurityException:InvalidPostHash' => "POST data hash is invalid - Expected %s but got %s.",
			'SecurityException:DupePacket' => "Packet signature already seen.",
			'SecurityException:InvalidAPIKey' => "Invalid or missing API Key.",
			'NotImplementedException:CallMethodNotImplemented' => "Call method '%s' is currently not supported.",
	
			'NotImplementedException:XMLRPCMethodNotImplemented' => "XML-RPC method call '%s' not implemented.",
			'InvalidParameterException:UnexpectedReturnFormat' => "Call to method '%s' returned an unexpected result.",
			'CallException:NotRPCCall' => "Call does not appear to be a valid XML-RPC call",
	
			'PluginException:NoPluginName' => "The plugin name could not be found",
	
			'ConfigurationException:BadDatabaseVersion' => "The database backend you have installed doesn't meet the basic requirements to run Elgg. Please consult your documentation.",
			'ConfigurationException:BadPHPVersion' => "You need at least PHP version 5.2 to run Elgg.",
			
	
			'InstallationException:DatarootNotWritable' => "Your data directory %s is not writable.",
			'InstallationException:DatarootUnderPath' => "Your data directory %s must be outside of your install path.",
			'InstallationException:DatarootBlank' => "You have not specified a data directory.",
	
		/**
		 * User details
		 */

			'name' => "昵称",
			'email' => "Email地址",
			'username' => "用户名",
			'password' => "密码",
			'passwordagain' => "密码(确认)",
			'admin_option' => "是否把这个用户作为管理员？",
	
		/**
		 * Access
		 */
	
			'ACCESS_PRIVATE' => "私有的",
			'ACCESS_LOGGED_IN' => "登录用户",
			'ACCESS_PUBLIC' => "公开的",
			'PRIVATE' => "私有的",
			'LOGGED_IN' => "登录用户",
			'PUBLIC' => "公开的",
			'access' => "访问",
	
		/**
		 * Dashboard and widgets
		 */
	
			'dashboard' => "起点站",
			'dashboard:nowidgets' => "你的起点站是你访问本站的一个起始位置。点击 '编辑页面' 来增加功能区块，以便开始你在本站的快乐生活。",

			'widgets:add' => '添加功能区块到你的页面',
			'widgets:add:description' => "选择你需要的功能区块，然后把它从右边的<b>功能区块列表</b>拖动到你的页面上去，并且可以调整位置。

要从页面删除一个功能区块，直接把它拖回<b>功能区块列表</b>即可。",
			'widgets:position:fixed' => '(页面上的固定位置)',
	
			'widgets' => "功能块",
			'widget' => "功能块",
			'item:object:widget' => "功能块",
			'layout:customise' => "修改布局",
			'widgets:gallery' => "可用功能块",
			'widgets:leftcolumn' => "左边栏",
			'widgets:fixed' => "固定位置",
			'widgets:middlecolumn' => "中间栏",
			'widgets:rightcolumn' => "右边栏",
			'widgets:profilebox' => "个人档案",
			'widgets:panel:save:success' => "功能块已经成功保存。",
			'widgets:panel:save:failure' => "保存功能块出错，请重试。",
			'widgets:save:success' => "功能块已经成功保存。",
			'widgets:save:failure' => "保存功能块出错，请重试。",
			
	
		/**
		 * Groups
		 */
	
			'group' => "群组", 
			'item:group' => "群组",
	
		/**
		 * Profile
		 */
	
			'profile' => "个人档案",
			'user' => "用户",
			'item:user' => "用户",

		/**
		 * Profile menu items and titles
		 */
	
			'profile:yours' => "个人档案",
			'profile:user' => "%s 的个人档案",
	
			'profile:edit' => "编辑个人档案",
			'profile:editicon' => "上传个人照片",
			'profile:profilepictureinstructions' => "个人照片是显示在你的个人资料上的那张图片。 <br /> 你可以自由修改。(文件格式: GIF, JPG, PNG)",
			'profile:icon' => "个人照片",
			'profile:createicon' => "创建头像",
			'profile:currentavatar' => "目前头像",
			'profile:createicon:header' => "个人照片",
			'profile:profilepicturecroppingtool' => "个人照片裁切工具",
			'profile:createicon:instructions' => "点击鼠标左键然后拖拽出一个矩形框来选择你想要的图像内容。右边框内将显示裁切后的效果。如果满意, 点击 '创建头像'。之后这裁切好的图片将成为你的头像。",
	
			'profile:editdetails' => "修改详细信息",
			'profile:editicon' => "修改头像",
	
			'profile:aboutme' => "关于我", 
			'profile:description' => "自我介绍",
			'profile:briefdescription' => "简要说明",
			'profile:location' => "地域",
			'profile:skills' => "特长",  
			'profile:interests' => "兴趣", 
			'profile:contactemail' => "电子邮件",
			'profile:phone' => "电话",
			'profile:mobile' => "手机",
			'profile:website' => "网址",

			'profile:river:update' => "%s 已更新个人档案",
			'profile:river:iconupdate' => "%s 已更新个人头像",
	
		/**
		 * Profile status messages
		 */
	
			'profile:saved' => "你的个人档案保存成功。",
			'profile:icon:uploaded' => "你的个人图片上传成功。",
	
		/**
		 * Profile error messages
		 */
	
			'profile:noaccess' => "你没有权限修改此个人档案。",
			'profile:notfound' => "未能找到指定的个人档案。",
			'profile:cantedit' => "对不起，你没有权限修改这个个人档案。",
			'profile:icon:notfound' => "对不起，上传个人图片碰到问题。",
	
		/**
		 * Friends
		 */
	
			'friends' => "好友",
			'friends:yours' => "你的好友",
			'friends:owned' => "%s 的好友",
			'friend:add' => "添加好友",
			'friend:remove' => "删除好友",
	
			'friends:add:successful' => "%s已成功加为好友。",
			'friends:add:failure' => "添加 %s 为好友失败。请重试。",
	
			'friends:remove:successful' => "%s 已从好友列表删除。",
			'friends:remove:failure' => "从好友列表删除 %s 失败。请重试。",
	
			'friends:none' => "这个用户还没添加任何好友。",
			'friends:none:you' => "你还没添加任何好友！搜索你兴趣相投的人加入吧。",
	
			'friends:none:found' => "未能找到任何好友。",
	
			'friends:of:none' => "还没人加这个用户为好友。",
			'friends:of:none:you' => "还没人加你为好友。赶紧完善个人资料和添加你的内容，以便别人能找到你啊！",
	
			'friends:of' => "我是谁的好友",
			'friends:of:owned' => "已把 %s 加为好友的人",

			 'friends:num_display' => "显示条目数量",
			 'friends:icon_size' => "头像大小",
			 'friends:tiny' => "很小",
			 'friends:small' => "小",
			 'friends' => "好友",
			 'friends:of' => "我是谁的好友",
			 'friends:collections' => "好友集",
			 'friends:collections:add' => "新建好友集",
			 'friends:addfriends' => "添加好友",
			 'friends:collectionname' => "好友集名称",
			 'friends:collectionfriends' => "好友集里面的好友",
			 'friends:collectionedit' => "编辑好友集",
			 'friends:nocollections' => "你还没有建立任何好友集。",
			 'friends:collectiondeleted' => "你的好友集已经被删除。",
			 'friends:collectiondeletefailed' => "不能删除好友集。可能是因为你没有权限，也可能发生了其他错误。",
			 'friends:collectionadded' => "你的好友集已成功建立。",
			 'friends:nocollectionname' => "必须要给你的好友集起个名字。",
		
	        'friends:river:created' => "%s 添加了好友功能块。",
	        'friends:river:updated' => "%s 更新了好友功能块。",
	        'friends:river:delete' => "%s 移除了好友功能块。",
	        'friends:river:add' => "%s 新添加了某人为好友。",
	
		/**
		 * Feeds
		 */
			'feed:rss' => '订阅',
			'feed:odd' => '同步数据(OpenDD)',
	
		/**
		 * River
		 */
			'river' => "River",			
			'river:relationship:friend' => 'is now friends with',

		/**
		 * Plugins
		 */
			'plugins:settings:save:ok' => "已成功保存对 %s plugin 的设置。",
			'plugins:settings:save:fail' => "保存对 %s plugin 的设置时出错。",
			'plugins:usersettings:save:ok' => "已成功保存对 %s plugin用户设置。",
			'plugins:usersettings:save:fail' => "保存对 %s plugin 的用户设置时出错。",
			
		/**
		 * Notifications
		 */
			'notifications:usersettings' => "提醒设置",
			'notifications:methods' => "请选择你允许的方法。",
	
			'notifications:usersettings:save:ok' => "你的提醒设置已成功保存。",
			'notifications:usersettings:save:fail' => "保存你的提醒设置时出错。",
		/**
		 * Search
		 */
	
			'search' => "搜索",
			'searchtitle' => "搜索: %s",
			'users:searchtitle' => "搜索用户: %s",
			'advancedsearchtitle' => "%s with results matching %s",
			'notfound' => "无搜索结果。",
			'next' => "下一步",
			'previous' => "上一步",
	
			'viewtype:change' => "改变列表方式",
			'viewtype:list' => "列表显示",
			'viewtype:gallery' => "陈列显示",
	
			'tag:search:startblurb' => "具有 '%s' tag的对象:",

			'user:search:startblurb' => "符合 '%s' 的用户:",
			'user:search:finishblurb' => "要看更多，点击此处。",
	
		/**
		 * Account
		 */
	
			'account' => "账户",
			'settings' => "设置",
	
			'register' => "注册",
			'registerok' => "你已成功注册 %s. 要激活你的帐号，请到检查你之前填写的邮箱并点击里面收到的链接。",
			'registerbad' => "注册未成功。可能因为你选的用户名已存在，或者因为你的两个密码不一致，也可能你填写的用户名和密码太短。",
			'registerdisabled' => "注册功能已被管理员禁止",
	
			'registration:notemail' => '你提供的email地址不像是有效的email地址。',
			'registration:userexists' => '用户名已存在',
			'registration:usernametooshort' => '用户名至少需要4个字符。',
			'registration:passwordtooshort' => '密码至少需要6个字符。',
			'registration:dupeemail' => '这个email地址已经被注册使用了。',
	
			'adduser' => "添加用户",
			'adduser:ok' => "你已成功添加一个新用户。",
			'adduser:bad' => "不能建立新用户。",
			
			'item:object:reported_content' => "报告中的对象",
	
			'user:set:name' => "账户名称设置",
			'user:name:label' => "昵称",
			'user:name:success' => "已成功设置你的昵称。",
			'user:name:fail' => "不能改变你的昵称。",
	
			'user:set:password' => "账户密码",
			'user:password:label' => "新密码",
			'user:password2:label' => "新密码(确认)",
			'user:password:success' => "密码已修改",
			'user:password:fail' => "不能改变密码。",
			'user:password:fail:notsame' => "新密码和确认新密码不一致！",
			'user:password:fail:tooshort' => "密码太短了！",
	
			'user:set:language' => "语言设置",
			'user:language:label' => "你的语言",
			'user:language:success' => "你的语言设置已保存。",
			'user:language:fail' => "不能保存你的语言设置。",
	
			'user:username:notfound' => '为找到用户名 %s ',
	
			'user:password:lost' => '忘记密码？',
			'user:password:resetreq:success' => '你的新密码已通过email发出',
			'user:password:resetreq:fail' => '不能获取新密码。',
	
			'user:password:text' => '如要获取新密码，在下面输入你的用户名。你将收到一封重置密码的email，点击邮件内的链接之后你将收到新的密码',
	
		/**
		 * Administration
		 */

			'admin:configuration:success' => "你的设置已保存。",
			'admin:configuration:fail' => "你的设置不能被保存。",
	
			'admin' => "系统管理",
			'admin:description' => "管理界面能让你管理系统从用户管理直到plugin的各个方面。选择下面的一项开始。",
			
			'admin:user' => "用户管理",
			'admin:user:description' => "管理站点的用户设置。 选择下面的一项开始。",
			'admin:user:adduser:label' => "点击这里添加用户...",
			'admin:user:opt:linktext' => "配置用户...",
			'admin:user:opt:description' => "配置用户和账户信息。",
			
			'admin:site' => "站点管理",
			'admin:site:description' => "管理站点的总体设置。选择下面的一项开始。",
			'admin:site:opt:linktext' => "配置站点...",
			'admin:site:opt:description' => "配置站点的技术和非技术的各个设置。",
			
			'admin:plugins' => "工具管理",
			'admin:plugins:description' => "管理站点上安装的工具。",
			'admin:plugins:opt:linktext' => "配置工具...",
			'admin:plugins:opt:description' => "配置站点上安装的工具",
			'admin:plugins:label:author' => "作者",
			'admin:plugins:label:copyright' => "版权",
			'admin:plugins:label:licence' => "授权",
			'admin:plugins:label:website' => "URL",
			'admin:plugins:disable:yes' => "Plugin %s 已禁止。",
			'admin:plugins:disable:no' => "Plugin %s 不能被禁止。",
			'admin:plugins:enable:yes' => "Plugin %s 已激活",
			'admin:plugins:enable:no' => "Plugin %s 不能被激活。",
	
			'admin:statistics' => "统计信息",
			'admin:statistics:description' => "站点的总体统计信息。如果你需要更详细的统计信息，有更专业的管理功能可用。",
			'admin:statistics:opt:description' => "查看你站点上的用户和对象的统计信息。",
			'admin:statistics:opt:linktext' => "查看统计...",
			'admin:statistics:label:basic' => "基本统计信息",
			'admin:statistics:label:numentities' => "站点上的实体",
			'admin:statistics:label:numusers' => "用户数量",
			'admin:statistics:label:numonline' => "在线用户数量",
			'admin:statistics:label:onlineusers' => "在线用户列表",
			'admin:statistics:label:version' => "Elgg 版本",
			'admin:statistics:label:version:release' => "Release",
			'admin:statistics:label:version:version' => "Version",
	
			'admin:user:label:search' => "查找用户:",
			'admin:user:label:seachbutton' => "搜索", 
	
			'admin:user:ban:no' => "不能禁用用户",
			'admin:user:ban:yes' => "用户已被禁用。",
			'admin:user:unban:no' => "不能开禁用户",
			'admin:user:unban:yes' => "用户已被开禁。",
			'admin:user:delete:no' => "不能删除用户",
			'admin:user:delete:yes' => "用户已删除",
	
			'admin:user:resetpassword:yes' => "密码重置，用户已通知。",
			'admin:user:resetpassword:no' => "不能重置密码。",
	
			'admin:user:makeadmin:yes' => "用户已被设为管理员。",
			'admin:user:makeadmin:no' => "不能设置此用户为管理员。",
			
		/**
		 * User settings
		 */
			'usersettings:description' => "可以修改用户的个人设置。选择下面一项开始。",
	
			'usersettings:statistics' => "你的统计信息",
			'usersettings:statistics:opt:description' => "查看站点的用户和对象统计信息。",
			'usersettings:statistics:opt:linktext' => "账户统计信息",
	
			'usersettings:user' => "你的设置",
			'usersettings:user:opt:description' => "这里你可以控制用户各项设置",
			'usersettings:user:opt:linktext' => "修改你的设置",
	
			'usersettings:plugins' => "工具",
			'usersettings:plugins:opt:description' => "配置你的工具。",
			'usersettings:plugins:opt:linktext' => "配置你的工具...",
	
			'usersettings:plugins:description' => "这里你可以修改已安装工具的配置。",
			'usersettings:statistics:label:numentities' => "你的实体",
	
			'usersettings:statistics:yourdetails' => "你的详情",
			'usersettings:statistics:label:name' => "全名",
			'usersettings:statistics:label:email' => "Email",
			'usersettings:statistics:label:membersince' => "注册日期",
			'usersettings:statistics:label:lastlogin' => "最后登录",
	
			
	
		/**
		 * Generic action words
		 */
	
			'save' => "保存",
			'cancel' => "取消",
			'saving' => "保存中 ...",
			'update' => "更新",
			'edit' => "编辑",
			'delete' => "删除",
			'load' => "载入",
			'upload' => "上传",
			'ban' => "禁止",
			'unban' => "解禁",
			'enable' => "激活",
			'disable' => "关闭",
			'request' => "请求",
	
			'invite' => "邀请",
	
			'resetpassword' => "重置密码",
			'makeadmin' => "设为管理员",
	
			'option:yes' => "Yes",
			'option:no' => "No",
	
			'unknown' => '未知',
	
			'learnmore' => "点击此处知道更多。",
	
			'content' => "内容",
			'content:latest' => '最近活动',
			'content:latest:blurb' => '点击此处查看站点最新内容。',
	
		/**
		 * Generic data words
		 */
	
			'title' => "标题",
			'description' => "说明",
			'tags' => "标签",
			'spotlight' => "热点",
			'all' => "全部",
	
			'by' => 'by',
	
			'annotations' => "附注",
			'relationships' => "关系",
			'metadata' => "Metadata",
	
		/**
		 * Input / output strings
		 */

			'deleteconfirm' => "你真的要删除这个对象？",
			'fileexists' => "文件已经被上传。要替换它，可在下面选择：",
	
		/**
		 * Import / export
		 */
			'importsuccess' => "导入数据成功",
			'importfail' => "OpenDD 导入数据失败。",
	
		/**
		 * Time
		 */
	
			'friendlytime:justnow' => "就现在",
			'friendlytime:minutes' => "%s 分钟之前",
			'friendlytime:minutes:singular' => "一分钟之前",
			'friendlytime:hours' => "%s 小时之前",
			'friendlytime:hours:singular' => "一小时之前",
			'friendlytime:days' => "%s 天前",
			'friendlytime:days:singular' => "昨天",
	
		/**
		 * Installation and system settings
		 */
	
			'installation:error:htaccess' => "Elgg requires a file called .htaccess to be set in the root directory of its installation. We tried to create it for you, but Elgg doesn't have permission to write to that directory. 

Creating this is easy. Copy the contents of the textbox below into a text editor and save it as .htaccess

",
			'installation:error:settings' => "Elgg couldn't find its settings file. Most of Elgg's settings will be handled for you, but we need you to supply your database details. To do this:

1. Rename engine/settings.example.php to settings.php in your Elgg installation.

2. Open it with a text editor and enter your MySQL database details. If you don't know these, ask your system administrator or technical support for help.

Alternatively, you can enter your database settings below and we will try and do this for you...",
	
			'installation:error:configuration' => "Once you've corrected any configuration issues, press reload to try again.",
	
			'installation' => "Installation",
			'installation:success' => "Elgg's database was installed successfully.",
			'installation:configuration:success' => "Your initial configuration settings have been saved. Now register your initial user; this will be your first system administrator.",
	
			'installation:settings' => "System settings",
			'installation:settings:description' => "Now that the Elgg database has been successfully installed, you need to enter a couple of pieces of information to get your site fully up and running. We've tried to guess where we could, but <b>you should check these details.</b>",
	
			'installation:settings:dbwizard:prompt' => "Enter your database settings below and hit save:",
			'installation:settings:dbwizard:label:user' => "Database user",
			'installation:settings:dbwizard:label:pass' => "Database password",
			'installation:settings:dbwizard:label:dbname' => "Elgg database",
			'installation:settings:dbwizard:label:host' => "Database hostname (usually 'localhost')",
			'installation:settings:dbwizard:label:prefix' => "Database table prefix (usually 'elgg')",
	
			'installation:settings:dbwizard:savefail' => "We were unable to save the new settings.php. Please save the following file as engine/settings.php using a text editor.",
	
			'installation:sitename' => "站点名称 (如 \"ShowUp.me\"):",
			'installation:sitedescription' => "站点简要说明 (可选)",
			'installation:wwwroot' => "站点根URL，最后要跟斜杠:",
			'installation:path' => "站点的物理目录，最后要跟斜杠:",
			'installation:dataroot' => "站点上传数据的物理路径，最后要跟斜杠:",
			'installation:dataroot:warning' => "你必须手工建立这个目录。并且不要跟elgg的安装目录放在一起。",
			'installation:language' => "站点的缺省语言:",
			'installation:debug' => "Debug 模式能提供更多信息供你调试，但是会降低系统性能，所以只在你碰到问题的时候才开启它:",
			'installation:debug:label' => "开启 debug 模式",
			'installation:usage' => "此选项会让Elgg发送匿名的使用统计情况到Curverider。",
			'installation:usage:label' => "发送匿名的使用统计情况",
			'installation:view' => "你想使用的view，缺省是 default，如果你不清楚怎么用，请留空或保持缺省值:",
			'debug:label' => "开启 debug 模式",
			'usage:label' => "发送匿名的使用统计情况",
	
		/**
		 * Welcome
		 */
	
			'welcome' => "欢迎 %s",
			'welcome_message' => "欢迎来到这个Elgg installation。",
	
		/**
		 * Emails
		 */
			'email:settings' => "Email 设置",
			'email:address:label' => "email 地址",
			
			'email:save:success' => "新邮件地址已保存，确认邮件已发出。",
			'email:save:fail' => "不能保存你的新邮件地址。",
	
			'email:confirm:success' => "你已确认你的邮件地址！",
			'email:confirm:fail' => "你的邮件地址不能被确认...",
	
			'friend:newfriend:subject' => "%s 已将你加为好友！",
			'friend:newfriend:body' => "%s 已将你加为好友！

如果要查看他的个人信息，点击此处：

	%s

不要回复这封email。",
	
	
			'email:validate:subject' => "%s 请确认你的邮件地址！",
			'email:validate:body' => "%s 你好,

请点击如下链接以确认你的email地址：

%s
",
			'email:validate:success:subject' => "Email 已激活 %s!",
			'email:validate:success:body' => "%s 你好,
			
恭喜你，你已成功激活你的邮件地址。",
	
	
			'email:resetpassword:subject' => "密码重置！",
			'email:resetpassword:body' => "%s 你好,
			
你的密码已被更改为： %s",
	
	
			'email:resetreq:subject' => "请求新密码",
			'email:resetreq:body' => "%s 你好,
			
有人 (IP地址 %s) 提交了一个拿回密码的请求。

如果是你自己发出的，请点击下面链接，否则请忽略此邮件。

%s
",

	
		/**
		 * XML-RPC
		 */
			'xmlrpc:noinputdata'	=>	"Input data missing",
	
		/**
		 * Comments
		 */
	
			'comments:count' => "%s 评论",
			'generic_comments:add' => "添加评论",
			'generic_comments:text' => "评论",
			'generic_comment:posted' => "你的评论已发表。",
			'generic_comment:deleted' => "你的评论已删除。",
			'generic_comment:blank' => "对不起，评论内容不能为空。",
			'generic_comment:notfound' => "对不起，找不到你要评论的对象。",
			'generic_comment:notdeleted' => "对不起，不能删除此评论。",
			'generic_comment:failure' => "添加评论时发生未知错误，请重试。",
	
			'generic_comment:email:subject' => '你得到新评论！',
			'generic_comment:email:body' => "你的对象 \"%s\" 得到新评论，来自 %s。内容:

			
%s


要回复或查看对象，点击此处：

	%s

要查看 %s 的个人信息，点击此处：

	%s

不要回复这封邮件。",
	
		/**
		 * Entities
		 */
			'entity:default:strapline' => '%s 被 %s 建立',
			'entity:default:missingsupport:popup' => '实体不能被正确显示。可能是因为它需要一个尚未安装的plugin。',
	
			'entity:delete:success' => '实体 %s 已被删除',
			'entity:delete:fail' => '实体 %s 不能被删除',
	
	
		/**
		 * Action gatekeeper
		 */
			'actiongatekeeper:missingfields' => '表单缺少 __token 或 __ts 字段',
			'actiongatekeeper:tokeninvalid' => '表单提交的特征码与服务器生成的不一致。',
			'actiongatekeeper:timeerror' => '表单已过期，请刷新后再试。',
			'actiongatekeeper:pluginprevents' => '一个扩展功能阻止了这个表单的提交。',
	
		/**
		 * Languages according to ISO 639-1
		 */
			"aa" => "Afar",
			"ab" => "Abkhazian",
			"af" => "Afrikaans",
			"am" => "Amharic",
			"ar" => "Arabic",
			"as" => "Assamese",
			"ay" => "Aymara",
			"az" => "Azerbaijani",
			"ba" => "Bashkir",
			"be" => "Byelorussian",
			"bg" => "Bulgarian",
			"bh" => "Bihari",
			"bi" => "Bislama",
			"bn" => "Bengali; Bangla",
			"bo" => "Tibetan",
			"br" => "Breton",
			"ca" => "Catalan",
			"co" => "Corsican",
			"cs" => "Czech",
			"cy" => "Welsh",
			"da" => "Danish",
			"de" => "German",
			"dz" => "Bhutani",
			"el" => "Greek",
			"en" => "English",
			"eo" => "Esperanto",
			"es" => "Spanish",
			"et" => "Estonian",
			"eu" => "Basque",
			"fa" => "Persian",
			"fi" => "Finnish",
			"fj" => "Fiji",
			"fo" => "Faeroese",
			"fr" => "French",
			"fy" => "Frisian",
			"ga" => "Irish",
			"gd" => "Scots / Gaelic",
			"gl" => "Galician",
			"gn" => "Guarani",
			"gu" => "Gujarati",
			"he" => "Hebrew",
			"ha" => "Hausa",
			"hi" => "Hindi",
			"hr" => "Croatian",
			"hu" => "Hungarian",
			"hy" => "Armenian",
			"ia" => "Interlingua",
			"id" => "Indonesian",
			"ie" => "Interlingue",
			"ik" => "Inupiak",
			"in" => "Indonesian",
			"is" => "Icelandic",
			"it" => "Italian",
			"iu" => "Inuktitut",
			"iw" => "Hebrew (obsolete)",
			"ja" => "Japanese",
			"ji" => "Yiddish (obsolete)",
			"jw" => "Javanese",
			"ka" => "Georgian",
			"kk" => "Kazakh",
			"kl" => "Greenlandic",
			"km" => "Cambodian",
			"kn" => "Kannada",
			"ko" => "Korean",
			"ks" => "Kashmiri",
			"ku" => "Kurdish",
			"ky" => "Kirghiz",
			"la" => "Latin",
			"ln" => "Lingala",
			"lo" => "Laothian",
			"lt" => "Lithuanian",
			"lv" => "Latvian/Lettish",
			"mg" => "Malagasy",
			"mi" => "Maori",
			"mk" => "Macedonian",
			"ml" => "Malayalam",
			"mn" => "Mongolian",
			"mo" => "Moldavian",
			"mr" => "Marathi",
			"ms" => "Malay",
			"mt" => "Maltese",
			"my" => "Burmese",
			"na" => "Nauru",
			"ne" => "Nepali",
			"nl" => "Dutch",
			"no" => "Norwegian",
			"oc" => "Occitan",
			"om" => "(Afan) Oromo",
			"or" => "Oriya",
			"pa" => "Punjabi",
			"pl" => "Polish",
			"ps" => "Pashto / Pushto",
			"pt" => "Portuguese",
			"qu" => "Quechua",
			"rm" => "Rhaeto-Romance",
			"rn" => "Kirundi",
			"ro" => "Romanian",
			"ru" => "Russian",
			"rw" => "Kinyarwanda",
			"sa" => "Sanskrit",
			"sd" => "Sindhi",
			"sg" => "Sangro",
			"sh" => "Serbo-Croatian",
			"si" => "Singhalese",
			"sk" => "Slovak",
			"sl" => "Slovenian",
			"sm" => "Samoan",
			"sn" => "Shona",
			"so" => "Somali",
			"sq" => "Albanian",
			"sr" => "Serbian",
			"ss" => "Siswati",
			"st" => "Sesotho",
			"su" => "Sundanese",
			"sv" => "Swedish",
			"sw" => "Swahili",
			"ta" => "Tamil",
			"te" => "Tegulu",
			"tg" => "Tajik",
			"th" => "Thai",
			"ti" => "Tigrinya",
			"tk" => "Turkmen",
			"tl" => "Tagalog",
			"tn" => "Setswana",
			"to" => "Tonga",
			"tr" => "Turkish",
			"ts" => "Tsonga",
			"tt" => "Tatar",
			"tw" => "Twi",
			"ug" => "Uigur",
			"uk" => "Ukrainian",
			"ur" => "Urdu",
			"uz" => "Uzbek",
			"vi" => "Vietnamese",
			"vo" => "Volapuk",
			"wo" => "Wolof",
			"xh" => "Xhosa",
			"y" => "Yiddish",
			"yo" => "Yoruba",
			"za" => "Zuang",
			"zh" => "Chinese",
			"zu" => "Zulu",
	);
	
	add_translation("zh",$simplifiedchinese);

?>
