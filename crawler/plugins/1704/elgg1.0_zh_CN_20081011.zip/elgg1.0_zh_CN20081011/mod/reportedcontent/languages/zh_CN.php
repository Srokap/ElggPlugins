<?php
	/**
	 * Elgg reported content plugin language pack
	 * 
	 * @package ElggReportedContent
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$simplifiedchinese = array(
	
		/**
		 * Menu items and titles
		 */
	
			'item:object:reported_content' => '被举报的对象',
			'reportedcontent' => '被举报的内容',
			'reportedcontent:this' => '举报',
			'reportedcontent:none' => '没有被举报的内容',
			'reportedcontent:report' => '向管理员举报',
			'reportedcontent:title' => '页面标题',
			'reportedcontent:deleted' => '举报的内容已被删除',
			'reportedcontent:notdeleted' => '不能删除举报信息',
			'reportedcontent:delete' => '删除',
			'reportedcontent:areyousure' => '你真的要删除吗？',
			'reportedcontent:archive' => '归档',
			'reportedcontent:archived' => '报告已被归档',
			'reportedcontent:visit' => '访问被举报对象',
			'reportedcontent:by' => '举报人',
			'reportedcontent:objecttitle' => '对象标题',
			'reportedcontent:objecturl' => '对象url',
			'reportedcontent:reason' => '举报原因',
			'reportedcontent:description' => '简述你举报的原因。',
			'reportedcontent:address' => '对象位置',
			'reportedcontent:success' => '你的举报已经发往管理员',
			'reportedcontent:failing' => '你的举报未能发出',
	
	);
					
	add_translation("zh",$simplifiedchinese);
?>