<?php

	$simplifiedchinese = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messages' => "消息",
			'messages:user' => "你的收件箱",
			'messages:sentMessages' => "发送消息",
			'messages:posttitle' => "%s 的消息: %s",
			'messages:inbox' => "收件箱",
			'messages:send' => "发送消息",
			'messages:sent' => "已发送消息",
			'messages:message' => "消息",
			'messages:title' => "标题",
			'messages:to' => "到",
			'messages:fly' => "Let it fly",
			'messages:replying' => "正在回复",
			'messages:inbox' => "收件箱",
			'messages:sendmessage' => "发送消息",
			'messages:compose' => "发送消息",
			'messages:sentmessages' => "已发送消息",
			'messages:recent' => "最近消息",
			
			'item:object:messages' => '消息',
	
		/**
		 * Status messages
		 */
	
			'messages:posted' => "你的消息已成功发送。",
			'messages:deleted' => "你的消息已成功删除。",
	
		/**
		 * Email messages
		 */
	
			'messages:email:subject' => '你有新的短消息！',
			'messages:email:body' => "你收到新的短消息，来自 %s. 内容如下：

			
%s


要查看短消息，点击此处：

	%s

要发送给 %s 短消息，点击此处：

	%s

不要回复这封邮件。",
	
		/**
		 * Error messages
		 */
	
			'messages:blank' => "对不起，消息内容不能为空。",
			'messages:notfound' => "对不起，未能找到指定消息。",
			'messages:notdeleted' => "对不起，未能删除消息。",
			'messages:nopermission' => "你没有权限删除消息。",
			'messages:nomessages' => "没有消息可显示。",
			'messages:user:nonexist' => "未能在用户数据库中找到收件人。",
	
	);
					
	add_translation("zh",$simplifiedchinese);

?>