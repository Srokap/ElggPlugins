<?php
	/**
	 * Elgg file plugin language pack
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$simplifiedchinese = array(
	
		/**
		 * Menu items and titles
		 */
	
			'file' => "文件",
			'files' => "文件",
			'file:yours' => "你的文件",
			'file:yours:friends' => "你好友的文件",
			'file:user' => "%s 的文件",
			'file:friends' => "%s 好友的文件",
			'file:all' => "所有文件",
			'file:more' => "更多文件",
			'file:list' => "列表显示",
			'file:group' => "群组文件",
			'file:gallery' => "陈列显示",
			'file:gallery_list' => "陈列或列表显示",
			'file:num_files' => "显示条目数量",
			'file:edit' => "编辑文件",
	
			'file:upload' => "上传文件",
			
			'file:file' => "文件",
			'file:title' => "标题",
			'file:desc' => "说明",
			'file:tags' => "标签",
	
			'file:types' => "已上传的文件类型",
	
			'file:type:all' => "所有文件",
			'file:type:video' => "视频文件",
			'file:type:document' => "文档文件",
			'file:type:audio' => "声音文件",
			'file:type:image' => "图片文件",
			'file:type:general' => "普通文件",
	
			'file:user:type:video' => "%s 的视频文件",
			'file:user:type:document' => "%s 的文档文件",
			'file:user:type:audio' => "%s 的声音文件",
			'file:user:type:image' => "%s 图片文件",
			'file:user:type:general' => "%s 普通文件",
	
			'file:friends:type:video' => "你好友的视频文件",
			'file:friends:type:document' => "你好友的文档文件",
			'file:friends:type:audio' => "是好友的声音文件",
			'file:friends:type:image' => "你好友的图片文件",
			'file:friends:type:general' => "你好友的普通文件",
	
			'file:widget' => "文件功能块",
			'file:widget:description' => "列出你最近的文件",
	
			'file:download' => "下载",
	
			'file:delete:confirm' => "你真的要删除这个文件吗？",
			
			'file:tagcloud' => "标签集",
	
			'file:display:number' => "显示的文件个数",
	
			'file:river:created' => "%s 已上传文件",
			'file:river:item' => "一个文件",
			'file:river:annotate' => "%s 评论",

			'item:object:file' => '文件',
	
		/**
		 * Status messages
		 */
	
			'file:saved' => "你的文件已成功保存。",
			'file:deleted' => "你的文件已成功删除。",
	
		/**
		 * Error messages
		 */
	
			'file:none' => "未能找到任何文件。",
			'file:uploadfailed' => "对不起，保存文件失败。",
			'file:downloadfailed' => "对不起，这个文件目前不可用。",
			'file:deletefailed' => "你的文件目前不能被删除。",
	
	);
					
	add_translation("zh",$simplifiedchinese);
?>