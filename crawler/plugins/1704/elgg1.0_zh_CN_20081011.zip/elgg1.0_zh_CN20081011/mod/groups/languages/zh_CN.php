<?php
	/**
	 * Elgg groups plugin language pack
	 * 
	 * @package ElggGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$simplifiedchinese = array(
	
		/**
		 * Menu items and titles
		 */
			
			'groups' => "群组",
			'groups:owned' => "你建立的群组",
			'groups:yours' => "你加入的群组",
			'groups:user' => "%s 的群组",
			'groups:all' => "所有群组",
			'groups:new' => "新建一个群组",
			'groups:edit' => "编辑群组",
	
			'groups:icon' => '群组图标(如不改变请留空)',
			'groups:name' => '群组名',
			'groups:username' => '群组短名(用于URL显示，只可用字母)',
			'groups:description' => '说明',
			'groups:briefdescription' => '简要说明',
			'groups:interests' => '兴趣',
			'groups:website' => '网站',
			'groups:members' => '群组组员',
			'groups:membership' => "会员身份",
			'groups:access' => "访问权限",
			'groups:owner' => "所有者",
	        'groups:widget:num_display' => '显示条目数量',
	        'groups:widget:membership' => '加入的群组',
	        'groups:widgets:description' => '在个人资料页显示你已加入的群组',
			'groups:noaccess' => '不能访问这个群组',
			'groups:cantedit' => '不能编辑这个群组',
			'groups:saved' => '群组已保存',
	
			'groups:joinrequest' => '请求加入',
			'groups:join' => '加入群组',
			'groups:leave' => '退出群组',
			'groups:invite' => '邀请好友',
			'groups:inviteto' => "邀请好友到 '%s'",
			'groups:nofriends' => "你所有好友都已加入此群组。",
	
			'groups:group' => "群组",
			
			'item:object:groupforumtopic' => "论坛主题",
	
			/*
			  Group forum strings
			*/
			
			'groups:forum' => '群组论坛',
			'groups:addtopic' => '添加新主题',
			'groups:forumlatest' => '论坛最近更新',
			'groups:latestdiscussion' => '最近讨论',
			'groupspost:success' => '你的回复已成功发表',
			'groups:alldiscussion' => '最近讨论',
			'groups:edittopic' => '编辑主题',
			'groups:topicmessage' => '主题消息',
			'groups:topicstatus' => '主题状态',
			'groups:reply' => '回帖',
			'groups:topic' => '主题',
			'groups:posts' => '帖子',
			'groups:lastperson' => '最后访问',
			'groups:when' => '时间',
			'grouptopic:notcreated' => '还没有主题。',
			'groups:topicopen' => '打开',
			'groups:topicclosed' => '关闭',
			'groups:topicresolved' => '断绝',
			'grouptopic:created' => '你的主题已建立。',
			'groupstopic:deleted' => '你的主题已删除。',
			'groups:topicsticky' => '粘滞',
			'groups:topicisclosed' => '主题已关闭。',
			'groups:topiccloseddesc' => '这个主题已经关闭，不能再后面发新帖了。',
			
	
			'groups:privategroup' => '这个群组是私有群组，申请加入。',
			'groups:notitle' => '群组必须要有一个主题',
			'groups:cantjoin' => '不能加入群组',
			'groups:cantleave' => '不能退出群组',
			'groups:addedtogroup' => '已成功将用户加入群组',
			'groups:joinrequestnotmade' => '加入请求不能发出',
			'groups:joinrequestmade' => '加入请求已成功发出',
			'groups:joined' => '已成功加入群组！',
			'groups:left' => '已成功退出群组',
			'groups:notowner' => '对不起，你不是这个群组的所有者。',
			'groups:alreadymember' => '你已经是这个群组的成员！',
			'groups:userinvited' => '邀请用户成功。',
			'groups:usernotinvited' => '邀请用户失败。',
	
			'groups:invite:subject' => "%s，你被邀请加入 %s！",
			'groups:invite:body' => "你好 %s,

你被邀请加入 '%s' 群组，点击如下链接确认：

%s",

			'groups:welcome:subject' => "欢迎来到 %s 群组！",
			'groups:welcome:body' => "你好 %s!
		
你现在已成为 '%s' 群组的组员！ 点击如下链接开始发帖！

%s",
	
			'groups:request:subject' => "%s 请求加入 %s",
			'groups:request:body' => "你好 %s,

%s 请求加入 '%s' 群组，点击如下链接可查看个人信息：

%s

或者点击如下链接直接批准：

%s",
	
			'groups:river:member' => '属于群组',
	
			'groups:nowidgets' => '这个群组没有定义功能区块。',
	
	
			'groups:widgets:members:title' => '群组组员',
			'groups:widgets:members:description' => '列出群组的组员。',
			'groups:widgets:members:label:displaynum' => '列出群组的组员。',
			'groups:widgets:members:label:pleaseedit' => '请配置功能区块。',
	
			'groups:widgets:entities:title' => "群组内的对象",
			'groups:widgets:entities:description' => "列出保存在这个群组内的对象",
			'groups:widgets:entities:label:displaynum' => '列出群组对象。',
			'groups:widgets:entities:label:pleaseedit' => '请配置功能区块。',
		
	);
					
	add_translation("zh",$simplifiedchinese);
?>