<?php
	/**
	 * Elgg GUID Tool
	 * 
	 * @package ElggGUIDTool
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$simplifiedchinese = array(
	
		/**
		 * Menu items and titles
		 */
	
			'guidtool' => 'GUID 工具',
			'guidtool:browse' => '浏览 GUIDs',
			'guidtool:import' => '导入',
			'guidtool:import:desc' => '粘贴你要导入的数据到下面窗口，数据必须是 "%s" 格式。',
	
			'guidtool:pickformat' => '请选择导入或导出的格式。',
	
			'guidbrowser:export' => '导出',
	);
					
	add_translation("zh",$simplifiedchinese);
?>