<?php

	$simplifiedchinese = array(
	
		/**
		 * Menu items and titles
		 */
	
			'status' => "状态",
			'status:currentstatus' => "当前状态",
			'status:description' => "这个功能区块显示你目前的状态",
			'status:user' => "%s 的状态",
			'status:posttitle' => "%s 的状态： %s",
			'status:everyone' => "整站状态",
			'status:strapline' => "%s",
			'status:addstatus' => "设置状态",
		    'status:messages' => "状态显示文本",
			'status:text' => "状态：",
			'status:set' => "设为 ",
			'status:clear' => "清除状态",
			'status:delete' => "删除状态",
			'status:nostatus' => "没有设置状态。",
			'status:viewhistory' => "查看历史",
	
			'item:object:status' => '状态显示文本',
	
	
        /**
	     * Status river
	     **/
	        
	        //generic terms to use
	        'status:river:created' => "%s 更新",
	        
	        //these get inserted into the river links to take the user to the entity
	        'status:river:create' => "他们状态。",
	        
	        
	
		/**
		 * Status messages
		 */
	
			'status:posted' => "你的状态已经添加。",
			'status:deleted' => "你的状态已经删除。",
	
		/**
		 * Error messages
		 */
	
			'status:blank' => "对不起，状态显示文本不能为空。",
			'status:notfound' => "对不起，为找到指定的状态显示文本。",
			'status:notdeleted' => "对不起，不能删除状态显示文本。",
			'status:notsaved' => "遇到错误，请重试或联系管理员。",
			'status:problem' => "遇到问题，看起来你不能编辑此状态。",
	
	);
					
	add_translation("zh",$simplifiedchinese);

?>