<?php

	$simplifiedchinese = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messageboard:board' => "留言板",
			'messageboard:messageboard' => "留言板",
			'messageboard:viewall' => "查看全部",
			'messageboard:postit' => "发表",
			'messageboard:history' => "历史",
			'messageboard:none' => "没有内容",
			'messageboard:num_display' => "显示条目数量",
			'messageboard:desc' => "这是一个留言板，你可以把它放在你的个人信息页。",
			
         /**
	     * Message board widget river
	     **/
	        
	        'messageboard:river:annotate' => "%s 有新的留言。",
	        'messageboard:river:create' => "%s 添加了留言板功能块。",
	        'messageboard:river:update' => "%s 更新了留言板功能块。",
			
		/**
		 * Status messages
		 */
	
			'messageboard:posted' => "留言成功。",
			'messageboard:deleted' => "删除留言成功。",
	
		/**
		 * Email messages
		 */
	
			'messageboard:email:subject' => '你有心留言！',
			'messageboard:email:body' => "你收到一个新留言，来自 %s. 内容如下：

			
%s


要查看你的留言板内容，点击这里：

	%s

要查看 %s 的个人信息，点击这里：

	%s

不要回复这封邮件。",
	
		/**
		 * Error messages
		 */
	
			'messageboard:blank' => "对不起，内容不能为空。",
			'messageboard:notfound' => "对不起，未能发现指定对象。",
			'messageboard:notdeleted' => "对不起，未能删除留言。",
	     
			'messageboard:failure' => "遇到未知错误，请重试。",
	
	);
					
	add_translation("zh",$simplifiedchinese);

?>