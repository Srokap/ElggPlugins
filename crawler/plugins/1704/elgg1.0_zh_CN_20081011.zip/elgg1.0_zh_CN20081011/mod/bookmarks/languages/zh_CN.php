<?php

	$simplifiedchinese = array(
	
		/**
		 * Menu items and titles
		 */
	
			'bookmarks' => "书签",
			'bookmarks:add' => "新建书签",
			'bookmarks:read' => "阅读书签",
			'bookmarks:friends' => "好友书签",
			'bookmarks:everyone' => "整站书签",
			'bookmarks:this' => "标为书签",
			'bookmarks:bookmarklet' => "获得书签",
			'bookmarks:inbox' => "书签盒",
			'bookmarks:more' => "更多书签",
			'bookmarks:shareditem' => "已被书签标记的对象",
			'bookmarks:with' => "分享了",
			'bookmarks:num_display' => "显示条目数量:",
	
			'bookmarks:address' => "书签资源的地址",
	
			'bookmarks:delete:confirm' => "你真的要删除这个资源？",
	
			'bookmarks:shared' => "已标注书签",
			'bookmarks:visit' => "访问资源",
			'bookmarks:recent' => "最近书签",
	
			'bookmarks:river:created' => '%s 被标为书签',
			'bookmarks:river:annotate' => '%s 被评论',
			'bookmarks:river:item' => '一个对象',
	
			'item:object:bookmarks' => '书签标注的对象',
	
	
		/**
		 * More text
		 */
		    
		    'bookmarks:widget:description' => 
		            "这个功能区块是用来显示你最近标注的书签，可以把它放置在你的起点站页面上。",
	
			'bookmarks:bookmarklet:description' =>
					"小书签是用来保存你从web上搜索到的一些资源的链接，用于和好友共享或者自己访问方便。把下面的按钮直接拖动到浏览器的地址栏即可使用：",

	        'bookmarks:bookmarklet:descriptionie' =>
					"如果你在使用IE，你需要右键点击小书签图标，选择“加入收藏夹”，然后选择地址栏",

			'bookmarks:bookmarklet:description:conclusion' =>
					"你可以最适随地方便保存任何你访问的网址。",
	
		/**
		 * Status messages
		 */
	
			'bookmarks:save:success' => "标注书签成功。",
			'bookmarks:delete:success' => "删除书签成功。",
	
		/**
		 * Error messages
		 */
	
			'bookmarks:save:failed' => "标注书签失败，请重试。",
			'bookmarks:delete:failed' => "删除书签失败，请重试。",
	
	
	);
					
	add_translation("zh",$simplifiedchinese);

?>