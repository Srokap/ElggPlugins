<?php
	/**
	 * Elgg pages plugin language pack
	 * 
	 * @package ElggPages
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$simplifiedchinese = array(
	
		/**
		 * Menu items and titles
		 */
			
			'pages' => "页面",
			'pages:yours' => "你的页面",
			'pages:user' => "首页",
			'pages:group' => "%s 的页面",
			'pages:all' => "整站页面",
			'pages:new' => "新建页面",
			'pages:groupprofile' => "群组页面",
			'pages:edit' => "编辑页面",
			'pages:delete' => "删除页面",
			'pages:history' => "页面历史",
			'pages:view' => "查看页面",
			'pages:welcome' => "编辑欢迎信息",
			'pages:welcomeerror' => "保存欢迎信息出错",
			'pages:welcomeposted' => "欢迎信息已保存",
			'pages:navigation' => "页面导航",
			'pages:welcomemessage' => "欢迎使用页面功能，通过权限管理，历史记录，多级显示可以保证你的页面组织更加完善有效，方便你的协同工作。",
	
			'item:object:page_top' => '顶层页面',
			'item:object:page' => '页面',
			'item:object:pages_welcome' => '页面的欢迎板块',
	
	
		/**
		 * Form fields
		 */
	
			'pages:title' => '页面标题',
			'pages:description' => '你的页面标题',
			'pages:tags' => '标签',	
			'pages:access_id' => '访问权限',
			'pages:write_access_id' => '修改权限',
		
		/**
		 * Status and error messages
		 */
			'pages:noaccess' => '无页面访问权限',
			'pages:cantedit' => '你不能编辑这个页面',
			'pages:saved' => '页面已保存',
			'pages:notsaved' => '页面不能保存',
			'pages:notitle' => '必须给页面一个标题。',
			'pages:delete:success' => '你的页面已成功删除。',
			'pages:delete:failure' => '你的页面未能成功删除。',
	
		/**
		 * Page
		 */
			'pages:strapline' => '最后更新 %s，更新人 %s',
	
		/**
		 * History
		 */
			'pages:revision' => '建立修订版 %s，创建人 %s',
	
		/**
		 * Submenu items
		 */
			'pages:label:view' => "查看页面",
			'pages:label:edit' => "编辑页面",
			'pages:label:history' => "页面历史",
	
		/**
		 * Sidebar items
		 */
			'pages:sidebar:this' => "这个页面",
			'pages:sidebar:children' => "子页面",
			'pages:sidebar:parent' => "父页面",
	
			'pages:newchild' => "创建子页面",
			'pages:backtoparent' => "返回 '%s'",
	);
					
	add_translation("zh",$simplifiedchinese);
?>