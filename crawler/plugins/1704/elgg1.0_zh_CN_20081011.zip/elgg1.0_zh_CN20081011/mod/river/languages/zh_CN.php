<?php

	$simplifiedchinese = array(
	
		/**
		 * Manifest
		 */
		
	
		'river:widget:noactivity' => '没有活动。',
		'river:widget:title' => "活动",
		'river:widget:description' => "显示你最近的活动。",
		'river:widget:title:friends' => "好友的活动",
		'river:widget:description:friends' => "显示你好友最近都在干什么。",
	
		'river:widget:label:displaynum' => "显示数量：",
	);
					
	add_translation("zh",$simplifiedchinese);

?>