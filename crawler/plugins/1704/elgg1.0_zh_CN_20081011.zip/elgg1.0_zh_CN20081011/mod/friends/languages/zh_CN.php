<?php

	$simplifiedchinese = array(
	
		/**
		 * Friends widget
		 */
			'friends:widget:description' => "显示你的好友。",
	        
		
	);
					
	add_translation("zh",$simplifiedchinese);

?>