<?php
	/**
	 * Elgg log browser plugin language pack
	 * 
	 * @package ElggLogBrowser
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$simplifiedchinese = array(
	
		/**
		 * Menu items and titles
		 */
	
			'logbrowser' => 'Log浏览器',
			'logbrowser:browse' => '浏览系统的log',
			'logbrowser:search' => '过滤结果',
			'logbrowser:user' => '用户名',
			'logbrowser:starttime' => '开始时间(例如"last monday", "1 hour ago")',
			'logbrowser:endtime' => '结束时间',
	
			'logbrowser:explore' => '浏览log',
	
	);
					
	add_translation("zh",$simplifiedchinese);
?>