<?php

	$simplifiedchinese = array(
	
		/**
		 * Menu items and titles
		 */
	
			'blog' => "博客",
			'blogs' => "博客",
			'blog:user' => "%s 的博客",
			'blog:user:friends' => "%s 的好友的博客",
			'blog:your' => "你的博客",
			'blog:posttitle' => "%s 的博客: %s",
			'blog:friends' => "好友的博客",
			'blog:yourfriends' => "好友博客最近更新",
			'blog:everyone' => "整站博客",
	
			'blog:read' => "阅读博客",
	
			'blog:addpost' => "撰写博客文章",
			'blog:editpost' => "编辑博客文章",
	
			'blog:text' => "博客文章内容",
	
			'blog:strapline' => "%s",
			
			'item:object:blog' => '博客文章',
	
			
         /**
	     * Blog river
	     **/
	        
	        //generic terms to use
	        'blog:river:created' => "%s 写作",
	        'blog:river:updated' => "%s 更新",
	        'blog:river:posted' => "%s 发表",
	        
	        //these get inserted into the river links to take the user to the entity
	        'blog:river:create' => "新博客文章",
	        'blog:river:update' => "博客文章。",
	        'blog:river:annotate:create' => "对博客文章的评论。",
			
	
		/**
		 * Status messages
		 */
	
			'blog:posted' => "你的博客文章已经成功发表。",
			'blog:deleted' => "你的博客文章已经成功删除。",
	
		/**
		 * Error messages
		 */
	
			'blog:save:failure' => "你的博客文章未能保存，请重试。",
			'blog:blank' => "对不起，博客的标题和正文不能为空。",
			'blog:notfound' => "对不起，未能找到指定博客文章。",
			'blog:notdeleted' => "对不起，未能删除博客文章。",
	
	);
					
	add_translation("zh",$simplifiedchinese);

?>