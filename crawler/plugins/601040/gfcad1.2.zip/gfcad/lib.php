<?php 
/**
 * Google Friend Connect(GFC) Integration
 *
 * @package ElggGFC
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Arunoda Susiripala
 * @copyright Arunoda Susiripala 2009
 * @link http://elgggfc.googlecode.com
 */

function icon_save($file,$force=false,$user=false){
	if(!$user) $user=get_loggedin_user();
	//no need to do the same if the thumbnail(GFC) is not get changed!
	if(!$force && $user->gfc_icon==$file) return;
	
	
	//resizing images
	$topbar = get_resized_image_from_existing_file($file,16,16, true);
	$tiny = get_resized_image_from_existing_file($file,25,25, true);
	$small = get_resized_image_from_existing_file($file,40,40, true);
	$medium = get_resized_image_from_existing_file($file,100,100, true);
	$large = get_resized_image_from_existing_file($file,200,200);
	$master = get_resized_image_from_existing_file($file,550,550);
	
	$filehandler = new ElggFile();
	$filehandler->owner_guid = $user->guid;
	$filehandler->setFilename("profile/" . $user->username . "large.jpg");
	$filehandler->open("write");
	$filehandler->write($large);
	$filehandler->close();
	$filehandler->setFilename("profile/" . $user->username . "medium.jpg");
	$filehandler->open("write");
	$filehandler->write($medium);
	$filehandler->close();
	$filehandler->setFilename("profile/" . $user->username . "small.jpg");
	$filehandler->open("write");
	$filehandler->write($small);
	$filehandler->close();
	$filehandler->setFilename("profile/" . $user->username . "tiny.jpg");
	$filehandler->open("write");
	$filehandler->write($tiny);
	$filehandler->close();
	$filehandler->setFilename("profile/" . $user->username . "topbar.jpg");
	$filehandler->open("write");
	$filehandler->write($topbar);
	$filehandler->close();
	$filehandler->setFilename("profile/" . $user->username . "master.jpg");
	$filehandler->open("write");
    $filehandler->write($master);
	$filehandler->close();
	
	$user->icontime = time();
	
	trigger_elgg_event('profileiconupdate',$user->type,$user);
	
	//set the metadata for to tell icon has been changed!
	$user->gfc_icon=$file;
}