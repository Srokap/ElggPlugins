<?php 
/**
 * Google Friend Connect(GFC) Integration
 *
 * @package ElggGFC
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Dario Agliottone
 * @copyright Dario Agliottone 20010
 * @link http://elgggfc.googlecode.com
 */

require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

admin_gatekeeper();
set_context('admin');

// Set admin user for user block
set_page_owner($_SESSION['guid']);
$names=array("gfcSiteID","gfcOnSocialBar","gfcOnValidation","gfcOffUsername","loginIconAlign");

if(get_input('submit')){
	foreach ($names as $name){
		$value=trim(get_input($name));
		if(strlen($value)>0) datalist_set($name,$value);
		else datalist_set($name,0);
	}
}


$values=array();
foreach ($names as $name){
	$values[$name]=datalist_get($name);
}

$form=elgg_view("show/config",$values);
$title = elgg_view_title("Google Friend Connect Config");
page_draw("GFC Config",elgg_view_layout("two_column_left_sidebar", '', $title . $form));

?>