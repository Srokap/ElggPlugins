
REplace in file start.php

    if ($_SERVER['PHP_SELF'] == "/sites/elgg2/index.php")

whith your path of index
//----------------------

Replace this code in file users.php
//-----------------------
function register_user($username, $password, $name, $email, $allow_multiple_emails = false, $friend_guid = 0, $invitecode = '',$gfcid='') {
	// Load the configuration
	global $CONFIG;

	$username = trim($username);
	// no need to trim password.
	$password = $password;
	$name = trim(strip_tags($name));
	$email = trim($email);

	// A little sanity checking
	if (empty($username)
	|| empty($password)
	|| empty($name)
	|| empty($email)) {
		return false;
	}

	// See if it exists and is disabled
	$access_status = access_get_show_hidden_status();
	access_show_hidden_entities(true);

	// Validate email address
	if (!validate_email_address($email)) {
		throw new RegistrationException(elgg_echo('registration:emailnotvalid'));
	}

	// Validate password
	if (!validate_password($password)) {
		throw new RegistrationException(elgg_echo('registration:passwordnotvalid'));
	}

	// Validate the username
	if (!validate_username($username)) {
		throw new RegistrationException(elgg_echo('registration:usernamenotvalid'));
	}

	// Check to see if $username exists already
	if ($user = get_user_by_username($username)) {
		//return false;
		throw new RegistrationException(elgg_echo('registration:userexists'));
	}

	// If we're not allowed multiple emails then see if this address has been used before
	if ((!$allow_multiple_emails) && (get_user_by_email($email))) {
		throw new RegistrationException(elgg_echo('registration:dupeemail'));
	}

	access_show_hidden_entities($access_status);

	// Otherwise ...
	$user = new ElggUser();
	$user->username = $username;
	$user->email = $email;
	$user->name = $name;
	$user->access_id = ACCESS_PUBLIC;
	$user->salt = generate_random_cleartext_password(); // Note salt generated before password!
	$user->password = generate_user_password($user, $password);
	$user->owner_guid = 0; // Users aren't owned by anyone, even if they are admin created.
	$user->container_guid = 0; // Users aren't contained by anyone, even if they are admin created.
	$user->gfcid = $gfcid;
        $user->save();

	// If $friend_guid has been set, make mutual friends
	if ($friend_guid) {
		if ($friend_user = get_user($friend_guid)) {
			if ($invitecode == generate_invite_code($friend_user->username)) {
				$user->addFriend($friend_guid);
				$friend_user->addFriend($user->guid);

				// @todo Should this be in addFriend?
				add_to_river('friends/river/create', 'friend', $user->getGUID(), $friend_guid);
				add_to_river('friends/river/create', 'friend', $friend_guid, $user->getGUID());
			}
		}
	}

	// Check to see if we've registered the first admin yet.
	// If not, this is the first admin user!
	$have_admin = datalist_get('admin_registered');
	global $registering_admin;

	if (!$have_admin) {
		$user->makeAdmin();
		set_user_validation_status($user->getGUID(), TRUE, 'first_run');
		datalist_set('admin_registered', 1);
		$registering_admin = true;
	} else {
		$registering_admin = false;
	}

	// Turn on email notifications by default
	set_user_notification_setting($user->getGUID(), 'email', true);

	return $user->getGUID();
}

//-----------------------

Replace this code in file actions\register.php

//-----------------------
global $CONFIG;

// Get variables
$gfcid=get_input('gfcid');
$username = get_input('username');
$password = get_input('password');
$password2 = get_input('password2');
$email = get_input('email');
$name = get_input('name');
$friend_guid = (int) get_input('friend_guid',0);
$invitecode = get_input('invitecode');

$admin = get_input('admin');
if (is_array($admin)) {
	$admin = $admin[0];
}

if (!$CONFIG->disable_registration) {
// For now, just try and register the user
	try {
		$guid = register_user($username, $password, $name, $email, false, $friend_guid, $invitecode,$gfcid);
		if (((trim($password) != "") && (strcmp($password, $password2) == 0)) && ($guid)) {
			$new_user = get_entity($guid);
			if (($guid) && ($admin)) {
				// Only admins can make someone an admin
				admin_gatekeeper();
				$new_user->makeAdmin();
			}

			// Send user validation request on register only
			global $registering_admin;
			if (!$registering_admin) {
				request_user_validation($guid);
			}

			if (!$new_user->isAdmin()) {
				// Now disable if not an admin
				// Don't do a recursive disable.  Any entities owned by the user at this point
				// are products of plugins that hook into create user and might need
				// access to the entities.
				$new_user->disable('new_user', false);
			}

			system_message(sprintf(elgg_echo("registerok"),$CONFIG->sitename));

			// Forward on success, assume everything else is an error...
			forward();
		} else {
			register_error(elgg_echo("registerbad"));
		}
	} catch (RegistrationException $r) {
		register_error($r->getMessage());
	}
} else {
	register_error(elgg_echo('registerdisabled'));
}

forward(REFERER);



//-----------------------
