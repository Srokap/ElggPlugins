<?php
/**
 * Elgg JConnect Plugin.
 *
 * @version		1.0
 * @package		JConnect.exApps.elgg.views.default.config
 * @author 		Arunoda Susiripala
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 */
?>
.jconnectContainer {
	padding: 10px;
	background-color: #dedede;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
}

#gfc_username_box{
	background-color:rgb(50,50,50);
	border-top:4px solid #b50202;
	border-bottom:4px solid #b50202;
	color:rgb(200,200,200);
	padding:5px;
	position:relative
}

#gfc_username_box div input{
	padding:1px;
	margin:0px;
	font-size:11px;
	font-family:monospace;
}

#gfc_username_box div a{
	color:white;
}


#gfc_username_box div a:hover{
	color:rgb(102,102,102);
}

#gfc_validate{
	background-color:black;
	opacity:0.8;
	filter: alpha(opacity = 80);
	position:fixed;
	top:0px;
	left:0px;
	right:0px;
	bottom:0px;
	width:100%;
	height:100%;
	z-index:100;
	text-align:center;
	padding:100px;
	color:rgb(200,200,200);
}

#gfc_validate #content{
	margin-left:auto;
	margin-right:auto;
	width:500px;
	height:500px
	padding:20px;
	border:3px solid white;
	text-align:left;
	overflow:auto;
}

#gfc_validate #content div{
	padding:5px;
}

#gfc_validate  #close{
	margin-top:30px;
	color:white;
	font-size:20px;
	cursor:pointer;
}

#gfc_validate #close a{
	color:white;	
}

