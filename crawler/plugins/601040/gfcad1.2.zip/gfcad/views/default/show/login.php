<?php 
/**
 * Google Friend Connect(GFC) Integration
 * 
 * @package ElggGFC
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Arunoda Susiripala
 * @copyright Arunoda Susiripala 2009
 * @link http://elgggfc.googlecode.com
 */	

$align=datalist_get('loginIconAlign');
$style="float:left";
if($align=='center'){
	$style="width:170px;marf";
}
else if($align=='right'){
	$style="float:right";
}

?>

<div style='<?php echo $style;?>' id="gfc_login_icon">
</div>

