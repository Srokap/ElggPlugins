<script src="http://www.google.com/jsapi"></script>


<script type="text/javascript">
  google.load('friendconnect', '0.8');
</script>

<script type="text/javascript">

	function setGFC(){

		var target=document.getElementById("gfc_login_icon");
		if(!target) return;

		google.friendconnect.container.setParentUrl('mod/gfc/');
		  google.friendconnect.container.loadOpenSocialApi({
		    site: '<?php echo $CONFIG->GFC_SITE_ID;?>',
		    onload: function(securityToken) {


		    	 if (!window.timesloaded) {

		    	      window.timesloaded = 1;

		    	    } else {
		    	      window.timesloaded++;

		    	    }
		    	    if (window.timesloaded > 1) {

		    	      window.top.location.reload();





		    	    }
		        }
		  });

		  google.friendconnect.renderSignInButton({ 'id': 'gfc_login_icon', 'text' : 'Click here to join ', 'style': 'standard' });

	}

  $(document).ready(function() {
      setGFC();

  });
</script>


<div style='<?php echo $style;?>' id="gfc_login_icon">
</div>