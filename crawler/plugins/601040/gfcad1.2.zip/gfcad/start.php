<?php

/**
 * Google Friend Connect(GFC) Integration
 *
 * @package ElggGFC
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Dario Agliottone
 * @copyright Dario Agliottone 20010
 * @link http://elgggfc.googlecode.com
 */
include_once 'lib.php';
$CONFIG->GFC_SITE_ID = datalist_get('gfcSiteID');

function gfc_init() {
    add_widget_type('gfc', 'GoogleFriends', 'GoogleFriends');
    
    global $CONFIG;
    //add the GFC login button...

    extend_view('account/forms/login', 'show/login');
    extend_view('account/forms/register', 'show/login');
    extend_view('account/forms/register', 'show/login');
    extend_view('page_elements/footer', 'show/bar');
    extend_view('usersettings/user', 'show/settings');
    extend_view('metatags', 'show/gfcLoad');
    extend_view('css', 'show/css');

    //gfc login work start
    gfc_login();
}

function gfc_login() {
    global $CONFIG;

    $fcauth = $_COOKIE['fcauth' . $CONFIG->GFC_SITE_ID];
    if (isset($fcauth)) {

        $rest_call = "http://www.google.com/friendconnect/api/people/@me/@self?fcauth=$fcauth";
        $res = file($rest_call);
        $res = implode("\n", $res);
        $gfc_user = json_decode($res)->entry;

        $CONFIG->gfcid = $gfc_user->id;

          if (isloggedin()) {

              $user=get_loggedin_user();
              $user->gfcid=$gfc_user->id;
              $user->save();
        system_message( $user->gfcid);
        }
    
        
        
        if (!isloggedin()) {

            $elgg_user = get_entities_from_metadata('gfcid', $gfc_user->id); 

            $elgg_user = $elgg_user[0];

            if (!$elgg_user->guid) {
                //do the login stuff...
                $elgg_user = vaisuregistra($gfc_user);
            } else {

                $elgg_user = get_user($elgg_user->guid);
                login($elgg_user);
            }
        }
    }
}

function vaisuregistra($gfc_user) {

    $CONFIG->gfci == $gfc_user->id;

    if ($_SERVER['PHP_SELF'] == "/sites/elgg2/index.php")
        forward("pg/register/");
}


function gfc_pagesetup() {
    if (get_context() == 'admin' && isadminloggedin()) {
        global $CONFIG;
        add_submenu_item(elgg_echo('GFC Administration'), $CONFIG->wwwroot . 'mod/gfcad/config.php');
    }
}

// Initialise GFC....
//register_plugin_hook('entity:icon:url','user','gfc_icon_url');


register_elgg_event_handler('init', 'system', 'gfc_init');

register_elgg_event_handler('pagesetup', 'system', 'gfc_pagesetup');
?>
