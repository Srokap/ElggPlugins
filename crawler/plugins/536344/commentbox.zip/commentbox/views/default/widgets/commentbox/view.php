<div class="contentWrapper">
<iframe src="http://www.h8ck.com/chat/index.php" width="700" height="500" frameborder="0" > </iframe>