<?php
  function commentbox_init() {        
    add_widget_type('commentbox', 'My Comment Box', 'Comment box widget');
  }
 
  register_elgg_event_handler('init','system','commentbox_init');       
?>