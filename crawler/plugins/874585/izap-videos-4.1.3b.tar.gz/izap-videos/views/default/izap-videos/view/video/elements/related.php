<?php
/**
 * iZAP izap_videos
 *
 * @package Elgg videotizer, by iZAP Web Solutions.
 * @license GNU Public License version 3
 * @Contact iZAP Team "<support@izap.in>"
 * @Founder Tarun Jangra "<tarun@izap.in>"
 * @link http://www.izap.in/
 *
 */
?>
<div id="related_videos"><img src="<?php echo elgg_get_site_url()?>mod/<?php echo GLOBAL_IZAP_VIDEOS_PLUGIN?>/_graphics/queue.gif" alt=""/></div>
