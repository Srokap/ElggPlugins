var shim_start; 
var navup=0;
var x;
var t;

function timedCount(){
    t = setTimeout("refreshstart()", 60000);
}

function stopCount(){
    clearTimeout(t);
}

function refreshload (siteurl){
    shim_start =siteurl +"mod/rfriverdashboard/lib/refreshstart.php";
    setTimeout("startload()",100);
//alert('Site Loaded');
}

function startload(){
    refreshstart();
}

function refreshstart()
{       
    $('#river_container').load(shim_start+'?callback=true&display='+$('input#display').val() + '&content=' + $('select#content').val()+'&offset='+navup);
//timedCount();
//
}

function navigationback(){      
    x=window.document.getElementById("content").value;
    navup = navup + 20;
    $('#river_container').load(shim_start+'?callback=true&display='+$('input#display').val() + '&content=' + $('select#content').val()+'&offset='+navup);
}
        
function navigationforward(){
    x=window.document.getElementById("content").value;
    if (navup >= 20) {
        navup = navup - 20;
        $('#river_container').load(shim_start+'?callback=true&display='+$('input#display').val() + '&content=' + $('select#content').val()+'&offset='+navup);
    }
}

function dashfilter (){
    $('#river_container').load(shim_start+'?callback=true&display='+$('input#display').val() + '&content=' + $('select#content').val());
    navup=0;
}


function navreset(){
    navup=0;
}

function refreshinit(siteurl) {
    // quit if this function has already been called
    if (arguments.callee.done) return;

    // flag this function so we don't do the same thing twice
    arguments.callee.done = true;

    // do stuff
    refreshload(siteurl);
};
