<?php
/* * *****************************************************************************
 * 3 column dashboard
 * 3 column replacement rfriverdashboard miniprofile
 *
 * @package 3 column dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fusion <contact@donkeydesigns.us>
 * @copyright TheFloridaCircle.com 2008-2009
 * @link http://www.thefloridacircle.com/
 *
 * **************************************************************************** */
if (isloggedin ()) {
    if (empty($vars['entity']))
        $vars['entity'] = $vars['user'];

    if ($vars['entity'] instanceof ElggUser) {
        $name = htmlentities($vars['entity']->name, ENT_QUOTES, 'UTF-8');
        $username = $vars['entity']->username;
?>

        <div id="owner_block">
            <div class="collapsable_box_content">
                <div id="miniprofile" class="contentWrapper">
                    <div class="mp_icon">
                <?php
                echo elgg_view('profile/icon', array('entity' => $vars['entity'], 'size' => 'large', 'override' => true));
                ?>
            </div>

            <div class="mp_username">
                <?php
                echo '<h2>' . elgg_echo('river:mini:hi') . ' ' . $name . '</h2>';
                ?>
            </div>
            <div class="mp_profilestats">
                <?php
                // profile stats
                $current_count = get_loggedin_user()->getAnnotations("profilecount");

                if (!$current_count) {
                    $current_count = 0;
                } else {
                    $current_count = $current_count[0]->value;
                }

                echo '<div class=\"mp_views\">' . sprintf(elgg_echo('river:stats:currentcount'), $current_count) . '</div>';

                // start user points
                if (is_plugin_enabled('userpoints')) {
                    echo '<div align="center"><b>';
                    $upperplural = get_plugin_setting('upperplural', 'userpoints');
                    echo $upperplural . ': ' . $vars['entity']->userpoints_points . '</b></div>';
                }
                // end of user points
                // start of vazco karma
                if (is_plugin_enabled('vazco_karma')) {
                    echo '<div align="center">';
                    global $CONFIG;
                    if ($vars['size'] == 'large') {
                        $karma = new vazco_karma();
                        $user = $vars['entity'];
                        if ($karma->showPointsOnProfile()) {
                            $points = $karma->getUserPoints($user);
                            $rank = $karma->getUserRank($user);
                            echo '<div class="karma_profile_points1">';
                            echo '<div><span class="karma_profile_header">' . elgg_echo('vazco_karma:profile:points') . '</span> <span>' . $points . '</span></div>';
                            echo '<div><span class="karma_profile_header">' . elgg_echo('vazco_karma:profile:rank') . '</span> <span>' . $rank . '</span></div>';
                            if (isadminloggedin() || $user->guid == get_loggedin_userid()) {
                                echo '<div class="vazco_points_history"><a href="' . $CONFIG->wwwroot . 'pg/vazco_karma/history/' . $user->username . '">' . elgg_echo('vazco_karma:history:menu') . '</a></div>';
                            }
                            echo '</div>';
                        }
                    }
                    echo '</div>';
                }
                // end vazco karma
                ?>
            </div>

            <div class="mp_usermenu">
                <?php
                // start user menu

                if (is_plugin_enabled('requestnotifications')) {
                    echo '<hr />';
                    echo elgg_view('requestnotifications/shortlist', $vars);
                    echo '<a href="' . $vars['url'] . 'pg/requestnotifications/" class="requestnotifications_viewall">' . elgg_echo('requestnotifications:viewall') . '</a><br />';
                }
                echo '<hr />';
                if (is_plugin_enabled('tidypics')) {
                    echo '<div>Photos: <a href="' . $vars['url'] . 'pg/photos/owned/' . $_SESSION['user']->username . '">' . elgg_echo("river:mini:edit") . '</a></div>';
                }
                if (is_plugin_enabled('izap_videos')) {
                    echo '<div>Videos: <a href="' . $vars['url'] . 'pg/izap_videos/' . $_SESSION['user']->username . '">' . elgg_echo("river:mini:edit") . '</a></div>';
                }
                if (is_plugin_enabled('blog')) {
                    echo '<div><a href="' . $vars['url'] . 'pg/blog/' . $_SESSION['user']->username . '">' . elgg_echo("river:mini:blog") . '</a></div>';
                }
                if (is_plugin_enabled('groups')) {
                    echo '<div><a href="' . $vars['url'] . 'pg/groups/member/' . $_SESSION['user']->username . '">' . elgg_echo("river:mini:groups") . '</a></div>';
                }
                if (is_plugin_enabled('omni_inviter')) {
                    echo '<div><a href="' . $vars['url'] . 'pg/omni_inviter/invite/">' . elgg_echo("river:mini:invite") . '</a></div>';
                } else {
                    if (is_plugin_enabled('invitefriends')) {
                        echo '<div><a href="' . $vars['url'] . 'mod/invitefriends/">' . elgg_echo("river:mini:invite") . '</a></div>';
                    } else {

                    }
                }
                ?>
            </div>


            <div class='msg_list'>
                <h3 class='msg_header'><?php echo elgg_echo('river:mini:manage') ?></h3>
                <div class='msg_body2'>
                    <div><h3><?php echo elgg_echo('river:mini:account') ?></h3>
                        <?php
                        if (is_plugin_enabled('customstyle')) {
                            echo '<div><a href="' . $vars['url'] . 'pg/customstyle/">' . elgg_echo('river:mini:custom_profile') . '</a></div>';
                        }
                        echo '<div><a href="' . $vars['url'] . 'mod/profile/editicon.php">' . elgg_echo('river:mini:profile_image') . '</a></div>';

                        echo '<h3>' . elgg_echo('river:mini:edit_account') . '</h3>';

                        echo '<div><a href="' . $vars['url'] . 'pg/settings/">' . elgg_echo('river:mini:account_settings') . '</a></div>';
                        echo '<div><a href="' . $vars['url'] . 'pg/settings/plugins/' . $_SESSION['user']->username . '">' . elgg_echo('river:mini:tools') . '</a></div>';
                        if (is_plugin_enabled('notifications')) {
                            echo '<div><a href="' . $vars['url'] . 'mod/notifications/">' . elgg_echo("river:mini:notifications") . '</a></div>';
                        }
                        echo '<div><a href="' . $vars['url'] . 'mod/profile/edit.php?username=' . $_SESSION['user']->name . '">' . elgg_echo('river:mini:edit_profile') . '</a></div>';
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php }
                } ?>