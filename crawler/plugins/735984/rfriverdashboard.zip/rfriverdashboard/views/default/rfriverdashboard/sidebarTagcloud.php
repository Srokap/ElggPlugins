<?php
if (is_plugin_enabled('tag_cumulus')) {
    /*     * *****************************************************************************
     * 3 column dashboard
     * view for tag cumulus....  REQUIRES Tag Cumulus plugin
     *
     * @package 3 column dashboard
     * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
     * @author Fusion <contact@donkeydesigns.us>
     * @copyright TheFloridaCircle.com 2008-2009
     * @link http://www.thefloridacircle.com/
     *
     * **************************************************************************** */
?>
    <div id="owner_block">

    <?php
    $body .= '<div class="collapsable_box_header">';
    $body .= '<h1>Tags</h1></div>';
    $body .= '<div class="collapsable_box_content">';
    $body .= '<div class="contentWrapper">';
    $body .= display_tag_cumulus(0, 50, 'tags', 'object', '', '', '');
    $body .= '</div></div></div>';
    echo $body;
    ?>
</div>
<?php } ?>
