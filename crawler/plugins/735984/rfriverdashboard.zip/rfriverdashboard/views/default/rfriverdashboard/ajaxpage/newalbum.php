<?php

/**
 * Tidypics Create New Album Page
 * 
 */
// Load Elgg engine
include_once dirname(dirname(dirname(dirname(dirname(dirname(dirname(__FILE__))))))) . "/engine/start.php";

// must be logged in to create a new album
gatekeeper();

// Get the current page's owner
$page_owner = page_owner_entity();
if ($page_owner === false || is_null($page_owner)) {
    $page_owner = $_SESSION['user'];
    set_page_owner($_SESSION['guid']);
}

if ($page_owner instanceof ElggGroup) {
    add_submenu_item(sprintf(elgg_echo('album:group'), $page_owner->name),
            $CONFIG->wwwroot . "pg/photos/owned/" . $page_owner->username);
}
$area2 = "<div id='river_container2' style='margin-top:3px;'><div class='dash_pad'>";
$area2 .= "<div style='border-bottom:1px solid silver; margin:0 auto 5px auto;'>";
$area2 .= "<div class='rd_floated_half_left'>";
$area2 .= "<img style='float:left;' src='" . $CONFIG->wwwroot . "mod/rfriverdashboard/graphics/icon_image.png'> <span style='padding:0 0 0 3px;'>" . elgg_echo('river:photo:create') . "</span>";
$area2 .= "</div>";
$area2 .= "<div align='right' class='rd_floated_half_right''>";
$area2 .= "<input style=\"border:none; padding:0 0 2px 0;\" type=\"image\" src=\"" . $CONFIG->wwwroot . "mod/rfriverdashboard/graphics/close.png\" onClick=\"document.getElementById('load_content').innerHTML=''\"></div>";
$area2 .= "<div class='clearfloat'></div></div>";
//$area2 .= elgg_view_title(elgg_echo('album:add'));
$area2 .= elgg_view("rfriverdashboard/ajaxpage/forms/imageedit");
$area2 .= "</div></div>";
echo $area2;
?>