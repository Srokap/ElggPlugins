<?php $rightads_title1 = get_plugin_setting('rightads_title1', 'rfriverdashboard'); ?>
<div id="owner_block">
    <div class="collapsable_box_header">
        <h1><?php echo $rightads_title1; ?></h1>
    </div>
    <div class="collapsable_box_content" align="center">
        <div align="right" class="contentWrapper">
            <marquee direction=up loop=true height="250" align="center" onmousemove="this.stop()" onmouseout="this.start()" >
                <a href="http://www.hcmus.edu.vn"><img src="<?php echo $vars['url']; ?>mod/rfriverdashboard/graphics/khtn.jpg" border="0" width="190" /></a>
            </marquee>
            <?php
//allow people to extend this top menu
            /* 		echo elgg_view('rightad/extend', $vars);
              $rightads_code = get_plugin_setting('rightads_code','rfriverdashboard');
              echo $rightads_code; */
            ?>

        </div>
    </div>
</div><!-- / owner_block -->