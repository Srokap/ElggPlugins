<?php
if (is_plugin_enabled('photo_cumulus')) {
    /*     * *****************************************************************************
     * 3 column dashboard
     * view for photo cumulus...   REQUIRES photo cumulus plugin!!
     *
     * @package 3 column dashboard
     * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
     * @author Fusion <contact@donkeydesigns.us>
     * @copyright TheFloridaCircle.com 2008-2009
     * @link http://www.thefloridacircle.com/
     *
     * **************************************************************************** */
?>

    <div id="owner_block">

        <div class="collapsable_box_header">
            <h1>Random Members</h1>
        </div>

        <div class="collapsable_box_content">




            <!-- display cumulus photos -->

        <?php
        echo elgg_view('photo_cumulus/view', array('width' => '220', 'height' => '230', '', 'usernumber' => '20', 'background_transparent' => 'yes'));
        ?>


    </div>
</div>
<?php } ?>
