<?php

/* * *****************************************************************************
 * 3 column dashboard
 * 3 column riverdashboard polls from river
 *
 * @package 3 column dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fusion <contact@donkeydesigns.us>
 * @copyright TheFloridaCircle.com 2008-2009
 * @link http://www.thefloridacircle.com/
 *
 * **************************************************************************** */
// Load Elgg engine
require_once(dirname(dirname(dirname(dirname(dirname(dirname(dirname(__FILE__))))))) . "/engine/start.php");
gatekeeper();

// Get the current page's owner
$page_owner = page_owner_entity();
if ($page_owner === false || is_null($page_owner)) {
    $page_owner = $_SESSION['user'];
    set_page_owner($_SESSION['guid']);
}

//set the title
$area2 = "<div id='river_container2' style='margin-top:3px;'><div class='dash_pad'>";
$area2 .= "<div style='border-bottom:1px solid silver; margin:0 auto 5px auto;'>";
$area2 .= "<div class='rd_floated_half_left'>";
$area2 .= "<img style='float:left;' src='" . $CONFIG->wwwroot . "mod/rfriverdashboard/graphics/icon_video.png'> <span style='padding:0 0 0 3px;'>" . elgg_echo('river:poll:create') . "</span>";
$area2 .= "</div>";
$area2 .= "<div align='right' class='rd_floated_half_right''>";
$area2 .= "<input style=\"border:none; padding:0 0 2px 0;\" type=\"image\" src=\"" . $CONFIG->wwwroot . "mod/rfriverdashboard/graphics/close.png\" onClick=\"document.getElementById('load_content').innerHTML=''\"></div>";
$area2 .= "<div class='clearfloat'></div></div>";
//$area2 .= elgg_view_title(elgg_echo('poll:addpost'));
$area2 .= elgg_view("rfriverdashboard/ajaxpage/forms/polledit");
$area2 .= "</div></div>";


echo $area2;
?>