<div id="owner_block">

    <div class="collapsable_box_header">
        <h1><?php echo elgg_echo("river:tips:title"); ?></h1>
    </div>
    <div class="collapsable_box_content">

        <?php
        if (is_plugin_enabled('tips')) {
            include("" . $CONFIG->pluginspath . 'tips/views/default/widgets/tips/view.php');
        } else {
        ?>

            <div class="contentWrapper">
            <?php
            /*             * ***
              Random Tips and How 2's
             */

            $quotes = array(
                "Did you know you can add your favorite rss feed to your dashboard? You can access the settings by clicking settings on the top bar and then clicking configure tools on the left side navigation.",
                "Settings often located in the top bar, or under Manage Account on the left, is for your account configurations such as your acount name, account password, email settings, and other settings provided by the website Admin.",
                "Tools in the top bar is a drop down with quick access to the sites features such as blogs, groups, files, and other features of the site.",
                "When you create your group, blog, page, upload a file, a video, or post photos to your album you have the option to set the access as private, logged in users, or public.",
                "Should you forget your password the system will send you a new password to the email you registered with",
                "When creating your blogs, groups, pages, or other features, remember that the more descriptive Tags the better other users will be able to find your content",
//"This site uses php to build pages, sometimes you may need to refresh a page for it to load properly",
//"This site has a micro blogging feature like Twitter, You can post to the micro blog either on the &quot;Dashboard&quot; or at &quot;the wire&quot; accessible from the Tools drop down menu",

                "To the left of the page, below your profile picture, click &quot;Manage Account&quot; to access your user settings where you can edit your profile, avatar, and various other useful settings.",
                "Remember to fill out your profile, Your profile is the best way for other users to meet and get to know you",
                "Search can help you find content from other users, it is based on the tags used to create files such as blogs, groups, pages, files, videos",
                "In your settings you can set your notification to email alerts when someone sends you a message to how the site will alert you to comments on your blogs, groups, pages, files, and videos",
                "To create a blog click blogs in the tools drop down menu, on the left side navigation you will see the option to create a blog",
                "This site is equipped with a report this option, if you feel the content or user is offensive use this option to inform the site Admin, the link is located on the left side navigation",
                "Please respect other users and do not use questionable images for your profile icon",
//"Letting everyone know you are here.  When you create a blog, a group, an album, upload a video or file, the site will send a system message to your followers that you have posted",

                "In the left navigation you will find invite freinds link, here you can invite your friends and family.",
//"Site Admin may make site announcements using the micro blog, check back with the micro blog often in case there is such an announcement",

                "Contact the site Admin should you find any bugs with the site.  The site Admin wants to make your experience enjoyable and will work to fix any issues",
                "Inviting you friends and family to visit you site is a sure way to get more followers and friends, you will find an invite friends link in the left navigation on the dashboard",
                "When your envelope turns red on the topbar, this means you have a message or comment, click the envelope to read your message"
            );

            /*             * ***
              ATTENTION -
              Do not edit below this line unless you know what you are doing.
             * *** */

            echo $quotes[rand(0, count($quotes) - 1)];
            ?>
        </div><!--/contentWrapper -->
        <?php } ?>
    </div><!--/dash_pad -->
</div><!--/owner_block -->
