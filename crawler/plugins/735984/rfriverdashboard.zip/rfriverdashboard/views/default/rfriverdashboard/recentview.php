<?php if (is_plugin_enabled('izap-profile-visitors')) { ?>
    <div id="owner_block">

    <?php
    /*     * *****************************************************************************
     * 3 column dashboard
     * view for recent profile visitors....  REQUIRES izap recent profile visitors plugin!!!
     *
     * @package 3 column dashboard
     * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
     * @author Fusion <contact@donkeydesigns.us>
     * @copyright TheFloridaCircle.com 2008-2009
     * @link http://www.thefloridacircle.com/
     *
     * **************************************************************************** */
// Get the number of events to display
    $rvToDisplay = get_plugin_setting('rvToDisplay', 'rfriverdashboard');

    $MaxVistors = $vars['entity']->num_display;

    if (!$MaxVistors)
        $MaxVistors = $rvToDisplay;

    $VisitorArray = izapVisitorList();
    $VisitorArray = array_slice($VisitorArray, 0, $MaxVistors);
    $TotalVisitor = count($VisitorArray);
    $online = find_active_users();
    foreach ($online as $key => $entity) {
        $onlineUsers[] = $entity->guid;
    }
    if ($TotalVisitor) {
        foreach ($VisitorArray as $VisitorGuid) {
            $VisitorEntity = get_entity($VisitorGuid);
            $icon = elgg_view("profile/icon", array('entity' => $VisitorEntity, 'size' => 'small'));

            if (in_array($VisitorGuid, $onlineUsers))
                $Visitors .= '<div class="izapWrapperOnline1">' . $icon . '</div>';
            else
                $Visitors .= '<div class="izapWrapper1">' . $icon . '</div>';
        }
    }
    else {
        $Visitors .= '<div align="center"><h3>' . elgg_echo('izapProfileVisitor:NoVisits') . '</h3></div>';
    }
    ?>
    <div class="collapsable_box_header">
        <h1><?php echo elgg_echo("recent:visitors"); ?></h1>
    </div>
    <div class="collapsable_box_content">
        <div class="contentWrapper">

<?php
    echo '<div class="myicon_wrap">';
    echo $Visitors;
    echo '</div>';
?>

            <div class="clearfloat"></div>
        </div>
    </div>
</div>
<?php } ?>
