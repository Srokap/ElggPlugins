<?php
if (is_plugin_enabled('vanilla_forum')) {
    /*     * *****************************************************************************
     * 3 column dashboard
     * view for tidy pics
     *
     * @package 3 column dashboard
     * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
     * @author Fusion <contact@donkeydesigns.us>
     * @copyright TheFloridaCircle.com 2008-2009
     * @link http://www.thefloridacircle.com/
     *
     * **************************************************************************** */
?>
    <div id="owner_block">
        <div class="dash_pad">

            <h3><?php elgg_echo('river:recent'); ?></h3>

        <?php echo elgg_view('vanillaforum/latest_discussions', array('limit' => $limit)); ?>


    </div>
</div>
<?php } ?>