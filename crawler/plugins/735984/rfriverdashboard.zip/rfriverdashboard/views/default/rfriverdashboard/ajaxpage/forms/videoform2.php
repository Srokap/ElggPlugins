
<?php
/**
 * iZAP izap_videos
 *
 * @package Elgg videotizer, by iZAP Web Solutions.
 * @license GNU Public License version 3
 * @author iZAP Team "<support@izap.in>"
 * @link http://www.izap.in/
 * @version 1.6.1-2.5
 */
// get page owner
$page_owner = page_owner_entity();

// set default all off
//$UPLOADurl = FALSE;
$UPLOADfile = FALSE;
//$UPLOADembed = FALSE;
// load plugin settings
/* $uploadMethodURL = get_plugin_setting('izapUploadOptionURL', 'izap_videos');
  if($uploadMethodURL == 'OFFSERVER_ON'){
  $UPLOADurl = TRUE;
  if(!$fileSelectedclass && !$embedSelectedclass){
  $urlSelectedclass = 'selected';
  $videoType = 'IZAP_URL';
  }
  } */

$uploadMethodUPLOAD = get_plugin_setting('izapUploadOptionUPLOAD', 'izap_videos');
if ($uploadMethodUPLOAD == 'ONSERVER_ON') {
    $UPLOADfile = TRUE;
    if (!$urlSelectedclass && !$embedSelectedclass) {
        $fileSelectedclass = 'selected';
        $videoType = 'IZAP_FILE';
    }
}

/* $uploadMethodEMBED = get_plugin_setting('izapUploadOptionEMBED', 'izap_videos');
  if($uploadMethodEMBED == 'EMBED_ON'){
  $UPLOADembed = TRUE;
  if(!$fileSelectedclass && !$urlSelectedclass){
  $embedSelectedclass = 'selected';
  $videoType = 'IZAP_EMBED';
  }
  } */

$maxFileSize = (int) get_plugin_setting('izapMaxFileSize', 'izap_videos');

if (isset($vars['entity'])) {
    $izap_videos_title = $vars['entity']->title;
    $izap_videos_description = $vars['entity']->description;
    if (is_array($vars['entity']->tags))
        $izap_videos_tags = implode(', ', $vars['entity']->tags);
    else
        $izap_videos_tags = $vars['entity']->tags;
    $izap_vidoesautoplay = (int) $vars['entity']->autoplay;
    $izap_videosaccessid = $vars['entity']->access_id;

    if ($vars['entity']->videotype == 'embed')
        $izap_embed_code = str_replace('"', '\'', $vars['entity']->videosrc);

    $action = 'izap_videos/edit';
}else {
    $previousData = $_SESSION['postedData'];

    $fileChecked = '';
    $urlChecked = 'CHECKED';
    $izap_videos_url = $previousData['izap_videosurl'];
    $izap_embed_code = str_replace('"', '\'', $previousData['izap_embed_code']);
    $izap_videos_title = $previousData['izap_videostitle'];
    $izap_videos_description = $previousData['izap_videosdescription'];
    $izap_videos_tags = $previousData['izap_videostags'];
    $izap_vidoesautoplay = 0;
    $izap_videosaccessid = ACCESS_PUBLIC;
    $action = 'izap_videos/add';

    //if(isset($previousData['inputTab']) || get_input('option', 'IZAP_URL')){

    if (isset($previousData['inputTab'])) {
        $mainOption = $previousData['inputTab'];
    } elseif (get_input('option', false)) {
        $mainOption = get_input('option');
    } else {
        $mainOption = $videoType;
    }

    unset($urlSelectedclass);
    unset($fileSelectedclass);
    unset($embedSelectedclass);

    switch ($mainOption) {
        /* case 'IZAP_URL':
          $urlSelectedclass = 'selected';
          $videoType = 'IZAP_URL';
          $UPLOADurlField = TRUE;
          break; */

        case 'IZAP_FILE':
            $fileSelectedclass = 'selected';
            $videoType = 'IZAP_FILE';
            $UPLOADfileField = TRUE;
            break;

        /* case 'IZAP_EMBED':
          $embedSelectedclass = 'selected';
          $videoType = 'IZAP_EMBED';
          $UPLOADembedField = TRUE;
          break; */

        default:
            $urlSelectedclass = 'selected';
            $videoType = 'IZAP_URL';
            $UPLOADfileField = TRUE;
            break;
    }
    //}
}


// lets start the form fields
if ($action != 'izap_videos/edit') {
    //if($UPLOADurlField)
    // $formFields['izapVideoUrl'] = array('type' => 'text', 'value' => $izap_videos_url);
    if ($UPLOADfileField)
        $formFields['izapVideoFile'] = array('type' => 'file', 'value' => '');
    //if($UPLOADembedField){
    //$formFields['izapVideoEmbed'] = array('type' => 'text', 'value' => $izap_embed_code);
}
//}elseif($vars['entity']->videotype == 'embed'){
//if($UPLOADembed){
//    $formFields['izapVideoEmbed'] = array('type' => 'text', 'value' => $izap_embed_code);
//}
//}
// lets give the image uploading options to all
$formFields['izapVideoOptionalImage'] = array('type' => 'file', 'value' => '');
$formExtraFields = array(
    'izapVideoTitle' => array('type' => 'text', 'value' => $izap_videos_title),
    'izapVideoDescription' => array('type' => 'text', 'value' => $izap_videos_description),
    'izapVideoTags' => array('type' => 'tags', 'value' => $izap_videos_tags),
    'izapVideoAccess' => array('type' => 'access', 'value' => $izap_videosaccessid),
    'izapPageOwner' => array('type' => 'hidden', 'value' => $page_owner->guid),
    'izapVideoId' => array('type' => 'hidden', 'value' => $vars['entity']->guid),
    'izapVideoType' => array('type' => 'hidden', 'value' => $videoType),
);

// show form only if admin has enabled some thing
if (is_array($formFields) || $action == 'izap_videos/edit') {
    // mrege fields
    if (is_array($formFields))
        $formFields = array_merge($formFields, $formExtraFields);
    else
        $formFields = $formExtraFields;

    foreach ($formFields as $name => $value) {
        if ($value['type'] != 'hidden') {
            $tmpForm .= '<p id="id_' . $name . '"><label>';
            $tmpForm .= elgg_echo('izap_videos:form:' . $name . '') . '<br />';
            $tmpForm .= elgg_view('input/' . $value['type'] . '', array(
                        'internalname' => $name,
                        'value' => $value['value'],
                        'internalid' => $name,
                        'noEditor' => $value['noEditor'],
                            //'class' => $value['class'],
                    ));
            if ($name == 'izapVideoFile') {
                $tmpForm .= '&nbsp;<b>' . sprintf(elgg_echo('izap_videos:maxFileSize'), $maxFileSize) . '</b>';
            }

            $tmpForm .= '</label></p>';
        } else {
            $tmpForm .= elgg_view('input/' . $value['type'] . '', array(
                        'internalname' => $name,
                        'value' => $value['value'],
                        'js' => 'id="hidden_' . $name . '"',
                    ));
        }
    }

    $tmpForm .= elgg_view('categories', $vars);
    $tmpForm .= elgg_view('input/submit', array('value' => elgg_echo('izap_videos:save')));
    $form = elgg_view('input/form', array('body' => $tmpForm, 'action' => $vars['url'] . 'action/' . $action, 'enctype' => 'multipart/form-data'));
    unset($_SESSION['postedData']);
} else {
    $form = '<p align="center"><b>' . elgg_echo('izap_videos:noOptionSelected') . '</b></p>';
}
?>

<div class="contentWrapper">
<?php if ($action != 'izap_videos/edit') { ?>
        <!--<div id="elgg_horizontal_tabbed_nav">
          <ul>
<?php if ($UPLOADurl) { ?>
            <li class="<?php echo $urlSelectedclass; ?>" id="formUrl_izap_videos"><a href="?option=IZAP_URL"><?php echo elgg_echo('izap_videos:form:enterUrl') ?></a></li>
    <?php } if ($UPLOADfile) {
 ?>
            <li class="<?php echo $fileSelectedclass; ?>" id="formUpload_izap_videos"><a href="?option=IZAP_FILE"><?php echo elgg_echo('izap_videos:form:upload') ?></a></li>
<?php } if ($UPLOADembed) { ?>
            <li class="<?php echo $embedSelectedclass; ?>" id="formEmbed_izap_videos"><a href="?option=IZAP_EMBED"><?php echo elgg_echo('izap_videos:form:embedCode') ?></a></li>
<?php } ?>
      </ul>
    </div>-->
<?php } ?>
    <div id="inputArea_izap_videos"></div>
<?php echo $form ?>
    <?php
    if ($action != 'izap_videos/edit' && $urlSelectedclass == 'selected') {
        echo '<a name="supportedSites"></a>';
        echo elgg_view('izap_videos/supportedSites');
    } elseif ($action != 'izap_videos/edit' && $fileSelectedclass == 'selected') {
        echo '<a name="supportedFormats"></a>';
        echo elgg_view('izap_videos/supportedFormats');
    }
    ?>
</div>

