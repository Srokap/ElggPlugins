<?php
/* * *****************************************************************************
 * 3 column dashboard
 * view for site message
 *
 * @package 3 column dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fusion <contact@donkeydesigns.us>
 * @copyright TheFloridaCircle.com 2008-2009
 * @link http://www.thefloridacircle.com/
 *
 * **************************************************************************** */
?>


<div id="owner_block">

    <?php
    //grab the current site message
    $site_message = get_entities("object", "sitemessage", 0, "", 1);
    if (is_array($site_message) && sizeof($site_message) > 0) {
        foreach ($site_message as $mes) {
            $message = $mes->description;
            $dateStamp = friendly_time($mes->time_created);
            $delete = elgg_view("output/confirmlink", array(
                        'href' => $vars['url'] . 'action/rfriverdashboard/delete?message=' . $mes->guid,
                        'text' => elgg_echo('delete'), 'confirm' => elgg_echo('deleteconfirm'),
                    ));
        }
    }
    ?>



    <?php
    //if there is a site message
    if ($site_message) {
    ?>

    <?php
        echo '<div class="collapsable_box_header">';
        echo '<h1>' . elgg_echo("sitemessages:announcements") . '</h1></div>';
        echo '<div class="collapsable_box_content">';
        echo '<div class="contentWrapper">';
        echo '<p><small>' . elgg_echo("sitemessages:posted") . ': ' . $dateStamp;
        //if admin display the delete link
        if (isadminloggedin ())
            echo ' " . $delete . " ';
        echo '</small></p>';
        //display the message
        echo '<p>' . $message . '</p>';

        //display the input form to add a new message
        if (isadminloggedin ()) {
            //action
            $action = "rfriverdashboard/add";
            $link = elgg_echo("sitemessages:add");
            $input_area = elgg_view('input/plaintext', array('internalname' => 'sitemessage', 'value' => ''));
            $submit_input = elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('save')));
            $form_body = <<<EOT
	
			<p><a class="collapsibleboxlink">{$link}</a></p>
			<div class="collapsible_box">
				{$input_area}<br />{$submit_input}
			</div>
	
EOT;
    ?>

    <?php
            //display the form
            echo elgg_view('input/form', array('action' => "{$vars['url']}action/$action", 'body' => $form_body));
        }//end of admin if statement
        echo '</div></div>';
    ?>
    <?php
        //if there is no message, add a form to create one
    } else {

        if (isadminloggedin ()) {

            //action
            $action = "rfriverdashboard/add";
            $link = elgg_echo("sitemessages:add");
            $input_area = elgg_view('input/text', array('internalname' => 'sitemessage', 'value' => ''));
            $submit_input = elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('save')));
            $form_body = <<<EOT
	
			<p><a class="collapsibleboxlink">{$link}</a></p>
			<div class="collapsible_box">
				{$input_area}<br />{$submit_input}
			</div>
EOT;
    ?>
    <?php
            //display the form
            echo elgg_view('input/form', array('action' => "{$vars['url']}action/$action", 'body' => $form_body));
        }//end of admin check
    }//end of main if
    ?>
</div>