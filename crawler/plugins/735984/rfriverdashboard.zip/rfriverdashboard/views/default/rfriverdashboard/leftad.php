<?php $leftads_title1 = get_plugin_setting('leftads_title1', 'rfriverdashboard'); ?>
<div id="owner_block">

    <div class="collapsable_box_header">
        <h1><?php echo $leftads_title1; ?></h1>
    </div>
    <div class="collapsable_box_content">
        <div align="center" class="contentWrapper">
            <?php
//allow people to extend this top menu
            echo elgg_view('leftad/extend', $vars);

            $leftads_code = get_plugin_setting('leftads_code', 'rfriverdashboard');
            echo $leftads_code;
            ?>
        </div>

    </div><!-- / dash_pad -->
</div><!-- / owner_block -->