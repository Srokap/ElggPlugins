<?php
/* * *****************************************************************************
 * 3 column dashboard
 * 3 column rfriverdashboard Friends View
 *
 * @package 3 column dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fusion <contact@donkeydesigns.us>
 * @copyright TheFloridaCircle.com 2008-2009
 * @link http://www.thefloridacircle.com/
 *
 * **************************************************************************** */
?>

<?php
if (is_plugin_enabled('people_from_the_neighborhood')) {
?>
    <div id="owner_block">
        <div class="collapsable_box_header">
            <h1><?php echo elgg_echo('rfriverdashboard:peopleyoumightknow') ?></h1>
        </div>

        <div class="collapsable_box_content">
            <div class="contentWrapper">
                <div class="sidebarBox">
                    <div class="membersWrapper">
                    <?php
                    gatekeeper();

                    $widget = $vars['entity'];

                    $friends = $widget->look_in_friends == 'no' ? 0 : 2;
                    $groups = $widget->look_in_groups == 'no' ? 0 : 2;
                    $num_display = $widget->num_display != null ? $widget->num_display : 2;

                    $people = people_from_the_neighborhood_get_people(get_loggedin_userid(), 2, $groups);
                    echo elgg_view('people_from_the_neighborhood/people', array('people' => $people));
                    ?>
                    <div class="clearfloat"></div>
                    <div class="widget_more_wrapper"><a href="<?php echo $vars['url']; ?>pg/pftn"><?php echo elgg_echo('pftn:see:more'); ?></a></div>



                </div>
            </div>
        </div>
    </div>
</div>

<?php } else if (is_plugin_enabled('friends')) {
?>
                    <div id="owner_block">
                        <div class="collapsable_box_header">
                            <h1><?php echo elgg_echo('rfriverdashboard:friends') ?></h1>
                        </div>
                        <div class="collapsable_box_content">
                            <div id="RDWire" class="contentWrapper">
            <?php
                    $current_user = $_SESSION['user'];
                    $friends = $current_user->getFriends('', 20);
                    if (is_array($friends)) {
                        echo '<div class="membersWrapper">';
                        foreach ($friends as $user) {
                            echo '<div class="member_icon">';
                            echo elgg_view("profile/icon", array(
                                'entity' => $user,
                                'size' => 'small')) . '</div>';
                        }
                        echo '</div>';
                    } else {
                        echo elgg_echo('rfriverdashboard:nofriends');
                    }
            ?>
                    <div class="clearfloat"></div>
                </div>
            </div>
        </div>
<?php } ?>