<?php
/* * *****************************************************************************
 * 3 column dashboard
 * 3 column rfriverdashboard CSS
 *
 * @package 3 column dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fusion <contact@donkeydesigns.us>
 * @copyright TheFloridaCircle.com 2008-2009
 * @link http://www.thefloridacircle.com/
 *
 * **************************************************************************** */
?>

#maincontent_wrap{
width:735px;
float:left;
}

#col_one {
float:left;
width:235px;
}

#col_two {
float:right;
width:500px;
}

#col_three {
float:right;
width:214px;
}

#river_container {

}

.dash_pad {
padding:5px;
}

.clear {
clear:both;
}

#welcome_left {
width:49%;
float:left;
}

#welcome_left h3 {
}

#welcome_left_url {
}

#welcome_right {
width:49%;
float:right;
}

.msg_header{
padding: 5px 5px;
cursor: pointer;
background: #cccccc none repeat scroll 0 0;
border: 1px #191817;
margin:10px;
-webkit-border-radius: 8px;
-moz-border-radius: 8px;
}

.msg_header_open{
padding: 5px 5px;
cursor: pointer;
background: #ffffff;
margin-top:10px;
margin-bottom:10px;
-webkit-border-radius: 8px;
-moz-border-radius: 8px;
}

.msg_body2 {
padding:0px;
margin-left: 0px;
width:100%;
}
#atticons {
width:100%;
}

.izapWrapper1{.
-webkit-border-radius: 8px;
-moz-border-radius: 8px;
// background: white;
margin: 1px;
padding:3px;
float:left;
}

.myicon_wrap{
margin-left:10px;
}

.izapWrapperOnline1{.
-webkit-border-radius: 8px;
-moz-border-radius: 8px;
background: #A4DA89;
margin: 1px;
padding:3px;
float:left;
}
/*tidy pics widget */
.tidypics_widget_latest {
margin: 0 auto;
width: 140px;
}
/*  Feeds  */
.pubdate {
font-size:9px;
color:#666666;
}

/* ------------- hide river icons ---------------- */
.river_user_update {
background: url() no-repeat left -1px;
}
.river_object_user_profileupdate {
background: url() no-repeat left -1px;
}
.river_object_user_profileiconupdate {
background: url() no-repeat left -1px;
}
.river_object_annotate {
background: url() no-repeat left -1px;
}
.river_object_bookmarks_create {
background: url() no-repeat left -1px;
}
.river_object_bookmarks_comment {
background: url() no-repeat left -1px;
}
.river_object_status_create {
background: url() no-repeat left -1px;
}
.river_object_file_create {
background: url() no-repeat left -1px;
}
.river_object_file_update {
background: url() no-repeat left -1px;
}
.river_object_file_comment {
background: url() no-repeat left -1px;
}
.river_object_widget_create {
background: url() no-repeat left -1px;
}
.river_object_forums_create {
background: url() no-repeat left -1px;
}
.river_object_forums_update {
background: url() no-repeat left -1px;
}
.river_object_widget_update {
background: url() no-repeat left -1px;
}
.river_object_blog_create {
background: url() no-repeat left -1px;
}
.river_object_blog_update {
background: url() no-repeat left -1px;
}
.river_object_blog_comment {
background: url() no-repeat left -1px;
}
.river_object_forumtopic_create {
background: url() no-repeat left -1px;
}
.river_user_friend {
background: url() no-repeat left -1px;
}
.river_object_relationship_friend_create {
background: url() no-repeat left -1px;
}
.river_object_relationship_member_create {
background: url() no-repeat left -1px;
}
.river_object_thewire_create {
background: url() no-repeat left -1px;
}
.river_group_join {
background: url() no-repeat left -1px;
}
.river_object_groupforumtopic_annotate {
background: url() no-repeat left -1px;
}
.river_object_groupforumtopic_create {
background: url() no-repeat left -1px;
}
.river_object_sitemessage_create {
background: url() no-repeat left -1px;
}
.river_user_messageboard {
background: url() no-repeat left -1px;
}
.river_object_page_create {
background: url() no-repeat left -1px;
}
.river_object_page_top_create {
background: url() no-repeat left -1px;
}
.river_object_page_top_comment {
background: url() no-repeat left -1px;
}
.river_object_page_comment {
background: url() no-repeat left -1px;
}
.river_object_academic_create, .river_object_academic_update, .river_object_achievements_create, .river_object_achievements_update, .river_object_skills_create, .river_object_skills_update, .river_object_work_create, .river_object_work_update {
background: url() no-repeat left -1px;
}

.river_object_image_create,
.river_object_image_update,
.river_object_album_create,
.river_object_album_update {
background: url() no-repeat left -1px;
}

/* ---------------- dropdown css -----------------  */
ul.cssMenu ul{display:none}
ul.cssMenu li:hover>ul{display:block}
ul.cssMenu ul{position: absolute;left:-1px;top:98%;}
ul.cssMenu ul ul{position: absolute;left:98%;top:-2px;}
ul.cssMenu,ul.cssMenu ul {
margin:0px;
list-style:none;
padding:0px 2px 2px 0px;
background-color:#ffffff;
background-repeat:repeat;

}
ul.cssMenu table {border-collapse:collapse}ul.cssMenu {
display:block;
zoom:1;
float: left;
}
ul.cssMenu ul{
width:61.95px;
}
ul.cssMenu li{
display:block;
margin:2px 0px 0px 2px;
font-size:0px;
}
ul.cssMenu a:active, ul.cssMenu a:focus {
outline-style:none;
}
ul.cssMenu a, ul.cssMenu li.dis a:hover, ul.cssMenu li.sep a:hover {
display:block;
vertical-align:middle;
background-color:#ffffff;
border-width:0px;
border-color:#6655ff;
border-style:solid;
text-align:left;
text-decoration:none;
padding:4px;
_padding-left:0;
font:normal 11px Verdana;
color: #000000;
text-decoration:none;
cursor:default;
}
ul.cssMenu span{
overflow:hidden;
}
ul.cssMenu li {
float:left;
}
ul.cssMenu ul li {
float:none;
}
ul.cssMenu ul a {
text-align:left;
white-space:nowrap;
}
ul.cssMenu li.sep{
text-align:center;
padding:0px;
line-height:0;
height:100%;
}
ul.cssMenu li.sep span{
float:none;	padding-right:0;
width:5;
height:16;
display:inline-block;
background-color:#AAAAAA;	background-image:none;}
ul.cssMenu ul li.sep span{
width:80%;
height:3;
}
ul.cssMenu li:hover{
position:relative;
}
ul.cssMenu li:hover>a{
background-color:#757575;
border-color:#665500;
border-style:solid;
font:normal 11px Verdana;
color: #ffffff;
text-decoration:none;
}
ul.cssMenu li a:hover{
position:relative;
background-color:#757575;
border-color:#665500;
border-style:solid;
font:normal 11px Verdana;
color: #ffffff;
text-decoration:none;
}
ul.cssMenu li.dis a {
color: #AAAAAA !important;
}
ul.cssMenu img {border: none;float:left;_float:none;margin-right:4px;width:16px;
height:16px;
}
ul.cssMenu ul img {width:16px;
height:16px;
}
ul.cssMenu img.over{display:none}
ul.cssMenu li.dis a:hover img.over{display:none !important}
ul.cssMenu li.dis a:hover img.def {display:inline !important}
ul.cssMenu li:hover > a img.def  {display:none}
ul.cssMenu li:hover > a img.over {display:inline}
ul.cssMenu a:hover img.over,ul.cssMenu a:hover ul img.def,ul.cssMenu a:hover a:hover img.over{display:inline}
ul.cssMenu a:hover img.def,ul.cssMenu a:hover ul img.over,ul.cssMenu a:hover a:hover img.def{display:none}
ul.cssMenu a:hover ul{display:block}
ul.cssMenu span{
display:block;
background-image:url(<?php echo $vars['url']; ?>mod/rfriverdashboard/graphics/arrv_anim_1.gif);
background-position:right center;
background-repeat: no-repeat;
padding-right:11px;}
ul.cssMenu li:hover>a>span{	background-image:url(<?php echo $vars['url']; ?>mod/rfriverdashboard/graphics/arrv_anim_1o.gif);
}
ul.cssMenu a:hover span{	_background-image:url(<?php echo $vars['url']; ?>mod/rfriverdashboard/graphics/arrv_anim_1o.gif)}
ul.cssMenu ul span,ul.cssMenu a:hover table span{background-image:url(<?php echo $vars['url']; ?>mod/rfriverdashboard/graphics/arr_double_1.gif)}
ul.cssMenu ul li:hover > a span{	background-image:url(<?php echo $vars['url']; ?>mod/rfriverdashboard/graphics/arr_double_1o.gif);}
ul.cssMenu table a:hover span{background-image:url(<?php echo $vars['url']; ?>mod/rfriverdashboard/graphics/arr_double_1o.gif)}

/* ---------- END FUSION MOD ------------------- */


.welcomemessage {
// background:white;
}
.rfriverdashboard_filtermenu {
margin:10px 0 10px 0;
}


#peopleyoumightknow-cont {padding:10px 2px; margin: 14px auto; border:1px solid #CCCCCC; border-left:none; border-right:none;}
#peopleyoumightknow-cont h4{font-size:1.0em; padding-bottom:8px;}
#peopleyoumightknow-cont p{font-size:0.9em; background:none;}
#peopleyoumightknow-cont p.owner_timestamp{font-size:0.8em;}
#peopleyoumightknow-cont div.search_listing{ background:none;}

#miniprofile {
text-align:center;
font-size:0.9em;
}

#miniprofile img {
width:100%;
}

.river_item {
margin:2px 10px;

}

.river_item:hover {
margin:2px 10px;
}

.ri_padding {
padding:12px 0;
}

.ri_icon_container {
width:40px;
float:left;
}

.ri_text_margin {
margin-left:55px;
}

.rd_floated_half_right {
float:right;
width:49%;
}

.rd_floated_half_left {
float:left;
width:49%;
}

#thewire_submit_button {
float:left;
margin-right:20px;
}

#thewire_sidebarInputBox {
width:100%;
}

.thewire_characters_remaining input {
width:30px;
}

#atticons h4 {
float:left;
margin-right:10px;
padding-top:5px;
}

#atticons a, #atticons ul {
float:left;
margin-right:5px;
}

#RDWire.contentWrapper {
margin:0;
padding:5px;
}

.groupicon {
float: left;
margin-right: 10px;
}