<?php
/* * *****************************************************************************
 * 3 column dashboard
 * 3 column layout
 *
 * @package 3 column dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fusion <contact@donkeydesigns.us>
 * @copyright TheFloridaCircle.com 2008-2009
 * @link http://www.thefloridacircle.com/
 *
 * **************************************************************************** */
?>

<div id="three_column_wrapper">

    <div id="river_welcome">
        <div class="dash_pad">
            <?php if (isset($vars['area4']))
                echo $vars['area4']; ?>
        </div>
    </div>

    <div id="maincontent_wrap">
        <div id="col_one">
            <div class="dash_pad">
                <?php if (isset($vars['area1']))
                    echo $vars['area1']; ?>
            </div>
            <div class="clearfloat"></div>
        </div><!-- close column 1 -->

        <div id="col_two">
            <div class="dash_pad contentWrapper">
                <?php if (isset($vars['area2']))
                    echo $vars['area2']; ?>
                <div class="clearfloat"></div>
            </div>
        </div><!-- close column 2 -->
    </div><!-- close the content wrapper -->

    <!-- start third column -->
    <div id="col_three">
        <div class="dash_pad">
            <?php if (isset($vars['area3']))
                    echo $vars['area3']; ?>
        </div>
        <div class="clearfloat"></div>
    </div><!-- close column 3 -->
    <div class="clearfloat"></div>
</div><!-- close the wrapper -->