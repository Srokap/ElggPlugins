<?php

/**
 * Show full content of blog in river
 *
 * @package ImprovedRiverDashboard
 */
/**
 * @author Snow.Hellsing <snow.hellsing@firebloom.cc>
 * @copyright FireBloom Studio
 * @link http://firebloom.cc
 */
/* $performed_by = get_entity($vars['item']->subject_guid); // $statement->getSubject();
  $object = get_entity($vars['item']->object_guid);

  $url = "<a href=\"{$performed_by->getURL()}\">{$performed_by->name}</a>";
  $summary .= $url.'&nbsp;'.elgg_echo("blog:river:create") . " <a href=\"" . $object->getURL() . "\">" . $object->title . "</a>";
  $toggle = "<div><a onclick=\"$('#blog_details-{$object->guid}').toggle();return false;\" class=\"river_item_toggle_details\" href=\"\">".elgg_echo('toggle_details').'</a></div>';
  $details = "<div id=\"blog_details-{$object->guid}\" class=\"blog_post\" style=\"display:none\">";
  $details .= "<h2>$object->title</h2>";
  $details .= elgg_view('output/longtext',array('value'=>$object->description));
  $details .= '</div>'; */


$performed_by = get_entity($vars['item']->subject_guid); // $statement->getSubject();
$object = get_entity($vars['item']->object_guid);
$url = $object->getURL();

$url = "<a href=\"{$performed_by->getURL()}\">{$performed_by->name}</a>";
$contents = strip_tags($object->description); //strip tags from the contents to stop large images etc blowing out the river view
$string = sprintf(elgg_echo("blog:river:created"), $url) . " ";
$string .= elgg_echo("blog:river:create") . " <a href=\"" . $object->getURL() . "\">" . $object->title . "</a>";
$string .= "<div class=\"river_content_display\">";
if (strlen($contents) > 200) {
    $string .= substr($contents, 0, strpos($contents, ' ', 200)) . "...";
} else {
    $string .= $contents;
}
$string .= "</div>";


echo $string;
?>