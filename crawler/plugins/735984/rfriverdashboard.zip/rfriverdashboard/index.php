<?php

/* * *****************************************************************************
 * 3 column dashboard
 * 3 column rfriverdashboard Index page
 *
 * @package 3 column dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fusion <contact@donkeydesigns.us>
 * @copyright TheFloridaCircle.com 2008-2009
 * @link http://www.thefloridacircle.com/
 *
 * **************************************************************************** */


require_once(dirname(dirname(dirname(__FILE__))) . '/engine/start.php');

gatekeeper();

$content = get_input('content', '');
$content = explode(',', $content);
$type = $content[0];
$subtype = $content[1];
$orient = get_input('display');
if ($orient == null) {
    $orient = friends;
}
$callback = get_input('callback');

if ($type == 'all') {
    $type = '';
    $subtype = '';
}

$body = '';
if (empty($callback)) {

    //set a view to display a welcome message
    $area5 = elgg_view("rfriverdashboard/welcome");
    //set a view to display left column
    $area3 .= elgg_view("rfriverdashboard/miniprofile");
    if (get_plugin_setting("show_photos", "rfriverdashboard") != "no") {
        $area3 .= elgg_view("rfriverdashboard/photos");
    }
    //$area3 .= elgg_view("rfriverdashboard/birthdaymembers");
    if (get_plugin_setting("show_bookmarks", "rfriverdashboard") != "no") {
        $area3 .= elgg_view("rfriverdashboard/bookmarks");
    }
    if (get_plugin_setting("show_events", "rfriverdashboard") != "no") {
        $area3 .= elgg_view("rfriverdashboard/events");
    }
    if (get_plugin_setting("show_leftads", "rfriverdashboard") != "no") {
        $area3 .= elgg_view("rfriverdashboard/leftad");
    }
    if (get_plugin_setting("show_newestmembers", "rfriverdashboard") != "no") {
        $area3 .= elgg_view("rfriverdashboard/newestmembers");
    }
    if (get_plugin_setting("show_featured_groups", "rfriverdashboard") != "no") {
        $area3 .= elgg_view("rfriverdashboard/featured_groups");
    }
    if (get_plugin_setting("show_mygroups", "rfriverdashboard") != "no") {
        $area3 .= elgg_view("rfriverdashboard/mygroups");
    }
    if (get_plugin_setting("show_vanilla", "rfriverdashboard") != "no") {
        $area3 .= elgg_view("rfriverdashboard/vanilla");
    }
    if (get_plugin_setting("show_sidebartagcloud", "rfriverdashboard") != "no") {
        $area3 .= elgg_view("rfriverdashboard/sidebarTagcloud");
    }

    //set a wiew for the wire
    $body .= elgg_view("rfriverdashboard/activity_view");

    //set a view for the right column
    if (get_plugin_setting("show_site", "rfriverdashboard") != "no") {
        $area4 .= elgg_view("rfriverdashboard/sitemessage");
    }
    if (get_plugin_setting("show_tips", "rfriverdashboard") != "no") {
        $area4 .= elgg_view("rfriverdashboard/tips");
    }
    if (get_plugin_usersetting("feedUserAllow", "rfriverdashboard") != "no") {
        $area4 .= elgg_view("rfriverdashboard/feed");
    }
    if (get_plugin_setting("show_friends", "rfriverdashboard") != "no") {
        $area4 .= elgg_view("rfriverdashboard/friends");
    }
    if (get_plugin_setting("show_videos", "rfriverdashboard") != "no") {
        $area4 .= elgg_view("rfriverdashboard/video");
    }
    if (get_plugin_setting("show_rightads", "rfriverdashboard") != "no") {
        $area4 .= elgg_view("rfriverdashboard/rightad");
    }
    if (get_plugin_setting("show_polls", "rfriverdashboard") != "no") {
        $area4 .= elgg_view("rfriverdashboard/poll");
    }
    if (get_plugin_setting("show_photocumulus", "rfriverdashboard") != "no") {
        $area4 .= elgg_view("rfriverdashboard/photo_cumulus");
    }
    if (get_plugin_setting("show_recentview", "rfriverdashboard") != "no") {
        $area4 .= elgg_view("rfriverdashboard/recentview");
    }
}

switch ($orient) {
    case 'mine':
        $subject_guid = $_SESSION['user']->guid;
        $relationship_type = '';
        break;
    case 'friends': $subject_guid = $_SESSION['user']->guid;
        $relationship_type = 'friend';
        break;
    default: $subject_guid = 0;
        $relationship_type = '';
        break;
}


//code moi

$river = elgg_view_river_items($subject_guid, 0, $relationship_type, $type, $subtype, '');
// Replacing callback calls in the nav with something meaningless
$river = str_replace('callback=true', 'replaced=88,334', $river);

$nav = elgg_view('rfriverdashboard/nav', array(
            'type' => $type,
            'subtype' => $subtype,
            'orient' => $orient
        ));
if (empty($callback)) {
    $body .= elgg_view('rfriverdashboard/container', array('body' => $nav . $river . elgg_view('rfriverdashboard/js')));
    if (is_plugin_enabled('theme_seashells') && get_plugin_setting('columnnumber', 'theme_seashells') == '3columns') {
        page_draw(elgg_echo('dashboard'), elgg_view_layout('two_column_left_sidebar', NULL, $body, $area3, $area4, NULL, $area5));
    } else {
        page_draw(elgg_echo('dashboard'), elgg_view_layout('three_column', $area3, $body, $area4, $area5));
    }
} else {
    header("Content-type: text/html; charset=UTF-8");
    echo $nav . $river . elgg_view('rfriverdashboard/js');
}
?>
