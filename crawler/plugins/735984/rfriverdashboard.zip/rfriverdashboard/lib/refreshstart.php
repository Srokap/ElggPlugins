<?php

/* * *****************************************************************************
 * 3 column dashboard
 * auto refresh files
 *
 * @package 3 column dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fusion <contact@donkeydesigns.us>
 * @copyright TheFloridaCircle.com 2008-2009
 * @link http://www.thefloridacircle.com/
 *
 * **************************************************************************** */


require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/engine/start.php');

gatekeeper();

$content = get_input('content', '');
$content = explode(',', $content);
$type = $content[0];
$subtype = $content[1];
$orient = get_input('display');
$callback = get_input('callback');

if ($type == 'all') {
    $type = '';
    $subtype = '';
}



switch ($orient) {
    case 'mine':
        $subject_guid = $_SESSION['user']->guid;
        $relationship_type = '';
        break;
    case 'friends': $subject_guid = $_SESSION['user']->guid;
        $relationship_type = 'friend';
        break;
    default: $subject_guid = 0;
        $relationship_type = '';
        break;
}

$river = elgg_view_river_items($subject_guid, 0, $relationship_type, $type, $subtype, '');
// Replacing callback calls in the nav with something meaningless
$dumbstop = $river;
$navexplode = explode('<div class="river_pagination">', $dumbstop);
$buttonexplode = explode('<a class="', $navexplode [1]);
$buttoncount = count($buttonexplode);

if ($buttoncount == 2) {

    $string = $river;
    if (stristr($string, 'forward') === FALSE) {
        $fillspot = 'back"href="javascript:navigationback();">' . elgg_echo('river:previous') . '</a></p><div class="clearfloat"></div></div></div>';
        $river = str_replace($buttonexplode [1], $fillspot, $river);
    } else {
        $fillspot = 'forward"href="javascript:navigationforward();">' . elgg_echo('river:next') . '</a></p><div class="clearfloat"></div></div></div>';
        $river = str_replace($buttonexplode [1], $fillspot, $river);
    }
}

if ($buttoncount == 3) {
    $fillspot = 'back"href="javascript:navigationback();">' . elgg_echo('river:previous') . '</a><a class="forward"href="javascript:navigationforward();">' . elgg_echo('river:next') . '</a></p><div class="clearfloat"></div></div></div>';
    $currentcheck = $buttonexplode [1] . '<a class="' . $buttonexplode [2];
    $river = str_replace($currentcheck, $fillspot, $river);
}

$river = str_replace('callback=true', 'replaced=88,334', $river);
$dumbput = '<script type ="text/javascript">rivercount(' . $dumbcount . ')</script>';
$nav = elgg_view('rfriverdashboard/nav', array(
            'type' => $type,
            'subtype' => $subtype,
            'orient' => $orient
        ));


echo $nav . $river . elgg_view('rfriverdashboard/js');
?>