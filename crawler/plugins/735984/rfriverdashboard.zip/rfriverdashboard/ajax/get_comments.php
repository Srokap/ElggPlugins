<?php

/**
 * return comments for ajax request
 *
 * @package Improvedrfriverdashboard
 */
/**
 * @author Snow.Hellsing <snow@firebloom.cc>
 * @copyright FireBloom Studio
 * @link http://firebloom.cc
 */
$guid = get_input('guid');

echo list_annotations($guid, 'generic_comment', comment_limit);
?>