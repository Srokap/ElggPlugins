
<?php 

    $plugin = find_plugin_settings('shai_sitecode');

    // Set default values
    $shai_sitecode_sitecode = $plugin->shai_sitecode_sitecode;

    echo elgg_echo('shai_sitecode:settings');

    echo elgg_view('input/text', array(
		'internalname' => 'params[shai_sitecode_sitecode]',
		'value' => $plugin->shai_sitecode_sitecode
	));

?>