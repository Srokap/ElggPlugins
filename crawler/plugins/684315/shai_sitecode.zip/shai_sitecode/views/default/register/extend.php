<div class="captcha">
<label>
<?php
    $form_body = elgg_echo('shai_sitecode:secretcode') . elgg_view('input/password' , array('internalname' => 'shai_sitecode_password', 'class' => "general-textarea"));

    echo $form_body;
	
?>
</label>
</div>
