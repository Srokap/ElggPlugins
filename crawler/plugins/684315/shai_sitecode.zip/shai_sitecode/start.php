<?php
    /*******************************************************************************
     * shai_sitecode
     *
     * @author kiter
     ******************************************************************************/


    function shai_sitecode_init() {
        global $CONFIG;

        elgg_extend_view('register/extend','shai_sitecode/account/forms/register', 900);
	register_plugin_hook("action", "register", "shai_sitecode_verify_action_hook", 999);

        return true;
    }


    function shai_sitecode_verify_action_hook($hook, $entity_type, $returnvalue, $params) {
	$password = get_input('shai_sitecode_password');
    	$plugin = find_plugin_settings('shai_sitecode');
    	$real_code = $plugin->shai_sitecode_sitecode;

	if (!strcmp($password,$real_code))
	    return $returnvalue;

	register_error(elgg_echo('user:resetpassword:unknown_user'));

	return false;
    }

    register_elgg_event_handler('init', 'system', 'shai_sitecode_init');
?>
