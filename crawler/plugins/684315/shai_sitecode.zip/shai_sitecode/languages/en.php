<?php

	$english = array(
			'shai_sitecode:secretcode' => "Site-wide registration code",
			'shai_sitecode:settings' => "Site-wide registration code for new users:"
			);
	add_translation("en",$english);

?>