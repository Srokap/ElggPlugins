<?php
	$english = array(
		// Title
		'profile_counter' => "Profile Counter",
		'profile_counter:title' => "Profile Counter",
		'profile_counter:shorttitle' => "Profile Counter",
		
		'profile_counter:stats:title' => "Profile Counter",
		'profile_counter:stats:currentcount' => "Currently your profile has been viewed %s time(s).",
		'profile_counter:stats:reset' => "Reset Counter",
		'profile_counter:stats:confirm' => "Are you sure you wish to reset your profile counter?",
		
	);
	
	add_translation("en", $english);
?>