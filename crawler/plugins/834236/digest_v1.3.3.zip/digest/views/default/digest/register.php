<?php

?>
<input type="checkbox" name="digest_site" value="yes" /> <?php echo elgg_echo("digest:register:enable"); ?>