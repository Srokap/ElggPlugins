<p>
  <?php 
    echo elgg_echo('feedback:user_1');
    echo "<input type='text' size='60' name='params[user_1]' value='".$vars['entity']->user_1."' />";
    echo "<br />";

    echo elgg_echo('feedback:user_2');
    echo "<input type='text' size='60' name='params[user_2]' value='".$vars['entity']->user_2."' />";
    echo "<br />";

    echo elgg_echo('feedback:user_3');
    echo "<input type='text' size='60' name='params[user_3]' value='".$vars['entity']->user_3."' />";
    echo "<br />";

    echo elgg_echo('feedback:user_4');
    echo "<input type='text' size='60' name='params[user_4]' value='".$vars['entity']->user_4."' />";
    echo "<br />";

    echo elgg_echo('feedback:user_5');
    echo "<input type='text' size='60' name='params[user_5]' value='".$vars['entity']->user_5."' />";
    echo "<br />";
  ?>
</p>
