<?php
/**
 * Unvalidatedemailchange plugin
 * iionly
 * Contact: iionly@gmx.de
 *
 * German language file
 **/

$german = array(
'unvalidatedemailchange:no_user_guid_provided' => 'Benutzer-GUID nicht verfügbar.',
'unvalidatedemailchange:user_email_changed_to' => 'Die Email-Adresse von %s wurde in %s geändert.',
'unvalidatedemailchange:email_address_invalid' => 'Die angegebene Email-Adresse %s ist unzulässig.',
'unvalidatedemailchange:new_user_email' => 'Gebe die neue Email-Addresse für den Benutzer %s ein: ',
'unvalidatedemailchange:change_email' => 'Email-Adresse ändern',
);
add_translation("de",$german);
