<?php





$act_create=get_input('actiontype_create');

if(isset($act_create))
{
	
elgg_set_plugin_setting('actiontype_create',$act_create,'controlactivity');
}

$act_friend=get_input('actiontype_friend');
if(isset($act_friend))
{
elgg_set_plugin_setting('actiontype_friend',$act_friend,'controlactivity');
}

$act_comment=get_input('actiontype_comment');
if(isset($act_comment))
{
elgg_set_plugin_setting('actiontype_comment',$act_comment,'controlactivity');
}

return true;

?>