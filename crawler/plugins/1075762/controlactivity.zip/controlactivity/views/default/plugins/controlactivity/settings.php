

  <h2>Which action type to displaying</h2>
  

<div>
	<?php
       
         $option_value;
         
	     $act_crete_value=elgg_get_plugin_setting('actiontype_create','controlactivity');
	     if(isset($act_crete_value))
	     {
	         if($act_crete_value=='display')
	         {
	          $option_value=array('display'=>'true','nodisplay'=>'false');
	         
	         }
	         else
	         {
	          $option_value=array('nodisplay'=>'false','display'=>'true');
	         }
	     
	     }
	     else 
	     {
	     	$option_value=array('display'=>'true','nodisplay'=>'false');
	     }
	     
	     
	     
		echo elgg_echo('true or false to display action_type    Create') . ' ';
		echo elgg_view('input/dropdown', array(
			'name' => 'actiontype_create',
			'options_values' => $option_value,	
			
			'value' => '',
		));
	?>
</div>

<div>
	<?php

    
     $option_value2=array();
	$act_friend_value=elgg_get_plugin_setting('actiontype_friend','controlactivity');
	if(isset($act_friend_value))
	{
		if($act_friend_value=='display')
		{
			$option_value2=array('display'=>'true','nodisplay'=>'false');
		}
		else
		{
			$option_value2=array('nodisplay'=>'false','display'=>'true');
		}
	
	}
	else
	{
		$option_value2=array('display'=>'true','nodisplay'=>'false');
	}
	
	
		echo elgg_echo('true or false to display action_type    friends') . ' ';
		echo elgg_view('input/dropdown', array(
			'name' => 'actiontype_friend',
			'options_values' => $option_value2,
			
			'value' => '',
		));
	?>
</div>

<div>
	<?php
       $option_value3=array();
	$act_comment_value=elgg_get_plugin_setting('actiontype_comment','controlactivity');
	if(isset($act_comment_value))
	{
		if($act_comment_value=='display')
		{
			$option_value3=array('display'=>'true','nodisplay'=>'false');
		}
		else
		{
			$option_value3=array('nodisplay'=>'false','display'=>'true');
		}
	
	}
	else
	{
		$option_value3=array('display'=>'true','nodisplay'=>'false');
	}
	
	

	
		echo elgg_echo('true or false to display action_type Comment') . ' ';
		echo elgg_view('input/dropdown', array(
			'name' => 'actiontype_comment',
			'options_values' => $option_value3,	
			
			'value' => '',
		));

	?>
</div>

<?php

?>