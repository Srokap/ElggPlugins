<?php


elgg_register_event_handler('init', 'system', 'control_activity_init');





function control_activity_init()
{

   elgg_register_page_handler('activity',control_elgg_river_page_handler);
  // $act_path="{$CONFIG->path}/mod/controlactivity/pages/controlactivity/actions/save.php";
   $path=elgg_get_plugins_path();
   elgg_register_action("controlactivity/settings/save",$path."controlactivity/actions/save.php");
   //var_dump($CONFIG->actions["controlactivity/settings/save"]);
   


}




function control_elgg_river_page_handler($page)
{
	//echo "control";
	//exit();
   global $CONFIG;

	elgg_set_page_owner_guid(elgg_get_logged_in_user_guid());

	// make a URL segment available in page handler script
	$page_type = elgg_extract(0, $page, 'all');
	$page_type = preg_replace('[\W]', '', $page_type);
	if ($page_type == 'owner') {
		$page_type = 'mine';
	}
	set_input('page_type', $page_type);

	// content filter code here
	$entity_type = '';
	$entity_subtype = '';

	if(!require_once("{$CONFIG->path}/mod/controlactivity/pages/controlactivity/river.php"));
	
	return true;

}





?>