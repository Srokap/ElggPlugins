<?php
/**
 * Main activity stream list page
 */

//echo "myriver";
//exit();


$options = array();

$page_type = preg_replace('[\W]', '', get_input('page_type', 'all'));
$type = preg_replace('[\W]', '', get_input('type', 'all'));
$subtype = preg_replace('[\W]', '', get_input('subtype', ''));
if ($subtype) {
	$selector = "type=$type&subtype=$subtype";
} else {
	$selector = "type=$type";
}

if ($type != 'all') {
	$options['type'] = $type;
	if ($subtype) {
		$options['subtype'] = $subtype;
	}
}

switch ($page_type) {
	case 'mine':
		$title = elgg_echo('river:mine');
		$page_filter = 'mine';
		$options['subject_guid'] = elgg_get_logged_in_user_guid();
		break;
	case 'friends':
		$title = elgg_echo('river:friends');
		$page_filter = 'friends';
		$options['relationship_guid'] = elgg_get_logged_in_user_guid();
		$options['relationship'] = 'friend';
		break;
	default:
		$title = elgg_echo('river:all');
		$page_filter = 'all';
		break;
}



//init the action settings
$options['action_types']=array('friend','comment','create');




//get the value of the plugin setting. add or delete value to the   //options['action_types']
$ac_create=elgg_get_plugin_setting('actiontype_create','controlactivity');

//echo $ac_create;
//exit();

 if($ac_create=='display')
 {  
    
    $options['action_types'][]='create';
	array_unique($options['action_types']);
 }
  
 else if($ac_create=='nodisplay')
 {    
     if($index=array_search('create',$options['action_types']));
	 {
         unset($options['action_types'][$index]);
	 }


 }


//action type of friend as action type of create to process
$ac_friend=elgg_get_plugin_setting('actiontype_friend','controlactivity');

if($ac_friend=='display')
 {  
    
	$options['action_types'][]='friend';
	array_unique($options['action_types']);
 }
  
 else if($ac_friend=='nodisplay')
 {
    if($index=array_search('friend',$options['action_types']));
	 {
         unset($options['action_types'][$index]);
	 }

 }


//action type of comment as action type of create to process
$ac_comment=elgg_get_plugin_setting('actiontype_comment','controlactivity');

if($ac_comment=='display')
 {  
   
    $options['action_types'][]='comment';
	array_unique($options['action_types']);
 }
  
 else if($ac_comment=='nodisplay')
 {
    if($index=array_search('comment',$options['action_types']));
	 {
         unset($options['action_types'][$index]);
	 }

 }




// get activity

$activity = elgg_list_river($options);
if (!$activity) {
	$activity = elgg_echo('river:none');
}

$content = elgg_view('core/river/filter', array('selector' => $selector));

$sidebar = elgg_view('core/river/sidebar');

$params = array(
	'content' =>  $content . $activity,
	'sidebar' => $sidebar,
	'filter_context' => $page_filter,
	'class' => 'elgg-river-layout',
);

$body = elgg_view_layout('content', $params);

echo elgg_view_page($title, $body);





?>