Notes:

* A simple tinymce plugin

Instructions:

Drop into mod, enable in the admin planel and use.