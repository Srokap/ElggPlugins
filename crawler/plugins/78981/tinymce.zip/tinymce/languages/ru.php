<?php

// Generate By translationbrowser. 

$russian = array( 
	 'tinymce:remove'  =>  "Добавить/удалить редактор"
); 

add_translation('ru', $russian); 

?>