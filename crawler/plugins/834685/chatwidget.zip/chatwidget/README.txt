Like Elgg, GPL V. 2.

You can edit the css to change the look of the chat widget by going to mod/chatwidget/views/default/css

Im not responsible for any damage this may cause to your site.

Use at your own risk. As much as i would love to guarantee that it works perfectly i cant say because it was only tested on my site.

Sorry if i sound harsh :)
