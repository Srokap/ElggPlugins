<?php

/**
 *  Admin CSS
 */

?>

/* ***************************************
	SETTINGS
*****************************************/
#basic_light-settings{
	width: 460px;
    padding:30px;
    border:1px solid #CCC;
}
#basic_light-settings .label{
	font-size: 1.2em;
    font-weight: bold;
}
#basic_light-settings .elgg-input-dropdown{
	float: right;
	margin-left: 8px;
}
.disabled{
	color: red;
}
