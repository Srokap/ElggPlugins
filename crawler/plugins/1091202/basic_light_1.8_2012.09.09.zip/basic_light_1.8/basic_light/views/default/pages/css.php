<?php
/**
 * Elgg Pages CSS
 *
 * @package ElggPages
 */
?>

.pages-nav.treeview ul {
	background-color: transparent;
}

.pages-nav.treeview a.selected {
	color: #666;
	background: none;
}

.pages-nav.treeview .hover {
	color: #666;
}