<?php
/**
 * File CSS extender 
 * 
 * @package ElggFile
 */
?>
.file-photo {
	text-align: center;
	margin-bottom: 15px;
    margin-top: 15px;
}
.file-gallery-item {
	text-align: center;
	width: 165px;
    margin:0 3px 15px 3px;
}
