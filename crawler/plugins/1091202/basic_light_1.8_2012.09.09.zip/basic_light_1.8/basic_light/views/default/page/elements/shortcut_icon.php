<?php
/**
 * Displays the default shortcut icon
 */
?>

<link rel="SHORTCUT ICON" href="<?php echo elgg_get_site_url(); ?>mod/basic_light/graphics/favicon.ico" />