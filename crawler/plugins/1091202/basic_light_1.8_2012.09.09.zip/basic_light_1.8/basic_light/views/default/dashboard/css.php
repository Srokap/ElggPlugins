<?php
/**
 * User dashboard CSS
 */
?>

#dashboard-info {
	margin-bottom: 15px; 
	border: 1px solid #D1D7DB;
    
	-webkit-border-radius: 3px;
	-moz-border-radius: 3px;
	border-radius: 3px;
}
