<?php

/**
 * Basic Light topbar
 * 
 */

?>

<div class="elgg-navbar">
    <div class="elgg-navbar-inner">
		<!-- Just an empty topbar -->
    </div><!-- /.elgg-navbar-inner -->
</div><!-- /.elgg-navbar -->

