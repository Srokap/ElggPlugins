<?php
/**
 * Custom Index CSS
 *
 */
?>

/*******************************
	Custom Index
********************************/
.custom-index {
	padding: 10px 0;
}


