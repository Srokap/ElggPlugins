<?php
/**
* Kaltura video client
* @package ElggKalturaVideo
* @license http://www.gnu.org/licenses/gpl.html GNU Public License version 3
* @author Ivan Vergés <ivan@microstudi.net>
* @copyright Ivan Vergés 2010
* @link http://microstudi.net/elgg/
**/

?>
	<p class="user_menu_kaltura_video">
	<a href="<?php echo $vars['url']; ?>pg/kaltura_video/<?php echo $vars['entity']->username; ?>"><?php echo elgg_echo("kalturavideo:userprofile"); ?></a>
	</p>
