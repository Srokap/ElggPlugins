<?php
//virtual_Keyboard  start.php
//dise�ado por www.floops.com.ar
//la red social argentina

function virtual_Keyboard_init(){}

register_elgg_event_handler('init','system','virtual_Keyboard_init');
?>
