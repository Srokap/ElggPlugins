<?php
 
    function webgall_adsense_analytics_init()
    {
    }
 
    register_elgg_event_handler('init','system','webgall_adsense_analytics_init');
 
?>