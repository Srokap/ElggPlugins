<?php
	$analytics = $vars['entity']->analytics;
	$spotlight = $vars['entity']->spotlight;
	$adsenseclientid = $vars['entity']->adsenseclientid;
?>
<p><b><?php echo elgg_echo('Google Analytics and Adsense');?></b></p>
  <p>
    <?php echo elgg_echo("Analytics tracker id, Looks like UA-1234567-8"); ?><br />
	<?php
		echo elgg_view('input/text', array(
			'internalname' => 'params[analytics]',
			'value' => $analytics
		));
	?>
  </p>
  
  
  <p>
    <?php echo elgg_echo("Google adsense Client Id, Looks like pub-12345678900987"); ?><br />
	<?php
		echo elgg_view('input/text', array(
			'internalname' => 'params[adsenseclientid]',
			'value' => $adsenseclientid
		));
	?>
  </p>
  
  
  <p>
    <?php echo elgg_echo("Adsense slot id for the spotlight,(728x90px)"); ?><br />
	<?php
		echo elgg_view('input/text', array(
			'internalname' => 'params[spotlight]',
			'value' => $spotlight
		));
	?>
  </p>
  <p>
    <?php echo elgg_echo("Slot id will look like 1234567890"); ?><br />
    <?php echo elgg_echo("You need to enter both the Client Id and slot id to display Ads"); ?><br />
    <?php echo elgg_echo("Upgrade to the full version for more adsense options!! You can purchase the full version"); ?>
    <a href="http://webgalli.com/pg/groups/15/google-adsense-and-analytics-plugin-for-elgg/"><?php echo elgg_echo("HERE"); ?></a><br />
  </p>
