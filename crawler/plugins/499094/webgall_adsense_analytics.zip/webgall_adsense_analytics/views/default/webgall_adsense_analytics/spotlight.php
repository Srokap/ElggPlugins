<div align="center">
<?php
				$adsenseclientid = get_plugin_setting('adsenseclientid', 'webgall_adsense_analytics');
				$spotlight = get_plugin_setting('spotlight', 'webgall_adsense_analytics');
?>
<script type="text/javascript"><!--
google_ad_client = "<?php echo $adsenseclientid; ?>";
google_ad_slot = "<?php echo $spotlight; ?>";
/* 728x90, created 5/14/10 */
google_ad_width = 728;
google_ad_height = 90;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</div>