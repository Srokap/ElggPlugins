<?php

	/**
	 * Elgg default spotlight
	 * The spotlight area that displays across the site
	 * 
	 * @package Elgg
	 * @subpackage Core

	 * @author Curverider Ltd

	 * @link http://elgg.org/
	 * 
	 */
?>
		<?php
            
               echo elgg_view("webgall_adsense_analytics/spotlight");
                
        ?>
