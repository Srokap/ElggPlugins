<?php

    /**
     * dynamic Spotligh
     **/
     
     /**
	 * Initialise the plugin 
	 *
	 */
	function dynmSpot_init(){
	
    }
	
	// Initialise log browser
	register_elgg_event_handler('init','system','dynmSpot_init');
	
?>