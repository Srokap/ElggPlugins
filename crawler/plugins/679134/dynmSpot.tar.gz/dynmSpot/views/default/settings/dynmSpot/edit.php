<p>
  <?php echo elgg_echo('dynmSpot:settings:dynText'); ?>
 <textarea name="params[dynText]"></textarea>
 <?php set_plugin_setting($dynText, $vars['entity']->dynText, $dynmSpot = "");?>
</p>
