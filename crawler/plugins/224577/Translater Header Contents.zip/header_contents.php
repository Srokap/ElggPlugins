<?php

	/**
	 * Modified Translator Elgg header contents
	 * This file holds the header output that a user will see
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2009
	 * @link http://elgg.org/
         * @This header has been modified by Demented Mind Productions & CMJ Productions to provide basic Google translation right in the header.
	 **/
	 
?>

<div id="page_container">
<div id="page_wrapper">

<div id="layout_header">
<div id="wrapper_header">
	<!-- display the page title --><table width="100%"><tr align="center"><td align="left" valign="top">
	<h1><a href="<?php echo $vars['url']; ?>"><?php echo $vars['config']->sitename; ?></a></h1></td><td width="40%"></td>
<td align="right" valign="top" width="170">
<script type="text/javascript">
function translate()
   {
   var posisi = document.f_googletranslator.tl.selectedIndex;
   var tl_value = document.f_googletranslator.tl.options[posisi].value;
   document.f_googletranslator.u.value = window.location.href;
   var google_url = 'http://translate.google.com/translate?u=' + document.f_googletranslator.u.value + '&hl=en&ie=UTF-8&sl=auto&tl=' + tl_value ;
   //document.f_googletranslator.submit(); 
   window.location.href = google_url;

   return true;
   }
</script>
 
<form id="f_googletranslator" name="f_googletranslator" method="post" action="http://translate.google.com/translate"><br/>  
    <select name="tl">
      <option  value="ar">Arabic</option>
	<option  value="bg">Bulgarian</option>
	<option  value="ca">Catalan</option>
	<option  value="zh-CN">Chinese</option>
	<option  value="hr">Croatian</option>
	<option  value="cs">Czech</option>
	<option  value="da">Danish</option>
	<option  value="nl">Dutch</option>
	<option  value="en">English</option>
	<option  value="et">Estonian</option>
	<option  value="tl">Filipino</option>
	<option  value="fi">Finnish</option>
	<option  value="fr">French</option>
	<option  value="de">German</option>
	<option  value="el">Greek</option>
	<option  value="iw">Hebrew</option>
	<option  value="hi">Hindi</option>
	<option  value="id">Indonesian</option>
	<option  value="it">Italian</option>
	<option  value="ja">Japanese</option>
	<option  value="ko">Korean</option>
	<option  value="lv">Latvian</option>
	<option  value="lt">Lithuanian</option>
	<option  value="no">Norwegian</option>
	<option  value="pl">Polish</option>
	<option  value="pt">Portuguese</option>
	<option  value="ro">Romanian</option>
	<option  value="ru">Russian</option>
	<option  value="sr">Serbian</option>
	<option  value="sk">Slovak</option>
	<option  value="sl">Slovenian</option>
	<option SELECTED value="es">Spanish</option>
	<option  value="sv">Swedish</option>
	<option  value="uk">Ukrainian</option>
	<option  value="vi">Vietnamese</option>
  </select><input name="hl" value="en" type="hidden" /><input name="ie" value="UTF-8" type="hidden" /><input name="sl" value="auto" type="hidden" /><input 

name="u" value="http://vivociti.com" type="hidden" />  
    <input type="button" name="Submit" value="Go" onclick="translate()"/>
</form>
</td></tr></table>

</div><!-- /#wrapper_header -->

</div><!-- /#layout_header -->