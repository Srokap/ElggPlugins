<?php
	$english = array(
		'searchcloud' => "Search Cloud",
		'searchcloud:title' => "Search Cloud",
		'item:object:searchstats' => "SearchCloud statistics",
		
		
		'searchcloud:reset' => "Reset search statistics",
		'searchcloud:reset:success' => "Reset successful",
		'searchcloud:reset:error' => "Reset failed",
		
	);
	
	add_translation("en", $english);
?>
