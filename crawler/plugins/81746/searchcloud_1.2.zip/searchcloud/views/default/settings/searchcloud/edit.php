<?php
	/**
	* Search Cloud - admin settings
	* 
	* @package searchcloud
	* @author ColdTrick IT Solutions
	* @copyright Coldtrick IT Solutions 2009
	* @link http://www.coldtrick.com/
	*/
?>
<p>
	<input type="button" onclick="document.location.href='<?php echo $vars['url'] . "action/searchcloud/reset"; ?>'" value="<?php echo elgg_echo("searchcloud:reset");?>"/>
</p>