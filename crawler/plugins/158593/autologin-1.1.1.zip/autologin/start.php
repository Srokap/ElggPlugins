<?php
	/*
	*	Elgg Third Party AutoLogin Plugin
	*	By Simon Bazley
	*
	* @package autologin
	* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	* @author BrainMedia Ltd (info@brain-media.co.uk)
	* @copyright (c) BrainMedia Ltd 2009
	* @link http://www.BrainDash.com/
	*/

	define('AUTOLOGIN_NOCOOKIE',		1);
	define('AUTOLOGIN_BADCOOKIE',		2);
	define('AUTOLOGIN_NOTLOGGEDIN',		3);
	define('AUTOLOGIN_NOTREGISTERED',	4);
	// If it all goes wrong, turn this on
	define('AUTOLOGIN_PANIC_I_CANT_LOGIN', 0);

	function autologin_init()
	{
		// If it all goes wrong, PANIC!!!!!
		if (!AUTOLOGIN_PANIC_I_CANT_LOGIN) {
			// If we're not logged in, try logging in
			if (isloggedin()) {
				if (get_plugin_setting('doautologout', 'autologin') &&
					autologin_is_loggedinto_thirdparty()==0) {
					$result = logout();
				}
			} else {
				autologin_try_login();
			}
		}
	}

	function autologin_try_login($warnuser=true)
	{
		try {
			$UserID = autologin_get_thirdparty_id();
			$user	= autologin_get_user($UserID);
			$result = login($user, false);
			if (!get_plugin_setting('dontshowwarnings', 'autologin'))
				system_message(sprintf(elgg_echo('autologin:userloggedin'),$user['name']));
			//if (!get_plugin_setting('dontshowwarnings', 'autologin'))
			//	system_message(sprintf(elgg_echo('autologin:loggedin'),$user));

//			if ($result) {
				// So it succeeded, so what now? leave alone I guess
				// results in not being able to go anywhere else
//				forward("pg/dashboard/");
//			} else {
				// it failed so what do we do? Nothing I think
//			}
			
		} catch (Exception $e) {
			if (!get_plugin_setting('dontshowwarnings', 'autologin'))
				system_message($e->getMessage());
		}
	}

	function autologin_is_loggedinto_thirdparty()
	{
		$UserID = 0;
		try {
			$UserID = autologin_get_thirdparty_id();
		} catch (Exception $e) {
			// for whatever reason, it failed
		}
		return $UserID;
	}

	function autologin_get_thirdparty_ident_cookie()
	{
		$forcecookievalue = (get_plugin_setting('forcecookievalue', 'autologin')==1);
		if ($forcecookievalue) {
			$thirdparty_forced_sessionid	= 
				get_plugin_setting('thirdparty_forced_sessionid', 'autologin');
			return $thirdparty_forced_sessionid;
		} else {
			$thirdparty_ident_type	= 
				get_plugin_setting('thirdparty_ident_type', 'autologin');
			//system_message("ThirdParty Ident Type is ".$thirdparty_ident_type);
			$thirdpartycookie	= get_plugin_setting('thirdparty_cookie_name', $pluginname);
			if (!isset($thirdparty_ident_type) || ($thirdparty_ident_type==0)) {
				$CookieID	= $_COOKIE[$thirdpartycookie];
				return $CookieID;
			} else if ($thirdparty_ident_type==1) {
				$CookieID	= $_REQUEST[$thirdpartycookie];
				return $CookieID;
			}
		}
	}

	function autologin_get_thirdparty_id()
	{
		$thirdparty_user_loggedin_field		= get_plugin_setting('thirdparty_user_loggedin', 'autologin');
		$thirdparty_user_loginname_field	= get_plugin_setting('thirdparty_user_loginname', 'autologin');
		$thirdparty_user_id_field		= get_plugin_setting('thirdparty_user_id', 'autologin');

		$UserUniqueID = autologin_get_thirdparty_ident_cookie();
		if (empty($UserUniqueID))
			throw new Exception(elgg_echo('autologin:nocookie'), AUTOLOGIN_NOCOOKIE);
		else if (!get_plugin_setting('dontshowwarnings', 'autologin'))
				system_message(sprintf(elgg_echo('autologin:cookieis'),$UserUniqueID));
		$UserData = autologin_interrogate_thirdparty_site($UserUniqueID);
		if (empty($UserData) || $UserData===false)
			throw new Exception(elgg_echo('autologin:badcookie'), AUTOLOGIN_BADCOOKIE);
		else if (!get_plugin_setting('dontshowwarnings', 'autologin'))
				system_message(sprintf(elgg_echo('autologin:userloginis'),$UserData[$thirdparty_user_loginname_field]));
		if ($UserData[$thirdparty_user_loggedin_field]==0)
			throw new Exception(
		sprintf(elgg_echo('autologin:usernotloggedin'), $UserData[$thirdparty_user_loginname_field]), AUTOLOGIN_NOTLOGGEDIN);
		else if (!get_plugin_setting('dontshowwarnings', 'autologin'))
				system_message(sprintf(elgg_echo('autologin:useridis'),$UserData[$thirdparty_user_id_field]));
		return $UserData[$thirdparty_user_id_field];
	}

	function autologin_get_user($UserID)
	{
		$thirdparty_metafield_name		= get_plugin_setting('thirdparty_metafield', 'autologin');
		$UserIDMetaS= find_metadata($thirdparty_metafield_name, $UserID, 'user');
		if (empty($UserIDMetaS))
			throw new Exception(elgg_echo('autologin:usernotregistered'), AUTOLOGIN_NOTREGISTERED);
		$UserGUID = $UserIDMetaS[0]->entity_guid;
		if (!get_plugin_setting('dontshowwarnings', 'autologin'))
				system_message(sprintf(elgg_echo('autologin:userGUIDis'),$UserGUID));
		$User = get_user($UserGUID);
		return $User;
	}


	function autologin_interrogate_thirdparty_site($CookieID)
	{
		global $ThirdPartyUserData;
		$debug = get_plugin_setting('debugthirdpartyxml', 'autologin');

		$thirdpartyxmlrpcparam	= get_plugin_setting('thirdparty_xmlrpc_param', 'autologin');
		$params = array (
			$thirdpartyxmlrpcparam  => $CookieID,
		);
		$XMLOptions     = array(
			'output_type'	=> 'xml',
			'verbosity'	=> 'pretty',
			'version'	=> 'xmlrpc',
			'debug'		=> 2);

		$thirdpartyxmlrpcproc	= get_plugin_setting('thirdparty_xmlrpc_proc', 'autologin');
		$request = xmlrpc_encode_request($thirdpartyxmlrpcproc, $params, $XMLOptions);
		if ($debug) {
			system_message(htmlentities($request));
		}
		$context = stream_context_create(
		array(
			'http'  => array(
				'method'        => "POST",
				'header'        => "Content-Type: text/xml",
				'content'       => $request,
				)
			)
		);

//		$thirdpartyxmlrpcurl	= "http://www.braindash.com/"

		$thirdpartyxmlrpcurl	= get_plugin_setting('thirdparty_xmlrpc_url', 'autologin');

		$file = file_get_contents($thirdpartyxmlrpcurl, false, $context);
		if ($debug) {
			//system_message($file);
			system_message(htmlentities($file));
		}
		$response = xmlrpc_decode($file);
		if ($debug) {
			ob_start();
			var_dump($response);
			$dumpped_response = ob_end_clean();
			//system_message("<pre>".$dumpped_response."</pre>\n");
			system_message("<pre>".htmlentities($dumpped_response)."</pre>\n");
			//system_message("<pre>".$dumpped_response."</pre>\n");
		}
		$ThirdPartyUserData=$response;

		if (xmlrpc_is_fault($response)) {
			$response = $response['faultString'];
			return false;
		}

		// My XML-RPC function doesn't return correctly formed errors

		if (isset($response['Status']) && $response['Status']=='ERROR')
			return false;
		return $response;
	}

	// Initialise 
	register_elgg_event_handler('init','system','autologin_init');
?>
