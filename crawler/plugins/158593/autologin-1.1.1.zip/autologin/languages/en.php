<?php
	/*
	*	Elgg Third Party AutoLogin Plugin - English Language translation
	*	By Simon Bazley
	*
	* @package autologin
	* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	* @author BrainMedia Ltd (info@brain-media.co.uk)
	* @copyright (c) BrainMedia Ltd 2009
	* @link http://www.BrainDash.com/
	*/

	$english = array(
	
		/**
		 * Error Reasons
		 */
	
		'autologin:nocookie'		=> "User Doesn't have a ThirdParty System Cookie",
		'autologin:badcookie'		=> "Cookie mis-match.  Third Party System doesn't recognise ID",
		'autologin:usernotloggedin'	=> "User '%s' isn't logged into ThirdParty System",
		'autologin:usernotregistered'	=> "ThirdParty User isn't registered here",

		/**
		 * Success/Log Comments
		 */
		'autologin:cookieis'		=> "Third Party Cookie value is %s",
		'autologin:userloginis'		=> "Cookie looked up user %s",
		'autologin:useridis'		=> "External user logged in, and has ID %s",
		'autologin:userGUIDis'		=> "Successfully looked up local user, GUID: %s",
		'autologin:userloggedin'	=> "User %s Successfully Logged on",

		/**
		 * Settings Page
		 */

		/**
		 * Headings
		 */
		'autologin:settings:heading'			=>
			"AutoLogin settings",
		'autologin:settings:headings:thirdparty_cookie_name'			=>
			"Third party site's Ident settings",
		'autologin:settings:headings:thirdparty_xmlrpc_settings'		=>
			"Third party site's XML-RPC service settings",
		'autologin:settings:headings:thirdparty_xmlrpc_response_details'=>
			"Field names in the XML-RPC response",
		'autologin:settings:headings:thirdparty_user_metafield_details'	=>
			"MetaField names (see CoReg Plugin)",

		/**
		 * Free text (notes)
		 */
		'autologin:settings:instructions'			=>
			"While you are setting up autologin, leave AutoLogout to no, ".
			"and watch the warnings generated to check it's working. ".
			"When you're sure, turn off Warnings and turn on AutoLogout.  ",
		'autologin:settings:healthwarning'	=>
			"Health Warning: If you turn on AutoLogout, and Elgg cannot ".
			"access your ThirdParty site, you will be unable to login to Elgg",
		'autologin:settings:panichint'		=>
			"In an emergency, if you need to bypass autologout, edit ".
			"mod/autologin/start.php and define AUTOLOGIN_PANIC_I_CANT_LOGIN as 1",

		/**
		 * Setting Labels
		 */
		'autologin:settings:doautologout'				=>
			"Do Auto Logout (see health warning)",
		'autologin:settings:showwarnings'				=>
			"Show warning messages?",
		'autologin:settings:thirdparty_cookie_name'		=>
			"What is the name of the Ident variable used by the Third party site?",
		'autologin:settings:thirdparty_ident_type'		=>
			"The ThirdParty Ident string, can be found by accessing: ",
		'autologin:usecookie'							=>
			"Cookies array",
		'autologin:userequest'							=>
			"Requests array",
		'autologin:settings:forcecookievalue'			=>
			"Don't lookup the cookie, just force the SessionID",
		'autologin:settings:thirdpartyforcedsessionid'	=>
			"The value to use as the forced SessionID",
		'autologin:settings:thirdparty_xmlrpc_url'		=>
			"The URL to call with the XML-RPC request (ie http://user:pass@your-site/xml-rpc.php)",
		'autologin:settings:thirdparty_xmlrpc_proc'		=>
			"The Procedure to request as part of the XML-RPC (ie user.getuserid)",
		'autologin:settings:thirdparty_xmlrpc_param'	=>
			"The name of the parameter, that will contain the SessionID (ie SessionID)",
		'autologin:settings:debugthirdparty_xmlrpc'		=>
			"Turn on XMl-RPC debugging, so log the XML-RPC request and response",
		'autologin:settings:thirdparty_user_loggedin'	=>
			"The name of the field that tells us the user is logged in (ie IsLoggedIn)",
		'autologin:settings:thirdparty_user_loginname'	=>
			"The field giving the users displayable name (ie UserName)",
		'autologin:settings:thirdparty_user_id'			=>
			"The field that will identify the remote user here (ie UserID)",
		'autologin:settings:thirdparty_metafield'		=>
			"The name of the metafield used to store the remote users id (ie userid)",
	);
					
	add_translation("en",$english);

?>
