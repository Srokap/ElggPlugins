<?php
	/*
	*	Elgg Third Party AutoLogin Plugin - edit settings file
	*	By Simon Bazley
	*
	* @package autologin
	* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	* @author BrainMedia Ltd (info@brain-media.co.uk)
	* @copyright (c) BrainMedia Ltd 2009
	* @link http://www.BrainDash.com/
	*/

/**
 * Default Settings
 */

$doautologout = 0;
$dontshowwarnings = 0;

// The cookie name, used by BrainDash.com
$thirdpartycookie		= "BrainDash.com";
$forcecookievalue = 0;
$thirdparty_forced_sessionid ="";
$thirdpartyidenttype = 0;

// The parameters used in forming the XML-RPC request
$thirdpartyxmlrpcparam	= "SessionID";
$thirdpartyxmlrpcproc	= "user.getuserid";

// Where to serve the request
$thirdpartyxmlrpcurl	= "http://user:pass@your-site/xml-rpc.php";

// The following are fields expected in the response
$thirdparty_user_loggedin_field		= "IsLoggedIn";
$thirdparty_user_loginname_field	= "UserName";
$thirdparty_user_id_field			= "UserID";

// The following is the name of the metafield (as set by coreg) used to look up a user
$thirdparty_metafield_name			= "userid";

/**
 *  Set the Default Values
 */

// Use this plugin name for everything in this file
$pluginname = 'autologin';

// Uncomment this, and dis/re-enable plugin to reset to BrainDash.com default settings
//include(dirname(__FILE__).'/BDdefaults.php');

if (!get_plugin_setting('doautologout', $pluginname)) {
	set_plugin_setting('doautologout', $doautologout, $pluginname);
}
if (!get_plugin_setting('dontshowwarnings', $pluginname)) {
	set_plugin_setting('dontshowwarnings', $dontshowwarnings, $pluginname);
}
if (!get_plugin_setting('thirdparty_cookie_name', $pluginname)) {
	set_plugin_setting('thirdparty_cookie_name', $thirdpartycookie, $pluginname);
}
if (!get_plugin_setting('thirdparty_ident_type', $pluginname)) {
	set_plugin_setting('thirdparty_ident_type', $thirdpartyidenttype, $pluginname);
}
if (!get_plugin_setting('forcecookievalue ', $pluginname)) {
	set_plugin_setting('forcecookievalue ', $forcecookievalue , $pluginname);
}
if (!get_plugin_setting('thirdparty_forced_sessionid', $pluginname)) {
	set_plugin_setting('thirdparty_forced_sessionid', $thirdparty_forced_sessionid, $pluginname);
}
if (!get_plugin_setting('thirdparty_xmlrpc_param', $pluginname)) {
	set_plugin_setting('thirdparty_xmlrpc_param', $thirdpartyxmlrpcparam, $pluginname);
}
if (!get_plugin_setting('thirdparty_xmlrpc_proc', $pluginname)) {
	set_plugin_setting('thirdparty_xmlrpc_proc', $thirdpartyxmlrpcproc, $pluginname);
}
if (!get_plugin_setting('thirdparty_xmlrpc_url', $pluginname)) {
	set_plugin_setting('thirdparty_xmlrpc_url', $thirdpartyxmlrpcurl, $pluginname);
}
if (!get_plugin_setting('thirdparty_user_loggedin', $pluginname)) {
	set_plugin_setting('thirdparty_user_loggedin', $thirdparty_user_loggedin_field, $pluginname);
}
if (!get_plugin_setting('thirdparty_user_loginname', $pluginname)) {
	set_plugin_setting('thirdparty_user_loginname', $thirdparty_user_loginname_field, $pluginname);
}
if (!get_plugin_setting('thirdparty_user_id', $pluginname)) {
	set_plugin_setting('thirdparty_user_id', $thirdparty_user_id_field, $pluginname);
}
if (!get_plugin_setting('thirdparty_metafield', $pluginname)) {
	set_plugin_setting('thirdparty_metafield', $thirdparty_metafield_name, $pluginname);
}

/**
 *  Load the current Values
 */

$thirdparty_cookie_name		= get_plugin_setting('thirdparty_cookie_name', $pluginname);
$thirdparty_ident_type		= get_plugin_setting('thirdparty_ident_type', $pluginname);
$thirdparty_forced_sessionid= get_plugin_setting('thirdparty_forced_sessionid', $pluginname);
$thirdparty_xmlrpc_param	= get_plugin_setting('thirdparty_xmlrpc_param', $pluginname);
$thirdparty_xmlrpc_proc		= get_plugin_setting('thirdparty_xmlrpc_proc', $pluginname);
$thirdparty_xmlrpc_url		= get_plugin_setting('thirdparty_xmlrpc_url', $pluginname);
$thirdparty_user_loggedin	= get_plugin_setting('thirdparty_user_loggedin', $pluginname);
$thirdparty_user_loginname	= get_plugin_setting('thirdparty_user_loginname', $pluginname);
$thirdparty_user_id			= get_plugin_setting('thirdparty_user_id', $pluginname);
$thirdparty_metafield		= get_plugin_setting('thirdparty_metafield', $pluginname);

/**
 *  setup each item on the form
 */

$doautologout = elgg_view('input/pulldown', array(
	'internalname' => 'params[doautologout]',
	'value' => get_plugin_setting('doautologout', $pluginname),
	'options_values' => array(
		1 => elgg_echo('option:yes'),
		0 => elgg_echo('option:no')
		)
	)
);
$showwarnings = elgg_view('input/pulldown', array(
	'internalname' => 'params[dontshowwarnings]',
	'value' => get_plugin_setting('dontshowwarnings', $pluginname),
	'options_values' => array(
		1 => elgg_echo('option:no'),
		0 => elgg_echo('option:yes')
		)
	)
);
$thirdpartycookiename= elgg_view('input/text', array(
	'internalname'	=> 'params[thirdparty_cookie_name]',
	'value'			=> $thirdparty_cookie_name,
	)
);
$thirdpartyidenttype = elgg_view('input/pulldown', array(
	'internalname' => 'params[thirdparty_ident_type]',
	'value' => get_plugin_setting('thirdparty_ident_type', $pluginname),
	'options_values' => array(
		0 => elgg_echo('autologin:usecookie'),
		1 => elgg_echo('autologin:userequest')
		)
	)
);
$forcecookievalue = elgg_view('input/pulldown', array(
	'internalname' => 'params[forcecookievalue]',
	'value' => get_plugin_setting('forcecookievalue', $pluginname),
	'options_values' => array(
		1 => elgg_echo('option:yes'),
		0 => elgg_echo('option:no')
		)
	)
);
$thirdpartyforcedsessionid= elgg_view('input/text', array(
	'internalname'	=> 'params[thirdparty_forced_sessionid]',
	'value'			=> $thirdparty_forced_sessionid,
	)
);
$thirdpartyxmlrpcparam= elgg_view('input/text', array(
	'internalname'	=> 'params[thirdparty_xmlrpc_param]',
	'value'			=> $thirdparty_xmlrpc_param,
	)
);
$thirdpartyxmlrpcproc= elgg_view('input/text', array(
	'internalname'	=> 'params[thirdparty_xmlrpc_proc]',
	'value'			=> $thirdparty_xmlrpc_proc,
	)
);
$thirdpartyxmlrpcurl= elgg_view('input/url', array(
	'internalname'	=> 'params[thirdparty_xmlrpc_url]',
	'value'			=> $thirdparty_xmlrpc_url,
	)
);
$debugthirdpartyxml = elgg_view('input/pulldown', array(
	'internalname' => 'params[debugthirdpartyxml]',
	'value' => get_plugin_setting('debugthirdpartyxml', $pluginname),
	'options_values' => array(
		0 => elgg_echo('option:no'),
		1 => elgg_echo('option:yes'),
		)
	)
);
$thirdpartyuserloggedin =elgg_view('input/text', array(
	'internalname'	=> 'params[thirdparty_user_loggedin]',
	'value'			=> $thirdparty_user_loggedin,
	)
);
$thirdpartyuserloginname= elgg_view('input/text', array(
	'internalname'	=> 'params[thirdparty_user_loginname]',
	'value'			=> $thirdparty_user_loginname,
	)
);
$thirdpartyuserid= elgg_view('input/text', array(
	'internalname'	=> 'params[thirdparty_user_id]',
	'value'			=> $thirdparty_user_id,
	)
);
$thirdpartymetafield= elgg_view('input/text', array(
	'internalname'	=> 'params[thirdparty_metafield]',
	'value'			=> $thirdparty_metafield,
	)
);

/**
 *  Print the form
 */
?>
<p>
	<b><?php echo elgg_echo('autologin:settings:heading'); ?></b><br />
	<p><?php echo elgg_echo('autologin:settings:instructions'); ?></p>
	<b><i><?php echo elgg_echo('autologin:settings:healthwarning'); ?></i></b></p>
	<p><i><?php echo elgg_echo('autologin:settings:panichint'); ?></i></p>
</p>
<p>
	<label><?php echo elgg_echo('autologin:settings:doautologout'); echo $doautologout; ?></label><br />
	<?php echo elgg_echo('autologin:settings:showwarnings'); echo $showwarnings; ?><br />
	<hr />
	<b><?php echo elgg_echo('autologin:settings:headings:thirdparty_cookie_name'); ?></b><br />
	<?php echo elgg_echo('autologin:settings:thirdparty_cookie_name'); echo $thirdpartycookiename; ?><br />
	<?php echo elgg_echo('autologin:settings:thirdparty_ident_type'); echo $thirdpartyidenttype; ?><br />
	<?php echo elgg_echo('autologin:settings:forcecookievalue'); echo $forcecookievalue; ?><br />
	<?php echo elgg_echo('autologin:settings:thirdpartyforcedsessionid'); echo $thirdpartyforcedsessionid; ?><br />
	<hr />
	<b><?php echo elgg_echo('autologin:settings:headings:thirdparty_xmlrpc_settings'); ?></b><br />
	<?php echo elgg_echo('autologin:settings:thirdparty_xmlrpc_url'); echo $thirdpartyxmlrpcurl; ?><br />
	<?php echo elgg_echo('autologin:settings:thirdparty_xmlrpc_proc'); echo $thirdpartyxmlrpcproc; ?><br />
	<?php echo elgg_echo('autologin:settings:thirdparty_xmlrpc_param'); echo $thirdpartyxmlrpcparam; ?><br />
	<?php echo elgg_echo('autologin:settings:debugthirdparty_xmlrpc'); echo $debugthirdpartyxml; ?><br />
	<hr />
	<b><?php echo elgg_echo('autologin:settings:headings:thirdparty_xmlrpc_response_details'); ?></b><br />
	<?php echo elgg_echo('autologin:settings:thirdparty_user_loggedin'); echo $thirdpartyuserloggedin; ?><br />
	<?php echo elgg_echo('autologin:settings:thirdparty_user_loginname'); echo $thirdpartyuserloginname; ?><br />
	<?php echo elgg_echo('autologin:settings:thirdparty_user_id'); echo $thirdpartyuserid; ?><br />
	<b><?php echo elgg_echo('autologin:settings:headings:thirdparty_user_metafield_details'); ?></b><br />
	<?php echo elgg_echo('autologin:settings:thirdparty_metafield'); echo $thirdpartymetafield; ?><br />
</p>
