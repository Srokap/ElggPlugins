	/*
	*	Elgg Third Party AutoLogin Plugin
	*	By Simon Bazley
	*
	* @package autologin
	* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	* @author BrainMedia Ltd (info@brain-media.co.uk)
	* @copyright (c) BrainMedia Ltd 2009
	* @link http://www.BrainDash.com/
	*/

1) Put the autologin directory into the mod folder
(this one is planned, but not coded yet)
2) Go to administration-tools-autologin-config and setup your the various configuration options

3) Test your setup and check that you (adminisitrator) get automatically logged into Elgg using some login on the other site

4) When you're happy it works, turn off warning messages and turn on Auto Logout

5) Now off you go.  

Some important notes and health warnings though:-

!!!Health Warning: If you turn on AutoLogout, and Elgg cannot access your ThirdParty site, you will be unable to login to Elgg!!!

I'm not joking, AutoLogin assumes no valid cookie, to mean you're logged off of the third party site, and it should log you off of Elgg.  
If you click save in the settings box, and it can't access the third party site, you will be logged out and unable to log back in, until you fix the third party site or disable AutoLogin's autologout feature.

//In an emergency, if you need to bypass autologout, edit mod/autologin/start.php and define AUTOLOGIN_PANIC_I_CANT_LOGIN as 1//

To aid those that want to see how this works, here's the process flow:-

1) First autologin checks for the named cookie, and looks up the value contained therein.
2) Then it forms an xml-rpc request for named function, with one parameter, using the name given, and the value looked up from the cookie.
3) It then sends that request to the named server.
4) The response is checked for errors, then if it is a success...
5) It checks the response for a the named field to see if the user is loggedin.  
6) If they are it wll check for the named field to get the UserID
7) Finally it will attempt to lookup a metadata object locally, using the given field name, and the UserID value
8) It will then use that metadata object to lookup a user locally and log them in

When doing the auto logout, it goes up to #5 and logs out if it doesn't get a value for any reason, it assumes the user is logged out.

