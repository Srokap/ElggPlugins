This is a plugin to embed videos from Kaltura in egg 1.2.

AUTHOR:

Ivan Vergés
05/03/2009
ivan@microstudi.net


FEATURES:

	Version 0.9.5

	This plugin for Elgg allows you:
	- Create videos very easy from various sources using the contribution wizard 
	  application provided in the Kaltura API.
	  The sources can be:
	   - Your webcam
	   - Uploaded videos, audio, photos.
	   - Easily import all rich media (video, audio, pictures...) from other
		 sites and social networks, such as YouTube, MySpace, Flickr, CCMixter,
		 Jamendo, New York Public Library, any URL on the web, etc.
	- Edit your videos online with a nice advanced editor provided also by the Kaltura API.
	- Edit the details of your videos: title, description, tags.
	- Define the level of privacy to share your videos: private, public, registered users or your friends.
	- Comment, rate you videos by any user allowed by the level of privacy.
	- View the code details of your generated video to allow put it on other places.
	- Make a collaborative videos in groups. In a group environment you can start a video, put the 
	  level of privacy to allow editing by others users of the group and le the other change you
	  initial video.
	- Integrated tinyMCE features: you can choose in "tools administration" if you want to allow
	  this. If it is allowed (by default) then the users can put videos in any textarea form, 
	  containing tinyMCE or not (this show a button witch open the video gallery or editor).
	- Widget: This plugin has also a widget to allow you show the last video in the dashboard.
	  The video shown to the visitor depends of its level of privacy, EX: if him is your friend, then
	  can view your last video make for friends, public or registered users.
	- RSS functionality: in the Elgg way, you can subscribe to feeds in any page related with the plugin.

INSTALL:

	0. Please be sure that you have Elgg installed in a site with CURL libraries for PHP 
	1. Copy the directory kaltura_video/ and all his files to the plugins folder in elgg_path/mod/
	2. Activate the plugin in tools administration
	3. Configure the plugin by clicking in "more info" in tools administration

UPGRADING FROM OLDER VERSIONS:

	1. Completly remove the old kaltura_video/ directory in the plugin's folder and put the 
	   new one instead
	2. Run the "Recreate all video objects" as administrador if your older version is lower than 0.9.1
	3. That's all, enjoy it!
   
IMPORTANT NOTE:

	You need be a partner of kaltura.com site, register in this page:
	http://www.kaltura.com/index.php/cms/signup

	When you have your login data login as a partner in this page
	http://www.kaltura.com/index.php/cms/login
	Then press the button "Account" -> "General Info"
	Copy the needed data to the plugin preferences under tools administration in elgg

DEPENDENCIES:

	CURL libraries for PHP needed!!!
	None other plugins required synce version 0.4, but you can use
	tinymce, tinymce_adv or tinymcebrowser if you want (in this case
	kaltura_video will try to add a button in tinymce editor)

BUGS:

	You can send me emails if you found bugs in this plugin, I'll try to solve them.
	Feel free to contact with me if you want to improve o personalize the plugin or need
	some comercial suport.

COLLABORATION:

	You can collaborate by solving bugs and send me by email if you want/can.
	You can also collaborate by make translations of the plugin and send me by email.
	To make a translation go to the folder languages and create a new file with your
	language (EX: es.php for Spanish) then put inside on the top of the file your name
	and mail (thats to contact to you if are changes in the future, so you can translate
	also) and send it to me.
   
DONATIONS:

	Note that I'm not affiliated with Elgg (Curverider) or Kaltura Corp. 
	So if you like this plugin consider to make a donation here:
	
	https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=3518572
	
THANKS TO:

	Many, many thanks to Jessica Yazbek for his valuable work on debuggin and improving this plugin!

	Thanks also for this language packs contributors:
		- Mathieu Reynouard: French language
		- Truong Dang: Duch language
		- Gleb Lagutin: German language
	

@author Ivan Vergés - Ballo Microstudi SL <ivan@microstudi.net>

@license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
@copyright Ballo Microstudi SL 2009
@link http://microstudi.net/elgg/
