<?php

require_once("kaltura/editor/includes.php");


$privacity = get_input('privacity');
$update_plays = get_input('update_plays');
$delete_kshow_id = get_input('delete_kshow_id');
$video_id = get_input('id');
$collaborative = get_input('collaborative');

if($update_plays) {
	//update plays status
	$kaltura_user = new kalturaUser();
	$kaltura_user->puser_id = $uid;
	$kaltura_user->puser_name = $username;
	$kaltura_service = kalturaService::getInstance( $kaltura_user,false);
	$params = array(
		"detailed" => '1',
		"kshow_id" => $update_plays
	);
	//open the kaltura list without admin privileges
	$res = $kaltura_service->getkshow ( $kaltura_user , $params );

	global $is_admin;
	$is_admin = true;

	//check the video and delete the elgg object if not exists in kaltura
	$ob = kaltura_get_entity($update_plays);
	$metadata = kaltura_get_metadata($ob);
	if ( $res['error'][0]['code'] == 'INVALID_KSHOW_ID' && $metadata->kaltura_video_id) {
		//delete!
		$ob->delete();
		echo elgg_echo('kalturavideo:error:objectnotavailable');
	}
	elseif ( $res['result']['kshow'] && $ob) {
		$current_plays = $res['result']['kshow']['plays'];
		if(empty($current_plays)) $current_plays = $res['result']['kshow']['showEntry']['plays'];
		//print_r($metadata);
		//print_r($res['result']['kshow']);
		$update = array("id"=>$update_plays,);
		
		$update['plays'] = $current_plays;
		//check other metadata not generated previously
		$update['lengthInMsecs'] = $res['result']['kshow']['lengthInMsecs'];
		$update['thumbnailUrl'] = $res['result']['kshow']['thumbnailUrl'];
		$update['showEntry'] = $res['result']['kshow']['showEntry'];
		$combined_tags = array();
		foreach ($res['result']['kshow']['entrys'] as $entry)
			if ($entry['tags'] != strtolower(get_plugin_setting('videotitle', 'kaltura_video')))
				$combined_tags[] = trim($entry['tags']);
		$combined_tags = array_unique($combined_tags);
		$update['tags'] = implode(',', $combined_tags);
		kaltura_update_object($update,null,null);
		
		//update manually the play number
		$metadata = kaltura_get_metadata($ob);
		if($metadata->kaltura_video_plays != $current_plays) {
			$value = add_metastring($current_plays);
			$name = get_metastring_id('kaltura_video_plays');

			if($value && $name) {
				$result = update_data("UPDATE {$CONFIG->dbprefix}metadata set value_id='$value' where entity_guid=".$ob->getGUID()." and name_id='$name'");
			}
		}
		
		echo $current_plays;
	}
	//back to the initial status of admin
	if(!isadminloggedin()) $is_admin = false;

	exit;
}

gatekeeper();

if(!empty($delete_kshow_id)) {
	//this case is when the elgg doesn't exists yet and the recent created kaltura video is cancelled
	$ob = kaltura_get_entity($delete_kshow_id);
	$metadata = kaltura_get_metadata($ob);
	$error = '';
	//check the video
	$kaltura_user = new kalturaUser();
	$kaltura_user->puser_id=$uid;
	$kaltura_user->puser_name=$username;
	$kaltura_service = kalturaService::getInstance( $kaltura_user,false);
	$params = array(
		"kshow_id" => $delete_kshow_id
	);
	//open the kaltura list without admin privileges
	$res = $kaltura_service->getkshow ( $kaltura_user , $params );
	if( $res['error'][0]['code'] == 'INVALID_KSHOW_ID') {
		//we can delete the elgg object
		if($ob) $ob->delete();
		exit;
	}
	elseif ( $res['error'][0]['code'] ) {
		$error = "Error Code: ".$res['error'][0]['code']."\n";
		$error .= "Error Code: ".$res['error'][0]['desc'];
	}
	elseif(!($metadata->kaltura_video_editable)) {
		 //check if belongs to this user (or is admin)
		$error = 'Forbidden!';
	}

	if(empty($error) && $ob) {
		$secret = $admin_secret;
		$kaltura_user = new kalturaUser();
		$kaltura_user->puser_id=$uid;
		$kaltura_user->puser_name=$username;
		$kaltura_service = kalturaService::getInstance( $kaltura_user,true);
		$params = array(
			"kshow_id" => $delete_kshow_id
		);
		//open the kaltura list with admin privileges
		$res = $kaltura_service->deletekshow ( $kaltura_user , $params );
		if ( $res['error'][0]['code'] ) {
			$error = "Error Code: ".$res['error'][0]['code']."\n";
			$error .= "Error Code: ".$res['error'][0]['desc'];
			echo $error;	
		}
		else {
			//we can delete the elgg object
			if($ob) $ob->delete();
			echo "deleted kshow_id: $delete_kshow_id";
		}
	}
	else echo $error;
	//if fails, no matter, the video can be delete from index admin
	
	exit;
}

//change privacity status
$ob = kaltura_get_entity($video_id);
$metadata = kaltura_get_metadata($ob);

if($metadata->kaltura_video_editable && $metadata->kaltura_video_id==$video_id && in_array($collaborative,array('yes','no'))) {
	$entry = array('id' => $video_id);
	//Privacity Status
	$ob->kaltura_video_collaborative = ($collaborative=='yes');
	if($ob->save())	system_message(str_replace("%1%",$video_id,elgg_echo("kalturavideo:text:collaborativechanged")));
	else register_error(str_replace("%1%",$video_id,elgg_echo("kalturavideo:text:collaborativenotchanged")));
	exit;
}

//only this status allowed
if(!in_array($privacity,array('me','friends','thisgroup','loggedin','public'))) {
	register_error(str_replace("%1%",$video_id,elgg_echo("kalturavideo:text:statusnotchanged")));
	exit;
}

if($metadata->kaltura_video_editable && $metadata->kaltura_video_id==$video_id) {
	//changes not allowed if not owner (or administrator)
	$entry = array('id' => $video_id);
	//Privacity Status
	$ops = kaltura_update_object($entry,null,null,$privacity);
	
	system_message(str_replace("%2%",$video_id,str_replace("%1%",elgg_echo("kalturavideo:private:".$privacity),elgg_echo("kalturavideo:text:statuschanged"))));
	exit;
	
}
else {
	register_error(str_replace("%1%",$video_id,elgg_echo("kalturavideo:text:statusnotchanged")));
	exit;
}


?>
