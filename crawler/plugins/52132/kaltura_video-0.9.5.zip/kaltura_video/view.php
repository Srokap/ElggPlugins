<?php
require_once("kaltura/editor/includes.php");

global $is_admin;
$is_admin = true;
			
$guid = $page[1];

$ob = get_entity($guid);
if(!$ob) forward();
$metadata = kaltura_get_metadata($ob);

$standard_entity = elgg_view_entity($ob, true);
//get the number of comments
$num_comments = elgg_count_comments($ob);

// If we've been asked to display the full view
$comments =  elgg_view_comments($ob);

list($votes,$rating_image,$rating) = kaltura_get_rating($ob);
$can_rate = (isloggedin() && !kaltura_is_rated_by_user($ob->getGUID(),$_SESSION['user'],$votes));

//groups handle
$group = get_entity($ob->container_guid);
if($group instanceof ElggGroup) {
	set_page_owner($group->getGUID());
	add_submenu_item(elgg_echo('kalturavideo:label:groupvideos'), $CONFIG->wwwroot."pg/kaltura_video/groups/".$group->username);
}
else $group = false;

//back to the initial status of admin
if(!isadminloggedin()) $is_admin = false;

if(empty($metadata->kaltura_video_visible) && !isadminloggedin()) {
		echo elgg_view_title($title);
		echo elgg_echo("kalturavideo:text:notfound");
}
else {
	$widget = kaltura_create_generic_widget_html ( $metadata->kaltura_video_id , 'l' );
	$widgetm = kaltura_create_generic_widget_html ( $metadata->kaltura_video_id , 'm' );

	if($metadata->kaltura_video_widget_html) $widget = $metadata->kaltura_video_widget_html;
	if($metadata->kaltura_video_widget_m_html) $widgetm = $metadata->kaltura_video_widget_m_html;

	$title = elgg_echo("kalturavideo:label:adminvideos").': ';
	$title .= elgg_echo("kalturavideo:label:showvideo");

	if(elgg_get_viewtype() != 'default') {
		//put here the standard view call: rss, opendd, etc.
		echo $standard_entity;
		//add comments
		echo $comments;
		return true;
	}


?>
<div class="kalturaviewer">

<h1><a href="<?php echo $ob->getURL(); ?>"><?php echo $ob->title; ?></a></h1>

<div class="post_icon">
<?php
$uob = get_user($ob->owner_guid);

echo elgg_view("profile/icon",array('entity' => $uob, 'size' => 'tiny'));
?>
</div>
<p class="strapline">
<?php
	echo sprintf(elgg_echo("kalturavideo:strapline"),$metadata->kaltura_video_created);
?>

<?php echo elgg_echo('by'); ?> <a href="<?php echo $CONFIG->wwwroot.'pg/kaltura_video/user/'.$uob->username; ?>" title="<?php echo htmlspecialchars(elgg_echo("kalturavideo:user:showallvideos")); ?>"><?php echo $uob->name; ?></a> 
<?php echo elgg_echo("kalturavideo:label:length"); ?> <strong><?php echo $metadata->kaltura_video_length; ?></strong> 
<?php echo elgg_echo("kalturavideo:label:plays"); ?> <strong class="ajax_play" rel="<?php echo $metadata->kaltura_video_id; ?>"><?php echo intval($metadata->kaltura_video_plays); ?></strong>
<!-- display the comments link -->
<a href="<?php echo $ob->getURL(); ?>#comments"><?php echo sprintf(elgg_echo("comments")) . " (" . $num_comments . ")"; ?></a><br />
</p>
<!-- display tags -->
<p class="tags">
<?php
echo elgg_view('output/tags', array('tags' => $ob->tags));
?>
</p>
<div class="clear"></div>

<!-- descrition -->
<div class="kalturaplayer left bigwidget"><?php echo $widget; ?></div>
<div class="text">
<?php
echo autop($ob->description);				
?>
</div>
<div class="clear"></div>

<form id="form1" name="form1" method="post" action="<?php echo $CONFIG->wwwroot; ?>action/kaltura_video/rate">

<p class="kaltura_video_rating">

<img src="<?php echo $CONFIG->wwwroot."mod/kaltura_video/kaltura/images/ratings/$rating_image"; ?>" alt="<?php echo "$rating"; ?>" /> <?php echo ("($votes " . elgg_echo('kalturavideo:votes') . ")"); ?>

<a href="#" class="submit_button showdetails"><?php echo elgg_echo("kalturavideo:show:advoptions"); ?></a>

<?php

if($metadata->kaltura_video_cancollaborate && !$metadata->kaltura_video_editable) {

?>
&nbsp;
<strong><?php echo elgg_echo("kalturavideo:label:collaborative"); ?>:</strong>
<a href="#" rel="<?php echo $metadata->kaltura_video_id; ?>" class="submit_button edit" title="<?php echo htmlspecialchars(elgg_echo("kalturavideo:text:iscollaborative")); ?>"><?php echo elgg_echo("kalturavideo:label:edit"); ?></a>

<?php
}
?>
</p>

<?php

	if ($can_rate) {
?>


<div class="kaltura_video_rating">
<div class="left">
<label><?php echo elgg_echo("kalturavideo:yourrate"); ?></label>
</div>
<div class="left">
<label class="rate"><input type="radio" name="rating" class="input-radio" value="0.00" /> 0 </label>
<label class="rate"><input type="radio" name="rating" class="input-radio" value="1.00" /> 1 </label>
<label class="rate"><input type="radio" name="rating" class="input-radio" value="2.00" /> 2 </label>
<label class="rate"><input type="radio" name="rating" class="input-radio" value="3.00" /> 3 </label>
<label class="rate"><input type="radio" name="rating" class="input-radio" value="4.00" /> 4 </label>
<label class="rate"><input type="radio" name="rating" class="input-radio" value="5.00" /> 5 </label>
</div>
<div class="left">
<input type="hidden" name="kaltura_video_guid" value="<?php echo $ob->getGUID(); ?>" />
<input type="submit" class="submit_button" name="submit" value="<?php echo elgg_echo("kalturavideo:rate"); ?>" />
</div>
<div class="clear"></div>
</div>
<?php

}
?>

<div class="hide kaltura_video_details">
<p><strong><?php echo elgg_echo("kalturavideo:label:thumbnail");?></strong></p>
<p><a href="<?php echo $metadata->kaltura_video_thumbnail; ?>" onclick="window.open(this.href);return false;"><?php echo $metadata->kaltura_video_thumbnail; ?></a></p>
<p><strong><?php echo elgg_echo("kalturavideo:label:flv");?></strong></p>
<p><a href="<?php echo $metadata->kaltura_video_flv; ?>" onclick="window.open(this.href);return false;"><?php echo $metadata->kaltura_video_flv; ?></a></p>
<p><strong><?php echo elgg_echo("kalturavideo:label:sharel");?></strong></p>
<p><input type="text" class="input-text" value="<?php echo htmlspecialchars($widget); ?>" /></p>
<p><strong><?php echo elgg_echo("kalturavideo:label:sharem");?></strong></p>
<p><input type="text" class="input-text" value="<?php echo htmlspecialchars($widgetm); ?>" /></p>
</div>

</form>

<?php
if($metadata->kaltura_video_editable) {
?>

<!-- options -->
<p class="options">
<a href="#" rel="<?php echo $metadata->kaltura_video_id; ?>" class="submit_button edit"><?php echo elgg_echo("kalturavideo:label:edit"); ?></a>
<a href="#" rel="<?php echo $metadata->kaltura_video_id; ?>" class="submit_button metadata"><?php echo elgg_echo("kalturavideo:label:editdetails"); ?></a>
<a href="<?php echo $CONFIG->wwwroot; ?>action/kaltura_video/delete?delete_video=<?php echo $metadata->kaltura_video_id; ?>" rel="<?php echo $metadata->kaltura_video_id; ?>" class="submit_button delete"><?php echo elgg_echo("kalturavideo:label:delete"); ?></a>

<?php

echo elgg_echo("kalturavideo:label:privateoptions");
echo kaltura_view_select_privacity($metadata->kaltura_video_id,$metadata->kaltura_video_privacity,$group,$metadata->kaltura_video_collaborative);

?>

</p>
<?php
}
?>

</div>
<div id="comments">
<?php

echo $comments;
				
}
?>
</div>
