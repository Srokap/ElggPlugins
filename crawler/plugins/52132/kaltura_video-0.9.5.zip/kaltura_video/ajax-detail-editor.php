<?php

require_once("kaltura/editor/includes.php");
gatekeeper();

$id = $_REQUEST['id'];

global $SKIP_KALTURA_REWRITE;
$SKIP_KALTURA_REWRITE = true;


$ob = kaltura_get_entity($id);

	$title_label = elgg_echo('title');
	$title_textbox = elgg_view('input/text', array('internalname' => 'title', 'value' => $ob->title));
	$text_label = elgg_echo('description');
	$text_textarea = elgg_view('input/longtext', array('internalname' => 'description', 'value' => $ob->description));
	$hidden_input = elgg_view('input/hidden', array('internalname' => 'kaltura_video_id', 'value' => $id));
	$tag_label = elgg_echo('tags');
	$tag_input = elgg_view('input/tags', array('internalname' => 'tags', 'value' => $ob->tags));
	$cancel_input = elgg_view('input/submit', array('internalname' => 'cancel', 'value' => elgg_echo('cancel')));
	$submit_input = elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('save')));
	
	$form_body = "<p>
			<label>$title_label</label><br />
                        $title_textbox
		<p>
		<p>
			<label>$text_label</label><br />
                        $text_textarea
		</p>
		<p>
			<label>$tag_label</label><br />
                        $tag_input
		</p>
		<p>
			$hidden_input
			$submit_input
			$cancel_input
		</p>

		";

	// Get the form
	$body = '<h1><img style="height:40px;" src="' . $ob->kaltura_video_thumbnail . '" alt="" title="' . htmlspecialchars($ob->title) . '" /> '.elgg_echo('kalturavideo:label:editdetails').'</h1>';
	$body .=  elgg_view('input/form', array('action' => $CONFIG->wwwroot."action/kaltura_video/update", 'body' => $form_body));
	
	$scripts = "";

	// Set the content type
	header("Content-type: text/html; charset=UTF-8");
	echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>'.elgg_echo('kalturavideo:label:editdetails').'</title>
	<script type="text/javascript" src="'.$CONFIG->wwwroot.'vendors/jquery/jquery-1.2.6.pack.js"></script>
	<script type="text/javascript" src="'.$CONFIG->wwwroot.'vendors/jquery/jquery-ui-personalized-1.5.packed.js"></script>
';

echo elgg_view('metatags', 'kaltura/jscripts');

if(isset($_REQUEST['submited'])) {
	$body = "";
	$scripts = "
	var topWindow = Kaltura.getTopWindow();
	topWindow.closeCurrentEdit();
	";
}

echo '
	<link rel="stylesheet" href="'.$CONFIG->wwwroot.'_css/css.css" type="text/css" />
<style type="text/css">
/* <![CDATA[ */

body {
	background:#fff;	
}

/* ]]> */
</style>

<script type="text/javascript">
/* <![CDATA[ */
KALTURA_VIDEO_MODAL = true;
'.$scripts.'
/* ]]> */
</script>

</head>

<body>

';
	echo '<div class="kaltura_detail_editor">';
	
	echo $body;
	
	echo '</div>
	

</body>
';
?>
