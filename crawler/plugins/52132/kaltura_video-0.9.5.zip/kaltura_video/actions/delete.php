<?php
require_once($CONFIG->pluginspath."kaltura_video/kaltura/editor/includes.php");
gatekeeper();

$delete_video = get_input('delete_video');
$annotation_id = (int) get_input('annotation_id');

if($annotation_id) {
	global $is_admin;
	$is_admin = true;
	if ($comment = get_annotation($annotation_id)) {
		
		$entity = get_entity($comment->entity_guid);
		$metadata = kaltura_get_metadata($entity);
		
		if ($metadata->kaltura_video_editable) {
			
			
			$comment->delete();

			//back to the initial status of admin
			if(!isadminloggedin()) $is_admin = false;

			system_message(elgg_echo("generic_comment:deleted"));
			forward($entity->getURL());
		}
		
	} else {
		$url = "";
	}
	//back to the initial status of admin
	if(!isadminloggedin()) $is_admin = false;
	
	register_error(elgg_echo("generic_comment:notdeleted"));
	forward($entity->getURL());
}
elseif($delete_video) {
	$error = '';
	//check the video
	$kaltura_user = new kalturaUser();
	$kaltura_user->puser_id=$uid;
	$kaltura_user->puser_name=$username;
	$kaltura_service = kalturaService::getInstance( $kaltura_user,false);
	$params = array(
		"kshow_id" => $delete_video
	);
	//open the kaltura list without admin privileges
	$res = $kaltura_service->getkshow ( $kaltura_user , $params );

	if( $res['error'][0]['code'] == 'INVALID_KSHOW_ID') {
		//we can delete the elgg object
		$ob = kaltura_get_entity($delete_video);
		if($ob) $ob->delete();
		system_message(str_replace("%ID%",$delete_video,elgg_echo("kalturavideo:action:deleteok")));
	}
	elseif ( $res['error'][0]['code'] ) {
		$error = "Error Code: ".$res['error'][0]['code']."\n";
		$error .= "Error Code: ".$res['error'][0]['desc'];
	}
	$ob = kaltura_get_entity($delete_video);
	$metadata = kaltura_get_metadata($ob);
	//check if belongs to this user (or is admin)
	if(!($metadata->kaltura_video_editable)) {
		$error = 'Forbidden!';
	}
	if(!$res) $error = 'Kaltura Connection Failed';

	if(empty($error)) {
		$secret = $admin_secret;
		$kaltura_user = new kalturaUser();
		$kaltura_user->puser_id=$uid;
		$kaltura_user->puser_name=$username;
		$kaltura_service = kalturaService::getInstance( $kaltura_user,true);
		$params = array(
			"kshow_id" => $delete_video
		);
		
		//delete the video
		$res = $kaltura_service->deletekshow ( $kaltura_user , $params );
		
		if ( $res['error'][0]['code'] ) {
			$error = "Error Code: ".$res['error'][0]['code']."\n";
			$error .= "Error Code: ".$res['error'][0]['desc'];
		}

		if(empty($error) && $res) {
			//now delete the object!
			$ob = kaltura_get_entity($delete_video);
			if($ob) $ob->delete();
			system_message(str_replace("%ID%",$delete_video,elgg_echo("kalturavideo:action:deleteok")));
		}
	}
	if($error) {
		register_error(str_replace("%ID%",$delete_video,elgg_echo("kalturavideo:action:deleteko"))."\n$error");
	}
}

$url = $_SERVER['HTTP_REFERER'];
if(strpos($url,'/kaltura_video/') === false) $url = $CONFIG->url.'pg/kaltura_video/';
if(!$error && strpos($url,'/kaltura_video/show/')!==false) $url = $CONFIG->url.'pg/kaltura_video/';
forward($url);

?>
