<?php

	/**
	 * Elgg add comment action
	 * 
	 * @package Elgg
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider <curverider.co.uk>
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.org/
	 */

	// Make sure we're logged in; forward to the front page if not
	
		gatekeeper();
		action_gatekeeper();
		
	// Get input
		$entity_guid = (int) get_input('entity_guid');
		$comment_text = get_input('generic_comment');
	

	
	global $is_admin;
	$is_admin = true;
	
	$can_comment = false;
	// Let's see if we can get an entity with the specified GUID	
	if ($entity = get_entity($entity_guid)) {

		if($entity->subtype == get_subtype_id('object','kaltura_video')) {
			require_once($CONFIG->pluginspath."kaltura_video/kaltura/editor/includes.php");
			$metadata = kaltura_get_metadata($entity);
			if($metadata->kaltura_video_visible) $can_comment = true;
		}
		else {
			//back to the initial status of admin
			if(!isadminloggedin()) $is_admin = false;
			if($entity = get_entity($entity_guid)) $can_comment = true;
		}
	}
	
	if($can_comment) {
		
        // If posting the comment was successful, say so
			if ($entity->annotate('generic_comment',$comment_text,$entity->access_id, $_SESSION['guid'])) {
				
				if ($entity->owner_guid != $_SESSION['user']->getGUID())
				notify_user($entity->owner_guid, $_SESSION['user']->getGUID(), elgg_echo('generic_comment:email:subject'), 
					sprintf(
									elgg_echo('generic_comment:email:body'),
									$entity->title,
									$_SESSION['user']->name,
									$comment_text,
									$entity->getURL(),
									$_SESSION['user']->name,
									$_SESSION['user']->getURL()
								)
					); 
					
					system_message(elgg_echo("generic_comment:posted"));
					
				} else {
					register_error(elgg_echo("generic_comment:failure"));
				}
				
	} else {
		
		register_error(elgg_echo("generic_comment:notfound"));
			
	}
		
	//back to the initial status of admin
	if(!isadminloggedin()) $is_admin = false;

	// Forward to the 
	forward($entity->getURL());

?>
