<?php
require_once($CONFIG->pluginspath."kaltura_video/kaltura/editor/includes.php");
gatekeeper();

$video_id = get_input('kaltura_video_id');
$title = get_input('title');
$desc = get_input('description');
$tags = get_input('tags');


if($video_id) {
	$error = '';
	//check the video
	$kaltura_user = new kalturaUser();
	$kaltura_user->puser_id=$uid;
	$kaltura_user->puser_name=$username;
	$kaltura_service = kalturaService::getInstance( $kaltura_user,false);
	$params = array(
		"kshow_id" => $video_id
	);
	//open the kaltura list without admin privileges
	$res = $kaltura_service->getkshow ( $kaltura_user , $params );
	if ( $res['error'][0]['code'] ) {
		$error = "Error Code: ".$res['error'][0]['code']."\n";
		$error .= "Error Code: ".$res['error'][0]['desc'];
	}
	$ob = kaltura_get_entity($video_id);
	$metadata = kaltura_get_metadata($ob);
	//check if belongs to this user (or is admin)
	if(!($metadata->kaltura_video_editable)) {
		$error = 'Forbidden!';
	}
	if(isadminloggedin()) { //this could change for groups
		$kaltura_user->puser_id = $res['result']['kshow']['puserId'];
	}

	if(empty($error)) {
		// Convert string of tags into a preformatted array
		$tagarray = string_to_tag_array($tags);
		
		$params = array(
			"kshow_id" => $video_id,
			"kshow_name" => kaltura_clean_chars(strip_tags($title)),
			"kshow_description" => kaltura_clean_chars(strip_tags($desc))
		);
		if (is_array($tagarray)) {
			$params["kshow_tags"] = kaltura_clean_chars(implode(", ",$tagarray));
		}
		//open the kaltura list with admin privileges
		$res = $kaltura_service->updatekshow ( $kaltura_user , $params );
		if ( $res['error'][0]['code'] ) {
			$error = "Error Code: ".$res['error'][0]['code']."\n";
			$error .= "Error Code: ".$res['error'][0]['desc'];
		}
		if(empty($error)) {
			//now update the object!
			$entry = array('id'=>$video_id,'name'=>$title,'description'=>$desc);
			if (is_array($tagarray)) {
				$entry['tags'] = implode(", ",$tagarray);
			}

			if(!($ob = kaltura_update_object($entry,null,null,null,null,null,true))) $error = "Error update Elgg object";
			
		}
	}
	if($error) {
		register_error(str_replace("%ID%",$video_id,elgg_echo("kalturavideo:action:updatedko"))."\n$error");
	}
	else system_message(str_replace("%ID%",$video_id,elgg_echo("kalturavideo:action:updatedok")));
}
else register_error("Fatal error, empty video id.");

$url = $_SERVER['HTTP_REFERER'];
if(strpos($url,'/kaltura_video/ajax-detail-editor.php') === false) $url = $CONFIG->url.'mod/kaltura_video/ajax-detail-editor.php';
else $url = $CONFIG->url.'mod/kaltura_video/ajax-detail-editor.php?submited';

forward($url);

?>
