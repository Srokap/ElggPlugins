<?php

	/**
	 * Elgg default object view
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.org/
	 */

	//for the RSS
	$uob = get_user($vars['entity']->owner_guid);
	
	$metadata = kaltura_get_metadata($vars['entity']);
	
	$description = '<p>'.elgg_echo("kalturavideo:label:length").' <b>'.$metadata->kaltura_video_length."</b>\n";
	$description .= elgg_echo("kalturavideo:label:plays").' <b>'.intval($metadata->kaltura_video_plays)."</b>\n";
	$description .= elgg_echo("kalturavideo:label:author").' <b>'.$uob->name.'</b></p>';
	$description .= $vars['entity']->description;
	
	$title = $vars['entity']->title;
	if (empty($title)) {
		$title = substr($description,0,32);
		if (strlen($description) > 32)
			$title .= " ...";
	}

?>

	<item>
	  <guid isPermaLink='true'><?php echo $vars['entity']->getURL(); ?></guid>
	  <pubDate><?php echo date("r",$vars['entity']->time_created) ?></pubDate>
	  <link><?php echo $vars['entity']->getURL(); ?></link>
	  <title><![CDATA[<?php echo $title; ?>]]></title>
	  <description><![CDATA[<?php echo (autop($description)); ?>]]></description>
	</item>
