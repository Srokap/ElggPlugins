<?php
require_once($CONFIG->pluginspath."kaltura_video/kaltura/editor/includes.php");

$owner = $vars['entity']->getOwnerEntity();

$metadata = kaltura_get_metadata($vars['entity']);
if(@empty($metadata->kaltura_video_id)) {
	$vars['entity']->delete();
	return false;
}

list($votes,$rating_image,$rating) = kaltura_get_rating($vars['entity']);

$rating = round($rating);

//get the number of comments
$num_comments = elgg_count_comments($vars['entity']);

//print_r($vars['entity']);
if(get_context()!='search') {
	//this view is for My videos:

?>

<div class="kalturavideoitem" id="kaltura_video_<?php echo $metadata->kaltura_video_id; ?>">

<div class="left">
<p><a href="<?php echo $vars['entity']->getURL(); ?>" rel="<?php echo $metadata->kaltura_video_id; ?>" class="play"><img src="<?php echo $metadata->kaltura_video_thumbnail; ?>" alt="<?php echo htmlspecialchars($vars['entity']->title); ?>" title="<?php echo htmlspecialchars($vars['entity']->title); ?>" /></a></p>
</div>
<div class="left">

<h3><a href="<?php echo $vars['entity']->getURL(); ?>"><?php echo $vars['entity']->title; ?></a></h3>


<p class="small"><?php echo elgg_echo("kalturavideo:label:created"); echo ' <b class="kaltura_video_created">'.$metadata->kaltura_video_created.'</b>'; ?>

<a href="<?php echo $vars['entity']->getURL(); ?>#comments"><?php echo sprintf(elgg_echo("comments")) . " (" . $num_comments . ")"; ?></a>
</p>


<p class="small">
<?php echo elgg_echo("kalturavideo:label:length"); echo ' <strong class="kaltura_video_length">'.$metadata->kaltura_video_length.'</strong>'; ?>

<?php echo elgg_echo("kalturavideo:label:plays"); echo ' <strong class="ajax_play kaltura_video_plays" rel="'.$metadata->kaltura_video_id.'">'.intval($metadata->kaltura_video_plays).'</strong>'; ?>
</p>

<p class="small kaltura_video_rating">
<img src="<?php echo $CONFIG->wwwroot."mod/kaltura_video/kaltura/images/ratings/$rating_image"; ?>" alt="<?php echo "$rating"; ?>" /> <?php echo ("($votes " . elgg_echo('kalturavideo:votes') . ")"); ?>
</p>

<p class="options">
<!-- <a href="<?php echo $vars['entity']->getURL(); ?>" class="submit_button"><?php echo elgg_echo("kalturavideo:label:view"); ?></a> -->

<?php
if($metadata->kaltura_video_editable) {
?>
<a href="#" rel="<?php echo $metadata->kaltura_video_id; ?>" class="submit_button edit"><?php echo elgg_echo("kalturavideo:label:edit"); ?></a>
<a href="#" rel="<?php echo $metadata->kaltura_video_id; ?>" class="submit_button metadata"><?php echo elgg_echo("kalturavideo:label:editdetails"); ?></a>
<a href="<?php echo $vars['url']; ?>action/kaltura_video/delete?delete_video=<?php echo $metadata->kaltura_video_id; ?>" rel="<?php echo $metadata->kaltura_video_id; ?>" class="submit_button delete"><?php echo elgg_echo("kalturavideo:label:delete"); ?></a>

<?php

echo elgg_echo("kalturavideo:label:privateoptions");
echo kaltura_view_select_privacity($metadata->kaltura_video_id,$metadata->kaltura_video_privacity);

}
?>
</p>
</div>

<div class="clear"></div>
</div>

<?php
}
else {
	
	$icon = '<a href="'.$vars['entity']->getURL().'">';
	$icon .= '<img src="' . $metadata->kaltura_video_thumbnail . '" alt="' . htmlspecialchars($vars['entity']->title) . '" title="' . htmlspecialchars($vars['entity']->title) . '" />';
	$icon .= '</a>';
	$info = "<p class=\"shares_gallery_title\">". elgg_echo("kalturavideo:river:shared") .": <a href=\"";
	$info .= $vars['entity']->getURL();
	$info .= "\">{$vars['entity']->title}</a> ";
	$info .= "</p>";
	//when listing user videos is ok:
	$info .= "<p class=\"owner_timestamp\">";
	$info .= $metadata->kaltura_video_created." ";
	$info .= elgg_echo('by')." <a href=\"{$vars['url']}pg/kaltura_video/user/{$owner->username}/\" title=\"".htmlspecialchars(elgg_echo("kalturavideo:user:showallvideos"))."\">{$owner->name}</a> ";
	
	$info .= elgg_echo("kalturavideo:label:length"). ' <strong>'.$metadata->kaltura_video_length.'</strong> '; 
	$info .= elgg_echo("kalturavideo:label:plays"). ' <strong>'.intval($metadata->kaltura_video_plays).'</strong>';

	$info .= " ".elgg_echo("kalturavideo:rating").": <strong>".$rating."</strong>";
	
	if ($num_comments)
		$info .= ", <a href=\"{$vars['entity']->getURL()}\">".sprintf(elgg_echo("comments")). " (" . $num_comments . ")</a>";
		


	$info .= "</p>";

	if (get_input('search_viewtype') == "gallery") {
		//display 
		$info = '<p class="shares_gallery_title">'.$icon.'</p>';
		$info .= "<p class=\"shares_gallery_title\"><a href=\"";
		$info .= $vars['entity']->getURL();
		$info .= "\">{$vars['entity']->title}</a> ";
		$info .= "</p>";
		$info .= "<p class=\"shares_gallery_user\">";
		$info .= elgg_echo("kalturavideo:label:length"). ' <strong>'.$metadata->kaltura_video_length.'</strong> '; 
		$info .= elgg_echo("kalturavideo:label:plays"). ' <strong>'.intval($metadata->kaltura_video_plays).'</strong>';
		$info .= "</p>";
		//when listing user videos is ok:
		$info .= "<p class=\"shares_gallery_user\"><a href=\"{$vars['url']}pg/kaltura_video/user/{$owner->username}/\">{$owner->name}</a> ";
		
		$info .= '<span class="shared_timestamp">'.$metadata->kaltura_video_created.'</span>';
		
		$info .= " ".elgg_echo("kalturavideo:rating").": <strong>".$rating."</strong>";

		if ($num_comments)
			$info .= ", <a href=\"{$vars['entity']->getURL()}\">".sprintf(elgg_echo("comments")). " (" . $num_comments . ")</a>";
	
		
		echo "<div class=\"share_gallery_view\">";
		echo "<div class=\"share_gallery_info\">" . $info . "</div>";
		echo "</div>";

	}
	else {
		//this view is for context search listing
		echo elgg_view_listing($icon, $info);
	}
}
?>
