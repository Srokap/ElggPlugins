<script type="text/javascript">
/* <![CDATA[ */

function KalturaVideoStartModal() {
	KalturaTextArea = $('textarea[name="<?php echo $vars['internalname']; ?>"]');
	KalturaModal.openModal("TB_window", "<?php echo $vars['url']; ?>mod/kaltura_video/kaltura/editor/init.php", { width: 240, height: 60 } );
	return false;
}
/* ]]> */
</script>

<a href="Javascript://" onclick="return KalturaVideoStartModal();"><img src="<?php echo $vars['url']; ?>mod/kaltura_video/kaltura/images/interactive_video_button.gif" alt="<?php echo elgg_echo('kalturavideo:label:addvideo'); ?>" title="<?php echo elgg_echo('kalturavideo:label:addvideo'); ?>" /></a>
