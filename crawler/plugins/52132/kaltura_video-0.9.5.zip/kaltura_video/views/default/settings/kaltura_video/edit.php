<?php
/**
* Kaltura video client
* @package ElggKalturaVideo
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author Ivan Vergés - Ballo Microstudi SL <ivan@microstudi.net>
* @copyright Ballo Microstudi SL 2009
* @link http://microstudi.net/elgg/
**/

global $KALTURA_DEFAULT_VIDEOTITLE;

?>

<p>
	<h4><?php echo elgg_echo('kalturavideo:label:partner_id'); ?>: </h4>
	<?php
		echo elgg_view('input/text', array('internalname' => 'params[partner_id]', 'value' => $vars['entity']->partner_id ));
	?>
</p>
<p>
	<h4><?php echo elgg_echo('kalturavideo:label:subp_id'); ?>: </h4>
	<?php
		echo elgg_view('input/text', array('internalname' => 'params[subp_id]', 'value' => $vars['entity']->subp_id ));
	?>
</p>
<p>
	<h4><?php echo elgg_echo('kalturavideo:label:admin_secret'); ?>: </h4>
	<?php
		echo elgg_view('input/text', array('internalname' => 'params[admin_secret]', 'value' => $vars['entity']->admin_secret ));
	?>
</p>
<p>
	<h4><?php echo elgg_echo('kalturavideo:label:secret'); ?>: </h4>
	<?php
		echo elgg_view('input/text', array('internalname' => 'params[secret]', 'value' => $vars['entity']->secret ));
	?>
</p>
<p>
<?php echo elgg_echo('kalturavideo:text:loginkaltura'); ?> 
<a href="http://www.kaltura.com/index.php/cms/login">http://www.kaltura.com/index.php/cms/login</a> 
<?php echo elgg_echo('kalturavideo:text:buttoninfo'); ?> 

</p>
<p>
<?php echo elgg_echo('kalturavideo:text:signupkaltura'); ?> 
<a href="http://www.kaltura.com/index.php/cms/signup">http://www.kaltura.com/index.php/cms/signup</a>
</p>
<p>
	<h4><?php
	$KALTURA_DEFAULT_VIDEOTITLE = ($vars['entity']->videotitle ? $vars['entity']->videotitle : elgg_echo('kalturavideo:title:video'));
 	echo elgg_echo('kalturavideo:label:videotitle'); ?>: </h4>
	<?php
		echo elgg_view('input/text', array('internalname' => 'params[videotitle]', 'value' => $KALTURA_DEFAULT_VIDEOTITLE ));
	?>
</p>
<p>
	<h4><?php
	$KALTURA_DEFAULT_USERPREFIX = ($vars['entity']->uid_prefix ? $vars['entity']->uid_prefix : 'Elgg_');
 	echo elgg_echo('kalturavideo:label:uid_prefix'); ?>: </h4>
	<?php
		echo elgg_view('input/text', array('internalname' => 'params[uid_prefix]', 'value' => $KALTURA_DEFAULT_USERPREFIX));
	?>
</p>
<p>
	<h4><?php echo elgg_echo('kalturavideo:label:integratetinymce'); ?>: </h4>
	<?php
		$use_tinymce = ($vars['entity']->usetinymce?$vars['entity']->usetinymce:'yes');
		echo elgg_view('input/radio', array('internalname' => 'params[usetinymce]', 'value' => $use_tinymce, 'options'=>array(elgg_echo('option:yes')=>'yes',elgg_echo('option:no')=>'no') ));
	?>
</p>
