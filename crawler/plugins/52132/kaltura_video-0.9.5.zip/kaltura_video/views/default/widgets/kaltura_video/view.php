<?php

/**
* Kaltura video client
* @package ElggKalturaVideo
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author Ivan Vergés - Ballo Microstudi SL <ivan@microstudi.net>
* @copyright Ballo Microstudi SL 2009
* @link http://microstudi.net/elgg/
**/

require_once($CONFIG->pluginspath."kaltura_video/kaltura/editor/includes.php");

global $is_admin;

//show the latest video

$object_label = 'kaltura_video';
$limit = 1;
$offset = 0;


$arr = array('public','loggedin');
$owner_id = $vars['entity']->owner_guid;
if(user_is_friend($owner_id,$_SESSION['user']->guid)) {
	$arr[] = 'friends';
}
$is_admin = true;


$result = kaltura_get_entities_from_metadata("kaltura_video_privacity",$arr,'object',$object_label,$owner_id,$limit,$offset,"time_created DESC");
$count = kaltura_get_entities_from_metadata("kaltura_video_privacity",$arr,'object',$object_label,$owner_id,null,null,"",0,true);
		
if(!$result) $body .= elgg_echo("kalturavideo:text:nouservideos");

if($result) {
	$ob = $result[0];
	
	if($metadata = kaltura_get_metadata($ob)) {
		$body = $metadata->kaltura_video_widget_m_html;
		$body .= '<p><a href="'.$CONFIG->wwwroot.'pg/kaltura_video/show/'.$ob->guid.'">'.elgg_echo('kalturavideo:label:details').'</a></p>';
	}
	else {
		$body = elgg_echo('kalturavideo:error:objectnotavailable');
	}
}
else {
	$body = $novideos;
}

if(!isadminloggedin()) $is_admin = false;
	
?>
<div style="text-align:center">
<?php
echo $body;
?>
</div>
