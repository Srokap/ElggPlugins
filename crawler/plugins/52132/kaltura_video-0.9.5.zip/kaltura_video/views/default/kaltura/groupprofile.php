<div id="kaltura_video_widget">
<h2><?php echo elgg_echo("kalturavideo:groupprofile"); ?></h2>
<?php
	
	$context = get_context();
	set_context("search");
    $objects = list_entities("object", "kaltura_video", page_owner(), 5, false);
	
	set_context($context);
	
	echo $objects;
	
?>
</div>
