<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/kaltura_video/kaltura/js/kaltura.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo $vars['url']; ?>mod/kaltura_video/kaltura/css/kaltura.css" />
<?php

if(get_context()=='kaltura_video') {
	echo '<link rel="stylesheet" type="text/css" href="'.$vars['url'].'mod/kaltura_video/kaltura/css/admin.css" />';
	$js = file_get_contents($CONFIG->path.'mod/kaltura_video/kaltura/js/admin.js');

	$js = preg_replace(array('/{SURETODELETE}/','/{URL}/','/{SHOWADV}/','/{HIDEADV}/','/{EDITTITLE}/','/{ERRORUPDATETITLE}/','/{SURETORECREATE}/'),array(str_replace("'","\'",elgg_echo("kalturavideo:prompt:delete")), $vars['url'].'mod/kaltura_video/',str_replace("'","\'",elgg_echo("kalturavideo:show:advoptions")),str_replace("'","\'",elgg_echo("kalturavideo:hide:advoptions")),str_replace("'","\'",elgg_echo("kalturavideo:label:edittitle")),str_replace("'","\'",elgg_echo("kalturavideo:error:edittitle")),str_replace("'","\'",elgg_echo("kalturavideo:text:recreateobjects"))),$js);

	echo '<script type="text/javascript">
/* <![CDATA[ */';
if (page_owner_entity() instanceof ElggGroup) {
        echo "\nCURRENT_GROUP = '" . page_owner_entity()->username . "';\n";
} else {
        echo "\nCURRENT_GROUP = '';\n";
}

echo $js.'
/* ]]> */
</script>
';
}
?>
