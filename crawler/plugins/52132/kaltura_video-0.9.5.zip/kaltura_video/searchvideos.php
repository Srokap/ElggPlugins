<?php
/**
* Kaltura video client
* @package ElggKalturaVideo
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author Ivan Vergés - Ballo Microstudi SL <ivan@microstudi.net>
* @copyright Ballo Microstudi SL 2009
* @link http://microstudi.net/elgg/
**/

require_once($CONFIG->pluginspath."kaltura_video/kaltura/editor/includes.php");

$limit = get_input('limit', 10);
$offset = get_input('offset');

$object_label = "kaltura_video";

if($page[0] == 'show') {
	//find the concrete video to show
	$type = 'show';
	ob_start();
	include('view.php');
	$body = ob_get_clean();
	
	
}
else {
	//turn the user administrator temporally (this is for view private objects)
	global $is_admin;
	
	$title = elgg_echo("kalturavideo:label:adminvideos").": ";
	
	if($page[0] == 'friends') {
		$title .= elgg_echo("kalturavideo:label:friendsvideos");
		$body = elgg_view_title($title);
	
		$owner_id = kaltura_get_owner_id_from_type('friends');
		
		$is_admin = true;

		//for show all videos with status public or friends from my friends
		$arr = array('public','friends','loggedin');
		$result = kaltura_get_entities_from_metadata("kaltura_video_privacity",$arr,'object',$object_label,$owner_id,$limit,$offset,"owner_guid ASC,time_updated DESC");
		$count = kaltura_get_entities_from_metadata("kaltura_video_privacity",$arr,'object',$object_label,$owner_id,null,null,"",0,true);
		
		
		if(!$result) $body .= elgg_echo("kalturavideo:text:nofriendsvideos");
	}
	elseif($page[0] == 'user') {
		//List all videos (If I can see it) from a user
		$user = get_user_by_username($page[1]);
		$title .= sprintf(elgg_echo("kalturavideo:label:videosfrom"),$user->name);
		$body = elgg_view_title($title);
		
		$arr = array('public','loggedin');
		
		$owner_id = $user->guid;
		if(user_is_friend($owner_id,$_SESSION['user']->guid)) {
			$arr[] = 'friends';
		}
		$is_admin = true;
		
		
		$result = kaltura_get_entities_from_metadata("kaltura_video_privacity",$arr,'object',$object_label,$owner_id,$limit,$offset,"owner_guid ASC,time_updated DESC");
		$count = kaltura_get_entities_from_metadata("kaltura_video_privacity",$arr,'object',$object_label,$owner_id,null,null,"",0,true);
		
		if(!$result) $body .= elgg_echo("kalturavideo:text:nouservideos");
	}
	else {
		//List all public videos
		
		$title .= elgg_echo("kalturavideo:label:allvideos");
		$body = elgg_view_title($title);

		$arr = array('public','loggedin');

		$result = kaltura_get_entities_from_metadata("kaltura_video_privacity",$arr,'object',$object_label,0,$limit,$offset,"owner_guid ASC,time_updated DESC");
		$count = kaltura_get_entities_from_metadata("kaltura_video_privacity",$arr,'object',$object_label,0,null,null,"",0,true);
		
		if(!$result) $body .= elgg_echo("kalturavideo:text:nopublicvideos");

	}
	
	
	if($result) {
		$wrapped_entries = array();
		foreach($result as $ob) {
			
			$tmp = get_entity($ob->guid);

			$wrapped_entries[] = $tmp;
		}

		$context = get_context();
		set_context('search');
		$body .= elgg_view_entity_list($wrapped_entries, $count, $offset, $limit, false);
		set_context($context);
    }

	//back to the initial status of admin
	if(!isadminloggedin()) $is_admin = false;
}

if(elgg_get_viewtype() == 'default') {
	$body = '<div id="kaltura_container">'.$body.'</div>';
}

// Display main admin menu
page_draw($title,elgg_view_layout("two_column_left_sidebar", '', $body));

?>
