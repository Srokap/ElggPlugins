<?php
/**
* Kaltura video client
* @package ElggKalturaVideo
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author Ivan Vergés - Ballo Microstudi SL <ivan@microstudi.net>
* @copyright Ballo Microstudi SL 2009
* @link http://microstudi.net/elgg/
**/

function kaltura_video_init() {
	// Load system configuration
	global $CONFIG;

	global $KALTURA_DEFAULT_VIDEOTITLE;
	global $KALTURA_DEFAULT_USERPREFIX;
	global $KALTURA_USE_TINYMCE;

	$KALTURA_DEFAULT_VIDEOTITLE = elgg_echo('kalturavideo:title:video');
	$KALTURA_DEFAULT_USERPREFIX = 'Elgg_';
	$KALTURA_USE_TINYMCE = (get_plugin_setting('usetinymce', 'kaltura_video')=='yes');

	//Add the javascript el javascript
	extend_view('metatags', 'kaltura/jscripts');

	if($KALTURA_USE_TINYMCE) {
		$CONFIG->allowedtags['object'] = array('id'=>array(), 'type'=>array(), 'allowScriptAccess'=>array(), 'data'=>array(), 'width'=>array(), 'height'=>array(), 'classid'=>array(), 'codebase'=>array());
		$CONFIG->allowedtags['param'] = array( 'name'=>array(), 'value'=>array());
		$CONFIG->allowedtags['embed'] = array( 'src'=>array(), 'type'=>array(), 'wmode'=>array(), 'width'=>array(), 'height'=>array());

		set_view_location('input/longtext', $CONFIG->path . 'views/');
		if( is_plugin_enabled('tinymce') || is_plugin_enabled('tinymce_adv') || is_plugin_enabled('tinymcebrowser')) {
	        	set_view_location('input/longtext', $CONFIG->path . 'mod/kaltura_video/views/');
		}
		else {
			extend_view('input/longtext', 'input/longtext-simple');
		}
	}

	// Set up menu for logged in users
	if (isloggedin()) 
	{
		add_menu(elgg_echo('kalturavideo:label:adminvideos'), $CONFIG->wwwroot . "pg/kaltura_video/");
	}
	
	// Extend hover-over menu	
	extend_view('profile/menu/links','kaltura/menu');
	// Add to groups context
	extend_view('groups/right_column', 'kaltura/groupprofile');
	
	// Register a page handler, so we can have nice URLs
	register_page_handler('kaltura_video','kaltura_video_page_handler');
	register_action('kaltura_video/delete', false, $CONFIG->pluginspath . 'kaltura_video/actions/delete.php');
	register_action('kaltura_video/update', false, $CONFIG->pluginspath . 'kaltura_video/actions/update.php');
	register_action('kaltura_video/rate', false, $CONFIG->pluginspath . 'kaltura_video/actions/rate.php');
	//tot delete comments, we need a special handle
	register_action('comments/delete', false, $CONFIG->pluginspath . 'kaltura_video/actions/delete.php');
	register_action('comments/add', false, $CONFIG->pluginspath . 'kaltura_video/actions/add.php');

	// Register a url handler
	register_entity_url_handler('kaltura_video_url','object', 'kaltura_video');


	/// Add widget
    add_widget_type('kaltura_video',elgg_echo('kalturavideo:label:latest'),elgg_echo('kalturavideo:text:widgetdesc'));
	// Register entity type
	register_entity_type('object','kaltura_video');

}

function kaltura_video_url($entity) {
		global $CONFIG;
		return $CONFIG->url . "pg/kaltura_video/show/{$entity->guid}/";
}

/**
* Post init gumph.
*/
function kaltura_video_page_setup()
{
	global $CONFIG;
	
	$page_owner = page_owner_entity();
		
	// Group submenu option	
	if ($page_owner instanceof ElggGroup) {
		add_submenu_item(sprintf(elgg_echo("kalturavideo:label:groupvideos"),$page_owner->name), $CONFIG->wwwroot . "pg/kaltura_video/groups/" . $page_owner->username);
	}

	if (get_context()=='kaltura_video')
	{
		if(!($page_owner instanceof ElggGroup)) {
			if(isloggedin()) {
				add_submenu_item(elgg_echo('kalturavideo:label:myvideos'), $CONFIG->wwwroot."pg/kaltura_video/");
				add_submenu_item(elgg_echo('kalturavideo:label:friendsvideos'), $CONFIG->wwwroot."pg/kaltura_video/friends/");
			}
			add_submenu_item(elgg_echo('kalturavideo:label:allgroupvideos'), $CONFIG->wwwroot."pg/kaltura_video/groups/");
			add_submenu_item(elgg_echo('kalturavideo:label:allvideos'), $CONFIG->wwwroot."pg/kaltura_video/public/");
			
			if(isadminloggedin()) {
				add_submenu_item(elgg_echo('kalturavideo:label:recreateobjects'), "#kaltura_recreateobjects",'pagesactions');
			}
		}
		if(isloggedin()) add_submenu_item(elgg_echo('kalturavideo:label:newvideo'), "#kaltura_create",'pagesactions');
	}
}

/**
* feeds page handler; allows the use of fancy URLs
*
* @param array $page From the page_handler function
* @return true|false Depending on success
*/

function kaltura_video_page_handler($page) {
		global $CONFIG;

	if (isset($page[0])) {
		switch ($page[0]) {
			case 'public':
			case 'friends':
			case 'show':
			case 'user':
				include(dirname(__FILE__) . "/searchvideos.php");
				return true;
				break;
			case 'groups':
				include(dirname(__FILE__) . "/groups.php");
				return true;
				break;
			case 'recreateobjects':
				include(dirname(__FILE__) . "/recreateobjects.php");
				return true;
				break;
			default:
				include(dirname(__FILE__) . "/index.php");
				return true;
		}
	}
	else {
		// If the URL is just 'feeds/username', or just 'feeds/', load the standard feeds index
		include(dirname(__FILE__) . "/index.php");
		return true;
	}
	return false;
}


// Make sure the status initialisation function is called on initialisation
register_elgg_event_handler('init','system','kaltura_video_init',1000);
register_elgg_event_handler('pagesetup','system','kaltura_video_page_setup');

?>
