<?php
/**
* Kaltura video client
* @package ElggKalturaVideo
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author Ivan Vergés - Ballo Microstudi SL <ivan@microstudi.net>
* @copyright Ballo Microstudi SL 2009
* @link http://microstudi.net/elgg/
**/

require_once($CONFIG->pluginspath."kaltura_video/kaltura/editor/includes.php");
if(!isloggedin()) {
	$url = $CONFIG->url.'pg/kaltura_video/public/';
	forward($url);
	exit;
}

$title = elgg_echo("kalturavideo:label:adminvideos").": ".elgg_echo("kalturavideo:label:myvideos");
$body = elgg_view_title($title);

$body .= list_user_objects($_SESSION['user']->getGUID(),'kaltura_video',10,false);

if(elgg_get_viewtype() == 'default') {
	$body = '<p class="em">'.elgg_echo("kalturavideo:text:privatestatus").'</p>'.$body;
	$body = '<div id="kaltura_container">'.$body.'</div>';

}

//global $autofeed;
//$autofeed = false;
// Display main admin menu
page_draw($title,elgg_view_layout("two_column_left_sidebar", '', $body));

?>
