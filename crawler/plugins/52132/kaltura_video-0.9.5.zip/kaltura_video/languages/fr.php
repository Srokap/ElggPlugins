<?php
/**
* Kaltura video client
* @package ElggKalturaVideo
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author Ivan Vergés - Ballo Microstudi SL <ivan@microstudi.net>
* @copyright Ballo Microstudi SL 2009
* @link http://microstudi.net/elgg/
* 
* This Translation is made by: Mathieu Reynouard
*
**/


$translations = array(
	
	'item:object:kaltura_video' => 'Vid&eacute;os',
	'kalturavideo:label:partner_id' => 'Partenaire ID ',
	'kalturavideo:label:subp_id' => 'Sous partenaire ID ',
	'kalturavideo:label:admin_secret' => 'Secret de l&#146;administrateur ',
	'kalturavideo:label:secret' => 'Secret du service Web ',
	'kalturavideo:title:video' => 'Vid&eacute;o de '.$CONFIG->sitename,
	'kalturavideo:descprefix:video' => 'Une vid&eacute;o de kaltura par',
	'kalturavideo:text:loginkaltura' => 'Vous pouvez obtenir ces informations sur le site de kaltura :',
	'kalturavideo:text:buttoninfo' => '(Aller sur "Account" -> "General Info")',
	'kalturavideo:text:signupkaltura' => 'Vous devez &ecirc;tre partenaire pour vous identifiez, inscrivez-vous ici si n&eacute;c&eacute;ssaire :',
	'kalturavideo:label:videotitle' => 'Titre des vid&eacute;os cr&eacute;es',
	'kalturavideo:label:addvideo' => 'Ajouter des vidéos de kaltura',
	'kalturavideo:label:uid_prefix' => 'Prefixe cms des utilisteurs de Kaltura',
	'kalturavideo:label:integratetinymce' => 'Essayer de l&#146;nt&eacute;grer au plugin TinyMCE',
	
	'kalturavideo:error:misconfigured' => 'Mauvaise configuration du plugin ou erreur d&#146;authentification !',
	'kalturavideo:error:notconfigured' => 'Le plugin n&#146;est pas configur&eacute; !',
	'kalturavideo:error:missingks' => 'Vous avez probablement un probl&egrave;me dans la configuration du "secret de l&#146;administrateur" ou du "secret du service web".',
	'kalturavideo:error:partnerid' => 'Cette erreur apparait normalement si vous n&#146;&ecirc;tes pas un partenaire de kaltura. Lisez le README et configurez ce plugin !',
	'kalturavideo:error:readme' => 'Lisez le README et configurez ce plugin !',
	
	'kalturavideo:label:closewindow' => 'Fermer la fen&ecirc;tre',
	'kalturavideo:label:select_size' => 'S&eacute;lectionner la taille du lecteur',
	'kalturavideo:label:large' => 'Large',
	'kalturavideo:label:small' => 'Petite',
	'kalturavideo:label:insert' => 'Ins&eacute;rer une vid&eacute;o',
	'kalturavideo:label:edit' => 'Modifier la vid&eacute;o',
	'kalturavideo:label:edittitle' => 'Modifier le titre de la vid&eacute;o',
	'kalturavideo:label:miniinsert' => 'Ins&eacute;rer',
	'kalturavideo:label:miniedit' => 'Modifier',
	'kalturavideo:label:cancel' => 'Annuler',
	'kalturavideo:label:publish' => 'Publier',
	'kalturavideo:label:gallery' => 'Gallerie',
	'kalturavideo:label:next' => 'Suivant',
	'kalturavideo:label:prev' => 'Pr&eacute;c&eacute;dent',
	'kalturavideo:label:start' => 'Commencer',
	'kalturavideo:label:newvideo' => 'Cr&eacute;er une nouvelle vid&eacute;o',
	'kalturavideo:label:toolsadmin' => 'Administration -> Gestion des Outils (cliquer sur "more info")',
	'kalturavideo:label:gotoconfig' => 'S&#146;il vous plait, configurez proprement la vid&eacute;o Kaltura sous ',
	'kalturavideo:label:adminvideos' => 'Vid&eacute;os',
	'kalturavideo:label:myvideos' => 'Mes Vid&eacute;os',
	'kalturavideo:label:friendsvideos' => 'Vid&eacute;os de vos Amis',
	'kalturavideo:label:length' => 'Longueur :',
	'kalturavideo:label:plays' => 'Jou&eacute;e :',
	'kalturavideo:label:created' => 'Cr&eacute;e :',
	'kalturavideo:label:details' => 'D&eacute;tails',
	'kalturavideo:label:view' => 'Voir la Vid&eacute;o',
	'kalturavideo:label:editdetails' => 'Modifier les d&eacute;tails',
	'kalturavideo:label:delete' => 'Supprimer la Vid&eacute;o',
	'kalturavideo:prompt:delete' => 'Etes vous s&ucirc;r de vouloir supprimer d&eacute;finitivement cette vid&eacute;o ?',
	'kalturavideo:action:deleteok' => 'La Vid&eacute;o num&eacute;ro %ID% a &eacute;t&eacute; supprim&eacute;e.',
	'kalturavideo:action:deleteko' => 'La Vid&eacute;o num&eacute;ro %ID% ne peut pas &ecirc;tre supprim&eacute;e !',
	'kalturavideo:action:updatedok' => 'La Vid&eacute;o num&eacute;ro %ID% a &eacute;t&eacute; mise &agrave; jour.',
	'kalturavideo:action:updatedko' => 'La Vid&eacute;o num&eacute;ro %ID% ne peut pas &ecirc;tre mise &agrave; jour !',
	'kalturavideo:label:flv' => 'Url FLV de la vid&eacute;o :',
	'kalturavideo:label:thumbnail' => 'Adresse url:',
	'kalturavideo:label:sharel' => 'Code HTML partag&eacute; (grande applet):',
	'kalturavideo:label:sharem' => 'Code HTML partag&eacute; (petite applet):',
	'kalturavideo:label:privateoptions' => 'Acc&egrave;s :',
	'kalturavideo:private:public' => 'Publique',
	'kalturavideo:private:me' => 'Juste Moi',
	'kalturavideo:private:friends' => 'Amis seulement',
	'kalturavideo:private:loggedin' => 'Utilisateurs connect&eacute;s',
	'kalturavideo:text:privatestatus' => 'Les options priv&eacute;es sont seulement valides pour ce module (publique signifie que les autres utilisateurs enregistr&eacute;s peuvent voir la vid&eacute;o mais ne peuvent pas la modifier). Si vous partagez le code HTML de la vid&eacute;o, le statut priv&eacute; n&#146;a plus d&#146;effet (Ceci inclut toutes les vid&eacute;os post&eacute;es).',
	'kalturavideo:text:statuschanged' => 'Le statut de la vid&eacute;o %2% a &eacute;t&eacute; chang&eacute; en "%1%"',
	'kalturavideo:text:statusnotchanged' => 'Le statut de la vid&eacute;o %1% ne peut pas &ecirc;tre chang&eacute; !',
	'kalturavideo:label:allvideos' => 'Vid&eacute;os publiques',
	'kalturavideo:text:novideos' => 'D&eacute;sol&eacute;, vous n&#146;avez pas encore de vid&eacute;os !',
	'kalturavideo:text:nopublicvideos' => 'D&eacute;sol&eacute;, Il n&#146;y a pas encore de vid&eacute;os publiques !',
	'kalturavideo:label:author' => 'Auteur :',
	'kalturavideo:text:nofriendsvideos' => 'D&eacute;sol&eacute;, Il n&#146;y a pas encore de vid&eacute;os de vos amis !',
	'kalturavideo:text:nouservideos' => 'D&eacute;sol&eacute;, Il n&#146;y a pas encore de vid&eacute;os de cet utilisateur !',
	'kalturavideo:label:showvideo' => 'Montrer la vid&eacute;o',
	'kalturavideo:text:notfound' => 'Ressource non trouv&eacute;e!',
	'kalturavideo:show:advoptions' => 'Voir le Code HTML',
	'kalturavideo:hide:advoptions' => 'Cacher le Code HTML',
	'kalturavideo:label:latest' => 'Derni&egrave;re Vid&eacute;o',
	'kalturavideo:text:widgetdesc' => 'Ce widget vous permet de montrer automatiquement votre derni&egrave;re vid&eacute;o publique &agrave; partir du plugin Kaltura video.',
	'kalturavideo:error:edittitle' => 'Erreur ! Ce titre ne peut pas &ecirc;tre chang&eacute; !',
	'kalturavideo:label:latestfrom' => 'Voir la derni&egrave;re vid&eacute;o de:',
	'kalturavideo:label:anyvideos' => 'Toutes les vid&eacute;os accessibles',
	'kalturavideo:error:objectnotavailable' => 'Objet non disponible. Recharger la page.',
	'kalturavideo:label:recreateobjects' => 'Recr&eacute;er toutes les vid&eacute;os',
	'kalturavideo:text:recreateobjects' => 'Faites ceci si vous êtes en train de mettre à jour le plugin Kaltura à partir d\'une ancienne version ou si quelques vidéos sont supprimées hors de Elgg.\nToutes les vidéos de Elgg seront vérifiées et recrées, ceci peut prendre du temps.\n\nNOTE IMPORTANTE:\nTous les objets de Elgg seront supprimés et recrées. Les metadonnées, les commentaires et les votes ne seront pas perdus mais l\'identifiant GUID de la vidéo sera modifié.\nCela signifie que les anciennes url des vidéos seront modifiés aussi (Ça pourra affecter d\'autres plugins comme les signets).',
	'kalturavideo:edit:notallowed' => 'Vous ne pouvez pas modifier cette vid&eacute;o !',
	
	'kalturavideo:river:created' => '%s cr&eacute;e',
	'kalturavideo:river:annotate' => '%s a comment&eacute;',
	'kalturavideo:river:item' => 'une vid&eacute;o',
	'kalturavideo:river:updated' => '%s mise &agrave; jour',
	
	'kalturavideo:river:shared' => 'Vid&eacute;o',
	'kalturavideo:label:videosfrom' => 'Vid&eacute;os de %s',
	
	'kalturavideo:user:showallvideos' => 'Voir toutes les vid&eacute;os de cet utilisateur',
	
	'kalturavideo:strapline' => "%s",
	
	 /**
     * kaltura_video rating system
	 **/
	'kalturavideo:rating' => "Note ",
	'kalturavideo:yourrate' => "Votre vote :",
	'kalturavideo:rate' => "Votez !",
	'kalturavideo:votes' => "Vote",
	'kalturavideo:ratesucces' => "Votre vote a &eacute;t&eacute; sauvergard&eacute; avec succ&egrave;s.",
	'kalturavideo:rateempty' => "Choisir une valeur avant de Voter !",
	'kalturavideo:notrated' => "Vous avez d&eacute;j&agrave; vot&eacute; pour cette vid&eacute;o !",
	
	/**
	 * Groups
	 **/
	'kalturavideo:groupprofile' => 'Vid&eacute;os',
	'kalturavideo:label:groupvideos' => "Vid&eacute;os du groupe",
	'kalturavideo:label:allgroupvideos' => "Vid&eacute;os des groupes",
	'kalturavideo:text:nogroupvideos' => 'D&eacute;sol&eacute;, Il n&#146;y a pas encore de vid&eacute;os pour ce groupe !',
	'kalturavideo:private:thisgroup' => 'Ce groupe seulement',
	'kalturavideo:label:collaborative' => 'Collaboration',
	'kalturavideo:text:collaborative' => 'Ceci permet aux autres membres du groupe de modifier la vid&eacute;o !',
	'kalturavideo:text:collaborativechanged' => 'Le statut de collaboration de la vid&eacute;o %1% a &eacute;t&eacute; chang&eacute; !',
	'kalturavideo:text:collaborativenotchanged' => 'Le statut de collaboration de la vid&eacute;o %1% ne peut pas &ecirc;tre chang&eacute; !',
	'kalturavideo:text:iscollaborative' => 'Ceci est une vid&eacute;o collaborative, vous pouvez la modifier !',
	
	'kalturavideo:userprofile' => 'Vid&eacute;os',
);

add_translation("fr", $translations);

?>
