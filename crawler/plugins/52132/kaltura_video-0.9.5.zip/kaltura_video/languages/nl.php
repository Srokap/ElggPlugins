<?php
/**
* Kaltura video client
* @package ElggKalturaVideo
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author Ivan Vergés - Ballo Microstudi SL <ivan@microstudi.net>
* @copyright Ballo Microstudi SL 2009
* @link http://microstudi.net/elgg/
*
* This Translation is made by: Truong Dang
*
**/


$nederlands = array(
	
	'item:object:kaltura_video' => 'video\'s',
	'kalturavideo:label:partner_id' => 'Partner ID',
	'kalturavideo:label:subp_id' => 'Sub-Partner ID',
	'kalturavideo:label:admin_secret' => 'Administrator geheime sleutel',
	'kalturavideo:label:secret' => 'Web Service geheime sleutel',
	'kalturavideo:title:video' => $CONFIG->sitename.'\'s video',
	'kalturavideo:descprefix:video' => 'Een video van',
	'kalturavideo:text:loginkaltura' => 'De gegevens zijn te vinden op de website van Kaltura in:',
	'kalturavideo:text:buttoninfo' => '(Klik op "Account" -> "Algemene Informatie")',
	'kalturavideo:text:signupkaltura' => 'Een partnerlogin is vereist, registreer hier:',
	'kalturavideo:label:videotitle' => 'Titel van video',
	'kalturavideo:label:addvideo' => 'Een Kaltura video toevoegen',
	'kalturavideo:label:uid_prefix' => 'Kaltura cms user prefix',
	
	'kalturavideo:error:misconfigured' => 'Foute configuratie van plugin, of Kaltura login fout!',
	'kalturavideo:error:notconfigured' => 'Deze plugin is niet geconfigureerd!',
	'kalturavideo:error:missingks' => 'De "Administrator geheime sleutel" of "Web Service geheime sleutel" is waarschijnlijk verkeerd ingesteld.',
	'kalturavideo:error:partnerid' => 'Deze fout wordt waarschijnlijk veroorzaakt omdat je nog geen Kaltura Partner login hebt. Meer informatie in  het README bestand.',
	'kalturavideo:error:readme' => 'Lees het README bestand om deze plugin te configureren!',
	
	'kalturavideo:label:closewindow' => 'Sluit venster',
	'kalturavideo:label:select_size' => 'Selecteer grootte van de speler',
	'kalturavideo:label:large' => 'Groot',
	'kalturavideo:label:small' => 'Klein',
	'kalturavideo:label:insert' => 'Voeg video toe',
	'kalturavideo:label:edit' => 'Bewerk video',
	'kalturavideo:label:edittitle' => 'Bewerk titel',
	'kalturavideo:label:miniinsert' => 'Invoegen',
	'kalturavideo:label:miniedit' => 'Bewerk',
	'kalturavideo:label:cancel' => 'Annuleer',
	'kalturavideo:label:publish' => 'Publiceer',
	'kalturavideo:label:gallery' => 'Gallerij',
	'kalturavideo:label:next' => 'Volgende',
	'kalturavideo:label:prev' => 'Vorige',
	'kalturavideo:label:start' => 'Begin',
	'kalturavideo:label:newvideo' => 'Maak een nieuwe video',
	'kalturavideo:label:toolsadmin' => 'Administratie -> Tools administration (klik op "meer info")',
	'kalturavideo:label:gotoconfig' => 'Please configure properly the Kaltura Video under ',
	'kalturavideo:label:adminvideo\'s' => 'video\'s',
	'kalturavideo:label:myvideo\'s' => 'Mijn video\'s',
	'kalturavideo:label:friendsvideo\'s' => 'Video\'s van vrienden',
	'kalturavideo:label:length' => 'Lengte:',
	'kalturavideo:label:plays' => 'Aantal keer afgespeeld:',
	'kalturavideo:label:created' => 'Gemaakt:',
	'kalturavideo:label:details' => 'Bekijk details',
	'kalturavideo:label:view' => 'Bekijk video',
	'kalturavideo:label:editdetails' => 'Bewerk details',
	'kalturavideo:label:delete' => 'Verwijder video',
	'kalturavideo:prompt:delete' => 'Weet je zeker dat je deze video wilt verwijderen?',
	'kalturavideo:action:deleteok' => 'Video met id %ID% is verwijderd.',
	'kalturavideo:action:deleteko' => 'Video met id %ID% kon niet worden verwijderd!',
	'kalturavideo:action:updatedok' => 'Video met id %ID% is berwerkt.',
	'kalturavideo:action:updatedko' => 'Video met id %ID% kon niet worden bewerkt!',
	'kalturavideo:label:flv' => 'FLV video url:',
	'kalturavideo:label:thumbnail' => 'Voorbeeld url:',
	'kalturavideo:label:sharel' => 'HTML share code (big applet):',
	'kalturavideo:label:sharem' => 'HTML share code (little applet):',
	'kalturavideo:label:privateoptions' => 'Prive instelling:',
	'kalturavideo:private:public' => 'Publiek',
	'kalturavideo:private:me' => 'Prive',
	'kalturavideo:private:friends' => 'Alleen vrienden',
	'kalturavideo:private:loggedin' => 'Ingelogde gebruikers',
	'kalturavideo:text:privatestatus' => 'De prive instellingen hebben alleen betrekking op deze module (Publiek houdt in dat andere geregistreerde gebruikers de video kunnen zien, maar niet bewerken). Als je video\'s via HTML code deelt, dan hebben de prive instellingen geen effect.',
	'kalturavideo:text:statuschanged' => 'Prive instelling van video %2% veranderd in "%1%"',
	'kalturavideo:text:statusnotchanged' => 'De prive instelling %1% kon niet worden veranderd!',
	'kalturavideo:label:allvideo\'s' => 'Alle openbare video\'s',
	'kalturavideo:text:novideo\'s' => 'Sorry, hebt nog geen video\'s in je profiel!',
	'kalturavideo:text:nopublicvideo\'s' => 'Sorry, er zijn nog geen openbare video\'s!',
	'kalturavideo:label:author' => 'Author:',
	'kalturavideo:text:nofriendsvideo\'s' => 'Sorry, je vrienden hebben nog geen video\'s!',
	'kalturavideo:text:nouservideo\'s' => 'Sorry, dit profiel heeft nog geen video\'s!',
	'kalturavideo:label:showvideo' => 'Bekijk de video',
	'kalturavideo:text:notfound' => 'Bron niet gevonden!',
	'kalturavideo:show:advoptions' => 'Tonen: Delen met anderen',
	'kalturavideo:hide:advoptions' => 'Verberg: Delen met anderen',
	'kalturavideo:label:latest' => 'Laatste video',
	'kalturavideo:text:widgetdesc' => 'Deze widget laat de laatste publieke video\'s van je zien.',
	'kalturavideo:error:edittitle' => 'Error! De titel kon niet worden bewerkt!',
	'kalturavideo:label:latestfrom' => 'Laat de laaste video zien van:',
	'kalturavideo:label:anyvideo\'s' => 'Alle toegestane video\'s',
	'kalturavideo:error:objectnotavailable' => 'Object niet beschikbaar. Ververs deze pagina.',
	'kalturavideo:label:recreateobjects' => 'Herstructureer alle video objecten',
	'kalturavideo:text:recreateobjects' => 'Dit is noodzakelijk wanneer een Kaltura upgrade heeft plaatsgevonden of wanneer video\'s  buiten het ELGG framework zijn aangepast.\nAlle Elgg video objecten worden gecontroleerd en geherstructureerd, dit is een intensief proces.\n\BELANGRIJKE MEDEDELING:\nAlle Elgg video objecten worden verwijderd en vervolgens opnieuw gecreeerd. Metada, reacties en beoordelingen raken niet zoek, de GUID van het video object wordt veranderd.\nDit houdt in dat de oude URLS van de video\'s ook zullen veranderen (kan effect hebben andere plugins zoals bookmarks).',
	'kalturavideo:edit:notallowed' => 'You can not edit this video!',
	
	'kalturavideo:river:created' => '%s heeft gemaakt',
	'kalturavideo:river:annotate' => '%s heeft gereageerd op:',
	'kalturavideo:river:item' => 'een video',
	'kalturavideo:river:updated' => '%s heeft bewerkt:',
	
	'kalturavideo:river:shared' => 'Video',
	'kalturavideo:label:video\'sfrom' => 'video\'s van %s',
	
	'kalturavideo:user:showallvideo\'s' => 'Toon alle video\'s van dit profiel',
	
	'kalturavideo:strapline' => "%s",
	
	 /**
     * kaltura_video rating system
	 **/
	'kalturavideo:rating' => "Beoordeling",
	'kalturavideo:yourrate' => "Jouw beoordeling:",
	'kalturavideo:rate' => "Stem!",
	'kalturavideo:votes' => "stemmen",
	'kalturavideo:ratesucces' => "Je beoordeling is opgeslagen.",
	'kalturavideo:rateempty' => "Selecteer een optie voor de beoordeling!",
	'kalturavideo:notrated' => "Je hebt hier al een beoordeling van gegeven!",
	
	/**
	 * Groups
	 **/
	'kalturavideo:groupprofile' => 'Video\'s',
	'kalturavideo:label:groupvideo\'s' => "Video\'s van deze groep",
	'kalturavideo:label:allgroupvideo\'s' => "video\'s van alle groepen",
	'kalturavideo:text:nogroupvideo\'s' => 'Sorry, deze groep heeft nog geen video\'s!',
	'kalturavideo:private:thisgroup' => 'Alleen voor deze groep',
	'kalturavideo:label:collaborative' => 'Samenwerken',
	'kalturavideo:text:collaborative' => 'Andere groepsleden kunnen deze video bewerken!',
	'kalturavideo:text:collaborativechanged' => 'Samenwerk status voor video %1% is gewijzigd!',
	'kalturavideo:text:collaborativenotchanged' => 'Samenwerk status voor video %1% kon niet worden gewijzigd!',
	'kalturavideo:text:iscollaborative' => 'Dit is een samenwerkvideo, je kan deze bewerken!',
	
	'kalturavideo:userprofile' => 'Video\'s',
);

add_translation("nl", $nederlands);

?>
