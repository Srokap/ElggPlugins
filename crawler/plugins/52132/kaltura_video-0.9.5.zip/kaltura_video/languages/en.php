<?php
/**
* Kaltura video client
* @package ElggKalturaVideo
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author Ivan Vergés - Ballo Microstudi SL <ivan@microstudi.net>
* @copyright Ballo Microstudi SL 2009
* @link http://microstudi.net/elgg/
**/


$translations = array(
	
	'item:object:kaltura_video' => 'Kaltura videos',
	'kalturavideo:label:partner_id' => 'Partner ID',
	'kalturavideo:label:subp_id' => 'Sub-Partner ID',
	'kalturavideo:label:admin_secret' => 'Administrator Secret',
	'kalturavideo:label:secret' => 'Web Service Secret',
	'kalturavideo:title:video' => $CONFIG->sitename.'\'s video',
	'kalturavideo:descprefix:video' => 'A video from kaltura by',
	'kalturavideo:text:loginkaltura' => 'You can get this data from Kaltura\'s site in:',
	'kalturavideo:text:buttoninfo' => '(Press the button "Account" -> "General Info")',
	'kalturavideo:text:signupkaltura' => 'You need to be a partner to login, signup here if needed:',
	'kalturavideo:label:videotitle' => 'Created video title',
	'kalturavideo:label:addvideo' => 'Add videos from Kaltura',
	'kalturavideo:label:uid_prefix' => 'Kaltura cms user prefix',
	'kalturavideo:label:integratetinymce' => 'Try to integrate into TinyMCE plugin',
	
	'kalturavideo:error:misconfigured' => 'Misconfigured plugin or auth error width Kaltura!',
	'kalturavideo:error:notconfigured' => 'The plugin is not configured!',
	'kalturavideo:error:missingks' => 'Probably you have a mistake in the "Administrator Secret" or "Web Service Secret" configuration.',
	'kalturavideo:error:partnerid' => 'This error normaly appears if you are not a partner of Kaltura. Please read the README file and configure this plugin!',
	'kalturavideo:error:readme' => 'Please read the README file and configure this plugin!',
	
	'kalturavideo:label:closewindow' => 'Close window',
	'kalturavideo:label:select_size' => 'Select player size',
	'kalturavideo:label:large' => 'Large',
	'kalturavideo:label:small' => 'Small',
	'kalturavideo:label:insert' => 'Insert video',
	'kalturavideo:label:edit' => 'Edit video',
	'kalturavideo:label:edittitle' => 'Edit video title',
	'kalturavideo:label:miniinsert' => 'Insert',
	'kalturavideo:label:miniedit' => 'Edit',
	'kalturavideo:label:cancel' => 'Cancel',
	'kalturavideo:label:publish' => 'Publish',
	'kalturavideo:label:gallery' => 'Gallery',
	'kalturavideo:label:next' => 'Next',
	'kalturavideo:label:prev' => 'Previous',
	'kalturavideo:label:start' => 'Start',
	'kalturavideo:label:newvideo' => 'Create a new video',
	'kalturavideo:label:toolsadmin' => 'Administration -> Tools administration (click "more info")',
	'kalturavideo:label:gotoconfig' => 'Please configure properly the Kaltura Video under ',
	'kalturavideo:label:adminvideos' => 'Kaltura videos',
	'kalturavideo:label:myvideos' => 'My videos',
	'kalturavideo:label:friendsvideos' => 'Your friends\' videos',
	'kalturavideo:label:length' => 'Length:',
	'kalturavideo:label:plays' => 'Plays:',
	'kalturavideo:label:created' => 'Created:',
	'kalturavideo:label:details' => 'View details',
	'kalturavideo:label:view' => 'View video',
	'kalturavideo:label:editdetails' => 'Edit details',
	'kalturavideo:label:delete' => 'Delete video',
	'kalturavideo:prompt:delete' => 'Are you sure to permanently delete this video?',
	'kalturavideo:action:deleteok' => 'The video with id %ID% was deleted.',
	'kalturavideo:action:deleteko' => 'The video with id %ID% cannot be deleted!',
	'kalturavideo:action:updatedok' => 'The video with id %ID% was updated.',
	'kalturavideo:action:updatedko' => 'The video with id %ID% cannot be updated!',
	'kalturavideo:label:flv' => 'FLV video url:',
	'kalturavideo:label:thumbnail' => 'Thumbnail url:',
	'kalturavideo:label:sharel' => 'HTML share code (big applet):',
	'kalturavideo:label:sharem' => 'HTML share code (little applet):',
	'kalturavideo:label:privateoptions' => 'Privacy:',
	'kalturavideo:private:public' => 'Public',
	'kalturavideo:private:me' => 'Just me',
	'kalturavideo:private:friends' => 'Friends only',
	'kalturavideo:private:loggedin' => 'Logged in users',
	'kalturavideo:text:privatestatus' => 'The privacy options are valid only for this module (public means that other registered users can see the video but not modify it). If you share the HTML code of the video the privacy status have no effect (this includes every posted videos).',
	'kalturavideo:text:statuschanged' => 'Privacy status for the video %2% changed to "%1%"',
	'kalturavideo:text:statusnotchanged' => 'The privacy status for the video %1% cannot be changed!',
	'kalturavideo:label:allvideos' => 'All public videos',
	'kalturavideo:text:novideos' => 'Sorry, you don\'t have videos yet!',
	'kalturavideo:text:nopublicvideos' => 'Sorry, there are not public videos yet!',
	'kalturavideo:label:author' => 'Author:',
	'kalturavideo:text:nofriendsvideos' => 'Sorry, there are not videos from friends yet!',
	'kalturavideo:text:nouservideos' => 'Sorry, there are not videos from this user yet!',
	'kalturavideo:label:showvideo' => 'Show the video',
	'kalturavideo:text:notfound' => 'Resource not found!',
	'kalturavideo:show:advoptions' => 'Show sharing',
	'kalturavideo:hide:advoptions' => 'Hide sharing',
	'kalturavideo:label:latest' => 'Latest video',
	'kalturavideo:text:widgetdesc' => 'This widget allows you to show automatically your latest public video from Kaltura video plugins.',
	'kalturavideo:error:edittitle' => 'Error! This title can not be changed!',
	'kalturavideo:label:latestfrom' => 'Show the latest video from:',
	'kalturavideo:label:anyvideos' => 'Any allowed video',
	'kalturavideo:error:objectnotavailable' => 'Object not available. Please reload the page.',
	'kalturavideo:label:recreateobjects' => 'Recreate all video objects',
	'kalturavideo:text:recreateobjects' => 'Try to do this if you are upgrading the Kaltura plugin from any older version or some videos are delete outside Elgg.\nAll Elgg video objects will be checked and recreated, this can be a slow process.\n\nIMPORTANT NOTE:\nAll the Elgg objects will be deleted and recreated. Metada, comments and ratings will not be lost but the GUID of the video object will change.\nThis means that the old url for the videos will change also (could affect other plugins like bookmarks).',
	'kalturavideo:edit:notallowed' => 'You can not edit this video!',
	
	'kalturavideo:river:created' => '%s created',
	'kalturavideo:river:annotate' => '%s commented on',
	'kalturavideo:river:item' => 'an video',
	'kalturavideo:river:updated' => '%s updated',
	
	'kalturavideo:river:shared' => 'Kaltura video',
	'kalturavideo:label:videosfrom' => 'Videos by %s',
	
	'kalturavideo:user:showallvideos' => 'Show all videos from this user',
	
	'kalturavideo:strapline' => "%s",
	
	 /**
     * kaltura_video rating system
	 **/
	'kalturavideo:rating' => "Rating",
	'kalturavideo:yourrate' => "Your rating:",
	'kalturavideo:rate' => "Vote!",
	'kalturavideo:votes' => "votes",
	'kalturavideo:ratesucces' => "Your rating has been succesfully saved.",
	'kalturavideo:rateempty' => "Please select a value before rating!",
	'kalturavideo:notrated' => "You have already rated this item!",
	
	/**
	 * Groups
	 **/
	'kalturavideo:groupprofile' => 'Kaltura videos',
	'kalturavideo:label:groupvideos' => "Videos from this group",
	'kalturavideo:label:allgroupvideos' => "Videos from groups",
	'kalturavideo:text:nogroupvideos' => 'Sorry, there are not videos from this group yet!',
	'kalturavideo:private:thisgroup' => 'This group only',
	'kalturavideo:label:collaborative' => 'Collaborative',
	'kalturavideo:text:collaborative' => 'This allows other members of this group to edit this video too!',
	'kalturavideo:text:collaborativechanged' => 'Collaborative status for the video %1% changed!',
	'kalturavideo:text:collaborativenotchanged' => 'Collaborative status for the video %1% cannot be changed!',
	'kalturavideo:text:iscollaborative' => 'This is a collaborative video, you can edit it!',
	
	'kalturavideo:userprofile' => 'Kaltura videos',
);

add_translation("en", $translations);

?>
