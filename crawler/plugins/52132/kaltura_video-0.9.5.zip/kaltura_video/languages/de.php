<?php
/**
* Kaltura video client
* @package ElggKalturaVideo
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author Ivan VergГ©s - Ballo Microstudi SL <ivan@microstudi.net>
* @copyright Ballo Microstudi SL 2008
* @link http://microstudi.net/elgg/
* 
* This Translation is made by: Gleb Lagutin
*
**/


$translations = array(

	'item:object:kaltura_video' => 'Kaltura Videos',
	'kalturavideo:label:partner_id' => 'Partner ID',
	'kalturavideo:label:subp_id' => 'Sub-Partner ID',
	'kalturavideo:label:admin_secret' => 'Administrator Secret',
	'kalturavideo:label:secret' => 'Web Service Secret',
	'kalturavideo:title:video' => $CONFIG->sitename."\'s Video",
	'kalturavideo:descprefix:video' => 'Ein Video von Kaltura von',
	'kalturavideo:text:loginkaltura' => "Du kannst diese Daten von Kalturas Website holen:",
	'kalturavideo:text:buttoninfo' => '(Klicke auf "Account" -> "General Info")',
	'kalturavideo:text:signupkaltura' => 'Du musst ein Partner sein, um sich einloggen zu k&ouml;nnen. Melde Dich hier an:',
	'kalturavideo:label:videotitle' => 'Titel des erstellten Videos',
	'kalturavideo:label:addvideo' => 'F&uuml;ge Videos von Kaltura ein',
	'kalturavideo:label:uid_prefix' => 'Kaltura cms user prefix',
	'kalturavideo:label:integratetinymce' => 'Plugin in das TinyMCE intergrieren',

	'kalturavideo:error:misconfigured' => 'Unkonfiguriertes Plugin oder Anmeldefehler mit Kaltura!',
	'kalturavideo:error:notconfigured' => 'Das Plugin ist nicht richtig konfiguriert!',
	'kalturavideo:error:missingks' => 'Wahrscheinlich gibt es ein Fehler in den "Administrator Secret" oder "Web Service Secret" Einstellungen.',
	'kalturavideo:error:partnerid' => 'Dieser Fehler taucht auf, wenn Sie kein Partner von Kaltura sind. Lesen Sie die README Datei und konfigurieren Sie das Plugin!',
	'kalturavideo:error:readme' => 'Lesen Sie die README Datei und konfigurieren Sie das Plugin!',

	'kalturavideo:label:closewindow' => 'Fenster schliessen',
	'kalturavideo:label:select_size' => 'W&auml;e die Gr&ouml;sse des Players aus',
	'kalturavideo:label:large' => 'Gross',
	'kalturavideo:label:small' => 'Klein',
	'kalturavideo:label:insert' => 'Video einf&uuml;gen',
	'kalturavideo:label:edit' => 'Video bearbeiten',
	'kalturavideo:label:edittitle' => 'Videotitel bearbeiten',
	'kalturavideo:label:miniinsert' => 'Einf&uuml;gen',
	'kalturavideo:label:miniedit' => 'Bearbeiten',
	'kalturavideo:label:cancel' => 'Abbrechen',
	'kalturavideo:label:publish' => 'Ver&ouml;ffentlichen',
	'kalturavideo:label:gallery' => 'Gallerie',
	'kalturavideo:label:next' => 'Weiter',
	'kalturavideo:label:prev' => 'Zur&uuml;ck',
	'kalturavideo:label:start' => 'Start',
	'kalturavideo:label:newvideo' => 'Neues Video erstellen',
 	'kalturavideo:label:toolsadmin' => 'Administration -> Tools administration (click "more info")',
	'kalturavideo:label:gotoconfig' => 'Konfiguriere Das Kaltura-Video unter ',
	'kalturavideo:label:adminvideos' => 'Videos',
	'kalturavideo:label:myvideos' => 'Meine Videos',
	'kalturavideo:label:friendsvideos' => 'Videos von Freunden',
	'kalturavideo:label:length' => 'L&auml;nge:',
	'kalturavideo:label:plays' => 'Zuschauer:',
	'kalturavideo:label:created' => 'Erstellt:',
	'kalturavideo:label:details' => 'Mehr:',
	'kalturavideo:label:view' => 'Video ansehen',
	'kalturavideo:label:editdetails' => 'Details bearbeiten',
	'kalturavideo:label:delete' => 'Video l&ouml;schen',
	'kalturavideo:prompt:delete' => 'Willst Du das Video wirklich l&ouml;schen?',
	'kalturavideo:action:deleteok' => 'Das Video mit der ID %ID% wurde gel&ouml;scht.',
	'kalturavideo:action:deleteko' => 'TDas Video mit der ID %ID% kann nicht gel&ouml;scht werden!',
	'kalturavideo:action:updatedok' => 'Das Video mit der ID %ID% wurde aktualisiert.',
	'kalturavideo:action:updatedko' => 'Das Video mit der ID %ID% konnte nicht aktualisiert werden!',
	'kalturavideo:label:flv' => 'FLV Video URL:',
	'kalturavideo:label:thumbnail' => 'Bildvorschau URL:',
	'kalturavideo:label:sharel' => 'HTML Code (grosses Fenster):',
	'kalturavideo:label:sharem' => 'HTML Code (kleines Fenster):',
	'kalturavideo:label:privateoptions' => 'Privatsph&auml;re:',
	'kalturavideo:private:public' => '&Ouml;ffentlich',
	'kalturavideo:private:me' => 'Nur f&uuml;r mich',
	'kalturavideo:private:friends' => 'Nur f&uuml;r Freunde',
	'kalturavideo:private:loggedin' => 'Eingeloggte Nutzer',
	'kalturavideo:text:privatestatus' => 'Einstellungen der Privatsph&auml;re gelten nur f&uuml;r dieses Modul (&ouml;ffentlich bedeutet, dass alle angemeldeten Nutzer das Video betrachten, aber nicht ver&auml;ndern k&ouml;nnen). Wenn Du den HTML Code kopierst, werden Einstellungen der Privatsph&auml;re nicht &uuml;bernommen (es betrifft jedes Video).',
	'kalturavideo:text:statuschanged' => 'Privateinstellungen für das Video %2% wurden auf "%1%" gesetzt.',
	'kalturavideo:text:statusnotchanged' => 'Privateinstellungen für das Video %1% konnten nicht geändert werden!',
	'kalturavideo:label:allvideos' => 'Alle &ouml;ffentlichen Videos',
	'kalturavideo:text:novideos' => "Sorry, Du hast noch keine Videos!",
	'kalturavideo:text:nopublicvideos' => 'Sorry, es gibt noch keine &ouml;ffentlichen Videos!',
	'kalturavideo:label:author' => 'Urheber:',
	'kalturavideo:text:nofriendsvideos' => 'Sorry, es gibt noch keine Videos von Freunden!',
	'kalturavideo:text:nouservideos' => 'Sorry, der Nutzer hat noch keine Videos!',
	'kalturavideo:label:showvideo' => 'Video anzeigen',
	'kalturavideo:text:notfound' => 'Resource nicht gefunden!',
	'kalturavideo:show:advoptions' => 'Erweiterte Infos anzeigen',
	'kalturavideo:hide:advoptions' => 'Erweiterte Infos verstecken',
	'kalturavideo:label:latest' => 'Neustes Video',
	'kalturavideo:text:widgetdesc' => 'In diesem Widget kannst Du dein neustes Video anzeigen lassen.',
	'kalturavideo:error:edittitle' => 'Fehler! Titel kann nicht ge&auml;ndert werden!',
	'kalturavideo:label:latestfrom' => 'Zeige neueste Videos von:',
	'kalturavideo:label:anyvideos' => 'Alle erlaubten Videos',
	'kalturavideo:error:objectnotavailable' => 'Objekt nicht verf&uuml;gbar. Bitte aktualisiere die Seite.',
	'kalturavideo:label:recreateobjects' => 'Alle Videos wiederherstellen',
	'kalturavideo:text:recreateobjects' => 'F&uuml;hre diese Aktion aus, wenn einige Videos nicht ьber YourLife.eu gel&ouml;scht wurden. Alle Videos werden gecheckt und verglichen.',
	'kalturavideo:edit:notallowed' => 'Du kannst dieses Video nicht bearbeiten!',

	'kalturavideo:river:created' => '%s erstellte',
	'kalturavideo:river:annotate' => '%s kommentierte',
	'kalturavideo:river:item' => 'ein Video',
	'kalturavideo:river:updated' => '%s aktualisierte',

	'kalturavideo:river:shared' => 'Kaltura Video',
	'kalturavideo:label:videosfrom' => 'Videos von %s',

	'kalturavideo:user:showallvideos' => 'Alle Videos dieses Nutzers anzeigen',

	'kalturavideo:strapline' => "%s",

	 /**
     * kaltura_video rating system
	 **/
	'kalturavideo:rating' => "Bewertung",
	'kalturavideo:yourrate' => "Deine Bewertung:",
	'kalturavideo:rate' => "Abstimmen!",
	'kalturavideo:votes' => "Bewertungen",
	'kalturavideo:ratesucces' => "Deine Bewertung wurde gespeichert.",
	'kalturavideo:rateempty' => "Bitte eine Bewertung auf der Skala auswählen!",
	'kalturavideo:notrated' => "Du hast dieses Video schon bewertet!",

	/**
	 * Groups
	 **/
	'kalturavideo:groupprofile' => 'Kaltura Videos',
	'kalturavideo:label:groupvideos' => "Videos dieser Gruppe",
	'kalturavideo:label:allgroupvideos' => "Videos von Gruppen",
	'kalturavideo:text:nogroupvideos' => 'Sorry, es gibt noch keine Videos in dieser Gruppe!',
	'kalturavideo:private:thisgroup' => 'Nur diese Gruppe',
	'kalturavideo:label:collaborative' => 'Gemeinschaftlich',
	'kalturavideo:text:collaborative' => 'Es erlaubt anderen Mitgliedern der Gruppe, das Video zu bearbeiten!',
	'kalturavideo:text:collaborativechanged' => 'Gemeinschaftlicher Status für das Video %1% wurde geändert!',
	'kalturavideo:text:collaborativenotchanged' => 'Gemeinschaftlicher Status für das Video %1% konnte nicht geändert werden!',
	'kalturavideo:text:iscollaborative' => 'Das ist ein gemeinschaftliches Video. Du kannst es bearbeiten!',

	'kalturavideo:userprofile' => 'Kaltura Videos',
);

add_translation("de", $translations);

?>
