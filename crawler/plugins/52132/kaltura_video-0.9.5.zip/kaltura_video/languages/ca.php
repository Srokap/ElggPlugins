<?php
/**
* Kaltura video client
* @package ElggKalturaVideo
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author Ivan Vergés - Ballo Microstudi SL <ivan@microstudi.net>
* @copyright Ballo Microstudi SL 2009
* @link http://microstudi.net/elgg/
**/




$translations = array(
	'item:object:kaltura_video' => 'Video',
	'kalturavideo:label:partner_id' => 'Partner ID',
	'kalturavideo:label:subp_id' => 'Sub-Partner ID',
	'kalturavideo:label:admin_secret' => 'Administrator Secret',
	'kalturavideo:label:secret' => 'Web Service Secret',
	'kalturavideo:title:video' => 'Sense títol',
	'kalturavideo:descprefix:video' => '',
	'kalturavideo:text:loginkaltura' => 'Pots obtenir aquestes dades del lloc de kaltura a:',
	'kalturavideo:text:buttoninfo' => '(Apreta el botó "Account" -> "General Info")',
	'kalturavideo:text:signupkaltura' => 'Necessites ser un partner de Kaltura per identificar-te, registra\'t aqui si és necessari:',
	'kalturavideo:label:videotitle' => 'Títol del video creat',
	'kalturavideo:label:addvideo' => 'Afegeix videos',
	'kalturavideo:label:uid_prefix' => 'Prefix de l\'usuari que es veurà al cms de kaltura',
	'kalturavideo:label:integratetinymce' => 'Intenta integrar un botó al plugin TinyMCE',

	'kalturavideo:error:misconfigured' => 'El plugin està mal configurat o bé hi ha un error d\'autentificació amb Kaltura!',
	'kalturavideo:error:notconfigured' => 'El plugin està mal configurat!',
	'kalturavideo:error:missingks' => 'Probablement tens un error a "Administrator Secret" or "Web Service Secret" a la configuració del plugin.',
	'kalturavideo:error:partnerid' => 'Aquest error apareix normalment quan encara no t\'has associat a Kaltura com a partner. Si us plau, llegeix l\'arxiu README i configura aquest plugin!',
	'kalturavideo:error:readme' => 'Si us plau, llegeix l\'arxiu README i configura aquest plugin!',

	'kalturavideo:label:closewindow' => 'Tanca la finestra',
	'kalturavideo:label:select_size' => 'Sel·lecciona el tamany del video',
	'kalturavideo:label:large' => 'Gran',
	'kalturavideo:label:small' => 'Petit',
	'kalturavideo:label:insert' => 'Inserta el video',
	'kalturavideo:label:edit' => 'Edita el video',
	'kalturavideo:label:edittitle' => 'Edita el títol del video',
	'kalturavideo:label:miniinsert' => 'Inserta',
	'kalturavideo:label:miniedit' => 'Edita',
	'kalturavideo:label:cancel' => 'Cancela',
	'kalturavideo:label:publish' => 'Publica el video',
	'kalturavideo:label:gallery' => 'Galeria',
	'kalturavideo:label:next' => 'Següent',
	'kalturavideo:label:prev' => 'Anterior',
	'kalturavideo:label:start' => 'Inici',
	'kalturavideo:label:newvideo' => 'Crea un nou video',
	'kalturavideo:label:toolsadmin' => 'Administració -> Tools administration (click a "more info")',
	'kalturavideo:label:gotoconfig' => 'Si us plau, configureu adequadament el plugin Kaltura Video a ',
	'kalturavideo:label:adminvideos' => 'Videos',
	'kalturavideo:label:myvideos' => 'Els meus videos',
	'kalturavideo:label:friendsvideos' => 'Els videos dels meus amics',
	'kalturavideo:label:length' => 'Llargada:',
	'kalturavideo:label:plays' => 'Reproduccions:',
	'kalturavideo:label:created' => 'Creat:',
	'kalturavideo:label:details' => 'Veure detalls',
	'kalturavideo:label:view' => 'Veure el video',
	'kalturavideo:label:editdetails' => 'Edita els detalls',
	'kalturavideo:label:delete' => 'Esborra el video',
	'kalturavideo:prompt:delete' => 'Segur que voleu esborrar permanentment aquest video?',
	'kalturavideo:action:deleteok' => 'El video amb id %ID% s\'ha esborrat.',
	'kalturavideo:action:deleteko' => 'El video amb id %ID% no es pot esborrar!',
	'kalturavideo:action:updatedok' => 'El video amb id %ID% s\'ha actualizat.',
	'kalturavideo:action:updatedko' => 'El video amb id %ID% no es pot actualizar!',
	'kalturavideo:label:flv' => 'Ruta de l\'arxiu FLV:',
	'kalturavideo:label:thumbnail' => 'Ruta de la miniatura:',
	'kalturavideo:label:sharel' => 'Codi per HTML per incrustar (mida gran):',
	'kalturavideo:label:sharem' => 'Codi per HTML per incrustar (mida petita):',

	'kalturavideo:label:privateoptions' => 'Privacitat:',
	'kalturavideo:private:public' => 'Públic',
	'kalturavideo:private:me' => 'Només jo',
	'kalturavideo:private:friends' => 'Només amics',
	'kalturavideo:text:privatestatus' => 'Les opcions de privacitat només són vàlides per aquest mòdul (públic vol dir que serà accessible per a tots els usuaris registrats encara que no el podran modificar). Si comparteixes el codi HTML del video la opció de privacitat no té efecte (això inclou tots els videos en que estiguin en posts, articles, etc).',
	'kalturavideo:text:statuschanged' => 'S\'ha canviat l\'estat de privacitat a "%1%" per al video %2%',
	'kalturavideo:text:statusnotchanged' => 'No s\'ha pogut canviar l\'estat de privacitat per al video %1%!',
	'kalturavideo:label:allvideos' => 'Tots els videos públics',
	'kalturavideo:text:novideos' => 'Ho sento, no tens videos encara!',
	'kalturavideo:text:nopublicvideos' => 'Ho sento, no hi ha videos públics encara!',
	'kalturavideo:label:author' => 'Autor:',
	'kalturavideo:text:nofriendsvideos' => 'Ho sento, no hi ha videos dels teus amics encara!',
	'kalturavideo:text:nouservideos' => 'Ho sento, no hi ha videos d\'aquest usuari encara!',
	'kalturavideo:label:showvideo' => 'Mostra el video',
	'kalturavideo:text:notfound' => 'Recurs no trobat!',
	'kalturavideo:show:advoptions' => 'Mostra el detalls avançats',
	'kalturavideo:hide:advoptions' => 'Amaga el detalls avançats',
	'kalturavideo:label:latest' => 'L\'últim video',
	'kalturavideo:text:widgetdesc' => 'Aquest widget et permet mostrar l\'últim video públic creat amb el plugin Kaltura video.',
	'kalturavideo:error:edittitle' => 'Error! No pots canviar aquest títol!',
	'kalturavideo:label:latestfrom' => 'Mostra l\'ultim video de:',
	'kalturavideo:label:anyvideos' => 'Qualsevol video permés',
	'kalturavideo:error:objectnotavailable' => 'Objecte no disponible. Si us plau recarega la pàgina.',
	'kalturavideo:label:recreateobjects' => 'Recrea tots els objectes de video',
	'kalturavideo:text:recreateobjects' => 'Prova d\'executar això si estàs actualitzant el plugin desde una versió anterior o has esborrat videos fora de l\'Elgg.\nTots els objectes d\'Elgg seran comprovats i recreats, això pot ser un procés lent.\n\nNOTA IMPORTANT:\nTots els objectes d\Elgg seran esborrats i recreats. Les metadades, comentaris i valoracions no es perdran pero el GUID de l\'objecte vido cambiarà.\nAixò significa que l\'antiga url per els videos cambiarà també (i pot afectar d\'altres plugins com el de bookmarks).',
	'kalturavideo:edit:notallowed' => 'No pots editar aquest video!',

	'kalturavideo:river:created' => '%s ha creat',
	'kalturavideo:river:annotate' => '%s comentat el',
	'kalturavideo:river:item' => 'un video',
	'kalturavideo:river:updated' => '%s ha actualitzat',

	'kalturavideo:river:shared' => 'Video',
	'kalturavideo:label:videosfrom' => 'Videos de %s',

	'kalturavideo:user:showallvideos' => 'Mostra tots els videos d\'aquest usuari',
	'kalturavideo:strapline' => "%s",

	/**
		 * kaltura_video rating system
	**/
	'kalturavideo:rating' => "Valoració",
	'kalturavideo:yourrate' => "La teva valoració:",
	'kalturavideo:rate' => "Vota!",
	'kalturavideo:votes' => "vots",
	'kalturavideo:ratesucces' => "La teva valoració s'ha desat correctament.",
	'kalturavideo:rateempty' => "Si us plau, sel·lecciona un valor abans de valorar!",
	'kalturavideo:notrated' => "Ja has valorat aquest ítem!",

	/**
	* Groups
	**/
	'kalturavideo:groupprofile' => 'Videos',
	'kalturavideo:label:groupvideos' => "Vídeos d'aquest grup",
	'kalturavideo:label:allgroupvideos' => "Vídeos de grups",
	'kalturavideo:text:nogroupvideos' => 'Ho sento, no hi ha vídeos en aquest grup encara!',
	'kalturavideo:private:thisgroup' => 'Aquest grup només',
	'kalturavideo:label:collaborative' => 'Video col·laboratiu',
	'kalturavideo:text:collaborative' => 'Això permetrà als altres membres del grup editar aquest vídeo també!',
	'kalturavideo:text:collaborativechanged' => 'L\'estat col·laboratiu per al vídeo %1% s\'ha cambiat!',
	'kalturavideo:text:collaborativenotchanged' => 'L\'estat col·laboratiu per al vídeo %1% no es pot cambiar!',
	'kalturavideo:text:iscollaborative' => 'Això és un vídeo col·laboratiu, el pots editar!',


	'kalturavideo:userprofile' => 'Videos',
);


add_translation("ca", $translations);


?>
