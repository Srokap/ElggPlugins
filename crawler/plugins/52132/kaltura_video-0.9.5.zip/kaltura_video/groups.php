<?php
/**
* Kaltura video client
* @package ElggKalturaVideo
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author Ivan Vergés - Ballo Microstudi SL <ivan@microstudi.net>
* @copyright Ballo Microstudi SL 2009
* @link http://microstudi.net/elgg/
**/

require_once($CONFIG->pluginspath."kaltura_video/kaltura/editor/includes.php");

$object_label = "kaltura_video";

$limit = get_input('limit', 10);
$offset = get_input('offset');

set_input('username',$page[1]);
	
$group = page_owner_entity();

if($group instanceof ElggGroup) {
	//List all videos (If I can see it) from a user
		$title = sprintf(elgg_echo("kalturavideo:label:videosfrom"),$group->name);
		$body = elgg_view_title($title);

		$body .= '<script type="text/javascript">
/* <![CDATA[ */
CURRENT_GROUP = "'.$group->username.'";
/* ]]> */
</script>
';

		//global $is_admin;$is_admin = true;
		$context = get_context();
		set_context('search');
		
		$count = get_objects_in_group($group->getGUID(),$object_label,0,0,"",$limit,$offset,true);
		$result = get_objects_in_group($group->getGUID(),$object_label,0,0,"",$limit,$offset,false);
		
		set_context($context);
		
		//$body .= elgg_echo("kalturavideo:text:nogroupvideos");
}
else {

	$title = elgg_echo("kalturavideo:label:adminvideos").": ";
	$title .= elgg_echo("kalturavideo:label:allgroupvideos");
	$body = elgg_view_title($title);

	$context = get_context();
	set_context('search');
	
	//list all videos from groups
	$body .= list_entities_from_metadata('kaltura_video_group_visible','1','object',$object_label);
	
	set_context($context);

}
	
if($result) {
	$wrapped_entries = array();
	foreach($result as $ob) {
		//print_r($ob);die;	
		$tmp = get_entity($ob->guid);
		$wrapped_entries[] = $tmp;
	}

	//print_r($result);die;
	$context = get_context();
	set_context('search');
	$body .= elgg_view_entity_list($wrapped_entries, $count, $offset, $limit, false);
	set_context($context);

}


if(elgg_get_viewtype() == 'default') {
	$body = '<div id="kaltura_container">'.$body.'</div>';
}

// Display main admin menu
page_draw($title,elgg_view_layout("two_column_left_sidebar", '', $body));

?>
