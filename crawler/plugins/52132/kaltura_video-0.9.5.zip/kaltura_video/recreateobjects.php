<?php
/**
* Kaltura video client
* @package ElggKalturaVideo
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author Ivan Vergés - Ballo Microstudi SL <ivan@microstudi.net>
* @copyright Ballo Microstudi SL 2009
* @link http://microstudi.net/elgg/
**/

require_once($CONFIG->pluginspath."kaltura_video/kaltura/editor/includes.php");

$object_label = 'kaltura_video';
$error = '';
if(isadminloggedin()) {
	$title = elgg_echo("kalturavideo:label:recreateobjects");
	$body = elgg_view_title($title);
	
	//open the kaltura list with admin privileges
	$user_secret = $secret;
	$secret = $admin_secret;
	$kaltura_user = new kalturaUser();
	$kaltura_user->puser_id=$uid;
	$kaltura_user->puser_name=$username;

	$domain = $SERVER_HOST;

	//open the kaltura list with admin privileges
	$kaltura_service = kalturaService::getInstance( $kaltura_user,true);
	
	$page = 0;
	$page_size = 1;
	$params = array(
		"page"=>$page,
		"page_size"=>$page_size
	);

	//gallery
	$res = $kaltura_service->listkshows ( $kaltura_user , $params );
	
	if($res['result']['count']) {
		//$page_size = $res['result']['count'];
		$page_size = 50;
		$params = array(
			"detailed"=>"1",
			"page"=>0,
			"page_size"=>$page_size
		);
		$subres = array();
		$kshows = array();
		for($i=0; $i<$res['result']['count']; $i+=50) {
			$params["page"] ++;
			$subres = $kaltura_service->listkshows ( $kaltura_user , $params );
			
			if(is_array($subres['result']['kshows'])) {
				$kshows = array_merge($kshows,$subres['result']['kshows']);
			}
		}

	}
	else $page_size = 0;

	if ( $res['error'][0]['code'] ) {
		if($res['error'][0]['code'] != 'INVALID_USER_ID') {
			$error = "Error Code: ".$res['error'][0]['code']."\n";
			$error .= "Error Code: ".$res['error'][0]['desc'];
		}
	}


	if($error) {
		$body .= kaltura_get_error_page($res['error'][0]['code'],$error,false);
	}
	elseif(@count($kshows)==$res['result']['count'] && $res['result']['count']>0) {
		
		$secret = $user_secret;
		$kaltura_user = new kalturaUser();
		$kaltura_user->puser_id=$uid;
		$kaltura_user->puser_name=$username;

		//open the kaltura list with admin privileges
		$kaltura_service = kalturaService::getInstance( $kaltura_user,false);
	
		$ok_guids = array();
		foreach($kshows as $result) {
			$user = substr($result['puserId'],strlen($prefix));
			if($uob = get_user_by_username($user)) {
				//print_r($result);continue;
				$ob = kaltura_get_entity($result['id']);
				
				if($ob->title) $result['name'] = $ob->title;
				if($ob->description) $result['description'] = $ob->description;
				if($ob->tags) $result['tags'] = implode(", ",$ob->tags);
				
				if($ob) {
					$metadata = kaltura_get_metadata($ob);
					$comments = $ob->getAnnotations("generic_comment");
					$video_ratings = $ob->getAnnotations("kaltura_video_rating");
					$video_numvotes = $ob->getAnnotations("kaltura_video_numvotes");
					$container_guid = $ob->container_guid;
					
				}
				else {
					$metadata = false;
					$comments = false;
					$video_ratings = false;
					$video_numvotes = false;
					$container_guid = null; //default value
				}
				
				//get comments && get rating (annotations)
				
				//stored values in users
				$voted_videos = get_annotations(0,"","","kaltura_video_rated",$ob->guid);
				//delete metadata
				if($metadata) {
					foreach($metadata as $name => $value) {
						remove_metadata($ob->guid,$name);
					}
				}
				if($ob) {
					//delete annotations
					$ob->clearAnnotations("generic_comment");
					$ob->clearAnnotations("kaltura_video_rating");
					$ob->clearAnnotations("kaltura_video_numvotes");
					//delete the object
					if(!$ob->delete()) die("Fatal error while deleting old object, ABORTING\n");
				}
				
				//create new object
				$ob = kaltura_update_object($result,null,null,$metadata->kaltura_video_privacity,$uob->guid,$container_guid);
				if(!$ob) die("Fatal error while creating new object, ABORTING\n");
				//create metadata
				if($metadata) {
					if($metadata->kaltura_video_widget_id) {
						$ob->kaltura_video_widget_id = $metadata->kaltura_video_widget_id;
						$ob->kaltura_video_widget_uid = $metadata->kaltura_video_widget_uid;
						$ob->kaltura_video_widget_width = $metadata->kaltura_video_widget_width;
						$ob->kaltura_video_widget_height = $metadata->kaltura_video_widget_height;
						$ob->kaltura_video_widget_html = $metadata->kaltura_video_widget_html;
					}
					if($metadata->kaltura_video_collaborative) $ob->kaltura_video_collaborative = $metadata->kaltura_video_collaborative;
					//echo htmlspecialchars(print_r($metadata,true));
				}
				if(!$ob->save()) die("Fatal error while saving metadata to new object, ABORTING\n");
				//create annotations
				if($comments) {
					foreach($comments as $annotation) {
						$ob->annotate($annotation['name'], $annotation['value'], $annotation['access_id'], $annotation['owner_guid'], $annotation['value_type']);
					}
				}
				if($video_ratings) {
					foreach($video_ratings as $annotation) {
						$ob->annotate($annotation['name'], $annotation['value'], $annotation['access_id'], $annotation['owner_guid'], $annotation['value_type']);
					}
				}
				if($video_numvotes) {
					foreach($video_numvotes as $annotation) {
						$ob->annotate($annotation['name'], $annotation['value'], $annotation['access_id'], $annotation['owner_guid'], $annotation['value_type']);
					}
				}
				
				//update user annotations
				if($voted_videos) {
					foreach($voted_videos as $annotation) {
						update_annotation($annotation['id'],$annotation['name'],$ob->guid,$annotation['owner_guid'],$annotation['access_id']);
					}
				}
				//create the widget if not exists
				$ob = kaltura_update_object($result,$kaltura_service,$kaltura_user,null,$uob->guid);

				if($ob->save()) {
					//$ob->delete();
					$body .= '<p>';
					$body .= 'UPDATED OBJECT '.$ob->guid.': KSHOW ID: '.$result['id'].', USER: '.$uob->username.' ('.$uob->guid.')';
					$body .= ' CONTAINER: '.$ob->container_guid;
					$body .= '</p>';
					$ok_guids[] = $ob->guid;
				}
				else $error = true;
			}
		}
		//return;
		//Check all objects from Elgg to delete which are not in kaltura
		$result = get_entities('object',$object_label,0,"",0);
		if($result && !$error) {
			foreach($result as $ob) {
				//checks if is deleted from kaltura
				if(!in_array($ob->guid,$ok_guids)) {
					$metadata = kaltura_get_metadata($ob);
					$body .= '<p>';
					$body .= 'INVALID KSHOW ID FOR OBJECT '.$ob->guid.' KSHOW ID: '.$metadata->kaltura_video_id;
					
					if($ob->delete()) $body .= ' <span style="color:#0f0">DELETED FROM ELGG</span>';
					else $body .= ' <span style="color:#f00">FAILED TO DELETE</span>';
					$body .= '</p>';
				}
			}
		}
	}
	else {
		$body .= "Not founds videos in Kaltura's site";
	}
	// Display main admin menu
	page_draw($title,elgg_view_layout("two_column_left_sidebar", '', $body));

}
else {
	header("Location: ".$CONFIG->wwwroot."pg/kaltura_video/");
	exit;
}

?>
