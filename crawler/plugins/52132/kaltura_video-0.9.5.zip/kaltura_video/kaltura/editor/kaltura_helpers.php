<?php
/**
* Kaltura video client
* @package ElggKalturaVideo
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author Ivan Vergés - Ballo Microstudi SL <ivan@microstudi.net>
* @copyright Ballo Microstudi SL 2009
* @link http://microstudi.net/elgg/
**/

//Checks if a video is rated by the user
function kaltura_is_rated_by_user($guid,$user_entity,$current_votes=1) {
	$user_ratings = $user_entity->getAnnotations('kaltura_video_rated');
	//echo "[".print_r($user_ratings,true)."]";
	foreach ($user_ratings as $user_rating){
		//$ratingobject->delete();
		if($user_rating['value'] == $guid) {
			if($current_votes==0) {
				delete_annotation($user_rating['id']);
				continue;
			}
			return true;
		}
	}
	return false;
}
//returns a rating of video object
function kaltura_get_rating($entity) {
	$article_rating = 0;
	$getoldrates = $entity->getAnnotations('kaltura_video_rating',1);
	foreach ($getoldrates as $getoldrate){
		$article_rating = $getoldrate['value'];
	}
	$numvotes = 0;
	$getnumvotes = $entity->getAnnotations('kaltura_video_numvotes',1);
	foreach ($getnumvotes as $getnumvote){
		$numvotes = $getnumvote['value'];
	}	
	
	// Match rating to image		
	if($numvotes == 0){
			$rating_image = "rating0.gif";
	} else {
		if((($article_rating >= 0)or($article_rating == 0)) && ($article_rating <= 0.50)){
			$rating_image = "rating0.gif";
		}
		if((($article_rating >= 0.50)or($article_rating == 0.50)) && ($article_rating <= .99)){
			$rating_image = "rating0_halt.gif";
		}
		if((($article_rating >= 1.00)or($article_rating == 1.50)) && ($article_rating <= 1.49)){
			$rating_image = "rating1.gif";
		}
		if((($article_rating >= 1.50)or($article_rating == 1.50)) && ($article_rating <= 1.99)){
			$rating_image = "rating1_half.gif";
		}
		if((($article_rating >= 2.00)or($article_rating == 2.00)) && ($article_rating <= 2.49)){
			$rating_image = "rating2.gif";
		}
		if((($article_rating >= 2.50)or($article_rating == 2.50)) && ($article_rating <= 2.99)){
			$rating_image = "rating2_half.gif";
		}
		if((($article_rating >= 3.00)or($article_rating == 3.00)) && ($article_rating <= 3.49)){
			$rating_image = "rating3.gif";
		}
		if((($article_rating >= 3.50)or($article_rating == 3.50)) && ($article_rating <= 3.99)){
			$rating_image = "rating3_half.gif";
		}
		if((($article_rating >= 4.00)or($article_rating == 4.00)) && ($article_rating <= 4.49)){
			$rating_image = "rating4.gif";
		}
		if((($article_rating >= 4.50)or($article_rating == 4.50)) && ($article_rating <= 4.99)){
			$rating_image = "rating4_half.gif";
		}
		if($article_rating == 5.0){
			$rating_image = "rating5.gif";
		}
	}
	return array($numvotes,$rating_image,$article_rating);
}
/**
 * This is the same function in engine/lib/metadata.php but with than a value (OR)
 * Return a list of entities based on the given search criteria.
 * 
 * @param mixed $meta_name 
 * @param mixed $meta_value
 * @param string $entity_type The type of entity to look for, eg 'site' or 'object'
 * @param string $entity_subtype The subtype of the entity.
 * @param int $limit 
 * @param int $offset
 * @param string $order_by Optional ordering.
 * @param int $site_guid The site to get entities for. Leave as 0 (default) for the current site; -1 for all sites.
 * @param true|false $count If set to true, returns the total number of entities rather than a list. (Default: false)
 * 
 * @return int|array A list of entities, or a count if $count is set to true
 */
function kaltura_get_entities_from_metadata($meta_name, $meta_value = array(), $entity_type = "", $entity_subtype = "", $owner_guid = 0, $limit = 10, $offset = 0, $order_by = "", $site_guid = 0, $count = false)
{
	global $CONFIG;
	
	$meta_n = get_metastring_id($meta_name);
	$meta_v = array();
	foreach($meta_value as $m) {
		$meta_v[] = get_metastring_id($m);
	}
	$entity_type = sanitise_string($entity_type);
	$entity_subtype = get_subtype_id($entity_type, $entity_subtype);
	$limit = (int)$limit;
	$offset = (int)$offset;
	if ($order_by == "") $order_by = "e.time_created desc";
	$order_by = sanitise_string($order_by);
	$site_guid = (int) $site_guid;
	if ((is_array($owner_guid) && (count($owner_guid)))) {
		foreach($owner_guid as $key => $guid) {
			$owner_guid[$key] = (int) $guid;
		}
	} else {
		$owner_guid = (int) $owner_guid;
	}
	if ($site_guid == 0)
		$site_guid = $CONFIG->site_guid;
		
	//$access = get_access_list();
		
	$where = array();
	
	if ($entity_type!="")
		$where[] = "e.type='$entity_type'";
	if ($entity_subtype)
		$where[] = "e.subtype=$entity_subtype";
	if ($meta_name!="")
		$where[] = "m.name_id='$meta_n'";
		
	if(count($meta_v)>0)
		$where[] = "m.value_id in ('".implode("','",$meta_v)."')";
		
	if ($site_guid > 0)
		$where[] = "e.site_guid = {$site_guid}";
	if (is_array($owner_guid)) {
		$where[] = "e.container_guid in (".implode(",",$owner_guid).")";
	} else if ($owner_guid > 0)
		$where[] = "e.container_guid = {$owner_guid}";
	
	if (!$count) {
		$query = "SELECT distinct e.* "; 
	} else {
		$query = "SELECT count(distinct e.guid) as total ";
	}
			
	$query .= "from {$CONFIG->dbprefix}entities e JOIN {$CONFIG->dbprefix}metadata m on e.guid = m.entity_guid where";
	foreach ($where as $w)
		$query .= " $w and ";
	$query .= get_access_sql_suffix("e"); // Add access controls
	$query .= ' and ' . get_access_sql_suffix("m"); // Add access controls
	
	if (!$count) {
		$query .= " order by $order_by limit $offset, $limit"; // Add order and limit
		return get_data($query, "entity_row_to_elggstar");
	} else {
		if ($row = get_data_row($query))
			return $row->total;
	}
	return false;
}

//return a list of guid of users (friends or public)
function kaltura_get_owner_id_from_type($type) {
	global $CONFIG;
	$owner_id = array(0);
	if($type == 'public') {
		//retrieve a list of all user guids in the system
		$query = "SELECT guid FROM {$CONFIG->dbprefix}users_entity";
		if($data = get_data($query)) {
			foreach($data as $ob) {
				if($ob->guid != $_SESSION['user']->guid) $owner_id[] = $ob->guid;
			}
		}
	}
	elseif($type == 'friends') {
		if(!isloggedin()) return $owner_id;
		//retrieve a list of all user friends guids in the system
		if($data = get_user_friends_of($_SESSION['user']->guid)) {
			foreach($data as $ob) {
				if($ob->guid != $_SESSION['user']->guid) $owner_id[] = $ob->guid;
			}
		}
	}
	elseif($type == 'group') {
		if(!isloggedin()) return $owner_id;
		//retrieve a list of all groups guids in the system
		$query = "SELECT guid FROM {$CONFIG->dbprefix}entities WHERE `type`='group' AND `enabled`='yes'";
		if($data = get_data($query)) {
			foreach($data as $ob) {
				$owner_id[] = $ob->guid;
			}
		}
	}
	return $owner_id;
}

//gets a kaltura object with all metadata from a guid
function kaltura_get_metadata($entity) {
	unset($ob);
	if(!$entity) return false;
	$metadata = get_metadata_for_entity($entity->getGUID());
	
	foreach($metadata as $meta) {	
		if(strpos($meta->name,"kaltura_video_")===0) $ob->{$meta->name} = $meta->value;
	}
	//editable ??
	$ob->kaltura_video_editable = false;
	$ob->kaltura_video_visible = false;
	//collaborative videos
	$ob->kaltura_video_cancollaborate = false;
	
	if(isloggedin()) {
		//if is not logged in, access will be handled as a normal elgg object
		
		if($entity->owner_guid == $_SESSION['user']->getGUID() || isadminloggedin()) $ob->kaltura_video_editable = true;
	
		//allow visible ??
		if( $entity->owner_guid == $_SESSION['user']->getGUID()
			|| ($ob->kaltura_video_privacity == 'friends' && user_is_friend($entity->owner_guid,$_SESSION['user']->getGUID()))
		) {
			$ob->kaltura_video_visible = true;
		}
		if($ob->kaltura_video_privacity == 'loggedin') $ob->kaltura_video_visible = true;
		$isgroupmember = is_group_member($entity->container_guid,$_SESSION['user']->getGUID());
		if($ob->kaltura_video_privacity == 'thisgroup') {
			if($isgroupmember) {
				$ob->kaltura_video_visible = true;
			}
		}
		if($ob->kaltura_video_collaborative) {
			if($isgroupmember) {
				$ob->kaltura_video_cancollaborate = true;
			}
		}
	}
	if($ob->kaltura_video_privacity == 'public') $ob->kaltura_video_visible = true;
	
	//the mini applet
	$ob->kaltura_video_widget_m_width = 250;
	$ob->kaltura_video_widget_m_height = 244;
	$ob->kaltura_video_widget_m_html = preg_replace(array('/width="([0-9]*)"/','/height="([0-9]*)"/'),array('width="250"','height="244"'),$ob->kaltura_video_widget_html);

	//the default date format
	
	if($ob->kaltura_video_time_created) $ob->kaltura_video_created = friendly_time($ob->kaltura_video_time_created);
	else $ob->kaltura_video_created = friendly_time($entity->time_created);

	return $ob;
}

//gets a kaltura object with all metadata from a kaltura id 
function kaltura_get_entity($video_id) {
	if(empty($video_id)) return false;
	
	$objs = get_entities_from_metadata('kaltura_video_id', $video_id, 'object');
	if($objs) {
		return get_entity($objs[0]->guid);
	}
	return false;
}

//creates or updates a kaltura object with all metadata
function kaltura_update_object($entry,$kaltura_service,$kaltura_user,$privacity=null,$user_guid=null,$container_guid=null,$force=false) {
	global $CONFIG;
	
	if(empty($entry['id'])) return false;
	
	if(!$user_guid && isloggedin()) {
		$user_guid = $_SESSION['user']->getGUID();
	}
	
	$ob = kaltura_get_entity($entry['id']);
	
	if($ob) {
		//for compatibility with older versions who do no have 'kaltura_video' in the suptype_id
		if($ob->subtype != get_subtype_id('object','kaltura_video')) {
			$ob->delete();
			$ob = new ElggObject();
			$ob->subtype = 'kaltura_video';
			$ob->owner_guid = $user_guid;
			$ob->save();
		}
	}
	elseif($user_guid) {
		$ob = new ElggObject();
		$ob->subtype = 'kaltura_video';
		$ob->owner_guid = $user_guid;
		$ob->container_guid = $container_guid;
		$ob->save();
	}
	else return false;
	
	$ob->kaltura_video_id = $entry['id'];
	//group perms
	$ob->kaltura_video_isgroup = 0;
	$ob->kaltura_video_group_visible = 0;
	
	//keep the current metada if exists (if not forced)...
	if($force || (empty($ob->title) && isset($entry['name']))) $ob->title = $entry['name'];
	if($force || (empty($ob->description) && isset($entry['description']))) $ob->description = $entry['description'];
	if($force || (empty($ob->tags) && isset($entry['tags']))) {
		$ob->clearMetadata('tags');
		if($array = string_to_tag_array($entry['tags'])) {
			foreach($array as $i => $arr) {
				$array[$i] = trim($arr);
			}
		}
		$ob->tags = $array;
	}
	
	if($entry['plays']) $ob->kaltura_video_plays = $entry['plays'];
	if($entry['lengthInMsecs']) $ob->kaltura_video_length = kaltura_parse_time($entry['lengthInMsecs']/1000);
	if($entry['showEntryId']) $ob->kaltura_video_kshow_id = $entry['showEntryId'];
	if($entry['thumbnailUrl']) $ob->kaltura_video_thumbnail = $entry['thumbnailUrl'];
	if($entry['showEntry']) $ob->kaltura_video_flv = $entry['showEntry']['dataUrl'];

	//for the rss
	if($entry['createdAtAsInt']) {
		$ob->kaltura_video_time_created = $entry['createdAtAsInt'];
		$ob->time_created = $entry['createdAtAsInt'];
		$ob->time_updated = $entry['createdAtAsInt'];
	}

	//set the privacity if is
	
	if(isset($privacity)) $ob->kaltura_video_privacity = $privacity;
	
	//save metadata
	$ob->save();


	$ob->access_id = ACCESS_PRIVATE; //private access
	
	$metadata = kaltura_get_metadata($ob);
	
	$group = get_entity($ob->container_guid);
	//privacity
	if($metadata->kaltura_video_privacity == 'loggedin') {
		$ob->access_id = ACCESS_LOGGED_IN;
	}
	if($metadata->kaltura_video_privacity == 'public') {
		$ob->access_id = ACCESS_PUBLIC;
	}
	if($metadata->kaltura_video_privacity == 'thisgroup') {
		
		if ($group instanceof ElggGroup) {
			$ob->kaltura_video_isgroup = 1;
			if($group->group_acl) {
				$ob->access_id = $group->group_acl;
				$ob->kaltura_video_group_visible = 1;
			}
		}
	}
	
	if ($group instanceof ElggGroup) {
		$ob->kaltura_video_isgroup = 1;
		if($ob->access_id) {
			$ob->kaltura_video_group_visible = 1;
		}
	}
	$ob->save();

	//for compatibility with older versions, will be removed. in the future
	if(empty($ob->title) && $metadata->kaltura_video_title) $ob->title = $metadata->kaltura_video_title;

	if(empty($metadata->kaltura_video_widget_id) && $kaltura_service && $kaltura_user) {
		//create the widget if needed
		$params = array("widget_kshowId"=>$entry['id']);
		$res = $kaltura_service->addwidget($kaltura_user,$params);
		if($widget = $res['result']['widget']['widgetHtml']) {
			//print_R($res);die;
			$ob->kaltura_video_widget_id = $res['result']['widget']['id'];
			$ob->kaltura_video_widget_uid = $res['result']['uiConfId'];
			$ob->kaltura_video_widget_width = $res['result']['widget']['width'];
			$ob->kaltura_video_widget_height = $res['result']['widget']['height'];
			$ob->kaltura_video_widget_html = $widget;
			$ob->save();
		}
	}

	return $ob;
}

function kaltura_parse_time($seconds,$complete=true) {
	$d = floor($seconds / (3600*24));
	$h = floor($seconds / 3600) - $d*24;
	$m = floor($seconds / 60) - $h*60 -$d*24*60;
	$s = $seconds % 60;
	//echo "\n[$d $h $m $s]\n";
	if($complete) {
		if(!empty($d)) return sprintf("%dd %d:%02d:%02d",$d,$h,$m,$s);
		elseif(!empty($h)) return sprintf("%d:%02d:%02d",$h,$m,$s);
		elseif(!empty($m)) return sprintf("%d:%02d",$m,$s);
		else return $s."s";
	}
	else {
		$ret = "";
		if(!empty($d)) {
			$ret .= sprintf("%dd %dh",$d,$h);
			if(!empty($m)) $ret .= sprintf(" %02dm",$m);
			if(!empty($s)) $ret .= sprintf(" %02ds",$s);
			return $ret;
		}
		elseif(!empty($h)) {
			$ret .= sprintf("%dh",$h);
			if(!empty($m)) $ret .= sprintf(" %02dm",$m);
			if(!empty($s)) $ret .= sprintf(" %02ds",$s);
			return $ret;
		}
		elseif(!empty($m)) {
			$ret .= sprintf("%dm",$m);
			if(!empty($s)) $ret .= sprintf(" %02ds",$s);
			return $ret;
		}
		else return $s."s";
	}
}

function kaltura_clean_chars($t) {
	$search=array("/Á|À|Ä|Â/","/á|à|ä|â/","/É|È|Ë|Ê/","/é|è|ë|ê/","/Í|Ì|Ï|Î/","/í|ì|ï|î/","/Ó|Ò|Ö|Ô/","/ó|ò|ö|ô/","/Ú|Ù|Ü|Û/","/ú|ù|ü|û/","/Ý/","/ý|ÿ/","/Ñ/","/ñ/","/Ç/","/ç/");
	$replace=array("A","a","E","e","I","i","O","o","U","u","Y","y","N","n","C","c");
	return preg_replace($search,$replace,$t);
}


function kaltura_build_widget_object($ob,$widget_html) {
	//echo htmlspecialchars(print_r($ob,true));
	
	preg_match('/width="([0-9]*)"/',$widget_html,$matches);
	$width = $matches[1];
	preg_match('/height="([0-9]*)"/',$widget_html,$matches);
	$height = $matches[1];
	preg_match('/id="([a-zA-Z0-9_-]*)"/',$widget_html,$matches);
	$id = $matches[1];
	preg_match('/data="([a-zA-Z0-9_\:\.\,\/-]*)"/',$widget_html,$matches);
	$swf = $matches[1];
	preg_match('/name="flashVars" value="([a-zA-Z0-9\%\ \&_\:\.\,\/-]*)"/',$widget_html,$matches);
	$flash_vars = $matches[1];
	
	if(empty($id)) $id = $ob->kaltura_video_id;
	
    $widget->id = $id;
    $widget->height = $height;
    $widget->width = $width;
    $widget->swf = $swf;
    $widget->flashvars = $flash_vars;
    $widget->thumbnail = $ob->kaltura_video_thumbnail;
    
    //echo '<br>'.nl2br(htmlspecialchars(print_r($widget,true)));die;
    
    return $widget;
    
}

function kaltura_get_error_page($code,$text = "",$popup=true) {
	global $CONFIG;
	$partner_id = get_plugin_setting('partner_id', 'kaltura_video');
	$subp_id = get_plugin_setting('subp_id', 'kaltura_video');
	$secret = get_plugin_setting('secret', 'kaltura_video');
	$admin_secret = get_plugin_setting('admin_secret', 'kaltura_video');

	$title = elgg_echo('kalturavideo:error:misconfigured');
	
	$ret = '';
	$ret .= '<div class="kalturaError">';
	$ret .= "<h2>$title</h2>";
	
	//typic error when not configured
	if(empty($partner_id) || empty($subp_id) || empty($secret) || empty($admin_secret)) {
		echo "$partner_id,$subp_id,$secret,$admin_secret";
		$title = elgg_echo('kalturavideo:error:notconfigured');
		$text = elgg_echo('kalturavideo:error:readme');
	}
	elseif($code == 'MISSING_KS') {
		$text .= '<br /><br />'.elgg_echo('kalturavideo:error:missingks');
	}
	elseif($code == 'UNKNOWN_PARTNER_ID') {
		$text .= '<br /><br />'.elgg_echo('kalturavideo:error:partnerid');
	}
	elseif(empty($code) && empty($text)) {
		
		$text = "<strong>Kaltura Connection Failed!</strong> Check your internet connection and the availability of kaltura's site.";
		
		$ret .= '<p><br />'.nl2br($text).'</p>';
		
		if($popup) {
			$ret .= '<p><a href="#" class="kalturaButton" onclick="finished(0)">'.elgg_echo('kalturavideo:label:closewindow').'</a></p>';
		}
		$ret .= '</div>';
		return $ret;
	}
	
	$ret .= '<p><br />'.nl2br($text).'</p>';
	if($popup) {
		if(!empty($code)) $ret .= '<p>'.elgg_echo('kalturavideo:label:gotoconfig').' <a href="#" onclick="gotoadmin()">'.elgg_echo('kalturavideo:label:toolsadmin').'</a></p>';
		$ret .= '<p><a href="#" class="kalturaButton" onclick="finished(0)">'.elgg_echo('kalturavideo:label:closewindow').'</a></p>';
	}
	else {
		$ret .= '<p>'.elgg_echo('kalturavideo:label:gotoconfig').' <a href="'.$CONFIG->wwwroot.'pg/admin/plugins/">'.elgg_echo('kalturavideo:label:toolsadmin').'</a></p>';
	}
	
	$ret .= '</div>';
	return $ret;
}


// 
function kaltura_create_generic_widget_html ( $kshow_id , $size='l' , $version=null , $version_kshow_name=null , $version_kshow_description=null)
{
	global $WIDGET_HOST;
	if(empty($kshow_id)) return "Error kshow_id: $kshow_id";

	$external_url = "";
     // add the version as an additional parameter
	$domain = $WIDGET_HOST; //"http://www.kaltura.com";
	//use of cms widget
	$swf_url = "/index.php/widget/$kshow_id/" . 
		( $entry_id ? $entry_id : "-1" ) . "/" .
		( $media_type ? $media_type : "-1" ) . "/" .
		( $widget_type ? $widget_type : "1" ) . "/" . // widget_type=3 -> WIKIA
		( $version ? "$version" : "-1" );

    if ( $size == "m")
    {
    	// medium size
    	$height = 201 + 20;
    	$width = 268;
    }
    else
    {
    	// large size "410", "364"
    	$height = 300 + 20;
    	$width = 400;

    }
    $str = "";//$extra_links ; //"";

    $links_arr = array (
    	//"base" => "$external_url/" , 
    	//"add" =>  "Special:KalturaContributionWizard?kshow_id=$kshow_id" ,
    	//"edit" => "Special:KalturaVideoEditor?kshow_id=$kshow_id" ,
    	//"share" => $share ,
    );

    $links_str = str_replace ( array ( "|" , "/") , array ( "|01" , "|02" ) , base64_encode ( serialize ( $links_arr ) ) ) ;

    $flash_vars = array (
	// "CW" => "gotoCW" ,
	//"Edit" => "gotoEdit" ,
	//"Editor" => "gotoEditor" ,
	//"Kaltura" => "",//gotoKalturaArticle" ,
	//"Generate" => "" , //gotoGenerate" ,
	"share" => "" , //$share ,
	"WidgetSize" => $size
    );

    // add only if not null
    if ( $version_kshow_name ) $flash_vars["Title"] = $version_kshow_name;
    if ( $version_kshow_description ) $flash_vars["Description"] = $version_kshow_description;

    $swf_url .= "/" . $links_str;
    $flash_vars_str = http_build_query( $flash_vars , "" , "&" );

	//black player
    $widget = 	 '<object id="kaltura_player_' . $kshow_id . '" type="application/x-shockwave-flash" allowScriptAccess="always" allowNetworking="all" height="' . $height . '" width="' . $width . '" data="'.$domain. $swf_url . '">'.
		'<param name="allowScriptAccess" value="always" />'.
		'<param name="allowNetworking" value="all" />'.
		'<param name="bgcolor" value=#000000 />'.
		'<param name="movie" value="'.$domain. $swf_url . '"/>'.
		'<param name="flashVars" value="' . $flash_vars_str . '"/>'.
		'<param name="wmode" value="opaque"/>'.
	'</object>';
	
	/*
	 * 
<object type="application/x-shockwave-flash" width="425" height="375" data="http://openserver.cccb.org/embed/1152.swf"><param name="movie" value="http://openserver.cccb.org/embed/1152.swf"></param></object>
	* 
	 * */

	$str .= $widget;

	return $str ;
}


function kaltura_view_select_privacity($video_id,$current_privacity,$group_mode=false,$collaborative=false) {
	$ret = '<select class="ajaxprivacity" name="public_status['.$video_id.']" rel="'.$video_id.'">';
    
	$ret .= '<option value="me"';
	if ($current_privacity == 'me') $ret .= ' selected="yes"'; 
	$ret .= '>' . elgg_echo("kalturavideo:private:me").'</option>';
    
	
	if($group_mode) {
		$ret .= '<option value="thisgroup"';
		if ($current_privacity == 'thisgroup') $ret .= ' selected="yes"';
		$ret .= '>' . elgg_echo("kalturavideo:private:thisgroup").'</option>';
	}
	else {
		$ret .= '<option value="friends"';
		if ($current_privacity == 'friends') $ret .= ' selected="yes"';
		$ret .= '>' . elgg_echo("kalturavideo:private:friends").'</option>';
	}
	$ret .= '<option value="loggedin"';
	if ($current_privacity == 'loggedin') $ret .= ' selected="yes"';
	$ret .= '>' . elgg_echo("kalturavideo:private:loggedin").'</option>';
	
	$ret .= '<option value="public"';
	if ($current_privacity == 'public') $ret .= ' selected="yes"';
	$ret .= '>' . elgg_echo("kalturavideo:private:public").'</option>';
	
	$ret .= '</select>';
	
	if($group_mode) {
		$label = elgg_echo("kalturavideo:text:collaborative");
		$label2 = '<span title="'.htmlspecialchars($label).'">'.elgg_echo("kalturavideo:label:collaborative").'</span>';
		$ret .= ' 
		&nbsp; <label><input class="input-checkboxes collaborative" type="checkbox" title="'.htmlspecialchars($label).'" name="kaltura_video_collaborative" value="'.$video_id.'"'.($collaborative?' checked="checked"':'').' />'.$label2.'</label>';
	}
	
	return $ret;
}


?>
