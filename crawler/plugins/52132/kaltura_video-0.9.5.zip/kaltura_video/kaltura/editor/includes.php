<?php
require_once(dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "/engine/start.php");

global $secret,$ks,$partner_id,$subp_id;
global $CONFIG;
global $KALTURA_DEFAULT_VIDEOTITLE;
global $KALTURA_DEFAULT_USERPREFIX;

$partner_id = get_plugin_setting('partner_id', 'kaltura_video');
$subp_id = get_plugin_setting('subp_id', 'kaltura_video');
$secret = get_plugin_setting('secret', 'kaltura_video');
$admin_secret = get_plugin_setting('admin_secret', 'kaltura_video');

$prefix = get_plugin_setting('uid_prefix', 'kaltura_video');
if (!$prefix) $prefix = $KALTURA_DEFAULT_USERPREFIX;

$uid = $prefix.$_SESSION['user']->username;

$name = (empty($_SESSION['user']->name)?$_SESSION['user']->username:$_SESSION['user']->name);

$username = $name;

$title = get_plugin_setting('videotitle', 'kaltura_video');
if (!$title) $title = $KALTURA_DEFAULT_VIDEOTITLE;

$kshow_name = $title;
//$kshow_description = elgg_echo('kalturavideo:descprefix:video')." $name";
$kshow_description = ''; //no description by default

$label_elggurl = $CONFIG->wwwroot;

if(isset($_REQUEST['kshow_id'])) $kshow_id = $_REQUEST['kshow_id'];
if(isset($_REQUEST['thumbnail'])) $thumbnail = $_REQUEST['thumbnail'];

require_once ( "kalturaapi_php5_lib.php");
require_once ( "kaltura_helpers.php");

header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT"); // Date in the past

?>
