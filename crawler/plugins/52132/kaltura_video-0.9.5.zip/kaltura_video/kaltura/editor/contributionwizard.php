<?php
require_once ( "includes.php" );
gatekeeper();
	
$kaltura_user = new kalturaUser();
$kaltura_user->puser_id = $uid;
$kaltura_user->puser_name = $username;

$kaltura_service = kalturaService::getInstance( $kaltura_user );


//I don't know the reason but kaltura don't allow non-ascii characters in kshow_name
$params = array
	(
		"kshow_name" => kaltura_clean_chars($kshow_name),
		"kshow_description" => kaltura_clean_chars($kshow_description)
	);


//init the new video
$res = $kaltura_service->addkshow ( $kaltura_user , $params );
$kshow = @$res["result"]["kshow"];
//print_R($kshow);print_r($uid);die;
if ( !$kshow ) {
	// TODO - handle fatal error
	$error = "Error Code: ".$res['error'][0]['code']."\n";
	$error .= "Error Code: ".$res['error'][0]['desc'];
}
else {
	$kshow_id = $kshow["id"];
}

$ks = $kaltura_service->getKs();

if($error) {
	echo kaltura_get_error_page($res['error'][0]['code'],$error);
	die;
}
else {
	$user_guid = $_SESSION['user']->getGUID();
	$container_guid = $user_guid;
	if($page_owner = page_owner_entity()) {
		if($page_owner instanceof ElggGroup) {
			$user_guid = $_SESSION['user']->getGUID();
			$container_guid = $page_owner->getGUID();
		}
	}
	
	
	//create the elgg object
	kaltura_update_object(array("id"=>$kshow_id),null,null,null,$user_guid,$container_guid);
	
	$domain = $WIDGET_HOST;
	if ( strpos ( $domain , "localhost"  ) !== false ) $host = 2;
	elseif ( strpos ( $domain , "kaldev" ) !== false ) $host = 0;
	else $host = 1;

	$swf_url = "/swf/ContributionWizard.swf";
		
	$lang = $_SESSION['user']->language;
	$height = 360;
	$width = 680;
	$flashvars = 'userId=' . $uid .
		'&sessionId=' . $ks.
		'&partnerId=' . $partner_id .
		'&subPartnerId=' . $subp_id .
		'&kshow_id=' . $kshow_id .
		'&host=' . $host . //$domain; it's an enum
		'&afterAddentry=editVideo' .
		'&close=deleteVideo' .
		'&lang=' . $lang .
		'&terms_of_use=http://www.kaltura.com/index.php/static/tandc' ;

	$widget = '<object id="kaltura_contribution_wizard" type="application/x-shockwave-flash" allowScriptAccess="always" allowNetworking="all" height="' . $height . '" width="' . $width . '" data="'.$domain. $swf_url . '">'.
		'<param name="allowScriptAccess" value="always" />'.
		'<param name="allowNetworking" value="all" />'.
		'<param name="bgcolor" value=#000000 />'.
		'<param name="movie" value="'.$domain. $swf_url . '"/>'.
    		'<param name="flashVars" value="' . $flashvars . '" />' .
	'</object>';
			
	echo $widget;
}
?>
<script type='text/javascript'>

var ks = '<?php echo $ks; ?>';
var kshow_id = '<?php echo $kshow_id; ?>';

</script>
