<?php
require_once ( "includes.php" );
gatekeeper();

?><html>
<head>
<script type="text/javascript" src="../../../../vendors/jquery/jquery-1.2.6.pack.js"></script>
<link rel="stylesheet" type="text/css" href="./kaltura.css"/>

<style type="text/css">
	#loading {
		height:100%;
		width:100%;
		background:url(images/loadingAnimation.gif) no-repeat center center;
	}
</style>
<script type='text/javascript' src="../js/kaltura.js"></script>
<script type='text/javascript'>
/* <![CDATA[ */

var ks = '';
var kshow_id = '';
var thumb = '';
var widget_html = '';
var widget_html_l = '';
var widget_html_m = '';
var obj = {};
var obj_l = {};
var obj_m = {};

function loadGallery(page) {
	
	var url = 'gallery.php?<?php echo (empty($_REQUEST['type'])?'':'type='.$_REQUEST['type'].'&'); ?>page=';
	if(page) url += page;

	$('#loading').html('<div id="flash-container"></div>');
	$('#flash-container').load(url,function(){
		cwWidth = 660;
		cwHeight = 580;
		var topWindow = Kaltura.getTopWindow();
		
		// fix for IE6, scroll the page up so modal would animate in the center of the window
		if (jQuery.browser.msie && jQuery.browser.version < 7)
			topWindow.scrollTo(0,0);

		topWindow.Kaltura.animateModalSize(cwWidth, cwHeight);
		
		$('a.insert').click(function(){
			kshow_id = $(this).attr('rel');
			thumb = $(this).parent().prev().attr('src');
			addentry();
			return false;
		});
		$('a.edit').click(function(){
			kshow_id = $(this).attr('rel');
			thumb = $(this).parent().prev().attr('src');
			editVideo();
			return false;
		});
		$('a.next,a.prev').click(function(){
			loadGallery($(this).attr('rel'));
		});
		$('a.new').click(function(){
			loadNew();
		});
		$('a.cancel').click(function(){
			finished(0);
		});
	});
}
function loadNew() {
	$('#loading').html('<div id="flash-container"></div>');
	$('#flash-container').load('contributionwizard.php',{username:'<?php echo get_input("new",''); ?>'},function(){
		cwWidth = 680;
		cwHeight = 360;
		var topWindow = Kaltura.getTopWindow();

		// fix for IE6, scroll the page up so modal would animate in the center of the window
		if (jQuery.browser.msie && jQuery.browser.version < 7)
			topWindow.scrollTo(0,0);

		topWindow.Kaltura.animateModalSize(cwWidth, cwHeight);
	});
}
function editVideo() {
	var url = 'editor.php?';
	if(kshow_id) url += 'kshow_id='+kshow_id;
	if(thumb) url += '&thumbnail='+escape(thumb);
	
	
	//hide the flash movie
	$('#flash-container').hide();

	//open the editor window
	$('#flash-container').load(url,function(){
		$('#flash-container').show();
		cwWidth = 890;
		cwHeight = 546;
		var topWindow = Kaltura.getTopWindow();

		// fix for IE6, scroll the page up so modal would animate in the center of the window
		if (jQuery.browser.msie && jQuery.browser.version < 7)
			topWindow.scrollTo(0,0);

		topWindow.Kaltura.animateModalSize(cwWidth, cwHeight);
	});
}
function deleteVideo() {
	if(kshow_id) {
		var url = '../../ajax-update.php?delete_kshow_id='+kshow_id;
		$('#loading').html('<div id="flash-container"></div>');
		$('#flash-container').load(url,function(data){
			var topWindow = Kaltura.getTopWindow();
			topWindow.KalturaModal.closeModal();
		});
	}
	else {
		var topWindow = Kaltura.getTopWindow();
		topWindow.KalturaModal.closeModal();
	}
}

function onEditorSave () {
<?php
if(empty($_REQUEST['kshow_id']) && !isset($_REQUEST['new'])) {
?>
	//addentry();
	loadGallery(1);
<?php
}
else {
?>
	finished(2);
<?php
}
?>

}
function onEditorBack () {
<?php
if(empty($_REQUEST['kshow_id']) && !isset($_REQUEST['new'])) {
?>
	//addentry();
	loadGallery(1);
<?php
}
else {
?>
	finished(3);
<?php
}
?>
}

function addentry ()
{
	var url = 'video_options.php?';
	if(kshow_id) url += 'kshow_id='+kshow_id;
	if(thumb) url += '&thumbnail='+escape(thumb);
	

<?php
if(isset($_REQUEST['new'])) {
?>
	editVideo();
	return;
<?php
}
?>

	$('#loading').html('<div id="flash-container"></div>');	
	$('#flash-container').load(url,function(){
		cwWidth = 600;
		cwHeight = 300;
		var topWindow = Kaltura.getTopWindow();

		// fix for IE6, scroll the page up so modal would animate in the center of the window
		if (jQuery.browser.msie && jQuery.browser.version < 7)
			topWindow.scrollTo(0,0);

		topWindow.Kaltura.animateModalSize(cwWidth, cwHeight);

		$('#finishVideo').click(function(){
			//put the correct widget and exit
			if($('#sizem').get(0).checked) {
				widget_html = widget_html_m;
				obj = obj_m;
			}
			else {
				widget_html = widget_html_l;
				obj = obj_l;
			}
			finished( '1' );
		});
		$('#editVideo').click(function(){
			editVideo();
		});
		$('#cancel').click(function(){
			finished('0');
		});
		$('#gallery').click(function(){
			loadGallery(1);
		});
	});
}

function finished ( modified )
{
	var topWindow = Kaltura.getTopWindow();
	
	if ( modified == 0 ) {
		topWindow.KalturaModal.closeModal();
	}
	else if ( modified > 1 ) {
	//in this case we try to update the image from opener and close the modal

        //hide the flash movie
        $('#flash-container').hide();
        

        cwWidth = 240;
        cwHeight = 60;
        topWindow.Kaltura.animateModalSize(cwWidth, cwHeight);

        $.get("../../ajax-update.php",{update_plays:kshow_id},function(){

	        //topWindow.KalturaModal.closeModal();
    	    // close the modal crashes safari and Firefox 2,
<?php
	// check if it's a new video
	if (isset($_REQUEST['new'])) {
		// check if we're on a group page
		if ($new = get_input('new', 0)) {
			$new = explode(':', $new);
			$page_owner = get_entity($new[1]);
			//go to the group video list if is a group video
			if ($page_owner instanceof ElggGroup)
				$refresh_loc = $CONFIG->wwwroot."/pg/kaltura_video/groups/group:{$new[1]}";
				//go to the personal video list if not
		} else
			$refresh_loc = $CONFIG->wwwroot."/pg/kaltura_video/";

		echo "\ntopWindow.location =  '$refresh_loc';\n";
	}
	//remains in the same page if whe are editing the video
	else echo "\ntopWindow.location.reload();\n";
?>
        });
	}
	else {
		
	    try {
		//update the tinymce!!!
			var cont = '<img style="width: ' + obj.width + 'px; height: ' + obj.height + 'px;" title="src:\'' + obj.swf + '\',width:\'' + obj.width + '\',height:\'' + obj.height + '\',thumbnail:\'' + obj.thumbnail + '\'" class="mceItemKaltura" src="' + obj.thumbnail + '" align="" width="' + obj.width + '" height="' + obj.height + '">';
			topWindow.tinyMCE.activeEditor.execCommand('mceReplaceContent', false, cont); 
	    }
	    catch(e) {
			//if tinymce is not active we will put the content as html
			var current_value = topWindow.KalturaTextArea.attr('value');
			topWindow.KalturaTextArea.attr('value',current_value+"\n"+widget_html);
	    }
	    topWindow.KalturaModal.closeModal();
	}
	return;
}
function gotoadmin() {
	var url = '<?php echo $CONFIG->wwwroot.'pg/admin/plugins/'; ?>';
	var topWindow = Kaltura.getTopWindow();
	topWindow.KalturaModal.closeModal();
	topWindow.location = url;
}

//at start
$(document).ready(function() {
<?php
if(isset($_REQUEST['new'])) {
?>
	loadNew();
<?php
}
elseif(empty($_REQUEST['kshow_id'])) {
?>
	loadGallery(1);
<?php
}
else {
?>
	kshow_id = '<?php echo $kshow_id; ?>';
	thumb = '<?php echo $thumbnail; ?>';
	editVideo();
<?php
}
?>
});

/* ]]> */
</script>
</head>
<body>
<div id="loading">
	<div id="flash-container"></div>
</div>
</body>
</html>
