<?php
require_once ( "includes.php" );
gatekeeper();

if(!empty($_REQUEST['kshow_id'])) $kshow_id = $_REQUEST['kshow_id'];

//check if user is allowed to edit this video


$kaltura_user = new kalturaUser();

$ob = kaltura_get_entity($kshow_id);
$metadata = kaltura_get_metadata($ob);
if($metadata->kaltura_video_cancollaborate) {
	if($uob = get_user($ob->owner_guid)) {
		$uid = $prefix.$uob->username;
	}
}

$kaltura_user->puser_id = $uid;
$kaltura_user->puser_name = $username;

$domain = $SERVER_HOST;

if ( ! $ks )
{
	$kaltura_service = kalturaService::getInstance( $kaltura_user );
	$ks = $kaltura_service->getKs();
}

$width = 890;
$height = 546;

$editor_params = array(
	"partner_id" => $partner_id ,
	"subp_id" => $subp_id ,
	"uid" => $uid ,
	"ks" => $ks ,
	"kshow_id" => $kshow_id,
	"saveF" => 'onEditorSave',
	"backF" => 'onEditorBack'
);
$res = $kaltura_service->getkshow ( $kaltura_user , $editor_params );

if ( $res['error'][0]['code'] ) {
	$error = "Error Code: ".$res['error'][0]['code']."\n";
	$error .= "Error Code: ".$res['error'][0]['desc'];
}


if($metadata->kaltura_video_cancollaborate || $metadata->kaltura_video_editable) {
	//create the widget if not exists
	kaltura_update_object(array("id"=>$kshow_id),$kaltura_service,$kaltura_user);
}
else {
	$error = elgg_echo('kalturavideo:edit:notallowed');
}
if($error) {
	echo kaltura_get_error_page($res['error'][0]['code'],$error);
	die;
}

$flashvars = http_build_query( $editor_params , '' , "&" );

$swf_url = "/swf/simpleeditor.swf";

$editor = '<object id="kaltura_contribution_wizard" type="application/x-shockwave-flash" allowScriptAccess="always" allowNetworking="all" height="' . $height . '" width="' . $width . '" data="'.$domain. $swf_url . '">'.
	'<param name="allowScriptAccess" value="always" />'.
	'<param name="allowNetworking" value="all" />'.
	'<param name="bgcolor" value=#000000 />'.
	'<param name="movie" value="'.$domain. $swf_url . '"/>'.
	'<param name="flashVars" value="' . $flashvars . '" />' .
'</object>';
		
echo $editor;
?>
