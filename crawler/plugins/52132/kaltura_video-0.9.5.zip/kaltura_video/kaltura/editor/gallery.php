<?php
require_once ( "includes.php" );
gatekeeper();

$type = $_REQUEST['type'];

$limit = get_input('limit', 8);
$page = get_input('page',1);

$offset = ($page-1) * $limit;

$object_label = "kaltura_video";
$owner_id = kaltura_get_owner_id_from_type($type);

$wrapped_entries = array();

if(empty($type)) {
 	
	$count = (int) count_user_objects($_SESSION['user']->getGUID(), 'kaltura_video');
	$result = get_user_objects($_SESSION['user']->getGUID(),'kaltura_video', $limit, $offset);
	
}
else {
	global $is_admin;
	$is_admin = true;
	
	$result = get_entities_from_metadata("kaltura_video_privacity",$type,'object',$object_label,$owner_id,$limit,$offset,"owner_guid ASC");
	$count = get_entities_from_metadata("kaltura_video_privacity",$type,'object',$object_label,$owner_id,null,null,"",0,true);
}
if($result) {
	foreach($result as $ob) {
		$metadata = kaltura_get_metadata($ob);
		$wrapped_entries[] = array($ob,$metadata);
	}
	//back to the initial status of admin
	if(!isadminloggedin()) $is_admin = false;
}


echo '<div class="box">';
//echo '<h2>'.elgg_echo('kalturavideo:label:gallery').": ";
echo '<h2 style="height:40px;">';
if($type=='') echo elgg_echo('kalturavideo:label:myvideos');
else echo '<a href="init.php" class="kalturaButton">'.elgg_echo('kalturavideo:label:myvideos').'</a>';
	
if($type=='friends') echo ' '.elgg_echo('kalturavideo:label:friendsvideos');
else echo ' <a href="init.php?type=friends" class="kalturaButton">'.elgg_echo('kalturavideo:label:friendsvideos').'</a>';
if($type=='public') echo ' '.elgg_echo('kalturavideo:label:allvideos');
else echo ' <a href="init.php?type=public" class="kalturaButton">'.elgg_echo('kalturavideo:label:allvideos').'</a>';
//echo '</h2>';
echo '</h2>';

echo '<div class="gallery">';

if(count($wrapped_entries)>0) {
	//echo '<pre>'.print_R($wrapped_entries,true).'</pre>';die;
	foreach($wrapped_entries as $entry) {
		echo '<div class="galleryItem">';
		echo '<label>'.$entry[1]->kaltura_video_created.'</label>';
		echo '<img src="'.$entry[1]->kaltura_video_thumbnail.'" alt="'.htmlspecialchars($entry[0]->title).'" title="'.htmlspecialchars($entry[0]->title).'" />';

		echo '<div><a href="'.$CONFIG->wwwroot.'pg/kaltura_video/show/'.$entry[0]->guid.'" rel="'.$entry[1]->kaltura_video_id.'" class="button1 insert">'.elgg_echo('kalturavideo:label:miniinsert').'</a>';
		if($entry[1]->kaltura_video_editable) {
			echo '<a href="'.$CONFIG->wwwroot.'pg/kaltura_video/show/'.$entry[0]->guid.'" rel="'.$entry[1]->kaltura_video_id.'" class="button2 edit">'.elgg_echo('kalturavideo:label:miniedit').'</a>';
		}
		echo '</div></div>';
	}
}
else {
	echo '<h3>';
	if($type == 'friends') {
		echo elgg_echo("kalturavideo:text:nofriendsvideos");
	}
	elseif($type == 'public') {
		echo elgg_echo("kalturavideo:text:nopublicvideos");
	}
	else {
		echo elgg_echo("kalturavideo:text:novideos");
	}
	echo '</h3>';
}

	echo '<div class="clear"></div>';
	echo '</div>';
	echo '<div class="left"><p>';
	echo '<a href="#" class="kalturaButton cancel">'.elgg_echo('kalturavideo:label:cancel').'</a> &nbsp; ';
	echo '<a href="#" class="kalturaButton new">'.elgg_echo('kalturavideo:label:newvideo').'</a>';
	echo '</p></div>';
	echo '<div class="right"><p>';
	if($page > 1) {
		echo '<a href="#" rel="1" class="kalturaButton prev">'.elgg_echo('kalturavideo:label:start').'</a> &nbsp; ';
		echo '<a href="#" rel="'.($page-1).'" class="kalturaButton prev">'.elgg_echo('kalturavideo:label:prev').'</a> &nbsp; ';
	}
	if($page < ceil($count/$limit)) echo '<a href="#" rel="'.($page+1).'" class="kalturaButton next">'.elgg_echo('kalturavideo:label:next').'</a>';
	echo '</p></div>';
	echo '<div class="clear"></div>';
	echo '</div>';
?>
