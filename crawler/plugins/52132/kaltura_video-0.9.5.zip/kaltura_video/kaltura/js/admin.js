OLD_HTML = '';
KALTURA_VIDEO_MODAL = false;
//CURRENT_GROUP = ''; //now is setup in jscripts.php
function Kaltura_button_init() {
	//edit videos
	$('.kalturavideoitem a.edit,.kalturaviewer a.edit').click(function(){
		cancelCurrentEdit();
		var id = $(this).attr('rel');
		var thumb = $(this).attr('href');
		KalturaModal.openModal("TB_window", "{URL}kaltura/editor/init.php?kshow_id="+id+"&thumbnail="+thumb, { width: 240, height: 60 } );
		return false;
	});
	//delete videos
	$('.kalturavideoitem a.delete,.kalturaviewer a.delete').click(function(){
		var id = $(this).attr('rel');
		return confirm('{SURETODELETE}');
	});
	//update status
	$('select.ajaxprivacity').change(function(){
		var id = $(this).attr('rel');
		var privacity = $(this).val();

		$.get("{URL}ajax-update.php",{
				id : id,
				privacity : privacity
			},
			function(data){
				window.location.reload();
			}
		);
	});
	//check/uncheck collaborative editing
	$('input.collaborative').click(function() {
		var id = $(this).val();
		var collaborative = $(this).attr('checked')?'yes':'no';
		$.get("{URL}ajax-update.php",{
				id : id,
				collaborative : collaborative
			},
			function(data){
				window.location.reload();
			}
		);
	});
	
	//show details of a video
	$('.kalturaviewer a.showdetails').click(function(){
		cancelCurrentEdit();
		if($('.kalturaviewer .kaltura_video_details').is(':visible')) {
			$(this).html('{SHOWADV}');
			$('.kalturaviewer .kaltura_video_details').slideUp();
		}
		else {
			$(this).html('{HIDEADV}');
			$('.kalturaviewer .kaltura_video_details input').focus(function(){
				$(this).select();
				return false;
			});
			$('.kalturaviewer .kaltura_video_details input').keypress(function(e){
				$(this).select();
				if(e.keyCode == 9) return true;
				return false;
			});
			$('.kalturaviewer .kaltura_video_details input').mousedown(function(){
				$(this).select();
				return false;
			});
			$('.kalturaviewer .kaltura_video_details').slideDown();
		}
		return false;
	});
	
	//edit details (metadata) of a video
	$('.kalturavideoitem a.metadata,.kalturaviewer a.metadata').click(handleEditDetail);
	
}

CURRENT_EDIT = '';
function handleEditDetail() {
	if($(this).hasClass('editing')) {
		return false;
	}
	cancelCurrentEdit();
	$(this).addClass('editing');
	var id = $(this).attr('rel');
	CURRENT_EDIT = id;
	KalturaModal.openModal("TB_window", "{URL}ajax-detail-editor.php?id="+id, { width: 240, height: 60 });
	
	return false;		
}
function cancelCurrentEdit() {
	if(CURRENT_EDIT) {
		$('.kalturavideoitem a.metadata,.kalturaviewer a.metadata').removeClass('editing');
		CURRENT_EDIT = '';
		KalturaModal.closeModal();
	}
}
function closeCurrentEdit() {
	if(CURRENT_EDIT) {
		$('.kalturavideoitem a.metadata,.kalturaviewer a.metadata').removeClass('editing');
		CURRENT_EDIT = '';
		KalturaModal.closeModal();
		location.reload()
	}
}

function Kaltura_ajax_button_init() {
	$('.kalturaviewer a.returnindex').click(function(){
		$('#kaltura_container').html(OLD_HTML);
		Kaltura_button_init();
		return false;
	});
	Kaltura_button_init();
}

function Kaltura_modal_button_init() {
	//Cancel button
	$('.kaltura_detail_editor input[type="submit"]:eq(1)').click(function(){
		var topWindow = Kaltura.getTopWindow();
		topWindow.cancelCurrentEdit();
		return false;
	});
}

$(document).ready(function () {
	//list video button actions
	Kaltura_button_init();
	
	//init the new video menu
	$('a[href="#kaltura_create"]').click(function(){
		
		var url = "{URL}kaltura/editor/init.php?new";
		
		if(CURRENT_GROUP) {
			url += "=" + escape(CURRENT_GROUP);
		}
		//alert(url)
		KalturaModal.openModal("TB_window", url, { width: 240, height: 60 } );
		return false;
	});
	//the recreate button
	$('a[href=#kaltura_recreateobjects]').click(function(){
		if(confirm('{SURETORECREATE}')) {
			location = '{URL}../../pg/kaltura_video/recreateobjects/';
		}
		return false;
	});
	
	//try to update the plays by ajax (to speed up the contact process with kaltura)
	$('.ajax_play').each(function(){
		var old = $(this).html();
		$(this).load("{URL}ajax-update.php?update_plays="+$(this).attr('rel'),function(data){
			if(!(data)) $(this).html(old)
		});
		
	});
	//if is the modal detail editor
	if(KALTURA_VIDEO_MODAL) {
		Kaltura_modal_button_init();
		var topWindow = Kaltura.getTopWindow();
		cwWidth = 660;
		cwHeight = 510;

		// fix for IE6, scroll the page up so modal would animate in the center of the window
		if (jQuery.browser.msie && jQuery.browser.version < 7)
			topWindow.scrollTo(0,0);

		topWindow.Kaltura.animateModalSize(cwWidth, cwHeight);
	}
});
