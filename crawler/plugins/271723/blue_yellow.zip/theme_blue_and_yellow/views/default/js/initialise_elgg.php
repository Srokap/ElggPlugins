jQuery.create = function() {
    if (arguments.length == 0) return [];
    var args = arguments[0] || {}, elem = null, elements = null;
    var siblings = null;

    // In case someone passes in a null object,
    // assume that they want an empty string.
    if (args == null) args = "";
    if (args.constructor == String) {
        if (arguments.length > 1) {
            var attributes = arguments[1];
                if (attributes.constructor == String) {
                            elem = document.createTextNode(args);
                            elements = [];
                            elements.push(elem);
                            siblings =
        jQuery.create.apply(null, Array.prototype.slice.call(arguments, 1));
                            elements = elements.concat(siblings);
                            return elements;

                    } else {
                            elem = document.createElement(args);

                            // Set element attributes.
                            var attributes = arguments[1];
                            for (var attr in attributes)
                                jQuery(elem).attr(attr, attributes[attr]);

                            // Add children of this element.
                            var children = arguments[2];
                            children = jQuery.create.apply(null, children);
                            jQuery(elem).append(children);

                            // If there are more siblings, render those too.
                            if (arguments.length > 3) {
                                    siblings =
        jQuery.create.apply(null, Array.prototype.slice.call(arguments, 3));
                                    return [elem].concat(siblings);
                            }
                            return elem;
                    }
            } else return document.createTextNode(args);
      } else {
              elements = [];
              elements.push(args);
              siblings =
        jQuery.create.apply(null, (Array.prototype.slice.call(arguments, 1)));
              elements = elements.concat(siblings);
              return elements;
      }
};

/**
 * FontEffect - jQuery plugin for font effect
 *
 * @author Alessandro Uliana (fonteffect@iofo.it)
 *
 * Dual licensed under the MIT and GPL licenses:
 * http://www.opensource.org/licenses/mit-license.php
 * http://www.gnu.org/licenses/gpl.html
 *
 * Demo and examples on
 * http://www.iofo.it/jquery/fonteffect/
 *
 * @requires jQuery v1.3.2
 * @version: 1.0.0 - 30/3/2009
 */
(function($){
    //* Global Variables *************************************************************
    var FE={};
    FE.divcounter=0; // div counter for debug
    //* Tabella posizioni layer *************************************************************
    FE.tabpos = ["", "0001021020212212", "00010203041020304041424344142434", "000102030405061020304050606162636465162636465666"];
    //* Most common typeface(from http: //www.codestyle.org/css/font-family/index.shtml) **********
    FE.font = {
        serif:       "Georgia, 'Times New Roman', 'Century Schoolbook L', serif",
        sans_serif:  "Verdana, Helvetica, Arial, 'URW Gothic L', sans-serif",
        monospace:   "'Courier New', Courier, 'DejaVu Sans Mono', monospace",
        fantasy:     "Impact, Papyrus, fantasy",
        cursive:     "'Comic Sans MS' cursive"
        };
    //* Main Function *******************************************************************************
    $.fn.FontEffect = function(o){
        //* Defaults *********************************************************************
        var d = $.extend({
            outline             :false,
            outlineColor1       :"",
            outlineColor2       :"",
            outlineWeight       :1,    // 1=light, 2=normal, 3=bold
            mirror              :false,
            mirrorColor         :"#000",
            mirrorOffset        :-10,
            mirrorHeight        :50,
            mirrorDetail        :1,    // 1=high, 2=medium, 3=low
            mirrorTLength       :50,
            mirrorTStart        :0.2,
            shadow              :false,
            shadowColor         :"#aaa",
            shadowOffsetTop     :5,
            shadowOffsetLeft    :5,
            shadowBlur          :1,    // 1=none, 2=low, 3=high
            shadowOpacity       :0.1,
            gradient            :false,
            gradientColor       :"",
            gradientFromTop     :true,
            gradientPosition    :20,
            gradientLength      :50,
            gradientSteps       :20,
            proportional        :false,
            hideText            :false,
            debug               :false
        },  o);
        //* Main Loop ********************************************************************
        this.not(".JQFE").each(function(){
            //* Check and correct options ********************************************************************
            if(!d.outline &&
                !d.shadow  &&
                !d.mirror  &&
                !d.gradient) {d.outline=true;};
            if(d.outline){
                if(d.outlineColor1 == "" && d.outlineColor2 == ""){
                    d.outlineColor1=pickcontrast($(this).css("color"));
                    };
                if(d.outlineColor2 == "") d.outlineColor2=d.outlineColor1;
                };
            if(d.gradient && d.gradientColor == ""){d.gradientColor=pickcontrast($(this).css("color"));};
            //* get the element display option and change to inline ********************************************************************
            var userdisplay=$(this).css("display");
            var userposition=$(this).css("position");
            $(this).css({
                display: "inline",
                position:((userposition == "absolute")?"absolute": "relative")
                });
            //* Local Variables ********************************************************************
            var h=$(this).height();
            var w=$(this).width()*1.04;
            var W=w+"px";
            var H=h+"px";
            //var W=w.pxToEm({scope: this});
            //var H=h.pxToEm({scope: this});
            var t=$(this).html();
            //* Set Class and Options ********************************************************
            $(this)
                .data("options", d)
                .addClass("JQFE")
                .css({
                    width: W,
                    height: H,
                    display: userdisplay,
                    position:(($(this).css("position")!= "absolute")?"relative": "absolute"),
                    zoom: 1
                    });
            //* Create the MyContainer structure ***********************************************
            var MyContainer=$("<div></div>").css({ // need extra div for IE zindex bug
                width: W,
                height: H,
                position: "relative"
            });
            //* MyContainer For the central layer ***********************************************
            MyContainer.append(
                $("<div class='JQFEText'>"+t+"</div>").css({
                    display:  d.hideText ? "none" :  "inline" ,
                    width: W,
                    height: H,
                    position: "relative",
                    zIndex:   100
                })
            );
            //* MyContainer For the Upper Effect layer ***********************************************
            var alldivsup=$("<div></div>").css({
                width: W,
                height: H,
                left: "0px",
                position: "absolute",
                top:      parseInt($(this).css("paddingTop"))*0+"px",
                zIndex:   110
            });
            //* MyContainer For the Lower Effect layer ***********************************************
            var alldivsdown=$(alldivsup).clone().css({zIndex: 90});
            FE.divounter+= 4;
            $(this).html("");
            //* Mirror Effect ****************************************************************
            if(d.mirror){
                for(i=0;i<h*(d.mirrorHeight/100);i++){
                    if(d.proportional){
                        var css_top1    =(h+d.mirrorOffset+i*d.mirrorDetail).pxToEm({scope: this});
                        var css_height  =d.mirrorDetail.pxToEm({scope: this});
                        var css_top2    =((h*-1)+i*(100/d.mirrorHeight)).pxToEm({scope: this});
                    }
                    else{
                        var css_top1    =(h+d.mirrorOffset+i*d.mirrorDetail)+"px";
                        var css_height  =d.mirrorDetail+"px";
                        var css_top2    =((h*-1)+i*(100/d.mirrorHeight))+"px";
                    };
                    var css_opacity=d.mirrorTStart-(i*(d.mirrorTStart/((d.mirrorHeight/100)*d.mirrorTLength)));
                    var appo=$("<div class='JQFEMirror'></div>").css({
                        position: "absolute",
                        top:      css_top1,
                        height:   css_height,
                        width:    W,
                        overflow: "hidden"
                    }).append($("<div>"+t+"</div>").css({
                            position: "absolute",
                            color:    d.mirrorColor,
                            top:      css_top2,
                            opacity:  css_opacity
                        })
                        );
                    FE.divounter+= i*2;
                    // Skip Non Visible Layers ************************************************
                    if(css_opacity<0.01) break;
                    alldivsdown.append(appo);
                };
            };
            //* Outline Effect ***************************************************************
            if(d.outline){
                var totdiv =(d.outlineWeight)*8;
                var to=FE.tabpos[d.outlineWeight];
                for(i=0;i<totdiv;i++){
                    appo=$("<div class='JQFEOutline'>"+t+"</div>").css({
                        position: "absolute",
                        top:     (to.charAt(i*2)  -d.outlineWeight)+"px",
                        left:    (to.charAt(i*2+1)-d.outlineWeight)+"px",
                        width:    W,
                        color:   ((i<totdiv/2+d.outlineWeight)?d.outlineColor1: d.outlineColor2),
                        zIndex:  ((i>totdiv-totdiv/3)?20: 30)
                    });
                    FE.divounter+= i;
                    alldivsdown.append(appo);
                };
            };
            //* Shadow Effect ****************************************************************
            if(d.shadow){
                var totdiv =(d.shadowBlur)*8;
                var to=FE.tabpos[d.shadowBlur];
                for(i=0;i<totdiv;i++){
                    appo=$("<div class='JQFEShadow'>"+t+"</div>").css({
                        opacity:  d.shadowOpacity,
                        position: "absolute",
                        top:     (to.charAt(i*2)  -d.shadowBlur)+d.shadowOffsetTop +"px",
                        left:    (to.charAt(i*2+1)-d.shadowBlur)+d.shadowOffsetLeft+"px",
                        width:    W,
                        height:   H,
                        color:    d.shadowColor,
                        zIndex:   10
                    });
                    FE.divounter+= i;
                    alldivsdown.append(appo);
                };
            };
            //* Gradient Effect *************************************************************
            if(d.gradient){
                var step    = Math.round((h*(d.gradientLength*0.01))/d.gradientSteps);
                var postop  = h*(d.gradientPosition*0.01);
                var opa     =(1/d.gradientSteps);
                var gcolor  = d.gradientColor;
                /*
                if(!d.gradientFromTop){
                    gcolor=$(this).css("color");
                    $(this).css("color", d.gradientColor);
                }
                */
                for(i=0;i<d.gradientSteps;i++){
                    if(d.proportional){
                        css_top1   = (((i == 0)?0: postop)+i*step).pxToEm({scope: this});
                        css_height = (((i == 0)?postop: 0)+step  ).pxToEm({scope: this});
                        css_top2   = ((((i == 0)?0: postop)+i*step)*-1).pxToEm({scope: this});
                    }
                    else{
                        css_top1   = (((i == 0)?0: postop)+i*step)+"px";
                        css_height = (((i == 0)?postop: 0)+step  )+"px";
                        css_top2   = ((((i == 0)?0: postop)+i*step)*-1)+"px";
                    };
                    appo=$("<div class='JQFEGradient'></div>").css({
                        position: "absolute",
                        top:      css_top1,
                        height:   css_height,
                        left:     "0px",
                        width:    W,
                        overflow: "hidden"
                    }).append($("<div>"+t+"</div>").css({
                            width:    "100%",
                            position: "absolute",
                            top:      css_top2,
                            color:    gcolor,
                            opacity:  1-opa*i
                        })
                        );
                    FE.divounter+= i*2;
                    alldivsup.append(appo);
                };
            };
            //* End Effects ******************************************************************
            MyContainer.append(alldivsdown);
            MyContainer.append(alldivsup);
            //* Draw Effect ******************************************************************
            $(this).append(MyContainer);
        });//* Main Loop End *******************************************************************************
        //* Internal Functions ******************************************************************************
        function hex2rgb(hexcolor){
            hexcolor=hexcolor.substring(1);
            if(hexcolor.length == 3) hexcolor=hexcolor.charAt(0)+hexcolor.charAt(0)+hexcolor.charAt(1)+hexcolor.charAt(1)+hexcolor.charAt(2)+hexcolor.charAt(2);
            var rgbcolor="rgb("+parseInt(hexcolor.substring(0, 2), 16)+", "+parseInt(hexcolor.substring(2, 4), 16)+", "+parseInt(hexcolor.substring(4, 6), 16)+")";
            return(rgbcolor);
        };
        function chkColorString(col){
            // test if "col" is a valid html color definition string(rgb(n, n, n)||#fff|#ffffff)
            return(/(#([0-9A-Fa-f]{3,6})\b)|(rgb\(\s*\b([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\b\s*,\s*\b([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\b\s*,\s*\b([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\b\s*\))|(rgb\(\s*(\d?\d%|100%)+\s*,\s*(\d?\d%|100%)+\s*,\s*(\d?\d%|100%)+\s*\))/.test(col));
        };
        function pickcontrast(col){ //(try to) find the contrasting color
            if(chkColorString(col)){
                col = col.toUpperCase();
                if(col.charAt(0) == "#") col=hex2rgb(col);
                var appo=col.substring(4, col.length-1).split(", ");
                var g=255-parseInt(appo[0]);
                var b=255-parseInt(appo[1]);
                var r=255-parseInt(appo[2]);
                col="rgb("+r+", "+g+", "+b+")";
            };
        return(col);
        };
        return this; // chain...
    }; //* Main Function End *******************************************************************************
    //* External Functions *******************************************************************************
    $.fn.changeOptionsFE = function(newoptions){
        if(this){
            var oldoptions=$(this).data("options") || {};
            $.extend(oldoptions, newoptions);
            $(this).data("options", oldoptions);
        };
    };
    $.fn.redrawFE = function(newoptions){
        if(this){
            if(newoptions) $(this).changeOptionsFE(newoptions);
            $(this).removeFE();
            $(this).FontEffect($(this).data("options"));
        };
    };
    $.fn.removeFE = function(removeoptions){
        if(this && $(this).hasClass("JQFE")){
            var t=$(this).find("div[class='JQFEText']").html();
            $(this).removeClass("JQFE");
            if(removeoptions) $(this).data("options", {});
            $(this).find("div[class^='JQFE']").remove();
            $(this).html(t);
        };
    };
    //* External Functions End *******************************************************************************
})(jQuery);
//* End FontEffect Plugin ******************************************************************************
/*--------------------------------------------------------------------
 * javascript method:  "pxToEm"
 * by:
   Scott Jehl(scott@filamentgroup.com)
   Maggie Wachs(maggie@filamentgroup.com)
   http: //www.filamentgroup.com
 *
 * Copyright(c) 2008 Filament Group
 * Dual licensed under the MIT(filamentgroup.com/examples/mit-license.txt) and GPL(filamentgroup.com/examples/gpl-license.txt) licenses.
 *
--------------------------------------------------------------------*/
Number.prototype.pxToEm = String.prototype.pxToEm = function(settings){
    settings = $.extend({
        scope:  'body',
        reverse:  false
},  settings);
    var pxVal =(this  ==  '') ? 0 :  parseFloat(this);
    var scopeVal;
    var getWindowWidth = function(){
        var de = document.documentElement;
        return self.innerWidth ||(de && de.clientWidth) || document.body.clientWidth;
};
    if(settings.scope  ==  'body' && $.browser.msie &&(parseFloat($('body').css('font-size')) / getWindowWidth()).toFixed(1) > 0.0){
        var calcFontSize = function(){
            return(parseFloat($('body').css('font-size'))/getWindowWidth()).toFixed(3) * 16;
    };
        scopeVal = calcFontSize();
}
    else { scopeVal = parseFloat($(settings.scope).css("font-size")); };
    var result =(settings.reverse  ==  true) ?(pxVal * scopeVal).toFixed(2) + 'px' : (pxVal / scopeVal).toFixed(2) + 'em';
    return result;
};

/**
* BORDER IMAGE
*/

(function($){
/*
 * jquery.borderImage - partial cross-browser implementation of CSS3's borderImage property
 *
 * Copyright (c) 2008 lrbabe ( lrbabe.com)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 */

/* TODO:
 * - Empty elements (img, canvas, ...) can't use borderImage without beeing wrapped first.
 */

$.fn.borderImage = function(value){
	// Test border-image and canvas support on first use
	if(!$.fn.borderImage.initialized) {
		if(document.defaultView && document.defaultView.getComputedStyle) {
			var s = document.defaultView.getComputedStyle(document.body, '');
			if(typeof(document.body.style['-webkitBorderImage']) == 'string') {
				$.browser.support.borderImage = true;
				$.fn.borderImage.prefix = '-webkit';
			} else if(s.getPropertyValue('-moz-border-image') != '') {
				$.browser.support.borderImage = true;
				$.fn.borderImage.prefix = '-moz';
			}
		}
		if(!$.browser.support.borderImage && document.createElement('canvas').getContext) {
			$.browser.support.canvas = true;
			// Create a global canvas that will be used to draw the slices.
			bicanvas = document.createElement('canvas');
		}
		$.fn.borderImage.initialized = true;
	}
	
	// Use browsers native implemantation when available.
	if($.browser.support.borderImage)
		// For single borderImage only
		return (arguments[1] && arguments[1].constructor == String)? $(this) : $(this).css($.fn.borderImage.prefix+'BorderImage', value).css('backgroundColor', 'transparent');
	
	var result = /url\(\s*"(.*?)"\s*\)\s*(\d+)(%)?\s*(\d*)(%)?\s*(\d*)(%)?\s*(\d*)(%)?/.exec(value);
  	if(result && ($.browser.support.canvas || $.browser.support.vml)) {    
        
		arguments[0] = result[1];
	    var _this = this,
	      imageWrapper = document.createDocumentFragment().appendChild(document.createElement('div')),
	      argsLength = arguments.length,
	      // Use the last argument as resolution if it is a number, otherwise use defaults.
	      resolution = arguments[argsLength -1].constructor == Number? arguments[argsLength -1] : $.fn.borderImage.defaults.resolution;
	    for(var i = 0; i < argsLength && arguments[i].constructor == String; ++i){
	    	var img = document.createElement('img');
	      	img.src = arguments[i];
			// If we don't clone the image, load event may not fire in IE
	      	imageWrapper.appendChild(img.cloneNode(true));
	    }
	    imageWrapper.style.position = 'absolute';
	    imageWrapper.style.visibility = 'hidden';
	    $('body').prepend(imageWrapper);
    
    	var $img = $('img:first', imageWrapper).load(function(){
			// Compute cuts
			var imgHeight 	= $img.height(),
				imgWidth	= $img.width(),
				topCut 		= parseInt(result[2]) * (result[3]? imgHeight/100 : 1),
				rightCut 	= result[4]? parseInt(result[4]) * (result[5]? imgWidth/100 : 1) : topCut,
				bottomCut 	= result[6]? parseInt(result[6]) * (result[7]? imgHeight/100 : 1) : topCut,
				leftCut		= result[8]? parseInt(result[8]) * (result[9]? imgWidth/100 : 1) : rightCut,
				centerHeight= imgHeight -topCut -bottomCut,
				centerWidth	= imgWidth -leftCut -rightCut,
				image = imageWrapper.getElementsByTagName('img'),
				// Draw all the slices
				slice0 = drawSlice(0, 					0, 						leftCut, 		topCut, 		image),
				slice1 = drawSlice(leftCut, 			0, 						centerWidth,	topCut, 		image),
				slice2 = drawSlice(leftCut+centerWidth,	0, 						rightCut, 		topCut,			image),
				slice3 = drawSlice(0, 					topCut, 				leftCut, 		centerHeight,	image),
				slice4 = drawSlice(leftCut, 			topCut, 				centerWidth,	centerHeight,	image),
				slice5 = drawSlice(leftCut+centerWidth,	topCut,					rightCut, 		centerHeight,	image),
				slice6 = drawSlice(0, 					topCut+centerHeight,	leftCut, 		bottomCut,		image),
				slice7 = drawSlice(leftCut,				topCut+centerHeight,	centerWidth,	bottomCut,		image),
				slice8 = drawSlice(leftCut+centerWidth,	topCut+centerHeight,	rightCut, 		bottomCut,		image),
				borderTop, borderRight, borderBottom, borderLeft,
				prevFragment;
				
			function drawSlice(sx, sy, sw, sh, image) {
				var slice = document.createDocumentFragment();
				// Don't waste time drawing slice with null dimension
				if(sw > 0 && sh > 0) {
					if($.browser.support.canvas) bicanvas.setAttribute('height', resolution+'px');				
					for(var i = 0; i < image.length; ++i) {
						if($.browser.support.canvas) {
							// Clear the global canvas and use it to draw a new slice
							bicanvas.setAttribute('width', resolution+'px');
							bicanvas.getContext('2d').drawImage(image[i], sx, sy, sw, sh, 0, 0, resolution, resolution);
							// Store the slice in an image in order to reuse it
							var el = document.createElement('img');
							el.src = bicanvas.toDataURL();
						} else {
							// Could you explain me why we can't just use "document.createElement('biv:image')"?
							var el = document.createElement('div');
							el.insertAdjacentHTML('BeforeEnd', 
								'<biv:image src="'+image[i].src+'" cropleft="'+sx/imgWidth+'" croptop="'+sy/imgHeight+'" cropright="'+(imgWidth-sw-sx)/imgWidth+'" cropbottom="'+(imgHeight-sh-sy)/imgHeight+'" />'
							);
							el = el.firstChild;
						}
						el.style.width = el.style.height = '100%';
						el.style.position = 'absolute';
						el.style.border = 'none';
						el.className = 'biSlice image'+i;
						slice.appendChild(el);
					}
				}
				return slice;
			}
			
			_this.each(function(i, el){
				var $this = $(el),
					thisStyle = {
						position: 'relative',
						borderColor: 'transparent',
						background: 'none',
						padding: 0
					},
					innerWrapper = document.createElement('div'),
					reuse = true;
					
				// There is many case where "display: 'inline'" actually is a problem.
				// TODO: Try to find exactly where
				if($this.css('display') == 'inline')
					thisStyle.display = 'inline-block'; 			
					
				// Workaround MSIE6 transparent border bug
				if($.browser.msie && parseInt($.browser.version) < 7){
					thisStyle.borderColor = '#808180';
					thisStyle.filter = 'chroma(color=#808180)';					
				}
				
				innerWrapper.style.paddingTop = $this.css('paddingTop');
				innerWrapper.style.paddingLeft = $this.css('paddingLeft');
				innerWrapper.style.paddingBottom = $this.css('paddingBottom');
				innerWrapper.style.paddingRight = $this.css('paddingRight');
				innerWrapper.style.position = 'relative';
				innerWrapper.className = 'biWrapper'
				$this.css(thisStyle).wrapInner(innerWrapper);
				
				if(borderTop != $this.css('borderTopWidth')) {
					borderTop = $this.css('borderTopWidth');
					reuse = false;
				}
				if(borderBottom != $this.css('borderBottomWidth')) {
					borderBottom = $this.css('borderBottomWidth');
					reuse = false;
				}
				if(borderRight != $this.css('borderRightWidth')) {
					borderRight = $this.css('borderRightWidth');
					reuse = false;
				}
				if(borderLeft != $this.css('borderLeftWidth')) {
					borderLeft = $this.css('borderLeftWidth');
					reuse = false;
				}
				
				// Reuse previous fragment if borderWidths are the same.
				if(!reuse) {
					var fragment = document.createDocumentFragment();
					
					function drawBorder(style, slice) {
						// Don't waste time drawing borders with null dimension
						if(parseInt(style.width) != 0 && parseInt(style.height) != 0) {
							var el = document.createElement('div');
							for(var i in style)
								el.style[i] = style[i];
							el.style.position = 'absolute';
							el.style.textAlign = 'left';
							el.appendChild(slice.cloneNode(true));
							fragment.appendChild(el);
						}						
					}
					
					// Create the magical tiles
					drawBorder({top:'-'+borderTop, left:'-'+borderLeft, height: borderTop, width: borderLeft}, 				slice0);
					drawBorder({top:'-'+borderTop, left: 0, width: '100%', height: borderTop}, 								slice1);
					drawBorder({top:'-'+borderTop, right:'-'+borderRight, height: borderTop, width: borderRight}, 			slice2);									
					drawBorder({top: 0, bottom:0, left:'-'+borderLeft, width: borderLeft, height: '100%'}, 					slice3);					
					drawBorder({left: 0, top: 0, right: 0, bottom: 0, height: '100%', width: '100%'},						slice4);
					drawBorder({top: 0, bottom:0, right:'-'+borderRight, width: borderRight, height: '100%'}, 				slice5);									
					drawBorder({bottom:'-'+borderBottom, left:'-'+borderLeft, width: borderLeft, height: borderBottom},		slice6);
					drawBorder({bottom:'-'+borderBottom, left: 0, width:'100%', height: borderBottom}, 						slice7);
					drawBorder({bottom:'-'+borderBottom, right:'-'+borderRight, height: borderBottom, width: borderRight},	slice8);
					
					prevFragment = fragment;
				}
				$this.prepend(prevFragment.cloneNode(true));
				
				// height: 100% doesn't work in IE6
				if($.browser.msie && parseInt($.browser.version) < 7)
					el.onpropertychange = function(){
						$this.find('div:eq(3), div:eq(4), div:eq(5)').css('height', $this.innerHeight())
					};									
			});
		});
		// Is there an explanation why we need this line to have all the slices actually drawn?
		if($.browser.support.vml) $('body')[0].appendChild(document.createElement('biv:image'));
	}
	return $(this);	
};

// Test vml support as early as possible.
if(!$.browser.support) $.browser.support = {};		
if (document.namespaces && !document.namespaces['biv']) {
	document.namespaces.add('biv', 'urn:schemas-microsoft-com:vml', "#default#VML");
	document.createStyleSheet().addRule('biv\\:*', "behavior: url(#default#VML);");
	$.browser.support.vml = true;
	$.fn.borderImage.initialized = true;
 }

$.fn.borderImage.defaults = {
	resolution: 20
};

/*
 * Helper function to resize an element potentially decorated with an emulated border-image, using an animation.
 */
$.fn.biResize = function(newDimensions, options) {
	return this.each(function(i, el){
		var $el = $(el),
			$biWrap = $el.find('.biWrapper');
			// If the content is wrapped, it means the browser is emulating borderImage
		    if($biWrap.length) {
		        // transfer dimensions to the internal wrapper
		        $biWrap.css({ width: $el.css('width'), height: $el.css('height') });
		        $el.css({ width: 'auto', height: 'auto' });
		        // Resize the internal wrapper instead
		        $biWrap.animate(newDimensions, options);
		    // If the native implementation is used, you can resize the element itself
		    } else $el.animate(newDimensions, options);
	});
}
})(jQuery);

/**
* NATIVE CODE
*/

$(document).ready(function () {

	function toggle(elmt) {
		if (navigator.appName == "Microsoft Internet Explorer") {
			if (elmt.css('display') == 'none')
				elmt.css('display', 'block');
			else
				elmt.css('display', 'none');
		} else
			elmt.slideToggle("fast");
	}

	// COLLAPSABLE WIDGETS (on Dashboard & Profile pages)
	// toggle widget box contents
	$('a.toggle_box_contents').bind('click', toggleContent);
	
	// toggle widget box edit panel
	$('a.toggle_box_edit_panel').click(function () {
		toggle($(this.parentNode.parentNode).children("[class=collapsable_box_editpanel]"));
		return false;
	});
	
	// toggle customise edit panel
	$('a.toggle_customise_edit_panel').click(function () {
		toggle($('div#customise_editpanel'));
		return false;
	}); 
	
	// toggle plugin's settings nad more info on admin tools admin
	$('a.pluginsettings_link').click(function () {
		toggle($(this.parentNode.parentNode).children("[class=pluginsettings]"));
		return false;
	});
	$('a.manifest_details').click(function () {
		toggle($(this.parentNode.parentNode).children("[class=manifest_file]"));
		return false;
	});
	// reusable generic hidden panel
	$('a.collapsibleboxlink').click(function () {
		toggle($(this.parentNode.parentNode).children("[class=collapsible_box]"));
		return false;
	});
	
	// WIDGET GALLERY EDIT PANEL
	// Sortable widgets
	var els = ['#leftcolumn_widgets', '#middlecolumn_widgets', '#rightcolumn_widgets', '#widget_picker_gallery' ];
	var $els = $(els.toString());
	
	$els.sortable({
		items: '.draggable_widget',
		handle: '.drag_handle',
		cursor: 'move',
		revert: true,
		opacity: 1.0,
		appendTo: 'body',
		placeholder: 'placeholder',
		connectWith: els,
		start:function(e,ui) {
	
		},
		stop: function(e,ui) {	
			// refresh list before updating hidden fields with new widget order		
			$(this).sortable( "refresh" );
			
			var widgetNamesLeft = outputWidgetList('#leftcolumn_widgets');
			var widgetNamesMiddle = outputWidgetList('#middlecolumn_widgets');
			var widgetNamesRight = outputWidgetList('#rightcolumn_widgets');
			
			document.getElementById('debugField1').value = widgetNamesLeft;
			document.getElementById('debugField2').value = widgetNamesMiddle;
			document.getElementById('debugField3').value = widgetNamesRight;
		}
	});
	
	// bind more info buttons - called when new widgets are created
	widget_moreinfo();
	
	// set-up hover class for dragged widgets
	$("#rightcolumn_widgets").droppable({
		accept: ".draggable_widget",
		hoverClass: 'droppable-hover'
	});
	$("#middlecolumn_widgets").droppable({
		accept: ".draggable_widget",
		hoverClass: 'droppable-hover'
	});
	$("#leftcolumn_widgets").droppable({
		accept: ".draggable_widget",
		hoverClass: 'droppable-hover'
	});
	
	$('#site_name_logo').FontEffect({
		mirror:true,
		mirrorColor: "#FFA400",
		shadow: true,
		shadowColor: "#000000",
		gradient: true,
		gradientColor: "#FFF800"
	});

	function apply_border_image(selector){	
		$(selector).css("border-width", "10px 20px 20px 10px");
		$(selector).borderImage('url("<?php echo $vars['url']; ?>mod/theme_blue_and_yellow/graphics/widget_border.png") 25% 50% 50% 25%');
	}
	
	apply_border_image('.collapsable_box');
	apply_border_image('#one_column');
	apply_border_image('#two_column_left_sidebar');
	apply_border_image('#two_column_left_sidebar_maincontent');
	apply_border_image('#two_column_left_sidebar_maincontent_boxes');
	apply_border_image('#two_column_left_sidebar_boxes .sidebarBox');
	apply_border_image('#profile_info');
	apply_border_image('#dashboard_info');
	apply_border_image('#customise_editpanel');
	apply_border_image('#index_welcome, #index_welcome_wide');
	apply_border_image('.index_box');
	apply_border_image('#register-box');
	apply_border_image('#edit_page_button');
	apply_border_image('#blog_edit_page #blog_edit_sidebar');

	if (navigator.appName == "Microsoft Internet Explorer" || navigator.appName == "Opera") {
		$('#index_welcome').after("<div class='widget_spacer'> </div>");
		$('#index_welcome_wide').after("<div class='widget_spacer'> </div>");
		$('#customise_editpanel').after("<div class='widget_spacer'> </div>");
		$('.index_box').after("<div class='widget_spacer'> </div>");
		$('.collapsable_box').after("<div class='widget_spacer'> </div>");
	}
	
}); /* end document ready function */


// List active widgets for each page column
function outputWidgetList(forElement) {
	return( $("input[@name='handler'], input[@name='guid']", forElement ).makeDelimitedList("value") );	
}

// Make delimited list
jQuery.fn.makeDelimitedList = function(elementAttribute) {

	var delimitedListArray = new Array();
	var listDelimiter = "::";
	
	// Loop over each element in the stack and add the elementAttribute to the array
	this.each(function(e) {
			var listElement = $(this);
			// Add the attribute value to our values array
			delimitedListArray[delimitedListArray.length] = listElement.attr(elementAttribute);
		}
	);
	
	// Return value list by joining the array
	return(delimitedListArray.join(listDelimiter));
}


// Read each widgets collapsed/expanded state from cookie and apply
function widget_state(forWidget) {

	var thisWidgetState = $.cookie(forWidget);

	if (thisWidgetState == 'collapsed') {
		forWidget = "#" + forWidget;
		$(forWidget).find("div.collapsable_box_content").hide();
		$(forWidget).find("a.toggle_box_contents").html('<img src="<?php echo $vars['url']; ?>mod/theme_blue_and_yellow/graphics/widget_maximize.png" border="0" />');
		$(forWidget).find("a.toggle_box_edit_panel").fadeOut('medium');
	};	
}

// Toggle widgets contents and save to a cookie
var toggleContent = function(e) {

var targetContent = $('div.collapsable_box_content', this.parentNode.parentNode);
	if (targetContent.css('display') == 'none') {		
		$(this).html('<img src="<?php echo $vars['url']; ?>mod/theme_blue_and_yellow/graphics/widget_minimize.png" border="0" />');
		if (navigator.appName == "Microsoft Internet Explorer") {
			targetContent.css('display', 'block');
		} else {
			targetContent.slideDown(400);
			$(this.parentNode).children("[class=toggle_box_edit_panel]").fadeIn('medium');
		}
		
		// set cookie for widget panel open-state
		var thisWidgetName = $(this.parentNode.parentNode.parentNode).attr('id');
		$.cookie(thisWidgetName, 'expanded', { expires: 365 });
		
	} else {
		$(this).html('<img src="<?php echo $vars['url']; ?>mod/theme_blue_and_yellow/graphics/widget_maximize.png" border="0" />');
		if (navigator.appName == "Microsoft Internet Explorer") {
			targetContent.css('display', 'none');
		} else {
			targetContent.slideUp(400);
			$(this.parentNode).children("[class=toggle_box_edit_panel]").fadeOut('medium');
			// make sure edit pane is closed
			$(this.parentNode.parentNode).children("[class=collapsable_box_editpanel]").hide();
		}
		
		// set cookie for widget panel closed-state
		var thisWidgetName = $(this.parentNode.parentNode.parentNode).attr('id');
		$.cookie(thisWidgetName, 'collapsed', { expires: 365 });			
	}

	return false;
};

// More info tooltip in widget gallery edit panel
function widget_moreinfo() {

	$("img.more_info").hover(function(e) {										  
	var widgetdescription = $("input[@name='description']", this.parentNode.parentNode.parentNode ).attr('value');
	$("body").append("<p id='widget_moreinfo'><b>"+ widgetdescription +" </b></p>");
	
		if (e.pageX < 900) {
			$("#widget_moreinfo")
				.css("top",(e.pageY + 10) + "px")
				.css("left",(e.pageX + 10) + "px")
				.fadeIn("medium");	
		}	
		else {
			$("#widget_moreinfo")
				.css("top",(e.pageY + 10) + "px")
				.css("left",(e.pageX - 210) + "px")
				.fadeIn("medium");		
		}			
	},
	function() {
		$("#widget_moreinfo").remove();
	});	
	
	$("img.more_info").mousemove(function(e) {
		// action on mousemove
	});	
};

// COOKIES
jQuery.cookie = function(name, value, options) {
	if (typeof value != 'undefined') { // name and value given, set cookie
    options = options || {};
	    if (value === null) {
	        value = '';
	        options.expires = -1;
	    }
    var expires = '';
    if (options.expires && (typeof options.expires == 'number' || options.expires.toUTCString)) {
        var date;
        if (typeof options.expires == 'number') {
            date = new Date();
            date.setTime(date.getTime() + (options.expires * 24 * 60 * 60 * 1000));
        } else {
            date = options.expires;
        }
        expires = '; expires=' + date.toUTCString(); // use expires attribute, max-age is not supported by IE
    }
    // CAUTION: Needed to parenthesize options.path and options.domain
    // in the following expressions, otherwise they evaluate to undefined
    // in the packed version for some reason.
    var path = options.path ? '; path=' + (options.path) : '';
    var domain = options.domain ? '; domain=' + (options.domain) : '';
    var secure = options.secure ? '; secure' : '';
    document.cookie = [name, '=', encodeURIComponent(value), expires, path, domain, secure].join('');
    
	} else { // only name given, get cookie
	    var cookieValue = null;
	    if (document.cookie && document.cookie != '') {
	        var cookies = document.cookie.split(';');
	        for (var i = 0; i < cookies.length; i++) {
	            var cookie = jQuery.trim(cookies[i]);
	            // Does this cookie string begin with the name we want?
	            if (cookie.substring(0, name.length + 1) == (name + '=')) {
	                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
	                break;
	            }
	        }
	    }
	    return cookieValue;
	}
};

// ELGG TOOLBAR MENU
$.fn.elgg_topbardropdownmenu = function(options) {
    
  options = $.extend({speed: 350}, options || {});
  
  this.each(function() {
    
    var root = this, zIndex = 5000;
    
    function getSubnav(ele) {
      if (ele.nodeName.toLowerCase() == 'li') {
        var subnav = $('> ul', ele);
        return subnav.length ? subnav[0] : null;
      } else {
	      
        return ele;
      }
    }
    
    function getActuator(ele) {
      if (ele.nodeName.toLowerCase() == 'ul') {
        return $(ele).parents('li')[0];
      } else {
        return ele;
      }
    }
    
    function hide() {
      var subnav = getSubnav(this);
      if (!subnav) return;
      $.data(subnav, 'cancelHide', false);
      setTimeout(function() {
        if (!$.data(subnav, 'cancelHide')) {
          $(subnav).slideUp(100);
        }
      }, 250);
    }
  
    function show() {
      var subnav = getSubnav(this);
      if (!subnav) return;
      $.data(subnav, 'cancelHide', true);
      $(subnav).css({zIndex: zIndex++}).slideDown(options.speed);
      if (this.nodeName.toLowerCase() == 'ul') {
        var li = getActuator(this);
        $(li).addClass('hover');
        $('> a', li).addClass('hover');
      }
    }
    
    $('ul, li', this).hover(show, hide);
    $('li', this).hover(
      function() { $(this).addClass('hover'); $('> a', this).addClass('hover'); },
      function() { $(this).removeClass('hover'); $('> a', this).removeClass('hover'); }
    );
    
  });  
};



