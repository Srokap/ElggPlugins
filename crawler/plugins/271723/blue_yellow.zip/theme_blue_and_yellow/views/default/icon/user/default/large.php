<?php
	echo $vars['url'] . "mod/theme_blue_and_yellow/graphics/user_icons/defaultlarge.gif";
?>