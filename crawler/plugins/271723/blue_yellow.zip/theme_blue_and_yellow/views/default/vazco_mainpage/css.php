<?php
	/**
	 * Custom Index page css extender
	 * 
	 * @package custom_index
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider <info@elgg.com>
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.org/
	 */
?>

/*-------------------------------
MAINPAGE WIDGETS EDIT PAGE
-------------------------------*/

textarea.mainpage_edit{
	width: 185px;
	font-size: 10px;
	height: 150px;
}
#custom_index {
	margin:10px;
}
#index_left {
    width:442px;
    float:left;
    margin:0 0 30px 0;
    padding:0 0 20px 0px;
}
#index_right {
    width:442px;
    float:right;
    margin:0 0 30px 0;
    padding:0 0px 20px 0;
}
#index_welcome,
#index_welcome_wide {
	padding:5px 10px 5px 10px;
	margin:0 0 20px 0;
	color: #EEEEEE;
}

#index_welcome h2 {
	color: #FFA400;
}

#index_welcome #login-box {
	margin:5px 0 10px 0;
	padding:0 0 10px 0;
	width:240px;
}
#index_welcome #login-box form {
	margin:0 10px 0 10px;
	padding:0 10px 4px 10px;
	background: white;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	width:200px;
}
#index_welcome #login-box h2,
.index_box h2 {
	color:#FFA400;
	font-size:1.35em;
	line-height:1.2em;
	margin:0 0 0 8px;
	padding:5px;
}
#index_welcome #login-box h2 {
	padding-bottom:5px;
}

.index_box {
	margin:0 0 20px 0;
	padding:0 0 5px 0;
	border-width: 10px 20px 20px 10px;
}

.index_box .search_listing {

}
.index_box .index_members {
	float:left;
	margin:2pt 5px 3px 0pt;
}
#persistent_login {
	float:right;
	display:block;
	margin-top:-34px;
}


/*-------------------------------
SIMPLEPIE FEED WIDGET
-------------------------------*/
.simplepie_blog_title {
  text-align: center;
  margin-bottom: 15px;
}

.simplepie_item {
  margin-bottom: 12px;
}

.simplepie_title {
  margin-bottom: 4px;
}

.simplepie_excerpt {
  margin-bottom: 4px;
}

.simplepie_date {
  font-size: 70%;
}

.simplepie_excerpt img {
  width: 170px;
}

/*-------------------------------
TIDYPICS WIDGET
-------------------------------*/
.tidypics_index {
	margin:4px;
	float:left;
}
.tidypics_frontpage{
	max-width: 60px;
	max-height: 60px;
}
.frontpage_tidypics_box{
	text-align:center;
	height: 70px;
	margin: 5px 30px;
}

/*-------------------------------
MAINPAGE WIDGETS EDIT PAGE
-------------------------------*/

#index_welcome_wide #login-box form {
    width: 310px
}
#index_welcome_wide #login-box {
    width:350px;
}
#index_welcome_wide #login-box .login-textarea{
	width:268px;
}