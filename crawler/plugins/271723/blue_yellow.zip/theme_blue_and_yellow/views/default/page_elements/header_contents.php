<?php

	/**
	 * Elgg header contents 
	 * This file holds the header output that a user will see
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2009
	 * @link http://elgg.org/
	 **/
	 
?>

<div id="page_container">
<div id="page_wrapper">

<div id="layout_header">
<div id="wrapper_header">
	
	<h1>
		<table width="100%">
		<tr>
		<td width="75"><img src="<?php echo $vars['url']; ?>mod/theme_blue_and_yellow/graphics/logo.png" border="0" />
		</td>
		<td>
			<a href="<?php echo $vars['url']; ?>">			
				<span id="site_name_logo"><?php echo $vars['config']->sitename; ?></span>
			</a>
		</td>
		<td align="right">
			<?php
		if($_SESSION['user']->guid == page_owner()){
			if (strrpos($_SERVER['REQUEST_URI'], 'pg/profile') || strrpos($_SERVER['REQUEST_URI'], 'pg/dashboard')) {
		?>
		<!-- customise page button -->
		<div id="edit_page_button">
			<img src="<?php echo $vars['url']; ?>mod/theme_blue_and_yellow/graphics/pencil_small.png" border = "0" />
			<a href="javascript:void(0);" class="toggle_customise_edit_panel"><?php echo(elgg_echo('dashboard:configure')); ?></a>
		</div>
		<?php
			}
		}
		?>
		</td>
		</tr></table>
	</h1>

</div><!-- /#wrapper_header -->
</div><!-- /#layout_header -->