<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2//EN">
<?php
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html;charset=ISO-8859-1" >
<title>Thank You</title>
<style>
a.navwhite:link { text-decoration: none; color: #ffffff; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navwhite:visited { text-decoration: none; color: #ffffff; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navwhite:hover { text-decoration: underline; color: #ffffff; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navblack:link { text-decoration: none; color: #000000; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navblack:visited { text-decoration: none; color: #000000; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navblack:hover { text-decoration: underline; color: #000000; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }

h1 { font-family: Arial, sans-serif; font-size: 30px; color: #004080;}
h2 { font-family: Arial, sans-serif; font-size: 18px; color: #004080;}

body,p,b,i,em,dt,dd,dl,sl,caption,th,td,tr,u,blink,select,option,form,div,li { font-family: Arial, sans-serif; font-size: 12px; }

</style>
</head>
<body bgcolor="#ffffff">
<p>

<table cellspacing="0" cellpadding="0" width="780" align="center" border="0" bgcolor="#000000">
  <tr>
        <td bgcolor="#8080c0">
      <h1 align="center"><font 
      color=#ffffff>Thank You</font></h1></td></tr>
  <tr>
        <td bgcolor="#ffffff">
      <table cellspacing="0" cellpadding="0" width="100%" align="center" border="0">
        
        <tr>
            <td width="150">
            <p>
            <table cellspacing="1" cellpadding="3" width="100%" align="center" 
            border=0 bgColor=#8080c0>
              
              <tr>
                      <td bgcolor="#004080" height="10">
                  <h3 align="center">Quick Links </h3>
                  <p align="center"><font size="2"><a 
                  href="http://productionsX.tk"><strong>Productions 
                  X</strong></a></font> </p></td></tr>
              
              <tr>
                        <td bgcolor="#004080" height="10">
                  <p align="center"><a href="<?php echo elgg_get_site_url(); ?>admin/plugin_settings/footer_editor">Edit footer</a></p> </td></tr>
              <tr>
                  <td width="150">
                  <p>&nbsp;</p></td></tr></table> </p>
            <p>  </p>
            <p> </p>
            <p> </p></td>
                        <td width="640" bgcolor="#ffffff" VALIGN  =top V v>
            <h2>
            <table cellspacing="6" cellpadding="0" width="100%" align="center" 
            border=0>
              
              <tr>
                <td>
                  <h2> Thank you for installing the Footer 
                  Editor Plugin. This plugin was made by
                  Speedysnail6.</h2></td></tr></table> </h2> </td></tr></table></td></tr></table></p>
</body>
</html>