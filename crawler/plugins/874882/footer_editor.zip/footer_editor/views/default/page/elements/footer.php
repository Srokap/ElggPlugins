<style type="text/css" media="screen">
.elgg-page-default .elgg-page-footer > .elgg-inner {
width: 990px;
margin: 0 auto;
height:  auto;
}
</style>
<?php
$footercontents = elgg_get_plugin_setting('footercontents', 'footer_editor');
echo $footercontents;
?><br>
<br><br></br>