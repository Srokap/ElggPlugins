<meta http-equiv="refresh" content="0; url=<?php
echo elgg_get_site_url(); ?>mod/footer_editor/thankyou.php">