<?php
	/**
	* ElggChat - Pure Elgg-based chat/IM
	* 
	* All the ElggChat CSS can be found here
	* 
	* @package elggchat
	* @author ColdTrick IT Solutions
	* @copyright Coldtrick IT Solutions 2009
	* @link http://www.coldtrick.com/
	* @version 0.4
	*/

	require_once(dirname(dirname(dirname(dirname(dirname(dirname(__FILE__)))))) . "/engine/start.php");
	global $CONFIG;
	
	header("Content-type: text/css", true);
?>

#elggchat_toolbar {
	position: fixed;
	bottom: 0px;
	height: 25px;
	left: 0px;
	z-index: 9999;
} 

*html #elggchat_toolbar {
	position: fixed;
	bottom: 0px;
	height: 25px;
	left: 0px;
	z-index: 9999;
}

#elggchat_toolbar_left {
	float:right;
	background:url(<?php echo $CONFIG->wwwroot; ?>mod/elggchat/_graphics/chatbg.png) repeat top left;
	padding-top: 0px;
	padding-bottom: 4px;
	height:25px;
    width:100%;
    left:30px;
    position:absolute;
}

#elggchat_copyright{
	color: #CCCCCC;
	padding-left: 5px;
	float:left;
	display: none;
}

.session {
	float: left;
	background: url(<?php echo $CONFIG->wwwroot; ?>mod/elggchat/_graphics/cool.png) repeat top left;
	border: 1px solid #999999;  /*bottom of chat window*/
    padding:3px;
    margin:0 5px 5px 5px;
    /* ie fix */
	max-width:200px;
}

.elggchat_session_new_messages {
	background: #333333;
}

.elggchat_session_new_messages.elggchat_session_new_messages_blink{
	background: #CD0000;
}

#elggchat_extensions{
	float:right;
	border-left:1px solid #CCCCCC;
	padding: 0 5px 0 5px;	
}

#elggchat_friends{
	float:right;
	border-left:1px solid #CCCCCC;
	background: url(<?php echo $CONFIG->wwwroot; ?>mod/elggchat/_graphics/chatbg.png) repeat top left; 
    height:100%;
}

#elggchat_friends a.click{
    padding: 3px 5px 3px 5px;
    color:#ffffff;
    display: block;
}

#elggchat_friends a.click:hover{
    color:#ffffff;
    display: block;
    background: #FFFFFF url(<?php echo $CONFIG->wwwroot; ?>mod/elggchat/_graphics/chatbg.png) repeat top left; 
    height:100%;
    weight:100%;
    text-decoration:none;
}

#elggchat_friends a.click img{
    padding: 0 3px 2px 3px;
    vertical-align: middle;
}

#icon_wrap {
}

#elggchat_friends2 {
    float:right;
    border-left:1px solid #CCCCCC;
    background: url(<?php echo $CONFIG->wwwroot; ?>mod/elggchat/_graphics/chatbg.png) repeat top left;
}

#elggchat_friends2 a img{
    width:24px;
    height:24px;
    padding:0;
    margin:0;
}

#elggchat_friends_picker{
	display: none;
	position: absolute;
	bottom: 29px;
	right: 0px;
	background: url(<?php echo $CONFIG->wwwroot; ?>mod/elggchat/_graphics/cool.png) repeat top left;
	padding: 5px;
	padding-right: 20px;
	overflow-x:hidden;
	max-height:300px;
	overflow-y: auto;
	white-space: nowrap;
	border-left:1px solid #CCCCCC;
	border-top:1px solid #CCCCCC;

}
#elggchat_friends_picker a {
    color: #ffffff;
}

.toggle_elggchat_toolbar {
	width: 30px;
	height: 100%;
	float:left;
	background:transparent url(<?php echo $CONFIG->wwwroot; ?>mod/elggchat/_graphics/minimize.png) repeat-x left center;	
}

.minimizedToolbar {
	background-position: right center;	
}

.messageWrapper {
	background:white;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
    padding:10px;
    margin:0 5px 5px 5px;
}

.messageWrapper table{
	background: white;
	height: 0px;
}
.systemMessageWrapper {
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
    padding:3px;
    margin:0 5px 5px 5px;
	color: #999999;
}

.messageIcon {
	margin-right: 7px;
}

.messageName {
	border-bottom:1px solid #DDDDDD;
	width: 100%;
	font-weight: bold;
	color: #4690D6;
}

.chatsessiondatacontainer {
	width:200px;
	display: none;
}

.chatsessiondata{
	border: 1px solid #999999;
	background: url(<?php echo $CONFIG->wwwroot; ?>mod/elggchat/_graphics/cool.png) repeat top left;
	margin: 0 -4px;
	position:absolute;
	bottom:26px;
	width:206px;
	max-height:600px;
	overflow:hidden;
}
.chatsessiondata a{
    color: #ffffff;
}

.chatmembers{     /*line under members in chat box */
	max-height:154px;
	overflow-y:auto;
}

.chatmember td{
	vertical-align: middle;
}

.chatmembers .chatmemberinfo{
	width: 100%;
}
.chatmembers img {
    padding:8px;
    bottom:0px;
}
.chatmembersfunctions {
	text-align:right;
	padding-right:2px;
    margin-bottom:8px;
	height:20px;
	border-bottom: 1px solid #DEDEDE;
}
.chatmembersfunctions_invite{
	display:none;
	text-align:left;
	position:absolute;
	background: #333333;
	width:100%;
	opacity: 0.8;
	filter: alpha(opacity=80);
	max-height:250px;
	overflow-x: hidden;
	overflow-y: auto;	
}

.chatmembersfunctions_invite a {
	color: #FFFFFF;
	padding:3px;
}

.online_status_chat{
	width:24px;
	height:24px;
	background: transparent url("<?php echo $CONFIG->wwwroot; ?>mod/elggchat/_graphics/online_status.png") no-repeat 0 0;
}

.online_status_idle{
	background-position: 0 -24px;
}

.online_status_inactive{
	background-position: 0 -48px;
}

.elggchat_session_leave{
	margin: 2px 0 0 4px;	
	float:right; 
	cursor: pointer;
	width:14px;
	height:14px;
	background: url("<?php echo $CONFIG->wwwroot; ?>mod/elggchat/_graphics/icon_customise_remove.png") no-repeat 0 0;
	
}
.elggchat_session_mini{
	margin: 2px 0 0 4px;	
	float:right; 
	cursor: pointer;
	width:14px;
	height:14px;
	background: url("<?php echo $CONFIG->wwwroot; ?>mod/elggchat/_graphics/icon_customise_min.gif") no-repeat 0 0;
	
}
.elggchat_session_leave:hover{
	background-position: 0 -16px;
}

.chatmessages{
	min-height: 250px;
	max-height: 400px;
	overflow-y:auto;
}

.elggchatinput{
	background: #FFFFFF url("<?php echo $CONFIG->wwwroot; ?>mod/elggchat/_graphics/chatwindow/chat_input.png") no-repeat 1px 50%;
	padding-left:18px;
	border-top: 1px solid #DEDEDE;
	border-bottom: 1px solid #DEDEDE;
	height:22px;
    font-size: 12px;
}

.elggchatinput input{
	border: none;
	font-size:100%;
	padding: 2px;
}

.elggchatinput input:focus{
	border: none;
	background:none;
}
