<?php
global $CONFIG;
	
	$file = $vars['entity'];
	
	$file_guid = $file->getGUID();
	$title = $file->title;
	$desc = $file->description;
	$owner = $vars['entity']->getOwnerEntity();
	if ($vars['full'] && $smallthumb = $vars['entity']->smallthumb) {
 
		echo "<p><a href=\"{$vars['url']}action/file/download?file_guid={$vars['entity']->getGUID()} \" rel=\"prettyPhoto\" title=\"$desc\"><img src=\"{$vars['url']}mod/file/thumbnail.php?file_guid={$vars['entity']->getGUID()}&size=large\"  border=\"0\" alt=\"$title\"  /></a></p>";
		
	}

?>