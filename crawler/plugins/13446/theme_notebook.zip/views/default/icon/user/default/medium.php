<?php
	echo $vars['url'] . "mod/theme_notebook/graphics/user_icons/defaultmedium.gif";
?>