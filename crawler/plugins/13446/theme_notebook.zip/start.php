<?php

    /**
     * Notebook theme
     **/
     
     /**
	 * Initialise the theme 
	 *
	 */
	function notebook_init(){
	
    }
	
	// Initialise log browser
	register_elgg_event_handler('init','system','notebook_init');
	
?>