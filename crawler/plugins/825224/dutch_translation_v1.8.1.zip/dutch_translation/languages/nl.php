<?php
	$dutch = array(
		// Main title
		'dutch_translation' => "Nederlandse Vertaling",
		
	);
	
	add_translation("nl", $dutch);