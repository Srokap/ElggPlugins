<?php
	$english = array(
		// Main title
		'dutch_translation' => "Dutch Translation",
		
	);
	
	add_translation("en", $english);
	