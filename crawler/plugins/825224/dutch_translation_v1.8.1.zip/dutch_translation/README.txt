= Dutch Translation =

Provides a Dutch translation for Elgg
