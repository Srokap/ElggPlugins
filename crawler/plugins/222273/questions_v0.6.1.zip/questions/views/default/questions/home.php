<?php
/**
 *	QUESTIONS PLUGIN
 *	@package questions
 *	@author Javier Luces jluces@df-digital.com
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) DF-Digital 2009
 *	@link http://www.df-digital.com
 **/
?>
<?php
	//require_once(dirname(dirname(dirname(dirname((__FILE__)))))."/utilities/utilities.php");

	global $CONFIG;
	gatekeeper();

	echo elgg_echo('questions:body:introduction');
?>