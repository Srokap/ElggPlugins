<?php

	/**
	* Flyers
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
	
	admin_gatekeeper();
	
	$site = get_entity(datalist_get('default_site'));
	$content_saved = false;
	
	
	if ($site) {
		if ($site->showflyer) {
			//If the content is get from siteannouncement
			$siteannouncement = get_input('siteannouncement');
			if ($siteannouncement) {
				$site->flyer_siteannouncement = $siteannouncement;
				$content_saved = true;  
			} 
			//Flyer Content
			$flyer_content = get_input('flyer_content');
			if ($flyer_content && !empty($flyer_content)) {
				$site->flyer_content = $flyer_content;
				$content_saved = true; 
			}
		}
	}
	
	if ($content_saved) {
		system_messages(elgg_echo('flyer:contentsaved'));
	} else {
		system_messages(elgg_echo('flyer:contenterror'));
	}
	forward($_SERVER['HTTP_REFERER']);
?>