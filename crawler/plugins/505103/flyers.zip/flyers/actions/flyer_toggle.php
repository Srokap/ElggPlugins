<?php
	/**
	* Flyers
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/


	require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
	
	admin_gatekeeper();
	
	$site = get_entity(datalist_get('default_site'));
	
	$status_flyer = 'activated';
	if ($site) {
		if ($site->showflyer) {
			remove_metadata($site->guid, 'showflyer');
			$status_flyer = 'deactivated';
		} else {
			$site->showflyer = true;
		}
	}
	
	if ($status_flyer == 'activated') {
		system_messages(elgg_echo('flyer:enabled'));
	} else {
		system_messages(elgg_echo('flyer:disabled'));
	}
	forward($_SERVER['HTTP_REFERER']);
?>