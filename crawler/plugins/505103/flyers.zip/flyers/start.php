<?php

	/**
	* Flyers
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	define('PLUGIN_NAME', 'flyers');
	
	function flyers_init() {
		//Event to act!
		register_elgg_event_handler('login', 'user', 'flyer_clear_user_meta');
		
		//Page Handler
		register_page_handler('flyer','flyer_page_handler');
		
		extend_view('css', 'flyer/css');
	}
	
	function flyers_setup() {
		global $CONFIG;
		if (get_context()=='admin') {
    		add_submenu_item(elgg_echo("flyer"), $CONFIG->wwwroot . "pg/flyer/setup" );
		}
		
		if (isloggedin()) {
			$site = get_entity(datalist_get('default_site'));
			$user = get_loggedin_user();
			if ($site->showflyer && !($user->flyerseen)) {
				//Show the flyer
				extend_view('page_elements/header_contents', 'flyer/show_flyer', 1);
				$user->flyerseen = true;
			}
		}
	}
	
	function flyer_page_handler($page) {
		global $CONFIG;
		if (isset($page[0])) {
			switch($page[0]) {
				case "setup":
					!@include_once(dirname(__FILE__) . "/flyer_setup.php");
					return false;
          			break;
			}
		}
	}
	
	/**
	 * This function clear the metadata flyerseen, when a user is loggin in.
	 * @param String $event
	 * @param String $object_type
	 * @param Object $object
	 */
	function flyer_clear_user_meta($event, $object_type, $object) {
		
		if($event == 'login' && $object_type=='user' && $object instanceof ElggUser) {
			//Clear metadata.
			$object->clearMetadata('flyerseen');
		}
		
		return true;
	}
	
	// Initialise Flyers Mod
	register_elgg_event_handler('init','system','flyers_init');
	register_elgg_event_handler('pagesetup','system','flyers_setup', 1);

	//	Flyer Actions
	register_action("flyer/toggle", false, $CONFIG->pluginspath . "flyers/actions/flyer_toggle.php");
	register_action("flyer/set_content", false, $CONFIG->pluginspath . "flyers/actions/flyer_set_content.php");