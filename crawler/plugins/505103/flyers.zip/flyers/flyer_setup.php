<?php

	/**
	* Flyers
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	// Get the Elgg engine
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	
	set_context('admin');
	$site = get_entity(datalist_get('default_site'));
	$flyer_content = $site->flyer_content;
	if ($site->showflyer) {
		$form_body .= elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('flyer:disable')));
		$form2_description = elgg_echo('flyer:putacontent');
		$form2_description2 = elgg_echo('flyer:showsiteannounces');
		$form2_longtext = elgg_view('input/longtext', array('value' => $flyer_content, 'internalname' => 'flyer_content'));
		$yes_option = ($site->flyer_siteannouncement == 'yes') ? " selected=\"yes\"" : "";
		$no_option = ($site->flyer_siteannouncement == 'no' || is_null($site->flyer_siteannouncement)) ? " selected=\"yes\"" : "";
		$pulldown =  "
			<select name=\"siteannouncement\">
				<option value=\"yes\"" . $yes_option . ">" . elgg_echo('option:yes') . "</option>
				<option value=\"no\"" . $no_option . ">" . elgg_echo('option:no') . "</option> 
			</select>";
		$form_body2 .= <<<EOT
			<hr />
			<br />
			<p>$form2_description</p>
			$form2_longtext
			<br />
			<p>$form2_description2<p>
			$pulldown
			<br />
EOT;
		$form_body2 .= elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('save')));
		$content2 = elgg_view('input/form', array('action' => "{$CONFIG->url}action/flyer/set_content", 'body' => $form_body2));
	} else {
		$form_body .= elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('flyer:enable')));	
	}
	
	$flyer_description = elgg_echo('flyer:description');
	$form_body = "<p>$flyer_description</p> $form_body";	
	
	$content = elgg_view('input/form', array('action' => "{$CONFIG->url}action/flyer/toggle", 'body' => $form_body));
	$content = <<<EOT
		<div class='flyer_container'>
			$content 
			$content2
		</div>
	
EOT;
	$body = elgg_view_layout('two_column_left_sidebar', '', $content . elgg_view('developed_by_keetup'));
	page_draw($title, $body);
?>