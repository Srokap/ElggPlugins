<?php
	/**
	* Flyers
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/
?>
	/* lightbox */
    #fonLB {
        width: 50%;
        height: 50%;
        background: #000;
        position: relative;
        top: 0;
        left: 0;
        z-index: 12345;
        display: none;
    }
    .lb {
        display: none;
        position: absolute;
        top: 50px;
        left: 25%;
        z-index: 123456;
    }
    .lbHome {
    	overflow-x: hidden;
    	background: #fef9f9;
    	border: 10px solid #060606;
        padding: 10px 12px 10px;
        width: 680px;
        height: 580px;
        -webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	}
    .lbHome img {
        display: block;
        position: relative;
        z-index: 1;
        top: 0;
        left: 0;
    }
    .lbHome .cerrar {
        background: red;
        color: #FFF;
        cursor: pointer;
        font-family: Arial, Lucida, Lucida Sans;
        font-size: 11px;
        font-weight: bold;
        height: 16px;
        line-height: 17px;
        padding: 0 0 1px 1px;
        position: absolute;
        left: 3px;
        text-align: center;
        top: 3px;
        width: 16px;
        z-index: 123;
        -webkit-border-radius: 4px; 
			-moz-border-radius: 4px;
    }
    
    .flyer_container {
    	padding: 5px;
    }