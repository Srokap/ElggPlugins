<?php
?>
<div style="text-align:right;">
<a href="<?php echo $vars['url']; ?>mod/elgg-crypt/crypt.html?TB_iframe=true&height=555&width=555" 
title="<?php echo elgg_echo("elgg-crypt:enterkey"); ?>" class="thickbox">
<?php echo elgg_echo("elgg-crypt:encrypt"); ?></a></div>
<br/>

