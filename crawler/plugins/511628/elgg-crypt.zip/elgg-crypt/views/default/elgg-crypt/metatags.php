<?php
// Adding encrypt/decrypt libraries to header
?>
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/elgg-crypt/vendors/jsenc/jsencryption.js"></script>
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/elgg-crypt/vendors/jsenc/jsencryptionform.js"></script>

