<?php
	$english = array(
		/**
		 * Menu items and titles
		 */
			'elgg-crypt:enterkey' => "Enter Key and Message to encrypt then copy 'Crypted Text' and paste it to use.",
			'elgg-crypt:encrypt' => "Encrypt Text",
			'elgg-crypt:decrypt' => "Decrypt Message (required encryption key)",
	);
	add_translation("en",$english);
?>
