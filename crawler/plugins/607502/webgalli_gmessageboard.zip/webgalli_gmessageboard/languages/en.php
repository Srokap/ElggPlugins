<?php

	$english = array(
	
			'groups:enablemessageboard' => "Enable group messageboard",
    		'blogs:groupprofile' => 'Group Blogs',
    		'blogs:nogroup' => 'No group blogs to display',
			'feedback:list:from' => 'From',
	);
					
	add_translation("en",$english);

?>