<?php
 
    function webgalli_gmessageboard_init()
    {
		extend_view('css','webgalli_gmessageboard/css');
		// extend the group members view
        extend_view('groups/left_column', 'webgalli_gmessageboard/group_messageboard');
		// add the group files tool option     
        add_group_tool_option('messageboard',elgg_echo('groups:enablemessageboard'),true);
    }
		register_elgg_event_handler('init','system','webgalli_gmessageboard_init');
	
?>