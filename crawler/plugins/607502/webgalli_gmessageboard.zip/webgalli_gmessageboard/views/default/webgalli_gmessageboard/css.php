<?php ?>



/* ***************************************
  GROUP MESSAGE BOARD
*************************************** */

/* input msg area */
#mb_input_wrapper_group {
	margin:0 0px 5px 0px;
	padding:5px;
	background: white;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
}

#mb_input_wrapper_group .input_textarea {
	width:315px;
}
.collapsable_box_content #mb_input_wrapper .input_textarea {
	width:259px;
}
.message_item_timestamp {
	font-size:90%;
	padding:10px 0 0 0;
}
p.message_item_timestamp {
	margin-bottom: 10px;
}
/* wraps each message */
.webgalli_gmessageboard {
	margin:0 0px 5px 0px;
	padding:0;
	background: white;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
}
.webgalli_gmessageboard .message_sender {
	float:left;
	margin: 5px 10px 0 5px;
}
/* IE6 */
* html .webgalli_gmessageboard { width: 280px; } 
* html #two_column_left_sidebar_maincontent .webgalli_gmessageboard { width: 667px; }
* html .webgalli_gmessageboard .message_sender { margin: 5px 10px 0 2px; }
* html #mb_input_wrapper .input_textarea { width:645px; }
/* IE7 */
*:first-child+html .webgalli_gmessageboard { width: 280px; } 
*:first-child+html #two_column_left_sidebar_maincontent .webgalli_gmessageboard { width: 698px; }
*:first-child+html .webgalli_gmessageboard .message_sender { margin: 5px 10px 0 2px; }

.webgalli_gmessageboard .message p {
	line-height: 1.2em;
	background:#dedede;
	margin:0 6px 4px 6px;
	padding:4px;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	overflow-y:hidden;
	overflow-x:auto;
	color:#333333;
}

.gmessage_buttons {
	padding:0 0 3px 4px;
	margin:0;
	font-size: 90%;
	color:#666666;
}

.webgalli_gmessageboard .delete_message a {
	display:block;
	float:right;
	cursor: pointer;
	width:14px;
	height:14px;
	margin:0 3px 3px 0;
	background: url("<?php echo $vars['url']; ?>_graphics/icon_customise_remove.png") no-repeat 0 0;
	text-indent: -9000px;
}
.webgalli_gmessageboard .delete_message a:hover {
	background-position: 0 -16px;
}

.river_group_messageboard {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_comment.gif) no-repeat left -1px;	
}





