<?php
	/**
	 * Elgg lastlogin plugin
	 * 
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette fabrice.collette@free.fr
	 * @copyright Fabrice Collette
	 * @link http://www.meleze-online.net
	 */




	$french = array(
	       'lastlogin:online' => '- en ligne -',
	       'lastlogin:lastconnexion' => 'Dernier passage',
	       'lastlogin:hours' => 'heures',
	       'lastlogin:hour' => "moins d'1 heure"
	       
		
	);
					
	add_translation("fr",$french);
?>