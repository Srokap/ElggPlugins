<?php

	/**
	 * Elgg lastlogin plugin
	 * 
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette fabrice.collette@free.fr
	 * @copyright Fabrice Collette
	 * @link http://www.meleze-online.net
	 */

		
		function lastlogin_init() {
			extend_view('css','lastlogin/css');
      extend_view('profile/icon','lastlogin/profile_extend',600);
			global $CONFIG;
			// Load the language file
			register_translations($CONFIG->pluginspath . "lastlogin/languages/");
		}

		register_elgg_event_handler('init','system','lastlogin_init');
				
		
?>