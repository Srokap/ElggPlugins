<?php
/**
	 * Elgg add_to_any plugin
	 * 
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette fabrice.collette@free.fr
	 * @copyright Fabrice Collette
	 * @link http://www.meleze-online.net
	 */

?>

#lastlogin {
  text-align: center;
  font-size: 0.8em;
	padding:1px 0 5px 0;
}

#lastlogin_online {
  text-align: center;
  color:#e69601;
  font-size: 0.8em;
	padding:1px 0 5px 0;
}

#lastlogin_online_puce {
	padding:5px 2px 0 0;
}
