<?php

	/**
	 * Elgg add_to_any plugin
	 * 
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette fabrice.collette@free.fr
	 * @copyright Fabrice Collette
	 * @link http://www.meleze-online.net
	 */
      if (get_context() == "profile"){
      $last_action = $vars['entity']->last_action;
      if ((time() - $last_action)< 600) {
      
        $contents .= "<div id=\"lastlogin_online\" style=\"text-align:center;\">".elgg_echo('lastlogin:online')."</div>";
	    
	      }
	    
      else {
    
	    $lastlogin = intval((time() - $last_action)/(3600));
	    
	    $contents .= "<div id=\"lastlogin\" style=\"text-align:center;\">".elgg_echo('lastlogin:lastconnexion')." : ";
	    if ($lastlogin > 3) {
	         $contents .= " ".date("d/m/y", $last_action)."</div>";
	         } else 
              if ($lastlogin > 1) {
                  $contents .= " ".elgg_echo('lastlogin:hours')."</div>";
	               } else {
	                 $contents .= " ".elgg_echo('lastlogin:hour')."</div>";
                 }
	    
      }
      echo $contents;
  }
    
?>