<?php
echo elgg_view('js/languages', array('language' => 'de'));