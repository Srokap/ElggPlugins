<?php
/**
 * Categories German language file
 */

$german = array(
	'categories' => 'Kategorien',
	'categories:settings' => 'Seiten-Kategorien einrichten',
	'categories:explanation' => 'Um einige Kategorien festzulegen, die für die gesamte Community-Seite benutzt werden, gebe sie bitte im folgenden mit Komma getrennt ein. Kompatible Tools werden die Kategorien dann anzeigen, wenn Mitglieder Einträge erzeugen oder editieren.',
	'categories:save:success' => 'Seiten-Kategorien wurden gespeichert.',
	'categories:results' => "Treffer für die Seiten-Kategorie: %s",
	'categories:on_enable_reminder' => "Du hast noch keine Kategorieren eingerichtet!  <a href=\"%s\">Kategorien jetzt hinzufügen.</a>",
        'categories:on_activate_reminder' => "Die seitenübergreifenden Kategorien sind erst verwendbar, nachdem Kategorien hinzugefügt wurden. <a href=\"%s\">Kategorien jetzt hinzufügen.</a>",
);

add_translation("de", $german);