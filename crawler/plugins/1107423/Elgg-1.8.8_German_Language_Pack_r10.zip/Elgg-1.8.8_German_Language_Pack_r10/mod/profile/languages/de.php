<?php
/**
 * Elgg profile plugin language pack
 */

$german = array(
	'profile' => 'Profil',
	'profile:notfound' => 'Entschuldigung, wir konnten das gesuchte Profil nicht finden.',

);

add_translation('de', $german);