<?php
/**
 * Tag cloud German language file
 */

$german = array(
	'tagcloud:widget:title' => 'Tagcloud',
	'tagcloud:widget:description' => 'Tagcloud',
	'tagcloud:widget:numtags' => 'Anzahl der anzuzeigenden Tags.',
);

add_translation('de', $german);