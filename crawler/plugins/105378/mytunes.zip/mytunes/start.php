<?php

  
    function mytunes_init() 
    {	
        add_widget_type('mytunes',elgg_echo("My Tunes"),elgg_echo("My Tunes"));	    
    }

     
    // Make sure the status initialisation function is called on initialisation
    register_elgg_event_handler('init','system','mytunes_init');
	

		
?>