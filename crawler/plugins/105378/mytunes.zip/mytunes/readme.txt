My Tunes MP3 Player Widget.

Original Flash player from: http://www.e-phonic.com/mp3player/#
you can remove 3 sec nag screen by purchasing.

Just unzip to your mod folder and activate the plugin.

It searches for any "audio/mpeg" file avaliable at user files and creates a playlist for.

includes 4 skin packs you can change skin in view.php

For additional info on customizing the flash player, see http://www.e-phonic.com/mp3player/documentation/
