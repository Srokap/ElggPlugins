<?php

   //the page owner
   $owner = $vars['entity']->owner_guid;
   //The maximum mp3 files on playlist	
   $number = 10000;
   $playlist = "";
   $titles = "";
   
   
	
   //get the user's files
   $files = get_user_objects($vars['entity']->owner_guid, "file", $number, 0);

   //if there are some files, go get them
   if ($files) 
   {
	   
	   
	   //display in list mode
      foreach($files as $f)
      {
          $mime = $f->mimetype;
          if ($mime == "audio/mpeg")
          {
            if ($playlist)
            {
              $playlist = '<track><location>' . $playlist . '</location><creator></creator><title>' . $titles . '</title></track>';
			}
			$playlist = $playlist . $vars['url'] . 'action/file/download?file_guid=' . $f->guid;
			$titles = $titles . $f->title;
          }
      }
	          
    } 
//    else 
//    {
//	    echo elgg_echo("No Files");
//    }

?>

<!-- flash player -->
<script src="<?php echo $vars['url']; ?>mod/mytunes/swfobject/swfobject.js" type="text/javascript"></script>
<center>
<div id="mytunes">
</div><!--
<a href="#" onclick='javascript:window.open("<?php //echo $vars['url']; ?>mod/mytunes/pop.php","pwin", "height=350,width=400,status=yes,toolbar=no,menubar=no,location=no");'><img src="<?php //echo $vars['url']; ?>mod/mytunes/graphics/open.jpg" style="margin-top: 3px;" border="0">-->
</center>

<script type="text/javascript">
	// <![CDATA[

	var so = new SWFObject("<?php echo $vars['url']; ?>mod/mytunes/audioplayer/ep_player.swf", "ep_player", "<?php echo $vars['entity']->width; ?>", "<?php echo $vars['entity']->height; ?>", "9", "#FFFFFF");
	so.addParam("WMODE", "transparent");
	so.addVariable("skin", "<?php echo $vars['url']; ?>mod/mytunes/audioplayer/skins/<?php echo $vars['entity']->mytunes; ?>");
	so.addVariable("playlistxml", "<?php echo $playlist; ?>");
	so.addVariable("autoplay", "true");
	so.addVariable("volume", "50");
	so.addVariable("repeat", "false");
	so.addVariable("shuffle", "false");
	so.addVariable("buffertime", "1");
	so.write("mytunes");

	// ]]>
</script>
