<?php

	/**
	 * Elgg MyTunes Plugin
	 * 
	 * @package My Tunes
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Donkey Designs
	 * @copyright Donkey Designs 2009
	 * @link http://donkeydesigns.us/
	 * 
	 */

?>
<div align="left">
<div><b><?php echo elgg_echo('Choose Your Skin'); ?></b></div>
<div>
    <select name="params[mytunes]">
    <option value="nobius_platinum/skin.xml"><?php echo elgg_echo('Nobius Platinum'); ?></option>
    <option value="alien_green/skin.xml"><?php echo elgg_echo('Alien Green'); ?></option>
    <option value="micro_player/skin.xml"><?php echo elgg_echo('Micro Player'); ?></option>
    <option value="nobius_blue/skin.xml"><?php echo elgg_echo('Nobius Blue'); ?></option>
    </select>
</div>
<div><hr align="center" width="100%" size="1" noshade="noshade" /></div>
<div>
  <p><b>Manually enter size for player!</b></p>
  <ul>
  <li>Micro Player: 300 x 15</li>
  <li>Nobius Platinum: 270 x 225</li>
  <li>Nobius Blue: 270 x 220</li>
  <li>Alien Green: 220 x 265</li>
  </ul>
</div>
<div>Width:&nbsp; <br /><input name="params[width]" type="text" value="270" /></div>
<div>Height: <br /><input name="params[height]" type="text" value="225"></div>
<div><hr align="center" width="100%" size="1" noshade="noshade" /></div>
</div>