<?php

	/**
	 * Elgg MyTunes Plugin
	 * 
	 * @package My Tunes
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Donkey Designs
	 * @copyright Donkey Designs 2009
	 * @link http://donkeydesigns.us/
	 * 
	 */
?>

<!-- flash player -->
<script src="<?php echo $vars['url']; ?>mod/mytunes/swfobject/swfobject.js" type="text/javascript"></script>
<center>
<div id="mytunes" style="margin-top:5px;">
</div>
</center>

<script type="text/javascript">
	// <![CDATA[

	var so = new SWFObject("<?php echo $vars['url']; ?>mod/mytunes/audioplayer/ep_player.swf", "ep_player", "<?php echo $vars['entity']->width; ?>", "<?php echo $vars['entity']->height; ?>", "9", "#FFFFFF");
	so.addParam("WMODE", "transparent");
	so.addVariable("skin", "<?php echo $vars['url']; ?>mod/mytunes/audioplayer/skins/<?php echo $vars['entity']->mytunes; ?>");
	so.addVariable("playlistxml", "<?php echo $playlist; ?><?php echo $creator; ?><?php echo $titles; ?>");
	so.addVariable("autoplay", "true");
	so.addVariable("volume", "50");
	so.addVariable("repeat", "false");
	so.addVariable("shuffle", "false");
	so.addVariable("buffertime", "1");
	so.write("mytunes");

	// ]]>
</script>
