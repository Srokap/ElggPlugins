<?php
  /**
   * Empty view to override FOAFSSL button when locked down.
   * @todo existing users should still be able to use a WebID to login.
  **/
?>
