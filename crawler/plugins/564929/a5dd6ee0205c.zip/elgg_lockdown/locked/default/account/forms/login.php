<?php
/**
 * Elgg login form
 *
 * @package Elgg
 * @subpackage Core
 * @author Curverider Ltd
 * @link http://elgg.org/
 */

global $CONFIG;

$form_body = '';

$form_body.= '<div class="required">';
$form_body.= '<label for="username">' . elgg_echo('username') . '</label>';
$form_body.= '<br />';
$form_body.= elgg_view('input/text', array('internalname' => 'username', 'class' => 'login-textarea'));
$form_body.= '</div>';

$form_body.= '<div class="required">';
$form_body.= '<label for="password">' . elgg_echo('password') . '</label>';
$form_body.= '<br />';
$form_body.= elgg_view('input/password', array('internalname' => 'password', 'class' => 'login-textarea'));
$form_body.= '</div>';

if (is_plugin_enabled('foafssl')) {
    $form_body.= elgg_view('foafssl/loginbox');
}

$form_body.= '<div id="persistent_login" class="optional">';
$form_body.= '<input type="checkbox" name="persistent" value="true" />';
$form_body.= '<label for="persistent">' . elgg_echo('user:persistent') . '</label>';
$form_body.= '</div>';

$form_body .= elgg_view('input/submit', array('value' => elgg_echo('login')));

$form_body .= '<p class="loginbox">';
$form_body .= "<a href=\"{$vars['url']}account/forgotten_password.php\">" . elgg_echo('user:password:lost') . "</a></p>";

$login_url = $vars['url'];
if ((isset($CONFIG->https_login)) && ($CONFIG->https_login)) {
	$login_url = str_replace("http", "https", $vars['url']);
}
?>
<div id="login-box">
    <h2><?php echo elgg_echo('login'); ?></h2>
<div class="auth_method" id="passwd_login">
<?php
    echo elgg_view('input/form', array('body' => $form_body, 'action' => "{$login_url}action/login"));
?>
</div>
<?php /* echo elgg_view('login/extend'); */ ?>
</div>
<script type="text/javascript">
	$(document).ready(function() { $('input[name=username]').focus(); });
</script>
