<?php
  /**
   * Empty view to ovverride OpenID form when locked down.
   * Users can still use OpenID in the regular form.
  **/
?>