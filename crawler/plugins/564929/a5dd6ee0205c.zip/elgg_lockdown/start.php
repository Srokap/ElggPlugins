<?php
/**
 * Elgg Lockdown Plugin
 *
 * Allow administrators to lock down the site and suspend user
 * registration functionality.  Users will be able to authenticate
 * with whatever login mechanism is available, but only if they
 * already have a local user account.  
 *
 * This plugin is part of the Lorea Framework (http://lorea.org/)
 * Copyright 2010 Lorea.org
**/

function lockdown_init()
{
    elgg_extend_view('css', 'lockdown/css');

    $lockdown_state = lockdown_state();
    ("unlocked" == $lockdown_state) ? lockdown_unlock() : lockdown_lock();
}

/**
 * Return the current state of lockdown
 * @return String locked | unlocked
**/
function lockdown_state() 
{
  return get_plugin_setting('lockdown_state', 'lockdown');
}

/**
 * Activate lockdown
 *
 * It will disable registration in the configuration,
 * and override login views.
**/
function lockdown_lock()
{
    if (TRUE !== get_config('disable_registration'))
        set_config('disable_registration', TRUE);
    $view_location = get_config('pluginspath') . 'lockdown/locked/';
    set_view_location("account/forms/login", $view_location, 'default');
//    if (is_plugin_enabled('foafssl')) {
//        set_view_location("foafssl/loginbox", $view_location, 'default');
//    }
    if (is_plugin_enabled('openid_client')) {
        set_view_location("openid_client/forms/login", $view_location, 'default');
        elgg_extend_view('js/initialise_elgg', 'lockdown/js');
    }
    if ('locked' != lockdown_state())
        set_plugin_setting('lockdown_state', 'locked');
//    error_log("lockdown_lock complete");
}

/**
 * Restore original functionality
 *
 * It will reactivate user self-registration functionality
 * and release views from the locked sandbox.
**/
function lockdown_unlock()
{
    if (FALSE !== get_config('disable_registration'))
        set_config('disable_registration', FALSE);
    if ('unlocked' != lockdown_state())
        set_plugin_setting('lockdown_state', 'unlocked');
//    error_log("lockdown_unlock complete");
}

register_elgg_event_handler('init','system','lockdown_init');
