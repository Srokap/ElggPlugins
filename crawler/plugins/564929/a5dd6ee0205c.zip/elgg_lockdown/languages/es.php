<?php

$spanish = array(
         'lockdown:title'          => 'Bloquear el registro de usuarios',
         'lockdown:lock:title'     => 'Bloquear el registro de usuarios en el sitio.',
         'lockdown:lock:notice'    => "Los usuarios no podrán registrar nuevas cuentas: solo los administradores podrán crear cuentas.",
         'lockdown:unlock:title'   => 'Restaurar el registro de usuarios en el sitio.',
         'lockdown:unlock:notice'  => "Cualquier persona podrá resigistrar una cuenta.",
         'lockdown:locked'         => 'Solo las admins pueden crear cuentas.',
         'lockdown:unlocked'       => 'El registro de usuarios está desbloqueado.'
);

add_translation("es", $spanish);
?>
