<?php

$english = array(
         'lockdown:title'          => 'Lock Down User Registration',
         'lockdown:lock:title'     => 'Turn off user registration functionality on the site',
         'lockdown:lock:notice'    => "Users won't be able to register a new account: only administrators will be able to create new accounts.",
         'lockdown:unlock:title'   => 'Restore user registration functionality on the site',
         'lockdown:unlock:notice'  => "Users will be able to register a new account themselves.",
         'lockdown:locked'         => 'User registration functionality is disabled.',
         'lockdown:unlocked'       => 'User registration functionality is enabled.'
);

add_translation("en", $english);
?>
