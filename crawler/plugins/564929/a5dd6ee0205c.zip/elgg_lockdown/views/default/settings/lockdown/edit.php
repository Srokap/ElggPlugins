<div id="lockdown_settings">
<?php

global $CONFIG;
$lockdown_state = lockdown_state();

echo '<h3>', elgg_echo('lockdown:title'), '</h3>';

echo '<p class="notice">', elgg_echo("lockdown:$lockdown_state"), '</p>';

?>
<div>
<input type="radio" name="params[lockdown_state]" value="locked" 
  <?php if ("locked" == $lockdown_state) echo 'checked="true"'; ?> />
<label><?php echo elgg_echo("lockdown:lock:title"); ?></label>
<p><?php echo elgg_echo("lockdown:lock:notice"); ?></p>
</div>
<div>
<input type="radio" name="params[lockdown_state]" value="unlocked"
  <?php if ("locked" != $lockdown_state) echo 'checked="true"'; ?> />
<label><?php echo elgg_echo("lockdown:unlock:title"); ?></label>
<p><?php echo elgg_echo("lockdown:unlock:notice"); ?></p>
</div>
</div>
