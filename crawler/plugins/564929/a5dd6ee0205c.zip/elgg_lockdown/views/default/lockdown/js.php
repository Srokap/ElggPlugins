<?php

if (is_plugin_enabled('openid_client')) {

?>
(function($) {

    $(document).ready(function() {

        var $username = $('#login-box input[type="text"]');
        var $password = $('#login-box input[type="password"]');

        var lockdown_host_regex = new RegExp("(^<?php echo $vars['url']; ?>|@<?php echo str_replace(array('http://','https://', '/'), '', $vars['url']); ?>$)", 'ig');
        $username.keyup(function(e) {
            var $in = $username.attr('value');
            // if user@localnode.example.org force passwd_login
            if ($in.match(lockdown_host_regex) != null ||
                  ($in.indexOf('@') == -1 && $in.indexOf(':/') == -1)) {
                $password.attr('disabled', false).css('opacity', 1);
                $username.css('background-image', 'url(/mod/lockdown/graphics/user.png)');
                $('#login-box label[for="username"]').text('<?php echo elgg_echo('username'); ?>');
            } else {
                $password.attr('disabled', 'disabled').css('opacity', 0.5);
                $password.disabled = true;
                $username.css('background-image', 'url(/mod/lockdown/graphics/openid-16x16.gif)');
                $('#login-box label[for="username"]').text('OpenID Identifier');
            }
        });


    });

})(jQuery);
<?php } ?>
