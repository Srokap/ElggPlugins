#index_welcome #login-box, 
#login-box,
#login-box form { 
    width: auto; 
}

#foafssl_login {
  float: right;
  margin: 30px 15px;
}

#login-box input[type="text"] {
  padding-left: 20px;
  background: transparent url(/mod/lockdown/graphics/user.png) 2px 2px no-repeat;
}

#login-box input[type="password"] {
  padding-left: 20px;
  background: transparent url(/mod/lockdown/graphics/key.png) 2px 2px no-repeat;
}
