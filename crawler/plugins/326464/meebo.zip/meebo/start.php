<?php
  function meebo_init() {        
    add_widget_type('meebo', 'Meebo Widget', 'The meebo widget');
  }
 
  register_elgg_event_handler('init','system','meebo_init');       
?>