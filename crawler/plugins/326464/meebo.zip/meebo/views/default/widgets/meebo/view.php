<div class="contentWrapper">
<!--Your Meebo Embed code below-->
<div style="width:210px"><style>.mcrmeebo { display: block; background:url("http://widget.meebo.com/r.gif") no-repeat top right; } .mcrmeebo:hover { background:url("http://widget.meebo.com/ro.gif") no-repeat top right; } </style><object width="210" height="350" ><param name="movie" value="http://widget.meebo.com/mcr.swf?id=fQTfHopXeO"/><embed src="http://widget.meebo.com/mcr.swf?id=fQTfHopXeO" type="application/x-shockwave-flash" width="210" height="350" /></object><a href="http://www.meebo.com/rooms" class="mcrmeebo"><img alt="http://www.meebo.com/rooms" src="http://widget.meebo.com/b.gif" width="210" height="45" style="border:0px"/></a></div>
<!--Your Meebo Embed code above-->
</div>
