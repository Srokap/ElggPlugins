<?php
/**
 * Latest blog entries
 * 
 * @package BlogLatest
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Alistair Young <alistair@codebrane.com>
 * @copyright codeBrane 2010
 * @link http://codebrane.com/blog/
 */

$german = array(
	// River
	"item:object:bloglatest" => "Neueste Nachrichten",
	
	// Widget name
	"bloglatest:start:widget:name" => "Neueste Nachrichten",
	
	// bloglatest edit view
	"bloglatest:view:edit:posttype:text" => "Nachrichtentyp",
	"bloglatest:view:edit:posttype:all:text" => "Blog und Hei�er Draht",
	"bloglatest:view:edit:posttype:blog:text" => "Blog",
	"bloglatest:view:edit:posttype:wire:text" => "Hei�er Draht",
	"bloglatest:view:edit:restricttofriends" => "Auf Freunde beschr�nken",
	"bloglatest:view:edit:username:text" => "Benutzername",
	"bloglatest:view:edit:tags:text" => "Tags",
	"bloglatest:view:edit:noofposts:text" => "Anzahl der Nachrichten",
	"bloglatest:view:edit:excerptlength:text" => "L�nge des Auszugs",
	
	// bloglatest main view
	"bloglatest:view:allusers:text" => "Alle Benutzer",
);

add_translation("de", $german);
?>
