<?php
/**
 * Elgg default widget view
 *
 * @package Elgg
 * @subpackage Core
 */

echo elgg_view('widgets/wrapper',$vars);
