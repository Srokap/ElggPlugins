<?php
/**
 * This view provides a hook for third parties to provide captcha behaviour.
 *
 * @package Elgg
 * @subpackage Core
 */
?>