<?php
/**
 * Elgg basic about page
 * The standard HTML about page
 *
 * @package Elgg
 * @subpackage Core
 *
 */
?>

<!-- still to do -->