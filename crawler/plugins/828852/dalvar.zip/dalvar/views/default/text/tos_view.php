<?php
/**
 * Elgg basic tos page
 *
 * @package Elgg
 * @subpackage Core
 *
 */
?>