<?php
/**
 * Elgg administration main screen
 *
 * @package Elgg
 * @subpackage Core
 */

// Description of what's going on
echo "<p>" . elgg_view('output/longtext', array('value' => elgg_echo("admin:description"))) . "</p>";
