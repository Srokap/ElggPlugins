<?php
/**
 * Elgg 2 column right sidebar canvas layout
 *
 * @package Elgg
 * @subpackage Core
 */
?>

<div id="blog_edit_page">

<?php if (isset($vars['area1'])) echo $vars['area1']; ?>

</div>