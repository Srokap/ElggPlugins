<?php
/**
 * Elgg one-column layout
 *
 * @package Elgg
 * @subpackage Core
 */
?>

<!-- main content -->
<div id="one_column">

<?php echo $vars['area1']; ?>

</div><!-- /one_column -->