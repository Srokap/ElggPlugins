<?php
/**
 *
 * @package Elgg
 * @subpackage Core
 *
 */

echo elgg_echo('river:noaccess');