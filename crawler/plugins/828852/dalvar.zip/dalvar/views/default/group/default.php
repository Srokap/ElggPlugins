<?php
/**
 * ElggGroup default view.
 *
 * @package Elgg
 * @subpackage Core
 */

echo elgg_view('object/default', $vars);
?>