<?php
/**
 * @package Elgg
 * @subpackage Core
 */
?>