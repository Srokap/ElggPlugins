<?php
/**
 * Elgg settings specific user settings.
 *
 * @package Elgg
 * @subpackage Core
 */

?>