<?php
if (isloggedin()) forward('pg/dashboard');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>My Network!</title>
  <meta charset="utf-8">
  
  <link rel="stylesheet" href="mod/dalvar/css/reset.css" type="text/css" media="all">
  <link rel="stylesheet" href="mod/dalvar/css/grid.css" type="text/css" media="all">
  <link rel="stylesheet" href="mod/dalvar/css/style.css" type="text/css" media="all">
  <link rel="stylesheet" href="mod/dalvar/css/jquery-ui-1.8.5.custom.css" type="text/css" media="all">
  <script type="text/javascript" src="mod/dalvar/js/jquery-1.4.2.min.js" ></script>
	<script type="text/javascript" src="mod/dalvar/js/jquery.cycle.all.js"></script>
  <script type="text/javascript" src="mod/dalvar/js/jquery-ui-1.8.5.custom.min.js"></script>
  
  
  <!--[if lt IE 9]>
  	<script type="text/javascript" src="mod/dalvar/js/html5.js"></script>
  <![endif]-->
</head>
<script type="text/javascript">
$(document).ready(function () {
	$('.messages').animate({opacity: 1.0}, 1000);
	$('.messages').animate({opacity: 1.0}, 5000);
	$('.messages').fadeOut('slow');

	$('span.closeMessages a').click(function () {
		$(".messages").stop();
		$('.messages').fadeOut('slow');
	return false;
	});

	$('div.messages').click(function () {
		$(".messages").stop();
		$('.messages').fadeOut('slow');
	return false;
	});
});
</script>
<script type="text/javascript">
$(document).ready(function () {
	$('.messages_error').animate({opacity: 1.0}, 1000);
	$('.messages_error').animate({opacity: 1.0}, 5000);
	$('.messages_error').fadeOut('slow');

	$('span.closeMessages a').click(function () {
		$(".messages_error").stop();
		$('.messages_error').fadeOut('slow');
	return false;
	});

	$('div.messages').click(function () {
		$(".messages").stop();
		$('.messages').fadeOut('slow');
	return false;
	});
});
</script>
	
	

<?php $messages = system_messages();	
	$message = $messages['messages'];
	
	if(count($message) > 0){ 
		echo '<div class="messages">';
		echo '<span class="closeMessages"><a href="#">click to dismiss</a></span>';
			foreach($message as $message1)
					{
					echo '<p>';
					echo $message1;
					echo '</p>';
					}
		echo '</div>';
	}

	$errors = register_error();
	$error = $errors['errors'];
	if(count($error) > 0){ 
		echo '<div class="messages_error">';
		echo '<span class="closeMessages"><a href="#">click to dismiss</a></span>';
			foreach($error as $error1)
					{
					echo '<p>';
					echo $error1;
					echo '</p>';
					}
		echo '</div>';
	}


////////////////////////////////////////////////////////////////////////////////////////////////
?>
<body>
  <header>
    <nav>
    	<div class="container">
        <div class="wrapper">
          <h1><strong>SW Social Web</strong></h1>
          <ul>
          	
            <li><a href="pg/register">Register</a></li>
            
          </ul>
        </div>
      </div>
    </nav>

  </header>
  <section id="content">
  	<div class="top">
    	<div class="container">
      	<div class="clearfix">
          <section id="gallery">
          	<div class="pics">
            	<img src="mod/dalvar/images/slide1.jpg" alt="" width="495" height="329">
             
           
            </div>
           
          </section>
          <section id="intro">
          	<div class="inner">
          	  <h2>Have an account?<span>Sign in!</span></h2>
              <p><?php
									$form_body = 
									"
										
										<label style='font-size:18px; color: black'>"
										.elgg_echo('username')
										."<br />"
										.elgg_view
										(
											'input/text'
											,array
											(
												'internalname' => 'username'
												,'class' => 'login-textarea'
											)
										)
										."</label><br />
									";
									$form_body .=
										"<label style='font-size:18px; color: black'>"
										.elgg_echo('password')
										."<br />" 
										.elgg_view
										(
											'input/password'
											,array
											(
												'internalname' => 'password'
												,'class' => 'login-textarea'
											)
										)
										."</label><br /><br />
									";
									$form_body .=
										elgg_view
										(
											 'input/submit'
											,array
											(
												'value' => elgg_echo('login')
											)
										)
										."</p>
									";
									echo elgg_view
									(
										'input/form'
										,array
										(
											 'body' => $form_body
											,'action' => ""
											.$vars['url']
											."action/login"
										)
									);
									?></p>
             
          	</div>
          </section>
        </div>
      </div>
    </div>
    <div class="middle">
    	<div class="container">
      	<div class="wrapper">
        	<div class="grid3 first">
          
          </div>
        	<div class="grid9">
          	<h2>About our network</h2>
           <p>Fusce euismod consequat ante. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Pellentesque sed dolor. Aliquam congue fermentum nisl. Mauris accumsan nulla vel diam. Sed in lacus ut enim adipiscing aliquet. Nulla venenatis. In pede m aliquet sit amet, euismod in, auctor ut, ligula. Aliquam dapibus tincidunt metus. Praesent justo dolor, lobortis quis, lobortisissim, pulvinar ac, lorem. Vestibulum sed ante. Donec sagittis euismod purus.Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta. </p> 
           
          </div>
        </div>
      </div>
    </div>
    <div class="bottom">
    	<div class="container">
      	<div class="wrapper">
        	<div class="grid3 first">
            <h3>Contact info</h3>
            <ul class="list1">
              <li><a href="#">info@demo.com</a></li>
              <li><a href="#">support@demo.com</a></li>
              <li><a href="#">help@demo.com</a></li>
            </ul>
          </div>
          <div class="grid3">
            <h3>Links</h3>
            <ul class="list2">
              <li><a href="#">Terms</a></li>
              <li><a href="#">Privacy</a></li>
              <li><a href="#">Careers</a></li>
              <li><a href="#">Blog</a></li>
              <li><a href="#">Twitter</a></li>
            </ul>
          </div>
          <div class="grid3">
            <h3>About</h3>
            <ul class="list2">
              <li><a href="#">Our site</a></li>
              <li><a href="#">Background</a></li>
              <li><a href="#">Press</a></li>
              <li><a href="#">Contact Us</a></li>
            
            </ul>
          </div>
          <div class="grid3">
          	<div id="datepicker"></div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <footer>
    <div class="container">
    	<div class="wrapper">
      	<div class="copy">SW Social Web (c) 2011  | Derechos Reservados</div>
        <address class="phone">
        	Designed by <strong>SW Social Web</strong>
        </address>
      </div>
    </div>
  </footer>
  <script type="text/javascript">
		$(document).ready(function() {
			$('.pics').cycle({
				fx: 'toss',
				next:   '#next', 
				prev:   '#prev' 
			});
			
			// Datepicker
			$('#datepicker').datepicker({
				inline: true
			});
			
		});
	</script>
</body>
</html>