<?php

/**
	
 * Google Search plugin
	 * 

	 * @package Elgg 1.5
	 

* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	
 * @author Joban John (j06anj0hn@gmail.com) 2009 
	
 * @copyright (c)Joban John (j06anj0hn@gmail.com) 2009 
	
 * @link http://phpqa.blogspot.com
	
 */


require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
global $CONFIG;

?>
<html>
<script src="http://www.google.com/jsapi" type="text/javascript"></script>
<script language="Javascript" src="<?php echo $CONFIG->wwwroot; ?>vendors/jquery/jquery-1.2.6.pack.js"></script>
<script language="Javascript" type="text/javascript">
google.load('search', '1');    function OnLoad() { var searchControl = new google.search.SearchControl(); searchControl.addSearcher(new google.search.WebSearch()); searchControl.addSearcher(new google.search.ImageSearch()); searchControl.addSearcher(new google.search.VideoSearch()); searchControl.addSearcher(new google.search.BlogSearch()); searchControl.addSearcher(new google.search.NewsSearch()); var localSearch = new google.search.LocalSearch(); searchControl.addSearcher(localSearch); searchControl.addSearcher(new google.search.BookSearch()); searchControl.addSearcher(new google.search.PatentSearch()); localSearch.setCenterPoint("New York, NY"); searchControl.draw(document.getElementById("searchcontrol")); searchControl.execute(""); searchControl.setSearchCompleteCallback(this,OnSearchComplete); } google.setOnLoadCallback(OnLoad); function OnSearchComplete(sc, searcher) { var heights       = $("#googiesearch").height(); var rotating = parent.document.getElementById('sample'); rotating.style.height= heights+"px"; $("#googleadd").show();  }
</script>   

<style type="text/css">

#searchcontrol{
  width:270px; 
  font-size:13px;
}
.gs-result{
 font-size:13px;
}
.gsc-results{
 display:block;
 width:265px;	
}
.gsc-bookResult .gsc-videoResult .gs-patentResult .gsc-imageResult .gsc-localResult .gsc-blogResult .gsc-webResult .gsc-patentResult .gs-text-box{
  font-size:13px;
}
.gsc-resultsRoot{
  font-size:13px;
}
#googleadd{
  display:none;
  text-align:center;
}
</style>
 </head>
  <body>
  <div id="googiesearch">
    <div id="searchcontrol">Loading</div> 
    <div id="googleadd">   
	<script type="text/javascript"><!--
	google_ad_client = "pub-9270046623087859";	/* 234x60, created 7/14/09 */ google_ad_slot = "1387414099"; google_ad_width = 234; google_ad_height = 60; //-->
	</script>
	<script type="text/javascript"
	src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
	</script>
</div>
   </div> 
  </body>
</html>
