<?php    

 /*

	
 * Google Search plugin
	 * 

	 * @package Elgg 1.5
	
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	
 * @author Joban John (j06anj0hn@gmail.com) 2009 
	
 * @copyright (c)Joban John (j06anj0hn@gmail.com) 2009 
	 
* 
@link http://phpqa.blogspot.com
	 
*/

?>

Go to http://google.com/cse and create your own search engine and earn revenue using adsense and
Copy and paste your code from http://google.com/cse