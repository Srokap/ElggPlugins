<?php
/**
	 * Google Search plugin
	 * 
	 * @package Elgg 1.5
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Joban John (j06anj0hn@gmail.com) 2009 
	 * @copyright (c)Joban John (j06anj0hn@gmail.com) 2009 
	 * @link http://phpqa.blogspot.com
	 */

 function googleSearch_init() {
  //extend css if style is required
  add_widget_type('googleSearch',"Google Search","Display google Search on a widget ");
}
register_elgg_event_handler('init','system','googleSearch_init');
?>
