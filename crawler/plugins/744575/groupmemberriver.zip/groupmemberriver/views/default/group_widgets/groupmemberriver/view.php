<?php 
$group = $vars["group"];

	$widget = $vars["widget"];
	echo elgg_view('groupmemberriver/groupmemberprofile', array('entity' => $group));
?>
