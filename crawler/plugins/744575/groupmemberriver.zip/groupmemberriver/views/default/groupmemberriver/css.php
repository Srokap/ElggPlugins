<?php

	/**
	* Activity River for Groups
	*
	*
	* @author Jon Maul, Jon Dron
	* @copyright The MITRE Corporation 2010
	* @link http://www.mitre.org/
	*/

?>

/* group river widget */
#group_river_widget {
	margin:0 0 20px 0;
	padding: 0 0 5px 0;
	-webkit-border-radius: 8px;
	-moz-border-radius: 8px;
}
#group_river_widget .search_listing {
	border: 2px solid;
}
