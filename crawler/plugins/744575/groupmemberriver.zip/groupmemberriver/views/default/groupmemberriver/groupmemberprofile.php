<?php 
		/*
		** Activity River for Groups
		*
		*
		* @author Jon Maul, Jon Dron
		* @copyright The MITRE Corporation 2010
		* @link http://www.mitre.org/
		
		* modified to enable/disable, show all activity for group members and set number to display
		*/



		$owner = page_owner_entity();
		$group_guid = $owner->guid;
		$limit = 10;  // TODO: make configurable

		$offset = (int) get_input('offset', 0);
// only show this if enabled
if ($owner->groupmemberriver_enable=='yes') {
?>

<div id="group_river_widget">
	<h2><?php echo elgg_echo('group_custom_layout:widgets:groupmemberriver:title'); ?></h2>
	<?php
		$pagination = false; // also should be customizable
	?>
	<div id="group_river_widget_content">
		<?php
			if ($pagination) { ?>
				<style type="text/css">
					.river_pagination { display: inline; }
				</style>
		<?php
			}
		?>

		<?php

		// Sanitise variables -- future proof in case they get sourced elsewhere
		$limit = (int) $limit;
		$offset = (int) $offset;
		$group_guid = (int) $group_guid;

		//this is the bit that gets activity from members of this group
		//whatever they have done on the site
		$sql=get_group_member_river_items(0,$group_guid);
		//print_r($sql);
		$items = get_data($sql);

        if (count($items) > 0) {
			if ($pagination) {
				$group_river = array_slice($items, $offset);
			}
			$river_items = elgg_view('river/item/list',array(
												'limit' => $limit,
												'offset' => $offset,
												'items' => $items,
												'pagination' => $pagination
											));
		}
		echo $river_items;

		?>

	</div>
</div>
<?php
} //endif check whether enabled
?>