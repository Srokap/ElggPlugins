<?php

  /**
   * Activity River for Groups
   *
   *
   * @author Jon Maul, Jon Dron, Curverider
   * @copyright The MITRE Corporation 2010, Athabasca University 2011
   * @link http://www.mitre.org/
	* combines Jon Maul's group profile with Brian Jorgensen's MT_activity_tabs and some tweaks by Jon Dron
   */

  function groupmemberriver_init() {
	global $CONFIG;
 	extend_view('groups/right_column', 'groupmemberriver/groupmemberprofile');
	extend_view('css', 'groupmemberriver/css');
	if (is_plugin_enabled("group_custom_layout")&&$pageowner->groupmemberriver_enable!='no'){
		add_group_widget("groupmemberriver", elgg_echo("groupmemberriver:widget:title"));
	}
	add_group_tool_option('groupmemberriver',elgg_echo('groupmemberriver:widget:title'),false);
  }

/**
 *  get group member activity
 */
function get_group_member_river_items($subject_guid = 0, $group_guid , $type = 'object', $subtype = '', $action_type = '',
$limit = 20, $offset = 0, $posted_min = 0, $posted_max = 0) {

    // get CONFIG
    global $CONFIG;

    // Sanitise variables
    if (!is_array($subject_guid)) {
        $subject_guid = (int) $subject_guid;
    } else {
        foreach($subject_guid as $key => $temp) {
            $subject_guid[$key] = (int) $temp;
        }
    }
    if (!empty($group_guid)) {
        $group_guid = (int) $group_guid;
    }
    if (!empty($type)) {
        $type = sanitise_string($type);
    }
    if (!empty($subtype)) {
        $subtype = sanitise_string($subtype);
    }
    if (!empty($action_type)) {
        $action_type = sanitise_string($action_type);
    }
    $limit = (int) $limit;
    $offset = (int) $offset;
    $posted_min = (int) $posted_min;
    $posted_max = (int) $posted_max;

    // Construct 'where' clauses for the river
    $where = array();

    // HUH?
    $where[] = str_replace("and enabled='yes'",'',str_replace('owner_guid','subject_guid',get_access_sql_suffix()));

    // grab array of users in this collection
    //$collection_users = get_members_of_access_collection($collection_guid, true);
    $group_users = get_group_members($group_guid);

    // if collection is empty, return false
    if (empty($group_users)) {
        return false;
    }

    //
    $wherein = " subject_guid in (";

    // iterate
    foreach($group_users as $user) {
        $wherein .= $user->guid . ',';

    }

    // strip final comma
    $wherein = rtrim($wherein, ',');

    $wherein .= ') ';

    $where[] = $wherein;

	if (!empty($type)) {
		$where[] = " type = '{$type}' ";
	}

    //
    $whereclause = implode(' and ', $where);

    // Construct main SQL
    // annotation_id field added in 1.7?
    $sql = "select id,type,subtype,action_type,access_id,view,subject_guid,object_guid,posted" .
	 		" from {$CONFIG->dbprefix}river where {$whereclause} order by posted desc limit {$offset},{$limit}";

    // Get data
    return $sql;

}


  register_elgg_event_handler('init', 'system', 'groupmemberriver_init');

?>
