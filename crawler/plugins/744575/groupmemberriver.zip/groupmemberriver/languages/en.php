<?php

   /**
   * Activity River for Groups
   *
   *
   * @author Jon Maul, Jon Dron
   * @copyright The MITRE Corporation 2010, Jon Dron 2011
   * @link http://www.mitre.org/
   */

$english = array(
    'groupmemberriver:widget:title' => 'Show site-wide member activity',
    'group_custom_layout:widgets:groupmemberriver:title' => 'Site-wide group member activity',
    'groupmemberriver:widget:description' => 'Site-wide group member activity',
    'groupmemberriver:setting' => 'Show member activity across the whole site',

 	);

  add_translation('en',$english);

?>
