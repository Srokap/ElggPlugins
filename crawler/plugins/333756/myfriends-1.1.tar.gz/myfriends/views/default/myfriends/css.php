<?php

	/**
     * Elgg Online Members plugin
     * Members Online interface for Elgg sites
     * 
     * @package Online Members
     * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
     * @author Shannon Anderson
     * @copyright Shannon Anderson
     * @link http://www.squidworks.net
	 */

?>

#myfriendsWrapper {
	position: fixed;
	top: 250px;
	left: 0px;
	width: 450px;
	z-index:1; 
}

#myfriendsToggler {
	float: left;
}

#myfriendsContent {
	width: 400px;
	display: none;
	overflow: hidden;
	float: left;
	border: solid #ccc 1px;
	background-color: #ffffe0;
}

#myfriendsError {
	color: #ff0000;
}

#myfriendsSuccess {
	color: #00ff00;
}

.myfriendsLabel {
}

.myfriendsText {
	width:350px;  
}

.myfriendsTextbox {
	width:350px;  
	height:75px;
}
 
.captcha {
	padding:10px;
}
.captcha-left {
	float:left;
	border:1px solid #0000ff;
}
.captcha-middle {
	float:left;
}
.captcha-right {
	float:left;
}
.captcha-input-text {
	width:100px;
}
