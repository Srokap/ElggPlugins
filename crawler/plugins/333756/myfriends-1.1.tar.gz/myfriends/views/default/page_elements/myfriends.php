<?php
    /**
     * Elgg Online Friends plugin
     * My Friends online interface for Elgg sites
     * 
     * @package Online Friends
     * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
     * @author Shannon Anderson
     * @copyright Shannon Anderson
     * @link http://www.squidworks.net
     */

	global $CONFIG;

  $user_ip = $_SERVER[REMOTE_ADDR];
  $user_id = elgg_echo('myfriends:default:id');
  if ( isloggedin () ) 
  {
    $user_id = $_SESSION['user']->name . " (" . $_SESSION['user']->email .")";
      
  
  $open_img = '<img src="'.$CONFIG->wwwroot.'mod/myfriends/_graphics/slide-button-open.gif" alt="'.elgg_echo('myfriends:label').'" title="'.elgg_echo('myfriends:label').'" />';
  $close_img = '<img src="'.$CONFIG->wwwroot.'mod/myfriends/_graphics/slide-button-close.gif" alt="'.elgg_echo('myfriends:label').'" title="'.elgg_echo('myfriends:label').'" />';

?>

  <div id="myfriendsWrapper">
  <div id="myfriendsToggler">
    <a id="myfriendsTogglerLink" href="javascript:void(0)" onclick="myfriends_Toggle();this.blur();" style="float:left;position:relative;left:-1px;">
      <?php echo $open_img ?>
    </a>
  </div>
		
  <div id="myfriendsContent">
    <div style="padding:10px;">        
      <h1 style="padding-bottom:10px;">
        <?php echo elgg_echo('myfriends:title'); ?>
      </h1>
      <div style="padding-bottom:10px;">
        <?php echo elgg_echo('myfriends:message'); ?>
      </div>

<?php
  $showFriendIcon = get_plugin_usersetting("friends_icons",$_SESSION['user']->guid,"myfriends") != "false";
  $friends = $_SESSION['user']->getFriends("",1000);
  $friends_online = 0;
  if (count($friends) > 0) {
    echo "<table width=100%>";
      foreach ($friends as $friend) {
	$icon = $friend->getIcon('topbar');
        if ($friend->last_action < time() - 600) {
        // Consider them offline if no action for 10 mins ..

        } elseif ($friend->last_action < time() - 300) {
          echo "<tr>";
	  if ($showFriendIcon) echo "<td width=10><img src='$icon'></td>";
	  echo "<td style='padding-left: 5px;'><a href=\"" . $CONFIG->wwwroot . "mod/messages/send.php?send_to=" . $friend->guid . "\">" . $friend->name . "</a></td><td width=10 style='padding-top: 3px;'>";
          echo "<img src='" . $CONFIG->wwwroot . "mod/myfriends/_graphics/inactive.gif'>";
          $friends_online ++;
        } else {
          echo "<tr>";
	  if ($showFriendIcon) echo "<td width=10><img src='$icon'></td>";
	  echo "<td style='padding-left: 5px;'><a href=\"" . $CONFIG->wwwroot . "mod/messages/send.php?send_to=" . $friend->guid . "\">" . $friend->name . "</a></td><td width=10 style='padding-top: 3px;'>";
          echo "<img src='" . $CONFIG->wwwroot . "mod/myfriends/_graphics/online_s.png'>";
          $friends_online ++;
        }
        echo "</td></tr>";
      }
    echo "</table>";
  }

  if ($friends_online == 0) {
    echo "No friends online";
  }else{ echo "Friends online";}
  echo " = <b>" . $friends_online . "</b>";

?>





    </div>
  </div>

  <div style="clear:both;"></div>
    
</div>
<?php } ?> 
<script type="text/javascript">

<?php 
  // if user is logged in then disable the myfriends ID
  if ( isloggedin () ) { 
    echo "$('#myfriends_id').attr ('disabled', 'disabled');";
  }
?>
$("#myfriendsWrapper").width("50px");
$('#myfriendsClose').hide();

var toggle_state = 0;

function myfriends_Toggle()
{
    if ( toggle_state ) 
    {
      toggle_state = 0;
      $("#myfriendsWrapper").width("50px");
      $("#myfriendsTogglerLink").html('<?php echo $open_img?>');
      $('#myfriendsFormInputs').show();
			$("#myfriendsFormStatus").html("");
      $('#myfriendsClose').hide();
    }
    else 
    {
      toggle_state = 1;
      $("#myfriendsWrapper").width("450px");
      $("#myfriendsTogglerLink").html('<?php echo $close_img?>');
    }

    $("#myfriendsContent").toggle();
}


</script>
