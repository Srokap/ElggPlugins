<?php
    /**
     * Elgg Online Friends plugin
     * My Friends interface for Elgg sites
     * 
     * @package Online members
     * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
     * @author Shannon Anderson
     * @copyright Shannon Anderson
     * @link http://www.squidworks.net
     */

    /*
     * Initialize Plugin
     */
	function myfriends_init() {
	
        global $CONFIG;

		// page handler        
		register_page_handler('myfriends','myfriends_page_handler');
        
        // load the language translations
        register_translations($CONFIG->pluginspath . "myfriends/languages/");
        
        // extend the view
		extend_view('page_elements/footer', 'page_elements/myfriends');
		
		// extend the site CSS
		extend_view('css','myfriends/css');			                       
	}
	
	/**
	 * My Friends Page handler
	 *
	 */
	function myfriends_page_handler($page)
	{
		@include(dirname(__FILE__) . "/myfriends.php");
		return true;
	}
	
	register_elgg_event_handler('init','system','myfriends_init');
	
	global $CONFIG;

?>