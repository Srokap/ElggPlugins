<?php

    /**
     * Elgg Online friends plugin
     * My Friends Online interface for Elgg sites
     * 
     * @package Online friends
     * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
     * @author Shannon Anderson
     * @copyright Shannon Anderson
     * @link http://www.squidworks.net
     */

	$english = array(

		'item:object:myfriends' => 'My Friends',
		'myfriends:label' => 'My Friends',
		'myfriends:title' => 'My Online Friends',

		'myfriends:message' => 'Select a friend to message',
		
		'myfriends:default:id' => 'Name and/or Email',
		'myfriends:default:txt' => 'Let us know what you think!',
		'myfriends:default:txt:err' => 'No My Friends message has been provided.\nWe value your suggestions and criticisms.\nPlease enter your message and press Send.',

		'myfriends:captcha:blank' => 'No captcha input provided',
		
		'myfriends:submit_msg' => 'Submitting...',
		'myfriends:submit_err' => 'Could not submit My Friends!',
		
		'myfriends:submit:error' => 'Could not submit My Friends!',
		'myfriends:submit:success' => 'My Friends submitted successfully. Thank you!',
		
		'myfriends:admin:menu' => 'My Friends for Site',
		'myfriends:admin:title' => 'Site My Friends',
		
		'myfriends:delete:success' => 'My Friends was deleted successfully',
		
		'myfriends:mood:' => 'None',
		'myfriends:mood:angry' => 'Angry',
		'myfriends:mood:neutral' => 'Neutral',
		'myfriends:mood:happy' => 'Happy',

		'myfriends:about:' => 'None',
		'myfriends:about:bug_report' => 'Bug Report',
		'myfriends:about:content' => 'Content',
		'myfriends:about:suggestions' => 'Suggestions',
		'myfriends:about:compliment' => 'Compliment',
		'myfriends:about:other' => 'Other',
		
		'myfriends:list:mood' => 'Mood',
		'myfriends:list:about' => 'About',
		'myfriends:list:page' => 'Submit Page',
		'myfriends:list:from' => 'From',
	);
					
	add_translation("en",$english);
?>