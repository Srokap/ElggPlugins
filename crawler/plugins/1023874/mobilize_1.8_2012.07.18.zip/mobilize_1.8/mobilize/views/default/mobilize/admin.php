<?php

/**
 *  Admin CSS
 */

?>

/* ***************************************
	SETTINGS
*****************************************/
#mobilize-settings{
	width: 460px;
    padding:30px;
    border:1px solid #CCC;
}
#mobilize-settings .label{
	font-size: 1.2em;
    font-weight: bold;
}
#mobilize-settings .elgg-input-dropdown{
	float: right;
	margin-left:8px;
}

