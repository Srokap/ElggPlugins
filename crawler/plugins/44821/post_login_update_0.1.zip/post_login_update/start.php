<?php
    /**
        * Post User Login Update Plugin
        *
        * @package ElggPostLoginUpdate
        * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
        * @author Prashant Juvekar
        * @copyright SocialTrak, 2009
        * @link http://www.socialtrak.com
        */
		
	function post_login_update_init(){
		global $CONFIG;
		register_elgg_event_handler('login', 'user', 'post_login_update_handler', 501);
	}

	function post_login_update_handler($event, $object_type, $object) {

			$user = $object;
			$username = $user->username;
			global $CONFIG;

            // do any followup operations on successfull login
			
			// ensure "admin" is a friend for all users ... if you want
			// any other user just use it below
			if ( ($username != "admin") && ($admin = get_user_by_username ("admin")) ) {
			
				if(isset($CONFIG->events['create']['friend'])) {
					$oldEventHander = $CONFIG->events['create']['friend'];
					$CONFIG->events['create']['friend'] = array();			//Removes any event handlers
				}

				try {
					$user->addFriend ( $admin->guid );
				} catch(Exception $e) {}
				try {
					$admin->addFriend ( $user->guid );
				} catch(Exception $e) {}
				//system_message ( "Added admin as friend" );

				if(isset($CONFIG->events['create']['friend'])) {
					$CONFIG->events['create']['friend'] = $oldEventHander;
				}
			}
            
			// put out a greeting message ... this could be customized
			// depending on user's profile, etc. 
			system_message ( "Welcome " . $user->name . " to " . $CONFIG->wwwroot );
	}

	//register plugin initialization handler
	register_elgg_event_handler('init', 'system', 'post_login_update_init');

?>
