
/*
 * Post User Login Update Plugin
 *
 * @package ElggPostLoginUpdate
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Prashant Juvekar
 * @copyright SocialTrak, 2009
 * @link http://www.socialtrak.com
 *
 */

This is simple module that hooks onto the user's login event
and allows the module writer to do some interesting things
upon successfull logon by changing the code in the handler
function (see start.php:post_login_update_handler). 

Default implementation has code that will add an user called
"admin" as the friend for the user logging in. This ensures
that all user's that get into the system have the admin as 
their friend. There is also a message displayed greeting the 
user. This could be a place to place user's profile dependent
customized messages. It could also be used to nag the user to
fill out their profiles. 

This module was developed and is used at www.socialtrak.com
for the above two purposes (add admin as friend and nag about
incomplete profiles).

The username could be made configurable and also the message
displayed on logon. If you would like that functionality let
us know at: admin@socialtrak.com
