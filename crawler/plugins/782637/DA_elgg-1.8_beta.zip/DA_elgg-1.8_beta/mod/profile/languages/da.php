<?php
/**
 * Profile Danish language file
 */

$danish = array(
	'profile' => "Profil",
	'profile:notfound' => "Beklager, vi kunne ikke finde den ønskede profil.",


);

add_translation("da",$danish);

?>