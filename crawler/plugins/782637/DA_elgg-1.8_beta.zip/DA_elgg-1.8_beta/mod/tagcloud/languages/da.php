<?php
/**
 * Tag cloud Danish language file
 */

$danish = array(
	'tagcloud:widget:title' => 'Tag Cloud',
	'tagcloud:widget:description' => 'Tag cloud',
	'tagcloud:widget:numtags' => 'Antal tags, der skal vises',
);

add_translation('da',$danish);

?>