<?php

// Generate By translationbrowser. 

$italian = array( 
	 'diagnostics'  =>  "Diagnosi Sistema" , 
	 'diagnostics:unittester'  =>  "Unità di test" , 
	 'diagnostics:description'  =>  "La seguente relazione di diagnostica è utile per diagnosticare eventuali problemi con Elgg, e dovrebbe essere applicata su qualsiasi bug report del file." , 
	 'diagnostics:unittester:description'  =>  "I seguenti sono test diagnostici che sono registrati dai plugin e può essere effettuata al fine di eseguire il debug di parti del quadro Elgg." , 
	 'diagnostics:test:executetest'  =>  "Esecuzione test" , 
	 'diagnostics:test:executeall'  =>  "Esegui tutto" , 
	 'diagnostics:unittester:notests'  =>  "Siamo spiacenti, non ci sono test di unità moduli attualmente installati. " , 
	 'diagnostics:unittester:testnotfound'  =>  "Siamo spiacenti, il rapporto non poteva essere generato perché quel test non è stato trovato" , 
	 'diagnostics:unittester:warning'  =>  "ATTENZIONE: Questi test possono lasciare il debug di oggetti nel database. NON USARE SU UN SITO DI PRODUZIONE! " , 
	 'diagnostics:unittest:example'  =>  "Esempio di unit test, disponibile solo nella modalità di debug. "
); 

add_translation('it', $italian); 

?>