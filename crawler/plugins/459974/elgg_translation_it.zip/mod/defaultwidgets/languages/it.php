<?php

// Generate By translationbrowser. 

$italian = array( 
	 'item:object:moddefaultwidgets'  =>  "Parametri base widget" , 
	 'defaultwidgets:menu:profile'  =>  "Profilo di base per gli widget" , 
	 'defaultwidgets:menu:dashboard'  =>  "Parametri base del cruscotto widget" , 
	 'defaultwidgets:admin:error'  =>  "Errore: non sei logato come amministratore" , 
	 'defaultwidgets:admin:notfound'  =>  "Errore: pagina non trovata" , 
	 'defaultwidgets:admin:loginfailure'  =>  "Attenzione: Non hai i privilegi di amministratore" , 
	 'defaultwidgets:update:success'  =>  "I parametri del tuo widget sono stati salvati" , 
	 'defaultwidgets:update:failed'  =>  "Errore: I parametri non sono stati salvati" , 
	 'defaultwidgets:update:noparams'  =>  "Errore: incongruenza nei parametri" , 
	 'defaultwidgets:profile:title'  =>  "Widget predefinito per le pagine nuovo profilo utente " , 
	 'defaultwidgets:dashboard:title'  =>  "Widget predefinito per le pagine cruscotto nuovo utente"
); 

add_translation('it', $italian); 

?>