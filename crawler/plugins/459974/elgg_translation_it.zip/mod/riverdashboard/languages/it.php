<?php

// Generate By translationbrowser. 

$italian = array( 
	 'filter'  =>  "Filtro" , 
	 'riverdashboard:useasdashboard'  =>  "Sostituire la dashboard di default con questa attività" , 
	 'activity'  =>  "Attività" , 
	 'riverdashboard:recentmembers'  =>  "Ultimi Membri" , 
	 'sitemessages:announcements'  =>  "Annunci sul sito" , 
	 'sitemessages:posted'  =>  "Aggiunti" , 
	 'sitemessages:river:created'  =>  "Sito admin, %s," , 
	 'sitemessages:river:create'  =>  "Aggiunto un nuovo sito " , 
	 'river:widget:title'  =>  "Attività" , 
	 'river:widget:title:friends'  =>  "Attività degli amici" , 
	 'river:widget:description:friends'  =>  "Mostrare ciò che i tuoi amici dicono" , 
	 'river:widgets:friends'  =>  "Amici" , 
); 

add_translation('it', $italian); 

?>