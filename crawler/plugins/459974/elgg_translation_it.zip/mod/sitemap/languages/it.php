<?php

// Generate By translationbrowser. 

$italian = array( 
	 'sitemap'  =>  "Sitemap" , 
	 'sitemap:start'  =>  "Inizio" , 
	 'sitemap:register'  =>  "Registrazione" , 
	 'sitemap:lostpassword'  =>  "Password persa" , 
	 'sitemap:settings'  =>  "Configurazione" , 
	 'sitemap:accountstatistics'  =>  "Statistiche utente" , 
	 'sitemap:notifications'  =>  "Notifiche" , 
	 'sitemap:groupnotifications'  =>  "Notifiche dei gruppi" , 
	 'sitemap:messages'  =>  "Messaggi" , 
	 'sitemap:sentmessages'  =>  "Manda messaggi" , 
	 'sitemap:friends'  =>  "Amici" , 
	 'sitemap:friendsof'  =>  "Amico di" , 
	 'sitemap:invitefriends'  =>  "Invita degli amici" , 
	 'sitemap:friendsactivity'  =>  "Attività degli amici" , 
	 'sitemap:myactivity'  =>  "La tua attività" , 
	 'sitemap:allsiteblogs'  =>  "Tutti iblog del sito" , 
	 'sitemap:yourblog'  =>  "Il tuo blog" , 
	 'sitemap:friendsblog'  =>  "Blog degli amici" , 
	 'sitemap:writeablogpost'  =>  "Scrivi un post" , 
	 'sitemap:allsitegroups'  =>  "Tutti igruppi del sito" , 
	 'sitemap:populargroups'  =>  "Gruppi piu' attivi" , 
	 'sitemap:latestgroupdiscussion'  =>  "Ultime discussioni di gruppo" , 
	 'sitemap:yourgroups'  =>  "I tuoi gruppi" , 
	 'sitemap:createanewgroup'  =>  "Crea un nuovo gruppo" , 
	 'sitemap:allsitefiles'  =>  "File del sito" , 
	 'sitemap:yourfiles'  =>  "I tuoi file" , 
	 'sitemap:yourfriendsfiles'  =>  "File dei tuoi amici" , 
	 'sitemap:uploadafile'  =>  "Carica i file" , 
	 'sitemap:allsitepages'  =>  "Tutte le pagine" , 
	 'sitemap:pagesHome'  =>  "Home page" , 
	 'sitemap:friendsbookmarks'  =>  "Segnalibro degli amici" , 
	 'sitemap:getbookmarklet'  =>  "Inserisci appunto" , 
	 'sitemap:allsitemembers'  =>  "Tutti  gli utenti" , 
	 'sitemap:activemembers'  =>  "Attivazione utenti" , 
	 'sitemap:allsitephotoalbums'  =>  "Tutti gli album del sito" , 
	 'sitemap:mostrecentimages'  =>  "Ultime immagini" , 
	 'sitemap:Mostviewedimages'  =>  "Immagini piu' viste" , 
	 'sitemap:recentlyviewedimages'  =>  "Immagini recentemente visitate" , 
	 'sitemap:recentlycommentedimages'  =>  "Commenti alle immagini " , 
	 'sitemap:yourphotoalbums'  =>  "Tuoi album foto" , 
	 'sitemap:yourfriendsphotoalbums'  =>  "Gli album dei tuoi amici" , 
	 'sitemap:yourmostviewedphotoalbums'  =>  "Le immagini piu' viste" , 
	 'sitemap:yourmostrecentphotoalbums'  =>  "Immagini recenti" , 
	 'sitemap:createnewphotoalbum'  =>  "Crea un nuovo album"
); 

add_translation('it', $italian); 

?>