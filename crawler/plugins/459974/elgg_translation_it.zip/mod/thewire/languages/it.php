<?php

// Generate By translationbrowser. 

$italian = array( 
	 'thewire'  =>  "In tempo reale" , 
	 'thewire:user'  =>  "Le ultime di %s" , 
	 'thewire:posttitle'  =>  "Le note di %s in tempo reale: %s" , 
	 'thewire:everyone'  =>  "Tutti i post in tempo reale" , 
	 'thewire:read'  =>  "Post in tempo reale" , 
	 'thewire:strapline'  =>  "%s" , 
	 'thewire:add'  =>  "Post in diretta" , 
	 'thewire:text'  =>  "Una nota in tempo reale" , 
	 'thewire:reply'  =>  "Replica" , 
	 'thewire:wired'  =>  "Postato in tempo reale" , 
	 'thewire:charleft'  =>  "caratteri a sx" , 
	 'item:object:thewire'  =>  "Post in diretta" , 
	 'thewire:notedeleted'  =>  "cancellate le note" , 
	 'thewire:doing'  =>  "Cosa stai facendo? Dillo a tutti in tempo reale: " , 
	 'thewire:newpost'  =>  "Nuovo post in diretta" , 
	 'thewire:addpost'  =>  "Scrivi in diretta" , 
	 'thewire:river:created'  =>  "%s postato" , 
	 'thewire:river:create'  =>  "In diretta" , 
	 'thewire:sitedesc'  =>  "Questo widget mostra le ultime note del sito inviate in diretta" , 
	 'thewire:yourdesc'  =>  "Questo widget mostra le ultime note del sito inviate in diretta" , 
	 'thewire:friendsdesc'  =>  "Questo widget vi mostrerà le ultime notizie in tempo reale dei tuoi amici" , 
	 'thewire:friends'  =>  "I tuoi amici attualmente in diretta" , 
	 'thewire:num'  =>  "Numero delle richieste da visualizzare" , 
	 'thewire:posted'  =>  "Il tuo messaggio è stato inviato in diretta. " , 
	 'thewire:deleted'  =>  "Il tuo post in diretta è stato cancellato con successo" , 
	 'thewire:blank'  =>  "Ci dispiace, dovete effettivamente mettere qualcosa nella casella di testo prima che si possa salvare. " , 
	 'thewire:notfound'  =>  "Ci dispiace, ma non abbiamo trovato in diretta il post specificato." , 
	 'thewire:notdeleted'  =>  "Ci dispiace, non siamo riusciti a cancellare questo post" , 
	 'thewire:smsnumber'  =>  "Il tuo numero di SMS, se diverso dal tuo numero di cellulare (il  numero di telefono cellulare deve essere impostato a \"pubblico\" per  per essere in grado di utilizzarlo in tempo reale). Tutti i numeri di telefono deve essere in formato internazionale. " , 
	 'thewire:channelsms'  =>  "Il numero per inviare messaggi SMS a è% s "
); 

add_translation('it', $italian); 

?>