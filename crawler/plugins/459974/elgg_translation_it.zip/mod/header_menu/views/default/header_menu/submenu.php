<!-- Dhruva Menu-->

<?php 
//		<li><a href='" . $vars['url'] . "pg/settings/plugins/" . $_SESSION['user']->username . "/' title='Configure Your Tools'>Configure Your Tools</a></li>
//		<li><hr></li>
//		<li><a href='" . $vars['url'] . "pg/groups/new/' title='Create a Group'>Create a Group</a></li>
//   	<li><a class='top_dir' href='" . $vars['url'] . "pg/forum/siteforum'><img src='" . $vars['url'] . "mod/header_menu/images/discussions.png' /> Forum</a></li>
//  	<li><a class='top_dir' href='" . $vars['url'] . "pg/forum/siteforum'><img src='" . $vars['url'] . "mod/header_menu/images/discussions.png' /> Forum</a></li>			

if (isloggedin()){

	echo "<table width='100%' cellspacing='0' cellpadding='0'>
  <tr>
    <td width='65px'>&nbsp;</td>
    <td>
<div class='clearfloat'></div>
<div >";

	echo "<ul id='nav' class='dropdown dropdown-horizontal'>

	<li><a class='top_dir' href='" . $vars['url'] . "'><img src='" . $vars['url'] . "mod/header_menu/images/home.png' /> Home</a>

		<ul>
		<li><a href='" . $vars['url'] . "'> Home Page</a></li>
		<li><a href='" . $vars['url'] . "pg/expages/read/About/' title='About the Site'>Info sito</a></li>
		<li><a href='" . $vars['url'] . "pg/expages/read/Terms/' title='Terms of Service'>Termini del servizio</a></li>
		<li><a href='" . $vars['url'] . "pg/expages/read/Privacy/' title='Privacy Policy'>Privacy Policy</a></li>
		<li><hr /></li>
		<li><a href='" . $vars['url'] . "mod/invitefriends/' title='Invite Friends'>Invita gli amici</a></li>
		</ul></li>

	<li><a class='top_dir' href='" . $vars['url'] . "pg/dashboard/'><img src='" . $vars['url'] . "mod/header_menu/images/dashboard.png' /> Principale</a></li>
						
	<li><a class='top_dir' href='" . $vars['url'] . "pg/settings/'><img src='" . $vars['url'] . "mod/header_menu/images/settings.png' /> Configurazione</a>

		<ul>
		<li><a href='" . $vars['url'] . "pg/settings/' title='My Settings'>Cambia Nome & Password</a></li>
		<li><a href='" . $vars['url'] . "mod/profile/editicon.php' title='Change My Icon'>Cambia la mia immagine</a></li>
		<li><a href='" . $vars['url'] . "pg/profile/" . $_SESSION['user']->username . "' title='View My Profile'>Guarda Profilo</a></li>
		<li><a href='" . $vars['url'] . "mod/profile/edit.php?username=" . $_SESSION['user']->username . "' title='Edit My Profile'>Edita il Profilo</a></li>
		<li><hr /></li>
		<li><a href='" . $vars['url'] . "mod/notifications/' title='Notifications'>Notifiche</a></li>
		<li><a href='" . $vars['url'] . "mod/notifications/groups.php' title='Group Notifications'>Notifiche Gruppo</a></li>
		</ul></li>

	<li><a class='top_dir' href='" . $vars['url'] . "mod/blog/everyone.php'><img src='" . $vars['url'] . "mod/header_menu/images/blog.png' /> Blog</a>

		<ul>
		<li><a href='" . $vars['url'] . "mod/blog/everyone.php' title='All Blogs'>Tutti i Blog</a></li>
		<li><a href='" . $vars['url'] . "pg/blog/" . $_SESSION['user']->username . "' title='My Blogs'>Mio Blog</a></li>
		<li><a href='" . $vars['url'] . "pg/blog/" . $_SESSION['user']->username . "/friends/' title='Friends Blogs'>Blog Amici</a></li>
		<li><hr /></li>
		<li><a href='" . $vars['url'] . "mod/blog/add.php' title='Add a blog post'>Aggiungi post al Blog</a></li>
		</ul></li>

	<li><a class='top_dir' href='" . $vars['url'] . "pg/questions/allquestions?order_by=time_created&criteria=desc'><img src='" . $vars['url'] . "mod/header_menu/images/question.png' /> Richieste</a>
	
		<ul>
		<li><a href='" . $vars['url'] . "pg/questions/allquestions?order_by=time_created&criteria=desc' title='All Questions'>All Questions</a></li>
		<li><a href='" . $vars['url'] . "pg/questions/yours' title='Your Questions'>Your Questions</a></li>
		<li><a href='" . $vars['url'] . "pg/questions/new' title='New Questions'>New Question</a></li>
		<li><a href='" . $vars['url'] . "pg/questions/notanswered' title='Not Answered'>Not Answered</a></li>
		</ul></li>
		
	<li><a class='top_dir' href='" . $vars['url'] . "pg/groups/world/?filter=active'><img src='" . $vars['url'] . "mod/header_menu/images/group.png' /> Gruppi</a>

		<ul>
		<li><a href='" . $vars['url'] . "pg/groups/world/?filter=active' title='Latest Discussion'>Ultime Discussioni</a></li>
			<li><hr /></li>
		<li><a href='" . $vars['url'] . "pg/groups/world/?filter=newest' title='All Groups'>Tutti i Gruppi</a></li>
		<li><a href='" . $vars['url'] . "pg/groups/member/" . $_SESSION['user']->username . "' title='My Groups'>I miei Gruppi</a></li>
		<li><a href='" . $vars['url'] . "pg/groups/world/?filter=pop' title='Popular Groups'>Gruppi piu' Popolari</a></li>
		</ul></li>

	<li><a class='top_dir' href='" . $vars['url'] . "mod/members/index.php?filter=newest'><img src='" . $vars['url'] . "mod/header_menu/images/members.png' /> Membri</a>

		<ul>
		<li><a href='" . $vars['url'] . "pg/vazco_gmap/members/map/' title='Users World Map'>Mappe degli utenti</a></li>
		<li><hr /></li>		
		<li><a href='" . $vars['url'] . "pg/vazco_karma/members/extend/?filter=karma' title='Top Users'>Utenti piu' seguiti</a></li>
		<li><a href='" . $vars['url'] . "mod/members/index.php?filter=newest' title='Newest'>Nuovi</a></li>
		<li><a href='" . $vars['url'] . "mod/members/index.php?filter=active' title='Logged In'>Attivi</a></li>
		<li><hr /></li>
		<li><a href='" . $vars['url'] . "pg/friends/" . $_SESSION['user']->username . "title='My Friends'>Miei Amici</a></li>
		</ul></li>

	<li><a class='top_dir' href='" . $vars['url'] . "pg/photos/world/'><img src='" . $vars['url'] . "mod/header_menu/images/thumbnail.png' /> Foto</a>

		<ul>
		<li><a href='" . $vars['url'] . "pg/photos/world/' title='All Photos'>Tutte le foto</a></li>
		<li><a href='" . $vars['url'] . "pg/photos/owned/" . $_SESSION['user']->username . "' title='My Photos'>Mie Foto</a></li>
		<li><a href='" . $vars['url'] . "pg/photos/mostrecent' title='Most recent'>Piu' Recenti</a></li>
		<li><a href='" . $vars['url'] . "pg/photos/mostviewed' title='Most viewed'>Piu' Viste</a></li>
		<li><hr /></li>
		<li><a href='" . $vars['url'] . "pg/photos/new/" . $_SESSION['user']->username . "' title='Create New Album'>Creaun nuovo Album</a></li>
		</ul></li>

	<li><a class='top_dir' href='" . $vars['url'] . "mod/thewire/everyone.php'><img src='" . $vars['url'] . "mod/header_menu/images/wire.png' /> In Diretta</a></li>

	<li><a class='top_dir' href='" . $vars['url'] . "pg/izap_videos/world/all/'><img src='" . $vars['url'] . "mod/header_menu/images/tv.png' /> Video</a>

		<ul>
		<li><a href='" . $vars['url'] . "pg/izap_videos/world/all/' title='Tutti video'>Tutti i Video</a></li>
		<li><a href='" . $vars['url'] . "pg/izap_videos/" . $_SESSION['user']->username . "/list/' title='Miei Video'>Miei Video</a></li>
		<li><a href='" . $vars['url'] . "pg/izap_videos/" . $_SESSION['user']->username . "/friends/' title='Video Amici'>Video Amici</a></li>
		<li><hr /></li>
		<li><a href='" . $vars['url'] . "pg/izap_videos/" . $_SESSION['user']->username . "/add/' title='Add a Video'>Aggiungi un Video</a></li>
		</ul></li>	
"; 

} else {

	echo "<table width='100%' cellspacing='0' cellpadding='0'>
  <tr>
    <td width='140px'>&nbsp;</td>
    <td>
<div class='clearfloat'></div>
<div >";

   echo "<ul id='nav' class='dropdown dropdown-horizontal'>

	<li><a class='top_dir' href='" . $vars['url'] . "'><img src='" . $vars['url'] . "mod/header_menu/images/home.png' /> Home</a></li>
	<li><a class='top_dir' href='" . $vars['url'] . "pg/dashboard/'><img src='" . $vars['url'] . "mod/header_menu/images/dashboard.png' /> Principale</a></li>
	<li><a class='top_dir' href='" . $vars['url'] . "mod/blog/everyone.php'><img src='" . $vars['url'] . "mod/header_menu/images/blog.png' /> Blog</a></li>
	<li><a class='top_dir' href='" . $vars['url'] . "pg/event_calendar/'><img src='" . $vars['url'] . "mod/header_menu/images/events.png' /> Eventi</a></li>
	<li><a class='top_dir' href='" . $vars['url'] . "pg/groups/world/?filter=active'><img src='" . $vars['url'] . "mod/header_menu/images/group.png' /> Gruppi</a></li>
	<li><a class='top_dir' href='" . $vars['url'] . "mod/members/index.php?filter=newest'><img src='" . $vars['url'] . "mod/header_menu/images/members.png' /> Membri</a></li>
	<li><a class='top_dir' href='" . $vars['url'] . "pg/photos/world/'><img src='" . $vars['url'] . "mod/header_menu/images/thumbnail.png' /> Foto</a></li>
	<li><a class='top_dir' href='" . $vars['url'] . "mod/thewire/everyone.php'><img src='" . $vars['url'] . "mod/header_menu/images/wire.png' /> In Diretta</a></li>
	<li><a class='top_dir' href='" . $vars['url'] . "pg/izap_videos/world/all'><img src='" . $vars['url'] . "mod/header_menu/images/tv.png' /> Video</a></li>
";
} 
?>
</div><div class='clearfloat'></div>

</td>
    <td width="1px">&nbsp;</td>
  </tr>
</table>

<!-- Dhruva Menu END-->
