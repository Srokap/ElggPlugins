<?php
 
    function header_menu_init()
    {
       	extend_view('css','header_menu/css');
        extend_view('page_elements/header_contents','header_menu/submenu');
    }
 
    register_elgg_event_handler('init','system','header_menu_init');
 
?>