<?php

	$english = array(
	
	
			'headermenu:members' => "Membri",
			'headermenu:photos' => "Foto",
			'headermenu:groups' => "Gruppi",
			'headermenu:videos' => "Video",
			'headermenu:current' => "attualmente �:",
			'headermenu:andmore' => "di piu'...",
			'headermenu:home' => "Home",
			'headermenu:blogs' => "Blog",
			'headermenu:bookmarks' => "Preferiti",
			'headermenu:ads' => "Annunci",
			'headermenu:discussions' => "Discussioni",
			'headermenu:events' => "Eventi",
			'headermenu:wire' => "In diretta",
			'headermenu:public' => "Visibile a tutti.",
			'headermenu:register' => "Registrati,",
			'headermenu:access' => "maggior accesso.",

			
	);
	
	add_translation("en",$english);

?>
