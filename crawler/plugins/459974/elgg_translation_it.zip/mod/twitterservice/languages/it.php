<?php

// Generate By translationbrowser. 

$italian = array( 
	 'twitterservice'  =>  "Servizi Twitter" , 
	 'twitterservice:postwire'  =>  "Impostando l'opzione di seguito tutti i messaggi di posta in diretta verrà inviata al tuo account Twitter. Vuoi inserire i tuoi messaggi in diretta a Twitter?" , 
); 

add_translation('it', $italian); 

?>