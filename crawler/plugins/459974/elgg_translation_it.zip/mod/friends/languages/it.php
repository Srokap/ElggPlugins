<?php

// Generate By translationbrowser. 

$italian = array( 
	 'friends:widget:description'  =>  "Mostra alcuni dei tuoi amici"
); 

add_translation('it', $italian); 

?>