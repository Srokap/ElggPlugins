<?php

// Generate By translationbrowser. 

$italian = array( 
	 'blog'  =>  "Blog" , 
	 'blogs'  =>  "Blogs" , 
	 'blog:user'  =>  "%s's blog" , 
	 'blog:user:friends'  =>  "%s's blog degli amici" , 
	 'blog:your'  =>  "Il tuo Blog" , 
	 'blog:posttitle'  =>  "%s's blog: %s" , 
	 'blog:friends'  =>  "Blog degli amici" , 
	 'blog:yourfriends'  =>  "Gli ultimi blog tuoi amici " , 
	 'blog:everyone'  =>  "Tutti i blog del sito" , 
	 'blog:newpost'  =>  "Nuovo contenuto del blog" , 
	 'blog:via'  =>  "via blog" , 
	 'blog:read'  =>  "Leggi Blog" , 
	 'blog:addpost'  =>  "Scrivi un argomento sul blog" , 
	 'blog:editpost'  =>  "Edita un post del blog" , 
	 'blog:text'  =>  "Blog testo" , 
	 'blog:strapline'  =>  "%s" , 
	 'blog:never'  =>  "mai" , 
	 'blog:preview'  =>  "Anteprima" , 
	 'blog:draft:save'  =>  "Salva bozza" , 
	 'blog:draft:saved'  =>  "Ultima bozza salvata" , 
	 'blog:comments:allow'  =>  "Permetti commenti " , 
	 'blog:preview:description'  =>  "Questo è un anteprima del tuo post non ancora salvata." , 
	 'blog:preview:description:link'  =>  "Per continuare a modificare o salvare il tuo post, clicca qui." , 
	 'blog:enableblog'  =>  "Abilita blog di gruppo" , 
	 'blog:group'  =>  "Blog di gruppo" , 
	 'blog:river:created'  =>  "%s ha scritto " , 
	 'blog:river:updated'  =>  "%s ha aggiornato" , 
	 'blog:river:posted'  =>  "%s ha inserito" , 
	 'blog:posted'  =>  "Il tuo post sul blog è stato inviato con successo." , 
	 'blog:deleted'  =>  "Il tuo post sul blog è stato cancellato con successo." , 
	 'blog:save:failure'  =>  "Il tuo post sul blog non ha potuto essere salvato. Riprova." , 
	 'blog:blank'  =>  "Ci dispiace, è necessario compilare sia il titolo e il corpo prima di poter fare un post. " , 
	 'blog:notfound'  =>  "Ci dispiace, non siamo riusciti a trovare questo post sul blog " , 
	 'blog:notdeleted'  =>  "Ci dispiace, non siamo riusciti a cancellare questo post sul blog " , 
	 'blog:river:update'  =>  "un post sul blog dal titolo " , 
	 'blog:river:annotate'  =>  "Un commento a questo blog" , 
	 'blog:error'  =>  "Qualcosa è andato storto. Riprova ancora. " , 
	 'item:object:blog'  =>  "Post" , 
	 'blog:river:create'  =>  "Un nuovo post sul blog "
); 

add_translation('it', $italian); 

?>