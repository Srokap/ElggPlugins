<?php

// Generate By translationbrowser. 

$italian = array( 
	 'profile'  =>  "Profilo" , 
	 'profile:edit:default'  =>  "Modifica i campi profilo" , 
	 'profile:preview'  =>  "Anteprima" , 
	 'profile:yours'  =>  "Tuo Profilo" , 
	 'profile:user'  =>  "Profilo di %s" , 
	 'profile:edit'  =>  "Edita profilo" , 
	 'profile:profilepictureinstructions'  =>  "La foto del profilo è l'immagine che viene visualizzato nella pagina del tuo profilo. È possibile modificare tutte le volte che desideri. (Formati di file accettati: GIF, JPG o PNG)" , 
	 'profile:icon'  =>  "Immagine profilo" , 
	 'profile:createicon'  =>  "Crea il tuo avatar" , 
	 'profile:currentavatar'  =>  "Avatar corrente" , 
	 'profile:createicon:header'  =>  "Immagine profilo" , 
	 'profile:profilepicturecroppingtool'  =>  "Immagine del profilo, strumento di ritaglio" , 
	 'profile:createicon:instructions'  =>  "Fare clic e tracciare un quadrato sull'immagine che si desidera essere ritagliata. L'anteprima della foto ritagliata verrà visualizzata nella finestra a destra. Quando si è soddisfatti con l'anteprima, fare clic su 'Crea il tuo avatar'. Questa immagine ritagliata sarà utilizzata in tutto il sito come il tuo avatar " , 
	 'profile:editdetails'  =>  "Edita i dettagli" , 
	 'profile:editicon'  =>  "Edita l'icona del profilo" , 
	 'profile:aboutme'  =>  "Cose di me" , 
	 'profile:description'  =>  "Cose di me" , 
	 'profile:briefdescription'  =>  "Breve descrizione" , 
	 'profile:location'  =>  "Localita'" , 
	 'profile:skills'  =>  "Abilità" , 
	 'profile:interests'  =>  "Interessi" , 
	 'profile:contactemail'  =>  "Email di contatto" , 
	 'profile:phone'  =>  "Telefono" , 
	 'profile:mobile'  =>  "Cellulare" , 
	 'profile:website'  =>  "Sito web" , 
	 'profile:banned'  =>  "Questo account utente è stato sospeso." , 
	 'profile:deleteduser'  =>  "Utente cancellato" , 
	 'profile:river:update'  =>  "% s e stato  aggiornato il suo profilo " , 
	 'profile:river:iconupdate'  =>  "% s icona  profilo aggiornata " , 
	 'profile:label'  =>  "Etichetta profilo" , 
	 'profile:editdefault:fail'  =>  "Il profilo base non puo' essere salvato" , 
	 'profile:editdefault:success'  =>  "Aggiunto al tuo profilo" , 
	 'profile:explainchangefields'  =>  "È possibile sostituire i campi già esistenti con il proprio profilo utilizzando il modulo seguente. In primo luogo si dà il nuovo campo profilo di una etichetta, ad esempio, 'squadra del cuore'. Dopodiché è necessario selezionare il tipo di campo, per esempio, i tag, url, testo e così via. In qualsiasi momento puoi tornare al profilo di default set up. " , 
	 'profile:saved'  =>  "Il tuo profilo e' stato salvato" , 
	 'profile:icon:uploaded'  =>  "L'immagine e ' stat caricata" , 
	 'profile:noaccess'  =>  "Non hai il permesso di modificare questo profilo" , 
	 'profile:notfound'  =>  "Ci dispiace, ma non abbiamo trovato il profilo specificato" , 
	 'profile:icon:notfound'  =>  "Spiacenti, si è verificato un problema nel caricare le tue foto del profilo" , 
	 'profile:icon:noaccess'  =>  "Non è possibile modificare questo profilo icona" , 
	 'profile:field_too_long'  =>  "Impossibile salvare le informazioni relative al profilo, perché il \"% s\" sezione è troppo lungo. " , 
	 'profile:type'  =>  "Tipo di profilo" , 
	 'profile:editdefault:delete:fail'  =>  "Rimosso il profilo predefinito " , 
	 'profile:editdefault:delete:success'  =>  "Elemento del profilo predefinito cancellato! " , 
	 'profile:defaultprofile:reset'  =>  "Reset profilo predefinito del sistema" , 
	 'profile:resetdefault'  =>  "Reset del profilo predefinito"
); 

add_translation('it', $italian); 

?>