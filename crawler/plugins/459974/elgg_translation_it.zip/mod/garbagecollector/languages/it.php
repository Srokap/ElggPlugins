<?php

// Generate By translationbrowser. 

$italian = array( 
	 'garbagecollector:period'  =>  "Quante volte dovrebbe eseguire il garbage collector Elgg? " , 
	 'garbagecollector:weekly'  =>  "Una alla settimana" , 
	 'garbagecollector:monthly'  =>  "Uno al mese" , 
	 'garbagecollector:yearly'  =>  "annuale" , 
	 'garbagecollector:done'  =>  "Eseguito" , 
	 'garbagecollector:optimize'  =>  "Ottimizzato %s" , 
	 'garbagecollector:error'  =>  "Errore" , 
	 'garbagecollector:ok'  =>  "Ok" , 
	 'garbagecollector:gc:metastrings'  =>  "Pulizia metastrings Unlinked: "
); 

add_translation('it', $italian); 

?>