<?php

// Generate By translationbrowser. 

$italian = array( 
	 'custom:bookmarks'  =>  "Ultimi preferiti" , 
	 'custom:groups'  =>  "Gruppi recenti" , 
	 'custom:files'  =>  "File recenti" , 
	 'custom:blogs'  =>  "Ultimi post nei blog" , 
	 'custom:members'  =>  "Ultimi iscritti " , 
	 'custom:nofiles'  =>  "Non ci sono ancora i file " , 
	 'custom:nogroups'  =>  "Non ci sono ancora i file "
); 

add_translation('it', $italian); 

?>