<?php

// Generate By translationbrowser. 

$italian = array( 
	 'friends:invite'  =>  "Invita gli amici" , 
	 'invitefriends:introduction'  =>  "Per invitare gli amici a unirsi a te in questa comunità, inserisci i loro indirizzi email qui sotto (uno per riga): " , 
	 'invitefriends:message'  =>  "Inserisci un messaggio che riceveranno con il tuo invito:" , 
	 'invitefriends:subject'  =>  "Invito ad aderire a % s " , 
	 'invitefriends:success'  =>  "I tuoi amici sono stati invitati." , 
	 'invitefriends:failure'  =>  "I tuoi amici non possono essere invitati. " , 
	 'invitefriends:message:default'  =>  "Ciao

Vorrei invitarti ad unirti a questa comunità; qui su %s." , 
	 'invitefriends:email'  =>  "Hai spedito un invito a %s da parte di %s. Il messaggio include il seguente testo:

%s

Per aderire clicca sul link seguente:

%s

Accetta l'invito e crea il tuo account. Automaticamente sarai inserito nei miei amici."
); 

add_translation('it', $italian); 

?>