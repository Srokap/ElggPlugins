<?php

// Generate By translationbrowser. 

$italian = array( 
	 'captcha:entercaptcha'  =>  "Inserisci il testo per l'immagine" , 
	 'captcha:captchafail'  =>  "Siamo spiacenti, il testo che avete inserito non corrisponde al testo nell'immagine."
); 

add_translation('it', $italian); 

?>