<?php

// Generate By translationbrowser. 

$italian = array( 
	 'categories'  =>  "Categorie" , 
	 'categories:settings'  =>  "Categorie sito" , 
	 'categories:explanation'  =>  "Per impostare qualche categoria per il sito predefinite, e utilizzabili  in tutto il sistema, inserisci qui sotto, separati da virgole. Compatibilmente agli strumenti installati potrai visualizzarne il contenuto quando l'utente li crea o li modifica." , 
	 'categories:save:success'  =>  "Categorie del sito sono state salvate. "
); 

add_translation('it', $italian); 

?>