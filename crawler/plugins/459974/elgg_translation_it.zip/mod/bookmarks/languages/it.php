<?php

// Generate By translationbrowser. 

$italian = array( 
	 'bookmarks'  =>  "Preferiti" , 
	 'bookmarks:friends'  =>  "I preferiti degli amici" , 
	 'bookmarks:everyone'  =>  "Preferiti nel sito" , 
	 'bookmarks:this'  =>  "Questo preferito" , 
	 'bookmarks:this:group'  =>  " Preferiti in %s" , 
	 'bookmarks:bookmarklet'  =>  "Inserisci nei preferiti" , 
	 'bookmarks:bookmarklet:group'  =>  "Manda nei preferiti del gruppo" , 
	 'bookmarks:more'  =>  "Piu'" , 
	 'bookmarks:with'  =>  "Condividi con" , 
	 'bookmarks:delete:confirm'  =>  "Sei sicuro di voler cancellare questa  risorsa?" , 
	 'bookmarks:visit'  =>  "Visita le risorse" , 
	 'bookmarks:river:annotate'  =>  "postato un commento su questo articolo dei preferiti " , 
	 'bookmarks:group'  =>  "Preferiti di gruppo" , 
	 'bookmarks:widget:description'  =>  "Questo widget è stato progettato per il vostro cruscotto e vi mostrerà le ultime nella tua casella di posta segnalibri. " , 
	 'bookmarks:bookmarklet:description'  =>  "Il bookmarklet segnalibri \"PREFERITI\" ti permette di condividere tutte le risorse che trovate sul web con i vostri amici, o semplicemente per te. Per poterlo utilizzare, è sufficiente trascinare ilseguente pulsante  link del tuo browser:" , 
	 'bookmarks:bookmarklet:descriptionie'  =>  "Se si utilizza Internet Explorer, sarà necessario fare clic destro del mouse sull'icona bookmarklet, selezionare 'Aggiungi ai preferiti', e poi la barra dei collegamenti " , 
	 'bookmarks:bookmarklet:description:conclusion'  =>  "È quindi possibile salvare le pagine visitate dai clic su di esso in qualsiasi momento." , 
	 'bookmarks:save:success'  =>  "Il tuo articolo è stato correttamente segnalato nei preferiti. " , 
	 'bookmarks:add'  =>  "Aggiungi preferiti" , 
	 'bookmarks:recent'  =>  "Recenti" , 
	 'bookmarks:river:item'  =>  "un elemento" , 
	 'bookmarks:enablebookmarks'  =>  "Abilita preferiti di gruppo" , 
	 'bookmarks:delete:success'  =>  "Gli elementi dei tuoi preferiti sono cancellati" , 
	 'bookmarks:save:failed'  =>  "Gli elementi dei toui preferiti non possono essere salvati Riprova" , 
	 'bookmarks:delete:failed'  =>  "Gli elementi dei tuoi preferiti non possono essere cancellati Riprova"
); 

add_translation('it', $italian); 

?>