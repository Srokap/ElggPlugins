<?php

// Generate By translationbrowser. 

$italian = array( 
	 'friends:all'  =>  "Tutti gli amici" , 
	 'notifications:subscriptions:personal:description'  =>  "Ricevi notifiche quando vi sono modifiche sui contenuti del sito" , 
	 'notifications:subscriptions:personal:title'  =>  "Avvisi personali" , 
	 'notifications:subscriptions:collections:title'  =>  "Togli o aggiungi dal gruppo" , 
	 'notifications:subscriptions:collections:description'  =>  "Per attivare o disattivare le impostazioni per i membri delle vostre collezioni amici, utilizzare le icone di sotto. Ciò avrà effetti sugli utenti corrispondenti nel pannello principale delle impostazioni di notifica nella parte inferiore della pagina." , 
	 'notifications:subscriptions:collections:edit'  =>  "Per editare il gruppo dei tuoi amici clicca qui." , 
	 'notifications:subscriptions:changesettings'  =>  "Avvisi" , 
	 'notifications:subscriptions:changesettings:groups'  =>  "Notifiche di gruppo" , 
	 'notification:method:email'  =>  "Email" , 
	 'notifications:subscriptions:title'  =>  "Notifiche per gli utenti" , 
	 'notifications:subscriptions:description'  =>  "Per ricevere le notifiche dai tuoi amici quando creano nuovi contenuti, li trovate qui sotto. Selezionare il metodo di notifica che si desidera utilizzare. " , 
	 'notifications:subscriptions:groups:description'  =>  "Per ricevere una notifica quando nuovi contenuti sono stai aggiunti ad un gruppo di amici di cui sei membro,seleziona qui sotto e scegli il metodo di notifica che si desidera utilizzare. " , 
	 'notifications:subscriptions:success'  =>  "I settaggi di notifica degli avvisi sono stati modificati"
); 

add_translation('it', $italian); 

?>