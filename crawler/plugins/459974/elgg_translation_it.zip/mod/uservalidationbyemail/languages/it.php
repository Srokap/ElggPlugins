<?php

// Generate By translationbrowser. 

$italian = array( 
	 'email:validate:subject'  =>  "%s per cortesia conferma il tuo indirizzo email!" , 
	 'email:validate:body'  =>  "Salve  %s,

T preghiamo di confermare il tuo indirizzo email cliccando sul link sottostante:

%s" , 
	 'email:validate:success:subject'  =>  "L'email e' valida %s!" , 
	 'email:validate:success:body'  =>  "Ciao %s, Benvenuto

La validazione della tua email è andata a buon fine." , 
	 'email:confirm:success'  =>  "Devi confermare il tuo indirizzo email!" , 
	 'email:confirm:fail'  =>  "Il tuo indirizzo email non risulta valido o non puo' essere validato" , 
	 'uservalidationbyemail:registerok'  =>  "Per attivare l'iscrizione devi procedere alla conferma dell'email che ti è stata spedita all'indirizzo che ci hai segnalato"
); 

add_translation('it', $italian); 

?>