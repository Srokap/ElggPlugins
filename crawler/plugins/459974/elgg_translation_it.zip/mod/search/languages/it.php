<?php

// Generate By translationbrowser. 

$italian = array( 
	 'search:enter_term'  =>  "Inserisci un termine per la ricerca:" , 
	 'search:no_results'  =>  "Nessun risultato" , 
	 'search:results'  =>  "Risultati per la ricerca di %s" , 
	 'search:no_query'  =>  "Inserisci una richiesta per la ricerca" , 
	 'search:search_error'  =>  "Errore" , 
	 'search:more'  =>  "+%s più %s" , 
	 'search_types:comments'  =>  "Commenti" , 
	 'search:comment_on'  =>  "Commenti su \"%s\"" , 
	 'search:unavailable_entity'  =>  "Disponibile Entity"
); 

add_translation('it', $italian); 

?>