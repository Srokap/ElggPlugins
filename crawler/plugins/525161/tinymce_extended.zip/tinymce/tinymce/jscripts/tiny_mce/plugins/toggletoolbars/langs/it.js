tinyMCE.addI18n('it.ttb',{
	hide : 'Nascondi toolbars',
	show : 'Mostra toolbars'
});