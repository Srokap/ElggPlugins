<?php
include_once ($_SERVER['DOCUMENT_ROOT'].'/Includes/Configure.php');
require_once("class_HTTPRetriever.php");

header('Content-type: text/xml');
header('Content-Encoding: UTF-8');
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

$raw = $_POST['txt'];


if(isset($_POST['txt'])) {
	$http = &new HTTPRetriever();
	$values = array(
		"host" => $_SERVER['HTTP_HOST'],
		"sid" => $_POST['sid'],
		"txt" => $_POST['txt']
	);
fb($values);
	if (!$http->post("http://kwex.crollmm.com/API/check4keywords.php",$http->make_query_string($values))) {
#	if (!$http->post("http://crollmm.localhost/KwExtract/API/check4keywords.php",$http->make_query_string($values))) {
		echo '<?xml version="1.0" encoding="windows-1250"?>
		<KeywordExtractor>
';
		echo "\t\t<message>HTTP request error: #{$http->result_code}: {$http->result_text}</message>\n";
		echo "\t\t<error>2</error>\n";
		echo "</KeywordExtractor>\n\n";
		return false;
	} else {
		echo $http->response;
	}
}

?>
