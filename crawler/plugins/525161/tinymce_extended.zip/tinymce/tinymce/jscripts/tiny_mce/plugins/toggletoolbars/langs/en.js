tinyMCE.addI18n('en.ttb',{
	hide : 'Hide toolbars',
	show : 'Show toolbars'
});
