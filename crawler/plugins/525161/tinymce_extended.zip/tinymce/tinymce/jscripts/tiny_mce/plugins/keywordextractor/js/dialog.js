tinyMCEPopup.requireLangPack();

var ExampleDialog = {
	init : function() {
		var f = document.forms[0];

		// Get the selected contents as text and place it in the input
		//f.someval.value = tinyMCE.activeEditor.getContent;
		//f.someval.value = tinyMCEPopup.editor.selection.getContent({format : 'text'});
		//f.somearg.value = tinyMCEPopup.getWindowArg('some_custom_arg');

	},

	insert : function() {
		tinyMCEPopup.editor.execCommand('mceInsertContent', false, document.forms[0].someval.value);
		tinyMCEPopup.close();
	}
};

tinyMCEPopup.onInit.add(ExampleDialog.init, ExampleDialog);

var newxmlhttp;
var oldhtmlsubmitbutton;
var ajaximage = "<img src='./img/ajax.gif' width='16' height='16'/>";

function getText(){
    var content= tinyMCE.activeEditor.getContent();
    content = content.replace(/<\/?[^>]+>/g, " ");
    checkKeywords(content);
}

function checkKeywords(contentvar) {
	newxmlhttp=GetXmlHttpObject();
	if (newxmlhttp==null) {
		alert ("Browser does not support HTTP Request");
		return;
	}

	var queryString = "txt=" + contentvar
		+ "&sid="+Math.random();

	try {
		oldhtmlsubmitbutton= document.getElementById("dialog_ajaximage").innerHTML;
		document.getElementById("dialog_close").style.display='none';
		document.getElementById("keywords").style.display='none';
		document.getElementById("dialog_keyword_check").style.display='none';
		document.getElementById("dialog_keyword_allkeyw").innerHTML='';
		document.getElementById("dialog_keyword_threewords").innerHTML='';
		document.getElementById("dialog_keyword_twowords").innerHTML='';
		document.getElementById("dialog_keyword_oneword").innerHTML='';
		document.getElementById("dialog_keyword_message").innerHTML='';
	} catch(err) {  }

	newxmlhttp.onreadystatechange=newstateChanged;
	newxmlhttp.open("POST","./check4keywords.php",true);
	newxmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
	newxmlhttp.send(queryString);
}

function newstateChanged() {
	if(newxmlhttp.readyState == 1) {
	   document.getElementById("dialog_ajaximage").innerHTML = ajaximage;
	}
	if (newxmlhttp.readyState==4) {
		document.getElementById("dialog_ajaximage").innerHTML = oldhtmlsubmitbutton;
		xmlDoc=newxmlhttp.responseXML;
		errorcheck = xmlDoc.getElementsByTagName("error")[0].childNodes[0].nodeValue;
		document.getElementById("dialog_keyword_check").style.display='none';
		if(errorcheck == '0') {
			document.getElementById("keywords").style.display='block';
			try {
				document.getElementById("dialog_keyword_allkeyw").innerHTML=	xmlDoc.getElementsByTagName("allkeyw")[0].childNodes[0].nodeValue;
				document.getElementById("dialog_keyword_threewords").innerHTML=	xmlDoc.getElementsByTagName("threewords")[0].childNodes[0].nodeValue;
				document.getElementById("dialog_keyword_twowords").innerHTML=	xmlDoc.getElementsByTagName("twowords")[0].childNodes[0].nodeValue;
				document.getElementById("dialog_keyword_oneword").innerHTML=	xmlDoc.getElementsByTagName("oneword")[0].childNodes[0].nodeValue;
			} catch(err) { }
		}
		if(errorcheck == '2') {
			document.getElementById("dialog_keyword_check").style.display='block';
			document.getElementById("dialog_close").style.display='none';
		} else {
			document.getElementById("dialog_close").style.display='block';
		}
		document.getElementById("dialog_keyword_message").innerHTML=	xmlDoc.getElementsByTagName("message")[0].childNodes[0].nodeValue;
	}
}


function GetXmlHttpObject() {
	if (window.XMLHttpRequest) {
		// code for IE7+, Firefox, Chrome, Opera, Safari
		return new XMLHttpRequest();
	}
	if (window.ActiveXObject) {
		// code for IE6, IE5
		return new ActiveXObject("Microsoft.XMLHTTP");
	}
	return null;
}


