tinyMCE.addI18n('en.example',{
	desc : 'TinyMCE Keyword Extractor',
});
