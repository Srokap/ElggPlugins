
	if(window.tinyMCE)
		window.tinyMCE.execCommand("mceInsertContent",true,content);
	