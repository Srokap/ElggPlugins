<?php
/**
 * editpage.php, part of Announcements
 * @author Norberto Bezi <norberto.bezi@gmail.com>
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

	// Make sure we're logged in (send us to the front page if not) and admin
	admin_gatekeeper();

	// Load newsletters model
	require_once(dirname(__FILE__) . "/../models/model.php");

	// get input fields
	$page_id = (int)get_input('guid');
	$title = get_input('title');
	
	if ( !$page_id){
		// redirect if newsletter id not present
        register_error(elgg_echo("announcements:page:invalid"));
        forward("pg/announcements/");
	}
	$page = get_entity($page_id);
	if (!$page){
		// redirect if newsletter not exists
        register_error(elgg_echo("announcements:page:invalid"));
        forward("pg/announcements/");
	}
	
	// if entity is newsletter and we can edit it
	if ($page->getSubtype() == 'announcement_page' && $page->canEdit()) {
		// Check for empty fields and redirect if required field empty
		if (empty($title)) {
			register_error(elgg_echo("announcements:page:blank"));
			forward("pg/announcements/");

		// Otherwise, update the newsletter 
		} else {
			// Set its information appropriately
			$page->title = $title;
			$page->access_id = 2;

			// Save the announcement post
			if (!$page->save()) {
				register_error(elgg_echo("announcements:page:save_error"));
				forward("pg/announcements/manage");
			}
	// Success message
			system_message(elgg_echo("announcements:page:updated"));

	// Forward to the main newsletters page
			forward("pg/announcements/manage");
		}
	}
