<?php
/**
 * deletepage.php, part of Announcements
 * @author Norberto Bezi <norberto.bezi@gmail.com>
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

// only for admin user
admin_gatekeeper();

global $CONFIG;

$page_id = (int) get_input('id',0);

// Make sure we actually have permission to edit
$page = get_entity($page_id);

if ($page->getSubtype() == "announcement_page" && $page->canEdit()) {

    // Delete it!
    $rowsaffected = $page->delete();
    if ($rowsaffected > 0) {
        // Success message
        system_message(elgg_echo("announcements:page:deleted"));
    } else {
        // show error
        register_error(elgg_echo("announcements:page:notdeleted"));
    }
}

// Forward to the manage page
forward($_SERVER['HTTP_REFERER']);
