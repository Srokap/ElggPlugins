<?php
/**
 * pages.php, part of Announcements
 * @author Norberto Bezi <norberto.bezi@gmail.com>
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

	admin_gatekeeper();

	// Load announcements model
	require_once(dirname(__FILE__) . "/../models/model.php");
	
	$title = get_input('title');

	// Cache to the session
	$_SESSION['announce_page_title'] = $title;
 	
	// Check for empty fields
	if (empty($title)) {
		register_error(elgg_echo("announcements:page:blank"));
		forward("pg/announcements/manage");

	// Otherwise, save the announcement page post
	} else {
			
	// Initialise a new ElggObject
			$announcement_page = new ElggObject();
	// Tell the system it's a announcement page
			$announcement_page->subtype = "announcement_page";
	// Set its owner to the current user
			$announcement_page->owner_guid = $_SESSION['user']->getGUID();
	// Set its information appropriately
			$announcement_page->title = $title;
			$announcement_page->access_id = 2;

	// Save the newsletter post
			if (!$announcement_page->save()) {
				register_error(elgg_echo("announcements:page:save_error"));
				forward("pg/announcements/manage");
			}
	// Success message
			system_message(elgg_echo("announcements:page:posted"));
	// Remove the blog post cache
			unset($_SESSION['announce_page_title']);
	// Forward to the main announcements page
			forward("pg/announcements/manage");
		}
