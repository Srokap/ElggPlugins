<?php

/**
    manage.php, part of Announcements
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
 * Modify to include pages by
 * @author Norberto Bezi <norberto.bezi@gmail.com>
 */


	// building administrative page
	
	// show list of newsletters and form for inserting new
    $limit = get_input('limit', 10);
    $offset = get_input('offset', 0);

	echo '<h2>' . elgg_echo('announcements') . '</h2>';
	echo announcements_list_entities($limit, $offset);
	echo '<hr><br />';
    echo elgg_view('announcements/forms/add');
	echo '<hr>';
	echo '<h2>' . elgg_echo('announcements:manage:page') . '</h2>';
	echo announcements_page_list_entities($limit, $offset);
	echo '<hr>';
    echo elgg_view('announcements/forms/addpage');
	
?>
