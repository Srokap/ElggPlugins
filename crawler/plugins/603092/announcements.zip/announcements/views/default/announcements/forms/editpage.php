<?php
/**
 * editpage.php, part of Announcements
 * @author Norberto Bezi <norberto.bezi@gmail.com>
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program. If not, see <http://www.gnu.org/licenses/>.
 */


	// get id of modified newsletter entity and redirect if not present
	$page_id = (int)get_input('id');
	if ( ! $page_id ){
        system_message(elgg_echo("announcements:page:invalid"));
        forward("pg/announcements/");
	}
	// loading newsletter entity for modification
	$page = get_entity($page_id);
	//get the full page owner entity
	$entity = get_entity(page_owner());

	// creating form body
	$form_body = '';
	$form_body .= elgg_echo('announcements:manage:page:title');
	$form_body .= elgg_view('input/text', array('internalname' => 'title', 'value' => $page->title));

	$form_body .= elgg_view('input/submit', array('value' => elgg_echo('announcements:manage:save')));
	$form_body .= elgg_view('input/hidden', array('internalname' => 'guid', 'value' => $page->guid));

	echo elgg_view('input/form', array('body' => $form_body, 'action' => $CONFIG->url . "action/announcements/editpage"));
