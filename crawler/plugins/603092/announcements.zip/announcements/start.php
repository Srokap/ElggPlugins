<?php
/**
    start.php, part of Announcements
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
*/

// unique function for plugin initialization
function announcements_init(){
    global $CONFIG;
    // registering languages translation constants
    register_translations($CONFIG->pluginspath . "announcements/languages/");
    // register handler for announcements list page
    register_page_handler('announcements', 'announcements_list_handler');
    // registering action for add announcements
    register_action('announcements/add', false, $CONFIG->pluginspath . 'announcements/actions/add.php');
    // registering action for edit announcements
    register_action('announcements/edit', false, $CONFIG->pluginspath . 'announcements/actions/edit.php');
    // registering action for delete announcement
    register_action('announcements/delete', false, $CONFIG->pluginspath . 'announcements/actions/delete.php');
    // registering action for add announcements
    register_action('announcements/addpage', false, $CONFIG->pluginspath . 'announcements/actions/addpage.php');
    // registering action for edit announcements
    register_action('announcements/editpage', false, $CONFIG->pluginspath . 'announcements/actions/editpage.php');
    // registering action for delete announcement
    register_action('announcements/deletepage', false, $CONFIG->pluginspath . 'announcements/actions/deletepage.php');
    // register plugin widget
    add_widget_type('announcements', elgg_echo('announcements:widget:title'), elgg_echo('announcements:widget:description'));
	// registering css styles
	extend_view('css','announcements/css');
	// Register entity type
	register_entity_type('object','announcement');
    // Register a URL handler for announcement
    register_entity_url_handler('announcement_url','object','announcement');
            
    add_menu(elgg_echo('announcements'), $CONFIG->wwwroot . "pg/announcements/");
	foreach (elgg_get_entities(array('type'=> 'object', 'subtypes' => 'announcement_page')) as $page) {
		add_menu($page->title, $CONFIG->wwwroot . 'pg/announcements/' . $page->guid);
	}
}

// handler for page setup, registered to add menu items for page menu
function announcements_pagesetup(){
	global $CONFIG;
	// if requested admin area by logged admin
	if ( get_context() == 'admin' && isadminloggedin() ){
		add_submenu_item( elgg_echo('announcements:manage'), $CONFIG->wwwroot . 'pg/announcements/manage/');
	} else {
        if ( get_context() == 'announcements' ) {
			add_submenu_item( elgg_echo('announcements:all'), $CONFIG->wwwroot . 'pg/announcements/');
			foreach (elgg_get_entities(array('type'=> 'object', 'subtypes' => 'announcement_page')) as $page) {
				add_submenu_item($page->title, $CONFIG->wwwroot . 'pg/announcements/' . $page->guid);
			}
		}
	}
}

// handler for list page
function announcements_list_handler($page){
	global $CONFIG;
	// if requested announcements/manage url include admin area script
    switch ( $page[0] )
    {
        case 'manage':
			announcements_list_manage_handler($page);
            break;

        case 'view':
            set_input('id', $page[1]);
            include($CONFIG->pluginspath . 'announcements/view.php'); 
            
            break;

        default:
			if (isset($page[0])) {
				set_input('page_guid', $page[0]);
			}
            include($CONFIG->pluginspath . 'announcements/index.php');
            break;
    }
		
}

function announcements_list_manage_handler($page) {
	global $CONFIG;
	switch ($page[1]) {
	  case 'edit':
		set_input('id', $page[2]);
		include($CONFIG->pluginspath . 'announcements/edit.php');
		break;

	  case 'editpage':
		set_input('id', $page[2]);
		include($CONFIG->pluginspath . 'announcements/editpage.php');
		break;

	  default:
		include($CONFIG->pluginspath . 'announcements/manage.php');
		break;
	}
}

function announcement_url($entity) 
{
    global $CONFIG;
    return $CONFIG->url . "pg/announcements/view/" . $entity->getGUID();
}

// register plugin event handler for plugin initialization
register_elgg_event_handler('init', 'system', 'announcements_init');
// register plugin event handler for page setup
register_elgg_event_handler('pagesetup', 'system', 'announcements_pagesetup');
// define constant for using in other parts
define('ANNOUNCEMENTS_SHORT_DESCRIPTION_LEN', 20);

?>
