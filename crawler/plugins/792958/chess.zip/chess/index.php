<?php
	/**
	 * Elgg Chess plugin
	 * This plugin gives you the ability to play chess with yourself or any site visitors
	 * 
	 * @package chess
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @original author Malaga Jack
	 * @Updated and modified by Jededitor
	 * @copyright fbfkids & Jed
	 * @link http://www.jedsite.info
	 */

	 
	// Load Elgg engine
	require_once(dirname(dirname(dirname(__FILE__))) . '/engine/start.php');


							
				
				$body = "";
				$bleft = "";

// ---------------- main ------------------------//

	// chess
				$body .= elgg_view('chess/iframelang', $vars);	
			
						
				
//----------------end ------------------------------//
				
	        	
		        set_context('main');
		        global $autofeed;
		        $autofeed = false;
				
				
	// Format
	//$content = elgg_view_layout('one_column', $area1);
	$content = elgg_view_layout('two_column_left_sidebar', '', $body, $bleft);
				
				
		// Draw page
		echo page_draw(null, $content);


?>