<?php
	/**
	 * Elgg Chess plugin
	 * This plugin gives you the ability to play chess with yourself or any site visitors
	 * 
	 * @package chess
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @original author Malaga Jack
	 * @Updated and modified by Jededitor
	 * @copyright fbfkids & Jed
	 * @link http://www.jedsite.info
	 */

 
    // put your code and html below the end php ">" tag
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html> 

<head> 
<style type="text/css">
<!--


body {
  margin: 0;
  height: 100%;
  width: 100%;
}
img { border-width: 0;}

#Igeo109 {
  width: 55.0em;
  height:28.00em;
}

-->
</style>
</head> 

<body>

<br />
<center>
<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0" width="600" height="584.736842105" id="6353504724.swf" align="center"><param name="movie" value="http://www.freegaming.de/components/flash/6353504724.swf" /><param name="quality" value="high" /><param name="bgcolor" value="#e8ffff" /><param name="menu" value="false" /><comment><embed src="http://www.freegaming.de/components/flash/6353504724.swf?affiliate_id=941efa0f97e566c4" quality="high" bgcolor="#e8ffff" width="600" height="544.736842105" name="6353504724.swf" menu="false" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer"></embed><noembed></noembed></comment></object>
</center>
<br />

</body> 
</html> 
