<?php
	/**
	 * Elgg customeyes plugin
	 * This plugin gives you the ability to have your own customised page
	 * 
	 * @package customeyes
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Malaga Jack
	 * @copyright fbfkids
	 * @link http://fbfkids.com
	 */

 
    // put your code and html below the end php ">" tag
?>
