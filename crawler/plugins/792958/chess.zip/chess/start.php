<?php
	/**
	 * Elgg Chess plugin
	 * This plugin gives you the ability to play chess with yourself or any site visitors
	 * 
	 * @package chess
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @original author Malaga Jack
	 * @Updated and modified by Jededitor
	 * @copyright fbfkids & Jed
	 * @link http://www.jedsite.info
	 */
	 
		function chess_init() {

		extend_view('metatags','chess/metatags');
		extend_view('css','chess/css');

	}
         add_menu(elgg_echo('Chess') , $CONFIG->wwwroot . "mod/chess");
	function chess() {

		if (!@include_once(dirname(dirname(__FILE__))) . "/chess/index.php") return false;
		return true;

	}
 
	 //------------------------------------------------//

	
	
	
?>