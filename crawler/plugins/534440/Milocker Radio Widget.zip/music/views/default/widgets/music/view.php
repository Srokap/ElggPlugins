<?php
    
     /**
	 * Elgg twitter view page
	 *
	 * @package ElggTwitter
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */
	 
	 //some required params
	 
	 
	 
?>
<div id="music_widget" align="center"<object width="180" height="220"><param name="movie" value="http://www.deezer.com/embed/player?rid=10&ap=0&ln=en"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.deezer.com/embed/player?rid=10&ap=0&ln=en" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="180" height="220"></embed></object><div id="dz_ref" style="font:9px Arial">Discover the Radio <a href="http://www.deezer.com/en/music/radios/rock-10" target="_blank">Rock</a></div>
