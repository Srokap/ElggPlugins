= Todo =
- Add optional forwarding window (with "you are being redirected" info)
- Add Preview functionality
- Add new window indicator ("underline" or image)

= Version history =

2.0 (2012-01-17):

- changed: moved info from manifest to README.txt
- fixed: replaced deprecated function in start.php

1.0.4 (2012-01-12):

- Updated for 1.8 by Brett Profitt.

1.0.3 (2011-04-22):

- changed: using jquery live function to register target blank on external links

1.0.2 (2011-04-21):

- changed: extend view functions updated for 1.7.x
- changed: moved code to js instead of metatags view
- fixed: target should not override target if it is already present
- fixed: support for https in external link

1.0.1 (2010-07-02):

- fixed: issue with href='#' (thx elggfan)
- fixed: widget content will now be handled

1.0 (2010-07-02):

- initial version
