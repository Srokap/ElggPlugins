<?php
	/**
	 * Elgg reported content plugin language pack
	 * 
	 * @package ElggReportedContent
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$french = array(
	
		/**
		 * Menu items and titles
		 */
	
			'item:object:reported_content' => 'Contenus signal&eacute;s',
			'reportedcontent' => 'Contenu signal&eacute;',
			'reportedcontent:this' => 'Signaler ce contenu',
			'reportedcontent:none' => 'Aucun contenu signal&eacute;',
			'reportedcontent:report' => 'Signaler aux Administrateurs',
			'reportedcontent:title' => 'Titre de la page',
			'reportedcontent:deleted' => 'Le contenu signal&eacute; a &eacute;t&eacute; supprim&eacute;',
			'reportedcontent:notdeleted' => 'Erreur. Rapport non supprim&eacute;',
			'reportedcontent:delete' => 'Supprimer',
			'reportedcontent:areyousure' => '&Ecirc;tes-vous certain de vouloir supprimer?',
			'reportedcontent:archive' => 'Archiver',
			'reportedcontent:archived' => 'Le raport a &eacute;t&eacute; archiv&eacute;',
			'reportedcontent:visit' => 'Voir les contenus signal&eacute;s',
			'reportedcontent:by' => 'Signal&eacute; par',
			'reportedcontent:objecttitle' => 'Titre',
			'reportedcontent:objecturl' => 'Url',
			'reportedcontent:reason' => 'Raison du signalement',
			'reportedcontent:description' => 'Pourquoi signalez-vous ceci?',
			'reportedcontent:address' => 'Emplacement du contenu',
			'reportedcontent:success' => 'Votre rapport a &eacute;t&eacute; envoy&eacute; aux Administrateurs',
			'reportedcontent:failing' => 'Erreur. Rapport non envoy&eacute;',
			'reportedcontent:report' => 'Signaler ceci', 
	
			'reportedcontent:failed' => 'D&eacute;sol&eacute;, la tentative de signaler ce contenu a &eacute;chou&eacute;.',
	);
					
	add_translation("fr",$french);
?>