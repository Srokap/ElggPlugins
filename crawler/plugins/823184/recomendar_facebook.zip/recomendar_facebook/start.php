<?php
/**
 * bot�o de recomendar no facebook
 * esse plugin proporciona ao usu�rio recomendar o perfil dele do elgg no facebook
 *
 * @package ElggTwitter
 */

elgg_register_event_handler('init', 'system', 'recomendar_facebook_init');

function recomendar_facebook_init() {
	elgg_extend_view('css/elgg');
	elgg_register_widget_type('recomendar_facebook', elgg_echo('facebook:title'), elgg_echo('facebook:info'));
}

?>