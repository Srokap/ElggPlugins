<?php
/**
 * facebook widget arquivo de idioma
 */

$portugues_brasil = array(

	'facebook:title' => 'Recomende no Facebook!',
	'facebook:info' => 'Exibe quem te recomenda!',
	
);

add_translation("en", $portugues_brasil);

?>