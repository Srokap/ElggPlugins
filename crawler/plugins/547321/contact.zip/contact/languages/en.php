<?php
	$english = array(
		'contact' => 'Contact',
		'contact:name' => 'Name',
		'contact:description' => 'Description',
		'contact:address' => 'Address',
		'contact:street' => 'Street',
		'contact:citystate' => 'City, State (, Country, World)',
		'contact:zip' => 'Zip Code',
		'contact:phone' => 'Phone Number',
		'contact:fax' => 'Fax Number',
		'contact:email' => 'Email Address',
		'contact:info' => 'Contact Information',
		'contact:content' => 'Contact',
		'contact:methods' => 'Contact Methods',
		'contact:contactname' => 'Contact Name',
		'contact:formemail' => 'Your email address (Email the form sends to)',
		'contact:settings' => 'Settings',
		'contact:showform' => 'Show Email Form',
		'contact:sent' => 'Email sent!',
		'contact:failed' => 'Email failed.  Try again later.',
		'contact:from' => 'Contact from ',
		'contact:send' => 'Send',
		'contact:formtitle' => 'Send a Message',
		'contact:title' => 'Title',
		'contact:from' => 'Your Email Address',
		'contact:body' => 'Body',
	);
					
	add_translation("en",$english);
?>