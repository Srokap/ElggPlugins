<?php 
include_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

function getContactSetting_html($translation, $name, $paragraph = true, $label = true)
{
	if(get_plugin_setting( $name, 'contact') != "")
	{
		if($paragraph)
		{
			$p = array("<p>","</p>");
		
		}
		if($label)
		{
			$label = "<em>".elgg_echo('contact:'.$translation).'</em>: ';
		}
		return $p[0].$label.get_plugin_setting( $name, 'contact').$p[1].'<br />';
	}
	return "";
}
$body = 
'<p><h1>'.elgg_echo('contact:content').'</h1>'.
getContactSetting_html('name', 'contactname', true, false).
getContactSetting_html('description', 'contactdescription', true, false).
'</p>'.
'<p><h2>'.elgg_echo('contact:info').'</h2>'.
'<h3>'.elgg_echo('contact:address').'</h3>'.
getContactSetting_html('street', 'contactstreet', false, false).
getContactSetting_html('addstreet', 'contactaddstreet', false, false).
getContactSetting_html('citystate', 'contactcitystate', false, false).
getContactSetting_html('zip', 'contactzip', false, false).
'</p>'.
'<p><h2>'.elgg_echo('contact:methods').'</h2>'.
'<h3>'.get_plugin_setting('contact', 'contactname').'</h3>'.
getContactSetting_html('phone', 'contactphone', false).
getContactSetting_html('fax', 'contactfax', false).
getContactSetting_html('email', 'contactemail', false).
'</p>'.elgg_view("contact/forms/send");


$body = elgg_view_layout('one_column', $body);
 
page_draw(get_plugin_setting('contact', 'contactname'),$body);

?>