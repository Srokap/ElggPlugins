<p>
	<h1><?php echo elgg_echo('contact:content'); ?>:</h1>
	<p>
		<p>
			<label><?php echo elgg_echo('contact:name'); ?></label>: 
			<?php echo elgg_view('input/text', 
						array('internalname' => 'params[contactname]', 
						'value' => $vars['entity']->contactname)); ?>
		</p>
		<p>
			<label><?php echo elgg_echo('contact:formemail'); ?></label>: 
			<?php echo elgg_view('input/text', 
						array('internalname' => 'params[contactformemail]', 
						'value' => $vars['entity']->contactformemail)); ?>
		</p>
		<p>
			<label><?php echo elgg_echo('contact:description'); ?></label>:
			<?php echo elgg_view('input/longtext', 
						array('internalname' => 'params[contactdescription]', 
						'value' => $vars['entity']->contactdescription)); ?>
		</p>
	</p>
</p>
<p>
	<h1><?php echo elgg_echo('contact:info'); ?>:</h1>
	<p>
	<h2><?php echo elgg_echo('contact:address'); ?></h2>:
		<p>
			<label><?php echo elgg_echo('contact:street'); ?></label>:  
			<?php echo elgg_view('input/text', 
						array('internalname' => 'params[contactstreet]', 
						'value' => $vars['entity']->contactstreet)); ?>
		</p>
		<p> 
			<?php echo elgg_view('input/text', 
						array('internalname' => 'params[contactstreet]', 
						'value' => $vars['entity']->contactstreet)); ?>
		</p>
		<p>
			<label><?php echo elgg_echo('contact:citystate'); ?></label>: 
			<?php echo elgg_view('input/text', 
						array('internalname' => 'params[contactcitystate]', 
						'value' => $vars['entity']->contactcitystate)); ?>
		</p>
		<p>
			<label><?php echo elgg_echo('contact:zip'); ?></label>:
			<?php echo elgg_view('input/text', 
						array('internalname' => 'params[contactzip]', 
						'value' => $vars['entity']->contactzip)); ?>
		</p>
	</p>
	<p>
	<h2><?php echo elgg_echo('contact:methods'); ?></h2>:
		<p>
			<label><?php echo elgg_echo('contact:name'); ?></label>:
			<?php echo elgg_view('input/text', 
						array('internalname' => 'params[contactname]', 
						'value' => $vars['entity']->contactname)); ?>
		</p>
		<p>
			<label><?php echo elgg_echo('contact:phone'); ?></label>:
			<?php echo elgg_view('input/text', 
						array('internalname' => 'params[contactphone]', 
						'value' => $vars['entity']->contactphone)); ?>
		</p>
		<p>
			<label><?php echo elgg_echo('contact:fax'); ?></label>:
			<?php echo elgg_view('input/text', 
						array('internalname' => 'params[contactfax]', 
						'value' => $vars['entity']->contactfax)); ?>
		</p>
		<p>
			<label><?php echo elgg_echo('contact:email'); ?></label>:
			<?php echo elgg_view('input/text', 
						array('internalname' => 'params[contactemail]', 
						'value' => $vars['entity']->contactemail)); ?>
		</p>	
	</p> 
</p>
<?php if (is_plugin_enabled('contact'))  
{ ?>
<p>
	<?php echo elgg_echo('contact:settings'); ?>
	<p>
		<label><?php echo elgg_echo('contact:showform'); ?></label>:
		<select name="params[contactshowform]">
			<option value="yes" <?php if ($vars['entity']->contactshowform == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
			<option value="no" <?php if ($vars['entity']->contactshowform != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
		</select>
	</p>
</p>
<?php } ?>