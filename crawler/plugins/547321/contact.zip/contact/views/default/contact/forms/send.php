<?php 

global $CONFIG;

if(get_plugin_setting( 'contactshowform', 'contact') == "yes")
{
 
	//$form_body = '<form action="'.$vars['url'].'action/contact/send" method="post">';
	$form_body .= "<label>".elgg_echo('contact:title')."</label>:";
	$form_body .= elgg_view('input/text', array('internalname' => 'title', 'value' => $vars['title']));
	$form_body .= "<label>".elgg_echo('contact:from')."</label>:";
	$form_body .= elgg_view('input/text', array('internalname' => 'fromemail', 'value' => $vars['fromemail']));
	$form_body .= "<label>".elgg_echo('contact:body')."</label>:";
	$form_body .= elgg_view('input/longtext', array('internalname' => 'body', 'value' => $vars['body']));
	
	$form_body .= elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('contact:send'))) . "</p>";

	//$form_body .= '</form>';
	$form_body = 
	'<p><h2>'.
	elgg_echo('contact:formtitle').
	'</h2>'.$form_body.'</p>';
 
}
echo elgg_view('input/form', array('action' => "{$vars['url']}action/contact/send", 'body' => $form_body)) ?>

?>