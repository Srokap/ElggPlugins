<?php

  // get the form input
  $title = elgg_echo('contact:from').get_input('fromemail').": ".get_input('title');
  $body = get_input('body');
 
 if(get_plugin_setting( 'contactshowform', 'contact') == "yes")
 {
	 $to = get_plugin_setting( 'contactformemail', 'contact');
	 $subject = $title;
	 
	 if (mail($to, $subject, $body)) 
	 {
	 	system_message(elgg_echo('contact:sent'));
	 } 
	 else 
	 {
	 	system_error(elgg_echo('contact:failed'));
	 }
 }
 
  // forward user back to contact
 forward('mod/contact/');
?>