<?php
global $CONFIG;
 
register_action("contact/send", true, $CONFIG->pluginspath . "contact/actions/send.php");
?>