<?php
/* Liang Lee Rightclick Plugin
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @package Liang Lee Rightclick Plugin
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File Version.php
 */
$LiangLeeRightclick_version = '20120531';
$LiangLeeRightclick_release = '1.0.0
';
?>
