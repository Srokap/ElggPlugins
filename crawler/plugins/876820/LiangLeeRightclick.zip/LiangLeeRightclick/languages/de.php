<?php
/* Liang Lee Rightclick Plugin
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @package Liang Lee Rightclick Plugin
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File de.php German Language by Nudeler2 http://community.elgg.org/pg/profile/Nudeler2
 */

$german = array(
	'llee:rc:1' => 'Geben Sie hier einen Text angezeigt werden, wenn Benutzer mit der rechten klicken Sie klicken Sie auf.',

);

add_translation('de', $german);
