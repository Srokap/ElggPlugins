<?php
/* Liang Lee Rightclick Plugin
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @package Liang Lee Rightclick Plugin
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File en.php 
 */

$english = array(
	'llee:rc:1' => 'Please Enter here a text to be displayed when user click right click.',

);

add_translation('en', $english);
