<?php

$user = get_loggedin_user();
$owner = $_SESSION['user']->guid;
	
$group_count = get_plugin_usersetting('group_count', 'river_addon');

$options = array(
	'relationship' => 'member',
	'relationship_guid' => $owner,
	'type' => 'group',
	'limit' => $group_count,
);
$groups = elgg_get_entities_from_relationship($options);	

if ($groups) {

?>

<div class="sidebarBox" id="rivergroups">
	<div class="collapsable_box_header">
<?php

	$closed = false;
	if (get_loggedin_user() instanceof ElggUser) {
		if (get_loggedin_user()->addon_groups_closed) {
			$closed = true;
		}
	}
	if ($closed) {
?>
		<a href="javascript:void(0);" class="toggle_box_contents" onClick="$.post('<?php echo elgg_add_action_tokens_to_url("{$vars['url']}action/user/show_groups?closed=false"); ?>')">+</a>
<?php
		} else {
?>
		<a href="javascript:void(0);" class="toggle_box_contents" onClick="$.post('<?php echo elgg_add_action_tokens_to_url("{$vars['url']}action/user/show_groups?closed=true"); ?>')">-</a>
<?php

		}

?>
	<h3><?php echo elgg_echo('groups:yours') ?></h3>
	</div>
	<div class="collapsable_box_content" <?php if ($closed) echo "style=\"display:none\"" ?>>

        <?php         
                echo "<div class=\"groupmembershipwidget\">";
        
                foreach($groups as $group){
                    $icon = elgg_view("groups/icon", array('entity' => $group, 'size' => 'small'));
                        
                    $group_link = $group->getURL();
                        
                    echo "<div class=\"contentWrapper\">" . $icon . " <div id=\"grouplink\" class='search_listing_info'><p><a href=\"$group_link\">" . $group->name . "</a>";
                    echo "</p></div><div class=\"clearfloat\"></div></div>";
                    
                }
                echo "</div>";                        
            ?>

    </div><!-- .collapsable_box_content -->  
</div>

<?php
}
