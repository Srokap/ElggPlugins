<?php

// river sidebar views
$sidebar_elements = array(	
	elgg_view('river_addon/hints', array('type' => 'hint')),
	elgg_view("riverdashboard/newestmembers"),
	elgg_view("river_addon/friends"),
	elgg_view("river_addon/mygroups")
);

echo "<ul id=\"addon_sidebar\">";
foreach ($sidebar_elements as $position => $value){
	echo '<li id="addon_item_' . $position . '">' . $value . "</li>";
}
echo "</ul>";

?>

