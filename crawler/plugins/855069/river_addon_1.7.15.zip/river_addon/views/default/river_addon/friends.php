<?php

$friends = get_loggedin_user()->getFriends('', 0);	

if ($friends) {

?>

<div class="sidebarBox">
<h3><?php echo elgg_echo('friends') ?></h3>
    <div class="membersWrapper"><br />
    <?php 
            foreach($friends as $friend) {
            echo "<div class=\"recentMember\">";
            echo elgg_view("profile/icon",array('entity' => get_user($friend->guid), 'size' => 'tiny'));
            echo "</div>";
            }
        ?>
    <div class="clearfloat"></div>
    </div>
</div>

<?php
}
