<?php

/**
 * River_addon CSS
 */

?>

#addon_sidebar { 
    list-style-type: none; 
    margin: 0; padding: 0; 
}
#addon_sidebar li { 
    height: auto;
}
