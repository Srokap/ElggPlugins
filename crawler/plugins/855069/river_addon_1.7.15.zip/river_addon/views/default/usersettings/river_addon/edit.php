<?php

$group_count = $vars['entity']->group_count;

?>
   
<?php echo elgg_echo('river_addon:param_label'); ?><br /><br />

<select name="params[group_count]">
	<option value="2" <?php if ($group_count == 2) echo " selected=\"yes\" "; ?>>2</option>
	<option value="4" <?php if ($group_count == 4) echo " selected=\"yes\" "; ?>>4</option>
	<option value="6" <?php if ($group_count == 6) echo " selected=\"yes\" "; ?>>6</option>
	<option value="8" <?php if ($group_count == 8) echo " selected=\"yes\" "; ?>>8</option>
</select>
