<?php

$danish = array(

	'river_addon'				=> 'Aktivitetssiden',
	'river_addon:param_label'	=> 'Hvor mange af dine grupper vil du vise på aktivitetsiden',

	// riverdashboard random hint
	'cg:hint:howto' => 'Information',
	'cg:howto:hint:loggedin:1' => "Du kan ændre denne tekst ved at redigere sprogfilen i river addon plugin",
	'cg:howto:hint:loggedin:2' => 'Gå til "Indstilling af værktøjer" på siden Indstillinger for at vælge hvilken aktivitetstrøm, du vil have vist som standard, Alle, Følger eller Mine',
	'cg:howto:hint:loggedin:3' => "Dette er en kort notits hentet fra en sprogfil",
	'cg:howto:hint:loggedin:4' => 'At blive medlem af en gruppe er så let som at klikke på "Bliv medlem" på gruppens profilside',	
	
);

add_translation("da",$danish);

?>