<?php

$english = array(

	'river_addon'				=> 'Activity page',
	'river_addon:param_label'	=> 'Number of your groups to display on activity page',
		
	// riverdashboard random hint	
	'cg:hint:howto' => 'Information',
	'cg:howto:hint:loggedin:1' 	=> "You can change this text by editing the language file in river addon plugin",
	'cg:howto:hint:loggedin:2' 	=> 'Go to "Configure your tools" on the Settings page to choose which activity stream, you want to display by default, All, Following or Mine',
	'cg:howto:hint:loggedin:3'	=> "This is a short note taken from a language file",
	'cg:howto:hint:loggedin:4' 	=> 'Joining a group is as easy as clicking the "Join Group" link on a group\'s profile page',

);

add_translation("en", $english);

?>