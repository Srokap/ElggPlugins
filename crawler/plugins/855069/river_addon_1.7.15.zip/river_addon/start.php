<?php

/**
 * river_addon
 *
 * @copyright perjensen-online.dk 2012
 * @link http://www.perjensen-online.dk
 */

function river_addon_init() {
	global $CONFIG;
	
	elgg_extend_view('css', 'river_addon/css');
	
	elgg_extend_view('riverdashboard','riverdashboard/index');
	
	register_page_handler('dashboard','addon_page_handler');
				
}

function addon_page_handler($page) {
	global $CONFIG;

	$user_id = get_loggedin_userid();
	$group_count = get_plugin_usersetting('group_count', $user_id, 'river_addon');	

	//override riverdashboard index
	include(dirname(__FILE__) . "/index.php");
	
}
global $CONFIG;
register_action("user/show_groups", false, $CONFIG->pluginspath . "river_addon/actions/user/show_groups.php");
register_elgg_event_handler('init', 'system', 'river_addon_init');
