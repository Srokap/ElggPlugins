	/**
	 * Egxite™ Themer for Elgg
	 * This theme allows for color preferences be set for the entire site.
	 * If the admin chooses to, it also allows each individual user to personalise their color settings.
	 * The display is reformatted when using an iPhone to view the site.
	 * 
	 * @package Egxite™ Themer
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Egxite Corp. <contact@egxite.com>
	 * @copyright Egxite Corp. 2009-2010
	 * @link http://egxite.com/
	 * 
	 */
	

Change History:


Version 0.5 Beta - Feb 20,2010 (Tested with Elgg 1.6.1 and Elgg 1.7beta)
 
 * Fixes to known problems from Version 0.4 Beta
	* Tab Colors/Borders
	* Removed image repeat on the optional logo image
	* Fixed "missing token" error when logging out on an Elgg 1.7 system
	* Fixed login panel width
	* Disables the themer stylesheet when doing plugin administration to eliminate "garbage" output.
		This will also help the admin in case bad color selections makes the rest of the site unreadable.

New Features:
 * Added this readme.txt file
 * Background image option to the topbar
 * Background image option to the header
 * Topbar icon image replacement and link option
 * JQuery Color picker by Stefan Petre (www.eyecon.ro) when editing the custom colors.
 * Option to turn off the Spotlight section (right above the footer section)
Known Issues:
    * The profile page haven't been coded for the iPhone and will display rather small because of the scaling.  
		I hope to code this in a much later release.
    * The dashboard with widgets works a bit better with viewing but you can't really edit your dashboard using the iphone.   
		Drag and drop of the widgets does not seem to work on the iPhone.
    * The friends collection/notification selection also haven't been coded so it doesn't display well on the iPhone.


Version 0.4 beta uploaded Friday, Oct 23, 2009.  NEW FEATURES:
    * CSS Caching Feature - Can be turned on/off to preview changes.
    * Option for Background Image URL.
    * Option for Header/Logo Image URL.
    * Transparency Mode - You can define the percentage of opacity.
    * Topbar Menu Color Customization.
    * Optional Override of Fonts.

Version 0.2 beta uploaded Sunday, Sep 13, 2009.  NEW FEATURES:
    * Expanded the top menu area to fix the Adminisration menu overlap with the site title.
    * Added specific font color/brightness for text and links.
    * You can now disable the desktop theme of this plugin but will allow iPhone only view.
    * You can also turn mobile view on/off.
    * Please note that there is a separate site setting under Administration and a user preference override in the users settings/configuration menu.
    * Instead of detecting specifically for the iPhone, it looks looks for Mobile in the browser type - not sure if that will work with other devices but it works ok on the iPhone.

Version 0.4 beta issues:



