<?php

	/**
	 * Egxite™ Themer for Elgg
	 * This theme allows for color preferences be set for the entire site.
	 * If the admin chooses to, it also allows each individual user to personalise their color settings.
	 * The display is reformatted when using an iPhone to view the site.
	 * 
	 * @package Egxite™ Themer
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Egxite Corp. <contact@egxite.com>
	 * @copyright Egxite Corp. 2009-2010
	 * @link http://egxite.com/
	 * 
	 */
	
		function themer_init() {
    		
			//global $CONFIG;
			$ref = $_SERVER['HTTP_REFERER'];	
			$skip = FALSE;
			if(	stripos($ref,"/pg/admin/statistics/")>1 ||
				stripos($ref,"/pg/admin/plugins/")>1
				) {
				extend_view('metatags','colorpicker/head');
				$skip = TRUE;
				} 
			if( $ref && !$skip )
				{
				extend_view('css','themer/css');
				}				
    		
 			
		}

		function colorpicker( $name, $value  ) 
		{
	
			$form_label = elgg_echo("themer:$name");
			$form_input = '<input type="text" class="input-text" maxlength="7" size="7" name="params[theme_'.$name.']" id="'.$name.'" value="'.$value.'" />'; 
			$html_code = "<tr><td align=\"right\">$form_label</td><td>$form_input</td></tr>\r\n";
			echo $html_code;
		}

		function inputtext( $name, $value  ) 
		{
	
			$form_label = elgg_echo("themer:$name");
			$form_input = elgg_view('input/text', array('internalname' => "params[theme_$name]", 'value' => $value));

			$html_code = "<tr><td align=\"right\">$form_label</td><td>$form_input</td></tr>\r\n";
			echo $html_code;
		}

		register_elgg_event_handler('init','system','themer_init');
?>
