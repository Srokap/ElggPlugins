<?php

	/**
	 * Egxite™ Themer for Elgg
	 * This theme allows for color preferences be set for the entire site.
	 * If the admin chooses to, it also allows each individual user to personalise their color settings.
	 * The display is reformatted when using an iPhone to view the site.
	 * 
	 * @package Egxite™ Themer
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Alex Tanchoco <contact@egxite.com>
	 * @copyright Egxite™ Corp. 2009-2010
	 * @link http://egxite.com/
	 * 
	 */


	$english = array(
	
		 /**
		 * Themer widget details
		 */
						'blackberry' => elgg_echo('themer:blackberry'),
				'samsung' => elgg_echo('themer:samsung'),
				'nokia' => elgg_echo('themer:nokia'),
				'on' => elgg_echo('themer:on'),

	
		'themer:theme' => 'Theme',
		'themer:notset' => 'You have not selected a theme. To set your theme, click on edit above.',
		'themer:cache' => 'Enable Themer Cache',
		'themer:spotlight' => 'Enable Spotlight',
		'themer:elggversion' => 'Elgg Version',
		'themer:elggversionsupport' => 'Only supported/tested Elgg versions are listed.',
		'themer:cachesupport' => 'Set to No when making changes. Set to Yes when done.',
		'themer:blue' => 'blue',
		'themer:white' => 'white',
		'themer:turquoise' => 'turquoise',
		'themer:green' => 'green',
		'themer:lime' => 'lime',
		'themer:gray' => 'gray',
		'themer:red' => 'red',
		'themer:orange' => 'orange',
		'themer:redorange' => 'red orange',
		'themer:yellow' => 'yellow',
		'themer:purple' => 'purple',
		'themer:white' => 'white',
		'themer:pink' => 'pink',
		'themer:burgundy' => 'burgundy',
		'themer:black' => 'black',
		'themer:khaki' => 'khaki',
		'themer:honeydew' => 'honey dew',
		'themer:light' => 'light',
		'themer:bright' => 'bright',
		'themer:medium' => 'medium',
		'themer:dim' => 'dim',
		'themer:dark' => 'dark',
		'themer:default' => 'default',
		
		'themer:sitesetting' => 'Default theme for the entire site.  You must click on Save below to store the changes.',
		'themer:theme_last_changed' => 'Theme last changed',
		'themer:current_time' => 'Current Time',
		'themer:mobile' => 'Mobile Device',
		'themer:mobileonly' => 'Mobile Only Theme',
		'themer:mobiletheme' => 'Mobile Device Theme',
		'themer:usersetting' => 'Your personalised theme',
		'themer:titlefont' => 'Title Font',
		'themer:bodyfont' => 'Body Font',
		'themer:captionfont' => 'Caption Font',
		'themer:titlecolor' => 'Title/Headline',
		'themer:themebrightness' => 'Theme Brightness Level',
		'themer:textbrightness' => 'Text Brightness Level',
		'themer:usertheme' => 'Selected Theme',
		'themer:sitetheme' => 'Site Theme',
		'themer:captioncolor' => 'Caption',
		'themer:subheadcolor' => 'Subheading',
		'themer:textcolor' => 'Text/Body',
		'themer:linkcolor' => 'Links',
		'themer:topbarcolor' => 'Top Bar Color',
		'themer:headerheight' => 'Header height in pixels',
		'themer:headerwidth' => 'Header/Page width in pixels',
		'themer:foradvancedusersonly' => 'WARNING: For Advanced Users Only.  Wrong setting may cause your entire site to be inaccessible.  These settings will override the above settings.<br><br>Are you sure you want to use the advanced setttings? ',
		'themer:background' => 'Background Image URL',
		'themer:text' => 'Text/Body',
		'themer:title' => 'Title',
		'themer:off' => 'Off',
		'themer:on' => 'On',
		'themer:yes' => 'Yes',
		'themer:no' => 'No',
		'themer:pct_opacity' => 'Opacity',
		'themer:headerbackground' => 'Header Image URL',
		'themer:logo' => 'Logo URL',
		'themer:topbarbackground' => 'TopToolBar Background Image URL',
		'themer:topbarlogo' => 'TopToolBar Logo Image URL',
		'themer:topbarurl' => 'TopToolBar Logo Target URL',
		'themer:logoposition' => 'Logo Position',
		'themer:allowusertheme' => 'Allow Individual User Themes',
		'themer:transparency' => 'Transparency',
		'themer:exact' => 'Theme web color in hex (rrggbb)',
		'themer:titleexact' => 'Title/Headline web color in hex (rrggbb)',
		'themer:subheadexact' => 'Subheading web color in hex (rrggbb)',
		'themer:captionexact' => 'Caption web color in hex (rrggbb)',
		'themer:textexact' => 'Text/Body web color in hex (rrggbb)',
		'themer:linkexact' => 'Links web color in hex (rrggbb)',		
		'themer:sitepreferred' => 'Use site-wide theme',
		'themer:personalpreferred' => 'Use my personal theme below',
		'themer:preference' => 'Select which theme to use',	
		'themer:mobilewidth' => 'Mobile screen width override',
		'themer:menubackcolor' => 'Menu bar color',
		'themer:menuhovercolor' => 'Menu hover over color',
		'themer:menutextcolor' => 'Menu text color', 				
		'themer:menutexthovercolor' => 'Menu text hover color', 				
		'themer:iphone' => 'iPhone',
		'themer:nokia' => 'Nokia',
		'themer:samsung' => 'Samsung',
		'themer:blackberry' => 'Blackberry',
		'themer:palmpre' => 'Palm Pre',
		'themer:lg' => 'LG',
		'themer:motorola' => 'Motorola',
		
		/** browser type keywords to look for **/
		'themer:headeriphone' => 'iPhone',
		'themer:headeriphonelandscape' => 'iPhone',
		'themer:headeriphoneportrait' => 'iPhone',
		'themer:headernokia' => 'Nokia',
		'themer:headersamsung' => 'Samsung',
		'themer:headerblackberry' => 'Blackberry',
		'themer:headerpalmpre' => 'PalmPre',


		
		
		 /**
	         * themer widget river
	         **/
	        
	         //generic terms to use
	         'themer:river:created' => "%s added the themer widget.",
	         'themer:river:updated' => "%s updated their themer widget.",
	         'themer:river:delete' => "%s removed their themer widget.",
	        
		
	);
					
	add_translation("en",$english);

?>
