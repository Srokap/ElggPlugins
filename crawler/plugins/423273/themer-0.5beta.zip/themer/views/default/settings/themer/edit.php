
<?php

	/**
	 * Egxite™ Themer for Elgg
	 * This theme allows for color preferences be set for the entire site.
	 * If the admin chooses to, it also allows each individual user to personalise their color settings.
	 * The display is reformatted when using an iPhone to view the site.
	 * 
	 * @package Egxite™ Themer
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author  Egxite™ Corp. <contact@egxite.com>
	 * @copyright Egxite™ Corp. 2009-2010
	 * @link http://egxite.com/
	 * 
	 */

		$user = get_loggedin_user();
		if( !$user ) return; 

		$theme_changed_date = get_plugin_setting('theme_changed_date', 'themer');;
		$itsnow = date("Y-m-d H:i:s");
		
		echo '<strong>'.elgg_echo("themer:theme_last_changed"). "</strong>: ".$theme_changed_date."<br>";
		
	    	$user = get_loggedin_user();
		if( !$user ) return;

		$colorchoices = array(
				'white' => elgg_echo('themer:white'),
				'blue' => elgg_echo('themer:blue'),
				'turquoise' => elgg_echo('themer:turquoise'),
				'green' => elgg_echo('themer:green'),
				'lime' => elgg_echo('themer:lime'),
				'honeydew' => elgg_echo('themer:honeydew'),
				'khaki' => elgg_echo('themer:khaki'),
				'redorange' => elgg_echo('themer:redorange'),
				'orange' => elgg_echo('themer:orange'),
				'yellow' => elgg_echo('themer:yellow'),
				'purple' => elgg_echo('themer:purple'),
				'red' => elgg_echo('themer:red'),
				'pink' => elgg_echo('themer:pink'),
				'burgundy' => elgg_echo('themer:burgundy'),
				'gray' => elgg_echo('themer:gray'),
				'black' => elgg_echo('themer:black'),
			);
			
		$brightnesschoices = array(
				'bright' => elgg_echo('themer:bright'),
				'light' => elgg_echo('themer:light'),
				'medium' => elgg_echo('themer:medium'),
				'dim' => elgg_echo('themer:dim'),
				'dark' => elgg_echo('themer:dark'),
			);

	$theme_mobileonly = $vars['entity']->theme_mobileonly;
	if( !theme_mobileonly ) $user_mobileonly = "yes";
	
	$theme_mobile = $vars['entity']->theme_mobile;
	if( !theme_mobile ) $theme_mobile = "yes";
	
	$theme_spotlight = $vars['entity']->theme_spotlight;
	if( !theme_spotlight ) $theme_spotlight = "yes";
	
	$theme_elggversion = $vars['entity']->theme_elggversion;
	$theme_cache = $vars['entity']->theme_cache;
	$theme_advanced = $vars['entity']->theme_advanced;
	$theme_color = $vars['entity']->theme_color;
	$theme_menuback = $vars['entity']->theme_menuback;
	$theme_menuhover = $vars['entity']->theme_menuhover;
	$theme_menutext = $vars['entity']->theme_menutext;
	$theme_menutexthover = $vars['entity']->theme_menutexthover;
	$theme_background = $vars['entity']->theme_background;
	$theme_logo = $vars['entity']->theme_logo;
	$theme_headerbackground = $vars['entity']->theme_headerbackground;
	$theme_topbarbackground = $vars['entity']->theme_topbarbackground;
	$theme_topbarlogo = $vars['entity']->theme_topbarlogo;
	$theme_topbarurl = $vars['entity']->theme_topbarurl;
	$theme_exact = $vars['entity']->theme_exact;
	$theme_linkexact = $vars['entity']->theme_linkexact;
    	$theme_titleexact = $vars['entity']->theme_titleexact;
    	$theme_subheadexact = $vars['entity']->theme_subheadexact;
    	$theme_captionexact = $vars['entity']->theme_captionexact;
	$theme_textexact = $vars['entity']->theme_textexact;
	$theme_headerheight = $vars['entity']->theme_headerheight;
	$theme_headerwidth = $vars['entity']->theme_headerwidth;
	$theme_transparency = $vars['entity']->theme_transparency;
	$theme_pct_opacity = $vars['entity']->theme_pct_opacity;
	$theme_allowusertheme = $vars['entity']->theme_allowusertheme;
	$theme_titlefont = $vars['entity']->theme_titlefont;
	$theme_bodyfont = $vars['entity']->theme_bodyfont;
	$theme_captionfont = $vars['entity']->theme_captionfont;
	
	if (!$theme_color) 
		{
		$theme_color = 'blue';
		$theme_brightness = "light";
		$title_color = "black";
		$title_brightness = "dim";
		$subhead_color = "black";
		$subhead_brightness = "dim";
		$caption_color = "black";
		$caption_brightness = "dim";
		$text_color = "black";
		$text_brightness = "dim";
		$menuback_color = "gray";
		$menuback_brightness = "dim";
		$menuhover_color = "orange";
		$menuhover_brightness = "dim";
		$menutext_color = "yellow";
		$menutext_brightness = "dark";
		$menutexthover_color = "white";
		$menutexthover_brightness = "bright";
		$topbar_color = "white";
		$topbar_brightness = "bright";
		$link_color = "yellow";
		$link_brightness = "medium";
		$theme_titlefont = 'Arial, Helvetica, sans-serif;';
		$theme_bodyfont = 'Verdana, Helvetica, sans-serif;';
		$theme_captionfont = 'Verdana, Helvetica, sans-serif; font-style: italic;';
		}
		else
		{
		$theme_brightness = $vars['entity']->theme_brightness;
		$title_color = $vars['entity']->title_color;
		$title_brightness = $vars['entity']->title_brightness;
		$menuback_color = $vars['entity']->menuback_color;
		$menuback_brightness = $vars['entity']->menuback_brightness;
		$menuhover_color = $vars['entity']->menuhover_color;
		$menuhover_brightness = $vars['entity']->menuhover_brightness;
		$menutext_color = $vars['entity']->menutext_color;
		$menutext_brightness = $vars['entity']->menutext_brightness;
		$menutexthover_color = $vars['entity']->menutexthover_color;
		$menutexthover_brightness = $vars['entity']->menutexthover_brightness;
		$topbar_color = $vars['entity']->topbar_color;
		$topbar_brightness = $vars['entity']->topbar_brightness;
		$subhead_color = $vars['entity']->subhead_color;
		$subhead_brightness = $vars['entity']->subhead_brightness;
		$caption_color = $vars['entity']->caption_color;
		$caption_brightness = $vars['entity']->caption_brightness;
		$text_color = $vars['entity']->text_color;
		$text_brightness = $vars['entity']->text_brightness;
		$link_color = $vars['entity']->link_color;
		$link_brightness = $vars['entity']->link_brightness;
		$theme_titlefont = $vars['entity']->theme_titlefont;
		$theme_bodyfont = $vars['entity']->theme_bodyfont;
		}
	
?>

<p>
	<h2></h2><?php echo elgg_echo('themer:sitesetting'); ?></h2>
	
	<br>
	<table>
		<tr><td align="right">
		<?php echo elgg_echo('themer:current_time'); ?>
		</td><td>
		<?php
				echo elgg_view('input/pulldown', array(
					'internalname' => 'params[theme_changed_date]',
					'options_values' => array(
					$itsnow => $itsnow,
					),
					));
		?>
		</td></tr>
		
		<tr><td align="right">
		<?php echo elgg_echo('themer:elggversion'); ?>
		</td><td>
	<?php
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[theme_elggversion]',
			'options_values' => array(
				'1.7' => elgg_echo('1.7'),
				'1.6' => elgg_echo('1.6'),
			),
			'value' => $theme_elggversion
		));
		echo " ".elgg_echo('themer:elggversionsupport');
		
		?>
		</td></tr>
		
		<tr><td align="right">
		<?php echo elgg_echo('themer:cache'); ?>
		</td><td>
	<?php
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[theme_cache]',
			'options_values' => array(
				'yes' => elgg_echo('themer:yes'),
				'no' => elgg_echo('themer:no'),
			),
			'value' => $theme_cache
		));
		echo " ".elgg_echo('themer:cachesupport');
		
		?>
		</td></tr>
		
		<tr><td align="right">
		<?php echo elgg_echo('themer:mobileonly'); ?>
		</td><td>
	<?php
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[theme_mobileonly]',
			'options_values' => array(
				'yes' => elgg_echo('themer:yes'),
				'no' => elgg_echo('themer:no'),
			),
			'value' => $theme_mobileonly
		));
		
		?>
		</td></tr>
		
		
		<tr><td align="right">
		<?php echo elgg_echo('themer:mobile'); ?>
		</td><td>
	<?php
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[theme_mobile]',
			'options_values' => array(
				'yes' => elgg_echo('themer:yes'),
				'no' => elgg_echo('themer:no'),
			),
			'value' => $theme_mobile
		));
		
		?>
		</td></tr>


		<tr><td align="right">
		<?php echo elgg_echo('themer:allowusertheme'); ?>
		</td><td>
	<?php
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[theme_allowusertheme]',
			'options_values' => array(
				'yes' => elgg_echo('themer:yes'),
				'no' => elgg_echo('themer:no'),
			),
			'value' => $theme_allowusertheme
		));
		
		?>
		</td></tr>
		
		<tr><td align="right">
		<?php echo elgg_echo('themer:spotlight'); ?>
		</td><td>
	<?php
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[theme_spotlight]',
			'options_values' => array(
				'yes' => elgg_echo('themer:yes'),
				'no' => elgg_echo('themer:no'),
			),
			'value' => $theme_spotlight
		));
		
		?>
		</td></tr>
		


		<tr><td align="right">

	<?php echo elgg_echo('themer:theme'); ?>
	</td><td>
	<?php
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[theme_brightness]',
			'options_values' => $brightnesschoices,
			'value' => $theme_brightness
		));
		
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[theme_color]',
			'options_values' => $colorchoices,
			'value' => $theme_color
		));
		?>
		</td></tr>


		<tr><td align="right">
		<?php echo elgg_echo('themer:titlecolor'); ?>
		</td><td>
		<?php
		
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[title_brightness]',
			'options_values' => $brightnesschoices,
			'value' => $title_brightness
		));

	    
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[title_color]',
			'options_values' => $colorchoices,
			'value' => $title_color
		));

		?>
		</td></tr>
		
		<tr><td align="right">
		<?php echo elgg_echo('themer:subheadcolor'); ?>
		</td><td>
		<?php
		
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[subhead_brightness]',
			'options_values' => $brightnesschoices,
			'value' => $subhead_brightness
		));

		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[subhead_color]',
			'options_values' => $colorchoices,
			'value' => $subhead_color
		));

		?>
		</td></tr>
		
		<tr><td align="right">
		<?php echo elgg_echo('themer:captioncolor'); ?>
		</td><td>
		<?php
		
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[caption_brightness]',
			'options_values' => $brightnesschoices,
			'value' => $caption_brightness
		));

		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[caption_color]',
			'options_values' => $colorchoices,
			'value' => $caption_color
		));

		?>
		</td></tr>
		<tr><td align="right">
		<?php echo elgg_echo('themer:textcolor'); ?>
		</td><td>
		<?php
		
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[text_brightness]',
			'options_values' => $brightnesschoices,
			'value' => $text_brightness
		));

		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[text_color]',
			'options_values' => $colorchoices,
			'value' => $text_color
		));

		?>
		</td></tr>
		
		<tr><td align="right">
		<?php echo elgg_echo('themer:linkcolor'); ?>
		</td><td>
		<?php
		
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[link_brightness]',
			'options_values' => $brightnesschoices,
			'value' => $link_brightness
		));

		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[link_color]',
			'options_values' => $colorchoices,
			'value' => $link_color
		));

		?>
		</td></tr>
		
		<tr><td align="right">
		<?php echo elgg_echo('themer:menubackcolor'); ?>
		</td><td>
		<?php
		
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[menuback_brightness]',
			'options_values' => $brightnesschoices,
			'value' => $menuback_brightness
		));

		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[menuback_color]',
			'options_values' => $colorchoices,
			'value' => $menuback_color
		));

		?>
		</td></tr>
		
		<tr><td align="right">
		<?php echo elgg_echo('themer:menuhovercolor'); ?>
		</td><td>
		<?php
		
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[menuhover_brightness]',
			'options_values' => $brightnesschoices,
			'value' => $menuhover_brightness
		));

		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[menuhover_color]',
			'options_values' => $colorchoices,
			'value' => $menuhover_color
		));

		?>
		</td></tr>
		
		<tr><td align="right">
		<?php echo elgg_echo('themer:menutextcolor'); ?>
		</td><td>
		<?php
		
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[menutext_brightness]',
			'options_values' => $brightnesschoices,
			'value' => $menutext_brightness
		));

		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[menutext_color]',
			'options_values' => $colorchoices,
			'value' => $menutext_color
		));

		?>
		</td></tr>
		
		<tr><td align="right">
		<?php echo elgg_echo('themer:menutexthovercolor'); ?>
		</td><td>
		<?php
		
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[menutexthover_brightness]',
			'options_values' => $brightnesschoices,
			'value' => $menutexthover_brightness
		));

		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[menutexthover_color]',
			'options_values' => $colorchoices,
			'value' => $menutexthover_color
		));

		?>
		</td></tr>
		
		<tr><td align="right">
		<?php echo elgg_echo('themer:topbarcolor'); ?>
		</td><td>
		<?php
		
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[topbar_brightness]',
			'options_values' => $brightnesschoices,
			'value' => $topbar_brightness
		));

		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[topbar_color]',
			'options_values' => $colorchoices,
			'value' => $topbar_color
		));

		?>
		</td></tr>
		
		</table>
		
		<p>
			<hr>
			<?php echo elgg_echo("themer:foradvancedusersonly");
			echo elgg_view('input/pulldown', array(
			'internalname' => 'params[theme_advanced]',
			'options_values' => array(
				'no' => elgg_echo('themer:no'),
				'yes' => elgg_echo('themer:yes'),
			),
			'value' => $theme_advanced
		));
		?>
		</p>
		<table>
		<tr><td align="right">
			<?php echo elgg_echo("themer:transparency");?>
		</td><td>
			<?php
			echo elgg_view('input/pulldown', array(
			'internalname' => 'params[theme_transparency]',
			'options_values' => array(
				'no' => elgg_echo('themer:no'),
				'yes' => elgg_echo('themer:yes'),
			),
			'value' => $theme_transparency
		));
			
	
		?>
		</td></tr>
		
		
		<?php inputtext( 'pct_opacity',$theme_pct_opacity ); ?>
		<?php inputtext( 'headerheight',$theme_headerheight ); ?>
		<?php inputtext( 'headerwidth',$theme_headerwidth ); ?>
		<?php inputtext( 'background',$theme_background ); ?>
		<?php inputtext( 'topbarbackground',$theme_topbarbackground ); ?>
		<?php inputtext( 'topbarlogo',$theme_topbarlogo ); ?>
		<?php inputtext( 'topbarurl',$theme_topbarurl ); ?>
		<?php inputtext( 'headerbackground',$theme_headerbackground ); ?>
		<?php inputtext( 'logo',$theme_logo ); ?>
		
		<?php colorpicker( 'exact',$theme_exact ); ?>
		<?php colorpicker( 'titleexact',$theme_titleexact ); ?>
		<?php colorpicker( 'subheadexact',$theme_subheadexact ); ?>
		<?php colorpicker( 'captionexact',$theme_captionexact ); ?>
		<?php colorpicker( 'textexact',$theme_textexact ); ?>
		<?php colorpicker( 'linkexact',$theme_linkexact ); ?>

		<?php inputtext( 'titlefont',$theme_titlefont ); ?>
		<?php inputtext( 'bodyfont',$theme_bodyfont ); ?>
		<?php inputtext( 'captionfont',$theme_captionfont ); ?>


		</table>
</p>

<script>
$('#exact, #titleexact, #subheadexact, #captionexact, #textexact, #linkexact').ColorPicker({
	onSubmit: function(hsb, hex, rgb, el) {
		$(el).val(hex);
		$(el).ColorPickerHide();
	},
	onBeforeShow: function () {
		$(this).ColorPickerSetColor(this.value);
	}
})
.bind('keyup', function(){
	$(this).ColorPickerSetColor(this.value);
});

$('#colorexact').ColorPicker({
	color: '#0000ff',
	onShow: function (colpkr) {
		$(colpkr).fadeIn(500);
		return false;
	},
	onHide: function (colpkr) {
		$(colpkr).fadeOut(500);
		return false;
	},
	onChange: function (hsb, hex, rgb) {
		//$('#colorSelector div').css('backgroundColor', '#' + hex);
		$(this).val(hex);
	}
});
</script>


