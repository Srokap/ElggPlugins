<?php

	/** 
	 * Egxite™ Themer for Elgg
	 * This theme allows for color preferences be set for the entire site.
	 * If the admin chooses to, it also allows each individual user to personalise their color settings.
	 * The display is reformatted when using an iPhone to view the site.
	 * 
	 * @package Egxite™ Themer
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author  Egxite™ Corp. <contact@egxite.com>
	 * @copyright Egxite™ Corp. 2009-2010
	 * @link http://egxite.com/
	 * 
	 */

	 
?>

<div id="page_container">
<div id="page_wrapper">

<div id="layout_header">
<div id="wrapper_header">
	<!-- display the page title -->
	<h1><a href="<?php echo $vars['url']; ?>">
<?php 	
		$theme_logo = get_plugin_setting('theme_logo','themer');
		if( $theme_logo>"" &&  ($_SERVER['HTTP_REFERER']=="" ||
			( stripos($_SERVER['HTTP_REFERER'],"/pg/admin/")<1
			  
			))) {
			echo "<img src=\"$theme_logo\">";
			} else {
			echo $vars['config']->sitename;
			}
?>
</a></h1>
</div><!-- /#wrapper_header -->
</div><!-- /#layout_header -->
