<?php
/**
 * Elgg top toolbar
 * The standard elgg top toolbar
 *
 * @package Elgg
 * @subpackage Core
 * @author Curverider Ltd
 * @link http://elgg.org/
 */
	/** Enhancements
	 * Egxite™ Themer for Elgg
	 * This theme allows for color preferences be set for the entire site.
	 * If the admin chooses to, it also allows each individual user to personalise their color settings.
	 * The display is reformatted when using an iPhone to view the site.
	 * 
	 * @package Egxite™ Themer
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author  Egxite™ Corp. <contact@egxite.com>
	 * @copyright Egxite™ Corp. 2009-2010
	 * @link http://egxite.com/
	 * 
	 */

?>

<?php
	$theme_elggversion= get_plugin_setting('theme_elggversion','themer');
	if (isloggedin()) {
?>

<div id="elgg_topbar">

<div id="elgg_topbar_container_left">
	<div class="toolbarimages">
		<a href="<?php 
			$theme_topbarlogo = get_plugin_setting('theme_topbarlogo','themer');
			$theme_topbarurl = get_plugin_setting('theme_topbarurl','themer');
			if( $theme_topbarurl>"" ) {
				echo $theme_topbarurl;
				} else {
				echo $vars['url'];
				}
			?>" target="_blank"><img src="<?php 
			if( $theme_topbarlogo>"" ) {
				echo $theme_topbarlogo;
				} else {
				echo $vars['url']."_graphics/elgg_toolbar_logo.gif";
				}
				?>" alt="toolbar_logo graphic" width="22" height="22"/></a>

		<a href="<?php echo $_SESSION['user']->getURL(); ?>"><img class="user_mini_avatar" src="<?php echo $_SESSION['user']->getIcon('topbar'); ?>" alt="User avatar" /></a>

	</div>
	<div class="toolbarlinks">
		<a href="<?php echo $vars['url']; ?>pg/dashboard/" class="pagelinks"><?php echo elgg_echo('dashboard'); ?></a>
	</div>
		<?php

			echo elgg_view("navigation/topbar_tools");

		?>

		<div class="toolbarlinks2">
		<?php
		//allow people to extend this top menu
		echo elgg_view('elgg_topbar/extend', $vars);
		?>

		<a href="<?php echo $vars['url']; ?>pg/settings/" class="usersettings"><?php echo elgg_echo('settings'); ?></a>

		<?php

			// The administration link is for admin or site admin users only
			if ($vars['user']->admin || $vars['user']->siteadmin) {

		?>

			<a href="<?php echo $vars['url']; ?>pg/admin/" class="usersettings"><?php echo elgg_echo("admin"); ?></a>

		<?php

				}

		?>
	</div>


</div>


<div id="elgg_topbar_container_right">
		<small>
			<?php if( $theme_elggversion=='1.7' ) { echo elgg_view('output/url', array('href' => "{$vars['url']}action/logout", 'text' => elgg_echo('logout'), 'is_action' => TRUE)); }
			else
			{
				echo '<a href="'.$vars['url'].'action/logout">'. elgg_echo('logout')." </a> ";
			} ?>
		</small>
</div>

<div id="elgg_topbar_container_search">
<?php if($theme_elggversion=='1.7') {
	echo elgg_view('page_elements/searchbox'); 
	}
	else
	{
?>

<form id="searchform" action="<?php echo $vars['url']; ?>search/" method="get">
        <input type="text" size="21" name="tag" value="Search" onclick="if (this.value=='Search') { this.value='' }" class="search_input" />
        <input type="submit" value="Go" class="search_submit_button" />
</form>

<?php	}
?>

</div>
</div>
</div><!-- /#elgg_topbar -->

<div class="clearfloat"></div>

<?php
	}
