	/**
	 * Egxite™ Themer for Elgg
	 * This theme allows for color preferences be set for the entire site.
	 * If the admin chooses to, it also allows each individual user to personalise their color settings.
	 * The display is reformatted when using an iPhone to view the site.
	 * 
	 * @package Egxite™ Themer
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author  Egxite™ Corp. <contact@egxite.com>
	 * @copyright Egxite™ Corp. 2009-2010
	 * @link http://egxite.com/
	 * 
	 */


blockquote {
    margin:10px;
    border:1px solid #efefef;
    padding:4px;
}

strong {
    font-weight:bold;
}

ul {
   list-style: disc;
}

ol {
  list-style: decimal;
}
