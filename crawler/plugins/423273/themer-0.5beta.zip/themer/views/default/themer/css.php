<?php

	/**
	 * Elgg v1.5 Default Theme
	 * core CSS file - modified to include user preferred settings
	 * 
	 * Updated 10 March 09
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @link http://elgg.org/
	 *
	 * Enhancements
	 * Egxite™ Themer for Elgg
	 * This theme allows for color preferences be set for the entire site.
	 * If the admin chooses to, it also allows each individual user to personalise their color settings.
	 * The display is reformatted when using an iPhone to view the site.
	 * 
	 * @package Egxite™ Themer
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author  Egxite™ Corp. <contact@egxite.com>
	 * @copyright Egxite™ Corp. 2009-2010
	 * @link http://egxite.com/
	 * 
	 *
	 *
	 * @revisions additional dynamic color/device contributions by Alex Tanchoco 2009-09-05
	 * @revisions	2009-09-05 - user theme settings incorporated into the themer plugin.
	 * 		2009-10-22 ver 0.3 - added caching algorithm.
	 *		2010-02-16 ver 0.5 - fixed the following: 
	 *				* missing language/en.php entries
	 *				* collection menu width
	 *				new in version 0.5: 
	 *				* background image with repeat settings
	 *				* header background image option with repeat settings
	 *				* site name is replaced by logo if it has logo url set
	 *				* top bar logo and url option
	 *				* themer plugin is now disabled for the plugins page (in case of bad settings, admin can still edit them)
	 */
 
	list($usec, $sec) = explode(' ', microtime());
   	$script_start = (float) $sec + (float) $usec;

	$mobile = false;

	$theme_allowusertheme = get_plugin_setting('theme_allowusertheme','themer');
	$theme_mobileonly = get_plugin_setting('theme_mobileonly','themer');
	$theme_cache = get_plugin_setting('theme_cache','themer');
	$user = get_loggedin_user();
	$theme_changed_date = get_plugin_setting('theme_changed_date', 'themer');
	$theme_user_date = $theme_changed_date;
	
	$user_device = 'Mobile';
	
	if(!$user)
		{
		$theme_preference = 'site';
		$user_css = 'site';
		$user_guid = 0;
		}
		else
		{
		$user_guid = $user->getGUID();
        $theme_preference = get_plugin_usersetting('theme_preference', $user_guid, 'themer');
		$theme_user_date = get_plugin_usersetting('theme_changed_date', $user_guid, 'themer');
	
		$user_css = $user_guid;
		
		$user_device_setting = get_plugin_usersetting('theme_mobile', $user_guid, 'themer');
		if( $user_device_setting>'' ) 
			{
			$user_device = $user_device_setting;
			}

		}

	if( stristr($_SERVER['HTTP_USER_AGENT'], $user_device ) )
        {
		$mobile = true;
		$mobiledevice = $user_device;
		}
	
	if ($mobile)
		{
			if( get_plugin_setting('theme_mobile','themer')=='no' ) return;
			if( $user ) {
				if( $theme_allowusertheme!='no' ) {
					if( get_plugin_usersetting('theme_mobile', $user_guid, 'themer')=='no' ) return;
				}
			}
			else
			{
				$user_device = 'Mobile';
			}
		}
		else
		{
			if( $theme_mobileonly=='yes' ) return;
			$user_device = 'Desktop';
		}


	if( $theme_allowusertheme!='yes' || $theme_preference=='site' ) {
		$user_css = 'site';
	} 

	$css_path = $CONFIG->dataroot."/themer_cache";
	if( !file_exists($css_path) ) {
		mkdir( $css_path );
	}

	//check if cached file is valid and if so use it!
	$css_file = "$css_path/$user_css-$user_device.css";
	if( file_exists($css_file) && $theme_cache!='no' ) {
		$file_stamp = date("Y-m-d H:i:s", filemtime($css_file));
		if( ((($theme_changed_date < $file_stamp) && !$user) || 
			($user
					&& $user->themer_css_stamp < $file_stamp 
					&& $user->themer_css_stamp > $user->themer_css_changed 
					) ) ) { 
				require_once( $css_file );
				return;
			}
	}
	list($usec, $sec) = explode(' ', microtime());
   	$script_middle = (float) $sec + (float) $usec;

	$themer_headerheight = get_plugin_setting('theme_headerheight','themer');
	$themer_headerwidth = get_plugin_setting('theme_headerwidth','themer');
	$themer_pageheight = get_plugin_setting('theme_pageheight','themer');
	$themer_pct_opacity = get_plugin_setting('theme_pct_opacity','themer');
	
	if( trim($themer_headerheight)=="") $themer_headerheight = "40";
	if( trim($themer_headerwidth)=="") $themer_headerwidth = "1010";
	if( trim($themer_pageheight)=="") $themer_pageheight = "760";
	if( $themer_pct_opacity<0 or $themer_pct_opacity>100 or !$themer_pct_opacity ) {
		$themer_pct_opacity = 70;	//default transparency
	} 
	 

	$theme_mobilewidth = 320;	//default

	if( $mobile ) {
		$theme_mobilewidth = get_plugin_usersetting('theme_mobilewidth', $user_guid, 'themer');

        if( $theme_mobilewidth < 240 ) { 
			$theme_mobilewidth = 320;
		}
			
		//$themer_headerheight = "30";

	}

	$site_theme = get_plugin_setting('theme_color','themer');
	$theme_background = get_plugin_setting('theme_background','themer');
	$theme_headerbackground = get_plugin_setting('theme_headerbackground','themer');
	$theme_topbarbackground = get_plugin_setting('theme_topbarbackground','themer');
    	$theme_logo = get_plugin_setting('theme_logo','themer');
	
	$theme_advanced =  get_plugin_setting('theme_advanced','themer');
	$theme_titlefont = "Arial, Helvetica, sans-serif";
	$theme_bodyfont = "Verdana, Helvetica, sans-serif";
	
	$theme_menuback = '#006699'; 
	$theme_menuhover = '#0086B9'; 
	$theme_menutexthover = '#ffffff'; 
	$theme_menutext = '#999999';
	
	$themer_transparency = '';

	//z-index is needed to make children text more opaque than the page elements
	$z_index_text = "999";
	$z_index_element = "998";
	
	$transparency_pct = sprintf( "%0.2f", $themer_pct_opacity/100.00);
	$transparency_css = "filter:alpha(opacity=$themer_pct_transparency); -moz-opacity: $transparency_pct; -khtml-opacity: $transparency_pct; opacity: $transparency_pct; z-index: $z_index_element; ";
	
	$width_mobile = '98%';
	$width_desktop_left = '46%';
	$width_desktop_right = '46%';

		$menuback_color = get_plugin_setting('menuback_color','themer');
		$menuback_brightness = get_plugin_setting('menuback_brightness','themer');
		$menuhover_color = get_plugin_setting('menuhover_color','themer');
		$menuhover_brightness = get_plugin_setting('menuhover_brightness','themer');
		$menutext_color = get_plugin_setting('menutext_color','themer');
		$menutext_brightness = get_plugin_setting('menutext_brightness','themer');
		$menutexthover_color = get_plugin_setting('menutexthover_color','themer');
		$menutexthover_brightness = get_plugin_setting('menutext_brightness','themer');

	if( $theme_advanced =='yes' )
		{
		//$theme_background = get_plugin_setting('theme_background','themer');
		$theme_transparency = get_plugin_setting('theme_transparency','themer');
		
		if( $theme_transparency=='yes') $themer_transparency = "transparent; $transparency_css";
		
		$theme_exact = validate_color(get_plugin_setting('theme_exact','themer'));
		$theme_linkexact = validate_color(get_plugin_setting('theme_linkexact','themer'));
		$theme_textexact = validate_color(get_plugin_setting('theme_textexact','themer'));
		$theme_titleexact = validate_color(get_plugin_setting('theme_titleexact','themer'));
		$theme_subheadexact = validate_color(get_plugin_setting('theme_subheadexact','themer'));
		$theme_captionexact = validate_color(get_plugin_setting('theme_captionexact','themer'));
		$theme_titlefont = get_plugin_setting('theme_titlefont','themer');
		$theme_bodyfont = get_plugin_setting('theme_bodyfont','themer');
		}

	if (!$site_theme ) 
		{
		/** defaults if not site setting defined **/
		$site_theme = 'blue';
		$theme_brightness = "bright";
		$title_color = "orange";
		$title_brightness = "dim";
		$subhead_color = "orange";
		$subhead_brightness = "dim";
		$caption_color = "orange";
		$caption_brightness = "dim";
		$text_color = "black";
		$text_brightness = "dim";
		$link_color = "red";
		$link_brightness = "bright";
		}
		
	//$widget_width = $canvas_width;
		
	

		if( $mobile ) {
			$page_width = $theme_mobilewidth;
			$sidebar_width = $page_width - 12;
			$canvas_width = $page_width - 12;
			$widgets_width = $page_width - 12;

			$content_width = $canvas_width;
			$main_width = $content_width;  
			$form_width = $content_width;  
			$message_width = $content_width;

		} else {
			$page_width = $themer_headerwidth;
			$sidebar_width = $page_width * 0.30;
			$canvas_width = $themer_headerwidth - $sidebar_width - 16;
			$widgets_width = ($themer_headerwidth)/3 - 6 ;

			$content_width = $canvas_width;
			$main_width = $content_width - 20;  
			$form_width = $content_width - 60;  
			$message_width = $content_width - 18;
			}

		$user_theme = $site_theme;
		
		$theme_brightness = get_plugin_setting('theme_brightness','themer');
		$title_color = get_plugin_setting('title_color','themer');
		$title_brightness = get_plugin_setting('title_brightness','themer');
		$subhead_color = get_plugin_setting('subhead_color','themer');
		$subhead_brightness = get_plugin_setting('subhead_brightness','themer');
		$caption_color = get_plugin_setting('caption_color','themer');
		$caption_brightness = get_plugin_setting('caption_brightness','themer');
		$text_color = get_plugin_setting('text_color','themer');
		$text_brightness = get_plugin_setting('text_brightness','themer');
		$link_color = get_plugin_setting('link_color','themer');
		$link_brightness = get_plugin_setting('link_brightness','themer');

	if( $user && $theme_preference=='personal' )
		{
        	$user_theme = get_plugin_usersetting('theme_color', $user_guid, 'themer');
			if( $user_theme<'' ) {
				$user_theme = $site_theme;
			}
			else
			{
		    //  $theme_mobilewidth = get_plugin_usersetting('theme_mobilewidth', $user_guid, 'themer');        
			//	if( $theme_mobilewidth < 240 ) $theme_mobilewidth = 320;
			$theme_brightness = get_plugin_usersetting('theme_brightness', $user_guid, 'themer');
		    $title_color = get_plugin_usersetting('title_color', $user_guid, 'themer');
    		$title_brightness = get_plugin_usersetting('title_brightness', $user_guid, 'themer');
		    $subhead_color = get_plugin_usersetting('subhead_color', $user_guid, 'themer');
    		$subhead_brightness = get_plugin_usersetting('subhead_brightness', $user_guid, 'themer');
		    $caption_color = get_plugin_usersetting('caption_color', $user_guid, 'themer');
    		$caption_brightness = get_plugin_usersetting('caption_brightness', $user_guid, 'themer');
        	$text_color = get_plugin_usersetting('text_color', $user_guid, 'themer');
	        $text_brightness = get_plugin_usersetting('text_brightness', $user_guid, 'themer');
        	$link_color = get_plugin_usersetting('link_color', $user_guid, 'themer');
        	$link_brightness = get_plugin_usersetting('link_brightness', $user_guid, 'themer');
			
        	$menutext_color = $title_color;
	        $menutext_brightness = $title_brightness;
        	$menuback_color = $title_color;
	        $menuback_brightness = $title_brightness;
        	$menuhover_color = $user_theme;
	        $menuhover_brightness = $theme_brightness;
       		$menuhovertext_color = $link_color;
	        $menuhovertext_brightness = $link_brightness;
			
			}
			
		}
		
	getcolor( $user_theme, $themer_r, $themer_g, $themer_b );
	getcolor( $title_color, $title_r, $title_g, $title_b );
	getcolor( $text_color, $text_r, $text_g, $text_b );
	getcolor( $subhead_color, $subhead_r, $subhead_g, $subhead_b );
	getcolor( $caption_color, $caption_r, $caption_g, $caption_b );
	getcolor( $link_color, $link_r, $link_g, $link_b );
	getcolor( $menuback_color, $menub_r, $menub_g, $menub_b );
	getcolor( $menuhover_color, $menuh_r, $menuh_g, $menuh_b );
	getcolor( $menutext_color, $menut_r, $menut_g, $menut_b );
	getcolor( $menutexthover_color, $menuth_r, $menuth_g, $menuth_b );
	
	if( $theme_advanced=='yes' )
		{
		if( $theme_exact > '' ) getcolor( $theme_exact, $themer_r, $themer_g, $themer_b );
        if( $theme_titleexact > '' ) getcolor( $theme_titleexact, $title_r, $title_g, $title_b );
        if( $theme_subheadexact > '' ) getcolor( $theme_subheadexact, $subhead_r, $subhead_g, $subhead_b );
        if( $theme_captionexact > '' ) getcolor( $theme_captionexact, $caption_r, $caption_g, $caption_b );
        if( $theme_textexact > '' ) getcolor( $theme_textexact, $text_r, $text_g, $text_b );
        if( $theme_linkexact > '' ) getcolor( $theme_linkexact, $link_r, $link_g, $link_b );
        if( $theme_menubackexact > '' ) getcolor( $theme_menubackexact, $menub_r, $menub_g, $menub_b );
        if( $theme_menuhoverexact > '' ) getcolor( $theme_menuhoverexact, $menuh_r, $menuh_g, $menuh_b );
        if( $theme_menutextexact > '' ) getcolor( $theme_menutextexact, $menut_r, $menut_g, $menut_b );
		}

		if( !$theme_exact )
				$brigthness = getBrightness( $theme_brightness );	
			else
				$brightness = 0;

		/* dont set the same brightness level for background and text */
		if( $theme_textexact<="" )
				$textbright = getBrightness( $text_brightness );	
			else
				$textbright = 0;

		if( $theme_titleexact<="" )
				$titlebright = getBrightness( $title_brightness );	
			else
				$titlebright = 0;

		if( $theme_captionexact<="" )
				$captionbright = getBrightness( $caption_brightness );	
			else
				$captionbright = 0;
				
		if( $theme_subheadexact<="" )
				$subheadbright = getBrightness( $subhead_brightness );	
			else
				$subheadbright = 0;


		if( $theme_linkexact<="" )
				$linkbright = getBrightness( $link_brightness );	
			else
				$linkbright = 0;

		if( $theme_menuhoverexact<="" )
				$menuhoverbright = getBrightness( $menuhover_brightness );	
			else
				$menuhoverbright = 0;

		if( $theme_menubackexact<="" )
				$menubackbright = getBrightness( $menuback_brightness );	
			else
				$menubackbright = 0;

		if( $theme_menutextexact<="" )
				$menutextbright = getBrightness( $menutext_brightness );	
			else
				$menutextbright = 0;

		if( $theme_menutexthoverexact<="" )
				$menutexthoverbright = getBrightness( $menutexthover_brightness );	
			else
				$menutexthoverbright = 0;

	
	if( $user_theme=='white' ) 
		{
		$themer_b = 255; $themer_g = 255; $themer_r = 255;
		}

		$themer_canvas = sethexcolor(0x20+$brightness,$themer_r,$themer_g,$themer_b );
		$themer_page = sethexcolor($brightness,$themer_r,$themer_g,$themer_b );
		$themer_sidebar = sethexcolor(0x30+$brightness,$themer_r,$themer_g,$themer_b );
		$themer_content = sethexcolor(0x30+$brightness,$themer_r,$themer_g,$themer_b );
		$themer_titlebar = sethexcolor(0x40+$brightness,$themer_r,$themer_g,$themer_b );
		$themer_listbar = sethexcolor(0x45+$brightness,$themer_r,$themer_g,$themer_b );
		$themer_entry = sethexcolor(0x50+$brightness,$themer_r,$themer_g,$themer_b );

		$themer_textearea = themer_content;

		$themer_entrybar = $themer_entry;
		$themer_boxheader = $themer_sidebar;
		$themer_spotlight = $theme_subheadcolor;
        
		$themer_textbody = sethexcolor($textbright, $text_r, $text_g, $text_b);
        	$themer_textvisited = sprintf( "#%02X%02X%02X", min($link_r + 0x10,255), min($link_g + 0x10,255), min($link_b + 0x10,255) );
        	$themer_texturl = sprintf( "#%02X%02X%02X", min($link_r ,255), min($link_g, 255), min($link_b ,255) );
		$themer_texturlhover = sprintf( "#%02X%02X%02X", min($link_r + 0x30, 255), min($link_g + 0x30,255), min($link_b + 0x30,255));
        	$themer_textheader = sprintf( "#%02X%02X%02X", min($title_r ,255), min($title_g ,255), min($title_b ,255) );
		$themer_textbox = sprintf( "#%02X%02X%02X", min($text_r + 0x20,255), min($text_g + 0x20,255), min($text_b + 0x20,255) );
		$themer_texttitle = sethexcolor($titlebright, $title_r, $title_g, $title_b);
 
		$theme_menuback = sethexcolor($menubackbright,$menub_r,$menub_g,$menub_b );
		$theme_menuhover = sethexcolor($menuhoverbright,$menuh_r,$menuh_g,$menuh_b );
		$theme_menutext = sethexcolor($menutextbright,$menut_r,$menut_g,$menut_b );
		$theme_menutexthover = sethexcolor($menutexthoverbright,$menuth_r,$menuth_g,$menuth_b );
		
		$themer_border = $themer_sidebar;
		
		$o = new OB_FileWriter($css_file);
		$o->start();
	
		$it_is_now = date("D, F j, Y, g:i a"); 
		echo "/* This css file was automatically generated by the Egxite™ Themer plugin on $it_is_now */\r\n";
		
		$themer_css_stamp = $user->themer_css_stamp;
		echo "/* debug: user:$user_guid setting:$theme_user_date css_stamp:$themer_css_stamp file:$file_stamp */";
		
?>

/* ***************************************
	RESET BASE STYLES
*************************************** */
html, body, div, span, applet, object, iframe,
h1, h2, h3, h4, h5, h6, p, blockquote, pre,
a, abbr, acronym, address, big, cite, code,
del, dfn, em, font, img, ins, kbd, q, s, samp,
small, strike, strong, sub, sup, tt, var,
dl, dt, dd, ol, ul, li,
fieldset, form, label, legend,
table, caption, tbody, tfoot, thead, tr, th, td {
	margin: 0;
	padding: 0;
	border: 0;
	outline: 0;
	font-weight: inherit;
	font-style: inherit;
	font-size: 100%;
	font-family: inherit;
	vertical-align: baseline;
 	z-index: $z_index_text;
}
/* remember to define focus styles! */
:focus {
	outline: 0;
 	z-index: -1;
}
ol, ul {
	list-style: none;
 	z-index: <?php echo $z_index_text; ?>;
}
em, i {
	font-style:italic;
 	z-index: <?php echo $z_index_text; ?>;
}
/* tables still need cellspacing="0" (for ie6) */
table {
	border-collapse: separate;
	border-spacing: 0;
}
caption, th, td {
	text-align: left;
	font-weight: normal;
	vertical-align: top;
 	z-index: <?php echo $z_index_text; ?>;
}
blockquote:before, blockquote:after,
q:before, q:after {
	content: "";
 	z-index: <?php echo $z_index_text; ?>;
}
blockquote, q {
	quotes: "" "";
 	z-index: <?php echo $z_index_text; ?>;
}
.clearfloat { 
	clear:both;
    height:0;
    font-size: 1px;
    line-height: 0px;
 	z-index: <?php echo $z_index_text; ?>;
}

/* ***************************************
	DEFAULTS
*************************************** */

body {
	text-align:left;
	margin:0 auto;
	padding:0;
	font: 80%/1.4  <?php echo $theme_bodyfont; ?>;
	color: <?php echo $themer_textbody; ?>;
	border: none;
	z-index: <?php echo $z_index_text; ?>;
}
a {
	color: <?php echo $themer_texturl; ?>;
	text-decoration: none;
	-moz-outline-style: none;
	outline: none;
}
a:visited {
	color: <?php echo $themer_textvisited; ?>;
	
}
a:hover {
	color: <?php echo $themer_texturlhover; ?>;
	text-decoration: underline;
}
p {
	margin: 0px 6px 6px 0;
	color: <?php echo $themer_textbody; ?>;
}
img {
	border: none;
}
ul {
	margin: 2px 0px 4px;
	padding-left: 8px;
}
ul li {
	margin: 0px;
}
ol {
	margin: 2px 0px 4px;
	padding-left: 8px;
}
ul li {
	margin: 0px;
}
form {
	margin: 0px;
	padding: 0px;
}
small {
	font-size: 90%;

}
h1, h2, h3, h4, h5, h6 {
	/* font-weight: bold; */
	line-height: normal;
}
h1 { font-size: <?php if( !$mobile ) echo "1.8em;"; else echo "1.6em";
	echo " color:".$themer_texttitle." ; font-family:$theme_titlefont; ";
 
 	?>; 
 	z-index: <?php echo $z_index_text; ?>;
	}
h2 { font-size: <?php if( !$mobile ) echo "1.3em;"; else echo "1.2em";
	echo " color:".$themer_texttitle." ; font-family:$theme_titlefont; ";
 	?>; 
 	z-index: <?php echo $z_index_text; ?>;
	}
h3 { font-size: <?php if( !$mobile ) echo "1.1em;"; else echo "1.1em";
	echo " color:".$themer_texttitle." ; font-family:$theme_titlefont; ";
 	?>; 
 	z-index: <?php echo $z_index_text; ?>;
	}
h4 { font-size: <?php if( !$mobile ) echo "1.0em;"; else echo "1.0em";
	echo " color:".$themer_texttitle." ; font-family:$theme_titlefont; ";
 	?>; 
 	z-index: <?php echo $z_index_text; ?>;
	}
h5 { font-size: <?php if( !$mobile ) echo "0.9em;"; else echo "0.9m";
	echo " color:".$themer_texttitle." ; font-family:$theme_titlefont; ";
 	?>; 
 	z-index: <?php echo $z_index_text; ?>;
	}
h6 { font-size: <?php if( !$mobile ) echo "0.8em;"; else echo "0.8em";
	echo " color:".$themer_texttitle." ; font-family:$theme_titlefont; ";
 	?>; 
 	z-index: <?php echo $z_index_text; ?>;
	}

dt {
	margin: 0;
	padding: 0;
	/* font-weight: bold */;
}
dd {
	margin: 0 0 1em 1em;
	padding: 0;
}
pre, code {
	font-family:Monaco,"Courier New",Courier,monospace;
	font-size:12px;
	overflow:auto;
	
	overflow-x: auto; /* Use horizontal scroller if needed; for Firefox 2, not needed in Firefox 3 */
	white-space: pre-wrap; /* css-3 */
	white-space: -moz-pre-wrap !important; /* Mozilla, since 1999 */
	white-space: -pre-wrap; /* Opera 4-6 */
	white-space: -o-pre-wrap; /* Opera 7 */
	word-wrap: break-word; /* Internet Explorer 5.5+ */
	
}
code {
	padding:2px 3px;
}
pre {
	padding:1px 4px;
	margin:0px 0 4px 0;
	line-height:1.3em;
}

blockquote {
	padding:1px 4px;
	margin:0px 0 4px 0;
	line-height:1.3em;
	background: <?php echo $themer_entry; ?>;
	border:none !important;
	-webkit-border-radius: 5px; 
	-moz-border-radius: 5px;
}

blockquote p {
	margin:0 0 2px 0;
}

/* ***************************************
    PAGE LAYOUT - MAIN STRUCTURE
*************************************** */
#page_container {
	margin:0;
	padding:0;
	width: 100%; 
	background: <?php if( $theme_background>'' ) echo "url($theme_background) $theme_backgroundrepeat "; else echo $themer_page; ?>;
}


#page_wrapper {
	width: <?php echo $page_width."px"; ?>;
	margin:0 auto;
	padding:0;
	min-height: <?php echo $themer_pageheight."px"; ?>;
	background: transparent;
}


#layout_header {
	text-align:left;
	width:100%;
	margin: 0 5 0 5;
	height:<?php echo $themer_headerheight."px"; ?>;
	background: <?php if($theme_headerbackground>"") echo " url($theme_headerbackground) $theme_headerbackgroundrepeat "; else echo " transparent "; ?>;
}

#wrapper_header {
	margin:0;
	padding:2px 1px 1px 1px;

}
#wrapper_header h1 {
	margin:0 0 0 0;

	letter-spacing: -0.03em;
}

#layout_canvas {
	margin:0 0 2px 0;
	padding:2px;
	min-height: <?php echo "400px;"; ?>;
	-webkit-border-radius: 5px; 
	-moz-border-radius: 5px;
	background: <?php if($themer_transparency>'') echo $themer_transparency; else echo $themer_canvas; ?>;
	border-top:1px solid <?php echo $themer_canvas; ?>;
	border-left:1px solid <?php echo $themer_canvas; ?>;
	border-bottom:1px solid <?php echo $themer_canvas; ?>;
	border-right:1px solid <?php echo $themer_canvas; ?>;
	}


/* canvas layout: 1 column, no sidebar */
#one_column {
/* 	width:928px; */
	margin:2px 2px 2px 2px;
	min-height: <?php echo "400px;"; ?>;
	background: <?php if($themer_transparency>'') echo $themer_transparency; else echo $themer_content; ?>;
	padding:0 0 4px 0;
	-webkit-border-radius: 5px; 
	-moz-border-radius: 5px;
}

/* canvas layout: 2 column left sidebar */
#two_column_left_sidebar {
	width:<?php echo $sidebar_width."px"; ?>;
	margin:2px 2px 2px 2px;
	min-height: <?php echo "300px;"; ?>;
	float:left;
	background: <?php if($themer_transparency>'') echo $themer_transparency; else echo $themer_sidebar; ?>;
	padding:0px;
	-webkit-border-radius: 5px; 
	-moz-border-radius: 5px;
	border-bottom:none;
	border-right:none;
}

#two_column_left_sidebar_maincontent {
	width:<?php echo $content_width."px"; ?>;
	margin:2px 2px 2px 2px;
	min-height: <?php echo "300px;"; ?>;
	float:left;
	background: <?php if($themer_transparency>'') echo $themer_transparency; else echo $themer_content; ?>;
	padding:0 0 4px 0;
	-webkit-border-radius: 5px; 
	-moz-border-radius: 5px;
}


#two_column_left_sidebar_maincontent_boxes {
	margin:0 0px 2px 2px;
	padding:0 0 1px 0;
	width:<?php echo $content_width."px"; ?>;
	background: <?php if($themer_transparency>'') echo $themer_transparency; else echo $themer_content; ?>;
	-webkit-border-radius: 5px; 
	-moz-border-radius: 5px;
	float:left;
}
#two_column_left_sidebar_boxes {
	width:<?php echo $sidebar_width."px"; ?>;
	margin:0px 0 4px 0px;
	min-height: <?php if( !$mobile ) echo "400px;"; else echo "50px"; ?>;
	float:left;
	padding:0;
}
#two_column_left_sidebar_boxes .sidebarBox {
	margin:0px 0 8px 0;
	background: <?php if($themer_transparency>'') echo $themer_transparency; else echo $themer_content; ?>;
	padding:1px 2px 2px 2px;
	-webkit-border-radius: 5px; 
	-moz-border-radius: 5px;
	border-top:1px solid <?php echo $themer_border; ?>;
	border-left:1px solid <?php echo $themer_border; ?>;
	border-bottom:1px solid <?php echo $themer_border; ?>;
	border-right:1px solid <?php echo $themer_border; ?>;
}
#two_column_left_sidebar_boxes .sidebarBox h3 {
	padding:0 0 5px 0;
	font-size:1.25em;
	line-height:1.2em;
	color: <?php echo $themer_tabbar; ?>;
;
}

.contentWrapper {
	background:<?php if($themer_transparency>'') echo $themer_transparency; else echo $themer_content; ?>;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	padding:2px;
    	margin:0 1px 1px 1px;
}
span.contentIntro p {
	margin:0 0 0 0;
}
.notitle {
	margin-top:2px;
}

/* canvas layout: widgets (profile and dashboard) */
#widgets_left {
	width:<?php echo $widgets_width."px"; ?>;
	margin:0 4px 4px 0;
	min-height: <?php if( !$mobile ) echo "360px;"; else echo "50px"; ?>;
	padding:0;
}
#widgets_middle {
	width:<?php echo $widgets_width."px"; ?>;
	margin:0 0 4px 0;
	padding:0;
}
#widgets_right {
	width:<?php echo $widgets_width."px"; ?>;
	margin:0px 0 4px 4px;
	float:left;
	padding:0;
}
#widget_table td {
	width:<?php echo $widgets_width."px"; ?>;
	border:0;
	padding:0;
	margin:0;
	text-align: left;
	vertical-align: top;
}
/* IE6 fixes */
* html #widgets_right { float:none; }
* html #profile_info_column_left {
	margin:0 2px 0 0;
	width:200px;
}
* html #dashboard_info { width:<?php if($mobile) echo $widgets_width."px"; else echo $dashboard_width."px"; ?>; }
/* IE7 */
*:first-child+html #profile_info_column_left { width:200px; }


/* ***************************************
	SPOTLIGHT
*************************************** */
#layout_spotlight {
	margin:4px 1px 4px 1px;
	padding:1px;
	-webkit-border-radius: 6px; 
	-moz-border-radius: 6px;
	background: <?php if($themer_transparency>'') echo $themer_transparency; else echo $themer_canvas; ?>;
	border-left:1px solid <?php echo $themer_canvas; ?>;
	border-top:1px solid <?php echo $themer_canvas; ?>;
	border-bottom:1px solid <?php echo $themer_canvas; ?>;
	border-right:1px solid <?php echo $themer_canvas; ?>;
}
#wrapper_spotlight {
	margin:0;
	padding:0;
	height:auto;
}
#wrapper_spotlight #spotlight_table h2 {
	color: <?php echo $themer_spotlight; ?>;
;
	font-size:1.25em;
	line-height:1.2em;
}
#wrapper_spotlight #spotlight_table li {
	list-style: square;
	line-height: 1.2em;
	margin:2px 4px 2px 0;
	color: <?php echo $themer_spotlight; ?>;
}
#wrapper_spotlight .collapsable_box_content  {
	margin:0;
	padding:2px 2px 1px 2px;
	background:none;
	min-height:60px;
	border:none;
	border-top:1px solid <?php echo $themer_canvas; ?>;
}
#spotlight_table {
	margin:0 0 1px 0;
}
#spotlight_table .spotlightRHS {
	float:right;
	width:270px;
	margin:0 0 0 20px;
}
/* IE7 */
*:first-child+html #wrapper_spotlight .collapsable_box_content {
	width:<?php echo $page_width."px"; ?>;
}
#layout_spotlight .collapsable_box_content p {
	padding:0;
}
#wrapper_spotlight .collapsable_box_header  {
	border: none;
	background: none;
}


/* ***************************************
	FOOTER
*************************************** */
#layout_footer {
	background: <?php if($themer_transparency>'') echo $themer_transparency; else echo $themer_canvas; ?>;
	height:80px;
	-webkit-border-radius: 6px; 
	-moz-border-radius: 6px;
	margin:0 0 <?php if($mobile) echo '0px'; else echo '10px'; ?> 0;
}
#layout_footer table {
   margin:0 0 0 <?php if($mobile) echo '1px'; else echo '20px'; ?>;
}
#layout_footer a, #layout_footer p {
   color: <?php echo $themer_texturl; ?>;
   margin:0;
}
#layout_footer .footer_toolbar_links {
	text-align:right;
	padding:<?php if($mobile) echo '4px'; else echo '15px'; ?> 0 0 0;
	font-size:<?php if($mobile) echo '0.9em'; else echo '1.2em'; ?>;
	margin: 0 0 0 <?php if($mobile) echo '0px'; else echo '20px'; ?>;
}
#layout_footer .footer_legal_links {
	text-align:right;
}


/* ***************************************
  HORIZONTAL ELGG TOPBAR
*************************************** */
#elgg_topbar {
	background:<?php echo $theme_menuhover; ?> url(<?php; 
		if($theme_topbarbackground>"") { 
			echo "$theme_topbarbackground) "; 
			} else {
			echo $vars['url']."_graphics/toptoolbar_background.gif) "; 
			}
	?> repeat-x top left;"
	color:<?php echo $theme_menutext; ?>;
	border-bottom:1px solid #000000;
	min-width:<?php echo $page_width."px"; ?>;
	position:relative;
	width:100%;
	height:<?php if($mobile) echo '120px'; else echo '24px'; ?>;
	z-index: 9000; /* if you have multiple position:relative elements, then IE sets up separate Z layer contexts for each one, which ignore each other */
}
#elgg_topbar_container_left {
	float:left;
	height:24px;
	left:0px;
	top:0px;
	position:absolute;
	text-align:left;
	width:60%;
}
#elgg_topbar_container_right {
	float:right;
	height:24px;
	position:absolute;
	right:0px;
	top:0px;
	/* width:120px;*/
	text-align:right;
}
#elgg_topbar_container_search {
	float:right;
	height:21px;
	/*width:280px;*/
	position:relative;
	right:120px;
	text-align:right;
	margin:3px 0 0 0;
}
#elgg_topbar_container_left .toolbarimages {
	float:left;
	margin-right:<?php if($mobile) echo '4px'; else echo '20px'; ?>;
}
#elgg_topbar_container_left .toolbarlinks {
	color:<?php echo $theme_menutext; ?>;
	margin:0 0 <?php if($mobile) echo '4px'; else echo '10px'; ?> 0;
	float:left;
}
#elgg_topbar_container_left .toolbarlinks2 {
	color:<?php echo $theme_menutext; ?>;
	margin:3px 0 0 0;
	float:left;
}
#elgg_topbar_container_left a.loggedinuser {
	color:<?php echo $theme_menutext; ?>;
	/* font-weight:bold */;
	margin:0 0 0 5px;
}
#elgg_topbar_container_left a.pagelinks {
	color:<?php echo $theme_menutext; ?>;
	margin:0 <?php if($mobile) echo '4px'; else echo '15px'; ?> 0 5px;
	display:block;
	padding:3px;
}
#elgg_topbar_container_left a.pagelinks:hover {
	color:<?php echo $theme_menutexthover; ?>;
	background: <?php echo $theme_menuhover; ?>;
	text-decoration: none;
}
#elgg_topbar_container_left a.privatemessages {
	color:<?php echo $theme_menutexthover; ?>;
	background:transparent url(<?php echo $vars['url']; ?>_graphics/toolbar_messages_icon.gif) no-repeat left 2px;
	padding:0 0 4px 16px;
	margin:0 15px 0 5px;
	cursor:pointer;
}
#elgg_topbar_container_left a.privatemessages:hover {
	color:<?php echo $theme_menutexthover; ?>;
	text-decoration: none;
	background:transparent url(<?php echo $vars['url']; ?>_graphics/toolbar_messages_icon.gif) no-repeat left -36px;
}
#elgg_topbar_container_left a.privatemessages_new {
	background:transparent url(<?php echo $vars['url']; ?>_graphics/toolbar_messages_icon.gif) no-repeat left -17px;
	padding:0 0 0 18px;
	margin:0 15px 0 5px;
	color:<?php echo $theme_menuback; ?>;
}
/* IE6 */
* html #elgg_topbar_container_left a.privatemessages_new { background-position: left -18px; } 
/* IE7 */
*+html #elgg_topbar_container_left a.privatemessages_new { background-position: left -18px; } 

#elgg_topbar_container_left a.privatemessages_new:hover {
	text-decoration: none;
}

#elgg_topbar_container_left a.usersettings {
	margin:0 0 0 10px;
	color:<?php echo $theme_menutext; ?>;
	padding:3px;
}
#elgg_topbar_container_left a.usersettings:hover {
	background:<?php echo $theme_menuhover; ?>;
	color:<?php echo $theme_menutexthover; ?>;
}
#elgg_topbar_container_left img {
	margin:0 0 0 5px;
}
#elgg_topbar_container_left .user_mini_avatar {
	border:1px solid #eeeeee;
	margin:0 0 0 10px;
}
#elgg_topbar_container_right {
	padding:3px 0 0 0;
}
#elgg_topbar_container_right a {
	color:<?php echo $theme_menutext; ?>;
	margin:0 5px 0 0;
	background:transparent url(<?php echo $vars['url']; ?>_graphics/elgg_toolbar_logout.gif) no-repeat top right;
	padding:0 21px 0 0;
	display:block;
	height:20px;
}
/* IE6 fix */
* html #elgg_topbar_container_right a { 
	width: 120px;
}
#elgg_topbar_container_right a:hover {
	background-position: right -21px;
	background:<?php echo $theme_menuhover; ?>;
}
#elgg_topbar_panel {
	background:#006699;
	color:<?php echo $theme_menutext; ?>;
	height:200px;
	width:100%;
	padding:10px 20px 10px 20px;
	display:none;
	position:relative;
}
#searchform input.search_input {
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	background-color:#FFFFFF;
	border:1px solid #BBBBBB;
	color:#999999;
	font-size:12px;
	/* font-weight:bold */;
	margin:<?php if($mobile) echo '26px -160px 4px 0px'; else echo '0'; ?>;
	padding:2px;
	width:<?php if($mobile) echo '100px'; else echo '180px'; ?>;
	height:12px;
}
#searchform input.search_submit_button {
	-webkit-border-radius: 3px; 
	-moz-border-radius: 3px;
	color:#006699;
	background: #cccccc;
	border:none;
	font-size:12px;
	/* font-weight:bold */;
	margin:0px;
	padding:2px;
	width:auto;
	height:16px;
	cursor:pointer;
}
#searchform input.search_submit_button:hover {
	color:#ffffff;
	background: #116699;
}


/* ***************************************
	TOP BAR - VERTICAL TOOLS MENU
*************************************** */
/* elgg toolbar menu setup */
ul.topbardropdownmenu, ul.topbardropdownmenu ul {
	margin:0;
	padding:0;
	display:inline;
	float:left;
	list-style-type: none;
	z-index: 9000;
	position: relative;
}
ul.topbardropdownmenu {
	margin:0pt 10px 0pt 4px;
}
ul.topbardropdownmenu li { 
	display: block;
	list-style: none;
	margin: 0;
	padding: 0;
	float: left;
	position: relative;
}
ul.topbardropdownmenu a {
	display:block;
}
ul.topbardropdownmenu ul {
	display: none;
	position: absolute;
	left: 0;
	margin: 0;
	padding: 0;
}
/* IE6 fix */
* html ul.topbardropdownmenu ul {
	line-height: 1.1em;
}
/* IE6/7 fix */
ul.topbardropdownmenu ul a {
	zoom: 1;
} 
ul.topbardropdownmenu ul li {
	float: none;
}   
/* elgg toolbar menu style */
ul.topbardropdownmenu ul {
	width: 140px;
	top: 24px; /* 24px */
	border-top:1px solid black;
}
ul.topbardropdownmenu *:hover {
	background-color: none;
}
ul.topbardropdownmenu a {
	padding:3px;
	text-decoration:none;
	color:<?php echo $theme_menutext; ?>;
}
ul.topbardropdownmenu li.hover a {
	background-color: <?php echo $theme_menuback; ?>;
	color:<?php echo $theme_menutexthover; ?>}

	text-decoration: none;
}
ul.topbardropdownmenu ul li.drop a {
	font-weight: normal;
}
/* IE7 fixes */
*:first-child+html #elgg_topbar_container_left a.pagelinks {

}
*:first-child+html ul.topbardropdownmenu li.drop a.menuitemtools {
	padding-bottom:6px;
}
ul.topbardropdownmenu ul li a {
	background-color: <?php echo $theme_menuback; ?>;/* menu off state color */
	/* font-weight: bold */;
	padding-left:6px;
	padding-top:4px;
	padding-bottom:0;
	height:100%; /* 22px */
	border-bottom: 1px solid <?php echo $theme_menutexthover; ?>;
}
ul.topbardropdownmenu ul a.hover {
	background-color: <?php echo $theme_menuhover; ?>;
	color:<?php echo $theme_menutexthover; ?>}
ul.topbardropdownmenu ul a {
	opacity: 0.9;
	filter: alpha(opacity=90);
}


/* ***************************************
  SYSTEM MESSSAGES
*************************************** */
.messages {
    background:#ccffcc;
    color:#000000;
    padding:3px 10px 3px 10px;
    z-index: 8000;
	margin:0;
	position:fixed;
	top:170px;
	width:<?php echo $message_width."px"; ?>;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	border:4px solid #00CC00;
	cursor: pointer;
}
.messages_error {
    border:4px solid #D3322A;
    background:#F7DAD8;
    color:#000000;
    padding:3px 10px 3px 10px;
    z-index: 8000;
	margin:0;
	position:fixed;
	top:220px;
	width:<?php echo $message_width."px"; ?>;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	cursor: pointer;
}
.closeMessages {
	float:right;
	margin-top:17px;
}
.closeMessages a {
	color:#666666;
	cursor: pointer;
	text-decoration: none;
	font-size: 80%;
}
.closeMessages a:hover {
	color:black;
}


/* ***************************************
  COLLAPSABLE BOXES
*************************************** */
.collapsable_box {
	margin: 0 0 8px 0;
	height:auto;

}
/* IE6 fix */
* html .collapsable_box  { 
	height:8px;
}
.collapsable_box_header {
	color: <?php echo $themer_listtab; ?>;

	padding: 5px 10px 5px 10px;
	margin:0;
	border-left: 1px solid <?php echo $themer_border; ?>;
	border-right: 1px solid  <?php echo $themer_border; ?>;
	border-bottom: 1px solid <?php echo $themer_border; ?>;
	-moz-border-radius-topleft:8px;
	-moz-border-radius-topright:8px; 
	-webkit-border-top-right-radius:8px;
	-webkit-border-top-left-radius:8px;
	background: <?php echo $themer_page; ?>;
}
.collapsable_box_header h1 {
	color: <?php echo $themer_texttitle; ?>;
	font-size:1.25em;
	line-height: 1.2em;
}
.collapsable_box_content {
	padding: 10px 0 10px 0;
	margin:0;
	height:auto;
	background: <?php echo $themer_content; ?>;
	-moz-border-radius-bottomleft:8px;
	-moz-border-radius-bottomright:8px;
	-webkit-border-bottom-right-radius:8px;
	-webkit-border-bottom-left-radius:8px;
	/*** border-left: 1px solid  <?php echo $themer_border; ?>;
	border-right: 1px solid  <?php echo $themer_border; ?>;
	border-bottom: 1px solid  <?php echo $themer_border; ?>;
	***/
}
.collapsable_box_content .contentWrapper {
	margin-bottom:1px;
	background: <?php echo $themer_entry; ?>;

}
.collapsable_box_editpanel {
	display: none;
	background:  <?php echo $themer_listbar; ?>;
	padding:10px 10px 5px 10px;
	border-left: 1px solid  <?php echo $themer_border; ?>;
    border-right: 1px solid  <?php echo $themer_border; ?>;
    border-top: 1px solid  <?php echo $themer_border; ?>;
	border-bottom: 1px solid  <?php echo $themer_border; ?>;
}
.collapsable_box_editpanel p {
	margin:0 0 5px 0;
}
.collapsable_box_header a.toggle_box_contents {
	color: <?php echo $themer_texturl; ?>;
	cursor:pointer;
	font-family:<?php echo font-family;?>;
;
	font-size:20px;
	/* font-weight: bold */;
	text-decoration:none;
	float:right;
	margin: 0;
	margin-top: -7px;
}
.collapsable_box_header a.toggle_box_edit_panel {
	color: <?php echo $themer_texturl; ?>;
	cursor:pointer;
	font-size:9px;
	text-transform: uppercase;
	text-decoration:none;
	font-weight: normal;
	float:right;
	margin: 3px 10px 0 0;
}
.collapsable_box_editpanel label {
	font-weight: normal;
	font-size: 100%;
}
/* used for collapsing a content box */
.display_none {
	display:none;
}
/* used on spotlight box - to cancel default box margin */
.no_space_after {
	margin: 0 0 0 0;
}



/* ***************************************
	GENERAL FORM ELEMENTS
*************************************** */
label {
	/* font-weight: bold */;
	color:<?php echo $themer_textbody; ?>;
	font-size: 110%;
}

input {
	font: 120% Arial, Helvetica, sans-serif;
	padding: 3px;
	border: 1px solid  <?php echo $themer_textborder; ?>;
	background: <?php echo $themer_listbar; ?>;
	color:  <?php echo $themer_textbody; ?>;
	-webkit-border-radius: 5px; 
	-moz-border-radius: 5px;
}
textarea {
	font: 120% Arial, Helvetica, sans-serif;
	border: solid 1px  <?php echo $themer_textborder; ?>;
	padding: 2px;
	color: <?php echo $themer_textbody; ?>;
	-webkit-border-radius: 5px; 
	-moz-border-radius: 5px;
}
textarea:focus, input[type="text"]:focus {
	border: solid 1px <?php echo $themer_textborder; ?>;
	color: <?php echo $themer_textbody; ?>;
	background:<?php echo $themer_listbar; ?>;
}
.submit_button {
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #ffffff;
	background:#116699;
	border: 1px solid #116699;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	width: auto;
	height: 25px;
	padding: 2px 6px 2px 6px;
	margin:10px 0 10px 0;
	cursor: pointer;
}
.submit_button:hover, input[type="submit"]:hover {
	background: #0054a7;
	border-color: #0054a7;
}

input[type="submit"] {
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #ffffff;
	background:#116699;
	border: 1px solid #116699;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	width: auto;
	height: 25px;
	padding: 2px 6px 2px 6px;
	margin:10px 0 10px 0;
	cursor: pointer;
}
.cancel_button {
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #999999;
	background:#dddddd;
	border: 1px solid #999999;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	width: auto;
	height: 25px;
	padding: 2px 6px 2px 6px;
	margin:10px 0 10px 10px;
	cursor: pointer;
}
.cancel_button:hover {
	background: #cccccc;
}

.input-text{
	width:98%;
},
.input-tags{
	width:98%;
},
.input-url{
	width:98%;
},

.input-textarea {
	width:<?php if ($mobile) echo "96%"; else echo "55%"; ?>;
	background: <?php echo $themer_textarea; ?>;
}

.input-textarea {
	height: 200px;
}


/* ***************************************
	LOGIN / REGISTER
*************************************** */
#login-box {
	margin:0 0 10px 0;
	padding:0 0 10px 0;
	background: <?php echo $themer_sidebar; ?>;
	-webkit-border-radius: 5px; 
	-moz-border-radius: 5px;
    	text-align:left;
}

#login-box form {
	margin:0 10px 0 10px;
	padding:0 10px 4px 10px;
	background: <?php echo $themer_sidebar; ?>;
	-webkit-border-radius: 5px; 
	-moz-border-radius: 5px;
	align: center;

}
#login-box h2 {
	color:#<?php echo $themer_texttitle; ?>;
	font-size:1.35em;
	line-height:1.2em;
	margin:0 0 0 8px;
	padding:5px 5px 0 5px;
}

#login-box .login-textarea {
	width: <?php if( $mobile) echo "80%"; else echo "96%"; ?>
}

#login-box label,
#register-box label {
	font-size: 1.0em;
	color:<?php echo $themer_texttitle; ?>;
}

#login-box p.loginbox {
	margin:0;
	width: <?php if( $mobile) echo "80%"; else echo "96%"; ?>
}
#login-box input[type="text"],
#login-box input[type="password"],
#register-box input[type="text"],
#register-box input[type="password"] {
	margin:0 0 10px 0;
}
#register-box input[type="text"],
#register-box input[type="password"] {

}
#login-box h2,
#login-box-openid h2,
#register-box h2,
#add-box h2,

#forgotten_box h2 {
	color:#0054A7;
	font-size:1.15em;
	line-height:1.0em;
	margin:0pt 0pt 5px;
}
#register-box {
    text-align:left;
    width: 96%;
    padding:10px;
    background: <?php echo $themer_sidebar; ?>;
    margin:0;
	-webkit-border-radius: 6px; 
	-moz-border-radius: 6px;
}
#persistent_login label {
	font-size:1.0em;
	font-weight: normal;
}
/* login and openID boxes when not running custom_index mod */
#two_column_left_sidebar #login-box {
	width: <?php if( $mobile) echo "80%"; else echo "100%"; ?>
	background: none;
}
#two_column_left_sidebar #login-box form {
	width: <?php if( $mobile) echo "80%"; else echo "100%"; ?>
	margin:10px 10px 0 10px;
	padding:5px 0 5px 10px;
}
#two_column_left_sidebar #login-box h2 {
	margin:0 0 0 5px;
	padding:5px 5px 0 5px;
}
#two_column_left_sidebar #login-box .login-textarea {
	width: <?php if( $mobile) echo "80%"; else echo "96%"; ?>
}


/* ***************************************
	PROFILE
*************************************** */
#profile_info {
	margin:0 0 20px 0;
	padding:20px;
	border-top:1px solid <?php echo $themer_sidebar; ?>;
	border-left:1px solid <?php echo $themer_sidebar; ?>;
	border-bottom:1px solid <?php echo $themer_sidebar; ?>;
	border-right:1px solid <?php echo $themer_sidebar; ?>;
	background: <?php if($themer_transparency>'') echo $themer_transparency; else echo $themer_listbar; ?>;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
}
#profile_info_column_left {
	float:left;
	padding: 0;
	margin:0 20px 0 0;
}
#profile_info_column_middle {
	float:left;
	width:<?php echo $widgets_width."px"; ?>;
	padding: 0;
}
#profile_info_column_right {
	width:<?php echo $widgets_width."px"; ?>;
	margin:0 0 0 0;
	background:<?php if($themer_transparency>'') echo $themer_transparency; else echo $themer_sidebar; ?>;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	padding:4px;
}
#dashboard_info {
	margin:0px 0px 0 0px;
	padding:20px;
	border-bottom:1px solid <?php echo $themer_border; ?>;
	border-right:1px solid <?php echo $themer_border; ?>;
	background: <?php if($themer_transparency>'') echo $themer_transparency; else echo $themer_listbar; ?>;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
}
#profile_menu_wrapper {
	margin:10px 0 10px 0;
	width:200px;
}
#profile_menu_wrapper p {
	border-bottom:1px solid <?php echo $themer_border; ?>;
}
#profile_menu_wrapper p:first-child {
	border-top:1px solid <?php echo $themer_border; ?>;
}
#profile_menu_wrapper a {
	color:<?php echo $themer_linkcolor; ?>;
	display:block;
	padding:0 0 0 3px;
}
#profile_menu_wrapper a:hover {
	color:<?php echo $themer_textbody; ?>;
	background:<?php echo $themer_page; ?>;
	text-decoration:none;
}
p.user_menu_friends, p.user_menu_profile, 
p.user_menu_removefriend, 
p.user_menu_friends_of {
	margin:0;
}
#profile_menu_wrapper .user_menu_admin {
	border-top:none;
}

#profile_info_column_middle p {
	margin:7px 0 7px 0;
	padding:2px 4px 2px 4px;
}
/* profile owner name */
#profile_info_column_middle h2 {
	padding:0 0 14px 0;
	margin:0;
}
#profile_info_column_middle .profile_status {
	background:<?php echo $themer_listbar; ?>;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	padding:2px 4px 2px 4px;
	line-height:1.2em;
}
#profile_info_column_middle .profile_status span {
	display:block;
	font-size:90%;
	color:<?php echo $themer_listbar; ?>;	
}
#profile_info_column_middle a.status_update {
	float:right;	
}
#profile_info_column_middle .odd {
	background:<?php echo $themer_listbar; ?>;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
}
#profile_info_column_middle .even {
	background:<?php echo $themer_listbar; ?>;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
}
#profile_info_column_right p {
	margin:0 0 7px 0;
}
#profile_info_column_right .profile_aboutme_title {
	margin:0;
	padding:0;
	line-height:1em;
}
/* edit profile button */
.profile_info_edit_buttons {
	float:right;
	margin:0  !important;
	padding:0 !important;
}
.profile_info_edit_buttons a {
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #ffffff;
	background:#116699;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	width: auto;
	padding: 2px 6px 2px 6px;
	margin:0;
	cursor: pointer;
}
.profile_info_edit_buttons a:hover {
	background: #0054a7;
	text-decoration: none;
	color: white;
}


/* ***************************************
	RIVER
*************************************** */
#river,
.river_item_list {
	border-top:1px solid #dddddd;
}
.river_item p {
	margin:0;
	padding:0 0 0 21px;
	line-height:1.1em;
	min-height:17px;
}
.river_item {
	border-bottom:1px solid #dddddd;
	padding:2px 0 2px 0;
}
.river_item_time {
	font-size:90%;
	color:#666666;
}
/* IE6 fix */
* html .river_item p { 
	padding:3px 0 3px 20px;
}
/* IE7 */
*:first-child+html .river_item p {
	min-height:17px;
}
.river_user_update {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_profile.gif) no-repeat left -1px;
}
.river_object_user_profileupdate {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_profile.gif) no-repeat left -1px;
}
.river_object_user_profileiconupdate {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_profile.gif) no-repeat left -1px;
}
.river_object_annotate {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_comment.gif) no-repeat left -1px;
}
.river_object_bookmarks_create {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_bookmarks.gif) no-repeat left -1px;
}
.river_object_bookmarks_comment {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_comment.gif) no-repeat left -1px;
}
.river_object_status_create {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_status.gif) no-repeat left -1px;
}
.river_object_file_create {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_files.gif) no-repeat left -1px;
}
.river_object_file_update {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_files.gif) no-repeat left -1px;
}
.river_object_file_comment {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_comment.gif) no-repeat left -1px;
}
.river_object_widget_create {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_plugin.gif) no-repeat left -1px;
}
.river_object_forums_create {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_forum.gif) no-repeat left -1px;
}
.river_object_forums_update {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_forum.gif) no-repeat left -1px;
}
.river_object_widget_update {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_plugin.gif) no-repeat left -1px;	
}
.river_object_blog_create {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_blog.gif) no-repeat left -1px;
}
.river_object_blog_update {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_blog.gif) no-repeat left -1px;
}
.river_object_blog_comment {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_comment.gif) no-repeat left -1px;
}
.river_object_forumtopic_create {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_forum.gif) no-repeat left -1px;
}
.river_user_friend {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_friends.gif) no-repeat left -1px;
}
.river_object_relationship_friend_create {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_friends.gif) no-repeat left -1px;
}
.river_object_relationship_member_create {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_forum.gif) no-repeat left -1px;
}
.river_object_thewire_create {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_thewire.gif) no-repeat left -1px;
}
.river_group_join {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_forum.gif) no-repeat left -1px;
}
.river_object_groupforumtopic_annotate {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_comment.gif) no-repeat left -1px;
}
.river_object_groupforumtopic_create {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_forum.gif) no-repeat left -1px;
}
.river_object_sitemessage_create {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_blog.gif) no-repeat left -1px;	
}
.river_user_messageboard {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_comment.gif) no-repeat left -1px;	
}
.river_object_page_create {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_pages.gif) no-repeat left -1px;
}
.river_object_page_top_create {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_pages.gif) no-repeat left -1px;
}
.river_object_page_top_comment {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_comment.gif) no-repeat left -1px;
}
.river_object_page_comment {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_comment.gif) no-repeat left -1px;
}

/* ***************************************
	SEARCH LISTINGS	
*************************************** */
.search_listing {
	display: block;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	background:<?php echo $themer_listbar; ?>;
	margin:0 10px 5px 10px;
	padding:5px;
}
.search_listing_icon {
	float:left;
}
.search_listing_icon img {
	width: 40px;
}
.search_listing_icon .avatar_menu_button img {
	width: 15px;
}
.search_listing_info {
	margin-left: 50px;
	min-height: 40px;
}
/* IE 6 fix */
* html .search_listing_info {
	height:40px;
}
.search_listing_info p {
	margin:0 0 3px 0;
	line-height:1.2em;
}
.search_listing_info p.owner_timestamp {
	margin:0;
	padding:0;
	color: <?php echo $themer_caption; ?>;
	font-size: 90%;
}
table.search_gallery {
	border-spacing: 10px;
	margin:0 0 0 0;
}
.search_gallery td {
	padding: 5px;
}

.search_gallery_item {
	background: transparent;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	width:170px;
}

.search_gallery_item:hover {
	background: black;
	color:white;
}
.search_gallery_item .search_listing {
	background: none;
	text-align: center;
}
.search_gallery_item .search_listing_header {
	text-align: center;
}
.search_gallery_item .search_listing_icon {
	position: relative;
	text-align: center;
}
.search_gallery_item .search_listing_info {
	margin: 5px;
}
.search_gallery_item .search_listing_info p {
	margin: 5px;
	margin-bottom: 10px;
}
.search_gallery_item .search_listing {
	background: none;
	text-align: center;
}
.search_gallery_item .search_listing_icon {
	position: absolute;
	margin-bottom: 20px;
}
.search_gallery_item .search_listing_info {
	margin: 5px;
}
.search_gallery_item .search_listing_info p {
	margin: 5px;
	margin-bottom: 10px;
}


/* ***************************************
	FRIENDS
*************************************** */
/* friends widget */
#widget_friends_list {
	display:table;
	width:275px;
	margin:0 10px 0 10px;
	padding:8px 0 4px 8px;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	background:white;
}
.widget_friends_singlefriend {
	float:left;
	margin:0 5px 5px 0;
}


/* ***************************************
	ADMIN AREA - PLUGIN SETTINGS
*************************************** */
.plugin_details {
	margin:0 10px 5px 10px;
	padding:0 7px 4px 10px;
	-webkit-border-radius: 5px; 
	-moz-border-radius: 5px;
}
.admin_plugin_reorder {
	float:right;
	width:200px;
	text-align: right;
}
.admin_plugin_reorder a {
	padding-left:10px;
	font-size:80%;
	color:#999999;
}
.plugin_details a.pluginsettings_link {
	cursor:pointer;
	font-size:80%;
}
.active {
	border:1px solid #999999;
    background:<?php echo $themer_listbar; ?>;
}
.not-active {
    border:1px solid #999999;
	background:<?php echo $themer_content; ?>;
}
.plugin_details p {
	margin:0;
	padding:0;
}
.plugin_details a.manifest_details {
	cursor:pointer;
	font-size:80%;
}
.manifest_file {
	background:<?php echo $themer_menuback; ?>;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	padding:5px 10px 5px 10px;
	margin:4px 0 4px 0;
	display:none;
}
.admin_plugin_enable_disable {
	width:150px;
	margin:10px 0 0 0;
	float:right;
	text-align: right;
}
.contentIntro .enableallplugins,
.contentIntro .disableallplugins {
	float:right;
}
.contentIntro .enableallplugins {
	margin-left:10px;
}
.contentIntro .enableallplugins, 
.not-active .admin_plugin_enable_disable a {
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #ffffff;
	background:#116699;
	border: 1px solid #116699;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	width: auto;
	padding: 4px;
	cursor: pointer;
}
.contentIntro .enableallplugins:hover, 
.not-active .admin_plugin_enable_disable a:hover {
	background:<?php echo $themer_menuhover; ?>;
	border: 1px solid #0054a7;
	text-decoration: none;
}
.contentIntro .disableallplugins, 
.active .admin_plugin_enable_disable a {
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #ffffff;
	background:#999999;
	border: 1px solid #999999;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	width: auto;
	padding: 4px;
	cursor: pointer;
}
.contentIntro .disableallplugins:hover, 
.active .admin_plugin_enable_disable a:hover {
	background:<?php echo $themer_menuhover; ?>;
	border: 1px solid #006699;
	text-decoration: none;
}
.pluginsettings {
	margin:15px 0 5px 0;
	background:#bbdaf7;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	padding:10px;
	display:none;
}
.pluginsettings h3 {
	padding:0 0 5px 0;
	margin:0 0 5px 0;
	border-bottom:1px solid #999999;
}
#updateclient_settings h3 {
	padding:0;
	margin:0;
	border:none;
}
.input-access {
	margin:5px 0 0 0;
}

/* ***************************************
	GENERIC COMMENTS
*************************************** */
.generic_comment_owner {
	font-size: 90%;
}
.generic_comment {
	-webkit-border-radius: 5px; 
	-moz-border-radius: 5px;
    padding:6px;
    margin:0 6px 6px 6px;
}
.generic_comment_icon {
	float:left;
}
.generic_comment_details {
	margin-left: 60px;
}

.generic_comment_details p {
	margin: 0 0 5px 0;
}
.generic_comment_owner {
	margin: 0px;
	font-size:90%;
	border-top: 1px solid #aaaaaa;
}
/* IE6 */
* html #generic_comment_tbl { width:<?php echo $widgets_width."px"; ?> !important;}

	
/* ***************************************
  PAGE-OWNER BLOCK
*************************************** */
#owner_block {
	padding:10px;
}
#owner_block_icon {
	float:left;
	margin:0 10px 0 0;
}
#owner_block_rss_feed,
#owner_block_odd_feed,
#owner_block_bookmark_this,
#owner_block_report_this {
	padding:5px 0 0 0;
}
#owner_block_report_this {
	padding-bottom:5px;
	border-bottom:1px solid #cccccc;
}
#owner_block_rss_feed a {
	font-size: 90%;
	color:#999999;
	padding:0 0 4px 20px;
	background: url(<?php echo $vars['url']; ?>_graphics/icon_rss.gif) no-repeat left top;
}
#owner_block_odd_feed a {
	font-size: 90%;
	color:#999999;
	padding:0 0 4px 20px;
	background: url(<?php echo $vars['url']; ?>_graphics/icon_odd.gif) no-repeat left top;
}
#owner_block_bookmark_this a {
	font-size: 90%;
	color:#999999;
	padding:0 0 4px 20px;
	background: url(<?php echo $vars['url']; ?>_graphics/icon_bookmarkthis.gif) no-repeat left top;
}
#owner_block_report_this a {
	font-size: 90%;
	color:#999999;
	padding:0 0 4px 20px;
	background: url(<?php echo $vars['url']; ?>_graphics/icon_reportthis.gif) no-repeat left top;
}
#owner_block_rss_feed a:hover,
#owner_block_odd_feed a:hover,
#owner_block_bookmark_this a:hover,
#owner_block_report_this a:hover {
	color: #0054a7;
}
#owner_block_desc {
	padding:4px 0 4px 0;
	margin:0 0 0 0;
	line-height: 1.2em;
	border-bottom:1px solid <?php echo $themer_sidebar; ?>;
	color:<?php echo $themer_textbody; ?>;
}
#owner_block_content {
	margin:0 0 4px 0;
	padding:3px 0 0 0;
	min-height:35px;
	/* font-weight: bold */;
}
#owner_block_content a {
	line-height: 1em;
}
.ownerblockline {
	padding:0;
	margin:0;
	border-bottom:1px solid #cccccc;
	height:1px;
}
#owner_block_submenu {
	margin:20px 0 20px 0;
	padding: 0;
	width:100%;
}
#owner_block_submenu ul {
	list-style: none;
	padding: 0;
	margin: 0;
}
#owner_block_submenu ul li.selected a {
	background: <?php echo $theme_menuback; ?>;
	color:<?php echo $theme_menutexthover; ?>;
	z-index: <?php echo $z_index_text; ?>;
}
#owner_block_submenu ul li.selected a:hover {
	background: <?php echo $theme_menuhover; ?>;
	color:<?php echo $theme_menutexthover; ?>;
	z-index: <?php echo $z_index_text; ?>;
}
#owner_block_submenu ul li a {
	text-decoration: none;
	display: block;
	margin: 2px 0 0 0;
	color:<?php echo $theme_menutext; ?>;
	padding:4px 6px 4px 10px;
	/* font-weight: bold */;
	line-height: 1.1em;
	-webkit-border-radius: 10px; 
	-moz-border-radius: 10px;
	z-index: <?php echo $z_index_text; ?>;
}
#owner_block_submenu ul li a:hover {
	color:<?php echo $theme_menutexthover; ?>;
	background: <?php echo $theme_menuhover; ?>;
	z-index: <?php echo $z_index_text; ?>;
}

/* IE 6 + 7 menu arrow position fix */
* html #owner_block_submenu ul li.selected a {
	background-position: left 10px;
}
*:first-child+html #owner_block_submenu ul li.selected a {
	background-position: left 8px;
}

#owner_block_submenu .submenu_group {
	border-bottom: 1px solid #cccccc;
	margin:10px 0 0 0;
	padding-bottom: 10px;
}

#owner_block_submenu .submenu_group .submenu_group_filter ul li a,
#owner_block_submenu .submenu_group .submenu_group_filetypes ul li a {
	color:#666666;
}
#owner_block_submenu .submenu_group .submenu_group_filter ul li.selected a,
#owner_block_submenu .submenu_group .submenu_group_filetypes ul li.selected a {
	background:#999999;
	color:white;
}
#owner_block_submenu .submenu_group .submenu_group_filter ul li a:hover,
#owner_block_submenu .submenu_group .submenu_group_filetypes ul li a:hover {
	color:white;
	background: #999999;
}


/* ***************************************
	PAGINATION
*************************************** */
.pagination {
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	background:<?php echo $themer_sidebar; ?>;
	margin:5px 10px 5px 10px;
	padding:5px;
}
.pagination .pagination_number {
	display:block;
	float:left;
	background:<?php echo $themer_sidebar; ?>;
	border:1px solid #116699;
	text-align: center;
	color:<?php echo $theme_menutext; ?>;
	font-size: 12px;
	font-weight: normal;
	margin:0 6px 0 0;
	padding:0px 4px;
	cursor: pointer;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
}
.pagination .pagination_number:hover {
	background:<?php echo $theme_menuhover; ?>;
	color:<?php echo $theme_menutext; ?>;
	font-style: bold;
	text-decoration: none;
}
.pagination .pagination_more {
	display:block;
	float:left;
	background:<?php echo $themer_menuback; ?>;
	border:1px solid <?php echo $themer_menutext; ?>;
	text-align: center;
	color:<?php echo $theme_menutext; ?>;
	font-size: 12px;
	font-weight: normal;
	margin:0 6px 0 0;
	padding:0px 4px;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
}
.pagination .pagination_previous,
.pagination .pagination_next {
	display:block;
	float:left;
	background:<?php echo $theme_sidebar; ?>;
	border:1px solid <?php echo $theme_menutext; ?>;
	color:<?php echo $theme_menutext; ?>;
	text-align: center;
	font-size: 12px;
	font-weight: normal;
	margin:0 6px 0 0;
	padding:0px 4px;
	cursor: pointer;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
}
.pagination .pagination_previous:hover,
.pagination .pagination_next:hover {
	border:1px solid <?php echo $theme_menuhover; ?>;
	background:<?php echo $theme_menuhover; ?>;
	color:<?php echo $theme_menutext; ?>;
	text-decoration: none;
}
.pagination .pagination_currentpage {
	display:block;
	float:left;
	background:<?php echo $theme_menuback; ?>;
	border:1px solid #116699;
	text-align: center;
	color:	<?php echo $themer_menuhover; ?>;
	font-size: 12px;
	font-weight: bold;
	margin:0 6px 0 0;
	padding:0px 4px;
	cursor: pointer;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
}
	

	
/* ***************************************
  WIDGET PICKER (PROFILE & DASHBOARD)
*************************************** */
/* 'edit page' button */
a.toggle_customise_edit_panel { 
	float:right;
	clear:right;
	color: #116699;
	background: white;
	border:1px solid #cccccc;
	padding: 5px 10px 5px 10px;
	margin:0 0 20px 0;
	width:280px;
	text-align: left;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
}
a.toggle_customise_edit_panel:hover { 
	color: #ffffff;
	background: #0054a7;
	border:1px solid #0054a7;
	text-decoration:none;
}
#customise_editpanel {
	display:none;
	margin: 0 0 20px 0;
	padding:10px;
	background: #dedede;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
}

/* Top area - instructions */
.customise_editpanel_instructions {
	width:<?php echo $canvas_width."px"; ?>;
	padding:0 0 10px 0;
}
.customise_editpanel_instructions h2 {
	padding:0 0 10px 0;
}
.customise_editpanel_instructions p {
	margin:0 0 5px 0;
	line-height: 1.4em;
}

/* RHS (widget gallery area) */
#customise_editpanel_rhs {
	float:right;
	width:230px;
	background:white;
}
#customise_editpanel #customise_editpanel_rhs h2 {
	color:#006699;
	font-size: 1.4em;
	margin:0;
	padding:6px;
}
#widget_picker_gallery {
	border-top:1px solid #cccccc;
	background:white;
	width:<?php $pwt=$page_width/4-25; echo $pwt."px"; ?>; 
	height:340px;
	padding:10px;
	overflow:scroll;
	overflow-x:hidden;
}

/* main page widget area */
#customise_page_view {
	width: 98%;
	padding:10px;
	margin:0 0 10px 0;
	background:white;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
}

#customise_page_view h2 {
	border-top:1px solid #cccccc;
	border-right:1px solid #cccccc;
	border-left:1px solid #cccccc;
	margin:0;
	padding:5px;
	width:200px;
	color: #0054a7;
	background: <?php echo $themer_textarea; ?>;
	font-size:1.25em;
	line-height: 1.2em;
}
#profile_box_widgets {
	width:<?php echo $widgets_width."px"; ?>;
	margin:0 10px 10px 0;
	padding:5px 5px 0px 5px;
	min-height: 50px;
	border:1px solid #cccccc;
	background: #dedede;
}
#customise_page_view h2.profile_box {
	width:<?php echo $widgets_width."px"; ?>;
	color: #999999;
}
#profile_box_widgets p {
	color:#999999;
}
#leftcolumn_widgets {
	width:200px;
	margin:0 10px 0 0;
	padding:5px 5px 40px 5px;
	min-height: 190px;
	border:1px solid #cccccc;
}
#middlecolumn_widgets {
	width:200px;
	margin:0 10px 0 0;
	padding:5px 5px 40px 5px;
	min-height: 190px;
	border:1px solid #cccccc;
}
#rightcolumn_widgets {
	width:200px;
	margin:0;
	padding:5px 5px 40px 5px;
	min-height: 190px;
	border:1px solid #cccccc;
}
#rightcolumn_widgets.long {
	min-height: 288px;
}
/* IE6 fix */
* html #leftcolumn_widgets { 
	height: 190px;
}
* html #middlecolumn_widgets { 
	height: 190px;
}
* html #rightcolumn_widgets { 
	height: 190px;
}
* html #rightcolumn_widgets.long { 
	height: 338px;
}

#customise_editpanel table.draggable_widget {
	width:200px;
	background: #cccccc;
	margin: 10px 0 0 0;
	vertical-align:text-top;
	border:1px solid #cccccc;
}
#widget_picker_gallery table.draggable_widget {
	width:200px;
	background: #cccccc;
	margin: 10px 0 0 0;
}

/* take care of long widget names */
#customise_editpanel table.draggable_widget h3 {
	word-wrap:break-word;/* safari, webkit, ie */
	width:140px;
	line-height: 1.1em;
	overflow: hidden;/* ff */
	padding:4px;
}
#widget_picker_gallery table.draggable_widget h3 {
	word-wrap:break-word;
	width:145px;
	line-height: 1.1em;
	overflow: hidden;
	padding:4px;
}
#customise_editpanel img.more_info {
	background: url(<?php echo $vars['url']; ?>_graphics/icon_customise_info.gif) no-repeat top left;
	cursor:pointer;
}
#customise_editpanel img.drag_handle {
	background: url(<?php echo $vars['url']; ?>_graphics/icon_customise_drag.gif) no-repeat top left;
	cursor:move;
}
#customise_editpanel img {
	margin-top:4px;
}
#widget_moreinfo {
	position:absolute;
	border:1px solid #006699;
	background:#e4ecf5;
	color:#006699;
	padding:5px;
	display:none;
	width: 200px;
	line-height: 1.2em;
}
/* droppable area hover class  */
.droppable-hover {
	background:#bbdaf7;
}
/* target drop area class */
.placeholder {
	border:2px dashed #AAA;
	width:196px !important;
	margin: 10px 0 10px 0;
}
/* class of widget while dragging */
.ui-sortable-helper {
	background: #116699;
	color:white;
	padding: 4px;
	margin: 10px 0 0 0;
	width:200px;
}
/* IE6 fix */
* html .placeholder { 
	margin: 0;
}
/* IE7 */
*:first-child+html .placeholder {
	margin: 0;
}
/* IE6 fix */
* html .ui-sortable-helper h3 { 
	padding: 4px;
}
* html .ui-sortable-helper img.drag_handle, * html .ui-sortable-helper img.remove_me, * html .ui-sortable-helper img.more_info {
	padding-top: 4px;
}
/* IE7 */
*:first-child+html .ui-sortable-helper h3 {
	padding: 4px;
}
*:first-child+html .ui-sortable-helper img.drag_handle, *:first-child+html .ui-sortable-helper img.remove_me, *:first-child+html .ui-sortable-helper img.more_info {
	padding-top: 4px;
}


/* ***************************************
	BREADCRUMBS
*************************************** */
#pages_breadcrumbs {
	font-size: 80%;
	color:#<?php echo $themer_linkurl; ?>;
	padding:0;
	margin:2px 0 0 10px;
}
#pages_breadcrumbs a {
	color:<?php echo $themer_linkvisited; ?>;
	text-decoration: none;
}
#pages_breadcrumbs a:hover {
	color: <?php echo $themer_linkurl; ?>;
	text-decoration: underline;
}


/* ***************************************
	MISC.
*************************************** */
/* general page titles in main content area */
#content_area_user_title h2 {	
	margin:0 0 0 6px;
	padding:5px;
	color:<?php echo $themer_texttitle; ?>;
	font-size:1.35em;
	line-height:1.2em;
}
/* reusable generic collapsible box */
.collapsible_box {
	background:#dedede;
	-webkit-border-radius: 6px; 
	-moz-border-radius: 6px;
	padding:5px 10px 5px 10px;
	margin:4px 0 4px 0;
	display:none;
}	
a.collapsibleboxlink {
	cursor:pointer;
}

/* tag icon */	
.object_tag_string {
	background: url(<?php echo $vars['url']; ?>_graphics/icon_tag.gif) no-repeat left 2px;
	padding:0 0 0 14px;
	margin:0;
}	

/* profile picture upload n crop page */	
#profile_picture_form {
	height:145px;
}	
#current_user_avatar {
	float:left;
	width:160px;
	height:130px;
	border-right:1px solid #cccccc;
	margin:0 10px 0 0;
}	
#profile_picture_croppingtool {
	border-top: 1px solid #cccccc;
	margin:20px 0 0 0;
	padding:10px 0 0 0;
}	
#profile_picture_croppingtool #user_avatar {
	float: left;
	margin-right: 20px;
}	
#profile_picture_croppingtool #applycropping {

}
#profile_picture_croppingtool #user_avatar_preview {
	float: left;
	position: relative;
	overflow: hidden;
	width: 100px;
	height: 100px;
}	


/* ***************************************
	SETTINGS & ADMIN
*************************************** */
.admin_statistics,
.admin_users_online,
.usersettings_statistics,
.admin_adduser_link,
#add-box,
#search-box,
#logbrowser_search_area {
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	background:white;
	margin:0 10px 10px 10px;
	padding:10px;
}

.usersettings_statistics h3,
.admin_statistics h3,
.admin_users_online h3,
.user_settings h3,
.notification_methods h3 {
	background:#e4e4e4;
	color:#006699;
	font-size:1.1em;
	line-height:1em;
	margin:0 0 10px 0;
	padding:5px;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;	
	z-index: <?php echo $z_index_text; ?>;	
}
h3.settings {
	background:#e4e4e4;
	color:#006699;
	font-size:1.1em;
	line-height:1em;
	margin:10px 0 4px 0;
	padding:5px;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	z-index: <?php echo $z_index_text; ?>;	
}
.admin_users_online .profile_status {
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	background:#bbdaf7;
	line-height:1.2em;
	padding:2px 4px;
}
.admin_users_online .profile_status span {
	font-size:90%;
	color:#666666;
}
.admin_users_online  p.owner_timestamp {
	padding-left:3px;
}


.admin_debug label,
.admin_usage label {
	color:#006699;
	font-size:100%;
	font-weight:normal;
}

.admin_usage {
	border-bottom:1px solid #cccccc;
	padding:0 0 20px 0;
}
.usersettings_statistics .odd,
.admin_statistics .odd {

}
.usersettings_statistics .even,
.admin_statistics .even {

}
.usersettings_statistics td,
.admin_statistics td {
	padding:2px 4px 2px 4px;
	border-bottom:1px solid #cccccc;
}
.usersettings_statistics td.column_one,
.admin_statistics td.column_one {
	width:200px;
}
.usersettings_statistics table,
.admin_statistics table {
	width:100%;
}
.usersettings_statistics table,
.admin_statistics table {
	border-top:1px solid #cccccc;
}
.usersettings_statistics table tr:hover,
.admin_statistics table tr:hover {
	background: #E4E4E4;
}
.admin_users_online .search_listing {
	margin:0 0 5px 0;
	padding:5px;
	border:2px solid #cccccc;
	-webkit-border-radius: 5px; 
	-moz-border-radius: 5px;
}



/* force tinyMCE editor initial width for safari */
.mceLayout {
	width:<?php echo $widgets_width."px"; ?>;
}
p.longtext_editarea {
	margin:0 !important;
}
.toggle_editor_container {
	margin:0 0 15px 0;
}
/* add/remove longtext tinyMCE editor */
a.toggle_editor {
	display:block;
	float:right;
	text-align:right;
	color:<?php echo $themer_linkurl; ?>;
	font-size:1em;
	font-weight:normal;
}

div.ajax_loader {
	background: <?php echo $themer_sidebar; ?> url(<?php echo $vars['url']; ?>_graphics/ajax_loader.gif) no-repeat center 30px;
	width:auto;
	height:100px;
	margin:0 10px 0 10px;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
}



/* reusable elgg horizontal tabbed navigation 
   (used on friends collections, external pages, & riverdashboard mods)
*/
#elgg_horizontal_tabbed_nav {
	margin:0 0 2px 0;
	padding: 0;
	border-bottom: 1px solid <?php echo $theme_menutexthover; ?>;
	display:table;
	width:100%;
}
#elgg_horizontal_tabbed_nav ul {
	list-style: none;
	padding: 0;
	margin: 0;
}
#elgg_horizontal_tabbed_nav li {
	float: left;
	border: 1px solid <?php echo $theme_menutexthover; ?>;
	border-bottom-width: 0;
	background: <?php echo $theme_menuback; ?>;
	margin: 0 0 0 2px;
	-moz-border-radius-topleft:3px;
	-moz-border-radius-topright:3px;	
	-webkit-border-top-left-radius:3px;
	-webkit-border-top-right-radius:3px;
}

#elgg_horizontal_tabbed_nav a {
	text-decoration: none;
	display: block;
	padding:0px 4px 0 4px;
	color: <?php echo $theme_menutexthover; ?>;
	text-align: center;
}
/* IE6 fix */
* html #elgg_horizontal_tabbed_nav a { display: inline; }

#elgg_horizontal_tabbed_nav a:hover {
	color: <?php echo $theme_menutexthover; ?>;
	background: <?php echo $theme_menuhover; ?>;
}
#elgg_horizontal_tabbed_nav .selected {
	float: left;
	border: 1px solid <?php echo $theme_menutexthover; ?>;
	border-bottom-width: 0;
	background: transparent;
	margin: 0 0 0 2px;
	-moz-border-radius-topleft:3px;
	-moz-border-radius-topright:3px;	
	-webkit-border-top-left-radius:3px;
	-webkit-border-top-right-radius:3px;
}
#elgg_horizontal_tabbed_nav .selected a {
	background: <?php echo $themer_content; ?>;
	color: <?php echo $theme_menutexthover; ?>;
}
/* IE6 fix */
* html #elgg_horizontal_tabbed_nav .selected a { top: 2px; }


/* ***************************************
	ADMIN AREA - REPORTED CONTENT
*************************************** */
.reportedcontent_content {
	margin:0 0 5px 0;
	padding:0 7px 4px 10px;
	-webkit-border-radius: 5px; 
	-moz-border-radius: 5px;
}
.reportedcontent_content p.reportedcontent_detail,
.reportedcontent_content p {
	margin:0;
}
.active_report {
	border:1px solid #D3322A;
    background:#F7DAD8;
}
.archived_report {
	border:1px solid #666666;
    background:#dedede;
}
a.archive_report_button {
	float:right;
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #ffffff;
	background:#116699;
	border: 1px solid #116699;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	width: auto;
	padding: 4px;
	margin:15px 0 0 20px;
	cursor: pointer;
}
a.archive_report_button:hover {
	background: #0054a7;
	border: 1px solid #0054a7;
	text-decoration: none;
}
a.delete_report_button {
	float:right;
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #ffffff;
	background:#006699;
	border: 1px solid #006699;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	width: auto;
	padding: 4px;
	margin:15px 0 0 20px;
	cursor: pointer;
}
a.delete_report_button:hover {
	background: #006699;
	border: 1px solid #006699;
	text-decoration:none;
}
.reportedcontent_content .collapsible_box {
	background: white;
}

/**
Added CSS from various plugins
**/

/* The Wire */
/* reply form */
textarea#thewire_large-textarea {
	width: 96%;
	height: 80px;
	padding: 4px;
	font-family: Garamond, Georgia, serif;
	font-size: 100%;
	color:#666666;
}
/* IE 6 fix */
* html textarea#thewire_large-textarea { 
	width: 96%;
}

/* external pages plugin */

/* IE6 */
* html #front_left_tbl { width:<?php echo ($form_width)."px"; ?> !important; }
* html #front_right_tbl { width:<?php echo ($form_width)."px"; ?> !important; }


/**
	custom_index
	**/
#index_left {
    width:<?php if($mobile) echo "98%"; else echo "46%"; ?>;
    float:left;
    margin:0 0 2% 0;
    padding:0 0 10px 0px;
}
#index_right {
    width:<?php if($mobile) echo "98%"; else echo "46%"; ?>;
    float:right;
    margin:0 0 2% 0;
    padding:0 0px 10px 0;
}	
	
	
/**
	blog 
	
	**/
#blog_edit_page #two_column_left_sidebar_maincontent {
	margin:0 0px 5px 5px;
	padding:5px 5px 5px 5px;
	width:<?php if($mobile) echo "98%"; else echo "46%"; ?>;
	background: <?php echo $themer_sidebar; ?>;
	}
	
#blog_edit_page #blog_edit_sidebar {
	margin:0px 0 10px 0;
	background: <?php echo $themer_sidebar; ?>;
	padding:5px;
	-webkit-border-radius: 6px; 
	-moz-border-radius: 6px;
}

#blog_edit_page #two_column_left_sidebar_210 {
	width: <?php echo $sidebar_width."px"; ?>;
	margin:0px 0 10px 0px;
	min-height:<?php if($mobile) echo "50px"; else echo "360px"; ?>;
	float:left;
	padding:0;
}

#custom_index {
	margin:10px;
}
#index_left {
    width:<?php if($mobile) echo $width_mobile; else echo $width_desktop_left;?>;
    float:left;
    margin:0 0 2% 0;
    padding:0 0 10px 0px;
}
#index_right {
    width:<?php if($mobile) echo $width_mobile; else echo $width_desktop_right;?>;
    float:right;
    margin:0 0 2% 0;
    padding:0 0px 10px 0;
}
#index_welcome {
	padding:5px 10px 5px 10px;
	margin:0 0 10px 0;
	border:1px solid <?php echo $themer_menuback; ?>;
	background: <?php echo $themer_sidebar; ?>;
	-moz-border-radius: 8px;
	-webkit-border-radius: 8px; 
}
#index_welcome #login-box {
	margin:5px 0 10px 0;
	padding:0 0 10px 0;
	background: <?php echo $themer_sidebar; ?>;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	width:96%px;
}
#index_welcome #login-box form {
	margin:0 10px 0 10px;
	padding:0 10px 4px 10px;
	background: <?php echo $themer_sidebar; ?>;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	width:100%px;
}
#index_welcome #login-box h2,
.index_box h2 {
	color:<?php echo $themer_titlecolor; ?>;
	font-size:1.35em;
	line-height:1.2em;
	margin:0 0 0 8px;
	padding:5px;
}
#index_welcome #login-box h2 {
	padding-bottom:5px;
}

.index_box {
	margin:0 0 20px 0;
	background: <?php echo $themer_sidebar; ?>;
	padding:0 0 5px 0;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
}

.index_box .search_listing {

}
.index_box .index_members {
	float:left;
	margin:2pt 5px 3px 0pt;
}
#persistent_login {
	float:right;
	display:block;
	margin-top:-34px;
}



/* GROUPS */
#content_area_group_title h2 {
	color:<?php echo $themer_texttitle; ?>;
	font-size:1.35em;
	line-height:1.2em;
	margin:0 0 0 1%;
	padding:1%;
}
#topic_posts #content_area_group_title h2 {
	margin:0 0 0 0;
}

#two_column_left_sidebar_maincontent #owner_block_content {
	margin:1% 0 1% 0 !important;
}

#groups_info_column_left {
	float:left:
	width:<?php if($mobile) echo "98%"; else echo "46%";?>;
	margin-left:2%;
	margin-right:2%;
	color: <?php echo $themer_texttitle; ?>;
}

#groups_info_column_left .odd {
	background:<?php echo $themer_listbar; ?>;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
}
#groups_info_column_left .even {
	background:<?php echo $themer_listbar; ?>;
	-webkit-border-radius: 5px; 
	-moz-border-radius: 5px;
}
#groups_info_column_left p {
	margin:0 0 2px 0;
	padding:2px 2px;
}

#groups_info_column_right {
	float:left;
	width:<?php if ($mobile) echo "98%"; else echo "36%"; ?>;
	margin:0 2px 0 12px;
}
#groups_info_wide p {
	text-align: right;
	padding-right:1%;
}
#group_stats {
	width:190px;
	background: <?php echo $themer_listbar; ?>;
	padding:5px;
	margin:10px 0 20px 0;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
}
#group_stats p {
	margin:0;
}
#group_members {
	margin:2px;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	background: <?php echo $themer_listbar; ?>;
}

#right_column {
	clear:left;
	float:right;
	width:<?php if($mobile) echo "96%"; else echo "46%";?>;
	margin:0 2% 0 2%;
}

#left_column {
	width:<?php if($mobile) echo "96%"; else echo "46%";?>;
	float:left;
	margin:0 2% 0 2%;

}
/* IE 6 fixes */
* html #left_column { 
	margin:0 0 0 5px;
}
* html #right_column { 
	margin:0 5px 0 0;
}

#group_members h2,
#right_column h2,
#left_column h2,
#fullcolumn h2 {
	margin:0 0 10px 0;
	padding:5px;
	color:<?php echo $themer_texttitle; ?>;
	font-size:1.25em;
	line-height:1.2em;
}
#fullcolumn .contentWrapper {
	margin:0 4px 10px 4px;
	padding:0 0 4px;
}

.member_icon {
	margin:0 0 6px 6px;
	float:left;
}

/* IE6 */
* html #topic_post_tbl { width:96% !important;}

/* all browsers - force tinyMCE on edit comments to be full-width */
.edit_forum_comments .defaultSkin table.mceLayout {
	width: 96% !important;
}

/* topics overview page */
#forum_topics {
    padding:4px;
    margin:0 4px 0 4px;
    background:<?php echo $themer_canvas; ?>;
	-webkit-border-radius: 5px; 
	-moz-border-radius: 5px;    
}
/* topics individual view page */
#topic_posts {
	margin:0 4px 2px 4px;
}
#topic_posts #pages_breadcrumbs {
	margin:2px 0 0 0px;
}
#topic_posts form {
    padding:4px;
    margin:0px 0 0 0;
    background:white;
	-webkit-border-radius: 5px; 
	-moz-border-radius: 5px; 
}
.topic_post {
	padding:4px;
    margin:0 0 3px 0;
    background:<?php echo $themer_listbar; ?>;
	-webkit-border-radius: 5px; 
	-moz-border-radius: 5px;  
}
.topic_post .post_icon {
    float:left;
    margin:0 4px 4px 0;
}
.topic_post h2 {
    margin-bottom:10px;
}
.topic_post p.topic-post-menu {
	margin:0;
}
.topic_post p.topic-post-menu a.collapsibleboxlink {
	padding-left:10px;
}
.topic_post table, td {
    border:none;
}

/* group latest discussions widget */
#latest_discussion_widget {
	margin:0 0 8px 0;
	background:<?php echo $themer_sidebar; ?>;
	-webkit-border-radius: 6px; 
	-moz-border-radius: 6px;
}
/* group files widget */
#filerepo_widget_layout {
	margin:0 0 8px 0;
	padding: 0 0 5px 0;
	background:<?php echo $themer_listbar; ?>;
	-webkit-border-radius: 6px; 
	-moz-border-radius: 6px;
}
#group_pages_widget {
	margin:0 0 8px 0;
	padding: 0 0 5px 0;
	background:<?php echo $themer_listbar; ?>;
	-webkit-border-radius: 6px; 
	-moz-border-radius: 6px;
}
#group_pages_widget .search_listing {
	border: 2px solid <?php echo $themer_listbar; ?>;
}
#right_column .filerepo_widget_singleitem {
	background: <?php echo $themer_listbar; ?> !important;
	margin:0 10px 5px 10px;
}
#left_column .filerepo_widget_singleitem {
	background: <?php echo $themer_listbar; ?> !important;
	margin:0 10px 5px 10px;
}
.forum_latest {
	margin:0 10px 5px 10px;
	background: <?php echo $themer_listbar; ?>;
	padding:5px;
   	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
}
.forum_latest:hover {

}
.forum_latest .topic_owner_icon {
	float:left;
}
.forum_latest .topic_title {
	margin-left:35px;
}
.forum_latest .topic_title p {
	line-height: 1.0em;
    padding:0;
    margin:0;
    font-weight: bold;
}
.forum_latest p.topic_replies {
    padding:3px 0 0 0;
    margin:0;
    color:<?php echo $themer_caption; ?>;
}
.add_topic {
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	background:<?php echo $themer_listbar; ?>;
	margin:5px 10px;
	padding:10px 10px 10px 6px;
}

a.add_topic_button {
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: <?php echo $theme_menuhover; ?>;
	background:<?php echo $theme_menuback; ?>;
	border:none;
	-webkit-border-radius: 5px; 
	-moz-border-radius: 5px;
	width: auto;
	height: auto;
	padding: 3px 6px 3px 6px;
	margin:0;
	cursor: pointer;
}

a.add_topic_button:hover {
	background:<?php echo $theme_menuhover; ?>;
	color:<?php echo $theme_menutexthover; ?>;
	text-decoration: none;
}



/* latest discussion listing */
.latest_discussion_info {
	float:right;
	width:96%;
	text-align: right;
	margin-left: 10px;
}
.groups .search_listing br {
	height:0;
	line-height:0;
}
span.timestamp {
	color:#666666;
	font-size: 90%;
}
.latest_discussion_info .timestamp {
	font-size: 0.85em;
}
/* new groups page */
.groups .search_listing {
	border:2px solid <?php echo $themer_listbar; ?>;
	margin:0 0 5px 0;
}
.groups .search_listing:hover {
	background:<?php echo $themer_listbar; ?>;
}
.groups .group_count {
	font-weight: bold;
	color: #666666;
	margin:0 0 5px 4px;
}
.groups .search_listing_info {
	color:#666666;
}
.groupdetails {
	float:right;
}
.groupdetails p {
	margin:0;
	padding:0;
	line-height: 1.1em;
	text-align: right;
}
#groups_closed_membership {
	margin:0 10px 20px 10px;
	padding: 3px 5px 5px 5px;
	background:<?php echo $themer_listbar; ?>;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;	
}
#groups_closed_membership p {
	margin:0;
}

/* groups membership widget */
.groupmembershipwidget .contentWrapper {
	margin:0 10px 5px 10px;
}
.groupmembershipwidget .contentWrapper .groupicon {
	float:left;
	margin:0 10px 0 0;
}
.groupmembershipwidget .search_listing_info p {
	color: <?php echo $themer_textbody; ?>;
}
.groupmembershipwidget .search_listing_info span {
	font-weight: bold;
}

/* groups sidebar */
.featuredgroups .contentWrapper {
	margin:0 0 10px 0;
}
.featuredgroups .contentWrapper .groupicon {
	float:left;
	margin:0 10px 0 0;
}
.featuredgroups .contentWrapper p {
	margin: 0;
	line-height: 1.2em;
	color:#666666;
}
.featuredgroups .contentWrapper span {
	font-weight: bold;
}
#groupssearchform {
	border-bottom: 1px solid <?php echo $themer_listbar; ?>;
	margin-bottom: 10px;
}
#groupssearchform input[type="submit"] {
	padding:2px;
	height:auto;
	margin:4px 0 5px 0;
}
.sidebarBox #owner_block_submenu {
	margin:5px 0 0 0;
}

/* delete post */
.delete_discussion {
	
}
.delete_discussion a {
	display:block;
	float:right;
	cursor: pointer;
	width:14px;
	height:14px;
	margin:0;
	background: url("<?php echo $vars['url']; ?>_graphics/icon_customise_remove.png") no-repeat 0 0;
}
.delete_discussion a:hover {
	background-position: 0 -16px;
	text-decoration: none;
}
/* IE6 */
* html .delete_discussion a { font-size: 1px; }
/* IE7 */
*:first-child+html .delete_discussion a { font-size: 1px; }

/* delete group button */
#delete_group_option input[type="submit"] {
	background:#dedede;
	border-color:#dedede;
	color:#333333; 
	margin:0;
	float:right;
	clear:both;
}
#delete_group_option input[type="submit"]:hover {
	background:red;
	border-color:red;
	color:white;
}

#groupsearchform .search_input {
	width:176px;
}

.thewire-singlepage .note_body {
	
	border: 1px solid  <?php echo "white"; ?>;
		
	background: <?php
	$opacity = 60; 
	$pct = sprintf( "%0.2f", $opacity/100.00);
	$trans = "filter:alpha(opacity=$opacity); -moz-opacity: $pct; -khtml-opacity: $pct; opacity: $pct; z-index: 99999; ";	
	echo $themer_entry; ?>;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
}

<?php

	list($usec, $sec) = explode(' ', microtime());
	$script_end = (float) $sec + (float) $usec;

	$elapsed_time_middle = round($script_middle - $script_start, 5);
	$elapsed_time_end = round($script_end - $script_start, 5);
	$elapsed_time_saved = round($script_end - $script_middle, 5);
	echo "\r\n/* Elapsed Times - Middle:$elapsed_time_middle End:$elapsed_time_end\r\n Estimated Time Saved with Cache: $elapsed_time_saved */\r\n"	;
	$o->end();
	 
	
	require( $css_file );

	//end of css output section
	$file_stamp = date("Y-m-d H:i:s", filemtime($css_file));
	//set_plugin_usersetting('theme_changed_date', $file_stamp, $user_guid, 'themer');
	if( $user ) {
		$user->themer_css_stamp = $file_stamp;
	}
	return;
	
	class OB_FileWriter
{
	private $_filename;
	private $_fp = null;
	private $_errorHandlersRegistered = false;

	public function __construct($filename)
	{
		$this->setFilename($filename);
	}

	public function __destruct()
	{
		//Make sure no data is lost
		if($this->_fp)
			$this->end();
	}

	public function setFilename($filename)
	{
		$this->_filename = $filename;
	}

	public function getFilename()
	{
		return $this->_filename;
	}

	public function setHaltOnError($value)		
	{
		//If new state is same as old, don't do anything
		if($value === $this->_errorHandlersRegistered)
			return;


		if($value === true)
		{
			set_exception_handler(array($this,'exceptionHandler'));
			set_error_handler(array($this,'errorHandler'));	
			$this->_errorHandlersRegistered = true;
		}
		else
		{
			restore_error_handler();
			restore_exception_handler();
			$this->_errorHandlersRegistered = false;
		}
	}

	public function start()
	{
		$this->_fp = @fopen($this->_filename,'w');
		if(!$this->_fp)
			throw new Exception('Cannot open file '.$this->_filename.' for writing!');

		ob_start(array($this,'outputHandler'),1024);
	}

	public function end()
	{
		$this->_stopBuffering();
		$this->setHaltOnError(false);
	}

	private function _stopBuffering()
	{
		@ob_end_flush();
		if($this->_fp)
			fclose($this->_fp);

		$this->_fp = null;
	}

	public function outputHandler($buffer)
	{
		fwrite($this->_fp,$buffer);
	}

	public function exceptionHandler($exception)
	{
		$this->_stopBuffering();
		echo '<b>Fatal error: uncaught', $exception;
	}

	public function errorHandler($errno, $errstr, $errfile, $errline)
	{		
		$this->_stopBuffering();
		$errorNumber = E_USER_ERROR;
		switch($errno)
		{
		case E_ERROR:
			$errorNumber = E_USER_ERROR;
			break;
		case E_NOTICE:
			$errorNumber = E_USER_NOTICE;
			break;
		case E_WARNING:
			$errorNumber = E_USER_WARNING;
			break;
		}
		trigger_error("$errstr, File: $errfile line $errline",$errorNumber);
	}
}

function strToHex($string)
{
    $hex=0;
	$s= strtoupper(trim($string));
	$l = strlen($s);
	$f = 1;
    for ($i=$l; $i > 0; $i--)
    {
        $hex += strlen(strchr("FEDCBA9876543210",$s[$i-1])) * $f;
		$f = $f * 16;
    }
    return $hex;
}

function getBrightness($theme_brightness)
{
			switch( trim($theme_brightness) )
		{
	        case 'bright': $brightness = 0x40;
	                break;
	        case 'light': $brightness = 0x30;
	                break;
	        case 'medium': $brightness = 0x20;
	                break;
	        case 'dim': $brightness = 0x10;
	                break;
	        case 'dark': $brightness = 0x00;
	                break;
			default: $brightness = 0x00;
		}	

		return $brightness;
	
}

function setBrightness($brightness,&$r, &$g, &$b)
{
	$nr = ($brightness+$r);
	$ng = ($brightness+$g);
	$nb = ($brightness+$b);
	$maxbrightness = max(max($nr,$ng),$nb);
	if($maxbrightness>255)
		{
		$newbrightness = $maxbrightness-255;
		$r = max($nr - $newbrightness,0);
		$g = max($ng - $newbrightness,0);
		$b = max($nb - $newbrightness,0);
		}
		else
		{
		$r = $nr;
		$g = $ng;
		$b = $nb;
		}
	return;
}


function sethexcolor( $brightness,$r,$g,$b )
{
		$bright = setBrightness($brightness,$r,$g,$b);
		$hexcolor = sprintf( "#%02X%02X%02X", $r, $g, $b );
		return $hexcolor;
	
}

function gethexcolor( $color,  &$c_r, &$c_g, &$c_b )
{
        if( substr($color,0,1)=='#' && strlen(trim($color))==7 )
                {
                $c_r = strToHex(substr($color,1,2));
                $c_g = strToHex(substr($color,3,2));
                $c_b = strToHex(substr($color,5,2));
                }
	else
		{
		$c_r = 0x80;
		$c_g = 0x80;
		$c_b = 0x80;
		}
}

	
function getcolor( $color, &$c_r, &$c_g, &$c_b )
	{
	
	if( substr($color,0,1)=='#' && strlen(trim($color))==7 )
		{
		gethexcolor( $color, &$c_r, &$c_g, &$c_b );
		return;
		}
		else
		switch( $color )
		{
	
        case 'blue': 
                $c_b = 0xA1; 
                $c_r = 0x09;
                $c_g = 0x29;
                break;

		case 'turquoise': 
				$c_b = 0xD1;
                $c_r = 0x0;
                $c_g = 0xCE;
				break;
	
        case 'burgundy':
                $c_r = 0x60;
                $c_b = 0x40;
                $c_g = 0x00;
                break;

        case 'purple': // 	a020f0
                $c_r = 0xa0;
                $c_b = 0xf0;
                $c_g = 0x20;
                break;

		case 'honeydew': 
				gethexcolor('#c1cdc1', &$c_r, &$c_g, &$c_b );	
				break;
		

        case 'pink':
                $c_r = 0xFF;
                $c_b = 0xB4;
                $c_g = 0x69;
                break;
	
		case 'khaki':
			gethexcolor('#f0e68c', &$c_r, &$c_g, &$c_b );
			break;

		case 'red':  
			$c_r = 0x90;
			$c_b = 0x0;
			$c_g = 0x0;
			break;
	
		case 'green': 
                $c_r = 0x00;
                $c_b = 0x00;
				$c_g = 0x64;
			break;
	
        case 'yellow':
                $c_r = 0xA0; //0xA0;
                $c_b = 0x2c; //0x50;
                $c_g = 0x96; //0xA0;
				break;

        case 'lime': 
                $c_r = 0xA0;
                $c_b = 0x60;
                $c_g = 0xC0;
				break;

        case 'redorange': 
                $c_r = 0xff;
                $c_b = 0x00;
                $c_g = 0x66;
				break;
	
        case 'orange': 
                $c_r = 0xfa;
                $c_b = 0x00;
                $c_g = 0xa5;
				break;
	
		case 'black':
				$c_r = 0x00; $c_g = 0x00; $c_b = 0x00;
				break;
			
		case 'white':
				//$c_r = 0xff; $c_g = 0xff; $c_b = 0xff;
				gethexcolor('#FFFFFF', $c_r, $c_g, $c_b );
				break;
			
		case 'grey':
		case 'gray':
				gethexcolor('#999999', $c_r, $c_g, $c_b );
				break;
			
		default:
			$c_r = 0x80;
			$c_g = 0x80;
			$c_b = 0x80;
	
		}
	
	}

function validate_color( $value )
		{
			if( strlen($value)==3 || strlen($value)==6 ) {
				if( substr($value,1,1)!="#" )
					return "#".$value;
			}
			return $value;
		}



