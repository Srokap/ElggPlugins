<?php

	/**
	 * Egxite™ Themer for Elgg
	 * This theme allows for color preferences be set for the entire site.
	 * If the admin chooses to, it also allows each individual user to personalise their color settings.
	 * The display is reformatted when using an iPhone to view the site.
	 * 
	 * @package Egxite™ Themer
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author  Egxite™ Corp. <contact@egxite.com>
	 * @copyright Egxite™ Corp. 2009-2010
	 * @link http://egxite.com/
	 * 
	 */
		
	    $user = get_loggedin_user();
		if (get_plugin_setting('theme_allowusertheme', 'themer')!='yes') return;

	    $user = get_loggedin_user();
		if( !$user ) return; 

		$theme_user_date = get_plugin_usersetting('theme_changed_date',  $user->getGUID(), 'themer');
		$user->themer_css_changed = $theme_user_date;
		$itsnow = date("Y-m-d H:i:s");
		
		echo '<strong>'.elgg_echo("themer:theme_last_changed"). "</strong>: ".$theme_user_date."<br>";
		
		$theme_mobile = get_plugin_usersetting('theme_mobile', $user->getGUID(), 'themer');
		if( !theme_mobile ) $theme_mobile = "on";

		$theme_mobilewidth = get_plugin_usersetting('theme_mobilewidth', $user->getGUID(), 'themer');
		if( !theme_mobilewidth ) $theme_mobilewidth = "320";
		
		$theme_preference = get_plugin_usersetting('theme_preference', $user->getGUID(), 'themer');
		if( !$theme_preference ) $theme_preference = "site";
		
		$theme_color = get_plugin_usersetting('theme_color', $user->getGUID(), 'themer');
		if (!$theme_color)
			{
				//if user does not have saved settings, use the site's settings
				$theme_color = get_plugin_setting('theme_color', 'themer');
				if( !$theme_color )
					{
					//if the site settings is not yet set, these are the plugin defaults
					$theme_color = 'blue';
					$theme_brightness = 'light';
					$title_color = 'black';
					$title_brightness = 'dim';
					$text_color = 'black';
					$text_brightness = 'dim';
					$link_color = 'yellow';
					$link_brightness = 'medium';
					}
					else
						{
						$theme_brightness = get_plugin_setting('theme_brightness', 'themer');
        				$title_color = get_plugin_setting('title_color', 'themer');
        				$title_brightness = get_plugin_setting('title_brightness', 'themer');
        				$text_color = get_plugin_setting('text_color', 'themer');
        				$text_brightness = get_plugin_setting('text_brightness', 'themer');
        				$link_color = get_plugin_setting('link_color', 'themer');
        				$link_brightness = get_plugin_setting('link_brightness', 'themer');
						
						}
			} 
			else
			{
				$theme_brightness = get_plugin_usersetting('theme_brightness', $user->getGUID(), 'themer');
        		$title_color = get_plugin_usersetting('title_color', $user->getGUID(), 'themer');
        		$title_brightness = get_plugin_usersetting('title_brightness', $user->getGUID(), 'themer');
        		$text_color = get_plugin_usersetting('text_color', $user->getGUID(), 'themer');
        		$text_brightness = get_plugin_usersetting('text_brightness', $user->getGUID(), 'themer');
        		$link_color = get_plugin_usersetting('link_color', $user->getGUID(), 'themer');
        		$link_brightness = get_plugin_usersetting('link_brightness', $user->getGUID(), 'themer');

			}

		
?>
<p>
	<h2></h2><?php echo elgg_echo('themer:usersetting'); ?></h2>
	<br>
	<table>
		
		<tr><td align="right">
		<?php echo elgg_echo('themer:current_time'); ?>
		</td><td>
		<?php
				echo elgg_view('input/pulldown', array(
					'internalname' => 'params[theme_changed_date]',
					'options_values' => array(
					$itsnow => $itsnow,
					),
					));
		?>
		</td></tr>
		
		
		<tr><td align="right">
		<?php echo elgg_echo('themer:mobile'); ?>
		</td><td>
	<?php
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[theme_mobile]',
			'options_values' => array(
				'off' => elgg_echo('themer:off'),
				'iphone' => elgg_echo('themer:iphone'),
				'blackberry' => elgg_echo('themer:blackberry'),
				'samsung' => elgg_echo('themer:samsung'),
				'nokia' => elgg_echo('themer:nokia'),
				'lg' => elgg_echo('themer:lg'),
				'motorola' => elgg_echo('themer:motorola'),
				'on' => elgg_echo('themer:on'),
			),
			'value' => $theme_mobile
		));
		
		?>
		</td></tr>
		
		<tr><td align="right">
		<?php echo elgg_echo('themer:mobilewidth'); ?>
		</td><td>
			
			<?php 
			
			//echo elgg_view('input/text', array('internalname' => 'params[theme_mobilewidth]', 'value' => $theme_mobilewidth));

		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[theme_mobilewidth]',
			'options_values' => array(
				'no' => elgg_echo('themer:no'),
				'240' => '240',
				'320' => '320',
				'480' => '480',
				'720' => '720',
			),
			'value' => $theme_mobilewidth
		));
		
		?>
		
			<tr><td align="right">
		<?php echo elgg_echo('themer:preference'); ?>
		</td><td>
			
			<?php 
			
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[theme_preference]',
			'options_values' => array(
				'site' => elgg_echo('themer:sitepreferred'),
				'personal' => elgg_echo('themer:personalpreferred'),
			),
			'value' => $theme_preference
		));
		
		?>
		
		
		<tr><td align="right">

	<?php echo elgg_echo('themer:theme'); ?>
	</td><td>
	<?php
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[theme_brightness]',
			'options_values' => array(
				'bright' => elgg_echo('themer:bright'),
				'light' => elgg_echo('themer:light'),
				'medium' => elgg_echo('themer:medium'),
				'dim' => elgg_echo('themer:dim'),
				'dark' => elgg_echo('themer:dark'),
			),
			'value' => $theme_brightness
		));
		
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[theme_color]',
			'options_values' => array(
				'white' => elgg_echo('themer:white'),
				'blue' => elgg_echo('themer:blue'),
				'turquoise' => elgg_echo('themer:turquoise'),
				'green' => elgg_echo('themer:green'),
				'lime' => elgg_echo('themer:lime'),
				'orange' => elgg_echo('themer:orange'),
				'yellow' => elgg_echo('themer:yellow'),
				'purple' => elgg_echo('themer:purple'),
				'red' => elgg_echo('themer:red'),
				'pink' => elgg_echo('themer:pink'),
				'burgundy' => elgg_echo('themer:burgundy'),
				'black' => elgg_echo('themer:black'),
			),
			'value' => $theme_color
		));
		?>
		</td></tr>
		
		
		<tr><td align="right">
		<?php echo elgg_echo('themer:title'); ?>
		</td><td>
		<?php
		
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[title_brightness]',
			'options_values' => array(
				'bright' => elgg_echo('themer:bright'),
				'light' => elgg_echo('themer:light'),
				'medium' => elgg_echo('themer:medium'),
				'dim' => elgg_echo('themer:dim'),
				'dark' => elgg_echo('themer:dark'),
			),
			'value' => $title_brightness
		));

		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[title_color]',
			'options_values' => array(
				'white' => elgg_echo('themer:white'),
				'blue' => elgg_echo('themer:blue'),
				'turquoise' => elgg_echo('themer:turquoise'),
				'green' => elgg_echo('themer:green'),
				'lime' => elgg_echo('themer:lime'),
				'orange' => elgg_echo('themer:orange'),
				'yellow' => elgg_echo('themer:yellow'),
				'purple' => elgg_echo('themer:purple'),
				'red' => elgg_echo('themer:red'),
				'pink' => elgg_echo('themer:pink'),
				'burgundy' => elgg_echo('themer:burgundy'),
				'black' => elgg_echo('themer:black'),
			),
			'value' => $title_color
		));

		?>
		</td></tr>
		
		<tr><td align="right">
		<?php echo elgg_echo('themer:text'); ?>
		</td><td>
		<?php
		
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[text_brightness]',
			'options_values' => array(
				'bright' => elgg_echo('themer:bright'),
				'light' => elgg_echo('themer:light'),
				'medium' => elgg_echo('themer:medium'),
				'dim' => elgg_echo('themer:dim'),
				'dark' => elgg_echo('themer:dark'),
			),
			'value' => $text_brightness
		));

		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[text_color]',
			'options_values' => array(
				'white' => elgg_echo('themer:white'),
				'blue' => elgg_echo('themer:blue'),
				'turquoise' => elgg_echo('themer:turquoise'),
				'green' => elgg_echo('themer:green'),
				'lime' => elgg_echo('themer:lime'),
				'orange' => elgg_echo('themer:orange'),
				'yellow' => elgg_echo('themer:yellow'),
				'purple' => elgg_echo('themer:purple'),
				'red' => elgg_echo('themer:red'),
				'pink' => elgg_echo('themer:pink'),
				'burgundy' => elgg_echo('themer:burgundy'),
				'black' => elgg_echo('themer:black'),
			),
			'value' => $text_color
		));

		?>
		</td></tr>

		<tr><td align="right">
		<?php echo elgg_echo('themer:linkcolor'); ?>
		</td><td>
		<?php
		
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[link_brightness]',
			'options_values' => array(
				'bright' => elgg_echo('themer:bright'),
				'light' => elgg_echo('themer:light'),
				'medium' => elgg_echo('themer:medium'),
				'dim' => elgg_echo('themer:dim'),
				'dark' => elgg_echo('themer:dark'),
			),
			'value' => $link_brightness
		));

		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[link_color]',
			'options_values' => array(
				'white' => elgg_echo('themer:white'),
				'blue' => elgg_echo('themer:blue'),
				'turquoise' => elgg_echo('themer:turquoise'),
				'green' => elgg_echo('themer:green'),
				'lime' => elgg_echo('themer:lime'),
				'orange' => elgg_echo('themer:orange'),
				'yellow' => elgg_echo('themer:yellow'),
				'purple' => elgg_echo('themer:purple'),
				'red' => elgg_echo('themer:red'),
				'pink' => elgg_echo('themer:pink'),
				'burgundy' => elgg_echo('themer:burgundy'),
				'black' => elgg_echo('themer:black'),
			),
			'value' => $link_color
		));

		?>
		</td></tr></table>
</p>
