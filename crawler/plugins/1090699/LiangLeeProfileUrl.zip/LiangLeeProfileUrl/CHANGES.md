LiangLeeProfileUrl 1.0.7
(September 08, 2012 from https://github.com/lianglee/LiangLeeProfileUrl/1.0.7)

BugFixs:

* Don't let backup if backup is done ticket #15.

* Minor bugs fixes.

 Enhancements:

* Undo Changes ( by My Wife ) ticket #16.

* Improved Ui ( by John Muller ) ticket #17
