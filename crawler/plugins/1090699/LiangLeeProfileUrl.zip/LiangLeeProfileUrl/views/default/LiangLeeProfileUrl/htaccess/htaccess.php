# Elgg htaccess directives
# Copyright Curverider Ltd 2008-2009
# License http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
# Link http://elgg.org/

<Files "htaccess_dist">
	order allow,deny
	deny from all
</Files>

# Don't listing directory
Options -Indexes

# Follow symbolic links
Options +FollowSymLinks

# Default handler
DirectoryIndex index.php

# Turn on expiry
<IfModule mod_expires.c>
	ExpiresActive On
	ExpiresDefault "access plus 10 years"
</IfModule>

# php 5, apache 1 and 2
<IfModule mod_php5.c>
	# limit the maximum memory consumed by the php script to 64 MB
	php_value memory_limit 64M
	# register_globals is deprecated as of PHP 5.3.0 - disable it for security reasons.
	php_value register_globals 0
	# post_max_size is the maximum size of ALL the data that is POST'ed to php at a time (8 MB)
	php_value post_max_size 8388608
	# upload_max_filesize is the maximum size of a single uploaded file (5 MB)
	php_value upload_max_filesize 5242880
	# on development servers, set to 1 to display errors. Set to 0 on production servers.
	php_value display_errors 0
</IfModule>

# Turn on mod_gzip if available
<IfModule mod_gzip.c>
	mod_gzip_on yes
	mod_gzip_dechunk yes
	mod_gzip_keep_workfiles No
	mod_gzip_minimum_file_size 1000
	mod_gzip_maximum_file_size 1000000
	mod_gzip_maximum_inmem_size 1000000
	mod_gzip_item_include mime ^text/.*
	mod_gzip_item_include mime ^application/javascript$
	mod_gzip_item_include mime ^application/x-javascript$
	# Exclude old browsers and images since IE has trouble with this
	mod_gzip_item_exclude reqheader "User-Agent: .*Mozilla/4\..*\["
	mod_gzip_item_exclude mime ^image/.*
</IfModule>

## Apache2 deflate support if available
##
## Important note: mod_headers is required for correct functioning across proxies.
##
<IfModule mod_deflate.c>
	AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css text/javascript application/javascript application/x-javascript
	BrowserMatch ^Mozilla/4 gzip-only-text/html
	BrowserMatch ^Mozilla/4\.[0678] no-gzip
	BrowserMatch \bMSIE !no-gzip

<IfModule mod_headers.c>
	Header append Vary User-Agent env=!dont-vary
</IfModule>

	# The following is to disable compression for actions. The reason being is that these
	# may offer direct downloads which (since the initial request comes in as text/html and headers
	# get changed in the script) get double compressed and become unusable when downloaded by IE.
	SetEnvIfNoCase Request_URI action\/* no-gzip dont-vary
	SetEnvIfNoCase Request_URI actions\/* no-gzip dont-vary

</IfModule>

# Configure ETags
<FilesMatch "\.(jpg|jpeg|gif|png|mp3|flv|mov|avi|3pg|html|htm|swf|js|ico)$">
	FileETag MTime Size
</FilesMatch>

#  Add Proper MIME-Type for Favicon to allow expires to work
AddType image/vnd.microsoft.icon .ico

<IfModule mod_rewrite.c>

RewriteEngine on

# If Elgg is in a subdirectory on your site, you might need to add a RewriteBase line
# containing the path from your site root to elgg's root. e.g. If your site is
# http://example.com/ and Elgg is in http://example.com/sites/elgg/, you might need
#
#RewriteBase /sites/elgg/
#
# here, only without the # in front.
#
# If you're not running Elgg in a subdirectory on your site, but still getting lots
# of 404 errors beyond the front page, you could instead try:
#
#RewriteBase /

# In for backwards compatibility
RewriteRule ^pg\/([A-Za-z0-9\_\-]+)$ engine/handlers/page_handler.php?handler=$1&%{QUERY_STRING}
RewriteRule ^pg\/([A-Za-z0-9\_\-]+)\/(.*)$ engine/handlers/page_handler.php?handler=$1&page=$2&%{QUERY_STRING}
RewriteRule ^tag\/(.+)\/?$ engine/handlers/page_handler.php?handler=search&page=$1

#Support profile url like facebook

RewriteRule ^([a-zA-Z0-9_-]+)$ profile/$1


RewriteRule ^action\/([A-Za-z0-9\_\-\/]+)$ engine/handlers/action_handler.php?action=$1&%{QUERY_STRING}

RewriteRule ^cache\/(.*)$ engine/handlers/cache_handler.php?request=$1&%{QUERY_STRING}

RewriteRule ^services\/api\/([A-Za-z0-9\_\-]+)\/(.*)$ engine/handlers/service_handler.php?handler=$1&request=$2&%{QUERY_STRING}

RewriteRule ^export\/([A-Za-z]+)\/([0-9]+)\/?$ engine/handlers/export_handler.php?view=$1&guid=$2
RewriteRule ^export\/([A-Za-z]+)\/([0-9]+)\/([A-Za-z]+)\/([A-Za-z0-9\_]+)\/$ engine/handlers/export_handler.php?view=$1&guid=$2&type=$3&idname=$4

RewriteRule xml-rpc.php engine/handlers/xml-rpc_handler.php
RewriteRule mt/mt-xmlrpc.cgi engine/handlers/xml-rpc_handler.php


# rule for rewrite module test during install - can be removed after installation
RewriteRule ^rewrite.php$ install.php

# Everything else that isn't a file gets routed through the page handler
RewriteCond %{REQUEST_FILENAME} !-d
RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^([A-Za-z0-9\_\-]+)$ engine/handlers/page_handler.php?handler=$1 [QSA]

RewriteCond %{REQUEST_FILENAME} !-d
RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^([A-Za-z0-9\_\-]+)\/(.*)$ engine/handlers/page_handler.php?handler=$1&page=$2 [QSA]


</IfModule>
