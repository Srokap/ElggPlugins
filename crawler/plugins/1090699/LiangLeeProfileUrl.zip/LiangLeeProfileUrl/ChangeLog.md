LiangLeeProfileUrl 1.0.6
(August 26, 2012 from https://github.com/lianglee/LiangLeeProfileUrl/1.0.6)

BugFixs:

* Fixed invite url link.

* Minor bugs fixes.

 Enhancements:

* Redirect User to Specific Page after Login.

* Updated ChangeLog.md

* Updated Version.php

* Updated Manifest.xml


LiangLeeProfileUrl 1.0.5
(August 26, 2012 from https://github.com/lianglee/LiangLeeProfileUrl/1.0.5)

BugFixs:

* Added elgg_register_entity_url_handler() to avoid core editing ( Thanks to Matt Beckett )

* Updated Readme.md

* Deleted configure folder 

 Enhancements:

* Added Matt Beckett as a contributors for helping us to find errors.

* Added settings page Preview.

LiangLeeProfileUrl 1.0.4
(August 26, 2012 from https://github.com/lianglee/LiangLeeProfileUrl/1.0.4)

* Fix Forgot password link in forms.

* Fix Register link in forms.

* Fix Search Module.

* Fix Common Bugs that cause automatic register menu item if plugin is disable.

* Fix a links of expages to avoid errors.

* Fix members link to avoid errors.

 Enhancements:

* Added kisssssss4ever as a contributors for helping us to find errors.

* Added settings page Preview.




LiangLeeProfileUrl 1.0.3
(August 26, 2012 from https://github.com/lianglee/LiangLeeProfileUrl/)

Bugfixs:

# Fix Minors issue



LiangLeeProfileUrl 1.0.2
(August 26, 2012 from https://github.com/lianglee/LiangLeeProfileUrl/1.0.3)

* Updated Readme.md
* Added Better Support for configuring profile url.
* Fix Error in Settings
* Updateed ChangeLog.md
* Removed htaccess.txt
* Added Missing Languages
* Backup Support



LiangLeeProfileUrl 1.0.1
(August 24, 2012 from https://github.com/lianglee/LiangLeeProfileUrl)

* Fixed Some of Redirected Loop Errors ( fixed by John Muller )
* Added Readme.md
* Fix Redirected Loop error when browse website.com/admin fixed by adding website.com/admin/

LiangLee ProfileUrl 1.0.0 -> initial release
