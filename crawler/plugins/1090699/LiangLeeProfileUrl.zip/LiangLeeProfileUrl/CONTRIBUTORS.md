Unless otherwise stated within individual files of this package:

John Muller - https://github.com/JohnMuller

Kisssssss4ever - http://community.elgg.org/profile/kisssssss

Matt Beckett - http://community.elgg.org/profile/Beck24