<?php

elgg_register_event_handler('init', 'system', 'phloor_lyrics_init');

function phloor_lyrics_init() {
	elgg_register_library('phloor-lyrics', elgg_get_plugins_path() . 'phloor_lyrics/lib/phloor_lyrics.lib.php');

	$item = new ElggMenuItem('phloor_lyrics', elgg_echo('phloor_lyrics:phloor_lyricss'), 'phloor_lyrics/all');
	elgg_register_menu_item('site', $item);

	/**
	 * CSS
	 */
	elgg_extend_view('css/elgg', 'phloor_lyrics/css');

	/**
	 * JavaScript
	 */
	$phloor_lyrics_js = elgg_get_simplecache_url('js', 'phloor_lyrics/save_draft');
	elgg_register_simplecache_view('js/phloor_lyrics/save_draft');
	elgg_register_js('elgg.phloor_lyrics', $phloor_lyrics_js);

	/**
	 * Page handler
	 */
	elgg_register_page_handler('phloor_lyrics', 'phloor_lyrics_page_handler');

	/**
	 * Url handler
	 */
	elgg_register_entity_url_handler('object', 'phloor_lyrics', 'phloor_lyrics_url_handler');


	/**
	 * Search
	 */
	elgg_register_entity_type('object', 'phloor_lyrics');

	/**
	 * Group option
	 */
	add_group_tool_option('phloor_lyrics', elgg_echo('phloor_lyrics:enablephloor_lyrics'), true);
	elgg_extend_view('groups/tool_latest', 'phloor_lyrics/group_module');

	/**
	 * Widgets
	 */
	elgg_register_widget_type('phloor_lyrics', elgg_echo('phloor_lyrics'), elgg_echo('phloor_lyrics:widget:description'), 'profile');

	/**
	 * Actions
	 */
	$action_path = elgg_get_plugins_path() . 'phloor_lyrics/actions/phloor_lyrics';
	elgg_register_action('phloor_lyrics/save', "$action_path/save.php");
	elgg_register_action('phloor_lyrics/auto_save_revision', "$action_path/auto_save_revision.php");
	elgg_register_action('phloor_lyrics/delete', "$action_path/delete.php");

	/**
	 * Plugin Hooks
	 */
	elgg_register_plugin_hook_handler('register', 'menu:entity', 'phloor_lyrics_entity_menu_setup');
	elgg_register_plugin_hook_handler('register', 'menu:owner_block', 'phloor_lyrics_owner_block_menu');

}

/**
 * Dispatches phloor_lyrics pages.
 * URLs take the form of
 *  All phloor_lyricss:       phloor_lyrics/all
 *  User's phloor_lyricss:    phloor_lyrics/owner/<username>
 *  Friends' phloor_lyrics:   phloor_lyrics/friends/<username>
 *  User's archives: phloor_lyrics/archives/<username>/<time_start>/<time_stop>
 *  View:            phloor_lyrics/view/<guid>/<title>
 *  Add:             phloor_lyrics/add/<guid>
 *  Edit:            phloor_lyrics/edit/<guid>/<revision>
 *  Preview:         phloor_lyrics/preview/<guid>
 *  Group lyrics:    phloor_lyrics/group/<guid>/all
 *
 * Title is ignored
 *
 *
 * @param array $page
 * @return bool
 */
function phloor_lyrics_page_handler($page) {

	elgg_load_library('phloor-lyrics');

	// @todo remove the forwarder in 1.9
	// forward to correct URL for phloor_lyrics pages pre-1.7.5
	phloor_lyrics_url_forwarder($page);

	// push all phloor_lyricss breadcrumb
	elgg_push_breadcrumb(elgg_echo('phloor_lyrics:phloor_lyricss'), "phloor_lyrics/all");

	if (!isset($page[0])) {
		$page[0] = 'all';
	}

	$page_type = $page[0];
	switch ($page_type) {
		case 'owner':
			$user = get_user_by_username($page[1]);
			$params = phloor_lyrics_get_page_content_list($user->guid);
			break;
		case 'friends':
			$user = get_user_by_username($page[1]);
			$params = phloor_lyrics_get_page_content_friends($user->guid);
			break;
		case 'view':
			$params = phloor_lyrics_get_page_content_read($page[1]);
			break;
		case 'add':
			gatekeeper();
			$params = phloor_lyrics_get_page_content_edit($page_type, $page[1]);
			break;
		case 'edit':
			gatekeeper();
			$params = phloor_lyrics_get_page_content_edit($page_type, $page[1], $page[2]);
			break;
		case 'group':
			$params = phloor_lyrics_get_page_content_list($page[1]);
			break;
		case 'all':
			$params = phloor_lyrics_get_page_content_list();
			break;
		default:
			return false;
	}

	if (isset($params['sidebar'])) {
		$params['sidebar'] .= elgg_view('phloor_lyrics/sidebar', array('page' => $page_type));
	} else {
		$params['sidebar'] = elgg_view('phloor_lyrics/sidebar', array('page' => $page_type));
	}

	$body = elgg_view_layout('content', $params);

	echo elgg_view_page($params['title'], $body);
	return true;
}

/**
 * Format and return the URL for phloor_lyricss.
 *
 * @param ElggObject $entity Blog object
 * @return string URL of phloor_lyrics.
 */
function phloor_lyrics_url_handler($entity) {
	if (!$entity->getOwnerEntity()) {
		// default to a standard view if no owner.
		return FALSE;
	}

	$friendly_title = elgg_get_friendly_title($entity->title);

	return "phloor_lyrics/view/{$entity->guid}/$friendly_title";
}

/**
 * Add a menu item to an ownerblock
 */
function phloor_lyrics_owner_block_menu($hook, $type, $return, $params) {
	if (elgg_instanceof($params['entity'], 'user')) {
		$url = "phloor_lyrics/owner/{$params['entity']->username}";
		$item = new ElggMenuItem('phloor_lyrics', elgg_echo('phloor_lyrics'), $url);
		$return[] = $item;
	} else {
		if ($params['entity']->phloor_lyrics_enable != "no") {
			$url = "phloor_lyrics/group/{$params['entity']->guid}/all";
			$item = new ElggMenuItem('phloor_lyrics', elgg_echo('phloor_lyrics:group'), $url);
			$return[] = $item;
		}
	}

	return $return;
}

/**
 * Add particular phloor_lyrics links/info to entity menu
 */
function phloor_lyrics_entity_menu_setup($hook, $type, $return, $params) {
	if (elgg_in_context('widgets')) {
		return $return;
	}

	$entity = $params['entity'];
	$handler = elgg_extract('handler', $params, false);
	if ($handler != 'phloor_lyrics') {
		return $return;
	}

	if ($entity->canEdit() && $entity->status != 'published') {
		$status_text = elgg_echo("phloor_lyrics:status:{$entity->status}");
		$options = array(
			'name' => 'published_status',
			'text' => "<span>$status_text</span>",
			'href' => false,
			'priority' => 150,
		);
		$return[] = ElggMenuItem::factory($options);
	}

	return $return;
}
