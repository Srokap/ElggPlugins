<?php
/**
 * Save phloor_lyrics entity
 *
 */

// start a new sticky form session in case of failure
elgg_make_sticky_form('phloor_lyrics');

// save or preview
$save = (bool)get_input('save');

// store errors to pass along
$error = FALSE;
$error_forward_url = REFERER;
$user = elgg_get_logged_in_user_entity();

// edit or create a new entity
$guid = get_input('guid');

if ($guid) {
	$entity = get_entity($guid);
	if (elgg_instanceof($entity, 'object', 'phloor_lyrics') && $entity->canEdit()) {
		$phloor_lyrics = $entity;
	} else {
		register_error(elgg_echo('phloor_lyrics:error:post_not_found'));
		forward(get_input('forward', REFERER));
	}

	// save some data for revisions once we save the new edit
	$revision_text = $phloor_lyrics->description;
	$new_post = $phloor_lyrics->new_post;
} else {
	$phloor_lyrics = new PhloorLyrics();
	$phloor_lyrics->subtype = 'phloor_lyrics';
	$new_post = TRUE;
}

// set the previous status for the hooks to update the time_created and river entries
$old_status = $phloor_lyrics->status;

$container_guid = (int)get_input('container_guid');
// set defaults and required values.
$values = array(
	'title' => '',
	'briefdescription' => '',
	'description' => '',
	'bandname' => '',
	'albumname' => '',
	'status' => 'draft',
	'access_id' => ACCESS_DEFAULT,
	'comments_on' => 'On',
	'tags' => '',
	'container_guid' => $container_guid,
);

// fail if a required entity isn't set
$required = array('title', 'description');

// load from POST and do sanity and access checking
foreach ($values as $name => $default) {
	$value = get_input($name, $default);

	if (in_array($name, $required) && empty($value)) {
		$error = elgg_echo("phloor_lyrics:error:missing:$name");
	}

	if ($error) {
		break;
	}

	switch ($name) {
		case 'tags':
			if ($value) {
				$values[$name] = string_to_tag_array($value);
			} else {
				unset ($values[$name]);
			}
			break;

		case 'briefdescription':
			if ($value) {
				$value = elgg_get_excerpt($value);
			} else {
				$value = elgg_get_excerpt($values['description']);
			}
			$values[$name] = $value;
			break;

		case 'container_guid':
			// this can't be empty or saving the base entity fails
			if (!empty($value)) {
				if (can_write_to_container($user->getGUID(), $value)) {
					$values[$name] = $value;
				} else {
					$error = elgg_echo("phloor_lyrics:error:cannot_write_to_container");
				}
			} else {
				unset($values[$name]);
			}
			break;

		// don't try to set the guid
		case 'guid':
			unset($values['guid']);
			break;

		default:
			$values[$name] = $value;
			break;
	}
}


$container_entity = get_entity($container_guid);
if(empty($values['bandname'])) {
    $values['bandname'] = $container_entity->name;
}

// if preview, force status to be draft
if ($save == false) {
	$values['status'] = 'draft';
}

// assign values to the entity, stopping on error.
if (!$error) {
	foreach ($values as $name => $value) {
		if (FALSE === ($phloor_lyrics->$name = $value)) {
			$error = elgg_echo('phloor_lyrics:error:cannot_save' . "$name=$value");
			break;
		}
	}
}

// only try to save base entity if no errors
if (!$error) {
	if ($phloor_lyrics->save()) {
		// remove sticky form entries
		elgg_clear_sticky_form('phloor_lyrics');

		// remove autosave draft if exists
		$phloor_lyrics->clearAnnotations('phloor_lyrics_auto_save');

		// no longer a brand new post.
		$phloor_lyrics->clearMetadata('new_post');

		// if this was an edit, create a revision annotation
		if (!$new_post && $revision_text) {
			$phloor_lyrics->annotate('phloor_lyrics_revision', $revision_text);
		}

		system_message(elgg_echo('phloor_lyrics:message:saved'));

		$status = $phloor_lyrics->status;
		$db_prefix = elgg_get_config('dbprefix');

		// add to river if changing status or published, regardless of new post
		// because we remove it for drafts.
		if (($new_post || $old_status == 'draft') && $status == 'published') {
			add_to_river('river/object/phloor_lyrics/create', 'create', elgg_get_logged_in_user_guid(), $phloor_lyrics->getGUID());

			if ($guid) {
				$phloor_lyrics->time_created = time();
				$phloor_lyrics->save();
			}
		} elseif ($old_status == 'published' && $status == 'draft') {
			elgg_delete_river(array(
				'object_guid' => $phloor_lyrics->guid,
				'action_type' => 'create',
			));
		}

		if ($phloor_lyrics->status == 'published' || $save == false) {
			forward($phloor_lyrics->getURL());
		} else {
			forward("phloor_lyrics/edit/$phloor_lyrics->guid");
		}
	} else {
		register_error(elgg_echo('phloor_lyrics:error:cannot_save'));
		forward($error_forward_url);
	}
} else {
	register_error($error);
	forward($error_forward_url);
}