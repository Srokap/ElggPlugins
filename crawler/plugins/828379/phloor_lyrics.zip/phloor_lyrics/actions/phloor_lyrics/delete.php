<?php
/**
 * Delete phloor_lyrics entity
 *
 */

$phloor_lyrics_guid = get_input('guid');
$phloor_lyrics = get_entity($phloor_lyrics_guid);

if (elgg_instanceof($phloor_lyrics, 'object', 'phloor_lyrics') && $phloor_lyrics->canEdit()) {
	$container = get_entity($phloor_lyrics->container_guid);
	if ($phloor_lyrics->delete()) {
		system_message(elgg_echo('phloor_lyrics:message:deleted_post'));
		if (elgg_instanceof($container, 'group')) {
			forward("phloor_lyrics/group/$container->guid/all");
		} else {
			forward("phloor_lyrics/owner/$container->username");
		}
	} else {
		register_error(elgg_echo('phloor_lyrics:error:cannot_delete_post'));
	}
} else {
	register_error(elgg_echo('phloor_lyrics:error:post_not_found'));
}

forward(REFERER);