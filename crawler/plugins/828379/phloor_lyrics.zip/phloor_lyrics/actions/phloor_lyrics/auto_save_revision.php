<?php
/**
 * Action called by AJAX periodic auto saving when editing.
 *
 */

$guid = get_input('guid');
$user = elgg_get_logged_in_user_entity();
$title = get_input('title');
$description = get_input('description');
$briefdescription = get_input('briefdescription');

// because get_input() doesn't use the default if the input is ''
if (empty($briefdescription)) {
	$briefdescription = $description;
}

// store errors to pass along
$error = FALSE;

if ($title && $description) {

	if ($guid) {
		$entity = get_entity($guid);
		if (elgg_instanceof($entity, 'object', 'phloor_lyrics') && $entity->canEdit()) {
			$phloor_lyrics = $entity;
		} else {
			$error = elgg_echo('phloor_lyrics:error:post_not_found');
		}
	} else {
		$phloor_lyrics = new PhloorLyrics();
		$phloor_lyrics->subtype = 'phloor_lyrics';

		// force draft and private for autosaves.
		$phloor_lyrics->status = 'unsaved_draft';
		$phloor_lyrics->access_id = ACCESS_PRIVATE;
		$phloor_lyrics->title = $title;
		$phloor_lyrics->description = $description;
		$phloor_lyrics->briefdescription = elgg_get_excerpt($briefdescription);

		// mark this as a brand new post so we can work out the
		// river / revision logic in the real save action.
		$phloor_lyrics->new_post = TRUE;

		if (!$phloor_lyrics->save()) {
			$error = elgg_echo('phloor_lyrics:error:cannot_save');
		}
	}

	// creat draft annotation
	if (!$error) {
		// annotations don't have a "time_updated" so
		// we have to delete everything or the times are wrong.

		// don't save if nothing changed
		if ($auto_save_annotations = $phloor_lyrics->getAnnotations('phloor_lyrics_auto_save', 1)) {
			$auto_save = $auto_save_annotations[0];
		} else {
			$auto_save == FALSE;
		}

		if (!$auto_save) {
			$annotation_id = $phloor_lyrics->annotate('phloor_lyrics_auto_save', $description);
		} elseif ($auto_save instanceof ElggAnnotation && $auto_save->value != $description) {
			$phloor_lyrics->clearAnnotations('phloor_lyrics_auto_save');
			$annotation_id = $phloor_lyrics->annotate('phloor_lyrics_auto_save', $description);
		} elseif ($auto_save instanceof ElggAnnotation && $auto_save->value == $description) {
			// this isn't an error because we have an up to date annotation.
			$annotation_id = $auto_save->id;
		}

		if (!$annotation_id) {
			$error = elgg_echo('phloor_lyrics:error:cannot_auto_save');
		}
	}
} else {
	$error = elgg_echo('phloor_lyrics:error:missing:description');
}

if ($error) {
	$json = array('success' => FALSE, 'message' => $error);
	echo json_encode($json);
} else {
	$msg = elgg_echo('phloor_lyrics:message:saved');
	$json = array('success' => TRUE, 'message' => $msg, 'guid' => $phloor_lyrics->getGUID());
	echo json_encode($json);
}
exit;
