<?php
/**
 * Deregister the PhloorLyrics class
 */

update_subtype('object', 'phloor_lyrics');
