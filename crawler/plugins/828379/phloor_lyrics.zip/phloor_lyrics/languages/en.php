<?php

$english = array(
	'phloor_lyrics' => 'Lyrics',
	'phloor_lyrics:phloor_lyricss' => 'Lyrics',
	'phloor_lyrics:revisions' => 'Revisions',
	'phloor_lyrics:phloor_lyrics' => 'Lyrics',
	'item:object:phloor_lyrics' => 'Lyrics',

	'phloor_lyrics:title:user_phloor_lyricss' => '%s\'s lyrics',
	'phloor_lyrics:title:all_phloor_lyricss' => 'All site lyrics',
	'phloor_lyrics:title:friends' => 'Friends\' lyrics',

	'phloor_lyrics:group' => 'Group lyrics',
	'phloor_lyrics:phloor_band' => 'Band lyrics',
	'phloor_lyrics:enablephloor_lyrics' => 'Enable group lyrics',
	'phloor_lyrics:write' => 'Write lyrics',

	// Editing
	'phloor_lyrics:add' => 'Add lyrics',
	'phloor_lyrics:edit' => 'Edit lyrics',
	'phloor_lyrics:briefdescription' => 'Brief description',
	'phloor_lyrics:description' => 'Text',
	'phloor_lyrics:bandname' => 'Band/artist name',
	'phloor_lyrics:bandname:description' => 'Enter the name of the artist or band (if you leave this blank, your username or bandname is used). ',
	'phloor_lyrics:albumname' => 'Album/compilation title',
	'phloor_lyrics:save_status' => 'Last saved: ',
	'phloor_lyrics:never' => 'Never',

	// Statuses
	'phloor_lyrics:status' => 'Status',
	'phloor_lyrics:status:draft' => 'Draft',
	'phloor_lyrics:status:published' => 'Published',
	'phloor_lyrics:status:unsaved_draft' => 'Unsaved Draft',

	'phloor_lyrics:revision' => 'Revision',
	'phloor_lyrics:auto_saved_revision' => 'Auto Saved Revision',

	// messages
	'phloor_lyrics:message:saved' => 'Lyrics saved.',
	'phloor_lyrics:error:cannot_save' => 'Cannot save lyrics.',
	'phloor_lyrics:error:cannot_write_to_container' => 'Insufficient access to save lyrics to container.',
	'phloor_lyrics:error:post_not_found' => 'Lyrics has been removed, is invalid, or you do not have permission to view it.',
	'phloor_lyrics:messages:warning:draft' => 'There is an unsaved draft of this lyrics!',
	'phloor_lyrics:edit_revision_notice' => '(Old version)',
	'phloor_lyrics:message:deleted_post' => 'Lyrics deleted.',
	'phloor_lyrics:error:cannot_delete_post' => 'Cannot delete lyrics.',
	'phloor_lyrics:none' => 'No lyrics.',
	'phloor_lyrics:error:missing:title' => 'Please enter a title!',
	'phloor_lyrics:error:missing:description' => 'Please enter the body of your lyrics!',
	'phloor_lyrics:error:cannot_edit_post' => 'Lyrics may not exist or you may not have permissions to edit it.',
	'phloor_lyrics:error:revision_not_found' => 'Cannot find this revision.',

	// river
	'river:create:object:phloor_lyrics' => '%s published lyrics %s',
	'river:comment:object:phloor_lyrics' => '%s commented on the lyrics %s',

	// notifications
	'phloor_lyrics:newpost' => 'New lyrics',

	// widget
	'phloor_lyrics:widget:description' => 'Display your latest lyrics',
	'phloor_lyrics:morephloor_lyricss' => 'More lyrics',
	'phloor_lyrics:numbertodisplay' => 'Number of lyrics to display',
	'phloor_lyrics:nophloor_lyricss' => 'No lyrics'
);

add_translation('en', $english);
