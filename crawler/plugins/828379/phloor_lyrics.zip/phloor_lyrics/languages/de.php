<?php

$german = array(
	'phloor_lyrics' => 'Lyrics',
	'phloor_lyrics:phloor_lyricss' => 'Lyrics',
	'phloor_lyrics:revisions' => 'Überarbeitungen',
	'phloor_lyrics:phloor_lyrics' => 'Lyrics',
	'item:object:phloor_lyrics' => 'Lyrics',

	'phloor_lyrics:title:user_phloor_lyricss' => '%s\'s Lyrics',
	'phloor_lyrics:title:all_phloor_lyricss' => 'Alle Lyrics',
	'phloor_lyrics:title:friends' => 'Lyrics von Freunden',

	'phloor_lyrics:group' => 'Gruppen Lyrics',
	'phloor_lyrics:phloor_band' => 'Band Lyrics',
	'phloor_lyrics:enablephloor_lyrics' => 'Gruppen Lyrics aktivieren',
	'phloor_lyrics:write' => 'Lyrics anlegen',

	// Editing
	'phloor_lyrics:add' => 'Lyrics hinzufügen',
	'phloor_lyrics:edit' => 'Lyrics bearbeiten',
	'phloor_lyrics:briefdescription' => 'Kurzbeschreibung',
	'phloor_lyrics:description' => 'Text',
	'phloor_lyrics:bandname' => 'Name der Band',
	'phloor_lyrics:bandname:description' => 'Gib den Namen der Band oder des Künstlers ein (ist dieses Feld leer, dein Username oder der Name deiner Band/Gruppe benutzt). ',
	'phloor_lyrics:albumname' => 'Album-/Compilation-Titel',
	'phloor_lyrics:save_status' => 'Zuletzt gespeichert: ',
	'phloor_lyrics:never' => 'Noch nie',

	// Statuses
	'phloor_lyrics:status' => 'Status',
	'phloor_lyrics:status:draft' => 'Entwurf',
	'phloor_lyrics:status:published' => 'Veräffentlicht',
	'phloor_lyrics:status:unsaved_draft' => 'Ungespeicherter Entwurf',

	'phloor_lyrics:revision' => 'Überarbeitung',
	'phloor_lyrics:auto_saved_revision' => 'Auto Saved Revision',

	// messages
	'phloor_lyrics:message:saved' => 'Lyrics wurden gespeichert.',
	'phloor_lyrics:error:cannot_save' => 'Konnte Lyrics nicht speichern.',
	'phloor_lyrics:error:cannot_write_to_container' => 'Du hast nicht die nötigen Rechte für diese Aktion.',
	'phloor_lyrics:error:post_not_found' => 'Lyrics konnten nicht gefunden werden, oder du hast  nicht die nötigen Rechte für diese Aktion.',
	'phloor_lyrics:messages:warning:draft' => 'Es gibt einen ungespeicherten Entwurf dieser Lyrics!',
	'phloor_lyrics:edit_revision_notice' => '(Alte Version)',
	'phloor_lyrics:message:deleted_post' => 'Lyrics wurden gelöscht.',
	'phloor_lyrics:error:cannot_delete_post' => 'Lyrics konnten nicht gelöscht werden.',
	'phloor_lyrics:none' => 'Keine Lyrics vorhanden.',
	'phloor_lyrics:error:missing:title' => 'Bitte gib den Lyrics einen Titel!',
	'phloor_lyrics:error:missing:description' => 'Bitte gib einen Text an!',
	'phloor_lyrics:error:cannot_edit_post' => 'Lyrics konnten nicht gefunden werden, oder du hast  nicht die nötigen Rechte für diese Aktion.',
	'phloor_lyrics:error:revision_not_found' => 'Überarbeitung konnte nicht gefunden werden.',

	// river
	'river:create:object:phloor_lyrics' => '%s veröffentlichte die Lyrics zu %s',
	'river:comment:object:phloor_lyrics' => '%s kommentierte die Lyrics zu %s',

	// notifications
	'phloor_lyrics:newpost' => 'Neue Lyrics',

	// widget
	'phloor_lyrics:widget:description' => 'Zeigt die deine letzten Lyrics an',
	'phloor_lyrics:morephloor_lyricss' => 'Mehr Lyrics',
	'phloor_lyrics:numbertodisplay' => 'Anzahl der anzuzeigenden Lyrics',
	'phloor_lyrics:nophloor_lyricss' => 'Keine Lyrics vorhanden.'
);

add_translation('de', $german);
