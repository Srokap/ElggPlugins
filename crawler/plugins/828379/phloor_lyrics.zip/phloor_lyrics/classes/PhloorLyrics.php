<?php
/**
 * Extended class to override the time_created
 */
class PhloorLyrics extends ElggObject {

	/**
	 * Set subtype to phloor_lyrics.
	 */
	protected function initializeAttributes() {
		parent::initializeAttributes();

		$this->attributes['subtype'] = "phloor_lyrics";
	}

	public function canComment($user_guid = 0) {
		$result = parent::canComment($user_guid);
		if ($result == false) {
			return $result;
		}

		if ($this->comments_on == 'Off') {
			return false;
		}
		
		return true;
	}

}