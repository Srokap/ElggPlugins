<?php

$object = $vars['item']->getObjectEntity();
$description = strip_tags($object->briefdescription);
$excerpt = elgg_get_excerpt($description);

echo elgg_view('river/elements/layout', array(
	'item' => $vars['item'],
	'message' => $excerpt,
));