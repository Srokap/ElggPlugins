<?php

?>

/* force tinymce input height for a more useful editing / phloor_lyrics creation area */
form#phloor_lyrics-post-edit #description_parent #description_ifr {
	height:400px !important;
}

span.phloor-lyrics-bandname,
span.phloor-lyrics-albumname {
	font-weight: bold;
}