<?php
/**
 * Group phloor_lyrics module
 */

$group = elgg_get_page_owner_entity();

if ($group->phloor_lyrics_enable == "no") {
	return true;
}

$title = elgg_echo('phloor_lyrics:group');
if(strcmp('phloor_band', $group->subtype) == 0) {
    $title = elgg_echo('phloor_lyrics:phloor_band');
}

$all_link = elgg_view('output/url', array(
	'href' => "phloor_lyrics/group/$group->guid/all",
	'text' => elgg_echo('link:view:all'),
	'is_trusted' => true,
));

elgg_push_context('widgets');
$options = array(
	'type' => 'object',
	'subtype' => 'phloor_lyrics',
	'container_guid' => elgg_get_page_owner_guid(),
	'limit' => 6,
	'full_view' => false,
	'pagination' => false,
);
$content = elgg_list_entities($options);
elgg_pop_context();

if (!$content) {
	$content = '<p>' . elgg_echo('phloor_lyrics:none') . '</p>';
}

$new_link = elgg_view('output/url', array(
	'href' => "phloor_lyrics/add/$group->guid",
	'text' => elgg_echo('phloor_lyrics:write'),
	'is_trusted' => true,
));

echo elgg_view('groups/profile/module', array(
	'title' => elgg_echo('phloor_lyrics:group'),
	'content' => $content,
	'all_link' => $all_link,
	'add_link' => $new_link,
));
