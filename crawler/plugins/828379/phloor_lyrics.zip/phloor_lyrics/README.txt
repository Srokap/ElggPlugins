/**
 * phloorLyrics
 * 
 * @package phloor_lyrics
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author void <void@13net.at>
 * @copyright 13net
 * @link http://www.13net.at/
 */

/**
 * Description
 */
Enables creating lyrics for your Elgg site.

User, Groups and Bands are able to create lyrics
objects just like the 'pages' plugin.

/**
 * Languages
 */
English
German

