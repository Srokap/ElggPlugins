<?php
/**
 * Register the PhloorLyrics class for the object/phloor_lyrics subtype
 */

if (get_subtype_id('object', 'phloor_lyrics')) {
	update_subtype('object', 'phloor_lyrics', 'PhloorLyrics');
} else {
	add_subtype('object', 'phloor_lyrics', 'PhloorLyrics');
}
