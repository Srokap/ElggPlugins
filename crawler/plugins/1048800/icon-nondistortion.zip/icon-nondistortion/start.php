<?php
/**
 * No distortion for icons
 * 
 */

