<?php

	/**
	 * Elgg resources add/save action
	 *
	 * @package ElggResources
	 */

	gatekeeper();

		$title = strip_tags(get_input('title'));
		$guid = get_input('resource_guid',0);
		$description = get_input('description');
		$address = get_input('address');
		$access = get_input('access');
		$shares = get_input('shares',array());



		// don't allow malicious code.
		// put this in a context of a link so HTMLawed knows how to filter correctly.
		$xss_test = "<a href=\"$address\"></a>";
		if ($xss_test != filter_tags($xss_test)) {
			register_error(elgg_echo('resources:save:failed'));
			forward(REFERER);
		}

		$tags = get_input('tags');
		$tagarray = string_to_tag_array($tags);

		$new_resource = FALSE;
		if ($guid == 0) {

			$entity = new ElggObject;
			$entity->subtype = "resources";
			$entity->owner_guid = $_SESSION['user']->getGUID();
			$entity->container_guid = (int)get_input('container_guid', $_SESSION['user']->getGUID());

			$new_resource = TRUE;

		} else {

			$canedit = false;
			if ($entity = get_entity($guid)) {
				if ($entity->canEdit()) {
					$canedit = true;
                    forward("pg/resources/shared");
				}
			}
			if (!$canedit) {
				system_message(elgg_echo('notfound'));
				//forward("pg/resources");
			}

		}

		$entity->title = $title;
		$entity->address = $address;
		$entity->description = $description;
		$entity->access_id = $access;
		$entity->tags = $tagarray;

		if ($entity->save()) {
			$entity->clearRelationships();
			$entity->shares = $shares;

			if (is_array($shares) && sizeof($shares) > 0) {
				foreach($shares as $links) {
					$links = (int) $links;
					add_entity_relationship($entity->getGUID(),'links',$links);
				}
			}
			system_message(elgg_echo('resources:save:success'));
			//add to river
			if ($new_resource) {
				add_to_river('river/object/resources/create','create',$_SESSION['user']->guid,$entity->guid);
                forward("pg/activity");
			}
			forward($entity->getURL());
		} else {
			register_error(elgg_echo('resources:save:failed'));
			forward("pg/dashboard");
		}

?>