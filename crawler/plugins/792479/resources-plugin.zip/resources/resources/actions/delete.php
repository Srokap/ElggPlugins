<?php

	/**
	 * Elgg resources delete action
	 * 
	 * @package ElggResources
	 */

		$guid = get_input('resource_guid',0);
		if ($entity = get_entity($guid)) {

			$container = get_entity($entity->container_guid);
			if ($entity->canEdit()) {
				
				if ($entity->delete()) {
					
					system_message(elgg_echo("resources:delete:success"));
					forward("pg/resources/owner/$container->username/");
					
				}
				
			}
			
		}
		
		register_error(elgg_echo("resources:delete:failed"));
		forward(REFERER);

?>