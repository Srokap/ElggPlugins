<?php

/**
 * Elgg Resources plugin
 *
 * @package ElggResources
 */

// Resources initialisation function
function resources_init() {

	// Grab the config global
	global $CONFIG;

	//add a tools menu option
	if (isloggedin()) {
        add_menu(elgg_echo('resources:tools'), $CONFIG->wwwroot . "pg/resources/owner/" . $_SESSION['user']->username);


		// add "resource this" to owner block
		elgg_extend_view('owner_block/extend', 'resources/owner_block');
	}

	// Register a page handler, so we can have nice URLs
	register_page_handler('resources','Resources_page_handler');

	// Add our CSS
	elgg_extend_view('css','resources/css');

	// Register granular notification for this type
	if (is_callable('register_notification_object')) {
		register_notification_object('object', 'resources', elgg_echo('resources:new'));
	}

	// Listen to notification events and supply a more useful message
	register_plugin_hook('notify:entity:message', 'object', 'Resources_notify_message');

	// Register a URL handler for shared items
	register_entity_url_handler('resource_url','object','entity');

	// Shares widget
	//add_widget_type('resources',elgg_echo("resources"),elgg_echo("resources:widget:description"));
    

	// Register entity type
	register_entity_type('object','resources');

	// Add group menu option
//	add_group_tool_option('resources',elgg_echo('groups:enableResources'),true);
	//elgg_extend_view('groups/right_column', 'resources/groupprofile_resources');
}

/**
 * Sidebar menu for resources
 *
 */
function resources_pagesetup() {
	global $CONFIG;

	$page_owner = page_owner_entity();

	//add submenu options
	if (get_context() == "resources") {

		if (isloggedin()) {
			// link to add resource form
			if ($page_owner instanceof ElggGroup) {
				if ($page_owner->isMember(get_loggedin_user())) {
 
                    
				}
			} else {
                               
			}
			if (page_owner()) {
				add_submenu_item(sprintf(elgg_echo('resources:inbox'),$page_owner->name),$CONFIG->wwwroot."pg/resources/inboxlinks/" . $page_owner->username);
                add_submenu_item(sprintf(elgg_echo('resources:read'), $page_owner->name),$CONFIG->wwwroot."pg/resources/owner/" . $page_owner->username);
                }
           
				//if (!$page_owner instanceof ElggGroup) {
			//	add_submenu_item(elgg_echo('resources:friends'),$CONFIG->wwwroot."pg/resources/friends/" . $_SESSION['user']->username);
               
			}
		}

		//	if (!$page_owner instanceof ElggGroup) {
		//	add_submenu_item(elgg_echo('resources:everyone'),$CONFIG->wwwroot."pg/resources/all/");
	
        

		
		// resourcelet
		//	if ((isloggedin()) && (page_owner()) && (can_write_to_container(0, page_owner()))) {

		//		$bmtext = elgg_echo('resources:resourcelet');
	    //		if ($page_owner instanceof ElggGroup) {
		//			$bmtext = elgg_echo('resources:resourcelet:group');
			
       //     	}
                        
		//		add_submenu_item($bmtext, $CONFIG->wwwroot . "pg/resources/web/{$page_owner->username}/");
        //
        //	}

	//	}

		//if ($page_owner instanceof ElggGroup && get_context() == 'groups') {
		//	if ($page_owner->resources_enable != "no") {
		//		add_submenu_item(sprintf(elgg_echo("resources:group"),$page_owner->name), $CONFIG->wwwroot . "pg/resources/owner/" . $page_owner->username);
		//	}
	//	}

	//}

	}
/**
 * Resources page handler; allows the use of fancy URLs
 *
 * @param array $page From the page_handler function
 * @return true|false Depending on success
 */
function resources_page_handler($page) {

	// group usernames
	if (substr_count($page[0], 'group:')) {
		preg_match('/group\:([0-9]+)/i', $page[0], $matches);
		$guid = $matches[1];
		if ($entity = get_entity($guid)) {
			Resources_url_forwarder($page);
		}
	}

	// user usernames
	$user = get_user_by_username($page[0]);
	if ($user) {
		Resources_url_forwarder($page);
	}

	switch ($page[0]) {
		
        case "share":
			set_input('username', $page[1]);
			include(dirname(__FILE__) . "/share.php");
            break;
               
        case "read":
			set_input('guid', $page[1]);
			require(dirname(dirname(dirname(__FILE__))) . "/entities/indexshare.php");
			break;
		case "friends":
			set_input('username', $page[1]);
			include(dirname(__FILE__) . "/friends.php");
			break;
		case "all":
			include(dirname(__FILE__) . "/everyone.php");
			break;
		case "inbox":
			set_input('username', $page[1]);
			include(dirname(__FILE__) . "/inbox.php");
			break;
        case "inboxlinks":
			set_input('username', $page[1]);
			include(dirname(__FILE__) . "/inboxlinks.php");
			break;
                
		case "owner":
			set_input('username', $page[1]);
			include(dirname(__FILE__) . "/indexshare.php");
			break;

		case "web":
			set_input('username', $page[1]);
			include(dirname(__FILE__) . "/bookmarklet.php");
			break;
            
   		case "shared":
			set_input('username', $page[1]);
			include(dirname(__FILE__) . "/indexshare.php");
			break;
            
		default:
			return false;
	}

	return true;
}

/**
 * Forward to the new style of URLs
 *
 * @param string $page
 */
function resources_url_forwarder($page) {
	global $CONFIG;

	if (!isset($page[1])) {
		$page[1] = 'items';
	}

	switch ($page[1]) {
		case "read":
			$url = "{$CONFIG->wwwroot}pg/resources/read/{$page[2]}/{$page[3]}";
			break;
		case "inbox":
			$url = "{$CONFIG->wwwroot}pg/resources/inbox/{$page[0]}/";
			break;
		case "friends":
			$url = "{$CONFIG->wwwroot}pg/resources/friends/{$page[0]}/";
			break;
		case "add":
			$url = "{$CONFIG->wwwroot}pg/resources/add/{$page[0]}/";
			break;
		case "items":
			$url = "{$CONFIG->wwwroot}pg/resources/owner/{$page[0]}/";
			break;
		case "resourcelet":
			$url = "{$CONFIG->wwwroot}pg/resources/resourcelet/{$page[0]}/";
			break;
       // case "shared":
		//	$url = "{$CONFIG->wwwroot}pg/resources/shared/{$page[0]}/";
		//	break;
    
            
	}
    

//	register_error(elgg_echo("changeresource"));
	forward($url);
}

/**
 * Populates the ->getUrl() method for resourceed objects
 *
 * @param ElggEntity $entity The resourceed object
 * @return string resourceed item URL
 */
function resources_url($entity) {

	global $CONFIG;
	$title = $entity->title;
	$title = elgg_get_friendly_title($title);
	return $CONFIG->url . "pg/resources/read/" . $entity->getGUID() . "/" . $title;
}

/**
 * Returns a more meaningful message
 *
 * @param unknown_type $hook
 * @param unknown_type $entity_type
 * @param unknown_type $returnvalue
 * @param unknown_type $params
 */
function resources_notify_message($hook, $entity_type, $returnvalue, $params) {
	$entity = $params['entity'];
	$to_entity = $params['to_entity'];
	$method = $params['method'];
    if (($entity instanceof ElggEntity) && ($entity->getSubtype() == 'resources'))  {
		
        $descr = $entity->description;
		$title = $entity->title;
		global $CONFIG;
		$url = $CONFIG->wwwroot . "pg/view/" . $entity->guid;
		if ($method == 'sms') {
			$owner = $entity->getOwnerEntity();
			return $owner->name . ' ' . elgg_echo("resources:via") . ': ' . $url . ' (' . $title . ')';
		}
		if ($method == 'email') {
			$owner = $entity->getOwnerEntity();
			return $owner->name . ' ' . elgg_echo("resources:via") . ': ' . $title . "\n\n" . $descr . "\n\n" . $entity->getURL();
		}
		if ($method == 'web') {
			$owner = $entity->getOwnerEntity();
			return $owner->name . ' ' . elgg_echo("resources:via") . ': ' . $title . "\n\n" . $descr . "\n\n" . $entity->getURL();
		}

	}
	return null;
}



// Make sure the initialisation function is called on initialisation
register_elgg_event_handler('init','system','resources_init');
register_elgg_event_handler('pagesetup','system','resources_pagesetup');

// Register actions
global $CONFIG;
register_action('resources/delete',false,$CONFIG->pluginspath . "resources/actions/delete.php");
register_action('resources/share',false,$CONFIG->pluginspath . "resources/actions/share.php");


?>