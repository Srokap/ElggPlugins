<?php

	/**
	 * Elgg resources plugin inbox page
	 * 
	 * @package ElggResources
	 */

	// Start engine
		require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
		
	// List resources
		$area2 = elgg_view_title(elgg_echo('resources:inbox'));
		set_context('searchresource');
		// offset is grabbed in list_entities_from_relationship()
        $area2 .= list_entities_from_relationship('links',page_owner(),true,'object','resources');
		set_context('resources');
		
	// Format page
		$body = elgg_view_layout('two_column_left_sidebar', $area1, $area2);
		
	// Draw it
		page_draw(elgg_echo('links:inbox'),$body);

?>