<?php

	/**
	 * Elgg resources plugin everyone page
	 * 
	 * @package ElggResources
	 */

	// Start engine
		require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
		
	// Get the current page's owner
		$page_owner = page_owner_entity();
		if ($page_owner === false || is_null($page_owner)) {
			$page_owner = $_SESSION['user'];
			set_page_owner($_SESSION['guid']);
		}
		
	// List resources
		$area2 = elgg_view_title(elgg_echo('resources:everyone'));
		set_context('searchresource');
		$offset = (int)get_input('offset', 0);
		$area2 .= elgg_list_entities(array('type' => 'object', 'subtype' => 'resources', 'limit' => 50, 'offset' => $offset, 'full_view' => FALSE, 'view_toggle_type' => FALSE));
		set_context('resources');
		
	// Format page
		$body = elgg_view_layout('two_column_left_sidebar', $area1, $area2);
		
	// Draw it
		page_draw(elgg_echo('resources:everyone'),$body);

?>