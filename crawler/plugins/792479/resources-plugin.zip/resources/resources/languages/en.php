<?php

	$english = array(

		/**
		 * Menu items and titles
		 */
            'links:river:created'=> '%s shared a resource:',
            'shareit'=> 'Share',
            'resource:link' => "resource", 
			'resources' => "Resources",
			'resources:add' => "Add resource",
			'resources:read' => "%s's resourceed items",
			'resources:friends' => "Friends' resources",
			'resources:everyone' => "All site resources",
			'resources:this' => "Share",
			'resources:this:group' => "resource in %s",
			'resources:resourcelet' => "Get resourcelet",
			'resources:resourcelet:group' => "Get group resourcelet",
			'resources:inbox' => "Resources inbox",
			'resources:moreResources' => "More resources",
			'resources:more' => "More",
			'resources:shareditem' => "resourceed item",
			'resources:with' => "Share with",
			'resources:new' => "A new resourceed item",
			'resources:via' => "via resources",
			'resources:address' => "Address of the resource to resource",

			'resources:delete:confirm' => "Are you sure you want to delete this resource?",

			'resources:numbertodisplay' => 'Number of resourceed items to display',

			'resources:shared' => "resourceed",
			'resources:visit' => "Visit resource",
			'resources:recent' => "Recent resources",

			'resources:river:created' => '%s <br />resourceed',
			'resources:river:annotate' => 'a comment on this resourceed item',
			'resources:river:item' => 'an item',

			'item:object:resources' => 'resourceed items',

			'resources:group' => 'Group resources',
			'groups:enableResources' => 'Enable group resources',
			'resources:nogroup' => 'This group does not have any resources yet',
			'resources:more' => 'More resources',


		/**
		 * More text
		 */

			'resources:widget:description' =>
					"This widget displays your latest resources.",

			'resources:resourcelet:description' =>
					"The resources resourcelet allows you to share any resource you find on the web with your friends, or just resource it for yourself. To use it, simply drag the following button to your browser's links bar:",

			'resources:resourcelet:descriptionie' =>
					"If you are using Internet Explorer, you will need to right click on the resourcelet icon, select 'add to resources', and then the Links bar.",

			'resources:resourcelet:description:conclusion' =>
					"You can then save any page you visit by clicking it at any time.",

			'resources:no_title' => 'No title',

		/**
		 * Status messages
		 */

			'resources:save:success' => "Your item was successfully resourceed.",
			'resources:delete:success' => "Your resourceed item was successfully deleted.",

		/**
		 * Error messages
		 */

			'resources:save:failed' => "Your resourceed item could not be saved. Make sure you've entered a title and address and then try again.",
			'resources:delete:failed' => "Your resourceed item could not be deleted. Please try again.",


	);

	add_translation("en",$english);

?>