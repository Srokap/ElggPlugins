<?php

	$italian = array(

		/**
		 * Menu items and titles
         * 
         *  
         * 
		 */ 
            'resources:inbox'=>'Risorse ricevute',
            'resources:tools'=>'Risorse',
            'shareit'=> 'Condividi',
            'resources:share:resource' => 'Risorse inviate',
            'resource:link' => "Risorsa", 
			'resources' => "Risorse",
			'resources:add' => "Condividi risorsa",
			'resources:read' => "Risorse inviate",
			'resources:friends' => "Risorse dei miei contatti",
			'resources:everyone' => "Tutte le risorse",
			'resources:this' => "Condividi",
			'resources:this:group' => "linka in %s",
			'resources:resourcelet' => "Condividere dal web",
			'resources:resourcelet:group' => "Condividere dal web",
			'resources:inbox' => "Risorse ricevute",
            'links:inbox'=>'Risorse ricevute',
			'resources:moreResources' => "Altre risorse",
			'resources:more' => "Leggi",
			'resources:shareditem' => "Risorse",
			'resources:with' => "Condividi con",
			'resources:new' => "Una nuova risorsa",
			'resources:via' => "via internet",
			'resources:address' => "Indirizzo del link",

			'resources:delete:confirm' => "Sei sicuro di voler rimuovere questo risorsa?",

			'resources:numbertodisplay' => 'Numero di risorse da mostrare',

			'resources:shared' => "Condiviso",
			'resources:visit' => "Guarda",
			'resources:recent' => "Risorse recenti",

			'resources:river:created' => '%s ha condiviso un risorsa:<br />',
			'resources:river:annotate' => 'un commento su questo risorsa:<br />',
			'resources:river:item' => 'un link',
            'links:river:created'=> '%s ha condiviso:',

			'item:object:resources' => 'Risorse',

			'resources:group' => 'Risorse',
			'groups:enableResources' => 'Attiva i risorse di gruppo',
			'resources:nogroup' => 'Questo gruppo non ha nessun risorsa.',
			'resources:more' => 'Di pi&ugrave;',
            'save' => 'Salva',


		/**
		 * More text
		 */

			'resources:widget:description' =>
					"Questo widget mostra i tuoi ultimi risorse.",

			'resources:resourcelet:description' =>
					"Trascina il link <b>Condividi</b> sulla barra dei preferiti per condividere nuove pagine dal web!",

			'resources:resourcelet:descriptionie' =>
					"",

			'resources:resourcelet:description:conclusion' =>
					"",

			'resources:no_title' => 'Nessun titolo',

		/**
		 * Status messages
		 */

			'resources:save:success' => "La risorsa &egrave; stata condivisa.",
			'resources:delete:success' => "La risorsa &egrave; stata eliminata.",

		/**
		 * Error messages
		 */

			'resources:save:failed' => "Dovresti scrivere qualcosa prima di condividere un risorsa.",
			'resources:delete:failed' => "Il tuo risorsa non pu&ograve; essere eliminato. Per favore, riprova di nuovo.",


	);

	add_translation("it",$italian);

?>