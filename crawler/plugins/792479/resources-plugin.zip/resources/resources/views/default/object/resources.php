<?php

	$owner = $vars['entity']->getOwnerEntity();
	$friendlytime = elgg_view_friendly_time($vars['entity']->time_created);

	if (get_context() == "searchresource") {

		if (get_input('searchresource_viewtype') == "gallery") {

			$parsed_url = parse_url($vars['entity']->address);
			$faviconurl = $parsed_url['scheme'] . "://" . $parsed_url['host'] . "/favicon.ico";
		
			
			$info .= "<p class=\"shares_gallery_user\">By: <a href=\"{$vars['url']}pg/resources/{$owner->username}\">{$owner->name}</a> <span class=\"shared_timestamp\">{$friendlytime}</span></p>";
			$numcomments = elgg_count_comments($vars['entity']);
			if ($numcomments)
				$info .= "<p class=\"shares_gallery_comments\"><a href=\"{$vars['entity']->getURL()}\">".sprintf(elgg_echo("comments")). " (" . $numcomments . ")</a></p>";
			
			//display 
			echo "<div class=\"share_gallery_view\">";
			echo "<div class=\"share_gallery_info\">" . $info . "</div>";
			echo "</div>";


		} else {

			$parsed_url = parse_url($vars['entity']->address);
			$faviconurl = $parsed_url['scheme'] . "://" . $parsed_url['host'] . "/favicon.ico";
			if (@file_exists($faviconurl)) {
				$icon = "<img src=\"{$faviconurl}\" />";
			} else {
				$icon = elgg_view(
					"profile/icon", array(
										'entity' => $owner,
										'size' => 'small',
									  )
				);
			}
		
			$info = "<p class=\"shares_gallery_title\">"."<a href=\"{$vars['entity']->address}\">{$vars['entity']->title}</a><a href=\"{$vars['entity']->address}\">"."</p>";
			$info .= "<p class=\"owner_timestamp\"><a href=\"{$vars['url']}pg/resources/{$owner->username}\">{$owner->name}</a> {$friendlytime}";
			$numcomments = elgg_count_comments($vars['entity']);
			if ($numcomments)
				$info .= ", <a href=\"{$vars['entity']->getURL()}\">".sprintf(elgg_echo("comments")). " (" . $numcomments . ")</a>";
		    $info .= "</p>";
			echo elgg_view_listing($icon, $info);

		}
		
	} else {


?>


	<?php echo elgg_view_title(elgg_echo('resources:shareditem'), false); ?>
	<div id="contentWrapperResourceSearch">
	<div class="sharing_item">
	
		<div class="resource_item_title">
			<h3>
				<a href="<?php echo $vars['entity']->address; ?>"><?php echo $vars['entity']->title; ?></a>
			</h3>
		</div>



	</div>
	</div>

	
<?php

	}


?>
