<div class="test">
<?php

	$performed_by = get_entity($vars['item']->subject_guid); // $statement->getSubject();
	$object = get_entity($vars['item']->object_guid);
	$url = $object->getURL();
	
    $url = "<a href=\"{$performed_by->getURL()}\">{$performed_by->name}</a>";
	$string = sprintf(elgg_echo("links:river:created"),$url) . " ";
	$string .= "<a href=\"" . $object->address . "\">" . $object->title . "</a>"; //elgg_echo("resources:river:item") . "</a>";
	
?>

<?php 
	echo $string;
?>
</div>