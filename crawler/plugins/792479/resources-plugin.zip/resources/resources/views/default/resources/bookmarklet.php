<?php

	$page_owner = $vars['pg_owner'];
	
	$resourcetext = elgg_echo("resources:this");
	if ($page_owner instanceof ElggGroup)	
		$resourcetext = sprintf(elgg_echo("resources:this:group"), $page_owner->name)
?>
	<div class="contentWrapperHowToShare">
	<p>
		<?php echo elgg_echo("resources:resourcelet:description"); ?>
	</p>
	<p class="sharing_resourcelet">
		<a href="javascript:location.href='<?php echo $vars['url']; ?>pg/resources/add/<?php echo $page_owner->username; ?>?address='+encodeURIComponent(location.href)+'&title='+encodeURIComponent(document.title)"> <img src="<?php echo $vars['url']; ?>_graphics/elgg_resourcelet.gif" border="0" title="<?php echo $resourcetext ?>" />   </a>
	</p>
	<p>
		<?php echo elgg_echo("resources:resourcelet:descriptionie"); ?>
	</p>
	<p>
		<?php echo elgg_echo("resources:resourcelet:description:conclusion"); ?>
	</p>
	</div>