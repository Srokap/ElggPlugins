<?php

$label = elgg_echo('resources:this');
$user = get_loggedin_user();
$url = "'" . $vars['url'] . "pg/resources/share/{$user->username}?address='+encodeURIComponent(location.href)+'&title='+encodeURIComponent(document.title)";

?>
<div id="owner_block_resource_this">
<a href="javascript:location.href=<?php echo $url; ?>"><?php echo $label ?></a>
</div>