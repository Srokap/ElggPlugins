
/* ***************************************
PAGE-OWNER BLOCK
*************************************** */
#contentWrapperResourceSearch{
    background: url("http://localhost/speedycue/_graphics/fondo_evento.png") no-repeat scroll right center transparent;
    margin: 0;
    padding-bottom: 22px;
    padding-left: 12px;
    padding-top: 18px;
}

.resource_item_title h3 {
    margin: 0;
}
.resource_item_title h3 a {
    cursor: pointer;
    font-size: 14px;
}
.resource_item_title h3 a:hover{
    text-decoration: underline;

}


#owner_block_resource_this {
    border-bottom: 1px solid #EBEBEB;
    margin-right: 40px;
    padding-bottom: 2px;
    padding-top: 14px;
}
#owner_block_resource_this a {
    background: none repeat scroll 0 0 #FFFFFF;
    border: 1px solid #FFFFFF;
    display: block;
    font: 12px arial,sans-serif;
    margin-bottom: 0;
    padding: 4px 5px 4px 7px;
    text-decoration: none;
}
#owner_block_resource_this a:hover {
    text-decoration: none ;
    background: #F3F8FC ;
    border: 1px solid #BFD9F0;
}

.new_boomark_share{
   margin-top: 12px;
}

.share_resource_with{
    margin-bottom: 0;
    margin-top: 18px; 
}
.share_explain{
    
}
