<?php

	/**
	 * Elgg resources plugin index page
	 * 
	 * @package ElggResources
	 */

	// Start engine
		require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	// access check for closed groups
	group_gatekeeper();
		
		$page_owner = page_owner_entity();
		if ($page_owner === false || is_null($page_owner)) {
			$page_owner = $_SESSION['user'];
			set_page_owner($page_owner->getGUID());
		}
		
		$title = sprintf(elgg_echo('resources:share:resource'), $page_owner->name);
		
	// List resources
		$area2 = elgg_view_title($title);
		set_context('searchresource');
		$offset = (int)get_input('offset', 0);
		$area2 .= elgg_list_entities(array('type' => 'object', 'subtype' => 'resources', 'container_guid' => page_owner(), 'limit' => 50, 'offset' => $offset, 'full_view' => FALSE, 'view_type_toggle' => FALSE));
		set_context('resources');
		
	// Format page
		$body = elgg_view_layout('two_column_left_sidebar', $area1, $area2);
		
	// Draw it
		page_draw($title, $body);

?>