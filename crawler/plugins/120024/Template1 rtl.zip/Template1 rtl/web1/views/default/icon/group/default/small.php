<?php
	echo $vars['url'] . "mod/web1/graphics/group_icons/defaultsmall.gif";
?>