<?php
	echo $vars['url'] . "mod/web1/graphics/file_icons/pages_lrg.gif";
?>