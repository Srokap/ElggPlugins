<?php
	/**
	 * Custom Index page css extender
	 * 
	 * @package custom_index
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider <info@elgg.com>
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.org/
	 */
?>

#custom_index {
	margin:10px;
}
#index_left {
    width:325px;
    float:left;
    margin:0 0px 30px 0;
    padding:0 0 20px 0px;
}
#index_right {
    width:600px;
    float:right;
    margin:0 0 30px 0;
    padding:0 0px 20px 0;
}
#index_welcome {
	padding:5px 10px 5px 10px;
	margin:0 0 20px 0;
        -webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	border:1px solid #CCC;
	background: #c4eafa;

}
#index_welcome #login-box {
	margin:5px 0 10px 0;
    padding:0 0 10px 0;
   	border: 1px solid #ccc;
	background: #FFF;
	width:303px;
}
#welcomemessage{
 background: #fff url(<?php echo $vars['url']; ?>mod/web1/graphics/back1.jpg) no-repeat;
 width:600px;
 padding:5px;
 height: 200px;

}
#welcomemessage h2{
color:#4d4d4d;
    -webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
background:#b6e9ff;
width:260px;
border:1px solid #ccc;
font-size:13px;
padding:2px;
margin-right:30px;
float:right;
text-align:right;
}
#welcomemessage.content{
color:white;
font-size:18px;
padding-right:10px;

}

#index_welcome #login-box form {
	margin:0 10px 0 10px;
    padding:0 10px 4px 10px;
	background: #FFF;
	width:262px;
}
h3{
padding:8px;
padding-right:15px;
color:white;
    -webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
border:1px solid #333;
background: #333 url(<?php echo $vars['url']; ?>mod/web1/graphics/menu2.png) repeat right -12px;
	font-family: tahoma, Arial, 'Trebuchet MS','Lucida Grande', sans-serif;
	font-size: 13px;

}
#index_welcome #login-box h2,
.index_box h2 {
background: #333 url(<?php echo $vars['url']; ?>mod/web1/graphics/collpasible_back.png) repeat right -20px;
color:#fff;
font-size:1em;
line-height:1.2em;
margin:0 0 12px 0;
padding:5px 14px 5px 5px;
}
#index_welcome #login-box h2 {
	padding-bottom:5px;
}

.index_box {
margin:0 0 20px;
padding:5px;
background:#c4eafa;
}

.index_box .search_listing {

}
.index_box .index_members {
	float:right;
	margin:2pt 0pt 3px 5px;
}
#persistent_login {
	float:left;
	display:block;
	margin-top:-34px;
}

/* ######### CSS for Shade Tabs. Remove if not using ######### */

.shadetabs{
padding: 3px 0;
margin-right: 0;
margin-top: 1px;
margin-bottom: 0;
color:white;
font: bold 12px tahoma, Verdana;
list-style-type: none;
text-align: left; /*set to left, center, or right to align the menu as desired*/

}

.shadetabs li{
display: inline;
margin: 0;
}

.shadetabs li a{
text-decoration: none;
-moz-border-radius: 8px;
position: relative;
z-index: 1;
font-size:14px;
padding: 6px;
margin-left: 3px;
border: 1px solid #778;
color: white;
background: #333 url(<?php echo $vars['url']; ?>mod/web1/graphics/collpasible_back.png) repeat right -16px;
}

.shadetabs li a:visited{
color: #fff;
}

.shadetabs li a:hover{
color: #fff;
border: 1px solid #778;
background: #56c2e6 url(<?php echo $vars['url']; ?>mod/web1/graphics/menu2.png) repeat right -16px;


}

.shadetabs li a.selected{ /*selected main tab style */
position: relative;
top: 1px;
}

.shadetabs li a.selected{ /*selected main tab style */
background: #56c2e6;
border: 1px solid #778;
}

.shadetabs li a.selected:hover{ /*selected main tab style */
text-decoration: none;
}

.tabcontent{
display:none;
}

@media print {
.tabcontent {
display:block !important;
}
}