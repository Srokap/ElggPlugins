<?php

	/* Elgg Theme Simple Example */
	
	
	/* Initialise the theme */
	function web1_init(){
	
	}
	
	// Initialise log browser
	register_elgg_event_handler('init','system','web1_init');
	
?>