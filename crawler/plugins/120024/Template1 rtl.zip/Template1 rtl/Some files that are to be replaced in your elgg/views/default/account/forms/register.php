<?php

     /**
	 * Elgg register form
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.org/
	 */
	 
	$username = get_input('u');
	$email = get_input('e');
	$name = get_input('n');

	$admin_option = false;
	if (($_SESSION['user']->admin) && ($vars['show_admin'])) 
		$admin_option = true;
		
	$form_body = "<p><label>" . elgg_echo('name') . "<br />" . elgg_view('input/text' , array('internalname' => 'name', 'class' => "general-textarea", 'value' => $name)) . "</label><br />";
	
	$form_body .= "<label>" . elgg_echo('email') . "<br />" . elgg_view('input/text' , array('internalname' => 'email', 'class' => "general-textarea", 'value' => $email)) . "</label><br />";
	$form_body .= "<label>" . elgg_echo('username') . "<br />" . elgg_view('input/text' , array('internalname' => 'username', 'class' => "general-textarea", 'value' => $username)) . "</label><br />";
	$form_body .= "<label>" . elgg_echo('password') . "<br />" . elgg_view('input/password' , array('internalname' => 'password', 'class' => "general-textarea")) . "</label><br />";
	$form_body .= "<label>" . elgg_echo('passwordagain') . "<br />" . elgg_view('input/password' , array('internalname' => 'password2', 'class' => "general-textarea")) . "</label><br />";
	
	if ($admin_option)
		$form_body .= elgg_view('input/checkboxes', array('internalname' => "admin", 'options' => array(elgg_echo('admin_option'))));
	
	$form_body .= elgg_view('input/hidden', array('internalname' => 'friend_guid', 'value' => $vars['friend_guid']));
	$form_body .= elgg_view('input/hidden', array('internalname' => 'invitecode', 'value' => $vars['invitecode']));
	$form_body .= elgg_view('input/hidden', array('internalname' => 'action', 'value' => 'register'));
	$form_body .= elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('register'))) . "</p>";
?>
<style type="text/css">
<!--
.style1 {color: #333333}
.style2 {color: #00CCCC}
-->
</style>


	<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="44%" valign="top"><div id="register-box">      <h2 style="padding:5px; border:1px solid #ccc; background:#f5f5f5; color:#00CCFF;">Register at <span class="style1">YOGUYZ!!</span></h2>

      <p><?php echo elgg_view('input/form', array('action' => "{$vars['url']}action/register", 'body' => $form_body)) ?></p>
    </div></td>
    <td width="56%" valign="top"   style="padding:5px; border:1px solid #ccc; background:#f5f5f5;"><h2 class="style2">What's new in YOGUYZ!!</h2>
      <ul>
        <li>Make new Friends</li>
        <li>Send Messages</li>
        <li>Share Files</li>
        <li>Share Photos</li>
        <li>Share Videos from Vimeo, Youtube, Google Video etc.</li>
        <li>Make Personlised profiles</li>
        <li>Import Files from other Social Networks</li>
    </ul></td>
  </tr>
</table>

	