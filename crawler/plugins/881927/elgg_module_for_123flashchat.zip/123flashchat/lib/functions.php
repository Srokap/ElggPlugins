<?php
require_once 'requestRemote.php';  
if (!defined('CACHE_PATH'))
    define('CACHE_PATH', elgg_get_plugins_path().'123flashchat/cache/');
function chat_server($chatSetting,$data){
	if(isset($data['popup']) && $data['popup'] == 1){
		if($chatSetting->fc_fullscreen && $chatSetting->fc_extendserver != '3'){
			$width = "100%";
			$height = "100%";
		}else{
			$width = $chatSetting->fc_client_width.'px';
			$height = $chatSetting->fc_client_height.'px';
		}
	}else{
		$width = $chatSetting->fc_client_width.'px';
		$height = $chatSetting->fc_client_height.'px';
	}
	if ($chatSetting->fc_extendserver != "3"){
		$client_name = ($chatSetting->fc_client != "0") ? (($chatSetting->fc_client == "1") ? 'htmlchat/123flashchat.html' : 'avatarchat.swf') : '123flashchat.swf';
		$url = $chatSetting->fc_client_loc . $client_name . "?init_host=" . $chatSetting->fc_server_host . "&init_port=" . $chatSetting->fc_server_port ;
		$url .= ($chatSetting->fc_extendserver == "2") ? ("&init_group=" . $chatSetting->fc_group) : "";
	}else{
		$url = "http://free.123flashchat.com/js.php?room=" . $chatSetting->fc_room . "&skin="  . $chatSetting->fc_client_skin . "&lang="  . $chatSetting->fc_client_lang;
	}
	if ($room = isset($data['room'])?$data['room']:""){
    	$url .= "&init_room=" . $room;
	}	
	$user = elgg_get_logged_in_user_entity();
	if ($user){
		if(!empty($user->username) && !empty($user->password) ){
			$url .= "&init_user=" . rawurlencode($user->username) . "&init_password=" . rawurlencode($user->password);
		}
		if($user->name){
			$url .= "&init_nickname=".rawurlencode($user->name);
		}
	}
		
	$chat = '';
	if($chatSetting->fc_extendserver == "2"){
    	//$chat .= '<script language="javascript" src="'.$url.'&width='.$width.'&height='.$height.'"></script>';
    	$chat .= '<style>body{margin:0;padding:0;}</style><iframe id="frame" HSPACE="0" VSPACE="0" frameborder="0"  style="height:'.$height.'; width:'.$width.';" src="'.$url.'"></iframe>';
	}else{
		if($chatSetting->fc_client == "1"){
                $chat .=  '<style>body{margin:0;padding:0;}</style><iframe id="frame" HSPACE="0" VSPACE="0" frameborder="0"  style="height:'.$height.'; width:'.$width.';" src="'.$url.'"></iframe>';
		}else{
			$chat .=  '<script src="'. $chatSetting->fc_client_loc .'123flashchat.js"></script>
			<style>body{margin:0;padding:0;}</style>
			<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,19,0" width="'.$width.'" height="'.$height.'" id="topcmm_123flashchat" type="application/x-shockwave-flash">
				<param name=movie value="'.$url.'">
				<param name=quality value="high">
				<param name="menu" value="false">
				<param name="allowScriptAccess" value="always">
				<embed src="'.$url.'" allowScriptAccess="always" quality="high" menu="false" width="'.$width.'" height="'.$height.'" type="application/x-shockwave-flash" pluginspace="http://www.macromedia.com/go/getflashplayer"  name="topcmm_123flashchat"></embed>
			</object>';
		}
	}
	return $chat;
}
function chat_free($chatSetting){
	$result = '	<!-- 123FLASHCHAT FREE CHAT ROOM CODE BEGIN -->
		<style>body{margin:0;padding:0;}</style>
		<script language="javascript" src="http://free.123flashchat.com/js.php?room=';
	if ($chatSetting->fc_room == '')
		$result .= rawurlencode(mb_convert_encoding($chatSetting->fc_room,"GBK","GBK"));
	else
		$result .= rawurlencode(mb_convert_encoding($chatSetting->fc_room,"GBK","GBK"));
	//get userinfo
	$user = elgg_get_logged_in_user_entity();
	if (!empty($user)){
		$user_name = '&user='.rawurlencode($user->name);
	}else{
		$user_name = '&user=guest';
	}		
	$result .= '&width='.$chatSetting->fc_client_width.'&height='.$chatSetting->fc_client_height.$user_name.'"></script>
	<!-- 123FLASHCHAT FREE CHAT ROOM CODE END -->';
	return $result;
}
function chat_free_nosetting(){
	$result = '	<!-- 123FLASHCHAT FREE CHAT ROOM CODE BEGIN -->
		<style>body{margin:0;padding:0;}</style>
		<script language="javascript" src="http://free.123flashchat.com/js.php?room=elgg';
	$user = elgg_get_logged_in_user_entity();
	if (!empty($user)){
		$user_name = '&user='.rawurlencode($user->name);
	}else{
		$user_name = '&user=guest';
	}		
	$result .= '&width=100%&height=600'.$user_name.'"></script>
	<!-- 123FLASHCHAT FREE CHAT ROOM CODE END -->';
	return $result;
}

function serviceGetChatStats($chatSetting){
	$c_full = $chatSetting->fc_fullscreen;
	if($c_full){
		$fc_client_width = "screen.width";
		$fc_client_height = "screen.height";
	}else{
		$fc_client_width = $chatSetting->fc_client_width;
		$fc_client_height = $chatSetting->fc_client_height;
	}
	$status = getStatus($chatSetting);
	if($chatSetting->fc_user_list){
		$users = getUsers($chatSetting);
	}
	if($chatSetting->fc_room_list && $chatSetting->fc_extendserver != "3"){
		$rooms = getRooms($chatSetting);
	}
	if(isset($status['ln'])){
		$sOutputCode .= '<b>' . $status['ln'] . '</b> login users.';
        if (isset($status['rn'])){
            $sOutputCode = '<b>' . $status['rn'] . '</b> rooms, ' . '<b>' . $status['cn'] . '</b> connections, ' . $sOutputCode;
        }
	}
	if(isset($rooms)){
        $sOutputCode .= "<b><p>Rooms:</b> ";
        if(!$rooms) {
            $sOutputCode .= "None";
        }else{
            $xa = '<br />';
            foreach($rooms as $room){                
				if($chatSetting->fc_popup == 1){
					$chaturl = elgg_get_site_url().'123flashchat/chat?'.(!$chatSetting->fc_popup ? '' :'popup=1&').'room=' . $room['id'];
				}else{
					$chaturl = get_option('siteurl').'/chat?'.(!$chatSetting->fc_popup ? '' :'popup=1&').'room=' . $room['id'];
				}
				$js = (!$chatSetting->fc_popup) ? '' : 'onclick="window.open(\''.$chaturl.'\',\'123flashchat\',\'width=\'+'. $fc_client_width . '+\' ,height=\'+' .$fc_client_height . ');return false;"';
				$sOutputCode .= $xa . '<a href="http://wwww.123flashchat.com" ' .  $js . ">" .$room['name'] ."</a>(" . $room['count'] . ")";
                $xa = "<br />";
            }
        }
    }
	if(isset($users)){
        $sOutputCode .= "</p><p><b>Users:</b> ";
        if(!$users){
            $sOutputCode .= "None</p>";
        }else{
            $xb = '';
            foreach($users as $user){
                $sOutputCode .= $xb . $user['name'];
                $xb = ', ';
            }
            $sOutputCode .= "</p>";
        }
    }
    $thishref = elgg_get_site_url().'123flashchat/chat?'.(!$chatSetting->fc_popup ? '' :'popup=1&').'room=';
    $js = (!$chatSetting->fc_popup) ? '' : ' onclick="window.open(\''.$thishref.'\',\'123flashchat\',\'width=\'+'. $fc_client_width . '+\' ,height=\'+' .$fc_client_height . ');return false;"';

	$sOutputCode .=  '<p><a href="http://www.123flashchat.com"' .$js.">" ."<b>Chat Now!</b>" ."</a>";
    if($chatSetting->fc_popup == 1 && $chatSetting->fc_show_live == 1 && $chatSetting->fc_extendserver != 3){
		$livehref = elgg_get_site_url().'123flashchat/liveshow?'.(!$chatSetting->fc_popup ? '' :'popup=1&').'room=';
		$jslive = (!$chatSetting->fc_popup) ? '' : ' onclick="window.open(\''.$livehref.'\',\'123flashchat\',\'width=\'+'. $chatSetting->fc_client_width . '+\' ,height=\'+' .$chatSetting->fc_client_height . ');return false;"';
    	$sOutputCode .= '&nbsp;&nbsp;<a href="http://www.123flashchat.com"' .$jslive.">" ."<b>Live Show!</b>" ."</a></p>";
    }
    $sOutputCode = '<div class="dbContentHtml">' . $sOutputCode . '</div>';
    return $sOutputCode;
}

function getStatus($chatSetting){
	$data = topcmmRequestRemote::requestRemote(CACHE_PATH . "status.js",1);
    $status_json = substr($data,10);
    if ((time() > substr($data,0,10)) || !$status_json)
    {
        $server =  $chatSetting->fc_extendserver;
        switch ($server)
        {
            case "1":
                $status_js = $chatSetting->fc_api_url . "online.js";
                if($rs = topcmmRequestRemote::requestRemote($status_js,1))
                {
                    $status_json = substr($rs,11,-1);
                }
                break;
            case "2":
                $status_js = $chatSetting->fc_api_url . "online.js?group=" . $chatSetting->fc_group;
                if($rs = topcmmRequestRemote::requestRemote($status_js,1))
                {
                    $status_json = substr($rs,11,-1);
                }
                break;
            case "3":
                $status_js = "http://free.123flashchat.com/freeroomnum.php?roomname=" . $chatSetting->fc_room;
                if($rs = topcmmRequestRemote::requestRemote($status_js,1))
                {
                    preg_match("/document.write\('(.*)'\);/",$rs,$matches);
                    $status['ln'] = $matches[1];
                    $status_json = json_encode($status);
                }
                break;
        }
        @file_put_contents(CACHE_PATH . "status.js",(time() + 120) . $status_json);
    }
    return json_decode($status_json,true);
}

function getUsers($chatSettting){
	$context = stream_context_create(array(
            'http' => array(
                    'timeout' => 3      // Timeout in seconds
            )
    ));
    $data =  topcmmRequestRemote::requestRemote(CACHE_PATH ."cache/users.js",1);
    $users_json = substr($data,10);
    if ((time() > substr($data,0,10)) || !$users_json)
    {
        $server =  $chatSettting->fc_extendserver;
        switch ($server)
        {
            case "1":
                $rooms = getRooms($chatSettting);
                $users = array();
                foreach ($rooms as $room)
                {
                    $user_js = $chatSettting->fc_api_url . "roomonlineusers.js?roomid=" . $room['id'];
                    if($rs = topcmmRequestRemote::requestRemote($user_js,1))
                    {
                        $users = array_merge($users, json_decode(substr($rs,20,-1),true));
                    }
                }
                $users_json = json_encode($users);
                break;
            case "2":
                $user_js = $chatSettting->fc_api_url . "roomonlineusers.js?group=" . $chatSettting->fc_group;
                if($rs = topcmmRequestRemote::requestRemote($user_js,1))
                {
                    $users_json = substr($rs,20,-1);
                }
                break;
            case "3":
                $user_js = "http://free.123flashchat.com/freeroomuser.php?roomname=" . $chatSettting->fc_room;
                if($rs = topcmmRequestRemote::requestRemote($user_js,1))
                {
                    preg_match("/document.write\('(.*)'\);/",$rs,$matches);
                    foreach (explode(',', $matches[1]) as $user)
                    {
                        $users[] = array('name' => $user);
                    }
                }
                $users_json = json_encode($users);
                break;
        }
        @file_put_contents(CACHE_PATH ."users.js",(time() + 120) . $users_json);
    }
    return json_decode($users_json, true);
}

function getRooms($chatSetting){
	$data = topcmmRequestRemote::requestRemote(CACHE_PATH ."rooms.js", 1);
    $rooms_json = substr($data,10);
    if ((time() > substr($data,0,10)) || !$rooms_json)
    {
        $server =  $chatSetting->fc_extendserver;
        switch ($server)
        {
            case "1":
                $room_js = $chatSetting->fc_api_url . "rooms.js";
                break;
            case "2":
                $room_js = $chatSetting->fc_api_url . "rooms.js?group=" . $chatSetting->fc_group;
                break;
        }
        if($rs = topcmmRequestRemote::requestRemote($room_js,1))
        {
            $rooms_json = substr($rs,10,-1);
        }
        @file_put_contents(CACHE_PATH ."rooms.js",(time() + 120) . $rooms_json);
    }
    return json_decode($rooms_json, true);
}

function validate_client($client_loc){	
    $c_own_loc = '1';
    $swf = $client_loc . '123flashchat.swf';
    $headers = topcmmRequestRemote::requestRemote($swf,0);
    if($headers)
    {
        $c_own_loc = (substr($headers, 9, 3) == '200') ? "0" : "1";
    }
    return $c_own_loc;
}
function validate_data_api($data_api){   
	$da = 1;
    if(substr(topcmmRequestRemote::requestRemote($data_api,0), 9, 3) == 200){
        $da = 0;
    }
    return $da;
}
