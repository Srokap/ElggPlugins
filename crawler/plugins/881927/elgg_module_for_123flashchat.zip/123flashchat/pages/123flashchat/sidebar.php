<?php
/**
 * Members sidebar
 */
function getSideBar($chatSetting){
	$body = serviceGetChatStats($chatSetting);
	return elgg_view_module('aside', elgg_echo('123flashchat:side:title'), $body);
}