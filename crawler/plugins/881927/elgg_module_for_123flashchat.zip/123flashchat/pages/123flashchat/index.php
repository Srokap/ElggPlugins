<?php
/**
 * Elgg 123flashchat plugin everyone page
 *
 * @package Elgg123FlashChat
 */
require_once 'sidebar.php';

$title = elgg_echo('123flashchat:title');



$content = '';
global $CONFIG;
$queryguid = "SELECT * FROM {$CONFIG->dbprefix}objects_entity WHERE title = '123flashchat'";
$chatobject = get_data_row($queryguid);
$query = "SELECT * FROM {$CONFIG->dbprefix}private_settings WHERE entity_guid = $chatobject->guid";
$chatSettingarray = get_data($query);
foreach ($chatSettingarray as $key => $value){
	$chatSetting[$value->name] = $value->value;
}
$chatSetting = (object)$chatSetting;

$data['popup'] = !empty($_GET['popup'])?1:0;
$data['room'] = !empty($_GET['room'])?$_GET['room']:'';

if($chatSetting){
	if($chatSetting->fc_extendserver == 1){	//own
		$content .= chat_server($chatSetting,$data);
	}elseif($chatSetting->fc_extendserver == 2){	//sever
		$content .= chat_server($chatSetting,$data);
	}else{
		$content .= chat_free($chatSetting);
	}
	$sidebar = getSideBar($chatSetting);
}else{
	$content .= chat_free_nosetting();
	$sidebar = '';
}






$params = array(
	'content' => $content,
	'title' => $title,
	'filter' => '',
	'sidebar' => $sidebar
);
$body = elgg_view_layout('content', $params);
echo elgg_view_page($title, $body);
