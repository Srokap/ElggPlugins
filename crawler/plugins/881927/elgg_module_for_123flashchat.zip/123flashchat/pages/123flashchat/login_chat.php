<?php
$LOGIN_SUCCESS = 0;
$LOGIN_PASSWD_ERROR = 1;
$LOGIN_NICK_EXIST = 2;
$LOGIN_ERROR = 3;
$LOGIN_ERROR_NOUSERID = 4;
$LOGIN_SUCCESS_ADMIN = 5;
$LOGIN_NOT_ALLOW_GUEST = 6;
$LOGIN_USER_BANED = 7;

global $CONFIG;
$db_userinfo = $CONFIG->dbprefix.'users_entity';

$username = isset($_GET['username']) ? trim(rawurldecode($_GET['username'])) : '';
$password = isset($_GET['password']) ? $_GET['password'] : '';
$username = mysql_escape_string($username);
$password = mysql_escape_string($password);

if(!$username){
	echo $LOGIN_ERROR;
	exit;
}
if(!$password){
	echo $LOGIN_ERROR;
	exit;
}

$query = "SELECT name,username,password,salt,email,admin FROM $db_userinfo WHERE username = '".$username."'";
$chatSetting = get_data_row($query);
if($chatSetting){
	if($chatSetting->password == $password || $chatSetting->password == md5($password.$chatSetting->salt)){
		if($chatSetting->admin == 'yes'){
			echo $LOGIN_SUCCESS_ADMIN;
			exit;
		}else{
			echo $LOGIN_SUCCESS;
			exit;
		}
	}else{
		echo $LOGIN_PASSWD_ERROR;
		exit;
	}
}else{
	echo $LOGIN_ERROR_NOUSERID;
	exit;
}