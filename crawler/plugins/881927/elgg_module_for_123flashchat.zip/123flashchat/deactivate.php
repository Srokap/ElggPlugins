<?php
global $CONFIG;

$queryguid = "SELECT * FROM {$CONFIG->dbprefix}objects_entity WHERE title = '123flashchat'";
$chatobject = get_data_row($queryguid);

$querydelete = "DELETE FROM {$CONFIG->dbprefix}private_settings WHERE entity_guid = $chatobject->guid and name <> 'elgg:internal:priority' ";
update_data($querydelete);

