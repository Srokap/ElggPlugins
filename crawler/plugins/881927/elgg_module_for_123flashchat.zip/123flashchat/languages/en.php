<?php
/**
 * 123FlashChat English language file.
 *
 */

$english = array(
	'123flashchat' => '123FlashChat',
	'123flashchat:title' => '123 Flash Chat',
	'123flashchat:side:title' => 'Chat Info',
	'admin:123flashchat' => '123 Flash Chat',
	'admin:123flashchat:chatsetting' => 'Chat Setting',
	'admin:123flashchat:adminpanel' => 'Admin Panel',
	
);

add_translation('en', $english);
