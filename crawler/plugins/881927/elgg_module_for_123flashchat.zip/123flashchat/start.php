<?php
/**
 * Likes plugin
 *
 */

elgg_register_event_handler('init', 'system', 'flashchat_init');
function flashchat_init() {
	elgg_register_event_handler('pagesetup', 'system', 'chatconfig_setting');
	
	elgg_register_page_handler('123flashchat', 'flashchat_page_handler');
	// menus
	elgg_register_menu_item('site', array('name' => '123flashchat','text' => elgg_echo('123flashchat'),'href' => '123flashchat'));	
}
function flashchat_page_handler($page){
	$root = dirname(__FILE__);
	$page_path = "$root/pages/123flashchat";
	require_once $root.'/lib/functions.php';
	//exit($page_path);
	switch ($page[0]) {	
		case "chat":
			require_once "$page_path/123flashchat.php";
			break;
		case "login_chat":
			require_once "$page_path/login_chat.php";
		case "liveshow":
			require_once "$page_path/liveshow.php";
			break;
		default:
			require_once "$page_path/index.php";
			break;
	}
	return true;
}
function chatconfig_setting(){
	if(elgg_in_context('admin')){
		elgg_register_js('elgg.123flashchat', 'mod/123flashchat/js/chat_setting.js');
		elgg_load_js('elgg.123flashchat');
	}
}
