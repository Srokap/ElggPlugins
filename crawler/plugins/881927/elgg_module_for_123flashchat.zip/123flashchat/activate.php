<?php
global $CONFIG;

$queryguid = "SELECT * FROM {$CONFIG->dbprefix}objects_entity WHERE title = '123flashchat'";
$chatobject = get_data_row($queryguid);
$queryinsert = "INSERT INTO `{$CONFIG->dbprefix}private_settings` (`entity_guid`,`name`,`value`) VALUES 
	($chatobject->guid,'fc_extendserver','3'),
	($chatobject->guid,'fc_server_host','".$_SERVER[SERVER_NAME]."'),
	($chatobject->guid,'fc_server_port','51127'),
	($chatobject->guid,'fc_http_port','35555'),
	($chatobject->guid,'fc_client_loc','http://".$_SERVER[SERVER_NAME].":35555/'),
	($chatobject->guid,'fc_api_url','http://".$_SERVER[SERVER_NAME].":35555/'),
	($chatobject->guid,'fc_room','ELGG'),
	($chatobject->guid,'fc_client','0'),
	($chatobject->guid,'fc_room_list','1'),
	($chatobject->guid,'fc_user_list','1'),
	($chatobject->guid,'fc_popup','1'),
	($chatobject->guid,'fc_fullscreen','0'),
	($chatobject->guid,'fc_client_width','740'),
	($chatobject->guid,'fc_dis_profile','1'),
	($chatobject->guid,'fc_client_height','528'),
	($chatobject->guid,'fc_client_lang','auto'),
	($chatobject->guid,'fc_client_skin','default'),
	($chatobject->guid,'fc_comment',''),
	($chatobject->guid,'fc_group',''),
	($chatobject->guid,'fc_show_live','0'),
	($chatobject->guid,'fc_own_width','616'),
	($chatobject->guid,'fc_own_height','528'),
	($chatobject->guid,'fc_sty','default'),
	($chatobject->guid,'fc_liveurl','http://".$_SERVER[SERVER_NAME].":35555/liveshow/'),
	($chatobject->guid,'fc_liveroom','1')";
insert_data($queryinsert);

