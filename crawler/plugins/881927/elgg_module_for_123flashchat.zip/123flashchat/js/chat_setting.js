/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
function dE(id, s)
{
    var e = document.getElementById(id);
    if (!s)
    {
        s = (e.style.display == '') ? -1 : 1;
    }
    e.style.display = (s == 1) ? '' : 'none';
}

function serverChange(s)
{
    switch(s)
    {
        case "1":
            if(document.getElementById("fc_server_local").value == 1)
            {
                dE('s_host', 1);
                dE('s_port', 1);
                dE('s_http_port', 1);
            }else
            {
                dE('s_host', -1);
                dE('s_port', -1);
                dE('s_http_port', -1);
            }
            dE('s_fc', 1);
            dE('s_free', -1);
			dE('f_buy', -1);
            dE('c', 1);
            dE('s_rl', 1);
            dE('s_info', 1);
            dE('u_as_lab', 1);
            dE('u_al_lab', 1);
            dE('fc_client_skin', -1);
            dE('fc_client_lang', -1);
			dE('showlive', 1);
			dE('buy_r', -1);
			dE('buy_l', -1);
			dE('down_r', 1);
			dE('down_l', 1);
			dE('s_warn', 1);
			if(document.getElementById("show_live0").checked == true){
				dE('display_live0', -1);
				dE('display_live1', -1);
			}else{
				dE('display_live0', 1);
				dE('display_live1', 1);
			}

			var serverval = document.getElementById("serverval").value;
			var lochidden = document.getElementById("lochidden").value;
			var hidhost = document.getElementById("hidhost").value;
			var hidport = document.getElementById("hidport").value;
			var hidhttp = document.getElementById("hidhttp").value;
			if(s == serverval){
				document.getElementById("fc_client_loc").value = lochidden;
				document.getElementById("fc_server_host").value = hidhost;
				document.getElementById("fc_server_port").value = hidport;
				document.getElementById("fc_http_port").value = hidhttp;

			}else{
				document.getElementById("fc_client_loc").value = "";
				document.getElementById("fc_server_host").value = "";
				document.getElementById("fc_server_port").value = "";
				document.getElementById("fc_http_port").value = "";
			}
            changeScreen();
            break;
        case "2":
            dE('s_host', -1);
            dE('s_port', -1);
            dE('s_http_port', -1);
            dE('s_fc', 1);
            dE('s_free', -1);
			dE('f_buy', 1);
            dE('c', 1);
            dE('s_rl', 1);
            dE('s_info', -1);
            dE('u_as_lab', 1);
            dE('u_al_lab', 1);
            dE('fc_client_skin', -1);
            dE('fc_client_lang', -1);
			dE('showlive', 1);
			dE('buy_r', 1);
			dE('buy_l', 1);
			dE('down_r', -1);
			dE('down_l', -1);
			dE('s_warn', 1);
			if(document.getElementById("show_live0").checked == true){
				dE('display_live0', -1);
				dE('display_live1', -1);
			}else{
				dE('display_live0', 1);
				dE('display_live1', 1);
			}
			var serverval = document.getElementById("serverval").value;
			var lochidden = document.getElementById("lochidden").value;
			var hidhost = document.getElementById("hidhost").value;
			var hidport = document.getElementById("hidport").value;
			var hidhttp = document.getElementById("hidhttp").value;
			if(s == serverval){
				document.getElementById("fc_client_loc").value = lochidden;
				document.getElementById("fc_server_host").value = hidhost;
				document.getElementById("fc_server_port").value = hidport;
				document.getElementById("fc_http_port").value = hidhttp;
			}else{
				document.getElementById("fc_client_loc").value = "";
				document.getElementById("fc_server_host").value = "";
				document.getElementById("fc_server_port").value = "";
				document.getElementById("fc_http_port").value = "";
			}



            //            if(document.getElementById("fc_popup1").checked == true){
            //                dE('c_fullscreen', 1);
            //                document.getElementById("fc_fullscreen0").checked = true;
            //
            //            }else{
            //                dE('c_fullscreen', -1);
            //            }
            changeScreen();
            break;
        case "3":

            dE('fc_client_skin', 1);
            dE('fc_client_lang', 1);
            dE('u_as_lab', -1);
            dE('u_al_lab', -1);
            dE('s_info', -1);
            dE('s_host', -1);
            dE('s_port', -1);
            dE('s_http_port', -1);
            dE('s_fc', -1);
            dE('s_free', 1);
			dE('f_buy', -1);
            dE('c', -1);
            dE('s_rl', -1);
            document.getElementById("fc_client0").checked = true;
            dE('c_skin', 1);
            dE('c_lang', 1);
			dE('showlive', -1);
			dE('display_live0', -1);
			dE('display_live1', -1);
			dE('buy_r', -1);
			dE('buy_l', -1);
			dE('down_r', -1);
			dE('down_l', -1);
			dE('s_warn', -1);
            changeScreen();
            break;
    }
    var c = getFCClient();
    clientChange(c);
}

function clientChange(s)
{
    switch(s)
    {
        case "0":
            dE('c_skin', 1);
            dE('c_lang', 1);
            break;
        case "1":
            dE('c_skin', -1);
            dE('c_lang', -1);
            break;
        case "2":
            dE('c_skin', -1);
            dE('c_lang', 1);
            break;
    }
}

function changeScreen(){
    s = getFCServer();

    switch(s)
    {
        case "0":

            if(document.getElementById("fc_popup1").checked == true){
                dE('c_fullscreen', 1);
            }else{
                dE('c_fullscreen', -1);
                document.getElementById("fc_fullscreen0").checked = true;

            }

            break;
        case "1":
            if(document.getElementById("fc_popup1").checked == true){
                dE('c_fullscreen', 1);
            }else{
                dE('c_fullscreen', -1);
                document.getElementById("fc_fullscreen0").checked = true;
            }
            break;
        case "2":
            dE('c_fullscreen', -1);
            document.getElementById("fc_fullscreen0").checked = true;
            break;
    }


}

function getFCServer(){
    var obj = document.getElementsByName('fc_extendserver');
    var s = 3;

    if(obj!=null){
        var i;
        for(i=1;i<obj.length;i++){
            if(obj[i].checked){
                s = obj[i].value;
            }
        }
    }
    return s;
}

function getFCClient(){
    var obj = document.getElementsByName('fc_client');
    var s = 0;

    if(obj!=null){
        var i;
        for(i=0;i<obj.length;i++){
            if(obj[i].checked){
                s = obj[i].value;
            }
        }
    }
    return s;
}

function changeMode()
{
    var s = getFCServer();
    var c = getFCClient();
    clientChange(c);
    serverChange(s);
}

function setPopup(){
document.getElementById("header").style.display = "none";
document.getElementById("content").style.display = "";
document.getElementById("sidebar").style.display = "none";
}

function display_live(id){
    if(id == 0){
   		document.getElementById("display_live0").style.display = "";
   		document.getElementById("display_live1").style.display = "";
   	}else if(id == 1){
   		document.getElementById("display_live0").style.display = "none";
   		document.getElementById("display_live1").style.display = "none";
   	}
}



