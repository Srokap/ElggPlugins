<?php
/**
 * Members sidebar
 */
/**
 * Check 123 FlashChat Client Location
 * @parm $client_loc   Chat Client Location
 * @return integer config status
 */
require_once elgg_get_plugins_path().'123flashchat/lib/functions.php';
if(validate_client($vars['entity']->fc_api_url)){
     $valid = "1";   
}else{
    $valid = "0";   
}

$title = "<a href='#' id='chattitle1' style='color:#ffffff;padding:3px 10px;' onclick='chatshow(\"chatsettingdiv\",1,2);'>".elgg_echo('admin:123flashchat:chatsetting').
		"</a>  <a href='#' id='chattitle2' style='padding:3px 10px;' onclick='chatshow(\"chatsettingdiv\",2,2);'>".elgg_echo('admin:123flashchat:adminpanel')."</a>";

//$body = elgg_view_form('chatsetting', array(), array('show_admin' => true));
echo elgg_view_module('inline', $title, '');
?>

<div class="wrap" id="chatsettingdiv1">
	<table cellspacing="0" cellpadding="0" border="0" style="width:800px;padding:0 0 0 15px;">
		<tbody>
			<tr>
				<td style="width: 160px; white-space: nowrap;" colspan="2" class="forumheader3"></td>
			</tr>
			<tr>
		        <td style="width: 160px; white-space: nowrap;" rowspan="3" class="forumheader3">Chat Server Mode:</td>
		        <td style="width: 625px;" class="">
					<input type="radio" <?php if($vars['entity']->fc_extendserver == "1" ) {  echo "checked"; } ?> onclick="serverChange('1');"  name="params[fc_extendserver]" id="fc_extendserver1" value="1">Chat Server Host By Own
				</td>
			</tr>
			<tr>
				<td style="width: 625px;" class="forumheader3">
					<input type="radio" <?php if($vars['entity']->fc_extendserver == "2" ) { echo "checked"; } ?> onclick="serverChange('2');"   name="params[fc_extendserver]" id="fc_extendserver2" value="2">Chat Server Host By 123 Flash Chat
				</td>
			</tr>
			<tr>
				<td style="width: 625px;" class="forumheader3">
					<input type="radio" <?php if($vars['entity']->fc_extendserver == "3" ) { echo "checked"; } ?> onclick="serverChange('3');"  name="params[fc_extendserver]" id="fc_extendserver3" value="3">Chat Server Host By 123 Flash Chat For Free
				</td>
			</tr>
			<tr id="s_host" style="<?php if($vars['entity']->fc_extendserver != "1" || $valid == 0 ) { echo "display: none;"; } ?>">
				<td style="width: 160px; white-space: nowrap;" class="form-field form-required">Chat Server Host:</td>
				<td style="width: 625px;" class="forumheader3">
					<input type="text" size="50" value="<?php echo $vars['entity']->fc_server_host; ?>" name="params[fc_server_host]" id="fc_server_host" class="tbox" />
				</td>
			</tr>
			<tr id="s_port" style="<?php if($vars['entity']->fc_extendserver != "1" || $valid == 0 ) { echo "display: none;"; } ?>">
                <td style="width: 160px; white-space: nowrap;" class="form-field form-required">Chat Server Port:</td>
                <td style="width: 625px;" class="forumheader3">
					<input type="text" maxlength="5" size="6" value="<?php echo $vars['entity']->fc_server_port; ?>" name="params[fc_server_port]" id="fc_server_port" class="tbox" />
				</td>
			</tr>
			<tr id="s_http_port" style="<?php if($vars['entity']->fc_extendserver != "1" || $valid == 0 ) { echo "display: none;"; } ?>">
                <td style="width: 160px; white-space: nowrap;" class="form-field form-required">Chat Http Port:</td>
                <td style="width: 625px;" class="forumheader3">
					<input type="text" maxlength="5" size="6" value="<?php echo $vars['entity']->fc_http_port; ?>" name="params[fc_http_port]" id="fc_http_port" class="tbox" />
				</td>
			</tr> 
			<tr id="f_down" style="<?php if( $valid == 0 ) { echo "display: none;"; } ?>">
		        <td id="down_r" style="<?php if($vars['entity']->fc_extendserver != "1") { echo "display: none;"; } ?> width: 160px; white-space: nowrap;" class="description"></td>
		        <td id="down_l" style="<?php if($vars['entity']->fc_extendserver != "1") { echo "display: none;"; } ?> width: 625px;" class="description">Note*: Please install 123FlashChat Server first before enable this Mod.<a href="http://www.123flashchat.com/download-now.html?p=123flashchat.exe" target="_blank" >Free Download </a></td>
		    </tr>
		    <tr id="f_buy">
		        <td id="buy_r" style="<?php if($vars['entity']->fc_extendserver != "2") { echo "display: none;"; } ?> width: 160px; white-space: nowrap;" class="description"></td>
		        <td id="buy_l" style="<?php if($vars['entity']->fc_extendserver != "2") { echo "display: none;"; } ?> width: 625px;" class="description"> 123FlashChat Hosting Service start at $30. <a href="http://www.123flashchat.com/host.html" target="_blank">Buy Now</a></td>
		    </tr>
		    <tr id="s_warn" style="<?php if($vars['entity']->fc_extendserver == "3" ) { echo "display: none;"; } ?>">
				<td style="width: 160px; white-space: nowrap;" class="form-field form-required">Integration URL:</td>
				<td style="width: 625px;" class="forumheader3">
					To integrate users for auto-login to chat, please open the Chat Admin Panel,
					then System Settings > Integration Panel, set authentication URL to:
					<span style="color:red;">http://&lt;Your elgg root URL&gt;/123flashchat/login_chat?username=%username%&password=%password%</span><br />
					<br />
				</td>
			</tr>
			<tr id="s_info" style="<?php if($vars['entity']->fc_extendserver != "1" ) { echo "display: none;"; } ?>">
				<td style="width: 160px; white-space: nowrap;" class="description"></td>
				<td style="width: 625px;" class="description">It is highly recommended to copy the chat client folder and files to your web server to reduce chat server load. For example, copy &lt;123flashchat server installed directory&gt;/client/ to //chat/, and configure "Chat Client Location" to http://www.yourdomain.com/chat/(i.e., //chat/) accordingly.</td>
			</tr>			
			<tr id="s_fc" style="<?php if($vars['entity']->fc_extendserver == "3" ) { echo "display: none;"; } ?>" >
                <td style="width: 160px; white-space: nowrap;" class="form-field form-required">Chat Client Location:</td>
                <td style="width: 625px;" class="forumheader3">
					<input type="text" size="50" value="<?php echo $vars['entity']->fc_client_loc; ?>" name="params[fc_client_loc]" id="fc_client_loc" class="tbox" />
				</td>
			</tr>
			<tr id="s_free" style="<?php if($vars['entity']->fc_extendserver != "3" ) { echo "display: none;"; } ?>">
                <td style="width: 160px; white-space: nowrap;" class="form-field form-required">Chat Room:</td>
                <td style="width: 625px;" class="forumheader3">
					<input type="text" size="50" value="<?php echo $vars['entity']->fc_room; ?>" name="params[fc_room]" id="fc_room" class="tbox" /></td>
			</tr>
			<tr id="s_rl" style="<?php if($vars['entity']->fc_extendserver == "3" ) echo "display: none;";?>">
                <td style="width: 160px; white-space: nowrap;" class="form-field form-required">Show rooms list:</td>
                <td style="width: 625px;" class="forumheader3">
					<input type="radio" name="params[fc_room_list]" value="1" <?php if($vars['entity']->fc_room_list == 1){echo 'checked="checked"';} ?> >Yes
			    	<input type="radio" name="params[fc_room_list]" value="0" <?php if($vars['entity']->fc_room_list == 0){echo 'checked="checked"';} ?> >No
				</td>
			</tr>
			<tr>
                <td style="width: 160px; white-space: nowrap;" class="form-field form-required">Show users list:</td>
                <td style="width: 625px;" class="forumheader3">
					<input type="radio" name="params[fc_user_list]" value="1" <?php if($vars['entity']->fc_user_list == 1){echo 'checked="checked"';} ?> >Yes
			    	<input type="radio" name="params[fc_user_list]" value="0" <?php if($vars['entity']->fc_user_list == 0){echo 'checked="checked"';} ?> >No
				</td>
			</tr>
			<tr id="c" style="<?php if($vars['entity']->fc_extendserver == "3" ) echo "display: none;";?>">
				<td style="width: 160px; white-space: nowrap;" class="form-field form-required">Chat Client Mode:</td>
				<td style="width: 625px;" class="forumheader3">
					<input type="radio" onclick="clientChange('0');" <?php if($vars['entity']->fc_client == "0") echo "checked"; ?> name="params[fc_client]" id="fc_client0" value="0">Standard Chat
					<input type="radio" onclick="clientChange('1');" <?php if($vars['entity']->fc_client == "1") echo "checked"; ?> name="params[fc_client]" id="fc_client1" value="1">Html Chat
					<input type="radio" onclick="clientChange('2');" <?php if($vars['entity']->fc_client == "2") echo "checked"; ?> name="params[fc_client]" id="fc_client2" value="2">Avatar Chat</td>
			</tr>
			<tr style="display:none;">
				<td style="width: 160px; white-space: nowrap;" class="form-field form-required">Popup mode:</td>
				<td style="width: 625px;" class="forumheader3">
					<input type="checkbox" onclick="changeScreen();" checked name="params[fc_popup]" id="fc_popup1" value="1"></td>
			</tr>
			<tr>
				<td style="width: 160px; white-space: nowrap;" class="form-field form-required">Chat Client Size:</td>
				<td style="width: 625px;" class="forumheader3">
					<input type="radio" name="params[fc_fullscreen]" <?php if($vars['entity']->fc_fullscreen == "0") echo "checked"; ?> id="fc_fullscreen0" value="0" />Width:
					<input type="text" maxlength="5" size="6" value="<?php echo $vars['entity']->fc_client_width; ?>" name="params[fc_client_width]" id="fc_client_width" class="tbox" />Height:
					<input type="text" maxlength="5" size="6" value="<?php echo $vars['entity']->fc_client_height; ?>" name="params[fc_client_height]" id="fc_client_height" class="tbox" />
				</td>
			</tr>
			<tr id="c_fullscreen" style="<?php if($vars['entity']->fc_popup == "0" || $vars['entity']->fc_extendserver == "3" ) echo "display: none;";?>">
				<td style="width: 160px; white-space: nowrap;" class="forumheader3"></td>
				<td style="width: 625px;" class="forumheader3">
					<input type="radio" <?php if($vars['entity']->fc_fullscreen == "1") echo "checked"; ?> name="params[fc_fullscreen]" id="fc_fullscreen1" value="1">Full Screen</td>
			</tr>
			<tr id="c_lang" style="<?php if($vars['entity']->fc_client == "1" ) echo "display: none;";?>">
				<td style="width: 160px; white-space: nowrap;" class="form-field form-required">Chat Client Language:</td>
				<td style="width: 625px;" class="forumheader3">
					<select class="tbox" name="params[fc_client_lang]" id="fc_client_lang" style="<?php if($vars['entity']->fc_extendserver != "3" ) echo "display: none;";?>">
						<option value="auto" <?php if($vars['entity']->fc_client_lang == "auto") echo "selected"; ?>  >Auto detect</option>
						<option value="en" <?php if($vars['entity']->fc_client_lang == "en") echo "selected"; ?> >English</option>
						<option value="zh-CN" <?php if($vars['entity']->fc_client_lang == "zh-CN") echo "selected"; ?> >GB Chinese</option>
						<option value="zh-TW" <?php if($vars['entity']->fc_client_lang == "zh-TW") echo "selected"; ?> >Big5 Chinese</option>
						<option value="fr" <?php if($vars['entity']->fc_client_lang == "fr") echo "selected"; ?> >French</option>
						<option value="it" <?php if($vars['entity']->fc_client_lang == "it") echo "selected"; ?> >Italian</option>
						<option value="de" <?php if($vars['entity']->fc_client_lang == "de") echo "selected"; ?> >German</option>
						<option value="nl" <?php if($vars['entity']->fc_client_lang == "nl") echo "selected"; ?> >Dutch</option>
						<option value="hu" <?php if($vars['entity']->fc_client_lang == "hu") echo "selected"; ?> >Hungarian</option>
						<option value="es" <?php if($vars['entity']->fc_client_lang == "es") echo "selected"; ?> >Spanish</option>
						<option value="hr" <?php if($vars['entity']->fc_client_lang == "hr") echo "selected"; ?> >Croatian</option>
						<option value="tr" <?php if($vars['entity']->fc_client_lang == "tr") echo "selected"; ?> >Turkish</option>
						<option value="ar" <?php if($vars['entity']->fc_client_lang == "ar") echo "selected"; ?> >Arabic</option>
						<option value="pt" <?php if($vars['entity']->fc_client_lang == "pt") echo "selected"; ?> >Portuguese</option>
						<option value="ru" <?php if($vars['entity']->fc_client_lang == "ru") echo "selected"; ?> >Russian</option>
						<option value="ko" <?php if($vars['entity']->fc_client_lang == "ko") echo "selected"; ?> >Korean</option>
						<option value="serbian" <?php if($vars['entity']->fc_client_lang == "serbian") echo "selected"; ?> >Serbian</option>
						<option value="no" <?php if($vars['entity']->fc_client_lang == "no") echo "selected"; ?> >Norwegian</option>
						<option value="ja" <?php if($vars['entity']->fc_client_lang == "ja") echo "selected"; ?> >Japanese</option>
					</select>
					<span id="u_al_lab" class="description" style="<?php if($vars['entity']->fc_extendserver == "3" ) echo "display: none;";?>">Note: You can set the language in 123FlashChat Admin Panel -&gt; Client Setting -&gt; Language Setting</span>
				</td>
			</tr>
			<tr id="c_skin" style="<?php if($vars['entity']->fc_client != "0" ) echo "display: none;";?>">
				<td style="width: 160px; white-space: nowrap;" class="form-field form-required">Chat Client Skin:</td>
				<td style="width: 625px;" class="forumheader3">
					<select class="tbox" name="params[fc_client_skin]" id="fc_client_skin" style="<?php if($vars['entity']->fc_extendserver != "3" ) echo "display: none;";?>">
						<option value="default"  <?php if($vars['entity']->fc_client_skin == "default") echo "selected"; ?> >Default</option>
						<option value="green" <?php if($vars['entity']->fc_client_skin == "green") echo "selected"; ?> >Green</option>
						<option value="orange" <?php if($vars['entity']->fc_client_skin == "orange") echo "selected"; ?> >Orange</option>
						<option value="red" <?php if($vars['entity']->fc_client_skin == "red") echo "selected"; ?> >Red</option>
						<option value="black" <?php if($vars['entity']->fc_client_skin == "black") echo "selected"; ?> >Black</option>
						<option value="beige" <?php if($vars['entity']->fc_client_skin == "beige") echo "selected"; ?> >Beige</option>
						<option value="standard" <?php if($vars['entity']->fc_client_skin == "standard") echo "selected"; ?> >Standard</option>
						<option value="clean" <?php if($vars['entity']->fc_client_skin == "clean") echo "selected"; ?> >Clean</option>
						<option value="artistic" <?php if($vars['entity']->fc_client_skin == "artistic") echo "selected"; ?> >Artistic</option>
					</select>
					<span id="u_as_lab" class="description" style="<?php if($vars['entity']->fc_extendserver == "3" ) echo "display: none;";?>" >Note: You can set the skin in 123FlashChat Admin Panel -&gt; Client Setting -&gt; Skin</span>
				</td>
			</tr>
			<!-- live show -->
		  	<tr id="showlive" style="<?php if($vars['entity']->fc_extendserver == "3" ) echo "display: none;";?>">
		  		<td style="width: 160px; white-space: nowrap;" class="form-field form-required">
					<span class="editlinktip hasTip">Show Live Show Chat:</span>
				</td>
		    	<td style="width: 625px;" class="forumheader3">
			   		<input type="radio" class="radio" name="params[fc_show_live]" id="show_live1" value="1" onclick="display_live(0)" <?php if($vars['entity']->fc_show_live == 1){echo 'checked="checked"';} ?> >Yes
			    	<input type="radio" class="radio" name="params[fc_show_live]" id="show_live0" value="0" onclick="display_live(1)" <?php if($vars['entity']->fc_show_live == 0){echo 'checked="checked"';} ?> >No
			   	</td>
			</tr>
			<tr id="display_live0" <?php if($vars['entity']->fc_show_live == 0 || $vars['entity']->fc_extendserver == "3"){echo 'style="display:none"';}?>>
				<td style="width: 160px; white-space: nowrap;" class="form-field form-required">
					<span class="editlinktip hasTip">Live Show Chat Skin:</span>
				</td>
				<td style="width: 625px;" class="forumheader3">
	        		<select name="params[fc_sty]" id="sel_c_lang_3" tabindex="1" class="bginput">
	            		<option value="default" <?php if($vars['entity']->fc_sty == "default"){ echo 'selected="selected"';} ?>>default</option>
	            		<option value="bubble" <?php if($vars['entity']->fc_sty == "bubble"){ echo 'selected="selected"';} ?>>bubble</option>
			       		<option value="orkut" <?php if($vars['entity']->fc_sty == "orkut"){ echo 'selected="selected"';} ?>>orkut</option>
			       		<option value="point_rect" <?php  if($vars['entity']->fc_sty == "point_rect"){ echo 'selected="selected"';} ?>>point_rect</option>
			       		<option value="point_line" <?php if($vars['entity']->fc_sty == "point_line"){ echo 'selected="selected"';} ?>>point_line</option>
			       		<option value="gradient_rect" <?php  if($vars['entity']->fc_sty == "gradient_rect"){ echo 'selected="selected"';} ?>>gradient_rect</option>
			       		<option value="serene" <?php if($vars['entity']->fc_sty == "serene"){ echo 'selected="selected"';} ?>>serene</option>
	           		</select>
				</td>
			</tr>
			<tr id="display_live1" <?php if($vars['entity']->fc_show_live == 0 || $vars['entity']->fc_extendserver == "3"){echo 'style="display:none"';}?>>
				<td style="width: 160px; white-space: nowrap;" class="form-field form-required">
					<span class="editlinktip hasTip">Live Show Room:</span>
				</td>
		        <td style="width: 625px;" class="forumheader3">
	               	<select name="params[fc_liveroom]" id="sel_c_lang_3" tabindex="1" class="bginput">
			       		<option value="1"  <?php if($vars['entity']->fc_liveroom == "1"){ echo 'selected="selected"';} ?>>Default Room</option>
			           	<option value="2"  <?php if($vars['entity']->fc_liveroom  == "2"){ echo 'selected="selected"';}?>>Multimedia Room</option>
			           	<option value="3"  <?php if($vars['entity']->fc_liveroom  == "3"){ echo 'selected="selected"';} ?>>Vedio/Audio Chat Room</option>
			           	<option value="6"  <?php if($vars['entity']->fc_liveroom  == "6"){ echo 'selected="selected"';} ?>>Moderated-chat Module Test</option>
			           	<option value="7"  <?php if($vars['entity']->fc_liveroom  == "7"){ echo 'selected="selected"';} ?>>Event Chat Module Test</option>
			           	<option value="8"  <?php if($vars['entity']->fc_liveroom  == "8"){ echo 'selected="selected"';} ?>>Cafe(avatar chat demo)</option>
			           	<option value="9"  <?php if($vars['entity']->fc_liveroom  == "9"){ echo 'selected="selected"';} ?>>Game room(avatar chat demo)</option>
			           	<option value="10"  <?php if($vars['entity']->fc_liveroom  == "10"){ echo 'selected="selected"';} ?>>Hetel(avatar chat demo)</option>
						<option value="11"  <?php if($vars['entity']->fc_liveroom  == "11"){ echo 'selected="selected"';} ?>>Park(avatar chat demo)</option>
			           	<option value="12"  <?php if($vars['entity']->fc_liveroom  == "12"){ echo 'selected="selected"';} ?>>Restaurant(avatar chat demo)</option>
	               	</select>
				</td>
			</tr>
			<!-- end live show -->
			<!-- show profile setting -->
			<tr>
				<td style="width: 160px; white-space: nowrap;" class="form-field form-required">Show Profile Setting:</td>
				<td style="width: 625px;" class="forumheader3">
					<input type="radio" name="params[fc_dis_profile]" value="1" <?php if($vars['entity']->fc_dis_profile == 1){echo 'checked="checked"';} ?> >Yes
			    	<input type="radio" name="params[fc_dis_profile]" value="0" <?php if($vars['entity']->fc_dis_profile == 0){echo 'checked="checked"';} ?> >No
			   	</td>
			</tr>
			<!-- end profile setting -->
		</tbody>
	</table>
	<input type="hidden" value="<?php echo $vars['entity']->fc_group; ?>" name="params[fc_group]" id="fc_group">
	<input type="hidden" value="<?php echo $vars['entity']->fc_api_url; ?>" name="params[fc_api_url]" id="fc_api_url">
	<input type="hidden" value="<?php echo $vars['entity']->fc_server_host; ?>" name="hidhost" id="hidhost">
	<input type="hidden" value="<?php echo $vars['entity']->fc_server_port; ?>" name="hidport" id="hidport">
	<input type="hidden" value="<?php echo $vars['entity']->fc_http_port; ?>" name="hidhttp" id="hidhttp">
	<input type="hidden" value="<?php echo $vars['entity']->fc_extendserver; ?>" name="serverval" id="serverval">
	<input type="hidden" value="<?php echo $vars['entity']->fc_client_loc;  ?>" name="lochidden" id="lochidden">
	<input type="hidden" value="<?php echo $valid; ?>" name="fc_server_local" id="fc_server_local">
	<input type="hidden" value="<?php echo $vars['entity']->fc_liveurl; ?>" name="params[fc_liveurl]" id="fc_liveurl">
<?php echo elgg_view("input/button",array(
			'value' => 'save',
			'onclick' => 'chat_checkform();',
			'class' => ' elgg-button-submit '
		)); 
?>
</div>

<div id="chatsettingdiv2" style="display:none;">
	<div style="text-align:center;">
<?php if( $vars['entity']->fc_extendserver == '3' ){ ?>
		<p>Sorry! Admin Panel is not available in the Free Chat Hosting Edition. 123FlashChat Full Version starts at $30. <br />Click the link below to have a live Admin Panel Demo for testing.</p>
		<p><a href="http://www.123flashchat.com/admin-panel-free.html" target="_blank">Live Demo</a></p>
<?php }else{ 
		$url =  $vars['entity']->fc_client_loc . "admin_123flashchat.swf?init_host=" . $vars['entity']->fc_server_host . "&init_port=" . $vars['entity']->fc_server_port . (($vars['entity']->fc_extendserver == "2") ? ("&init_group=" . $vars['entity']->fc_group) : "");
?>
		<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,19,0" width="700" height="528">
			<param name=movie value="<?php echo $url; ?>">
			<param name=quality value="high">
			<param name="menu" value="false">
			<embed src="<?php echo $url; ?>" quality="high" menu="false" width="700" height="528" type="application/x-shockwave-flash" pluginspace="http://www.macromedia.com/go/getflashplayer"></embed>
		</object>
<?php } ?>
	</div>
</div>
<style>
	.elgg-foot .elgg-button-submit{
		display:none;
	}
</style>
<script>
	function chatshow(str,id,num){
		for(var i=1; i<=num; i++){
			$("#"+str+i).hide();
			$("#chattitle"+i).css('color','#333333');
		}
		$("#"+str+id).show();
		$("#chattitle"+id).css('color','#ffffff');
	}
	function chat_checkform(){
		var message = '';
		if($("input:[name='params[fc_extendserver]']:checked").val() == 3){
			if($.trim($("#fc_room").val()) == ''){
				$("#fc_room").val('<?php echo $_SERVER[HTTP_HOST]; ?>');
				//message += 'Chat Room name should not be null.';
			}			
		}else{
			if($("input:[name='params[fc_extendserver]']:checked").val() == 1){
				if($("#fc_server_host").val() == ''){
					$("#fc_server_host").val("<?php echo str_ireplace('http://', '', $_SERVER[SERVER_NAME]); ?>");
				}
				if($("#fc_server_host").val() != '127.0.0.1' && $("#fc_server_host").val() != 'localhost'){					
				}else{
					$("#fc_server_host").val("<?php echo $_SERVER[HTTP_HOST]; ?>");
				}
				if($("#fc_server_port").val() == ''){
					$("#fc_server_port").val('51127');
				}
				if($("#fc_http_port").val() == ''){
					$("#fc_http_port").val('35555');
				}
				$("#fc_api_url").val('http://'+$("#fc_server_host").val()+':'+$("#fc_http_port").val()+'/');
				if($("#fc_client_loc").val() == ''){
					$("#fc_client_loc").val($("#fc_api_url").val());
				}
				$("#fc_liveurl").val($("#fc_client_loc").val()+'liveshow/');
			}else if($("input:[name='params[fc_extendserver]']:checked").val() == 2){
				if($("#fc_client_loc").val() != ''){
					var client_location = $("#fc_client_loc").val().split("/");
					$("#fc_api_url").val('http://'+client_location[2]+'/');
					$("#fc_group").val(client_location[3]);
					$("#fc_server_host").val(client_location[2]);
					$("#fc_server_port").val('21127');
					$("#fc_liveurl").val($("#fc_client_loc").val()+'liveshow/');
				}
				if($("#fc_group").val() == ''){
					message += 'Chat Client Location is not right.';
				}
			}
			//alert($("#fc_client_loc").val()=='');
			//alert($("input:[name='params[fc_extendserver]']:checked").val());
			if($("#fc_client_loc").val() == ''){
				message += 'Chat Client Location should not be null.';
			}
			
		}
		if(!isNaN($("#fc_client_width").val()) && !isNaN($("#fc_client_height").val())){
		}else{
			if(message == ''){
				message += 'Chat Client Size:Width and Height can only be number.';
			}else{
				message += '<br />Chat Client Size:Width and Height can only be number.';
			}
			
		}
		if(message){
			//$(".elgg-page-messages > ul.elgg-system-messages").append('hellooo');
			$(".elgg-page-messages > ul.elgg-system-messages").html('<li class="elgg-message elgg-state-error" style="opacity: 1;">'+
					'<p>'+message+'</p></li>');
		}else{
			$(".elgg-foot > .elgg-button-submit").click();
		}
	}
</script>

 