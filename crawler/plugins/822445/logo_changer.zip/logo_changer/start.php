<?php
/*
 * plugin created by imoni.
 * This will change the topbar logo and logo link.
 * This will use .png image file for logo.
 *
 */
 
elgg_register_event_handler('init', 'system', 'custom_logo');

function custom_logo()
{
    elgg_unregister_menu_item('topbar', 'elgg_logo');
	
	$site_url = elgg_get_site_url();
	$logo_url = elgg_get_site_url() . "/mod/logo_changer/_graphics/logo.png";
	
	elgg_register_menu_item('topbar', array(
		'name' => 'elgg_logo',
		'href' => "$site_url",
		'text' => "<img src=\"$logo_url\" alt=\"Elgg logo\" width=\"38\" height=\"20\" />",
		'priority' => 1,
		'link_class' => 'elgg-topbar-logo',
	));
}
?>