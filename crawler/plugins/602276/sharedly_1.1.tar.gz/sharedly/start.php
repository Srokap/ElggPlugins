<?php
/**
 * A plugin to share links on an Elgg site
 *
 * @package FnxtSharedly
 * @author Shyam Somanadh
 * @author Frontiernxt
 * @link http://frontiernxt.com/
 */


    function sharedly_init(){
	
		global $CONFIG;

		// Clean URLs are a must!
		register_page_handler('sharedly','sharedly_page_handler');

		// A link for the menu bar!
		add_menu(elgg_echo('sharedly:menu:sharedly'), $CONFIG->wwwroot . 'pg/sharedly/');

		//The main CSS file for styling
		extend_view('css','sharedly/css');

		//Fire up the sub menus
		register_elgg_event_handler('pagesetup','system','sharedly_submenus');

		//Register the add action
		register_action('sharedly/action_add', false, $CONFIG->pluginspath.'sharedly/actions/add.php');
		
		//Register the delete action
		register_action('sharedly/action_delete', false, $CONFIG->pluginspath.'sharedly/actions/delete.php');

		//Register the edit action		
		register_action('sharedly/action_edit', false, $CONFIG->pluginspath.'sharedly/actions/edit.php');		
		
		//Point to the function that will generate the links when $entity->geturl() is called
		register_entity_url_handler('sharedly_url','object','sharedly');
		
		//Register a notification object for others to subscribe to
		if (is_callable('register_notification_object'))
			register_notification_object('object','sharedly',elgg_echo('sharedly:new'));

		// Respond to notification listeners
		register_plugin_hook('notify:entity:message', 'object', 'sharedly_notify_message');

		
		//Register our entity type
		register_entity_type('object','sharedly');
		
		
		return true;
	}


	
	//Function to define how the entity URLs are generated
	$share = get_entity(get_input('entity_guid'));

	function sharedly_url($share) {
		
		global $CONFIG;
		$title = $share->title;
		$title = friendly_title($title);
		return $CONFIG->url . "pg/sharedly/view/".$share->getGUID()."/".friendly_title($share->title);
		
	}



	//Map the URL segments to methods and IDs

	function sharedly_page_handler($page)
	{
		global $CONFIG;
	

		$controller  = strtolower($page[0]);
		$param1 =  strtolower($page[1]);
		$param2 =  strtolower($page[2]);		
		$param3 =  strtolower($page[3]);				
		

		switch($controller){
		
			case 'view':

				//set id from second element on the URL if it is set and if it is a number. 
				//Object validation will happen in controller
			
				if((int)$param1){
				set_input('id',$param1);
				include $CONFIG->pluginspath . 'sharedly/pages/view.php';
				}
			
			
				//file to load for the /view/popular link
				elseif(strtolower($param1) == 'popular'){

				include $CONFIG->pluginspath . 'sharedly/pages/popular.php';

				}


				//if nothing is set in second element, load all items, this will be handled by the controller
				else{

				include $CONFIG->pluginspath . 'sharedly/pages/view.php';	
				}
				break;
			
			
			case 'add':
				include $CONFIG->pluginspath . 'sharedly/pages/add.php';
				break;
				
			case 'edit':
			
				if((int)$param1){
				set_input('id',$param1);
				include $CONFIG->pluginspath . 'sharedly/pages/edit.php';
				}
				else{
					register_error(elgg_echo('sharedly:error:invalidedit'));
					forward($_SERVER['HTTP_REFERER']);
				}
				
				break;								

			case 'action_edit':
				include $CONFIG->pluginspath . 'sharedly/actions/edit.php';
				break;

			case 'action_add':
				include $CONFIG->pluginspath . 'sharedly/actions/add.php';
				break;
				
			case 'action_delete':
				set_input('id',$param1);
				include $CONFIG->pluginspath . 'sharedly/actions/delete.php';
				break;				
				
			case 'voteinfo':
				if((int)$param1){
				set_input('id',$param1);
				include $CONFIG->pluginspath . 'sharedly/pages/voteinfo.php';
				}
				break;				

			case 'popular':
				include $CONFIG->pluginspath . 'sharedly/pages/popular.php';
				break;

			case 'show':
				if($param1 == 'user' && !empty($param2)){
					set_input('user',$param2);
					include $CONFIG->pluginspath . 'sharedly/pages/user.php';
				}
				elseif($param1 == 'friends'){
					include $CONFIG->pluginspath . 'sharedly/pages/friends.php';
				}
				else{
					include $CONFIG->pluginspath . 'sharedly/pages/view.php';
				}
				break;

			default:
				include $CONFIG->pluginspath . 'sharedly/pages/view.php';
				break;
				
				
		}
		
		
		return true;
	}


	//Function to set up the sub menus

	function sharedly_submenus()
	{
		global $CONFIG;

		
		if (get_context() == 'sharedly')
		{
			add_submenu_item(elgg_echo('sharedly:submenu:showall'), $CONFIG->wwwroot . 'pg/sharedly/');
			add_submenu_item(elgg_echo('sharedly:submenu:add'), $CONFIG->wwwroot . 'pg/sharedly/add/');			
		}
		
	}
	
	
	//Code for the notification handler

	function sharedly_notify_message($hook, $entity_type, $returnvalue, $params)
	{
		$entity = $params['entity'];
		$to_entity = $params['to_entity'];
		$method = $params['method'];
		if (($entity instanceof ElggEntity) && ($entity->getSubtype() == 'sharedly'))
		{
			$descr = $entity->description;
			$title = $entity->title;

			if ($method == 'email') {
				$owner = $entity->getOwnerEntity();
				return $owner->name . ' posted a link: ' . $title . "\n\n" . $descr . "\n\n" . $entity->getURL();
			}
			if ($method == 'site') {
				$owner = $entity->getOwnerEntity();
				return $owner->name . ' posted a link: ' . $title . "\n\n" . $descr . "\n\n" . $entity->getURL();
			}			
			
		}
		return null;
	}



	
	
	
	
	//Function that shows the vote widget, using the updown plugin
	
	function sharedly_display_vote_widget($entity, $context){
		
		if(is_plugin_enabled('updown')){
			
			if($context == 'entity'){

				$updown = elgg_view('input/updown', array('entity'=> $entity));

			}
			
			if($context == 'list'){

				$updown = elgg_view('input/updown', array('entity'=> $entity));

			}			
			
			
			
		}
		
		else
		
		$updown = FALSE;
		
		return $updown;
		
	}
	
	
	//Function to do a quick version check to x.x
	
	function sharedly_version_check(){
		
		
		$version = get_version($humanreadable=true);
		return $matched = substr($version, 0,3);
		
		
	}
	

	
	//Function to show items as a list. Wrapper for both 1.7 and 1.6
	function sharedly_list_items($options){
		
		$matched = sharedly_version_check();
		
		if($matched == '1.6'){
			
							
		return list_entities($type= $options['type'], $subtype=$options['subtype'], $owner_guid=$options['owner_guid'], $limit=$options['limit'], $fullview=$options['full_view'], $viewtypetoggle=$options['view_type_toggle'], $pagination=$options['pagination']);
							
			
		}
		

		if($matched == '1.7'){

			
		return elgg_list_entities($options);
			
		}
		
		
	}
	
	//Function to show latest items links. Wrapper for both 1.7 and 1.6
	
	function sharedly_render_latest_block($options){
		
		$matched = sharedly_version_check();
		$links = '';
		
		if($matched == '1.7'){
			
			
			$entities = elgg_get_entities($options);
			foreach($entities as $entity){
				
				$entity_url = $entity->geturl();
				$links .= "&raquo <a href=\"$entity_url\">$entity->title</a><br>";
			}
			
			return $links;
			
		}
		
		if($matched == '1.6'){
			

			$entities = get_entities($type=$options['type'], $subtype=$options['subtype'], $owner_guid=$options['owner_guid'], $order_by="", $limit=$options['limit'], $offset=$options['offset'], $count=false, $site_guid=0, $container_guid=null, $timelower=0, $timeupper=0);
			foreach($entities as $entity){
				
				$entity_url = $entity->geturl();
				$links .= "&raquo <a href=\"$entity_url\">$entity->title</a><br>";
			}
			
			return $links;
		}		
		
	}
	
	
	//Function to show top items as a list. Need to provide option to use the 'like' module here, along with updown
	
	
	function sharedly_render_top_links_block(){
		
		$entities = get_entities_from_annotation_count ($entity_type="object", $entity_subtype="sharedly", $name="generic_updown", $mdname= '', $mdvalue= '', $owner_guid=0, $limit=10, $offset=0, $orderdir= 'desc', $count=false);
		
			foreach($entities as $entity){
				
				$entity_url = $entity->geturl();
				$links .= "&raquo <a href=\"$entity_url\">$entity->title</a><br>";
			}
			
			return $links;
		
	}
	

	//function to render items shared by links. 
	
	function sharedly_list_friends_items($origin_user_id){

		return list_user_friends_objects($origin_user_id,'sharedly',10,false);
		
	}
	
	//function to show more links by a user
	
	function sharedly_render_user_links_block($user){
		
		$matched = sharedly_version_check();
		$links = '';
		$options = array('type' => "object",
						'subtype' => "sharedly",
						'owner_guid' => $user,
						'limit' => 5,
						'full_view' => FALSE,
						'view_type_toggle' => FALSE,
						'pagination' => TRUE,
						);

		
		
		if($matched == '1.7'){
			
			
			$entities = elgg_get_entities($options);
			foreach($entities as $entity){
				
				$entity_url = $entity->geturl();
				$links .= "&raquo <a href=\"$entity_url\">$entity->title</a><br>";
			}
			
			return $links;
			
		}
		
		
		if($matched == '1.6'){
			

			$entities = get_entities($type=$options['type'], $subtype=$options['subtype'], $owner_guid=$options['owner_guid'], $order_by="", $limit=$options['limit'], $offset=$options['offset'], $count=false, $site_guid=0, $container_guid=null, $timelower=0, $timeupper=0);
			foreach($entities as $entity){
				
				$entity_url = $entity->geturl();
				$links .= "&raquo <a href=\"$entity_url\">$entity->title</a><br>";
			}
			
			return $links;
		}
		
	}


	
	register_elgg_event_handler('init', 'system', 'sharedly_init');
?>