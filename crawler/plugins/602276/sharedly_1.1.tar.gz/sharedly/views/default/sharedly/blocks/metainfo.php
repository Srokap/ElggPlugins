<div class="sharedlyMenuTitleLeft"><?php echo elgg_echo('sharedly:blocktitle:iteminfo')?></div>

<?php

$entity = $vars['share'];
$owner = $entity->getOwnerEntity();
$date =	date("F j, Y",$entity->time_created).'<br>';
$owner_link = '<a href="'.$owner->geturl().'">'.$owner->name.'</a>';

$gid = $entity->guid;
$gid = 'objid'.$gid;



if(is_plugin_enabled('updown')){
$limit = 3;	
$votes = $entity->getAnnotations ($name = 'generic_updown', $limit, $offset=0, $order="desc");
$votedetail = '';
$morelink = '';
$upvote = '';
$downvote = '';
$latestvote = '';



	if($entity->countAnnotations($name="generic_updown") > $limit){

		//$morelink = '<a href="'.$CONFIG->wwwroot.'pg/sharedly/voteinfo/'.$entity->guid.'">';
		$latestvote = '<a href="'.$CONFIG->wwwroot.'pg/sharedly/voteinfo/'.$entity->guid.'">Show all Votes</a>';
	}
	
	$upvote = 0;
	$downvote = 0;
	
	$votedetail = "<b>Latest Votes</b><br>";
	
	foreach($votes as $vote){
		$voter = get_entity($vote->owner_guid);

		//$votedetail .= $voter->name.'<br>';
		
		if($vote->value == 1){
			
			$upvote++;
			$vote_value = '+';
		}
		
		if($vote->value == -1){
			
			$downvote++;
			$vote_value = '-';
		}
		
	$votedetail .= '<a href="'.$voter->geturl().'">'.$voter->name.'</a> ('.$vote_value.')<br>';	
	
	}
	
	$upvote = "<b>Upvotes: </b>$upvote<br>";
	$downvote = "<b>Downvotes: </b>$downvote<br>";
	$votedetail .= $morelink;


}

echo "<b>Added by: </b>$owner_link<br><b>On:</b> $date$upvote$downvote$votedetail$latestvote";



?>

<?php 

if($entity->tags)
echo '<b>'.elgg_echo('sharedly:tags_label').':</b> '.elgg_view('output/tags', array('tags' => $entity->tags)); 

?>
<div class="clearfloat"></div>