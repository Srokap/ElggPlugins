<?php


$url = $_SESSION['sharedly']->url;
$title = $_SESSION['sharedly']->title;
$description = $_SESSION['sharedly']->description;
$tags = $_SESSION['sharedly']->tags;




/*
$_SESSION['sharedly']->url
$_SESSION['sharedly']->title
$_SESSION['sharedly']->description
$_SESSION['sharedly']->tags
*/

$form_body = '<label>'.elgg_echo('sharedly:url_label').'</label>';
$form_body .= elgg_view('input/text', array('internalname' => 'url', 'value' => $url));
$form_body .= '<label>'.elgg_echo('sharedly:title_label').'</label>';
$form_body .= elgg_view('input/text', array('internalname' => 'title', 'value' => $title));
$form_body .= '<label>'.elgg_echo('sharedly:description_label').'</label>';
$form_body .= elgg_view('input/longtext', array('internalname' => 'description', 'value' => $description));
$form_body .= '<label>'.elgg_echo('sharedly:tags_label').'</label>';
$form_body .= elgg_view('input/tags',array('internalname' => 'tags', 'value' => $tags));
$form_body .= elgg_view('input/submit', array('internalname' => 'submit', 'value' => 'Submit'));
 
echo elgg_view('input/form', array('body' => $form_body, 'action' => "{$CONFIG->url}pg/sharedly/action_add"));


?>