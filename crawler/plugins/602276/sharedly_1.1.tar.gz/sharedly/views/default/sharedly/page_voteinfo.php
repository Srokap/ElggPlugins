<div class="contentWrapper">
<?php

$entity = $vars['entity'];

$votes = $entity->getAnnotations ($name = 'generic_updown', $limit=99999999, $offset=0, $order="desc");
foreach($votes as $vote){
	
	
	if($vote->value === 1){
		
		$vote_value = ' +';
	}

	if($vote->value === -1){
		
		$vote_value = ' -';
	}

	$voter = get_entity($vote->owner_guid);
	$votedetail .= '<a href="'.$voter->geturl().'">'.$voter->name.'</a>'.$vote_value.'<br>';

	

}

echo $votedetail;

?>

</div>