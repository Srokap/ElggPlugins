<?php


//var_export($vars['share']);

$share = $vars['share'];

?>

 
<div class="contentWrapper">


<p><H1><a href="<?php echo $share->url;?>"><?php echo $share->title; ?></a></H1></p>

	<?php 




	if($share->embledly){

		echo $share->embledlyEmbed;
		echo '<br>Link: '.$share->url;

	}
	
	else{

		echo $share->url;
		
	}


	?>

 
<p><?php echo $share->description; ?></p>

 
<?php echo elgg_view('output/tags', array('tags' => $share->tags)); ?>

</div>
<?php 
echo "<br>Comments<hr><br>".elgg_view_comments($share);	

?>