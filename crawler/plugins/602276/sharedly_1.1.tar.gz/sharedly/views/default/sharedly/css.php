/* canvas layout: 2 column left sidebar */
#sharedly_left_sidebar {
	width:200px;
	margin:0 20px 0 10px;
	min-height:360px;
	float:left;

	padding-left:2px;
	border-top:1px solid #cccccc;	
	border-bottom:1px solid #cccccc;
	border-right:1px solid #cccccc;
	border-left:1px solid #cccccc;	
}

#sharedly_maincontent {
	width:540px;
	margin:0;
	min-height: 360px;
	float:left;
	padding:0 0 5px 0;
	-webkit-border-radius: 1px;
	-moz-border-radius: 1px;
}

#sharedly_right_sidebar {
	width:160px;
	margin-left:10px;
	min-height: 360px;
	float:left;
	
	/*text-indent: 12px; */
	padding:0 0 5px 2px;
	border-right:1px solid #cccccc;		
	border-top:1px solid #cccccc;
	border-bottom:1px solid #cccccc;
	border-left:1px solid #cccccc;	
}

.sharedlyMenuTitleLeft{
	background-color: #575757;
	text-align: center;
	color: #fcfff9;
	font-size: 12px;
	font-weight: bold;
	padding:2px;
	
}

.sharedlyMenuTitleRight{
	background-color: #575757;
	text-align: center;
	color: #fcfff9;
	font-size: 12px;
	font-weight: bold;
	
}


.river_object_sharedly_comment{
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_comment.gif) no-repeat left -1px;
}

.river_object_sharedly_create {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_pages.gif) no-repeat left -1px;
}
	
	
	
	
}