<div class="sharedlyMenuTitleLeft"><?php echo elgg_echo('sharedly:navtitle:morebyuser').$vars['name'];?></div>

<?php 

	
	echo sharedly_render_user_links_block($vars['user'])


;?>