<?php 

	if(is_plugin_enabled('updown')){


	echo '<div class="sharedlyMenuTitleRight">'.elgg_echo('sharedly:blocktitle:top').'</div>';
//	echo "<hr>".elgg_echo('sharedly:blocktitle:top')."<hr>";

	echo sharedly_render_top_links_block();
	}	


;?>