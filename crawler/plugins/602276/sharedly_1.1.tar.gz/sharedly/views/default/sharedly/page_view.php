<?php


//var_export($vars['share']);

$share = $vars['share'];
$owner = $share->getOwnerEntity();
$date =	date("F j, Y",$share->time_created);
?>

 
<div class="contentWrapper">


<p><H1><a href="<?php echo $share->url;?>"><?php echo $share->title; ?></a></H1></p>

			<!--	<p><?php echo elgg_echo('sharedly:by_label'); ?> <a href="<?php echo $owner->geturl(); ?>"><?php echo $owner->name; ?></a> on <?php echo $date;?></p> -->


	<?php 
	
	
	echo '<p>'.sharedly_display_vote_widget($share, $context='entity').'</p>';



	if($share->embledly){

		echo $share->embledlyEmbed;
		//echo '<br>'.elgg_echo('sharedly:link_label').': <a href="'.$share->url.'">'.$share->url.'</a>';
		echo elgg_echo('sharedly:link_label').': '.elgg_view('output/url', array('value' => $share->url, 'target' => '_blank'));

	}
	
	else{

		//echo elgg_echo('sharedly:link_label').': <a href="'.$share->url.'">'.$share->url.'</a>';
		echo elgg_echo('sharedly:link_label').': '.elgg_view('output/url', array('value' => $share->url, 'target' => '_blank'));
		
	}


	?>

 
<br><?php echo elgg_echo('sharedly:description_label').': '.$share->description; ?>

<br><?php 


if($share->canEdit()){
	
	echo '<a href="'.$CONFIG->wwwroot.'pg/sharedly/edit/'.$share->guid.'">'.elgg_echo('sharedly:edit_link').'</a>';
	
	 $ts = time();
	 $token = generate_action_token($ts);
	 $action_gatekeeper = "&__elgg_token=$token&__elgg_ts=$ts";
	
	$delurl = $CONFIG->wwwroot.'pg/sharedly/action_delete/'.$share->guid.$action_gatekeeper;
	
	echo " | ".elgg_view('output/confirmlink', array('text' => elgg_echo('sharedly:delete_link'), 'href' => $delurl, 'confirm' => elgg_echo('sharedly:confirm_delete_link')));
}

?>

</div>
<?php 

if(elgg_count_comments($share)){

echo "<h4>&nbsp;&nbsp;&nbsp;&nbsp;Comments</h4>";	
	
}
echo elgg_view_comments($share);	

?>