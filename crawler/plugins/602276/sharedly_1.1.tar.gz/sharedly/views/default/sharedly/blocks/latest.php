<div class="sharedlyMenuTitleRight"><?php echo elgg_echo('sharedly:blocktitle:latest')?></div>

<?php


$options = array('type' => 'object',
				 'subtype' => 'sharedly',
				'owner_guid' => 0,
			 	'limit' => 10,
		 		'offset' => 0);


echo sharedly_render_latest_block($options);





?>

