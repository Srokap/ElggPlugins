

<div class="sharedlyMenuTitleLeft"><?php echo elgg_echo('sharedly:navtitle:sharedlymenu')?></div>


<b><a href="<?php echo $CONFIG->wwwroot .'pg/sharedly/';?>"><?php echo elgg_echo('sharedly:submenu:showall')?></a></b>

<?php $user = get_loggedin_user();?>

<br><b><a href="<?php echo $CONFIG->wwwroot .'pg/sharedly/show/user/'.$user->username;?>"><?php echo elgg_echo('sharedly:submenu:showyours')?></a></b>

<br><b><a href="<?php echo $CONFIG->wwwroot .'pg/sharedly/show/friends/';?>"><?php echo elgg_echo('sharedly:submenu:showfriends')?></a></b>

<?php if(is_plugin_enabled('updown')){ ?>
<br><b><a href="<?php echo $CONFIG->wwwroot .'pg/sharedly/popular';?>"><?php echo elgg_echo('sharedly:submenu:showpopular')?></a></b>
<?php }?>

<br><b><a href="<?php echo $CONFIG->wwwroot .'pg/sharedly/add';?>"><?php echo elgg_echo('sharedly:submenu:add')?></a></b>