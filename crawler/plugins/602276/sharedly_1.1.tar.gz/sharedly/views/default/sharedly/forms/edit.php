	<?php


	if(!$entity = get_entity(get_input('id'))){

		register_error(elgg_echo('sharedly:error:invalidedit'));
		forward($_SERVER['HTTP_REFERER']);

	}

	else{
	
	if(!$entity->canEdit()){
		register_error(elgg_echo('sharedly:error:editpermissionfail'));
		forward($_SERVER['HTTP_REFERER']);
	}
	
	
	$formreturn = $_SESSION['sharedly']->formreturn;
	
	
	if($formreturn){
	
	$url = $_SESSION['sharedly']->url;
	$guid = $_SESSION['sharedly']->guid;
	$title = $_SESSION['sharedly']->title;
	$description = $_SESSION['sharedly']->description;
	$tags = $_SESSION['sharedly']->tags;
	}

	else{
	$guid = $entity->guid;
	$url = $entity->url;
	$title = $entity->title;
	$description = $entity->description;
	$tags = $entity->tags;
	}

	$form_body = '<label>'.elgg_echo('sharedly:url_label').'</label>';
	$form_body .= elgg_view('input/hidden', array('internalname' => 'guid', 'value' => $guid));
	$form_body .= elgg_view('input/text', array('internalname' => 'url', 'value' => $url));
	$form_body .= '<label>'.elgg_echo('sharedly:title_label').'</label>';
	$form_body .= elgg_view('input/text', array('internalname' => 'title', 'value' => $title));
	$form_body .= '<label>'.elgg_echo('sharedly:description_label').'</label>';
	$form_body .= elgg_view('input/longtext', array('internalname' => 'description', 'value' => $description));
	$form_body .= '<label>'.elgg_echo('sharedly:tags_label').'</label>';
	$form_body .= elgg_view('input/tags',array('internalname' => 'tags', 'value' => $tags));
	$form_body .= elgg_view('input/submit', array('internalname' => 'submit', 'value' => 'Submit'));
 
	echo elgg_view('input/form', array('body' => $form_body, 'action' => "{$CONFIG->url}pg/sharedly/action_edit"));

	}
	?>