<?php
/**
 * Elgg 2 column left sidebar canvas layout
 *
 * @package Elgg
 * @subpackage Core
 * @author Curverider Ltd
 * @link http://elgg.org/
 */
?>

<!-- Add pagination here -->

<!-- sharedly_left_sidebar -->
<div id="sharedly_left_sidebar">


<?php if (isset($vars['area4'])) echo $vars['area4']; ?>

<?php if (isset($vars['area5'])) echo $vars['area5']; ?>


</div><!-- /sharedly_left_sidebar -->

<!-- main sharedly_maincontent -->
<div id="sharedly_maincontent">

<?php if (isset($vars['area1'])) echo $vars['area1']; ?>

</div><!-- /sharedly_maincontent -->


<!-- /sharedly_right_sidebar -->
<div id="sharedly_right_sidebar">

<?php if (isset($vars['area2'])) echo $vars['area2']; ?>

<?php if (isset($vars['area3'])) echo $vars['area3']; ?>


</div><!-- /sharedly_right_sidebar -->
