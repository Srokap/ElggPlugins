<?php


//var_export($vars['share']);

$share = $vars['entity'];
$owner = $share->getOwnerEntity();
$date =	date("F j, Y",$share->time_created);
?>

 
<div class="contentWrapper">


<p><H1><a href="<?php echo $share->geturl();?>"><?php echo $share->title; ?></a></H1></p>


				<p><?php echo elgg_echo('sharedly:by_label'); ?> <a href="<?php echo $owner->geturl(); ?>"><?php echo $owner->name; ?></a> on <?php echo $date;?></p>


	<?php 


 	//echo elgg_view("profile/icon",array('entity' => $owner, 'size' => 'tiny'));	
	
		echo '<p>'.sharedly_display_vote_widget($share, $context='list').'</p>';


	if($share->embledly){

		echo $share->embledlyEmbed;
		echo elgg_echo('sharedly:link_label').': '.elgg_view('output/url', array('value' => $share->url, 'target' => '_blank'));

	}
	
	else{


		echo elgg_echo('sharedly:link_label').': '.elgg_view('output/url', array('value' => $share->url, 'target' => '_blank'));
		
	}


	?>

<br><?php echo elgg_echo('sharedly:description_label').': '.$share->description; ?>

<?php echo elgg_echo('sharedly:tags_label').': '.elgg_view('output/tags', array('tags' => $share->tags)); ?>


<br><?php echo '<a href="'.$share->geturl().'#commentstart">'.elgg_echo('sharedly:commentscount_label')." (".elgg_count_comments($share).")</a>"; ?>

<br><?php 


if($share->canEdit()){
	
	echo '<a href="'.$CONFIG->wwwroot.'pg/sharedly/edit/'.$share->guid.'">'.elgg_echo('sharedly:edit_link').'</a>';
	
	 $ts = time();
	 $token = generate_action_token($ts);
	 $action_gatekeeper = "&__elgg_token=$token&__elgg_ts=$ts";
	
	$delurl = $CONFIG->wwwroot.'pg/sharedly/action_delete/'.$share->guid.$action_gatekeeper;
	
	echo " | ".elgg_view('output/confirmlink', array('text' => elgg_echo('sharedly:delete_link'), 'href' => $delurl, 'confirm' => elgg_echo('sharedly:confirm_delete_link')));
}

?>

</div>
<?php 




if (isset($vars['full']) && $vars['full'] == true){

	echo "<br>Comments<hr><br>".elgg_view_comments($share);	
	
	}

?>