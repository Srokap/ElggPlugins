<?php

	// must be logged in
	gatekeeper();
	
	// must have security token 
	action_gatekeeper();
	
	// get parameters that were posted
	$guid = get_input('id');
	
	if($entity = get_entity($guid) ){
		
		if($entity->getSubtype() =='sharedly' && $entity->canEdit()){
			
			$entity->delete();
			system_message(elgg_echo('sharedly:deletesuccess'));
			forward($CONFIG->wwwroot.'pg/sharedly');
			
		}
		
		else{
			
			register_error(elgg_echo('sharedly:error:editpermissionfail'));
			forward();
		
		}
		
	}
	
	else{
		register_error(elgg_echo('sharedly:error:invalidentity'));
		forward();		
	}
	
	
?>