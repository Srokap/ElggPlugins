<?php

	// must be logged in
	gatekeeper();
	
	// must have security token 
	action_gatekeeper();

	// get parameters that were posted and shove them into the session
	$_SESSION['sharedly']->url = $url = get_input('url');
	$_SESSION['sharedly']->title = $title = get_input('title');		
	$_SESSION['sharedly']->description = $description = get_input('description');
	$_SESSION['sharedly']->tags = $tags = get_input('tags');
	
	//Check for empty required variables

	//if(empty($url) || empty($title) || empty($description)){
	if(empty($url) || empty($title)){		
		
		register_error(elgg_echo('sharedly:error:emptyfields'));
		forward($_SERVER['HTTP_REFERER']);
	}
	
	
	//check if the link is an URL indeed
	
	if(preg_match("#((http|https|ftp)://(\S*?\.\S*?))(\s|\;|\)|\]|\[|\{|\}|,|\"|'|:|\<|$|\.\s)#ie", $url, $matches))

	{

		//see if it is one of the shared.ly providers
		
		$url = $matches[1];
		$maxwidth = '500';
		$maxheight = '800';
		$format = 'json';
		$request = "http://api.embed.ly/v1/api/oembed?url=$url&maxwidth=$maxwidth&maxheight=$maxheight&format=$format";

		$handle = fopen($request, "rb");
		$contents = stream_get_contents($handle);
		fclose($handle);


		
		$embed = json_decode($contents);
		
	  // spawn a new Elgg object
	  $sharedly = new ElggObject();
	  $sharedly->title = $title;
 	  $sharedly->url = $url;	
	  $sharedly->description = $description;
	  $sharedly->subtype = "sharedly";
	  $sharedly->access_id = ACCESS_PUBLIC;
	  $sharedly->owner_guid = get_loggedin_userid();
	  $sharedly->tags = string_to_tag_array($tags);





		
				if($embed){
		
					$sharedly->embledly = TRUE;
					$sharedly->embledlyTitle =  $embed->{'title'};
					$sharedly->embledlyDescription =  $embed->{'description'};					
					$sharedly->embledlyEmbed =  $embed->{'html'};				
			
				}
		
		
				else{
			
			
					$sharedly->embledly = FALSE;
			
			
				}	
		
		
	  $sharedly->save();
	
	//flush the cookies
	unset($_SESSION['sharedly']->url, $_SESSION['sharedly']->title, $_SESSION['sharedly']->description, $_SESSION['sharedly']->tags);


	  system_message(elgg_echo('sharedly:success'));
	  add_to_river('river/object/sharedly/create','create',$_SESSION['user']->guid,$sharedly->guid);
	  forward($sharedly->getURL());		
				
				
		
		/* Available fields from embedly API
		provider_url
		description
		title
		url
		type
		html
		author_name
		
		height
		width
		thumbnail_width
		provider_name
		thumbnail_url
		thumbnail_height
		author_url
		
		
		*/
		
		
		
	}	
	
	
	
	else{
		
		register_error(elgg_echo('sharedly:error:urlfailure'));
		forward($_SERVER['HTTP_REFERER']);
		
		
	}
	
?>