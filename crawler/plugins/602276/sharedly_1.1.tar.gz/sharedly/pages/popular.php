<?php

	// include the Elgg engine
	include_once dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php"; 

	// maybe logged in users only?
	gatekeeper();
	

	
	// if username or owner_guid was not set as input variable, we need to set page owner
	// Get the current page's owner
	$page_owner = page_owner_entity();
	if (!$page_owner) {
		$page_owner_guid = get_loggedin_userid();
		if ($page_owner_guid)
			set_page_owner($page_owner_guid);
	}	
	
	
	$body = list_entities_from_annotation_count ($entity_type="object", $entity_subtype="sharedly", $name="generic_updown", $limit=10, $owner_guid=0, $group_guid=0, $asc=false, $fullview=false, $viewtypetoggle=false, $pagination=true, $orderdir= 'desc');


	$maincontent = elgg_view_title(elgg_echo('sharedly:pagetitle:popular'));
	$maincontent .= $body;
	
	$featured_block = elgg_view('sharedly/blocks/featured_block', '');
	$topusers = elgg_view('sharedly/blocks/top_users', '');
	$toplinks = elgg_view('sharedly/blocks/top_links', '');
	$latest = elgg_view('sharedly/blocks/latest','');
	$owner_block = elgg_view('sharedly/blocks/owner_block','');
	$rightpanel = $latest.$topusers.$toplinks;
	
	$html = elgg_view_layout('sharedly_three_columns', $area1 = $maincontent, $area2 = $featured_block, $area3 = $rightpanel, $area4= $metainfo, $area5 = $owner_block);	

	// create the complete html page and send to browser
	page_draw($title, $html);
?>