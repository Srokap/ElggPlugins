<?php

	// include the Elgg engine
	include_once dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php"; 

	// maybe logged in users only?
	gatekeeper();
	
	// if username or owner_guid was not set as input variable, we need to set page owner
	// Get the current page's owner
	$page_owner = page_owner_entity();
	if (!$page_owner) {
		$page_owner_guid = get_loggedin_userid();
		if ($page_owner_guid)
			set_page_owner($page_owner_guid);
	}	

	$id = get_input('id');
	$entity = get_entity($id);
	
	if(!$entity instanceof ElggEntity){
	register_error(elgg_echo('sharedly:error:invalidentity'));
	forward($_SERVER['HTTP_REFERER']);
	}

	$title = elgg_echo('sharedly:pagetitle:voteinfo').": ".$entity->title;
	
	// create content for main column
	$content = elgg_view_title($title);
	$content .= elgg_view('sharedly/page_voteinfo', array('entity' => $entity));
	
	$metainfo = elgg_view('sharedly/blocks/metainfo', array('share' => $entity));	
	$leftpanel = $metainfo;
	
	$featured_block = elgg_view('sharedly/blocks/featured_block', '');
	$toplinks = elgg_view('sharedly/blocks/top_links', '');
	$latest = elgg_view('sharedly/blocks/latest','');		
	$rightpanel = $latest.$topusers.$toplinks;	

	
	$html = elgg_view_layout('sharedly_three_columns', $area1 = $content, $area2 = $featured_block, $area3 = $rightpanel, $area4= $leftpanel, $area5 = $latest);

	// create the complete html page and send to browser
	page_draw($title, $html);	
	
?>