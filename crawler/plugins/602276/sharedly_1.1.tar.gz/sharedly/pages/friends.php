<?php

	// include the Elgg engine
	include_once dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php"; 

	// maybe logged in users only?
	gatekeeper();
	
	
	$origin_user_id = get_loggedin_userid();		
	$body = sharedly_list_friends_items($origin_user_id);
	
	
	$maincontent = elgg_view_title(elgg_echo('sharedly:pagetitle:byfriends'));
	$owner_block = elgg_view('sharedly/blocks/owner_block','');

	
	$maincontent .= $body;
	
	$featured_block = elgg_view('sharedly/blocks/featured_block', '');
	$topusers = elgg_view('sharedly/blocks/top_users', '');
	$toplinks = elgg_view('sharedly/blocks/top_links', '');
	$latest = elgg_view('sharedly/blocks/latest','');		
	$rightpanel = $latest.$topusers.$toplinks;

	
	$html = elgg_view_layout('sharedly_three_columns', $area1 = $maincontent, $area2 = $featured_block, $area3 = $rightpanel, $area4= $leftpanel, $area5 = $owner_block);	

	// create the complete html page and send to browser
	page_draw($title, $html);
?>