<?php

update_subtype('object', 'phloor_favicon');
