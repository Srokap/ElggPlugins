<?php

$french = array(
"phloor_custom_favicon" => "phloorFavicon",
'admin:appearance:phloor_custom_favicon' => "Favicon",

'phloor_custom_favicon:title' => "Téléchargement favicon",

'phloor_custom_favicon:description' => "Téléchargement d'une coutume favicon pour votre site. Admis mimetypes sont 'image/gif', 'image/jpg', 'image/jpeg', 'image/pjpeg' et 'image/png'. ",

'phloor_custom_favicon:save:success' => "Paramètres enregistrés avec succès.",
'phloor_custom_favicon:save:failure' => "Paramètres pourrait ne pas être sauvegardées.",

'phloor_custom_favicon:form:section:favicon' => "Favicon",

'phloor_custom_favicon:image:label' => "Téléchargement d'une coutume favicon",

'phloor_custom_favicon:image:description' => "Sélectionnez le fichier que vous souhaitez définir comme site favicon. Afin de s'intégrer dans la section en-tête envisager la hauteur et la largeur de l'image.",

'phloor_custom_favicon:delete_image:label' => "Supprimez favicon",
'phloor_custom_favicon:delete_image:description' => "Si vous cochez cette case, le favicon seront supprimés.",

);

add_translation("fr", $french);

