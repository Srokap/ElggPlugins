<?php

$dutch = array(
	"phloor_custom_favicon" => "phloorFavicon",
	'admin:appearance:phloor_custom_favicon' => 'Favicon',

	'phloor_custom_favicon:title' => "Upload favicon",

	'phloor_custom_favicon:description' => "Upload je eigen favicon voor je site. Toegestane mimetypes zijn 'image/gif', 'image/jpg', 'image/jpeg', 'image/pjpeg' en 'image/png'. ",

	'phloor_custom_favicon:save:success' => 'Settings succesvol opgeslagen.',
	'phloor_custom_favicon:save:failure' => 'Settings konden niet opgeslagen worden.',

	'phloor_custom_favicon:form:section:favicon' => 'Favicon',

	'phloor_custom_favicon:image:label' => 'Upload je favicon',
	'phloor_custom_favicon:image:description' => 'Selecteer je favicon. Denk om de breedte en de hoogte. ',

	'phloor_custom_favicon:delete_image:label' => 'Verwijder favicon',
	'phloor_custom_favicon:delete_image:description' => 'Bij het selecteren van deze optie word je favicon verwijderd. ',

);

add_translation("nl", $dutch);
