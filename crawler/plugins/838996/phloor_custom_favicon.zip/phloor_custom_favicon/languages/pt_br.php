<?php

// Gerado pela extensão 'translationbrowser'  20111122-09:57:08 PM

$portugues_brasileiro = array(
	"phloor_custom_favicon" => "phloorFavicon",
	 'admin:appearance:phloor_custom_favicon'  =>  "Favicon" ,
	 'phloor_custom_favicon:title'  =>  "Enviar favicon" ,
	 'phloor_custom_favicon:description'  =>  "Envie para o seu site um favicon personalizado. Mimetypes permitidos são 'image/gif', 'image/jpg', 'image/jpeg', 'image/pjpeg' e 'image/png'. ",
	 'phloor_custom_favicon:save:success'  =>  "Configurações salvas com sucesso." ,
	 'phloor_custom_favicon:save:failure'  =>  "Configurações não puderam ser salvas." ,
	 'phloor_custom_favicon:form:section:favicon'  =>  "Favicon" ,
	 'phloor_custom_favicon:image:label'  =>  "Envie seu favicon" ,
	 'phloor_custom_favicon:image:description'  =>  "Selecione o arquivo que você gostaria de definir como o favicon do site. " ,
	 'phloor_custom_favicon:delete_image:label'  =>  "Remover favicon" ,
	 'phloor_custom_favicon:delete_image:description'  =>  "Marque esta caixa para remover o favicon." ,
);

add_translation('pt_br', $portugues_brasileiro);

