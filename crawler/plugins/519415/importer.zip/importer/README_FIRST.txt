Disclaimer: Contacts importer plugin for Elgg 1.0 is provided as is. I am not liable for any damage whatsoever that may occur due to your use of this plugin

. drsanupmoideen@gmail.com, Www.webgalli.com