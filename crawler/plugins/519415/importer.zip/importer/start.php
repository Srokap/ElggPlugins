<?php

	/**
	 * Elgg Contacts importer plugin
	 * This plugin allows users to import contacts from email providers and social networks
	 * 
	 * @package Elgg Contacts importer
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @author Dr. Sanu P Moideen <drsanupmoideen@gmail.com>
	 * @copyright Team Webgalli Ltd 2008
	 * @copyright Dr. Sanu P Moideen @ webgalli.com 2008
	 * @link http://webgalli.com/ && http://m4medicine.com/
	 */
	 
	 global $CONFIG;
	 	 	
	// Register a page handler, so we can have nice URLs
		register_page_handler('importer','importer_page_handler');
	
	// Page handler
		function importer_page_handler($page) {
			global $CONFIG;
			include($CONFIG->pluginspath . "importer/index.php");
		}
		
	// Load menu
			// Check the current Context
		if (get_context() == "friends" || 
			get_context() == "friendsof" || 
			get_context() == "collections") {

if (isloggedin()) {
		add_submenu_item(elgg_echo('Import your Contacts'),$CONFIG->wwwroot."pg/importer");
		}
		}
?>