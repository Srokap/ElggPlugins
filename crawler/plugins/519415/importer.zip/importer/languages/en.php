<?php

	/**
	 * Elgg Contacts importer plugin
	 * This plugin allows users to import contacts from email providers and social networks
	 * 
	 * @package Elgg Contacts importer
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @author Dr. Sanu P Moideen <drsanupmoideen@gmail.com>
	 * @copyright Team Webgalli Ltd 2008
	 * @copyright Dr. Sanu P Moideen @ webgalli.com 2008
	 * @link http://webgalli.com/ && http://m4medicine.com/
	 */
		
		$english = array(
	
		/**
		 * Plugin button, menu title, page title, 
		 */
	
			'importer:plugin:name' => "Contacts Importer",
			'importer:page:title' => "Import your contacts",			
			

	);
					
	add_translation("en",$english);

?>