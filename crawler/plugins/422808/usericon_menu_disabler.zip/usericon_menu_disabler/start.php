<?php

	/**
	 * Elgg User icon menu Disabler
	 * 
	 * @package ElggUserIconMenuDisabler
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
	 * @copyright (C) Sergio De Falco 2010
	 * @link http://www.gonk.it/
	 */
	 
    function usericon_menu_disabler_init() {
	
        // Extend system CSS with our own styles
			extend_view('css','usericon_menu_disabler/css');

    }

    // Make sure the User icon menu Disabler initialisation function is called on initialisation
		    register_elgg_event_handler('init','system','usericon_menu_disabler_init');

?>