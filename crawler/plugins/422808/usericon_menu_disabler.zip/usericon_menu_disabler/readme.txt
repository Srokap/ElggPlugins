/**
* Elgg User icon menu Disabler
* 
* @package ElggUserIconMenuDisabler
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
* @copyright (C) Sergio De Falco 2010
* @link http://www.gonk.it/
*/

Features:

Don't you like the menu appearing clicking on every user icon? then you have to install this plugin.

Installation:

- Copy user_icon_menu_disabler into the "mod" directory
- Go to the Site Tools
- Order the user_icon_menu_disabler after the Profile plugin
- Enable the user_icon_menu_disabler plugin