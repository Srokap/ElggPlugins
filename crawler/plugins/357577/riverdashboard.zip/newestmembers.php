<?php

	/**
	 * Elgg thewire view page
	 * 
	 * @package ElggTheWire
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider <info@elgg.com>
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 * 
	 */

	$newest_members = get_entities_from_metadata('icontime', '', 'user', '', 0, 18);

    //the page owner
	$owner = get_user($vars['entity']->owner_guid);

	$size_value = "tiny";
	
	$groups = get_entities_from_relationship('member', $_SESSION['user']->getGUID(), false, "group", "", 0, "", 9999, 0, false, 0);
	
	$friends = get_entities_from_relationship('friend',$_SESSION['user']->getGUID(), false,'user','', 0, "", 9999);				
	
?>

<div class="sidebarBox">
<h3><?php echo elgg_echo('riverdashboard:recentmembers') ?></h3>
<div class="membersWrapper"><br />
<?php 
	foreach($newest_members as $mem){
		echo "<div class=\"recentMember\">" . elgg_view("profile/icon",array('entity' => $mem, 'size' => 'tiny')) . "</div>";
	}
	?>
<div class="clearfloat"></div>
</div>
</div>

<div class="sidebarBox">
<h3><?php echo elgg_echo('friends') ?></h3>
<div class="membersWrapper"><br />
<?php 
		foreach($friends as $friend) {
		echo "<div class=\"recentMember\">";
		echo elgg_view("profile/icon",array('entity' => get_user($friend->guid), 'size' => $size_value));
		echo "</div>";
		}
	?>
<div class="clearfloat"></div>
</div>
</div>

<div class="sidebarBox">
<h3><?php echo elgg_echo('groups:widget:membership') ?></h3>
<div class="membersWrapper"><br />
<?php 
		echo "<div class=\"groupmembershipwidget\">";

		foreach($groups as $group){
			$icon = elgg_view(
				"groups/icon", array(
									'entity' => $group,
									'size' => 'small',
								  )
				);
				
			echo "<div class=\"contentWrapper\">" . $icon . " <div class='search_listing_info'><p><span>" . $group->name . "</span>";
			echo "</p></div><div class=\"clearfloat\"></div></div>";
			
		}
		echo "</div>";
		
	?>
<div class="clearfloat"></div>
</div>
</div>
