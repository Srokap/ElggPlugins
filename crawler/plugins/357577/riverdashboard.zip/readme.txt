Riverdashboard modification ( new panels: Friends, Group membership )

Replace the newestmembers.php file with the one in this directory: mod/riverdashboard/views/default/riverdashboard/
Backup old one

Enjoy
David Levinsky