<?php
/**
 * Blog English language file.
 *
 */

$english = array(
	'group_chat' => 'Group Chat',
	'group_chat:setting' => 'Number of day\'s history',
);

add_translation('en', $english);
