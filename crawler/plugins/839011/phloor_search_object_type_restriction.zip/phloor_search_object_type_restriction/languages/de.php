<?php
/*****************************************************************************
 * Phloor Search Object Type Restriction                                     *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php
/**
 * Phloor Search Object Type Restrcition Language File
 * German
 */

$german = array(
	'phloor_search_object_type_restriction' => 'Search Type Restriction',

	'phloor_search_object_type_restriction:form:description' =>
	'Hier können Sie die Einstellungen zur Einschränkung der Anzeige von bestimmten Objekt-Typen als Suchergebnisse vornehmen. Die Einstellung ist individuell für Gäste und eingeloggte Mitglieder. Die Suche eines Administrators kann nicht eingeschränkt werden. ',

	'phloor_search_object_type_restriction:save:success' => 'Einstellungen erfolgreich gespeichert',
	'phloor_search_object_type_restriction:save:failure' => 'Einstellungen konnten nicht gespeichert werden',

	'menu:page:header:search' => 'Suche',
	'admin:restrictions' => 'Einschränkungen',
	'admin:restrictions:phloor_search_object_type_restriction' => 'Objekt-Typen',

	'phloor_search_object_type_restriction:form:section:search' => 'Sucheinstellugen',
	'phloor_search_object_type_restriction:form:section:guest' => 'Einstellung für Gäste',
	'phloor_search_object_type_restriction:form:section:user' => 'Einstellung für angemeldete Mitglieder',

	'phloor_search_object_type_restriction:guest_allowed_object_types:description' => '',
	'phloor_search_object_type_restriction:guest_allowed_object_types:label' => 'Wählen Sie die Objekte, die für Gäste in der Suche SICHTBAR sein sollen. ',


	'phloor_search_object_type_restriction:user_allowed_object_types:description' => '',
	'phloor_search_object_type_restriction:user_allowed_object_types:label' => 'Wählen Sie die Objekte, die für angemeldete Mitglieder in der Suche SICHTBAR sein sollen. ',
);

add_translation('de', $german);
