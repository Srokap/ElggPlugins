<?php
/*****************************************************************************
 * Phloor Search Object Type Restriction                                     *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php
/**
 * Phloor Search Object Type Restrcition Language File
 * English
 */

$english = array(
	'phloor_search_object_type_restriction' => 'Search Type Restriction',

	'phloor_search_object_type_restriction:form:description' =>
	'Here you can change the settings for blocking certain objects from being displayed on the search result page. There are individual setups for guest and logged in users. The search results of an administrator will not be restricted. ',

	'phloor_search_object_type_restriction:save:success' => 'Settings successfully saved',
	'phloor_search_object_type_restriction:save:failure' => 'Settings could not be saved',

	'menu:page:header:search' => 'Search',
	'admin:restrictions' => 'Restrictions',
	'admin:restrictions:phloor_search_object_type_restriction' => 'Object Types',

	'phloor_search_object_type_restriction:form:section:search' => 'Search Settings',
	'phloor_search_object_type_restriction:form:section:guest' => 'Guest Settings',
	'phloor_search_object_type_restriction:form:section:user' => 'User Settings',

	'phloor_search_object_type_restriction:guest_allowed_object_types:description' => '',
	'phloor_search_object_type_restriction:guest_allowed_object_types:label' => 'Choose the object types that ARE DISPLAYED in a search result for guests',


	'phloor_search_object_type_restriction:user_allowed_object_types:description' => '',
	'phloor_search_object_type_restriction:user_allowed_object_types:label' => 'Choose the object types that ARE DISPLAYED in a search result for logged in users',
);

add_translation('en', $english);
