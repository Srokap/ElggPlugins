<?php
/*****************************************************************************
 * Phloor Search Object Type Restriction                                     *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php

elgg_register_event_handler('init', 'system', 'phloor_search_object_type_restriction_init');

/**
 *
 */
function phloor_search_object_type_restriction_init() {

	/**
	 * LIBRARY
	 * register a library of helper functions
	 */
	$lib_path = elgg_get_plugins_path() . 'phloor_search_object_type_restriction/lib';
	elgg_register_library('phloor-search-object-type-restriction-lib', "$lib_path/phloor_search_object_type_restriction.lib.php");
	elgg_load_library('phloor-search-object-type-restriction-lib');

	/**
	 * Plugin Hooks
	 */
	elgg_register_plugin_hook_handler('search', 'all', 'phloor_search_object_type_restriction_plugin_hook', 999);

	/**
	 * Actions
	 */
	$action_path = elgg_get_plugins_path() . 'phloor_search_object_type_restriction/actions/phloor_search_object_type_restriction';
	elgg_register_action('phloor_search_object_type_restriction/save', "$action_path/save.php", 'admin');

	/**
	 * Admin Menu
	 */
	//elgg_register_admin_menu_item('appearance', 'phloor_search_object_type_restriction', 'restrictions' , 500);
	elgg_register_admin_menu_item('search', 'phloor_search_object_type_restriction', 'restrictions' , 500);
}

/**
 * Plugin hook for restricting (blocking) certain
 * types or subtypes from being displayed in on
 * the search result page.
 *
 * @param unknown_type $hook
 * @param unknown_type $types
 * @param unknown_type $returnvalue
 * @param unknown_type $params
 */
function phloor_search_object_type_restriction_plugin_hook($hook, $types, $returnvalue, $params) {
	// admin is unrestricted
	if(elgg_is_admin_logged_in()) {
		return $returnvalue;
	}
	$site = elgg_get_site_entity();

	// get the allowed types for the search based on logged in state
	$section = !elgg_is_logged_in() ? 'guest' : 'user';

	$type = $params['type']; // type of the specific objects
	$subtype = $params['subtype']; // subptype of the specific objects

	// get settings
	$allowed_types = phloor_search_object_type_restriction_prepare_vars($site);

	// build key for array
	$key = empty($subtype) ? "$section:$type" : "$section:$type:$subtype";

	// check if the type is in allowed array
	if(!isset($allowed_types[$key])) {
		// block displaying if not!
		return false;
	}

 	return $returnvalue;
}


