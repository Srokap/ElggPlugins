<?php
/*****************************************************************************
 * Phloor Search Object Type Restriction                                     *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php
/**
 * Checkboxes with all object types/subtypes
 */
$value = elgg_extract('value', $vars, array());
$name  = elgg_extract('name',  $vars, '');

$options = array();

if (is_array($value)) {
	$values = array_map('elgg_strtolower', $value);
} else {
	$values = array(elgg_strtolower($value));
}

$types = get_registered_entity_types();
foreach($types as $type => $subtypes) {
	// add type
	$key = "$name:$type";
	$options[$key] = array(
		'name'  => $key,
	 	'value' => 'false',
        'label' =>  elgg_echo("item:$type"),
	);

	// add its subtypes
	if(is_array($subtypes) && count($subtypes) > 0) {
		foreach($subtypes as $subtype) {
			if($subtype && !empty($subtype) && is_registered_entity_type($type, $subtype)) {
			    $key = "$name:$type:$subtype";
			    $options[$key] = array(
            		'name'  => $key,
                    'value' => 'false',
                    'label' => elgg_echo("item:$type:$subtype"),
            	);
			}
		}
	}
}

// object key like "item:$type:$subtype"
foreach($value as $object_key => $_) {
    if (isset($options[$object_key])) {
        $options[$object_key]['value'] = 'true';
    }
}

// unset entity type "object" (as it may be confusing)
unset($options["$name:object"]);

// hide phloor release and version metadata
echo elgg_view('phloor/input/vendors/prettycheckboxes/checklist', array(
	'options' => $options,
));
