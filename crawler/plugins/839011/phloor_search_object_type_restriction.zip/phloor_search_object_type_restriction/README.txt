/**
 * Phloor Search Object Type Restriction
 * 
 * @package phloor_search_object_type_restirction
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * @author void <void@13net.at>
 * @copyright 13net
 * @link http://www.13net.at/
 */
 
Version: 1.8-11.11.21
Requires: Elgg 1.8 or higher, Search Plugin

/**
 * Description
 */
This plugin can be configured to prevent certain object types from being 
displayed on the search result page. Requires the search plugin to be enabled. 

This plugin prevents certain object types from being displayed on the search 
result page. The administrator can individually set the allowed object types 
for guest as well as for logged in users. The search of an administrator is 
not restricted. The settings are all OPT-IN which means that by default 
NOTHING will be displayed to guests or ordinary users.
		
/**
 * Languages
 */
English
German

/**
 * Admin Settings
 */
The administrator can individually set the allowed object types for guest as well as for
logged in users. The search of an administrator is not restricted.
The settings are all OPT-IN which means that by default NOTHING will be displayed to 
guests or ordinary users.

