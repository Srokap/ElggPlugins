<?php
/*****************************************************************************
 * Phloor Search Object Type Restriction                                     *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php

/**
 * Default attributes
 *
 * @return array with default values
 */
function phloor_search_object_type_restriction_default_vars() {
	$defaults = array(

	);

	return $defaults;
}

/**
 * Load vars from post or get requests and returns them as array
 *
 * @return array with values from the request
 */
function phloor_search_object_type_restriction_get_input_vars() {
    $sections = array(
		'guest' => array(),
		'user' => array(),
	);

    $params = array();

    $types = get_registered_entity_types();
	foreach($sections as $name => $_)  {
    	foreach($types as $type => $subtypes) {
        	// add type
        	$key = "$name:$type";
        	$input = get_input($key, 'false');
            if(strcmp('true', $input) == 0) {
                $params[$key] = 'true';
            }

        	// add its subtypes
        	if(is_array($subtypes) && count($subtypes) > 0) {
        		foreach($subtypes as $subtype) {
        			if($subtype && !empty($subtype) && is_registered_entity_type($type, $subtype)) {
        			    $key = "$name:$type:$subtype";
    			    	$input = get_input($key, 'false');
                        if(strcmp('true', $input) == 0) {
                            $params[$key] = 'true';
                        }
        			}
        		}
        	}
        }
	}

	return $params;
}
/**
 * Load vars from given site into and returns them as array
 *
 * @return array with stored values
 */
function phloor_search_object_type_restriction_prepare_vars(ElggSite $site) {
	if(!$site) {
		$site = elgg_get_site_entity();
	}
	// get default values
	$defaults = phloor_search_object_type_restriction_default_vars();

	$params = $defaults;

	// decode settings if existing
	if(isset($site->phloor_search_object_type_restriction_settings)) {
		$params = json_decode($site->phloor_search_object_type_restriction_settings, true);
	}

	return $params;
}

/**
 * Load vars from given site into and returns them as array
 *
 * @return array with stored values
 */
function phloor_search_object_type_restriction_save_vars($site, $params = array()) {
	// get default values
	$defaults = phloor_search_object_type_restriction_default_vars();
	// merge with params
	$options = array_merge($defaults, $params);
	// store as an  json encoded attribute of the site entity
	$site->phloor_search_object_type_restriction_settings = json_encode($options);
	// save site and return status
	return $site->save();
}
