<?php

/* ***********************************************************************
 * @author : Purusothaman Ramanujam
 * @link http://www.iYaffle.com/
 * Under this agreement, No one has rights to sell this script further.
 * ***********************************************************************/

add_translation('fr', array(
    'advanced-google-tools:lblPublisherID'    => 'Google Adsense Publisher ID',
    'advanced-google-tools:lblPubExample'     => '(Exemple: CA-PUB-0123456789123456)',
    'advanced-google-tools:lblBanner728x90'   => 'ID Adslot pour la taille Banni�re 728 X 90',
    'advanced-google-tools:lblBanner160x600'  => 'ID Adslot pour la taille Banni�re 160 X 60',
    'advanced-google-tools:lblAnalyticsID'    => 'Analytics Tracker ID: ',
    'advanced-google-tools:lblExample'        => '(Exemple: UA-1234567-8)',
    'advanced-google-tools:lblAdsenseHelp'    => 'Pour plus d'informations sur Adsense visitez ',
    'advanced-google-tools:lblAnalyticsHelp'  => 'Pour plus d'informations sur Analytics visitez '
));


