<?php

/* ***********************************************************************
 * @author : Purusothaman Ramanujam
 * @link http://www.iYaffle.com/
 * Under this agreement, No one has rights to sell this script further.
 * ***********************************************************************/

add_translation('en', array(
    'advanced-google-tools:lblPublisherID'    => 'Google Adsense Publisher ID',
    'advanced-google-tools:lblPubExample'     => '(Example: CA-PUB-0123456789123456)',
    'advanced-google-tools:lblBanner728x90'   => 'Adslot ID for Banner Size 728 X 90',
    'advanced-google-tools:lblBanner160x600'  => 'Adslot ID for Banner Size 160 X 60',
    'advanced-google-tools:lblAnalyticsID'    => 'Analytics Tracker ID: ',
    'advanced-google-tools:lblExample'        => '(looks like UA-1234567-8)',
    'advanced-google-tools:lblAdsenseHelp'    => 'For more information on Adsense please visit ',
    'advanced-google-tools:lblAnalyticsHelp'  => 'For more information on Analytics please visit '
));