Questions Elgg 1.8.5 beta1 Liang

* Fix Delete a question and answer
* Fix some river translation
* New language Brazilian portuguese translation (by Matheus Borges Lopes http://suachance.lucrebem.com.br)
* Fix add quesion button
* Fix Deprecated Widgets Error.
