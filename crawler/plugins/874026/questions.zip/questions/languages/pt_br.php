<?php
add_translation('pt_br', array(

'item:object:question' => 'Perguntas',
'answers' => 'Respostas',
'answers:addyours' => 'Responder',
'item:object:answer' => "Respostas",
'item:object:question' => "Perguntas",
'questions' => 'Perguntar',
'questions:asked' => 'Perguntado por %s',
'questions:answered' => '�ltima resposta por %s %s',
'questions:everyone' => 'Todas as perguntas',
'questions:add' => 'Perguntar',
'questions:owner' => "Perguntas de %s",
'questions:none' => "Nenhuma pergunta enviada ainda.",
'questions:friends' => "Perguntas dos seus amigos",
'questions:group' => 'Perguntas da equipe',
'object:question:title' => 'Pergunta',
'object:question:description' => "Detalhes",
'questions:river:question:created:by' => "Nova pergunta criada por",
'question:view' => " Visualizar",
'questions:river:question:created:by' => "%s Posted new Question.",
'questions:river:answer:created:by' => "%s posted Answer of Question",
'question:view' => " view",

/**
* Widgets
*/

'widget:questions:title' => "Perguntas",
'widget:questions:description' => "Voc� pode ver o status de suas perguntas.",
'widget:questions:limit' => "N�mero de perguntas para exibir:",

));