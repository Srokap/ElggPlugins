Yet Another Full Featured TinyMCE
1.5 for elgg v1.5

You don't need this version except when you:
want to have your pages, blogs, groups etc. image/media asset storage separated from your files or you don't have the files plugin or the embed plugin enabled,
want to have the possibility to switch the tinymce to fullscreen to have better overview while editing large pages,
want to embed flash videos,
want to have some of the other features described below.

What does it do?

Tinymce gives you the power of wysiwyg text-editing on fields of type 'longtext' in elgg. Currently enabled features of tinymce in this version are:

Text attributes: bold,italic,underline,strikethrough,foregroundcolor,backgroundcolor
Text styles: select style,select format,select font,select font size
Text alignment: justify left,justify center,justify right,justify full

Other features: inserting bullet lists or numbered lists, inserting and editing tables, direct editing of html-code, outdent or indent text blocks, inserting of smilies, inserting media files with uploading possibility by integrated tinybrowser, elgg language support. Inline-scripting should work, too.

In addition you can now switch between two alternating images like 'hover' using onmouseover/onmouseout and embedded images are scalable with the mouse or by entering dimensions.

The tinybrowser needs a directory '/assets' under your $_SERVER['DOCUMENT_ROOT'], so that you have to create this first and chmod it to '777'. When a user uploads a file, additional subdirectorys based on the loginname of the user will be created in the following form:

/assets
   /loginname
      /img        //store for images
         /_thumbs //store for automatic created thumbnails
      /media      //store for 'swf' files
      
If you want to upload and embed flash videos, you first have to put the *.flv together with a flashplayer into an *.swf. You can do this with a flash toolbox. Otherwise you can embed flash videos from youtube simply by inserting the url of the video.
I've NOT tested inserting media of other formats than flash.

Installation:
Do not overwrite your existing version of tinymce!
First disable your existing tinymce plugin in the admin/tools section.
Make a backup copy of your existing /mod/tinymce folder and delete it. Insert the tinymce folder from this archive in /mod.
Create a folder '/assets' under your $_SERVER['DOCUMENT_ROOT'] and chmod it to '777' (or chown it according to the account of your webserver e.g 'www', 'wwwrun' and give permissions to write - this should work, too).

Enable the new tinymce plugin in the admin/tools section.

Although i've tested this plugin on my various systems, there's no warranty. Use it on your own risk.

You will find additional information on the website of the tinymce developers: http://www.moxiecode.com.

Please give me a short response if this plugin works for you with or without restrictions.

enjoy it!
Karsten Schulze (2009)
