<?php

   /**
    * Elgg 'primeiros passos' plugin
    * adapta��o dos plugins 'tips' e 'cicero' (from Goofbucket)
    * @author Cerceau, Renato (30nov2010)
    */
      
    global $CONFIG;
                          
    // Register a page handler, so we can have nice URLs
    register_page_handler('primeiros_passos','primeiros_passos_page_handler');
        
    // Page handler
    function scopes_page_handler($page) {
       global $CONFIG;
       include($CONFIG->pluginspath . "primeiros_passos/index.php");
    }
                   
    // Shares widget

    // Brazilian portuguese    
    //$name = elgg_echo("Primeiros Passos");

    // english
    $name = elgg_echo("Firsy Steps");

    add_widget_type('primeiros_passos', $name, $name);


                 
?>
