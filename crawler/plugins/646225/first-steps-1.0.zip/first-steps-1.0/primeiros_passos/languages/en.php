<?php

$english = array( 
	 'primeirospasssos'  =>  "First Steps", 
	 'primeirospasssos:tit'  =>  "First Steps", 
	 'primeirospasssos:welcome'  =>  "welcome...",
      'primeirospasssos:comments' => "We suggest some initial steps:",
      'primeirospasssos:profile' => "change your profile", 
      'primeirospasssos:profile:comments' => "to be better known by the group.",
      'primeirospasssos:personal' => "customize your profile with your style",
      'primeirospasssos:personal:comments' => "you can change the background and the colors",
      'primeirospasssos:friends:comments' => "search among members of social network (or invite by email) yours",
      'primeirospasssos:friends' => "friends",
      'primeirospasssos:groups:comments' => "see the activities and issues under discussion in",  
      'primeirospasssos:groups' => "groups",
      'primeirospasssos:share' => "share",
      'primeirospasssos:share:comments' => " the contents with your friends and find interesting topics  (twitter, facebook, orkut. gmail, etc)",
      'primeirospasssos:talk:comments' => "participate in community discussions,",
      'primeirospasssos:talk' => "let we know your opnion",
      'primeirospasssos:final' => "Have fun",
      'primeirospasssos:link:profile' => "Profile",
      'primeirospasssos:link:style' => "Style",
      'primeirospasssos:link:friends' => "Friends",
      'primeirospasssos:link:members' => "Members",
      'primeirospasssos:link:groups' => "Groups",
      'primeirospasssos:link:activity' => "Activity"

); 

add_translation('en', $english); 

?>