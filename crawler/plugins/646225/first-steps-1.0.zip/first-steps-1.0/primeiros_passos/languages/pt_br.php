<?php

$portugues_brasileiro = array( 
	 'primeirospasssos'  =>  "Primeiros Passos", 
	 'primeirospasssos:tit'  =>  "Primeiros Passos", 
	 'primeirospasssos:welcome'  =>  "seja bem vindo...",
      'primeirospasssos:comments' => "Sugerimos alguns passos iniciais:",
      'primeirospasssos:profile' => "altere seu perfil", 
      'primeirospasssos:profile:comments' => "para ser melhor  conhecido pela comunidade.",
      'primeirospasssos:personal' => "personalize seu perfil com seu estilo",
      'primeirospasssos:personal:comments' => "voce pode alterar a tela de fundo e as cores",
      'primeirospasssos:friends:comments' => "procure dentre os membros da rede social (ou convide por email) seus",
      'primeirospasssos:friends' => "amigos",
      'primeirospasssos:groups:comments' => "veja as atividades e os assuntos em discuss&atilde;o nas",  
      'primeirospasssos:groups' => "comunidades",
      'primeirospasssos:share' => "divulgue",
      'primeirospasssos:share:comments' => " para seus amigos os conte&uacute;dos e temas que achar interessante  (twitter, facebook, orkut. gmail, etc)",
      'primeirospasssos:talk:comments' => "participe dos debates nas comunidades,",
      'primeirospasssos:talk' => "deixe sua opini&atilde;o",
      'primeirospasssos:final' => "Divirta-se",
      'primeirospasssos:link:profile' => "Perfil",
      'primeirospasssos:link:style' => "Estilo",
      'primeirospasssos:link:friends' => "Amigos",
      'primeirospasssos:link:members' => "Membros",
      'primeirospasssos:link:groups' => "Comunidades",
      'primeirospasssos:link:activity' => "Atividades"

); 

add_translation('pt_br', $portugues_brasileiro); 

?>