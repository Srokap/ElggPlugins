<?php

   /**
    * Elgg 'primeiros passos' plugin
    * adapta��o dos plugins 'tips' e 'cicero' (from Goofbucket)
    * @author Cerceau, Renato (30nov2010)
    */

?>

<div id="scope" style="text-align:center;" class="contentWrapper">

<?php

   // Get the current page's owner
   $guid = page_owner();
   $obj = get_entity($guid); 
       $name = $obj->name; 
       $username = $obj->username; 


$text = "<p align=\"left\"> ";
// name
$text .= $name . ", " . elgg_echo ('primeirospasssos:welcome');
$text .= "</p>
  <HR>";

$text .= "
  <BR>
  <p align=\"left\"> ";
$text .= elgg_echo ('primeirospasssos:comments');
$text .=" </p>
  <div align=\"left\">
    <ol>
      <li>";
$text .= "<strong>" . elgg_echo ('primeirospasssos:profile') . " </strong>";
$text .= elgg_echo ('primeirospasssos:profile:comments') . "</li>";
$text .= "<li align=left>";
$text .= "<strong>" . elgg_echo ('primeirospasssos:personal') . " </strong>";
$text .= "(" . elgg_echo ('primeirospasssos:personal:comments') . ") </li>";
$text .= "<li>";
$text .= elgg_echo ('primeirospasssos:friends:comments');
$text .= "<strong> " . elgg_echo ('primeirospasssos:friends') . " </strong></li>";
$text .= "<li>";
$text .= elgg_echo ('primeirospasssos:groups:comments');
$text .= "<strong> " . elgg_echo ('primeirospasssos:groups') . " </strong></li>";
$text .= "<li>";
$text .= "<strong> " . elgg_echo ('primeirospasssos:share') . " </strong>";
$text .= elgg_echo ('primeirospasssos:share:comments') . "</li>";
$text .= "<li>";
$text .= elgg_echo ('primeirospasssos:talk:comments');
$text .= "<strong> " . elgg_echo ('primeirospasssos:talk') . "</strong>";
$text .= "!<br /></li>
      <p></p>
    </ol>
  </div>
  <p align=\"left\">";
$text .=  elgg_echo ('primeirospasssos:final');
$text .= "!</p> ....  <BR>  "; 
$text .= "</div>";

// INIT ECHO
    echo( $text ); 
// END ECHO

  $text = " "; //INIT ECHO

	// PROFILE :: http://www.assetans.org.br/redesocial2/pg/profile/renato.cerceau
  $text .= "  <blockquote ALIGN=\"center\"> <h5> <a href=";
  $text .= get_entity_url($guid); 
  $text .= " > " . elgg_echo ('primeirospasssos:link:profile') . "</a>, ";

	// CUSTOM STYLE :: http://www.assetans.org.br/redesocial2/pg/customstyle/
  $text .= "<a href=";
  $text .= dirname(dirname (get_entity_url($guid))) . "/customstyle/"; 
  $text .= " > " . elgg_echo ('primeirospasssos:link:style') . "</a>, ";

	// FRIENDS :: http://www.assetans.org.br/redesocial2/pg/friends/renato.cerceau
  $text .= "<a href=";
  $text .= dirname(dirname (get_entity_url($guid))) . "/friends/" . $username ; 
  $text .= " > " . elgg_echo ('primeirospasssos:link:friends') . "</a>, ";

	// MEMBERS :: http://www.assetans.org.br/redesocial2/pg/members/all/
  $text .= "<a href=";
  $text .= dirname(dirname (get_entity_url($guid))) . "/members/all/" ; 
  $text .= " > " . elgg_echo ('primeirospasssos:link:members') . "</a>, ";

	// GROUPS :: http://www.assetans.org.br/redesocial2/pg/groups/all/
  $text .= "<a href=";
  $text .= dirname(dirname (get_entity_url($guid))) . "/groups/all/"; 
  $text .= " > " . elgg_echo ('primeirospasssos:link:groups') . "</a>, ";

     // ACTIVITY :: http://www.assetans.org.br/redesocial2/pg/activity/
  $text .= "<a href=";
  $text .= dirname(dirname (get_entity_url($guid))) . "/activity/"; 
  $text .= " > " . elgg_echo ('primeirospasssos:link:activity') . "</a></h5> </blockquote>";


  echo( $text ); // END ECHO

?>

<BR> <h6> <a href="http://www.assetans.org.br/redesocial/"> Assetans 2010 </a> </h6>
