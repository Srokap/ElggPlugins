<?php

   /**
    * Elgg 'primeiros passos' plugin
    * adapta��o dos plugins 'tips' e 'cicero' (from Goofbucket)
    * @author Cerceau, Renato (30nov2010)
    */
         
  // Load Elgg engine
  require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

   
  // Display form

        $area1 = elgg_view("primeiros_passos/form"); //Get the form
                
  // Draw page
        page_draw(elgg_echo ("AAAprimeirospasssos:tit",elgg_view_layout("one_column", $area1));
        
?>
