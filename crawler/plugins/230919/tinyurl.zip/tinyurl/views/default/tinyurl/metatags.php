		<script type="text/javascript">
		 jQuery(document).ready(function($) {
		  $('a[rel*=facebox]').facebox()
		});
		</script>
		<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/tinyurl/jquery.form.js"></script> 