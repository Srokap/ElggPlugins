<?php

	$english = array(
	
		'shortlink:insert' => 'Insert short link',
		'shortlink:modaltitle' => 'Short URL via TinyURL',
		'shortlink:link' => 'URL',
		
	);
					
	add_translation("en",$english);

?>