<?php

	/**
	 * TinyURL plugin
	 * 
	 */

	/**
	 * Init function
	 *
	 */
		function tinyurl_init() {
			// Extend useful views 
			extend_view('css','tinyurl/css');
			
			if(!is_plugin_enabled('embed')){
				extend_view('js/initialise_elgg','tinyurl/js');
				extend_view('metatags','tinyurl/metatags');
			}			
				
			register_page_handler('tinyurl','tinyurl_page_handler');
		}	

		function tinyurl_page_handler($page) {
			switch($page[0]) {
				default:			require_once(dirname(__FILE__) . '/longurl.php');
									exit;
									break;			
			}
		}	

		function getTinyUrl($url) {
			$tinyurl = file_get_contents("http://tinyurl.com/api-create.php?url=".$url);
			return $tinyurl;
		}		

	// Register the init action
		register_elgg_event_handler('init','system','tinyurl_init',10);
?>