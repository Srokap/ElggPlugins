<?php

	$reg_popup = $vars['entity']->reg_popup;
	if (!$reg_popup) $reg_popup = 'yes';
	
?>
<div class="contentWrapper">
    <p><?php echo elgg_echo('custom_reg:param_label'); ?>
    <?php
    echo elgg_view('input/pulldown', array(
            'internalname' => 'params[reg_popup]',
            'options_values' => array(
                'no' => elgg_echo('option:no'),
                'yes' => elgg_echo('option:yes')
            ),
            'value' => $reg_popup
    ));
    ?>
    </p>
</div>
