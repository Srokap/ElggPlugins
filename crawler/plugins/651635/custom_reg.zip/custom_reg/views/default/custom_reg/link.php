<a class='regpop' href="<?php echo $vars['url'] . 'mod/custom_reg/'; ?>"><?php echo elgg_echo('custom_reg:link'); ?></a>

