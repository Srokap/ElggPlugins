<script type="text/javascript" src="<?php echo $CONFIG->wwwroot . 'mod/custom_reg/vendors/jquery.colorbox-min.js'; ?>"></script>
    
<script>
	$(document).ready(function(){
		$(".regpop").colorbox();
	});
</script>
