<div id="reg_box">
If you already have an account log in below.
</div>