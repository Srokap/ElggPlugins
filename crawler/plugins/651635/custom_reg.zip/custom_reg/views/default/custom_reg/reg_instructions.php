<div id="reg_box">
Create your display and username as shown.
</div>