<?php
/*******************************************************************************
 * registration page
 *
 * @author Fusion
 ******************************************************************************/
 ?>
 
 <div id="reg_box">
 <p><center><b>Welcome to MyPaintersPlace.com. Promote your business for free!<br /> Connect with product makers, get certified and start getting business from them.<br />
 </b></center></p>
 </div>