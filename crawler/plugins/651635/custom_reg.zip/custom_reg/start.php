<?php
/*******************************************************************************
* registration page
*
* @author Fusion
******************************************************************************/

function custom_reg_init()	{
	global $CONFIG;

	// Page handler
	register_page_handler('registration','custom_reg_page_handler');

	if (get_plugin_setting('reg_popup', 'custom_reg') == 'yes') {
		// add js
		elgg_extend_view('metatags', 'custom_reg/head');
	
	}

	// add xtra registration link	
	elgg_extend_view('input/longtext','custom_reg/link');
	
	// extend some views
	elgg_extend_view('css','custom_reg/css');
	
	return true;
}

function custom_reg_page_handler($page)	{
	global $CONFIG;
		
	@include(dirname(__FILE__) . "/index.php");
	return true;
}

function custom_reg_registration() {			
	include(dirname(__FILE__) . '/index.php');
		
}
register_elgg_event_handler('init', 'system', 'custom_reg_init');

?>