<?php
/*******************************************************************************
 * registration page
 *
 * @author Fusion
 ******************************************************************************/
    //include the elgg engine
	require_once(dirname(dirname(dirname(__FILE__))) . '/engine/start.php');

	$title = elgg_echo('Login - Register');
		
    //set a view for the top
	$area1 = elgg_view("custom_reg/topbox");

    //set a view to display left column
	$area2 .= elgg_view("custom_reg/login_instructions");
	$area2 .= elgg_view("custom_reg/login");
	
	//set aview for the right column
	$area3 .= elgg_view("custom_reg/reg_instructions");
	$area3 .= elgg_view("account/forms/register"); 
	
	// layout the sidebar and main column using the default sidebar
	$body = elgg_view_layout('my_two_column',$area1,$area2,$area3);

	
	if (get_plugin_setting('reg_popup', 'custom_reg') == 'no') {
		
	// create the complete html page and send to browser
	page_draw($title, $body);
	
	} else {

	header("Content-type: text/html; charset=UTF-8");
	echo $body;
		
	}
?>