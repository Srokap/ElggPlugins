<?php

$danish = array(

	'custom_reg:param_label'	=> "Skal siden Registrer vises som popup",
	'custom_reg:link'			=> "Login/Register",

);

add_translation("da",$danish);

?>