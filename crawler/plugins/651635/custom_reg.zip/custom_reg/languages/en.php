<?php

$english = array(

	'custom_reg:param_label'	=> "Do you want Register page shown in popup",
	'custom_reg:link'			=> "Login/Register",
);
				
add_translation("en",$english);

?>