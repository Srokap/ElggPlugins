<?php
	echo $vars['url'] . "mod/profile/graphics/defaultlarge.jpg";
?>