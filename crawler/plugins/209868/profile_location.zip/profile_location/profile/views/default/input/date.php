<?php

	/**
	 * Elgg date input
	 * Displays a date selection
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.org/
	 * 
	 * @uses $vars['value'] The current value, if any
	 * @uses $vars['js'] Any Javascript to enter into the input tag
	 * @uses $vars['internalname'] The name of the input field
	 * @uses $vars['disabled'] If true then control is read-only
	 * @uses $vars['class'] Class override
	 */

	
	$class = $vars['class'];
	if (!$class) $class = "input-date";

	$birthdate = $vars['value'];
	$ybdate = date("Y", $birthdate);
	$mbdate = date("m", $birthdate);
	$dbdate = date("d", $birthdate);

	$ybdate = (int)$ybdate;
	$mbdate = (int)$mbdate;
	$dbdate = (int)$dbdate;
	
?>

<script language="JavaScript">

//function for returning how many days there are in a month including leap years
function DaysInMonth(WhichMonth, WhichYear)
{
  var DaysInMonth = 31;
  if (WhichMonth == 4 || WhichMonth == 6 || WhichMonth == 9 || WhichMonth == 11) DaysInMonth = 30;
  if (WhichMonth == 2 && (WhichYear/4) != Math.floor(WhichYear/4))	DaysInMonth = 28;
  if (WhichMonth == 2 && (WhichYear/4) == Math.floor(WhichYear/4))	DaysInMonth = 29;
  return DaysInMonth;
}


// alert(DaysInMonth(document.getElementById('monthid').value,2000));


//function to change the available days in a months
function ChangeOptionDays(resultid) {

  DaysObject = document.getElementById('dayid');
  MonthObject = document.getElementById('monthid');
  YearObject = document.getElementById('yearid');

  Day = DaysObject.value;
  Month = MonthObject.value;
  Year = YearObject.value;

  DaysForThisSelection = DaysInMonth(Month, Year);
  CurrentDaysInSelection = DaysObject.length;

  if (CurrentDaysInSelection > DaysForThisSelection) {
    for (i=0; i<(CurrentDaysInSelection-DaysForThisSelection); i++) {

      DaysObject.options[DaysObject.options.length - 1] = null;
    }
  }
  if (DaysForThisSelection > CurrentDaysInSelection) {
    for (i=0; i<(DaysForThisSelection-CurrentDaysInSelection); i++) {

	  NewOption = new Option(DaysObject.options.length +1);
      DaysObject.options.add(NewOption);
	}
  }
  if (DaysObject.selectedIndex < 0) DaysObject.selectedIndex == 0;

  if (Day > 0 && Month > 0 && Year > 0) {
		setDate(resultid,Day,Month,Year);
  }
}

//Function to calculate the timestamp
function humanToTime(Day,Month,Year) {

  DaysObject = document.getElementById('dayid');
  MonthObject = document.getElementById('monthid');
  YearObject = document.getElementById('yearid');

  Day = DaysObject.value;
  Month = MonthObject.value;
  Year = YearObject.value;

    var humDate = new Date(Date.UTC(Year,
          (stripLeadingZeroes(Month)-1),
          stripLeadingZeroes(Day),
          stripLeadingZeroes(0),
          stripLeadingZeroes(0),
          stripLeadingZeroes(0)));

    return (humDate.getTime()/1000.0);

}

//Function to save the date
function setDate(resultid,Day,Month,Year) {

	resultObj = document.getElementById(resultid);

	datetime = humanToTime(Day,Month,Year);
	resultObj.value = datetime;
}

function stripLeadingZeroes(input) {

    if((input.length > 1) && (input.substr(0,1) == "0"))
      return input.substr(1);
    else
      return input;
}

</script>

<input type="hidden" name="<?php echo $vars['internalname']; ?>" id="<?php echo $vars['internalname']; ?>id" value="<?php echo (int)$vars['value']; ?>"/> 

<select <?php if ($vars['disabled']) echo ' disabled="yes" '; ?> name="FirstSelectDay" id="dayid" class="<?php echo $class ?>" onchange="ChangeOptionDays('<?php echo $vars['internalname']; ?>id')"/> 
	<?php

		$daycount = 1;

		while ($daycount < 32) {
			echo '<option value="' . $daycount . '"';
			if ($daycount == $dbdate) {
				echo ' selected="selected"';
			}
			
			echo '>' . $daycount . '</option>' . chr(10);
			$daycount = $daycount +1;
		}
	?>
</select>

<select <?php if ($vars['disabled']) echo ' disabled="yes" '; ?> name="FirstSelectMonth" id="monthid" class="<?php echo $class ?>" onchange="ChangeOptionDays('<?php echo $vars['internalname']; ?>id')"/> 
	<?php
		$monthcount = 1;

		while ($monthcount < 13) {
			echo '<option value="' . $monthcount . '"';
			if ($monthcount == $mbdate) {
				echo ' selected="selected"';
			}
			
			echo '>' . elgg_echo("month:{$monthcount}") . '</option>' . chr(10);
			$monthcount = $monthcount +1;
		}
	?>
</select>

<select <?php if ($vars['disabled']) echo ' disabled="yes" '; ?> name="FirstSelectYear" id="yearid" class="<?php echo $class ?>" onchange="ChangeOptionDays('<?php echo $vars['internalname']; ?>id')"/> 
	<?php
		$year = (int)date('Y');
		$yearcount = $year - 6;
		$yearend = $year - 99;

		while ($yearcount > $yearend) {
			echo '<option value="' . $yearcount . '"';
			if ($yearcount == $ybdate) {
				echo ' selected="selected"';
			}
			
			echo '>' . $yearcount . '</option>' . chr(10);
			$yearcount = $yearcount -1;
		}
	?>
</select><br />