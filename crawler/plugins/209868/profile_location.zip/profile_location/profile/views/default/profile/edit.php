<?php

	/**
	 * Elgg user display (details) "Age And Gender"
	 * 
	 * @package ElggProfile
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>, modified by Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
	 * @copyright Curverider Ltd 2008
	 * @link http://www.ircaserta.com/
	 * 
	 * @uses $vars['entity'] The user entity
	 */

?>

<form action="<?php echo $vars['url']; ?>action/profile/edit" method="post">

<?php

	//var_export($vars['profile']);
	if (is_array($vars['config']->profile) && sizeof($vars['config']->profile) > 0)
		foreach($vars['config']->profile as $shortname => $valtype) {
			if ($metadata = get_metadata_byname($vars['entity']->guid, $shortname)) {
				if (is_array($metadata)) {
					$value = '';
					foreach($metadata as $md) {
						if (!empty($value)) $value .= ', ';
						$value .= $md->value;
						$access_id = $md->access_id;
					}
				} else {
					$value = $metadata->value;
					$access_id = $metadata->access_id;
				}
			} else {
				$value = '';
				$access_id = 2;
			}

?>

	<p>
		<label for="<?php echo elgg_echo("profile:{$shortname}") ?>"><?php echo elgg_echo("profile:{$shortname}") ?></label>
			<?php
				if ($valtype == 'pulldown' and $shortname == 'gender') {
								
					echo elgg_view("input/pulldown",array(
															'internalname' => $shortname,
															'options_values' => array(
																	'' => elgg_echo('profile:gender:n'),
																	'm' => elgg_echo('profile:gender:m'),
																	'f' => elgg_echo('profile:gender:f')),
															'value' => $value,
															));						
				
				}

   elseif($valtype == 'tags' and $shortname == 'location') {

					echo elgg_view("input/pulldown",array(
															'internalname' => $shortname,
															'options_values' => array(
																	'' => elgg_echo('-- Select Country & Location --'),
																	'Vietnam' => elgg_echo('Vietnam'),
																	'United Kingdom' => elgg_echo('United Kingdom'),
																	'Washington' => elgg_echo('Washington'),
                                                                    'Idaho' => elgg_echo('Idaho'),
                                                                    'Montana' => elgg_echo('Montana'),
                                                                    'North Dakota' => elgg_echo('North Dakota'),
                                                                    'Minnesota' => elgg_echo('Minnesota'),
                                                                    'Wisconsin' => elgg_echo('Wisconsin'),
                                                                    'Michigan' => elgg_echo('Michigan'),
                                                                    'Oregon' => elgg_echo('Oregon'),
                                                                    'Wyoming' => elgg_echo('Wyoming'),
                                                                    'South Dakota' => elgg_echo('South Dakota'),
                                                                    'Iowa' => elgg_echo('Iowa'),
                                                                    'Illinois' => elgg_echo('Illinois'),
                                                                    'Indiana' => elgg_echo('Indiana'),
                                                                    'Ohio' => elgg_echo('Ohio'),
                                                                    'California' => elgg_echo('California'),
                                                                    'Nevada' => elgg_echo('Nevada'),
                                                                    'Utah' => elgg_echo('Utah'),
                                                                    'Colorado' => elgg_echo('Colorado'),
                                                                    'Nebraska' => elgg_echo('Nebraska'),
                                                                    'Kansas' => elgg_echo('Kansas'),
                                                                    'Missouri' => elgg_echo('Missouri'),
                                                                    'Kentucky' => elgg_echo('Kentucky'),
                                                                    'Arizona' => elgg_echo('Arizona'),
                                                                    'New Mexico' => elgg_echo('New Mexico'),
                                                                    'Texas' => elgg_echo('Texas'),
                                                                    'Oklahoma' => elgg_echo('Oklahoma'),
                                                                    'Arkansas' => elgg_echo('Arkansas'),
                                                                    'Louisiana' => elgg_echo('Louisiana'),
                                                                    'Mississippi' => elgg_echo('Mississippi'),
                                                                    'Tennessee' => elgg_echo('Tennessee'),
                                                                    'Alabama' => elgg_echo('Alabama'),
                                                                    'Georgia' => elgg_echo('Georgia'),
                                                                    'Florida' => elgg_echo('Florida'),
                                                                    'West Virginia' => elgg_echo('West Virginia'),
                                                                    'Maryland' => elgg_echo('Maryland'),
                                                                    'Pennsylvania' => elgg_echo('Pennsylvania'),
                                                                    'New York' => elgg_echo('New York'),
                                                                    'Vermont' => elgg_echo('Vermont'),
                                                                    'New Hampshire' => elgg_echo('New Hampshire'),
                                                                    'Maine' => elgg_echo('Maine'),
                                                                    'Massachusetts' => elgg_echo('Massachusetts'),
                                                                    'Rhode Island' => elgg_echo('Rhode Island'),
                                                                    'Connecticut' => elgg_echo('Connecticut'),
                                                                    'New Jersey' => elgg_echo('New Jersey'),
                                                                    'Delaware' => elgg_echo('Delaware'),
                                                                    'Virginia' => elgg_echo('Virginia'),
                                                                    'North Carolina' => elgg_echo('North Carolina'),
                                                                    'South Carolina' => elgg_echo('South Carolina'),
                                                                    'Alaska' => elgg_echo('Alaska'),
                                                                    'Hawaii' => elgg_echo('Hawaii'),
                                                                    'District of Columbia' => elgg_echo('District of Columbia'),
                                                                    'Canada' => elgg_echo('Canada'),
                                                                    'Bermuda' => elgg_echo('Bermuda'),
                                                                    'Anguilla' => elgg_echo('Anguilla (U.K.)'),
                                                                    'Antigua and Barbuda' => elgg_echo('Antigua and Barbuda'),
                                                                    'Aruba' => elgg_echo('Aruba (Neth.)'),
                                                                    'Barbados' => elgg_echo('Barbados'),
                                                                    'Belize' => elgg_echo('Belize'),
                                                                    'British Virgin Islands' => elgg_echo('British Virgin Islands (U.K.)'),
                                                                    'Cayman Islands' => elgg_echo('Cayman Islands'),
                                                                    'Costa Rica' => elgg_echo('Costa Rica'),
                                                                    'Cuba' => elgg_echo('Cuba'),
                                                                    'Dominica' => elgg_echo('Dominica'),
                                                                    'Dominican Republic' => elgg_echo('Dominican Republic'),
                                                                    'El Salvador' => elgg_echo('El Salvador'),
                                                                    'Grenada' => elgg_echo('Grenada'),
                                                                    'Guadeloupe' => elgg_echo('Guadeloupe (France)'),
                                                                    'Guatemala' => elgg_echo('Guatemala'),
                                                                    'Haiti' => elgg_echo('Haiti'),
                                                                    'Honduras' => elgg_echo('Honduras'),
                                                                    'Jamaica' => elgg_echo('Jamaica'),
                                                                    'Martinique' => elgg_echo('Martinique (France)'),
                                                                    'Montserrat' => elgg_echo('Montserrat (U.K.)'),
                                                                    'Netherland' => elgg_echo('Netherland Antilles (Neth.)'),
                                                                    'Nicaragua' => elgg_echo('Nicaragua'),
                                                                    'Panama' => elgg_echo('Panama'),
                                                                    'Puerto Rico' => elgg_echo('Puerto Rico (U.S.)'),
                                                                    'Kitts and Nevis' => elgg_echo('St. Kitts and Nevis'),
																	'Vincent and The Grenadines' => elgg_echo('St. Vincent and The Grenadines'),
                                                                    'Lucia' => elgg_echo('St. Lucia'),
																	'Bahamas' => elgg_echo('The Bahamas'),
																	'Trinidad and Tobago' => elgg_echo('Trinidad and Tobago'),
																	'Turks and Caicos Islands' => elgg_echo('Turks and Caicos Islands (U.K.)'),
																	'Virgin Islands' => elgg_echo('Virgin Islands (U.S.)'),
																	'Mexico' => elgg_echo('Mexico'),
																	'Argentina' => elgg_echo('Argentina'),
																	'Bolivia' => elgg_echo('Bolivia'),
																	'Brazil' => elgg_echo('Brazil'),
																	'Chile' => elgg_echo('Chile'),
																	'Colombia' => elgg_echo('Colombia'),
																	'Ecuador' => elgg_echo('Ecuador'),
																	'Falkland Islands' => elgg_echo('Falkland Islands (UK)'),
																	'French Guiana' => elgg_echo('French Guiana (France)'),
																	'Guyana' => elgg_echo('Guyana'),
																	'Paraguay' => elgg_echo('Paraguay'),
																	'Peru' => elgg_echo('Peru'),
																	'Suriname' => elgg_echo('Suriname'),
																	'Uruguay' => elgg_echo('Uruguay'),
																	'Venezuela' => elgg_echo('Venezuela'),
																	'Algeria' => elgg_echo('Algeria'),
																	'Angola' => elgg_echo('Angola'),
																	'Benin' => elgg_echo('Benin'),
																	'Botswana' => elgg_echo('Botswana'),
																	'Burkina Faso' => elgg_echo('Burkina Faso'),
																	'Burundi' => elgg_echo('Burundi'),
																	'Cameroon' => elgg_echo('Cameroon'),
																	'Cape Verde' => elgg_echo('Cape Verde'),
																	'Central African Republic' => elgg_echo('Central African Republic'),
																	'Chad' => elgg_echo('Chad'),
																	'Comoros' => elgg_echo('Comoros'),
																	'Congo' => elgg_echo('Congo'),
																	'Cote d\'Ivoire' => elgg_echo('Cote d\'Ivoire'),
																	'Democratic Republic of the Congo' => elgg_echo('Democratic Republic of the Congo'),
																	'Djibouti' => elgg_echo('Djibouti'),
																	'Egypt' => elgg_echo('Egypt'),
																	'Equatorial Guinea' => elgg_echo('Equatorial Guinea'),
																	'Eritrea' => elgg_echo('Eritrea'),
																	'Ethiopia' => elgg_echo('Ethiopia'),
																	'Gabon' => elgg_echo('Gabon'),
																	'Gambia' => elgg_echo('Gambia'),
																	'Ghana' => elgg_echo('Ghana'),
																	'Guinea' => elgg_echo('Guinea'),
																	'Guinea-Bissau' => elgg_echo('Guinea-Bissau'),
																	'Kenya' => elgg_echo('Kenya'),
																	'Lesotho' => elgg_echo('Lesotho'),
																	'Liberia' => elgg_echo('Liberia'),
																	'Libya' => elgg_echo('Libya'),
																	'Madagascar' => elgg_echo('Madagascar'),
																	'Malawi' => elgg_echo('Malawi'),
																	'Mali' => elgg_echo('Mali'),
																	'Mauritania' => elgg_echo('Mauritania'),
																	'Mauritius' => elgg_echo('Mauritius'),
																	'Morocco' => elgg_echo('Morocco'),
																	'Mozambique' => elgg_echo('Mozambique'),
																	'Namibia' => elgg_echo('Namibia'),
																	'Niger' => elgg_echo('Niger'),
																	'Nigeria' => elgg_echo('Nigeria'),
																	'Reunion' => elgg_echo('Reunion (France)'),
																	'Rwanda' => elgg_echo('Rwanda'),
																	'Sao Tome and Principe' => elgg_echo('Sao Tome and Principe'),
																	'Senegal' => elgg_echo('Senegal'),
																	'Seychelles' => elgg_echo('Seychelles'),
																	'Sierra Leone' => elgg_echo('Sierra Leone'),
																	'Somalia' => elgg_echo('Somalia'),
																	'South Africa' => elgg_echo('South Africa'),
																	'Sudan' => elgg_echo('Sudan'),
																	'Swaziland' => elgg_echo('Swaziland'),
																	'Tanzania' => elgg_echo('Tanzania'),
																	'Togo' => elgg_echo('Togo'),
																	'Tunisia' => elgg_echo('Tunisia'),
																	'Uganda' => elgg_echo('Uganda'),
																	'Western Sahara' => elgg_echo('Western Sahara'),
																	'Zambia' => elgg_echo('Zambia'),
																	'Zimbabwe' => elgg_echo('Zimbabwe'),
																	'Portugal' => elgg_echo('Portugal'),
																	'Spain' => elgg_echo('Spain'),
																	'France' => elgg_echo('France'),
																	'Andorra' => elgg_echo('Andorra'),
																	'Ireland' => elgg_echo('Ireland'),
																	'Iceland' => elgg_echo('Iceland'),
																	'Belgium' => elgg_echo('Belgium'),
																	'Netherlands' => elgg_echo('Netherlands'),
																	'Czech Republic' => elgg_echo('Czech Republic'),
																	'Germany' => elgg_echo('Germany'),
																	'Luxembourg' => elgg_echo('Luxembourg'),
																	'Denmark' => elgg_echo('Denmark'),
																	'Norway' => elgg_echo('Norway'),
																	'Sweden' => elgg_echo('Sweden'),
																	'Finland' => elgg_echo('Finland'),
																	'Estonia' => elgg_echo('Estonia'),
																	'Latvia' => elgg_echo('Latvia'),
																	'Lithuania' => elgg_echo('Lithuania'),
																	'Russian Federation' => elgg_echo('Russian Federation'),
																	'Poland' => elgg_echo('Poland'),
																	'Belarus' => elgg_echo('Belarus'),
																	'Ukraine' => elgg_echo('Ukraine'),
																	'Moldova' => elgg_echo('Moldova, Republic of'),
																	'Romania' => elgg_echo('Romania'),
																	'Slovakia' => elgg_echo('Slovakia'),
																	'Hungary' => elgg_echo('Hungary'),
																	'Austria' => elgg_echo('Austria'),
																	'Switzerland' => elgg_echo('Switzerland'),
																	'Slovenia' => elgg_echo('Slovenia'),
																	'Bosnia and Gerzegovina' => elgg_echo('Bosnia and Gerzegovina'),
																	'Republic of Serbia' => elgg_echo('Republic of Serbia'),
																	'Albania' => elgg_echo('Albania'),
																	'Macedonia' => elgg_echo('Macedonia, The former'),
																	'Greece' => elgg_echo('Greece'),
																	'Bulgaria' => elgg_echo('Bulgaria'),
																	'Turkey' => elgg_echo('Turkey'),
																	'Georgia' => elgg_echo('Georgia'),
																	'Armenia' => elgg_echo('Armenia'),
																	'Azerbaijan' => elgg_echo('Azerbaijan'),
																	'Cyprus' => elgg_echo('Cyprus'),
																	'Malta' => elgg_echo('Malta'),
																	'Monaco' => elgg_echo('Monaco'),
																	'Liechtenstein' => elgg_echo('Liechtenstein'),
																	'Greenland' => elgg_echo('Greenland'),
																	'Faroe islands' => elgg_echo('Faroe islands'),
																	'San Marino' => elgg_echo('San Marino'),
																	'Vatican' => elgg_echo('Vatican'),
																	'Gibraltar' => elgg_echo('Gibraltar'),
																	'Guernsey' => elgg_echo('Guernsey'),
																	'Isle of Man' => elgg_echo('Isle of Man'),
																	'Jersey' => elgg_echo('Jersey'),
																	'Afghanistan' => elgg_echo('Afghanistan'),
																	'Armenia' => elgg_echo('Armenia'),
																	'Bahrain' => elgg_echo('Bahrain'),
																	'Bangladesh' => elgg_echo('Bangladesh'),
																	'Bhutan' => elgg_echo('Bhutan'),
																	'Brunei' => elgg_echo('Brunei'),
																	'Cambodia' => elgg_echo('Cambodia'),
																	'Cyprus' => elgg_echo('Cyprus'),
																	'Gaza' => elgg_echo('Gaza'),
																	'Hong Kong' => elgg_echo('Hong Kong'),
																	'India' => elgg_echo('India'),
																	'Indonesia' => elgg_echo('Indonesia'),
																	'Iran' => elgg_echo('Iran'),
																	'Iraq' => elgg_echo('Iraq'),
																	'Israel' => elgg_echo('Israel'),
																	'Japan' => elgg_echo('Japan'),
																	'Jordan' => elgg_echo('Jordan'),
																	'Kazakhstan' => elgg_echo('Kazakhstan'),
																	'Kuwait' => elgg_echo('Kuwait'),
																	'Kyrgyzstan' => elgg_echo('Kyrgyzstan'),
																	'Laos' => elgg_echo('Laos'),
																	'Lebanon' => elgg_echo('Lebanon'),
																	'Macau' => elgg_echo('Macau (PRC)'),
																	'Malaysia' => elgg_echo('Malaysia'),
																	'Maldives' => elgg_echo('Maldives'),
																	'Mongolia' => elgg_echo('Mongolia'),
																	'Myanmar' => elgg_echo('Myanmar (Burma)'),
																	'Azerbaijan' => elgg_echo('Naxcivan (Azerbaijan)'),
																	'Nepal' => elgg_echo('Nepal'),
																	'North Korea' => elgg_echo('North Korea'),
																	'Oman' => elgg_echo('Oman'),
																	'Pakistan' => elgg_echo('Pakistan'),
																	'China' => elgg_echo('People\'s Republic of China'),
																	'Philippines' => elgg_echo('Philippines'),
																	'Qatar' => elgg_echo('Qatar'),
																	'Taiwan' => elgg_echo('Republic of China (Taiwan)'),
																	'Saudi Arabia' => elgg_echo('Saudi Arabia'),
																	'Singapore' => elgg_echo('Singapore'),
																	'Korea' => elgg_echo('South Korea'),
																	'Sri Lanka' => elgg_echo('Sri Lanka'),
																	'Syria' => elgg_echo('Syria'),
																	'Tajikistan' => elgg_echo('Tajikistan'),
																	'Thailand' => elgg_echo('Thailand'),
																	'East Timor' => elgg_echo('Timor-Leste (East Timor)'),
																	'Turkmenistan' => elgg_echo('Turkmenistan'),
																	'United Arab Emirates' => elgg_echo('United Arab Emirates'),
																	'Uzbekistan' => elgg_echo('Uzbekistan'),
																	'West Bank' => elgg_echo('West Bank'),
																	'Yemen' => elgg_echo('Yemen'),
																	'Russia' => elgg_echo('Russia'),
																	'Georgia' => elgg_echo('Georgia'),
																	'Turkey' => elgg_echo('Turkey'),
																	'American Samoa' => elgg_echo('American Samoa (USA)'),
																	'Australia' => elgg_echo('Australia'),
																	'Christmas Island' => elgg_echo('Christmas Island (Australia)'),
																	'Cocos Islands' => elgg_echo('Cocos (Keeling) Islands (Australia)'),
																	'Cook Islands' => elgg_echo('Cook Islands (NZ)'),
																	'Micronesia' => elgg_echo('Federated States of Micronesia'),
																	'Fiji' => elgg_echo('Fiji'),
																	'French Polynesia' => elgg_echo('French Polynesia (France)'),
																	'Guam' => elgg_echo('Guam (USA)'),
																	'Hawaii' => elgg_echo('Hawaii (USA)'),
																	'Kiribati' => elgg_echo('Kiribati'),
																	'Marshall Islands' => elgg_echo('Marshall Islands'),
																	'Nauru' => elgg_echo('Nauru'),
																	'New Caledonia' => elgg_echo('New Caledonia (France)'),
																	'New Zealand' => elgg_echo('New Zealand'),
																	'Niue' => elgg_echo('Niue (NZ)'),
																	'Norfolk Island' => elgg_echo('Norfolk Island (Australia)'),
																	'Northern Mariana Islands' => elgg_echo('Northern Mariana Islands (USA)'),
																	'Palau' => elgg_echo('Palau'),
																	'Papua New Guinea' => elgg_echo('Papua New Guinea'),
																	'Pitcairn Islands' => elgg_echo('Pitcairn Islands (UK)'),
																	'Samoa' => elgg_echo('Samoa'),
																	'Solomon Islands' => elgg_echo('Solomon Islands'),
																	'Tokelau' => elgg_echo('Tokelau (NZ)'),
																	'Tonga' => elgg_echo('Tonga'),
																	'Tuvalu' => elgg_echo('Tuvalu'),
																	'Vanuatu' => elgg_echo('Vanuatu'),
																	'Wallis and Futuna' => elgg_echo('Wallis and Futuna (France)'),
																	'Wake Islands' => elgg_echo('Wake Islands'),
																	'Coral Sea Islands' => elgg_echo('Coral Sea Islands'),
																	'United States Outlying Islands' => elgg_echo('United States Outlying Islands')),
																    'value' => $value,
															));

				}


                else {
			
					echo elgg_view("input/{$valtype}",array(
															'internalname' => $shortname,
															'value' => $value,
															));
				}
			?>

			<?php echo elgg_view('input/access',array('internalname' => 'accesslevel['.$shortname.']', 'value' => $access_id)); ?>
	</p>

<?php

		}

?>

	<p>
		<input type="hidden" name="username" value="<?php echo page_owner_entity()->username; ?>" />
		<input type="submit" class="submit_button" value="<?php echo elgg_echo("save"); ?>" />
	</p>

</form>
