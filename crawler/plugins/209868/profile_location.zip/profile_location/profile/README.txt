* Elgg profile plugin - Age and Gender add-on
* 
* @package ElggProfile Modified by SGr33n
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author Curverider Ltd <info@elgg.com>
* @modified by SGr33n <sgr33n@ircaserta.com>
* @modified by Le Van Luyen <luyenlv@vietskygroup.com>
* @link http://elgg.com/

-----

Hi People,

This the new Elgg "Profile - Age and Gender" plug-in by SGr33n.

There is a user age calculation based on the date of birth. There is a new
input type, I named "Date": there are 3 pulldowns (day/month/year), and there is a javascript
that recognize uncorrect dates (like 30 february).

The style is not perfect, but I know you will not use the default theme, so
you can style it as you want.

Anyway more to come ;)



INSTALLATION
-----

Replace the original Profile Plug-in with this one

If you have Elgg 1.2, not updated to the last SVN, look at the directoty profile_for_Elgg_1.2_base.

Please post your comments on the elgg community:
http://community.elgg.com

Cya ;)

UPDATES
-----

Profile Age And Gender Plugin 0.1
- First release

Profile Age And Gender Plugin 0.2
- Added compatibility to Elgg 1.2

Profile Age And Gender Plugin 0.3
- Added some files to correct Elgg 1.2 base compatibility

Profile Age And Gender Plugin 0.4
- Fixed: Time ZOne Issue


-----
Sergio De Falco aka SGr33n

www.ircaserta.com
www.myspace.com/sgr33n
http://vietskygroup.com
