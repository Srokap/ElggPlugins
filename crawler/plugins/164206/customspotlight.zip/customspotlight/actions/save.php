<?php

	/**
	 * custom spotlight saver
	 * 
	 * @package customspotlight
	 * @license http://www.gnu.org/licenses/gpl.html GNU Public License version 3
	 * @author Adam Boardman
	 * @copyright Adam Boardman 2009
	 */

	action_gatekeeper();

	$spotlighta = get_input('spotlighta');
	$spotlightb = get_input('spotlightb');
	$spotlightc = get_input('spotlightc');
	$spotlightla = get_input('spotlightla');
	$spotlightlb = get_input('spotlightlb');
	$spotlightlc = get_input('spotlightlc');

	global $CONFIG;
	$site = $CONFIG->site;
	$site->spotlightla = $spotlightla;
	$site->spotlightlb = $spotlightlb;
	$site->spotlightlc = $spotlightlc;
	$site->spotlighta = $spotlighta;
	$site->spotlightb = $spotlightb;
	$site->spotlightc = $spotlightc;
	system_message(elgg_echo("customspotlight:save:success"));
		
	forward($_SERVER['HTTP_REFERER']);

?>
