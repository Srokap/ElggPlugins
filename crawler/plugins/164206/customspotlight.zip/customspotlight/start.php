<?php

        /*
        ** Customise the spotlight
        **
        ** @package customspotlight
        ** @author Adam Boardman
        ** @copyright Adam Boardman 2009
        ** @license http://www.gnu.org/licenses/gpl.html GNU Public License version 3
	**
        */

function customspotlight_init() {
	extend_view('css','customspotlight/css');
	
	global $CONFIG;
	register_action("customspotlight/save", false, $CONFIG->pluginspath . "customspotlight/actions/save.php", true);
}

/**
 * Set up menu items
 *
 */
function customspotlight_pagesetup()
	{
	if (get_context() == 'admin' && isadminloggedin()) {
		global $CONFIG;
		add_submenu_item(elgg_echo('customspotlight:settings'), $CONFIG->wwwroot . 'mod/customspotlight/settings.php');
	}
}

register_elgg_event_handler('init','system','customspotlight_init');
register_elgg_event_handler('pagesetup','system','customspotlight_pagesetup');

?>
