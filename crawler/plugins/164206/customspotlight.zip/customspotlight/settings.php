<?php

	/**
	 * Customisable default spotlight
	 * 
	 * @package customspotlight
	 * @license http://www.gnu.org/licenses/gpl.html GNU Public License version 3
	 * @author Adam Boardman
	 * @copyright Adam Boardman 2009
	 */

	// Load engine and restrict to admins 

	require_once(dirname(dirname(dirname(__FILE__))) . '/engine/start.php');
	admin_gatekeeper();

	// Set context

	set_context('admin');

	// Get site and categories

	global $CONFIG;
	$site = $CONFIG->site;
	$customspotlight = $site->customspotlight;

	if (empty($customspotlight)) $customspotlight = array();

	// Load category save view

	$body = elgg_view('customspotlight/settings',array('customspotlight' => $customspotlight));

	// Layout

	$body = elgg_view_layout('two_column_left_sidebar','', $body);

	// View page
	echo page_draw(elgg_echo('customspotlight:settings'),$body);

?>
