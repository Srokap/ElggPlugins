<?php

	if (isset($vars['entity']) && $vars['entity'] instanceof ElggEntity) {
		
		echo "<p>a</p>".$vars['entity']->spotlighta;
		echo "<p>b</p>".$vars['entity']->spotlightb;
		echo "<p>c</p>".$vars['entity']->spotlightc;
		
	}

?>