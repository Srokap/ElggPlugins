<?php
	/**
	 * Customisable Spotlight CSS extender
	 * 
	 * @package customspotlight
	 * @copyright Adam Boardman 2009
	 */
?>
#spotlight_table .spotlightA {
        float:left;
        position:relative;
        padding:0 0 1em 0;
        width: 33%;
}
#spotlight_table .spotlightB {
        float:left;
        position:relative;
        padding:0 0 1em 0;
        width: 33%;
}
#spotlight_table .spotlightC {
        float:left;
        position:relative;
        padding:0 0 1em 0;
}
