<?php
	global $CONFIG;
	$site = $CONFIG->site;

	echo elgg_view('input/text', array('value' => $site->spotlightla,'internalname' => 'spotlightla'));
	echo elgg_view('input/longtext', array('value' => $site->spotlighta,'internalname' => 'spotlighta'));
	echo elgg_view('input/text', array('value' => $site->spotlightlb,'internalname' => 'spotlightlb'));
	echo elgg_view('input/longtext', array('value' => $site->spotlightb,'internalname' => 'spotlightb'));
	echo elgg_view('input/text', array('value' => $site->spotlightlc,'internalname' => 'spotlightlc'));
	echo elgg_view('input/longtext', array('value' => $site->spotlightc,'internalname' => 'spotlightc'));

?>
	<input type="submit" value="<?php echo elgg_echo('save'); ?>" />
