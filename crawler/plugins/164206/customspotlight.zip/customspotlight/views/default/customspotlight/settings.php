<?php

	echo elgg_view_title(elgg_echo('customspotlight:settings'));

?>

	<div class="contentWrapper">
		<p>
			<?php echo elgg_echo('customspotlight:explanation'); ?>
		</p>

<?php

	echo elgg_view('input/form',
		array(
			'action' => $vars['url'] . 'action/customspotlight/save',
			'method' => 'post',
			'body' => elgg_view('customspotlight/settingsform',$vars)
		)
	);

?>

</div>