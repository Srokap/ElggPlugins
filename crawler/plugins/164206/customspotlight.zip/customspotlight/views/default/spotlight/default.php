<?php

        /*
        * Customise the spotlight
        *
        * @package customspotlight
        * @author Adam Boardman
        * @copyright Adam Boardman 2009
        * @license http://www.gnu.org/licenses/gpl.html GNU Public License version 3
	*
        */

	global $CONFIG;
	$site = $CONFIG->site;
?>

<div id="spotlight_table">
	<div class="spotlightA" />
	<h2><?php echo $site->spotlightla; ?></h2>
	<?php echo $site->spotlighta; ?>
	</div>
	<div class="spotlightB">
	<h2><?php echo $site->spotlightlb; ?></h2>
	<?php echo $site->spotlightb; ?>
	</div>
	<div class="spotlightC">
	<h2><?php echo $site->spotlightlc; ?></h2>
	<?php echo $site->spotlightc; ?>
	</div>
	<div class="clearfloat"></div>
</div>
