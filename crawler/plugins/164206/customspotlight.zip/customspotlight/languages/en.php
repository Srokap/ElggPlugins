<?php

	$english = array(
	
		'customspotlight' => 'Custom Spotlight',
		'customspotlight:settings' => 'Set default spotlight',	
		'customspotlight:explanation' => 'The custom spotlight has three sections, enter content as desired.',	
		'customspotlight:save:success' => 'Site custom spotlight was successfully saved.',
	
	);
					
	add_translation("en",$english);

?>
