<center><b>Edit <i>\mycustomtext\views\default\mytext.php</i> to change this text!</b></center>
