<?php

$file = $_COOKIE['log-filename'];
if (!$file) $file = '/var/log/php/php.log';
$file = elggx_get_input_var($vars, 'file', $file);

$pa = $_SERVER['REQUEST_URI'];
$pb = strpos('pg/testing', $pa)
  ? str_replace('pg/testing', 'pg/vx/testing', $pa)
  : str_replace('pg/vx/testing', 'pg/testing', $pa);

if (file_exists($file)) {
  setcookie('log-filename', $file, 0, $pa);
  setcookie('log-filename', $file, 0, $pb);
}
else {
  $file = "";
}

$refresh = $_COOKIE['log-refresh'];
if (!$refresh) $refresh = 10;
$refresh = elggx_get_input_var($vars, 'refresh', $refresh);
setcookie('log-refresh', $refresh, 0, $pa);
setcookie('log-refresh', $refresh, 0, $pb);

$maxlines = $_COOKIE['log-maxlines'];
if (!$maxlines) $maxlines = 400;
$maxlines = elggx_get_input_var($vars, 'maxlines', $maxlines);
setcookie('log-maxlines', $maxlines, 0, $pa);
setcookie('log-maxlines', $maxlines, 0, $pb);

$filter = elggx_get_input_var($vars, 'filter', $_COOKIE['log-filter']);
if (!$filter) {
  $filter = null;
}
setcookie('log-filter', $filter, 0, $pa);
setcookie('log-filter', $filter, 0, $pb);

$dates = elggx_get_input_var($vars, 'show-dates', isset($_COOKIE['log-show-dates'])?$_COOKIE['log-show-dates']:true);
setcookie('log-show-dates', $dates?$dates:0, 0, $pa);
setcookie('log-show-dates', $dates?$dates:0, 0, $pb);

$types = elggx_get_input_var($vars, 'show-types', isset($_COOKIE['log-show-types'])?$_COOKIE['log-show-types']:true);
setcookie('log-show-types', $types?$types:0, 0, $pa);
setcookie('log-show-types', $types?$types:0, 0, $pb);
$clients = elggx_get_input_var($vars, 'show-clients', isset($_COOKIE['log-show-clients'])?$_COOKIE['log-show-clients']:true);
setcookie('log-show-clients', $clients?$clients:0, 0, $pa);
setcookie('log-show-clients', $clients?$clients:0, 0, $pb);

$checked_date = $dates ? 'checked=checked' : '';
$checked_type = $types ? 'checked=checked' : '';
$checked_client = $clients ? 'checked=checked' : '';
$display_date = $dates ? '' : 'display:none';
$display_type = $types ? '' : 'display:none';
$display_client = $clients ? '' : 'display:none';
$dates_input = elgg_view('input/checkbox', array('internalname'=>'show-dates',
                                                 'label'=>'Show Dates',
                                                 'value'=>$dates));
$types_input = elgg_view('input/checkbox', array('internalname'=>'show-types',
                                                 'label'=>'Show Types',
                                                 'value'=>$types));
$clients_input = elgg_view('input/checkbox', array('internalname'=>'show-clients',
                                                   'label'=>'Show Clients',
                                                   'value'=>$clients));

$refresh_input = elgg_view('input/text', array('internalname'=>'refresh',
                                               'value'=>$refresh));
$lines_input = elgg_view('input/text', array('internalname'=>'maxlines',
                                             'value'=>$maxlines));
$file_input = elgg_view('input/text', array('internalname'=>'file',
                                            'value'=>$file));
$filter_input = elgg_view('input/text', array('internalname'=>'filter',
                                              'value'=>$filter));
$submit = elgg_view('input/submit', array('value'=>'Reload')); 

$form_body = <<<END
<div>
<label>Refresh interval{$refresh_input}</label><br/>
<label>Max lines{$lines_input}</label><br/>
<label>Log file{$file_input}</label><br/>
{$dates_input}
{$types_input}
{$clients_input}
<br/>
<label>Filter{$filter_input}</label>
<input type='hidden' name='shell' value='no'/>
</div>
{$submit}
END;

$form = elgg_view('input/form', array('internalid'=>'log-form',
                                      'method'=>'get',
                                      'action'=>$vars['url'] . 'pg/vx/testing/log',
                                      'body'=>$form_body));

if (empty($file)) {
  $contents = "No file specified";
}
else if (file_exists($file)) {
  $fd = fopen($file, 'r');
  $lines = array();
  $start = 0;
  while ($line = fgets($fd)) {
    if ($filter) {
      if ($filter{0} == '/') {
        if (!preg_match($filter, $line)) {
          continue;
        }
      }
      else if (strpos($line, $filter) === false) {
        continue;
      }
    }

    $line = preg_replace('/^\[([^]]+)\] \[([^]]+)\] \[([^]]+)\] (.*)$/', 
                         "<span class=date style='{$display_date}'>\\1</span> "
                         ."<span class=type style='{$display_type}'>\\2</span> "
                         ."<span class=client style='{$display_client}'>\\3</span> "
                         ."<span class=log-message>\\4</span>", $line);

    $line = str_replace('WARNING', '<span class=warning>WARNING</span>', $line);
    $line = str_replace('ERROR', '<span class=error>ERROR</span>', $line);

    $lines[] = $line;
    if (count($lines) > $maxlines) {
      unset($lines[$start++]);
    }
  }
  fclose($fd);
  
  $contents = implode("<br/>", array_slice($lines, 0));
}
else {
  $contents = "File '{$file}' does not exist";
}

echo <<<END
<div id='log' style='margin:8px'>
{$form}
<h1>Log Contents</h1>
<div id='log-contents'>
{$contents}
</div>
<script type='text/javascript'>
$(document).ready(function() {
    setInterval('$("form").submit()', {$refresh} * 1000);
    var form = $('#log form');
    form.submit(function() {
        $.elgg.busy($('form'));
        $('#log-contents').load(form.attr('action') + ' #log-contents',
                                form.serializeArray(), function() {
                                  $.elgg.busy($('form'), false);
          });
        return false;
      });
    $('input[name*=show-dates]').change(function() {
        $('span.date').toggle();
      });
    $('input[name*=show-types]').change(function() {
        $('span.type').toggle();
      });
    $('input[name*=show-client]').change(function() {
        $('span.client').toggle();
      });
});
</script>
</div>
END;
?>