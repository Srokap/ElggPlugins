<?php

  /**
     Display test results and links to run tests.
   */

require_once('PHPUnit/TextUI/TestRunner.php');

$tests = "<a href='#all' test_class='all'>Run All Tests</a><p/>";
$tests .= "Run Module Tests<p/>";
$tests .= "<div class='tests ui-helper-clearfix'>";

$paths = testing_get_search_paths();
foreach ($paths as $path) {
  $tests .= "<div class='test-group' title='from mod/".basename($path)."/tests'><h3>".basename($path)."</h3><ul test_class='{$path}'>";
  $collector = new PHPUnit_Runner_IncludePathTestCollector(array($path));
  $files = $collector->collectTests();
  $count = 0;
  foreach ($files as $file) {
    ++$count;
    $name = str_replace(".php", "", basename($file));
    $tests .= "<li><a href='#{name}' title='Run all tests in this class' test_class='{$name}'>{$name}</a></li>";
  }
  if ($count == 0) {
    $tests .= "<li class='no-tests'>No tests found</li>";
  }
  $tests .= "</ul></div>";
}
$tests .= "</div>";

if (!($user = get_loggedin_user())) {
  $userinfo = "Not logged in";
}
else {
  $userinfo = "Logged in as {$user->username} ({$user->getGUID()})";
}

echo <<<END
<h1>Automated Testing</h1>
<p>{$userinfo}</p>
<p><a href='{$vars['url']}pg/admin/plugins'>Change Settings</a></p>
<h2>Tests</h2>
{$tests}
<style type='text/css'>
.famos .tests .test-group { float: left; margin-right: 14px; }  
.famos .tests .test-group ul { border-left: 1px solid gray; }
.famos .tests .test-group li { margin-left: -15px; }
.famos .no-tests { font-style: italic; color: gray; }
</style>

<h2>Results</h2>
<div class='results'></div>

<script sid='testing/runner' type='text/javascript'>
$(function() {
    var run_test = function(cls, method) {
        var busy = $.elgg.busy('.results');
        var url = '{$vars['url']}pg/testing';
        var suffix = '';
        var msg = "Running";
        if (cls) {
          suffix += '/' + cls;
          msg += ' ' + cls;
          if (method) {
            suffix += '/' + method;
            msg += ':' + method;
          }
        }
        $('.results').html(msg + "...");
        var url = '{$vars['url']}pg/testing' + suffix + "?shell=none";
        $.get(url, function(data) {
            busy.remove();
            $('.results').html(data);
            $('.results a').click(function() {
                run_test($(this).attr('test_class'), $(this).attr('test_method'));
                return false;
              });
          });
    };
    $('.tests a').click(function() {
        run_test($(this).attr('test_class'), $(this).attr('test_method'));
        return false;
      });
  });
</script>

END;
?>