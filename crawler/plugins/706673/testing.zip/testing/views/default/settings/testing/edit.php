<p>
<?php
 /** Testing plugin settings editing view. */
echo "<p>Go to the <a href='" . $vars['url'] . "pg/testing'>Testing Page</a></p>";

echo "<fieldset><legend>" . elgg_echo('testing:options') . "</legend>";

$flags = array(
  'verbose',
  'convertErrorsToExceptions',
  'convertWarningsToExceptions',
  'convertNoticesToExceptions',
               );
foreach($flags as $flag) {
  echo elgg_view('input/checkbox',
                 array('internalname'=>"params[{$flag}]",
                       'label'=>elgg_echo("testing:{$flag}"),
                       'value'=>$vars['entity']->$flag));
  echo "<br/>";
}

echo "</fieldset><fieldset>";
echo "<legend>".elgg_echo('testing:tests')."</legend>";
echo elgg_view('input/radio',
               array('internalname'=>"params[autoscan]",
                     'value'=>$vars['entity']->autoscan,
                     'options'=>array(elgg_echo('testing:autoscan')=>true,
                                      elgg_echo('testing:find')=>false)));

echo "<div id='find_options'>";
echo "<h5>" . elgg_echo('testing:enabled') . "</h5>";
$plugins = array_values(get_plugin_list());
foreach($plugins as $plugin) {
  if (!is_plugin_enabled($plugin)) continue;

  $field = "test_{$plugin}";
  echo elgg_view('input/checkbox',
                 array('internalname'=>"params[{$field}]",
                       'label'=>$plugin,
                       'value'=>$vars['entity']->$field));
  echo "<br/>";
}

echo "<h5>".elgg_echo('testing:additional')."</h5>";
echo elgg_view('input/text',
               array('internalname'=>"params[additional]",
                     'value'=>$vars['entity']->additional));
echo "</div></fieldset>";

echo <<<END
<script type='text/javascript'>
  $(document).ready(function() {
      var label = $('input[name="params[autoscan]"]').parent();
      $('input[type=radio]', label).change(function() {
          if ($('input[type=radio][value=1]').is(':checked')) {
            $('#find_options input').attr('disabled', 'true');
            $('#find_options label').attr('disabled', 'true');
          }
          else {
            $('#find_options input').removeAttr('disabled');
            $('#find_options label').removeAttr('disabled');
          }
        });
    });
</script>
END;
?>
</p>