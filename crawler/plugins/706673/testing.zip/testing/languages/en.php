<?php
global $CONFIG;

$english = array(
                 'testing' => 'Testing',
                 'testing:desc' => 'Provides support for unit testing within the Elgg environment.',
                 'testing:autoscan'=>"Autoscan for all unit tests<br/><em>(all files named XXXTest.php below {$CONFIG->path})</em>",
                 'testing:additional'=>"Additional directories to scan<br/><em>(relative to Elgg root {$CONFIG->path})</em>",
                 'testing:enabled'=>'Scan for unit tests in these plugins',

                 'testing:verbose'=>'Verbose output',
                 'testing:convertErrorsToExceptions'=>'Convert errors to exceptions',
                 'testing:convertWarningsToExceptions'=>'Convert warnings to exceptions',
                 'testing:convertNoticesToExceptions'=>'Convert notices to exceptions',
                 'testing:options'=>'Test runner options',
                 'testing:tests'=>'Tests to be run (from /pg/testing)',
                 'testing:find'=>'Specify where to search for tests',
                 );

add_translation("en",$english);
?>
