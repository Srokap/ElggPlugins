<?php

class ElggInputsTest extends ElggTestCase
{
  public function runGetInputTest() {
    echo json_encode(get_input('data'));
  }

  /** As of elgg 1.5, page handlers obliterate the $_GET array. */
  public function testPageHandlerInputs() {
    global $CONFIG;
    $value = array('text1','text2');
    $response = $this->get($CONFIG->url . 'pg/testing/ElggInputsTest/runGetInputTest', array('data'=>$value));
    $this->assertEquals(json_encode($value), $response, 'Wrong GET data');
  }
}


?>