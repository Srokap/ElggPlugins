PHPUnit Test Runner
-------------------
See ExampleTest.php for an example test case.

See ElggTestCase.php for methods facilitating tests within the Elgg framework.

Methods of note:
* action: run an elgg action, automatically handling form tokens
* get/post: invoke an arbitrary GET/POST request
* addTestUser: add or note a user scoped to the test lifetime
* pg/testing/<class>/<method>: this API may be used to run arbitrary
methods/return results in the context of an HTTP session.

NOTE: PHPUnit uses your system's 'diff' executable.  If
open_basedir is active, you'll need to add the path to it so that
PHPUnit can use it to generate diff messages in errors.  

NOTE: PHPUnit also attempts to read the local php binary, but this is not
required for proper operation.