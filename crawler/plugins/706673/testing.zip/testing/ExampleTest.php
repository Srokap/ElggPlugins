<?php

class ExampleTest extends ElggTestCase
{
  public function testOneAssertion() {
    $this->assertTrue(true, 'Simple assertion');
  }
  public function testOneFailure() {
    try {
      $this->assertFalse(true, 'Simple assertion');
      $this->fail("Test should already have failed");
    }
    catch(Exception $e) {
    }
  }
  public function testOneLogWarning() {
    if (!get_plugin_setting('convertWarningsToExceptions', 'testing')) 
      return;

    try {
      trigger_error("This is a warning", E_USER_WARNING);
      $this->fail("Test should already have failed");
    }
    catch(Exception $e) {
    }
  }
  public function testOneLogError() {
    if (!get_plugin_setting('convertErrorsToExceptions', 'testing')) 
      return;

    try {
      trigger_error("This is an error", E_USER_ERROR);
      $this->fail("Test should already have failed");
    }
    catch(Exception $e) {
    }
  }
  public function testOneLogNotice() {
    if (!get_plugin_setting('convertNoticesToExceptions', 'testing')) 
      return;

    try {
      trigger_error("This is a notice", E_USER_NOTICE);
      $this->fail("Test should already have failed");
    }
    catch(Exception $e) {
    }
  }
}


?>