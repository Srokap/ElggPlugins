<?php

require_once('PHPUnit/Framework/TestSuite.php');

/** Base test class for anything that needs to run under Elgg. */
// TODO: need facilities for logging in as a given user for the duration
// of a test
// TODO: auto-remove all objects with metadata test_object=true
abstract class ElggTestCase extends PHPUnit_Framework_TestCase
{
  const TEST_USER = 'test_user';
  const TEST_PASSWORD = 'ATestUser';
  const TEST_EMAIL = 'test_user@testing.org';
  // Create objects with this subtype to have them automatically disposed
  const TEST_SUBTYPE = 'test-object';
  const TEST_METADATA = 'test_metadata';

  // Setting $backupGlobals false prevents PHPUnit from restoring globals'
  // state and erasing the results of any elgg lazy init.
  protected $backupGlobals = FALSE;

  // Current cURL session, if any
  protected $curl;
  private $cookies;

  // Preserve the logged-in user between tests
  private $user;

  protected function deleteOnExit($obj) {
    if ($obj && is_object($obj)) {
      $field = TEST_METADATA;
      $obj->$field = true;
    }
    return $obj;
  }

  /** Extract a single system error message (from register_error). */
  // TODO: return an array of all of them
  protected function extract_error($response) {
    if (preg_match('/^.*<div class="messages_error">(.*?)<\\/div.*$/s',
                   $response, $matches)) {
      return preg_replace('/^.*<p>(.*?)<\\/p>.*$/s', '\\1', $matches[1]);
    }
    return false;
  }

  /** Extract a single system message (from system_message). */
  // TODO: return an array of all of them
  protected function extract_message($response) {
    if (preg_match('/^.*<div class="messages">(.*?)<\\/div.*$/s',
                   $response, $matches)) {
      return preg_replace('/^.*<p>(.*?)<\\/p>.*$/s', '\\1', $matches[1]);
    }
    return false;
  }

  protected function parse_cookies($headers, &$cookies) {
    $lines = explode("\r\n", $headers);
    foreach($lines as $line) {
      if (strpos($line, 'Set-Cookie: ') === 0) {
        if (preg_match('/[^:]:\\s*([^=]+)=([^;]+);.*/', $line, $matches)) {
          $cookies[$matches[1]] = urldecode($matches[2]);
        }
      }
    }
    return $cookies;
  }

  // This method should be used for any requests which require session
  // information
  protected function get($url, $data = array(), &$cookies = false) {
    $data['__userid'] = get_loggedin_userid();
    if (strpos($url, '?') === false)
      $url .= '?';
    $url .= http_build_query($data);

    if (!$this->curl) {
      $this->curl = curl_init();
      $this->cookies = tempnam(sys_get_temp_dir(), 'CURLCOOKIES');
      if ($cookies) {
        foreach($cookies as $key=>$value) {
          $cookie_data .= "{$key}={$value}; ";
        }
      }
    }
    curl_setopt_array($this->curl, array(CURLOPT_URL=>$url,
                                         CURLOPT_HTTPGET=>true,
                                         CURLOPT_RETURNTRANSFER=>true,
                                         CURLOPT_COOKIEJAR=>$this->cookies,
                                         CURLOPT_COOKIEFILE=>$this->cookies,
                                         CURLOPT_COOKIE=>$cookie_data,
                                         CURLOPT_HEADER=>true,
                                         ));
    if (!ini_get('safe_mode') && !ini_get('open_basedir')) {
      curl_setopt($this->curl, CURLOPT_FOLLOWLOCATION, true);
    }

    $response = curl_exec($this->curl);
    if ($response === false) {
      throw new Exception("GET from {$url} failed: {$php_errormsg}");
    }

    list($headers, $body) = explode("\r\n\r\n", $response, 2);
    // Forward manually, in case we couldn't use CURLOPT_FOLLOWLOCATION
    if (preg_match('/Location:(.*?)\r\n/', $headers, $matches)) {
      return $this->get(trim($matches[1]), $data, $cookies);
    }

    if ($cookies) {
      $cookies = $this->parse_cookies($headers, $cookies);
    }

    return $body;
  }

  // This method should be used for any requests which require session
  // information
  protected function post($url, $data = array(), &$cookies=false) {
    $data['__userid'] = get_loggedin_userid();
    if (!$this->curl) {
      $this->curl = curl_init();
      $this->cookies = tempnam(sys_get_temp_dir(), 'CURLCOOKIES');
      if ($cookies) {
        foreach($cookies as $key=>$value) {
          $cookie_data .= "{$key}={$value}; ";
        }
      }
    }
    // CURLOPT_POSTFIELDS can't handle arrays
    $pdata = array();
    foreach($data as $key=>$value) {
      if (is_array($value)) {
        foreach($value as $k=>$v) {
          $pdata["{$key}[{$k}]"] = $v;
        }
      }
      else {
        $pdata[$key] = $value;
      }
    }
    curl_setopt_array($this->curl, array(CURLOPT_URL=>$url,
                                         CURLOPT_POST=>true,
                                         CURLOPT_POSTFIELDS=>$pdata,
                                         CURLOPT_RETURNTRANSFER=>true,
                                         CURLOPT_COOKIEJAR=>$this->cookies,
                                         CURLOPT_COOKIEFILE=>$this->cookies,
                                         CURLOPT_COOKIE=>$cookie_data,
                                         CURLOPT_HEADER=>true,
                                         ));
    if (!ini_get('safe_mode') && !ini_get('open_basedir')) {
      curl_setopt($this->curl, CURLOPT_FOLLOWLOCATION, true);
    }

    $response = curl_exec($this->curl);
    if ($response === false) {
      throw new Exception("POST to {$url} failed: {$php_errormsg}");
    }

    list($headers, $body) = explode("\r\n\r\n", $response, 2);
    // FIXME do this properly: handle HTTP/1.1 100 Continue
    if (strpos($body, 'HTTP') === 0) {
      list($headers, $body) = explode("\r\n\r\n", $body, 2);
    }

    // Forward manually, in case we couldn't use CURLOPT_FOLLOWLOCATION
    if (preg_match('/Location:(.*?)\r\n/', $headers, $matches)) {
      return $this->post(trim($matches[1]), $data, $cookies);
    }

    if ($cookies) {
      $cookies = $this->parse_cookies($headers, $cookies);
    }

    return $body;
  }

  /** Return the results of an elgg action (via POST). */
  protected function action($action, $data = array(), &$cookies = false) {
    global $CONFIG;
    $url = elgg_add_action_tokens_to_url("{$CONFIG->url}action/{$action}");

    return $this->post($url, $data, $cookies);
  }

  /** Add another user for testing. */
  protected function addTestUser($username, $password, $email, $validate=false) {
    $user = get_user_by_username($username);
    if (!$user) {
      $guid = register_user($username, $password, $username, $email);
      if (!$guid) {
        throw new Exception("register_user failed for '".$username."'");
      }
      $user = get_user($guid);
    }
    if ($validate) {
      request_user_validation($user->getGUID());
    }
    else {
      $user->validated = true;
    }
    return $this->deleteOnExit($user);
  }

  protected function setUp() {
    $this->session = self::saveSession();
    // always add a test user
    $ignore = elgg_get_ignore_access();
    elgg_set_ignore_access(true);
    $user = get_user_by_username(self::TEST_USER);
    if ($user) {
      if (!$user->delete()) {
        elgg_set_ignore_access($ignore);
        throw new Exception("Test user already exists and can't delete it, aborting");
      }
    }
    elgg_set_ignore_access($ignore);
    $this->addTestUser(self::TEST_USER, self::TEST_PASSWORD, self::TEST_EMAIL);
  }

  // clear any system error messages generated by tests
  protected function clearMessages() {
    $msgs = system_messages("messages");
    $errs = system_messages("errors");
  }

  private static function saveSession() {
    return array('guid'=>get_loggedin_userid(),
                 'code'=>$_SESSION['code'],
                 'id'=>$_SESSION['id'],
                 'username'=>$_SESSION['username'],
                 'name'=>$_SESSION['name']);
  }

  private static function restoreSession($session) {
    $_SESSION['user'] = get_entity($session['guid']);
    $_SESSION['guid'] = $session['guid'];
    $_SESSION['code'] = $session['code'];
    $_SESSION['username'] = $session['username'];
    $_SESSION['name'] = $session['name'];
    if ($user = get_entity($session['guid'])) {
      login($user);
    }
  }

  protected function tearDown() {

    $ignore = elgg_get_ignore_access();
    elgg_set_ignore_access(true);
    $failed = array();

    if ($this->curl) {
      curl_close($this->curl);
    }
    if (file_exists($this->cookies)) {
      unlink($this->cookies);
    }

    $this->clearMessages();

    $delete = array();
    $list = elgg_get_entities(array('types'=>'object',
                                    'subtypes'=>TEST_SUBTYPE,
                                    'limit'=>100));
    if ($list) $delete = array_merge($delete, $list);
    $list = elgg_get_entities_from_metadata(array('metadata_names'=>TEST_METADATA,
                                                  'limit'=>100));
    if ($list) $delete = array_merge($delete, $list);
    foreach($delete as $obj) {
      if (get_entity($obj->getGUID())
          && !$obj->delete()) {
        $failed[] = $obj;
      }
    }
    elgg_set_ignore_access($ignore);

    // Restore original login, if necessary
    self::restoreSession($this->session);
    unset($this->session);

    if (count($failed)) {
      throw new Exception("could not remove one or more test objects after test: " . print_r($failed, true));
    }
  }
}

?>