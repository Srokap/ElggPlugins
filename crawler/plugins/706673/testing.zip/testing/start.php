<?php

  /**
   * Testing Plugin
   * Facilitate execution of various types of tests
   *
   * Run PHPUnit from the web server to avoid any potential differences with
   * the CLI environment.
   *
   * @package famos
   * @author famos LLC <info@famos.com>
   * @copyright famos LLC 2009
   * @link http://famos.com/
   */

function testing_init() {

  if (preg_match('/\/testing\/log/', current_page_url())) {
    // Turn off logging for display of this page
    ini_set('error_log', '/dev/null');
    require_once('Log.php');
    $logger = Log::singleton('error_log');
    $logger->setMask(0);
  }

  register_translations(dirname(__FILE__) . '/languages/');
  register_page_handler('testing', 'testing_page_handler');

  // auto-login on local testing requests
  $local = preg_match('/^(localhost|127.0.0.1)$/', $_SERVER['REMOTE_ADDR']);
  if ($local && get_input('__userid')) {
    $user = get_entity(get_input('__userid'));
    $_SESSION['user'] = $user;
    $_SESSION['guid'] = $user->getGUID();
  }
}

function testing_page_handler($path) {

  $user = get_loggedin_user();

  switch($path[0]) {
  case 'action-tokens':
    $ts = time();
    $token = generate_action_token($ts);
    echo json_encode(array('ts'=>$ts, 'token'=>$token));
    break;
  case 'log':
    if (!isadminloggedin()) {
      register_error("You must be logged in as administrator to view the log");
      forward(famos_login_url(current_page_url(), "admin", true));
    }
    $body = elgg_view('pageshells/basic', array('title'=>'Log', 'body'=>elgg_view('testing/log')));
    page_draw("Log File", $body);
    break;
  case 'debug':
    // When you want to get some info...
    setcookie('foo', 'cookie');
    echo "_GET: " . $_GET['foo'] . "\n";
    echo "_POST: " . $_POST['foo'] . "\n";
    echo "_COOKIE: " . $_COOKIE['foo'] . "\n";
    echo "_REQUEST: " . $_REQUEST['foo'] . "\n";
    echo "get_input('foo'): " . get_input('foo', 'default') . "\n";
    break;
  default:

    $local = preg_match('/^(localhost|127.0.0.1)$/', $_SERVER['REMOTE_ADDR']);
    if (!isadminloggedin() || !$local) {
      register_error("You must be logged in as administrator to run tests");
      forward(famos_login_url(current_page_url(), "admin", true));
      break;
    }

    // direct nav ('all'); populate page, start running
    // direct nav w/test (class under test); populate page, start running
    // API nav w/test (actual test run); no page, start running
    $class = $path[0];
    $method = $path[1];

    // Main testing view
    if (!$class) {
      echo page_draw("AutomatedTests",
                     elgg_view('testing/runner'));
      break;
    }

    if ($local && get_input('__userid')) {
      $user = get_entity(get_input('__userid'));
      $_SESSION['user'] = $user;
      $_SESSION['guid'] = $user->getGUID();
    }

    if ($class == 'all') {
      $class = false;
    }
    ob_start();
    try {
      testing_run_tests($class, $method);
      $body = ob_get_clean();
    }
    catch(Exception $e) {
      
      $body = 'Could not create and run test suite: ' . $e->getMessage();
      $body .= "<br/>" . str_replace("\n", "<br/>", $e->getTraceAsString());
      $body .= "<br/>Output: " . ob_get_clean();
    }
    // Clear elgg system error messages
    system_messages(null, "messages");
    system_messages(null, "errors");
    
    $manifest = load_plugin_manifest('testing');
    $version = $manifest['version'];
    
    // Standalone method invocations get passed back raw
    if ($method && strpos($method, 'test') !== 0) {
      echo $body;
    }
    else {
      $body = testing_format_output($body);
      echo "Elgg Test Runner {$version} by Timothy Wall.<br/>{$body}";
    }
  
    break;
  }
}

function testing_format_output($results) {
  $errors = preg_match('/^There .* errors?:$/m', $results);
  $failures = preg_match('/^There .* failures?:$/m', $results);
  
  $results = preg_replace('/^(There.*errors?:\n\n)(([1-9][0-9]*\\).*?\n\n)*)/ms', '<span id="error-header">\\1</span><div id="phpunit-errors">\\2</div>', $results);
  $results = preg_replace('/^(There.*failures?:\n\n)(([1-9][0-9]*\\).*?\n\n)*)/ms', '<span id="failure-header">\\1</span><div id="phpunit-failures">\\2</div>', $results);
  
  if ($errors && $failures) {
    list($errors, $failures) = explode('--', $results, 2);
    $body = preg_replace('/([1-9][0-9]*\\) )([^\\(]+)\\(([^\\)]+)\\)([^\n]*)(\n.*?)\n\n/ms',
                         "<span class='phpunit error'>\\1<a title='Re-run this test' href='#\\3/\\2' test_class='\\3' test_method='\\2'>\\2(\\3)</a>\\4\\5</span>\n\n", $errors);
    $body .= "--\n\n";
    $body .= preg_replace('/([1-9][0-9]*\\) )([^\\(]+)\\(([^\\)]+)\\)([^\n]*)(\n.*?)\n\n/ms',
                          "<span class='phpunit failure'>\\1<a title='Re-run this test' href='#\\3/\\2' test_class='\\3' test_method='\\2'>\\2(\\3)</a>\\4\\5</span>\n\n", $failures);
  }
  else {
    $type = $errors ? 'error' : 'failure';
    $body = preg_replace('/([1-9][0-9]*\\) )([^\\(]+)\\(([^\\)]+)\\)([^\n]*)(\n.*?\n\n)/ms',
                         "<span class='phpunit {$type}'>\\1<a title='Re-run this test' href='#\\3/\\2' test_class='\\3' test_method='\\2'>\\2(\\3)</a>\\4\\5</span>\n\n", $results);
  }
  
  $body = str_replace("--\n\n\n\n\n", "\n", $body);
  $body = str_replace("\n", "<br/>", $body);
  
  $body .= <<<END
<script type='text/javascript'>
$(document).ready(function() {
    $('#error-header').click(function() { $('#phpunit-errors').slideToggle(); });
    $('#failure-header').click(function() { $('#phpunit-failures').slideToggle(); });
});
</script>
END;
  return $body;
}

function testing_get_search_paths() {
  global $CONFIG;
  $paths = array();
  if (get_plugin_setting('autoscan', 'testing')) {
    $paths[] = realpath($CONFIG->path);
  }
  else {
    $plugins = array_values(get_plugin_list());
    foreach($plugins as $plugin) {
      if (is_plugin_enabled($plugin)
          && get_plugin_setting("test_{$plugin}", 'testing')) {
        $paths[] = realpath($CONFIG->pluginspath . '/' . $plugin);
      }
    }

    $more = explode(' ', get_plugin_setting('additional', 'testing'));
    foreach ($more as $dir) {
      if (empty($dir)) continue;
      $paths[] = realpath($CONFIG->path . '/' . $dir);
    }
  }
  return $paths;
}

function testing_find_file($name, $dir = false) {
  $file = false;
  if (!$dir) {
    $paths = testing_get_search_paths();
    foreach ($paths as $path) {
      if (($file = testing_find_file($name, $path)) !== false) {
        break;
      }
    }
  }
  else {
    $path = "{$dir}/{$name}";
    if (file_exists($path)) {
      $file = $path;
    }
    else {
      $d = dir($dir);
      while (($entry = $d->read()) !== false) {
        $path = "{$dir}/{$entry}";
        if (is_dir($path)) {
          if ($entry == '.' || $entry == '..') {
            continue;
          }
          if (($file = testing_find_file($name, $path)) !== false) {
            break;
          }
        }
      }
      $d->close();
    }
  }
  return $file;
}

function testing_run_tests($class=false, $method=false) {

  require_once('PHPUnit/TextUI/TestRunner.php');
  require_once('PHPUnit/Framework/TestSuite.php');
  require_once(dirname(__FILE__) . '/ElggTestCase.php');

  // Give tests a long timeout; default is 30s, give tests 5min
  ini_set('max_execution_time', 300);

  $runner = new PHPUnit_TextUI_TestRunner;
  $suite = new PHPUnit_Framework_TestSuite();

  if ($class) {
    $file = testing_find_file($class . ".php");
    if (!$file) {
      throw new Exception("Can't find file for '{$class}'");
    }
    if ($method) {
      // Methods need special handling for annotations
      require_once($file);
      if (strpos($method, 'test') === 0) {
        $suite->addTest($suite->createTest(new ReflectionClass($class), $method));
      }
      else {
        $obj = new $class;
        $obj->$method();
        return;
      }
    }
    else {
      $suite->addTestFile($file);
    }
  }
  else {
    $paths = testing_get_search_paths();
    foreach ($paths as $dir) {
      // Let the test runner scan each directory
      $suite->addTest($runner->getTest($dir));
    }
  }

  // TODO: use a custom runner to emit the output as it is produced
  // and format it the way we want instead of parsing text
  
  $config = find_plugin_settings('testing');
  // FIXME: runner is picky about boolean values
  $arguments = array('convertErrorsToExceptions'=>$config->convertErrorsToExceptions?true:false,
                     'convertWarningsToExceptions'=>$config->convertWarningsToExceptions?true:false,
                     'convertNoticesToExceptions'=>$config->convertNoticesToExceptions?true:false,
                     'verbose'=>$config->verbose?true:false);
  $runner->doRun($suite, $arguments);
}

register_elgg_event_handler('init','system','testing_init');

?>