<?php
$english = array(
	'agerestriction' => "I swear to high heaven that I'm of full age (18 years or older).",

	'agerestriction:required' => "You must confirm to be of full age (18 years or older) to join.",
);

add_translation("en",$english);
