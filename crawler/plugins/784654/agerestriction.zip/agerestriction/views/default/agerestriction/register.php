<?php
/**
 *
 */
?>
<label>
	<input type="checkbox" name="agevalid" value="true">
	<?php echo elgg_echo('agerestriction')."</a>"; ?>
</label><br/>