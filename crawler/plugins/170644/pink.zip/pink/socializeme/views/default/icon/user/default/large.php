<?php
	echo $vars['url'] . "mod/socializeme/graphics/user_icons/defaultlarge.gif";
?>