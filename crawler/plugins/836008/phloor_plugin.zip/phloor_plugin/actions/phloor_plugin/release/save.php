<?php 
/*****************************************************************************
 * Phloor Plugin                                                            *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php

action_gatekeeper();

// store errors to pass along
$error = FALSE;
$error_forward_url = REFERER;

$plugin_guid = get_input('plugin_guid', 0, true);
$plugin = get_entity($plugin_guid);
if(!phloor_plugin_instanceof($plugin)) {
	register_error(elgg_echo("phloor_plugin:release:error:invalid:plugin_guid"));
	return false;
}
		
$release = NULL;
$new_release = TRUE;

// edit or create a new entity
$release_guid = get_input('guid');
if ($release_guid) {
	$release = get_entity($release_guid);
	
	if (!phloor_plugin_release_instanceof($release) || !$release->canEdit()) {
		register_error(elgg_echo('phloor_plugin:release:error:release_not_found'));
		forward(get_input('forward', REFERER));
		exit;
	}

	$new_release = FALSE;
	
	// delete former file if new file was uploaded
	if (isset ($_FILES['file']['name']) && 
		!empty($_FILES['file']['name'])) {
		// delete former file
		$plugin->deleteFile();
	}
} else {
	// check if upload failed
	if (empty($_FILES['file']['name']) || $_FILES['file']['error'] != 0) {
		register_error(elgg_echo('phloor_plugin:release:error:cannot_load_file'));
		forward(REFERER);
		exit;
	}
	$release = new PhloorPluginRelease();
	$new_release = TRUE;
}

// get form inputs from POST var
$params = phloor_plugin_release_get_input_vars();
$params['title'] = $plugin->title;

$is_recommended_release = $params['recommended_release'];

// save settings and display success message
if (phloor_plugin_release_save_vars($release, $params)) {
	// remove sticky form entries
	elgg_clear_sticky_form('phloor_plugin_release');
	system_message(elgg_echo('phloor_plugin:release:message:saved'));

	if(strcmp('true', $is_recommended_release) == 0) {
		$plugin->setRecommendedRelease($release);
	}
	
	if ($new_release) {
		// create relationship to plugin		
		if(!check_entity_relationship($plugin_guid, 'phloor_plugin_release', $release->getGUID())) {
			add_entity_relationship($plugin_guid, 'phloor_plugin_release', $release->getGUID());
		}
		
		// push to river
		add_to_river('river/object/phloor_plugin_release/create', 'create', elgg_get_logged_in_user_guid(), $release->getGUID());
	}
		
	forward($plugin->getURL());	
} 
// ... or display an error message on failures.
else {
	register_error(elgg_echo('phloor_plugin:release:error:cannot_save'));
	forward($_SERVER['HTTP_REFERER']);
}

exit();
