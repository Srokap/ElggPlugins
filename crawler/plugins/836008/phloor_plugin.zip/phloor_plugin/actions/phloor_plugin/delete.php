<?php 
/*****************************************************************************
 * Phloor Plugin                                                            *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php
/**
 * Delete plugin entity
 *
 */
action_gatekeeper();

$plugin_guid = get_input('guid');
$plugin = get_entity($plugin_guid);

$url = elgg_get_site_url() . phloor_plugin_url_handler($plugin);

if (phloor_plugin_instanceof($plugin) && $plugin->canEdit()) {
	$container = get_entity($plugin->container_guid);
	
	// delete plugin entity
	if ($plugin->delete()) {
		system_message(elgg_echo('phloor_plugin:message:deleted_plugin'));

		// if DID NOT came from object site.. refere him back..
		if(strpos($url, REFERER) === 0) {
			forward(REFERER);
		}
		
		if (elgg_instanceof($container, 'group')) {
			forward("phloor_plugin/group/$container->guid/all");
		} else {
			forward("phloor_plugin/owner/$container->username");
		}

		exit();
	} else {
		register_error(elgg_echo('phloor_plugin:error:cannot_delete_plugin'));
	}
} else {
	register_error(elgg_echo('phloor_plugin:error:plugin_not_found'));
}

forward(REFERER);