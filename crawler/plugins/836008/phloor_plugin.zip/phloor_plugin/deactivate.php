<?php

if (get_subtype_id('object', 'phloor_plugin')) {
	update_subtype('object', 'phloor_plugin');
} 

if (get_subtype_id('object', 'phloor_plugin_release')) {
update_subtype('object', 'phloor_plugin_release');
} 