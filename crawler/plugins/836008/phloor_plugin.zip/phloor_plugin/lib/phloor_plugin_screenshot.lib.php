<?php 
/*****************************************************************************
 * Phloor Plugin                                                             *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php

/**
 * Default attributes
 * 
 * @return array with default values
 */
function phloor_plugin_screenshot_default_vars() {
	$defaults = array(
		'title' => '',
	    'description'  => '',
	    'image' => '',
	    'tags' => NULL,
	    'comments_on' => 'On',
		'access_id' => ACCESS_DEFAULT,
	);
	
	return $defaults;
}

/**
 * Load vars from post or get requests and returns them as array
 * 
 * @return array with values from the request
 */
function phloor_plugin_screenshot_get_input_vars() {
	// set defaults and required values
	$values = phloor_plugin_screenshot_default_vars();
	$values['container_guid'] = (int)get_input('container_guid', '');
		
	$user = elgg_get_logged_in_user_entity();
	// load from plugin_screenshot and do sanity and access checking
	foreach ($values as $name => $default) {
		$value = get_input($name, $default);
		switch ($name) {
			// get the image from $_FILES array
			case 'image':
				$values['image'] = $_FILES['image'];
				break;
			case 'container_guid':
				// this can't be empty or saving the base entity fails
				if (!empty($value)) {
					if (can_write_to_container($user->getGUID(), $value)) {
						$values['container_guid'] = $value;
					}
				}
				break;
			// don't try to set the guid
			case 'guid':
				unset($values['guid']);
				break;
			default:
				$values[$name] = $value;
				break;
		}
	}

	return $values;
}

/**
 * Load vars from given site into and returns them as array
 * 
 * @return array with stored values
 */
function phloor_plugin_screenshot_save_vars(PhloorPluginScreenshot $plugin_screenshot, $params) {
	// get default params
	$defaults = phloor_plugin_screenshot_default_vars();

	// merge with given params
	$vars = array_merge($defaults, $params);
	   	
	// check variables
	if(!phloor_plugin_screenshot_check_vars($vars)) {
		return false;
	}
	
	// adopt variables
	foreach($vars as $key => $value) {
		$plugin_screenshot->$key = $value;
	}
	
	// save and return status
	return $plugin_screenshot->save();
}

function phloor_plugin_screenshot_check_vars(&$params) {
	if (isset($params['image']) && !empty($params['image']) && $params['image']['error'] != 4) {
		$mime = array(	
			'image/gif' => 'gif',
			'image/jpg' => 'jpeg',
			'image/jpeg' => 'jpeg',
			'image/pjpeg' => 'jpeg',
			'image/png' => 'png',
		);  
		
		if (!array_key_exists($params['image']['type'], $mime)) {
			register_error(elgg_echo('phloor_plugin_screenshot:image_mime_type_not_supported', array(
				$params['image']['type'],
			)));
			return false;
		}
		if ($params['image']['error'] != 0) {
			register_error(elgg_echo('phloor_plugin_screenshot:upload_error', array(
				$params['image']['error'],
			)));
			return false;
		}
		
		$tmp_filename = $params['image']['tmp_name'];
		$params['mime'] = $params['image']['type'];
		
		// determine filename (clean title)
		$clean_title = ereg_replace("[^A-Za-z0-9]", "", $params['title']); // just numbers and letters
		$filename = $clean_title . '.' . time() . '.' . $mime[$params['mime']];
		$prefix = "phloor_plugin/screenshots/";
		
		$image = new ElggFile();
		$image->setMimeType($params['mime']);
		$image->setFilename($prefix . $filename);
		$image->open("write");
		$image->close();
		
		// move the file to the data directory
		$move = move_uploaded_file($_FILES['image']['tmp_name'], $image->getFilenameOnFilestore());
		// report errors if that did not succeed
		if(!$move) {
			register_error(elgg_echo('phloor_plugin_screenshot:could_not_move_uploaded_file'));
			return false;
		} 	
		
		$params['image'] = $image->getFilenameOnFilestore();
	}
	
	// fail if a required entity isn't set
	$required = array('title', 'description');
	
	// load from plugin_screenshot and do sanity and access checking
	foreach ($required as $name) {
		if (!isset($params[$name]) || empty($params[$name])) {
			register_error(elgg_echo("phloor_plugin_screenshot:error:missing:$name"));
			return false;
		}
	}	
	
	return true;
}

/**
 * Get page components to view a plugin_screenshot post.
 *
 * @param int $guid GUID of a plugin_screenshot entity.
 * @return array
 */
function phloor_plugin_screenshot_get_page_content_read($guid = NULL) {
	$return = array();
	$plugin_screenshot = get_entity($guid);

	if (!phloor_plugin_screenshot_instanceof($plugin_screenshot)) {
		$return['content'] = elgg_echo('phloor_plugin_screenshot:error:plugin_screenshot_not_found');
		return $return;
	}
	set_input('plugin_screenshot_guid', $plugin_screenshot->guid);

	// no header or tabs for viewing an individual plugin_screenshot
	$return['filter'] = '';

	/*
	$container = $plugin_screenshot->getContainerEntity();
	$crumbs_title = $container->name;
	if (elgg_instanceof($container, 'group')) {
		elgg_push_breadcrumb($crumbs_title, "phloor_plugin/screenshot/group/$container->guid/all");
	} else {
		elgg_push_breadcrumb($crumbs_title, "phloor_plugin/screenshot/owner/$container->username");
	} */

	elgg_push_breadcrumb($plugin_screenshot->title);
		
	$params = array(
		'entity' => $plugin_screenshot,
	);
	$header .= elgg_view('navigation/breadcrumbs');

	$title = htmlspecialchars($plugin_screenshot->title);
	
	$title_view = elgg_view_title($title, array('class' => 'elgg-heading-main'));
	$buttons = elgg_view_menu('title', array(
		'sort_by' => 'priority',
		'class' => 'elgg-menu-hz',
	));
		
	$header .= <<<HTML
	<div class="elgg-head clearfix">
		$title_view$buttons
	</div>
HTML;

	$plugin_screenshot_view =  elgg_view_entity($plugin_screenshot, array('full_view' => true));
	
	$return['title'] = $title;
	$return['content'] =  $header . $plugin_screenshot_view;

	// sidebar	
	//$return['sidebar']     = elgg_view('phloor_pluginscreenshot/sidebar',     $params);
	//$return['sidebar_alt'] = elgg_view('phloor_plugin/screenshot/sidebar_alt', $params);
	
	//check to see if comment are on
	if ($plugin_screenshot->comments_on != 'Off') {
		$return['content'] .= elgg_view_comments($plugin_screenshot, true);
	}

	return $return;
}

/**
 * Get page components to list a user's or all plugin_screenshots.
 *
 * @param int $owner_guid The GUID of the page owner or NULL for all plugin_screenshots
 * @return array

function phloor_plugin_screenshot_get_page_content_list($container_guid = NULL) {	
	if(!$container_guid) {
	    $return['content'] = elgg_echo('phloor_plugin_screenshot:error:plugin_screenshot_not_found');
		return $return;
	}
    
    $options = array(
		'type' => 'object',
		'subtype' => 'phloor_plugin_screenshot',
		'full_view' => FALSE,
	);
	
	$return = array();
	
	$return['filter_context'] = 'all';

	$loggedin_userid = elgg_get_logged_in_user_guid();
	
	// access check for closed groups
	group_gatekeeper();

	$options['container_guid'] = $container_guid;
	$container = get_entity($container_guid);
	$return['title'] = elgg_echo('phloor_plugin_screenshot:title:user_phloor_plugin_screenshots', array($container->name));

	$crumbs_title = $container->name;
	elgg_push_breadcrumb($crumbs_title);

	if ($container_guid == $loggedin_userid) {
		$return['filter_context'] = 'mine';
	} else if (elgg_instanceof($container, 'group')) {
		$return['filter'] = false;
	} else {
		// do not show button or select a tab when viewing someone else's posts
		$return['filter_context'] = 'none';
	}


	//elgg_register_title_button('phloor_plugin_screenshot', 'add');
	
	//$list = elgg_list_entities_from_metadata($options);
	$list = elgg_view_entity_list($plugin_screenshots, $options);
	if (!$list) {
		$return['content'] = elgg_echo('phloor_plugin_screenshot:none');
	} else {
		$return['content'] = $list;
	}
	
	$return['filter_override'] = elgg_view('phloor_plugin/screenshot/plugin_screenshotfilter', array(
		'filter_context' => $return['filter_context'],
	    'context' => elgg_get_context(),
	));
	

	return $return;
}

 */

/**
 * Get page components to edit/create a plugin_screenshot
 *
 * @param string  $page     'edit' or 'new'
 * @param int     $guid     GUID of phloor_plugin_screenshot post or container
 * @return array
 */
function phloor_plugin_screenshot_get_page_content_edit($page, $guid = 0) {
	$return = array(
		'filter' => '',
	);

	$vars = array();
	$vars['id'] = 'phloor_plugin_screenshot-post-edit';
	$vars['name'] = 'phloor_plugin_screenshot_post';
	$vars['class'] = 'elgg-form-alt';

	$form_vars = array(
		'enctype' => 'multipart/form-data'
	);
			
	if ($page == 'edit') {
		$plugin_screenshot = get_entity((int)$guid);	
		
		$title = elgg_echo('phloor_plugin_screenshot:edit');
		if (phloor_plugin_screenshot_instanceof($plugin_screenshot) && $plugin_screenshot->canEdit()) {
			$vars['entity'] = $plugin_screenshot;

			elgg_push_breadcrumb($plugin_screenshot->title, $plugin_screenshot->getURL());
			elgg_push_breadcrumb(elgg_echo('edit'));
			
			$body_vars = phloor_plugin_screenshot_prepare_form_vars($plugin_screenshot);
			
			$title .= ": \"$plugin_screenshot->title\"";
			// create form
			$content = elgg_view_form('phloor_plugin/screenshot/save', $form_vars, $body_vars);
			$sidebar = '';
		} else {
			$content = elgg_echo('phloor_plugin_screenshot:error:cannot_edit_plugin_screenshot');
			$sidebar = '';
		}
	} else {
		elgg_push_breadcrumb(elgg_echo('phloor_plugin_screenshot:add'));

		$body_vars = phloor_plugin_screenshot_prepare_form_vars(null);
		
		$content = elgg_view_form('phloor_plugin/screenshot/save', $form_vars, $body_vars);
		$title = elgg_echo('phloor_plugin_screenshot:add');
		$sidebar = '';
	}

	$return['title'] = $title;
	$return['content'] = $content;
	$return['sidebar'] = $sidebar;
	return $return;	
}


/**
 * Pull together plugin_screenshot variables for the save form
 *
 * @param Phloorplugin_screenshot       $plugin_screenshot
 * @return array
 */
function phloor_plugin_screenshot_prepare_form_vars($plugin_screenshot = NULL) {
	// set defaults and required values
	$values = phloor_plugin_screenshot_default_vars();
	$values['container_guid'] = (int)get_input('container_guid', '');
	$values['guid'] = phloor_plugin_screenshot_instanceof($plugin_screenshot) ? $plugin_screenshot->guid : NULL;	

	if ($plugin_screenshot) {
		foreach (array_keys($values) as $field) {
			if (isset($plugin_screenshot->$field)) {
				$values[$field] = $plugin_screenshot->$field;
			}
		}
	}

	if (elgg_is_sticky_form('phloor_plugin_screenshot')) {
		$sticky_values = elgg_get_sticky_values('phloor_plugin_screenshot');
		foreach ($sticky_values as $key => $value) {
			$values[$key] = $value;
		}
	}
	
	elgg_clear_sticky_form('phloor_plugin_screenshot');

	return $values;
}

/**
 * Get plugin_screenshot entities via elgg_get_entities
 * 
 * @param unknown_type $plugin_screenshot
 */
function phloor_plugin_screenshot_get_plugin_screenshot_entities($count = false) {
	$params = array(
		'type' => 'object',
		'subtype' => 'phloor_plugin_screenshot',
		'offset' => 0,
		'limit' => 9999, //PHP_INT_MAX,
	);
	
	if($count == true) {
		$params['count'] = true;
	}
	
	return elgg_get_entities($params);
}

/**
 * Check if entity is instance of Phloorplugin_screenshot class
 * 
 * @param unknown_type $plugin_screenshot
 */
function phloor_plugin_screenshot_instanceof($plugin_screenshot) {
	return elgg_instanceof($plugin_screenshot, 'object', 'phloor_plugin_screenshot', 'PhloorPluginScreenshot');
}

/**
 * Check if entity is instance of Phloorplugin_screenshot class
 * 
 * @param unknown_type $plugin_screenshot

function phloor_plugin_screenshots_get_plugin_screenshots_from_user($user, $options = array()) {
	$return = array();
	if(!elgg_instanceof($user, 'user')) {
		return $return;
	}
	
	$params = array(
		'type' => 'object',
		'subtype' => 'phloor_plugin_screenshot',
		'offset' => isset($options['offset']) ? $options['offset'] : 0,
		'limit' => isset($options['limit']) ? $options['limit'] : 999, //PHP_INT_MAX,
		'container_guid' => $user->guid,
	);
	
	return elgg_get_entities($params);
}

function phloor_plugin_screenshots_get_plugin_screenshots_from_group($group, $options = array()) {
	$return = array();
	if(!elgg_instanceof($group, 'group')) {
		return $return;
	}
	
	$params = array(
		'type' => 'object',
		'subtype' => 'phloor_plugin_screenshot',
		'offset' => isset($options['offset']) ? $options['offset'] : 0,
		'limit' => isset($options['limit']) ? $options['limit'] : 999, //PHP_INT_MAX,
		'container_guid' => $group->guid,
	);
	
	return elgg_get_entities($params);
}

function phloor_plugin_screenshots_get_plugin_screenshots_from_container($container, $options = array()) {
	$return = array();
	if(elgg_instanceof($container, 'user')) {
		return phloor_plugin_screenshots_get_plugin_screenshots_from_user($container, $options);
	} else if(elgg_instanceof($container, 'group')) {
		return phloor_plugin_screenshots_get_plugin_screenshots_from_group($container, $options);
	}
	return false;
}

/**
 * Check if entity is instance of Phloorplugin_screenshot class
 * 
 * @param unknown_type $plugin_screenshot_release

function phloor_plugin_screenshot_get_releases_from_plugin_screenshot(Phloorplugin_screenshot $plugin_screenshot, $options = array()) {
	$return = array();
	if(!phloor_plugin_screenshot_instanceof($plugin_screenshot)) {
		return $return;
	}
	
	$params = array(
		'relationship' => 'phloor_plugin_screenshot_release',
		'relationship_guid' => $plugin_screenshot->getGUID(),
		'inverse_relationship' => false,
		'offset' => isset($options['offset']) ? $options['offset'] : 0,
		'limit' => isset($options['limit']) ? $options['limit'] : 10, //PHP_INT_MAX,
		'count' => isset($options['count']) ? $options['count'] : false,
	);
	
	// return the plugin_screenshot entity from releationship
	$return = elgg_get_entities_from_relationship($params);
		
	return $return;
} 

function phloor_plugin_screenshot_get_latest_release(Phloorplugin_screenshot $plugin_screenshot) {
	$latest_release_array = phloor_plugin_screenshot_get_releases_from_plugin_screenshot($plugin_screenshot, array('limit' => 1));
	return empty($latest_release_array) ? false : $latest_release_array[0];
}

function phloor_plugin_screenshot_get_recommended_release(Phloorplugin_screenshot $plugin_screenshot) {
	if(!phloor_plugin_screenshot_instanceof($plugin_screenshot)) {
		return false;
	}

	$recommended_release_guid = $plugin_screenshot->getMetadata('recommended_release_guid');
	$recommended_release = get_entity($recommended_release_guid);
	return phloor_plugin_screenshot_release_instanceof($recommended_release) ? $recommended_release : false;
}
 */

