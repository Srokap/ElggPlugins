<?php 
/*****************************************************************************
 * Phloor Plugin                                                            *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php

/**
 * Default attributes
 * 
 * @return array with default values
 */
function phloor_plugin_default_vars() {
	$defaults = array(
		'title' => '',
		'summary' => '',
	    'description'  => '',
	    'licence' => '',
	    'plugin_type' => 'plugin',
	    'website'  => '',
	    'code_repository'  => '',
	    'donations_url'  => '',
	    'tags' => NULL,
	    'comments_on' => 'On',
		'access_id' => ACCESS_DEFAULT,
		'delete_image' => 'false',
	    'image' => '',
	);
	
	return $defaults;
}

/**
 * Load vars from post or get requests and returns them as array
 * 
 * @return array with values from the request
 */
function phloor_plugin_get_input_vars() {
	// set defaults and required values
	$values = phloor_plugin_default_vars();
	$values['container_guid'] = (int)get_input('container_guid', '');
		
	$user = elgg_get_logged_in_user_entity();
	// load from plugin and do sanity and access checking
	foreach ($values as $name => $default) {
		$value = get_input($name, $default);
		switch ($name) {
			// get the image from $_FILES array
			case 'image':
				$values['image'] = $_FILES['image'];
				break;
			case 'container_guid':
				// this can't be empty or saving the base entity fails
				if (!empty($value)) {
					if (can_write_to_container($user->getGUID(), $value)) {
						$values['container_guid'] = $value;
					}
				}
				break;
			// don't try to set the guid
			case 'guid':
				unset($values['guid']);
				break;
			default:
				$values[$name] = $value;
				break;
		}
	}

	return $values;
}

/**
 * Load vars from given site into and returns them as array
 * 
 * @return array with stored values
 */
function phloor_plugin_save_vars(PhloorPlugin $plugin, $params) {
    if(!phloor_plugin_instanceof($plugin)) {
        return false;
    }
    
	// get default params
	$defaults = phloor_plugin_default_vars();

	// merge with given params
	$vars = array_merge($defaults, $params);

	// delete image if checkbox was set
	if($vars['delete_image'] == 'true' &&
	   $plugin->hasImage()) {
	    //system_message(elgg_echo('phloor_plugin:message:delete_image:success'));
	   	$plugin->deleteImage();
	}
	   	
	// check variables
	if(!phloor_plugin_check_vars($plugin, $vars)) {
		return false;
	}
		
	// reset the delete_image var
	unset($vars['delete_image']);
	
	// adopt variables
	foreach($vars as $key => $value) {
		$plugin->$key = $value;
	}
	
	// save and return status
	return $plugin->save();
}

function phloor_plugin_check_vars(PhloorPlugin $plugin, &$params) { 
    if(!phloor_plugin_instanceof($plugin)) {
        return false;
    }
    
    // see if an image has been set.. if not.. explicitly reassign the current one!
	if (!isset($params['image']) || empty($params['image']) || $params['image']['error'] == 4) {
	    $params['image'] = $plugin->hasImage() ? $plugin->image : '';
	} else {
		$mime = array(	
			'image/gif' => 'gif',
			'image/jpg' => 'jpeg',
			'image/jpeg' => 'jpeg',
			'image/pjpeg' => 'jpeg',
			'image/png' => 'png',
		);  
		
		if (!array_key_exists($params['image']['type'], $mime)) {
			register_error(elgg_echo('phloor_plugin:image_mime_type_not_supported', array(
				$params['image']['type'],
			)));
			return false;
		}
		if ($params['image']['error'] != 0) {
			register_error(elgg_echo('phloor_plugin:upload_error', array(
				$params['image']['error'],
			)));
			return false;
		}
		
		$tmp_filename = $params['image']['tmp_name'];
		$params['mime'] = $params['image']['type'];
		
		// determine filename (clean title)
		$clean_title = ereg_replace("[^A-Za-z0-9]", "", $params['title']); // just numbers and letters
		$filename = $clean_title . '.' . time() . '.' . $mime[$params['mime']];
		$prefix = "phloor_plugin/images/";
		
		$image = new ElggFile();
		$image->setMimeType($params['mime']);
		$image->setFilename($prefix . $filename);
		$image->open("write");
		$image->close();
		
		// move the file to the data directory
		$move = move_uploaded_file($_FILES['image']['tmp_name'], $image->getFilenameOnFilestore());
		// report errors if that did not succeed
		if(!$move) {
			register_error(elgg_echo('phloor_plugin:could_not_move_uploaded_file'));
			return false;
		} 	
		
		$params['image'] = $image->getFilenameOnFilestore();
	}
	
	/*
    if (is_string($params['image']) || !file_exists($params['image'])) {
        $params['image'] = '';
    } */
    
	
	// fail if a required entity isn't set
	$required = array('title', 'summary', 'description');
	
	// load from plugin and do sanity and access checking
	foreach ($required as $name) {
		if (!isset($params[$name]) || empty($params[$name])) {
			register_error(elgg_echo("phloor_plugin:error:missing:$name"));
			return false;
		}
	}	
	
	return true;
}

/**
 * Get page components to view a plugin post.
 *
 * @param int $guid GUID of a plugin entity.
 * @return array
 */
function phloor_plugin_get_page_content_read($guid = NULL) {
	$return = array();
	$plugin = get_entity($guid);

	if (!phloor_plugin_instanceof($plugin)) {
		$return['content'] = elgg_echo('phloor_plugin:error:plugin_not_found');
		return $return;
	}
	set_input('plugin_guid', $plugin->guid);
	
	$release_guid = get_input('release_guid', 0);
	$release = get_entity($release_guid);
	if(!phloor_plugin_release_instanceof($release)) {
		$release = $plugin->getLatestRelease();
		set_input('release_guid', $release->guid ? $release->guid : 0);
	}

	// no header or tabs for viewing an individual plugin
	$return['filter'] = '';

	$container = $plugin->getContainerEntity();
	$crumbs_title = $container->name;
	if (elgg_instanceof($container, 'group')) {
		elgg_push_breadcrumb($crumbs_title, "phloor_plugin/group/$container->guid/all");
	} else {
		elgg_push_breadcrumb($crumbs_title, "phloor_plugin/owner/$container->username");
	}

	elgg_push_breadcrumb($plugin->title);
		
	$params = array(
		'entity' => $plugin,
	);
	$header .= elgg_view('navigation/breadcrumbs');
	
	if(!$plugin->isRecommendedRelease($release)) {
		// append a 'download warning' if viewing not the recommended release
		$download_warning = elgg_view('phloor_plugin/output/download-warning', $params);
		$header .= $download_warning;
	}
	
	$title = htmlspecialchars($plugin->title);
	
	$title_view = elgg_view_title($title, array('class' => 'elgg-heading-main'));
	$buttons = elgg_view_menu('title', array(
		'sort_by' => 'priority',
		'class' => 'elgg-menu-hz',
	));
		
	$header .= <<<HTML
	<div class="elgg-head clearfix">
		$title_view$buttons
	</div>
HTML;

	$plugin_view =  elgg_view_entity($plugin, array('full_view' => true));
	
	$return['title'] = $title;
	$return['content'] =  $header . $plugin_view;

	
	// sidebar	
	$return['sidebar']     = elgg_view('phloor_plugin/sidebar',     $params);
	$return['sidebar_alt'] = elgg_view('phloor_plugin/sidebar_alt', $params);
	
	//check to see if comment are on
	if ($plugin->comments_on != 'Off' && phloor_plugin_release_instanceof($release)) {
		if($release->comments_on != 'Off') {
			$return['content'] .= elgg_view_comments($release, true);
		}
	}

	return $return;
}

/**
 * Get page components to list a user's or all plugins.
 *
 * @param int $owner_guid The GUID of the page owner or NULL for all plugins
 * @return array
 */
function phloor_plugin_get_page_content_list($container_guid = NULL) {	
	$options = array(
		'type' => 'object',
		'subtype' => 'phloor_plugin',
		'full_view' => FALSE,	
		//'limit' => 5,
    	//'list_type' => 'list',
    	//'list_type_toggle' => false,
		//'offset' => (int) get_input('offset', 0),
	);
	
	$return = array();

	$return['filter_context'] = $container_guid ? 'mine' : 'all';

	$loggedin_userid = elgg_get_logged_in_user_guid();
	if ($container_guid) {
		// access check for closed groups
		group_gatekeeper();

		$options['container_guid'] = $container_guid;
		$container = get_entity($container_guid);
		$return['title'] = elgg_echo('phloor_plugin:title:user_phloor_plugins', array($container->name));

		$crumbs_title = $container->name;
		elgg_push_breadcrumb($crumbs_title);

		if ($container_guid == $loggedin_userid) {
			$return['filter_context'] = 'mine';
		} else if (elgg_instanceof($container, 'group')) {
			$return['filter'] = false;
		} else {
			// do not show button or select a tab when viewing someone else's posts
			$return['filter_context'] = 'none';
		}
	} else {
		elgg_pop_breadcrumb();
		elgg_push_breadcrumb(elgg_echo('phloor_plugin:phloor_plugins'));
	}

	$plugins = array();
	//if(strcmp('all', $return['filter_context']) == 0) {
		$return['filter_context'] = get_input('sort', $return['filter_context']);
		$direction                = get_input('direction', 'desc');
		
		//system_message('i am in sort section - '.$return['filter_context']);
		switch($return['filter_context']) {
			case 'most_downloaded':	{
				$return['title'] = elgg_echo('phloor_plugin:title:most_downloaded_plugins');
				$plugins = phloor_plugin_get_most_downloaded_plugins();
				$list = elgg_view_entity_list($plugins, $options);
				break;	
			}
			/*			
			case 'most_recommended':	{
				$return['title'] = elgg_echo('phloor_plugin:title:most_recommended_plugins');
				//$options['order_by_metadata'] = array(
				//	'name' => 'likes', 
				//	'direction' => strtoupper($direction), 
				//	'as' => ''
				//);
				
				$plugins = phloor_plugin_get_most_recommended_plugins();
				break;	
			}*/
		    case 'latest_plugins':	{
				$return['title'] = elgg_echo('phloor_plugin:title:latest_plugins');
				$options['subtype']  = 'phloor_plugin';
				$options['order_by'] = 'e.time_updated desc';
	            $list = elgg_list_entities_from_metadata($options);
				break;	
			}	
			case 'latest_releases':	{
				$return['title'] = elgg_echo('phloor_plugin:title:latest_releases');
				$options['subtype']  = 'phloor_plugin_release';
				$options['order_by'] = 'e.time_updated desc';
	            $list = elgg_list_entities_from_metadata($options);
				break;	
			}		
			case 'newest':
				$return['title'] = elgg_echo('phloor_plugin:title:newest_plugins');
	            $list = elgg_list_entities_from_metadata($options);
				break;
			case 'all':
				$return['title'] = elgg_echo('phloor_plugin:title:all_plugins');
	            $list = elgg_list_entities_from_metadata($options);
				break;
			default:
				// do nothing.. default order.
                $list = elgg_list_entities_from_metadata($options);
		}
	//}
		
	elgg_register_title_button('phloor_plugin', 'add');
	
	//$list = elgg_view_entity_list($plugins, $options);
	if (!$list) {
		$return['content'] = elgg_echo('phloor_plugin:none');
	} else {
		$return['content'] = $list;
	}
	

	
	$return['filter_override'] = elgg_view('phloor_plugin/pluginfilter', array(
		'filter_context' => $return['filter_context'],
	    'context' => elgg_get_context(),
	));
	

	return $return;
}



/**
 * Get page components to edit/create a plugin
 *
 * @param string  $page     'edit' or 'new'
 * @param int     $guid     GUID of phloor_plugin post or container
 * @return array
 */
function phloor_plugin_get_page_content_edit($page, $guid = 0) {
	$return = array(
		'filter' => '',
	);

	$vars = array();
	$vars['id'] = 'phloor_plugin-post-edit';
	$vars['name'] = 'phloor_plugin_post';
	$vars['class'] = 'elgg-form-alt';

	$form_vars = array(
		'enctype' => 'multipart/form-data'
	);
			
	if ($page == 'edit') {
		$plugin = get_entity((int)$guid);	
		
		$title = elgg_echo('phloor_plugin:edit');
		if (phloor_plugin_instanceof($plugin) && $plugin->canEdit()) {
			$vars['entity'] = $plugin;

			elgg_push_breadcrumb($plugin->title, $plugin->getURL());
			elgg_push_breadcrumb(elgg_echo('edit'));
	
			// register 'new screenshot' button
			elgg_register_menu_item('page', array(
				'name' => "phloor-plugin-{$plugin->guid}-new-screenshot",
				'href' => "phloor_plugin/screenshot/add/{$plugin->guid}",
				'text' => elgg_echo('phloor_plugin:newscreenshot'),
			    'priority' => 200,
			));
			
			$body_vars = phloor_plugin_prepare_form_vars($plugin);
			
			$title .= ": \"$plugin->title\"";
			// create form
			$content = elgg_view_form('phloor_plugin/save', $form_vars, $body_vars);
			$sidebar = '';
		} else {
			$content = elgg_echo('phloor_plugin:error:cannot_edit_plugin');
			$sidebar = '';
		}
	} else {
		elgg_push_breadcrumb(elgg_echo('phloor_plugin:add'));

		$body_vars = phloor_plugin_prepare_form_vars(null);
		
		$content = elgg_view_form('phloor_plugin/save', $form_vars, $body_vars);
		$title = elgg_echo('phloor_plugin:add');
		$sidebar = '';
	}

	$return['title'] = $title;
	$return['content'] = $content;
	$return['sidebar'] = $sidebar;
	return $return;	
}


/**
 * Get page components to list of the user's friends' plugins.
 *
 * @param int $user_guid
 * @return array
 */
function phloor_plugin_get_page_content_friends($user_guid) {

	$user = get_user($user_guid);
	if (!$user) {
		forward('phloor_plugin/all');
	}

	$return = array();

	$return['filter_context'] = 'friends';
	$return['title'] = elgg_echo('phloor_plugin:title:friends');

	$crumbs_title = $user->name;
	elgg_push_breadcrumb($crumbs_title, "phloor_plugin/owner/{$user->username}");
	elgg_push_breadcrumb(elgg_echo('friends'));

	elgg_register_title_button();

	if (!$friends = get_user_friends($user_guid, ELGG_ENTITIES_ANY_VALUE, 0)) {
		$return['content'] .= elgg_echo('friends:none:you');
		return $return;
	} else {
		$options = array(
			'type' => 'object',
			'subtype' => 'phloor_plugin',
			'full_view' => FALSE,
		);

		foreach ($friends as $friend) {
			$options['container_guids'][] = $friend->getGUID();
		}

		$list = elgg_list_entities_from_metadata($options);
		if (!$list) {
			$return['content'] = elgg_echo('phloor_plugin:none');
		} else {
			$return['content'] = $list;
		}
	}

	return $return;
}

/**
 * Pull together plugin variables for the save form
 *
 * @param PhloorPlugin       $plugin
 * @return array
 */
function phloor_plugin_prepare_form_vars($plugin = NULL) {
	// set defaults and required values
	$values = phloor_plugin_default_vars();
	$values['container_guid'] = (int)get_input('container_guid', '');
	$values['guid'] = phloor_plugin_instanceof($plugin) ? $plugin->guid : NULL;	

	if ($plugin) {
		foreach (array_keys($values) as $field) {
			if (isset($plugin->$field)) {
				$values[$field] = $plugin->$field;
			}
		}
	}

	if (elgg_is_sticky_form('phloor_plugin')) {
		$sticky_values = elgg_get_sticky_values('phloor_plugin');
		foreach ($sticky_values as $key => $value) {
			$values[$key] = $value;
		}
	}
	
	elgg_clear_sticky_form('phloor_plugin');

	return $values;
}

/**
 * Get plugin entities via elgg_get_entities
 * 
 * @param unknown_type $plugin
 */
function phloor_plugin_get_plugin_entities($count = false) {
	$params = array(
		'type' => 'object',
		'subtype' => 'phloor_plugin',
		'offset' => 0,
		'limit' => 9999, //PHP_INT_MAX,
	);
	
	if($count == true) {
		$params['count'] = true;
	}
	
	return elgg_get_entities($params);
}

/**
 * Check if entity is instance of PhloorPlugin class
 * 
 * @param unknown_type $plugin
 */
function phloor_plugin_instanceof($plugin) {
	return elgg_instanceof($plugin, 'object', 'phloor_plugin', 'PhloorPlugin');
}
	/**
 * Check if entity is instance of PhloorPlugin class
 * 
 * @param unknown_type $plugin
 */
function phloor_plugins_get_plugins_from_user($user, $options = array()) {
	$return = array();
	if(!elgg_instanceof($user, 'user')) {
		return $return;
	}
	
	$params = array(
		'type' => 'object',
		'subtype' => 'phloor_plugin',
		'offset' => isset($options['offset']) ? $options['offset'] : 0,
		'limit' => isset($options['limit']) ? $options['limit'] : 999, //PHP_INT_MAX,
		'container_guid' => $user->guid,
	);
	
	return elgg_get_entities($params);
}

function phloor_plugins_get_plugins_from_group($group, $options = array()) {
	$return = array();
	if(!elgg_instanceof($group, 'group')) {
		return $return;
	}
	
	$params = array(
		'type' => 'object',
		'subtype' => 'phloor_plugin',
		'offset' => isset($options['offset']) ? $options['offset'] : 0,
		'limit' => isset($options['limit']) ? $options['limit'] : 999, //PHP_INT_MAX,
		'container_guid' => $group->guid,
	);
	
	return elgg_get_entities($params);
}

function phloor_plugins_get_plugins_from_container($container, $options = array()) {
	$return = array();
	if(elgg_instanceof($container, 'user')) {
		return phloor_plugins_get_plugins_from_user($container, $options);
	} else if(elgg_instanceof($container, 'group')) {
		return phloor_plugins_get_plugins_from_group($container, $options);
	}
	return false;
}

/**
 * Check if entity is instance of PhloorPlugin class
 * 
 * @param unknown_type $plugin_release
 */
function phloor_plugin_get_releases_from_plugin(PhloorPlugin $plugin, $options = array()) {
	$return = array();
	if(!phloor_plugin_instanceof($plugin)) {
		return $return;
	}
	
	$params = array(
		'relationship' => 'phloor_plugin_release',
		'relationship_guid' => $plugin->getGUID(),
		'inverse_relationship' => false,
		'offset' => isset($options['offset']) ? $options['offset'] : 0,
		'limit' => isset($options['limit']) ? $options['limit'] : 10, //PHP_INT_MAX,
		'count' => isset($options['count']) ? $options['count'] : false,
	);
	
	// return the plugin entity from releationship
	$return = elgg_get_entities_from_relationship($params);
		
	return $return;
} 

function phloor_plugin_get_latest_release(PhloorPlugin $plugin) {
	$latest_release_array = phloor_plugin_get_releases_from_plugin($plugin, array('limit' => 1));
	return empty($latest_release_array) ? false : $latest_release_array[0];
}

function phloor_plugin_get_recommended_release(PhloorPlugin $plugin) {
	if(!phloor_plugin_instanceof($plugin)) {
		return false;
	}

	$recommended_release_guid = $plugin->getMetadata('recommended_release_guid');
	$recommended_release = get_entity($recommended_release_guid);
	return phloor_plugin_release_instanceof($recommended_release) ? $recommended_release : false;
}


/**
 * prepare phloor_plugin object entity menu
 * 
 * @param unknown_type $hook
 * @param unknown_type $type
 * @param unknown_type $return
 * @param unknown_type $params
 */
function phloor_plugin_prepare_entity_menu_setup($hook, $type, $return, $params) {	
	$plugin = elgg_extract('entity', $params, false);
	
	// break up if wrong handler or entity is not of class PhloorMenuitem
	if (!phloor_plugin_instanceof($plugin)) {
		return $return;
	}
	
	//$handler = elgg_extract('handler', $params, false);	
	$context = elgg_get_context();
	$filter_in_contexts = array('phloor-plugin-sidebar', 'widgets',);	
	if(in_array($context, $filter_in_contexts)) {
		return array();
	}
	
	/**
	 * UNregister items
	 * unregister like and likes_count
	 */
	$unregister_items = array();
	
	foreach ($return as $index => $section) {		
		if(is_array($section)) {
			foreach($section as $key => $item) {
				if(in_array($item->getName(), $unregister_items)) {
					unset($return[$index][$key]);
				}
			}
		}
	}

	return $return;
}

/**
 * register phloor_plugin object entity menu
 * 
 * @param unknown_type $hook
 * @param unknown_type $type
 * @param unknown_type $return
 * @param unknown_type $params
 */
function phloor_plugin_register_entity_menu_setup($hook, $type, $return, $params) {	
	$plugin = elgg_extract('entity', $params, false);
	if (!phloor_plugin_instanceof($plugin)) {
		return $return;
	}
	
	// inject "download counter" if plugin has a release
	$release = $plugin->getRecommendedRelease();
	if(phloor_plugin_release_instanceof($release)) {
		$download_count = $plugin->getDownloadCount();
		$options = array(
				'name' => 'phloor-plugin-download-count', 
				'text' => elgg_view_icon('download') . $download_count,
				'href' => "phloor_plugin/release/download/{$release->getGUID()}",
		);
		$return[] = ElggMenuItem::factory($options);
	}
		
	return $return;
}

/**
 * prepare phloor_plugin object page menu
 * 
 * @param unknown_type $hook
 * @param unknown_type $type
 * @param unknown_type $return
 * @param unknown_type $params
 */
function phloor_plugin_prepare_page_menu_setup($hook, $type, $return, $params) {	
	$plugin_guid = get_input('plugin_guid', 0);
	$plugin = get_entity($plugin_guid);
	
	// break up if wrong handler or entity is not of class PhloorMenuitem
	if (!phloor_plugin_instanceof($plugin)) {
		return $return;
	}

	return $return;
}

/**
 * register phloor_plugin object page menu
 * 
 * @param unknown_type $hook
 * @param unknown_type $type
 * @param unknown_type $return
 * @param unknown_type $params
 */
function phloor_plugin_register_page_menu_setup($hook, $type, $return, $params) {	
	$plugin_guid = get_input('plugin_guid', 0);
	$plugin = get_entity($plugin_guid);
	if (!phloor_plugin_instanceof($plugin)) {
		return $return;
	}
	
	if($plugin->canEdit()) {
		$new_release_options = array(
			'name' => "phloor-plugin-new-release",
			'href' => "phloor_plugin/release/add/{$plugin->guid}",
			'text' => elgg_echo('phloor_plugin:menu:newrelease'),
		    'priority' => 10,
		    'section' => 'owner-1',
		);	
		$edit_plugin_options = array(
			'name' => "phloor-plugin-edit",
			'href' => "phloor_plugin/edit/{$plugin->guid}",
			'text' => elgg_echo('phloor_plugin:menu:editplugin'),
		    'priority' => 20,
		    'section' => 'owner-1',
		);	
		$delete_plugin_options = array(
			'name' => "phloor-plugin-delete",
			'href' => elgg_add_action_tokens_to_url("action/phloor_plugin/delete?guid={$plugin->guid}", false),
			'text' => elgg_echo('phloor_plugin:menu:delete'),
		    'priority' => 10,
		    'section' => 'owner-2',
			'confirm' => elgg_echo('phloor_plugin:delete:confirm'),
		);	
		$new_plugin_options = array(
			'name' => "phloor-plugin-new",
			'href' => "phloor_plugin/add/{$plugin->getContainerGUID()}",
			'text' => elgg_echo('phloor_plugin:menu:new'),
		    'priority' => 10,
		    'section' => 'owner-3',
		);	
		
		$return[] = ElggMenuItem::factory($new_release_options);
		$return[] = ElggMenuItem::factory($edit_plugin_options);
		$return[] = ElggMenuItem::factory($delete_plugin_options);
		$return[] = ElggMenuItem::factory($new_plugin_options);
	}
		
	return $return;
}

/**
 * prepare phloor_plugin object page menu
 * 
 * @param unknown_type $hook
 * @param unknown_type $type
 * @param unknown_type $return
 * @param unknown_type $params
 */
function phloor_plugin_prepare_title_menu_setup($hook, $type, $return, $params) {	
	$plugin_guid = get_input('plugin_guid', 0);
	$plugin = get_entity($plugin_guid);
	
	// break up if wrong handler or entity is not of class PhloorMenuitem
	if (!phloor_plugin_instanceof($plugin)) {
		return $return;
	}

	return $return;
}

/**
 * register phloor_plugin object page menu
 * 
 * @param unknown_type $hook
 * @param unknown_type $type
 * @param unknown_type $return
 * @param unknown_type $params
 */
function phloor_plugin_register_title_menu_setup($hook, $type, $return, $params) {	
	$plugin_guid = get_input('plugin_guid', 0);
	$plugin = get_entity($plugin_guid);
	if (!phloor_plugin_instanceof($plugin)) {
		return $return;
	}
	
	if($plugin->canEdit()) {
		$new_release_options = array(
			'name' => "phloor-plugin-new-release",
			'href' => "phloor_plugin/release/add/{$plugin->guid}",
			'text' => elgg_echo('phloor_plugin:menu:newrelease'),
			'link_class' => 'elgg-button elgg-button-action',
		    'priority' => 10,
		    'section' => 'owner-1',
		);		
		$return[] = ElggMenuItem::factory($new_release_options);	
	}
	
	return $return;
}

function phloor_plugin_get_most_downloaded_plugins($params = array()) {
    $options = array(
		'calculation' => 'count',
		'type' => 'object',
		'subtype' => 'phloor_plugin',
		'annotation_names' => 'download',
		'offset' => get_input('offset', 0),
		'limit' => get_input('limit', 10),
	);
	
    $most_downloaded = elgg_get_entities_from_annotation_calculation($options);
	return $most_downloaded;
}


/*
function phloor_plugin_get_most_recommended_plugins($params = array()) {
	if(!elgg_is_active_plugin('likes')) {
		return array();
	}
	
    $options = array(
		'calculation' => 'count',
		'annotation_calculation' => 'count',
		'type' => 'object',
		'subtype' => 'phloor_plugin',
		'annotation_names' => 'likes',
		'offset' => get_input('offset', 0),
		'limit' => get_input('limit', 10),
	);
	
    $most_downloaded = elgg_get_entities_from_annotation_calculation($options);
	return $most_downloaded;
} */
function phloor_plugin_get_most_recommended_plugins($params = array()) {
	if(!elgg_is_active_plugin('likes')) {
		return array();
	}
	
	$params = array(
		'type' => 'object',
		'subtype' => 'phloor_plugin',
		'offset' => 0,
		'limit' => PHP_INT_MAX,
	);
	
	$plugins = array();
	foreach(elgg_get_entities($params) as $plugin) {
		if(likes_count($plugin) > 0) {
			$plugins[] = $plugin;
		}
	}
	
	return $plugins;
}