<?php 
/*****************************************************************************
 * Phloor Plugin                                                            *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php

/**
 * Default attributes
 * 
 * @return array with default values
 */
function phloor_plugin_release_default_vars() {
	$defaults = array(
		'version'              => '0.1',
		'description'          => elgg_echo('phloor_plugin:see_readme_txt'),
		'notes'                => elgg_echo('phloor_plugin:initial_commit'),
	    'file'                 => NULL,
	    'filename'             => '',
	    'comments_on'          => 'On',
	    'recommended_release'  => 'false', // wont be stored
		'access_id'            => ACCESS_DEFAULT,
		'compatible_version'   => 'elgg-1.8',
	);
	
	return $defaults;
}

/**
 * Load vars from post or get requests and returns them as array
 * 
 * @return array with values from the request
 */
function phloor_plugin_release_get_input_vars() {
	// set defaults and required values
	$values = phloor_plugin_release_default_vars();
	$values['container_guid'] = (int)get_input('container_guid', '');
		
	$user = elgg_get_logged_in_user_entity();
	// load from plugin_release and do sanity and access checking
	foreach ($values as $name => $default) {
		$value = get_input($name, $default);
		switch ($name) {
			// get the image from $_FILES array
			case 'file':
				$values['file'] = $_FILES['file'];
				break;
			case 'container_guid':
				// this can't be empty or saving the base entity fails
				if (!empty($value)) {
					if (can_write_to_container($user->getGUID(), $value)) {
						$values['container_guid'] = $value;
					}
				}
				break;
			// don't try to set the guid
			case 'guid':
				unset($values['guid']);
				break;
			default:
				$values[$name] = $value;
				break;
		}
	}

	return $values;
}

/**
 * Load vars from given site into and returns them as array
 * 
 * @return array with stored values
 */
function phloor_plugin_release_save_vars(PhloorPluginRelease $release, $params) {	
	$defaults = phloor_plugin_release_default_vars();
	
	$vars = array_merge($defaults, $params);
	
	// check variables
	if(!phloor_plugin_release_check_vars($vars)) {
		return false;
	}
	
	// nobody is allowed to re-upload/overwrite an archive of a release. 
	// has to be deleted as a whole..
	if(phloor_plugin_release_instanceof($release) && $release->hasFile()) {
		$vars['file'] = $release->file;
	}
	
	// unset temporary data
	unset($vars['recommended_release']);
	
	// adopt variables
	foreach($vars as $key => $value) {
		$release->$key = $value;
	}
	
	// save and return status
	return $release->save();
}

function phloor_plugin_release_check_vars(&$params) {			
	// fail if a required entity isn't set
	$required = array('version');
	
	// load from plugin_release and do sanity and access checking
	foreach ($required as $name) {
		if (!isset($params[$name]) || empty($params[$name])) {
			register_error(elgg_echo("phloor_plugin:release:error:missing:$name"));
			return false;
		}
	}
	$version = ereg_replace('[^\.A-Za-z0-9]', '-', $params['version']);
	// set title to plugin title + release version
	$params['title'] = $params['title'] . ' ' . $params['version'];
	
	if (isset($params['file']) && !empty($params['file']) && $params['file']['error'] != 4) {
		$mime = array(	
			'application/zip' => 'zip',
			'application/x-compressed-tar' => 'tar.gz',
		);  
		
		if (!array_key_exists($params['file']['type'], $mime)) {
			register_error(elgg_echo('phloor_plugin:release:file_mime_type_not_supported', array(
				$params['file']['type'],
			)));
			return false;
		}
		if ($params['file']['error'] != 0) {
			register_error(elgg_echo('phloor_plugin:release:upload_error', array(
				$params['file']['error'],
			)));
			return false;
		}
		
		$tmp_filename = $params['file']['tmp_name'];

		// determine filename (clean title)
		$clean_title = ereg_replace('[^A-Za-z0-9]', '-', $params['title']);
		$filename = $clean_title . '.' . time() . '.' . $mime[$params['file']['type']];
		$prefix = 'phloor_plugin/release/';
		
		$archive = new ElggFile();
		$archive->setMimeType($params['file']['type']);
		$archive->setFilename($prefix . $filename);
		$archive->open("write");
		//$archive->write(file_get_contents($tmp_filename));
		$archive->close();
		
		// move the file to the data directory
		$move = move_uploaded_file($_FILES['file']['tmp_name'], $archive->getFilenameOnFilestore());
			// report errors if that did not succeed
		if(!$move) {
			register_error(elgg_echo('phloor_plugin:release:could_not_move_uploaded_file'));
			return false;
		} 	
		
		$params['mime'] = $params['file']['type'];
		$params['file'] = $archive->getFilenameOnFilestore();
		$params['filename'] = $filename;
		$params['md5'] = md5_file($params['file']);
	}
	
	return true;
}

/**
 * Get page components to view a plugin post.
 *
 * @param int $guid GUID of a plugin entity.
 * @return array
 */
function phloor_plugin_release_get_page_content_download($guid = NULL) {
	$release = get_entity($guid);
	
	// register error if archive does not exist
	if(!phloor_plugin_release_instanceof($release)) {
		register_error(elgg_echo('phloor_plugin:release:error:release_not_found'));
		forward(REFERER);
		exit();
	}
	
	$plugin = $release->getPlugin();
	if(!phloor_plugin_release_instanceof($release)) {
		register_error(elgg_echo('phloor_plugin:release:error:plugin_not_found'));
		forward(REFERER);
		exit();
	}
	
	$archive = $release->file;
	if(!file_exists($archive) || !is_file($archive)) {
		register_error(elgg_echo('phloor_reconstructor:filenotfound'));
		forward(REFERER);
		exit();
	}
	
	// increase download counter
	$plugin->incrementDownloadCount();
	
	$filename = $release->filename;
	$mime = $release->mime;
	
	header("Pragma: public");
	header("Content-type: $mime");
	header("Content-Disposition: attachment; filename=\"$filename\"");
	ob_clean();
	flush();
	echo file_get_contents($archive);
	exit();

}

/**
 * 
 *
 * @param unknown_type $container_guid
 */
function phloor_plugin_release_get_page_content_list($plugin_guid = NULL) {
	$return = array();

	$plugin = get_entity($plugin_guid);
	if(!phloor_plugin_instanceof($plugin)) {
		return false;
	}
	
	$releases = $plugin->getReleases(array(
		'limit' => 999,
	));
	
	// breadcrumbs
	$crumbs_title = $plugin->title;
	elgg_push_breadcrumb($crumbs_title, $plugin->getURL());
	elgg_push_breadcrumb(elgg_echo('phloor_plugin:releases'));
	
	$header = elgg_view('navigation/breadcrumbs');
	
	// project admin links
	if($plugin->canEdit()) {
		$new_release_options = array(
			'name' => "phloor-plugin-{$plugin->guid}-new-release",
			'href' => "phloor_plugin/release/add/{$plugin->guid}",
			'text' => elgg_echo('phloor_plugin:menu:newrelease'),
			'link_class' => 'elgg-button elgg-button-action',
		    'priority' => 10,
		    'section' => 'aaa-owner',
		);
		
		elgg_register_menu_item('title', $new_release_options);
	}
	
	
	$title = elgg_echo('phloor_plugin:all:releases:title', array($plugin->title));
	
	/*$title_view = elgg_view_title($title, array('class' => 'elgg-heading-main'));
	$buttons = elgg_view_menu('title', array(
		'sort_by' => 'priority',
		'class' => 'elgg-menu-hz',
	));	
	
	$header .= <<<HTML
	<div class="elgg-head clearfix">
		$title_view$buttons
	</div>
HTML; */
	
	$return['title'] = $title;
	$return['filter'] = false;
	//$return['content'] =  $header;
	
	$options = array(
		'full_view' => false,
		'pagination' => true,
		'list_type_toggle' => true,
	);
	$list = elgg_view_entity_list($releases, $options);
	if (!$list) {
		$return['content'] .= elgg_echo('phloor_plugin:norelease');
	} else {
		$return['content'] .= $list;
	}

	return $return;
}

/**
 * Get page components to edit/create a plugin_release
 *
 * @param string  $page     'edit' or 'new'
 * @param int     $guid     GUID of phloor_plugin_release post or container
 * @return array
 */
function phloor_plugin_release_get_page_content_edit($page, $guid = 0) {
	$return = array(
		'filter' => '',
	);

	$plugin_guid = get_input('plugin_guid', 0, true);
	$plugin = get_entity($plugin_guid);
	if(!phloor_plugin_instanceof($plugin)) {
		return $return;
	}
	
	$vars = array();
	$vars['id'] = 'phloor_plugin_release-post-edit';
	$vars['name'] = 'phloor_plugin_release';
	$vars['class'] = 'elgg-form-alt';

	$form_vars = array(
		'enctype' => 'multipart/form-data'
	);
	
	if ($page == 'edit') {
		$release = get_entity((int)$guid);

		$title = elgg_echo('phloor_plugin:release:edit');
		if (phloor_plugin_release_instanceof($release) && $release->canEdit()) {
			$vars['entity'] = $release;
			
			elgg_push_breadcrumb($plugin->title, $plugin->getURL());
			elgg_push_breadcrumb($release->version, $release->getURL());
			elgg_push_breadcrumb(elgg_echo('edit'));
	
			// register 'new screenshot' button
			elgg_register_menu_item('page', array(
				'name' => "phloor-plugin-release-{$release->guid}-new-screenshot",
				'href' => "phloor_plugin/screenshot/add/{$release->guid}",
				'text' => elgg_echo('phloor_plugin:release:newscreenshot'),
			    'priority' => 200,
			));
			
			$body_vars = phloor_plugin_release_prepare_form_vars($release);
			
			$title .= ": \"$release->version\"";
			// create form
			$content = elgg_view_form('phloor_plugin/release/save', $form_vars, $body_vars);
			$sidebar = '';
		} else {
			$content = elgg_echo('phloor_plugin:release:error:cannot_edit_plugin_release');
			$sidebar = '';
		}
	} else {
		$plugin = get_entity($guid);
		if(!phloor_plugin_instanceof($plugin)) {
			register_error(elgg_echo("phloor_plugin:release:error:invalid:plugin_guid"));
			return false;
		}
		
		elgg_push_breadcrumb($plugin->title, $plugin->getURL());
		elgg_push_breadcrumb(elgg_echo('phloor_plugin:release:add'));

		$body_vars = phloor_plugin_release_prepare_form_vars(null);
		
		$content = elgg_view_form('phloor_plugin/release/save', $form_vars, $body_vars);
		$title = elgg_echo('phloor_plugin:release:add');
		$sidebar = '';
	}

	$return['title'] = $title;
	$return['content'] = $content;
	$return['sidebar'] = $sidebar;
	return $return;	
}

/**
 * Pull together plugin_release variables for the save form
 *
 * @param PhloorPlugin       $plugin_release
 * @return array
 */
function phloor_plugin_release_prepare_form_vars($release = NULL) {
	// set defaults and required values
	$values = phloor_plugin_release_default_vars();
	$values['container_guid'] = (int)get_input('container_guid', '');
	$values['guid'] = phloor_plugin_release_instanceof($release) ? $release->guid : 0;
	$values['entity'] = phloor_plugin_release_instanceof($release) ? $release : NULL;
	$values['plugin_guid'] = (int)get_input('plugin_guid', 0);	
	
	if (phloor_plugin_release_instanceof($release)) {
		foreach (array_keys($values) as $field) {
			if (isset($release->$field)) {
				$values[$field] = $release->$field;
			}
		}
	}

	if (elgg_is_sticky_form('phloor_plugin_release')) {
		$sticky_values = elgg_get_sticky_values('phloor_plugin_release');
		foreach ($sticky_values as $key => $value) {
			$values[$key] = $value;
		}
	}
	
	elgg_clear_sticky_form('phloor_plugin_release');

	return $values;
}

/**
 * Get plugin_release entities via elgg_get_entities
 * 
 * @param unknown_type $plugin_release
 */
function phloor_plugin_release_get_plugin_release_entities($count = false) {
	$params = array(
		'type' => 'object',
		'subtype' => 'phloor_plugin_release',
		'offset' => 0,
		'limit' => 999, //PHP_INT_MAX,
	);
	
	if($count == true) {
		$params['count'] = true;
	}
	
	return elgg_get_entities($params);
}

/**
 * Check if entity is instance of PhloorPlugin class
 * 
 * @param unknown_type $plugin_release
 */
function phloor_plugin_release_instanceof($release) {
	return elgg_instanceof($release, 'object', 'phloor_plugin_release', 'PhloorPluginRelease');
} 

function phloor_plugin_release_get_plugin(PhloorPluginRelease $release) {
	$return = array();
	if(!phloor_plugin_release_instanceof($release)) {
		return false;
	}
	
	$params = array(
		'relationship' => 'phloor_plugin_release',
		'relationship_guid' => $release->guid,
		'inverse_relationship' => true,
		'offset' =>  0,
		'limit' => 1, //PHP_INT_MAX,
	);
	
	// return the plugin entity from releationship
	$return = elgg_get_entities_from_relationship($params);

	if(empty($return)) {
		return false;
	}
	
	$plugin  = $return[0]; // get first (and only) entry
	if(!phloor_plugin_instanceof($plugin)) {
		return false;
	}
	
	
	return $plugin;
} 


/**
 * prepare phloor_plugin_release object entity menu
 * 
 * remove likes and likes_count
 * 
 * @param unknown_type $hook
 * @param unknown_type $type
 * @param unknown_type $return
 * @param unknown_type $params
 */
function phloor_plugin_release_prepare_entity_menu_setup($hook, $type, $return, $params) {	
	$release = elgg_extract('entity', $params, false);
	if (!phloor_plugin_release_instanceof($release)){
		return $return;
	}
	
	//$handler = elgg_extract('handler', $params, false);
	$context = elgg_get_context();
	$filter_in_contexts = array('phloor-plugin-sidebar', 'widgets',);	
	if(in_array($context, $filter_in_contexts)) {
		return array();
	}
	
	$unregister_items = array( 
		'likes', 'likes_count',
	);
	
	foreach ($return as $index => $section) {		
		if(is_array($section)) {
			foreach($section as $key => $item) {
				if(in_array($item->getName(), $unregister_items)) {
					unset($return[$index][$key]);
				}
			}
		}
	}

	return $return;
}

/**
 * register phloor_plugin_release object entity menu
 * 
 * remove likes and likes_count
 * 
 * @param unknown_type $hook
 * @param unknown_type $type
 * @param unknown_type $return
 * @param unknown_type $params
 */
function phloor_plugin_release_register_entity_menu_setup($hook, $type, $return, $params) {	
	$release = elgg_extract('entity', $params, false);
	$handler = elgg_extract('handler', $params, false);
	// break up if wrong handler or entity is not of class PhloorMenuitem
	if(!phloor_plugin_release_instanceof($release) ||  
	   strcmp('phloor_plugin_release', $handler) != 0) {
		return $return;
	}
	$plugin = $release->getPlugin();
	if (!phloor_plugin_instanceof($plugin)){
		return $return;
	}
	
	// add plugin title to entity menu
	$options = array(
		'name' => 'plugin-name', 
		'text' => $plugin->title, 
		'href' => false,
	);
	$return[] = ElggMenuItem::factory($options);
			
	if(!$plugin->isRecommendedRelease($release)) {
		if($plugin->canEdit()) {
			$url = "action/phloor_plugin/release/set_recommended_release?guid={$release->guid}";
			$options = array(
				'name' => 'set-as-recommended-release', 
				'text' => elgg_echo('phloor_plugin:release:set_as_recommended_release'), 
				'href' => elgg_add_action_tokens_to_url($url),
			);
			
			$return[] = ElggMenuItem::factory($options);
		}
	} else {
		$options = array(
			'name' => 'recommended-release', 
			'text' => elgg_echo('phloor_plugin:release:recommended_release'), 
			'href' => false,
		);
		
		$return[] = ElggMenuItem::factory($options);
	}

	return $return;
}


function phloor_plugin_releases_get_latest_releases($params = array()) {
	$default = array(
		'relationship' => 'phloor_plugin_release',
		'offset' => get_input('offset', 0),
		'limit' => get_input('limit', 10),
		'order_by' => 'e.time_created desc',
	);
	
	$params = array_merge($default, $params);
	
	// return the plugin entity from releationship
	$return = elgg_get_entities_from_relationship($params);
}


/**
 * prepare phloor_plugin object page menu
 * 
 * @param unknown_type $hook
 * @param unknown_type $type
 * @param unknown_type $return
 * @param unknown_type $params
 */
function phloor_plugin_release_prepare_title_menu_setup($hook, $type, $return, $params) {	
	$release_guid = get_input('release_guid', 0);
	$release = get_entity($release_guid);
	
	// break up if wrong handler or entity is not of class PhloorMenuitem
	if (!phloor_plugin_release_instanceof($release)) {
		return $return;
	}

	return $return;
}

/**
 * register phloor_plugin object page menu
 * 
 * @param unknown_type $hook
 * @param unknown_type $type
 * @param unknown_type $return
 * @param unknown_type $params
 */
function phloor_plugin_release_register_title_menu_setup($hook, $type, $return, $params) {	
	$release_guid = get_input('release_guid', 0);
	$release = get_entity($release_guid);
	if (!phloor_plugin_release_instanceof($release)) {
		return $return;
	}
	
	if($release->isRecommendedRelease()) {
		$download_release_options = array(
			'name' => "phloor-plugin-release-download",
			'href' => "phloor_plugin/release/download/{$release->guid}",
			'text' => elgg_echo('phloor_plugin:menu:download'),
			'link_class' => 'elgg-button elgg-button-action',
		    'priority' => 40,
		);	
		
		$return[] = ElggMenuItem::factory($download_release_options);	
	} 
		
	return $return;
}

/**
 * prepare phloor_plugin object page menu
 * 
 * @param unknown_type $hook
 * @param unknown_type $type
 * @param unknown_type $return
 * @param unknown_type $params
 */
function phloor_plugin_release_prepare_page_menu_setup($hook, $type, $return, $params) {	
	$release_guid = get_input('release_guid', 0);
	$release = get_entity($release_guid);
	
	// break up if wrong handler or entity is not of class PhloorMenuitem
	if (!phloor_plugin_release_instanceof($release)) {
		return $return;
	}

	return $return;
}

/**
 * register phloor_plugin object page menu
 * 
 * @param unknown_type $hook
 * @param unknown_type $type
 * @param unknown_type $return
 * @param unknown_type $params
 */
function phloor_plugin_release_register_page_menu_setup($hook, $type, $return, $params) {	
	$release_guid = get_input('release_guid', 0);
	$release = get_entity($release_guid);
	if (!phloor_plugin_release_instanceof($release)) {
		return $return;
	}
	
	if($release->canEdit()) {
		$edit_release_options = array(
			'name' => "phloor-plugin-release-edit",
			'href' => "phloor_plugin/release/edit/{$release->guid}",
			'text' => elgg_echo('phloor_plugin:menu:release:edit'),
		    'priority' => 30,
		    'section' => 'owner-1',
		);
		
		$return[] = ElggMenuItem::factory($edit_release_options);	
	} 
		
	return $return;
}
