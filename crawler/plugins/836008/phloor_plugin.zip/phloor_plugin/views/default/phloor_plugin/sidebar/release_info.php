<?php
/**
 * Release Information View
 */
$plugin = elgg_extract('entity', $vars, FALSE);
if(!phloor_plugin_instanceof($plugin)) {
	return true;
}

// latest update time
$release_guid = get_input('release_guid', 0);
$release = get_entity($release_guid);
if(!phloor_plugin_release_instanceof($release)) {
	$release = $plugin->getRecommendedRelease();
	if(!phloor_plugin_release_instanceof($release)) {
		return true;
	}
}

$title = elgg_echo('phloor_plugin:release_info');

// prepare upload timestamp
$uploaded  = '<span class="font-weight-bold">' . elgg_view('output/text', array(
	'value' => elgg_echo('phloor_plugin:release:uploaded')  . ': ',
)) . '</span>';
$uploaded .= elgg_view_friendly_time($release->time_created);

$version  = '<span class="font-weight-bold">' . elgg_view('output/text', array(
	'value' => elgg_echo('phloor_plugin:release:version')  . ': ',
)) . '</span>';
$version  .= elgg_echo($release->version);

$compatible_version = '<span class="font-weight-bold">' . elgg_view('output/text', array(
	'value' => elgg_echo('phloor_plugin:release:compatible_version')  . ': ',
)) . '</span>';
$compatible_version .= "{$release->compatible_version}";

// prepare filename
$filename = '<span class="font-weight-bold">' . elgg_view('output/text', array(
	'value' => elgg_echo('phloor_plugin:release:filename') . ': ',
)) . '</span>';
$filename .=  $release->filename;

// prepare md5 hash
$md5 = '<span class="font-weight-bold">' . elgg_view('output/text', array(
	'value' => elgg_echo('phloor_plugin:release:md5') . ': ',
)) . '</span>';
$md5 .= $release->md5;

// create the content
$body = <<<HTML
<ul class="phloor-plugin-release-info">
<li>$uploaded</li>
<li>$version</li>
<li>$compatible_version</li>
<li>$filename</li>
<li>$md5</li>
</ul>
HTML;

// view module
echo elgg_view_module('aside', $title, $body);
