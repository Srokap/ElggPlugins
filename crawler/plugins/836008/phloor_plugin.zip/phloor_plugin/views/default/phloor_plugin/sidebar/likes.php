<?php
/**
 * List of member who 'like' this plugin
 */
if(!elgg_is_active_plugin('likes')) {
	return true;
}

// get plugin entity
$plugin = elgg_extract('entity', $vars, FALSE);
if(!phloor_plugin_instanceof($plugin)) {
	return true;
}

$likes = $plugin->getLikes(array(
	'limit' => 20,
));
// show nothing if plugins has no likes currently
if(empty($likes)) {
	return true;
}

// get like owner
$owners = array();
foreach($likes as $like) {
	$owners[] = $like->getOwnerEntity();
}

$list_options = array(
	'list_class' => 'elgg-list-entity',
	'full_view' => false,
	'pagination' => false,
	'list_type' => 'gallery',
	'list_type_toggle' => false,
	'offset' => 0,
);

$title = elgg_echo('phloor_plugin:likes');
$body = elgg_view_entity_list($owners, $list_options);

echo elgg_view_module('aside', $title, $body);