<?php 
/*****************************************************************************
 * Phloor Plugin                                                            *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>

.font-weight-bold {
	font-weight: bold;
}

ul.phloor-plugin-information > li,
ul.phloor-plugin-release-info > li {
	margin:0 1px 5px 1px;
}
ul.phloor-plugin-information{
	margin:5px 0 0 0;
}

.plugin-description {
	margin-bottom: 10px;
}

.plugin-image {
	text-align: center;
	margin-bottom: 15px;
}

ul.phloor-phlugin-stats {
	list-style-type:none;
}

ul.elgg-menu-phloor-plugin-warning-title {
	float: right;
	clear: right;
}
ul.elgg-menu-phloor-plugin-warning-title > li {
    display: inline-block;
    margin: 5px 5px 0 4px;
}

.phloor-download-warning-title {
	float: left;
	max-width: 530px;
	margin: 5px 10px 0 5px;
}

.elgg-menu-phloor-plugin-information {
    margin-bottom: 1px;
}

.phloor-plugin-subtitle-latest-release-upload,
.phloor-plugin-subtitle-summary,
.phloor-plugin-subtitle-version {
	display: block;
}

.phloor-plugin-download-warning {
	background-color: #F7DAD8;
	border: 1px solid #D3322A;
}

.phloor-plugin-download-warning .elgg-inner {
	padding: 2px;
}
.phloor-plugin-download-warning .elgg-inner .elgg-body {
	padding: 0 5px 0 5px;
}

.elgg-menu-item-phloor-plugin-download-count a,
.elgg-menu-item-phloor-plugin-download-count a:hover {
	text-decoration:none;
}
