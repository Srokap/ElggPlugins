<?php
/**
 * Sidebar - Screenshots of a Plugin
 */

$plugin = elgg_extract('entity', $vars, FALSE);

if(!phloor_plugin_instanceof($plugin)) {
	return true;
}

$title = elgg_echo('phloor_plugin:screenshots');

// get lastest 10 sceenshots
$screenshots = $plugin->getAnnotations('phloor_screenshot', 10, 0, 'time_created DESC');

$body = elgg_echo('phloor_plugin:noscreenshots');
if(!empty($screenshots)) {
	$list_options = array(
		'list_class' => 'elgg-list-entity',
		'full_view' => false,
		'pagination' => true,
		'list_type' => 'list',
		'list_type_toggle' => false,
		'offset' => 0,
	);

	$body = elgg_view_entity_list($screenshots, $list_options);
}

echo elgg_view_module('aside', $title, $body);