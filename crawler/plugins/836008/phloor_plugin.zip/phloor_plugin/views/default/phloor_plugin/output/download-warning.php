<?php 
/*****************************************************************************
 * Phloor Plugin                                                            *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php
/**
 * 
 */
$plugin = elgg_extract('entity', $vars, false);

if (!phloor_plugin_instanceof($plugin)) {
	return TRUE;
}

//$release_guid = elgg_extract('release_guid', $vars, 0);
$release_guid = get_input('release_guid', 0);
$release = get_entity($release_guid);
if(!phloor_plugin_release_instanceof($release) ||
   $plugin->isRecommendedRelease($release)) {
	return true;
}

// register download button which has to be confirmed
// (ala "Are you sure you dont want the recommended release?"
elgg_register_menu_item('phloor-plugin-warning-title', array(
	'name' => "phloor-plugin-release-{$release->guid}-download",
	'href' => "phloor_plugin/release/download/{$release->guid}",
	'text' => elgg_echo('phloor_plugin:menu:download'),
	'link_class' => 'elgg-button elgg-button-action',
	'confirm' => elgg_echo('phloor_plugin:release:download:not_recommended:confirm'),
    'priority' => 40,
));	

	
$title = elgg_echo('phloor_plugin:release:download_warning:title');
	
$title_view = elgg_view_title($title, array('class' => 'phloor-download-warning-title'));
$buttons = elgg_view_menu('phloor-plugin-warning-title', array(
	'sort_by' => 'priority',
	'class' => 'elgg-menu-hz',
));

// warning message
$body = elgg_view('output/longtext', array(
	'value' => elgg_echo('phloor_plugin:release:download_warning:body'),
	'class' => '',
));

// display recommended plugin
elgg_push_context('phloor-plugin-sidebar'); // dont show 'edit' or 'like'
$body .= elgg_view_entity($plugin->getRecommendedRelease(), array(
	'full_view' => false,
));
elgg_pop_context();

// create download warning section
$download_warning = elgg_view_module('aside', false, $body, array(
	'header' => $title_view . $buttons,
	'class'  => 'phloor-plugin-download-warning',   
	'show_inner' => true,
));

echo $download_warning;