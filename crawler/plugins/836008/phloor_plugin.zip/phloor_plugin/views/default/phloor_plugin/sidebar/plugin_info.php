<?php
/**
 * Sidebar - Plugin Information 
 * 
 * @todo maybe pull registration of items into hook
 */

$plugin = elgg_extract('entity', $vars, FALSE);
if(!phloor_plugin_instanceof($plugin)) {
	return true;
}


$title = elgg_echo('phloor_plugin:plugin_information');
$menu_name = "phloor-plugin-information";

// register title 'Plugin Website'
if(!empty($plugin->website)) {
	elgg_register_menu_item($menu_name, array(
		'name' => "phloor-menuitem-website",
		'href' => $plugin->website,
		'text' => elgg_echo('phloor_plugin:menu:website'),
	    'priority' => 100,
		'target' => '_blank',
	    'section' => 'general',
	));
}

// register title 'Plugin Homepage'
if(!empty($plugin->code_repository)) {
	elgg_register_menu_item($menu_name, array(
		'name' => "phloor-plugin-code-repository",
		'href' => $plugin->code_repository,
		'text' => elgg_echo('phloor_plugin:menu:code_repository'),
	    'priority' => 200,
		'target' => '_blank',
	    'section' => 'general',
	));
}

// register 'Donations' button
if(!empty($plugin->donations_url)) {
	elgg_register_menu_item($menu_name, array(
		'name' => "phloor-plugin-dontations-url",
		'href' => $plugin->donations_url,
		'text' => elgg_echo('phloor_plugin:menu:donations_url'),
	    'priority' => 300,
		'target' => '_blank',
	    'section' => 'general',
	));
}

// latest update time
$release = $plugin->getRecommendedRelease();
if(phloor_plugin_release_instanceof($release) &&
	$release->guid != get_input('release_guid', $release->guid)) {
	elgg_register_menu_item($menu_name, array(
		'name' => "phloor-plugin-dontations-url",
		'href' => $release->getURL(),
		'text' => elgg_echo('phloor_plugin:menu:release:recommended_release'),
	    'priority' => 400,
	    'section' => 'recommended-release',
	));
}

	
// view menu
$menu = elgg_view_menu($menu_name, array(
	'sort_by' => 'priority',
	'class' => 'elgg-menu-page', // layout like page menu
));

// licence
$licence = '<span class="font-weight-bold">' . elgg_view('output/text', array(
	'value' => elgg_echo('phloor_plugin:form:licence') ,
)) . '</span>';
$licence .= elgg_echo("phloor_plugin:input:licence:{$plugin->licence}");

// plugin type
$plugin_type = '<span class="font-weight-bold">' . elgg_view('output/text', array(
	'value' => elgg_echo('phloor_plugin:form:plugin_type'),
)) . '</span>';
$plugin_type .= $plugin->plugin_type;

// categories
$categories = elgg_view('output/categories', $vars);

// add to content
$information_list .= <<<HTML
<ul class="phloor-plugin-information">
<li>$licence</li>
<li>$plugin_type</li>
<li>$categories</li>
</ul>
HTML;

$body = $menu . $information_list;

$content = elgg_view_module('aside', $title, $body);


// display content
echo $content;

