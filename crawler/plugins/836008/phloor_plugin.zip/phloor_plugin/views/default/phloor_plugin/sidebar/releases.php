<?php
/**
 * Sidebar - List of Releases of a Plugin
 */

$plugin = elgg_extract('entity', $vars, FALSE);
if(!phloor_plugin_instanceof($plugin)) {
	return true;
}

$title = elgg_echo('phloor_plugin:releases');


// get last 6 latest releases
$view_limit = 5;
$releases = $plugin->getReleases(array(
	'limit' => $view_limit + 1,
));

$release_count = count($releases);

$body = '';
if(empty($releases)) {
	$body .= elgg_echo('phloor_plugin:noreleases');
}
else {
	$list_options = array(
		'full_view' => false,
		'list_type' => 'list',
		'list_type_toggle' => true,
		'pagination' => false,
		'offset' => 0,
		//'limit' => $view_limit, <- does not work. y?
	);
	
	// get the first '$view_list' releases
	$release_list_chunked = array_chunk($releases, $view_limit);
	$release_list = !empty($release_list_chunked) ? $release_list_chunked[0] : array();
	
	elgg_push_context('phloor-plugin-sidebar'); //  remove 'edit and 'delete'
	$body = elgg_view_entity_list($release_list, $list_options);
	elgg_pop_context();
	
	// if user has more than 5 plugins,.. show a "more" link
	if($release_count > $view_limit) {	
		$body .= elgg_view('output/url', array(
			'href' => "phloor_plugin/release/all/{$plugin->guid}",
			'text' => elgg_echo('phloor_plugin:view_all_releases'),
		));
	} 
}

echo elgg_view_module('aside', $title, $body);