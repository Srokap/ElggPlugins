<?php 
/*****************************************************************************
 * Phloor Menuitem                                                           *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php
/**
 * CURRENTLY DISABELD! see bottom!
 * Plugin filter
 *
 * Select beetween all, friends, mine, most downloaded, most recommended
 *
 * @uses $vars['filter_context']  Filter context: all, friends, mine
 * @uses $vars['context']         Page context (override)
 */

$user = elgg_get_logged_in_user_entity();

$filter_context = elgg_extract('filter_context', $vars, 'all');

$context = elgg_get_context();

$all_href = (isset($vars['all_link'])) ? $vars['all_link'] : "phloor_plugin/all";
$url_prefix = "";
if($context == 'admin') {
	$all_href = "$context/appearance/phloor_plugin/all";
	$url_prefix .= "admin/appearance/";
}
// generate a list of default tabs
$tabs = array(
	'all' => array(
		'text' => elgg_echo('all'),
		'href' => $all_href,
		'selected' => ($filter_context == '' || $filter_context == 'all'),
		'priority' => 1,
	),/*
	'newest' => array(
		'text' => elgg_echo('phloor_plugin:filter:newest'),
		'href' =>  $url_prefix . "phloor_plugin/all?sort=newest",
		'selected' => ($filter_context == 'newest'),
		'priority' => 4,
	),*/
	'most_downloaded' => array(
		'text' => elgg_echo('phloor_plugin:filter:most_downloaded'),
		'href' => $url_prefix . "phloor_plugin/all?sort=most_downloaded",
		'selected' => ($filter_context == 'most_downloaded'),
		'priority' => 5,
	), /*
	'most_recommended' => array(
		'text' => elgg_echo('phloor_plugin:filter:most_recommended'),
		'href' => $url_prefix . "phloor_plugin/all?sort=most_recommended",
		'selected' => ($filter_context == 'most_recommended'),
		'priority' => 6,
	),*/
	'latest_releases' => array(
		'text' => elgg_echo('phloor_plugin:filter:latest_releases'),
		'href' => $url_prefix . "phloor_plugin/all?sort=latest_releases",
		'selected' => ($filter_context == 'latest_releases'),
		'priority' => 7,
	),
);

if(elgg_is_logged_in()) {
	$tabs['mine'] = array(
		'text' => elgg_echo('mine'),
		'href' => $url_prefix . "phloor_plugin/owner/{$user->username}",
		'selected' => ($filter_context == 'mine'),
		'priority' => 2,
	);
	$tabs['friends'] = array(
		'text' => elgg_echo('friends'),
		'href' => $url_prefix . "phloor_plugin/friends/{$user->username}",
		'selected' => ($filter_context == 'friends'),
		'priority' => 3,
	);
}

foreach ($tabs as $name => $tab) {
	$tab['name'] = $name;
	elgg_register_menu_item('filter', $tab);
}

echo elgg_view_menu('filter', array('sort_by' => 'priority', 'class' => 'elgg-menu-hz'));

