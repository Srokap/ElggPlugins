<?php
/**
 * Sidebar - Other Plugins of a Member/Group
 */
$plugin = elgg_extract('entity', $vars, FALSE);

if(!phloor_plugin_instanceof($plugin)) {
	return true;
}
$owner     = $plugin->getOwnerEntity();
$container = $plugin->getContainerEntity();

// owner must be user
if(!elgg_instanceof($owner, 'user')) {
	return true;
}

$title = elgg_echo('phloor_plugin:other_plugins');

$view_limit = 5;
$plugins = phloor_plugins_get_plugins_from_container($container, array(
	'limit' => $view_limit + 2, // +2 because a 'more' like may be shown (-1 current plugin)
));
// remove current plugin from plugins
//$plugins = array_diff($plugins, array($plugin));
foreach($plugins as $key => $value) {
	if($value == $plugin) {
		unset($plugins[$key]);
	}
}

$plugin_count = count($plugins);

$body = '';
if(empty($plugins)) {
	$body .= elgg_echo('phloor_plugin:no_other_plugins');
}
else {
	$list_options = array(
		'list_class' => 'elgg-list-entity',
		'full_view' => false,
		'pagination' => true,
		'list_type' => 'list',
		'list_type_toggle' => false,
		'offset' => 0,
		//'limit' => $view_limit,
	);
	
	$title = elgg_echo('phloor_plugin:other_plugins', array($owner->username));
	
	// get the first '$view_list' releases
	$plugin_list_chunked = array_chunk($plugins, $view_limit);
	$plugin_list = !empty($plugin_list_chunked) ? $plugin_list_chunked[0] : array();
	
	elgg_push_context('phloor-plugin-sidebar'); //  remove 'edit and 'delete'
	$body = elgg_view_entity_list($plugin_list, $list_options);
	elgg_pop_context();
	
	// if user has more than 5 plugins,.. show a "more" link
	if($plugin_count > $view_limit) {	
		$username = $owner->username;

		$body .= elgg_view('output/url', array(
			'href' => "phloor_plugin/owner/$username",
			'text' => elgg_echo('phloor_plugin:more_plugins_of_this_user'),
		));
	}
}

echo elgg_view_module('aside', $title, $body);