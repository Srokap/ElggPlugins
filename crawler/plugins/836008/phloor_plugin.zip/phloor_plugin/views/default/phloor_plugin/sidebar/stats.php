<?php
/**
 * Blog archives
 */
$plugin = elgg_extract('entity', $vars, FALSE);

if(!phloor_plugin_instanceof($plugin)) {
	return true;
}

$title = elgg_echo('phloor_plugin:stats');

// categories
$downloads = elgg_echo('phloor_plugin:release:downloads') . ': ' . $plugin->getDownloadCount();

/*$latest_release_time = elgg_view('output/text', array(
	'value' => $latest_release_create_time,
));*/

// create the content
$body = <<<HTML
<ul class="phloor-plugin-stats">
<li>$downloads</li>
</ul>
HTML;

// view module
echo elgg_view_module('aside', $title, $body);
