<?php 
/*****************************************************************************
 * Phloor Plugin                                                            *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php
/**
 * Edit form for releases
 *
 */

$plugin_guid = elgg_extract('plugin_guid', $vars, 0);
$plugin = get_entity($plugin_guid);
$vars['entity'] = $plugin;

if (phloor_plugin_instanceof($plugin) && $plugin->canEdit()) {
	// add a delete button if editing
	$delete_url = "action/phloor_plugin/screenshot/delete?guid={$guid}&element=all";
	$delete_link = elgg_view('output/confirmlink', array(
		'href' => $delete_url,
		'text' => elgg_echo('delete:all'),
		'class' => 'elgg-button elgg-button-delete elgg-state-disabled float-alt'
	));
}

$save_button = elgg_view('input/submit', array(
	'value' => elgg_echo('save'),
	'name' => 'save',
));
$action_buttons = $save_button . $delete_link;


$form_content = '';
$screenshots = $plugin->getScreenshots();

foreach($screenshots as $screenshot) {		
	echo '<pre>';
	print_r($screenshot);
	echo '</pre>';
}

// hidden inputs
$container_guid_input = elgg_view('input/hidden', array('name' => 'container_guid', 'value' => elgg_get_page_owner_guid()));
$plugin_guid_input = elgg_view('input/hidden', array('name' => 'plugin_guid', 'value' => $plugin_guid));

// create content
$content = <<<___HTML
$form_content

<div class="elgg-foot">
	$plugin_guid_input
	$container_guid_input

	$action_buttons
</div>
___HTML;

// output content
echo $content;
