<?php
/**
 * phloor plugin river view.
 */

$object = $vars['item']->getObjectEntity();
$summary = strip_tags($object->summary);
$summary = elgg_get_excerpt($summary);

echo elgg_view('river/elements/layout', array(
	'item' => $vars['item'],
	'message' => $summary,
));