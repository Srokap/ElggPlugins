<?php
/**
 * phloor plugin river view.
 */

$object = $vars['item']->getObjectEntity();
$version = strip_tags($object->version);
$version = elgg_get_excerpt($version);

echo elgg_view('river/elements/layout', array(
	'item' => $vars['item'],
	'message' => $version,
));