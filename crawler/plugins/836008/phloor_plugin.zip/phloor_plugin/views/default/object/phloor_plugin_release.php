<?php 
/*****************************************************************************
 * Phloor Plugin                                                            *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php
/**
 * View of PhloorPluginRelease objects
 *
 */

// get release entity
$release = elgg_extract('entity', $vars, FALSE);
if (!phloor_plugin_release_instanceof($release)) {
	return TRUE;
}

// retrieve plugin
$plugin = $release->getPlugin();
if (!phloor_plugin_instanceof($plugin)) {
	return TRUE;
}

$full = elgg_extract('full_view', $vars, FALSE);

$container = $release->getContainerEntity();
$owner = $release->getOwnerEntity();
$owner_link = elgg_view('output/url', array(
	'href' => "phloor_plugin/owner/$owner->username",
	'text' => $owner->name,
	'is_trusted' => true,
));
$author_text = elgg_echo('byline', array($owner_link));

$categories = elgg_view('output/categories', $vars);
$tags = elgg_view('output/tags', array('tags' => $release->tags));
$date = elgg_view_friendly_time($release->time_created);

$comments_link = '';
// The "on" status changes for comments, so best to check for !Off
if ($release->comments_on != 'Off') {
	$comments_count = $release->countComments();
	//only display if there are commments
	if ($comments_count != 0) {
		$text = elgg_echo("comments") . " ($comments_count)";
		$comments_link = elgg_view('output/url', array(
			'href' => $release->getURL() . '#plugin-release-comments',
			'text' => $text,
			'is_trusted' => true,
		));
	} 
}

$metadata = elgg_view_menu('entity', array(
	'entity' => $release,
	'handler' => 'phloor_plugin_release',
	'sort_by' => 'priority',
	'class' => 'elgg-menu-hz',
));

$subtitle = <<<HTML
$author_text $date $comments_link
HTML;

// do not show the metadata and controls in widget view
if (elgg_in_context('widgets')) {
	$metadata = '';
}

$content = '';
if ($full) { 
	 $release_notes = elgg_view_module('aside', 
		elgg_echo('phloor_plugin:release:notes'),
		elgg_view('output/longtext', array(
			'value' => $release->notes,
			'class' => 'release-notes',
		)),
		array(  
			'class'  => '',   
			'show_inner' => true,
	));

	$body = $release_notes;
	
	$release_icon = elgg_view_entity_icon($release, 'small');
	
	$params = array(
		'entity' => $release,
		'title' => false,
		'metadata' => $metadata,
		'subtitle' => $subtitle,
		'tags' => $tags,
	);
	$params = $params + $vars;

 	$content = elgg_view('object/elements/full', array(
		'summary' => elgg_view('object/elements/summary', $params),
		'icon' => $release_icon,
		'body' => $body,
	));		

} else {	
	$icon_size = 'small';
	if(strcmp('phloor-plugin-sidebar', elgg_get_context()) == 0) {
		$icon_size = 'tiny';
	}
	$release_icon = elgg_view_entity_icon($release, $icon_size);
	
	// brief view
	$version = elgg_view('output/url', array(
		'text' => $release->version,
		'href' => $release->getURL(),
	));
	
	$params = array(
		'entity' => $release,
		'metadata' => $metadata,
		'title' => $version,
		'subtitle' => $subtitle,
		'tags' => $tags,
		'content' => '',
		'icon' => $release_icon,
	);
	$params = $params + $vars;
	//$list_body = elgg_view('object/elements/summary', $params);
	
	$content = elgg_view('object/elements/full', array(
		'summary' => elgg_view('object/elements/summary', $params),
		'icon' => $release_icon,
		'body' => '',
	));
	//$content = elgg_view_image_block($release_icon, $list_body);
}

//output content
echo $content;


