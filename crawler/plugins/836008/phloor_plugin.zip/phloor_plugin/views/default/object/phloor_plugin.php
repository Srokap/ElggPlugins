<?php 
/*****************************************************************************
 * Phloor Plugin                                                            *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php
/**
 * View for Plugin objects
 *
 */

$full = elgg_extract('full_view', $vars, FALSE);
$plugin = elgg_extract('entity', $vars, FALSE);

if (!phloor_plugin_instanceof($plugin)) {
	return TRUE;
}

$container = $plugin->getContainerEntity();
$owner = $plugin->getOwnerEntity();
$owner_link = elgg_view('output/url', array(
	'href' => "phloor_plugin/owner/$owner->username",
	'text' => $owner->name,
	'is_trusted' => true,
));
$author_text = elgg_echo('byline', array($owner_link));

$summary = elgg_get_excerpt($plugin->summary, $full ? 250 : 100);

$categories = elgg_view('output/categories', $vars);
$tags = elgg_view('output/tags', array('tags' => $plugin->tags));
$date = elgg_view_friendly_time($plugin->time_created);

$comments_link = '';
// The "on" status changes for comments, so best to check for !Off
if ($plugin->comments_on != 'Off') {
	$comments_count = $plugin->countComments();
	//only display if there are commments
	if ($comments_count != 0) {
		$text = elgg_echo("comments") . " ($comments_count)";
		$comments_link = elgg_view('output/url', array(
			'href' => $plugin->getURL() . '#plugin-comments',
			'text' => $text,
			'is_trusted' => true,
		));
	} 
}

$metadata = elgg_view_menu('entity', array(
	'entity' => $plugin,
	'handler' => 'phloor_plugin',
	'sort_by' => 'priority',
	'class' => 'elgg-menu-hz',
));


// do not show the metadata and controls in widget view
if (elgg_in_context('widgets')) {
	$metadata = '';
}

$subtitle = <<<HTML
<span class="phloor-plugin-subtitle-summary">$summary</span>
HTML;

$release_guid = get_input('release_guid', 0);
$release = get_entity($release_guid);
if(!phloor_plugin_release_instanceof($release)) {
	//if(!$recommedned_release) { }
	// recommended_release can be null
	$release = $plugin->getRecommendedRelease();
}

// append upload date of latest release
$latest_release = $plugin->getLatestRelease();
if(phloor_plugin_release_instanceof($latest_release)) {
	$latest_upload_text = elgg_echo('phloor_plugin:latest_release_uploaded');
	$latest_upload_text .= elgg_view_friendly_time($latest_release->time_created);

	$subtitle .= <<<HTML
<span class="phloor-plugin-subtitle-latest-release-upload">$latest_upload_text</span>
HTML;
}

$content = '';
if ($full) {
		$subtitle .= <<<HTML
$author_text $date $categories $comments_link
HTML;

	$description = elgg_view_module('aside', 
		// title
		elgg_echo('phloor_plugin:description'),
		// body
		elgg_view('output/longtext', array(
			'value' => $plugin->description,
			'class' => 'plugin-description',
		)),
		// vars
		array(
			//'header' => '',  
			//'footer'  => '',    
			'class'  => '',   
			'show_inner' => true,
	 ));
	 
	$body = $description;
	
	if(phloor_plugin_release_instanceof($release)) {
		// dont use:
		// $release_image_block = elgg_view_entity($release, array(
		//	'full_view' => true,
		//));	
		// 
		// build release view autonomous (todo: pull into a function)			
		$release_metadata = elgg_view_menu('entity', array(
			'entity' => $release,
			'handler' => 'phloor_plugin_release',
			'sort_by' => 'priority',
			'class' => 'elgg-menu-hz',
		));
	
		$release_icon = elgg_view_entity_icon($release, 'tiny');
		$params = array(
			'entity' => $release,
			'title' => elgg_echo('phloor_plugin:release'),
			'metadata' => $release_metadata,
			'subtitle' => $release->version,
			'content' => '',
		);
		$params = $params + $vars;	
		$list_body = elgg_view('object/elements/summary', $params);
		$release_image_block = elgg_view_image_block($release_icon, $list_body);
		
		$release_description = elgg_view_module('aside', 
			elgg_echo('phloor_plugin:release:description'),
			elgg_view('output/longtext', array(
				'value' => !empty($release->description) ? $release->description : elgg_echo('none'), //empty
				'class' => 'release-description',
			)),
			array(  
				'class'  => '',   
				'show_inner' => true,
		));
		$release_notes = elgg_view_module('aside', 
			elgg_echo('phloor_plugin:release:notes'),
			elgg_view('output/longtext', array(
				'value' => !empty($release->notes) ? $release->notes : elgg_echo('none'), //empty
				'class' => 'release-notes',
			)),
			array(  
				'class'  => '',   
				'show_inner' => true,
		));

		// append release image block + description and notes to body
		$body .= <<<HTML
$release_image_block
$release_description
$release_notes	
HTML;
			
	} else {
		$body .= elgg_view_module('aside', elgg_echo('phloor_plugin:noreleases'), '');
	}

	$params = array(
		'entity' => $plugin,
		'title' => false,
		'metadata' => $metadata,
		'subtitle' => $subtitle,
		'tags' => $tags,
	);
	$params = $params + $vars;
	
 	$content = elgg_view('object/elements/full', array(
		'summary' => elgg_view('object/elements/summary', $params),
		'icon' => elgg_view_entity_icon($plugin, 'thumb'),
		'body' => $body,
	));
	
} else {
	// brief view
	$title = elgg_view('output/url', array(
		'text' => $plugin->title,
		'href' => elgg_get_site_url() . phloor_plugin_url_handler($plugin),
	));
	
	$icon_size = 'thumb';
	if(strcmp('phloor-plugin-sidebar', elgg_get_context()) == 0) {
		$icon_size = 'tiny';
	}
	
	$plugin_icon = elgg_view_entity_icon($plugin, $icon_size);
	
	$params = array(
		'entity' => $plugin,
		'metadata' => $metadata,
		'title' => $title,
		'subtitle' => $subtitle,
		'tags' => $tags,
		'content' => '',
		'icon' => $plugin_icon,
	);
	$params = $params + $vars;
	
	$content = elgg_view('object/elements/full', array(
		'summary' => elgg_view('object/elements/summary', $params),
		'icon' => $plugin_icon,
	));
}


// display content
echo $content;
