<?php 
/*****************************************************************************
 * Phloor Plugin                                                            *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php

$english = array(
	"admin:plugins:category:PHLOOR" => "PHLOOR Plugins",
	'admin:appearance:phloor_plugin' => 'Plugins',
	
	'phloor_plugin' => 'Plugins',
	'phloor_plugin:plugins' => 'Plugins',
	'phloor_plugin:phloor_plugins' => 'Plugins',
	'phloor_plugin:group' => 'Group plugins',
	'phloor_plugin:release' => 'Release',
	'phloor_plugin:releases' => 'Releases',
	'phloor_plugin:view_all_releases' => 'View all releases',

	'phloor_plugin:initial_commit' => 'initial commit',
	'phloor_plugin:see_readme_txt' => 'see README.txt',

	'phloor_plugin:enablephloor_plugin' => 'Enable group plugins',

	'item:object:phloor_plugin' => 'Plugins',
	'item:object:phloor_plugin_release' => 'Releases',


	'phloor_plugin:admin:appearance:title' => "Your site plugins",
	'phloor_plugin:admin:appearance:description' => "Here you can manage the plugins of your site. ",
	'phloor_plugin:admin:appearance:entity_count' => "Plugin count: %s ",
	'phloor_plugin:admin:appearance:new_plugin:title' => 'Create new plugin',

	'phloor_plugin:title' => 'Name',
	'phloor_plugin:summary' => 'Summary',
	'phloor_plugin:description' => 'Description',
	'phloor_plugin:licence' => 'Licence',
	'phloor_plugin:plugin_type' => 'Type',
	'phloor_plugin:category' => 'Category',
	'phloor_plugin:website' => 'Website',
	'phloor_plugin:code_repository' => 'Code Repository',
	'phloor_plugin:donations_url' => 'Donations URL',
	'phloor_plugin:tags' => 'Tags',
	'phloor_plugin:comments_on' => 'Allow comments',
	'phloor_plugin:access_id' => 'Read access',
	'phloor_plugin:price' => 'Price',
	'phloor_plugin:image' => 'Image',
	
	'phloor_plugin:form:title' => 'Name*: ',
	'phloor_plugin:form:summary' => 'Summary*: ',
	'phloor_plugin:form:description' => 'Description*: ',
	'phloor_plugin:form:licence' => 'Licence: ',
	'phloor_plugin:form:plugin_type' => 'Type: ',
	'phloor_plugin:form:category' => 'Category: ',
	'phloor_plugin:form:website' => 'Website: ',
	'phloor_plugin:form:code_repository' => 'Code Repository: ',
	'phloor_plugin:form:donations_url' => 'Donations URL: ',
	'phloor_plugin:form:tags' => 'Tags: ',
	'phloor_plugin:form:comments_on' => 'Allow comments: ',
	'phloor_plugin:form:access_id' => 'Read access: ',
	'phloor_plugin:form:price' => 'Price: ',
	'phloor_plugin:form:image' => 'Image: ',
	'phloor_plugin:form:delete_image' => 'Delete image? ',

	'phloor_plugin:title:description' => '',
	'phloor_plugin:plugin_type:description' => '',
	'phloor_plugin:summary:description' => 'A one- or two-sentence (250 characters) summary of your project\'s main features. ',
	'phloor_plugin:licence:description' => 'Please select a the appropriate licence for this plugin from the list. ',
	'phloor_plugin:description:description' => 'A full description of your project\'s features. ',
	'phloor_plugin:website:description' => 'Insert the url of the plugins website. (optional) ',
	'phloor_plugin:code_repository:description' => 'Insert the code repository url. (optional) ',
	'phloor_plugin:donations_url:description' => 'If you accept donations, enter the URL to the donations section of your website. (optional) ',
	'phloor_plugin:image:description' => 'Upload a logo for the plugin. (optional) ',
	'phloor_plugin:tags:description' => 'A comma-separated list of tags relevant to your project. (optional) ',
	'phloor_plugin:comments_on:description' => '',
	'phloor_plugin:access_id:description' => 'The access level of the project. Note that individual releases can have their own access settings. ',
	'phloor_plugin:delete_image:description' => 'The activation of this checkbox results in the deletion of the current image. ',

	'phloor_plugin:message:saved' => 'Plugin as been successfully saved. ',
	'phloor_plugin:message:deleted_plugin' => 'Plugin has been successfully deleted. ',
	'phloor_plugin:error:cannot_save' => 'Plugin can not be saved. ',
	'phloor_plugin:error:cannot_edit_plugin' => 'Plugin can not be edited. ',
	'phloor_plugin:error:cannot_delete_plugin' => 'Plugin can not be deleted. ',

	'phloor_plugin:error:plugin_not_found' => 'Plugin not found. ',
	'phloor_plugin:error:wrong_mimetype' => 'The picture you\'ve uploaded is invalid. Error 483: Invalid mimetype %s ',
	'phloor_plugin:error:missing:title' => 'Please insert a title. ',
	'phloor_plugin:error:missing:description' => 'Please insert a description. ',
	'phloor_plugin:error:missing:image' => 'Please upload an image. ',


	'phloor_plugin:title:all_phloor_plugins' => 'All plugins',
	'phloor_plugin:title:all_plugins' => 'All plugins',
	'phloor_plugin:title:friends' => 'Friends plugins',
	'phloor_plugin:title:user_phloor_plugins' => '%s\'s plugins',

    /** FILTER */
	'phloor_plugin:title:latest_releases'          => 'Latest releases',
    'phloor_plugin:title:most_downloaded_plugins'  => 'Most downloaded',
    'phloor_plugin:title:most_recommended_plugins' => 'Most recommended',


	'phloor_plugin:edit' => 'Edit',
	'phloor_plugin:add' => 'Add plugin',
	'phloor_plugin:none' => 'No plugins found. ',

	'phloor_plugin:input:plugin_type:plugin' => 'Plugin',
	'phloor_plugin:input:plugin_type:theme' => 'Theme',
	'phloor_plugin:input:plugin_type:languagepack' => 'Language Pack',

	"phloor_plugin:input:licence:gpl2"          => 'GNU General Public License (GPL) version 2',
	"phloor_plugin:input:licence:gpl3"          => 'GNU General Public License (GPL) version 3',
	"phloor_plugin:input:licence:lgpl2.1"       => 'GNU Lesser General Public License (LGPL) version 2.1',
	"phloor_plugin:input:licence:mit"           => 'MIT License',
	"phloor_plugin:input:licence:mbsd"          => 'Modified BSD license',
	"phloor_plugin:input:licence:cbsd"          => 'The Clear BSD License',
	"phloor_plugin:input:licence:cca-sa3.0"     => 'Creative Commons Attribution-ShareAlike 3.0 Unported License',
	"phloor_plugin:input:licence:cca3.0"        => 'Creative Commons Attribution 3.0 Unported License',
	"phloor_plugin:input:licence:cca-nd3.0"     => 'Creative Commons Attribution-NoDerivs 3.0 Unported License',
	"phloor_plugin:input:licence:cca-nc3.0"     => 'Creative Commons Attribution-NonCommercial 3.0 Unported License',
	"phloor_plugin:input:licence:cca-nc-sa3.0"  => 'Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License',
	"phloor_plugin:input:licence:cca-nc-nd3.0"  => 'Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License',

	"phloor_plugin:menu:download"        => 'Download',
	"phloor_plugin:menu:newscreenshot"   => 'Upload Screenshot',
	"phloor_plugin:menu:newrelease"      => 'Upload New Release',
	"phloor_plugin:menu:editplugin"      => 'Edit Plugin Details',
	"phloor_plugin:menu:release:edit"    => 'Edit Release Details',
	"phloor_plugin:menu:delete"          => 'Delete Plugin',
	"phloor_plugin:menu:website"         => 'Plugin Website',
	"phloor_plugin:menu:code_repository" => 'Code Repository',
	"phloor_plugin:menu:donations_url"   => 'Donations',
	'phloor_plugin:menu:new'             => 'Upload New Plugin',

	'phloor_plugin:menu:set_as_recommended_release' => 'Set as recommended release',

	'phloor_plugin:plugin_information' => 'Plugin Information',
	'phloor_plugin:stats' => 'Stats',
	"phloor_plugin:releases"   => 'Releases',
	"phloor_plugin:screenshots"   => 'Screenshots',
	"phloor_plugin:likes"   => 'Likes',
	'phloor_plugin:other_plugins' => 'Other Plugins',

	"phloor_plugin:noscreenshots"   => 'No screenshots. ',
	"phloor_plugin:noreleases"   => 'No releases. ',
	'phloor_plugin:no_other_plugins' => 'No other plugins. ',

	"phloor_plugin:delete:confirm"   => 'Do you really want to delete this plugin? Everything related to this plugin will be lost (releases, archives, comments, ..). This opteration can not be undone. ',

	// river
	'river:create:object:phloor_plugin' => '%s published the plugin %s',
	'river:comment:object:phloor_plugin' => '%s commented on the plugin %s',
	'river:create:object:phloor_plugin_release' => '%s published a new release %s',
	'river:comment:object:phloor_plugin_release' => '%s commented on the plugin %s',

	// release
	'phloor_plugin:release:edit' => 'Edit',

	'phloor_plugin:release:version'       => 'Version',
	'phloor_plugin:release:file'          => 'Archive',
	'phloor_plugin:release:notes'         => 'Release notes',
	'phloor_plugin:release:comments_on'   => 'Allow comments',
	'phloor_plugin:release:access_id'     => 'Read access',
	'phloor_plugin:release:recommended_release' => 'Recommended Release',
	'phloor_plugin:release:description' => 'Release Description',

	'phloor_plugin:release:compatible_version' => 'Compatible version',

	'phloor_plugin:release:form:version'     => 'Version*: ',
	'phloor_plugin:release:form:file'        => 'Archive*: ',
	'phloor_plugin:release:form:notes'       => 'Release notes*: ',
	'phloor_plugin:release:form:comments_on' => 'Allow comments: ',
	'phloor_plugin:release:form:access_id'   => 'Read access: ',
	'phloor_plugin:release:form:recommended_release' => 'Set as recommended release? ',
	'phloor_plugin:release:form:description' => 'Description:',
	'phloor_plugin:release:form:compatible_version' => 'Compatible version: ',

	'phloor_plugin:release:version:description' => ' ',
	'phloor_plugin:release:file:description'    => 'Uploaded files must contain a working plugin or theme. Allowed mimetypes are \'application/zip\' and \'application/x-compressed-tar\'. CURRENTLY ONLY \'application/zip\' (.zip) SUPPORTED. ',
	'phloor_plugin:release:notes:description'   => 'A list of changes, bugfixes, bugs, todos, and general release notes for this release. ',
	'phloor_plugin:release:comments_on:description' => ' ',
	'phloor_plugin:release:access_id:description' => 'The access level of this release. Useful if you want to release only to a certain group or collection. ',
	'phloor_plugin:release:description:description' => 'Describe the specifics of this release. (optional)',
	'phloor_plugin:release:recommended_release:description' => 'Recommend all users of this plugin use this release? The activation of this box results in setting this release as recommended release. The latest uploaded release is always the recommended release if it has never been activated yet',
	'phloor_plugin:release:description:description' => '(optional)',
	'phloor_plugin:release:compatible_version:description' => 'The version of Elgg this plugin was developed and tested on',

	'phloor_plugin:release:downloads' => 'Downloads',
	'phloor_plugin:release:uploaded' => 'Uploaded',
	'phloor_plugin:release:filename' => 'File',

	'phloor_plugin:release:no_release' => 'No release available.',

	'phloor_plugin:release:message:saved' => 'Release as been successfully saved. ',
	'phloor_plugin:release:message:deleted_release' => 'Release has been successfully deleted. ',
	'phloor_plugin:release:error:cannot_save' => 'Release can not be saved. ',
	'phloor_plugin:release:error:cannot_edit_release' => 'Release can not be edited. ',
	'phloor_plugin:release:error:cannot_delete_release' => 'Release can not be deleted. ',

	'phloor_plugin:filter:newest'           => 'Newest',
	'phloor_plugin:filter:most_downloaded'  => 'Most downloaded',
	'phloor_plugin:filter:most_recommended' => 'Most recommended',
	'phloor_plugin:filter:lastest_releases' => 'Latest releases',

	'phloor_plugin:release:set_as_recommended_release' => 'Set as recommended release',

	'phloor_plugin:release:download_warning:title' => 'Warning!',
	'phloor_plugin:release:download_warning:body' => 'The author recommends using a different release of this plugin!',

	'phloor_plugin:all:releases:title' => 'All releases of %s',

	'phloor_plugin:release:download:not_recommended:confirm' => 'The author recommends using a different release of this plugin! I understand the potential risks and I really want this release and not the recommended one. ',

	'phloor_plugin:newscreenshot' => 'Upload new screenshot',

	'phloor_plugin:release:add' => 'Add release',
	'phloor_plugin:release:file_mime_type_not_supported' => 'Error 1337: invalid mimetype - Mimetype not supported. (%s)',

	'phloor_plugin:release_info' => 'Release Information',
	'phloor_plugin:release:uploaded' => 'Uploaded',
	'phloor_plugin:release:md5' => 'Hash (md5)',

	'phloor_plugin:menu:release:recommended_release' => 'Recommended Release',
	'phloor_plugin:more_plugins_of_this_user' => 'More plugins',

	'phloor_plugin:latest_release_uploaded' => 'Latest release uploaded ',
	'phloor_plugin:filter:latest_releases' => 'Latest releases',

	'phloor_plugin:release:recommendation:successful' => 'This is now the recommended release. ',

	// compatible version picker
	"elgg-1.8"       => "Elgg 1.8",
	"elgg-1.8.1"     => "Elgg 1.8.1",
	"elgg-1.8.2"     => "Elgg 1.8.2",
	"elgg-1.9-dev"   => "Elgg 1.9-dev",
	"phloor-1.8"     => "Phloor 1.8",
	"phloor-1.9-dev" => "Phloor 1.9-dev",

    'phloor_plugin:release:noplugin' => 'The plugin could not be found or you do not have the rights to access it.',


);

add_translation("en", $english);
