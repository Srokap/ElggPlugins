<?php 
/*****************************************************************************
 * Phloor Plugin                                                             *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php
/**
 * Phloor Plugin Portfolio
 */

elgg_register_event_handler('init', 'system', 'phloor_plugin_portfolio_init_1', 1);
elgg_register_event_handler('init', 'system', 'phloor_plugin_portfolio_init_500', 500);

function phloor_plugin_portfolio_init_1() {	
	/**
	 * LIBRARY
	 * register a library of helper functions
	 */
	$lib_path = elgg_get_plugins_path() . 'phloor_plugin/lib/';
	elgg_register_library('phloor-plugin-lib', $lib_path . 'phloor_plugin.lib.php');
	elgg_register_library('phloor-plugin-release-lib', $lib_path . 'phloor_plugin_release.lib.php');
	elgg_register_library('phloor-plugin-screenshot-lib', $lib_path . 'phloor_plugin_screenshot.lib.php');
	
	elgg_load_library('phloor-plugin-lib');
	elgg_load_library('phloor-plugin-release-lib');
	elgg_load_library('phloor-plugin-screenshot-lib');
}

function phloor_plugin_portfolio_init_500() {	
	/**
	 * Site Menu Item
	 */
	$item = new ElggMenuItem('plugin', elgg_echo('phloor_plugin:plugins'), 'phloor_plugin/all');
	elgg_register_menu_item('site', $item);

	/**
	 * Register for search.
	 */ 
	elgg_register_entity_type('object', 'phloor_plugin');	
	
	/**
	 * Entity url handler
	 */
	elgg_register_entity_url_handler('object', 'phloor_plugin',         'phloor_plugin_url_handler');
	elgg_register_entity_url_handler('object', 'phloor_plugin_release', 'phloor_plugin_release_url_handler');
	
	/**
	 * CSS
	 */
	elgg_extend_view('css/admin', 'phloor_plugin/css/admin');
	elgg_extend_view('css/elgg',  'phloor_plugin/css/elgg' );
	
	/**
	 * Admin menu
	 */
	//elgg_register_admin_menu_item('configure', 'phloor_plugin', 'appearance');
	
	/**
	 * Owner menu
	 */ 
	elgg_register_plugin_hook_handler('register', 'menu:owner_block', 'phloor_plugin_owner_block_menu');
	
	/**
	 * Entity menu
	 */
	// phloor_plugin
	elgg_register_plugin_hook_handler('register', 'menu:entity', 'phloor_plugin_register_entity_menu_setup', 999);
	elgg_register_plugin_hook_handler('prepare',  'menu:entity', 'phloor_plugin_prepare_entity_menu_setup',  999);
	elgg_register_plugin_hook_handler('register', 'menu:page',   'phloor_plugin_register_page_menu_setup', 999);
	//elgg_register_plugin_hook_handler('prepare',  'menu:page',   'phloor_plugin_prepare_page_menu_setup',  999);
	elgg_register_plugin_hook_handler('register', 'menu:title',  'phloor_plugin_register_title_menu_setup', 999);
	//elgg_register_plugin_hook_handler('prepare',  'menu:title',  'phloor_plugin_prepare_title_menu_setup',  999);
	// phloor_plugin_release
	elgg_register_plugin_hook_handler('register', 'menu:entity', 'phloor_plugin_release_register_entity_menu_setup', 999);
	elgg_register_plugin_hook_handler('prepare',  'menu:entity', 'phloor_plugin_release_prepare_entity_menu_setup',  999);
	elgg_register_plugin_hook_handler('register', 'menu:page',   'phloor_plugin_release_register_page_menu_setup', 999);
	//elgg_register_plugin_hook_handler('prepare',  'menu:page',   'phloor_plugin_release_prepare_page_menu_setup',  999);
	elgg_register_plugin_hook_handler('register', 'menu:title',  'phloor_plugin_release_register_title_menu_setup', 999);
	//elgg_register_plugin_hook_handler('prepare',  'menu:title',  'phloor_plugin_release_prepare_title_menu_setup',  999);
	
	
	/**
	 * Group options
	 */
	// only admins can see the option to enable plugins for groups
	if(elgg_is_admin_logged_in()) {
		add_group_tool_option('phloor_plugin', elgg_echo('phloor_plugin:enablephloor_plugin'), false);
	}
	elgg_extend_view('groups/tool_latest', 'phloor_plugin/group_module');
	
	/**
	 * Actions
	 */
	$action_path = elgg_get_plugins_path() . 'phloor_plugin/actions/phloor_plugin';
	elgg_register_action('phloor_plugin/save',   "$action_path/save.php");
	elgg_register_action('phloor_plugin/delete', "$action_path/delete.php");
	
	$action_path = elgg_get_plugins_path() . 'phloor_plugin/actions/phloor_plugin/release';
	elgg_register_action('phloor_plugin/release/save',     "$action_path/save.php");
	elgg_register_action('phloor_plugin/release/delete',   "$action_path/delete.php");
	elgg_register_action('phloor_plugin_release/delete',   "$action_path/delete.php");
	elgg_register_action('phloor_plugin/release/download', "$action_path/download.php");
	elgg_register_action('phloor_plugin/release/set_recommended_release', "$action_path/set_as_recommended_release.php");

	/**
	 * Page handler
	 */
	global $CONFIG;
	elgg_register_page_handler('phloor_plugin', 'phloor_plugin_page_handler');
	if (!isset($CONFIG->pagehandler['plugins'])) {
		elgg_register_page_handler('plugins', 'phloor_plugin_page_handler');
	}
	
	elgg_register_page_handler('phloor_plugin_screenshot', 'phloor_plugin_screenshot_page_handler');
	elgg_register_page_handler('phloor_plugin_release',    'phloor_plugin_release_page_handler');
	
	// temporarily load set config on every init
	// @todo: better in phloor_menuitem_run_once?
	//(attribute_name => input_view)
	elgg_set_config('phloor_plugin', array(
		'title'            => 'input/text',
		'summary'          => 'input/text',
	    'description'      => 'input/longtext',
		'delete_image'     => 'phloor/input/enable',
	    'image'            => 'input/file',
	    'licence'          => 'phloor_plugin/input/licence-picker',
	    'plugin_type'      => 'phloor_plugin/input/plugin-type-picker',
	    'website'          => 'input/text',
	    'code_repository'  => 'input/text',
	    'donations_url'    => 'input/text',
	    'tags'             => 'input/tags',
	    'comments_on'      => 'input/dropdown',
		'access_id'        => 'input/access',
	    //'donate'            => 'input/text',
	));
	
	elgg_set_config('phloor_plugin_release', array(
		'file'                => 'input/file',
	    'recommended_release' => 'phloor/input/enable', // wont be stored
		'version'             => 'input/text',
	    'description'         => 'input/longtext',
	    'notes'               => 'input/longtext', 
	    'compatible_version'  => 'phloor_plugin/input/compatible-version-picker', 
		'access_id'           => 'input/access', 
	    'comments_on'         => 'input/dropdown',  
	));
}

/**
 * 
 * Page handler for 'phloor_plugin'
 * and (if not overwritten) 'plugin'
 * 
 * @param unknown_type $page
 */
function phloor_plugin_page_handler($page) {
	if (!isset($page[0])) {
		$page[0] = 'all';
	}

	$layout = 'content';

	elgg_push_breadcrumb(elgg_echo('phloor_plugin:plugins'), "phloor_plugin/all");
	
	$page_type = $page[0];
	switch ($page_type) {
		case 'owner':
			$user = get_user_by_username($page[1]);
			$params = phloor_plugin_get_page_content_list($user->guid);
			break;		
		case 'group':
			$group = get_entity($page[1]);
			if(!elgg_instanceof($group, 'group')) {
				return false;
			}
			$params = phloor_plugin_get_page_content_list($group->guid);
			break;
		case 'friends':
			$user = get_user_by_username($page[1]);
			$params = phloor_plugin_get_page_content_friends($user->guid);
			break;
		case 'view':
			$params = phloor_plugin_get_page_content_read($page[1]);
			$layout = 'two_sidebar';
			break;
		case 'add':
			gatekeeper();
			$params = phloor_plugin_get_page_content_edit($page_type, $page[1]);
			break;
		case 'edit':
			gatekeeper();
			$params = phloor_plugin_get_page_content_edit($page_type, $page[1]);
			break;
		case 'release':
			elgg_pop_breadcrumb();
			return phloor_plugin_release_page_handler($page);
		case 'all':
			$params = phloor_plugin_get_page_content_list();
			break;
		default:
			return false;
	}

	if (isset($params['sidebar'])) {
		$params['sidebar'] .= elgg_view('phloor_plugin/sidebar', array('page' => $page_type));
	} else {
		$params['sidebar'] = elgg_view('phloor_plugin/sidebar', array('page' => $page_type));
	}
	
	$body = elgg_view_layout($layout, $params);
	
	echo elgg_view_page($params['title'], $body);
	
	return true;
}


/**
 * Format and return the URL for plugins.
 *
 * @param PhloorPlugin $entity plugin object
 * @return string URL of plugin.
 */
function phloor_plugin_url_handler($entity) {
	if (!$entity->getOwnerEntity()) {
		return FALSE;
	}
	$friendly_title = elgg_get_friendly_title($entity->title);
	return "phloor_plugin/view/{$entity->guid}/$friendly_title";
}

/**
 * Format and return the URL for plugins.
 *
 * @param PhloorPlugin $entity plugin object
 * @return string URL of plugin.
 */
function phloor_plugin_release_url_handler($entity) {
	if(!elgg_instanceof($entity)) {
		return false;
	}
	
	if (!$entity->getOwnerEntity()) {
		return FALSE;
	}	
	$friendly_version = $entity->version ? elgg_get_friendly_title($entity->version) : '';
	$return = "phloor_plugin/release/view/{$entity->guid}/$friendly_title";
	
	/*
	if (phloor_plugin_release_instanceof($entity)) {
		$plugin = $entity->getPlugin();
		$return = phloor_plugin_url_handler($plugin) . "/$friendly_version";
	} */
	
	return $return;
}

function phloor_plugin_release_page_handler($page) {
	if (!isset($page[0]) || !isset($page[1])) {
		return false;
	}
		
	$page_type = $page[0];
	$guid = $page[1];
	if(strcmp('release', $page[0]) == 0) {
		if(!isset($page[2])) {
			return false;
		}
		
		$page_type = $page[1];
		$guid = $page[2];		
	}
	
	// route through plugin page handler on 'view'
	if(strcmp('view', $page_type) == 0) {
		$release = get_entity($guid);
		if(!phloor_plugin_release_instanceof($release)) {
			register_error(elgg_echo('phloor_plugin:release:norelease'));
			return false;
		}
		
		$plugin = $release->getPlugin();
		if(!phloor_plugin_instanceof($plugin)) {
			register_error(elgg_echo('phloor_plugin:release:noplugin'));
			return false;
		}
		set_input('release_guid', $guid);
		set_input('plugin_guid', $plugin->guid);
		return phloor_plugin_page_handler(array('view', $plugin->guid));
	}
	
	switch ($page_type) {
		case 'add':
			gatekeeper();
			set_input('plugin_guid', $guid); // page type 'add' takes a plugin guid
			$params = phloor_plugin_release_get_page_content_edit($page_type, $guid);
			break;		
		case 'download':
			$release = get_entity($guid);
			if(!phloor_plugin_release_instanceof($release)) {
				register_error(elgg_echo('phloor_plugin:release:norelease'));
				return false;
			}
			set_input('release_guid', $release->guid);
			phloor_plugin_release_get_page_content_download($guid);
			return true;
		case 'edit':			
			$release = get_entity($guid);
			if(!phloor_plugin_release_instanceof($release)) {
				register_error(elgg_echo('phloor_plugin:release:norelease'));
				return false;
			}
			$plugin = $release->getPlugin();			
			if(!phloor_plugin_instanceof($plugin)) {
				register_error(elgg_echo('phloor_plugin:release:noplugin'));
				return false;
			}
			set_input('release_guid', $guid);
			set_input('plugin_guid', $plugin->guid);
			$params = phloor_plugin_release_get_page_content_edit($page_type, $guid);
			break;		
		case 'all':
			set_input('plugin_guid', $guid); // page type 'all' takes a plugin guid
			$params = phloor_plugin_release_get_page_content_list($guid);
			break;
		default:
			return false;
	}

	if (isset($params['sidebar'])) {
		$params['sidebar'] .= elgg_view('phloor_plugin/sidebar', array('page' => $page_type));
	} else {
		$params['sidebar'] = elgg_view('phloor_plugin/sidebar', array('page' => $page_type));
	}
	
	$body = elgg_view_layout('content', $params);

	echo elgg_view_page($params['title'], $body);
	
	return true;
}

/**
 * Add a menu item to an ownerblock
 */
function phloor_plugin_owner_block_menu($hook, $type, $return, $params) {
	if (elgg_instanceof($params['entity'], 'user')) {
		$url = "phloor_plugin/owner/{$params['entity']->username}";
		$item = new ElggMenuItem('phloor_plugin', elgg_echo('phloor_plugin'), $url);
		$return[] = $item;
	} else {
		if ($params['entity']->phloor_plugin_enable != "no") {
			$url = "phloor_plugin/group/{$params['entity']->guid}/all";
			$item = new ElggMenuItem('phloor_plugin', elgg_echo('phloor_plugin:group'), $url);
			$return[] = $item;
		}
	}

	return $return;
}