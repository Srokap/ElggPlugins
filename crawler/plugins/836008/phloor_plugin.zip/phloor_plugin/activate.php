<?php

if (get_subtype_id('object', 'phloor_plugin')) {
	update_subtype('object', 'phloor_plugin', 'PhloorPlugin');
} else {
	add_subtype('object', 'phloor_plugin', 'PhloorPlugin');
}

if (get_subtype_id('object', 'phloor_plugin_release')) {
	update_subtype('object', 'phloor_plugin_release', 'PhloorPluginRelease');
} else {
	add_subtype('object', 'phloor_plugin_release', 'PhloorPluginRelease');
}

if (get_subtype_id('object', 'phloor_plugin_screenshot')) {
	update_subtype('object', 'phloor_plugin_screenshot', 'PhloorPluginScreenshot');
} else {
	add_subtype('object', 'phloor_plugin_screenshot', 'PhloorPluginScreenshot');
}
