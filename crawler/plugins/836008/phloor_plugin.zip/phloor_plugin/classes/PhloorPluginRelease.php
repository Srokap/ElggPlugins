<?php
/*****************************************************************************
 * Phloor Plugin                                                             *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php

//include_once(elgg_get_plugins_path() . 'phloor/classes/AbstractPhloorElggFile.php');

/**
 *
 */
class PhloorPluginRelease extends AbstractPhloorElggFile implements IPhloorPluginRelease {

    public function __construct($guid = null) {
        parent::__construct($guid);
    }

    /**
     * Set subtype to phloor_plugin_release.
     */
    protected function initializeAttributes() {
        parent::initializeAttributes();

        $this->attributes['subtype'] = "phloor_plugin_release";
    }

    /**
     * @see ElggObject::save()
     */
    public function save() {
        $return = parent::save();
        return $return;
    }

    public function delete() {
        $return = true;
        if($this->hasFile()) {
            $this->deleteFile();
        }

        $return = parent::delete();
        return $return;
    }


    public function getURL() {
        $version = ereg_replace('[^\.A-Za-z0-9]', '-', $this->version);
        $url = "phloor_plugin/release/view/{$this->guid}/{$version}";
        return $url;
    }

    /**
     * get the url of the icon
     */
    public function getIconURL($size = 'small') {
        $guid = $this->getGUID();

        $sizes = array('tiny', 'small', 'medium', 'large');
        if(!in_array($size, $sizes)) {
            $size = 'small';
        }

        // determine folder of icon (default, recommended_release)
        $folder = 'default';
        $folder = $this->isRecommendedRelease() ? 'recommended_release' : $folder;

        $image_url = "mod/phloor_plugin/graphics/icons/phloor_plugin_release/$folder/$size.png";

        return elgg_normalize_url($image_url);
    }

    /**
     * get the plugin entity
     */
    public function getPlugin() {
        // return the plugin entity from releationship
        return phloor_plugin_release_get_plugin($this);
    }

    /**
     * get the plugin entity
     */
    public function isRecommendedRelease() {
        $plugin = $this->getPlugin();
        if(!$plugin) {
            return false;
        }
        
        return $plugin->isRecommendedRelease($this);
    }

    /*********************************
     * FILE
     *********************************/

    public function getFileURL() {
        $guid = $this->getGUID();
        $file_url = "mod/phloor_plugin/download.php?release_guid=$guid";
        return elgg_normalize_url($file_url);
    }

    protected function deleteFile() {
        $return = false;

        if($this->hasFile()) {
            $return = @unlink($this->file);
        }

        return $return;
    }
    /*********************************
     * FILE - END
     *********************************/

    /*********************************
     * Getter/Setter
     *********************************/

    /**
     * Getter for notes
     */
    public function getNotes() {
        return $this->notes;
    }

    /**
     * Setter for notes
     */
    public function setNotes($notes) {
        $this->notes = $notes;
    }

    /**
     * Getter for version
     */
    public function getVersion() {
        return $this->version;
    }

    /**
     * Setter for version
     */
    public function setVersion($version) {
        $this->version = $version;
    }

    /*********************************
     * Getter/Setter - END
     *********************************/

}