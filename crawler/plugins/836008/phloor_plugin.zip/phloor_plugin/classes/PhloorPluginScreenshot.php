<?php 
/*****************************************************************************
 * Phloor Plugin                                                             *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php

/**
 * 
 */
class PhloorPluginScreenshot extends AbstractPhloorElggThumbnails implements IPhloorPluginScreenshot {
	public function getThumbnailURL($size = 'tiny') {
		$sizes = array('tiny', 'small', 'medium', 'large');
		if(!in_array($size, $sizes)) {
			$size = 'small';		
		}
		
		$thumb_url = "mod/phloor/thumbnail.php?guid={$this->guid}&size={$size}";
		
		return elgg_normalize_url($thumb_url);
	}
	public function __construct($guid = null) {
		parent::__construct($guid);
	}
	
	/**
	 * Set subtype to phloor_plugin.
	 */
	protected function initializeAttributes() {
		parent::initializeAttributes();

		$this->attributes['subtype'] = "phloor_plugin_screenshot";
	}
	
	public function getIconURL($size = 'tiny') {
		return $this->getImageURL($size);
	}
	
	/*********************************
	 * IMAGE
	 *********************************/	
	public function deleteImage() {
		return parent::deleteImage(); 
	}
	/*********************************
	 * IMAGE - END
	 *********************************/
	
	/*********************************
	 * Getter/Setter
	 *********************************/	
	/**
	 * Getter for title
	 */
	public function getTitle() {
		return $this->title;
	}	
	
	/**
	 * Setter for title
	 */
	public function setTitle($title) {
		$this->title = $title;
	}		
	/*********************************
	 * Getter/Setter - END
	 *********************************/	
}