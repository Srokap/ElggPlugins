<?php
/*****************************************************************************
 * Phloor Plugin                                                             *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php

//include_once(elgg_get_plugins_path() . 'phloor/classes/AbstractPhloorElggThumbnails.php');

/**
 *
 */
class PhloorPlugin extends AbstractPhloorElggThumbnails implements IPhloorPlugin {
    public function __construct($guid = null) {
        parent::__construct($guid);
    }

    /**
     * Set subtype to phloor_plugin.
     */
    protected function initializeAttributes() {
        parent::initializeAttributes();

        $this->attributes['subtype'] = "phloor_plugin";
    }

    /**
     * @see ElggObject::save()
     */
    public function save() {
        $return = parent::save();
        return $return;
    }

    /**
     * deletes orginal image (and thumbnails) + all releases
     *
     * @see ElggEntity::delete()
     */
    public function delete() {
        $success = $this->deleteReleases(); // delete all releases

        if($success) {
            return parent::delete();
        }

        //return $success ? parent::delete() : false;
        return false;
    }

    public function getIconURL($size = 'tiny') {
        return $this->getImageURL($size);
    }

    /*********************************
     * IMAGE
     *********************************/
    /**
     * get the url for the image
     */
    public function getImageURL($size = 'tiny') {
        $sizes = array('tiny', 'thumb', 'small', 'medium', 'large');
        if(!in_array($size, $sizes)) {
            $size = 'small';
        }

        if($this->hasImage()) {
			return $this->getThumbnailURL($size);
		}

        // determine folder of icon (default, missing_release or private_plugin)
        $folder = 'default';
        $folder = ($this->access_id == ACCESS_PRIVATE) ? 'private_plugin' : $folder;
        if(!phloor_plugin_release_instanceof($this->getLatestRelease())) {
            $folder = 'missing_release';
        }

        $image_url = "mod/phloor_plugin/graphics/icons/phloor_plugin/$folder/$size.png";

        return elgg_normalize_url($image_url);
    }
    
    /**
     * making the protected function public
     * (image can be delete so icon falls back to standard)
     * other plugins may dont want this (e.g. force user to use
     * an other image)
     * @see AbstractPhloorElggThumbnails::deleteImage()
     */
    public function deleteImage() {
        return parent::deleteImage();
    }
    /*********************************
     * IMAGE - END
     *********************************/

    /*********************************
     * RELEASES
     *********************************/
    /**
     *
     */
    public function hasRelease() {
        return $this->getLatestRelease() !== false;
    }
    /**
     * get all release entities of a plugin
     *
     * @param unknown_type $params
     */
    public function getReleases($params = array()) {
        return phloor_plugin_get_releases_from_plugin($this, $params);
    }

    /**
     * get the latest release
     */
    public function getLatestRelease() {
        return phloor_plugin_get_latest_release($this);
    }

    /**
     * get the recommended release
     */
    public function getRecommendedRelease() {

        $return = phloor_plugin_get_recommended_release($this);
        if(!phloor_plugin_release_instanceof($return)) {
            $return  = $this->getLatestRelease();
        }
        return $return;
    }

    /**
     * set the recommended release
     */
    public function setRecommendedRelease($release) {
        if(!phloor_plugin_release_instanceof($release)) {
            return false;
        }
        return $this->setMetaData('recommended_release_guid', $release->getGUID());
    }

    /**
     * determine if a release is the recommended one
     */
    public function isRecommendedRelease($release) {
        $recommended_release = $this->getRecommendedRelease();
        if(!phloor_plugin_release_instanceof($release) ||
        !phloor_plugin_release_instanceof($recommended_release)) {
            return false;
        }

        return $recommended_release->guid == $release->guid;
    }

    /**
     * deletes all releases of this plugin
     */
    protected function deleteReleases() {
        $return = true;
        $releases = $this->getReleases(array(
			'limit' => 0,
        ));

        foreach($releases as $release) {
            $return = $release->delete() && $return;
        }

        return $return;
    }
    /*********************************
     * RELEASES - END
     *********************************/

    /*********************************
     * SCREENSHOTS
     *********************************/

    /**
     * get the screenshots
     */
    public function getScreenshots($options = array()) {
        $default = array(
			'limit' => 10,
			'offset' => 0,
			'order' => 'asc',
        );

        $options = array_merge($default, $options);

        return $this->getAnnotations('screenshots', $default['limit'],
        $default['offset'], $default['order']);
    }

    /*********************************
     * SCREENSHOTS - END
     *********************************/

    /*********************************
     * DOWNLOAD COUNTER
     *********************************/    
    public function incrementDownloadCount() {
        create_annotation($this->guid, 'download', 1, 'integer', 0, ACCESS_PUBLIC);
    }
    
    public function getDownloadCount() {
        return $this->countAnnotations('download');
    }

    /**********************************
     * DOWNLOAD COUNTER - END
     *********************************/

    /**********************************
     * LIKES
     *********************************/
    public function getLikes($options = array()) {
        $defaults = array(
			'limit' => 0,
			'offset' => 0,
			'order' => 'time_created DESC',
        );

        $options = array_merge($default, $options);

        return $this->getAnnotations(
			'likes', 
        $options['limit'],
        $options['limit'],
        $options['order']
        );
    }

    /**********************************
     * LIKES - END
     *********************************/

    /*********************************
     * Getter/Setter
     *********************************/
    /**
     * Getter for title
     */
    public function getTitle() {
        return $this->title;
    }

    /**
     * Setter for title
     */
    public function setTitle($title) {
        $this->title = $title;
    }
    /*********************************
     * Getter/Setter - END
     *********************************/
}