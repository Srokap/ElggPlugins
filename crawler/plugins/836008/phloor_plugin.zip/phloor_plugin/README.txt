/**
 * Phloor Plugin Portfolio
 * 
 * @package phloor_plugin
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author void <void@13net.at>
 * @copyright 13net
 * @link http://www.13net.at/
 */
 
Version: 1.8-11.11.30b
Requires: Elgg 1.8 or higher


/**
 * Description
 */
Plugin Portfolio for your Elgg site.
(a clone of the community site plugin section)

  __   __     __          __                  ___            __          
_/  |_|  |__ |__| ______ |__| ______ _____    \_ |__   _____/  |______   
\   __\  |  \|  |/  ___/ |  |/  ___/ \__  \    | __ \_/ __ \   __\__  \  
 |  | |   Y  \  |\___ \  |  |\___ \   / __ \_  | \_\ \  ___/|  |  / __ \_
 |_ | |___|  /__/_____ \ |__/____  \ (____  /  |___  /\___ \|_ | (____  /
   \/      \/         \/          \/      \/       \/     \/  \/      \/ 
                __                               
_______   ____ |  |   ____ _____    ______ ____  
\_  __ \_/ __ \|  | _/ __ \\__  \  /  ___// __ \ 
 |  | \/\  ___/|  |_\  ___/ / __ \_\___ \\  ___/ 
 |__|    \___ \|____/\___ \/____  /____  \\___ \
             \/          \/     \/      \/    \/ 

Supported:
- creating plugin objects
- managing releases

Differences:
- plugin can have a logo
- group can manage plugin entities too
- plugin can exist without releases (-> "comming soon..")
- download button is on top instead of at the bottom
- "likes" instead of recommends
- release has own description and own comments_on and access_id attribute 
  (-> indicates that a release can be set to private, 
  although the plugin in general is public)
- included some Creative Commons licence to pick (excluded others)
- shows md5 hash and filename
- default icon changes with different status (default, private, no_release)
- only plugins for elgg 1.8 and above.. (quit downwards compatibility)

Currently not supported:
- adding screenshots
- most downloaded, most recommended

Todo:
- autodetect stuff from the manifest file (screenshots, elgg_version, etc. ) 
  (thaaaaat'd be naice - and would automate a bunch of stuff)
- functionality to activate plugin objects in admin view (rather low priority)
- plugin settings for access restriction (e.g: only admins can create plugins)
- plugin widget (user / group )
- complete language files


/**
 * Languages
 */
English
German (comming soon!)

/**
 * Icons
 */
This plugin uses icons from the amazing famfamfam silk icon set:
Please visit: http://www.famfamfam.com/lab/icons/silk/
Thank you Mr Mark James for this great work.
