<?php
/**
 * phloor plugin release download
 */
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

// get release guid
$release_guid = get_input("release_guid", 0);

forward("phloor_plugin/release/download/$release_guid");
