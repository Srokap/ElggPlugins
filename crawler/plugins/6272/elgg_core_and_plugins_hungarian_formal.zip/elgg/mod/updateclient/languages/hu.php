<?php

	/**
	 * Update client language pack.
	 * 
	 * @package ElggUpdateClient
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */	

	$hungarian = array(
	
		'updateclient:label:core' => 'Mag',
		'updateclient:label:plugins' => 'Pluginok',
	
		'updateclient:settings:days' => 'Friss verzió ellenőrzése minden',
		'updateclient:days' => 'nap',
	
		'updateclient:settings:server' => 'Szerver frissítése',
	
		'updateclient:message:title' => 'Új Elgg verzió jelent meg!',
		'updateclient:message:body' => 'Egy új Elgg verzió jelent meg (%s %s)  "%s" belső névvel!
		
Kattintson ide a letöltéshez: %s

Vagy olvassa el a kibocsátási jegyzeteket:

%s',
	);
					
	add_translation("hu", $hungarian);
?>