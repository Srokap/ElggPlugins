<?php

	$hungarian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'bookmarks' => "Könyvjelzők",
			'bookmarks:add' => "Könyvjelző hozzáadása/Bookmark something",
			'bookmarks:read' => "Megjegyzett elemek",
			'bookmarks:friends' => "Barárok könyvjelzői",
			'bookmarks:everyone' => "A weboldal könyvjelzői",
			'bookmarks:this' => "Könyvjelzőkhöz hozzáad",
			'bookmarks:bookmarklet' => "Get bookmarklet",
			'bookmarks:inbox' => "Bookmarks inbox",
			'bookmarks:more' => "Még több könyvjelző",
			'bookmarks:shareditem' => "Megjegyzett elemek",
			'bookmarks:with' => "Megosztom",
	
			'bookmarks:address' => "A megjegyzendő forrás címe",
	
			'bookmarks:delete:confirm' => "Biztos, hogy törölni szeretné ezt a könyvjelzőt?",
	
			'bookmarks:shared' => "Megjegyezve",
			'bookmarks:visit' => "Forrás meglátogatása",
			'bookmarks:recent' => "Friss könyvjelzők",
	
			'bookmarks:river:created' => '%s megjegyezve',
			'bookmarks:river:annotate' => '%s kommentálva ',
			'bookmarks:river:item' => 'an item',
	
			'item:object:bookmarks' => 'Megjegyzett elemek',
	
	
		/**
		 * More text
		 */
		    
		    'bookmarks:widget:description' => 
		            "This widget is designed for your dashboard and will show you the latests items in your bookmarks inbox.",
	
			'bookmarks:bookmarklet:description' =>
					"The bookmarks bookmarklet allows you to share any resource you find on the web with your friends, or just bookmark it for yourself. To use it, simply drag the following button to your browser's links bar:",

	        'bookmarks:bookmarklet:descriptionie' =>
					"If you are using Internet Explorer, you will need to right click on the bookmarklet icon, select 'add to favorites', and then the Links bar.",

			'bookmarks:bookmarklet:description:conclusion' =>
					"You can then save any page you visit by clicking it at any time.",
	
		/**
		 * Status messages
		 */
	
			'bookmarks:save:success' => "Az elem sikeresen hozzáadva a könyvjelzőkhöz.",
			'bookmarks:delete:success' => "A könyvjelző sikeresen törölve.",
	
		/**
		 * Error messages
		 */
	
			'bookmarks:save:failed' => "Nem sikerült a könyvjelző mentése. Kérem, próbálja meg még egyszer.",
			'bookmarks:delete:failed' => "Nem sikerült a könyvjelző törlése. Kérem, próbálja meg még egyszer.",
	
	
	);
					
	add_translation("hu",$hungarian);

?>