<?php

	$hungarian = array(
	
		/**
		 * Friends widget
		 */
			'friends' => "Barátok",
			'friends:widget' => "Barátok",
			'friends:widget:title' => "Barátok",
			'friends:widget:description' => "Megjeleníti néhány barátját.",
	        
		
	);
					
	add_translation("hu",$hungarian);

?>