<?php

	$hungarian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'blog' => "Blog",
			'blogs' => "Blogok",
			'blog:user' => "%s blogja",
			'blog:user:friends' => "%s barátjának blogja",
			'blog:your' => "Blogod",
			'blog:posttitle' => "%s blogja: %s",
			'blog:friends' => "Barátok blogjai",
			'blog:yourfriends' => "Barátaid utolsó blogjai",
			'blog:everyone' => "A weboldal blogjai",
	
			'blog:read' => "Read blog",
	
			'blog:addpost' => "Blogbejegyzés írása",
			'blog:editpost' => "Blogbejegyzés módosítása",
	
			'blog:text' => "Blog szövege",
	
			'blog:strapline' => "%s",
			
			'item:object:blog' => 'Blogbejegyzések',
	
			
         /**
	     * Blog river
	     **/
	        
	        //generic terms to use
	        'blog:river:created' => "írta %s",
	        'blog:river:updated' => "frissítette %s",
	        'blog:river:posted' => "közzétette %s",
	        
	        //these get inserted into the river links to take the user to the entity
	        'blog:river:create' => " egy új blogbejegyzés.",
	        'blog:river:update' => "egy blogbejegyzés.",
	        'blog:river:annotate:create' => "egy blogbejegyzés kommentárja.",
			
	
		/**
		 * Status messages
		 */
	
			'blog:posted' => "Sikerült az ön blogjának közzététele.",
			'blog:deleted' => "Sikerült az ön blogjának törlése.",
	
		/**
		 * Error messages
		 */
	
			'blog:save:failure' => "Nem sikerült a blogbejegyzés mentése. Kérem, próbálja meg még egyszer.",
			'blog:blank' => "Ki kell töltenie a cím és tartalom mezőket, mielőtt közzétesz egy bejegyzést.",
			'blog:notfound' => "A kért blogbejegyzés nem található.",
			'blog:notdeleted' => "Nem sikerült a blogbejegyzés törlése.",
	
	);
					
	add_translation("hu",$hungarian);

?>