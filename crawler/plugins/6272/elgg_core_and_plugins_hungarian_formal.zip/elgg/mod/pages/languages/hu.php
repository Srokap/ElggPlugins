<?php
	/**
	 * Elgg pages plugin language pack
	 * 
	 * @package ElggPages
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$hungarian = array(
	
		/**
		 * Menu items and titles
		 */
			
			'pages' => "Oldalak",
			'pages:yours' => "Oldalaim",
			'pages:user' => "Oldalak",
			'pages:group' => "%s oldalai",
			'pages:all' => "A weboldal oldalai",
			'pages:new' => "Új oldal",
			'pages:groupprofile' => "Csoport oldalai",
			'pages:edit' => "Oldal módosítása",
			'pages:delete' => "Oldal törlése",
			'pages:history' => "Oldal archívum",
			'pages:view' => "Oldal megtekintése",
			'pages:welcome' => "Üdvözlő üzenet módosítása",
			'pages:welcomeerror' => "Hiba lépett fel az üdvözlő üzenet mentésekor",
			'pages:welcomeposted' => "Üdvözlő üzenete sikeresen közzétéve",
			'pages:navigation' => "Oldal navigáció",
	
			'item:object:page_top' => 'Felső szintű oldalak',
			'item:object:page' => 'Oldalak',
			'item:object:pages_welcome' => 'Oldalak üdvözlő blokkjai',
	
	
		/**
		 * Form fields
		 */
	
			'pages:title' => 'Oldalak címe',
			'pages:description' => 'Az ön oldalbejegyzése',
			'pages:tags' => 'Címkék',	
			'pages:access_id' => 'Hozzáférési jogok',
			'pages:write_access_id' => 'Írási jog',
		
		/**
		 * Status and error messages
		 */
			'pages:noaccess' => 'Nincs hozzáférés',
			'pages:cantedit' => 'Nem módosíthatja ezt az oldalt',
			'pages:saved' => 'Oldalak elmentve',
			'pages:notsaved' => 'Nem sikerült az oldal mentése',
			'pages:notitle' => 'Kérem, adjon meg az oldal címét.',
			'pages:delete:success' => 'Oldal sikeresen törölve.',
			'pages:delete:failure' => 'Nem sikerült az oldal törlése.',
	
		/**
		 * Page
		 */
			'pages:strapline' => 'Utoljára frissítve %s %s által',
	
		/**
		 * History
		 */
			'pages:revision' => 'Átdolgozva %s %s által',
	
		/**
		 * Submenu items
		 */
			'pages:label:view' => "Oldal megtekintése",
			'pages:label:edit' => "Oldal módosítása",
			'pages:label:history' => "Oldal arhívum",
	
		/**
		 * Sidebar items
		 */
			'pages:sidebar:this' => "Ezen oldal",
			'pages:sidebar:children' => "Aloldalak",
			'pages:sidebar:parent' => "Szülőelem",
	
			'pages:newchild' => "Aloldal létrehozása",
			'pages:backtoparent' => "Vissza '%s'",
	);
					
	add_translation("hu",$hungarian);
?>