<?php
	/**
	 * API Admin language pack.
	 * 
	 * @package ElggAPIAdmin
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */


	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'apiadmin' => 'API Adminisztráció',
	
	
			'apiadmin:keyrevoked' => 'API Kulcs visszavonva',
			'apiadmin:keynotrevoked' => 'Nem sikerült az API Kulcsot visszavonni',
			'apiadmin:generated' => 'Sikeres API Kulcsgenerálás',
	
			'apiadmin:yourref' => 'Az ön hivatkozása',
			'apiadmin:generate' => 'Új kulcspár generálása',
	
			'apiadmin:noreference' => 'Kérem, adjon meg egy hivatkozást az új kulcsához.',
			'apiadmin:generationfail' => 'Hiba az új kulcspár generálásakor',
			'apiadmin:generated' => 'Új API kulcspár sikeresen generálva.',
	
			'apiadmin:revoke' => 'Kulcs visszavonása',
			'apiadmin:public' => 'Nyilvános',
			'apiadmin:private' => 'Privát',

	
			'item:object:api_key' => 'API Kulcsok',
	);
					
	add_translation("hu",$hungarian);
?>