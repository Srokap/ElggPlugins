<?php
	/**
	 * Elgg diagnostics language pack.
	 * 
	 * @package ElggDiagnostics
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$hungarian = array(
	
			'diagnostics' => 'Rendszer diagnózis',
	
			'diagnostics:description' => 'A következő diagnózis jelentés fontos a rendszer hibáinak diagnosztizálásához, és hozzácsatolandó minden hibajelentéshez.',
	
			'diagnostics:download' => 'Letolt .txt',
	
	
			'diagnostics:header' => '========================================================================
Elgg Diagnózis jelentés
Generálva %s dátumon %s által
========================================================================
			
',
			'diagnostics:report:basic' => '
Elgg %s kiadás, %s verzió

------------------------------------------------------------------------',
			'diagnostics:report:php' => '
PHP info:
%s
------------------------------------------------------------------------',
			'diagnostics:report:plugins' => '
Telepített plugin-ok és részletinformációik:

%s
------------------------------------------------------------------------',
			'diagnostics:report:md5' => '
Telepített file-ok és ellenőrző összegeik:

%s
------------------------------------------------------------------------',
			'diagnostics:report:globals' => '
Globális változók:

%s
------------------------------------------------------------------------',
	
	);
					
	add_translation("hu",$hungarian);
?>