<?php
	/**
	 * Elgg reported content plugin language pack
	 * 
	 * @package ElggReportedContent
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$hungarian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'item:object:reported_content' => 'Jelentett elemek',
			'reportedcontent' => 'Jelentett tartalom',
			'reportedcontent:this' => 'Jelentem',
			'reportedcontent:none' => 'Nincs jelentett tartalom',
			'reportedcontent:report' => 'Jelentem az adminisztrátornak',
			'reportedcontent:title' => 'Oldal cím',
			'reportedcontent:deleted' => 'A jelentett tartalom törlésre került',
			'reportedcontent:notdeleted' => 'Nem sikerült a jelentés törlése',
			'reportedcontent:delete' => 'Törlés',
			'reportedcontent:areyousure' => 'Biztosan törölni akarja?',
			'reportedcontent:archive' => 'Arhiválás',
			'reportedcontent:archived' => 'A jelentés arhiválásra került',
			'reportedcontent:visit' => 'Jelentett elem megtekintése',
			'reportedcontent:by' => 'Jelentette',
			'reportedcontent:objecttitle' => 'Objektum címe',
			'reportedcontent:objecturl' => 'Objektum url',
			'reportedcontent:reason' => 'Jelentés oka',
			'reportedcontent:description' => 'Miért jelenti ön ezt?',
			'reportedcontent:address' => 'Elem elhelyezése',
			'reportedcontent:success' => 'A jelentése elküldetett az oldal adminisztrátorának',
			'reportedcontent:failing' => 'Nem sikerült a jelentés elküldése',
	
	);
					
	add_translation("hu",$hungarian);
?>