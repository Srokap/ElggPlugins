<?php
	/**
	 * Elgg log rotator language pack.
	 * 
	 * @package ElggLogRotate
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$hungarian = array(
		'logrotate:period' => 'Milyen gyakran aktiváljam a rendszer naplóforgatását?',
	
		'logrotate:weekly' => 'Hetente',
		'logrotate:monthly' => 'Havonta',
		'logrotate:yearly' => 'Évente',
	
		'logrotate:logrotated' => "Napló forgatva\n",
		'logrotate:lognotrotated' => "Naplóforgatási hiba\n",
	);
					
	add_translation("hu",$hungarian);
?>