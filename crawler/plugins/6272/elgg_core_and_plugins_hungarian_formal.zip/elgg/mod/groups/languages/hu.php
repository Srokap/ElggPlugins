<?php
	/**
	 * Elgg groups plugin language pack
	 * 
	 * @package ElggGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$hungarian = array(
	
		/**
		 * Menu items and titles
		 */
			
			'groups' => "Csoportok",
			'groups:owned' => "Általalm létrehozott csoportok",
			'groups:yours' => "Csoportjaim",
			'groups:user' => "%s csoportjai",
			'groups:all' => "A weboldal csoportjai",
			'groups:new' => "Új csoport létrehozása",
			'groups:edit' => "Csoport módosítása",
	
			'groups:icon' => 'Csoport ikonja (hagyja üresen, ha nem kívánja változtatni)',
			'groups:name' => 'Csoport neve',
			'groups:username' => 'Csoport rövid neve (az URL-kben szerepel, alfanumerikus karakterek lehetnek csak benne)',
			'groups:description' => 'Leírás',
			'groups:briefdescription' => 'Rövid leírás',
			'groups:interests' => 'Érdeklődési kör',
			'groups:website' => 'Weboldal',
			'groups:members' => 'Csoport tagjai',
			'groups:membership' => "Tagság",
			'groups:access' => "Hozzáférési jogok",
			'groups:owner' => "Tulajdonos",
	        'groups:widget:num_display' => 'Megjelenítendő csoportok száma',
	        'groups:widget:membership' => 'Csoport tagság',
	        'groups:widgets:description' => 'Jelenítse meg az adatlapon azon csoportokat, melyeknek tagja vagyok',
			'groups:noaccess' => 'Nincs a csoporthoz hozzáférés',
			'groups:cantedit' => 'Nem módosíthatja a csoport beállításait',
			'groups:saved' => 'Csoport elmentve',
	
			'groups:joinrequest' => 'Tagság kérvényezése',
			'groups:join' => 'Csatlakozás a csoporthoz',
			'groups:leave' => 'Csoport elhagyása',
			'groups:invite' => 'Barátok meghívása',
			'groups:inviteto' => "Barátok meghívása a következő csoportba: '%s'",
			'groups:nofriends' => "Nincs olyan barátja, aki nem volt meghívva ebbe a csoportba.",
	
			'groups:group' => "Csoport",
			
			'item:object:groupforumtopic' => "Fórum tárgyak",
	
			/*
			  Group forum strings
			*/
			
			'groups:forum' => 'Csoport fóruma',
			'groups:addtopic' => 'Tárgy hozzáadása',
			'groups:forumlatest' => 'Utolsó fórum',
			'groups:latestdiscussion' => 'Utolsó fórumbejegyzések',
			'groupspost:success' => 'Hozzászólás sikeresen hozzáadva',
			'groups:alldiscussion' => 'Utolsó tárgyalások',
			'groups:edittopic' => 'Tárgy módosítása',
			'groups:topicmessage' => 'Tárgy üzenet',
			'groups:topicstatus' => 'Tárgy állapota',
			'groups:reply' => 'Hozzászólás',
			'groups:topic' => 'Tárgy',
			'groups:posts' => 'Hozzászólások',
			'groups:lastperson' => 'Utolsó hozzászóló',
			'groups:when' => 'Amikor',
			'grouptopic:notcreated' => 'Nincs létrehozott tárgy.',
			'groups:topicopen' => 'Nyitott',
			'groups:topicclosed' => 'Zárt',
			'groups:topicresolved' => 'Eldöntött',
			'grouptopic:created' => 'Tárgy létrehozva.',
			'groupstopic:deleted' => 'Tárgy törölve.',
			'groups:topicsticky' => 'Sticky',
			'groups:topicisclosed' => 'Ez a tárgy le van zárva.',
			'groups:topiccloseddesc' => 'Ez a tárgy most le van zárva, és nem fogad el új hozzászólásokat.',
			
	
			'groups:privategroup' => 'Ez a csoport privát, szükségeltetik a tagság.',
			'groups:notitle' => 'Csoportoknak kell legyen neve',
			'groups:cantjoin' => 'Nem sikerült a csatlakozás a csoporthoz',
			'groups:cantleave' => 'Nem sikerült a kilépés a csoportból',
			'groups:addedtogroup' => 'Felhasználó sikeresen hozzáadva a csoporthoz',
			'groups:joinrequestnotmade' => 'Nem sikerült a csatlakozási kérés létrehozása',
			'groups:joinrequestmade' => 'Csatlakozási kérés sikeresen létrehozva',
			'groups:joined' => 'Sikeres csatlakozás!',
			'groups:left' => 'Sikeres kilépés a csoportból',
			'groups:notowner' => 'Ön nem a csoport tulajdonosa.',
			'groups:alreadymember' => 'Ön már tagja a csoportnak!',
			'groups:userinvited' => 'Felhasználó meghívva.',
			'groups:usernotinvited' => 'Nem sikerült a felhasználót meghívni.',
	
			'groups:invite:subject' => "%s, önt meghívták, hogy csatlakozzon a(z) %s csoporthoz!",
			'groups:invite:body' => "Üdvözöljük, %s,

Meghívást kapott, hogy csatlakozzon a '%s' csoporthoz. A csatlakozáshoz kattintson az alábbi linkre:

%s",

			'groups:welcome:subject' => "Üdvözöljük a(z) %s csoportban!",
			'groups:welcome:body' => "Üdvözöljük, %s!
		
Sikeresen csatlakozott a '%s' csoporthoz. Kattintson az alábbi linkre a hozzászólás elkezdéséhez!

%s",
	
			'groups:request:subject' => "%s kérte a csatlakozást a(z) %s csoporthoz",
			'groups:request:body' => "Üdvözöljük, %s,

%s kérte a csatlakozást a '%s' csoporthoz, kattintson az alábbi linkre az adatlapja megtekintéséhez:

%s

vagy kattintson az alábbi linkre a kérés megerősítéséért:

%s",
	
			'groups:river:member' => 'tagja a következő csoportnak:',
	
			'groups:nowidgets' => 'Nincs e csoport számára értelmezett eszköztár.',
	
	
			'groups:widgets:members:title' => 'Csoporttagok',
			'groups:widgets:members:description' => 'Csoporttagok listázása.',
			'groups:widgets:members:label:displaynum' => 'Csoporttagok listázása.',
			'groups:widgets:members:label:pleaseedit' => 'Kérem, állítsa be ezt az eszközt.',
	
			'groups:widgets:entities:title' => "Objektumok a csoportban",
			'groups:widgets:entities:description' => "E csoportban elmentett objektumok listája",
			'groups:widgets:entities:label:displaynum' => 'Csoport objektumainak listázása.',
			'groups:widgets:entities:label:pleaseedit' => 'Kérem, állítsa be ezt az eszközt.',
		
	);
					
	add_translation("hu",$hungarian);
?>