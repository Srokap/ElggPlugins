<?php

	$hungarian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'status' => "Státus",
			'status:user' => "%s státusa",
			'status:posttitle' => "%s státusa: %s",
			'status:everyone' => "A weboldal felhasználóinak státusa",
			'status:strapline' => "%s",
			'status:addstatus' => "Státus beállítása",
		    'status:messages' => "Státusüzenetek",
			'status:text' => "Státus:",
			'status:set' => "beállít ",
			'status:clear' => "státus kiürítése",
			'status:delete' => "státus törlése",
			'status:nostatus' => "Nincs beállított státus.",
			'status:viewhistory' => "arhívum megtekintése",
	
			'item:object:status' => 'Státusüzenetek',
	
	
        /**
	     * Status river
	     **/
	        
	        //generic terms to use
	        'status:river:created' => "%s frissítette",
	        
	        //these get inserted into the river links to take the user to the entity
	        'status:river:create' => "státusát.",
	        
	        'status:widget:title' => "Státusüzenetek",
	        'status:widget:description' => "",
	        
	        
	
		/**
		 * Status messages
		 */
	
			'status:posted' => "Sikerült közzétenni a státusüzenetét.",
			'status:deleted' => "Sikerült törölni a státusüzenetét.",
	
		/**
		 * Error messages
		 */
	
			'status:blank' => "Kérem, adja meg az üzenet szövegét, mielőtt lementené az üzenetet.",
			'status:notfound' => "A kért státusüzenet nem található.",
			'status:notdeleted' => "Nem sikerült a státusüzenet törlése.",
			'status:notsaved' => "Hiba lépett fel a mentéskor. Kérem, próbálja meg újból, vagy keresse meg az adminisztrátort.",
			'status:problem' => "Hiba lépett fel. Nem módosíthatja ezt a státusüzenetet.",
	
	);
					
	add_translation("hu",$hungarian);

?>