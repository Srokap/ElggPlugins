<?php
	echo $vars['url'] . "mod/socializeme/graphics/group_icons/defaultmedium.gif";
?>