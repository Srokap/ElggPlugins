AU-Bookmarks-Widget-1.8.x
=========================

Allows additional configuration for the bookmarks widget in Elgg 1.8

Plugin should reside in mod/au_bookmarks_wigdet