<?php

elgg_register_event_handler('init', 'system', 'phloor_news_init');

/**
 * Init phloor_news
 */
function phloor_news_init() {
    /**
     * Library
     */
    elgg_register_library('phloor-news', elgg_get_plugins_path() . 'phloor_news/lib/phloor_news.lib.php');
    elgg_load_library('phloor-news');

    /**
     * Site Menu
     */
    $item = new ElggMenuItem('phloor_news', elgg_echo('phloor_news:phloor_news'), 'phloor/object/phloor_news/all');
    elgg_register_menu_item('site', $item);
    /**
     * Entity Menu
     */
    elgg_register_plugin_hook_handler('register', 'menu:entity', 'phloor_news_entity_menu_setup');
    /**
     * Owner Block Menu
     */
    elgg_register_plugin_hook_handler('register', 'menu:owner_block', 'phloor_news_owner_block_menu');


    /**
     * CSS
     */
    elgg_extend_view('css/elgg', 'css/phloor_news/elgg');

    /**
     * JS
     */
    $phloor_news_js = elgg_get_simplecache_url('js', 'phloor_news/save_draft');
    elgg_register_simplecache_view('js/phloor_news/save_draft');
    elgg_register_js('elgg.phloor_news', $phloor_news_js);

    $masonry_js = elgg_get_simplecache_url('js', 'phloor_news/masonry');
    elgg_register_simplecache_view('js/phloor_news/masonry');
    elgg_register_js('elgg.phloor_news.masonry', $masonry_js);

    // notifications
    //register_notification_object('object', 'phloor_news', elgg_echo('phloor_news:newpost'));
    //elgg_register_plugin_hook_handler('notify:entity:message', 'object', 'phloor_news_notify_message');
    // pingbacks
    //elgg_register_event_handler('create', 'object', 'phloor_news_incoming_ping');
    //elgg_register_plugin_hook_handler('pingback:object:subtypes', 'object', 'phloor_news_pingback_subtypes');

    /**
     * Search.
     */
    elgg_register_entity_type('object', 'phloor_news');

    /**
     * Add group option
     */
    add_group_tool_option('phloor_news', elgg_echo('phloor_news:enablephloor_news'), true);
    elgg_extend_view('groups/tool_latest', 'phloor_news/group_module');

    /**
     * Widget
     */
    elgg_register_widget_type('phloor_news', elgg_echo('phloor_news'), elgg_echo('phloor_news:widget:description'), 'profile');

    /**
     * Actions
     */
    $action_path = elgg_get_plugins_path() . 'phloor_news/actions/phloor_news';
    elgg_register_action('phloor_news/ajax/auto_save_revision', "$action_path/ajax/auto_save_revision.php");

    /**
     * GC
     */
    //elgg_register_plugin_hook_handler('gc', "system", 'phloor_news_gc');
    
    /**
     * PHLOOR entity handler functions
     */
    // let phloor know about your entity subtype
    if (\phloor\entity\object\phloor_my_subtype('phloor_news')) {

        // populate your function for the DEFAULT VALUES of your entity
        elgg_register_plugin_hook_handler('phloor_object:default_vars', 'phloor_news', '\phloor_news\default_vars');

        // populate your function for the FROM ATTRIBUTES of your entity
        elgg_register_plugin_hook_handler('phloor_object:form_vars', 'phloor_news', '\phloor_news\form_vars');
         
        // prepare the FROM ATTRIBUTES and add/change/delete stuff
        elgg_register_plugin_hook_handler('phloor_object:prepare_form_vars', 'phloor_news', '\phloor_news\prepare_form_vars');

        // populate your function for VALIDATING the attributes of your entity
        elgg_register_plugin_hook_handler('phloor_object:check_vars',   'phloor_news', '\phloor_news\check_vars');
        
        elgg_register_plugin_hook_handler('phloor_object:page_handler', "phloor_news:all",     "\phloor_news\page_handler_prepare_all",     1);
        elgg_register_plugin_hook_handler('phloor_object:page_handler', "phloor_news:all",     "\phloor_news\page_handler_postprocess_all", 900);
        
        elgg_register_plugin_hook_handler('phloor_object:page_handler', "phloor_news:view",    "\phloor_news\page_handler_prepare_view",    1);
        elgg_register_plugin_hook_handler('phloor_object:page_handler', "phloor_news:owner",   "\phloor_news\page_handler_prepare_owner",   1);
        elgg_register_plugin_hook_handler('phloor_object:page_handler', "phloor_news:friends", "\phloor_news\page_handler_prepare_friends", 1);
        elgg_register_plugin_hook_handler('phloor_object:page_handler', "phloor_news:edit",    "\phloor_news\page_handler_prepare_edit",    1);
        elgg_register_plugin_hook_handler('phloor_object:page_handler', "phloor_news:edit",    "\phloor_news\page_handler_postprocess_edit", 900);
        
        elgg_register_plugin_hook_handler('phloor_object:page_handler', "phloor_news:add",     "\phloor_news\page_handler_prepare_add",     1);
        elgg_register_plugin_hook_handler('phloor_object:page_handler', "phloor_news:add",     "\phloor_news\page_handler_postprocess_add",  900);
        elgg_register_plugin_hook_handler('phloor_object:page_handler', "phloor_news:archive", "\phloor_news\page_handler_archive",          400);
         
        elgg_register_plugin_hook_handler('phloor_object:page_handler', "all", "\phloor_news\page_handler_add_sidebar_content", 999);
         
        elgg_register_event_handler('phloor_object:save:after', "phloor_news",     "\phloor_news\save_after",     550);
    }
    /*
     * PHLOOR entity handler functions - END
    **/
}


/**
 * Add 'news' to ownerblock
 */
function phloor_news_owner_block_menu($hook, $type, $return, $params) {
    $entity = elgg_extract('entity', $params, NULL);

    if (elgg_instanceof($entity, 'user')) {
        $url = "phloor/object/phloor_news/owner/{$entity->username}";
        $item = new ElggMenuItem('phloor_news', elgg_echo('phloor_news'), $url);
        $return[] = $item;
    } else {
        if ($entity->phloor_news_enable != "no") {
            $url = "phloor/object/phloor_news/group/{$entity->guid}/all";
            $item = new ElggMenuItem('phloor_news', elgg_echo('phloor_news:group'), $url);
            $return[] = $item;
        }
    }

    return $return;
}

/**
 * Add particular news links/info to entity menu
 */
function phloor_news_entity_menu_setup($hook, $type, $return, $params) {
    if (elgg_in_context('widgets')) {
        return $return;
    }

    $entity  = elgg_extract('entity',  $params, NULL);
    $handler = elgg_extract('handler', $params, false);

    if ($handler != 'phloor_news') {
        return $return;
    }

    if ($entity->canEdit() && $entity->status != 'published') {
        $status_text = elgg_echo("phloor_news:status:{$entity->status}");
        $options = array(
			'name' => 'published_status',
			'text' => "<span>$status_text</span>",
			'href' => false,
			'priority' => 150,
        );
        $return[] = ElggMenuItem::factory($options);
    }

    return $return;
}

/**
 * Garbage Collection
 * 
 * @todo: delete unecesarry amounts of
 * revisions for a news entity 
 * 
 * @param string $hook
 * @param string $type
 * @param unknown_type $return
 * @param array $params
 * @return unknown
 */
function phloor_news_gc($hook, $type, $return, $params) {

}

