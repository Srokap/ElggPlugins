<?php 
?>

.phloor-news-image {
	text-align: center;
	
	display: block;
}

.phloor-news-image > a > img {
    display: inline-block;    
    border-radius: 5px;
    box-shadow: 2px 2px 5px #666;
}

<?php 