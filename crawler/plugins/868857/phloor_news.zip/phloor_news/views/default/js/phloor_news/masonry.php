<?php
/**
 * load masonry
 *
 * @package phloor_news
 */
?>
elgg.provide('elgg.phloor_news.masonry');

/*
 * Attempt to save and update the input with the guid.
 */
elgg.phloor_news.masonry.init = function(data, textStatus, XHR) {
	if ($('.phloor-list-phloor_news .elgg-item').length > 2) {
		$('.phloor-list-phloor_news .elgg-item').css('width', '345px');
		$('.phloor-list-phloor_news .elgg-item').css('margin', '5px');
		$('.phloor-list-phloor_news .elgg-item').css('float', 'left');
		$(".phloor-list-phloor_news").masonry({
		    // options
		    itemSelector : '.elgg-item',
		    columnWidth : 360
		});
	}
};


elgg.register_hook_handler('init', 'system', elgg.phloor_news.masonry.init);

