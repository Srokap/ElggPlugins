<?php
/**
 * phloor_news tagcloud
 */

echo elgg_view('page/elements/tagcloud_block', array(
    'subtypes' => 'phloor_news',
    'owner_guid' => elgg_get_page_owner_guid(),
));