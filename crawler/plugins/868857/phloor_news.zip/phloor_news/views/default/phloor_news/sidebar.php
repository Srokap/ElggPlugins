<?php
/**
 * phloor_news sidebar
 *
 * @package phloor_news
 */

$page_type = elgg_extract('page_type', $vars, '');

// display latest comments
echo elgg_view('phloor_news/sidebar/comments', $vars);

// only users can have archives at present
if (elgg_instanceof(elgg_get_page_owner_entity(), 'user')) {
	echo elgg_view('phloor_news/sidebar/archives', $vars);
}

if ($page_type == 'edit') {
    echo elgg_view('phloor_news/sidebar/revisions', $vars);
}

if ($page_type != 'friends') {
    echo elgg_view('phloor_news/sidebar/tagcloud', $vars);
}

