<?php
/**
 * Group phloor_news module
 */

$group = elgg_get_page_owner_entity();

if ($group->phloor_news_enable == "no") {
	return true;
}

$all_link = elgg_view('output/url', array(
	'href' => "phloor/object/phloor_news/group/$group->guid/all",
	'text' => elgg_echo('link:view:all'),
	'is_trusted' => true,
));

elgg_push_context('widgets');
$options = array(
	'type' => 'object',
	'subtype' => 'phloor_news',
	'container_guid' => elgg_get_page_owner_guid(),
	'limit' => 6,
	'full_view' => false,
	'pagination' => false,
);
$content = elgg_list_entities($options);
elgg_pop_context();

if (!$content) {
	$content = '<p>' . elgg_echo('phloor_news:none') . '</p>';
}

$new_link = elgg_view('output/url', array(
	'href' => "phloor/object/phloor_news/add/$group->guid",
	'text' => elgg_echo('phloor_news:write'),
	'is_trusted' => true,
));

echo elgg_view('groups/profile/module', array(
	'title' => elgg_echo('phloor_news:group'),
	'content' => $content,
	'all_link' => $all_link,
	'add_link' => $new_link,
));
