<?php
/**
 * phloor_news tagcloud
 */

$page_type = elgg_extract('page_type', $vars, '');

// fetch & display latest comments
if ($page_type == 'all') {
	echo elgg_view('page/elements/comments_block', array(
		'subtypes' => 'phloor_news',
		'limit' => elgg_extract('limit', $vars, 4),
	));
} elseif ($page_type == 'owner') {
	echo elgg_view('page/elements/comments_block', array(
		'subtypes' => 'phloor_news',
		'owner_guid' => elgg_get_page_owner_guid(),
		'limit' => elgg_extract('limit', $vars, 4),
	));
}