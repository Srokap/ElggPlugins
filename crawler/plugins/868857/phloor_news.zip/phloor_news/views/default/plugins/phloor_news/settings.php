<?php
/*****************************************************************************
 * Phloor News                                                               *
 *                                                                           *
 * Copyright (C) 2011, 2012 Alois Leitner                                    *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php

$entity = elgg_extract('entity', $vars, NULL);

$restrict_to_admins  = $entity->restrict_to_admins;

$enable_masonry = $entity->enable_masonry;
$element_limit  = $entity->element_limit;

if (strcmp('true', $restrict_to_admins) != 0) {
    $restrict_to_admins = 'false';
}

if (strcmp('true', $enable_masonry) != 0) {
    $enable_masonry = 'false';
}

if (!is_numeric($element_limit) || $element_limit < 3) {
    $element_limit = 15;
}
?>

<?php

echo elgg_view('phloor/input/vendors/prettycheckboxes/checklist', array(
	'options' => array(
    	'enable_masonry'  => array(
        	'name'  => 'params[restrict_to_admins]',
        	'value' => $restrict_to_admins,
            'label' => elgg_echo('phloor_news:settings:restrict_to_admins:label'),
        ),
    ),
));

?>


<?php
echo elgg_view_title(elgg_echo('phloor_news:settings:layout:title'));

echo elgg_view('phloor/input/vendors/prettycheckboxes/checklist', array(
	'options' => array(
    	'enable_masonry'  => array(
        	'name'  => 'params[enable_masonry]',
        	'value' => $enable_masonry,
            'label' => elgg_echo('phloor_news:settings:layout:enable_masonry:label'),
        ),
    ),
));


?>

<div style="clear: both;"></div>


<div>
<?php echo elgg_echo('phloor_news:settings:layout:element_limit:label'); ?>

<?php
echo elgg_view('input/dropdown', array(
	'name' => 'params[element_limit]',
	'value' => $element_limit,
	'options_values' => array(
		 4 => 4,
	 	 6 => 6,
		 8 => 8,
		10 => 10,
		12 => 12,
		14 => 14,
		20 => 20,
		25 => 25,
		30 => 30,
	),
));
?>
<?php echo elgg_echo('phloor_news:settings:layout:element_limit:description'); ?>
</div>

<?php
