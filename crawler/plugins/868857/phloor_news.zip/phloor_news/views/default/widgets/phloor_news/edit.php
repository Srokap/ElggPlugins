<?php
/**
 * User phloor_news widget edit view
 */

$entity = elgg_extract('entity', $vars, NULL);

// set default value
if (!isset($entity->num_display)) {
	$entity->num_display = 4;
}

$params = array(
	'name' => 'params[num_display]',
	'value' => $entity->num_display,
	'options' => array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10),
);
$dropdown = elgg_view('input/dropdown', $params);

// display "title" + "dropdown" as settings and add to $output
$num_display_input  = elgg_echo('phloor_news:numbertodisplay');
$num_display_input .= $dropdown;

$output = elgg_view('phloor/output/div', array(
    'content' => $num_display_input,
));

echo $output;


