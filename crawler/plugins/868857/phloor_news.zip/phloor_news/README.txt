/**
 * Phloor News
 * 
 * @package phloor_news
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author void <void@13net.at>
 * @copyright 13net
 * @link http://www.13net.at/
 */

/**
 * Description
 */
Adds news posting capabilities to your Elgg installation. 

This plugin requires the phloorFramework!

/**
 * Languages
 */
English
German
