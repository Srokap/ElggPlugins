<?php
/**
 * Phloor News Language File
 * German
 */

$german = array(	
    'phloor_news' => 'News',
	'phloor_news:phloor_news' => 'News',
	'phloor_news:revisions' => 'Revisionen',
	'phloor_news:archives' => 'Archive',
	'item:object:phloor_news' => 'News',
	
/**
* PHLOOR specific language strings
*/
	'phloor/object/phloor_news:breadcrumb:all'                    => 'Alle News',
	'phloor/object/phloor_news:page:content:list:all:title'       => 'Alle News',
	'phloor/object/phloor_news:page:content:list:none'            => 'Keine News gefunden.',
	'phloor/object/phloor_news:page:content:list:container:title' => '%s\'s News',
	'phloor/object/phloor_news:page:content:friends:title'        => 'Friends\' News',
	'phloor/object/phloor_news:page:content:add:title'            => 'News hinzufügen',
	'phloor/object/phloor_news:page:content:edit:title'           => 'News-Beitrag %s editieren',

	'phloor/object/phloor_news:add' => 'News hinzufügen',

/** ATTRIBUTES */

	'phloor/object/phloor_news:form:title'        => 'Titel*: ',
	'phloor/object/phloor_news:form:excerpt'      => 'Auszug: ',
	'phloor/object/phloor_news:form:description'  => 'Text*: ',
	'phloor/object/phloor_news:form:tags'         => 'Tags: ',
	'phloor/object/phloor_news:form:image'        => 'Bild: ',
	'phloor/object/phloor_news:form:comments_on'  => 'Kommentare erlauben? ',
	'phloor/object/phloor_news:form:access_id'    => 'Lesezugriff: ',
	'phloor/object/phloor_news:form:status'       => 'Status: ',
	'phloor/object/phloor_news:form:delete_image' => 'Aktuelles Bild löschen? ',
	
	'phloor/object/phloor_news:form:title:description'        => ' ',
	'phloor/object/phloor_news:form:excerpt:description'      => ' ',
	'phloor/object/phloor_news:form:description:description'  => ' ',
	'phloor/object/phloor_news:form:tags:description'         => ' ',
	'phloor/object/phloor_news:form:image:description'        => ' ',
	'phloor/object/phloor_news:form:access_id:description'    => ' ',
	'phloor/object/phloor_news:form:status::description  '    => ' ',
	'phloor/object/phloor_news:form:delete_image:description' => ' ',
	'phloor/object/phloor_news:form:comments_on:description'  => ' ',
	
	'phloor/object/phloor_news:title'        => 'Titel',
	'phloor/object/phloor_news:excerpt'      => 'Auszug',
	'phloor/object/phloor_news:description'  => 'Text',
	'phloor/object/phloor_news:tags'         => 'Tags',
	'phloor/object/phloor_news:image'        => 'Bild',
	'phloor/object/phloor_news:access_id'    => 'Lesezugriff',
	'phloor/object/phloor_news:status'       => 'Status',
	'phloor/object/phloor_news:comments_on'  => 'Kommentare erlauben? ',
	'phloor/object/phloor_news:delete_image' => 'Aktuelles Bild löschen? ',
/* ATTRIBUTES - END **/

	'phloor_news:error:check_vars:title:missing'       => 'Der News-Eintrag braucht einen Titel. ',
	'phloor_news:error:check_vars:description:missing' => 'Der News-Eintrag braucht einen Text. ',


/*
 * PHLOOR specific language strings - END
 **/

// volatile metadata
	'phloor_news:form:save_status' => 'Zuletzt gespeichert: ',
	'phloor_news:form:save_status:description'  => ' Der Beitrag wird alle 60 Sekunden zwischengespeichert um Datenverlust zu verhindern.  ',
	'phloor_news:save_status:never' => 'Noch nie ',

	'phloor_news:message:access_id:set_to_private' => 'Der Lesezugriff des Entwurfs wurde auf PRIVATE gestellt. ',
/*
* NEW - NED
**/

    // settings
	"phloor_news:settings:layout:title" => "Layout",

	"phloor_news:settings:layout:enable_masonry:label" => "Masonry für News aktivieren? ",
	"phloor_news:settings:layout:enable_masonry:description" => "Aktiviert das Mansonry jQuery Plugin für der News Übersichtseite (deaktiviert Elggs Standardlayout für Listen auf der Übersichtsseite). Mehr Informationen unter http://masonry.desandro.com/ ",

	"phloor_news:settings:layout:element_limit:label" => "Maximale Anzahl an News-Einträgen pro Seite",
	"phloor_news:settings:layout:element_limit:description" => "",

	"phloor_news:settings:restrict_to_admins:label" => "Die Erstellung von Newsbeiträgen auf Administratoren beschränken.",
	
    // Group
	'phloor_news:group' => 'News',
	'phloor_news:enablephloor_news' => 'News aktivieren',
	'phloor_news:write' => 'Neuen News-Beitrag verfassen',

	// Editing
	'phloor_news:add' => 'News hinzufügen',
	'phloor_news:edit' => 'News editieren',
	
	'phloor_news:save_status' => 'Zuletzt gespeichert: ',
	'phloor_news:never' => 'Noch nie',

	// Statuses
	'phloor_news:status' => 'Status',
	'phloor_news:status:draft' => 'Entwurf',
	'phloor_news:status:published' => 'Veröffentlicht',
	'phloor_news:status:unsaved_draft' => 'Ungespeicherter Entwurf',

	'phloor_news:revision' => 'Überarbeitung',
	'phloor_news:auto_saved_revision' => 'Automatisches Speichern der Überarbeitung',
	

	// messages
	'phloor_news:messages:warning:draft' => 'Es exisitert eine ungespeicherte Überarbeitung des Eintrags.',
	'phloor_news:edit_revision_notice' => '(Alte Version)',
	'phloor_news:none' => 'Keine neuen News',
	'phloor_news:error:revision_not_found' => 'Konnte die Überabeitung nicht finden.',
	
	// river
	'river:create:object:phloor_news' => '%s veröffentlichte den News-Eintrag %s',
	'river:comment:object:phloor_news' => '%s kommentierte den News-Eintrag %s',

	// notifications
	'phloor_news:newpost' => 'Ein neuer News-Eintrag',

	// widget
	'phloor_news:widget:description' => 'Zeigt die letzten News-Einträge an',
	'phloor_news:more_news' => 'Mehr News-Einträge',
	'phloor_news:numbertodisplay' => 'Anzahl der anzuzeigenden News-Einträge',
);

add_translation('de', $german);
