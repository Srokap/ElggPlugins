<?php
/**
 * Phloor News Language File
 * English
 */

$english = array(
	'phloor_news' => 'News',
	'phloor_news:phloor_news' => 'News',
	'phloor_news:revisions' => 'Revisions',
	'phloor_news:archives' => 'Archives',
	'item:object:phloor_news' => 'News',
	
/**
* PHLOOR specific language strings
*/
	'phloor/object/phloor_news:breadcrumb:all'                    => 'All news',
	'phloor/object/phloor_news:page:content:list:all:title'       => 'All news',
	'phloor/object/phloor_news:page:content:list:none'            => 'No news found.',
	'phloor/object/phloor_news:page:content:list:container:title' => '%s\'s news',
	'phloor/object/phloor_news:page:content:friends:title'        => 'Friends\' news',
	'phloor/object/phloor_news:page:content:add:title'            => 'Add a news post',
	'phloor/object/phloor_news:page:content:edit:title'           => 'Edit news post %s',

	'phloor/object/phloor_news:add' => 'Add news post',

/** ATTRIBUTES */

	'phloor/object/phloor_news:form:title'        => 'Title*: ',
	'phloor/object/phloor_news:form:excerpt'      => 'Excerpt: ',
	'phloor/object/phloor_news:form:description'  => 'Body*: ',
	'phloor/object/phloor_news:form:tags'         => 'Tags: ',
	'phloor/object/phloor_news:form:image'        => 'Image: ',
	'phloor/object/phloor_news:form:comments_on'  => 'Comments on? ',
	'phloor/object/phloor_news:form:access_id'    => 'Read access: ',
	'phloor/object/phloor_news:form:status'       => 'Status: ',
	'phloor/object/phloor_news:form:delete_image' => 'Delete current icon? ',
	
	'phloor/object/phloor_news:form:title:description'        => ' ',
	'phloor/object/phloor_news:form:excerpt:description'      => ' ',
	'phloor/object/phloor_news:form:description:description'  => ' ',
	'phloor/object/phloor_news:form:tags:description'         => ' ',
	'phloor/object/phloor_news:form:image:description'        => ' ',
	'phloor/object/phloor_news:form:access_id:description'    => ' ',
	'phloor/object/phloor_news:form:status::description  '    => ' ',
	'phloor/object/phloor_news:form:delete_image:description' => ' ',
	'phloor/object/phloor_news:form:comments_on:description'  => ' ',
	
	'phloor/object/phloor_news:title'        => 'Title',
	'phloor/object/phloor_news:excerpt'      => 'Excerpt',
	'phloor/object/phloor_news:description'  => 'Body',
	'phloor/object/phloor_news:tags'         => 'Tags',
	'phloor/object/phloor_news:image'        => 'Image',
	'phloor/object/phloor_news:access_id'    => 'Read access',
	'phloor/object/phloor_news:status'       => 'Status',
	'phloor/object/phloor_news:comments_on'  => 'Comments on? ',
	'phloor/object/phloor_news:delete_image' => 'Delete current icon? ',
/* ATTRIBUTES - END **/

	'phloor_news:error:check_vars:title:missing'       => 'Please insert a title. ',
	'phloor_news:error:check_vars:description:missing' => 'Please insert a text. ',


/*
 * PHLOOR specific language strings - END
 **/

// volatile metadata
	'phloor_news:form:save_status' => 'Last saved: ',
	'phloor_news:form:save_status:description'  => ' News will be saved every 60 seconds to prevent data loss. ',
	'phloor_news:save_status:never' => 'Never ',

	'phloor_news:message:access_id:set_to_private' => 'Read access was set to PRIVATE for the draft. ',
/*
* NEW - NED
**/

    // settings
	"phloor_news:settings:layout:title" => "Layout",

	"phloor_news:settings:layout:enable_masonry:label" => "Enable Masonry for viewing collections of news?",
	"phloor_news:settings:layout:enable_masonry:description" => "Enables the Masonry jQuery Plugin on the News overview page (disables the default list behaviour for news objects). More information can be found on http://masonry.desandro.com/ ",

	"phloor_news:settings:layout:element_limit:label" => "Maximum number of news objects displayed",
	"phloor_news:settings:layout:element_limit:description" => "",
	

	"phloor_news:settings:restrict_to_admins:label" => "Restrict the creation of News objects to admins",


    // Group
	'phloor_news:group' => 'Group news',
	'phloor_news:enablephloor_news' => 'Enable group news',
	'phloor_news:write' => 'Write a news post',

	// Editing
	'phloor_news:add' => 'Add news post',
	'phloor_news:edit' => 'Edit news post',
	
	'phloor_news:save_status' => 'Last saved: ',
	'phloor_news:never' => 'Never',

	// Statuses
	'phloor_news:status' => 'Status',
	'phloor_news:status:draft'         => 'Draft',
	'phloor_news:status:published'     => 'Published',
	'phloor_news:status:unsaved_draft' => 'Unsaved Draft',

	'phloor_news:revision' => 'Revision',
	'phloor_news:auto_saved_revision' => 'Auto Saved Revision',

	// messages
	'phloor_news:messages:warning:draft' => 'There is an unsaved draft of this post!',
	'phloor_news:edit_revision_notice' => '(Old version)',
	'phloor_news:none' => 'No news posts',

	'phloor_news:error:cannot_edit_post' => 'This post may not exist or you may not have permissions to edit it.',
	'phloor_news:error:revision_not_found' => 'Cannot find this revision.',

	// river
	'river:create:object:phloor_news' => '%s published the news post %s',
	'river:comment:object:phloor_news' => '%s commented on the news %s',

	// notifications
	'phloor_news:newpost' => 'A new news post',

	// widget
	'phloor_news:widget:description' => 'Display your latest news posts',
	'phloor_news:more_news' => 'More news posts',
	'phloor_news:numbertodisplay' => 'Number of news posts to display',

);

add_translation('en', $english);
