<?php


namespace phloor_news;

define('PHLOOR_NEWS_DEFAULT_EXCERPT_LENGTH', 1000);


function instance_of($entity) {
    return elgg_instanceof($entity, 'object', 'phloor_news', 'PhloorNews');
}

/**
 * default attributes
 * @param string $hook 'phloor_object:default_vars'
 * @param string $type "phloor_news"
 * @param unknown_type $return
 * @param unknown_type $params
 */
function default_vars($hook, $type, $return, $params) {
    $return = array(
    	'title'       => '',
    	'excerpt'     => '',
    	'description' => '',
    	'status'      => 'draft',
    	'access_id'   => ACCESS_DEFAULT,
    	'comments_on' => 'On',
    	'tags'        => '',
    );

    return $return;
}

/**
 * form attributes
 * @param string $hook 'phloor_object:form_vars'
 * @param string $type "phloor_news"
 * @param unknown_type $return
 * @param unknown_type $params
 */
function form_vars($hook, $type, $return, $params) {
    $return = array(
	    'title'       => 'input/text',
		'excerpt'     => 'input/longtext',
	    'description' => 'input/longtext',
	    'tags'        => 'input/tags',
	    'comments_on' => 'phloor/input/enable_comments',
		'access_id'   => 'input/access',
    	'status'      => 'phloor_news/input/statuspicker',
    );

    return $return;
}


/**
 * prepare form vars
 * 
 * @param string $hook 'phloor_object:prepare_form_vars'
 * @param string $type "phloor_news"
 * @param unknown_type $return
 * @param unknown_type $params
 */
function prepare_form_vars($hook, $type, $return, $params) {
    $entity = elgg_extract("entity", $params, NULL);

    //$new_entity = elgg_entity_exists($entity->guid) == false;
    $entity_exists = is_int($entity->guid) && $entity->guid > 0;
    if ($entity_exists) {
        $saved = date('F j, Y @ H:i', $entity->time_created);
    } else {
        $saved = elgg_echo('phloor_news:save_status:never');
    }

    // save the save status as description of the hidden field
    $new_return = array(
    	'save_status'  => array(
			'label'  => elgg_echo('phloor_news:form:save_status'),
			'view'   => 'phloor_news/output/save_status',
			'value'  => $saved,
    ),
    );

    // add a description to "new" entities (page: add)
    if (!$entity_exists) {
        $description = elgg_echo('phloor_news:form:save_status:description');
        $new_return['save_status']['description'] = $description;
    }

    // merge with $return (overwrite existing keys)
    $new_return = array_merge($return, $new_return);
     
    $revision = get_input('revision', 0);
    if ($entity_exists && $revision) {
        $revision = elgg_get_annotation_from_id((int)$revision);

        // load the revision annotation if requested
        if ($revision instanceof \ElggAnnotation &&
        $revision->entity_guid == $entity->getGUID()) {
            $new_return['description']['value'] = $revision->value;
        }

        // display a notice if there's an autosaved annotation
        // and we're not editing it.
        $auto_save == FALSE;
        if ($auto_save_annotations = $entity->getAnnotations('phloor_news_auto_save', 1)) {
            $auto_save = $auto_save_annotations[0];
        }

        if ($auto_save && $auto_save->id != $revision->id) {
            system_echo(elgg_echo('phloor_news:messages:warning:draft'));
        }

    }


    return $new_return;
}


/**
 * @param string $hook 'phloor_object:check_vars'
 * @param string $type "phloor_news"
 * @param unknown_type $return
 * @param unknown_type $params
 */
function check_vars($hook, $type, $return, $params) {

    $entity = elgg_extract("entity", $params, NULL);
    // check for valid class instance
    if (!namespace\instance_of($entity)) {
        return false;
    }

    // fail if a required entity isn't set
    $required = array('title', 'description');

    // load from menuitem and do sanity and access checking
    foreach ($required as $name) {
        $value = elgg_extract($name, $return, NULL);
        if (empty($value)) {
            register_error(elgg_echo("phloor_news:error:check_vars:$name:missing"));
            return false;
        }
    }

    // automatically create excerpt from description if none was given
    $excerpt     = elgg_extract('excerpt',     $return, '');
    $status      = elgg_extract('status',      $return, 'draft');
    $access_id   = elgg_extract('access_id',   $return, ACCESS_PUBLIC);
    $tags        = elgg_extract('tags',        $return, '');
    $comments_on = elgg_extract('comments_on', $return, 'Off');


    // convert tag string to array
    $return['tags'] = string_to_tag_array($tags);

    if (empty($excerpt)) {
        $description =  elgg_extract('description', $return, NULL);
        $return['excerpt'] = elgg_get_excerpt($description, PHLOOR_NEWS_DEFAULT_EXCERPT_LENGTH);
    }


    if (strcmp('draft', $status) == 0 && $access_id != ACCESS_PRIVATE) {
        system_message(elgg_echo("phloor_news:message:access_id:set_to_private"));
        $return['access_id'] = ACCESS_PRIVATE;
    }

    if(strcmp('On', $comments_on) != 0) {
        $return['comments_on'] = 'Off';
    }

    return $return;
}


/********************************************************************************/


/**
 * @param string $hook 'phloor_object:save:after'
 * @param string $type "phloor_news"
 * @param unknown_type $return
 * @param unknown_type $params
 */
function save_after($phloor_event, $subtype, $object) {
    // check for valid class instance
    if (!namespace\instance_of($object)) {
        return true;
    }

    // get the old values.. this entity has no guid if in "add" mode
    $old_object = $object->getVolatileData('old_entity');

    // save revision when body has changed
    if (!empty($old_object->description) &&
    strcmp($object->description, $old_object->description) != 0) {
        $object->annotate('phloor_news_revision', $old_object->description);
    }

    // determine if post is "new"
    $new_post = $object->get('new_post') == true ||
    !isset($old_object->guid);
     
    // remove autosave draft if exists
    $object->deleteAnnotations('phloor_news_auto_save');
    // no longer a brand new post.
    $object->deleteMetadata('new_post');
     
    // add to river if changing status or published, regardless of new post
    // because we remove it for drafts.
    if (($new_post || $old_object->status == 'draft') && $object->status == 'published') {
        add_to_river('river/object/phloor_news/create', 'create', elgg_get_logged_in_user_guid(), $object->getGUID());

        $object->time_created = time();
        $object->save();
    } elseif ($old_object->status == 'published' && $object->status == 'draft') {
        elgg_delete_river(array(
			'object_guid' => $object->guid,
			'action_type' => 'create',
        ));
    }

    return true;
}


/****************************************************************/


/**
 * Get page components to show phloor_news with
 * publish dates between $lower and $upper
 *
 * [wwwroot]/phloor/object/phloor_news/archive/[username]/[lower]/[upper]
 *
 * @param string $hook 'phloor_object:page_handler'
 * @param string $type "phloor_news:archive"
 * @param unknown_type $return
 * @param unknown_type $params
 *
 * @return array
 */
function page_handler_archive($hook, $type, $return, $params) {
    $page = elgg_extract('page', $params, array());
     
    $username  = elgg_extract(3, $page, ''); // username of owner
    $lower     = (int)elgg_extract(4, $page, 0); // Unix timestamp
    $upper     = (int)elgg_extract(5, $page, 0); // Unix timestamp

    if (!is_numeric($lower)) {
        $lower = 0;
    }
    if (!is_numeric($upper)) {
        $upper = 0;
    }

    $user = get_user_by_username($username);
    if (!elgg_instanceof($user, 'user')) {
        return false;
    }

    elgg_set_page_owner_guid($user->guid);
    $all_crumbs_title = elgg_echo("phloor/object/phloor_news:breadcrumb:all");
    elgg_push_breadcrumb($all_crumbs_title, "phloor/object/phloor_news/all");

    elgg_push_breadcrumb($user->name, "phloor/object/phloor_news/owner/{$user->username}");
    elgg_push_breadcrumb(elgg_echo('phloor_news:archives'));

    $options = array(
		'type' => 'object',
		'subtype' => 'phloor_news',
		'full_view' => FALSE,
    );

    if ($user->guid) {
        $options['owner_guid'] = $user->guid;
    }

    // admin / owners can see any posts
    // everyone else can only see published posts
    if (!(elgg_is_admin_logged_in() || (elgg_is_logged_in() && $user->guid == elgg_get_logged_in_user_guid()))) {
        $options['metadata_name_value_pairs'] = array(
        array('name' => 'status', 'value' => 'published')
        );
    }

    $now = time();
    if ($upper > $now) {
        $upper = $now;
    }

    if ($lower != 0) {
        $options['created_time_lower'] = $lower;
    }

    if ($upper != 0) {
        $options['created_time_upper'] = $upper;
    }

    $list = elgg_list_entities_from_metadata($options);
    if (!$list) {
        $content .= elgg_echo('phloor_news:none');
    } else {
        $content .= $list;
    }

    if ($upper != 0 && $lower != 0) {
        $title = elgg_echo('date:month:' . date('m', $lower), array(date('Y', $lower)));
    }
    else {
        $title = elgg_echio('phloor_news:archives');
    }

    return array(
		'content' => $content,
		'title' => $title,
		'filter' => '',
    );
}

/**
 * @param string $hook 'phloor_object:page_handler'
 * @param string $type "phloor_news:view"
 * @param unknown_type $return
 * @param unknown_type $params
 */
function page_handler_prepare_view($hook, $type, $return, $params) {
    elgg_load_js('lightbox');
    elgg_load_css('lightbox');

    return $return;
}

/**
 * @param string $hook 'phloor_object:page_handler'
 * @param string $type "phloor_news:add"
 * @param unknown_type $return
 * @param unknown_type $params
 */
function page_handler_prepare_add($hook, $type, $return, $params) {    
    // check if user if admin if news is restricted to admins
    if (namespace\is_restricted_to_admins() && !elgg_is_admin_logged_in()) {
        admin_gatekeeper();
    }
    
    elgg_load_js('elgg.phloor_news');

    return $return;
}

/**
* @param string $hook 'phloor_object:page_handler'
* @param string $type "phloor_news:add"
* @param unknown_type $return
* @param unknown_type $params
*/
function page_handler_postprocess_add($hook, $type, $return, $params) {
    $subtype = 'phloor_news';
    
    elgg_set_page_owner_guid(elgg_get_logged_in_user_guid());
    
    $container_guid = elgg_get_logged_in_user_guid();
    
    $container = elgg_extract("container", $params, NULL);
    if(elgg_instanceof($container)) {
        $container_guid = $container->guid;
    }
    
    //elgg_push_breadcrumb(elgg_echo("item:object:$subtype"));
	elgg_push_breadcrumb(elgg_echo('add'));
	
	// get form variables
	$form_variables = \phloor\entity\object\form_vars($subtype, NULL);	
	
	// create form
	$form = elgg_view('input/form',array(
    	'action' => elgg_normalize_url("action/phloor/object/save/?subtype=$subtype"),
    	'body' => elgg_view('phloor/entity_object/forms/save', array(
		    'guid'           => NULL,
		    'container_guid' => get_input('container_guid', $container_guid),
	        'subtype'        => $subtype,
	        'form_vars'      => $form_variables,
		)),
	    'id'               => "phloor-{$subtype}-add",
	    'name'             => "phloor-{$subtype}",
    	'method'           => 'post',
    	'enctype'          => 'multipart/form-data',
    	'disable_security' => false,
    	'class'            => 'elgg-form-alt',

    ));

    $return = array(
		'title'   => elgg_echo("phloor/object/$subtype:page:content:add:title"),
		'content' => $form,
		'sidebar' => '',
		'filter'  => '',
		'layout'  => 'one_column',
	);

    return $return;
}


/**
 * @param string $hook 'phloor_object:page_handler'
 * @param string $type "phloor_news:view"
 * @param unknown_type $return
 * @param unknown_type $params
 */
function page_handler_prepare_edit($hook, $type, $return, $params) {
    elgg_load_js('elgg.phloor_news');
    
    // check if user if admin if news is restricted to admins
    if (namespace\is_restricted_to_admins() && !elgg_is_admin_logged_in()) {
        admin_gatekeeper();
    }

    $page = elgg_extract('page', $params, array());

    // set rivison guid as input
    $revision = elgg_extract(4, $page, false);
    set_input('revision', $revision);

    return $return;
}

/**
* @param string $hook 'phloor_object:page_handler'
* @param string $type "phloor_news:add"
* @param unknown_type $return
* @param unknown_type $params
*/
function page_handler_postprocess_edit($hook, $type, $return, $params) {
    $subtype = 'phloor_news';
    $entity  = elgg_extract("entity", $params, NULL);
    if (!elgg_instanceof($entity, 'object', $subtype)) {
        return false;
    }

    // mark page as owned by the user
    elgg_set_page_owner_guid($entity->getOwnerGUID());
    
    //$options = \phloor\entity\object\page_handler\defaults\page_content_edit($subtype, $entity->guid);
    // check if user can edit this entity
    if (!$entity->canEdit()) {
        return false;
    }
     
    elgg_push_breadcrumb($entity->title, $entity->getURL());
    elgg_push_breadcrumb(elgg_echo('edit'));
    
    // get form variables
    $form_variables = \phloor\entity\object\form_vars($subtype, $entity->guid);
    
    // create form
    $form = elgg_view('input/form',array(
    	'action' => elgg_normalize_url("action/phloor/object/save/?subtype=$subtype"),
    	'body' => elgg_view('phloor/entity_object/forms/save', array(
		    'guid'    => $entity->guid,
		    'container_guid' => get_input('container_guid', $entity->getContainerGUID()),
		    'subtype' => $subtype,
	        'form_vars' => $form_variables,
        )),
	    'id'               => "phloor-{$subtype}-edit",
	    'name'             => "phloor-{$subtype}",
    	'method'           => 'post',
    	'enctype'          => 'multipart/form-data',
    	'disable_security' => false,
    	'class'            => 'elgg-form-alt',
    ));
    
    $options = array(
    	'title'   => elgg_echo("phloor/object/$subtype:page:content:edit:title", array(
            $entity->title
        )),
    	'content' => $form,
    	'sidebar' => '',
    	'filter'  => '',
        'layout' => 'one_column',
    );

    return $options;
}

/**
 * @param string $hook 'phloor_object:page_handler'
 * @param string $type "phloor_news:owner"
 * @param unknown_type $return
 * @param unknown_type $params
 */
function page_handler_prepare_owner($hook, $type, $return, $params) {
    namespace\load_mansonry_js();
    elgg_load_js('lightbox');
    elgg_load_css('lightbox');

    return $return;
}

/**
 * @param string $hook 'phloor_object:page_handler'
 * @param string $type "phloor_news:friends"
 * @param unknown_type $return
 * @param unknown_type $params
 */
function page_handler_prepare_friends($hook, $type, $return, $params) {
    namespace\load_mansonry_js();
    elgg_load_js('lightbox');
    elgg_load_css('lightbox');

    return $return;
}

/**
 * @param string $hook 'phloor_object:page_handler'
 * @param string $type "phloor_news:all"
 * @param unknown_type $return
 * @param unknown_type $params
 */
function page_handler_prepare_all($hook, $type, $return, $params) {
    namespace\load_mansonry_js();
    elgg_load_js('lightbox');
    elgg_load_css('lightbox');

    return $return;
}

/**
* @param string $hook 'phloor_object:page_handler'
* @param string $type "phloor_news:all"
* @param unknown_type $return
* @param unknown_type $params
*/
function page_handler_postprocess_all($hook, $type, $return, $params) {
    $subtype = 'phloor_news';

    if (!namespace\is_restricted_to_admins() || elgg_is_admin_logged_in()) {
        \phloor\entity\object\page_handler\defaults\register_title_button($subtype, "add");
    }
    
	$default_options = array(
		'type'             => 'object',
		'subtype'          => $subtype,
		'full_view'        => false,
		'pagination'       => true,
		'list_type_toggle' => false,
		'offset'           => (int) max(get_input('offset', 0), 0),
		'limit'            => (int) max(get_input('limit', 10), 0),
		'list_class'       => "elgg-list-entity phloor-list-$subtype",
	);
	$options = array_merge($default_options, $params);

    $container = get_entity($container_guid);
    $user = elgg_get_logged_in_user_entity();   

	$return = array();
	if (elgg_instanceof($container)) {
		// access check for closed groups
		group_gatekeeper();

		elgg_push_breadcrumb($container->name);

		$options['container_guid'] = $container_guid;

		$title = elgg_echo("phloor/object/$subtype:page:content:list:container:title", array(
		    $container->name,
		));

        $return['title'] = $title;
        
        $return['filter_context'] = 'none';
        // set filter context to mine if owner viewing own objects
		if ($container_guid == $user->guid) {
		    $return['filter_context'] = 'mine';
		}
		// dont display filter when watching someone else's objects
		// or its from a group
		if (elgg_instanceof($container, 'group')) {
		    $return['filter'] = ''; // turn off filter
		    //$return['filter_context'] = 'none';
		}
	} else {
	    $title = elgg_echo("phloor/object/$subtype:page:content:list:all:title");

		$return['title'] = $title;
		$return['filter_context'] = 'all';
	}
	
	$content = elgg_list_entities_from_metadata($options);
	if (!$content) {
	    $content = '<p>' . elgg_echo("phloor/object/$subtype:page:content:list:none") . '</p>';
	}
	
	$return['content'] = $content;
	$return['layout']  = 'content';

	return $return;
}

/**
 * appends sidebar related stuff to all news pages
 * 
 * @param string $hook 'phloor_object:page_handler'
 * @param string $type "all"
 * @param unknown_type $return
 * @param unknown_type $params
 */
function page_handler_add_sidebar_content($hook, $type, $return, $params) {
    $subtype   = elgg_extract("subtype",   $params, NULL);
    // check for the right 'hook' and subtype
    if (strcmp('phloor_news', $subtype) != 0 ||
        strcmp('phloor_object:page_handler', $hook) != 0) {
        return $return;
    }

    if (!is_array($return)) {
        return $return;
    }
     
    // set default values for the page options
    $default_options = array(
	    'sidebar' => elgg_view('phloor_news/sidebar', $params),
    );
    // merge default values with options from hook
    $options = array_merge($return, $default_options);

    return $options;
}


function load_mansonry_js() {
    // check settings to load needed javascript
    $enable_masonry = elgg_get_plugin_setting('enable_masonry', 'phloor_news');
    if (!phloor_str_is_true($enable_masonry)) {
        return false;
    }
   
    elgg_load_js('jquery-masonry');
    elgg_load_js('elgg.phloor_news.masonry');

    return true;
}


function is_restricted_to_admins() {
    $restrict_to_admins  = elgg_get_plugin_setting('restrict_to_admins',  'phloor_news');

    return strcmp('true', $restrict_to_admins) == 0;
}