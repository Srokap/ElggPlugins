<?php

update_subtype('object', 'phloor_news');
