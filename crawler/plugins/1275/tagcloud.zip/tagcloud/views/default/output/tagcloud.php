<?php

	/**
	 * Elgg tagcloud
	 * Displays a tagcloud
	 * 
	 * @package Elgg
	 * @subpackage tagcloud
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd - bug fix sammykanan@yahoo.com
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.org/
	 * 
	 * @uses $vars['tagcloud'] An array of stdClass objects with two elements: 'tag' (the text of the tag) and 'total' (the number of elements with this tag) 
	 * 
	 */
    
	if (!empty($vars['subtype'])) {
		$subtype = "&subtype=" . urlencode($vars['subtype']);
	} else {
		$subtype = "";
	}
	if (!empty($vars['object'])) {
		$object = "&object=" . urlencode($vars['object']);
	} else {
		$object = "";
	}
	
	if (empty($vars['tagcloud']) && !empty($vars['value']))
		$vars['tagcloud'] = $vars['value'];

        if (!empty($vars['tagcloud']) && is_array($vars['tagcloud'])) {
        
        $counter = 0;
        $cloud = "";
        $max = 0;
        foreach($vars['tagcloud'] as $tag) {
	    // BUG FIX: UPDATE TO ENSURE WE DONT COUNT BLANKS
	    if ( $tag->tag != "" ) {
        	if ($tag->total > $max) {
        		$max = $tag->total;
        	}
   	    }
        }
        foreach($vars['tagcloud'] as $tag) {
            if (!empty($cloud)) 
	      $cloud .= ", ";
	    // BUG FIX: UPDATE TO ENSURE WE DONT COUNT BLANKS
	    if ( $tag->tag != "" ) {
              $size = round((log($tag->total) / log($max)) * 100) + 30;
              if ($size < 60) 
                $size = 60;
              $cloud .= "<a href=\"" . $vars['url'] . "search/?tag=". urlencode($tag->tag) . $object . $subtype . "\" style=\"font-size: {$size}%\" title=\"".addslashes($tag->tag)." ({$tag->total})\" style=\"text-decoration:none;\">" .$tag->tag . "</a>";
	    }
        }
        echo $cloud;

    }
     
?>
