<?php
    /**
     * Elgg tagcloud plugin edit page
     */

        $notags = 100;
        if ( $vars['entity']->notags ) {
                $notags = $vars['entity']->notags;
        }
?>
<p>
        <?php echo elgg_echo("tagcloud:widget:notags"); ?>:
        <select name="params[notags]">
             <option value="10" <?php if ($notags == 10) echo "SELECTED"; ?>>10</option>
             <option value="20" <?php if ($notags == 20) echo "SELECTED"; ?>>20</option>
             <option value="50" <?php if ($notags == 50) echo "SELECTED"; ?>>50</option>
             <option value="100" <?php if ($notags == 100) echo "SELECTED"; ?>>100</option>
             <option value="200" <?php if ($notags == 200) echo "SELECTED"; ?>>200</option>
         </select>
</p>
