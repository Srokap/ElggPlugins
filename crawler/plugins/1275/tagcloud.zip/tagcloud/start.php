<?php

	/**
	 */

	/**
	 * status initialisation
	 *
	 * These parameters are required for the event API, but we won't use them:
	 * 
	 * @param unknown_type $event
	 * @param unknown_type $object_type
	 * @param unknown_type $object
	 */

		function tagcloud_init() {
			
			// Load system configuration
				global $CONFIG;
				
			// Load the language file
				register_translations($CONFIG->pluginspath . "tagcloud/languages/");
				
			// Extend system CSS with our own styles, which are defined in the tagcloud/css view
				extend_view('css','tagcloud/css');
				
			// Your tag cloud widget
			      add_widget_type( "tagcloud" , elgg_echo("tagcloud:widget:title"), elgg_echo("tagcloud:widget:description" ));
			     
		}
			
	// Make sure the status initialisation function is called on initialisation
		register_elgg_event_handler('init','system','tagcloud_init');
		
?>
