<?php
	/**
	 * Custom Index page css extender
	 * 
	 * @package custom_index
	 */
?>

#custom_index {
}
#index_left {
	width: 49%;
	float: left;
	margin: 0 0 1% 0;
}
#index_right {
    width:49%;
    float:right;
    margin:0 0 1% 0;
}
#index_welcome {
	background: <?php echo $canvasbg ?>;
}


