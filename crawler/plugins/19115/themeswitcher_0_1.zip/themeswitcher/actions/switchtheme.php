<?php

  require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
  global $CONFIG;
  
  //action_gatekeeper();

  if (function_exists('get_loggedin_user'))
    $user = get_loggedin_user();
  else
    $user = $_SESSION['user'];
    
  $theme = get_input('theme');
  
  $user->usertheme = $theme;
  $user->save();  
     
  forward($_SERVER['HTTP_REFERER']);
  exit();
?>
