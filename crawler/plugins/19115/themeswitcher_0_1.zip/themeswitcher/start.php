<?php

/***********************************
 Theme Switcher 

  Cash Costello
  copyright 2009

*************************************/

  function themeswitcher_set_theme_list()
  {
    global $CONFIG;
    
    $themes_dir  = $CONFIG->pluginspath . 'themeswitcher/themes/';
    $themes_list = array(); 
    if ($handle = opendir($themes_dir)) 
    {
      while (false !== ($file = readdir($handle))) 
      {
        if (!in_array($file, array('.','..')) && is_dir($themes_dir . $file))
        {
          $themes_list[] = $file;
        }
      }
    }
    sort($themes_list);
  
    $CONFIG->themelist = $themes_list;
  }

  function themeswitcher_init() 
  {    
    global $CONFIG;
    
    register_action('switchtheme', false, $CONFIG->pluginspath . 'themeswitcher/actions/switchtheme.php');
    
    themeswitcher_set_theme_list();  
  }
  
  register_elgg_event_handler('plugins_boot', 'system', 'themeswitcher_init');
?>
