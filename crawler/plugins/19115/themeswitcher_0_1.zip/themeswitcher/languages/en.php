<?php

	$english = array(	
      'themeswitcher:themes' => 'Themes',
	);
					
	add_translation("en",$english);

?>
