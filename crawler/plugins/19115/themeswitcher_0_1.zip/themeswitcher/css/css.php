<?php

  require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
      
  $default_css = elgg_view("css");
      
  header("Content-type: text/css", true);
  header("Pragma: public", true);
  header("Content-Length: " . strlen($default_css));
  header("Cache-Control: no-cache, must-revalidate");
         
  echo $default_css;
    
?>
