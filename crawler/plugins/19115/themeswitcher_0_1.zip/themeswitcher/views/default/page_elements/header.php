<body>

<div id="page_container">

<?php echo elgg_view('page_elements/elgg_topbar', $vars); ?>

  <div id="page_subcontainer">
	
    <div id="page_wrapper">
    
      <div id="layout_header">
        <div id="wrapper_header">
          <div id="site_name">
	          <h1><a href="<?php echo $vars['url']; ?>"><?php echo $vars['config']->sitename; ?></a></h1>
          </div>
        </div><!-- /#wrapper_header -->
      </div><!-- /#layout_header -->
