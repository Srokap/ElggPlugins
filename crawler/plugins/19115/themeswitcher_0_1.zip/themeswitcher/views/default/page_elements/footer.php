<?php

	/**
	 * Elgg footer
	 * The standard HTML footer that displays across the site
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.org/
	 * 
	 */
	 
	 // get the tools menu
	$menu = get_register('menu');
	
	if (is_array($menu) && sizeof($menu) > 0) {
		$alphamenu = array();
		foreach($menu as $item) {
			$alphamenu[$item->name] = $item;
	  }
		ksort($alphamenu);
		$menu = $alphamenu;
  }	

?>

</div><!-- /#page_wrapper -->

<div id="layout_footer">
  <div id="footer_wrapper">
		<div class="footer_toolbar_links">
		<?php
			foreach($menu as $item) {
    			
    				echo " | <a href=\"{$item->value}\">" . $item->name . "</a>";
    			
			} 
		?>
		|
		</div>

    <div id="footer_left_column">
		<a href="http://www.elgg.org" target="_blank">
		<img src="<?php echo $vars['url']; ?>_graphics/powered_by_elgg_badge_drk_bckgnd.gif" border="0" />
		</a>
		</div>
		
		<div id="footer_middle_column">
		</div>
		
		<div id="footer_right_column">
		  <p class="footer_legal_links">
        <small>Powered by Elgg, the leading open source social networking platform</small>
		  </p>
		</div>
	</div><!-- /#footer_wrapper -->
</div><!-- /#layout_footer -->

</div><!-- /#page_subcontainer -->
</div><!-- /#page_container -->

</body>
</html>
