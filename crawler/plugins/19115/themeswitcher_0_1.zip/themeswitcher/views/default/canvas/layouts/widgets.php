<?php

		$widgettypes = get_widget_types();

		$owner = page_owner_entity();
		
		$area1widgets = get_widgets(page_owner(),get_context(),1);
		$area2widgets = get_widgets(page_owner(),get_context(),2);
		$area3widgets = get_widgets(page_owner(),get_context(),3);
		
		if (empty($area1widgets) && empty($area2widgets) && empty($area3widgets)) {
			
			if (isset($vars['area3'])) $vars['area1'] = $vars['area3'];
			if (isset($vars['area4'])) $vars['area2'] = $vars['area4'];
			
		}
		
		if (get_context() === 'dashboard')
		{
			if (isset($vars['area3'])) $vars['area1'] = $vars['area3'];
    
    }
		
		if (is_array($widgettypes) && sizeof($widgettypes) > 0 && $owner && $owner->canEdit()) {
		  include 'widgets_edit.inc';
		}

			
?>

<div id="primary">
<?php 
    if (isset($vars['area1'])) {
      echo $vars['area1']; 
    } 
?>

  <div id="the_rest">
    <div id="left_widget_column">
<?php
		
			if (is_array($area1widgets) && sizeof($area1widgets) > 0)
			foreach($area1widgets as $widget) {
				echo elgg_view_entity($widget);
			}

?>
    </div>
    <div id="middle_widget_column">
<?php 
      if (isset($vars['area2'])) echo $vars['area2']; 
		
			if (is_array($area2widgets) && sizeof($area2widgets) > 0)
			foreach($area2widgets as $widget) {
				echo elgg_view_entity($widget);
			}
		
?>
    </div>
  </div>
</div>

<div id="secondary">
		<?php
		
		if($_SESSION['user']->guid == page_owner()) {
		?>
		<!-- customise page button -->
		<div id="edit_page">
    <a href="javascript:void(0);" class="toggle_customise_edit_panel"><?php echo(elgg_echo('dashboard:configure')); ?></a>
		</div>
    <?php
		}
				
			if (is_array($area3widgets) && sizeof($area3widgets) > 0)
			foreach($area3widgets as $widget) {
				echo elgg_view_entity($widget);
			}

		?>
</div>
