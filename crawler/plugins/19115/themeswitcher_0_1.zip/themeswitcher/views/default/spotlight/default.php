<?php

	/**
	 * Elgg default spotlight
	 * The spotlight area that displays across the site
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.org/
	 * 
	 */
?>

<div id="spotlight_left_column">
							<h2>Welcome to the Elgg software</h2>
							<p>Elgg is a social networking framework. It provides the necessary functionality to allow you to run your own social networking site, whether publicly (like Facebook) or internally on a networked intranet (like Microsoft Sharepoint).</p> 
</div>

<div id="spotlight_middle_column">
							<ul>
								<li><a href="http://news.elgg.org/pg/blog/marcus/read/42/import-and-export-in-elgg-10">Import and Export</a></li>
								<li><a href="http://news.elgg.org/pg/blog/bwerdmuller/read/38/events-and-auditing-in-elgg">Events and Auditing</li>
								<li><a href="http://news.elgg.org/pg/blog/bwerdmuller/read/31/translations-and-views-in-elgg-10">Translations and Views</li>
								<li><a href="http://news.elgg.org/pg/blog/bwerdmuller/read/41/access-control-in-elgg">Access controls</a></li>
							</ul>
</div>

<div id="spotlight_right_column">
							<ul>
								<li><a href="http://news.elgg.org">Elgg news</a></li>
								<li><a href="http://elgg.com">Elgg services</a></li>
								<li><a href="http://elgg.com">Elgg support</a></li>
								<li><a href="http://elgg.com">Elgg hosting</a></li>
							</ul>
</div>
