    <ul class="topbardropdownmenu">
      <li><a href="#"><?php echo elgg_echo('themeswitcher:themes'); ?></a>
        <ul>
  
<?php

  // theme name cannot have any spaces or special characters
  foreach ($CONFIG->themelist as $theme)
  {
    $theme_name = ucfirst(strtolower($theme));
    echo "<li><a href='${vars['url']}action/switchtheme?theme=${theme}'>${theme_name}</a></li>";  
  }
?>
        </ul>  
      </li>
    </ul>
