<?php

/*******************************************
  Vertical toolbar theme by Cash Costello
********************************************/
?>

a {
	color: #333333; 
	text-decoration: none;
	-moz-outline-style: none;
	outline: none;
}
a:visited {
	color: #333333; 
}
a:hover {
	text-decoration: underline;
	color:#000000;
}

/* ***************************************
    PAGE LAYOUT - MAIN STRUCTURE
*************************************** */
body {
	font:80%/1.4  "Lucida Grande", Verdana, sans-serif;
	color:#666666;
	background: #ffffff;
}

#page_container {
	position:relative;
  width:1000px;
	margin:0 auto;
	padding:0;
	border-right:1px solid #000000;
	border-left:1px solid #000000;
}

#page_subcontainer {
}

#page_wrapper {
}

#layout_header {
  position:absolute;
  top: 0px;
  left: 200px;
  width: 800px;
  height: 300px;
	background:url(<?php echo $vars['url']; ?>mod/themeswitcher/themes/white/graphics/header.jpg) repeat-x left top;
  border-bottom:5px solid #000000;
}

#layout_canvas {
  float:left;
  margin-top:305px;
  width:1000px;
	min-height:400px;
	clear:both;
}

#layout_spotlight {
  float:left;
	padding:0;
	margin:0;
  width:1000px;
	clear:both;
}

#layout_footer {
	background:#333333;
	height:80px;
	border-bottom:1px solid black;
	clear:both;
}


/* only used for install and forgotten password */ 
/* canvas layout: 1 column, no sidebar */
#one_column {
	width:918px;
	margin:20px;
	padding:20px;
	min-height: 360px;
	background: white;
	border-right: 1px solid #cccccc;
	border-bottom: 1px solid #cccccc;
}

/* canvas layout: 2 column left sidebar */
#two_column_left_sidebar {
	width:209px;
	margin:20px 0 20px 20px;
	min-height:360px;
	float:left;
	background:white;
	border-right: 1px solid #cccccc;
	padding:0px;
}

#two_column_left_sidebar_maincontent {
	width:690px;
	margin:20px 0 20px 20px;
	min-height: 360px;
	float:left;
	background: white;
	padding:0 10px 20px 10px;
}

#primary {
  float: left; 
  width: 648px;
  padding-left: 10px;
  padding-top: 10px;
}

#secondary {
  float: left; 
  width: 319px;
  padding-left: 10px;
  padding-top: 10px;
}

#left_widget_column {
  float: left;
  width: 319px;
}

#middle_widget_column {
  float: left;
  width: 319px;
  padding-left: 10px;
}

/* ***************************************
  ELGG TOPBAR
*************************************** */
#elgg_topbar {
  position: absolute;
  top: 0px;
  left: 0px;
  width: 200px;
  height: 300px;
	background:#252525;
  color:ffffff;
  border-bottom:5px solid #000000;
  z-index: 100;
}
#elgg_topbar_container_left {
	float:left;
	margin: 10px 10px;
}
#elgg_topbar_container_right {
	float:right;
	height:24px;
	position:absolute;
	right:0px;
	top:0px;
	text-align:right;
	display:none;
}
#elgg_topbar_container_search {
	float:right;
	height:21px;
	position:relative;
	right:120px;
	text-align:right;
	margin:3px 0 0 0;
	display:none;
}
#elgg_topbar_container_left a.pagelinks {
	float:left;
	clear:both;
	color:#ffffff;
}
#elgg_topbar_container_left a.pagelinks:hover {
	text-decoration: none;
}
#elgg_topbar_container_left .toolbarlinks2 {
	float:left;
	clear:both;
}
#elgg_topbar_container_left a.usersettings {
	float:left;
	clear:both;
	color:#ffffff;
}
#elgg_topbar_container_left a.usersettings:hover {
	color:#eeeeee;
}

#elgg_topbar_container_right {
	padding:3px 0 0 0;
}
#elgg_topbar_container_right a {
	color:#eeeeee;
	margin:0 5px 0 0;
	background:transparent url(<?php echo $vars['url']; ?>_graphics/elgg_toolbar_logout.gif) no-repeat top right;
	padding:0 21px 0 0;
	display:block;
	height:20px;
}
#elgg_topbar_container_right a:hover {
	background-position: right -21px;
}

#searchform input.search_input {
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	background-color:#FFFFFF;
	border:1px solid #BBBBBB;
	color:#999999;
	font-size:12px;
	font-weight:bold;
	margin:0pt;
	padding:2px;
	width:180px;
	height:12px;
}
#searchform input.search_submit_button {
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	color:#333333;
	background: #cccccc;
	border:none;
	font-size:12px;
	font-weight:bold;
	margin:0px;
	padding:2px;
	width:auto;
	height:18px;
	cursor:pointer;
}
#searchform input.search_submit_button:hover {
	color:#ffffff;
	background: #0054a7;
}

/* ***************************************
	DROPDOWN MENU
*************************************** */
.topbardropdownmenu, .topbardropdownmenu ul {
  list-style-type:none;
  padding:0;
  margin:0;
  float:left;
  margin:0;
  clear:both;
  text-indent: -3px;
}
.topbardropdownmenu li {
  float:left;
  position:relative;
/*	background: url(<?php echo $vars['url']; ?>_graphics/toolbar_arrow.png) no-repeat right 9px;	*/
  width:70px;
}
.topbardropdownmenu li a, .topbardropdownmenu li a:visited {
  color:white;
  display:block;
  padding:3px 13px 3px 3px;
  text-decoration:none;
}
.topbardropdownmenu li:hover > a {
/*  background: #333333 url(<?php echo $vars['url']; ?>_graphics/toolbar_arrow.png) no-repeat right -18px; */
}
.topbardropdownmenu li ul {
  margin: 0;
  padding: 0;
}
.topbardropdownmenu li ul {
  height:0;
  left:70px;
  top:0px;
  border-top:1px solid #000000;
  position:absolute;
  visibility:hidden;
}
.topbardropdownmenu li:hover ul, .topbardropdownmenu a:hover ul {
  visibility:visible; 
}
.topbardropdownmenu li ul li {
  background:#DEDEDE none repeat scroll 0 0;
  color:#333333;
  padding:0;
  float: left;
  position: relative;
  margin: 0;
  border: 0;
}
.topbardropdownmenu li ul li a, .topbardropdownmenu li ul li a:visited {
  background:#dedede none repeat scroll 0 0;
  color:#333333;
  height:auto;
  width:120px;
  border-color:#F5F5F5 #333333 #999999 #F5F5F5;
  border-style:solid;
  border-width:1px;
  padding:2px 6px 2px 6px;
}
.topbardropdownmenu li ul li a:hover {
  background:#333333;
  color:#ffffff;
	border-left:1px solid #999999;
	border-top:1px solid #999999;
}

/* ***************************************
	HEADER
*************************************** */

#wrapper_header {
  position:relative;
  float:left;
  width:100%;
  height:300px;
}

#site_name {
  background:transparent url(<?php echo $vars['url']; ?>mod/themeswitcher/themes/white/graphics/title.gif) repeat-x left top;
  float:right;
  height:100px;
  margin:60px 0 0;
  padding:0 20px;
  text-align:right;
}
#site_name h1 {
  padding-top: 20px;
}
#site_name h1 a {
  color:#333333;
	font-size: 1.2em;
	line-height: 1em;
}

/* ***************************************
	SPOTLIGHT
*************************************** */
#wrapper_spotlight {
	margin:0;
	padding:0;
	height:auto;
}
#wrapper_spotlight .collapsable_box_content  {
	margin:0;
	padding:20px 20px 10px 20px;
	min-height:60px;
	border:none;
	float: left;
}
#layout_spotlight .collapsable_box_content p {
	padding:0;
}
#wrapper_spotlight .collapsable_box_header  {
	border-left: none;
	border-right: none;
}
#spotlight_left_column {
  float: left;
  width: 100%;
}
#spotlight_middle_column {
  float: left;
  width: 50%;
}
#spotlight_right_column {
  float: left;
  width: 50%;
}
/* IE7 */
*:first-child+html #wrapper_spotlight .collapsable_box_content {
	width:958px;
}


/* ***************************************
	FOOTER
*************************************** */
#layout_footer, #layout_footer a {
  color:#999999;
}
#layout_footer a:hover {
	color:white;
}
#footer_wrapper {
  height: 80px;
  width: 990px;
	position:relative;
	margin:0 auto;
}
.footer_toolbar_links {
  float: left;
  width: 100%;
  text-align: right;
  font-size:1.2em;
  padding: 15px 0 15px 0;
}
#footer_left_column {
  float: left;
}
#footer_right_column {
  float: right;
}


/* ***************************************
  COLLAPSABLE BOXES
*************************************** */
.collapsable_box {
  float: left;
  width: 100%;
  padding-bottom: 10px;
}
.collapsable_box_header {
	position: relative;	
	color: #333333;
	background: white;
	border:1px solid #cccccc;
	padding: 5px 10px 5px 10px;
	margin:0;
}
.collapsable_box_header h1 {
	color: #333333;
	font-size:1.25em;
}
.collapsable_box_content {
	padding: 10px;
	margin:0;
	height:auto;
	background: white;
	border-right:1px solid #cccccc;
	border-left:1px solid #cccccc;
	border-bottom:1px solid #cccccc;
}
.collapsable_box_editpanel {
	display: none;
	background: #aaaaaa;
	color:#333333;
	padding:5px 10px 5px 10px;
}
.collapsable_box_header a.toggle_box_contents {
	color: #333333;
	cursor:pointer;
	font-size:20px;
	font-weight: bold;
	text-decoration:none;
	float:right;
	position:absolute;
	right:5px;
	top:0px;
}
.collapsable_box_header a.toggle_box_edit_panel {
	color: #333333;
	cursor:pointer;
	font-size:9px;
	text-transform: uppercase;
	text-decoration:none;
	font-weight: normal;
	float:right;
	position:absolute;
	right:25px;
	top:10px;
}
.collapsable_box_editpanel label {
	font-weight: normal;
	font-size: 100%;
}
/* used for collapsing a content box */
.display_none {
	display:none;
}
/* used on spotlight box - to cancel default box margin */
.no_space_after {
	margin: 0 0 0 0;
	padding: 0 0 0 0;
}
/* IE6 fix */
* html .collapsable_box  { 
	height:10px;
}


/* ***************************************
	PROFILE
*************************************** */
#dashboard_info {
  margin-bottom: 10px;
	width:605px;
	padding:20px;
	background: white;
	border:1px solid #cccccc;
}
#profile_info {
	float:left;
	width:605px;
	margin:0px 0px 10px 0;
	padding:20px;
	background:white;
	border:1px solid #cccccc;
}
#profile_left_column {
	float:left;
  width:37%;
	padding: 0;
	margin:0;
}
#profile_middle_column {
	float:left;
	width:63%;
	padding: 0;
}
#profile_right_column {
	width:100%;
	margin:15px 0 0 0;
	padding: 0;
	float: left;
}
#profile_menu_wrapper {
	margin:10px 0 10px 0;
	width:200px;
	float: left;
}
#profile_menu_wrapper p {
	border-bottom:1px solid #cccccc;
}
#profile_menu_wrapper p:first-child {
	border-top:1px solid #cccccc;
}
#profile_menu_wrapper a {
	display:block;
	padding:0 0 0 3px;
}
#profile_menu_wrapper a:hover {
	color:#ffffff;
	background:#cccccc;
	text-decoration:none;
}
p.user_menu_friends, p.user_menu_profile, 
p.user_menu_removefriend, 
p.user_menu_friends_of {
	margin:0;
}
#profile_menu_wrapper .user_menu_admin {
	border-top:none;
}

#profile_middle_column p {
	margin:7px 0 7px 0;
	padding:2px 4px 2px 4px;
}
/* profile owner name */
#profile_middle_column h2 {
	padding:0 0 14px 0;
	margin:0;
}
#profile_middle_column .odd {
	background:#dedede;
}
#profile_middle_column .even {
	background:#eeeeee;
}
#profile_right_column p {
	margin:0 0 7px 0;
}
#profile_right_column .profile_aboutme_title {
	margin:0;
	padding:0;
	line-height:1em;
}
/* edit profile button */
.profile_info_edit_buttons {
	float:right;
	margin:0  !important;
	padding:0 !important;
	font-size: 90%;
}


/* ***************************************
  WIDGET PICKER (PROFILE & DASHBOARD)
*************************************** */

/* 'edit page' button */
#edit_page {
  float: left;
}

a.toggle_customise_edit_panel {
  background: #ffffff;
  float:right;
  padding:5px 5px 5px 8px;
  margin-bottom: 10px;
  width:306px;
	color: #333333;
	border:1px solid #cccccc;
}
a.toggle_customise_edit_panel:hover { 
	color: #ffffff;
	background: #333333;
	text-decoration:none;
}

#customise_editpanel {
	display:none;
	margin: 0;
	padding:20px;
	background: #dedede;
}

/* Top area - instructions */
.customise_editpanel_instructions {
	width:690px;
	padding:0 0 10px 0;
}
.customise_editpanel_instructions h2 {
	padding:0 0 10px 0;
}
.customise_editpanel_instructions p {
	margin:0 0 5px 0;
	line-height: 1.4em;
}

/* RHS (widget gallery area) */
#customise_editpanel_rhs {
	float:right;
	width:230px;
	background:white;
}
#customise_editpanel #customise_editpanel_rhs h2 {
	color:#333333;
	font-size: 1.4em;
	margin:0;
	padding:6px;
}
#widget_picker_gallery {
	border-top:1px solid #cccccc;
	background:white;
	width:210px; 
	height:340px;
	padding:10px;
	overflow:scroll;
	overflow-x:hidden;
}

/* main page widget area */
#customise_page_view {
	width:656px;
	padding:10px;
	margin:0 0 10px 0;
	background:white;
}
#customise_page_view h2 {
	border-top:1px solid #cccccc;
	border-right:1px solid #cccccc;
	border-left:1px solid #cccccc;
	margin:0;
	padding:5px;
	width:200px;
	color: #0054a7;
	background: #f5f5f5;
	font-size:1.25em;
	line-height: 1.2em;
}
#profile_box_widgets {
	width:422px;
	margin:0 10px 10px 0;
	padding:5px 5px 0px 5px;
	min-height: 50px;
	border:1px solid #cccccc;
	background: #f5f5f5;
}
#customise_page_view h2.profile_box {
	width:422px;
	color: #999999;
}
#profile_box_widgets p {
	color:#999999;
}
#leftcolumn_widgets {
	width:200px;
	margin:0 10px 0 0;
	padding:5px 5px 40px 5px;
	min-height: 190px;
	border:1px solid #cccccc;
}
#middlecolumn_widgets {
	width:200px;
	margin:0 10px 0 0;
	padding:5px 5px 40px 5px;
	min-height: 190px;
	border:1px solid #cccccc;
}
#rightcolumn_widgets {
	width:200px;
	margin:0;
	padding:5px 5px 40px 5px;
	min-height: 190px;
	border:1px solid #cccccc;
}
#rightcolumn_widgets.long {
	min-height: 288px;
}
/* IE6 fix */
* html #leftcolumn_widgets { 
	height: 190px;
}
* html #middlecolumn_widgets { 
	height: 190px;
}
* html #rightcolumn_widgets { 
	height: 190px;
}
* html #rightcolumn_widgets.long { 
	height: 338px;
}

#customise_editpanel table.draggable_widget {
	width:200px;
	background: #cccccc;
	margin: 10px 0 0 0;
	vertical-align:text-top;
	border:1px solid #cccccc;
}
#widget_picker_gallery table.draggable_widget {
	width:200px;
	background: #cccccc;
	margin: 10px 0 0 0;
}

/* take care of long widget names */
#customise_editpanel table.draggable_widget h3 {
	word-wrap:break-word;/* safari, webkit, ie */
	width:140px;
	line-height: 1.1em;
	overflow: hidden;/* ff */
	padding:4px;
}
#widget_picker_gallery table.draggable_widget h3 {
	word-wrap:break-word;
	width:145px;
	line-height: 1.1em;
	overflow: hidden;
	padding:4px;
}
#customise_editpanel img.more_info {
	background: url(<?php echo $vars['url']; ?>_graphics/icon_customise_info.gif) no-repeat top left;
	cursor:pointer;
}
#customise_editpanel img.drag_handle {
	background: url(<?php echo $vars['url']; ?>_graphics/icon_customise_drag.gif) no-repeat top left;
	cursor:move;
}
#customise_editpanel img {
	margin-top:4px;
}
#widget_moreinfo {
	position:absolute;
	border:1px solid #333333;
	background:#e4ecf5;
	color:#333333;
	padding:5px;
	display:none;
	width: 200px;
	line-height: 1.2em;
}
/* droppable area hover class  */
.droppable-hover {
	background:#fdffc3;
}
/* target drop area class */
.placeholder {
	border:2px dashed #AAA;
	width:196px !important;
	margin: 10px 0 10px 0;
}
/* class of widget while dragging */
.ui-sortable-helper {
	background: #4690d6;
	color:white;
	padding: 4px;
	margin: 10px 0 0 0;
	width:200px;
}
/* IE6 fix */
* html .placeholder { 
	margin: 0;
}
/* IE7 */
*:first-child+html .placeholder {
	margin: 0;
}
/* IE6 fix */
* html .ui-sortable-helper h3 { 
	padding: 4px;
}
* html .ui-sortable-helper img.drag_handle, * html .ui-sortable-helper img.remove_me, * html .ui-sortable-helper img.more_info {
	padding-top: 4px;
}
/* IE7 */
*:first-child+html .ui-sortable-helper h3 {
	padding: 4px;
}
*:first-child+html .ui-sortable-helper img.drag_handle, *:first-child+html .ui-sortable-helper img.remove_me, *:first-child+html .ui-sortable-helper img.more_info {
	padding-top: 4px;
}

/* ***************************************
	GENERAL FORM ELEMENTS
*************************************** */
label {
	font-weight: bold;
	color:#333333;
	font-size: 140%;
}
input {
	font: 120% Arial, Helvetica, sans-serif;
	border: solid 1px #cccccc;
	padding: 3px;
	color:#666666;
	background: #dedede;
}
textarea {
	font: 120% Arial, Helvetica, sans-serif;
	border: solid 1px #cccccc;
	padding: 3px;
	color:#666666;
	background: #dedede;
}
textarea:focus, input[type="text"]:focus {
	border: solid 1px black;
	background: white;
	color:#333333;
}
.submit_button {
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: white;
	background:#666666;
	border: none;
	-webkit-border-radius: 5px; 
	-moz-border-radius: 5px;
	width: auto;
	height: 25px;
	padding: 2px 6px 2px 6px;
	margin:10px 0 10px 0;
	cursor: pointer;
}
.submit_button:hover, input[type="submit"]:hover {
	background: black;
	color:white;
}

input[type="submit"] {
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: white;
	background:#666666;
	border:none;
	-webkit-border-radius: 5px; 
	-moz-border-radius: 5px;
	width: auto;
	height: 25px;
	padding: 2px 6px 2px 6px;
	margin:10px 0 10px 0;
	cursor: pointer;
}
.cancel_button {
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #666666;
	background:#aaaaaa;
	border:none;
	-webkit-border-radius: 5px; 
	-moz-border-radius: 5px;
	width: auto;
	height: 25px;
	padding: 2px 6px 2px 6px;
	margin:10px 0 10px 10px;
	cursor: pointer;
}
.cancel_button:hover {
	background: black;
	color: #999999;
}

.input-text,
.input-tags,
.input-url,
.input-textarea {
	width:98%;
}

.input-textarea {
	height: 200px;
}

/* ***************************************
  PAGE-OWNER BLOCK
*************************************** */
#owner_block {
	padding:10px;
}
#owner_block_icon {
	float:left;
	margin:0 10px 0 0;
}
#owner_block_rss_feed,
#owner_block_odd_feed,
#owner_block_bookmark_this,
#owner_block_report_this {
	padding:2px 0 3px 0;
}
#owner_block_rss_feed {
	margin:5px 0 0 0;
}
#owner_block_report_this {
	border-bottom:1px solid #cccccc;
}
#owner_block_rss_feed a {
	font-size: 90%;
	color:#666666;
	padding:0 0 4px 20px;
	background: url(<?php echo $vars['url']; ?>_graphics/icon_rss.gif) no-repeat left top;
}
#owner_block_odd_feed a {
	font-size: 90%;
	color:#666666;
	padding:0 0 4px 20px;
	background: url(<?php echo $vars['url']; ?>_graphics/icon_odd.gif) no-repeat left top;
}
#owner_block_bookmark_this a {
	font-size: 90%;
	color:#666666;
	padding:0 0 4px 20px;
	background: url(<?php echo $vars['url']; ?>_graphics/icon_bookmarkthis.gif) no-repeat left top;
}
#owner_block_report_this a {
	font-size: 90%;
	color:#666666;
	padding:0 0 4px 20px;
	background: url(<?php echo $vars['url']; ?>_graphics/icon_reportthis.gif) no-repeat left top;
}
#owner_block_rss_feed a:hover,
#owner_block_odd_feed a:hover,
#owner_block_bookmark_this a:hover,
#owner_block_report_this a:hover {
	color: black;
}

#owner_block_desc {
	padding:3px 0 4px 0;
	margin:0 0 0 0;
	line-height: 1.2em;
	border-bottom:1px solid #cccccc;
	color:#999999;
}
#owner_block_content {
	margin:0 0 4px 0;
	padding:3px 0 0 0;
	min-height:25px;
	font-weight: bold;
	line-height: 1em;
}
.ownerblockline {
	padding:0;
	margin:0;
	border-bottom:1px solid #cccccc;
	height:1px;
}
#owner_block_submenu {
	margin:20px 0 20px 0;
	padding: 0;
	/* border-bottom: 1px solid #cccccc; */	
	width:100%;
}

#owner_block_submenu ul {
	list-style: none;
	padding: 0;
	margin: 0;
}
#owner_block_submenu ul li.selected a {
	background: url(<?php echo $vars['url']; ?>mod/themeswitcher/themes/neutral/graphics/owner_block_menu_arrow.gif) no-repeat left 6px;
	padding-left:10px;
}
#owner_block_submenu ul li a {
	text-decoration: none;
	display: block;
	padding: 0;
	margin: 0;
	color:#333333;
	padding:4px 6px 4px 10px;
	border-top: 1px solid #cccccc;
	font-weight: bold;
	line-height: 1.1em;
}

#owner_block_submenu ul li a:hover {
	color:black;
	background: #cccccc; 
}

/* IE 6 + 7 menu arrow position fix */
* html #owner_block_submenu ul li.selected a {
	background-position: left 10px;
}
*:first-child+html #owner_block_submenu ul li.selected a {
	background-position: left 8px;
}

#owner_block_submenu .submenu_group {
	border-bottom: 1px solid #cccccc;
	margin:22px 0 0 0;
}

/* filetypes filter menu */
#owner_block_submenu .submenu_group .submenu_group_filetypes ul li a {
	color:#666666;
}
#owner_block_submenu .submenu_group .submenu_group_filetypes ul li.selected a {
	background: url(<?php echo $vars['url']; ?>mod/themeswitcher/themes/neutral/graphics/owner_block_menu_dot.gif) no-repeat left 7px;
}
#owner_block_submenu .submenu_group .submenu_group_filetypes ul li a:hover {
	color:black;
	background: #999999;
}

/* pages actions menu */
#owner_block_submenu .submenu_group .submenu_group_pagesactions ul li a {
	color:#666666;
}
#owner_block_submenu .submenu_group .submenu_group_pagesactions ul li.selected a {
	background: url(<?php echo $vars['url']; ?>mod/themeswitcher/themes/neutral/graphics/owner_block_menu_dot.gif) no-repeat left 7px;
}
#owner_block_submenu .submenu_group .submenu_group_pagesactions ul li a:hover {
	color:black;
	background: #999999;
}

/* ***************************************
	LOGIN / REGISTER
*************************************** */
#login-box {
    text-align:left;
}
#login-box form p,
#register-box form p {
	padding:10px;
}
#login-box .login-textarea {
	width:195px;
	background:#dedede;
}
#register-box .general-textarea {
	width:360px;
	background:#dedede;
}
#login-box .login-textarea:focus,
#register-box .general-textarea:focus {
	color:#333333;
	border: solid 1px black;
}
#login-box label,
#register-box label {
	font-size: 1.2em;
	color:gray;
}
#login-box p.loginbox {
	margin:10px 0 0 0;
}
#login-box input[type="text"],
#login-box input[type="password"],
#register-box input[type="text"],
#register-box input[type="password"] {
	margin:0 0 10px 0;
}

#login-box-openid {
	margin: 10px;
    text-align:left;
    padding:10px;
    background: #ffffff;
}
input.openid_login {
	font: 120% Arial, Helvetica, sans-serif;
	padding: 5px;
	border: 1px solid #cccccc;
	color:#666666;
	background: #dedede !important;
	width:195px !important;
}
input.openid_login:focus {
	border: solid 1px black;
	background: white;
	color:#333333;
}

#login-box h2,
#login-box-openid h2,
#register-box h2 {
	color: #333333;
	font-size:1.35em;
	line-height:1.2em;
	margin:0pt 0pt 5px;
	padding:5px 10px;
	border-bottom: 1px solid #cccccc;
}
#add-box h2 {
	color: #333333;
	font-size:1.35em;
	line-height:1.2em;
	margin:0pt 0pt 10px;
	padding:0px 0 5px;
	border-bottom: 1px solid #cccccc;
}
#register-box {
    text-align:left;
	-moz-border-radius-bottomleft:10px;
	-moz-border-radius-bottomright:10px;
	-moz-border-radius-topleft:10px;
	-moz-border-radius-topright:10px;
	-webkit-border-top-left-radius:10px;
	-webkit-border-top-right-radius:10px;
	-webkit-border-bottom-left-radius:10px;
	-webkit-border-bottom-right-radius:10px;
    width:400px;
    padding:0px;
    background: white;
    margin:0px 0 20px 0;
}
#persistent_login {
	padding:0 10px 0 10px;
}
#persistent_login label {
	font-size:1.0em;
	font-weight: normal;
}
#forgotten_box {
	width:600px;
	padding:0 10px 0 10px;
}
#forgotten_box .input-text {
	width:340px;
}

/* ***************************************
	SEARCH LISTINGS	
*************************************** */
.search_listing {
	display: block;
	background: #cccccc; 
	padding: 0;
	margin-bottom: 10px;
	border:1px solid #cccccc;
}

.search_listing_icon {
	float:left;
}
.search_listing_icon img {
	width: 40px;
}
.search_listing_icon .avatar_menu_button img {
	width: 15px;
}
	
.search_listing_info {
	margin-left: 50px;
	min-height: 40px;
}
.search_listing:hover {
	background:#aaaaaa;
}
/* IE 6 fix */
* html .search_listing_info {
	height:40px;
}
.search_listing_info p {
	margin:0;
	line-height:1em;
	padding:5px 0 3px 0;
}
.search_listing_info p a { 
	font-weight:bold;
}
.search_listing_info p a:hover { 
	
}
.search_listing_info p.owner_timestamp a {
	font-weight:normal;
}
.search_listing_info p.owner_timestamp {
	margin:0 0 5px 0;
	padding:0;
	font-size: 90%;
}

table.search_gallery {
	border-spacing: 6px;
}
.search_gallery td {
	padding: 5px;
}

.search_gallery_item {
	border:3px dotted #cccccc;
    background-color: #cccccc;
}
.search_gallery_item:hover {
	border:3px dotted #999999;
}

.search_gallery_item .search_listing {
	background: none;
	text-align: center;
}

.search_gallery_item .search_listing_header {
	text-align: center;
}

.search_gallery_item .search_listing_icon {
	position: relative;
	text-align: center;
}

.search_gallery_item .search_listing_info {
	margin: 5px;
}

.search_gallery_item .search_listing_info p {
	margin: 5px;
	margin-bottom: 10px;
}

.search_gallery_item .search_listing {
	background: none;
	text-align: center;
}

.search_gallery_item .search_listing_icon {
	position: absolute;
	margin-bottom: 20px;
	text-align: center;
}

.search_gallery_item .search_listing_info {
	margin: 5px;
	text-align: center;
}

.search_gallery_item .search_listing_info p {
	margin: 5px;
	margin-bottom: 10px;
}

/* ***************************************
	PAGINATION
*************************************** */
.pagination {
	margin:10px 10px 20px 0px;
}

.pagination .pagination_number {
	display:block;
	float:left;
	border:1px solid #666666; 
	text-align: center;
	color:#666666; 
	font-size: 12px;
	font-weight: normal;
	margin:0 6px 0 0;
	padding:0px 4px;
	cursor: pointer;
}
.pagination .pagination_number:hover {
	background:#aaaaaa; 
	color:black;
	text-decoration: none;
}
.pagination .pagination_more {
	display:block;
	float:left;
	border:1px solid #666666; 
	color:#666666; 
	text-align: center;
	font-size: 12px;
	font-weight: normal;
	margin:0 6px 0 0;
	padding:0px 4px;
}

.pagination .pagination_previous,
.pagination .pagination_next {
	display:block;
	float:left;
	border:1px solid #666666; 
	color:#666666; 
	text-align: center;
	font-size: 12px;
	font-weight: normal;
	margin:0 6px 0 0;
	padding:0px 4px;
	cursor: pointer;
}
.pagination .pagination_previous:hover,
.pagination .pagination_next:hover {
	background:#aaaaaa; 
	color:black;
	text-decoration: none;
}
.pagination .pagination_currentpage {
	display:block;
	float:left;
	background:#666666; 
	border:1px solid #666666; 
	text-align: center;
	color:white;
	font-size: 12px;
	font-weight: bold;
	margin:0 6px 0 0;
	padding:0px 4px;
	cursor: pointer;
}


/* ***************************************
	MISC.
*************************************** */
/* general page titles in main content area */
#content_area_user_title h2 {	
	color: #333333;
	margin:0 0 10px 0;
	padding:5px 10px 5px 0;
	font-size:1.35em;
	line-height:1.2em;
	border-bottom: 1px solid #999999;
}	
#sidebar_page_tree {
	margin:10px;
}
#sidebar_page_tree h3 {
	background:#F5F5F5;
	border-top:2px solid #333333;
	margin:0 0 5px 0;
	padding:5px;
	color:#0054A7;
	font-size:1.25em;
	line-height:1.2em;
}	



<?php
  @include_once dirname(__FILE__) . '/plugins_css.php';
?>

