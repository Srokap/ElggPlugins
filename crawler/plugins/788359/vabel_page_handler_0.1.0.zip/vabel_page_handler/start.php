<?php
/**
 * @package Vabel Page Handler
 * @author Angel Gabriel
 * @web http://angelgabriel.tk
 * @mail angel.wrt@gmail.com
 **/  

function vph_init() {
    
    //core pages
    $pages = array('login','forgotpassword','resetpassword','activity','register', 'friends', 'friendsof', 'collections', 'profile',
		   'settings');
    
    //dashboard
    if (elgg_is_active_plugin('dashboard') || elgg_is_active_plugin('deyan')) {
    $pages = array_merge($pages, array('dashboard'));
	} 
	
    //invitefriends
    if (elgg_is_active_plugin('invitefriends')) {
    $pages = array_merge($pages, array('invite'));
	}

    //notifications
    if (elgg_is_active_plugin('notifications')) {
    $pages = array_merge($pages, array('notifications'));
	}
	
    //messages
    if (elgg_is_active_plugin('messages')) {
    $pages = array_merge($pages, array('messages'));
	}
	
    //bookmarks
    if (elgg_is_active_plugin('bookmarks')) {
    $pages = array_merge($pages, array('bookmarks'));
	}
	
    //personalize (deyan shell)
    if (elgg_is_active_plugin('deyan')) {
    $pages = array_merge($pages, array('personalize'));
	}
	
    //file
    if (elgg_is_active_plugin('file')) {
    $pages = array_merge($pages, array('file'));
	}
	
    //groups
    if (elgg_is_active_plugin('groups')) {
    $pages = array_merge($pages, array('groups'));
	}
	
    //pages
    if (elgg_is_active_plugin('pages')) {
    $pages = array_merge($pages, array('pages'));
	}
	
//     //search
//     if (elgg_is_active_plugin('search')) {
//     $pages = array_merge($pages, array('search'));
// 	}
	
    //thewire
    if (elgg_is_active_plugin('thewire')) {
    $pages = array_merge($pages, array('thewire'));
	}
    
    foreach($pages as $page) {
      elgg_register_page_handler($page, 'vph_page_handler');
      elgg_register_page_handler(elgg_echo("vph:$page"), "vph_{$page}_handler");
    }
 

	
}

/*******************
General handler
*******************/
function vph_page_handler($page, $handler) {
	for($i=0; $i<=5; $i++) {
		if(isset($page[$i])) {
		      $page[$i] = "/$page[$i]";
		}
	}
	
	forward(elgg_echo("vph:$handler") . "$page[0]" . "$page[1]");
}

/*********************
 DASHBOARD (ESCRITORIO)
*********************/
function vph_dashboard_handler($page) {
	if (elgg_is_active_plugin('deyan')){
	deyan_dashboard_handler();
	}
	else {
	dashboard_page_handler();
	}
}

/**************************
 LOGIN (ACCEDER)
****************************/

function vph_login_handler($page) {
	if (elgg_is_active_plugin('deyan')){
	return deyan_login_handler();
	}
	elgg_user_login_page_handler();
}

/**************************
 forgotpassword (recuperarclave)
****************************/

function vph_forgotpassword_handler($page) {
	if (elgg_is_active_plugin('deyan')){
	return deyan_forgotpassword_handler();
	}
	elgg_user_account_page_handler($page_elements, 'forgotpassword');
}

/**************************
 register (registro)
****************************/

function vph_register_handler($page) {
	if (elgg_is_active_plugin('deyan')){
	return deyan_register_handler();
	}
	elgg_user_account_page_handler($page_elements, 'register');
}

/**************************
 resetpassword (riniciarclave)
****************************/

function vph_resetpassword_handler($page) {
	elgg_user_account_page_handler($page_elements, 'resetpassword');
}

/**************************
 activity (actividad)
****************************/

function vph_activity_handler($page) {
	elgg_river_page_handler($page);
}

/**************************
 friends (amigos)
****************************/

function vph_friends_handler($page) {
	elgg_set_context('friends');
	friends_page_handler($page);
}

/**************************
 friendsof (amigode)
****************************/

function vph_friendsof_handler($page) {
	friends_of_page_handler($page);
}

/**************************
 collections (circulos)
****************************/

function vph_collections_handler($page) {
	collections_page_handler($page);
}

/**************************
 profile (perfil)
****************************/

function vph_profile_handler($page) {
	if(isset($page[1])) {
	elgg_profile_page_handler($page);
	}
	elseif(elgg_is_active_plugin('profile')) {
	profile_page_handler($page);
	}
	
}

/*********************
 invite (invitar)
*********************/
function vph_invite_handler($page) {
	invitefriends_page_handler($page);
}

/*********************
 SETTINGS (AJUSTES)
*********************/
function vph_settings_handler($page) {
	elgg_set_context('settings');
	usersettings_page_handler($page);
}

/*********************
 notifications (notificaciones)
*********************/
function vph_notifications_handler($page) {
	notifications_page_handler($page);
}

/*********************
 messages (mensajes)
*********************/
function vph_messages_handler($page) {
	messages_page_handler($page);
}

/*********************
 bookmarks (marcadores)
*********************/
function vph_bookmarks_handler($page) {
	bookmarks_page_handler($page);
}

/*********************
 personalize (personalizar)
*********************/
function vph_personalize_handler($page) {
	elgg_set_context('personalize');
	deyan_personalize_handler($page);
}

/*********************
 file (carpeta)
*********************/
function vph_file_handler($page) {
	file_page_handler($page);
}

/*********************
 groups (comunidades)
*********************/
function vph_groups_handler($page) {
	elgg_set_context('groups');
	groups_page_handler($page);
}

/*********************
 pages (paginas)
*********************/
function vph_pages_handler($page) {
	pages_page_handler($page);
}

// /*********************
//  search (buscar)
// *********************/
// function vph_search_handler($page) {
// 	search_page_handler($page);
// }

/*********************
 thewire (estados)
*********************/
function vph_thewire_handler($page) {
	thewire_page_handler($page);
}

elgg_register_event_handler('init', 'system', 'vph_init');

?>