<?php

$spanish = array(

		// Core pages
		'vph:login' => 				'acceder',
		'vph:forgotpassword' => 		'recuperarclave',
		'vph:register' => 			'registro',
		'vph:resetpassword' => 			'reiniciarclave',
		'vph:activity' => 			'actividad',
		'vph:friends' => 			'amigos',
		'vph:friendsof' => 			'amigode',
		'vph:collections' => 			'circulos',
		'vph:profile' => 			'perfil',
		'vph:settings' => 			'ajustes',

		//Plugins
		'vph:dashboard' => 			'escritorio',
		'vph:invite' => 			'invitar',
		'vph:notifications' => 			'notificaciones',
		'vph:messages' => 			'mensajes',
		'vph:bookmarks' => 			'marcadores',
		'vph:personalize' => 			'personalizar',
		'vph:file' => 				'carpeta',
		'vph:groups' => 			'comunidades',
		'vph:pages' => 				'paginas',
		//'vph:search' => 			'buscar',
		'vph:thewire' => 			'estados',
		
		
		
		);
		
add_translation('es', $spanish);
