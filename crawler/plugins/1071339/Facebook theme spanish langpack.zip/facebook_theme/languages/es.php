<?php
add_translation('es', array(
	'annotation:group_topic_post:value:placeholder' => 'Responder...',
	'annotation:generic_comment:value:placeholder' => 'Comentar...',
	
	'composer:object:thewire' => "Estado",
	'composer:object:bookmarks' => "Marcadores",
	'composer:object:blog' => "Blog",
	'composer:annotation:messageboard' => "Post",
	'composer:object:file' => 'Archivo',
	'composer:prompt' => 'Compartir',

	'file:river:create' => 'ha subido un archivo',
	'files' => 'Files',
	
	'friend:user:add' => "A�adir a %s como amigo",
	
	'groups:add' => 'Crear un grupo...',
	
	'home' => 'Inicio',
	
	'newsfeed' => 'Noticias',
	
	'profile:wall' => "Muro",
	'profile:info' => "Info",
	'profile:activity:none' => "No hay actividad para mostrar",
	
	'likes:likethis' => 'Me gusta',
	'likes:remove' => 'Ya no me gusta',
	
	'notifications:personal' => "Notificaciones",
	
	'pages:river:create' => 'ha creado una p&aacute;gina',

	'river:comment:object:thewire' => '',
	'river:comments:all' => 'Ver todos los comentarios de %d',
	'river:messageboard:group:default' => '',
	'river:replies:all' => 'Ver todas las respuestas de %d',
	'river:to' => '%s &#x25B6 %s',
	
	'rss:subscribe' => 'Suscribirse via RSS',

	'see:all' => 'Ver todo',
	
	'settings:user' => 'Configuraci&oacute;n de la cuenta',
));
