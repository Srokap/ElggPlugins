<?php

	/**
	 * Elgg ElggLoic plugin
	 *
	 * @package ElggLoic
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author psy
	 * @copyright Lorea 2011
	 */

	// Get the Elgg engine
		require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
		
		$body = elgg_view('loic');
		$title = elgg_echo("elggloic");
		page_draw($title, $body);
		
?>
