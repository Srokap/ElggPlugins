<?php

	/**
	 * Elgg Loic plugin
	 *
	 * @package ElggLoic
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author psy
	 * @copyright Lorea.org 2011
	 */

	/**
	 * Elgg Loic init function
	 *
	 */
		function elggloic_init() {

				global $CONFIG;

			 register_page_handler('elggloic','elggloic_page_handler');
	                
			 if (isloggedin())        {
			
				add_menu(elgg_echo('elggloic'), $CONFIG->wwwroot . "pg/elggloic/");
			 }	
				}

					function elggloic_page_handler($page)
						{
							global $CONFIG;
							switch ($page[0])
							{
								default:
									include $CONFIG->pluginspath . 'loic/index.php';
									break;	
							}
							exit;
						}
				
		register_elgg_event_handler('init', 'system', 'elggloic_init');
?>
