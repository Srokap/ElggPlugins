<?php
	/**
	 * Elgg Loic plugin
	 *
	 * @package ElggLoic
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author psy
	 * @copyright Lorea.org 2011
	 */

	$spanish = array(

		'elggloic' => "LOIC",
	);

	add_translation("es",$spanish);
