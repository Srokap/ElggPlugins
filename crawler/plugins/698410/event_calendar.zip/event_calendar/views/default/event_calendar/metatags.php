<link rel="stylesheet" href="<?php echo $vars['url']; ?>mod/event_calendar/datepicker.css" type="text/css" media="screen" title="Flora (Default)">
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/event_calendar/ui.datepicker.js"></script>
