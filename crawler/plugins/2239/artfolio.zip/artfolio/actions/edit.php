<?php

	/**
	 * Elgg artfolio: edit project action
	 * 
	 * @package Artfolio
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Frederqiue Hermans
	 * @copyright ANN-Designs 2008
	 * @link www.frederiquehermans.be
	 */

	// Make sure we're logged in (send us to the front page if not)
		if (!isloggedin()) forward();

	// Get input data
		$guid = (int) get_input('artfoliopost');
		$title = get_input('artfoliotitle');
		$body = get_input('artfoliobody');
		$access = get_input('access_id');
		$tags = get_input('artfoliotags');
		
	// Make sure we actually have permission to edit
		$artfolio = get_entity($guid);
		if ($artfolio->getSubtype() == "artfolio" && $artfolio->canEdit()) {
	
		// Cache to the session
			$_SESSION['artfoliotitle'] = $title;
			$_SESSION['artfoliobody'] = $body;
			$_SESSION['artfoliotags'] = $tags;
			
		// Convert string of tags into a preformatted array
			$tagarray = string_to_tag_array($tags);
			
		// Make sure the title / description aren't blank
			if (empty($title) || empty($body)) {
				register_error(elgg_echo("artfolio:blank"));
				forward("mod/artfolio/add.php");
				
		// Otherwise, save the artfolio post 
			} else {
				
		// Get owning user
				$owner = get_entity($artfolio->getOwner());
		// For now, set its access to public (we'll add an access dropdown shortly)
				$artfolio->access_id = $access;
		// Set its title and description appropriately
				$artfolio->title = $title;
				$artfolio->description = $body;
		// Before we can set metadata, we need to save the artfolio post
				if (!$artfolio->save()) {
					register_error(elgg_echo("artfolio:error"));
					forward("mod/artfolio/edit.php?artfoliopost=" . $guid);
				}
		// Now let's add tags. We can pass an array directly to the object property! Easy.
				$artfolio->clearMetadata('tags');
				if (is_array($tagarray)) {
					$artfolio->tags = $tagarray;
				}
		// Success message
				system_message(elgg_echo("artfolio:posted"));
		// Remove the artfolio post cache
				unset($_SESSION['artfoliotitle']); unset($_SESSION['artfoliobody']); unset($_SESSION['artfoliotags']);
		// Forward to the main artfolio page
				//forward("mod/artfolio/?username=" . $owner->username);
				forward($artfolio->getURL());
			}
		
		}
		
?>