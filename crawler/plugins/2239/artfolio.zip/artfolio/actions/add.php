<?php

	/**
	 * Elgg artfolio: add project action
	 * 
	 * @package Artfolio
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Frederqiue Hermans
	 * @copyright ANN-Designs 2008
	 * @link www.frederiquehermans.be
	 */

	// Make sure we're logged in (send us to the front page if not)
		if (!isloggedin()) forward();

	// Get input data
		$title = get_input('artfoliotitle');
		$body = get_input('artfoliobody');
		$tags = get_input('artfoliotags');
		$access = get_input('access_id');

	// Cache to the session
		$_SESSION['artfoliotitle'] = $title;
		$_SESSION['artfoliobody'] = $body;
		$_SESSION['artfoliotags'] = $tags;
		
	// Convert string of tags into a preformatted array
		$tagarray = string_to_tag_array($tags);
		
	// Make sure the title / description aren't blank
		if (empty($title) || empty($body)) {
			register_error(elgg_echo("artfolio:blank"));
			forward("mod/artfolio/add.php");
			
	// Make sure image is not to big, is the right filetype and is an uploaded file
		} else {
		if ($_FILES['upload']['size'] > 1048576) {
			register_error(elgg_echo("artfolio:tobig"));
			forward("mod/artfolio/add.php");
		
		 } else {
		if ( $_FILES['upload']['type'] != 'image/jpeg' and $_FILES['upload']['type'] != 'image/pjpeg') {
			register_error(elgg_echo("artfolio:notjpg"));
			forward("mod/artfolio/add.php");
			
	// Otherwise, save the artfolio post 
		} else {
	
	/** lets deal with creating the post
	------------------------------------------------------------
	*/
			
	// Initialise a new ElggObject
			$artfolio = new ElggObject();
			
	// Tell the system it's a artfolio post
	
			$artfolio->subtype = "artfolio";
	// Set its owner to the current user
	
			$artfolio->owner_guid = $_SESSION['user']->getGUID();
	// Set its access_id
			$artfolio->access_id = $access;
			
	// Set its title and description appropriately
			$artfolio->title = $title;
			$artfolio->description = $body;
			
	// Before we can set metadata, we need to save the artfolio post
			if (!$artfolio->save()) {
				register_error(elgg_echo("artfolio:error"));
				forward("mod/artfolio/add.php");
			}
			
	// Now let's add tags
			if (is_array($tagarray)) {
				$artfolio->tags = $tagarray;
			}
			
	/** Now lets deal with our uploaded image
	------------------------------------------------------------
	*/
	
	// Create a user artfoliofolder based on GUID, if it doen't have one
			if (!is_dir( $CONFIG->path . '/artfolio/' . $_SESSION['user']->getGUID())){
					mkdir($CONFIG->path . '/artfolio/' . $_SESSION['user']->getGUID(), 0777, true);
			}
	
	// Create a unique but logical filename based on title and time
			$filename = strtolower($title);
			$filename = str_replace(' ', '_', $filename);
			$filename = preg_replace('/[^a-z0-9_]/i', '', $filename);
			$filename = $filename . '_' . md5(uniqid(mt_rand()));
			
	// Copy the uploaded image to the user folder
			copy($_FILES['upload']['tmp_name'], $CONFIG->path . '/artfolio/' . $_SESSION['user']->getGUID() . '/' . $filename . '.jpg');
	
	// Adding the filelocation to the artfolio post
			$artfolio->annotate('artfoliolocation', 'artfolio/' . $_SESSION['user']->getGUID() . '/' . $filename, $access, $_SESSION['user']->getGUID(), "string");
	
	// Create a small thumbnail	
			$img = $CONFIG->path . '/artfolio/' . $_SESSION['user']->getGUID() . '/' . $filename . '.jpg';
		
			$canvas_width  = 60;
			$canvas_height = 60;
			
			$canvas = imagecreatetruecolor($canvas_width, $canvas_height);
			
			list($img_width, $img_height) = getimagesize($img);
			
			$original = imagecreatefromjpeg($img);
			
			if ($img_width >= 460 or $img_height >= 460){
			
					imagecopyresampled($canvas, $original, 0, 0, 
					                 (($img_width / 2 ) - ( ($canvas_width / 2) * 4 ) ),
													 (($img_height / 2 ) - ( ($canvas_height / 2) * 4 ) ),
													 $img_width / 4,
													 $img_height / 4,
													 $img_width,
													 $img_height
													 );								 
					} else {
					
					imagecopyresampled($canvas, $original, 0, 0, 
					                 (($img_width / 2 ) - ($canvas_width / 2) ),
													 (($img_height / 2 ) - ($canvas_height / 2) ),
													 $img_width,
													 $img_height,
													 $img_width,
													 $img_height
													 );		
					}
			
			imagejpeg($canvas, $CONFIG->path . '/artfolio/' . $_SESSION['user']->getGUID() . '/' . $filename . '_thumbsmall.jpg', 100);
			
	// Create a large thumbnail	
			$canvas_width  = 153;
			$canvas_height = 153;
			
			$canvaslarge = imagecreatetruecolor($canvas_width, $canvas_height);
			
			if ($img_width >= 460 or $img_height >= 460){
			
					imagecopyresampled($canvaslarge, $original, 0, 0, 
					                 (($img_width / 2 ) - ( ($canvas_width / 2) * 3 ) ),
													 (($img_height / 2 ) - ( ($canvas_height / 2) * 3 ) ),
													 $img_width / 3,
													 $img_height / 3,
													 $img_width,
													 $img_height
													 );								 
					} else {
					
					imagecopyresampled($canvaslarge, $original, 0, 0, 
					                 (($img_width / 2 ) - ($canvas_width / 2) ),
													 (($img_height / 2 ) - ($canvas_height / 2) ),
													 $img_width,
													 $img_height,
													 $img_width,
													 $img_height
													 );		
					}
			
			imagejpeg($canvaslarge, $CONFIG->path . '/artfolio/' . $_SESSION['user']->getGUID() . '/' . $filename . '_thumblarge.jpg', 100);
			
	// Create an image of smaller resolution for webviewing, if needed	
			
			$canvas_width  = 1000;
			$canvas_height = 600;
			
			if ($img_width > $canvas_width or $img_height > $canvas_height){
			
					$ratio_orig = $img_width / $img_height;
		
					if ($canvas_width / $canvas_height > $ratio_orig){
		  					$canvas_width = $canvas_height * $ratio_orig;	
						} else {
							$canvas_height = $canvas_width / $ratio_orig;
						}
			
					$canvasfull = imagecreatetruecolor($canvas_width, $canvas_height);
		
     				imagecopyresampled($canvasfull, $original, 0, 0, 0, 0, $canvas_width, $canvas_height, $img_width, $img_height);
			
					imagejpeg($canvasfull, $CONFIG->path . '/artfolio/' . $_SESSION['user']->getGUID() . '/' . $filename . '_full.jpg', 80);
				} else {
					copy($img, $CONFIG->path . '/artfolio/' . $_SESSION['user']->getGUID() . '/' . $filename . '_full.jpg');
				}
	// Delete the original image	
			unlink($img);
	
	// Start with an empty rating system
			$artfolio->annotate('artfoliorating', 0.00, $access, $_SESSION['user']->getGUID(), "integer");
			$artfolio->annotate('artfolionumvotes', 0, $access, $_SESSION['user']->getGUID(), "integer");
	
	// Success message
			system_message(elgg_echo("artfolio:posted"));
			
	// Remove the artfolio post cache
			unset($_SESSION['artfoliotitle']); unset($_SESSION['artfoliobody']); unset($_SESSION['artfoliotags']);
			
	// Forward to the main artfolio page
			//forward("mod/artfolio/?username=" . $owner->username);
			forward($artfolio->getURL());
		}
	  }
	}
		
?>