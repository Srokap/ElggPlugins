<?php

// http://tecnoparquesena.peesco.com/action/artfolio/deleteimg?artfoliopost=235&artfolioimg=58
	/**
	 * Elgg artfolio: delete project action
	 * 
	 * @package Artfolio
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Frederqiue Hermans
	 * @copyright ANN-Designs 2008
	 * @link www.frederiquehermans.be
	 */

	// Make sure we're logged in (send us to the front page if not)
		if (!isloggedin()) forward();

	// Get input data
		$guid = (int) get_input('artfoliopost');
		$img = (int) get_input('artfolioimg');
		
	// Make sure we actually have permission to edit
		$artfolio = get_entity($guid);
		if ($artfolio->getSubtype() == "artfolio" && $artfolio->canEdit()) {
	
		// Get owning user
				$owner = get_entity($artfolio->getOwner());
				

				$annotations = $artfolio->getAnnotations('artfoliolocation');

				foreach ($annotations as $annotation){

					$annotation_id = $annotation['id'];

					if ($annotation_id == $img) {

						unlink($_SERVER['DOCUMENT_ROOT'] . '/' . $annotation['value'] . '_thumbsmall.jpg');
						unlink($_SERVER['DOCUMENT_ROOT'] . '/' . $annotation['value'] . '_thumblarge.jpg');
						unlink($_SERVER['DOCUMENT_ROOT'] . '/' . $annotation['value'] . '_full.jpg');

						// Delete the annotations
						$object = get_annotation($annotation_id);
						$object->delete();

						system_message(elgg_echo("artfolio:deleted"));

					}
				}


		}
	forward($artfolio->getURL());
?>