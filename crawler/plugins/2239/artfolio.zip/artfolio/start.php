<?php

	/**
	 * Elgg artfolio plugin
	 * 
	 * @package Artfolio
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Frederqiue Hermans
	 * @copyright ANN-Designs 2008
	 * @link www.frederiquehermans.be
	 */

	/**
	 * artfolio initialisation
	 *
	 * These parameters are required for the event API, but we won't use them:
	 * 
	 * @param unknown_type $event
	 * @param unknown_type $object_type
	 * @param unknown_type $object
	 */

		function artfolio_init() {
			
			// Load system configuration
				global $CONFIG;
				
			// Load the language file
				register_translations($CONFIG->pluginspath . "artfolio/languages/");
				
			// Set up menu for logged in users
				if (isloggedin()) {
    				
					add_menu(elgg_echo('artfolios'), $CONFIG->wwwroot . "pg/artfolio/" . $_SESSION['user']->username);
					
			// And for logged out users
				} else {
					add_menu(elgg_echo('artfolio'), $CONFIG->wwwroot . "mod/artfolio/everyone.php",array(
					));
				}
				
			// Extend system CSS with our own styles, which are defined in the artfolio/css view
				extend_view('css','artfolio/css');
				
			// Extend hover-over menu	
				extend_view('profile/menu/links','artfolio/menu');
			
			// Add a new widget
				add_widget_type('artfolio',elgg_echo("artfolio:widget"),elgg_echo("artfolio:widget:description"));
				
			// Register a page handler, so we can have nice URLs
				register_page_handler('artfolio','artfolio_page_handler');
				
			// Register a URL handler for artfolio posts
				register_entity_url_handler('artfolio_url','object','artfolio');
				
			// Register this plugin's object for sending pingbacks
				register_plugin_hook('pingback:object:subtypes', 'object', 'artfolio_pingback_subtypes');
				
			// Listen for new pingbacks
				register_elgg_event_handler('create', 'object', 'artfolio_incoming_ping');
				
			// Register entity type
				register_entity_type('object','artfolio');
		}
		
		function artfolio_pagesetup() {
			
			global $CONFIG;

			//add submenu options
				if (get_context() == "artfolio") {
					if ((page_owner() == $_SESSION['guid'] || !page_owner()) && isloggedin()) {
						add_submenu_item(elgg_echo('artfolio:your'),$CONFIG->wwwroot."pg/artfolio/" . $_SESSION['user']->username);
						add_submenu_item(elgg_echo('artfolio:friends'),$CONFIG->wwwroot."pg/artfolio/" . $_SESSION['user']->username . "/friends/");
						add_submenu_item(elgg_echo('artfolio:everyone'),$CONFIG->wwwroot."mod/artfolio/everyone.php");
						add_submenu_item(elgg_echo('artfolio:addpost'),$CONFIG->wwwroot."mod/artfolio/add.php");
					} else if (page_owner()) {
						$page_owner = page_owner_entity();
						add_submenu_item(sprintf(elgg_echo('artfolio:user'),$page_owner->name),$CONFIG->wwwroot."pg/artfolio/" . $page_owner->username);
						if ($page_owner instanceof ElggUser) // Sorry groups, this isn't for you.
							add_submenu_item(sprintf(elgg_echo('artfolio:user:friends'),$page_owner->name),$CONFIG->wwwroot."pg/artfolio/" . $page_owner->username . "/friends/");
						add_submenu_item(elgg_echo('artfolio:everyone'),$CONFIG->wwwroot."mod/artfolio/everyone.php");
					} else {
						add_submenu_item(elgg_echo('artfolio:everyone'),$CONFIG->wwwroot."mod/artfolio/everyone.php");
					}
				}
			
		}
		
		/**
		 * artfolio page handler; allows the use of fancy URLs
		 *
		 * @param array $page From the page_handler function
		 * @return true|false Depending on success
		 */
		function artfolio_page_handler($page) {
			
			// The first component of a artfolio URL is the username
			if (isset($page[0])) {
				set_input('username',$page[0]);
			}
			
			// The second part dictates what we're doing
			if (isset($page[1])) {
				switch($page[1]) {
					case "read":		set_input('artfoliopost',$page[2]);
										@include(dirname(__FILE__) . "/read.php");
										break;
					case "friends":		@include(dirname(__FILE__) . "/friends.php");
										break;
				}
			// If the URL is just 'artfolio/username', or just 'artfolio/', load the standard artfolio index
			} else {
				@include(dirname(__FILE__) . "/index.php");
				return true;
			}
			
			return false;
			
		}

		/**
		 * Populates the ->getUrl() method for artfolio objects
		 *
		 * @param ElggEntity $artfoliopost artfolio post entity
		 * @return string artfolio post URL
		 */
		function artfolio_url($artfoliopost) {
			
			global $CONFIG;
			$title = $artfoliopost->title;
			$title = friendly_title($title);
			return $CONFIG->url . "pg/artfolio/" . $artfoliopost->getOwnerEntity()->username . "/read/" . $artfoliopost->getGUID() . "/" . $title;
			
		}
		
		/**
		 * This function adds 'artfolio' to the list of objects which will be looked for pingback urls.
		 *
		 * @param unknown_type $hook
		 * @param unknown_type $entity_type
		 * @param unknown_type $returnvalue
		 * @param unknown_type $params
		 * @return unknown
		 */
		function artfolio_pingback_subtypes($hook, $entity_type, $returnvalue, $params)
		{
			$returnvalue[] = 'artfolio';
			
			return $returnvalue;
		}
		
		/**
		 * Listen to incoming pings, this parses an incoming target url - sees if its for me, and then
		 * either passes it back or prevents it from being created and attaches it as an annotation to a given
		 *
		 * @param unknown_type $event
		 * @param unknown_type $object_type
		 * @param unknown_type $object
		 */
		function artfolio_incoming_ping($event, $object_type, $object)
		{
			// TODO: Get incoming ping object, see if its a ping on a artfolio and if so attach it as a comment
		}
		
	// Make sure the artfolio initialisation function is called on initialisation
		register_elgg_event_handler('init','system','artfolio_init');
		register_elgg_event_handler('pagesetup','system','artfolio_pagesetup');
		
	// Register actions
		global $CONFIG;
		register_action("artfolio/add",false,$CONFIG->pluginspath . "artfolio/actions/add.php");
		register_action("artfolio/edit",false,$CONFIG->pluginspath . "artfolio/actions/edit.php");
		register_action("artfolio/delete",false,$CONFIG->pluginspath . "artfolio/actions/delete.php");
		register_action("artfolio/upload",false,$CONFIG->pluginspath . "artfolio/actions/upload.php");
		register_action("artfolio/rate",false,$CONFIG->pluginspath . "artfolio/actions/rate.php");
		register_action("artfolio/deleteimg",false,$CONFIG->pluginspath . "artfolio/actions/deleteimg.php");
		
?>