<?php

	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'artfolio' => "Artfolio",
			'artfolios' => "Artfolios",
			'artfolio:user' => "%s's artfolio",
			'artfolio:user:friends' => "%s's friends' artfolio",
			'artfolio:your' => "Your artfolio",
			'artfolio:posttitle' => "%s's artfolio: %s",
			'artfolio:friends' => "Friends' artfolios",
			'artfolio:yourfriends' => "Your friends' latest artfolios",
			'artfolio:everyone' => "All site artfolios",
	
			'artfolio:read' => "Read artfolio",
	
			'artfolio:addpost' => "Write a artfolio post",
			'artfolio:editpost' => "Edit artfolio post",
			'artfolio:upload' => "Upload extra images to artfolio post",
	
			'artfolio:text' => "Artfolio text",
			'artfolio:uploadimages' => "Upload image",
			'artfolio:imagelimitation' => "Must be jpg, smaller than 1MB",
			'artfolio:imagelater' => "(More images can be added later by pressing 'upload')",
	
			'artfolio:strapline' => "%s",
			
			'item:object:artfolio' => 'artfolio posts',
	
		 /**
	     * artfolio rating system
	     **/
			'artfolio:rate' => "Vote",
			'artfolio:votes' => "votes",
			
			'artfolio:rate0' => "Auch!",
			'artfolio:rate1' => "Disappointing",
			'artfolio:rate2' => "Needs some work",
			'artfolio:rate3' => "Good",
			'artfolio:rate4' => "Very good",
			'artfolio:rate5' => "Brilliant!",
			
			'artfolio:ratesucces' => "Your rating has been succesfully saved.",
		
		/**
	     * artfolio widget
	     **/
			'artfolio:widget' => "Artfolio widget",
			'artfolio:widget:description' => "Showcase your latest artfolios",
			'artfolio:widget:viewall' => "View all my artfolios",
			'artfolio:num_display' => "Number of artfolios to display",
			'artfolio:icon_size' => "Icon size",
			'artfolio:small' => "small",
			'artfolio:tiny' => "tiny",
		
         /**
	     * artfolio river
	     **/
	        
	        //generic terms to use
	        'artfolio:river:created' => "%s wrote",
	        'artfolio:river:updated' => "%s updated",
	        'artfolio:river:posted' => "%s posted",
	        
	        //these get inserted into the river links to take the user to the entity
	        'artfolio:river:create' => "a new artfolio post.",
	        'artfolio:river:update' => "a artfolio post.",
	        'artfolio:river:annotate:create' => "a comment on a artfolio post.",
			
	
		/**
		 * Status messages
		 */
	
			'artfolio:posted' => "Your artfolio post was successfully posted.",
			'artfolio:deleted' => "Your artfolio post was successfully deleted.",
			'artfolio:uploaded' => "Your image was succesfully added.",
	
		/**
		 * Error messages
		 */
	
			'artfolio:save:failure' => "Your artfolio post could not be saved. Please try again.",
			'artfolio:blank' => "Sorry; you need to fill in both the title and body before you can make a post.",
			'artfolio:tobig' => "Sorry; your file is bigger then 1MB, please upload a smaller file.",
			'artfolio:notjpg' => "Please make sure you inculed a .jpg file.",
			'artfolio:notuploaded' => "Sorry; your file doesn't apear to be uploaded.",
			'artfolio:notfound' => "Sorry; we could not find the specified artfolio post.",
			'artfolio:notdeleted' => "Sorry; we could not delete this artfolio post.",
	
	);
					
	add_translation("en",$english);

?>