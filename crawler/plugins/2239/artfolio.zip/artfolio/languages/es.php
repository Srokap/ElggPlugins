<?php

	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'artfolio' => "Galería",
			'artfolios' => "Galerías",
			'artfolio:user' => " Galería de %s",
			'artfolio:user:friends' => " Las galerías de los amigos de %s",
			'artfolio:your' => "Tú Galería",
			'artfolio:posttitle' => "%s de Galería: %s",
			'artfolio:friends' => "Galerías de amigos",
			'artfolio:yourfriends' => " Últimas galerías de tus amigos",
			'artfolio:everyone' => "Todas las galerías del sitio",
	
			'artfolio:read' => "Ver la galería",
	
			'artfolio:addpost' => "Crear nueva galería",
			'artfolio:editpost' => "Editar el aporte de la galería",
			'artfolio:upload' => "Subir imágenes adicionales a la galería.",
	
			'artfolio:text' => "Descripción de la galería",
			'artfolio:uploadimages' => "Subir imagenes",
			'artfolio:imagelimitation' => " Las imágenes deben ser jpg con tamaño inferior a un mega",
			'artfolio:imagelater' => "(Se puede agregar más imágenes dando clic en examinar)",
	
			'artfolio:strapline' => "%s",
			
			'item:object:artfolio' => 'Comentarios',
	
		 /**
	     * artfolio rating system
	     **/
			'artfolio:rate' => "Voto",
			'artfolio:votes' => "votos",
			
			'artfolio:rate0' => "0",
			'artfolio:rate1' => "1",
			'artfolio:rate2' => "2",
			'artfolio:rate3' => "3",
			'artfolio:rate4' => "4",
			'artfolio:rate5' => "5",
			
			'artfolio:ratesucces' => "Su valoración de agregado con éxito.",
		
		/**
	     * artfolio widget
	     **/
			'artfolio:widget' => "Artfolio widget",
			'artfolio:widget:description' => "Showcase your latest artfolios",
			'artfolio:widget:viewall' => "View all my artfolios",
			'artfolio:num_display' => "Number of artfolios to display",
			'artfolio:icon_size' => "Icon size",
			'artfolio:small' => "small",
			'artfolio:tiny' => "tiny",
		
         /**
	     * artfolio river
	     **/
	        
	        //generic terms to use
	        'artfolio:river:created' => "%s wrote",
	        'artfolio:river:updated' => "%s updated",
	        'artfolio:river:posted' => "%s posted",
	        
	        //these get inserted into the river links to take the user to the entity
	        'artfolio:river:create' => "a new artfolio post.",
	        'artfolio:river:update' => "a artfolio post.",
	        'artfolio:river:annotate:create' => "a comment on a artfolio post.",
			
	
		/**
		 * Status messages
		 */
	
			'artfolio:posted' => "Your artfolio post was successfully posted.",
			'artfolio:deleted' => "Your artfolio post was successfully deleted.",
			'artfolio:uploaded' => "Your image was succesfully added.",
	
		/**
		 * Error messages
		 */
	
			'artfolio:save:failure' => "Your artfolio post could not be saved. Please try again.",
			'artfolio:blank' => "Sorry; you need to fill in both the title and body before you can make a post.",
			'artfolio:tobig' => "Sorry; your file is bigger then 1MB, please upload a smaller file.",
			'artfolio:notjpg' => "Please make sure you inculed a .jpg file.",
			'artfolio:notuploaded' => "Sorry; your file doesn't apear to be uploaded.",
			'artfolio:notfound' => "Sorry; we could not find the specified artfolio post.",
			'artfolio:notdeleted' => "Sorry; we could not delete this artfolio post.",
	
	);
					
	add_translation("en",$english);

?>