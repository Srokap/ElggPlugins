<?php

    /**
	 * Elgg artfolio widget
	 * 
	 * @package Artfolio
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Frederqiue Hermans
	 * @copyright ANN-Designs 2008
	 * @link www.frederiquehermans.be
	 */

	//the page owner
	$owner = get_user($vars['entity']->owner_guid);

    //the number of files to display
	$num = (int) $vars['entity']->num_display;
	if (!$num)
		$num = 8;
		
	//get the correct size
	$size = (int) $vars['entity']->icon_size;
		
    // Get the users friends
	$artfolios = get_user_objects($vars['entity']->owner_guid, "artfolio", $num, 0);
		
	// display the posts, if there are any
	if (is_array($artfolios) && sizeof($artfolios) > 0) {

		echo "<div id=\"artfolio_widget_list\">";
		
		if (!$size || $size == 1){
			foreach($artfolios as $artfolio) {
				// Images and links
				$annotations = $artfolio->getAnnotations('artfoliolocation', 1);
				foreach ($annotations as $annotation){
					echo ("<div class=\"artfolio-smallthumb\"><a href=\"" . $artfolio->getURL() . "\"><img src=\"" . $CONFIG->wwwroot . $annotation['value'] . '_thumbsmall.jpg' . "\"/></a></div>");
				}
				$rates = $artfolio->getAnnotations('artfoliorating',1);
				foreach ($rates as $rate){
						$overallrating = $overallrating + $rate['value'];
						$numprojects = $numprojects + 1;
				}
			}
		}else{
    		foreach($artfolios as $artfolio) {
				// Images and links
				$annotations = $artfolio->getAnnotations('artfoliolocation', 1);
				foreach ($annotations as $annotation){
					echo ("<div class=\"artfolio-tinythumb\"><a href=\"" . $artfolio->getURL() . "\"><img src=\"" . $CONFIG->wwwroot . $annotation['value'] . '_thumbsmall.jpg' . "\" width=\"25\" height=\"25\" /></a></div>");
				}
				$rates = $artfolio->getAnnotations('artfoliorating',1);
				foreach ($rates as $rate){
						$overallrating = $overallrating + $rate['value'];
						$numprojects = $numprojects + 1;
				}
			}
		}
		echo "<div class=\"clearfloat\"></div>";
		
		// Match rating to image
			$article_rating = $overallrating / $numprojects;
		
			if((($article_rating >= 0)or($article_rating == 0)) && ($article_rating <= 0.50)){
				$rating_image = "rate00.gif";
				}
			if((($article_rating >= 0.50)or($article_rating == 0.50)) && ($article_rating <= .99)){
				$rating_image = "rate05.gif";
				}
			if((($article_rating >= 1.00)or($article_rating == 1.50)) && ($article_rating <= 1.49)){
				$rating_image = "rate10.gif";
				}
			if((($article_rating >= 1.50)or($article_rating == 1.50)) && ($article_rating <= 1.99)){
				$rating_image = "rate15.gif";
				}
			if((($article_rating >= 2.00)or($article_rating == 2.00)) && ($article_rating <= 2.49)){
				$rating_image = "rate20.gif";
				}
			if((($article_rating >= 2.50)or($article_rating == 2.50)) && ($article_rating <= 2.99)){
				$rating_image = "rate25.gif";
				}
			if((($article_rating >= 3.00)or($article_rating == 3.00)) && ($article_rating <= 3.49)){
				$rating_image = "rate30.gif";
				}
			if((($article_rating >= 3.50)or($article_rating == 3.50)) && ($article_rating <= 3.99)){
				$rating_image = "rate35.gif";
				}
			if((($article_rating >= 4.00)or($article_rating == 4.00)) && ($article_rating <= 4.49)){
				$rating_image = "rate40.gif";
				}
			if((($article_rating >= 4.50)or($article_rating == 4.50)) && ($article_rating <= 4.99)){
				$rating_image = "rate45.gif";
				}
			if($article_rating == 5.0){
				$rating_image = "rate50.gif";
				}		
		echo "<div class=\"artfolio_gallery_rating\"><img src=\"" . $CONFIG->wwwroot . "mod/artfolio/images/" . $rating_image . "\"/><BR><a href=\"" . $CONFIG->wwwroot . "pg/artfolio/" . $owner->username . "&search_viewtype=gallery\">" . elgg_echo("artfolio:widget:viewall") . "</a></div>";
		echo "</div>";
			
    }
	
?>