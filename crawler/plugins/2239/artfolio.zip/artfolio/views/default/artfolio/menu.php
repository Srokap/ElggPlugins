<?php

	/**
	 * Elgg hoverover extender for artfolio
	 * 
	 * @package Artfolio
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Frederqiue Hermans
	 * @copyright ANN-Designs 2008
	 * @link www.frederiquehermans.be
	 */

?>

	<p class="user_menu_artfolio">
		<a href="<?php echo $vars['url']; ?>pg/artfolio/<?php echo $vars['entity']->username; ?>"><?php echo elgg_echo("artfolio"); ?></a>	
	</p>