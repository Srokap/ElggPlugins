<?php

	/**
	 * Elgg artfolio edit/add page
	 * 
	 * @package Artfolio
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Frederqiue Hermans
	 * @copyright ANN-Designs 2008
	 * @link www.frederiquehermans.be
	 * 
	 * @uses $vars['object'] Optionally, the artfolio post to edit
	 */

	// Set title, form destination
		if (isset($vars['entity'])) {
			$title = sprintf(elgg_echo("artfolio:editpost"),$object->title);
			$action = "artfolio/edit";
			$title = $vars['entity']->title;
			$body = $vars['entity']->description;
			$tags = $vars['entity']->tags;
			$access_id = $vars['entity']->access_id;
		} else  {
			$title = elgg_echo("artfolio:addpost");
			$action = "artfolio/add";
			$tags = "";
			$title = "";
			$description = "";
			$access_id = 0;
		}

	// Just in case we have some cached details
		if (isset($vars['artfoliotitle'])) {
			$title = $vars['artfoliotitle'];
			$body = $vars['artfoliobody'];
			$tags = $vars['artfoliotags'];
		}

?>

	<form action="<?php echo $vars['url']; ?>action/<?php echo $action; ?>" enctype="multipart/form-data" method="post">
	
		<p>
			<label><?php echo elgg_echo("title"); ?><br />
			<?php

				echo elgg_view("input/text", array(
									"internalname" => "artfoliotitle",
									"value" => $title,
													));
			
			?>
			</label>
		</p>
		<p>
			<label><?php echo elgg_echo("artfolio:text"); ?><br />
			<?php

				echo elgg_view("input/longtext",array(
									"internalname" => "artfoliobody",
									"value" => $body,
													));
			?>
			</label>
		</p>
		<p>
			<label><?php echo elgg_echo("tags"); ?><br />
			<?php

				echo elgg_view("input/tags", array(
									"internalname" => "artfoliotags",
									"value" => $tags,
													));
			
			?>
            </label>
		</p>
        <!-- display upload if action is edit -->
        		<?php
				if ($action == "artfolio/add") {	
				?>
        				<p>
   					     	<label><?php echo elgg_echo("artfolio:uploadimages"); ?><br />
   				     		   <?php echo elgg_echo("artfolio:imagelimitation"); ?><br />
							<?php
									echo elgg_view("input/file",array('internalname' => 'upload'));
					
							?>
  				          		<br /><?php echo elgg_echo("artfolio:imagelater"); ?><br />
 				           </label>
 				        </p>
 		        <?php
					}
				?>
         <!-- display upload if action is edit end -->
		<p>
			<label>
				<?php echo elgg_echo('access'); ?><br />
				<?php echo elgg_view('input/access', array('internalname' => 'access_id','value' => $access_id)); ?>
			</label>
		</p>
		<p>
			<?php

				if (isset($vars['entity'])) {
					?><input type="hidden" name="artfoliopost" value="<?php echo $vars['entity']->getGUID(); ?>" /><?php
				}
			
			?>
			<input type="submit" name="submit" value="<?php echo elgg_echo('save'); ?>" />
		</p>
	
	</form>