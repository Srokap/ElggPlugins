<?php

	/**
	 * Elgg artfolio listing
	 * 
	 * @package Artfolio
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Frederqiue Hermans
	 * @copyright ANN-Designs 2008
	 * @link www.frederiquehermans.be
	 */

		// Get info
			$owner = $vars['entity']->getOwnerEntity();
			$friendlytime = friendly_time($vars['entity']->time_created);
				$annotations = $vars['entity']->getAnnotations('artfoliolocation',1);
				foreach ($annotations as $annotation){
					$icon = "<img src=\"" . $CONFIG->wwwroot . $annotation['value'] . '_thumblarge.jpg' . "\"/>";
				}
			$title = $vars['entity']->title;
			$info = "<a href=\"{$owner->getURL()}\">{$owner->name}</a> <BR> {$friendlytime}";
		
		// Make title fit in thumbs
			if ( strlen ($title) >= 19){
				$title = substr_replace($title, '...', 18);
			}
	
		// Get rating
			$getoldrates = $vars['entity']->getAnnotations('artfoliorating',1);
				foreach ($getoldrates as $getoldrate){
						$article_rating = $getoldrate['value'];
				}
			$getnumvotes = $vars['entity']->getAnnotations('artfolionumvotes',1);
				foreach ($getnumvotes as $getnumvote){
						$numvotes = $getnumvote['value'];
				}
	
		// Match rating to image		
		if($numvotes == 0){
				$rating_image = "rateempty.gif";
		} else {
			if((($article_rating >= 0)or($article_rating == 0)) && ($article_rating <= 0.50)){
				$rating_image = "rate00.gif";
				}
			if((($article_rating >= 0.50)or($article_rating == 0.50)) && ($article_rating <= .99)){
				$rating_image = "rate05.gif";
				}
			if((($article_rating >= 1.00)or($article_rating == 1.50)) && ($article_rating <= 1.49)){
				$rating_image = "rate10.gif";
				}
			if((($article_rating >= 1.50)or($article_rating == 1.50)) && ($article_rating <= 1.99)){
				$rating_image = "rate15.gif";
				}
			if((($article_rating >= 2.00)or($article_rating == 2.00)) && ($article_rating <= 2.49)){
				$rating_image = "rate20.gif";
				}
			if((($article_rating >= 2.50)or($article_rating == 2.50)) && ($article_rating <= 2.99)){
				$rating_image = "rate25.gif";
				}
			if((($article_rating >= 3.00)or($article_rating == 3.00)) && ($article_rating <= 3.49)){
				$rating_image = "rate30.gif";
				}
			if((($article_rating >= 3.50)or($article_rating == 3.50)) && ($article_rating <= 3.99)){
				$rating_image = "rate35.gif";
				}
			if((($article_rating >= 4.00)or($article_rating == 4.00)) && ($article_rating <= 4.49)){
				$rating_image = "rate40.gif";
				}
			if((($article_rating >= 4.50)or($article_rating == 4.50)) && ($article_rating <= 4.99)){
				$rating_image = "rate45.gif";
				}
			if($article_rating == 5.0){
				$rating_image = "rate50.gif";
				}
			}
		

		// Display everything
		echo "<div class=\"artfolio_gallery_item\">";
		echo "<div class=\"artfolio_gallery_title\"><a href=\"{$vars['entity']->getURL()}\">" . $title . "</a></div>";
		echo "<a href=\"{$vars['entity']->getURL()}\">" . $icon ."</a>";
		echo "<div class=\"artfolio_gallery_content\">" . $info . "</div>";
		echo "<div class=\"artfolio_gallery_rating\"><img src=\"" . $CONFIG->wwwroot . "mod/artfolio/images/" . $rating_image . "\"/><BR>(" . $numvotes . " " . elgg_echo('artfolio:votes') . ")</div>";
		echo "</div>";


?>