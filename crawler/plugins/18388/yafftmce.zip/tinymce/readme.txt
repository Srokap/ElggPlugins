Installation:

If you already have tinymce installed {
   disable the plugin 'tinymce' in the admin panel;
   backup your existing /mod/tinymce folder;
   delete it;
   drop the new tinymce folder from the zip into /mod;
   
   } else {
	
   drop the new tinymce folder from the zip into /mod;
   }
   
create a directory 'assets' in your $_SERVER['DOCUMENT_ROOT'];
chmod it to 777 (linux only);
enable the plugin 'tinymce' in the admin panel.

This Version of tinymce has automatic language support depending on the users language settings
with the exception of tinybrowser (at the moment - i'm working on it) 

You can change the tinybrowser language and some other tinybrowser settings 
(default tinybrowser language, name of 'assets' directory etc.)
of the tinybrowser plugin in:
/mod/tinymce/tinymce/jscripts/tiny_mce/plugins/tinybrowser/config_tinybrowser.php

The tinybrowser creates subdirectories under 'assets' depending on the username,
so every user has his own assets directory.

/assets
   /[username]
     /img
         /_thumbs		
     /media
     /file
     
Usernames MUST NOT CONTAIN SPACES in this version.

Embedded flash videos now also will displayed in IE6 and IE7!

For me it works fine, feel free to make it better!
Karsten Schulze (http://ks.frinx.eu)
