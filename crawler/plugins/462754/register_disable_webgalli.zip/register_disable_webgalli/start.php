<?php

	/**
	 * Elgg registration close pluggin
	 * @license: GPL v 2. 
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */
 
    function register_disable_webgalli_init()
    {
		
    }
	
    register_elgg_event_handler('init','system','register_disable_webgalli_init');
	
?>