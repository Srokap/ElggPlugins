<?php 
	/**
	 * Elgg registration close pluggin
	 * @license: GPL v 2. 
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */
?>
	<div id="register-box">
	<h2><?php echo elgg_echo('register'); ?></h2><br />
    <?php echo elgg_echo('register:disabled'); ?><br />
	<?php echo elgg_echo('register:disabled:alternative'); ?>
	</div>
    
