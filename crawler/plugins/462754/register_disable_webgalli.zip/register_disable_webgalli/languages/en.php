<?php
	/**
	 * Elgg registration close pluggin
	 * @license: GPL v 2. 
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */




	$english = array(
	
	
			'register:disabled' => "Sorry; Registrations for this site is currently closed.",
			'register:disabled:alternative' => "Specify an alternative way for users to get registered here..",
	
	);
					
	add_translation("en",$english);

?>