<?php

    /**
     * Elgg Miscellaneous Administration plugin
     * Some administration utilities for Elgg sites
     * 
     * @package MiscAdmin
     * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
     * @author Prashant Juvekar
     * @copyright Prashant Juvekar
     * @link http://www.linkedin.com/in/prashantjuvekar
     */

	$english = array(

		'misc_admin:menu' => 'Miscellaneous Utilities',
		'misc_admin:title' => 'Miscellaneous Administration Utilities',

		'misc_admin:rescue_users:label' => '[+] Click here to enable %s stuck user accounts...',
		'misc_admin:user:signup_stats:label' => '[+] Click here to see user signup trend...',
		'misc_admin:user:last_login_stats:label' => '[+] Click here to see user last login trend...',

		'misc_admin:date:label' => 'Date',
		'misc_admin:nusers:label' => '# of users',

		'misc_admin:name:label' => 'Display Name',
		'misc_admin:uname:label' => 'User Name',
		'misc_admin:email:label' => 'Email address',
		'misc_admin:cdate:label' => 'Time of Registration',
		
		'misc_admin:user:enable' => 'Enable',
		'misc_admin:user:delete' => 'Delete',

		'misc_admin:user:enable:none' => 'No users were selected to be enabled.',
		'misc_admin:user:delete:none' => 'No users were selected to be deleted.',
		
		'misc_admin:user:enable:success' => 'Selected users have been enabled successfully.',
		'misc_admin:user:delete:success' => 'Selected users have been deleted successfully.',
	);
					
	add_translation("en",$english);
?>