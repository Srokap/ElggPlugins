
<div style="padding:5px;">

<?php

	echo elgg_view("misc_admin/rescue_users");
	echo elgg_view("misc_admin/signup_stats");
	echo elgg_view("misc_admin/last_login_stats");

?>

</div>
