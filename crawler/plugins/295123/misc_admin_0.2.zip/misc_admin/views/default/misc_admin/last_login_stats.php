<?php
	/**
	 * View the last_login stats by timeline
	 * 
	 */
?>

<div class="admin_view_last_login_stats_link">
	<a href="javascript:void(0)" onclick="$('#view_last_login_stats_showhide').toggle()">
		<?php echo elgg_echo('misc_admin:user:last_login_stats:label'); ?>
	</a>
</div>
<div id="view_last_login_stats_showhide" style="display:none;background-color:#dedede;padding:5px" >

<?php
	$users = search_for_user("", 9999, 0);

	$tab = "&nbsp;&nbsp;&nbsp;&nbsp;";

  $last_login_arr = array ();
	foreach ( $users as $user ) {
    $time_str = date('D d M Y',$user->last_login);
    if ( !isset ( $last_login_arr[$time_str] ) ) {
      $last_login_arr[$time_str] = 0;
    }
    $last_login_arr[$time_str]++;
	}

	$body .= "<table>";
	$body .= "<tr>";
	$body .= "<th><b>".elgg_echo('misc_admin:date:label')."</b></th>";
	$body .= "<th><b>".elgg_echo('misc_admin:nusers:label')."</b></th>";
	$body .= "</tr>";
	foreach ( $last_login_arr as $time_str => $count ) {
			$body .= "<tr>";
			$body .= "<td>".$time_str.$tab.$tab."</td>";
			$body .= "<td>".$count.$tab.$tab."</td>";
			$body .= "</tr>";
	}
	$body .= "</table>";

	echo $body;		
?>

</div>
<p />