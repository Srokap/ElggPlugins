<?php
  /**
   * View the disabled users and activate them
   * 
   */
	 
  access_show_hidden_entities(true);
  $users = search_for_user("",9999);
	$idx=0; $users_stuck = array();
  foreach ( $users as $user ) {
    if ( !$user->isEnabled() ) {
      $users_stuck[$idx] = $user;
		  $idx++;
    }
  }
  if ( count($users_stuck) == 0 ) {
	return;
  }
?>

<div class="admin_rescue_users_link">
	<a href="javascript:void(0)" onclick="$('#rescue_users_showhide').toggle()">
     <?php echo sprintf ( elgg_echo('misc_admin:rescue_users:label'), "<b>".count($users_stuck)."</b>" ); ?>
  </a>
</div>

<div id="rescue_users_showhide" style="display:none;background-color:#dedede;padding:5px" >

<?php

  $tab = "&nbsp;&nbsp;&nbsp;&nbsp;";

  $form_body .= "<table>";
	$form_body .= "<tr>";
	$form_body .= "<th>&nbsp;</th>";
	$form_body .= "<th><b>".elgg_echo('misc_admin:name:label').$tab."</b></th>";
	$form_body .= "<th><b>".elgg_echo('misc_admin:uname:label').$tab."</b></th>";
	$form_body .= "<th><b>".elgg_echo('misc_admin:email:label').$tab."</b></th>";
	$form_body .= "<th><b>".elgg_echo('misc_admin:cdate:label').$tab."</b></th>";
	$form_body .= "</tr>";
  $counter=0;
  foreach ( $users_stuck as $user ) {
    $counter++;
    $creation_time_str = date("F j, Y, g:i a (D)",$user->time_created);
    $form_body .= "<tr>";
    $form_body .= "<td><input name='check_{$counter}' id='check_{$counter}' value='{$counter}' type='checkbox' class='thCheckbox' checked></td>";
    $form_body .= "<td><label>" . $user->name . $tab.$tab . "</label></td>";
    $form_body .= "<td>" . $user->username . $tab.$tab . "</td>";
    $form_body .= "<td>" . $user->email . $tab.$tab. "</td>";
    $form_body .= "<td>" . $creation_time_str . $tab.$tab. "</td>";
    $form_body .= "<input type='hidden' name='guid_{$counter}' value='{$user->guid}'>";
    $form_body .= "</tr>";
  }
  $form_body .= "</table>";
  if ( count($users_stuck) ) {
	  $form_body .= elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('misc_admin:user:enable')));
    $form_body .= "&nbsp;";
	  $form_body .= elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('misc_admin:user:delete')));
  }
  echo elgg_view('input/form', array('action' => "{$vars['url']}action/misc_admin/rescue_users", 'body' => $form_body));
?>
  
</div>
<p />