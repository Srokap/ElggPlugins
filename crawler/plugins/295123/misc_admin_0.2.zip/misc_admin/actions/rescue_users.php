<?php

	/**
	 * Elgg rescue users action
	 * 
	 */

	require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");

	admin_gatekeeper(); // Only admins can rescue users
	action_gatekeeper();

	$selected_users=array(); $count=0;
	foreach ($_POST as $key=>$val) {
		if (strpos($key,'check_')!==false) {
			$selected_users[$count] = $_POST['guid_'.$val];
			$count++;
		}
	}
	access_show_hidden_entities(true);
	foreach ( $selected_users as $user_guid ) {
		if ( $user = get_user($user_guid) ) {
			if ( $_POST['submit'] == elgg_echo('misc_admin:user:enable') ) {
				$user->enable();
				set_user_validation_status($user_guid, true, 'admin');
				global $CONFIG;
				notify_user($user_guid, $CONFIG->site->guid, sprintf(elgg_echo('email:validate:success:subject'), $user->name), 
					sprintf(elgg_echo('email:validate:success:body'), $user->name), NULL, 'email');
			} else {
				$user->delete();
			}
		} else {
			register_error ( "Cannot find user " . $user_guid . " in the system" );
		}
	}

	if ( $count > 0 ) {
		if ( $_POST['submit'] == elgg_echo('misc_admin:user:enable') ) {
			system_message (elgg_echo('misc_admin:user:enable:success'));
		} else {
			system_message (elgg_echo('misc_admin:user:delete:success'));
		}
	} else {
		if ( $_POST['submit'] == elgg_echo('misc_admin:user:enable') ) {
			register_error (elgg_echo('misc_admin:user:enable:none'));
		} else {
			register_error (elgg_echo('misc_admin:user:delete:none'));
		}
	}
	
	forward($_SERVER['HTTP_REFERER']);
	exit;
?>
