<?php
    /**
     * Elgg Miscellaneous Administration plugin
     * Some administration utilities for Elgg sites
     * 
     * @package MiscAdmin
     * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
     * @author Prashant Juvekar
     * @copyright Prashant Juvekar
     * @link http://www.linkedin.com/in/prashantjuvekar
     */

    /*
     * Initialize Plugin
     */
	function misc_admin_init() {
        global $CONFIG;
		
        // Set Plugin Version for Update Checks
		set_plugin_setting('version', '0.1', 'misc_admin');
		
        register_translations($CONFIG->pluginspath . "misc_admin/languages/");            
        
		#extend_view('css','misc_admin/css');			                       
	}
    
	/*
	 * Create Admin Menu
	 */
	function misc_admin_adminmenu()
	{
		global $CONFIG;
		if (get_context() == 'admin' && isadminloggedin()) {
			add_submenu_item(elgg_echo('misc_admin:menu'), $CONFIG->url . "mod/misc_admin/index.php");
		}
	}

    global $CONFIG;
	register_elgg_event_handler('init','system','misc_admin_init');
	register_elgg_event_handler('pagesetup','system','misc_admin_adminmenu');
    register_action("misc_admin/rescue_users", false, $CONFIG->pluginspath . "misc_admin/actions/rescue_users.php");
	
?>