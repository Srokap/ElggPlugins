<?php
	/**
	 * Elgg RP Playlist plugin edit page
	 *
	 * @package Radio Paradise Playlist
	 * @license GNU General Public License (GPL) version 2
	 * @author Michael Holm, Pixel Brothers Interactive <holm@pixbros.com>
	 * @copyright Pixel Brothers Interactive 2009
	 * @link http://pixbros.com/
	 */
	
	$english = array(	
      'rpplaylist:widget' => 'Radio Paradise Playlist',
      'rpplaylist:description' => 'The Radio Pardise Playlist',
	);
					
	add_translation("en",$english);

?>