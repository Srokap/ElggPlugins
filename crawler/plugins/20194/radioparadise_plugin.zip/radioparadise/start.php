<?php
	/**
	 * Elgg RP Playlist plugin
	 *
	 * @package Radio Paradise Playlist
	 * @license GNU General Public License (GPL) version 2
	 * @author Michael Holm, Pixel Brothers Interactive <holm@pixbros.com>
	 * @copyright Pixel Brothers Interactive 2009
	 * @link http://pixbros.com/
	 */
	
	function radioparadise_init() {
   		add_widget_type('playlist', 
				elgg_echo('rpplaylist:widget'), 
				elgg_echo('rpplaylist:description')
		);  		
	}
			
	register_elgg_event_handler('init', 'system', 'radioparadise_init');
  
?>