<?php

    /**
     * Elgg Social Bookmarking
     *
     * @package ElggSocialBookmarking
     * @author Nudge Digital
     * @copyright Nudge Digital 2010
     * @link http://www.nudgedigital.co.uk/
     */


    // Initialization of the plugin.
    function social_bookmarking_init() {
        global $CONFIG;

        // For backward compatibility, we'll check if the elgg_extend_view() function exists (Elgg 1.7+) or the extend_view() function exists (Elgg 1.6.1 - Elgg 1.7)
        // *** extend_view may exist in previous version of Elgg as well.
        // *** We haven't used any previous versions though so to be safe, we've put 1.6.1 as min version

        $location = get_plugin_setting('buttons_location', 'social_bookmarking');
        if (!$location)
        {
            $location = 'sidebar';
        }

        if ($location == 'sidebar')
        {
            $view_to_extend = 'owner_block/extend';
        }
        else if ($location == 'topbar')
        {
            $view_to_extend = 'elgg_topbar/extend';
        }

        if ($view_to_extend)
        {
            if (function_exists('elgg_extend_view') || function_exists('extend_view')) {
                if (function_exists('elgg_extend_view')) {
                        elgg_extend_view($view_to_extend, 'social_bookmarking/owner_block');
                        elgg_extend_view('css', 'social_bookmarking/css');
                } else if (function_exists('extend_view')) {
                        extend_view($view_to_extend, 'social_bookmarking/owner_block');
                        extend_view('css', 'social_bookmarking/css');
                }
            }
        }
    }

    // Register our page setup function. In that call we will extend the appropriate view
    register_elgg_event_handler('init','system','social_bookmarking_init', 400);

?>