div.social_bookmarking_sidebar ul {
    padding: 0;
    text-align: center;
}

div.social_bookmarking_sidebar ul li {
    margin-bottom: 5px;
    float: left;
    margin: 0 18px;
}

div.social_bookmarking_topbar, div.social_bookmarking_topbar ul, div.social_bookmarking_topbar ul li {
    float: left;
}

div.social_bookmarking_topbar ul {
    margin: 0;
    padding: 0;
}

div.social_bookmarking_topbar ul li {
    margin-right: 5px;
}