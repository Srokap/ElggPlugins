<?php
$location = get_plugin_setting('buttons_location', 'social_bookmarking');
if (!$location)
{
    $location = 'sidebar';
}

$facebook_button_type = get_plugin_setting('facebook_button_type', 'social_bookmarking');
if (!$facebook_button_type)
{
    $facebook_button_type = 'button';
}

$twitter_button_type = get_plugin_setting('twitter_button_type', 'social_bookmarking');
if (!$twitter_button_type)
{
    $twitter_button_type = 'none';
}
?>
<div class="social_bookmarking_<?php echo $location; ?>">
    <ul>
        <li>
            <a name="fb_share" type="<?php echo $facebook_button_type; ?>" href="http://www.facebook.com/sharer.php">Share</a><script src="http://static.ak.fbcdn.net/connect.php/js/FB.Share" type="text/javascript"></script>
        </li>
        <li>
            <a href="http://twitter.com/share" class="twitter-share-button" data-count="<?php echo $twitter_button_type; ?>">Tweet</a><script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>
        </li>
    </ul>
</div>