<?php
$buttons_location = $vars['entity']->buttons_location;
if (!$buttons_location) $buttons_location = 'sidebar';

$facebook_button_type = $vars['entity']->facebook_button_type;
if (!$facebook_button_type) $facebook_button_type = 'button';

$twitter_button_type = $vars['entity']->twitter_button_type;
if (!$twitter_button_type) $twitter_button_type = 'none';
?>	
<p>
    <label>Position of buttons:&nbsp;
        <?php
        echo elgg_view('input/pulldown', array(
            'internalname' => 'params[buttons_location]',
            'options_values' => array(
                'sidebar' => 'Left sidebar',
                'topbar' => 'Top bar/Header'
            ),
            'value' => $buttons_location
        ));
        ?>
    </label>
</p>
<p>
    <label>Facebook button type:&nbsp;
        <?php
        echo elgg_view('input/pulldown', array(
            'internalname' => 'params[facebook_button_type]',
            'options_values' => array(
                'button' => 'Button (no counter)',
                'button_count' => 'Button (counter on right)',
                'box_count' => 'Button (counter on top)',
                'icon_link' => 'Link'
            ),
            'value' => $facebook_button_type
        ));
        ?>
    </label>
</p>
<p>
    <label>Twitter button type:&nbsp;
        <?php
        echo elgg_view('input/pulldown', array(
            'internalname' => 'params[twitter_button_type]',
            'options_values' => array(
                'none' => 'No counter',
                'vertical' => 'Counter on top',
                'horizontal' => 'Counter on right'
            ),
            'value' => $twitter_button_type
        ));
        ?>
    </label>
</p>