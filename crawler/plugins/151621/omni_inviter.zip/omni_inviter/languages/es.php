<?php
/**
 * Omni Inviter -- Offers multiple, extendable ways of inviting new users
 * 
 * @package Omni Inviter
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Brett Profitt <brett.profitt@gmail.com>
 */

$blurb = "Configure el mensaje a enviar, la frecuencia y cantidad de mensajes que se mandaran cada vez, que metodos habilitar y cualquier configuracion de metodo.<br /><br />

In the subject, body, and email fields these variables will 
automatically be filled in when the message is sent:<br />
<ul>
	<li>%USER_NAME% -- El usuario de la persona que que realiza la invitación.</li>
	<li>%USER_FULLNAME% -- El nombre completo de la persona que que realiza la invitación.</li>
	<li>%USER_EMAIL% -- Email de la persona que realiza la invitación.</li>
	<li>%USER_MESSAGE% -- Mensaje de la persona que realiza la invitación.</li>
	
	<li>%INVITED_NAME% -- Nombre de la persona invitada.</li>
	<li>%INVITED_EMAIL% -- Email de la persona invitada.</li>
	
	<li>%SITE_EMAIL% -- Email configurado para la página.</li>
	<li>%SITE_NAME% -- Nombre de la página.</li>
	<li>%SITE_DOMAIN_SHORTENED% -- Version de la pagina Elgg, ayuda a configurar los filtros de link.</li>
	
	<li>%OI_JOIN_LINK% -- Link que los usuarios invitados deben clickar para registrarse.</li>
	<li>%OI_INVITATION_ID% -- ID de la invitación.</li>
	<li>%OI_INVITATION_CODE% -- Código de invitación.</li>
</ul>

For maximum compatibility with email clients, disable all HTML editors.
";

// the weird formatting is because we use wordwrap to wrap at 75 chars.
// can't do that here because of the vars, but long lines annoy me.
$body = "Apreciado %INVITED_NAME%,

%USER_FULLNAME% le ha invitado a unirse a %SITE_NAME%.  Haga click en " .  
"el enlace más abajo para comenzar con el proceso de registro. Tras registrarse " .
"usted y %USER_FULLNAME% serán enlazados automáticamente y así " . 
"podrá disfrutar de los contenidos de %SITE_NAME%.

Haga click más abajo para comenzar.
(Ésta invitacion es sólo para usted. No la comparta con ninguna otra persona.)
%OI_JOIN_LINK%

Si no puede ver el link o hacer click, puede utilizar la informacion de más abajo para " .
"registrarse en la página. Dirigase a %SITE_DOMAIN_SHORTENED% " .
"y haga click en el enlace de Registro, busque la sección \"Tengo una invitación\".

ID Invitación: %OI_INVITATION_ID%
Código invitación: %OI_INVITATION_CODE%

Este es lo que %USER_FULLNAME% tiene que decir sobre %SITE_NAME%:
%USER_MESSAGE%

Grácias!
%SITE_NAME%
";

$default_user_message = 'Únete a ZonaNastic... La comunidad online del Gimnàstic de Tarragona';


$spanish = array(
	'oi:settings:rename' => 'Renombrar',
	'oi:settings:blurb' => $blurb,
	'oi:settings:installed_methods' => 'Métodos instalados',
	
	'oi:settings:message_subject_default' => '%USER_FULLNAME% te ha invitado a %SITE_NAME%!',
	//'oi:settings:message_from_default' => '%SITE_NAME% <%SITE_EMAIL%>',
	'oi:settings:message_from_default' => '%SITE_EMAIL%',
	'oi:settings:message_body_default' => $body,
	'oi:settings:message_rate' => 'Mandart %s invitaciones cada %s',
	'oi:settings:message_subject' => 'Asunto del mensaje de invitacion',
	'oi:settings:message_from' => 'Mensaje de invitación de',
	'oi:settings:message_body' => 'Cuerpo del mensaje de invitación',
	
	'oi:settings:disabled' => 'Deshabilitado -- Sólo envio manual',
	'oi:settings:minute' => 'Minuto',
	'oi:settings:fiveminute' => 'Cinco minutos',
	'oi:settings:fifteenminute' => 'Quince minutos',
	'oi:settings:halfhour' => 'Trenta minutos',
	'oi:settings:hourly' => 'Hora',
	'oi:settings:daily' => 'Dia',
	'oi:settings:weekly' => 'Semana',

	'oi:settings:enable_widget' => 'Habilitar el widget de Omni Inviter?',

	'oi:settings:max_send_attempts' => 'Intentos de envio máximos antes de deshabilitar la invitacion',
	
	/* User Settings */
	'oi:usersettings:notify_on_invite_use' => 'Notificarme cuando se una alguien a quien he invitado',

	'oi:message:invited_join_subject' => '%s acaba de unirse %s!',
	'oi:message:invited_join_body' => '%s acaba de utilizar tu invitacion para unirse %s! Aprovecha para saludarle!',

	'oi:invite:i_want_to_invite' => 'Quiero invitar',
	'oi:invite:default_user_message' => $default_user_message,
	'oi:invite:user_message' => 'Mensaje personalizado',

	'oi:invite:invitations_created' => '%s invitaciones han sido creadas y se enviarán pronto.',
	'oi:invite:invitations_created_singular' => '%s invitacion ha sido creada y se enviará pronto.',

	'oi:invite' => 'Invitar usuarios',
	'oi:invite:inviting' => 'Voy a invitar a %s usuarios.',
	'oi:invite:inviting_singular' => 'Voy a invitar a %s usuario.',
	'oi:invite:send_invitations' => 'Enviar invitaciones!',
	'oi:invite:send_success' => 'Invitacion enviada',
	'oi:invite:delete_success' => 'La invitación se ha borrado.', 

	'oi:send' => 'Enviar',
	'oi:name' => 'Nombre',
	'oi:method' => 'Método',
	'oi:log' => 'Log',
	'oi:add' => 'Añadir usuario',
	'oi:done' => 'Dejar de añadir usuario',
	'oi:added_users' => 'Los usuarios han sido añadido pero aún no se han enviado las invitaciones. Puedes buscar a más usuarios o apretar el botón de envio para enviarlas ahora.',
	
	'oi:have_invitation' => 'Tengo un ID de invitación y un código.',
	'oi:invitation_id' => 'ID Invitación',
	'oi:invitation_code' => 'Código de invitación',
	'oi:invitation_info_accepted' => 'ID Invitación y código confirmado! Continue con el registro.',

	/* WIDGET */
	'oi:widget:name' => 'Mis usuarios invitados',
	'oi:widget:description' => 'Mostrar los usuarios que he invitado',
	'oi:widget:i_invited' => 'Has invitado a %s usuarios.',
	'oi:widget:i_invited_singular' => 'Has invitado %s usuario.',
	'oi:widget:link_msg' => 'Puedes invitar a más!',
	'oi:widget:my_invited_users' => 'Mis usuarios invitados',
	'oi:widget:num_display' => 'Número de usuarios invitados a mostrar',
	'oi:widget:icon_size' => 'Tamaño de icono para usuarios invitados',
	'oi:widget:small' => 'Pequeño',
	'oi:widget:tiny' => 'Icono',
	'oi:widget:disabled' => 'Deshabilitado',


	/* ERRORS */
	'oi:errors:unknown_method' => 'Método Omni Inviter desconocido. No se pudo continuar.',
	'oi:errors:cannot_create_all_invitations' => 'Sólo %s de tus invitaciones pudo ser creada. Dirigase a la seccion de Invitaciones para más detalles.',
	'oi:errors:used_code' => 'El código que insertó ya ha sido utilizado! Revise su ID y Código de invitacion y vuelta a intentarlo. Si no tiene ninguno aún puede registrarse! Rellene el formulario de más abajo.',
	'oi:errors:invalid_code' => 'El ID y Código que ha insertado no es válido. Por favor reviselos y vuelva a intentarlo. Si no tiene ninguno aún puede registrarse! Rellene el formulario de más abajo.',
	'oi:errors:method_error' => 'Hay un problema con el método seleccionado. Seleccione un métido diferente.',
	'oi:errors:unknown_user' => 'Usuario desconocido.',
	'oi:errors:send_fail' => 'No pudo enviarse la invitación. Por favor revise los detalles, asegúrese de que el métido está accesible y no se ha llegado al máximo de envios.',

	/* ADMIN */
	'oi:omni_inviter' => 'Omni Inviter',
	'oi:admin:stats' => 'Estadísticas',
	'oi:admin:invitations' => 'Mostrar Invitaciones',
	'oi:admin:no_invitations' => 'No se encontraron invitaciones.',

	'oi:admin:invites:list_user' => 'Invitationes enviadas por %s',
	'oi:admin:invites:list_all' => 'Todas las invitaciones',

	'oi:admin:sent_status' => 'Estado de envio:',
	'oi:admin:not_sent' => 'No enviada.',
	'oi:admin:sent_error' => 'No se pudo enviar. (Intentos: %s, Último intento: %s)',
	'oi:admin:sent_stalled' => 'Colgado.  (Intentos: %s, Último intento:  %s)',
	'oi:admin:sent_status_value' => 'Ultimo intento %s (Intentos: %s, Éxito: %s)',
	
	'oi:admin:used_status' => 'Estado utilizado:',
	'oi:admin:not_used' => 'No usado.',
	'oi:admin:used_status_value' => 'Usado por %s el %s',

	'oi:admin:clicked_status' => 'Estado de clickados:',
	'oi:admin:not_clicked' => 'No clickado.',
	'oi:admin:clicked_status_value' => 'Clickado el %s',

	'oi:admin:created_by' => 'Creado por',
	'oi:admin:created_by_value' => '%s el %s',
	'oi:admin:invited_name' => 'Nombre del usuario invitado',

	'oi:admin:log' => 'Log',

	/* Stats */

	// section headers
	'oi:stats' => 'Estadísticas',
	'oi:stats:sent_invitations' => 'Invitaciones enviadas',
	'oi:stats:all_invitations' => 'Todas las invitaciones',
	'oi:stats:used_invitations' => 'Invitaciones utilizadas',
	'oi:stats:total' => 'Total',


	// types
	'oi:stats:sent' => 'Enviadas',
	'oi:stats:unsent' => 'No enviadas',
	'oi:stats:error' => 'Error enviando',
	'oi:stats:used' => 'Utilizadas',
	'oi:stats:ignored' => 'Ignoradas',
	'oi:stats:clicked_and_ignored' => 'Clickadas',
	'oi:stats:sent' => 'Enviadas',
	'oi:stats:error_sending' => 'Error enviando',


	

	


	
	

	'item:object:invitation' => 'Invitaciones'
);

add_translation("es", $spanish);
