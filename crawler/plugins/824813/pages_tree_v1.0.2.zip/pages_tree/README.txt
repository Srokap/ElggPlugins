= Pages Tree =
Allows to pages to be sorted using drag-and-drop.

Should be place below pages plugin in plugin order.

== Contents ==
1. Features
2. Credits

== 1. Features ==
- Completely (forward and backward) compatible with the Pages plugin
- Order pages
- Drag and drop pages to rearange structure
- Take over of default pages navigation in sidebar

== 2. Credits ==
- Thanks to jsTree (http://jstree.com) for the wonderful jQuery tree plugin