<?php
	/*
	*	Elgg Third Party Co-Registration uploadcsv helper script
	*	By Simon Bazley
	*
	* @package coreg
	* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	* @author BrainMedia Ltd (info@brain-media.co.uk)
	* @copyright (c) BrainMedia Ltd 2009
	* @link http://www.BrainDash.com/
	*/

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	$rownum = 0;
	if (!isadminloggedin()) {
		forward(); 
		echo "Still here?  You can't run this script unless you're an administrator\n";
		exit;
	}
	$filename = get_input('file');
	$confirm = (int) get_input('confirm');
	$headings = array('ID'=>0, 'Username'=>1, 'Password'=>2, 'Email'=>3,
					'Voornaam'=>4, 'Voorvoegsel'=>5, 'Achternaam'=>6, 
					);
	if (empty($filename)) {
		echo "<p>\n";
		echo "Usage: http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']."?file=&lt;filename&gt;&amp;confirm=1\n";
		echo "</p>\n";
		echo "<p>\n";
		echo "Where &lt;filename&gt; is the location on the elgg server, of the .csv file to upload\n";
		echo "It is expected that the .csv file uses UTF-8 encoding and is comma separated.\n";
		echo "Fields which contain commas, may cause problems, ".
										"so ensure that the important fields occur before any containing commas\n";
		echo "</p>\n";
		echo "<p>\n";
		echo "The first row is expected to contain the column headings.  ".
				"The following are the expected headings:- ".implode(", ",array_keys($headings));
		echo "</p>\n";
		echo "<p>\n";
		echo "The confirm parameter dictates whether or not to actually action the registration.  \n";
		echo "Without it (or if it is set to 0 or less) the script will purely test the csv file.  \n";
		echo "</p>\n";
		echo "<p>\n";
		echo "If confirm is set, you can use it to output extra debug information.  ".
				"If it is less that 0 it will output debug information on the formation of the xml request.  ".
				"If it is greater than 0 it will action the csv file, and output debug information on the response.  ";
		echo "So a value of -1 or 2 will print the xml either to be sent, or recieved (if all works as planned).  \n";
		echo "A value of -2 or 3 will var_dump the objects used to make the xml (if all works as planned).  \n";
		echo "</p>\n";
		exit;
	}
	if (!file_exists($filename)) {
		echo "<p>\n";
		echo "Filename ".$filename." doesn't exist\n";
		echo "</p>\n";
		if ($filename[0]!="/") {
			echo "<p>\n";
			echo "You specified a relative path.  Remember paths are relative to the ".getcwd()."\n";
			echo "</p>\n";
		}
		exit;
	}
	@$handle = fopen($filename, "r");
	if ($handle===FALSE) {
		echo "<p>\n";
		echo "Failed to open ".$filename." (aka ".getcwd()."/".$filename.")\n";
		echo "Check the process run the web services has access rights to the file, and its parent directories\n";
		echo "</p>\n";
		if ($filename[0]!="/") {
			echo "<p>\n";
			echo "You specified a relative path.  Remember paths are relative to the ".getcwd()."\n";
			echo "</p>\n";
		}
		exit;
	}
	$titles = array('UserID', 'UserName', 'Password', 'Email', 'FullName', 'SubmissionState');
	echo "<table border=1>\n";
	echo "<tr>\n";
	foreach($titles as $heading)
		echo "<th>".$heading."</th>\n";
	echo "</tr>\n";
	while (($row = fgetcsv($handle, 1000, ",")) !== FALSE) {
		if ($rownum==0) {
			// For the heading row, lookup each heading against the list above, to find out where the given columns are
			// Note the default values for each row are never used.
			foreach($row as $column=>$text) {
				if (isset($headings[$text]))
					$headings[$text] = $column;
			}
		} else {
			// For each for, pick the data out of the 
			$newdata = array();
			foreach($headings as $heading=>$index) {
				$data = $row[$index];
				// Convert the data encoding if needs be
				$data = iconv("UTF-8", "ISO-8859-1", $data);
				$newdata[] = $data;
			}
			// Now pick out of the newdata array, the fields we want.  
			list($id, $username, $password, $email, $forename, $middlebit, $surname) = $newdata;
			$name = $forename;
			if (!empty($name)) $name.=" ";
			$name.= $middlebit;
			$name = trim($name);
			if (!empty($name)) $name.=" ";
			$name.= $surname;
			// Now reform the array, with named indexes
			$newdata = array('userid'=>$id, 'username'=>$username, 'password'=>$password, 'email'=>$email,
							'name'=>$name);
			// Now form the request
			$xml = xmlrpc_encode_request('coreg.register', $newdata, array('encoding'=>'UTF-8'));
			$data = new XMLRPCCall($xml);
			if ($confirm>0) {
		    	$retval = coregrpc_register($data);
//				$xml = (string)$retval;
				$xml = $retval->__toString();
				$data = xmlrpc_decode($xml);
				if ($confirm>1) {
					echo "<pre>".htmlspecialchars($xml)."</pre>\n";
					if ($confirm>2) {
						echo "<pre>"; var_dump($retval); echo "</pre>\n";
						echo "<pre>"; var_dump($data); echo "</pre>\n";
					}
				}
				// Check up on the response
				if (xmlrpc_is_fault($data)) {
					// If the failure was caused within CoReg, the faultString will contain <reason> tags
					$xml = "<node>".$data['faultString']."</node>\n";
					$XML = simplexml_load_string($xml);
					$reason = $XML->reason;
				} else {
					// The response form CoReg, will contain <comment> tags, giving the GUID of the newly created user
					$xml = "<node>".$data."</node>\n";
					$XML = simplexml_load_string($xml);
					$comment = $XML->comment;
					$no = sscanf($comment, "User Created with GUID %d", $GUID);
					// $no will be 0 if GUID was not picked up from the comment string.  
				}
			} else {
				echo "<!-- confirm wasn't set so didn't attempt to create user ".$newdata['username']." -->\n";
				if ($confirm<0) {
					echo "<pre>".htmlspecialchars($xml)."</pre>\n";
					if ($confirm<-1) {
						echo "<pre>"; var_dump($data); echo "</pre>\n";
					}
				}
			}
			// So now print out all the datacolumns
			echo "<tr>\n";
			foreach($newdata as $column) {
				echo "<td>".$column."</td>\n";
			}
			// And finally output the submission state, saying what happened
			echo "<td>";
			if ($confirm>0) {
				if (xmlrpc_is_fault($data)) {
					if (empty($reason)) {
						echo $data['faultString'];
					} else {
						echo $reason;
					}
				} else {
					if ($no!=1) {
						echo "GUID ".$GUID;
					} else {
						echo $comment;
					}
				}
			} else {
				echo "Test Run";
			}
			echo "</td>\n";
			echo "</tr>\n";
    	}
	    $rownum++;
	}
	echo "</table>\n";
	fclose($handle);
	if ($confirm<=0) {
		echo "<p>\n";
		echo "Add the confirm=1 parameter to actually action this test run. \n";
		echo "<a href='http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']."?file=".$filename."&confirm=1'>".
				"Or click here</a>\n";
		echo "<p>\n";
	}
?>

