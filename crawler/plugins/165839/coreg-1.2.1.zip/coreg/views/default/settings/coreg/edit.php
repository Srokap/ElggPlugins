<?php
	/*
	*	Elgg Third Party Co-Registration Plugin - Edit Settings file
	*	By Simon Bazley
	*
	* @package coreg
	* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	* @author BrainMedia Ltd (info@brain-media.co.uk)
	* @copyright (c) BrainMedia Ltd 2009
	* @link http://www.BrainDash.com/
	*/

/**
 * Default Settings
 */

$extra_fields			= array("userid");
$extra_fields			= implode("\n", $extra_fields);

//include(dirname(__FILE__).'/BDdefaults.php');

/**
 *  Set the Default Values
 */

// Use this plugin name for everything in this file
$pluginname = 'coreg';

if (!get_plugin_setting('extra_fields', $pluginname)) {
	set_plugin_setting('extra_fields', $extra_fields, $pluginname);
}
if (!get_plugin_setting('empty_password_ok', $pluginname)) {
	set_plugin_setting('empty_password_ok', $empty_password_ok, $pluginname);
}

/**
 *  Load the current Values
 */

$extra_fields		= get_plugin_setting('extra_fields', $pluginname);
$empty_password_ok	= get_plugin_setting('empty_password_ok', $pluginname);

/**
 *  setup each item on the form
 */

$extrafields= elgg_view('input/longtext', array(
	'internalname'	=> 'params[extra_fields]',
	'value'			=> $extra_fields,
	)
);

$emptypassword= elgg_view('input/pulldown', array(
    'internalname' => 'params[empty_password_ok]',
    'value' => get_plugin_setting('empty_password_ok', $pluginname),
    'options_values' => array(
        0 => elgg_echo('option:no'),
        1 => elgg_echo('option:yes')
        )
    )
);

/**
 *  Print the form
 */
?>
<p>
	<b><?php echo elgg_echo($pluginname.':settings:heading'); ?></b><br />
	<p><?php echo elgg_echo($pluginname.':settings:instructions'); ?></p>
</p>
<p>
	<?php echo elgg_echo($pluginname.':settings:extra_fields'); echo $extrafields; ?><br />
	<?php echo elgg_echo($pluginname.':settings:emptypasswordok'); echo $emptypassword; ?><br />
</p>
