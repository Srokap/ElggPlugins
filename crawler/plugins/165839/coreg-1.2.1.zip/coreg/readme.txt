	/*
	*	Elgg Third Party Co-Registration Plugin
	*	By Simon Bazley
	*
	* @package coreg
	* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	* @author BrainMedia Ltd (info@brain-media.co.uk)
	* @copyright (c) BrainMedia Ltd 2009
	* @link http://www.BrainDash.com/
	*/

1) Put the coreg directory into the mod folder and enable it
2) Edit your Apache2 (or whichever webbrowser your Elgg site is running on) config file to add the 
	environment variable "XML-RPC-IPs", and define it with a ; separated list of allowed IPs
	ie in Apache add something like the following to your VirtualHost definition (and reload config) :-
		SetEnv        XML-RPC-IPs 127.0.0.1;192.168.1.1;192.168.1.2
3) Now off you go.  

In successfully registering a user the XML Response will be:-
<status>Success</status><comment>User Created with GUID %s</comment> (replace %s with the actual GUID obviously)

If it failed it will return an XML Fault, and the faultString will be in this form:-
<status>Error</status><reason>...</reason>

Where ... may be one or more of:-
XML-RPC Client IP, %s not permitted to access $s
"Username not given",
"Password not given",
"Real Name not given",
"Email Address not given",
register_user failed

To access the function use something like this (remember to change <your-elgg-site> to your hostname):-
<?php                                     
$params = array (
					'username'	=>'testuser',
					'password'	=>'testpassword',
					'name'		=>'Test Name',   
					'email'		=>'testemail@braindash.com',
				);
$XMLOptions     =       array(  'output_type' => 'xml',
                                'verbosity' => 'pretty',
                                'version' => 'xmlrpc',
                                'debug' => 2);

$request = xmlrpc_encode_request("coreg.register", $params, $XMLOptions);
$context = stream_context_create(array('http' => array(
    'method' => "POST",
    'header' => "Content-Type: text/xml",
    'content' => $request
)));
$file = file_get_contents("http://your-elgg-site/xml-rpc.php", false, $context);
$response = xmlrpc_decode($file);
if (xmlrpc_is_fault($response)) {
	$response = $response['faultString'];
}
echo "<pre>\n".htmlentities($response)."\n</pre><hr>\n";
?>
