<?php
	/*
	*	Elgg Third Party Co-Registration Plugin
	*	By Simon Bazley
	*
	* @package coreg
	* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	* @author BrainMedia Ltd (info@brain-media.co.uk)
	* @copyright (c) BrainMedia Ltd 2009
	* @link http://www.BrainDash.com/
	*/

	function coregrpc_init()
	{
		register_xmlrpc_handler('coreg.register', 'coregrpc_register');
	}

    function coregrpc_register(XMLRPCCall $data) 
	{
		
		global $CONFIG;

		$parameters = xmlrpc_parse_params( $data->getParameters());
        $values = $parameters[0];

		$remoteaddr	= $_SERVER['REMOTE_ADDR'];

		$xmlrpcips 	= getenv("XML-RPC-IPs");
		if ($xmlrpcips===false)
			$xmlrpcips='127.0.0.1';
		$xmlrpcips 	= explode(';', $xmlrpcips);

		if (!in_array($remoteaddr, $xmlrpcips)) {
			$host = $_SERVER['HTTP_HOST'];
			$reason = sprintf(elgg_echo('coreg:ipnotpermitted'), $remoteaddr, $host);
			return new XMLRPCErrorResponse('<status>Error</status><reason>'.$reason.'</reason>');
        }

        @$username 	= $values['username'];
        @$password 	= $values['password'];
		@$name		= $values['name'];
		@$email		= $values['email'];

		if (get_plugin_setting('empty_password_ok', 'coreg')==1)
			$password = 'password';
		$errors=array();
		if (!isset($username))
			$errors[]=elgg_echo('coreg:nousername');
		if (!isset($password))
			$errors[]=elgg_echo('coreg:nopassword');
		if (!isset($name))
			$errors[]=elgg_echo('coreg:norealname');
		if (!isset($email))
			$errors[]=elgg_echo('coreg:noemailaddr');

		$extrafields       = get_plugin_setting('extra_fields', 'coreg');
		if (isset($extrafields) && !empty($extrafields))
			$extrafields = explode("\n", $extrafields);
		else
			$extrafields = array('userid');
		$extrafieldvalues = array();
		foreach($extrafields as $field) {
			$field = trim($field);
			@$extrafieldvalues[$field]	= $values[$field];
			if (!isset($extrafieldvalues[$field])) {
				$errors[]=sprintf(elgg_echo('coreg:noextrafield'), $field);
			}
		}


		if (!empty($errors))
			return new XMLRPCErrorResponse('<status>Error</status><reason>'.implode(', ', $errors).'</reason>');
        //
		try {
			$guid = register_user($username, $password, $name, $email, true);
			
		}
 		catch (RegistrationException $e) {
			// Need to code something here to check whether Exception indicated Failure or just a Warning
			return new XMLRPCErrorResponse('<status>Error</status><reason>'.$e->getMessage().'</reason>');
		}

		if ($guid===FALSE) {
			$reason = sprintf(elgg_echo('coreg:someprocfailed'), 'register_user');
			return new XMLRPCErrorResponse('<status>Error</status><reason>'.$reason.'</reason>');
		}
		else {
			foreach($extrafieldvalues as $name=>$value) {
				$retval = create_metadata($guid, $name, $value, '', 0, ACCESS_PUBLIC);
				if (!$retval) {
					$reason = sprintf(elgg_echo('coreg:createmetadatafailed'), $name, $value);
					return new XMLRPCErrorResponse('<status>Partial</status><reason>'.$reason.'</reason');
				}
			}
			$response = new XMLRPCSuccessResponse();
			$comment = sprintf(elgg_echo('coreg:usercreated'), $guid);
			$response->addString('<status>Success</status><comment>'.$comment.'</comment>');
		}
        return $response;
	}

	// Initialise 
	register_elgg_event_handler('init','system','coregrpc_init');
?>
