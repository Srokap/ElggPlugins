<?php
	/*
	*	Elgg Third Party Co-Registration Plugin - English Language translation
	*	By Simon Bazley
	*
	* @package coreg
	* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	* @author BrainMedia Ltd (info@brain-media.co.uk)
	* @copyright (c) BrainMedia Ltd 2009
	* @link http://www.BrainDash.com/
	*/

	$english = array(
	
		/**
		 * Error Reasons
		 */
	
		'coreg:ipnotpermitted'	=> "XML-RPC Client IP, %s, not permitted to access %s",
		'coreg:nousername'		=> "Username not given",
		'coreg:nopassword'		=> "Password not given",
		'coreg:norealname'		=> "Real Name not given",
		'coreg:noemailaddr'		=> "Email Address not given",
		'coreg:noextrafield'		=> "Additional field %s not specified",
		'coreg:someprocfailed'	=> "%s failed",

		/**
		 * Success Comments
		 */
		'coreg:usercreated'		=> "User Created with GUID %s",
	
		/**
		 * Settings Page
		 */

		/**
		 * Headings
		 */
		'coreg:settings:heading'			=>
			"CoReg Settings",

		/**
		 * Free text (notes)
		 */
		'coreg:settings:instructions'			=>
			"If you have any extra data you want to store as part of your registration, ".
			"set the fields here. ",

		/**
		 * Setting Labels
		 */
		'coreg:settings:extra_fields'				=>
			"Extra fields to store as meta data against new users",
		'coreg:settings:emptypasswordok'				=>
			"Allow ThirdParty sites to not specify a password (in which case 'password' is used)",
	);
					
	add_translation("en",$english);

?>
