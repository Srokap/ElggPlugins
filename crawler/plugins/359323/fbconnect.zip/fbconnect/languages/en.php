<?php

$english = array(

		'item:user:facebook' => "Facebook users",			
		'fbconnect:settings:api_key:title' => "API Key",
		'fbconnect:settings:api_secret:title' => "API Secret",
		'fbconnect:account_create' => "Error: Unable to create your account. "
		."Please contact the site administrator or try again later.",
		'fbconnect:inactive' => "Error: cannot activate your Elgg account.",
		'fbconnect:banned' => "Error: cannot log you in. "
		."Please contact the site administrator or try again later.",
		'fbconnect:fail' => "Error: cannot log you in. "
		."Please contact the site administrator or try again later.",
		'fbconnect:facebookerror' => "Error: Facebook returned the following error message: %s",
		'fbconnect:account_duplicate' => "Error: a non-Facebook account with "
		."the same username (%s) already exists on this site.",
		'fbconnect:settings:yes' => "yes",
		'fbconnect:settings:no' => "no",
		'fbconnect:user_settings_title' => "Facebook profile",
		'fbconnect:user_settings_description' => "Let Facebook control my profile when I login into Elgg. This means facebook will update your picture and information every time you login."
		." If you set this to \"no\", you will be able to edit your %s profile and it will no longer be synchronised with Facebook.",
		'fbconnect:user_settings:save:ok' => "Your Facebook profile preference has been saved.",
		'fbconnect:facebook_login_settings:save:ok' => "Your Facebook uid has been saved.",
		'fbconnect:facebook_login_title' => "Facebook login",
		'fbconnect:facebook_login_description' => "If you want to sync your %s account with Facebook click on the \"Connect with Facebook\" button.",
		'fbconnect:cron_report' => "Synced %s Facebook accounts.",
		'fbconnect:addProfileLinkUpdate' => "Update From Facebook",
		'fbconnect:sync_current_profile_success' => "Your profile has been Synced with Facebook. You can now login through Facebook or with your email address and password. You can also go to your settings page to update your account from Facebook.",
		'fbconnect:sync_current_profile_Fail' => "There was an error saving the account.",
		'fbconnect:sync_current_profile_Fail_pass' => "There was an error, the password you entered was incorrect, please input your information again.",
		'fbconnect:email_address_mismatch' => "The email you provided does not match the email on your facebook account.",
		'fbconnect:facebook_update_profile' => "You can sync your account with facebook by clicking the button below.",
		'fbconnect:facebook_account_created' => "
Hi %s,
Congratulations, your Facebook/%s account has been activated!\n
Login to %s with the link below you can use your generated username: %s \n
This is your password: %s \n
or you can login by clicking on any buttons that say Signup with Facebook or Login with Facebook. \n
Go here to login to your account:
%s",
		'fbconnect:no_sync_current_profile_success' => "Your Facebook information has been saved, You now have two seperate accounts."
		);
			

$user_email = get_plugin_setting('fbsync_email', 'fbconnect');
if($user_email)
{
	$fbsync_email = array('fbconnect:add_email_address' => $user_email);	
}
else
{
	$fbsync_email = array(
	'fbconnect:add_email_address' => "<strong>In order to create your account we need your email address. If you are already registered with %s please use the email you registered with.</strong>"
	);
}

$existing_acct = get_plugin_setting('fbsync_existing_account', 'fbconnect');
if($existing_acct)
{
	$fbsync_existing_account = array('fbconnect:sync_current_profile' => $existing_acct);
}
else
{
	$fbsync_existing_account = array(
	'fbconnect:sync_current_profile' => "We see you do have an account with us already. So now you have two options you can either <strong>sync your Facebook account with your %s account </strong> or <strong>create a seperate account</strong>. Pick which one you want to do:"
	);
}

$get_password = get_plugin_setting('fbsync_password', 'fbconnect');
if($get_password)
{
	$fbsync_password = array('fbconnect:sync_current_profile_pass' => $get_password);
}
else
{
		$fbsync_password = array(
		'fbconnect:sync_current_profile_pass' => "Just to make sure that this is really you, we need you to type in your %s password. We wouldn't anyone stealing your account."
		);
}


add_translation("en",$english);
add_translation("en", $fbsync_email);
add_translation("en", $fbsync_existing_account);
add_translation("en", $fbsync_password);

?>