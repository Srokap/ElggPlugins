<?php

$users_email = 0;
$syncAccounts = 0;
//gatekeeper();

$users_email_valid = false;

$loggedin_user = get_loggedin_user();

//$_SESSION['fbconnect_debug_email']['addEmail_START'] = array('addemail_entered' => 'true', 'loggedinuser' => $loggedin_user);

$users_email = $_POST['email'];

if(is_string($users_email))
{
	$users_email_valid = true;
}

$syncAccounts = $_POST['syncacct'];
$password = $_POST['p4550rd'];

//$_SESSION['fbconnect_debug_email']['request_data'] = array('REQUEST_DATA' => $_REQUEST);
//$_SESSION['fbconnect_debug_email']['request_data_before_if'] = array('before_if_users_email' => $users_email);

if($users_email_valid == true)
{

	$user_email_match = get_user_by_email($users_email);
//	$_SESSION['fbconnect_debug_email']['addemail'] = array('usersemail' => $users_email, 'users_email_match' => $user_email_match, 'count_users_email_match' => count($user_email_match));

	if(count($user_email_match) == 1 && $user_email_match != false || $user_email_match == true)
	{
		$email_exists = true;
		$_SESSION['fbconnect_addemail']['email_exists'] = true;
		$_SESSION['fbconnect_addemail']['email'] = $users_email;
		$_SESSION['fbconnect_addemail']['new_user'] = false;

	}
	else
	{
		$email_exists = false;
		$_SESSION['fbconnect_addemail']['new_user'] = true;
		$_SESSION['fbconnect_addemail']['email_exists'] = false;
		$_SESSION['fbconnect_addemail']['email'] = $users_email;

	}
}
else
{
	//	$_SESSION['fbconnect_debug_email']['email_no_data'] = array('_GET' => $_GET, '_POST'=> $_POST);
}

if(is_string($syncAccounts))
{
	$_SESSION['fbconnect_addemail']['syncAccts'] = true;
	$_SESSION['fbconnect_addemail']['syncAccts_val'] = $syncAccounts;
}

if(is_string($password) && $_SESSION['fbconnect_addemail']['pass_verified'] != true && $_SESSION['fbconnect_addemail']['syncAccts_val'] == "yes")
{
	$existing_account = get_user_by_email($_SESSION['fbconnect_addemail']['email']);
	$user = get_entity($existing_account[0]['guid']);
	$pass_validate = generate_user_password($user, $password);
//	$_SESSION['fbconnect_debug_email']['PASSWORD_DATA'] = array('existing_account' => $existing_account[0]['guid'],'email_address' => $_SESSION['fbconnect_addemail']['email'], 'existing_password' => $user, 'pass_validate' => $pass_validate);
	if($user->password == $pass_validate)
	{
		$_SESSION['fbconnect_addemail']['pass_verified'] = true;
	}
	else
	{
		$_SESSION['fbconnect_addemail']['pass_verified'] = false;
		register_error(elgg_echo("fbconnect:sync_current_profile_Fail_pass"));
		unset($_SESSION['fbconnect_addemail']);
	}
	
}


if(is_string($_SESSION['fbconnect_addemail']['syncAccts_val']) )
{
	//	$_SESSION['fbconnect_debug_email']['syncFBaccts'] = array('syncaccounts' => $syncAccounts);

	if($_SESSION['fbconnect_addemail']['syncAccts_val'] == "yes" && $_SESSION['fbconnect_addemail']['pass_verified'] == true)
	{
		$loggedin_user = get_loggedin_user();
		$users_email = $_SESSION['fbconnect_addemail']['email'];
		$existing_account = get_user_by_email($users_email);

		$user_bb = get_entity($existing_account[0]['guid']);

		$user_bb->facebook = 'synced';
		$user_bb->facebook_uid = $loggedin_user->facebook_uid;
		$user_bb->facebook_controlled_profile = 'no';
		$user_bb->fbconnect_icon_url = $loggedin_user->fbconnect_icon_url;

		$user_bb_metadata = get_metadata_for_entity($user_bb->guid);
//		$_SESSION['fbconnect_debug_email']['user_bb'] = array('existing_account'=> $existing_account, 'user_bb_metadata' => $user_bb_metadata, 'user_bb' => $user_bb, 'loggedin_user' => $loggedin_user);

		if(fbconnect_update_profile($user_bb))
		{
//			$_SESSION['fbconnect_debug_email']['user_bb'] = array('REMOVE_USER_UPDATE_COMPLETE' => true);
			
			unset($_SESSION['fbconnect_addemail']);

			$loggedin_user->delete();

			system_message(elgg_echo('fbconnect:sync_current_profile_success'));
		}
		else
		{
			register_error(elgg_echo("fbconnect:account_create"));
		}

//		$_SESSION['fbconnect_debug_email']['yes_sync'] = array('user_bb' => $user_bb, 'loggedinUser' => $loggedin_user);

		forward();

		exit();
	}
	elseif($_SESSION['fbconnect_addemail']['syncAccts_val'] == "no" && $_SESSION['fbconnect_addemail']['pass_verified'] != true)
	{
		$users_email = $_POST['user_email'];
		$user = get_loggedin_user();
		set_user_validation_status($user->guid, true, 'admin');
		$user->enable();
		$user->email = $users_email;
		$password = generate_random_cleartext_password();
		$user->salt = generate_random_cleartext_password();
		$user->password = generate_user_password($user, $password);
		
		$user->save();
		$user->facebook = "nonsynced";
		if (fbconnect_update_profile($user))
		{
			unset($_SESSION['fbconnect_addemail']);
			notify_user($user->guid, $CONFIG->site->guid, sprintf(elgg_echo('uservalidation:success:subject', $user->language), $user->name), sprintf(elgg_echo('fbconnect:facebook_account_created', $user->language), $user->name, $CONFIG->site->name, $CONFIG->site->name, $user->username, $password, $CONFIG->site->url), NULL, 'email');
			system_message(elgg_echo('fbconnect:no_sync_current_profile_success'));
		}
		else
		{
			register_error(elgg_echo('fbconnect:sync_current_profile_Fail'));
		}

		unset($_SESSION['fbconnect_addemail']);
		forward();

		exit();

	}

}
else
{
	//	$_SESSION['fbconnect_debug_email']['sync_no_data'] = array('_GET' => $_GET, '_POST'=> $_POST);
}

if(is_string($_REQUEST['facebook_update']))
{

	if(is_string($_REQUEST['guid']))
	{
		$user_update_req = get_entity($_REQUEST['guid']);
		$update_success = fbconnect_update_profile($user_update_req);
		$fbprofile = fbconnect_get_info_from_fb($user_update_req,'status');
			
		if ($fbprofile)
		{
			thewire_save_post($fbprofile['status']['message'], ACCESS_PUBLIC, 0, 'facebook');
//						$_SESSION['fbconnect_updateuser'] = array('USER_GUID' => $user_update_req, 'REQUEST_DATA' => $_REQUEST['guid'], 'UPDATE_USER_SUCCESS' => $update_success);
		}
		else
		{
//						$_SESSION['fbconnect_updateuser'] = array('USER_GUID' => $user_update_req, 'REQUEST_DATA' => $_REQUEST['guid'], 'UPDATE_USER_SUCCESS' => $update_success);
		}
	}

}

if(is_string($_REQUEST['remove_facebook_account']))
{
	if(is_string($_REQUEST['guid']))
	{
		$user_rem_acct = get_entity($_REQUEST['guid']);

		$metadata_todel1 = get_metadata_byname($user_rem_acct->guid, "facebook_controlled_profile");
		$metadata_todel1->delete();
		$metadata_todel2 = get_metadata_byname($user_rem_acct->guid, "facebook_uid");
		$metadata_todel2->delete();
		$metadata_todel3 = get_metadata_byname($user_rem_acct->guid, "facebook");
		$metadata_todel3->delete();
		$metadata_todel4 = get_metadata_byname($user_rem_acct->guid, "facebook_sync_time");
		$metadata_todel4->delete();
		//		$metadata_todel5 = get_metadata_byname($user_rem_acct->guid, "facebook_icon_url_mini");
		//		$metadata_todel5->delete();
		//		$metadata_todel6 = get_metadata_byname($user_rem_acct->guid, "facebook_icon_url_normal");
		//		$metadata_todel6->delete();

		unset($metadata_todel1);
		unset($metadata_todel2);
		unset($metadata_todel3);
		unset($metadata_todel4);
		//		unset($metadata_todel5);
		//		unset($metadata_todel6);

	}
}

if(is_string($_REQUEST['make_site_account']))
{
	if(is_string($_REQUEST['guid']))
	{
		$user_site_only = get_entity($_REQUEST['guid']);
		$metadata_todel1 = get_metadata_byname($user_site_only->guid, "facebook_controlled_profile");
		$metadata_todel1->delete();
		$metadata_todel2 = get_metadata_byname($user_site_only->guid, "facebook_uid");
		$metadata_todel2->delete();
		$metadata_todel3 = get_metadata_byname($user_site_only->guid, "facebook");
		$metadata_todel3->delete();
		$metadata_todel4 = get_metadata_byname($user_site_only->guid, "facebook_sync_time");
		$metadata_todel4->delete();
		//		$metadata_todel5 = get_metadata_byname($user_site_only->guid, "facebook_icon_url_mini");
		//		$metadata_todel5->delete();
		//		$metadata_todel6 = get_metadata_byname($user_site_only->guid, "facebook_icon_url_normal");
		//		$metadata_todel6->delete();

		unset($metadata_todel1);
		unset($metadata_todel2);
		unset($metadata_todel3);
		unset($metadata_todel4);
		trigger_elgg_event('validate', 'user', $user_site_only);
		send_new_password_request($user_site_only->guid);
		//		unset($metadata_todel5);
		//		unset($metadata_todel6);
	}
}


?>