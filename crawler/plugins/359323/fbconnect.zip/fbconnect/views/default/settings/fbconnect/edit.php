<?php
$body = '';

$body .= elgg_echo('fbconnect:settings:api_key:title');
$body .= '<br />';
$body .= elgg_view('input/text',array('internalname'=>'params[api_key]','value'=>get_plugin_setting('api_key', 'fbconnect')));

$body .= '<br /><br />';

$body .= elgg_echo('fbconnect:settings:api_secret:title');
$body .= '<br />';
$body .= elgg_view('input/text',array('internalname'=>'params[api_secret]','value'=>get_plugin_setting('api_secret', 'fbconnect')));

$body .= '<br /><br />';
$body .= '<h2>Global FaceBook Login Settings</h2>';
$body .= '<br /><br />';

$body .= 'Set where the user is redirected after login (Default is main page)<br/> use full url ie. http://www.yoursite.com/pg/dashboard/';
$body .= '<br/>';
$body .= 'URL to forward to: <br/>'.elgg_view('input/text',array('internalname'=>'params[login_forward]','value'=>get_plugin_setting('login_forward', 'fbconnect')));

$body .= '<br /><br />';
$body .= '<h2>This is where you can set what the user sees in the email, sync, password prompts.</h2>';
$body .= '<br /><br />';


$body .= 'This is where you specify what the prompt says when asking for the users email.';
$body .= '<br/>';
$body .= ' <br/>'.elgg_view('input/longtext',array('internalname'=>'params[fbsync_email]','value'=>get_plugin_setting('fbsync_email', 'fbconnect')));

$body .= '<br /><br />';

$body .= 'This is where you specify what the prompt says when asking<br/> if the user wishes to sync their existing account or not.';
$body .= '<br/>';
$body .= ' <br/>'.elgg_view('input/longtext',array('internalname'=>'params[fbsync_existing_account]','value'=>get_plugin_setting('fbsync_existing_account', 'fbconnect')));

$body .= '<br /><br />';

$body .= 'This is where you specify what the prompt says when asking for the users password.';
$body .= '<br/>';
$body .= ' <br/>'.elgg_view('input/longtext',array('internalname'=>'params[fbsync_password]','value'=>get_plugin_setting('fbsync_password', 'fbconnect')));

$body .= '<br /><br />';
$body .= '<h2>Global User Settings</h2>';
$body .= '<br /><br />';

$body .= 'Set Width and Height of the dashboard profile picture';
$body .= '<br/>';
$body .= 'Width (default: 200): <br/>'.elgg_view('input/text',array('internalname'=>'params[Profile_Iconw]','value'=>get_plugin_setting('Profile_Iconw', 'fbconnect')));
$body .= '<br/>';
$body .= 'Height (default: 200): <br/>'.elgg_view('input/text',array('internalname'=>'params[Profile_Iconh]','value'=>get_plugin_setting('Profile_Iconh', 'fbconnect')));

$body .= '<br /><br />';

$body .= 'Set Width and Height of the Topbar profile picture';
$body .= '<br/>';
$body .= 'Width (default: 16): <br/>'.elgg_view('input/text',array('internalname'=>'params[Top_bar_Iconw]','value'=>get_plugin_setting('Top_bar_Iconw', 'fbconnect')));
$body .= '<br/>';
$body .= 'Height (default: 16): <br/>'.elgg_view('input/text',array('internalname'=>'params[Top_bar_Iconh]','value'=>get_plugin_setting('Top_bar_Iconh', 'fbconnect')));


echo $body;
?>