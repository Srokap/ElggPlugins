<script src="http://static.ak.connect.facebook.com/js/api_lib/v0.4/FeatureLoader.js.php" type="text/javascript"></script>
<div id="facebooklogin-box"><fb:login-button onlogin="facebook_onlogin();" v="2">Connect with Facebook</fb:login-button></div>
<script type="text/javascript">
function facebook_onlogin() {
	document.location.href = "<?php echo $vars['url'] ?>action/fbconnect/login";
}
FB.init("<?php echo get_plugin_setting('api_key', 'fbconnect'); ?>", "<?php echo $vars['url']; ?>mod/fbconnect/xd_receiver.html"); 
</script>
