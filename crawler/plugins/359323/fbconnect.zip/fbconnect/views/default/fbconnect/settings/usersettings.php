<?php
/**
 * User settings for fbconnect.
 *
 * @package twitterlogin
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine
 * @copyright Curverider 2009
 * @link http://elgg.org/
 */

$options = array(elgg_echo('fbconnect:settings:yes')=>'yes',
elgg_echo('fbconnect:settings:no')=>'no',
);

$user = page_owner_entity();
if (!$user) {
	$user = $_SESSION['user'];
}

if(isset($user->facebook))
{

	if( $user->facebook == 'nonsynced') {
		$facebook_controlled_profile = $user->facebook_controlled_profile;

		if (!$facebook_controlled_profile) {
			$facebook_controlled_profile = 'yes';
		}
		?>
<h3><?php echo elgg_echo('fbconnect:user_settings_title'); ?></h3>

<p><?php echo sprintf(elgg_echo('fbconnect:user_settings_description'), $CONFIG->site->name); ?></p>

		<?php
		echo elgg_view('input/radio',array('internalname' => "facebook_controlled_profile", 'options' => $options, 'value' => $facebook_controlled_profile));

		echo '<br><br><input type="button" onClick="$.ajax({
   type: \'POST\',
   url: \''.$CONFIG->url.'action/fbconnect/addemail\',
   data: \'facebook_update=true&guid='.$user->guid.'\',
   success: function(msg){
     alert( \'Your account has been updated! \');
   }
 });
 " value="Update my profile from Facebook"></p>';

		echo '<input type="button" onClick="$.ajax({
   type: \'POST\',
   url: \''.$CONFIG->url.'action/fbconnect/addemail\',
   data: \'make_site_account=true&guid='.$user->guid.'\',
   success: function(msg){
     alert( \'Your account has been updated! \');
     $(document).reload(); 
   }
 });
" value="Remove Facebook from my profile and make this a site account"></p>';			

	}
	else if ($user->facebook == 'synced')
	{
		$facebook_uid = $user->facebook_uid;
		?>
<h3><?php echo elgg_echo('fbconnect:facebook_login_title'); ?></h3>

<p><?php echo elgg_echo('fbconnect:facebook_update_profile'); ?></p>

		<?php
		//echo '<p>'.elgg_view('input/text',array('internalname' => "facebook_uid", 'value' => $facebook_uid)).'<br>';
		echo '<input type="button" onClick="$.ajax({
   type: \'POST\',
   url: \''.$CONFIG->url.'action/fbconnect/addemail\',
   data: \'facebook_update=true&guid='.$user->guid.'\',
   success: function(msg){
     alert( \'Your account has been updated! \');
   }
 });
 " value="Update my profile from Facebook"></p>';

		echo '<input type="button" onClick="$.ajax({
   type: \'POST\',
   url: \''.$CONFIG->url.'action/fbconnect/addemail\',
   data: \'remove_facebook_account=true&guid='.$user->guid.'\',
   success: function(msg){
     alert( \'Your account has been updated! \');
     $(document).reload(); 
   }
 });
" value="Remove Facebook from my profile"></p>';		


	}
}
else
{
	?>
<h3><?php echo elgg_echo('fbconnect:facebook_login_title'); ?></h3>

<p><?php echo sprintf(elgg_echo('fbconnect:facebook_login_description'), $CONFIG->site->name); ?></p>

<script
	src="http://static.ak.connect.facebook.com/js/api_lib/v0.4/FeatureLoader.js.php"
	type="text/javascript"></script>
<fb:login-button onlogin="facebook_onlogin();" v="2" size="large">Connect with Facebook</fb:login-button><br /><br />
<script type="text/javascript">
function facebook_onlogin() {
	document.location.href = "<?php echo $vars['url'] ?>action/fbconnect/login";
}
FB.init("<?php echo get_plugin_setting('api_key', 'fbconnect'); ?>", "<?php echo $vars['url']; ?>mod/fbconnect/xd_receiver.html"); 
</script>
</br>
</br>
</br>
	<?php
}
?>