<?php

global $CONFIG;
$user_load_header = get_loggedin_user();
$userHeader = get_entity($user_load_header->guid);
if(isset($userHeader->facebook_uid))
{
	
	if(strlen($userHeader->email) < 7)
	{
		$email_exists = true;

		//starting off assuming its not a new user
	}

	if($email_exists && $_SESSION['fbconnect_addemail']['email_exists'] != true && $_SESSION['fbconnect_addemail']['new_user'] !=true )
	{
		$form_body = "<p class=\"emailbox\"><center>";
		$form_body .= "<label> Email Address: " . elgg_view('input/text', array('internalname' => 'email', 'class' => 'login-textarea')) . "</label>";
		$form_body .= elgg_view('input/submit', array('value' =>'submit' )) . "";
		$form_body .= "</center></p>";

		$login_url = $vars['url'];
		if ((isset($CONFIG->https_login)) && ($CONFIG->https_login))
		$login_url = str_replace("http", "https", $vars['url']);
		?>

<div class="fbconnect-box">
<h2>Email Verification</h2>
<div class="fbconnect-box-content">
<p><?php echo sprintf(elgg_echo('fbconnect:add_email_address'), $CONFIG->site->name ); ?></p>

		<?php echo elgg_view('input/form', array('body' => $form_body, 'action' => $CONFIG->url . "action/fbconnect/addemail")); ?>
</div>
</div>


		<?
	}

	else if($email_exists && $_SESSION['fbconnect_addemail']['email_exists'] == true && $_SESSION['fbconnect_addemail']['new_user'] != true && $_SESSION['fbconnect_addemail']['syncAccts'] != true)
	{
		$form_body = "<p class=\"emailconfirm-box\"><center>";
		$form_body .= '<br /> <input type="radio" name="syncacct" value="yes" CHECKED> Sync my Facebook Account &nbsp;|&nbsp; <input type="radio" name="syncacct" value="no">Create a seperate account';
		$form_body .= '<br><input type="hidden" value="'.$_SESSION['fbconnect_addemail']['email'].'" name="user_email"/>';
		$form_body .= elgg_view('input/submit', array('value' =>'submit' )) . "</center></p>";

		$login_url = $vars['url'];
		if ((isset($CONFIG->https_login)) && ($CONFIG->https_login))
		$login_url = str_replace("http", "https", $vars['url']);
		?>

<div class="fbconnect-box">
<h2>Check It Out</h2>
<div class="fbconnect-box-content">
<p><?php echo sprintf(elgg_echo('fbconnect:sync_current_profile'), $CONFIG->site->name ); ?></p>

		<?php
		echo elgg_view('input/form', array('body' => $form_body, 'action' => $CONFIG->url . "action/fbconnect/addemail"));
		?></div>
</div>
		<?
	}
	else if($email_exists && $_SESSION['fbconnect_addemail']['email_exists'] == true && $_SESSION['fbconnect_addemail']['new_user'] != true && $_SESSION['fbconnect_addemail']['pass_verified'] != true && $_SESSION['fbconnect_addemail']['syncAccts'] == true)
	{
		$form_body = "<p class=\"emailbox\"><center>";
		$form_body .= "<label> Password: <input type=\"password\" name=\"p4550rd\"></label>";
		$form_body .= '<input type="hidden" value="'.$_SESSION['fbconnect_addemail']['email'].'" name="user_email"/>';
		$form_body .= '<input type="hidden" value="'.$_SESSION['fbconnect_addemail']['syncAccts_val'].'" name="user_email"/>';
		$form_body .= elgg_view('input/submit', array('value' =>'submit' )) . "";
		$form_body .= "</center></p>";

		$login_url = $vars['url'];
		if ((isset($CONFIG->https_login)) && ($CONFIG->https_login))
		$login_url = str_replace("http", "https", $vars['url']);
		?>

<div class="fbconnect-box">
<h2>One More Thing</h2>
<div class="fbconnect-box-content">
<p><?php echo sprintf(elgg_echo('fbconnect:sync_current_profile_pass'), $CONFIG->site->name); ?></p>
		<?php
		echo elgg_view('input/form', array('body' => $form_body, 'action' => $CONFIG->url . "action/fbconnect/addemail"));
		?></div>
</div>
		<?
	}
	else if($email_exists && $_SESSION['fbconnect_addemail']['new_user'] == true)
	{
		if(($userHeader instanceof ElggUser))
		{
			set_user_validation_status($userHeader->guid, true, 'admin');
			$userHeader->enable();
			$userHeader->email = $_SESSION['fbconnect_addemail']['email'];
			$password = generate_random_cleartext_password();
			$userHeader->salt = generate_random_cleartext_password();
			$userHeader->password = generate_user_password($userHeader, $password);
			$userHeader->save();

			unset($_SESSION['fbconnect_addemail']);
			notify_user($userHeader->guid, $CONFIG->site->guid, sprintf(elgg_echo('email:validate:success:subject', $userHeader->language), $userHeader->name), sprintf(elgg_echo('fbconnect:facebook_account_created', $userHeader->language), $userHeader->name, $CONFIG->site->name, $CONFIG->site->name, $userHeader->username, $password, $CONFIG->site->url), NULL, 'email');
		}
		else
		{
			echo "User is not a ElggUser";
			exit();
		}
	}

}


?>
