.fbconnect-box {
	margin-left: -250px;
	left: 50%;
	top: 100px;
	padding: 0 0 10px 0;
	background: #dfdfdf;
	-webkit-border-radius: 8px;
	-moz-border-radius: 8px;
	width: 500px;
	text-align: left;
	z-index: 8999;
	position: fixed;
	padding: 10px;
	border: 3px solid #0054a7;
}

.fbconnect-box-content {
 	background: white;
	padding: 10px;
	-webkit-border-radius: 8px;
	-moz-border-radius: 8px;
}

.fbconnect-box h2 {
	color: #0054A7;
	font-size: 1.35em;
	line-height: 1.2em;
	margin-bottom: 5px;
}