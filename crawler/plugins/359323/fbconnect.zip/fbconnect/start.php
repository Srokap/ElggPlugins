<?php

/*********************************
 * Facebook Connect Plugin
 * Version 0.1 Beta - Tested and working on live site
 * Initial code written by Kevin Jardine, heavily modified to work with elgg 1.6.1 with extensive
 * functional changes by Levi De Haan at Springs Hosting
 *
 * License http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 *********************************/

function fbconnect_init()
{
	// Load system configuration
	global $CONFIG;

	//get the current user if they are logged in.
	$user_load = get_loggedin_user();
	$user = get_entity($user_load->guid);
	// Load the language files
	register_translations($CONFIG->pluginspath . "fbconnect/languages/");

	register_page_handler('fbconnect', 'fbConnect_page_handler');

	extend_view("page_elements/header", "fbconnect/header");
	extend_view("account/forms/login", "fbconnect/login");

	// Extend system CSS with our own styles
	extend_view('css','fbconnect/css');

	register_plugin_hook('usersettings:save','user','fbconnect_user_settings_save');
	register_plugin_hook('action', 'logout', 'log_user_out_of_facebook');

	register_action('fbconnect/addemail', false, $CONFIG->pluginspath . "fbconnect/actions/addemail.php");
}

function log_user_out_of_facebook($hook, $entity_type, $returnvalue, $params)
{
	global $CONFIG;

	if(isset($_SESSION['user']->facebook_uid))
	{
		if (fbconnect_client()) {
			try {
				logout();
				$fb_connect = fbconnect_client();
				$fb_connect->logout($CONFIG->site->url);
			} catch (Exception $e) {
				error_log('Exception thrown while logging out of facebook: '. $e->getMessage());
			}
		}
	}
}

function fbconnect_pagesetup()
{
	// make profile edit links invisible for Facebook accounts
	// that do not have Facebook control explicitly turned off
	if ((get_context() == 'profile')
	&& ($page_owner_entity = page_owner_entity())
	&& ($page_owner_entity->getSubtype() == "facebook")
	&& ($page_owner_entity->facebook_controlled_profile != 'no')
	) {
		extend_view('metatags','fbconnect/hide_profile_embed');
	}

	extend_elgg_settings_page('fbconnect/settings/usersettings', 'usersettings/user');
}

/**
 * Cron job
 * Every 12 hours we need to update the Facebook information
 *
 */
function fbconnect_cron($hook, $entity_type, $returnvalue, $params)
{
	$i = 0;
	$twelve_hours = 60*60*12;
	set_context('fbconnect');
	// get the Facebook users
	$user_count = get_entities('user','facebook',0,'',10,0,true);
	if ($user_count) {
		$users = get_entities('user','facebook',0,'',$user_count,0,false);
		foreach ($users as $user) {
			// sync the user data with Facebook if the data is older than
			// tweleve hours
			if(($user->facebook_controlled_profile != 'no')&& ((time()-$user->facebook_sync_time) > $twelve_hours)) {
				fbconnect_update_profile($user);
				$i += 1;
			}
		}
	}

	echo sprintf(elgg_echo('fbconnect:cron_report'),$i);
}

register_plugin_hook('cron', 'hourly', 'fbconnect_cron');


function fbconnect_can_edit($hook_name, $entity_type, $return_value, $parameters)
{

	$entity = $parameters['entity'];
	$context = get_context();
	if ($context == 'fbconnect' && $entity->getSubtype() == "facebook") {
		// should be able to update Facebook user data
		return true;
	}
	return null;
}

//---------------
//checks user profile to make sure it can be edited.

register_plugin_hook('permissions_check','user','fbconnect_can_edit');

register_elgg_event_handler('init','system','fbconnect_init');
register_elgg_event_handler('pagesetup','system','fbconnect_pagesetup');

//--------------


function fbconnect_icon_url($hook_name,$entity_type, $return_value, $parameters)
{
	$entity = $parameters['entity'];
	if (in_array($parameters['size'],array('tiny','small','topbar'))) {
		return $entity->facebook_icon_url_mini;
	} else {
		return $entity->facebook_icon_url_normal;
	}

}

function fbconnect_user_settings_save()
{
	gatekeeper();

	$user = page_owner_entity();
	if (!$user) {
		$user = $_SESSION['user'];
	}

	$subtype = $user->getSubtype();

	if ($subtype == 'facebook') {

		$facebook_controlled_profile = get_input('facebook_controlled_profile','yes');

		if ((!$user->facebook_controlled_profile && ($facebook_controlled_profile == 'no'))
		|| ($user->facebook_controlled_profile && ($user->facebook_controlled_profile != $facebook_controlled_profile))
		) {
			$user->facebook_controlled_profile = $facebook_controlled_profile;
			system_message(elgg_echo('fbconnect:user_settings:save:ok'));
		}
	} else if (!$subtype) {

		// users with no subtype (regular Elgg users) are allowed a
		// slave Facebook login
		$facebook_uid = get_input('facebook_uid');
		if ($facebook_uid != $user->facebook_uid) {
			$user->facebook_uid = $facebook_uid;
			system_message(elgg_echo('fbconnect:facebook_login_settings:save:ok'));
		}
	}
}

register_plugin_hook('entity:icon:url','user','fbconnect_icon_url');

/**
 * Get the facebook client object for easy access.
 * @return object
 *   Facebook Api object
 */
function fbconnect_client()
{
	global $CONFIG;
	static $fb = NULL;
	if (!$fb instanceof Facebook) {
		include_once($CONFIG->pluginspath.'fbconnect/facebook-platform/facebook.php');
		$api_key = get_plugin_setting('api_key', 'fbconnect');
		$api_secret = get_plugin_setting('api_secret', 'fbconnect');
		$fb = new Facebook($api_key, $api_secret);
	}
	return $fb;
}

/**
 * Query information from facebook user table.
 *
 * @return array
 */
function fbconnect_get_info_from_fb($fbuid, $fields)
{
	if (fbconnect_client() && $fields) {
		try {
			$result = fbconnect_client()->api_client->fql_query("SELECT $fields FROM user WHERE uid = $fbuid");
			return $result[0];
		} catch (Exception $e) {
			error_log('Exception thrown while using FQL: '. $e->getMessage());
		}
	}
}

function fbconnect_update_profile($user)
{
	$fbuid = $user->facebook_uid;
	$fbprofile = fbconnect_get_info_from_fb($fbuid,'name, pic_big, interests, hometown_location, about_me, status');
	if ($fbprofile) {
		$user->description = $fbprofile['about_me'];
		$user->name = $fbprofile['name'];
		$location = $fbprofile['hometown_location'];
		$location2 = array();
		foreach($location as $item) {
			if ($item)
			$location2[] = $item;
		}
		$user->location = $location2;
		$user->interests = explode(',',$fbprofile['interests']);

		$user->facebook_sync_time = time();
		$user->save();
		thewire_save_post($fbprofile['status']['message'], ACCESS_PUBLIC, 0, 'facebook');
		//Add images to profile
		if(!isset($fbprofile['pic_big']))
		{
			return true;
		}
		elseif(fbconnect_Get_Image_from_FB($fbprofile['pic_big'], $user))
		{
			return true;
		}
		else
		{
			return false;
		}


	}
}


function fbconnect_Get_Image_from_FB($link, $user)
{
	global $CONFIG;

	if(!$user)
	{
		$user = page_owner_entity();
	}

	$file_dir = $CONFIG->path.'/_graphics/temp.jpg';
	$file = file_get_contents($link);

	$file_w = fopen($file_dir, 'w');
	if($file_w)
	{
		$write_file = fwrite($file_w, $file);
		fclose($file_w);
	}
	else
	{
		echo `touch `.$file_dir;
		$write_file = fwrite($file_w, $file);
		fclose($file_w);
	}

	$profile_iconw = get_plugin_setting('Profile_Iconw', 'fbconnect');
	$profile_iconh = get_plugin_setting('Profile_Iconh', 'fbconnect');
	$topbar_iconw = get_plugin_setting('Top_bar_Iconw', 'fbconnect');
	$topbar_iconh = get_plugin_setting('Top_bar_Iconh', 'fbconnect');

	if($profile_iconw != false && $profile_iconh != false)
	{
		$large = get_resized_image_from_existing_file($file_dir,$profile_iconw,$profile_iconh);
	}
	else
	{
		$large = get_resized_image_from_existing_file($file_dir,200,200);
	}

	if($topbar_iconw != false && $topbar_iconh != false)
	{
		$topbar = get_resized_image_from_existing_file($file_dir,$topbar_iconw,$topbar_iconh, true);
	}
	else
	{
		$topbar = get_resized_image_from_existing_file($file_dir,16,16, true);
	}

	$tiny = get_resized_image_from_existing_file($file_dir,25,25, true);
	$small = get_resized_image_from_existing_file($file_dir,40,40, true);
	$medium = get_resized_image_from_existing_file($file_dir,100,100, true);

	$master = get_resized_image_from_existing_file($file_dir,550,550);

	if ($small !== false && $medium !== false && $large !== false && $tiny !== false)
	{

		$filehandler = new ElggFile();
		$filehandler->owner_guid = $user->getGUID();
		$filehandler->setFilename("profile/" . $user->username . "large.jpg");
		$filehandler->open("write");
		$filehandler->write($large);
		$filehandler->close();
		$filehandler->setFilename("profile/" . $user->username . "medium.jpg");
		$filehandler->open("write");
		$filehandler->write($medium);
		$filehandler->close();
		$filehandler->setFilename("profile/" . $user->username . "small.jpg");
		$filehandler->open("write");
		$filehandler->write($small);
		$filehandler->close();
		$filehandler->setFilename("profile/" . $user->username . "tiny.jpg");
		$filehandler->open("write");
		$filehandler->write($tiny);
		$filehandler->close();
		$filehandler->setFilename("profile/" . $user->username . "topbar.jpg");
		$filehandler->open("write");
		$filehandler->write($topbar);
		$filehandler->close();
		$filehandler->setFilename("profile/" . $user->username . "master.jpg");
		$filehandler->open("write");
		$filehandler->write($master);
		$filehandler->close();
			
		$user->icontime = time();
			
		trigger_elgg_event('profileiconupdate',$user->type,$user);
			
		add_to_river('river/user/default/profileiconupdate','update',$user->guid,$user->guid);
		return true;
	}
	else
	{
		system_message(elgg_echo("profile:icon:notfound"));
		return false;
	}
}

function facebook_email_hash($email)
{
	$normalizedAddress = trim(strtolower($email));
	//crc32 outputs signed int
	$crc = crc32($normalizedAddress);
	//output in unsigned int format
	$unsignedCrc = sprintf('%u', $crc);
	$md5 = md5($normalizedAddress);
	return "{$unsignedCrc}_{$md5}";
}

// Register actions

global $CONFIG;

register_action("fbconnect/login",false,$CONFIG->pluginspath . "fbconnect/actions/login.php");

?>