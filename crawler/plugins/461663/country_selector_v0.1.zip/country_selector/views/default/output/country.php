<?php 
	/**
	* Country Selector
	* 
	* Output view for Country selection
	* 
	* @package country_selector
	* @author ColdTrick IT Solutions
	* @copyright Coldtrick IT Solutions 2009
	* @link http://www.coldtrick.com/
	* @version 0.1
	*/

	echo elgg_echo("country_code:" . strtolower($vars["value"]));

?>