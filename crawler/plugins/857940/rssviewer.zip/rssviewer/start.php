<?php

	/**
	 * Elgg Feed widget
	 * This simple plugin allows users to view rss and atom feeds in Elgg.
	 * 
	 * @package ElggFeeds
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author I Like Different (mike@ilikedifferent.com)
	 * @copyright I Like Different Ltd 2012
	 * 
	 */
	 
	function rssviewer_init() {
	elgg_register_widget_type('rssviewer', 'RSS Viewer', 'The RSS Viewer widget');
	}
	
	elgg_register_event_handler('init', 'system', 'rssviewer_init');
?>
