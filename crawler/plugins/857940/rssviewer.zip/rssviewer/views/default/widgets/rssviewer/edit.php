<div>
    <label>Enter RSS:</label> 
<?php 
    //This is an instance of the ElggWidget class that represents our widget.
    $widget = $vars['entity'];
 
    // Give the user a plain text box to input a message
    echo elgg_view('input/text', array(
        'name' => 'params[rssfeed]', 
        'value' => $widget->rssfeed,
        'class' => 'hello-input-text',
    )); 
?>
	
	<label>Number of Articles to Show:</label>

<?php
	$widget = $vars['entity'];
	echo elgg_view('input/text', array(
        'name' => 'params[articlecount]', 
        'value' => $widget->articlecount,
        'class' => 'hello-input-text',
    )); 
?>
<br />
Find an RSS feed at <a href="http://www.feedage.com/" target="_new">Feedage.com</a>
</div>
