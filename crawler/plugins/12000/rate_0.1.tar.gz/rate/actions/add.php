<?php
/**
 *	RATE PLUGIN
 *	@package rate
 *	@author Miguel Montes mmontesp@gmail.com
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Miguel Montes 2008
 *	@link http://community.elgg.org/pg/profile/mmontesp
 **/

//Aseguramos la acción - Make sure action is secure
	gatekeeper();
	action_gatekeeper();
	
//Conseguimos los parámetros de entrada - Get input data
	$guid = (int) get_input('guid');
	$rate = (int) get_input('rate');

//Intentamos conseguir la entidad sobre la que vamos a votar - Make sure we actually have the entity
	if (!$entity = get_entity($guid)){
		register_error(elgg_echo('rate:badguid'));
		forward();
	}

//Comprobamos si la puntuación es correcta, si lo es convertimos la puntuacion a formato [0 - 5]
// Make sure we have a correct rate
	if ($rate && ($rate >= 1 || $rate <= 6)){
		$rate--; 
	}else{
		register_error(elgg_echo('rate:badrate'));
		forward($entity->getUrl());
	}

//Comprobamos si ya hemos votado - We have rated before?	
	//if (count_annotations ($entity->guid, $entity->getType(), $entity->getSubtype(), 'generic_rate', "", "", $_SESSION['guid'])){
	if (!allow_rate($entity)){
		register_error(elgg_echo('rate:rated'));
		forward($entity->getUrl());
	}
	
//Si no hemos votado votamos - Let's go rate
	if ($entity->annotate('generic_rate', $rate, 2, $_SESSION['guid'])){
		system_message(elgg_echo('rate:saved'));
	}else{
		register_error(elgg_echo('rate:error'));
	}
	
	forward($entity->getUrl());
	

?>