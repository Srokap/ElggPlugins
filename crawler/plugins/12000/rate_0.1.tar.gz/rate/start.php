<?php
/**
 *	RATE PLUGIN
 *	@package rate
 *	@author Miguel Montes mmontesp@gmail.com
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Miguel Montes 2008
 *	@link http://community.elgg.org/pg/profile/mmontesp
 **/

//Inicio - Start
function rate_init(){
	global $CONFIG;
	// Registrar los ficheros de idiomas
	register_translations($CONFIG->pluginspath . "rate/languages/");
	//Extendemos la vista css
	extend_view('css', 'rate/css');
}

//Eventos - Events
register_elgg_event_handler('init','system','rate_init');

// la función count_annotations no hace nada con el guid del propietario
// asi que tendremos que hacer una pequeña función
// count_annotations dont works fine, it does anythig with the given owner_guid
// the we have a little function...
function allow_rate ($entity){
	if (isloggedin()){
		$annotations = $entity->getAnnotations('generic_rate');
		foreach ($annotations as $annotation){
			if ($annotation->owner_guid == $_SESSION['guid']){
				return false;
			}
		}
		return true;
	}else{
		return false;
	}
}

//Acciones - Actions
register_action("rate/add",false,$CONFIG->pluginspath . "rate/actions/add.php");

?>