<?php
/**
 *	RATE PLUGIN
 *	@package rate
 *	@author Miguel Montes mmontesp@gmail.com
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Miguel Montes 2008
 *	@link http://community.elgg.org/pg/profile/mmontesp
 **/



$opt = array(elgg_echo("rate:0")=>1, elgg_echo("rate:1")=>2, elgg_echo("rate:2")=>3, elgg_echo("rate:3")=>4, elgg_echo("rate:4")=>5, elgg_echo("rate:5")=>6);

$rate = $vars['entity']->getAnnotationsAvg('generic_rate');
$image = round($rate*2);
$rate = $image/2;

echo "<img src='{$CONFIG->wwwroot}mod/rate/_graphics/$image.gif' alt='$rate' title='$rate'/> (".$vars['entity']->countAnnotations('generic_rate')." ".elgg_echo("rate:rates").")";

//Solo mostramos el formulario para usuarios logueados que no hayan votado aun
//We show the form if the user is legged in and it hasn't rate yet
gatekeeper();

//if (!count_annotations($vars['entity']->guid, $vars['entity']->getType(), $vars['entity']->getSubtype(), 'generic_rate', "", "", $_SESSION['guid'])){
if (allow_rate($vars['entity'])){
	$form_body = "<p><label>".elgg_echo("rate:text")."</label></p>";
	$form_body .= "<p>" . elgg_view('input/hidden', array('internalname' => 'guid', 'value' => $vars['entity']->getGUID()));
	$form_body .= "<p>" . elgg_view('input/rate', array('internalname' => 'rate', 'options' => $opt));
	$form_body .= elgg_view('input/submit', array('value' => elgg_echo("rate:rateit"))) . "</p>";

	echo elgg_view('input/form', array('body' => $form_body, 'action' => "{$vars['url']}action/rate/add"));	
}

?>