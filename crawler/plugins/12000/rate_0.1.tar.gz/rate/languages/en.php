<?php
/**
 *	RATE PLUGIN
 *	@package rate
 *	@author Miguel Montes mmontesp@gmail.com
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Miguel Montes 2008
 *	@link http://community.elgg.org/pg/profile/mmontesp
 **/

	$english = array(
		'rate:rates' => "Rates",
		'rate:rateit' => "Rate it",
		'rate:text' => "Do you like it?",
		'rate:rated' => "You have rated it before.",
		'rate:badguid' => "Error, we haven't found any item to rate.",
		'rate:badrate' => "Rate must be from 0 to 5.",
		'rate:saved' => "Your rate has been saved.",
		'rate:error' => "Your rate could not be saved. Please try again.",
		'rate:0' => "Very bad (0)",
		'rate:1' => "Bad (1)",
		'rate:2' => "Good (2)",
		'rate:3' => "Cool (3)",
		'rate:4' => "Amazing (4)",
		'rate:5' => "Awesome (5)",
	);
	add_translation("en",$english);
?>