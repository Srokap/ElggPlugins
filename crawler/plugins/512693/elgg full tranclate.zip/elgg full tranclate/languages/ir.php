<?php
/**
 * Activity viewer
 *
 * @package Elgg
 * @subpackage Core
 * @author Curverider Ltd
 * @link http://elgg.org/
 */

$farsi = array(

/**
 * Sites
 */

	'item:site' => 'Sites',

/**
 * Sessions
 */

    'login' => "ورود",
	'loginok' => "شما با موفقيت وارد شديد",
	'loginerror' => "ما نتوانستیم شما را وارد سایت کنیم. این ممکن است به خاطر این باشد که شما هنوز ایمیل ارسالی از طرف سایت را فعال نکرده اید, یا اطلاعاتی که شما داده اید نامعتبر باشد, یا قسمتی را برای ورود اشتباه پر کرده باشید. مطمئن باشید که اطلاعات وارد شده درست باشد و دوباره تلاش کنید.",

	'logout' => "خروج",
	'logoutok' => "شما با موفقيت خارج شديد",
	'logouterror' => "ما نمیتوایم شما را از سایت خارج کنیم لطفا دوباره تلاش کنید",

	'loggedinrequired' => "برای دیدن صفحه مورد نظر شما باید وارد سایت شوید",
	'adminrequired' => "برای دیدن صفحه مورد نظر شما باید مدیر باشید",

/**
 * Errors
 */
	'exception:title' => "به جمع ما خوش آمديد",

	'InstallationException:CantCreateSite' => "Unable to create a default ElggSite with credentials Name:%s, Url: %s",

	'actionundefined' => "The requested action (%s) was not defined in the system.",
	'actionloggedout' => "Sorry, you cannot perform this action while logged out.",

	'SecurityException:Codeblock' => "Denied access to execute privileged code block",
	'DatabaseException:WrongCredentials' => "Elgg couldn't connect to the database using the given credentials.",
	'DatabaseException:NoConnect' => "Elgg couldn't select the database '%s', please check that the database is created and you have access to it.",
	'SecurityException:FunctionDenied' => "Access to privileged function '%s' is denied.",
	'DatabaseException:DBSetupIssues' => "There were a number of issues: ",
	'DatabaseException:ScriptNotFound' => "Elgg couldn't find the requested database script at %s.",

	'IOException:FailedToLoadGUID' => "Failed to load new %s from GUID:%d",
	'InvalidParameterException:NonElggObject' => "Passing a non-ElggObject to an ElggObject constructor!",
	'InvalidParameterException:UnrecognisedValue' => "Unrecognised value passed to constuctor.",

	'InvalidClassException:NotValidElggStar' => "GUID:%d is not a valid %s",

	'PluginException:MisconfiguredPlugin' => "%s is a misconfigured plugin. It has been disabled. Please see the Elgg wiki for possible causes.",

	'InvalidParameterException:NonElggUser' => "Passing a non-ElggUser to an ElggUser constructor!",

	'InvalidParameterException:NonElggSite' => "Passing a non-ElggSite to an ElggSite constructor!",

	'InvalidParameterException:NonElggGroup' => "Passing a non-ElggGroup to an ElggGroup constructor!",

	'IOException:UnableToSaveNew' => "Unable to save new %s",

	'InvalidParameterException:GUIDNotForExport' => "GUID has not been specified during export, this should never happen.",
	'InvalidParameterException:NonArrayReturnValue' => "Entity serialisation function passed a non-array returnvalue parameter",

	'ConfigurationException:NoCachePath' => "Cache path set to nothing!",
	'IOException:NotDirectory' => "%s is not a directory.",

	'IOException:BaseEntitySaveFailed' => "Unable to save new object's base entity information!",
	'InvalidParameterException:UnexpectedODDClass' => "import() passed an unexpected ODD class",
	'InvalidParameterException:EntityTypeNotSet' => "Entity type must be set.",

	'ClassException:ClassnameNotClass' => "%s is not a %s.",
	'ClassNotFoundException:MissingClass' => "Class '%s' was not found, missing plugin?",
	'InstallationException:TypeNotSupported' => "Type %s is not supported. This indicates an error in your installation, most likely caused by an incomplete upgrade.",

	'ImportException:ImportFailed' => "Could not import element %d",
	'ImportException:ProblemSaving' => "There was a problem saving %s",
	'ImportException:NoGUID' => "New entity created but has no GUID, this should not happen.",

	'ImportException:GUIDNotFound' => "Entity '%d' could not be found.",
	'ImportException:ProblemUpdatingMeta' => "There was a problem updating '%s' on entity '%d'",

	'ExportException:NoSuchEntity' => "No such entity GUID:%d",

	'ImportException:NoODDElements' => "No OpenDD elements found in import data, import failed.",
	'ImportException:NotAllImported' => "Not all elements were imported.",

	'InvalidParameterException:UnrecognisedFileMode' => "Unrecognised file mode '%s'",
	'InvalidParameterException:MissingOwner' => "File %s (%d) is missing an owner!",
	'IOException:CouldNotMake' => "Could not make %s",
	'IOException:MissingFileName' => "You must specify a name before opening a file.",
	'ClassNotFoundException:NotFoundNotSavedWithFile' => "Filestore not found or class not saved with file!",
	'NotificationException:NoNotificationMethod' => "No notification method specified.",
	'NotificationException:NoHandlerFound' => "No handler found for '%s' or it was not callable.",
	'NotificationException:ErrorNotifyingGuid' => "There was an error while notifying %d",
	'NotificationException:NoEmailAddress' => "Could not get the email address for GUID:%d",
	'NotificationException:MissingParameter' => "Missing a required parameter, '%s'",

	'DatabaseException:WhereSetNonQuery' => "Where set contains non WhereQueryComponent",
	'DatabaseException:SelectFieldsMissing' => "Fields missing on a select style query",
	'DatabaseException:UnspecifiedQueryType' => "Unrecognised or unspecified query type.",
	'DatabaseException:NoTablesSpecified' => "No tables specified for query.",
	'DatabaseException:NoACL' => "No access control was provided on query",

	'InvalidParameterException:NoEntityFound' => "No entity found, it either doesn't exist or you don't have access to it.",

	'InvalidParameterException:GUIDNotFound' => "GUID:%s could not be found, or you can not access it.",
	'InvalidParameterException:IdNotExistForGUID' => "Sorry, '%s' does not exist for guid:%d",
	'InvalidParameterException:CanNotExportType' => "Sorry, I don't know how to export '%s'",
	'InvalidParameterException:NoDataFound' => "Could not find any data.",
	'InvalidParameterException:DoesNotBelong' => "Does not belong to entity.",
	'InvalidParameterException:DoesNotBelongOrRefer' => "Does not belong to entity or refer to entity.",
	'InvalidParameterException:MissingParameter' => "Missing parameter, you need to provide a GUID.",

	'APIException:ApiResultUnknown' => "API Result is of an unknown type, this should never happen.",
	'ConfigurationException:NoSiteID' => "No site ID has been specified.",
	'SecurityException:APIAccessDenied' => "Sorry, API access has been disabled by the administrator.",
	'SecurityException:NoAuthMethods' => "No authentication methods were found that could authenticate this API request.",
	'InvalidParameterException:APIMethodOrFunctionNotSet' => "Method or function not set in call in expose_method()",
	'InvalidParameterException:APIParametersArrayStructure' => "Parameters array structure is incorrect for call to expose method '%s'",
	'InvalidParameterException:UnrecognisedHttpMethod' => "Unrecognised http method %s for api method '%s'",
	'APIException:MissingParameterInMethod' => "Missing parameter %s in method %s",
	'APIException:ParameterNotArray' => "%s does not appear to be an array.",
	'APIException:UnrecognisedTypeCast' => "Unrecognised type in cast %s for variable '%s' in method '%s'",
	'APIException:InvalidParameter' => "Invalid parameter found for '%s' in method '%s'.",
	'APIException:FunctionParseError' => "%s(%s) has a parsing error.",
	'APIException:FunctionNoReturn' => "%s(%s) returned no value.",
	'APIException:APIAuthenticationFailed' => "Method call failed the API Authentication",
	'APIException:UserAuthenticationFailed' => "Method call failed the User Authentication",
	'SecurityException:AuthTokenExpired' => "Authentication token either missing, invalid or expired.",
	'CallException:InvalidCallMethod' => "%s must be called using '%s'",
	'APIException:MethodCallNotImplemented' => "Method call '%s' has not been implemented.",
	'APIException:FunctionDoesNotExist' => "Function for method '%s' is not callable",
	'APIException:AlgorithmNotSupported' => "Algorithm '%s' is not supported or has been disabled.",
	'ConfigurationException:CacheDirNotSet' => "Cache directory 'cache_path' not set.",
	'APIException:NotGetOrPost' => "Request method must be GET or POST",
	'APIException:MissingAPIKey' => "Missing API key",
	'APIException:BadAPIKey' => "Bad API key",
	'APIException:MissingHmac' => "Missing X-Elgg-hmac header",
	'APIException:MissingHmacAlgo' => "Missing X-Elgg-hmac-algo header",
	'APIException:MissingTime' => "Missing X-Elgg-time header",
	'APIException:MissingNonce' => "Missing X-Elgg-nonce header",
	'APIException:TemporalDrift' => "X-Elgg-time is too far in the past or future. Epoch fail.",
	'APIException:NoQueryString' => "No data on the query string",
	'APIException:MissingPOSTHash' => "Missing X-Elgg-posthash header",
	'APIException:MissingPOSTAlgo' => "Missing X-Elgg-posthash_algo header",
	'APIException:MissingContentType' => "Missing content type for post data",
	'SecurityException:InvalidPostHash' => "POST data hash is invalid - Expected %s but got %s.",
	'SecurityException:DupePacket' => "Packet signature already seen.",
	'SecurityException:InvalidAPIKey' => "Invalid or missing API Key.",
	'NotImplementedException:CallMethodNotImplemented' => "Call method '%s' is currently not supported.",

	'NotImplementedException:XMLRPCMethodNotImplemented' => "XML-RPC method call '%s' not implemented.",
	'InvalidParameterException:UnexpectedReturnFormat' => "Call to method '%s' returned an unexpected result.",
	'CallException:NotRPCCall' => "Call does not appear to be a valid XML-RPC call",

	'PluginException:NoPluginName' => "The plugin name could not be found",

	'ConfigurationException:BadDatabaseVersion' => "The database backend you have installed doesn't meet the basic requirements to run Elgg. Please consult your documentation.",
	'ConfigurationException:BadPHPVersion' => "You need at least PHP version 5.2 to run Elgg.",
	'configurationwarning:phpversion' => "Elgg requires at least PHP version 5.2, you can install it on 5.1.6 but some features may not work. Use at your own risk.",


	'InstallationException:DatarootNotWritable' => "Your data directory %s is not writable.",
	'InstallationException:DatarootUnderPath' => "Your data directory %s must be outside of your install path.",
	'InstallationException:DatarootBlank' => "You have not specified a data directory.",

	'SecurityException:authenticationfailed' => "User could not be authenticated",

	'CronException:unknownperiod' => '%s is not a recognised period.',

	'SecurityException:deletedisablecurrentsite' => 'You can not delete or disable the site you are currently viewing!',

	'memcache:notinstalled' => 'PHP memcache module not installed, you must install php5-memcache',
	'memcache:noservers' => 'No memcache servers defined, please populate the $CONFIG->memcache_servers variable',
	'memcache:versiontoolow' => 'Memcache needs at least version %s to run, you are running %s',
	'memcache:noaddserver' => 'Multiple server support disabled, you may need to upgrade your PECL memcache library',

	'deprecatedfunction' => 'Warning: This code uses the deprecated function \'%s\' and is not compatible with this version of Elgg',

	'pageownerunavailable' => 'Warning: The page owner %d is not accessible!',
/**
 * API
 */
	'system.api.list' => "List all available API calls on the system.",
	'auth.gettoken' => "This API call lets a user obtain a user authentication token which can be used for authenticating future API calls. Pass it as the parameter auth_token",

/**
 * User details
 */

    'name' => "نمایش اسم",
	'email' => "ایمیل آدرس",
	'username' => "نام کاربری",
	'password' => "رمز عبور",
	'passwordagain' => "تایید رمز عبور",
	'admin_option' => "این کاربر ادمین شود?",

/**
 * Access
 */

    'PRIVATE' => "خصوصی",
	'LOGGED_IN' => "کاربرانی که وارد سایت شدند",
	'PUBLIC' => "عمومی",
	'access:friends:label' => "دوستان",
	'access' => "دسترسی",

/**
 * Dashboard and widgets
 */

    'dashboard' => "Dashboard",
	'dashboard:configure' => "ویرایش صفحه",
	'dashboard:nowidgets' => "Your dashboard is your gateway into the site. Click 'Edit page' to add widgets to keep track of content and your life within the system.",

	'widgets:add' => 'Add widgets to your page',
	'widgets:add:description' => "Choose the features you want to add to your page by dragging them from the <b>Widget gallery</b> on the right, to any of the three widget areas below, and position them where you would like them to appear.

To remove a widget drag it back to the <b>Widget gallery</b>.",
	'widgets:position:fixed' => '(Fixed position on page)',

	'widgets' => "جعبه ها",
	'widget' => " جعبه",
	'item:object:widget' => "جعبه هاا",
	'layout:customise' => "تنظیمات طرح بندی",
	'widgets:gallery' => "جعبه  گالری",
	'widgets:leftcolumn' => "بخشهای چپ",
	'widgets:fixed' => "موقعیت ثابت",
	'widgets:middlecolumn' => "بخش میانی",
	'widgets:rightcolumn' => "بخش راست",
	'widgets:profilebox' => "جعبه پروفایل",
	'widgets:panel:save:success' => "بخش جعبه امکانات با موفقیت ذخیره شد.",
	'widgets:panel:save:failure' => "There was a problem saving your widgets. Please try again.",
	'widgets:save:success' => "The widget was successfully saved.",
	'widgets:save:failure' => "We could not save your widget. Please try again.",
	'widgets:handlernotfound' => 'This widget is either broken or has been disabled by the site administrator.',

/**
 * Groups
 */

	'group' => "گروه",
	'item:group' => "گروهها",

/**
 * Users
 */

	'user' => "کاربر",
	'item:user' => "کاربران",

/**
 * Friends
 */

	'friends' => "دوستان",
	'friends:yours' => "دوستان شما",
	'friends:owned' => "%s's دوستان",
	'friend:add' => "اضافه کردن به عنوان دوست",
	'friend:remove' => "برداشتن از دوستی",

	'friends:add:successful' => "شما با موفقیت انتخاب کردید %s به عنوان دوست.",
	'friends:add:failure' => "ما نتوانستیم اضافه کنیم %s به عنوان دوست. لطفا دوباره امتحان کنید.",

	'friends:remove:successful' => "شما با موفقیت برداشتید %s از لیست دوستانتان.",
	'friends:remove:failure' => "ما نمیتوانیم برداریم %s از لیست دوستانان. لطفا دوباره امتحان کنید.",

	'friends:none' => "این کاربر هنوز کسی را به عنوان دوست  انتخاب نکرده است.",
	'friends:none:you' => "شما هنوز کسی را به عنوان دوست انتخاب نکرده اید! برای پیدا کردن دوست مورد علاقه خود میتوانید جستجو را شروع کنید.",

	'friends:none:found' => "هیچ دوستی یافت نشد.",

	'friends:of:none' => "هیچ کاربر این عضو را به عنوان دوست انتخاب نکرده است.",
	'friends:of:none:you' => "کسی شما را به عنوان دوست انتخاب نکرده است.شما میتوانید شروع به اضافه کردن آیتمها عکس بلاگ کنید و قسمتهای مختلف پروفایلتان را تکمیل کنید تا دیگران شما را بهتر بشناسند!",

	'friends:of:owned' => "کسانی که انتخاب کرده اند %s به عنوان دوست",

	'friends:num_display' => "تعداد دوستان برای نمایش",
	'friends:icon_size' => "سایز آیکون",
	'friends:tiny' => "خیلی کوچک",
	'friends:small' => "کوچک",
	'friends:of' => "دوستان",
	'friends:collections' => "مجموعه دوستان",
	'friends:collections:add' => "مجموعه دوستان جدید",
	'friends:addfriends' => "اضافه کردن دوست",
	'friends:collectionname' => "نام مجموعه",
	'friends:collectionfriends' => "دوستان در مجموعه",
	'friends:collectionedit' => "ویرایش این مجموعه",
	'friends:nocollections' => "شما هنوز هیچ مجموعه ایی ندارید.",
	'friends:collectiondeleted' => "مجموعه شما پاک شد.",
	'friends:collectiondeletefailed' => "We were unable to delete the collection. Either you don't have permission, or some other problem has occurred.",
	'friends:collectionadded' => "Your collection was successfuly created",
	'friends:nocollectionname' => "شما باید برای مجموعه خود قبل از اینکه آن را ایجاد کنید نامی انتخاب کنید.",
	'friends:collections:members' => "اعضای مجموعه",
	'friends:collections:edit' => "ویرایش مجموعه",

	'friends:river:created' => "%sبخش جعبه دوستان را اضافه کرد.",
	'friends:river:updated' => "%s بخش جعبه دوستان را آپدیت کرد.",
	'friends:river:delete' => "%s بخش جعبه دوستان را حذف کرد.",
	'friends:river:add' => "%s الان دوست هست با",

	'friendspicker:chararray' => 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',

/**
 * Feeds
 */
	'feed:rss' => 'Subscribe to feed',
	'feed:odd' => 'Syndicate OpenDD',

/**
 * links
 **/

	'link:view' => 'نمایش لینک',


/**
 * Plugins
 */
    'river' => "River",
	'river:relationship:friend' => 'الان دوست هست با',
	'river:noaccess' => 'شما برای دیدن این بخش اجازه ندارید.',
	'river:posted:generic' => '%s ارسال کرد',
	'riveritem:single:user' => 'یک کاربر',
	'riveritem:plural:user' => 'بعضی از کاربران',

/**
 * Notifications
 */
	'notifications:usersettings' => "Notification settings",
	'notifications:methods' => "Please specify which methods you want to permit.",

	'notifications:usersettings:save:ok' => "Your notification settings were successfully saved.",
	'notifications:usersettings:save:fail' => "There was a problem saving your notification settings.",

	'user.notification.get' => 'Return the notification settings for a given user.',
	'user.notification.set' => 'Set the notification settings for a given user.',
/**
 * Search
 */

    'search' => "جستجو",
	'searchtitle' => "جستجوی: %s",
	'users:searchtitle' => "جستجو برای کاربران: %s",
	'groups:searchtitle' => "جستجو برای گروهها: %s",
	'advancedsearchtitle' => "%s مشاهده نتایج تطبیق %s",
	'notfound' => "هیچ نتیجه ایی یافت نشد.",
	'next' => "Next",
	'previous' => "قبلی",

	'viewtype:change' => "Change listing type",
	'viewtype:list' => "مشاهده لیست",
	'viewtype:gallery' => "گالری",

	'tag:search:startblurb' => "Items with tags matching '%s':",

	'user:search:startblurb' => "مطابقت کاربر '%s':",
	'user:search:finishblurb' => "برای دیدن بیشتر اینجا کلیک کنید.",

	'group:search:startblurb' => "مطابقت گروه '%s':",
	'group:search:finishblurb' => "برای دیدن بیشتر اینجا کلیک کنید.",
	'search:go' => 'Go',
	'userpicker:only_friends' => 'فقط دوستان',

/**
 * Account
 */

    'account' => "حساب کاربر",
	'settings' => "تنظیمات",
	'tools' => "ابزار",
	'tools:yours' => "ابزار شما",

	'register' => "ثبـت نام",
	'registerok' => "شما با موقیت ثبت نام کردید برای  %s.",
	'registerbad' => "ثبت نام شما انجام  نشد. ممکن است نام کاربری شما هم اکنون در سایت وجود داشته باشد, یا پسوردهای شما با هم مطابقت نمیکنند, یا نام کاربری یا پسورد شما بسیار کوتاه باشد.",
	'registerdisabled' => "ثبت نام شما توسط مدیران سایت غیر فعال شد",

	'firstadminlogininstructions' => 'Your new Elgg site has been successfully installed and your administrator account created. You can now configure your site further by enabling various installed plugin tools.',

	'registration:notemail' => 'ایمیل آدرس شما ایمیل آدرس معتبری به نظر نمیرسد.',
	'registration:userexists' => 'این نام کاربری هم اکنون در سایت وجود دارد',
	'registration:usernametooshort' => 'نام کاربری شما حداقل باید چهار کاراکتر داشته باشد.',
	'registration:passwordtooshort' => 'پسورد شما حداقل باید 6 کاراکتر داشته باشد.',
	'registration:dupeemail' => 'این ایمیل آدرس هم اکنون در سایت ثبت شده.',
	'registration:invalidchars' => 'متاسفیم اسم کاربری شما از کاراکترهای نامعتبر تشکیل شده است.استفاده از علائم و اشکال نا معتبر میباشد.',
	'registration:emailnotvalid' => 'متاسفیم این ایمیل آدرسی که شما وارد کردید نا معتبر به نظر میرسد',
	'registration:passwordnotvalid' => 'پسورد شما نا معتبر میباشد',
	'registration:usernamenotvalid' => 'نام کاربری شما نا معتبر میباشد',

	'adduser' => "اضافه کردن کاربر",
	'adduser:ok' => "شما با موفقیت یک کاربر جدید اضافه کردید.",
	'adduser:bad' => "کاربر جدید نمیتواند ایجاد شود.",

	'item:object:reported_content' => "آیتمهای گزارش شده",

	'user:set:name' => "تنظیمات نام کاربری",
	'user:name:label' => "نام شما",
	'user:name:success' => "اسم شما بر روی سیستم با موفقیت تغییر پیدا کرد.",
	'user:name:fail' => "نمیتوانید نامتان را در سیستم تغییر دهید. لطفا مطمئن شوید که نام شما خیلی طولانی نباشد و دوباره سعی کنید.",

	'user:set:password' => "رمز عبور حساب",
	'user:password:label' => "پسورد جدید شما",
	'user:password2:label' => "تایپ دوباره رمز عبور",
	'user:password:success' => "رمز عبور تغییر کزد",
	'user:password:fail' => "پسورد شما در این سیستم قابل تغییر نیست.",
	'user:password:fail:notsame' => "دو رمز عبور با هم مطابقت نمیکنند",
	'user:password:fail:tooshort' => "رمز عبورتان خیلی کوتاه است",
	'user:resetpassword:unknown_user' => 'کاربر نا معتبر.',
	'user:resetpassword:reset_password_confirm' => 'برای بدست آوردن پ رمز عبور,رمز عبور جدید به شما ایمیل میشود.',

	'user:set:language' => "تنظیمات زبان",
	'user:language:label' => "زبان شما",
	'user:language:success' => "تغییرات زبان شما آپدیت شد.",
	'user:language:fail' => "تغییرات زبان شما ذخیره نمیشود.",

	'user:username:notfound' => 'نام کاربری %s یافت نشد.',

	'user:password:lost' => 'پسورد را فراموش کرده اید',
	'user:password:resetreq:success' => 'درخواست پسورد شما با موفقیت انجام شد.ایمل خود را چک کنید',
	'user:password:resetreq:fail' => 'نمیتوانید رمز عبور جدید درخواست کنید.',

	'user:password:text' => 'برای ایجاد رمز عبور جدید, نام کاربری خود را در قسمت پایین وارد کنید. We will send the address of a unique verification page to you via email click on the link in the body of the message and a new password will be sent to you.',

	'user:persistent' => 'مرا به یاد بیاور',
/**
 * Administration
 */

    'admin:configuration:success' => "تنظیمات شما ذخیره شد.",
	'admin:configuration:fail' => "تنظیمات شما ذخیره نمیشود.",

	'admin' => "مدیریت",
	'admin:description' => "The admin panel allows you to control all aspects of the system, from user management to how plugins behave. Choose an option below to get started.",

	'admin:user' => "مدیریت کاربر",
	'admin:user:description' => "This admin panel allows you to control user settings for your site. Choose an option below to get started.",
	'admin:user:adduser:label' => "Click here to add a new user...",
	'admin:user:opt:linktext' => "Configure users...",
	'admin:user:opt:description' => "Configure users and account information. ",

	'admin:site' => "Site Administration",
	'admin:site:description' => "This admin panel allows you to control global settings for your site. Choose an option below to get started.",
	'admin:site:opt:linktext' => "Configure site...",
	'admin:site:opt:description' => "Configure the site technical and non-technical settings. ",
	'admin:site:access:warning' => "Changing the access setting only affects the permissions on content created in the future.",

	'admin:plugins' => "Tool Administration",
	'admin:plugins:description' => "This admin panel allows you to control and configure tools installed on your site.",
	'admin:plugins:opt:linktext' => "Configure tools...",
	'admin:plugins:opt:description' => "Configure the tools installed on the site. ",
	'admin:plugins:label:author' => "Author",
	'admin:plugins:label:copyright' => "Copyright",
	'admin:plugins:label:licence' => "Licence",
	'admin:plugins:label:website' => "URL",
	'admin:plugins:label:moreinfo' => 'more info',
	'admin:plugins:label:version' => 'Version',
	'admin:plugins:warning:elggversionunknown' => 'Warning: This plugin does not specify a compatible Elgg version.',
	'admin:plugins:warning:elggtoolow' => 'Warning: This plugin requires a later version of Elgg!',
	'admin:plugins:reorder:yes' => "Plugin %s was reordered successfully.",
	'admin:plugins:reorder:no' => "Plugin %s could not be reordered.",
	'admin:plugins:disable:yes' => "Plugin %s was disabled successfully.",
	'admin:plugins:disable:no' => "Plugin %s could not be disabled.",
	'admin:plugins:enable:yes' => "Plugin %s was enabled successfully.",
	'admin:plugins:enable:no' => "Plugin %s could not be enabled.",

	'admin:statistics' => "Statistics",
	'admin:statistics:description' => "This is an overview of statistics on your site. If you need more detailed statistics, a professional administration feature is available.",
	'admin:statistics:opt:description' => "View statistical information about users and objects on your site.",
	'admin:statistics:opt:linktext' => "View statistics...",
	'admin:statistics:label:basic' => "Basic site statistics",
	'admin:statistics:label:numentities' => "Entities on site",
	'admin:statistics:label:numusers' => "Number of users",
	'admin:statistics:label:numonline' => "Number of users online",
	'admin:statistics:label:onlineusers' => "Users online now",
	'admin:statistics:label:version' => "Elgg version",
	'admin:statistics:label:version:release' => "Release",
	'admin:statistics:label:version:version' => "Version",

	'admin:user:label:search' => "پیدا کردن کاربران:",
	'admin:user:label:searchbutton' => "جستجو",

	'admin:user:ban:no' => "نمیتوانید این کاربر را بنکنید ",
	'admin:user:ban:yes' => "کاربر بن شد.",
	'admin:user:unban:no' => "نمیتوانید این کار بر را از حالت حذف بیرون بیاورید",
	'admin:user:unban:yes' => "کاربر از حالت حذف بیرون آمد.",
	'admin:user:delete:no' => "نمیتوانید این کاربر را کلا  پاک کنید",
	'admin:user:delete:yes' => "کاربر پاک شد",

	'admin:user:resetpassword:yes' => "Password reset, user notified.",
	'admin:user:resetpassword:no' => "رمز عبور قابل تغییر نیست.",

	'admin:user:makeadmin:yes' => "این کاربر الان ادمین است.",
	'admin:user:makeadmin:no' => "ما نمیتوانیم این کاربر را ادمین کنیم.",

	'admin:user:removeadmin:yes' => "این کاربر دیگر ادمین نیست.",
	'admin:user:removeadmin:no' => "We could not remove administrator privileges from this user.",

/**
 * User settings
 */
    'usersettings:description' => "The user settings panel allows you to control all your personal settings, from user management to how plugins behave. Choose an option below to get started.",

	'usersettings:statistics' => "Your statistics",
	'usersettings:statistics:opt:description' => "View statistical information about users and objects on your site.",
	'usersettings:statistics:opt:linktext' => "Account statistics",

	'usersettings:user' => "Your settings",
	'usersettings:user:opt:description' => "This allows you to control user settings.",
	'usersettings:user:opt:linktext' => "Change your settings",

	'usersettings:plugins' => "Tools",
	'usersettings:plugins:opt:description' => "Configure settings (if any) for your active tools.",
	'usersettings:plugins:opt:linktext' => "Configure your tools",

	'usersettings:plugins:description' => "This panel allows you to control and configure the personal settings for the tools installed by your system administrator.",
	'usersettings:statistics:label:numentities' => "مندرجات شما",

	'usersettings:statistics:yourdetails' => "جزییات شما",
	'usersettings:statistics:label:name' => "نام کامل",
	'usersettings:statistics:label:email' => "ایمیل",
	'usersettings:statistics:label:membersince' => "Member since",
	'usersettings:statistics:label:lastlogin' => "آخرین ورود",



/**
 * Generic action words
 */

    'save' => "ذخیــره ",
	'publish' => "انتشــار",
	'cancel' => "لغو",
	'saving' => "در حال ذخیره کردن ...",
	'update' => "آپدیت",
	'edit' => ",ویـرایش",
	'delete' => "حذف",
	'accept' => "پذیرفتن",
	'load' => "بار گزاری",
	'upload' => "آپلود",
	'ban' => "حذف",
	'unban' => "لغو حذف",
	'enable' => "فعال کردن",
	'disable' => "غیر فعال کردن",
	'request' => "درخواست",
	'complete' => "کامل کردن",
	'open' => 'باز کزدن',
	'close' => 'بستن',
	'reply' => "پاسخ",
	'more' => 'بیشتر',
	'comments' => 'نظرات',
	'import' => 'وارد کردن',
	'export' => 'خارج کردن',
	'untitled' => 'بدون عنوان',
	'help' => 'کمک',
	'send' => 'ارسال',
	'post' => 'پست',
	'submit' => 'ثبت',
	'site' => 'سایت',

	'up' => 'بالا',
	'down' => 'پایین',
	'top' => 'پالاترین',
	'bottom' => 'پایین ترین',

	'invite' => "دعوت",

	'resetpassword' => "تغییر رمز عبور",
	'makeadmin' => "ادمین کردن",
	'removeadmin' => "از ادمین برداشتن",

	'option:yes' => "بله",
	'option:no' => "خیر",

	'unknown' => 'ناشناس',

	'active' => 'فعال',
	'total' => 'مجموع',

	'learnmore' => "برای یادگیری بیشتر کلیک کنید.",

	'content' => "مندرجات",
	'content:latest' => 'آخرین فعالیتها',
	'content:latest:blurb' => 'متناوبا, اینجا کلیک کنید تا آخرین مطالب را در عرض سایت ببینید.',

	'link:text' => 'نمایش لینک',

	'enableall' => 'فعال کردن همه',
	'disableall' => 'غیر فعال کردن همه',

/**
 * Generic questions
 */

	'question:areyousure' => 'آیا شما مطمئن هستید?',

/**
 * Generic data words
 */

    'title' => "عنوان",
	'description' => "توضیح",
	'tags' => "برچسبها",
	'spotlight' => "Spotlight",
	'all' => "همه",

	'by' => 'توسط',

	'annotations' => "Annotations",
	'relationships' => "Relationships",
	'metadata' => "Metadata",

/**
 * Input / output strings
 */

    'deleteconfirm' => "آیا مطمئن هستید که شما میخواهید این آیتم را پاک کنید?",
	'fileexists' => "یک فایل هم اکنون آپلود شد. برای جایگزینی آن در پایین کلیک کنید:",

/**
 * User add
 */

    	'useradd:subject' => 'حساب کاربر عضو ایجاد شد',
	'useradd:body' => '
%s,

A user account has been created for you at %s. To log in, visit:

%s

And log in with these user credentials:

Username: %s
Password: %s

Once you have logged in, we highly recommend that you change your password.
',

/**
 * System messages
 **/

	'systemmessages:dismiss' => "برای برداشتن این قسمت کلیک کنید",


/**
 * Import / export
 */
    'importsuccess' => "وارد کردن اطلاعات مفید بود",
	'importfail' => "OpenDD import of data failed.",

/**
 * Time
 */

    'friendlytime:justnow' => "همین لحظه",
	'friendlytime:minutes' => "%s دقیقه پیش",
	'friendlytime:minutes:singular' => "یک دقیقه پیش",
	'friendlytime:hours' => "%s ساعت پیش",
	'friendlytime:hours:singular' => "یک ساعت پیش",
	'friendlytime:days' => "%s روز پیش",
	'friendlytime:days:singular' => "دیروز",
	'friendlytime:date_format' => 'j F Y @ g:ia',

	'date:month:01' => 'January %s',
	'date:month:02' => 'February %s',
	'date:month:03' => 'March %s',
	'date:month:04' => 'April %s',
	'date:month:05' => 'May %s',
	'date:month:06' => 'June %s',
	'date:month:07' => 'July %s',
	'date:month:08' => 'August %s',
	'date:month:09' => 'September %s',
	'date:month:10' => 'October %s',
	'date:month:11' => 'November %s',
	'date:month:12' => 'December %s',


/**
 * Installation and system settings
 */

    	'installation:error:htaccess' => "Elgg requires a file called .htaccess to be set in the root directory of its installation. We tried to create it for you, but Elgg doesn't have permission to write to that directory.

Creating this is easy. Copy the contents of the textbox below into a text editor and save it as .htaccess

",
	'installation:error:settings' => "Elgg couldn't find its settings file. Most of Elgg's settings will be handled for you, but we need you to supply your database details. To do this:

1. Rename engine/settings.example.php to settings.php in your Elgg installation.

2. Open it with a text editor and enter your MySQL database details. If you don't know these, ask your system administrator or technical support for help.

Alternatively, you can enter your database settings below and we will try and do this for you...",

	'installation:error:configuration' => "Once you've corrected any configuration issues, press reload to try again.",

	'installation' => "Installation",
	'installation:success' => "Elgg's database was installed successfully.",
	'installation:configuration:success' => "Your initial configuration settings have been saved. Now register your initial user; this will be your first system administrator.",

	'installation:settings' => "System settings",
	'installation:settings:description' => "Now that the Elgg database has been successfully installed, you need to enter a couple of pieces of information to get your site fully up and running. We've tried to guess where we could, but <b>you should check these details.</b>",

	'installation:settings:dbwizard:prompt' => "Enter your database settings below and hit save:",
	'installation:settings:dbwizard:label:user' => "Database user",
	'installation:settings:dbwizard:label:pass' => "Database password",
	'installation:settings:dbwizard:label:dbname' => "Elgg database",
	'installation:settings:dbwizard:label:host' => "Database hostname (usually 'localhost')",
	'installation:settings:dbwizard:label:prefix' => "Database table prefix (usually 'elgg_')",

	'installation:settings:dbwizard:savefail' => "We were unable to save the new settings.php. Please save the following file as engine/settings.php using a text editor.",

	'installation:sitename' => "The name of your site (eg \"My social networking site\"):",
	'installation:sitedescription' => "Short description of your site (optional)",
	'installation:wwwroot' => "The site URL, followed by a trailing slash:",
	'installation:path' => "The full path to your site root on your disk, followed by a trailing slash:",
	'installation:dataroot' => "The full path to the directory where uploaded files will be stored, followed by a trailing slash:",
	'installation:dataroot:warning' => "You must create this directory manually. It should sit in a different directory to your Elgg installation.",
	'installation:sitepermissions' => "The default access permissions:",
	'installation:language' => "The default language for your site:",
	'installation:debug' => "Debug mode provides extra information which can be used to diagnose faults. However, it can slow your system down so should only be used if you are having problems:",
	'installation:debug:none' => 'Turn off debug mode (recommended)',
	'installation:debug:error' => 'Display only critical errors',
	'installation:debug:warning' => 'Display errors and warnings',
	'installation:debug:notice' => 'Log all errors, warnings and notices',
	'installation:httpslogin' => "Enable this to have user logins performed over HTTPS. You will need to have https enabled on your server for this to work.",
	'installation:httpslogin:label' => "Enable HTTPS logins",
	'installation:view' => "Enter the view which will be used as the default for your site or leave this blank for the default view (if in doubt, leave as default):",

	'installation:siteemail' => "Site email address (used when sending system emails)",

	'installation:disableapi' => "The RESTful API is a flexible and extensible interface that enables applications to use certain Elgg features remotely.",
	'installation:disableapi:label' => "Enable the RESTful API",

	'installation:allow_user_default_access:description' => "If checked, individual users will be allowed to set their own default access level that can over-ride the system default access level.",
	'installation:allow_user_default_access:label' => "Allow user default access",

	'installation:simplecache:description' => "The simple cache increases performance by caching static content including some CSS and JavaScript files. Normally you will want this on.",
	'installation:simplecache:label' => "Use simple cache (recommended)",

	'installation:viewpathcache:description' => "The view filepath cache decreases the loading times of plugins by caching the location of their views.",
	'installation:viewpathcache:label' => "Use view filepath cache (recommended)",

	'upgrading' => 'Upgrading...',
	'upgrade:db' => 'Your database was upgraded.',
	'upgrade:core' => 'Your elgg installation was upgraded.',

/**
 * Welcome
 */

    'welcome' => "خوش آمدید",
	'welcome:user' => 'خوش آمديد %s',
	'welcome_message' => "خوش آمديد",

/**
 * Emails
 */
    	'email:settings' => "تنظیمات ایمیل",
	'email:address:label' => "Yایمیل آدرس شما",

	'email:save:success' => "ایمیل آدرس جدید ذخره شد,درخواست بازبینی, .",
	'email:save:fail' => "ایمیل آدرس شما نمیتواند ذخیره شود.",

	'friend:newfriend:subject' => "%s شما را به عنوان دوست انتخاب کرد!",
	'friend:newfriend:body' => "%s شما را به عنوان دوست انتخاب کرد!

To view their profile, click here:

%s

You cannot reply to this email.",



	'email:resetpassword:subject' => "تغییر پسورد!",
	'email:resetpassword:body' => "سلام و درود %s,

Your password has been reset to: %s",


	'email:resetreq:subject' => "درخواست برای پسورد جدید؟.",
	'email:resetreq:body' => "سلام و درود %s,

Somebody (from the IP address %s) has requested a new password for their account.

اگر شما این را در خواست کرده اید  بر لینک زیر کلیک کنید, در غیر این صورت از این ایمیل چشم پوشی کنید.

%s
",

/**
 * user default access
 */

'default_access:settings' => "Your default access level",
'default_access:label' => "Default access",
'user:default_access:success' => "Your new default access level was saved.",
'user:default_access:failure' => "Your new default access level could not be saved.",

/**
 * XML-RPC
 */
	'xmlrpc:noinputdata'	=>	"Input data missing",

/**
 * Comments
 */


	'comments:count' => "%s نظرات",

	'riveraction:annotation:generic_comment' => '%s نظر در %s',

	'generic_comments:add' => "یک پیام بگذارید",
	'generic_comments:text' => "نظر",
	'generic_comment:posted' => "نظر شما با موفقیت ارسال شد.",
	'generic_comment:deleted' => "نظر شما با موفقیت حذف شد",
	'generic_comment:blank' => "متاسفیم,شما باید در واقع چیز را در نظر قرار دهی قبل از اینکه آن را ذخیره کنی.",
	'generic_comment:notfound' => "Sorry, we could not find the specified item.",
	'generic_comment:notdeleted' => "متاسفیم شما نمیتوانید این نظر را حذف کنید.",
	'generic_comment:failure' => "وقتی شما نظر میدادید یک  اشکال غیر منتظره بوجود آمد لطفا دوباره امتحان کنید.",

	'generic_comment:email:subject' => 'شما یک نظر جدید دارید!',
	'generic_comment:email:body' => "شما نظر جدید در آیتمتان دارید \"%s\" از %s. It reads:


%s


To reply or view the original item, click here:

%s

برای دیدن %s's پروفایل, اینجا کلیک کنید:

%s

شما نمیتوایند این ایمیل را پاسخ دهید.",

/**
 * Entities
 */

	'entity:default:strapline' => 'ایجاد شد %s توسط %s',
	'entity:default:missingsupport:popup' => 'This entity cannot be displayed correctly. This may be because it requires support provided by a plugin that is no longer installed.',

	'entity:delete:success' => 'Entity %s has been deleted',
	'entity:delete:fail' => 'Entity %s could not be deleted',


/**
 * Action gatekeeper
 */
	'actiongatekeeper:missingfields' => 'Form is missing __token or __ts fields',
	'actiongatekeeper:tokeninvalid' => "We encountered an error (token mismatch). This probably means that the page you were using expired. Please try again.",
	'actiongatekeeper:timeerror' => 'The page you were using has expired. Please refresh and try again.',
	'actiongatekeeper:pluginprevents' => 'A extension has prevented this form from being submitted.',

/**
 * Word blacklists
 */
	'word:blacklist' => 'و, the, بعد, اما, او, his, her, him, یک, not, همچنین, دربازه, الان, hence, however, still, likewise, otherwise, therefore, conversely, rather, consequently, furthermore, nevertheless, instead, meanwhile, accordingly, this, seems, what, whom, whose, whoever, whomever',

/**
 * Tag labels
 */

	'tag_names:tags' => 'برچسبها',

/**
 * Languages according to ISO 639-1
 */
	"aa" => "Afar",
	"ab" => "Abkhazian",
	"af" => "Afrikaans",
	"am" => "Amharic",
	"ar" => "Arabic",
	"as" => "Assamese",
	"ay" => "Aymara",
	"az" => "Azerbaijani",
	"ba" => "Bashkir",
	"be" => "Byelorussian",
	"bg" => "Bulgarian",
	"bh" => "Bihari",
	"bi" => "Bislama",
	"bn" => "Bengali; Bangla",
	"bo" => "Tibetan",
	"br" => "Breton",
	"ca" => "Catalan",
	"co" => "Corsican",
	"cs" => "Czech",
	"cy" => "Welsh",
	"da" => "Danish",
	"de" => "German",
	"dz" => "Bhutani",
	"el" => "Greek",
	"en" => "English",
	"eo" => "Esperanto",
	"es" => "Spanish",
	"et" => "Estonian",
	"eu" => "Basque",
	"fa" => "Persian",
	"fi" => "Finnish",
	"fj" => "Fiji",
	"fo" => "Faeroese",
	"fr" => "French",
	"fy" => "Frisian",
	"ga" => "Irish",
	"gd" => "Scots / Gaelic",
	"gl" => "Galician",
	"gn" => "Guarani",
	"gu" => "Gujarati",
	"he" => "Hebrew",
	"ha" => "Hausa",
	"hi" => "Hindi",
	"hr" => "Croatian",
	"hu" => "Hungarian",
	"hy" => "Armenian",
	"ia" => "Interlingua",
	"id" => "Indonesian",
	"ie" => "Interlingue",
	"ik" => "Inupiak",
	//"in" => "Indonesian",
	"is" => "Icelandic",
	"it" => "Italian",
	"iu" => "Inuktitut",
	"iw" => "Hebrew (obsolete)",
	"ja" => "Japanese",
	"ji" => "Yiddish (obsolete)",
	"jw" => "Javanese",
	"ka" => "Georgian",
	"kk" => "Kazakh",
	"kl" => "Greenlandic",
	"km" => "Cambodian",
	"kn" => "Kannada",
	"ko" => "Korean",
	"ks" => "Kashmiri",
	"ku" => "Kurdish",
	"ky" => "Kirghiz",
	"la" => "Latin",
	"ln" => "Lingala",
	"lo" => "Laothian",
	"lt" => "Lithuanian",
	"lv" => "Latvian/Lettish",
	"mg" => "Malagasy",
	"mi" => "Maori",
	"mk" => "Macedonian",
	"ml" => "Malayalam",
	"mn" => "Mongolian",
	"mo" => "Moldavian",
	"mr" => "Marathi",
	"ms" => "Malay",
	"mt" => "Maltese",
	"my" => "Burmese",
	"na" => "Nauru",
	"ne" => "Nepali",
	"nl" => "Dutch",
	"no" => "Norwegian",
	"oc" => "Occitan",
	"om" => "(Afan) Oromo",
	"or" => "Oriya",
	"pa" => "Punjabi",
	"pl" => "Polish",
	"ps" => "Pashto / Pushto",
	"pt" => "Portuguese",
	"qu" => "Quechua",
	"rm" => "Rhaeto-Romance",
	"rn" => "Kirundi",
	"ro" => "Romanian",
	"ru" => "Russian",
	"rw" => "Kinyarwanda",
	"sa" => "Sanskrit",
	"sd" => "Sindhi",
	"sg" => "Sangro",
	"sh" => "Serbo-Croatian",
	"si" => "Singhalese",
	"sk" => "Slovak",
	"sl" => "Slovenian",
	"sm" => "Samoan",
	"sn" => "Shona",
	"so" => "Somali",
	"sq" => "Albanian",
	"sr" => "Serbian",
	"ss" => "Siswati",
	"st" => "Sesotho",
	"su" => "Sundanese",
	"sv" => "Swedish",
	"sw" => "Swahili",
	"ta" => "Tamil",
	"te" => "Tegulu",
	"tg" => "Tajik",
	"th" => "Thai",
	"ti" => "Tigrinya",
	"tk" => "Turkmen",
	"tl" => "Tagalog",
	"tn" => "Setswana",
	"to" => "Tonga",
	"tr" => "Turkish",
	"ts" => "Tsonga",
	"tt" => "Tatar",
	"tw" => "Twi",
	"ug" => "Uigur",
	"uk" => "Ukrainian",
	"ur" => "Urdu",
	"uz" => "Uzbek",
	"vi" => "Vietnamese",
	"vo" => "Volapuk",
	"wo" => "Wolof",
	"xh" => "Xhosa",
	//"y" => "Yiddish",
	"yi" => "Yiddish",
	"yo" => "Yoruba",
	"za" => "Zuang",
	"zh" => "Chinese",
	"zu" => "Zulu",
);

add_translation("en",$farsi);
