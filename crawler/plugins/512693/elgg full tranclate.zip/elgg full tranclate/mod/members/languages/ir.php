<?php

	$farai = array(
			
		'members:members' => "اعضا",
	    'members:online' => "کاربران آنلاین",
	    'members:active' => "کاربران سایت",
	    'members:searchtag' => "جستجوی کاربران با استفاده از برچسب",
	    'members:searchname' => "جستجوي اعضا بر اساس نام",

		'members:label:newest' => 'جدیدترین',
		'members:label:popular' => 'محبوبترین',
		'members:label:active' => 'فعالترین',
		'members:search:name' => 'اسامی کاربران',
		'members:search:tags' => 'برچسبها',
		
	);
					
	add_translation("ir",$farsi);

?>