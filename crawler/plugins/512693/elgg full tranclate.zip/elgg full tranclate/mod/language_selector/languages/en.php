<?php
	$english = array(

		'language_selector:admin:settings:min_completeness' => 'Enter the minimum amount of completeness for languages to show up in the language selector (e.g. 30).',
		'language_selector:admin:settings:show_in_header' => 'Show language selector in header?',
		'language_selector:admin:settings:autodetect' => 'Enable autodetect of language (for non-logged in users)',
		'language_selector:admin:settings:show_images' => 'Show images of language/country (if available)',
	
	);
					
	add_translation("en",$english);
?>