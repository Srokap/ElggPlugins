<?php

	$farsi = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messages' => "پیامهای خصوصی",
            'messages:back' => "بازگشت به پیامها",
			'messages:user' => " صندوق پیام شما",
			'messages:sentMessages' => "پیامهای ارسال شده",
			'messages:posttitle' => "%s's پیامهای: %s",
			'messages:inbox' => "صندوق پیام",
			'messages:send' => "ارسال یک پیام خصوصی",
			'messages:sent' => "پیامهای ارسال شده",
			'messages:message' => "پیام خصوصی",
			'messages:title' => "عنوان",
			'messages:to' => "به",
            'messages:from' => "از",
			'messages:fly' => "ارسال",
			'messages:replying' => "پاسخ پیام به",
			'messages:inbox' => "صندوق پیام",
			'messages:sendmessage' => "ارسال پیام خصوصی",
			'messages:compose' => "ایجاد یک پیام خصوصی",
			'messages:sentmessages' => "پیامهای ارسال شده",
			'messages:recent' => "پیامهای اخیر",
            'messages:original' => "پیام اصلی",
            'messages:yours' => "پیام شما",
            'messages:answer' => "پاسخ",
			'messages:toggle' => 'انتخاب زنجیروار',
			'messages:markread' => 'انتخاب خوانده شده ها',
			
			'messages:new' => 'پیام خصوصی جدید',
	
			'notification:method:site' => 'سایت',
	
			'messages:error' => 'در هنگام ذخیر پیام شما اشکالی بوجود آمد لطفا دوبار امتحان کنید.',
	
			'item:object:messages' => 'پیامهای خصوصی',
	
		/**
		 * Status messages
		 */
	
			'messages:posted' => "پیام خصوصی شما با موفقیت ارسال شد.",
			'messages:deleted' => "پیام خصوصی شما با موفقیت حذف شد.",
			'messages:markedread' => "پیامهای شما با موفقیت به عنوان پیامهای نشاندار انتخاب شد.",
	
		/**
		 * Email messages
		 */
	
			'messages:email:subject' => 'شما یک پیام خصوصی جدید دارید!',
			'messages:email:body' => "شما پیام خصوصی جدید دارید از %s. که میگوید:

			
%s


برای دیدن پیامهای خصوصیتان,اینجا کلیک کنید:

	%s

برای ارسال %s یک پیام خصوصی, اینجا کلیک کنید:

	%s

شما نمتوانید به این ایمیل پاسخ دهید.",
	
		/**
		 * Error messages
		 */
	
			'messages:blank' => "متاسفیم شما قبل از اینکه پیام را ذخیره کنید باید در قسمت بدنه پیام چیزی بگذارید.",
			'messages:notfound' => "متاسفیم ما پیام مورد نظر شما را پیدا نکردیم.",
			'messages:notdeleted' => "متاسفیم ما نتوانستیم این پیام را حذف کنیم.",
			'messages:nopermission' => "شما اجازه تغییر واصلاح این پیام را ندارید.",
			'messages:nomessages' => "هیچ پیامی برای نمایش وجود ندارد.",
			'messages:user:nonexist' => "متاسفیم ما گیرنده را در این بخش اطلاعاتی نتوانستیم پیدا کنیم.",
			'messages:user:blank' => "شما برای ارسال این کسی را انتخاب نکرده اید.",
	
	);
					
	add_translation("ir",$farsi);

?>