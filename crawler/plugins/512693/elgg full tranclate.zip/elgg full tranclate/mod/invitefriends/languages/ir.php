<?php

	/**
	 * Elgg invite page
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2010
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @link http://elgg.org/
	 */

	$farsi = array(

       'friends:invite' => 'دعوت از دوستان',
		'invitefriends:introduction' => 'براي دعوت از دوستانتان به اين سايت لطفا ايميل انها را به صورت مجزا و زير همديگر در کادر زير وارد نماييد',
		'invitefriends:message' => 'يک پيام براي دوستتان بنويسيد و از انها بخواهيد به شما ملحق بشوند',
		'invitefriends:subject' => 'دعوتنامه %s',

		'invitefriends:success' => 'دوست شما دعوت شد',
		'invitefriends:email_error' => 'دعوتنامه ارسال شد اما ادرس ايميل زير صحيح نيست <br/> %s',
		'invitefriends:failure' => 'قادر به دعوت از دوست شما نيستيم',

		'invitefriends:message:default' => '
سلام

يک وبسايت خوب پيدا کردم با نام
 %s.',
		'invitefriends:email' => '
شما دعوت شده ايد براي پيوستن به
  %s
   از طرف
    %s.
%s

براي پيوستن لينک زير را کليک کن

%s

شما به صورت اتوماتيک با هم دوست خواهيد شد',

	);
					
	add_translation("ir",$farsi);
?>
