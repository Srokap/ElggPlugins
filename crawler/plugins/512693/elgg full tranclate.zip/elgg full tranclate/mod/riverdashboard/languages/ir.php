<?php

	$farsi = array(

		'mine' => 'مال من',
		'filter' => 'جدا کردن',
		'riverdashboard:useasdashboard' => "داشبورد پیش فرض را با فعالیت رودخانهایی جایگزین کن?",
		'activity' => 'Activity',
		'riverdashboard:recentmembers' => 'کاربران اخیر',
	
	    /**
	     * Site messages
           **/

		'sitemessages:announcements' => "اطلاعیه های فارسی لند",
		'sitemessages:posted' => "ارسال شده",
		'sitemessages:river:created' => "مدیر فارسی لند گفت, %s,",
		'sitemessages:river:create' => "یک پیام همگانی ارسال کرد",
		'sitemessages:add' => "یک پیام همگانی به قسمت رودخانه سایت ارسال کرد",
		'sitemessage:deleted' => "پیام سایت حذف شد",
		'sitemessage:error' => "ذخیره پیام سایت باشکست مواجه شد.",
		
		'river:widget:noactivity' => 'ما هیچ فعالیتی نمیتوانیم پیدا کنیم.',
		'river:widget:title' => "فعالیت",
		'river:widget:description' => "آخرین فعالیت شما را نمایش میدهد.",
		'river:widget:title:friends' => "فعالیت دوستان",
		'river:widget:description:friends' => "دوستان شما را که تا کنون فعال بودند را نمایش میدهد.",
		'river:widgets:friends' => "دوستان",
		'river:widgets:mine' => "مال من",
		'river:widget:label:displaynum' => "تعداد ورودی ها برای نمایش:",
		'river:widget:type' => "چه رودخانه ایی دوست دارید نمایش داده شود? آن که متعلق به فعالیت شماست؟ یا آنکه متعلق به فعالیت دوستانتان است?",
		'item:object:sitemessage' => "پیامهای سایت",
		'riverdashboard:avataricon' => "Would you like to use user avatars or icons on your site activity stream?", 
		'option:icon' => 'آیکونها',
		'option:avatar' => 'آواتارها',
	);
					
	add_translation("ir",$farsi);

?>