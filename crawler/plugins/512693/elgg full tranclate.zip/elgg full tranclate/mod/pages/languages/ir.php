<?php
	/**
	 * Elgg pages plugin language pack
	 * 
	 * @package ElggPages
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2010
	 * @link http://elgg.com/
	 */

	$farsi = array(

		/**
		 * Menu items and titles
		 */
			
			'pages' => "گفتگوها",
			'pages:yours' => "گفتگوهاي شما",
			'pages:user' => "گفتگوهاي ما",
			'pages:group' => "بحث هاي گروه ها",
			'pages:all' => "همه بحثهاي سايت",
			'pages:new' => "بحث جديد",
			'pages:groupprofile' => "بحث گروه ها",
			'pages:edit' => "ويرايش اين بحث",
			'pages:delete' => "حذف اين بحث",
			'pages:history' => "فعاليتهاي بحث",
			'pages:view' => "نمايش بحث",
			'pages:welcome' => "ويرايش سرتيتر",
			'pages:welcomemessage' => "بسيار خوش آمديد به اين قسمت . شما در اينجا توانايي ساخت بحث را داريد با امکانات مورد نياز",
			'pages:welcomeerror' => "مشکلي پيش آمده در ذخيره سرتيتر",
			'pages:welcomeposted' => "سرتيتر شما ارسال شد",
			'pages:navigation' => "مسير مشخص شده بحث",
	        'pages:via' => "بر اساس بحث",
			'item:object:page_top' => 'برترين بحثها',
			'item:object:page' => 'بحثها',
			'item:object:pages_welcome' => 'سرتيتر بحث',
			'pages:nogroup' => 'اين گروه هنوز بحثي ندارد',
			'pages:more' => 'بيشتر',
			
		/**
		* River
		**/

		    'pages:river:annotate' => "يک نظر در اين بحث",
		    'pages:river:created' => "%s نوشته",
	        'pages:river:updated' => "%s بروز رساني",
	        'pages:river:posted' => "%s ارسال کرده",
			'pages:river:create' => "عنوان يک بحث جديد",
	        'pages:river:update' => "يک بحث عنوان گرفت",
	        'page:river:annotate' => "يک نظر بر روي اين بحث",
	        'page_top:river:annotate' => "يک نظر بر روي اين بحث",
	
		/**
		 * Form fields
		 */
	
			'pages:title' => 'سرتيتر بحث',
			'pages:description' => 'متن بحث',
			'pages:tags' => 'برچسب',
			'pages:access_id' => 'اجازه ورود به',
			'pages:write_access_id' => 'اجازه نوشتن به',
		
		/**
		 * Status and error messages
		 */
			'pages:noaccess' => 'اجازه ورود به بحث نيست',
			'pages:cantedit' => 'شما نميتوانيد اين بحث را ويرايش کنيد',
			'pages:saved' => 'بحث ذخيره شده',
			'pages:notsaved' => 'بحث قادر به ذخيره شدن نيست',
			'pages:notitle' => 'شما ميبايست عنوان بحث را مشخص نماييد',
			'pages:delete:success' => 'بحث با موفقيت حذف شد',
			'pages:delete:failure' => 'اين بحث حذف نمي شود',

		/**
		 * Page
		 */
			'pages:strapline' => 'آخرين بروز رساني <br/> %s <br/> توسط %s',

		/**
		 * History
		 */
			'pages:revision' => 'Revision created %s by %s',
			
		/**
		 * Widget
		 **/
		 
		    'pages:num' => 'Number of pages to display',
			'pages:widget:description' => "This is a list of your pages.",
	
		/**
		 * Submenu items
		 */
			'pages:label:view' => "نمايش بحث",
			'pages:label:edit' => "ويرايش بحث",
			'pages:label:history' => "فعاليتهاي بحث",
	
		/**
		 * Sidebar items
		 */
			'pages:sidebar:this' => "اين بحث",
			'pages:sidebar:children' => "زير مجموعه بحث",
			'pages:sidebar:parent' => "منبع",

			'pages:newchild' => "ايجاد زير مجموعه بحث",
			'pages:backtoparent' => "باز گشت '%s'",
	);
					
	add_translation("ir",$farsi);
?>