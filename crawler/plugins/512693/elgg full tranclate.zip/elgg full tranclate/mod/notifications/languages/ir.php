<?php

	$farsi = array(
	
		'friends:all' => 'همه دوستان',
	
		'notifications:subscriptions:personal:description' => 'وقتی بر روی مطالب شما فعالیتی انجام میشود اطلاعیه دریافت کنم',
		'notifications:subscriptions:personal:title' => 'اطلاعیه شخصی',
	
		'notifications:subscriptions:collections:title' => 'زنجیره مجموعه دوستان',
		'notifications:subscriptions:collections:description' => 'To toggle settings for members of your friends collections, use the icons below. This will affect the corresponding users in the main notification settings panel at the bottom of the page. ',
		'notifications:subscriptions:collections:edit' => ' برای ویرایش مجموعه دوستان کلیک کنید.',
	
		'notifications:subscriptions:changesettings' => 'اطلاعیه ها',
		'notifications:subscriptions:changesettings:groups' => 'اطلاعیه های گروه',
		'notification:method:email' => 'Email',	
	
		'notifications:subscriptions:title' => 'اطلاعیه های هر کاربر',
		'notifications:subscriptions:description' => 'برای دریافت اطلاعیه از طرف دوستان وقتی که انها مطلب جدیدی را ایجاد میکنند برای دریافت اطلاعیه وقتی که مطلب جدیدی به گروه شمایا گروهی که در آن عضو هستید اضافه میشود قسمت پایین را نگاه کنید و  روشهای اطلاع رسانی را ببینید و روشی ا که دوست دارید انتخاب کنید.',
     	'notifications:subscriptions:groups:description' =>' براي مواردي که شما دوست داريد استفاده نماييد',

		'notifications:subscriptions:groups:description' => '  برای دریافت اطلاعیه وقتی که مطلب جدیدی به گروه شما یا گروهی که در آن عضو هستید اضافه میشود قسمت پایین را نگاه کنید و  روشهای اطلاع رسانی را ببینید و روشی ا که دوست دارید انتخاب کنید.',
	
		'notifications:subscriptions:success' => 'تنظیمات اطلاعیه شما ذخیره شد.',
	
	);
					
	add_translation("ir",$farsi);

?>