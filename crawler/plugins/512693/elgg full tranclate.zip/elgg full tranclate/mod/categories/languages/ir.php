<?php

	$farsi = array(
	
		'categories' => 'دسته بندیها',
		'categories:settings' => 'تنظیم دسته بندی سایت',	
		'categories:explanation' => 'To set some predefined site-wide categories that will be used throughout your system, enter them below, separated with commas. Compatible tools will then display them when the user creates or edits content.',	
		'categories:save:success' => 'دسته بندی سایت با موفقیت ذخیره شد.',
	
	);
					
	add_translation("ir",$farsi);

?>