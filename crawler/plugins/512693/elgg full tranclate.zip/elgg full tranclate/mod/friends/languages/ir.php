<?php

	$farsi = array(
	
		/**
		 * بخش نمایش دوستان
		 */
			'friends:widget:description' => "تعدادی از دوستان شما را نمایش میدهد.",
	        
		
	);
					
	add_translation("ir",$farsi);

?>