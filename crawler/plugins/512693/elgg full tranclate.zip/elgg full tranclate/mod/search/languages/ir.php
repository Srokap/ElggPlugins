<?php

$farsi = array(
	'search:enter_term' => 'یک آیتم برای جستجو وارد کنید:',
	'search:no_results' => 'بدون نتیجه.',
	'search:matched' => 'تطبیق با: ',
	'search:results' => 'نتایج برای %s',
	'search:no_query' => 'یک سوال برای جستجو وارد کنید.',
	'search:search_error' => 'خطا',

	'search:more' => '+%sبیشتر %s',

	'search_types:tags' => 'برچسبها',

	'search_types:comments' => 'نظرها',
	'search:comment_on' => 'نظر در "%s"',
	'search:unavailable_entity' => 'غیر قابل دسترس',
);

add_translation('ir', $farsi);
