<?php

	$farsi = array(
	
		/**
		 * Menu items and titles
		 */
	
			'thewire' => "جعبه فریاد",
			'thewire:user' => "%s's جعبه فریاد",
			'thewire:posttitle' => "%s's نوشته های در جعبه فریاد: %s",
			'thewire:everyone' => "همه پستهای جعبه فریاد",
	
			'thewire:read' => "پستهاي کوتاه",

			'thewire:strapline' => "%s",
	
			'thewire:add' => "پست برای جعبه فریاد",
		    'thewire:text' => "یک نوشته در جعبه فریاد",
			'thewire:reply' => "پاسخ",
			'thewire:via' => "از طریق",
			'thewire:wired' => "به جعبه بی سیم ارسال شد",
			'thewire:charleft' => "کاراکترهای باقیمانده",
			'item:object:thewire' => "پستهای جعبه فریاد",
			'thewire:notedeleted' => "نوشته پاک شد",
			'thewire:doing' => "در این جعبه فریاد هر چه میخواهد دل تنگت بگو:",
			'thewire:newpost' => 'پست جدید جعبه فریاد',
			'thewire:addpost' => 'ارسال به جعبه فریاد',

	
        /**
	     * The wire river
	     **/
	        
	        //generic terms to use
	        'thewire:river:created' => "%sارسال شده",
	        
	        //these get inserted into the river links to take the user to the entity
	        'thewire:river:create' => "در جعبه فریاد.",
	        
	    /**
	     * Wire widget
	     **/
	     
	        'thewire:sitedesc' => 'این بخش نمایشگر آخرین پستهای ارسالی کاربران به جعبه فریاد میباشد',
	        'thewire:yourdesc' => ' این بخش نمایشگر آخرین پستهای ارسالی شما به جعبه فریاد میباشد',
	        'thewire:friendsdesc' => 'این بخش نمایشگر آخرین پستهای ارسالی دوستانان به جعبه فریاد میباشد ',
	        'thewire:friends' => 'دوستان شما در جعبه فریاد',
	        'thewire:num' => 'تعداد آیتمها برای نمایش',
	        
	        
	
		/**
		 * Status messages
		 */
	
			'thewire:posted' => "مسیج شما به صورت موفقیت آمیز به جعبه فریاد ارسال شد.",
			'thewire:deleted' => " پست جعبه فریاد شما به صورت موفقیت آمیز حذف شد.",
	
		/**
		 * Error messages
		 */
	
			'thewire:blank' => "متاسفیم شما قبل از ذهیره کردن باید چیزی در جعبه نوشتاری بنویسید.",
			'thewire:notfound' => "متاسفیم ما نتوانستیم پست جعبه فریاد خاصی را پیدا کنیم.",
			'thewire:notdeleted' => "متاسفیم ما نمیتوانیم این پست جعبه فریاد را حذف کنیم.",
	
	
		/**
		 * Settings
		 */
			'thewire:smsnumber' => "Your SMS number if different from your mobile number (mobile number must be set to public for the wire to be able to use it). All phone numbers must be in international format.",
			'thewire:channelsms' => "The number to send SMS messages to is <b>%s</b>",
			
	);
					
	add_translation("ir",$farsi);

?>