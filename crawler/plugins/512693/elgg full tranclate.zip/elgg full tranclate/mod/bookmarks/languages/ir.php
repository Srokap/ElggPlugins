<?php

	$farsi = array(
	
		/**
		 * Menu items and titles
		 */
	
			'bookmarks' => "بوکمارکها*اضافه کردن سایت",
			'bookmarks:add' => "اضافه کردن بوکمارک",
			'bookmarks:read' => "%s's آیتم های بوکمارک شده",
			'bookmarks:friends' => "بوکمارکهای دوستان",
			'bookmarks:everyone' => "همه بوکمارک های سایت",
			'bookmarks:this' => "این را بوکمارک کن",
			'bookmarks:this:group' => "بوکمارک در %s",
			'bookmarks:bookmarklet' => "استفاده از بوکمارک",
			'bookmarks:bookmarklet:group' => "استفاده از بوکمارکهای گروه",
			'bookmarks:inbox' => "این باکسهای بوکمارک شده",
			'bookmarks:more' => "بیشتر",
			'bookmarks:shareditem' => "آیتمهای بوکمارک شده",
			'bookmarks:with' => "تقسیم با",
			'bookmarks:new' => "یک آیتم بوکمارک شده جدید",
			'bookmarks:via' => "از طریق بوکمارکها",
			'bookmarks:address' => "آدرس منبع بوکمارکها",
	
			'bookmarks:delete:confirm' => "آیا شما مطمئن هستید که این منبع را میخواهید حذف کنید؟",
	
			'bookmarks:numbertodisplay' => 'تعداد آیتمهای بوکمارک شده برای نمایش',
	
			'bookmarks:shared' => "بوکمارک شده",
			'bookmarks:visit' => "مشاهده منبع",
			'bookmarks:recent' => "بوکمارکهای اخیر",
	
			'bookmarks:river:created' => '%s بوکمارک شده های',
			'bookmarks:river:annotate' => 'یک نظر در این آیتم بوکمارک شده',
			'bookmarks:river:item' => 'یک آیتم',
	
			'item:object:bookmarks' => 'آیتمهای بوکمارک شده',
	
			'bookmarks:group' => 'بوکمارکهای گروه*آدرسهای ثبت شده',
			'bookmarks:enablebookmarks' => 'فعال کردن بوکمارکهای گروه',
	
	
		/**
		 * More text
		 */
		    
		    'bookmarks:widget:description' => " این بخش برای داشبورد شما طراحی شده و به شما آخرین آیتمها در این باکس بوکمارک(آدرسهای ثبت شده)را نشان میدهد" ,
	
			'bookmarks:bookmarklet:description' =>
					" این بخش باعث میشود شما تمام منابع بوکمارکتان را با دوستانتان تقسیم کنید یا اینکه فقط برای خودتان ذخیره کنید,برای استفاده از آن,آن را در لینک بار درگ کنید :",

	        'bookmarks:bookmarklet:descriptionie' =>
					"add to favorite سپس link barرا انتخبا کنیداگر شما از اینترنت اکسپلورر استفاده میکنید,شما باید بر روی آستم بوکمار شده راست کلیک کنید, و', .",

			'bookmarks:bookmarklet:description:conclusion' =>
					"شما میتوانید بعدا هر صفحه ایی را که میبینید در هر زمانی با کلیک بر آن ذخیره کنید.",
	
		/**
		 * Status messages
		 */
	
			'bookmarks:save:success' => "آیتم شما با موفقیت بوکمارک شد.",
			'bookmarks:delete:success' => "آیتم بوکمارک شده شما با موفقیت حذف شد.",
	
		/**
		 * Error messages
		 */
	
			'bookmarks:save:failed' => " .آیتم بوکمارک شده شما قابل ذخیره شدن نیست لطفا دوباره تلاش کنید  .",
			'bookmarks:delete:failed' => "آیتم بوکمارک شده شما قابل پاک شدن نیست لطفا دوباره تلاش کنید.",
	
	
	);
					
	add_translation("ir",$farsi);

?>