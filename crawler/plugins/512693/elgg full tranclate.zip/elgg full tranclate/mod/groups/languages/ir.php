<?php
	/**
	 * Elgg groups plugin language pack
	 *
	 * @package ElggGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2010
	 * @link http://elgg.com/
	 */

	$farsi = array(

		/**
		 * Menu items and titles
		 */

			'groups' => "گروهها",
			'groups:owned' => "گروههای که شما مالک آن هستید",
			'groups:yours' => "گروههای شما",
			'groups:user' => "%s's گروههای",
			'groups:all' => "همه گروهای سایت",
			'groups:new' => "یک گروه جدید ایجاد کنید",
			'groups:edit' => "ویرایش گروه",
			'groups:delete' => 'حذف گروه',
			'groups:membershiprequests' => 'مدیریت درخواستهای عضویت',
			'groups:invitations' => 'دعوتهای گروه',

			'groups:icon' => 'آیکون گروه (leave blank to leave unchanged)',
			'groups:name' => 'نام گروه',
			'groups:username' => 'نام کوتاه گروه(displayed in URLs, alphanumeric characters only)',
			'groups:description' => 'توضیح ',
			'groups:briefdescription' => 'توضیح مختصر',
			'groups:interests' => 'برچسبها',
			'groups:website' => 'وب سایت',
			'groups:members' => 'اعضای گروه',
			'groups:membership' => "اجازه عضویت در گروه",
			'groups:access' => "اجازه دسترسی",
			'groups:owner' => "مالک",
			'groups:widget:num_display' => 'تعداد گروهها برای نمایش',
			'groups:widget:membership' => 'عضویت گروه',
			'groups:widgets:description' => 'نمایش گروههای که شما عضو ان هستید در پروفایل شما',
			'groups:noaccess' => 'گروه غیر قابل دسترس',
			'groups:cantedit' => 'شما نمیتوانید این گروه را ویرایش کنید',
			'groups:saved' => 'گروه ذخیره شد',
			'groups:featured' => 'گروههای برجسته',
			'groups:makeunfeatured' => 'غیر برجسته',
			'groups:makefeatured' => 'برجسته کن',
			'groups:featuredon' => 'شما این گروه را برجسته ساختید.',
			'groups:unfeature' => 'شما این گروه را از برجسته ها برداشتید',
			'groups:joinrequest' => 'درخواست عضویت',
			'groups:join' => 'عضویت در گروه',
			'groups:leave' => 'ترک کردن و لغو عضویت گروه',
			'groups:invite' => 'دعوت کردن دوستان',
			'groups:inviteto' => "دوستانتان را دعوت کنید به'%s'",
			'groups:nofriends' => "هیچ دوستی باقی نمانده که شما به این گروه دعوت نگرده باشید.",
			'groups:viagroups' => "توسط گروهها",
			'groups:group' => "گروه",
			'groups:search:tags' => "برچسب",

			'groups:notfound' => "گروه یافت نشد",
			'groups:notfound:details' => "گروه درخواست شده یا وجود ندارد یا شما حق ورود به آن را ندارید",

			'groups:requests:none' => 'هیچ در خواست عضویتی الان وجود ندارد.',

			'groups:invitations:none' => '.هیچ دعوتی الان وجود ندارد',

			'item:object:groupforumtopic' => "عنوانهای گفتگوها",

			'groupforumtopic:new' => "پست جدید بحث",

			'groups:count' => "گروههای ایجاد شده",
			'groups:open' => "گروههای باز",
			'groups:closed' => "گروههای بسته",
			'groups:member' => "اعضا",
			'groups:searchtag' => "جستجوی گروهها با برچسب",


			/*
			 * Access
			 */
			'groups:access:private' => 'بسته شد_اعضا باید دعوت شوند',
			'groups:access:public' => 'باز شد_هر عضوی میتواند به گروه بپیوندد',
			'groups:closedgroup' => 'عضویت در این گروه بسته شد. اگر میخواهید عضو شوید بر روی درخواست عضویت در لینک منو کلیک کنید.',
			'groups:visibility' => 'چه کسی میتواند این گروه را ببیند؟?',

			/*
			Group tools
			*/
			'groups:enablepages' => 'فعال کردن صفحات گروهها',
			'groups:enableforum' => 'فعال کردن بحثهای گروه',
			'groups:enablefiles' => 'فعال کردن فایلهای گروه',
			'groups:yes' => 'بله',
			'groups:no' => 'خیر',

			'group:created' => 'ایجاد شد %s با %d پستها',
			'groups:lastupdated' => 'آخرین آپدیت %s توسط %s',
			'groups:pages' => 'صفحات گروه',
			'groups:files' => 'فایلهای گروه',

			/*
			Group forum strings
			*/

			'group:replies' => 'پاسخها',
			'groups:forum' => 'بحثهای گروه',
			'groups:addtopic' => 'یک تاپیک اضافه کنید',
			'groups:forumlatest' => 'جدیدترین بحثها',
			'groups:latestdiscussion' => 'جدیدترین بحثها',
			'groups:newest' => 'جدیدترین',
			'groups:popular' => 'محبوب ترین',
			'groupspost:success' => 'نظر شما با موفقیت ارسال شد',
			'groups:alldiscussion' => 'جدیدترین بحث',
			'groups:edittopic' => 'ویرایش تاپیک',
			'groups:topicmessage' => 'عنوان موضوع',
			'groups:topicstatus' => 'موقعیت موضوع',
			'groups:reply' => 'یک نظر ارسال کنیدt',
			'groups:topic' => 'تاپیک',
			'groups:posts' => 'پستها',
			'groups:lastperson' => 'آخرین شخص',
			'groups:when' => 'وقتی',
			'grouptopic:notcreated' => 'هیچ تاپیکی ایجاد نشده.',
			'groups:topicopen' => 'باز',
			'groups:topicclosed' => 'بسته',
			'groups:topicresolved' => 'برطرف شد',
			'grouptopic:created' => 'موضوع شما ایجاد شد.',
			'groupstopic:deleted' => 'موضوع حذف شد.',
			'groups:topicsticky' => 'چسبنده',
			'groups:topicisclosed' => 'این تاپیک بسته شد.',
			'groups:topiccloseddesc' => 'این تاپیک هم اکنون بسته شد و دیگر نظری را نمیپذرید.',
			'grouptopic:error' => 'تاپیک گروه شما نمیتواند ایجاد شود. لطفا دوباره امتحان کنید یا به مدیران سایت اطلاع دهید.',
			'groups:forumpost:edited' => "شما با موفقیت این پست فروم را ویرایش کردید.",
			'groups:forumpost:error' => "مشکلی در ویرایش این فروم پست بود.",
			'groups:privategroup' => 'این گروه به صوذت خصوصی میباشد برای عضویت درخواست دهید.',
			'groups:notitle' => 'گروه باید عنوان داشته باشد',
			'groups:cantjoin' => 'نمیتوانید عضو گروه شوید',
			'groups:cantleave' => 'نمیتوانید گروه را ترک کنید',
			'groups:addedtogroup' => 'کابر با موفقیت به گروه اضافه شد',
			'groups:joinrequestnotmade' => 'نمیتوانید برای عضویت در خواست دهید',
			'groups:joinrequestmade' => 'درخواست کرد برای عضویت در گروه',
			'groups:joined' => 'با موفقیت عضو گروه شد!',
			'groups:left' => 'با موفقیت گروه را ترک کرد',
			'groups:notowner' => 'متاسفیم ضما مالک این گروه نمیباشید.',
			'groups:notmember' => 'متاسفیم شما عضو این گروه نمیباشید.',
			'groups:alreadymember' => 'شما هم اکنون به این گروه پیوستید!',
			'groups:userinvited' => 'کاربر.',
			'groups:usernotinvited' => 'کاربر نمیتواند دعوت شود.',
			'groups:useralreadyinvited' => 'کاربر هم اکنون دعوت شد',
			'groups:updated' => "آخرین نظر",
			'groups:invite:subject' => "%s شما برای پیوستن دعوت شدید به گروه %s!",
			'groups:started' => "شروع توسط",
			'groups:joinrequest:remove:check' => 'آیا شما مطمئن هستید که میخواهید این درخواست را لغو کنید?',
			'groups:invite:body' => "Hi %s,

%s شما را برای پیوستن به دعوت کرده است  '%s'گروه, برای تایید در قسمت پایین کلیک کنید:

%s",

			'groups:welcome:subject' => "خوش امدید به %s گروه!",
			'groups:welcome:body' => "سلام %s!

شما الان عضوی هستید از '%s' گروه! برای ارسال پست در قسمت پایین کلیک کنید!

%s",

			'groups:request:subject' => "%s برای عضویت درخواست داده است %s",
			'groups:request:body' => "سلام %s,

%s درخواست داده است برای پیوستن به '%s' گروه, برای دیدن پروفایلشان در قسمت پایین کلیک کنید:

%s

یا اینکه درخواست را تایید کنید:

%s",

			/*
				Forum river items
			*/

			'groups:river:member' => 'هم اکنون عضو',
			'groupforum:river:updated' => '%s آپدیت کرده است',
			'groupforum:river:update' => 'این موضوع بحث',
			'groupforum:river:created' => '%s ایجاد کرده است',
			'groupforum:river:create' => 'تاپیک جدید بحث عنوان بندی شد',
			'groupforum:river:posted' => '%s یک نظر جدید ارسال کرد',
			'groupforum:river:annotate:create' => 'در این موضوع بحث',
			'groupforum:river:postedtopic' => '%s یک موضوع بحث جدید را آغاز کرده است',
			'groups:river:member' => '%sالان عضوی است از',
			'groups:river:togroup' => 'در گروه',

			'groups:nowidgets' => 'هیچ بخش خاصی برای این گروه یافت نشد.',


			'groups:widgets:members:title' => 'اعضای گروه',
			'groups:widgets:members:description' => 'لیست اعضای این گروه.',
			'groups:widgets:members:label:displaynum' => 'لیست اعضای یک گروه.',
			'groups:widgets:members:label:pleaseedit' => 'لطفا این بخش را ایجاد کنید.',

			'groups:widgets:entities:title' => "شکایات گروه",
			'groups:widgets:entities:description' => "لیست  شکایات ذخیره شده در گروه",
			'groups:widgets:entities:label:displaynum' => 'لیست اشکایات گروه.',
			'groups:widgets:entities:label:pleaseedit' => 'لطفا این بخش را ایجاد کنید.',

			'groups:forumtopic:edited' => 'بحث با موفقیت ویرایش شد.',

			'groups:allowhiddengroups' => 'شما نمیخواهید این گروه خصوصی( غیر قابل دیدن) باشد?',

			/**
			 * Action messages
			 */
			'group:deleted' => 'گروه و محتوای گروه حذف شد',
			'group:notdeleted' => 'گروه قابل حذف شدن نمیباشد',

			'grouppost:deleted' => 'ارسال پست گروه با موفقیت حذف  شد',
			'grouppost:notdeleted' => 'ارسال پست گروه قابل حذف شدن نیست',
			'groupstopic:deleted' => 'تاپیک حذف شد',
			'groupstopic:notdeleted' => 'تاپیک حذف نشد',
			'grouptopic:blank' => 'بدون تاپیک',
			'grouptopic:notfound' => 'تاپیک پیدا نمیشود ',
			'grouppost:nopost' => 'پست خالی',
			'groups:deletewarning' => "آیا شما مطمئن هستید که این گروه را میخواهید حذف کنید؟بازگشتی وجود ندارد!",

			'groups:joinrequestkilled' => 'تقاضای عضویت حذف شد.',
	);

	add_translation("ir",$farsi);
?>
