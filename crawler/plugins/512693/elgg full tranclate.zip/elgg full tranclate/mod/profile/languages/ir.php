<?php
	/**
	 * Elgg profile plugin language pack
	 *
	 * @package ElggProfile
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2010
	 * @link http://elgg.com/
	 */

	$farsi = array(

	/**
	 * Profile
	 */

		'profile' => "پروفــایل",
		'profile:edit:default' => 'زمینه های پروفایل را به سلیقه خود جایگزین کنید',
		'profile:preview' => 'پیش نمایش',

	/**
	 * Profile menu items and titles
	 */

		'profile:yours' => "پروفایل شما",
		'profile:user' => "%s's پروفایل",

		'profile:edit' => "ویراش پروفایل",
		'profile:profilepictureinstructions' => "عکس پروفایل عکسی است که در پروفایل شما نمایش داده میشود***آواتار. <br /> شما میتوانید هر زمان که دوست داشتید آن را تغییر دهید.  file formate accepted: GIF, JPG or PNG)",
		'profile:icon' => "عکس پروفایل",
		'profile:createicon' => "آواتار خود را ایجاد کنید",
		'profile:currentavatar' => "آواتار کنونی",
		'profile:createicon:header' => "عکس پروفایل",
		'profile:profilepicturecroppingtool' => "ابزار برش عکس پروفایل",
		'profile:createicon:instructions' => "کلیک و بر روی عکس درگ کنید و بگویید تا چه اندازه میخواهید عکس شما بریده شود. یک پیش نمایش از عکس برش خورده در جعبه سمت راست نمایش داده میشود.وقتی شما از پیش نمایش عکس راضی بودید بر روی ایجاد آواتار کلیک کنید و این عکس انتخابی شما به عنوان آواتار در کل سایت نمایش داده میشود. ",

		'profile:editdetails' => "ویرایش جزییات",
		'profile:editicon' => "ویرایش آیکون پروفایل",

		'profile:aboutme' => "مختصری از بیوگرافی من",
		'profile:description' => "مختصری از بیوگرافی من",
		'profile:briefdescription' => "توصیف مختصر",
		'profile:location' => "محل اقامت",
		'profile:skills' => "مهارتها",
		'profile:interests' => "علایق",
		'profile:contactemail' => "ایمیل آدرس",
		'profile:phone' => "تلفن ",
		'profile:mobile' => "موبایل",
		'profile:website' => "وبسایت یا وبلاگ",

		'profile:banned' => 'حساب کاربری این شخص بسته شده است.',
		'profile:deleteduser' => 'کاربر حذف شده',

		'profile:river:update' => "%s پروفایل خود را آپدیت کرد",
		'profile:river:iconupdate' => "%s آیکون پروفایل را آپدیت کرد",

		'profile:label' => "برچسب پروفایل",
		'profile:type' => "نوع پروفایل",

		'profile:editdefault:fail' => 'پروفایل پیش فرض قابل ذخیره شدن نمیباشد',
		'profile:editdefault:success' => 'آیتم با موفقیت به پروفایل پیش فرض اضافه شد',


		'profile:editdefault:delete:fail' => 'برداشتن زمینه های پروفایل پیش فرض موفق نبود',
		'profile:editdefault:delete:success' => 'آیتمهای پروفایل پیش فرض حذف شد!',

		'profile:defaultprofile:reset' => 'سیستم پروفایل پیش فرض باز نشانی شد',

		'profile:resetdefault' => 'باز نشانی پروفایل پیش فرض',
		'profile:explainchangefields' => 'You can replace the existing profile fields with your own using the form below. First you give the new profile field a label, for example, \'Favourite team\'. Next you need to select the field type, for example, tags, url, text and so on. At any time you can revert back to the default profile set up.',


	/**
	 * Profile status messages
	 */

		'profile:saved' => "پروفایل شما با موفقیت ذخیره شد.",
		'profile:icon:uploaded' => "عکس پروفایل شما با موفقیت آپلود شد.",

	/**
	 * Profile error messages
	 */

		'profile:noaccess' => "اجازه ویرایش این پروفایل را ندارید.",
		'profile:notfound' => "متاسفیم ما نتوانستیم پروفایل مورد نظر را پیدا کنیم.",
		'profile:icon:notfound' => "متاسفیم در آپلود عکس پروفایل مشکلی وجود دارد.",
		'profile:icon:noaccess' => 'شما نمیتوانید این پروفایل آیکون را تغییر دهید',
		'profile:field_too_long' => 'اطلاعات پروفایل شما ذخیره نمیشود "%s" بخش خیلی طولانی میباشد.',

	);

	add_translation("ir",$farsi);