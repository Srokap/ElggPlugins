<?php
	/**
	 * Elgg file plugin language pack
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2010
	 * @link http://elgg.com/
	 */

	$farsi = array(
	
		/**
		 * Menu items and titles
		 */
	
			'file' => "فایل",
			'files' => "فایلها",
			'file:yours' => "فایلهای  شما",
			'file:yours:friends' => "فایلهای دوستان شما",
			'file:user' => "%s's فایلهای",
			'file:friends' => "%s's فایلهای دوستان",
			'file:all' => "همه فایلهای سایت",
			'file:edit' => "ویرایش فایل",
			'file:more' => "فایلهای بیشتر",
			'file:list' => "مشاهده لیست",
			'file:group' => "فایلهای گروه",
			'file:gallery' => "مشاهده گالری",
			'file:gallery_list' => "گالری یا مشاهده لیست",
			'file:num_files' => "تعداد فایلها برای نمایش",
			'file:user:gallery'=>'مشاهده %s گالری', 
	        'file:via' => 'via files',
			'file:upload' => "آپلود یک فایل",
			'file:replace' => 'محتوای فایل را جایگزین کنید(leave blank to not change file)',
	
			'file:newupload' => 'آپلود فایل جدید',
			
			'file:file' => "فایل",
			'file:title' => "عنوان",
			'file:desc' => "توضیح",
			'file:tags' => "برچسبها",
	
			'file:types' => "انواع فایلهای آپلودش شده",
	
			'file:type:all' => "همه فایلها",
			'file:type:video' => "ویدئو ها",
			'file:type:document' => "اسناد",
			'file:type:audio' => "آهنگ",
			'file:type:image' => "عکسها",
			'file:type:general' => "عمومی",
	
			'file:user:type:video' => "%s's ویدئوهای",
			'file:user:type:document' => "%s's اسناد",
			'file:user:type:audio' => "%s's آهنگ",
			'file:user:type:image' => "%s's عکسها",
			'file:user:type:general' => "%s's فایهای عمومی",
	
			'file:friends:type:video' => "ویدئوهای دوستان شما",
			'file:friends:type:document' => "اسناد دوستان شما",
			'file:friends:type:audio' => "آهنگهای دوستان شما",
			'file:friends:type:image' => "عکسهای دوستان شما",
			'file:friends:type:general' => "فایلهای عمومی دوستان شما",
	
			'file:widget' => "جعبه فایل",
			'file:widget:description' => "نمایش آخرین فایلها",
	
			'file:download' => "این را دانلود کن",
	
			'file:delete:confirm' => "آیا مطمئن هستید که میخوهید این فایل را حذف کنید?",
			
			'file:tagcloud' => "ابر برچسب",
	
			'file:display:number' => "تعداد فایلها برای نمایش",
	
			'file:river:created' => "%s آپلود شده های",
			'file:river:item' => "a file",
			'file:river:annotate' => "يک نظر بر روي اين فايل",

			'item:object:file' => 'فايلها',
			
	    /**
		 * Embed media
		 **/
		 
		    'file:embed' => "کد فایل",
		    'file:embedall' => "همه",
	
		/**
		 * Status messages
		 */
	
			'file:saved' => "فایل شما با موفقیت ذخیره شد.",
			'file:deleted' => "فایل شما با موفیقت حذف شد.",
	
		/**
		 * Error messages
		 */
	
			'file:none' => "هیچ فایلی آپلود نشد.",
			'file:uploadfailed' => "متاسفیم ما نمیتواینم فایل شما را ذخیره کنیم.",
			'file:downloadfailed' => "متاسفیم این فایل در این لحظه در دسترس نمیباشد.",
			'file:deletefailed' => "متاسفیم فایل شما در این لحظه حذف نمیشود.",
			'file:noaccess' => "شما اجازه تغییر این فایل را ندارید",
			'file:cannotload' => "در هنگام بار گزاری فایل خطایی به وجود امد",
			'file:nofile' => "شما باید فایلی را انتخاب کنید",
	);
					
	add_translation("ir",$farsi);
?>