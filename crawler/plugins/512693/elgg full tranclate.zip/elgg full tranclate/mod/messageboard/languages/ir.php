<?php

	$farsi = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messageboard:board' => "جعبه ارسال پیام",
			'messageboard:messageboard' => "جعبه ارسال پیام",
			'messageboard:viewall' => "مشاهده همه",
			'messageboard:postit' => "ارسال کنید",
			'messageboard:history:title' => "گذشته",
			'messageboard:none' => "هنوز چیزی در جعبه ارسال پیام وجود ندارد",
			'messageboard:num_display' => "تعداد پیامها برای نمایش",
			'messageboard:desc' => "این یک جعبه ارسال پیام میباشد که شما میتوانید آن را در پروفایلتان قرار دهید تا دیگران با استفاده از آن برای شما نظر ارسال کنند.",
	
			'messageboard:user' => "%s's جعبه پیام",
	
			'messageboard:replyon' => 'پاسخ به',
			'messageboard:history' => "گذشته",
	
         /**
	     * Message board widget river
	     **/
	        
	        'messageboard:river:annotate' => "%sیک پیام جدید  دادند در جعبه نظرشان.",
	        'messageboard:river:create' => "%s جعبه ارسال پیام را اضافه کردند.",
	        'messageboard:river:update' => "%s جعبه ارسال پیامشان را آپدیت کردند.",
	        'messageboard:river:added' => "%s ارسال شده در",
		    'messageboard:river:messageboard' => "جعبه ارسال پیام",

			
		/**
		 * Status messages
		 */
	
			'messageboard:posted' => "شما با موفقیت پست کردید در جعبه پیام.",
			'messageboard:deleted' => "شما با موفقیت پیام را پاک کردید.",
	
		/**
		 * Email messages
		 */
	
			'messageboard:email:subject' => 'شما پیام جدیدی در جعبه ارسال پیام دارید!',
			'messageboard:email:body' => "شما پیام جدیدی در جعبه پیام دارید از %s. او میگوید:

			
%s


برای دیدن پیامهای جعبه پیام اینجا کلیک کنید:

	%s
برای مشاهده %s's پروفایل, اینجا کلیک کنید:

	%s
شما نمیتوانید این ایمیل را پاسخ دهید.",
	
		/**
		 * Error messages
		 */
	
			'messageboard:blank' => "متاسفیم,شما باید در محدوده ارسال مسیج قبل از اینکه آن را پست میکنید چیزی قرار دهید.",
			'messageboard:notfound' => "متاسفیم ما آیتم مورد نظر شما را پیدا نکردیم.",
			'messageboard:notdeleted' => "متاسفیم ما نمیتوانیم آن پیام را حذف کنیم.",
			'messageboard:somethingwentwrong' => "در هنگام ذخیر پیام خطایی بوجود آمد.مطمئن هستید در نوشتن آن اشکالی وجود نداشته است.",
	     
			'messageboard:failure' => "در هنگام اضافه کردن پیام خطایی بوجود آمد لطفا دوباره تلاش کنید.",
	
	);
					
	add_translation("ir",$farsi);

?>