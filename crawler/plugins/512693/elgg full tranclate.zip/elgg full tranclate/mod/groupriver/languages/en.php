<?php

   /**
   * Activity River for Groups
   *
   *
   * @author Jon Maul
   * @copyright The MITRE Corporation 2010
   * @link http://www.mitre.org/
   */

$english = array(
	'groupriver' => 'Group activity',
    'groupriver:widget:title' => 'Group activity',
    'groupriver:widget:description' => 'Group activity',
 	);

  add_translation('en',$english);

?>
