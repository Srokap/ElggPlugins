<?php

   /**
   * Activity River for Groups
   *
   *
   * @author Jon Maul
   * @copyright The MITRE Corporation 2010
   * @link http://www.mitre.org/
   */

$farsi = array(
	'groupriver' => 'فعاليتهاي گروه',
    'groupriver:widget:title' => 'فعاليتهاي گروه',
    'groupriver:widget:description' => 'فعاليتهاي گروه',
 	);

  add_translation('ir',$farsi);

?>
