<?php

$farsi = array (

	/**
	 * Nice name for the entity (shown in admin panel)
	 */
	'item:object:moddefaultwidgets' => 'تنظیمات پیش فرض بخش امکانات',

	/**
	 * Menu items
	 */
	'defaultwidgets:menu:profile' => 'تنظیمات پیش فرض بخش امکانات پروفایل',
    'defaultwidgets:menu:dashboard' => 'بخش پیش فرض داشبود',

    'defaultwidgets:admin:error' => 'خطا,شما به عنوان مدیر این بخش وارد نشده اید',
	'defaultwidgets:admin:notfound' => 'خطا:صفحه پیدا نشد',
	'defaultwidgets:admin:loginfailure' => 'خطا:شما به عنوان مدیر وارد بخش نشده اید',

	'defaultwidgets:update:success' => 'تنظیمات بخش امکانات ذخیره شد',
	'defaultwidgets:update:failed' => 'خطا:تنظیمات ذخیره نشد',
	'defaultwidgets:update:noparams' => 'خطا:پارامترهای غلط',

	'defaultwidgets:profile:title' => 'تنظیمات بخش امکانات برای کاربران تازه عضو شده',
	'defaultwidgets:dashboard:title' => 'برای کاربران جدید بخش امکانات داشبورد را فعال کنید',
);

add_translation ( "ir", $farsi );
