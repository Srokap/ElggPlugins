<?php
	/**
	 * Elgg reported content plugin language pack
	 * 
	 * @package ElggReportedContent
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2010
	 * @link http://elgg.com/
	 */

	$farsi = array(
	
		/**
		 * Menu items and titles
		 */
	
			'item:object:reported_content' => 'آیتمهای گزارش شده',
			'reportedcontent' => 'مطالب گزارش شده',
			'reportedcontent:this' => 'این را گزارش دهید',
			'reportedcontent:none' => 'هیچ مطلب گزارش شده ایی وجود ندارد',
			'reportedcontent:report' => 'گزارش به مدیر',
			'reportedcontent:title' => 'عنوان صفحه',
			'reportedcontent:deleted' => 'محتوای گزارش شده ذخیره شد',
			'reportedcontent:notdeleted' => 'ما قادر به حذف این صفحه نبودیم',
			'reportedcontent:delete' => 'حذف کن',
			'reportedcontent:areyousure' => 'مطمئنید که میخواهید حذف کنید?',
			'reportedcontent:archive' => 'آرشیو کن',
			'reportedcontent:archived' => 'گزارش آرشیو شد',
			'reportedcontent:visit' => 'مشاهده آیتمهای گزارش شده',
			'reportedcontent:by' => 'گزارش توسط',
			'reportedcontent:objecttitle' => 'شکایت عنوان',
			'reportedcontent:objecturl' => 'شکایت url',
			'reportedcontent:reason' => 'دلیل گزارش',
			'reportedcontent:description' => 'چرا شما این را گزارش میکنید?',
			'reportedcontent:address' => 'مکان آیتم',
			'reportedcontent:success' => 'گزارش شما به مدیر سایت ارسال شد',
			'reportedcontent:failing' => 'گزارش شما ارسال نشد',
			'reportedcontent:report' => 'گزارش این', 
			'reportedcontent:moreinfo' => 'اطلاعات بیشتر',
	
			'reportedcontent:failed' => 'متاسفیم تلاش شما برای گزارش بینتیجه بود.',
			'reportedcontent:notarchived' => 'متاسفیم ما نتوانستیم این گزارش را آرشیو کنیم',
	);
					
	add_translation("ir",$farsi);
?>