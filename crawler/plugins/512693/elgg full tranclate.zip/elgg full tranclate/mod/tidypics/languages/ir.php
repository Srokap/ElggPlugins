<?php

	$farsi = array(
		// hack for core bug
			'untitled' => "بدون عنوان",

		// Menu items and titles

			'image' => "عکس",
			'images' => "عکسها",
			'caption' => "عنوان",
			'photos' => "عکسها",
			'images:upload' => "آپلود عکسها",
			'images:multiupload' => "ابزار آپلود فلش",
			'images:multiupload:todo' => "یک یا چند فایل را برای آپلود انتخاب کنید.",
			'album' => "آ",
			'albums' => "آلبوم عکس",
			'album:slideshow' => "نمایش اسلاید",
			'album:yours' => "آلبوم عکسهای شما",
			'album:yours:friends' => "آلبوم عکسهای دوستان شما",
			'album:user' => "%s's آلبوم عکسهای",
			'album:friends' => "%s's آلبوم عکسهای دوستان",
			'album:all' => "همه آلبوم عکسهای سایت",
			'album:group' => "آلبومهای گروه",
			'item:object:image' => "عکسها",
			'item:object:album' => "آلبومها",
			'tidypics:uploading:images' => "لطفا در حال آلپود عکسها صبر داشته باشید.",
			'tidypics:enablephotos' => 'فعال کردن آلبوم عکسهای گروه',
			'tidypics:editprops' => 'ویرایش ویژگی های عکس',
			'tidypics:mostcommented' => 'عکسهای با بیشترین نظر',
			'tidypics:mostcommentedthismonth' => 'بیشترین نظرهای این ماه',
			'tidypics:mostcommentedtoday' => 'بیشترین نظرهای امروز',
			'tidypics:mostviewed' => 'بیشترین بازدیدهای امروز',
			'tidypics:mostvieweddashboard' => 'بیشترین بازدید میزکار',
			'tidypics:mostviewedthisyear' => 'بیشترین بازدید امسال',
			'tidypics:mostviewedthismonth' => 'بیشترین بازدید این ماه',
			'tidypics:mostviewedlastmonth' => 'بیشترین بازدید ماه گذشته',
			'tidypics:mostviewedtoday' => 'بیشترین بازدید امروز',
			'tidypics:recentlyviewed' => 'بیشترین بازدید عکسهای اخیر',
			'tidypics:recentlycommented' => 'آخرین نظرات عکسها',
			'tidypics:mostrecent' => 'بیشترین عکسهای اخیر',
			'tidypics:yourmostviewed' => 'بیشترین بازدید عکسهای شما',
			'tidypics:yourmostrecent' => 'بیشترین عکسهای اخیر شما',
			'tidypics:friendmostviewed' => "%s's بیشترین بازدید عکسهای",
			'tidypics:friendmostrecent' => "%s'sبیشترین عکسهای اخیر",
			'tidypics:highestrated' => "عکسها با بالاترین رای",
			'tidypics:views' => "Views: %s",
			'tidypics:viewsbyowner' => "توسط %s کاربران که شمامل شما نمیشود",
			'tidypics:viewsbyothers' => "(%s توسط شما)",
			'tidypics:administration' => 'Tidypics Administration',
			'tidypics:stats' => 'Stats',
			'flickr:setup' => 'Flickr Setup',
			'flickr:usernamesetup' => 'Please enter your Flickr username here:',
			'flickr:selectalbum' => 'Select album to import photos into',
			'flickr:albumdesc' => 'Album to import photos to:',
			'flickr:importmanager' => 'Photoset Import Manager',
			'flickr:desc' => 'روی مجموعه ایی که میخواهید واردسایت کنید کلیک کنید.<br />کپی از عکسها ایجاد میشود و در سایت نمایش داده میشود.',
			'flickr:intro' => 'فلیکر به شما این اجازه را میدهد با استفاده از حساب کاربری خود عکسهای فلیکر را وارد این سایت کنید.وارد حساب کاربر فلیکر شوید . <br />.',
			'flickr:menusetup' => 'تنظیمات فلیکر',
			'flickr:menuimport' => 'وارد کردن عکسهای فلیکر',
			
		//settings
			'tidypics:settings' => 'Settings',
			'tidypics:admin:instructions' => 'These are the core Tidypics settings. Change them for your setup and then click save.',
			'tidypics:settings:image_lib' => "Image Library",
			'tidypics:settings:thumbnail' => "Thumbnail Creation",
			'tidypics:settings:help' => "Help",
			'tidypics:settings:download_link' => "Show download link",
			'tidypics:settings:tagging' => "Enable photo tagging",
			'tidypics:settings:photo_ratings' => "Enable photo ratings (requires rate plugin of Miguel Montes or compatible)",
			'tidypics:settings:exif' => "Show EXIF data",
			'tidypics:settings:view_count' => "View counter",
			'tidypics:settings:grp_perm_override' => "Allow group members full access to group albums",
			'tidypics:settings:maxfilesize' => "Maximum image size in megabytes (MB):",
			'tidypics:settings:quota' => "User/Group Quota (MB) - 0 equals no quota",
			'tidypics:settings:watermark' => "Enter text to appear in the watermark - not for production sites yet",
			'tidypics:settings:im_path' => "Enter the path to your ImageMagick commands (with trailing slash)",
			'tidypics:settings:img_river_view' => "How many entries in river for each batch of uploaded images",
			'tidypics:settings:album_river_view' => "Show the album cover or a set of photos for new album",
			'tidypics:settings:largesize' => "Primary image size",
			'tidypics:settings:smallsize' => "Album view image size",
			'tidypics:settings:thumbsize' => "Thumbnail image size",
			'tidypics:settings:im_id' => "Image ID",
	
		//actions

			'album:create' => "ایجاد یک آلبوم جدید",
			'album:add' => "اضافه کردن آلبوم",
			'album:addpix' => "ارســــــال عکس به این آلبوم",
			'album:edit' => "ویرایـش آلبوم",
			'album:delete' => "حذف آلبوم",

			'image:edit' => "ویرایش عکس",
			'image:delete' => "حذف عکس",
			'image:download' => "دانلـــود عکس",

		//forms

			'album:title' => "عنوان",
			'album:desc' => "توضیح",
			'album:tags' => "برچسبها",
			'album:cover' => "این را عکس روی جلد آلبوم قرار بده?",
			'tidypics:quota' => "Quota usage:",

		//views

			'image:total' => "عکسها در این آلبوم:",
			'image:by' => "عکس ارسال شد توسط",
			'album:by' => "آلبوم ایجاد شد توسط",
			'album:created:on' => "ایجاد شد",
			'image:none' => "هنوز عکسی اضافه نشد.",
			'image:back' => "قبلی",
			'image:next' => "بعدی",

		// tagging
			'tidypics:taginstruct' => 'منطقه ایی را که میخواهید برچسب گذاری کنید انتخاب کنید',
			'tidypics:deltag_title' => 'برچسب را برای حذف انتخاب کنید',
			'tidypics:finish_tagging' => 'توقف برچسب گذاری',
			'tidypics:tagthisphoto' => 'برچسب بزنید',
			'tidypics:deletetag' => 'برچسب عکس را  پاک کنید',
			'tidypics:actiontag' => 'برچسب',
			'tidypics:actiondelete' => 'حذف',
			'tidypics:actioncancel' => 'لغو',
			'tidypics:inthisphoto' => 'در این عکس',
			'tidypics:usertag' => "عکسهای برچسب گذاری شده توسط %s",
			'tidypics:phototagging:success' => 'برچسب عکس با موفقیت اضافه شد',
			'tidypics:phototagging:error' => 'خطا در حین برچسب گذاری',
			'tidypics:deletetag:success' => 'برچسبهای شما با موفقیت حذف شد',
			
			'tidypics:tag:subject' => "شما در این عکس برچسب گذاری شدید",
			'tidypics:tag:body' => " شما در این عکس برچسب گذاری شدید %s توسط %s.			
			
عکس اینجا میتواند مشاهده شود: %s",


		//rss
			'tidypics:posted' => 'یک عکس ارسال کرد:',

		//widgets

			'tidypics:widget:albums' => "آلبوم عکسها",
			'tidypics:widget:album_descr' => "ویترین آلبوم عکسهای شما",
			'tidypics:widget:num_albums' => "تعداد آلبومهای برای نمایش",
			'tidypics:widget:latest' => "آخرین عکسها",
			'tidypics:widget:latest_descr' => "نمایش آخرین عکسها",
			'tidypics:widget:num_latest' => "تعداد عکسها برای نمایش",
			'album:more' => "نمایش همه آلبومها",

		//  river

			//images
			'image:river:created' => "%s یک عکس ارسال کرد  %s to به آلبوم %s",
			'image:river:item' => "یک عکس",
			'image:river:annotate' => "یک نظر در عکس",
			'image:river:tagged' => "برچسب گذاری کرد در عکس",

			//albums
			'album:river:created' => "%s یک آلبوم جدید بوجود آورد",
			'album:river:group' => "در گروه",
			'album:river:item' => "در گروه",
			'album:river:annotate' => "یک نظر در آلبوم عکس",

		// notifications
			'tidypics:newalbum' => 'آلبوم عکس جدید',


		//  Status messages

			'tidypics:upl_success' => "عکسهای شما با موفقیت آپلود شد.",
			'image:saved' => " عکسهای شما با موفقیت ذخیره شد.",
			'images:saved' => "همه عکسها با موفقیت ذخیره شدند.",
			'image:deleted' => "عکس شما با موفقیت حذف شد.",
			'image:delete:confirm' => "از حذف عکس مطمئن هستید?",

			'images:edited' => "عکسهای شما با موفقیت آپدیت شد.",
			'album:edited' => " آلبوم شما با موفقیت آپدیت شد.",
			'album:saved' => "آلبوم شما با موفقیت ذخیره شد.",
			'album:deleted' => "آلبوم شما با موفقیت حذف شد.",
			'album:delete:confirm' => "آیا از حذف این آلبوم مطمئن هستید?",
			'album:created' => "آلبوم جدید شما ایجاد شد.",
			'tidypics:settings:save:ok' => 'Successfully saved the Tidypics plugin settings',

			'tidypics:upgrade:success' => 'Upgrade of Tidypics a success',
			
			'flickr:enterusername' => 'You must enter a username',
			'flickr:savedusername' => 'Successfully saved username of %s',
			'flickr:saveduserid' => 'Successfully saved userid of %s',
			'flickr:savedalbum' => 'آلبوم ذخیره شد - %s',

		//Error messages

			'tidypics:partialuploadfailure' => "خطایی در قسمت آپلود عکس وجود داشت (%s از %s عکسهای).",
			'tidypics:completeuploadfailure' => "آپلود عکسها ناموفق بود.",
			'tidypics:exceedpostlimit' => "عکسها خیلی حجم زیادی دارند - سعی کنید عکسهای کوچکتر با حجم کمتری را آپلود کنید.",
			'tidypics:noimages' => "هیچ عکسی انتخاب نشده است.",
			'tidypics:image_mem' => "عکس خیلی بزرگ است - حجم زادی دارد",
			'tidypics:image_pixels' => "عکس حجم زیادی دارد",
			'tidypics:unk_error' => "خطای آپلود نامشخص",
			'tidypics:save_error' => "خطای نامشخص در هنگام ذخیره عکس",
			'tidypics:not_image' => "فرمت عکس نامشخص است",
			'tidypics:deletefailed' => "متاسفیم حذف ناموفق بود.",
			'tidypics:deleted' => "حذف موفق.",
			'image:downloadfailed' => "متاسفیم این عکس هم اکنون در دسترس نمیباشد.",
			'tidypics:nosettings' => "Admin of this site has not set photo album settings.",
			'tidypics:exceed_quota' => "You have exceeded the quota set by the administrator",
			'images:notedited' => "همه عکسها با موفقیت آپدیت شد",

			'album:none' => "هنوزآلبومی ایجاد نشده است.",
			'album:uploadfailed' => " متاسفیم ما نمیتوانیم آلبوم شما را ذخیره کنیم.",
			'album:deletefailed' => "آلبوم شما الان قابل حذف شدن نیست.",
			'album:blank' => "لطفا عنوان و توضیحی به آلبوم بدهید.",

			'tidypics:upgrade:failed' => "The upgrade of Tidypics failed",
			
			'flickr:errorusername' => 'Username %s not found on Flickr',
			'flickr:errorusername2' => 'You must enter a username',
			'flickr:errorimageimport' => 'This image has already been imported',
			'flickr:errornoalbum' => "No album selected.  Please choose and save an album: %s" 
	);

	add_translation("ir",$farsi);
?>
