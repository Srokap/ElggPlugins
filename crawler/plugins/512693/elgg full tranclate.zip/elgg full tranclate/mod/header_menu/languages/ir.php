<?php

	$farsi = array(
	
	
			'headermenu:members' => "اعضا",
			'headermenu:photos' => "عکسها",
			'headermenu:groups' => "گروه ها",
			'headermenu:videos' => "ويدئوها",
			'headermenu:current' => "در حال حاضر",
			'headermenu:andmore' => "و بيشتر ...",
			'headermenu:home' => "صفحه اصلي",
			'headermenu:blogs' => "وبلاگها",
			'headermenu:bookmarks' => "بوکمارکها",
			'headermenu:ads' => "دسته بنديها",
			'headermenu:discussions' => "بحثها",
			'headermenu:events' => "رويدادها",
			'headermenu:wire' => "The Wire",
			'headermenu:public' => "publicly available.",
			'headermenu:register' => "به تازگي پيوسته,",
			'headermenu:access' => "براي دست يافتن بيشتر",

			
	);

	add_translation("ir",$farsi);

?>
