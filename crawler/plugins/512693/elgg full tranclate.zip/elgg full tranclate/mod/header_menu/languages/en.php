<?php

	$english = array(
	
	
			'headermenu:members' => "Members",
			'headermenu:photos' => "Photos",
			'headermenu:groups' => "Groups",
			'headermenu:videos' => "Videos",
			'headermenu:current' => "currently has:",
			'headermenu:andmore' => "and more...",
			'headermenu:home' => "Home",
			'headermenu:blogs' => "Blogs",
			'headermenu:bookmarks' => "Bookmarks",
			'headermenu:ads' => "Classifieds",
			'headermenu:discussions' => "Discussions",
			'headermenu:events' => "Events",
			'headermenu:wire' => "The Wire",
			'headermenu:public' => "publicly available.",
			'headermenu:register' => "Register now,",
			'headermenu:access' => "to access more.",

			
	);
	
	add_translation("en",$english);

?>
