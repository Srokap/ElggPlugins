<?php

	$farsi = array(
	
		/**
		 * Menu items and titles
		 */
	
			'blog' => "بلاگ پست",
			'blogs' => "بلاگ پستها",
			'blog:user' => "%s'بلاگ پستهای",
			'blog:user:friends' => "%s'بلاگ پستهای دوستان",
			'blog:your' => "بلاگ پست شما",
			'blog:posttitle' => "%s'بلاگ پست: %s",
			'blog:friends' => "بلاگ پستهای دوستان",
			'blog:yourfriends' => "آخرین بلاگ پستهای دوستان شما",
			'blog:everyone' => "همه بلاگهای سایت",
			'blog:newpost' => "بلاگ پست جدید",
			'blog:via' => "توسط بلاگ",
			'blog:read' => "خواندن بلاگ پست",
	
			'blog:addpost' => "یک بلاگ پست بنویسید",
			'blog:editpost' => "ویرایش بلاگ پست",
	
			'blog:text' => "متن بلاگ پست",
	
			'blog:strapline' => "%s",
			
			'item:object:blog' => 'بلاگ پستها',
	
			'blog:never' => 'هرگز',
			'blog:preview' => 'پیش نمایش',
	
			'blog:draft:save' => 'ذخیره به عنوان پیش نویس',
			'blog:draft:saved' => 'آخرین پیش نویس ذخیره شده',
			'blog:comments:allow' => 'دادن اجازه برای نظر دادن',
	
			'blog:preview:description' => 'این یک پیش نمایش ذخیره نشده از بلاگ پست شما میباشد.',
			'blog:preview:description:link' => 'برای ادامه دادن به ویرایش بلاگ پست اینجا کلیک کنید',
	
			'blog:enableblog' => 'فعال کردن بلاگ پستهای گروه',
	
			'blog:group' => 'بلاگ پست گروه',
			
         /**
	     * Blog river
	     **/
	        
	        //generic terms to use
	        'blog:river:created' => "%sنوشته شد",
	        'blog:river:updated' => "%s آبدين",
	        'blog:river:posted' => "%s ارسال شد",
	        
	        //these get inserted into the river links to take the user to the entity
	        'blog:river:create' => "یک بلاگ پست جدید نامگذاری شد",
	        'blog:river:update' => "یک بلاگ شد نام گذاری شد",
	        'blog:river:annotate' => "یک نظر در این بلاگ پست",
			
	
		/**
		 * Status messages
		 */
	
			'blog:posted' => "بلاگ پست شما با موفقیت ارسال شد.",
			'blog:deleted' => "بلاگ پست شما با موفقیت حذف شد.",
	
		/**
		 * Error messages
		 */
	
			'blog:error' => 'اشکالی بوجود آمده است .لطفا دوباره تلاش کنید.',
			'blog:save:failure' => "بلاگ پست شما نمیتواند ذخیره شود.لطفا دوباره تلاش کنید.",
			'blog:blank' => "متاسفیم; شما باید هر دو قسمت عنوان و بدنه را قبل از ارسال پست کامل کنید .",
			'blog:notfound' => "متاسفیم; ما نتوانستیم بلاگ پست خاصی را پیدا کنیم.",
			'blog:notdeleted' => "متاسفیم; ما نمیتوانیم این بلاگ پست را پاک کنیم.",
	
	);
					
	add_translation("ir",$farsi);

?>