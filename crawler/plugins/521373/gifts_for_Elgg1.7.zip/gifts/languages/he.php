<?php

// Generate By translationbrowser. 

$hebrew = array( 
	 'gifts:menu'  =>  "מתנות" , 
	 'gifts:yourgifts'  =>  "המתנות שלי" , 
	 'gifts:allgifts'  =>  "כל המתנות" , 
	 'gifts:sent'  =>  "מתנות ששלחתי" , 
	 'gifts:sendgifts'  =>  "שליחת מתנה" , 
	 'gifts:friend'  =>  "חבר/ה" , 
	 'gifts:message'  =>  "הודעה" , 
	 'gifts:selectgift'  =>  "בחר/י מתנה" , 
	 'gifts:gift'  =>  "מתנה" , 
	 'gifts:send'  =>  "שלח" , 
	 'gifts:sendok'  =>  "שליחת המתנה הצליחה" , 
	 'gifts:object'  =>  "%s קיבל/ה %s מ%s" , 
	 'gifts:river'  =>  "%s קיבל/ה %s מ" , 
	 'gifts:blank'  =>  "אנא בחר/י חבר/ה" , 
	 'gifts:widget'  =>  "תיבת מתנות" , 
	 'gifts:widget:num_display'  =>  "מספר המתנות" , 
	 'gifts:widget:description'  =>  "הצגת המתנות שקיבלת" , 
	 'gifts:pointssum'  =>  "נשארו לך %s נקודות לשליחת מתנות" , 
	 'gifts:notenoughpoints'  =>  "מצטערים אין לך מספיק נקודות לשליחת מתנה זו!" , 
	 'gifts:pointscost'  =>  "עלויות" , 
	 'gifts:pointfail'  =>  "אירע שגיאה ביישום הנקודות!" , 
	 'gifts:pointsuccess'  =>  "הנקודות הוחסרו בהצלחה!" , 
	 'item:object:gift'  =>  "מתנות" , 
	 'gifts:settings:number'  =>  "כמה מתנות ברצונך לספק" , 
	 'gifts:settings:title'  =>  "מתנות" , 
	 'gifts:settings:globalsettings'  =>  "הגדרות" , 
	 'gifts:settings:giftsettings'  =>  "מתנות" , 
	 'gifts:settings:useuserpoints'  =>  "השתמש בנקודות" , 
	 'gifts:settings:userpoints'  =>  "נקודות" , 
	 'gifts:settings:image'  =>  "תמונה" , 
	 'gifts:settings:showallyes'  =>  "כן" , 
	 'gifts:settings:showallno'  =>  "לא" , 
	 'gifts:settings:showallgifts'  =>  "הצגת כל המתנות" , 
	 'gifts:settings:saveok'  =>  "ההגדרות נשמרו בהצלחה" , 
	 'gifts:settings:savefail'  =>  "לא הצלחנו לשמור את ההגדרות" , 
	 'gifts:mail:subject'  =>  "קיבלת מתנה חדשה!" , 
	 'gifts:mail:body'  =>  "קיבלת מתנה חדשה מ%s.

לתפייה במתנה יש ללחוץ על הקישור למטה: %s 

לא ניתן להשיב לדואר זה."
); 

add_translation('he', $hebrew); 

?>