Elgg Gifts Plugin Changelog
Current Version: 0.2.0
Released: 2010-06-30
Author:   iionly (iionly@gmx.de)

v0.2.0 2010-6-30
    + Compatibility with Elgg 1.7+


Elgg Gifts Plugin Changelog
Current Version: 0.1.2
Released: 2009-09-19
Author:   Galdrapiu

v0.1.2 2009-09-18

    + Accessright


Elgg Gifts Plugin

Current Version: 0.1.0
Released:		 2009-09-07
Author: 		 Christian Heckelmann (checkelmann@gmail.com)

Included Languages:
English, German, Hebrew (thanks to Susan)




Installation:

1. Copy the gifts plugin to you mod folder
2. !!!! Set the folder permissions of gifts/images to be writeable by the webserver (chmod 777) !!!!
3. Enable the gifts plugin in your "Tool Administrator"
4. Configure your Gifts in the Gifts Settings

Important!
If you are using a version below 0.1.0 and uploaded pictures to the images folder,
you have to upload the pictures again within the Gifts admin menu

!!! Please check the permissions of the images directory !!!
=======================================================
For RTL languages change left to right in gifts/views/default/gifts/css.php
from
.river_user_gifts {
    background:transparent url(<?php echo $vars['url']; ?>mod/gifts/river_icon_gifts.gif) no-repeat scroll left -1px;
}

to
.river_user_gifts {
    background:transparent url(<?php echo $vars['url']; ?>mod/gifts/river_icon_gifts.gif) no-repeat scroll right -1px;
}
