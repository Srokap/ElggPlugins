<?php

    require_once $CONFIG->pluginspath . "tidypicsExt/lib/upload_lib.php";
    require_once $CONFIG->pluginspath . "tidypics/actions/upload.php";
