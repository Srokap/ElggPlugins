Just enable it, and enjoy.

Thanks to Pedro Prez for teaching me all about Elgg ^^.


