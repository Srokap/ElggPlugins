<?php
		function Glitterz_init() 
		{
		global $CONFIG;
		add_menu(elgg_echo('Glitterz'), $CONFIG->wwwroot . "mod/Glitterz");
		}
		
	register_elgg_event_handler('init','system','Glitterz_init');
	

?>