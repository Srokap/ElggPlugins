<?php

update_subtype('object', 'phloor_starter_ENTITY');
