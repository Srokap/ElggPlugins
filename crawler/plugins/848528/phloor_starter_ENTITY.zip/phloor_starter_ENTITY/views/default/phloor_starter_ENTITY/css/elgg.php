<?php 
?>

.phloor-starter-ENTITY-description {
    color:#333;
}

.phloor-starter-ENTITY-image {
    border:1px solid #eee;
   
    display:block;
    margin:0 auto;  
    padding:5px;
}

<?php 


