<?php
/**
* iZAP izap_videos
*
* @package youtube, vimeo, veoh and onserver uploading
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.5-2.0
*/

?>
<p class="user_menu_profile">
	<a href="<?php echo $vars['url'] . 'pg/izap_videos/' . $vars['entity']->username;?> "><?php echo elgg_echo('videos');?></a>
</p>