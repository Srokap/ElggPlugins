<?php
/**
* iZAP izap_videos
*
* @package youtube, vimeo, veoh and onserver uploading
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.5-2.0
*/

?>
	<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/izap_videos/views/default/izap_videos/izap.js"></script>