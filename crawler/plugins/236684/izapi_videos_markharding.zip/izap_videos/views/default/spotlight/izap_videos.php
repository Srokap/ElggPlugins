<?php
/**
* iZAP izap_videos
*
* @package youtube, vimeo, veoh and onserver uploading
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.5-1.0
*/

echo elgg_view('spotlight/default');
?>
<div class="contentWrapper" align="right" style="font-size:10px;">
    'izap_videos' by <a href="http://www.izap.in" target="_blank">iZAP Web Solutions</a>
</div>