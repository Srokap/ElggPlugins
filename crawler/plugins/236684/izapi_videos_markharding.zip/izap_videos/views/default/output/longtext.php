<?php
/**
* iZAP izap_videos
*
* @package youtube, vimeo, veoh and onserver uploading
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.5-2.0
*/

	global $CONFIG;
    //echo $vars['value'];
    echo autop(izap_parse_urls(filter_tags($vars['value'])));
?>