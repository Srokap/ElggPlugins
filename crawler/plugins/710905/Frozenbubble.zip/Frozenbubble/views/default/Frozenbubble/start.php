<div class="contentWrapper">
<div align="center">

<?php
echo "<iframe src='$CONFIG->wwwroot/mod/Frozenbubble/Frozenbubble/index.html"."' width='900' height='566'></iframe>";
?>


</div>
</div>