<?php
 
function red_mania_init() {
    // Replace the default index page
    register_plugin_hook('index','system','new_index');
}
 
function new_index() {
    if (!include_once(dirname(dirname(__FILE__)) . "/red_mania/index.php"))
        return false;
 
    return true;
}
 
// register for the init, system event when our plugin start.php is loaded
register_elgg_event_handler('init','system','red_mania_init');
?>