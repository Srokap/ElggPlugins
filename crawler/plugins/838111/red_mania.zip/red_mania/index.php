<?php
if (isloggedin()) forward('activity');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2//EN">
<html>
<head>
<title>Welcome</title>
<style>
a.navwhite:link { text-decoration: none; color: #ffffff; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navwhite:visited { text-decoration: none; color: #ffffff; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navwhite:hover { text-decoration: underline; color: #ffffff; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navblack:link { text-decoration: none; color: #000000; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navblack:visited { text-decoration: none; color: #000000; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navblack:hover { text-decoration: underline; color: #000000; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }

h1 { font-family: Arial, sans-serif; font-size: 30px; color: #a80000;}
h2 { font-family: Arial, sans-serif; font-size: 18px; color: #a80000;}

body,p,b,i,em,dt,dd,dl,sl,caption,th,td,tr,u,blink,select,option,form,div,li { font-family: Arial, sans-serif; font-size: 12px; }

/* IE Specific - Delete this if you do not want a colored scrollbar */
body, textarea {
scrollbar-3dlight-color: #800800;
scrollbar-highlight-color: #800000;
scrollbar-face-color: #800000;
scrollbar-shadow-color: #800800;
scrollbar-darkshadow-color: #805B32;
scrollbar-arrow-color: #FFFFFF;
scrollbar-track-color: #F8EFE2;
}
/* END IE Specific */

</style>


</head>
<body bgcolor="#a80000" >
<p>
<table cellspacing="0" cellpadding="8" width="780" align="center" border="0"
>

<tr>
<td>
<h1 align="center"><br><font
color=#ffffff>Welcome</font></h1>
<p></p></td></tr>
<tr>
<td bgcolor="#ffffff">
<p align="center">&nbsp;</p>
<p align="center">
<table border="0" cellspacing="0" bordercolor="#000000" cellpadding="3"
bgColor=#feb8a0 align=center>

<tr>
<td>
<p>Here you can put ots of things, such as a
about us or rules page. It is very small,but it expands when you
type.</p></td></tr>
<tr>
<td><?php
/**
* Elgg login box
*
* @package Elgg
* @subpackage Core
*
* @uses $vars['module'] The module name. Default: aside
*/

$module = elgg_extract('module', $vars, 'aside');

$login_url = elgg_get_site_url();
if (elgg_get_config('https_login')) {
$login_url = str_replace("http:", "https:", $login_url);
}

$title = elgg_echo('login');
$body = elgg_view_form('login', array('action' => "{$login_url}action/login"));

echo elgg_view_module($module, $title, $body);
?></td></tr>
<tr>
<td>
<p align="center"><font size="4">How to edit</font></p>
<ol>
<li>
<div align="center"><font size="4">Go into your file
manager</font></div>
<li>
<div align="center"><font size="4">Go to red_mania</font></div>
<li>
<div align="center"><font size="4">Edit index.php</font></div>
<li>
<div align="center"><font size="4">Make
edits</font></div></li></ol></td></tr></table></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p></td></tr>
<tr>
<td BGCOLOR=#000000>
<p align="center"><strong><font color="#ffffff">�&nbsp;Yoursite
at&nbsp;yoursite.com&nbsp;</font></strong></p></td></tr></table></p>
</body>
</html>