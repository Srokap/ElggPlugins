<?php
	$english = array(
	    'everybody' => "Everybody",
	    'memberlist' => "Member List",
	    'memberlistdescription' => "Find your friend",
	);
					
	add_translation("en",$english);
?>
