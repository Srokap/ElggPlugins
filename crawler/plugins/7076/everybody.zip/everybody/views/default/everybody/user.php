<?php
		echo "<p>" . autop(elgg_echo("memberlistdescription")) . "</p>";
?>
