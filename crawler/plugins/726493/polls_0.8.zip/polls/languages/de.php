<?php

	$german = array(
	
		/**
		 * Menu items and titles
		 */
	
			'poll' => "Umfrage",
			'polls' => "Umfragen",
			'polls:votes' => "Stimmen",
			'polls:user' => "%ss Umfrage",
			'polls:group_Umfragen' => "Gruppenumfragen",
			'polls:user:friends' => "%ss Freunde Umfragen",
			'polls:your' => "Deine Umfragen",
			'polls:not_me' => "%ss Umfragen",
			'polls:posttitle' => "%ss polls %s",
			'polls:friends' => "Umfragen deiner Freunde",
			'polls:not_me_friends' => "%ss Freunde Umfragen",
			'polls:yourfriends' => "Deiner Freunde letzte Umfragen",
			'polls:everyone' => "Allgemeine Umfragen",
			'polls:read' => "Lies Umfrage",
			'polls:addpost' => "Erstelle eine Umfrage",
			'polls:editpost' => "Bearbeite eine Umfrage",
			'polls:text' => "Umfragetext",
			'polls:strapline' => "%s",			
			'item:object:Umfrage' => 'Umfragen',
			'polls:question' => "Umfrage Frage",
			'polls:responses' => "Antwortm�glichkeiten",
			'polls:results' => "[+] Zeige die Ergebnisse",
			'polls:show_results' => "Zeige die Ergebnisse",
			'polls:show_Umfrage' => "Zeige Umfrage",
			'polls:add_choice' => "Erg�nze Antwort",
			'polls:delete_choice' => "L�sche Antwort",
			'polls:settings:group:title' => "Gruppen Umfragen",
			'polls:settings:group_Umfragen_default' => "ja, an als standard",
			'polls:settings:group_Umfragen_not_default' => "ja, aus als standard",
			'polls:settings:no' => "nein",
			'polls:settings:group_profile_display:title' => "Wenn Gruppenumfragen eingeschaltet sind, wo sollen die Umfragen im Gruppenprofil dargestellt werden?",
			'polls:settings:group_profile_display_option:left' => "links",
			'polls:settings:group_profile_display_option:right' => "rechts",
			'polls:settings:group_profile_display_option:none' => "gar nicht",
			'polls:settings:group_access:title' => "Wenn Gruppenumfragen eingeschaltet sind, wer darf Umfragen erstellen?",
			'polls:settings:group_access:admins' => "�nur Gruppenchefs und Admins",
			'polls:settings:group_access:members' => "jedes Gruppenmitglied",
		/**
	     * Umfrage widget
	     **/
			'polls:latest_widget_title' => "Neueste allgemeine Umfragen",
			'polls:latest_widget_description' => "Zeige die neuesten Umfragen.",
			'polls:my_widget_title' => "Meine Umfragen",
			'polls:my_widget_description' => "Dieses Modul zeigt deine Umfragen.",
			'polls:widget:label:displaynum' => "Wieviel Umfragen m�chtest du sehen?",
			'polls:individual' => "Neueste Umfrage",
			'Umfrage_individual_group:widget:description' => "Zeige diu neuste Umfrage dieser Gruppe.",
			'Umfrage_individual:widget:description' => "Zeige deine neueste Umfrage",
			'polls:widget:no_Umfragen' => "%s hat noch keine Umfragen.",
			'polls:widget:nonefound' => "Keine Umfragen gefunden.",
			'polls:widget:think' => "La� %s wissen was du denkst!",
			'polls:enable_Umfragen' => "Umfragen einschalten",
			'polls:group_identifier' => "(in %s)",
			
         /**
	     * Umfrage river
	     **/
	        
	        //generic terms to use
	        'polls:river:created' => "%s erstellt",
	        'polls:river:updated' => "%s aktualisiert",
	        'polls:river:posted' => "%s ver�ffentlicht",
	        'polls:river:voted' => "%s gew�hlt",
	        //these get inserted into the river links to take the user to the entity
	        'polls:river:create' => "eine neue Umfrage: ",
	        'polls:river:update' => "die Umfrage: ",
	        'Umfrage:river:annotate' => "Umfrage kommentieren",
	        'polls:river:vote' => "auf die Umfrage: ",
		/**
		 * Status messages
		 */
	
			'polls:posted' => "Deine Umfrage wurde ver�ffentlicht.",
			'polls:responded' => "Danke, deine Stimme wurde gez�hlt.",
			'polls:deleted' => "Deine Umfrage wurde gel�scht.",
			'polls:totalvotes' => "Gesamtzahl der Antworten: ",
			'polls:voted' => "Deine Stimme f�r diese Umfrage wurde abgegeben. Danke.",
			
	
		/**
		 * Error messages
		 */
	
			'polls:save:failure' => "Dfeine Umfrage konnte nicht gespeichert werden. Bitte versuch's nochmal.",
			'polls:blank' => "Entschuldigung: du mu�t erst die Frage und die Antwort ausf�llen, um eine Umfrage zu erstellen.",
			'polls:novote' => "Entschuldigung: du mu�t eine Auswahl treffen, um an der Umfrage teilzunehmen.",
			'polls:notfound' => "Entschuldigung: wir konnten diese Umfrage nicht finden.",
			'polls:nonefound' => "Keine Umfragen von %s wurden gefunden",
			'polls:notdeleted' => "Entschuldigung: wir konnten diese Umfrage nicht l�schen."
	);
					
	add_translation("de",$german);

?>