<?php

	/**
	 * Elgg widget save action
	 * 
	 * @package Elgg
	 * @subpackage Core

	 * @author Curverider Ltd

	 * @link http://elgg.org/
	 */
                action_gatekeeper();
		set_context('event_calendar');
		date_default_timezone_set('UTC');
		$guid = get_input('guid');
		$event = get_entity($guid);
		$start_delta = get_input('start_delta', 0);
		$end_delta = get_input('end_delta', 0);
		$event->allday = get_input('allday', "true")=="true" ? true : false;		
		$event->start_date += $start_delta;

//		if (!$event->end_date) {
//			$event->end_date = $event->start_date;	
//			$oneday = true;
//		} else {
//			$start_date = getdate($event->start_date);
//			$end_date = getdate($event->end_date);
//			
//			if ($start_date['year'] == $end_date['year'] && $start_date['yday'] == $end_date['yday']) {
//				$oneday = true;
//			} else {
//				$oneday = false;
//			}
//		}
		if (!$event->end_date || $event->start_date == $event->end_date) {
			$event->end_date = $event->start_date + 2 * 3600; 
		} else {
			$event->end_date += $start_delta + $end_delta; 
		}
		$start_date = getdate($event->start_date);
		$end_date = getdate($event->end_date);


		if (!$event->allday) {
			$event->start_time = $start_date['minutes'] + $start_date['hours'] * 60;
			$event->end_time = $end_date['minutes'] + $end_date['hours'] * 60;// + 2 * 60;
		} else {
			$event->start_time = '';
			$event->end_time = '';
		}
		
		if ($event->canEdit())
			echo "Can!";
		else
			echo "NOT!";

		if ($event->save())
			echo "saved!";

?>
