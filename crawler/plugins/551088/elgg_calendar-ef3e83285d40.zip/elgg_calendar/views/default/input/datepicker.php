<?php

/**
 * JQuery data picker
 * 
 * @package event_calendar
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2008
 * @link http://radagast.biz/
 * 
 */
global $CONFIG;

$dateformat = get_plugin_usersetting("dateformat", $_SESSION['user']->guid, "event_calendar");
if (!$dateformat)
	$dateformat = "dd/mm/yyyy";

$locale = get_current_language();
$locale = $locale."_".strtoupper($locale);
$locale = Array($locale.".UTF-8", $locale, get_current_language());
setlocale(LC_TIME, $locale);

?>
<script type="text/javascript" src="<?php echo $CONFIG->wwwroot?>mod/event_calendar/js/date.js"></script> 
<script type="text/javascript" src="<?php echo $CONFIG->wwwroot?>mod/event_calendar/js/jquery.datePicker.js"></script>
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo $CONFIG->wwwroot?>mod/event_calendar/js/datePicker.css"> 
<link rel="stylesheet" type="text/css" href="<?php echo $CONFIG->wwwroot?>mod/event_calendar/js/inline-datepicker.css">

<script language="javascript">
$(document).ready(function(){
	Date.monthNames =  [<?php for($i = 1; $i <= 12;  $i++) echo "'".strftime("%B", mktime(0, 0, 0, $i)) . "',";?>];
	Date.abbrMonthNames =  [<?php for($i = 1; $i <= 12;  $i++) echo "'".strftime("%b", mktime(0, 0, 0, $i)) . "',";?>];
	Date.dayNames = [<?php for($i = 6; $i <= 13;  $i++) echo "'".strftime("%A", mktime(0, 0, 0, 0, $i)) . "',";?>];
	Date.abbrDayNames =[<?php for($i = 6; $i <= 13;  $i++) echo "'".strftime("%a", mktime(0, 0, 0, 0, $i)) . "',";?>];
	Date.format = "<?php echo $dateformat?>";
	$.dpText = {
		TEXT_PREV_YEAR		:	'<?php echo elgg_echo("event_calendar:previousyear_label")?>',
		TEXT_PREV_MONTH		:	'<?php echo elgg_echo("event_calendar:previousmonth_label")?>',
		TEXT_NEXT_YEAR		:	'<?php echo elgg_echo("event_calendar:nextyear_label")?>',
		TEXT_NEXT_MONTH		:	'<?php echo elgg_echo("event_calendar:nextmonth_label")?>',
		TEXT_CLOSE			:	'Close',
		TEXT_CHOOSE_DATE	:	'Choose date',
		HEADER_FORMAT		:	'mmmm yyyy'
	};
	$('#<?php echo $vars['internalname'] ?>').datePicker({startDate:'01/01/1996'});

//$("#<?php echo $vars['internalname']; ?>").datepicker({ 
//    dateFormat: "DD, MM d, yy", 
//    showOn: "both", 
//    buttonImage: "<?php echo $vars['url']; ?>mod/event_calendar/images/calendar.gif", 
//    buttonImageOnly: true 
//})

});
</script>
<input type="text" size="30" value="<?php echo $vars['value']; ?>" name="<?php echo $vars['internalname']; ?>" id="<?php echo $vars['internalname']; ?>" class="date-pick" />
<br />
