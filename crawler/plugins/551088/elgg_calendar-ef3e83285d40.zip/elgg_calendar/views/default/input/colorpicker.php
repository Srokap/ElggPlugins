<script type='text/javascript' src='<?php echo $CONFIG->wwwroot."mod/event_calendar/js/jscolor.js"?>'></script> 

<?php
        $form_body .= elgg_view("input/hidden", array('internalname' => 'color', 'value'=>$vars['value']));
	$form_body .= "<div><input class='color {hash:true}' value='".$vars['value']."' onchange=\"$('input[name=color]').val('#'+this.color)\"></div>";
	echo $form_body;
?>
