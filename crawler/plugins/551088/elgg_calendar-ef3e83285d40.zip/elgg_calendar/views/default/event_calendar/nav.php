<?php
	global $CONFIG; 

	$url = $CONFIG->wwwroot.'pg/event_calendar/' ; 
	$url .= page_owner() ? 'group/' . page_owner() . '/' : '';
?>
<div id="elgg_horizontal_tabbed_nav"></div>
<script>

	var selected;
	function createTabs(selector) {

		var baseurl = "<?php echo $url?>";
		var filters = ["all", "friends", "mine"];
		var labels = ["<?php echo elgg_echo('all') . '","' . elgg_echo('friends') . '","' . elgg_echo('mine')?>"];
		var initTab = 0;
		var ul=$("<ul>");	

		function tab(i) {
			return $("<a>").attr("href", "##").text(labels[i]).click(function () {

				var p = $(this).parent().parent();	
				for (var j=0; j<p.children().length; j++) {
					var c = p.children().get(j);
					$(c).removeClass('selected');
				}
				$(this).parent().addClass('selected');
				$('#fullcalendar').fullCalendar('removeEvents');
				$('#fullcalendar').fullCalendar('addEventSource', baseurl + filters[i] + '?format=json_events');
				$('#navcalendar').dpSetEvents(baseurl + filters[i]);
	
			});
		}

		for (var i=0; i<labels.length; i++) {
			var a=tab(i);
			if (i == initTab) {
				ul.append($("<li>").append(a).addClass('selected'));
				selected = a;
			} else {
				ul.append($("<li>").append(a));
			}
		}
		$(selector).html(ul);
	}
	
	createTabs("#elgg_horizontal_tabbed_nav");
	
	$(document).ready(function() {
		selected.trigger("click");
	});
</script>


