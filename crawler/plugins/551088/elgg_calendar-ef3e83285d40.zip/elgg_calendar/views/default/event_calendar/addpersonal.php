<?php
	global $CONFIG;
	$event_id = $vars['event_id'];
	$event = get_entity($event_id);
	if (event_calendar_has_personal_event($event_id,$_SESSION['user']->getGUID())) {
		$add = "false";			
	} else {
		$add = "true";
	}
?>
<!-- un estilito por aki-->

<script>
	var event_id = <?php echo $event_id;?>;
	var add = <?php echo $add;?>;
	var label_remove = "<?php echo elgg_echo('event_calendar:remove_from_my_calendar');?>";
	var label_add = "<?php echo elgg_echo('event_calendar:add_to_my_calendar');?>";
	var url_remove = "<?php echo $CONFIG->url . "action/event_calendar/manage?event_action=remove_personal&event_id=".$event_id.'&'.event_calendar_security_fields().'&forward=false';?>";
	var url_add = "<?php echo $CONFIG->url . "action/event_calendar/manage?event_action=add_personal&event_id=".$event_id.'&'.event_calendar_security_fields(), '&forward=false';?>";
	var a = $('<a style="float:left;margin-left:0.5em">');
	
	
	a.html(add ? label_add : label_remove);
	a.click(function (e) {
		a.removeClass('add_topic_button');
		a.html('<div class="ajax_loader" style="height:32px;width:32px;background-position:0px"><div/>');
		$.post(add ? url_add : url_remove, function(data) {
			add = !add;
			a.html(add ? label_add : label_remove);
			a.addClass('add_topic_button');
			$('#fullcalendar').fullCalendar('refetchEvents');
		});
	});

	$("#addpersonal").append(a.addClass('add_topic_button'));	
</script>


<div id="addpersonal" style="height:16px">

<?php if($event->canEdit()) {?>
<a class='add_topic_button' style="float:left" href="<?php echo $CONFIG->wwwroot."pg/event_calendar/new?event_id=".$event_id?>"><?php echo elgg_echo('event_calendar:manage_event_title')?></a>
<?php }?>
</div>
	
