<?php
$event = $vars['event'];
$event_id = $vars['event_id'];
$event_calendar_region_display = get_plugin_setting('region_display', 'event_calendar');
$event_calendar_type_display = get_plugin_setting('type_display', 'event_calendar');
$dateformat = get_plugin_usersetting("dateformat", $_SESSION['user']->guid, "event_calendar");

if ($dateformat == "mm/dd/yyyy")
	$phpdateformat = "m/d/Y";
elseif ($dateformat == "dd/mm/yyyy")
	$phpdateformat = "d/m/Y";
else
	$phpdateformat = "d/m/Y";

if ($event) {
	$title = $event->title;
	$brief_description = $event->description;
	$venue = $event->venue;
	if ($event->form_data) {
		// this is a form redisplay, so take the values as submitted
		$start_date = $event->start_date;
		$end_date = $event->end_date;
	} else {
		// the values are from the database,
		// so convert
		$start_date = date($phpdateformat, $event->start_date);
		if ($event->end_date) {
			$end_date = date($phpdateformat, $event->end_date);
		} else {
			$end_date = '';
		}
	}
	
	if ($event_calendar_region_display) {
		$region = $event->region;
		if (!$region) {
			$region = '-';
		}
	}
	if ($event_calendar_type_display) {
		$event_type = $event->event_type;
		if (!$event_type) {
			$event_type = '-';
		}
	}
	$fees = $event->fees;
	$contact = $event->contact;
	$organiser = $event->organiser;
	$event_tags = $event->event_tags;
	$long_description = $event->long_description;
	$access = $event->access_id;
	$color = $event->color;
	$start_time = $event->start_time;
	$end_time = $event->end_time;
	$event_action = 'manage_event';
} else {
	$event_id = 0;
	$title = '';
	$brief_description = '';
	$venue = '';
	$start_date = '';
	$end_date = '';
	$fees = '';
	$color = '#555555';
	if ($event_calendar_region_display) {
		$region = '-';
	}
	if ($event_calendar_type_display) {
		$event_type = '-';
	}
	$contact = '';
	$organiser = '';
	$event_tags = '';
	$long_description = '';
	$access = get_default_access();
	$start_time = '';
	$end_time = '';
	$event_action = 'add_event';
}
$body = '';

$body .= elgg_view('input/hidden',array('internalname'=>'event_action', 'value'=>$event_action));
$body .= elgg_view('input/hidden',array('internalname'=>'event_id', 'value'=>$event_id));
$body .= elgg_view('input/hidden',array('internalname'=>'group_guid', 'value'=>$vars['group_guid']));
//$body .= elgg_view("input/hidden",array('internalname' => 'timezoneoffset','value'=>'0'));

$body .= '<p><label>'.elgg_echo("event_calendar:title_label").'<br />';
$body .= elgg_view("input/text",array('internalname' => 'title','value'=>$title));
$body .= '</label></p>';
$body .= '<p class="description">'.elgg_echo('event_calendar:title_description').'</p>';

$body .= '<p><label>'.elgg_echo("event_calendar:venue_label").'<br />';
$body .= elgg_view("input/text",array('internalname' => 'venue','value'=>$venue));
$body .= '</label></p>';
$body .= '<p class="description">'.elgg_echo('event_calendar:venue_description').'</p>';

$body .= '<p><label>'.elgg_echo("event_calendar:start_time_label").'</label><br />';
$body .= elgg_view("input/timepicker",array('internalname' => 'start_time','value'=>$start_time));
$body .= '</p>';
$body .= '<p class="description">'.elgg_echo('event_calendar:start_time_description').'</p>';

$body .= '<p><label>'.elgg_echo("event_calendar:start_date_label").'<br />';
$body .= elgg_view("input/datepicker",array('internalname' => 'start_date','value'=>$start_date));
$body .= '</label></p>';
$body .= '<p class="description">'.elgg_echo('event_calendar:start_date_description').'</p>';

$body .= '<p><label>'.elgg_echo("event_calendar:end_time_label").'</label><br />';
$body .= elgg_view("input/timepicker",array('internalname' => 'end_time','value'=>$end_time));
$body .= '</p>';
$body .= '<p class="description">'.elgg_echo('event_calendar:end_time_description').'</p>';

$body .= '<p><label>'.elgg_echo("event_calendar:end_date_label").'<br />';
$body .= elgg_view("input/datepicker",array('internalname' => 'end_date','value'=>$end_date));
$body .= '</label></p>';
$body .= '<p class="description">'.elgg_echo('event_calendar:end_date_description').'</p>';

$body .= '<p><label>'.elgg_echo("event_calendar:brief_description_label").'<br />';
$body .= elgg_view("input/text",array('internalname' => 'brief_description','value'=>$brief_description));
$body .= '</label></p>';
$body .= '<p class="description">'.elgg_echo('event_calendar:brief_description_description').'</p>';

if ($event_calendar_region_display == 'yes') {
	$region_list = trim(get_plugin_setting('region_list', 'event_calendar'));
	// make sure that we are using Unix line endings
	$region_list = str_replace("\r\n","\n",$region_list);
	$region_list = str_replace("\r","\n",$region_list);
	if ($region_list) {
		$options = array();
		$options[] = '-';
		foreach(explode("\n",$region_list) as $region_item) {
			$region_item = trim($region_item);
			$options[] = $region_item;
		}
		$body .= '<p><label>'.elgg_echo("event_calendar:region_label").'<br />';
		$body .= elgg_view("input/pulldown",array('internalname' => 'region','value'=>$region,'options'=>$options));
		$body .= '</label></p>';
		$body .= '<p class="description">'.elgg_echo('event_calendar:region_description').'</p>';
	}
}

if ($event_calendar_type_display == 'yes') {
	$type_list = trim(get_plugin_setting('type_list', 'event_calendar'));
	// make sure that we are using Unix line endings
	$type_list = str_replace("\r\n","\n",$type_list);
	$type_list = str_replace("\r","\n",$type_list);
	if ($type_list) {
		$options = array();
		$options[] = '-';
		foreach(explode("\n",$type_list) as $type_item) {
			$type_item = trim($type_item);
			$options[] = $type_item;
		}
		$body .= '<p><label>'.elgg_echo("event_calendar:type_label").'<br />';
		$body .= elgg_view("input/pulldown",array('internalname' => 'event_type','value'=>$event_type,'options'=>$options));
		$body .= '</label></p>';
		$body .= '<p class="description">'.elgg_echo('event_calendar:type_description').'</p>';
	}
}

$body .= '<p><label>'.elgg_echo("event_calendar:fees_label").'<br />';
$body .= elgg_view("input/text",array('internalname' => 'fees','value'=>$fees));
$body .= '</label></p>';
$body .= '<p class="description">'.elgg_echo('event_calendar:fees_description').'</p>';

$body .= '<p><label>'.elgg_echo("event_calendar:contact_label").'<br />';
$body .= elgg_view("input/text",array('internalname' => 'contact','value'=>$contact));
$body .= '</label></p>';
$body .= '<p class="description">'.elgg_echo('event_calendar:contact_description').'</p>';

$body .= '<p><label>'.elgg_echo("event_calendar:organiser_label").'<br />';
$body .= elgg_view("input/text",array('internalname' => 'organiser','value'=>$organiser));
$body .= '</label></p>';
$body .= '<p class="description">'.elgg_echo('event_calendar:organiser_description').'</p>';

$body .= '<p><label>'.elgg_echo("event_calendar:event_tags_label").'<br />';
$body .= elgg_view("input/tags",array('internalname' => 'event_tags','value'=>$event_tags));
$body .= '</label></p>';
$body .= '<p class="description">'.elgg_echo('event_calendar:event_tags_description').'</p>';

$body .= '<label>'.elgg_echo("event_calendar:event_color_label");
$body .= elgg_view("input/colorpicker",array('internalname' => 'color','value'=>$color));
$body .= '</label>';
$body .= '<br />';
$body .= '<p class="description">'.elgg_echo('event_calendar:event_color_description').'</p>';

$body .= '<p><label>'.elgg_echo("event_calendar:long_description_label").'<br />';
$body .= elgg_view("input/longtext",array('internalname' => 'long_description','value'=>$long_description));
$body .= '</label></p>';
$body .= '<p class="description">'.elgg_echo('event_calendar:long_description_description').'</p>';

$body .= '<p><label>'.elgg_echo("access").'<br />';
$body .= elgg_view("input/access",array('internalname' => 'access','value'=>$access));
$body .= '</label></p>';

print $body;
?>
