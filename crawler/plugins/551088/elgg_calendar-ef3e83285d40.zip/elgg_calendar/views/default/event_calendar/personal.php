<?php 
	global $CONFIG; 
	$page_owner = page_owner_entity();

	$url = $CONFIG->wwwroot.'/pg/event_calendar/' . 
	$url .= $page_owner ? $page_owner->getGUID() . '/' : '';
?>
<script>
	$(document).ready(function() {
		$('#fullcalendar').fullCalendar('removeEventSource');
		$('#fullcalendar').fullCalendar('addEventSource', '<?php echo $CONFIG->wwwroot?>' + 'pg/event_calendar/personal?format=json_events');
		$('#navcalendar').dpSetEvents('personal');
	});
</script>




