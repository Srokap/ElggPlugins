<link rel="stylesheet" href="<?php echo $vars['url']; ?>mod/event_calendar/js/fullcalendar.css" type="text/css" media="screen">
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/event_calendar/js/jquery-ui-custom.js"></script>
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/event_calendar/js/fullcalendar.js"></script>


<div id="fullcalendar"></div>

<script type='text/javascript'>

var show_event = function(event) {
	$.facebox(function() {
		$.get('<?php echo $vars['url'];?>pg/event_calendar/view/' + event.guid + '/fetch', function(data) {
			$.facebox(data);
		})
	});
};


$('#fullcalendar').fullCalendar({
	header: {
		left: 'prev,next today',
		center: 'title',
		right: 'month,agendaWeek,agendaDay'
	},
	lazyFetching: false,
	//month: 'ddd',    // Mon
	//week: 'ddd d', // Mon 9
	//day: 'dddd d',  // Monday  9
	firstDay: 1,
	height: 600,
	columnFormat: {
		month: 'ddd',
		week: 'ddd d',
		day: 'dddd d'
	},

<?php
	$locale = get_current_language();
	$locale = $locale."_".strtoupper($locale);
	$locale = Array($locale.".UTF-8", $locale, get_current_language());
	setlocale(LC_TIME, $locale);
?>
	monthNames : [<?php for($i = 1; $i <= 12;  $i++) echo "'".strftime("%B", mktime(0, 0, 0, $i)) . "',";?>],
	monthNamesShort: [<?php for($i = 1; $i <= 12;  $i++) echo "'".strftime("%b", mktime(0, 0, 0, $i)) . "',";?>],
	dayNames: [<?php for($i = 6; $i <= 12;  $i++) echo "'".strftime("%A", mktime(0, 0, 0, 0, $i)) . "',";?>],
	dayNamesShort: [<?php for($i = 6; $i <= 12;  $i++) echo "'".strftime("%a", mktime(0, 0, 0, 0, $i)) . "',";?>],

	buttonText :
	{
	    prev:     '&nbsp;&#9668;&nbsp;',  // left triangle
	    next:     '&nbsp;&#9658;&nbsp;',  // right triangle
	    prevYear: '&nbsp;&lt;&lt;&nbsp;', // <<
	    nextYear: '&nbsp;&gt;&gt;&nbsp;', // >>
	    today:    '<?php echo elgg_echo("event_calendar:today_label")?>',
	    month:    '<?php echo elgg_echo("event_calendar:month_label")?>',
	    week:     '<?php echo elgg_echo("event_calendar:week_label")?>',
	    day:      '<?php echo elgg_echo("event_calendar:day_label")?>'
	},

	editable: true,
//	events: events_fetch_url,
//	startParam : 'start',
//	endParam : 'end',
	eventDrop: function(event, dayDelta, minuteDelta) {
		<?php 
		$ts = time();
		$token = generate_action_token($ts);
		?>
		var d = new Date();
		$.post("<?php echo $CONFIG->wwwroot?>action/event_calendar/change",
			{
			__elgg_ts : "<?php echo $ts?>",
			__elgg_token : "<?php echo $token?>",
			start_delta : 60*60*24*dayDelta + 60*minuteDelta, 
			allday : event.allDay,
			guid : event.guid	
			},
			function () {}
		);
	},

	eventRender : function(event) {
//		alert(event.color);
//		alert($(this).css());
//		if (event.color && String(event.color).substring(0,1)=="#")
//			$(this).css('background-color', event.color);
//		else
//			$(this).css('background-color', event.color);

	},
		
	loading: function(bool) {
		if (bool) { 
			$('#loading').show();
		}
		else $('#loading').hide();
	},

	eventClick: function(event,jsEvent,view) {
		$(this).css('background-color', event.color);
		show_event(event);
	},

//	eventMouseover: function(event, jsEvent,view) {
//
//		var color = parseInt('0x' + event.color)
//		var inc = parseInt('0x333333');
//		if (color < parseInt('0xFFFFFF') / 2)
//			color += inc;
//		else	
//			color -= inc;
//		$(this).css('background-color', color));
//			
//		$(this).css('background-color', event.color);
//	},
//
//	eventMouseout: function(event, jsEvent,view) {
//		$(this).css('background-color', event.color);
//	},

	eventResize: function(event,dayDelta,minuteDelta,revertFunc) {
		$.post("<?php echo $CONFIG->wwwroot?>action/event_calendar/change",
			{
			__elgg_ts : "<?php echo $ts?>",
			__elgg_token : "<?php echo $token?>",
			end_delta : 60*60*24*dayDelta + 60*minuteDelta,
			allday : event.allDay,
			guid : event.guid
			},
			function () {}
		);
		
	},

	viewDisplay: function(view) {
		if (view.name == "month") {
			$("#fullcalendar").fullCalendar('option', 'height', 600);
		} else if (view.name == "agendaWeek") {	
			$("#fullcalendar").fullCalendar('option', 'height', 1110);
		} else if (view.name == "agendaDay") {
			$("#fullcalendar").fullCalendar('option', 'height', 1140);
		}
	}


});

</script>

