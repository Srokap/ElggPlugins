<?php $url=$vars['url'] . 'mod/event_calendar/js/' ?>

<script type="text/javascript" src="<?php echo $url?>jquery.datePicker.js"></script>
<script type="text/javascript" src="<?php echo $url?>date.js"></script> 
<script type="text/javascript" src="<?php echo $url?>json2.js"></script> 
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo $url?>datePicker.css"> 

<br />
<div id="navcalendar" ></div>

<script language="javascript">
<?php
                        $locale = get_current_language();
                        $locale = $locale."_".strtoupper($locale);
                        $locale = Array($locale.".UTF-8", $locale, get_current_language());
                        //setlocale(LC_ALL, $locale); 
                        setlocale(LC_TIME, $locale);

?>
			Date.monthNames =  [<?php for($i = 1; $i <= 12;  $i++) echo "'".strftime("%B", mktime(0, 0, 0, $i)) . "',";?>];
			Date.abbrMonthNames =  [<?php for($i = 1; $i <= 12;  $i++) echo "'".strftime("%b", mktime(0, 0, 0, $i)) . "',";?>];
			Date.dayNames = [<?php for($i = 6; $i <= 13;  $i++) echo "'".strftime("%A", mktime(0, 0, 0, 0, $i)) . "',";?>];
			Date.abbrDayNames =[<?php for($i = 6; $i <= 13;  $i++) echo "'".strftime("%a", mktime(0, 0, 0, 0, $i)) . "',";?>];
	$.dpText = {
		TEXT_PREV_YEAR		:	'<?php echo elgg_echo("event_calendar:previousyear_label")?>',
		TEXT_PREV_MONTH		:	'<?php echo elgg_echo("event_calendar:previousmonth_label")?>',
		TEXT_NEXT_YEAR		:	'<?php echo elgg_echo("event_calendar:nextyear_label")?>',
		TEXT_NEXT_MONTH		:	'<?php echo elgg_echo("event_calendar:nextmonth_label")?>',
		TEXT_CLOSE		:	'Close',
		TEXT_CHOOSE_DATE	:	'Choose date',
		HEADER_FORMAT		:	'mmmm yyyy'
	};
var datepicker=$("#navcalendar");
var navlastfetchid = 0;
$.fn.extend({
	dpSetEvents: function(baseurl)  { 
	
		if (baseurl) {
			datepicker.dpSetFilter(baseurl);
		}

		var displayedYear = datepicker.dpGetYear();
		var displayedMonth = datepicker.dpGetMonth();

		var currentDate = (new Date(displayedYear, displayedMonth, 1, 12, 0, 0));
		var firstDayOffset = Date.firstDayOfWeek - currentDate.getDay() + 1;
		if (firstDayOffset > 1) firstDayOffset -= 7;
		var weeks = Math.ceil(( (-1*firstDayOffset+1) + currentDate.getDaysInMonth() ) /7);
		currentDate.addDays(firstDayOffset-1);
		
		var start = new Date(currentDate);
		
//		var end = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDays() + weeks * 7);
//		var start = new Date(displayedYear, displayedMonth);
		var end = new Date(displayedYear, displayedMonth+1, 0);

		var fetchurl = datepicker.dpGetFilter() + "?format=json_dates" + 
				'&start=' + start.getTime() / 1000 + '&end=' + end.getTime() / 1000;
		var fetchdata = function(fetchurl, id) {
			$.get(fetchurl, function (data) {
				if (!data || id != navlastfetchid) return;
				var daysJSON = JSON.parse(data);
					
				for (var i=0;i<daysJSON.length;i++) {
					datepicker.dpSetEvent(new Date(daysJSON[i].replace(/\./g,"/")));
				}
			});
		};

		fetchdata(fetchurl, ++navlastfetchid);

	}
});

datepicker
	.datePicker({inline:true,
			startDate:'01/01/1970',
			filter:'all'
	})
	.bind(	'monthClick',
		function(e, displayedMonth, displayedYear) {
			$("#fullcalendar").fullCalendar('gotoDate',displayedYear, displayedMonth);
			$("#fullcalendar").fullCalendar('changeView', 'month');
		}
	)
	.bind( 'viewChanged',
		function(e, view) {
			$("#fullcalendar").fullCalendar('changeView', view);
		}
	)
	.bind( 'dpMonthChanged',
		function(e, displayedMonth, displayedYear)
		{
			datepicker.dpSetEvents();		
		}
	)
	.bind( 'dateSelected',
		function(e, selectedDate, $td)
		{
//			var cdate = $("#fullcalendar").fullCalendar("getDate");
			var day = selectedDate.getDate();
			var month = selectedDate.getMonth();
			var year = selectedDate.getFullYear();
//			if (cdate.getMonth() != month) {
//				var view = $("#fullcalendar").fullCalendar("getView");
//				$("#fullcalendar").fullCalendar("changeView", "month");
//				$("#fullcalendar").fullCalendar('refetchEvents');
//				$("#fullcalendar").fullCalendar("changeView", view.name);
//			}
			$("#fullcalendar").fullCalendar('gotoDate',year,month,day);
//			$("#fullcalendar").fullCalendar('refetchEvents');
		}
//	($setEvents(datepicker.dpGetMonth(), datepicker.dpGetYear());
	);

</script>
