<p>
<?php echo elgg_echo('event_calendar:config_recommend'); var_dump($vars['entity'])?>
</p>

<p><?php echo elgg_echo("event_calendar:dateformat")?>
<select name="params[dateformat]">
<option value="dd/mm/yyyy" <?php if ($vars['entity']->dateformat=="dd/mm/yyyy") echo 'selected="yes"'?>>dd/mm/yyyy</option>
<option value="mm/dd/yyyy" <?php if ($vars['entity']->dateformat=="mm/dd/yyyy") echo 'selected="yes"'?>>mm/dd/yyyy</option>
</select> 
<p>

