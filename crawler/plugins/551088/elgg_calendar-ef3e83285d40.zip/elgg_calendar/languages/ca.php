<?php

// Generate By translationbrowser. 

$catalan = array( 
	 'item:object:event_calendar'  =>  "Calendari d'esdeveniments" , 
	 'event_calendar:personal_calendar'  =>  "Esdeveniments personals" , 
	 'event_calendar:new_event'  =>  "Nou" , 
	 'event_calendar:no_such_event_edit_error'  =>  "Error: No existeix aquest esdeveniment o bé no tens permisos per modificar-lo." , 
	 'event_calendar:add_event_title'  =>  "Afegeix" , 
	 'event_calendar:manage_event_title'  =>  "Edita" , 
	 'event_calendar:manage_event_description'  =>  "Especifica a continuació una mica d'informació. El títol, el lloc, la data d'inici i de finalització en són necessaris. Pots prémer als botons de calendari per definir ambdues dates." , 
	 'event_calendar:title_label'  =>  "Títol"
); 

add_translation('ca', $catalan); 

?>