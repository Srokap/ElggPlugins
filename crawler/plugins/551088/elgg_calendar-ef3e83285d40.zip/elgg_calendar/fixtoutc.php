<?php
/* 
Fix the entities date from the original Kevin's event calendar to UTC.
IMPORTANT: The $seconds_offset variable must be set to the difference between the system date and the UTC date in seconds.
Example:
 
$ date
mar jul 13 17:30:43 CEST 2010
$ date -u
mar jul 13 15:30:47 UTC 2010

Then, $seconds_offset=2*3600;
*/

// Load Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

// Load event model
require_once(dirname(__FILE__) . "/models/model.php");
    
// Define context
set_context('event_calendar');

global $CONFIG;

$seconds_offset = 3600*2;
$group_guid = 0; 
$offset = 0;
$limit = 99999;
$region = '-';
$start_ts = 0; 
$end_ts = 999999999999; 

//	$count = event_calendar_get_events_between($start_ts,$end_ts,true,$limit,$offset,$group_guid,$region);
	$events = event_calendar_get_events_between($start_ts,$end_ts,false,$limit,$offset,$group_guid,$region);
foreach($events as $event) {
	var_dump($event->title);	
	var_dump($event->start_date);
	var_dump($event->end_date);
	if ($event->start_date) $event->start_date = (int) $event->start_date - $seconds_offset;
	if ($event->end_date) $event->end_date = (int) $event->end_date - $seconds_offset;
	print_r('after change\n');
	var_dump($event->start_date);
	var_dump($event->end_date);
}
?>
