<?php

/**
 * Show event
 *
 * @package event_calendar
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2008
 * @link http://radagast.biz/
 *
 */
 
// Load Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

// Load event calendar model
require_once(dirname(__FILE__) . "/models/model.php");
    
// Define context
set_context('event_calendar');

global $CONFIG;

$event_id = get_input('event_id');
$fetch = get_input('fetch');

if ($event_id && ($event = get_entity($event_id))) {
	if ($fetch) {
		$owner = get_entity($event->container_guid);
		$icon = elgg_view("profile/icon",array('entity' => $owner, 'size' => 'tiny'));
		if ($owner instanceof ElggUser || $owner instanceof ElggGroup) {
			$info = '<a href="' . $owner->getURL() . '">' . $owner->name . '</a>';
		}
		$display = "<div id=\"owner_block_icon\">" . $icon . "</div>";
		$display .= "<div id=\"owner_block_content\">" . $info . "</div><div class=\"clearfloat ownerblockline\"></div>";
		
		if ($owner->briefdescription) {
			$desc = $owner->briefdescription;
			$display .= "<div id=\"owner_block_desc\">" . $desc . "</div>";
		}

		echo $display;
		echo elgg_view('object/event_calendar',array('entity'=>$event,'full'=>true));

		if (isloggedin()) {
			echo elgg_view('event_calendar/addpersonal', array('event_id'=>$event_id));
		}
	} else {
		$event_container = get_entity($event->container_guid);
		if ($event_container instanceOf ElggGroup) {
			// Re-define context
			set_context('groups');
			set_page_owner($event_container->getGUID());
		}
		$count = event_calendar_get_users_for_event($event_id,0,0,true);
		if ($count > 0) {
			add_submenu_item(sprintf(elgg_echo('event_calendar:personal_event_calendars_link'),$count), $CONFIG->url . "mod/event_calendar/display_event_users.php?event_id=".$event_id, '0eventnonadmin');
		}
		$body = elgg_view('object/event_calendar',array('entity'=>$event,'full'=>true));
	
	
		$title = $event->title;
		page_draw($title,elgg_view_layout("two_column_left_sidebar", '', elgg_view_title($title) . $body));
	}
} else {

	register_error('event_calendar:error_nosuchevent');
	forward();

}

