<?php

/**
 * Show events
 *
 * @package event_calendar
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2008
 * @link http://radagast.biz/
 *
 */
 
// Load Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

// Load event model
require_once(dirname(__FILE__) . "/models/model.php");
    
// Define context
set_context('event_calendar');

global $CONFIG;

$group_guid = (int) get_input('group_guid',0);
if ($group_guid && $group = get_entity($group_guid)) {
	// redefine context
	set_context('groups');
	set_page_owner($group_guid);
	$group_calendar = get_plugin_setting('group_calendar', 'event_calendar');
	if (!$group_calendar || $group_calendar == 'members') {
		if (page_owner_entity()->canWriteToContainer($_SESSION['user'])){
			add_submenu_item(elgg_echo('event_calendar:new'), $CONFIG->url . "pg/event_calendar/new/?group_guid=" . page_owner(), '1eventcalendaradmin');
		}
	} else if ($group_calendar == 'admin') {
		if (isadminloggedin() || ($group->owner_guid == get_loggedin_userid())) {				
			add_submenu_item(elgg_echo('event_calendar:new'), $CONFIG->url . "pg/event_calendar/new/?group_guid=" . page_owner(), '1eventcalendaradmin');
		}
	}
}

$offset = (int) get_input('offset',0);
$limit = 99999;
$filter = get_input('filter','all');
$region = get_input('region','-');
$format = get_input('format');
$start_ts = get_input('start', 0);
$end_ts = get_input('end', 0);
if ($filter == "personal") {
	$user_guid = get_loggedin_userid();
	$events = event_calendar_get_personal_events_for_user_between($start_ts, $end_ts, $user_guid,$limit);
} else if ($filter == 'all') {
//	$count = event_calendar_get_events_between($start_ts,$end_ts,true,$limit,$offset,$group_guid,$region);
	$events = event_calendar_get_events_between($start_ts,$end_ts,false,$limit,$offset,$group_guid,$region);
} else if ($filter == 'friends') {
	$user_guid = get_loggedin_userid();
//	$count = event_calendar_get_events_for_friends_between($start_ts,$end_ts,true,$limit,$offset,$user_guid,$group_guid,$region);
	$events = event_calendar_get_events_for_friends_between($start_ts,$end_ts,false,$limit,$offset,$user_guid,$group_guid,$region);	
} else if ($filter == 'mine') {
	$user_guid = get_loggedin_userid();
//	$count = event_calendar_get_events_for_user_between($start_ts,$end_ts,true,$limit,$offset,$user_guid,$group_guid,$region);
	$events = event_calendar_get_events_for_user_between($start_ts,$end_ts,false,$limit,$offset,$user_guid,$group_guid,$region);	
}
/*
		foreach($events as $event) {
		echo 'time' . $event->start_time . '-' . $event->end_time . '<br />';
		echo $event->start_date . '-' . $event->end_date . '<br />';
}*/
// ------- JSON EXPORT --------------------------
// ---------- End JSON EXPORT --------------------
//
//$vars = array(	'original_start_date' => $original_start_date,
//			'start_date'	=> $start_date,
//			'end_date'		=> $end_date,
//			'first_date'	=> $event_calendar_first_date,
//			'last_date'		=> $event_calendar_last_date,
//			'mode'			=> $mode,
//			'events'		=> $events,
//			'count'			=> $count,
//			'offset'		=> $offset,
//			//'limit'			=> $limit,
//			'group_guid'	=> $group_guid,
//			'filter'		=> $filter,
//			'region'		=> $region,
//);
//
if ($format == 'json_events') {
	if ($events) {
		echo "[";
		foreach($events as $event) {
			$start_date = $event->start_date;// + $event->start_time * 60;
			$end_date = $event->end_date;//->end_date; // + $event->end_time * 60;
			$export = new stdClass;
			$exportable_values = $event->getExportableValues();
                                
                        foreach ($exportable_values as $v) {
                                //FIXME debugging owner class^M
                                $export->$v = $event->$v;
			}

			$export->allDay = ($event->start_time && $event->end_time) ? false : true; 

			if ($event->color)
				$export->color = $event->color;
			else
				$export->color = "#555555";
			$export->start = $start_date;// + 2 * 3600;
			if ($end_date) {
				$export->end  = $end_date; // + 24 * 3600;
			} else {
				$export->end = $export->start;
			}
			$export->editable = $event->canEdit();
			echo json_encode($export);
			echo ",";
		}
		echo "]";
	} else {
		echo('no events');
	}

} elseif($format == 'json_dates') {
	$event_dates = array();
	$start = $start_ts;
	$end = $end_ts;
	$events = event_calendar_vsort($events, "start_date" ,false);
	if ($events) {
		foreach($events as $event) {
			$start_date = $event->start_date;
			$end_date = $event->end_date;
			while ($end_date >= $start && $start_date <= $end && $start <= $end) {
				if ($start_date >= $start) {
					$tmp = getdate($start_date);
					$start = mktime(0, 0, 0, $tmp['mon'],$tmp['mday'], $tmp['year']);
				}
				$event_dates[] = date("m.d.Y", $start);
				$start += 24*3600;
			}
		}
		echo json_encode($event_dates);
	} else {
	//	echo('no events');
	}

} else {
	if ($filter=="personal") 
		$body = elgg_view('event_calendar/personal');
	else
		$body = elgg_view('event_calendar/nav');

	$body .= elgg_view('event_calendar/fullcalendar');
	$left_sidebar = elgg_view('event_calendar/navcalendar');
		
	$title = elgg_echo('event_calendar:show_events_title');
	$body = elgg_view('page_elements/contentwrapper',array('body' =>$body, 'subclass' => 'events'));
		
	page_draw($title,elgg_view_layout("two_column_left_sidebar", $left_sidebar, elgg_view_title($title).$body));
}

?>
