<?php
/* Code source basé sur http://www.vulgarisation-informatique.com/mail.php */

$localadmin = get_plugin_setting('localadmin', 'mailing');
// Facyla : this tool is rather for global admins and webmasters than local admins, but let's allow them to send mailing to their own network (only)
//if ($localadmin == "true") {
  if (is_plugin_enabled('multisite')) { multisite_admin_gatekeeper(); set_context('localmultisite'); } else { admin_gatekeeper(); set_context('admin'); }
//} else { admin_gatekeeper(); set_context('admin'); }

global $CONFIG;
$t1 = microtime(true);

$subject = get_input('emailsubject', null);
$message = get_input('emailmessage', null);
$recipient = get_input('emailto', null);
$sender = get_input('emailsender', null);
$replyto = get_input('emailreply', null);
$send = true;

// Conserve la conf du mail si envoi impossible
$_SESSION['mailing']['subject'] = $subject;
$_SESSION['mailing']['message'] = $message;
$_SESSION['mailing']['recipient'] = $recipient;
$_SESSION['mailing']['sender'] = $sender;
$_SESSION['mailing']['replyto'] = $replyto;


//-----------------------------------------------
//DECLARE LES VARIABLES INITIALES
//-----------------------------------------------
if(empty($subject)) {
  $send = false;
  system_message(elgg_echo('mailing:send:error:subject') . ' : SUBJECT');
}
if(empty($recipient)) {
  $send = false;
  system_message(elgg_echo('mailing:send:error:recipient') . ' : RECIPIENT');
} else {
  // cible : mails séparés par des virgules, points-virgules ou retours à la ligne, sans espace ou autre
	$recipient = str_replace('\n', ',', $recipient); // pour prendre une liste séparées par un retour à la ligne
	$recipient = str_replace(' ', ',', $recipient); // pour prendre une liste séparées par un espace
	$recipient = str_replace('\r', ',', $recipient); // pour prendre une liste séparées par un retour à la ligne
	$recipient = str_replace(';', ',', $recipient); // points-virgules aussi : full-csv compliant !
	if (strpos($recipient, ',') !== false) $recipients = explode(',', $recipient);
	else $recipients[] = trim($recipient);
  $recipients = array_unique($recipients); // Retire les doublons et ne laisse qu'une seule valeur vide
}
if(empty($message)) {
  $send = false;
  system_message(elgg_echo('mailing:send:error:message') . ' : MESSAGE');
}
if(empty($sender)) {
  $send = false;
  system_message(elgg_echo('mailing:send:error:sender') . ' : SENDER');
}

if (is_email_address($sender) && is_email_address($replyto)) {} else {
  $send = false;
  system_message(elgg_echo('mailing:send:error:recipient') . ' : SENDER/REPLYTO EMAIL ADDRESSES');
}

//-----------------------------------------------
//HEADERS DU MAIL
//-----------------------------------------------
$headers = "From: $sender\r\n";
$headers .= "Reply-To: $replyto\r\n";
// $headers .= "CC:: \r\n";
// $headers .= "X-Priority:: \r\n"; // De 1(max) à 5(min)
//$headers .= "BCC: $recipient \r\n"; // Accepte une liste de destinataires importante mais ne pas abuser : mieux vaut découper en lots, même en BCC
$headers .= "Return-Path: <$sender>\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=\"iso-8859-1\"\r\n";
$headers .= "Content-Transfer-Encoding: 8bit\r\n";

//-----------------------------------------------
//MESSAGE HTML
//-----------------------------------------------
$message .= "\r\n";
//$recipient = $email_reply;  // Masquage des destinataires (utile ssi en copie cachée BCC)
//$recipient = $_SESSION['user']->email;  // Masquage des destinataires (utile ssi en copie cachée BCC)

// Si tout semble OK pour envoi.. (ssi rien ne manque)
if ($send) {

  // Make headers readable + create headers for report
  $mailingheaders = str_replace("\r\n", "<br />", $headers);
  $reportheaders = "From: " . $sender . "\r\nReply-To: $replyto\r\nReturn-Path: <$sender>\r\nMIME-Version: 1.0\r\nContent-Type: text/html; charset=\"iso-8859-1\"\r\nContent-Transfer-Encoding: 8bit\r\n";
  
  $t2 = microtime(true);
  // Note : avec l'envoi via une boucle, plus besoin de BCC
    set_time_limit(5); // Définit, mais surtout réinitialise la durée maximale d'éxécution du script (secondes)
  foreach ($recipients as $dest) {
    if (!empty($dest)) {
      if ( mail($dest, $subject, $message, $headers) ) {
        $reportok[] = "$dest, ";
      } else {
        $reporterr[] = "$dest, ";
        $err = true;
      }
    }
  }
  if ($err) $status = elgg_echo('mailing:send:error'); else $status = elgg_echo('mailing:send:success');
  
  $delta = '<br />Temps de calcul de la page : ' . (microtime(true) - $t1) . " secondes (" . (microtime(true) - $t2) . ")";
  
  // Messages et rapports
  system_message("$status<br /><br />$delta<br /><br />Rapport d'envoi :<br />OK : " . count($reportok) . "<br />Erreurs : " . count($reporterr));
  if (is_array($reportok)) $reportok = count($reportok) . " envois = " . implode(',', $reportok);
  else $reportok = count($reportok) . " envois = $reportok";
  if (is_array($reporterr)) $reporterr = count($reporterr) . " envois = " . implode(',', $reporterr);
  $reporterr = count($reporterr) . " envois = $reporterr";
  $reportmessage = "Sujet : $subject<br />Headers : $mailingheaders<br /><br />Rapport d'envoi :<br />Envoyé par " . $_SESSION['user']->name . "<br />Erreurs : $reporterr<br /><br />Envois réussis : $reportok<br /><br />$delta<br /><br />Message : $message";

  // Send report to sender (site + user) //  mail("mail@domain.tld", elgg_echo('mailing:report') . " : $status", $reportmessage, $reportheaders);
//  if (mail($CONFIG->site->email, elgg_echo('mailing:report') . " : $status", $reportmessage, $reportheaders)) system_message("Rapport envoyé à ". $CONFIG->site->email); else system_message("Echec de l'envoi du rapport au site");
  if (mail($_SESSION['user']->email, elgg_echo('mailing:report') . " : $status", $reportmessage, $reportheaders)) system_message("Rapport envoyé à ". $_SESSION['user']->email); else system_message("Echec de l'envoi du rapport à l'expéditeur");
  //phpmailer_send($from, $from_name, $to, $to_name, $subject, $body, array $bcc = NULL, $html = false, array $files = NULL, array $params = NULL);
//  if ( phpmailer_send($CONFIG->site->email, $CONFIG->site->name, $_SESSION['user']->email, $_SESSION['user']->name, elgg_echo('mailing:report') . " : $status", $reportmessage, NULL, true, NULL, $params = NULL) ) system_message("Rapport envoyé à ". $_SESSION['user']->email); else system_message("Echec de l'envoi du rapport à l'expéditeur");
  
  unset($_SESSION['mailing']['recipient']); // Vide les destinataires du mail (évite un double envoi)
//  unset($_SESSION['mailing']); // Vide la conf du mail
}

forward($_SERVER['HTTP_REFERER']);
