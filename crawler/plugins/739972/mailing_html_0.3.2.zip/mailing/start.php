<?php
/**
 * Elgg mailing plugin
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Facyla
 * @copyright (cc) Facyla 2010
 * @link http://id.facyla.net/
 * Description : sends mails to any valid mail address. HTML message content, reply-to etc.
 */

function mailing_init() {
  global $CONFIG;
  register_action("mailing/send",false,$CONFIG->pluginspath . "mailing/actions/send.php");
  
  if (get_context() == 'admin' && isadminloggedin()) {
    add_submenu_item(elgg_echo('mailing:menu:title'), $CONFIG->wwwroot . 'mod/mailing/mailing.php');
  }
}

register_elgg_event_handler('init','system','mailing_init');
