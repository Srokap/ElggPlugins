<?php

	echo elgg_view('file/icon/video',$vars);

?>