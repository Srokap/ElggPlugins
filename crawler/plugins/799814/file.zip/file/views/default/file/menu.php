<?php

	/**
	 * Elgg hoverover extender for file
	 * 
	 * @package ElggFile
	 */

?>

	<p class="user_menu_file">
		<a href="<?php echo $vars['url']; ?>pg/file/owner/<?php echo $vars['entity']->username; ?>"><?php echo elgg_echo("file"); ?></a>
	</p>