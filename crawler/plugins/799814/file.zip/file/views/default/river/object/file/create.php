<?php

	$performed_by = get_entity($vars['item']->subject_guid);
	$object = get_entity($vars['item']->object_guid);
	$url = $object->getURL();
	$mime = $object->mimetype;
	$container = get_entity($object->container_guid);
	$url = "<a href=\"{$performed_by->getURL()}\">{$performed_by->name}</a>";
	$string = sprintf(elgg_echo("file:river:created"),$url) . " " . elgg_echo("file:river:item");
	$string .= " <a href=\"" . $object->getURL() . "\">" . $object->title . "</a>";
	if ($container && $container instanceof ElggGroup) {
		$string .= ' ' . elgg_echo('groups:river:togroup') . " <a href=\"" . $container->getURL() ."\">". $container->name . "</a>";
	}

	echo $string;
?>

<?php
echo "<div>";
echo elgg_view("file/icon", array("mimetype" => $object->mimetype, 'thumbnail' => $object->thumbnail, 'size' => 'small', 'file_guid' => $object->guid));
echo "<div>" .$object->description. "</div>";
echo "</div>";
?>
<?php
	if ($object->simpletype == "audio") {
		?>
<script>
$(document).ready(function(){
$("#ocultar").click(function(){$("#showmp3_<?php echo $object->guid ?>").hide("slow")});
$("#rep_<?php echo $object->guid ?>").click(function(){$("#showmp3_<?php echo $object->guid ?>").show("slow")});
});
</script>
<a id="rep_<?php echo $object->guid ?>">Reproducir</a>
<div id="showmp3_<?php echo $object->guid ?>" style="display:none;">
<?php
$playlist = $playlist . $vars['url'] . 'action/file/download?file_guid=' . $object->guid;
$titles = $titles . $object->title;
?>
<!--width="200" height="100" -->

<object type="application/x-shockwave-flash" data="<?php echo $vars['url']; ?>mod/file/audioplayer/player_mp3_maxi.swf" width="200" height="20" wmode="transparent">
<param name="movie" value="<?php echo $vars['url']; ?>mod/file/audioplayer/player_mp3_maxi.swf" />
<PARAM NAME="WMODE" VALUE="transparent">
<param name="FlashVars" value="mp3=<?php echo $playlist; ?>&amp;title=<?php echo $titles; ?>&amp;showstop=1&amp;showinfo=1&amp;showvolume=1" /></center>
</object>

</div>
<?php
		}
?>