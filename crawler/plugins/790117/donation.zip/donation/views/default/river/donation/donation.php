<?php

echo elgg_view('river/item', array(
	'item' => $vars['item'],
));

