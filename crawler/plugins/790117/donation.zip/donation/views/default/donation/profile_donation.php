<?php
/**
 * Elgg Donation plugin
 * @license: GPL v 2.
 * @author Tiger
 * @copyright TechIsUs
 * @link www.techisus.dk
 */

// Get plugin settings
$profile_donation = elgg_get_plugin_setting("profile_donation","donation");



if($profile_donation == 'yes' && $vars['entity']->donation > time()) {
	$date = date("j/n-Y", $vars['entity']->donation);
	$linktext = sprintf(elgg_echo('donation:donator'), elgg_get_config('sitename'));
	// Link to all donators
	$link = "<a href=\"" . elgg_get_site_url() . "donation\" title=\"" . elgg_echo('donation:show:everyone') . "\">{$linktext}</a>";

	if (elgg_get_context() == 'profile') {
		echo "<div class=\"profile_donation\">";
		echo $link;
		echo "</div>";
	}
}

