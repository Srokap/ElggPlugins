<?php
/**
 * Elgg Donation plugin
 * @license: GPL v 2.
 * @author Tiger
 * @copyright TechIsUs
 * @link www.techisus.dk
 */

register_elgg_event_handler('init','system','donation_init');

function donation_init() {

	elgg_extend_view('css','donation/css');

	// Show donation status on profile
	if (get_plugin_setting('profile_donation', 'donation') == 'yes') {
		elgg_extend_view('profile/status', 'donation/profile_donation');
	}
		
	if (isadminloggedin()) {
		elgg_extend_view('profile/menu/adminlinks','donation/menu');
	}

	// Register a page handler, so we can have nice URLs
	register_page_handler('donation','donation_page_handler');

	if(elgg_is_admin_logged_in()) {

		// user hover menu
		elgg_register_plugin_hook_handler('register', 'menu:user_hover', 'donation_user_hover_menu');

		// register actions
		elgg_register_action("donation/add", elgg_get_plugins_path() . "donation/actions/add.php");

	}

}

function donation_page_handler($page) {
			
	gatekeeper();

	$title = sprintf(elgg_echo('donation:title:everyone'), elgg_get_config('sitename'));

	$body = elgg_view('donation/everyone');

	$sidebar = elgg_view("donation/donation");

	$params = array(
		'content' => $body,
		'title' => $title,
		'sidebar' => $sidebar,
	);
	$body = elgg_view_layout('one_sidebar', $params);

	echo elgg_view_page($title, $body);
			
}

// Donations are announced to the river
function donation_add_to_river($user, $type) {
	if (get_plugin_setting('useriver', 'donation') == 'yes') {
		add_to_river('river/donation/donation',$type, $user->guid, $user->guid);
	}
}

// Add to the user hover menu
function donation_user_hover_menu($hook, $type, $return, $params) {
	$user = $params['entity'];

	$url = "action/donation/add?guid={$user->guid}";
	$url = elgg_add_action_tokens_to_url($url);
	$item = new ElggMenuItem('donation', elgg_echo('donation:add'), $url);
	$item->setSection('admin');
	$return[] = $item;

	return $return;
}
