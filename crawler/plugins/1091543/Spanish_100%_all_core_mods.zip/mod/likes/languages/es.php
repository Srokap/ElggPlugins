<?php
/**
 * Likes Spanish language file
 */

$spanish = array(
	'likes:this' => 'le gusta esto',
	'likes:deleted' => 'Tu Like ha sido removido',
	'likes:see' => 'Ver quienes les gusta esto',
	'likes:remove' => 'Ya no me gusta',
	'likes:notdeleted' => 'Hubo un problema al quitar el Like',
	'likes:likes' => 'Ahora puedes marcar que te gusta este elemento',
	'likes:failure' => 'Hubo un problema al marcar que te gusta este elemento',
	'likes:alreadyliked' => 'Ya has marcado que te gusta este elemento',
	'likes:notfound' => 'El elemento que tratas de marcar no est&aacute; disponnible',
	'likes:likethis' => 'Me gusta esto',
	'likes:userlikedthis' => '%s like',
	'likes:userslikedthis' => '%s likes',
	'likes:river:annotate' => 'likes',
	'likes:delete:confirm' => '&iquest;Seguro que ya no te gusta esto?',

	'river:likes' => 'likes %s %s',

	// notifications. yikes.
	'likes:notifications:subject' => '%s Me gusta en tu post "%s"',
	'likes:notifications:body' =>
'Hola %1$s,

%2$s le(s) gusta tu post "%3$s" en %4$s

ver el post original aqu&iacute;:

%5$s

o ver el perfil de %2$s\ aqu&iacute;:

%6$s

Gracias,
%4$s
',
	
);

add_translation('es', $spanish);