<?php
/**
 * Elgg groups plugin language pack
 *
 * @package ElggGroups
 */

$spanish = array(

	/**
	 * Menu items and titles
	 */
	'groups' => "Grupos",
	'groups:owned' => "Grupos que administro",
	'groups:owned:user' => 'Grupos que administra %s',
	'groups:yours' => "Mis grupos",
	'groups:user' => "Grupos de %s",
	'groups:all' => "Todos los grupos",
	'groups:add' => "Crear un nuevo grupo",
	'groups:edit' => "Editar grupo",
	'groups:delete' => 'Borrar grupo',
	'groups:membershiprequests' => 'Manejar solicitudes de uni&oacute;n a grupos',
	'groups:invitations' => 'Invitaciones de grupo',

	'groups:icon' => '&iacute;cono de grupo (dejar en blanco para no hacer cambios)',
	'groups:name' => 'Nombre del Grupo',
	'groups:username' => 'Nombre corto del Grupo (mostrado en la URL, s&oacute;lo caracteres alfanum&eacute;ricos)',
	'groups:description' => 'Descripci&oacute;n completa',
	'groups:briefdescription' => 'Breve descripci&oacute;n',
	'groups:interests' => 'Etiquetas',
	'groups:website' => 'Sitio Web',
	'groups:members' => 'Miembros del grupo',
	'groups:members:title' => 'Miembros de %s',
	'groups:members:more' => "Ver todos los miembros",
	'groups:membership' => "Ver los permisos de los miembros",
	'groups:access' => "Permisos de acceso",
	'groups:owner' => "Propietario",
	'groups:widget:num_display' => 'N&uacute;mero de miembros a mostrar',
	'groups:widget:membership' => 'Miembros del grupo',
	'groups:widgets:description' => 'Muestra los grupos en dond eeres miembro',
	'groups:noaccess' => 'No hay acceso al grupo',
	'groups:permissions:error' => 'No tienes permisos para esto',
	'groups:ingroup' => 'en el grupo',
	'groups:cantedit' => 'No puedes editar este grupo',
	'groups:saved' => 'Grupo guardado',
	'groups:featured' => 'Grupos destacados',
	'groups:makeunfeatured' => 'No destacar',
	'groups:makefeatured' => 'Destacar',
	'groups:featuredon' => '%s es miembro de un grupo destacado.',
	'groups:unfeatured' => '%s has been removed from the featured groups.',
	'groups:featured_error' => 'Grupo inv&aacute;lido.',
	'groups:joinrequest' => 'Solicitar unirse',
	'groups:join' => 'Unirse al grupo',
	'groups:leave' => 'Abandonar el grupo',
	'groups:invite' => 'Invitar amigos',
	'groups:invite:title' => 'Invitar amigos a este grupo',
	'groups:inviteto' => "Invitar amigos a '%s'",
	'groups:nofriends' => "No hay amigos que no hayan sido invitados al grupo.",
	'groups:nofriendsatall' => 'No hay amigos para invitar',
	'groups:viagroups' => "via grupos",
	'groups:group' => "Grupo",
	'groups:search:tags' => "etiqueta",
	'groups:search:title' => "Search for groups tagged with '%s'",
	'groups:search:none' => "No matching groups were found",
	'groups:search_in_group' => "Search in this group",
	'groups:acl' => "Group: %s",

	'discussion:notification:topic:subject' => 'Nuevo tema de discusi&oacute;n para el grupo',
	'groups:notification' =>
'%s ha agregado un nuevo tema a %s:

%s
%s

Ver y responder:
%s
',

	'discussion:notification:reply:body' =>
'%s ha respondido al tema %s en el grupo %s:

%s

Ver y comentar:
%s
',

	'groups:activity' => "Actividad del grupo",
	'groups:enableactivity' => 'Habilitar las actividades del grupo',
	'groups:activity:none' => "El grupo no ha tenido actividades a&uacute;n",

	'groups:notfound' => "No se encontr&oacute; el grupo",
	'groups:notfound:details' => "El grupo solicitado no existe o no tienes permiso para verlo",

	'groups:requests:none' => 'No hay solicitudes de membres&iacute;a.',

	'groups:invitations:none' => 'Actualmente no hay invitaciones.',

	'item:object:groupforumtopic' => "Temas de discusi&oacute;n",

	'groupforumtopic:new' => "A&ntilde;adir un tema de discusi&oacute;n",

	'groups:count' => "Grupos creados",
	'groups:open' => "grupo abierto",
	'groups:closed' => "grupo cerrado",
	'groups:member' => "miembros",
	'groups:searchtag' => "Buscar grupos por etiqueta",

	'groups:more' => 'M&aacute;s grupos',
	'groups:none' => 'No hay grupos',


	/*
	 * Access
	 */
	'groups:access:private' => 'Cerrado &mdash; los miembros deben ser invitados',
	'groups:access:public' => 'Abierto &mdash; cualquiera puede unirse',
	'groups:access:group' => 'S&oacute;lo miembros del grupo',
	'groups:closedgroup' => 'Este grupo ha cerrado nuevas membres&iacute;as.',
	'groups:closedgroup:request' => 'Para solicitar unirse, haz click en "solicitar unirse" en el menu de enlaces.',
	'groups:visibility' => '&iquest;Quienes pueden ver este grupo?',

	/*
	Group tools
	*/
	'groups:enableforum' => 'Habilitar discusi&oacute;n de los grupos',
	'groups:yes' => 's&iacute;',
	'groups:lastupdated' => '&Uacute;ltimas actualizaciones de %s por %s',
	'groups:lastcomment' => '&Uacute;ltimos de %s por %s',

	/*
	Group discussion
	*/
	'discussion' => 'Discusi&oacute;n',
	'discussion:add' => 'Agregar tema de discusi&oacute;n',
	'discussion:latest' => '&uacute;ltimas discusiones',
	'discussion:group' => 'Discusiones de grupo',
	'discussion:none' => 'No hay discusiones',
	'discussion:reply:title' => 'Respuesta de %s',

	'discussion:topic:created' => 'El tema de discusi&oacute;n ha sido creado.',
	'discussion:topic:updated' => 'El tema de discusi&oacute;n ha sido actualizado.',
	'discussion:topic:deleted' => 'El tema de discusi&oacute;n ha sido borrado.',

	'discussion:topic:notfound' => 'No se ha encontrado el tema de discusi&oacute;n. solicitado',
	'discussion:error:notsaved' => 'No se puede guardar el tema de discusi&oacute;n',
	'discussion:error:missing' => 'El t&iacute;tulo y el cuerpo del mensaje son obligatorios',
	'discussion:error:permissions' => 'No tienes permiso para hacer eso',
	'discussion:error:notdeleted' => 'No se pudo borrar el tema de discusi&oacute;n',

	'discussion:reply:deleted' => 'La respuesta ha sido borrada.',
	'discussion:reply:error:notdeleted' => 'No se pudo borrar la respuesta',

	'reply:this' => 'Responder a esto',

	'group:replies' => 'Respuestas',
	'groups:forum:created' => 'Creado %s con %d comentarios',
	'groups:forum:created:single' => 'creado %s con %d respuestas',
	'groups:forum' => 'Discusi&oacute;n',
	'groups:addtopic' => 'Agregar un tema',
	'groups:forumlatest' => '&uacute;ltima discusi&oacute;n',
	'groups:latestdiscussion' => '&uacute;ltimas discusiones',
	'groups:newest' => 'Nuevo',
	'groupspost:success' => 'Tu respuesta ha sido publicada',
	'groups:alldiscussion' => '&uacute;ltima discusi&oacute;n',
	'groups:edittopic' => 'Editar tema',
	'groups:topicmessage' => 'Mensaje del tema',
	'groups:topicstatus' => 'Estado del tema',
	'groups:reply' => 'Publicar un comentario',
	'groups:topic' => 'Tema',
	'groups:posts' => 'Publicaciones',
	'groups:lastperson' => '&Uacute;ltimo usuario',
	'groups:when' => 'Cuando',
	'grouptopic:notcreated' => 'No hay temas creados.',
	'groups:topicopen' => 'Abierto',
	'groups:topicclosed' => 'Cerrado',
	'groups:topicresolved' => 'Resuelto',
	'grouptopic:created' => 'Tu tema ha sido creado.',
	'groupstopic:deleted' => 'El tema ha sido creado.',
	'groups:topicsticky' => 'Sticky',
	'groups:topicisclosed' => 'Esta discusi&oacute;n est&aacute; cerrada.',
	'groups:topiccloseddesc' => 'Este tema est&aacute; cerrado y no acepta nuevas respuestas.',
	'grouptopic:error' => 'El grupo no pudo ser creado. Por favor intenta de nuevo o contacta con el administrador.',
	'groups:forumpost:edited' => "Has editado la entrada exitosamente.",
	'groups:forumpost:error' => "Hubo un problema al editar la entrada.",


	'groups:privategroup' => 'Este es un grupo cerrado. Debes solicitar membres�a.',
	'groups:notitle' => 'El grupo debe tener un t&iacute;tulo',
	'groups:cantjoin' => 'No se puedo unir al grupo',
	'groups:cantleave' => 'No se pudo abandonar el grupo',
	'groups:removeuser' => 'Remover del grupo',
	'groups:cantremove' => 'No se puede remover este usuario del grupo',
	'groups:removed' => 'El usuario %s ha sido removido del grupo',
	'groups:addedtogroup' => 'El usuario ha sido agregado con &eacute;xito',
	'groups:joinrequestnotmade' => 'No se pudo enviar la solicitud de membres&iacute;a del grupo',
	'groups:joinrequestmade' => 'Solicitar unirse al grupo',
	'groups:joined' => 'Te has unido al grupo',
	'groups:left' => 'Has abandonado el grupo',
	'groups:notowner' => 'No eres el propietario del grupo.',
	'groups:notmember' => 'No eres miembro de este grupo.',
	'groups:alreadymember' => 'Ya eres miembro de este grupo',
	'groups:userinvited' => 'El usuario ha sido invitado.',
	'groups:usernotinvited' => 'El usuario no pudo ser invitado.',
	'groups:useralreadyinvited' => 'El uuario ya ha sido invitado',
	'groups:invite:subject' => "%s te ha invitado al grupo %s",
	'groups:updated' => "&Uacute;ltima respuesta en %s de %s",
	'groups:started' => "Iniciado por %s",
	'groups:joinrequest:remove:check' => '&iquest;Seguro que deseas cancelar la solicitud de membres&iacute;a?',
	'groups:invite:remove:check' => '&iquest;Seguro que deseas anular esta invitaci&oacute;n?',
	'groups:invite:body' => "Hi %s,

%s te ha invitado para que te unas al grupo '%s'. Haz click en el siguiente enlace para unirte:

%s",

	'groups:welcome:subject' => "Bienvenido al grupo %s",
	'groups:welcome:body' => "Hola %s!

Ahora eres miembro de '%s'. Haz click en el siguiente enlace para empezar a postear:

%s",

	'groups:request:subject' => "%s ha solicitado unirse a %s",
	'groups:request:body' => "Hola %s,

%s ha solicitado unirse al grupo '%s'. Click en el siguiente enlace para ver el perfil:

%s

O click a continuaci&oacute;n para ver las solicitudes de membres&iacute;a del grupo:

%s",

	/*
		Forum river items
	*/

	'river:create:group:default' => '%s ha creado el grupo %s',
	'river:join:group:default' => '%s se ha unido al grupo %s',
	'river:create:object:groupforumtopic' => '%s abri&oacute; el tema %s',
	'river:reply:object:groupforumtopic' => '%s ha respondido en el tema %s',
	
	'groups:nowidgets' => 'No se han definido widgets para el grupo.',


	'groups:widgets:members:title' => 'Miembros del grupo',
	'groups:widgets:members:description' => 'Lista de miembros del grupo.',
	'groups:widgets:members:label:displaynum' => 'Lista de miembros de un grupo.',
	'groups:widgets:members:label:pleaseedit' => 'Por favor configura este widget.',

	'groups:widgets:entities:title' => "Objetos en el grupo",
	'groups:widgets:entities:description' => "Lista de objetos guardados en este grupo",
	'groups:widgets:entities:label:displaynum' => 'Lista de objetos de este grupo.',
	'groups:widgets:entities:label:pleaseedit' => 'Por favor configura este widget.',

	'groups:forumtopic:edited' => 'Tema de discusi&oacute;n guaddado con &eacute;xito.',

	'groups:allowhiddengroups' => '&iquest;Desea habilitar los grupos provados?',

	/**
	 * Action messages
	 */
	'group:deleted' => 'Grupo y contenidos borrados',
	'group:notdeleted' => 'El grupo no pudo ser borrado',

	'group:notfound' => 'No se pudo encontrar el Grupo',
	'grouppost:deleted' => 'Publicaci&oacute;n del grupo borrada con &eacute;xito',
	'grouppost:notdeleted' => 'La publicaci&oacute;n del grupo no se pudoborrar',
	'groupstopic:deleted' => 'Tema borrado',
	'groupstopic:notdeleted' => 'No se pudo borrar el tema',
	'grouptopic:blank' => 'No hay temas',
	'grouptopic:notfound' => 'No se pude encontrar el tema solicitado',
	'grouppost:nopost' => 'Post vacio',
	'groups:deletewarning' => "&iquest;Seguro que deseas borrar este grupo? No se puede deshacer",

	'groups:invitekilled' => 'El invitado ha sido eliminado.',
	'groups:joinrequestkilled' => 'La solicitud ha sido borrada.',

	// ecml
	'groups:ecml:discussion' => 'Discusi&oacute;n de los grupos',
	'groups:ecml:groupprofile' => 'Pefiles de los grupos',
	'groups:uniquetitle' => 'Ya existe un grupo con ese nombre. Por favor usa otro nombre',

);

add_translation("es", $spanish);