<?php
/**
 * User dashboard languages
 */

$spanish = array(
	'dashboard:widget:group:title' => 'Actiidad del grupo',
	'dashboard:widget:group:desc' => 'Ver la actividad de uno o m&aacute;s grupos',
	'dashboard:widget:group:select' => 'Selecciona un grupo',
	'dashboard:widget:group:noactivity' => 'No hay actividad en este grupo',
	'dashboard:widget:group:noselect' => 'Editar este widget para ver los grupos',
);

add_translation("es", $spanish);