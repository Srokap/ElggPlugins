<?php
/**
 * Elgg profile plugin language pack
 *
 * Spanish translation by Davod
 */

$spanish = array(
	'profile' => 'Perfil',
	'profile:notfound' => 'No se puede encontrar el perfil solicitado.',

);

add_translation('es', $spanish);