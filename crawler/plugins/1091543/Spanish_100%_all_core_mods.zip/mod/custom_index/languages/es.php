<?php
/**
 * Custom Index Spanish language file
 */

$spanish = array(	
	'custom:bookmarks' => "&uacute;ltimos marcadores",
	'custom:groups' => "&uacute;ltimos grupos",
	'custom:files' => "&uacute;ltimos archivos",
	'custom:blogs' => "&uacute;ltimos blogs",
	'custom:members' => "Nuevos miembros",
);
					
add_translation("es", $spanish);
