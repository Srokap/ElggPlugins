<?php
/**
 * Elgg garbage collector spanish language pack.
 *
 * @package ElggGarbageCollector
 */

$spanish = array(
	'garbagecollector:period' => '&iquest;Cada cuanto tiempo deseas ejecutar el recolector de basura?',

	'garbagecollector:weekly' => 'Semanalmente',
	'garbagecollector:monthly' => 'Mensualmente',
	'garbagecollector:yearly' => 'Anualmente',

	'garbagecollector' => "RECOLECTOR DE BASURA\n",
	'garbagecollector:done' => "HECHO\n",
	'garbagecollector:optimize' => "Optimizando %s ",

	'garbagecollector:error' => "ERROR",
	'garbagecollector:ok' => "OK",

	'garbagecollector:gc:metastrings' => 'Limpiando metastrings desvinculados: ',
);

add_translation("es", $spanish);