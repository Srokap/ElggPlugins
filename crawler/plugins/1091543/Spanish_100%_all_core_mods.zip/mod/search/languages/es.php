<?php

$spanish = array(
	'search:enter_term' => 'Ingresa un t&eacute;rmino para buscar:',
	'search:no_results' => 'Sin resultados.',
	'search:matched' => 'Coincide: ',
	'search:results' => 'Resultados para %s',
	'search:no_query' => 'Por favor ingresa una consulta para buscar.',
	'search:search_error' => 'Error',

	'search:more' => '+%s m&aacute;s %s',

	'search_types:tags' => 'Tags',

	'search_types:comments' => 'Comments',
	'search:comment_on' => 'Comment on "%s"',
	'search:comment_by' => 'por',
	'search:unavailable_entity' => 'Entrada no disponible',
);

add_translation('es', $spanish);
