<?php
/**
 * Tag cloud Spanish language file
 */

$spanish = array(
	'tagcloud:widget:title' => 'Nube de etiquetas',
	'tagcloud:widget:description' => 'Nube de etiquetas',
	'tagcloud:widget:numtags' => 'N&uacute;mero de etiquetas a mostrar',
);

add_translation('es', $spanish);
