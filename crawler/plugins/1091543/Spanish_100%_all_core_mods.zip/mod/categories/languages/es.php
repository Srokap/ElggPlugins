<?php
/**
 * Categories Spanish language file
 */

$spanish = array(
	'categories' => 'Categor&iacute;as',
	'categories:settings' => 'Configurar las categor&iacute;as del sitio',
	'categories:explanation' => 'Para configurar las categorias del sistema predeterminadas, ingr&eacute;salas a continuaci&oacute;n, separadas por comas. Compatible tools will then display them when the user creates or edits content.',
	'categories:save:success' => 'Categori&iacute;as guardadas exitosamente.',
	'categories:results' => "Resultados para esta categor&iacute;a: %s",
	'categories:on_activate_reminder' => "Las categor&iacute;s del sitio no funcionan si no hay categir&iacute;as. <a href=\"%s\">Agrega categor&iacute;as ahora.</a>",
);

add_translation("es", $spanish);