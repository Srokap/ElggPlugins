<?php
function in_arrayi($needle, $haystack)
{
    foreach ($haystack as $value)
    {
        if (strtolower($value) == strtolower($needle))
        return true;
    }
    return false;
}
$LOCFLD_STOP_DEPTH = 3;
$LOCFLD_SHOW_DEPTH = 1;

$queryarr =  explode("?",$_SERVER['REQUEST_URI']);

if(!empty($queryarr[1]))
 {
   if($_SESSION['filterq'] != $queryarr[1]) $_SESSION['filterq'] = $queryarr[1];
 }

 $querysplit = explode("&",$_SESSION['filterq']);
 $querystr = '?'.$_SESSION['filterq'];
 $lang_list = elgg_echo("Locationbook:List");
 $lang_Map = elgg_echo("Locationbook:Map");
 $lang_Group = elgg_echo("Locationbook:Group");
 $lang_Search = elgg_echo("Locationbook:Search");
 
 $body  = "<ul class='elgg-menu elgg-menu-filter elgg-menu-hz elgg-menu-filter-default'>";
 $body .= "<li class='elgg-menu-item-all elgg-state-selected'><a href='/LocationBook/all".$querystr."'>$lang_list</a></li>";
 $body .= "<li class='elgg-menu-item-mine '><a href='/LocationBook/map/".$querystr."'>$lang_Map</a></li>";
 $body .= "<li class='elgg-menu-item-mine'><a href='/LocationBook/grp'>$lang_Group</a></li>";
 $body .= "<li class='elgg-menu-item-mine'><a href=''>$lang_Search</a></li>";
 $body .= "</ul>";

 

$nextlink = "/LocationBook/all/";
elgg_push_breadcrumb(elgg_echo("Locationbook:All"),$nextlink.$querystr);
$segmentcount = 1;
     for (; ($segmentcount <count($segments)) && ($segmentcount <$LOCFLD_STOP_DEPTH); $segmentcount++)
     {	  
	  $nextlink = $nextlink.$segments[$segmentcount]."/";
	  elgg_push_breadcrumb($segments[$segmentcount],$nextlink.$querystr);
     } 
	 
/////////////////////////////////
$metaset = array();
foreach($querysplit as $q)
{
 $tm = explode("=",$q);

 if(($tm[0] != '') AND($tm[1] != 'Any'))
   $metaset[$tm[0]]=urldecode ($tm[1]);
} 
$LocationFieldNames = explode(",",elgg_get_plugin_setting('LocationFieldNames' , 'LocationBook')); 
$fld1 = array();
$options = array(
	'type' => 'object',
	'subtype' => 'LocationObject',
	'limit' =>'0',	
);
$loclist= elgg_get_entities($options);	 
$tmpbody = '';
$totalcount = 0;
foreach($loclist as $locobj)
 { 
    $segid = 1;
	$locfldpresent = FALSE;
	//$body .= '<br>';	$body .= $locobj->title;
	foreach ($metaset as $key=>$value)
		{
		if($key == 'sitecategories') $key = universal_categories;
		//$body .= '<br> key ='; $body .= $key; $body .=" value =";$body .= $value;  
		if(is_array($locobj->$key)){ /*$body .=" aval =";$body .= implode(',',$locobj->$key);*/
			if(!in_array($value,$locobj->$key)) {/*$body .="  skipped <br>"; */continue 2;} }
		else {/*$body .=" val =";$body .=$locobj->$key;*/if($locobj->$key != $value){/*$body .="  skipped <br>"; */continue 2;}}
		}

     for (; ($segid <count($segments)) && ($segid <3); $segid++)
     {
	  //$body .="<br>";    //debug
	  //$body .= $segid;	  
	  //$body .= $segments[$segid]; $body .="&nbsp&nbsp";	  
	  //$body .= $locobj->$LocationFieldNames[$segid-1];
	  if(($locobj->$LocationFieldNames[$segid-1] == '') AND ($segments[$segid] == 'unknown')){continue;}
	  else { $locfldpresent = TRUE;}
      if (strtolower($locobj->$LocationFieldNames[$segid-1]) != strtolower($segments[$segid])) {/*$body .="hm...";*/continue 2;}
     } 
	 //$body .="....loop over <br>";
	    $tmpbody .="<br>\n";
     	$tmpbody .="<a href='".$locobj->getURL()."'>".$locobj->title."</a>"; $tmpbody .="<br>\n";		
		$tmpbody .= elgg_get_excerpt($locobj->description,127);
        $totalcount++;
	 if(($segmentcount>1)  AND ($locfldpresent === FALSE) AND ($segments[$segid-1] != 'unknown')) {continue;}
	if (!in_arrayi($locobj->$LocationFieldNames[$segid-1],$fld1))
	{
	  //$body .="ok...";$body .= $segid;$body .=$LocationFieldNames[$segid-1];
	  $fld1[] = $locobj->$LocationFieldNames[$segid-1];
	}
 }


$body .= "\n<table  style='width:100%; border: 2px solid #CCC;padding-top: 20px;padding-bottom: 4px;padding-left: 4px;'>";
$tmp = 0;

if($segmentcount <$LOCFLD_STOP_DEPTH)
{
	foreach($fld1 as $val)
	{
	  if($val =='')
	  {
	   $val ='unknown';
	  }
	   if($tmp === 0)
	   {  $tmp = $tmp +1;
		   $body .= "\n<tr ><td style='border: 1px solid #CCC; padding-right: 10px;'>\n<a href='";
		   $body .= $nextlink.$val;
		   $body .= $querystr;
		   $body .="'>";

	   $body .= $val;
	   $body .= "</a></td>";
	   }
	   elseif($tmp === 1)
	   {  $tmp = 0;
	    $body .= "<td style='border: 1px solid #CCC; padding-right: 10px;'>\n<a href='";
		$body .= $nextlink.$val;
		$body .= $querystr;
	   $body .="'>";	
	   $body .= $val;
	   $body .= "</td></tr>";
	   }  
	}
}
if($tmp === 1)
{
$body .= "<td style='border: 1px solid #CCC; padding-right: 10px;'>&nbsp</td>";
}
$body .= "\n</table>\n";


if($segmentcount >$LOCFLD_SHOW_DEPTH)
{
  $body .="<br>";
  $body .= $tmpbody;
} 
	elgg_register_menu_item('title', array(
			'name' => 'CreateLocation',
			'href' => "LocationBook/add",
			'text' => elgg_echo("Locationbook:Create Entry"),
			'link_class' => 'elgg-button elgg-button-action',
	));
$sidebar = "";


$body = elgg_view_layout('content', array(
	'filter' => '',
	'content' => $body,
	'title' => $totalcount.elgg_echo("Locationbook:Locations"),
	'sidebar' => elgg_view('LocationBook/sidebar/filter'),
));


 echo elgg_view_page("All Site Locations", $body);
?>
