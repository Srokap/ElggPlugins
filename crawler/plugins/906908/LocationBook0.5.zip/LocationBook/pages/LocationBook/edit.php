<?php
// make sure only logged in users can see this page 
gatekeeper();

$page_owner = elgg_get_page_owner_entity();


$locobj_guid = $segments[1];


$locobj = get_entity($locobj_guid);

$tt =  $locobj->getSubtype();

if($tt == 'LocationObject'){

include elgg_get_plugins_path() . 'LocationBook/pages/LocationBook/editlocobj.php';
}
else  if($tt == 'LocationGrp'){

include elgg_get_plugins_path() . 'LocationBook/pages/LocationBook/editgrpobj.php';

	}


?>