<?php

$queryarr =  explode("?",$_SERVER['REQUEST_URI']);

if($queryarr[1])
 {
   if($_SESSION['filterq'] != $queryarr[1]) $_SESSION['filterq'] = $queryarr[1];
 }

$querystr = '?'.$_SESSION['filterq'];

$lang_List = elgg_echo("Locationbook:List");
 $lang_Map = elgg_echo("Locationbook:Map");
 $lang_Group = elgg_echo("Locationbook:Group");
 $lang_Search = elgg_echo("Locationbook:Search");
 $body = "<ul class='elgg-menu elgg-menu-filter elgg-menu-hz elgg-menu-filter-default'>";
 $body .= "<li class='elgg-menu-item-all '><a href='/LocationBook/all".$querystr."'>$lang_List</a></li>";
 $body .= "<li class='elgg-menu-item-mine elgg-state-selected'><a href='/LocationBook/map".$querystr."'>$lang_Map</a></li>";
 $body .= "<li class='elgg-menu-item-mine'><a href='/LocationBook/grp'>$lang_Group</a></li>";
 $body .= "<li class='elgg-menu-item-mine'><a href=''>$lang_Search</a></li>";
 $body .= "</ul>";
  


 
  $body .= elgg_view("LocationBook/multilocationmap");
	elgg_register_menu_item('title', array(
			'name' => 'CreateLocation',
			'href' => "LocationBook/add",
			'text' => elgg_echo("Locationbook:Create Entry"),
			'link_class' => 'elgg-button elgg-button-action',
	));



$body = elgg_view_layout('content', array(
	'filter' => '',
	'content' => $body,
	'title' => elgg_echo("Locationbook:Locations"),
	'sidebar' => elgg_view('LocationBook/sidebar/filter'),
));


 echo elgg_view_page("All Site Locations", $body);
?>
