


<?php
$grpobj_guid = $segments[1];

$grpobj = get_entity($grpobj_guid);
if (!$grpobj) {
	forward();
}



elgg_push_breadcrumb(elgg_echo("Locationbook:AllGroups"),"LocationBook/grp");

$title = $grpobj->title;

$content = elgg_view_entity($grpobj, array('full_view' => true));


	elgg_register_menu_item('title', array(
			'name' => 'CreateLocation',
			'href' => "LocationBook/add/$grpobj_guid",
			'text' => elgg_echo("Locationbook:Create Location"),
			'link_class' => 'elgg-button elgg-button-action',
	));

$content .= elgg_view("LocationBook/grouplocationmap",array('grpobjguid' =>$grpobj_guid));
$content .= elgg_view_comments($grpobj);

if (elgg.isloggedin) {


}

$queryarr =  explode("?",$_SERVER['REQUEST_URI']);
$querysplit = explode("&",$queryarr[1]);
if($queryarr[1])
$querystr = '?'.$queryarr[1];

$lang_List = elgg_echo("Locationbook:List");
 $lang_Map = elgg_echo("Locationbook:Map");
 $lang_Group = elgg_echo("Locationbook:Group");
 $lang_Search = elgg_echo("Locationbook:Search");
 $sidebar  = "<ul class='elgg-menu elgg-menu-filter elgg-menu-hz elgg-menu-filter-default'>";
 $sidebar .= "<li class='elgg-menu-item-all '><a href='/LocationBook/all".$querystr."'>$lang_List</a></li>";
 $sidebar .= "<li class='elgg-menu-item-mine '><a href='/LocationBook/map/".$querystr."'>$lang_Map</a></li>";
 $sidebar .= "<li class='elgg-menu-item-mine'><a href='/LocationBook/grp'>$lang_Group</a></li>";
 $sidebar .= "<li class='elgg-menu-item-mine'><a href=''>$lang_Search</a></li>";
 $sidebar .= "</ul>";

$body = elgg_view_layout('content', array(
	'filter' => '',
	'content' => $content,
	'title' => $title,
	'sidebar' => $sidebar,
));

echo elgg_view_page("", $body);
