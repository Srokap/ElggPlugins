<?php
$locobj_guid = $segments[1];

$locobj = get_entity($locobj_guid);
if (!$locobj) {
	forward();
}


elgg_push_breadcrumb(elgg_echo("Locationbook:Locations"),"LocationBook/all");

 
$title = $locobj->title;

$content = elgg_view_entity($locobj, array('full_view' => true));



$content .="<table style='width:100%; border: 1px solid #CCC; '>";
$SitewideCategories = elgg_get_plugin_setting('SitewideCategories', 'LocationBook');

$content .="<tr><td style='border: 1px solid #CCC; padding-right: 10px;'> webURL</td><td style='border: 1px solid #CCC; padding-left: 4px;  padding-right: 4px;'>";
$content .= elgg_view('output/url', array('value' => $locobj->webURL,'href' => $locobj->webURL,));
$content .="</td><tr>";
$options = array(
				'type' => 'object',
				'relationship' => 'contains',
				'relationship_guid' => $locobj_guid ,
				'inverse_relationship' => true,
				'full_view' => false,
			);
$objects = elgg_get_entities_from_relationship($options);

if(count($objects))
{
$content .="<tr><td style='border: 1px solid #CCC; padding-right: 10px;'> group</td><td style='border: 1px solid #CCC; padding-left: 4px;  padding-right: 4px;'>";
$content .= elgg_view('output/url', array('text' => $objects[0]->title,'href' => $objects[0]->getURL(),));
}
$content .="</td><tr>";

$ExtraFieldNames = explode(",",elgg_get_plugin_setting('ExtraFieldNames' , 'LocationBook')); 
for ($pos=0; $pos<count($ExtraFieldNames); $pos++)
{
$content .="<tr><td style='border: 1px solid #CCC; padding-right: 10px;'>";
$content .= $ExtraFieldNames[$pos];
$content .=" </td><td style='border: 1px solid #CCC; padding-left: 4px;  padding-right: 4px;'>";
if (is_array($locobj->$ExtraFieldNames[$pos]))
  $content .= implode(',',$locobj->$ExtraFieldNames[$pos]);	 
else
  $content .= $locobj->$ExtraFieldNames[$pos];	
$content .="</td><tr>";
}

$LocationFieldNames = explode(",",elgg_get_plugin_setting('LocationFieldNames' , 'LocationBook')); 
for ($pos=0; $pos<count($LocationFieldNames); $pos++)
{	
$content .="<tr><td style='border: 1px solid #CCC; padding-right: 10px;'>";
$content .= $LocationFieldNames[$pos];
$content .="</td><td style='border: 1px solid #CCC; padding-left: 6px; padding-right: 4px;'>";
$content .= $locobj->$LocationFieldNames[$pos];	
$content .="</td><tr>";
}

$content .="</table>";

$startingLat = $locobj->lat;
$startingLong = $locobj->long;

if(!$startingLat)
	{
	$startingLat = elgg_get_plugin_setting('defaultLat', 'LocationBook');
	$startingLong = elgg_get_plugin_setting('defaultLong', 'LocationBook');
    }
//	$content .= elgg_view('LocationBook/onelocationmap');
$content .= elgg_view('LocationBook/onelocationmap',array('lat' => $startingLat,'long' => $startingLong,));    //"<br><div id='map_canvas' style='width: 700px; height: 300px'></div>";


$content .= elgg_view_comments($locobj);

if (elgg.isloggedin) {


}
$queryarr =  explode("?",$_SERVER['REQUEST_URI']);
$querysplit = explode("&",$queryarr[1]);
if($queryarr[1])
$querystr = '?'.$queryarr[1];
$lang_List = elgg_echo("Locationbook:List");
 $lang_Map = elgg_echo("Locationbook:Map");
 $lang_Group = elgg_echo("Locationbook:Group");
 $lang_Search = elgg_echo("Locationbook:Search");
 $sidebar  = "<ul class='elgg-menu elgg-menu-filter elgg-menu-hz elgg-menu-filter-default'>";
 $sidebar .= "<li class='elgg-menu-item-all '><a href='/LocationBook/all".$querystr."'>$lang_List</a></li>";
 $sidebar .= "<li class='elgg-menu-item-mine '><a href='/LocationBook/map/".$querystr."'>$lang_Map</a></li>";
 $sidebar .= "<li class='elgg-menu-item-mine'><a href='/LocationBook/grp'>$lang_Group</a></li>";
 $sidebar .= "<li class='elgg-menu-item-mine'><a href=''>$lang_Search</a></li>";
 $sidebar .= "</ul>";

$body = elgg_view_layout('content', array(
	'filter' => '',
	'content' => $content,
	'title' => $title,
	'sidebar' => $sidebar,
));

echo elgg_view_page("", $body);
?>