<?php

$LOCFLD_STOP_DEPTH = 3;
$LOCFLD_SHOW_DEPTH = 1;

$lang_List = elgg_echo("Locationbook:List");
 $lang_Map = elgg_echo("Locationbook:Map");
 $lang_Group = elgg_echo("Locationbook:Group");
 $lang_Search = elgg_echo("Locationbook:Search");
 $body  = "<ul class='elgg-menu elgg-menu-filter elgg-menu-hz elgg-menu-filter-default'>";
 $body .= "<li class='elgg-menu-item-all '><a href='/LocationBook/all'>$lang_List</a></li>";
 $body .= "<li class='elgg-menu-item-mine '><a href='/LocationBook/map'>$lang_Map</a></li>";
 $body .= "<li class='elgg-menu-item-mine elgg-state-selected'><a href='/LocationBook/grp'>$lang_Group</a></li>";
 $body .= "<li class='elgg-menu-item-mine'><a href=''>$lang_Search</a></li>";
 $body .= "</ul>";

elgg_push_breadcrumb(elgg_echo("Locationbook:AllGroups"),"LocationBook/grp");
$grplist= elgg_get_entities(array(
	'type' => 'object',
	'subtype' => 'LocationGrp',
	'limit' => '0',
	
));
foreach($grplist as $grp)
{
    $body .="<br>\n";
    $body .="<a href='".$grp->getURL()."'>".$grp->title."</a>"; $body .="<br>\n";
	$body .=  elgg_get_excerpt($grp->description,115);
    
}
	elgg_register_menu_item('title', array(
			'name' => 'CreateGrp',
			'href' => "LocationBook/addgrp",
			'text' => elgg_echo("Locationbook:Create Group"),
			'link_class' => 'elgg-button elgg-button-action',
	));

	
$sidebar = "";


$body = elgg_view_layout('content', array(
	'filter' => '',
	'content' => $body,
	'title' => 'LocationGroups',
	'sidebar' => elgg_view('LocationBook/sidebar/navigation'),
));


 echo elgg_view_page("All Site Locations", $body);
?>
