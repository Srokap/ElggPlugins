<?php
/**
 * Delete locobj entity
 *
 * @package locobj
 */

$locobj_guid = get_input('guid');
$locobj = get_entity($locobj_guid);
$fpath  = '';

$isLocation = FALSE;
if (elgg_instanceof($locobj, 'object', 'LocationGrp')) 
{
 $fpath  = '/LocationBook/grp'; 
 $isLocation = TRUE;
}
else if (elgg_instanceof($locobj, 'object', 'LocationObject'))
{
 $fpath  = '/LocationBook/all'; 
 $isLocation = TRUE;
}

if ($locobj->canEdit() AND ($isLocation == TRUE)) {
	   if ($locobj->delete()) {
		system_message(elgg_echo("Locationbook:deleted successfully"));
		}   
} 
else
{register_error(elgg_echo('Locationbook:insufficient permisson')); }

forward($fpath);
