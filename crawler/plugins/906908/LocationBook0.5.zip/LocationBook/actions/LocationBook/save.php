<?php

gatekeeper();

$guid = get_input('guid');
if (!$guid) {
$newobj = True;
  $locobj= new ElggObject();
  $locobj->subtype = 'LocationObject';
  $locobj->extrafield = array();
  $locobj->locationfield = array();
 }
else {
        
	 $locobj = get_entity($guid);
	if (! $locobj->canEdit()) {
		system_message("Locationbook:LocationBook save failed" );
		forward(REFERRER);
	}
}


$locobj->title = get_input('title');
$locobj->description = get_input('description');

$locobj->webURL = get_input('webURL');
$locobj->lat = get_input('lat');
$locobj->long = get_input('long');

$ExtraFieldNames = explode(",",elgg_get_plugin_setting('ExtraFieldNames' , 'LocationBook')); 
for ($pos=0; $pos<count($ExtraFieldNames); $pos++)
{	
$locobj->$ExtraFieldNames[$pos] =  get_input($ExtraFieldNames[$pos]);
}


$LocationFieldNames = explode(",",elgg_get_plugin_setting('LocationFieldNames' , 'LocationBook')); 
for ($pos=0; $pos<count($LocationFieldNames); $pos++)
{
$locobj->{$LocationFieldNames[$pos]}= get_input($LocationFieldNames[$pos]);
}


 // for now make all my_blog posts public
$locobj->access_id = ACCESS_PUBLIC;
 
 // owner is logged in user
$locobj->owner_guid = elgg_get_logged_in_user_guid();
 
// save to database and get id of the new my_blog
$locobj_guid =  $locobj->save();

$grpguid = get_input('grpguid');
if($grpguid)
{
add_entity_relationship($grpguid, 'contains', $locobj_guid);
}

 if ( $locobj_guid) {
    if($newobj)
          system_message(elgg_echo("Locationbook:new Location is created"));
    else
	      system_message(elgg_echo("Locationbook:Location is saved"));
    forward( $locobj->getURL());
 } else {
    register_error("Locationbook:The location could not be saved");
    forward(REFERER); // REFERER is a global variable that defines the previous page
 }
?>