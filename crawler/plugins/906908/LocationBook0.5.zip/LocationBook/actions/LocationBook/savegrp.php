<?php



$guid = get_input('guid');
if (!$guid) {
$newobj = True;
  $grpobj= new ElggObject();
  $grpobj->subtype = 'LocationGrp';
  $grpobj->GrpField = array();
  $grpobj->locationfield = array();
 }
else {
        
	 $grpobj = get_entity($guid);
	if (! $grpobj->canEdit()) {
		system_message("Locationbook:LocationGroup save failed" );
		forward(REFERRER);
	}
}

$grpobj->title = get_input('title');
$grpobj->description = get_input('description');
$grpobj->webURL = get_input('webURL');
$GrpFieldNames = explode(",",elgg_get_plugin_setting('GrpFieldNames' , 'LocationBook')); 
for ($pos=0; $pos<count($GrpFieldNames); $pos++)
{	
$grpobj->$GrpFieldNames[$pos] =  get_input($GrpFieldNames[$pos]);
}
 // for now make all my_blog posts public
$grpobj->access_id = ACCESS_PUBLIC;
 
 // owner is logged in user
$grpobj->owner_guid = elgg_get_logged_in_user_guid();
 
// save to database and get id of the new my_blog
$grpobj_guid =  $grpobj->save();


 if ( $grpobj_guid) {
    if($newobj)
          system_message(elgg_echo("Locationbook:new Location Group is created"));
    else
	      system_message(elgg_echo("Locationbook:Location Group is saved"));
    forward( $grpobj->getURL());
 } else {
    register_error(elgg_echo("Locationbook:The location Group could not be saved"));
    forward(REFERER); // REFERER is a global variable that defines the previous page
 }
?>