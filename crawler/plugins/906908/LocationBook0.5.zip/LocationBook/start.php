<?php
/**
 * Describe plugin here
 */

elgg_register_event_handler('init', 'system', 'LocationBook_init');

function LocationBook_init() {
	$base_dir = elgg_get_plugins_path() . 'LocationBook/actions/LocationBook';
     elgg_register_action("LocationBook/save", $base_dir . '/save.php');
     elgg_register_action('LocationBook/delete', "$base_dir/delete.php");
	 elgg_register_action('LocationBook/savegrp', "$base_dir/savegrp.php");
    //a little help from you to promote my site.
    elgg_extend_view('page/elements/footer','LocationBook/footer/footerlink');
     
     elgg_register_page_handler('LocationBook', 'LocationBook_page_handler');

	elgg_register_entity_url_handler('object', 'LocationObject', 'LocationBook_url_handler');
	elgg_register_entity_url_handler('object', 'LocationGrp', 'LocationBook_url_handler');
	//support sitewide search
	register_entity_type('object','LocationObject');
	register_entity_type('object','LocationGrp');
		// Register granular notification for this type
	//register_notification_object('object', 'LocationObject', elgg_echo('LocationObject'));
    // Add a menu item to the main site menu
	$menuTitle = elgg_get_plugin_setting('menuTitle', 'LocationBook');
	
	$item = new ElggMenuItem('LocationBook', $menuTitle, 'LocationBook/all');
	elgg_register_menu_item('site', $item);
	$js_url = 'mod/LocationBook/vendors/mapiconmaker.js';
	elgg_register_js('LocationBook.mapiconmaker', $js_url);
 }

function LocationBook_page_handler($segments) {
    if ($segments[0] == 'add') {
        include elgg_get_plugins_path() . 'LocationBook/pages/LocationBook/add.php';
        return true;
    }
    if ($segments[0] == 'edit') {
        include elgg_get_plugins_path() . 'LocationBook/pages/LocationBook/edit.php';
        return true;
    }

    if ($segments[0] == 'all') {
        include elgg_get_plugins_path() . 'LocationBook/pages/LocationBook/all.php';
        return true;
    }
    if ($segments[0] == 'map') {
        include elgg_get_plugins_path() . 'LocationBook/pages/LocationBook/map.php';
        return true;
    }
    if ($segments[0] == 'viewlocobj') {
        include elgg_get_plugins_path() . 'LocationBook/pages/LocationBook/viewlocobj.php';
        return true;
    }
    if ($segments[0] == 'grp') {
        include elgg_get_plugins_path() . 'LocationBook/pages/LocationBook/grp.php';
        return true;
    }
	if ($segments[0] == 'addgrp') {
        include elgg_get_plugins_path() . 'LocationBook/pages/LocationBook/addgrp.php';
        return true;
    }
	if ($segments[0] == 'viewgrpobj') {
        include elgg_get_plugins_path() . 'LocationBook/pages/LocationBook/viewgrpobj.php';
        return true;
    }
    return false;
}

function LocationBook_url_handler($entity) {
	if (!$entity->getOwnerEntity()) {
		// default to a standard view if no owner.
		return FALSE;
	}
$friendly_title = elgg_get_friendly_title($entity->title);
$tt =  $entity->getSubtype();
if($tt == 'LocationObject'){
return "LocationBook/viewlocobj/{$entity->guid}/$friendly_title";

//include elgg_get_plugins_path() . 'LocationBook/pages/LocationBook/viewlocobj.php';
}
else  if($tt == 'LocationGrp'){
return "LocationBook/viewgrpobj/{$entity->guid}/$friendly_title";
//include elgg_get_plugins_path() . 'LocationBook/pages/LocationBook/viewgrpobj.php';

	}

	
}