
0.6  plan for next release
relation {
corporate csr
partner NGO,  like in youthforseva
international affliation ?  like http://www.wwfindia.org/
}

change blue bullets color,size and logo based on cotext.
create loclet object, which are small centers of a given ngo,  they are visible at a zoomlevel 10.
support profile.
impliment search.
-------------------------------------
version 0.5
*Language support.
-------------------------------------
version 0.4
* MAJOR CHANGES:-> 
* BUG  : when there are multiple location with same lat,long, then only one location was shown in map
   solution  :Now all the location are embedded in the same marker.
* Added Filter in map
* supported the sitewide search.
* Added configurable fields for LocationGroup
* Added sitewide categories in LocationGroup
* Remember querystr in session so that from locobjview,grp pages also you can come back.
* BUGFIX :->
* Some of the extrafield are labeled as locfield which disturbs the google map adjsuting.
* The fix of case-insensitve comparision created another issues of not showing the Capital lettered location.
* The map in add,edit page  was zooming exponentially on field change.
* untitled objects where not visible in map
* MINOR CHANGES:->
* Tabview added in sidebar of locobj and locgrp
* In Edit view zoomlevel can be more then defaultzoomlevel.
* Create line after description in viewlocobj
* Show count in all.php and map.php
* Viewlocobj zoom level should be increased by 2 point
* group listing should show number of locations in breaket

-----------------------------------
version 0.3
* Added Choice fields, where admin can fill options.
* For additional field Choice can be  with multiple values.
* Support to site wide Category.
* Added sidebar filter for Choice Field and sitewide category.
* BUG FIX : elgg_get_entity was giving only 10 object
MINOR
* In the listing, I made the location field case in-sensetive.
-----------------------------------
version 0.2

added  LocationGroup.

-----------------------------------
version 0.1
The first version with basic features, 
List of location obj,
map of all locaqtion obj.
configurable location fields in setting.