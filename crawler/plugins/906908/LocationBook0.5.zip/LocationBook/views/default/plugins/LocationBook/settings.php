<?php
/**
 * Elgg log rotator plugin settings.
 *
 * @package ElggLogRotate
 */
 $menuTitle = $vars['entity']->menuTitle;
$googlekey = $vars['entity']->googlekey;
$defaultLat = $vars['entity']->defaultLat;
$defaultLong = $vars['entity']->defaultLong;
$defaultZoomLevel = $vars['entity']->defaultZoomLevel;

$GrpFieldNames = $vars['entity']->GrpFieldNames;
$GrpFieldSIZEs = $vars['entity']->GrpFieldSIZEs;

$LocationFieldNames = $vars['entity']->LocationFieldNames;
$LocationFieldSIZEs = $vars['entity']->LocationFieldSIZEs;

$ExtraFieldNames = $vars['entity']->ExtraFieldNames;
$ExtraFieldSIZEs = $vars['entity']->ExtraFieldSIZEs;

$ChoiceDetail =   $vars['entity']->ChoiceDetail;
$FilterDetail =   $vars['entity']->FilterDetail;
$SitewideCategories = $vars['entity']->SitewideCategories;
$SitewideCategoriesFilter = $vars['entity']->SitewideCategoriesFilter;
if (!$menuTitle) {
	$menuTitle = 'Locations';
}

if (!$googlekey) {
	$googlekey = '';
	$defaultLat = 23;
	$defaultLong =80;
	$defaultZoomLevel = 5;
}
if(!$defaultZoomLevel)
{
$defaultZoomLevel = 5;
}
if(!$ChoiceDetail)
{
$ChoiceDetail = "state=0:Maharastra";
}
if (!$LocationFieldNames) {
  $LocationFieldNames = "state,District,City,address,PIN";
  $LocationFieldSIZEs = "199,199,199,550,60";
  $GrpFieldNames = $ExtraFieldNames = "phone1,phone2,FAX,email";
  $GrpFieldSIZEs = $ExtraFieldSIZEs = "130,130,130,300";
  
}
?>

<div   style=' border: 1px solid #CC0;padding-top: 20px;padding-bottom: 4px;padding-left: 4px;'>
	<?php

		echo elgg_echo('Site menu title : ');
		echo elgg_view('input/text', array('name' => 'params[menuTitle]','value' => $menuTitle,'style'=>'width: 200px;'));
		echo elgg_echo('<br>Google Key : ');
		echo elgg_view('input/text', array('name' => 'params[googlekey]','value' => $googlekey,));
		echo elgg_echo('<br>Default lattitude  and Longitude, (23,80 is India)');
		echo elgg_view('input/text', array('name' => 'params[defaultLat]','value' => $defaultLat,'style'=>'width: 200px;',));
		echo elgg_view('input/text', array('name' => 'params[defaultLong]','value' => $defaultLong,'style'=>'width: 200px;'));
		echo elgg_echo('<br>Default Zoom  Level');
		echo elgg_view('input/text', array('name' => 'params[defaultZoomLevel]','value' => $defaultZoomLevel,'style'=>'width: 100px;'));
	?>
<br>
</div>
<?php
echo elgg_echo("<br></div>Use sitewide categories for LocationGroup and LocationObjects:");
echo elgg_echo("<input type='hidden' name='params[SitewideCategories]' value='0'/>");
if($SitewideCategories =='1')
 echo elgg_echo("<input type='checkbox' name='params[SitewideCategories]' value='1' checked/><br><br>");
else
echo elgg_echo("<input type='checkbox' name='params[SitewideCategories]' value='1' /><br><br>");
?>
<div  style=' border: 1px solid #CC0;padding-top: 20px;padding-bottom: 4px;padding-left: 4px;'>
<b>LocatioGroup  fields</b><br><br>
	<?php	
	    echo elgg_echo('Titles (comma separated)');
		echo elgg_view('input/text', array('name' => 'params[GrpFieldNames]','value' => $GrpFieldNames, ));
        echo elgg_echo('Sizes in pixel(comma separated)');
		echo elgg_view('input/text', array('name' => 'params[GrpFieldSIZEs]','value' => $GrpFieldSIZEs, ));	
	?>	
	
</div>
<div  style=' border: 1px solid #CC0;padding-top: 20px;padding-bottom: 4px;padding-left: 4px;'>
<b>LocationObject fields</b><br><br>
<div  style=' border: 1px solid #CCC;padding-top: 20px;padding-bottom: 4px;padding-left: 4px;'>
	<?php
	    echo elgg_echo('Location related fields( map adjust upon changing the field)<br><br>Titles (comma separated)');

		echo elgg_view('input/text', array('name' => 'params[LocationFieldNames]','value' => $LocationFieldNames, ));
        echo elgg_echo('Sizes in pixel(comma separated)');
		echo elgg_view('input/text', array('name' => 'params[LocationFieldSIZEs]','value' => $LocationFieldSIZEs, ));	
	


?>
<br>
<div  style=' border: 1px solid #CCC;padding-top: 20px;padding-bottom: 4px;padding-left: 4px;'>
	<?php	
	    echo elgg_echo('additional  fields<br><br>Titles (comma separated)');
		echo elgg_view('input/text', array('name' => 'params[ExtraFieldNames]','value' => $ExtraFieldNames, ));
        echo elgg_echo('Sizes in pixel(comma separated)');
		echo elgg_view('input/text', array('name' => 'params[ExtraFieldSIZEs]','value' => $ExtraFieldSIZEs, ));	
	?>	
	
</div>
</div>	
<div  style=' border: 1px solid #CC0;padding-top: 20px;padding-bottom: 4px;padding-left: 4px;'>
<b>Choice  fields</b><br><br>
	<?php
	    echo elgg_echo('syntext => Title=N:option1,option2...;Title=N:option1,option2...;...  where N is 0 (single choice) or 1 (multiple choice).');
		echo elgg_echo('Title must be one of the Location field, additional field or group fields above');
		echo elgg_echo('<br>example state=0:Gujarat,Rajasthan,Delhi;category=1:orphanage,oldagehome,slum,');
		echo elgg_view('input/text', array('name' => 'params[ChoiceDetail]','value' => $ChoiceDetail, ));
	?>	
	
</div>

<div  style=' border: 1px solid #CC0;padding-top: 20px;padding-bottom: 4px;padding-left: 4px;'>
<b>Filter Fields</b><br><br>
	<?php
		echo elgg_echo('Choose the field to add as sidebar filter(comma separated). Not applicable to  Group ');
		echo elgg_echo('<br>Title must be one of the Choice field above');
		echo elgg_view('input/text', array('name' => 'params[FilterDetail]','value' => $FilterDetail, ));
		echo elgg_echo('Use sitewide categories as filter:');
		
		echo elgg_echo("<input type='hidden' name='params[SitewideCategoriesFilter]' value='0'/>");
		if($SitewideCategoriesFilter =='1')
		 echo elgg_echo("<input type='checkbox' name='params[SitewideCategoriesFilter]' value='1' checked/>");
		else
		echo elgg_echo("<input type='checkbox' name='params[SitewideCategoriesFilter]' value='1' />");

	?>	

</div>