<?php 
//$body = elgg_view_title($vars['entity']->title);

  $friendly_title = elgg_get_friendly_title($vars['entity']->title);
  $locobj_url = "LocationBook/viewlocobj/{$vars['entity']->guid}/$friendly_title"; 
$body = elgg_view('output/url', array(
		'href' => $locobj_url,
		'text' => elgg_echo($vars['entity']->title),
		'is_trusted' => true,
	));


$locobj = $vars['entity'];
$body .= elgg_view('output/longtext', array('value' => $locobj->description));
$body .= "<a href='http://humchale.in/' ><hr></a>";
$SitewideCategories = elgg_get_plugin_setting('SitewideCategories', 'LocationBook');
    if( $SitewideCategories == '1')
	$body .=elgg_view('output/categories', $vars);
$metadata = elgg_view_menu('entity', array(
	'entity' => $locobj,
	'handler' => 'LocationBook',
	'sort_by' => 'priority',
	'class' => 'elgg-menu-hz',
));

	$params = array(
		'entity' => $blog,
		'title' => false,
		'metadata' => $metadata,
		'subtitle' => $subtitle,
		'tags' => $tags,
	);
	$params = $params + $vars;
	$summary = elgg_view('object/elements/summary', $params);
	echo elgg_view('object/elements/full', array(
		'summary' => $summary,
		'icon' => $owner_icon,
		'body' => $body,));
?>