<?php 
//$body = elgg_view_title($vars['entity']->title);
$locobj = $vars['entity'];
  $friendly_title = elgg_get_friendly_title($locobj->title);
  $locobj_url = "LocationBook/viewgrpobj/{$locobj->guid}/$friendly_title"; 
$body = elgg_view('output/url', array(
		'href' => $locobj_url,
		'text' => elgg_echo($vars['entity']->title),
		'is_trusted' => true,
	));



$body .= elgg_view('output/longtext', array('value' => $locobj->description));
$SitewideCategories = elgg_get_plugin_setting('SitewideCategories', 'LocationBook');
    if( $SitewideCategories == '1')
	$body .=elgg_view('output/categories', $vars);
	
$body .= elgg_view('output/url', array('value' => $locobj->webURL,'href' => $locobj->webURL,));
$body .="<table style='width:100%; border: 1px solid #CCC; '>";
	
$GrpFieldNames = explode(",",elgg_get_plugin_setting('GrpFieldNames' , 'LocationBook')); 
for ($pos=0; $pos<count($GrpFieldNames); $pos++)
{
$body .="<tr><td style='border: 1px solid #CCC; padding-right: 10px;'>";
$body .= $GrpFieldNames[$pos];
$body .=" </td><td style='border: 1px solid #CCC; padding-left: 4px;  padding-right: 4px;'>";
if (is_array($locobj->$GrpFieldNames[$pos]))
  $body .= implode(',',$locobj->$GrpFieldNames[$pos]);	 
else
  $body .= $locobj->$GrpFieldNames[$pos];	
$body .="</td><tr>";
}
$body .="</table>";
$options = array(
				'type' => 'object',
				'relationship' => 'contains',
				'relationship_guid' => $locobj->guid,
				'inverse_relationship' => false,
				'full_view' => false,
			);
$objects = elgg_get_entities_from_relationship($options);
$body  .= "<hr>";
foreach ($objects as $object) {
        $title = 'untitled'; if(!empty($object->title))$title = $object->title;	
        $body .="<a href='".$object->getURL()."'>".$title."</a>"; 
		$body .= "&nbsp&nbsp\n";
}
//$body .= elgg_list_entities_from_relationship($options );



$metadata = elgg_view_menu('entity', array(
	'entity' => $locobj,
	'handler' => 'LocationBook',
	'sort_by' => 'priority',
	'class' => 'elgg-menu-hz',
));

	$params = array(
		'entity' => $blog,
		'title' => false,
		'metadata' => $metadata,
		'subtitle' => $subtitle,
		'tags' => $tags,
	);
	$params = $params + $vars;
	$summary = elgg_view('object/elements/summary', $params);
	echo elgg_view('object/elements/full', array(
		'summary' => $summary,
		'icon' => $owner_icon,
		'body' => $body,));
?>