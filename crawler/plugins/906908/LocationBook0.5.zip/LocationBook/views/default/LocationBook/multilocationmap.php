<?php
echo "<script src='http://maps.google.com/maps?file=api&amp;v=2&amp;key=";
$googleKey = elgg_get_plugin_setting('googlekey', 'LocationBook');
echo $googleKey;
echo "' type='text/javascript'></script>";
echo "\n<script>";

elgg_load_js('LocationBook.mapiconmaker');
$startingLat = elgg_get_plugin_setting('defaultLat', 'LocationBook');
$startingLong = elgg_get_plugin_setting('defaultLong', 'LocationBook');
echo "\nvar startingLat = ";echo $startingLat;echo ";";
echo "\nvar startingLong = ";echo $startingLong;echo ";";
$defaultZoomLevel = elgg_get_plugin_setting('defaultZoomLevel', 'LocationBook');
echo "\nvar defaultZoomLevel = ";echo $defaultZoomLevel;echo ";";


$queryarr =  explode("?",$_SERVER['REQUEST_URI']);
if($queryarr[1])
 {
   if($_SESSION['filterq'] != $queryarr[1]) $_SESSION['filterq'] = $queryarr[1];
 }
$querysplit = explode("&",$_SESSION['filterq']);


$metaset = array();

foreach($querysplit as $q)
{
 $tm = explode("=",$q);

 if(($tm[0] != '') AND($tm[1] != 'Any'))
   $metaset[$tm[0]]=urldecode ($tm[1]);
} 

$loclist= elgg_get_entities(array(
	'type' => 'object',
	'subtype' => 'LocationObject',
	'limit' => '0',
));
$totalcount = 0;
echo "\nvar locations = [";
foreach($loclist as $locobj)
 {
 	foreach ($metaset as $key=>$value)
		{
		if($key == 'sitecategories') $key = universal_categories;
		//$body .= '<br> key ='; $body .= $key; $body .=" value =";$body .= $value;  
		if(is_array($locobj->$key)){ /*$body .=" aval =";$body .= implode(',',$locobj->$key);*/
			if(!in_array($value,$locobj->$key)) {/*$body .="  skipped <br>"; */continue 2;} }
		else {/*$body .=" val =";$body .=$locobj->$key;*/if($locobj->$key != $value){/*$body .="  skipped <br>"; */continue 2;}}
		}
	$title = 'untitled'; if(!empty($locobj->title))$title = $locobj->title;	
  echo "\n['";  echo $title; echo "',"; echo $locobj->lat;echo ",";echo $locobj->long; echo ",'";echo $locobj->getURL(); echo "'],";
  $totalcount++;
 }
echo "];";

?>


var newIcon = MapIconMaker.createMarkerIcon({width: 15, height: 20, primaryColor: "#0000FF", cornercolor:"#0000FF"});
var loclist = null;
window.onload = function() {
	if (GBrowserIsCompatible()){
	map = new GMap2 (document.getElementById("map_canvas"));
	map.addControl(new GLargeMapControl());
	map.addControl(new GMapTypeControl(3));
	map.setCenter( new GLatLng(startingLat,startingLong), defaultZoomLevel,0);	
	
    var tmpmarker, index;
    loclist = new Array();
    for (index = 0; index < locations.length; index++) {
	    var found = false;
		for (var i=0;i <loclist.length;i++)
		{
		 if ((locations[index][1] == loclist[i].point.lat()) && (locations[index][2] == loclist[i].point.lng()) )
		   {
			loclist[i].html +="<hr><a href='" + locations[index][3]+"'>"+locations[index][0]+"</a>";
				found = true;break;
		   }
		}
		if(found ==false)
           {
		    var locentry = new Object();
			locentry.point =  new GLatLng(locations[index][1], locations[index][2]);
			locentry.html = "<a href='" + locations[index][3]+"'>"+locations[index][0]+"</a>";
			loclist.push(locentry);
           }
    }
   for (i = 0; i < loclist.length; i++) {  
	 tmpmarker = new GMarker(loclist[i].point,{icon: newIcon});
	 map.addOverlay(tmpmarker);	 
	 	  
	 GEvent.addListener(tmpmarker,'click',(function(i) 
	  {
		return function() {
		map.openInfoWindowHtml(loclist[i].point, loclist[i].html);	    
		}
	  })(i));
	

    }		
				
	}
}	

</script>
<?php echo $totalcount ;  echo elgg_echo("Locationbook:Locations");?>
<br><div id='map_canvas' style='width: 700px; height: 700px'></div>
