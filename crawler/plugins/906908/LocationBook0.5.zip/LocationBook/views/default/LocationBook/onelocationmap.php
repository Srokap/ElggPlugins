<?php
echo "<script src='http://maps.google.com/maps?file=api&amp;v=2&amp;key=";
$googleKey = elgg_get_plugin_setting('googlekey', 'LocationBook');
echo $googleKey;
echo "' type='text/javascript'></script>";
echo "\n<script>";


echo "\nvar startingLat = ";echo $vars['lat'];echo ";";
echo "\nvar startingLong = ";echo $vars['long'];echo ";";
$defaultZoomLevel = elgg_get_plugin_setting('defaultZoomLevel', 'LocationBook');
echo "\nvar defaultZoomLevel = ";echo $defaultZoomLevel;echo ";";
?>

var marker;
window.onload = function() {
	if (GBrowserIsCompatible()){
		map = new GMap2 (document.getElementById("map_canvas"));
		map.addControl(new GLargeMapControl());
		map.addControl(new GMapTypeControl(3));
		map.setCenter( new GLatLng(startingLat,startingLong), defaultZoomLevel+8,0);	

        marker = new GMarker(new GLatLng(startingLat, startingLong));
		map.addOverlay(marker);
		GEvent.addListener(map,'click',function(overlay,point)
		{
			document.getElementById('lat').value = point.lat();
			document.getElementById('long').value = point.lng();		    
            marker.setLatLng(point);	
		});
	}
}	

</script>
<br><div id='map_canvas' style='width: 700px; height: 300px'></div>
