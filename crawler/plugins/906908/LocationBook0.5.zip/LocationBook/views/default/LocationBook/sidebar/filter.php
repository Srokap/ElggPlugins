
<?php
$queryarr =  explode("?",$_SERVER['REQUEST_URI']);

if($queryarr[1])
 {
   if($_SESSION['filterq'] != $queryarr[1]) $_SESSION['filterq'] = $queryarr[1];
 }

$querysplit = explode("&",$_SESSION['filterq']);

$queryset = array();
foreach($querysplit as $q)
{
 $tm = explode("=",$q);
 $queryset[$tm[0]] = $tm[1];
}

$any = array(0 => 'Any',);

$SitewideCategoriesFilter = elgg_get_plugin_setting('SitewideCategoriesFilter', 'LocationBook');
$SitewideCategories = elgg_get_plugin_setting('SitewideCategories', 'LocationBook');
$queryElements = "\nvar queryElements = [";
if( elgg_is_active_plugin('categories') AND ($SitewideCategoriesFilter == '1') AND ($SitewideCategories == '1'))
{
$filtercode = elgg_echo("Locationbook:category")."<br>";
$filtercode .=  elgg_view('input/dropdown',array( 'name' => 'sitecategories','id' => 'filtersitecategories','value' => $queryset[sitecategories],
'options'=> array_merge($any,elgg_get_site_entity()->categories) ,'onChange'=>'reloadpage()'));
$queryElements .= "'filtersitecategories',";

}
$FilterDetail = explode(",",elgg_get_plugin_setting('FilterDetail' , 'LocationBook')); 
$ChoiceData = explode(";",elgg_get_plugin_setting('ChoiceDetail' , 'LocationBook')); 

$ChoiceDetail = array();
foreach ($ChoiceData as $chunk) {
  $chunk = explode('=', $chunk);
  $ChoiceDetail[$chunk[0]] = $chunk[1];
}
foreach ($FilterDetail as $filter) {
     $filtercode.= '<br>';     $filtercode .= $filter;$filtercode .= '<br>';
  	if($ChoiceDetail[$filter])
	{
		  $choicestr =  $ChoiceDetail[$filter];	  
	  $choicearr = explode(":",$ChoiceDetail[$filter]); 	  
	  $choiceoptarr  =explode(",",$choicearr[1]); 
	   $filtercode .=  elgg_view('input/dropdown',array( 'name' => $filter,'id' => filter.$filter,'value' => $queryset[$filter],
	   'options'=> array_merge($any,$choiceoptarr) ,'onChange'=>'reloadpage()'));
	 $queryElements .= "'filter".$filter."',";
    }
}
echo '<script>';
echo $queryElements;

echo "];";
?>

function reloadpage()
{
var pageurl = document.URL.split("?")[0];
 var tt  = queryElements.length;

var qurl=''; 

for (i = 0; i < queryElements.length; i++)
  {
   if(qurl != '')qurl +="&"; 
   qurl += document.getElementById(queryElements[i]).name;
   qurl += "=";
   qurl += document.getElementById(queryElements[i]).value;
  }
if(qurl != '') 
  pageurl = pageurl +"?"+qurl;
  window.location = pageurl;

}
</script>
<?php
echo $filtercode;
?>