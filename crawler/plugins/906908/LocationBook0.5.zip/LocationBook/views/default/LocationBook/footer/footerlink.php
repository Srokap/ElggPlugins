<div class="mts float-alt">
<a href="http://humchale.in/" id='humchalefooter'><img src="<?php echo elgg_get_site_url(); ?>mod/LocationBook/views/default/LocationBook/footer/humchale.gif" alt="Hc" title="HumChale"/></a>
</div>