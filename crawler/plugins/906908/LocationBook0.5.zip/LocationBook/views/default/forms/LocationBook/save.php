

<?php
echo "<script src='http://maps.google.com/maps?file=api&amp;v=2&amp;key=";
$googleKey = elgg_get_plugin_setting('googlekey', 'LocationBook');
echo $googleKey;
echo "' type='text/javascript'></script>";
echo "\n<script>";

$locobj = $vars['entity'];
$startingLat = $locobj->lat;
$startingLong = $locobj->long;

$defaultZoomLevel = elgg_get_plugin_setting('defaultZoomLevel', 'LocationBook');
echo "\nvar Zoomdelta = 6;"; 
if(!$startingLat)
      {
        echo "\nZoomdelta = 0;";
        $startingLat = elgg_get_plugin_setting('defaultLat', 'LocationBook');
	$startingLong = elgg_get_plugin_setting('defaultLong', 'LocationBook');
      }
echo "\nvar defaultZoomLevel = ";echo $defaultZoomLevel;echo ";";

echo "\nvar startingLat = ";echo $startingLat;echo ";";
echo "\nvar startingLong = ";echo $startingLong;echo ";";
?>

var marker;
window.onload = function() {
	if (GBrowserIsCompatible()){
		map = new GMap2 (document.getElementById("map_canvas"));
		map.addControl(new GLargeMapControl());
		map.addControl(new GMapTypeControl(3));
		map.setCenter( new GLatLng(startingLat,startingLong), defaultZoomLevel+Zoomdelta ,0);

        marker = new GMarker(new GLatLng(startingLat, startingLong),{draggable: true});
		map.addOverlay(marker);
		//GEvent.addListener(map,'click',function(overlay,point) 		{
			//document.getElementById('lat').value = point.lat();
			//document.getElementById('long').value = point.lng();		    
            //marker.setLatLng(point);			});
		GEvent.addListener(marker,'dragend',function(overlay,point) 
		{
        	document.getElementById('lat').value =marker.getPoint().lat();
			document.getElementById('long').value = marker.getPoint().lng();		               
		});
	}
}	
function adjustMap()
{
count = document.getElementById('locfieldcount').value;

var searchstr='';
var zoomlevel = defaultZoomLevel;
for(var i=0; i<count; i++) {
var str  =document.getElementById('locfld'+i).value;
if(str !='')
  {
  searchstr += str+',';
  zoomlevel = defaultZoomLevel +2*i;
  }
}
var geocoder = new GClientGeocoder();

geocoder.getLatLng(
    searchstr,
    function(point) {
      if (!point) {
        alert(address + " not found");
      } else {
        map.setCenter(point, zoomlevel);
		marker.setLatLng(point);
		document.getElementById('lat').value = point.lat();
		document.getElementById('long').value = point.lng();
        //marker.openInfoWindow(document.createTextNode(searchstr));
      }
    }
  );
};
</script>

<?php

if ($vars['guid']) {
	echo elgg_view('input/hidden', array('name' => 'guid','value' => $vars['guid'],));
}
if ($vars['grpguid']) {
	echo elgg_view('input/hidden', array('name' => 'grpguid','value' => $vars['grpguid'],));
}
    echo "<label>".elgg_echo("Locationbook:Title")."</label>";
	echo elgg_view('input/text', array('name' => 'title','value' => $locobj->title,));

    
	echo "<label>".elgg_echo("Locationbook:Description")."</label>";
	echo elgg_view('input/longtext', array('name' => 'description','value' => $locobj->description,));
	$SitewideCategories = elgg_get_plugin_setting('SitewideCategories', 'LocationBook');
    if( $SitewideCategories == '1')
     {
       echo elgg_view('input/categories', $vars);
	 }
	 echo "<label>".elgg_echo("Locationbook:webURL")."</label>";
	
	echo elgg_view('input/text', array('name' => 'webURL','value' => $locobj->webURL,));

echo "<br>";
$ChoiceData = explode(";",elgg_get_plugin_setting('ChoiceDetail' , 'LocationBook')); 

$ChoiceDetail = array();
foreach ($ChoiceData as $chunk) {
  $chunk = explode('=', $chunk);
  $ChoiceDetail[$chunk[0]] = $chunk[1];
}

$ExtraFieldNames = explode(",",elgg_get_plugin_setting('ExtraFieldNames' , 'LocationBook')); 
$ExtraFieldSIZEs = explode(",",elgg_get_plugin_setting('ExtraFieldSIZEs' , 'LocationBook')); 

echo $locobj->extrafield[0];

for ($pos=0; $pos<count($ExtraFieldNames); $pos++)
{	
	echo "<label>".$ExtraFieldNames[$pos]."</label>";
	if($ChoiceDetail[$ExtraFieldNames[$pos]])
	{
	  $choicestr =  $ChoiceDetail[$ExtraFieldNames[$pos]];	  
	  $choicearr = explode(":",$ChoiceDetail[$ExtraFieldNames[$pos]]); 	  
	  $choiceoptarr  =explode(",",$choicearr[1]); 
      if($choicearr[0] == '1')
      {
	   echo elgg_view('input/checkboxes',array( 'name' => $ExtraFieldNames[$pos],'value' => $locobj->$ExtraFieldNames[$pos],
	   'options'=>array_combine($choiceoptarr, $choiceoptarr)  ,'align' => 'horizontal',));
       }	  
	  else
	   echo elgg_view('input/dropdown',array( 'name' => $ExtraFieldNames[$pos],'value' => $locobj->$ExtraFieldNames[$pos],
	   'options'=> $choiceoptarr ,));
	}
	else
	echo elgg_view('input/text', array('name' => $ExtraFieldNames[$pos],'value' => $locobj->$ExtraFieldNames[$pos],
	'style'=>'width: '.$ExtraFieldSIZEs[$pos].'px;'));

}

echo "<br><br>";
$LocationFieldNames = explode(",",elgg_get_plugin_setting('LocationFieldNames' , 'LocationBook')); 
$LocationFieldSIZEs = explode(",",elgg_get_plugin_setting('LocationFieldSIZEs' , 'LocationBook')); 

echo elgg_view('input/hidden', array('id' => 'locfieldcount','value' => count($LocationFieldNames),));
for ($pos=0; $pos<count($LocationFieldNames); $pos++)
{	
	echo "<label>".$LocationFieldNames[$pos]."</label>";
	if($ChoiceDetail[$LocationFieldNames[$pos]])
	{
	  $choicestr =  $ChoiceDetail[$LocationFieldNames[$pos]];	  
	  $choicearr = explode(":",$ChoiceDetail[$LocationFieldNames[$pos]]); 	  
	  $choiceoptarr  =explode(",",$choicearr[1]); 
	  echo elgg_view('input/dropdown',array( 'name' => $LocationFieldNames[$pos],'id' => locfld.$pos,'value' => $locobj->$LocationFieldNames[$pos],
	  'options'=> $choiceoptarr ,'onChange'=>'adjustMap()'));
	}
	else
	echo elgg_view('input/text', array('name' => $LocationFieldNames[$pos],'id' => locfld.$pos,'value' => $locobj->$LocationFieldNames[$pos],
	'style'=>'width: '.$LocationFieldSIZEs[$pos].'px;','onChange'=>'adjustMap()'));

}
echo "<br><br>";

echo elgg_view('input/text', array('name' => 'lat','id' => 'lat','value' => $locobj->lat,'style'=>'width: 200px; '));
echo elgg_view('input/text', array('name' => 'long','id' => 'long','value' => $locobj->long,'style'=>'width: 200px; '));

echo elgg_view('input/submit', array('value' => elgg_echo("Locationbook:Save")));
echo "<br><label>".elgg_echo("Locationbook:move the marker to adjust the location.")."</label>";
?>
	
<br><div id="map_canvas" style="width: 700px; height: 300px"></div>



