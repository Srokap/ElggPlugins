

<?php


$grpobj = $vars['entity'];


if ($vars['guid']) {
	echo elgg_view('input/hidden', array('name' => 'guid','value' => $vars['guid'],));
}

    echo "<label>".elgg_echo("Locationbook:Title")."</label>";
	echo elgg_view('input/text', array('name' => 'title','value' => $grpobj->title,));

    echo "<label>".elgg_echo("Locationbook:Description")."</label>";
	echo elgg_view('input/longtext', array('name' => 'description','value' => $grpobj->description,));
	$SitewideCategories = elgg_get_plugin_setting('SitewideCategories', 'LocationBook');
    if( $SitewideCategories == '1')
       echo elgg_view('input/categories', $vars);

	echo "<label>".elgg_echo("Locationbook:webURL")."</label>";
	echo elgg_view('input/text', array('name' => 'webURL','value' => $grpobj->webURL,));

echo "<br>";

echo "<br>";
$ChoiceData = explode(";",elgg_get_plugin_setting('ChoiceDetail' , 'LocationBook')); 

$ChoiceDetail = array();
foreach ($ChoiceData as $chunk) {
  $chunk = explode('=', $chunk);
  $ChoiceDetail[$chunk[0]] = $chunk[1];
}

$GrpFieldNames = explode(",",elgg_get_plugin_setting('GrpFieldNames' , 'LocationBook')); 
$GrpFieldSIZEs = explode(",",elgg_get_plugin_setting('GrpFieldSIZEs' , 'LocationBook')); 

echo $locobj->GrpField[0];

for ($pos=0; $pos<count($GrpFieldNames); $pos++)
{	
	
	echo "<label>".$GrpFieldNames[$pos]."</label>";
	if($ChoiceDetail[$GrpFieldNames[$pos]])
	{
	  $choicestr =  $ChoiceDetail[$GrpFieldNames[$pos]];	  
	  $choicearr = explode(":",$ChoiceDetail[$GrpFieldNames[$pos]]); 	  
	  $choiceoptarr  =explode(",",$choicearr[1]); 
      if($choicearr[0] == '1')
      {
	   echo elgg_view('input/checkboxes',array( 'name' => $GrpFieldNames[$pos],'value' => $locobj->$GrpFieldNames[$pos],
	   'options'=>array_combine($choiceoptarr, $choiceoptarr)  ,'align' => 'horizontal',));
       }	  
	  else
	   echo elgg_view('input/dropdown',array( 'name' => $GrpFieldNames[$pos],'value' => $locobj->$GrpFieldNames[$pos],
	   'options'=> $choiceoptarr ,));
	}
	else
	echo elgg_view('input/text', array('name' => $GrpFieldNames[$pos],'value' => $locobj->$GrpFieldNames[$pos],
	'style'=>'width: '.$GrpFieldSIZEs[$pos].'px;'));

}
echo elgg_view('input/submit', array('value' => elgg_echo("Locationbook:Save")));
?>
<br><div id="map_canvas" style="width: 700px; height: 300px"></div>



