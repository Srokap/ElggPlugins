<?php
/**
 * Blog English language file.
 *
 */

$english = array(
    //Main Page
    'Locationbook:Locations' =>' Locations',	
	'Locationbook:List' =>'List',
	'Locationbook:Map' =>'Map',
	'Locationbook:Group' =>'Group',
	'Locationbook:Search' =>'Search',
	'Locationbook:All' =>'All',
	//Filter
	'Locationbook:category' =>'category',
	//Edit
	'Locationbook:Create Entry' =>'Create Entry',
	'Locationbook:Create Group' =>'Create Group',
	'Locationbook:AllGroups' =>'AllGroups',
	'Locationbook:Create Location' =>'Create Location in this Group',
	'Locationbook:Create a new Location Group' =>'Create a new Location Group',
	//Add	
	'Locationbook:Create a new location' =>'Create a new location',
	'Locationbook:Title' =>'Title',
	'Locationbook:Description' =>'Description',
	'Locationbook:webURL' =>'webURL',
	'Locationbook:Categories' =>'Categories',
	'Locationbook:Save' =>'Save',
	'Locationbook:move the marker to adjust the location.' =>'move the marker to adjust the location.',
	 //Edit 
     'Locationbook:Edit Location Entry' =>'Edit Location Entry',
	 'Locationbook:Edit Location Group' =>'Edit Location Group',
	 
    //message
	'Locationbook:deleted successfully' =>'deleted successfully',
	'Locationbook:insufficient permisson' =>'insufficient permisson',
	'Locationbook:Location is saved' =>'Location is saved',
	'Locationbook:new Location is created' =>'new Location is created',
	'Locationbook:new Location Group is created' =>'new Location Group is created',
	'Locationbook:Location Group is saved' =>'Location Group is saved',
	
	
	'Locationbook:you dont have rights to edit' =>'you dont have rights to edit',
	
        //support for site wide search
	'item:object:LocationObject' => 'Locations',
	'item:object:LocationGrp' => 'LocationGroups',
         //support for river comment.
	'river:comment:object:LocationObject' => '%s commented on a Location %s',
	'river:comment:object:LocationGrp' => '%s commented on a LocationGroup %s',
);

add_translation('en', $english);
