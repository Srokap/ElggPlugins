<?php
		function splash_init() 
		{
		global $CONFIG;
		add_menu(elgg_echo('splash'), $CONFIG->wwwroot . "mod/splash");
		}
		
	register_elgg_event_handler('init','system','splash_init');

?>