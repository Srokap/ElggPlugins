<div class="contentWrapper">
<div align="left">

<?php
echo "<iframe src='$CONFIG->wwwroot/mod/splash/splash/splash.swf"."' width='900' height='466' frameborder='0' ></iframe>";
?>


</div>
</div>