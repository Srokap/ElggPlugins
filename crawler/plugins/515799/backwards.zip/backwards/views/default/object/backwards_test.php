<?php
$obj = $vars['entity'];
$tags = $obj->tag;
if (is_array($tags)) {
	$tags = implode(', ',$tags);
}
$body = <<<END
<tr>
<td>{$obj->guid}</td>
<td>{$obj->metadata_integer1}</td>
<td>{$obj->metadata_integer2}</td>
<td>{$obj->metadata_text1}</td>
<td>{$obj->metadata_text2}</td>
<td>{$tags}</td>
</tr>
END;

echo $body;