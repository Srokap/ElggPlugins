<?php
if (!function_exists('elgg_get_entities')) {
	require_once(dirname(__FILE__) . "/models/model.php");
}
?>