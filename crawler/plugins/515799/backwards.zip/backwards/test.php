<?php

// Load Elgg engine
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

$options = array('type'=>'object','subtype'=>'backwards_test',
	'metadata_name_value_pairs'=>array(array('name'=>'tag','value'=>array('four','two'),'operand'=> 'IN')),
	'limit'=>20,
	'order_by_metadata'=>array(
		array('name'=>'metadata_text1','direction'=>'DESC','as'=>'text'),
		array('name'=>'metadata_integer2','direction'=>'ASC','as'=>'integer')
	)
);

/*$options = array('type'=>'object','subtype'=>'backwards_test',
	'metadata_name'=>'tag','metadata_values'=>array('four','two'),'limit'=>20,
	'order_by_metadata'=>array(
		array('name'=>'metadata_integer1','as'=>'text'),
		array('name'=>'metadata_integer2','direction'=>'ASC','as'=>'integer')
	)
);*/
$entities = elgg_get_entities_from_metadata($options);
$body = '';
if ($entities) {
	foreach($entities as $entity) {
		$body .= elgg_view('object/backwards_test',array('entity'=>$entity));
	}
}

$body = <<<END
<table border="1">
<tr>
<td>guid</td>
<td>metadata_integer1</td>
<td>metadata_integer2</td>
<td>metadata_text1</td>
<td>metadata_text2</td>
<td>tags</td>
</tr>
$body
</table>
END;

$body = elgg_view_layout("two_column_left_sidebar", '', $body);
page_draw("Test",$body);
?>