<?php
function nopublic_init() {

}

register_elgg_event_handler('init','system','nopublic_init');
?>