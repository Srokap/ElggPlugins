<?php
// Note: This file is included from the library/Framework/Framework.Control.Filler.php
// class for "People" pages.

echo '<div class="SiteContainer '.$this->Properties['CssClass'].'">
	<h1>'.$this->Context->Configuration['BANNER_TITLE'].'</h1>';
?>