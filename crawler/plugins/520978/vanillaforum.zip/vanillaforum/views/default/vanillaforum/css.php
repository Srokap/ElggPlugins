/* ***************************************
    VanillaForum river entries
*************************************** */
.river_object_vanillaforum_notify_create {
    background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_comment.gif) no-repeat left -1px;   
} 