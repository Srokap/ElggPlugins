<?php

/* Be Tom - Elgg plugin to automatically add the user you specify as friends with every new user that registers on your site.
 * 
 * Instructions:
 * *************
 * 1) Find the GUID for the user you want to be Tom.
 *     If you don't know how a simple way is to look at any of 
 *     the action links on their profile and in the link there will
 *     be a part where it says guid=123. 123 is what you want.
 * 2) Put that GUID below in the $BE_TOM_FRIEND_GUID = 2; line
 * 3) Decide if you want to get emails when people join and become your friend automatically.
 *     By default this is set to not allow the emails to get sent out.
 *     To change it look below for $i_want_emails = false; and make it $i_want_emails = true;
 *
 * And of course check out my Elgg blog for updates, mods, and articles about setting my own Elgg based site up.
 * Blog: http://www.addicted2kicks.com/devblog/
 * Elgg Site: http://www.addicted2kicks.com/
 *
 * Version 1.1 - Zac
 * (version 1.1 fixes an issue where it works with the latest svn version, but not the 'stable' 1.0 release)
 * It's a low priority, but a future todo item will be a page in the admin interface to allow you to 
 * configure this plugin easily w/o messing with code. It's a very low priority, but if there is a lot
 * of interest I will start on it.
 */
	
function betom_init(){
	global $CONFIG;
	register_elgg_event_handler('create', 'user', 'AutoAddFriend',501);
}

function AutoAddFriend($event, $object_type, $object){
	$host = 'localhost';
	$username = '';
	$password = '';
	$database = '';
	mysql_connect($host,$username,$password) or die ("Problem connecting to DataBase");
	
	$getFriendsIds = "SELECT guid FROM elggusers_entity ORDER BY guid DESC";
	$getFriendsIdsResult = mysql_db_query($database,$getFriendsIds) or die ( "Query failed: " . mysql_error() . " please inform admin!" );
	
	$addToFriends = "INSERT INTO elggentity_relationships (guid_one,relationship,guid_two) VALUES";
	$i=0;
	while ($row = mysql_fetch_array($getFriendsIdsResult))
	{
		$BE_TOM_FRIEND_GUID = $row['guid'];	//HEY YOU - REPLACE THE GUID # HERE WITH THE ONE YOU WANT!
		if (!isset($user))
		{
			$user = $BE_TOM_FRIEND_GUID;
		}
		if ($i > 0)
		{
			$addToFriends .= ", (".$BE_TOM_FRIEND_GUID.",'friend',".$user.")";
		}
		else
		{
			$addToFriends .= " (".$BE_TOM_FRIEND_GUID.",'friend',".$user.")";
		}
		$i++;
		
		global $CONFIG;
		
		//Version 1.1 - The current 1.0 version of Elgg doesn't populate the $_SESSION var (log the user in)
		// Versions in SVN right now apparently do...
		// Now we will try to use the $object passed to us instead...
		
		if (($object instanceof ElggUser) && ($event == 'create') && ($object_type == 'user')) {
			if($friend = get_entity($BE_TOM_FRIEND_GUID)) {
				//READ ME: If you want your 'Tom' to receive emails every time someone registers (it'll be the friend added email) then you
				//need to set the below variable to true instead of false.
				
				//IMPORTANT: If you are using my friend request plugin (or any other mod that catches and modifies the friend created event
				//then you will MUST leave this as false!!!
				$i_want_emails = false;
				
				if(!$i_want_emails) {
					//The engine/lib/relationships.php file would usually catch the friend created event and send an email to our Tom.
					//This will prevent that by removing any hooks that would handle the friend created event.
					//This will also stop any other plugins from interfering with our friend add process (say a friend request plugin)
					if(isset($CONFIG->events['create']['friend'])) {
						$oldEventHander = $CONFIG->events['create']['friend'];
						$CONFIG->events['create']['friend'] = array();			//Removes any event handlers
					}
				}
				
				try {
					$object->addFriend($BE_TOM_FRIEND_GUID);
				} catch (Exception $e) {
				}
				
				//If we disabled any events below then reenable them:
				if(!$i_want_emails) {
					if(isset($CONFIG->events['create']['friend'])) {
						$CONFIG->events['create']['friend'] = $oldEventHander;
					}
				}
			}
		}
		
	}
	$addToFriendsResult = mysql_db_query($database,$addToFriends) or die ( "Query failed: " . mysql_error() . " please inform admin!" );
	return true;
}



register_elgg_event_handler('init', 'system', 'betom_init');

?>