<?php
	$host = 'localhost';
	$username = '';
	$password = '';
	$database = '';
	mysql_connect($host,$username,$password) or die ("Problem connecting to DataBase");
	$deleteRelationships = "DELETE FROM elggentity_relationships WHERE relationship='friend'";
	$deleteRelationshipsResult = mysql_db_query($database,$deleteRelationships) or die ( "Query failed: " . mysql_error() . " please inform admin!" );
	$getFriendsIds = "SELECT guid FROM elggusers_entity ORDER BY guid DESC";
	$getFriendsIdsResult = mysql_db_query($database,$getFriendsIds) or die ( "Query failed: " . mysql_error() . " please inform admin!" );
	$getFriendsIdsResult2 = mysql_db_query($database,$getFriendsIds) or die ( "Query failed: " . mysql_error() . " please inform admin!" );
	
	$addToFriends = "INSERT INTO elggentity_relationships (guid_one,relationship,guid_two) VALUES";
	$i=0;
	$j=0;
	while ($row = mysql_fetch_array($getFriendsIdsResult))
	{
		$guid = $row['guid'];
		$BE_TOM_FRIEND_GUID[$j] = $row['guid'];
		$j++;
	}
		while ($row2 = mysql_fetch_array($getFriendsIdsResult2))
		{
			foreach ($BE_TOM_FRIEND_GUID as $value)
			{
				$user = $row2['guid'];
				if ($value!==$user)
				{
				if ($i > 0)
				{
					$addToFriends .= ", (".$value.",'friend',".$user.")";
				}
				else
				{
					$addToFriends .= " (".$value.",'friend',".$user.")";
				}
				$i++;
				}
			}
		}
	$addToFriendsResult = mysql_db_query($database,$addToFriends) or die ( "Query failed: " . mysql_error() . " please inform admin!" );
	echo 'Done';
?>