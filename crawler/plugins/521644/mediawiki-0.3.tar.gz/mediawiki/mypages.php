<?php


  // Load Elgg engine
    require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
		
global $CONFIG, $SESSION;

gatekeeper();

$callback = get_input('callback');
$offset = get_input('offset', 0);

$user = get_user_by_username(get_input('user'));
if ($user) {
    $name = $user->name . "'s";
} else {
    $user = get_loggedin_user();
    $name = 'My';
}
    
$limit = 10;

$area2 = elgg_view_title($name . ' recent ' . get_plugin_setting('mwtitle', 'mediawiki') . ' page contributions');

if ($callback) {
    // render and show the page

    $pages = mediawiki_get_pages_for_user($user);

    /*
    $content = '<ul>';

    foreach ($pages as $page) {
	$content .= '<li><a href="' . mediawiki_get_url('localwikiroot') . mediawiki_encode($page) . '">' . $page . '</a></li>';
    }

    $content .= '</ul>';
  

    echo elgg_view('page_elements/contentwrapper', array('body' => $content));
    */

    $count = count($pages);

    usort($pages, mediawiki_page_sort);

    $display = array_slice($pages, $offset, $limit);

    $context = get_context();
			
    $html = elgg_view('entities/entity_list',array('entities' => $display,
						 'count' => $count,
						 'offset' => $offset,
						 'limit' => $limit,
						 'baseurl' => $CONFIG->wwwroot . 'mod/mediawiki/mypages.php?user=' . $user->username, // so we don't get the callback=true tacked on
						 'fullview' => true,
						 'context' => $context, 
						 'viewtypetoggle' => true,
						 'viewtype' => get_input('search_viewtype','list'), 
						 'pagination' => true
						 ));
				
    // it's the callback, draw the content
    echo $html;

} else {
    // draw the waiting loop

    $area2 .= '<div id="mediawikicontent">';
    $area2 .= elgg_view('ajax/loader');
    $area2 .= '</div>';
    
    $area2 .= "\n\n";

    $area2 .= '<script type="text/javascript">
$(document).ready(function() {

	$("#mediawikicontent").load("' . $CONFIG->wwwroot . 'mod/mediawiki/mypages.php?user=' . $user->username . '&callback=true&offset=' . $offset . '");


});
</script>';



    $body = elgg_view_layout('two_column_left_sidebar', $area1, $area2);

    page_draw($name . ' recent ' . get_plugin_setting('mwtitle', 'mediawiki') . ' page contributions', $body);

}

?>
