<?php


  // Load Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
		
global $CONFIG, $SESSION;

$pt = get_input('pageTitle');
$pageTitle = mediawiki_get_redirects($pt);

$callback = get_input('callback');

$area2 = elgg_view_title($pageTitle);

if ($callback) {
    // render and show the page
    $content = elgg_view('mediawiki/viewpage', array('pageTitle' => $pageTitle));
  
    echo elgg_view('page_elements/contentwrapper', array('body' => $content));
} else {
    // draw the waiting loop

    $area2 .= '<div id="mediawikicontent">';
    $area2 .= elgg_view('ajax/loader');
    $area2 .= '</div>';
    
    $area2 .= "\n\n";

    $area2 .= '<script type="text/javascript">
$(document).ready(function() {

	$("#mediawikicontent").load("' . $CONFIG->wwwroot . 'mod/mediawiki/view.php?pageTitle=' . $pt . '&callback=true");


});
</script>';



    $body = elgg_view_layout('two_column_left_sidebar', $area1, $area2);

    page_draw($pageTitle, $body);

}

?>
