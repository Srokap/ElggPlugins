<?php

global $CONFIG;

$page = $vars['entity'];


if ($page->new) {
	$icon = '<img src="' . $CONFIG->wwwroot . 'mod/mediawiki/graphics/icons/mediawikipagenew.png' . '" alt="New MediaWiki page" title="New MediaWiki page" />';
} else {
	$icon = '<img src="' . $CONFIG->wwwroot . 'mod/mediawiki/graphics/icons/mediawikipage.png' . '" alt="MediaWiki page" title="MediaWiki page" />';
}

$content = '<a href="' . mediawiki_get_url('localwikiroot') . mediawiki_encode($page->title) . '">' . $page->title . '</a>';
$content .= "<br />\n";

$user = get_user_by_username($page->user);

if ($user) {
	// if it's a real user, go to their profile page
	$usertxt = '<a href="' . $user->getURL() . '">' . $user->name . '</a>';
} else {
	// if it's not a real user, go to their mediawiki page
	$usertxt = '<a href="' . mediawiki_get_url('localwikiroot') . 'User:' . $page->user . '">' . $page->user . '</a>';
}

$time = friendly_time($page->timestamp);

if ($page->comment) {
	$comment = ' (' . $page->comment .')';
} else {
	$comment = '';
}

if ($page->new) {
	$content .= 'Created ' . $time . ' by ' . $usertxt . $comment;
} else {
	$content .= 'Updated ' . $time . ' by ' . $usertxt . $comment;
}

echo elgg_view_listing($icon, $content);

?>