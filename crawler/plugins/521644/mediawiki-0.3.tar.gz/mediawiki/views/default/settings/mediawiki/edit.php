<?php

$mwIndex = $vars['entity']->index;
$mwApi = $vars['entity']->api;
$mwTitle = $vars['entity']->mwtitle;

echo "MediaWiki Server URL (like 'http://wiki.myplace.org'): ";
echo elgg_view('input/text', array('internalname' => 'params[url]',
				   'value' => $vars['entity']->url,
				   'class' => ' ',
				   ));
echo "<br />\n";
echo "API (like '/api.php'):";
echo elgg_view('input/text', array('internalname' => 'params[api]',
				   'value' => $vars['entity']->api,
				   'class' => ' ',
				   ));
echo "<br />\n";
echo "Index (like '/index.php'):";
echo elgg_view('input/text', array('internalname' => 'params[index]',
				   'value' => $vars['entity']->index,
				   'class' => ' ',
				   ));
echo "<br />\n";
echo "Wiki root (like '/wiki/' or '/index.php/'):";
echo elgg_view('input/text', array('internalname' => 'params[wikiroot]',
				   'value' => $vars['entity']->wikiroot,
				   'class' => ' ',
				   ));
echo "<br />\n";
echo "Media root (for images, like '/'):";
echo elgg_view('input/text', array('internalname' => 'params[mediaroot]',
				   'value' => $vars['entity']->mediaroot,
				   'class' => ' ',
				   ));
echo "<br />\n";
echo "Wiki name (like 'My Wiki'):";
echo elgg_view('input/text', array('internalname' => 'params[mwtitle]',
				   'value' => $vars['entity']->mwtitle,
				   'class' => ' ',
				   ));

?>