<?php

global $CONFIG;

$limit = $vars['entity']->limit;
$offset = 0;

$user = get_entity(page_owner());

if (!$limit) {
  $limit = 10;
}

$pages = mediawiki_get_pages_for_user($user);

$count = count($pages);

usort($pages, mediawiki_page_sort);

$display = array_slice($pages, $offset, $limit);

$context = get_context();
			
$html = elgg_view_entity_list($display, $count, $offset, $limit, true, false, false);

echo $html;

echo elgg_view('page_elements/contentwrapper', array('body' => '<a href="' . $CONFIG->wwwroot . 'mod/mediawiki/mypages.php?user=' . $user->username . '">All recent contributions...</a>'));

?>