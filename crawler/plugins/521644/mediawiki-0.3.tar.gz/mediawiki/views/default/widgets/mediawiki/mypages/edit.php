<?php

if (!$vars['entity']->limit) {
  $vars['entity']->limit = 5;
}
?>
<p>Maximum Pages to Display
        <select name="params[limit]">
		    <option value="1" <?php if($vars['entity']->limit == 1) echo 'selected="selected"'; ?>>1</option>
		    <option value="2" <?php if($vars['entity']->limit == 2) echo 'selected="selected"'; ?>>2</option>
		    <option value="3" <?php if($vars['entity']->limit == 3) echo 'selected="selected"'; ?>>3</option>
		    <option value="4" <?php if($vars['entity']->limit == 4) echo 'selected="selected"'; ?>>4</option>
		    <option value="5" <?php if($vars['entity']->limit == 5) echo 'selected="selected"'; ?>>5</option>
		    <option value="6" <?php if($vars['entity']->limit == 6) echo 'selected="selected"'; ?>>6</option>
		    <option value="7" <?php if($vars['entity']->limit == 7) echo 'selected="selected"'; ?>>7</option>
		    <option value="8" <?php if($vars['entity']->limit == 8) echo 'selected="selected"'; ?>>8</option>
		    <option value="9" <?php if($vars['entity']->limit == 9) echo 'selected="selected"'; ?>>9</option>
		    <option value="10" <?php if($vars['entity']->limit == 10) echo 'selected="selected"'; ?>>10</option>
	</select>
</p>