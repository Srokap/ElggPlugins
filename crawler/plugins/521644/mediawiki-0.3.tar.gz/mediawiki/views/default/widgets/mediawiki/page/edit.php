<?php

echo "MediaWiki Title: ";
echo elgg_view('input/text', array('internalname' => 'params[pagename]',
				   'value' => $vars['entity']->pagename,
				   'class' => ' ',
				   ));
?>