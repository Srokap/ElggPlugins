<?php

global $CONFIG;

if ($vars['entity']->pagename) {

  $pageTitle = mediawiki_get_redirects($vars['entity']->pagename);

  $content = elgg_view('mediawiki/viewpage', array('pageTitle' => $pageTitle));

  echo elgg_view_title($pageTitle);

  echo elgg_view('page_elements/contentwrapper', array('body' => $content, 'subclass' => 'mediawiki-widget'));

  echo elgg_view('page_elements/contentwrapper', array('body' => '<a href="' . $CONFIG->wwwroot . 'mod/mediawiki/view.php?pageTitle=' . mediawiki_encode($pageTitle) . '">View full page...</a>'));

} else {
  $content = 'To include a wiki page, edit the settings for this widget and add a page title.';

  echo elgg_view('page_elements/contentwrapper', array('body' => $content));
}

//echo elgg_view('page_elements/contentwrapper', array('body' => $content, 'subclass' => 'mediawik-widget'));

?>