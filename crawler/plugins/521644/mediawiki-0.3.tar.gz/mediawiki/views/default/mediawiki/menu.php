<?php
if (isloggedin()) {

	$mwTitle = get_plugin_setting('mwtitle', 'mediawiki');

	if ($vars['entity'] != get_loggedin_user()) {
		$args = '?user=' . $vars['entity']->username;
	} else {
		$args = '';
	}

?>
	<p class="user_menu_profile">
		<a href="<?php echo $vars['url']; ?>mod/mediawiki/mypages.php<?php echo $args; ?>">
		<?php echo $mwTitle; ?> Pages</a>
	</p>
<?php
}
?>