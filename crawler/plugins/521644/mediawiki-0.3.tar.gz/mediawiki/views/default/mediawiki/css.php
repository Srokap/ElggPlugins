/*************/
/* Mediawiki */
/*************/

.mediawiki-widget {

max-height: 25em;
overflow: scroll;

}

/*****************/
/* End Mediawiki */
/*****************/