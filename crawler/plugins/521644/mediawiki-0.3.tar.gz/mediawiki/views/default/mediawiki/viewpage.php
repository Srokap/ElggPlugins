<?php

  // really simple: render the content of the page, then print it out

echo mediawiki_get_rendered_page($vars['pageTitle']);

?>