<?php

function mediawiki_init() {        

	global $CONFIG;

	$mwTitle = get_plugin_setting('mwtitle', 'mediawiki');

	// add submenu options
	if (get_context() == "mediawiki" || get_context() == "wiki") {
		$pt = get_input('pageTitle');
		if ($pt) {
			//add_submenu_item("Edit this page", $CONFIG->wwwroot . 'mod/mediawiki/edit.php?pageTitle=' . $pt, 'wiki');
			add_submenu_item("View this page on " . $mwTitle, mediawiki_get_url('wikiroot') . $pt, 'wiki');
			add_submenu_item("Edit this page on " . $mwTitle, mediawiki_get_url('index') . '?title=' . $pt . '&action=edit', 'wiki');
		}
		add_submenu_item($mwTitle . ' Main Page', mediawiki_get_url('localwikiroot'));
		add_submenu_item('My recent ' . $mwTitle . ' pages', $CONFIG->wwwroot . 'mod/mediawiki/mypages.php');
		add_submenu_item("My friends' recent " . $mwTitle . ' pages', $CONFIG->wwwroot . 'mod/mediawiki/friendspages.php');
		add_submenu_item('Recent ' . $mwTitle . ' changes', $CONFIG->wwwroot . 'mod/mediawiki/recentchanges.php');
	}

	add_menu($mwTitle, $CONFIG->wwwroot . 'mod/mediawiki/mypages.php');

	extend_view('profile/menu/links', 'mediawiki/menu');
	extend_view('profile/menu/linksownpage', 'mediawiki/menu');

	extend_view('css', 'mediawiki/css');

	add_widget_type('mediawiki/page', $mwTitle . ' Page', $mwTitle . ' page view');
	add_widget_type('mediawiki/mypages', 'My ' . $mwTitle . ' Pages', 'My recent ' . $mwTitle . ' page contributions');

	register_page_handler('wiki', 'mediawiki_page_handler');

	run_function_once('mediawiki_run_once');

}

function mediawiki_run_once() {
	add_subtype('object', 'mediawikipage');
}

function mediawiki_get_url($urlType) {
	global $CONFIG;
	switch($urlType) {
	case 'api':
		return get_plugin_setting('url', 'mediawiki') . get_plugin_setting('api', 'mediawiki');
	case 'index':
		return get_plugin_setting('url', 'mediawiki') . get_plugin_setting('index', 'mediawiki');
	case 'wikiroot':
		return get_plugin_setting('url', 'mediawiki') . get_plugin_setting('wikiroot', 'mediawiki');
	case 'mediaroot':
		return get_plugin_setting('url', 'mediawiki') . get_plugin_setting('mediaroot', 'mediawiki');
	case 'localwikiroot':
		//return $CONFIG->wwwroot . 'pg/wiki/';
		return $CONFIG->wwwroot . 'mod/mediawiki/view.php?pageTitle=';
	default:
		return null;
	}    

}

function mediawiki_page_handler($page) {
	global $CONFIG;

	// re-join the page title since mediawiki pages can have slashes in them
	$pageTitle = implode($page, '/');
	set_input('pageTitle', $pageTitle);
  
	include($CONFIG->pluginspath . 'mediawiki/view.php');
    
}

function mediawiki_get_redirects($request_title) {

	$page_title = $request_title;

	$url = mediawiki_get_url('api') . '?action=query&titles=' . mediawiki_encode($request_title) . '&redirects&format=xml';

	//print $url;
  
	$doc = url_getter_getDoc($url);
  
	$pages = $doc->getElementsByTagName('page');
	$pgNode = $pages->item(0);
  
	// this handles normalization and redirects for us
	if ($pgNode) {
		$real_page_title = $pgNode->getAttribute('title'); // we only care about the first page
    
		if ($request_title != $real_page_title) {
			//print 'REDIRECT! to: ' . $real_page_title;
			//die();
			$page_title = $real_page_title;
		}
	}

	return $page_title;

}

function mediawiki_get_rendered_page($page_title) {

	$url = mediawiki_get_url('index') . '?title=' . mediawiki_encode($page_title) . '&action=render';
	$html = url_getter_getUrl($url);

	
	// TODO: use an actual parser and root instead of the string replace

	//$doc = new DOMDocument();
	//$doc->loadXML('<root/>');
	//$frag = $doc->createDocumentFragment();
	//if ($frag->appendXML($html)) {
	//	print 'LOADED!';
	//} else {
	//	print 'NOT LOADED :(';
	//}
	//$doc->documentElement->appendChild($frag);
	//$doc->loadHTML($html);
	//$anchors = $doc->getElementsByTagName('a');
	//print $doc->saveXML();

	// transform the document


	// move links
	//$links = $doc->getElementsByTagName('
	


	// move links over
	$html = str_replace('href="' . mediawiki_get_url('wikiroot'), 'href="' . mediawiki_get_url('localwikiroot'), $html);
	$html = str_replace('href="/', 'href="' . mediawiki_get_url('wikiroot'), $html);
	// move image sources ... later TODO: JR
	$html = str_replace('src="' . mediawiki_get_url('wikiroot'), 'src="' . mediawiki_get_url('localwikiroot'), $html);
	$html = str_replace('src="/', 'src="' . mediawiki_get_url('mediaroot'), $html);


	$body = '<!-- Begin MediaWiki content -->';

	$body .= $html;
	
	$body .= '<!-- End MediaWiki content -->';

	return $body;

}

function mediawiki_get_pages_for_user($user, $limit = 100) {

	$username = $user->username;

	$url = mediawiki_get_url('api') . '?format=xml&action=query&list=usercontribs&uclimit=' . $limit . '&ucuser=' . urlencode($username);
  
	$doc = url_getter_getDoc($url);

	$items = $doc->getElementsByTagName('item'); // get all 'item' tags and pluck off the parts we care about

	return mediawiki_create_page_entities_from_list($items);

}

function mediawiki_get_recent_changes($limit = 100) {
  
	$url = mediawiki_get_url('api') . '?format=xml&action=query&list=recentchanges&rcprop=title|timestamp|ids|user|comment&rclimit=' . $limit;

	$doc = url_getter_getDoc($url);

	$items = $doc->getElementsByTagName('rc');

	return mediawiki_create_page_entities_from_list($items, true);

}

function mediawiki_create_page_entities_from_list($items, $dups = false) {
	$pages = array();

	foreach ($items as $item) {

		// we either allow dupes entirely or we check if the pageid has already been seen
		// TODO: that didn't work due to the pageid keying we're using below, bail for now

		if (!array_key_exists($item->getAttribute('pageid'), $pages)) {

			$ent = new ElggObject();
			$ent->subtype = 'mediawikipage';
      
			$user = get_user_by_username($item->getAttribute('user'));
			if ($user) {
				$ent->owner_guid = $user->getGUID();
			}
			$ent->user = strtolower($item->getAttribute('user'));
			$ent->title = $item->getAttribute('title');
			$ent->timestamp = strtotime($item->getAttribute('timestamp'));
			$ent->comment = $item->getAttribute('comment');
			if ($item->hasAttribute('new') || 
			    ($item->hasAttribute('old_revid') && $item->getAttribute('old_revid') == '0')) {
				$ent->new = true;
			}
			$ent->pageid = $item->getAttribute('pageid');
			$ent->revid = $item->getAttribute('revid');

			$pages[$item->getAttribute('pageid')] = $ent;
		}
	}


	return $pages;
}

function mediawiki_encode($str) {
	return urlencode(strtr($str, ' ', '_'));
}

// compare two pages		 
function mediawiki_page_sort($page1, $page2) {
	if ($page1->timestamp < $page2->timestamp) {
		// page1 is older
		return 1;
	} else if ($page1->timestamp > $page2->timestamp) {
		// page1 is newer
		return -1;
	} else {
		return 0;
	}
}

register_elgg_event_handler('init','system','mediawiki_init');       

?>
