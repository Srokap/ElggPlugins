<?php

	/* Elgg 174test template */
	
	
	/* Initialise the theme */
	function isprofile_init(){
		global $CONFIG;

		// Extend system CSS with our own styles, which are defined in the isprofile/css view
		elgg_extend_view('css', 'isprofile/css');

	}
	
	// Initialise log browser
	register_elgg_event_handler('init','system','isprofile_init');
	
?>
