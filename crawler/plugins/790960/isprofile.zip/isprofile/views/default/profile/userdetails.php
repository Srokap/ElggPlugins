<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/tab_navigator/vendors/tabber/tabber.js"></script>

<link rel="stylesheet" href="<?php echo $vars['url']; ?>mod/tab_navigator/vendors/tabber/example.css" TYPE="text/css" MEDIA="screen">
<link rel="stylesheet" href="<?php echo $vars['url']; ?>mod/tab_navigator/vendors/tabber/example-print.css" TYPE="text/css" MEDIA="print">

<script type="text/javascript">

	/* Optional: Temporarily hide the "tabber" class so it does not "flash"
	   on the page as plain HTML. After tabber runs, the class is changed
	   to "tabberlive" and it will appear.
	   */
	document.write('<style type="text/css">.tabber{display:none;}<\/style>');
</script>


	<?php

	// Simple XFN
	$rel_type = "";
	if (get_loggedin_userid() == $vars['entity']->guid) {
		$rel_type = 'me';
	} elseif (check_entity_relationship(get_loggedin_userid(), 'friend', $vars['entity']->guid)) {
		$rel_type = 'friend';
	}

	if ($rel_type) {
		$rel = "rel=\"$rel_type\"";
	}


	//insert a view that can be extended
	//echo elgg_view("profile/status", array("entity" => $vars['entity']));

		if ($vars['full'] == true) {

	?>
<?php

	/**
	 * Elgg user display (details)
	 *
	 * @package ElggProfile
	 *
	 * @uses $vars['entity'] The user entity
	 */

	if ($vars['full'] == true) {
		$iconsize = "large";
	} else {
		$iconsize = "medium";
	}

	// wrap all profile info
	echo "<div id=\"profile_info\">";

?>

<table cellspacing="0">
<tr>
<td style="border-right: 1px solid #cccccc;">

<?php

	// wrap the icon and links in a div
	echo "<div id=\"profile_info_column_left\">";

	echo "<div id=\"profile_icon_wrapper\">";
	// get the user's main profile picture
	echo elgg_view(
						"profile/icon", array(
												'entity' => $vars['entity'],
												//'align' => "left",
												'size' => $iconsize,
												'override' => true,
											)
					);


	echo "</div>";
	echo "<div class=\"clearfloat\"></div>";
	// display relevant links
	echo elgg_view("profile/profilelinks", array("entity" => $vars['entity']));

	// close profile_info_column_left
	echo "</div>";

?>


	<div id="profile_info_column_middle" >




	<?php
		$even_odd = null;

		if (is_array($vars['config']->profile) && sizeof($vars['config']->profile) > 0)
			foreach($vars['config']->profile as $shortname => $valtype) {
				if ($shortname != "description") {
					$value = $vars['entity']->$shortname;
					if (!empty($value)) {

						//This function controls the alternating class
						$even_odd = ( 'odd' != $even_odd ) ? 'odd' : 'even';

						?>
						<p class="<?php echo $even_odd; ?>">
							<b><?php

							echo elgg_echo("profile:{$shortname}");

							?>: </b>
							<?php
							$options = array(
								'value' => $vars['entity']->$shortname
							);

							if ($valtype == 'tags') {
								$options['tag_names'] = $shortname;
							}

							echo elgg_view("output/{$valtype}", $options);

							?>

						</p>

						<?php
					}
				}
			}
		}

	?>
	</div><!-- /#profile_info_column_middle -->



<?php if (!get_plugin_setting('user_defined_fields', 'profile')) {?>


	<div id="profile_info_column_right">
	<p class="profile_aboutme_title"><b><?php echo elgg_echo("profile:aboutme"); ?></b></p>

	<?php if ($vars['entity']->isBanned()) { ?>
		<div id="profile_banned">
		<?php
			echo elgg_echo('profile:banned');
		?>
		</div><!-- /#profile_info_column_right -->

	<?php } else { ?>

		<?php
		echo elgg_view('output/longtext', array('value' => $vars['entity']->description));
		//echo autop(filter_tags($vars['entity']->description));
		?>

	<?php } ?>

	</div><!-- /#profile_info_column_right -->
</td>
<td>

	<?php

		if ($vars['entity']->canEdit()) {

	?>
		
			<a class="edit_button" href="<?php echo $vars['url']; ?>pg/profile/<?php echo $vars['entity']->username; ?>/edit/"><?php echo elgg_echo("profile:edit"); ?></a>
		
	<?php

		}

	?>


<?php
	// display the users name
	echo "<h2><a href=\"" . $vars['entity']->getUrl() . "\" $rel>" . $vars['entity']->name . "</a></h2>";
?>


<div class="tabber" style="paddding:0;">
<div class="tabbertab" style="padding:0;">
			<h2><?php echo elgg_echo("messageboard:board"); ?></h2>
		 <!--/leftwideheader -->
		<?php
		//get the full page owner entity
		$user = get_entity(page_owner());

		//the number of message to display
		$num_display = 10;
		if (isset($vars['entity']->num_display)) {
			$num_display = $vars['entity']->num_display;
		}

		//Just the loggedin user can post messages
		if (isloggedin()) {
		?>
		<script type="text/javascript">
			$(document).ready(function(){

				$("#postit").click(function(){

					//display the ajax loading gif at the start of the function call
					//$('#loader').html('<img src="<?php echo $vars['url']; ?>_graphics/ajax_loader.gif" />');
					$('#loader').html('<?php echo elgg_view('ajax/loader',array('slashes' => TRUE)); ?>');

					//load the results back into the message board contents and remove the loading gif
					//remember that the actual div being populated is determined on views/default/messageboard/messageboard.php
					$("#messageboard_wrapper").load("<?php echo $vars['url']; ?>mod/messageboard/ajax_endpoint/load.php", {messageboard_content:$("[name=message_content]").val(), pageOwner:$("[name=pageOwner]").val(), numToDisplay:<?php echo $num_display; ?>}, function(){
						$('#loader').empty(); // remove the loading gif
						$('[name=message_content]').val(''); // clear the input textarea
					}); //end

				}); // end of the main click function

			}); //end of the document .ready function
		</script>

		<div id="is_mb_input_wrapper"><!-- start of mb_input_wrapper div -->

			<!-- message textarea -->
			<textarea name="message_content" class="is_input_textarea"></textarea>

			<!-- the page owner, this will be the profile owner -->
			<input type="hidden" name="pageOwner" value="<?php echo page_owner(); ?>" class="pageOwner"  />

			<!-- submit button -->
			<input onClick="history.go(0)" type="submit" id="postit" value="<?php echo elgg_echo('messageboard:postit'); ?>">

			<!-- menu options -->
			<div id="messageboard_widget_menu">
				<a href="<?php echo $vars['url']; ?>pg/messageboard/<?php echo $user->username; ?>"><?php echo elgg_echo("messageboard:viewall"); ?></a>
			</div>

			<!-- loading graphic -->
			<div id="loader" class="loading">  </div>

		</div><!-- end of mb_input_wrapper div -->

			<?php
		} //	if(isloggedin())

		//this for the first time the page loads, grab the latest messages.
		$contents = $user->getAnnotations('messageboard', $num_display, 0, 'desc');

		//as long as there is some content to display, display it
		if (!empty($contents)) {

			echo elgg_view('messageboard/messageboard',array('annotation' => $contents));

		} else {

			//put the required div on the page for the first message
			echo "<div id=\"messageboard_wrapper\"></div>";

		}
		?>
</div> <!-- /tabbertab -->
<div class="tabbertab">
<h2>Activity</h2>
<?php
/**
 * user activity
 */

$owner = page_owner_entity();

//get the type - mine or friends
$type = $vars['entity']->content_type;
if (!$type) {
	$type = "mine";
}

//based on type grab the correct content type
if ($type == "mine") {
	$content_type = '';
} else {
	$content_type = 'friend';
}

//get the number of items to display
$limit = $vars['entity']->num_display;
if (!$limit) {
	$limit = 10;
}

//grab the river
$river = elgg_view_river_items($owner->getGuid(), 0, $content_type, $content[0], $content[1], '', $limit, 0, 0, FALSE);

//display
echo "<div class=\"contentWrapper\" style='width:417px; margin: 0;' >";
if ($type != 'mine') {
	echo "<div class='content_area_user_title'><h2>" . elgg_echo("friends") . "</h2></div>";
}
echo $river;
echo "</div>";
?>
</div> <!-- /tabbertab -->
</div> <!-- /tabber -->

</td>
</tr>
<?php } ?>

</table>



</div><!-- /#profile_info -->
