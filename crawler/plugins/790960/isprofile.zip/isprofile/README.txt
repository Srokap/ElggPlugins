1.	Comment out the message board widget option from /mod/messageboard/start.php

2.	Comnent out the 'activity' widget optin from the /mod/riverdashboard/start.php

3.	Remove the page forward after deletion of individual entries.
	Go to /mod/messageboard/actions/delete.php and change the value of the variable $url.
	
	$url = $_SERVER['HTTP_REFERER'];
