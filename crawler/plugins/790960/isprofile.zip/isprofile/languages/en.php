<?php

	$english = array(
	
			'profile:widgets' => "Profile Widgets"	,
			'profilebox:message' => 'Choose the additional features you want to add to your page by dragging them from the Widget gallery, to the widget area on right. To remove a widget drag it back to the Widget gallery. Added widgets would appear on the right most column of your profile page.',
			'widget:edit' => "Add/Remove Widgets",
			'widgets:default:add' => 'Set default widgets for new user'
	);
					
	add_translation("en",$english);

?>
