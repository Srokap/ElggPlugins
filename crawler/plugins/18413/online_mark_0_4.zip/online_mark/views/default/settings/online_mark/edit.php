<?php
   $timeout = get_plugin_setting('timeout','online_mark');
   if(!$timeout) set_plugin_setting('timeout', 600, 'online_mark'); 
?>
 <p><b>Timeout in sec:</b> <input name="params[timeout]" type="text" size="5" value="<?php echo $vars['entity']->timeout; ?>" maxlength="5"></p>

