<?php

	/**
	 * Elgg default spotlight
	 * The spotlight area that displays across the site
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.org/
	 * 
	 */
?>

<table id="spotlight_table" width="100%"cellspacing="0">
	<tr>
		<td align="left" valign="top">
		<!-- spotlight LHS content -->
					<table id="spotlight_table_left_area" width="90%" cellspacing="0">
						<tr>
							<td colspan="3" align="left" valign="top">
							The Moon Books Entertainment Network is a community of Nintendo DS devotees, Science Fiction fanatics, game designers, coders, artists and weirdos. Join us, you will fit right in!
							</td>
						</tr>
						
						<tr><td width="100%" height="10" colspan="3" align="left" valign="top"></td>	</tr>
						
						<tr>
							<td width="33%" align="center" valign="top">
							<center><h2><a href="http://moonbooks.net/mb2/pg/groups/7/the-moon-books-project/" >Moon Books Project</a></h2></center>
							<a href="http://moonbooks.net/mb2/pg/groups/7/the-moon-books-project/" class="icon"><img src="http://moonbooks.net/mb2/pg/groupicon/7/large/default.jpg" title="" border="0"></a>
							<center>classic literature and films on the nintendo ds</center>
							</td>
							<td width="33%" align="left" valign="top">
							<h2></h2>
							<ul>
								<li>your group could be here</li>
							</ul>
							
							
							</td>
							<td width="33%" align="left" valign="top">
							<h2></h2>
							<ul>
								<li>your group could be here</li>
							</ul>
							
							</td>
						</tr>
					</table>
				<!-- /spotlight LHS content -->

		</td>		
		
		
		<td width="250" align="left" valign="top">
		<!-- spotlight RHS content -->
		<h2>Featured Blogs:</h2>
					
		<ul>
			<li><a href="http://moonbooks.net/mb2/pg/blog/btmullins">Brandon's Blog</a></li>
			
		</ul>
		<!-- /spotlight RHS content -->
		<!-- <a href="http://elgg.com"><img src="http://news.elgg.org/mod/standaloneblog/graphics/elgg_com_badge.gif"></a> -->
		</td>
	</tr>
</table>