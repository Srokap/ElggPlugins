this theme has been hacked together using several themes, and other bits and pieces. i hacked (cut-n-paste) this together for moonbooks.net

hopefully someone will make a dashboard and/or frontpage editor or something that the less technical of us lot can use.

brandon
btmullins@live.com
http://moonbooks.net
