<?php
/* LiangLee Metatags Manager
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @Package Liang Lee Metatags
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File settings.php
 */
$path = elgg_get_plugins_path();
$liang_lee_meta_url = "LiangLee_metatags";
$Lianglee_Metatags_ver = $path. $liang_lee_meta_url . "/version.php";
include $Lianglee_Metatags_ver;
$liang_lee_Metainfo1 = elgg_echo('llee:metas:1');
$liang_lee_Metainfo2 = elgg_echo('llee:metas:2');
$liang_lee_Metainfo3 = elgg_echo('llee:metas:3');
$liang_lee_Metainfo4 = elgg_echo('llee:metas:4');
$liang_lee_Metainfo5 = elgg_echo('llee:metas:5');
$liang_lee_Metainfo6 = elgg_echo('llee:metas:6');
$liang_lee_Metainfo7 = elgg_echo('llee:metas:7');
$liang_lee_SiteMeta_1 = elgg_view("input/text", array(
"name" => "params[LiangLee_keywords]", 
"value" => $vars['entity']->LiangLee_keywords));
$liang_lee_SiteMeta_2 = elgg_view("input/text", array(
"name" => "params[LiangLee_description]", 
"value" => $vars['entity']->LiangLee_description));
$liang_lee_SiteMeta_3 = elgg_view("input/text", array(
"name" => "params[LiangLee_author]", 
"value" => $vars['entity']->LiangLee_author));
$liang_lee_SiteMeta_4 = elgg_view("input/text", array(
"name" => "params[LiangLee_robots]", 
"value" => $vars['entity']->LiangLee_robots));
$liang_lee_SiteMeta_5 = elgg_view("input/text", array(
"name" => "params[LiangLee_revisit]", 
"value" => $vars['entity']->LiangLee_revisit));
$liang_lee_SiteMeta_6 = elgg_view("input/text", array(
"name" => "params[LiangLee_contentLang]", 
"value" => $vars['entity']->LiangLee_contentLang));
$settings = <<<__HTML

    <h3>$lleesettings</h3>
    <div>
        <p><i>$liang_lee_Metainfo1</i><br>$liang_lee_SiteMeta_1</p>
		 <p></p>
		<p><i>$liang_lee_Metainfo2</i><br>$liang_lee_SiteMeta_2</p>
		<p></p>
		<p><i>$liang_lee_Metainfo3</i><br>$liang_lee_SiteMeta_3</p>
		<p></p>
		<p><i>$liang_lee_Metainfo4</i><br>$liang_lee_SiteMeta_4</p>
		<p></p>
		<p><i>$liang_lee_Metainfo5</i><br>$liang_lee_SiteMeta_5</p>
		<p></p>
		<p><i>$liang_lee_Metainfo6</i><br>$liang_lee_SiteMeta_6</p>
		<p><i>$liang_lee_Metainfo7</i>
		<p>Release:$LiangLee_Metatags_release</p>
		<p>Version:$LiangLee_Metatags_version</p>

    </div>
    <hr>
</div>
__HTML;

echo $settings, $title;