<?php
/* LiangLee Meta Tags Manager
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @package LiangLee Meta Tags Manager
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File LiangLee_metatags.php
 */
if($LiangLee_Keywords = elgg_get_plugin_setting("LiangLee_keywords", "LiangLee_metatags")){
	$Le_keywords =$LiangLee_Keywords;
}
if($LiangLee_description = elgg_get_plugin_setting("LiangLee_description", "LiangLee_metatags")){
	$Le_des =$LiangLee_description;
}
if($LiangLee_author = elgg_get_plugin_setting("LiangLee_author", "LiangLee_metatags")){
	$Le_author =$LiangLee_author;
}
if($LiangLee_robots = elgg_get_plugin_setting("LiangLee_robots", "LiangLee_metatags")){
	$Le_robots =$LiangLee_robots;
}
if($LiangLee_revisit = elgg_get_plugin_setting("LiangLee_revisit", "LiangLee_metatags")){
	$Le_revisit =$LiangLee_revisit;
}
if($LiangLee_contentLang = elgg_get_plugin_setting("LiangLee_contentLang", "LiangLee_metatags")){
	$Le_cLang =$LiangLee_contentLang;
}
?>
<?php
if (elgg_get_plugin_setting('LiangLee_keywords', 'LiangLee_metatags')) {
?>
<meta name="keywords" content="<?php echo $Le_keywords ?>" />
<?php } ?>
<?php
if (elgg_get_plugin_setting('LiangLee_description', 'LiangLee_metatags')) {
?>
<meta name="description" content="<?php echo $Le_des ?>" />
<?php } ?>
<?php
if (elgg_get_plugin_setting('LiangLee_author', 'LiangLee_metatags')) {
?>
<meta name="author" content="<?php echo $Le_author ?>" />
<?php } ?>
<?php
if (elgg_get_plugin_setting('LiangLee_robots', 'LiangLee_metatags')) {
?>
<meta name="robots" content="<?php echo $Le_robots ?>" />
<?php
}
?>
<?php
if (elgg_get_plugin_setting('LiangLee_revisit', 'LiangLee_metatags')) {
?>
<meta name="revisit-after" content="<?php echo $Le_revisit ?>" />
<?php } ?>
<?php
if (elgg_get_plugin_setting('LiangLee_contentLang', 'LiangLee_metatags')) {
?>
<meta http-equiv="content-language" content="<?php echo $Le_cLang ?>">
<?php } ?>
