<?php
/* LiangLee Metatags Manager
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @Package Liang Lee Metatags
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File Version.php
 */
$LiangLee_Metatags_version = '20120205';
$LiangLee_Metatags_release = '1.0.3';
?>
