<?php

	$english = array(

		/**
		 * Sites
		 */
	
			'item:site' => 'Sítě',
	
		/**
		 * Sessions
		 */
			
			'login' => "Přihlásit se",
			'loginok' => "Jsi přihlašen.",
			'loginerror' => "Nelze vás přihlásit. Možná jste ješte nepotvrdili svůj účet, nebo jsou vámi vyplněná data chybná. Přesvěčte se zda jste zadali správně svá data a zkuste se přihlásit znovu.",
	
			'logout' => "Odhlásit se",
			'logoutok' => "Jsi odhlašen(a).",
			'logouterror' => "Nelze vás odhlasit. Zkuste to ješte jednou.",
	
		/**
		 * Errors
		 */
			'exception:title' => "Vítejte v Elgg.",
	
			'InstallationException:CantCreateSite' => "Unable to create a default ElggSite with credentials Name:%s, Url: %s",
		
			'actionundefined' => "Požadovaná akce (%s) není v systému nadefinována.",
			'actionloggedout' => "Omlouváme se, nelze vykonat požadovanou akci, když jste odelašen(a).",
	
			'notfound' => "Požadovaná data nelze najít, nebo k nim není povolen přístup.",
			
			'SecurityException:Codeblock' => "Denied access to execute privileged code block",
			'DatabaseException:WrongCredentials' => "Elgg se nemůže připojit k databázi s pomocí zadaných údajů.",
			'DatabaseException:NoConnect' => "Elgg couldn't select the database '%s', please check that the database is created and you have access to it.",
			'SecurityException:FunctionDenied' => "Access to privileged function '%s' is denied.",
			'DatabaseException:DBSetupIssues' => "Nastalo několik problémů: ",
			'DatabaseException:ScriptNotFound' => "Elgg couldn't find the requested database script at %s.",
			
			'IOException:FailedToLoadGUID' => "Failed to load new %s from GUID:%d",
			'InvalidParameterException:NonElggObject' => "Passing a non-ElggObject to an ElggObject constructor!",
			'InvalidParameterException:UnrecognisedValue' => "Unrecognised value passed to constuctor.",
			
			'InvalidClassException:NotValidElggStar' => "GUID:%d není platný %s",
			
			'PluginException:MisconfiguredPlugin' => "%s je špatně nastavený plugin.",
			
			'InvalidParameterException:NonElggUser' => "Passing a non-ElggUser to an ElggUser constructor!",
			
			'InvalidParameterException:NonElggSite' => "Passing a non-ElggSite to an ElggSite constructor!",
			
			'InvalidParameterException:NonElggGroup' => "Passing a non-ElggGroup to an ElggGroup constructor!",
	
			'IOException:UnableToSaveNew' => "Nelze uložit nový %s",
			
			'InvalidParameterException:GUIDNotForExport' => "GUID nebyl specifikován během expotu, toto by se nikdy nemělo stát.",
			'InvalidParameterException:NonArrayReturnValue' => "Entity serialisation function passed a non-array returnvalue parameter",
			
			'ConfigurationException:NoCachePath' => "Ne nastavena cesta k Cache!",
			'IOException:NotDirectory' => "%s není adresář.",
			
			'IOException:BaseEntitySaveFailed' => "Unable to save new object's base entity information!",
			'InvalidParameterException:UnexpectedODDClass' => "import() passed an unexpected ODD class",
			'InvalidParameterException:EntityTypeNotSet' => "Typ entity musí být nastaven.",
			
			'ClassException:ClassnameNotClass' => "%s is not a %s.",
			'ClassNotFoundException:MissingClass' => "Třída '%s' nebyla nalezena, chybějící plugin?",
			'InstallationException:TypeNotSupported' => "Typ %s není podporován. Toto naznačuje chybu ve vaší instalaci, která nejsíše vznikla neuplnou aktualizací systému.",

			'ImportException:ImportFailed' => "Element %d nelze importovat",
			'ImportException:ProblemSaving' => "Při ukládání %s nastal problém",
			'ImportException:NoGUID' => "Byla vytvořena nová entita ale nemá , toto by se nikdy nemělo stát.",
			
			'ImportException:GUIDNotFound' => "Entitu '%d' nelze najít.",
			'ImportException:ProblemUpdatingMeta' => "Při update entity %d nastal problem '%s'",
			
			'ExportException:NoSuchEntity' => "No such entity GUID:%d", 
			
			'ImportException:NoODDElements' => "No OpenDD elements found in import data, import failed.",
			'ImportException:NotAllImported' => "Not all elements were imported.",
			
			'InvalidParameterException:UnrecognisedFileMode' => "Unrecognised file mode '%s'",
			'InvalidParameterException:MissingOwner' => "File %s (%d) is missing an owner!",
			'IOException:CouldNotMake' => "Could not make %s",
			'IOException:MissingFileName' => "Pro ovevření souboru je nutné nejdříve zadat jméno.",
			'ClassNotFoundException:NotFoundNotSavedWithFile' => "Filestore not found or class not saved with file!",
			'NotificationException:NoNotificationMethod' => "No notification method specified.",
			'NotificationException:NoHandlerFound' => "No handler found for '%s' or it was not callable.",
			'NotificationException:ErrorNotifyingGuid' => "There was an error while notifying %d",
			'NotificationException:NoEmailAddress' => "Could not get the email address for GUID:%d",
			'NotificationException:MissingParameter' => "Missing a required parameter, '%s'",
			
			'DatabaseException:WhereSetNonQuery' => "Where set contains non WhereQueryComponent",
			'DatabaseException:SelectFieldsMissing' => "Fields missing on a select style query",
			'DatabaseException:UnspecifiedQueryType' => "Unrecognised or unspecified query type.",
			'DatabaseException:NoTablesSpecified' => "No tables specified for query.",
			'DatabaseException:NoACL' => "No access control was provided on query",
			
			'InvalidParameterException:NoEntityFound' => "No entity found, it either doesn't exist or you don't have access to it.",
			
			'InvalidParameterException:GUIDNotFound' => "GUID:%s could not be found, or you can not access it.",
			'InvalidParameterException:IdNotExistForGUID' => "Sorry, '%s' does not exist for guid:%d",
			'InvalidParameterException:CanNotExportType' => "Sorry, I don't know how to export '%s'",
			'InvalidParameterException:NoDataFound' => "Could not find any data.",
			'InvalidParameterException:DoesNotBelong' => "Does not belong to entity.",
			'InvalidParameterException:DoesNotBelongOrRefer' => "Does not belong to entity or refer to entity.",
			'InvalidParameterException:MissingParameter' => "Missing parameter, you need to provide a GUID.",
			
			'SecurityException:APIAccessDenied' => "Omlouváme se, přístup k API byl zakázán administrátorem.",
			'SecurityException:NoAuthMethods' => "Nebyly nalezeny žádné metody pro ověření pozadavku API.",
			'APIException:ApiResultUnknown' => "Výstup z API má neznámý typ, toto by nemělo nikdy nastat.", 
			
			'ConfigurationException:NoSiteID' => "ID sítě nebylo specifikováno.",
			'InvalidParameterException:UnrecognisedMethod' => "Unrecognised call method '%s'",
			'APIException:MissingParameterInMethod' => "Missing parameter %s in method %s",
			'APIException:ParameterNotArray' => "%s does not appear to be an array.",
			'APIException:UnrecognisedTypeCast' => "Unrecognised type in cast %s for variable '%s' in method '%s'",
			'APIException:InvalidParameter' => "Invalid parameter found for '%s' in method '%s'.",
			'APIException:FunctionParseError' => "%s(%s) has a parsing error.",
			'APIException:FunctionNoReturn' => "%s(%s) returned no value.",
			'SecurityException:AuthTokenExpired' => "Authentication token either missing, invalid or expired.",
			'CallException:InvalidCallMethod' => "%s must be called using '%s'",
			'APIException:MethodCallNotImplemented' => "Method call '%s' has not been implemented.",
			'APIException:AlgorithmNotSupported' => "Algorithm '%s' is not supported or has been disabled.",
			'ConfigurationException:CacheDirNotSet' => "Cache directory 'cache_path' not set.",
			'APIException:NotGetOrPost' => "Request method must be GET or POST",
			'APIException:MissingAPIKey' => "Missing X-Elgg-apikey HTTP header",
			'APIException:MissingHmac' => "Missing X-Elgg-hmac header",
			'APIException:MissingHmacAlgo' => "Missing X-Elgg-hmac-algo header",
			'APIException:MissingTime' => "Missing X-Elgg-time header",
			'APIException:TemporalDrift' => "X-Elgg-time is too far in the past or future. Epoch fail.",
			'APIException:NoQueryString' => "No data on the query string",
			'APIException:MissingPOSTHash' => "Missing X-Elgg-posthash header",
			'APIException:MissingPOSTAlgo' => "Missing X-Elgg-posthash_algo header",
			'APIException:MissingContentType' => "Missing content type for post data",
			'SecurityException:InvalidPostHash' => "POST data hash is invalid - Expected %s but got %s.",
			'SecurityException:DupePacket' => "Packet signature already seen.",
			'SecurityException:InvalidAPIKey' => "Invalid or missing API Key.",
			'NotImplementedException:CallMethodNotImplemented' => "Call method '%s' is currently not supported.",
	
			'NotImplementedException:XMLRPCMethodNotImplemented' => "XML-RPC method call '%s' not implemented.",
			'InvalidParameterException:UnexpectedReturnFormat' => "Call to method '%s' returned an unexpected result.",
			'CallException:NotRPCCall' => "Call does not appear to be a valid XML-RPC call",
	
			'PluginException:NoPluginName' => "Nelze najít jméno pluginu",
	
			'ConfigurationException:BadDatabaseVersion' => "Databáze, kterou máte naistalovanou nesplňuje požadavky pro základní chod systému Elgg. Prosím prostudujte si dokumentaci.",
			'ConfigurationException:BadPHPVersion' => "Potřebuje alespoň PHP verze 5.2 ke spuštění Elgg.",
			'configurationwarning:phpversion' => "Potřebuje alespoň PHP verze 5.2 ke spuštění Elgg, systém lze nainstolvat i na vezi 5.1.6 ale některé funkce musí fungovat (použijte pouze na vlastní riziko).",
	
	
			'InstallationException:DatarootNotWritable' => "U vašeho datového adresáře %s není povoleno zapisovat.",
			'InstallationException:DatarootUnderPath' => "Váš datový adresář %s musí být mimo adreař instalace.",
			'InstallationException:DatarootBlank' => "Datový adresář nebyl specifikován.",
	
			'SecurityException:authenticationfailed' => "Uživatele nelze ověřit",
	
			'CronException:unknownperiod' => '%s je neplatný časový údaj.',
	
			'SecurityException:deletedisablecurrentsite' => 'Nelze smazat nebo vypnout síť, která je zrovna prohlížena!',
	
			'memcache:notinstalled' => 'PHP memcache module not installed, you must install php5-memcache',
			'memcache:noservers' => 'No memcache servers defined, please populate the $CONFIG->memcache_servers variable',
			'memcache:versiontoolow' => 'Memcache needs at least version %s to run, you are running %s',
			'memcache:noaddserver' => 'Multiple server support disabled, you may need to upgrade your PECL memcache library',
	
			'deprecatedfunction' => 'Varování: Tento kod používá zastaralou funkci \'%s\', která není kopatibilní se současnou verzí Elgg',
	
			'pageownerunavailable' => 'Varování: Vlastník stránek %d není dostupný!',
		/**
		 * API
		 */
			'system.api.list' => "Seznam všech dostupných příkazů API na tomto systému.",
			'auth.gettoken' => "This API call lets a user log in, returning an authentication token which can be used in leu of a username and password for authenticating further calls.",
	
		/**
		 * User details
		 */

			'name' => "Zobrazované jméno",
			'email' => "Emailová adresa",
			'username' => "Uživatelské jméno",
			'password' => "Heslo",
			'passwordagain' => "Heslo (vyplňte znovu - pro ověření)",
			'admin_option' => "Bude tento uživatel administrátor?",
	
		/**
		 * Access
		 */
	
			'PRIVATE' => "Soukromé",
			'LOGGED_IN' => "Pro přihlášené uživatele",
			'PUBLIC' => "Veřejné",
			'access:friends:label' => "Pro přátele",
			'access' => "Pro skupinu uživatelů",
	
		/**
		 * Dashboard and widgets
		 */
	
			'dashboard' => "Události",
            'dashboard:configure' => "Upravit stránku",
			'dashboard:nowidgets' => "Události jsou vaší vstupní branou do této sítě. Zmáčkněte 'Upravit stránku' pro přidaní miniaplikací, které budou sledovat obsah a události v síti.",

			'widgets:add' => 'Přidat miniaplikace na vaši stránku',
			'widgets:add:description' => "Vyberte si funkce, které chcete přidat na vaši stránku tím, že je přetáhnete z <b>Galerie miniaplikací</b> (na pravé straně) do jednoho ze tří sloupců vlevo (které reprezentují umístění na vaší stránce) ve vámi zvoleném pořadí.

Miniaplikace lze odstranit tím, že je přetáhnete zpět do <b>Galerie miniaplikací</b>.",
			'widgets:position:fixed' => '(stálá pozice na stránce)',
	
			'widgets' => "Miniaplikace",
			'widget' => "Miniaplikace",
			'item:object:widget' => "Miniaplikace",
			'layout:customise' => "Upravit vzhled",
			'widgets:gallery' => "Galerie miniaplikací",
			'widgets:leftcolumn' => "Miniaplikace nalevo",
			'widgets:fixed' => "Stálá pozice",
			'widgets:middlecolumn' => "Miniaplikace uprostřed",
			'widgets:rightcolumn' => "Miniaplikace napravo",
			'widgets:profilebox' => "Rámeček profilu",
			'widgets:panel:save:success' => "Zvolené miniaplikace byly úspěšně uloženy.",
			'widgets:panel:save:failure' => "Při ukládání miniaplikace nastal problém. Prosím zkuste to znovu.",
			'widgets:save:success' => "Miniaplikace byla úspěšně uložena.",
			'widgets:save:failure' => "Nelze uložit miniaplikaci. Prosím zkuste to znovu.",
			'widgets:handlernotfound' => 'Tato miniaplikace je poškozená, nebo byla odstavena administrátorem.',
	
		/**
		 * Groups
		 */
	
			'group' => "Skupina", 
			'item:group' => "Skupiny",
	
		/**
		 * Profile
		 */
	
			'profile' => "Profil",
			'profile:edit:default' => 'Upravte položky profilu',
			'profile:preview' => 'Náhled',
			'user' => "Uživatel",
			'item:user' => "Uživatelé",
			'riveritem:single:user' => 'uživatel',
			'riveritem:plural:user' => 'uživatelé',
	
	

		/**
		 * Profile menu items and titles
		 */
	
			'profile:yours' => "Váš profil",
			'profile:user' => "%s profil",
	
			'profile:edit' => "Upravit profil",
			'profile:profilepictureinstructions' => "Ikona profilu je obrázek, který je zobrazen na stránce vašeho profilu. <br /> Tuto ikonu může měnit tak často, jak chcete. (akceptované formáty jsou: GIF, JPG nebo PNG)",
			'profile:icon' => "Ikona profilu",
			'profile:createicon' => "Vytvoř ikonu",
			'profile:currentavatar' => "Současná Ikona",
			'profile:createicon:header' => "Ikona profilu",
			'profile:profilepicturecroppingtool' => "Nástroj na oříznutí obrázku",
			'profile:createicon:instructions' => "Klikni a roztáhni rámeček tak, aby obsahoval tu část obrázku, kterou si přeješ použít. Náhled výsledného obrázku se objeví vpravo. Stisknutím tlačítka 'Vytvoř ikonu' se uloží výsledná ikona, která bude v síti doprovázet váš profil. ",
	
			'profile:editdetails' => "Upravit detaily",
			'profile:editicon' => "Upravit ikonu profilu",
	
			'profile:aboutme' => "O mě", 
			'profile:description' => "O mě",
			'profile:briefdescription' => "Stručný popis",
			'profile:location' => "Místo",
			'profile:skills' => "Dovednosti",  
			'profile:interests' => "Zájmy", 
			'profile:contactemail' => "Kontaktní email",
			'profile:phone' => "Číslo uživatele (nevyplňuje, vyplní administrátor)",
			'profile:mobile' => "Telefon/Mobil",
			'profile:website' => "Webové stránky",
	
			'profile:banned' => 'Tento uživatelský účet byl pozastaven.',
			'profile:deleteduser' => 'Smazaný uživatel',

			'profile:river:update' => "%s upravil(a) svůj profil",
			'profile:river:iconupdate' => "%s upravil(a) ikonu svého profilu",
	
			'profile:label' => "Nadpis profilu",
			'profile:type' => "Typ profilu",
	
			'profile:editdefault:fail' => 'Výchozí profil nelze uložit',
			'profile:editdefault:success' => 'Položka byla, úspešně přidána do výchozího profilu',
	
			
			'profile:editdefault:delete:fail' => 'Odebírání položky z výchozího profilu, selhalo',
			'profile:editdefault:delete:success' => 'Položka byla odebrána z výchozího profilu!',
	
			'profile:defaultprofile:reset' => 'Reset výchozího systémového profilu',
	
			'profile:resetdefault' => 'Resetovat výchozí profil',
			'profile:explainchangefields' => 'Existující položky profilu mohou být nahrazeny novými, použitím následujícího formuláře. Nejdříve dáte nové položce jméno, např. \'Oblíbený team\'. Pak je třeba nastavit typ položky, např. záložka, url, text, atd. Nastavení položek profilu lze kdykoliv vrátit do výchozího nastavení.',
	

	
		/**
		 * Profile status messages
		 */
	
			'profile:saved' => "Váš profil byl úspěšně uložen.",
			'profile:icon:uploaded' => "Podklad pro vaši ikonu byl úspěšně načten.",
	
		/**
		 * Profile error messages
		 */
	
			'profile:noaccess' => "Nemáte povolení k úpravě tohoto profilu.",
			'profile:notfound' => "Omlouváme se; nelze najít specifikovaný profil.",
			'profile:cantedit' => "Omlouváme se; nemáte povolení upravovat tento profil.",
			'profile:icon:notfound' => "Omlouváme se; během nahrávání ikony pro vás profil nastal problém.",
	
		/**
		 * Friends
		 */
	
			'friends' => "Přátelé",
			'friends:yours' => "Tvoji přátelé",
			'friends:owned' => "%s přátele",
			'friend:add' => "Přidat mezi přátele",
			'friend:remove' => "Odstanit z přátel",
	
			'friends:add:successful' => "%s byl úspěsně přidán mezi přátele.",
			'friends:add:failure' => "Nelze přidat %s mezi přátele. Prosím zkuste to znova.",
	
			'friends:remove:successful' => "%s byl úspěšně odstraněn z přátel.",
			'friends:remove:failure' => "Nelze odstranit %s z přátel. Prosím zkuste to znova.",
	
			'friends:none' => "Tento uživatel ješte nikoho nepřidal mezi přátele.",
			'friends:none:you' => "Jestě jsi nikoho nepřidal(a) mezi přátele. Zkus použít vyhledávaní k nalezení přátel se společnými zájmy.",
	
			'friends:none:found' => "Žadní přátelé nebyly nalezeni.",
	
			'friends:of:none' => "Tohoto uživatele ješte nikdo nepřidal mezi přátele.",
			'friends:of:none:you' => "Nikdo tě ještě nepřidal mezi přátele. Zkus doplnit detaily do tvého profilu a přidat nějaký obsah, aby tě přátelé mohli najít!",
	
			'friends:of:owned' => "Lidé, kteří přidali %s mezi přátele",

			 'friends:num_display' => "Počet zobrazených přátel",
			 'friends:icon_size' => "Velikost ikon",
			 'friends:tiny' => "nejmenší",
			 'friends:small' => "malé",
			 'friends:of' => "Přátelé od",
			 'friends:collections' => "Skupiny přátel",
			 'friends:collections:add' => "Nová skupina přátel",
			 'friends:addfriends' => "Přidat nové přátele",
			 'friends:collectionname' => "Název skupiny",
			 'friends:collectionfriends' => "Přátelé ve skupině",
			 'friends:collectionedit' => "Upravit tuto skupinu",
			 'friends:nocollections' => "Ještě jsi nevytvořil žádnou skupinu.",
			 'friends:collectiondeleted' => "Tvoje skupina byla smazána.",
			 'friends:collectiondeletefailed' => "Nelze smazat skupinu. Buď nemáš potřebné povolení, nebo nastal jiný problém.",
			 'friends:collectionadded' => "Tvoje skupina byla úspěšne vytvořena",
			 'friends:nocollectionname' => "Tvoje skupina musí mít jméno k tomu, aby mohla být vytvořena.",
			'friends:collections:members' => "Členové skupiny",
			'friends:collections:edit' => "Upravit skupinu",
		
	        'friends:river:created' => "%s přidal miniaplikaci Přátelé.",
	        'friends:river:updated' => "%s upravil svoji miniaplikaci Přátelé.",
	        'friends:river:delete' => "%s odstranil miniaplikaci Přátelé.",
	        'friends:river:add' => "%s se přátelí s",
	
			'friendspicker:chararray' => 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
	
		/**
		 * Feeds
		 */
			'feed:rss' => 'Přihlásit k odběru',
			'feed:odd' => 'Přihlásit OpenDD',
			
		/**
          * links
		 **/

			'link:view' => 'zobraz odkaz',

	
		/**
		 * River
		 */
			'river' => "Řeka",			
			'river:relationship:friend' => 'se přátelí s',
			'river:noaccess' => 'Nemáte povolení k zobrazení této položky.',
			'river:posted:generic' => '%s napsal',

		/**
		 * Plugins
		 */
			'plugins:settings:save:ok' => "Nastavení pro plugin %s  bylo úspěšně uloženo.",
			'plugins:settings:save:fail' => "Při ukládání nastavení pro plugin %s nastal problém.",
			'plugins:usersettings:save:ok' => "Ukládání nastavení pro plugin %s proběhlo úspěšně.",
			'plugins:usersettings:save:fail' => "Při ukládání uživatelských nastavení pro plugin %s nastal problém.",
			'admin:plugins:label:version' => "Verze",
			'item:object:plugin' => 'Nastavení pro Plugin',
			
		/**
		 * Notifications
		 */
			'notifications:usersettings' => "Nastavení upozorňování",
			'notifications:methods' => "Specifikujte prosím metody, které chcete povolit.",
	
			'notifications:usersettings:save:ok' => "Vaše nastavení upozorňování bylo úspěšně uloženo.",
			'notifications:usersettings:save:fail' => "Při ukládání nastavení upozorňování nastal problém.",
	
			'user.notification.get' => 'Obnov nastavení upozorňování pro zvoleného uživatele.',
			'user.notification.set' => 'Nastav nastavení upozorňování pro zvoleného uživatele.',
		/**
		 * Search
		 */
	
			'search' => "Hledat",
			'searchtitle' => "Hledám položku: %s",
			'users:searchtitle' => "Hledám uživatele: %s",
			'groups:searchtitle' => "Hledám skupiny %s",
			'advancedsearchtitle' => "Nalezeno %s položek obsahujících %s",
			'notfound' => "Hledaný výraz nebyl nalezen.",
			'next' => "Další",
			'previous' => "Předchozí",
	
			'viewtype:change' => "Změnit způsob zobrazení",
			'viewtype:list' => "Zobraz seznam",
			'viewtype:gallery' => "Galerie",
	
			'tag:search:startblurb' => "Položky obsahující '%s':",

			'user:search:startblurb' => "Uživatelé obsahující '%s':",
			'user:search:finishblurb' => "Kliknutím, zobrazíte více.",
	
			'group:search:startblurb' => "Skupiny obsahující '%s':",
			'group:search:finishblurb' => "Klikněte pro zobrazení detailů.",
			'search:go' => 'Hledat',
	
		/**
		 * Account
		 */
	
			'account' => "Účet",
			'settings' => "Nastavení",
            'tools' => "Nástroje",
            'tools:yours' => "Tvoje nástroje",
	
			'register' => "Registrace",
			'registerok' => "Úspěšně jste se zaregistroval do %s.",
			'registerbad' => "Vaše registrace nebyla úspěšná. Možné důvody: uživatelské jméno už existuje, heslo se neshoduje, heslo nebo uživatelské jméno je příliš krátké.",
			'registerdisabled' => "Registrace byla blokována systémovým administrátorem",
	
			'firstadminlogininstructions' => 'Vaše nová Elgg síť byla úspěšně nainstalována a váš administrátorský účet byt vytvořen. Nyní můžete donastavit vaši sít zapnutím některých z nainstalových nástrojů (pluginů).',
	
			'registration:notemail' => 'Poskytnutá emailová adresa nevypadá jako platná emailová adresa.',
			'registration:userexists' => 'Uživatelské jméno již existuje',
			'registration:usernametooshort' => 'Uživatelské jméno musí být min. 4 znaky dlouhé.',
			'registration:passwordtooshort' => 'Heslo musí být min. 6 znaků dlouhé.',
			'registration:dupeemail' => 'Učet se stejnou emailovou adresou již existuje.',
			'registration:invalidchars' => 'Omlouváme se, vaše uživatelské jméno obsahuje nepodporované znaky.',
			'registration:emailnotvalid' => 'Omlouváme se, emailová adresa není platná',
			'registration:passwordnotvalid' => 'Omlouváme se, heslo není platné',
			'registration:usernamenotvalid' => 'Omlouváme se, uživatelské jméno není platné',
	
			'adduser' => "Přidat uživatele",
			'adduser:ok' => "Uživatel byl úspěšně přidán.",
			'adduser:bad' => "Nový uživatel nemohl být vytvořen.",
			
			'item:object:reported_content' => "Nahlášené položky",
	
			'user:set:name' => "Nastavení jména účtu",
			'user:name:label' => "Tvoje jméno",
			'user:name:success' => "Jméno bylo úspěšně změněno.",
			'user:name:fail' => "Jméno nemohlo být změněno.",
	
			'user:set:password' => "Heslo účtu",
			'user:password:label' => "Nové heslo",
			'user:password2:label' => "Nové heslo (napište znova pro kontrolu)",
			'user:password:success' => "Heslo bylo změněno",
			'user:password:fail' => "Vaše heslo nelze změnit.",
			'user:password:fail:notsame' => "Zadaná hesla nejsou stejná!",
			'user:password:fail:tooshort' => "Heslo je příliš krátké!",
	
			'user:set:language' => "Nastavení jazyka",
			'user:language:label' => "Váš jazyk",
			'user:language:success' => "Vaše jazykové nastavení bylo upraveno.",
			'user:language:fail' => "Vaše jazykové nastavení nelze uložit.",
	
			'user:username:notfound' => 'Uživatelské jméno %s nelze najít.',
	
			'user:password:lost' => 'Zapomenuté heslo',
			'user:password:resetreq:success' => 'Vaše žádost o nové heslo byla úspěšná a potvrzení bylo zasláno na email',
			'user:password:resetreq:fail' => 'Nelze získat nové heslo.',
	
			'user:password:text' => 'Pro vygenerování nového hesla, zadejte své uživateské jméno a mi vám na váš email zašleme spec. odkaz. Jakmile kliknete na tento odkaz tak se vám vygeneruje nové heslo a zašle na váš email.',
	
			'user:persistent' => 'Zapamatovat',
		/**
		 * Administration
		 */

			'admin:configuration:success' => "Vaše nastavení bylo uloženo.",
			'admin:configuration:fail' => "Vaše nastavení nelze uložit.",
	
			'admin' => "Administrace",
			'admin:description' => "Administrátosrský panel vám umožní kontrolovat všechny aspekty systému. Začnete jednou z následujících položek.",
			
			'admin:user' => "Administrace uživatelů",
			'admin:user:description' => "Tento panel umožňuje kontrolovat nastení uživatelů na vaší síti. Začněte jednou z následujících položek.",
			'admin:user:adduser:label' => "Klikněte zde, pro přidání nového uživatele...",
			'admin:user:opt:linktext' => "Nastavit uživatele...",
			'admin:user:opt:description' => "Nastavit uživatele a informace na účtu. ",
			
			'admin:site' => "Administrace sítě",
			'admin:site:description' => "Tento administrátorský panel vám umožňuje globální kontrolu vašich nastavení sítě. Začněte jednou z následujících položek.",
			'admin:site:opt:linktext' => "Nastavit síť...",
			'admin:site:opt:description' => "Nastavtuje technická a netechnická nastavení sítě. ",
			'admin:site:access:warning' => "Změna úrovně přístupu ovlivní pouze následně vytvořený obsah.", 
			
			'admin:plugins' => "Administrace nástrojů",
			'admin:plugins:description' => "Tento panel vám umožní nastavit a ovládat nástroje, které jsou nainstalované na této síti.",
			'admin:plugins:opt:linktext' => "Nastavení nástrojů...",
			'admin:plugins:opt:description' => "Nastavení nástrojů, umístěných na síti. ",
			'admin:plugins:label:author' => "Author",
			'admin:plugins:label:copyright' => "Copyright",
			'admin:plugins:label:licence' => "Licence",
			'admin:plugins:label:website' => "URL",
			'admin:plugins:label:moreinfo' => 'více informací',
			'admin:plugins:label:version' => 'Version',
			'admin:plugins:warning:elggversionunknown' => 'Varování: Tento plugin nespecifikuje se kterou verzí Elgg je kompatibilní.',
			'admin:plugins:warning:elggtoolow' => 'Varování: Tento plugin vyžaduje novější verzi Elgg!',
			'admin:plugins:reorder:yes' => "U pluginu %s bylo úspěšně změněno pořadí.",
			'admin:plugins:reorder:no' => "U pluginu %s nelze změnit pořadí.",
			'admin:plugins:disable:yes' => "Plugin %s byl úspěšně vypnut.",
			'admin:plugins:disable:no' => "Plugin %s nelze vypnout.",
			'admin:plugins:enable:yes' => "Plugin %s byl úspěšně zapnut.",
			'admin:plugins:enable:no' => "Plugin %s nelze zapnout.",
	
			'admin:statistics' => "Statistika",
			'admin:statistics:description' => "Toto je hrubá statistika vaší sítě. Pokud potřebujete více detailní statistiku, tak existuje profesionální statistický nástroj...",
			'admin:statistics:opt:description' => "Zobraz statistické informace o uživatelích a obsahu sítě.",
			'admin:statistics:opt:linktext' => "Zobraz statistiku...",
			'admin:statistics:label:basic' => "Základní statistika sítě",
			'admin:statistics:label:numentities' => "Entit v síti",
			'admin:statistics:label:numusers' => "Počet uživatelů",
			'admin:statistics:label:numonline' => "Počet uživatelů online",
			'admin:statistics:label:onlineusers' => "Uživatelů online",
			'admin:statistics:label:version' => "Verze Elgg",
			'admin:statistics:label:version:release' => "Release",
			'admin:statistics:label:version:version' => "Verze",
	
			'admin:user:label:search' => "Hledat uživatele:",
			'admin:user:label:seachbutton' => "Hledej", 
	
			'admin:user:ban:no' => "Uživatele nelze blokovat",
			'admin:user:ban:yes' => "Uživatel blokován.",
			'admin:user:unban:no' => "Nelze odblokovat uživatele",
			'admin:user:unban:yes' => "Uživatel byl odblokován.",
			'admin:user:delete:no' => "Uživatele nelze smazat",
			'admin:user:delete:yes' => "Uživatel byl smazán",
	
			'admin:user:resetpassword:yes' => "Heslo bylo resetováno a uživatel byl upozorněn.",
			'admin:user:resetpassword:no' => "Heslo nelze resetovat.",
	
			'admin:user:makeadmin:yes' => "Uživatel byl přidán mezi administrátory.",
			'admin:user:makeadmin:no' => "Z tohoto uživatele nelze vytvořit administrátora.",
	
			'admin:user:removeadmin:yes' => "Uživatel už není administrátorem.",
			'admin:user:removeadmin:no' => "Od tohoto uživatele nelze odejmout administrátorská práva.",
			
		/**
		 * User settings
		 */
			'usersettings:description' => "Tento panel vám umožnuje nastavit veškeré osobní nastavení a chování systému. Začnete s níže uvedenými položkami.",
	
			'usersettings:statistics' => "Vaše statistiky",
			'usersettings:statistics:opt:description' => "Zobraz statistické informace o uživatelích a položkách ve vašich stránkách.",
			'usersettings:statistics:opt:linktext' => "Statistika účtu",
	
			'usersettings:user' => "Vaše nastavení",
			'usersettings:user:opt:description' => "Vám umožní kontrolovat uživatelské nastavení.",
			'usersettings:user:opt:linktext' => "Změnit nastavení",
	
			'usersettings:plugins' => "Nástroje",
			'usersettings:plugins:opt:description' => "Nastavení vašich aktivních nástrojů.",
			'usersettings:plugins:opt:linktext' => "Nastavte vaše nástroje",
	
			'usersettings:plugins:description' => "Tento panel vám umožňujě ovládat a nastavit vaše osobní nastavení a nástroje nainstalované systemovým administrátorem.",
			'usersettings:statistics:label:numentities' => "Vaše entity",
	
			'usersettings:statistics:yourdetails' => "Vaše detaily",
			'usersettings:statistics:label:name' => "Celé jméno",
			'usersettings:statistics:label:email' => "Email",
			'usersettings:statistics:label:membersince' => "Členem od",
			'usersettings:statistics:label:lastlogin' => "Naposledy přihlášen",
	
			
	
		/**
		 * Generic action words
		 */
	
			'save' => "Uložit",
			'publish' => "Publikovat",
			'cancel' => "Zrušit",
			'saving' => "Ukládám ...",
			'update' => "Aktualizovat",
			'edit' => "Upravit",
			'delete' => "Smazat",
			'accept' => "Přijmout",
			'load' => "Načíst",
			'upload' => "Uložit",
			'ban' => "Zakázat",
			'unban' => "Povolit",
			'enable' => "Zapnout",
			'disable' => "Vypnout",
			'request' => "Požádat",
			'complete' => "Hotovo",
			'open' => 'Otevřít',
			'close' => 'Zavřít',
			'reply' => "Odpovědět",
			'more' => 'Více',
			'comments' => 'Komentáře',
			'import' => 'Importovat',
			'export' => 'Exportovat',
	
			'up' => 'Nahoru',
			'down' => 'Dolu',
			'top' => 'Na začátek',
			'bottom' => 'Na konec',
	
			'invite' => "Pozvat",
	
			'resetpassword' => "Resetovat heslo",
			'makeadmin' => "Jmenovat administrátorem",
			'removeadmin' => "Zrušit administrátora",
	
			'option:yes' => "Ano",
			'option:no' => "Ne",
	
			'unknown' => 'Neznámý',
	
			'active' => 'Aktivních',
			'total' => 'Celkově',
	
			'learnmore' => "Kliknutím, se dozvíte více.",
	
			'content' => "obsah",
			'content:latest' => 'Poslední aktivita',
			'content:latest:blurb' => 'Klikněte zde, pokud chcete vidět poslední aktivity v síti.',
	
			'link:text' => 'zobrazit odkaz',
	
			'enableall' => 'Zapnout vše',
			'disableall' => 'Vypnout vše',
	
		/**
		 * Generic questions
		 */
	
			'question:areyousure' => 'Jste si jistý(á)?',
	
		/**
		 * Generic data words
		 */
	
			'title' => "Nadpis",
			'description' => "Popis",
			'tags' => "Záložka",
			'spotlight' => "Nepřehléněte",
			'all' => "Vše",
	
			'by' => 'od',
	
			'annotations' => "Poznámky",
			'relationships' => "Vztahy",
			'metadata' => "Metadata",
	
		/**
		 * Input / output strings
		 */

			'deleteconfirm' => "Jste si jisti, že chcete smazat tuto položku?",
			'fileexists' => "Soubor se stejným jménem byl již uložen. Zvolte, který se má nahradit:",
			
		/**
		 * User add
		 */

			'useradd:subject' => 'Uživateský účet byl vytvořen',
			'useradd:body' => '
%s,

Byl pro vás vytvořen uživatelský učet na %s. Pro přihlášení navštivte:

	%s

Pro přihlášení použijte tyto údaje:

	Uživatelské jméno: %s
	Heslo: %s
	
Po přihlášení, je doporučeno si změnit toto heslo.
',
			
	    /**
         * System messages
         **/

			'systemmessages:dismiss' => "Kliknutím zruš",

	
		/**
		 * Import / export
		 */
			'importsuccess' => "Import dat proběhl úspěšně",
			'importfail' => "Import dat z OpenDD selhal.",
	
		/**
		 * Time
		 */
	
			'friendlytime:justnow' => "práve teď",
			'friendlytime:minutes' => "před %s minutami",
			'friendlytime:minutes:singular' => "před minutou",
			'friendlytime:hours' => "před %s hodinami",
			'friendlytime:hours:singular' => "před hodinou",
			'friendlytime:days' => "před %s dny",
			'friendlytime:days:singular' => "včera",
	
			'date:month:01' => '%s Ledna',
			'date:month:02' => '%s Února',
			'date:month:03' => '%s Března',
			'date:month:04' => '%s Dubna',
			'date:month:05' => '%s Května',
			'date:month:06' => '%s Června',
			'date:month:07' => '%s Července',
			'date:month:08' => '%s Srpna',
			'date:month:09' => '%s Září',
			'date:month:10' => '%s Říjena',
			'date:month:11' => '%s Listopadu',
			'date:month:12' => '%s Prosince',
	
	
		/**
		 * Installation and system settings
		 */
	
			'installation:error:htaccess' => "Elgg vyžduje soubor nazvaný .htaccess umístěný v kořenovém adresáři instalace. Pokusili jsme se ho vytvořit pro vás, ale Elgg nemá přístupová práva k zápisu do adresáře. 

Vytvoření souboru je snadné. Zkopírujte obsah uvedeného textu do textové editoru a uložte ho v příslušném adresáři jako .htaccess

",
			'installation:error:settings' => "Elgg nemůže najít soubor s nastavením. Většinu nastavení si Elgg nastaví sám ale potřebuje vaše udaje o databázi. Toto se provede následujícím způsobem:

1. Přejmenujte engine/settings.example.php na settings.php v instalačním adresáři Elgg.

2. Otevřete tento soubor v textovém editoru a vyplňte detaily MySQL databáze. Pokud je neznáte, zeptejte se systémového administrátora nebo technické podpory.

Anebo, vyplňte naledující údaje tady a my se to pokusíme udělat pro vás...",
	
			'installation:error:configuration' => "Jakmile opravíte nastavení, zmáčkněte aktualizovat a zkuste to znovu.",
	
			'installation' => "Instalace",
			'installation:success' => "Databáze Elgg byla nainstalována úspěšně.",
			'installation:configuration:success' => "Vaše výchozí nastavení bylo uloženo. Nyní registrujte prvního uživatele; tento uživatel se stane systémovým administrátorem.",
	
			'installation:settings' => "Systémová nastavení",
			'installation:settings:description' => "Nyní je databáze Elgg úspěšně nainstalovaná. Ješte potřebujeme vyplnit pár informací pro dokončení instalace. Snažili jsme se vaše nastavení odhadnout, ale <b>měl by jste tyto údaje překontrolovat a doplnit.</b>",
	
			'installation:settings:dbwizard:prompt' => "Vyplňte nastavení databáze a zmáčkněte uložit:",
			'installation:settings:dbwizard:label:user' => "Uživateké jméno databáze",
			'installation:settings:dbwizard:label:pass' => "Heslo databáze",
			'installation:settings:dbwizard:label:dbname' => "Elgg databáze",
			'installation:settings:dbwizard:label:host' => "Hostname databáze (obvykle 'localhost')",
			'installation:settings:dbwizard:label:prefix' => "Prefix tabulky databáze (obvykle 'elgg')",
	
			'installation:settings:dbwizard:savefail' => "Nelze uložit settings.php. Prosím, uložte následující text pomocí textového editoru do engine/settings.php.",
	
			'installation:sitename' => "Jméno vaší sítě (např. \"Moje sociální síť\"):",
			'installation:sitedescription' => "Hrubý popis vaší sítě (nepovinné)",
			'installation:wwwroot' => "URL sítě, ukončena lomítkem:",
			'installation:path' => "Celá cesta do síťového rootu na vašem disku, ukončena lomítkem:",
			'installation:dataroot' => "Celá cesta do adresáře kde budou uloženy všechny nahrané soubory, ukončena lomítkem:",
			'installation:dataroot:warning' => "Tento adresář musí být vytvořen ručne. Měl by být umístěn v jiném adresáři než instalace Elgg.",
			'installation:sitepermissions' => "Výchozí úroveň přístupu:",
			'installation:language' => "Výchozí jazyk sítě:",
			'installation:debug' => "Debugovací režim poskytuje dodatečné informace, které mužou být použity pro diagnostiku chyb. Nicméně tento režim zpomaluje systém a měl by být použit pouze v případě nějakých problémů:",
			'installation:debug:label' => "Zapnout debug režim",
			'installation:httpslogin' => "Zapnout přihlašování přes HTTPS. Ke správné funkci potřebujete aby bylo https zapnuté na vašem serveru.",
			'installation:httpslogin:label' => "Zapnout HTTPS přihlašování",
			'installation:usage' => "Toto nastavení umožní zasílat anonymní statistické údaje zpět do Curverider.",
			'installation:usage:label' => "Zasílat anonymní statistiku",
			'installation:view' => "Zadejte, který vzhled bude použit jako výchozí pro tuto síť nebo nechte tuto položku přázdnou (v případě pochyb to nechte, tak jak to je):",

			'installation:siteemail' => "Emailová adresa sítě (bude používána pro systémové emaily)",
	
			'installation:disableapi' => "RESTful API je flexibilní a rozšiřovatelné rozhraní, které umožní aplikacím používat nekteré funkce Elgg na dálku.",
			'installation:disableapi:label' => "Zapnout RESTful API",
			
			'installation:allow_user_default_access:description' => "Pokud je tato volba zapnuta, tak to umožní jednotlivým uživatelům nastavit jejich vlastní přístupová práva, která nahradí výchozí systémová práva.",
			'installation:allow_user_default_access:label' => "Povolit uživatelům výchozí přistupové práva",
	
			'installation:simplecache:description' => "Jednoduchá cache, která zvýší výkon cachovováním statického obsahu včetně CSS a JavaScript souborů. Tuto volbu je dobré mít zapnutou.",
			'installation:simplecache:label' => "Použít jednoduchou cache (doporučeno)",
	
			'installation:viewpathcache:description' => "Použitím cache pro cesty k souborů mse sníží čas pro nahrátí pluginů .",
			'installation:viewpathcache:label' => "Použít cache pro cesty k souborů (doporučeno)",
	
			'upgrading' => 'Aktualizuji',
			'upgrade:db' => 'Vaše databáze byla aktualizována.',
			'upgrade:core' => 'Vaše ibnstalace elgg byla aktualizovaána',
	
		/**
		 * Welcome
		 */
	
			'welcome' => "Vítejte",
			'welcome:user' => 'Vítejte %s',
			'welcome_message' => "Vítejte v instalaci Elgg.",
	
		/**
		 * Emails
		 */
			'email:settings' => "Nastavení emailu",
			'email:address:label' => "Tvoje emailová adresa",
			
			'email:save:success' => "Nová emailová adresa byla uložena, proveďte ověření.",
			'email:save:fail' => "Vaši novou emailovou adresu nelze uložit.",
	
			'friend:newfriend:subject' => "%s vás přidal(a) mezi přátele!",
			'friend:newfriend:body' => "%s vás přidal(a) mezi přátele!

Jeho(její) profil zobrazíte, kliknutím zde:

	%s

Na tento email nelze odpovědět.",
	
	
	
			'email:resetpassword:subject' => "Heslo bylo resetováno!",
			'email:resetpassword:body' => "Zdravím %s,
			
Tvoje heslo bylo nastaveno zpět na: %s",
	
	
			'email:resetreq:subject' => "Požadavek na změnu hesla.",
			'email:resetreq:body' => "Zdravím %s,
			
Někdo (z IP adresy %s) požádal o změnu hesla vašeho účtu.

Pokud je to váš požadavek, tak klikněte na níže uvedený odkaz. Pokud to nebyl váš požadavek, tak ignorujte tento email.

%s
",

		/**
		 * user default access
		 */
	
		'default_access:settings' => "Vaše výchozí přístupové oprávnění",
		'default_access:label' => "Výchozí přístupové oprávnění",
		'user:default_access:success' => "Vaše výchozí přístupové oprávnění bylo uloženo.",
		'user:default_access:failure' => "Vaše výchozí přístupové oprávnění nelze uložit.",
	
		/**
		 * XML-RPC
		 */
			'xmlrpc:noinputdata'	=>	"Chybějí vstupní data",
	
		/**
		 * Comments
		 */
	
			'comments:count' => "%s komentářů",
			
			'riveraction:annotation:generic_comment' => '%s komentovalo %s',
	
			'generic_comments:add' => "Přidat komentář",
			'generic_comments:text' => "Komentář",
			'generic_comment:posted' => "Tvůj komentář byl úspěšně odeslán.",
			'generic_comment:deleted' => "Tvůj komentář byl úspěšně smazán.",
			'generic_comment:blank' => "Omlouváme se; váš komentář musí něco obsahovat, aby mohl být uložen.",
			'generic_comment:notfound' => "Omlouváme se; nelze najít specifikovanou položku.",
			'generic_comment:notdeleted' => "Omlouváme se; nelze smazat tento komentář.",
			'generic_comment:failure' => "Při vkládaní vašeho komentáře, nastala neočakávaná chyba. Prosím zkuste to znova.",
	
			'generic_comment:email:subject' => 'Máte nový komentář!',
			'generic_comment:email:body' => "Máte nový komentář k \"%s\" od %s. V něm stojí:

			
%s


Na komentář odpovíte, kliknutím zde:

	%s

Pro zobrazení profilu %s, klikměnte zde:

	%s

Na tento email nelze odpovědet.",
	
		/**
		 * Entities
		 */
			'entity:default:strapline' => '%s vytvořeno %s',
			'entity:default:missingsupport:popup' => 'Tuto entitu nelze zobrazovat správně. To může být tím, že k tomu potřebuje plugin, který už není nainstalován.',
	
			'entity:delete:success' => 'Entita %s byla smazána',
			'entity:delete:fail' => 'Entitu %s nelze smazat',
	
	
		/**
		 * Action gatekeeper
		 */
			'actiongatekeeper:missingfields' => 'Form is missing __token or __ts fields',
			'actiongatekeeper:tokeninvalid' => "We encountered an error (token mismatch). This probably means that the page you were using expired. Please try again.",
			'actiongatekeeper:timeerror' => 'Platnost stránky, kterou používáte vypšela. Znovunačtěte stránku a zkuste to znova.',
			'actiongatekeeper:pluginprevents' => 'A extension has prevented this form from being submitted.',
	
		/**
		 * Word blacklists
		 */
			'word:blacklist' => 'a, the, pak, ale, ona, jeho, její, jemu, one, not, tské, okolo, nyní, proto, nicméněr, stále, jako, jinak, nejspíš, naopak, spíš, následně, více, nicméně, jinak, mezitím, podle, toto, zdáse, co, komu, koho, jakkoli, kdokoli',
	
		/**
		 * Languages according to ISO 639-1
		 */
			"aa" => "Afar",
			"ab" => "Abkhazian",
			"af" => "Afrikaans",
			"am" => "Amharic",
			"ar" => "Arabic",
			"as" => "Assamese",
			"ay" => "Aymara",
			"az" => "Azerbaijani",
			"ba" => "Bashkir",
			"be" => "Byelorussian",
			"bg" => "Bulharsky",
			"bh" => "Bihari",
			"bi" => "Bislama",
			"bn" => "Bengali; Bangla",
			"bo" => "Tibetan",
			"br" => "Breton",
			"ca" => "Catalan",
			"co" => "Corsican",
			"cs" => "Žádný",
			"cy" => "Welsh",
			"da" => "Danish",
			"de" => "Německy",
			"dz" => "Bhutani",
			"el" => "Řecky",
			"en" => "Česky",
			"eo" => "Esperanto",
			"es" => "Španělsky",
			"et" => "Estonsnky",
			"eu" => "Basque",
			"fa" => "Persian",
			"fi" => "Finnish",
			"fj" => "Fiji",
			"fo" => "Faeroese",
			"fr" => "Francousky",
			"fy" => "Frisian",
			"ga" => "Irish",
			"gd" => "Scots / Gaelic",
			"gl" => "Galician",
			"gn" => "Guarani",
			"gu" => "Gujarati",
			"he" => "Hebrew",
			"ha" => "Hausa",
			"hi" => "Hindi",
			"hr" => "Chorvatsky",
			"hu" => "Hungarian",
			"hy" => "Armenian",
			"ia" => "Interlingua",
			"id" => "Indonesian",
			"ie" => "Interlingue",
			"ik" => "Inupiak",
			//"in" => "Indonesian",
			"is" => "Icelandic",
			"it" => "Italsky",
			"iu" => "Inuktitut",
			"iw" => "Hebrew (obsolete)",
			"ja" => "Japanese",
			"ji" => "Yiddish (obsolete)",
			"jw" => "Javanese",
			"ka" => "Georgian",
			"kk" => "Kazakh",
			"kl" => "Greenlandic",
			"km" => "Cambodian",
			"kn" => "Kannada",
			"ko" => "Korean",
			"ks" => "Kashmiri",
			"ku" => "Kurdish",
			"ky" => "Kirghiz",
			"la" => "Latin",
			"ln" => "Lingala",
			"lo" => "Laothian",
			"lt" => "Lithuanian",
			"lv" => "Latvian/Lettish",
			"mg" => "Malagasy",
			"mi" => "Maori",
			"mk" => "Macedonian",
			"ml" => "Malayalam",
			"mn" => "Mongolian",
			"mo" => "Moldavian",
			"mr" => "Marathi",
			"ms" => "Malay",
			"mt" => "Maltese",
			"my" => "Burmese",
			"na" => "Nauru",
			"ne" => "Nepali",
			"nl" => "Dutch",
			"no" => "Norwegian",
			"oc" => "Occitan",
			"om" => "(Afan) Oromo",
			"or" => "Oriya",
			"pa" => "Punjabi",
			"pl" => "Polsky",
			"ps" => "Pashto / Pushto",
			"pt" => "Portuguese",
			"qu" => "Quechua",
			"rm" => "Rhaeto-Romance",
			"rn" => "Kirundi",
			"ro" => "Romanian",
			"ru" => "Rusky",
			"rw" => "Kinyarwanda",
			"sa" => "Sanskrit",
			"sd" => "Sindhi",
			"sg" => "Sangro",
			"sh" => "Serbo-Croatian",
			"si" => "Singhalese",
			"sk" => "Slovensky",
			"sl" => "Slovinsky",
			"sm" => "Samoan",
			"sn" => "Shona",
			"so" => "Somali",
			"sq" => "Albanian",
			"sr" => "Srbsky",
			"ss" => "Siswati",
			"st" => "Sesotho",
			"su" => "Sundanese",
			"sv" => "Švédsky",
			"sw" => "Swahili",
			"ta" => "Tamil",
			"te" => "Tegulu",
			"tg" => "Tajik",
			"th" => "Thai",
			"ti" => "Tigrinya",
			"tk" => "Turkmen",
			"tl" => "Tagalog",
			"tn" => "Setswana",
			"to" => "Tonga",
			"tr" => "Turkish",
			"ts" => "Tsonga",
			"tt" => "Tatar",
			"tw" => "Twi",
			"ug" => "Uigur",
			"uk" => "Ukrajinsky",
			"ur" => "Urdu",
			"uz" => "Uzbek",
			"vi" => "Vietnamese",
			"vo" => "Volapuk",
			"wo" => "Wolof",
			"xh" => "Xhosa",
			//"y" => "Yiddish",
			"yi" => "Yiddish",
			"yo" => "Yoruba",
			"za" => "Zuang",
			"zh" => "Chinese",
			"zu" => "Zulu",
	);
	
	add_translation("en",$english);

?>
