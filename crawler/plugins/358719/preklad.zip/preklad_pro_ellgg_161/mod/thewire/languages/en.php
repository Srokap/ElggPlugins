<?php

	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'thewire' => "Vzkazy",
			'thewire:user' => "vzkazy od %s",
			'thewire:posttitle' => "%s vzkazy na: %s",
			'thewire:everyone' => "Všechny příspěvky ve vzkazech",
	
			'thewire:read' => "Příspěvky ve vzkazech",
			
			'thewire:strapline' => "%s",
	
			'thewire:add' => "Poslat do vzkazů",
		    'thewire:text' => "příspěvek ve vzkazech",
		    'thewire:text' => "příspěvek ve vzkazech",
			'thewire:reply' => "Odpovědět",
			'thewire:via' => "přes",
			'thewire:wired' => "Odesláno do vzkazů",
			'thewire:charleft' => "zbívajících znaků",
			'item:object:thewire' => "Příspěvky ve vzkazech",
			'thewire:notedeleted' => "příspěvek smazán",
			'thewire:doing' => "Řekni všem ve vzkazech (např. co zrovna dělás):",
			'thewire:newpost' => 'Nový příspěvek',
			'thewire:addpost' => 'Odeslat příspěvek',

	
        /**
	     * The wire river
	     **/
	        
	        //generic terms to use
	        'thewire:river:created' => "odeslal %s",
	        
	        //these get inserted into the river links to take the user to the entity
	        'thewire:river:create' => "přidat do vzkazů",
	        
	    /**
	     * Wire widget
	     **/
	     
	        'thewire:sitedesc' => 'Tato miniaplikace zobrazuje nejnovější příspěvky ve vzkazech',
	        'thewire:yourdesc' => 'Tato miniaplikace zobrazuje vaše nejnovější příspěvky ve vzkazech',
	        'thewire:friendsdesc' => 'Tato miniaplikace zobrazuje nejnovější příspěvky vašich přátel ve vzkazech',
	        'thewire:friends' => 'Vaši přátelé ve vzkazech',
	        'thewire:num' => 'Počet zobrazených položek',
	        
	        
	
		/**
		 * Status messages
		 */
	
			'thewire:posted' => "Vaš příspěvek byl úspěšně uložen do vzkazů.",
			'thewire:deleted' => "Vaš příspěvek byl úspěšně smazán.",
	
		/**
		 * Error messages
		 */
	
			'thewire:blank' => "Omlouváme se; aby vzkaz mohl být odeslán, musí nejdříve něco obsahovat.",
			'thewire:notfound' => "Omlouváme se; specifikovaný vzkaz nelze najít.",
			'thewire:notdeleted' => "Omlouváme se; tento zkaz nelze smazat.",
	
	
		/**
		 * Settings
		 */
			'thewire:smsnumber' => "Vaše číslo SMS je jiné než číslo vašeho mobilního telefonu (aby vzkazy mohly pouzivat vaše mobilní číslo, tak musí být nastaveno jako veřejné). Všechna telefoní čísla musí být v mezinárodním formátu.",
			'thewire:channelsms' => "Číslo pro zasílání SMS zpráv je <b>%s</b>",
			
	);
					
	add_translation("en",$english);

?>