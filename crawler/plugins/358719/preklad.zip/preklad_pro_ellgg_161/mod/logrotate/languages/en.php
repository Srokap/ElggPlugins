<?php
	/**
	 * Elgg log rotator language pack.
	 * 
	 * @package ElggLogRotate
	 * @author Curverider Ltd
	 * @link http://elgg.com/
	 */

	$english = array(
		'logrotate:period' => 'Jak často by měly být systémové záznamy archivovány?',
	
		'logrotate:weekly' => 'Jednou týdně',
		'logrotate:monthly' => 'Jednou měsíčně',
		'logrotate:yearly' => 'Jednou ročně',
	
		'logrotate:logrotated' => "Záznam byl otočen\n",
		'logrotate:lognotrotated' => "Chyba při otáčení záznamu\n",
	);
					
	add_translation("en",$english);
?>