<?php
	/**
	 * Email user validation plugin language pack.
	 * 
	 * @package ElggUserValidationByEmail
	 * @author Curverider Ltd
	 * @link http://elgg.com/
	 */

	$english = array(
	
		'email:validate:subject' => "%s prosím potvrďte vaší emailovou adresu!",
		'email:validate:body' => "Zdravím %s,

protvrďte prosím svoji emailovou adresu, kliknutí na následující odkaz:

%s
",
		'email:validate:success:subject' => "Email by potvrzen %s!",
		'email:validate:success:body' => "Zdravím %s,
			
Gratuluji, vaše emailová adresa byla úspěšně potvrzena.",
	
		
		'email:confirm:success' => "Vaše emailová adresa byla potvrzena!",
		'email:confirm:fail' => "Vaši emailovou adresu nelze potvrdit...",
	
		'uservalidationbyemail:registerok' => "Váš účet bude aktivován, kliknutím na odkaz, který byl zaslán na váš email."
	
	);
					
	add_translation("en",$english);
?>