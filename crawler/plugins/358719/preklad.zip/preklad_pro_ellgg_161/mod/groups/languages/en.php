<?php
	/**
	 * Elgg groups plugin language pack
	 * 
	 * @package ElggGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	$english = array(
	
		/**
		 * Menu items and titles
		 */
			
			'groups' => "Skupiny",
			'groups:owned' => "Skupiny, které vlastníte",
			'groups:yours' => "Vaše skupiny",
			'groups:user' => "skupiny od %s",
			'groups:all' => "skupiny v celé síti",
			'groups:new' => "Vytvořit novou skupinu",
			'groups:edit' => "Upravit skupinu",
			'groups:delete' => 'Smazat skupinu',
			'groups:membershiprequests' => 'Spravovat žádosti o připojení',
	
			'groups:icon' => 'Ikona skupiny (pokud ji nechcete měnit nechte pole prázné)',
			'groups:name' => 'Jméno skupiny',
			'groups:username' => 'Skrácené jméno skupiny (bude zobrazeno v URLs, pouze písmena latinské abecedy)',
			'groups:description' => 'Popis',
			'groups:briefdescription' => 'Stručný popis',
			'groups:interests' => 'Označení',
			'groups:website' => 'Webové stránky',
			'groups:members' => 'Členové skupiny',
			'groups:membership' => "Přístupové povolení pro členy skupiny",
			'groups:access' => "Přístupové povolení",
			'groups:owner' => "Vlastník",
	        'groups:widget:num_display' => 'Počet zobrazených skupin',
	        'groups:widget:membership' => 'Členství ve skupině',
	        'groups:widgets:description' => 'Zobrazí skupiny, ve kterých jsi členem',
			'groups:noaccess' => 'Do skupiny nemáte přístup',
			'groups:cantedit' => 'Tuto skupinu nemůžete editovat',
			'groups:saved' => 'Skupina byla uložena',
			'groups:featured' => 'Prezentované skupiny',
			'groups:makeunfeatured' => 'Odebrad z prezentovanych skupin',
			'groups:makefeatured' => 'Přidat do prezentovanych skupin',
			'groups:featuredon' => 'Tato skupina byla zařazena mezi prezentované.',
			'groups:unfeature' => 'Tato skupina byla odebrána z prezentovaných.',
			'groups:joinrequest' => 'Zažádat o členství',
			'groups:join' => 'Připojit se ke skupině',
			'groups:leave' => 'Opustit skupinu',
			'groups:invite' => 'Pozvat přátele',
			'groups:inviteto' => "Pozvat přátele do '%s'",
			'groups:nofriends' => "Nemáte už zádné přátele, které jste ješte nepozval do této skupiny.",
			'groups:viagroups' => "přes skupiny",
			'groups:group' => "Skupina",
	
			'groups:notfound' => "Skupina nebyla nalezena",
			'groups:notfound:details' => "Požadovaná skupina buďto neexistuje nebo do ní nemáte povolen přístup",
			
			'groups:requests:none' => 'V tuto chvíli už nejsou žádné zbývající žádosti o členství.',
	
			'item:object:groupforumtopic' => "Diskutované témata",
	
			'groupforumtopic:new' => "Nový diskuzní příspěvek",
			
			'groups:count' => "vytvořených skupin",
			'groups:open' => "otevřených skupin",
			'groups:closed' => "uzavřených skupin",
			'groups:member' => "členů",
			'groups:searchtag' => "Hledat skupiny podle označení",
	
			
			/*
			 * Access
			 */
			'groups:access:private' => 'Uzavřená - Uživatelé musí být pozváni',
			'groups:access:public' => 'Otevřená - Jakýkoliv uživatel se může připojit',
			'groups:closedgroup' => 'Tato skupina má uzavřené členství. O přijetí požádáte, kliknutím v menu na "požádat o členství".',
			'groups:visibility' => 'Kdo může vidět tuto skupinu?',
	
			/*
			   Group tools
			*/
			'groups:enablepages' => 'Povolit skupinové stránky',
			'groups:enableforum' => 'Povolit skupinovou diskuzi',
			'groups:enablefiles' => 'Povolit skupinové soubory',
			'groups:yes' => 'ano',
			'groups:no' => 'ne',
	
			'group:created' => 'Vytvořeno %s s %d příspěvky',
			'groups:lastupdated' => 'Naposledy aktualizováno %s od %s',
			'groups:pages' => 'Skupinové stránky',
			'groups:files' => 'Skupinové soubory',
	
			/*
			  Group forum strings
			*/
			
			'group:replies' => 'Odpovědí',
			'groups:forum' => 'Skupinová diskuze',
			'groups:addtopic' => 'Přidat téma',
			'groups:forumlatest' => 'Poslední diskuze',
			'groups:latestdiscussion' => 'Poslední diskuze',
			'groups:newest' => 'Nejnovější',
			'groups:popular' => 'Populární',
			'groupspost:success' => 'Váš komentář by byl úspěšně odeslán',
			'groups:alldiscussion' => 'Poslední diskuze',
			'groups:edittopic' => 'Upravit téma',
			'groups:topicmessage' => 'Popis tématu (povinné jinak se téma nevytvoří)',
			'groups:topicstatus' => 'Status tématu',
			'groups:reply' => 'Poslat komentář',
			'groups:topic' => 'Téma',
			'groups:posts' => 'Příspěvky',
			'groups:lastperson' => 'Poslední člen',
			'groups:when' => 'Kdy',
			'grouptopic:notcreated' => 'Žádné téma nebylo vytvořeno.',
			'groups:topicopen' => 'Otevřené',
			'groups:topicclosed' => 'Zavřené',
			'groups:topicresolved' => 'Znovuotevřené',
			'grouptopic:created' => 'Vaše téma bylo vytvořeno.',
			'groupstopic:deleted' => 'Téma bylo vymazáno.',
			'groups:topicsticky' => 'Navrchu',
			'groups:topicisclosed' => 'Toto téma je uzavřené.',
			'groups:topiccloseddesc' => 'Toto téma bylo uzavřené a nepřijímá nové komentáře.',
			'grouptopic:error' => 'Vaše skupinové téma nemohlo být vytvořeno. Prosím zkuste to znova nebo kontaktujte systémového administrátora.',
			'groups:forumpost:edited' => "Uspěšně jsi upravil příspěvek ve foru.",
			'groups:forumpost:error' => "Při editaci příspěvku ve foru nastal problem.",
			'groups:privategroup' => 'Tato skupina je soukromá (vyžaduje členství).',
			'groups:notitle' => 'Skupina musí mít název',
			'groups:cantjoin' => 'Nelze se připojit ke skupině',
			'groups:cantleave' => 'Nelze opustit skupinu',
			'groups:addedtogroup' => 'Uživatel byl uspěšně přidán ke skupině',
			'groups:joinrequestnotmade' => 'Nelze zažádat o přijetí',
			'groups:joinrequestmade' => 'Žádost o přijetí proběhla úspěšně',
			'groups:joined' => 'Připojení ke skupině proběhlo úspěšně!',
			'groups:left' => 'Odpojení od skupiny proběhlo úspěšně!',
			'groups:notowner' => 'Omlouváme se, nejste vlastník této skupiny.',
			'groups:alreadymember' => 'Vy už jste členem této skupiny!',
			'groups:userinvited' => 'Uživatel byl pozvám.',
			'groups:usernotinvited' => 'Uživatel nemůže býl pozván.',
			'groups:useralreadyinvited' => 'Uživatel byl už pozván.',
			'groups:updated' => "Poslední komentář",
			'groups:invite:subject' => "%s byl pozván aby se připojil k %s!",
			'groups:started' => "Započato",
			'groups:joinrequest:remove:check' => 'Jste si jist, že chcete smazat tento požadavek o přijetí?',
			'groups:invite:body' => "Zdravím %s,

Byl(a) jste pozván(a), aby jste se připojil(a) ke skupině '%s'. Kliknutím, potvrdíte přijetí:

%s",

			'groups:welcome:subject' => "Vítejte do skupiny %s!",
			'groups:welcome:body' => "Zdravím %s!
		
Nyní jste členem skupiny '%s'! Kliknutím, můzěte začít vkládat příspěvky!

%s",
	
			'groups:request:subject' => "%s požádal o přijetí do %s",
			'groups:request:body' => "Zdravím %s,

%s požádal o přijetí do skupiny '%s'. Kliknutím zabrazíte jeho(její) profil:

%s

nebo můžete potvdit žádost:

%s",
	
            /*
				Forum river items
			*/
	
			'groups:river:member' => 'je nyní členem',
			'groupforum:river:updated' => '%s bylo aktualizovano',
			'groupforum:river:update' => 'toto diskuzní téma',
			'groupforum:river:created' => '%s bylo vytvořeno',
			'groupforum:river:create' => 'nové diskuzní téma nazvané',
			'groupforum:river:posted' => '%s odeslal nový komentář',
			'groupforum:river:annotate:create' => 'v tomto diskuzním tématu',
			'groupforum:river:postedtopic' => '%s začal nové diskuzní téma, nazvané',
			'groups:river:member' => '%s je nyní člen',
	
			'groups:nowidgets' => 'Žádné miniaplikace nebyly definovány pro tuto skupinu.',
	
	
			'groups:widgets:members:title' => 'Členové skupiny',
			'groups:widgets:members:description' => 'Zobrazit seznam členů v této skupině.',
			'groups:widgets:members:label:displaynum' => 'Zobrazit seznam členů v této skupině.',
			'groups:widgets:members:label:pleaseedit' => 'Prosím potvrďte tuto miniaplikaci.',
	
			'groups:widgets:entities:title' => "Položky ve skupině",
			'groups:widgets:entities:description' => "Zobrazit seznam uložených položek v této skupině",
			'groups:widgets:entities:label:displaynum' => 'Zobrazit seznam položek v této skupině.',
			'groups:widgets:entities:label:pleaseedit' => 'Prosím potvrďte tuto miniaplikaci.',
		
			'groups:forumtopic:edited' => 'Téma ve fóru bylo úspěšně editováno.',
	
			'groups:allowhiddengroups' => 'Chcete povolit soukromé (neviditelné) skupiny?',
	
			/**
			 * Action messages
			 */
			'group:deleted' => 'Skupina a její obsah byl smazán',
			'group:notdeleted' => 'Skupina nemohla být smazána',
	
			'grouppost:deleted' => 'Skupinový příspěvek byl úspěšně smazán',
			'grouppost:notdeleted' => 'Skupinový příspěvek nelze smazat',
			'groupstopic:deleted' => 'Téma bylo smazáno',
			'groupstopic:notdeleted' => 'Téma nebylo smazáno',
			'grouptopic:blank' => 'Žádné téma',
			'groups:deletewarning' => "Jste si jistý, že chcete smazat tuto skupinu? Tato akce nelze vrátit zpět!",
	
			'groups:joinrequestkilled' => 'Požadavek o přijetí byl smazán.',
	);
					
	add_translation("en",$english);
?>