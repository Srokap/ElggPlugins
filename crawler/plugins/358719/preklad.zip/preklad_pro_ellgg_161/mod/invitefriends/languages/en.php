<?php

	/**
	 * Elgg invite page
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @link http://elgg.org/
	 */

	$english = array(

		'friends:invite' => 'Pozvat přátele',
		'invitefriends:introduction' => 'Zadejte emailové adresy přátel (jedna na jeden řádek), které chcete pozvat do této sítě:',
		'invitefriends:message' => 'Zadejte zprávu, kterou obdrží společne s pozvánkou:',
		'invitefriends:subject' => 'Pozvánka do %s',
	
		'invitefriends:success' => 'Vaši přátelé byli pozváni.',
		'invitefriends:failure' => 'Vaše přátelé nelze pozvat.',
	
		'invitefriends:message:default' => '
Zdravím,

rád bych vás pozval do mé sítě %s.',
		'invitefriends:email' => '
Byl(a) jste pozván(a) %s do sítě %s. K vaší pozvánce byla připojena tato zpráva:

%s

Pokud se chcete připojit, tak klikněte na následující odkaz:

	%s

Tímto budete automacticky zaregistrováni jako přátelé při vytvoření účtu.',
	
	);
					
	add_translation("en",$english);
?>