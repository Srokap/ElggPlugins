<?php

$english = array (

	/**
	 * Nice name for the entity (shown in admin panel)
	 */
	'item:object:moddefaultwidgets' => 'Výchozí nastavení miniaplikací',

	/**
	 * Menu items
	 */
	'defaultwidgets:menu:profile' => 'Výchozí miniaplikace profilu',
    'defaultwidgets:menu:dashboard' => 'Výchozí miniaplikace událostí',

    'defaultwidgets:admin:error' => 'Chyba: Nejste přihlášen jako administrátor',
	'defaultwidgets:admin:notfound' => 'Chyba: Stránka nenalezena',
	'defaultwidgets:admin:loginfailure' => 'Varování: Nejste přihlášen jako administrátor',

	'defaultwidgets:update:success' => 'Nastavení vaší miniaplikace bylo uloženo',
	'defaultwidgets:update:failed' => 'Chyba: nastavení nelze uložit',
	'defaultwidgets:update:noparams' => 'Chyba: špatně vyplněné parametry',

	'defaultwidgets:profile:title' => 'Nastavit výchozí miniaplikace pro stránky s profilem nového uživatele',
	'defaultwidgets:dashboard:title' => 'Nastavit výchozí miniaplikace pro stránky s nástěnkou nového uživatele',
);

add_translation ( "en", $english );
