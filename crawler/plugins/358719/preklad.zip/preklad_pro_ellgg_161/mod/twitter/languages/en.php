<?php

	$english = array(
	
		/**
		 * twitter widget details
		 */
		
	
		'twitter:username' => 'Vložte vaše uživatelské jméno na twitteru.',
		'twitter:num' => 'Počet zobrazených členů tweettru.',
		'twitter:visit' => 'navštívit můj twitter',
		'twitter:notset' => 'Tato miniaplikace Twitter ješte není nakonfigurována. Pro zobrazení nejnovějších členů twitteru, klikněte na upravit a vyplňte vaše detaily',
		
		
		 /**
	     * twitter widget river
	     **/
	        
	        //generic terms to use
	        'twitter:river:created' => "%s přidal miniaplikaci twitter.",
	        'twitter:river:updated' => "%s miniaplikace twitter byla aktualizována.",
	        'twitter:river:delete' => "%s odebral miniaplikaci twitter.",
	        
		
	);
					
	add_translation("en",$english);

?>