<?php

	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'bookmarks' => "Záložky",
			'bookmarks:add' => "Přidej záložku",
			'bookmarks:read' => "%s si založil tyto položky",
			'bookmarks:friends' => "Záložky přátel",
			'bookmarks:everyone' => "Záložky z celé sítě",
			'bookmarks:this' => "Přidej do záložek",
			'bookmarks:this:group' => "Záložka v %s",
			'bookmarks:bookmarklet' => "Získat bookmarklet",
			'bookmarks:bookmarklet:group' => "Získat bookmarklet skupiny",
			'bookmarks:inbox' => "Schránka záložek",
			'bookmarks:more' => "Více",
			'bookmarks:shareditem' => "Položka se záložkou",
			'bookmarks:with' => "Sdílet s",
			'bookmarks:new' => "Nová záložka",
			'bookmarks:via' => "přes záložky",
			'bookmarks:address' => "adresa položky v záložce",
	
			'bookmarks:delete:confirm' => "Jste si jisti, že chcete smazat tuto položku?",
	
			'bookmarks:numbertodisplay' => 'Počet zobrazených položek se záložkou',
	
			'bookmarks:shared' => "Položky se záložkou",
			'bookmarks:visit' => "Navštívit položku",
			'bookmarks:recent' => "Nejnovější záložky",
	
			'bookmarks:river:created' => 'pro %s byla vytvořena záložka',
			'bookmarks:river:annotate' => 'byl přidán komentář k položce se záložkou',
			'bookmarks:river:item' => 'položka',
	
			'item:object:bookmarks' => 'Položky se záložkou',
	
			'bookmarks:group' => 'Skupinové záložky',
			'bookmarks:enablebookmarks' => 'Zapnout skupinové záložky',
	
	
		/**
		 * More text
		 */
		    
		    'bookmarks:widget:description' => 
		            "Tato miniaplikace je navržena pro nástěnku, kde zobrazí nejnověji vytvořené záložky.",
	
			'bookmarks:bookmarklet:description' =>
					"Bookmarklet v záložkách vám umožní sdílet jakoukoliv stránku na internetu s vašimi přáteli anebo si ji uložit pro své potřeby. Požívá se tak, že přetáhnete následující tlačítko do panelu se záložkami ve vašem prohlížeči:",

	        'bookmarks:bookmarklet:descriptionie' =>
					"Pokud používáte Internet Explorer, tak potřebujete kliknout pravým tlačítkem na ikonu bookmarkletu a zvolit 'přidat do oblíbených' a vložte ji do panelu s odkazy.",

			'bookmarks:bookmarklet:description:conclusion' =>
					"Kdykoliv můžete uložit jakoukoliv navštívenou stránku tím, že na tento odkaz kliknete.",
	
		/**
		 * Status messages
		 */
	
			'bookmarks:save:success' => "Pro vaši položku byla úspěšně vytvořena záložka.",
			'bookmarks:delete:success' => "Záložka pro vaši položku byla úspěšne smazána.",
	
		/**
		 * Error messages
		 */
	
			'bookmarks:save:failed' => "Záložka pro vaši položku nelze uložit. Zkuste to prosím znovu.",
			'bookmarks:delete:failed' => "Záložka pro vaši položku nelze smazat. Zkuste to prosím znovu.",
	
	
	);
					
	add_translation("en",$english);

?>