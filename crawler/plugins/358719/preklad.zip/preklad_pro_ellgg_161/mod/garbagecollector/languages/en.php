<?php
	/**
	 * Elgg garbage collector language pack.
	 * 
	 * @package ElggGarbageCollector
	 * @author Curverider Ltd
	 * @link http://elgg.com/
	 */

	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'garbagecollector:period' => 'Jak často by se měl úklid Elgg spouštět?',
	
			'garbagecollector:weekly' => 'Jednou týdně',
			'garbagecollector:monthly' => 'Jednou měsíčně',
			'garbagecollector:yearly' => 'Jednou ročně',
	
			'garbagecollector' => "ÚKLID ODPADU\n",
			'garbagecollector:done' => "Hotovo\n",
			'garbagecollector:optimize' => "Optimalizuji %s ",
	
			'garbagecollector:error' => "Chyba",
			'garbagecollector:ok' => "OK",
	
			'garbagecollector:gc:metastrings' => 'Čistím nepřipojené metařetězce: ',
	
	);
					
	add_translation("en",$english);
?>