<?php

	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messageboard:board' => "Nástěnka",
			'messageboard:messageboard' => "nástěnka",
			'messageboard:viewall' => "Zobrazit vše",
			'messageboard:postit' => "Odeslat",
			'messageboard:history' => "historie",
			'messageboard:none' => "Na této nástěnce ješte nic není",
			'messageboard:num_display' => "Počet zobrazených zpáv",
			'messageboard:desc' => "Toto je nástěnka, na které mohou ostatní uživatelé zanechávat komentáře.",
	
			'messageboard:user' => "nástěnka od %s",
	
			'messageboard:history' => "Historie",
			'messageboard:replyon' => 'odpovědět',
			
         /**
	     * Message board widget river
	     **/
	        
	        'messageboard:river:annotate' => "%s napsal(a) nový komentář na své nástěnce.",
	        'messageboard:river:create' => "%s přidal(a) miniaplikaci nástěnka.",
	        'messageboard:river:update' => "%s aktualizoval(a) svoji miniaplikaci nástěnka..",
	        'messageboard:river:added' => "%s napsal příspěvek",
		    'messageboard:river:messageboard' => "nástěnka",

			
		/**
		 * Status messages
		 */
	
			'messageboard:posted' => "Příspek byl úspěšně uložen na nástěnku.",
			'messageboard:deleted' => "Příspek byl úspěšně vymazán.",
	
		/**
		 * Email messages
		 */
	
			'messageboard:email:subject' => 'Máte nový kometář na nástěnce!',
			'messageboard:email:body' => "Máte nový kometář na nástěnce od %s. V něm stojí:

			
%s


Klikne zde, pro zobrazení komentářů na nástěnce:

	%s

Klikněte zde, pro zobrazení profilu:

	%s

Na tento email nelze odpovědět.",
	
		/**
		 * Error messages
		 */
	
			'messageboard:blank' => "Omlouváme se; správa musí něco obsahovat, aby mohla být odeslána.",
			'messageboard:notfound' => "Omlouváme se; nelze najít specifikovanou položku.",
			'messageboard:notdeleted' => "Omlouváme se; tuto zprávu nelze smazat.",
			'messageboard:somethingwentwrong' => "Během odesílaní zprávy nastala chyba. Ujistěte se že obsah zprávy není prázdný.",
	     
			'messageboard:failure' => "Během odesílaní zprávy nastala neočekávaná chyba. Prosím zkuste to znova.",
	
	);
					
	add_translation("en",$english);

?>