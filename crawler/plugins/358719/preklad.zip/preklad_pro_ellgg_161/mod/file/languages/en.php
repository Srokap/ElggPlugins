<?php
	/**
	 * Elgg file plugin language pack
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'file' => "Soubory",
			'files' => "Soubory",
			'file:yours' => "Vaše soubory",
			'file:yours:friends' => "Soubory přátel",
			'file:user' => "soubory od %s",
			'file:friends' => "soubory přátel %s",
			'file:all' => "Soubory z celé sítě",
			'file:edit' => "Upravit soubor",
			'file:more' => "Více souborů",
			'file:list' => "zobrazit seznam",
			'file:group' => "Soubory skupiny",
			'file:gallery' => "zobrazit jako galerii",
			'file:gallery_list' => "Zobrazit jako galerii nebo seznam",
			'file:num_files' => "Počet zobrazených souborů",
			'file:user:gallery'=>'Zobraz galerii od %s', 
	        'file:via' => 'přes soubory',
			'file:upload' => "Uložit soubor",
	
			'file:newupload' => 'Uložit nový soubor',
			
			'file:file' => "Soubor",
			'file:title' => "Název",
			'file:desc' => "Popis",
			'file:tags' => "Označení(bez diakritiky(háčy,čárky,..))",
	
			'file:types' => "Typy uložených souborů",
	
			'file:type:all' => "Všechny soubory",
			'file:type:video' => "Videa",
			'file:type:document' => "Dokumenty",
			'file:type:audio' => "Audio",
			'file:type:image' => "Obrázky",
			'file:type:general' => "Obecné",
	
			'file:user:type:video' => "videa od %s",
			'file:user:type:document' => "dokumenty od %s",
			'file:user:type:audio' => "audio od %s",
			'file:user:type:image' => "obrázky od %s",
			'file:user:type:general' => "obecné soubory od %s",
	
			'file:friends:type:video' => "Videa vašich přátel",
			'file:friends:type:document' => "Dokumenty vašich přátel",
			'file:friends:type:audio' => "Audio vašich přátel",
			'file:friends:type:image' => "Obrázky vašich přátel",
			'file:friends:type:general' => "Obecné soubory vašich přátel",
	
			'file:widget' => "Soubory",
			'file:widget:description' => "Zobrazí vaše nejnovější soubory",
	
			'file:download' => "Stáhni to",
	
			'file:delete:confirm' => "Jste si jisti, že chcete smazat tento soubor?",
			
			'file:tagcloud' => "Všechna označení",
	
			'file:display:number' => "Počet zobrazených souborů",
	
			'file:river:created' => "%s uložil(a)",
			'file:river:item' => "soubor",
			'file:river:annotate' => "komentář k tomu souboru",

			'item:object:file' => 'Soubory',
			
	    /**
		 * Embed media
		 **/
		 
		    'file:embed' => "Vložit media",
		    'file:embedall' => "Vše",
	
		/**
		 * Status messages
		 */
	
			'file:saved' => "Váš soubor byl úspěšně uložen.",
			'file:deleted' => "Váš soubor byl úspěšně smazán.",
	
		/**
		 * Error messages
		 */
	
			'file:none' => "Žádné soubory nebyly nalezeny.",
			'file:uploadfailed' => "Omlouváme se; nelze uložit váš soubor.",
			'file:downloadfailed' => "Omlouváme se; soubor není aktuálně dostupný.",
			'file:deletefailed' => "Váš soubor teď nelze smazat.",
	
	);
					
	add_translation("en",$english);
?>