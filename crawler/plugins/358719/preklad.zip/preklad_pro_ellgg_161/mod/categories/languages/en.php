<?php

	$english = array(
	
		'categories' => 'Kategorie',
		'categories:settings' => 'Nastav kategorie v síti',	
		'categories:explanation' => 'Nastavení předdefinovaných kategorií, které budu společné pro celou síť. Napište je do následucí kolonky a jednolivé kategorie oddělte čárkou. Kompatibilní nástroje pak nabídnou tyto kategorie při vytváření nebo úpravě obsahu.',	
		'categories:save:success' => 'Nové kategorie byly úspěšně uloženy.',
	
	);
					
	add_translation("en",$english);

?>