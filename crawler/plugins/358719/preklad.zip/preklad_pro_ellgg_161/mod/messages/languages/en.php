<?php

	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messages' => "Zprávy",
            'messages:back' => "zpět ke zprávám",
			'messages:user' => "Vaše schránka",
			'messages:sentMessages' => "Odeslat zprávu",
			'messages:posttitle' => "%s odeslal tyto zprávy: %s",
			'messages:inbox' => "Schránka",
			'messages:send' => "Odeslat zprávu",
			'messages:sent' => "Odeslané zprávy",
			'messages:message' => "Zpráva",
			'messages:title' => "Název",
			'messages:to' => "Komu",
            'messages:from' => "Od",
			'messages:fly' => "Odeslat",
			'messages:replying' => "Zpráva je odpovědí na",
			'messages:inbox' => "Schránka",
			'messages:sendmessage' => "Poslat zprávu",
			'messages:compose' => "Napsat zprávu",
			'messages:sentmessages' => "Odeslané zprávy",
			'messages:recent' => "Nedávné zprávy",
            'messages:original' => "Původní zpráva",
            'messages:yours' => "Vaše zpráva",
            'messages:answer' => "Odpověď",
			'messages:toggle' => 'Označit vše',
			'messages:markread' => 'Označit jako přečtené',
			
			'messages:new' => 'Nová zpráva',
	
			'notification:method:site' => 'Síť',
	
			'messages:error' => 'Při ukládání zprávy nastal problém. Prosím zkuste to znova.',
	
			'item:object:messages' => 'Zprávy',
	
		/**
		 * Status messages
		 */
	
			'messages:posted' => "Vaše zpráva byla úspěšně odeslána.",
			'messages:deleted' => "Vaše zpráva byla úspěšně smazána.",
			'messages:markedread' => "Vaše zpráva byla úspěšně označená jako přečtená.",
	
		/**
		 * Email messages
		 */
	
			'messages:email:subject' => 'Máte novou zprávu!',
			'messages:email:body' => "Máte novou zprávu od %s. Ve zprávě stojí:

			
%s

Pro zobrazení vaší zprávy, kliknete zde:

	%s

Pro odeslaní zprávy %s, klikněte zde:

	%s

Na tento email nelze odpovědět.",
	
		/**
		 * Error messages
		 */
	
			'messages:blank' => "Omlouváme se; zpráva musí něco obsahovat pro to, aby mohla být odeslána.",
			'messages:notfound' => "Omlouváme se; nelze najít specifikovanou zprávu.",
			'messages:notdeleted' => "Omlouváme se; tato zpráva nelze smazat.",
			'messages:nopermission' => "Nemáte přístupová práva k tomu, aby jste mohl upravit tuto zprávu.",
			'messages:nomessages' => "Žádné zprávy k zobrazení.",
			'messages:user:nonexist' => "Příjemce nebyl nalezen v databázi uživatelů.",
			'messages:user:blank' => "Nevyplnil(a) jste příjemce.",
	
	);
					
	add_translation("en",$english);

?>