<?php

	$english = array(
	
		/**
		 * Site info details
		 */
		
		'members:members' => "Členové sítě",
	    'members:online' => "Členové, kteří jsou teď aktivní",
	    'members:active' => "členů sítě",
	    'members:searchtag' => "Hledat člena podle označení",
	    'members:searchname' => "Hledat člena podle jména",
	   
		'members:label:newest' => 'Nejnovější',
		'members:label:popular' => 'Populární',
		'members:label:active' => 'Aktivní',
		
	);
					
	add_translation("en",$english);

?>