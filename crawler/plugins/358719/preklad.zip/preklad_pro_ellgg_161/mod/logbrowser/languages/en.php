<?php
	/**
	 * Elgg log browser plugin language pack
	 * 
	 * @package ElggLogBrowser
	 * @author Curverider Ltd
	 * @link http://elgg.com/
	 */

	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'logbrowser' => 'Prohlížeč záznamů',
			'logbrowser:browse' => 'Prohlížet systémové záznamy',
			'logbrowser:search' => 'Projít záznamy',
			'logbrowser:user' => 'Hledat podle uživatele',
			'logbrowser:starttime' => 'Počáteční čas (např."poslední pondělí", "před 1 hodinou")',
			'logbrowser:endtime' => 'Konečný čas',
	
			'logbrowser:explore' => 'Prozkoumat záznam',
	
	);
					
	add_translation("en",$english);
?>