<?php

	$english = array(
	
		'friends:all' => 'Všem přátelům',
	
		'notifications:subscriptions:personal:description' => 'Tento nástroj bude posílat upozornění o akcích vykonaných s vašim obsahem',
		'notifications:subscriptions:personal:title' => 'Osobní upozorňování',
	
		'notifications:subscriptions:collections:title' => 'Označit skupiny přátel',
		'notifications:subscriptions:collections:description' => 'Pokud chcete, aby jste obdželi upozornění když někdo z vašich skupnin přátel vytvoří nový obsah, tak u těchto skupin nastavte patřičnou metodu upozorňování. Tyto změny budou aplikovány na jednotlivé přátele (ve spodním panelu přátel). ',
		'notifications:subscriptions:collections:edit' => 'Skupiny přátel upravíte, klíknutím zde.',
	
		'notifications:subscriptions:changesettings' => 'Upozorňování',
		'notifications:subscriptions:changesettings:groups' => 'Upozorňování skupin',
		'notification:method:email' => 'Email',	
	
		'notifications:subscriptions:title' => 'Upozornění podle uživatele',
		'notifications:subscriptions:description' => 'Pokud chcete, aby jste obdželi upozornění když některý z vašich přátel vytvoří nový obsah, tak u těchto přátel nastvavte patřičnou metodu upozorňování.',
	
		'notifications:subscriptions:groups:description' => 'Pokud chcete aby jste odrovali pozornění ze skupin ve kterých jste členy, tak u těchto skupin nastavte patřičnou metodu upozorňování.',
	
		'notifications:subscriptions:success' => 'Vaše nastavení upozornňování bylo uloženo.',
	
	);
					
	add_translation("en",$english);

?>