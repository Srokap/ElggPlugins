<?php

	$english = array(
	
			'custom:bookmarks' => "Nejnovější záložky",
			'custom:groups' => "Nejnovější skupiny",
			'custom:files' => "Nejnovější soubory",
			'custom:blogs' => "Nejnovější blogové příspěvky",
			'custom:members' => "Nejnovější členové",
			'custom:nofiles' => "Žádné položky zatím neexistují",
			'custom:nogroups' => "Žádné položky zatím neexistují",	
	
	);
					
	add_translation("en",$english);

?>