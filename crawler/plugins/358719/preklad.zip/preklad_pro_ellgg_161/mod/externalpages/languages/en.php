<?php

	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'expages' => "Externí stránky",
			'expages:frontpage' => "Výchozí stránka",
			'expages:about' => "O nás",
			'expages:terms' => "Podmínky",
			'expages:privacy' => "Soukromí",
			'expages:analytics' => "Analytika",
			'expages:contact' => "Kontakt",
			'expages:nopreview' => "Náhled zatím není dostupný",
			'expages:preview' => "Náhled",
			'expages:notset' => "Tato stránka ještě nebyla nastavena.",
			'expages:lefthand' => "Levý informační panel",
			'expages:righthand' => "Pravý informační panel",
			'expages:addcontent' => "Obsah lze přidávat skrze administrátorské nástroje. V administraci hledejte položku externí stránky.",
			'item:object:front' => 'Položky na výchozí stránce',
	
		/**
		 * Status messages
		 */
	
			'expages:posted' => "Váše vložená stránka byla úspěšně uložena.",
			'expages:deleted' => "Váše vložená stránka byla úspěšně smazána.",
	
		/**
		 * Error messages
		 */
	
			'expages:deleteerror' => "Při mazání vložené stránky nastal problém",
			'expages:error' => "Během akce nastala chyba. Prosím zkuste to znova. Pokud problém přetrvá, kontaktujte systémového administrátora.",
	
	);
					
	add_translation("en",$english);

?>