<?php

	$english = array(
	
		'media:insert' => 'Vložit/Uložit media',
	
		'embed:instructions' => 'Klikni na jakýkoliv soubor, který bude vložen jako obsah.',
	
		'embed:media' => 'Vlož media',
		'upload:media' => 'Ulož media',
	
		'embed:file:required' => 'Zádné nástroje pro nahrání souboru nebyly nalezeny. Systemový administrator nejspíš potřebuje nahrát potřebný plugin.',
	
	);
					
	add_translation("en",$english);

?>