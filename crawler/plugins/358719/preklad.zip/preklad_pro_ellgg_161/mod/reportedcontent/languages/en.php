<?php
	/**
	 * Elgg reported content plugin language pack
	 * 
	 * @package ElggReportedContent
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'item:object:reported_content' => 'Nahlášené položky',
			'reportedcontent' => 'Nahlášený obsah',
			'reportedcontent:this' => 'Nahlásit',
			'reportedcontent:none' => 'Žadný nahlášený obsah',
			'reportedcontent:report' => 'Nahlásit administrátorovi',
			'reportedcontent:title' => 'Nadpis stránky',
			'reportedcontent:deleted' => 'Nahlášený obsah byl smazán',
			'reportedcontent:notdeleted' => 'Toto ohlášení nelze smazat',
			'reportedcontent:delete' => 'Smazat',
			'reportedcontent:areyousure' => 'Opravdu to chcete smazat?',
			'reportedcontent:archive' => 'Archívovat',
			'reportedcontent:archived' => 'Ohlášení bylo archívováno',
			'reportedcontent:visit' => 'Navštívit reportovanou položku',
			'reportedcontent:by' => 'Nahlášeno od',
			'reportedcontent:objecttitle' => 'Název položky',
			'reportedcontent:objecturl' => 'URL položky',
			'reportedcontent:reason' => 'Důvod ohlášení',
			'reportedcontent:description' => 'Jaký je důvod ohlášení?',
			'reportedcontent:address' => 'Umístění položky',
			'reportedcontent:success' => 'Vaše ohlášení bylo odesláno administrátorovi',
			'reportedcontent:failing' => 'Vaše ohlášení nelze odeslat',
			'reportedcontent:report' => 'Nahlásit', 
			'reportedcontent:moreinfo' => 'Více informací',
	
			'reportedcontent:failed' => 'Omlouváme se, pokus o nahlášení selhal.',
			'reportedcontent:notarchived' => 'Toto ohlášení nelze archívovat',
	);
					
	add_translation("en",$english);
?>