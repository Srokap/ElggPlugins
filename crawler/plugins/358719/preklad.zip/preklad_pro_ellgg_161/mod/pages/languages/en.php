<?php
	/**
	 * Elgg pages plugin language pack
	 * 
	 * @package ElggPages
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	$english = array(
	
		/**
		 * Menu items and titles
		 */
			
			'pages' => "Stránky",
			'pages:yours' => "Vaše stránky",
			'pages:user' => "Domácí stránky",
			'pages:group' => "Skupinové stránky",
			'pages:all' => "Stránky z celé sítě",
			'pages:new' => "Novou stránku",
			'pages:groupprofile' => "Skupinové stránky",
			'pages:edit' => "Upravit tuto stránku",
			'pages:delete' => "Smazat tuto stránku",
			'pages:history' => "Historie stránky",
			'pages:view' => "Zobraz stránku",
			'pages:welcome' => "Upravit uvítání",
			'pages:welcomemessage' => "Vítejte v pluginu Stránky. Tento nástroj vám umožní vytvářet stránky na jakékoliv téma a nastavit kdo si je může prohlížet a upravovat.",
			'pages:welcomeerror' => "Při ukládání uvítací zprávy nastal problém",
			'pages:welcomeposted' => "Vaše uvítací zpráva byla uložena",
			'pages:navigation' => "Navigace na stránce",
	        'pages:via' => "přes stránky",
			'item:object:page_top' => 'Vrchní stránky',
			'item:object:page' => 'Stránky',
			'item:object:pages_welcome' => 'Uvítací blok stránek',
			'pages:nogroup' => 'Tato skupina ještě nemá žádné stránky',
			'pages:more' => 'Více stránek',
			
		/**
		* River
		**/
		
		    'pages:river:annotate' => "komentovat tyto stránky",
		    'pages:river:created' => "%s vytvořil",
	        'pages:river:updated' => "%s upravil",
	        'pages:river:posted' => "%s odeslal",
			'pages:river:create' => "novou stánku nazvanou",
	        'pages:river:update' => "stránku nazvanou",
	        'page:river:annotate' => "komentovat tuto stránku",
	        'page_top:river:annotate' => "komentovat tuto stránku",
	
		/**
		 * Form fields
		 */
	
			'pages:title' => 'Nadpis stránky',
			'pages:description' => 'Váš příspěvek na stránku',
			'pages:tags' => 'Označení(bez diakritiky(háčy,čárky,..))',	
			'pages:access_id' => 'Přístup',
			'pages:write_access_id' => 'Právo upravovat',
		
		/**
		 * Status and error messages
		 */
			'pages:noaccess' => 'Ke stránce nemáte přístup',
			'pages:cantedit' => 'Stránku nemůžete editovat',
			'pages:saved' => 'Stránky byly uloženy',
			'pages:notsaved' => 'Stránku nelze uložit',
			'pages:notitle' => 'Stránka musí mít název.',
			'pages:delete:success' => 'Vaše stránka byla úspěšně smazána.',
			'pages:delete:failure' => 'Stránku nelze smazat.',
	
		/**
		 * Page
		 */
			'pages:strapline' => 'Naposledy upraveno %s od %s',
	
		/**
		 * History
		 */
			'pages:revision' => 'Opraveno %s od %s',
			
		/**
		 * Widget
		 **/
		 
		    'pages:num' => 'Počet zobrazených stránek',
			'pages:widget:description' => "Toto je seznam vašich stránek.",
	
		/**
		 * Submenu items
		 */
			'pages:label:view' => "Zobrazit stránku",
			'pages:label:edit' => "Upravit stránku",
			'pages:label:history' => "Historie stránky",
	
		/**
		 * Sidebar items
		 */
			'pages:sidebar:this' => "Tuto stránku",
			'pages:sidebar:children' => "Podstránky",
			'pages:sidebar:parent' => "Rodič",
	
			'pages:newchild' => "Vytvořit podstránku",
			'pages:backtoparent' => "Zpět na '%s'",
	);
					
	add_translation("en",$english);
?>