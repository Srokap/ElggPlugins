<?php
	/**
	 * Elgg diagnostics language pack.
	 * 
	 * @package ElggDiagnostics
	 * @author Curverider Ltd
	 * @link http://elgg.com/
	 */

	$english = array(
	
			'diagnostics' => 'Systémová diagnostika',
			'diagnostics:unittester' => 'Test jednotky',
	
			'diagnostics:description' => 'Následující diagostický výpis je užitečný pro řešení jakýkoliv problemů s Elgg a měl by být součásti nahlášených chyb.',
			'diagnostics:unittester:description' => 'Následující diagnostické testy jsou registrované pluginy a mohou být použity za účelem odladění Elgg.',
	
			'diagnostics:test:executetest' => 'Spustit test',
			'diagnostics:test:executeall' => 'Spustit vše',
			'diagnostics:unittester:notests' => 'Omlouváme se, žadné testy nejsou aktuálně nainstalovány.',
			'diagnostics:unittester:testnotfound' => 'Omlouváme se, výpis nelze vygenerovat, protožen test nebyl nalezen',
	
			'diagnostics:unittester:testresult:nottestclass' => 'SELHAL - Výstup není testovaná třída',
			'diagnostics:unittester:testresult:fail' => 'SELHAL',
			'diagnostics:unittester:testresult:success' => 'ÚSPĚŠNÝ',
	
			'diagnostics:unittest:example' => 'Ukázkový test jednotky je dostupny pouze v debug režimu.',
	
			'diagnostics:unittester:report' => 'Výsledky Test report for %s',
	
			'diagnostics:download' => 'Download .txt',
	
	
			'diagnostics:header' => '========================================================================
Výsledky diagnostiky Elgg
Generovaný %s by %s
========================================================================
			
',
			'diagnostics:report:basic' => '
Elgg Release %s, verze %s

------------------------------------------------------------------------',
			'diagnostics:report:php' => '
PHP info:
%s
------------------------------------------------------------------------',
			'diagnostics:report:plugins' => '
Detaily nainstlovanych pluginů:

%s
------------------------------------------------------------------------',
			'diagnostics:report:md5' => '
Instalované soubory a jejich kontrolní součty:

%s
------------------------------------------------------------------------',
			'diagnostics:report:globals' => '
Globalní proměné:

%s
------------------------------------------------------------------------',
	
	);
					
	add_translation("en",$english);
?>