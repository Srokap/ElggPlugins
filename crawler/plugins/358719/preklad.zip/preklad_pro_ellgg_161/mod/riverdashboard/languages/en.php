<?php

	$english = array(

		'mine' => 'Moje',
		'filter' => 'Filtr',
		'riverdashboard:useasdashboard' => "Nahradit výchozí nástěnku tímto proudem aktivit?",
		'activity' => 'Aktivity',
		'riverdashboard:recentmembers' => 'Nový členové',
	
	    /**
	     * Site messages
           **/

		'sitemessages:announcements' => "Síťová oznámení",
		'sitemessages:posted' => "Odesláno",
		'sitemessages:river:created' => "Síťovým administrátorem, %s,",
		'sitemessages:river:create' => "odeslána nová celosíťová zpráva",
		'sitemessages:add' => "Přidat celosíťovou zprávu do proudu aktivit",
		'sitemessage:deleted' => "Síťová zpráva byla smazána",
		
		'river:widget:noactivity' => 'Aktivitu nelze najít.',
		'river:widget:title' => "Aktivity",
		'river:widget:description' => "Zobrazí nejnovější aktivity.",
		'river:widget:title:friends' => "Aktivity přátel",
		'river:widget:description:friends' => "Zobraz co dělají přátelé.",
		'river:widgets:friends' => "Přátelé",
		'river:widgets:mine' => "Moje",
		'river:widget:label:displaynum' => "Počet zobrazených položek:",
		'river:widget:type' => "Který proud aktivit si přejete zobrazit? Ten, který zobrazuje vaše aktivity nebo ten co zobrazuje aktivity přátel?",
		'item:object:sitemessage' => "Síťové zprávy",
	);
					
	add_translation("en",$english);

?>