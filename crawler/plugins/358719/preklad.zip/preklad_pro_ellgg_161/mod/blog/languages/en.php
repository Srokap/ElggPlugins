<?php

	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'blog' => "Blog",
			'blogs' => "Blogy",
			'blog:user' => "blog od %s",
			'blog:user:friends' => "blog přátel %s",
			'blog:your' => "Tvůj blog",
			'blog:posttitle' => "%s blog: %s",
			'blog:friends' => "Blogy přátel",
			'blog:yourfriends' => "Nejnovější blogy přátel",
			'blog:everyone' => "Blogy z celé sítě",
			'blog:newpost' => "Nový příspěvek v blogu",
			'blog:via' => "přes blog",
			'blog:read' => "Číst blog",
	
			'blog:addpost' => "Napsat příspěvek do blogu",
			'blog:editpost' => "Upravit blogový příspvěk",
	
			'blog:text' => "Text blogu",
	
			'blog:strapline' => "%s",
			
			'item:object:blog' => 'Příspěvky v blogu',
	
			'blog:never' => 'nikdy',
			'blog:preview' => 'Náhled',
	
			'blog:draft:save' => 'Uložit mezi rozepsaný',
			'blog:draft:saved' => 'Naposledy rozepsané',
			'blog:comments:allow' => 'Povolit komentáře',
	
			'blog:preview:description' => 'Toto je neuložený náhled vašeho příspěvku.',
			'blog:preview:description:link' => 'Klikněte zde, pro pokračovaní v editaci.',
	
			'blog:enableblog' => 'Povolit skupinový blog',
	
			'blog:group' => 'Skupinový blog',
			
         /**
	     * Blog river
	     **/
	        
	        //generic terms to use
	        'blog:river:created' => "vytvořil %s",
	        'blog:river:updated' => "upravil %s",
	        'blog:river:posted' => "odeslal %s",
	        
	        //these get inserted into the river links to take the user to the entity
	        'blog:river:create' => "nový příspěvek do blogu",
	        'blog:river:update' => "upraven blogový příspěvek",
	        'blog:river:annotate' => "poznámka k blogovému příspěvku",
			
	
		/**
		 * Status messages
		 */
	
			'blog:posted' => "Tvůj příspěvek do blogu byl úspěsně odeslán.",
			'blog:deleted' => "Tvůj příspěvek do blogu byl úspěsně smazán.",
	
		/**
		 * Error messages
		 */
	
			'blog:error' => 'Něco proběhlo spatně. Prosím zkuste to znova.',
			'blog:save:failure' => "Vaš příspěvek do blogu nemohl být odeslán. Prosím zkuste to znova.",
			'blog:blank' => "Omlouváme se; pro odeslání příspěvku je třeba vyplnit nadpis a tělo textu.",
			'blog:notfound' => "Omlouváme se; nelze najít specifikovaný příspěvek.",
			'blog:notdeleted' => "Omlouváme se; nelze smazat tento příspevek.",
	
	);
					
	add_translation("en",$english);

?>