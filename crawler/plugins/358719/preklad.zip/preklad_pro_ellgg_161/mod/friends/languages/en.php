<?php

	$english = array(
	
		/**
		 * Friends widget
		 */
			'friends:widget:description' => "Zobrazí tvoje přátele.",
	        
		
	);
					
	add_translation("en",$english);

?>