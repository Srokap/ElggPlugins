<?php

	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
		'tinymce:remove' => "Přidat/Odebrat editor",
		'tinymce:remove' => "Přidat/Odebrat editor",
	
	);
					
	add_translation("en",$english);

?>