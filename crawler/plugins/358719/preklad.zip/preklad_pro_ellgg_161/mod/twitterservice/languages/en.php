<?php
	$english = array(
		'twitterservice' => 'Služba Twitter',
		'twitterservice:postwire' => 'Nastvením následujících položek budou všechny vaše příspěvky, které napíšete do vzkazů zaslány na váš účet ve twitteru. Chcete, aby vaše příspěvky ze vzkazů byly zasílány na twitter?',
		'twitterservice:twittername' => 'Uživatelské jméno v Twitteru',
		'twitterservice:twitterpass' => 'Heslo v Twitteru',
	);
					
	add_translation("en",$english);
?>