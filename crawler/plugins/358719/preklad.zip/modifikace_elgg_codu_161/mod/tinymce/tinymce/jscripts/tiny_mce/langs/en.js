tinyMCE.addI18n({en:{
common:{
edit_confirm:"Chcete  v tomto případe použít režim WYSIWYG?",
apply:"Použít",
insert:"Vložit",
update:"Aktualizovat",
cancel:"Zrušit",
close:"Zavřít",
browse:"Projít",
class_name:"Třída",
not_set:"-- Není nastaveno --",
clipboard_msg:"Kopírovat/Vyjmoput/Vložit nemí podporováno v Mozille a Firefoxu.\nChcete se o tom dozvědět více?",
clipboard_no_support:"Aktualně není podporováno ve vašem prohlížeci, použije klávesové zkratky.",
popup_blocked:"Omlouváme se, zjistili jsme, že popup-blocker zablokoval okna, která jsou nutna pro funkci aplikace. Potřebujete vypnout blokování vyskakovaných oken pro tuto sít aby jste mohli plně vyuzívat tuto aplikaci.",
invalid_data:"Chyba: Vloženy chybné hodnoty (označeny červeně).",
more_colors:"Více barev"
},
contextmenu:{
align:"Zarovnání",
left:"Vlevo",
center:"Střed",
right:"Vpravo",
full:"Vyplnit"
},
insertdatetime:{
date_fmt:"%Y-%d-%m",
time_fmt:"%H:%M:%S",
insertdate_desc:"Vložit datum",
inserttime_desc:"Vložit čas",
months_long:"Leden,Únor,Březen,Duben,Květen,Červen,Červenec,Srpen,Září,Říjen,Listopad,Prosinec",
months_short:"Led,Úno,Bře,Dub,Kvě,Čer,Čec,Srp,Zář,Říj,Lis,Pro",
day_long:"Neděle,Pondělí,Úterý,Středa,Čtvrtek,Pátek,Sobota,Neděle",
day_short:"Neď,Pon,Úte,Stř,Čtv,Pát,Sob,Neď"
},
print:{
print_desc:"Vytisknout"
},
preview:{
preview_desc:"Náhled"
},
directionality:{
ltr_desc:"Směr zleva do prava",
rtl_desc:"Směr zprava do leva"
},
layer:{
insertlayer_desc:"Vložit novou vrstvu",
forward_desc:"Posunout dopředu",
backward_desc:"Posunout dozadu",
absolute_desc:"Zapnout absolutní pozice",
content:"Nová vrstva..."
},
save:{
save_desc:"Uložit",
cancel_desc:"Zrušit všechny změny"
},
nonbreaking:{
nonbreaking_desc:"Vložit nepřerušující znak mezery"
},
iespell:{
iespell_desc:"Spustit kontrolu pravopisu",
download:"ieSpell nebyl nalezen. Chcete ho nainstalovat?"
},
advhr:{
advhr_desc:"Horizontální pravítko"
},
emotions:{
emotions_desc:"Emoce"
},
searchreplace:{
search_desc:"Hledat",
replace_desc:"Hledat/Najít"
},
advimage:{
image_desc:"Vložit/upravit obrázek"
},
advlink:{
link_desc:"Vložit/upravit odkaz"
},
xhtmlxtras:{
cite_desc:"Citace",
abbr_desc:"Abbreviation",
acronym_desc:"Acronym",
del_desc:"Smazání",
ins_desc:"Vložení",
attribs_desc:"Vložit/upravit Atributy"
},
style:{
desc:"Upravit CSS Styl"
},
paste:{
paste_text_desc:"Vložit jako text",
paste_word_desc:"Vložit z Wordu",
selectall_desc:"Vybrat vše"
},
paste_dlg:{
text_title:"Použijte CTRL+V na vaší klávesnici k vložení textu do okna.",
text_linebreaks:"Keep linebreaks",
word_title:"Použijte CTRL+V na vaší klávesnici k vložení textu do okna."
},
table:{
desc:"Vloží novou tabulku",
row_before_desc:"Vloží řádek před",
row_after_desc:"Vloží řádek za",
delete_row_desc:"Smaže řádek",
col_before_desc:"Vloží sloupec před",
col_after_desc:"Vloží sloupec za",
delete_col_desc:"Odstraní sloupec",
split_cells_desc:"Rozdělí sloučené buňky tabulky",
merge_cells_desc:"Sloucí buňky tabuky",
row_desc:"Nastvení řáků tabulky",
cell_desc:"Nastvení buňeky tabulky",
props_desc:"Nastvení tabulky",
paste_row_before_desc:"Vložit řádek před",
paste_row_after_desc:"Vložit řádek za",
cut_row_desc:"Vyjmout řádek tabulky",
copy_row_desc:"Kopírovat řádek tabulky",
del:"Smazat tabulku",
row:"Řádek",
col:"Sloupec",
cell:"Buňka"
},
autosave:{
unload_msg:"Změny, které jste udělal, budou ztraceny pokud opustíte tyto stranky."
},
fullscreen:{
desc:"Zapnout režim celé obrazovky"
},
media:{
desc:"Vložit/Upravit zapouzdřená media",
edit:"Upravit zapouzdřená media"
},
fullpage:{
desc:"Nastavení Dokumentu"
},
template:{
desc:"Vložit předefinovaný obsah tabulky"
},
visualchars:{
desc:"Zobrazit/vypnout kontrolní znaky."
},
spellchecker:{
desc:"Zapnout kontrolu pravopisu",
menu:"Nastavení kontroly pravopisu",
ignore_word:"Ignorovat slova",
ignore_words:"Ignorovat vše",
langs:"Jazyky",
wait:"Prosím počkejte...",
sug:"Doporučení",
no_sug:"Žadná doporučení",
no_mpell:"Zádné chyby nenalezeny."
},
pagebreak:{
desc:"Vložit odělovač stran."
}}});