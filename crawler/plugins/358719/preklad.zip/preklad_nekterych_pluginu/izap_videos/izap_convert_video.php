<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-3.0
*/
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
// only works if started from command line
if($argc > 1 && $argv[1] == 'izap' && $argv[2] == 'web'){
  izapGetAccess_izap_videos(); // get the complete access to the system;
    izapAdminSettings_izap_videos('isQueueRunning', 'yes', TRUE);
    echo 'Queue started.........................RUNNING..............';
      izapRunQueue_izap_videos();
      izapAdminSettings_izap_videos('isQueueRunning', 'no', TRUE);
    echo '______________ :) Done__________';
  izapRemoveAccess_izap_videos(); // remove the access from the system
}
forward('http://www.izap.in');
?>