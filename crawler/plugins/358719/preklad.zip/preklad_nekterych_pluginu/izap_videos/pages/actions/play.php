<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-3.0
*/




// get the video id as input 
$video = (int) get_input('guid');
$izap_videos = izapVideoCheck_izap_videos($video);

// make the video owner page owner
set_page_owner($izap_videos->container_guid);
  
$title = $izap_videos->title;

// get page contents
$area2 = elgg_view_entity($izap_videos, TRUE);
$area2 .= elgg_view('izap_videos/izapLink');
// get tags and categories
$area3 = elgg_view('izap_videos/area3');
$body = elgg_view_layout("two_column_left_sidebar", '', $area2, $area3);

page_draw($title, $body);