<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-3.0
*/

global $CONFIG;

$queueStatus = (izapIsQueueRunning_izap_videos()) ? elgg_echo('izap_videos:running') : elgg_echo('izap_videos:notRunning');
$queuedVideos = get_entities('object', 'izapVideoQueue', 0, '', 0, 0, true);
$main_url = $CONFIG->wwwroot . 'pg/izap_videos/adminSettings/'.get_loggedin_user()->username.'?option=queue_status';
?>
<div class="usersettings_statistics">
  <h3><?php echo elgg_echo('izap_videos:queueStatus');?></h3>
    <table>
      <tbody>
        <tr class="odd">
          <td class="column_one"><?php echo elgg_echo('izap_videos:queueStatus')?></td>
          <td>
          <?php echo $queueStatus;?> &nbsp;&nbsp;

          <?php if($queueStatus == elgg_echo('izap_videos:running')) {?>
            <a href="<?php echo $main_url;?>&action=reset">
              <?php echo elgg_echo('izap_videos:resetNow')?>
            </a>
          <?php  }?>
          </td>
        </tr>

        <tr class="odd">
          <td class="column_one"><?php echo elgg_echo('izap_videos:queuedFilesTotal')?></td>
          <td><?php echo $queuedVideos;?> &nbsp;&nbsp;
            <?php
            if($queuedVideos){
              echo elgg_view('output/confirmlink', array(
                            'text' => elgg_echo('izap_videos:deleteNow'),
                            'href' => $main_url . '&action=delete',
                            'confirm' => elgg_echo('izap_video:deleteQueue'),
                ));
            }
            ?>
          </td>
        </tr>

      </tbody>
    </table>
</div>
