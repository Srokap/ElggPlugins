<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-3.0
*/

require_once(dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "/engine/start.php");
global $CONFIG, $IZAPSETTINGS;
$guid = get_input("id");


if(!$guid)
$guid = current(explode('.', get_input("file")));

// if nothing is found yet..
if(!$guid){
  $guid = get_input('videoID');
}

$what = get_input("what");
$izap_videos = izapVideoCheck_izap_videos($guid);


if($izap_videos){
  // check what is needed
  if($what == 'image'){
    $filename = $izap_videos->imagesrc;
  }elseif(!isset($what) || empty($what) || $what == 'file'){
    $filename = $izap_videos->videofile;
  }

  // only works if there is some file name
  if($filename != ''){
    $fileHandler = new ElggFile();
    $fileHandler->owner_guid = $izap_videos->owner_guid;
    $fileHandler->setFilename($filename);
    $contents = $fileHandler->grabFile();
  }
  
  if($contents == ''){
    if($izap_videos->videotype == 'others'){
        $url = $IZAPSETTINGS->apiUrl . '?image=' . base64_encode($izap_videos->videotype_site);
        $urltocapture =  new curl($url) ;
        $urltocapture->setopt(CURLOPT_GET, true) ;
        $feed = $urltocapture->exec();
      if($feed){
        $contents = $feed;
      }else{
        $contents = file_get_contents($CONFIG->pluginspath . 'izap_videos/graphics/izapdesign_logo.gif');
      }
    }else{
      $contents = file_get_contents($CONFIG->pluginspath . 'izap_videos/_graphics/izapdesign_logo.gif');
    }
  }
  
  if($what == 'image'){
    header("Content-type: image/jpeg");
  }elseif(!isset($what) || empty($what) || $what == 'file'){
    header("Content-type: application/x-flv");
  }

  $fileName = end(explode('/', $filename));
  header("Content-Disposition: inline; filename=\"$fileName\"");

 echo $contents;
}