<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-3.0
*/

/**
 * main function that register everything
 * 
 * @global <type> $CONFIG
 */
function init_izap_videos(){
  global $CONFIG;

  // include the main lib file
  include $CONFIG->pluginspath . 'izap_videos/lib/izapLib.php';

  // add menu
  add_menu(elgg_echo('videos'), $CONFIG->wwwroot . "pg/izap_videos/all/");

  // register pagehandler
  register_page_handler('izap_videos', 'pageHandler_izap_videos');
  register_page_handler('izap_videos_files', 'pageHandler_izap_videos_files');
  // register urlhandler
  register_entity_url_handler('urlHandler_izap_videos', 'object', 'izap_videos');

  // register the notification hook
  if(is_callable('register_notification_object')){
    register_notification_object('object', 'izap_videos', elgg_echo('izap_videos:newVideoAdded'));
  }

  // asking group to include the izap_videos
  if(is_callable('add_group_tool_option')){
    add_group_tool_option('izap_videos', elgg_echo('izap_videos:group:enablevideo'), true);
  }

  // register the notification hook
  if(is_callable('register_notification_object')){
    register_notification_object('object', 'izap_videos', elgg_echo('izap_videos:newVideoAdded'));
  }
  
  // skip tags from filteration
  $CONFIG->allowedtags['object'] = array( 'width'=>array(), 'height'=>array(), 'classid'=>array(), 'codebase'=>array() , 'data' =>array(), 'type'=>array());
  $CONFIG->allowedtags['param'] = array( 'name'=>array(), 'value'=>array());
  $CONFIG->allowedtags['embed'] = array( 'src'=>array(), 'type'=>array(), 'wmode'=>array(), 'width'=>array(), 'height'=>array());
  // htmlawed
  $CONFIG->htmlawed_config['elements'] = 'object, embed, params, param, b, i, ul,
                                          li, u, img, alt, a, blockquote, span,
                                          style, p, strong, em, ol, br';

  // add subtype
  run_function_once('izapSetup_izap_videos');

  // extend the views
  extend_view('css', 'izap_videos/css/default');
  extend_view('metatags','izap_videos/js/javascript');
	extend_view('profile/menu/links','izap_videos/menu');
  extend_view('groups/right_column', 'izap_videos/gruopVideos', 1);
  
  // adding the widget
  add_widget_type('izap_videos',elgg_echo('izap_videos:videos'),elgg_echo('izap_videos:widget'));

   // only if enabled by admin
  if(izapIncludeIndexWidget_izap_videos()){
    extend_view('index/righthandside', 'izap_videos/customindexVideos');
  }

  // only if enabled by admin
  if(izapTopBarWidget_izap_videos()){
    extend_view('elgg_topbar/extend','izap_videos/navBar');
  }
  
  // finally lets register the object
  register_entity_type('object','izap_videos');
}

/**
 * includes the required file based on the url parameters
 * 
 * @param array $page url components
 * @return boolean
 */
function pageHandler_izap_videos($page){
  if(isloggedin()){
    set_input('username', get_loggedin_user()->name);
  }

  $action = empty($page[0])?null:$page[0];
  if(!empty($page[2]) && is_numeric($page[2])){
    $username = $page[1];
    $guid = $page[2];
    set_input('guid',$guid);
    set_input('username', $username);
  }elseif(!empty($page[1]) && is_string($page[1])){
    $username = $page[1];
    set_input('username',$username);
  }elseif(!empty($page[1]) && is_numeric($page[1])){
    $guid = $page[1];
    set_input('guid',$guid);
  }

  switch($action) {
    default:
      if(!include('pages/actions/' . $action . '.php')){
        include('pages/actions/all.php');
      }
      break;
  }
}

/**
 * sets page hadler for the thumbs and video
 * 
 * @param array $page
 */
function pageHandler_izap_videos_files($page){
  set_input('what', $page[0]);
  set_input('videoID', $page[1]);
  include ('pages/actions/thumbs.php');
}

/**
 * returns the url for the video to play
 * 
 * @global <type> $CONFIG
 * @param ElggEntity $izap_videos video object
 * @return string video play url
 */
function urlHandler_izap_videos($izap_videos){
  global $CONFIG;
  return $CONFIG->wwwroot . 'pg/izap_videos/play/'.get_entity($izap_videos->container_guid)->username.'/' . $izap_videos->guid . '/' . friendly_title($izap_videos->title);
}

/**
 * setups the submenus
 * 
 * @global <type> $CONFIG 
 */
function pageSetup_izap_videos(){
  global $CONFIG;

  // get the page owner
	$pageowner = page_owner_entity();

  // if page owner is user and context is izap_videos
  if($pageowner instanceof ElggUser && get_context() == 'izap_videos'){
    // if page owner is loggedin user then
    if($pageowner == get_loggedin_user()){
      add_submenu_item(sprintf(elgg_echo('izap_videos:videos'),$pageowner->name), $CONFIG->wwwroot . 'pg/izap_videos/list/' . $pageowner->username . '/', 'IZAPVIDEOS');
      add_submenu_item(sprintf(elgg_echo('izap_videos:frnd'),$pageowner->name), $CONFIG->wwwroot . 'pg/izap_videos/friends/' . $pageowner->username . '/', 'IZAPVIDEOS');
    }else{
      add_submenu_item(sprintf(elgg_echo('izap_videos:user'),$pageowner->name), $CONFIG->wwwroot . 'pg/izap_videos/list/' . $pageowner->username . '/', 'IZAPVIDEOS');
      add_submenu_item(sprintf(elgg_echo('izap_videos:userfrnd'),$pageowner->name), $CONFIG->wwwroot . 'pg/izap_videos/friends/' . $pageowner->username . '/', 'IZAPVIDEOS');
    }

    // for loggedin users only
    if(isloggedin()){
      if($pageowner instanceof ElggUser){
        add_submenu_item(elgg_echo('izap_videos:add'), $CONFIG->wwwroot . 'pg/izap_videos/add/'.get_loggedin_user()->username.'/', 'IZAPVIDEOS');
      }
    }
  }

  // for all
  if(get_context() == 'izap_videos'){
    add_submenu_item(elgg_echo('izap_videos:all'), $CONFIG->wwwroot . 'pg/izap_videos/', 'IZAPVIDEOS');
  }
    
  // if the page owner is group and context is group
  if($pageowner instanceof ElggGroup && (get_context() == 'groups' || get_context() == 'izap_videos') && $pageowner->izap_videos_enable == 'yes'){
    if(can_write_to_container(get_loggedin_userid(), $pageowner->guid, 'izap_videos')){
      add_submenu_item(elgg_echo('izap_videos:addgroupVideo'), $CONFIG->wwwroot . 'pg/izap_videos/add/'.$pageowner->username.'/', 'IZAPVIDEOS');
    }
    add_submenu_item(elgg_echo('izap_videos:groupvideos'), $CONFIG->wwwroot . 'pg/izap_videos/list/'.$pageowner->username.'/', 'IZAPVIDEOS');
  }

  // if the context is admin and is admin logged in
  if(get_context() == 'admin' && isadminloggedin()){
    add_submenu_item(elgg_echo('izap_videos:adminSettings'), $CONFIG->wwwroot . 'pg/izap_videos/adminSettings/' . get_loggedin_user()->username, 'IZAPADMIN');
  }
}

// register some actions
register_action('izapAdminSettings', FALSE, dirname(__FILE__) . '/actions/izap_videos/admin/editSettings.php', TRUE);
register_action('izapResetSettings', FALSE, dirname(__FILE__) . '/actions/izap_videos/admin/resetSettings.php', TRUE);
register_action('izapAddEdit', FALSE, dirname(__FILE__) . '/actions/izap_videos/addEdit.php');
register_action('izapCopy', FALSE, dirname(__FILE__) . '/actions/izap_videos/copy.php');
register_action('izapDelete', FALSE, dirname(__FILE__) . '/actions/izap_videos/delete.php');

// register the main fucntion with the elgg system
register_elgg_event_handler('init', 'system', 'init_izap_videos');
register_elgg_event_handler('pagesetup', 'system', 'pageSetup_izap_videos');