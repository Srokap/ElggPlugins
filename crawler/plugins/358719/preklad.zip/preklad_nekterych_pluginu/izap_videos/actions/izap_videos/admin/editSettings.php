<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-3.0
*/

action_gatekeeper();
admin_gatekeeper();

$postedArray = get_input('izap');

$plugin = find_plugin_settings('izap_videos');

// get the video options checkboxes
$videoOptions = filter_tags($_POST['izap']['izapVideoOptions']);
if(empty($videoOptions)){
  register_error(elgg_echo('izap_videos:error:videoOptionBlank'));
  forward($_SERVER['HTTP_REFERER']);
}
$postedArray['izapVideoOptions'] = $videoOptions;

// get the marquee checkbox
if(!empty($postedArray['izapVideoWatermarkObjectMarquee'])){
  $postedArray['izapVideoWatermarkObjectMarquee'] = 'YES';
}else{
  $postedArray['izapVideoWatermarkObjectMarquee'] = 'NO';
}

// get the index page widget
if(!empty($postedArray['izapExtendVideoSupport'])){
  $postedArray['izapExtendVideoSupport'] = 'YES';
}else{
  $postedArray['izapExtendVideoSupport'] = 'NO';
}

// get the index page widget
if(!empty($postedArray['izapIndexPageWidget'])){
  $postedArray['izapIndexPageWidget'] = 'YES';
}else{
  $postedArray['izapIndexPageWidget'] = 'NO';
}

// get the index page widget
if(!empty($postedArray['izapTopBarWidget'])){
  $postedArray['izapTopBarWidget'] = 'YES';
}else{
  $postedArray['izapTopBarWidget'] = 'NO';
}

// get the credit
if(!empty($postedArray['izapGiveUsCredit'])){
  $postedArray['izapGiveUsCredit'] = 'YES';
}else{
  $postedArray['izapGiveUsCredit'] = 'NO';
}

foreach($postedArray AS $key => $values){
  izapAdminSettings_izap_videos($key, $values, TRUE);
}

system_message(elgg_echo('izap_videos:success:adminSettingsSaved'));
forward($_SERVER['HTTP_REFERER']);
exit;