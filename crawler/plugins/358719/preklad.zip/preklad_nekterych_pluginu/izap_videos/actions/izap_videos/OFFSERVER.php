<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-3.0
*/

$videoValues = $izap_videos->input($postedArray['videoUrl'], 'url');

if(!is_object($videoValues)){
  register_error(elgg_echo('izap_videos:error:code:' . $videoValues));
  forward($_SERVER['HTTP_REFERER']);
}

if($postedArray['title'] == ''){
  $izap_videos->title = $videoValues->title;
}

if($postedArray['description'] == ''){
  $izap_videos->description = $videoValues->description;
}

if($postedArray['tags'] == ''){
  $izap_videos->tags = string_to_tag_array($videoValues->videoTags);
}

$izap_videos->videosrc = $videoValues->videoSrc;
$izap_videos->videotype = $videoValues->type;
$izap_videos->imagesrc = "izap_videos/" . $videoValues->type . "/" . $videoValues->fileName;
$izap_videos->converted = 'yes';

if($izap_videos->videotype != 'others'){
  $izap_videos->setFilename($izap_videos->imagesrc);
  $izap_videos->open("write");
  $izap_videos->write($videoValues->fileContent);
  $thumb = get_resized_image_from_existing_file($izap_videos->getFilenameOnFilestore(),120,90, true);
  $izap_videos->setFilename($izap_videos->imagesrc);
  $izap_videos->open("write");
  $izap_videos->write($thumb);
}else{
  $izap_videos->videotype_site = $videoValues->domain;
  $izap_videos->videotype_id = $videoValues->id;
  $izap_videos->videosrc = $videoValues->object;
  $izap_videos->imagesrc = $videoValues->image;
}