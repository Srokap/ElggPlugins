<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-3.0
*/

admin_gatekeeper();

if(clear_plugin_setting('', 'izap_videos')){
  system_message(elgg_echo('izap_videos:success:adminSettingsReset'));
}else{
  register_error(elgg_echo('izap_videos:error:adminSettingsReset'));
}

forward($_SERVER['HTTP_REFERER']);
exit;