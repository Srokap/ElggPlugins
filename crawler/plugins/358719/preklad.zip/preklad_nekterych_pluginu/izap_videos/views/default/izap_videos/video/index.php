<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-3.0
*/

// copy video link only shows up if the user is loggedin,
// video doesn't belongs to loggedin user and
// video is converted(in case of uploaded videos)
  if(($vars['video']->canCopy()))
    $Add = '<div class="contentWrapper"><h3 align="center"><a href="' . $CONFIG->wwwroot . 'action/izapCopy?videoId=' . $vars['video']->getGUID() . '">' . elgg_echo('izap_videos:addtoyour') . '</a></h3></div>';
?>
<div>
  <?php
  echo elgg_view_title($vars['video']->title);
  echo $Add;
  echo elgg_view('izap_videos/video/elements/video', array('video' => $vars['video']));
  echo elgg_view('izap_videos/video/elements/description', array('video' => $vars['video']));
  echo elgg_view('izap_videos/video/elements/share', array('video' => $vars['video']));
  echo elgg_view('izap_videos/video/elements/related', array('video' => $vars['video']));
  echo elgg_view('izap_videos/customindexVideos', array('videosTOdisplay' => 28));
  // view for other plugins to extend
  echo elgg_view('izap_videos/extendedPlay');
  echo elgg_view('izap_videos/video/elements/comments', array('video' => $vars['video']));
  ?>
</div>
<?php
// update view
$vars['video']->updateViews();