<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-3.0
*/
global $CONFIG;

if($vars['entity']->izap_videos_enable != 'no'){
  echo '<div id="izap_widget_layout">';
  echo '<a href="' .  $CONFIG->wwwroot . "pg/izap_videos/" . page_owner_entity()->username . '"><h2>' . elgg_echo('izap_videos:groupvideos') . '</h2></a>';
  
  set_context('izapMiniList');
  $videos = list_entities('object', 'izap_videos', $vars['entity']->guid, 10, false, false, false);
  
  if($videos){
    echo $videos;
    $user_inbox = $vars['url'] . "pg/izap_videos/" . page_owner_entity()->username;
    echo '<div class="forum_latest" align="right"><a href="'.$user_inbox.'">'.elgg_echo('izap_videos:everyone').'</a></div>';
  }else{
    echo '<div class="forum_latest">' . elgg_echo('izap_videos:notfound') . '</div>';
  }
  echo '<div class="clearfloat"></div></div>';
}