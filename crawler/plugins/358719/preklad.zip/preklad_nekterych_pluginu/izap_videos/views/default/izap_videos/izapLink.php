<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-3.0
*/

if(izapAdminSettings_izap_videos('izapGiveUsCredit') == 'YES'){
?>
<div class="izap_credit" align="right" style="font-size:10px;">
    Powered by <a href="http://www.izap.in/" target="_blank">iZAP</a>
</div>
<?php }?>