<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-3.0
*/

global $IZAPSETTINGS;

// get page owner
$page_owner = page_owner_entity();

// get entity
$video = $vars['entity'];

// get the add options
$options = izapGetVideoOptions_izap_videos();

// get the selected option
$selectedOption = get_input('option', '');
if(empty($selectedOption)){
  $selectedOption = $options[0];
}

// get values from session if any
if(isset($_SESSION['izapVideos']) && !empty($_SESSION['izapVideos'])){
  $izapLoadedValues = izapArrayToObject_izap_videos($_SESSION['izapVideos']);
}

if(empty($video)){  // if it is new video
  $form .= elgg_view('izap_videos/forms/elements/tabs', array('options' => $options, 'selected' => $selectedOption));
  if(in_array($selectedOption, $options)){
    $formElements = $IZAPSETTINGS->videoForms[$selectedOption];
    $form .= elgg_view('izap_videos/forms/elements/' . $selectedOption, array('position' => 'top'));
  }
}else{  // if we are editing video
  $izapLoadedValues = $video->getAttributes();
  $formElements = $IZAPSETTINGS->defaultForm;
}

$izapLoadedValues->container_guid = page_owner();
// create form
$formArray = array(
  'fromElements' => $formElements,
  'action' => 'izapAddEdit',
  'values' => $izapLoadedValues,
  'language' => 'izap_videos:addEditForm:',
  'vars' => $vars,
  'categories' => TRUE,
  );$form .= izapCreateForm_izap_videos($formArray);

$form .= elgg_view('izap_videos/forms/elements/' . $selectedOption, array('position' => 'bottom'));
?>
<div class="contentWrapper">
  <?php echo $form?>
</div>
<?php
// unset the session when from is loaded
unset($_SESSION['izapVideos']);
?>