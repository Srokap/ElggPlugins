<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-3.0
*/

if ($vars['video']->canEdit()){
  $DeleteEdit .= elgg_view("output/confirmlink", array(
                        'href' => $vars['url'] . "action/izapDelete?video_id=" . $vars['video']->getGUID(),
                        'text' => elgg_echo('delete'),
                        'confirm' => elgg_echo('izap_videos:remove'),
                      ));
  $DeleteEdit .= '&nbsp;&nbsp;';
  $DeleteEdit .= '<a href="' . $vars['url']  . 'pg/izap_videos/edit/' . get_entity($vars['video']->container_guid)->username . '/' . $vars['video']->getGUID() . '">' . elgg_echo('izap_videos:edit') . '</a>';
}else{
  $DeleteEdit = '<br />';
}
?>
<div class="contentWrapper">
  <h3>
    <a href="<?php echo $vars['video']->getUrl()?>" class="screenshot" rel="<?php echo $vars['video']->getThumb(TRUE)?>">
      <?php echo $vars['video']->title;?>
    </a>
  </h3>
  
    <div class="generic_comment">
      <div class="generic_comment_icon">
        <a href="<?php echo $vars['video']->getUrl()?>" class="screenshot" rel="<?php echo $vars['video']->getThumb(TRUE);?>">
            <img src="<?php  echo $vars['video']->getThumb(TRUE);?>" height="40" width="40" alt="<?php echo $vars['video']->title;?>"/>
        </a>
        <div style="background:#DEDEDE;color:#0054A7;text-align:center;">
          <h3>
           <?php echo ((!$vars['video']->getViews()) ? '0' : $vars['video']->getViews())?>
          </h3>
        </div>
      </div>
      <div class="generic_comment_details">
        <?php echo friendly_time($vars['video']->time_created); ?>
        <?php echo elgg_echo('by'); ?> <a href="<?php echo $vars['url']; ?>pg/izap_videos/list/<?php echo $vars['video']->getOwnerEntity()->username; ?>"><?php echo $vars['video']->getOwnerEntity()->name; ?></a> &nbsp;
        <!-- display the comments link -->
          <a href="<?php echo $vars['video']->getURL(); ?>"><?php echo sprintf(elgg_echo("comments")) . " (" . elgg_count_comments($vars['video']) . ")"; ?></a>
        <?php echo '<p class="generic_comment_owner">' . $DeleteEdit . '</p>';?>
      </div>
    </div>
  </div>