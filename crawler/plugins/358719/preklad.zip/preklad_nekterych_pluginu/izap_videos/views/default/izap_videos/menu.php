<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-3.0
*/

?>
<p class="user_menu_profile izapProfileLink">
	<a href="<?php echo $vars['url'] . 'pg/izap_videos/list/' . $vars['entity']->username;?> "><?php echo elgg_echo('videos');?></a>
</p>