<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-3.0
*/

global $IZAPSETTINGS;

// tabs array
$options = array(
  'settings',
  'queue_status',
  'sever_analysis'
);

$selectedTab = get_input('option');
if(empty($selectedTab)){
  $selectedTab = 'settings';
}

$formArray = array(
  'fromElements' => $IZAPSETTINGS->settingsForm,
  'action' => 'izapAdminSettings',
  'values' => $izapLoadedValues,
  'language' => 'izap_videos:adminSettings:',
);

if(izapIsWin_izap_videos()){
  $formArray['exclude'] = $IZAPSETTINGS->settingsFormExclude;
}

$form = izapCreateForm_izap_videos($formArray);
?>
<div class="contentWrapper">
  
    <div id="elgg_horizontal_tabbed_nav">
    <ul>
    <?php
    foreach ($options as $option) {
      ?>
      <li class="<?php echo ($option == $selectedTab) ? 'selected' : '';?>">
        <a href="?option=<?php echo $option?>">
          <?php echo elgg_echo('izap_videos:adminSettings:tabs_' . $option);?>
        </a>
      </li>
      <?php
    }
    ?>
    </ul>
    </div>


  <?php
  if($selectedTab == 'settings'){
    echo $form;
  ?>
  <p align="right">
    <a href="<?php echo $vars['url']?>action/izapResetSettings" class="izapResetSettings">
      <?php echo elgg_echo('izap_videos:adminSettings:resetSettings');?>
    </a>
  </p>
<?php }else{
  echo elgg_view('izap_videos/admin/' . $selectedTab);
}
?>
</div>