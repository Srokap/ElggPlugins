<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-3.0
*/

$sites = izapGetSupportingVideoFormats_izap_videos();

?>
<h3><?php echo elgg_echo('izap_videos:form:izapSupportedFormats') . ' ('.count($sites).')' . ' a monohé další...';?></h3>
<ul>
  <?php foreach($sites as $site){?>
  <li>
    <b><?php echo $site;?></b>
  </li>
  <?php } ?>
</ul>
