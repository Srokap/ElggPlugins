<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-3.0
*/

if($vars['video']->countAnnotations()){
  echo elgg_view_title(elgg_echo('izap_videos:comments'));
}
echo elgg_view_comments($vars['video']);