<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-3.0
*/
// get video
$video = $vars['video'];
$iconPath = $vars['url'] . 'mod/izap_videos/_graphics/sharing/';
$embedCode =  str_replace('"', '\'', $vars['video']->getPlayer());
$url = current_page_url();
$title = $video->title;
$embed = elgg_view('input/text', array('value' => $embedCode, 'js' => ' onClick = this.select() READONLY', 'class' => 'genral-textarea'));

?>
<div>
  <?php echo elgg_view_title(elgg_echo('izap_videos:embedCode'));?>
  <div id="videoSrc" class="contentWrapper">
    <div>
      <a href="http://www.facebook.com/share.php?u=<?php echo $url;?>" target="_blank">
        <img src="<?php echo $iconPath?>facebook.png" alt="Facebook">
      </a>

      <a href="http://twitter.com/home/?status=<?php echo $url;?>" target="_blank">
        <img src="<?php echo $iconPath?>twitter.png" alt="Twitter">
      </a>

      <a href="http://www.myspace.com/Modules/PostTo/Pages/?u=<?php echo $url;?>&t=<?php echo friendly_title($title)?>&c=<?php echo urlencode($embedCode);?>" target="_blank">
        <img src="<?php echo $iconPath?>myspace.png" alt="MySpace">
      </a>

      <a href="http://www.linkedin.com/shareArticle?url=<?php echo $url;?>" target="_blank">
        <img src="<?php echo $iconPath?>linkedin.png" alt="LinkedIn">
      </a>

      <div style="float:left">
        <?php echo $embed?>
      </div>

      <div class="clearflaot"></div>
    </div>
  </div>
</div>