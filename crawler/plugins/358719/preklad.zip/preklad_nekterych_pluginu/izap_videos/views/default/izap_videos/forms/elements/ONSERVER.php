<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-3.0
*/

switch ($vars['position']) {
  case 'top':
    echo '<p align="right">'.sprintf(elgg_echo('izap_videos:maxFileSize'), izapAdminSettings_izap_videos('izapMaxFileSize')).'</p>';
  break;

case 'bottom':
  echo elgg_view('izap_videos/supportedFormats');
break;

 default:
   break;
}