<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-3.0
*/

$options = izapGetVideoOptions_izap_videos();
if(in_array('ONSERVER', $options)){
?>
  <a href="<?php echo $vars['url'] . 'pg/izap_videos/add/' . get_loggedin_user()->username . '?option=ONSERVER' ?>"  class="usersettings">
    <img src="<?php echo $vars['url']?>mod/izap_videos/_graphics/upload.png" height="16" width="16"/>
    <?php echo elgg_echo('izap_videos:uploadVideo') ?>
  </a>
<?php
}
?>