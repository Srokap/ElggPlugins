<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-3.0
*/

?>
<div class="contentWrapper">
  <h3>
    <a href="<?php echo $vars['url']?>pg/izap_videos/adminSettings/<?php echo get_loggedin_user()->username?>" >
      <?php echo elgg_echo('izap_videos:adminSettings:gotoSettings');?>
    </a>
 </h3>
</div>