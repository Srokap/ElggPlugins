<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-3.0
*/

if($vars['video']){
  $owner = $vars['video']->getOwnerEntity();
  $friendlytime = friendly_time($vars['video']->time_created);
  $icon = '<a href="' . $vars['video']->getURL() . '"  class="screenshot" rel="' . $vars['video']->getThumb(TRUE) . '"><img src="'.$vars['video']->getThumb(TRUE).'"></a>';
  $info .= '<a href="' . $vars['video']->getURL() . '">' . izapWordWrap_izap_videos($vars['video']->title, 30, TRUE) . '</a>';
  $info .= "<br />";
  $info .= "<a href=\"{$vars['video']->getOwnerUrl()}\">{$owner->name}</a> {$friendlytime}";
}
?>
<div class="search_listing izapMiniList">
  <div class="search_listing_icon">
    <?php echo $icon; ?>
  </div>
  <div class="search_listing_info">
    <?php echo $info; ?>
  </div>
</div>