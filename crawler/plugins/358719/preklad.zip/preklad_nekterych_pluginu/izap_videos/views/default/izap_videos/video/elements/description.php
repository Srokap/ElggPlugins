<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-3.0
*/

if ($vars['video']->canEdit()){
		$DeleteEdit .= '' . elgg_view("output/confirmlink", array(
													'href' => $vars['url'] . "action/izapDelete?video_id=" . $vars['video']->getGUID(),
													'text' => elgg_echo('delete'),
													'confirm' => elgg_echo('izap_videos:remove'),
												));
		$DeleteEdit .= '&nbsp;&nbsp;';
		$DeleteEdit .= '<a href="' . $vars['url']  . 'pg/izap_videos/edit/' . get_entity($vars['video']->container_guid)->username . '/' . $vars['video']->getGUID() . '">' . elgg_echo('izap_videos:edit') . '</a>';
    $DeleteEdit .= '&nbsp;&nbsp;';
}
?>

<div class="contentWrapper">
  <div class="generic_comment">
    <!-- Owner icon -->
    <div class="generic_comment_icon">
    <?php
    echo elgg_view("profile/icon",array('entity' => $vars['video']->getOwnerEntity(), 'size' => 'small'));
    ?>
      <div style="background:#DEDEDE;color:#0054A7;text-align:center">
      <h3>
      <?php echo $vars['video']->getViews();?>
      </h3>
      </div>
    </div>
    
    <div class="generic_comment_details">
      <p>
      <?php
        echo sprintf(elgg_echo("izap_videos:time"), date("F j, Y",$vars['video']->time_created)) . ' ';
        echo elgg_echo('by');
      ?>
        <a href="<?php echo $vars['url']; ?>pg/izap_videos/list/<?php echo $vars['video']->getOwnerEntity()->username; ?>">
          <?php echo $vars['video']->getOwnerEntity()->name; ?>
        </a> &nbsp;
      <!-- display the comments link -->
      <?php
          echo $DeleteEdit . sprintf(elgg_echo("comments")) . " (" . elgg_count_comments($vars['video']) . ")";
          // if the video is copied
          if((int)$vars['video']->copiedFrom > 0){
            $owner = get_user($vars['video']->copiedFrom);
            echo ' <span class="copied_text">[' . elgg_echo('izap_videos:copiedFrom') . ': <a href="' . $vars['video']->copiedVideoUrl . '">' . $owner->name . '</a>]</span>';
          }
          // get tags
          $tags = elgg_view('output/tags', array('tags' => $vars['video']->tags));
          if(!empty($tags)){
            echo '<p class="generic_comment_owner">' . elgg_echo('izap_videos:tags') . ': ' . $tags . '</p>';
          }
      ?>
      </p>
    </div>
    <div class="generic_comment_details">
      <p>
        <?php echo $vars['video']->description; ?>
      </p>
    </div>
  </div>
  <div class="clearfloat"></div>
</div>