<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-3.0
*/

class UrlFeed extends GetFeed {
	private $youtube_api_capture = array('api_location'=>'http://gdata.youtube.com/feeds/api/videos/');
	private $vimeo_api_capture = array('api_location' => 'http://vimeo.com/api/clip/');
	private $veoh_api_capture = array('api_location'=>'http://www.veoh.com/rest/v2/execute.xml?method=veoh.video.findByPermalink','apiKey'=>'CFEDBB8B-59FB-D36B-7435-E4B39C5D39A2');
	private $feed;
	public  $type;
	private $video_id;
	
	function setUrl($url = '')
	{
		if (preg_match('/(http:\/\/)?(www\.)?(youtube\.com\/)(.*)/', $url, $matches)){
			$this->type = 'youtube';
		}elseif (preg_match('/(http:\/\/)?(www\.)?(vimeo\.com\/)(.*)/', $url, $matches)){
			$this->type = 'vimeo';
		}elseif (preg_match('/(http:\/\/)?(www\.)?(veoh\.com\/)(.*)/', $url, $matches)){
			$this->type = 'veoh';
		}
			
		switch($this->type){
			case 'youtube':
			  $url_pram = explode("?",$url);
			  $url_pram = explode("&",$url_pram[1]);
			  $url_pram = explode("=",$url_pram[0]);
			  $this->video_id = $url_pram[1];
			  $this->feed = array('url' => $this->youtube_api_capture['api_location'].$this->video_id, 'type' => 'youtube');
			break;
			
			case 'vimeo':
				$url_pram = explode("/",$url);
				$this->video_id = end($url_pram);
				$this->feed = array('url' => $this->vimeo_api_capture['api_location'].$this->video_id.'.php', 'type' => 'vimeo');
			break;
			
			case 'veoh':
				$video_id = end(explode("%",$url));
				$this->video_id = substr($video_id, 2);
                $chk = strtolower(substr($this->video_id, 0, 1));
                if($chk != 'v') {
                    $this->video_id = end(explode("/",$url));
                }
				$this->feed = array('url' => $this->veoh_api_capture['api_location'].'&apiKey='.$this->veoh_api_capture['apiKey'].'&permalink='.$this->video_id, 'type' => 'veoh');
			break;

      default:
        if(izapAdminSettings_izap_videos('izapExtendVideoSupport') == 'YES'){
          return izapIsSupportedSite_izap_videos($url);
        }else{
          return '103';
        }
      break;
		}

    return $this->capture();
	}
	
	function capture(){
				
	  $obj= new stdClass;
		
	  $arry = $this->readFeed($this->feed['url'], $this->feed['type']);

	  $obj->title = $arry['title'];
	  $obj->description = $arry['description'];
	  $obj->videoThumbnail = $arry['videoThumbnail'];
	  $obj->videoTags = $arry['videoTags'];
	  $obj->videoSrc = $arry['videoSrc'];
	  	if(empty($obj->title) or empty($obj->videoSrc) or empty($obj->videoThumbnail)) {
			return $arry;
		}
	  $obj->fileName = time() . $this->video_id . ".jpg";
	  
		$urltocapture =  new curl($obj->videoThumbnail) ;
		$urltocapture->setopt(CURLOPT_GET, true) ;
	
	  $obj->fileContent = $urltocapture->exec();
		
	  $obj->type = $this->feed['type'];
//	  echo "<pre>";print_r($obj);exit;
	  return $obj;      
	}

}

// function for the other supported sites

function izapIsSupportedSite_izap_videos($url){
  global $IZAPSETTINGS;
    $url = $IZAPSETTINGS->apiUrl . '?url=' . base64_encode($url);
    $urltocapture =  new curl($url) ;
    $urltocapture->setopt(CURLOPT_GET, true) ;
    $feed = $urltocapture->exec();
    $returnArray = unserialize($feed);
    if(is_array($returnArray)){
      $return = izapArrayToObject_izap_videos($returnArray);
      $return->type = 'others';
      $return->title = $return->domain;
    }else{
      $return = 103;
    }

  return $return;
}

/**
 * it gets the list of supporting video sites from the iZAP Server
 *
 * @global <type> $izapSupportedVideoSites
 * @global <type> $CONFIG
 * @return array array of supported videos site.
 */
function izapGetSupportingVideoSites_izap_videos(){
  global $IZAPSETTINGS;

  $supportedSites[] = 'http://www.youtube.com';
  $supportedSites[] = 'http://www.vimeo.com';
  $supportedSites[] = 'http://www.veoh.com';

  // get feed from the server
  $url = $IZAPSETTINGS->apiUrl;
  $urltocapture =  new curl($url) ;
  $urltocapture->setopt(CURLOPT_GET, true) ;
  $feed = unserialize($urltocapture->exec());

  foreach ($feed as $site) {
    $supportedSites[] = $site;
  }

  asort($supportedSites);
  return $supportedSites;
}
