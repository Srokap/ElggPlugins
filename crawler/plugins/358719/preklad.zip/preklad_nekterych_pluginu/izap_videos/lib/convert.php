<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-3.0
*/

class izapConvert{
	private $invideo;
	private $outvideo;
  private $outimage;
	private $values = array();

	public $format = 'flv';

	function izapConvert($in = ''){
    $this->invideo = $in;
		$outputPath = substr($this->invideo, 0, -4);
		$this->outvideo =  $outputPath . '_c.' . $this->format;
		$this->outimage = $outputPath . '_i.png';
  }

	function convert(){
    
    $videoCommand = izapGetFfmpegVideoConvertCommand_izap_videos();
    $videoCommand = str_replace('[inputVideoPath]', $this->invideo, $videoCommand);
    $videoCommand = str_replace('[outputVideoPath]', $this->outvideo, $videoCommand);
    $videoCommand = str_replace('[watermarkCommnad]', izapGetFfmpegVideoWatermarkCommand_izap_videos($this->invideo), $videoCommand);
    //$videoCommand .= ' 2>&1';

    //echo $videoCommand;exit;
		exec($videoCommand, $arr, $ret);
    
		if(!$ret == 0){
      $return = array();
      $return['error'] = 1;
      $return['message'] = end($arr);
      $return['completeMessage'] = implode(' ', $arr);

      return $return;
    }

		return end(explode('/', $this->outvideo));
	}

	function photo(){
    $videoThumb = izapGetFfmpegVideoImageCommand_izap_videos();
    $videoThumb = str_replace('[inputVideoPath]', $this->invideo, $videoThumb);
    $videoThumb = str_replace('[outputImage]', $this->outimage, $videoThumb);

    // run command to take snapshot
		exec($videoThumb, $out2, $ret2);

		if(!$ret2 == 0)
			return FALSE;

		return $this->outimage;
	}

	function getValues(){
		$this->values['origname'] = time() . '_' . end(explode('/', $this->invideo));
	 	$this->values['origcontent'] = file_get_contents($this->invideo);
		$this->values['filename'] = time() . '_' . end(explode('/', $this->outvideo));
	 	$this->values['filecontent'] = file_get_contents($this->outvideo);
		$this->values['imagename'] = time() . '_' . end(explode('/', $this->outimage));
	 	$this->values['imagecontent'] = file_get_contents($this->outimage);
    
    if($this->values['filecontent'] != ''){
      if(file_exists($this->invideo))
        @unlink($this->invideo);
      if(file_exists($this->outvideo))
        @unlink($this->outvideo);
      if(file_exists($this->outimage))
        @unlink($this->outimage);
    }

		return $this->values;
	}
}


/**
 * this function gives the FFmpeg video converting command
 *
 * @return string path
 */
function izapGetFfmpegVideoConvertCommand_izap_videos() {
  $path = izapAdminSettings_izap_videos('izapVideoCommand');
  $path = html_entity_decode($path);
  if(!$path)
    $path = '';
  return $path;
}

/**
 * this function gives the FFmpeg video image command
 *
 * @return string path
 */
function izapGetFfmpegVideoImageCommand_izap_videos() {
  $path = izapAdminSettings_izap_videos('izapVideoThumb');
  $path = html_entity_decode($path);
  if(!$path)
    $path = '';
  return $path;
}

/**
 * this fucntion actually converts the video
 * @param string $file file loacation
 * @param int $videoId video guid
 * @param int $ownerGuid video owner guid
 * @param int $accessId access id
 * @return boolean
 */
function izapConvertVideo_izap_videos($file, $videoId, $videoTitle, $videoUrl, $ownerGuid, $accessId = 2) {
  global $CONFIG;
  $return = FALSE;

  // works only if we have the input file
  if($file != '' && file_exists($file)){
    // now convert video
    $video = new izapConvert($file);
    $videofile = $video->convert();

    // check if every this is ok
    if(!is_array($videofile)){

    // if every thing is ok then get back values to save
    $file_values = $video->getValues();
    $izap_videofile = 'izap_videos/uploaded/' . $file_values['filename'];
    $izap_origfile = 'izap_videos/uploaded/' . $file_values['origname'];

      $izap_videos = new IzapVideos($videoId);
      $izap_videos->setFilename($izap_videofile);
      $izap_videos->open("write");
      $izap_videos->write($file_values['filecontent']);

      $izap_videos->setFilename($izap_origfile);
      $izap_videos->open("write");
      $izap_videos->write($file_values['origcontent']);

      $izap_videos->converted = 'yes';
      $izap_videos->videofile = $izap_videofile;
      $izap_videos->orignalfile = $izap_origfile;

      if($izap_videos->save()){
        $return = TRUE;
        // notify the user if the video is saved properly
        notify_user($ownerGuid,
                  $CONFIG->site_guid,
                  elgg_echo('izap_videos:notifySub:videoConverted'),
                  sprintf(elgg_echo('izap_videos:notifyMsg:videoConverted'), $videoTitle, $videoUrl)
                  );
        return $return;
      }
    }else{
      $errorReason = $videofile['message'];
    }
  }else{
    $errorReason = elgg_echo('izap_videos:fileNotFound');
  }
  $adminGuid = izapGetSiteAdmin_izap_videos(TRUE);

  if(TRUE){
    // notify admin
    notify_user($adminGuid,
                    $CONFIG->site_guid,
                    elgg_echo('izap_videos:notifySub:videoNotConverted'),
                    sprintf(elgg_echo('izap_videos:notifyAdminMsg:videoNotConverted'), $errorReason)
                    );
    // notify user
    notify_user($ownerGuid,
                    $CONFIG->site_guid,
                    elgg_echo('izap_videos:notifySub:videoNotConverted'),
                    elgg_echo('izap_videos:notifyUserMsg:videoNotConverted')
                    );
  }
  return $return;
}

/**
 * this function gives the FFmpeg video watermarking command
 *
 * @return string path
 */
function izapGetFfmpegVideoWatermarkCommand_izap_videos($videoPath = '') {
  global $CONFIG;

  $ffmpegPath = current(explode(' ', izapGetFfmpegVideoConvertCommand_izap_videos()));
  exec($ffmpegPath . ' -i ' . $videoPath . '  2>&1', $return_var);

  preg_match('/\d+x\d+/',implode('', $return_var),$mat_string);
  $dimensions = explode('x', $mat_string[0]);

  $margin = explode('x', izapAdminSettings_izap_videos('izapVideosWatermarkMargins'));
  //$margin = array(0,0);
  $watermark_h_w = explode('x', izapAdminSettings_izap_videos('izapVideoWatermarkHeightWidth'));

  $dimArray = array('top-left' => array(0,0),
                    'top-right' => array(($dimensions[0] - $watermark_h_w[0]),0),
                    'bottom-right' => array($dimensions[0] - $watermark_h_w[0],$dimensions[1] - $watermark_h_w[1]),
                    'bottom-left' => array(0,($dimensions[1] - $watermark_h_w[1])));


  switch(izapAdminSettings_izap_videos('izapVideoWatermarkPosition')){
    case "top-left":
      $x = $dimArray['top-left'][0]+$margin[0];
      $y = $dimArray['top-left'][1]+$margin[1];
    break;

    case "top-right":
      $x = $dimArray['top-right'][0]-$margin[0];
      $y = $dimArray['top-right'][1]+$margin[1];
    break;

    case "bottom-right":
      $x = $dimArray['bottom-right'][0]-$margin[0];
      $y = $dimArray['bottom-right'][1]-$margin[1];
    break;

    case "bottom-left":
      $x = $dimArray['bottom-left'][0]+$margin[0];
      $y = $dimArray['bottom-left'][1]-$margin[1];
    break;
  }
  
  $path = izapAdminSettings_izap_videos('izapVideoWatermark');
  $path = html_entity_decode($path);
  if(!$path)
    $path = '';

    $object = izapGetFfmpegVideoWatermarkObject_izap_videos();
    if(preg_match('/imlib2\.(so|dll)/', $path)){
      if(file_exists($object) && in_array(end(explode('.', $object)), array('png'))){ // if image path
  //      $path = '-vhook \''.$path.' -i '.$object.'\'';
        $path = '-vhook \''.$path.' -x '.$x.' -y '.$y.' -i '.$object . '\'';
      }else{ // if text
        if(izapAdminSettings_izap_videos('izapVideoWatermarkObjectMarquee') == 'YES'){
          $path = '-vhook \''.$path.' -c gray -F '.$CONFIG->pluginspath.'izap_videos/_graphics/izap.ttf/15 -x 0+0.3*N -y 7 -t '.$object . '\'';
        }elseif(izapAdminSettings_izap_videos('izapVideoWatermarkObjectMarquee') == 'NO'){
          $path = '-vhook \''.$path.' -c gray -F '.$CONFIG->pluginspath.'izap_videos/_graphics/izap.ttf/15 -x '.$x.' -y '.$y.' -t '.$object . '\'';
        }
      }
    }else{
      return '';
    }
  //echo $path;exit;
  return $path;
}

/**
 * this function gives the FFmpeg video watermarking object
 *
 * @return string path
 */
function izapGetFfmpegVideoWatermarkObject_izap_videos() {
  $path = izapAdminSettings_izap_videos('izapVideoWatermarkObject');
  $path = html_entity_decode($path);
  if(!$path)
    $path = '';
  return $path;
}

/**
 * this returns the array of supported videos for uploading
 *
 * @global <type> $CONFIG
 * @return array array of supported videos
 */
function izapGetSupportingVideoFormats_izap_videos(){
  global $IZAPSETTINGS;

  foreach ($IZAPSETTINGS->allowedExtensions as $formats) {
    $supportedFormats[] = $formats;
  }
  
  asort($supportedFormats);
  return $supportedFormats;
}