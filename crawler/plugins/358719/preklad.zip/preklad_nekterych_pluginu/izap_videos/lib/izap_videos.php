<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-3.0
*/

class IzapVideos extends IZAPElggBridge {
   private $IZAPSETTINGS;

  public function __construct($guid = null) {
    
   parent::__construct($guid);
   
   
   // set some initial values so that old videos can work
   if(empty($this->videosrc)){
      $this->videosrc = $this->IZAPSETTINGS->filesPath . 'file/' . $this->guid . '/' . friendly_title($this->title) . '.flv';
    }

    if(empty($this->converted)){
      $this->converted = 'yes';
    }
  }

  protected function initialise_attributes() {
    global $IZAPSETTINGS;
    parent::initialise_attributes();
    $this->attributes['subtype'] = 'izap_videos';
    $this->IZAPSETTINGS = $IZAPSETTINGS;
  }

  function input($input, $type){
    switch ($type) {
      case 'url':
        return $this->readUrl($input);
      break;

      case 'file':
        return $this->processFile($input);
      break;

      case 'embed':
        return $this->embedCode($input);
      break;
      
      default:
        return false;
      break;
    }
  }

  protected function readUrl($url){
    $urlFeed = new UrlFeed();
    $feed = $urlFeed->setUrl($url);
    return $feed;
  }

  protected function processFile($file){

    $returnValue =  new stdClass();
    $returnValue->type = 'uploaded';
    $fileName = $_FILES[$file['mainArray']]['name'][$file['fileName']];
    $error = $_FILES[$file['mainArray']]['error'][$file['fileName']];
    $tmpName = $_FILES[$file['mainArray']]['tmp_name'][$file['fileName']];
    $type = $_FILES[$file['mainArray']]['type'][$file['fileName']];
    $size = $_FILES[$file['mainArray']]['size'][$file['fileName']];

    if($error > 0){
      return 104;
    }

    if($size == 0){
      return 105;
    }


    // check supported video type
    if(!izapSupportedVideos_izap_videos($fileName)){
      return 106;
    }

    // check supported video size
    if(!izapCheckFileSize_izap_videos($size)){
      return 107;
    }

    // upload the tmp file
    $newFileName = izapGetFriendlyFileName_izap_videos($fileName);
    $this->setFilename('tmp/' . $newFileName);
    $this->open("write");
    $this->write(file_get_contents($tmpName));
    $returnValue->tmpFile = $this->getFilenameOnFilestore();

    // take snapshot of the video
    $image = new izapConvert($returnValue->tmpFile);
    if($image->photo()){
      $retValues = $image->getValues();

      if($retValues['imagename'] != '' && $retValues['imagecontent'] != ''){
        $this->setFilename('izap_videos/uploaded/' . $retValues['imagename']);
        $this->open("write");
        $this->write($retValues['imagecontent']);

        $thumb = get_resized_image_from_existing_file($this->getFilenameOnFilestore(), 120, 90);
        $this->setFilename('izap_videos/uploaded/' . $retValues['imagename']);
        $this->open("write");
        $this->write($thumb);

        $this->close();

        $returnValue->thumb = 'izap_videos/uploaded/' . $retValues['imagename'];
      }
    }

    return $returnValue;
  }

  protected function embedCode($code){
    $returnValue =  new stdClass();
    $returnValue->type = 'embed';
    $returnValue->videoSrc = $code;

    return $returnValue;
  }

  public function getPlayer($width = 640, $height = 385, $autoPlay = 0, $extraOptions = ''){
    $html = '';
    
    if($this->converted == 'yes'){
      switch ($this->videotype) {
        case 'youtube':
          $html = "<object width=\"$width\" height=\"$height\"><param name=\"movie\" value=\"{$this->videosrc}&hl=en&fs=1&autoplay={$autoPlay}\"></param><param name=\"wmode\" value=\"transparent\"></param><param name=\"allowFullScreen\" value=\"true\"></param><embed src=\"{$this->videosrc}&hl=en&fs=1&autoplay={$autoPlay} \" type=\"application/x-shockwave-flash\" allowfullscreen=\"true\" width=\"$width\" height=\"$height\" wmode=\"transparent\"></embed></object>";
          break;
        case 'vimeo':
          $html = "<object width=\"$width\" height=\"$height\"><param name=\"wmode\" value=\"transparent\"></param><param name=\"allowfullscreen\" value=\"true\" /><param name=\"allowscriptaccess\" value=\"always\" /><param name=\"movie\" value=\"{$this->videosrc}&amp;autoplay={$autoPlay}\" /><embed src=\"{$this->videosrc}&amp;autoplay={$autoPlay}\" type=\"application/x-shockwave-flash\" allowfullscreen=\"true\" allowscriptaccess=\"always\" width=\"$width\" height=\"$height\" wmode=\"transparent\"></embed></object>";
          break;
        case 'veoh':
          $html = "<embed src=\"{$this->videosrc}&videoAutoPlay={$autoPlay}\" allowFullScreen=\"true\" width=\"$width\" height=\"$height\" bgcolor=\"#FFFFFF\" type=\"application/x-shockwave-flash\" pluginspage=\"http://www.macromedia.com/go/getflashplayer\" wmode=\"transparent\"></embed>";
          break;
        case 'uploaded':
          $html = "<object width='".$width."' height='".$height."' id='flvPlayer'><param name='wmode' value='transparent' /><param name='allowFullScreen' value='true' /><param name='movie' value='".$this->IZAPSETTINGS->playerPath."?movie=".$this->videosrc . $extraOptions ."&volume=70&autoload=on&mute=off&autorewind=on&muteonly=off' /><embed src='".$this->IZAPSETTINGS->playerPath."?movie=".$this->videosrc . $extraOptions ."&volume=70&autoload=on&mute=off&autorewind=on&muteonly=off' width='".$width."' height='".$height."' allowFullScreen='true' type='application/x-shockwave-flash' wmode='transparent'/></object>";
          break;

        case 'embed':
        case 'others':
          $html = izapGetReplacedHeightWidth_izap_videos($height, $width, $this->videosrc);
          break;
      }
    }else{
      $html = elgg_echo('izap_videos:processed');
    }
    return $html;
  }

  public function getThumb($pathOnly = false, $attArray = array()){
    $html = '';
    $attString = '';
    $imagePath = $this->IZAPSETTINGS->filesPath . 'image/' . $this->guid . '/' . friendly_title($this->title) . '.jpg';
    if(count($attArray) > 0){
      foreach ($attArray as $att => $value) {
        $attString .= ' '.$att.'="'.$value.'" ';
      }
    }
    if($pathOnly){
      $html = $imagePath;
    }else{
      $html = '<img src="'.$imagePath.'" '.$attString.'>';
    }

    return $html;
  }

  public function updateViews(){
    if($this->converted == 'yes'){
      izapGetAccess_izap_videos();
        $this->views = ((int)$this->views + 1);
      izapRemoveAccess_izap_videos();
    }
  }

  public function getViews(){
    return $this->views;
  }

  public function canCopy(){
    if($this->owner_guid != get_loggedin_userid()
      && $this->converted == 'yes'
      && isloggedin()
      ){
      return TRUE;
    }

    // default
    return FALSE;
  }

  public function getAttributes(){
    $attrib = new stdClass();
    $attrib->guid = $this->guid;
    $attrib->title = $this->title;
    $attrib->owner_guid = $this->owner_guid;
    $attrib->container_guid = $this->container_guid;
    $attrib->description = $this->description;
    $attrib->access_id = $this->access_id;
    $attrib->tags = $this->tags;
    $attrib->views = $this->views;
    $attrib->videosrc = $this->videosrc;
    $attrib->videotype = $this->videotype;
    $attrib->imagesrc = $this->imagesrc;
    $attrib->videotype_site = $this->videotype_site;
    $attrib->videotype_id = $this->videotype_id;
    $attrib->converted = $this->converted;
    $attrib->videofile = $this->videofile;
    $attrib->orignalfile = $this->orignalfile;
    
    return $attrib;
  }

 public function delete(){
   // delete it from the queue if not converted yet
    if($this->converted == 'no'){
      $queueEntry = get_entities_from_metadata('videoId', $this->guid, 'object', 'izapVideoQueue', $this->owner_guid);
      if($queueEntry){
        izapDeleteQueueObject_izap_videos($queueEntry[0]);
      }
      $queue = get_entities('object', 'izapVideoQueue');
      if(!$queue){ // resets the queue if it was the last video
        izapAdminSettings_izap_videos('isQueueRunning', 'no', TRUE);
      }
    }

    $imagesrc = $izap_videos->imagesrc;
    $filesrc = $izap_videos->videofile;
    $ofilesrc = $izap_videos->orignalfile;

    $this->setFilename($imagesrc);
    $image_file = $this->getFilenameOnFilestore();
    if(file_exists($image_file)){
      @unlink($image_file);
    }

    $this->setFilename($filesrc);
    $video_file = $this->getFilenameOnFilestore();
    if(file_exists($video_file)){
      @unlink($video_file);
    }

    $this->setFilename($ofilesrc);
    $orignal_file = $this->getFilenameOnFilestore();
    if(file_exists($orignal_file)){
      @unlink($orignal_file);
    }

    return delete_entity($this->guid, TRUE);
 }

 function getOwnerUrl(){
   global $CONFIG;
   return $CONFIG->wwwroot . 'pg/izap_videos/list/' . $this->getOwnerEntity()->username . '/';
 }
}


/**
 * returns the file name, that ffmpeg can operate
 *
 * @param string $fileName file name
 * @return string all formated file name
 */
function izapGetFriendlyFileName_izap_videos($fileName){
  $new_name = time() . preg_replace('/[^A-Za-z0-9\.]+/','_',$fileName);
  return $new_name;
}

/**
 * this function checks the supported videos
 * @global <type> $CONFIG
 * @param string $videoFileName video name with extension
 * @return boolean TRUE if supported else FALSE
 */
function izapSupportedVideos_izap_videos($videoFileName) {
  global $IZAPSETTINGS;
  $supportedFormats = $IZAPSETTINGS->allowedExtensions;
  $extension = strtolower(end(explode('.', $videoFileName)));
  if(in_array($extension, $supportedFormats))
    return TRUE;

  return FALSE;
}

/**
 * this function will check the max upload limit for file
 *
 * @param integer $fileSize in Mb
 * @return boolean true if everything is ok else false
 */
function izapCheckFileSize_izap_videos($fileSize) {
  $maxFileSize = (int) izapAdminSettings_izap_videos('izapMaxFileSize');
  $maxSizeInBytes = $maxFileSize*1024*1024;

  if($fileSize > $maxSizeInBytes)
    return FALSE;

  return TRUE;
}

function izapGetReplacedHeightWidth_izap_videos($newHeight, $newWidth, $object){
  $videodiv = preg_replace('/width=["\']\d+["\']/', 'width="' . $newWidth . '"', $object);
  $videodiv = preg_replace('/width:\d+/', 'width:'.$newWidth, $videodiv);
  $videodiv = preg_replace('/height=["\']\d+["\']/', 'height="' . $newHeight . '"', $videodiv);
  $videodiv = preg_replace('/height:\d+/', 'height:'.$newHeight, $videodiv);

  return $videodiv;
}