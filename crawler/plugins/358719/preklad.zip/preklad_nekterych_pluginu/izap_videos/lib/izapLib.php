<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-3.0
*/

include_once ('settings.php');

function izapLoadLib_izap_videos(){
  // Get config
  global $CONFIG;
      
  $file_exceptions = array(
										'.','..',
										'.DS_Store',
										'Thumbs.db',
										'.svn',
										'CVS','cvs',
										'settings.php','izapLib.php'
									);

		// Get the list of files to include, and alphabetically sort them
			$files = get_library_files(dirname(__FILE__),$file_exceptions);
			asort($files);

		// Include them
			foreach($files as $file) {
				if (!include_once($file))
					throw new InstallationException("Could not load {$file}");
			}
}
/**
 * checks if the field is null or not
 *
 * @param variable $input any variable
 * @param array $exclude in case if we want to exclude some values
 * @return boolean true if null else false
 */
function izapIsNull_izap_videos($input, $exclude = array()) {
  if(!is_array($input)){
    $input = array($input);
  }

  if(count($input) >= 1){
    foreach ($input as $key => $value) {
      if(!in_array($key, $exclude)){
        //if(is_null($value) || empty($value)){
        if(empty($value)){
          return TRUE;
        }
      }
    }
  }else{
    return TRUE;
  }

  return FALSE;
}

/**
 * it creates the form, from the provided array
 *
 * @global GLOBAL $CONFIG
 * @param array $mainArray main form array
 * @param string $mainArray['action'] form action
 * @param object $mainArray['values'] values for the elements
 * @param string $mainArray['language'] initial label string from language file
 * @param string $mainArray['postArray'] array name for posting elements
 * @param char $mainArray['requiredMark'] anything which will attach with the require fields
 * @param boolean $mainArray['returnForm'] is we want the form back
 * @param string $mainArray['formId'] form id
 * @return html
 */
function izapCreateForm_izap_videos($mainArray){
  global $CONFIG;

  // default array
  $defaultArray = array(
    'values' => new stdClass(),
    'language' => '',
    'postArray' => 'izap',
    'requiredMark' => '*',
    'returnForm' => TRUE,
    'formId' => 'izapForm',
    'categories' => FALSE
  );

  // get the remaining array
  $remainingArray = array_diff_key($defaultArray, $mainArray);

  // all array
  $mainArray = array_merge($mainArray, $remainingArray);

  // check if we have required elements
  if(!is_array($mainArray['fromElements']) || $mainArray['action'] == ''){
    return FALSE;
  }

  // create the fields fromt the array
  foreach ($mainArray['fromElements'] as $name => $options) {
    // create array for the input field to work
    $elementMainArray = array(
      'name' => $name,
      'options' => $options,
      'value' => $mainArray['values']->$name,
      'language' => $mainArray['language'],
      'postArray' => $mainArray['postArray'],
      'requiredMark' => $mainArray['requiredMark'],
    );

    if(!in_array($name, $mainArray['exclude'])){
      // creats the fields
      $form .= izapCreateField_izap_videos($elementMainArray);
    }
  }

  // if we want elgg categories
  if($mainArray['categories']){
    $form .= elgg_view('categories', $mainArray['vars']);;
  }

  // if we want to return the complete form
  if($mainArray['returnForm']){
    // submit  buttom
    $form .= elgg_view('input/submit', array(
                                            'value' => elgg_echo($mainArray['language'] . 'save'),
                                            'js' => 'id="butnSubmit_"' .$mainArray['formId']. '',
                                          )
                      );

    // all form
    $form = elgg_view('input/form', array(
                                          'body' => $form,
                                          'action' => $CONFIG->wwwroot . 'action/' . $mainArray['action'],
                                          'enctype' => 'multipart/form-data',
                                          'internalid' => $mainArray['formId'],
                                          )
                     );
  }

  return $form;
}

/**
 * this converts the array into object
 *
 * @param array $array
 * @return object
 */
function izapArrayToObject_izap_videos($array){
  if(!is_array($array))
    return FALSE;

  $obj = new stdClass();
  foreach ($array as $key => $value) {
    if($key != '' && $value != ''){
      $obj->$key = $value;
    }
  }

 return $obj;
}

/**
 * this function acutally creats the input fields
 *
 * @param string $mainArray['name'] name for the input field
 * @param array $mainArray['options'] all the required parameters
 * @param array $mainArray['value'] initial values for the fields
 * @param string $mainArray['language'] starting text for the label
 * @param string $mainArray['postArray'] array name
 * @param string $mainArray['requiredMark'] sign for the compusory fields
 * @return html full input fields
 */
function izapCreateField_izap_videos($mainArray){
  $requiredText = ($mainArray['options']['required']) ? $mainArray['requiredMark'] : '';
  $label = '<p><label>'.elgg_echo($mainArray['language'] . $mainArray['name']) . ' ' . $requiredText .'<br />%s</label></p>';

  $tmpField = elgg_view('input/' . $mainArray['options']['type'], array(
                                                      'internalname' => $mainArray['postArray']. '[' . $mainArray['name'] . ']',
                                                      'internalid' => $mainArray['options']['internalid'],
                                                      'value' => ($mainArray['value'] == '') ? $mainArray['options']['value'] : $mainArray['value'],
                                                      'options' => $mainArray['options']['options'],
                                                      'options_values' => $mainArray['options']['options_values'],
                                                      'js' => $mainArray['options']['js'],
                                                      'class' => $mainArray['options']['class'],
                                                      'disabled' => $mainArray['options']['disabled'],
                                                      'hidden' => $mainArray['options']['hidden'],
                                                      'noEditer' => $mainArray['options']['noEditer'],
                                                     )
                    );

  // if hidden field then lables are not needed
  if($mainArray['options']['type'] == 'hidden'){
    $final = $tmpField;
  }else{
    $final = sprintf($label, $tmpField);
  }

return $final;
}

/**
 * sets or gets the private settings for the izap_videos
 * 
 * @param string $settingName setting name
 * @param mix $values sting or array of value
 * @param boolean $override if we want to force override the value
 * @param boolean $makeArray if we want the return value in the array
 * @return value array or string
 */
function izapAdminSettings_izap_videos($settingName, $values = '', $override = false, $makeArray = false){
    // get the old value
    $oldSetting = get_plugin_setting($settingName, 'izap_videos');

    if(is_array($values)){
      $pluginValues = implode('|', $values);
    }else{
      $pluginValues = $values;
    }
    // if it is not set yet
    if(empty($oldSetting) || $override){
      if(!set_plugin_setting($settingName, $pluginValues, 'izap_videos')){
        return FALSE;
      }
    }

    if($oldSetting){
      $oldArray = explode('|', $oldSetting);
      if(count($oldArray) > 1){
        $returnVal = $oldArray;
      }else{
        $returnVal = $oldSetting;
      }
    }else{
      $returnVal = $values;
    }

    if(!is_array($returnVal) && $makeArray){
      $newReturnVal[] = $returnVal;
      $returnVal = $newReturnVal;
    }
    
  return $returnVal;
}

/**
 * checks if it is windows
 * 
 * @return boolean TRUE if windows else FALSE
 */
function izapIsWin_izap_videos(){
  if(strtolower(PHP_OS) == 'winnt'){
    return TRUE;
  }else{
    return FALSE;
  }
}

/**
 * gets the video add options from the admin settings
 * 
 * @return array
 */
function izapGetVideoOptions_izap_videos(){
  $videoOptions = izapAdminSettings_izap_videos('izapVideoOptions', '', FALSE, TRUE);

  return $videoOptions;
}

/**
 * this function will check that is the given id is of izap_videos
 * 
 * @param int $videoId video id
 * @return video entity or FALSE
 */
function izapVideoCheck_izap_videos($videoId, $canEditCheck = FALSE) {
  $videoId = (int) $videoId;
  if($videoId){
    $video = get_entity($videoId);

      if($canEditCheck && !$video->canEdit())
        forward();
      
    if($video instanceof IzapVideos)
      return $video;
  }

  //register_error(elgg_echo('izap_videos:noVideo'));
  forward();
}

/**
 * this function saves the entry for futher processing
 * @param string $file main filepath
 * @param int $videoId video guid
 * @param int $ownerGuid owner guid
 * @param int $accessId access id for entry to save (must be kept public)
 */
function izapSaveFileInfoForConverting_izap_videos($file, $video, $accessId = 2){
// this will not let save any thing if there is no file to convert
if($file == '')
  return ;

  $queue = new ElggObject();
  $queue->subtype = 'izapVideoQueue';
  $queue->access_id = ACCESS_PUBLIC;
  $queue->mainFile = $file;
  $queue->videoId = $video->guid;
  $queue->videoTitle = $video->title;
  $queue->videoUrl = $video->getUrl();
  $queue->videoOwner = $video->owner_guid;
  $queue->videoAccess = $accessId;
  $queue->save();

  // trigger the queue after upload
  izapTrigger_izap_videos();
}

/**
 * this function triggers the queue
 *
 * @global <type> $CONFIG
 */
function izapTrigger_izap_videos(){
  global $CONFIG;
  $PHPpath = izapGetPhpPath_izap_videos();
  if(!izapIsQueueRunning_izap_videos()){
    izapAdminSettings_izap_videos('isQueueRunning', 'yes', TRUE);
    if(izapIsWin_izap_videos()){
      pclose( popen("start \"MyProcess\" \"cmd /C ".$PHPpath . " " . $CONFIG->pluginspath . "izap_videos/izap_convert_video.php izap web", "r") );
    }else{
      exec($PHPpath . ' ' . $CONFIG->pluginspath . 'izap_videos/izap_convert_video.php izap web > /dev/null 2>&1 &');
    }
  }
}

/**
 * this function gives the path of PHP
 *
 * @return string path
 */
function izapGetPhpPath_izap_videos() {
  $path = izapAdminSettings_izap_videos('izapPhpInterpreter');
  $path = html_entity_decode($path);
  if(!$path)
    $path = '';
  return $path;
}

/**
 * this function checks if the queue is running or not
 *
 * @return boolean TRUE if yes or FALSE if no
 */
function izapIsQueueRunning_izap_videos() {
  $status = izapAdminSettings_izap_videos('isQueueRunning', 'no');

  if($status == 'yes')
    return TRUE;
  else
    return FALSE;

}

/**
 * resets queue
 *
 * @return boolean
 */
function izapResetQueue_izap_videos(){
  return izapAdminSettings_izap_videos('isQueueRunning', 'no', TRUE);
}

/**
 * clears queue and resets it
 *
 * @return boolean
 */
function izapEmptyQueue_izap_videos(){
  $pending_videos = izapGetNotConvertedVideos_izap_videos();
  if($pending_videos){
    foreach($pending_videos as $video){
        $video->delete();
    }
  }

  return izapResetQueue_izap_videos();
}

/**
 * grants the access
 *
 * @param <type> $functionName
 */
function izapGetAccess_izap_videos($functionName = 'izapGetAccessForAll_izap_videos') {
  register_plugin_hook('permissions_check', 'object', $functionName);
}

/**
 * remove access
 *
 * @global global $CONFIG
 * @param string $functionName
 */
function izapRemoveAccess_izap_videos($functionName = 'izapGetAccessForAll_izap_videos') {
  global $CONFIG;
  if(isset($CONFIG->hooks['permissions_check']['object'])){
    foreach ($CONFIG->hooks['permissions_check']['object'] as $key => $hookFunction) {
      if($hookFunction == $functionName){
        unset($CONFIG->hooks['permissions_check']['object'][$key]);
      }
    }
  }
}

/**
 * elgg hook
 *
 * @param <type> $hook
 * @param <type> $entity_type
 * @param <type> $returnvalue
 * @param <type> $params
 * @return <type>
 */
function izapGetAccessForAll_izap_videos($hook, $entity_type, $returnvalue, $params) {
  return TRUE;
}

function izapRunQueue_izap_videos() {
  $queue = get_entities('object', 'izapVideoQueue', 0, 'time_created', 0);
  if(is_array($queue)){
    foreach($queue as $pending) {
      $converted = izapConvertVideo_izap_videos($pending->mainFile, $pending->videoId, $pending->videoTitle, $pending->videoUrl, $pending->videoOwner);

      // if the video is not converted properly then delete it
      if(!$converted){
        if(delete_entity($pending->videoId, TRUE))
          echo 'Video Entity not deleted';
      }

      // finally delete the entry from queue
      izapDeleteQueueObject_izap_videos($pending);
    }

    // recheck if there is new video in the queue
    $queue = get_entities('object', 'izapVideoQueue', 0, 'time_created');
    if(is_array($queue))
      izapRunQueue_izap_videos();
  }

  return ;
}

/**
 * this function deletes video queue entity from the elgg
 *
 * @global global $CONFIG
 * @param int $id guid of queue
 * @return result if deleted else FALSE
 */
function izapDeleteQueueObject_izap_videos($queueEntity) {
  global $CONFIG;

  $removeChar = '-' . (strlen(end(explode('.', $queueEntity->mainFile))) + 1);
  $tmpVideoFile = substr($queueEntity->mainFile, 0, $removeChar) . '_c.flv';
  $tmpImageFile = substr($queueEntity->mainFile, 0, $removeChar) . '_i.png';
  
  if(file_exists($queueEntity->mainFile)){
    @unlink($queueEntity->mainFile);
  }

  if(file_exists($tmpVideoFile)){
    @unlink($tmpVideoFile);
  }

  if(file_exists($tmpImageFile)){
    @unlink($tmpImageFile);
  }

  $result = $queueEntity->delete();
  return $result;
}

/**
 * this function gets the site admin
 *
 * @param boolean $guid if only guid is required
 * @return mix depends on the input and result
 */
function izapGetSiteAdmin_izap_videos($guid = FALSE) {
  $admin = get_entities_from_metadata('admin', 1, 'user', '', 0, 1, 0);
    if($admin[0]->admin || $admin[0]->siteadmin) {
      if($guid)
        return $admin[0]->guid;
      else
        return $admin[0];
    }

  return FALSE;
}

/**
 * this function copies the files from one location to another
 *
 * @param int $sourceOwnerGuid guid of the file owner
 * @param string $sourceFile source file location
 * @param int $destinationOwnerGuid guid of new file owner, if not given then takes loggedin user id
 * @param string $destinationFile destination location, if blank then same as source
 */
function izapCopyFiles_izap_videos($sourceOwnerGuid, $sourceFile, $destinationOwnerGuid = 0, $destinationFile = '') {
  $filehandler = new ElggFile();

  $filehandler->owner_guid = $sourceOwnerGuid;
  $filehandler->setFilename($sourceFile);
  $filehandler->open('read');
  $sourceFileContents = $filehandler->grabFile();

  if($destinationFile == '')
    $destinationFile = $sourceFile;

  if(!$destinationOwnerGuid)
    $destinationOwnerGuid = get_loggedin_userid();

  $filehandler->owner_guid = $destinationOwnerGuid;
  $filehandler->setFilename($destinationFile);
  $filehandler->open('write');
  $filehandler->write($sourceFileContents);

  $filehandler->close();
}

/**
 * this function get all the videos for a user or all users
 *
 * @param int $ownerGuid id of the user to get videos for
 * @param boolean $count Do u want the total or videos ? :)
 * @return videos or false
 */
function izapGetAllVideos_izap_videos($ownerGuid = 0, $count = FALSE, $izapVideoType = 'object', $izapSubtype = 'izap_videos') {
  $videos = get_entities($izapVideoType, $izapSubtype, $ownerGuid, '', 0);
  return $videos;
}

/**
 * wraps the string to given number of words
 *
 * @param string $string string to wrap
 * @param integer $length max length of sting
 * @return sting $string wrapped sting
 */
function izapWordWrap_izap_videos($string, $length = 300, $addEnding = false){
    if (strlen($string) <= $length) {
        $string = $string; //do nothing
    }
    else {
        $string = wordwrap(str_replace("\n", "", $string), $length);
        $string = substr($string, 0, strpos($string, "\n"));

        if($addEnding){
          $string .= '...';
          if(is_string($addEnding)){
            $string .= '<a href="'.$addEnding.'">Read more</a>';
          }
        }
    }

    return $string;
}

/**
 * this function will tell if the admin wants to include the index page widget
 *
 * @return boolean true for yes and false for no
 */
function izapIncludeIndexWidget_izap_videos() {
  $var = izapAdminSettings_izap_videos('izapIndexPageWidget', 'YES');
  
  if($var == 'NO')
    return FALSE;

  return TRUE;
}

/**
 * this function will tell if the admin wants to include the top bar upload button
 *
 * @return boolean true for yes and false for no
 */
function izapTopBarWidget_izap_videos(){
  $var = izapAdminSettings_izap_videos('izapTopBarWidget', 'YES');
  
  if($var == 'NO')
    return FALSE;

  return TRUE;
}

/**
 * manages the url for embeding the videos
 *
 * @param string $text all text
 * @return string
 */
function izapParseUrls_izap_videos($text) {
  return preg_replace_callback('/(^flv=)(?<!=["\'])((ht|f)tps?:\/\/[^\s\r\n\t<>"\'\!\(\)]+)/i',
  create_function(
      '$matches',
      '
        $url = $matches[1];
        $urltext = str_replace("/", "/<wbr />", $url);
        return "<a href=\"$url\" style=\"text-decoration:underline;\">$urltext</a>";
      '
  ), $text);
}

/**
 * gets the not converted videos
 * 
 * @return boolean or entites
 */
function izapGetNotConvertedVideos_izap_videos(){
  $not_converted_videos = get_entities_from_metadata('converted', 'no', 'object', 'izap_videos', 0, 999999);
  if($not_converted_videos){
    return $not_converted_videos;
  }

  return FALSE;
}


function izapReadableSize_izap_videos($inputSize){
		if (strpos($inputSize, 'M'))
			return $inputSize . 'B';

		$outputSize = $inputSize / 1024;
		if ($outputSize < 1024) {
			$outputSize = number_format($outputSize, 2);
			$outputSize .= ' KB';
		} else {
			$outputSize = $outputSize / 1024;
			if($outputSize < 1024) {
				$outputSize = number_format($outputSize, 2);
				$outputSize .= ' MB';
			} else {
				$outputSize = $outputSize / 1024;
				$outputSize = number_format($outputSize, 2);
				$outputSize .= ' GB';
			}
		}
	return $outputSize;
}

/**
 * runs some setups on enable of plugin
 * 
 * @global <type> $CONFIG
 */
function izapSetup_izap_videos(){
  global $CONFIG;

  // update the exsting subtye entry
  $id = get_subtype_id('object', 'izap_videos');
  if($id){
    $query = 'UPDATE ' . $CONFIG->dbprefix . 'entity_subtypes SET class = "IzapVideos" WHERE id = ' . $id;
    update_data($query);
  }else{
    add_subtype('object', 'izap_videos', 'IzapVideos');
  }

  // clears the old plugin settings
  clear_plugin_setting('', 'izap_videos');
}