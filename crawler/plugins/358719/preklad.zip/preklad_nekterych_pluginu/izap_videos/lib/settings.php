<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-3.0
*
* contains the default settings for the izap_videos plugin
*/

// get global
global $CONFIG;
global $IZAPSETTINGS;

$IZAPSETTINGS = new stdClass();

$IZAPSETTINGS->filesPath = $CONFIG->wwwroot . 'pg/izap_videos_files/';
$IZAPSETTINGS->playerPath = $CONFIG->wwwroot . 'mod/izap_videos/player/izap_player.swf';
$IZAPSETTINGS->apiUrl = 'http://www.izap.in/izap_videos/getFeed.php';
$IZAPSETTINGS->allowedExtensions = array('avi', 'flv', '3gp', 'mp4', 'wmv', 'mpg', 'mpeg');
$IZAPSETTINGS->ffmpegPath = $CONFIG->pluginspath . 'izap_videos/ffmpeg/bin/ffmpeg.exe';
$IZAPSETTINGS->ffmpegPresetPath = $CONFIG->pluginspath . 'izap_videos/ffmpeg/presets/libx264-hq.ffpreset';

// set default inputs for the add/edit form
$IZAPSETTINGS->defaultForm = array(
  'title' => array(
          'type' => 'text',
          'required' => TRUE,
      ),

  'videoImage' => array(
          'type' => 'file'
      ),

  'description' => array(
          'type' => 'longtext'
      ),

  'access_id' => array(
          'type' => 'access',
          'value' => ACCESS_PUBLIC,
      ),

  'tags' => array(
          'type' => 'tags'
      ),

  'guid' => array(
          'type' => 'hidden',
          'value' => 0,
      ),

  'container_guid' => array(
          'type' => 'hidden',
          'value' => get_loggedin_userid(),
  ),
);

// parameters for the url adding
$IZAPSETTINGS->addUrl = array(
  'videoUrl' => array(
          'type' => 'text',
          'required' => TRUE,
      ),

  'videoType' => array(
          'type' => 'hidden',
          'value' => 'OFFSERVER',
      ),
);
$IZAPSETTINGS->addUrl = array_merge($IZAPSETTINGS->addUrl, $IZAPSETTINGS->defaultForm);

// parameters for the file adding
$IZAPSETTINGS->addFile = array(
  'videoFile' => array(
          'type' => 'file',
          'required' => TRUE,
      ),

  'videoType' => array(
          'type' => 'hidden',
          'value' => 'ONSERVER',
      ),
);
$IZAPSETTINGS->addFile = array_merge($IZAPSETTINGS->addFile, $IZAPSETTINGS->defaultForm);

// parameters for the embed code adding
$IZAPSETTINGS->addCode = array(
  'videoEmbed' => array(
          'type' => 'text',
          'required' => TRUE,
      ),

  'videoType' => array(
          'type' => 'hidden',
          'value' => 'EMBED',
      ),
);
$IZAPSETTINGS->addCode = array_merge($IZAPSETTINGS->addCode, $IZAPSETTINGS->defaultForm);

// lets create main form array
$IZAPSETTINGS->videoForms = array(
  'OFFSERVER' => $IZAPSETTINGS->addUrl,
  'ONSERVER' => $IZAPSETTINGS->addFile,
  'EMBED' => $IZAPSETTINGS->addCode,
);

//admin form
$IZAPSETTINGS->settingsForm =  array(
  'izapVideoOptions' => array(
          'type' => 'checkboxes',
          'options' => array(
                  elgg_echo('izap_videos:adminSettings:offServerVideos') => 'OFFSERVER',
                  elgg_echo('izap_videos:adminSettings:onServerVideos') => 'ONSERVER',
                  elgg_echo('izap_videos:adminSettings:embedCode') => 'EMBED',
                  ),
          'class' => 'izap_videos_checkboxes',
          'value' => izapAdminSettings_izap_videos('izapVideoOptions', array('OFFSERVER', 'ONSERVER', 'EMBED')),
      ),

  'izapPhpInterpreter' => array(
          'type' => 'text',
          'value' => izapAdminSettings_izap_videos('izapPhpInterpreter', (izapIsWin_izap_videos()) ? '' : '/usr/bin/php'),
      ),

  'izapVideoCommand' => array(
          'type' => 'text',
          'value' => izapAdminSettings_izap_videos(
                              'izapVideoCommand',
                              (izapIsWin_izap_videos()) ?
                                $IZAPSETTINGS->ffmpegPath . ' -y -i [inputVideoPath] -vcodec libx264 -vpre '.$IZAPSETTINGS->ffmpegPresetPath.' -b 300k -bt 300k -ar 22050 -ab 48k -s 400x400 [outputVideoPath]'
                                  :
                                '/usr/bin/ffmpeg -y -i [inputVideoPath] -vcodec libx264 -vpre hq  -b 300k  -bt 300k  -acodec libfaac  -ar 22050  -ab 48k [watermarkCommnad] [outputVideoPath]'
                            ),
      ),

  'izapVideoThumb' => array(
          'type' => 'text',
          'value' => izapAdminSettings_izap_videos(
                              'izapVideoThumb',
                              (izapIsWin_izap_videos()) ?
                                $IZAPSETTINGS->ffmpegPath . ' -y -i [inputVideoPath] -vframes 1 -ss 00:00:10 -an -vcodec png -f rawvideo -s 320x240 [outputImage]'
                                  :
                                '/usr/bin/ffmpeg -y -i [inputVideoPath] -vframes 1 -ss 00:00:10 -an -vcodec png -f rawvideo -s 320x240 [outputImage]'
                            ),
      ),

  'izapVideoWatermark' => array(
          'type' => 'text',
          'value' => izapAdminSettings_izap_videos('izapVideoWatermark', (izapIsWin_izap_videos()) ? '' : '/usr/local/lib/vhook/imlib2.so'),
      ),

  'izapVideoWatermarkObject' => array(
          'type' => 'text',
          'value' => izapAdminSettings_izap_videos('izapVideoWatermarkObject', (izapIsWin_izap_videos()) ? '' : $CONFIG->pluginspath . 'izap_videos/_graphics/v-small.png'),

      ),

  'izapVideoWatermarkPosition' => array(
          'type' => 'radio',
          'options' => array(
                  elgg_echo('izap_videos:adminSettings:marqueePositionTopLeft') => 'top-left',
                  elgg_echo('izap_videos:adminSettings:marqueePositionTopRight') => 'top-right',
                  elgg_echo('izap_videos:adminSettings:marqueePositionBottomLeft') => 'bottom-left',
                  elgg_echo('izap_videos:adminSettings:marqueePositionBottomRight') => 'bottom-right',
                  ),
          'value' => izapAdminSettings_izap_videos('izapVideoWatermarkPosition', (izapIsWin_izap_videos()) ? '' : 'top-left'),
      ),

  'izapVideoWatermarkObjectMarquee' => array(
          'type' => 'checkboxes',
          'options' => array(
                  elgg_echo('izap_videos:adminSettings:makeMarquee') => 'YES',
                  ),
          'value' => izapAdminSettings_izap_videos('izapVideoWatermarkObjectMarquee', (izapIsWin_izap_videos()) ? '' : '', false, true),
      ),
      
  'izapVideosWatermarkMargins' => array(
          'type' => 'text',
          'value' => izapAdminSettings_izap_videos('izapVideosWatermarkMargins', (izapIsWin_izap_videos()) ? '' : '1x1'),
      ),

  'izapVideoWatermarkHeightWidth' => array(
          'type' => 'text',
          'value' => izapAdminSettings_izap_videos('izapVideoWatermarkHeightWidth', (izapIsWin_izap_videos()) ? '' : '100x40'),
      ),

  'izapMaxFileSize' => array(
          'type' => 'text',
          'value' => izapAdminSettings_izap_videos('izapMaxFileSize', '20'),
      ),

  'izapExtendVideoSupport' => array(
          'type' => 'checkboxes',
          'options' => array(
                  elgg_echo('izap_videos:adminSettings:extendVideoSupport') => 'YES',
                  ),
          'value' => izapAdminSettings_izap_videos('izapExtendVideoSupport', 'YES', FALSE, TRUE),
      ),

  'izapIndexPageWidget' => array(
          'type' => 'checkboxes',
          'options' => array(
                  elgg_echo('izap_videos:adminSettings:addOnHomePage') => 'YES',
                  ),
          'value' => izapAdminSettings_izap_videos('izapIndexPageWidget', 'YES', FALSE, TRUE),
      ),

  'izapTopBarWidget' => array(
          'type' => 'checkboxes',
          'options' => array(
                  elgg_echo('izap_videos:adminSettings:addOnTopBar') => 'YES',
                  ),
          'value' => izapAdminSettings_izap_videos('izapTopBarWidget', 'YES', FALSE, TRUE),
      ),

  'izapGiveUsCredit' => array(
          'type' => 'checkboxes',
          'options' => array(
                  elgg_echo('izap_videos:adminSettings:giveUsCredit') => 'YES',
                  ),
          'value' => izapAdminSettings_izap_videos('izapGiveUsCredit', 'YES', FALSE, TRUE),
      ),
);

$IZAPSETTINGS->settingsFormExclude = array(
  'izapVideoWatermark',
  'izapVideoWatermarkObject',
  'izapVideoWatermarkPosition',
  'izapVideoWatermarkObjectMarquee',
  'izapVideosWatermarkMargins',
  'izapVideoWatermarkHeightWidth',
);

// load all the required files
izapLoadLib_izap_videos();