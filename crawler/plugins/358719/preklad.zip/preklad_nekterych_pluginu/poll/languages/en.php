<?php

	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'poll' => "Anketa",
			'polls' => "Ankety",
			'poll:user' => "Anketa od %s",
			'polls:user' => "Ankety od %s",
			'poll:user:friends' => "Ankety od přátel %s",
			'poll:your' => "Vaše Ankety",
			'poll:posttitle' => "Anketa %s od %s",
			'poll:friends' => "Ankety Přátel",
			'poll:yourfriends' => "Nejnovější ankety vašich přátel",
			'poll:everyone' => "Ankety z celé sítě",
			'poll:read' => "Číst anketu",
			'poll:addpost' => "Vytvořit anketu",
			'poll:editpost' => "Upravit anketu",
			'poll:text' => "Text ankety",
			'poll:strapline' => "%s",			
			'item:object:poll' => 'Ankety',
			'poll:question' => "Anketní otázka",
			'poll:responses' => "Nožné odpovědi (jednolivé odpovědi oddělte čárkou)",
'poll:approvelist'=>"Ankety k odsouhlasení",
            'poll:mypolls'=>"Moje Ankety",
            'poll:displayyourpoll'=>"Tato miniaplikace zobrazuje vaše ankety",
            'poll:latestComunityPoll'=>"Nejnovějsí ankety",
            'poll:displaymostrecentpoll'=>"Zobrazí nejnovější ankety",
	    'poll:saved:request'=>"Požadavek byl uložen a čeká na schválení",
            'poll:enabled'=>"Anketa byla  spuštěna",
            'poll:saved'=>"Anketa byla uložena!",
            'poll:requests'=>"Ankety ke schválení",
            'poll:enable:on'=>"Spustit",
            'poll:results'=>"Výsledky",

		/**
	     * poll widget
	     **/	
	     'poll:widget:label:displaynum' => "Kolik anket chcete zobrazit?",
	     'poll:usepolladmin'=>"Ankety moderované síťovým administrátorem",
            'poll:usepolladmin:yes'=>"Ano",
            'poll:usepolladmin:no'=>"Ne",
			
         /**
	     * poll river
	     **/
	        
	        //generic terms to use
	        'poll:river:created' => "vytvořeno %s",
	        'poll:river:updated' => "upraveno %s",
	        'poll:river:posted' => "odesláno %s",
            'poll:river:voted'=>"hlasovalo %s",
	        
	        //these get inserted into the river links to take the user to the entity
	        'poll:river:create' => "nová anketa - ",
	        'poll:river:update' => "anketa  - ",
	        'poll:river:annotate' => "komentář k anketě - ",
	        'poll:river:annotate:create' => "konentovat anketu - ",
            'poll:river:vote'=>"anketa - ",

		/**
		 * Status messages
		 */
	
			'poll:posted' => "Vaše anketa byla úspěšně uložena.",
			'poll:responded' => "Děkuji, váš hlas byl zaznamenán.",
			'poll:deleted' => "Vaše anketa byla úspšne smzána.",
			'poll:totalvotes' => "Celkový počet hlasů: ",
			'poll:voted' => "Váš hlas byl zaznamenán. Děkuji za vaši účast",
			
	
		/**
		 * Error messages
		 */
	
			'poll:save:failure' => "Vaši anketu nelze uložit. Prosím zkuste to znova.",
			'poll:blank' => "Omlouváme se; k vytvoření ankety je třeba vyplnit otazku a odvědi na otázku.",
			'poll:notfound' => "Omlouváme se; specifikovanou anketu nelze najít.",
			'poll:notdeleted' => "Omlouváme se; tuto anketu nelze smazat.", 
			'polls:nonefound' => "Žádné ankety od %s nebyly nalezeny",
			'poll:group' => "Ankety skupiny",
            		'poll:add'=>"Přidat ankety",
'responses'=>"odpovědi"
);

					
	add_translation("en",$english);

?>
