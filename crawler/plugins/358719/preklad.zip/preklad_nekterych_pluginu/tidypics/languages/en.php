<?php

	$english = array(
		// hack for core bug
			'untitled' => "nez názvu",

		// Menu items and titles

			'image' => "Obrázek",
			'images' => "Obrázky",
			'caption' => "Titulek",
			'photos' => "Fotky",
			'images:upload' => "Nahrát Obrázky",
			'images:multiupload' => "Nástroj pro hromadné ukládání",
			'images:multiupload:todo' => "Zavolte jeden nebo víc souborů k uložení.",
			'album' => "Fotoalbum",
			'albums' => "Fotoalba",
			'album:slideshow' => "Spusť prohlížení",
			'album:yours' => "Vaše fotoalba",
			'album:yours:friends' => "Fotoalba vašich přátel",
			'album:user' => "fotoalba od %s",
			'album:friends' => "fotoalba od  přátel %s",
			'album:all' => "Fotoalba z celé sítě",
			'album:group' => "Fotoalba skupin",
			'item:object:image' => "Fotky",
			'item:object:album' => "Alba",
			'tidypics:uploading:images' => "Čekejte prosím. Ukládam obrázky.",
			'tidypics:enablephotos' => 'Povolit skupinové fotoalba',
			'tidypics:editprops' => 'Upravit nastavení obrázku',
			'tidypics:mostcommented' => 'Nejvíce komentované obrázky',
			'tidypics:mostcommentedthismonth' => 'Tento měsíc nejkomentovanější',
			'tidypics:mostcommentedtoday' => 'Dnes nejvíce komentované',
			'tidypics:mostviewed' => 'Nejzobrazovanější obrázky',
			'tidypics:mostvieweddashboard' => 'Nejzobrazovanější nástěnka',
			'tidypics:mostviewedthisyear' => 'Tento rok nejzobrazovanější',
			'tidypics:mostviewedthismonth' => 'Tento měsíc nejzobrazovanější',
			'tidypics:mostviewedlastmonth' => 'Poslední měsíc nejzobrazovanější',
			'tidypics:mostviewedtoday' => 'Dnes nejvíce zobrazované',
			'tidypics:recentlyviewed' => 'Nedávno prohlížené obrázky',
			'tidypics:recentlycommented' => 'Nedávno komentované obrázky',
			'tidypics:mostrecent' => 'Nejnovější obrázky',
			'tidypics:yourmostviewed' => 'Vaše nejprohlíženější',
			'tidypics:yourmostrecent' => 'Vaše nejnovější',
			'tidypics:friendmostviewed' => "nevíce prohlížené od %s",
			'tidypics:friendmostrecent' => "nejnovější od %s",
			'tidypics:highestrated' => "Nejvíce hodnocené obrázky",
			'tidypics:views' => "Počet zobrazení: %s",
			'tidypics:viewsbyowner' => "od %s uživatel (vy nejste započítan(a))",
			'tidypics:viewsbyothers' => "(%s od vás)",
			'tidypics:administration' => 'Administrace Tidypics',
			'tidypics:stats' => 'Statistiky',
			'flickr:setup' => 'Nastavení Flickr',
			'flickr:usernamesetup' => 'Prosím, vložte vaše uživatelské jméno z Flickr:',
			'flickr:selectalbum' => 'Zvolte album ze, kterého chcete importovat fotky',
			'flickr:albumdesc' => 'Album určné pro import fotek:',
			'flickr:importmanager' => 'Manažer Importu',
			'flickr:desc' => 'Vlote sadu fotografijí, kteru chcete importovat na tuto síť.<br />Kopie těchto fotek budou uloženy na této síti, kde se je budete moct prohlížet a komentovat.',
			'flickr:intro' => 'Integrace Flickr vám umožní importovat fotky z vašeho flickr účtu do této Elgg sítě. Vložením vašeho uživatelského jména a zvolením alba, které chcete importovat, začne proces importování. <br />Jakmile jsi uložil uživatelské jméno a zvolil akbum, klikni na odkaz' . elgg_echo( 'flickr:menuimport' ) . ' ,aby jste mohl(a) zvolit, kterou sadu fotek chcete z Flickr importovat.',
			'flickr:menusetup' => 'Nastavení Flickr',
			'flickr:menuimport' => 'Importuj fotky z Flickr',

		//settings
			'tidypics:settings' => 'Nastavení',
			'tidypics:admin:instructions' => 'Toto je nastavení jádra Tidypics.',
			'tidypics:settings:image_lib' => "Knihovna obrázků",
			'tidypics:settings:thumbnail' => "Vytvorit náhledy",
			'tidypics:settings:help' => "Nápověda",
			'tidypics:settings:download_link' => "Zobrazit odkaz ke stáhnutí",
			'tidypics:settings:tagging' => "Povolit označování obrázků",
			'tidypics:settings:photo_ratings' => "Povolit hodnocení fotek (vyzaduje rate plugin od Miguel Montes)",
			'tidypics:settings:exif' => "Zobrazit EXIF data",
			'tidypics:settings:view_count' => "Zobrazit počítadlo",
			'tidypics:settings:grp_perm_override' => "Povolit členům skupin plný přístup do fotoalb",
			'tidypics:settings:maxfilesize' => "Maximální velikost odesílaných souborů dohromady 30 MB, maximální velikost jednotlivého souboru (MB): ",
			'tidypics:settings:quota' => "Limit pro Uživatele/Skupinu (v MB) - 0 znamená bez limitu",
			'tidypics:settings:watermark' => "Nastave text, který se objeví na vodotisku - ješte není určeno pro ostrý provoz",
			'tidypics:settings:im_path' => "Nastavte cestu pro příkazy ImageMagick (zakončenou lomítkem)",
			'tidypics:settings:img_river_view' => "Počet záznamů v produ událostí pro každou várku uložených obrázků",
			'tidypics:settings:album_river_view' => "Zobrazí obal fotoalba nebo nastaví obrázky pro nové fotoalbum",
			'tidypics:settings:largesize' => "Primární velikost obrázku",
			'tidypics:settings:smallsize' => "Velikost obrázku ve fotoalbu",
			'tidypics:settings:thumbsize' => "Velikost náhledu obrázku",
			'tidypics:settings:im_id' => "ID Obrázku",
	
		//actions

			'album:create' => "Vytvořit nové fotoalbum",
			'album:add' => "Přidat Fotoalbum",
			'album:addpix' => "Přidat fotky do fotoalba",
			'album:edit' => "Upravit fotoalbum",
			'album:delete' => "Smazat fotoalbum",

			'image:edit' => "Upravit obrázek",
			'image:delete' => "Smazat obrázek",
			'image:download' => "Stáhnout obrázek",

		//forms

			'album:title' => "Nadpis",
			'album:desc' => "Popis",
			'album:tags' => "Označení(bez diakritiky(háčy,čárky,..))",
			'album:cover' => "Vyvorit obálku fotoalba?",
			'tidypics:quota' => "Limit:",

		//views

			'image:total' => "Obrázky ve fotoalbu:",
			'image:by' => "Obrázek přidán od",
			'album:by' => "Fotoalbum vytvořeno",
			'album:created:on' => "Vytvořeno",
			'image:none' => "Žádné obrázky ještě nebyly vytvořeny.",
			'image:back' => "Předchozí",
			'image:next' => "Další",

		// tagging
			'tidypics:taginstruct' => 'Zvolte oblast, kterou chcete označit',
			'tidypics:deltag_title' => 'Zvolte, která označení chcete smazat',
			'tidypics:finish_tagging' => 'Přerušit označování',
			'tidypics:tagthisphoto' => 'Označit tuto fotku',
			'tidypics:deletetag' => 'Smazat označení fotky',
			'tidypics:actiontag' => 'Označení',
			'tidypics:actiondelete' => 'Smazat',
			'tidypics:actioncancel' => 'Zrušit',
			'tidypics:inthisphoto' => 'Na této fotce',
			'tidypics:usertag' => "Fotky oznčené uživatelem %s",
			'tidypics:phototagging:success' => 'Fotka byla úspěšně označena',
			'tidypics:phototagging:error' => 'Během označování nastala neočekávaná chyba',
			'tidypics:deletetag:success' => 'Vybraná označení byla smazána',
			
			'tidypics:tag:subject' => "Byl jste označen na fotce",
			'tidypics:tag:body' => "Byl jste označen na fotce %s od %s.			
			
Fotku můžete vidět zde: %s",


		//rss
			'tidypics:posted' => 'uložené fotky:',

		//widgets

			'tidypics:widget:albums' => "Fotoalba",
			'tidypics:widget:album_descr' => "Zobrazí vaše fotoalba",
			'tidypics:widget:num_albums' => "Počet zobrazených fotoalb",
			'tidypics:widget:latest' => "Nejnovější fotky",
			'tidypics:widget:latest_descr' => "Zobrazí nejnovější obrázky",
			'tidypics:widget:num_latest' => "Počet zobrazených obrázků",
			'album:more' => "Zobrazit všechny fotoalba",

		//  river

			//images
			'image:river:created' => "%s přidal(a) fotku %s do fotoalba %s",
			'image:river:item' => "fotka",
			'image:river:annotate' => "komentář k fotce",
			'image:river:tagged' => "byl(a) označen na fotce",

			//albums
			'album:river:created' => "%s vytvořil nové fotoalbum",
			'album:river:group' => "ve skupině",
			'album:river:item' => "fotoalbum",
			'album:river:annotate' => "komentář k fotoalbu",

		// notifications
			'tidypics:newalbum' => 'Nové fotoalbum',


		//  Status messages

			'tidypics:upl_success' => "Vaše obrázky byly úspěšně uloženy.",
			'image:saved' => "Váš obrázek byl úspěšně uložen.",
			'images:saved' => "Všechny obrázky byly úspěsně uloženy.",
			'image:deleted' => "Vás obrázek by úspěšně smazán.",
			'image:delete:confirm' => "Jste si jistý, že chcete smazat tento obrázek?",

			'images:edited' => "Vaše obrázky byly úspěšně aktualizovány.",
			'album:edited' => "Vaše album bylo úspěšně aktualizováno.",
			'album:saved' => "Vaše album bylo úspěšně uložen.",
			'album:deleted' => "Vaše album bylo úspěšně smazáno.",
			'album:delete:confirm' => "Jste si jistý, že chcete smazat toto album?",
			'album:created' => "Nové album bylo vytvořeno.",
			'tidypics:settings:save:ok' => 'Nastavení Tidypics bylo úspěšně uloženo',

			'tidypics:upgrade:success' => 'Aktualizace Tidypics proběhla úspěšně',

			'flickr:enterusername' => 'Musíte vložit uživatelské jméno',
			'flickr:savedusername' => 'Uživateské jméno %s bylo úspěšne uloženo',
			'flickr:saveduserid' => 'Uživatlská ID od %s byla úspěšne uložena',
			'flickr:savedalbum' => 'Album uloženo - %s',

		//Error messages

			'tidypics:partialuploadfailure' => "Během ukládání těchto obrázků nastaly chyby (%s z %s obrázků).",
			'tidypics:completeuploadfailure' => "Ukládání obrázku selhalo.",
			'tidypics:exceedpostlimit' => "Příliš mnoho velikých orázků - zkuste jich ukládat méně nebo použijte menší obrázky.",
			'tidypics:noimages' => "Žádné obrázky nebyly vybrány.",
			'tidypics:image_mem' => "Obrázek je příliš veliký - příliš mnoho pixelů",
			'tidypics:image_pixels' => "Obrázek má příliš mnoho pixeků",
			'tidypics:unk_error' => "Neznámá chyba při ukládání",
			'tidypics:save_error' => "Při ukládání obrázku nastala neznáma chyba",
			'tidypics:not_image' => "Toto není podporovaný typ obrázku",
			'image:deletefailed' => "Obrázek nelze smazat",
			'image:downloadfailed' => "Omlouváme se; tento obrázek není dostupný.",
			'tidypics:nosettings' => "Administrátor této sítě nenastavil fotoalbum.",
			'tidypics:exceed_quota' => "Překročili jste limit nastavený administratorem",
			'images:notedited' => "Některé obrázky nebyly aktualizovany",

			'album:none' => "Žádná alba ještě nebyla vytvořena.",
			'album:uploadfailed' => "Omlouváme se; vaše album nelze uložit.",
			'album:deletefailed' => "Vaše alba nelze smazat.",
			'album:blank' => "Prosím, vyplňte nadpis a popis pro toto album.",

			'tidypics:upgrade:failed' => "Aktualizace Tidypics selhala",
			
			'flickr:errorusername' => 'Uživatelské jméno %s nebylo na Flickr nalezeno',
			'flickr:errorusername2' => 'Musíte vložit uživatelské jméno',
			'flickr:errorimageimport' => 'Tento obrázek už byl importován',
			'flickr:errornoalbum' => "Nebyl zvoleno žádné album. Prosím zvolte a uložte album: %s" 
			
	);

	add_translation("en",$english);
?>