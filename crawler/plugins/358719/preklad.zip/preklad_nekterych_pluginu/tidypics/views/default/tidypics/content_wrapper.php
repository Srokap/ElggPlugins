<?php
	echo elgg_view_title($vars['title']);
?>
<div class="contentWrapper">
<div class="clearfloat"></div>
<?php
	echo $vars['content'];
?>
<div class="clearfloat"></div>
</div>