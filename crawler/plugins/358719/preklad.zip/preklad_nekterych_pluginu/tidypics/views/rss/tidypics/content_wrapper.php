<?php
echo $vars['content'];
