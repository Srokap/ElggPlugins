<p>
<?php echo elgg_echo('gmap:modify'); ?>
<?php echo elgg_view('input/text', array('internalname'=>'params[api_key]',
                                         'value'=>$vars['entity']->api_key));
?>
</p>