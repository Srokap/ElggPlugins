/* CSS extender for google-map */ 
.gmapped { display:none; }
