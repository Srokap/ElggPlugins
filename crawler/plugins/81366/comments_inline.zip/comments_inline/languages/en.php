<?php
	$english = array(
	
		'comment_inline:writecomment' => 'Write a comment',
			
	);
					
	add_translation("en",$english);

?>