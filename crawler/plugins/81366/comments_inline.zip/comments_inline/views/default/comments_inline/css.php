<?php

?>

div.contentWrapper p {margin:0px;}
div.contentWrapper p.longtext_editarea {float:right; overflow:hidden; width:90%; }
div.contentWrapper textarea.input-textarea {height:42px; font-size:0.9em; color:gray; font-style:italic;} 
div.contentWrapper p.longtext_editarea label {display:block; margin-top:-20px; }
div.contentWrapper div.comment_inline div.usericon {width:40px; float:left; padding:8px; background:#F0F0EE; -webkit-border-radius: 5px; -moz-border-radius: 5px;}
div.contentWrapper input[type="submit"] {float:right;}
div.no_mce input[type="submit"] {display:none;} 