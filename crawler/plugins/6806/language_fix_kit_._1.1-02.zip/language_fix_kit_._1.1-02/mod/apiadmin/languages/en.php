<?php
	/**
	 * API Admin language pack.
	 * 
	 * @package ElggAPIAdmin
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'apiadmin' => "API Administration",
			'apiadmin:generate' => "Generate a new keypair",
			'apiadmin:generated' => "API Key successfully generated",
			'apiadmin:generationfail' => "There was a problem generating the new keypair",
			'apiadmin:keynotrevoked' => "API Key could not be revoked",
			'apiadmin:keyrevoked' => "API Key revoked",
			'apiadmin:noreference' => "You must provide a reference for your new key.",
			'apiadmin:revoke' => "Revoke key",
			'apiadmin:yourref' => "Your reference",
			
			'item:object:api_key' => "API Keys",
			
	);
	add_translation('en', $english);
	
?>