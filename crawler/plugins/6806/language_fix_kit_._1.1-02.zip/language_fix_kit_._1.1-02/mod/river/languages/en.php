<?php
	/**
	 * Elgg river plugin language pack
	 * 
	 * @package ElggReportedContent
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */
	 
	$english = array(
	
		/**
		 * Manifest
		 */
		
			'river:widget:description' => "Show your latest activity.",
			'river:widget:description:friends' => "Show what your friends are up to.",
			'river:widget:label:displaynum' => "Number of entries to display:",
			'river:widget:noactivity' => 'We could not find any activity.',
			'river:widget:title' => "Activity",
			'river:widget:title:friends' => "Friends' activity",
		
	);
	add_translation('en', $english);

?>