<?php
	/**
	 * Elgg groups plugin language pack
	 * 
	 * @package ElggGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$english = array(
	
		/**
		 * Menu items and titles
		 */
			
			'groups' => "Groups",
			'groups:access' => "Access permissions",
			'groups:all' => "All site groups",
			'groups:briefdescription' => "Brief description",
			'groups:cantedit' => "You can not edit this group",
			'groups:description' => "Description",
			'groups:edit' => "Edit group",
			'groups:group' => "Group",
			'groups:icon' => "Group icon (leave blank to leave unchanged)",
			'groups:interests' => "Interests",
			'groups:invite' => "Invite friends",
			'groups:inviteto' => "Invite friends to '%s'",
			'groups:join' => "Join group",
			'groups:joinrequest' => "Request membership",
			'groups:leave' => "Leave group",
			'groups:members' => "Group members",
			'groups:membership' => "Membership",
			'groups:name' => "Group name",
			'groups:new' => "Create a new group",
			'groups:noaccess' => "No access to group",
			'groups:nofriends' => "You have no friends left who have not been invited to this group.",
			'groups:owned' => "Groups you own",
			'groups:owner' => "Owner",
			'groups:saved' => "Group saved",
			'groups:user' => "%s's groups",
			'groups:username' => "Group short name (displayed in URLs, alphanumeric characters only)",
			'groups:website' => "Website",
			'groups:widget:membership' => "Group membership",
			'groups:widget:num_display' => "Number of groups to display",
			'groups:widgets:description' => "Display the groups you are a member of on your profile",
			'groups:yours' => "Your groups",
			
			'item:object:groupforumtopic' => "Forum topics",
	
		/**
		 * Group forum strings
		 */
			
			'groups:addedtogroup' => "Successfully added the user to the group",
			'groups:addtopic' => "Add a topic",
			'groups:alldiscussion' => "Latest discussion",
			'groups:alreadymember' => "You are already a member of this group!",
			'groups:cantjoin' => "Can not join group",
			'groups:cantleave' => "Could not leave group",
			'groups:edittopic' => "Edit topic",
			'groups:forum' => "Group forum",
			'groups:forumlatest' => "Forum latest",
			'groups:forumtopic:edited' => "Forum topic successfully edited.",
			'groups:joined' => "Successfully joined group!",
			'groups:joinrequestmade' => "Request to join group successfully made",
			'groups:joinrequestnotmade' => "Join request could not be made",
			'groups:lastperson' => "Last person",
			'groups:latestdiscussion' => "Latest discussion",
			'groups:left' => "Successfully left group",
			'groups:notitle' => "Groups must have a title",
			'groups:notowner' => "Sorry, you are not the owner of this group.",
			'groups:nowidgets' => "No widgets have been defined for this group.",
			'groups:posts' => "Posts",
			'groups:privategroup' => "This group is private, requesting membership.",
			'groups:reply' => "Post a comment",
			'groups:river:member' => "is now a member of",
			'groups:topic' => "Topic",
			'groups:topicclosed' => "Closed",
			'groups:topiccloseddesc' => "This topic has now been closed and is not accepting new comments.",
			'groups:topicisclosed' => "This topic is closed.",
			'groups:topicmessage' => "Topic message",
			'groups:topicopen' => "Open",
			'groups:topicreplies' => "Replies",
			'groups:topicresolved' => "Resolved",
			'groups:topicstatus' => "Topic status",
			'groups:topicsticky' => "Sticky",
			'groups:userinvited' => "User has been invited.",
			'groups:usernotinvited' => "User could not be invited.",
			'groups:when' => "When",
			'groups:widgets:entities:description' => "List the objects saved in this group",
			'groups:widgets:entities:label:displaynum' => "List the objects of a group.",
			'groups:widgets:entities:label:pleaseedit' => "Please configure this widget.",
			'groups:widgets:entities:title' => "Objects in group",
			'groups:widgets:members:description' => "List the members of a group.",
			'groups:widgets:members:label:displaynum' => "List the members of a group.",
			'groups:widgets:members:label:pleaseedit' => "Please configure this widget.",
			'groups:widgets:members:title' => "Group members",
			
			'groupspost:success' => "Your comment was succesfully posted",
			
			'grouptopic:created' => "Your topic was created.",
			'grouptopic:deleted' => "The topic has been deleted.",
			'grouptopic:error' => "Your group topic could not be created. Please try again or contact a system administrator.",
			'grouptopic:notcreated' => "No topics have been created.",
			'grouptopic:notdeleted' => "No topics have been deleted.",
		
		/**
		 * Groups invitation
		 */

			'groups:invite:subject' => "%s you have been invited to join %s!",
			'groups:invite:body' => "
Hi %s,

You have been invited to join the '%s' group, click below to confirm:

%s",

			'groups:welcome:subject' => "Welcome to the %s group!",
			'groups:welcome:body' => "
Hi %s!
		
You are now a member of the '%s' group! Click below to begin posting!

%s",
	
			'groups:request:subject' => "%s has requested to join %s",
			'groups:request:body' => "
Hi %s,

%s has requested to join the '%s' group, click below to view their profile:

%s

or click below to confirm request:

%s",
	
	);
	add_translation('en', $english);
	
?>