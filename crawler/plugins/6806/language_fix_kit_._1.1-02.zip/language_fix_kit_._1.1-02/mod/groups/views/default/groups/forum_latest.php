<?php
	/**
	 * Elgg groups plugin latest forum
	 * 
	 * @package ElggGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */
	 
?>
<div id="latest_discussion_widget">
<h2><?php echo elgg_echo('groups:latestdiscussion'); ?></h2>
<?php
	
    $forum = get_entities_from_annotations("object", "groupforumtopic", "group_topic_post", "", 0, $vars['entity']->guid, 4, 0, "asc", false);
    if($forum) {
    
        foreach($forum as $f){
        	    
            $count_annotations = $f->countAnnotations("group_topic_post");
                
?>
<div class="forum_latest">
<div class="topic_owner_icon"><?php echo elgg_view('profile/icon',array('entity' => $f->getOwnerEntity(), 'size' => 'tiny')); ?></div>
<div class="topic_title"><p><a href="<?php echo "{$vars['url']}mod/groups/topicposts.php?topic={$f->guid}&group_guid={$vars['entity']->guid}"; ?>>"<?php echo $f->title; ?></a></p>
<p class=\"topic_replies\"><small><?php echo elgg_echo('groups:topicreplies') . ": " . $count_annotations ?></small></p></div>
</div>
<?php
    	        
        }
    } else {
        
        echo elgg_echo("grouptopic:notcreated");
        
    }
    
?>
<br class="clearfloat" />
</div>