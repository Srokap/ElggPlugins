<?php
	/**
	 * Elgg log rotator language pack.
	 * 
	 * @package ElggLogRotate
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$english = array(
	
		'logrotate:lognotrotated' => "Error rotating log\n",
		'logrotate:logrotated' => "Log rotated\n",
		'logrotate:monthly' => "Once a month",
		'logrotate:period' => "How often should the system log be archived?",
		'logrotate:weekly' => "Once a week",
		'logrotate:yearly' => "Once a year",

	);
	add_translation('en', $english);
	
?>