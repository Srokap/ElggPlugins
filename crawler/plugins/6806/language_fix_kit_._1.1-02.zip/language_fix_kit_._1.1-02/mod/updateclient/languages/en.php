<?php
	/**
	 * Update client language pack.
	 * 
	 * @package ElggUpdateClient
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */	

	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'updateclient:days' => "days",
			'updateclient:label:core' => "Core",
			'updateclient:label:plugins' => "Plugins",
			'updateclient:message:title' => "New version of Elgg released!",
			'updateclient:message:body' => "
A new version of Elgg (%s %s) codenamed '%s' has been released!
		
Go here to download: %s

Or scroll down and read the release notes:

%s",
	
			'updateclient:settings:days' => "Check for updates every",
			'updateclient:settings:server' => "Update server",

	);
	add_translation('en', $english);
	
?>