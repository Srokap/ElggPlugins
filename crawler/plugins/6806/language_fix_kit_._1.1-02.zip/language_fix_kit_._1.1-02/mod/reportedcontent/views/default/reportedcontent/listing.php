<?php
	/**
	 * Elgg report content plugin listing
	 * 
	 * @package ElggReportContent
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider <info@elgg.com>
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.org/
	 */
	 
    if($vars['entity']){
        
        foreach($vars['entity'] as $report){
            
            //get the user making the report
            $user = get_user($report->owner_guid)->name;
            $user_url = get_user($report->owner_guid)->getURL();
            
            //find out if the report is current or archive
	        if ($report->state == 'archived'){
		        $reportedcontent_background = 'archived_report';
	        } else {
    	        $reportedcontent_background = 'active_report';
	        }
		   
?>
<div class="reportedcontent_content <?php echo $reportedcontent_background; ?>">
<p class="reportedcontent_detail">
<?php

            if ($report->state != 'archived') {
            
?>            
<a class="archive_report_button" href="<?php echo $vars['url']; ?>action/reportedcontent/archive?item=<?php echo $report->guid; ?>"><?php echo elgg_echo('reportedcontent:archive'); ?></a>

<?php

            }
            
?>
<a class="delete_report_button" href="<?php echo $vars['url']; ?>action/reportedcontent/delete?item=<?php echo $report->guid; ?>" onclick="return confirm('<?php echo elgg_echo('reportedcontent:areyousure'); ?>')"><?php echo elgg_echo('reportedcontent:delete'); ?></a></p>
<p class="reportedcontent_detail"><b><?php echo elgg_echo('reportedcontent:by'); ?>: </b><a href="<?php echo $user_url; ?>"><?php echo $user; ?></a>, <?php echo friendly_time($report->time_created) ?></p>
<p class="reportedcontent_detail"><b><?php echo elgg_echo('reportedcontent:objecttitle'); ?>: </b><?php echo $report->title; ?></p>
<p><a class="manifest_details"><?php echo elgg_echo('moreinfo'); ?></a></p>
<div class="manifest_file">
<p class="reportedcontent_detail"><b><?php echo elgg_echo('reportedcontent:objecturl'); ?>: </b><a href="<?php echo $report->address; ?>"><?php echo elgg_echo('reportedcontent:visit'); ?></a></p>
<p class="reportedcontent_detail"><b><?php echo elgg_echo('reportedcontent:reason'); ?>: </b><?php echo $report->description; ?></p>
</div>
</div>

<?php
            
        }
    }
    
?>