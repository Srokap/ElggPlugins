<?php
	/**
	 * Language pack.
	 * 
	 * @package ElggCore
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$english = array(

		/**
		 * Sites
		 */
	
			'item:site' => "Sites",
	
		/**
		 * Sessions
		 */
			
			'login' => "Log in",
			'loginerror' => "We couldn't log you in. This may be because you haven't validated your account yet, or the details you supplied were incorrect. Make sure your details are correct and please try again.",
			'loginok' => "You have been logged in.",
			'logout' => "Log out",
			'logouterror' => "We couldn't log you out. Please try again.",
			'logoutok' => "You have been logged out.",
	
		/**
		 * Errors
		 */
		 
			'actionloggedout' => "Sorry, you cannot perform this action while logged out.",
			'actionundefined' => "The requested action (%s) was not defined in the system.",
			
			'APIException:AlgorithmNotSupported' => "Algorithm '%s' is not supported or has been disabled.",
			'APIException:ApiResultUnknown' => "API Result is of an unknown type, this should never happen.", 
			'APIException:FunctionNoReturn' => "%s(%s) returned no value.",
			'APIException:FunctionParseError' => "%s(%s) has a parsing error.",
			'APIException:InvalidParameter' => "Invalid parameter found for '%s' in method '%s'.",
			'APIException:MethodCallNotImplemented' => "Method call '%s' has not been implemented.",
			'APIException:MissingAPIKey' => "Missing X-Elgg-apikey HTTP header",
			'APIException:MissingContentType' => "Missing content type for post data",
			'APIException:MissingHmac' => "Missing X-Elgg-hmac header",
			'APIException:MissingHmacAlgo' => "Missing X-Elgg-hmac-algo header",
			'APIException:MissingParameterInMethod' => "Missing parameter %s in method %s",
			'APIException:MissingPOSTAlgo' => "Missing X-Elgg-posthash_algo header",
			'APIException:MissingPOSTHash' => "Missing X-Elgg-posthash header",
			'APIException:MissingTime' => "Missing X-Elgg-time header",
			'APIException:NoQueryString' => "No data on the query string",
			'APIException:NotGetOrPost' => "Request method must be GET or POST",
			'APIException:ParameterNotArray' => "%s does not appear to be an array.",
			'APIException:TemporalDrift' => "X-Elgg-time is too far in the past or future. Epoch fail.",
			'APIException:UnrecognisedTypeCast' => "Unrecognised type in cast %s for variable '%s' in method '%s'",
			
			'CallException:InvalidCallMethod' => "%s must be called using '%s'",
			'CallException:NotRPCCall' => "Call does not appear to be a valid XML-RPC call",
			
			'ClassException:ClassnameNotClass' => "%s is not a %s.",
			
			'ClassNotFoundException:MissingClass' => "Class '%s' was not found, missing plugin?",
			'ClassNotFoundException:NotFoundNotSavedWithFile' => "Filestore not found or class not saved with file!",
			
			'ConfigurationException:BadDatabaseVersion' => "The database backend you have installed doesn't meet the basic requirements to run Elgg. Please consult your documentation.",
			'ConfigurationException:BadPHPVersion' => "You need at least PHP version 5.2 to run Elgg.",
			'ConfigurationException:CacheDirNotSet' => "Cache directory 'cache_path' not set.",
			'ConfigurationException:NoCachePath' => "Cache path set to nothing!",
			'ConfigurationException:NoSiteID' => "No site ID has been specified.",
			
			'ConfigurationWarning:phpversion' => "Elgg requires at least PHP version 5.2, you can install it on 5.1.6 but some features may not work. Use at your own risk.",
			
			'CronException:unknownperiod' => "%s is not a recognised period.",
			
			'DatabaseException:DBSetupIssues' => "There were a number of issues: ",
			'DatabaseException:NoACL' => "No access control was provided on query",
			'DatabaseException:NoConnect' => "Elgg couldn't select the database '%s', please check that the database is created and you have access to it.",
			'DatabaseException:NoTablesSpecified' => "No tables specified for query.",
			'DatabaseException:ScriptNotFound' => "Elgg couldn't find the requested database script at %s.",
			'DatabaseException:SelectFieldsMissing' => "Fields missing on a select style query",
			'DatabaseException:UnspecifiedQueryType' => "Unrecognised or unspecified query type.",
			'DatabaseException:WhereSetNonQuery' => "Where set contains non WhereQueryComponent",
			'DatabaseException:WrongCredentials' => "Elgg couldn't connect to the database using the given credentials %s@%s (pw: %s).",
			
			'exception:title' => "Welcome to Elgg.",
			
			'ExportException:NoSuchEntity' => "No such entity GUID:%d", 
			
			'ImportException:GUIDNotFound' => "Entity '%d' could not be found.",
			'ImportException:ImportFailed' => "Could not import element %d",
			'ImportException:NoGUID' => "New entity created but has no GUID, this should not happen.",
			'ImportException:NoODDElements' => "No OpenDD elements found in import data, import failed.",
			'ImportException:NotAllImported' => "Not all elements were imported.",
			'ImportException:ProblemSaving' => "There was a problem saving %s",
			'ImportException:ProblemUpdatingMeta' => "There was a problem updating '%s' on entity '%d'",
			
			'InstallationException:CantCreateSite' => "Unable to create a default ElggSite with credentials Name:%s, Url: %s",
			'InstallationException:DatarootBlank' => "You have not specified a data directory.",
			'InstallationException:DatarootNotWritable' => "Your data directory %s is not writable.",
			'InstallationException:DatarootUnderPath' => "Your data directory %s must be outside of your install path.",
			'InstallationException:TypeNotSupported' => "Type %s is not supported. This indicates an error in your installation, most likely caused by an incomplete upgrade.",
			
			'InvalidClassException:NotValidElggStar' => "GUID:%d is not a valid %s",
			
			'InvalidParameterException:CanNotExportType' => "Sorry, I don't know how to export '%s'",
			'InvalidParameterException:DoesNotBelong' => "Does not belong to entity.",
			'InvalidParameterException:DoesNotBelongOrRefer' => "Does not belong to entity or refer to entity.",
			'InvalidParameterException:EntityTypeNotSet' => "Entity type must be set.",
			'InvalidParameterException:GUIDNotForExport' => "GUID has not been specified during export, this should never happen.",
			'InvalidParameterException:GUIDNotFound' => "GUID:%s could not be found, or you can not access it.",
			'InvalidParameterException:IdNotExistForGUID' => "Sorry, '%s' does not exist for guid:%d",
			'InvalidParameterException:MissingOwner' => "All files must have an owner!",
			'InvalidParameterException:MissingParameter' => "Missing parameter, you need to provide a GUID.",
			'InvalidParameterException:NoDataFound' => "Could not find any data.",
			'InvalidParameterException:NoEntityFound' => "No entity found, it either doesn't exist or you don't have access to it.",
			'InvalidParameterException:NonArrayReturnValue' => "Entity serialisation function passed a non-array returnvalue parameter",
			'InvalidParameterException:NonElggGroup' => "Passing a non-ElggGroup to an ElggGroup constructor!",
			'InvalidParameterException:NonElggObject' => "Passing a non-ElggObject to an ElggObject constructor!",
			'InvalidParameterException:NonElggSite' => "Passing a non-ElggSite to an ElggSite constructor!",
			'InvalidParameterException:NonElggUser' => "Passing a non-ElggUser to an ElggUser constructor!",
			'InvalidParameterException:UnexpectedODDClass' => "import() passed an unexpected ODD class",
			'InvalidParameterException:UnexpectedReturnFormat' => "Call to method '%s' returned an unexpected result.",
			'InvalidParameterException:UnrecognisedFileMode' => "Unrecognised file mode '%s'",
			'InvalidParameterException:UnrecognisedMethod' => "Unrecognised call method '%s'",
			'InvalidParameterException:UnrecognisedValue' => "Unrecognised value passed to constuctor.",
			
			'IOException:BaseEntitySaveFailed' => "Unable to save new object's base entity information!",
			'IOException:CouldNotMake' => "Could not make %s",
			'IOException:FailedToLoadGUID' => "Failed to load new %s from GUID:%d",
			'IOException:MissingFileName' => "You must specify a name before opening a file.",
			'IOException:NotDirectory' => "%s is not a directory.",
			'IOException:UnableToSaveNew' => "Unable to save new %s",
			
			'memcache:noaddserver' => "Multiple server support disabled, you may need to upgrade your PECL memcache library",
			'memcache:notinstalled' => "PHP memcache module not installed, you must install php5-memcache",
			'memcache:noservers' => "No memcache servers defined, please populate the {$CONFIG->memcache_servers} variable",
			'memcache:versiontoolow' => "Memcache needs at least version %s to run, you are running %s",

			'notfound' => "The requested resource could not be found, or you do not have access to it.",

			'NotificationException:ErrorNotifyingGuid' => "There was an error while notifying %d",
			'NotificationException:MissingParameter' => "Missing a required parameter, '%s'",
			'NotificationException:NoEmailAddress' => "Could not get the email address for GUID:%d",
			'NotificationException:NoHandlerFound' => "No handler found for '%s' or it was not callable.",
			'NotificationException:NoNotificationMethod' => "No notification method specified.",
			
			'NotImplementedException:CallMethodNotImplemented' => "Call method '%s' is currently not supported.",
			'NotImplementedException:XMLRPCMethodNotImplemented' => "XML-RPC method call '%s' not implemented.",
			
			'PluginException:MisconfiguredPlugin' => "%s is a misconfigured plugin.",
			'PluginException:NoPluginName' => "The plugin name could not be found",
			
			'SecurityException:APIAccessDenied' => "Sorry, API access has been disabled by the administrator.",
			'SecurityException:authenticationfailed' => "User could not be authenticated",
			'SecurityException:AuthTokenExpired' => "Authentication token either missing, invalid or expired.",
			'SecurityException:Codeblock' => "Denied access to execute privileged code block",
			'SecurityException:deletedisablecurrentsite' => "You can not delete or disable the site you are currently viewing!",
			'SecurityException:DupePacket' => "Packet signature already seen.",
			'SecurityException:FunctionDenied' => "Access to privileged function '%s' is denied.",
			'SecurityException:InvalidAPIKey' => "Invalid or missing API Key.",
			'SecurityException:InvalidPostHash' => "POST data hash is invalid - Expected %s but got %s.",
			'SecurityException:NoAuthMethods' => "No authentication methods were found that could authenticate this API request.",

		/**
		 * API
		 */
		 
			'auth.gettoken' => "This API call lets a user log in, returning an authentication token which can be used in leu of a username and password for authenticating further calls.",
			'system.api.list' => "List all available API calls on the system.",
	
		/**
		 * User details
		 */

			'admin_option' => "Make this user an admin?",
			'email' => "Email address",
			'name' => "Display name",
			'password' => "Password",
			'passwordagain' => "Password (again for verification)",
			'username' => "Username",
	
		/**
		 * Access
		 */
	
			'access' => "Access",
			'ACCESS_LOGGED_IN' => "Logged in users",
			'ACCESS_PRIVATE' => "Private",
			'ACCESS_PUBLIC' => "Public",
			'LOGGED_IN' => "Logged in users",
			'PRIVATE' => "Private",
			'PUBLIC' => "Public",
	
		/**
		 * Dashboard and widgets
		 */
	
			'dashboard' => "Dashboard",
			'dashboard:configure' => "Edit page",
			'dashboard:nowidgets' => "Your dashboard is your gateway into the site. Click 'Edit page' to add widgets to keep track of content and your life within the system.",
			
			'item:object:widget' => "Widgets",
			
			'layout:customise' => "Customise layout",
			
			'widget' => "Widget",
			'widgets' => "Widgets",
			'widgets:add' => "Add widgets to your page",
			'widgets:add:description' => "
Choose the features you want to add to your page by dragging them from the <b>Widget gallery</b> on the right, to any of the three widget areas below, and position them where you would like them to appear.

To remove a widget drag it back to the <b>Widget gallery</b>.",

			'widgets:fixed' => "Fixed position",
			'widgets:gallery' => "Widget gallery",
			'widgets:leftcolumn' => "Left widgets",
			'widgets:middlecolumn' => "Middle widgets",
			'widgets:panel:save:failure' => "There was a problem saving your widgets. Please try again.",
			'widgets:panel:save:success' => "Your widgets were successfully saved.",
			'widgets:position:fixed' => "(Fixed position on page)",
			'widgets:profilebox' => "Profile box",
			'widgets:rightcolumn' => "Right widgets",
			'widgets:save:failure' => "We could not save your widget. Please try again.",
			'widgets:save:success' => "The widget was successfully saved.",
			
		/**
		 * Groups
		 */
	
			'item:group' => "Groups",
	
		/**
		 * Profile
		 */
	
			'item:user' => "Users",
			
			'profile' => "Profile",
			'profile:edit:default' => "Replace profile fields",
			
			'riveritem:single:user' => "a user",
			'riveritem:plural:user' => "some users",
			
			'user' => "User",

		/**
		 * Profile menu items and titles
		 */
	
			'profile:aboutme' => "About me", 
			'profile:briefdescription' => "Brief description",
			'profile:contactemail' => "Contact email",
			'profile:createicon' => "Create your avatar",
			'profile:createicon:header' => "Profile picture",
			'profile:createicon:instructions' => "Click and drag a square below to match how you want your picture cropped.  A preview of your cropped picture will appear in the box on the right.  When you are happy with the preview, click 'Create your avatar'. This cropped image will be used throughout the site as your avatar. ",
			'profile:currentavatar' => "Current avatar",
			'profile:defaultprofile:reset' => "Default system profile reset",
			'profile:description' => "About me",
			'profile:edit' => "Edit profile",
			'profile:editdefault:delete:fail' => "Removed default profile item field failed",
			'profile:editdefault:delete:success' => "Default profile item deleted!",
			'profile:editdefault:fail' => "Default profile could not be saved",
			'profile:editdefault:success' => "Item successfully added to default profile",
			'profile:editdetails' => "Edit details",
			'profile:editicon' => "Edit profile icon",
			'profile:icon' => "Profile picture",
			'profile:interests' => "Interests", 
			'profile:label' => "Profile label",
			'profile:location' => "Location",
			'profile:mobile' => "Mobile phone",
			'profile:phone' => "Telephone",
			'profile:profilepicturecroppingtool' => "Profile picture cropping tool",
			'profile:profilepictureinstructions' => "The profile picture is the image that's displayed on your profile page. <br /> You can change it as often as you'd like. (File formats accepted: GIF, JPG or PNG)",
			'profile:resetdefault' => "Reset default profile",
			'profile:river:iconupdate' => "%s updated their profile icon",
			'profile:river:update' => "%s updated their profile",
			'profile:skills' => "Skills",  
			'profile:type' => "Profile type",
			'profile:user' => "%s's profile",
			'profile:website' => "Website",
			'profile:yours' => "Your profile",
	
		/**
		 * Profile status messages
		 */
	
			'profile:icon:uploaded' => "Your profile picture was successfully uploaded.",
			'profile:saved' => "Your profile was successfully saved.",
	
		/**
		 * Profile error messages
		 */
	
			'profile:cantedit' => "Sorry; you do not have permission to edit this profile.",
			'profile:icon:notfound' => "Sorry; there was a problem uploading your profile picture.",
			'profile:noaccess' => "You do not have permission to edit this profile.",
			'profile:notfound' => "Sorry; we could not find the specified profile.",
	
		/**
		 * Friends
		 */
	
			'friend:add' => "Add friend",
			'friend:remove' => "Remove friend",
			
			'friends' => "Friends",
			'friends:add:failure' => "We couldn't add %s as a friend. Please try again.",
			'friends:add:successful' => "You have successfully added %s as a friend.",
			'friends:addfriends' => "Add friends",
			'friends:collectionadded' => "Your collection was successfuly created",
			'friends:collectiondeleted' => "Your collection has been deleted.",
			'friends:collectiondeletefailed' => "We were unable to delete the collection. Either you don't have permission, or some other problem has occurred.",
			'friends:collectionedit' => "Edit this collection",
			'friends:collectionfriends' => "Friends in collection",
			'friends:collectionname' => "Collection name",
			'friends:collections' => "Collections of friends",
			'friends:collections:add' => "New friends collection",
			'friends:collections:closeall' => "close all",
			'friends:collections:edit' => "Edit collection",
			'friends:collections:expandall' => "expand all",
			'friends:collections:members' => "Collection members",
			'friends:icon_size' => "Icon size",
			'friends:nocollectionname' => "You need to give your collection a name before it can be created.",
			'friends:nocollections' => "You do not yet have any collections.",
			'friends:none' => "This user hasn't added anyone as a friend yet.",
			'friends:none:found' => "No friends were found.",
			'friends:none:you' => "You haven't added anyone as a friend! Search for your interests to begin finding people to follow.",
			'friends:num_display' => "Number of friends to display",
			'friends:of' => "Friends of",
			'friends:of:none' => "Nobody has added this user as a friend yet.",
			'friends:of:none:you' => "Nobody has added you as a friend yet. Start adding content and fill in your profile to let people find you!",
			'friends:of:owned' => "People who have made %s a friend",
			'friends:owned' => "%s's friends",
			'friends:remove:failure' => "We couldn't remove %s from your friends. Please try again.",
			'friends:remove:successful' => "You have successfully removed %s from your friends.",
			'friends:river:add' => "%s add someone as a friend.",
			'friends:river:created' => "%s added the friends widget.",
			'friends:river:delete' => "%s removed their friends widget.",
			'friends:river:updated' => "%s updated their friends widget.",
			'friends:small' => "small",
			'friends:tiny' => "tiny",
			'friends:yours' => "Your friends",
	
		/**
		 * Feeds
		 */
	 
			'feed:odd' => "Syndicate OpenDD",
			'feed:rss' => "Subscribe to feed",
			
		/**
          * links
		 **/

			'link:text' => "view link",
			'link:view' => "view link",
	
		/**
		 * River
		 */
		 
			'river' => "River",			
			'river:relationship:friend' => "is now friends with",

		/**
		 * Plugins
		 */
		 
			'item:object:plugin' => "Plugin configuration settings",
			
			'plugins:settings:save:ok' => "Settings for the %s plugin were saved successfully.",
			'plugins:settings:save:fail' => "There was a problem saving settings for the %s plugin.",
			'plugins:usersettings:save:ok' => "User settings for the %s plugin were saved successfully.",
			'plugins:usersettings:save:fail' => "There was a problem saving  user settings for the %s plugin.",

		/**
		 * Notifications
		 */
		 
			'notifications:methods' => "Please specify which methods you want to permit.",
			'notifications:usersettings' => "Notification settings",
			'notifications:usersettings:save:ok' => "Your notification settings were successfully saved.",
			'notifications:usersettings:save:fail' => "There was a problem saving your notification settings.",

			'user.notification.get' => "Return the notification settings for a given user.",
			'user.notification.set' => "Set the notification settings for a given user.",
			
		/**
		 * Search
		 */
	
			'advancedsearchtitle' => "%s with results matching %s",
			'next' => "Next",
			'notfound' => "No results found.",
			'previous' => "Previous",
			'search' => "Search",
			'searchtitle' => "Search: %s",
			
			'tag:search:startblurb' => "Items with tags matching '%s':",
			
			'user:search:finishblurb' => "To view more, click here.",
			'user:search:startblurb' => "Users matching '%s':",
			'users:searchtitle' => "Searching for users: %s",
			
			'viewtype:change' => "Change listing type",
			'viewtype:gallery' => "Gallery",
			'viewtype:list' => "List view",
	
		/**
		 * Account
		 */
	
			'account' => "Account",
			'adduser' => "Add User",
			'adduser:bad' => "The new user could not be created.",
			'adduser:ok' => "You have successfully added a new user.",
			'register' => "Register",
			'registerbad' => "Your registration was unsuccessful. The username may already exist, your passwords might not match, or your username or password may be too short.",
			'registerdisabled' => "Registration has been disabled by the system administrator",
			'registerok' => "You have successfully registered for %s.",
			'settings' => "Settings",
			'tools' => "Tools",
			'tools:yours' => "Your tools",
			
			'registration:dupeemail' => "This email address has already been registered.",
			'registration:emailnotvalid' => "Sorry, the email address you entered is invalid on this system",
			'registration:invalidchars' => "Sorry, your username contains invalid characters.",
			'registration:notemail' => "The email address you provided does not appear to be a valid email address.",
			'registration:passwordnotvalid' => "Sorry, the password you entered is invalid on this system",
			'registration:passwordtooshort' => "The password must be a minimum of 6 characters long.",
			'registration:userexists' => "That username already exists",
			'registration:usernamenotvalid' => "Sorry, the username you entered is invalid on this system",
			'registration:usernametooshort' => "Your username must be a minimum of 4 characters long.",
			
			'user:language:fail' => "Your language settings could not be saved.",
			'user:language:label' => "Your language",
			'user:language:success' => "Your language settings have been updated.",
			'user:name:fail' => "Could not change your name on the system.",
			'user:name:label' => "Your name",
			'user:name:success' => "Successfully changed your name on the system.",
			'user:password:fail' => "Could not change your password on the system.",
			'user:password:fail:notsame' => "The two passwords are not the same!",
			'user:password:fail:tooshort' => "Password is too short!",
			'user:password:label' => "Your new password",
			'user:password:lost' => "Lost password",
			'user:password:resetreq:fail' => "Could not request a new password.",
			'user:password:resetreq:success' => "Successfully requested a new password, email sent",
			'user:password:success' => "Password changed",
			'user:password:text' => "To generate a new password, enter your username below. We will send the address of a unique verification page to you via email click on the link in the body of the message and a new password will be sent to you.",
			'user:password2:label' => "Your new password again",
			'user:persistent' => "Remember me",
			'user:set:language' => "Language settings",
			'user:set:name' => "Account name settings",
			'user:set:password' => "Account password",
			'user:username:notfound' => "Username %s not found.",
			
		/**
		 * Administration
		 */

			'admin' => "Administration",
			'admin:configuration:fail' => "Your settings could not be saved.",
			'admin:configuration:success' => "Your settings have been saved.",
			'admin:description' => "The admin panel allows you to control all aspects of the system, from user management to how plugins behave. Choose an option below to get started.",
			'admin:plugins' => "Tool Administration",
			'admin:plugins:description' => "This admin panel allows you to control and configure tools installed on your site.",
			'admin:plugins:disable:no' => "Plugin %s could not be disabled.",
			'admin:plugins:disable:yes' => "Plugin %s was disabled successfully.",
			'admin:plugins:enable:no' => "Plugin %s could not be enabled.",
			'admin:plugins:enable:yes' => "Plugin %s was enabled successfully.",
			'admin:plugins:label:author' => "Author",
			'admin:plugins:label:copyright' => "Copyright",
			'admin:plugins:label:licence' => "Licence",
			'admin:plugins:label:website' => "URL",
			'admin:plugins:opt:description' => "Configure the tools installed on the site. ",
			'admin:plugins:opt:linktext' => "Configure tools...",
			'admin:plugins:reorder:no' => "Plugin %s could not be reordered.",
			'admin:plugins:reorder:yes' => "Plugin %s was reordered successfully.",
			'admin:site' => "Site Administration",
			'admin:site:description' => "This admin panel allows you to control global settings for your site. Choose an option below to get started.",
			'admin:site:opt:description' => "Configure the site technical and non-technical settings. ",
			'admin:site:opt:linktext' => "Configure site...",
			'admin:statistics' => "Statistics",
			'admin:statistics:description' => "This is an overview of statistics on your site. If you need more detailed statistics, a professional administration feature is available.",
			'admin:statistics:label:basic' => "Basic site statistics",
			'admin:statistics:label:numentities' => "Entities on site",
			'admin:statistics:label:numonline' => "Number of users online",
			'admin:statistics:label:numusers' => "Number of users",
			'admin:statistics:label:onlineusers' => "Users online now",
			'admin:statistics:label:version' => "Elgg version",
			'admin:statistics:label:version:release' => "Release",
			'admin:statistics:label:version:version' => "Version",
			'admin:statistics:opt:description' => "View statistical information about users and objects on your site.",
			'admin:statistics:opt:linktext' => "View statistics...",
			'admin:user' => "User Administration",
			'admin:user:adduser:label' => "Click here to add a new user...",
			'admin:user:ban:no' => "Can not ban user",
			'admin:user:ban:yes' => "User banned.",
			'admin:user:delete:no' => "Can not delete user",
			'admin:user:delete:yes' => "User deleted",
			'admin:user:description' => "This admin panel allows you to control user settings for your site. Choose an option below to get started.",
			'admin:user:label:seachbutton' => "Search", 
			'admin:user:label:search' => "Find users:",
			'admin:user:makeadmin:no' => "We could not make this user an admin.",
			'admin:user:makeadmin:yes' => "User is now an admin.",
			'admin:user:opt:description' => "Configure users and account information. ",
			'admin:user:opt:linktext' => "Configure users...",
			'admin:user:resetpassword:no' => "Password could not be reset.",
			'admin:user:resetpassword:yes' => "Password reset, user notified.",
			'admin:user:unban:no' => "Can not unban user",
			'admin:user:unban:yes' => "User un-banned.",
		
		/**
		 * User settings
		 */
		 
			'usersettings:description' => "The user settings panel allows you to control all your personal settings, from user management to how plugins behave. Choose an option below to get started.",
			'usersettings:plugins' => "Tools",
			'usersettings:plugins:description' => "This panel allows you to control and configure the personal settings for the tools installed by your system administrator.",
			'usersettings:plugins:opt:description' => "Configure settings for your active tools.",
			'usersettings:plugins:opt:linktext' => "Configure your tools",
			'usersettings:statistics' => "Your statistics",
			'usersettings:statistics:label:email' => "Email",
			'usersettings:statistics:label:lastlogin' => "Last logged in",
			'usersettings:statistics:label:membersince' => "Member since",
			'usersettings:statistics:label:name' => "Full name",
			'usersettings:statistics:label:numentities' => "Your entities",
			'usersettings:statistics:opt:description' => "View statistical information about users and objects on your site.",
			'usersettings:statistics:opt:linktext' => "Account statistics",
			'usersettings:statistics:yourdetails' => "Your details",
			'usersettings:user' => "Your settings",
			'usersettings:user:opt:description' => "This allows you to control user settings.",
			'usersettings:user:opt:linktext' => "Change your settings",

		/**
		 * Generic action words
		 */
	
			'active' => "Active",
			'ban' => "Ban",
			'bottom' => "Bottom",
			'cancel' => "Cancel",
			'close' => "Close",
			'complete' => "Complete",
			'content' => "content",
			'content:latest' => "Latest activity",
			'content:latest:blurb' => "Alternatively, click here to view the latest content from across the site.",
			'delete' => "Delete",
			'disable' => "Disable",
			'down' => "Down",
			'edit' => "Edit",
			'enable' => "Enable",
			'invite' => "Invite",
			'learnmore' => "Click here to learn more.",
			'load' => "Load",
			'makeadmin' => "Make admin",
			'moreinfo' => "more info",
			'open' => "Open",
			'option:no' => "No",
			'option:yes' => "Yes",
			'reply' => "Reply",
			'request' => "Request",
			'resetpassword' => "Reset password",
			'save' => "Save",
			'saving' => "Saving ...",
			'top' => "Top",
			'total' => "Total",
			'unban' => "Unban",
			'unknown' => "Unknown",
			'up' => "Up",
			'update' => "Update",
			'upload' => "Upload",
	
		/**
		 * Generic data words
		 */
	
			'all' => "All",
			'annotations' => "Annotations",
			'by' => "by",
			'description' => "Description",
			'metadata' => "Metadata",
			'relationships' => "Relationships",
			'spotlight' => "Spotlight",
			'tags' => "Tags",
			'title' => "Title",
	
		/**
		 * Input / output strings
		 */

			'deleteconfirm' => "Are you sure you want to delete this item?",
			'fileexists' => "A file has already been uploaded. To replace it, select it below:",
			
	    /**
         * System messages
         **/

			'systemmessages:dismiss' => "click to dismiss",

		/**
		 * Import / export
		 */
		 
			'importfail' => "OpenDD import of data failed.",
			'importsuccess' => "Import of data was successful",
	
		/**
		 * Time
		 */
	
			'friendlytime:days' => "%s days ago",
			'friendlytime:days:singular' => "yesterday",
			'friendlytime:hours' => "%s hours ago",
			'friendlytime:hours:singular' => "an hour ago",
			'friendlytime:justnow' => "just now",
			'friendlytime:minutes' => "%s minutes ago",
			'friendlytime:minutes:singular' => "a minute ago",
	
		/**
		 * Installation and system settings
		 */
	
			'installation' => "Installation",
			'installation:configuration:success' => "Your initial configuration settings have been saved. Now register your initial user; this will be your first system administrator.",
			'installation:dataroot' => "The full path to the directory where uploaded files will be stored, followed by a trailing slash:",
			'installation:dataroot:warning' => "You must create this directory manually. It should sit in a different directory to your Elgg installation.",
			'installation:debug' => "Debug mode provides extra information which can be used to diagnose faults, however it can slow your system down so should only be used if you are having problems:",
			'installation:debug:label' => "Turn on debug mode",
			'installation:disableapi' => "The RESTful API is a flexible and extensible interface that enables applications to use certain Elgg features remotely.",
			'installation:disableapi:label' => "Enable the RESTful API",
			'installation:error:configuration' => "Once you've corrected any configuration issues, press reload to try again.",
			'installation:error:htaccess' => "
Elgg requires a file called .htaccess to be set in the root directory of its installation. We tried to create it for you, but Elgg doesn't have permission to write to that directory. 

Creating this is easy. Copy the contents of the textbox below into a text editor and save it as .htaccess",

			'installation:error:settings' => "
Elgg couldn't find its settings file. Most of Elgg's settings will be handled for you, but we need you to supply your database details. To do this:

1. Rename engine/settings.example.php to settings.php in your Elgg installation.

2. Open it with a text editor and enter your MySQL database details. If you don't know these, ask your system administrator or technical support for help.

Alternatively, you can enter your database settings below and we will try and do this for you...",
	
			'installation:language' => "The default language for your site:",
			'installation:path' => "The full path to your site root on your disk, followed by a trailing slash:",
			'installation:settings' => "System settings",
			'installation:settings:dbwizard:label:dbname' => "Elgg database",
			'installation:settings:dbwizard:label:host' => "Database hostname (usually 'localhost')",
			'installation:settings:dbwizard:label:pass' => "Database password",
			'installation:settings:dbwizard:label:prefix' => "Database table prefix (usually 'elgg')",
			'installation:settings:dbwizard:label:user' => "Database user",
			'installation:settings:dbwizard:prompt' => "Enter your database settings below and hit save:",
			'installation:settings:dbwizard:savefail' => "We were unable to save the new settings.php. Please save the following file as engine/settings.php using a text editor.",
			'installation:settings:description' => "Now that the Elgg database has been successfully installed, you need to enter a couple of pieces of information to get your site fully up and running. We've tried to guess where we could, but <b>you should check these details.</b>",
			'installation:sitedescription' => "Short description of your site (optional)",
			'installation:siteemail' => "Site email address (used when sending system emails)",
			'installation:sitename' => "The name of your site (eg \"My social networking site\"):",
			'installation:success' => "Elgg's database was installed successfully.",
			'installation:usage' => "This option lets Elgg send anonymous usage statistics back to Curverider.",
			'installation:usage:label' => "Send anonymous usage statistics",
			'installation:view' => "Enter the view which will be used as the default for your site or leave this blank for the default view (if in doubt, leave as default):",
			'installation:wwwroot' => "The site URL, followed by a trailing slash:",
			
			'upgrade:core' => "Your elgg installation was upgraded",
			'upgrade:db' => "Your database was upgraded.",
			'upgrading' => "Upgrading",
	
		/**
		 * Welcome
		 */
	
			'welcome' => "Welcome %s",
			'welcome_message' => "Welcome to this Elgg installation.",
	
		/**
		 * Emails
		 */
		 
			'email:address:label' => "Your email address",
			'email:confirm:success' => "You have confirmed your email address!",
			'email:confirm:fail' => "Your email address could not be verified...",
	
			'friend:newfriend:subject' => "%s has made you a friend!",
			'friend:newfriend:body' => "
%s has made you a friend!

To view their profile, click here:

	%s

You cannot reply to this email.",
	
			'email:resetpassword:subject' => "Password reset!",
			'email:resetpassword:body' => "
Hi %s,
			
Your password has been reset to: %s",
	
			'email:resetreq:subject' => "Request for new password.",
			'email:resetreq:body' => "
Hi %s,
			
Somebody (from the IP address %s) has requested a new password for their account.

If you requested this click on the link below, otherwise ignore this email.


%s",
	
			'email:save:fail' => "Your new email address could not be saved.",
			'email:save:success' => "New email address saved, verification requested.",
			'email:settings' => "Email settings",

		/**
		 * XML-RPC
		 */
		 
			'xmlrpc:noinputdata'	=>	"Input data missing",
	
		/**
		 * Comments
		 */
	
			'comments:count' => "%s comments",
			
			'generic_comment:blank' => "Sorry; you need to actually put something in your comment before we can save it.",
			'generic_comment:deleted' => "Your comment was successfully deleted.",
			'generic_comment:email:subject' => "You have a new comment!",
			'generic_comment:email:body' => "
You have a new comment on your item '%s' from %s. It reads:

%s

To reply or view the original item, click here:

	%s

To view %s's profile, click here:

	%s

You cannot reply to this email.",
	
			'generic_comment:failure' => "An unexpected error occurred when adding your comment. Please try again.",
			'generic_comment:notdeleted' => "Sorry; we could not delete this comment.",
			'generic_comment:notfound' => "Sorry; we could not find the specified item.",
			'generic_comment:posted' => "Your comment was successfully posted.",
			'generic_comments:add' => "Add a comment",
			'generic_comments:text' => "Comment",
			
			'riveraction:annotation:generic_comment' => "%s commented on %s",

		/**
		 * Entities
		 */
		 
			'entity:default:missingsupport:popup' => "This entity cannot be displayed correctly. This may be because it requires support provided by a plugin that is no longer installed.",
			'entity:default:strapline' => "Created %s by %s",
			'entity:delete:fail' => "Entity %s could not be deleted",
			'entity:delete:success' => "Entity %s has been deleted",
	
		/**
		 * Action gatekeeper
		 */
		 
			'actiongatekeeper:missingfields' => "Form is missing __token or __ts fields",
			'actiongatekeeper:pluginprevents' => "A extension has prevented this form from being submitted.",
			'actiongatekeeper:timeerror' => "The page you were using has expired. Please refresh and try again.",
			'actiongatekeeper:tokeninvalid' => "We encountered an error (token mismatch). This probably means that the page you were using expired. Please try again.",
	
		/**
		 * Word blacklists
		 */
		 
			'word:blacklist' => "and, the, then, but, she, his, her, him, one, not, also, about, now, hence, however, still, likewise, otherwise, therefore, conversely, rather, consequently, furthermore, nevertheless, instead, meanwhile, accordingly, this, seems, what, whom, whose, whoever, whomever",
	
		/**
		 * Languages according to ISO 639-1
		 * Only translate and uncomment the line for your language
		 */
		 
			//'aa' => "Afar",
			//'ab' => "Abkhazian",
			//'af' => "Afrikaans",
			//'am' => "Amharic",
			//'ar' => "Arabic",
			//'as' => "Assamese",
			//'ay' => "Aymara",
			//'az' => "Azerbaijani",
			//'ba' => "Bashkir",
			//'be' => "Byelorussian",
			//'bg' => "Bulgarian",
			//'bh' => "Bihari",
			//'bi' => "Bislama",
			//'bn' => "Bengali; Bangla",
			//'bo' => "Tibetan",
			//'br' => "Breton",
			//'ca' => "Catalan",
			//'co' => "Corsican",
			//'cs' => "Czech",
			//'cy' => "Welsh",
			//'da' => "Danish",
			//'de' => "German",
			//'dz' => "Bhutani",
			//'el' => "Greek",
			'en' => "English",
			//'eo' => "Esperanto",
			//'es' => "Spanish",
			//'et' => "Estonian",
			//'eu' => "Basque",
			//'fa' => "Persian",
			//'fi' => "Finnish",
			//'fj' => "Fiji",
			//'fo' => "Faeroese",
			//'fr' => "French",
			//'fy' => "Frisian",
			//'ga' => "Irish",
			//'gd' => "Scots / Gaelic",
			//'gl' => "Galician",
			//'gn' => "Guarani",
			//'gu' => "Gujarati",
			//'he' => "Hebrew",
			//'ha' => "Hausa",
			//'hi' => "Hindi",
			//'hr' => "Croatian",
			//'hu' => "Hungarian",
			//'hy' => "Armenian",
			//'ia' => "Interlingua",
			//'id' => "Indonesian",
			//'ie' => "Interlingue",
			//'ik' => "Inupiak",
			//'in' => "Indonesian",
			//'is' => "Icelandic",
			//'it' => "Italian",
			//'iu' => "Inuktitut",
			//'iw' => "Hebrew (obsolete)",
			//'ja' => "Japanese",
			//'ji' => "Yiddish (obsolete)",
			//'jw' => "Javanese",
			//'ka' => "Georgian",
			//'kk' => "Kazakh",
			//'kl' => "Greenlandic",
			//'km' => "Cambodian",
			//'kn' => "Kannada",
			//'ko' => "Korean",
			//'ks' => "Kashmiri",
			//'ku' => "Kurdish",
			//'ky' => "Kirghiz",
			//'la' => "Latin",
			//'ln' => "Lingala",
			//'lo' => "Laothian",
			//'lt' => "Lithuanian",
			//'lv' => "Latvian/Lettish",
			//'mg' => "Malagasy",
			//'mi' => "Maori",
			//'mk' => "Macedonian",
			//'ml' => "Malayalam",
			//'mn' => "Mongolian",
			//'mo' => "Moldavian",
			//'mr' => "Marathi",
			//'ms' => "Malay",
			//'mt' => "Maltese",
			//'my' => "Burmese",
			//'na' => "Nauru",
			//'ne' => "Nepali",
			//'nl' => "Dutch",
			//'no' => "Norwegian",
			//'oc' => "Occitan",
			//'om' => "(Afan) Oromo",
			//'or' => "Oriya",
			//'pa' => "Punjabi",
			//'pl' => "Polish",
			//'ps' => "Pashto / Pushto",
			//'pt' => "Portuguese",
			//'qu' => "Quechua",
			//'rm' => "Rhaeto-Romance",
			//'rn' => "Kirundi",
			//'ro' => "Romanian",
			//'ru' => "Russian",
			//'rw' => "Kinyarwanda",
			//'sa' => "Sanskrit",
			//'sd' => "Sindhi",
			//'sg' => "Sangro",
			//'sh' => "Serbo-Croatian",
			//'si' => "Singhalese",
			//'sk' => "Slovak",
			//'sl' => "Slovenian",
			//'sm' => "Samoan",
			//'sn' => "Shona",
			//'so' => "Somali",
			//'sq' => "Albanian",
			//'sr' => "Serbian",
			//'ss' => "Siswati",
			//'st' => "Sesotho",
			//'su' => "Sundanese",
			//'sv' => "Swedish",
			//'sw' => "Swahili",
			//'ta' => "Tamil",
			//'te' => "Tegulu",
			//'tg' => "Tajik",
			//'th' => "Thai",
			//'ti' => "Tigrinya",
			//'tk' => "Turkmen",
			//'tl' => "Tagalog",
			//'tn' => "Setswana",
			//'to' => "Tonga",
			//'tr' => "Turkish",
			//'ts' => "Tsonga",
			//'tt' => "Tatar",
			//'tw' => "Twi",
			//'ug' => "Uigur",
			//'uk' => "Ukrainian",
			//'ur' => "Urdu",
			//'uz' => "Uzbek",
			//'vi' => "Vietnamese",
			//'vo' => "Volapuk",
			//'wo' => "Wolof",
			//'xh' => "Xhosa",
			//'yi' => "Yiddish",
			//'yo' => "Yoruba",
			//'za' => "Zuang",
			//'zh' => "Chinese",
			//'zu' => "Zulu",
		
	);
	add_translation('en', $english);

?>
