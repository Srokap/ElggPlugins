<?php
/**
 * View a wire post
 */

$name = $vars['entity']->getOwnerEntity()->name;
$user_name = $vars['entity']->getOwnerEntity()->username;
$post_guid = $vars['entity']->guid;

$author_one = $vars['url'] . 'pg/thewire/owner/' . $user_name;
$body_text = "<b><a href=\"$author_one\">$name</a></b>";

$reply = false;

//is the post a reply?
if ($vars['entity']->reply) {
	$reply = true;

	//get the owner of the message being replied to
	$owner = get_user(get_entity($vars['entity']->parent)->owner_guid);

	$other_url = $vars['url'] . 'pg/thewire/owner/' . $owner->username;

	if ($owner) {
		$text = elgg_echo('thewire:inreplyto');
		$body_text .= " <span class='thewire_inreplyto'>$text</span> <b><a href=\"{$other_url}\">" . $owner->name . "</a></b>";
	}
}


$body_text .= ": ";
$post_text = thewire_filter($vars['entity']->description);
$body_text .= $post_text;

// options
$options = '';
if (isadminloggedin ()) {
	$options .= "<li>" . elgg_view("output/confirmlink", array('href' => $vars['url'] . "action/thewire/delete?thewirepost=" . $vars['entity']->getGUID(),
				'text' => elgg_echo('thewire:delete'),
				'confirm' => elgg_echo('deleteconfirm'),)) . "</li>";
}

if ($vars['full'] == true && $reply == true) {
	$text = elgg_echo('thewire:view:previous');
	$options .= "<li><a class=\"thewire_view_previous\" href=\"{$post_guid}\">$text</a></li>";
}

$text = elgg_echo('thewire:view:thread');
$options .= "<li><a href=\"{$CONFIG->wwwroot}pg/thewire/view/{$post_guid}\">$text</a></li>";

if (isloggedin ()) {
	$text = elgg_echo('thewire:reply:small');
	$options .= "<li><a href=\"{$vars['url']}pg/thewire/reply/{$post_guid}\">$text</a></li>";
}
?>
<div class="thewire_post">
<?php
if ($vars['icon'] !== false) {
?>
	<div class="thewire_icon">
<?php
echo elgg_view("profile/icon", array('entity' => $vars['entity']->getOwnerEntity(), 'size' => 'small'));
?>
	</div>
<?php
}
?>
	<div class="thewire_body">
		<div class="thewire_msg">
<?php
echo $body_text;
?>
		</div>
		<div class="thewire_info">
			<div class="thewire_options">
				<ul>
<?php
echo $options;
?>
				</ul>
			</div>
<?php
echo elgg_view_friendly_time($vars['entity']->time_created);
echo ' ' . elgg_echo('thewire:via') . ' ' . elgg_echo("thewire:method:{$vars['entity']->method}");
?>
		</div>
	</div>
</div>
<?php
if ($vars['full'] == true && $reply == true) {
?>
<div class="thewire_previous" id="thewire_previous_<?php echo $post_guid; ?>">
	<img class="thewire_previous_img" src="<?php echo $vars['url'] . "mod/thewire/graphics/ajax-loader.gif"; ?>" height="11" width="16" />
</div>
<?php
}
