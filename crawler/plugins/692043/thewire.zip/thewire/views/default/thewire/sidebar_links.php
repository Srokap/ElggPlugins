<?php
/**
 * Sidebar menu
 */

$select_your = '';
$select_user = '';
$select_all = '';
$select_following = '';

if ($vars['user_wire']) {
	$select_user = 'class="selected"';
} else if ($vars['your_wire']) {
	$select_your = 'class="selected"';
} else if ($vars['user_following']) {
	$select_following = 'class="selected"';
} else if ($vars['all']) {
	$select_all = 'class="selected"';
}
?>
<div class="sidebarBox">
	<div id="owner_block_submenu">
		<ul>
<?php
	// View all wire posts
	echo "<li {$select_all}><a href=\"{$vars['url']}pg/thewire/\">" . elgg_echo('thewire') . "</a></li>";
	
	$viewer = get_loggedin_user();
	if ($viewer && $viewer->guid == page_owner()) {
		// Show "Your posts"
		echo "<li {$select_your}><a href=\"{$vars['url']}pg/thewire/owner/" . $viewer->username . "\">". elgg_echo('thewire:yours') ."</a></li>";
		
		// Show "Following posts"
		echo "<li {$select_following}><a href=\"{$vars['url']}pg/thewire/following/" . $viewer->username . "\">" . elgg_echo('thewire:following:menu') ."</a></li>";
	} else if ($viewer) {
		$owner = page_owner_entity();
		
		// Show "Your posts"
		echo "<li {$select_your}><a href=\"{$vars['url']}pg/thewire/owner/" . $viewer->username . "\">". elgg_echo('thewire:yours') ."</a></li>";

		// Show "%s's posts", where %s is the user of the page owner
		echo "<li {$select_user}><a href=\"{$vars['url']}pg/thewire/owner/" . $owner->username . "\">".
			sprintf(elgg_echo('thewire:user'), $owner->name) ."</a></li>";
	}
?>
		</ul>
	</div>
</div>
