<?php
/**
 * Wire add form
 */
?>
<div class="thewire_add_form">
	<form action="<?php echo $vars['url']; ?>action/thewire/add" method="post" name="wireForm">
		<textarea name='body' rows='2' cols='100' onkeydown="textCounter(document.wireForm.body,document.wireForm.remLen1,200)" onkeyup="textCounter(document.wireForm.body,document.wireForm.remLen1,200)" id="thewire_large-textarea"></textarea>
		<div class='thewire_characters_remaining'>
			<input readonly="readonly" type="text" name="remLen1" size="3" maxlength="3" value="200" class="thewire_characters_remaining_field" /><?php echo elgg_echo('thewire:charleft'); ?>
		</div>
<?php 
	echo elgg_view('input/securitytoken');
	if ($vars['parent_guid']) {
		echo "<input type='hidden' name='parent_guid' value='{$vars['parent_guid']}' />";
	}
	
	$post = elgg_echo('post');
	if (isset($vars['reply']) && $vars['reply']) {
		$post = elgg_echo('thewire:reply');
	}
?>
		<input type="submit" value="<?php echo $post; ?>" id="thewire_submit_button" />
	</form>
</div>
<?php echo elgg_view('input/urlshortener'); ?>