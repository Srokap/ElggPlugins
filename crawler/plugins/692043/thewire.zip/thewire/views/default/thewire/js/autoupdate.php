<?php
/**
 * Javascript that checks for new posts
 */

$POLLING_INTERVAL_MSEC = 60000;
	
// DEPENDENCIES ON OTHER ELGG COMPONENTS
	
// Other dependencies
$CALLBACK_URI = "mod/thewire/endpoint/autoupdate.php";
$CALLBACK_URL_TEMPLATE = $CONFIG->wwwroot . $CALLBACK_URI;
		
// The polling plugin is an enhanced version of: 
// 		http://buntin.org/2008/sep/23/jquery-polling-plugin/
?>
<script type="text/javascript">

var latestGUID = <?php echo (int)$vars['latest_guid']; ?>;
var updateType   = "<?php echo $vars['update_type']; ?>";
var updateParam  = "<?php echo $vars['update_param']; ?>";

(function($) {
	
	$.fn.poll = function(options){
		var $this = $(this);
		// extend our default options with those provided
		var opts = $.extend({}, $.fn.poll.defaults, options);
        
		setInterval(update, opts.interval);

        // method used to update element html
        function update(){

    		$.ajax({type: "GET",
				url: typeof(opts.url) == 'function' ? opts.url() : opts.url, 
				dataType: "json",
				cache: false,
				data: {latest: latestGUID, type: updateType, param: updateParam},
				success: opts.callback 
    		});
		};
	};

    // default options
    $.fn.poll.defaults = {
        url: ".",  // can be an actual url or a callback that returns a (dynamic) url
        callback: '',
        interval: 2000
    };
})(jQuery);


$(document).ready(function() {
	
	var $wireItemList = $("<?php echo $CSS_SELECTOR_WIRE_ITEMS_DIV; ?>");
	$wireItemList.poll({
	    url: "<?php echo $CALLBACK_URL_TEMPLATE ?>",
	    interval: <?php echo $POLLING_INTERVAL_MSEC; ?>,
	    callback: function(jsonData, textStatus){ 
			
	    	// update latest guid
	    	latestGUID = jsonData['guid'];
	    	
			// if we have new updates, add and animate
			if (jsonData['posts'].length) {
				newposts = "<div class='thewire_newest'>" + jsonData['posts'] + "</div>";
				$("#thewire_new_posts").prepend(newposts);

				$(".thewire_newest").animate({ backgroundColor: "#FFFFFF"}, 8000);				
			}			
	    }
	});
}); // ready
</script>