<?php
/**
 * Character counter js
 */
?>
// text counter for the wire
function textCounter(field, cntfield, maxlimit) {
	cntfield.value = maxlimit - field.value.length;

	if (cntfield.value < 0) {
		$(".thewire_characters_remaining").css("color", "#D40D12");
		$(".thewire_characters_remaining_field").css("color", "#D40D12");
		$("#thewire_submit_button").attr('disabled','disabled');
		$("#thewire_submit_button").css('background','#999999');
		$("#thewire_submit_button").css('border-color','#999999');
		$("#thewire_submit_button").css('cursor','default');
	} else {
		$(".thewire_characters_remaining").css("color", "");
		$(".thewire_characters_remaining_field").css("color", "");
		$("#thewire_submit_button").removeAttr('disabled');
		$("#thewire_submit_button").css('background','#4690d6');
		$("#thewire_submit_button").css('border-color','#4690d6');
		$("#thewire_submit_button").css('cursor','pointer');
	}
}