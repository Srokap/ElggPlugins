<script type="text/javascript">

var oldestGUID = <?php echo $vars['oldest_guid']; ?>;
var moreType   = "<?php echo $vars['more_type']; ?>";
var moreParam  = "<?php echo $vars['more_param']; ?>";

$(document).ready(function() {

	$(".thewire_more").live("click", function(){
		var ajax_loader_url = '<img src="<?php echo $CONFIG->wwwroot . "mod/thewire/graphics/ajax-loader.gif"; ?>" />';
		
		var button = $(this);
		button.blur();
		var endpoint = "<?php echo $vars['url'] . "mod/thewire/endpoint/more.php"; ?>";
		
		$.ajax({type: "GET",
				url: endpoint, 
				dataType: "json",
				cache: false,
				data: {oldest: oldestGUID, type: moreType, param: moreParam},
				beforeSend: function(){
					$(".thewire_more").html(ajax_loader_url);
				},
				success: function(jsonData){

					if (jsonData['html'].length > 0) {
						oldestGUID = jsonData['guid'];
						$("#thewire_old_posts").append(jsonData['html']);
					}
					if (jsonData['more'] == true) {
						$(".thewire_more").html("<?php echo elgg_echo('thewire:more'); ?>");
					} else {
						$(".thewire_more").html("<?php echo elgg_echo('thewire:nomore'); ?>");
						$(".thewire_more").addClass("thewire_more_disabled");															
					}
				}
				});
		
		
		return false;	      
	});
	
	
});

</script>