/********************************
              The Wire
**********************************/
.thewire_container {
-webkit-border-radius: 8px; 
-moz-border-radius: 8px;
background: #ffffff;
margin: 0 10px 10px 10px;
padding: 10px 10px 20px 10px;
}

.thewire_post {
border-bottom: 1px solid #dedede;
padding: 12px 0;
overflow: hidden;
}

.thewire_post:hover {
background-color: #f8f8f8;
}

.thewire_icon {
float: left;
margin: 0 8px 4px 2px;
}

.thewire_body {
margin-left: 55px;
}

.thewire_msg {
margin: 0 5px 5px 0;
}

.thewire_info {
font-size: 85%;
color: #666666;
cursor: default;
}

.thewire_options {
float: right;
}

.thewire_options ul {
padding: 0;
margin: 0;
}

.thewire_options li {
list-style-type: none;
margin-left: 12px;
float: left;
}

.thewire_inreplyto {
color: #008000;
font-weight: bold;
}

.thewire_newest {
background-color: #A0F54D;  /* light green */
}

.thewire_more {
display: block;
margin: 10px auto;
padding: 8px 0;
width: 100px;
min-height: 18px;
text-align: center;
background-color: #DEDEDE;
-webkit-border-radius: 8px; 
-moz-border-radius: 8px;
}

.thewire_more:hover {
background-color: #cccccc;
text-decoration: none;
}

.thewire_more img {
margin-top: 4px;
}

.thewire_more_disabled:hover {
background-color: #DEDEDE;
color: #4690D6;
cursor: default;
}

.thewire_add_form {
background: white;
-webkit-border-radius: 8px; 
-moz-border-radius: 8px;
margin:0 10px 10px 10px;
padding:10px;	
}
.thewire_add_form input[type="submit"] {
margin:0;
}

.thewire_previous {
display: none;
}

.thewire_previous_img {
margin: 25px 48%;
}

.thewire_generic_title h3 {
color:#0054A7;
margin:0 0 0 8px;
padding:5px;
}

#thewire_replying {
background: #FFFFFF;
margin: 0 10px -10px;
padding: 10px 10px 10px 10px;
-moz-border-radius-topleft: 8px;
-moz-border-radius-topright: 8px;
-webkit-border-top-right-radius: 8px;
-webkit-border-top-left-radius: 8px; 
}


.thewire_first_level_reply {
margin-left: 50px;
}



/* hide owner name etc in certain situations - sidebar and wire widgets */
.collapsable_box_content .wireownername,
.collapsable_box_content .replytolink {
	display:none;
}





/* threaded conversation/replies */
.the_wire_conversation {
	text-align: left;
}

.replytolink,
.conversationlink {
	/* text-decoration: underline;*/
	cursor: pointer;
}
.conversationlink {
	display:inline !important;
}


.thewire-threaded-posts {
	padding:0;
	/* margin:10px 0 20px 0; */
}
.the_wire_conversation {
	margin:10px 0 20px 0;
	height:auto;
}

.thewire-threaded-posts .thewire-singlepage {
	margin:0;
}
.thewire-childpost {
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	background: white;
	margin:4px 20px 5px 20px;
	padding:5px;
}
.parentpost {
	margin-left:20px;
	margin-right:20px;
}
.current {
   background:#bbdaf7 !important;
}
.thewire-childpost .thewire_icon {
	margin:0 8px 0 0;
}
.thewire-childpost .note_date {
	font-size:90%;
	color:#666666;
	padding:0;
}


.sidebarBox .thewire-singlepage {
	margin:20px 0 10px 0;
}
.sidebarBox .contentWrapper {
	margin:10px 0 0 0;
}
.sidebarBox #owner_block_submenu {
	margin:0;
}

/* single post reply page */
.thewire-replypage {
	margin:0 10px 0 10px;
}
.thewire-replypage .parentpost {
	margin-left:0;
	margin-right:0;
}

/* the wire everyone */
.sidebarBox #thewire_sidebarInputBox {
	width:178px;
	height:140px;
}
.sidebarBox .last_wirepost {
	margin:20px 0 20px 0;
}
.sidebarBox .last_wirepost .thewire-singlepage {
	margin:0;
}
.sidebarBox .last_wirepost .thewire-singlepage .thewire_options {
	display:none;
}
.sidebarBox .last_wirepost .thewire-singlepage .note_date {
	line-height: 1em;
	padding:3px 0 0 0;
	width:142px;
}
.sidebarBox .last_wirepost .thewire-singlepage .note_body {
	color:#666666;
	line-height: 1.2em;
}
.sidebarBox .last_wirepost .thewire-singlepage .thewire-post {
	background-position: 130px bottom;
}
.sidebarBox .thewire_characters_remaining {
	float:right;
}
.sidebarBox input.thewire_characters_remaining_field {
	background: #dedede;
}
.sidebarBox input.thewire_characters_remaining_field:focus {
	background: #dedede;
	border:none;
}
.sidebarBox input#thewire_submit_button {
	margin:2px 0 0 0;
	padding:2px 2px 1px 2px;
	height:auto;
}
.sidebarBox .membersWrapper {
	background: white;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	padding:7px;	
}
.sidebarBox .membersWrapper .recentMember {
	margin:2px;
	float:left;
}
/* br necessary for ie6 & 7 */
.sidebarBox .membersWrapper br {
	height:0;
	line-height:0;
}




/* widget */
.thewire-singlepage {
	margin:0 10px 0 10px;
}
.thewire-singlepage .note_body {
	background: white;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	padding: 5px;
}
.collapsable_box_content .note_body {
	line-height:1.2em;
}
.thewire-singlepage .thewire-post {
	margin-bottom:5px;
	background:transparent url(<?php echo $vars['url']; ?>mod/thewire/graphics/thewire_speech_bubble.gif) no-repeat bottom right; 
}
.thewire-post .reply {
	font: 11px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #ffffff;
	background:#999999;
	border: 2px solid #999999;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	width: auto;
	padding: 0 3px 2px 3px;
	margin:0 0 5px 5px;
	cursor: pointer;
	float:right;
}
.thewire-post .reply:hover {
	background: #4690d6;
	border: 2px solid #4690d6;
	color:white;
	text-decoration: none;
}
.thewire-post .delete_note {
	width:14px;
	height:14px;
	margin:3px 0 0 0;
	float:right;
}
.thewire-post .delete_note a {
	display:block;
	cursor: pointer;
	width:14px;
	height:14px;
	background: url("<?php echo $vars['url']; ?>_graphics/icon_customise_remove.png") no-repeat 0 0;
	text-indent: -9000px;
}
.thewire-post .delete_note a:hover {
	background-position: 0 -16px;
}

/* reply form */
textarea#thewire_large-textarea {
	width: 664px;
	height: 40px;
	padding: 6px;
	font-family: Arial, 'Trebuchet MS','Lucida Grande', sans-serif;
	font-size: 100%;
	color:#666666;
}
/* IE 6 fix */
* html textarea#thewire_large-textarea { 
	width: 642px;
}

input.thewire_characters_remaining_field { 
	color:#333333;
	border:none;
	font-size: 100%;
	font-weight: bold;
	padding:0 2px 0 0;
	margin:0;
	text-align: right;
	background: white;
}
input.thewire_characters_remaining_field:focus {
	border:none;
	background:white;
}
.thewire_characters_remaining {
	text-align: right;
}

#wiresearchform {
margin-top: 5px;
}

#wiresearchform input.search_input {
-moz-border-radius-bottomleft:4px;
-moz-border-radius-bottomright:4px;
-moz-border-radius-topleft:4px;
-moz-border-radius-topright:4px;
background-color:#FFFFFF;
border:1px solid #BBBBBB;
color:#999999;
font-size:12px;
font-weight:bold;
height:14px;
margin:0;
padding:2px;
}

#wiresearchform input.search_submit_button {
height:18px;
margin:0;
padding:2px;
padding-top:0;
width:auto;
}

.wire_following_icon {
	margin:0 0 6px 6px;
	float:left;
}