<?php
/**
 * Display latest wire post on profile page
 */
$owner = $vars['entity']->guid;
$url_to_wire = $vars['url'] . "pg/thewire/owner/" . $vars['entity']->username;

//grab the users latest from the wire
$latest_wire = elgg_get_entities(array(
	"type" => "object",
	"subtype" => "thewire",
	"owner_guid" => $owner,
	"limit" => 1,
));

if ($latest_wire) {
	foreach ($latest_wire as $lw) {
		$content = $lw->description;
		$time = "<span> (" . elgg_view_friendly_time($lw->time_created) . ")</span>";
	}
}

if ($latest_wire) {
	echo "<div class=\"profile_status\">";
	echo $content;
	if ($owner == get_loggedin_userid()) {
		echo " <a class=\"status_update\" href=\"{$url_to_wire}\">update</a>";
	}
	echo $time;
	echo "</div>";
}
