<?php
/**
 * Reply view
 */
// what post are we replying to
$parent_guid = $vars['guid'];
$parent_post = get_entity($parent_guid);

// compatible with posts created with original Curverider plugin
$thread_id = $parent_post->wire_thread;
if (!$thread_id) {
	$parent_post->wire_thread = $parent_post->guid;
}

//get all discussions in that thread
$discussion = elgg_get_entities_from_metadata(array(
	"metadata_name" => "wire_thread",
	"metadata_value" => $parent_post->wire_thread,
	"type" => "object",
	"subtype" => "thewire",
	"limit" => 20,
));

$parent_post_body = $parent_post->description;

$parent_poster_name = $parent_post->getOwnerEntity()->name;
?>
<div id="thewire_replying">
<?php
if ($parent_poster_name) {
?>
	<b><?php echo elgg_echo('thewire:replying'); ?> <?php echo $parent_poster_name; ?>
		<?php echo elgg_echo('thewire:who_wrote'); ?>:</b> <?php echo $parent_post_body; ?>
</div>
<?php
}

echo elgg_view("thewire/forms/add", array(
	'parent_guid' => $parent_guid,
	'reply' => true,
));
?>

<div class="thewire_generic_title">
	<h3><?php echo elgg_echo('thewire:conversation_thread'); ?></h3>
</div>

<?php
echo elgg_view('thewire/listing', array('posts' => $discussion, 'full' => false,));
