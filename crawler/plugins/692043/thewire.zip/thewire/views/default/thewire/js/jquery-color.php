
<script type="text/javascript" src="<?php echo $CONFIG->wwwroot."mod/thewire/js/jquery.color.js"; ?>" ></script>
