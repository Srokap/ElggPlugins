<script type="text/javascript">

$(document).ready(function() {

	$(".thewire_view_previous").live("click", function() {

		var link = $(this);
		var post_guid = link.attr("href");
		var div_id = "#thewire_previous_" + post_guid;

		if (link.html() == "<?php echo elgg_echo('thewire:hide:previous'); ?>") {
			link.html("<?php echo elgg_echo('thewire:view:previous'); ?>");
			$(div_id).find('.usericon').fadeOut(400);
			$(div_id).slideUp(400);
			return false;
		}

   		$.ajax({type: "GET",
			url: "<?php echo $vars['url'] . "mod/thewire/endpoint/viewprevious.php"; ?>",
			dataType: "html",
			cache: false,
			data: {guid: post_guid},
			beforeSend: function() {
				link.html("<?php echo elgg_echo('thewire:hide:previous'); ?>");
				$(".thewire_container").find('.usericon').css('position', 'static');
				$(div_id).slideDown(600);
			},
			success: function(htmlData) {

				if (htmlData.length > 0) {

					$(div_id).html('<div class="thewire_first_level_reply">' + htmlData + '</div>');
				}

			}
		});
		
		return false;
	});


});

</script>