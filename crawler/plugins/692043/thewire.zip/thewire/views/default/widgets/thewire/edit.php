<?php
/**
 * Wire widget edit view
 */


// set default values
if (!isset($vars['entity']->num_display)) {
	$vars['entity']->num_display = 4;
}
if (!isset($vars['entity']->content_type)) {
	$vars['entity']->content_type = 'following';
}

$params = array(
	'internalname' => 'params[num_display]',
	'value' => $vars['entity']->num_display,
	'options' => array(1, 2, 3, 4, 5, 6),
);
$num_dropdown = elgg_view('input/pulldown', $params);

$params = array(
	'internalname' => 'params[content_type]',
	'value' => $vars['entity']->content_type,
	'options_values' => array(
		'site' => elgg_echo('thewire:widget:site'),
		'following' => elgg_echo('thewire:widget:following'),
		'mine' => elgg_echo('thewire:widget:mine'),
	),
);
$type_dropdown = elgg_view('input/pulldown', $params);

?>
<p>
	<?php echo elgg_echo('thewire:num'); ?>:
	<?php echo $num_dropdown; ?>
</p>
<p>
	<?php echo elgg_echo('thewire:widget:content_type'); ?>:
	<?php echo $type_dropdown; ?>
</p>
