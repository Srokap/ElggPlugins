<?php
/**
 * Wire widget view
 */

$content_type = $vars['entity']->content_type;
$num = $vars['entity']->num_display;

set_page_owner($vars['entity']->owner_guid);
$page_owner = page_owner_entity();

if ($content_type == 'site') {
	$wire_posts = elgg_get_entities(array(
		'type' => 'object',
		'subtype' => 'thewire',
		'limit' => $num,
	));
	$more_url = $vars['url'] . "pg/thewire/";
} else if ($content_type == 'mine') {
	$wire_posts = $page_owner->getObjects('thewire', $num);
	$more_url = $vars['url'] . "pg/thewire/owner/" . page_owner_entity()->username;
} else {
	$wire_posts = get_user_friends_objects($page_owner->getGUID(), 'thewire', $num);
	$more_url = $vars['url'] . "pg/thewire/following/" . page_owner_entity()->username;
}

// If there are any wire posts to view, view them
if (is_array($wire_posts) && sizeof($wire_posts) > 0) {
	echo '<div class="thewire_container">';
	foreach ($wire_posts as $post) {
		echo elgg_view_entity($post);
	}
	echo '</div>';

	echo "<div class=\"widget_more_wrapper\"><a href=\"$more_url\">";
	echo elgg_echo('thewire:moreposts');
	echo "</a></div>";
}
