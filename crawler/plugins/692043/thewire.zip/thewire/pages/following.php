<?php
/**
 * Wire posts of those you follow
 */

// Get the current page's owner
$page_owner = page_owner_entity();
if ($page_owner == false) {
	set_page_owner(get_loggedin_userid());
	$page_owner = page_owner_entity();
}


$sidebar = elgg_view("thewire/sidebar_links", array('user_following' => 'yes'));

$title = elgg_echo('thewire:following:title');

$content = elgg_view_title($title);

$sidebar_ext = elgg_view("thewire/twitter");
$sidebar_ext .= elgg_view("thewire/following", array('user_guid' => page_owner()));

if (isloggedin()) {
	$content .= elgg_view("thewire/forms/add");
}

$wire_posts = get_user_friends_objects($page_owner->getGUID(), 'thewire', 20);
$content .= elgg_view('thewire/listing', array(
	'posts' => $wire_posts,
	'page_type' => 'following',
	'page_param' => $page_owner->getGUID(),
));


$body = elgg_view_layout("sidebar_boxes", $sidebar, $content, $sidebar_ext);

page_draw($title, $body);
