<?php
/**
 * User's wire posts
 * 
 */

// if cannot return user, send to global view
$owner = get_user_by_username(get_input('username'));
if (!$owner) {
	forward('pg/thewire/');
}

set_page_owner($owner->getGUID());


$user_wire_type = '';
if ($owner->guid == get_loggedin_userid()) {
	$title = elgg_echo('thewire:yours:title');
	$content = elgg_view_title($title);
	$content .= elgg_view("thewire/forms/add");
	$user_wire_type = 'your_wire';
} else {
	$title = sprintf(elgg_echo('thewire:user:title'), $owner->name);
	$content = elgg_view_title($title);
	$user_wire_type = 'user_wire';
}

$sidebar = elgg_view("thewire/sidebar_links", array($user_wire_type => 'yes'));

$sidebar_ext = elgg_view("thewire/twitter");

$sidebar_ext .= elgg_view("thewire/following", array('user_guid' => $owner->getGUID()));

// Display the user's wire
$wire_posts = get_user_objects($owner->getGUID(), 'thewire', 20);
$content .= elgg_view('thewire/listing', array(
	'posts' => $wire_posts,
	'page_type' => 'user',
	'page_param' => $owner->getGUID(),
));

$body = elgg_view_layout("sidebar_boxes", $sidebar, $content, $sidebar_ext);

page_draw($title, $body);
