<?php
/**
 * Reply page
 * 
 */

gatekeeper();

set_page_owner(get_loggedin_userid());

// what are we replying to
$original_post_guid = (int) get_input('wire_post');

// choose the required canvas layout and items to display
$sidebar = elgg_view("thewire/sidebar_links", array('add' => 'yes'));
$sidebar_ext = elgg_view("thewire/twitter");

$content = elgg_view_title(elgg_echo('thewire:reply'));
$content .= elgg_view("thewire/reply", array('guid' => $original_post_guid));

$body = elgg_view_layout("sidebar_boxes", $sidebar, $content, $sidebar_ext);

page_draw(elgg_echo('thewire:reply'), $body);
