<?php
/**
 * Check if there are any new wire posts
 */

$start = microtime(true);

// the lastest guid is passed in
$latest = (int) $_GET['latest'];

/*
 * 
 *  Directly querying database for updates before loading engine
 *  This saves substantial time - 1000x faster
 * 
 */
require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/engine/settings.php');

global $CONFIG;
$mysql_dblink = mysql_connect($CONFIG->dbhost, $CONFIG->dbuser, $CONFIG->dbpass, true);
if ($mysql_dblink === false) {
	// failed to connect
	header('HTTP/1.0 304 Not Modified');
	exit;
}

if (mysql_select_db($CONFIG->dbname, $mysql_dblink) == false) {
	// failed to connect
	header('HTTP/1.0 304 Not Modified');
	exit;
}

// query for any new wire posts
$query = "SELECT distinct e.* FROM {$CONFIG->dbprefix}entities e JOIN {$CONFIG->dbprefix}entity_subtypes s ";
$query .= "ON e.subtype = s.id WHERE s.subtype = 'thewire' AND e.guid > $latest";
$result = mysql_query($query, $mysql_dblink);
if ($result === false || mysql_num_rows($result) == 0) {
	// no new data
	header('HTTP/1.0 304 Not Modified');
	exit;
}

// set new latest guid
$num_results = mysql_num_rows($result);
$new_latest_guid = (int) mysql_result($result, $num_results - 1, 'guid');

mysql_close($mysql_dblink);


/*
 * 
 * There is at least one new wire post - but might not be for this page
 * Load engine and check to see if we need to return an update
 * 
 */

require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");

// setup return variables
$data = array();
$data['guid'] = $new_latest_guid;
$data['posts'] = '';

// once we switch over to using guids completely this won't be necessary
$reference_post = get_entity($latest);

// what type of page is this
$page_type = get_input('type');
$param = get_input('param');

switch ($page_type) {
	case 'world':
		$new_posts = elgg_get_entities(array(
			'type' => 'object',
			'subtype' => 'thewire',
			'limit' => 20,
			'created_time_lower' => $reference_post->time_created + 1,
		));
		break;
	case 'user':
		$new_posts = get_user_objects($param, 'thewire', 20, 0, $reference_post->time_created + 1);
		break;
	case 'following':
		$new_posts = get_user_friends_objects($param, 'thewire', 20, 0, $reference_post->time_created + 1);
		break;
	case 'search':
		$new_posts = '';
		break;
	default:
		break;
}

if (!is_array($new_posts)) {
	// send data to at least update the guid
	echo json_encode($data);
	exit;
}

foreach ($new_posts as $post) {
	$data['posts'] .= elgg_view_entity($post);
}

echo json_encode($data);
