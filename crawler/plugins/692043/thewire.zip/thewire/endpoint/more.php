<?php
/**
 * Load more posts
 */

require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");

$oldest_post_guid = get_input('oldest');
$page_type = get_input('type');
$param = get_input('param');

if (!$oldest_post_guid || !$page_type) {
	header('HTTP/1.0 304 Not Modified');
	exit;
}

// once we switch over to using guids completely this won't be necessary
$reference_post = get_entity($oldest_post_guid);

switch ($page_type) {
	case 'world':
		$wire_posts = elgg_get_entities(array(
			'type' => 'object',
			'subtype' => 'thewire',
			'limit' => 20,
			'created_time_upper' => $reference_post->time_created - 1,
		));
		break;
	case 'user':
		$wire_posts = get_user_objects($param, 'thewire', 20, 0, 0, $reference_post->time_created - 1);
		break;
	case 'following':
		$wire_posts = get_user_friends_objects($param, 'thewire', 20, 0, 0, $reference_post->time_created - 1);
		break;
	case 'search':
		$wire_posts = '';
		break;
	default:
		break;
}

$data = array();
$data['html'] = "";
$data['more'] = false;

if (!is_array($wire_posts)) {
	echo json_encode($data);
	exit;
}

foreach ($wire_posts as $post) {
	$data['html'] .= elgg_view_entity($post, true);
	$data['guid'] = $post->guid;
	if (count($wire_posts) == 20) {
		$data['more'] = true;
	}
}

echo json_encode($data);
