<?php

function linkedin_init()
{
    global $CONFIG;
    register_action('linkedin/login', true, $CONFIG->pluginspath.'linkedin/actions/login.php');
    register_action('linkedin/callback', true, $CONFIG->pluginspath.'linkedin/actions/callback.php');
    elgg_extend_view('account/forms/login', 'linkedin/login');
    extend_elgg_settings_page('linkedin/usersettings', 'usersettings/user');
    register_plugin_hook('usersettings:save','user', 'linkedin_usersettings_save', 1);
}

function linkedin_usersettings_save($hook, $type, $returnvalue, $params)
{
    get_loggedin_user()->linkedin_sync = isset($_POST['linkedin_sync']);
}

register_elgg_event_handler('init', 'system', 'linkedin_init');
