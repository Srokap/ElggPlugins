<p>
    <label><?php echo elgg_echo('linkedin:settings:key') ?></label>
    <input type="text" class="input-text" name="params[linkedin_key]" value="<?php echo get_plugin_setting('linkedin_key', 'linkedin') ?>">
</p>
<p>
    <label><?php echo elgg_echo('linkedin:settings:secret') ?></label>
    <input type="text" class="input-text" name="params[linkedin_secret]" value="<?php echo get_plugin_setting('linkedin_secret', 'linkedin') ?>">
</p>