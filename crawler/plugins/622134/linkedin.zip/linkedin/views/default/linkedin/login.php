<div class="linkedin-login">
    <a href="<?php echo elgg_add_action_tokens_to_url('/action/linkedin/login') ?>">
        <img src="/mod/linkedin/graphics/linkedin_signin.png" alt="sign in with linkedin">
    </a>
</div>