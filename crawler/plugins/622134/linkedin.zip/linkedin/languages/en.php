<?php

$english = array(

    'linkedin:settings:key' => 'API Key',
    'linkedin:settings:secret' => 'Secret Key',

    'linkedin:usersettings:title' => 'LinkedIn Settings',
    'linkedin:usersettings:desc' => 'If you select this option your profile details will be updated when you update your LinkedIn profile',
    'linkedin:usersettings:sync' => 'Sync with LinkedIn',

);

add_translation("en", $english);
