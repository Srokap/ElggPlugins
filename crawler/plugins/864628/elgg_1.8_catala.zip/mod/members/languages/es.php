<?php

// Generado por translationbrowser 

$spanish = array( 
	 'members:members'  =>  "Miembros registrados en la red social" , 
	 'members:online'  =>  "Miembros online" , 
	 'members:active'  =>  "Miembros registrados" , 
	 'members:searchtag'  =>  "Buscar miembros por etiquetas" , 
	 'members:searchname'  =>  "Buscar miembros por nombre" , 
	 'members:label:newest'  =>  "Nuevos" , 
	 'members:label:popular'  =>  "Populares" , 
	 'members:label:online' => 'Conectados',
	 'members:label:active'  =>  "Conectados" , 
	 'members:search:name'  =>  "Nombres de usuario" , 
	 'members:search:tags'  =>  "Etiquetas",
	 'members:title:searchname' => 'Buscar miembros para %s',
	 'members:title:searchtag' => 'Miembros con tags %s',
); 

add_translation('es', $spanish); 