<?php

// Generado por translationbrowser 

$catalan = array( 
	 'members:members'  =>  "Membres registrats a la xarxa" , 
	 'members:online'  =>  "Membres en l&iacute;nia" , 
	 'members:active'  =>  "Membres registrats" , 
	 'members:searchtag'  =>  "Cercar membres per etiqueta" , 
	 'members:searchname'  =>  "Cercar membres per nom" , 
	 'members:label:newest'  =>  "Nous" , 
	 'members:label:popular'  =>  "Populars" , 
	 'members:label:online' => 'Connectats',
	 'members:label:active'  =>  "Connectats" , 
	 'members:search:name'  =>  "Noms d&acute;usuari" , 
	 'members:search:tags'  =>  "Etiquetes",
	 'members:title:searchname' => 'Cercar membres per %s',
	 'members:title:searchtag' => 'Membres amb etiquetes %s',
); 

add_translation('ca', $catalan); 