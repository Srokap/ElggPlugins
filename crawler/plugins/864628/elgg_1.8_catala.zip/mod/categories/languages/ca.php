<?php

// Generat per Openlife amb la col·laboració de translationbrowser 

$catalan = array( 
	 'categories'  =>  "Categories" , 
	 'categories:settings'  =>  "Edita les categories del lloc" , 
	 'categories:explanation'  =>  "Pot establir algunes categories globals per al lloc que s´utilitzaran a través del seu sistema. S´han d´introduir a sota separades per comes. Les eines compatibles les mostraran quan l´usuari crei o editi contingut." , 
	 'categories:save:success'  =>  "Les categories del lloc s´han desat correctament.",
	 'categories:results' => "Resultats del lloc per la categoria: %s",
	 'categories:on_activate_reminder' => "Les categories del lloc no estaran disponibles fins que no n´hi hagi d´afegides. <a href=\"%s\">Afegir categories ara.</a>",
); 

add_translation('ca', $catalan); 

?>