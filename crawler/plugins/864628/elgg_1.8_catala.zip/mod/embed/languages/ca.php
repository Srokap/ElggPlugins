<?php

$catalan = array(
	'embed:embed' =>
	 'Incrustar',
	'media:insert' => 'Afegir / Carregar arxiu',
	'embed:instructions' => 'Seleccioni l´arxiu que vol afegir al contingut. Només cal que  faci clic al damunt',
	'embed:media' => 'Afegir contingut',
	'embed:upload' => 'Carregar recurs',
	'embed:upload_type' => 'Tipus de càrrega: ',
	'upload:media' => 'Carregar arxiu',
	'embed:file:required' => 'No té instal·lada cap aplicació per carregar arxius. Posi´s en contacte en contacte amb l´administrador perquè habiliti el plugin.',
	
	'embed:no_upload_content' => 'No hi ha contingut de càrrega!',
	'embed:no_section_content' => 'No s´ha trobat cap element.',
	'embed:no_sections' => 'No s´ha trobat cap plugin suportat. Consulti l´administrador del lloc perquè habiliti un plugin amb suport per incrustar recursos.',
);
				
add_translation("ca",$catalan);
