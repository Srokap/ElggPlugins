<?php

	$catalan = array(
	
			'custom:bookmarks' => "Favorits més recents",
			'custom:groups' => "Grups més recents",
			'custom:files' => "Arxius pujats més recents",
			'custom:blogs' => "Entrades més recents",
			'custom:members' => "Membres nous de la xarxa",
			'custom:nofiles' => "Encara no hi ha cap arxiu",
			'custom:nogroups' => "Encara no hi ha cap grup",	
	
	);
					
	add_translation("ca",$catalan);

?>
