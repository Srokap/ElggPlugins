<?php
/**
 * Elgg Messageboard CSS view
 * 
 */
?>

.messageboard-input {
	height: 100px;
}
