<?php
/**
 * Deregister the ElggBlog class
 */

update_subtype('object', 'blog');
