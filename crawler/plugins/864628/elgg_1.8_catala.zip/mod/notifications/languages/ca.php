<?php

$catalan = array(

	'friends:all' =>
 'Tots els contactes',

	'notifications:subscriptions:personal:description' => 'Rebre notificacions quan es modifiquin els meus continguts',
	'notifications:subscriptions:personal:title' => 'Notificacions personals',

	'notifications:subscriptions:friends:title' => 'Contactes',
	'notifications:subscriptions:friends:description' => 'Aix&ograve; &eacute;s una col&middot;lecci&oacute; autom&agrave;tica dels seus contactes. Per rebre actualitzacions, seleccioni a sota. Aix&ograve; afectar&agrave; els usuaris que corresponguin amb el panell principal de notificacions al final de la p&agrave;gina',
'notifications:subscriptions:collections:edit' => 'Per habilitar notificacions compartides faci clic aqu&iacute;',

	'notifications:subscriptions:changesettings' => 'Notificacions',
	'notifications:subscriptions:changesettings:groups' => 'Notificacions de grups',
	'notification:method:email' => 'Correu',	

	'notifications:subscriptions:title' => 'Notificacions per usuari',
	'notifications:subscriptions:description' => 'Per rebre notificacions dels seus contactes quan crei nou contingut, cerqui&acute;ls a la xarxa i seleccioni el tipus de notificaci&oacute; que vol rebre',

	'notifications:subscriptions:groups:description' => 'Per rebre notificacions quan es crei un nou contingut en grups dels quals vost&egrave; n&acute;&eacute;s membre, cerqui&acute;ls a la xarxa i seleccioni el tipus de notificaci&oacute; que vol rebre',

	'notifications:subscriptions:success' => 'La seva configuraci&oacute; de notificacions ha quedat desada',

);

add_translation("ca", $catalan);