<?php

$catalan = array( 
	 'search:enter_term'  =>  "Introdueix un terme de recerca" , 
	 'search:no_results'  =>  "No hi ha resultats." , 
	 'search:matched'  =>  "Coincideixen:" , 
	 'search:results'  =>  "Resultats de %s" , 
	 'search:no_query'  =>  "Si us plau, instrodueixi una consulta." , 
	 'search:search_error'  =>  "Error" , 
	 'search:more'  =>  "+%s més %s" , 
	 'search_types:tags'  =>  "Etiquetes" , 
	 'search_types:comments'  =>  "Comentaris" , 
	 'search:comment_on'  =>  "Comentari de \"%s\"" , 
	 'search:comment_by' => 'per',
	 'search:unavailable_entity'  =>  "Entitat no disponible"
); 

add_translation('ca', $catalan); 
