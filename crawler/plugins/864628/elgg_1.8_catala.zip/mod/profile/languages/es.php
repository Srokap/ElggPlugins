<?php
/**
 * Elgg profile plugin language pack
 */

$spanish = array(
	'profile' => 'Perfil',
	'profile:notfound' => 'Lo sentimos. No se pudo encontrar el perfil solicitado.',

);

add_translation('es', $spanish);