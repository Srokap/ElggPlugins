<?php
/**
 * Elgg profile plugin language pack
 */

$english = array(
	'profile' => 'Profile',
	'profile:notfound' => 'Sorry. We could not find the requested profile.',

);

add_translation('en', $english);