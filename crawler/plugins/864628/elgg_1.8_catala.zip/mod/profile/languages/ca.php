<?php
/**
 * Elgg profile plugin language pack
 */

$catalan = array(
	'profile' =>
	 'Perfil',
	'profile:notfound' => 'Ens sap greu, no s&acute;ha pogut trobar el perfil sol&middot;licitat.',

);

add_translation('ca', $catalan);