<?php
/**
 * Elgg administration main screen
 *
 * @package Elgg
 * @subpackage Core
 * @author Curverider Ltd
 * @link http://elgg.org/
 */

// Description of what's going on
echo "<p>" . elgg_view('output/longtext', array('value' => elgg_echo("admin:description"))) . "</p>";
