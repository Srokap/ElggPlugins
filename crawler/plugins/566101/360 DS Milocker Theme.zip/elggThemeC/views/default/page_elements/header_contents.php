<?php

	/**
	 * Elgg header contents
	 * This file holds the header output that a user will see
	 * 
	 * @package Elgg
	 * @subpackage Core

	 * @author Curverider Ltd

	 * @link http://elgg.org/
	 **/
	 
?>
<?php $homeindex = "index.php";	
$currentpage = basename($_SERVER['PHP_SELF']);

	 if ((!isloggedin())&&($currentpage==$homeindex)) {		 

		 $textomovible="	<div id=\"base\"> Join Our Social Network! Talk to people, share photos, and more!<div id=\"jump_base\" class=\"news\" >
  <table class=\"news\" >
  <tr><td></td></tr>
    <tr>
    <td id=\"td1\"> </td></tr>
    <tr><td id = \"td2\" valign=\"middle\" align=\"center\"><a id=\"jump_link\"  target=\"_new\"></a></td></tr>
    <tr><td id=\"td3\"> </td></tr>
  </table>
</div></div>";
$topbody .= (!isset($CONFIG->disable_registration) || !($CONFIG->disable_registration)) ? "<div id=\"top\"><div id=\"top1\"><br/><a href=\"{$vars['url']}account/forgotten_password.php\">" . elgg_echo('user:password:lost') . "</a>&nbsp;&nbsp;&nbsp;&nbsp;" : "    " ;  
$topbody .=  "<input type=\"button\" class=\"regis\"onClick=\"location.href='{$vars['url']}account/register.php'\" value=\"".elgg_echo('register')."\"  /></div> ";
$topbody=$topbody.$textomovible."</div>";
echo $topbody ;

?>





<div id="page_container">

<div id="page_wrapper">

<?php

	 }
	 else
	 {
     if (isloggedin()) {

?>

		 
		 

<div id="page_container">
<div id="page_wrapper">

<div id="layout_header">
<div id="wrapper_header">
	<!-- display the page title -->
	<h1><a href="<?php echo $vars['url']; ?>"><?php echo $vars['config']->sitename; ?></a></h1>
</div><!-- /#wrapper_header -->
</div><!-- /#layout_header -->





<?php } else { ?>

<div id="page_container">
<div id="page_wrapper">

<div id="layout_header">
<div id="wrapper_header">
	<!-- display the page title -->
	<h1><a href="<?php echo $vars['url']; ?>"><?php echo $vars['config']->sitename; ?></a></h1>
</div><!-- /#wrapper_header -->
</div><!-- /#layout_header -->
<?php 
} 
}
?>