<?php
/**
 * Elgg basic about page
 * The standard HTML about page
 *
 * @package Elgg
 * @subpackage Core
 * @author Curverider Ltd
 * @link http://elgg.org/
 *
 */
?>

<!-- still to do -->