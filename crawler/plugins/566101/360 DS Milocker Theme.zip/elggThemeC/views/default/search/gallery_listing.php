<?php

	/**
	 * Elgg search listing: gallery view
	 * 
	 * @package Elgg
	 * @subpackage Core

	 * @author Curverider Ltd

	 * @link http://elgg.org/
	 */

?>

	<div class="search_listing">
	
		<div class="search_listing_header">
			
				<?php
	
					echo $vars['icon'];
				
				?>
			
		</div>
		<div class="search_listing_info">
			<?php

				echo $vars['info'];
			
			?>
		</div>		
	
	</div>