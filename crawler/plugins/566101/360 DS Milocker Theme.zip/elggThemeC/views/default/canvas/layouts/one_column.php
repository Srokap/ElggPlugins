<?php
/**
 * Elgg one-column layout
 *
 * @package Elgg
 * @subpackage Core
 * @author Curverider Ltd
 * @link http://elgg.org/
 */
?>

<!-- main content -->
<div id="one_column">

<?php echo $vars['area1']; ?>

</div><!-- /one_column -->