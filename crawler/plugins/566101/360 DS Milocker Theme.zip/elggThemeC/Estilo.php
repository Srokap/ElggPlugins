<?php header("Content-type: text/css"); 
$Ruta="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
$Ruta = str_replace("mod/elggThemeC/Estilo.php", "", $Ruta);
?>






html, body, div, span, applet, object, iframe,

h1, h2, h3, h4, h5, h6, p, blockquote, pre,

a, abbr, acronym, address, big, cite, code,

del, dfn, em, font, img, ins, kbd, q, s, samp,

small, strike, strong, sub, sup, tt, var,

dl, dt, dd, ol, ul, li,

fieldset, form, label, legend,

table, caption, tbody, tfoot, thead, tr, th, td {

	margin: 0;

	padding: 0;

	border: 0;

	outline: 0;

	font-weight: inherit;

	font-style: inherit;

	font-size: 100%;

	font-family: inherit;

	vertical-align: baseline;

}

body {padding:0; margin:0; background:#ffffff;

}
h1, h2, h3, h4, h5, h6{
	color:#FFF;
}
table {

	border-collapse: separate;

	border-spacing: 0;

}
#mails{
	visibility:hidden;
	position:absolute;
	z-index:1;
	background-color:#036;
	height:300px;
	width:250px;
}

#base{

	width: 100%;

	

	text-align:left;

	background:url(<?php echo $Ruta; ?>mod/elggThemeC/_graphics/indexpic/ri2.png)repeat-x bottom right;

	background-image:url(<?php echo $Ruta; ?>mod/elggThemeC/_graphics/indexpic/ri2.png);

	background-position:bottom;

	padding-left:0px;

	

	

}

#jump_base {

  overflow-y:hidden;

  width: 100%;

  height: 30px;

  padding-top:2px;

  /*border: 2px dotted #000099;*/

  font: 120% Helvetica, Arial, sans-serif;

			font-weight: bold;

 

}



#jump_base a {

	font: 120% Helvetica, Arial, sans-serif;

  /*color: #000099;*/

  /*background:#FFFFFF;*/

  /*color:#555;font-size:.9em;font-weight:normal;*/

  color:#999;font-size:.875em;font-style:normal;

  margin-top:3em;margin-bottom:3em;overflow:hidden;transition:height .5s ease;-webkit-transition:height .5s ease;

  color:#555;

}



.news {

	font: 100% Helvetica, Arial, sans-serif;

	font-weight: bold;

	



 /* background:#FFFFFF;*/

  /*color: inherit;*/

}


#full
{
	visibility:hidden;
	background-image:url(<?php echo $Ruta; ?>mod/elggThemeC/_graphics/indexpic/blackback.png);
	height:100%;
	width:100%;
	position:absolute;
	text-align:center;
	
	z-index:2;
	
	
}

#cen
{
	background-image:url(<?php echo $Ruta; ?>mod/elggThemeC/_graphics/indexpic/bgGreen.png);
	position:relative;
	height:400px;
	width:600px;
	padding-left:50px;
	text-align:left;
	margin-left:auto;
	margin-right:auto;
	margin-top:100px;
 border-radius: 10px;
 -ms-border-radius: 10px;  
-moz-border-radius: 10px;  
 -webkit-border-radius: 10px;  
 -khtml-border-radius: 10px;  

}
#clearfloat
{
	position:absolute;
	background:#036;
	height:25px;
	height:100%;
	
}
#flo
{
	position:relative;
	vertical-align:text-bottom;
	 margin-left: auto ;
	 margin-top:50px;

  margin-right: auto ;
	
}


#allindex 

{

	
	overflow:hidden;

	margin:0;

	padding:0;

	position:relative;

	 top: 25px;

	 text-align:center;

	 width:800px;

	  margin-left: auto ;

  margin-right: auto ;

	background:#036 url(<?php echo $Ruta; ?>mod/elggThemeC/_graphics/indexpic/left.png)repeat-x bottom right;

	border-radius: 10px;  
 -ms-border-radius: 10px;  
-moz-border-radius: 10px;  
 -webkit-border-radius: 10px;  
 -khtml-border-radius: 10px;  



	}

	#top{

		font: 100% Arial, Helvetica, sans-serif;

			font-weight: bold;

			text-decoration: none;

		

		width:100%;

		height:105px;

		text-align:right;

		

		

	}

	#top1{

		font: 100% Arial, Helvetica, sans-serif;

			font-weight: bold;

			text-decoration: none;

			margin:0px auto;

		width:100%;

		text-align:right;

		height:70px;

		background:#F3F3F3 url(<?php echo $Ruta; ?>mod/elggThemeC/_graphics/indexpic/ri.png)repeat-x bottom right;

		background-image:url(<?php echo $Ruta; ?>mod/elggThemeC/_graphics/indexpic/ri.png);

		

		

	}

	#page_wrapper{

		text-align:center;

		width:100%;

	}

	#page_container{

		text-align:center;

		width:100%;

	

	}

	a:link { 

color:#FE8618;

	}



	#topindex 

{margin:0;

	padding:0;

	position:absolute;

	z-index:2;

	 top: 95px;

	 width:800px;

	 height:300px;

	   margin-left: auto;

       margin-right: auto;

       left: 0;

       right: 0;

	background: url(<?php echo $Ruta; ?>mod/elggThemeC/_graphics/indexpic/top.png) no-repeat 0 0;

	

	}

	#activo{

		font: 100% Arial, Helvetica, sans-serif;

		font-weight: bold;

		overflow-y:hidden;

		background:#003 url(<?php echo $Ruta; ?>mod/elggThemeC/_graphics/indexpic/bgGreen.png);

		text-align:left;

		

	

		color:#DBDEDA;

		width:800px;

		height:110px;

		-webkit-border-bottom-left-radius:10px;

	-webkit-border-bottom-right-radius:10px;

	-moz-border-radius-bottomleft:10px;

	-moz-border-radius-bottomright:10px;

	border-bottom-left-radius:10px;

	border-bottom-right-radius:10px;

		

	}

	

	#fot{

		overflow-y:hidden;

		width:800px;

		height:300px;

		padding:0px;

		background:#1F7FA7;

		}

	#log{

		padding-left:40px;

		vertical-align:middle;

		

				

	

	}
	input.xclose

	{
		background:url(<?php echo $Ruta; ?>mod/elggThemeC/_graphics/indexpic/close.png) no-repeat left top;
		width:30px;

	height: 30px;
	
	border: 0;
		
	
	
		-moz-border-radius-topleft:0px;

	-moz-border-radius-topright:0px; 

	-webkit-border-top-right-radius:0px;

	-webkit-border-top-left-radius:0px;
	border-top-left-radius:0px;

	border-top-right-radius:0px;
	
	}

	input.regis

	{

		font: 100% Arial, Helvetica, sans-serif;

	font-weight: bold;

	color: #ffffff;

	border: 0px solid #98CF00;

	-webkit-border-radius: 4px; 

	-moz-border-radius: 4px;
	vertical-align:text-top;

	width: 237px;

	height: 30px;

	background:url(<?php echo $Ruta; ?>mod/elggThemeC/_graphics/indexpic/boton.png) no-repeat left top;

	cursor: pointer;

	}
	input.regis:hover
	{
		width: 237px;

	height: 30px;

	background:url(<?php echo $Ruta; ?>mod/elggThemeC/_graphics/indexpic/boton.png) no-repeat left -30px;

	}



/* ***************************************

	RESET BASE STYLES

*************************************** */



/* remember to define focus styles! */

:focus {

	outline: 0;

}

ol, ul {

	list-style: none;

}

em, i {

	font-style:italic;

}

/* tables still need cellspacing="0" (for ie6) */

table {

	

	border-spacing: 0;

	vertical-align: top;

}



caption, th, td {

	text-align: left;

	font-weight: normal;

	vertical-align: top;

}

blockquote:before, blockquote:after,

q:before, q:after {

	content: "";

}

blockquote, q {

	quotes: "" "";

}

.clearfloat { 

	clear:both;

    height:0;

    font-size: 1px;

    line-height: 0px;

}







/* ***************************************

  SYSTEM MESSSAGES

*************************************** */

.messages {

    background:#ccffcc;

    color:#000000;

    padding:3px 10px 3px 10px;

    z-index: 8000;

	margin:0;

	position:fixed;

	top:30px;

	width:969px;

	-webkit-border-radius: 4px; 

	-moz-border-radius: 4px;

	border:4px solid #00CC00;

	cursor: pointer;

}

.messages_error {

    border:4px solid #D3322A;

    background:#F7DAD8;

    color:#000000;

    padding:3px 10px 3px 10px;

    z-index: 8000;

	margin:0;

	position:fixed;

	top:30px;

	width:969px;

	-webkit-border-radius: 4px; 

	-moz-border-radius: 4px;

	cursor: pointer;

}

.closeMessages {

	float:right;

	margin-top:17px;

}

.closeMessages a {

	color:#666666;

	cursor: pointer;

	text-decoration: none;

	font-size: 80%;

}

.closeMessages a:hover {

	color:black;

}







/* ***************************************

	GENERAL FORM ELEMENTS

*************************************** */

label {

	font-weight: bold;

	color:#FF8A00;

	font-size: 100%;

	padding: 0px;

	vertical-align:top;

	

}

input {

	font: 100% Arial, Helvetica, sans-serif;

	padding: 6px;

	border: 1px;

	

	color:#003;

	-webkit-border-radius: 5px; 

	-moz-border-radius: 5px;

	vertical-align:top;



	

}

input-checkbox{

	padding: 0px;

}

textarea {

	background:#FFF;

	font: 100% Arial, Helvetica, sans-serif;

	border: solid 1px #196280;

	padding: 5px;

	color:#003;

	-webkit-border-radius: 5px; 

	-moz-border-radius: 5px;

}

textarea:focus, input[type="text"]:focus {

	background:#FFF;

	

	/*background: #e4ecf5;*/

	color:#003;

}

.submit_button {

	font: 100% Arial, Helvetica, sans-serif;

	font-weight: bold;

	color: #ffffff;

	background:#98CF00;

	border: 1px solid #4690d6;

	-webkit-border-radius: 5px; 

	-moz-border-radius: 5px;

	width: 120px;

	height: 31px;

	padding: 0px 0px 0px 0px;

	margin:0px 0 0px 0;

	cursor: pointer;

	vertical-align:top;

	

}



input[type="submit"] {

	font: 100% Arial, Helvetica, sans-serif;

	font-weight: bold;

	color: #ffffff;

	border: 1px solid #98CF00;

	-webkit-border-radius: 5px; 

	-moz-border-radius: 5px;

	width: 120px;

	height: 31px;

	background:#98CF00 url(<?php echo $Ruta; ?>mod/elggThemeC/_graphics/indexpic/buttonindex.png) repeat-x 0 0;

	vertical-align:top;

	

	cursor: pointer;

}

.submit_button:hover, input[type="submit"]:hover {

	background: #89D612;

	border-color: #98CF00;

}



.cancel_button {

	font: 12px/100% Arial, Helvetica, sans-serif;

	font-weight: bold;

	color: #999999;

	background:#dddddd;

	border: 1px solid #999999;

	-webkit-border-radius: 4px; 

	-moz-border-radius: 4px;

	width: auto;

	height: 25px;

	/*padding: 2px 6px 2px 6px;

	margin:10px 0 10px 10px;*/

	cursor: pointer;

}

.cancel_button:hover {

	background: #cccccc;

}



.input-text,

.input-tags,

.input-url,

.input-textarea {

	width:98%;

}



.input-textarea {

	height: 100px;

}





/*//////////////////////////////////////////////////////////////////////////*/







/* ***************************************

	DEFAULTS

*************************************** */



/* elgg open source		blue 			#4690d6 */

/* elgg open source		dark blue 		#0054a7 */

/* elgg open source		light yellow 	#FDFFC3 */

/* elgg open source		light blue	 	#bbdaf7 */





a {

	color: #4690d6;

	text-decoration: none;

	-moz-outline-style: none;

	outline: none;

}

a:visited {

	

}

a:hover {

	color: #0054a7;

	text-decoration: underline;

}

p {

	margin: 0px 0px 15px 0;

}

img {

	border: none;

}

ul {

	margin: 5px 0px 15px;

	padding-left: 20px;

}

ul li {

	margin: 0px;

}

ol {

	margin: 5px 0px 15px;

	padding-left: 20px;

}

ul li {

	margin: 0px;

}

form {

	margin: 0px;

	padding: 0px;

}

small {

	font-size: 90%;

}

h1, h2, h3, h4, h5, h6 {

	font-weight: bold;

	line-height: normal;

}

h1 { font-size: 1.8em; }

h2 { font-size: 1.5em; }

h3 { font-size: 1.2em; }

h4 { font-size: 1.0em; }

h5 { font-size: 0.9em; }

h6 { font-size: 0.8em; }



dt {

	margin: 0;

	padding: 0;

	font-weight: bold;

}

dd {

	margin: 0 0 1em 1em;

	padding: 0;

}

pre, code {

	font-family:Monaco,"Courier New",Courier,monospace;

	font-size:12px;

	background:#EBF5FF;

	overflow:auto;

	

	overflow-x: auto; /* Use horizontal scroller if needed; for Firefox 2, not needed in Firefox 3 */

	white-space: pre-wrap; /* css-3 */

	white-space: -moz-pre-wrap !important; /* Mozilla, since 1999 */

	white-space: -pre-wrap; /* Opera 4-6 */

	white-space: -o-pre-wrap; /* Opera 7 */

	word-wrap: break-word; /* Internet Explorer 5.5+ */

	

}

code {

	padding:2px 3px;

}

pre {

	padding:3px 15px;

	margin:0px 0 15px 0;

	line-height:1.3em;

}

blockquote {

	padding:3px 15px;

	margin:0px 0 15px 0;

	line-height:1.3em;

	background:#EBF5FF;

	border:none !important;

	-webkit-border-radius: 5px; 

	-moz-border-radius: 5px;

}

blockquote p {

	margin:0 0 5px 0;

}

.collapsable_box {

	margin: 0 0 20px 0;

	height:auto;



}

/* IE6 fix */

* html .collapsable_box  { 

	height:10px;

}

.collapsable_box_header {

	color: #4690d6;

	padding: 5px 10px 5px 10px;

	margin:0;

	border-left: 1px solid white;

	border-right: 1px solid #cccccc;

	border-bottom: 1px solid #cccccc;

	-moz-border-radius-topleft:8px;

	-moz-border-radius-topright:8px; 

	-webkit-border-top-right-radius:8px;

	-webkit-border-top-left-radius:8px;

	background:#dedede;

}

.collapsable_box_header h1 {

	color: #0054a7;

	font-size:1.25em;

	line-height: 1.2em;

}

.collapsable_box_content {

	padding: 10px 0 10px 0;

	margin:0;

	height:auto;

	background:#dedede;

	-moz-border-radius-bottomleft:8px;

	-moz-border-radius-bottomright:8px;

	-webkit-border-bottom-right-radius:8px;

	-webkit-border-bottom-left-radius:8px;

	border-left: 1px solid white;

	border-right: 1px solid #cccccc;

	border-bottom: 1px solid #cccccc;

}

.collapsable_box_content .contentWrapper {

	margin-bottom:5px;

}

.collapsable_box_editpanel {

	display: none;

	background: #a8a8a8;

	padding:10px 10px 5px 10px;

	border-left: 1px solid white;

	border-bottom: 1px solid white;

}

.collapsable_box_editpanel p {

	margin:0 0 5px 0;

}

.collapsable_box_header a.toggle_box_contents {

	color: #4690d6;

	cursor:pointer;

	font-family: Arial, Helvetica, sans-serif;

	font-size:20px;

	font-weight: bold;

	text-decoration:none;

	float:right;

	margin: 0;

	margin-top: -7px;

}

.collapsable_box_header a.toggle_box_edit_panel {

	color: #4690d6;

	cursor:pointer;

	font-size:9px;

	text-transform: uppercase;

	text-decoration:none;

	font-weight: normal;

	float:right;

	margin: 3px 10px 0 0;

}

.collapsable_box_editpanel label {

	font-weight: normal;

	font-size: 100%;

}

/* used for collapsing a content box */

.display_none {

	display:none;

}

/* used on spotlight box - to cancel default box margin */

.no_space_after {

	margin: 0 0 0 0;

}



#persistent_login{

	font-size:1.0em;

	font-weight: normal;

}



#persistent_login input [type="checkbox"] {

background:#FFF;

color:#066;

border:none;

font-size:16px;



} 




