<?php

	/* Milocker.com SK Free Theme */
	
	
	/* Initialise the theme */
	function elggThemeC_init(){
		register_plugin_hook('index','system','new_index');

	}
	function new_index() {
	if (!@include_once(dirname(__FILE__) . "/index.php")) return false;
			return true;
	}

	// Initialise log browser dirname(dirname(__FILE__))) .
	register_elgg_event_handler('init','system','elggThemeC_init');
	
?>