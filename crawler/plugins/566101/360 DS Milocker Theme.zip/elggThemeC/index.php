<?php

	/**
	 * Elgg index page for web-based applications
	 * 
	 * @package Elgg
	 * @subpackage Core

	 * @author Curverider Ltd

	 * @link http://elgg.org/
	 */

	/**
	 * Start the Elgg engine
	 */
		define('externalpage',true);
		//require_once(dirname(__FILE__) . "/engine/start.php");
		require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
		
		//if (!trigger_plugin_hook('index','system',null,false)) {
	
			/**
		      * Check to see if user is logged in, if not display login form
		      **/
				
				if (isloggedin()) forward('pg/dashboard/');
			
	        //Load the front page
	        	global $CONFIG;
	        	


 header("Content-type: text/css"); 
$Ruta="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
$Ruta = str_replace("index.php", "", $Ruta);
$Ruta =$Ruta."mod/elggThemeC/";

	// Otherwise, forward to the index page
		
				$con ="<div id=\"allindex\"><div id=\"fot\"><img id=\"Fotos1\" border=0 src=\"". $Ruta."_graphics/indexpic/1.jpg\" /></div><div id=\"activo\"><div id=\"log\">".elgg_view("account/forms/login")."</div></div></div>";

global $autofeed;
		        $autofeed = false;
		        page_draw(null, $con);
		
//}
//$cpde="<script language=\"JavaScript\">
/*Run();</script>";*/
?>

