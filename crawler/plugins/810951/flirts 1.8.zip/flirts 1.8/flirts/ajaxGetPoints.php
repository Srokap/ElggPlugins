<?php
	// Get the required points for an flirt
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	
	global $CONFIG;
	
	$FlirtID = get_input('id');
	
	$points = get_plugin_setting('flirtpoints_'.$FlirtID, 'flirts');
	
	if($points == "") {
		echo 0;
	} else {
		echo $points;
	}
?>