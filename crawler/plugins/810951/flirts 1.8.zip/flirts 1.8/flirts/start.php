<?php
    /**
     * Elgg Gifts plugin
     * Send gifts to you friends
     *
     * @package Gifts
     * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
     * @author Christian Heckelmann
     * @copyright Christian Heckelmann
     * @link http://www.heckelmann.info
     */

    global $CONFIG;

    /*
     * Initialize Plugin
     */
    function flirts_init() {
      global $CONFIG;

      // Set Plugin Version for Update Checks
      set_plugin_setting('version', '1.0', 'flirts');

      register_translations($CONFIG->pluginspath . "flirts/languages/");
      // Show in Menu
      if (isloggedin()) {
        add_menu(elgg_echo('flirts:menu'), $CONFIG->wwwroot."flirts/" . $_SESSION['user']->username . "/index");
      }

      // hide menu in admin area
      if (get_context() != 'admin') {
	if (get_context() == "flirts") {
	  add_submenu_item(elgg_echo('flirts:yourflirts'),$CONFIG->wwwroot."flirts/" . $_SESSION['user']->username . "/index");

	  // Show all flirts?
	  if(get_plugin_setting('showallflirts', 'flirts') == 1) {
	    add_submenu_item(elgg_echo('flirts:allflirts'),$CONFIG->wwwroot."flirts/" . $_SESSION['user']->username . "/all");
	  }

	  add_submenu_item(elgg_echo('flirts:sent'),$CONFIG->wwwroot."flirts/" . $_SESSION['user']->username . "/sent");
	  add_submenu_item(elgg_echo('flirts:sendflirts'),$CONFIG->wwwroot."flirts/" . $_SESSION['user']->username . "/sendflirt");
        }
      }

      // Add Widget
      add_widget_type('flirts',elgg_echo("flirts:widget"),elgg_echo("flirts:widget:description"));

      register_page_handler('flirts','flirts_page_handler');
      register_entity_url_handler('flirts_url','object','flirts');
      elgg_extend_view('profile/menu/links','flirts/menu');
      elgg_extend_view('css','flirts/css');
    }

    function flirts() {
      if (!@include_once(dirname(dirname(__FILE__))) . "/flirts/index.php") return false;
      return true;
    }

    /*
     * Page Handler
     */
    function flirts_page_handler($page) {
      if (isset($page[0])) {
	set_input('username',$page[0]);
      }

      if (isset($page[1])) {
	switch($page[1]) {
	  case "read":  set_input('guid',$page[2]);
			@include(dirname(dirname(dirname(__FILE__))) . "/index.php"); return true;
			break;
	  case "index":	@include(dirname(__FILE__) . "/index.php"); return true;
			break;
	  case "sent":	@include(dirname(__FILE__) . "/sent.php"); return true;
			break;
	  case "sendflirt": @include(dirname(__FILE__) . "/sendflirt.php"); return true;
			   break;
	  case "all": @include(dirname(__FILE__) . "/all.php"); return true;
		      break;
	}
      } else {
	@include(dirname(__FILE__) . "/index.php");
	return true;
      }

      return false;
    }

    /*
     * URL Handler
     */
    function flirts_url($entity) {
      global $CONFIG;
      $title = $entity->title;
      $title = friendly_title($title);
      return $CONFIG->url . "flirts/" . $entity->getOwnerEntity()->username . "/read/".$entity->getGUID();
    }

    /*
     * Create Admin Menu
     */
    function flirts_adminmenu() {
      global $CONFIG;
      if (get_context() == 'admin' && isadminloggedin()) {
	add_submenu_item(elgg_echo('flirts:settings:title'), $CONFIG->url . "mod/flirts/admin.php");
      }
    }

    register_elgg_event_handler('init','system','flirts_init');
    register_elgg_event_handler('pagesetup','system','flirts_adminmenu');
    register_action("flirts/settings", false, $CONFIG->pluginspath . "flirts/actions/savesettings.php");
    register_action("flirts/saveflirts", false, $CONFIG->pluginspath . "flirts/actions/saveflirts.php");
    register_action("flirts/sendflirt", false, $CONFIG->pluginspath . "flirts/actions/send.php");

?>