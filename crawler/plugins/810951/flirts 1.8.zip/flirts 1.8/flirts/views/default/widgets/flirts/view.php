<?php

    /**
     * Gifts profile widget - this displays a users gifts on their profile
      **/

    //the number of flirts to display
    $number = (int) $vars['entity']->num_display;
    if (!$number)
	$number = 4;

    //the page owner
    $owner = $vars['entity']->owner_guid;

    $oflirts = elgg_get_entities(array('types' => 'object', 'subtypes' => 'flirt', 'owner_guid' => 0, 'limit' => 999));

    $i=0;
    foreach($oflirts as $flirt) {
        if($flirt->receiver == $owner) {
                $i++;
                if($i == $number) break;
                // Select Receiver and Sender
                $sender = get_entity($flirt->owner_guid);
                $receiver = get_entity($flirt->receiver);

                $flirttext = get_plugin_setting('flirt_'.$flirt->flirt_id, 'flirts');
                $imagefile = "flirt_".$flirt->flirt_id."_tiny.jpg";
                $imgfile =  dirname(dirname(dirname(dirname(dirname(__FILE__)))))."/images/".$imagefile;

                $Url = $flirt->getURL();

                echo "<div class=\"flirts_widget_wrapper\">";
                echo "<a href=\"$Url\">";
                if (file_exists($imgfile)) {
                    echo "<div class=\"flirts_widget_icon\"><img src=\"".$vars['url'].'mod/flirts/images/'.$imagefile."\" /></div>";
                } else {
                    echo "<div class=\"flirts_widget_icon\"><img src=\"".$vars['url']."mod/flirts/images/noimage.jpg\" /></div>";
                }
		echo "</a>";
		echo "<div class=\"flirts_widget_content\">";
		echo sprintf(elgg_echo("flirts:object"), $sender->name, $flirttext, $receiver->name);
		echo "</div>";
		echo "</div>";
        }
    }

?>