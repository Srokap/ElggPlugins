<?php
	/**
	 * Elgg Gifts plugin
	 * Send gifts to you friends
	 * 
	 * @package Gifts
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Christian Heckelmann
	 * @copyright Christian Heckelmann
	 * @link http://www.heckelmann.info
	 */

	// THANK YOU DDFUSION
	// Added Fix from DDFusion
	
    $performed_by = get_entity($vars['item']->subject_guid);
	$performed_on = get_entity($vars['item']->object_guid);
	$object = get_entity($vars['item']->object_guid);
	
	$person_link = "<a href=\"{$performed_by->getURL()}\">{$performed_by->name}</a>";
	$object_link = "<a href=\"{$performed_on->getURL()}\">{$performed_on->name}</a>";
	$flirt = "<a href=\"{$vars['url']}flirts/{$_SESSION['user']->username}/index\">".elgg_echo("flirts:flirt")."</a>";
	
	$string = sprintf(elgg_echo("flirts:river"), $person_link, $flirt)  . $object_link;    
	
    echo $string; 


?>
