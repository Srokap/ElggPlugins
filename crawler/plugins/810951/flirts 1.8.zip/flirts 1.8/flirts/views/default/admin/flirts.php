<?php
	/**
	 * Elgg Gifts plugin
	 * Send gifts to you friends
	 * 
	 * @package Gifts
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Christian Heckelmann
	 * @copyright Christian Heckelmann
	 * @link http://www.heckelmann.info
	 */

	global $CONFIG;
	
	$tab = $vars['tab'];
	$user_guid = $vars['user_guid'];
	
	$settingsselect = ''; 
	$statsselect = '';
	switch($tab) {
		case 'globalsettings':
			$listglobal = 'class="selected"';
			break;
		case 'flirtsettings':
			$listflirts = 'class="selected"';
			break;
	}
	
?>
<div class="contentWrapper">
	<div id="elgg_horizontal_tabbed_nav">
		<ul>
			<li <?php echo $listglobal; ?>><a href="<?php echo $CONFIG->wwwroot . 'mod/flirts/admin.php?tab=globalsettings'; ?>"><?php echo elgg_echo('flirts:settings:globalsettings'); ?></a></li>
			<li <?php echo $listflirts; ?>><a href="<?php echo $CONFIG->wwwroot . 'mod/flirts/admin.php?tab=flirtsettings'; ?>"><?php echo elgg_echo('flirts:settings:flirtsettings'); ?></a></li>			
		</ul>
	</div>
<?php
	switch($tab) {
		case 'globalsettings':
			echo elgg_view("flirts/globalsettings");
			break;
		case 'flirtsettings':
			echo elgg_view("flirts/flirtsettings");
			break;
	}
?>
</div>
