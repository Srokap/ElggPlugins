<?php

	//Load Plugin Settings
	$plugin = find_plugin_settings('flirts');

	$showallflirts	= $plugin->showallflirts;
	$useuserpoints  = $plugin->useuserpoints;
	$flirtcount	= $plugin->flirtcount;

        $ts = time();
        $token = generate_action_token($ts);
        $security = "?__elgg_token=$token&__elgg_ts=$ts";
	$action = $vars['url'] . 'action/flirts/settings' . $security;

	$form = "<p>".elgg_echo('flirts:settings:showallflirts');
	$form .= '<br/><select name="params[showallflirts]">';
	$form .=  "<option value=1";

	if ($showallflirts == 1) $form .= " selected=\"yes\" ";

	$form .= ">".elgg_echo('flirts:settings:showallyes')."</option>";
	$form .=  "<option value=0";

	if ($showallflirts == 0) $form .= " selected=\"no\" ";

	$form .= ">".elgg_echo('flirts:settings:showallno')."</option>";
	$form .= "</select><br/>\n\r";

	// Userpoints
	// Check if Userpoint Api is enabled
	if (is_plugin_enabled('elggx_userpoints')) {
		$form .= elgg_echo('flirts:settings:useuserpoints');
		$form .= '<br/><select name="params[useuserpoints]">';
		$form .=  "<option value=1";

		if ($useuserpoints == 1) $form .= " selected=\"yes\" ";

		$form .= ">".elgg_echo('flirts:settings:showallyes')."</option>";
		$form .=  "<option value=0";

		if ($useuserpoints == 0) $form .= " selected=\"no\" ";

		$form .= ">".elgg_echo('flirts:settings:showallno')."</option>";
		$form .= "</select><br/>\n\r";
	}

	$form .= elgg_echo('flirts:settings:number');
	$form .= "<br/><select name=\"params[flirtcount]\">";
    for ($i=0;$i<99;$i++)
    {
    	$form .= "<option value=\"".$i."\"";
    	if($flirtcount == $i) {
    		$form .= " selected=\"yes\" ";
    	}
    	$form .= ">".$i."</option>\n\r";
    }
    $form .= "</select>";
    $form .= "<br><br>".elgg_view('input/submit', array('value' => elgg_echo("save")));
    $form .= "</p>";
    echo elgg_view('input/form', array('action' => $action, 'body' => $form));

/*
    $flirt_count = $flirtcount;
        for ($i=1;$i<=$flirt_count;$i++)
        {
            echo elgg_echo('flirts:settings:title')." #$i";
            echo elgg_view('input/text',array('internalname'=>'params[flirt_'.$i.']','value'=>get_plugin_setting('flirt_'.$i, 'flirts')));
        }*/
?>
<?php

	//Load Plugin Settings
	$plugin = find_plugin_settings('flirts');

	$showallflirts	= $plugin->showallflirts;
	$useuserpoints  = $plugin->useuserpoints;
	$flirtcount	= $plugin->flirtcount;

        $ts = time();
        $token = generate_action_token($ts);
        $security = "?__elgg_token=$token&__elgg_ts=$ts";
	$action = $vars['url'] . 'action/flirts/saveflirts' . $security;

	if($useuserpoints == 1 && function_exists('userpoints_get')) {
		$pTemp = userpoints_get(get_loggedin_userid());
		$points = $pTemp['approved'];
	}

	$form = "<input type=\"hidden\" name=\"flirtcount\" value=\"$flirtcount\" />";
        $flirt_count = $flirtcount;
        for ($i=1;$i<=$flirt_count;$i++) {
            $form .= "<h2>".elgg_echo('flirts:settings:title')." #$i</h2>";
            $form .= elgg_view('input/text',array('internalname'=>'params[flirt_'.$i.']','value'=>get_plugin_setting('flirt_'.$i, 'flirts')));

            if ($useuserpoints == 1) {
                $form .= elgg_echo('flirts:settings:userpoints')." #$i";
                $form .= elgg_view('input/text',array('internalname'=>'params[flirtpoints_'.$i.']','value'=>get_plugin_setting('flirtpoints_'.$i, 'flirts')));
                if (function_exists('userpoints_delete')) {}
                //$form .= elgg_echo('flirts:settings:code')." #$i";
                //$form .= elgg_view('input/longtext',array('internalname'=>'params[flirtcode_'.$i.']','value'=>get_plugin_setting('flirtcode_'.$i, 'flirts')));
            }

            //elgg_view("input/file",array('internalname' => 'icon'))
            $form .= elgg_echo('flirts:settings:image')." #$i<br/>";
            $form .= elgg_view('input/file',array('internalname'=>'flirtimage_'.$i));

            // Show Image if already uploaded
            $imgfile = dirname(dirname(dirname(dirname(__FILE__))))."/images/flirt_".$i.".jpg";
            //$form .= $imgfile;
            if (file_exists($imgfile)) {
                $form .= '<img src="'.$vars['url'].'mod/flirts/images/flirt_'.$i.'_medium.jpg" /><br/>';
            }

        }

    $form .= "<br><br>".elgg_view('input/submit', array('value' => elgg_echo("save")));
    $form .= "</p>";
    echo elgg_view('input/form', array('action' => $action, 'enctype'=>"multipart/form-data"  ,'body' => $form));

?>