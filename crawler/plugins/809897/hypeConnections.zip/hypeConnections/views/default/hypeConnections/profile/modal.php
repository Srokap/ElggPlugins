<?php
echo elgg_view('hypeConnections/js/add');
?>
<div id="modalWrapper">
    <div id="modalContent"></div>
</div>
