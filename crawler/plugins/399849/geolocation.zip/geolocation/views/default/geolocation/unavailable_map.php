<?php
	/**
	* Geolocation Module
	* 
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2009-2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/
?>
	<p>
		<?php
			$link_option = "<a href='#'>#</a>";
			echo sprintf(elgg_echo('geolocation:messages:unavaiblaemap'),$link_option); 
		?>
	</p>