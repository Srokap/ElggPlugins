<?php
/*******************************************************************************
 * Registration_Control
 *
 * @author WebGalli
 * @author Leo de Carvalho
 * @author Jeroen Dalsem
 * @author Evan Winslow 
 * @author Trajan
 ******************************************************************************/

require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
global $CONFIG;

//value got from the get metho
$username = get_input('username');
//checking weather user exists or not in $existing_users array
$user = get_user_by_username($username);

if ($user)
{
	//user name is not availble
	echo 'no';
}
else if (strlen($username) < 4)
{
        echo 'error';
}
else
{
	//user name is available
	echo 'yes';
}
?>