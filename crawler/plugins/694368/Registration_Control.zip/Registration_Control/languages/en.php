<?php
/*******************************************************************************
 * Registration_Control
 *
 * @author WebGalli
 * @author Leo de Carvalho
 * @author Jeroen Dalsem
 * @author Evan Winslow 
 * @author Trajan
 ******************************************************************************/

$english = array(
                'Registration_Control:usernameChecker:message:available' => 'Username available to register',
                'Registration_Control:usernameChecker:message:exists' => 'This username already exists',
                'Registration_Control:usernameChecker:message:minChar' => 'Username must be at least 4 characters',
                'Registration_Control:usernameChecker:activate' => "Activate the username checker?",
                
                'Registration_Control:emailChecker:message:available' => 'Email available to register',
                'Registration_Control:emailChecker:message:exists' => 'This email address has already been registered',
                'Registration_Control:emailChecker:message:error' => 'This email is not valid',
                'Registration_Control:emailChecker:activate' => "Activate the email checker?",
                
                'Registration_Control:passwordchecker:message:veryweak' => 'Weak',
                'Registration_Control:passwordchecker:message:weak' => 'Very Weak',
                'Registration_Control:passwordchecker:message:medium' => 'Medium',
                'Registration_Control:passwordchecker:message:strong' => 'Strong',
                'Registration_Control:passwordchecker:message:verystrong' => 'Very Strong',
                'Registration_Control:passwordchecker:message:minchar' => 'Minimum number of characters is ',
                'Registration_Control:passwordchecker:activate' => "Activate the password checker?",
                
                'Registration_Control:terms:activate' => "Activate the registration terms check?",
                'Registration_Control:agreetoterms' => "I have read and agree to the",
				'Registration_Control:terms' => 'Terms',
				'Registration_Control:agreetoterms:required' => "You must first agree to the terms",
				
				'Registration_Control:addbox:activate' => "Add a box to the right of the register form?",
				'Registration_Control:addbox:title' => "    Get Involved Today!",
				'addbox:chat' => "Communicate with other management staff on projects to make sure everyone is on the same page and UKEC is 100% successful.",
				'addbox:contacts' => "Get access to a completely up-to-date external contacts list and help keep it up-to-date yourself.",
				'addbox:documents' => "Share company documents to make everyone's life easier. No need to reinvent the wheel everyday!",
				
				'Registration_Control:icon:activate' => "Activate profile icon on registration form?",
				'Registration_Control:register:profile_icon' => 'This site requires you to upload a profile icon',
				
				'Registration_Control:disable:activate' => "Disable Registration for visitors?",
				'register:disabled' => "Sorry, we are not currently allowing registration.",
				
				'Registration_Control:join:groups' => "Force new user to join a group on registration (if yes new option appears below)",
				'autosubscribe' => 'Auto-subscription to group',
				'Registration_Control:joingroups:list' => "Groups' ids (separated by commas)",
				'Registration_Control:joingroups:list' => "<em>Get the id from the urls of the groups you want to select.</em><br><strong>url:</strong>yoursite.com/pg/groups/<strong>56</strong>/group-name<br>Separate by a comma",

);

add_translation("en",$english);
?>