<?php
/*******************************************************************************
 * Registration_Control
 *
 * @author WebGalli
 * @author Leo de Carvalho
 * @author Jeroen Dalsem
 * @author Evan Winslow 
 * @author Trajan
 ******************************************************************************/

$chinese = array(
                'Registration_Control:usernameChecker:message:available' => '行',
                'Registration_Control:usernameChecker:message:exists' => '该用户名已存在',
                'Registration_Control:usernameChecker:message:minChar' => '用户名不能少于四个字',
                'Registration_Control:usernameChecker:activate' => "Activate the username checker?",
                
                'Registration_Control:emailChecker:message:available' => '行',
                'Registration_Control:emailChecker:message:exists' => '该用户名已被注册',
                'Registration_Control:emailChecker:message:error' => '邮件无效',
                'Registration_Control:emailChecker:activate' => "Activate the email checker?",
                
                'Registration_Control:passwordchecker:message:veryweak' => '低',
                'Registration_Control:passwordchecker:message:weak' => '很低',
                'Registration_Control:passwordchecker:message:medium' => '中等',
                'Registration_Control:passwordchecker:message:strong' => '高',
                'Registration_Control:passwordchecker:message:verystrong' => '很高',
                'Registration_Control:passwordchecker:message:minchar' => '最少字数为： ',
                'Registration_Control:passwordchecker:activate' => "Activate the password checker?",
                
                'Registration_Control:terms:activate' => "Activate the registration terms check?",
                'Registration_Control:agreetoterms' => "我已阅读并同意接受",
				'Registration_Control:terms' => '条款',
				'Registration_Control:agreetoterms:required' => "请先同意服务条款",
				
				'Registration_Control:addbox:activate' => "Add a box to the right of the register form?",
				'Registration_Control:addbox:title' => "今天参与!",
				'addbox:chat' => "与管理人员联系，确保所有人进度统一，UKEC百分百成功.",
				'addbox:contacts' => "获取最新通讯录，并协助更新.",
				'addbox:documents' => "共享公司文件，避免每个人重复相同的工作，让生活变得更加轻松!",
				
				'Registration_Control:icon:activate' => "Activate profile icon on registration form?",
				'Registration_Control:register:profile_icon' => '请上传头像',
				
				'Registration_Control:disable:activate' => "Disable Registration for visitors?",
				'register:disabled' => "抱歉，目前禁止注册.",

);

add_translation("zh",$chinese);
?>