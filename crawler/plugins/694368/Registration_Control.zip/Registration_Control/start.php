<?php
/*******************************************************************************
 * Registration_Control
 *
 * @author WebGalli
 * @author Leo de Carvalho
 * @author Jeroen Dalsem
 * @author Evan Winslow 
 * @author Trajan
 ******************************************************************************/

function Registration_Control_init() {
	global $CONFIG;

	extend_view('css','Registration_Control/css');

				$passwordChecker = get_plugin_setting('passwordChecker','Registration_Control');
				if (!$passwordChecker || $passwordChecker == 'yes') {
                     extend_view('account/forms/register', 'Registration_Control/passwordChecker/register');
                     extend_view('usersettings/form', 'Registration_Control/passwordchecker/password');
                }

                $usernameChecker = get_plugin_setting('usernameChecker','Registration_Control');
                if (!$usernameChecker || $usernameChecker == 'yes') {
                     extend_view('account/forms/register','Registration_Control/usernameChecker/register');
                     register_action('Registration_Control/user_availability', true, $CONFIG->pluginspath . "/Registration_Control/actions/user_availability.php", false);
                }

                $emailChecker = get_plugin_setting('emailChecker','Registration_Control');
                if (!$emailChecker || $emailChecker == 'yes') {
                    extend_view('account/forms/register','Registration_Control/emailChecker/register');
                    extend_view('usersettings/form', 'Registration_Control/emailChecker/email');
                    register_action('Registration_Control/email_availability',  true, $CONFIG->pluginspath . "/Registration_Control/actions/email_availability.php", false);
                }
                
                $iconChecker = get_plugin_setting('icon','Registration_Control');
				if (!$iconChecker || $iconChecker == 'yes') {
                     extend_view('register/extend', 'Registration_Control/icon/register', 950);
                }
                
                $termsChecker = get_plugin_setting('Terms','Registration_Control');
				if (!$termsChecker || $termsChecker == 'yes') {
                     extend_view('register/extend', 'Registration_Control/terms/register', 1000);
                }
				//block user registration if they don't check the box
				register_plugin_hook('action', 'register', 'registrationterms_register_hook');
                
				$addbox = get_plugin_setting('addbox','Registration_Control');
                if (!$addbox || $addbox == 'yes') {
                    extend_view('account/forms/register','Registration_Control/addbox/register');
                }
                return true;				
	}
	function registrationterms_register_hook()
	{
		if (get_input('agreetoterms',false) != 'true') {
			register_error(elgg_echo('Registration_Control:agreetoterms:required'));
			forward($_SERVER['HTTP_REFERER']);
		}
	}
	 function autosubscribegroup_join($event, $object_type, $object){
        global $CONFIG;
        
        //auto submit relashionships between user & groups
        if (($object instanceof ElggUser) && ($event == 'create') && ($object_type == 'user')) {
        
            //retrieve groups ids from plugin
            $groups = get_plugin_setting('joingroups');
            $groups = split(',',$groups);
        
            //for each group ids
            foreach ($groups as $groupId){
            
                //if group exist : submit to group
                if ($groupEnt = get_entity($groupId)){
                
                    //join group succeed ?
                    if ($groupEnt->join($object))
                    {
                        // Remove any invite or join request flags
                        remove_metadata($object->guid, 'group_invite', $groupEnt->guid);
                        remove_metadata($object->guid, 'group_join_request', $groupEnt->guid);
                        
                    }
					
                }
            }
        }
    }
	
	
	
register_elgg_event_handler('init', 'system', 'Registration_Control_init');