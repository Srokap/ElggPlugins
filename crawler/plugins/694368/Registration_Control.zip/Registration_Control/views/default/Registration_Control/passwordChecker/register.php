<?php
/*******************************************************************************
 * Registration_Control
 *
 * @author WebGalli
 * @author Leo de Carvalho
 * @author Jeroen Dalsem
 * @author Evan Winslow 
 * @author Trajan
 ******************************************************************************/
 ?>
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/Registration_Control/js/jquery.pstrength-min.1.2.js">
</script>
<script type="text/javascript">
$(function() {
$('input[name=password]').pstrength(
    '<?php echo elgg_echo('Registration_Control:passwordchecker:message:minchar') ?>',
    '<?php echo elgg_echo("Registration_Control:passwordchecker:message:veryweak") ?>',
    '<?php echo elgg_echo("Registration_Control:passwordchecker:message:weak") ?>',
    '<?php echo elgg_echo("Registration_Control:passwordchecker:message:medium") ?>',
    '<?php echo elgg_echo("Registration_Control:passwordchecker:message:strong") ?>',
    '<?php echo elgg_echo("Registration_Control:passwordchecker:message:verystrong") ?>');
});
</script>