<?php
/*******************************************************************************
 * Registration_Control
 *
 * @author WebGalli
 * @author Leo de Carvalho
 * @author Jeroen Dalsem
 * @author Evan Winslow 
 * @author Trajan
 ******************************************************************************/
 ?>
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/Registration_Control/js/jquery.emailChecker.js">
    // verify name avaiability
</script>
<script language="javascript">
$(document).ready(function()
{
	$('input[name=email]').blur(function () { emailChecker('<?php echo $vars['url']; ?>mod/Registration_Control/actions/email_availability.php', '<?php echo elgg_echo("Registration_Control:emailChecker:message:exists") ?>',
            '<?php echo elgg_echo("Registration_Control:emailChecker:message:error") ?>',
            '<?php echo elgg_echo("Registration_Control:emailChecker:message:available") ?>') });
});
</script>