<?php
/*******************************************************************************
 * Registration_Control
 *
 * @author WebGalli
 * @author Leo de Carvalho
 * @author Jeroen Dalsem
 * @author Evan Winslow 
 * @author Trajan
 ******************************************************************************/
 ?>
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/Registration_Control/js/jquery.usernameChecker.js">
    // verify name avaiability
</script>
<script language="javascript">
$(document).ready(function()
{
	$('input[name=username]').blur(function () { usernameChecker('<?php echo $vars['url']; ?>mod/Registration_Control/actions/user_availability.php', '<?php echo elgg_echo("Registration_Control:usernameChecker:message:exists") ?>',
            '<?php echo elgg_echo("Registration_Control:usernameChecker:message:minChar") ?>',
            '<?php echo elgg_echo("Registration_Control:usernameChecker:message:available") ?>') });
});
</script>