/*******************************************************************************
 * Registration_Control
 *
 * @author WebGalli
 * @author Leo de Carvalho
 * @author Jeroen Dalsem
 * @author Evan Winslow 
 * @author Trajan
 ******************************************************************************/

.usernameChecker_div {
	color: #000000;
}

.messagebox{
	position:absolute;
	width:100px;
	margin-left:430px;
	border:1px solid #c93;
	background:#ffc;
	padding:3px;
}
.messageboxok{
	position:absolute;
	width:auto;
	margin-left:430px;
	border:1px solid #349534;
	background:#C9FFCA;
	padding:3px;
	font-weight:bold;
	color:#008000;

}
.messageboxerror{
	position:absolute;
	width:auto;
	margin-left:430px;
	border:1px solid #CC0000;
	background:#F7CBCA;
	padding:3px;
	font-weight:bold;
	color:#CC0000;
}
#register_right {
	float:left;
	width:480px;
	padding:5px;
	margin:5px 5px 5px 15px;
	border:1px solid #cccccc;
	background:none;
}
#register_bottom {
	float:left;
	width:900px;
	padding:5px;
	margin:5px 5px 5px 10px;
	border:1px solid #cccccc;
	background:none;
}
#register-box {
	float:left;
	text-align:left;
	width:400px;
	padding:10px;
	background: #dedede;
	margin:0;
	-webkit-border-radius: 8px;
	-moz-border-radius: 8px;
}