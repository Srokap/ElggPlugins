<?php
/*******************************************************************************
 * Registration_Control
 *
 * @author WebGalli
 * @author Leo de Carvalho
 * @author Jeroen Dalsem
 * @author Evan Winslow 
 * @author Trajan
 ******************************************************************************/
?>    
    <div id="register_right">

		<div class="register_right_box">
		    <h2><?php echo elgg_echo("Registration_Control:addbox:title"); ?></h2>
            <div class="contentWrapper">
            <p>
            <img style="float:right;" src="<?php echo $vars['url']; ?>mod/Registration_Control/graphics/chat.png">
            <?php echo elgg_echo("addbox:chat"); ?>
            </p>
            <br><br>
            <p>
            <img style="float:right;" src="<?php echo $vars['url']; ?>mod/Registration_Control/graphics/contacts.png">
            <?php echo elgg_echo("addbox:contacts"); ?>
            </p>
            <br><br>
            <p>
            <img style="float:right;" src="<?php echo $vars['url']; ?>mod/Registration_Control/graphics/documents.png">
            <?php echo elgg_echo("addbox:documents"); ?>
            </p>
            <br><br>
	        <div class="clearfloat"></div>
	        </div>
        </div>
    </div>
    <div class="clearfloat"></div>
