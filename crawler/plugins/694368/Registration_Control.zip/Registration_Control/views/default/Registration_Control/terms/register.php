<?php
/*******************************************************************************
 * Registration_Control
 *
 * @author WebGalli
 * @author Leo de Carvalho
 * @author Jeroen Dalsem
 * @author Evan Winslow 
 * @author Trajan
 ******************************************************************************/

?>
<label>
<input type="checkbox" name="agreetoterms" value="true">
<?php echo elgg_echo('Registration_Control:agreetoterms')." <a href=\"{$vars['url']}pg/expages/read/Terms/\">".elgg_echo('Registration_Control:terms')."</a>"; ?>
</label><br/>
