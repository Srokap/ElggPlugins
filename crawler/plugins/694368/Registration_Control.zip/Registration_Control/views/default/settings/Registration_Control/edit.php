<?php
/*******************************************************************************
 * Registration_Control
 *
 * @author WebGalli
 * @author Leo de Carvalho
 * @author Jeroen Dalsem
 * @author Evan Winslow 
 * @author Trajan
 ******************************************************************************/
 
    if ($vars['entity']) {
        if (!$vars['entity']->usernameChecker) {
	    $vars['entity']->usernameChecker = "no";
        }
        if (!$vars['entity']->passwordChecker) {
	    $vars['entity']->passwordChecker = "no";
        }
        if (!$vars['entity']->emailChecker) {
	    $vars['entity']->emailChecker = "no";
        }
        if (!$vars['entity']->Terms) {
	    $vars['entity']->Terms = "no";
        }
        if (!$vars['entity']->ThickBoxTerms) {
	    $vars['entity']->ThickBoxTerms = "no";
        }
        if (!$vars['entity']->addbox) {
	    $vars['entity']->addbox = "no";
        }
        if (!$vars['entity']->BoxContent) {
	    $vars['entity']->BoxContent = "no";
        }
        if (!$vars['entity']->icon) {
	    $vars['entity']->icon = "no";
        }
        if (!$vars['entity']->reg_disable) {
	    $vars['entity']->icon = "no";
        }
        if (!$vars['entity']->joingroups) {
	    $vars['entity']->joingroups = "no";
        }
    }
 ?>
 
 <p>	
	<?php echo elgg_echo('Registration_Control:usernameChecker:activate'); ?> 
<select name="params[usernameChecker]">
  <option value="no" <?php if($vars['entity']->usernameChecker == 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
  <option value="yes" <?php if($vars['entity']->usernameChecker != 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
</select> 
</p>
<br />
 <p>	
	<?php echo elgg_echo('Registration_Control:passwordchecker:activate'); ?> 
<select name="params[passwordChecker]">
  <option value="no" <?php if($vars['entity']->passwordChecker == 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
  <option value="yes" <?php if($vars['entity']->passwordChecker != 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
</select> 
</p>
<br />
<p>
	<?php echo elgg_echo('Registration_Control:emailChecker:activate'); ?>
<select name="params[emailChecker]">
  <option value="no" <?php if($vars['entity']->emailChecker == 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
  <option value="yes" <?php if($vars['entity']->emailChecker != 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
</select>
</p>
<br />
<?php
	$profile_manager_icon = get_plugin_setting('profile_icon_on_register','profile_manager');
				if (!$profile_manager_icon || $profile_manager_icon == 'yes') {}else{
?>
<p>
	<?php echo elgg_echo('Registration_Control:icon:activate'); ?>
<select name="params[icon]">
  <option value="no" <?php if($vars['entity']->icon == 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
  <option value="yes" <?php if($vars['entity']->icon != 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
</select>
</p>
<?php } ?>
<br />
<hr>
<p>
	<?php echo elgg_echo('Registration_Control:terms:activate'); ?>
<select name="params[Terms]">
  <option value="no" <?php if($vars['entity']->Terms == 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
  <option value="yes" <?php if($vars['entity']->Terms != 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
</select>
</p>
<br />
<hr>
<p>
	<?php echo elgg_echo('Registration_Control:addbox:activate'); ?>
<select name="params[addbox]">
  <option value="no" <?php if($vars['entity']->addbox == 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
  <option value="yes" <?php if($vars['entity']->addbox != 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
</select>
</p>
<br />
<hr>
<p>
	<?php echo elgg_echo('Registration_Control:disable:activate'); ?>
<select name="params[reg_disable]">
  <option value="no" <?php if($vars['entity']->reg_disable == 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
  <option value="yes" <?php if($vars['entity']->reg_disable != 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
</select>
</p>
<br />
<p>
	<?php echo elgg_echo('Registration_Control:join:groups'); ?>
<select name="params[joingroups]">
  <option value="no" <?php if($vars['entity']->joingroups == 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
  <option value="yes" <?php if($vars['entity']->joingroups != 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
</select>
</p>
<br />
<?php
	$joingroups = get_plugin_setting('joingroups','Registration_Control');
				if (!$joingroups || $joingroups == 'yes') {
?>

<p>
	<?php echo elgg_echo('Registration_Control:joingroups:list'); ?>:
	<?php
		echo elgg_view('input/text', array('internalname' => 'params[systemgroups]', 'value' => $vars['entity']->systemgroups));
		echo "<p>&nbsp;</p>"
	?>
</p>
<?php } ?>