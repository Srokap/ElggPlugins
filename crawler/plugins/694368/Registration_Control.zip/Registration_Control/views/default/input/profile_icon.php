<?php 
/*******************************************************************************
 * Registration_Control
 *
 * @author WebGalli
 * @author Leo de Carvalho
 * @author Jeroen Dalsem
 * @author Evan Winslow 
 * @author Trajan
 ******************************************************************************/

	echo "<p><label>";
	echo elgg_echo("Registration_Control:register:profile_icon") . "<br />";
	echo elgg_view("input/file", array("internalname"=>"profile_icon"));
	echo "</label></p>";
?>
<script type="text/javascript">
	$(document).ready(function(){
		$("#register-box form").attr("enctype", "multipart/form-data").attr("encoding", "multipart/form-data");
	});
</script>