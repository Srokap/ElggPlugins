<?php 

global $CONFIG;

admin_gatekeeper();

$user = get_user(get_loggedin_userid());

if(!empty($user)){
	$progress = $user->mass_mailouts_progress;
	if(!empty($progress)){
		echo $progress;
	} else {
		echo 0;
	}
} else {
	echo 0;
}

?>