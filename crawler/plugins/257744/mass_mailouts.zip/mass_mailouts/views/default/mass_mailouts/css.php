<?php
	global $CONFIG;
	
?>
.footnote {
	color: grey;
	font-size: 80%;
}