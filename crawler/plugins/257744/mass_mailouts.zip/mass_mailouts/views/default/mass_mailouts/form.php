<?php 
	$form = "";

	$form .= "<p>" . elgg_echo('mass_mailouts:subject');
	$form .= elgg_view('input/text',array(
		'internalname' => 'email_subject',
		'value' => "" 
	)) . "</p>";
	$form .= "<p>" . elgg_echo('mass_mailouts:email_text');
	$form .= elgg_view('input/longtext',array(
		'internalname' => 'email_text',
		'value' => ""
	))  . "</p>";

	$form .= "<p>" . elgg_echo('mass_mailouts:recipienttype');
	$form .= elgg_view('input/recipienttype', array('internalname' => 'access_id','value' => "")) . "</p>";

	$form .= elgg_view('input/submit',array(
		'value' => elgg_echo('mass_mailouts:send')
	));

	$wrappedform2 = elgg_view('input/form',array(
		'body' => $form,
		'internalid' => "massmailForm",
		'action' => $vars['url'] . "action/mass_mailouts/progressWindow"
	));

?>
<script type="text/javascript">

	$(document).ready(function(){
		$('#massmailForm').submit(function(){
			<?php
			if (is_plugin_enabled("tinymce")) {
				echo "tinyMCE.triggerSave();"; 
			} 
			?>
			var url = this.action + "?" + $('#' + this.id).serialize();
			var sWidth = screen.width;
			var sHeight = screen.height;
			var height = 100;
			var width = 300;
			
			var options = "height=" + height + ",width=" + width + ",menubar=no,toolbar=no,status=no,left=" + ((sWidth / 2) - ( width / 2)) + ",top=" + ((sHeight / 2) - (height / 2)) + ",location=no,resizable=no";
			
			window.open(url, "<?php echo elgg_echo("mass_mailouts:progress:window_title"); ?>", options);

			// Reset the form to basic
			$('#massmailForm').each(function(){
				this.reset();
			});

			return false;
		});
	});
</script>
<div id="mass_mailouts_email_area" class="contentWrapper">
	<?php echo $wrappedform2; ?>
	<p class="footnote">
		<?php echo elgg_echo("mass_mailouts:footnote"); ?><br />
		<b>[displayname]</b>: <?php echo elgg_echo("mass_mailouts:footnote:displayname"); ?><br />
		<b>[profile]</b>: <?php echo elgg_echo("mass_mailouts:footnote:profile"); ?><br />
		<b>[username]</b>: <?php echo elgg_echo("mass_mailouts:footnote:username"); ?><br />
		<b>[email]</b>: <?php echo elgg_echo("mass_mailouts:footnote:email"); ?><br />
	</p>
</div>
