<?php
	$groupquery = "SELECT guid,name from {$CONFIG->dbprefix}groups_entity";
	$groupdata = get_data($groupquery);
	$userid = get_loggedin_userid();
	$listquery = "select id,name from {$CONFIG->dbprefix}access_collections where owner_guid = $userid";
	$listdata = get_data($listquery);
?>
<select name="recipients" size="auto">
<?php 
	foreach($groupdata as $groupitem) {
		?>
<option value = "<?php echo "g".($groupitem->guid); ?>" > <?php  echo ($groupitem->name);?> </option>
<?php
	}
?>
<?php 
	foreach($listdata as $listitem) {
		?>
<option value = "<?php echo "l".($listitem->id); ?>" >  <?php echo($listitem->name);?> </option>
<?php 
	}
?>
<option value="c002">Friends</option>
<option value="t001">Everyone</option>
</select>