<?php
/**
* Mass Mail outs.
* 
* @package mass_mailouts
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author ColdTrick IT Solutions
* @copyright ColdTrick 2009
* @link http://www.coldtrick.com/
*/

global $CONFIG;

action_gatekeeper();
admin_gatekeeper();

$subject = get_input('email_subject');
$text = get_input("email_text");
$recipients = get_input("recipients");
$type = substr($recipients, 0, 1);
$id = substr($recipients, 1); 

if (!empty($subject) && !empty($text)) {
	switch($type) {
		case "t": //all
			$count = get_entities("user", "", 0, "", 0, 0, true);
			$users = get_entities("user", "", 0, "", $count);
			break;
		case "c": //friends
			$users = get_entities_from_relationship('friend', get_loggedin_userid(), $inverse_relationship, 'user', $subtype, $owner_guid, "", 10, 0);
			$count = count($users);
			break;
		case "g": //groups
			$users = get_group_members($id,200, 0, 0 , false);
			$count = count($users);
			break;
		case "l": //list of friends
			$users = get_members_of_access_collection($id, false);
			$count = count($users);
			break;
		default:
			$users = array();
			register_error(elgg_echo("mass_mailouts:failure"));
			break;
	}
	
	$failure = 0;
	$succes = 0;
	
	$curUser = get_loggedin_user();
	remove_metadata($curUser->guid, "mass_mailouts_progress");
	
	foreach($users as $user){
		set_time_limit(5);
		
		$newSubject = str_ireplace("[displayname]", $user->name, $subject);
		$newSubject = str_ireplace("[profile]", "<a href='" . $user->getUrl() . "'>" . $user->getUrl() . "</a>", $newSubject);
		$newSubject = str_ireplace("[username]", $user->username, $newSubject);
		$newSubject = str_ireplace("[email]", $user->email, $newSubject);
		$newSubject = str_ireplace("&nbsp;", "", $newSubject);
		
		$newText = str_ireplace("[displayname]", $user->name, $text);
		$newText = str_ireplace("[profile]", "<a href='" . $user->getUrl() . "'>" . $user->getUrl() . "</a>", $newText);
		$newText = str_ireplace("[username]", $user->username, $newText);
		$newText = str_ireplace("[email]", $user->email, $newText);
		$newText = str_ireplace("&nbsp;", "", $newText);
		
		$result = notify_user($user->guid, $user->site_guid, $newSubject, $newText, null, "email");
		
		if($result["email"] === false){
			$failure++;
		} else {
			$succes++;
		}
		
		$curUser->mass_mailouts_progress = ((($succes + $failure) / $count) * 100) . "|" . sprintf(elgg_echo("mass_mailouts:progress:text"), ($succes + $failure), $count);
	}
	
	if($failure == 0){
		system_message(sprintf(elgg_echo("mass_mailouts:success"), $succes));
	} else {
		if($failure == $count){
			register_error(elgg_echo("mass_mailouts:failure"));
		} else {
			register_error(sprintf(elgg_echo("mass_mailouts:some_errors"), $failure, $count));
		}
	}
} else {
	register_error(elgg_echo("mass_mailouts:invalid_input"));
}

forward($_SERVER["HTTP_REFERER"]);
?>