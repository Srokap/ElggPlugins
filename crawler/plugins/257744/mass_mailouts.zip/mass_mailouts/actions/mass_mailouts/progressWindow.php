<?php 
global $CONFIG;
global $SESSION;
action_gatekeeper();
admin_gatekeeper();

$email_subject = urldecode(get_input("email_subject"));
$email_text = urldecode(get_input("email_text"));
$recipients = urldecode(get_input("recipients"));

if(!empty($email_subject) && !empty($email_text)){
	$formBody = elgg_view("input/hidden", array("internalname" => "email_subject", "value" => $email_subject));
	$formBody .= elgg_view("input/hidden", array("internalname" => "email_text", "value" => $email_text));
	$formBody .= elgg_view("input/hidden", array("internalname" => "recipients", "value" => $recipients));
	
	$form = elgg_view("input/form", array("internalid" => "massmailForm", "action" => $CONFIG->wwwroot . "action/mass_mailouts/send", "body" => $formBody));
} else {
	$close = "<script type='text/javascript'>window.close();</script>";
	echo $close;
}

?>
<script type="text/javascript" src="<?php echo $CONFIG->wwwroot; ?>vendors/jquery/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="<?php echo $CONFIG->wwwroot; ?>mod/mass_mailouts/js/jquery.progressbar.js"></script>
<script type='text/javascript'>
	$(document).ready(function(){
		$('#massmailForm').submit(function(){
			$.post(this.action, $('#' + this.id).serialize(), function(data){
				// do nothing
			});

			setTimeout("checkProgress()", 1000);
			
			return false;
		});

		$('#massmailForm').submit();
	});

	function checkProgress(){
		$.post("<?php echo $CONFIG->wwwroot; ?>pg/mass_mailouts/progress", { is_action: "yes" }, function(data){
			if(data){
				var progress = data.split("|"); 
				$('#progress').progressBar(progress[0], { showText: false, boxImage: '<?php echo $CONFIG->wwwroot; ?>/mod/mass_mailouts/images/progressbar.gif', barImage: '<?php echo $CONFIG->wwwroot; ?>/mod/mass_mailouts/images/progressbg_green.gif'});
				$('#progressText').html(progress[1]);
				
				if(parseInt(progress[0]) >= 100){
					setTimeout("window.close()", 10000);
				}else {
					setTimeout("checkProgress()", 1000);
				}
			}
		});
		
	}
</script>
<div id='all'>
	<center>
	<div id='sending'>
		<img src="<?php echo $CONFIG->wwwroot; ?>_graphics/ajax_loader.gif" alt="sending" title="sending" />
		<br />
		<br />
	</div>
	<div id="progress"></div>
	<div id="progressText"></div>
	<div id="form" style="display:none;">
		<?php echo $form;
		ob_flush(); //this is needed to ensure that headers are already sent to avoid the progress page redirecting
		?>
	</div>
	</center>
</div>