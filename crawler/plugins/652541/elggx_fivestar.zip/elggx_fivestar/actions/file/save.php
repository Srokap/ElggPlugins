<?php
	/**
	 * Elgg file browser save action
	 *
	 * @package ElggFile
	 */

	global $CONFIG;

	// Get variables
	$title = strip_tags(get_input("title"));
	$desc = get_input("description");
	$tags = get_input("tags");
	$access_id = (int) get_input("access_id");

	$guid = (int) get_input('file_guid');

	if (!$file = get_entity($guid)) {
		register_error(elgg_echo("file:uploadfailed"));
		forward($CONFIG->wwwroot . "pg/file/owner/" . $_SESSION['user']->username);
		exit;
	}

	$result = false;

	$container_guid = $file->container_guid;
	$container = get_entity($container_guid);

	if ($file->canEdit()) {

		$file->access_id = $access_id;
		$file->title = $title;
		$file->description = $desc;

		// Save tags
			$tags = explode(",", $tags);
			$file->tags = $tags;

			$file->elggx_fivestar_average = 0;
			$file->elggx_fivestar_votes = 0;
			$file->elggx_fivestar_rating = 0;

			$result = $file->save();
	}

	if ($result)
		system_message(elgg_echo("file:saved"));
	else
		register_error(elgg_echo("file:uploadfailed"));

	forward($CONFIG->wwwroot . "pg/file/owner/" . $container->username);
?>