<?php
/**
 *language file for approvenewmembers
 */

$english = array(
	'email:validate:subject' => "New member on %s",
	'email:validate:body' => "Hi,

A new member has just signed up:
Username: %s
Email: %s

IP address: %s
Probable location: %s

You can approve this member by clicking on the link below, or go to the Unvalidated Users list in your network administration panel:

%s


%s
%s
",

	'email:validate:success:subject' => "Welcome %s",
	'email:validate:success:body' => "Hi %s,

You have been accepted as a member of %s.
You can now sign in with your username and password.

Thanks for joining.

%s
%s
",


	'email:signup:subject' => "%s",
	'email:signup:body' => "Hi %s,

We have received your application to join %s.

IMPORTANT: You must REPLY to this email to confirm your email address.
Just hit reply and send.

We will review and approve your application as soon as possible. 
You should be able to log in within the next 24 hours.
A notification will be sent to your email address.
	
Mail us if you have any problem or question.

Thanks for joining.

%s
%s
",

	'email:confirm:success' => "The new member has been approved!",
	'email:confirm:fail' => "The new member could not be approved",

	'uservalidationbyemail:registerok' => "Please check your mailbox for further instructions.
	
	You will need to REPLY to the mail we send you, to confirm your email address.
	(also check your bulk folder if you haven't received our mail within the next 5 minutes)
	",

	'uservalidationbyemail:admin:no_unvalidated_users' => 'No unvalidated users.',

	'uservalidationbyemail:admin:unvalidated' => 'Unvalidated users',
	'uservalidationbyemail:admin:user_created' => 'Registered %s',
	'uservalidationbyemail:admin:resend_validation' => 'Resend validation',
	'uservalidationbyemail:admin:validate' => 'Validate',
	'uservalidationbyemail:admin:delete' => 'Delete',
	'uservalidationbyemail:confirm_validate_user' => 'Validate %s?',
	'uservalidationbyemail:confirm_resend_validation' => 'Resend validation email to %s?',
	'uservalidationbyemail:confirm_delete' => 'Delete %s?',
	'uservalidationbyemail:confirm_validate_checked' => 'Validate checked users?',
	'uservalidationbyemail:confirm_resend_validation_checked' => 'Resend validation to checked users?',
	'uservalidationbyemail:confirm_delete_checked' => 'Delete checked users?',
	'uservalidationbyemail:check_all' => 'All',

	'uservalidationbyemail:errors:unknown_users' => 'Unknown users',
	'uservalidationbyemail:errors:could_not_validate_user' => 'Could not validate user.',
	'uservalidationbyemail:errors:could_not_validate_users' => 'Could not validate all checked users.',
	'uservalidationbyemail:errors:could_not_delete_user' => 'Could not delete user.',
	'uservalidationbyemail:errors:could_not_delete_users' => 'Could not delete all checked users.',
	'uservalidationbyemail:errors:could_not_resend_validation' => 'Could not resend validation request.',
	'uservalidationbyemail:errors:could_not_resend_validations' => 'Could not resend all validation requests to checked users.',

	'uservalidationbyemail:messages:validated_user' => 'User validated.',
	'uservalidationbyemail:messages:validated_users' => 'All checked users validated.',
	'uservalidationbyemail:messages:deleted_user' => 'User deleted.',
	'uservalidationbyemail:messages:deleted_users' => 'All checked users deleted.',
	'uservalidationbyemail:messages:resent_validation' => 'Validation request resent.',
	'uservalidationbyemail:messages:resent_validations' => 'Validation requests resent to all checked users.'

);

add_translation("en", $english);