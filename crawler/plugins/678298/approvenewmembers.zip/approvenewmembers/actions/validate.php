<?php
/**
 * Validate a user or users by guid
 *
 * @package Elgg.Core.Plugin
 * @subpackage UserValidationByEmail
 */

$user_guids = get_input('user_guids');
$error = FALSE;

if (!$user_guids) {
	register_error(elgg_echo('uservalidationbyemail:errors:unknown_users'));
	forward(REFERRER);
}

$access = access_get_show_hidden_status();
access_show_hidden_entities(TRUE);

foreach ($user_guids as $guid) {
	$user = get_entity($guid);
	$site = $CONFIG->site;
	if (!$user instanceof ElggUser) {
		$error = TRUE;
		continue;
	}

	// only validate if not validated
	$is_validated = uservalidationbyemail_get_user_validation_status($guid);
	$validate_success = set_user_validation_status($guid, TRUE, 'email');
	//notify member
	notify_user($guid, $site->guid, sprintf(elgg_echo('email:validate:success:subject'), $user->username), sprintf(elgg_echo('email:validate:success:body'), $user->name, $site->name, $site->name, $site->url), NULL, 'email');


	if ($is_validated || !($validate_success && $user->enable())) {
		$error = TRUE;
		continue;
	}
}

access_show_hidden_entities($access);

if (count($user_guids) == 1) {
	$message_txt = elgg_echo('uservalidationbyemail:messages:validated_user');
	$error_txt = elgg_echo('uservalidationbyemail:errors:could_not_validate_user');
} else {
	$message_txt = elgg_echo('uservalidationbyemail:messages:validated_users');
	$error_txt = elgg_echo('uservalidationbyemail:errors:could_not_validate_users');
}

if ($error) {
	register_error($error_txt);
} else {
	system_message($message_txt);
}

forward(REFERRER);