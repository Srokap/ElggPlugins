.uvbe_bulk_actions {
	padding: 0 5px;
}

.uvbe_bulk_controls {
	float: right;
}

.uvbe_admin_controls {
	float: right;
}

.uvbe_unvalidated_user_details {
	margin-left: 15px;
	font-size: smaller;
}

.uvbe_unvalided_user {
	border: 1px solid gray;
	padding: 5px;
	-webkit-border-radius: 8px;
	-moz-border-radius: 8px;
	margin-bottom: 1em;
}