<?php

	function vazco_cache_metadata_plugins_boot()
	{
		global $CONFIG;
		
		elgg_register_event_handler('create', 'metadata', 'vazco_cache_metadata_update_metadata_event', 1);
		elgg_register_event_handler('update', 'metadata', 'vazco_cache_metadata_update_metadata_event', 1);
		elgg_register_event_handler('delete', 'metadata', 'vazco_cache_metadata_delete_metadata_event', 1);
		
		elgg_register_event_handler('delete', 'object', 'vazco_cache_metadata_delete_entity');
		elgg_register_event_handler('delete', 'file', 'vazco_cache_metadata_delete_entity');
		elgg_register_event_handler('delete', 'user', 'vazco_cache_metadata_delete_entity');
		elgg_register_event_handler('delete', 'group', 'vazco_cache_metadata_delete_entity');
		
		return true;
	}
	
	function vazco_cache_metadata_cache_revaldate()
	{
		if(elgg_is_admin_logged_in() && get_input('cache_revalidate')==1)
		{
			vazco_cache_metadata::cacheRevalidate();//check and recover cache consistency
			system_message('cache_revalidate performed');
		}
	}
	

	function vazco_cache_metadata_init()
	{
		global $CONFIG;
		/*if(get_input('dev')==1)
		{
			$entity = get_entity(29);
			if(get_input('clr')==1)
			{
				$entity->clearMetaData('foo');
			}
			else
			{
				$entity->foo = 1;
			}
		}*/
		return true;
	}
	
	function vazco_cache_metadata_update_metadata_event($event, $object_type, $object)
	{
		$row = get_entity_as_row($object->entity_guid);
		if($row){
			$type = $row->type;
			$subtype = get_subtype_from_id($row->subtype);
			$options = vazco_cache_metadata::getOptions($type, $subtype);
			if($options && in_array($object->name, $options))
			{
				//system_message("update_metadata=".$object->name);
				vazco_cache_metadata::rowUpdate($object->entity_guid, $object->name, false, $type, $subtype);
			}
		}
	}
	
	function vazco_cache_metadata_delete_metadata_event($event, $object_type, $object)
	{
		$row = get_entity_as_row($object->entity_guid);
		if($row){
			$type = $row->type;
			$subtype = get_subtype_from_id($row->subtype);
			$options = vazco_cache_metadata::getOptions($type, $subtype);
			if($options && in_array($object->name, $options))
			{
				//system_message("update_metadata=".$object->name);
				vazco_cache_metadata::rowUpdate($object->entity_guid, $object->name, true, $type, $subtype);
			}
		}
	}
	
	function vazco_cache_metadata_delete_entity($event, $object_type, $object)
	{
		$options = vazco_cache_metadata::getOptions($object->getType(),$object->getSubtype());
		if($options)
		{
			//system_message("delete_entity=".$object->guid);
			vazco_cache_metadata::rowDelete($object->guid, $object->getType(),$object->getSubtype());
		}
	}
	
	/**
	 * Cache'ing metadata values. Possible TODOs: ordering by cached metadata, access control for cached metadata
	 */
	function vazco_cache_metadata_where_sql(&$options, $type, $e_table, $n_table) {
		global $CONFIG;
	
		$n_table_old = $n_table;
		$singulars = array('type', 'subtype');
		$options = elgg_normalise_plural_options_array($options, $singulars);
		
		$return = array (
			'joins' => array (),
			'wheres' => array(),
			'orders' => array()
		);
		//var_dump($type);
		//var_dump($options);
		if($type=='metadata')
		{
			if((isset($options['types']) && !is_array($options['types'])
			   	&& isset($options['subtypes']) && !is_array($options['subtypes']))
			|| (isset($options['types']) && is_array($options['types']) && count($options['types'])==1
			   	&& isset($options['subtypes']) && is_array($options['subtypes']) && count($options['subtypes'])==1)
			|| (isset($options['type_subtype_pairs']) && is_array($options['type_subtype_pairs']) && count($options['type_subtype_pairs'])==1)
			)
			{
				if(count($options['type_subtype_pairs'])==1)
				{
					foreach($options['type_subtype_pairs'] as $paired_type => $paired_subtypes)
					{
						$cache_type = $paired_type;
						$cache_subtype = $paired_subtypes;
					}
				}
				else
				{
					$cache_type = $options['types'];
					$cache_subtype = $options['subtypes'];
				}
				if(is_array($cache_type))
					$cache_type = array_pop($cache_type);
				if(is_array($cache_subtype))
					$cache_subtype = array_pop($cache_subtype);
				
				//var_dump($cache_type);
				//var_dump($cache_subtype);
				$cache_options = vazco_cache_metadata::getOptions($cache_type, $cache_subtype);
				if($cache_options)
				{
					$n_table = 'cache_'.$cache_type.($cache_subtype?'_'.$cache_subtype:'');
					$pair_operator = $options["{$type}_name_value_pairs_operator"];
					if($pair_operator===null)
						$pair_operator = 'AND';
					
					//mapujemy nasze pola
					$onames = &$options["{$type}_names"];
					$ovalues = &$options["{$type}_values"];
					$opairs = &$options["{$type}_name_value_pairs"];
					$names = array();
					$values = array();
					$pairs = array();
					
					if($onames!==NULL && $ovalues!==NULL)
					{
						if (!is_array($onames)) {
							$onames = array($onames);
						}
						if (!is_array($ovalues)) {
							$ovalues = array($ovalues);
						}
						foreach($onames as $key=>$name)
						{
							if(in_array($name, $cache_options))
							{
								$names[] = $name;
								$values[] = $ovalues[$key];
								unset($onames[$key]);
								unset($ovalues[$key]);
							}
						}
					}
					if($opairs!==NULL)
					{
						if (isset($opairs['name']) || isset($opairs['value'])) {
							$opairs = array($opairs);
						}
						foreach($opairs as $key=>$pair)
						{
							if(in_array($pair['name'], $cache_options))
							{
								$pairs[] = $pair;
								unset($opairs[$key]);
							}
						}
					}
					
					/*if (!((!$names && $names !== 0)
						&& (!$values && $values !== 0)
						&& (!$pairs && $pairs !== 0))) 
					{*/
						// will always want to join these tables if pulling metastrings.
						$return['joins'][] = "JOIN {$CONFIG->dbprefix}{$n_table} cn_table on {$e_table}.guid = cn_table.guid";
					
						$wheres = array();
					
						// get names wheres and joins
						$names_where = '';
			
						// get values wheres and joins
						$values_where = '';
						if ($values !== NULL) {
							if (!is_array($values)) {
								$values = array($values);
							}
					
							$sanitised_values = array();
							foreach ($values as $key=>$value) {
								// normalize to 0
								if (!$value) {
									$value = 0;
								}
								$sanitised_values[] = '\'' . sanitise_string($value) . '\'';
							}
					
							if ($values_str = implode(',', $sanitised_values)) {
								$values_where = "(cn_table.{$names[$key]} IN ($values_str))";
							}
						}
					
						if ($values_where) {
							$wheres[] = "($values_where)";
						}
					
						// add pairs
						// pairs must be in arrays.
						if (is_array($pairs)) {
							// check if this is an array of pairs or just a single pair.
							if (isset($pairs['name']) || isset($pairs['value'])) {
								$pairs = array($pairs);
							}
					
							$pair_wheres = array();
							
							foreach ($pairs as $index => $pair) {
								// @todo move this elsewhere?
								// support shortcut 'n' => 'v' method.
								if (!is_array($pair)) {
									$pair = array(
										'name' => $index,
										'value' => $pair
									);
								}
					
								// must have at least a name and value
								if (!isset($pair['name']) || !isset($pair['value'])) {
									// @todo should probably return false.
									continue;
								}
					
								if (isset($pair['operand'])) {
									$operand = sanitise_string($pair['operand']);
								} else {
									$operand = ' = ';
								}
					
								// for comparing
								$trimmed_operand = trim(strtolower($operand));
					
								//$access = get_access_sql_suffix("cn_table{$i}");
								// if the value is an int, don't quote it because str '15' < str '5'
								// if the operand is IN don't quote it because quoting should be done already.
								if (is_numeric($pair['value'])) {
									$value = sanitise_string($pair['value']);
								} else if (is_array($pair['value'])) {
									$values_array = array();
					
									foreach ($pair['value'] as $pair_value) {
										if (is_numeric($pair_value)) {
											$values_array[] = sanitise_string($pair_value);
										} else {
											$values_array[] = "'" . sanitise_string($pair_value) . "'";
										}
									}
					
									if ($values_array) {
										$value = '(' . implode(', ', $values_array) . ')';
									}
					
									// @todo allow support for non IN operands with array of values.
									// will have to do more silly joins.
									$operand = 'IN';
								} else if ($trimmed_operand == 'in') {
									$value = "({$pair['value']})";
								} else {
									$value = "'" . sanitise_string($pair['value']) . "'";
								}
					
								$name = sanitise_string($pair['name']);
					
								// @todo The multiple joins are only needed when the operator is AND
								//$return['joins'][] = "JOIN {$CONFIG->dbprefix}{$n_table} cn_table{$i} on {$e_table}.guid = cn_table{$i}.entity_guid";
								//$return['joins'][] = "JOIN {$CONFIG->dbprefix}metastrings cmsn{$i} on cn_table{$i}.name_id = cmsn{$i}.id";
								//$return['joins'][] = "JOIN {$CONFIG->dbprefix}metastrings cmsv{$i} on cn_table{$i}.value_id = cmsv{$i}.id";
					
								//$pair_wheres[] = "(msn{$i}.string = '$name' AND {$pair_binary}msv{$i}.string $operand $value AND $access)";
								$pair_wheres[] = "(cn_table.$name $operand $value)";
					
								$i++;
							}
					
							if ($where = implode (" $pair_operator ", $pair_wheres)) {
								$wheres[] = "($where)";
							}
						}
					
						if ($where = implode(' AND ', $wheres)) {
							$return['wheres'][] = "($where)";
						}
					//}
				}
			}
		}
		
		//normal execution
		$clauses_cache = $return;
		$clauses = elgg_get_entity_metadata_where_sql('e', $n_table_old, $options["{$type}_names"], $options["{$type}_values"],
			$options["{$type}_name_value_pairs"], $options["{$type}_name_value_pairs_operator"], $options["{$type}_case_sensitive"],
			$options["order_by_{$type}"], $options["{$type}_owner_guids"]);
		//dump($clauses_cache);
		//dump($clauses);
		if(!is_array($clauses))
		{
			$clauses = array (
				'joins' => array (),
				'wheres' => array(),
				'orders' => array()
			);
		}
		$clauses['joins'] = array_merge($clauses['joins'], $clauses_cache['joins']);
		$clauses['wheres'] = array_merge($clauses['wheres'], $clauses_cache['wheres']);
		$clauses['orders'] = array_merge($clauses['orders'], $clauses_cache['orders']);
		
		return $clauses;
	}

	
register_elgg_event_handler('plugins_boot','system','vazco_cache_metadata_cache_revaldate', 1);
register_elgg_event_handler('plugins_boot','system','vazco_cache_metadata_plugins_boot');
register_elgg_event_handler('init','system','vazco_cache_metadata_init');

?>