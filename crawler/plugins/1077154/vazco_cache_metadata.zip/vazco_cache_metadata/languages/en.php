<?php

	$english = array(

		'vazco_cache_metadata:title' => "Test cache for metadata",
	);

	add_translation("en",$english);