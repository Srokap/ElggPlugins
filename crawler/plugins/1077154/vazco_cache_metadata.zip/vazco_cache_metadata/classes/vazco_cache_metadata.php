<?php

class vazco_cache_metadata{
	
	public static function getMetadata($entity, $metadataName){
		if (!$entity){
			return false;
		}
		$dblinkr = get_db_link('read');
		$name = self::tableName($entity->type, $entity->subtype, false);
		
		$sql = "SELECT `{$metadataName}` FROM {$name} WHERE guid={$entity->guid}";
		$result = execute_query($sql, $dblinkr);
			/*if($val_name=='foo')
				echo "$sql<br/>";	*/
			//fetch values and insert
			if($row = mysql_fetch_array($result,MYSQL_NUM))
				$value = $row[0];		
			else
				$value=null;
		return $value;
	}
	public static function getOptions($type=null, $subtype=null)
	{
		$cache_metadata_options = array(
			'group' => array(
					'classified_type', 
					'admpolicy', 
					'typespec', 
					'day', 
					'boarding',
					'agerange',
					'add2',
					'ks2points2010',
					'primary',
					'alevel',
					'gcse',
					'ks5totpup',
					'ks4totpup',
					'ks2totpup',
					'postcode2',
					'status',
					'gender',
					'description',
					'website',
					'postcode',
					'message',
					'boardingfee',
					'lev3ppe2010',
					'lev3pps2010',
					'gcsepoints2010',
					'add1',
					'town',
					'dayfee',
					'tel',
					'eastings',
					'northings',
					'county'
				),
		);
		
		//DO NOT ENABLE LINE BELOW - breaks DB
		//$cache_metadata_options = elgg_trigger_plugin_hook('vazco:cache:metadata','object',null, $cache_metadata_options);
		
		if($type===null)
			return $cache_metadata_options;
			
		$key = $type.($subtype?':'.$subtype:'');
		if(!isset($cache_metadata_options[$key]))
			return false;
		return $cache_metadata_options[$key];
	}
	
	public static function tableName($type, $subtype=null, $override_table_name=null)
	{
		global $CONFIG;
		if($override_table_name)
			$name = $CONFIG->dbprefix.$override_table_name;
		else
		{
			$type = sanitise_string($type);
			$subtype = sanitise_string($subtype);
			$name = $CONFIG->dbprefix.'cache_'.$type.($subtype?'_'.$subtype:'');
		}
		return $name;
	}
	
	public static function rowUpdate($guid, $val_name, $clear, $type, $subtype=null, $override_table_name=null)
	{
		global $CONFIG;
		$dblinkr = get_db_link('read');
		$dblinkw = get_db_link('write');
		$name = self::tableName($type, $subtype, $override_table_name);
		$val_name = mysql_real_escape_string($val_name);
		
		if(!$clear)
		{
			//fetch raw data
			$sql = "SELECT e.guid, msv.string as val";
			$joins = "";
			$wheres = array();
			$joins .= "LEFT JOIN {$CONFIG->dbprefix}metadata n_table on e.guid = n_table.entity_guid "; 
			$joins .= "LEFT JOIN {$CONFIG->dbprefix}metastrings msn on n_table.name_id = msn.id ";
			$joins .= "LEFT JOIN {$CONFIG->dbprefix}metastrings msv on n_table.value_id = msv.id ";
			$wheres[] = "e.guid=$guid";
			$wheres[] = "(msn.string = '$val_name' OR msn.string IS NULL)";
			if($subtype)
				$wheres[] = "((e.type = '$type' AND e.subtype IN (".get_subtype_id($type,$subtype).")))";
			else 
				$wheres[] = "((e.type = '$type'))";
			$sql = $sql." FROM {$CONFIG->dbprefix}entities e ".$joins."WHERE ".implode(" AND ",$wheres);
			
			$result = execute_query($sql, $dblinkr);
			/*if($val_name=='foo')
				echo "$sql<br/>";	*/
			//fetch values and insert
			if($row = mysql_fetch_array($result,MYSQL_NUM))
				$value = $row[1];		
			else
				$value=null;
		}
		else
			$value=null;
		/*if($val_name=='foo')
		{
			var_dump($value);
			dumpdie("all");
		}	*/
		
		/*if ($value){
			$value = str_replace("\'","'",$value);
		}*/
		//$value = mysql_real_escape_string($value);
		$value = sanitise_string($value);
		$sql = "INSERT INTO $name (guid,`$val_name`) VALUES ($guid,".($value!==null?"'$value'":"NULL").")";
		$sql .= " ON DUPLICATE KEY UPDATE `$val_name`=VALUES(`$val_name`)";
		$result = execute_query($sql, $dblinkw);
		return $result;
	}
	
	public static function rowDelete($guid, $type, $subtype=null, $override_table_name=null)
	{
		$dblinkw = get_db_link('write');
		$name = self::tableName($type, $subtype, $override_table_name);
		$sql = "DELETE FROM $name WHERE guid=$guid LIMIT 1;";
		$result = execute_query($sql, $dblinkw);
		return $result;
	}
	
	public static function cacheRevalidate()
	{
		$cache_config = $cache_options = self::getOptions();
		$result = false;
		foreach($cache_config as $key=>$value)
		{
			$pos = strpos($key,':');
			if($pos!==false)
			{
				$type = substr($key,0,$pos);
				$subtype = substr($key,$pos+1);	
			}
			else
			{
				$type = $key;
				$subtype = null;
			}
			//var_dump("[$type][$subtype]");
			if(!self::tableValidate($type, $subtype))
			{
				self::tableRevalidate($type, $subtype);
				$result = true;
			}
		}
		return $result;
	}
	
	public static function tableRevalidate($type, $subtype=null, $override_table_name=null)
	{
		self::tableDrop($type, $subtype, $override_table_name);
		self::tableCreate($type, $subtype, $override_table_name);
		self::tableRefill($type, $subtype, $override_table_name);
	}
	
	public static function tableValidate($type, $subtype=null, $override_table_name=null)
	{
		global $CONFIG;
		if(self::tableExists($type, $subtype, $override_table_name))
		{
			$name = self::tableName($type, $subtype, $override_table_name);
			$cache_options = self::getOptions($type, $subtype);
			if($cache_options===false)
				return false;
				
			$sql = "SHOW COLUMNS FROM $name FROM {$CONFIG->dbname};";
			$result = get_data($sql);
			
			$fields = array();
			$guid_set = false;
			foreach($result as $column_obj)
			{
				$name = $column_obj->{Field};
				if($name=='guid')
					$guid_set = true;
				else
					$fields[] = $name;
			}
			if($guid_set==false)
				return false;
			if(array_diff($fields,$cache_options)!=array())
				return false;
			if(array_diff($cache_options,$fields)!=array())
				return false;
			return true;
		}
		return false;
	}
	
	public static function tableRefill($type, $subtype=null, $override_table_name=null)
	{
		global $CONFIG;
		$name = self::tableName($type, $subtype, $override_table_name);
		$cache_options = self::getOptions($type, $subtype);
		$sql = "TRUNCATE TABLE $name;";
		$result = update_data($sql);
		if(!$result)
			return false;

		$access = elgg_set_ignore_access(true);
		$pairs = array();
		foreach($cache_options as $option)
		{
			$pairs[] = array('name'=>$option, 
						'value' => 'NULL', 
						'operand' => 'NOT');
		}
		$dblinkr = get_db_link('read');
		$dblinkw = get_db_link('write');
		
		$cnt = 1;
		foreach($cache_options as $option)
		{
			$last_guid = 0;
			$step = 50;
			while(true)
			{
				$sql = "SELECT e.guid";
				$joins = "";
				$wheres = array();
				$cnt = 1;
				$sql .= ", msv$cnt.string as $option";
				$joins .= "LEFT JOIN {$CONFIG->dbprefix}metadata n_table$cnt on e.guid = n_table$cnt.entity_guid "; 
				$joins .= "LEFT JOIN {$CONFIG->dbprefix}metastrings msn$cnt on n_table$cnt.name_id = msn$cnt.id ";
				$joins .= "LEFT JOIN {$CONFIG->dbprefix}metastrings msv$cnt on n_table$cnt.value_id = msv$cnt.id ";
				
				$wheres[] = "(msn$cnt.string = '$option' OR msn$cnt.string IS NULL)";
				if($subtype)
				{
					$subtypeId = get_subtype_id($type,$subtype);
					if(!$subtypeId)
					{
						add_subtype($type,$subtype);
						$subtypeId = get_subtype_id($type,$subtype);
						if(!$subtypeId)
						{
							throw new Exception("Unable to register type subtype pair: ($type,$subtype)");
						}
					}
					$wheres[] = "((e.type = '$type' AND e.subtype IN (".$subtypeId.")))";
				}
				else 
				{
					$wheres[] = "((e.type = '$type'))";
				}
				$wheres[] = "($last_guid<e.guid)";
				
				$sql = $sql." FROM {$CONFIG->dbprefix}entities e ".$joins."WHERE ".implode(" AND ",$wheres)." ORDER BY e.guid LIMIT $step";
			
				//var_dump("$sql<br/>");
				$result = execute_query($sql, $dblinkr);
				
				//fetch values and insert
				$values = array();
				while($row = mysql_fetch_array($result,MYSQL_NUM))
				{
					$values[] = "($row[0],'".sanitise_string($row[1])."')";
					$last_guid = $row[0];
				}
				if(count($values)>0)
				{
					$values = ''.implode(",",$values).'';
					//var_dump($values);
					
					$sql = "INSERT INTO $name (guid,$option) VALUES $values ON DUPLICATE KEY UPDATE $option=VALUES($option)";
					$result = execute_query($sql, $dblinkw);
				}
				else 
				{
					break;
				}
				//echo "$sql<br/>";
				//$cnt++;
				//die();
			}
		}
		
		/*
		INSERT INTO table (guid,b,c) VALUES (1,2),(4,5)
			ON DUPLICATE KEY UPDATE c=VALUES(a)+VALUES(b);
		 */
		//, msv1.string as classified_type, n_table1.id, n_table1.value_id, msv2.string as copies_counter
		/*$entities = elgg_get_entities_from_metadata(
				array('type'=>$type,'subtype'=>$subtype,'offest'=>0,'limit'=>999999999,'order_by'=>'asd',
				'metadata_name_value_pairs' => array(
					array('name'=>'end_ts', 
						'value' => 'NULL', 
						'operand' => 'NOT'),
					)	
				)
				'metadata_name_value_pairs' => $pairs,
				)
			);*/
		foreach($entities as $entity)
		{
			$values = array();
		}
		elgg_set_ignore_access($access);
			
		//$options
		return true;
	}
	
	public static function tableExists($type, $subtype=null, $override_table_name=null)
	{
		global $CONFIG;
		//$result = update_data("ALTER TABLE {$CONFIG->dbprefix}entities ADD language_flag VARCHAR(3);");
		$name = self::tableName($type, $subtype, $override_table_name);
		
		/*$sql = "SELECT COUNT(*) as cnt"
			." FROM information_schema.tables" 
			." WHERE table_schema = '{$CONFIG->dbname}'" 
			." AND table_name = '$name'";*/
		$sql = "SHOW TABLES FROM {$CONFIG->dbname} LIKE '$name';";
		$result = get_data_row($sql);
		$result = ((array) $result);
		$result = array_pop($result);
		
		//var_dump($result);
		//var_dump($name);
		//var_dump($result->{cnt});
		if ($result==$name)
			return true;
		return false;
	}
	
	public static function tableCreate($type, $subtype=null, $override_table_name=null)
	{
		global $CONFIG;
		if(!self::tableExists($type, $subtype, $override_table_name))
		{
			$name = self::tableName($type, $subtype, $override_table_name);
			$cache_options = self::getOptions($type, $subtype);
			if($cache_options===false)
				return false;
			
			$sql = "CREATE TABLE `$name` ("
			."`guid` int(10) unsigned NOT NULL,";
			
			foreach($cache_options as $field){
				$field = sanitise_string($field);
				$sql .= "`$field` text,";
				$sql .= "INDEX `{$field}_index` (`$field`(50)),";
			}
			$sql .= "PRIMARY KEY (`guid`));";
			//var_dump($sql);
			$result = update_data($sql);
			return $result;
		}
		return false;
	}
	
	public static function tableDrop($type, $subtype=null, $override_table_name=null)
	{
		global $CONFIG;
		if(self::tableExists($type, $subtype, $override_table_name)){
			$name = self::tableName($type, $subtype, $override_table_name);
			$sql = "DROP TABLE `$name`;";
			$result = update_data($sql);
			//var_dump('res='.$sql);
			//var_dump($result);
			return true;
		}
		//var_dump('not exists');
		return false;
	}

}
?>