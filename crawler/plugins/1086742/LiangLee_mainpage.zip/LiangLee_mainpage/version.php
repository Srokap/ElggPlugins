<?php
/* LiangLee Main Page
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @package Liang Lee Framework
 * @subpackage LiangLee Main Page
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File version.php 
 */
$LiangLee_version = 01092012;
$LiangLee_release = '1.1.1';
?>
