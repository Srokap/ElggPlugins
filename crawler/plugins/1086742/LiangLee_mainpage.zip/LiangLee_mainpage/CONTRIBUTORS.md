Unless otherwise stated within individual files of this package:

Andreas Johannes Berchtold - http://www.freudenschaft.de/Erdschrei_Aura/profile/Andreas 

John Muller - https://github.com/JohnMuller