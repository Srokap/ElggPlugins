LiangLee Main Page 1.1.0
* Converted to 1.1.0
* Upgrade for LiangLeeFramework 1.1.x
* Default Form not view if settings not saved ( Bug reported by http://community.elgg.org/profile/kevanjr )


LiangLee Mian Page 1.0.4
* Add German language
* Add Contributors File.
* Add CHANGE LOG.
* Update CHANGES


LiangLee Mian Page 1.0.4
* Add German language
* Add Contributors File.
* Add CHANGE LOG.
* Update CHANGES

LiangLee Mian Page 1.0.3
* Fix Some Deprecated Errors.
* Fix Group Image Problem.
