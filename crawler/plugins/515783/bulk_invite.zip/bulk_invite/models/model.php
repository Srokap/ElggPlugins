<?php
function bulk_invite_email_user($name, $email, $subject, $message) {
	
	global $CONFIG;

	// **** this should be replaced by a core function for sending emails to people who are not members
	$site = get_entity($CONFIG->site_guid);
	if (($site) && (isset($site->email))) {
		// Has the current site got a from email address?
		$from = $site->email;
	} else {
		// If all else fails, use the domain of the site.
		$from = 'noreply@' . get_site_domain($CONFIG->site_guid);
	}

	if (is_callable('mb_internal_encoding')) {
		mb_internal_encoding('UTF-8');
	}
	$sitename = $site->name;
	if (is_callable('mb_encode_mimeheader')) {
		$sitename = mb_encode_mimeheader($sitename,"UTF-8", "B");
	}

	$header_eol = "\r\n";
	if ((isset($CONFIG->broken_mta)) && ($CONFIG->broken_mta)) {
		// Allow non-RFC 2822 mail headers to support some broken MTAs
		$header_eol = "\n";
	}

	$from_email = "\"$sitename\" <$from>";
	if (strtolower(substr(PHP_OS, 0 , 3)) == 'win') {
		// Windows is somewhat broken, so we use a different format from header
		$from_email = "$from";
	}

	$headers = "From: $from_email{$header_eol}"
		. "Content-Type: text/plain; charset=UTF-8; format=flowed{$header_eol}"
		. "MIME-Version: 1.0{$header_eol}"
		. "Content-Transfer-Encoding: 8bit{$header_eol}";
		
	if (is_callable('mb_encode_mimeheader')) {
		$subject = mb_encode_mimeheader($subject,"UTF-8", "B");
	}

	// Format message
	$message = html_entity_decode($message, ENT_COMPAT, 'UTF-8'); // Decode any html entities
	$message = strip_tags($message); // Strip tags from message
	$message = preg_replace("/(\r\n|\r)/", "\n", $message); // Convert to unix line endings in body
	$message = preg_replace("/^From/", ">From", $message); // Change lines starting with From to >From
	
	$email = "$name <$email>";

	mail($email, $subject, wordwrap($message), $headers);
}

function bulk_invite_create_message($subject, $body) {
	$obj = new ElggObject();
	$obj->subtype = "bulk_invite_message";
	$obj->owner_guid = get_loggedin_userid();
	$obj->access_id = ACCESS_PUBLIC;
	$obj->title = $subject;
	$obj->description = $body;
	$obj->status = 'unsent';
	
	if ($obj->save()) {
		return $obj->guid;
	} else {
		return false;
	}
}

function bulk_invite_create_message_recipient($message_id, $name, $email) {
	$obj = new ElggObject();
	$obj->subtype = "bulk_invite_message_recipient";
	$obj->owner_guid = get_loggedin_userid();
	$obj->access_id = ACCESS_PUBLIC;
	$obj->name = $name;
	$obj->email = $email;
	
	if ($obj->save()) {
		$recipient_id = $obj->guid;
		add_entity_relationship($recipient_id, 'bulk_invite_message', $message_id);
	}
}

function bulk_invite_send_emails() {
	
	// This could take a while, so ask for more time
	// current request is 4 minutes
	
	set_time_limit(240);
	
	// get the site email address
 	
 	$max_emails = 200; // pessimistic quota per cron run - could be increased
 	$emails_sent = 0;
 	
 	// start with current jobs (left over from previous cron run)
 	
 	$emails_sent = bulk_invite_send_message_type('sending',$emails_sent,$max_emails);
 	
 	$message_limit = $max_emails-$emails_sent;
 	
 	// if still within quota, start new jobs
 	if ($message_limit > 0) { 	
		bulk_invite_send_message_type('unsent',$emails_sent,$max_emails);
 	}
}

function bulk_invite_send_message_type($type,$emails_sent,$max_emails) {
	global $CONFIG;
	
	$site = get_entity($CONFIG->site_guid);
	// get up to 10 messages
	$messages = get_entities_from_metadata('status',$type,'object','bulk_invite_message');
	$bulk_invite_unique_code = get_plugin_setting('unique_code', 'bulk_invite') == 'yes';
 	if ($messages) {
 		foreach ($messages as $message) {
 			// lock the message to avoid the small chance that another cron job might
 			// try sending it
 			$message_limit = $max_emails-$emails_sent;
 			if ($message_limit <= 0) {
 				break;
 			}
 			$message->status = "locked";
 			$recipients = get_entities_from_relationship('bulk_invite_message', $message->getGUID(), true, 'object', '', 0, "", $message_limit);
 			if ($recipients) {
 				$subject = $message->title;
 				$body = $message->description;
 				if(strpos($body,'%s') == FALSE) {
 					$body .= "\n\n%s";
 				}
 				
 				$basic_link = $CONFIG->wwwroot.'pg/register';
 				foreach ($recipients as $r) {
 					//$subject = sprintf(elgg_echo('bulk_invite:subject'), $CONFIG->site->name);
	 				if ($bulk_invite_unique_code) {
	 					$code = bulk_invite_generate_unique_code($r->name, $r->email);
	 					$link = $basic_link . "?code=".$code;
	 				} else {
	 					$link = $basic_link;
	 				}
	 				// we don't use sprintf here because it does not behave 
	 				// properly if there are "%" characters in the text being sent
	 				// (beyond %s)
	 				$msg = str_replace("%s",$link,$body);
 					bulk_invite_email_user($r->name, $r->email,$subject,$msg);
 					$r->delete();
 					//remove_entity_relationship($to->getGUID(), 'message_queue', $message_id);
 				}
 				$user_count = count($recipients);
 				$emails_sent += $user_count;
 				if ($user_count < $message_limit) {
 					$message->status = "sending";
 				} else {
 					$message->status = "sent";
 				}
 			} else {
 				//$message->status = "sent";
 			}
 		}
 	}
 	
 	return $emails_sent;
}

// creates an invitation object for the user that is deleted upon registration
function bulk_invite_generate_unique_code($name, $email) {
	global $CONFIG;
	
	$obj = new ElggObject();
	$obj->subtype = "registration_code";
	$obj->owner_guid = get_loggedin_userid();
	$obj->access_id = ACCESS_PUBLIC;
	$obj->name = $name;
	$obj->email = $email;
	// is this random enough?
	$obj->code = md5($name . $email . $CONFIG->site->url . get_site_secret());
	
	if ($obj->save()) {
		return $obj->code;
	} else {
		return false;
	}
}
?>