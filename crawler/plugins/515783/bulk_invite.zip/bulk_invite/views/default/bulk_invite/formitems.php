<?php
if ($vars['error']) {
	$error = '<p>'.$vars['error'].'</p>';
} else {
	$error = '';
}

$subject = $vars['subject'];
$body = $vars['body'];
?>
<div class="contentWrapper">
<?php echo $error; ?>
<p><?php echo elgg_echo('bulk_invite:introduction'); ?></p>
<p><label>
	<?php echo elgg_echo('bulk_invite:subject'); ?>
</label>
<?php echo elgg_view('input/text', array('internalname'=>'subject','value'=>$subject)); ?>
</p>
<p><label>
	<?php echo elgg_echo('bulk_invite:message'); ?>
</label>
</p>
<p><textarea class="input-textarea" name="body" ><?php echo $body; ?></textarea></p>
<p><label>
	<?php echo elgg_echo('bulk_invite:csv'); ?>
</label><br />
<?php 	echo elgg_view('input/file', array('internalname'=>'csv')); ?>
<br />
<?php 	echo elgg_view('input/submit', array('value' => elgg_echo('send')));?>
</p>
</div>