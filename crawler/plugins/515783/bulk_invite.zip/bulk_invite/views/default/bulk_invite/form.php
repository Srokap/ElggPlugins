<?php
echo elgg_view('input/form', array(
		'action' => $vars['url'] . 'action/bulk_invite/invite',
		'body' => elgg_view('bulk_invite/formitems',$vars),
		'method' => 'post',
		'enctype' => 'multipart/form-data'
	)
);
?>
