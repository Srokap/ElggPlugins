<?php
$yn_options = array(elgg_echo('bulk_invite:settings:yes')=>'yes',
	elgg_echo('bulk_invite:settings:no')=>'no',
);

$bulk_invite_unique_code = get_plugin_setting('unique_code', 'bulk_invite');
if (!$bulk_invite_unique_code) {
	$bulk_invite_unique_code = 'no';
}

$body = '';

$body .= elgg_echo('bulk_invite:settings:unique_code:title');
$body .= '<br />';
$body .= elgg_view('input/radio',array('internalname'=>'params[unique_code]','value'=>$bulk_invite_unique_code,'options'=>$yn_options));

echo $body;
?>