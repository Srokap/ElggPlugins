<?php

	/**
	 * Elgg invite page
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2010
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @link http://elgg.org/
	 */

	$english = array(
		'bulk_invite:admin_title' => "Send invitations",
		'bulk_invite:invite' => "Invite a list of people to join \"%s\"",
		'bulk_invite:introduction' => "To invite people to register for this site, "
			."upload a CSV file with name and email fields, and a message to send to them."
			." You can place a %s where you would like the invitation link to appear "
			."(or it will be added to the end of your message).",
		'bulk_invite:message' => "Message",
		'bulk_invite:subject' => "Subject",	
		'bulk_invite:csv' => "CSV file (two columns: name, email)",	
		'bulk_invite:title' => "Bulk invite",
		'bulk_invite:error:title' => "Bulk invite error",
		'bulk_invite:response:invite' => "Your email job has been queued for sending.",
		'bulk_invite:error:email_parse' => "Bad email address: %s",
		'bulk_invite:error:line_parse' => "Cannot parse this CSV line: %s",
		'bulk_invite:error:empty_file' => "There seems to be no content in the CSV file.",
		'bulk_invite:error:invalid_message' => "You need to supply both a subject and a body for your message.",
		'bulk_invite:error:explanation' => 'Error: No invitations have been sent because of the following'
			.' problems. Please correct these problems and resubmit the entire CSV file again.',
		'bulk_invite:error:invite' => "Error: could not queue message for sending. Please try again later.",
		'bulk_invite:settings:yes' => "Yes",
		'bulk_invite:settings:no' => "No",
		'bulk_invite:settings:unique_code:title' => "Add unique code to invitation"
			." (useful for invitation-only sites)",
	
	);
					
	add_translation("en",$english);
?>
