<?php
admin_gatekeeper();

set_context('admin');
$title = elgg_echo('bulk_invite:title');
$body = elgg_view('bulk_invite/form');

page_draw($title,elgg_view_layout("two_column_left_sidebar", '', elgg_view_title($title) . $body));
