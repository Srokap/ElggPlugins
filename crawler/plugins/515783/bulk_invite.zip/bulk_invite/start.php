<?php
// Load model
require_once(dirname(__FILE__) . "/models/model.php");

function bulk_invite_init() {
	global $CONFIG;
	
	// Register a page handler, so we can have nice URLs
	register_page_handler('bulk_invite','bulk_invite_page_handler');
	
	$unique_code = get_plugin_setting('unique_code', 'flexreg') == 'yes';
	if ($unique_code) {
		// disable public registration
		$CONFIG->disable_registration = true;
	}
}

function bulk_invite_pagesetup()
    {
    if (get_context() == 'admin' && isadminloggedin()) {
    	global $CONFIG;
    	add_submenu_item(elgg_echo('bulk_invite:admin_title'), $CONFIG->wwwroot . 'pg/bulk_invite/invite');
    }
}

function bulk_invite_page_handler($page) {
	include(dirname(__FILE__) . "/pages/invite.php");
	return true;
}

function bulk_invite_can_edit($hook_name, $entity_type, $return_value, $parameters) {
	$entity = $parameters['entity'];
	if (($entity->getType() == 'object') && ($entity->getSubtype() == "bulk_invite_message_recipient")) {
		// cron jobs should be able to delete bulk invite recipients
		return true;
	}
	return null;  
}

register_elgg_event_handler('init','system','bulk_invite_init');
register_elgg_event_handler('pagesetup','system','bulk_invite_pagesetup');

register_plugin_hook('cron', 'fiveminute', 'bulk_invite_send_emails');
register_plugin_hook('permissions_check','object','bulk_invite_can_edit');

// Register actions
global $CONFIG;
register_action("bulk_invite/invite",false,$CONFIG->pluginspath . "bulk_invite/actions/invite.php");
?>