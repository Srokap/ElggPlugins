<?php
admin_gatekeeper();

$subject = trim(get_input('subject',''));
$body = trim(get_input('body',''));
if ($subject && $body) {
	$recipients = array();
	$errors = array();
	$csv = get_uploaded_file('csv');
	// make sure that we are using Unix line endings
	$csv = str_replace("\r\n","\n",$csv);
	$csv = str_replace("\r","\n",$csv);
	if ($csv) {
		foreach(explode("\n",$csv) as $line) {
			$line = trim($line);
			if ($line) {
				$bits = explode(",",$line);
				if (count($bits) == 2) {
					$name = $bits[0];
					$email = $bits[1];
					if (is_email_address($email)) {
						$r = new StdClass;
						$r->name = $name;
						$r->email = $email;
						$recipients[] = $r;					
					} else {
						$errors[] = sprintf(elgg_echo('bulk_invite:error:email_parse'),$email);
					}
				} else {
					$errors[] = sprintf(elgg_echo('bulk_invite:error:line_parse'),htmlspecialchars($line));
				}
			}
		}
	} else {
		$errors[] = elgg_echo('bulk_invite:error:empty_file');
	}
} else {
	$errors[] = elgg_echo('bulk_invite:error:invalid_message');	
}

if ($errors) {
	set_context('admin');
	$title = elgg_echo('bulk_invite:error:title');
	$msg = elgg_echo('bulk_invite:error:explanation');
	$msg .= '<br /><p><b>'.implode("<br /><br />",$errors).'</b></p>';
	$body = elgg_view('bulk_invite/form',array('error'=>$msg,'subject' => $subject,'body' => $body));
	
	page_draw($title,elgg_view_layout("two_column_left_sidebar", '', elgg_view_title($title) . $body));
} else {
	// OK, good to go
	$message_id = bulk_invite_create_message($subject, $body);
	if ($message_id) {
		foreach($recipients as $r) {
			bulk_invite_create_message_recipient($message_id, $r->name, $r->email);
		}
		system_message(elgg_echo('bulk_invite:response:invite'));
	} else {
		register_error(elgg_echo('bulk_invite:error:invite'));
	}
	
	forward($CONFIG->wwwroot.'pg/bulk_invite/invite');
}
?>