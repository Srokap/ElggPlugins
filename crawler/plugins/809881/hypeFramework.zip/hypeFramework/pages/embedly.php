<?php

// This page can only be run from within the Elgg framework
if (!is_callable('elgg_view'))
    exit;

if (!isloggedin())
    exit;

global $SESSION;

$offset = (int) get_input('offset', 0);
$simpletype = get_input('simpletype');
$entity_types = array('object' => array('media'));

if (empty($simpletype)) {
    $count = elgg_get_entities(array('type' => 'object', 'subtype' => 'media', 'owner_guid' => $SESSION['user']->guid, 'count' => TRUE));
    $entities = elgg_get_entities(array('type' => 'object', 'subtype' => 'media', 'owner_guid' => $SESSION['user']->guid, 'limit' => 6, 'offset' => $offset));
} else {
    $count = elgg_get_entities_from_metadata(array('metadata_name' => 'oembed_type', 'metadata_value' => $simpletype, 'types' => 'object', 'subtypes' => 'media', 'owner_guid' => $SESSION['user']->guid, 'limit' => 6, 'offset' => $offset, 'count' => TRUE));
    $entities = elgg_get_entities_from_metadata(array('metadata_name' => 'oembed_type', 'metadata_value' => $simpletype, 'types' => 'object', 'subtypes' => 'media', 'owner_guid' => $SESSION['user']->guid, 'limit' => 6, 'offset' => $offset));
}

elgg_register_tag_metadata_name('oembed_type');
$types = get_tags(0, 10, 'oembed_type', 'object', 'media', $SESSION['user']->guid);

// Echo the embed view
echo elgg_view('embed/embedly', array(
    'entities' => $entities,
    'internalname' => $internalname,
    'offset' => $offset,
    'count' => $count,
    'simpletype' => $simpletype,
    'limit' => 6,
    'simpletypes' => $types,
));
?>