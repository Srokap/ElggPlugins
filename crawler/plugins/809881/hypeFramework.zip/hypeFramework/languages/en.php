<?php

	/*** styler Theme language file*/
	
	$english = array(
	'embed:embedly' => 'Media Library'
	);

add_translation("en",$english);
?>