About hypeFramework
--------------------

hypeFramework is a collection of re-usable scripts, visual elements, graphics, cascade style sheets, javascript and other libraries. 
As a foundation for all hypeJunction plugins, hypeFramework helps reduce the volume of server and browser-side scripting. 

Noteworthy features include:
- Improved layout fluidity (integrated 960 grid system allows to create column-base design without loosing control over the placement and floats)
- Latest jQuery UI integration (helps resolve certain UI problems existing within Elgg 1.7; introduces such UI elements, as tabs, dialog, accordion and others)
- Enhanced views and canvases for Elgg (creates views that are often needed to avoid extra HTML markup and CSS styling)
- CLEditor integration (adds a lightweight WYSIWYG HTML editor that is more tolerant towards ajax calls and file embeds)

Integration:
- Replaces TinyMCE/CKEditor with CLEditor
- Integrates CLEditor with Embed plugin
- Integrated CLEditor with NoeLab_media_embedly (only posts links to media if htmlawed enabled)


Bug reports:
- www.hypeJunction.com/trac

INSTALLATION:
1. Unzip the package in your mod folder
2. Enable the plugin in Tool Administration
3. Configure the settings
4. Roll out a theme for jQuery UI to match your Elgg theme

UPGRADE INSTRUCTIONS:
1. Backup the previous version of hypeFramework
2. Remove hypeFramework folder
3. Unzip the new version of hypeFramework
4. Run upgrade.php
