<?php
if (isset($vars['area1']))
    echo elgg_view('hypeFramework/grid/join', array('width' => array(12), 'content' => array($vars['area1'])));
?>
<div>
    <?php
    if (isset($vars['area3'])) {
        echo elgg_view('hypeFramework/grid/join', array('width' => array(3, 9), 'content' => array($vars['area3'], $vars['area2'])));
    } else {
        echo elgg_view('hypeFramework/grid/join', array('width' => array(12), 'content' => array($vars['area2'])));
    }
    ?>
</div>

<?php
    if (isset($vars['area4']))
        $area4 = elgg_view('hypeFramework/grid/join', array('width' => array(12), 'content' => array($vars['area4'])));
        echo elgg_view('hypeFramework/wrappers/horizontalmenu', array('body' => $area4));
?>