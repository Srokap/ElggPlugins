#layout_canvas {
padding:1%;
margin:0.5% 0;
}

#two_column_left_sidebar,
#two_column_left_sidebar_210,
#two_column_left_sidebar_boxes {
width:21%;
margin:0;
padding:0;
}

#two_column_left_sidebar_maincontent,
#two_column_left_sidebar_maincontent_boxes {
width:78%;
margin:0;
padding:0;
float:right;
}

#blog_edit_page {
margin:0;
}

#blog_edit_page #two_column_left_sidebar_maincontent {
width:76%;
margin:0;
padding:1%;
float:right;
}