<?php

//if (get_plugin_setting('lib_modal', 'hypeFramework') == 'enabled')
//        echo elgg_view('hypeFramework/meta/libs/modal', $vars);

if (get_plugin_setting('lib_ui_custom_theme', 'hypeFramework') == 'enabled')
        echo elgg_view('hypeFramework/meta/libs/ui-custom-theme', $vars);

//if (get_plugin_setting('lib_ui_onload_buttons', 'hypeFramework') == 'enabled')
//        echo elgg_view('hypeFramework/meta/libs/ui-onload-buttons', $vars);
//
//if (get_plugin_setting('lib_ui_onload_multiselect', 'hypeFramework') == 'enabled') {
//        echo elgg_view('hypeFramework/meta/libs/multiselect', $vars);
//        echo elgg_view('hypeFramework/meta/libs/ui-onload-multiselect', $vars);
//}
if (is_plugin_enabled('hypeMiniProfile'))
        echo elgg_view('hypeFramework/meta/libs/ui-tipped-tooltip', $vars);

if (get_plugin_setting('lib_cleditor', 'hypeFramework') == 'enabled')
        echo elgg_view('hypeFramework/meta/libs/cleditor', $vars);

//if (get_plugin_setting('lib_ui_dialog', 'hypeFramework') == 'enabled')
//        echo elgg_view('hypeFramework/meta/libs/ui-confirm-dialog', $vars);
?>