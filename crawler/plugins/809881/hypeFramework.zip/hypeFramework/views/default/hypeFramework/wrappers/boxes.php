<div id="two_column_left_sidebar_boxes">
    <?php
    echo $vars['body'];
    ?>
</div>
