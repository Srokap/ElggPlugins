<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/hypeFramework/views/default/hypeFramework/js/ui-elements-buttons
.js"></script>