<?php
$graphics_url = $vars['url'] . 'mod/hypeFramework/graphics/';
echo elgg_view('hypeFramework/css/elements/layout', $vars);
echo elgg_view('hypeFramework/css/elements/framework', $vars);
if (get_plugin_setting('lib_cleditor', 'hypeFramework') == 'enabled') {
    echo elgg_view('hypeFramework/css/elements/embed', $vars);
}
?>

.hj-left, .left { float:left }
.hj-right, .right { float:right }
.hj-left:after,
.hj-right:after {
content: ".";
display: block;
height: 0;
clear: both;
visibility: hidden;
}
.hj-padding-ten, .hj-admin-padding { padding:10px }
.hj-padding-fifteen { padding:15px }
.hj-padding-twenty { padding:20px }
.hj-margin-ten { margin:10px }
.hj-margin-fifteen { margin:15px }
.hj-margin-twenty { margin:20px }
.hj-margin-center { margin: 0 auto; }

.hj-content-container {
background:#ffffff;
width:auto;
min-height:350px;
margin:10px;
padding-bottom:40px;
border-width:1px;
border-color:<?php echo $midbg ?>;
border-style:solid;
-webkit-border-radius: 10px;
-moz-border-radius: 10px;
border-radius: 10px;
}

.hj-ajax-loader {
margin:0 auto;
display:block;
}

.hj-loader-circle { 
background:transparent url(<?php echo $graphics_url ?>loader/circle.gif) no-repeat center center; 
width:75px;
height:75px;
}
.hj-loader-bar { 
background:transparent url(<?php echo $graphics_url ?>loader/bar.gif) no-repeat center center; 
width:16px;
height:11px;
}
.hj-loader-arrows { 
background:transparent url(<?php echo $graphics_url ?>loader/arrows.gif) no-repeat center center; 
width:16px;
height:16px;
}
.hj-loader-indicator { 
background:transparent url(<?php echo $graphics_url ?>loader/indicator.gif) no-repeat center center; 
width:16px;
height:16px;
}

div.button,
a.button {
padding:5px;
font-weight:bold;
cursor:pointer;
}

#hypeHorizontalMenu {
padding:10px;
margin-top:10px;
border-top:1px solid <?php echo $midbg ?>;
}

#hypeVerticalMenu ul {
list-style:none;
}

#hypeHorizontalMenu ul li {
float:left;
margin-right:15px;
}

#hypeHorizontalMenu p {
float:left;
padding:0 10px;
}