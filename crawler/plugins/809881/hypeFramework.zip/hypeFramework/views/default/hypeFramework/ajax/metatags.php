<?php header("Content-type: text/html; charset=UTF-8"); ?>

<?php echo elgg_view('hypeFramework/meta/metatags') ?>
