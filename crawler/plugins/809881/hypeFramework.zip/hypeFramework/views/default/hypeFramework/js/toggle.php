<script type="text/javascript">
    $(document).ready(function() {
        $('<?php echo $vars['source'] ?>').click( function() {
            $('<?php echo $vars['target'] ?>').toggle();
        });
    });
</script>