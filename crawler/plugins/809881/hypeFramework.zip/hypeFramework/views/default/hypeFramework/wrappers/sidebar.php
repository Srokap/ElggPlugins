<div id="two_column_left_sidebar" class="<?php echo $vars['subclass'] ?>">
    <?php echo $vars['body'] ?>
</div>
