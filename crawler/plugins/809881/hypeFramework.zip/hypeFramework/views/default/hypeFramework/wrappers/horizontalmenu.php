<div id="hypeHorizontalMenu">
    <?php
    echo $vars['body'];
    ?>
    <div class="clearfloat"></div>
</div>
