<div class="hj-<?php echo $vars['float'] ?>">
    <?php echo $vars['body']; ?>
</div>
<div class="clearfloat"></div>
