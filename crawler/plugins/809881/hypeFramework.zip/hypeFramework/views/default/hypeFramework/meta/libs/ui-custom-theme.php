<?php
    if (!$theme_path = get_plugin_setting('lib_ui_custom_theme_path', 'hypeFramework'))
            $theme_path = 'mod/hypeFramework/views/default/hypeFramework/vendors/css/custom-theme/jquery-ui-1.8.16.custom.css';
?>
<link type="text/css" href="<?php echo $vars['url'] . $theme_path ; ?>" rel="stylesheet" />