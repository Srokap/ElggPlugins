<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/hypeFramework/views/default/hypeFramework/vendors/editor/jquery.cleditor.min.js"></script>
<link type="text/css" href="<?php echo $vars['url'] . 'mod/hypeFramework/views/default/hypeFramework/vendors/editor/jquery.cleditor.css' ?>" rel="stylesheet" />

<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/hypeFramework/views/default/hypeFramework/vendors/editor/jquery.cleditor.table.min.js"></script>

<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/hypeFramework/views/default/hypeFramework/vendors/editor/jquery.cleditor.icon.min.js"></script>

<?php
if (is_plugin_enabled('embed') || is_plugin_enabled('noelab_video_embedly')) {
    echo elgg_view('hypeFramework/vendors/editor/jquery.cleditor.embed');
}
?>

<script type="text/javascript">
    $(document).ready(function() {
        $('.input-textarea').each(function() {
            var editor = $(this).cleditor({width: '97%'});
        });
    });
    
    $('#embed_simpletype_select').change(function(){
        var simpletype = $('#embed_simpletype_select').val();
        var url = '<?php echo $vars['url']; ?>pg/embed/media?simpletype=' + simpletype + '&internalname=<?php echo $vars['internalname']; ?>';
        $('.popup .content').load(url);
    });
</script>