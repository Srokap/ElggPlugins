<?php
//source: http://www.vrusso.com.br/blog/2011/03/unobtrusive-confirm-javascript-replacement-with-jquery-ui-dialog/
?>

<script type="text/javascript">
$(function ($) {
    $.each($('a'), function() {
        e = $(this).attr("onclick");
        if(e!=undefined) {
            string = $(this).attr("onclick").toString();
            if (string.indexOf('return confirm(')!=-1) {
                target = $(this).attr("href");
                $(this).click(function (e) {
                    e.preventDefault();
                    confirm(null, function () {
                        window.location.href = target;
                    });
                });
            }
        }
    });
});

function confirm(message, callback) {

    $('body').append('<div id="confirm" style="display:none">'+message+'</div>');
    $( "#confirm" ).dialog({
        resizable: false,
        title: 'Confirm',
        modal: true,
        buttons: [
            {
                text: "Yes",
                click: function() {
                    $(this).dialog("close");
                    if ($.isFunction(callback)) {
                        callback.apply();
                    }

                }
            },{
                text: "No",
                click: function() { $(this).dialog("close");}
            }
        ],
        close: function(event, ui) {
            $('#confirm').remove();
        }
    });
}
</script>