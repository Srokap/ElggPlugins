<div id="two_column_left_sidebar_maincontent" class="<?php echo $vars['subclass'] ?>">
    <div id="<?php echo $vars['subdiv'] ?>">
        <div class="hj-padding-ten">
            <?php echo $vars['body'] ?>
        </div>
        <div class="clearfloat"></div>
    </div>
</div>
