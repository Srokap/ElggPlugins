<div class="hj-canvas container_12 clearfix">
<?php
    foreach ($vars['width'] as $key => $width) {
        echo '<div class="grid_' . $width . '">' . $vars['content'][$key] . '</div>';
    }
    ?>
</div>