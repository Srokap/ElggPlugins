.popup .content {
font-size:0.8em;
height:180px;
width:100%;
overflow:auto;
}

#embed_media_tabs {
margin:0;
}
#embed_media_tabs ul li {
background:transparent;
}
#embed_media_tabs ul li a {
height:20px;
margin:0 5px;
padding:0 5px;
}

#mediaUpload, #mediaEmbed {
margin:0;
padding:5px;
}

#mediaUpload .search_listing, #mediaEmbed .search_listing {
padding:3px;
}

#embed_simpletype_select {
font-size:10px;
}

a.embed_media {
display:none;
}