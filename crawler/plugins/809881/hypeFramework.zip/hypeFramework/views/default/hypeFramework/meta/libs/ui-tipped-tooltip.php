<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/hypeFramework/views/default/hypeFramework/js/tooltip/js/bridge/bridge.js"></script>
<!--[if lt IE 9]>
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/hypeFramework/views/default/hypeFramework/js/tooltip/js/excanvas/excanvas.js"></script>
<![endif]-->
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/hypeFramework/views/default/hypeFramework/js/tooltip/js/spinners/spinners.js"></script>
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/hypeFramework/views/default/hypeFramework/js/tooltip/js/tipped/tipped.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo $vars['url']; ?>mod/hypeFramework/views/default/hypeFramework/js/tooltip/css/tipped.css" />
