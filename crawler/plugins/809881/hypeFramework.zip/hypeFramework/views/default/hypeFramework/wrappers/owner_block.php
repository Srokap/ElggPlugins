<div id="owner_block" class="<?php echo $vars['subclass'] ?>">
    <?php echo $vars['body'] ?>

</div>
