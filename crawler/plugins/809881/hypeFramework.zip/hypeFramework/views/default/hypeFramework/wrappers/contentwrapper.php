<?php
/**
 *
 * @package Elgg
 * @subpackage Core
 *
 * @uses $vars['body'] The content to display inside content wrapper
 * @uses $vars['subclass'] Additional css class
 *
 */
?>
<div class="container_12 clearfix">
    <div class="grid_12">
        <div class="contentWrapper<?php
if (isset($vars['subclass'])) {
    echo ' ' . $vars['subclass'];
}
?>">
                 <?php
                 echo $vars['body'];
                 ?>
        </div>
    </div>
</div>