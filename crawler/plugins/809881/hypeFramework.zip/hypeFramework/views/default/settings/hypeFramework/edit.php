<?php

global $CONFIG;

//echo '<p>Enable jQuery UI Buttons</p>';
//
//echo elgg_view('input/pulldown', array(
//    'internalname' => 'params[lib_ui_onload_buttons]',
//    'value' => $vars['entity']->lib_ui_onload_buttons,
//    'options_values' => array(
//        'disabled' => 'No',
//        'enabled' => 'Yes'
//    )
//));
//
//echo '<hr><br>';
//
//echo '<p>Enable jQuery UI Dropdowns</p>';
//
//echo elgg_view('input/pulldown', array(
//    'internalname' => 'params[lib_ui_onload_multiselect]',
//    'value' => $vars['entity']->lib_ui_onload_multiselect,
//    'options_values' => array(
//        'disabled' => 'No',
//        'enabled' => 'Yes'
//    )
//));
//
//echo '<hr><br>';

echo '<p>Enable Custom jQuery UI Theme</p>';

echo elgg_view('input/pulldown', array(
    'internalname' => 'params[lib_ui_custom_theme]',
    'value' => $vars['entity']->lib_ui_custom_theme,
    'options_values' => array(
        'disabled' => 'No',
        'enabled' => 'Yes'
    )
));

echo '<br>';
echo '<p>A number of hypeJunction plugins rely on jQuery UI for user infterface elements (such as tabs, datepicker, accordion etc). To style these elements in a way to match your theme, you can roll out a theme and upload it on your server.</p>';
echo '<p>Path to Custom jQuery UI Theme (default is "mod/hypeFramework/views/default/hypeFramework/vendors/css/custom-theme/jquery-ui-1.8.16.custom.css")</p>';

echo elgg_view('input/text', array(
    'internalname' => 'params[lib_ui_custom_theme_path]',
    'value' => $vars['entity']->lib_ui_custom_theme_path
));


echo '<hr><br>';

echo '<p>Enable CLEditor</p>';
echo '<i>Please disable TinyMCE or CKEditor plugins, if enabled</i>';

echo elgg_view('input/pulldown', array(
    'internalname' => 'params[lib_cleditor]',
    'value' => $vars['entity']->lib_cleditor,
    'options_values' => array(
        'disabled' => 'No',
        'enabled' => 'Yes'
    )
));

//echo '<hr><br>';
//
//echo '<p>Enable Tipped Tooltip Framework</p>';
//
//echo elgg_view('input/pulldown', array(
//    'internalname' => 'params[lib_ui_tipped_tooltip]',
//    'value' => $vars['entity']->lib_ui_tipped_tooltip,
//    'options_values' => array(
//        'disabled' => 'No',
//        'enabled' => 'Yes'
//    )
//));

//echo '<hr><br>';

//echo '<p>Replace JS Confirm with jQuery UI Dialog</p>';
//
//echo elgg_view('input/pulldown', array(
//    'internalname' => 'params[lib_ui_dialog]',
//    'value' => $vars['entity']->lib_ui_dialog,
//    'options_values' => array(
//        'disabled' => 'No',
//        'enabled' => 'Yes'
//    )
//));


?>