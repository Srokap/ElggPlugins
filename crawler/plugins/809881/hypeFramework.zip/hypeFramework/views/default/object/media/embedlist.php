<?php

	$media = $vars['entity'];
	$friendlytime = elgg_view_friendly_time($vars['entity']->time_created);
	
	$info = "<p> <a href=\"{$media->getURL()}\">{$media->title}</a></p>";
	$info .= "<p class=\"owner_timestamp\">{$friendlytime}";	
	$icon = "<a href=\"{$media->getURL()}\"><img src=\"". $vars['entity']->oembed_thumbnail_url . "\" /></a>";
?>
<div id="embedFile<?php echo $media->guid; ?>">
	<div class="search_listing">
		<div class="search_listing_icon">
			<?php echo $icon; ?>
		</div>
		<div class="search_listing_info">
			<?php echo $info; ?>
		</div>
	</div>
</div>
