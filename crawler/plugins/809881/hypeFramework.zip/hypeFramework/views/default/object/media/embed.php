<?php
$media_type = $vars['entity']->media_type;

//get embedly values
$oembed_html = $vars['entity']->oembed_html;
$oembed_type = $vars['entity']->oembed_type;
$oembed_title = $vars['entity']->oembed_title;
$oembed_url = $vars['entity']->oembed_url;
$oembed_provider_name = $vars['entity']->oembed_provider_name;
$oembed_author_name = $vars['entity']->oembed_author_name;
$oembed_description = $vars['entity']->oembed_description;
$oembed_thumbnail_url = $vars['entity']->oembed_thumbnail_url;

switch ($oembed_type) {
    case 'photo':
        ?>

        <img src="<?php echo $oembed_url ?>" alt="<?php echo $oembed_title ?>" title="<?php echo $oembed_title ?>"</img>

        <?php
        break;
    case 'link':
    case 'rich':
    case 'video':
        echo "<div style=\"background:#f4f4f4;padding:5px;\">";
        echo "<div style=\"padding:5px 5px 10px;font-weight:bold\">Media: <a href=\"{$vars['entity']->getURL()}\">{$vars['entity']->title}</a></div>";
        echo $oembed_html;
        echo "</div>";
    case 'error':
    default:
}
?>