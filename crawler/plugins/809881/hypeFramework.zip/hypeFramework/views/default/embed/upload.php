<?php

if (!is_plugin_enabled('file')) {
    return true;
}

echo elgg_view('embed/tabs', array('tab' => 'upload', 'internalname' => $vars['internalname']));

$action = $vars['url'] . 'action/file/upload';
$enctype = 'multipart/form-data';

$form_body .= '<label>' . elgg_echo("file:file") . '</label><br />';
$form_body .= elgg_view("input/file", array('internalname' => 'upload', 'js' => 'id="upload"'));

$form_body .= '<label>' . elgg_echo("title") . '</label><br />';
$form_body .= elgg_view("input/text", array(
    "internalname" => "title",
    "value" => $vars['entity']->title,
        ));

$form_body .= '<label>' . elgg_echo("description") . '</label><br />';
$form_body .= elgg_view("input/longtext", array(
    "internalname" => "description",
    "internalid" => "filedescription",
    "value" => $vars['entity']->description,
        ));

$form_body .= '<label>' . elgg_echo("tags") . '</label><br />';
$form_body .= elgg_view("input/tags", array(
    "internalname" => "tags",
    "value" => $vars['entity']->tags,
        ));

$form_body .= '<label>' . elgg_echo("access") . '</label><br />';
$form_body .= elgg_view("input/access", array(
    "internalname" => "access_id",
    "value" => $vars['entity']->access_id,
        ));

$form_body .= elgg_view("input/hidden", array(
    "internalname" => "container_guid",
    "value" => $vars['container_guid']
        ));
$form_body .= elgg_view("input/hidden", array(
    "internalname" => "file_guid",
    "value" => $vars['entity']->guid
        ));

$form_body .= elgg_view('input/submit', array(
    "value" => elgg_echo('save')
        ));

$form = elgg_view('input/form', array(
    'body' => $form_body,
    'action' => $action,
    'enctype' => $enctype,
    'method' => 'POST',
    'internalid' => "mediaUpload"
        ));

echo $form;