<div id="layout_canvas">
            <?php echo $vars['body'] ?>
</div>