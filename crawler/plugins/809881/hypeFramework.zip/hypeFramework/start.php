<?php

/* hypeFramework
 *
 * Builds a framework for hypeJunction plugins
 * 
 * @package hype
 * @subpackage Framework
 *
 * @author Ismayil Khayredinov <ismayil.khayredinov@gmail.com>
 * @copyright Copyrigh (c) 2011, Ismayil Khayredinov
 */
register_elgg_event_handler('init', 'system', 'hypeFramework_init');

function hypeFramework_init() {

    global $CONFIG;

// Load the CSS Framework
    elgg_extend_view('css', 'hypeFramework/css/base');

// Load the 960 Grid
    elgg_extend_view('css', 'hypeFramework/css/ninesixtygrid');

// Load the Ajax Tabs Framework
    elgg_extend_view('page_elements', 'hypeFramework/tabs');

// Load the Modal Framework
    elgg_extend_view('css', 'hypeFramework/js/modal/css');
    elgg_extend_view('metatags', 'hypeFramework/meta/metatags');

// Register a public action for Ajax tabs
    register_action('framework/tabs', true, $CONFIG->pluginspath . 'hypeFramework/actions/tabs.php', false);

    register_page_handler('embedly', 'hj_framework_embedly');
// hypePlugins
    $hypepluginlist = 'hypeApprove, hypeCategories, hypeComments, hypeCompanies, hypeConnections, hypeJobs, hypeLiveSearch, hypeMiniProfile, hypePortfolio, hypeStyler, hypeWidgets';
    set_plugin_setting('hypepluginlist', $hypepluginlist, 'hypeFramework');
}

function hj_framework_embedly($page) {
    switch ($page[0]) {
        case 'embedly': require_once(dirname(__FILE__) . '/pages/embedly.php');
            exit;
            break;
        case 'embedlyupload' : require_once(dirname(__FILE__) . '/pages/embedlyupload.php');
            exit;
            break;
    }
}

?>