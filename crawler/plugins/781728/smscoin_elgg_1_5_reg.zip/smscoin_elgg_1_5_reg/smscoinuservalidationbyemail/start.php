<?php
	/**
	 * @package ElggPages
	 * @author smscoin.com
	 * @copyright smscoin.com 2009
	 * @link http://smscoin.com/
	 */

	function smscoinuservalidationbyemail_init() {
		global $CONFIG;

		if (isadminloggedin()) {
			add_menu(elgg_echo('SmsCoin Reg'), $CONFIG->wwwroot . "mod/smscoinuservalidationbyemail/config.php");
		}

		// Register actions
		register_action("email/confirm",true, $CONFIG->pluginspath . "smscoinuservalidationbyemail/actions/email/confirm.php");

		// Register hook listening to new users.
		register_elgg_event_handler('validate', 'user', 'smscoinuservalidationbyemail_email_validation');
	}

	/**
	 * Request email validation.
	 */
	function smscoinuservalidationbyemail_email_validation($event, $object_type, $object) {
		if (($object) && ($object instanceof ElggUser)) {
			smscoinuservalidationbyemail_request_validation($object->guid);
		}

		return true;
	}

	/**
	 * Generate an email activation code.
	 *
	 * @param int $user_guid The guid of the user
	 * @param string $email_address Email address
	 * @return string
	 */
	function smscoinuservalidationbyemail_generate_code($user_guid, $email_address) {
		global $CONFIG;

		return md5($user_guid . $email_address . $CONFIG->site->url); // Note I bind to site URL, this is important on multisite!
	}

	/**
	 * Request user validation email.
	 * Send email out to the address and request a confirmation.
	 *
	 * @param int $user_guid The user
	 * @return mixed
	 */
	function smscoinuservalidationbyemail_request_validation($user_guid) {
		global $CONFIG;

		$user_guid = (int)$user_guid;
		$user = get_entity($user_guid);

		if (($user) && ($user instanceof ElggUser)) {
			// Work out validate link
			$link = $CONFIG->site->url . "action/email/confirm?u=$user_guid&c=" . smscoinuservalidationbyemail_generate_code($user_guid, $user->email);

			// Send validation email
			$result = notify_user($user->guid, $CONFIG->site->guid, sprintf(elgg_echo('email:validate:subject'), $user->username), sprintf(elgg_echo('email:validate:body'), $user->name, $link), NULL, 'email');
			if ($result) {
				system_message(elgg_echo('smscoinuservalidationbyemail:registerok'));
			}
			return $result;
		}

		return false;
	}

	/**
	 * Validate a user
	 *
	 * @param unknown_type $user_guid
	 * @param unknown_type $code
	 * @return unknown
	 */
	function smscoinuservalidationbyemail_validate_email($user_guid, $code) {
		$user = get_entity($user_guid);

		$valid = ($code == smscoinuservalidationbyemail_generate_code($user_guid, $user->email));
		if ($valid)
			set_user_validation_status($user_guid, true, 'email');

		return $valid;
	}

	// Initialise
	register_elgg_event_handler('init','system','smscoinuservalidationbyemail_init');

?>
