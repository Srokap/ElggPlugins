<?php
	/**
	 * @package ElggPages
	 * @author smscoin.com
	 * @copyright smscoin.com 2009
	 * @link http://smscoin.com/
	 */

	global $CONFIG;

	// Get user id
	$access_status = access_get_show_hidden_status();
	access_show_hidden_entities(true);
	
	$user_guid = (int)get_input('u');
	$user = get_entity($user_guid);
	
	// And the code
	$code = sanitise_string(get_input('c'));
	
	if ( ($code) && ($user) ) {
		### SMS:Key v1.0.6 ###
		$res = get_data_row("SELECT * FROM {$CONFIG->dbprefix}smscoin_config");
		$old_ua = @ini_set('user_agent', 'smscoin_key_1.0.6');
		$key_id = 210070;
		$response = @file("http://key.smscoin.com/language/".$res->language."/key/?s_key=".$res->key_id
		."&s_pair=".urlencode(substr(get_input("s_pair"),0,10))
		."&s_enc=".$res->enc
		."&s_language=".urlencode(substr(get_input("s_language"),0,10))
		."&s_ip=".$_SERVER["REMOTE_ADDR"]
		."&s_url=".$_SERVER["SERVER_NAME"].htmlentities(urlencode($_SERVER["REQUEST_URI"])));
		if ($response !== false) {
			if (count($response)>1 || $response[0] != 'true') {
				die(implode("", $response));
			}
		} else {
			die('Connection error');
		}
		@ini_set('user_agent', $old_ua);
		### SMS:Key end ###
		
		if (smscoinuservalidationbyemail_validate_email($user_guid, $code)) {

			system_message(elgg_echo('email:confirm:success'));
		
			$user = get_entity($user_guid);
			$user->enable();
			
			notify_user($user_guid, $CONFIG->site->guid, sprintf(elgg_echo('email:validate:success:subject'), $user->username), sprintf(elgg_echo('email:validate:success:body'), $user->name), NULL, 'email');
			
		} else {
			register_error(elgg_echo('email:confirm:fail'));
		}
	} else {
		register_error(elgg_echo('email:confirm:fail'));
	}
	access_show_hidden_entities($access_status);
	
	forward();
	exit;

?>
