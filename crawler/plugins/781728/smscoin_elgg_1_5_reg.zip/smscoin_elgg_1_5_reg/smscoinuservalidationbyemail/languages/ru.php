<?php
    /**
     * @package ElggPages
     * @author smscoin.com
     * @copyright smscoin.com 2009
     * @link http://smscoin.com/
     */

    $russian = array(
    
        'email:validate:subject' => "%s пожалуйста подтвердите ваш email адрес!",
        'email:validate:body' => "Здравствуйте %s,

Пожалуйста подтвердите ваш email адрес пройдя по ссылке:

%s
",
        'email:validate:success:subject' => "Email %s подтвержден!",
        'email:validate:success:body' => "Здравствуйте %s,
            
Email подтвержден.",
    
        
        'email:confirm:success' => "Email подтвержден!",
        'email:confirm:fail' => "Email не подтвержден ...",
    
        'uservalidationbyemail:registerok' => "Для подтверждения регистрации пройдите по ссылке, высланной вам на Email.",
    
        "SMSCOIN_KEY_ID"   => "смс:ключ ID",
        "SMSCOIN_LANGUAGE" => "Язык",
        "SMSCOIN_ENCODING" => "Кодировка",

    );
                    
    add_translation("ru", $russian);
?>
