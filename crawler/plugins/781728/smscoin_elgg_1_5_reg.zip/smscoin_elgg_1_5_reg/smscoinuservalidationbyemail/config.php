<?php
	/**
	 * @package ElggPages
	 * @author smscoin.com
	 * @copyright smscoin.com 2009
	 * @link http://smscoin.com/
	 */

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	global $CONFIG;

	// Get the current page's owner
	$page_owner = page_owner_entity();
	if ($page_owner === false || is_null($page_owner)) {
		$page_owner = $_SESSION['user'];
		set_page_owner($_SESSION['guid']);
	}

	#Get variables
	$key_id = intval(get_input("key_id"));
	$lang = get_input("lang");
	$enc = get_input("enc");
	$save = get_input("save");
	$drop = get_input("drop");

	$title = "SmsCoin Config";

	$res = get_data_row("SHOW TABLES LIKE '{$CONFIG->dbprefix}smscoin_config'");

	#Do Action
	if(!$res) {
		update_data("CREATE TABLE IF NOT EXISTS {$CONFIG->dbprefix}smscoin_config (
			key_id int,
			language varchar(32),
			enc varchar(32),
			PRIMARY KEY (key_id)
			)
		");
		update_data("INSERT IGNORE INTO {$CONFIG->dbprefix}smscoin_config (key_id, language, enc)
			VALUES (".$key_id.",'".$lang."','".$enc."')
		");
	}
	if($save == 'Save') {
		update_data("UPDATE {$CONFIG->dbprefix}smscoin_config SET
			key_id = ".$key_id.",
			language = '".$lang."',
			enc = '".$enc."'
		");
		$info = "Saved";
	}
	$res = get_data_row("SELECT * FROM {$CONFIG->dbprefix}smscoin_config");
	if($drop == 'Drop Tables') {
		update_data("DROP TABLE {$CONFIG->dbprefix}smscoin_config");
		$info = "Droped";
	}
	// Get objects
	$objects = "
		<div align = 'center'>
			<h3>$info</h3>
			<form action = '' method = 'post'>
				<table>
					<tr>
						<td>
							<p>".elgg_echo('SMSCOIN_KEY_ID').":</p>
						</td>
						<td>
							<input type = 'text' value = '$res->key_id' name = 'key_id' />

						</td>
					</tr>
					<tr>
						<td>
							<p>".elgg_echo('SMSCOIN_LANGUAGE').":</p>
						</td>
						<td>
							<select name = 'lang'>
								<option value = 'russian' ".($res->language == 'russian'?'selected':'').">russian</option>
								<option value = 'english' ".($res->language == 'english'?'selected':'').">english</option>
							</select>

						</td>
					</tr>
					<tr>
						<td>
							<p>".elgg_echo('SMSCOIN_ENCODING').":</p>
						</td>
						<td>
							<input type = 'text' value = '$res->enc' name = 'enc' />

						</td>
					</tr>
					<tr>
						<td>
							<input type = 'submit' value = 'Save' name = 'save' />&nbsp;&nbsp;&nbsp;<input type = 'submit' value = 'Drop Tables' name = 'drop' />
						</td>
					</tr>
				</table>
			</form>
		</div>
	";

	set_context($context);

	$body = elgg_view_title($title);
	$body .= $objects;
	$body = elgg_view_layout('two_column_left_sidebar','',$body);

	// Finally draw the page
	page_draw($title, $body);
?>
