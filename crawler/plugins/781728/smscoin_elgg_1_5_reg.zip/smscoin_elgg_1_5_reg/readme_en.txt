
SmsCoin sms:key registration

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
All information within this software product is the
intellectual property of SmsCoin, Israel.

Given software can be used by http://smscoin.com/ clients
for sms:key service only. Any other use of the software
is violation of the company's right and will be pursued
according to operating law.

SmsCoin. Israel will not be held liable for any loss
or damage of any kind as a result of using this software,
including any lost revenues and/or data.
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

 To use this module you have to be registered on smscoin.net
http://smscoin.net/account/register/ , approve
your e-mail account and add service sms:key.

 Registration and set up process are free of charge.


 Plug-in set up:

	1. Disconnect uservalidationbyemail module.
	2. Copy folder smscoinuservalidationbyemail to folder /mod/
	3. Activate the module in your website admin.
	4. Open the module Tools->SmsCoin and configure it.

 How it works:

 Following the registration user receives an e-mail containing activation link.
By clicking the link user will be offered to finish the registration process via SMS-message.


 Uninstall:
	1. Open configuration module Tools->SmsCoin and clikc the Drop Tables button.
	2. Disconnect the module.
	3. Remove the /mod/smscoinuservalidationbyemail/ folder.

 Support
-------------
 For further questions, please contact SmsCoin technical support
via support@smscoin.com

