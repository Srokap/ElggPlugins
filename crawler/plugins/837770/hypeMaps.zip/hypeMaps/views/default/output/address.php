<?php
echo elgg_view('output/location', $vars);