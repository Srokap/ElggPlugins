<?php
/**
 * Elgg Pages CSS
 *
 * @package ElggPages
 */
?>

.tasks-nav.treeview ul {
	background-color: transparent;
}

.tasks-nav.treeview a.selected {
	color: #555555;
}

.tasks-nav.treeview .hover {
	color: #0054a7;
}