<?php
/**
 * Page view
 *
 * @package ElggPages
 */

echo elgg_view('object/task_top', $vars);
