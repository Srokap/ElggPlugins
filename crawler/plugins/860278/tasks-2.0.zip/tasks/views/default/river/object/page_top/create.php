<?php
/**
 * Top task create river view.
 *
 * @package ElggPages
 */

echo elgg_view('river/object/task/create', $vars);