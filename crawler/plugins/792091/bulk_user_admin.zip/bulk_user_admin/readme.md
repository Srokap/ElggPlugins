Bulk user Admin
===============

(C) 2011 Brett Profitt
GPL 2

About
=====
Adds ability to bulk delete users from the admin section.

Adds menu to display users by domain and the most common domains registered.
