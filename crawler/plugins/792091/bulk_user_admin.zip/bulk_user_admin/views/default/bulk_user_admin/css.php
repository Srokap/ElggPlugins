
table.bulk_user_admin_email_domains {
	width: 300px;
}

table.bulk_user_admin_email_domains th {
	text-align: center;
	font-weight: bold;
	font-size: 125%;
}

table.bulk_user_admin_email_domains td {
	padding: 3px;
}

table.bulk_user_admin_email_domains td.center {
	text-align: center;
}

table.bulk_user_admin_email_domains tr.odd {
	background-color: #fff;
}

table.bulk_user_admin_email_domains tr.even {
	background-color: #dedede;
}