<?php 
/*****************************************************************************
 * Phloor Menu Admin Plugins                                                 *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php

elgg_register_event_handler('init',  'system', 'phloor_menu_admin_plugins_init');

/**
 * 
 */
function phloor_menu_admin_plugins_init() {
	/**
	 * LIBRARY
	 * register a library of helper functions
	 */
	$lib_path = elgg_get_plugins_path() . 'phloor_menu_admin_plugins/lib/';
	elgg_register_library('phloor-menu-admin-plugins-lib', $lib_path . 'phloor_menu_admin_plugins.lib.php');
    
	if(elgg_is_admin_logged_in()) {
    	elgg_load_library('phloor-menu-admin-plugins-lib');
        /**
    	 * Event handler
    	 */
        elgg_register_event_handler('pagesetup',  'system', 'phloor_menu_admin_plugins_admin_pagesetup');
    }
    
}

