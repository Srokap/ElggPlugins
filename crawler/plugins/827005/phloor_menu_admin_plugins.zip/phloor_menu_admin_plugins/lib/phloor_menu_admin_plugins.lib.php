<?php 
/*****************************************************************************
 * Phloor Menu Admin Plugins                                                 *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php 

/**
 * 
 *
 */
function phloor_menu_admin_plugins_admin_pagesetup() {
    if(!elgg_in_context('admin')) {
        return true;
    }
    
	$installed_plugins = elgg_get_plugins('any');
 
    $categories = array();
    foreach ($installed_plugins as $id => $plugin) {
    	$plugin_categories = array_flip($plugin->getManifest()->getCategories());      	
        if (isset($plugin_categories)) {
    		foreach ($plugin_categories as $category => $_) {
    			if (!array_key_exists($category, $categories)) {
    				// if localization string not defined, fall back to original category string
    				$cat_raw_string = "admin:plugins:category:$category";
    				$cat_display_string = elgg_echo($cat_raw_string);
    				if ($cat_display_string == $cat_raw_string) {
    					$cat_display_string = ucwords($category);
    				}
    				$categories[$category] = $cat_display_string;
    			}
    		}
        }
    }
    
    ksort($categories);
    
    $common_categories = array(
    	'all' => elgg_echo('admin:plugins:category:all'),
    	'active' => elgg_echo('admin:plugins:category:active'),
    	'inactive' => elgg_echo('admin:plugins:category:inactive'),
    	'bundled' => elgg_echo('admin:plugins:category:bundled'),
    	'nonbundled' => elgg_echo('admin:plugins:category:nonbundled'),
    );
    
    foreach($common_categories as $category => $_) {     
        unset($categories[$key]);
    }
    
    $categories = array_merge($common_categories, $categories);
     
    $i = 0;
    foreach($categories as $key => $text) {
        elgg_register_menu_item('page', array(
    		'name' => "{$key}",
    		'href' => "admin/plugins?category={$key}&sort=priority",
    		'text' => $text,
    		'context' => 'admin',
    		'parent_name' => 'plugins',
    		'priority' => $i++,
    		'section' => 'configure',
    	));
    }	
}
