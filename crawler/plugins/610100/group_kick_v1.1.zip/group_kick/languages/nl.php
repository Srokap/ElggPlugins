<?php 

	$english = array(
		'group_kick:kick' => "Verwijder uit groep",
	
		'group_kick:actions:kick:succes' => "Gebruiker succesvol uit de groep verwijderd",
		'group_kick:actions:kick:error' => "Er ging iets mis bij het verwijderen van de gebruiker uit de groep",
	
	);
	
	add_translation("en", $english);

?>