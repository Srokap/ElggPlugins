<?php 

	$english = array(
		'group_kick:kick' => "Kick from group",
	
		'group_kick:actions:kick:succes' => "Succesfully removed the user from the group",
		'group_kick:actions:kick:error' => "Something went wrong when removing this user from the group",
	
	);
	
	add_translation("en", $english);

?>