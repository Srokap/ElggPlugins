<?php


	function radio_init() 
	{
		global $CONFIG;
		add_menu('Radio', $CONFIG->wwwroot ."radio/onx5radio");	
		register_page_handler('radio','radio_page_handler');	
	}


	function radio_page_handler($page) 
	{

		global $CONFIG;
		if (!isset($page[0])) {
		      forward();
		}

		$base_dir = elgg_get_plugins_path() . 'radio/pages/radio';

		switch ($page[0]) {

			case 'onx5radio':
				include "$base_dir/onx5radio.php";
				break;
			default:
				include "$base_dir/onx5radio.php";
				break;
		}

		
	}
	register_elgg_event_handler('init','system','radio_init');
?>