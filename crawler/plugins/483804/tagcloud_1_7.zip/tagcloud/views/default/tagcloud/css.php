/************* begin tag cloud ***************************/

/* 1 is the least popular tag and 4 is the most */

a.tagcloud {
text-decoration: none;
}

a.tagcloud:hover {
text-decoration: none;
}

a.tagcloud1 {
color: #10568C;
}

a.tagcloud1:hover {
color: #0A3556;
}

a.tagcloud2 {
color: #7AA61B;
}

a.tagcloud2:hover {
color: #658616;
}

a.tagcloud3 {
color: #1B8EE7;
}

a.tagcloud3:hover {
color: #136AAD;
}

a.tagcloud4 {
color: #93C8F1;
}

a.tagcloud4:hover {
color: #66B2EC;
}

/************** end tag cloud ****************************/