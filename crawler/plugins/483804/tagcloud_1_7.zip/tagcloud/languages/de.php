<?php

	$german = array(
		"tagcloud" => "Schlagworte",
		"tagcloud:widget:title" => "Schlagworte",
		"tagcloud:widget:description" => "Schlagworte",
		"tagcloud:widget:notags" => "Anzahl anzeigen",
	);
					
	add_translation("de",$german);

?>