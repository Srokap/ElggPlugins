<?php
	echo $vars['url'] . "mod/natural_brown_theme/graphics/group_icons/defaultsmall.gif";
?>