<?php
	echo $vars['url'] . "mod/natural_brown_theme/graphics/file_icons/pages_lrg.gif";
?>