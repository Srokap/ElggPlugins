Notes:

* Just load it up and go tinymce plugin

Instructions:

Drop into mod, enable in the admin planel and use.