<?php
/**
 * All site questions
 */

require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

// Get the current page's owner
$page_owner = get_loggedin_user();
set_page_owner($page_owner->guid);

$area2 = elgg_view_title(elgg_echo("answers") . ": " . elgg_echo('answers:everyone'));

$area2 .= elgg_list_entities(array(
	'type' => 'object',
	'subtype' => 'question',
	'full_view' => false,
));

$body = elgg_view_layout("two_column_left_sidebar", '', $area2);

page_draw(elgg_echo('answers:everyone'), $body);
