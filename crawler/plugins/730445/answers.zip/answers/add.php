<?php
/**
 * Create a question
 */

require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

gatekeeper();
group_gatekeeper();

// Get the current page's owner
$page_owner = page_owner_entity();
if ($page_owner === false || is_null($page_owner)) {
	set_page_owner($_SESSION['guid']);
}

$area2 = elgg_view("answers/forms/question", array('container_guid' => page_owner()));
$body = elgg_view_layout('two_column_left_sidebar', '', $area2);

page_draw(elgg_echo('answers:question:add'), $body);
