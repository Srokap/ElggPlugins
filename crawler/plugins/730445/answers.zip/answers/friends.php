<?php
/**
 * Friends' questions
 */

require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

// Get the current page's owner
$page_owner = page_owner_entity();
if ($page_owner === false || is_null($page_owner)) {
	$page_owner = $_SESSION['user'];
	set_page_owner($_SESSION['guid']);
}
if (!($page_owner instanceof ElggEntity)) {
	forward();
}

//set the title
if ($page_owner == $_SESSION['user']) {
	$area2 = elgg_view_title(elgg_echo("answers") . ": " . elgg_echo('answers:friends'));
} else {
	$area2 = elgg_view_title(elgg_echo("answers") . ": " . sprintf(elgg_echo('answers:user:friends'), $page_owner->name));
}

// get the user's friends' questions
$area2 .= list_user_friends_objects($page_owner->getGUID(), 'question', 10, false);

$body = elgg_view_layout("two_column_left_sidebar", '', $area2);

page_draw(elgg_echo('answers:friends'), $body);
