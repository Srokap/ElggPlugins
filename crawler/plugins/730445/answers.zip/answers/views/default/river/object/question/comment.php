<?php
/**
 * Comment on a question/answer river view
 */

$performed_by = get_entity($vars['item']->subject_guid);
$object = get_entity($vars['item']->object_guid);
	
$type = $object->getSubType();
$person_url = "<a href=\"{$performed_by->getURL()}\">{$performed_by->name}</a>";
	
$string = sprintf(elgg_echo("question:river:comment:".$type),$person_url) . " ";
$object_title = $type == 'answer' ? get_question_for_answer($object)->title : $object->title;
$string .= "<a href=\"" . $object->getURL() . "\">" . $object_title . "</a>";

echo $string;
