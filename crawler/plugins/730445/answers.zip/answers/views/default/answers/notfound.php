<?php
/**
 * No questions/answers view
 */
?>
<p><?php echo elgg_echo("answers:notfound"); ?></p>