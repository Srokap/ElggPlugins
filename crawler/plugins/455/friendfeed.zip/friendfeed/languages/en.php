<?php

	$english = array(
	
		'friendfeed' => 'FriendFeed',
	
		'friendfeed:username' => 'FriendFeed username',
		'friendfeed:apikey' => 'Friendfeed API key',
		'friendfeed:apikeyfind' => 'find your key',
		'friendfeed:num_display' => 'Number of entries to display',
	
	
		'friendfeed:favorited' => "Favorited: ",
	
		'friendfeed:nouser' => 'This widget has not yet been configured.',
		'friendfeed:nonefound' => 'No information was found at this time.',
		'friendfeed:epicfail' => 'We could not connect to this user\'s FriendFeed at this time.',
			
	);
					
	add_translation("en",$english);

?>