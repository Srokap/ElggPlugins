/**
 * Gifts
 */
.gifts-count {
	font-size: 1.5em;
}
