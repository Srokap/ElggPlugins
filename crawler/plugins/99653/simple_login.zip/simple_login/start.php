<?php

	/**
	 * Simple Login Box
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author skotmiller <skotmiller(at)gmail(dawt)com>
	 * @copyright skotmiller Ltd 2008
	 * @link http://bescenepromotions.com/
	 */

	 
    function simple_login_init() {
    
	    	extend_view('css','simple_login/css');

}
    // Make sure the
		    register_elgg_event_handler('init','system','simple_login_init');

?>