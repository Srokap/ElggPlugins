<?php
	echo $vars['url'] . "mod/theme_greenrounded/graphics/user_icons/defaulttopbar.gif";
?>