<?php
	echo $vars['url'] . "mod/theme_greenrounded/graphics/group_icons/defaultmedium.gif";
?>