/* ***************************************
	ADMIN AREA - REPORTED CONTENT
*************************************** */
.reportedcontent_content {
	padding:10px;
	margin:0 0 10px 0;
}
.reportedcontent_content p.reportedcontent_detail,
.reportedcontent_content p {
	margin:0;
}
.active_report {
	border:1px solid #D3322A;
    background:#F7DAD8; /* red */
}
.archived_report {
	border:1px solid #666666;
    background:#dedede;
}

a.archive_report_button {
	float:right;
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: white;
	background:#688A02; 
	-webkit-border-radius: 5px; 
	-moz-border-radius: 5px;
	width: auto;
	padding: 4px;
	margin:15px 0 0 20px;
	cursor: pointer;
}
a.archive_report_button:hover {
	background: #cc3300;
	color:white;
	text-decoration: none;
}

a.delete_report_button {
	float:right;
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #ffffff;
	background:#999999;
	border: none;
	-webkit-border-radius: 5px; 
	-moz-border-radius: 5px;
	width: auto;
	padding: 4px;
	margin:15px 0 0 20px;
	cursor: pointer;
}
a.delete_report_button:hover {
	background: #333333;
	text-decoration:none;
}

a.manifest_details {
	cursor:pointer;
}
