<?php

    /**
     * GreenRounded theme
     **/
     
     /**
	 * Initialise the theme 
	 *
	 */
	function greenrounded_init(){
	
    }
	
	// Initialise log browser
	register_elgg_event_handler('init','system','greenrounded_init');
	
?>