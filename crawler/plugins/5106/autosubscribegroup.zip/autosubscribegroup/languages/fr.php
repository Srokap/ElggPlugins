<?php
	/**
	 * Elgg autosubscribegroup plugin
	 * This plugin allows new user to join a group when registering
	 * 
	 * @package autosubscribegroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author RONNEL Jérémy
	 * @copyright (c) Elbee 2008
	 * @link /www.notredeco.com
	 */


	$french = array(
	
		/**
		 * Menu items and titles
		 */
	
			'autosubscribe' => 'Inscription automatique à un groupe',
			'autosubscribe:list' => "Liste des identifiants des groupes séparés par des virgules",
	);
    
	add_translation("fr",$french);
?>