<?php
	/**
	 * Elgg autosubscribegroup plugin
	 * This plugin allows new user to join a group when registering
	 * 
	 * @package autosubscribegroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author RONNEL Jérémy
	 * @copyright (c) Elbee 2008
	 * @link /www.notredeco.com
	 */


	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'autosubscribe' => 'Auto-subscription to group',
			'autosubscribe:list' => "Groups' ids (separated by commas)",
	);
    
	add_translation("en",$english);
?>