<?php
	/**
	 * Elgg autosubscribegroup plugin
	 * This plugin allows new user to join a group when registering
	 * 
	 * @package autosubscribegroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author RONNEL J�r�my
	 * @copyright (c) Elbee 2008
	 * @link /www.notredeco.com
	 */

	/**
	 * Init.
	 *
	 */
	function autosubscribegroup_init()
	{
		//group plugin disabled : no need to go further...
        if (!is_plugin_enabled("groups"))
            return;
        
        global $CONFIG;
        
        // Load the language file
		register_translations($CONFIG->pluginspath . "autosubscribegroup/languages/");
            
        //Listen to user registration
	    register_elgg_event_handler('create', 'user', 'autosubscribegroup_join',502); 
	}
    
    /**
    *auto join group define in plugin settings
    *
    */
    function autosubscribegroup_join($event, $object_type, $object){
        global $CONFIG;
        
        //auto submit relashionships between user & groups
        if (($object instanceof ElggUser) && ($event == 'create') && ($object_type == 'user')) {
        
            //retrieve groups ids from plugin
            $groups = get_plugin_setting('systemgroups');
            $groups = split(',',$groups);
        
            //for each group ids
            foreach ($groups as $groupId){
            
                //if group exist : submit to group
                if ($groupEnt = get_entity($groupId)){
                
                    //join group succeed ?
                    if ($groupEnt->join($object))
                    {
                        // Remove any invite or join request flags
                        remove_metadata($object->guid, 'group_invite', $groupEnt->guid);
                        remove_metadata($object->guid, 'group_join_request', $groupEnt->guid);
                        
                    }
					
                }
            }
        }
    }
   
   register_elgg_event_handler('init', 'system', 'autosubscribegroup_init');
    
?>