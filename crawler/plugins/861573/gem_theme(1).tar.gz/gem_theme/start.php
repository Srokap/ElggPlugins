<?php
/*

* Gem Theme by Geminixx is licensed under a 
* Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.
* If you are looking for a designer, 
* feel free to hit me up at 
* http://geminixx.com or email me jermie21@gmail.com

*/

elgg_register_event_handler('init', 'system', 'gem_theme_init');

function gem_theme_init() {
  elgg_unregister_menu_item('topbar', 'elgg_logo');

// Extend system CSS with our own styles
	elgg_extend_view('css/elgg', 'gem_theme/css');

	// Replace the default index page
	elgg_register_plugin_hook_handler('index', 'system', 'gem_theme');
}
        

function gem_theme($hook, $type, $return, $params) {
	if ($return == true) {
		// another hook has already replaced the front page
		return $return;
	}

	if (!include_once(dirname(__FILE__) . "/index.php")) {
		return false;
	}

	// return true to signify that we have handled the front page
	return true;
}

?>