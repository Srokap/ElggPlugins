<?php
/**
 * Walled garden login
 */

$title = elgg_get_site_entity()->name;
$welcome = elgg_echo('walled_garden:welcome');
$welcome .= ': <br/>' . $title;

$menu = elgg_view_menu('walled_garden', array(
	'sort_by' => 'priority',
	'class' => 'elgg-menu-general elgg-menu-hz',
));

$login_box = elgg_view('core/account/login_box', array('module' => 'walledgarden-login'));

$content = <<<HTML
<div class="elgg-col elgg-col-1of2">
	<div class="elgg-inner inbox_text">

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi faucibus, elit vehicula auctor adipiscing, mi nisl dictum nunc, at consequat neque tellus sit amet turpis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed consequat porta arcu, vitae mollis felis malesuada id. Aenean bibendum, justo id fringilla lacinia, ipsum velit dapibus tellus, quis ultricies ligula risus eu mauris. Donec mi ipsum, iaculis non blandit id, dapibus eget felis. Morbi congue justo a metus feugiat pretium nec porta lacus. 
<br /><br >
Aenean bibendum, justo id fringilla lacinia, ipsum velit dapibus tellus, quis ultricies ligula risus eu mauris. Donec mi ipsum, iaculis non blandit id, dapibus eget felis. Morbi congue justo a metus feugiat pretium nec porta lacus. 
	</div>
</div>
<div class="elgg-col elgg-col-1of2">
	<div class="elgg-inner login_box2">
		$login_box
	</div>
<div class="elgg-inner login_box3">
<div id="container"><a href="http://www.macromedia.com/go/getflashplayer">Get the Flash Player</a> to see this player.
<a href="http://www.shoutcheap.com/shoutcast/">shoutcast server</a>
<a href="http://www.shoutcheap.com/icecast/">icecast server</a></div>
<script type="text/javascript" src="http://www.shoutcheap.com/flashplayer/swfobject.js?9d7bd4"></script>
<script type="text/javascript">
var s1 = new SWFObject("http://www.shoutcheap.com/flashplayer/player.swf",
"ply","200","20","9","#FFFFFF");
s1.addParam("allowfullscreen","true");
s1.addParam("allowscriptaccess","always");
s1.addParam("flashvars",
"file=http://ipaddress:port/;stream.nsv&type=mp3&volume=50&autostart=true");
s1.write("container");
</script>

</div>
</div>
HTML;

echo elgg_view_module('walledgarden', '', $content, array(
	'class' => 'elgg-walledgarden-double',
	'header' => ' ',
	'footer' => ' ',
));
