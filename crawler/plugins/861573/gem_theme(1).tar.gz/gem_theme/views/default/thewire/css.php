<?php
/**
 * The Wire CSS
 */

?>
/********************************
The Wire
*********************************/
#thewire-textarea {
	height: 40px;
	padding: 10px;
}
#thewire-characters-remaining {
	text-align: right;
	float: right;
	font-weight: bold;
	color: #222;
}
.thewire-characters-remaining {
	color:#222;
	border:none;
	font-size: 100%;
	font-weight: bold;
	padding:0;
	margin:0;
	text-align: right;
	background: transparent;
}
.thewire-parent {
	margin-left: 40px;
}
