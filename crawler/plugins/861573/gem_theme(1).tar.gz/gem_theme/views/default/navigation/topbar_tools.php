<?php
/**
 * Empty view for backward compatibility.
 *
 * @package Elgg
 * @subpackage Core
 * 
 * @deprecated 1.8 Extend the topbar menus or the page/elements/topbar view directly
 */
