/**
 * CSS for IE8 and above
 */

/* ie8 does not like shrink wrapping this div with inline-block */
.elgg-avatar {
	display: block;
}
