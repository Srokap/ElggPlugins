<?php
/**
 * Elgg Profile CSS
 * 
 * @package Profile
 */
?>
/* ***************************************
	Profile
*************************************** */
.profile {
	float: left;
	margin-bottom: 15px;
}
.profile .elgg-inner {
	margin: 0 5px;

        box-shadow: 0 0 2px 3px #fff;
	border-radius: 0 6px 6px 0; 
}
#profile-details { 
    border-radius: 0 0 6px 0;
    margin: 0 0 5px;
    padding: 15px;
    border: 1px solid #fff;
    border-bottom: 0;
}


/*** ownerblock ***/
#profile-owner-block {
    background-color: #fff;
    border-right: 2px solid #DDDDDD;
    float: left;
    padding: 1px;
    width: 200px;
    padding-right: 3px;
    box-shadow: 0 0 4px #fff;
}
#profile-owner-block .large {
	margin-bottom: 10px;
}
#profile-owner-block a.elgg-button-action {
	margin-bottom: 5px;
	display: table;
}
.profile-content-menu a {
	display: block;
	
	-webkit-border-radius: 3px;
	-moz-border-radius: 3px;
	border-radius: 3px;
	
	background: #fff url(<?php echo elgg_get_site_url(); ?>mod/bright-theme/graphics/button.png) repeat-x left top;
  border: 1px solid #bbb;
	padding: 5px 15px;
	margin: 1px 0;
}
.profile-content-menu a:hover {
	background-color: #28d;
  border-color: #06b;
	color: #fff;
	text-decoration: none;
}
.profile-content-menu a:active {
	background-image: url(<?php echo elgg_get_site_url(); ?>mod/bright-theme/graphics/button-active.png);
  background-position: left bottom;
}
.profile-admin-menu {
	display: none;
}
.profile-admin-menu-wrapper {
  margin-top: 10px;
	background-color: #fff;
	
	-webkit-border-radius: 3px;
	-moz-border-radius: 3px;
	border-radius: 3px;
}
.profile-admin-menu-wrapper a {
	display: block;
	
	-webkit-border-radius: 3px;
	-moz-border-radius: 3px;
	border-radius: 3px;
	
	background-color: #fff;
	padding: 5px 15px;

  color: #f00;
}
.profile-admin-menu-wrapper a:hover {
	color: #000;
}


/*** profile details ***/

#profile-details .odd {
	 background-color: #fff;
    margin: 0 0 5px;
    padding: 3px 10px;
    border-radius: 6px 0 6px 0;
    box-shadow: 0 0 1px 1px #776;
}
#profile-details .even {
	background-color: transparent;
	
	margin: 0 0 5px;
	padding: 3px 10px;
}
.profile-aboutme-title {
	background-color: #fff;
    margin: 0 0 5px;
    padding: 3px 10px;
    border-radius: 6px 0 6px 0;
    box-shadow: 0 0 1px 1px #776;
}
.profile-aboutme-contents {
	padding: 3px 10px;
}
.profile-banned-user {
	border: 2px solid #f00;
	padding: 5px 10px;
}
