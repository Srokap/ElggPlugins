Make sure this plugin is at the bottom of the plugin list.

Gem Theme is a theme that uses CSS3, therefore if users are using an older browser then you wont see the beauty of this theme.

If you dont have a logo for your site then this theme will make your site lovely just the same with plain text as it creates a real beautiful text header with borders.

The theme will work on ALL popular browsers that supports css, if not it will still shows but users wont see the borders etc.

Recommend Browsers:

FF 6 and up.

Chrome 9 and up

IE 9

To edit the index file go to mod/gem_theme/views/default/walled_garden/login.php


If you are looking for a designer, feel free to hit me up at http://geminixx.com or email me jermie21@gmail.com