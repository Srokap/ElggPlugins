<?php

         /**
         * Elgg tips plugin
         * Displays a Quote of the Day widget in a users profile
         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author jededitor and based on an original by Goofbucket
         * @copyright Open
         */
         
         global $CONFIG;
                          
        // Register a page handler, so we can have nice URLs
                register_page_handler('quote','quote_page_handler');
        
        // Page handler
                function scopes_page_handler($page) {
                        global $CONFIG;
                        include($CONFIG->pluginspath . "quote/index.php");
                }
                
        // Load menu
                if (isloggedin()) {
                //add_menu(elgg_echo('Tips'),$CONFIG->wwwroot."pg/tips");
                }
        // Shares widget
                add_widget_type('quote',elgg_echo("Quote of the Day"),elgg_echo("quote"));
        
                
?>
