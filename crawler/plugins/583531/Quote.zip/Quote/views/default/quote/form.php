<?php
         /**
         * Elgg tips plugin
         * Displays a Quote of the Day widget in a users profile
         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author jededitor and based on an original by Goofbucket
         * @copyright Open
         */
?>
<div id="scope" style="text-align:center;" class="contentWrapper">
<?php
/*****
Random Tips and How 2's


HOW TO USE -
1. Edit the quotes below (Random quote 1, etc).
2. Or add in new quotes by copying the text
"Random quote 1",
and pasting it on a new line above
"Random quote 1",

Then include it on your website by using the code:
include("quotes.php");
*****/

$quotes = array(
"Random quote 1",
"Random quote 2",
"Random quote 3"
);

/*****
ATTENTION -
Do not edit below this line unless you know what you are doing.
*****/

echo $quotes[rand(0, count($quotes) - 1)];

?>

</div>
