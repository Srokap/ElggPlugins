<?php
         /**
         * Elgg tips plugin
         * Displays a Quote of the Day widget in a users profile
         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author jededitor and based on an original by Goofbucket
         * @copyright Open
         */
?>
<div id="scope" style="text-align:center;" class="contentWrapper">
<?php
/*****
Random Tips and How 2's


HOW TO USE -
1. Edit the quotes below (Random quote 1, etc).
2. Or add in new quotes by copying the text
"Random quote 1",
and pasting it on a new line above
"Random quote 1",

Then include it on your website by using the code:
include("quotes.php");
*****/

$quotes = array(

"The spirit of this country is totally adverse to a large military force.<br /><b>Thomas Jefferson</b>",
"For good or for ill, air mastery is today the supreme expression of military power and fleets and armies, however vital and important, must accept a subordinate rank.<br /><b>Winston Churchill</b>", 
"Operations in Iraq and Afghanistan and the war on terrorism have reduced the pace of military transformation and have revealed our lack of preparation for defensive and stability operations. This Administration has overextended our military.<br /><b>Barack Obama</b>",
"We're in greater danger today than we were the day after Pearl Harbor. Our military is absolutely incapable of defending this country.Ronald Reagan<br /><b>Ronald Reagan</b>",
"A nation that continues year after year to spend more money on military defense than on programs of social uplift is approaching spiritual doom.<br /><b>Martin Luther King, Jr.</b>",
"Over grown military establishments are under any form of government inauspicious to liberty, and are to be regarded as particularly hostile to republican liberty.<br /><b>George Washington</b>",
"Military justice is to justice what military music is to music.<br /><b>Groucho Marx</b>",
"Military intelligence is a contradiction in terms.<br /><b>Groucho Marx</b>",
"A piece of spaghetti or a military unit can only be led from the front end.<br /><b>George S. Patton</b>",
"A young man who does not have what it takes to perform military service is not likely to have what it takes to make a living. Today's military rejects include tomorrow's hard-core unemployed.<br /><b>John F. Kennedy</b>",
"The basic problems facing the world today are not susceptible to a military solution.<br /><b>John F. Kennedy</b>",
"I look forward to a great future for America - a future in which our country will match its military strength with our moral restraint, its wealth with our wisdom, its power with our purpose.<br /><b>John F. Kennedy</b>",
"War should be the only study of a prince. He should consider peace only as a breathing-time, which gives him leisure to contrive, and furnishes as ability to execute, military plans.<br /><b>Niccolo Machiavelli</b>",
"And like the old soldier in that ballad, I now close my military career and just fade away, an old soldier who tried to do his duty as God gave him the sight to see that duty.<br /><b>Douglas MacArthur</b>",
"I feel impelled to speak today in a language that in a sense is new-one which I, who have spent so much of my life in the military profession, would have preferred never to use. That new language is the language of atomic warfare.<br /><b>Dwight D. Eisenhower</b>",
"I have against me the bourgeois, the military and the diplomats, and for me, only the people who take the Metro.<br /><b>Charles de Gaulle</b>",
"I had examined myself pretty thoroughly and discovered that I was unfit for military service.<br /><b>Joseph Heller</b>",
"I'm inclined to think that a military background wouldn't hurt anyone.<br /><b>William Faulkner</b>",
"I would sincerely regret, and which never shall happen whilst I am in office, a military guard around the President.<br /><b>Andrew Jackson</b>",
"We don't thrive on military acts. We do them because we have to, and thank God we are efficient.<br /><b>Golda Meir</b>",
"Wealth, religion, military victory have more rhetorical than efficacious worth.<br /><b>George Santayana</b>",
"Never forget that no military leader has ever become great without audacity.<br /><b>Karl Von Clausewitz</b>",
"After a shooting spree, they always want to take the guns away from the people who didn't do it. I sure as hell wouldn't want to live in a society where the only people allowed guns are the police and the military.<br /><b>William S. Burroughs</b>",
"But courage which goes against military expediency is stupidity, or, if it is insisted upon by a commander, irresponsibility.<br /><b>Erwin Rommel</b>",
"You don't have to be straight to be in the military; you just have to be able to shoot straight.<br /><b>Barry Goldwater</b>",
"If we have reason to believe someone is preparing an attack against the U.S., has developed that capability, harbours those aspirations, then I think the U.S. is justified in dealing with that, if necessary, by military force.<br /><b>Dick Cheney</b>",
"The plan was criticized by some retired military officers embedded in TV studios. But with every advance by our coalition forces, the wisdom of that plan becomes more apparent.<br /><b>Dick Cheney</b>",
"Today, only 2 percent of the people know the name of someone serving in uniform. That means 2 percent of your listeners can actually conjure up the image of someone wearing the uniform of the military of the United States.<br /><b>Oliver North</b>",
"That's the reason some schools of thinking don't rule out a destruction of the Chinese military potential before the situation grows worse than it is today. It's bad enough now.<br /><b>Curtis Lemay</b>",
"President Kennedy was willing to go to war. He was not a coward. The man had been in war and so had Ken O'Donnell. He was ready to protect this nation, but he was not ready for a military solution just because it was being rammed down his throat.<br /><b>Kevin Costner</b>",
"I always ask two questions: How many countries have military bases in the United States? And in how many countries does the United States not have military bases?<br /><b>Jose Saramago</b>",
"Can you imagine what Bush would say if someone like Hugo Chavez asked him for a little piece of land to install a military base, and he only wanted to plant a Venezuelan flag there?<br /><b>Jose Saramago</b>",
"The US needs to control the Middle East, the gateway to Asia. It already has military installations in Uzbekistan.<br /><b>Jose Saramago</b>",
"I don't think there's any reason on Earth why people should have access to automatic and semiautomatic weapons unless they're in the military or in the police.<br /><b>John Howard</b>",
"We citizens don't need to know every detail of every military operation in this new kind of war. Nor should the media tell us and hence our enemy.<br /><b>David Hackworth</b>",
"If you ask me to summarise our mission, I would put it this way: We were a military regime that sought to lay the foundations for freedom and liberty in a complex society.<br /><b>Ibrahim Babangida</b>",
"The military don't start wars. Politicians start wars.<br /><b>William Westmoreland</b>",
"The military lead turbulent lives, but they are people like everybody else.<br /><b>William Westmoreland</b>",
"My decision to register women confirms what is already obvious throughout our society-that women are now providing all types of skills in every profession. The military should be no exception.<br /><b>Jimmy Carter</b>",
"A military man can scarcely pride himself on having smitten a sleeping enemy; it is more a matter of shame, simply, for the one smitten.<br /><b>Isoroku Yamamoto</b>",
"Successful organizations, including the Military, have learned that the higher the risk, the more necessary it is to engage everyone's commitment and intelligence.<br /><b>Margaret J. Wheatley</b>",
"Most people associate command and control leadership with the military.<br /><b>Margaret J. Wheatley</b>",
"I think they are paying a lot more attention to news now, by the way, in part because of national-security issues. A lot of young people have friends or family in the military today.<br /><b>Tom Brokaw</b>",
"Bush's war in Iraq has done untold damage to the United States. It has impaired our military power and undermined the morale of our armed forces. Our troops were trained to project overwhelming power. They were not trained for occupation duties.<br /><b>George Soros</b>",
"Conquest is the missionary of valor, and the hard impact of military virtues beats meanness out of the world.<br /><b>Walter Bagehot</b>",
"There's no military solution to terrorism. If there were, Israel would be the safest place in the world.<br /><b>Bradley Whitford</b>",
"No state, furthermore, unless it has aggressive military designs such as those which consumed Nazi leaders in the thirties, is likely to divert to defense any more of its resources and wealth and energy than seems necessary.<br /><b>Lester B. Pearson</b>",
"Military hardliners called me a 'security threat' for promoting peace in South Asia and for supporting a broad-based government in Afghanistan.<br /><b>Benazir Bhutto</b>",
"The military wants a system that protects its policies and privileges.<br /><b>Benazir Bhutto</b>",
"The military destabilised my government on politically motivated charges.<br /><b>Benazir Bhutto</b>",
"Washington is like a self-sealing tank on a military aircraft. When a bullet passes through, it closes up.<br /><b>Dean Acheson</b>",
"I'm against the draft. I believe we should have a professional military; it might be smaller, but it would be more effective.<br/><b>Jesse Ventura</b>",
"The proportion between the velocity with which men or animals move, and the weights they carry, is a matter of considerable importance, particularly in military affairs.<br /><b>Charles Babbage</b>",
"Even military ministers have no more than a certain amount of control. It is customary that they have the right and the power to participate, from a political and military point of view, in the planning of actual operations.<br /><b>Hideki Tojo</b>",
"Therefore, if one were to consider that there was virtually no possibility of success through the US-Japan negotiations, the military and economic pressures would only force Japan into further crisis if time were allowed to pass in vain.<br /><b>Hideki Tojo</b>",
"As costly as it was in the lives of our men and women in uniform, in military assets, and in esteem and pride, Pearl Harbor was a watershed moment for America.<br /><b>Joe Baca</b>",
"I really do inhabit a system in which words are capable of shaking the entire structure of government, where words can prove mightier than ten military divisions.<br /><b>Vaclav Havel</b>",
"I think you also understand that one of the key things that's got to be done in Iraq is to build a mentality of understanding that the military needs to be subordinate to civilian control and respectful of its own people.<br /><b>John Abizaid</b>",
"Well, the reports are correct that we're conducting very robust military operations on the Afghan side of the border in areas where we think al-Qaida is operating and Taliban remnants are.<br /><b>John Abizaid</b>",
"You know as well as I do that counterinsurgency is a very nuanced type of military operation.<br /><b>John Abizaid</b>",
"Before a war military science seems a real science, like astronomy; but after a war it seems more like astrology.<br /><b>Rebecca West</b>",
"If the United States is hit with a weapon of mass destruction that inflicts large casualties, the Constitution will likely be discarded in favor of a military form of government.<br /><b>Tommy Franks</b>",
"My mental faculties remained in suspended animation while I obeyed the orders of the higher-ups. This is typical with everyone in the military.<br /><b>Smedley Butler</b>",
"I think I understand what military fame is; to be killed on the field of battle and have your name misspelled in the newspapers.<br /><b>William Tecumseh Sherman</b>",
"The Roswell incident, for instance, had over three hundred witnesses - some describing the bodies, some the craft, some the military procedures. Were they all perpetuating their own lives in a myth?<br /><b>Dwight Schultz</b>",
"He is neither a strategist nor is he schooled in the operational arts, nor is he a tactician, nor is he a general. Other than that he's a great military man.<br /><b>Norman Schwarzkopf</b>",
"Inasmuch as society cannot go on without discipline of some kind, men were constrained, in the absence of any other form of discipline, to turn to discipline of the military type.<br /><b>Irving Babbitt</b>",
"I did not go to military school. I had an option either a military school or a private school. I don't know how to get that out of the information that's out there.<br /><b>Channing Tatum</b>",
"Emancipation came to the colored race in America as a war measure. It was an act of military necessity. Manifestly it would have come without war, in the slower process of humanitarian reform and social enlightenment.<br /><b>Wendell Willkie</b>",
"I played the organ when I went to military school, when I was 10. They had a huge organ, the second-largest pipe organ in New York State. I loved all the buttons and the gadgets. I've always been a gadget man.<br /><b>Stephen Sondheim</b>",
"The law increasing and organizing the military establishment of the United States has been nearly carried into effect, and the Army has been extensively and usefully employed during the past season.<br /><b>Martin Van Buren</b>",
"War is much too serious a matter to entrust to military men.<br /><b>Georges Clemenceau</b>",
"When an aggressor force continually launches attacks from a particular base of operations, it is sound military strategy to take the flight to the enemy.<br /><b>Timothy McVeigh</b>",
"The use of military force against Iran would be very dangerous. It would be very provocative. The only thing worse would be Iran being a nuclear power.<br /><b>Rudy Giuliani</b>", 
"Man is a military animal, glories in gunpowder, and loves parade.<br /><b>Philip James Bailey</b>",
"War is much too serious a thing to be left to military men.<br /><b>Charles Maurice de Talleyrand</b>",
"My hope is that gays will be running the world, because then there would be no war. Just a greater emphasis on military apparel.<br /><b>Roseanne Barr</b>",
"Sometimes I sit down to dinner with people and I realize there is a massive military machine surrounding us, trying to kill the people I'm having dinner with.<br /><b>Rachel Corrie</b>",
"I have two brothers buried in the military cemetery in Texas. I don't want to see any more of that.<br /><b>F. Murray Abraham</b>",
"I know that military alliances and armament have been the reliance for peace for centuries, but they do not produce peace; and when war comes, as it inevitably does under such conditions, these armaments and alliances but intensify and broaden the conflict.<br /><b>Frank B. Kellogg</b>",
"White House and State Department foreign-policy experts are overwhelmingly directed towards military and diplomatic issues, not development issues.<br /><b>Jeffrey Sachs</b>",
"This experience actually means the very opposite: the largest military power was unable to stop such a sensitive attack and will be unable to rule out such a possibility in the future. Precisely this is the background to the United States' military interventions.<br /><b>Ulrich Beck</b>",
"Neither science, nor the politics in power, nor the mass media, nor business, nor the law nor even the military are in a position to define or control risks rationally.<br /><b>Ulrich Beck</b>",
"I'm convinced my cockroaches have military training, I set off a roach bomb - they diffused it.<br /><b>Jay London</b>",
"Military leaders aren't made. They are born. To be a good leader, you have to have something in your character to cause people to follow you.<br /><b>Jimmy Johnson</b>",
"Meanwhile, our young men and women whose economic circumstances make military service a viable career choice are dying bravely in a war with no end in sight.<br /><b>Charles Rangel</b>",
"The People's Republic of China has not yet reached the military might of the Soviet Empire. It requires a little more time and a little more infusion of Western aid, loans, technology and the hard currency of our tourists.<br /><b>Barbara Amiel</b>",
"There are, of course, all sorts of other unpleasant regimes outside the walls as well - the military dictators of Latin America and the apartheid regime of South Africa.<br /><b>Barbara Amiel</b>",
"If the military might of Germany and Japan are ultimately to be crushed, the United Nations, one and all, must definitely and urgently strive toward a total war effort.<br /><b>William Lyon Mackenzie King</b>",
"Airplanes are interesting toys, but of no military value.<br /><b>Ferdinand Foch</b>",
"Native Americans had only stone and wooden weapons and no animals that could be ridden. Those military advantages repeatedly enabled troops of a few dozen mounted Spaniards to defeat Indian armies numbering in the thousands.<br /><b>Jared Diamond</b>",
"I thought what the military was doing was unconstitutional.<br /><b>Fred Korematsu</b>",
"On the battlefield, the military pledges to leave no soldier behind. As a nation, let it be our pledge that when they return home, we leave no veteran behind.<br /><b>Dan Lipinski</b>",
"The world must know that America holds to the highest standards of military conduct and human rights protections. Anything less is unacceptable.<br /><b>Barbara Mikulski</b>",
"A major power can afford a military debacle only when it looks like a political victory.<br /><b>Friedrich Durrenmatt</b>",
"We don't know what may yet happen to us, what military and political defeats we may yet have to face.<br /><b>Moshe Sharett</b>",
"No, no, I never despair, because George Bush is not running the universe. He may be running the United States, he may be running the military, he may be running even the world, but he is not running the universe, he is not running the human heart.<br /><b>Martin Sheen</b>",
"We want to look at how we would respond because, as hard as we work to prevent terrorist attacks here North America, if we have a catastrophic terrorist attack, it is the military that is going to have to go in at the request of civilian authorities.<br /><b>Paul Cellucci</b>",
"To win the cause we all believe in, the spread of true democracy all over the world, we need to win by example, not just with speeches but by example; not just with military might but by gaining the respect of the world.<br /><b>Barbara Boxer</b>",
"As Commander in Chief of the United States Military, I will never send our sons and daughters and our brothers and sisters to die in a foreign land without telling the truth about why they're going there.<br /><b>Howard Dean</b>",
"As a former veteran, I understand the needs of veterans, and have been clear - we will work together, stand together with the Administration, but we will also question their policies when they shortchange veterans and military retirees.<br /><b>Solomon Ortiz</b>",
"We all know that in war the political and military factors have to complement each other.<br /><b>Nguyen Cao Ky</b>",
"History offers no evidence for the proposition that the assignment of women to military combat jobs is the way to win wars, improve combat readiness, or promote national security.<br /><b>Phyllis Schlafly</b>",
"Several studies, and a number of public statements by senior military and political personalities, testify that - except for disputes between the present nuclear states - all military conflicts, as well as threats to peace, can be dealt with using conventional weapons.<br /><b>Joseph Rotblat</b>",
"There are a lot of things that have to be considered in National. The military aspect of it is only one of them. I'm confident that President Bush will have all of those things laid out for him before he makes the decision.<br /><b>Hugh Shelton</b>",
"There was no place at all for me in my father's military world.<br /><b>Gloria Swanson</b>",
"But Canada remains a crucial partner in this global war on terrorism, and we are grateful for that Canadian naval vessels, aircraft and military personnel continue anti-terrorist operations in the Persian Gulf.<br /><b>Paul Cellucci</b>",
"But if you're going to go out on a military unit, you've got to allow yourself to be under the control of the commander because you really could put the troops in danger.<br /><b>Bob Schieffer</b>",
"My first few films were institutional comedies, and you're on pretty safe ground when you're dealing with an institution that vast numbers of people have experienced: college, summer camp, the military, the country club.<br /><b>Harold Ramis</b>",
"Every one of our greatest national treasures, our liberty, enterprise, vitality, wealth, military power, global authority, flow from a surprising source: our ability to give thanks.<br /><b>Tony Snow</b>",
"To honor our national promise to our veterans, we must continue to improve services for our men and women in uniform today and provide long overdue benefits for the veterans and military retirees who have already served.<br /><b>Solomon Ortiz</b>",
"We ought to recognize that we have an offensive responsibility to take the war to the terrorists where they are. That responsibility has waned in the last year as military and intelligence resources were withdrawn from Afghanistan and Pakistan to be used in Iraq.<br /><b>Bob Graham</b>",
"Putting women in military combat is the cutting edge of the feminist goal to force us into an androgynous society.<br /><b>Phyllis Schlafly</b>",
"All governments in all wars have used all the means at their disposal to put their own motives, decisions and actions, and the actions of their military forces, in the best possible light.<br /><b>Bruce Jackson</b>",
"This Administration has led us into an area without vision. Bush has no clear understanding of what is being asked of the citizens, and the military is under his direction.<br /><b>Martin Sheen</b>",
"Putting together a counter- terrorism policy, it's very easy to look at law enforcement or defense, military action or stopping the money flows or whatever, but the really difficult part is integrating all aspects of the policy, and I think she put a lot of emphasis on that.<br /><b>Lee H. Hamilton</b>",
"The current stage does not allow the entrance of everyone into a military conflict, however everyone must be ready for the day in which it might take place, as the Zionist enemy is planning to attack our people and to control our land once again.<br /><b>Ahmed Yassin</b>",
"Ronald Reagan was a president of strength. His philosophy was a philosophy of strength - a strong military, a strong economy and strong families.<br /><b>Mitt Romney</b>",
"Also a great part of Polish industry proved to have existed only to support the Soviet military industry, and it became superfluous and incapable of being transformed into anything else. We did not foresee that or the magnitude of these phenomena.<br /><b>Andrzej Wajda</b>",
"The veterans of our military services have put their lives on the line to protect the freedoms that we enjoy. They have dedicated their lives to their country and deserve to be recognized for their commitment.<br /><b>Judd Gregg</b>",
"It is an exaggeration to call the Hamas and Islamic Jihad announcement a military alliance. It is rather a message that our people are united in the face of Israeli aggression.<br /><b>Ahmed Yassin</b>",
"In view of China's growing military strength and intentions, the best way to safeguard Asia's permanent peace and prosperity is to have all Asian countries join forces with other democratic countries in the world to form a global community of democracies.<br /><b>Jim Costa</b>",
"At their core, Americans all want the same basic things: a quality education for their children, a good job so they can provide for their families, healthcare and affordable prescription drugs, security during retirement, a strongly equipped military and national security.<br /><b>Ruben Hinojosa</b>",
"It matters not what your individual position is on either war we are currently prosecuting - in Iraq or Afghanistan - certainly we can all agree protesting at military funerals is a cruel and unnecessary hardship on our military families during their most difficult hour.<br /><b>Solomon Ortiz</b>",
"And I have to tell you as a grandmother, I worry about the fact that my grandchildren are going to be paying for all the spending, including military spending, that has gone on and the tax cuts that have come through.<br /><b>Geraldine Ferraro</b>",
"We had training camp for a week, and we used the actual military drills of that period. We didn't have to work out much after hours, because going up and down hills all day was a good workout in itself.<br /><b>Tom Berenger</b>",
"The War on Drugs employs millions - politicians, bureaucrats, policemen, and now the military - that probably couldn't find a place for their dubious talents in a free market, unless they were to sell pencils from a tin cup on street corners.<br /><b>L. Neil Smith</b>",
"If I had undertaken the practical direction of military operations, and anything went amiss, I feared that my conscience would torture me, as guilty of the fall of my country, as I had not been familiar with military tactics.<br /><b>Lajos Kossuth</b>",
"When you are covering a life-or-death struggle, as British reporters were in 1940, it is legitimate and right to go along with military censorship, and in fact in situations like that there wouldn't be any press without the censorship.<br /><b>Kate Adie</b>",
"Love is a kind of military service.<br /><b>Latin proverb</b>",
"Putting aside all the fancy words and academic doubletalk, the basic reason for having a military is to do two jobs-to kill people and to destroy the works of man.<br /><b>Thomas S. Power</b>",
"One of the most important factors, not only in military matters but in life as a whole, is ... the ability to direct one's whole energies towards the fulfillment of a particular task.<br /><b>Field Marshal Erwin Rommel</b>",
"Courage which goes against military expediency is stupidity, or, if it is insisted upon by a commander, irresponsibility.<br /><b>Field Marshal Erwin Rommel</b>",
);

/*****
ATTENTION -
Do not edit below this line unless you know what you are doing.
*****/

echo $quotes[rand(0, count($quotes) - 1)];

?>
</div>

