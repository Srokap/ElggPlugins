<?php	
	/**
	* CustomStyle
	* 
	* @package customstyle
	* @author ColdTrick IT Solutions
	* @copyright Coldtrick IT Solutions 2009
	* @link http://www.coldtrick.com/
	*/
?>

/* customstyle color configuration view */
.customstyle th {
	font-weight: bold;
	padding-top: 5px;
}

#style_change{
	text-align:right;
	position:relative;
	height: 0px;
	margin-right:20px;	
}