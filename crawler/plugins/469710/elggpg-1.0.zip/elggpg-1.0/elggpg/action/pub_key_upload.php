<?php

	/**
	 * Elgg profile plugin upload new user icon action
	 * 
	 * @package ElggProfile
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @copyright Curverider Ltd 2008-2010
	 * @link http://elgg.com/
	 */

	gatekeeper();
	
putenv("GNUPGHOME=".elggpg_get_gpg_home());
$gpg = new gnupg();


//require_once('Crypt/GPG.php');
//$gpg = new Crypt_GPG(array('homedir' => elggpg_get_gpg_home()));


	$user = page_owner_entity();
	if (!$user)
		$user = $_SESSION['user'];
		
	// If we were given a correct icon
		if (
				(isloggedin()) &&
				($user) &&
				($user->canEdit())
			) {
				$text = get_uploaded_file('public_key');
				if ($text !== false) {
					//$gpg->deletePublicKey($user->email);
					//$gpg->importKey($text);
					$gpg->deletekey($user->email);
					$gpg->import($text);
					add_to_river('river/elggpg/update','addkey',$user->getGUID(),$user->getGUID());
					system_message(elgg_echo("elggpg:public_key:imported"));
				} else {
					system_message(elgg_echo("elggpg:public_key:notfound"));
				}
				
			} else {
				
				system_message(elgg_echo("elggpg:public_key:notfound"));
				
			}
			
	    //forward the user back to the upload page to crop
	    
	    $url = "pg/gpg/managekey";
			
		if (isloggedin()) forward($url);

?>
