<script type="text/javascript" src='<?php echo $vars['url']; ?>mod/elggpg/js/firegpgapi.js' />

