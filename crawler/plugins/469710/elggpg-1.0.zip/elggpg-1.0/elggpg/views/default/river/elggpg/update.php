<?php

	$performed_by = get_entity($vars['item']->subject_guid); // $statement->getSubject();
        $string = "".$vars['item'];
	if ($performed_by) {
	  $url = "<a href=\"{$performed_by->getURL()}\">{$performed_by->name}</a>";
	  $string .= sprintf(elgg_echo("elggpg:river:".$vars['item']->action_type), $url) . " ";
	}
	echo $string;
?>
