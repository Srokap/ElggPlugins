<?php

	/**
	 * Elgg gpg plugin
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Rhizomatik
	 * @copyright Pablo Martin 2010
	 * @link http://bitbucket.org/rhizomatik/elggpg/
	 * 
	 * @uses $vars['user'] The user entity
	 * @uses $vars['url'] The site url
	 */

	// user is passed to view and set by caller (normally the page editicon)
	$currentuser = $vars['user'];

?>
<!-- grab the required js for icon cropping -->
<div id='firegpg-node'></div>
<div class="contentWrapper">
<!--
<script type="text/javascript">
$(document).ready(function () {
	if(fireGPGHello() == true) {
		var akf = 'gN3VhAUi9KJ2QlNY8KCbotXdFxRgSdUYYWKZChnIZjNxBuqp2yTqH4hO436rwGe0HKnUx3jLudbWCJEa4EKleqnA74m3ZJK12';
		if (fireGPGAuth(akf)) {
		}
		else {
			akf = fireGPGRegister();
		}
		/*var res = fireGPGSign(akf, "foo");
		if (res.sign_ok) {
		var signed = document.getElementById('signed');
			signed.innerHTML = res.text
			
		}
		res = fireGPGSign(akf, "foo");
		if (res.sign_ok) {
		signed = document.getElementById('signed');
			signed.innerHTML += res.text
		}*/
	}
})
</script>
-->
<p><?php echo elgg_echo('elggpg:profileinstructions'); ?></p>

<div id="current_user_avatar">

	<label><?php echo elgg_echo('elggpg:identity'); ?></label>
	<?php 
		
		$user_avatar = $currentuser->getIcon('medium');
		echo "<img src=\"{$user_avatar}\" alt=\"avatar\" />";

	?>

</div>
<?php
// new class
putenv("GNUPGHOME=".elggpg_get_gpg_home());
$gnupg = new gnupg();
//require_once 'Crypt/GPG.php';
//$gpg = new Crypt_GPG(array('homedir' => elggpg_get_gpg_home()));
$user = $currentuser;
echo $user->email.":\n";
$has_key = false;
try {
  echo "<p>";
  $info = $gnupg->keyinfo($user->email);
  $fingerprint = $info[0]['subkeys'][0]['fingerprint'];
  //echo var_dump($info[0]);
  //$fingerprint = $gpg->getFingerPrint($user->email, Crypt_GPG::FORMAT_CANONICAL);
  if (strlen($fingerprint) > 1) {
  echo "<b>".$fingerprint."</b>";
  	echo "<a href='".$vars['url'].'pg/gpg/raw/'.$user->username."'> [".elgg_echo('elggpg:download')."]</a><br/>";
  $subkeys = $info[0]['subkeys'];
  //$keys = $gpg->getKeys($user->email);
  //foreach ($keys as $key) {
    //$subkeys = $key->getSubKeys();
     foreach ($subkeys as $subkey) {
       if ($subkey['can_encrypt'])
       //if ($subkey->canEncrypt())
          echo elgg_echo('elggpg:date').": ".date('M Y',$subkey['timestamp'])."<br/><br/>";
     }
  //}
  echo "</p>";
	  $has_key = true;
  }
  else
  echo elgg_echo("elggpg:nopublickey");
}
catch (Exception $e) {
  echo elgg_echo("elggpg:nopublickey");
}
?>
<?php
if ($currentuser == $_SESSION['user']) {
?>

<div id="profile_picture_form">
	<form action="<?php echo $vars['url']; ?>action/elggpg/pub_key_upload" method="post" enctype="multipart/form-data">
	<?php echo elgg_view('input/securitytoken'); ?>
	<input type="hidden" name="username" value="<?php echo $currentuser->username; ?>" />
	<div><label><?php echo elgg_echo("elggpg:upload"); ?></label><br />
	
		<?php
			
			echo elgg_view("input/file",array('internalname' => 'public_key'));
		?>
		<input type="submit" class="submit_button" value="<?php echo elgg_echo("upload"); ?>" />
	</div>
	</form>
</div>
<?php
}
if ($has_key) {
	echo elgg_view('elggpg/forms/send',array('currentuser'=>$currentuser));
}
try {
  // encrypt some test data for the user
  //echo $gpg->exportPublicKey($user->email);
  //echo "</p></pre>";
  $gnupg->addencryptkey($user->email);
  echo "<pre>".$gnupg->encrypt("just for you!")."</pre>";
  //$gpg->addEncryptKey($user->email);
}
catch (Exception $e) {
}
?>
<div id="signed"></div>
<div class="clearfloat"></div>
</div>
