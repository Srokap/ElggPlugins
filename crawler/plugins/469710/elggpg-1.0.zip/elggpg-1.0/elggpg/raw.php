<?php
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

//require_once 'Crypt/GPG.php';

header("Content-type: text/plain");

if (!isloggedin()) {
                forward();
        }

$user = get_entity(get_input('user'));

//$gpg = new Crypt_GPG(array('homedir' => elggpg_get_gpg_home()));
//echo $gpg->exportPublicKey($user->email);
putenv("GNUPGHOME=".elggpg_get_gpg_home());
$gnupg = new gnupg();
echo $gnupg->export($user->email);

?>
