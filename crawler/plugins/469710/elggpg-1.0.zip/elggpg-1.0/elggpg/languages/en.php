<?php

	$english = array(
		'elggpg:profileinstructions'=>'This is your public key information',
		'elggpg:identity'=>'Associated identity',
		'elggpg:manage'=>'Manage encryption',
		'elggpg:download'=>'Download',
		'elggpg:date'=>'Date',
		'elggpg:size'=>'Size',
		'elggpg:river:addkey'=>'%s uploaded her gpg key',
		'elggpg:public_key:imported'=>'Key imported',
		'elggpg:sendamessage'=>'Send an encrypted message',
		'elggpg:view'=>'View encryption keys',
		'elggpg:nopublickey'=>'User has no public key',
		'elggpg:manage:header'=>'GPG Public Key',
		'elggpg:upload'=>'Upload a new public key'
	);
					
	add_translation("en",$english);

?>
