<?php

// Generado por translationbrowser 

$spanish = array( 
                'elggpg:profileinstructions'=>'Informacion acerca de tu llave publica',
                'elggpg:identity'=>'Identidad asociada',
                'elggpg:manage'=>'Encriptacion',
                'elggpg:download'=>'Descargar',
                'elggpg:river:addkey'=>'%s ha subido su llave gpg',
                'elggpg:public_key:imported'=>'Llave importada',
                'elggpg:date'=>'Fecha',
                'elggpg:size'=>'Bits',
                'elggpg:sendamessage'=>'Enviar un mensaje encriptado',
                'elggpg:view'=>'Ver llaves de encriptacion',
                'elggpg:nopublickey'=>'Esta persona no tiene ninguna llave gpg',
                'elggpg:manage:header'=>'LLave publica gpg',
                'elggpg:upload'=>'Subir una llave nueva'

); 

add_translation('es', $spanish); 

?>
