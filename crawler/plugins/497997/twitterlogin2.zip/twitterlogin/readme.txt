As Twitter's OAuth support is still in beta - use this plugin at your own risk.

Please note: If Twitter shutdown OAuth athentication for any reason, users on your site who have 
sign in with twitter will no longer have access to your site until Twitter bring their OAuth support back online.

To use:

1) Go to Twitter and register your site to obtain a login key and secret

2) The call back URL you need is path-to-your-elgg/action/twitterlogin/return

3) Enable the plugin and you are ready to go