#twitterlogin-box {
	padding: 10px 10px 10px 10px;
}

.toolbarimages .user_mini_avatar {
	width:16px;
	height:16px;
}