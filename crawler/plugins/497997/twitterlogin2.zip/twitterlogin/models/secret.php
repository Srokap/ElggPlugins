<?php
$login_key = get_plugin_setting('login_key', 'twitterlogin');
$login_secret = get_plugin_setting('login_secret', 'twitterlogin');

$consumer_key = get_plugin_setting('login_key', 'twitterlogin');
$consumer_secret = get_plugin_setting('login_secret', 'twitterlogin');

//'99hq3Q5qY7ubtTPEHs9AA'
//'m2AG3em85UIFji1DFq5uqw87ROEIInUie1NOXb0g18'
?>
