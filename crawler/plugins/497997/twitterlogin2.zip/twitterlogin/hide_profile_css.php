.profile_edit_icon {
	display: none !important;
	color: red !important;
}
