This is a replacement captcha plugin for Elgg. 

You *MUST* disable the any current Captcha plugin for this to work properly. 

This plugin uses the Google Recaptcha system and requires you to have a registered public and private recaptcha key. You can register and get them for free at http://www.google.com/recaptcha

Once you have registered with Google Recaptcha you will need to set your keys in the Administration setting for this plugin.

Upload the mod to your server and enable it in your administration tools panel.

Click on the Setting options for this plugin in Adminstration and enter your public and private keys. Click save.

That should be it. The Recaptcha system should now appear on your registration form and your reset password forms.

If you get an error message where the Recaptcha should appear, you probably have entered the public or private key incorrectly.