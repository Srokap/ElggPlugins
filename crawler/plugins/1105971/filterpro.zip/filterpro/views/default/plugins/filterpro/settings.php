<?php 

// SW Social Web LLC
// SW Social Web Rules!!!

$filter_setting = $vars['entity']->filter_filter;
$jpg_filter_setting = $vars['entity']->jpg_filter;
$word_filter_setting = $vars['entity']->word_filter;
$excel_filter_setting = $vars['entity']->excel_filter;
$mp3_filter_setting = $vars['entity']->mp3_filter;
$pdf_filter_setting = $vars['entity']->pdf_filter;


?>


<p>
  <b>Do you want to Filter File Types?</b>

<?php

echo elgg_view('input/dropdown',array(
'name' => 'params[filter_filter]', 
'options_values'=> array( '0' => '  ', '1'=>'Yes','2'=>'No'),
'value'=> $filter_setting));

 ?>
</p>
<?php

if ($filter_setting == 1)
{ 
?>
<p>
  <b>Do you want to allow JPG files?</b>

<?php

echo elgg_view('input/dropdown',array(
'name' => 'params[jpg_filter]', 
'options_values'=> array( '0' => '  ', '1'=>'Yes','2'=>'No'),
'value'=> $jpg_filter_setting));

 ?>
</p>

<p>
  <b>Do you want to allow MS Word Documents?</b>

<?php

echo elgg_view('input/dropdown',array(
'name' => 'params[word_filter]', 
'options_values'=> array( '0' => '  ', '1'=>'Yes','2'=>'No'),
'value'=> $word_filter_setting));

 ?>
</p>

<p>
  <b>Do you want to Allow MS Excel Documents?</b>

<?php

echo elgg_view('input/dropdown',array(
'name' => 'params[excel_filter]', 
'options_values'=> array( '0' => '  ', '1'=>'Yes','2'=>'No'),
'value'=> $excel_filter_setting));

 ?>
</p>

<p>
  <b>Do you want to Allow PDf Documents?</b>

<?php

echo elgg_view('input/dropdown',array(
'name' => 'params[pdf_filter]', 
'options_values'=> array( '0' => '  ', '1'=>'Yes','2'=>'No'),
'value'=> $pdf_filter_setting));

 ?>
</p>


<p>
  <b>Do you want to Allow MP3 files?</b>

<?php

echo elgg_view('input/dropdown',array(
'name' => 'params[mp3_filter]', 
'options_values'=> array( '0' => '  ', '1'=>'Yes','2'=>'No'),
'value'=> $mp3_filter_setting));

 ?>
</p>


<?php
}
?>