<?php
	/**
	* likes
	*
	* @author likes
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	$chinese = array(
			'likes:admin' => 'Like Settings',
			'likes:admin:subtitle' => 'Do you like show the "like this" button for...',
			
			'like:show:thewire' => 'the wire on the river?',
			'like:show:messageboard' => 'messageboard on the river?',
			'like:show:bookmarks' => 'bookmarks on the river?',
			'like:show:blog' => 'blog on the river?',
			'like:show:file' => 'file on the river?',
			'like:show:page' => 'page on the river?',
			'like:show:topic' => 'discussion topic on the river?',
			'like:show:essay' => 'essays on the river?',
			'like:show:poll' => 'polls on the river?',
			'like:show:event' => 'events on the river?',
			'like:show:test' => 'tests on the river?',
			'like:show:news' => 'news on the river?',
			
			'like' => '喜欢',
			'unlike' => 'Unlike',
	
			'like:youlikethis' => '你喜欢.',
			'like:otherlikesthis' => '%s 喜欢.',
	
			'like:otherandyoulikethis' => '你和 %s 喜欢.',
			'like:others2likethis' => '%s 和 %s 喜欢.',
	
			'like:others' => '%s others',
	
			'like:lotofpeoplelikethis' => '%s 人喜欢.',
			'like:youandalotofpeoplelikethis' => '你和 %s 喜欢.',
	
			/*Actions*/
			'like:posted' => '您的意见已成功发表.',
			'like:failure' => '您的选择出现未知错误，请再试一次.',

			'like:deleted' => '您已经成功改变了您的意见.',
			'like:notdeleted' => '抱歉，您的选择无法更改.',
	
	);
					
	add_translation("zh",$chinese);
?>