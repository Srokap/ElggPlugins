<?php
	/**
	* dislikes
	*
	* @author dislikes
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	$chinese = array(
			'dislikes:admin' => 'Dislike Settings',
			'dislikes:admin:subtitle' => 'Do you dislike show the "dislike this" button for...',
			
			'dislike:show:thewire' => 'the wire on the river?',
			'dislike:show:messageboard' => 'messageboard on the river?',
			'dislike:show:bookmarks' => 'bookmarks on the river?',
			'dislike:show:blog' => 'blog on the river?',
			'dislike:show:file' => 'file on the river?',
			'dislike:show:page' => 'page on the river?',
			'dislike:show:topic' => 'discussion topic on the river?',
			'dislike:show:essay' => 'essays on the river?',
			'dislike:show:poll' => 'polls on the river?',
			'dislike:show:event' => 'events on the river?',
			'dislike:show:test' => 'tests on the river?',
			'dislike:show:news' => 'news on the river?',			
			
			'dislike' => '不喜欢',
			'undislike' => '改变主意',
	
			'dislike:youdislikethis' => '你不喜欢.',
			'dislike:otherdislikesthis' => '%s 不喜欢.',
	
			'dislike:otherandyoudislikethis' => '你和 %s 不喜欢.',
			'dislike:others2dislikethis' => '%s 和 %s 不喜欢.',
	
			'dislike:others' => '%s others',
	
			'dislike:lotofpeopledislikethis' => '%s 人不喜欢.',
			'dislike:youandalotofpeopledislikethis' => '你和 %s 不喜欢.',
	
			/*Actions*/
			'dislike:posted' => '您的意见已经发表成功',
			'dislike:failure' => '您的选择出现未知错误，请再试一次.',

			'dislike:deleted' => '您已经成功改变了您的意见.',
			'dislike:notdeleted' => '抱歉，您的选择无法更改.',
	
	);
					
	add_translation("zh",$chinese);
?>