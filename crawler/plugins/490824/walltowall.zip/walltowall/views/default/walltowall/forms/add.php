<?php

    /**
	 * Elgg Message board add form
	 * 
	 * @package ElggMessageBoard
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */
	 
?>
<div id="mb_input_wrapper">
<?php
$form_body .= elgg_view('input/text', array('internalname' => 'message_content', 'value' => ''));
$form_body .= elgg_view('input/hidden', array('internalname' => 'guid', 'value' => $_SESSION['guid']));
$form_body .= elgg_view('input/hidden', array('internalname' => 'pageOwner', 'value' => page_owner()));
$form_body .= elgg_view('input/hidden', array('internalname' => 'pageOwner', 'value' => $vars['poster']));
$form_body .= elgg_view('input/hidden', array('internalname' => 'pageOwner', 'value' => $vars['poster']));
$form_body .= elgg_view('input/submit', array('internalname' => 'messageboard:postit','value'=>'Post It'));
$action_url = "{$CONFIG->url}action/walltowall/add";
 
echo elgg_view('input/form', array('body' => $form_body, 'action' => $action_url));
?>

</div>
