<?php
/**
 * bit.ly extensions to Elgg's CSS
 */
?>

.bitly-wrapper {
	text-align: right;
}

#bitly-input {
	padding: 3px;
}