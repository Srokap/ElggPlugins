<?php
		
	function wookie_init(){
			add_widget_type('wookie', 'Wookie', 'Wookie widgets');
	}

	// Initialise
	register_elgg_event_handler('init','system','wookie_init');

?>
