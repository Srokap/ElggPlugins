<h5>URL to Wookie: <input type="text" name="params[wookie_url]" value="<?= $vars['entity']->wookie_url ?>" size="50"></h5>
<h5>API Key: <input style="margin-left:49px;" type="text" name="params[wookie_api_key]" value="<?= $vars['entity']->wookie_api_key ?>" size="50"></h5>
