<?php

require_once('functions.php');

## using highslide instead of facebox (which comes shipped with elgg) because it is richer in functionality
## highslide js/css
echo '
	<script type="text/javascript" src="../../mod/wookie/views/default/widgets/wookie/highslide/highslide-full.packed.js"></script>
	<script type="text/javascript" src="../../mod/wookie/views/default/widgets/wookie/highslide/highslide.config.js" charset="utf-8"></script>
	<link rel="stylesheet" type="text/css" href="../../mod/wookie/views/default/widgets/wookie/highslide/highslide.css" />
	<!--[if lt IE 7]>
	<link rel="stylesheet" type="text/css" href="../../mod/wookie/views/default/widgets/wookie/highslide/highslide-ie6.css" />
	<![endif]-->
';

## fading out/in of widgets after expanding/closing
echo '
	<script type="text/javascript">
		hs.Expander.prototype.onAfterExpand = function(sender) {
			widget_id = sender.headingId.match(/\d+/);
			$(\'#widget\' + widget_id).fadeTo(1000, 0.33);
		};
		hs.Expander.prototype.onBeforeClose = function(sender) {
			widget_id = sender.headingId.match(/\d+/);
			$(\'#widget\' + widget_id).fadeTo(700, 1.00);
		};
	</script>
';

## pass global $vars
$widget = new elggWookieWidget($vars);

echo '
	<a
		href="' . $widget->getWidgetParameter('url') . '"
		onclick="return hs.htmlExpand(this, { 
			objectType: \'iframe\',
			t: \'test\',
			width: \'700\',
			height: \'525\',
			slideshowGroup: \'wookie-widgets\',
			headingText: \'' . addslashes($widget->getWidgetParameter('title')) . '\',
			wrapperClassName: \'titlebar\' } )">
				<img
					id="enlarge' . $vars['entity']->getGUID() . '"
					style="display:none; position:absolute;"
					onmouseover="$(this).stop()"
					onmouseout="$(this).fadeOut(500)"
					src="../../mod/wookie/views/default/widgets/wookie/enlarge.png"
					alt="enlarge"
					width="13"
					height="12"
					border="0"
				/>
	</a>
';

if ($vars['entity']->wookie_widget_guid) {
	echo '
		<iframe
			style="border:none"
			onmouseover="$(\'#enlarge' . $vars['entity']->getGUID() . '\').stop().fadeIn(500)"
			onmouseout="$(\'#enlarge' . $vars['entity']->getGUID() . '\').fadeOut(500)"
			src="' . $widget->getWidgetParameter('url') . '"
			height="' . $widget->getWidgetParameter('height') . '"
			width="' . $widget->getWidgetParameter('width') . '">
		</iframe>
	';
} else {
	echo '<p style="margin:10px">Please select a widget.</p>';
}

?>
