<?php

require_once('functions.php');

echo '<input type="hidden" name="params[title]" id="widget_type" value="' . htmlentities($vars['entity']->title) . '" />';

## not needed if there is a select box
//echo 'GUID: <input type="text" name="params[wookie_widget_guid]" value="' . $vars['entity']->wookie_widget_guid . '" /> <br />';

$widgetGallery = new Gallery($vars);
echo $widgetGallery->showGallery();

echo 'Width: <input type="text" size="4" maxlength="4" name="params[wookie_widget_width]" value="' . $vars['entity']->wookie_widget_width . '" /> px<br />';

echo 'Height: <input type="text" size="4" maxlength="4" name="params[wookie_widget_height]" value="' . $vars['entity']->wookie_widget_height . '" /> px';

?>
