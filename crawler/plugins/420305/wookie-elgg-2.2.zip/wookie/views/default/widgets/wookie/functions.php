<?php

require_once('wookie_xml.php');

## url to wookie engine (as set in tool administration)
$vars['entity']->wookie_url = get_plugin_setting('wookie_url', 'wookie');
if (strrchr($vars['entity']->wookie_url, '/') != '/') {
	$vars['entity']->wookie_url .= '/';
}

## the requested api key (as set in tool administration)
$vars['entity']->wookie_api_key = get_plugin_setting('wookie_api_key', 'wookie');


class elggWookieWidget {

	## widget instace
	private $widget;

	## servicetype
	private $type;

	## elgg user variables
	private $userID = '';
	private $username = '';
	private $src;

	## global vars
	private $vars;


	function __construct($vars) {

		$this->vars = $vars;

		$user = $_SESSION['user'];
		if  (!is_null($user)){
			$this->userID = $user->getGUID();
			if  (!is_null($this->userID)){
				$this->username = get_user($this->userID)->name;
				$this->src = get_user($this->userID)->getIcon();
			}
		}

		//??? seems to be empty all the time
		$this->type = $this->vars['entity']->title;

		## instantiate widget
		$this->widget = $this->getWidget();

		## add openid identifier to widget url
		if ($vars['user']->alias) {
			$this->widget['widgetdata']['url'] .= '&openid_identifier=' . $vars['user']->alias;
		}

		$this->addParticipant();

		$this->setPersonalProperty('username', urlencode($this->username));

		//need to do access check here
		if (page_owner() == $this->userID){
			$this->setPersonalProperty('moderator', 'true');
		}

	}


	## parameters: url, title, height, width, maximize
	public function getWidgetParameter($param) {
		$vars_param = "wookie_widget_$param";

		if ($this->vars['entity']->$vars_param) {
			return $this->vars['entity']->$vars_param;
		}

		return $this->widget['widgetdata'][$param];
	}


	public function getWidget() {
		$request = $this->vars['entity']->wookie_url;
		$request.= 'WidgetServiceServlet?';
		$request.= 'requestid=getwidget';
		$request.= '&api_key='.$this->vars['entity']->wookie_api_key;
		$request.= '&servicetype='.$this->type;
		$request.= '&widgetid='.$this->vars['entity']->wookie_widget_guid;
		$request.= '&userid='.$this->userID;
		$request.= '&shareddatakey='.$this->vars['entity']->getGUID();

		$response = file_get_contents($request);

		return XML_unserialize($response);
	}


	public function setPersonalProperty($name, $value) {
		$request = $this->vars['entity']->wookie_url;
		$request.= 'WidgetServiceServlet?';
		$request.= 'requestid=setpersonalproperty';
		$request.= '&api_key='.$this->vars['entity']->wookie_api_key;
		$request.= '&servicetype='.$this->type;
		$request.= '&widgetid='.$this->vars['entity']->wookie_widget_guid;
		$request.= '&userid='.$this->userID;
		$request.= '&shareddatakey='.$this->vars['entity']->getGUID();
		$request.= '&propertyname='.$name;
		$request.= '&propertyvalue='.$value;

		return file_get_contents($request);
	}


	public function addParticipant() {
		$request = $this->vars['entity']->wookie_url;
		$request.= 'WidgetServiceServlet?';
		$request.= 'requestid=addparticipant';
		$request.= '&api_key='.$this->vars['entity']->wookie_api_key;
		$request.= '&servicetype='.$this->type;
		$request.= '&widgetid='.$this->vars['entity']->wookie_widget_guid;
		$request.= '&userid='.$this->userID;
		$request.= '&shareddatakey='.$this->vars['entity']->getGUID();
		$request.= '&participant_id='.$this->userID;
		$request.= '&participant_display_name='.$this->username;
		$request.= '&participant_thumbnail_url='.$this->src;

		return file_get_contents($request);
	}


}


## adapted from the moodle plugin
class Gallery {

	private $vars;

	function __construct($vars) {
		$this->vars = $vars;
	}


	function showGallery(){
		$widgets = $this->getWidgets();

		$gallery = 'Select widget: <select name="params[wookie_widget_guid]">';
		$gallery .= '<option value="">[No widget selected]</option>';

		foreach ($widgets as $widget){
			unset($selected);
			if ($this->vars['entity']->wookie_widget_guid == $widget->id) {
				$selected = " selected";
			}
			$gallery .= "<option value='$widget->id'" . $selected . ">$widget->title</option>";
		}

		$gallery .= '</select><br />';

		return $gallery;
	}


	function getWidgets(){
		$request = $this->vars['entity']->wookie_url;
		$request.= 'advertise?all=true';
		$response = file_get_contents($request);
		$xml = XML_unserialize($response);
		$widgets = array();

		foreach ($xml['widgets']['widget'] as $data){
			// if there's an identifier, coin a new widget
			if ($data['identifier'] != ''){
				$widget = new Widget();
				$widget->id = $data['identifier'];
			} else {
				$widget->title = $data['title'];
				$widgets[] = $widget;
			}
		}

		return $widgets;
	}

}


class Widget {
	public $id;
	public $title;
	public $icon;
	public $description;
	public $type;
}

?>
