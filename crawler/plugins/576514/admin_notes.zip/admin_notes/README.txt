Admin Notes lets admins make notes about users and share the notes
with other admins.  The idea is to create a single spot where admins
can leave notes about actions they've taken, which can then be later referenced.

It can confusing when multiple admins maintain the same large site--Was 
this user already warned about inappropriate behavior?  Did someone help 
the user with a question?  How long ago did we tell this user to change 
his profile picture?  Admin Notes aims to make it a bit easier.
