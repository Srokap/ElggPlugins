<?php
/*******************************************************************************
 * fusion_lib_pack
 *
 * @author Fusion
 ******************************************************************************/

	function fusion_pack_init()
	{
		global $CONFIG;

        // extend some views
		extend_view('css','fusion_pack/css');
		extend_view('metatags','fusion_pack/metatags');

        return true;
	}

    register_elgg_event_handler('init', 'system', 'fusion_pack_init');
?>