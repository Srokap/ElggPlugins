<?php
	// start tipsy -->
    echo "<script type='text/javascript' src='" . $vars['url'] . "mod/fusion_pack/lib/tipsy/javascripts/jquery.tipsy.js'></script>";
    echo "<link rel='stylesheet' href='" . $vars['url'] . "mod/fusion_pack/lib/tipsy/stylesheets/tipsy.css' type='text/css' />";
    // end tipsy
?>
<script type='text/javascript'> 
  $(function() {

$('#elggchat_friends2 a img').tipsy({gravity: 's'});
$('#toggle_elggchat_toolbar').tipsy({gravity: 'w'});
$('#tooltip a img').tipsy({gravity: 's'});
$('.usericon a img').tipsy({gravity: 's'});

  });
</script>