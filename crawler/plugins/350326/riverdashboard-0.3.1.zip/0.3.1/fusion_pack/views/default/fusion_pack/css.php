<?php
/*
 * Css for fusion_lib_pack
 */
?>
.fusion_lib_pack_div {
	color: #000000;
}