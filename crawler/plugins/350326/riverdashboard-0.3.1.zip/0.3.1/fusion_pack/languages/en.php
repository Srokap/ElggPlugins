<?php
$english = array(

);

add_translation("en",$english);
?>