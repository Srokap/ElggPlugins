<?php
/*******************************************************************************
 * 3 column dashboard
 * 3 column riverdashboard Language Files
 *
 * @package 3 column dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fusion <contact@donkeydesigns.us>
 * @copyright TheFloridaCircle.com 2008-2009
 * @link http://www.thefloridacircle.com/
 *
 ******************************************************************************/
?>
<?php

	$english = array(
		/***  for comments  ***/
		'river:item:toggle_comments' => 'Comment',
		/***  end comments  ***/
		/*
		 *Fusion Mod
		 */
		 'river:viewall' => 'View All',
		 'river:groups:mygroup' => 'My Groups',
		 'river:share' => 'Share',
		 'river:recent' => 'Recent Discussions',
		 'riverdashboard:randommembers' => 'Random Members',
		 'river:next' => 'Next &gt;&gt;',
         'river:previous' => '&lt;&lt; Previous',
		 'river:mini:welcome' => 'Welcome',
		 'recent:visitors' => 'Recent Visitors',
		 'thewire:latest' => 'Latest',
		 /*
		  *Activity_view
		  */
		 'river:activity:add' => 'Add:',
		 'river:activity:post' => 'Post',
		 'river:newpost' => 'Whats on your mind?',
		 'river:created' => 'says:',
		 /** Tips **/
		 'river:tips:title' => 'Helpful Hints',
		 /*
		  *Share a link
		  */
		 'river:bookmarks:river:created' => '%s shared a link',
		 'river:bookmark:title' => 'Title',
		 'river:bookmarks:address' => 'Enter a complete URL eg.. http://somesite.com',
		 'river:bookmark:description' => 'Please enter a description for this link',
		 'river:bookmark:tags' => 'Enter relevant search tags',
		 'river:bookmark:share' => 'Share',
		 'river:bookmarks' => 'Bookmarks',
		 'river:save:success' => 'You have successfully shared a link',
		 'river:save:failed' => 'Your link could not be saved..  Please try again.',
		 /*
		  * videos
		  */
		 'river:video:upload' => 'Upload Video',
		 'river:video:videos' => 'Videos',
		 'river:video:add' => 'Add Video',
	     'river:video:supported' => 'From supported sites',
   	     'river:video:harddrive' => 'From your hardrive',
		 'river:latestvideos' => '<b>Latest</b>',
		 'river:topViewed' => '<b>Top Views</b>',
		 'river:topCommented' => '<b>Top Comments</b>',
		 /*
	      *photos
	      */
		  'river:photo:latest' => 'Latest Images',
		  'river:photo:photos' => 'Photos',
		  'river:photo:create' => 'Create an Album',
		  'river:photo:many' => 'With many photos', 
		  'river:photo:upload' => 'Upload Photos',
		  'river:mostviewed' => 'Most Viewed Photos',
		 /*
		  *polls
		  */
		  'river:poll:create' => 'Create a poll',
		  'river:poll' => 'Recent Site Polls',
		 /*
		  *events
		  */
		  'river:events:new' => 'Latest Events',
		 /*
		  *gifts
		  */
		  'river:gifts' => "%s sent a %s to %s",
		  'river:gift:gifts' => 'Send a Gift',
		 /*
          * Mini Profile
          */
		 'river:stats:currentcount' => "Profile Views: %s",
         'river:mini:hi' => 'Hi',
         'river:mini:edit' => 'Edit/Upload',
         'river:mini:blog' => 'Manage Blog',
         'river:mini:groups' => 'Manage Groups',
         'river:mini:invite' => 'Invite Your Friends',
         'river:mini:manage' => 'Manage Account',
         'river:mini:account' => 'Customize Account',
         'river:mini:custom_profile' => 'Customize Profile',
         'river:mini:profile_image' => 'Change Profile Image',
         'river:mini:edit_account' => 'Edit Account',
         'river:mini:account_settings' => 'Account Settings',
         'river:mini:notifications' => 'Notifications',
         'river:mini:edit_profile' => 'Edit Profile',
		 'river:mini:tools' => 'Configure Tools',

		 /* Settings */
         'riverdashboard:settings:newestmembers' => 'Show Newest Members?',
		 'riverdashboard:newestmembers:num' => 'Number of members to show?',
         'riverdashboard:settings:featured_groups' => 'Show Featured Groups?',
		 'riverdashboard:groups:num' => 'Number of groups to show?',
         'riverdashboard:settings:mygroups' => 'Show My Groups?',
         'riverdashboard:settings:sidebarTagcloud' => 'Show SidebarTagcloud?',
         'riverdashboard:settings:friends' => 'Show Friends?',
		 'riverdashboard:friends:num' => 'Number of friends to show?',
         'riverdashboard:settings:birthdaymembers' => 'Show Birthdaymembers?',
         'riverdashboard:settings:polls' => 'Show Polls?',
		 'riverdashboard:polls:num' => 'Number of polls to show?',
         'riverdashboard:settings:photocumulus' => 'Show Photo Cumulus?',
         'riverdashboard:settings:videos' => 'Show Videos?',
		 'riverdashboard:video:num' => 'Number of videos to show?',
         'riverdashboard:settings:recentview' => 'Show Recent Profile Views?',
		 'riverdashboard:recentv:num' => 'Number of recent visitors to show?',
		 'riverdashboard:settings:bookmarks' => 'Show Bookmarks?',
		 'riverdashboard:bookmarks:num' => 'Number of bookmarks to show?',
		 'riverdashboard:settings:events' => 'Show Events?',
		 'riverdashboard:settings:vanilla' => 'Show Recent Vanilla Forum Discussions?',
		 'riverdashboard:settings:topad' => 'Show Top Adverts? Size 468x60',
		 'riverdashboard:settings:leftad' => 'Show Left Adverts Box?',
		 'riverdashboard:settings:rightad' => 'Show Right Adverts Box?',
		 'riverdashboard:settings:adcode' => 'Enter your Advertisement code here',
		 'riverdashboard:settings:photos' => 'Show Photos?',
		 'photos:num:display' => 'Number of images to show?',
		 'riverdashboard:settings:site' => 'Show Site Messages?',
		 'riverdashboard:settings:tips' => 'Show Helpful Hints?',
		 /* feeds */
		 'riverdashboard:feeds:show' => 'Show a Feed',
		 'riverdashboard:feeds:allow' => 'Allow user feeds on dashboard?',
		 'riverdashboard:feeds:userallow' => 'Show a feed on dashboard?',
		 'riverdashboard:feed:url' => 'Enter the url for a feed you want to display.',
		 'riverdashboard:feed:items' => 'How many items from feed to display?',
		 'riverdashboard:feed:excerpt' => 'Show excerpts?',
		 /*** notifications ***/
		 'river:requests' => 'Notifications',
         /*
		  *End Fusion Mod
		  */

		'mine' => 'Mine',
		'filter' => 'Filter',
		'riverdashboard:useasdashboard' => "Replace the default dashboard with this activity river?",
		'activity' => 'Activity',
		'riverdashboard:recentmembers' => 'Recent members',
		
	
	    /**
	     * Site messages
           **/

		'sitemessages:announcements' => "Site announcements",
		'sitemessages:posted' => "Posted",
		'sitemessages:river:created' => "Site admin, %s,",
		'sitemessages:river:create' => "posted a new site wide message",
		'sitemessages:add' => "Add a site-wide message to the river page",
		'sitemessage:deleted' => "Site message deleted",
		
		'river:widget:noactivity' => 'We could not find any activity.',
		'river:widget:title' => "Activity",
		'river:widget:description' => "Show your latest activity.",
		'river:widget:title:friends' => "Friends' activity",
		'river:widget:description:friends' => "Show what your friends are up to.",
		'river:widgets:friends' => "Friends",
		'river:widgets:mine' => "Mine",
		'river:widget:label:displaynum' => "Number of entries to display:",
		'river:widget:type' => "Which river would you like to display? One that shows your activity or one that shows your friends activity?",
		'item:object:sitemessage' => "Site messages",
		'riverdashboard:avataricon' => "Would you like to use user avatars or icons on your site activity stream?",
		'option:icon' => 'Icons',
		'option:avatar' => 'Avatars',
	);
					
	add_translation("en",$english);

?>