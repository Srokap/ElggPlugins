<?php
if (is_plugin_enabled('event_calendar')){
/*******************************************************************************
 * 3 column dashboard
 * view for event calendar
 *
 * @package 3 column dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fusion <contact@donkeydesigns.us>
 * @copyright TheFloridaCircle.com 2008-2009
 * @link http://www.thefloridacircle.com/
 *
 ******************************************************************************/
   // Get the number of events to display
    $numToDisplay = get_plugin_setting('numToDisplay','riverdashboard');
   
   // Get the events

	$events = event_calendar_get_personal_events_for_user(page_owner(),$numToDisplay);
		
	// If there are any events to view, view them
	if (is_array($events) && sizeof($events) > 0) {

        echo "<div id=\"river_container2\">";
		echo "<div class=\"collapsable_box_header\"><h1>" .elgg_echo("river:events:new"). "</h1></div>";
		echo '<div class="collapsable_box_content">';
		echo '<div class="contentWrapper">';
		echo "<div id=\"widget_calendar\">";

		foreach($events as $event) {
			echo elgg_view("object/event_calendar",array('entity' => $event));
		}

		echo "</div>";
		echo '<div align="right"><a href="' .$vars['url']. 'pg/event_calendar">' .elgg_echo("river:viewall"). '</a></div>';
		echo "</div></div></div>";//closes river_container2 and dash_pad
    }

}
?>
