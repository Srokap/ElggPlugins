<?php
if(empty($vars['entity']->feed_url)) $vars['entity']->feed_url = "http://google.blogspace.com/rss";
$feedItems = $vars['entity']->feedItems;

    //check if admin is allowing feeds for users
    if(get_plugin_setting("feedAllow", "riverdashboard") != "no"){ 
	    // show some settings to the user
?>
    <?php echo '<h3>' . elgg_echo('riverdashboard:feeds:show') . '</h3>'; ?><br />
    <?php echo '<p>' . elgg_echo('riverdashboard:feeds:userallow'). '<br />'; ?>
	<select name="params[feedUserAllow]">
		<option value="yes" <?php if ($vars['entity']->feedUserAllow == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->feedUserAllow != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
    </p>
    <p>
    <?php echo elgg_echo('riverdashboard:feed:url') . elgg_view("input/text", array("internalname"=>"params[feed_url]", "value"=>$vars['entity']->feed_url));?>
   </p>
   <p>
   <?php echo elgg_echo('riverdashboard:feed:items'); ?><br />
   	<select name="params[feedItems]">
		<option value="1" <?php if ($feedItems == 1) echo " selected=\"yes\" "; ?>>1</option>
		<option value="3" <?php if ($feedItems == 3 || empty($feedItems)) echo " selected=\"yes\" "; ?>>3</option>
		<option value="5" <?php if ($feedItems == 5) echo " selected=\"yes\" "; ?>>5</option>
		<option value="7" <?php if ($feedItems == 7) echo " selected=\"yes\" "; ?>>7</option>
        <option value="10" <?php if ($feedItems == 10) echo " selected=\"yes\" "; ?>>10</option>
	</select>
   </p> 
   <p>
   <?php echo elgg_echo('riverdashboard:feed:excerpt'); ?><br />
   <select name="params[feedExcerpt]">
		<option value="yes" <?php if ($vars['entity']->feedExcerpt == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->feedExcerpt != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
   
   </p>
   <hr color="silver" /> 
<?php } ?>
  
