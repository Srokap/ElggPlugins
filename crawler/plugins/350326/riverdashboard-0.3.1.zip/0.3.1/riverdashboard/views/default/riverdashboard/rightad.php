<?php $rightads_title1 = get_plugin_setting('rightads_title1','riverdashboard'); ?>
<div id="river_container2">


<div class="collapsable_box_header">
<h1><?php echo $rightads_title1; ?></h1>
</div>
<div class="collapsable_box_content">
<div align="center" class="contentWrapper">

<?php
//allow people to extend this top menu
		echo elgg_view('rightad/extend', $vars);
$rightads_code = get_plugin_setting('rightads_code','riverdashboard');
	    echo $rightads_code;
?>

</div>
</div>
</div><!-- / river_container2 -->