<?php
/*******************************************************************************
 * 3 column dashboard
 * 3 column riverdashboard add video
 *
 * @package 3 column dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fusion <contact@donkeydesigns.us>
 * @copyright TheFloridaCircle.com 2008-2009
 * @link http://www.thefloridacircle.com/
 *
 ******************************************************************************/

require_once(dirname(dirname(dirname(dirname(dirname(dirname(dirname(__FILE__))))))) . "/engine/start.php");
gatekeeper();
$page_owner = page_owner_entity();

	$area2 = "<div id='river_container2' style='margin-top:3px;'><div class='dash_pad'>";
	$area2 .= "<div style='border-bottom:1px solid silver; margin:0 auto 5px auto;'>";
    $area2 .= "<div style='float:left; width:49%;'>";
    $area2 .= "<img style='float:left;' src='" .$CONFIG->wwwroot. "mod/riverdashboard/graphics/icon_video.png'> <span style='padding:0 0 0 3px;'>" .elgg_echo('river:video:add'). "</span>";
    $area2 .= "</div>";
    $area2 .= "<div align='right' style='float:right; width:49%;'>";
    $area2 .= "<input style=\"border:none; padding:0 0 2px 0;\" type=\"image\" src=\"" .$CONFIG->wwwroot. "mod/riverdashboard/graphics/close.png\" onClick=\"document.getElementById('load_content').innerHTML=''\"></div>";
    $area2 .= "<div class='clearfloat'></div></div>";
    //$area2 .= elgg_view_title(elgg_echo('izap_videos:add'));
    $area2 .= elgg_view('riverdashboard/ajaxpage/forms/videoform');
	$area2 .= "</div></div>";

echo $area2;

?>