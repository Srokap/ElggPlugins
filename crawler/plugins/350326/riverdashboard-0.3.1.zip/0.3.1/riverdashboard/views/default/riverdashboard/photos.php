<?php if (is_plugin_enabled("tidypics")) { ?>
<div id="river_container2">

<?php

	//the number of files to display
	$imagesToDisplay = get_plugin_setting("imagesToDisplay", "riverdashboard");
	$number = (int) $vars['entity']->num_display;
	//if no number has been set, default to 6
	if (!$number)
		$number = $imagesToDisplay;
	echo '<div class="collapsable_box_header">';
    echo '<h1>' .elgg_echo("river:photo:latest"). '</h1></div>';
	echo '<div class="collapsable_box_content">';
	echo '<div class="contentWrapper">';
	echo '<div class="tidypics_widget_latest">';
	echo tp_get_latest_photos($number);
	echo '</div></div>';
	
?>
</div>
</div>
<?php } ?>