<?php
/*******************************************************************************
 * 3 column dashboard
 * view for newest members
 *
 * @package 3 column dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fusion <contact@donkeydesigns.us>
 * @copyright TheFloridaCircle.com 2008-2009
 * @link http://www.thefloridacircle.com/
 *
 ******************************************************************************/
   // Get the number of events to display
    $memToDisplay = get_plugin_setting('memToDisplay','riverdashboard');

	$newest_members = get_entities_from_metadata('icontime', '', 'user', '', 0, $memToDisplay);
	
?>
<div id="river_container2">
    
<div class="collapsable_box_header">        
<h1><?php echo elgg_echo('riverdashboard:recentmembers') ?></h1>
</div>
<div class="collapsable_box_content">
<div class="contentWrapper">
<?php 
	foreach($newest_members as $mem){
		echo "<div class=\"recentMember\">" . elgg_view("profile/icon",array('entity' => $mem, 'size' => 'tiny')) . "</div>";
	}
?>
<div class="clearfloat"></div>
</div>
        

    </div><!-- /dash_pad -->
</div><!-- / river_container2 -->