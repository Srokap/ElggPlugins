<?php
/*******************************************************************************
 * 3 column dashboard
 * 3 column replacement riverdashboard view for comments and extras
 *
 * @package 3 column dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fusion <contact@donkeydesigns.us>
 * @copyright TheFloridaCircle.com 2008-2009
 * @link http://www.thefloridacircle.com/
 * 
 ******************************************************************************/
	$performed_by = $vars['performed_by'];
	$object = $vars['object'];
	$body = $vars['body'];
	$time = $vars['time']?$vars['time']:$object->time_created;
	$show_comment = $vars['show_comment'];
	$join_group = $vars['join_group'];
	$group_guid = $vars['group_guid'];
	$add_video = $vars['add_video'];
	$vote = $vars['vote'];
	$send_gift = $vars['send_gift'];
	

	echo '</div>';//break from basic_river_item_view?>
<div style="padding:10px 0">
<?php
	echo elgg_view("profile/icon",
    					array(
    						'entity' => $performed_by,
    						'size' => 'small')); ?>

<div class="obj_guid js_meta"><?php echo $object->guid;?></div>
  <div class="item_body">
	<?php echo $body; ?>
  </div>
    <div class="item_info">
	<img src="<?php echo $vars['url']; ?>mod/riverdashboard/graphics/clock_icon.gif" width="11px" height="11px" /><span style="font-size:11px;"> <?php echo friendly_time($time); ?> 
<?php
	if ($show_comment) {
		?>
		- <a href="" class="toggle_comment">(<span class="comment_cnt"><?php echo count_annotations($object->guid,'','','generic_comment');?></span>)&nbsp;<?php echo elgg_echo('river:item:toggle_comments');?></a> 
		<?php
	}
	if ($join_group) {
		?>
		- <a href="<?php echo $vars['url'] . "action/groups/join?group_guid=" . $group_guid; ?>"><?php echo elgg_echo('river:join'); ?></a>
        <?php
	}
	if ($add_video) {
		?>
		- <a href="<?php echo $vars['url'] . "pg/izap_videos/" . get_loggedin_user()->username . "/add" ?>"><img src="<?php echo $vars['url']?>mod/izap_videos/graphics/upload.png" height="12" width="12"/> <?php echo elgg_echo('river:uploadVideo') ?></a>
	<?php
	}
	if ($vote) {
	    ?>
        - <a href="" class="toggle_vote"><img src="<?php echo $vars['url']?>mod/riverdashboard/graphics/vote_icon.gif" height="12" width="12"/> <?php echo elgg_echo('river:vote');?></a>
    <?php
	}
	if ($send_gift) {
		?>
        - <a href="<?php echo $vars['url']; ?>pg/gifts/<?php echo $_SESSION['user']->username; ?>/sendgift"><img src="<?php echo $vars['url']; ?>mod/riverdashboard/graphics/gift.gif" height="12px" width="12px" /> <?php echo elgg_echo('river:sendgift'); ?></a></span>
        <?php
	}
	?>
    

    </div>
<?php
    if ($vote) {
		
		/*$alreadyVoted = 0;
        if ( $priorVote !== false ) {
          $alreadyVoted = 1;
        }
		
				
				//if user has voted, show the results
				if ( $alreadyVoted ) {
          // show the user's vote
		            echo "<div class=\"item_vote\">";
					echo "<p><h2>" . elgg_echo('poll:voted') . "</h2></p>";
					echo "</div>";
				} else {
					
					//else show the voting form
					echo "<div class=\"item_vote\">";
					echo elgg_view('river/forms/vote', array('entity' => $vars['entity']));
					echo "</div>";
					
				}*/
		
			
	  echo "<div class=\"item_vote\">";
	  echo elgg_view('river/forms/vote',array('entity' => $object));
      echo "</div>";
	}// if ($vote)
?>

<?php 
   // if ($send_gift) {		
		//echo "<div class=\"item_vote\">";
		//echo elgg_view('riverdashboard/sendgift');
		//echo "</div>";
	//}// if ($send_gift)
?>

<?php
	if ($show_comment) {
      echo "<div class=\"item_comments\">";
      echo getRiverItemComments($object->guid);
      echo "</div>";
      echo "<div class=\"item_comment_form\">";
	  echo elgg_view('river/forms/comment',array('entity' => $object));
      echo "</div>";
    }//if ($show_comment)
?>

<?php
	echo '<div class="hide_basic_river_item_view_time">';//hide friendly time div in basic view
?>
</div>