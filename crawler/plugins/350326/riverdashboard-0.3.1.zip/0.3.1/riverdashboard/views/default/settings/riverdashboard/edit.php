<?php
if(empty($vars['entity']->leftads_title1)) $vars['entity']->leftads_title1 = "Sponsors";

if(empty($vars['entity']->rightads_title1)) $vars['entity']->rightads_title1 = "Sponsors";

if(empty($vars['entity']->leftads_code)) $vars['entity']->leftads_code = "<script type=\"text/javascript\"><!--
google_ad_client = \"pub-4047588580641274\";
/* 120x600, created 10/8/09 */
google_ad_slot = \"0665594238\";
google_ad_width = 120;
google_ad_height = 600;
//-->
</script>
<script type=\"text/javascript\"
src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">
</script>";

if(empty($vars['entity']->rightads_code)) $vars['entity']->rightads_code = "<script type=\"text/javascript\"><!--
google_ad_client = \"pub-4047588580641274\";
/* 250x250, created 4/25/09 */
google_ad_slot = \"3669726112\";
google_ad_width = 250;
google_ad_height = 250;
//-->
</script>
<script type=\"text/javascript\"
src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">
</script>";

if(empty($vars['entity']->topads_code)) $vars['entity']->topads_code = "<script type=\"text/javascript\"><!--
google_ad_client = \"pub-4047588580641274\";
/* 468x60, created 9/21/09 */
google_ad_slot = \"4429845588\";
google_ad_width = 468;
google_ad_height = 60;
//-->
</script>
<script type=\"text/javascript\"
src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">
</script>";

$numToDisplay = $vars['entity']->numToDisplay;
$featuredNumToDisplay = $vars['entity']->featuredNumToDisplay;
$marksToDisplay = $vars['entity']->marksToDisplay;
$memToDisplay = $vars['entity']->memToDisplay;
$friendsToDisplay = $vars['entity']->friendsToDisplay;
$pollsToDisplay = $vars['entity']->pollsToDisplay;
$vidsToDisplay = $vars['entity']->vidsToDisplay;
$rvToDisplay = $vars['entity']->rvToDisplay;
$imagesToDisplay = $vars['entity']->imagesToDisplay;
//$riverRefreshRate = $vars['entity']->riverRefreshRate;

if (!$vars['entity']->show_site) {// site message
	    $vars['entity']->show_site = "yes";
    }

if (!$vars['entity']->show_tips) {// helpful tips
	    $vars['entity']->show_tips = "yes";
    }

if (!$vars['entity']->show_topads) {
	    $vars['entity']->show_topads = "yes";
    }
	
if (!$vars['entity']->show_leftads) {
	    $vars['entity']->show_leftads = "yes";
    }
	
if (!$vars['entity']->show_rightads) {
	    $vars['entity']->show_rightads = "yes";
    }

if (!$vars['entity']->show_newestmembers) {
	    $vars['entity']->show_newestmembers = "yes";
    }
	
if (!$vars['entity']->show_friends) {
	    $vars['entity']->show_friends = "yes";
    }

?>

<div>
<p>
	<?php echo elgg_echo('riverdashboard:useasdashboard'); ?><br />
	<select name="params[useasdashboard]">
		<option value="yes" <?php if ($vars['entity']->useasdashboard == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->useasdashboard != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<hr color="silver" />
<p>
	<?php echo elgg_echo('riverdashboard:feeds:allow'); ?><br />
	<select name="params[feedAllow]">
		<option value="yes" <?php if ($vars['entity']->feedAllow == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->feedAllow != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<hr color="silver" />
<!--<p>
        <?php echo elgg_echo('riverdashboard:settings:refresh'); ?><br />
        <select name="params[riverRefreshRate]">
		<option value="10000" <?php if ($riverRefreshRate == 10000) echo " selected=\"yes\" "; ?>>10</option>
		<option value="20000" <?php if ($riverRefreshRate == 20000) echo " selected=\"yes\" "; ?>>20</option>
		<option value="30000" <?php if ($riverRefreshRate == 30000 || empty($riverRefreshRate)) echo " selected=\"yes\" "; ?>>30</option>
		<option value="40000" <?php if ($riverRefreshRate == 40000) echo " selected=\"yes\" "; ?>>40</option>
        <option value="50000" <?php if ($riverRefreshRate == 50000) echo " selected=\"yes\" "; ?>>50</option>
        <option value="60000" <?php if ($riverRefreshRate == 60000) echo " selected=\"yes\" "; ?>>60</option>
	</select>
</p>
<hr color="silver" />-->
<p>
        <?php echo elgg_echo('riverdashboard:settings:topad'); ?><br />
        <select name="params[show_topads]">
                <option value="yes" <?php if ($vars['entity']->show_topads == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
                <option value="no" <?php if ($vars['entity']->show_topads != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
                </select>
                <br />
         <?php echo elgg_echo('riverdashboard:settings:adcode') . elgg_view("riverdashboard/input/longtext", array("internalname"=>"params[topads_code]", "value"=>$vars['entity']->topads_code));?>
</p>
<hr color="silver" />

<div id="setleft" style="float:left; width:45%; border:1px solid silver; padding:10px;">
<h3>LEFT COLUMN</h3>
<?php if (is_plugin_enabled('tidypics')){ ?>
<p>
        <?php echo elgg_echo('riverdashboard:settings:photos'); ?><br />
        <select name="params[show_photos]">
                <option value="yes" <?php if ($vars['entity']->show_photos == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
                <option value="no" <?php if ($vars['entity']->show_photos != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
        </select><br />
	<?php echo elgg_echo('photos:num:display'); ?><br />
	
	<select name="params[imagesToDisplay]">
		<option value="3" <?php if ($imagesToDisplay == 3) echo " selected=\"yes\" "; ?>>3</option>
		<option value="6" <?php if ($imagesToDisplay == 6 || empty($imagesToDisplay)) echo " selected=\"yes\" "; ?>>6</option>
		<option value="9" <?php if ($imagesToDisplay == 9) echo " selected=\"yes\" "; ?>>9</option>
		<option value="12" <?php if ($imagesToDisplay == 12) echo " selected=\"yes\" "; ?>>12</option>
        <option value="15" <?php if ($imagesToDisplay == 15) echo " selected=\"yes\" "; ?>>15</option>
        <option value="18" <?php if ($imagesToDisplay == 18) echo " selected=\"yes\" "; ?>>18</option>
        <option value="21" <?php if ($imagesToDisplay == 21) echo " selected=\"yes\" "; ?>>21</option>
	</select>
</p><hr color="silver" />
<?php } ?>
<?php if (is_plugin_enabled('event_calendar')){ ?>
<p>
        <?php echo elgg_echo('riverdashboard:settings:events'); ?><br />
        <select name="params[show_events]">
                <option value="yes" <?php if ($vars['entity']->show_events == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
                <option value="no" <?php if ($vars['entity']->show_events != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
        </select><br />
	<?php echo elgg_echo('event_calendar:num_display'); ?><br />
	
	<select name="params[numToDisplay]">
		<option value="1" <?php if ($numToDisplay == 1) echo " selected=\"yes\" "; ?>>1</option>
		<option value="2" <?php if ($numToDisplay == 2 || empty($numToDisplay)) echo " selected=\"yes\" "; ?>>2</option>
		<option value="3" <?php if ($numToDisplay == 3) echo " selected=\"yes\" "; ?>>3</option>
		<option value="4" <?php if ($numToDisplay == 4) echo " selected=\"yes\" "; ?>>4</option>
        <option value="5" <?php if ($numToDisplay == 5) echo " selected=\"yes\" "; ?>>5</option>
        <option value="6" <?php if ($numToDisplay == 6) echo " selected=\"yes\" "; ?>>6</option>
        <option value="7" <?php if ($numToDisplay == 7) echo " selected=\"yes\" "; ?>>7</option>
        <option value="8" <?php if ($numToDisplay == 8) echo " selected=\"yes\" "; ?>>8</option>
        <option value="9" <?php if ($numToDisplay == 9) echo " selected=\"yes\" "; ?>>9</option>
        <option value="10" <?php if ($numToDisplay == 10) echo " selected=\"yes\" "; ?>>10</option>
	</select>
</p><hr color="silver" />
<?php } ?>
<?php if (is_plugin_enabled('bookmarks')){ ?>
<p>
        <?php echo elgg_echo('riverdashboard:settings:bookmarks'); ?><br />
        <select name="params[show_bookmarks]">
                <option value="yes" <?php if ($vars['entity']->show_bookmarks == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
                <option value="no" <?php if ($vars['entity']->show_bookmarks != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
        </select><br />
        <?php echo elgg_echo('riverdashboard:bookmarks:num'); ?><br />
        <select name="params[marksToDisplay]">
		<option value="1" <?php if ($marksToDisplay == 1) echo " selected=\"yes\" "; ?>>1</option>
		<option value="2" <?php if ($marksToDisplay == 2 || empty($marksToDisplay)) echo " selected=\"yes\" "; ?>>2</option>
		<option value="3" <?php if ($marksToDisplay == 3) echo " selected=\"yes\" "; ?>>3</option>
		<option value="4" <?php if ($marksToDisplay == 4) echo " selected=\"yes\" "; ?>>4</option>
        <option value="5" <?php if ($marksToDisplay == 5) echo " selected=\"yes\" "; ?>>5</option>
        <option value="6" <?php if ($marksToDisplay == 6) echo " selected=\"yes\" "; ?>>6</option>
        <option value="7" <?php if ($marksToDisplay == 7) echo " selected=\"yes\" "; ?>>7</option>
        <option value="8" <?php if ($marksToDisplay == 8) echo " selected=\"yes\" "; ?>>8</option>
        <option value="9" <?php if ($marksToDisplay == 9) echo " selected=\"yes\" "; ?>>9</option>
        <option value="10" <?php if ($marksToDisplay == 10) echo " selected=\"yes\" "; ?>>10</option>
	</select>
</p>
<hr color="silver" />
<?php } ?>
<p>
        <?php echo elgg_echo('riverdashboard:settings:leftad'); ?><br />
        <select name="params[show_leftads]">
                <option value="yes" <?php if ($vars['entity']->show_leftads == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
                <option value="no" <?php if ($vars['entity']->show_leftads != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
                </select>
                <br />
         <?php echo elgg_echo('riverdashboard:settings:title1') . elgg_view("input/text", array("internalname"=>"params[leftads_title1]", "value"=>$vars['entity']->leftads_title1));?>
                <br />
         <?php echo elgg_echo('riverdashboard:settings:adcode') . elgg_view("riverdashboard/input/longtext", array("internalname"=>"params[leftads_code]", "value"=>$vars['entity']->leftads_code));?>
</p>
<hr color="silver" />
<p>
        <?php echo elgg_echo('riverdashboard:settings:newestmembers'); ?><br />
        <select name="params[show_newestmembers]">
                <option value="yes" <?php if ($vars['entity']->show_newestmembers == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
                <option value="no" <?php if ($vars['entity']->show_newestmembers != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
        </select><br />
        <?php echo elgg_echo('riverdashboard:newestmembers:num'); ?><br />
        <select name="params[memToDisplay]">
		<option value="7" <?php if ($memToDisplay == 7) echo " selected=\"yes\" "; ?>>7</option>
		<option value="14" <?php if ($memToDisplay == 14) echo " selected=\"yes\" "; ?>>14</option>
		<option value="21" <?php if ($memToDisplay == 21) echo " selected=\"yes\" "; ?>>21</option>
		<option value="28" <?php if ($memToDisplay == 28 || empty($memToDisplay)) echo " selected=\"yes\" "; ?>>28</option>
        <option value="35" <?php if ($memToDisplay == 35) echo " selected=\"yes\" "; ?>>35</option>
        <option value="42" <?php if ($memToDisplay == 42) echo " selected=\"yes\" "; ?>>42</option>
        <option value="49" <?php if ($memToDisplay == 49) echo " selected=\"yes\" "; ?>>49</option>
        <option value="56" <?php if ($memToDisplay == 56) echo " selected=\"yes\" "; ?>>56</option>
        <option value="63" <?php if ($memToDisplay == 63) echo " selected=\"yes\" "; ?>>63</option>
        <option value="70" <?php if ($memToDisplay == 70) echo " selected=\"yes\" "; ?>>70</option>
	</select>
</p>
<hr color="silver" />
<?php if (is_plugin_enabled('groups')){ ?>
<p>
        <?php echo elgg_echo('riverdashboard:settings:featured_groups'); ?><br />
        <select name="params[show_featured_groups]">
                <option value="yes" <?php if ($vars['entity']->show_featured_groups == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
                <option value="no" <?php if ($vars['entity']->show_featured_groups != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
        </select><br />
        <?php echo elgg_echo('riverdashboard:groups:num'); ?><br />
        <select name="params[featuredNumToDisplay]">
		<option value="1" <?php if ($featuredNumToDisplay == 1) echo " selected=\"yes\" "; ?>>1</option>
		<option value="2" <?php if ($featuredNumToDisplay == 2 || empty($featuredNumToDisplay)) echo " selected=\"yes\" "; ?>>2</option>
		<option value="3" <?php if ($featuredNumToDisplay == 3) echo " selected=\"yes\" "; ?>>3</option>
		<option value="4" <?php if ($featuredNumToDisplay == 4) echo " selected=\"yes\" "; ?>>4</option>
        <option value="5" <?php if ($featuredNumToDisplay == 5) echo " selected=\"yes\" "; ?>>5</option>
        <option value="6" <?php if ($featuredNumToDisplay == 6) echo " selected=\"yes\" "; ?>>6</option>
        <option value="7" <?php if ($featuredNumToDisplay == 7) echo " selected=\"yes\" "; ?>>7</option>
        <option value="8" <?php if ($featuredNumToDisplay == 8) echo " selected=\"yes\" "; ?>>8</option>
        <option value="9" <?php if ($featuredNumToDisplay == 9) echo " selected=\"yes\" "; ?>>9</option>
        <option value="10" <?php if ($featuredNumToDisplay == 10) echo " selected=\"yes\" "; ?>>10</option>
	</select>
</p>
<hr color="silver" />
<p>
        <?php echo elgg_echo('riverdashboard:settings:mygroups'); ?><br />
        <select name="params[show_mygroups]">
                <option value="yes" <?php if ($vars['entity']->show_mygroups == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
                <option value="no" <?php if ($vars['entity']->show_mygroups != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
        </select><br />
        <?php echo elgg_echo('riverdashboard:groups:num'); ?><br />
        <select name="params[groupsNumToDisplay]">
		<option value="1" <?php if ($groupsNumToDisplay == 1) echo " selected=\"yes\" "; ?>>1</option>
		<option value="2" <?php if ($groupsNumToDisplay == 2 || empty($groupsNumToDisplay)) echo " selected=\"yes\" "; ?>>2</option>
		<option value="3" <?php if ($groupsNumToDisplay == 3) echo " selected=\"yes\" "; ?>>3</option>
		<option value="4" <?php if ($groupsNumToDisplay == 4) echo " selected=\"yes\" "; ?>>4</option>
        <option value="5" <?php if ($groupsNumToDisplay == 5) echo " selected=\"yes\" "; ?>>5</option>
        <option value="6" <?php if ($groupsNumToDisplay == 6) echo " selected=\"yes\" "; ?>>6</option>
        <option value="7" <?php if ($groupsNumToDisplay == 7) echo " selected=\"yes\" "; ?>>7</option>
        <option value="8" <?php if ($groupsNumToDisplay == 8) echo " selected=\"yes\" "; ?>>8</option>
        <option value="9" <?php if ($groupsNumToDisplay == 9) echo " selected=\"yes\" "; ?>>9</option>
        <option value="10" <?php if ($groupsNumToDisplay == 10) echo " selected=\"yes\" "; ?>>10</option>
	</select>
</p>
<hr color="silver" />
<?php } ?>
<!--<p>
        <?php echo elgg_echo('riverdashboard:settings:vanilla'); ?><br />
        <select name="params[show_vanilla]">
                <option value="yes" <?php if ($vars['entity']->show_vanilla == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
                <option value="no" <?php if ($vars['entity']->show_vanilla != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
        </select>
</p>
<br />-->
<?php if (is_plugin_enabled('tag_cumulus')){ ?>
<p>
        <?php echo elgg_echo('riverdashboard:settings:sidebarTagcloud'); ?><br />
        <select name="params[show_sidebartagcloud]">
                <option value="yes" <?php if ($vars['entity']->show_sidebartagcloud == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
                <option value="no" <?php if ($vars['entity']->show_sidebartagcloud != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
        </select>
</p>
<hr color="silver" />
<?php } ?>
</div><!-- / setleft -->

<div id="setright" style="float:right; width:45%; border:1px solid silver; padding:10px;">
<h3>RIGHT COLUMN</h3>
<p>
        <?php echo elgg_echo('riverdashboard:settings:site'); ?><br />
        <select name="params[show_site]">
                <option value="yes" <?php if ($vars['entity']->show_site == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
                <option value="no" <?php if ($vars['entity']->show_site != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
        </select>
</p>
<hr color="silver" />
<p>
        <?php echo elgg_echo('riverdashboard:settings:tips'); ?><br />
        <select name="params[show_tips]">
                <option value="yes" <?php if ($vars['entity']->show_tips == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
                <option value="no" <?php if ($vars['entity']->show_tips != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
        </select>
</p>
<hr color="silver" />
<p>
        <?php echo elgg_echo('riverdashboard:settings:friends'); ?><br />
        <select name="params[show_friends]">
                <option value="yes" <?php if ($vars['entity']->show_friends == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
                <option value="no" <?php if ($vars['entity']->show_friends != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
        </select><br />
        <?php echo elgg_echo('riverdashboard:friends:num'); ?><br />
        <select name="params[friendsToDisplay]">
		<option value="5" <?php if ($friendsToDisplay == 5) echo " selected=\"yes\" "; ?>>5</option>
		<option value="10" <?php if ($friendsToDisplay == 10) echo " selected=\"yes\" "; ?>>10</option>
		<option value="15" <?php if ($friendsToDisplay == 15 || empty($friendsToDisplay)) echo " selected=\"yes\" "; ?>>15</option>
		<option value="20" <?php if ($friendsToDisplay == 20) echo " selected=\"yes\" "; ?>>20</option>
        <option value="25" <?php if ($friendsToDisplay == 25) echo " selected=\"yes\" "; ?>>25</option>
        <option value="30" <?php if ($friendsToDisplay == 30) echo " selected=\"yes\" "; ?>>30</option>
        <option value="35" <?php if ($friendsToDisplay == 35) echo " selected=\"yes\" "; ?>>35</option>
        <option value="40" <?php if ($friendsToDisplay == 40) echo " selected=\"yes\" "; ?>>40</option>
        <option value="45" <?php if ($friendsToDisplay == 45) echo " selected=\"yes\" "; ?>>45</option>
        <option value="50" <?php if ($friendsToDisplay == 50) echo " selected=\"yes\" "; ?>>50</option>
	</select>
</p>
<hr color="silver" />
<p>
        <?php echo elgg_echo('riverdashboard:settings:rightad'); ?><br />
        <select name="params[show_rightads]">
                <option value="yes" <?php if ($vars['entity']->show_rightads == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
                <option value="no" <?php if ($vars['entity']->show_rightads != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
                </select>
                <br />
         <?php echo elgg_echo('riverdashboard:settings:title1') . elgg_view("input/text", array("internalname"=>"params[rightads_title1]", "value"=>$vars['entity']->rightads_title1));?>
                <br />
         <?php echo elgg_echo('riverdashboard:settings:adcode') . elgg_view("riverdashboard/input/longtext", array("internalname"=>"params[rightads_code]", "value"=>$vars['entity']->rightads_code));?>
</p>
<hr color="silver" />
<!-- <p>
        <?php echo elgg_echo('riverdashboard:settings:birthdaymembers'); ?><br>
        <select name="params[show_birthdaymembers]">
                <option value="yes" <?php if ($vars['entity']->show_birthdaymembers == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
                <option value="no" <?php if ($vars['entity']->show_birthdaymembers != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
        </select>
</p>-->
<?php if (is_plugin_enabled('poll')){ ?>
<p>
        <?php echo elgg_echo('riverdashboard:settings:polls'); ?><br />
        <select name="params[show_polls]">
                <option value="yes" <?php if ($vars['entity']->show_polls == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
                <option value="no" <?php if ($vars['entity']->show_polls != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
        </select><br />
        <?php echo elgg_echo('riverdashboard:polls:num'); ?><br />
        <select name="params[pollsToDisplay]">
		<option value="1" <?php if ($pollsToDisplay == 1) echo " selected=\"yes\" "; ?>>1</option>
		<option value="2" <?php if ($pollsToDisplay == 2) echo " selected=\"yes\" "; ?>>2</option>
		<option value="3" <?php if ($pollsToDisplay == 3 || empty($pollsToDisplay)) echo " selected=\"yes\" "; ?>>3</option>
		<option value="4" <?php if ($pollsToDisplay == 4) echo " selected=\"yes\" "; ?>>4</option>
        <option value="5" <?php if ($pollsToDisplay == 5) echo " selected=\"yes\" "; ?>>5</option>
	</select>
</p>
<hr color="silver" />
<?php } ?>
<?php if (is_plugin_enabled('photo_cumulus')){ ?>
<p>
        <?php echo elgg_echo('riverdashboard:settings:photocumulus'); ?><br />
        <select name="params[show_photocumulus]">
                <option value="yes" <?php if ($vars['entity']->show_photocumulus == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
                <option value="no" <?php if ($vars['entity']->show_photocumulus != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
        </select>
</p>
<hr color="silver" />
<? } ?>
<?php if (is_plugin_enabled('izap_videos')){ ?>
<p>
        <?php echo elgg_echo('riverdashboard:settings:videos'); ?><br />
        <select name="params[show_videos]">
                <option value="yes" <?php if ($vars['entity']->show_videos == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
                <option value="no" <?php if ($vars['entity']->show_videos != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
        </select><br />
        <?php echo elgg_echo('riverdashboard:video:num'); ?><br />
        <select name="params[vidsToDisplay]">
		<option value="5" <?php if ($vidsToDisplay == 5) echo " selected=\"yes\" "; ?>>5</option>
		<option value="10" <?php if ($vidsToDisplay == 10) echo " selected=\"yes\" "; ?>>10</option>
		<option value="15" <?php if ($vidsToDisplay == 15) echo " selected=\"yes\" "; ?>>15</option>
		<option value="20" <?php if ($vidsToDisplay == 20 || empty($vidsToDisplay)) echo " selected=\"yes\" "; ?>>20</option>
        <option value="25" <?php if ($vidsToDisplay == 25) echo " selected=\"yes\" "; ?>>25</option>
        <option value="30" <?php if ($vidsToDisplay == 30) echo " selected=\"yes\" "; ?>>30</option>
        <option value="35" <?php if ($vidsToDisplay == 35) echo " selected=\"yes\" "; ?>>35</option>
        <option value="40" <?php if ($vidsToDisplay == 40) echo " selected=\"yes\" "; ?>>40</option>
        <option value="45" <?php if ($vidsToDisplay == 45) echo " selected=\"yes\" "; ?>>45</option>
        <option value="50" <?php if ($vidsToDisplay == 50) echo " selected=\"yes\" "; ?>>50</option>
	</select>
</p>
<hr color="silver" />
<?php } ?>
<?php if (is_plugin_enabled('izap-profile-visitors')){ ?>
<p>
        <?php echo elgg_echo('riverdashboard:settings:recentview'); ?><br />
        <select name="params[show_recentview]">
                <option value="yes" <?php if ($vars['entity']->show_recentview == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
                <option value="no" <?php if ($vars['entity']->show_recentview != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
        </select><br />
        <?php echo elgg_echo('riverdashboard:recentv:num'); ?><br />
        <select name="params[rvToDisplay]">
		<option value="5" <?php if ($rvToDisplay == 5) echo " selected=\"yes\" "; ?>>5</option>
		<option value="10" <?php if ($rvToDisplay == 10 || empty($rvToDisplay)) echo " selected=\"yes\" "; ?>>10</option>
		<option value="15" <?php if ($rvToDisplay == 15) echo " selected=\"yes\" "; ?>>15</option>
		<option value="20" <?php if ($rvToDisplay == 20) echo " selected=\"yes\" "; ?>>20</option>
        <option value="25" <?php if ($rvToDisplay == 25) echo " selected=\"yes\" "; ?>>25</option>
        <option value="30" <?php if ($rvToDisplay == 30) echo " selected=\"yes\" "; ?>>30</option>
        <option value="35" <?php if ($rvToDisplay == 35) echo " selected=\"yes\" "; ?>>35</option>
        <option value="40" <?php if ($rvToDisplay == 40) echo " selected=\"yes\" "; ?>>40</option>
        <option value="45" <?php if ($rvToDisplay == 45) echo " selected=\"yes\" "; ?>>45</option>
        <option value="50" <?php if ($rvToDisplay == 50) echo " selected=\"yes\" "; ?>>50</option>
	</select>
</p>
<hr color="silver" />
<?php } ?>
</div><!-- / setright -->

<div class="clearfloat"></div>
</div><!-- //</div> -->











