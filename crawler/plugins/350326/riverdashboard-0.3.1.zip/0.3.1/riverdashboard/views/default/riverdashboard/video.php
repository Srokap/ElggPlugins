<?php if (is_plugin_enabled('izap_videos')){ ?>
<div id="river_container2">


<?php
   // Get the number of events to display
    $vidsToDisplay = get_plugin_setting('vidsToDisplay','riverdashboard');
	
        $videos = $vars['entities'];
        $total = $vidsToDisplay;
        if(isset($vars['videosTOdisplay']))
        $total = $vars['videosTOdisplay'];
		echo '<div class="collapsable_box_header">';
        echo "<h1>" .elgg_echo('videos'). "</h1></div>";
		echo '<div class="collapsable_box_content">';
        echo '<div class="contentWrapper">';
        ?>
        
        <script>
            function selectTab(selectedTab, displayDiv) {
                $('#ltab').removeClass('selected');
                $('#vtab').removeClass('selected');
                $('#ctab').removeClass('selected');

               $('#latest').hide('fast');
                $('#views').hide('fast');
                $('#com').hide('fast');

               $('#'+displayDiv).show('fast');
                $('#'+displayDiv).load('<?php echo $vars['url']; ?>mod/izap_videos/customindexVideos.php?type='+displayDiv+'&videosTOdisplay='+<?php echo $total;?>);
                $('#'+selectedTab).addClass('selected');
            }
        </script>
        
        <div id="elgg_horizontal_tabbed_nav">
            <ul>
                <li id="ltab" style="font-size:9px;"><a href="javascript: selectTab('ltab', 'latest');"><?php echo elgg_echo('river:latestvideos'); ?></a></li>
                <li id="vtab" style="font-size:9px;"><a href="javascript: selectTab('vtab', 'views');"><?php echo elgg_echo('river:topViewed'); ?></a></li>
                <li id="ctab" style="font-size:9px;"><a href="javascript: selectTab('ctab', 'com');"><?php echo elgg_echo('river:topCommented'); ?></a></li>
            </ul>
        </div>
        
        <?php
		echo '<div class="myicon_wrap">';
        echo '<div id="latest">';
            echo '<p align="center"><img src="'.$CONFIG->wwwroot .'_graphics/ajax_loader.gif"></p>';
        echo '</div>';
        echo '<div id="views">';
            echo '<p align="center"><img src="'.$CONFIG->wwwroot .'_graphics/ajax_loader.gif"></p>';
        echo '</div>';
        echo '<div id="com">';
            echo '<p align="center"><img src="'.$CONFIG->wwwroot .'_graphics/ajax_loader.gif"></p>';
        echo '</div>';
        echo '</div></div>';
        ?>
        
        <script language="javascript">
            $(document).ready(function(){
               selectTab('ltab', 'latest');
				});
        </script>
        
</div></div>
<?php }?>