<?php
    if (is_plugin_enabled('groups')){ 
	    $featuredNumToDisplay = get_plugin_setting('featuredNumToDisplay','riverdashboard');
?>
<div id="river_container2">

<?php
$featured_groups = get_entities_from_metadata("featured_group", "yes", "group", "", 0, $featuredNumToDisplay, false, false, false);
?>

<div class="collapsable_box_header">
<h1><?php echo elgg_echo("groups:featured"); ?></h1>
</div><!-- // collapsable_box_header -->

<div class="collapsable_box_content">

<?php
	if($featured_groups){
		
		foreach($featured_groups as $group){
			$icon = elgg_view(
				"groups/icon", array(
									'entity' => $group,
									'size' => 'small',
								  )
				);
				
			echo "<div class=\"contentWrapper\"><div style=\"float:left;margin-right:10px;\">" . $icon . " </div><p><span style=\"font-weight:bold; color:#666;\">" . $group->name . "</span><br />";
			echo "<span style=\"color:#999; \">" .$group->briefdescription . "</span></p>";
			echo "<div class=\"clearfloat\"></div></div>";
			
		}
	}
	
?>

</div><!-- // collapsable_box_content -->

</div><!-- // river_container2 -->

<?php } ?>
		