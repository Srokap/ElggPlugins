<?php
/*******************************************************************************
 * 3 column dashboard
 * the wire river file for riverdashboard
 *
 * @package 3 column dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fusion <contact@donkeydesigns.us>
 * @copyright TheFloridaCircle.com 2008-2009
 * @link http://www.thefloridacircle.com/
 *
 ******************************************************************************/
?>
<?php

	$performed_by = get_entity($vars['item']->subject_guid); // $statement->getSubject();
	$object = get_entity($vars['item']->object_guid);
	$url = $object->getURL();

	$string = "<a href=\"{$performed_by->getURL()}\">{$performed_by->name}</a> ";
	//$string .= $object->description;
	$desc .= $object->description;
	$desc = preg_replace('/\@([A-Za-z0-9\_\.\-]*)/i','@<a href="' . $vars['url'] . 'pg/thewire/$1">$1</a>',$desc);
	$string .= elgg_echo("river:created");
	$string .= "<div class=\"river_content_display\">";
	$string .= parse_urls($desc);
	$string .= "</div>";
	
	
?>

<?php 
	echo $string; 
?>