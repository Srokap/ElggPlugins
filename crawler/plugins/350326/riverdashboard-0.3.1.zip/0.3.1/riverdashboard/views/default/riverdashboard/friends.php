<?php
/*******************************************************************************
 * 3 column dashboard
 * 3 column riverdashboard Friends View
 *
 * @package 3 column dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fusion <contact@donkeydesigns.us>
 * @copyright TheFloridaCircle.com 2008-2009
 * @link http://www.thefloridacircle.com/
 *
 ******************************************************************************/
?>
<div id="river_container2">




<div class="collapsable_box_header">
<h1>Friends</h1>
</div>

<div class="collapsable_box_content">

<div class="contentWrapper">
<div class="sidebarBox">
<div class="membersWrapper">

<?php
   // Get the number of events to display
    $friendsToDisplay = get_plugin_setting('friendsToDisplay','riverdashboard');
	
$friends = get_entities_from_relationship('friend',$_SESSION['guid'],false,'user','',0,'',$friendsToDisplay);

foreach($friends as $friend) {
echo '<div class="myicon_wrap">';
echo "<div class=\"widget_friends_singlefriend\" >";
echo elgg_view("profile/icon",array('entity' => get_user($friend->guid), 'size' => 'small')) . "<br>";
echo $entity->name;
echo "</div></div>";
}

?>

<div class="clearfloat"></div>



<div align="right">
<a href="<?php echo $vars['url']; ?>pg/friends/<?php echo $_SESSION['user']->name; ?>"><?php echo elgg_echo("river:viewall");
?></a>
</div>
</div>
</div>
</div>
</div>
</div>