<?php
/*******************************************************************************
 * 3 column dashboard
 * 3 column riverdashboard The Wire Input
 *
 * @package 3 column dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fusion <contact@donkeydesigns.us>
 * @copyright TheFloridaCircle.com 2008-2009
 * @link http://www.thefloridacircle.com/
 *
 ******************************************************************************/


	//grab the users latest from the wire
	$latest_wire = list_entities("object", "thewire", $_SESSION['user']->getGUID(), 1, true, false, false);

?>

<script>
function textCounter(field,cntfield,maxlimit) {
    // if too long...trim it!
    if (field.value.length > maxlimit) {
        field.value = field.value.substring(0, maxlimit);
    } else {
        // otherwise, update 'characters left' counter
        cntfield.value = maxlimit - field.value.length;
    }
}
</script>

<div id="river_container2">
<div class="dash_pad">
<div class="sidebarBox">

	<form action="<?php echo $vars['url']; ?>action/thewire/add" method="post" name="noteForm">
			
		<?php
			$display .= "<h3>" . elgg_echo('river:newpost') . "</h3><textarea style=\"width: 97.5%; height:25px;\" name='note' value='' onKeyDown=\"textCounter(document.noteForm.note,document.noteForm.remLen1,140)\" onKeyUp=\"textCounter(document.noteForm.note,document.noteForm.remLen1,140)\" id=\"thewire_sidebarInputBox\">{$msg}</textarea><br />";
			$display .= "<div class='thewire_characters_remaining'><input readonly type=\"text\" name=\"remLen1\" size=\"3\" maxlength=\"3\" value=\"140\" class=\"thewire_characters_remaining_field\">";
			echo $display;
			echo elgg_echo("thewire:charleft") . "</div>";
		?>
			<input type="hidden" name="method" value="site" />
			<input type="hidden" name="location" value="activity" />
			<input type="hidden" name="access_id" value="2" />
			<input type="submit" value="<?php echo elgg_echo('river:share'); ?>" id="thewire_submit_button" />
            
       
	</form>

	<!--<div class="last_wirepost">
		<?php
			//echo $latest_wire;
		?>
	</div>-->
	
	<img src="<?php echo $vars['url']; ?>mod/riverdashboard/graphics/river_icon_thewire.gif" alt="the wire" align="left" style="margin-right:5px;"/><a href="<?php echo $vars['url']; ?>mod/thewire/everyone.php" /><?php echo elgg_echo('river:read'); ?></a>

</div></div></div>