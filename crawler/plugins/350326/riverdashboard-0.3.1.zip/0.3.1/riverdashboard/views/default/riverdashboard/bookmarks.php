<?php if (is_plugin_enabled('bookmarks')){ 

    echo "<div id=\"river_container2\">";
        
		echo '<div class="collapsable_box_header">';
        echo "<h1>" . elgg_echo("river:bookmarks") . "</h1></div>";
        echo '<div class="collapsable_box_content">';
		echo '<div class="contentWrapper">';
                // Get the number of events to display
                $marksToDisplay = get_plugin_setting('marksToDisplay','riverdashboard');
				
                //grab the users bookmarked items
                $shares = get_entities('object', 'bookmarks',$vars['entity']->owner_guid, "", $marksToDisplay, 0, false);
                
                if($shares){

                        foreach($shares as $s){
                        
                                //get the owner
                                $owner = $s->getOwnerEntity();
                
                                //get the user icon
                                $icon = elgg_view(
                                                "profile/icon", array(
                                                                                'entity' => $owner,
                                                                                'size' => 'tiny',
                                                                          )
                                        );

                                //get the bookmark title and goto resource
                                $info = "<p class=\"shares_title\"><a href=\"{$s->address}\">{$s->title}</a></p>";
                                
                                //get the bookmark description
                                if($s->description)
                                        $info .= "<div><p></p></div>";
                
                                //display 
                                echo "<div class=\"shares_widget_wrapper\">";
                                echo "<div class=\"shares_widget_icon\">" . $icon . "</div>";
                                echo "<div class=\"shares_widget_content\">" . $info . "</div>";
                                echo "</div>";

                        }

                        $user_inbox = $vars['url'] . "pg/bookmarks/" . $_SESSION['user']->name . "/items";
                        echo "<div align=\"right\"><a href=\"{$user_inbox}\">".elgg_echo('river:viewall')."</a></div>";

                }
    echo "</div></div></div>";
}
?>
