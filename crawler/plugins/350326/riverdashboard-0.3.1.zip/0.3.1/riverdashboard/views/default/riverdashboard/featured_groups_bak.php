<?php 
    if (is_plugin_enabled('groups')){
		$featuredNumToDisplay = get_plugin_setting('featuredNumToDisplay','riverdashboard');
		
	$area1 .= "<div id=\"river_container2\">";
	
	$featured_groups = get_entities_from_metadata("featured_group", "yes", "group", "", 0, $featuredNumToDisplay, false, false, false);
	$area1 .= '<div class="collapsable_box_content">';
	$area1 .= elgg_view("groups/featured", array("featured" => $featured_groups));
	
	$area1 .= "</div></div>";
	
	echo $area1;
	
}
?>