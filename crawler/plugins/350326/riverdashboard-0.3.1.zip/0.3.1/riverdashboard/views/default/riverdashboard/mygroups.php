<?php
if (is_plugin_enabled('groups')){
	$groupsNumToDisplay = get_plugin_setting('groupsNumToDisplay','riverdashboard');
/*******************************************************************************
 * 3 column dashboard
 * 3 column replacement riverdashboard view for my groups
 *
 * @package 3 column dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fusion <contact@donkeydesigns.us>
 * @copyright TheFloridaCircle.com 2008-2009
 * @link http://www.thefloridacircle.com/
 * Thanks to Cube
 ******************************************************************************/
?>
<div id="river_container2">

<?php
    $groups = get_entities_from_relationship('member', $_SESSION['guid'], false, "group", "", 0, "", $groupsNumToDisplay, 0, false, 0);
?>

<div class="collapsable_box_header">
<h1><?php echo elgg_echo("river:groups:mygroup"); ?></h1>
</div><!-- // collapsable_box_header -->
          
<div class="collapsable_box_content"> 

<?php     
    if($groups){
        
        foreach($groups as $group){
            $icon = elgg_view(
                "groups/icon", array(
                                    'entity' => $group,
                                    'size' => 'small',
                                  )
                );
                
            echo "<div class=\"contentWrapper\"><div style=\"float:left;margin-right:10px;\">" . $icon . " </div><p><span style=\"font-weight:bold; color:#666;\">" . $group->name . "</span><br />";
			echo "<span style=\"color:#999; \">" .$group->briefdescription . "</span></p>";
			echo "<div class=\"clearfloat\"></div></div>";
            
        }
    }
      
?>

</div><!-- // collapsable_box_content -->

</div><!-- // river_container2 -->
<?php } ?>