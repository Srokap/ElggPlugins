var shim_start; 
var navup=0;
var x;
var t;

function timedCount(){t = setTimeout("refreshstart()", 30000);}
function stopCount(){clearTimeout(t);}
function refreshload (siteurl){
	shim_start =siteurl +"mod/riverdashboard/refreshstart.php";
	setTimeout("startload()",100);
}

function startload(){refreshstart();}

function refreshstart()
{	
$('#river_container').load(shim_start+'?callback=true&display='+$('input#display').val() + '&content=' + $('select#content').val()+'&offset='+navup);
timedCount();
//alert('Refresh started');
}

function navigationback(){	
x=window.document.getElementById("content").value;	
navup = navup + 20;
$('#river_container').load(shim_start+'?callback=true&display='+$('input#display').val() + '&content=' + $('select#content').val()+'&offset='+navup);
}
	
function navigationforward(){
    x=window.document.getElementById("content").value;
	if (navup >= 20) {
		navup = navup - 20;
		$('#river_container').load(shim_start+'?callback=true&display='+$('input#display').val() + '&content=' + $('select#content').val()+'&offset='+navup);
		}
}

function dashfilter (){
$('#river_container').load(shim_start+'?callback=true&display='+$('input#display').val() + '&content=' + $('select#content').val());
navup=0;
}

function navreset (){
	navup=0;
}
