<?php
/*******************************************************************************
 * 3 column dashboard
 * 3 column riverdashboard Index page
 *
 * @package 3 column dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fusion <contact@donkeydesigns.us>
 * @copyright TheFloridaCircle.com 2008-2009
 * @link http://www.thefloridacircle.com/
 *
 ******************************************************************************/


		require_once(dirname(dirname(dirname(__FILE__))) . '/engine/start.php');

		gatekeeper();
		
		$content = get_input('content','');
		$content = explode(',',$content);
		$type = $content[0];
		$subtype = $content[1];
		$orient = get_input('display');
		$callback = get_input('callback');
		
		if ($type == 'all') {
			$type = '';
			$subtype = '';
		}

		$body = '';
		if (empty($callback)) {
			
			//set a view to display a welcome message
			$area4 = elgg_view("riverdashboard/welcome");
			
			//set a view to display left column
			$area1 .= elgg_view("riverdashboard/miniprofile");
			if(get_plugin_setting("show_photos", "riverdashboard") != "no") {
			    $area1 .= elgg_view("riverdashboard/photos");}
			//$area1 .= elgg_view("riverdashboard/birthdaymembers");
			if(get_plugin_setting("show_bookmarks", "riverdashboard") != "no") {
				$area1 .= elgg_view("riverdashboard/bookmarks");}
			if(get_plugin_setting("show_events", "riverdashboard") != "no") {
			    $area1 .= elgg_view("riverdashboard/events");}
			if(get_plugin_setting("show_leftads", "riverdashboard") != "no") {
				$area1 .= elgg_view("riverdashboard/leftad");}
			if(get_plugin_setting("show_newestmembers", "riverdashboard") != "no") {
                $area1 .= elgg_view("riverdashboard/newestmembers");}                        
            if(get_plugin_setting("show_featured_groups", "riverdashboard") != "no") {
                $area1 .= elgg_view("riverdashboard/featured_groups");}                
            if(get_plugin_setting("show_mygroups", "riverdashboard") != "no") {
                $area1 .= elgg_view("riverdashboard/mygroups");}
			if(get_plugin_setting("show_vanilla", "riverdashboard") != "no") {
				$area1 .= elgg_view("riverdashboard/vanilla");}
            if(get_plugin_setting("show_sidebartagcloud", "riverdashboard") != "no"){
                $area1 .= elgg_view("riverdashboard/sidebarTagcloud");}

			//set a wiew for the wire
			$body .= elgg_view("riverdashboard/activity_view");

			//set a view for the right column
			if(get_plugin_setting("show_site", "riverdashboard") != "no"){
			    $area3 .= elgg_view("riverdashboard/sitemessage");}
			if(get_plugin_setting("show_tips","riverdashboard") != "no"){
		        $area3 .= elgg_view("riverdashboard/tips");}
			if(get_plugin_usersetting("feedUserAllow", "riverdashboard") != "no"){
			    $area3 .= elgg_view("riverdashboard/feed");}
			if(get_plugin_setting("show_friends", "riverdashboard") != "no"){
                $area3 .= elgg_view("riverdashboard/friends");}
			if(get_plugin_setting("show_rightads", "riverdashboard") != "no"){
				$area3 .= elgg_view("riverdashboard/rightad");}
            if(get_plugin_setting("show_polls", "riverdashboard") != "no"){
                $area3 .= elgg_view("riverdashboard/poll");}
            if(get_plugin_setting("show_photocumulus", "riverdashboard") != "no"){
                $area3 .= elgg_view("riverdashboard/photo_cumulus");}
            if(get_plugin_setting("show_videos", "riverdashboard") != "no"){
                $area3 .= elgg_view("riverdashboard/video");}
            if(get_plugin_setting("show_recentview", "riverdashboard") != "no"){
                $area3 .= elgg_view("riverdashboard/recentview");}
	

		}
		
		switch($orient) {
			case 'mine':
							$subject_guid = $_SESSION['user']->guid;
							$relationship_type = ''; 
							break;
			case 'friends':	$subject_guid = $_SESSION['user']->guid;
							$relationship_type = 'friend';
							break;
			default:		$subject_guid = 0;
							$relationship_type = '';
							break;
		}

		$river = elgg_view_river_items($subject_guid, 0, $relationship_type, $type, $subtype, '') . "</div>";
		// Replacing callback calls in the nav with something meaningless
		$river = str_replace('callback=true','replaced=88,334',$river);
		
		$nav = elgg_view('riverdashboard/nav',array(
															'type' => $type,
															'subtype' => $subtype,
															'orient' => $orient 
														));
		if (empty($callback)) {
			$body .= elgg_view('riverdashboard/container', array('body' => $nav . $river . elgg_view('riverdashboard/js')));
			page_draw(elgg_echo('dashboard'),elgg_view_layout('three_column2',$area1,$body,$area3,$area4));
		} else {
			header("Content-type: text/html; charset=UTF-8");
			echo $nav . $river . elgg_view('riverdashboard/js');
		}

?>