<?php
/*******************************************************************************
 * 3 column dashboard
 * riverdashboard start page
 *
 * @package 3 column dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fusion <contact@donkeydesigns.us>
 * @copyright TheFloridaCircle.com 2008-2009
 * @link http://www.thefloridacircle.com/
 *
 ******************************************************************************/


		function riverdashboard_init() {
		
			global $CONFIG;
			
			// Register and optionally replace the dashboard
			if (get_plugin_setting('useasdashboard', 'riverdashboard') == 'yes') {
				register_page_handler('dashboard','riverdashboard_page_handler');
			} else {
				// Activity main menu
				if (isloggedin())
				{
					add_menu(elgg_echo('activity'), $CONFIG->wwwroot . "mod/riverdashboard/");
				}
			}
			
			// Page handler
			register_page_handler('riverdashboard','riverdashboard_page_handler');
			
			extend_view('css','riverdashboard/css');
			extend_view('metatags','riverdashboard/metatags');
			
			add_widget_type('river_widget',elgg_echo('river:widget:title'), elgg_echo('river:widget:description'));
			
			
		}
		
		//profile counter
		function profile_counter_init()	{
		    global $CONFIG;
		
		    // Extend profile to keep track of count
		    extend_view('profile/userdetails','profile_counter/count',999);
		
		    // Extend statistics to show current count
		    extend_view('usersettings/statistics','profile_counter/stats',999);
				
	    }
	
		register_elgg_event_handler('init','system','profile_counter_init');
		
		/**
		 * Page handler for riverdash
		 *
		 * @param unknown_type $page
		 */
		function riverdashboard_page_handler($page)
		{
			global $CONFIG;
			
			@include(dirname(__FILE__) . "/index.php");
			return true;
		}
		
		function riverdashboard_dashboard() {
			
			include(dirname(__FILE__) . '/index.php');
			
		}

		register_elgg_event_handler('init','system','riverdashboard_init');
		
	// Register actions
		global $CONFIG;
		register_action("riverdashboard/add",false,$CONFIG->pluginspath . "riverdashboard/actions/add.php");
		register_action("riverdashboard/shout",false,$CONFIG->pluginspath . "riverdashboard/actions/shout.php");
		register_action("riverdashboard/addpost",false,$CONFIG->pluginspath . "riverdashboard/actions/addpost.php");
		register_action("riverdashboard/delete",false,$CONFIG->pluginspath . "riverdashboard/actions/delete.php");
		register_action("riverdashboard/addlink",false,$CONFIG->pluginspath . "riverdashboard/actions/addlink.php");
		register_action("riverdashboard/addalbum",false,$CONFIG->pluginspath . "riverdashboard/actions/addalbum.php");
		register_action("riverdashboard/addvideo",false,$CONFIG->pluginspath . "riverdashboard/actions/addvideo.php");


?>