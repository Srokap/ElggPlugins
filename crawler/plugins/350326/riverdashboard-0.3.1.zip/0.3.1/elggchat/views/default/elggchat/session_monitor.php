<?php
	/**
	* ElggChat - Pure Elgg-based chat/IM
	* 
	* Builds the ElggChat Toolbar
	* 
	* @package elggchat
	* @author ColdTrick IT Solutions
	* @copyright Coldtrick IT Solutions 2009
	* @link http://www.coldtrick.com/
	* @version 0.4
	*/
	
?>

<div id="elggchat_toolbar">
	<!--<div id="elggchat_copyright">
		ElggChat (c) ColdTrick IT Solutions
	</div>-->
	<div id="elggchat_toolbar_left" >
		<div id='elggchat_sessions'> 
		</div>
        <div id="icon_wrap">
        
		<div id="elggchat_friends">
			<a class="click" href="javascript:toggleFriendsPicker();"></a>
		</div>

        <div id="elggchat_friends2">
        <div style="padding: 0 3px">
        <?php if (is_plugin_enabled('tidypics')){ ?>
        <a href="<?php echo $CONFIG->wwwroot; ?>pg/photos/friends/<?php echo $_SESSION['user']->username; ?>"><img src="<?php echo $vars['url']; ?>mod/elggchat/_graphics/icon_image.png" title="Photos" /></a>
        <?php } ?>
        
        <?php if (is_plugin_enabled('izap_videos')){ ?>
        <a href="<?php echo $CONFIG->wwwroot; ?>pg/izap_videos/<?php echo $_SESSION['user']->username; ?>/frnd"><img src="<?php echo $vars['url']; ?>mod/elggchat/_graphics/icon_video.png" title="Videos" /></a>
        <?php } ?>
        
        <?php if (is_plugin_enabled('groups')){ ?>
        <a href="<?php echo $CONFIG->wwwroot; ?>pg/groups/world/<?php echo $_SESSION['user']->username; ?>"><img src="<?php echo $vars['url']; ?>mod/elggchat/_graphics/icon_group.png" title="Groups" /></a>
        <?php } ?>
        
        <?php if (is_plugin_enabled('event_calendar')){ ?>
        <a href="<?php echo $CONFIG->wwwroot; ?>pg/event_calendar"><img src="<?php echo $vars['url']; ?>mod/elggchat/_graphics/icon_event.png" title="Events" /></a>
		<?php } ?>
        </div><!-- /elggchat_friends2 -->
        </div><!-- /style -->
        </div><!-- close icon wrap -->
		<div id="elggchat_friends_picker"></div>
		<div id='elggchat_extensions'>
			<?php
				if(get_plugin_setting("enableExtensions", "elggchat") == "yes")	echo elgg_view("elggchat/extensions");
			?> 
		</div>
	</div>
	
	<div id="toggle_elggchat_toolbar" class="toggle_elggchat_toolbar" onclick="toggleChatToolbar('fast')" title="<?php echo elgg_echo("elggchat:toolbar:minimize");?>"></div>

</div>
