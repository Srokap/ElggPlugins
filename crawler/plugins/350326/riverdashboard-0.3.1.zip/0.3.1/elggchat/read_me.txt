///////////////////////////////////////////
///           INSTRUCTIONS              ///
///////////////////////////////////////////

For elgg 1.5 add this in the css file located at views/default/elggchat/css.php add it at line 92 or you could put it anywhere but that is under the element it is hacking.

/* hack for chrome and safari */
@media screen and (-webkit-min-device-pixel-ratio:0)
{
 #elggchat_friends
 {
  margin-right:15px;
 }
}

Drop in mod folder and enable.
check settings for sound and blinking after enable.


For elgg 1.6.1
Drop in mod folder and enable.
check settings for sound and blinking after enable.

This is confirmed working for elgg 1.5 and 1.6.1
in the following browsers:

ie8
firefox 3.5
safari
chrome
minefield (new firefox alpha)

with no problems.