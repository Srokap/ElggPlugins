	<p>
		<?php echo elgg_echo("Playlist.com flashvars value:"); ?>
		<input type="text" name="params[playlist]" value="<?php echo htmlentities($vars['entity']->playlist); ?>" />	
	</p>
	
	<p>Playlist.com flashvars value:<br/> <b>config=http%3A%2F%2Fwww.profileplaylist.net%2Fext%2Fpc%2Fconfig_black_noautostart.xml&amp;mywidth=285&amp;myheight=177&amp;playlist_url=http://www.profileplaylist.net/loadplaylist.php?playlist=26711503&t=1235660023&amp;wid=os</b></p>