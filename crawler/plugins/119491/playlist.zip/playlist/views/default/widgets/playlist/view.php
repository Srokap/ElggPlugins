<?php
	 $Playlist = $vars['entity']->playlist;

	 // if the flickr id is empty, then do not sure any photos
    if($Playlist){	 
print
	 "<style type=\"text/css\">
      #images img { 
          border:none;
      }
</style>

<!-- div where the images will display -->

<div style=\"text-align: center; margin-left: auto; visibility:visible; margin-right: auto; width:285px;\"> <object width=\"285\" height=\"350\"> <param name=\"movie\" value=\"http://www.profileplaylist.net/mc/mp3player_new.swf\"></param> <param name=\"allowscriptaccess\" value=\"never\"></param> <param name=\"wmode\" value=\"transparent\"></param> <param name=\"flashvars\" value=\"$Playlist\"></param> <embed style=\"width:285px; visibility:visible; height:350px;\" allowScriptAccess=\"never\" src=\"http://www.profileplaylist.net/mc/mp3player_new.swf\" flashvars=\"$Playlist\" width=\"285\" height=\"350\" name=\"mp3player\" wmode=\"transparent\" type=\"application/x-shockwave-flash\" border=\"0\"/> </object> <br/> <a href=\"http://www.profileplaylist.net\"><img src=\"http://www.profileplaylist.net/mc/images/create_black.jpg\" border=\"0\" alt=\"Get a playlist!\"/></a> <a href=\"http://www.mysocialgroup.com/standalone/26711503\" target=\"_blank\"><img src=\"http://www.profileplaylist.net/mc/images/launch_black.jpg\" border=\"0\" alt=\"Standalone player\"/></a></div>"; ?>

<?php 

    }else{
        
        echo "You have not yet entered any Playlist.com in.";
        
    }
?>