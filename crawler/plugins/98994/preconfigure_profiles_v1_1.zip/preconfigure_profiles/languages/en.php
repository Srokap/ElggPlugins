<?php
/**
    en.php, part of Preconfigure_profiles
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
*/

$language_array_en = array(
    'preconfigure_profiles:item' => 'Preconfigure profiles',
    'preconfigure_profiles:csv_file' => 'CSV profiles source file: ',
    'preconfigure_profiles:generate' => 'Generate',
    'preconfigure_profiles:generated' => 'Generated %d profiles',
    
);

// register constants for english version of elgg site
add_translation('en', $language_array_en);

?>