<?php

/**
    generate.php, part of Preconfigure_profiles
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
*/

	// Make sure we're logged in (send us to the front page if not)
	admin_gatekeeper();


	$genCount = 0;

	if ( !isset($_FILES['csv_profiles']) || $_FILES['csv_profiles']['size'] == 0 )
	{
		// Forward to the main newsletters page
		system_message(elgg_echo('preconfigure_profiles:empty'));
		forward("pg/genprofiles");
	}


	if ( $fd = fopen($_FILES['csv_profiles']['tmp_name'], 'r') )
	{
		$accesslevel = get_input('accesslevel');
		if (!is_array($accesslevel)) $accesslevel = array();
		$dataHeader = fgetcsv($fd, 1000, ';');
		$lineCount = 0;
		while ( ($data = fgetcsv($fd, 1000, ';')) !== FALSE )
		{
			$user_profile = array();
			$user_login = $user_password = $user_name = $user_email;
			for ( $i = 0; $i < count($data); $i++)
			{
				$value = trim($data[$i]);
				if ( $dataHeader[$i] == 'user_login' )
					$user_login = $value;
				elseif ( $dataHeader[$i] == 'user_email' )
					$user_email = $value;
				elseif ( $dataHeader[$i] == 'user_name' )
					$user_name = $value;
				elseif ( isset($CONFIG->profile[$dataHeader[$i]]))
				{
					$user_profile[$dataHeader[$i]] = $value;
				}
			}
			$user_password = $user_login . '1';
			if ( ! $user_name )
			    $user_name = $user_login;

			try {
                $guid = register_user($user_login, $user_password, $user_name, $user_email, false, 0, '');
			}
			catch ( RegistrationException $e ){
				$guid = 0;
			}

			if ( $guid )
			{
				$genCount++;
   	            $new_user = get_entity($guid);
       	        // Send user validation request on register only
				request_user_validation($guid);
				set_user_validation_status($guid, true);
	//				$new_user->disable('new_user');	// Now disable
				foreach ( $user_profile as $shortname => $value)
				{
					if (isset($accesslevel[$shortname])) {
						$access_id = (int) $accesslevel[$shortname];
					} else {
						$access_id = 0;
					}
					create_metadata($guid, $shortname, $value, 'text', $guid, $access_id);
				}
			}
			$lineCount++;
		}
	}

	if ( $genCount )
	{
		system_message(sprintf(elgg_echo('preconfigure_profiles:generated'), $genCount));
	}

	forward("action/logout");

?>
