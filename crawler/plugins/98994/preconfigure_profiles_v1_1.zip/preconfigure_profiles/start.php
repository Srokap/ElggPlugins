<?php

/**
    start.php, part of Preconfigure_profiles
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
*/
	 
	function preconfigure_profiles_init() {

		// Load system configuration
		global $CONFIG;
			
		// Load the language file
		register_translations($CONFIG->pluginspath . "preconfigure_profiles/languages/");

		register_page_handler('genprofiles','preconfigure_profiles_page_handler');

		register_action("preconfigure_profiles/genprofiles",false, $CONFIG->pluginspath . "preconfigure_profiles/actions/generate.php", true);


	}
	
	function preconfigure_profiles_pagesetup() {

		if (get_context() == 'admin' && isadminloggedin()) {
			global $CONFIG;
			add_submenu_item(elgg_echo('preconfigure_profiles:item'), $CONFIG->wwwroot . 'pg/genprofiles/');
		}
	}
	
	function preconfigure_profiles_page_handler($page)
	{
		global $CONFIG;
		include($CONFIG->pluginspath . "preconfigure_profiles/index.php");
	}
	

	register_elgg_event_handler('init','system','preconfigure_profiles_init');
	register_elgg_event_handler('pagesetup','system','preconfigure_profiles_pagesetup');
	
?>