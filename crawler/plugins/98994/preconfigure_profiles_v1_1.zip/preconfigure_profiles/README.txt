/**
    README.txt, part of Preconfigure_profiles
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.


    Elgg version: 1.5
    Title: Import_Preconfigured_Profiles
    Intro: Allows to create set of users, importing them from CSV file
    Description: Plugin is compatible with any profile, field names are compared with headers in file, mandatory fields are: user_login, user_email, user_name. 
    Order and number of other fields do not matter.
    Plugin is developed by Web100 Net Technology Center, Ltd. http://web100.com.ua under the assignment of Lorinthe,BV.
    Dependencies: No
    Version: 1.1
    Licence: GPL v.3						    	
*/

The Elgg 1.x preconfigure_profiles plugin allow to import preconfigured profiles from CSV file.
This plugin require venvn_profile plugin.

*Activating the preconfigure_profiles plugin*

Simply extract the preconfigure_profiles plugin into the mod directory and
activate it as usual using the Elgg 1.x tool administration.

*Import profiles*
After instalation in admin area new menu item will appear.
Using this page you can upload CSV file with profiles info.
First line of the file is fields name.
User email used for initial user password.
You can look at example_profiles.csv file.
This file consist from fields for all user profile information


