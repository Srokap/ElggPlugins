<?php

	$german = array(


			'headermenu:members' => "Mitglieder",
			'headermenu:photos' => "Bilder",
			'headermenu:groups' => "Gruppen",
			'headermenu:videos' => "Videos",
			'headermenu:current' => "hat momentan:",
			'headermenu:andmore' => "und weitere...",
			'headermenu:home' => "Startseite",
			'headermenu:blogs' => "Blogs",
			'headermenu:bookmarks' => "Lesezeichen",
			'headermenu:ads' => "Anzeigen",
			'headermenu:discussions' => "Diskussionen",
			'headermenu:events' => "Termine",
			'headermenu:wire' => "Der Heiße Draht",
			'headermenu:public' => "öffentlich verfügbar.",
			'headermenu:register' => "Melde Dich an,",
			'headermenu:access' => "um Zugang zu mehr Inhalten zu bekommen.",


	);

	add_translation("de",$german);

?>
