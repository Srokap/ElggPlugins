<?php
$german = array(
	'admin:plugins:reorder:yes'	=> 'Die neue Anordnung der Plugins wurde gespeichert.',
	'admin:plugins:reorder:no'	=> 'Das Speichern der neuen Anordnung der Plugins ist fehlgeschlagen!',
);

add_translation("de",$german);
