<?php

	$german = array(
		'advanced_comments' => "Advanced comments",


		'advanced_comments:header:order' => "Anordung der Kommentare",
		'advanced_comments:header:order:asc' => "Älteste zuerst",
		'advanced_comments:header:order:desc' => "Neueste zuerst",

		'advanced_comments:header:limit' => "Anzahl der anzuzeigenden Kommentare",
		'advanced_comments:header:auto_load' => "Automatisch mehr nachladen",

	);

	add_translation("de", $german);

?>