<?php

$german = array(
		 'recentdiscussions:title' => "Neueste Diskussionsbeiträge",
		 );

add_translation("de",$german);

?>