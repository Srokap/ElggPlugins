<?php

	$german = array(

		/**
		 * Menu items and titles
		 */

		'tinymce:remove' => "Editor ein-/ausblenden",
		'vazco_tinymce:settings:option' => 'Wähle die Version, in der TinyMCE angezeigt werden soll',
		'vazco_tinymce:option:emoticons' => 'Vereinfachte Version (mit Emoticons)',
		'vazco_tinymce:option:full' => 'Vollständige Version',
		'vazco_tinymce:option:plain' => 'Vereinfachte Version (ohne Emoticons)',
	);

	add_translation("de",$german);

?>