<?php
$german = array(
	'admin:plugins:reorder:yes'			=> 'Die neue Anordnung der Plugins wurde gespeichert.',
	'admin:plugins:reorder:no'			=> 'Das Speichern der neuen Anordnung der Plugins ist fehlgeschlagen!',
	'admin:plugins:extension'       	=> 'Erweiterungen',
	'admin:plugins:plugins_name_list' 	=> 'Liste der Plugins (eine durch Komma getrennte Liste der momentan aktivierten Plugins)',
	'admin:plugins:apply' 				=> 'Anwenden',
	'admin:plugins:clear_list'      	=> 'Liste leeren',
	'admin:plugins:reset_list'      	=> 'Liste zurücksetzen',
	'admin:plugins:select_list'     	=> 'Liste auswählen',
);

add_translation("de", $german);
