<?php
	/**
	* DraggableWidgets - Languages
	*
	* @package draggable_widgets
	* @author ColdTrick IT Solutions
	* @copyright Coldtrick IT Solutions 2009
	* @link http://www.coldtrick.com/
	*/
	$german = array(
			'draggable_widgets:add' => "Hier klicken, um ein neues Widget hinzuzufügen.",
			'draggable_widgets:delete' => "Bist Du sicher, dass Du dieses Widget entfernen willst?",







	);

	add_translation("de",$german);

?>