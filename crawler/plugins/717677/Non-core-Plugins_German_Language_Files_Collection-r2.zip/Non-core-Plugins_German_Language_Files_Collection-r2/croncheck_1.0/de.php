<?php

	$german = array(

		'croncheck:info' => 'Die letzten Durchläufe der Cronjobs',
		'croncheck:registered' => 'Registrierte Events pro Cronintervall',
		'croncheck:interval' => 'Intervall',
		'croncheck:timestamp' => 'Zeitstempel',
		'croncheck:friendly_time' => 'Zeitpunkt',

		'croncheck:no_run' => 'Dieser Cronjob ist bisher noch nicht ausgeführt worden (seit das Croncheck-Plugin aktiviert wurde).',
		'croncheck:none_registered' => 'Für dieses Cronintervall sind keine Events registriert.',

	);

	add_translation("de",$german);

?>