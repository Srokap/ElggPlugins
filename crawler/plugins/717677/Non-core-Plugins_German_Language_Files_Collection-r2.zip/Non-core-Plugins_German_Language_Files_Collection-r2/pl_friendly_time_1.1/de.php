<?php

  $german = array(
/**
 * Time strings
 */
	'friendlytime:weeks' => "vor etwa 2 Wochen",
	'friendlytime:weeks:singular' => "letzte Woche",
	'friendlytime:date' => "j F Y",
	 );

add_translation("de", $german);
?>