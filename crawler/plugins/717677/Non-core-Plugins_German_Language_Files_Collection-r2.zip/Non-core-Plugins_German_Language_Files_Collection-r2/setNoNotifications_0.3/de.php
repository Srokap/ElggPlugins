<?php
	$german = array(
		'users:notifications:disabled' => 'Benutzer mit deaktivierter Email-Benachrichtigungseinstellung',
		'users:notifications:enabled' => 'Benutzer mit aktivierter Email-Benachrichtigungseinstellung',
		'users:notifications:choose:type:a' => 'Alle Benutzer',
		'users:notifications:choose:type:b' => 'Neue Benutzer',
		'users:notifications:choose:type' => 'Email-Benachrichtigungseinstellung bei Anmeldung auf der Community-Seite auf deaktiviert setzen für',
	);

	add_translation("de",$german);
?>