<?php

// saml_group_id --> array(elgg_group_id)


$group_mapping = array ();

// Mapping example
$group_mapping['student'] = array(48);
//$group_mapping['teacher'] = array(43);

?>
