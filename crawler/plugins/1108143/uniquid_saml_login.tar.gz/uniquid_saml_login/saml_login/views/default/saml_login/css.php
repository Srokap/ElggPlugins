<?php
/**
 * Elgg SAML CSS
 */
?>

#saml_login_site_settings .text_input
{
	width: 350px;
}
#login_with_saml
{
	padding: 10px 0 0 0;
}
