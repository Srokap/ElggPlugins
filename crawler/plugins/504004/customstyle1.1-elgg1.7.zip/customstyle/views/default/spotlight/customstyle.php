<?php
	/**
	* CustomStyle - Spotlight Information
	* 
	* @package customstyle
	* @author ColdTrick IT Solutions
	* @copyright Coldtrick IT Solutions 2009
	* @link http://www.coldtrick.com/
	*/
echo elgg_echo('customstyle:spotlight');
?>
