<?php
/**
 * LiHaiBar
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Callum West
 * @copyright LiHai Learning 2012
 */

//include_once 'lib/functions.php';

function LiHaiBar_init() {

	// Extend system CSS with our own styles
	elgg_extend_view('css','LiHaiBar/css');
	
	// We need to extend a view that is never overwritten but always there
	elgg_extend_view('page/elements/topbar', 'LiHaiBar/bar');
	
	elgg_register_js('LiHaiBar', elgg_get_site_url() . "mod/LiHaiBar/js/javascript.js");

	// Load the language file
	register_translations(elgg_get_plugins_path() . "LiHaiBar/languages/");

	//register action to approve/delete comments
	//elgg_register_action("annotation/review", elgg_get_plugins_path() . "moderated_comments/actions/annotation/review.php");
	
	
}


// call init
elgg_register_event_handler('init','system','LiHaiBar_init');

?>