<?php

/**
 * LiHaiBar
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Callum West
 * @copyright LiHai Learning 2012
 */
 
 
 
 	
if(elgg_is_logged_in()){ // Don't show for users who are logged out
?>


<div id="LiHaiBar" class="LiHaiBar-default">

	<?php

		echo elgg_view("LiHaiBar/extend");

	?>
	
</div>

<?php

} // End check for logged in user

?>