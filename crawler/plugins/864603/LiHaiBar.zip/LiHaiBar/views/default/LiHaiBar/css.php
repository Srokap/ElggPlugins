<?php

/**
 * LiHaiBar
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Callum West
 * @copyright LiHai Learning 2012
 */
 
?>


#LiHaiBar {
	position: fixed;
	bottom: 0px;
	left: 10px;
	right: 10px;
	padding: 2px;
	height: 30px;
	margin: 0 0 0 0;
}
.LiHaiBar-default {
	background: rgb(30,87,153);
	background: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiA/Pgo8c3ZnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgdmlld0JveD0iMCAwIDEgMSIgcHJlc2VydmVBc3BlY3RSYXRpbz0ibm9uZSI+CiAgPGxpbmVhckdyYWRpZW50IGlkPSJncmFkLXVjZ2ctZ2VuZXJhdGVkIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgeDE9IjAlIiB5MT0iMCUiIHgyPSIxMDAlIiB5Mj0iMTAwJSI+CiAgICA8c3RvcCBvZmZzZXQ9IjAlIiBzdG9wLWNvbG9yPSIjMWU1Nzk5IiBzdG9wLW9wYWNpdHk9IjEiLz4KICAgIDxzdG9wIG9mZnNldD0iNTElIiBzdG9wLWNvbG9yPSIjMjA3Y2NhIiBzdG9wLW9wYWNpdHk9IjEiLz4KICAgIDxzdG9wIG9mZnNldD0iMTAwJSIgc3RvcC1jb2xvcj0iIzdkYjllOCIgc3RvcC1vcGFjaXR5PSIxIi8+CiAgPC9saW5lYXJHcmFkaWVudD4KICA8cmVjdCB4PSIwIiB5PSIwIiB3aWR0aD0iMSIgaGVpZ2h0PSIxIiBmaWxsPSJ1cmwoI2dyYWQtdWNnZy1nZW5lcmF0ZWQpIiAvPgo8L3N2Zz4=);
	background: -moz-linear-gradient(-45deg,  rgba(30,87,153,1) 0%, rgba(32,124,202,1) 51%, rgba(125,185,232,1) 100%);
	background: -webkit-gradient(linear, left top, right bottom, color-stop(0%,rgba(30,87,153,1)), color-stop(51%,rgba(32,124,202,1)), color-stop(100%,rgba(125,185,232,1)));
	background: -webkit-linear-gradient(-45deg,  rgba(30,87,153,1) 0%,rgba(32,124,202,1) 51%,rgba(125,185,232,1) 100%);
	background: -o-linear-gradient(-45deg,  rgba(30,87,153,1) 0%,rgba(32,124,202,1) 51%,rgba(125,185,232,1) 100%);
	background: -ms-linear-gradient(-45deg,  rgba(30,87,153,1) 0%,rgba(32,124,202,1) 51%,rgba(125,185,232,1) 100%);
	background: linear-gradient(-45deg,  rgba(30,87,153,1) 0%,rgba(32,124,202,1) 51%,rgba(125,185,232,1) 100%);
	filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#1e5799', endColorstr='#7db9e8',GradientType=1 );
	-webkit-border-top-left-radius: 8px;
	-webkit-border-top-right-radius: 8px;
	-moz-border-radius-topleft: 8px;
	-moz-border-radius-topright: 8px;
	border-top-left-radius: 8px;
	border-top-right-radius: 8px;
	border-top: 2px outset #1e5799;
	border-left: 2px outset #1e5799;
	border-right: 2px outset #1e5799;
	margin: 0 10px 0 10px;
}
.gradient {
       filter: none\9;
}