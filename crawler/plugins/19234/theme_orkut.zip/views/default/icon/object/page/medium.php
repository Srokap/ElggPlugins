<?php
	echo $vars['url'] . "mod/theme_orkut/graphics/file_icons/pages_lrg.gif";
?>