<?php
	echo $vars['url'] . "mod/theme_orkut/graphics/user_icons/defaulttiny.gif";
?>