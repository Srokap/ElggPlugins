<?php
	echo $vars['url'] . "mod/theme_orkut/graphics/group_icons/defaultmedium.gif";
?>