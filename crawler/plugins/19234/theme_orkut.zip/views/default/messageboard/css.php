<?php

	/**
	 * Elgg Messageboard CSS extender 
	 * 
	 * @package ElggMessageBoard
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @copyright Laithai Team 2009
	 * @link http://elgg.com/
	 */

?>
/*-------------------------------
MESSAGEBOARD PLUGIN
-------------------------------*/
/* input msg area */
#mb_input_wrapper {


}

#mb_input_wrapper .input_textarea {
	width:716px;
}
.collapsable_box_content #mb_input_wrapper .input_textarea {
	width:290px;
}
.message_item_timestamp {
	font-size:90%;
	padding:10px 0 0 0;
}
p.message_item_timestamp {
	margin-bottom: 10px;
}
/* wraps each message */
.messageboard {
	margin:10px 0 10px 0;
    background:#cccccc;
}
.messageboard .message_sender {
	float:left;
	margin: 5px 10px 0 5px;
}
* html .messageboard .message_sender { margin: 5px 10px 0 2px; } /* IE6 */
*+html .messageboard .message_sender {  } /* IE7 */

.messageboard .message p {
	line-height: 1.2em;
	background:#fff;
	margin:0 6px 4px 6px;
	padding:4px;
	-moz-border-radius-bottomleft:5px;
	-moz-border-radius-bottomright:5px;
	-moz-border-radius-topleft:5px;
	-moz-border-radius-topright:5px;
	-webkit-border-top-left-radius:5px;
	-webkit-border-top-right-radius:5px;
	-webkit-border-bottom-left-radius:5px;
	-webkit-border-bottom-right-radius:5px;
	overflow-y:hidden;
	overflow-x:auto;
	color:#333333;
}

.message_buttons {
	padding:0 0 3px 4px;
	margin:0;
	font-size: 90%;
	color:#666666;
}

.messageboard .delete_message a {
	display:block;
	float:right;
	cursor: pointer;
	width:14px;
	height:14px;
	margin:0 3px 3px 0;
	background: url("<?php echo $vars['url']; ?>_graphics/icon_customise_remove.png") no-repeat 0 0;
	text-indent: -9000px;
}
.messageboard .delete_message a:hover {
	background-position: 0 -16px;
}

#two_column_left_sidebar_maincontent #messageboard_wrapper {

}

#two_column_left_sidebar_maincontent #mb_input_wrapper {

}

.collapsable_box_content #mb_input_wrapper #messageboard_wrapper {

}





