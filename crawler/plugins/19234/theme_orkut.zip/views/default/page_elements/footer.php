<?php

	/**
	 * Elgg footer
	 * The standard HTML footer that displays across the site
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Laithai Team 2009
	 * @link http://elgg.in.th/
	 * 
	 */
	 
	 // get the tools menu
	$menu = get_register('menu');

?>

<div class="clearfloat"></div>
</div><!-- /#page_wrapper -->


<div id="layout_footer">
<div class="footer_r">
</div>
<div class="footer_l">
<div class="foottxt" align="center">
    <table width="100%" border="0" align="center" cellpadding="2" cellspacing="2">
  <tr>
    <td><a href="http://www.elgg.org" target="_blank">
		<img src="<?php echo $vars['url']; ?>_graphics/powered_by_elgg_badge_drk_bckgnd.gif" border="0" />
		</a></td>
    <td>
    <?php
			foreach($menu as $item) {

    				echo " | <a href=\"{$item->value}\">" . $item->name . "</a>";

			}
		?>
		|</td>
    <td><b>Design By :</b><a href="http://www.elgg.in.th" target="_blank"> Laithai Team</a></td>
  </tr>
</table>
</div>
</div>
</div><!-- /#layout_footer -->

<div class="clearfloat"></div>


</div><!-- /#page_container -->

</body>
</html>