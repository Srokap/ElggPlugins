<?php

	if ($vars['size'] == 'large') {
		$ext = '_lrg';
	} else {
		$ext = '';
	}
	echo "<img src=\"{$CONFIG->wwwroot}mod/theme_orkut/graphics/file_icons/music{$ext}.gif\" border=\"0\" />";

?>