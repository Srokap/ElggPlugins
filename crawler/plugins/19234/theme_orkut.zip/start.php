<?php

    /**
     * Orkut theme
     **/
     
     /**
	 * Initialise the theme 
	 *
	 */
	function orkut_init(){
	
    }
	
	// Initialise log browser
	register_elgg_event_handler('init','system','orkut_init');
	
?>