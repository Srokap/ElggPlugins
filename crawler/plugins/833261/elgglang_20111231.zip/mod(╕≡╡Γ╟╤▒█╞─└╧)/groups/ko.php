<?php
	/**
	 * Elgg groups plugin language pack
	 *
	 * @package ElggGroups
	 */

	$korean = array(

		/**
		 * Menu items and titles
		 */

			'groups' => "그룹들",
			'groups:owned' => "당신이 속한 그룹들",
			'groups:yours' => "당신의 그룹들",
			'groups:user' => "%s'의 그룹들",
			'groups:all' => "사이트의 모든 그룹들",
			'groups:new' => "새로운 그룹을 생성",
			'groups:edit' => "그룹 편집",
			'groups:delete' => '그룹 삭제',
			'groups:membershiprequests' => '그룹 참여 요청 관리',
			'groups:invitations' => '그룹 초청',

			'groups:icon' => '그룹 아이콘(변경하지 않으려면 빈칸으로 두세요.)',
			'groups:name' => '그룹 이름',
			'groups:username' => '그룹 짧은 이름(URL로 보여지는, 영숫자 문자 전용)',
			'groups:description' => '설명',
			'groups:briefdescription' => '간략한 설명',
			'groups:interests' => '태그들',
			'groups:website' => '웹사이트',
			'groups:members' => '그룹 멤버들',
			'groups:membership' => "그룹 멤버쉽 허가",
			'groups:access' => "접근 허가",
			'groups:owner' => "소유자",
			'groups:widget:num_display' => '보여줄 그룹의 수',
			'groups:widget:membership' => '그룹 멤버쉽',
			'groups:widgets:description' => '당신의 프로파일에 당신이 멤버인 그룹을 표시하기',
			'groups:noaccess' => '그룹에 접근이 없음',
			'groups:cantedit' => '당신은 이 그룹을 편집할 수 없습니다.',
			'groups:saved' => '그룹이 저장됨',
			'groups:featured' => '주요한 그룹',
			'groups:makeunfeatured' => '주요하지 않음',
			'groups:makefeatured' => '주요한지를 확인',
			'groups:featuredon' => '당신은 이 그룹을 주요한 것으로 만들었습니다.',
			'groups:unfeature' => '당신은 이 그룹을 주요한 목록에서 제거했습니다.',
			'groups:joinrequest' => '멤버쉽을 요청',
			'groups:join' => '그룹 참여',
			'groups:leave' => '그룹 탈퇴',
			'groups:invite' => '친구를 초대',
			'groups:inviteto' => "'%s'에 친구를 초대",
			'groups:nofriends' => "당신은 이 그룹에 초대 되지 않은 친구가 없습니다.",
			'groups:viagroups' => "그룹들을 통해서",
			'groups:group' => "그룹",
			'groups:search:tags' => "태그",

			'groups:memberlist' => "그룹 멤버들",
			'groups:membersof' => "%s의 멤버",
			'groups:members:more' => "더 많은 멤버를 보기",

			'groups:notfound' => "그룹을 찾을 수 없습니다.",
			'groups:notfound:details' => "요청된 그룹은 존재하지 않거나 당신은 그룹에 접근할 수 없습니다.",

			'groups:requests:none' => '이번에는 눈에 띄는 멤버쉽 요청이 없습니다.',

			'groups:invitations:none' => '이번에는 눈에 띄는 초청이 없습니다.',

			'item:object:groupforumtopic' => "토론 주제들",

			'groupforumtopic:new' => "새로운 토론 포스트",

			'groups:count' => "그룹들이 생성됨groups created",
			'groups:open' => "그룹 열기",
			'groups:closed' => "닫힌 그룹",
			'groups:member' => "멤버들",
			'groups:searchtag' => "태그로 그룹을 찾기",


			/*
			 * Access
			 */
			'groups:access:private' => '닫힘-사용자는 초대되어야 합니다.',
			'groups:access:public' => '열림-어떤 사용자든지 참여 가능합니다.',
			'groups:closedgroup' => '이 그룹은 닫힌 멤버쉽이 있습니다.',
			'groups:closedgroup:request' => '추가되도록 요청하기 위해서, "멤버쉽 요청" 메뉴 링크를 클릭하세요.',
			'groups:visibility' => '이 그룹을 누가 볼 수 있습니까?',

			/*
			Group tools
			*/
			'groups:enablepages' => '그룹 페이지를 활성화',
			'groups:enableforum' => '그룹 토론을 활성화',
			'groups:enablefiles' => '그룹 파일을 활성화',
			'groups:yes' => '네',
			'groups:no' => '아니오',

			'group:created' => '%d 포스트들로 생성된 %s',
			'groups:lastupdated' => '%s에 의해서 가장 마지막에 업데이트된 %s',
			'groups:lastcomment' => '%s에 의한 가장 마지막 덧글 %s',
			'groups:pages' => '그룹 페이지들',
			'groups:files' => '그룹 파일들',

			/*
			Group forum strings
			*/

			'group:replies' => '답글들',
			'groups:forum' => '그룹 토론',
			'groups:addtopic' => '주제를 추가',
			'groups:forumlatest' => '가장 최근 토론',
			'groups:latestdiscussion' => '가장 최근 토론',
			'groups:newest' => '가장 최신',
			'groups:popular' => '인기있는',
			'groupspost:success' => '당신의 덧글은 성공적으로 포스트되었습니다.',
			'groups:alldiscussion' => '가장 최근 토론',
			'groups:edittopic' => '주제 편집',
			'groups:topicmessage' => '주제 메시지',
			'groups:topicstatus' => '주제 상태',
			'groups:reply' => '덧글을 포스트',
			'groups:topic' => '주제',
			'groups:posts' => '포스트들',
			'groups:lastperson' => '마지막 사람',
			'groups:when' => '언제',
			'grouptopic:notcreated' => '어떤 주제도 생성되지 않았습니다.',
			'groups:topicopen' => '열기',
			'groups:topicclosed' => '닫힘',
			'groups:topicresolved' => '해결됨',
			'grouptopic:created' => '당신의 주제가 생성되었습니다.',
			'groupstopic:deleted' => '주제가 삭제되었습니다.',
			'groups:topicsticky' => '어려운',
			'groups:topicisclosed' => '이 주제는 닫힘니다.',
			'groups:topiccloseddesc' => '이 주제는 지금 닫힌 상태이기 때문에 새로운 덧글을 달 수 없습니다.',
			'grouptopic:error' => '당신의 그룹 주제는 생성될 수 없습니다. 다시 시도하거나 시스템 관리자에게 연락하세요.',
			'groups:forumpost:edited' => "당신은 성공적으로 포럼 포스트를 편집했습니다.",
			'groups:forumpost:error' => "포럼 포스트를 편집하는데 문제가 있었습니다.",
			'groups:privategroup' => '이 그룹은 닫힙니다. 멤버쉽을 요청',
			'groups:notitle' => '그룹들은 타이틀이 있어야 합니다. ',
			'groups:cantjoin' => '그룹에 참여할 수 없습니다.',
			'groups:cantleave' => '그룹을 탈퇴할 수 없었습니다.',
			'groups:addedtogroup' => '그룹에 사용자를 추가하는데 성공했습니다.',
			'groups:joinrequestnotmade' => '그룹에 참여를 요청할 수 없었습니다.',
			'groups:joinrequestmade' => '그룹에 가입을 요청',
			'groups:joined' => '성공적으로 그룹에 가입됨!',
			'groups:left' => '그룹을 탈퇴하는데 성공',
			'groups:notowner' => '미안합니다. 당신은 이 그룹의 소유자가 아닙니다.',
			'groups:notmember' => '미안합니다. 당신은 이 그룹의 회원이 아닙니다.',
			'groups:alreadymember' => '당신은 이미 이 그룹의 회원입니다!',
			'groups:userinvited' => '사용자가 초대되었습니다.',
			'groups:usernotinvited' => '사용자가 초대될 수 없었습니다.',
			'groups:useralreadyinvited' => '사용자는 이미 초대되었습니다.',
			'groups:updated' => "마지막 덧글",
			'groups:invite:subject' => "%s 당신은 %s를 가입하도록 초대 되었습니다!",
			'groups:started' => "의해서 시작됨",
			'groups:joinrequest:remove:check' => '이 가입 요청을 삭제하는 것이 확실합니까?',
			'groups:invite:remove:check' => '이 초대를 삭제하기를 원하는 것이 확실합니까?',
			'groups:invite:body' => "하이! %s,

%s 당신을 '%s' 그룹에 가입하도록 초대했습니다. 당신에 대한 초대를 보기 위해서 아래를 클릭하세요:

%s",

			'groups:welcome:subject' => "%s 그룹에 오신것을 환영합니다!",
			'groups:welcome:body' => "하이 %s!

당신은 지금 '%s' 그룹의 회원입니다! 포스팅을 시작하기 위해서 아래를 클릭하세요!

%s",

			'groups:request:subject' => "%s 는 %s를 가입하도록 요청되었습니다.",
			'groups:request:body' => "하이 %s,

%s 는 %s를 가입하도록 요청되었습니다. 그들의 프로필을 보기위해서 아래를 클릭하세요:

%s

혹은 그룹의 가입 요청을 보기 위해서 아래를 클릭하세요:

%s",

			/*
				Forum river items
			*/

			'groups:river:member' => '%s 은 지금 회원입니다.',
			'groups:river:create' => '%s이(가) 그룹을 생성했습니다.',
			'groupforum:river:updated' => '%s 이(가) 업데이트 했습니다.',
			'groupforum:river:update' => '이 토론 주제',
			'groupforum:river:created' => '%s이(가) 생성되었습니다.',
			'groupforum:river:create' => '새로운 토론 주제가 게시되었습니다.',
			'groupforum:river:posted' => '%s이(가) 새로운 덧글을 포스트 했습니다.',
			'groupforum:river:annotate:create' => '이 토론 주제에 관해서',
			'groupforum:river:postedtopic' => '%s이(가) 게시된 새로운 토론 주제를 시작했습니다.',
			'groups:river:togroup' => '그룹으로',

			'groups:nowidgets' => '어떤 위젯도 이 그룹에 대해서 정의되지 않았습니다.',


			'groups:widgets:members:title' => '그룹 회원들',
			'groups:widgets:members:description' => '그룹의 회원 목록',
			'groups:widgets:members:label:displaynum' => '그룹의 회원 목록',
			'groups:widgets:members:label:pleaseedit' => '이 위젯을 설정해 주세요.',

			'groups:widgets:entities:title' => "그룹에 있는 객체들",
			'groups:widgets:entities:description' => "이 그룹에 저장된 객체 목록",
			'groups:widgets:entities:label:displaynum' => '그룹의 객체 목록',
			'groups:widgets:entities:label:pleaseedit' => '이 이위젯을 설정해 주세요.',

			'groups:forumtopic:edited' => '포럼 주제가 성공적으로 편집되었습니다.',

			'groups:allowhiddengroups' => '당신은 개인적인 (보이지 않는) 그룹들을 허가하겠습니까?',

			/**
			 * Action messages
			 */
			'group:deleted' => '그룹과 그룹 컨텐츠들이 삭제 되었습니다.',
			'group:notdeleted' => '그룹은 삭제될 수 없었습니다.',

			'grouppost:deleted' => '그룹 포스팅이 성공적으로 삭제 되었습니다.',
			'grouppost:notdeleted' => '그룹 포스팅이 삭제 될 수 없었습니다.',
			'groupstopic:deleted' => '주제 삭제됨',
			'groupstopic:notdeleted' => '주제가 삭제 되지 않음',
			'grouptopic:blank' => '주제 없음',
			'grouptopic:notfound' => '주제를 찾을 수 없습니다.',
			'grouppost:nopost' => '빈 포스트',
			'groups:deletewarning' => "이 그룹을 삭제하는 것이 확실합니까? 되돌리기가 없습니다!",

			'groups:invitekilled' => '이 초대는 삭제 되었습니다.',
			'groups:joinrequestkilled' => '가입 요청은 삭제 되었습니다.',
	);

	add_translation("ko",$korean);
?>
