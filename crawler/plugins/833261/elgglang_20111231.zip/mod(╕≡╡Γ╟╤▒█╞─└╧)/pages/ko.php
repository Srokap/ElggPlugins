<?php
	/**
	 * Elgg pages plugin language pack
	 * 
	 * @package ElggPages
	 */

	$korean = array(
	
		/**
		 * Menu items and titles
		 */
			
			'pages' => "페이지",
			'pages:yours' => "당신의 페이지",
			'pages:user' => "페이지 홈",
			'pages:group' => "그룹 페이지",
			'pages:all' => "사이트 모든 페이지",
			'pages:new' => "새로운 페잊",
			'pages:groupprofile' => "그룹 페이지들",
			'pages:edit' => "이 페이지를 편집",
			'pages:delete' => "이 페이지를 삭제",
			'pages:history' => "페이지 히스토리",
			'pages:view' => "페이지 보기",
			'pages:welcome' => "환영 메시지를 편집",
			'pages:welcomemessage' => "%s의 페이지 도구에 오신 것을 환영합니다. 이 도구는 어떤 주제에 관해서 그것들을 보고 편집할 수 있는 사람이 누구인지를 선택할 수 있는  페이지를 만들도록 해 줄 것입니다.",
			'pages:welcomeerror' => "환영 메시지를 저장하는 데 문제가 있었습니다.",
			'pages:welcomeposted' => "환영 메시지가 포스트 되었습니다.",
			'pages:navigation' => "페이지 네비게이션",
	        'pages:via' => "페이지를 통해서",
			'item:object:page_top' => '상위 레벨 페이지들',
			'item:object:page' => '페이지들',
			'item:object:pages_welcome' => '페이지들은 블럭들을 환영합니다.',
			'pages:nogroup' => '이 그룹은 아직 페이지가 없습니다.',
			'pages:more' => '페이지 더 보기',
			
		/**
		* River
		**/
		
		    'pages:river:annotate' => "이 페이지의 덧글",
		    'pages:river:created' => "%s 씀",
	        'pages:river:updated' => "%s 업데이트함",
	        'pages:river:posted' => "%s 포스트됨",
			'pages:river:create' => "타이틀된 새로운 페이지",
	        'pages:river:update' => "타이틀 된 페이지",
	        'page:river:annotate' => "이 페이지의 덧글",
	        'page_top:river:annotate' => "이 페이지의 덧글",
	
		/**
		 * Form fields
		 */
	
			'pages:title' => '페이지 타이틀',
			'pages:description' => '당신의 페이지 항목',
			'pages:tags' => '태그들',	
			'pages:access_id' => '접근',
			'pages:write_access_id' => '쓰기 접근',
		
		/**
		 * Status and error messages
		 */
			'pages:noaccess' => '페이지에 접근 허용 안 됨',
			'pages:cantedit' => '당신은 이 페이지를 편집할 수 없습니다.',
			'pages:saved' => '페이지 저장됨',
			'pages:notsaved' => '페이지를 저장할 수 없었습니다.',
			'pages:notitle' => '당신은 페이지에 대해서 제목을 분류해야만 합니다.',
			'pages:delete:success' => '페이지 삭제에 성공했습니다.',
			'pages:delete:failure' => '이 페이지는 삭제 될 수 없습니다.',
	
		/**
		 * Page
		 */
			'pages:strapline' => '%s에 의해서 가장 최근 업데이트된 %s',
	
		/**
		 * History
		 */
			'pages:revision' => '%s에 의해서 생성된 %s를 개정',
			
		/**
		 * Widget
		 **/
		 
		    'pages:num' => '보여질 페이지의 숫자',
			'pages:widget:description' => "이것은 당신의 페이지의 목록입니다.",
	
		/**
		 * Submenu items
		 */
			'pages:label:view' => "페이지 보기V",
			'pages:label:edit' => "페이지 편집",
			'pages:label:history' => "페이지 히스토리",
	
		/**
		 * Sidebar items
		 */
			'pages:sidebar:this' => "이 페이지",
			'pages:sidebar:children' => "하위 페이지",
			'pages:sidebar:parent' => "부모",
	
			'pages:newchild' => "하위 페이지 생성하기",
			'pages:backtoparent' => "'%s'로 되돌리기",
	);
					
	add_translation("ko",$korean);
?>