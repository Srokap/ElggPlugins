<?php
/**
 * Korean strings
 */

$ko = array(
	'login_as:login_as' => '~로 로그인',
	'login_as:logged_in_as_user' => '당신은 지금 %s로 로그인 되었습니다.',

	'login_as:return_to_user' => '%s로 로그인',

	'login_as:unknown_user' => '알려지지 않은 사용자. 로그인 할 수 없습니다.',
	'login_as:could_not_login_as_user' => '%s로 로그인 할 수 없습니다.',
);

add_translation('ko', $ko);