<?php

	$korean = array(
			
		'members:members' => "구성원들",
	    'members:online' => "지금 활동하고 있는 사용자들",
	    'members:active' => "사이트 사용자들",
	    'members:searchtag' => "태그를 통해서 사용자 찾기",
	    'members:searchname' => "이름으로 사용자 찾기",
	   
		'members:label:newest' => '가장 최근',
		'members:label:popular' => '인기있는',
		'members:label:active' => '활동적인',
		'members:search:name' => "사용자의 이름",
		'members:search:tags' => '태그들',
		
	);
					
	add_translation("ko",$korean);

?>