<?php
/**
 * Categories English language file
 */

$korean = array(
	'categories' => '카테고리',
	'categories:settings' => '사이트 카테고리 설정',
	'categories:explanation' => '당신의 시스템을 통해서 사용될 미리 정의된 사이트-와이드 카테고리를 설정하기 위해서, 아래에, "," 로 구분해서 입력하세요. 호환되는 도구는 사용자가 컨텐츠를 편집하거나 생성할 때 그것을 보여줄 것입니다.',	
	'categories:save:success' => '사이트 카테고리가 성공적으로 저장되었습니다.',
	'categories:results' => "사이트 카테고리에 대한 결과 : %s",
	'categories:on_activate_reminder' => "사이트-와이트 카테고리는 당신이 카테고리를 추가할 때까지 동작하지 않을 것입니다. <a href=\"%s\">카테고리를 추가.</a>",
);

add_translation("ko", $korean);