<?php

$korean = array(

	/**
	 * Friends widget
	 */
	'friends:widget:description' => "친구들 중에 몇 명을 보여 주기",
	'friends:num_display' => "보여줄 친구의 수",
	'friends:icon_size' => "아이콘 크기",
	'friends:tiny' => "작은(tiny)",
	'friends:small' => "소규모(small)",
);

add_translation("ko", $korean);
