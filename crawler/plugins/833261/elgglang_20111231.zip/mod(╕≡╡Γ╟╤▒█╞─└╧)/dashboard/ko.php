<?php
/**
 * User dashboard languages
 */

$korean = array(
	'dashboard:widget:group:title' => '그룹 활동',
	'dashboard:widget:group:desc' => '당신의 그룹 중에 하나에서 활동을 보기',
	'dashboard:widget:group:select' => '그룹을 선택',
	'dashboard:widget:group:noactivity' => '이 그룹에는 어떤 활동도 없습니다.',
	'dashboard:widget:group:noselect' => '그룹을 선택하기 위해서 이 위젯을 편집하세요.',
);

add_translation("ko", $korean);
