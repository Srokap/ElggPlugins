<?php

	$korean = array(

		/**
		 * Menu items and titles
		 */

			'thewire' => "글방",
			'thewire:user' => "%s'의 글방",
			'thewire:posttitle' => "글방에 있는 %s'의 노트들 : %s",
			'thewire:everyone' => "모든 글방에 있는 글",
			'thewire:friends:title' => "글방에 %s'의 친구",
			'thewire:friends' => "친구들의 글방에 글 남기기",

			'thewire:yours' => "당신의 글방에 있는 포스트",
			'thewire:theirs' => "%s의 글방 포스트",

			'thewire:strapline' => "%s",

			'thewire:add' => "글방에 포스트",
			'thewire:text' => "글방에 있는 노트",
			'thewire:reply' => "답변",
			'thewire:via_method' => "%s 통해서",
			'thewire:wired' => "글방에 포스트 됨",
			'thewire:charleft' => "문자 왼쪽으로",
			'item:object:thewire' => "글방 포스트들",
			'thewire:notedeleted' => "삭제된 노트",
			'thewire:doing' => "당신은 무엇을 하고 있나요? 글방에 있는 모든 사람들에게 말하세요:",
			'thewire:newpost' => '새로운 글방의 글',
			'thewire:addpost' => '글방에 글을 남김',
			'thewire:by' => "%s에 의해서 글방에 포스트",
			'thewire:update' => '업데이트',


		/**
		 * The wire river
		 **/

			//generic terms to use
			'thewire:river:created' => "%s 포스트 됨",

			//these get inserted into the river links to take the user to the entity
			'thewire:river:create' => "글방에.",

		/**
		 * Wire widget
		 **/

			'thewire:sitedesc' => '이 위젯은 글방에 포스트된 사이트의 가장 최근  노트들을 보여 줍니다. ',
			'thewire:yourdesc' => '이 위젯은 당신이 가장 최근에 글방의 포스트를 보여 줍니다. ',
			'thewire:friendsdesc' => '이 위젯은 글방에 있는 당신의 친구들로 부터 가장 최근 것을 보여 줄 것입니다.',
			'thewire:num' => '보여주기 할 아이템의 숫자',
			'thewire:moreposts' => '더 많은 글방의 글들',


		/**
		 * Status messages
		 */

			'thewire:posted' => "메시지가 성공적으로 글방에 포스트 되었습니다.",
			'thewire:deleted' => "글방에 있는 포스트가 성공적으로 삭제되었습니다.",

		/**
		 * Error messages
		 */

			'thewire:blank' => "미안합니다; 그것을 저장하기 전에 텍스트 박스에 실제로 무언가를 쓸 필요가 있습니다.",
			'thewire:notfound' => "미안합니다; 분류된 글방의 글들을 찾을 수 없었습니다.",
			'thewire:notdeleted' => "미안합니다; 이 글방의 글을 삭제할 수 없었습니다.",


		/**
		 * Settings
		 */
			'thewire:smsnumber' => "당신의 모바일 번호와 다르다면 당신의 SMS 번호(모바일 번호는 글방에서 그것을 사용하기 위해서는 공개로 설정되어야 함) 모든 폰 번호는 국제 형식으로 되어야 합니다.",
			'thewire:channelsms' => "SMS 메시지를 보내기 위한 번호는 <b>%s</b> 입니다.",

		// twitter
			'thewire:twitterservice:desc' => '트윗의 모든 포스트들이 글방으로 만들어 졌습니다.',

	);

	add_translation("ko",$korean);

?>