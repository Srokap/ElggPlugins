<?php
/**
 * Custom Index English language file
 */

$korean = array(	
	'custom:bookmarks' => "가장 최근 북마크",
	'custom:groups' => "가장 최근 그룹",
	'custom:files' => "가장 최근 파일",
	'custom:blogs' => "가장 최근 블로그 댓글",
	'custom:members' => "가장 최근 멤버",
);
					
add_translation("ko", $korean);
