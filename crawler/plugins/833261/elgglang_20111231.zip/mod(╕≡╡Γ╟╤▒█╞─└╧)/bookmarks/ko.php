<?php
/**
 * Bookmarks English language file
 */

$korean = array(

	/**
	 * Menu items and titles
	 */
	'bookmarks' => "북마크들",
	'bookmarks:add' => "북마크를 추가",
	'bookmarks:edit' => "북마크를 편집",
	'bookmarks:owner' => "%s'의 북마크들",
	'bookmarks:friends' => "친구들의 북마크들",
	'bookmarks:everyone' => "사이트의 모든 북마크들",
	'bookmarks:this' => "이 페이지를 북마크",
	'bookmarks:this:group' => "%s 안에 북마크",
	'bookmarks:bookmarklet' => "북마크릿을 가져오기",
	'bookmarks:bookmarklet:group' => "그룹 북마크릿을 가져오기",
	'bookmarks:inbox' => "북마크 편지함",
	'bookmarks:morebookmarks' => "더 많은 북마크들",
	'bookmarks:more' => "더...",
	'bookmarks:with' => "~와 공유",
	'bookmarks:new' => "새로운 북마크",
	'bookmarks:via' => "북마크를 통해서",
	'bookmarks:address' => "북마크의 주소",
	'bookmarks:none' => '북마크 없음',

	'bookmarks:delete:confirm' => "당신은 이 자원을 삭제하는 것이 확실합니까?",

	'bookmarks:numbertodisplay' => '보여질 북마크의 수',

	'bookmarks:shared' => "북마크됨",
	'bookmarks:visit' => "리소스를 방문",
	'bookmarks:recent' => "최근 북마크들",

	'river:create:object:bookmarks' => '%s 북마크된 %s',
	'river:comment:object:bookmarks' => '북마크 %s에 코멘트된 %s',
	'bookmarks:river:annotate' => '이 북마크에 덧글',
	'bookmarks:river:item' => '항목',

	'item:object:bookmarks' => '북마크들',

	'bookmarks:group' => '그룹 북마크',
	'bookmarks:enablebookmarks' => '그룹 북마크를 활성화',
	'bookmarks:nogroup' => '이 그룹은 아직 북마크가 없습니다.',
	'bookmarks:more' => '더 많은 북마크',

	'bookmarks:no_title' => '타이틀이 없음',

	/**
	 * Widget and bookmarklet
	 */
	'bookmarks:widget:description' => "당신을 가장 최근 북마크를 보여 주기",

	'bookmarks:bookmarklet:description' =>
			"북마크들 북마크릿은 당신이 당신의 친구들과 함께 웹에서 어떤 자원들을 공유하도록 하거나 당신을 위해서 그것을 다만 북마크 한다. 그것을 사용하기 위해서, 당신의 브라우저의 링크 바에 아래 버튼을 단순히 드래그 하세요:",

	'bookmarks:bookmarklet:descriptionie' =>
			"만약 당신이 국제적인 익스플로러를 사용하고 있다면, 북마크릿 아이콘에 오른쪽 클릭을 할 필요가 있을 것입니다. '즐겨찾기에 추가'를 선택하고 나서 링크바를 선택하세요.",

	'bookmarks:bookmarklet:description:conclusion' =>
			"당신은 언제라도 그것을 클릭하므로써 당신이 방문한 어떤 페이지든 저장할 수 있습니다.",

	/**
	 * Status messages
	 */

	'bookmarks:save:success' => "당신의 아이템은 성공적을 북마크 되었습니다.",
	'bookmarks:delete:success' => "당신의 북마크는 삭제되었습니다.",

	/**
	 * Error messages
	 */

	'bookmarks:save:failed' => "당신의 북마크는 저장될 수 없습니다. 표제와 주소를 입력했는 확인하고 다시 시도하세요.",
	'bookmarks:save:invalid' => "북마크의 주소가 유효하지 않아서 저장할 수 없습니다.",
	'bookmarks:delete:failed' => "당신의 북마크는 삭제 될 수 없습니다. 다시 시도 하세요.",
);

add_translation('ko', $korean);