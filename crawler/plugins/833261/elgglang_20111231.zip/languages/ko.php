<?php
/**
 * Core language file
 *
 * @package Elgg
 * @subpackage Core
 */

$korean = array(

/**
 * Sites
 */

	'item:site' => '사이트',

/**
 * Sessions
 */

	'login' => "로그인",
	'loginok' => "로그인 성공!!",
	'loginerror' => "당신은 로그인 할 수 없다. 아직 계정이 생성되지 않았기 때문입니다, 입력한 사항이 잘 못되었거나,잘 못된 시도를 너무 많이 했기 때문입니다. 세부적인 입력사항을 다시 확인하고 재시도 해 보세요.",
    'login:empty' => "사용자명/ 이메일과 패스워드가 필요합니다.", 
    'login:baduser' => "당신의 사용자 계정을 로드할 수 없습니다.",
	'auth:nopams' => "내부 오류. 어떤 사용자 권한 메소드도 설치되지 않았습니다.",	

    'logout' => "로그 아웃",
	'logoutok' => "로그 아웃 되었습니다.",
	'logouterror' => "로그 아웃되지 않았습니다. 다시 시도해 보세요.",

	'loggedinrequired' => "이 페이지를 보기 위해서는 로그인 해야 합니다.",
	'adminrequired' => "이 페이지를 보기 위해서 관리자 관리자여야 합니다.",
	'membershiprequired' => "이 페이지를 보기 위해서는 그룹의 멤버가 되어야 합니다.",


/**
 * Errors
 */
	'exception:title' => "치명적인 오류.",

	'InstallationException:CantCreateSite' => "이름:%s, Url: %s을 사용하여 elgg 사이트를 생성할 수 없습니다.",

	'actionundefined' => "요청하신 작업 (%s)는 시스템에 정의되어 있지 않습니다. ",
    'actionnotfound' => "The action file for %s was not found.",
	'actionloggedout' => "미안합니다. 로그 아웃 상태에서는 이 작업을 수행할 수 없습니다.",
	'actionunauthorized' => '당신은 이 작업을 수행할 수 있는 권한이 없습니다.',

    'InstallationException:SiteNotInstalled' => 'Unable to handle this request. This site '
		. ' is not configured or the database is down.',
	'InstallationException:MissingLibrary' => 'Could not load %s',
	'InstallationException:CannotLoadSettings' => 'Elgg could not load the settings file. It does not exist or there is a file permissions issue.',

	'SecurityException:Codeblock' => "권한이 있는 코드 블럭을 실행할 수 있는 접근이 거부되었습니다.",
	'DatabaseException:WrongCredentials' => "Elgg는 주어진 정보를 사용하여 데이터베이스에 연결할 수 없습니다.",
	'DatabaseException:NoConnect' => "Elgg는 데이터베이스 '%s'를 선택할 수 없습니다, 데이터베이스가 만들어져 있는지, DB에 접근할 수 있는 체크해 주십시오.",
	'SecurityException:FunctionDenied' => "권한이 필요한 기능'%s' 에 대한 접근이 거부되었습니다.  ",
	'DatabaseException:DBSetupIssues' => "여러가지 문제가 있었음: ",
	'DatabaseException:ScriptNotFound' => "Elgg가 %s에서 요청된 데이터베이스를 찾을 수 없었습니다.  ",
    'DatabaseException:InvalidQuery' => "Invalid query",

	'IOException:FailedToLoadGUID' => "GUID:%d 로부터 새로운 %s를 로드하는데 실패했습니다.",
	'InvalidParameterException:NonElggObject' => "ElggObject 생성자에게 non-ElggObject로 넘겨주기!",
	'InvalidParameterException:UnrecognisedValue' => "알 수 없는 값이 생성자에게 넘겨짐.",

	'InvalidClassException:NotValidElggStar' => "GUID:%d 은(는) 값: %s가 아닙니다.",

	'PluginException:MisconfiguredPlugin' => "%s은(는) 잘 못 설정된 플러그인 입니다. 그것은 활성화 되어 있지 않습니다. 가능한 원인에 대해서 Elgg 위키를 검색해 보세요.(http://docs.elgg.org/wiki/).",
    'PluginException:CannotStart' => '%s (guid: %s) 는 시작할 수 없고 비활성화 되었습니다.   이유는: %s',
	'PluginException:InvalidID' => "%s 은(는) 유효하지 않은 플러그인 ID입니다.",
	'PluginException:InvalidPath' => "%s 은(는) 유효하지 않은 플러그인 경로 입니다.",
	'PluginException:InvalidManifest' => '플러그인 %s 에 대해서 유효하지 않은 manifest 파일입니다.',
	'PluginException:InvalidPlugin' => '%s 은(는) 유효한 플러그인이 아닙니다.',
	'PluginException:InvalidPlugin:Details' => '%s 은(는) 유효한 플리그인 : %s가 아닙니다.',
	'PluginException:NullInstantiated' => 'ElggPlugin은 인스턴스가 null일 수가 없습니다. 당신은 GUID, 플러그인 ID, 혹은 전체 경로를 넘겨 주어야 합니다.',

'ElggPlugin:MissingID' => '플러그인 ID가 빠졌습니다.(guid %s)',
	'ElggPlugin:NoPluginPackagePackage' => '플러그인 ID %S (guid %s)에 대한 ElggPluginPackage 가 빠졌습니다.',

	'ElggPluginPackage:InvalidPlugin:MissingFile' => 'Missing file %s in package',
	'ElggPluginPackage:InvalidPlugin:InvalidDependency' => 'Invalid dependency type "%s"',
	'ElggPluginPackage:InvalidPlugin:InvalidProvides' => 'Invalid provides type "%s"',
	'ElggPluginPackage:InvalidPlugin:CircularDep' => 'Invalid %s dependency "%s" in plugin %s.  Plugins cannot conflict with or require something they provide!',

	'ElggPlugin:Exception:CannotIncludeFile' => 'Cannot include %s for plugin %s (guid: %s) at %s.',
	'ElggPlugin:Exception:CannotRegisterViews' => 'Cannot open views dir for plugin %s (guid: %s) at %s.',
	'ElggPlugin:Exception:CannotRegisterLanguages' => 'Cannot register languages for plugin %s (guid: %s) at %s.',
	'ElggPlugin:Exception:NoID' => 'No ID for plugin guid %s!',

	'PluginException:ParserError' => 'Error parsing manifest with API version %s in plugin %s.',
	'PluginException:NoAvailableParser' => 'Cannot find a parser for manifest API version %s in plugin %s.',
	'PluginException:ParserErrorMissingRequiredAttribute' => "Missing required '%s' attribute in manifest for plugin %s.",

	'ElggPlugin:Dependencies:Requires' => 'Requires',
	'ElggPlugin:Dependencies:Suggests' => 'Suggests',
	'ElggPlugin:Dependencies:Conflicts' => 'Conflicts',
	'ElggPlugin:Dependencies:Conflicted' => 'Conflicted',
	'ElggPlugin:Dependencies:Provides' => 'Provides',
	'ElggPlugin:Dependencies:Priority' => 'Priority',

	'ElggPlugin:Dependencies:Elgg' => 'Elgg version',
	'ElggPlugin:Dependencies:PhpExtension' => 'PHP extension: %s',
	'ElggPlugin:Dependencies:PhpIni' => 'PHP ini setting: %s',
	'ElggPlugin:Dependencies:Plugin' => 'Plugin: %s',
	'ElggPlugin:Dependencies:Priority:After' => 'After %s',
	'ElggPlugin:Dependencies:Priority:Before' => 'Before %s',
	'ElggPlugin:Dependencies:Priority:Uninstalled' => '%s is not installed',
	'ElggPlugin:Dependencies:Suggests:Unsatisfied' => 'Missing',

	'ElggPlugin:InvalidAndDeactivated' => '%s is an invalid plugin and has been deactivated.',

	'InvalidParameterException:NonElggUser' => "ElggUser 생성자에게 a non-ElggUser를 넘겨주었음!",

	'InvalidParameterException:NonElggSite' => "ElggSite 생성자에게 a non-ElggSite를 넘겨주었음!",

	'InvalidParameterException:NonElggGroup' => "ElggGroup 생성자에게 a non-ElggGroup을 넘겨주었음!",

	'IOException:UnableToSaveNew' => "새로운 %s를 저장할 수 없습니다.",

	'InvalidParameterException:GUIDNotForExport' => "추출하는 동안 GUID가 지정되지 않았습니다. 이것은 절대로 일어나지 않아야 합니다.",
	'InvalidParameterException:NonArrayReturnValue' => "Entity 직렬화 기능은 배열화 되지 않는 반환 값 파라미터를 넘겨주었음",

	'ConfigurationException:NoCachePath' => "캐쉬 경로가 아무 것도 설정되지 않음!",
	'IOException:NotDirectory' => "%s은(는) 디렉토리가 아닙니다.",

	'IOException:BaseEntitySaveFailed' => "새로운 개체의 기초 엔티티 정보를 저장할 수 없습니다. !",
	'InvalidParameterException:UnexpectedODDClass' => "예기치 않은 ODD 클래스를 넘긴 import() ",
	'InvalidParameterException:EntityTypeNotSet' => "엔티티 타입이 설정되어야만 합니다.",

	'ClassException:ClassnameNotClass' => "%s은(는) %s이(가) 아닙니다.",
	'ClassNotFoundException:MissingClass' => "클래스 '%s'는 발견되지 않았습니다. 플러그인을 뺐습니까?",
	'InstallationException:TypeNotSupported' => "타입 %s은(는) 지원되지 않습니다. 이것은 설치 정보에서의 오류를 가리킵니다. 대개 완료도지 않은 업그레이드에 의해서 발생하는 것 같습니다.",

	'ImportException:ImportFailed' => "엘리먼트 %d를(을) 가져올 수 없습니다.",
	'ImportException:ProblemSaving' => "%s를(을) 저장하는데 문제가 있었습니다.",
	'ImportException:NoGUID' => "새로운 엔티티가 생성되었지만, GUID를 가지고 있지 않습니다. 이런 일은 발생하면 안됩니다.",

	'ImportException:GUIDNotFound' => "엔티티 '%d'을(를) 찾을 수 없습니다.",
	'ImportException:ProblemUpdatingMeta' => "엔티티 '%d'에 '%s'를(을) 업데이트 하는데 문제가 있었습니다.",

	'ExportException:NoSuchEntity' => "그런 엔티티 GUID:%d는 없습니다.",

	'ImportException:NoODDElements' => "가져올 데이터에서 어떤 OpenDD 엘리먼트를 찾을 수 없었습니다. 가져오는데 실패했습니다.",
	'ImportException:NotAllImported' => "모든 엘리먼트들을 가져오지는 못 했습니다.",

	'InvalidParameterException:UnrecognisedFileMode' => "알 수 없는 파일 모드 '%s'",
	'InvalidParameterException:MissingOwner' => "파일 %s (파일 guid:%d) (owner guid:%d)가 owner를 잃어버렸습니다!",
	'IOException:CouldNotMake' => "%s를 만들 수 없었습니다.",
	'IOException:MissingFileName' => "파일을 열기 전에 이름을 정해야 합니다.",
	'ClassNotFoundException:NotFoundNotSavedWithFile' => " 파일 %u에 대한 filestore class %s를 로드할 수 없습니다.",
	'NotificationException:NoNotificationMethod' => "어떤 공지 방법도 지정하지 않았습니다.",
	'NotificationException:NoHandlerFound' => "'%s'에 대한 어떤 핸들러를 찾을 수 없거나 그것이 호출되지 않았습니다.",
	'NotificationException:ErrorNotifyingGuid' => "%d를 공지하는 동안 오류가 있었습니다.",
	'NotificationException:NoEmailAddress' => "GUID:%d에 대한 이메일 주소를 가져올 수 없었습니다. ",
	'NotificationException:MissingParameter' => "요청된 파라미터, '%s'를 잃어버렸습니다.",

	'DatabaseException:WhereSetNonQuery' => "설정은 어디에 non WhereQueryComponent 포함하고 있는가",
	'DatabaseException:SelectFieldsMissing' => "선택한 스타일 쿼리에 필드가 빠져 있음",
	'DatabaseException:UnspecifiedQueryType' => "인식하지 못하거나 지정되지 않은 쿼리 타입.",
	'DatabaseException:NoTablesSpecified' => "쿼리에 대해서 어떤 테이블도 지정되지 않았음.",
	'DatabaseException:NoACL' => "어떤 접근 제어도 쿼리에 제공되지 않았음",

	'InvalidParameterException:NoEntityFound' => "어떤 엔티티도 찾지 못했습니다. 그것이 존재하지 않거나 그것에 접근 권한이 없습니다. ",

	'InvalidParameterException:GUIDNotFound' => "GUID:%s는 찾을 수 없거나, 그것에 접근할 수 없습니다.",
	'InvalidParameterException:IdNotExistForGUID' => "미안합니다, '%s'는 guid:%d에 대해서 존재하지 않습니다.",
	'InvalidParameterException:CanNotExportType' => "미안합니다, '%s'를 출력하는 방법을 알 수 없습니다.",
	'InvalidParameterException:NoDataFound' => "어떤 데이터를 찾을 수 없었습니다.",
	'InvalidParameterException:DoesNotBelong' => "엔티티에 속해 있지 않습니다.",
	'InvalidParameterException:DoesNotBelongOrRefer' => "엔티티에 속해 있지 않거나 엔티티를 참조 하고 있지 않습니다.",
	'InvalidParameterException:MissingParameter' => "파라미터가 빠졌습니다, GUID를 제공해 줄 필요가 있습니다.",
    'InvalidParameterException:LibraryNotRegistered' => '%s is not a registered library',
	'InvalidParameterException:LibraryNotFound' => 'Could not load the %s library from %s',

    'APIException:ApiResultUnknown' => "API 결과가 알려지지 않은 타입입니다. 이런 일은 발생해서는 안됩니다.",
	'ConfigurationException:NoSiteID' => "어떤 사이트 ID도 지정되지 않았습니다.",
	'SecurityException:APIAccessDenied' => "미안합니다, API 접근은 관리자에 의해서 비활성화 되었습니다.",
	'SecurityException:NoAuthMethods' => "이런 API 요청에 권한을 줄 수 있는 어떤 권한 함수도 찾을 수가 없습니다.",
	'SecurityException:UnexpectedOutputInGatekeeper' => 'gatekeeper에 예기치 않은 출력이 호출. 보안때문에 실행을 중지. 좀 더 정보를 얻기 위해서 http://docs.elgg.org/를 검색하세요.',
	'InvalidParameterException:APIMethodOrFunctionNotSet' => "메소드 혹은 함수가 expose_method()에 설정되지 않았습니다.",
	'InvalidParameterException:APIParametersArrayStructure' => "파라미터들의 배열 구조가 메소드'%s'를 나타내기 위한 호출에 대해서 올바르지 않습니다.",
	'InvalidParameterException:UnrecognisedHttpMethod' => "api 메소드'%s'에 대한 인식되지 않은 http 메소드 %s",
	'APIException:MissingParameterInMethod' => "메소드 %s에 파라미터 %s가 없습니다.",
	'APIException:ParameterNotArray' => "%s는 배열에 나타나 있지 않습니다.",
	'APIException:UnrecognisedTypeCast' => "메소드 '%s'에 변수'%s'에 대한 캐스트'%s'에 인식되지 않은 형식",
	'APIException:InvalidParameter' => "잘못된 파라미터가 메소드 '%s'에서 '%s'을 찾았습니다.",
	'APIException:FunctionParseError' => "%s(%s)는 파싱 에러가 있습니다.",
	'APIException:FunctionNoReturn' => "%s(%s)는 어떤 값도 리턴하지 않았습니다.",
	'APIException:APIAuthenticationFailed' => "메소드 호출이 API 인증을 실패했습니다. ",
	'APIException:UserAuthenticationFailed' => "메소드 호출이 사용자 인증을 실패했습니다.",
	'SecurityException:AuthTokenExpired' => "누락, 잘못되었거나 만료된 인증 토큰",
	'CallException:InvalidCallMethod' => "%s는 '%s'를 사용해서 호출되어야 합니다.",
	'APIException:MethodCallNotImplemented' => "메소드 호출 '%s'가 Method call '%s' 구현되지 않았습니다.",
	'APIException:FunctionDoesNotExist' => "메소드 '%s'에 대한 함수는 호출 할 수 없습니다.",
	'APIException:AlgorithmNotSupported' => "알고리즘 '%s'는 지원되지 않거나 활성화 되지 않았습니다.",
	'ConfigurationException:CacheDirNotSet' => "캐쉬 디렉토리 'cathe_path'가 설정하지 않았습니다. ",
	'APIException:NotGetOrPost' => "요청 메소드는 GET 혹은 POST가 되어야만 합니다.",
	'APIException:MissingAPIKey' => "API키가 없습니다.",
	'APIException:BadAPIKey' => "잘못된 API 키",
	'APIException:MissingHmac' => "X-Elgg-hmac 헤더가 없습니다.",
	'APIException:MissingHmacAlgo' => "X-Elgg-hmac-algo 헤더가 없습니다.",
	'APIException:MissingTime' => "X-Elgg-time 헤더가 없습니다.",
	'APIException:MissingNonce' => "X-Elgg-nonce 헤더가 없습니다.",
	'APIException:TemporalDrift' => "X-Elgg-time이 너무 과거이거나 미래입니다. Epoch(시간대) 실패.",
	'APIException:NoQueryString' => "쿼리 스트링에 어떤 데이터도 없습니다.",
	'APIException:MissingPOSTHash' => "X-Elgg-posthash 헤더가 없습니다.",
	'APIException:MissingPOSTAlgo' => "X-Elgg-posthash_algo 헤더가 없습니다.",
	'APIException:MissingContentType' => "포스트 한 데이터의 내용 형식이 없습니다.",
	'SecurityException:InvalidPostHash' => "POST 데이터 해쉬가 의미가 없습니다.- %s를 기대했지만, %s를 갖게 되었습니다.",
	'SecurityException:DupePacket' => "이미 보여진 패킷 서명.",
	'SecurityException:InvalidAPIKey' => "API 키가 의미가 없거나 없습니다.",
	'NotImplementedException:CallMethodNotImplemented' => "호츨 메소드 '%s'는 현재 지원되지 않습니다.",

	'NotImplementedException:XMLRPCMethodNotImplemented' => "XML-RPC 메소드 호출 '%s' 는 구현되지 않았습니다.",
	'InvalidParameterException:UnexpectedReturnFormat' => "메소드 '%s'에 대한 호출은 예상치 않은 결과를 받았습니다.",
	'CallException:NotRPCCall' => "호출이 유효한 XML-RPC 호출로 나타나지 않았습니다.",

	'PluginException:NoPluginName' => "플러그인 이름을 찾을 수 없습니다.",

	'ConfigurationException:BadDatabaseVersion' => "당신이 설치한 데이터베이스 백엔드는 Elgg를 실행하는데 필요한 기본적인 요구사항을 충족하지 못했습니다. 문서를 참고 하세요.",
	'ConfigurationException:BadPHPVersion' => "Elgg를 실행하기 위해서 최소한 PHP 5.2 버전이 필요합니다.",
	'configurationwarning:phpversion' => "Elgg는 최소한 PHP 5.2 버전을 요구합니다. 5.1.6 버전에 설치할 수는 있지만, 어떤 기능은 동작하지 않을 수 있습니다. requires at least PHP version 5.2,모든 위험에 대한 책임은 당신에게 있습니다.",


	'InstallationException:DatarootNotWritable' => "당신의 데이터 디렉토리 %s 는 쓰기 권한이 없습니다.",
	'InstallationException:DatarootUnderPath' => "당신의 데이터 디렉토리 %s 는 설치 경로의 밖에 있어야만 합니다.",
	'InstallationException:DatarootBlank' => "당신은 데이터 디렉토리를 지정하지 않았습니다.",

	'SecurityException:authenticationfailed' => "사용자는 인증 받을 수 없었습니다.",

	'CronException:unknownperiod' => '%s 는 인식된 기간이 아닙니다.',

	'SecurityException:deletedisablecurrentsite' => '당신은 현재 보고 있는 사이트를 제거하나 비활성화 할 수 없습니다!',

	'RegistrationException:EmptyPassword' => '패스워드 필드는 반드시 채워져야 합니다.',
	'RegistrationException:PasswordMismatch' => '패스워드가 일치해야만 합니다.',
    'LoginException:BannedUser' => 'You have been banned from this site and cannot log in',
	'LoginException:UsernameFailure' => 'We could not log you in. Please check your username/email and password.',
	'LoginException:PasswordFailure' => 'We could not log you in. Please check your username/email and password.',
	'LoginException:AccountLocked' => 'Your account has been locked for too many log in failures.',
	'LoginException:ChangePasswordFailure' => 'Failed current password check.',
	
    'memcache:notinstalled' => 'PHP memcache 모듈이 설치되지 않았습니다. php5-memcache 모듈을 설치해야 합니다.',
	'memcache:noservers' => 'memcache 서버도 정의되지 않았습니다. $CONFIG->memcache_servers 변수를 채워주십시오.',
	'memcache:versiontoolow' => 'Memcache가 실행되려면 적어도 %s 가 필요합니다. 당신은 %s 를 실행하고 있습니다.',
	'memcache:noaddserver' => 'Multiple server 지원이 비활성화 되어있습니다. PECL memcache library를 업데이트 할 필요가 있습니다.',
	'deprecatedfunction' => '경고: 이 코드는 앞으로 사용중지될 함수 \'%s\'을(를) 사용합니다. 이 코드는 Elgg의 이 버전과는 호환되지 않습니다.',

	'pageownerunavailable' => '경고: 페이지 소유자 %d 는 접근하지 못합니다!',
    'viewfailure' => 'There was an internal failure in the view %s',
	'changebookmark' => '이 페이지에 대해서 북마크를 변경해 주십시오.',
    'noaccess' => 'This content has been removed, is invalid, or you do not have permission to view it.',

	'error:default' => 'Oops...something went wrong.',
	'error:404' => 'Sorry. We could not find the page that you requested.',



/**
 * API
 */
	'system.api.list' => "시스템에서 모든 사용가능한 API 호출 목록.",
	'auth.gettoken' => "이 API 호출은 장래에 API 호출을 인증하기 위해 사용될 사용자 인증 토큰을 사용자가 얻을 수 있도록 합니다. 파라미터 auth_token으로 그것을 넘겨 주십시오.",

/**
 * User details
 */

	'name' => "보여지는 이름",
	'email' => "이메일 주소",
	'username' => "사용자명",
    'loginusername' => "Username or email",
	'password' => "암호",
	'passwordagain' => "암호 재확인",
	'admin_option' => "이 사용자를 관리자로 할까요?",

/**
 * Access
 */

	'PRIVATE' => "개인적인",
	'LOGGED_IN' => "로그인 된 사용자",
	'PUBLIC' => "공개적인",
	'access:friends:label' => "친구들",
	'access' => "접근",

/**
 * Dashboard and widgets
 */

	'dashboard' => "대쉬보드",
	'dashboard:configure' => "페이지 편집",
	'dashboard:nowidgets' => "대쉬보드는 이 사이트로 들어가는 관문입니다. 이 시스템 내에서 활동하고 내용들을 추적하는 위젯을 추가하기 위해 '페이지 편집'을 클릭하세요.",

	'widgets:add' => '당신의 페이지에 위젯을 추가',
	'widgets:add:description' => "아래쪽 세개의 위젯 영역중 어떤 곳에라도 위젯이 나타나으면 하는 위치로, 오른쪽에 있는 <b>위젯 갤러리</b>로 부터 위젯을 드래그 해서 여러분의 페이지에 추가하고 싶은 기능을 선택하세요.
 	위젯을 없애기 위해서는 <b>위젯 갤러리</b>로 그것을 다시 드래그 하세요. ",
	'widgets:position:fixed' => '(페이지에 고정된 위치)',
    'widget:unavailable' => 'You have already added this widget',
	'widget:numbertodisplay' => 'Number of items to display',

	'widget:delete' => 'Remove %s',
	'widget:edit' => 'Customize this widget',

	'widgets' => "위젯들(Widgets)",
	'widget' => "위젯(Widget)",
	'item:object:widget' => "위젯들(Widgets)",
    'widgets:save:success' => "The widget was successfully saved.",
	'widgets:save:failure' => "We could not save your widget. Please try again.",
	'widgets:add:success' => "The widget was successfully added.",
	'widgets:add:failure' => "We could not add your widget.",
	'widgets:move:failure' => "We could not store the new widget position.",
	'widgets:remove:failure' => "Unable to remove this widget",	

 /**   'layout:customise' => "사용자 레이아웃(Customise layout)",
	'widgets:gallery' => "위젯 갤러리(Widget gallery)",
	'widgets:leftcolumn' => "왼쪽 위젯들(Left widgets)",
	'widgets:fixed' => "고정된 위치(Fixed position)",
	'widgets:middlecolumn' => "중앙 위젯들(Middle widgets)",
	'widgets:rightcolumn' => "오른쪽 위젯들(Right widgets)",
	'widgets:profilebox' => "프로파일 박스(Profile box)",
	'widgets:panel:save:success' => "당신의 위젯들이 성공적으로 저장 되었습니다.",
	'widgets:panel:save:failure' => "위젯을 저장하는데 문제가 있었습니다. 로그인을 확인하고 다시 시도해 보세요.",
	'widgets:save:success' => "위젯이 성공적으로 저장되었습니다.",
	'widgets:save:failure' => "당신의 위젯을 저장할 수 없습니다. 로그인을 확인하고 다시 시도해 보세요.",
	'widgets:handlernotfound' => '이 위젯은 깨졌거나 사이트관리자에 의해서 비활성화 되어 있습니다. ',
*/

/**
 * Groups
 */

	'group' => "그룹",
	'item:group' => "그룹들",

/**
 * Users
 */

	'user' => "사용자",
	'item:user' => "사용자들",

/**
 * Friends
 */

	'friends' => "친구들",
	'friends:yours' => "당신의 친구들",
	'friends:owned' => "%s의 친구들",
	'friend:add' => "친구로 추가",
	'friend:remove' => "친구에서 제외",

	'friends:add:successful' => "당신은 성공적으로 친구로 %s를 추가했습니다.",
	'friends:add:failure' => "친구로 %s을(를) 추가할 수 없습니다. 다시 시도해 보세요.",

	'friends:remove:successful' => "당신의 친구들로 부터 %s을(를) 성공적으로 제외했습니다.",
	'friends:remove:failure' => "당신의 친구들로 부터 %s을(를) 제외할 수 없습니다. 다시 시도해 보세요.",

	'friends:none' => "이 사용자는 아직 친구로서 아무도 추가하지 않았습니다. ",
	'friends:none:you' => "당신은 친구를 아무도 추가하지 않았습니다. 팔로우할 사람을 찾기 시작하기 위해서 당신의 관심사를 검색해 보세요.",

	'friends:none:found' => "친구를 아무도 발견하지 못했습니다.",

	'friends:of:none' => "어떤 사람도 이 사용자를 친구로 아직 추가하지 않았습니다.",
	'friends:of:none:you' => "어떤 사람도 아직 친구로 당신을 추가하지 않았습니다. 사람들이 당신을 찾을 수 있도록 프로필과 내용 추가를 시작하세요!",

	'friends:of:owned' => "%s이(가) 친구로 했던 사람들",

	'friends:of' => "의 친구들",
	'friends:collections' => "친구들의 모임들",
	'friends:collections:add' => "새로운 친구들 모임",
	'friends:collections:add' => "New friends collection",
    'friends:addfriends' => "친구들을 추가",
	'friends:collectionname' => "모임 이름",
	'friends:collectionfriends' => "모임에 친구들",
	'friends:collectionedit' => "이 모임을 편집",
	'friends:nocollections' => "당신은 아직 어떤 모임들에 참여하고 있지 않습니다.",
	'friends:collectiondeleted' => "당신의 모임이 삭제되었습니다.",
	'friends:collectiondeletefailed' => "모임을 삭제할 수 없습니다. 권한이 없거나 다른 어떤 문제가 발생했습니다.",
	'friends:collectionadded' => "당신의 모임이 성공적으로 생성되었습니다.",
    'friends:nocollectionname' => "모임이 생성되기 전에 모임에 이름을 만들 필요가 있습니다.",
	'friends:collections:members' => "모임 멤버들",
	'friends:collections:edit' => "모임을 편집",
	'friends:collections:edited' => "저장된 모임",
	'friends:collection:edit_failed' => '모임을 저장할 수 없었습니다.',

    'friendspicker:chararray' => 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
	'friends:river:add' => "%s는 지금 ~와 친구입니다.",
    'avatar' => '아바타',
	'avatar:create' => '아바타 생성',
	'avatar:edit' => '아바타 편집',
	'avatar:preview' => '미리보기',
	'avatar:upload' => '새로운 아바타를 업로드',
	'avatar:current' => '현재의 아바타',
	'avatar:crop:title' => '아바타 잘라내기 도구',
	'avatar:upload:instructions' => "당신의 아바타는 사이트에서 보여집니다. 당신이 원할 때마다 그것을 변경할 수 있습니다. (파일 포맷은 GIF, JPG 혹은 PNG 입니다.)",
	'avatar:create:instructions' => 'Click and drag a square below to match how you want your avatar cropped. A preview will appear in the box on the right. When you are happy with the preview, click \'Create your avatar\'. This cropped version will be used throughout the site as your avatar.',
	'avatar:upload:success' => 'Avatar successfully uploaded',
	'avatar:upload:fail' => 'Avatar upload failed',
	'avatar:resize:fail' => 'Resize of the avatar failed',
	'avatar:crop:success' => 'Cropping the avatar succeeded',
	'avatar:crop:fail' => 'Avatar cropping failed',

	'profile:edit' => 'Edit profile',
	'profile:aboutme' => "About me",
	'profile:description' => "About me",
	'profile:briefdescription' => "Brief description",
	'profile:location' => "Location",
	'profile:skills' => "Skills",
	'profile:interests' => "Interests",
	'profile:contactemail' => "Contact email",
	'profile:phone' => "Telephone",
	'profile:mobile' => "Mobile phone",
	'profile:website' => "Website",
	'profile:twitter' => "Twitter username",
	'profile:saved' => "Your profile was successfully saved.",

	'profile:field:text' => 'Short text',
	'profile:field:longtext' => 'Large text area',
	'profile:field:tags' => 'Tags',
	'profile:field:url' => 'Web address',
	'profile:field:email' => 'Email address',
	'profile:field:location' => 'Location',
	'profile:field:date' => 'Date',

	'admin:appearance:profile_fields' => 'Edit Profile Fields',
	'profile:edit:default' => 'Edit profile fields',
	'profile:label' => "Profile label",
	'profile:type' => "Profile type",
	'profile:editdefault:delete:fail' => 'Removed default profile item field failed',
	'profile:editdefault:delete:success' => 'Profile field deleted',
	'profile:defaultprofile:reset' => 'Profile fields reset to the system default',
	'profile:resetdefault' => 'Reset default profile',
	'profile:explainchangefields' => "You can replace the existing profile fields with your own using the form below. \n\n Give the new profile field a label, for example, 'Favorite team', then select the field type (eg. text, url, tags), and click the 'Add' button. To re-order the fields drag on the handle next to the field label. To edit a field label - click on the label's text to make it editable. \n\n At any time you can revert back to the default profile set up, but you will lose any information already entered into custom fields on profile pages.",
	'profile:editdefault:success' => 'New profile field added',
	'profile:editdefault:fail' => 'Default profile could not be saved',


/**
 * Feeds
 */
	'feed:rss' => '피드에 Subscribe',
	'feed:odd' => '연결한(Syndicate) OpenDD',

/**
 * links
 **/

	'link:view' => '링크 보기',
    'link:view:all' => 'View all',


/**
 * River
 */
	'river' => "River",
    'river:friend:user:default' => "%s is now a friend with %s",
	'river:update:user:avatar' => '%s has a new avatar',
	'river:update:user:profile' => '%s has updated their profile',
	'river:noaccess' => 'You do not have permission to view this item.',
	'river:posted:generic' => '%s posted',
	'riveritem:single:user' => 'a user',
	'riveritem:plural:user' => 'some users',
	'river:ingroup' => 'in the group %s',
	'river:none' => 'No activity',
	'river:update' => 'Update for %s',

	'river:widget:title' => "Activity",
	'river:widget:description' => "Display latest activity",
	'river:widget:type' => "Type of activity",
	'river:widgets:friends' => 'Friends activity',
	'river:widgets:all' => 'All site activity',

	'river:relationship:friend' => '는 와 함께 현재 친구이다',
	'river:noaccess' => '당신은 이 아이템을 볼 수 있는 권한을 가지고 있지 않습니다.',
	'river:posted:generic' => '%s는 포스트됨',
	'riveritem:single:user' => '한 사용자',
	'riveritem:plural:user' => '어떤 사용자들',













/**
 * Notifications
 */
	'notifications:usersettings' => "공지 설정",
	'notifications:methods' => "허용하고자 하는 방법을 지정해 주십시오.",
    'notification:method:email' => 'Email',

	'notifications:usersettings:save:ok' => "공지 설정이 성공적으로 저정되었습니다.",
	'notifications:usersettings:save:fail' => "공지 설정을 저장하는데 문제가 있었습니다.",

	'user.notification.get' => '지정된 사용자에 대한 공지설정을 반환합니다.',
	'user.notification.set' => '지정된 사용자에 대한 공지설정을 설정합니다.',
/**
 * Search
 */

	'search' => "검색",
	'searchtitle' => "검색:%s",
	'users:searchtitle' => "사용자들:%s에 대한 검색중",
	'groups:searchtitle' => "그룹:%s에 대한 검색 중",
	'advancedsearchtitle' => "%s를 일치하는 결과를 가진 %s",
	'notfound' => "어떤 결과도 찾을 수 없습니다.",
	'next' => "다음으로",
	'previous' => "이전으로",

	'viewtype:change' => "리스트 형식을 변경",
	'viewtype:list' => "리스트 뷰",
	'viewtype:gallery' => "갤러리",

	'tag:search:startblurb' => "'%s'를 일치하는 태그를 가진 아이템:",

	'user:search:startblurb' => "'%s'를 일치하는 사용자들:",
	'user:search:finishblurb' => "더 보기하려면, 여기를 클릭.",

	'group:search:startblurb' => "'%s'를 일치하는 그룹:",
	'group:search:finishblurb' => "더 보기하려면, 여기를 클릭.",
	'search:go' => '가기',
	'userpicker:only_friends' => '친구들만',

/**
 * Account
 */

	'account' => "계정",
	'settings' => "설정",
	'tools' => "도구들",
	'tools:yours' => "당신의 도구들",

	'register' => "등록",
	'registerok' => "%s에 대해서 성공적으로 등록되었습니다.",
	'registerbad' => "등록에 성공했습니다. 사용자 이름이 이미 존재합니다. 패스워드가 일치하지 않습니다. 혹은 사용자 이름이나 패스워드가 너무 짧습니다.",
	'registerdisabled' => "등록이 시스템 관리자에 의해서 비활성화 되었습니다.",
    'register:fields' => 'All fields are required',
	'firstadminlogininstructions' => '새로운 Elgg 사이트가 성공적으로 설치되었습니다. 그리고 관리자 계정이 생성되었습니다. 지금 설치되어 있는 다양한 플러그인 도구들을 활성화 함으로써 좀 더 사이트를 조정할 수 있습니다.',

	'registration:notemail' => '당신이 제공한 이메일 주소가 유효한 이메일 주소에 나타나지 않습니다.',
	'registration:userexists' => '사용자 이름이 이미 존재합니다.',
	'registration:usernametooshort' => '사용자 이름은 최소 4(영어로 4자, 한글로 2자)자이어자 합니다.',
	'registration:passwordtooshort' => '패스워드는 최소 6자 이어야 합니다.',
	'registration:dupeemail' => '이 이메일 주소는 이미 등록되어 있습니다.',
	'registration:invalidchars' => '미안합니다. 당신의 사용자 이름은 옆에 있는 것과 같이 의미없는 문자를 포함하고 있습니다.:%S',
	'registration:emailnotvalid' => '미안합니다. 입력한 이메일 주소가 없습니다.',
	'registration:passwordnotvalid' => '미안합니다. 입력한 패스워드가 없습니다.',
	'registration:usernamenotvalid' => '미안합니다. 입력한 사용자 이름은 없습니다.',

	'adduser' => "사용자 추가",
	'adduser:ok' => "새로운 사용자를 추가하는데 성공했습니다.",
	'adduser:bad' => "새로운 사용자를 만들 수 없습니다.",

	'item:object:reported_content' => "기록된 항목들",

	'user:set:name' => "계정 이름 설정",
	'user:name:label' => "당신의 이름",
	'user:name:success' => "당신의 이름이 성공적으로 바뀌었습니다.",
	'user:name:fail' => "당신의 이름을 바꿀 수 없습니다. 이름이 너무 길지 않은지 확인하고 다시 시도해 보세요.",

	'user:set:password' => "계정 패스워드",
	'user:current_password:label' => '현재의 패스워드',
	'user:password:label' => "새로운 패스워드",
	'user:password2:label' => "새로운 패스워드 재확인",
	'user:password:success' => "패스워드 변경됨",
	'user:password:fail' => "패스워드를 변경할 수 없습니다.",
	'user:password:fail:notsame' => "패스워드가 일치하지 않습니다!",
	'user:password:fail:tooshort' => "패스워드가 너무 짧습니다!",
	'user:password:fail:incorrect_current_password' => '입력한 패스워드가 틀립니다.',
	'user:resetpassword:unknown_user' => '의미없는 사용자.',
	'user:resetpassword:reset_password_confirm' => '패스워드를 재설정하기 위해서 당신의 이메일 주소로 새로운 패스워드를 보낼 것입니다.',

	'user:set:language' => "언어 설정",
	'user:language:label' => "당신의 언어",
	'user:language:success' => "언어 설정이 업데이트 되었습니다.",
	'user:language:fail' => "언어 설정을 저장할 수 없었습니다. ",

	'user:username:notfound' => '사용자 이름 %s는 찾을 수 없습니다.',

	'user:password:lost' => '패스워드가 기억안남',
	'user:password:resetreq:success' => '새로운 패스워드를 성공적으로 요청하고, 이메일이 보내졌습니다.',
	'user:password:resetreq:fail' => '새로운 패스워드를 요청할 수 없었습니다.',

	'user:password:text' => '새로운 패스워드를 생성하기 위해서, 아래 당신의 이름을 입력하세요. 이메일로 당신에 확인을 위한 페이지가 보내질 것입니다. 메시지의 링크를 클릭하세요. 새로운 패스워드가 당신에 보내질 것입니다.',

	'user:persistent' => '내 정보를 저장(Remember me)',

    'walled_garden:welcome' => 'Welcome to',


/**
 * Administration
 */
    'menu:page:header:administer' => 'Administer',
	'menu:page:header:configure' => 'Configure',
	'menu:page:header:develop' => 'Develop',
	'menu:page:header:default' => 'Other',

    'admin:view_site' => 'View site',
	'admin:loggedin' => 'Logged in as %s',
	'admin:menu' => 'Menu',

	'admin:configuration:success' => "당신의 설정이 저장되었습니다.",
	'admin:configuration:fail' => "당신의 설정이 저장됮 않았습니다.",

    'admin:unknown_section' => 'Invalid Admin Section.',

	'admin' => "관리자",
	'admin:description' => "관리 패널은 당신이 시스템의 모든 면, 사용자 관리에서 부터 플러그인들이 동작하는 방법까지,을 제어하도록 허가합니다. 아래 옵션을 선택해서 시작하십시오.",

    'admin:statistics' => "Statistics",
	'admin:statistics:overview' => 'Overview',

	'admin:appearance' => 'Appearance',
	'admin:administer_utilities' => 'Utilities',
	'admin:develop_utilities' => 'Utilities',

	'admin:user' => "사용자 관리자",
    'admin:users:online' => 'Currently Online',
	'admin:users:newest' => 'Newest',
	'admin:users:add' => 'Add New User',
	'admin:users:description' => "This admin panel allows you to control user settings for your site. Choose an option below to get started.",
	'admin:users:adduser:label' => "Click here to add a new user...",
	'admin:users:opt:linktext' => "Configure users...",
	'admin:users:opt:description' => "Configure users and account information. ",
	'admin:users:find' => 'Find',	

    'admin:settings' => 'Settings',
	'admin:settings:basic' => 'Basic Settings',
	'admin:settings:advanced' => 'Advanced Settings',

    'admin:user:description' => "이 관리 패널은 당신의 사이트에 사용자 설정을 제어하도록 합니다. 아래 옵션을 선택해서 시작하십시오.",
	'admin:user:adduser:label' => "새로운 사용자...를 추가하기 위해서 여기를 클릭하세요.",
	'admin:user:opt:linktext' => "사용자를 구성...",
	'admin:user:opt:description' => "사용자 및 계정 정보를 구성합니다.",

	'admin:site' => "사이트 관리",
	




    'admin:site:description' => "이 관리 패널은 여러분의 사이트에 대한 전역설정을 제어할 수 있도록 해 줍니다. 시작하려면 아래 옵션을 선택하세요.",
	'admin:site:opt:linktext' => "사이트를 구성...",
	'admin:site:opt:description' => "기술적, 비 기술적인 설정들을 사이트에 구성",
	'admin:site:access:warning' => "접근 설정을 변경하는 것은 나중에 만들어지는 컨텐트에 대한 권한에만 영향을 미치게 됩니다.",

    'admin:dashboard' => 'Dashboard',
	'admin:widget:online_users' => 'Online users',
	'admin:widget:online_users:help' => 'Lists the users currently on the site',
	'admin:widget:new_users' => 'New users',
	'admin:widget:new_users:help' => 'Lists the newest users',
	'admin:widget:content_stats' => 'Content statistics',
	'admin:widget:content_stats:help' => 'Keep track of the content created by your users',
	'widget:content_stats:type' => 'Content type',
	'widget:content_stats:number' => 'Number',

	'admin:widget:admin_welcome' => 'Welcome',
	'admin:widget:admin_welcome:help' => "A short introduction to Elgg's admin area",
	'admin:widget:admin_welcome:intro' =>
    'Welcome to Elgg! Right now you are looking at the administration dashboard. It\'s useful for tracking what\'s happening on the site.',

	'admin:widget:admin_welcome:admin_overview' =>
    "Navigation for the administration area is provided by the menu to the right. It is organized into"
.   " three sections:
	<dl>
		<dt>Administer</dt><dd>Everyday tasks like monitoring reported content, checking who is online, and viewing statistics.</dd>
		<dt>Configure</dt><dd>Occasional tasks like setting the site name or activating a plugin.</dd>
		<dt>Develop</dt><dd>For developers who are building plugins or designing themes. (Requires a developer plugin.)</dd>
	</dl>
	",

	// argh, this is ugly
	'admin:widget:admin_welcome:outro' => '<br />Be sure to check out the resources available through the footer links and thank you for using Elgg!',

	'admin:widget:control_panel' => 'Control panel',
	'admin:widget:control_panel:help' => "Provides easy access to common controls",

	'admin:cache:flush' => 'Flush the caches',
	'admin:cache:flushed' => "The site's caches have been flushed",

	'admin:footer:faq' => 'Administration FAQ',
	'admin:footer:manual' => 'Administration Manual',
	'admin:footer:community_forums' => 'Elgg Community Forums',
	'admin:footer:blog' => 'Elgg Blog',

    'admin:plugins:category:all' => 'All plugins',
	'admin:plugins:category:active' => 'Active plugins',
	'admin:plugins:category:inactive' => 'Inactive plugins',
	'admin:plugins:category:admin' => 'Admin',
	'admin:plugins:category:bundled' => 'Bundled',
	'admin:plugins:category:nonbundled' => 'Non-bundled',
	'admin:plugins:category:content' => 'Content',
	'admin:plugins:category:development' => 'Development',
	'admin:plugins:category:enhancement' => 'Enhancements',
	'admin:plugins:category:api' => 'Service/API',
	'admin:plugins:category:communication' => 'Communication',
	'admin:plugins:category:security' => 'Security and Spam',
	'admin:plugins:category:social' => 'Social',
	'admin:plugins:category:multimedia' => 'Multimedia',
	'admin:plugins:category:theme' => 'Themes',
	'admin:plugins:category:widget' => 'Widgets',
	'admin:plugins:category:utility' => 'Utilities',

	'admin:plugins:sort:priority' => 'Priority',
	'admin:plugins:sort:alpha' => 'Alphabetical',
	'admin:plugins:sort:date' => 'Newest',

	'admin:plugins:markdown:unknown_plugin' => 'Unknown plugin.',
	'admin:plugins:markdown:unknown_file' => 'Unknown file.',


	'admin:notices:could_not_delete' => 'Could not delete notice.',

    'admin:options' => 'Admin options',


/**
 * Plugins
 */
	'plugins:settings:save:ok' => "%s 플러그인에 대한 설정들이 성공적으로 저장되었습니다.",
	'plugins:settings:save:fail' => "%s 플러그인에 대한 설정을 저장하는데 문제가 있었습니다.",
	'plugins:usersettings:save:ok' => "%s 플러그인에 대한 사용자 설정들이 성공적으로 저장되었습니다.",
	'plugins:usersettings:save:fail' => "%s 플러그인에 대한 사용자 설정을 저장하는데 문제가 있었습니다.",
	'admin:plugins:label:version' => "버전",
	'item:object:plugin' => '플러그인 구성 설정',

 	'admin:plugins' => "도구 관리",
    'admin:plugins:activate_all' => 'Activate All',
	'admin:plugins:deactivate_all' => 'Deactivate All',
	'admin:plugins:activate' => 'Activate',
	'admin:plugins:deactivate' => 'Deactivate',
	'admin:plugins:description' => "이 관리 패널은 여러분의 사이트에 설치되어 있는 도구들은 제어하고 구성하도록 해 줍니다.",
	'admin:plugins:opt:linktext' => "도구들을 구성...",
    'admin:plugins:opt:description' => "사이트에 설치되어 있는 도구들을 구성. ",
	    'admin:plugins:label:author' => "저자",
	'admin:plugins:label:copyright' => "저작권",
    'admin:plugins:label:categories' => 'Categories',
	'admin:plugins:label:licence' => "라이센스",
	'admin:plugins:label:website' => "URL",
	'admin:plugins:label:moreinfo' => '더 많은 정보 보기',
	'admin:plugins:label:version' => '버전',
    'admin:plugins:label:location' => 'Location',
	'admin:plugins:label:dependencies' => 'Dependencies',
	
    'admin:plugins:warning:elgg_version_unknown' => '경고: 이 플러그인은 호환되는 Elgg 버전을 지정하지 않았습니다.',
'admin:plugins:warning:unmet_dependencies' => 'This plugin has unmet dependencies and cannot be activated. Check dependencies under more info.',
	'admin:plugins:warning:invalid' => '%s is not a valid Elgg plugin.  Check <a href="http://docs.elgg.org/Invalid_Plugin">the Elgg documentation</a> for troubleshooting tips.',
	'admin:plugins:cannot_activate' => 'cannot activate',

	'admin:plugins:set_priority:yes' => "Reordered %s.",
	'admin:plugins:set_priority:no' => "Could not reorder %s.",
	'admin:plugins:set_priority:no_with_msg' => "Could not reorder %s. Error: %s",
	'admin:plugins:deactivate:yes' => "Deactivated %s.",
	'admin:plugins:deactivate:no' => "Could not deactivate %s.",
	'admin:plugins:deactivate:no_with_msg' => "Could not deactivate %s. Error: %s",
	'admin:plugins:activate:yes' => "Activated %s.",
	'admin:plugins:activate:no' => "Could not activate %s.",
	'admin:plugins:activate:no_with_msg' => "Could not activate %s. Error: %s",
	'admin:plugins:categories:all' => 'All categories',
	'admin:plugins:plugin_website' => 'Plugin website',
	'admin:plugins:author' => '%s',
	'admin:plugins:version' => 'Version %s',
	'admin:plugin_settings' => 'Plugin Settings',
	'admin:plugins:warning:unmet_dependencies_active' => 'This plugin is active but has unmet dependencies. You may encounter problems. See "more info" below for details.',

	'admin:plugins:dependencies:type' => 'Type',
	'admin:plugins:dependencies:name' => 'Name',
	'admin:plugins:dependencies:expected_value' => 'Expected Value',
	'admin:plugins:dependencies:local_value' => 'Actual value',
	'admin:plugins:dependencies:comment' => 'Comment',	

	'admin:plugins:reorder:yes' => "플러그인 %s 는 성공적으로 복구되었습니다. .",
	'admin:plugins:reorder:no' => "플러그인 %s 는 복구할 수 없습니다.",
	'admin:plugins:disable:yes' => "플러그인 %s 는 성공적으로 비활성화 되었습니다.",
	'admin:plugins:disable:no' => "플러그인 %s 비활성화 될 수 없었습니다.",
	'admin:plugins:enable:yes' => "플러그인 %s 성공적으로 활성화 되었습니다. ",
	'admin:plugins:enable:no' => "플러그인 %s 활성화 될 수 없었습니다.",

	'admin:statistics' => "통계",
	'admin:statistics:description' => "이것은 당신의 사이트에 대한 통계 개요입니다. 좀더 자세한 통계가 필요하다면, 전문적인 관리 기능을 사용할 수 있습니다.",
	'admin:statistics:opt:description' => "당신의 사이트에 대한 사용자와 객체에 관한 통계 정보를 볼 수 있습니다.",
	'admin:statistics:opt:linktext' => "통계를 보기...",
	'admin:statistics:label:basic' => "기초적인 사이트 통계",
	'admin:statistics:label:numentities' => "사이트에 관한 엔티티",
	'admin:statistics:label:numusers' => "사용자의 수",
	'admin:statistics:label:numonline' => "온라인 상에 있는 사용자의 수",
	'admin:statistics:label:onlineusers' => "현재 온라인 사용자",
	'admin:statistics:label:version' => "Elgg 버전",
	'admin:statistics:label:version:release' => "릴리즈",
	'admin:statistics:label:version:version' => "버전",

	'admin:user:label:search' => "사용자를 찾기:",
	'admin:user:label:searchbutton' => "검색",

	'admin:user:ban:no' => "사용자를 금지할 수 없습니다.",
	'admin:user:ban:yes' => "사용자 금지.",
	'admin:user:self:ban:no' => "You cannot ban yourself",
    'admin:user:unban:no' => "사용자를 금지할 수 있습니다",
	'admin:user:unban:yes' => "사용자 금지 취소.",
	'admin:user:delete:no' => "사용자를 삭제할 수 없습니다.",
	'admin:user:delete:yes' => "사용자 %s 삭제될 수 없습니다. ",
    'admin:user:self:delete:no' => "You cannot delete yourself",

	'admin:user:resetpassword:yes' => "패스워드 재설정, 사용자 통보.",
	'admin:user:resetpassword:no' => "패스워드를 재설정 할 수 없습니다.",

	'admin:user:makeadmin:yes' => "사용자가 현재 관리자 입니다.",
	'admin:user:makeadmin:no' => "이 사용자를 관리자로 만들 수 없습니다.",

	'admin:user:removeadmin:yes' => "사용자는 더이상 관리자가 아닙니다.",
	'admin:user:removeadmin:no' => "이 사용자로 부터 관리자 권한을 제거할 수 없습니다.",
    'admin:user:self:removeadmin:no' => "You cannot remove your own administrator privileges.",
    'admin:appearance:menu_items' => 'Menu Items',
	'admin:menu_items:configure' => 'Configure main menu items',
	'admin:menu_items:description' => 'Select which menu items you want to show as featured links.  Unused items will be added as "More" at the end of the list.',
	'admin:menu_items:hide_toolbar_entries' => 'Remove links from tool bar menu?',
	'admin:menu_items:saved' => 'Menu items saved.',
	'admin:add_menu_item' => 'Add a custom menu item',
	'admin:add_menu_item:description' => 'Fill out the Display name and URL to add custom items to your navigation menu.',

	'admin:appearance:default_widgets' => 'Default Widgets',
	'admin:default_widgets:unknown_type' => 'Unknown widget type',
	'admin:default_widgets:instructions' => 'Add, remove, position, and configure default widgets for the selected widget page.'
		. '  These changes will only affect new users on the site.',

/**
 * User settings
 */
	'usersettings:description' => "사용자 설정 패널은 사용자 관리에서 부터 플러그인이 어떻게 동작해야 하는지까지의 당신의 모든 개인적인 설정을 할 수 있도록 해 줍니다. 시작하려면 아래 옵션을 선택하세요.",

	'usersettings:statistics' => "당신의 통계",
	'usersettings:statistics:opt:description' => "당신의 사이트에서 사용자와 객체들에 대한 통계 정보 보기.",
	'usersettings:statistics:opt:linktext' => "계정 통계",

	'usersettings:user' => "당신의 설정",
	'usersettings:user:opt:description' => "이것은 사용자 설정을 할 수 있도록 해 줍니다.",
	'usersettings:user:opt:linktext' => "당신의 설정을 변경",

	'usersettings:plugins' => "도구들",
	'usersettings:plugins:opt:description' => "당신의 활성화된 도구들에 대해서(만약 있다면) 설정을 구성하기.",
	'usersettings:plugins:opt:linktext' => "당신의 도구들을 구성",

	'usersettings:plugins:description' => "이 패널은 당신이 시스템 관리자에 의해서 설치된 도구들에 대해서 개인적인 설정을 구성하고 제어하도록 해 줍니다.",
	'usersettings:statistics:label:numentities' => "당신의 콘텐트",

	'usersettings:statistics:yourdetails' => "당신의 세부사항",
	'usersettings:statistics:label:name' => "전체 이름",
	'usersettings:statistics:label:email' => "이메일",
	'usersettings:statistics:label:membersince' => "Member since",
	'usersettings:statistics:label:lastlogin' => "마지막 로그인",

/**
 * Activity river
 */
	'river:all' => 'All Site Activity',
	'river:mine' => 'My Activity',
	'river:friends' => 'Friends Activty',
	'river:select' => 'Show %s',
	'river:comments:more' => '+%u more',
	'river:generic_comment' => 'commented on %s %s',

	'friends:widget:description' => "Displays some of your friends.",
	'friends:num_display' => "Number of friends to display",
	'friends:icon_size' => "Icon size",
	'friends:tiny' => "tiny",
	'friends:small' => "small",

/**
 * Generic action words
 */

	'save' => "저장",
    'reset' => 'Reset',	
    'publish' => "출판",
	'cancel' => "취소",
	'saving' => "저장중...",
	'update' => "업데이트",
    'preview' => "Preview",	
    'edit' => "편집",
	'delete' => "삭제",
	'accept' => "수락",
	'load' => "로드",
	'upload' => "업로드",
	'ban' => "금지",
	'unban' => "금지 않함",
	'enable' => "활성화",
	'disable' => "비활성화",
	'request' => "요청",
	'complete' => "완료함",
	'open' => '열기',
	'close' => '닫기',
	'reply' => "답글",
	'more' => '좀 더...',
	'comments' => '코멘트',
	'import' => '가져오기',
	'export' => '내보내기',
	'untitled' => '제목없음',
	'help' => '도움말',
	'send' => '보내기',
	'post' => '포스트',
	'submit' => '제출하기',
  
  'comment' => 'Comment',
	'upgrade' => 'Upgrade',
	'sort' => 'Sort',
	'filter' => 'Filter',
	'new' => 'New',
	'add' => 'Add',
	'create' => 'Create',

	'site' => '사이트',
	'activity' => 'Activity',
	'members' => 'Members',

	'up' => '위로',
	'down' => '아래로',
	'top' => '맨 위로',
	'bottom' => '맨 아래로',

	'invite' => "초대",

	'resetpassword' => "패스워드 재설정",
	'makeadmin' => "관리자로 만들기",
	'removeadmin' => "관리자를 제거",

	'option:yes' => "예",
	'option:no' => "아니오",

	'unknown' => '알 수 없는',

	'active' => '활성화됨',
	'total' => '합계',

	'learnmore' => "자세한 내용은 여기를 클릭하세요.",

	'content' => "내용",
	'content:latest' => '가장 최근 활동',
	'content:latest:blurb' => '또는, 사이트 전체에 가장 최근의 컨텐트를 보려면 여기를 클릭하세요. ',

	'link:text' => '링크 보기',

	'enableall' => '모두 활성화',
	'disableall' => '모두 비활성화',


/**
 * Generic questions
 */

	'question:areyousure' => '확실합니까?',

/**
 * Generic data words
 */

	'title' => "타이틀",
	'description' => "설명",
	'tags' => "태그",
	'spotlight' => "스포라이트",
	'all' => "모두",

	'by' => '의해서',

	'annotations' => "주석",
	'relationships' => "관계",
	'metadata' => "메타 데이터",

'tagcloud' => "Tag cloud",
	'tagcloud:allsitetags' => "All site tags",

	'on' => 'On',
	'off' => 'Off',

/**
 * Entity actions
 */
	'edit:this' => 'Edit this',
	'delete:this' => 'Delete this',
	'comment:this' => 'Comment on this',


/**
 * Input / output strings
 */

	'deleteconfirm' => "이 항목을 삭제하는 것이 확실 합니까?",
	'fileexists' => "파일이 이미 업로드 되었습니다. 그것을 바꾸도록, 아래에서 그것을 선택하세요::",

/**
 * User add
 */

	'useradd:subject' => '사용자 계정 생성됨',
	'useradd:body' => '
%s,

사용자 계정이 %s 에서 생성되었습니다. 로그인 하기 위해서 방문하세요:

%s

그리고 이런 사용자로 로그인:

사용자명: %s
패스워드: %s

일단 로그인하면, 패스워드 변경을 강력히 추천합니다.
',

/**
 * System messages
 **/

	'systemmessages:dismiss' => "사라지도록 클릭",


/**
 * Import / export
 */
	'importsuccess' => "데이터 가져오기 성공했습니다.",
	'importfail' => "데이터의 OpenDD 가져오기는 실패했습니다.",

/**
 * Time
 */

	'friendlytime:justnow' => "바로 지금",
	'friendlytime:minutes' => "%s 분 전",
	'friendlytime:minutes:singular' => "1분 전",
	'friendlytime:hours' => "%s 시간 전",
	'friendlytime:hours:singular' => "한 시간 전",
	'friendlytime:days' => "%s 일 전",
	'friendlytime:days:singular' => "어제",
	'friendlytime:date_format' => 'j F Y @ g:ia',

	'date:month:01' => '1월 %s',
	'date:month:02' => '2월 %s',
	'date:month:03' => '3월 %s',
	'date:month:04' => '4월 %s',
	'date:month:05' => '5월 %s',
	'date:month:06' => '6월 %s',
	'date:month:07' => '7월 %s',
	'date:month:08' => '8월 %s',
	'date:month:09' => '9월 %s',
	'date:month:10' => '10월%s',
	'date:month:11' => '11월 %s',
	'date:month:12' => '12월 %s',


/**
 * Installation and system settings
 */

	'installation:error:htaccess' => "Elgg는 설치하는 루트 디렉토리에 설치하기 위해서 .htaccess가 호출되는 파일을 필요로 합니다. 그것을 만들려고 했습니다만, Elgg는 그 디렉토리에 쓸 수 있늘 권한이 없습니다. 

 이것을 만드는 것은 쉽습니다. 텍스트 편집기에 아래 텍스트의 내용을 복사하고 그것을 .htaccess로 저장하세요. ",
	'installation:error:settings' => "Elgg가 설정 파일을 찾을 수 없었습니다. Elgg의 설정의 대부분은 당신을 위해서 다루어질 것입니다. 그러나 당신이 데이터베이스 세부사항을 제공할 필요가 있습니다. 
	 이렇게 하세요:

1. Elgg 설치시에 engine/settings.example.php를 settings.php로 바꾸세요.

2. 텍스트 편집기로 그것을 열고 MySQL 데이터베이스 세부사항을 입력하세요. 이것을 모른다면 시스템 관리자에게 묻거나 기술적인 지원을 도움 받으세요. 

선택적으로, 데이터베이스 설정을 아래 입력할 수 있습니다. 그리고 우리가 당신을 위해서 이것을 하려고 할 것입니다....",

	'installation:error:db:title' => "데이터베이스 설정 오류",
	'installation:error:db:text' => "Elgg가 데이터베이스에 접근하여 연결할 수 없을 때는 데이터베이스 설정을 다시 체크하세요.",
	'installation:error:configuration' => "일단 구성에 대한 이슈를 고치고 나면, 다시 시도하기 위해서 reload를 누르세요.",

	'installation' => "설치",
	'installation:success' => "Elgg의 데이터베이스가 성공적으로 설치되었습니다.",
	'installation:configuration:success' => "초기 구성 설정이 저장되었습니다. 지금 초기 사용자를 등록하세요; 이것이 첫 번째 시스템 관리자가 될 것입니다.",

	'installation:settings' => "시스템 설정",
	'installation:settings:description' => "이제 Elgg 데이터베이스가 성공적으로 설치되었습니다. 완전히 완료하고 실행되도록 하기 위해서 몇 가지 정보를 입력할 필요가 있습니다. We've tried to guess where we could, but <b>당신은 이 세부사항들을 체크해야 합니다.</b>",

	'installation:settings:dbwizard:prompt' => "아래 데이터베이스 설정을 입력하고 저장을 누르세요:",
	'installation:settings:dbwizard:label:user' => "데이터베이스 사용자",
	'installation:settings:dbwizard:label:pass' => "데이터베이스 패스워드",
	'installation:settings:dbwizard:label:dbname' => "Elgg 데이터베이스",
	'installation:settings:dbwizard:label:host' => "데이터베이스 호스트이름(통상적으로 'localhost')",
	'installation:settings:dbwizard:label:prefix' => "데이터베이스 테이블 prefix (통상적으로 'elgg_')",

	'installation:settings:dbwizard:savefail' => "새로운 settings.php 를 저장할 수 없었습니다. 텍스트 편집기를 사용해서 아래 파일을 engine/settings.php로 저장해 주세요.",

	'installation:sitename' => "당신의 사이트의 이름(예를 들어 \"My social networking site\"):",
	'installation:sitedescription' => "당신의 사이트에 간단한 설명(옵션)",
	'installation:wwwroot' => "\가 따르는 사이트 URL:",
	'installation:path' => "디스크 상에 있는 사이트 루트에 대한 완전한 경로, \가 따릅니다:",
	'installation:dataroot' => "업로드한 파일이 저장될 디렉토리에 대한 완전한 경로,\가 따릅니다:",
	'installation:dataroot:warning' => "수동으로 이 디렉토리를 만들어야 합니다. Elgg 설치를 위해서 다른 디렉토리에 있어야 합니다.",
	'installation:sitepermissions' => "기본 접근 권한:",
	'installation:language' => "사이트 기본 언어:",
	'installation:debug' => "디버그 모드는 결함을 진단하는데 사용할 수 있는 추가적인 정보를 제공합니다. 그러나, 그것은 시스템의 속도를 저하시킬 수 있기 때문에, 문제가 있을 때에만 사용되어야 합니다 :",
	'installation:debug:none' => '디버그 모드 끄기(추천)',
	'installation:debug:error' => '중요한 오류만 표시함',
	'installation:debug:warning' => '오류와 경고를 표시함',
	'installation:debug:notice' => '모든 오류, 경고와 통지를 로그',
	'installation:httpslogin' => "HTTPS에서 수행된 사용자 로그인을 갖기 위해서 이것을 활성화. 이것이 적용되도록 서버에 활성화된 https가 있을 필요가 있습니다.",
	'installation:httpslogin:label' => "HTTPS 로그인을 활성화",
	'installation:view' => "사이트에 대해서 초기에 사용될 뷰를 입력 혹은 초기 뷰에 대하여 이것을 빈칸으로 남겨 두기(의심스럽다면, 초기값으로 두세요.):",

	'installation:siteemail' => "사이트 이메일 주소(시스템 이메을 보낼 때 사용된)",

	'installation:disableapi' => "RESTful APIsms 원격으로 어떤 Elgg 기능들을 활성화할 수 있는 유연하고 확장성 있는 인터페이스이다.",
	'installation:disableapi:label' => "RESTful API 활성화",

	'installation:allow_user_default_access:description' => "체크된다면, 개인적인 사용자들이 시스템 초기 접근 레벨을 덮어씌울 수 있는 자신의 초기 접근 레벨을 사용하도록 허가할 것이다.",
	'installation:allow_user_default_access:label' => "사용자 초기 접근을 허가함",

	'installation:simplecache:description' => "간단한 캐쉬가 어떤 CSS와 JavaScript 파일을 포함한 정적인 컨텐트를 캐쉬함으로써 수행을 증가시킨다. ",
	'installation:simplecache:label' => " 간단한 캐쉬 사용(추천)",

	'installation:viewpathcache:description' => "파일경로 캐쉬 뷰는 뷰의 위치를 캐쉬함으로써 로딩 시감을 감소시킨다.",
	'installation:viewpathcache:label' => "파일경로 캐쉬 뷰를 사용(추천)",

	'upgrading' => '업그레이드 중...',
	'upgrade:db' => '데이터베이스 업그레이드 되었습니다.',
	'upgrade:core' => 'elgg 설치가 업그레이드 되었습니다.',

/**
 * Welcome
 */

	'welcome' => "환영합니다.",
	'welcome:user' => '%s 님 환영합니다. ',
	'welcome_message' => "Elgg 설치에 오신 것을 환영합니다.",

/**
 * Emails
 */
	'email:settings' => "이메일 설정",
	'email:address:label' => "당신의 이메일 주소",

	'email:save:success' => "새로운 이메일 주소가 저장됨, 확인이 요구됨.",
	'email:save:fail' => "당신의 새로운 이메일 주소는 저장되지 않았습니다.",

	'friend:newfriend:subject' => "%s님이 당신을 친구로 삼았습니다!",
	'friend:newfriend:body' => "%s님이 당신을 친구로 삼았습니다!

그들의 프로필을 보기위해서 여기를 클릭:

%s 당신은 이 이메일에 대답할 수 없습니다.",



	'email:resetpassword:subject' => "패스워드 재설정!",
	'email:resetpassword:body' => "하이! %s,

패스워드가 리셋되었습니다 : %s",

	'email:resetreq:subject' => "새로운 패스워드를 요구합니다.",
	'email:resetreq:body' => "하이, %s,

(IP address %s 로 부터) 누군가가 계정에 대해서 새로운 패스워드를 요구했습니다. 

 당신이 아래 링크에서 클릭을 요청 한다면, 그렇지 않으면, 이 이메일을 무시하세요. %s
",




/**
 * user default access
 */

'default_access:settings' => "당신의 초기 접근 레벨",
'default_access:label' => "초기 접근",
'user:default_access:success' => "새로운 초기 접근 레벨이 저장되었습니다.",
'user:default_access:failure' => "새로운 초기 접근 레벨이 저장될 수 없었습니다.",

/**
 * XML-RPC
 */
	'xmlrpc:noinputdata'	=>	"입력 데이터가 빠져있습니다.",

/**
 * Comments
 */

	'comments:count' => "%s 덧글들",

	'riveraction:annotation:generic_comment' => '%s 에 덧글을 단 %s',

	'generic_comments:add' => "덧글 추가",
	'generic_comments:post' => "Post comment",
    'generic_comments:text' => "덧글",
    'generic_comments:latest' => "Latest comments",	
    'generic_comment:posted' => "덧글이 성공적으로 포스트 되었습니다.",
	'generic_comment:deleted' => "덧글을 지우는데 성공했습니다. ",
	'generic_comment:blank' => "미안합니다. 그것을 저장하기 전에 덧글에 어떤 것을 실제적으로 입력할 필요가 있습니다.",
	'generic_comment:notfound' => "미안합니다. 지정된 아이템을 찾을 수 없습니다.",
	'generic_comment:notdeleted' => "미안합니다. 이 덧글을 삭제할 수 없습니다.",
	'generic_comment:failure' => "덧글을 저장할 때 예기치 못한 오류가 나타났습니다. 다시 시도 해 보세요.",
    'generic_comment:none' => 'No comments',
	'generic_comment:title' => 'Comment by %s',

	'generic_comment:email:subject' => '새로운 덧글이 있습니다!!',
	'generic_comment:email:body' => "당신의 %s로 부터의 항목\"%s\" 에 대해서 새로운 덧글이 있습니다. 읽어봅니다.:


%s


원래 항목을 보거나 답변하기위 해서, 여기를 클릭:

%s

%s의 프로필을 보기 위해서, 여기를 클릭:

%s

당신은 이 이메일에 답할 수 없습니다. ",

/**
 * Entities
 */
    'byline' => 'By %s',
	'entity:default:strapline' => '%s에 의해서 생성된 %s ',
	'entity:default:missingsupport:popup' => '이 엔티티는 올바르게 볼 수 없습니다. 더 이상 설치되지 않은 플러그인에 의해서 제공되는 지원을 요구하기 때문일지도 모릅니다.',

	'entity:delete:success' => '엔티티 %s 가 삭제되었습니다.',
	'entity:delete:fail' => '엔티티 %s 가 삭제 될 수 없습니다. ',


/**
 * Action gatekeeper
 */
	'actiongatekeeper:missingfields' => '폼은 __토큰 혹은 __ts 필드가 빠져있습니다.',
	'actiongatekeeper:tokeninvalid' => "(토큰이 일치하지 않는) 오류를 만났습니다. 이것은 아마도 당신이 사용하는 페이지가 만료되었다는 것을 의미합니다. 다시 시도해 보세요.",
	'actiongatekeeper:timeerror' => '사용하고 있던 페이지가 만료되었습니다. 새로 고침 후 다시 시도해 보세요.',
	'actiongatekeeper:pluginprevents' => '확장은 이 폼이 제출되는 것을 금지합니다.',

/**
 * Word blacklists
 */
	'word:blacklist' => 'and, the, then, but, she, his, her, him, one, not, also, about, now, hence, however, still, likewise, otherwise, therefore, conversely, rather, consequently, furthermore, nevertheless, instead, meanwhile, accordingly, this, seems, what, whom, whose, whoever, whomever',

/**
 * Tag labels
 */

	'tag_names:tags' => '태그들',
    'tags:site_cloud' => 'Site Tag Cloud',

/**
 * Javascript
 */

	'js:security:token_refresh_failed' => 'Cannot contact %s. You may experience problems saving content.',
	'js:security:token_refreshed' => 'Connection to %s restored!',
 
/**
 * Languages according to ISO 639-1
 */
	"aa" => "Afar",
	"ab" => "Abkhazian",
	"af" => "Afrikaans",
	"am" => "Amharic",
	"ar" => "Arabic",
	"as" => "Assamese",
	"ay" => "Aymara",
	"az" => "Azerbaijani",
	"ba" => "Bashkir",
	"be" => "Byelorussian",
	"bg" => "Bulgarian",
	"bh" => "Bihari",
	"bi" => "Bislama",
	"bn" => "Bengali; Bangla",
	"bo" => "Tibetan",
	"br" => "Breton",
	"ca" => "Catalan",
	"co" => "Corsican",
	"cs" => "Czech",
	"cy" => "Welsh",
	"da" => "Danish",
	"de" => "German",
	"dz" => "Bhutani",
	"el" => "Greek",
	"en" => "English",
	"eo" => "Esperanto",
	"es" => "Spanish",
	"et" => "Estonian",
	"eu" => "Basque",
	"fa" => "Persian",
	"fi" => "Finnish",
	"fj" => "Fiji",
	"fo" => "Faeroese",
	"fr" => "French",
	"fy" => "Frisian",
	"ga" => "Irish",
	"gd" => "Scots / Gaelic",
	"gl" => "Galician",
	"gn" => "Guarani",
	"gu" => "Gujarati",
	"he" => "Hebrew",
	"ha" => "Hausa",
	"hi" => "Hindi",
	"hr" => "Croatian",
	"hu" => "Hungarian",
	"hy" => "Armenian",
	"ia" => "Interlingua",
	"id" => "Indonesian",
	"ie" => "Interlingue",
	"ik" => "Inupiak",
	//"in" => "Indonesian",
	"is" => "Icelandic",
	"it" => "Italian",
	"iu" => "Inuktitut",
	"iw" => "Hebrew (obsolete)",
	"ja" => "Japanese",
	"ji" => "Yiddish (obsolete)",
	"jw" => "Javanese",
	"ka" => "Georgian",
	"kk" => "Kazakh",
	"kl" => "Greenlandic",
	"km" => "Cambodian",
	"kn" => "Kannada",
	"ko" => "Korean",
	"ks" => "Kashmiri",
	"ku" => "Kurdish",
	"ky" => "Kirghiz",
	"la" => "Latin",
	"ln" => "Lingala",
	"lo" => "Laothian",
	"lt" => "Lithuanian",
	"lv" => "Latvian/Lettish",
	"mg" => "Malagasy",
	"mi" => "Maori",
	"mk" => "Macedonian",
	"ml" => "Malayalam",
	"mn" => "Mongolian",
	"mo" => "Moldavian",
	"mr" => "Marathi",
	"ms" => "Malay",
	"mt" => "Maltese",
	"my" => "Burmese",
	"na" => "Nauru",
	"ne" => "Nepali",
	"nl" => "Dutch",
	"no" => "Norwegian",
	"oc" => "Occitan",
	"om" => "(Afan) Oromo",
	"or" => "Oriya",
	"pa" => "Punjabi",
	"pl" => "Polish",
	"ps" => "Pashto / Pushto",
	"pt" => "Portuguese",
	"qu" => "Quechua",
	"rm" => "Rhaeto-Romance",
	"rn" => "Kirundi",
	"ro" => "Romanian",
	"ru" => "Russian",
	"rw" => "Kinyarwanda",
	"sa" => "Sanskrit",
	"sd" => "Sindhi",
	"sg" => "Sangro",
	"sh" => "Serbo-Croatian",
	"si" => "Singhalese",
	"sk" => "Slovak",
	"sl" => "Slovenian",
	"sm" => "Samoan",
	"sn" => "Shona",
	"so" => "Somali",
	"sq" => "Albanian",
	"sr" => "Serbian",
	"ss" => "Siswati",
	"st" => "Sesotho",
	"su" => "Sundanese",
	"sv" => "Swedish",
	"sw" => "Swahili",
	"ta" => "Tamil",
	"te" => "Tegulu",
	"tg" => "Tajik",
	"th" => "Thai",
	"ti" => "Tigrinya",
	"tk" => "Turkmen",
	"tl" => "Tagalog",
	"tn" => "Setswana",
	"to" => "Tonga",
	"tr" => "Turkish",
	"ts" => "Tsonga",
	"tt" => "Tatar",
	"tw" => "Twi",
	"ug" => "Uigur",
	"uk" => "Ukrainian",
	"ur" => "Urdu",
	"uz" => "Uzbek",
	"vi" => "Vietnamese",
	"vo" => "Volapuk",
	"wo" => "Wolof",
	"xh" => "Xhosa",
	//"y" => "Yiddish",
	"yi" => "Yiddish",
	"yo" => "Yoruba",
	"za" => "Zuang",
	"zh" => "Chinese",
	"zu" => "Zulu",
);

add_translation("ko",$korean);
