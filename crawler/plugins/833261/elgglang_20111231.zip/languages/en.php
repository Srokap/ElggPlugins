<?php
/**
 * Core language file
 *
 * @package Elgg
 * @subpackage Core
 */

$english = array(

/**
 * Sites
 */

	'item:site' => '사이트',

/**
 * Sessions
 */

	'login' => "로그인",
	'loginok' => "로그인 성공!!",
	'loginerror' => "당신은 로그인 할 수 없다. 아직 계정이 생성되지 않았기 때문입니다, 입력한 사항이 잘 못되었거나,잘 못된 시도를 너무 많이 했기 때문입니다. 세부적인 입력사항을 다시 확인하고 재시도 해 보세요.",

	'logout' => "로그 아웃",
	'logoutok' => "로그 아웃 되었습니다.",
	'logouterror' => "로그 아웃되지 않았습니다. 다시 시도해 보세요.",

	'loggedinrequired' => "이 페이지를 보기 위해서는 로그인 해야 합니다.",
	'adminrequired' => "이 페이지를 보기 위해서 관리자 관리자여야 합니다.",
	'membershiprequired' => "이 페이지를 보기 위해서는 그룹의 멤버가 되어야 합니다.",


/**
 * Errors
 */
	'exception:title' => "elgg에 오신 것을 환영합니다.",

	'InstallationException:CantCreateSite' => "이름:%s, Url: %s을 사용하여 elgg 사이트를 생성할 수 없습니다.",

	'actionundefined' => "요청하신 작업 (%s)는 시스템에 정의되어 있지 않습니다. ",
	'actionloggedout' => "미안합니다. 로그 아웃 상태에서는 이 작업을 수행할 수 없습니다.",
	'actionunauthorized' => '당신은 이 작업을 수행할 수 있는 권한이 없습니다.',

	'SecurityException:Codeblock' => "권한이 있는 코드 블럭을 실행할 수 있는 접근이 거부되었습니다.",
	'DatabaseException:WrongCredentials' => "Elgg는 주어진 정보를 사용하여 데이터베이스에 연결할 수 없습니다.",
	'DatabaseException:NoConnect' => "Elgg는 데이터베이스 '%s'를 선택할 수 없습니다, 데이터베이스가 만들어져 있는지, DB에 접근할 수 있는 체크해 주십시오.",
	'SecurityException:FunctionDenied' => "권한이 필요한 기능'%s' 에 대한 접근이 거부되었습니다.  ",
	'DatabaseException:DBSetupIssues' => "여러가지 문제가 있었음: ",
	'DatabaseException:ScriptNotFound' => "Elgg가 %s에서 요청된 데이터베이스를 찾을 수 없었습니다.  ",

	'IOException:FailedToLoadGUID' => "GUID:%d 로부터 새로운 %s를 로드하는데 실패했습니다.",
	'InvalidParameterException:NonElggObject' => "ElggObject 생성자에게 non-ElggObject로 넘겨주기!",
	'InvalidParameterException:UnrecognisedValue' => "알 수 없는 값이 생성자에게 넘겨짐.",

	'InvalidClassException:NotValidElggStar' => "GUID:%d 은(는) 값: %s가 아닙니다.",

	'PluginException:MisconfiguredPlugin' => "%s은(는) 잘 못 설정된 플러그인 입니다. 그것은 활성화 되어 있지 않습니다. 가능한 원인에 대해서 Elgg 위키를 검색해 보세요.(http://docs.elgg.org/wiki/).",

	'InvalidParameterException:NonElggUser' => "ElggUser 생성자에게 a non-ElggUser를 넘겨주었음!",

	'InvalidParameterException:NonElggSite' => "ElggSite 생성자에게 a non-ElggSite를 넘겨주었음!",

	'InvalidParameterException:NonElggGroup' => "ElggGroup 생성자에게 a non-ElggGroup을 넘겨주었음!",

	'IOException:UnableToSaveNew' => "새로운 %s를 저장할 수 없습니다.",

	'InvalidParameterException:GUIDNotForExport' => "추출하는 동안 GUID가 지정되지 않았습니다. 이것은 절대로 일어나지 않아야 합니다.",
	'InvalidParameterException:NonArrayReturnValue' => "Entity 직렬화 기능은 배열화 되지 않는 반환 값 파라미터를 넘겨주었음",

	'ConfigurationException:NoCachePath' => "캐쉬 경로가 아무 것도 설정되지 않음!",
	'IOException:NotDirectory' => "%s은(는) 디렉토리가 아닙니다.",

	'IOException:BaseEntitySaveFailed' => "새로운 개체의 기초 엔티티 정보를 저장할 수 없습니다. !",
	'InvalidParameterException:UnexpectedODDClass' => "예기치 않은 ODD 클래스를 넘긴 import() ",
	'InvalidParameterException:EntityTypeNotSet' => "엔티티 타입이 설정되어야만 합니다.",

	'ClassException:ClassnameNotClass' => "%s은(는) %s이(가) 아닙니다.",
	'ClassNotFoundException:MissingClass' => "클래스 '%s'는 발견되지 않았습니다. 플러그인을 뺐습니까?",
	'InstallationException:TypeNotSupported' => "타입 %s은(는) 지원되지 않습니다. 이것은 설치 정보에서의 오류를 가리킵니다. 대개 완료도지 않은 업그레이드에 의해서 발생하는 것 같습니다.",

	'ImportException:ImportFailed' => "엘리먼트 %d를(을) 가져올 수 없습니다.",
	'ImportException:ProblemSaving' => "%s를(을) 저장하는데 문제가 있었습니다.",
	'ImportException:NoGUID' => "새로운 엔티티가 생성되었지만, GUID를 가지고 있지 않습니다. 이런 일은 발생하면 안됩니다.",

	'ImportException:GUIDNotFound' => "엔티티 '%d'을(를) 찾을 수 없습니다.",
	'ImportException:ProblemUpdatingMeta' => "엔티티 '%d'에 '%s'를(을) 업데이트 하는데 문제가 있었습니다.",

	'ExportException:NoSuchEntity' => "그런 엔티티 GUID:%d는 없습니다.",

	'ImportException:NoODDElements' => "가져올 데이터에서 어떤 OpenDD 엘리먼트를 찾을 수 없었습니다. 가져오는데 실패했습니다.",
	'ImportException:NotAllImported' => "모든 엘리먼트들을 가져오지는 못 했습니다.",

	'InvalidParameterException:UnrecognisedFileMode' => "알 수 없는 파일 모드 '%s'",
	'InvalidParameterException:MissingOwner' => "파일 %s (파일 guid:%d) (owner guid:%d)가 owner를 잃어버렸습니다!",
	'IOException:CouldNotMake' => "%s를 만들 수 없었습니다.",
	'IOException:MissingFileName' => "파일을 열기 전에 이름을 정해야 합니다.",
	'ClassNotFoundException:NotFoundNotSavedWithFile' => " 파일 %u에 대한 filestore class %s를 로드할 수 없습니다.",
	'NotificationException:NoNotificationMethod' => "어떤 공지 방법도 지정하지 않았습니다.",
	'NotificationException:NoHandlerFound' => "'%s'에 대한 어떤 핸들러를 찾을 수 없거나 그것이 호출되지 않았습니다.",
	'NotificationException:ErrorNotifyingGuid' => "%d를 공지하는 동안 오류가 있었습니다.",
	'NotificationException:NoEmailAddress' => "GUID:%d에 대한 이메일 주소를 가져올 수 없었습니다. ",
	'NotificationException:MissingParameter' => "요청된 파라미터, '%s'를 잃어버렸습니다.",

	'DatabaseException:WhereSetNonQuery' => "설정은 어디에 non WhereQueryComponent 포함하고 있는가",
	'DatabaseException:SelectFieldsMissing' => "선택한 스타일 쿼리에 필드가 빠져 있음",
	'DatabaseException:UnspecifiedQueryType' => "인식하지 못하거나 지정되지 않은 쿼리 타입.",
	'DatabaseException:NoTablesSpecified' => "쿼리에 대해서 어떤 테이블도 지정되지 않았음.",
	'DatabaseException:NoACL' => "어떤 접근 제어도 쿼리에 제공되지 않았음",

	'InvalidParameterException:NoEntityFound' => "어떤 엔티티도 찾지 못했습니다. 그것이 존재하지 않거나 그것에 접근 권한이 없습니다. ",

	'InvalidParameterException:GUIDNotFound' => "GUID:%s는 찾을 수 없거나, 그것에 접근할 수 없습니다.",
	'InvalidParameterException:IdNotExistForGUID' => "미안합니다, '%s'는 guid:%d에 대해서 존재하지 않습니다.",
	'InvalidParameterException:CanNotExportType' => "미안합니다, '%s'를 출력하는 방법을 알 수 없습니다.",
	'InvalidParameterException:NoDataFound' => "어떤 데이터를 찾을 수 없었습니다.",
	'InvalidParameterException:DoesNotBelong' => "엔티티에 속해 있지 않습니다.",
	'InvalidParameterException:DoesNotBelongOrRefer' => "엔티티에 속해 있지 않거나 엔티티를 참조 하고 있지 않습니다.",
	'InvalidParameterException:MissingParameter' => "파라미터가 빠졌습니다, GUID를 제공해 줄 필요가 있습니다.",

	'APIException:ApiResultUnknown' => "API 결과가 알려지지 않은 타입입니다. 이런 일은 발생해서는 안됩니다.",
	'ConfigurationException:NoSiteID' => "어떤 사이트 ID도 지정되지 않았습니다.",
	'SecurityException:APIAccessDenied' => "미안합니다, API 접근은 관리자에 의해서 비활성화 되었습니다.",
	'SecurityException:NoAuthMethods' => "이런 API 요청에 권한을 줄 수 있는 어떤 권한 함수도 찾을 수가 없습니다.",
	'SecurityException:UnexpectedOutputInGatekeeper' => 'gatekeeper에 예기치 않은 출력이 호출. 보안때문에 실행을 중지. 좀 더 정보를 얻기 위해서 http://docs.elgg.org/를 검색하세요.',
	'InvalidParameterException:APIMethodOrFunctionNotSet' => "메소드 혹은 함수가 expose_method()에 설정되지 않았습니다.",
	'InvalidParameterException:APIParametersArrayStructure' => "파라미터들의 배열 구조가 메소드'%s'를 나타내기 위한 호출에 대해서 올바르지 않습니다.",
	'InvalidParameterException:UnrecognisedHttpMethod' => "api 메소드'%s'에 대한 인식되지 않은 http 메소드 %s",
	'APIException:MissingParameterInMethod' => "메소드 %s에 파라미터 %s가 없습니다.",
	'APIException:ParameterNotArray' => "%s는 배열에 나타나 있지 않습니다.",
	'APIException:UnrecognisedTypeCast' => "메소드 '%s'에 변수'%s'에 대한 캐스트'%s'에 인식되지 않은 형식",
	'APIException:InvalidParameter' => "잘못된 파라미터가 메소드 '%s'에서 '%s'을 찾았습니다.",
	'APIException:FunctionParseError' => "%s(%s)는 파싱 에러가 있습니다.",
	'APIException:FunctionNoReturn' => "%s(%s)는 어떤 값도 리턴하지 않았습니다.",
	'APIException:APIAuthenticationFailed' => "메소드 호출이 API 인증을 실패했습니다. ",
	'APIException:UserAuthenticationFailed' => "메소드 호출이 사용자 인증을 실패했습니다.",
	'SecurityException:AuthTokenExpired' => "누락, 잘못되었거나 만료된 인증 토큰",
	'CallException:InvalidCallMethod' => "%s는 '%s'를 사용해서 호출되어야 합니다.",
	'APIException:MethodCallNotImplemented' => "메소드 호출 '%s'가 Method call '%s' 구현되지 않았습니다.",
	'APIException:FunctionDoesNotExist' => "메소드 '%s'에 대한 함수는 호출 할 수 없습니다.",
	'APIException:AlgorithmNotSupported' => "알고리즘 '%s'는 지원되지 않거나 활성화 되지 않았습니다.",
	'ConfigurationException:CacheDirNotSet' => "캐쉬 디렉토리 'cathe_path'가 설정하지 않았습니다. ",
	'APIException:NotGetOrPost' => "요청 메소드는 GET 혹은 POST가 되어야만 합니다.",
	'APIException:MissingAPIKey' => "Missing API key",
	'APIException:BadAPIKey' => "Bad API key",
	'APIException:MissingHmac' => "Missing X-Elgg-hmac header",
	'APIException:MissingHmacAlgo' => "Missing X-Elgg-hmac-algo header",
	'APIException:MissingTime' => "Missing X-Elgg-time header",
	'APIException:MissingNonce' => "Missing X-Elgg-nonce header",
	'APIException:TemporalDrift' => "X-Elgg-time is too far in the past or future. Epoch fail.",
	'APIException:NoQueryString' => "No data on the query string",
	'APIException:MissingPOSTHash' => "Missing X-Elgg-posthash header",
	'APIException:MissingPOSTAlgo' => "Missing X-Elgg-posthash_algo header",
	'APIException:MissingContentType' => "Missing content type for post data",
	'SecurityException:InvalidPostHash' => "POST data hash is invalid - Expected %s but got %s.",
	'SecurityException:DupePacket' => "Packet signature already seen.",
	'SecurityException:InvalidAPIKey' => "Invalid or missing API Key.",
	'NotImplementedException:CallMethodNotImplemented' => "Call method '%s' is currently not supported.",

	'NotImplementedException:XMLRPCMethodNotImplemented' => "XML-RPC method call '%s' not implemented.",
	'InvalidParameterException:UnexpectedReturnFormat' => "Call to method '%s' returned an unexpected result.",
	'CallException:NotRPCCall' => "Call does not appear to be a valid XML-RPC call",

	'PluginException:NoPluginName' => "The plugin name could not be found",

	'ConfigurationException:BadDatabaseVersion' => "The database backend you have installed doesn't meet the basic requirements to run Elgg. Please consult your documentation.",
	'ConfigurationException:BadPHPVersion' => "You need at least PHP version 5.2 to run Elgg.",
	'configurationwarning:phpversion' => "Elgg requires at least PHP version 5.2, you can install it on 5.1.6 but some features may not work. Use at your own risk.",


	'InstallationException:DatarootNotWritable' => "Your data directory %s is not writable.",
	'InstallationException:DatarootUnderPath' => "Your data directory %s must be outside of your install path.",
	'InstallationException:DatarootBlank' => "You have not specified a data directory.",

	'SecurityException:authenticationfailed' => "User could not be authenticated",

	'CronException:unknownperiod' => '%s is not a recognised period.',

	'SecurityException:deletedisablecurrentsite' => 'You can not delete or disable the site you are currently viewing!',

	'RegistrationException:EmptyPassword' => 'The password fields cannot be empty',
	'RegistrationException:PasswordMismatch' => 'Passwords must match',

	'memcache:notinstalled' => 'PHP memcache module not installed, you must install php5-memcache',
	'memcache:noservers' => 'No memcache servers defined, please populate the $CONFIG->memcache_servers variable',
	'memcache:versiontoolow' => 'Memcache needs at least version %s to run, you are running %s',
	'memcache:noaddserver' => 'Multiple server support disabled, you may need to upgrade your PECL memcache library',

	'deprecatedfunction' => 'Warning: This code uses the deprecated function \'%s\' and is not compatible with this version of Elgg',

	'pageownerunavailable' => 'Warning: The page owner %d is not accessible!',
	'changebookmark' => 'Please change your bookmark for this page',
/**
 * API
 */
	'system.api.list' => "List all available API calls on the system.",
	'auth.gettoken' => "This API call lets a user obtain a user authentication token which can be used for authenticating future API calls. Pass it as the parameter auth_token",

/**
 * User details
 */

	'name' => "보여지는 이름",
	'email' => "이메일 주소",
	'username' => "사용자명",
	'password' => "암호",
	'passwordagain' => "암호 재확인",
	'admin_option' => "이 사용자를 관리자로 할까요?",

/**
 * Access
 */

	'PRIVATE' => "개인적인",
	'LOGGED_IN' => "로그인 된 사용자",
	'PUBLIC' => "공개적인",
	'access:friends:label' => "친구들",
	'access' => "접근",

/**
 * Dashboard and widgets
 */

	'dashboard' => "대쉬보드",
	'dashboard:configure' => "페이지 편집",
	'dashboard:nowidgets' => "대쉬보드는 이 사이트로 들어가는 관문입니다. 이 시스템 내에서 활동하고 내용들을 추적하는 위젯을 추가하기 위해 '페이지 편집'을 클릭하세요.",

	'widgets:add' => '당신의 페이지에 위젯을 추가',
	'widgets:add:description' => "아래쪽 세개의 위젯 영역중 어떤 곳에라도 위젯이 나타나으면 하는 위치로, 오른쪽에 있는 <b>위젯 갤러리</b>로 부터 위젯을 드래그 해서 여러분의 페이지에 추가하고 싶은 기능을 선택하세요.
 
	위젯을 없애기 위해서는 <b>위젯 갤러리</b>로 그것을 다시 드래그 하세요. ",
	
	'widgets:position:fixed' => '(페이지에 고정된 위치)',

	'widgets' => "위젯들(Widgets)",
	'widget' => "위젯(Widget)",
	'item:object:widget' => "위젯들(Widgets)",
	'layout:customise' => "사용자 레이아웃(Customise layout)",
	'widgets:gallery' => "위젯 갤러리(Widget gallery)",
	'widgets:leftcolumn' => "왼쪽 위젯들(Left widgets)",
	'widgets:fixed' => "고정된 위치(Fixed position)",
	'widgets:middlecolumn' => "중앙 위젯들(Middle widgets)",
	'widgets:rightcolumn' => "오른쪽 위젯들(Right widgets)",
	'widgets:profilebox' => "프로파일 박스(Profile box)",
	'widgets:panel:save:success' => "당신의 위젯들이 성공적으로 저장 되었습니다.",
	'widgets:panel:save:failure' => "위젯을 저장하는데 문제가 있었습니다. 로그인을 확인하고 다시 시도해 보세요.",
	'widgets:save:success' => "위젯이 성공적으로 저장되었습니다.",
	'widgets:save:failure' => "당신의 위젯을 저장할 수 없습니다. 로그인을 확인하고 다시 시도해 보세요.",
	'widgets:handlernotfound' => '이 위젯은 깨졌거나 사이트관리자에 의해서 비활성화 되어 있습니다. ',

/**
 * Groups
 */

	'group' => "그룹",
	'item:group' => "그룹들",

/**
 * Users
 */

	'user' => "사용자",
	'item:user' => "사용자들",

/**
 * Friends
 */

	'friends' => "친구들",
	'friends:yours' => "당신의 친구들",
	'friends:owned' => "%s의 친구들",
	'friend:add' => "친구로 추가",
	'friend:remove' => "친구에서 제외",

	'friends:add:successful' => "당신은 성공적으로 친구로 %s를 추가했습니다.",
	'friends:add:failure' => "친구로 %s을(를) 추가할 수 없습니다. 다시 시도해 보세요.",

	'friends:remove:successful' => "당신의 친구들로 부터 %s을(를) 성공적으로 제외했습니다.",
	'friends:remove:failure' => "당신의 친구들로 부터 %s을(를) 제외할 수 없습니다. 다시 시도해 보세요.",

	'friends:none' => "이 사용자는 아직 친구로서 아무도 추가하지 않았습니다. ",
	'friends:none:you' => "당신은 친구를 아무도 추가하지 않았습니다. 팔로우할 사람을 찾기 시작하기 위해서 당신의 관심사를 검색해 보세요.",

	'friends:none:found' => "친구를 아무도 발견하지 못했습니다.",

	'friends:of:none' => "어떤 사람도 이 사용자를 친구로 아직 추가하지 않았습니다.",
	'friends:of:none:you' => "어떤 사람도 아직 친구로 당신을 추가하지 않았습니다. 사람들이 당신을 찾을 수 있도록 프로필과 내용 추가를 시작하세요!",

	'friends:of:owned' => "%s이(가) 친구로 했던 사람들",

	'friends:of' => "의 친구들",
	'friends:collections' => "친구들의 모임들",
	'friends:collections:add' => "새로운 친구들 모임",
	'friends:addfriends' => "친구들을 추가",
	'friends:collectionname' => "모임 이름",
	'friends:collectionfriends' => "모임에 친구들",
	'friends:collectionedit' => "이 모임을 편집",
	'friends:nocollections' => "당신은 아직 어떤 모임들에 참여하고 있지 않습니다.",
	'friends:collectiondeleted' => "당신의 모임이 삭제되었습니다.",
	'friends:collectiondeletefailed' => "모임을 삭제할 수 없습니다. 권한이 없거나 다른 어떤 문제가 발생했습니다.",
	'friends:collectionadded' => "당신의 모임이 성공적으로 생성되었습니다.",
	'friends:nocollectionname' => "모임이 생성되기 전에 모임에 이름을 만들 필요가 있습니다.",
	'friends:collections:members' => "모임 멤버들",
	'friends:collections:edit' => "모임을 편집",
	'friends:collections:edited' => "저장된 모임",
	'friends:collection:edit_failed' => '모임을 저장할 수 없었습니다.',

	'friends:river:add' => "%s는 지금 ~와 친구입니다.",

	'friendspicker:chararray' => 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',

/**
 * Feeds
 */
	'feed:rss' => '피드에 Subscribe',
	'feed:odd' => '연합한(Syndicate) OpenDD',

/**
 * links
 **/

	'link:view' => '링크 보기',


/**
 * River
 */
	'river' => "River",
	'river:relationship:friend' => 'is now friends with',
	'river:noaccess' => '당신은 이 아이템을 볼 수 있는 권한을 가지고 있지 않습니다.',
	'river:posted:generic' => '%s는 포스트됨',
	'riveritem:single:user' => '한 사용자',
	'riveritem:plural:user' => '어떤 사용자들',

/**
 * Plugins
 */
	'plugins:settings:save:ok' => "%s 플러그인에 대한 설정들이 성공적으로 저장되었습니다.",
	'plugins:settings:save:fail' => "%s 플러그인에 대한 설정을 저장하는데 문제가 있었습니다.",
	'plugins:usersettings:save:ok' => "%s 플러그인에 대한 사용자 설정들이 성공적으로 저장되었습니다.",
	'plugins:usersettings:save:fail' => "%s 플러그인에 대한 사용자 설정을 저장하는데 문제가 있었습니다.",
	'admin:plugins:label:version' => "버전",
	'item:object:plugin' => '플러그인 구성 설정',

/**
 * Notifications
 */
	'notifications:usersettings' => "공지 설정",
	'notifications:methods' => "허용하고자 하는 방법을 지정해 주십시오.",

	'notifications:usersettings:save:ok' => "공지 설정이 성공적으로 저정되었습니다.",
	'notifications:usersettings:save:fail' => "공지 설정을 저장하는데 문제가 있었습니다.",

	'user.notification.get' => '지정된 사용자에 대한 공지설정을 반환합니다.',
	'user.notification.set' => '지정된 사용자에 대한 공지설정을 설정합니다.',
/**
 * Search
 */

	'search' => "검색",
	'searchtitle' => "검색:%s",
	'users:searchtitle' => "사용자들:%s에 대한 검색중",
	'groups:searchtitle' => "그룹:%s에 대한 검색 중",
	'advancedsearchtitle' => "%s를 일치하는 결과를 가진 %s",
	'notfound' => "어떤 결과도 찾을 수 없습니다.",
	'next' => "다음으로",
	'previous' => "이전으로",

	'viewtype:change' => "리스트 형식을 변경",
	'viewtype:list' => "리스트 뷰",
	'viewtype:gallery' => "갤러리",

	'tag:search:startblurb' => "'%s'를 일치하는 태그를 가진 아이템:",

	'user:search:startblurb' => "'%s'를 일치하는 사용자들:",
	'user:search:finishblurb' => "더 보기하려면, 여기를 클릭.",

	'group:search:startblurb' => "'%s'를 일치하는 그룹:",
	'group:search:finishblurb' => "더 보기하려면, 여기를 클릭.",
	'search:go' => '가기',
	'userpicker:only_friends' => '친구들만',

/**
 * Account
 */

	'account' => "계정",
	'settings' => "설정",
	'tools' => "도구들",
	'tools:yours' => "당신의 도구들",

	'register' => "등록",
	'registerok' => "%s에 대해서 성공적으로 등록되었습니다.",
	'registerbad' => "등록에 성공했습니다. 사용자 이름이 이미 존재합니다. 패스워드가 일치하지 않습니다. 혹은 사용자 이름이나 패스워드가 너무 짧습니다.",
	'registerdisabled' => "등록이 시스템 관리자에 의해서 비활성화 되었습니다.",

	'firstadminlogininstructions' => '새로운 Elgg 사이트가 성공적으로 설치되었습니다. 그리고 관리자 계정이 생성되었습니다. 지금 설치되어 있는 다양한 플러그인 도구들을 활성화 함으로써 좀 더 사이트를 조정할 수 있습니다.',

	'registration:notemail' => '당신이 제공한 이메일 주소가 유효한 이메일 주소에 나타나지 않습니다.',
	'registration:userexists' => '사용자 이름이 이미 존재합니다.',
	'registration:usernametooshort' => '사용자 이름은 최소 4(영어로 4자, 한글로 2자)자이어자 합니다.',
	'registration:passwordtooshort' => '패스워드는 최소 6자 이어야 합니다.',
	'registration:dupeemail' => '이 이메일 주소는 이미 등록되어 있습니다.',
	'registration:invalidchars' => '미안합니다. 당신의 사용자 이름은 옆에 있는 것과 같이 의미없는 문자를 포함하고 있습니다.:%S',
	'registration:emailnotvalid' => '미안합니다. 입력한 이메일 주소가 없습니다.',
	'registration:passwordnotvalid' => '미안합니다. 입력한 패스워드가 없습니다.',
	'registration:usernamenotvalid' => '미안합니다. 입력한 사용자 이름은 없습니다.',

	'adduser' => "사용자 추가",
	'adduser:ok' => "새로운 사용자를 추가하는데 성공했습니다.",
	'adduser:bad' => "새로운 사용자를 만들 수 없습니다.",

	'item:object:reported_content' => "기록된 항목들",

	'user:set:name' => "계정 이름 설정",
	'user:name:label' => "당신의 이름",
	'user:name:success' => "당신의 이름이 성공적으로 바뀌었습니다.",
	'user:name:fail' => "당신의 이름을 바꿀 수 없습니다. 이름이 너무 길지 않은지 확인하고 다시 시도해 보세요.",

	'user:set:password' => "계정 패스워드",
	'user:current_password:label' => '현재의 패스워드',
	'user:password:label' => "새로운 패스워드",
	'user:password2:label' => "새로운 패스어드 재확인",
	'user:password:success' => "패스워드 변경됨",
	'user:password:fail' => "패스워드를 변경할 수 없습니다.",
	'user:password:fail:notsame' => "패스워드가 일치하지 않습니다!",
	'user:password:fail:tooshort' => "패스워드가 너무 짧습니다!",
	'user:password:fail:incorrect_current_password' => '입력한 패스워드가 틀립니다.',
	'user:resetpassword:unknown_user' => '의미없는 사용자.',
	'user:resetpassword:reset_password_confirm' => '패스워드를 재설정하기 위해서 당신의 이메일 주소로 새로운 패스워드를 보낼 것입니다.',

	'user:set:language' => "언어 설정",
	'user:language:label' => "당신의 언어",
	'user:language:success' => "언어 설정이 업데이트 되었습니다.",
	'user:language:fail' => "언어 설정을 저장할 수 없었습니다. ",

	'user:username:notfound' => '사용자 이름 %s는 찾을 수 없습니다.',

	'user:password:lost' => '패스워드가 기억안남',
	'user:password:resetreq:success' => '새로운 패스워드를 성공적으로 요청하고, 이메일이 보내졌습니다.',
	'user:password:resetreq:fail' => '새로운 패스워드를 요청할 수 없었습니다.',

	'user:password:text' => '새로운 패스워드를 생성하기 위해서, 아래 당신의 이름을 입력하세요. 이메일로 당신에 확인을 위한 페이지가 보내질 것입니다. 메시지의 링크를 클릭하세요. 새로운 패스워드가 당신에 보내질 것입니다.',

	'user:persistent' => '내 정보를 저장(Remember me)',
/**
 * Administration
 */

	'admin:configuration:success' => "당신의 설정이 저장되었습니다.",
	'admin:configuration:fail' => "당신의 설정이 저장됮 않았습니다.",

	'admin' => "관리자",
	'admin:description' => "관리 패널은 당신이 시스템의 모든 면, 사용자 관리에서 부터 플러그인들이 동작하는 방법까지,을 제어하도록 허가합니다. 아래 옵션을 선택해서 시작하십시오.",

	'admin:user' => "사용자 관리자",
	'admin:user:description' => "이 관리 패널은 당신의 사이트에 사용자 설정을 제어하도록 합니다. 아래 옵션을 선택해서 시작하십시오.",
	'admin:user:adduser:label' => "새로운 사용자...를 추가하기 위해서 여기를 클릭하세요.",
	'admin:user:opt:linktext' => "사용자를 구성...",
	'admin:user:opt:description' => "사용자 및 계정 정보를 구성합니다.",

	'admin:site' => "사이트 관리",
	'admin:site:description' => "이 관리 패널은 여러분의 사이트에 대한 전역설정을 제어할 수 있도록 해 줍니다. 시작하려면 아래 옵션을 선택하세요.",
	'admin:site:opt:linktext' => "사이트를 구성...",
	'admin:site:opt:description' => "기술적, 비 기술적인 설정들을 사이트에 구성",
	'admin:site:access:warning' => "접근 설정을 변경하는 것은 나중에 만들어지는 컨텐트에 대한 권한에만 영향을 미치게 됩니다.",

	'admin:plugins' => "도구 관리",
	'admin:plugins:description' => "이 관리 패널은 여러분의 사이트에 설치되어 있는 도구들은 제어하고 구성하도록 해 줍니다.",
	'admin:plugins:opt:linktext' => "도구들을 구성...",
	'admin:plugins:opt:description' => "사이트에 설치되어 있는 도구들을 구성. ",
	'admin:plugins:label:author' => "저자",
	'admin:plugins:label:copyright' => "저작권",
	'admin:plugins:label:licence' => "라이센스",
	'admin:plugins:label:website' => "URL",
	'admin:plugins:label:moreinfo' => '더 많은 정보 보기',
	'admin:plugins:label:version' => '버전',
	'admin:plugins:warning:elggversionunknown' => '경고: 이 플러그인은 호환되는 Elgg 버전을 지정하지 않았습니다.',
	'admin:plugins:warning:elggtoolow' => '경고: 이 플러그 인은 Elgg의 나중 버전을 요구합니다!',
	'admin:plugins:reorder:yes' => "플러그인 %s 는 성공적으로 복구되었습니다. .",
	'admin:plugins:reorder:no' => "플러그인 %s 는 복구할 수 없습니다.",
	'admin:plugins:disable:yes' => "플러그인 %s 는 성공적으로 비활성회 되었습니다.",
	'admin:plugins:disable:no' => "플러그인 %s 비활성화 될 수 없었습니다.",
	'admin:plugins:enable:yes' => "플러그인 %s 성공적으로 활성화 되었습니다. ",
	'admin:plugins:enable:no' => "플러그인 %s 활성화 될 수 없었습니다.",

	'admin:statistics' => "통계",
	'admin:statistics:description' => "이것은 당신의 사이트에 대한 통계 개요입니다. 좀더 자세한 통계가 필요하다면, 전문적인 관리 기능을 사용할 수 있습니다.",
	'admin:statistics:opt:description' => "당신의 사이트에 대한 사용자와 객체에 관한 통계 정보를 볼 수 있습니다.",
	'admin:statistics:opt:linktext' => "통계를 보기...",
	'admin:statistics:label:basic' => "기초적인 사이트 통계",
	'admin:statistics:label:numentities' => "사이트에 관한 엔티티",
	'admin:statistics:label:numusers' => "사용자의 수",
	'admin:statistics:label:numonline' => "온라인 상에 있는 사용자의 수",
	'admin:statistics:label:onlineusers' => "현재 온라인 사용자",
	'admin:statistics:label:version' => "Elgg 버전",
	'admin:statistics:label:version:release' => "릴리즈",
	'admin:statistics:label:version:version' => "버전",

	'admin:user:label:search' => "사용자를 찾기:",
	'admin:user:label:searchbutton' => "검색",

	'admin:user:ban:no' => "사용자를 금지할 수 없습니다.",
	'admin:user:ban:yes' => "사용자 금지.",
	'admin:user:unban:no' => "사용자를 금지할 수 있습니다",
	'admin:user:unban:yes' => "사용자 금지 취소.",
	'admin:user:delete:no' => "사용자를 삭제할 수 없습니다.",
	'admin:user:delete:yes' => "사용자 %s 삭제될 수 없습니다. ",

	'admin:user:resetpassword:yes' => "패스워드 재설정, 사용자 통보.",
	'admin:user:resetpassword:no' => "패스워드를 재설정 할 수 없습니다.",

	'admin:user:makeadmin:yes' => "사용자가 현재 관리자 입니다.",
	'admin:user:makeadmin:no' => "이 사용자를 관리자로 만들 수 없습니다.",

	'admin:user:removeadmin:yes' => "사용자는 더이상 관리자가 아닙니다.",
	'admin:user:removeadmin:no' => "이 사용자로 부터 관리자 권한을 제거할 수 없습니다.",

/**
 * User settings
 */
	'usersettings:description' => "The user settings panel allows you to control all your personal settings, from user management to how plugins behave. Choose an option below to get started.",

	'usersettings:statistics' => "Your statistics",
	'usersettings:statistics:opt:description' => "View statistical information about users and objects on your site.",
	'usersettings:statistics:opt:linktext' => "Account statistics",

	'usersettings:user' => "Your settings",
	'usersettings:user:opt:description' => "This allows you to control user settings.",
	'usersettings:user:opt:linktext' => "Change your settings",

	'usersettings:plugins' => "Tools",
	'usersettings:plugins:opt:description' => "Configure settings (if any) for your active tools.",
	'usersettings:plugins:opt:linktext' => "Configure your tools",

	'usersettings:plugins:description' => "This panel allows you to control and configure the personal settings for the tools installed by your system administrator.",
	'usersettings:statistics:label:numentities' => "Your content",

	'usersettings:statistics:yourdetails' => "Your details",
	'usersettings:statistics:label:name' => "Full name",
	'usersettings:statistics:label:email' => "Email",
	'usersettings:statistics:label:membersince' => "Member since",
	'usersettings:statistics:label:lastlogin' => "Last logged in",



/**
 * Generic action words
 */

	'save' => "Save",
	'publish' => "Publish",
	'cancel' => "Cancel",
	'saving' => "Saving ...",
	'update' => "Update",
	'edit' => "Edit",
	'delete' => "Delete",
	'accept' => "Accept",
	'load' => "Load",
	'upload' => "Upload",
	'ban' => "Ban",
	'unban' => "Unban",
	'enable' => "Enable",
	'disable' => "Disable",
	'request' => "Request",
	'complete' => "Complete",
	'open' => 'Open',
	'close' => 'Close',
	'reply' => "Reply",
	'more' => 'More',
	'comments' => 'Comments',
	'import' => 'Import',
	'export' => 'Export',
	'untitled' => 'Untitled',
	'help' => 'Help',
	'send' => 'Send',
	'post' => 'Post',
	'submit' => 'Submit',
	'site' => 'Site',

	'up' => 'Up',
	'down' => 'Down',
	'top' => 'Top',
	'bottom' => 'Bottom',

	'invite' => "Invite",

	'resetpassword' => "Reset password",
	'makeadmin' => "Make admin",
	'removeadmin' => "Remove admin",

	'option:yes' => "Yes",
	'option:no' => "No",

	'unknown' => 'Unknown',

	'active' => 'Active',
	'total' => 'Total',

	'learnmore' => "Click here to learn more.",

	'content' => "content",
	'content:latest' => 'Latest activity',
	'content:latest:blurb' => 'Alternatively, click here to view the latest content from across the site.',

	'link:text' => 'view link',

	'enableall' => 'Enable All',
	'disableall' => 'Disable All',

/**
 * Generic questions
 */

	'question:areyousure' => 'Are you sure?',

/**
 * Generic data words
 */

	'title' => "Title",
	'description' => "Description",
	'tags' => "Tags",
	'spotlight' => "Spotlight",
	'all' => "All",

	'by' => 'by',

	'annotations' => "Annotations",
	'relationships' => "Relationships",
	'metadata' => "Metadata",

/**
 * Input / output strings
 */

	'deleteconfirm' => "Are you sure you want to delete this item?",
	'fileexists' => "A file has already been uploaded. To replace it, select it below:",

/**
 * User add
 */

	'useradd:subject' => 'User account created',
	'useradd:body' => '
%s,

A user account has been created for you at %s. To log in, visit:

%s

And log in with these user credentials:

Username: %s
Password: %s

Once you have logged in, we highly recommend that you change your password.
',

/**
 * System messages
 **/

	'systemmessages:dismiss' => "click to dismiss",


/**
 * Import / export
 */
	'importsuccess' => "Import of data was successful",
	'importfail' => "OpenDD import of data failed.",

/**
 * Time
 */

	'friendlytime:justnow' => "just now",
	'friendlytime:minutes' => "%s minutes ago",
	'friendlytime:minutes:singular' => "a minute ago",
	'friendlytime:hours' => "%s hours ago",
	'friendlytime:hours:singular' => "an hour ago",
	'friendlytime:days' => "%s days ago",
	'friendlytime:days:singular' => "yesterday",
	'friendlytime:date_format' => 'j F Y @ g:ia',

	'date:month:01' => 'January %s',
	'date:month:02' => 'February %s',
	'date:month:03' => 'March %s',
	'date:month:04' => 'April %s',
	'date:month:05' => 'May %s',
	'date:month:06' => 'June %s',
	'date:month:07' => 'July %s',
	'date:month:08' => 'August %s',
	'date:month:09' => 'September %s',
	'date:month:10' => 'October %s',
	'date:month:11' => 'November %s',
	'date:month:12' => 'December %s',


/**
 * Installation and system settings
 */

	'installation:error:htaccess' => "Elgg requires a file called .htaccess to be set in the root directory of its installation. We tried to create it for you, but Elgg doesn't have permission to write to that directory.

Creating this is easy. Copy the contents of the textbox below into a text editor and save it as .htaccess

",
	'installation:error:settings' => "Elgg couldn't find its settings file. Most of Elgg's settings will be handled for you, but we need you to supply your database details. To do this:

1. Rename engine/settings.example.php to settings.php in your Elgg installation.

2. Open it with a text editor and enter your MySQL database details. If you don't know these, ask your system administrator or technical support for help.

Alternatively, you can enter your database settings below and we will try and do this for you...",

	'installation:error:db:title' => "Database settings error",
	'installation:error:db:text' => "Check your database settings again as Elgg could not connect and access the database.",
	'installation:error:configuration' => "Once you've corrected any configuration issues, press reload to try again.",

	'installation' => "Installation",
	'installation:success' => "Elgg's database was installed successfully.",
	'installation:configuration:success' => "Your initial configuration settings have been saved. Now register your initial user; this will be your first system administrator.",

	'installation:settings' => "System settings",
	'installation:settings:description' => "Now that the Elgg database has been successfully installed, you need to enter a couple of pieces of information to get your site fully up and running. We've tried to guess where we could, but <b>you should check these details.</b>",

	'installation:settings:dbwizard:prompt' => "Enter your database settings below and hit save:",
	'installation:settings:dbwizard:label:user' => "Database user",
	'installation:settings:dbwizard:label:pass' => "Database password",
	'installation:settings:dbwizard:label:dbname' => "Elgg database",
	'installation:settings:dbwizard:label:host' => "Database hostname (usually 'localhost')",
	'installation:settings:dbwizard:label:prefix' => "Database table prefix (usually 'elgg_')",

	'installation:settings:dbwizard:savefail' => "We were unable to save the new settings.php. Please save the following file as engine/settings.php using a text editor.",

	'installation:sitename' => "The name of your site (eg \"My social networking site\"):",
	'installation:sitedescription' => "Short description of your site (optional)",
	'installation:wwwroot' => "The site URL, followed by a trailing slash:",
	'installation:path' => "The full path to your site root on your disk, followed by a trailing slash:",
	'installation:dataroot' => "The full path to the directory where uploaded files will be stored, followed by a trailing slash:",
	'installation:dataroot:warning' => "You must create this directory manually. It should sit in a different directory to your Elgg installation.",
	'installation:sitepermissions' => "The default access permissions:",
	'installation:language' => "The default language for your site:",
	'installation:debug' => "Debug mode provides extra information which can be used to diagnose faults. However, it can slow your system down so should only be used if you are having problems:",
	'installation:debug:none' => 'Turn off debug mode (recommended)',
	'installation:debug:error' => 'Display only critical errors',
	'installation:debug:warning' => 'Display errors and warnings',
	'installation:debug:notice' => 'Log all errors, warnings and notices',
	'installation:httpslogin' => "Enable this to have user logins performed over HTTPS. You will need to have https enabled on your server for this to work.",
	'installation:httpslogin:label' => "Enable HTTPS logins",
	'installation:view' => "Enter the view which will be used as the default for your site or leave this blank for the default view (if in doubt, leave as default):",

	'installation:siteemail' => "Site email address (used when sending system emails)",

	'installation:disableapi' => "The RESTful API is a flexible and extensible interface that enables applications to use certain Elgg features remotely.",
	'installation:disableapi:label' => "Enable the RESTful API",

	'installation:allow_user_default_access:description' => "If checked, individual users will be allowed to set their own default access level that can over-ride the system default access level.",
	'installation:allow_user_default_access:label' => "Allow user default access",

	'installation:simplecache:description' => "The simple cache increases performance by caching static content including some CSS and JavaScript files. Normally you will want this on.",
	'installation:simplecache:label' => "Use simple cache (recommended)",

	'installation:viewpathcache:description' => "The view filepath cache decreases the loading times of plugins by caching the location of their views.",
	'installation:viewpathcache:label' => "Use view filepath cache (recommended)",

	'upgrading' => 'Upgrading...',
	'upgrade:db' => 'Your database was upgraded.',
	'upgrade:core' => 'Your elgg installation was upgraded.',

/**
 * Welcome
 */

	'welcome' => "Welcome",
	'welcome:user' => 'Welcome %s',
	'welcome_message' => "Welcome to this Elgg installation.",

/**
 * Emails
 */
	'email:settings' => "Email settings",
	'email:address:label' => "Your email address",

	'email:save:success' => "New email address saved, verification requested.",
	'email:save:fail' => "Your new email address could not be saved.",

	'friend:newfriend:subject' => "%s has made you a friend!",
	'friend:newfriend:body' => "%s has made you a friend!

To view their profile, click here:

%s

You cannot reply to this email.",



	'email:resetpassword:subject' => "Password reset!",
	'email:resetpassword:body' => "Hi %s,

Your password has been reset to: %s",


	'email:resetreq:subject' => "Request for new password.",
	'email:resetreq:body' => "Hi %s,

Somebody (from the IP address %s) has requested a new password for their account.

If you requested this click on the link below, otherwise ignore this email.

%s
",

/**
 * user default access
 */

'default_access:settings' => "Your default access level",
'default_access:label' => "Default access",
'user:default_access:success' => "Your new default access level was saved.",
'user:default_access:failure' => "Your new default access level could not be saved.",

/**
 * XML-RPC
 */
	'xmlrpc:noinputdata'	=>	"Input data missing",

/**
 * Comments
 */

	'comments:count' => "%s comments",

	'riveraction:annotation:generic_comment' => '%s commented on %s',

	'generic_comments:add' => "Add a comment",
	'generic_comments:text' => "Comment",
	'generic_comment:posted' => "Your comment was successfully posted.",
	'generic_comment:deleted' => "Your comment was successfully deleted.",
	'generic_comment:blank' => "Sorry, you need to actually put something in your comment before we can save it.",
	'generic_comment:notfound' => "Sorry, we could not find the specified item.",
	'generic_comment:notdeleted' => "Sorry, we could not delete this comment.",
	'generic_comment:failure' => "An unexpected error occurred when adding your comment. Please try again.",

	'generic_comment:email:subject' => 'You have a new comment!',
	'generic_comment:email:body' => "You have a new comment on your item \"%s\" from %s. It reads:


%s


To reply or view the original item, click here:

%s

To view %s's profile, click here:

%s

You cannot reply to this email.",

/**
 * Entities
 */
	'entity:default:strapline' => 'Created %s by %s',
	'entity:default:missingsupport:popup' => 'This entity cannot be displayed correctly. This may be because it requires support provided by a plugin that is no longer installed.',

	'entity:delete:success' => 'Entity %s has been deleted',
	'entity:delete:fail' => 'Entity %s could not be deleted',


/**
 * Action gatekeeper
 */
	'actiongatekeeper:missingfields' => 'Form is missing __token or __ts fields',
	'actiongatekeeper:tokeninvalid' => "We encountered an error (token mismatch). This probably means that the page you were using expired. Please try again.",
	'actiongatekeeper:timeerror' => 'The page you were using has expired. Please refresh and try again.',
	'actiongatekeeper:pluginprevents' => 'A extension has prevented this form from being submitted.',

/**
 * Word blacklists
 */
	'word:blacklist' => 'and, the, then, but, she, his, her, him, one, not, also, about, now, hence, however, still, likewise, otherwise, therefore, conversely, rather, consequently, furthermore, nevertheless, instead, meanwhile, accordingly, this, seems, what, whom, whose, whoever, whomever',

/**
 * Tag labels
 */

	'tag_names:tags' => 'Tags',

/**
 * Languages according to ISO 639-1
 */
	"aa" => "Afar",
	"ab" => "Abkhazian",
	"af" => "Afrikaans",
	"am" => "Amharic",
	"ar" => "Arabic",
	"as" => "Assamese",
	"ay" => "Aymara",
	"az" => "Azerbaijani",
	"ba" => "Bashkir",
	"be" => "Byelorussian",
	"bg" => "Bulgarian",
	"bh" => "Bihari",
	"bi" => "Bislama",
	"bn" => "Bengali; Bangla",
	"bo" => "Tibetan",
	"br" => "Breton",
	"ca" => "Catalan",
	"co" => "Corsican",
	"cs" => "Czech",
	"cy" => "Welsh",
	"da" => "Danish",
	"de" => "German",
	"dz" => "Bhutani",
	"el" => "Greek",
	"en" => "English",
	"eo" => "Esperanto",
	"es" => "Spanish",
	"et" => "Estonian",
	"eu" => "Basque",
	"fa" => "Persian",
	"fi" => "Finnish",
	"fj" => "Fiji",
	"fo" => "Faeroese",
	"fr" => "French",
	"fy" => "Frisian",
	"ga" => "Irish",
	"gd" => "Scots / Gaelic",
	"gl" => "Galician",
	"gn" => "Guarani",
	"gu" => "Gujarati",
	"he" => "Hebrew",
	"ha" => "Hausa",
	"hi" => "Hindi",
	"hr" => "Croatian",
	"hu" => "Hungarian",
	"hy" => "Armenian",
	"ia" => "Interlingua",
	"id" => "Indonesian",
	"ie" => "Interlingue",
	"ik" => "Inupiak",
	//"in" => "Indonesian",
	"is" => "Icelandic",
	"it" => "Italian",
	"iu" => "Inuktitut",
	"iw" => "Hebrew (obsolete)",
	"ja" => "Japanese",
	"ji" => "Yiddish (obsolete)",
	"jw" => "Javanese",
	"ka" => "Georgian",
	"kk" => "Kazakh",
	"kl" => "Greenlandic",
	"km" => "Cambodian",
	"kn" => "Kannada",
	"ko" => "Korean",
	"ks" => "Kashmiri",
	"ku" => "Kurdish",
	"ky" => "Kirghiz",
	"la" => "Latin",
	"ln" => "Lingala",
	"lo" => "Laothian",
	"lt" => "Lithuanian",
	"lv" => "Latvian/Lettish",
	"mg" => "Malagasy",
	"mi" => "Maori",
	"mk" => "Macedonian",
	"ml" => "Malayalam",
	"mn" => "Mongolian",
	"mo" => "Moldavian",
	"mr" => "Marathi",
	"ms" => "Malay",
	"mt" => "Maltese",
	"my" => "Burmese",
	"na" => "Nauru",
	"ne" => "Nepali",
	"nl" => "Dutch",
	"no" => "Norwegian",
	"oc" => "Occitan",
	"om" => "(Afan) Oromo",
	"or" => "Oriya",
	"pa" => "Punjabi",
	"pl" => "Polish",
	"ps" => "Pashto / Pushto",
	"pt" => "Portuguese",
	"qu" => "Quechua",
	"rm" => "Rhaeto-Romance",
	"rn" => "Kirundi",
	"ro" => "Romanian",
	"ru" => "Russian",
	"rw" => "Kinyarwanda",
	"sa" => "Sanskrit",
	"sd" => "Sindhi",
	"sg" => "Sangro",
	"sh" => "Serbo-Croatian",
	"si" => "Singhalese",
	"sk" => "Slovak",
	"sl" => "Slovenian",
	"sm" => "Samoan",
	"sn" => "Shona",
	"so" => "Somali",
	"sq" => "Albanian",
	"sr" => "Serbian",
	"ss" => "Siswati",
	"st" => "Sesotho",
	"su" => "Sundanese",
	"sv" => "Swedish",
	"sw" => "Swahili",
	"ta" => "Tamil",
	"te" => "Tegulu",
	"tg" => "Tajik",
	"th" => "Thai",
	"ti" => "Tigrinya",
	"tk" => "Turkmen",
	"tl" => "Tagalog",
	"tn" => "Setswana",
	"to" => "Tonga",
	"tr" => "Turkish",
	"ts" => "Tsonga",
	"tt" => "Tatar",
	"tw" => "Twi",
	"ug" => "Uigur",
	"uk" => "Ukrainian",
	"ur" => "Urdu",
	"uz" => "Uzbek",
	"vi" => "Vietnamese",
	"vo" => "Volapuk",
	"wo" => "Wolof",
	"xh" => "Xhosa",
	//"y" => "Yiddish",
	"yi" => "Yiddish",
	"yo" => "Yoruba",
	"za" => "Zuang",
	"zh" => "Chinese",
	"zu" => "Zulu",
);

add_translation("en",$english);
