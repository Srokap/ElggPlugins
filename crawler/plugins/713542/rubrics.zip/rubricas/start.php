<?php
/*******************************************************************************
 * rubricas
 *
 * @author jctorrecilla
 ******************************************************************************/

/**************
* Submenu del administrador
***************/

        function rubricas_init()
        {
                global $CONFIG;

                elgg_extend_view('css', 'style'); 

				// Añadir el menu del administrador
                if (isadminloggedin()) 
                {

                  register_page_handler('rubrics','rubricas_page_handler');

                  add_menu(elgg_echo('rubricas:rubrics'), $CONFIG->wwwroot . 'pg/rubrics/listado/');

                  register_elgg_event_handler('pagesetup','system','rubricas_submenus');
                  
                }
                // Submenú del usuario
                else
                {
                	register_elgg_event_handler('pagesetup','system','rubricas_submenus_usuario');
                	add_menu(elgg_echo('rubricas:rubrics'), $CONFIG->wwwroot . 'pg/rubrics/listado/');
                	register_page_handler('rubrics','rubricas_page_handler');
                }
                
                // Registrar acciones
                register_action("rubrics/guardar", false, $CONFIG->pluginspath . "rubricas/actions/guardar.php");

                register_action("rubrics/borrar", false, $CONFIG->pluginspath . "rubricas/actions/borrar.php");

                register_action("rubrics/editar", false, $CONFIG->pluginspath . "rubricas/actions/editar.php");
                
                register_action("rubrics/editar_nueva", false, $CONFIG->pluginspath . "rubricas/actions/editar_nueva.php");
                
                register_action('rubrics/import', false, $CONFIG->pluginspath . "rubricas/actions/importar.php");

				register_action('rubrics/calificar', false, $CONFIG->pluginspath . "rubricas/actions/calificar.php");
				
                return true;
        }

/**************
* Controladores de página
***************/

        function rubricas_page_handler($page)
        {
                global $CONFIG;

                switch ($page[0])
                {
                        case 'listado':
                                include $CONFIG->pluginspath . 'rubricas/pages/listado.php';
                                break;
                        case 'crear':
                                include $CONFIG->pluginspath . 'rubricas/pages/crear.php';
                                break;     
                        case 'editar':
                                include $CONFIG->pluginspath . 'rubricas/pages/editar.php';
                                break;                   
                }

                return true;
        }

/**************
* Submenu del administrador
***************/
        function rubricas_submenus()
        {
                global $CONFIG;

				
                if (get_context() == 'rubrics')
                {
                        add_submenu_item(elgg_echo('rubricas:menulistado'), $CONFIG->wwwroot . 'pg/rubrics/listado/');
                        add_submenu_item(elgg_echo('rubricas:menucrear'), $CONFIG->wwwroot . 'pg/rubrics/crear/');
                }

        }

        function rubricas_submenus_usuario()
        {
                global $CONFIG;

				
                if (get_context() == 'rubrics')
                {
                        add_submenu_item(elgg_echo('rubricas:menulistado'), $CONFIG->wwwroot . 'pg/rubrics/listado/');
                }

        }
/**************
* Registrar controlador de eventos
***************/    
		// Al inicio del sistema se ejecuta la funcion de inicialización del plugin    
        register_elgg_event_handler('init', 'system', 'rubricas_init');
        
?>
