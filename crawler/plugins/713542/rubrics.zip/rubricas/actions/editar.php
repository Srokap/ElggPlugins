<?php

/*
* rubricas/actions/editar
* Editar una rúbrica
*
* @package ElggRubric
*/

	  // Solo usuarios registrados
	  gatekeeper();
	
	  // Coger datos
	  $guid = (int) get_input('rubrica');
	  $arr = $_POST[puntos];
	  $ar1 = $_POST[criterio];
	  $ar2 = $_POST[desc];
	  $filas = $_POST[filas];
	  $cols = $_POST[cols];
	  $title = $_POST[titulo];
	  $pd = $_POST[pdesc];
	  $cd = $_POST[cdesc];
	
	  // Crear una nueva rubrica
	  $rubrica = get_entity($guid);
	  $rubrica->title = $title;
	  $rubrica->description = $ar2;
	  $rubrica->subtype = "rubrica";
	
	  // Premiso
	  $rubrica->access_id = $_POST[access_id];
	
	  // El propietario es el usuario registrado
	  $rubrica->owner_guid = get_loggedin_userid();
	
	  // Almacenar la rubrica antes de almacenar sus metadatos
	  if (!$rubrica->save()) 
	  {
	        register_error(elgg_echo("Error al salvar la rubrica"));
	        forward("mod/rubrica/views/default/editar.php?rubrica=" . $guid);
	  }
	  
	  // Limpiar metadatos
	  $rubrica->clearMetadata('puntos');
	  $rubrica->clearMetadata('criterio');
	  $rubrica->clearMetadata('desc');
	  $rubrica->clearMetadata('filas');
	  $rubrica->clearMetadata('cols');
	  $rubrica->clearMetadata('etiquetas');
	  $rubrica->clearMetadata('pdesc');
	  $rubrica->clearMetadata('cdesc');
	  
	  // Almacenar los arrays en una cadena para que queden ordenados
	  foreach ($arr as $a)
	   $p .= $a . "#";
	  foreach ($ar1 as $b)
	   $ac .= $b . "#";
	  foreach ($ar2 as $c)
	   $ad .= $c . "#";
	  foreach ($pd as $d)
	   $apd .= $d . "#";
	  foreach ($cd as $e)
	   $acd .= $e . "#";
	   
	   // Guardar metadatos
	   $rubrica->puntos = $p;
	
	   $rubrica->criterio = $ac;
	
	   $rubrica->desc = $ad;
	
	   $rubrica->filas = $filas;
	
	   $rubrica->cols = $cols;
	   
	   $rubrica->pdesc = $apd;
	   
	   $rubrica->cdesc = $acd;
	
		$tags = explode(',',$_POST[tags]);
		
	    $rubrica->tags = $tags;
	   
	  // Mensaje de exito
	  system_message(elgg_echo("Se han almacenado los cambios"));
	  
	  // Redirigir al listado de rubricas
	  forward($CONFIG->wwwroot . 'pg/rubrics/listado/');

?>
