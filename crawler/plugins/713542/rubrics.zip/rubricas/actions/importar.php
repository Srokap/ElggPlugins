<?php

/*
* rubricas/actions/importar
* Permite importar una r�brica
*
* @package ElggRubric
*/


	include_once dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php";
	
	
	if ((strpos($_FILES['data']['type'] , "csv") != false) || (strpos($_FILES['data']['type'] , "excel") != false))
	{
		$i = 0;
		$rubrica = new ElggObject();
	
		$fp = fopen ($_FILES['data']['tmp_name'],'r');
		
		if ($fp)
		{
			while ($data = fgetcsv($fp, 1000, ";"))
			{
				$j = 0;
	
				foreach ($data as $d)
				{
					if ($d != "")
					{
						// Titulo de la rubrica
						if (($i == 0) & ($j == 0))
						{
							$rubrica->title = $d;
						} 
						else 
						{
							// Puntos
							if ( $i == 0 )
							{
								$pd .= $d . "#";
							}
							else
							{
								if ( $i == 1 ) 
								{
									$puntos .= $d . "#";
								}
									else 
									{	
									// Criterio
									if ( ($j == 0) & ($i%2 == 0) )
									{
										$criterio .= $d . "#";
									}
									else
									{
										if ( ($j== 0) & ($i%2!=0) )
										{
											$cd .= $d . "#";
										}
										// Descripcion
										else 
										{
												$descripcion .= $d . "#";									
										}
									}
								}
							}		
						} // END IF
						
						$j++;
						
					} // END FOREACH
	
				} // End while
				
				$i++;
	
			} // End if 
	
			$rubrica->filas = ($i / 2);
			$rubrica->cols = $j;
			$rubrica->puntos = $puntos;
			$rubrica->desc = $descripcion;
			$rubrica->criterio = $criterio;
			$rubrica->cdesc = $cd;
			$rubrica->pdesc = $pd;
			$rubrica->subtype = "rubrica";
	
			fclose ($fp);
			
			$guid = $rubrica->save();
			system_message(elgg_echo("La r&uacute;brica se ha guardado"));
			forward($CONFIG->wwwroot . 'mod/rubricas/pages/editar.php?rubrica='.$guid);
		}
		else
		{
			register_error(elgg_echo("Error al leer el fichero"));
			forward($CONFIG->wwwroot . 'mod/rubricas/pages/importar.php');		
		}

	}
	else
	{
		register_error(elgg_echo("Tipo de fichero incorrecto"));
		forward($CONFIG->wwwroot . 'mod/rubricas/pages/importar.php');
	}


?>
