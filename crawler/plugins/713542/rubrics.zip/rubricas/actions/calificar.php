<?php

	/**
	 * rubricas/actions/calificar
	 * Almacena una entidad calificacion
	 *
	 * Coge los siguiente parámetros por POST: 
	 * 
	 * - envio: guid de la actividad a la que se asocia la calificacion
	 * - act: GUID de la rubrica / 0 si es nota numerica
	 * - url: URL de la rediccion
	 * - peso: El peso de la actividad
	 * - visb: Visibilidad (true/false)
	 *
	 * Los siguientes datos son pasados por la vista "Evaluar":
	 * - nota: La nota numerica 
	 * - max: Puntuacion maxima (Ejemplo: Sería 7 en una nota 5/7)
	 * - numerica: Nota total calculada dependiendo de los puntos de la rubrica
	 * - nota: Listado de filas y columnas separados por # que marcan la puntuacion de la rubrica
	 * - total: Puntuacion maxima de la rubrica
	 * 
	 * Entidad CALIFICACION
	 * - GUID 
	 * - Subtype: calificacion
	 * - owner_guid: guid del usuario que califica
	 * METADATOS
	 * - guid_actividad: GUID de la entidad a la que se asocia la calificación
	 * - Tipo: rubrica o numerica
	 * - nota: Un número para nota numérica y una lista tipo 11#24#31 para una rubrica
	 * - Peso
	 * - Total: número. 
	 * - Porcentaje: Tanto por cien de la nota total
	 * - visible: true/false
	 * - user_guid: GUID del usuario evaluado
	 * - numérica: Cálculo de la puntuación obtenida en la rúbrica
	 *
	 * @package ElggRubric
	 */


	// Solo usuarios registrados pueden almacenar una calificacion
	gatekeeper();
	
	require_once($CONFIG->pluginspath . "/rubricas/lib/assess_functions.php");
	
	// guid del envio
	$e = $_POST[envio];
	
	// guid de la rubrica
	$a = $_POST[act];
	
	// url para redirección
	$url = $_POST[url];
	
	if ( $e != "" )
	{	
		$calificacion = get_assessment ( $e );
		
		if (!$calificacion )
		{
			$calificacion = new ElggObject();
			$calificacion->subtype = 'calificacion';
		}
		
		$calificacion->guid_actividad  = $e;
		$calificacion->clearMetadata('tipo');  
			
		// Nota numerica 
		if ($a == '0')
		{
			$calificacion->clearMetadata('nota');  
			$calificacion->clearMetadata('total');  
			$calificacion->clearMetadata('porcentaje');  
			$calificacion->tipo = 'numerica';
			$calificacion->nota = $_POST[nota];
			$calificacion->total = $_POST[max];	
			$calificacion->porcentaje = round((($_POST[nota] * 100) / $_POST[max])*100)/100;	
		}
		// Rubrica
		else
		{
			$calificacion->clearMetadata('numerica');  
			$calificacion->clearMetadata('nota');  
			$calificacion->clearMetadata('total');
			$calificacion->clearMetadata('porcentaje');  
			$calificacion->tipo = 'rubrica';
			$calificacion->numerica = $_POST[numerica];
			$calificacion->nota = $_POST[calificaciones];
			$calificacion->total = $_POST[maxpuntos];
			$calificacion->porcentaje = round((($_POST[numerica] * 100) / $_POST[maxpuntos])*100)/100;	
		}
		
		$calificacion->clearMetadata('peso');  
		$calificacion->peso = $_POST[peso];
		
		$calificacion->visible = $_POST[visb];
		
		$calificacion->owner_guid = get_loggedin_userid();
		$calificacion->access_id = 2;
		
		// Guardar en la base de datos
		if ($calificacion->save()) 
		{
			if ($url == "")
				$url = $CONFIG->wwwroot . "mod/rubricas/pages/listado.php";
			system_message(elgg_echo("rubricas:guardarok"));
			forward($url);
		}
		
	}
	else
	{
		register_error(elgg_echo('rubricas:failure'));
	  	// Redireccionar
	  	forward($url);
	}
?>