<?php

/*
* rubricas/actions/save
* Guarda una nueva r�brica
*
* @package ElggRubric
*/


	// Solo usuarios registrados pueden almacenar una rubrica
	gatekeeper();
	  
	global $CONFIG;
	
	// Guardar variables pasadas como par�metros
	$arr = $_POST[puntos];
	$ar1 = $_POST[criterio];
	$ar2 = $_POST[desc];
	$filas = $_POST[filas];
	$cols = $_POST[cols];
	$title = $_POST[titulo];
	$cdesc = $_POST[cdesc];
	$pdesc = $_POST[pdesc];
	
	// Crear un nuevo objeto
	$rubrica = new ElggObject();
	$rubrica->title = $title;
	$rubrica->description = $ar2;
	$rubrica->subtype = 'rubrica';
	
	// Permisos
	$rubrica->access_id = $_POST[access_id];
	
	// El propietario es el usuario registrado
	$rubrica->owner_guid = get_loggedin_userid();
	
	// Almacenar valores como string para que queden ordenados
	foreach ($arr as $a)
	   $p .= $a . "#";
	foreach ($ar1 as $b)
	   $ac .= $b . "#";
	foreach ($ar2 as $c)
	   $ad .= $c . "#";
	foreach ($cdesc as $d)
	   $cd .= $d . "#";  
	foreach ($pdesc as $e)
	   $pd .= $e . "#";
	   
	// Almacenar valores como metadatos
	$rubrica->puntos = $p;
	$rubrica->criterio = $ac;
	$rubrica->desc = $ad;
	$rubrica->filas = $filas;
	$rubrica->cols = $cols;
	$rubrica->cdesc = $cd;
	$rubrica->pdesc = $pd;
	  
	$tags = explode(',',$_POST[tags]);
	$rubrica->tags = $tags;
	
	// Guardar en la BD
	if ($rubrica->save()) 
	  	system_message(elgg_echo("La r&uacute;brica se ha guardado"));
	
	// Redireccionar al usuario al listado de r�bricas
	forward($CONFIG->wwwroot . 'pg/rubrics/listado/');
	
?>
