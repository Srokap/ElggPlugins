<?php
/*
* rubricas/actions/borrar
* Borrar una rubrica
*
* @package ElggRubric
*/

      // Solo usuarios registrados
      gatekeeper();

      // Recoger datos
      $guid = (int) get_input('rubrica');

      // Si hay permisos de edicion
      $rubrica = get_entity($guid);
      
      if ($rubrica->getSubtype() == "rubrica" ) 
      {
      		// Coger el propietario
            $owner = get_entity($rubrica->getOwner());
            
      		// Borrar
            $rowsaffected = $rubrica->delete();
            
            if ($rowsaffected > 0) 
            {
      			// Mensaje de exito
               system_message(elgg_echo("La r&uacute;brica se ha eliminado"));
      		} 
      		else 
      		{
               register_error(elgg_echo("Ha ocurrido un error: la r&uacute;brica no se ha eliminado"));
      		}
      
		    // Redirigir al listado de rubricas
		    forward($CONFIG->wwwroot . 'pg/rubrics/listado/');
      }
      
?>