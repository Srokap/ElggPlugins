<?php
/*
* pages/editar
* Página para editar una rúbrica
*
* @package ElggRubric
*/

   // Incluye el nucleo de Elgg
   include_once dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php";
   
   // Solo el administrador
   admin_gatekeeper(); 
   
    // Coge al actual propietario de la página
    $page_owner = page_owner_entity();
    
    if (!$page_owner) 
    {
            $page_owner_guid = get_loggedin_userid();
            if ($page_owner_guid)
                   set_page_owner($page_owner_guid);
    }
       
   // Coge la rubrica pasada como parametro, si existe
   $rub = (int) get_input('rubrica');
   $rubrica = get_entity($rub);

   $area1 = elgg_view_title(elgg_echo('rubricas:editar_rubrica'));
   
   if (isset( $_POST[nueva]))
   		$area1 .= elgg_view("rubricas/editar_nueva", array('entity' => $rubrica));
   else
   		$area1 .= elgg_view("rubricas/editar", array('entity' => $rubrica));

   $body = elgg_view_layout("two_column_left_sidebar", "", $area1);

   // Visualizar la pagina
   page_draw($rubrica->title, $body);
   
?>