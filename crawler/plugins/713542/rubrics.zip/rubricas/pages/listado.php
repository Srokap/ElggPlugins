<?php

/*
* pages/listado
* Llama al objeto rubrica para mostrarlo (sin parametros)
*
* @package ElggRubric
*/

   // Incluye el nucleo de Elgg
   include_once dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php"; 

   // Solo usuarios registrados
   gatekeeper();

    // Coge al actual propietario de la página
    $page_owner = page_owner_entity();
    
    if (!$page_owner) 
    {
            $page_owner_guid = get_loggedin_userid();
            if ($page_owner_guid)
                   set_page_owner($page_owner_guid);
    }
    
   $title = elgg_echo('rubricas:pagetitle');
   
   // Crea el contenido de la columna principal
   $content = elgg_view_title($title);
   
   if ( isadminloggedin() )
   	$content .= list_entities('object', 'rubrica', get_loggedin_userid(), 10, true);
   else
   	$content .= list_entities('object', 'rubrica', 0, 10, true);
   	
   $content .= elgg_view("<br>");

   $body = elgg_view_layout('two_column_left_sidebar', '', $content);

   // Crear la pagina completa html y enviarla al buscador
   page_draw("Editar una r&uacute;brica", $body);
   
?>