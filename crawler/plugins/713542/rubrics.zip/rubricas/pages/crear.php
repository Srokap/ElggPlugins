<?php

/*
* pages/crear
* Llama al objeto rubrica para crearlo (sin parametros)
*
* @package ElggRubric
*/
	// Incluye el nucleo de elgg
    include_once dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php"; 
    
    // Pagina solo para administradores
    admin_gatekeeper();
    
     // Coge al actual propietario de la p�gina
    $page_owner = page_owner_entity();
    
    if (!$page_owner) 
    {
            $page_owner_guid = get_loggedin_userid();
            if ($page_owner_guid)
                   set_page_owner($page_owner_guid);
    }
    
    $title = elgg_echo('rubricas:pagetitle');

    // Crea el contenido de la columna principal
    $content = elgg_view_title($title);
    $content .= elgg_view("rubricas/crear");

    // Crea la barra de contenido
    $body = elgg_view_layout('two_column_left_sidebar', '', $content);

    // Crea la pagina completa html y la envia al navegador
    page_draw($title, $body);
    
?>
