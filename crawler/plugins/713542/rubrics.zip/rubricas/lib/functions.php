<?php
/*
* Funciones últiles para mostrar una rúbrica
*
* @package ElggRubric
*/
		/*
		* Crea la cabecera de la tabla de una rúbrica
		* (Botones de añadir, eliminar columna, ...)
		*/
		function create_table( $rubric, $url )
		{
			global $CONFIG;

			$toRet = "<table border=\"5px\" id=\"main-content\">";
			$toRet .= "<tr>";
	   		$toRet .= "<td>";
	
	      	$toRet .= "<table id=\"botones\" align = \"center\"><tr align = \"center\">";
	        $toRet .= "<td><center><a onclick= \"javascript:addfil ()\"; href=\"javascript:;\">";
	        $toRet .= "<img border= \"0\" alt=\"add\" src=\"".$url ."mod/rubricas/graphics/insertr.png\"> <br>". elgg_echo('rubricas:anadir_fila')."</a></center></td>";
	        $toRet .= "<td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</td>";
	        $toRet .= "<td><center><a onclick= \"javascript:delfil ()\"; href=\"javascript:;\">";
	        $toRet .= "<img border= \"0\" alt=\"del\" src=\"".$url ."mod/rubricas/graphics/delete.png\"> <br>". elgg_echo('rubricas:borrar_fila')."</a></center></td>";
	        $toRet .= "<td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</td>";
	        $toRet .= "<td><center><a onclick= \"javascript:addcol ()\"; href=\"javascript:;\">";
	        $toRet .= "<img border= \"0\" alt=\"add\" src=\"".$url ."mod/rubricas/graphics/insertc.png\"> <br>". elgg_echo('rubricas:anadir_col') ."</a></center>";
	        $toRet .= "</td>";
	        $toRet .= "<td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</td>";
	        $toRet .= "<td><center><a onclick= \"javascript:delcol ()\"; href=\"javascript:;\">";
	        $toRet .= "<img border= \"0\" alt=\"del\" src=\"".$url ."mod/rubricas/graphics/delete.png\"> <br>". elgg_echo('rubricas:borrar_col') ."</a></center></td>";
	        $toRet .= "</table>";
	   		$toRet .= "</td>";
			$toRet .= "</tr>";
	
			$toRet .= "<tr>";
			$toRet .= "<td>". $rubric;
			$toRet .= "</td>";
	
			$toRet .= "</tr>";
			$toRet .= "</table>";
				
			return $toRet;
		}

		/*
		* Crea un formulario de rúbrica nueva
		*/
		function create_new()
		{
			
		$form = "<table id='datos'>";
			
			for ($i=0; $i<4; $i++)
			{
				
				$form .=  "<tr id = 'fila".$i."'>";
				
				for ($j=1; $j<4 + 1; $j++)
				{
					
					// Title cell
					if (($j == 1) & ($i == 0))
					{
						
						$form .=  "<td id='celda1' class='celdatitulo'><table id='tcelda1' border='1'><tr><td><input type='text' id= 'nombre' size='22' value='Enter title' name='titulo'></td></tr></table></td>";
						
					}
					// Left row
					else if ($j == 1)
					{
					
						$form .=  "<td id='celda1' class='celdaizq'><table id='tcelda1' border='1' ><tr><td><input type='text' id= 'nombre".$i.$j."' size='22' value='Enter criteria name' name='criterio[]'></td></tr><tr><td><textarea id='texto".$i.$j."' name='cdesc[]'>Enter criteria description</textarea></td></tr></table></td>";
						
					}
					else 
					{								
						// Top col
						if ($i == 0) 
						{				
							$t = $j - 1;	
							switch ($j)
							{
								case "2": $text = "Poor";	
												break;
							    case "3": $text = "Fair";	
												break;
								case "4": $text = "Good";	
												break;
							}
							$form .=  "<td id='celda2' class='celdaarriba'><table id='tcelda".$j."' border='1'><tr><td><input type='text' id='texto".$i.$j."' name='pdesc[]' value='".$text."' size='22'></td></tr><tr><td id='puntos'><center>Weight &nbsp;<input id= 'nombre".$i.$j."' type='text' size='4' value='".$t."' name='puntos[]'>&nbsp; pts</center></td></tr></table></td>";		
										
						}
						// Other cell
						else
						{						
							$form .=  "<td id='celda2' class='celda'><table id='tcelda".$j."' border='1'><tr><td><textarea class='cell' id='texto".$i.$j."' name='desc[]'>Descripcion</textarea></td></tr></table></td>";	
						
						}		
					}
				} // End for j
				
				$form .= "</tr>";
			} // End for i
			
			$form .= "</table>";		
			
			return $form; 	
		}
		
		/*
		* Crea el formulario para editar una rúbrica
		*/
		function editar( $rubric )
		{
		   $nc = 0;
		   $nd = 0;
		   $np = 0;
		   $ncd = 0;
		   $npd = 0;
		   $arrpuntos = $rubric->puntos;
		   $arrcrit = $rubric->criterio;
		   $arrdesc = $rubric->desc;
		   $arrpd =  $rubric->pdesc;
		   $arrcd = $rubric->cdesc;
		   			
		   $arr = explode('#',$arrpuntos);
		   $ar1 = explode('#',$arrcrit);
		   $ar2 = explode('#',$arrdesc);
		   $cd = explode('#',$arrcd);
		   $pd = explode('#', $arrpd);
				   $r = "<table id='datos'>";
		   for ($i=0; $i< $rubric->filas; $i++)
		   {
		   
		   $r .=  "<tr id='fila".$i."'>";
		
		   for ($j=0; $j< $rubric->cols; $j++)
		   {
		   	
		   	  // Celda de titulo
		      if ($j == 0 && $i == 0)
		      {
		         $r .= "<td id='celda1' class='celdatitulo'><table id='tcelda1' border='1'><tr><td><input type='text' id= 'nombre' size='22' value='". $rubric->title."' name='titulo'></td></tr></table></td>";
		      }
		      else 
		      {
		      	
		      // Fila izquierda
		      if ($j == 0) 
		      {
		            $t = $j + 1;
		            $r .= "<td id='celda".$t."' class='celdaizq'><table id='tcelda".$t."' border='1'><tr><td><input id= 'nombre".$i.$t."' type='text' size='22' value='". $ar1[$nc] ."' name='criterio[]'></td></tr><tr><td><textarea id='texto".$i.$t."' name='cdesc[]'>".$cd[$ncd]."</textarea></td></tr></table></td>";
		            $ncd++;
		            $nc++;
		      } 
		      else 
		      {
		      	if ($i == 0)
		      	{
		      		// Columna de arriba
			         $t = $j + 1;
			         $r .= "<td id='celda".$t."' class='celdaarriba'><table id='tcelda".$t."' border='1'><tr><td><input id='texto".$i.$t."' name='pdesc[]' size='22' value=".$pd[$npd]."></td></tr><tr><td><center>Weight &nbsp;<input id= 'nombre".$i.$t."' type='text' size='4' value='". $arr[$np] ."' name='puntos[]'>&nbsp; pts</center></td></tr></table></td>";
			         $npd++;
			         $np++;    
			           		
		      	}
			      else 
			      {
			         $t = $j + 1;
			         $r .= "<td id='celda".$t."' class='celda'><table id='tcelda".$t."' border='1'><tr><td><textarea class='cell' id='texto".$i.$t."' name='desc[]'>".$ar2[$nd]."</textarea></td></tr></table></td>";
			         $nd++;
		
			         }
		      }
		      }
		   } // end for $j
		
		   $r .= "</tr>";
		   
		   } // end for $i
		
		   $r .= "</table>";	
		   return $r;
			
		}
		
		/* 
		* Vista de galería de una rúbrica
		*/
		function gallery( $rubrica )
		{
			$info .= "<table id='data' name='data'>";
		      $nc = 0;
		      $nd = 0;
		      $np = 0;
		      $ncd = 0;
		      $npd = 0;
		      $arr = $rubrica->puntos;
		      $ar1 = $rubrica->criterio;
		      $ar2 = $rubrica->desc;
		      $cd = $rubrica->cdesc;
		      $pd = $rubrica->pdesc;
		
		      $arrpuntos = explode('#',$arr);
		      $arrcrit = explode('#',$ar1);
		      $arrdesc = explode('#',$ar2);
		      $arrpdesc = explode('#',$pd);
		      $arrcdesc = explode('#',$cd);
		
		      for ($i=0; $i<$rubrica->filas; $i++)
		      {
		        $info .=  "<tr>";
		
		        for ($j=0; $j<$rubrica->cols; $j++)
		        {
		                if ($j == 0 && $i == 0)
		                {
		                        $info .= "<td> <table id='celdat'> <tr> <td id='titul' name='titul'>".$rubrica->title." </td> </tr></table> </td>";
		                }
		                else {
		                		// Primera celda de la fila
		                        if ($j == 0) 
		                        {
		                                $info .= "<td> <table id='celda'> <tr> <td id='crit'>". $arrcrit[$nc] ."</td> </tr> <tr> <td>". $arrcdesc[$ncd] ."</td> </tr> </table> </td>";
		                                $ncd++;
		                                $nc++;
		                        } 
		                        else 
		                        {
		                        	// Primera celda de la columna
		                        	if ($i==0)
		                        	{
		                        			$info .= "<td> <table id='celdat'> <tr> <td>". $arrpdesc[$npd] ."</td> </tr> <tr> <td id='puntos'>". $arrpuntos[$np] ." pts</td> </tr>  </table> </td>";
		                        			$np++;
		                        			$npd++;
		                        	}
			                        else 
			                        {
			                                $info .= "<td> <table id='celda'> <tr> <td><center><b>". $arrpdesc[$j-1] ."</b></center></td> </tr><tr> <td>". $arrdesc[$nd] ."</td> </tr> </table> </td>";
			                                $nd++;
			                        }
		                        }
		                }
		        } // end for $j
		
		        $info .= "</tr>";
		        
		      } // end for $i
		
		      $info .= "</table>";
		      
		      return $info;

		}
?>