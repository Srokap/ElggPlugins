<?php
/*
* lib/assess_functions
* Funciones útiles para evaluar una rúbrica y visualizar una calificación
*
* @package ElggRubric
*/
	
	/*
	* Crear rubrica
	* Crea una rúbrica para ser evaluada
	* param El objeto rubrica
	* return HTML de salida de esa rubrica
	*/
	function crear_rubrica ($rubrica)
	{
		
	// Visualizar la rubrica
		  $inf .= "<div class='act_gallery'>";
	      $inf .= "<table id='tabla'>";
	      $nc = 0;
	      $nd = 0;
	      $np = 0;
	 	  $ncd = 0;
		  $npd = 0;     
		  
	      $arr = $rubrica->puntos;
	      $ar1 = $rubrica->criterio;
	      $ar2 = $rubrica->desc;
		  $arrpd =  $rubrica->pdesc;
		  $arrcd = $rubrica->cdesc;
		  
	      $arrpuntos = explode('#',$arr);
	      $arrcrit = explode('#',$ar1);
	      $arrdesc = explode('#',$ar2);
	  	  $cd = explode('#',$arrcd);
		  $pd = explode('#', $arrpd);    
		        
	     for ($i=0; $i<$rubrica->filas; $i++)
	     {
	        $inf .=  "<tr>";
	
	        for ($j=0; $j<$rubrica->cols; $j++)
	        {
	                if ($j == 0 && $i == 0)
	                {
	                        $inf .= "<td id='titul'> <table id='celdat'> <tr> <td id='titul' name='titul'>".$rubrica->title." </td> </tr></table> </td>";
	                }
	                else 
	                {
	                		// Primera celda de la fila
	                        if ($j == 0) 
	                        {
	                                $inf .= "<td> <table id='celda'> <tr> <td id='crit'>". $arrcrit[$nc] ."</td> </tr> <tr> <td>". $cd[$ncd] ."</td> </tr> </table> </td>";
	                                $ncd++;
	                                $nc++;
	                        } 
	                        else 
	                        {
	                        	// Primera celda de la columna
	                        	if ($i==0)
	                        	{
	                        			$inf .= "<td> <table id='celdat'><tr> <td id='puntos'>". $pd[$npd] ."</td> </tr> <tr> <td id='puntos'><input type='hidden' id='p".$j."' value='".$arrpuntos[$np]."'>". $arrpuntos[$np] ." pts</td> </tr>  </table> </td>";
	                        			$np++;
	                        			$npd++;
	                        	}
		                        else 
		                        {
		                        	$cols = $rubrica->cols - 1;
		                        	$inf .= "<td class='celdas' id='".$i.$j."'><a id='selectCell' onClick='select(".$i.",".$j.",".$cols."); return false;' href='javascript:'>".$arrdesc[$nd]."</a></td>";
		                            $nd++;
	
		                        }
		                   }
	                }
	        } // end for $j
	
	        $inf .= "</tr>";
	        
	      } // end for $i
	
	      $inf .= "</table></div>";
		  $key = $rubrica->cols-2;
	      $inf .= "<input type='hidden' id='maxpuntos' name='maxpuntos' value='".$arrpuntos[$key]."'>";
	      
	      
		  return $inf;	
		
	}
	
	/*
	* Crear evaluacion
	* Crea una rúbrica para ser evaluada señalando las calificaciones
	* param El guid del envio y el guid de la rubrica
	* return HTML de salida de esa rubrica
	*/
	function crear_evaluacion ($e, $r)
	{
		$envio = get_entity($e->guid);
		$rubricas = get_entity($r->guid);
		
	    $info = "<div class='act_gallery'>";
	    $info .= "<table id='selectable' name='data'>";
	    $nc = 0;
	    $nd = 0;
	    $np = 0;
	    $ncd = 0;
		$npd = 0;
		
	    $ne = -2;
	    $arrpuntos = $rubricas->puntos;
	    $arrcrit = $rubricas->criterio;
	    $arrdesc = $rubricas->desc;
	    $arrpd =  $rubricas->pdesc;
		$arrcd = $rubricas->cdesc;
		
	    $arr = explode('#',$arrpuntos);
	    $ar1 = explode('#',$arrcrit);
	    $ar2 = explode('#',$arrdesc);
		$cd = explode('#',$arrcd);
		$pd = explode('#', $arrpd);
		
		$puntuacion = explode('#',$e->nota);
	
	    for ($i=0; $i<$rubricas->filas; $i++) 
	    {
	    	$info .=  "<tr>";
	    	$ne++;
			
	        for ($j=0; $j<$rubricas->cols; $j++) 
	        {
	                           
	        	if ($j == 0 && $i == 0)
	        	{
	            	$info .= "<td id='titul'> <table id='celdat'> <tr> <td id='titul' name='titul'>".$rubricas->title." </td> </tr></table> </td>";
	            }
				else 
				{
					// Primera celda de la fila
	            	if ($j == 0) 
	            	{
	                	$info .= "<td> <table id='celda'> <tr> <td id='crit'>". $ar1[$nc] ."</td> </tr> <tr> <td>". $cd[$ncd] ."</td> </tr> </table> </td>";
	                    $ncd++;
	                    $nc++;
	
	                } else {
	                	// Primera celda de la columna
	                	if ($i == 0)
	                	{                 
	                      $info .= "<td> <table id='celdat'><tr> <td id='puntos'>". $pd[$npd] ."</td> </tr> <tr> <td id='puntos'><input type='hidden' id='p".$j."' value='".$arr[$np]."'>". $arr[$np] ." pts</td> </tr> </table> </td>";            
	                      $np++;
	                      $npd++;
	                  }                
	                   else 
	                   {  
	                   			$o = $i . $j;
	                   			$cols = $rubricas->cols - 1;
	                   			if ($puntuacion[$ne] == $o)     
	                   				$info .= "<td class='seleccionada' id='".$i.$j."'><a id='selectCell' onClick='select(".$i.",".$j.",".$cols."); return false;' href='javascript:'>".$ar2[$nd]."</a></td>";                     
	                    		else
	                    			$info .= "<td class='celdas' id='".$i.$j."'><a id='selectCell' onClick='select(".$i.",".$j.",".$cols."); return false;' href='javascript:'>".$ar2[$nd]."</a></td>";
	                    		$nd++;   
	                  	}
	
					} // Else
				} // else
	         } // end for $j
	
	        $info .= "</tr>";
	                           
		} // end for $i
	
	    $info .= "</table>";
	    $info .= "</div>";
	    
	    $key = $rubricas->cols-2;
	    $info .= "<input type='hidden' id='maxpuntos' name='maxpuntos' value='".$arr[$key]."'>";
	    
	    return $info;
	  
	}


	/*
	* Ver evaluacion
	* Muestra una rubrica evaluada señalando las calificaciones
	* param El guid del envio y el guid de la rubrica
	* return HTML de salida de esa rubrica
	*/
	function ver_evaluacion ($e, $r)
	{
		$envio = get_entity($e->guid);
		$rubricas = get_entity($r->guid);
		
	    $info = "<div class='act_gallery'>";
	    $info .= "<table>";
	    $nc = 0;
	    $nd = 0;
	    $np = 0;
	    $ncd = 0;
		$npd = 0;
		
	    $ne = -2;
	    $arrpuntos = $rubricas->puntos;
	    $arrcrit = $rubricas->criterio;
	    $arrdesc = $rubricas->desc;
	    $arrpd =  $rubricas->pdesc;
		$arrcd = $rubricas->cdesc;
		
	    $arr = explode('#',$arrpuntos);
	    $ar1 = explode('#',$arrcrit);
	    $ar2 = explode('#',$arrdesc);
		$cd = explode('#',$arrcd);
		$pd = explode('#', $arrpd);
		
		$puntuacion = explode('#',$e->nota);
	
	    for ($i=0; $i<$rubricas->filas; $i++) 
	    {
	    	$info .=  "<tr>";
	    	$ne++;
			
	        for ($j=0; $j<$rubricas->cols; $j++) 
	        {
	                           
	        	if ($j == 0 && $i == 0)
	        	{
	            	$info .= "<td id='titul'> <table id='celdat'> <tr> <td id='titul' name='titul'>".$rubricas->title." </td> </tr></table> </td>";
	            }
				else 
				{
					// Primera celda de la fila
	            	if ($j == 0) 
	            	{
	                	$info .= "<td> <table id='celda'> <tr> <td id='crit'>". $ar1[$nc] ."</td> </tr> <tr> <td>". $cd[$ncd] ."</td> </tr> </table> </td>";
	                    $ncd++;
	                    $nc++;
	
	                } else {
	                	// Primera celda de la columna
	                	if ($i == 0)
	                	{                 
	                      $info .= "<td> <table id='celdat'><tr> <td id='puntos'>". $pd[$npd] ."</td> </tr> <tr> <td id='puntos'><input type='hidden' id='p".$j."' value='".$arr[$np]."'>". $arr[$np] ." pts</td> </tr> </table> </td>";            
	                      $np++;
	                      $npd++;
	                  }                
	                   else 
	                   {  
	                   			$o = $i . $j;
	                   			$cols = $rubricas->cols - 1;
	                   			if ($puntuacion[$ne] == $o)     
	                   				$info .= "<td class='seleccionada' id='".$i.$j."'>".$ar2[$nd]."</td>";                     
	                    		else
	                    			$info .= "<td class='celdas' id='".$i.$j."'>".$ar2[$nd]."</td>";
	                    		$nd++;   
	                  	}
	
					} // Else
				} // else
	         } // end for $j
	
	        $info .= "</tr>";
	                           
		} // end for $i
	
	    $info .= "</table>";
	    $info .= "</div>";
	    
	    return $info;
	  
	}
	
	/*
	* Exportar evaluacion
	* Muestra una rubrica evaluada señalando las calificaciones, en formato CSV
	* param El guid del envio y el guid de la rubrica
	* return HTML de salida de esa rubrica en formato CSV
	*/
	function exportar_evaluacion ($e, $r)
	{
		$envio = get_entity($e);
		$rubrica = get_entity($r);
		
		$separator = ";";
		
		$puntuacion = explode('#', $envio->nota);
		
		// Titulo y descripcion de puntos
		$pdesc = str_replace("#", ";", $rubrica->pdesc); 
		$info = utf8_decode($rubrica->title) . $separator . $pdesc . "\n";
		
		// puntos
		$puntos = str_replace("#", ";", $rubrica->puntos); 
		$info .= " ;" . utf8_decode($puntos) . "\n";
		
		// Criterio y descripciones
		$nc = 0;
		$nd = 0;
		$ncd = 0;
		   			
		$ar1 = explode('#', $rubrica->criterio);
		$ar2 = explode('#', $rubrica->desc);
		$cd = explode('#', $rubrica->cdesc);
		$pd =  explode('#', $rubrica->pdesc);
		
		$replace = array("\r\n", "\n\r", "\n", "\r");
		
		for ($i=0; $i<$rubrica->filas-1; $i++)
		{
			for ($j=0; $j<$rubrica->cols; $j++)
			{
				if ($j == 0)
				{
					$f1 .= utf8_decode($ar1[$nc]) . $separator;
					$f2 .= utf8_decode($cd[$ncd]) . $separator; 
					$nc++;
					$ncd++;
				}
				else
				{
					$pos = $i+1 . $j;
					if ($puntuacion[$i] == $pos)
					{
						$f1 .= "[" . utf8_decode($pd[$j-1]) . "]" . $separator;
						$f2 .= "[" . utf8_decode(str_replace($replace," ",$ar2[$nd])) . "]" . $separator; 
					}
					else
					{
						$f1 .= utf8_decode($pd[$j-1]) . $separator;
						$f2 .= utf8_decode(str_replace($replace," ",$ar2[$nd])) . $separator; 
					}
					$nd++;				
				}
			}
			$info .= $f1 . "\n";
			$info .= $f2 . "\n";
			$f1 = "";
			$f2 = "";
		}
		
		return $info;
	}
	
// Devolver una entidad calificacion por el guid de la actividad evaluada
function get_assessment ( $actividad )
{
	$calificaciones = elgg_get_entities(array( "type"=>"object", "subtype"=>"calificacion", "owner_guid" => 0, "limit"=>100));
	if (isset($calificaciones) || $calificaciones != "")
	{
		foreach ($calificaciones as $c)
		{
			if ($c->guid_actividad == $actividad)
				return $c;
		}
	}
	return false;
}

// Devolver una nota en formato x / x ( x % )
function mostrar_nota ( $calificacion )
{
	$c = get_entity($calificacion);
	
	if ($c)
	{
		if ($c->tipo == 'rubrica')
		{
			return $c->numerica ." / ". $c->total . " ( " . $c->porcentaje . " % )";
		}
		else
		{
			return $c->nota ." / ". $c->total . " ( " . $c->porcentaje . " % )";
		}
	}
	else
		return 0;
}
?>