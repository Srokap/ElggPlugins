<?php
/*
* /object/rubrica
*
* Permite visualizar el objeto rúbrica
* Dependiendo del tipo de vista
*
* @package ElggRubric
*/

if (get_input('search_viewtype') == "gallery") 
{
        // Visualizar la vista de galeria
        echo elgg_view("rubricas/gallery",$vars);

} else 
{
        echo elgg_view("rubricas/listado",$vars);

       }
?>

