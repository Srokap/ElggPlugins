/* 
* Scripts.js
* Utilizado por edit, editar, y nueva r�brica
* Funciones para a�adir/eliminar columnas y celdas
* Y validar las r�bricas
*
* @package ElggRubric
*/

contador = 1;
numfilas = 4;
numcols = 4;

/* 
* Funcion para a�adir una fila
* @return boolean
*/
function addfil()
{	
	var t,i, celda, nodo, fila, nombre;
	
    t = document.getElementById("datos");
    fila = t.insertRow(numfilas);
    nombre = "fila" + numfilas;
    fila.id = nombre;

    for (i=numcols;i>0;i--)
    {
	    celda = fila.insertCell(0);
    	nodo = document.createElement("table");
        nombre = "celda" + i;
        nodo.setAttribute("id",nombre);
        
        n = numfilas;
        
        if (i==1) 
        {
        	nodo.innerHTML = '<td id="celda'+n+i+'" class="celdaizq"><table id="tcelda'+n+i+'" border="1"><tr><td><input id= "nombre'+n+i+'" type="text" size="22" value="Enter criteria name" name="criterio[]"></td></tr><tr><td><textarea id="texto'+n+i+'"  name="cdesc[]">Enter criteria description</textarea></td></tr></table></td>';
        	
        }
        else
        { 
        	nodo.innerHTML = crearNodo(i, n); 
        }
            celda.appendChild(nodo);
	}

    numfilas++;
    f = document.getElementById("filas");
    f.setAttribute("value",numfilas);

    return true;
}


/* 
* Funcion para a�adir una columna
* @return boolean
*/
function addcol()
{
	var t,i, celda, nodo, fila;

    for (i=0;i<numfilas;i++)
    {

    	fila = "fila" + i;
        t=document.getElementById(fila);
        celda = t.insertCell(numcols);
        nodo = document.createElement("table");
        
        if (i==0)
        {
         	n = numcols+1;
            nodo.innerHTML = '<td id="celda'+i+n+'" class="celdaarriba"><table id="tcelda'+i+n+'" border="1"><tr><td><input type="text" id="texto'+i+n+'" name = "pdesc[]" value="Points description" size="22"></td></tr><tr><td id="puntos"><center>Weight &nbsp;<input id= "nombre'+i+n+'" type="text" size="4" value="'+numcols+'" name="puntos[]">&nbsp; pts</center></td></tr></table></td>';           								
            
         }
         else
         	nodo.innerHTML = crearNodo(numcols+1, i);
         	
        celda.appendChild(nodo);
	}
	
    numcols++;

    f = document.getElementById("cols");
    f.setAttribute("value",numcols);

    return true;
}

/* 
* Funcion para borrar una fila
* @return boolean
*/
function delfil()
{
	var t = document.getElementById("datos");
    if (numfilas <2) 
    {
    	alert("No es posible borrar m�s filas");
    }
    else 
    {
    	t.deleteRow(-1);
        numfilas--;

        f = document.getElementById("filas");
        f.setAttribute("value",numfilas);

     }
     
     return true;
}

/* 
* Funcion para borrar una columna
* @return boolean
*/
function delcol()
{
 	var fila;
 	
    if (numcols <2) 
    {
    	alert("No es posible borrar m�s columnas");
    }
    else 
    {
    	var t = document.getElementById("datos");
        for (i=0;i<numfilas;i++)
        {
        	fila = "fila" + i;
            t=document.getElementById(fila);
            t.deleteCell(-1);
         }
         
         numcols--;
         f = document.getElementById("cols");
         f.setAttribute("value",numcols);
	}
	
    return true;
}

/* 
* Funcion para Crear un nodo
* @return string (El nodo)
* @param j, i (La columna y la fila)
*/
function crearNodo(j, i)
{
	return '<td id="celda2" class="celda"><table id="tcelda2" border="1"><tr><td><textarea id="texto'+i+j+'" class="cell" name = "desc[]">Descripcion</textarea></td></tr></table></td>';
        
}

/* 
* Funcion para Crear un boton (a�adir/borrar fila/columna)
* @return string (El boton)
*/
function crearCeldaButton()
{
	return '<td id="celdaButton1" bgcolor=#DCDCDC><center><a onclick= "javascript:delete ()"; href="javascript:;"><img border= "0" alt="add" src="img/delete.png"></a></center></td>';
	
}

/* 
* Funcion para Validar el formulario
* @return 0 si no se puede validar
*/
function valida()
{
    //validar el titulo
    if (document.getElementById("nombre").value=="Titulo" || document.getElementById("nombre").value.length==0)
    {
       alert("Debe introducir un titulo");

       return 0;
    }
    
    // Validar que los puntos sean numericos
    if (numcols > 3) 
    {
        for (i=2;i<=numcols;i++)
        {
	        nombre = "nombre0" + i;
	        texto = "texto0" + i; 
	       	if ((isNaN(document.getElementById(nombre).value)) || document.getElementById(nombre).value.length==0 || document.getElementById(texto).value.length==0)
	       	{
	       		alert("Debe introducir una puntuacion (Valor numerico)");
	       		return 0;
      		}
      	}
    }

	// Validar que no existan celdas vac�as
	for (i=1; i<numfilas; i++)
	{
		for (j=2; j<=numcols; j++)
		{
			nombre = "texto" + i + j;
			if (document.getElementById(nombre).value.length==0)
			{
	       		alert("No puede haber valores vacios"+ i+j);
	       		return 0;
      		}
		}
	}
	
	// Valida el criterio
	for (i=1; i<numfilas; i++){
		nombre = "nombre"+i+"1";
		//texto = "texto"+i+"1";
		if (document.getElementById(nombre).value.length==0 )
		{
	       	alert("No puede haber valores vacios");
	       	return 0;
      	}		
	}
	
    //el formulario se envia
    document.val.submit();
}
