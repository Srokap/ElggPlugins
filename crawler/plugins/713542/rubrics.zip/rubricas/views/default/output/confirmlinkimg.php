<?php
/**
 * Enlace de confirmación con una imagen
 * Visualiza un mensaje de confirmación antes de continuar
 *
 * @package ElggRubric
 *
 * @uses $vars['img'] Imagen del enlace
 * @uses $vars['href'] Dirección
 * @uses $vars['confirm'] El texto del mensaje
 *
 */

$confirm = $vars['confirm'];
if (!$confirm) {
	$confirm = elgg_echo('question:areyousure');
}

// Añadir la acción a la URL
$link = elgg_add_action_tokens_to_url($vars['href']);

if (isset($vars['class']) && $vars['class']) {
	$class = 'class="' . $vars['class'] . '"';
} else {
	$class = '';
}
?>
<a href="<?php echo $link; ?>" <?php echo $class; ?> onclick="return confirm('<?php echo addslashes($confirm); ?>');"><img title='<?php echo $vars['title']; ?>' src='<?php echo $vars['img']; ?>' /></a>