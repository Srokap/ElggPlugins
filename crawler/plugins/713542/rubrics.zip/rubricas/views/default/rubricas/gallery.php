<?php
	/*
	*
	* Gallery: Muestra una rubrica con filas y columnas
	*
	*
	* @package ElggRubric
	*/
?>

	<script type="text/javascript" >
	$(document).ready(function() {
	   $(".botonExcel").click(function(event) {
	      $("#datos").val($("<div>").append($("#data").eq(0).clone()).html());
	      $("#FormularioExportacion").submit();
	});
	});
	</script>
	
	<style type="text/css">
	.botonExcel{cursor:pointer;}
	</style>

<?php

	global $CONFIG;
	
	// Librer�a para crearci�n de r�brica
	require_once($CONFIG->pluginspath . "/rubricas/lib/functions.php");
	
	$info = "<div class=\"rubrics_gallery\">";
	
	// Muestra el usuario en el listado
	$owner = $vars['entity']->getOwnerEntity();
	
	// Muestra el tiempo de creacion
	$friendlytime = friendly_time($vars['entity']->time_created);
	
	// Muestra el t�tulo de la rubrica
	$info .= "<h1> {$vars['entity']->title}</h1>";
	$info .= "<BR>";
	
	// Muestra la foto del usuario
	$icon .= elgg_view(
	            "profile/icon", array(
	                              'entity' => $owner,
	                              'size' => 'small',
	                             )
	         );
	$inf .= "<p class=\"owner_timestamp\"><a href=\"{$owner->getURL()}\">{$owner->name}</a> {$friendlytime}</p>";
	$info .= elgg_view_listing($icon, $inf);
	$info .= "<BR>";
	
	// Crear rubrica
	$info .= "<center>". gallery($vars['entity']) ."</center>";      
	
	$botonBorrar = elgg_view("output/confirmlinkimg", array(
							'href' => $vars['url'] . "action/rubrics/borrar?rubrica=" . $vars['entity']->getGUID(),
							'title' => 'Delete',
							'img' => $vars['url']."mod/rubricas/graphics/borrar.png",
							'confirm' => elgg_echo('deleteconfirm'),
						));
						
	// Tabla con botones de borrar, editar y exportar
	if (isadminloggedin())
	{
		$info .= "<br><br><center><table><tr>";
		$info .= "<td text-align=\"center\">";
		$info .= "<a href=\"". $vars['url']."mod/rubricas/pages/editar.php?rubrica=". $vars['entity']->getGUID()."\"><img title='Edit' src=\"". $vars['url']."mod/rubricas/graphics/edit.gif\" /></a>  &nbsp;";
		$info .= "</td>";
		$info .= "<td>";
		$info .= $botonBorrar;
		$info .= "</td>";
		$info .= "<td>";
		$info .= "<a href=\"". $vars['url']."mod/rubricas/views/csv/exportar.php?rubrica=". $vars['entity']->getGUID() ."\" method=\"post\">";
		$info .= "<img title='Exportar' src=\"". $vars['url']."mod/rubricas/graphics/csv-icon.gif\" class=\"botonExcel\" />";
		$info .= "</a>&nbsp;";
		$info .= "</td>";
		$info .= "</tr></table></center>";
	}
		  
	// Acceso de la rubrica      
	$info .= "<br><div class='texto'>";
	$info .= elgg_echo('rubricas:acceso');
	$info .= ":<BR>";
	$info .= get_readable_access_level($vars['entity']->access_id);
		
	//Etiquetas
	$tags = elgg_view('output/tags', array('tags' => $vars['entity']->tags));
	if (!empty($tags)) 
	{
		$info .= "<BR><BR>";
		$info .= elgg_echo('tags');
		$info .= "<BR>";
		$info .= '<p class="tags">' . $tags . '</p>';
	}
		       
	$info .= "</div><BR><BR>";
	
	echo $info;
		       
	echo "<center><form name='volver' action='". $vars['url'] ."mod/rubricas/pages/listado.php' method='post'>
		<input type='submit' value='". elgg_echo('rubricas:volver') ."' name='volver' title='Volver'></form></center>";

?>

