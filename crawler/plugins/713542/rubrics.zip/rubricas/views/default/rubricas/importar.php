<?php

	/**
	 * Elgg rubricas/importar
	 * Permite importar una rubrica para editarla y almacenarla como nueva
	 *
	 * @package ElggRubric
	 */


	echo "<form name='select' action='". $vars['url'] ."mod/rubricas/actions/importar.php' method='post' enctype='multipart/form-data'>";
	echo "<div class='rubricas_form'>";
	echo  elgg_echo('rubricas:selectcsv');
	echo "<br><br>";
	
	// Subir un fichero
	echo elgg_view('input/file',array('internalname' => 'data', 'internalid' => 'data'));
	echo "<BR><BR>";
	
	echo "<input type='submit' value='". elgg_echo('rubricas:enviar') ."' title='". elgg_echo('rubricas:enviar') ."'>";
	
	echo elgg_view('input/securitytoken'); 
	
	echo "</form>";
	echo "<br>";
	
	// Descargar plantilla
	echo "<a href=\"".$vars['url']."mod/rubricas/lib/Plantilla_Rubrica.csv\"><img title='".elgg_echo('rubricas:plantilla')."' src=\"". $vars['url']."mod/rubricas/graphics/download-icon.jpg\" /></a> ".elgg_echo('rubricas:plantilla')."<br><br>";
		
	echo " </div>";
	
	echo " <form name='volver' action='". $vars['url'] ."mod/rubricas/pages/crear.php' method='post'>";
	echo " <center><input type='submit' value='". elgg_echo("rubricas:volver") ."' name='volver' title='". elgg_echo("rubricas:volver") ."'></center></form>";
	
?>