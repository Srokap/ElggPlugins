<?php
/*
* views/default/rubricas/editar_nueva
* Formulario de edici�n de una r�brica
*
* @package ElggRubric
*/

?>
	
	<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/rubricas/views/default/js/scripts.js"></script>

<?php

	require_once($CONFIG->pluginspath . "/rubricas/lib/functions.php");
	
	echo "<div class='rubrics_new'>";
	
	echo "<form name='val' action='". $vars['url'] ."action/rubrics/editar_nueva' method='post'>";
	
   	echo "<center><h2>".$vars['entity']->title."</h2></center>";

	echo "<br><br>";
	
   // Para pasar valores a javascript
   echo "<script language='javascript'>";
   echo  "  var numfilas = " . $vars['entity']->filas . ";";
   echo  "  var numcols = " . $vars['entity']->cols . ";";
   echo "</script>";

   // Visualiza la r�brica con los parametros guardados por el usuario
   $info = "<div class='rubric-content'>";
    
   $info .= create_table(editar($vars['entity']), $vars['url']);
         
   $info .= "<br>";
   
   $info .= "</div>";
   
   $info .= "<br><br>";
   
	// Acceso de la rubrica
	$access_input = elgg_view('input/access', array('internalname' => 'access_id', 'value' => $vars['entity']->access_id));
	$info .=  elgg_echo('rubricas:acceso');
	$info .=  "<BR>";
	$info .=  $access_input;
	
	//Etiquetas
	$info .=  "<BR><BR>";
	$info .=  elgg_echo('tags');
	$info .=  "<BR>";
	$info .=  elgg_view('input/tags',array('internalname' => 'tags', 'value'=>$vars['entity']->tags));
	$info .=  "<BR><BR>";   
	
   $info .= "<BR>";
   $info .= "<input type='hidden' name='filas' id= 'filas' value=".$vars['entity']->filas.">";
   $info .= "<input type='hidden' name='cols' id = 'cols' value=".$vars['entity']->cols.">";
   $info .= "<center><input type='button' value='". elgg_echo('rubricas:enviar') ."' onclick='valida()' class='boton' title='". elgg_echo('rubricas:enviar') ."'></center>";
   $info .= elgg_view('input/securitytoken');
   
   $info .= "</form>";
   $info .= "</div>";

   if (isset($vars['entity'])) 
   {
        $entity_hidden = elgg_view('input/hidden', array('internalname' => 'rubrica', 'value' => $vars['entity']->getGUID()));
   } 
   else 
   { 
        $entity_hidden = '';
    }
     
   echo $entity_hidden;
   
   $info .= "<center><form name='volver' action='". $vars['url'] ."mod/rubricas/pages/cargar.php' method='post'>
	<input type='submit' value='". elgg_echo('rubricas:volver') ."' name='volver' title='". elgg_echo('rubricas:volver') ."'></form></center>";
	
   echo $info;
   
?>

</form>
