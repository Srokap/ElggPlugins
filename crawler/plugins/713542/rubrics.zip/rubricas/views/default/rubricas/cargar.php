<?php

	/**
	 * Elgg rubricas/cargar
	 * Permite seleccionar una rubrica para editarla y almacenarla como nueva
	 *
	 * @package ElggRubric
	 */
	
	// Todas las rúbricas públicas 
	$rubricas = get_entities ("object", "rubrica");

	if (($rubricas != "") & is_array($rubricas))
	{
		$tags_ = array();
		
		foreach ($rubricas as $r)
		{
			if ($r->title != "") 
			{
	
				$todas_guid .= $r->guid . "#";
				$todas_title .= $r->title . "#";
	
				if ($r->tags != "" & !is_array($r->tags))
				{
					$tags .= $r->tags . ",";
					$rub .= $r->guid . "#";
					$rubTitle .= $r->title . "#";
				}
				
				if ( is_array($r->tags))
				{						
					foreach ($r->tags as $etq)
					{			
						$tags .= $etq . ",";
						$rub .= $r->guid . "#";
						$rubTitle .= $r->title . "#";
					}
				}
			}	
		} // foreach
	} // if
	
	$url = $vars['url'];

?>

<script language="Javascript">
	function filtrar(etiqueta, rubricas)
	{
	
	    var tag = '<?php echo $tags ?>'; 
	    var ru = "<?php echo $rub ?>"; 
	    var tit = "<?php echo $rubTitle ?>"; 
	    var todas = "<?php echo $todas_guid ?>"; 
	    var todas_titulos = "<?php echo $todas_title ?>"; 
	    var etiquetas = tag.split(','); 
	    var rubs = ru.split('#');
	    var titulos = tit.split("#");
	    var t = todas.split('#');
	    var tt = todas_titulos.split('#');
	
	    // Ver la opcion seleccionada
	    for (i=etiqueta.options.length-1; i>=0; i--)
	    {
	    	if (etiqueta.options[i].selected == true)
	    	{
	    		var valor = etiqueta.options[i].text;
	    		borrarValores(rubricas);
	
	    		if (valor == "Todas")
	    		{
		    		for (j=0; j<=t.length-2; j++)
		    		{
		    			var newRow = new Option(tt[j], t[j]);
		    			rubricas.options[j] = newRow;	 	
		    		}    			
	    		}
	    		else
	    		{
		    		var x = 0;
		    		
		    		for (j=etiquetas.length-1; j>=0; j--)
		    		{
		    			if (etiquetas[j] == valor)
		    			{
		    				var newRow = new Option(titulos[j], rubs[j]);
		    				rubricas.options[x] = newRow;
		    				x++;
		    			}				
		    		}
	    		}
	    		break;
	    	}
	
	    }
	
	}
	
	function borrarValores(select)
	{
	    for (i=select.options.length; i>0; i--)
	    {
	    	select.options[i] = null;
	    }	
	    select.options[0] = null;
	}
	
	/*
	* Visualiza una rubrica
	*/
	function boton()
	{
		var f = document.getElementById("v");
		var rubricas = document.getElementById("rub");
		var rubrica = "";
		
		for (i=rubricas.options.length-1; i>=0; i--)
	    {
	    	if (rubricas.options[i].selected == true)
	    	{
	    		rubrica = rubricas.options[i].value;
	    		break;
	    	}
	    }
	    	
		f.action = "<?php echo $url ?>" + 'pg/view/' + rubrica + "?search_viewtype=gallery";
		f.submit();
	}
</script>

<?php
	
	echo "<div class=\"rubricas_form\">";
	
	$select = "<fieldset class='rub_info'><legend>".elgg_echo('rubricas:cargar') ."</legend>";
	
	// Mostrar rubricas
	if ($rubricas != "")
	{
		echo "<form name=\"select\" action=\"". $vars['url']."mod/rubricas/pages/editar.php\" method=\"post\">";
		
		$select .= "<select name=rubrica id=rub>";
		$rubricas = get_entities ("object", "rubrica");
		foreach ($rubricas as $r)
		{
			if ($r->title != " ") 
			{
				$select .= "<option value='".$r->guid."'>{$r->title}</option>";
			}	
		}	
		$select .= "</select>";
		
		$filtro .= "<select name='filtro'>";
		$filtro .= "<option value='0'>Todas</option>";
		$tag = explode(",", $tags);
		$tag = array_unique($tag);
		
		// Etiquetas
		foreach ($tag as $t)
		{
			if ($t != "")
				$filtro .= "<option value='".$t."'>{$t}</option>";
		}
		
		$filtro .= "</select> &nbsp;";
		$filtro .= "<input type=\"Button\" value=\"".elgg_echo('rubricas:filtrar')."\" title='".elgg_echo('rubricas:filtrar')."' class=\"boton\" onClick=\"filtrar(filtro, rubrica)\">";
		
		echo "<fieldset class='rub_info'><legend>".elgg_echo('rubricas:filtro') ."</legend>";
		echo $filtro . "<br><br></fieldset>";
		echo $select;
	
		// Editar rubrica
		echo "&nbsp;<input type='hidden' value='nueva' name='nueva'>";
		echo "<input type=\"submit\" value=\"". elgg_echo('rubricas:enviar') ."\" class=\"boton\" title=\"". elgg_echo('rubricas:enviar') ."\">";
		echo "</form>";
		
		// Visualizar rubrica
		echo "<br><form name='view' action=\"\" method='post' id=\"v\" target=\"ver\" onsubmit=\"ver = window.open(this.action , 'ver' , 'width=500,height=500')\">";
		echo "<input type=\"button\" class=\"boton\" value=\"". elgg_echo('rubricas:view') ."\" name=\"visualizar\" onclick=\"boton();\" title=\"". elgg_echo('rubricas:view') ."\">";
		echo "</form></fieldset>";
			
	} 
	else 
		echo elgg_echo("rubricas:noexisten");
	

	
	echo elgg_view('input/securitytoken');
	
	echo "</div>";

	// Botón volver
	echo "<center>";
	echo "<form name='volver' action='". $vars['url'] ."mod/rubricas/pages/crear.php' method='post'>";
	echo "<input type='submit' value=\"". elgg_echo('rubricas:volver') ."\" name='volver' title=\"". elgg_echo('rubricas:volver') ."\"></form>";
	echo "</center>";

?>




