<?php

/* 
* views/default/rubricas/calificar/evaluar_rubrica
* Muestra un formulario con una rúbrica para ser evaluada (Solo la rubrica y la puntuacion total)
*
* @param $vars['rubrica'] GUID de la rúbrica a calificar / 0 Si es nota numérica
* @param $vars['actividad'] GUID de la activad a la que se asocia la calificacion
*
* @package ElggRubric
*/

require_once($CONFIG->pluginspath . "/rubricas/lib/assess_functions.php");

?>

<script>
	$(function() {
			$( ".selectable" ).selectable({
				stop: function() {
					var result = $( "#select-result" ).empty();
					$( ".ui-selected", this ).each(function() {
						var index = $( "#selectable tr" ).index( this );
						result.append( " #" + ( index + 1 ) );
						var datos = document.getElementById(index + 1);
						var act = document.getElementById('actividad');
						act.value = datos.value;
	
					});
				}
			});
		});
</script>

<script language='javascript'>
	function select(i, j, cols)
	{
		for (x=1; x<=cols; x++)
		{
			var cell = i + "" + x;
			var celda = document.getElementById(cell);
			if (x == j)
				celda.className = "seleccionada";
			else
				celda.className = "celdas";
				
		}
	}
	
	function valorar(cols, rows)
	{
		var cell;
		var celda;
		var total = 0;
		var t = 0;
		var p;
		var pts;
		var puntos;
		
		for (i=1; i<rows; i++)
		{
			for (j=1; j<cols; j++)
			{
				cell = i + "" + j;
				celda = document.getElementById(cell);
		 		if	(celda.className == "seleccionada")
		 		{
		 			p = "p"+j;
		 			pts = document.getElementById(p);
		 			puntos = pts.value;
		 			total += parseInt(puntos);
		 			t++;
		 			break;	 			
		 		}
			}
		}
		var max = cols-1;
		max = "p" + max;
		max = document.getElementById(max).value;
		
		var toRet = Math.round((total/t)*100)/100;
		var d = document.getElementById('puntuaciontotal');
		if ( isNaN(toRet) )
			var message = "<div id='pt' style='background:#F08080; border:1px solid #FF0000; padding: 5px'>No ha seleccionado una puntación</div>";
		else
		{
			var porcentaje = (toRet*100)/max;
			porcentaje = Math.round(porcentaje*100)/100;
			var message = "<div id='pt' style='background:#D0FFD0; border:1px solid #66CC00; padding: 5px'>Puntuación total: " + toRet + " (" + porcentaje + " %)</div>";
		}
		d.innerHTML = message;
			
	}
	
	function guarda (cols, rows)
	{
		var cell;
		var celda;
		var total = 0;
		var t = 0;
		var p;
		var pts;
		var puntos;
		var calificacion = "";
		
		for (i=1; i<rows; i++)
		{
			for (j=1; j<cols; j++)
			{
				cell = i + "" + j;
				celda = document.getElementById(cell);
		 		if	(celda.className == "seleccionada")
		 		{
		 			p = "p"+j;
		 			pts = document.getElementById(p);
		 			puntos = pts.value;
		 			total += parseInt(puntos);
		 			t++;
		 			calificacion += i + "" + j + "#";
		 			break;	 			
		 		}
			}
		}	
		formcal = document.createElement("input");
		formcal.setAttribute("type", "hidden");
		formcal.setAttribute("name", "calificaciones");
		formcal.setAttribute("id", "calificaciones");
		formcal.setAttribute("value", calificacion);
		
		var d = document.getElementById('envio');
		d.appendChild(formcal);
		
		var max = cols-1;
		max = "p" + max;
		max = document.getElementById(max).value;
		
		var toRet = Math.round((total/t)*100)/100;
		
		formpuntuacion = document.createElement("input");
		formpuntuacion.setAttribute("type", "hidden");
		formpuntuacion.setAttribute("name", "numerica");
		formpuntuacion.setAttribute("id", "numerica");
		formpuntuacion.setAttribute("value", toRet);   
		d.appendChild(formpuntuacion);
}
</script>

<?php


if ( ($vars['rubrica'] != " " || $vars['rubrica'] == '0') && ($vars['actividad'] != " ") )
{
	$rubrica = get_entity($vars['rubrica']);
	$actividad = get_entity($vars['actividad']);
	
	$c = get_assessment ( $actividad->guid );
	
	// Si es un rubrica
	if ($vars['rubrica'] != "0")
	{
									
		// Si aún no se ha evaluado
		if ($c == false)
		{
			$act .= crear_rubrica($rubrica);
		}	
		// Ya se ha evaluado (Editar)
		else
		{
			$act .= crear_evaluacion($c, $rubrica);
			$total = round((($c->numerica * 100) / $c->total)*100)/100;
			$act .= "</center><br><center><p><table><tr><td><div id='pt' style='background:#ADD8E6; border:1px solid #4682B4; padding: 5px'>Puntuación total: " .$c->numerica." / ".$c->total." ( ".$total." % )</div></td></tr></table></p></center><br>";
		}		
					
		$act .= "<br><center><p><table id='tablapuntuacion'><tr><td id='puntuaciontotal'></td></tr></table></p></center><br>";
		$act .= "<br><center><p><input type='button' value='".elgg_echo('rubricas:rate')."' name='val' onClick='valorar(".$rubrica->cols.",".$rubrica->filas."); return false;' class='boton' title='".elgg_echo('rubricas:rate')."'></p></center>";

	}
	// Si es una nota numerica
	else
	{
		$act .= elgg_echo('rubricas:numerica');
		// No se ha evaluado
		if ($c == false)
		{
			$act .= "<p>".elgg_echo('rubricas:entergrade').": <input id= 'nota' type='text' size='6' value='10,00' name='nota'></p>";
			$act .= "<p>".elgg_echo('rubricas:entermax').": <input id= 'max' type='text' size='6' value='10,00' name='max'></p>";
		}
		// Ya se ha evaluado (Editar)
		else
		{
			$act .= "<p>".elgg_echo('rubricas:entergrade').": <input id= 'nota' type='text' size='6' value='".$c->numerica."' name='nota'></p>";
			$act .= "<p>".elgg_echo('rubricas:entermax').": <input id= 'max' type='text' size='6' value='".$c->total."' name='max'></p>";
		}
	}					

	echo $act;
}
else
{
	echo "<div class='actividad_view'>";
	echo elgg_view('rubricas:error_noactivity');
	echo "</div>";
}


?>
