<div class="contentWrapper">

<?php

/* views/default/listado
* Muetra un listado de las r�bricas del sistema.
*
* @package ElggRubric
*/
	
	
	$owner = $vars['entity']->getOwnerEntity();
	
	$friendlytime = friendly_time($vars['entity']->time_created);
	
	$icon = elgg_view("profile/icon", array(
	              'entity' => $owner,
	              'size' => 'small',)
	         );
	         
	// Titulo
	if (get_input('search_viewtype') == "evaluar") 
	{
	        echo "<h2><a href=\"{$vars['entity']->getURL()}?search_viewtype=evaluar\">{$vars['entity']->title}</a></h2><br>";
	}
	
	else 
	{	
	         // Mostramos el titulo de la rubrica
	         echo "<h2><a href=\"{$vars['entity']->getURL()}?search_viewtype=gallery\">{$vars['entity']->title}</a></h2><br>";
	 }
	
	// El propietario
	$info .= "<p class=\"owner_timestamp\"><a href=\"{$owner->getURL()}\">{$owner->name}</a> ". date('F j, Y', $vars['entity']->time_created). "</p>";
	
	// Etiquetas
	$info .= "<p class='tags'>". elgg_view('output/tags', array('tags' => $vars['entity']->tags)) . "</p>";
	    
	// Visualizar por pantalla
	echo elgg_view_listing($icon,$info);
	
	if (isadminloggedin())
	{

	echo "<a href='".$vars['url'] ."pg/rubrics/editar?rubrica=". $vars['entity']->getGUID() ."'>". elgg_echo("rubricas:edit")."</a>&nbsp;";


	// Bot�n de borrar
	echo elgg_view("output/confirmlink", array(
	           'href' => $vars['url'] . "action/rubrics/borrar?rubrica=" . $vars['entity']->getGUID(),
	           'text' => elgg_echo('rubricas:del'),
	           'confirm' => elgg_echo('deleteconfirm'),
	           ));
	}
?>
</div>
