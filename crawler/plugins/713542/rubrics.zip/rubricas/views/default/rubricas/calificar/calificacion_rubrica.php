<?php

/* 
* views/default/rubricas/calificar/calificacion_rubrica
* Permite visualizar una rubrica evaluada (Sólo la rúbrica)
*
* @param $vars['rubrica'] GUID de la rúbrica a calificar / 0 Si es nota numérica
* @param $vars['actividad'] GUID de la activad a la que se asocia la calificacion
*
* @package ElggRubric
*/

	require_once($CONFIG->pluginspath . "/rubricas/lib/assess_functions.php");
	
	$act_guid = $vars['act'];
	$alumno_guid = $vars['alumno'];
	
	if ( ($vars['rubrica'] != " " || $vars['rubrica'] == '0') && ($vars['actividad'] != " ") )
	{
		$rubrica = get_entity($vars['rubrica']);
		$actividad = get_entity($vars['actividad']);

		$c = get_assessment ( $actividad->guid );			
					
		// Si es un rubrica
		if ($c->tipo == 'rubrica')
		{
			if ($rubrica != "0")
			{
											
				// Si aún no se ha evaluado
				if ($c == false)
				{
					$act .= elgg_echo("rubricas:nograde") ."<br><br>";
				}
				// Ya se ha evaluado 
				else
				{
					$act .= "<center>". ver_evaluacion($c, $rubrica) ."</center>";
					$total = round((($c->numerica * 100) / $c->total)*100)/100;
					$act .= "<br><center><p><table><tr><td><div id='pt' style='background:#ADD8E6; border:1px solid #4682B4; padding: 5px'>".elgg_echo('rubricas:puntuaciontotal') .$c->numerica." / ".$c->total." ( ".$total." % )</div></td></tr></table></p></center><br>";
					$calificado = true;
				}		
		
			}
			else 
			{
				$act .= elgg_echo('rubricas:rubrica').": Privada o eliminada <br>";
				$total = round((($c->numerica * 100) / $c->total)*100)/100;
				$act .= elgg_echo('rubricas:puntuaciontotal') .$c->numerica." / ".$c->total." ( ".$total." % ) <br>";
			}
		}			
		// Si es una nota numerica
		else
		{
			$act .= elgg_echo('rubricas:numerica');
						
			// No se ha evaluado
			if ($c == false)
				$act .= elgg_echo("rubricas:nograde");
			// Ya se ha evaluado 
			else
			{
				$act .= "<p>".elgg_echo('rubricas:grade').": ". $c->nota." / ". $c->total;	
				$calificado = true;
			}			
		}
					
		echo $act;
	}
	else
	{
		echo "<div class='actividad_view'>";
		echo elgg_view('rubricas:error_noactivity');
		echo "</div>";
	}

?>