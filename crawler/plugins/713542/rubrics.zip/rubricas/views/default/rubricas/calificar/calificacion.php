<?php

/* 
* views/default/rubricas/calificar/calificacion
* Permite visualizar una rubrica evaluada con campos como el peso y el formulario de exportacion
*
* @param $vars['rubrica'] GUID de la rúbrica a calificar / 0 Si es nota numérica
* @param $vars['actividad'] GUID de la activad a la que se asocia la calificacion
* @param $vars['act'] GUID de la actividad
* @param $vars['actividad'] GUID del alumno calificado
*
* @package ElggRubric
*/

	require_once($CONFIG->pluginspath . "/rubricas/lib/assess_functions.php");
	
	$act_guid = $vars['act'];
	$alumno_guid = $vars['alumno'];
	
	if ( ($vars['rubrica'] != " " || $vars['rubrica'] == '0') && ($vars['actividad'] != " ") )
	{
		$rubrica = get_entity($vars['rubrica']);
		$actividad = get_entity($vars['actividad']);
		
		$c = get_assessment( $actividad->guid );
		
		// Evaluacion
		$act .= "<fieldset class='rub_info'><legend><b>".elgg_echo('rubricas:tipoeval')." </b></legend>";	
					
		// Peso de la actividad
		$act .= "<table><tr><td>". elgg_echo('rubricas:weightact').":&nbsp; </td><td>".$c->peso."</td></tr>";	
					
		// Visibilidad
		$act .= "<tr><td>".elgg_echo('rubricas:visibilidad').": </td><td>";
	
		if ($c->visible == 'true')
			$act .= "<img src=\"". $vars['url']."mod/rubricas/graphics/tick.jpg\" />";
		else
			$act .= "<img src=\"". $vars['url']."mod/rubricas/graphics/cross.jpg\" '/>";
					
		$act .= "</td></tr></table>";
		$act .= "<br>";				
	
		// Si es un rubrica
		if ($c->tipo == 'rubrica')
		{
			if ($rubrica != "0")
			{
				$act .= elgg_echo('rubricas:rubrica').": " . $rubrica->title;
				$act .= "<br><br>";
											
				// Si aún no se ha evaluado
				if ($c == false)
				{
					$act .= elgg_echo("rubricas:nograde") ."<br><br>";
				}
				// Ya se ha evaluado 
				else
				{
					$act .= "<center>". ver_evaluacion($c, $rubrica) ."</center>";
					$total = round((($c->numerica * 100) / $c->total)*100)/100;
					$act .= "<br><center><p><table><tr><td><div id='pt' style='background:#ADD8E6; border:1px solid #4682B4; padding: 5px'>".elgg_echo('rubricas:puntuaciontotal') .$c->numerica." / ".$c->total." ( ".$total." % )</div></td></tr></table></p></center><br>";
					$calificado = true;
				}		
		
			}
			else 
			{
				$act .= elgg_echo('rubricas:rubrica').": Privada o eliminada <br>";
				$total = round((($c->numerica * 100) / $c->total)*100)/100;
				$act .= elgg_echo('rubricas:puntuaciontotal') .$c->numerica." / ".$c->total." ( ".$total." % ) <br>";
			}
		}
		// Si es una nota numerica
		else
		{
			$act .= elgg_echo('rubricas:numerica');
						
			// No se ha evaluado
			if ($c == false)
				$act .= elgg_echo("rubricas:nograde");
			// Ya se ha evaluado 
			else
			{
				$act .= "<p>".elgg_echo('rubricas:grade').": ". $c->nota." / ". $c->total;	
				$calificado = true;
			}			
		}
	
		$act .= "<input type='hidden' id='act' name='act' value='".$act_guid."'>";
		$act .= "<input type='hidden' id='envio' name='envio' value='".$actividad->guid."'>";		
		
		// Exportar			
		if ($calificado)
		{
			$act .= "<center><a href=\"". $vars['url']."mod/actividad/views/csv/export_unique.php?alumno=". $alumno_guid ."&envio=".$actividad->guid."&act=".$act_guid."\" method=\"post\"><img title='Exportar' src=\"". $vars['url']."mod/rubricas/graphics/csv-icon.gif\" class=\"botonExcel\" /></a></center>";	
		}
					
		$act .= "</fieldset>";		
					
		echo $act;
	}
	else
	{
		echo "<div class='actividad_view'>";
		echo elgg_view('rubricas:error_noactivity');
		echo "</div>";
	}

?>
