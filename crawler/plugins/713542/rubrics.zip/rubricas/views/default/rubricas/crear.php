<div class="contentWrapper">

<?php

/* views/default/rubricas/crear
* Elegir crear una rubrica desde cero, importar o desde una existente
*
* @package ElggRubric
*/

	echo "<center>";
	echo "<form name='validar' action='' method='post'>";
	
	echo "<fieldset class='rub_info'><legend>".elgg_echo('rubricas:crear')."</legend>";
	echo "<table>";
	echo "<tr><td id='tabl'><img src='".$vars['url']."/mod/rubricas/graphics/new.gif'/></td>";
	echo "<td id='tabl'><input type='button' value='".elgg_echo('rubricas:nueva')."' name='nueva' onclick='this.form.action=\"".$vars['url']."mod/rubricas/pages/nueva.php\";this.form.submit();' class='boton' title='Create a new rubric'></td></tr>";
	echo "</table>";
	echo "</fieldset>";
	
	echo "<br><br>";
	
	echo "<fieldset class='rub_info'><legend>".elgg_echo('rubricas:cargartext')."</legend>";
	echo "<table>";
	echo "<tr><td id='tabl'><img src='".$vars['url']."/mod/rubricas/graphics/load.gif'/></td>";
	echo "<td id='tabl'><input type='button' value='".elgg_echo('rubricas:cargar')."' name='cargar' onclick='this.form.action=\"".$vars['url']."mod/rubricas/pages/cargar.php\";this.form.submit();' class='boton' title='Create a new rubric with another'></td></tr>";
	echo "</table>";
	echo "</fieldset>";
	
	echo "<br><br>";
	
	echo "<fieldset class='rub_info'><legend>".elgg_echo('rubricas:importartext')."</legend>";
	echo "<table>";
	echo "<tr><td id='tabl'><img src='".$vars['url']."/mod/rubricas/graphics/csv.gif'/></td>";
	echo "<td id='tabl'><input type='button' value='".elgg_echo('rubricas:importar')."' name='importar' onclick='this.form.action=\"".$vars['url']."mod/rubricas/pages/importar.php\";this.form.submit();' class='boton' title='Import a rubric'></td></tr>";
	echo "</table>";
	echo "</fieldset>";
	
	echo "</center>";
	
	echo "</form>";
?>

</div>
