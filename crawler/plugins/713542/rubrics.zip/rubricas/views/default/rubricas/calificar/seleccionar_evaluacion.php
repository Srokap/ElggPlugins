<?php

	/**
	 * rubricas/calificar/seleccionar_evaluacion
	 * Envia un formulario que permite seleccionar una rubrica o nota numerica
	 * Permite filtrar las rubricas por etiquetas
	 * Muestra las rubricas del usuario que realiza la solicitud
	 *
	 * @package ElggRubric
	 */
	 
	$rubricas = elgg_get_entities (array('type'=>"object", 'subtype'=>"rubrica", 'owner_guid'=>get_loggedin_userid()));

	// Coger etiquetas
	if ($rubricas != "")
	{
		foreach ($rubricas as $r)
		{
			if ($r->title != "") 
			{
	
				$todas_guid .= $r->guid . "#";
				$todas_title .= $r->title . "#";
	
				if ($r->tags != "" & !is_array($r->tags))
				{
					$tags .= $r->tags . ",";
					$rub .= $r->guid . "#";
					$rubTitle .= $r->title . "#";
				}
				
				if (is_array($r->tags))
				{	
					foreach ($r->tags as $etq)
					{			
						$tags .= $etq . ",";
						$rub .= $r->guid . "#";
						$rubTitle .= $r->title . "#";
					}
				}
				
				// Eliminar valores duplicados
				//$etiqu = array_unique(explode(",", $tags));
				//foreach ($etiqu as $e)
				//	$etiquetas .= $e . ",";
			}	
		}
	}

	$url = $vars['url'];

?>

<script language="Javascript">
	function filtrar(etiqueta, rubricas)
	{
	
	    var tag = '<?php echo $tags ?>'; 
	    var ru = "<?php echo $rub ?>"; 
	    var tit = "<?php echo $rubTitle ?>"; 
	    var todas = "<?php echo $todas_guid ?>"; 
	    var todas_titulos = "<?php echo $todas_title ?>"; 
	    var etiquetas = tag.split(',');
	    var rubs = ru.split('#');
	    var titulos = tit.split("#");
	    var t = todas.split('#');
	    var tt = todas_titulos.split('#');

	    var x = document.getElementById("filtro").selectedIndex;
	    var valor = document.getElementsByTagName("option")[x].text;
	    borrarValores(rubricas);
	
	    if (document.getElementsByTagName("option")[x].value == 0)
	    {
		    for (j=0; j<=t.length-2; j++)
		    {
		    	var newRow = new Option(tt[j], t[j]);
		    	rubricas.options[j] = newRow;	 	
		    }    			
	    }
	    else
	    {
		    var x = 0;
		    		
		    for (j=etiquetas.length-1; j>=0; j--)
		    {
		    	if (etiquetas[j] == valor)
		    	{
		    		var newRow = new Option(titulos[j], rubs[j]);
		    		rubricas.options[x] = newRow;
		    		x++;
		    	}				
		    }
	    }
	
	}
	
	function borrarValores(select)
	{
	    for (i=select.options.length; i>0; i--)
	    {
	    	select.options[i] = null;
	    }	
	    select.options[0] = null;
	}
	
	/*
	* Visualiza una rubrica
	*/
	function boton()
	{
		var f = document.getElementById("v");
		var rubricas = document.getElementById("rub");
		var rubrica = "";
		
		for (i=rubricas.options.length-1; i>=0; i--)
	    {
	    	if (rubricas.options[i].selected == true)
	    	{
	    		rubrica = rubricas.options[i].value;
	    		break;
	    	}
	    }
	    	
		f.action = "<?php echo $url ?>" + 'pg/view/' + rubrica + "?search_viewtype=gallery";
		f.submit();
	}
	
	function mostrar()
	{
		var radio = document.getElementById('tipoeval');
		if (radio.checked)
		{
			div = document.getElementById('select');
			div.style.display = '';
		}
	}
	
	function ocultar()
	{
		var radio = document.getElementById('numerica');
		if (radio.checked)
		{
			div = document.getElementById('select');
			div.style.display='none';
		}
	}
	
</script>

<?php
	
	// Tipo de evaluación
	echo "<h4>". elgg_echo('rubricas:tipoeval') . "</h4>";
	echo "<BR>";

	echo "<input type='radio' name='tipoevaluacion' value='rubrica' id='tipoeval' onclick='mostrar()'>".elgg_echo('rubricas:evalrubric');
	echo "<br>";
	$seleccionar =  "<fieldset id='select' style='display:none;' class='seleccionar'>";
	$seleccionar .=  elgg_echo('rubricas:seleccionar');
	$seleccionar .= "<a href='".$vars['url']."pg/rubrics/crear/' style='color: #4690D6'>".elgg_echo('rubricas:crear')."</a><br><br>"; 

	// Mostrar las rúbricas disponibles
	$rubricas = get_entities ("object", "rubrica");
	if ($rubricas != "")
	{
		$select .= "<select name=rubrica id=rub>";
		$rubricas = get_entities ("object", "rubrica");
		foreach ($rubricas as $r)
		{
			if ($r->title != " ") 
			{
				$select .= "<option value='".$r->guid."'>{$r->title}</option>";
			}	
		}	
		$ver .= "<input type=\"button\" class=\"boton\" value=\"".elgg_echo('rubricas:view')."\" name=\"visualizar\" onclick=\"boton();\" title=\"".elgg_echo('rubricas:view')."\">";
	
		$select .= "</select> &nbsp;" . $ver;
		
		// Etiquetas
		$filtro .= "<select name='filtro' id='filtro'>";
		$filtro .= "<option value='0'>".elgg_echo('rubricas:all')."</option>";
		$tag = explode(",", $tags);
		$tag = array_unique($tag);
		
		foreach ($tag as $t)
		{
			if ($t != "")
				$filtro .= "<option value='".$t."'>{$t}</option>";
		}
		
		$filtro .= "</select> &nbsp;";
		$filtro .= "<input type=\"Button\" value=\"".elgg_echo('rubricas:filter')."\" class=\"boton\" onClick=\"filtrar(filtro, rubrica)\">";
		$filtro .= "<br><br>";
		$seleccionar .=  elgg_echo('rubricas:filter');
		$seleccionar .=  "<br><br>";
		$seleccionar .=  $filtro;
		$seleccionar .=  $select;
		$seleccionar .=  "<br><br>";
		
	} 
	else 
		$seleccionar .=  elgg_echo('rubricas:rubricnotexist');
		
	$seleccionar .=  "</fieldset>"; 
	echo $seleccionar;
	
	// Nota numerica
	echo "<input type='radio' name='tipoevaluacion' value='numerica' id='numerica' onclick='ocultar()'>".elgg_echo('rubricas:evalnumeric');

	echo "<BR><BR>";
	
?>