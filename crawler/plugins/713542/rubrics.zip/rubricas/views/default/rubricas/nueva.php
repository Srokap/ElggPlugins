<?php

/*
* views/default/rubricas/crear
* Formulario para creación de una nueva rúbrica
*
* @package ElggRubric
*/

global $CONFIG;

// Librería
require_once($CONFIG->pluginspath . "/rubricas/lib/functions.php");

?>	
	
	<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/rubricas/views/default/js/scripts.js"></script>
	
<?php

	echo "<form name='val' action='". $vars['url'] ."action/rubrics/guardar' method='post'>";

	echo "<div class='rubrics_new'>";
	
	echo elgg_echo('rubricas:introducir_datos');
	echo "<BR><i style='color:#a9a9a9'>";
	echo elgg_echo('rubricas:texto2') . "</i>";
		
	echo "<br><br><br>";
	
	echo "<div class='rubric-content'>";
	
	$r = create_new();
	echo create_table($r, $vars['url']);
		
	echo "<BR><BR>";
	echo "</div>";
	
	echo "<BR>";
	echo "<input type='hidden' name='filas' id='filas' value=4>";
	echo "<input type='hidden' name='cols' id = 'cols' value=4>";

	// Acceso de la rubrica
	$access_input = elgg_view('input/access', array('internalname' => 'access_id', 'value' => $access_id));
	echo elgg_echo('rubricas:acceso');
	echo "<BR>";
	echo $access_input;
	
	//Etiquetas
	echo "<BR><BR>";
	echo elgg_echo('rubricas:tags');
	echo "<BR>";
	echo elgg_view('input/tags',array('internalname' => 'tags'));
	echo "<BR><BR>";
	
	
	echo "<center><input type='button' value='". elgg_echo('rubricas:enviar') ."' onclick='valida()' class='boton' title='Enviar'></center>";
	
	echo elgg_view('input/securitytoken'); 
	
	echo "</div>";
	echo "</form>";
	
	echo "<center><form name='volver' action='". $vars['url'] ."mod/rubricas/pages/crear.php' method='post'>";
	echo "<input type='submit' value='". elgg_echo('rubricas:volver') ."' name='volver' title='Volver'></form></center>";
	
?>	