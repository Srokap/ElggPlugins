<?php
	/**
	 * views/csv/exportar.php
	 * Permite exportar una rúbrica
	 * 
	 * @package ElggRubric
	 */

	require_once(dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "/engine/start.php");

	// Coger el guid
	$guid = get_input("rubrica");

	// Coger el fichero
	$rubrica = get_entity($guid);

	if ($rubrica)
	{
		$filename = $rubrica->title . ".csv";
		// Para IE
		header("Content-type: text/csv");
		header("Content-Disposition: attachment; filename=\"$filename\"");
		header("Pragma: no-cache");
		header("Expires: 0");
	
		$separator = ";";
		
		// Titulo y descripcion de puntos
		$pdesc = str_replace("#", ";", $rubrica->pdesc); 
		echo utf8_decode($rubrica->title) . $separator . $pdesc . "\n";
		
		// puntos
		$puntos = str_replace("#", ";", $rubrica->puntos); 
		echo " ;" . $puntos . "\n";
		
		// Criterio y descripciones
		$nc = 0;
		$nd = 0;
		$ncd = 0;
		   			
		$ar1 = explode('#', $rubrica->criterio);
		$ar2 = explode('#', $rubrica->desc);
		$cd = explode('#', $rubrica->cdesc);
		$pd =  explode('#', $rubrica->pdesc);
		
		$replace = array("\r\n", "\n\r", "\n", "\r");
		
		for ($i=0; $i<$rubrica->filas-1; $i++)
		{
			for ($j=0; $j<$rubrica->cols; $j++)
			{
				if ($j == 0)
				{
					$f1 .= utf8_decode(str_replace($replace," ",$ar1[$nc])) . $separator;
					$f2 .= utf8_decode(str_replace($replace," ",$cd[$ncd])) . $separator; 
					$nc++;
					$ncd++;
				}
				else
				{
					$f1 .= utf8_decode(str_replace($replace," ",$pd[$j-1])) . $separator;
					$f2 .= utf8_decode(str_replace($replace," ",$ar2[$nd])) . $separator; 
					$nd++;				
				}
			}
			echo $f1 . "\n";
			echo $f2 . "\n";
			$f1 = "";
			$f2 = "";
		}
		
		exit; 
	}
	else
	{
		register_error(elgg_echo("rubricas:failed"));
		forward();
	}
	
?>