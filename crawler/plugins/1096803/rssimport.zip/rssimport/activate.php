<?php

add_subtype('object','rssimport');