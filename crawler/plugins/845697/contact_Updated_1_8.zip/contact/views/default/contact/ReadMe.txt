___Contact Form code from html-form-guide.com___
See the article here: 
http://www.html-form-guide.com/contact-form/creating-a-contact-form.html


Installing the form____
1. Edit the file contactform.php and update your email address.

2. Upload the entire folder to your web site. 

3. Link to contactform.php or embed using iframe.
see: http://www.html-form-guide.com/contact-form/embed-contact-form.html

You can customize almost every aspect of this form.

Visit html-form-guide.com for more info.


License____
This program is free software published under the terms of the GNU Lesser General Public License.
You can freely use it on commercial or non-commercial websites. 
