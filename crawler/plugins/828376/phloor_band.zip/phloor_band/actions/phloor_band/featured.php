<?php	

$band_guid = get_input('phloor_band_guid');
$action = get_input('action_type');

$band = get_entity($band_guid);

if (!phloor_band_instanceof($band)) {
	register_error(elgg_echo('phloor_band:featured_error'));
	forward(REFERER);
}

//get the action, is it to feature or unfeature
if ($action == "feature") {
	$band->featured_phloor_band = "yes";
	system_message(elgg_echo('phloor_band:featuredon', array($band->name)));
} else {
	$band->featured_phloor_band = "no";
	system_message(elgg_echo('phloor_band:unfeatured', array($band->name)));
}

forward(REFERER);
