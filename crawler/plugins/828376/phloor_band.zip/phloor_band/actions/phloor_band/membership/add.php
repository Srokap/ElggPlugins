<?php
/**
 * Add users to a band
 *
 */	
$logged_in_user = elgg_get_logged_in_user_entity();

$user_guid = get_input('user_guid');
if (!is_array($user_guid)) {
	$user_guid = array($user_guid);
}
$band_guid = get_input('phloor_band_guid');
$band = get_entity($band_guid);

if (sizeof($user_guid)) {
	foreach ($user_guid as $u_id) {
		$user = get_user($u_id);

		if ($user && phloor_band_instanceof($band) && $band->canEdit()) {
			if (!$band->isMember($user)) {
				if (groups_join_group($band, $user)) {

					// send welcome email to user
					notify_user($user->getGUID(), $band->owner_guid,
							elgg_echo('phloor_band:welcome:subject', array($band->name)),
							elgg_echo('phloor_band:welcome:body', array(
								$user->name,
								$band->name,
								$band->getURL())
							));

					system_message(elgg_echo('phloor_band:addedtophloor_band'));
				} else {
					// huh
				}
			}
		}
	}
}

forward(REFERER);
