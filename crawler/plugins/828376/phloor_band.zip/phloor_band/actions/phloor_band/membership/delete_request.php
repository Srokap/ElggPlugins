<?php
/**
 * Delete a request to join a band
 */
$user_guid = get_input('user_guid', elgg_get_logged_in_user_guid());
$band_guid = get_input('phloor_band_guid');

$user = get_entity($user_guid);
$band = get_entity($band_guid);

if (check_entity_relationship($user->guid, 'membership_request', $band->guid)) {
	remove_entity_relationship($user->guid, 'membership_request', $band->guid);
	system_message(elgg_echo("phloor_band:joinrequestkilled"));
}

forward(REFERER);
