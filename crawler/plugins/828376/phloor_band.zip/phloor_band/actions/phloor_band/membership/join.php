<?php
/**
 * Join a band
 */
global $CONFIG;
	
$user_guid = get_input('user_guid', elgg_get_logged_in_user_guid());
$band_guid = get_input('phloor_band_guid');

$user = get_entity($user_guid);

// access bypass for getting invisible phloor_band
$ia = elgg_set_ignore_access(true);
$band = get_entity($band_guid);
elgg_set_ignore_access($ia);

if (($user instanceof ElggUser) && phloor_band_instanceof($band)) {
	// join or request
	$join = false;
	if ($band->canEdit($user->guid)) {
		$join = true;
	} else {
		if (check_entity_relationship($band->guid, 'invited', $user->guid)) {
			// user has invite to closed phloor_band
			$join = true;
		}
	}

	if ($join) {
		if (phloor_band_join_band($band, $user)) {
			system_message(elgg_echo("phloor_band:joined"));
			forward($band->getURL());
		} else {
			register_error(elgg_echo("phloor_band:cantjoin"));
		}
	} else {
		add_entity_relationship($user->guid, 'membership_request', $band->guid);

		// Notify phloor_band owner
		$url = "{$CONFIG->url}phloor_band/requests/$band->guid";
		$subject = elgg_echo('phloor_band:request:subject', array(
			$user->name,
			$band->name,
		));
		$body = elgg_echo('phloor_band:request:body', array(
			$band->getOwnerEntity()->name,
			$user->name,
			$band->name,
			$user->getURL(),
			$url,
		));
		if (notify_user($band->owner_guid, $user->getGUID(), $subject, $body)) {
			system_message(elgg_echo("phloor_band:joinrequestmade"));
		} else {
			register_error(elgg_echo("phloor_band:joinrequestnotmade"));
		}
	}
} else {
	register_error(elgg_echo("phloor_band:cantjoin"));
}

forward(REFERER);
