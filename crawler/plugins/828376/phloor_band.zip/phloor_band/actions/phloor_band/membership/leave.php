<?php
/**
 * Leave a band
 */
$user_guid = get_input('user_guid');
$band_guid = get_input('phloor_band_guid');

$user = NULL;
if (!$user_guid) {
	$user = elgg_get_logged_in_user_entity();
} else {
	$user = get_entity($user_guid);
}

$band = get_entity($band_guid);

elgg_set_page_owner_guid($band->guid);

if (($user instanceof ElggUser) && phloor_band_instanceof($band)) {
	if ($band->getOwnerGUID() != elgg_get_logged_in_user_guid()) {
		if ($band->leave($user)) {
			system_message(elgg_echo("phloor_band:left"));
		} else {
			register_error(elgg_echo("phloor_band:cantleave"));
		}
	} else {
		register_error(elgg_echo("phloor_band:cantleave"));
	}
} else {
	register_error(elgg_echo("phloor_band:cantleave"));
}

forward(REFERER);
