<?php
/**
 * Remove a band memeber
 */
$user_guid = get_input('user_guid');
$band_guid = get_input('phloor_band_guid');

$user = get_entity($user_guid);
$band = get_entity($band_guid);

elgg_set_page_owner_guid($band->guid);

if (($user instanceof ElggUser) && phloor_band_instanceof($band) && $band->canEdit()) {
	// don't allow removing band owner
	if ($band->getOwnerGUID() != $user->getGUID()) {
		if ($band->leave($user)) {
			system_message(elgg_echo("phloor_band:removed", array($user->name)));
		} else {
			register_error(elgg_echo("phloor_band:cantremove"));
		}
	} else {
		register_error(elgg_echo("phloor_band:cantremove"));
	}
} else {
	register_error(elgg_echo("phloor_band:cantremove"));
}

forward(REFERER);
