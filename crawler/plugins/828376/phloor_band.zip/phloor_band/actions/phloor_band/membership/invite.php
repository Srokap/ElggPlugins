<?php
/**
 * Invite users to join a band
 */
$logged_in_user = elgg_get_logged_in_user_entity();

$user_guid = get_input('user_guid');
if (!is_array($user_guid)) {
	$user_guid = array($user_guid);
}
$band_guid = get_input('phloor_band_guid');

if (sizeof($user_guid)) {
	foreach ($user_guid as $u_id) {
		$user = get_entity($u_id);
		$band = get_entity($band_guid);

		if ($user && $band && phloor_band_instanceof($band) && $band->canEdit()) {

			if (!check_entity_relationship($band->guid, 'invited', $user->guid)) {

				// Create relationship
				add_entity_relationship($band->guid, 'invited', $user->guid);

				// Send email
				$url = elgg_normalize_url("phloor_band/invitations/$user->username");
				$result = notify_user($user->getGUID(), $band->owner_guid,
						elgg_echo('phloor_band:invite:subject', array($user->name, $band->name)),
						elgg_echo('phloor_band:invite:body', array(
							$user->name,
							$logged_in_user->name,
							$band->name,
							$url,
						)),
						NULL);
				if ($result) {
					system_message(elgg_echo("phloor_band:userinvited"));
				} else {
					register_error(elgg_echo("phloor_band:usernotinvited"));
				}
			} else {
				register_error(elgg_echo("phloor_band:useralreadyinvited"));
			}
		}
	}
}

forward(REFERER);
