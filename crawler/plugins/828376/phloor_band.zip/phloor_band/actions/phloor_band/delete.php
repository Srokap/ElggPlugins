<?php
/**
 * Delete a band
 */
		
$guid = (int) get_input('guid');
if (!$guid) {
	$guid = (int)get_input('phloor_band_guid');
}
$band = get_entity($guid);

if (!phloor_band_instanceof($band) || !$band->canEdit()) {
	register_error(elgg_echo('phloor_band:notdeleted'));
	forward(REFERER);
}

if (($band) && phloor_band_instanceof($band)) {
	// delete phloor_band icons
	$owner_guid = $band->owner_guid;
	$prefix = "phloor_band/" . $band->guid;
	$imagenames = array('.jpg', 'tiny.jpg', 'small.jpg', 'medium.jpg', 'large.jpg');
	$img = new ElggFile();
	$img->owner_guid = $owner_guid;
	foreach ($imagenames as $name) {
		$img->setFilename($prefix . $name);
		$img->delete();
	}

	// delete phloor_band
	if ($band->delete()) {
		system_message(elgg_echo('phloor_band:deleted'));
	} else {
		register_error(elgg_echo('phloor_band:notdeleted'));
	}
} else {
	register_error(elgg_echo('phloor_band:notdeleted'));
}

$url_name = elgg_get_logged_in_user_entity()->username;
forward(elgg_get_site_url() . "phloor_band/member/{$url_name}");
