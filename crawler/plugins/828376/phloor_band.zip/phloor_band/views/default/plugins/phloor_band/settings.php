<?php
/**
 * Groups plugin settings
 */

// set default value
if (!isset($vars['entity']->hidden_phloor_band)) {
	$vars['entity']->hidden_phloor_band = 'no';
}

echo '<div>';
echo elgg_echo('phloor_band:allowhiddenphloor_band');
echo ' ';
echo elgg_view('input/dropdown', array(
	'name' => 'params[hidden_phloor_band]',
	'options_values' => array(
		'no' => elgg_echo('option:no'),
		'yes' => elgg_echo('option:yes')
	),
	'value' => $vars['entity']->hidden_phloor_band,
));
echo '</div>';
