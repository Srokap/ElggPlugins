<?php
/**
 * Elgg Groups css
 * 
 * @package phloor_band
 */

?>
.phloor_band-profile > .elgg-image {
	margin-right: 10px;
}

.phloor_band-stats {
	background: #eeeeee;
	padding: 5px;
	margin-top: 10px;
	
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	border-radius: 5px;
}

.phloor_band-profile-fields .odd,
.phloor_band-profile-fields .even {
	background: #f4f4f4;
	
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	border-radius: 4px;
	
	padding: 2px 4px;
	margin-bottom: 7px;
}

.phloor_band-profile-fields .elgg-output {
	margin: 0;
}

#phloor_band-tools > li {
	width: 48%;
	min-height: 200px;
	margin-bottom: 40px;
}

#phloor_band-tools > li:nth-child(odd) {
	margin-right: 4%;
}

.phloor_band-widget-viewall {
	float: right;
	font-size: 85%;
}

.phloor_band-latest-reply {
	float: right;
}
