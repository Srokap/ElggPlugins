<?php
/**
 * Layout of the band profile page
 */
echo elgg_view('phloor_band/profile/summary', $vars);
echo elgg_view('phloor_band/profile/widgets', $vars);
