<?php

$url = elgg_get_site_url() . 'phloor_band/search';
$body = elgg_view_form('phloor_band/search', array(
	'action' => $url,
	'method' => 'get',
	'disable_security' => true,
));

echo elgg_view_module('aside', elgg_echo('phloor_band:searchtag'), $body);
