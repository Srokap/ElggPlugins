<?php
/**
 * Group profile summary
 *
 * Icon and profile fields
 *
 * @uses $vars['group']
 */

if (!isset($vars['entity']) || !$vars['entity']) {
	echo elgg_echo('phloor_band:notfound');
	return true;
}

$group = $vars['entity'];
$owner = $group->getOwnerEntity();

?>
<div class="phloor_band-profile clearfix elgg-image-block">
	<div class="elgg-image">
		<div class="phloor_band-profile-icon">
			<?php echo elgg_view_entity_icon($group, 'large', array('href' => '')); ?>
		</div>
		<div class="phloor_band-stats">
			<?php /*<p>
				<b><php echo elgg_echo("phloor_band:owner"); >: </b>
				<php
					echo elgg_view('output/url', array(
						'text' => $owner->name,
						'value' => $owner->getURL(),
						'is_trusted' => true,
					));
				>
			</p>*/ 
			?>
			<p>
			<?php
				echo elgg_echo('phloor_band:members') . ": " . $group->getMembers(0, 0, TRUE);
			?>
			</p>
		</div>
	</div>

	<div class="phloor_band-profile-fields elgg-body">
		<?php
			echo elgg_view('phloor_band/profile/fields', $vars);
		?>
	</div>
</div>
<?php
?>

