<?php
/**
 * Band members sidebar
 *
 *
 * @uses $vars['entity'] Band entity
 * @uses $vars['limit']  The number of band members to display
 */

$limit = elgg_extract('limit', $vars, 99);

$title_link = elgg_view('output/url', array(
	'href' => 'phloor_band/members/' . $vars['entity']->guid,
	'text' => elgg_echo('phloor_band:members'),
	'is_trusted' => true,
));

$body = elgg_list_entities_from_relationship(array(
	'relationship' => 'member',
	'relationship_guid' => $vars['entity']->guid,
	'inverse_relationship' => true,
	'types' => 'user',
	'limit' => $limit,
	'list_type' => 'gallery',
	'gallery_class' => 'elgg-gallery-users',
));

echo elgg_view_module('aside', $title_link, $body);
