
$(function() {
	// jQuery uses 0-based indexing
	$('#phloor_band-tools').children('li:even').addClass('odd');
});
