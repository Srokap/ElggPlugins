<?php
/**
* Profile widgets/tools
*/ 
	
// tools widget area
echo '<ul id="phloor_band-tools" class="elgg-gallery elgg-gallery-fluid mtl clearfix">';

// enable tools to extend this area
//echo elgg_view("phloor_band/tool_latest", $vars);
echo elgg_view("groups/tool_latest", $vars);

echo "</ul>";

