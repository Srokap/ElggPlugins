<?php
/**
 * All phloor_band listing page navigation
 *
 */

$tabs = array(
	'newest' => array(
		'text' => elgg_echo('phloor_band:newest'),
		'href' => 'phloor_band/all?filter=newest',
		'priority' => 200,
	),
	'popular' => array(
		'text' => elgg_echo('phloor_band:popular'),
		'href' => 'phloor_band/all?filter=popular',
		'priority' => 300,
	),
	'discussion' => array(
		'text' => elgg_echo('phloor_band:latestdiscussion'),
		'href' => 'phloor_band/all?filter=discussion',
		'priority' => 400,
	),
);

// sets default selected item
if (strpos(full_url(), 'filter') === false) {
	$tabs['newest']['selected'] = true;
}

foreach ($tabs as $name => $tab) {
	$tab['name'] = $name;

	elgg_register_menu_item('filter', $tab);
}

echo elgg_view_menu('filter', array('sort_by' => 'priority', 'class' => 'elgg-menu-hz'));
