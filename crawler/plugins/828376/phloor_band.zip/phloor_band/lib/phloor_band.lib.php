<?php
/**
 * phloor_bands function library
 */

/**
 * List all phloor_band
 */
function phloor_band_handle_all_page() {

	// all phloor_band doesn't get link to self
	elgg_pop_breadcrumb();
	elgg_push_breadcrumb(elgg_echo('phloor_band'));

	elgg_register_title_button();

	$selected_tab = get_input('filter', 'newest');

	switch ($selected_tab) {
		case 'popular':
			$content = elgg_list_entities_from_relationship_count(array(
				'type' => 'group',
				'subtype' => 'phloor_band',
				'relationship' => 'member',
				'inverse_relationship' => false,
				'full_view' => false,
			));
			if (!$content) {
				$content = elgg_echo('phloor_band:none');
			}
			break;
		case 'newest':
		default:
			$content = elgg_list_entities(array(
				'type' => 'group',
				'subtype' => 'phloor_band',
				'full_view' => false,
			));
			if (!$content) {
				$content = elgg_echo('phloor_band:none');
			}
			break;
	}

	$filter = elgg_view('phloor_band/phloor_band_sort_menu', array('selected' => $selected_tab));
	
	$sidebar = elgg_view('phloor_band/sidebar/find');
	$sidebar .= elgg_view('phloor_band/sidebar/featured');

	$params = array(
		'content' => $content,
		'sidebar' => $sidebar,
		'filter' => $filter,
	);
	$body = elgg_view_layout('content', $params);

	echo elgg_view_page(elgg_echo('phloor_band:all'), $body);
}

function phloor_band_search_page() {
	elgg_push_breadcrumb(elgg_echo('search'));

	$tag = get_input("tag");
	$title = elgg_echo('phloor_band:search:title', array($tag));

	// phloor_band plugin saves tags as "interests" - see phloor_band_fields_setup() in start.php
	$params = array(
		'metadata_name' => 'interests',
		'metadata_value' => $tag,
		'types' => 'group',
	    'subtypes' => 'phloor_band',
		'full_view' => FALSE,
	);
	$content = elgg_list_entities_from_metadata($params);
	if (!$content) {
		$content = elgg_echo('phloor_band:search:none');
	}

	$sidebar = elgg_view('phloor_band/sidebar/find');
	$sidebar .= elgg_view('phloor_band/sidebar/featured');

	$params = array(
		'content' => $content,
		'sidebar' => $sidebar,
		'filter' => false,
		'title' => $title,
	);
	$body = elgg_view_layout('content', $params);

	echo elgg_view_page($title, $body);
}

/**
 * List owned phloor_band
 */
function phloor_band_handle_owned_page() {

	$page_owner = elgg_get_page_owner_entity();

	$title = elgg_echo('phloor_band:owned');
	elgg_push_breadcrumb($title);

	elgg_register_title_button();

	$content = elgg_list_entities(array(
		'type' => 'group',
		'subtype' => 'phloor_band',
		'owner_guid' => elgg_get_page_owner_guid(),
		'full_view' => false,
	));
	if (!$content) {
		$content = elgg_echo('phloor_band:none');
	}

	$params = array(
		'content' => $content,
		'title' => $title,
		'filter' => '',
	);
	$body = elgg_view_layout('content', $params);

	echo elgg_view_page($title, $body);
}

/**
 * List phloor_band the user is memober of
 */
function phloor_band_handle_mine_page() {

	$page_owner = elgg_get_page_owner_entity();

	$title = elgg_echo('phloor_band:yours');
	elgg_push_breadcrumb($title);

	elgg_register_title_button();

	$content = elgg_list_entities_from_relationship_count(array(
		'type' => 'group',
		'subtype' => 'phloor_band',
		'relationship' => 'member',
		'relationship_guid' => elgg_get_page_owner_guid(),
		'inverse_relationship' => false,
		'full_view' => false,
	));
	if (!$content) {
		$content = elgg_echo('phloor_band:none');
	}

	$params = array(
		'content' => $content,
		'title' => $title,
		'filter' => '',
	);
	$body = elgg_view_layout('content', $params);

	echo elgg_view_page($title, $body);
}

/**
 * Create or edit a phloor_band
 *
 * @param string $page
 * @param int $guid
 */
function phloor_band_handle_edit_page($page, $guid = 0) {
	gatekeeper();
	
	if ($page == 'add') {
		elgg_set_page_owner_guid(elgg_get_logged_in_user_guid());
		$title = elgg_echo('phloor_band:add');
		elgg_push_breadcrumb($title);
		$content = elgg_view('phloor_band/edit');
	} else {
		$title = elgg_echo("phloor_band:edit");
		$band = get_entity($guid);

		if ($band && $band->canEdit()) {
			elgg_set_page_owner_guid($band->getGUID());
			elgg_push_breadcrumb($band->name, $band->getURL());
			elgg_push_breadcrumb($title);
			$content = elgg_view("phloor_band/edit", array('entity' => $band));
		} else {
			$content = elgg_echo('phloor_band:noaccess');
		}
	}
	
	$params = array(
		'content' => $content,
		'title' => $title,
		'filter' => '',
	);
	$body = elgg_view_layout('content', $params);

	echo elgg_view_page($title, $body);
}

/**
 * phloor_band invitations for a user
 */
function phloor_band_handle_invitations_page() {
	gatekeeper();

	$user = elgg_get_page_owner_entity();

	$title = elgg_echo('phloor_band:invitations');
	elgg_push_breadcrumb($title);

	// @todo temporary workaround for exts #287.
	$invitations = phloor_band_get_invited_phloor_band(elgg_get_logged_in_user_guid());
	$content = elgg_view('phloor_band/invitationrequests', array('invitations' => $invitations));

	$params = array(
		'content' => $content,
		'title' => $title,
		'filter' => '',
	);
	$body = elgg_view_layout('content', $params);

	echo elgg_view_page($title, $body);
}

/**
 * phloor_band profile page
 *
 * @param int $guid phloor_band entity GUID
 */
function phloor_band_handle_profile_page($guid) {
	elgg_set_page_owner_guid($guid);

	// turn this into a core function
	global $autofeed;
	$autofeed = true;

	$band = get_entity($guid);
	if (!$band) {
		forward('phloor_band/all');
	}

	elgg_push_breadcrumb($band->name);

	$content = elgg_view('phloor_band/profile/layout', array('entity' => $band));
	$sidebar = elgg_view('phloor_band/sidebar/members', array('entity' => $band));

	phloor_band_register_profile_buttons($band);

	$params = array(
		'content' => $content,
		'sidebar' => $sidebar,
		'title' => $band->name,
		'filter' => '',
	);
	$body = elgg_view_layout('content', $params);

	echo elgg_view_page($band->name, $body);
}

/**
 * phloor_band activity page
 *
 * @param int $guid phloor_band entity GUID
 */
function phloor_band_handle_activity_page($guid) {

	elgg_set_page_owner_guid($guid);

	$band = get_entity($guid);
	if (!$band || !phloor_band_instanceof($band)) {
		forward();
	}

	$title = elgg_echo('phloor_band:activity');

	elgg_push_breadcrumb($band->name, $band->getURL());
	elgg_push_breadcrumb($title);

	$db_prefix = elgg_get_config('dbprefix');

	$content = elgg_list_river(array(
		'joins' => array("JOIN {$db_prefix}entities e ON e.guid = rv.object_guid"),
		'wheres' => array("e.container_guid = $guid")
	));
	if (!$content) {
		$content = '<p>' . elgg_echo('phloor_band:activity:none') . '</p>';
	}
	
	$params = array(
		'content' => $content,
		'title' => $title,
		'filter' => '',
	);
	$body = elgg_view_layout('content', $params);

	echo elgg_view_page($title, $body);
}

/**
 * phloor_band members page
 *
 * @param int $guid phloor_band entity GUID
 */
function phloor_band_handle_members_page($guid) {

	elgg_set_page_owner_guid($guid);

	$band = get_entity($guid);
	if (!$band || !phloor_band_instanceof($band)) {
		forward();
	}

	$title = elgg_echo('phloor_band:members:title', array($band->name));

	elgg_push_breadcrumb($band->name, $band->getURL());
	elgg_push_breadcrumb(elgg_echo('phloor_band:members'));

	$content = elgg_list_entities_from_relationship(array(
		'relationship' => 'member',
		'relationship_guid' => $band->guid,
		'inverse_relationship' => true,
		'types' => 'user',
		'limit' => 20,
	));

	$params = array(
		'content' => $content,
		'title' => $title,
		'filter' => '',
	);
	$body = elgg_view_layout('content', $params);

	echo elgg_view_page($title, $body);
}

/**
 * Invite users to a phloor_band
 *
 * @param int $guid phloor_band entity GUID
 */
function phloor_band_handle_invite_page($guid) {
	gatekeeper();

	elgg_set_page_owner_guid($guid);

	$band = get_entity($guid);

	$title = elgg_echo('phloor_band:invite:title');

	elgg_push_breadcrumb($band->name, $band->getURL());
	elgg_push_breadcrumb(elgg_echo('phloor_band:invite'));

	if ($band && $band->canEdit()) {
		$content = elgg_view_form('phloor_band/invite', array(
			'id' => 'invite_to_phloor_band',
			'class' => 'elgg-form-alt mtm',
		), array(
			'entity' => $band,
		));
	} else {
		$content .= elgg_echo('phloor_band:noaccess');
	}

	$params = array(
		'content' => $content,
		'title' => $title,
		'filter' => '',
	);
	$body = elgg_view_layout('content', $params);

	echo elgg_view_page($title, $body);
}

/**
 * Manage requests to join a phloor_band
 * 
 * @param int $guid phloor_band entity GUID
 */
function phloor_band_handle_requests_page($guid) {

	gatekeeper();

	elgg_set_page_owner_guid($guid);

	$band = get_entity($guid);

	$title = elgg_echo('phloor_band:membershiprequests');

	if ($band && $band->canEdit()) {
		elgg_push_breadcrumb($band->name, $band->getURL());
		elgg_push_breadcrumb($title);
		
		$requests = elgg_get_entities_from_relationship(array(
			'type' => 'user',
			'relationship' => 'membership_request',
			'relationship_guid' => $guid,
			'inverse_relationship' => true,
			'limit' => 0,
		));
		$content = elgg_view('phloor_band/membershiprequests', array(
			'requests' => $requests,
			'entity' => $band,
		));

	} else {
		$content = elgg_echo("phloor_band:noaccess");
	}

	$params = array(
		'content' => $content,
		'title' => $title,
		'filter' => '',
	);
	$body = elgg_view_layout('content', $params);

	echo elgg_view_page($title, $body);
}

/**
 * Registers the buttons for title area of the phloor_band profile page
 *
 * @param PhloorBand $band
 */
function phloor_band_register_profile_buttons($band) {

	$actions = array();

	// phloor_band owners
	if ($band->canEdit()) {
		// edit and invite
		$url = elgg_get_site_url() . "phloor_band/edit/{$band->getGUID()}";
		$actions[$url] = 'phloor_band:edit';
		$url = elgg_get_site_url() . "phloor_band/invite/{$band->getGUID()}";
		$actions[$url] = 'phloor_band:invite';
	}

	// phloor_band members
	if ($band->isMember(elgg_get_logged_in_user_entity())) {
		if ($band->getOwnerGUID() != elgg_get_logged_in_user_guid()) {
			// leave
			$url = elgg_get_site_url() . "action/phloor_band/leave?phloor_band_guid={$band->getGUID()}";
			$url = elgg_add_action_tokens_to_url($url);
			$actions[$url] = 'phloor_band:leave';
		}
	} 
	/*elseif (elgg_is_logged_in()) {
		// join - admins can always join.
		$url = elgg_get_site_url() . "action/phloor_band/join?phloor_band_guid={$band->getGUID()}";
		$url = elgg_add_action_tokens_to_url($url);
		//if ($band->isPublicMembership() || $band->canEdit()) {
		if ($band->canEdit()) {
			$actions[$url] = 'phloor_band:join';
		} else {
			// request membership
			$actions[$url] = 'phloor_band:joinrequest';
		}
	}*/

	if ($actions) {
		foreach ($actions as $url => $text) {
			elgg_register_menu_item('title', array(
				'name' => $text,
				'href' => $url,
				'text' => elgg_echo($text),
				'link_class' => 'elgg-button elgg-button-action',
			));
		}
	}
}


function phloor_band_instanceof($entity) {
    return elgg_instanceof($entity, 'group', 'phloor_band', 'PhloorBand');
}


/**
 * This function aborts the band join process
 * when i user tries to join a band without
 * an invitation.
 * 
 * @param unknown_type $event
 * @param unknown_type $type
 * @param unknown_type $object
 */
function phloor_band_prevent_user_without_invite_from_joining($event, $type, $object) {
	if($event == 'create' && $type == 'member') {
		if($object instanceof ElggRelationship) {
			$user_guid = $object->guid_one;
			$band_guid = $object->guid_two;
			
			$user = get_entity($user_guid);
			$band = get_entity($band_guid);
			
			if(phloor_band_instanceof($band) &&
			   elgg_instanceof($user, 'user')) {
				$invited = check_entity_relationship($band->guid, 'invited', $user->guid);
				
				if($user->isAdmin()) {
				    return true;
				}
				
				// if user is not invited and is not the owner or an admin
				// let the relationship be deleted by returning 'false'
				if (!$invited && !$band->canEdit()) {
					return false;
				}
			}
		}
	}
	
	return true;
}

/**
 * Join a user to a group, add river event, clean-up invitations
 *
 * @param ElggGroup $group
 * @param ElggUser  $user
 * @return bool
 */
function phloor_band_join_band($band, $user) {

	// access ignore so user can be added to access collection of invisible group
	$ia = elgg_set_ignore_access(TRUE);
	$result = $band->join($user);
	elgg_set_ignore_access($ia);
	
	if ($result) {
		// flush user's access info so the collection is added
		get_access_list($user->guid, 0, true);

		// Remove any invite or join request flags
		remove_entity_relationship($band->guid, 'invited', $user->guid);
		remove_entity_relationship($user->guid, 'membership_request', $band->guid);

		add_to_river('river/relationship/member/create', 'join', $user->guid, $band->guid);

		return true;
	}

	return false;
}


/**
 * Grabs bands by invitations
 * Have to override all access until there's a way override access to getter functions.
 *
 * @param int  $user_guid    The user's guid
 * @param bool $return_guids Return guids rather than ElggGroup objects
 *
 * @return array ElggGroups or guids depending on $return_guids
 */
function phloor_band_get_invited_phloor_band($user_guid, $return_guids = FALSE) {
	$ia = elgg_set_ignore_access(TRUE);
	$band = elgg_get_entities_from_relationship(array(
		'relationship' => 'invited',
		'relationship_guid' => $user_guid,
		'inverse_relationship' => TRUE,
		'limit' => 0,
	));
	elgg_set_ignore_access($ia);

	if ($return_guids) {
		$guids = array();
		foreach ($band as $band) {
			$guids[] = $band->getGUID();
		}

		return $guids;
	}

	return $band;
}


/**
 * Handle phloor_band icons.
 *
 * @param array $page
 * @return void
 */
function phloor_band_icon_handler($page) {

	// The username should be the file we're getting
	if (isset($page[0])) {
		set_input('phloor_band_guid', $page[0]);
	}
	if (isset($page[1])) {
		set_input('size', $page[1]);
	}
	// Include the standard profile index
	$plugin_dir = elgg_get_plugins_path();
	include("$plugin_dir/phloor_band/icon.php");
	return true;
}

