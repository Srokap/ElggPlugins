<?php

class PhloorBand extends ElggGroup {

	protected function initializeAttributes() {
		parent::initializeAttributes();

		$this->attributes['subtype'] = "phloor_band";
		$this->attributes['membership'] = ACCESS_PUBLIC;
	}
}
