<?php

update_subtype('group', 'phloor_band');
