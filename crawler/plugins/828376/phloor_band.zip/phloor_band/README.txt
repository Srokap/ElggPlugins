/**
 * Phloor Band
 * 
 * @package phloor_band
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * @author void <void@13net.at>
 * @copyright 13net
 * @link http://www.13net.at/
 */

/**
 * Description
 */
Enables creating bands on your Elgg site.

This plugin enables creating band objects that act
just like a group. A band can have one or more members - 
a user can have zero or more bands. Difference: A user 
must be invited before he is able to join a band.

Todo:
- Assigning roles (Guitar, Bass, Vocal, ...)
- Becoming a "fan"
- Tour dates
- improved graphics

/**
 * Languages
 */
English
German



