<?php

if (get_subtype_id('group', 'phloor_band')) {
	update_subtype('group', 'phloor_band', 'PhloorBand');
} else {
	add_subtype('group', 'phloor_band', 'PhloorBand');
}
