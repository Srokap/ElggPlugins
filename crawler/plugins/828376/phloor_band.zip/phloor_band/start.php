<?php

elgg_register_event_handler('init', 'system', 'phloor_band_init');
elgg_register_event_handler('init', 'system', 'phloor_band_fields_setup', 10000);


function phloor_band_init() {
	elgg_register_library('phloor-band', elgg_get_plugins_path() . 'phloor_band/lib/phloor_band.lib.php');
	elgg_load_library('phloor-band');
	
	$item = new ElggMenuItem('phloor_band', elgg_echo('phloor_band'), 'phloor_band/all');
	elgg_register_menu_item('site', $item);

	/**
	 * Url handler
	 */
	elgg_register_entity_url_handler('group', 'phloor_band', 'phloor_band_url');

	/**
	 * Page handler
	 */
	elgg_register_page_handler('phloor_band', 'phloor_band_page_handler');
	elgg_register_page_handler('phloor_bandicon', 'phloor_band_icon_handler');

	/**
	 * Actions
	 */
	$action_base = elgg_get_plugins_path() . 'phloor_band/actions/phloor_band';
	elgg_register_action("phloor_band/edit", "$action_base/edit.php");
	elgg_register_action("phloor_band/delete", "$action_base/delete.php");
	elgg_register_action("phloor_band/featured", "$action_base/featured.php", 'admin');

	$action_base .= '/membership';
	elgg_register_action("phloor_band/invite", "$action_base/invite.php");
	elgg_register_action("phloor_band/join", "$action_base/join.php");
	elgg_register_action("phloor_band/leave", "$action_base/leave.php");
	elgg_register_action("phloor_band/remove", "$action_base/remove.php");
	elgg_register_action("phloor_band/killrequest", "$action_base/delete_request.php");
	elgg_register_action("phloor_band/killinvitation", "$action_base/delete_invite.php");
	elgg_register_action("phloor_band/addtophloor_band", "$action_base/add.php");
	
	/**
	 * Search
	 */
	elgg_register_entity_type('group', 'phloor_band');
	
	/**
	 * Widgets
	 */
	elgg_register_widget_type('a_users_bands', elgg_echo('phloor_band:widget:membership'), elgg_echo('phloor_band:widgets:description'));

	/**
	 * JS/CSS
	 */
	elgg_extend_view('css/elgg', 'phloor_band/css');
	elgg_extend_view('js/elgg', 'phloor_band/js');

	/**
	 * Event handler
	 */
	elgg_register_event_handler('pagesetup', 'system', 'phloor_band_setup_sidebar_menus');

	elgg_register_event_handler('create', 'member', 'phloor_band_prevent_user_without_invite_from_joining');
	
	/**
	 * Plugin hook handler
	 */
	elgg_register_plugin_hook_handler('entity:icon:url', 'group', 'phloor_band_icon_url_override', 999);
	elgg_register_plugin_hook_handler('register', 'menu:entity', 'phloor_band_entity_menu_setup', 999);
	elgg_register_plugin_hook_handler('register', 'menu:user_hover', 'phloor_band_user_entity_menu_setup', 999);
}

/**
 * This function loads a set of default fields into the profile, then triggers
 * a hook letting other plugins to edit add and delete fields.
 *
 * Note: This is a system:init event triggered function and is run at a super
 * low priority to guarantee that it is called after all other plugins have
 * initialized.
 */
function phloor_band_fields_setup() {

	$profile_defaults = array(
		'briefdescription' => 'text',
		'description' => 'longtext',
		'genre' => 'tags',
		'website' => 'url',
		'interests' => 'tags',
	);

	$profile_defaults = elgg_trigger_plugin_hook('profile:fields', 'phloor_band', NULL, $profile_defaults);

	elgg_set_config('phloor_band', $profile_defaults);

	// register any tag metadata names
	foreach ($profile_defaults as $name => $type) {
		if ($type == 'tags') {
			elgg_register_tag_metadata_name($name);

			// only shows up in search but why not just set this in en.php as doing it here
			// means you cannot override it in a plugin
			add_translation(get_current_language(), array("tag_names:$name" => elgg_echo("phloor_band:$name")));
		}
	}
}

/**
 * Configure the phloor_band sidebar menu. Triggered on page setup
 *
 */
function phloor_band_setup_sidebar_menus() {

	// Get the page owner entity
	$page_owner = elgg_get_page_owner_entity();

	if (elgg_get_context() == 'phloor_band') {
		if (phloor_band_instanceof($page_owner)) {
			if (elgg_is_logged_in() && $page_owner->canEdit()) {
				$url = elgg_get_site_url() . "phloor_band/requests/{$page_owner->getGUID()}";
				elgg_register_menu_item('page', array(
					'name' => 'membership_requests',
					'text' => elgg_echo('phloor_band:membershiprequests'),
					'href' => $url,
				));
			}
		} else {
			elgg_register_menu_item('page', array(
				'name' => 'phloor_band:all',
				'text' => elgg_echo('phloor_band:all'),
				'href' => 'phloor_band/all',
			));

			$user = elgg_get_logged_in_user_entity();
			if ($user) {
				$url =  "phloor_band/owner/$user->username";
				$item = new ElggMenuItem('phloor_band:owned', elgg_echo('phloor_band:owned'), $url);
				elgg_register_menu_item('page', $item);
				$url = "phloor_band/member/$user->username";
				$item = new ElggMenuItem('phloor_band:member', elgg_echo('phloor_band:yours'), $url);
				elgg_register_menu_item('page', $item);
				$url = "phloor_band/invitations/$user->username";
				$item = new ElggMenuItem('phloor_band:user:invites', elgg_echo('phloor_band:invitations'), $url);
				elgg_register_menu_item('page', $item);
			}
		}
	}
}

/**
 * Groups page handler
 *
 * URLs take the form of
 *  All phloor_band:           phloor_band/all
 *  User's owned phloor_band:  phloor_band/owner/<username>
 *  User's member phloor_band: phloor_band/member/<username>
 *  Group profile:        phloor_band/profile/<guid>/<title>
 *  New phloor_band:            phloor_band/add/<guid>
 *  Edit phloor_band:           phloor_band/edit/<guid>
 *  Group invitations:    phloor_band/invitations/<username>
 *  Invite to phloor_band:      phloor_band/invite/<guid>
 *  Membership requests:  phloor_band/requests/<guid>
 *  Group members:        phloor_band/members/<guid>
 *
 * @param array $page Array of url segments for routing
 * @return bool
 */
function phloor_band_page_handler($page) {
	elgg_load_library('phloor-band');

	elgg_push_breadcrumb(elgg_echo('phloor_band'), "phloor_band/all");

	switch ($page[0]) {
		case 'all':
			phloor_band_handle_all_page();
			break;
		case 'search':
			phloor_band_search_page();
			break;
		case 'owner':
			phloor_band_handle_owned_page();
			break;
		case 'member':
			set_input('username', $page[1]);
			phloor_band_handle_mine_page();
			break;
		case 'invitations':
			set_input('username', $page[1]);
			phloor_band_handle_invitations_page();
			break;
		case 'add':
			phloor_band_handle_edit_page('add');
			break;
		case 'edit':
			phloor_band_handle_edit_page('edit', $page[1]);
			break;
		case 'profile':
			phloor_band_handle_profile_page($page[1]);
			break;
		case 'activity':
			phloor_band_handle_activity_page($page[1]);
			break;
		case 'members':
			phloor_band_handle_members_page($page[1]);
			break;
		case 'invite':
			phloor_band_handle_invite_page($page[1]);
			break;
		case 'requests':
			phloor_band_handle_requests_page($page[1]);
			break;
		default:
			return false;
	}
	return true;
}


/**
 * Populates the ->getUrl() method for phloor_band objects
 *
 * @param ElggEntity $entity File entity
 * @return string File URL
 */
function phloor_band_url($entity) {
	$title = elgg_get_friendly_title($entity->name);

	return "phloor_band/profile/{$entity->guid}/$title";
}

/**
 * Override the default entity icon for phloor_band
 *
 * @return string Relative URL
 */
function phloor_band_icon_url_override($hook, $type, $returnvalue, $params) {
    if($band instanceof PhloorBand) {
        return $returnvalue;
    }
    
	$band = $params['entity'];
	$size = $params['size'];

	if(!phloor_band_instanceof($band)) {
	    return $returnvalue;
	}
	
	if (isset($band->icontime)) {
		// return thumbnail
		$icontime = $band->icontime;
		return "phloor_bandicon/$band->guid/$size/$icontime.jpg";
	}

	return "mod/phloor_band/graphics/default{$size}.gif";
}


/**
 * Add links/info to entity menu particular to phloor_band entities
 */
function phloor_band_entity_menu_setup($hook, $type, $return, $params) {
	if (elgg_in_context('widgets')) {
		return $return;
	}

	$band = $params['entity'];
	if(!phloor_band_instanceof($band)) {
	    return $return;
	}
	
	$handler = elgg_extract('handler', $params, false);
	if ($handler != 'phloor_band') {
		return $return;
	}

	foreach ($return as $index => $item) {
		if (in_array($item->getName(), array('access', 'edit', 'delete'))) {
			unset($return[$index]);
		}
	}

	// number of members
	$num_members = get_group_members($band->guid, 10, 0, 0, true);
	$members_string = elgg_echo('phloor_band:member');
	$options = array(
		'name' => 'members',
		'text' => $num_members . ' ' . $members_string,
		'href' => false,
		'priority' => 200,
	);
	$return[] = ElggMenuItem::factory($options);

	// feature link
	if (elgg_is_admin_logged_in()) {
		if ($band->featured_phloor_band == "yes") {
			$url = "action/phloor_band/featured?phloor_band_guid={$band->guid}&action_type=unfeature";
			$wording = elgg_echo("phloor_band:makeunfeatured");
		} else {
			$url = "action/phloor_band/featured?phloor_band_guid={$band->guid}&action_type=feature";
			$wording = elgg_echo("phloor_band:makefeatured");
		}
		$options = array(
			'name' => 'feature',
			'text' => $wording,
			'href' => $url,
			'priority' => 300,
			'is_action' => true
		);
		$return[] = ElggMenuItem::factory($options);
	}

	return $return;
}

/**
 * Add a remove user link to user hover menu when the page owner is a phloor_band
 */
function phloor_band_user_entity_menu_setup($hook, $type, $return, $params) {
	if (elgg_is_logged_in()) {
		$band = elgg_get_page_owner_entity();
		$entity = $params['entity'];

		// make sure we have a user and that user is a member of the band
		if (!elgg_instanceof($entity, 'user') || 
		    !phloor_band_instanceof($band) || 
		    !$band->isMember($entity)) {
			return $return;
		}

		// add remove link if we can edit the phloor_band, and if we're not trying to remove the band owner
		if ($band->canEdit() && $band->getOwnerGUID() != $entity->guid) {
			$remove = elgg_view('output/confirmlink', array(
				'href' => "action/phloor_band/remove?user_guid={$entity->guid}&phloor_band_guid={$band->guid}",
				'text' => elgg_echo('phloor_band:removeuser'),
			));
			$options = array(
				'name' => 'removeuser',
				'text' => $remove,
				'priority' => 999,
			);
			$return[] = ElggMenuItem::factory($options);
			
			/*$assignisntrument = elgg_view('output/url', array(
				'href' => "phloor_band/instrument/{$band->guid}/{$entity->guid}",
				'text' => elgg_echo('phloor_band:assigninstrument'),
			));
			$options = array(
				'name' => 'assigninstrument',
				'text' => $assignisntrument,
				'priority' => 500,
			);
			$return[] = ElggMenuItem::factory($options);*/
			
		} 
	}

	return $return;
}


