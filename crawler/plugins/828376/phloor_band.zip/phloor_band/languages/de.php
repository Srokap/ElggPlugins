<?php

$german = array(

	'phloor_band' => "Bands",
	'phloor_band:owned' => "von mir gegründete Bands",
	'phloor_band:yours' => "Meine Bands",
	'phloor_band:user' => "%s's Bands",
	'phloor_band:all' => "Alle Bands",
	'phloor_band:add' => "Neue Band gründen",
	'phloor_band:edit' => "Band bearbeiten",
	'phloor_band:delete' => 'Band auflösen',
	'phloor_band:membershiprequests' => 'Beitrittsanfragen managen',
	'phloor_band:invitations' => 'Aufnahmeangebote',

	'phloor_band:icon' => 'Bandlogo (auslassen um unverändert zu lassen)',
	'phloor_band:name' => 'Bandname',
	'phloor_band:username' => 'Kurzname (wird in URLs angezeigt; nur Buchstaben möglich)',
	'phloor_band:description' => 'Über uns',
	'phloor_band:briefdescription' => 'Kurzbeschreibung',
	'phloor_band:interests' => 'Tags',
	'phloor_band:website' => 'Website',
	'phloor_band:genre' => 'Genre',

	'phloor_band:members' => 'Bandmitglieder',
	'phloor_band:members:title' => 'Mitglieder von %s',
	'phloor_band:members:more' => "Alle Mitglieder ansehen",
	'phloor_band:membership' => "Band-Mitgliedschaft Erlaubnis",
	'phloor_band:access' => "Zugriffserlaubnis",
	'phloor_band:owner' => "Gründer",
	'phloor_band:widget:num_display' => 'Anzahl der anzuzeigenden Bands',
	'phloor_band:widget:membership' => 'Bandmitgliedschaft',
	'phloor_band:widgets:description' => 'Zeigt die Bands, in denen du Mitglied bist, auf deinem Profil an. ',
	'phloor_band:noaccess' => 'Kein Zugriff auf die Band',
	'phloor_band:permissions:error' => 'Fehlende Berechtigung. ',
	'phloor_band:inband' => 'in der Band',
	'phloor_band:cantedit' => 'Du kannst die Band nicht editieren. ',
	'phloor_band:saved' => 'Band wurde gespeichert',
	'phloor_band:featured' => 'Featured Bands',
	'phloor_band:makeunfeatured' => 'Unfeature',
	'phloor_band:makefeatured' => 'Make featured',
	'phloor_band:featuredon' => '%s is now a featured band.',
	'phloor_band:unfeatured' => '%s has been removed from the featured bands.',
	'phloor_band:featured_error' => 'Invalide Band.',
	'phloor_band:joinrequest' => 'Mitgliedsanfragen',
	'phloor_band:join' => 'Band beitreten',
	'phloor_band:leave' => 'Aus Band austreten',
	'phloor_band:invite' => 'Freunde einladen',
	'phloor_band:invite:title' => 'Lade Freunde zu der Band ein',
	'phloor_band:inviteto' => "Lade Freunde zu '%s' ein",
	'phloor_band:nofriends' => "Es können keine weiteren Freunde eingeladen werden.",
	'phloor_band:nofriendsatall' => 'Du hast noch keine Freunde, die du einladen könntest!',
	'phloor_band:viaphloor_band' => "via Band",
	'phloor_band:band' => "Band",
	'phloor_band:search:tags' => "tag",
	'phloor_band:search:title' => "Suche nach Bands mit dem Tag '%s'",
	'phloor_band:search:none' => "Es konnten keine Bands gefunden werden. ",

	'phloor_band:notfound' => "Band nicht gefunden",
	'phloor_band:notfound:details' => "Invalide Anfrage. Band existiert nicht, oder fehlende Berechtigung. ",

	'phloor_band:requests:none' => 'Es liegen zur Zeit keine Mitgliedsanfragen vor.',

	'phloor_band:invitations:none' => 'Es liegen momentan keine Beitrittsangebote vor. ',

	'phloor_band:count' => "gegründete Bands",
	'phloor_band:member' => "Mitglieder",
	'phloor_band:searchtag' => "Suche eine Band nach Tag",

	'phloor_band:more' => 'Mehr Bands',
	'phloor_band:none' => 'Keine Bands',

	'phloor_band:access:band' => 'nur für Bandmitglieder',
	'phloor_band:visibility' => 'Wer kann diese Band sehen?',

	'phloor_band:yes' => 'ja',
	'phloor_band:no' => 'nein',
	'phloor_band:lastupdated' => 'Letztes Update %s von %s',
	'phloor_band:lastcomment' => 'Letztes Kommentar %s von %s',

	'phloor_band:privateband' => 'Requesting membership.',
	'phloor_band:notitle' => 'Hey, jede Band braucht einen Namen!',
	'phloor_band:cantjoin' => 'Der Band kann nicht beigetreten werden',
	'phloor_band:cantleave' => 'Die Band konnte nicht verlassen werden',
	'phloor_band:removeuser' => 'Aus der Band werfen',
	'phloor_band:cantremove' => 'Das Mitglied konnte nicht aus der Band geworfen werden',
	'phloor_band:removed' => '%s wurde aus der Band geworfen',
	'phloor_band:addedtoband' => 'User wurde erfolgreich in die Band aufgenommen',
	'phloor_band:joinrequestnotmade' => 'Konnte keine Mitgliedsanfrage abschicken',
	'phloor_band:joinrequestmade' => 'Eine Mitgliedsanfrage wurde abgeschickt',
	'phloor_band:joined' => 'Du wurdest erfolgreich in der Band aufgenommen!',
	'phloor_band:left' => 'Du hast die Band erfolgreich verlassen',
	'phloor_band:notowner' => 'Sorry, du bist nicht der Gründer dieser Band.',
	'phloor_band:notmember' => 'Sorry, du bist nicht Mitglied dieser Band.',
	'phloor_band:alreadymember' => 'Du bist bereits Mitglied dieser Band',
	'phloor_band:userinvited' => 'User wurde eingeladen.',
	'phloor_band:usernotinvited' => 'User konnte nicht eingeladen werden.',
	'phloor_band:useralreadyinvited' => 'User wurde bereits eingeladen',
	'phloor_band:invite:subject' => "%s du wurdest eingeladen um %s beizutreten!",
	'phloor_band:updated' => "Letzte Antwort von %s %s",
	'phloor_band:started' => "Gestartet von %s",
	'phloor_band:joinrequest:remove:check' => 'Bist du sicher, dass du diese Aufnahmeanfrage löschen willst?',
	'phloor_band:invite:remove:check' => 'Bist du sicher, dass du dieses Beitrittsangebot?',
	'phloor_band:invite:body' => "Hallo %s,

%s hat dich eingeladen der Band '%s' beizutreten. Klick folgenden Link um die Einladung zu sehen:

%s",

	'phloor_band:welcome:subject' => "Willkommen in der Band %s!",
	'phloor_band:welcome:body' => "Hallo %s!

Du bist jetzt Mitglied der Band '%s'!

%s",

	'phloor_band:request:subject' => "%s will der Band '%s' beitreten",
	'phloor_band:request:body' => "Hallo %s,

%s will der Band '%s' beitreten. 
Zum Profil:

%s

Klick hier um zu den Mitgliedsanfragen zu kommen:

%s",

	'river:create:group:phloor_band' => '%s hat die Band %s gegründet',
	'river:join:group:phloor_band' => '%s ist jetzt Mitglied der Band %s',
	
	'phloor_band:nowidgets' => 'Keine Widgets gefunden.',

	'phloor_band:widgets:members:title' => 'Bandmitglieder',
	'phloor_band:widgets:members:description' => 'Zeigt die Mitglieder einer Band an.',
	'phloor_band:widgets:members:label:displaynum' => 'List the members of a band.',
	'phloor_band:widgets:members:label:pleaseedit' => 'Bitte konfiguriere dieses Widget.',

	'phloor_band:widgets:entities:title' => "Objekte in der Band",
	'phloor_band:widgets:entities:description' => "Zeigt die Objekte einer Band an",
	'phloor_band:widgets:entities:label:displaynum' => 'List the objects of a band.',
	'phloor_band:widgets:entities:label:pleaseedit' => 'Bitte konfiguriere dieses Widget.',

	'phloor_band:allowhiddenphloor_band' => 'Private (versteckte) Bands erlauben?',

	'phloor_band:deleted' => 'Die Band wurde aufgelöst.',
	'phloor_band:notdeleted' => 'Die Band konnte nicht aufgelöst werden',

	'phloor_band:notfound' => 'Die Band konnte nicht gefunden werden',
	'phloor_band:deletewarning' => "Bist du dir sicher, dass du die Band auflösen willst? Dieser Vorgang kann nicht rückgängig gemacht werden",

	'phloor_band:invitekilled' => 'Das Angebot wurde gelöscht',
	'phloor_band:joinrequestkilled' => 'Die Anfrage wurde gelöscht',
);

add_translation("de", $german);