<?php

$english = array(

	'phloor_band' => "Bands",
	'phloor_band:owned' => "Bands I own",
	'phloor_band:yours' => "My bands",
	'phloor_band:user' => "%s's bands",
	'phloor_band:all' => "All bands",
	'phloor_band:add' => "Create a new band",
	'phloor_band:edit' => "Edit band",
	'phloor_band:delete' => 'Delete band',
	'phloor_band:membershiprequests' => 'Manage join requests',
	'phloor_band:invitations' => 'Band invitations',

	'phloor_band:icon' => 'Band icon (leave blank to leave unchanged)',
	'phloor_band:name' => 'Band name',
	'phloor_band:username' => 'Band short name (displayed in URLs, alphanumeric characters only)',
	'phloor_band:description' => 'About',
	'phloor_band:briefdescription' => 'Brief description',
	'phloor_band:interests' => 'Tags',
	'phloor_band:website' => 'Website',
	'phloor_band:genre' => 'Genre',

	'phloor_band:members' => 'Band members',
	'phloor_band:members:title' => 'Members of %s',
	'phloor_band:members:more' => "View all members",
	'phloor_band:membership' => "Band membership permissions",
	'phloor_band:access' => "Access permissions",
	'phloor_band:owner' => "Owner",
	'phloor_band:widget:num_display' => 'Number of bands to display',
	'phloor_band:widget:membership' => 'Band membership',
	'phloor_band:widgets:description' => 'Display the bands you are a member of on your profile',
	'phloor_band:noaccess' => 'No access to band',
	'phloor_band:permissions:error' => 'You do not have the permissions for this',
	'phloor_band:inband' => 'in the band',
	'phloor_band:cantedit' => 'You can not edit this band',
	'phloor_band:saved' => 'Band saved',
	'phloor_band:featured' => 'Featured bands',
	'phloor_band:makeunfeatured' => 'Unfeature',
	'phloor_band:makefeatured' => 'Make featured',
	'phloor_band:featuredon' => '%s is now a featured band.',
	'phloor_band:unfeatured' => '%s has been removed from the featured bands.',
	'phloor_band:featured_error' => 'Invalid band.',
	'phloor_band:joinrequest' => 'Request membership',
	'phloor_band:join' => 'Join band',
	'phloor_band:leave' => 'Leave band',
	'phloor_band:invite' => 'Invite friends',
	'phloor_band:invite:title' => 'Invite friends to this band',
	'phloor_band:inviteto' => "Invite friends to '%s'",
	'phloor_band:nofriends' => "You have no friends left who have not been invited to this band.",
	'phloor_band:nofriendsatall' => 'You have no friends to invite!',
	'phloor_band:viaphloor_band' => "via band",
	'phloor_band:band' => "Band",
	'phloor_band:search:tags' => "tag",
	'phloor_band:search:title' => "Search for bands tagged with '%s'",
	'phloor_band:search:none' => "No matching bands were found",

	'phloor_band:notfound' => "Band not found",
	'phloor_band:notfound:details' => "The requested band either does not exist or you do not have access to it",

	'phloor_band:requests:none' => 'There are no current membership requests.',

	'phloor_band:invitations:none' => 'There are no current invitations.',

	'phloor_band:count' => "Bands created",
	'phloor_band:open' => "open band",
	'phloor_band:closed' => "closed band",
	'phloor_band:member' => "members",
	'phloor_band:searchtag' => "Search for bands by tag",

	'phloor_band:more' => 'More bands',
	'phloor_band:none' => 'No bands',

	'phloor_band:access:private' => 'Closed - Users must be invited',
	'phloor_band:access:public' => 'Open - Any user may join',
	'phloor_band:access:band' => 'Band members only',
	'phloor_band:closedband' => 'This band has a closed membership.',
	'phloor_band:closedband:request' => 'To ask to be added, click the "request membership" menu link.',
	'phloor_band:visibility' => 'Who can see this band?',

	'phloor_band:yes' => 'yes',
	'phloor_band:no' => 'no',
	'phloor_band:lastupdated' => 'Last updated %s by %s',
	'phloor_band:lastcomment' => 'Last comment %s by %s',

	'phloor_band:privateband' => 'This band is closed. Requesting membership.',
	'phloor_band:notitle' => 'Bands must have a title',
	'phloor_band:cantjoin' => 'Can not join band',
	'phloor_band:cantleave' => 'Could not leave band',
	'phloor_band:removeuser' => 'Remove from band',
	'phloor_band:cantremove' => 'Cannot remove user from band',
	'phloor_band:removed' => 'Successfully removed %s from band',
	'phloor_band:addedtoband' => 'Successfully added the user to the band',
	'phloor_band:joinrequestnotmade' => 'Could not request to join band',
	'phloor_band:joinrequestmade' => 'Requested to join band',
	'phloor_band:joined' => 'Successfully joined band!',
	'phloor_band:left' => 'Successfully left band',
	'phloor_band:notowner' => 'Sorry, you are not the owner of this band.',
	'phloor_band:notmember' => 'Sorry, you are not a member of this band.',
	'phloor_band:alreadymember' => 'You are already a member of this band!',
	'phloor_band:userinvited' => 'User has been invited.',
	'phloor_band:usernotinvited' => 'User could not be invited.',
	'phloor_band:useralreadyinvited' => 'User has already been invited',
	'phloor_band:invite:subject' => "%s you have been invited to join %s!",
	'phloor_band:updated' => "Last reply by %s %s",
	'phloor_band:started' => "Started by %s",
	'phloor_band:joinrequest:remove:check' => 'Are you sure you want to remove this join request?',
	'phloor_band:invite:remove:check' => 'Are you sure you want to remove this invite?',
	'phloor_band:invite:body' => "Hi %s,

%s invited you to join the '%s' band. Click below to view your invitations:

%s",

	'phloor_band:welcome:subject' => "Welcome to the %s band!",
	'phloor_band:welcome:body' => "Hi %s!

You are now a member of the '%s' band! Click below to begin posting!

%s",

	'phloor_band:request:subject' => "%s has requested to join %s",
	'phloor_band:request:body' => "Hi %s,

%s has requested to join the '%s' band. Click below to view their profile:

%s

or click below to view the band's join requests:

%s",

	'river:create:group:phloor_band' => '%s created the band %s',
	'river:join:group:phloor_band' => '%s joined the band %s',

	'phloor_band:nowidgets' => 'No widgets have been defined for this band.',

	'phloor_band:widgets:members:title' => 'Band members',
	'phloor_band:widgets:members:description' => 'List the members of a band.',
	'phloor_band:widgets:members:label:displaynum' => 'List the members of a band.',
	'phloor_band:widgets:members:label:pleaseedit' => 'Please configure this widget.',

	'phloor_band:widgets:entities:title' => "Objects in band",
	'phloor_band:widgets:entities:description' => "List the objects saved in this band",
	'phloor_band:widgets:entities:label:displaynum' => 'List the objects of a band.',
	'phloor_band:widgets:entities:label:pleaseedit' => 'Please configure this widget.',

	'phloor_band:allowhiddenphloor_band' => 'Do you want to allow private (invisible) phloor_band?',

	'phloor_band:deleted' => 'Band and band contents deleted',
	'phloor_band:notdeleted' => 'Band could not be deleted',

	'phloor_band:notfound' => 'Could not find the band',
	'phloor_band:deletewarning' => "Are you sure you want to delete this band? There is no undo!",

	'phloor_band:invitekilled' => 'The invite has been deleted.',
	'phloor_band:joinrequestkilled' => 'The join request has been deleted.',
);

add_translation("en", $english);