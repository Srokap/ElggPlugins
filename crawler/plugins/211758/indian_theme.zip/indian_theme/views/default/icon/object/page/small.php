<?php
	echo $vars['url'] . "mod/theme_elgg_example/graphics/file_icons/pages.gif";
?>