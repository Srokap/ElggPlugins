<?php

	/* indian theme */
	
	
	/* Initialise the theme */
	function indian_theme_init(){
	
	}
	extend_view('metatags','customindex/metatags');
    extend_view('css','customindex/css');
	
	// Initialise log browser
	register_elgg_event_handler('init','system','indian_theme_init');
	
?>