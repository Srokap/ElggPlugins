<?php

	/**
	 * Save Userpoints settings
	 * 
	 */

	global $CONFIG;

	gatekeeper();
	action_gatekeeper();


	// Params array (text boxes and drop downs)
	$params = get_input('params');
	$result = false;
	foreach ($params as $k => $v) {
		if (!set_plugin_setting($k, $v, 'userpoints')) {
			register_error(sprintf(elgg_echo('plugins:settings:save:fail'), 'userpoints'));
			forward($_SERVER['HTTP_REFERER']);
		}
	}

	system_message(elgg_echo('userpoints:settings:save:ok'));
	
	forward($_SERVER['HTTP_REFERER']);
?>
