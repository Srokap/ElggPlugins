<?php

	global $CONFIG;
	
	$tab = $vars['tab'];
	$user_guid = $vars['user_guid'];
	
	$settingsselect = ''; 
	$statsselect = '';
	switch($tab) {
		case 'list':
			$listselect = 'class="selected"';
			break;
		case 'detail':
			$listdetail = 'class="selected"';
			break;
		case 'moderate':
			$moderateselect = 'class="selected"';
			break;
		case 'add':
			$addselect = 'class="selected"';
			break;
		case 'settings':
			$settingsselect = 'class="selected"';
			break;
	}
	
?>
<div class="contentWrapper">
	<div id="elgg_horizontal_tabbed_nav">
		<ul>
			<li <?php echo $listselect; ?>><a href="<?php echo $CONFIG->wwwroot . 'mod/userpoints/admin.php?tab=list'; ?>"><?php echo elgg_echo('userpoints:list'); ?></a></li>
			<li <?php echo $listdetail; ?>><a href="<?php echo $CONFIG->wwwroot . 'mod/userpoints/admin.php?tab=detail'; ?>"><?php echo elgg_echo('userpoints:detail'); ?></a></li>
			<li <?php echo $moderateselect; ?>><a href="<?php echo $CONFIG->wwwroot . 'mod/userpoints/admin.php?tab=moderate'; ?>"><?php echo elgg_echo('userpoints:moderate'); ?></a></li>
			<li <?php echo $addselect; ?>><a href="<?php echo $CONFIG->wwwroot . 'mod/userpoints/admin.php?tab=add'; ?>"><?php echo elgg_echo('userpoints:add'); ?></a></li>
			<li <?php echo $settingsselect; ?>><a href="<?php echo $CONFIG->wwwroot . 'mod/userpoints/admin.php?tab=settings'; ?>"><?php echo elgg_echo('userpoints:settings'); ?></a></li>
		</ul>
	</div>
<?php
	switch($tab) {
		case 'list':
			echo elgg_view("userpoints/list");
			break;
		case 'detail':
			echo elgg_view("userpoints/detail");
			break;
		case 'moderate':
			echo elgg_view("userpoints/moderate");
			break;
		case 'add':
			echo elgg_view("userpoints/add");
			break;
		case 'settings':
			echo elgg_view("userpoints/settings");
			break;
	}
?>
</div>
