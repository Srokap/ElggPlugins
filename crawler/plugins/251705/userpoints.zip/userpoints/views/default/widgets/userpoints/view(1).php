<div class="contentWrapper">
  <div id="userpoints_mypoints_widget_container">

<?php 
    $lowerplural = get_plugin_setting('lowerplural', 'userpoints');
    $upperplural = get_plugin_setting('upperplural', 'userpoints');
    $points = userpoints_get($vars['user']->guid);

    if ($points['pending'] > 0) {
        echo elgg_echo('userpoints:pending') . ": {$points['pending']} <br>";
    }

    echo elgg_echo('userpoints:total') . " $lowerplural: {$points['approved']}";
?>

  </div>
</div>
