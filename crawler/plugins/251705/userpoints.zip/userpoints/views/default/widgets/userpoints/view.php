<div class="contentWrapper">
<?php //print_r(userpoints_get($vars['user']->guid)); ?>
<?php 
    $lowerplural = get_plugin_setting('lowerplural', 'userpoints');
    $upperplural = get_plugin_setting('upperplural', 'userpoints');
    $points = userpoints_get($vars['user']->guid);

    echo sprintf(elgg_echo('userpoints:pending'), $upperplural) . ": {$points['pending']} <br>";
    echo sprintf(elgg_echo('userpoints:approved_balance'), $lowerplural) . ": {$points['approved']}";
?>
</div>
