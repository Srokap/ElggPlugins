<?php

    $profile_display = get_plugin_setting('profile_display', 'userpoints');
    if ($vars['size'] == 'large'){ 
	    if (get_plugin_setting('profile_display', 'userpoints')) {
            $upperplural = get_plugin_setting('upperplural', 'userpoints');
		    $points = userpoints_get($vars['entity']->guid)
?>

	<div class="userpoints_profile">
		<div><span><?php echo $upperplural . ': ' . $points['approved'];?></span></div>
	</div>

<?php 
        }
    } 
?>
