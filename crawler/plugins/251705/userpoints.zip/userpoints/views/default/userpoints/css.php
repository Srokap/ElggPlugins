<?php
	/**
	 * userpoint CSS
	 */
?>

.userpoints_profile{
    padding: 5px;
    margin: 5px 0 0;
    font-weight: bold; 
}

/* ------ userpoints widgets ------  */

#userpoints_mypoints_widget_container {
    text-align:left;
    /* background-color:#00ffff; */
}

#userpoints_toppoints_widget_container {
    text-align:left;
    /* background-color:#00ffff; */
}
