<?php

    // Include the Userpoint class 
    require_once dirname(__FILE__) . "/lib/userpoint.php";

    function userpoints_init() {        

        // Register the userpoint entity
        register_entity_type('object', 'userpoint', 'Userpoint');

        register_plugin_hook('expirationdate:expire_entity', 'all', 'userpoints_expire');

        extend_view('css', 'userpoints/css');

        $mypoints_name  =  get_plugin_setting('mypoints_name') ? get_plugin_setting('mypoints_name') : 'My Points';
        $toppoints_name  =  get_plugin_setting('toppoints_name') ? get_plugin_setting('toppoints_name') : 'Top Points';

        add_widget_type('userpoints', $mypoints_name, elgg_echo('userpoints:widget:mypoints:info'));
        add_widget_type('toppoints', $toppoints_name, elgg_echo('userpoints:widget:toppoints:info'));

        $version = get_plugin_setting('version', 'userpoints');

        // Check if we need to run an upgrade
        if (!$version) {
            $count = get_entities('object', 'userpoint', 0, '', 1, 0, true);
            if ($count > 0) {
                userpoints_upgrade();
            }

            set_plugin_setting('version', '1.1', 'userpoints');
        }
    }

    /**
     * Add points to a user
     * 
     * @param integer  $guid User Guid
     * @param integer  $points The number of ppoints to add
     * @param string   $description Description for these points
     * @param string   $type The entity type that the points are being awarded for
     * @param integer  $guid The entity guid
     * @return Bool    Return true/false on success/failure
     */
    function userpoints_add($user_guid, $points, $description, $type=null, $guid=null) {

        $points = (int)$points;
        $user = get_user($user_guid);

        // Create and save our new Userpoint object 
        $userpoint = new Userpoint(null, $user_guid, $description);
        $userpoint->save();

        // Just in case the save fails
        if (!$userpoint->guid) {
            return(false);
        }

        // Add the points, type, and guid as metadata to the user object
        $userpoint->meta_points = $points;
        $userpoint->meta_type = $type;
        $userpoint->meta_guid = $guid;

        // Increment the users running total

        // If moderation is enabled set points to pending else they are auto approved
        if (get_plugin_setting('moderate') && $type != 'admin') {
            $userpoint->meta_moderate = 'pending';
        } else {
            $userpoint->meta_moderate = 'approved';
            $user->userpoints_points = $user->userpoints_points + $points;
        }

        // Setup point expiration if enabled
        if (get_plugin_setting('expire_after')) {
            if (function_exists('expirationdate_set')) {
                $ts = time() + get_plugin_setting('expire_after');
                expirationdate_set($userpoint->guid, date('Y-m-d H:i:s', $ts), false);
            }
        }

        // Display a system message to the user if configured to do so
        $branding = ($points == 1) ? get_plugin_setting('lowersingular') : get_plugin_setting('lowerplural');
        if (get_plugin_setting('displaymessage') && $type != 'admin') {
            $message = get_plugin_setting('moderate') ? 'userpoints:pending_message' : 'userpoints:awarded_message';
            system_message(sprintf(elgg_echo($message), $points, $branding));
        }

        return($userpoint);
    }

    /**
     * Subtract points from a user. This is just a wrapper around
     * userpoints_add as we are really just adding negataive x points.
     * 
     * @param integer  $guid User Guid
     * @param integer  $points The number of points to subtract
     * @param string   $description Description for these points
     * @param string   $type The entity type that the points are being awarded for
     * @param integer  $guid The entity guid
     * @return Bool    Return true/false on success/failure
     */
    function userpoints_subtract($user_guid, $points, $description, $type=null, $guid=null) {
        if ($points > 0) {
            $points = -$points;
        }

        return(userpoints_add($user_guid, $points, $description, $type=null, $guid=null));
    }

    /**
     * Called when the expirationdate:expire_entity hook is triggered.
     * When a userpoint record is expired we have to decrement the users
     * total points.
     * 
     * @param integer  $hook The hook being called. 
     * @param integer  $type The type of entity you're being called on. 
     * @param string   $return The return value.
     * @param string   $params An array of parameters including the userpoint entity
     * @return Bool    Return true
     */
    function userpoints_expire($hook, $type, $return, $params) {

        if (!$params['entity']->subtype == 'userpoint') {
            return(true);
        }

        $user = get_user($params['entity']->owner_guid);

        // Decerement the users total points
        $user->userpoints_points = $user->userpoints_points - $params['entity']->meta_points;

        return(true);
    }

    /**
     * Sets up the userpoints admin menu.
     */
    function userpoints_adminmenu()
    {
        global $CONFIG;
        if (get_context() == 'admin' && isadminloggedin()) {
            add_submenu_item(elgg_echo('userpoints:userpoints'), $CONFIG->url . "mod/userpoints/admin.php");
        }
    }


    /**
     * Given a user id, type, and entity id check to see if points have 
     * already been awarded.
     * 
     * @param  integer  $user_guid User Guid
     * @param  string   $type The entity type that the points are being awarded for
     * @param  integer  $guid The entity guid
     * @return Bool
     */
    function userpoints_exists($user_guid, $type, $guid) {
        $entities = get_entities_from_metadata('meta_type', '', 'object', 'userpoint', $owner_guid);
        foreach($entities as $obj) {
            if ($obj->meta_type == $type && $obj->meta_guid == $guid) {
                return(true);
            }
        }
        return(false);
    }

    /**
     * Returns a count of approved and pending points for the given user.
     * 
     * @param  integer  $user_guid The user Guid
     * @return array    An array including the count of approved/pending points
     */
    function userpoints_get($user_guid) {

        $points = array('approved' => 0, 'pending' => 0);

        if ($entities = get_entities_from_metadata('meta_points', '', 'object', 'userpoint', $user_guid, 100000)) {
            foreach($entities as $obj) {
                if (isset($obj->meta_moderate)) { 
                    if ($obj->meta_moderate == 'approved') {
                        $points['approved'] = $points['approved'] + $obj->meta_points;
                    } else if ($obj->meta_moderate == 'pending') {
                        $points['pending'] = $points['pending'] + $obj->meta_points;
                    }
                } else {
                    $points['approved'] = $points['approved'] + $obj->meta_points;
                }
            }
        }
        return($points);
    }

    /**
     * Deletes a userpoint record based on the meta_guid. This method
     * should be called by plugins that want to delete points if the 
     * content/object that awarded the points is deleted.
     * 
     * @param  integer  $user_guid The user Guid
     * @param  integer  $guid The guid of the object being deleted
     */
    function userpoints_delete($user_guid, $guid) {

        if (!get_plugin_setting('delete')) {
            return(false);
        }

        $points = 0;

        $entities = get_entities_from_metadata('meta_guid', $guid, 'object', 'userpoint', $user_guid);
        foreach ($entities as $entity) {
            $points = $points + $entity->meta_points;
            delete_entity($entity->guid);
        }

        $user = get_user($user_guid);

        // Decerement the users total points
        $user->userpoints_points = $user->userpoints_points - $points;
    }   

    /**
     * Deletes userpoints by the guid of the userpoint entity.
     * This method is called when administratively deleting points
     * or when points expire.
     * 
     * @param  integer  $guid The guid of the userpoint entity
     */
    function userpoints_delete_by_userpoint($guid) {

        $entity = get_entity($guid);
        $user = get_user($entity->owner_guid);

        // Decerement the users total points
        $user->userpoints_points = $user->userpoints_points - $entity->meta_points;

        // Delete the userpoint entity
        $entity->delete();
        delete_entity($guid);
    }   

    /**
     * Deletes userpoints by the guid of the userpoint entity.
     * This method is called when administratively deleting points
     * or when points expire.
     * 
     * @param  integer  $guid The guid of the userpoint entity
     */
    function userpoints_moderate($guid, $status) {

        $entity = get_entity($guid);
        $user = get_user($entity->owner_guid);

        $entity->meta_moderate = $status;

        // increment the users total points if approved
        if ($status == 'approved') {
            $user->userpoints_points = $user->userpoints_points + $entity->meta_points;
        }
    }   


    /**
     * This very cool method was contributed by Alivin79 to the Goolge Elgg Development group
     * http://groups.google.com/group/elgg-development/browse_thread/thread/30259601808493f1/b66ce5aa2f48b921
     *
     * @global Array $CONFIG
     * @param Array $meta_array Is a multidimensional array with the list of metadata to filter.
     * For each metadata you have to provide 3 values:
     * - name of metadata
     * - value of metadata
     * - operand ( <, >, <=, >=, =, like)
     * For example
     *      $meta_array = array(
     *              array(
     *                  'name'=>'my_metadatum',
     *                  'operand'=>'>=',
     *                  'value'=>'my value'
     *              )
     *      )
     * @param String $entity_type
     * @param String $entity_subtype
     * @param Boolean $count
     * @param Integer $owner_guid
     * @param Integer $container_guid
     * @param Integer $limit
     * @param Integer $offset
     * @param String $order_by "Order by" SQL string. If you want to sort by metadata string,
     * possible values are vN.string, where N is the first index of $meta_array,
     * hence our example is $order by = 'v1.string ASC'
     * @param Integer $site_guid
     * @return Mixed Array of entities or false
     *
     */
    function userpoints_get_entities_from_metadata_by_value($meta_array, $entity_type="", $entity_subtype="", $count=false, $owner_guid=0, $container_guid=0, $limit=10, $offset=0, $order_by="", $site_guid=0) {

        global $CONFIG;

        // ORDER BY
        if ($order_by == "") $order_by = "e.time_created desc";
        $order_by = sanitise_string($order_by);

        $where = array();

        // Filetr by metadata
        $mindex = 1; // Starting index of joined metadata/metastring tables
        $join_meta = "";
        $query_access = "";
        foreach($meta_array as $meta) {
            $join_meta .= "JOIN {$CONFIG->dbprefix}metadata m{$mindex} on e.guid = m{$mindex}.entity_guid ";
            $join_meta .= "JOIN {$CONFIG->dbprefix}metastrings v{$mindex} on v{$mindex}.id = m{$mindex}.value_id ";

            $meta_n = get_metastring_id($meta['name']);
            $where[] = "m{$mindex}.name_id='$meta_n'";

            if (strtolower($meta['operand']) == "like"){
                // "LIKE" search
                $where[] = "v{$mindex}.string LIKE ('".$meta['value']."') ";
            }elseif(strtolower($meta['operand']) == "in"){
                // TO DO - "IN" search
            }else{
                // Simple operand search
                $where[] = "v{$mindex}.string".$meta['operand']."'".$meta['value']."'";
            }

            $query_access .= ' and ' . get_access_sql_suffix("m{$mindex}"); // Add access controls

            $mindex++;
        }

        $limit = (int)$limit;
        $offset = (int)$offset;

        if ((is_array($owner_guid) && (count($owner_guid)))) {
            foreach($owner_guid as $key => $guid) {
                $owner_guid[$key] = (int) $guid;
            }
        } else {
            $owner_guid = (int) $owner_guid;
        }

        if ((is_array($container_guid) && (count($container_guid)))) {
            foreach($container_guid as $key => $guid) {
                $container_guid[$key] = (int) $guid;
            }
        } else {
            $container_guid = (int) $container_guid;
        }

        $site_guid = (int) $site_guid;
        if ($site_guid == 0)
            $site_guid = $CONFIG->site_guid;

        $entity_type = sanitise_string($entity_type);
        if ($entity_type!="")
            $where[] = "e.type='$entity_type'";

        $entity_subtype = get_subtype_id($entity_type, $entity_subtype);
        if ($entity_subtype)
            $where[] = "e.subtype=$entity_subtype";

        if ($site_guid > 0)
            $where[] = "e.site_guid = {$site_guid}";

        if (is_array($owner_guid)) {
            $where[] = "e.owner_guid in (".implode(",",$owner_guid).")";
        } else if ($owner_guid > 0) {
            $where[] = "e.owner_guid = {$owner_guid}";
        }

        if (is_array($container_guid)) {
            $where[] = "e.container_guid in (".implode(",",$container_guid).")";
        } else if ($container_guid > 0)
            $where[] = "e.container_guid = {$container_guid}";
        if (!$count) {
            $query = "SELECT distinct e.* ";
        } else {
            $query = "SELECT count(distinct e.guid) as total ";
        }

        $query .= "FROM {$CONFIG->dbprefix}entities e ";
        $query .= $join_meta;

        $query .= "  WHERE ";
        foreach ($where as $w)
            $query .= " $w and ";
        $query .= get_access_sql_suffix("e"); // Add access controls
        $query .= $query_access;

        if (!$count) {
            $query .= " order by $order_by limit $offset, $limit"; // Add order and limit
            return get_data($query, "entity_row_to_elggstar");
        } else {
            $row = get_data_row($query);
            if ($row)
                return $row->total;
        }
        return false;
    } 


    /*
     * Upgrades userpoints 1.0b to 1.0.1b
     *
     * Loop though all the userpoint objects, sum up the points by user,
     * and add the total points to the user as metadata. This way the user
     * object holds the current total points.
     */
    function userpoints_upgrade() {

        global $CONFIG;

        // Get the total points for each user
        $results = get_data("
            SELECT   u.guid AS guid,
                     Sum(s2.string) AS points
            FROM     {$CONFIG->dbprefix}users_entity u,
                     {$CONFIG->dbprefix}entities e,
                     {$CONFIG->dbprefix}metadata em,
                     {$CONFIG->dbprefix}metadata em1,
                     {$CONFIG->dbprefix}entity_subtypes es,
                     {$CONFIG->dbprefix}metastrings s1,
                     {$CONFIG->dbprefix}metastrings s2,
                     {$CONFIG->dbprefix}metastrings s3,
                     {$CONFIG->dbprefix}metastrings s4
            WHERE    e.owner_guid = u.guid
                     AND e.subtype = es.id
                     AND es.subtype = 'userpoint'
                     AND e.guid = em.entity_guid
                     AND e.guid = em1.entity_guid
                     AND em.name_id = s1.id
                     AND s1.string = 'meta_points'
                     AND em.value_id = s2.id
                     AND em1.name_id = s3.id
                     AND s3.string = 'meta_moderate'
                     AND em1.value_id = s4.id
                     AND s4.string = 'approved'
            GROUP BY u.guid
        ");

        // Loop through all users and add their total points as metadata
        foreach ($results as $obj) {
            $user = get_user($obj->guid);
            $user->userpoints_points = $obj->points;
        }
    }

    register_elgg_event_handler('init','system','userpoints_init');       
    register_elgg_event_handler('pagesetup','system','userpoints_adminmenu');

    register_action("userpoints/settings", false, $CONFIG->pluginspath . "userpoints/actions/settings.php", true);
    register_action("userpoints/delete",false,$CONFIG->pluginspath . "userpoints/actions/delete.php", true);
    register_action("userpoints/moderate",false,$CONFIG->pluginspath . "userpoints/actions/moderate.php", true);
    register_action("userpoints/add",false,$CONFIG->pluginspath . "userpoints/actions/add.php", true);
    register_action("userpoints/reset",false,$CONFIG->pluginspath . "userpoints/actions/reset.php", true);

?>
