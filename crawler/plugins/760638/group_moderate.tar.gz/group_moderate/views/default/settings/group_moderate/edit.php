<?php
/**
 *	Group Moderate Pro Plugin
 *
 *	@package group moderate pro
 *	@author Liran Tal <liran.tal@gmail.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 */


echo "<a href='".$CONFIG->url . "pg/group_moderate_pro/admin" ."' /> Group Moderate Administration</a>";