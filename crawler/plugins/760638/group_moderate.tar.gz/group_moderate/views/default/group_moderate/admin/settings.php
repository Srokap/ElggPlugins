<?php
/**
 *	Group Moderate Pro Plugin
 *
 *	@package group moderate pro
 *	@author Liran Tal <liran.tal@gmail.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 */

$plugin = find_plugin_settings('group_moderate');

$send_user_email_pending_group = $plugin->send_user_email_pending_group ? $plugin->send_user_email_pending_group : "0"; 
$send_user_email_pending_group_message_text = $plugin->send_user_email_pending_group_message_text ? $plugin->send_user_email_pending_group_message_text : "";

$send_user_email_deleted_group = $plugin->send_user_email_deleted_group ? $plugin->send_user_email_deleted_group : "0"; 
$send_user_email_deleted_group_message_text = $plugin->send_user_email_deleted_group_message_text ? $plugin->send_user_email_deleted_group_message_text : "";

$send_user_email_approved_group = $plugin->send_user_email_approved_group ? $plugin->send_user_email_approved_group : "0";
$send_user_email_approved_group_message_text = $plugin->send_user_email_approved_group_message_text ? $plugin->send_user_email_approved_group_message_text : "";

$send_admin_email_pending_group = $plugin->send_admin_email_pending_group ? $plugin->send_admin_email_pending_group : "0";
$send_admin_email_pending_group_message_text = $plugin->send_admin_email_pending_group_message_text ? $plugin->send_admin_email_pending_group_message_text : "";

$message_to_show_user_after_group_creation = $plugin->message_to_show_user_after_group_creation ? $plugin->message_to_show_user_after_group_creation : "Please wait while admin approves this group";


$timestamp = time();
$token = generate_action_token($timestamp);

$action = $vars['url'] . "action/group_moderate/settings";


$form_body = "";

$form_body .= elgg_echo('group_moderate:settings:send user email pending group notice');
$form_body .= elgg_view('input/pulldown', array(
                'internalname' => 'params[send_user_email_pending_group]',
                'options_values' => array('1' => 'Yes', '0' => 'No'),
                'value' => $plugin->send_user_email_pending_group
					)
				);
$form_body .= "<br/>";
$form_body .= elgg_echo('group_moderate:settings:message text');
$form_body .= "<br/>";
$form_body .= elgg_view('input/plaintext', array('internalname' => 'params[send_user_email_pending_group_message_text]',
										'value' => $plugin->send_user_email_pending_group_message_text)
				);
				
				
				
$form_body .= elgg_echo('group_moderate:settings:send user email deleted group notice');
$form_body .= elgg_view('input/pulldown', array(
                'internalname' => 'params[send_user_email_deleted_group]',
                'options_values' => array('1' => 'Yes', '0' => 'No'),
                'value' => $plugin->send_user_email_deleted_group
					)
				);
$form_body .= "<br/>";
$form_body .= elgg_echo('group_moderate:settings:message text');
$form_body .= "<br/>";
$form_body .= elgg_view('input/plaintext', array('internalname' => 'params[send_user_email_deleted_group_message_text]',
										'value' => $plugin->send_user_email_deleted_group_message_text)
				);
				
				
				
				
$form_body .= "<br/><br/>";
$form_body .= elgg_echo('group_moderate:settings:send user email approved group notice');
$form_body .= elgg_view('input/pulldown', array(
                'internalname' => 'params[send_user_email_approved_group]',
                'options_values' => array('1' => 'Yes', '0' => 'No'),
                'value' => $plugin->send_user_email_approved_group
					)
				);
$form_body .= "<br/>";
$form_body .= elgg_echo('group_moderate:settings:message text');
$form_body .= "<br/>";
$form_body .= elgg_view('input/plaintext', array('internalname' => 'params[send_user_email_approved_group_message_text]', 
										'value' => $plugin->send_user_email_approved_group_message_text)
				);

$form_body .= "<br/><br/>";
$form_body .= elgg_echo('group_moderate:settings:send admin email pending group notice');
$form_body .= elgg_view('input/pulldown', array(
                'internalname' => 'params[send_admin_email_pending_group]',
                'options_values' => array('1' => 'Yes', '0' => 'No'),
                'value' => $plugin->send_admin_email_pending_group
					)
				);
$form_body .= "<br/>";
$form_body .= elgg_echo('group_moderate:settings:message text');
$form_body .= "<br/>";
$form_body .= elgg_view('input/plaintext', array('internalname' => 'params[send_admin_email_pending_group_message_text]',
										'value' => $plugin->send_admin_email_pending_group_message_text)
				);


$form_body .= "<br/><br/>";
$form_body .= elgg_echo('group_moderate:settings:message to show user after group creation');
$form_body .= "<br/>";
$form_body .= elgg_view('input/longtext', array('internalname' => 'params[message_to_show_user_after_group_creation]', 
										'value' => $plugin->message_to_show_user_after_group_creation)
				);
				
$form_body .= elgg_view("input/securitytoken"); 

$form_body .= elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('save')));

$form .= elgg_view('input/form', array('action' => "$action", 'body' => $form_body));

echo $form;