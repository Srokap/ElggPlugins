<?php
/**
 *	Group Moderate Pro Plugin
 *
 *	@package group moderate pro
 *	@author Liran Tal <liran.tal@gmail.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 */


function draw_entity($groupEntity) {
	
	global $CONFIG;
	
	$entity = $groupEntity;
	
	$timestamp = time();
	$token = generate_action_token($timestamp);

	$owner = get_entity($entity->owner_guid);
	
	if (!$owner)
		return false;
	
	$icon = elgg_view(
			"groups/icon", array(
									'entity' => $entity,
									'size' => 'small',
								  )
		);
	
	$info .= "<div class=\"contentWrapper\"><p>";
	$info .= "<b>".elgg_echo('group_moderate:Group Name')."</b>: ".$entity->name."<br/>";
	$info .= "<b>".elgg_echo('group_moderate:Group Description')."</b>: ".$entity->description."<br/>";
	$info .= "<b>".elgg_echo('group_moderate:Group Creator Username')."</b>: <a href='".$owner->getURL()."' />".$owner->username."</a><br/>";
	$info .= "<b>".elgg_echo('group_moderate:Group Creator Name')."</b>: ".$owner->name."<br/>";
	$info .= "<b>".elgg_echo('group_moderate:Group Created on')."</b>: ".friendly_time($entity->time_created)."<br/>";
	
	// create the enable button form
	$action = $CONFIG->url . "action/group_moderate/enable";
	$form_body = elgg_view('input/hidden', array('internalname' => 'entity_guid', 'value' => $entity->getGUID()));
	$form_body .= elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('enable')));
	$form_body .= " ";
	$form_body .= elgg_view("input/securitytoken");
    $form_body .= elgg_view("output/confirmlink", array(
        'href' => $CONFIG->url . "action/group_moderate/delete?entity_guid=".$entity->getGUID()."&__elgg_token=$token&__elgg_ts=$timestamp",
        'text' => elgg_echo('delete'),
        'confirm' => elgg_echo('group_moderate:settings:are you sure you want to reject and delete this group?')
    ));
	
	
	$info .= elgg_view('input/form', array('action' => "$action", 'body' => $form_body));
	//
	
	$info .= "</p></div>";
	echo elgg_view_listing($icon, $info);
	
}

	global $CONFIG; 
	
	$plugin = find_plugin_settings('group_moderate');
	
	$access_status = access_get_show_hidden_status();
	access_show_hidden_entities(true);

	$entities = array();
	$disabled_groups_guids = group_moderate_getDisabledGroupsGuids();
	foreach($disabled_groups_guids as $group) {
		$groupEntity = get_entity($group->guid);
		array_push($entities, $groupEntity);
		draw_entity($groupEntity);
	}
	
	//var_dump($entities);
	access_show_hidden_entities($access_status);
	