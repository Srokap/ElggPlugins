<?php
/**
 *	Group Moderate Pro Plugin
 *
 *	@package group moderate pro
 *	@author Liran Tal <liran.tal@gmail.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 */

global $CONFIG;

gatekeeper();
admin_gatekeeper();
action_gatekeeper();

// settings parameters
$params = get_input('params');
$result = false;
foreach ($params as $k => $v) {
	if (!set_plugin_setting($k, $v, 'group_moderate')) {
		register_error(sprintf(elgg_echo('plugins:settings:save:fail'), 'group_moderate'));
		forward($_SERVER['HTTP_REFERER']);
	}
}

system_message(elgg_echo('group_moderate:settings:successfully saved settings'));
forward($_SERVER['HTTP_REFERER']);

?>
