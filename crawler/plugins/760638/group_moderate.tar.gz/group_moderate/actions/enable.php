<?php
/**
 *	Group Moderate Pro Plugin
 *
 *	@package group moderate pro
 *	@author Liran Tal <liran.tal@gmail.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 */

global $CONFIG;

// making sure the user is logged in
gatekeeper();
admin_gatekeeper();

set_context('group_moderate');

// get object details
$entity_guid = get_input('entity_guid');

// enable the entity
if ($entity_guid) {
	
	// override hidden status of entities
	$access_status = access_get_show_hidden_status();
	access_show_hidden_entities(true);
	
	$object = get_entity($entity_guid);
	if ($object instanceof ElggGroup) {
		
		enable_entity($entity_guid);
		
		$group_owner_guid = $object->owner_guid;
		
		$groupName = $object->name;
		$groupURL = $object->getURL();
		$groupInfo = sprintf(elgg_echo('group_moderate:group_information'), $groupName, $groupURL);
	
		$pluginSettings = find_plugin_settings('group_moderate');
		if ($pluginSettings->send_user_email_approved_group == 1) {
			$notification = $pluginSettings->send_user_email_approved_group_message_text;
			group_moderate_emailUserNotification($group_owner_guid, $notification, $groupInfo);
		}
		
		system_message(elgg_echo('group_moderate:successfully_enabled_group'));
	
	} else {
		register_error(elgg_echo('group_moderate:error_not_group_entity'));
	}
	
	// return hidden status
	access_show_hidden_entities($access_status);
}

forward($_SERVER['HTTP_REFERER']);

?>
