<?php
/**
 *	Group Moderate Pro Plugin
 *
 *	@package group moderate pro
 *	@author Liran Tal <liran.tal@gmail.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 */

/**
 * group_moderate_getDisabledGroupsGuids
 * returns a stdobj class array with GUIDs as elements of disabled groups/entities
 * @return unknown_type
 */
function group_moderate_getDisabledGroupsGuids() {
	
	global $CONFIG;
	
	$query = "SELECT ".
				" distinct(a.guid) ".
			" FROM ".
				" {$CONFIG->dbprefix}entities a ".
			" WHERE ".
				" a.enabled = 'no' ".
			" ORDER BY a.time_created DESC";
	
	//return get_data($query, "entity_row_to_elggstar");
	return get_data($query);
	
}

/*
 * group_moderate_emailUserNotification
 * @param		$user_guid		the guid of the user who owns the group
 * @param		$notification	the notification message to send
 * @param		$groupInfo		additional group information like name and url to append to the notification
 */
function group_moderate_emailUserNotification($user_guid, $notification, $groupInfo) {
	
	global $CONFIG;
	
	$user = get_entity($user_guid);
	if (!$user)
		return;
	
	$email = $user->email;
	
	$site = get_entity($CONFIG->site_guid);
	if ($site->name)
		$sitename = $site->name;
	else
		$sitename = "Unavailable";

	if (($site) && (isset($site->email))) {
		$from = $site->email;
	} else if (isset($from->url))  {
		 $breakdown = parse_url($from->url);
		 $from = 'noreply@' . $breakdown['host'];
	} else
		$from = 'noreply@' . get_site_domain($CONFIG->site_guid);
	
	$subject = elgg_echo('groups:new');

	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=utf-8" . "\r\n";
	$headers .= "From: $sitename<$from>";
	
	$notification .= $groupInfo;
	
	
	
	if (function_exists('phpmailer_send')) {
		phpmailer_send($from, $sitename, $email, "", $subject, $notification, NULL, false);
	} else {
		mail($email, $subject, wordwrap($notification), $headers);
	}

                
}









