<?php
/**
 *	Group Moderate Pro Plugin
 *
 *	@package group moderate pro
 *	@author Liran Tal <liran.tal@gmail.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 */

	$english = array(
	
		// General Items
			'group_moderate' => "Group Moderate",
			'group_moderate:administration' => "Group Moderate Administration",
			'group_moderate:Group Name' => "Group name",
			'group_moderate:Group Description' => "Group Description",
			'group_moderate:Group Creator Username' => "Group Creator Username",
			'group_moderate:Group Creator Name' => "Group Creator Name",
			'group_moderate:Group Created on' => "Created on",
			'group_moderate:created_group_user_text' => "
			Thank you for creating a group, <br/>
			We will review the group details and enable it if appropriate.<br/>
			",

			'group_moderate:group_information' => "\n
			Group Name: %s, \n
			Group Website: %s \n
			",
	
		// plugin settings
			'group_moderate:settings' => "Settings",
			'group_moderate:listgroups' => "List Groups",
	
			'group_moderate:settings:send user email deleted group notice' => "Send User Email Regarding Deleted/Rejected Group",
			'group_moderate:settings:send user email pending group notice' => "Send User Email Regarding Pending Group",
			'group_moderate:settings:send admin email pending group notice' => "Send Admin Email Regarding Pending Group",
			'group_moderate:settings:send user email approved group notice' => "Send User Email Regarding Approved Group",
			'group_moderate:settings:message to show user after group creation' => "Write the message to show the user after creating the group and pending approval of it",
			'group_moderate:settings:message text' => "The Message text",
			'group_moderate:settings:successfully saved settings' => "Successfully saved settings",
			'group_moderate:settings:are you sure you want to reject and delete this group?' => "Are you sure you want to reject and DELETE this group?",
			'group_moderate:settings:' => "Administration",
			'group_moderate:settings:' => "Administration",
	
	
		// plugin messages
			'group_moderate:successfully_enabled_group' => "Successfully enabled group",
			'group_moderate:successfully_deleted_group' => "Successfully deleted group",
			
	);
					
	add_translation("en", $english);
