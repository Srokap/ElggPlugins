<?php
/**
 *	Group Moderate Pro Plugin
 *
 *	@package group moderate pro
 *	@author Liran Tal <liran.tal@gmail.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 */

gatekeeper();
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

global $CONFIG;

set_context('group_moderate');

$pluginSettings = find_plugin_settings('group_moderate');

$body = "<div class=\"search_listing\">";
$body .= $pluginSettings->message_to_show_user_after_group_creation;
$body .= "</div>";

$title = elgg_echo('Created Group');

$body = elgg_view_layout('two_column_left_sidebar', '', elgg_view_title($title) . $body);
page_draw($title, $body);
