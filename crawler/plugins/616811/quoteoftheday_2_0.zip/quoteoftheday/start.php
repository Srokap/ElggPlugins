<?PHP

	/**
	 * Quote of the day - Plugin
	 * 
	 * @package Quote of the day
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Mike Jones
	 * @copyright Dreamware LLC 2009
	 * @link http://www.facebake.com/
	 */
	 
	//link to common functions
	require_once(dirname((__FILE__))."/utilities/utilities.php"); 
	
	function quoteoftheday_init()
	{
		global $CONFIG;	
		
		extend_view('css','quoteoftheday/css/css');
		
		//get admin setting for update frequency
		$update_freq = get_setting("update_freq"); //custom get setting function (utilities.php)
		
		//add widget
		add_widget_type('quoteoftheday',elgg_echo("quoteoftheday:widget:title:".$update_freq),elgg_echo("quoteoftheday:widget:description"));
		
		//page handler for friendly url's
		register_page_handler('quoteoftheday','quoteoftheday_init_page_handler');
		
		// register entity type
		register_entity_type('object','quoteoftheday');
	
		//tool menu item
		if (isloggedin())
			add_menu(elgg_echo('quoteoftheday:title:home:'.$update_freq), $CONFIG->wwwroot . "pg/quoteoftheday");
	}
	
	function quoteoftheday_init_pagesetup()
	{
		global $CONFIG;

		//add submenu options
		if (get_context() == "quoteoftheday" && isloggedin()) 
		{
			$quote_freq = get_setting("update_freq");
			
			add_submenu_item(elgg_echo('quoteoftheday:menu:home'), $CONFIG->wwwroot."pg/quoteoftheday/home");
			add_submenu_item(elgg_echo('quoteoftheday:menu:the_quote:'.$quote_freq), $CONFIG->wwwroot."pg/quoteoftheday/the_quote");
			add_submenu_item(elgg_echo('quoteoftheday:menu:new_quotes'), $CONFIG->wwwroot."pg/quoteoftheday/new_quotes");
			add_submenu_item(elgg_echo('quoteoftheday:menu:top_quotes'), $CONFIG->wwwroot."pg/quoteoftheday/top_quotes");
			add_submenu_item(elgg_echo('quoteoftheday:menu:own_quotes'), $CONFIG->wwwroot."pg/quoteoftheday/own_quotes");
			//add_submenu_item(elgg_echo('quoteoftheday:menu:src_quotes'), $CONFIG->wwwroot."pg/quoteoftheday/src_quotes");
			add_submenu_item(elgg_echo('quoteoftheday:menu:archive'), $CONFIG->wwwroot."pg/quoteoftheday/archive");
		}
	}
	
	function quoteoftheday_init_page_handler($page) 
	{
		global $CONFIG;
		if(isset($page[0]))
			set_input("page", $page[0]);

		include($CONFIG->pluginspath . "quoteoftheday/index.php"); 
	}
	
	// this custom hook is used to override the metadata edit permissions on quote objects
	// It basically allows non-admin users to rate eachother's submitted quotes. 
	function quoteoftheday_permission_hook($hook, $entity_type, $returnvalue, $params)
	{
		$entity = $params['entity'];
		if($entity->getSubType()=="quoteoftheday" )
			return true;
	}
	
	//cron hook to update the featured quote
	function quoteoftheday_cron_hook($hook, $entity_type, $returnvalue, $params)
	{
		//Get the top rated quote that hasn't been featured yet and make that the new featured quote
		$count = get_entities_from_metadata("featured", "0", "object", "quoteoftheday", "", 10, 0, "", 0, true);
		$list = get_entities_from_metadata("featured", "0", "object", "quoteoftheday", "", $count, 0, "", 0, false);
	
		if($list)
		{
			usort($list, "rating_cmp"); //sort the list by rating
			
			echo $list[0]->desciption;
			$list[0]->featured = 1; //mark as featured
			$list[0]->featured_date = time(); //save feature date
			if(!$list[0]->save())
			{
				register_error(elgg_echo("quoteoftheday:updateerr"));
				forward();
			}
		}
	}
		
	//this action adds a user submitted quote
	register_action("quoteoftheday/add", false, $CONFIG->pluginspath . "quoteoftheday/actions/add.php", false);
	//this action is for rating the quotes
	register_action("quoteoftheday/rate", false, $CONFIG->pluginspath . "quoteoftheday/actions/rate.php", false);
	//this action is for deleting quotes
	register_action("quoteoftheday/delete", false, $CONFIG->pluginspath . "quoteoftheday/actions/delete.php", false);
	
	//this hook overrides edit permissions on metadata (see plugin hook function for more detail)
	register_plugin_hook("permissions_check:metadata", "object", "quoteoftheday_permission_hook", 0);
	
	//cron hook for updating teh featured quote
	$update_freq = get_setting("update_freq"); 
	register_plugin_hook("cron", $update_freq, "quoteoftheday_cron_hook", 0);
	
	//events
	register_elgg_event_handler('init','system','quoteoftheday_init');
	register_elgg_event_handler('pagesetup','system','quoteoftheday_init_pagesetup');

?>