<?PHP

	/**
	 * Quote of the Day - Plugin
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Mike Jones
	 * @copyright Dreamware LLC 2009
	 * @link http://www.facebake.com/
	 */
	
	$page = get_input("page");
	if($page=="")
		$page = "home";
	
	$quote_freq = get_setting("update_freq");
	$title_string = "quoteoftheday:title:".$page;
	if($page=="the_quote" || $page=="home")
		$title_string .= ":".$quote_freq; //change title based on featured frequency setting
	$view_string = "quoteoftheday/".$page;

	$title = elgg_view_title(elgg_echo($title_string));

	//main page area
	$area1 = $title;
	$area1 .= elgg_view($view_string);

	$content = elgg_view_layout("two_column_left_sidebar", '', $area1);
	page_draw(elgg_echo($title_string), $content);
?>