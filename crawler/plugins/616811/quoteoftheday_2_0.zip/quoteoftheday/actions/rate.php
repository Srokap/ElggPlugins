<?php
	
	/**
	 * Quote of the Day - Plugin
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Mike Jones
	 * @copyright Dreamware LLC 2009
	 * @link http://www.facebake.com/
	 *
	 * This action facilitates the rating of quotes 
	 */
	
	// Make sure we're logged in (send us to the front page if not)
	if (!isloggedin()) forward();

	// Get input data
	$direction = get_input('rating_direction'); //direction = up/down
	$quote_id = get_input('quote_id'); //quote guid

	if(!isset($quote_id) || $quote_id == 0)
	{
		register_error("quoteoftheday:rateerror");
		forward($_SERVER['HTTP_REFERER']);
	}
	
	//get the quote object
	$tmp = new ElggObject();
	$quote = $tmp->getObjectFromID($quote_id);
	$userid =  $_SESSION['user']->getGUID();

	//do some logical error checking (if not administrator)
	if(!($_SESSION['user']->admin || $_SESSION['user']->siteadmin))
	{
		//check if this is the user's own quote
		if($quote->getOwner() == $userid)
		{
			register_error(elgg_echo("quoteoftheday:ownerror"));
			forward($_SERVER['HTTP_REFERER']);
		}
		
		//check if this user rated this quote already
		if($quote->last_rater == $userid)
		{
			//NOTE: This isn't a perfect way to prevent multiple ratings. The same user can rate a quote twice, this just
			//      prevents them from doing it in succesion. Someone else has to rate the quote before they can
			//      rate it again.  It's the best way to deter multi-rating without making every rating an annotation
			//      which would cause a lot of unnecesary overhead in the database.
			register_error(elgg_echo("quoteoftheday:twicerateerror"));
			forward($_SERVER['HTTP_REFERER']);
		}
	}
	
	//go ahead and modify the rating
	{
		if($direction == "up") //up
		{
			$dir_string = "rating_up";
			$val = $quote->rating_up + 1;
		}
		else //down
		{
			$dir_string = "rating_down";
			$val = $quote->rating_down + 1;
		}
			
		if(!$quote->setMetaData($dir_string, $val) || !$quote->setMetaData("last_rater", $userid))
		{
			register_error(elgg_echo("quoteoftheday:rateerror"));
			forward($_SERVER['HTTP_REFERER']);
		}
	}
	
	// Success message
	system_message(elgg_echo("quoteoftheday:rated"));
	
	forward($_SERVER['HTTP_REFERER']);

		
?>