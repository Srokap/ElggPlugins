<?php
	
	/**
	 * Quote of the Day - Plugin
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Mike Jones
	 * @copyright Dreamware LLC 2009
	 * @link http://www.facebake.com/
	 *
	 * This action facilitates quote deletion
	 */
	
	// Make sure we're logged in (send us to the front page if not)
	if (!isloggedin()) forward();

	// Get input data
	$quote_id= get_input('id'); 

	//validate input
	if(!isset($quote_id) || $quote_id == 0)
	{
		register_error("quoteoftheday:deleteerror");
		forward($_SERVER['HTTP_REFERER']);
	}
	
	$tmp = new ElggObject();
	$quote = $tmp->getObjectFromID($quote_id);
	
	if($quote == null)
	{
		register_error(elgg_echo("quoteoftheday:deleteerror"));
		forward($_SERVER['HTTP_REFERER']);
	}
	
	//make sure we have permission to delete the quote (admins can delete any quote)
	if($_SESSION['user']->getGUID() == $quote->getOwner() || $_SESSION['user']->admin || $_SESSION['user']->siteadmin) 
	{
		if(!$quote->delete())
		{
			register_error(elgg_echo("quoteoftheday:deleteerror"));
			forward($_SERVER['HTTP_REFERER']);
		}
	}
	else
	{
		register_error(elgg_echo("quoteoftheday:deleteerror"));
		forward($_SERVER['HTTP_REFERER']);
	}
	
	// Success message
	system_message(elgg_echo("quoteoftheday:deleted"));
	
	// Forward to the main blog page with their original tab
	forward($_SERVER['HTTP_REFERER']);

		
?>