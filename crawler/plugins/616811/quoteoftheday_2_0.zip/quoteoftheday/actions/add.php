<?php

	/**
	 * Quote of the Day - Plugin
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Mike Jones
	 * @copyright Dreamware LLC 2009
	 * @link http://www.facebake.com/
	 *
	 * This action facilitates quote submission
	 */

		// Make sure we're logged in (send us to the front page if not)
		if (!isloggedin()) forward();

		// Get input data
		$quote_body = get_input('quote');
		$agree = get_input('agreement');
		$access = 1; //access is always "logged in users" for now
		
		//cache to the session incase submission fails
		$_SESSION['qod_quote'] = $quote_body;
		$_SESSION['qod_agree'] = $agree;
		
		// Make sure the quote isn't blank
		if (empty($quote_body)) 
		{
			register_error(elgg_echo("quoteoftheday:quoteblank"));
			forward($_SERVER['HTTP_REFERER']);
		}
		else if(empty($agree[0]))
		{
			register_error(elgg_echo("quoteoftheday:disagree"));
			forward($_SERVER['HTTP_REFERER']);
		}
		 else
	    {
			// Initialise a new ElggObject to be the quote
			$quote = new ElggObject();
			$quote->subtype = "quoteoftheday";
			$quote->owner_guid = $_SESSION['user']->getGUID();  //set owner
			$quote->access_id = $access;
			$quote->title = "Quote";
			$quote->description = $quote_body;
			$quote->rating = 0;       //rating
			$quote->rating_up = 0;    //rating system (up/down)
			$quote->rating_down = 0;
			$quote->last_rater = 0;   //save the ID of the last person to rate the quote (to discourage double rating)
			$quote->featured = 0;     //boolean
			$quote->feature_date = 0; 

			// Save the new object
			if (!$quote->save()) 
			{
				register_error(elgg_echo("quoteoftheday:error"));
				forward($_SERVER['HTTP_REFERER']);
			}

			add_to_river("river/object/quoteoftheday/create", "create", $_SESSION['user']->getGUID(), $quote->getGUID());
	
			// Success message
			system_message(elgg_echo("quoteoftheday:submitted"));
			
			// Remove the cache
			unset($_SESSION['qod_quote']); unset($_SESSION['qod_agree']);
				
			forward($_SERVER['HTTP_REFERER']);
				
		}
		
?>