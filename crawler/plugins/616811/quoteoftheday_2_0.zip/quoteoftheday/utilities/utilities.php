<?php
	/**
	 * Quote of the Day - Plugin
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Mike Jones
	 * @copyright Dreamware LLC 2009
	 * @link http://www.facebake.com/
	 *
	 * This file contains some common functions used throughout the plugin
	 */
	 
	//======================================
	//  Compare functions used for sorting
	//======================================
	
	//function used to compare two quotes by their ratings
	function rating_cmp($a, $b)
	{
		$val1 = (intval($a->rating_up) - intval($a->rating_down));
		$val2 = (intval($b->rating_up) - intval($b->rating_down));
		if ($val1 == $val2) {
			return 0;
		}
		return ($val1 > $val2) ? -1 : 1;
	}
	
	//this also compares quotes by their ratings but it puts quotes 
	// that have been previously featured at the bottom of the list
	function non_feat_rating_cmp($a, $b)
	{
		if($a->featured_date != 0 && $b->featured_date != 0)
		{
			$val1 = (intval($a->rating_up) - intval($a->rating_down));
			$val2 = (intval($b->rating_up) - intval($b->rating_down));
			if ($val1 == $val2) {
				return 0;
			}
			return ($val1 > $val2) ? -1 : 1;
		}
		else
		{
			//one is featured so put it down on the list
			if($a->featured_date != 0)
				return 1; //put a lower than b
			else
				return -1;
		}
	}
	
	//function used to compare two quotes by their featured dates
	function feat_cmp($a, $b)
	{
		$val1 = $a->featured_date;
		$val2 = $b->featured_date;
		if ($val1 == $val2) {
			return 0;
		}
		return ($val1 > $val2) ? -1 : 1;
	}
	
	
	//returns one page of entities based on $offset and $per_page. Basically this paginates entities outside of elgg's view functions
	function fetch_paginated_quotes($entities, $offset, $per_page)
	{
		$count = count($entities);
		$offset_list = array();
		if($offset==0 || $offset=="")
			$start = 0;
		else
			$start = $offset;
		for($i=$start;$i<=min($start+$per_page, $count)-1;$i++)
			array_push($offset_list, $entities[$i]);
		return $offset_list;
	}
	
	
	//this is used to get plugin settings but it lets us specify a default
	function get_setting($setting)
	{
		if($setting == "perpage")
		{	
			$perpage = get_plugin_setting('perpage','quoteoftheday');
			if($perpage==0)
				return 10;
			else
				return $perpage;
		}
		if($setting == "update_freq")
		{	
			$update_freq = get_plugin_setting('update_freq','quoteoftheday');
			if($update_freq=="")
				return "daily";
			else
				return $update_freq;
		}
	}
	
	//returns featured quote entity (if it exists) else false
	function get_featured_quote_entity()
	{
        //elgg_get_entities_from_metadata(array('metadata_name' => 'featured_group', 'metadata_value' => 'yes', 'types' => 'group', 'limit' => 10));

        $options = array('metadata_name' => 'featured', 'metadata_value' => '1', 'types' => 'object', 'subtypes' => 'quoteoftheday', 'limit' => 999);
        $ret = elgg_get_entities_from_metadata($options);
		//$ret = get_entities_from_metadata('featured', '1', 'object', 'quoteoftheday', 0, 9999, 0);
		if($ret)
		{
			usort($ret, "feat_cmp"); //sort the list by feature_date
			return $ret[0];
		}
		else
			return false;
	}
	
	
?>