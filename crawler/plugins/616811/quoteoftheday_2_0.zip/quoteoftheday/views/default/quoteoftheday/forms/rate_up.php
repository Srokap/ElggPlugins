<?php

	/**
	 * Quote of the Day - Plugin
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Mike Jones
	 * @copyright Dreamware LLC 2009
	 * @link http://www.facebake.com/
	 */
	
	global $CONFIG;
	
	//this is the form submitting up ratings;
	$form .= "<form action=\"".$CONFIG->wwwroot."action/quoteoftheday/rate\" method=\"POST\">";
	$form .= elgg_view('input/securitytoken');
    $form .= "<input type=\"hidden\" name=\"quote_id\" value=\"".$vars['quote_guid']."\" />";
	$form .= "<input type=\"hidden\" name=\"rating_direction\" value=\"up\" />";
	$form .= "<div class=\"quoteoftheday_rating_up\">".$vars['rating']."</div>";
	$form .= "<input type=\"submit\" id=\"quoteoftheday_vote_up\" name=\"direction\" value=\"\" />";
	$form .= "</form>";
	echo $form;
	
?>
