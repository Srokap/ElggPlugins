<?php

	/**
	 * Quote of the Day - Plugin
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Mike Jones
	 * @copyright Dreamware LLC 2009
	 * @link http://www.facebake.com/
	 */

?>

/*=============================
===============================
  Quote of the day plugin CSS
===============================
=============================*/

/*for checkboxes*/
.qod-checkboxes {
	font: 11px Arial;
	font-weight: bold;
}

/*intro to page box*/
.quoteoftheday_intro {
	background-color: #FFFFFF;
	padding: 25px;
}

/*submit quote box*/
.submit_form_box {
	background-color: #BACCE1;
	border: 1px solid #0F4B24;
	padding: 5px;
	text-align: center;
	margin-bottom: 10px;
    -webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
}

/*=======================================
   CSS for displaying listed quotes
========================================*/
.qod_listing {
	margin:0px 10px 5px 10px;
	background-color: #FFFFFF;
	padding: 5px;
	float: left;
	min-height: 53px;
    -webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
}
.qod_listing_icon {
	float:left;
}
.qod_listing_icon img {
	width: 30px;
	margin-right: 5px;
}
.qod_listing_top_block{
	min-height: 27px;
	/*float: left;*/
	min-width: 400px;
	padding-bottom: 3px;
}
.qod_listing_left_block {
	min-width: 300px;
	float: left;
}
.qod_listing_right_block {
	min-width: 300px;
	float: right;
}

/*these are for the boxes that display the rating values*/
.quoteoftheday_rating
{
	text-align: center;
	float: left;
	font-weight: bold;
	font: 14px Arial, Helvetica, sans-serif;
	min-width: 100px;
	height: 25px;
	margin-right: 15px;
}
.quoteoftheday_rating_up
{
	text-align: center;
	background-color: #FFFFFF;
	float: left;
	color: green;
	font-weight: bold;
	font: 14px Arial, Helvetica, sans-serif;
	min-width: 40px;
	margin-top: 2px;
	height: 17px;
	border-left: 2px solid green;
	border-top: 2px solid green;
	border-bottom: 2px solid green;
}
.quoteoftheday_rating_down
{
	margin-left: 5px;
	text-align: center;
	background-color: #FFFFFF;
	float: left;
	color: #A5201B;
	font-weight: bold;
	font: 14px Arial, Helvetica, sans-serif;
	min-width: 40px;
	margin-top: 2px;
	height: 17px;
	border-left: 2px solid #A5201B;
	border-top: 2px solid #A5201B;
	border-bottom: 2px solid #A5201B;
}

/*these are the buttons to vote quotes up or down */
#quoteoftheday_vote_up{
	float: left;
	color: transparent;
	border: none;
	height: 25px;
	width: 25px;
	min-width: 25px;
	margin:0;
	padding:0;
	background: url(<?php echo $vars['url'];?>/mod/quoteoftheday/graphics/up_vote.gif) 0 0 no-repeat;
}
#quoteoftheday_vote_up:hover{
	background-position: 0px -25px;
	width: 25px;
}
#quoteoftheday_vote_down{
	float: left;
	color: transparent;
	border: none;
	height: 25px;
	width: 25px;
	min-width: 25px;
	padding: 0;
	margin: 0;
	background: url(<?php echo $vars['url'];?>/mod/quoteoftheday/graphics/down_vote.gif) 0 0 no-repeat;
}
#quoteoftheday_vote_down:hover{
	background-position: 0px -25px;
	width: 25px;
}


/*END CSS FOR LISTING QUOTES*/


/*=======================================
   CSS for displaying quote in widget
========================================*/
.qod_widget {
	background-color: #FFFFFF;
	margin: 5px 10px 5px 10px;
	min-height: 53px;
	padding: 5px;
    -webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
}
.qod_widget_icon {
	float: left;
	padding: 5px;
}
.qod_widget_icon img {
	width: 30px;
	margin-right: 5px;
}
.qod_widget_wide_block{
	margin-top: 10px;
	min-height: 27px;
}
.qod_widget_left_block {
	text-align: right;
	padding-top: 2px;
	float: left;
	width: 121px;
}
.qod_widget_right_block {
	float: left;
	width: 141px;
}

/*river icon*/
.river_object_quoteoftheday_create {
	background: url(<?php echo $vars['url']; ?>mod/quoteoftheday/graphics/river_icon.gif) no-repeat left -1px;
}

/*==============================
   End Quoteoftheday Plugin
================================*/

