<?php

	/**
	 * Quote of the Day - Plugin
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Mike Jones
	 * @copyright Dreamware LLC 2009
	 * @link http://www.facebake.com/
	 *
	 * This view displays search results and form
	 */

     //this is depricated by the search plugin
/*
	global $CONFIG;
	gatekeeper();

	$offset = get_input("offset");
	$criteria = get_input("criteria");
	$per_page = get_setting("perpage");//get listings per-page
	
	echo elgg_view('quoteoftheday/forms/search'); //output form

	if($criteria != "")
	{
		echo elgg_echo('quoteoftheday:results')." '".$criteria."':<br /><br />";
		$criteria = $criteria;
		
		//perform the search
		$count = search_for_object($criteria, $per_page, $offset, "", true);
		$objects = search_for_object($criteria, $count, $offset, "", false);
		if($objects)
		{
			//Here we loop through the results and only pick out the quoteoftheday objects.
			//  This is another awful way of doing things but I don't know of a work around other
			//  than creating my own search function.  This is on the TODO list...
			$qod_objects = array();
			for($i=0;$i<count($objects);$i++)
			{
				if($objects[$i]->getSubtype()=="quoteoftheday")
					array_push($qod_objects, $objects[$i]);
			}
			echo elgg_view_entity_list($qod_objects, $count ,$offset, $per_page, true, false, true); 
		}
		else
			echo elgg_echo('quoteoftheday:noquotetodisplay');
	}

*/


?>