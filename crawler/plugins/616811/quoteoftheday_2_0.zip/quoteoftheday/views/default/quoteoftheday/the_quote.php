<?php

	/**
	 * Quote of the Day - Plugin
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Mike Jones
	 * @copyright Dreamware LLC 2009
	 * @link http://www.facebake.com/
	 *
	 * This view displays the featured quote
	 */

	global $CONFIG;
	gatekeeper();

	$todays_quote = get_featured_quote_entity();
	if($todays_quote!="")
    	echo elgg_view_entity($todays_quote);
	else
		echo elgg_echo('quoteoftheday:emptyset');
	
	//echo "<br /><p>";
	//echo "Last featured quote date: ".date('Y-m-d H:i:s', get_update_period_stamp())."<br />";
	//echo "</p>";

?>
