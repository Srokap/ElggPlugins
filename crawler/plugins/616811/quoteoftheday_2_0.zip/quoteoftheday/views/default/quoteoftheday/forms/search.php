<?php

	/**
	 * Quote of the Day - Plugin
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Mike Jones
	 * @copyright Dreamware LLC 2009
	 * @link http://www.facebake.com/
	 */

	//search for quotes form
	echo "<div class=\"submit_form_box\">";
	echo '<form action="" method="post">';
    echo elgg_view('input/securitytoken');
	echo "<label>".elgg_echo('quoteoftheday:search');
	echo elgg_view("input/text", array("internalname" => "criteria", 'class' => "general-textarea", 'size' => 50, 'maxlength' => 75));
	echo "</label><br />";
	echo elgg_echo("quoteoftheday:search:requirements")."<br />";
	echo '<input type="submit" name="submit" value="'.elgg_echo('quoteoftheday:submit').'" />';
	
	echo '</form></div>';

?>