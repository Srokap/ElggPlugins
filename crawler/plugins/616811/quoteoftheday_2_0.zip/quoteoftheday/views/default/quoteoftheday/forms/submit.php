<?php

	/**
	 * Quote of the Day - Plugin
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Mike Jones
	 * @copyright Dreamware LLC 2009
	 * @link http://www.facebake.com/
	 *
	 * Form for submitting quotes
	 */

	$action = "quoteoftheday/add";

	// Just in case we have some cached details
	if (isset($vars['qod_quote'])) 
	{
		$quote = $vars['qod_quote'];
		$agree = $vars['qod_agree'];
	}

?>

	<form action="<?php echo $vars['url']; ?>action/<?php echo $action; ?>" method="post">
        <?php
    echo elgg_view('input/securitytoken');

	echo "<div class=\"submit_form_box\">";
	echo "<label>".elgg_echo('quoteoftheday:yourquote');
	echo elgg_view("input/qod-text", array("internalname" => "quote", 'class' => "general-textarea", "value" => $quote, 'size' => 50, 'maxlength' => 250));
	echo "</label><br /><div class=\"qod-checkboxes\">";
	echo elgg_echo("quoteoftheday:maxinput")."<br /><br />";
	echo elgg_view("input/checkboxes", array("internalname" => "agreement", 'value' => $agree, 'class' => "input-checkboxes", 'options' => array(elgg_echo('quoteoftheday:agreement') => 'checked') ));
	echo "</div><br />";
	

?>
	<input type="submit" name="submit" value="<?php echo elgg_echo('submit'); ?>" />
	</form>
	</div>
	