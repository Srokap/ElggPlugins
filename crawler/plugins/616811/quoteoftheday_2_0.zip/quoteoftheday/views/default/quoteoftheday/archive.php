<?php

	/**
	 * Quote of the Day - Plugin
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Mike Jones
	 * @copyright Dreamware LLC 2009
	 * @link http://www.facebake.com/
	 *
	 * This view displays an archive of all previously featured quotes of the day
	 */

	//this file contains some common functions used below
	require_once(dirname(dirname(dirname(dirname((__FILE__)))))."/utilities/utilities.php");
	
	global $CONFIG;
	gatekeeper();
	
	$offset = get_input("offset");
	$per_page = get_setting("perpage");//get listings per-page
	
	//grab all of the quotes that haven't been featured yet
    $options = array('metadata_name' => 'featured', 'metadata_value' => '1', 'types' => 'object', 'subtypes' => 'quoteoftheday', 'limit' => 999);
    $entities = elgg_get_entities_from_metadata($options);
    $count = count($entities);
    
	//$count = get_entities_from_metadata("featured", "1", "object", "quoteoftheday", "", $per_page, 0, "", 0, true);
	//$entities = get_entities_from_metadata("featured", "1", "object", "quoteoftheday", "", $count, 0, "", 0, false);

	if($entities)
	{
		//sort the quotes with our custom compare function (in utilities.php)
		usort($entities, "feat_cmp"); 
		
		//we have to manually paginate the entities because we grabbed the entire list in order to sort it
		$output_list = fetch_paginated_quotes($entities, $offset, $per_page);
		
		echo elgg_view_entity_list($output_list, $count, $offset, $per_page, true, false, true); 
	}
	else
		echo elgg_echo('quoteoftheday:emptyfeat');

?>
