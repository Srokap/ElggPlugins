<?php

	/**
	 * Quote of the Day - Plugin
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Mike Jones
	 * @copyright Dreamware LLC 2009
	 * @link http://www.facebake.com/
	 * 
	 *  This view displays the most recently submitted quotes
	 */

	global $CONFIG;
	gatekeeper();

	$per_page = get_setting("perpage");//get listings per-page

    $offset = get_input("offset", 0);
    $view = elgg_list_entities(array('types' => 'object', 'subtypes' => 'quoteoftheday', 'limit' => $per_page, 'offset' => $offset, 'full_view' => TRUE));
	
	//$view = list_entities('object','quoteoftheday',0, $per_page, true, true, true);
	if($view!="")
		echo $view;
	else
		echo elgg_echo('quoteoftheday:emptyset');

?>
