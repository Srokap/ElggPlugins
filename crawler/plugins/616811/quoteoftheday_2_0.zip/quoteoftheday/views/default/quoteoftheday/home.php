<?php

	/**
	 * Quote of the Day - Plugin
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Mike Jones
	 * @copyright Dreamware LLC 2009
	 * @link http://www.facebake.com/
	 *
	 * This is the home view for the plugin. It displays a brief description of the plugin and a submit form
	 */
	
	echo '<div class="quoteoftheday_intro">';
	echo elgg_echo('quoteoftheday:description');
	echo '</div>';
	
	echo elgg_view_title(elgg_echo('quoteoftheday:submityourown'));
	echo "<br />";
	echo elgg_view('quoteoftheday/forms/submit');
	
?>