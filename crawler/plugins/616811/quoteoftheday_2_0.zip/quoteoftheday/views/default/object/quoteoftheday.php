<?php
	/**
	 * Quote of the Day - Plugin
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Mike Jones
	 * @copyright Dreamware LLC 2009
	 * @link http://www.facebake.com/
	 *
	 * This is a custom entity view for quotes
	 */
	 
	$quote = $vars["entity"];         //the quote object
	$is_widget = $vars["is_widget"];  //is this a widget listing
	
	if($quote)
	{
		//get data
		$owner = get_user($quote->owner_guid);
		$icon = elgg_view("profile/icon",array('entity' => $owner, 'size' => 'small'));   
		$quote_txt = $quote->description;
		$rating_up = $quote->rating_up;
		$rating_down = $quote->rating_down;
		
		//sanitize data (just for shitz and giggles)
		if($rating_up == "")
			$rating_up = 0;
		if($rating_down == "")
			$rating_down = 0;
		$total_rating = $rating_up - $rating_down;
		
		//these are forms for submitting up/down ratings;
		$ratings .= elgg_view('quoteoftheday/forms/rate_up', array('rating' => $rating_up, 'quote_guid' => $quote->getGUID())); 
		$ratings .= elgg_view('quoteoftheday/forms/rate_down', array('rating' => $rating_down, 'quote_guid' => $quote->getGUID())); 
		
		//quote info
		$info_quote = "<b>\"".$quote_txt."\"</b>";
		$info_time = sprintf(elgg_echo("quoteoftheday:strapline"), friendly_time($quote->time_created), $ownertxt);
		$info_url = "<a href=\"" . $owner->getURL() . "\">" . $owner->name ."</a>";
	
		$ratings = "<span title=\"" . elgg_echo('quoteoftheday:rating:popup') . "\">$ratings</span>";
		$total_rating = "<div class=\"quoteoftheday_rating\">".elgg_echo('quoteoftheday:rating').": <b>".$total_rating."</b></div>";
		
		//setup admin controls
		$controls = "";
		$featured = "";
		
		//if previosuly featured, display it
		if($quote->featured_date != 0)
			$featured .= elgg_echo("quoteoftheday:featured").date("m-d-Y", $quote->featured_date)."&nbsp;&nbsp;";
		
		if ($_SESSION['user']->getGUID() == $quote->owner_guid || $_SESSION['user']->admin || $_SESSION['user']->siteadmin) 
		{
			//this is for deleting the quote (allowed by owner and admin)
			$controls .= elgg_view("output/confirmlink", array(
			'href' => $vars['url'] . "action/quoteoftheday/delete?id=" . $quote->getGUID(),
			'text' => elgg_echo('quoteoftheday:delete'),
			'confirm' => elgg_echo('quoteoftheday:deleteconfirm')));
		}
		 
		if(!$is_widget) //regular listing
		{
			//display the listing
			echo '<div class="qod_listing">';
			echo '<div class="qod_listing_icon">';
			echo $icon;
			echo '</div>';
			echo '<div class="qod_listing_top_block">';
			echo $info_quote;
			echo '</div>';
			echo '<div class="qod_listing_left_block">';
			echo $info_time.$info_url;
			echo '</div>';
			echo '<div class="qod_listing_right_block">';
			echo $total_rating.$ratings;
			echo '</div>';
			echo '<div class="qod_listing_left_block">';
			echo $controls.$featured;
			echo '</div>';
			echo '</div><div style="clear:both;"></div>';	
		}
		else  //widget listing
		{
			echo '<div class="qod_widget">';
			echo '<div class="qod_widget_icon">';
			echo $icon;
			echo '</div>';
			echo '<div class="qod_widget_top_block">';
			echo $info_quote;
			echo '</div>';
			echo '<div class="qod_widget_wide_block">';
			echo $info_time.$info_url;
			if($featured != "")
				echo "<br />".$featured;
			if($controls != "")
				echo "<br />".$controls;
			echo '</div>';
			echo '<div class="qod_widget_wide_block">';
			echo '<div class="qod_widget_left_block">';
			echo $total_rating;
			echo '</div>';
			echo '<div class="qod_widget_right_block">';
			echo $ratings;
			echo '</div>';
			echo '</div>';
			echo '</div><div style="clear:both;"></div>';	
		}		
	}
?>