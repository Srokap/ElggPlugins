<?php
	/**
	 * Quote of the Day - Plugin
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Mike Jones
	 * @copyright Dreamware LLC 2009
	 * @link http://www.facebake.com/
	 *
	 * This is the widegt view for the Quoteoftehday widget
	 */
	 
	//get widget settings
	$diplaytype = $vars['entity']->displaytype;
	$num_display = $vars['entity']->num_display;

    $user = get_entity(page_owner());
    
	$list = "";
	
	if($diplaytype == "mine") //display my latest quotes
	{
       // $list = elgg_list_entities(array('types' => 'object', 'subtypes' => 'quoteoftheday', 'owner_guids' => $_SESSION['user']->getGUID(), 'limit' => $num_display, 'full_view' => TRUE));
        $options = array('types' => 'object', 'subtypes' => 'quoteoftheday', 'owner_guids' => $user->getGUID(), 'limit' => $num_display, 'offset' => $offset, 'full_view' => FALSE);
        $list = elgg_get_entities($options);
		//$list = get_entities('object', 'quoteoftheday', $_SESSION['user']->getGUID(), "", $num_display, 0);
	}
	else //display the latest featured quotes
	{
        $options = array('metadata_name' => 'featured', 'metadata_value' => '1', 'types' => 'object', 'subtypes' => 'quoteoftheday', 'limit' => $num_display);
        $list = elgg_get_entities_from_metadata($options);
		//$list = get_entities_from_metadata("featured", "1", "object", "quoteoftheday", "", $num_display, 0, "", 0, false);
	}
	
	if($list)
	{
		foreach($list as $entity)
		{
			echo elgg_view("object/quoteoftheday", array("entity" => $entity, "is_widget" => 1), false, true);
			//function elgg_view($view, $vars = "", $bypass = false, $debug = false, $viewtype = '') {
		}
	}
	else
		echo elgg_echo('quoteoftheday:noquotetodisplay');
?>