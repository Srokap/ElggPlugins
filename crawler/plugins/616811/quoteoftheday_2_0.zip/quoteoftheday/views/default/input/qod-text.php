<?php

	/**
	 * Quote of the Day - Plugin
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Mike Jones
	 * @copyright Dreamware LLC 2009
	 * @link http://www.facebake.com/
	 *
	 * Input for submitting quotes
	 * Same as standard elgg input/text but this one that allows us to specify a maximum character input
	 *
	 */

	
	$class = $vars['class'];
	if (!$class) $class = "input-text";
	
?>

<input type="text" <?php if ($vars['disabled']) echo ' disabled="yes" '; ?> <?php echo $vars['js']; ?> name="<?php echo $vars['internalname']; ?>" value="<?php echo htmlentities($vars['value'], null, 'UTF-8'); ?>" class="<?php echo $class ?>" size="<?php echo $vars['size'];?>" maxlength="<?php echo $vars['maxlength'];?>"/> 