<?PHP
	/**
	 * Quote of the Day - Plugin
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Mike Jones
	 * @copyright Dreamware LLC 2009
	 * @link http://www.facebake.com/
	 *
	 * Plugin settings form
	 */
?>
	 
<p>
    <?php 
	
	//Setting for quotes displayed per-page
	echo elgg_echo('quoteoftheday:settings:perpage');
    echo '<select name="params[perpage]">';

	for($i=5;$i<100;$i=$i+5)
	{
		if($i==10 && $vars['entity']->perpage=="")
			echo '<option value="'.$i.'" selected="yes">10</option>'; //default setting
		else
		{
			echo '<option value="'.$i.'"';
			if ($vars['entity']->perpage == $i) 
				echo " selected=\"yes\" >";
			else
				echo " >";
			echo $i."</option>";
		}
	}
    echo "</select>";
	
	
	//Setting for how frequently the quotes get updated
	echo "<br />".elgg_echo('quoteoftheday:settings:update_freq');
	?>
	<select name="params[update_freq]">
    <option value="daily" <?php if ($vars['entity']->update_freq == "day" || $vars['entity']->update_freq == "") echo " selected=\"yes\" "; ?>><?php echo elgg_echo('quoteoftheday:settings:everyday'); ?></option>
    <option value="weekly" <?php if ($vars['entity']->update_freq == "week") echo " selected=\"yes\" "; ?>><?php echo elgg_echo('quoteoftheday:settings:everyweek'); ?></option>
	<option value="monthly" <?php if ($vars['entity']->update_freq == "month") echo " selected=\"yes\" "; ?>><?php echo elgg_echo('quoteoftheday:settings:everymonth'); ?></option>
    </select>
	
</p>

