<?php
	/**
	 * Quote of the Day - Plugin
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Mike Jones
	 * @copyright Dreamware LLC 2009
	 * @link http://www.facebake.com/
	 *
	 * English translation
	 */

$english = array(
	
		//submenu items
		'quoteoftheday:menu:home' => 'Home',
		'quoteoftheday:menu:the_quote:daily' => 'Today\'s Quote',
		'quoteoftheday:menu:the_quote:weekly' => 'This Week\'s Quote',
		'quoteoftheday:menu:the_quote:monthly' => 'This Month\'s Quote',
		'quoteoftheday:menu:new_quotes' => 'Recently Submitted',
		'quoteoftheday:menu:top_quotes' => 'Top Rated Quotes',
		'quoteoftheday:menu:own_quotes' => 'My Quotes',
		'quoteoftheday:menu:src_quotes' => 'Search Quotes',
		'quoteoftheday:menu:archive' => 'Featured Archive',
		'quoteoftheday:menu:admin' => 'Administrator',
			
		//page titles
		'quoteoftheday:title:home:daily' => 'Quote Of The Day',
		'quoteoftheday:title:home:weekly' => 'Quote Of The Week',
		'quoteoftheday:title:home:monthly' => 'Quote Of The Month',
		'quoteoftheday:title:the_quote:daily' => 'Today\'s Quote',
		'quoteoftheday:title:the_quote:weekly' => 'This Week\'s Quote',
		'quoteoftheday:title:the_quote:monthly' => 'This Month\'s Quote',
		'quoteoftheday:title:sub_quote' => 'Submit Your Own Quote',
		'quoteoftheday:title:top_quotes' => 'Top Rated Quotes',
		'quoteoftheday:title:own_quotes' => 'My Submitted Quotes',
		'quoteoftheday:title:new_quotes' => 'Recently Submitted Quotes',
		'quoteoftheday:title:src_quotes' => 'Search Quotes',
		'quoteoftheday:title:archive' => 'Archive of Featured Quotes',
		'quoteoftheday:title:admin' => 'Administrator Options',
		
		//messages
		'quoteoftheday:submitted' => 'Quote submitted successfully. Thank you.',
		'quoteoftheday:deleted' => 'Quote deletion successfull.',
		'quoteoftheday:rated' => 'Your rating was submitted successfully.  Thank you.',
		'quoteoftheday:error' => 'There was an error saving your quote.  Please try again.',
		'quoteoftheday:rateerror' => 'There was an error rating the quote.  Please try again.',
		'quoteoftheday:ownerror' => 'You can\'t rate your own quote! That\'s just not fair.',
		'quoteoftheday:twicerateerror' => 'Nice try... You already rated that quote!',
		'quoteoftheday:quoteblank' => 'Please enter a quote before submitting.',
		'quoteoftheday:disagree' => 'We\'re sorry, you must agree to the terms of service before submitting a quote.',
		'quoteoftheday:deleteerror' => 'There was a unexpected error deleting your quote. Please try again.',
		'quoteoftheday:emptyset' => 'No submitted quotes to display yet. Submit one!',
        'quoteoftheday:emptyfeat' => 'No quotes have been featured yet!',
		'quoteoftheday:updateerr' => 'Error updating the featured quote.',
		'quoteoftheday:noquotetodisplay' => 'No quotes to display',
		
		//listing controls
		'quoteoftheday:strapline' => 'Submitted %s by %s',
		'quoteoftheday:rating:popup' => 'Rate this quote either up or down',
		'quoteoftheday:rating' => 'Rating',
		'quoteoftheday:deleteconfirm' => 'Are you sure you want to delete this quote?',
		'quoteoftheday:delete' => 'Delete Quote',
		'quoteoftheday:featured' => '> Featured: ',
		'quoteoftheday:results' => 'Results for', 
		
		//object names
		'item:object:quoteoftheday' => 'Quote of the Day',
		
		//river stuff
		'quoteoftheday:river:created' => '%s submitted',
		'quoteoftheday:river:create' => 'a new quote',
		
		//settings 
		'quoteoftheday:settings:perpage' => 'Quotes to display per page: ',
		'quoteoftheday:settings:update_freq' => 'Frequency of featured quote updates: ',
		'quoteoftheday:settings:myquotes' => 'My quotes',
		'quoteoftheday:settings:featured' => 'Featured Quotes',
		'quoteoftheday:settings:everyday' => 'Every Day',
		'quoteoftheday:settings:everyweek' => 'Every Week',
		'quoteoftheday:settings:everymonth' => 'Every Month',
		
		//Widget Text
		'quoteoftheday:widget:title:daily' => 'Quote of the day',
		'quoteoftheday:widget:title:weekly' => 'Quote of the week',
		'quoteoftheday:widget:title:monthly' => 'Quote of the month',
		'quoteoftheday:widget:description' => 'Displays the current featured quote',
		'quoteoftheday:widget:num_display' => 'Quotes to display',
		'quoteoftheday:widget:displaytype' => 'Type of quotes', 
		
		//misc
		'quoteoftheday:search' => 'Search for quotes: ',
		'quoteoftheday:submit' => 'Find',
		'quoteoftheday:submityourown' => 'Submit your own quote',
		'quoteoftheday:search:requirements' => '(Search string must be greater than 4 characters long)',
		'quoteoftheday:yourquote' => 'Your Quote',
		'quoteoftheday:maxinput' => '(maximum of 250 characters)',
		'quoteoftheday:agreement' => 'I agree that this quote is not offensive and <br /> does not violate the terms of service.',
		'quoteoftheday:description' => 'Welcome to the quote section. Here you can submit your own quotes and view/rate other user\'s submitted quotes. The highest rated quotes will be selected and featured across the whole site.  Yours could be next!', 
		);
		
add_translation('en',$english);
?>