<?php
 /**
 *	Elgg - Sitecode plugin
 *	This plugin adds extra protection to user registration. Only users with a valid site code can register
 *	Author : Sarath C | Team Webgalli
 *	Team Webgalli | Elgg developers and consultants
 *	Mail : info@webgalli.com
 *	Web	: http://webgalli.com | http://plugingalaxy.com
 *	Skype : 'team.webgalli'
 *	@package Elgg-webgalli_sitecode
 *	Licence : GNU2
 *	Copyright : Team Webgalli 2011-2015
 */
	$english = array(
	
			'webgalli_sitecode:validcodeneeded' => "You need to provide a valid site code for registering.",
			'webgalli_sitecode:inputsitecode' => "Add the site code for your site",
			'webgalli_sitecode:label' => "Enter the site code to register<br/>",
	
	);
					
	add_translation("en",$english);

?>