<?php
 /**
 *	Elgg - Sitecode plugin
 *	This plugin adds extra protection to user registration. Only users with a valid site code can register
 *	Author : Sarath C | Team Webgalli
 *	Team Webgalli | Elgg developers and consultants
 *	Mail : info@webgalli.com
 *	Web	: http://webgalli.com | http://plugingalaxy.com
 *	Skype : 'team.webgalli'
 *	@package Elgg-webgalli_sitecode
 *	Licence : GNU2
 *	Copyright : Team Webgalli 2011-2015
 */
$label = elgg_echo('webgalli_sitecode:label');
$input = elgg_view('input/text', array('name' => 'site_code','required' => TRUE));
?>
<div>
	<label><?php echo "$label $input"; ?></label>
</div>