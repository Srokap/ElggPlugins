<?php

 /**
 *	Elgg - Sitecode plugin
 *	This plugin adds extra protection to user registration. Only users with a valid site code can register
 *	Author : Sarath C | Team Webgalli
 *	Team Webgalli | Elgg developers and consultants
 *	Mail : info@webgalli.com
 *	Web	: http://webgalli.com | http://plugingalaxy.com
 *	Skype : 'team.webgalli'
 *	@package Elgg-webgalli_sitecode
 *	Licence : GNU2
 *	Copyright : Team Webgalli 2011-2015
 */

function webgalli_sitecode_init() {
	elgg_extend_view('register/extend', 'webgalli_sitecode/register', 1000);
	elgg_register_plugin_hook_handler('action', 'register', 'webgalli_sitecode_register_hook');
}

function webgalli_sitecode_register_hook() {
	$input_site_code = get_input('site_code');
	$defined_site_code = elgg_get_plugin_setting('site_key', 'webgalli_sitecode');
	if ((!$input_site_code) or ($input_site_code != $defined_site_code)) {
		register_error(elgg_echo('webgalli_sitecode:validcodeneeded'));
		forward(REFERER);
	}
}

elgg_register_event_handler('init', 'system', 'webgalli_sitecode_init');
