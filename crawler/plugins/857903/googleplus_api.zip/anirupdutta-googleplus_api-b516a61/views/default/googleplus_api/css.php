<?php
/**
 * Elgg Google+ API CSS
 */
?>

#googleplus_api_site_settings .text_input {
	width: 350px;
}
#login_with_googleplus {
	padding: 10px 0 0 0;
}