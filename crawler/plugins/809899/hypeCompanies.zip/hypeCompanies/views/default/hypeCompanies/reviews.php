<?php


$company = $vars['entity'];

echo elgg_view_comments($company);

?>
