<?php

	/**
	 * Elgg default spotlight
	 * The spotlight area that displays across the site
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @copyright Curverider Ltd 2008
	 * @Stephen J O'Connor 2008
	 * @link http://elgg.org/
	 * @link http://openedweb.com/blog/
	 * 
	 */
?>

<table id="spotlight_table" width="100%"cellspacing="0">
	<tr>
		<td align="left" valign="top">
		<!-- spotlight LHS content -->
					<table id="spotlight_table_left_area" width="90%" cellspacing="0">
						<tr>
							<td colspan="3" align="left" valign="top">
							<h2>Dark Green Theme</h2>
							<p>A simple modification of the Elgg 1.0 default theme. You can change this text by editing /mod/dark_green_theme/views/default/spotlight/default.php.</p> 
							<!-- <p>Welcome to this Elgg spotlight area. This is a new feature introduced in Elgg v1.0 and we hope you will find it useful. Every plugin within Elgg can set its own content to be displayed in this space. This can include author infomation, help documents or tutorial videos.<p> -->							</td>
						</tr>
						
						<tr><td height="10" colspan="3" align="left" valign="top"></td>	</tr>
						
						<tr>
							<td width="46%" align="left" valign="top">
							<h2>Theme information</h2>
							
							<ul>
								<li>Spotlight appears only when logged off.</li>
								<li>Dark Green Theme has it's own graphics folder.</li>
							</ul>							</td>
							<td width="54%" align="left" valign="top">
							<ul>
								<li>Override system leaves Elgg core intact.</li>
								<li>Change the header by overwriting dark_green_theme/graphics/header.jpg</li>
								<li>Alter CSS by editing dark_green_theme/views/default/css.php</li>
                                <li>GNU Public License version 2</li>
								
							</ul>							</td>
							
					  </tr>
					</table>
		  <!-- /spotlight LHS content -->

		</td>		
		
		
		<td width="250" align="left" valign="top">
		<!-- spotlight RHS content -->
		<h2>More Help</h2>
					
		<ul>
			<li><a href="http://docs.elgg.org/wiki">Elgg Documentation Wiki</a></li>
			<li><a href="http://groups.google.com">Elgg User Mailing List</a></li>
			<li><a href="http://docs.elgg.org/wiki/Views/SystemViews">Populating this spotlight area</a></li>
            <li><a href="http://openedweb.com/blog">Dark Green Theme's creator's blog</a></li>
		</ul>
		<!-- /spotlight RHS content --></td>
	</tr>
</table>