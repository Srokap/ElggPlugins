<?php

	/**
	 * Elgg spotlight
	 * The spotlight area that displays across the site
	* @package Elgg
	 * @subpackage Core
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @copyright Curverider Ltd 2008
	 * @Stephen J O'Connor 2008
	 * @link http://elgg.org/
	 * @link http://openedweb.com/blog/
	 * 
	 */
?>

<div id="layout_spotlight">
<div id="wrapper_spotlight">
	
<div class="collapsable_box no_space_after">
	<div class="collapsable_box_header">

		<h1><?php echo elgg_echo("spotlight"); ?></h1>
	</div>
	<div class="collapsable_box_content" <?php if ($closed) echo "style=\"display:none\"" ?>>
<?php

	$context = get_context();
	if (!empty($context) && elgg_view_exists("spotlight/{$context}")) {
		echo elgg_view("spotlight/{$context}");
	} else {
		echo elgg_view("spotlight/default");
	}
	
	
	

?>
	</div><!-- /.collapsable_box_content -->
</div><!-- /.collapsable_box -->
	
</div><!-- /#wrapper_spotlight -->
</div><!-- /#layout_spotlight -->