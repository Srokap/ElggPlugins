<?php

	/**
	 * Elgg footer
	 * The standard HTML footer that displays across the site
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @copyright Curverider Ltd 2008
	 * @Stephen J O'Connor 2008
	 * @link http://elgg.org/
	 * @link http://openedweb.com/blog/
	 * 
	 */
	 
	 // get the tools menu
	$menu = get_register('menu');

?>

<div class="clearfloat"></div>

<div id="layout_footer">
<table width="958" height="79" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td width="217" height="50" valign="bottom"><small>Dark Green Theme by <br />
	    <a href="http://openedweb.com/blog">Stephen J O'Connor</a> </small>		</td>
		
	  <td width="741" height="50" align="right">
		<p class="footer_toolbar_links">
		<?php
			foreach($menu as $item) {
    			
    				echo " | <a href=\"{$item->value}\">" . $item->name . "</a>";
    			
			} 
		?>
		|
		</p>
		</td>
	</tr>
	
	<tr>
		<td width="217" height="28">
		<a href="http://www.elgg.org" target="_blank">
		<img src="<?php echo $vars['url']; ?>_graphics/powered_by_elgg_badge_drk_bckgnd.gif" border="0" />		</a>		</td>
		
	  <td width="741" height="28" align="left">
		<p class="footer_legal_links">&nbsp;</p>
	  </td>
	</tr>
</table>
</div><!-- /#layout_footer -->

<div class="clearfloat"></div>

</div><!-- /#page_wrapper -->
</div><!-- /#page_container -->

</body>
</html>