<?php

/**
 * Elgg widget layout
 *
 * @package Elgg
 * @subpackage Core
 */
$widgettypes = get_widget_types();

$owner = page_owner_entity();

$area1widgets = get_widgets(page_owner(),get_context(),1);
$area2widgets = get_widgets(page_owner(),get_context(),2);
$area3widgets = get_widgets(page_owner(),get_context(),3);

if (empty($area1widgets) && empty($area2widgets) && empty($area3widgets)) {
	if (isset($vars['area3'])) {
		$vars['area1'] = $vars['area3'];
	}
	if (isset($vars['area4'])) {
		$vars['area2'] = $vars['area4'];
	}
}

if ($owner && $owner->canEdit()) {

?>

<div id="customise_editpanel">

<div id="customise_editpanel_rhs">
<h2><?php echo elgg_echo("widgets:gallery"); ?></h2>
<div id="widget_picker_gallery">

<?php
	foreach($widgettypes as $handler => $widget) {
?>

<table class="draggable_widget" cellspacing="0"><tr><td>
	<h3>
		<?php echo $widget->name; ?>
		<input type="hidden" name="multiple" value="<?php if ((isset($widget->handler)) && (isset($widgettypes[$widget->handler]->multiple))) echo $widgettypes[$widget->handler]->multiple; ?>" />
		<input type="hidden" name="side" value="<?php if ((isset($widget->handler)) && (isset($widgettypes[$widget->handler])) && (is_array($widgettypes[$widget->handler]->positions))) echo in_array('side',$widgettypes[$widget->handler]->positions); ?>" />
		<input type="hidden" name="main" value="<?php if ((isset($widget->handler)) && (isset($widgettypes[$widget->handler])) && (is_array($widgettypes[$widget->handler]->positions))) echo in_array('main',$widgettypes[$widget->handler]->positions); ?>" />
		<input type="hidden" name="handler" value="<?php echo htmlentities($handler, ENT_QUOTES, 'UTF-8'); ?>" />
		<input type="hidden" name="description" value="<?php echo htmlentities($widget->description, ENT_QUOTES, 'UTF-8'); ?>" />
		<input type="hidden" name="guid" value="0" />
	</h3>
</td>
<td width="17px" align="right"></td>
<td width="17px" align="right"><a href="#"><img src="<?php echo $vars['url']; ?>_graphics/spacer.gif" width="14" height="14" class="more_info" /></a></td>
<td width="17px" align="right"><a href="#"><img src="<?php echo $vars['url']; ?>_graphics/spacer.gif" width="15" height="15" class="drag_handle" /></a></td>
</tr></table>

<?php
	}
?>

<br /><!-- bit of space at the bottom of the widget gallery -->

</div><!-- /#customise_editpanel_rhs -->
</div><!-- /#widget_picker_gallery -->

<div class="customise_editpanel_instructions">
<h2><?php echo elgg_echo('widgets:add'); ?></h2>
<?php echo elgg_view('output/longtext', array('value' => elgg_echo('widgets:add:description'))); ?>
</div>


<div id="customise_page_view">

<table cellspacing="0">
<tr>
	<td colspan="2" align="left" valign="top">

	<?php
	if(get_context() == "profile"){
	?>
			<h2 class="profile_box"><?php echo elgg_echo("widgets:profilebox"); ?></h2>
			<div id="profile_box_widgets">
			<p><small><?php echo elgg_echo('widgets:position:fixed'); ?></small></p>
			</div>
	<?php
	}
	?>

	</td>

	<td rowspan="2" align="left" valign="top">
		<h2><?php echo elgg_echo("widgets:rightcolumn"); ?></h2>
		<div id="rightcolumn_widgets" <?php if(get_context() == "profile")echo "class=\"long\""; ?>>
		<?php
			$rightcolumn_widgets = "";
			if (is_array($area3widgets) && sizeof($area3widgets) > 0) {
				foreach($area3widgets as $widget) {
					if (!empty($rightcolumn_widgets)) {
						$rightcolumn_widgets .= "::";
					}
					$rightcolumn_widgets .= "{$widget->handler}::{$widget->getGUID()}";
		?>

		<table class="draggable_widget" cellspacing="0"><tr><td width="149px">
			<h3>
				<?php echo $widgettypes[$widget->handler]->name; ?>
				<input type="hidden" name="handler" value="<?php
					echo $widget->handler;
				?>" />
				<input type="hidden" name="multiple" value="<?php echo $widgettypes[$widget->handler]->multiple; ?>" />
				<input type="hidden" name="side" value="<?php echo in_array('side',$widgettypes[$widget->handler]->positions); ?>" />
				<input type="hidden" name="main" value="<?php echo in_array('main',$widgettypes[$widget->handler]->positions); ?>" />
				<input type="hidden" name="description" value="<?php echo htmlentities($widgettypes[$widget->handler]->description, ENT_QUOTES, 'UTF-8'); ?>" />
				<input type="hidden" name="guid" value="<?php echo $widget->getGUID(); ?>" />
			</h3>
		</td>
		<td width="17px" align="right"></td>
		<td width="17px" align="right"><a href="#"><img src="<?php echo $vars['url']; ?>_graphics/spacer.gif" width="14" height="14" class="more_info" /></a></td>
		<td width="17px" align="right"><a href="#"><img src="<?php echo $vars['url']; ?>_graphics/spacer.gif" width="15" height="15" class="drag_handle" /></a></td>
		</tr></table>

		<?php

				}
			}
		?>

		</div>
	</td><!-- /rightcolumn td -->

</tr>

<tr>

<td>
<h2><?php echo elgg_echo("widgets:leftcolumn"); ?></h2>
<div id="leftcolumn_widgets">

<?php
	$leftcolumn_widgets = "";
	if (is_array($area1widgets) && sizeof($area1widgets) > 0) {
		foreach($area1widgets as $widget) {
			if (!empty($leftcolumn_widgets)) {
				$leftcolumn_widgets .= "::";
			}
			$leftcolumn_widgets .= "{$widget->handler}::{$widget->getGUID()}";
?>

<table class="draggable_widget" cellspacing="0"><tr><td width="149px">
	<h3>
		<?php echo $widgettypes[$widget->handler]->name; ?>
		<input type="hidden" name="handler" value="<?php
			echo $widget->handler;
		?>" />
		<input type="hidden" name="multiple" value="<?php echo $widgettypes[$widget->handler]->multiple; ?>" />
		<input type="hidden" name="side" value="<?php echo in_array('side',$widgettypes[$widget->handler]->positions); ?>" />
		<input type="hidden" name="main" value="<?php echo in_array('main',$widgettypes[$widget->handler]->positions); ?>" />
		<input type="hidden" name="description" value="<?php echo htmlentities($widgettypes[$widget->handler]->description, ENT_QUOTES, 'UTF-8'); ?>" />
		<input type="hidden" name="guid" value="<?php echo $widget->getGUID(); ?>" />
	</h3>
</td>
<td width="17px" align="right"></td>
<td width="17px" align="right"><a href="#"><img src="<?php echo $vars['url']; ?>_graphics/spacer.gif" width="14" height="14" class="more_info" /></a></td>
<td width="17px" align="right"><a href="#"><img src="<?php echo $vars['url']; ?>_graphics/spacer.gif" width="15" height="15" class="drag_handle" /></a></td>
</tr></table>

<?php

		}
	}
?>
</div>
</td>

<td>

<h2><?php echo elgg_echo("widgets:middlecolumn"); ?></h2>
<div id="middlecolumn_widgets">

<?php
	$middlecolumn_widgets = "";
	if (is_array($area2widgets) && sizeof($area2widgets) > 0) {
		foreach($area2widgets as $widget) {
			if (!empty($middlecolumn_widgets)) {
				$middlecolumn_widgets .= "::";
			}
			$middlecolumn_widgets .= "{$widget->handler}::{$widget->getGUID()}";
?>

<table class="draggable_widget" cellspacing="0"><tr><td width="149px">
	<h3>
		<?php echo $widgettypes[$widget->handler]->name; ?>
		<input type="hidden" name="handler" value="<?php
			echo $widget->handler;
		?>" />
		<input type="hidden" name="multiple" value="<?php echo $widgettypes[$widget->handler]->multiple; ?>" />
		<input type="hidden" name="side" value="<?php echo in_array('side',$widgettypes[$widget->handler]->positions); ?>" />
		<input type="hidden" name="main" value="<?php echo in_array('main',$widgettypes[$widget->handler]->positions); ?>" />
		<input type="hidden" name="description" value="<?php echo htmlentities($widgettypes[$widget->handler]->description, ENT_QUOTES, 'UTF-8'); ?>" />
		<input type="hidden" name="guid" value="<?php echo $widget->getGUID(); ?>" />
	</h3>
</td>
<td width="17px" align="right"></td>
<td width="17px" align="right"><a href="#"><img src="<?php echo $vars['url']; ?>_graphics/spacer.gif" width="14" height="14" class="more_info" /></a></td>
<td width="17px" align="right"><a href="#"><img src="<?php echo $vars['url']; ?>_graphics/spacer.gif" width="15" height="15" class="drag_handle" /></a></td>
</tr></table>

<?php

		}
	}
?>

</div>
</td>






</tr>
</table>

</div><!-- /#customise_page_view -->

<form action="<?php echo $vars['url']; ?>action/widgets/reorder" method="post">
<textarea style="display:none" name="debugField1" id="debugField1"><?php echo $leftcolumn_widgets; ?></textarea>
<textarea style="display:none" name="debugField2" id="debugField2"><?php echo $middlecolumn_widgets; ?></textarea>
<textarea style="display:none" name="debugField3" id="debugField3"><?php echo $rightcolumn_widgets; ?></textarea>

<input type="hidden" name="context" value="<?php echo get_context(); ?>" />
<input type="hidden" name="owner" value="<?php echo page_owner(); ?>" />

<?php
$ts = time();
$token = generate_action_token($ts);
?>
<input type="hidden" name="__elgg_ts" value="<?php echo $ts; ?>" />
<input type="hidden" name="__elgg_token" value="<?php echo $token; ?>" />

<input type="submit" value="<?php echo elgg_echo('save'); ?>" class="submit_button" onclick="$('a.toggle_customise_edit_panel').click();" />
<input type="button" value="<?php echo elgg_echo('cancel'); ?>" class="cancel_button" onclick="$('a.toggle_customise_edit_panel').click();" />

</form>
</div><!-- /customise_editpanel -->

<?php

		}

?>


<table cellspacing="0" id="widget_table">
<tr>
	<td colspan="0" align="left" valign="top" height="1px">
		
<?php

	/**
	 * Elgg thewire menu
	 * 
	 * @package Wire menu
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Shane Barron <admin@mercyspeak.com>
	 * @link http://www.mercyspeak.com
	 * 
	 */
?>


     

       

      <p align="center"><a href="<?php echo $vars['url']; ?>pg/profile/<?php echo $_SESSION['user']->username; ?>"><img src="<?php echo $_SESSION['user']->getIcon('large'); ?>" style="border: 1px solid #cccccc;padding:3px;" /></a></p>

       

      <p align="center">

       

       

      <script>

      var timeZoneOff=((new Date()).getTimezoneOffset())/(-60);

      function setCookie( name, value, expires/*days*/, path, domain, secure )

      {

      var today = new Date();

      today.setTime( today.getTime() );

      if ( expires ){ expires = expires * 1000 * 60 * 60 * 24; }

      var expires_date = new Date( today.getTime() + (expires) );

      document.cookie = name + "=" +escape( value ) +

      ( ( expires ) ? ";expires=" + expires_date.toGMTString() : "" ) +

      ( ( path ) ? ";path=" + path : "" ) +

      ( ( domain ) ? ";domain=" + domain : "" ) +

      ( ( secure ) ? ";secure" : "" );

      }

      setCookie("tzoff",timeZoneOff,100,"/","","");

      </script>

       

      <?

      if(isset($_COOKIE['tzoff']))

      {

        echo gmdate('D F j, Y g:i A',time(0)+((double)$_COOKIE['tzoff'])*3600);

      }

      else echo "Please refresh the dashboard.";

      ?>

      </p>

      <div style="padding-left: 10px; padding-right: 10px; padding-bottom: 20px;">


      <br />
 
      <div style="background:#ffffff url(<?php echo $vars['url']; ?>mod/riverdashboard/_graphics/26.png) no-repeat center left; margin-bottom: 5px; padding-left: 20px; padding-top: 5px; padding-bottom: 5px; border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><a href="<?php echo $vars['url']; ?>mod/profile/edit.php?username=<?php echo $_SESSION['user']->username; ?>">Edit Profile</a></h3></div>

      <div style="background:#ffffff url(<?php echo $vars['url']; ?>mod/riverdashboard/_graphics/38.png) no-repeat center left; margin-bottom: 5px; padding-left: 20px; padding-top: 5px; padding-bottom: 5px; border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><a href="<?php echo $vars['url']; ?>mod/profile/editicon.php">Profile Picture</a></h3></div>

      <div style="background:#ffffff url(<?php echo $vars['url']; ?>mod/riverdashboard/_graphics/40.png) no-repeat center left; margin-bottom: 5px; padding-left: 20px; padding-top: 5px; padding-bottom: 5px; border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><a href="<?php echo $vars['url']; ?>pg/photos/owned/<?php echo $_SESSION['user']->username; ?>">Manage Photos</a></h3></div>

      <div style="background:#ffffff url(<?php echo $vars['url']; ?>mod/riverdashboard/_graphics/7.png) no-repeat center left; margin-bottom: 5px; padding-left: 20px; padding-top: 5px; padding-bottom: 5px; border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><a href="<?php echo $vars['url']; ?>pg/file/<?php echo $_SESSION['user']->username; ?>/new">Upload File</a></h3></div>

      <div style="background:#ffffff url(<?php echo $vars['url']; ?>mod/riverdashboard/_graphics/24.png) no-repeat center left; margin-bottom: 5px; padding-left: 20px; padding-top: 5px; padding-bottom: 5px; border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><a href="<?php echo $vars['url']; ?>pg/blog/<?php echo $_SESSION['user']->username; ?>">Blog</a></h3></div>

      <div style="background:#ffffff url(<?php echo $vars['url']; ?>mod/riverdashboard/_graphics/16.png) no-repeat center left; margin-bottom: 5px; padding-left: 20px; padding-top: 5px; padding-bottom: 5px; border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><a href="<?php echo $vars['url']; ?>pg/thewire/<?php echo $_SESSION['user']->username; ?>">The Wire</a></h3></div>

      <div style="background:#ffffff url(<?php echo $vars['url']; ?>mod/riverdashboard/_graphics/18.png) no-repeat center left; margin-bottom: 5px; padding-left: 20px; padding-top: 5px; padding-bottom: 5px; border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><a href="<?php echo $vars['url']; ?>pg/messageboard/<?php echo $_SESSION['user']->username; ?>">Message Board</a></h3></div>

      <div style="background:#ffffff url(<?php echo $vars['url']; ?>mod/riverdashboard/_graphics/41.png) no-repeat center left; margin-bottom: 5px; padding-left: 20px; padding-top: 5px; padding-bottom: 5px; border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><a href="<?php echo $vars['url']; ?>pg/friends/<?php echo $_SESSION['user']->username; ?>">Friends</a></h3></div>

      <div style="background:#ffffff url(<?php echo $vars['url']; ?>mod/riverdashboard/_graphics/72.png) no-repeat center left; margin-bottom: 5px; padding-left: 20px; padding-top: 5px; padding-bottom: 5px; border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><a href="<?php echo $vars['url']; ?>pg/settings/user/<?php echo $_SESSION['user']->username; ?>">Settings</a></h3></div>

      </div>










	</td>
	<td rowspan="2" align="left" valign="top" height="100%">
			<?php if (isset($vars['area2'])) echo $vars['area2']; ?>
		<?php

			if (is_array($area2widgets) && sizeof($area2widgets) > 0)
			foreach($area2widgets as $widget) {
				echo elgg_view_entity($widget);
			}

		?>
		
		<?php

			if (is_array($area3widgets) && sizeof($area3widgets) > 0)
			foreach($area3widgets as $widget) {
				echo elgg_view_entity($widget);
			}

		?>


		</div><!-- /#widgets_right -->
	</td>
</tr>
<tr>
	<td align="left" valign="top">

		<!-- left widgets -->
		<div id="widgets_left">

		<?php

			if (is_array($area1widgets) && sizeof($area1widgets) > 0)
			foreach($area1widgets as $widget) {
				echo elgg_view_entity($widget);
			}

		?>

		</div><!-- /#widgets_left -->

	</td>
	<td align="left" valign="top">

		<!-- widgets middle -->
		<div id="widgets_middle">

		

		</div><!-- /#widgets_middle -->

	</td>
	</tr>
</table>
