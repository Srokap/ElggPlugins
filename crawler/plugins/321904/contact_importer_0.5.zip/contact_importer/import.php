<?php

    /**
    * Contact Importer Plugin (using OpenInviter)
    *
    * @package ElggContactImporter
    * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
    * @author Prashant Juvekar
    * @copyright SocialTrak, 2009
    * @link http://www.socialtrak.com
    */

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	
	global $CONFIG;
		
	gatekeeper();
	
	set_context('friends');
	set_page_owner($_SESSION['guid']);
	
	//set the title
	$body = elgg_view_title(elgg_echo('contact_importer:title'));

	$body .= "<div style='padding:10px;'>";

	// setup some defaults
	$oi_provider = $_POST['oi_provider'];
	if ( $oi_provider == null || empty($oi_provider) ) {
		$oi_provider = "gmail";
	}
	$oi_username = $_POST['oi_username'];
	$oi_password = $_POST['oi_password'];
	$oi_session_id = $_POST['oi_session_id'];

	// include and initialize openinviter	
	global $CONFIG;
	include ( $CONFIG->path . 'mod/contact_importer/OpenInviter/openinviter.php');
	$inviter=new OpenInviter();
	$oi_services=$inviter->getPlugins();

	// lookup the provider name
	foreach ($oi_services as $type=>$providers)	{
		foreach ($providers as $provider=>$details) {
			if ( $oi_provider == $provider ) {
				$oi_provider_name = $details['name'];
			}
		}
	}

	function get_web_mails () {
		return array (
			'aol' => 'AOL',
			'gmail' => 'GMail',
			'hotmail' => 'Live/Hotmail',
			'yahoo' => 'Yahoo!',
		);
	}
	
	function get_social_networks () {
		return array (
			'facebook' => 'Facebook',
			'linkedin' => 'LinkedIn',
			'twitter_ex' => 'Twitter',
			'orkut' => 'Orkut',
		);
	}

	function echo_OpenInviter_Inputs_form ($oi_services, $oi_provider, $oi_username) {

		$body  = "<form action='' method='POST' name='OpenInviter_Inputs'>";
		$body .= "<table>";

		$body .= "<tr>";
		$body .= "<td style='width:150px'><label>".elgg_echo('contact_importer:choose_provider')."</label></td>";

		$body .= "<td>";
		foreach ( get_web_mails() as $provider => $details )	
		{
			if ( $oi_provider == $provider ) {
				$body .= "<input type='radio' name='oi_provider' value='{$provider}' checked='checked'>&nbsp;&nbsp;{$details}</input><br />";
			} else {
				$body .= "<input type='radio' name='oi_provider' value='{$provider}'>&nbsp;&nbsp;{$details}</input><br />";
			}
		}
		$body .= "<br />";
		foreach ( get_social_networks() as $provider => $details )	
		{
			if ( $oi_provider == $provider ) {
				$body .= "<input type='radio' name='oi_provider' value='{$provider}' checked='checked'>&nbsp;&nbsp;{$details}</input><br />";
			} else {
				$body .= "<input type='radio' name='oi_provider' value='{$provider}'>&nbsp;&nbsp;{$details}</input><br />";
			}
		}
		$body .= "<br /";
		$body .= "</td>";

		$body .= "</tr>";

		$body .= "<tr>";
		$body .= "<td><label>".elgg_echo('contact_importer:username')."</label></td>";
		$body .= "<td><input type='text' name='oi_username' value='{$oi_username}' / ></td>";
		$body .= "</tr>";

		$body .= "<tr>";
		$body .= "<td><label>".elgg_echo('contact_importer:password')."</label></td>";
		$body .= "<td><input type='password' name='oi_password' / ></td>";
		$body .= "<td style='color:red;font-size:11px'>".elgg_echo('contact_importer:password:disclaimer').".</td>";
		$body .= "</tr>";

		$body .= "</table>";
		
		$body .= "<input type='submit' name='submit' value='".elgg_echo('contact_importer:submit')."' />";
		$body .= "<input type='hidden' name='oi_step' value='Inputs' />";
		
		$body .= "</form>";	
		
		return $body;
	}

	function echo_OpenInviter_Invite_form ($oi_provider, $oi_provider_name, $oi_username, $oi_contacts, $oi_session_id) {

		$body .= 
			"<script type='text/javascript'>
				function selectAll(count,which) 
				{
					for( z=1; z<=count; z++ )
					{
						var check_obj = document.getElementById('check_'+z)
						if ( check_obj ) {
							check_obj.checked = which;
						}
	   				}
				}
			</script>";
	
		$body .= "<form action='' method='POST' name='OpenInviter_Invite'>";
		if (count($oi_contacts)==0)
		{
			$body .= "<table class='contactImportTable'>";
			$body .= "<H2>".sprintf(elgg_echo('contact_importer:contacts'),$oi_provider_name)."</H2>";
			$body .= "<tr class='contactImportTableOddRow'>";
			$body .= "<td align='center' style='padding:20px;' colspan='".($plugType=='email'? "3":"2")."'>";
			$body .= "<label class='OpenInviter_Error'>".elgg_echo('contact_importer:nocontacts')."</label>";
			$body .= "</td>";
			$body .= "</tr>";
			$body .= "</table>";
		}
		else
		{
			$body .= "<input type='submit' name='send' value='".elgg_echo('contact_importer:send_invites')."' class='thButton'>" . "&nbsp;&nbsp";
			$body .= "<H2>".sprintf(elgg_echo('contact_importer:contacts2'),$oi_provider_name,count($oi_contacts))."</H2>";
			$body .= "<a href='javascript:none(0)' onclick='selectAll(".count($oi_contacts).",true)'>".elgg_echo('contact_importer:select_all')."</a>" . "&nbsp;&nbsp";
			$body .= "<a href='javascript:none(0)' onclick='selectAll(".count($oi_contacts).",false)'>".elgg_echo('contact_importer:unselect_all')."</a>";
			$body .= "<table class='contactImportTable'>";
			$body .= "<tr class='contactImportTableDesc'>";
			$body .= "<td style='font-weight:bold'>".elgg_echo('contact_importer:invite')."</td>";
			$body .= "<td style='font-weight:bold'>".elgg_echo('contact_importer:name')."</td>".($plugType == 'email' ?"<td style='font-weight:bold'>E-mail</td>":"")."</tr>";
			$odd=true;$counter=0;
			foreach ($oi_contacts as $email=>$name)
			{
				$counter++;
				if ($odd) {
					$class='contactImportTableOddRow'; 
				} else {
					$class='contactImportTableEvenRow';
				}
				$body .= "<tr class='{$class}'>";
				$body .= "<td><input name='check_{$counter}' id='check_{$counter}' value='{$counter}' type='checkbox' class='thCheckbox' checked>";
				$body .= "<input type='hidden' name='email_{$counter}' value='{$email}'>";
				$body .= "<input type='hidden' name='name_{$counter}' value='{$name}'>";
				$body .= "</td><td>{$name}</td>".($plugType == 'email' ?"<td>{$email}</td>":"")."</tr>";
				$odd=!$odd;
			}
			$body .= "</table>";
			$body .= "<a href='javascript:none(0)' onclick='selectAll(".count($oi_contacts).",true)'>".elgg_echo('contact_importer:select_all')."</a>" . "&nbsp;&nbsp";
			$body .= "<a href='javascript:none(0)' onclick='selectAll(".count($oi_contacts).",false)'>".elgg_echo('contact_importer:unselect_all')."</a><br />";
			$body .= "<input type='submit' name='send' value='".elgg_echo('contact_importer:send_invites')."' class='thButton'>" . "&nbsp;&nbsp";

			$body .= "<input type='hidden' name='oi_step' value='Invite' />";
			$body .= "<input type='hidden' name='oi_provider' value='{$oi_provider}'>";
			$body .= "<input type='hidden' name='oi_username' value='{$oi_username}'>";
			$body .= "<input type='hidden' name='oi_session_id' value='{$oi_session_id}'>";
		}
		$body .= "</form>";
		
		return $body;
	}
	
	function ers($ers)
	{
		if (!empty($ers))
		{
			$contents="<table cellspacing='0' cellpadding='0' style='border:1px solid red;' align='center' class='tbErrorMsgGrad'><tr><td valign='middle' style='padding:3px' valign='middle' class='tbErrorMsg'><img src='/images/ers.gif'></td><td valign='middle' style='color:red;padding:5px;'>";
			foreach ($ers as $key=>$error)
				$contents.="{$error}<br >";
			$contents.="</td></tr></table><br >";
			return $contents;
		}
	}
		
	function oks($oks)
	{
		if (!empty($oks))
		{
			$contents="<table border='0' cellspacing='0' cellpadding='10' style='border:1px solid #5897FE;' align='center' class='tbInfoMsgGrad'><tr><td valign='middle' valign='middle' class='tbInfoMsg'><img src='/images/oks.gif' ></td><td valign='middle' style='color:#5897FE;padding:5px;'>	";
			foreach ($oks as $key=>$msg)
				$contents.="{$msg}<br >";
			$contents.="</td></tr></table><br >";
			return $contents;
		}
	}

	if ( !isset($_POST['oi_step']) ) {
	
		$body .= echo_OpenInviter_Inputs_form($oi_services, $oi_provider, $oi_username);
		
	} else if ( $_POST['oi_step'] == "Inputs" ) {

		$ers=array();$oks=array();$import_ok=false;$done=false;
		$inviter->startPlugin($oi_provider);
		$internal=$inviter->getInternalError();
		if ($internal) 
		{
			$body .= echo_OpenInviter_Inputs_form($oi_services, $oi_provider, $oi_username);
			$body .= "<label class='OpenInviter_Error'>" . $internal . "</label>";
		}
		elseif (!$inviter->login($oi_username,$oi_password))
		{
			$body .= echo_OpenInviter_Inputs_form($oi_services, $oi_provider, $oi_username);
			$internal=$inviter->getInternalError();
			if ( $internal )
				$body .= "<label class='OpenInviter_Error'>" . $internal . "</label>";
			else
				$body .= "<label class='OpenInviter_Error'>" . elgg_echo('contact_importer:login_failed') . "</label>";
		}
		elseif (false===$contacts=$inviter->getMyContacts())
		{
			$body .= echo_OpenInviter_Inputs_form($oi_services, $oi_provider, $oi_username);
			$body .= "<label class='OpenInviter_Error'>" . elgg_echo('contact_importer:contact_err') . "</label>";
		}
		else
		{
			// success -> show the contacts
			$body .= echo_OpenInviter_Invite_form ($oi_provider, $oi_provider_name, $oi_username, $contacts, $inviter->plugin->getSessionID());
		}

	} else if ( $_POST['oi_step'] == "Invite" ) {
		$inviter->startPlugin($oi_provider);
		$internal=$inviter->getInternalError();
		if ($internal) 
		{
			$body .= echo_OpenInviter_Inputs_form($oi_services, $oi_provider, $oi_username);
			$body .= "<label class='OpenInviter_Error'>" . $internal . "</label>";
		}
		else
		{
			$selected_contacts=array(); $invitee_list="";
			foreach ($_POST as $key=>$val) {
				if (strpos($key,'check_')!==false) {
					$selected_contacts[$_POST['email_'.$val]]=$_POST['name_'.$val];
					$invitee_list .= "&nbsp;&nbsp;&nbsp;&nbsp;- " . $_POST['name_'.$val] . "<br />";
				} elseif (strpos($key,'email_')!==false) {
					$temp=explode('_',$key);$counter=$temp[1];
					if (is_numeric($temp[1])) $contacts[$val]=$_POST['name_'.$temp[1]];
				}
			}
			if (count($selected_contacts)==0) {
				$body .= "<label class='OpenInviter_Error'>" . elgg_echo('contact_importer:contacts_sel_err') . "</label>";
			} else {

				// Compose the message
				$message['subject'] = 
					sprintf(
						elgg_echo ('contact_importer:email:subject'),
						$CONFIG->site->name
					);
				$message['body'] = 
					sprintf(
						elgg_echo ('contact_importer:email:mailbody'),
						$CONFIG->site->name,
						$_SESSION['user']->name,
						$CONFIG->wwwroot
					);

				$sendMessage=$inviter->sendMessage($oi_session_id,$message,$selected_contacts);
				$inviter->logout();
				
				if ($sendMessage===-1)
				{
					$message_subject=$_SESSION['user']->name.": ".$message['subject'];
					$message_body=$message['body']; 
					$headers="From: {$_SESSION['user']->email}";
					foreach ($selected_contacts as $email=>$name) {
						mail($email,$message_subject,$message_body,$headers);
					}
					$body .= "<label class='OpenInviter_Info'>" . elgg_echo('contact_importer:send_success') . "<br />" . $invitee_list . "</label>";
				}
				elseif ($sendMessage===false)
				{
					$internal=$inviter->getInternalError();
					if ( $internal ) {
						$body .= "<label class='OpenInviter_Error'>" . $internal . "</label>";
					} else {
						$body .= "<label class='OpenInviter_Error'>" . elgg_echo('contact_importer:send_err') . "</label>";
					}
				}
				else 
				{
					$body .= "<label class='OpenInviter_Info'>" . elgg_echo('contact_importer:send_success') . "<br />" . $invitee_list . "</label>";
				}
			}
		}		
	}

	$body .= "</div>";

	$body = elgg_view_layout('two_column_left_sidebar','',$body);
	
	// Finally draw the page
	page_draw(elgg_echo('contact_importer:title'), $body);
?>
