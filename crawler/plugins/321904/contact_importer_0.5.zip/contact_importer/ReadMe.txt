
/**
 * Contact Importer Plugin (using OpenInviter)
 *
 * @package ElggContactImporter
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Prashant Juvekar
 * @copyright SocialTrak, 2009
 * @link http://www.socialtrak.com
 */

This module wraps the OpenInviter PHP library and provides 
a friendly interface for Elgg installations to add the import
capability. We have exposed only a handful of supported 
plugins in the form since these were known to work at the 
time of implementation as well as were considered important.
You can tweak the code to add more plugin support.

This module was developed and is used at www.socialtrak.com
for the purpose of allowing users to invite their friends 
from other social networks as well as by importing their 
webmail address books.

Right now, the message sent is hardcoded in but one could 
provide a textbox to collect message from the user to tack
onto the default message. 

Feel free to report bugs or requests to admin@socialtrak.com

