<?php

    /**
    * Contact Importer Plugin (using OpenInviter)
    *
    * @package ElggContactImporter
    * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
    * @author Prashant Juvekar
    * @copyright SocialTrak, 2009
    * @link http://www.socialtrak.com
    */

	$english = array(

		'contact_importer:plugin:name' => 'Import Contacts',
		'contact_importer:title' => 'Import Contacts',

		'contact_importer:email:subject' => 'Invitation to join %s',
		'contact_importer:email:mailbody' => '
You have been invited to join %s by %s. 
To join, click the following link:

	%s',

		'contact_importer:password:disclaimer' => "This password will not be stored by us",
		'contact_importer:submit' => "Submit",
		'contact_importer:choose_provider' => "Choose a Provider",
		'contact_importer:username' => "Enter Username",
		'contact_importer:password' => "Enter Password",
		'contact_importer:contacts' => "Your %s contacts",
		'contact_importer:contacts2' => "Your %s contacts (Found %s)",
		'contact_importer:nocontacts' => "You do not have any contacts in your address book.",
		'contact_importer:send_invites' => "Send Invites",
		'contact_importer:select_all' => "Select All",
		'contact_importer:unselect_all' => "Unselect All",
		'contact_importer:invite' => "Invite?",
		'contact_importer:name' => "Name",
		'contact_importer:login_failed' => "Login failed. Please check the email and password you have provided and try again.",
		'contact_importer:contacts_err' => "Unable to get contacts.",
		'contact_importer:contacts_sel_err' => "You did not select any contacts to invite.",
		'contact_importer:send_success' => "Invitation emails were sent successfully to the following:",
		'contact_importer:send_err' => "There were errors while sending your invites.<br>Please try again later!",
	
	);
					
	add_translation("en",$english);
?>