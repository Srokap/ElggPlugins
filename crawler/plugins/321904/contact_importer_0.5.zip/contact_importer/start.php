<?php

    /**
    * Contact Importer Plugin (using OpenInviter)
    *
    * @package ElggContactImporter
    * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
    * @author Prashant Juvekar
    * @copyright SocialTrak, 2009
    * @link http://www.socialtrak.com
    */
	
	// Get config
	global $CONFIG;
	
	/**
	 * Initialisation function
	 */
	 
	 function contact_importer_init() {
	 
		// Get config
		global $CONFIG;
		
		// Load the language file
		register_translations($CONFIG->pluginspath . "contact_importer/languages/");
	
		// Load menu for logged in users
		if ( isloggedin() ) {
			// Menu options
			global $CONFIG;
			if (get_context() == "friends" || 
				get_context() == "friendsof" || 
				get_context() == "collections") {
					add_submenu_item(elgg_echo('contact_importer:plugin:name'),$CONFIG->wwwroot."mod/contact_importer/import.php",'import');
				}
		}
		
		// Extend CSS
		extend_view('css', 'contact_importer/css');

	}
	
	// Make sure init is called on initialisation
	register_elgg_event_handler('pagesetup','system','contact_importer_init',1000);
	
?>