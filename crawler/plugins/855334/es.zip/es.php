<?php
	$spanish= array(
		'friend_request' => "Solicitud de amistad",
		'friend_request:menu' => "Solicitudes de amistad",
		'friend_request:title' => "Peticiones de amigo para: %s",
	
		'friend_request:new' => "Nueva solicitud de amistad",
		
		'friend_request:friend:add:pending' => "Solicitud de amistad pendiente",
		
		'friend_request:newfriend:subject' => "%s quiere ser tu amigo!",
		'friend_request:newfriend:body' => "%s quiere ser tu amigo , pero esta esperando a que apruebes la solicitud ... inicia sesion ahora para aprobar la solicitud!

Puede ver las solicitudes de amistad pendientes al (Aseg�rese de que est� registrado en el sitio web antes de hacer clic en el siguiente enlace de lo contrario va a ser redirigido a la p�gina de inicio de sesi�n.):

%s

(No puedes responder a este correo electronico)",
		
		// Actions
		// Add request
		'friend_request:add:failure' => "Lo sentimos , debido a un error del sistema no se pudo completar su solicitud . Por favor , int�ntelo de nuevo.",
		'friend_request:add:successful' => "A solicitado ser amigo de %s. Se debe aprobar la solicitud antes de mostrarse en su lista de amigos",
		'friend_request:add:exists' => "Ya has solicitado ser amigo de %s.",
		
		// Approve request
		'friend_request:approve' => "Aceptar",
		'friend_request:approve:successful' => "%s es ahora un amigo",
		'friend_request:approve:fail' => "Error al crear relacion amiga con %s",
	
		// Decline request
		'friend_request:decline' => "Rechazar",
		'friend_request:decline:subject' => "%s a rechazado tu solicitud de amistad",
		'friend_request:decline:message' => "Estimado %s,

no quiero tu amistad.",
		'friend_request:decline:success' => "ya no quiere ser tu amigo",
		'friend_request:decline:fail' => "Error al quitar tu amistad , intentalo de nuevo",
		
		// Revoke request
		'friend_request:revoke' => "Anular",
		'friend_request:revoke:success' => "Anulada con exito la solicitud de amistad",
		'friend_request:revoke:fail' => "Error al anular la solicitude de amistad , intentalo de nuevo",
	
		// Vistas
		// Recibido
		'friend_request:received:title' => "Recibidas las solicitudes de amistad",
		'friend_request:received:none' => "No hay solicitudes pendientes de aprobacion",
	
		// Enviado
		'friend_request:sent:title' => "Enviadas solicitudes de amistad",
		'friend_request:sent:none' => "No hay solicitudes enviadas pendientes de aprobacion",
	);
					
	add_translation("es", $espa�ol);
?>