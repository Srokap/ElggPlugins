<?php
	/**
	* Dutch translation.
	* 
	* @package dutch_translation
	* @author ColdTrick IT Solutions
	* @copyright Coldtrick IT Solutions 2009
	* @link http://www.coldtrick.com/
	*/

	$dutch = array(

		/**
		* Menu items and titles
		*/

		'messages' => "Berichten",
		'messages:back' => "terug naar berichten",
		'messages:user' => "Jouw Postvak In",
		'messages:sentMessages' => "Verstuur berichten",
		'messages:posttitle' => "%s's berichten: %s",
		'messages:inbox' => "Postvak In",
		'messages:send' => "Verstuur een bericht",
		'messages:sent' => "Verstuurde berichten",
		'messages:message' => "Bericht",
		'messages:title' => "Titel",
		'messages:to' => "Aan",
		'messages:from' => "Van",
		'messages:fly' => "Verstuur",
		'messages:replying' => "Bericht beantwoorden",
		'messages:sendmessage' => "Verstuur een bericht",
		'messages:compose' => "Verstuur een bericht",
		'messages:sentmessages' => "Verstuurde berichten",
		'messages:recent' => "Recente berichten",
		'messages:original' => "Originele bericht",
		'messages:yours' => "Jouw bericht",
		'messages:answer' => "Antwoorden",
		'messages:toggle' => 'Selecteer alles',
		'messages:markread' => 'Markeer als gelezen',
		
		'messages:new' => 'New bericht',

		'notification:method:site' => 'Site',

		'messages:error' => 'Er was een probleem tijdens het opslaan van je bericht. Probeer het nogmaals.',
	
		'item:object:messages' => 'Berichten',

		/**
		* Status messages
		*/

		'messages:posted' => "Je bericht is succesvol verzonden.",
		'messages:deleted' => "Je bericht is succesvol verwijderd.",
		'messages:markedread' => "Je berichten zijn succesvol gemakreed als gelezen.",
		
		/**
		* Email messages
		*/

		'messages:email:subject' => 'Je hebt een nieuw bericht!',
		'messages:email:body' => "Je hebt een nieuw bericht van %s. Her bericht is:


		%s


		On jouw berichten te bekijken, klik hier:

		%s

		Om %s een bericht te sturen, klik hier:

		%s

		Je kunt niet antwoorden op deze email.",

		/**
		* Error messages
		*/

		'messages:blank' => "Sorry, je moet wel tekst invullen voordat we je bericht kunnen versturen.",
		'messages:notfound' => "Sorry, we konden het opgegeven bericht niet vinden.",
		'messages:notdeleted' => "Sorryd we konden dit bericht niet verwijderen.",
		'messages:nopermission' => "Je hebt geen toegang om dit bericht te mogen verwijderen.",
		'messages:nomessages' => "Er zijn geen berichten om weer te geven.",
		'messages:user:nonexist' => "We konden de geadresseerde niet vinden in de gebruikers database.",

	);
	
	add_translation("nl", $dutch);

?>