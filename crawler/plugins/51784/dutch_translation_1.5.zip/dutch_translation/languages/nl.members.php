<?php

	$dutch = array(

		/**
		* Site info details
		*/

		'members:members' => "Site gebruikers",
		'members:online' => "Active gebruikers",
		'members:active' => "site gebruikers",
		'members:searchtag' => "Gebruikers zoeken op tag",
		'members:searchname' => "Gebruikers zoeken op naam",

	);
	
	add_translation("nl", $dutch);
?>