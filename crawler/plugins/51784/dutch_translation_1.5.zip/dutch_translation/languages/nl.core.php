<?php
	/**
	* Dutch translation.
	* 
	* @package dutch_translation
	* @author ColdTrick IT Solutions
	* @copyright Coldtrick IT Solutions 2009
	* @link http://www.coldtrick.com/
	*/

	$dutch = array(

		/**
		* Sites
		*/

		'item:site' => 'Sites',

		/**
		* Sessions
		*/

		'login' => "Aanmelden",
		'loginok' => "Je bent aangemeld.",
		'loginerror' => "We konden je niet aanmelden. Dit kan komen omdat je account nog niet is gevalideerd of je hebt een verkeerde combinatie van gebruikersnaam en wachtwoord gebruikt. Controlleer of je gebruikersnaam en wachtwoord en probeer het nogmaals.",

		'logout' => "Afmelden",
		'logoutok' => "Je bent afgemeld.",
		'logouterror' => "We konden je niet afmelden. Probeer het nogmaals.",

		/**
		* Errors
		*/
		'exception:title' => "Welkom bij Elgg.",

		'InstallationException:CantCreateSite' => "Het is niet gelukt een standaard Elgg Site te maken met de volgende gegevens Naam: %s, URL: %s",

		'actionundefined' => "De gevraagde actie (%s) is niet gedefineerd in het systeem.",
		'actionloggedout' => "Sorry, je kunt deze actie niet uivoeren als je bent afgemeld.",

		'notfound' => "Het gevraagde item kon niet gevonden worden, of je hebt er geen toegang toe.",

		'SecurityException:Codeblock' => "Toegang tot het uitvoeren van 'privileged code block' is geweigerd",
		'DatabaseException:WrongCredentials' => "Elgg kon geen verbinding maken met de database met de opgegevens aanmeldgegegevens %s@%s (ww: %s).",
		'DatabaseException:NoConnect' => "Elgg kon de database '%s' niet selecteren, controlleer of de database is aangemaakt en de toegang geregeld is.",
		'SecurityException:FunctionDenied' => "Toegang tot prive functie '%s' is geweigerd.",
		'DatabaseException:DBSetupIssues' => "Er waren een aantal problemen: ",
		'DatabaseException:ScriptNotFound' => "Elgg kon het gevraagde database script niet vinden in %s.",

		'IOException:FailedToLoadGUID' => "Het laden van nieuw %s voor GUID: %d is mislukt",
		'InvalidParameterException:NonElggObject' => "Er wordt een non-ElggObject aan een ElggObject constructor gegeven!",
		'InvalidParameterException:UnrecognisedValue' => "Onherkenbare waarde aan de contructor gegeven.",

		'InvalidClassException:NotValidElggStar' => "GUID:%d is geen geldig %s",

		'PluginException:MisconfiguredPlugin' => "%s is een verkeerd geconfigureerde plugin.",

		'InvalidParameterException:NonElggUser' => "Er wordt een non-ElggUser aan een ElggUser constructor gegeven!",

		'InvalidParameterException:NonElggSite' => "Er wordt een non-ElggSite aan een ElggSite constructor gegeven!",

		'InvalidParameterException:NonElggGroup' => "Er wordt een  non-ElggGroup aan een ElggGroup constructor gegeven!",

		'IOException:UnableToSaveNew' => "Opslaan van nieuw %s mislukt",

		'InvalidParameterException:GUIDNotForExport' => "GUID is niet gespecificeerd tijdens export, dit mag nooit gebeuren.",
		'InvalidParameterException:NonArrayReturnValue' => "Entity serialisation functie leverde een non-array resultaat op",

		'ConfigurationException:NoCachePath' => "Cache pad ingesteld op leeg!",
		'IOException:NotDirectory' => "%s is geen directory.",

		'IOException:BaseEntitySaveFailed' => "Het opslaan van de basis entity gegevens voor het nieuwe object is mislukt!",
		'InvalidParameterException:UnexpectedODDClass' => "import() leverde een onverwachte ODD class",
		'InvalidParameterException:EntityTypeNotSet' => "Entity type moet zijn ingesteld.",

		'ClassException:ClassnameNotClass' => "%s is geen %s.",
		'ClassNotFoundException:MissingClass' => "Class '%s' was niet gevonden, ontbrekende plugin?",
		'InstallationException:TypeNotSupported' => "Type %s is niet ondersteund. Dit wijst op een fout in de installatie, waarschijnlijk veroorzaakt door een onvoltooide upgrade.",

		'ImportException:ImportFailed' => "Kon element %d niet importeren",
		'ImportException:ProblemSaving' => "Er was een probleem tijden het opslaan van %s",
		'ImportException:NoGUID' => "Nieuwe entity aangemaakt, maar heeft geen GUID. Dit mag niet gebeuren.",

		'ImportException:GUIDNotFound' => "Entity '%d' kon niet gevonden worden.",
		'ImportException:ProblemUpdatingMeta' => "Er was een probleem tijdens het bijwerken van '%s' voor entity '%d'",

		'ExportException:NoSuchEntity' => "Geen entity GUID: %d", 

		'ImportException:NoODDElements' => "Geen OpenDD elementen gevonden in de import gegevens, import mislukt.",
		'ImportException:NotAllImported' => "Niet alle elementen ge&iuml;mporteerd.",

		'InvalidParameterException:UnrecognisedFileMode' => "Onbekende bestands mode '%s'",
		'InvalidParameterException:MissingOwner' => "Alle bestanden moeten een eigenaar hebben!",
		'IOException:CouldNotMake' => "Kon %s niet aanmaken",
		'IOException:MissingFileName' => "Je moet een naam opgeven voor het openen van een bestand.",
		'ClassNotFoundException:NotFoundNotSavedWithFile' => "Filestore niet gevonden of class niet opgeslagen bij bestand!",
		'NotificationException:NoNotificationMethod' => "Geen berichtgevingsmethode gespecificeerd.",
		'NotificationException:NoHandlerFound' => "Geen handler gevonden voor '%s' of het was niet aan te roepen.",
		'NotificationException:ErrorNotifyingGuid' => "Er was een fout tijdens de berichtgeving naar %d",
		'NotificationException:NoEmailAddress' => "Kon het e-mail adress niet verkrijgen van GUID: %d",
		'NotificationException:MissingParameter' => "Er ontbreekt een vereiste parameter, '%s'",

		'DatabaseException:WhereSetNonQuery' => "WHERE set bevat non WhereQueryComponent",
		'DatabaseException:SelectFieldsMissing' => "Ontbrekende velden in een SELECT stijl query",
		'DatabaseException:UnspecifiedQueryType' => "Onbekend of ongespecificeerd query type.",
		'DatabaseException:NoTablesSpecified' => "Geen tabbelen gespecificeer voor query.",
		'DatabaseException:NoACL' => "Geen Access Control aangeleverd aan query",

		'InvalidParameterException:NoEntityFound' => "Geen Entity gevonden, of het bestaat niet of je hebt er geen toegang toe.",

		'InvalidParameterException:GUIDNotFound' => "GUID: %s kon niet worden gevonden, of je hebt er geen toegang toe.",
		'InvalidParameterException:IdNotExistForGUID' => "Sorry, '%s' bestaat niet voor GUID: %d",
		'InvalidParameterException:CanNotExportType' => "Sorry, ik weet niet hoe '%s' moet worden ge&euml;xporteerd",
		'InvalidParameterException:NoDataFound' => "Kon geen data vinden.",
		'InvalidParameterException:DoesNotBelong' => "Behoord niet tot Entity.",
		'InvalidParameterException:DoesNotBelongOrRefer' => "Behoord niet tot Entity of refereerd aan Entity.",
		'InvalidParameterException:MissingParameter' => "Ongeldige parameter, je moet een GUID opgeven.",

		'SecurityException:APIAccessDenied' => "Sorry, toegang tot de API is uitgeschakeld door de beheerder.",
		'SecurityException:NoAuthMethods' => "Geen authenticatie methoden gevonden die deze API aanvraag kon authoriseren.",
		'APIException:ApiResultUnknown' => "API Resultaat is van een onbekend type, dit mag nooit gebeuren.", 

		'ConfigurationException:NoSiteID' => "Site ID was niet gedefineerd.",
		'InvalidParameterException:UnrecognisedMethod' => "Onbekende methode aanroep '%s'",
		'APIException:MissingParameterInMethod' => "Ontbrekende parameter %s in methode %s",
		'APIException:ParameterNotArray' => "%s lijkt geen array te zijn.",
		'APIException:UnrecognisedTypeCast' => "Onbekend type in cast %s voor variabele '%s' in methode '%s'",
		'APIException:InvalidParameter' => "Ongeldige parameter gevonden voor '%s' in methode '%s'.",
		'APIException:FunctionParseError' => "%s(%s) heeft een parsing fout.",
		'APIException:FunctionNoReturn' => "%s(%s) retourneerde geen waarde.",
		'SecurityException:AuthTokenExpired' => "Authenticatie token ontbreekt, ongeldig of verlopen.",
		'CallException:InvalidCallMethod' => "%s moet worden aangeroepen met '%s'",
		'APIException:MethodCallNotImplemented' => "Methode aanroep '%s' is niet ge&iuml;mplementeerd.",
		'APIException:AlgorithmNotSupported' => "Algoritme '%s' wordt niet ondersteund of is uitgeschakeld.",
		'ConfigurationException:CacheDirNotSet' => "Cache directory 'cache_path' niet ingesteld.",
		'APIException:NotGetOrPost' => "Request methode moet GET of POST zijn",
		'APIException:MissingAPIKey' => "Onbrekende X-Elgg-apikey HTTP header",
		'APIException:MissingHmac' => "Onbrekende X-Elgg-hmac header",
		'APIException:MissingHmacAlgo' => "Onbrekende X-Elgg-hmac-algo header",
		'APIException:MissingTime' => "Onbrekende X-Elgg-time header",
		'APIException:TemporalDrift' => "X-Elgg-time is te ver in het verleden of toekomst. Epoch fout.",
		'APIException:NoQueryString' => "Geen query string opgegeven",
		'APIException:MissingPOSTHash' => "Onbrekende X-Elgg-posthash header",
		'APIException:MissingPOSTAlgo' => "Onbrekende X-Elgg-posthash_algo header",
		'APIException:MissingContentType' => "Onbrekend content type voor POST data",
		'SecurityException:InvalidPostHash' => "POST data hash is ongeldig - Verwacht %s naar kreeg %s.",
		'SecurityException:DupePacket' => "Packet signature al gezien.",
		'SecurityException:InvalidAPIKey' => "Ongeldige of ontbrekende API Key.",
		'NotImplementedException:CallMethodNotImplemented' => "Aanroep methode '%s' is op dit moment niet ondersteund.",

		'NotImplementedException:XMLRPCMethodNotImplemented' => "XML-RPC methode aanroep '%s' niet ge&iuml;mplementeerd.",
		'InvalidParameterException:UnexpectedReturnFormat' => "Aanroep van methode '%s' gaf een onverwacht resultaat.",
		'CallException:NotRPCCall' => "Aanroep lijkt geen geldige XML-RPC aanroep",

		'PluginException:NoPluginName' => "De plugin naam kon niet worden gevonden",

		'ConfigurationException:BadDatabaseVersion' => "Het database backend dat is ge&iuml;nstalleerd voldoet niet aan de basis vereisten om Elgg te kunne gebruiken. Controlleer de documentatie.",
		'ConfigurationException:BadPHPVersion' => "Je hebt op zijn minst PHP versie 5.2 nodig om Elgg uit te voeren.",
		'configurationwarning:phpversion' => "Elgg vereist minimaal PHP versie 5.2, je kunt het installeren op versie 5.1.6 maar sommige features kunnen dan niet functioneren. Gebruik op eigen risico.",


		'InstallationException:DatarootNotWritable' => "Er kan in de data directory %s niet worden geschreven.",
		'InstallationException:DatarootUnderPath' => "De data directory %s moet buiten het installatie pad zijn.",
		'InstallationException:DatarootBlank' => "Er is geen data directory opgegeven.",

		'SecurityException:authenticationfailed' => "Gebruiker kon niet worden geautoriseerd",

		'CronException:unknownperiod' => '%s is geen geldige periode.',

		'SecurityException:deletedisablecurrentsite' => 'Je kunt de Site die je op dit moment bekijkt niet verwijderen of uitschakelen!',

		'memcache:notinstalled' => 'PHP memcache module niet ge&iuml;nstalleerd, je moet php5-memcache installeren',
		'memcache:noservers' => 'Geen memcache servers dedefineerd, vul de $CONFIG->memcache_servers variabele',
		'memcache:versiontoolow' => 'Memcache vereist minimaal versie %s, je gebruikt %s',
		'memcache:noaddserver' => 'Multiple server support uitgeschakeld, je moet misschien de PECL memcache library bijwerken',
		
		'deprecatedfunction' => 'Waarschuwing: Deze code gebruikt de deprecated functies \'%s\' en is niet compatibel met deze versie van Elgg',
		/**
		* API
		*/
		'system.api.list' => "Toon alle beschikbare API calls op het systeem.",
		'auth.gettoken' => "Deze API call laat een gebruiker zich aanmelden. Retourneerd een authenticatie token dat gebruikt kan worden in plaats van gebruikersnaam en wachtwoord voor verdere authenticatie calls.",

		/**
		* User details
		*/

		'name' => "Weergave naam",
		'email' => "E-mail adres",
		'username' => "Gebruikersnaam",
		'password' => "Wachtwoord",
		'passwordagain' => "Wachtwoord (nogmaals voor verificatie)",
		'admin_option' => "Maak deze gebruiker admin?",

		/**
		* Access
		*/

		'ACCESS_PRIVATE' => "Prive",
		'ACCESS_LOGGED_IN' => "Aangemelde gebruikers",
		'ACCESS_PUBLIC' => "Publiek",
		'PRIVATE' => "Prive",
		'LOGGED_IN' => "Aangemelde gebruikers",
		'PUBLIC' => "Publiek",
		'access:friends:label' => "Vrienden",
		'access' => "Toegang",

		/**
		* Dashboard and widgets
		*/

		'dashboard' => "Dashboard",
		'dashboard:configure' => "Bewerk pagina",
		'dashboard:nowidgets' => "Je Dashboard is jou toegangsweg tot de Site. Klik op 'Bewerk pagina' om Widgets toe te voegen die je op de hoogte houden van content en je leven binnen de Site.",

		'widgets:add' => 'Voeg Widgets toe aan je pagina',
		'widgets:add:description' => "Kies de Widgets die je wilt toevoegen aan je pagina, door ze te slepen uit de <b>Widget gallerij</b> (rechts) naar &eacute;&eacute;n van de drie beschikbare Widget kolomen en positioneer ze zoals je ze graag wilt weergeven.<br><br>Om een Widget te verwijderen sleep het terug naar de <b>Widget gallerij</b>.",
		'widgets:position:fixed' => '(Vaste positie op pagina)',

		'widgets' => "Widgets",
		'widget' => "Widget",
		'item:object:widget' => "Widgets",
		'layout:customise' => "Pas de layout aan",
		'widgets:gallery' => "Widget gallerij",
		'widgets:leftcolumn' => "Linker Widgets",
		'widgets:fixed' => "Vaste positie",
		'widgets:middlecolumn' => "Middelste Widgets",
		'widgets:rightcolumn' => "Rechter Widgets",
		'widgets:profilebox' => "Profiel",
		'widgets:panel:save:success' => "Jouw Widgets zijn succesvol opgeslagen.",
		'widgets:panel:save:failure' => "Er is een fout opgetreden tijdens het opslaan van je Widgets. Probeer het nog een keer.",
		'widgets:save:success' => "De Widget was succesvol opgeslagen.",
		'widgets:save:failure' => "Er was een fout tijdens het opslaan van je Widget. Probeer het nog een keer.",
		'widgets:handlernotfound' => 'Deze Widget is corrupt of is uitgeschakeld door de Site Administrator.',
		

		/**
		* Groups
		*/

		'group' => "Groep", 
		'item:group' => "Groepen",

		/**
		* Profile
		*/

		'profile' => "Profiel",
		'profile:edit:default' => 'Vervang Profiel velden',
		'user' => "Gebruiker",
		'item:user' => "Gebruikers",
		'riveritem:single:user' => 'een gebruiker',
		'riveritem:plural:user' => 'sommige gebruikers',

		/**
		* Profile menu items and titles
		*/

		'profile:yours' => "Jouw Profiel",
		'profile:user' => "%s's Profiel",

		'profile:edit' => "Bewerk Profiel",
		'profile:profilepictureinstructions' => "De Profiel foto is het plaatje dat wordt weergegeven op je Profiel pagina.<br>Je kunt de foto zo vaak als je wilt aanpassen (Geaccepteerde formaten: GIF, JPG or PNG)",
		'profile:icon' => "Profiel foto",
		'profile:createicon' => "Cre&euml;r je avatar",
		'profile:currentavatar' => "Huidige avatar",
		'profile:createicon:header' => "Profiel foto",
		'profile:profilepicturecroppingtool' => "Profiel foto bijsnijden",
		'profile:createicon:instructions' => "Klik en sleep hieronder een vierkant die overeenkomt met hoe je de foto wilt bijsnijden. Een voorbeeld van je bijgesneden foto kun je rechts zien. Als je tevreden bent met het voorbeeld klik dan op 'Cre&euml;r je avatar'. Deze bijgesneden foto wordt gebruikt op de Site als je avatar.",

		'profile:editdetails' => "Bewerk details",
		'profile:editicon' => "Bewerk Profiel foto",

		'profile:aboutme' => "Over mij", 
		'profile:description' => "Over mij",
		'profile:briefdescription' => "Korte beschijving",
		'profile:location' => "Locatie",
		'profile:skills' => "Vaardigheden",  
		'profile:interests' => "Interesses", 
		'profile:contactemail' => "Contact e-mail",
		'profile:phone' => "Telefoon",
		'profile:mobile' => "Mobiel",
		'profile:website' => "Website",

		'profile:banned' => 'Dit Profiel is gebanned.',

		'profile:river:update' => "%s heeft zijn/haar Profiel bijgewerkt",
		'profile:river:iconupdate' => "%s heeft zijn/haar Profiel foto bijgewerkt",

		'profile:label' => "Profiel label",
		'profile:type' => "Profiel type",

		'profile:editdefault:fail' => 'Standaard Profiel kon niet worden opgeslagen',
		'profile:editdefault:success' => 'Item veld succesvol toegevoegd aan Standaard Profiel',


		'profile:editdefault:delete:fail' => 'Verwijderen van Item veld van Standaard Profiel mislukt',
		'profile:editdefault:delete:success' => 'Standaard Profiel Item succesvol verwijderd!',

		'profile:defaultprofile:reset' => 'Standaard systeem Profiel reset',
		'profile:resetdefault' => 'Reset Standaard Profiel',

		/**
		* Profile status messages
		*/

		'profile:saved' => "Je Profiel is succesvol opgeslagen.",
		'profile:icon:uploaded' => "Je Profiel foto is succesvol toegevoegd.",

		/**
		* Profile error messages
		*/

		'profile:noaccess' => "Je bent niet bevoegd dit Profiel aan te passen.",
		'profile:notfound' => "Sorry, we konden het opgegeven Profiel niet vinden.",
		'profile:cantedit' => "Sorry, je bent niet bevoegd om dit Profiel aan te passen.",
		'profile:icon:notfound' => "Sorry, er is een fout opgetreden tijden het opslaan van je Profiel foto.",

		/**
		* Friends
		*/

		'friends' => "Vrienden",
		'friends:yours' => "Jouw vrienden",
		'friends:owned' => "%s's vrienden",
		'friend:add' => "Voeg vriend toe",
		'friend:remove' => "Verwijder vriend",

		'friends:add:successful' => "Je hebt %s succesvol toegevoegd als vriend.",
		'friends:add:failure' => "We konden %s niet toevoegen als vriend. Probeer het nogmaals.",

		'friends:remove:successful' => "Je hebt %s succesvol verwijderd als vriend.",
		'friends:remove:failure' => "We konden %s niet verwijderen als vriend. Probeer het nogmaals.",

		'friends:none' => "Deze gebruiker heeft nog niemand toegevoegd als vriend.",
		'friends:none:you' => "Je hebt nog niemand toegevoegd als vriend! Zoek naar jou intresses om mensen te vinden om toe te voegen.",

		'friends:none:found' => "Geen vrienden gevonden.",

		'friends:of:none' => "Nog niemand heeft deze gebruiker toegevoegd als vriend.",
		'friends:of:none:you' => "Nog niemand heeft jou als vriend toegevoegd. Begin met het toevoegen van content en vul je Profiel aan om beter te vinden te zijn!",

		'friends:of:owned' => "Mensen die %s als vriend hebben",

		'friends:num_display' => "Aantal vrienden om weer te geven",
		'friends:icon_size' => "Avatar grootte",
		'friends:tiny' => "Klein",
		'friends:small' => "Normaal",
		'friends' => "Vrienden",
		'friends:of' => "Vrienden van",
		'friends:collections' => "Vriendengroepen",
		'friends:collections:add' => "Nieuwe vriendengroep",
		'friends:addfriends' => "Voeg vrienden toe",
		'friends:collectionname' => "Groepsnaam",
		'friends:collectionfriends' => "Vrienden in de vriendengroep",
		'friends:collectionedit' => "Bewerk deze vriendegroep",
		'friends:nocollections' => "Je hebt nog geen vriendengroepen.",
		'friends:collectiondeleted' => "Je vriendengroep is verwijderd.",
		'friends:collectiondeletefailed' => "We konden je vriendengroep niet verwijderen. Mogelijk heb je geen toegang of er was een ander probleem.",
		'friends:collectionadded' => "Je vriendengroep was succesvol aangemaakt",
		'friends:nocollectionname' => "Je moet je vriendengroep een naam geven voordat die opgeslagen kan worden.",
		'friends:expandall' => 'Alles uitvouwen',
		'friends:closeall' => 'Alles invouwen',
		'friends:collections:members' => "Groepsleden",
		'friends:collections:edit' => "Bewerk groep",

		'friends:river:created' => "%s heeft de vrienden Widget toegevoegd.",
		'friends:river:updated' => "%s heeft de vrienden Widget aangepast.",
		'friends:river:delete' => "%s heeft de vrienden Widget verwijderd.",
		'friends:river:add' => "%s heeft een vriend toegevoegd.",

		'friendspicker:chararray' => 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
	
		/**
		* Feeds
		*/
		'feed:rss' => 'Abboneer op RSS feed',
		'feed:odd' => 'Syndicate OpenDD',

		/**
		* links
		**/

		'link:view' => 'bekijk link',


		/**
		* River
		*/
		'river' => "River",			
		'river:relationship:friend' => 'is nu een vriend van',
		'river:noaccess' => 'Je hebt geen toegang tot dit item.',
		'river:posted:generic' => '%s plaatste',

		/**
		* Plugins
		*/
		'plugins:settings:save:ok' => "De instellingen voor de %s Plugin zijn succesvol opgeslagen.",
		'plugins:settings:save:fail' => "Er is een fout opgetreden tijdens het opslaan van de instellingen voor de %s Plugin.",
		'plugins:usersettings:save:ok' => "Gebruikers instellingen voor de %s Plugin zijn succesvol opgeslagen.",
		'plugins:usersettings:save:fail' => "Er is een fout opgetreden tijden het opslaan van de gebruikersinstellingen van de %s Plugin.",
		'item:object:plugin' => 'Plugin configuratie instellingen',

		/**
		* Notifications
		*/
		'notifications:usersettings' => "Berichtgevingsinstellingen",
		'notifications:methods' => "Geef aan welke methode je wilt toestaan.",
		'notifications:usersettings:save:ok' => "Je berichtgevingsinstellingen zijn succesvol opgeslagen.",
		'notifications:usersettings:save:fail' => "Er is een fout opgetreden tijdens het opslaan van je berichtgevingsinstellingen.",
		'user.notification.get' => 'Geef de berichtgevingsinstellingen voor de opgegeven gebruiker terug.',
		'user.notification.set' => 'Stel de berichtgevingsinstellingen in voor de opgegegeven gebruiker.',
		/**
		* Search
		*/

		'search' => "Zoeken",
		'searchtitle' => "Zoeken: %s",
		'users:searchtitle' => "Zoeken naar gebruikers: %s",
		'advancedsearchtitle' => "%s gevonden met %s",
		'notfound' => "Geen resultaten gevonden.",
		'next' => "Volgende",
		'previous' => "Vorige",

		'viewtype:change' => "Wijzig weergave methode",
		'viewtype:list' => "Lijst weergave",
		'viewtype:gallery' => "Gallerij",

		'tag:search:startblurb' => "Items gevonden met '%s':",

		'user:search:startblurb' => "Gebruikers gevonden met '%s':",
		'user:search:finishblurb' => "Om meer te zien, klik hier.",

		/**
		* Account
		*/

		'account' => "Account",
		'settings' => "Instellingen",
		'tools' => "Tools",
		'tools:yours' => "Jouw tools",

		'register' => "Registreer",
		'registerok' => "Je hebt je succesvol geregistreerd voor %s.",
		'registerbad' => "Je registratie is niet gelukt. De gebruikersnaam kan al bestaan, je wachtwoord kwam niet overeen of je gebruikersnaam of wachtwoord was te kort.",
		'registerdisabled' => "Registratie is uitgeschakeld door de Site Administrator",

		'firstadminlogininstructions' => 'Je nieuwe Elgg site is succesvol ge&iuml;nstalleerd en je administrator account is gecree&euml;rd. Je kunt nu je site verder configureren door de verschillende plugins te activeren.',
	
		'registration:notemail' => 'Het opgegeven e-mail adres lijkt geen geldig e-mail adres te zijn.',
		'registration:userexists' => 'Deze gebruikersnaam bestaat al',
		'registration:usernametooshort' => 'De gebruikersnaam moet minimaal 4 karakters lang zijn.',
		'registration:passwordtooshort' => 'Het wachtwoord moet minimaal 6 karakters lang zijn.',
		'registration:dupeemail' => 'Dit e-mail adres is al geregistreerd.',
		'registration:invalidchars' => 'Sorry, je gebruikersnaam bevat ongeldige karakters.',
		'registration:emailnotvalid' => 'Sorry, het opgegeven e-mail adres is ongeldig op dit systeem',
		'registration:passwordnotvalid' => 'Sorry, het opgegevens wachtwoord is ongeldig op dit systeem',
		'registration:usernamenotvalid' => 'Sorry, de opgegeven gebruikersnaam is ongeldig op dit systeem',

		'adduser' => "Gebruiker toevoegen",
		'adduser:ok' => "Nieuwe gebruiker is succesvol aangemaakt.",
		'adduser:bad' => "De nieuwe gebruiker kon niet worden aangemaakt.",

		'item:object:reported_content' => "Gemelde items",

		'user:set:name' => "Account naam instellingen",
		'user:name:label' => "Je naam",
		'user:name:success' => "Je naam is succesvol gewijzigd.",
		'user:name:fail' => "Er is een fout opgetreden tijdens het wijzigen van je naam.",

		'user:set:password' => "Account wachtwoord",
		'user:password:label' => "Je nieuwe wachtwoord",
		'user:password2:label' => "Nogmaals je nieuwe wachtwoord",
		'user:password:success' => "Wachtwoord gewijzigd",
		'user:password:fail' => "Er is een fout opgetreden tijdens het wijzigen van je wachtwoord.",
		'user:password:fail:notsame' => "De twee wachtwoorden komen niet overeen!",
		'user:password:fail:tooshort' => "Het wachtwoord is te kort!",

		'user:set:language' => "Taal instellingen",
		'user:language:label' => "Jouw taal",
		'user:language:success' => "Je taal instellingen zijn gewijzigd.",
		'user:language:fail' => "Er is een fout opgetreden tijdens het wijzigen van je taal instellingen.",

		'user:username:notfound' => 'Gebruikersnaam %s niet gevonden.',

		'user:password:lost' => 'Wachtwoord vergeten',
		'user:password:resetreq:success' => 'Er is een nieuw wachtwoord aangemaakt, controller je e-mail',
		'user:password:resetreq:fail' => 'Er kon geen nieuw wachtwoord worden aangemaakt.',

		'user:password:text' => 'Vul je gebruikersnaam hieronder in om een nieuw wachtwoord te krijgen. Wij versturen een e-mail met een link naar een unieke verificatie pagina. Klik op de link in het bericht en een nieuw wachtwoord zal naar je worden opgestuurd.',

		'user:persistent' => 'Onthoud mij',
		/**
		* Administration
		*/

		'admin:configuration:success' => "Je instellingen zijn opgeslagen.",
		'admin:configuration:fail' => "Je instellingen zijn niet opgeslagen.",

		'admin' => "Beheer",
		'admin:description' => "Het Beheer paneel maakt het mogelijk het hele systeem te beheren. Van gebruikers beheer tot hoe Plugins zich gedragen. Kies een optie om te beginnen.",

		'admin:user' => "Gebruikers Beheer",
		'admin:user:description' => "Via dit Beher paneel kun je de gebruikers instellingen van de site aanpassen. Kies een optie om te beginnen.",
		'admin:user:adduser:label' => "Klik hier om een nieuwe gebruiker toe te voegen...",
		'admin:user:opt:linktext' => "Configureer gebruikers...",
		'admin:user:opt:description' => "Configureer gebruikers en account informatie. ",
		'admin:site:access:warning' => "Het wijzigen van de toegangs instellingen is alleen van toepassing op nieuwe content.", 
			
		'admin:site' => "Site Beheer",
		'admin:site:description' => "Via dit Beheer paneel kun je de globale instellingen van de site beheren. Kies een optie om te beginnen.",
		'admin:site:opt:linktext' => "Configureer site...",
		'admin:site:opt:description' => "Configureer de technische en niet-technische instellingen van de site. ",

		'admin:plugins' => "Plugin Beheer",
		'admin:plugins:description' => "Via dit Beheer paneel kun je de veschillende Plugins van de site beheren en configureren.",
		'admin:plugins:opt:linktext' => "Configureer Plugins...",
		'admin:plugins:opt:description' => "Configureer de Plugins die zijn ge&iuml;nstalleerd op de site. ",
		'admin:plugins:label:author' => "Auteur",
		'admin:plugins:label:copyright' => "Copyright",
		'admin:plugins:label:licence' => "Licentie",
		'admin:plugins:label:website' => "Website",
		"admin:plugins:label:moreinfo" => 'Meer informatie',
		'admin:plugins:label:version' => "Versie",
		'admin:plugins:warning:elggversionunknown' => 'Waarschuwing: Deze plugin heeft geen compatibele Elgg versie gedefineerd.',
		'admin:plugins:warning:elggtoolow' => 'Waarschuwing: Deze plugin vereist een nieuwere versie van Elgg!',
		'admin:plugins:reorder:yes' => "Plugin %s was succesvol verplaatst.",
		'admin:plugins:reorder:no' => "Plugin %s kon niet worden verplaatst.",
		'admin:plugins:disable:yes' => "Plugin %s was succesvol uitgeschakeld.",
		'admin:plugins:disable:no' => "Plugin %s kon niet worden uitgeschakeld.",
		'admin:plugins:enable:yes' => "Plugin %s was succesvol ingeschakeld.",
		'admin:plugins:enable:no' => "Plugin %s kon niet worden ingeschakeld.",

		'admin:statistics' => "Statistieken",
		'admin:statistics:description' => "Dit is een statistisch overzicht van de site. Als je meer gedetaileerde informatie nodig hebt is er een prefessionele beheer functie beschikbaar.",
		'admin:statistics:opt:description' => "Bekijk statistische gegevens over gebruikers en objecten op de site.",
		'admin:statistics:opt:linktext' => "Bekijk statistieken...",
		'admin:statistics:label:basic' => "Basis site statistieken",
		'admin:statistics:label:numentities' => "Entities op de site",
		'admin:statistics:label:numusers' => "Aantal gebruikers",
		'admin:statistics:label:numonline' => "Aantal gebruikers online",
		'admin:statistics:label:onlineusers' => "Online gebruikers",
		'admin:statistics:label:version' => "Elgg versie",
		'admin:statistics:label:version:release' => "Release",
		'admin:statistics:label:version:version' => "Versie",

		'admin:user:label:search' => "Gebruikers zoeken:",
		'admin:user:label:seachbutton' => "Zoeken", 

		'admin:user:ban:no' => "Kan gebruiker niet blokkeren",
		'admin:user:ban:yes' => "Gebruiker geblokeerd.",
		'admin:user:unban:no' => "Kan gebruiker niet deblokkeren",
		'admin:user:unban:yes' => "gebruiker gedeblokeerd.",
		'admin:user:delete:no' => "Kan gebruiker niet verwijderen",
		'admin:user:delete:yes' => "Gebruiker verwijderd",

		'admin:user:resetpassword:yes' => "Wachtwoord gereset, gebruiker op de hoogte gebracht.",
		'admin:user:resetpassword:no' => "Wachtwoord kon niet worden gereset.",

		'admin:user:makeadmin:yes' => "Gebruiker is nu Admin.",
		'admin:user:makeadmin:no' => "Gebruiker kon geen Admin worden gemaakt.",
	
		'admin:user:removeadmin:yes' => "Gebruiker is geen administrator meer.",
		'admin:user:removeadmin:no' => "We konden de administrator rechten van deze gebruiker niet verwijderen.",
			
		/**
		* User settings
		*/
		'usersettings:description' => "Het gebruikers instellingen paneel geeft je controlle over al je persoonlijke instellingen. Van gebruikers management tot hoe Plugins zijn geconfigureerd. Kies een optie om te beginnen.",

		'usersettings:statistics' => "Jouw statistieken",
		'usersettings:statistics:opt:description' => "Bekijk statistische gegevens van gebruikers en objecten op je site.",
		'usersettings:statistics:opt:linktext' => "Account statistieken",

		'usersettings:user' => "Jouw instellingen",
		'usersettings:user:opt:description' => "Hier kun je je gebruikers instellingen configureren.",
		'usersettings:user:opt:linktext' => "Wijzig je instellingen",

		'usersettings:plugins' => "Plugins",
		'usersettings:plugins:opt:description' => "Configureer instellingen voor je actieve Plugins.",
		'usersettings:plugins:opt:linktext' => "Configureer Plugins",

		'usersettings:plugins:description' => "Dit paneel staat je toe persoonlijke instellingen te maken voor Plugins die door de Site Administrators zijn ge&iuml;nstalleerd.",
		'usersettings:statistics:label:numentities' => "Jouw entities",

		'usersettings:statistics:yourdetails' => "Jouw details",
		'usersettings:statistics:label:name' => "Volledige naam",
		'usersettings:statistics:label:email' => "E-mail",
		'usersettings:statistics:label:membersince' => "Lid sinds",
		'usersettings:statistics:label:lastlogin' => "Laatst aangemeld op",



		/**
		* Generic action words
		*/

		'save' => "Opslaan",
		'publish' => "Publiceer",
		'cancel' => "Annuleren",
		'saving' => "Opslaan ...",
		'update' => "Wijzig",
		'edit' => "Bewerk",
		'delete' => "Verwijder",
		'accept' => "Accepteer",
		'load' => "Laden",
		'upload' => "Upload",
		'ban' => "Blokkeer",
		'unban' => "Deblokkeer",
		'enable' => "Activeren",
		'disable' => "Deactiveren",
		'request' => "Aanvraag",
		'complete' => "Compleet",
		'open' => 'Open',
		'close' => 'Sluiten',
		'reply' => "Antwoord",
		'more' => 'Meer',
		'comments' => 'Reacties',
		'import' => 'Import',
		'export' => 'Export',
	
		'up' => 'Omhoog',
		'down' => 'Omlaag',
		'top' => 'Boven',
		'bottom' => 'Beneden',

		'invite' => "Uitnodigen",

		'resetpassword' => "Reset wachtwoord",
		'makeadmin' => "Maak admin",
		'removeadmin' => "Verwijder admin",
	
		'option:yes' => "Ja",
		'option:no' => "Nee",

		'unknown' => 'Onbekend',

		'active' => 'Actief',
		'total' => 'Totaal',

		'learnmore' => "Klik hier voor meer informatie.",

		'content' => "inhoud",
		'content:latest' => 'Laatste activiteit',
		'content:latest:blurb' => 'Of klik hier om de laatste inhoud van de hele site te bekijken',

		'link:text' => 'bekijk link',

		'enableall' => 'Alles activeren',
		'disableall' => 'Alles deactiveren',
	
		/**
		 * Generic questions
		 */
	
			'question:areyousure' => 'Weet je het zeker?',
	
		/**
		* Generic data words
		*/

		'title' => "Titel",
		'description' => "Omschrijving",
		'tags' => "Tags",
		'spotlight' => "Spotlight",
		'all' => "Alle",

		'by' => 'door',

		'annotations' => "Opmerkingen",
		'relationships' => "Relaties",
		'metadata' => "Metadata",

		/**
		* Input / output strings
		*/

		'deleteconfirm' => "Weet je zeker dat je dit item wilt verwijderen?",
		'fileexists' => "Er is reeds een bestand geupload. Om het te vervangen selecteer het hieronder:",

		/**
		 * User add
		 */

			'useradd:subject' => 'Gebruikers account aangemaakt',
			'useradd:body' => '
%s,

Een gebruikers account is voor jou aangemaakt op %s. Om je aan te melden, klikt hier:

	%s

En meld je aan met de volgende gegevens:

	Gebruikersnaam: %s
	Wachtwoord: %s
	
Als je bent aangemeld raden we je aan om je wachtwoord direct te wijzigen.',
		
		/**
		* System messages
		**/

		'systemmessages:dismiss' => "Klik om te verbergen",


		/**
		* Import / export
		*/
		'importsuccess' => "Importeren van data was succesvol",
		'importfail' => "OpenDD data importeren is mislukt.",

		/**
		* Time
		*/

		'friendlytime:justnow' => "zojuist",
		'friendlytime:minutes' => "%s minuten geleden",
		'friendlytime:minutes:singular' => "een minuut geleden",
		'friendlytime:hours' => "%s uren geleden",
		'friendlytime:hours:singular' => "een uur geleden",
		'friendlytime:days' => "%s dagen geleden",
		'friendlytime:days:singular' => "gisteren",

		'date:month:01' => '%s januari',
		'date:month:02' => '%s februari',
		'date:month:03' => '%s maart',
		'date:month:04' => '%s april',
		'date:month:05' => '%s mei',
		'date:month:06' => '%s juni',
		'date:month:07' => '%s juli',
		'date:month:08' => '%s augustus',
		'date:month:09' => '%s september',
		'date:month:10' => '%s oktober',
		'date:month:11' => '%s november',
		'date:month:12' => '%s december',
	
		/**
		* Installation and system settings
		*/

		'installation:error:htaccess' => "Elgg vereist een bestand genaamd .htaccess in de hoofdmap van de installatie. We hebben geprobeerd dit bestand aan te maken, maar Elgg heeft geen toegang om in de map te moge schrijven.

		Het aanmaken is erg eenvoudig. Kopie&euml;r de inhoud van het onderstaande textveld in een text editor en sla het op als .htaccess

		",
		'installation:error:settings' => "Elgg kon zijn instellingen bestand niet vinden. De meeste Elgg instellingen worden voor je gedaan, maar we moeten de database instellingen van jou krijgen. Om dit te doen: 

		1. Hernoem engine/settings.example.php naar settings.php in je Elgg installatie.

		2. Open het met een text editor en geef je MySQL instellingen op. Als je deze niet weet vraag dan je systeembeheerder of de helpdesk voor ondersteuning.

		Of je kunt de database instellingen hieronder ingeven en wij zullen het voor jou proberen aan te passen...",

		'installation:error:configuration' => "Als je de configuratie fouten hebt aangepast, klik op ververs en probeer het nogmaals.",

		'installation' => "Installatie",
		'installation:success' => "Elgg database is succesvol ge&iuml;nstalleerd.",
		'installation:configuration:success' => "Je initi&euml;le instellingen zijn opgeslagen. Registreer nu je eerste gebruiker, dit is tevens je eerste Site Administrator.",

		'installation:settings' => "Systeem instellingen",
		'installation:settings:description' => "Nu dat de Elgg database is ge&iuml;nstalleerd, moet je nog een aantal zaken invullen om je site volledig af te krijgen. We hebben geprobeerd een aantal zaken te gokken, maar <b>controlleer de instellingen goed.</b>",

		'installation:settings:dbwizard:prompt' => "Geeft je database instellingen op en klik op opslaan:",
		'installation:settings:dbwizard:label:user' => "Database gebruiker",
		'installation:settings:dbwizard:label:pass' => "Database wachtwoord",
		'installation:settings:dbwizard:label:dbname' => "Elgg database",
		'installation:settings:dbwizard:label:host' => "Database hostname (meestal 'localhost')",
		'installation:settings:dbwizard:label:prefix' => "Database tabel prefix (meestal 'elgg')",

		'installation:settings:dbwizard:savefail' => "We konden de nieuwe settings.php niet opslaan. Sla het volgende bestand op als engine/setting.php door gebruik te maken van een text editor.",

		'installation:sitename' => "De naam van je site (bijv \"Mijn sociale netwerk site\"):",
		'installation:sitedescription' => "Korte omschrijving van je site (optioneel)",
		'installation:wwwroot' => "De site URL, gevolgd door een slash:",
		'installation:path' => "Het volledige pad naar de hoofdmap van de site op de schijf, gevolgd door een slash:",
		'installation:dataroot' => "Het volledige pad naar de map waar de uploads worden opgeslagen, gevolgd door een slash:",
		'installation:dataroot:warning' => "Je moet deze map handmatig aanmaken. Het moet buiten de mappen structuur van de Elgg installatie.",
		'installation:sitepermissions' => "Het standaard toegangs niveau:",
		'installation:language' => "De standaard taal voor de site: ",
		'installation:debug' => "Debug mode geeft extra informatie die gebruikt kan worden om fouten te achterhalen. Echter vertraagd dit het systeem en moet alleen gebruikt worden als je problemen ondervindt:",
		'installation:debug:label' => "Debug mode inschakelen",
		'installation:httpslogin' => "Activeer dit om gebruikers via HTTPS aan te melden. Je moet HTTPS hebben geactiveerd op je server om dit te kunnen gebruiken.",
		'installation:httpslogin:label' => "HTTPS aanmelden inschakelen",
		'installation:usage' => "Deze optie staat Elgg toe om anonieme statistieken naar Curverider te sturen.",
		'installation:usage:label' => "Verstuur anonieme statistieken",
		'installation:view' => "Geeft de view op die standaard wordt gebruikt binnen de site of laat het leeg voor de standaard view (bij twijfel, laat de standaard staan):",

		'installation:siteemail' => "Site e-mail adres (wordt gebruikt voor het verzenden van systeem e-mails)",

		'installation:disableapi' => "De RESTful API is een flexibel en uitbreidbaar interface dat het applicaties mogelijk maakt bepaalde Elgg features op afstand te gebruiken.",
		'installation:disableapi:label' => "RESTful API inschakelen",

		'installation:allow_user_default_access:description' => "Indien aangevinkt hebben individuele gebruikers de mogelijkheid om hun eigen standaard toegangs niveau in te stellen. Dit kan anders zijn als de standaard instelling van de Site.",
		'installation:allow_user_default_access:label' => "Gebruikers standaard toegang toestaan",

		'installation:simplecache:description' => "De simple cache verhoogt de performance door statische content te cachen waaronder sommige CSS en Javascript bestanden. Normaall gezien wil je dit aan hebben staan.",
		'installation:simplecache:label' => "Gebruik simple cache",
	
		'upgrading' => 'Bijwerken',
		'upgrade:db' => 'Je database is bijgewerkt.',
		'upgrade:core' => 'Je Elgg installatie is bijgewerkt',

		/**
		* Welcome
		*/

		'welcome' => "Welkom",
		'welcome_message' => "Welkom op deze Elgg installatie.",

		/**
		* Emails
		*/
		'email:settings' => "E-mail instellingen",
		'email:address:label' => "Jouw e-mail adres",

		'email:save:success' => "Nieuwe e-mail sdres opgeslagen, verificatie gevraagd.",
		'email:save:fail' => "Je nieuwe e-mail adres kon niet worden opgeslagen.",

		'email:confirm:success' => "Je hebt je e-mail adres bevestigd!",
		'email:confirm:fail' => "Je e-mail adres kon niet worden geverifeerd...",

		'friend:newfriend:subject' => "%s heeft jou toegevoegd als vriend!",
		'friend:newfriend:body' => "%s heeft jou toegevoegd als vriend!

		Om zijn/haar profiel te bekijken, klik hier:

		%s

		Je kunt niet reageren op deze e-mail.",



		'email:resetpassword:subject' => "Wachtwoord reset!",
		'email:resetpassword:body' => "Beste %s,

		Je wachtwoord is gereset naar: %s",


		'email:resetreq:subject' => "Aanvraag voor nieuw wachtwoord.",
		'email:resetreq:body' => "Beste %s,

		Iemand (van IP adres %s) heeft een nieuw wachtwoord aangevraagd voor zijn/haar account.

		Als jij dit hebt aangevraagd klik dan op onderstaande link, anders negeer deze e-mail.

		%s
		",

		/**
		 * user default access
		 */
	
		'default_access:settings' => "Je standaard toegangs niveau",
		'default_access:label' => "Standaard toegang",
		'user:default_access:success' => "Je nieuwe standaard toegangs niveau is opgeslagen.",
		'user:default_access:failure' => "Je nieuwe standaard toegangs niveau is niet opgeslagen.",
	
		/**
		* XML-RPC
		*/
		'xmlrpc:noinputdata'	=>	"Input data ontbreekt",

		/**
		* Comments
		*/

		'comments:count' => "%s reacties",

		'riveraction:annotation:generic_comment' => '%s reageerde op %s',

		'generic_comments:add' => "Voeg een reactie toe",
		'generic_comments:text' => "Reactie",
		'generic_comment:posted' => "Je reactie is succesvol geplaatst.",
		'generic_comment:deleted' => "Je reactie is succesvol verwijderd.",
		'generic_comment:blank' => "Sorry, maar je moet wel wat invullen voordat we je reactie kunnen opslaan.",
		'generic_comment:notfound' => "Sorry, we konden het opgegeven item niet vinden.",
		'generic_comment:notdeleted' => "Sorry, we konden deze reactie niet verwijderen.",
		'generic_comment:failure' => "Er is een fout opgetreden tijdens het opslaab van je reactie. Probeer het nogmaals.",

		'generic_comment:email:subject' => 'Er is een nieuwe reactie!',
		'generic_comment:email:body' => "Er is een nieuwe reactie op je item \"%s\" door %s. De reactie is:


		%s


		Om te antwoorden of het originele item te zien, klik hier:

		%s

		Om %s's Profile te bekijken, klik hier:

		%s

		Je kunt niet antwoorden op deze e-mail.",

		/**
		* Entities
		*/
		'entity:default:strapline' => 'Aangemaakt op %s door %s',
		'entity:default:missingsupport:popup' => 'Deze entity kan niet correct worden weergegeven. Dit kan komen doordat er ondersteuning nmodig is van een Plugin die niet meer is ge&iuml;nstalleerd.',

		'entity:delete:success' => 'Entity %s is verwijderd',
		'entity:delete:fail' => 'Entity %s kon niet worden verwijderd',


		/**
		* Action gatekeeper
		*/
		'actiongatekeeper:missingfields' => 'Het formulier mist __token en/of __ts veld(en)',
		'actiongatekeeper:tokeninvalid' => "Er was een probleem (token mismatch). Dit betekend waarschijnlijk dat de gebruikte pagina verlopen was. Probeer het nogmaals.",
		'actiongatekeeper:timeerror' => 'De gebruikte pagina is verlopen. Ververs en probeer het nogmaals.',
		'actiongatekeeper:pluginprevents' => 'Een Extension heeft voorkomen dat het formulier wordt verzonden.',

		/**
		* Word blacklists
		*/
		'word:blacklist' => 'en, het, dan, maar, hij, zijn, haar, hem, een, niet, ook, ongeveer, nu, dus, wel, toch, is, anders, omgekeerd, maar dus, in plaats daarvan, intussen, derhalve, dit, lijkt, wat, wie',

		/**
		* Languages according to ISO 639-1
		*/
		"aa" => "Afar",
		"ab" => "Abkhazian",
		"af" => "Afrikaans",
		"am" => "Amharic",
		"ar" => "Arabic",
		"as" => "Assamese",
		"ay" => "Aymara",
		"az" => "Azerbaijani",
		"ba" => "Bashkir",
		"be" => "Byelorussian",
		"bg" => "Bulgarian",
		"bh" => "Bihari",
		"bi" => "Bislama",
		"bn" => "Bengali; Bangla",
		"bo" => "Tibetan",
		"br" => "Breton",
		"ca" => "Catalan",
		"co" => "Corsican",
		"cs" => "Czech",
		"cy" => "Welsh",
		"da" => "Danish",
		"de" => "German",
		"dz" => "Bhutani",
		"el" => "Greek",
		"en" => "English",
		"eo" => "Esperanto",
		"es" => "Spanish",
		"et" => "Estonian",
		"eu" => "Basque",
		"fa" => "Persian",
		"fi" => "Finnish",
		"fj" => "Fiji",
		"fo" => "Faeroese",
		"fr" => "French",
		"fy" => "Frisian",
		"ga" => "Irish",
		"gd" => "Scots / Gaelic",
		"gl" => "Galician",
		"gn" => "Guarani",
		"gu" => "Gujarati",
		"he" => "Hebrew",
		"ha" => "Hausa",
		"hi" => "Hindi",
		"hr" => "Croatian",
		"hu" => "Hungarian",
		"hy" => "Armenian",
		"ia" => "Interlingua",
		"id" => "Indonesian",
		"ie" => "Interlingue",
		"ik" => "Inupiak",
		//"in" => "Indonesian",
		"is" => "Icelandic",
		"it" => "Italian",
		"iu" => "Inuktitut",
		"iw" => "Hebrew (obsolete)",
		"ja" => "Japanese",
		"ji" => "Yiddish (obsolete)",
		"jw" => "Javanese",
		"ka" => "Georgian",
		"kk" => "Kazakh",
		"kl" => "Greenlandic",
		"km" => "Cambodian",
		"kn" => "Kannada",
		"ko" => "Korean",
		"ks" => "Kashmiri",
		"ku" => "Kurdish",
		"ky" => "Kirghiz",
		"la" => "Latin",
		"ln" => "Lingala",
		"lo" => "Laothian",
		"lt" => "Lithuanian",
		"lv" => "Latvian/Lettish",
		"mg" => "Malagasy",
		"mi" => "Maori",
		"mk" => "Macedonian",
		"ml" => "Malayalam",
		"mn" => "Mongolian",
		"mo" => "Moldavian",
		"mr" => "Marathi",
		"ms" => "Malay",
		"mt" => "Maltese",
		"my" => "Burmese",
		"na" => "Nauru",
		"ne" => "Nepali",
		"nl" => "Nederlands",
		"no" => "Norwegian",
		"oc" => "Occitan",
		"om" => "(Afan) Oromo",
		"or" => "Oriya",
		"pa" => "Punjabi",
		"pl" => "Polish",
		"ps" => "Pashto / Pushto",
		"pt" => "Portuguese",
		"qu" => "Quechua",
		"rm" => "Rhaeto-Romance",
		"rn" => "Kirundi",
		"ro" => "Romanian",
		"ru" => "Russian",
		"rw" => "Kinyarwanda",
		"sa" => "Sanskrit",
		"sd" => "Sindhi",
		"sg" => "Sangro",
		"sh" => "Serbo-Croatian",
		"si" => "Singhalese",
		"sk" => "Slovak",
		"sl" => "Slovenian",
		"sm" => "Samoan",
		"sn" => "Shona",
		"so" => "Somali",
		"sq" => "Albanian",
		"sr" => "Serbian",
		"ss" => "Siswati",
		"st" => "Sesotho",
		"su" => "Sundanese",
		"sv" => "Swedish",
		"sw" => "Swahili",
		"ta" => "Tamil",
		"te" => "Tegulu",
		"tg" => "Tajik",
		"th" => "Thai",
		"ti" => "Tigrinya",
		"tk" => "Turkmen",
		"tl" => "Tagalog",
		"tn" => "Setswana",
		"to" => "Tonga",
		"tr" => "Turkish",
		"ts" => "Tsonga",
		"tt" => "Tatar",
		"tw" => "Twi",
		"ug" => "Uigur",
		"uk" => "Ukrainian",
		"ur" => "Urdu",
		"uz" => "Uzbek",
		"vi" => "Vietnamese",
		"vo" => "Volapuk",
		"wo" => "Wolof",
		"xh" => "Xhosa",
		//"y" => "Yiddish",
		"yi" => "Yiddish",
		"yo" => "Yoruba",
		"za" => "Zuang",
		"zh" => "Chinese",
		"zu" => "Zulu",

	);
	
	add_translation("nl",$dutch);

?>
