<?php
	$dutch = array(
		'twitterservice' => 'Twitter Service',
		'twitterservice:postwire' => 'Wil je jou publieke Wire berichten direct op Twitter plaatsen?',
		'twitterservice:twittername' => 'Twitter gebruikersnaam',
		'twitterservice:twitterpass' => 'Twitter wachtwoord',
	);
					
	add_translation("nl", $dutch);
?>