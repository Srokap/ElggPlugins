<?php

	$dutch = array(

		'friends:all' => 'Alle vrienden',

		'notifications:subscriptions:personal:description' => 'Ontvang een melding als er acties worden ondernomen op jou content',
		'notifications:subscriptions:personal:title' => 'Persoonlijke melding',

		'notifications:subscriptions:collections:title' => 'Vrienden collecties',
		'notifications:subscriptions:collections:description' => 'Om meldingen van leden van je vrienden collecties aan te zetten, gebruik je onderstaande icoonen. Dit heeft effect op de weergegeven gebruiker in onderstaande venster.',
		'notifications:subscriptions:collections:edit' => 'Om je vrienden collecties aan te passen, klik hier.',

		'notifications:subscriptions:changesettings' => 'Meldingen',
		'notifications:subscriptions:changesettings:groups' => 'Groeps meldingen',
		'notification:method:email' => 'E-mail',	

		'notifications:subscriptions:title' => 'Meldingen per gebruiker',
		'notifications:subscriptions:description' => 'Om meldingen te ontvangen wanneer je vrienden nieuwe content plaatsen, vindt ze hieronder en selecteer de meldings manier die je wilt gebruiken.',

		'notifications:subscriptions:groups:description' => 'Om een melding te ontvangen wanneer er nieuwe content is in een groep waarvan je lid bent, zoek de groep hieronder op en selecteer de meldings manier die je wilt gebruiken.',

		'notifications:subscriptions:success' => 'Je meldings instellingen zijn opgeslagen.',

	);

	add_translation("nl", $dutch);
?>