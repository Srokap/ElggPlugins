<?php
	/**
	 * Email user validation plugin language pack.
	 * 
	 * @package ElggUserValidationByEmail
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	/**
	* Dutch translation.
	* 
	* @package dutch_translation
	* @author ColdTrick IT Solutions
	* @copyright Coldtrick IT Solutions 2009
	* @link http://www.coldtrick.com/
	*/

	$dutch = array(

		'email:validate:subject' => "%s bevestig aub je email adres!",
		'email:validate:body' => "Beste %s,

		Bevesting aub je email adres door op onderstaande link te klikken:

		%s",
		'email:validate:success:subject' => "Email adres bevestigd %s!",
		'email:validate:success:body' => "Beste %s,

		Gefeliciteerd, je hebt je email adres succesvol bevestigd.",

		'uservalidationbyemail:registerok' => "Om je account te activeren, bevestig je email adres door te klikken op de link die we je gestuurd hebben."

	);
	
	add_translation("nl", $dutch);
?>