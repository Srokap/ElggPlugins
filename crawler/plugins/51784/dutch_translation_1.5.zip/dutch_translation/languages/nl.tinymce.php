<?php

	$dutch = array(

		/**
		* Menu items and titles
		*/

		'tinymce:remove' => "Voeg toe/verwijder editor",

	);
	
	add_translation("nl", $dutch);

?>