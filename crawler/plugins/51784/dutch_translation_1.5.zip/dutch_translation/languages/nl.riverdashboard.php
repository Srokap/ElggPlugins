<?php

	$dutch = array(

		'mine' => 'Mijn',
		'filter' => 'Filter',
		'riverdashboard:useasdashboard' => "Vervang het standaard Dashboard door deze Acivity River?",
		'activity' => 'Activiteit',

		/**
		* Site messages
		**/

		'sitemessages:announcements' => "Site mededelingen",
		'sitemessages:posted' => "Geplaatst",
		'sitemessages:river:created' => "Site admin, %s,",
		'sitemessages:river:create' => "plaatste een nieuwe mededeling",
		'sitemessages:add' => "Voeg een mededeling toe aan de River pagina",
		'sitemessage:deleted' => "Mededeling verwijderd",

		'river:widget:noactivity' => 'We konden geen activiteit vinden.',
		'river:widget:title' => "Activiteit",
		'river:widget:description' => "Laat je laatste activiteit zien.",
		'river:widget:title:friends' => "Activiteit van je vrienden",
		'river:widget:description:friends' => "Laat zien wat je vrienden doen.",
		'river:widgets:friends' => "Vrienden",
		'river:widgets:mine' => "Mijn",
		'river:widget:label:displaynum' => "Aantal items om weer te geven:",
		'river:widget:type' => "Welke River wil je weergeven? Een die jouw activiteit weergeeft of die van je vrienden?",
		'item:object:sitemessage' => "Site mededelingen",
	);

	add_translation("nl", $dutch);

?>