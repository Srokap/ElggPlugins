<?php

	$dutch = array(
	
		'categories' => 'Categori&euml;n',
		'categories:settings' => 'Stel Site categori&euml;n in',	
		'categories:explanation' => 'Om een aantal voorgedefineerde categori&euml;n in te stellen, die door over hele site kunnen worden gebruik, geeft ze hieronder in. Door een komma geschijden. Geschikte plugins zullen ze dan weer geven als een gebruiker content bewerkt of aanmaakt.',	
		'categories:save:success' => 'Site categori&euml;n zijn succesvol opgeslagen.',
	
	);
	
	add_translation("nl", $dutch);

?>