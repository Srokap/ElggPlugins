<?php
	/**
	 * Elgg groups plugin language pack
	 * 
	 * @package ElggGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	/**
	* Dutch translation.
	* 
	* @package dutch_translation
	* @author ColdTrick IT Solutions
	* @copyright Coldtrick IT Solutions 2009
	* @link http://www.coldtrick.com/
	*/

	$dutch = array(
	
		/**
		* Menu items and titles
		*/

		'groups' => "Groepen",
		'groups:owned' => "Groepen beheren",
		'groups:yours' => "Jouw groepen",
		'groups:user' => "%s's groepen",
		'groups:all' => "Alle site groepen",
		'groups:new' => "Maak een nieuwe groep",
		'groups:edit' => "Bewerk groep",
		'groups:delete' => 'Verwijder groep',
		'groups:membershiprequests' => 'Beheer lidmaatschap aanvragen',
	
		'groups:icon' => 'Groep icoon (laat leeg voor huidige)',
		'groups:name' => 'Groep naam',
		'groups:username' => 'Korte groepnaam (voor URLs, alleen alfanumerieke tekens)',
		'groups:description' => 'Omschrijving',
		'groups:briefdescription' => 'Korte omschrijving',
		'groups:interests' => 'Interesses',
		'groups:website' => 'Website',
		'groups:members' => 'Groepsleden',
		'groups:membership' => "Lidmaatschap",
		'groups:access' => "Toegangs rechten",
		'groups:owner' => "Eigenaar",
		'groups:widget:num_display' => 'Aantal groepen om weer te geven',
		'groups:widget:membership' => 'Groeps lidmaatschap',
		'groups:widgets:description' => 'Laat je groepslidmaatschap zien op je profiel',
		'groups:noaccess' => 'Geen toegang tot de groep',
		'groups:cantedit' => 'Je kunt deze groep niet bewerken',
		'groups:saved' => 'Groep opgeslagen',
		'groups:featured' => 'Aangeraden groepen',
		'groups:makeunfeatured' => 'Afraden',
		'groups:makefeatured' => 'Aanraden',
		'groups:featuredon' => 'Je hebt deze groep aangeraden.',
		'groups:unfeature' => 'Je hebt deze groep verwijderd van de aangeraden lijst',
		'groups:joinrequest' => 'Verzoek lidmaatschap',
		'groups:join' => 'Wordt lid',
		'groups:leave' => 'Verlaat groep',
		'groups:invite' => 'Nodig vrienden uit',
		'groups:inviteto' => "Nodig vrienden uit voor '%s'",
		'groups:nofriends' => "Je hebt geen vrienden meer die niet al lid zijn van deze groep.",
		'groups:viagroups' => "via groepen",
		'groups:group' => "Groep",

		'groups:notfound' => "Groep niet gevonden",
		'groups:notfound:details' => "De gevraagde groep bestaat niet of je hebt hiertoe geen toegang",
		
		'groups:requests:none' => 'Er zijn geen openstaande lidmaatschaps aanvragen op dit moment.',
		
		'item:object:groupforumtopic' => "Forum onderwerpen",
		'groupforumtopic:new' => "Nieuw forum bericht",
		
		'groups:count' => "groepen aangemaakt",
		'groups:open' => "open groep",
		'groups:closed' => "gesloten groep",
		'groups:member' => "leden",
		'groups:searchtag' => "Zoek naar groepen op tag",
	
		/*
		* Access
		*/
		'groups:access:private' => 'Gesloten - Gebruikers moeten worden uitgenodigd',
		'groups:access:public' => 'Open - Iedere gebruiker kan lid worden',
		'groups:closedgroup' => 'Deze groep is besloten. Om lid te worden klik op de "Verzoek lidmaatschap" link in het menu.',

		/*
		Group tools
		*/
		'groups:enablepages' => "Activeer groep pagina's",
		'groups:enableforum' => 'Activeer groep forum',
		'groups:enablefiles' => 'Activeer groep bestanden',
		'groups:yes' => 'ja',
		'groups:no' => 'nee',

		'group:created' => '%s aangemaakt met %d berichten',
		'groups:lastupdated' => 'Laatst bijgewerkte %s door %s',
		'groups:pages' => "Groeps pagina's",
		'groups:files' => 'Groeps bestanden',

		/*
		Group forum strings
		*/

		'group:replies' => 'Reacties',
		'groups:forum' => 'Groep forum',
		'groups:addtopic' => 'Nieuw onderwerp',
		'groups:forumlatest' => 'Forum laatste',
		'groups:latestdiscussion' => 'Laatste discussie',
		'groups:newest' => 'Nieuwste',
		'groups:popular' => 'Populair',
		'groupspost:success' => 'Je reactie is succesvol geplaatst',
		'groups:alldiscussion' => 'Laatste discussie',
		'groups:edittopic' => 'Bewerk onderwerp',
		'groups:topicmessage' => 'Onderwerp bericht',
		'groups:topicstatus' => 'Onderwerp status',
		'groups:reply' => 'Plaats een reactie',
		'groups:topic' => 'Onderwerp',
		'groups:posts' => 'reacties',
		'groups:lastperson' => 'Laaste persoon',
		'groups:when' => 'Wanneer',
		'grouptopic:notcreated' => 'No geen onderwerpen aangemaakt.',
		'groups:topicopen' => 'Open',
		'groups:topicclosed' => 'Gesloten',
		'groups:topicresolved' => 'Opgelost',
		'grouptopic:created' => 'Je onderwerp is aangemaakt.',
		'groupstopic:deleted' => 'Het onderwerp is verwijderd.',
		'groups:topicsticky' => 'Sticky',
		'groups:topicisclosed' => 'Dit onderwerp is gesloten.',
		'groups:topiccloseddesc' => 'Dit onderwerp is nu gesloten, er kunnen geen reacties meer geplaatst worden.',
		'grouptopic:error' => 'Je groep onderwerp kon niet worden aangemaakt. Probeer het nogmaals of neem contact op met de Site Administrator.',
		'groups:forumpost:edited' => "Je hebt het forum bericht succesvol bewerkt.",
		'groups:forumpost:error' => "Er was een probleem tijdens het bewerken van het forum bericht.",
			
		'groups:privategroup' => 'Deze groep is besloten, lidmaatschap wordt aangevraagd.',
		'groups:notitle' => 'Groepen moeten een titel hebben',
		'groups:cantjoin' => 'Kan niet lid worden van de groep',
		'groups:cantleave' => 'Kon de groep niet verlaten',
		'groups:addedtogroup' => 'Gebruiker succesvol toegevoegd aan de groep',
		'groups:joinrequestnotmade' => 'Lidmaatschap verzoek kon niet worden gemaakt',
		'groups:joinrequestmade' => 'Lidmaatschap verzoek succesvol aangemaakt',
		'groups:joined' => 'Succesvol lid geworden van de groep!',
		'groups:left' => 'De groep succesvol verlaten',
		'groups:notowner' => 'Sorry, je bent niet de eigenaar van de groep.',
		'groups:alreadymember' => 'Je bent reeds lid van deze groep!',
		'groups:userinvited' => 'Gebruiker is uitgenodigd.',
		'groups:usernotinvited' => 'Gebruiker kon niet worden uitgenodigd.',
		'groups:useralreadyinvited' => 'Gebruiker is al uitgenodigd',
		'groups:updated' => "Laatste reactie",
		
		'groups:started' => "Opgestart door",
		'groups:joinrequest:remove:check' => 'Weet je zeker dat je dit lidmaatschaps verzoek wilt verwijderen?',
		
		'groups:invite:subject' => "%s je bent uitgenodigd om lid te worden van %s!",
		'groups:invite:body' => "Beste %s,

		Je bent uitgenodigd om lid te worden van de '%s' groep, om te accepteren klik hier:

		%s",

		'groups:welcome:subject' => "Welkom bij de %s groep!",
		'groups:welcome:body' => "Beste %s!

		Je bent nu lid van de '%s' groep! Klik hieronder om te beginnen met posten!

		%s",

		'groups:request:subject' => "%s wil lid worden van %s",
		'groups:request:body' => "Beste %s,

		%s wil lid worden van de '%s' groep, klik hieronder om zijn/haar profiel te bekijken:

		%s

		of klik hieronder om het verzoek te accepteren:

		%s",

		/*
		Forum river items
		*/

		'groups:river:member' => 'is nu lid van',
		'groupforum:river:updated' => '%s berwerkte',
		'groupforum:river:update' => 'dit forum bericht',
		'groupforum:river:created' => '%s cree&euml;rde',
		'groupforum:river:create' => 'een nieuw forum bericht getiteld',
		'groupforum:river:posted' => '%s plaatste een reactie',
		'groupforum:river:annotate:create' => 'op dit forum bericht',
		'groupforum:river:postedtopic' => '%s cree&euml;rde een nieuw forum bericht getiteld',
		
		/*
		Widget
		*/
		'groups:nowidgets' => 'Er zijn geen widgets gedefineerd voor deze groep.',
		'groups:widgets:members:title' => 'Groepsleden',
		'groups:widgets:members:description' => 'Lijst van groepsleden.',
		'groups:widgets:members:label:displaynum' => 'Toon de groepsleden.',
		'groups:widgets:members:label:pleaseedit' => 'Stel deze widget AUB in.',

		'groups:widgets:entities:title' => "Objecten in de groep",
		'groups:widgets:entities:description' => "Toon de objecten van deze groep",
		'groups:widgets:entities:label:displaynum' => 'Toon de objecten van een groep.',
		'groups:widgets:entities:label:pleaseedit' => 'Stel deze widget AUB in.',

		'groups:forumtopic:edited' => 'Forum onderwerp succesvol bewerkt.',
		
		/**
		* Action messages
		*/
		'group:deleted' => 'Groep en groeps berichten verwijderd',
		'group:notdeleted' => 'Groep kon niet worden verwijderd',

		'grouppost:deleted' => 'Groep bericht succesvol verwijderd',
		'grouppost:notdeleted' => 'Groep bericht kon niet worden verijderd',
		'groupstopic:deleted' => 'Onderwerp verwijderd',
		'groupstopic:notdeleted' => 'Onderwerp niet verijderd',
		'grouptopic:blank' => 'Geen onderwerp',
		'groups:deletewarning' => "Weet je zeker dat je deze groep wilt verwijderen? Dit kan niet ongedaan worden gemaakt!",

		'groups:joinrequestkilled' => 'Lidmaatschap verzoek verwijderd.',
	);
	
	add_translation("nl", $dutch);
?>