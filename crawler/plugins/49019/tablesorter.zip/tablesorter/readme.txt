/**
 * Elgg jQuery Table Sorter plugin
 * 
 * @author  Lenny Urbanowski
 * @link	http://www.itslennysfault.com
 * @package ElggTableSorter
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 *
 * Created for Pixel Brothers Interactive (http://www.pixbros.com)
 */
 
This plugin creates a sortable table ouput view in elgg

It uses the table sorter jQuery plugin by Christian Bach
http://tablesorter.com/


Install:
	copy to mod directory
	activate in elgg


Usage:

	simply create an associative array with table elements and pass it to elgg_view
	as the value. tableid is set as the id field of the table element
	(must be unique on the current page)


Example:

	this example will create a 2 column table with 3 rows the column heads will be
	Name and Website and will be sortable.

	$tableArray[0]["Name"]="Lenny";
	$tableArray[0]["Website"]="itslennysfault.com";	
	$tableArray[1]["Name"]="Pixel Brothers";
	$tableArray[1]["Website"]="pixbros.com";	
	$tableArray[2]["Name"]="Elgg";
	$tableArray[2]["Website"]="elgg.org";
	
	echo elgg_view('output/tablesorter', array('value' => $tableArray,'tableid' => 'MyTableID'));
	

Changes:
	version		description
	
	.1			Initial Creation
	
	.2			Bug fixes code smoothing.. Released to elgg community
	
	.5			Change in the way the array is handled to allow for empty cells
				previous version needed every cell to have content or it would break
				the table code.
				
				tested and abused a bit to try to find bugs.. seems clean, but holding off
				on a Version 1.0 release still