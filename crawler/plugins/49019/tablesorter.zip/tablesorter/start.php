<?php
	/**
	 * Elgg jQuery Table Sorter plugin
	 * 
	 * @author  Lenny Urbanowski
	 * @link	http://www.itslennysfault.com
	 * @package ElggTableSorter
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 *
	 * Created for Pixel Brothers Interactive (http://www.pixbros.com)
	 */
	 
		function tablesorter_init() {
			global $CONFIG;
			
			//add table sorter css
			extend_view('css','tablesorter/css');
		}
		register_elgg_event_handler('init','system','tablesorter_init');
?>