<?php
	/**
	 * Elgg jQuery Table Sorter plugin
	 * 
	 * @author  Lenny Urbanowski
	 * @link	http://www.itslennysfault.com
	 * @package ElggTableSorter
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 *
	 * Created for Pixel Brothers Interactive (http://www.pixbros.com)
	 */

	//load external JS if not already loaded
	global $tablesorter_js_loaded;
	if (!isset($tablesorter_js_loaded)) $tablesorter_js_loaded = false;
	if (!$tablesorter_js_loaded) {
		?><script type="text/javascript" src="<?php print $CONFIG->wwwroot; ?>mod/tablesorter/js/jquery.tablesorter.min.js"></script><?php	
	}
	
	//JS to activate this sortable table
	$tblCodeJS='<script type="text/javascript">$(document).ready(function(){ $("#'.$vars['tableid'].'").tablesorter(); } ); </script>';
	$tblColumnHeads = array();
	$tblCodeBody="<tbody>";
	
	//pre build table head array allows us to populate empty cells
	foreach($vars['value'] as $tblRows){
		foreach($tblRows as $tblHead => $tblCells){
			$tblColumnHeads[$tblHead]= $tblHead;
		}
	}
	
	//build table body code
	foreach($vars['value'] as $tblRows){
		$tblCodeBody.="<tr>";
		foreach($tblColumnHeads as $tblHead){
			if($tblRows[$tblHead]) //make empty cells if needed
				$tblCodeBody.="<td>".$tblRows[$tblHead]."</td>";
			else
				$tblCodeBody.="<td>&nbsp;</td>";			
		}
		$tblCodeBody.="</tr>";
	}
	$tblCodeBody.="</tbody>";	
	
	//create table head code
	$tblCodeHead='<table id="'.$vars['tableid'].'" class="tablesorter"><thead><tr>';
	foreach($tblColumnHeads as $tblHead){
		$tblCodeHead.="<th>".$tblHead."</th>";
	}
	$tblCodeHead.='</tr></thead>';
	
	//table footer
	$tblCodeFoot="</table>";
	
	//output all the code
	echo $tblCodeHead . $tblCodeBody . $tblCodeFoot . $tblCodeJS;
?>