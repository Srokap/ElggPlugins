<?php


	if (isset($vars['entity'])) {
        $object=$vars['entity'];

?>
<div class="onlinescreenshot-singlepage">
	<div class="onlinescreenshot-room">

	    <!-- the actual shout -->
		<div class="room_body">

	    <div class="onlinescreenshot_picture">
	    <?php
		        echo elgg_view("profile/icon",array('entity' => $vars['entity']->getOwnerEntity(), 'size' => 'small'));
	    ?>
	    </div>
	    <div class="clearfloat"></div>
	    </div>

		<?php

		?>


		<div class="clearfloat"></div>
		</div>



	</div>
</div>
<?php

		}

?>
