<?php
 
    /**
	 * Elgg onlinescreenshot CSS
	 * 
	 * @package Elggonlinescreenshot
	 */
     
?>

.onlinescreenshot-singlepage {
	margin:0 10px 0 10px; 	
	-webkit-border-radius: 8px;	
	-moz-border-radius: 8px; 
	margin-bottom:5px;
}

.onlinescreenshot-singlepage .room_body {
	background: white;	
	-webkit-border-radius: 8px;	
	-moz-border-radius: 8px;
}

.onlinescreenshot_picture {
	float:left;    
	margin:0 8px 4px 2px;
}
