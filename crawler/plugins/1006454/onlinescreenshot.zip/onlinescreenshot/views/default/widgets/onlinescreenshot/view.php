<?php

/**
 * Elgg onlinescreenshot view page
 *
 * @package Elggonlinescreenshot
 */
 
  global $CONFIG;
  // get_data from datalist to get last modified picture
  $vchat_snapshotsTime = datalist_get('vchat_snapshotsTime');
  $lstr_snapshotsTime = datalist_get('lstr_snapshotsTime');
  
  $sqlliveusercount = "SELECT ".$CONFIG->dbprefix."objects_entity.description, ".
			 $CONFIG->dbprefix."objects_entity.guid, ".
			 $CONFIG->dbprefix."objects_entity.title ".
			 "FROM ( ".$CONFIG->dbprefix."entities ".$CONFIG->dbprefix."entities ".
       "INNER JOIN ".
       $CONFIG->dbprefix."entity_subtypes ".$CONFIG->dbprefix."entity_subtypes ".
       "ON (".$CONFIG->dbprefix."entities.subtype = ".$CONFIG->dbprefix."entity_subtypes.id)) ".
       "INNER JOIN ".
       $CONFIG->dbprefix."objects_entity ".$CONFIG->dbprefix."objects_entity ".
       "ON (".$CONFIG->dbprefix."objects_entity.guid = ".$CONFIG->dbprefix."entities.guid) ".
			 "WHERE ".$CONFIG->dbprefix."entity_subtypes.subtype = 'videowhisper' AND ".
			 "LEFT(".$CONFIG->dbprefix."objects_entity.description,3) IN
               ('2:1', '4:1', '5:1') ORDER BY guid DESC;";

	$ztime = time();
	$exptime=$ztime-30;
  $exptime_vchat=$exptime-($vchat_snapshotsTime/1000);
  $exptime_lstr=$exptime-($lstr_snapshotsTime/1000);
  $arr1 = array ();
  $isNoScreenShot = true;
  $name = "";	  //nama time untuk vchat screenshot terbaru
	if ($rows = get_data($sqlliveusercount)) {
		foreach($rows as $row) {
			$descriptionx = $row->description; 
			$guid = $row->guid;
			$title = $row->title;

			$nilai = explode(":", $descriptionx);
			$newdescription = "";
			if ($nilai[3] < $exptime) {	// if last access time < exptime
				for ($i = 0; $i <= 2; $i++) {
					if ($i == 1) 
						$newdescription .= "0:"; // set status as 0 ( logout )
					else
						$newdescription .= $nilai[$i].":";
				}
				$newdescription .= $nilai[3];
				$result = update_data("UPDATE {$CONFIG->dbprefix}objects_entity 
				set description='$newdescription' 
				where guid=$guid ;");
			} elseif ($nilai[0]==2) {
					$folder = $CONFIG->pluginspath ."videochat/uploads/".$title;
      		$handle = opendir($folder); 
		      $nama = "";
		      while(false !== ($file = readdir($handle))){
		      $file2 = str_replace ("$nilai[2]",".",$file);
		      $file3 = str_replace ("jpg","",$file2);
		      $fileAndExt = explode('.', $file3);
          if ($fileAndExt[2] > $nama) $nama = $fileAndExt[2];
          }
          if (($nama > $exptime_vchat )) { // waktu pembuatan gambar yang ada > waktu minimal snapshot
            $filegambar = $CONFIG->pluginspath ."videochat/uploads/".$title."/".$nilai[2].".".$nama.".jpg";
            if (file_exists($filegambar)) {
             $isNoScreenShot = false;
             array_push ($arr1, "2:".$nilai[2].":".$title.":".$nama); // roomtype:liveuser:roomname:waktugambar
          }}
			} elseif ($nilai[0]==4) {
        $alamat = $CONFIG->pluginspath ."livestreaming/snapshots/".$title.".jpg";
        $lastmodif = date(filemtime($alamat));
        //echo $lastmodif;
        if ($lastmodif > $exptime_lstr) { // waktu pembuatan gambar yang ada > waktu minimal snapshot
          $isNoScreenShot = false;
            array_push ($arr1, "4:".$nilai[2].":".$title); // roomtype:liveuser:roomname
        }
      }
		}
	}


// view arr1
if ($arr1) {
  	foreach($arr1 as $arr) {
      $nilai = explode(":", $arr);

?>
<div class="onlinescreenshot-singlepage" >
	    <!-- the actual shout -->
		<div class="room_body" >

	    <div class="onlinescreenshot_picture" >
<?php  
    
    if ($nilai[0]==2)
      echo "<img src=".$CONFIG->wwwroot."mod/videochat/uploads/".$nilai[2]."/".$nilai[1].".".$nilai[3].".jpg height=40px>";
      else echo "<img src=".$CONFIG->wwwroot."mod/livestreaming/snapshots/".$nilai[2].".jpg height=40px>";

?>
	    </div>
		<?php

		if ($nilai[0]==2) 
			echo $nilai[1]." active in :<a href=".$CONFIG->wwwroot.'videochat/'.$nilai[2].">".$nilai[2]."</a> video chat room.";
		  else {

// get username
$ver=explode('.', get_version(true));	
if ($ver[1]>7) $ElggUser=elgg_get_logged_in_user_entity();
else $ElggUser=get_loggedin_user();
$username=$ElggUser->get("username");

// get livestreaming room owner_username
$sql2 = "SELECT ".$CONFIG->dbprefix."users_entity.username ".
			 "FROM    ( (  ".$CONFIG->dbprefix."entities ".$CONFIG->dbprefix."entities ".
			 "INNER JOIN ".
              $CONFIG->dbprefix."entity_subtypes ".$CONFIG->dbprefix."entity_subtypes ".
			 "ON (".$CONFIG->dbprefix."entities.subtype = ".$CONFIG->dbprefix."entity_subtypes.id)) ".
			 "INNER JOIN ".
          $CONFIG->dbprefix."objects_entity ".$CONFIG->dbprefix."objects_entity ".
			 "ON (".$CONFIG->dbprefix."objects_entity.guid = ".$CONFIG->dbprefix."entities.guid)) ".
			 "INNER JOIN ".
              $CONFIG->dbprefix."users_entity ".$CONFIG->dbprefix."users_entity ".
			 "ON (".$CONFIG->dbprefix."entities.owner_guid = ".$CONFIG->dbprefix."users_entity.guid) ".
			 "WHERE ((".$CONFIG->dbprefix."objects_entity.title = '".$title."') AND (".$CONFIG->dbprefix."entity_subtypes.subtype = 'livestreaming'))
 LIMIT 1;";
      $hasil = mysql_query ($sql2);
      $hasil2 = mysql_fetch_array ($hasil);
      if ($hasil2[0] == $username) 
        echo $nilai[1]." active in :<a href=".$CONFIG->wwwroot.'livestreaming/'.$nilai[2]."?live=1>".$nilai[2]."</a> live streaming room.<br />"; 
      else echo $nilai[1]." active in :<a href=".$CONFIG->wwwroot.'livestreaming/'.$nilai[2]."?live=2>".$nilai[2]."</a> live streaming room.<br />";
    }
		?>
		</div>
</div>
<?php
}}
if ($isNoScreenShot) echo "&nbsp; No screenshot user active.";
?>
