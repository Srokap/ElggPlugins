<?php

    /**
	 * Elgg onlinescreenshot edit page
	 *
	 * @package Elggonlinescreenshot
	 */

?>
