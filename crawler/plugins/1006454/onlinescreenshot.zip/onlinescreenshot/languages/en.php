<?php
/**
 * onlinescreenshot widget language file
 */

$english = array(

	'onlinescreenshot:title' => 'Online Screenshot Users',
	'onlinescreenshot:info' => 'Display online screenshot users on video chat and live streaming rooms',

);
					
add_translation("en", $english);
