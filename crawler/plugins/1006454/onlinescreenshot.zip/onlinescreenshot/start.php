<?php
/**
 * Elgg onlinescreenshot widget
 * This plugin show screenshots of online users with webcams on
 * 
 * @package Elggonlinescreenshot
 */

function onlinescreenshot_init() {
	elgg_extend_view('css', 'onlinescreenshot/css');
	add_widget_type('onlinescreenshot', elgg_echo('onlinescreenshot:title'), elgg_echo('onlinescreenshot:info'));
}

register_elgg_event_handler('init', 'system', 'onlinescreenshot_init');
