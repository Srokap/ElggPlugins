<?php
		function technerd_init() 
		{
		global $CONFIG;
		add_menu(elgg_echo('technerd'), $CONFIG->wwwroot . "mod/technerd");
		}
		
	register_elgg_event_handler('init','system','technerd_init');
	// Shares widget

?>