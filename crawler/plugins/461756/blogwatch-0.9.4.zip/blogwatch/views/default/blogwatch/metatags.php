<?
/**
 * start
 * 
 * @package Blogwatch
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Alistair Young <alistair@codebrane.com>
 * @copyright codeBrane 2009
 * @link http://codebrane.com/blog/
 */

/*
don't need this as Elgg already provides jquery	
<script type="text/javascript" src="<? echo $vars['url']; ?>mod/blogwatch/lib/js/jquery-latest.pack.js"></script>
*/
?>
<script type="text/javascript" src="<? echo $vars['url']; ?>mod/blogwatch/lib/js/thickbox.js"></script>
<style type="text/css" media="all">
@import "<? echo $vars['url']; ?>mod/blogwatch/lib/js/thickbox-elgg.css";
</style>
