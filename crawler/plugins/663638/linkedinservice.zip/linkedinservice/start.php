<?php
/**
 * Linkedin Service plugin
 *
 * Author: M.R.A.Welkers
 * E-mail: m_welkers@hotmail.com
 * Website: http://www.fautloos.nl
 * 
 * This plugin allows authentication of your Elgg site with Linkedin.
 */


function linkedinservice_init() {
	global $CONFIG;

	// require libraries
	require_once "{$CONFIG->pluginspath}linkedinservice/linkedinservice_lib.php";

	if (!class_exists('LinkedinOAuth')) {
		require_once "{$CONFIG->pluginspath}linkedinservice/vendors/oauth/linkedinOAuth.php";
	}

	// extend site views
	elgg_extend_view('css', 'linkedinservice/css');
	// register page handler
	register_page_handler('linkedinservice', 'linkedinservice_pagehandler');

}

function linkedinservice_pagehandler($page) {
	if (!isset($page[0])) {
		forward();
	}
	switch ($page[0]) {
		case 'authorize':
			linkedinservice_authorize();
			break;
		case 'revoke':
			linkedinservice_revoke();
			break;
		case 'sync':
			linkedinservice_sync();
			break;
		default:
			forward();
			break;
	}
}

register_elgg_event_handler('init','system','linkedinservice_init');
?>