<?php
/**
 *
 */

$access_key = get_plugin_usersetting('access_key', get_loggedin_userid(), 'linkedinservice');
$access_secret = get_plugin_usersetting('access_secret', get_loggedin_userid(), 'linkedinservice');

echo '<p>' . elgg_echo('linkedinservice:usersettings:description') . '</p>';

if (!$access_key || !$access_secret) {
	// send user off to validate account
	$request_link = linkedinservice_get_authorize_url($vars['url'] . 'pg/linkedinservice/authorize');
	echo '<p>' . sprintf(elgg_echo('linkedinservice:usersettings:request'), $request_link) . '</p>';
} else {
	$url = "{$CONFIG->site->url}pg/linkedinservice/revoke";
	echo '<p class="linkedin_anywhere">' . sprintf(elgg_echo('linkedinservice:usersettings:authorized'), $linkedin_name, $vars['config']->site->name) . '</p>';
	echo '<p>' . sprintf(elgg_echo('linkedinservice:usersettings:revoke'), $url) . '</p>';

}