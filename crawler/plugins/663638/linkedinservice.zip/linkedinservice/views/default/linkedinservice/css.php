<?php
/**
 * Elgg linkedinService CSS
 */
?>

#linkedinservice_site_settings .text_input {
	width: 350px;
}

.linkedinservice_usersettings_desc {
	font-size: smaller;
}