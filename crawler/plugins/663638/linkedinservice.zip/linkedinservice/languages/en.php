<?php
/**
 * An english language definition file
 */

$english = array(
	'linkedinservice' => 'LinkedIn Services',

	'linkedinservice:consumer_key' => 'Api key',
	'linkedinservice:consumer_secret' => 'Secret key',

	'linkedinservice:usersettings:description' => "Link your {$CONFIG->site->name} account with Linkedin.",
	'linkedinservice:usersettings:request' => "You must first <a href=\"%s\">authorize</a> {$CONFIG->site->name} to access your Linkedin account.",
	'linkedinservice:authorize:error' => 'Unable to authorize linkedin.',
	'linkedinservice:authorize:success' => 'Linkedin access has been authorized.',
	'linkedinservice:usersettings:authorized' => "You have authorized {$CONFIG->site->name} to access your Linkedin account. If details aren't showing up, you might need to reauthorize. Click revoke below, then go to <a href=\"https://www.linkedin.com/secure/settings?userAgree=\">Linkedin Connection Settings</a> and revoke access.  Then come back to this page and authorize again.",
	'linkedinservice:usersettings:revoke' => 'Click <a href="%s">here</a> to revoke access.',
	'linkedinservice:revoke:success' => 'Linkedin access has been revoked.',
	'plugin:settings:linkedinservice:access_key'	=> 'Personal linkedin access key',
	'plugin:settings:linkedinservice:access_secret'	=> 'Personal linkedin access secret',
	'linkedinservice:usersettings:allowed_plugins' => 'Allowed Plugins',
);

add_translation('en', $english);
