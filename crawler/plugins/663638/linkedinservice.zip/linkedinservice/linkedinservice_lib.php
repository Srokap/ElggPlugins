<?php
/**
 * Common library of functions used by linkedinservice
 *
 * @package linkedinservice
 */


function linkedinservice_authorize() {
	$token = linkedinservice_get_access_token(get_input('oauth_verifier', NULL));
	if (!isset($token['oauth_token']) || !isset($token['oauth_token_secret'])) {
		register_error(elgg_echo('linkedinservice:authorize:error'));
		forward('pg/settings/plugins');
	}

	// only one user per tokens
	$values = array(
		'plugin:settings:linkedinservice:access_key' => $token['oauth_token'],
		'plugin:settings:linkedinservice:access_secret' => $token['oauth_token_secret'],
	);

	if ($users = get_entities_from_private_setting_multi($values, 'user', '', 0, '', 0)) {
		foreach ($users as $user) {
			// revoke access
			set_plugin_usersetting('access_key', NULL, $user->getGUID());
			set_plugin_usersetting('access_secret', NULL, $user->getGUID());
		}
	}

	// register user's access tokens
	set_plugin_usersetting('access_key', $token['oauth_token']);
	set_plugin_usersetting('access_secret', $token['oauth_token_secret']);

	system_message(elgg_echo('linkedinservice:authorize:success'));
	forward('pg/settings/plugins');
}

function linkedinservice_revoke() {
	// unregister user's access tokens
	set_plugin_usersetting('access_key', NULL);
	set_plugin_usersetting('access_secret', NULL);

	system_message(elgg_echo('linkedinservice:revoke:success'));
	forward('pg/settings/plugins');
}

function linkedinservice_get_authorize_url($callback=NULL) {
	global $SESSION;

	$consumer_key = get_plugin_setting('consumer_key', 'linkedinservice');
	$consumer_secret = get_plugin_setting('consumer_secret', 'linkedinservice');

	// request tokens from linkedin
	$linkedin = new LinkedinOAuth($consumer_key, $consumer_secret);
	$token = $linkedin->getRequestToken($callback);
	// save token in session for use after authorization
	$SESSION['linkedinservice'] = array(
		'oauth_token' => $token['oauth_token'],
		'oauth_token_secret' => $token['oauth_token_secret'],
	);
	return $linkedin->getAuthorizeURL($token['oauth_token']);
}

function linkedinservice_get_access_token($oauth_verifier=NULL) {
	global $SESSION;

	$consumer_key = get_plugin_setting('consumer_key', 'linkedinservice');
	$consumer_secret = get_plugin_setting('consumer_secret', 'linkedinservice');

	// retrieve stored tokens
	$oauth_token = $SESSION['linkedinservice']['oauth_token'];
	$oauth_token_secret = $SESSION['linkedinservice']['oauth_token_secret'];
	$SESSION->offsetUnset('linkedinservice');

	// fetch an access token
	$api = new LinkedinOAuth($consumer_key, $consumer_secret, $oauth_token, $oauth_token_secret);
	return $api->getAccessToken($oauth_verifier);
}

?>