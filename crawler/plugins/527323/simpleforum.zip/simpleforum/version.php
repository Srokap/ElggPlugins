<?php
	/**
	* simpleforum
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	// YYYYMMDD = river_comments date
	// XX = Interim incrementer
	$version = 2010071201;
	
	// Human-friendly version name
	$release = '0.1.1';