<?php
	/**
	* simpleforum
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	// Load Elgg engine
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
		
	gatekeeper();
		
	get_input('group');
	$page_owner = set_page_owner((int)get_input('group'));
	
	// check the user is a member of the group
	//if (!$page_owner->isMember($_SESSION['user'])) forward();
	
	if (!(page_owner_entity() instanceof ElggGroup)) forward();
	
	//get the topic
	$topic = get_entity((int) get_input('topic'));
		
	// sort the display
    $area2 = elgg_view("forms/forums/edittopic", array('entity' => $topic));
    $body = elgg_view_layout('two_column_left_sidebar', '', $area2);
		
	// Display page
	page_draw(elgg_echo('groups:edittopic'),$body);
		
?>