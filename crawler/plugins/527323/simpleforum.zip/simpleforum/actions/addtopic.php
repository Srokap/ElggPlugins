<?php

    /**
	 * Elgg groups plugin add topic action.
	 * 
	 * @package ElggGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	// Make sure we're logged in; forward to the front page if not
		if (!isloggedin()) forward();
		
	// Get input data
	    $title = get_input('topictitle');
		$message = get_input('topicmessage');
		$tags = get_input('topictags');
		$access = get_input('access_id');
		$user_guid = (int) get_loggedin_userid();
		$status = get_input('status'); // sticky, resolved, closed
		
	// Convert string of tags into a preformatted array
		 $tagarray = string_to_tag_array($tags);
		
	// Make sure the title / message aren't blank
		if (empty($title) || empty($message)) {
			register_error(elgg_echo("grouptopic:blank"));
			forward("mod/simpleforum/addtopic.php/");
			
	// Otherwise, save the topic
		} else {
			
	// Initialise a new ElggObject
			$topic = new ElggObject();
	// Tell the system it's a group forum topic
			$topic->subtype = "forumtopic";
	// Set its owner to the current user
			$topic->owner_guid = $user_guid;
	// Set the group it belongs to
			$topic->container_guid = $user_guid;
	// For now, set its access to public (we'll add an access dropdown shortly)
			$topic->access_id = $access;
	// Set its title and description appropriately
			$topic->title = $title;
	// Before we can set metadata, we need to save the topic
			if (!$topic->save()) {
				register_error(elgg_echo("grouptopic:error"));
				forward("pg/forum/");
			}
	// Now let's add tags. We can pass an array directly to the object property! Easy.
			if (is_array($tagarray)) {
				$topic->tags = $tagarray;
			}
	// add metadata
	        $topic->status = $status; // the current status i.e sticky, closed, resolved, open
	           
    // now add the topic message as an annotation
        	$topic->annotate('topic_post',$message,$access, $user_guid);   
        	
    // add to river
	        add_to_river('river/simpleforum/topic/create','create',$user_guid,$topic->guid);
	        
	// Success message
			system_message(elgg_echo("grouptopic:created"));
			
	// Forward to the group forum page
	        global $CONFIG;
	        $url = $CONFIG->wwwroot . "pg/forum/";
			forward($url);
				
		}
		
?>

