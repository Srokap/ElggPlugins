<?php
	/**
	* simpleforum
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	// Load Elgg engine
		require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
		
		gatekeeper();	
		
    // get the entity from id
        $topic = get_entity(get_input('topic'));
        if (!$topic) forward();
         
    // Display them
	    $area2 = elgg_view("simpleforum/viewposts", array('entity' => $topic));
	    $body = elgg_view_layout("two_column_left_sidebar", '' , $area2);
		
	// Display page
		page_draw($topic->title, $body);
		
?>