<?php
	/**
	* simpleforum
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	$english = array(
			//Translation Here
			'forum' => 'Forum',
			'item:object:groupforumtopic' => 'Discussion topics',
			'groupspost:success' => 'Your comment was succesfully posted',
	
			'groupspost:failure' => 'Error was found trying to save',
			'groupspost:nopost' => 'grouppost',
			'groupstopic:notfound' => 'Empty post',
			'grouptopic:blank' => 'No topic',
			'grouptopic:error' => 'Your discussion topic could not be created. Please try again or contact a system administrator.',
			'grouptopic:created' => 'Your topic was created.',
			'grouppost:deleted' => 'Forum posting successfully deleted',
			'grouppost:notdeleted' => 'Forum posting could not be deleted',
			'groupstopic:deleted' => 'Topic deleted',
			'groupstopic:notdeleted' => 'Topic not deleted',
			'grouptopic:notfound' => 'Could not find the topic',
			'groups:forumpost:edited' => 'You have successfully edited the forum post.',
			'groups:forumpost:error' => 'There was a problem editing the forum post.',
			'groups:forumtopic:edited' => 'Forum topic successfully edited.',
			
			'topic:created' => 'Created %s with %d posts',
			'topic:updated' => 'Last comment',
			'groupforum:river:postedtopic' => '%s has started a new discussion topic titled',
			'groupforum:river:annotate:create' => 'on this discussion topic',
			'groupforum:river:posted' => '%s has posted a new comment',
			'groups:reply' => 'Post a comment',
			'groups:addtopic' => 'Add a topic',
			'groups:topicstatus' => 'Topic status',
			'groups:topicmessage' => 'Topic message',
			'groups:topicopen' => 'Open',
			'groups:topicclosed' => 'Closed',
			'groups:topicsticky' => 'Sticky',
			'groups:topicresolved' => 'Resolved',
			'groups:started' => "Started by",
			'groupforum:river:postedtopic' => '%s has started a new discussion topic titled',
			'groups:forum' => 'Discussion',
			'grouptopic:notcreated' => 'No topics have been created.',
			'groups:topicisclosed' => 'This topic is closed.',
			'groups:topiccloseddesc' => 'This topic has now been closed and is not accepting new comments.',
	
			'simpleforum:admin' => 'Simple Forum Settings',
			'simpleforum:ping:title' => 'Simpleforum Plugin',		
			'simpleforum:ping:description' => 'Help us to improve the quality of this plugin. This program will send minimal information (elgg version, site url, name of the plugin) just once to the keetup.com servers to know the majority elgg versions the users have installed. Then we can focus on that particular versions.',
			'simpleforum:ping:description2' => 'We can also send to you a notification when we release new versions of this plugin so please add your email address',
			'simpleforum:ping:description3' => 'this will be used just to that end',
			'simpleforum:ping:thanks' => 'Thanks for help us',
			'simpleforum:ping:cancel' => 'No, thanks',
			'simpleforum:ping' => 'Yes, I want to help',
	
	);
					
	add_translation("en",$english);
?>