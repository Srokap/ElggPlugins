<?php
	/**
	* simpleforum
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	//get the required variables
    $title = htmlentities($vars['entity']->title, ENT_QUOTES, 'UTF-8');
    //$description = get_entity($vars['entity']->description);
    $topic_owner = get_user($vars['entity']->owner_guid);
    $user = get_entity($vars['entity']->container_guid);
    $forum_created = friendly_time($vars['entity']->time_created);
    $counter = $vars['entity']->countAnnotations("topic_post");
    $last_post = $vars['entity']->getAnnotations("topic_post", 1, 0, "desc");
    
    //get the time and user
    if ($last_post) {
		foreach($last_post as $last)
		{
			$last_time = $last->time_created;
			$last_user = $last->owner_guid;
		}
	}

	$u = get_user($last_user);
	
	//select the correct output depending on where you are
	/*
	if(get_context() == "search"){
		
	
	    $info = "<p class=\"latest_discussion_info\">" . sprintf(elgg_echo('group:created'), $forum_created, $counter) .  "<br /><span class=\"timestamp\">";
	    if (($last_time) && ($u)) $info.= sprintf(elgg_echo('groups:lastupdated'), friendly_time($last_time), " <a href=\"" . $u->getURL() . "\">" . $u->name . "</a>");
	    $info .= '</span></p>';
		//get the group avatar
		$icon = elgg_view("profile/icon",array('entity' => $user, 'size' => 'small'));
	    //get the group and topic title
	    
		$info .= "<p>" . elgg_echo('topic') . ": <a href=\"{$vars['url']}mod/simpleforum/topicposts.php?topic={$vars['entity']->guid}\">{$title}</a></p>";
		//get the forum description
		//$info .= $description;
		
	}else{*/
		
		$info = "<span class=\"latest_discussion_info\"><span class=\"timestamp\">" . sprintf(elgg_echo('topic:created'), $forum_created, $counter) . "</span>";
		if (($last_time) && ($u)) $info.= "<br /><span class='timestamp'>" . elgg_echo('topic:updated') . " " . friendly_time($last_time) . " by <a href=\"" . $u->getURL() . "\">" . $u->name . "</a></span>";

		    if ($user->canEdit()) {
	
	                	// display the delete link to those allowed to delete
	                	$info .= "<br /><span class=\"delete_discussion\">" . elgg_view("output/confirmlink", array(
	                																'href' => $vars['url'] . "action/simpleforum/deletetopic?topic=" . $vars['entity']->guid,
	                																'text' => " ",
	                																'confirm' => elgg_echo('deleteconfirm'),
	                															)) . "</span>";
	                				
	           }		
		
		$info .= "</span>";
		
	    //get the user avatar
		$icon = elgg_view("profile/icon",array('entity' => $topic_owner, 'size' => 'small'));
	    $info .= "<p>" . elgg_echo('groups:started') . " " . $topic_owner->name . ": <a href=\"{$vars['url']}mod/simpleforum/topicposts.php?topic={$vars['entity']->guid}\">{$title}</a></p>";
		$info .= "<div class='clearfloat'></div>";
		
	/*}*/
		
		//display
		echo elgg_view_listing($icon, $info);
		
?>