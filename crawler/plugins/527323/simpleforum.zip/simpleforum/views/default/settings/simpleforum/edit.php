<?php
	/**
	* simpleforum
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	global $ASKQUESTION_simpleforum;
	run_function_once("simpleforum_question_for_ping");
	if ($ASKQUESTION_simpleforum) {
		echo elgg_view('simpleforum/question/wrapper');
	}
	
/*** Example code ***/
/*
?>
<p>
	<?php echo elgg_echo('simpleforum:show'); ?>
	<select name="params[show]">
		<option value="yes" <?php if ($vars['entity']->show == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<?php 
*/
/*** Example code ***/
	
	//Developed by Keetup
	echo elgg_view('developed_by_keetup')
?>