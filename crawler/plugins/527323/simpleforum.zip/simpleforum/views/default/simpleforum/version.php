<?php
	/**
	* simpleforum
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	$version = simpleforum_get_version();
	$release = simpleforum_get_version(true);
?>	

	<meta name="simpleforum_release" content="<?php echo $release; ?>" />
	<meta name="simpleforum_version" content="<?php echo $version; ?>" />