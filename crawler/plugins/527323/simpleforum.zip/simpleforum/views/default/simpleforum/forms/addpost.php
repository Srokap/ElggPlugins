<?php
	/**
	* simpleforum
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

// Generate a security header
$security_header = "";
if (!isset($vars['disable_security']) || $vars['disable_security'] != true) {
	$security_header = elgg_view('input/securitytoken');
}	    
?>
	<form action="<?php echo $vars['url']; ?>action/simpleforum/addpost" method="post">
		<?php echo $security_header; ?>
		<p class="longtext_editarea">
			<label><?php echo elgg_echo("groups:reply"); ?><br />
			<?php

				echo elgg_view("input/longtext",array(
									"internalname" => "topic_post",
									"value" => $body,
				));
			?>
			</label>
		</p>
		<p>
		    <!-- pass across the topic guid -->
			<input type="hidden" name="topic_guid" value="<?php echo $vars['entity']->guid; ?>" />
			<!-- display the save button -->
			<input type="submit" class="submit_button" value="<?php echo elgg_echo('save'); ?>" />
		</p>
	
	</form>