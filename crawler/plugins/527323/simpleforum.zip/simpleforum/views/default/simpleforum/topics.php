<?php
	/**
	 * Elgg groups plugin
	 * 
	 * @package ElggGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */
	 
?>

<div id="content_area_group_title"><h2><?php echo elgg_echo("forum"); ?></h2></div>

	<!-- display the add a topic link -->
    <div class="add_topic"><a href="<?php echo $vars['url']; ?>mod/simpleforum/addtopic.php" class="add_topic_button"><?php echo elgg_echo("groups:addtopic"); ?></a></div>
    
<?php
	if($vars['topics'])
		echo $vars['topics'];
	else
		echo "<div class='contentWrapper'>". elgg_echo("grouptopic:notcreated") . "</div>";

?>