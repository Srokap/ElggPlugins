<?php
	/**
	* simpleforum
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/
?>
	.forum_latest {
		margin:0 10px 5px 10px;
		background: #dedede;
		padding:5px;
	   	-webkit-border-radius: 4px; 
		-moz-border-radius: 4px;
	}
	.forum_latest:hover {
	
	}
	.forum_latest .topic_owner_icon {
		float:left;
	}
	.forum_latest .topic_title {
		margin-left:35px;
	}
	.forum_latest .topic_title p {
		line-height: 1.0em;
	    padding:0;
	    margin:0;
	    font-weight: bold;
	}
	.forum_latest p.topic_replies {
	    padding:3px 0 0 0;
	    margin:0;
	    color:#666666;
	}
	.add_topic {
		-webkit-border-radius: 8px; 
		-moz-border-radius: 8px;
		background:white;
		margin:5px 10px;
		padding:10px 10px 10px 6px;
	}
	
	a.add_topic_button {
		font: 12px/100% Arial, Helvetica, sans-serif;
		font-weight: bold;
		color: white;
		background:#4690d6;
		border:none;
		-webkit-border-radius: 5px; 
		-moz-border-radius: 5px;
		width: auto;
		height: auto;
		padding: 3px 6px 3px 6px;
		margin:0;
		cursor: pointer;
	}
	a.add_topic_button:hover {
		background: #0054a7;
		color:white;
		text-decoration: none;
	}
	
	
	
	/* latest discussion listing */
	.latest_discussion_info {
		float:right;
		width:300px;
		text-align: right;
		margin-left: 10px;
	}
	.groups .search_listing br {
		height:0;
		line-height:0;
	}
	span.timestamp {
		color:#666666;
		font-size: 90%;
	}
	.latest_discussion_info .timestamp {
		font-size: 0.85em;
	}
	
	/* IE6 */
	* html #topic_post_tbl { width:676px !important;}
	
	/* all browsers - force tinyMCE on edit comments to be full-width */
	.edit_forum_comments .defaultSkin table.mceLayout {
		width: 636px !important;
	}
	
	/* topics overview page */
	#forum_topics {
	    padding:10px;
	    margin:0 10px 0 10px;
	    background:white;
		-webkit-border-radius: 8px; 
		-moz-border-radius: 8px;    
	}
	/* topics individual view page */
	#topic_posts {
		margin:0 10px 5px 10px;
	}
	#topic_posts #pages_breadcrumbs {
		margin:2px 0 0 0px;
	}
	#topic_posts form {
	    padding:10px;
	    margin:30px 0 0 0;
	    background:white;
		-webkit-border-radius: 8px; 
		-moz-border-radius: 8px; 
	}
	.topic_post {
		padding:10px;
	    margin:0 0 5px 0;
	    background:white;
		-webkit-border-radius: 8px; 
		-moz-border-radius: 8px;  
	}
	.topic_post .post_icon {
	    float:left;
	    margin:0 8px 4px 0;
	}
	.topic_post h2 {
	    margin-bottom:20px;
	}
	.topic_post p.topic-post-menu {
		margin:0;
	}
	.topic_post p.topic-post-menu a.collapsibleboxlink {
		padding-left:10px;
	}
	.topic_post table, .topic_post td {
	    border:none;
	}