<?php
	/**
	* simpleforum
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	// Set title, form destination
			$title = elgg_echo("groups:addtopic");
			$action = "simpleforum/addtopic";
			$tags = "";
			$title = "";
			$message = "";
			$message_id = "";
			$status = "";
			$access_id = ACCESS_DEFAULT;
	    
	// set the title
	    echo elgg_view_title(elgg_echo("groups:addtopic"));
	    

// Generate a security header
$security_header = "";
if (!isset($vars['disable_security']) || $vars['disable_security'] != true) {
	$security_header = elgg_view('input/securitytoken');
}

?>
<div class="contentWrapper">
	<!-- display the input form -->
	<form action="<?php echo $vars['url']; ?>action/<?php echo $action; ?>" method="post">
		<?php echo $security_header; ?>	
		<p>
			<label><?php echo elgg_echo("title"); ?><br />
			<?php
                //display the topic title input
				echo elgg_view("input/text", array(
									"internalname" => "topictitle",
									"value" => $title,
													));
			?>
			</label>
		</p>
		
		<!-- display the tag input -->
		<p>
			<label><?php echo elgg_echo("tags"); ?><br />
			<?php

				echo elgg_view("input/tags", array(
									"internalname" => "topictags",
									"value" => $tags,
													));
			
			?>
		</p>
		
		<!-- topic message input -->
		<p class="longtext_editarea">
			<label><?php echo elgg_echo("groups:topicmessage"); ?><br />
			<?php

				echo elgg_view("input/longtext",array(
									"internalname" => "topicmessage",
									"value" => $message,
													));
			?>
			</label>
		</p>
		
		<!-- set the topic status -->
		<p>
		    <label><?php echo elgg_echo("groups:topicstatus"); ?><br />
		    <select name="status">
		        <option value="open" <?php if($status == "") echo "SELECTED";?>><?php echo elgg_echo('groups:topicopen'); ?></option>
		        <option value="closed" <?php if($status == "closed") echo "SELECTED";?>><?php echo elgg_echo('groups:topicclosed'); ?></option>
		    </select>
		    </label>
		</p>
		
		<!-- access -->
		<p>
			<label>
				<?php echo elgg_echo('access'); ?><br />
				<?php echo elgg_view('input/access', array('internalname' => 'access_id','value' => $access_id)); ?>
			</label>
		</p>
		
		<!-- required hidden info and submit button -->
		<p>
			<input type="submit" class="submit_button" value="<?php echo elgg_echo('save'); ?>" />
		</p>
	
	</form>
</div>
