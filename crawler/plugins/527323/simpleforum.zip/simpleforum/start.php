<?php
	/**
	* simpleforum
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	global $ASKQUESTION_simpleforum;

	function simpleforum_init() {
		global $CONFIG;
		global $ASKQUESTION_simpleforum;
		
		$ASKQUESTION_simpleforum = false;
		
		//Page Handler
		register_page_handler('forum','simpleforum_page_handler');
		
		register_entity_url_handler('simpleforum_forumtopic_url','object','forumtopic');
		
		add_menu(elgg_echo('forum'), $CONFIG->wwwroot . "pg/forum/");
		
		//Print the plugin version
		extend_view('metatags', 'simpleforum/version');
		
		//Extend css view
		extend_view('css', 'simpleforum/css');
		
		if (isadminloggedin()) {
			extend_view('page_elements/header_contents', 'simpleforum/question/content');
		}
	}
	
	function simpleforum_page_handler($page) {
		global $CONFIG;
		if (isset($page[0])) {
			switch($page[0]) {
				case "admin":
					!@include_once(dirname(__FILE__) . "/admin.php");
					return false;
          			break;
			}
		}
		include($CONFIG->pluginspath . "simpleforum/index.php");
		exit;
	}
	
	function simpleforum_forumtopic_url($entity) {
		global $CONFIG;
		return $CONFIG->url . 'mod/simpleforum/topicposts.php?topic='. $entity->guid;
	}
	
	function simpleforum_setup() {
		global $CONFIG;
		if (get_context()=='admin') {
    		add_submenu_item(elgg_echo("simpleforum:admin"), $CONFIG->wwwroot . "pg/simpleforum/admin" );
		}
	}
	
	function simpleforum_question_for_ping() {
		global $ASKQUESTION_simpleforum;
		$ASKQUESTION_simpleforum = true;
	}
    
    function simpleforum_get_version($humanreadable = false){
	    if (include(dirname(__FILE__) . "/version.php")) {
			return (!$humanreadable) ? $version : $release;
		}
		return FALSE;
    }
    	
	//Generate url for accept action on elgg 1.7
	if(!is_callable('url_compatible_mode')) {
	    function url_compatible_mode($hook = '?') {
	    	$now = time();
			$query[] = "__elgg_ts=" . $now;
			$query[] = "__elgg_token=" . generate_action_token($now);
			$query_string = implode("&", $query);
			return $hook . $query_string;
	    }
	}
	
	register_action("simpleforum/addtopic",false,$CONFIG->pluginspath . "simpleforum/actions/addtopic.php");
	register_action("simpleforum/deletetopic",false,$CONFIG->pluginspath . "simpleforum/actions/deletetopic.php");
	register_action("simpleforum/addpost",false,$CONFIG->pluginspath . "simpleforum/actions/addpost.php");
	register_action("simpleforum/edittopic",false,$CONFIG->pluginspath . "simpleforum/actions/edittopic.php");
	register_action("simpleforum/deletepost",false,$CONFIG->pluginspath . "simpleforum/actions/deletepost.php");
	register_action("simpleforum/editpost",false,$CONFIG->pluginspath . "simpleforum/actions/editpost.php");
	
	register_elgg_event_handler('init','system','simpleforum_init');
	register_elgg_event_handler('pagesetup','system','simpleforum_setup');