<?php
	/**
	* simpleforum
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	// Load Elgg engine
		require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
		
		gatekeeper();
		
	// sort the display
	    $area2 = elgg_view("simpleforum/forms/addtopic");
	    $body = elgg_view_layout('two_column_left_sidebar',$area1, $area2);
		
	// Display page
		page_draw(elgg_echo('groups:addtopic'),$body);
		
?>