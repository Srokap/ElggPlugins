<?php
	/**
	* simpleforum
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	
	//get any forum topics
	//get any forum topics
	$topics = list_entities_from_annotations("object", "forumtopic", "topic_post", "", 20, 0, "", false, false, false);
	set_context('search');
	$area2 = elgg_view("simpleforum/topics", array('topics' => $topics));
	set_context('simpleforum');
	
	$body = elgg_view_layout('two_column_left_sidebar',$area1, $area2);
	
	$title = elgg_echo('item:object:groupforumtopic');
	
	// Finally draw the page
	page_draw($title, $body);

?>