<?php
 
// Generate By translationbrowser. 
 
$french = array( 
		/**
		 * Menu items and titles
		 */
	
			'discussion:salon' => "Salon de discussion", 
			'englishlevel' => "englishlevel chat", 'englishlevel:disc' => "pluging pour participer aux salon de discussion sur englishlevel",
); 
 
add_translation('fr', $french); 
 
?>