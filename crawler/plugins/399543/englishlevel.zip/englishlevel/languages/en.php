<?php

	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'discussion:salon' => "Chat room", 			'englishlevel' => "englishlevel chat", 
'englishlevel:disc' => "chat room on englishlevel",  
	);
					
	add_translation("en",$english);

?>