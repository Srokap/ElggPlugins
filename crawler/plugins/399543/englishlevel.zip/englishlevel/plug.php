<?php 
//autor :l'alchimiste
//freedom palestine
?>

<div Style="Font: 10px Verdana; font-weight:bold;">lest's know your english level</div>
<script type="text/javascript" src="http://cdn.widgetserver.com/syndication/subscriber/InsertWidget.js"></script><script>if (WIDGETBOX) WIDGETBOX.renderWidget('bbb67134-faf7-49dd-8976-3e165c12c76d');</script><noscript>Get the <a href="http://www.widgetbox.com/widget/english-level-test">English level test</a> widget and many other <a href="http://www.widgetbox.com/">great free widgets</a> at <a href="http://www.widgetbox.com">Widgetbox</a>! Not seeing a widget? (<a href="http://docs.widgetbox.com/using-widgets/installing-widgets/why-cant-i-see-my-widget/">More info</a>)</noscript> 