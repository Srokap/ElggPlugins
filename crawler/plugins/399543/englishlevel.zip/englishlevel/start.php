<?php
  function englishlevel_init() {   
  // Load system configuration
			global $CONFIG;
	if (isloggedin()) {
    				
	//	add_menu(elgg_echo('englishlevel'), $CONFIG->wwwroot . "pg/englishlevel/" . $_SESSION['user']->username);
			 
				} 

		register_page_handler('englishlevel','englishlevel_page_handler');
	
add_widget_type('englishlevel', 'englishlevel Widget', elgg_echo("englishlevel:disc"));//last parametre pour info bull sur le tablo des widgets:)
  }
 function englishlevel_page_handler($page) {
			
 			if (isset($page[0])) {
				set_input('username',$page[0]);
			}
			
			 
				@include(dirname(__FILE__) . "/index.php");
				return true;
		 
		}
	
  register_elgg_event_handler('init','system','englishlevel_init');       
?>