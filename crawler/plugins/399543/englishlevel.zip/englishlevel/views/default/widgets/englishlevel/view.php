<div class="contentWrapper">
<!--Your englishlevel Embed code below-->
<div style="width:270px">		 
		<iframe id="ifrVideoStreaming" name="ifrVideoStreaming" src="<?php echo $vars['url']; ?>/mod/englishlevel/plug.php"
											frameborder="0" scrolling="no"  height="250"></iframe> </div>

	 </div>
</div>
