<?php
/*******************************************************************************
 * usernamePasswordChecker
 *
 * @author Leo de Carvalho
 * @author Trajan 2010
 ******************************************************************************/

$english = array(
                'usernameChecker:message:available' => 'Username available to register',
                'usernameChecker:message:exists' => 'This user name already exists',
                'usernameChecker:message:minChar' => 'Username must be at least 4 characters',
                'emailChecker:message:available' => 'Email available to register',
                'emailChecker:message:exists' => 'This email address has already been registered',
                'emailChecker:message:error' => 'This email is not valid',
                'emailChecker:activate' => "Activate the email checker?",
                'usernameChecker:activate' => "Activate the username checker?",
                'passwordchecker:message:veryweak' => 'Weak',
                'passwordchecker:message:weak' => 'Very Weak',
                'passwordchecker:message:medium' => 'Medium',
                'passwordchecker:message:strong' => 'Strong',
                'passwordchecker:message:verystrong' => 'Very Strong',
                'passwordchecker:message:minchar' => 'Minimum number of characters is ',
                'passwordchecker:activate' => "Activate the password checker?",

);

add_translation("en",$english);
?>