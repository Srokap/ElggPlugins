/*******************************************************************************
 * usernamePasswordChecker
 *
 * @author Leo de Carvalho
 ******************************************************************************/
function emailChecker(verifyUserDisponibilityFile, messageExists, messageError, messageAvailable) {

		//remove all the class add the messagebox classes and start fading
                $('input[name=email]').before('<span id="msgboxemail" style="display:none"></span>');
		$("#msgboxemail").removeClass().addClass('messagebox').text('Checking...').fadeIn("slow");
		//check the username exists or not from ajax
		$.post(verifyUserDisponibilityFile,{ email:$('input[name=email]').val() } ,function(data)
        {

		  if(data=='no') //if email not available
		  {
		  	$("#msgboxemail").fadeTo(200,0.1,function() //start fading the messagebox
			{
			  //add message and change the class of the box and start fading
			  $(this).html(messageExists).addClass('messageboxerror').fadeTo(900,1);
			});
                  }
                  else if (data == 'error') { // email is not valid
                        $("#msgboxemail").fadeTo(200,0.1,function() //start fading the messagebox
			{
			  //add message and change the class of the box and start fading
			  $(this).html(messageError).addClass('messageboxerror').fadeTo(900,1);
			});
                  }
		  else
		  {
		  	$("#msgboxemail").fadeTo(200,0.1,function()  //start fading the messagebox
			{
			  //add message and change the class of the box and start fading
			  $(this).html(messageAvailable).addClass('messageboxok').fadeTo(900,1);
			});
		  }

        });


        }