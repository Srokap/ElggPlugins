/*******************************************************************************
 * usernamePasswordChecker
 *
 * @author Leo de Carvalho
 ******************************************************************************/
function usernameChecker(verifyUserDisponibilityFile, messageExists, messageMinChar, messageAvailable) {

		//remove all the class add the messagebox classes and start fading
                $('input[name=username]').before('<span id="msgbox" style="display:none"></span>');
		$("#msgbox").removeClass().addClass('messagebox').text('Checking...').fadeIn("slow");
		//check the username exists or not from ajax
		$.post(verifyUserDisponibilityFile,{ username:$('input[name=username]').val() } ,function(data)
        {

		  if(data=='no') //if username not avaiable
		  {
		  	$("#msgbox").fadeTo(200,0.1,function() //start fading the messagebox
			{
			  //add message and change the class of the box and start fading
			  $(this).html(messageExists).addClass('messageboxerror').fadeTo(900,1);
			});
                  }
                  else if (data == 'error') {
                        $("#msgbox").fadeTo(200,0.1,function() //start fading the messagebox
			{
			  //add message and change the class of the box and start fading
			  $(this).html(messageMinChar).addClass('messageboxerror').fadeTo(900,1);
			});
                  }
		  else
		  {
		  	$("#msgbox").fadeTo(200,0.1,function()  //start fading the messagebox
			{
			  //add message and change the class of the box and start fading
			  $(this).html(messageAvailable).addClass('messageboxok').fadeTo(900,1);
			});
		  }

        });


        }