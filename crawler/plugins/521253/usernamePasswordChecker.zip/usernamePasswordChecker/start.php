<?php
/*******************************************************************************
 * usernamePasswordChecker
 *
 * @author Leo de Carvalho
 * @author Trajan 2010
 ******************************************************************************/

	function usernamePasswordChecker_init()
	{
		global $CONFIG;
		extend_view('css','usernamePasswordChecker/css');

                $passwordChecker = get_plugin_setting('passwordChecker','usernamePasswordChecker');
		if (!$passwordChecker || $passwordChecker == 'yes') {
                     extend_view('account/forms/register', 'passwordchecker/register');
                     extend_view('usersettings/form', 'passwordchecker/password');
                }

                $usernameChecker = get_plugin_setting('usernameChecker','usernamePasswordChecker');
                if (!$usernameChecker || $usernameChecker == 'yes') {
                     extend_view('account/forms/register','usernameChecker/register');
                     register_action('usernamePasswordChecker/user_availability', true, $CONFIG->pluginspath . "/usernamePasswordChecker/actions/user_availability.php", false);
                }

                $emailChecker = get_plugin_setting('emailChecker','usernamePasswordChecker');
                if (!$emailChecker || $emailChecker == 'yes') {
                    extend_view('account/forms/register','emailChecker/register');
                    extend_view('usersettings/form', 'emailChecker/email');
                    register_action('usernamePasswordChecker/email_availability',  true, $CONFIG->pluginspath . "/usernamePasswordChecker/actions/email_availability.php", false);
                }
                return true;
	}


	register_elgg_event_handler('init', 'system', 'usernamePasswordChecker_init');
?>