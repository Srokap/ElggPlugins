<?php
/*******************************************************************************
 * usernamePasswordChecker
 *
 * @author Leo de Carvalho
 ******************************************************************************/

require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
global $CONFIG;

//value got from the get metho
$email =  get_input('email');

if (!is_email_address($email)) {
	echo 'error';
}
else{
    //checking weather user exists or not in $existing_users array
    $user = get_user_by_email($email);

    if ($user != NULL)
    {
        //email registred
	echo 'no';
    }
    else
    {
	//email avaiable
	echo 'yes';
    }
}
?>