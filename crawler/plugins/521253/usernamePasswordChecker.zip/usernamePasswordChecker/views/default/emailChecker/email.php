<?php
/*******************************************************************************
 * usernamePasswordChecker
 *
 * @author Leo de Carvalho
 ******************************************************************************/
 ?>
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/usernamePasswordChecker/js/jquery.emailChecker.js">
    // verify name avaiability
</script>
<script language="javascript">
$(document).ready(function()
{
	$('input[name=email]').blur(function () { emailChecker('<?php echo $vars['url']; ?>mod/usernamePasswordChecker/actions/email_availability.php', '<?php echo elgg_echo("emailChecker:message:exists") ?>',
            '<?php echo elgg_echo("emailChecker:message:error") ?>',
            '<?php echo elgg_echo("emailChecker:message:available") ?>') });
});
</script>
