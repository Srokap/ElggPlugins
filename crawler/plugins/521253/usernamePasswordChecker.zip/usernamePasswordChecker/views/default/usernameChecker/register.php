<?php
/*******************************************************************************
 * usernamePasswordChecker
 *
 * @author Leo de Carvalho
 ******************************************************************************/
 ?>
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/usernamePasswordChecker/js/jquery.usernameChecker.js">
    // verify name avaiability
</script>
<script language="javascript">
$(document).ready(function()
{
	$('input[name=username]').blur(function () { usernameChecker('<?php echo $vars['url']; ?>mod/usernamePasswordChecker/actions/user_availability.php', '<?php echo elgg_echo("usernameChecker:message:exists") ?>',
            '<?php echo elgg_echo("usernameChecker:message:minChar") ?>',
            '<?php echo elgg_echo("usernameChecker:message:available") ?>') });
});
</script>