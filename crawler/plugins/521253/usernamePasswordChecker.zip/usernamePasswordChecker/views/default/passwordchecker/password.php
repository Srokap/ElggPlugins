<?php
/*******************************************************************************
 * usernamePasswordChecker
 *
 * @author Leo de Carvalho
 ******************************************************************************/
 ?>
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/usernamePasswordChecker/js/jquery.pstrength-min.1.2.js">
</script>
<script type="text/javascript">
$(function() {
$('input[name=password]').pstrength(
    '<?php echo elgg_echo('passwordchecker:message:minchar') ?>',
    '<?php echo elgg_echo("passwordchecker:message:veryweak") ?>',
    '<?php echo elgg_echo("passwordchecker:message:weak") ?>',
    '<?php echo elgg_echo("passwordchecker:message:medium") ?>',
    '<?php echo elgg_echo("passwordchecker:message:strong") ?>',
    '<?php echo elgg_echo("passwordchecker:message:verystrong") ?>');
});
</script>