<?php
/*******************************************************************************
 * usernamePasswordChecker
 *
 * @author Trajan
 ******************************************************************************/
    if ($vars['entity']) {
        if (!$vars['entity']->usernameChecker) {
	    $$vars['entity']->usernameChecker = "yes";
        }
        if (!$vars['entity']->passwordChecker) {
	    $vars['entity']->passwordChecker = "yes";
        }
        if (!$vars['entity']->emailChecker) {
	    $vars['entity']->emailChecker = "yes";
        }
    }
 ?>
 
 <p>	
	<?php echo elgg_echo('usernameChecker:activate'); ?> 
<select name="params[usernameChecker]">
  <option value="yes" <?php if($vars['entity']->usernameChecker != 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
  <option value="no" <?php if($vars['entity']->usernameChecker == 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
</select> 
</p>
<br />
 <p>	
	<?php echo elgg_echo('passwordchecker:activate'); ?> 
<select name="params[passwordChecker]">
  <option value="yes" <?php if($vars['entity']->passwordChecker != 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
  <option value="no" <?php if($vars['entity']->passwordChecker == 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
</select> 
</p>
<br />
<p>
	<?php echo elgg_echo('emailChecker:activate'); ?>
<select name="params[emailChecker]">
  <option value="yes" <?php if($vars['entity']->emailChecker != 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
  <option value="no" <?php if($vars['entity']->emailChecker == 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
</select>
</p>