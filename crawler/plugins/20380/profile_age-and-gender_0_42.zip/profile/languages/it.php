<?php

	$italian = array(

		/**
		 * Misc
		 */
		
			"profile:name" => "Nome",
			"profile:age" => "Et&agrave;",
			"profile:dateofbirth" => "Data di nascita",
			"profile:age:unit" => "anni",
			"profile:description:none" => "...",

			"profile:gender" => "Sesso",
			"profile:gender:n" => "seleziona sesso:",
			"profile:gender:m" => "uomo",
			"profile:gender:f" => "donna",

			"profile:birthdate" => "Data di nascita",
			
			"date:day" => "giorno",
			"date:month" => "mese",
			"date:year" => "anno",

			"month:1" => "Gennaio",
			"month:2" => "Febbraio",
			"month:3" => "Marzo",
			"month:4" => "Aprile",
			"month:5" => "Maggio",
			"month:6" => "Giugno",
			"month:7" => "Luglio",
			"month:8" => "Agosto",
			"month:9" => "Settembre",
			"month:10" => "Ottobre",
			"month:11" => "Novembre",
			"month:12" => "Dicembre",

	);
	
	add_translation("it",$italian);

?>
