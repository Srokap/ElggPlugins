<?php

	$english = array(

		/**
		 * Misc
		 */

			"profile:name" => "Name",
			"profile:age" => "Age",
			"profile:dateofbirth" => "Date of birth",
			"profile:age:unit" => "years old",
			"profile:description:none" => "...",

			"profile:gender" => "Gender",
			"profile:gender:n" => "select:",
			"profile:gender:m" => "male",
			"profile:gender:f" => "female",

			"profile:birthdate" => "Date of birth",
			
			"date:day" => "day",
			"date:month" => "month",
			"date:year" => "year",

			"month:1" => "January",
			"month:2" => "February",
			"month:3" => "March",
			"month:4" => "April",
			"month:5" => "May",
			"month:6" => "June",
			"month:7" => "July",
			"month:8" => "Agoust",
			"month:9" => "September",
			"month:10" => "October",
			"month:11" => "November",
			"month:12" => "December",
	);
	
	add_translation("en",$english);

?>
