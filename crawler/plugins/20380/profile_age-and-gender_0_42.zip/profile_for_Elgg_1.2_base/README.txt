INSTALLATION
-----

This is the Elgg 1.2 base compatible version of the plug-in.

Just install the plugin as explained in the first directory, then copy the views dir from profile_for_Elgg_1.2_base to your mod/profile dir, overwriting existing files.

Have fun ;)

-----
Sergio De Falco aka SGr33n

www.ircaserta.com
www.myspace.com/sgr33n
