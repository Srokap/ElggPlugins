<?php global $CONFIG; ?>
<script type="text/javascript" src="<?php echo $CONFIG->url; ?>mod/protovis/assets/protovis-r3.2.js"></script>
