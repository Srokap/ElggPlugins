Protovis v3.2

For documentation, see http://protovis.org.
For development, see http://gitorious.org/protovis.
