<?php
$portuguese = array(
/**
 * Blog types translations
 */
  'blog:type'=>"Tipo de Artigo",
  'blog:type:ArtandPhotography'=>"Arte e Fotografia",
  'blog:type:Automotive'=>"Automotivo",
  'blog:type:Blogging'=>"Blog",
  'blog:type:MoviesTVCelebrities'=>"Filmes, TV e Celebridades",
  'blog:type:DreamsandSupernatural'=>"Sonhos e Sobrenatural",
  'blog:type:FashionStyleShopping'=>"Moda e Estilo",
  'blog:type:FoodandRestaurants'=>"Comida e Restaurantes",
  'blog:type:Friends'=>"Amigos",
  'blog:type:Games'=>"Jogos",
  'blog:type:JobsWorkCareers'=>"Carreira, Trabalho e Empregos",
  'blog:type:Life'=>"Vida",
  'blog:type:Music'=>"Música",
  'blog:type:NewsandPolitics'=>"Notícias e Política",
  'blog:type:PetsandAnimals'=>"Animais",
  'blog:type:Personal'=>"Pessoal",
  'blog:type:Podcast'=>"Podcast",
  'blog:type:ReligionandPhilosophy'=>"Filosofia e Religião",
  'blog:type:Sports'=>"Esportes",
  'blog:type:TravelandPlaces'=>"Viagens e Lugares",
  'blog:type:WebHTMLComputerTech'=>"Web, HTML e Tecnologia",
  'blog:type:WritingandPoetry'=>"Poemas",
  'blog:type:School'=>"Ensino e Escola",
  'blog:type:Others'=>"Outros",
/**
 * Blog widget
 */
  'blog:widget:title'=>"Blog",
  'blog:widget:description'=>"Exibir seus artigos no perfil",
  'blog:widget:default_view'=>"Escolha o modelo",
  'blog:widget:default'=>"Padrão",
  'blog:widget:compact'=>"Compacto",

  'contents:empty'=>"Não existe nenhum artigo",

  'blog:extratypes:enable'=> "Habilitar soporte ao blog?",
  'blog:group:contents'=> "Habilitar grupos de artigos?",
  'blog:group:iconoverwrite'=>"Habilitar icone quando tiver um grupo associado?",

// Group related translations
  'group:contents'=>"Artigos",
  'group:contents:empty'=>"Não existe nenhum artigo",

//
  'content:owner'=>"Atribuir para",
  'my:profile'=>"Meu perfil",
  'publish:for'=>"Publicado em %s",

);
add_translation("pt",$portuguese);

?>
