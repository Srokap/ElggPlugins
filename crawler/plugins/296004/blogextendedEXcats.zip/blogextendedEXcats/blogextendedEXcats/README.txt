Blog extended plugin
=======================

Features:
  - Extend the edit blog view to support before and after description fields.
  - Add support for blog types
  - Add support for assign blog 'ownership' to a group (Read more after)
  - Widget for show blog posts in the profile
  - Overwrite post icon with the group icon (if it is associated to a group)
  
Install
-------

Just drop it on your mod directory and then go to the admin panel and activate it. 

Take on mind that this plugins overwrites some blog plugin behaviors so it need 
to be loaded after it.

How works the blog post group 'ownership' works?
------------------------------------------------
It let the user specify on what of his groups wants to publish a content.
The user continues being the post owner just that the content is published in their profile
AND in the group profile.

At this moment the group owner couldn't edit or deny blog posts content but its a planed feature
to support some kind of pre-approval process to let group owners accept/deny contents for their group.