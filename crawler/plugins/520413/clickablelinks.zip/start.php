<?php

	
	 
	    function clickablelinks_init() {
    	    
    	    // Load system configuration
				global $CONFIG;
				
		}
		
	    function makeClickableLinks($text) {
	
	      $text = eregi_replace('(((f|ht){1}tp://)[-a-zA-Z0-9@:%_+.~#?&//=]+)',
	        '<a href="\\1"target=\"_blank\">\\1" "</a>', $text);
	    
	    return $text;
	
	    }	
		
	// Make sure the messages initialisation function is called on initialisation
		register_elgg_event_handler('init','system','clickablelinks_init');
		 
?>