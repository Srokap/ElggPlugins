<?php
/**
 * File river view.
 */

$object = $vars['item']->getObjectEntity();
$excerpt = strip_tags($object->description);
$excerpt = elgg_get_excerpt($excerpt);

echo elgg_view('river/elements/layout', array(
	'item' => $vars['item'],
	'message' => $excerpt,
));

?>
<div style="margin-left:34px;">
<?php
echo "<div>";
echo elgg_view_entity_icon($object, 'small');
echo "<div>" .$object->description. "</div>";
echo "</div>";
?>
<?php

//audio player

if ($object->simpletype == "audio") {
?>
<script>
$(document).ready(function(){
$("#ocultar").click(function(){$("#showmp3_<?php echo $object->guid ?>").hide("slow")});
$("#rep_<?php echo $object->guid ?>").click(function(){$("#showmp3_<?php echo $object->guid ?>").show("slow")});
});
</script>
<div style="padding-top:5px; padding-bottom:5px; ">
<a id="rep_<?php echo $object->guid ?>" style="cursor: pointer;">Play</a>
</div>
<div id="showmp3_<?php echo $object->guid ?>" style="display:none;">
<?php
$playlist = $playlist . $vars['url'] . 'action/file/download?file_guid=' . $object->guid;
$titles = $titles . $object->title;
?>
<object type="application/x-shockwave-flash" data="<?php echo $vars['url']; ?>mod/file/audioplayer/player_mp3_maxi.swf" width="200" height="20" wmode="transparent">
<param name="movie" value="<?php echo $vars['url']; ?>mod/file/audioplayer/player_mp3_maxi.swf" />
<PARAM NAME="WMODE" VALUE="transparent">
<param name="FlashVars" value="mp3=<?php echo $playlist; ?>&amp;title=<?php echo $titles; ?>&amp;showstop=1&amp;showinfo=1&amp;showvolume=1" /></center>
</object>
</div>
<?php
}
?>
</div>