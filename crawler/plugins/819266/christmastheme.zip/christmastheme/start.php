<?php

function christmastheme_init() {

    //Register our theme for deyan shell
	deyan_register_theme('christmastheme');

}

elgg_register_event_handler('init', 'system', 'christmastheme_init');

?>
