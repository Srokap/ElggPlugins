<?php
	echo $vars['url'] . "mod/theme_simpleneutralcolour/graphics/file_icons/pages.gif";
?>