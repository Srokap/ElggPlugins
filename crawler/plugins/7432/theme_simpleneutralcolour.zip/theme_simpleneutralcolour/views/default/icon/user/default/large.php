<?php
	echo $vars['url'] . "mod/theme_simpleneutralcolour/graphics/user_icons/defaultlarge.gif";
?>