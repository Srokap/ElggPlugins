<?php
	echo $vars['url'] . "mod/theme_simpleneutralcolour/graphics/group_icons/defaultsmall.gif";
?>