<?php

	/**
	 * Elgg bookmarks CSS 
	 * 
	 * @package ElggBookmarks
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider <info@elgg.com>
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.org/
	 */

?>

.sharing_item {
	margin-bottom: 50px;
	border-bottom:1px solid #AAAAAA;
	padding:0 0px 10px 0px;
}

.sharing_item_owner {
	font-size: 90%;
	margin: 10px 0 0 0;
	color:#666666;
}

.sharing_item_owner .icon {
	float: left;
	margin-right: 5px;

}
.sharing_item_title h3 {
	font-size: 150%;
	margin-bottom: 5px;
}
.sharing_item_title h3 a {
	text-decoration: none;
}
.sharing_item_description p {
	margin:0;
	padding:0 0 5px 0;
}
p.shares_gallery_title {

}
.sharing_item_tags {
	background:transparent url(<?php echo $vars['url']; ?>mod/theme_simpleneutralcolour/graphics/icon_tag.gif) no-repeat scroll left 2px;
	margin:0;
	padding:0 0 0 14px;
}

.sharing_item_address a {
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: white;
	background:#666666;
	border:none;
	-webkit-border-radius: 5px; 
	-moz-border-radius: 5px;
	width: auto;
	height: 25px;
	padding: 3px 6px 3px 6px;
	margin:10px 0 10px 0;
	cursor: pointer;
}
.sharing_item_address a:hover {
	background: black;
	color:white;
	text-decoration: none;
}
.sharing_item_controls p {
	margin:0;
}



/* SHARES WIDGET VIEW */
.shares_widget_wrapper {
	margin:0 0 10px 0;
	padding:5px;
	background:#cccccc;
}
.shares_widget_wrapper:hover {
	background:#aaaaaa;
}
.shares_widget_icon {
	float: left;
	margin-right: 10px;
}
.shares_timestamp {
	color:#666666;
	margin:0;
}
.share_desc {
	display:none;
	line-height: 1.2em;
}
.shares_widget_content {
	margin-left: 35px;
}
.shares_title {
	margin:0;
	line-height: 1.2em;
	/* color:white; */
}
p.shares_title a {
	/* color:white; */
	font-weight:bold;
}

/* timestamp and user info in gallery and list view */
.search_listing_info .shares_gallery_user,
.share_gallery_info .shares_gallery_user,
.share_gallery_info .shares_gallery_comments {
	color:#666666;
	margin:0;
	font-size: 90%;	
}




