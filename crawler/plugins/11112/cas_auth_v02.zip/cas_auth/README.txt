Elgg is an open source social networking platform.

CAS (Central Authentification Service) is an SSO.

This project tries to allow CAS authentification in Elgg. The idea is to authenticate with CAS, then look up the user info in LDAP
and authenticate the user in Elgg.

This plugin has been widely built on the ldap_auth plugin from Misja Hoebe and is inspired from the CAS authentification used in 
Claroline : www.claroline.net

You can edit the config in the Tool administration section by providing CAS host, port and URI.

--

Xavier Roussel
Responsable technique - TICE
Direction des Systèmes d'Information - UVSQ
xavier.roussel@uvsq.fr
www.uvsq.fr
www.tice.uvsq.fr