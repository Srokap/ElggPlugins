<?php

     /**
	 * Elgg login form adapted for CAS Auth
	 * 
	 * @package cas_auth
	 * @license http://www.gnu.org/licenses/gpl.html
	 * @author Xavier Roussel
	 * @copyright UVSQ 2008
	 * @link http://www.uvsq.fr
	 */
	 
	global $CONFIG;
	
	$form_body = "<p class=\"login-box\"><label>" . elgg_echo('username') . "<br />" . elgg_view('input/text', array('internalname' => 'username', 'class' => 'login-textarea')) . "</label>";
	$form_body .= "<br />";
	$form_body .= "<label>" . elgg_echo('password') . "<br />" . elgg_view('input/password', array('internalname' => 'password', 'class' => 'login-textarea')) . "</label><br />";
	$form_body .= elgg_view('input/submit', array('value' => elgg_echo('login'))) . " <div id=\"persistent_login\"><label><input type=\"checkbox\" name=\"persistent\" value=\"true\" />".elgg_echo('user:persistent')."</label></div></p>";
	$form_body .= "<p class=\"loginbox\">";
	$form_body .= (!isset($CONFIG->disable_registration) || !($CONFIG->disable_registration)) ? "<a href=\"{$vars['url']}account/register.php\">" . elgg_echo('register') . "</a> | " : "";
	$form_body .= "<a href=\"{$vars['url']}account/forgotten_password.php\">" . elgg_echo('user:password:lost') . "</a></p>";  
	
	//<input name=\"username\" type=\"text\" class="general-textarea" /></label>
?>
	
	<div id="login-box">
	<h2><?php echo elgg_echo('login'); ?></h2>
		<!-- Comment the line below to allow only CAS authentification -->
		<?php  echo elgg_view('input/form', array('body' => $form_body, 'action' => "{$vars['url']}action/login")); ?>
		<a href="/?authModeReq=CAS" alt="CAS Connection"><img src="<?php echo $CONFIG->wwwroot; ?>mod/cas_auth/images/connex_cas.gif" title="CAS connection"></a>
	</div>
