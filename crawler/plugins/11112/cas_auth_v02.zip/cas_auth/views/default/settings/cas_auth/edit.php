<?php
 /**
* Elgg CAS authentication
* 
* @package cas_auth
* @license http://www.gnu.org/licenses/gpl.html
* @author Xavier Roussel <xavier.roussel@uvsq.fr>
* @copyright UVSQ 2008
* @link http://www.uvsq.fr
*/
?>
<p>
    <fieldset style="border: 1px solid; padding: 15px; margin: 0 10px 0 10px">
        <legend><?php echo elgg_echo('CAS');?></legend>
        
        <label for="params[casurl]"><?php echo elgg_echo('CAS URL');?></label><br/>
        <input type="text" name="params[casurl]" value="<?php echo $vars['entity']->casurl;?>" /><br/>
        
				<label for="params[casport]"><?php echo elgg_echo('CAS PORT');?></label><br/>
        <input type="text" name="params[casport]" value="<?php echo $vars['entity']->casport;?>" /><br/>

				<label for="params[casuri]"><?php echo elgg_echo('CAS URI');?></label><br/>
        <input type="text" name="params[casuri]" value="<?php echo $vars['entity']->casuri;?>" /><br/>
    </fieldset>
</p>