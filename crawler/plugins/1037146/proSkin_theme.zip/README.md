Proskin

 
 proSkin_theme 1.0(Black & White) for elgg 1.8




Thank you for choosing the proSkin_theme.

Notes:
This theme is based on the "facebook_theme" & Designed and developed by Saeid Iltork.



Features

* Nice and simple
* Filtering content on the home page
* Add widgets to profile page


by Saeid iltork

facebook.com/iltork  |  http://proskin.webs.com//

