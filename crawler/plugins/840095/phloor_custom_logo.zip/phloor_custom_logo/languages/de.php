<?php
/*****************************************************************************
 * Phloor Logo                                                               *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php

$german = array(
	'admin:appearance:phloor_custom_logo' => 'Logo',

	'phloor_custom_logo:title' => "Logo Upload",

	'phloor_custom_logo:description' => "Hier können Sie ein eigenes Logo hochladen. Unterstütze Mimetypes sind 'image/gif', 'image/jpg', 'image/jpeg', 'image/pjpeg' und 'image/png'. ",

	'phloor_custom_logo:save:success' => 'Einstellungen erfolgreich gespeichert. ',
	'phloor_custom_logo:save:failure' => 'Einstellungen konnten nicht gespeichert werden. ',

	'phloor_custom_logo:form:section:logo' => 'Logo',

	'phloor_custom_logo:logo:label' => 'Laden Sie Ihr Logo hoch',
	'phloor_custom_logo:logo:description' => 'Wählen Sie die Datei die Sie als Logo einstellen wollen. Um in den Header der Seite zu passen, wählen Sie bitte eine geeignete Größe für das Logo. ',

	'phloor_custom_logo:delete:label' => 'Logo entfernen',
	'phloor_custom_logo:delete:description' => 'Bei Aktivierung dieser Checkbox wird das momentane Logo entfernt. ',

	'phloor_custom_logo:logodircreated' => "Das Verzeichnis 'logo/' wurde im Daten-Ordner angelegt. ",
	'phloor_custom_logo:couldnotcreatelogodir' => "Der Ordner 'logo/' konnte im Daten-Verzeichnis nicht angelegt werden. ",
	'phloor_custom_logo:coultnotmoveuploadedfile' => "Die Datei konnte nicht in das Verzeichnis 'logo/' im Daten-Ordner verschoben werden. ",

	'phloor_custom_logo:upload_error' => "Upload Fehler: %s ",
	'phloor_custom_logo:logo_mime_type_not_supported' => "Der Mimetype der Datei ('%s') wird nicht unterstützt. Bitte benützen Sie 'image/gif','image/jpg','image/jpeg','image/pjpeg' oder 'image/png'. ",

);

add_translation("de", $german);
