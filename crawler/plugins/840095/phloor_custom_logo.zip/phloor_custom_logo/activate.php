<?php

if (get_subtype_id('object', 'phloor_logo')) {
	update_subtype('object', 'phloor_logo', 'PhloorLogo');
} else {
	add_subtype('object', 'phloor_logo', 'PhloorLogo');
}
