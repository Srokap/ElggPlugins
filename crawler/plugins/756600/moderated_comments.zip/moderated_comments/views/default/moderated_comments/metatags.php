<link rel="stylesheet" href="<?php echo $vars['url']; ?>mod/moderated_comments/lib/style.css" type="text/css" />
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/moderated_comments/lib/javascript.js"></script>
