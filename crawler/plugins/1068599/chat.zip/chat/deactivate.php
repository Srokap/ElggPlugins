<?php
/**
 * Deregister the ElggChat class
 */

update_subtype('object', 'chat');