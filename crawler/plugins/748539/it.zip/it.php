<?php
/**
 * Italian Core language file
 * 
 * @package Elgg 1.7.6
 * @subpackage Core
 * 
 * @By: Italian Support Group for Elgg
 * @Credit: lord55 from www.noelab.com
 * @Credit: mic from www.socialbusinessworld.org
 */

$italian = array(

/**
 * Sites
 */

	'item:site' => 'Siti',

/**
 * Sessions
 */

	'login' => "Entra",
	'loginok' => "Sei entrato.",
	'loginerror' => "Non possiamo farti entrare. Questo può accadere perchè non hai ancora validato il tuo account, le credenziali che hai fornito erano sbagliate, o hai fatto troppi tentativi di accesso errati. Assicurati che le tue credenziali siano corrette e per favore riprova.",

	'logout' => "Esci",
	'logoutok' => "Sei uscito.",
	'logouterror' => "Non possiamo farti uscire. Per favore riprova.",

	'loggedinrequired' => "Devi entrare per visualizzare quella pagina.",
	'adminrequired' => "Devi essere un amministratore per visualizzare quella pagina.",
	'membershiprequired' => "Devi essere un membro di questo gruppo per visualizzare quella pagina.",


/**
 * Errors
 */
	'exception:title' => "Benvenuto su Elgg.",

	'InstallationException:CantCreateSite' => "Inabilitati a creare un SitoElgg principale con le credenziali Nome:%s, Url: %s",

	'actionundefined' => "L'azione che è stata richiesta(%s) non è definita nel sistema.",
	'actionloggedout' => "Scusaci, non puoi compiere questa azione mentre non sei autenticato.",
	'actionunauthorized' => 'Non sei autorizzato a compiere questa operazione',

	'SecurityException:Codeblock' => "Accesso negato ad eseguire il blocco di codice privilegiato",
	'DatabaseException:WrongCredentials' => "Elgg non può connettersi al database usando le credenziali.",
	'DatabaseException:NoConnect' => "Elgg non può selezionare il database '%s', per favore verifica che il database è stato creato ed che hai accesso ad esso.",
	'SecurityException:FunctionDenied' => "L'accesso alla funzione privilegiata '%s' è negato.",
	'DatabaseException:DBSetupIssues' => "Ci sono stati un numero di problemi: ",
	'DatabaseException:ScriptNotFound' => "Elgg non può trovare lo script del database richiesto su %s.",

	'IOException:FailedToLoadGUID' => "Fallito il caricamento del nuovo %s da GUID:%d",
	'InvalidParameterException:NonElggObject' => "Passaggio di un non-ElggObject a un costruttore ElggObject!",
	'InvalidParameterException:UnrecognisedValue' => "Valore non riconosciuto passato al costruttore.",

	'InvalidClassException:NotValidElggStar' => "GUID:%d non è un valido %s",

	'PluginException:MisconfiguredPlugin' => "%s è un plugin non configurato. E' stato disabilitato.  Per favore ricerca sul wiki di Elgg per le possibili cause (http://docs.elgg.org/wiki/).",

	'InvalidParameterException:NonElggUser' => "Passaggio di un non-ElggUser a un costruttore ElggUser!",

	'InvalidParameterException:NonElggSite' => "Passaggio di un non-ElggSite a un costruttore ElggSite!",

	'InvalidParameterException:NonElggGroup' => "Passaggio di un non-ElggGroup a un costruttore ElggGroup!",

	'IOException:UnableToSaveNew' => "Inabilitato a salvare il nuovo %s",

	'InvalidParameterException:GUIDNotForExport' => "Il GUID non è stato specificato durante l'esportazione, questo non dovrebbe accadere mai.",
	'InvalidParameterException:NonArrayReturnValue' => "La funzione di serializzazione dell'entità è stata passata a un parametro di non-array returnvalue",

	'ConfigurationException:NoCachePath' => "Settaggio della cartella Cache invalido!",
	'IOException:NotDirectory' => "%s non è una directory.",

	'IOException:BaseEntitySaveFailed' => "Impossibile salvare il nuovo oggetto di informazione entità di base!",
	'InvalidParameterException:UnexpectedODDClass' => "importazione() passata a una inaspettata classe ODD",
	'InvalidParameterException:EntityTypeNotSet' => "Deve essere settato il tipo di entità.",

	'ClassException:ClassnameNotClass' => "%s non è un %s.",
	'ClassNotFoundException:MissingClass' => "La classe '%s' non è stata trovata, plugin mancante?",
	'InstallationException:TypeNotSupported' => "Il tipo %s non è supportato. Questo indica un errore nella tua installazione, molto probabilmente causato da un aggiornamento incompleto.",

	'ImportException:ImportFailed' => "Non è possibile importare l'elemento %d",
	'ImportException:ProblemSaving' => "C'era un problema ad importare %s",
	'ImportException:NoGUID' => "Una nuova entità è stata creata ma non ha un GUID, questo non dovrebbe accadere.",

	'ImportException:GUIDNotFound' => "L'entità '%d' non può essere trovata.",
	'ImportException:ProblemUpdatingMeta' => "C'era un problema ad aggiornare '%s' sull'entità '%d'",

	'ExportException:NoSuchEntity' => "Nessuna entità GUID simile:%d",

	'ImportException:NoODDElements' => "Nessun elemento OpenDD è stato trovato nell'importazione dei dati, l'importazione è fallita.",
	'ImportException:NotAllImported' => "Non tutti gli elementi sono stati importati.",

	'InvalidParameterException:UnrecognisedFileMode' => "Modalità file non riconosciuta '%s'",
	'InvalidParameterException:MissingOwner' => "Il File %s (file guid:%d) (owner guid:%d) manca di un proprietario!",
	'IOException:CouldNotMake' => "Non si può fare %s",
	'IOException:MissingFileName' => "Devi specificare un nome prima di aprire un file.",
	'ClassNotFoundException:NotFoundNotSavedWithFile' => "Inabilitati a caricare la classe del deposito dei file %s per il file %u",
	'NotificationException:NoNotificationMethod' => "Nessun metodo di notificazione è stato specificato.",
	'NotificationException:NoHandlerFound' => "No handler found for '%s' or it was not callable.",
	'NotificationException:ErrorNotifyingGuid' => "C'era un problema nel notificare %d",
	'NotificationException:NoEmailAddress' => "Non posso ottenere l'indirizzo email per il GUID:%d",
	'NotificationException:MissingParameter' => "Manca un parametro richiesto, '%s'",

	'DatabaseException:WhereSetNonQuery' => "Il settaggio non contiene WhereQueryComponent",
	'DatabaseException:SelectFieldsMissing' => "Campi mancanti sullo stile di query selettiva",
	'DatabaseException:UnspecifiedQueryType' => "Tipo di query non riconosciuta o non specificata.",
	'DatabaseException:NoTablesSpecified' => "Nessuna tabella specificata per la query.",
	'DatabaseException:NoACL' => "Nessun controllo di accesso è stato fornito sulla query",

	'InvalidParameterException:NoEntityFound' => "Nessuna entità trovata, può non esistere o non hai accesso ad essa.",

	'InvalidParameterException:GUIDNotFound' => "GUID:%s non può essere trovato, o non puoi accedere ad esso.",
	'InvalidParameterException:IdNotExistForGUID' => "Scusaci, '%s' non esiste per il GUID:%d",
	'InvalidParameterException:CanNotExportType' => "Scusaci, non sappiamo come esportare '%s'",
	'InvalidParameterException:NoDataFound' => "Non è possibile trovare alcun dato.",
	'InvalidParameterException:DoesNotBelong' => "Non appartiene all'entità.",
	'InvalidParameterException:DoesNotBelongOrRefer' => "Non appartiene all'entità o non si riferisce all'entità.",
	'InvalidParameterException:MissingParameter' => "Parametro mancante, devi fornire un GUID.",

	'APIException:ApiResultUnknown' => "Il Risultato API è di un tipo sconosciuto, questo non dovrebbe mai accadere.",
	'ConfigurationException:NoSiteID' => "Nessun sito ID è stato specificato.",
	'SecurityException:APIAccessDenied' => "Scusaci, l'accesso all'API è stato disbilitato dall'amministratore.",
	'SecurityException:NoAuthMethods' => "Non è stato trovato nessun metodo di autenticazione che potrebbe autenticare questa richiesta API.",
	'InvalidParameterException:APIMethodOrFunctionNotSet' => "Metodo o funzione non settata nella chiamata in expose_method()",
	'InvalidParameterException:APIParametersArrayStructure' => "La struttura dei parametri array non è corretta per le chiamate al metodo esibito '%s'",
	'InvalidParameterException:UnrecognisedHttpMethod' => "Unrecognised http method %s for api method '%s'",
	'APIException:MissingParameterInMethod' => "Parametro mancante %s nel metodo %s",
	'APIException:ParameterNotArray' => "%s non sembra essere un array.",
	'APIException:UnrecognisedTypeCast' => "Tipo non riconosciuto nel forma %s per la variabile '%s' nel metodo '%s'",
	'APIException:InvalidParameter' => "Trovato parametro invalido per '%s' nel metodo '%s'.",
	'APIException:FunctionParseError' => "%s(%s) ha un errore di parsing.",
	'APIException:FunctionNoReturn' => "%s(%s) ha risposto con nessun valore.",
	'APIException:APIAuthenticationFailed' => "Il metodo di chiamata ha fallito l'Autenticazione API",
	'APIException:UserAuthenticationFailed' => "Il metodo di chiamata ha fallito l'Autenticazione User",
	'SecurityException:AuthTokenExpired' => "Token di autenticazione mancante , invalido o scaduto.",
	'CallException:InvalidCallMethod' => "%s deve essere chiamato usando '%s'",
	'APIException:MethodCallNotImplemented' => "Metodo di chiamata '%s' non è stato implementato.",
	'APIException:FunctionDoesNotExist' => "La funzione per il metodo '%s' non è collocabile",
	'APIException:AlgorithmNotSupported' => "Algoritmo '%s' non è supportato o è stato disabilitato.",
	'ConfigurationException:CacheDirNotSet' => "La directory di Cache 'cache_path' non è settata.",
	'APIException:NotGetOrPost' => "Il metodo richiesto deve essere GET o POST",
	'APIException:MissingAPIKey' => "API key mancante",
	'APIException:BadAPIKey' => "API key non corretta",
	'APIException:MissingHmac' => "X-Elgg-hmac header mancante",
	'APIException:MissingHmacAlgo' => "X-Elgg-hmac-algo header mancante",
	'APIException:MissingTime' => "X-Elgg-time header mancante",
	'APIException:MissingNonce' => "X-Elgg-nonce header mancante",
	'APIException:TemporalDrift' => "X-Elgg-time non è troppo lontano nel passato o futuro. Epoca fallita.",
	'APIException:NoQueryString' => "Nessun dato sulla stringa di query",
	'APIException:MissingPOSTHash' => "X-Elgg-posthash header mancante",
	'APIException:MissingPOSTAlgo' => "X-Elgg-posthash_algo header mancante",
	'APIException:MissingContentType' => "Tipo di contenuto per il post data mancante",
	'SecurityException:InvalidPostHash' => "POST data hash is invalido - Vuole %s ma si ha %s.",
	'SecurityException:DupePacket' => "Firma del pacchetto già visto.",
	'SecurityException:InvalidAPIKey' => "API Key invalida o mancante.",
	'NotImplementedException:CallMethodNotImplemented' => "Il metodo di chiamata '%s' non è attualmente supportato.",

	'NotImplementedException:XMLRPCMethodNotImplemented' => "Il metodo di chiamata XML-RPC '%s' non è stato implementato.",
	'InvalidParameterException:UnexpectedReturnFormat' => "La chiamata al metodo '%s' ha fatto ritornare un risultato inaspettato.",
	'CallException:NotRPCCall' => "La chiamata non sembra essere una valida chiamata XML-RPC",

	'PluginException:NoPluginName' => "Il nome del Plugin installato non può essere trovato",

	'ConfigurationException:BadDatabaseVersion' => "Il backend del database che hai installato non incontra le condizioni di base per far funzionare Elgg. Per favore consulta la tua documentazione.",
	'ConfigurationException:BadPHPVersion' => "Necessiti almeno della versione PHP version 5.2 per far funzionare Elgg.",
	'configurationwarning:phpversion' => "richiede almeno PHP versione 5.2, puoi installarlo sulla versione 5.1.6 ma alcune caratteristiche potrebbero non funzionare. L'utilizzo è a proprio rischio.",


	'InstallationException:DatarootNotWritable' => "La tua cartella dati %s non è scrivibile.",
	'InstallationException:DatarootUnderPath' => "La tua cartella dati %s deve stare fuori dal tuo percorso di installazione.",
	'InstallationException:DatarootBlank' => "Non hai specificato una cartella dati.",

	'SecurityException:authenticationfailed' => "L'utente non può essere autenticato",

	'CronException:unknownperiod' => '%s non è un periodo riconosciuto.',

	'SecurityException:deletedisablecurrentsite' => 'Non puoi cancellare o disabilitare il sito che stai visualizzando ora!',

	'RegistrationException:EmptyPassword' => 'I campi password non possono essere vuoti',
	'RegistrationException:PasswordMismatch' => 'Le Password devono essere identiche',

	'memcache:notinstalled' => 'Il modulo PHP memcache non è istallato, devi installare php5-memcache',
	'memcache:noservers' => 'Nessuna memcache servers definita, per favore inserisci la variabile di $CONFIG->memcache_servers',
	'memcache:versiontoolow' => 'Memcache necessita almeno della versione %s per funzionare, stai funzionando con %s',
	'memcache:noaddserver' => 'Il supporto Server Multiplo è disabilitato, devi aggiornare la tua libreria PECL memcache',

	'deprecatedfunction' => 'Attenzione: Questo codice utilizza una funzione deprecata \'%s\' e non è compatibile con questa versione di Elgg',

	'pageownerunavailable' => 'Attenzione: La pagina del proprietario %d non è accessibile!',
	'changebookmark' => 'Per favore cambia il Segnalibro per questa pagina',
/**
 * API
 */
	'system.api.list' => "Elenca tutte le chiamate delle API disponibili sul sito.",
	'auth.gettoken' => "Questa chiamata API permette ad un utente di ottenere un token di autenticazione utente che può essere usata per future autenticazioni di chiamata API. Passarla come parametro auth_token",

/**
 * User details
 */

	'name' => "Nome Pubblico",
	'email' => "Indirizzo Email",
	'username' => "Nome utente",
	'password' => "Password",
	'passwordagain' => "Password (di nuovo per la verifica)",
	'admin_option' => "Nomina Amministratore questo utente?",

/**
 * Access
 */

	'PRIVATE' => "Privato",
	'LOGGED_IN' => "Membri",
	'PUBLIC' => "Pubblico",
	'access:friends:label' => "Amici",
	'access' => "Accesso",

/**
 * Dashboard and widgets
 */

	'dashboard' => "Dashboard",
	'dashboard:configure' => "Modifica pagina",
	'dashboard:nowidgets' => "La Dashboard è la tua porta d'ingresso nel sito. Clicca su 'Modifica pagina' per aggiungere i Widget che ti permetteranno di tenere traccia di tutte le interazioni dentro il sistema.",

	'widgets:add' => 'Aggiungi i Widget alla tua pagina.',
	'widgets:add:description' => "Scegli le caratteristiche che vorresti aggiungere alla tua pagina personale spostando i Widget dalla <b>Galleria-Widget</b> (qui a destra), su una delle tre Aree-Widget qui sotto e posizionali dove vorresti farli apparire.

Per rimuovere un Widget, riportalo indietro nella <b>Galleria-Widget</b>.",
	'widgets:position:fixed' => '(Posizione bloccata sulla pagina)',

	'widgets' => "I Widget",
	'widget' => "Widget",
	'item:object:widget' => "Widgets",
	'layout:customise' => "Personalizza la grafica",
	'widgets:gallery' => "Galleria-Widget",
	'widgets:leftcolumn' => "Sinistra-Area Widget",
	'widgets:fixed' => "Posizione sistemata",
	'widgets:middlecolumn' => "Centro-Area Widget",
	'widgets:rightcolumn' => "Destra-Area Widget",
	'widgets:profilebox' => "Modulo profilo",
	'widgets:panel:save:success' => "Il tuo Widget è stato salvato con successo.",
	'widgets:panel:save:failure' => "si è verificato un problema nel salvataggio del tuo Widget. Per favore riprova.",
	'widgets:save:success' => "Il Widget è stato salvato con successo.",
	'widgets:save:failure' => "Non possiamo salvare il tuo widget. Per favore riprova.",
	'widgets:handlernotfound' => 'Questo widget può essere entrambi rotto o è stato disabilitato dall\'Amminnistratore del sito.',
	
/**
 * Groups
 */

	'group' => "Gruppo", 
	'item:group' => "Gruppi",

/**
 * Users
 */

	'user' => "Utente",
	'item:user' => "Utenti",

/**
 *  INIZIO SECONDA PARTE /////////////////////////////////////////////////////////////////////////////
 */	
	
/**
 * Friends
 */

	'friends' => "Amici",
	'friends:yours' => "Tuoi Amici",
	'friends:owned' => "Amici di %s",
	'friend:add' => "Aggiungi Amico",
	'friend:remove' => "Rimuovi Amico",

	'friends:add:successful' => "Hai aggiunto con successo %s come amico.",
	'friends:add:failure' => "Non possiamo aggiungere %s come amico. Per favore riprova.",

	'friends:remove:successful' => "Hai rimosso con successo %s dai tuoi amici.",
	'friends:remove:failure' => "Non possiamo rimuovere %s dai tuoi amici. Per favore riprova.",

	'friends:none' => "Questo utente non ha ancora aggiunto nessuno come amico.",
	'friends:none:you' => "Non hai aggiunto nessuno come amico! Cerca il tuo interesse per iniziare la ricerca delle persone da seguire.",

	'friends:none:found' => "Nessun amico è stato trovato.",

	'friends:of:none' => "Nessuno ha ancora aggiunto questo utente come amico.",
	'friends:of:none:you' => "Ancora nessuno ti ha aggiunto come amico. Inizia ad aggiungere un contenuto e a compilare il proprio profilo per permettere alle persone di trovarti!",

	'friends:of:owned' => "Persone che hanno fatto %s come amico",

	'friends:of' => "Amici di",
	'friends:collections' => "Collezione di amici",
	'friends:collections:add' => "Nuova collezione di amici",
	'friends:addfriends' => "Aggiungi amici",
	'friends:collectionname' => "Nome della collezione",
	'friends:collectionfriends' => "Amici nella collezione",
	'friends:collectionedit' => "Modifica questa collezione",
	'friends:nocollections' => "Non hai ancora nessuna collezione.",
	'friends:collectiondeleted' => "La tua colllezione è stata cancellata.",
	'friends:collectiondeletefailed' => "Non siamo abilitati a cancellare questa collezione. O non hai il permesso, o si è verificato qualche altro problema.",
	'friends:collectionadded' => "La tua collezione è stata creata con successo",
	'friends:nocollectionname' => "Necessiti di dare una nome alla tua collezione prima che essa possa essere creata.",
	'friends:collections:members' => "Collezione dei membri",
	'friends:collections:edit' => "Modifica collezione",

	'friends:river:add' => "%s è ora amico con",

	'friendspicker:chararray' => 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',

/**
 * Feeds
 */
	'feed:rss' => 'Sottoscriviti al feed',
	'feed:odd' => 'Syndicate OpenDD',

/**
 * links
 **/

	'link:view' => 'vedi link',


/**
 * River
 */
	'river' => "River",
	'river:relationship:friend' => 'è ora amico con',
	'river:noaccess' => 'Non hai il permesso di visualizzare questa voce.',
	'river:posted:generic' => '%s ha inviato',
	'riveritem:single:user' => 'un utente',
	'riveritem:plural:user' => 'alcuni utenti',

/**
 * Plugins
 */
	'plugins:settings:save:ok' => "I settaggi per il plugin %s sono stati salvati con successo.",
	'plugins:settings:save:fail' => "C'è stato un problema nel salvare i settaggi per il plugin %s.",
	'plugins:usersettings:save:ok' => "I settaggi utente per il plugin %s sono stati salvati con successo.",
	'plugins:usersettings:save:fail' => "C'è stato un problema nel salvare i settaggi dell'utente per il plugin %s.",
	'admin:plugins:label:version' => "Versione",
	'item:object:plugin' => 'Configurazione dei settaggi del plugin',

/**
 * Notifications
 */
	'notifications:usersettings' => "Settaggi delle notifiche",
	'notifications:methods' => "Per favore specifica quale metodo vuoi permettere.",

	'notifications:usersettings:save:ok' => "I tuoi settaggi di notifica sono stati salvati con successo.",
	'notifications:usersettings:save:fail' => "C'è stato un problema nel salvare i tuoi settaggi di notifica.",

	'user.notification.get' => 'Riporta i settaggi di notifica per un dato utente.',
	'user.notification.set' => 'Setta i settaggi di notifica per un dato utente.',
/**
 * Search
 */

	'search' => "Cerca",
	'searchtitle' => "Cerca: %s",
	'users:searchtitle' => "Ricerca per utenti: %s",
	'groups:searchtitle' => "Ricerca per gruppi: %s",
	'advancedsearchtitle' => "%s cone risultati trovati %s",
	'notfound' => "Nessun risultato trovato.",
	'next' => "Successivo",
	'previous' => "Precedente",

	'viewtype:change' => "Cambia la modalità lista",
	'viewtype:list' => "Modalità lista",
	'viewtype:gallery' => "Galleria",

	'tag:search:startblurb' => "Voci con tag trovati '%s':",

	'user:search:startblurb' => "Utenti trovati '%s':",
	'user:search:finishblurb' => "Per visualizzare altro, clicca qui.",

	'group:search:startblurb' => "Gruppi trovati '%s':",
	'group:search:finishblurb' => "Per visualizzare altro, clicca qui.",
	'search:go' => 'Vai',
	'userpicker:only_friends' => 'Solo Amici',

/**
 * Account
 */

	'account' => "Account",
	'settings' => "Settaggi",
	'tools' => "Strumenti",
	'tools:yours' => "Tuoi Strumenti",

	'register' => "Registrati",
	'registerok' => "Ti sei registrato con successo per %s.",
	'registerbad' => "La tua registrazione non ha avuto successo. Lo username può esistere già, le tue passwords possono non coincidere, o il tuo username o password può essere troppo corta.",
	'registerdisabled' => "La registrazione è stata disabilitata dall'amministratore del sistema",

	'firstadminlogininstructions' => 'Il tuo nuovo sito Elgg è stato installato con successo e il tuo account di amministratore è stato creato con successo. Puoi ora ulteriormente configurare il tuo sito abilitando i vari strumenti di plugin installati.',

	'registration:notemail' => 'L\'indirizzo email che hai fornito non sembra essere un valido indirizzo email.',
	'registration:userexists' => 'Quel nome utente già esiste',
	'registration:usernametooshort' => 'Il tuo nome utente deve essere lungo di un minimo di 4 caratteri.',
	'registration:passwordtooshort' => 'La password deve essere lunga di un minimo di 6 caratteri.',
	'registration:dupeemail' => 'Questo indirizzo email è stato già registrato.',
	'registration:invalidchars' => 'Scusaci, il tuo nome utente contiene i seguente caratteri invalidi: %s.  Tutti questi caratteri sono invalidi: %s',
	'registration:emailnotvalid' => 'Scusaci, l\'indirizzo email che hai inserito è invalido su questo sistema',
	'registration:passwordnotvalid' => 'Scusaci, la password che hai inserito è invalida su questo sistema',
	'registration:usernamenotvalid' => 'Scusaci, il nome utente che hai inserito è invalido su questo sistema',

	'adduser' => "Aggiungi Utente",
	'adduser:ok' => "Hai aggiunto con successo un nuovo utente.",
	'adduser:bad' => "Il nuovo utente non può essere creato.",

	'item:object:reported_content' => "Voci riportate",

	'user:set:name' => "Settaggi del nome account",
	'user:name:label' => "Il tuo nome",
	'user:name:success' => "Il tuo nome è stato cambiato con successo sul sistema.",
	'user:name:fail' => "Non è possibile cambiare il tuo nome sul sistema.  Per favore accertati che il tuo nome non sia troppo lungo e prova di nuovo.",

	'user:set:password' => "Account password",
	'user:current_password:label' => 'Password corrente',
	'user:password:label' => "La tua nuova password",
	'user:password2:label' => "La tua nuova password di nuovo",
	'user:password:success' => "Password cambiata",
	'user:password:fail' => "Non puoi cambiare la tua password sul sistema.",
	'user:password:fail:notsame' => "Le due password non sono uguali!",
	'user:password:fail:tooshort' => "Password è troppo corta!",
	'user:password:fail:incorrect_current_password' => 'La password corrente non è valida.',
	'user:resetpassword:unknown_user' => 'Utente invalido.',
	'user:resetpassword:reset_password_confirm' => 'Resetta la tua password ti sarà inviata una email con la nuova password all\'indirizzo email registrato.',

	'user:set:language' => "Settaggi della lingua",
	'user:language:label' => "La tua lingua",
	'user:language:success' => "I settaggi della tua lingua sono stati aggiornati.",
	'user:language:fail' => "I settaggi della tua lingua non possono essere aggoirnati.",

	'user:username:notfound' => 'Nome utente %s non trovato.',

	'user:password:lost' => 'Password smarrita',
	'user:password:resetreq:success' => 'Nuova password richiesta con successo, email inviata',
	'user:password:resetreq:fail' => 'Non puoi richiedere una nuova password.',

	'user:password:text' => 'Per generare una nuova password, inserisci il tuo nome utente qui sotto. Ti invieremo l\'indirizzo di una pagina di verifica univoca via email. Clicca il link nel corpo del messaggio e una nuova passwprd ti sarà inviata.',

	'user:persistent' => 'Ricordati',
/**
 * Administration
 */

	'admin:configuration:success' => "I tuoi settaggi sono stati salvati.",
	'admin:configuration:fail' => "I tuoi settaggi non possono essere salvati.",

	'admin' => "Amministrazione",
	'admin:description' => "Il pannello amministrativo ti permette di controllare tutti gli aspetti del tuo sistema, dalla gestione utente a come i devo essere i tuoi plugin. Scegli una opzione qui sotto per iniziare.",

	'admin:user' => "Amministrazione utente",
	'admin:user:description' => "Questo pannello amministrativo ti permette di controllare i settaggi per lutente per il tuo sito. Scegli una opzione qui sotto per iniziare.",
	'admin:user:adduser:label' => "Clicca qui per aggiungere un nuovo utente...",
	'admin:user:opt:linktext' => "Configura utenti...",
	'admin:user:opt:description' => "Configura utenti e i dati account. ",

	'admin:site' => "Amministrazione sito",
	'admin:site:description' => "Questo pannello amministrativo ti permette di controllare i settaggi globali del tuo sito. Scegli una opzione qui sotto per iniziare.",
	'admin:site:opt:linktext' => "Configura sito...",
	'admin:site:opt:description' => "Configurai settaggi tecnici and non-tecnici del tuo sito. ",
	'admin:site:access:warning' => "Modificando il settaggio di accesso ha solo effetto sui permessi dei contenuti creati nel futuro.",

	'admin:plugins' => "Amministrazione strumenti",
	'admin:plugins:description' => "Questo pannello amministrativo ti permette di controllare e configurare gli strumenti sul tuo sito.",
	'admin:plugins:opt:linktext' => "Configura strumenti...",
	'admin:plugins:opt:description' => "Configura gli strumenti installati sul sito. ",
	'admin:plugins:label:author' => "Autore",
	'admin:plugins:label:copyright' => "Copyright",
	'admin:plugins:label:licence' => "Licenza",
	'admin:plugins:label:website' => "URL",
	'admin:plugins:label:moreinfo' => 'più info',
	'admin:plugins:label:version' => 'Versione',
	'admin:plugins:warning:elggversionunknown' => 'Attenzione: Questo plugin non specifica una versione compatibile di Elgg.',
	'admin:plugins:warning:elggtoolow' => 'Attenzione: Questo plugin necessita l\'ultima versione di Elgg!',
	'admin:plugins:reorder:yes' => "Plugin %s è stato riordinato con successo.",
	'admin:plugins:reorder:no' => "Plugin %s non può essere riordinato.",
	'admin:plugins:disable:yes' => "Plugin %s è stato disabilitato con successo.",
	'admin:plugins:disable:no' => "Plugin %s non può essere disabilitato.",
	'admin:plugins:enable:yes' => "Plugin %s è stato abilitato con successo.",
	'admin:plugins:enable:no' => "Plugin %s non può essere abilitato.",

	'admin:statistics' => "Statistiche",
	'admin:statistics:description' => "Questa è una panoramica delle statistiche sul tuo sito. Se avete bisogno di statistiche più dettagliate, è disponibile una funzione di amministrazione professionale.",
	'admin:statistics:opt:description' => "Visualizza informazioni statisticeh su utenti e oggetti sul tuo sito.",
	'admin:statistics:opt:linktext' => "Visualzza statistiche...",
	'admin:statistics:label:basic' => "Statistiche base del sito",
	'admin:statistics:label:numentities' => "Entità sul sito",
	'admin:statistics:label:numusers' => "Numero di utenti",
	'admin:statistics:label:numonline' => "Numero di utenti online",
	'admin:statistics:label:onlineusers' => "Utenti online ora",
	'admin:statistics:label:version' => "Elgg versione",
	'admin:statistics:label:version:release' => "Release",
	'admin:statistics:label:version:version' => "Versione",

	'admin:user:label:search' => "Trova utenti:",
	'admin:user:label:searchbutton' => "Cerca",

	'admin:user:ban:no' => "Non può bannare l'utente",
	'admin:user:ban:yes' => "Utente bannato.",
	'admin:user:unban:no' => "Non puoi non bannare l'utente",
	'admin:user:unban:yes' => "Utente non bannato.",
	'admin:user:delete:no' => "Non può cancellare l'utente",
	'admin:user:delete:yes' => "L'utente %s è stato cancellato",

	'admin:user:resetpassword:yes' => "Password risettata, utente avvisato.",
	'admin:user:resetpassword:no' => "Password non può essere risettata.",

	'admin:user:makeadmin:yes' => "L'utente è ora un amministratore.",
	'admin:user:makeadmin:no' => "Non possiamo eleggere questo utente come amministratore.",

	'admin:user:removeadmin:yes' => "L'utente non è più un amministratore.",
	'admin:user:removeadmin:no' => "Non possiamo rimuovere i privilegi di amministratore per questo utento.",

/**
 * User settings
 */
	'usersettings:description' => "Il pannello settaggi utenti ti permette di controllare tutti i settaggi personali, dalla gestione degli utenti a come configurare i plugin. Scegli un'opzione qui sotto per iniziare.",

	'usersettings:statistics' => "Le tue statistiche",
	'usersettings:statistics:opt:description' => "Visualizza l\'informazione statistica sugli utenti e gli oggetti nel tuo sito.",
	'usersettings:statistics:opt:linktext' => "Statistiche dell\'account",

	'usersettings:user' => "I tuoi settaggi",
	'usersettings:user:opt:description' => "Questo ti permette di controllare i settaggi dell\'utente.",
	'usersettings:user:opt:linktext' => "Cambia i tuoi settaggi",

	'usersettings:plugins' => "Strumenti",
	'usersettings:plugins:opt:description' => "Configura i settaggi (se esistono) per i tuoi strumenti attivi.",
	'usersettings:plugins:opt:linktext' => "Configura i tuoi strumenti",

	'usersettings:plugins:description' => "Questo pannello ti permette di controllare e configurare i settaggi personali per gli strumenti installati dal tuo amministratore del sistema.",
	'usersettings:statistics:label:numentities' => "Il tuo contenuto",

	'usersettings:statistics:yourdetails' => "I tuoi dettagli",
	'usersettings:statistics:label:name' => "Nome completo",
	'usersettings:statistics:label:email' => "Email",
	'usersettings:statistics:label:membersince' => "Membro dal",
	'usersettings:statistics:label:lastlogin' => "Ultimo accesso",

/**
 *  INIZIO TERZA PARTE /////////////////////////////////////////////////////////////////////////////
 */ 

/**
 * Generic action words
 */

	'save' => "Salva",
	'publish' => "Pubblica",
	'cancel' => "Elimina",
	'saving' => "Salvataggio...",
	'update' => "Aggiorna",
	'edit' => "Modifica",
	'delete' => "Cancella",
	'accept' => "Accetta",
	'load' => "Carica",
	'upload' => "Carica",
	'ban' => "Blocca",
	'unban' => "Sblocca",
	'enable' => "Abilita",
	'disable' => "Disabilita",
	'request' => "Richiesta",
	'complete' => "Completato",
	'open' => 'Apri',
	'close' => 'Chiudi',
	'reply' => "Rispondi",
	'more' => 'Continua',
	'comments' => 'Commenti',
	'import' => 'Importa',
	'export' => 'Esporta',
	'untitled' => 'Senza titolo',
	'help' => 'Aiuto',
	'send' => 'Invia',
	'post' => 'Pubblica',
	'submit' => 'Invia',
	'site' => 'Sito',

	'up' => 'Su',
	'down' => 'Giù',
	'top' => 'Inizio',
	'bottom' => 'Fine',

	'invite' => "Invita",

	'resetpassword' => "Modifica la password",
	'makeadmin' => "Rendi amministratore",
	'removeadmin' => "Rimuovi amministratore",

	'option:yes' => "Si",
	'option:no' => "No",

	'unknown' => 'Sconosciuto',

	'active' => 'Attivo',
	'total' => 'Totale',

	'learnmore' => "Clicca qui per maggiori info.",

	'content' => "contenuto",
	'content:latest' => 'Attività recenti',
	'content:latest:blurb' => 'In alternativa, clicca qui per leggere gli ultimi contenuti inseriti nel sito.',

	'link:text' => 'segui il link',

	'enableall' => 'Abilita tutto',
	'disableall' => 'Disabilita tutto',

/**
 * Generic questions
 */

	'question:areyousure' => 'Sei sicuro/a?',

/**
 * Generic data words
 */

	'title' => "Titolo",
	'description' => "Descrizione",
	'tags' => "Tags",
	'spotlight' => "In evidenza",
	'all' => "Tutto",

	'by' => 'di',

	'annotations' => "Annotazioni",
	'relationships' => "Relazioni",
	'metadata' => "Metadata",

/**
 * Input / output strings
 */

	'deleteconfirm' => "Sei sicuro/a di voler cancellare questo elemento?",
	'fileexists' => "Un file è già stato caricato. Per sostituirlo, selezionare in basso:",

/**
 * User add
 */

	'useradd:subject' => 'Account utente creato',
	'useradd:body' => '
%s,

Un account utente è stato creato per te in %s. Per entrare, visita:

%s

ed effettua l\'accesso con le seguenti credenziali:

Username: %s
Password: %s

Una volta entrato/a ti suggeriamo caldamente di modificare la tua password.
',

/**
 * System messages
 **/

	'systemmessages:dismiss' => "Clicca per chiudere",


/**
 * Import / export
 */
	'importsuccess' => "Importazione dati riuscita",
	'importfail' => "Importazione dati OpenDD fallita.",

/**
 * Time
 */

	'friendlytime:justnow' => "proprio ora",
	'friendlytime:minutes' => "%s minuti fa",
	'friendlytime:minutes:singular' => "un minuto fa",
	'friendlytime:hours' => "%s ore fa",
	'friendlytime:hours:singular' => "un'ora fa",
	'friendlytime:days' => "%s giorni fa",
	'friendlytime:days:singular' => "ieri",
	'friendlytime:date_format' => 'j F Y @ g:ia',

	'date:month:01' => 'Gennaio %s',
	'date:month:02' => 'Febbraio %s',
	'date:month:03' => 'Marzo %s',
	'date:month:04' => 'Aprile %s',
	'date:month:05' => 'Maggio %s',
	'date:month:06' => 'Giugno %s',
	'date:month:07' => 'Luglio %s',
	'date:month:08' => 'Agosto %s',
	'date:month:09' => 'Settembre %s',
	'date:month:10' => 'Ottobre %s',
	'date:month:11' => 'Novembre %s',
	'date:month:12' => 'Dicembre %s',


/**
 * Installation and system settings
 */

	'installation:error:htaccess' => "Elgg necessita del file .htaccess nella root directory di installazione. Si è cercato di crearlo per te ma Elgg non ha permessi sufficienti per scrivere in quella directory.

Crearla � facile: copia il contenuto della casella di testo in basso in un editor di testo e salva il file con il nome .htaccess

",
	'installation:error:settings' => "Elgg non è riuscito a trovare il suo file dei settings. La maggior parte dei settaggi di Elgg verr� effettuata in automatico per te ma devi fornire i dati del tuo database come segue:

1. Rinomina engine/settings.example.php in settings.php nella tua installazione di Elgg.

2. Aprilo con un editor di testo ed inserisci i dati del tuo database MySQL. Se non li conosci, chiedi aiuto al tuo amministratore o al tuo supporto tecnico.

In alternativa, inserisci i dati del tuo database in basso e al resto pensa Elgg...",

	'installation:error:db:title' => "Errori nei settaggi del database",
	'installation:error:db:text' => "Verifica di nuovo i settaggi del tuo database perch� Elgg non � riuscito a connettersi ed accedervi.",
	'installation:error:configuration' => "Una volta corretti gli errori di configurazione, ricarica per riprovare.",

	'installation' => "Installazione",
	'installation:success' => "Database di Elgg installato con successo.",
	'installation:configuration:success' => "I settaggi della configurazione iniziale sono stati salvati con successo. Ora registra l'utente iniziale: questo utente sar� il tuo primo amministratore di sistema.",

	'installation:settings' => "Settaggi del sistema",
	'installation:settings:description' => "Ora che il database di Elgg è stato installato con successo, devi inserire qualche informazione per rendere il tuo sito attivo e pronto. Si � cercato di indovinare dove si � potuto ma <b>dovresti controllare questi dati.</b>",

	'installation:settings:dbwizard:prompt' => "Inserisci i settaggi del tuo database in basso e salva:",
	'installation:settings:dbwizard:label:user' => "Username del database",
	'installation:settings:dbwizard:label:pass' => "Password del database",
	'installation:settings:dbwizard:label:dbname' => "Database Elgg",
	'installation:settings:dbwizard:label:host' => "Nome host del database (di solito 'localhost')",
	'installation:settings:dbwizard:label:prefix' => "Prefisso delle tabelle del database (di solito 'elgg_')",

	'installation:settings:dbwizard:savefail' => "Non è stato possibile salvare il nuovo settings.php. Per favore salva il file seguente con nome engine/settings.php utilizzando un editor di testo.",

	'installation:sitename' => "Il nome del tuo sito (Es. \"Il mio Social Network\"):",
	'installation:sitedescription' => "Breve descrizione del tuo sito (opzionale)",
	'installation:wwwroot' => "L'URL del sito seguito dallo slash:",
	'installation:path' => "Il percorso completo del root del tuo sito sul tuo disco seguito dallo slash:",
	'installation:dataroot' => "Il percorso completo della directory nella quale verranno salvati i file seguito dallo slash:",
	'installation:dataroot:warning' => "Devi creare questa directory manualmente. Dovrebbe trovarsi in una directory diversa da quella dell'installazione di Elgg.",
	'installation:sitepermissions' => "Permessi di accesso di default:",
	'installation:language' => "Lingua di default del tuo sito:",
	'installation:debug' => "La modalità di Debug offre informazioni extra da usare per diagnostiche di errori. Tuttavia potrebbe rallentare il tuo sistema quindi andrebbe usata solo nel caso tu stia avendo problemi con il sito:",
	'installation:debug:none' => 'Disattiva la modalit� debug (raccomandato)',
	'installation:debug:error' => 'Visualizza solo errori critici',
	'installation:debug:warning' => 'Visualizza errori e messaggi di allarme',
	'installation:debug:notice' => 'Logga tutti gli errori, messaggi di allarme e comunicazioni',
	'installation:httpslogin' => "Abilita questo per utilizzare il login sicuro via HTTPS. Per farlo funzionare avrai bisogno dell' https abilitato sul tuo server.",
	'installation:httpslogin:label' => "Abilita login HTTPS",
	'installation:view' => "Inserisci la visualizzazione che sara utilizzata di default per il tuo sito o lascia vuoto per la visualizzazione di default di Elgg (se hai dubbi, non modificare):",

	'installation:siteemail' => "Indirizzo e-mail del sito (usato quando si inviano e-mail di/dal sistema)",

	'installation:disableapi' => "La RESTful API è un'interfaccia flessibile ed estensibile che permette alle applicazioni di usare alcune funzioni di Elgg da remoto.",
	'installation:disableapi:label' => "Abilita la RESTful API",

	'installation:allow_user_default_access:description' => "Se spuntato, gli utenti singoli saranno abilitati a settare il proprio livello di accesso di default che sovrascriverà il livello di accesso di default del sistema.",
	'installation:allow_user_default_access:label' => "Consenti il livello di accesso di default per singolo utente",

	'installation:simplecache:description' => "La cache semplice aumenta le performance mettendo in cache il contenuto statico, inclusi alcuni file CSS e JavaScript. L'uso è consigliato.",
	'installation:simplecache:label' => "Usa la cache semplice (raccomandato)",

	'installation:viewpathcache:description' => "La cache vista percorso file diminuisce i tempi di caricamento dei plugin inserendo in cache le posizioni delle loro visualizzazioni.",
	'installation:viewpathcache:label' => "Usa la cache vista percorso file (raccomandato)",

	'upgrading' => 'Upgrade in corso...',
	'upgrade:db' => 'Il tuo database è stato aggiornato.',
	'upgrade:core' => 'La tua installazione di Elgg è stata aggiornata.',

/**
 * Welcome
 */

	'welcome' => "Ciao",
	'welcome:user' => 'Ciao %s',
	'welcome_message' => "Benvenuto/a a questa installazione di Elgg.",

/**
 * Emails
 */
	'email:settings' => "Impostazioni Email",
	'email:address:label' => "Il tuo indirizzo Email",

	'email:save:success' => "Nuovo indirizzo Email salvato, richiesta verifica.",
	'email:save:fail' => "Non è stato possibile salvare il tuo nuovo indirizzo Email.",

	'friend:newfriend:subject' => "%s ti ha aggiunto ai suoi amici!",
	'friend:newfriend:body' => "%s ti ha aggiunto ai suoi amici!

Per vedere il suo profilo clicca qui:

%s

Non puoi rispondere a questa email.",



	'email:resetpassword:subject' => "Cambio password!",
	'email:resetpassword:body' => "Ciao %s,

La tua password è stata cambiata in: %s",


	'email:resetreq:subject' => "Richiesta di nuova password.",
	'email:resetreq:body' => "Ciao %s,

Qualcuno (dall' indirizzo IP %s) ha richiesto una nuova password per il tuo account.

Se sei stato/a tu allora clicca sul link in basso, altrimenti per favore ignora questa email.

%s
",

/**
 * user default access
 */

'default_access:settings' => "Il tuo livello di accesso di default",
'default_access:label' => "Accesso di default",
'user:default_access:success' => "Il tuo nuovo livello di accesso di default è stato salvato.",
'user:default_access:failure' => "Non è stato possibile salvare il tuo nuovo livello di accesso di default.",

/**
 * XML-RPC
 */
	'xmlrpc:noinputdata'	=>	"Dati da inserire mancanti",

/**
 * Comments
 */

	'comments:count' => "%s commenti",

	'riveraction:annotation:generic_comment' => '%s ha commentato %s',

	'generic_comments:add' => "Inserisci un commento",
	'generic_comments:text' => "Commento",
	'generic_comment:posted' => "Il tuo commento è stato inserito con successo.",
	'generic_comment:deleted' => "Il tuo commento è stato cancellato correttamente.",
	'generic_comment:blank' => "Spiacenti ma per salvare il commento devi inserire del testo.",
	'generic_comment:notfound' => "Spiacenti, elemento non trovato.",
	'generic_comment:notdeleted' => "Spiacenti, non è stato possibile cancellare questo commento.",
	'generic_comment:failure' => "Errore non previsto mentre inserivi il tuo commento. Per favore riprova, grazie.",

	'generic_comment:email:subject' => 'Hai un nuovo commento!',
	'generic_comment:email:body' => "Hai un nuovo commento su  \"%s\" da %s :


%s


Per rispondere o visualizzare l'elemento iniziale, clicca qui:

%s

Per vedere il profilo di %s clicca qui:

%s

Non puoi rispondere a questa email.",

/**
 * Entities
 */
	'entity:default:strapline' => 'Creato %s da %s',
	'entity:default:missingsupport:popup' => 'Questo elemento non pu� essere visualizzato correttamente, probabilmente perchè necessita di un plugin che non � pi� installato.',

	'entity:delete:success' => 'L\'elemento %s � stato cancellato',
	'entity:delete:fail' => 'Non è stato possibile cancellare l\'elemento %s',


/**
 * Action gatekeeper
 */
	'actiongatekeeper:missingfields' => 'Il Form non trova __token or __ts fields',
	'actiongatekeeper:tokeninvalid' => "Abbiamo riscontrato un errore (token mismatch). Probabilmente significa che la pagina che stavi usando � scaduta. Per favore riprova, grazie.",
	'actiongatekeeper:timeerror' => 'La pagina che stavi usando � scaduta. Per favore aggiorna e riprova, grazie.',
	'actiongatekeeper:pluginprevents' => 'Un\'estensione ha impedito al form di essere inviato.',

/**
 * Word blacklists
 */
	'word:blacklist' => 'and, the, then, but, she, his, her, him, one, not, also, about, now, hence, however, still, likewise, otherwise, therefore, conversely, rather, consequently, furthermore, nevertheless, instead, meanwhile, accordingly, this, seems, what, whom, whose, whoever, whomever',

/**
 * Tag labels
 */

	'tag_names:tags' => 'Tag',
	
/**
 *  FINE TERZA PARTE /////////////////////////////////////////////////////////////////////////////
 */ 

/**
 * Languages according to ISO 639-1
 */
	"aa" => "Nord Etiope",
	"ab" => "Abcaso",
	"af" => "Africano",
	"am" => "Sud Etiope",
	"ar" => "Arabo",
	"as" => "Assamese",
	"ay" => "Andino",
	"az" => "Azero",
	"ba" => "Baschiri",
	"be" => "Bielorusso",
	"bg" => "Bulgaro",
	"bh" => "Bihari",
	"bi" => "Bislama",
	"bn" => "Bengalese",
	"bo" => "Tibetano",
	"br" => "Bretone",
	"ca" => "Catalano",
	"co" => "Corso",
	"cs" => "Ceco",
	"cy" => "Gallese",
	"da" => "Danese",
	"de" => "Tedesco",
	"dz" => "Bhutanese",
	"el" => "Greco moderno",
	"en" => "Inglese",
	"eo" => "Esperanto",
	"es" => "Spagnolo",
	"et" => "Estone",
	"eu" => "Basco",
	"fa" => "Persiano",
	"fi" => "Finlandese",
	"fj" => "Fijiano",
	"fo" => "Faroese",
	"fr" => "Francese",
	"fy" => "Fresone",
	"ga" => "Irlandese",
	"gd" => "Gaelico",
	"gl" => "Galiziano",
	"gn" => "Guarani",
	"gu" => "Gujarati",
	"he" => "Ebraico",
	"ha" => "Hausa",
	"hi" => "Indi",
	"hr" => "Croato",
	"hu" => "Ungherese",
	"hy" => "Armeno",
	"ia" => "Interlingua",
	"id" => "Indonesiano",
	"ie" => "Interlingue",
	"ik" => "Inupiak(Alaska)",
	//"in" => "Indonesian",
	"is" => "Islandese",
	"it" => "Italiano",
	"iu" => "Estone",
	"iw" => "Ebreo(obsoleto)",
	"ja" => "Giapponese",
	"ji" => "Yiddish (obsoleto)",
	"jw" => "Javanese",
	"ka" => "Georgiano",
	"kk" => "Kazako",
	"kl" => "Groenlandese",
	"km" => "Cambogiano",
	"kn" => "Canarese",
	"ko" => "Coreano",
	"ks" => "Kashmir",
	"ku" => "Curdo",
	"ky" => "Kirghiso",
	"la" => "Latino",
	"ln" => "Lingala",
	"lo" => "Laothian",
	"lt" => "Lituano",
	"lv" => "Lettone",
	"mg" => "Malgascio",
	"mi" => "Maori",
	"mk" => "Macedone",
	"ml" => "Malayalam",
	"mn" => "Mongolo",
	"mo" => "Moldavo",
	"mr" => "Marathi",
	"ms" => "Malese",
	"mt" => "Maltese",
	"my" => "Burmese",
	"na" => "Nauru",
	"ne" => "Nepalese",
	"nl" => "Olandese",
	"no" => "Norvegese",
	"oc" => "Provenzale / Occitano",
	"om" => "Oromo (Etiope)",
	"or" => "Oriya",
	"os" => "Osseto",
	"pa" => "Punjabi",
	"pl" => "Polacco",
	"ps" => "Pashtun",
	"pt" => "Portoghese",
	"qu" => "Quechua",
	"rm" => "Rhaeto-Romance",
	"rn" => "Kirundi",
	"ro" => "Rumeno",
	"ru" => "Russo",
	"rw" => "Ruandese",
	"sa" => "Sanscrito",
	"sd" => "Sindhi",
	"sg" => "Sangro",
	"sh" => "Serbo-Croato",
	"si" => "Singalese",
	"sk" => "Slovacco",
	"sl" => "Sloveno",
	"sm" => "Samoa",
	"sn" => "Shona",
	"so" => "Somalo ",
	"sq" => "Albanese",
	"sr" => "Serbo",
	"ss" => "Swazilandese",
	"st" => "Sesotho",
	"su" => "Sudanese",
	"sv" => "Svedese ",
	"sw" => "Swahili",
	"ta" => "Tamil",
	"te" => "Telugu (Indiano)",
	"tg" => "Persiano",
	"th" => "Thailandese",
	"ti" => "Tigrino",
	"tk" => "Turcomanno",
	"tl" => "Filippino",
	"tn" => "Nigeriano",
	"to" => "Polinesiano",
	"tr" => "Turco",
	"ts" => "Mozambicano",
	"tt" => "Tataro",
	"tw" => "Ghanese",
	"ug" => "Uigur",
	"uk" => "Ucraino",
	"ur" => "Urdu",
	"uz" => "Uzbeko ",
	"vi" => "Vietnamita",
	"vo" => "Volapuk",
	"wo" => "Wolof",
	"xh" => "Xhosa",
	//"y" => "Yiddish",
	"yi" => "Yiddish", 
	"yo" => "Yoruba",
	"za" => "Zuang",
	"zh" => "Cinese",
	"zu" => "Zulu",
);

add_translation("it",$italian);
