<?php
	/**
	* likes
	*
	* @author likes
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	$object = $vars['entity'];
	
	//We count the quantity of people that likes this.
	$likes_no = (int) count_annotations($object->getGUID(), "", "", 'like');
	
	if ($object instanceof ElggEntity && isloggedin()) {
		//Do you like this object?
		$doyoulike = false;
		
		//Now we check if the user that is logged in likes this object.
		$likes_no_by_user = count_annotations($object->getGUID(), "", "", 'like', 1, '', get_loggedin_userid());
		if ($likes_no_by_user > 0) {
			//You already liked it
			$doyoulike = true;
			$annotation = get_annotations($object->getGUID(), "", "", 'like', 1, get_loggedin_userid(), 1);
			if (!empty($annotation)) {
				$annotation = array_shift($annotation);
			}
			$link = "{$vars['url']}action/unlike?like_id={$annotation->id}" . url_compatible_mode('&');
			$content .=  "<a href=\"$link\">" . elgg_echo('unlike') . "</a> · ";
		} else {
			//You can like it
			//always generate missing action tokens
			$link = "{$vars['url']}action/like?guid={$object->guid}" . url_compatible_mode('&');
			$end_sentence = ($likes_no > 0 ? ' · ' : '');
			$content .=  "<a href=\"$link\">" . elgg_echo('like') . "</a>$end_sentence";	
		} // if ($likes_no_by_user > 0) {
		
		if ($likes_no > 0) {
			
			// If more than two users, and if you are not there then the translation must finish with: 3 people likes it (like:lotofpeoplelikethis)
			// If more than two users, and you are in that list then the translation must finish with: you and 2 more people likes it.
			
			// If there are two users that likes it and you are not then the translation must be: user1 and user2 likes it. (like:others2likethis)
			// If there are two users that likes it and you are not then the translation must be: user1 and you likes it. (like:otherandyoulikethis)
			
			// If just one user likes it and that user is you then it must say: You likes it. (like:youlikethis)
			// If just one user likes it and that user is not you then it must say: user1 likes it. (like:otherlikesthis)
			
			if ($likes_no < 3) {
				$annotations = get_annotations($object->getGUID(), "", "", 'like', "", "", $likes_no);
				
				$first_annotation = current($annotations);
				$user = get_entity($first_annotation->owner_guid);
				$username = "<a href=\"{$user->getURL()}\">$user->name</a>"; 
				
				if ($likes_no == 1) {
					if ($doyoulike) {
						$content .= elgg_echo("like:youlikethis");
					} else {
						$content .= sprintf(elgg_echo("like:otherlikesthis"), $username);
					}
				} else {
					$last_annotation = end($annotations);
					$user2 = get_entity($last_annotation->owner_guid);
					$username2 = "<a href=\"{$user2->getURL()}\">$user2->name</a>";
					
					//Likes == 2
					if ($user == get_loggedin_user() || $user2 == get_loggedin_user()) {
						//TODO Make it better.
						if ($user2 == get_loggedin_user()) {
							$aux = $username;
							$username = $username2;
							$username2 = $aux;  
						}
						$content .= sprintf(elgg_echo("like:otherandyoulikethis"), $username2);
					} else {
						$content .= sprintf(elgg_echo("like:others2likethis"), $username2, $username);
					}
				} //if ($likes_no == 1) {
			} else {
				if ($doyoulike) {
					$content .= sprintf(elgg_echo("like:youandalotofpeoplelikethis"), "<strong>" . sprintf(elgg_echo("like:others"),$likes_no-1) . "</strong>");
				} else {
					$content .= sprintf(elgg_echo("like:lotofpeoplelikethis"), "<strong>" . sprintf(elgg_echo("like:others"),$likes_no). "</strong>");
				}
			} //if ($likes_no < 3) {
		}
		echo "<div class='like'>$content</div>";
	} //if ($object instanceof ElggEntity && isloggedin())