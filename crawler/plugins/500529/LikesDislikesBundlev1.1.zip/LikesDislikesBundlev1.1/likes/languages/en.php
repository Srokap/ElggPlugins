<?php
	/**
	* likes
	*
	* @author likes
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*
	* @title Likes/Dislikes Bundle v1.0
	* @author Artist Craze Media
	* @link http://elgg.artistcrazemedia.com/
	* @version 1.0
	* @license GNU General Public License (GPL) version 2
	*/

	$english = array(
			'likes:admin' => 'Like Settings',
			'like:admin:subtitle' => 'Please select what should be shown below:',
			
			'like:show:thewire' => 'Show The Wire likes on the river?',
			'like:show:mood' => 'Show Mood likes on the river?',
			'like:show:messageboard' => 'Show Messageboard likes on the river?',
			'like:show:bookmarks' => 'Show Bookmark likes on the river?',
			'like:show:blog' => 'Show Blog likes on the river?',
			'like:show:file' => 'Show file likes on the river?',
			'like:show:page' => 'Show Page likes on the river?',
			'like:show:topic' => 'Show Discussion Topic likes on the river?',
			'like:show:stores' => 'Show Social Commerce likes on the river?',
			'like:show:groups' => 'Show Group likes on the river?',
			'like:show:image' => 'Show Image likes on the river?',
			'like:show:album' => 'Show Album likes on the river?',
			'like:show:profileiconupdate' => 'Show Profile Icon Update dislikes on the river?',
			'like:show:profileupdate' => 'Show Profile Update dislikes on the river?',
			
			'like' => 'Like',
			'unlike' => 'Unlike',
	
			'like:youlikethis' => 'You like this.',
			'like:otherlikesthis' => '%s likes this.',
	
			'like:otherandyoulikethis' => 'You and %s like this.',
			'like:others2likethis' => '%s and %s like this.',
	
			'like:others' => '%s others',
	
			'like:lotofpeoplelikethis' => '%s people like this.',
			'like:youandalotofpeoplelikethis' => 'You and %s like this.',
	
			/*Actions*/
			'like:posted' => 'Your "like" was successfully posted.',
			'like:failure' => 'An unexpected error occurred when adding your "like". Please try again.',

			'like:deleted' => 'Your "like" was successfully deleted.',
			'like:notdeleted' => 'Sorry, we could not delete this "like".',
	
	);
					
	add_translation("en",$english);
?>