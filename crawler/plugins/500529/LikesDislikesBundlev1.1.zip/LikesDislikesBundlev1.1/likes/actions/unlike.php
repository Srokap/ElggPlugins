<?php
	/**
	* likes
	*
	* @author likes
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	// Ensure we're logged in
		if (!isloggedin()) {
			forward();
		}
		
		$forward_url = "";
		//Forward
		if (isset($_SERVER['HTTP_REFERER'])) {
			//Go to referer page
			$forward_url = $_SERVER['HTTP_REFERER'];	
		}

	// Make sure we can get the "like" in question
		$like_id = (int) get_input('like_id');
		if ($like = get_annotation($like_id)) {
	
			$entity = get_entity($like->entity_guid);
	
			if ($like->canEdit()) {
				$like->delete();
				system_message(elgg_echo("like:deleted"));
				forward($forward_url);
			}
		}
		
		register_error(elgg_echo("like:notdeleted"));
	//Go to home
		forward($forward_url);