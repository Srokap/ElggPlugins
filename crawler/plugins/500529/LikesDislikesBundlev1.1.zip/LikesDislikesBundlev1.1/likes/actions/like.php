<?php
	/**
	* likes
	*
	* @author likes
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	// Make sure we're logged in (send us to the front page if not)
		if (!isloggedin()) forward();

	// Get input data
		$guid = get_input('guid');
		
		$forward_url = "";
		//Forward
		if (isset($_SERVER['HTTP_REFERER'])) {
			//Go to referer page
			$forward_url = $_SERVER['HTTP_REFERER'];	
		}	
		
	//Check status
		$object = get_entity($guid);
		$user = get_loggedin_user();
		if ($object instanceof ElggEntity) {
			$likes_no_by_user = count_annotations($object->getGUID(), "", "", 'like', '', get_loggedin_userid());
			if ($likes_no_by_user == 0) {
				//Do LIKE action
				$like = create_annotation($object->guid, 'like', 1, "", $user->guid, $object->access_id);
	
				// tell user annotation posted
				if ($like) {
					system_message(elgg_echo("like:posted"));
					forward($forward_url);
				}
			}
		}
		
		register_error(elgg_echo("like:failure"));
	//Go to home
		forward($forward_url);
?>