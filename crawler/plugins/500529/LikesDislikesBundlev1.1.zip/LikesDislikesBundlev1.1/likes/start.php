<?php
	/**
	* likes
	*
	* @author likes
	* @link http://community.elgg.org/pg/icon/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*
	* @title Likes/Dislikes Bundle v1.0
	* @author Artist Craze Media
	* @link http://elgg.artistcrazemedia.com/
	* @version 1.0
	* @license GNU General Public License (GPL) version 2
	*/

	function likes_init() {
		global $CONFIG;
	extend_view('river/object/quotes/create', 'likes/river/item');
	extend_view('river/object/quotes/annotate', 'likes/river/item');
		if (get_plugin_setting('show_thewire', 'likes') != 'no') {
	
			extend_view('river/object/thewire/create', 'likes/river/item');
		}
                if (get_plugin_setting('show_mood', 'likes') != 'no') {
			extend_view('river/object/mood/create', 'likes/river/item');
		}
		if (get_plugin_setting('show_messageboard', 'likes') != 'no') {
			extend_view('river/object/messageboard/create', 'likes/river/item');
		}
		if (get_plugin_setting('show_bookmarks', 'likes') != 'no') {
			extend_view('river/object/bookmarks/create', 'likes/river/item');
		}
		if (get_plugin_setting('show_file', 'likes') != 'no') {
			extend_view('river/object/file/create', 'likes/river/item');
		}
		if (get_plugin_setting('show_blog', 'likes') != 'no') {
			extend_view('river/object/blog/create', 'likes/river/item');
		}
		if (get_plugin_setting('show_page', 'likes') != 'no') {
			extend_view('river/object/page/create', 'likes/river/item');
		}
		if (get_plugin_setting('show_topic', 'likes') != 'no') {
			extend_view('river/forum/topic/create', 'likes/river/item');
		}
		if (get_plugin_setting('show_stores', 'likes') != 'no') {
			extend_view('river/object/stores/create', 'likes/river/item');
		}
                if (get_plugin_setting('show_album', 'likes') != 'no') {
			extend_view('river/object/album/create', 'likes/river/item');
		}
                if (get_plugin_setting('show_image', 'likes') != 'no') {
			extend_view('river/object/image/create', 'likes/river/item');
		}
		if (get_plugin_setting('show_profileiconupdate', 'likes') != 'no') {
			extend_view('river/object/profileiconupdate', 'likes/river/item');
		}
		if (get_plugin_setting('show_profileupdate', 'likes') != 'no') {
			extend_view('river/object/profileupdate', 'likes/river/item');
		}
		extend_view('css', 'likes/css');
		
		//Page Handler
		register_page_handler('likes','likes_page_handler');
		
		//Actions
		register_action("like",false, $CONFIG->pluginspath . "/likes/actions/like.php");
		register_action("unlike",false, $CONFIG->pluginspath . "/likes/actions/unlike.php");
	}
	
	function likes_page_handler($page) {
		global $CONFIG;
		if (isset($page[0])) {
			switch($page[0]) {
				case "admin":
					!@include_once(dirname(__FILE__) . "/admin.php");
					return false;
          			break;
			}
		}
	}
	
	function likes_setup() {
		global $CONFIG;
		if (get_context()=='admin') {
    		add_submenu_item(elgg_echo("likes:admin"), $CONFIG->wwwroot . "pg/likes/admin" );
		}
	}
	
	//Generate url for accept action on elgg 1.7
	if(!is_callable('url_compatible_mode')) {
	    function url_compatible_mode($hook = '?') {
	    	$now = time();
			$query[] = "__elgg_ts=" . $now;
			$query[] = "__elgg_token=" . generate_action_token($now);
			$query_string = implode("&", $query);
			return $hook . $query_string;
	    }
	}
	
	register_elgg_event_handler('init','system','likes_init');
	register_elgg_event_handler('pagesetup','system','likes_setup');