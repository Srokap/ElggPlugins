<?php
	/**
	* dislikes
	*
	* @author dislikes
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*
	* @title Likes/Dislikes Bundle v1.0
	* @author Artist Craze Media
	* @link http://elgg.artistcrazemedia.com/
	* @version 1.0
	* @license GNU General Public License (GPL) version 2
	*/

	$english = array(
			'dislikes:admin' => 'Dislike Settings',
			'dislikes:admin:subtitle' => 'Please select what should be shown below:',
			
			'dislike:show:thewire' => 'Show The Wire dislikes on the river?',
			'dislike:show:mood' => 'Show Mood dislikes on the river?',
			'dislike:show:messageboard' => 'Show Messageboard dislikes on the river?',
			'dislike:show:bookmarks' => 'Show Bookmark dislikes on the river?',
			'dislike:show:blog' => 'Show Blog dislikes on the river?',
			'dislike:show:file' => 'Show file dislikes on the river?',
			'dislike:show:page' => 'Show Page dislikes on the river?',
			'dislike:show:topic' => 'Show Discussion Topic dislikes on the river?',
			'dislike:show:stores' => 'Show Social Commerce dislikes on the river?',
			'dislike:show:groups' => 'Show Group dislikes on the river?',
			'dislike:show:image' => 'Show Image dislikes on the river?',
			'dislike:show:album' => 'Show Album dislikes on the river?',
			'dislike:show:profileiconupdate' => 'Show Profile Icon Update dislikes on the river?',
			'dislike:show:profileupdate' => 'Show Profile Update dislikes on the river?',
			
			'dislike' => 'Dislike',
			'undislike' => 'Undislike',
	
			'dislike:youdislikethis' => 'You dislike this.',
			'dislike:otherdislikesthis' => '%s dislikes this.',
	
			'dislike:otherandyoudislikethis' => 'You and %s dislike this.',
			'dislike:others2dislikethis' => '%s and %s dislike this.',
	
			'dislike:others' => '%s others',
	
			'dislike:lotofpeopledislikethis' => '%s people dislike this.',
			'dislike:youandalotofpeopledislikethis' => 'You and %s dislike this.',
	
			/*Actions*/
			'dislike:posted' => 'Your "dislike" was successfully posted.',
			'dislike:failure' => 'An unexpected error occurred when adding your "dislike". Please try again.',

			'dislike:deleted' => 'Your "dislike" was successfully deleted.',
			'dislike:notdeleted' => 'Sorry, we could not delete this "dislike".',
	
	);
					
	add_translation("en",$english);
?>