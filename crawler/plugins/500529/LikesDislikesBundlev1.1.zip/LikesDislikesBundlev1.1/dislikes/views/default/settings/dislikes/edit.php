<?php
	/**
	* dislikes
	*
	* @author dislikes
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*
	* @title Likes/Dislikes Bundle v1.0
	* @author Artist Craze Media
	* @link http://elgg.artistcrazemedia.com/
	* @version 1.0
	* @license GNU General Public License (GPL) version 2
	*/

?>
<p>
	<?php echo elgg_echo('dislike:show:thewire'); ?>
	<select name="params[show_thewire]">
		<option value="yes" <?php if ($vars['entity']->show_thewire == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_thewire != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<p>
	<?php echo elgg_echo('dislike:show:mood'); ?>
	<select name="params[show_mood]">
		<option value="yes" <?php if ($vars['entity']->show_mood == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_mood != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<p>
	<?php echo elgg_echo('dislike:show:messageboard'); ?>
	<select name="params[show_messageboard]">
		<option value="yes" <?php if ($vars['entity']->show_messageboard == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_messageboard != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<p>
	<?php echo elgg_echo('dislike:show:bookmarks'); ?>
	<select name="params[show_bookmarks]">
		<option value="yes" <?php if ($vars['entity']->show_bookmarks == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_bookmarks != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<p>
	<?php echo elgg_echo('dislike:show:file'); ?>
	<select name="params[show_file]">
		<option value="yes" <?php if ($vars['entity']->show_file == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_file != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<p>
	<?php echo elgg_echo('dislike:show:blog'); ?>
	<select name="params[show_blog]">
		<option value="yes" <?php if ($vars['entity']->show_blog == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_blog != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<p>
	<?php echo elgg_echo('dislike:show:page'); ?>
	<select name="params[show_page]">
		<option value="yes" <?php if ($vars['entity']->show_page == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_page != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<p>
	<?php echo elgg_echo('dislike:show:topic'); ?>
	<select name="params[show_topic]">
		<option value="yes" <?php if ($vars['entity']->show_topic == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_topic != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<p>
	<?php echo elgg_echo('dislike:show:stores'); ?>
	<select name="params[show_stores]">
		<option value="yes" <?php if ($vars['entity']->show_stores == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_stores != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<p>
	<?php echo elgg_echo('dislike:show:groups'); ?>
	<select name="params[show_groups]">
		<option value="yes" <?php if ($vars['entity']->show_groups == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_groups != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<p>
	<?php echo elgg_echo('dislike:show:album'); ?>
	<select name="params[show_album]">
		<option value="yes" <?php if ($vars['entity']->show_album == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_album != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<p>
	<?php echo elgg_echo('dislike:show:image'); ?>
	<select name="params[show_image]">
		<option value="yes" <?php if ($vars['entity']->show_image == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_image != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<p>
	<?php echo elgg_echo('dislike:show:profileiconupdate'); ?>
	<select name="params[show_profileiconupdate]">
		<option value="yes" <?php if ($vars['entity']->show_profileiconupdate == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_profileiconupdate != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<p>
	<?php echo elgg_echo('dislike:show:profileupdate'); ?>
	<select name="params[show_profileupdate]">
		<option value="yes" <?php if ($vars['entity']->show_profileupdate == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_profileupdate != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>