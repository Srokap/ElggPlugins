<?php
	/**
	* dislikes
	*
	* @author dislikes
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/
	
	$entity = get_entity($vars['item']->object_guid);
	echo elgg_view('input/dislike', array('entity' => $entity));