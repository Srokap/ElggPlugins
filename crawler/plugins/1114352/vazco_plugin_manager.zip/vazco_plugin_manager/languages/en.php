<?php
$english = array(
	'admin:plugins:reorder:yes'			=> 'Plugins were successfully reordered',
	'admin:plugins:reorder:no'			=> 'Failed to reorder plugins!',
	'admin:plugins:extension'       	=> 'Extension',
	'admin:plugins:plugins_name_list' 	=> 'List of plugins (a comma separated list with currently enabled plugins)',
	'admin:plugins:apply' 				=> 'Apply',
	'admin:plugins:clear_list'      	=> 'Clear List',
	'admin:plugins:reset_list'      	=> 'Reset List',
	'admin:plugins:select_list'     	=> 'Select List',
	
	'admin:plugins:disable:yes'			=> 'Plugin \'%s\' was successfully disabled',
	'admin:plugins:disable:no'			=> 'Unable to disable plugin \'%s\'',
	'admin:plugins:enable:yes'			=> 'Plugin \'%s\' was successfully enabled',
	'admin:plugins:enable:no'			=> 'Unable to enable plugin \'%s\'',
	'admin:plugins:reorder:yes'			=> 'Plugins were successfully reordered',
	'admin:plugins:reorder:no'			=> 'There was problem while reordering plugins',

);

add_translation("en", $english);
