<?php
elgg_set_context('pluginmanager');

$plugin = get_input('plugin');

$title = "$plugin settings";

$area2 = elgg_view_title($title);

$area2 .= elgg_view('object/plugin', array('plugin' => $plugin, 'entity' => find_plugin_settings($plugin)));

$body = elgg_view_layout('two_column_left_sidebar', array(
'area1' =>  $area1,
'area2' =>  $area2
));

$body = elgg_view_layout('content', array(
		'filter' => '',
		'content' => $content,
		'title' => $title,
	));

echo elgg_view_page($title, $body);