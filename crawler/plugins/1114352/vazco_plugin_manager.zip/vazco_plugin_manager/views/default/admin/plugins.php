<?php 
echo elgg_view('admin/plugins/advanced', $vars);
?>