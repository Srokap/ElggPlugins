<?php
function plugin_manager_init() {
	global $CONFIG;

	if (elgg_get_context() == 'admin') {
		//TODO:
// 		elgg_extend_view('metatags', 'links/admin/plugins');
// 		elgg_extend_view('metatags', 'links/jquery/ui');
// 		elgg_extend_view('metatags', 'scripts/admin/plugins');
		
		elgg_register_js('plugin_manager_js', $vars['url'] . "mod/plugin_manager/js/admin/plugins.js");
		elgg_register_css('jquery_ui', "ajax.googleapis.com/ajax/libs/jqueryui/1.8.5/themes/start/jquery-ui.css");
		elgg_register_css('plugin_manager_css', $vars['url']. "mod/plugin_manager/css/admin/plugins.css");
	}
	
	elgg_load_css('plugin_manager_css');
	elgg_load_js('plugin_manager_js');
	elgg_load_css('jquery_ui');
	
	
	elgg_extend_view('css', 'plugin_manager/css');
	
	elgg_register_simplecache_view('js/admin/plugins');
	 
	//register_action('admin/plugins/save', FALSE, dirname(__FILE__)."/actions/admin/plugins/save.php", TRUE);
	elgg_register_action('admin/plugins/save', dirname(__FILE__)."/actions/admin/plugins/save.php", 'admin');
	//register_action('admin/plugins/list', FALSE, dirname(__FILE__)."/actions/admin/plugins/list.php", TRUE);
	elgg_register_action('admin/plugins/list', dirname(__FILE__)."/actions/admin/plugins/list.php", 'admin');
	
	elgg_register_page_handler('pluginmanager', 'plugin_manager_page_handler');
}

function plugin_manager_page_handler($page) {
	
	switch ($page[0]) {
		case 'admin':
			set_input('plugin', $page[1]);
			include dirname(__FILE__).'/pages/pluginsettings/admin.php';
			break;
		default:
			forward('', '404');
			break;
	}
}

elgg_register_event_handler('init', 'system', 'plugin_manager_init');
