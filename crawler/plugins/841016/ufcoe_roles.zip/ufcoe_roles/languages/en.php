<?php

$english = array(
	'ufcoe_roles:settings:my' => "My System Roles",
	'ufcoe_roles:key:elgg' => "Community",
    'ufcoe_roles:settings:no_roles' => "You have no system roles.",
    'ufcoe_roles:settings:menu:my' => 'My System Roles',
);

add_translation("en", $english);