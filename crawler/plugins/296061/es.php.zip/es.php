<?php
$spanish = array(
/**
 * Blog types translations
 */
  'blog:type'=>"Categor&iacute;a",
  'blog:type:ArtandPhotography'=>"Arte y fotogr&aacute;fia",
  'blog:type:Automotive'=>"Motores",
  'blog:type:Blogging'=>"Blogging",
  'blog:type:MoviesTVCelebrities'=>"Pel&iacute;culas, TV y celebridades",
  'blog:type:DreamsandSupernatural'=>"Sue&ntilde;os y supernatural",
  'blog:type:FashionStyleShopping'=>"Moda, estilo y shopping",
  'blog:type:FoodandRestaurants'=>"Comidas y Comedores",
  'blog:type:Friends'=>"Amigos",
  'blog:type:Games'=>"Juegos",
  'blog:type:JobsWorkCareers'=>"Trabajos, Empleos y Carreras",
  'blog:type:Life'=>"Vida",
  'blog:type:Music'=>"M&uacute;sica",
  'blog:type:NewsandPolitics'=>"Noticias y P&oacute;litica",
  'blog:type:PetsandAnimals'=>"Mascotas y anim&aacute;les",
  'blog:type:Personal'=>"Personal",
  'blog:type:Podcast'=>"Podcast",
  'blog:type:ReligionandPhilosophy'=>"Religi&oacute;n y Filosof&iacute;a",
  'blog:type:Sports'=>"Deportes",
  'blog:type:TravelandPlaces'=>"Viajes y lugares ",
  'blog:type:WebHTMLComputerTech'=>"Web, HTML, Tecnolog&iacute;a",
  'blog:type:WritingandPoetry'=>"Escritos y poes&iacute;a",
  'blog:type:School'=>"Escuela",

/**
 * Blog widget
 */
  'blog:widget:title'=>"Blogs",
  'blog:widget:description'=>"Mostrar sus art&iacute;culos en el widget",
  'blog:widget:default_view'=>"Seleccione el tema",
  'blog:widget:default'=>"Default",
  'blog:widget:compact'=>"Compacto",

  'contents:empty'=>"No existe ning&uacute;n art&iacute;culo.",

  'blog:extratypes:enable'=> "Habilitar soporte de blog?",
  'blog:group:contents'=> "Habilitar contenido en grupos?",
  'blog:group:iconoverwrite'=>"Habilitar un icono cuando tienen un grupo asociado ?",

// Group related translations
  'group:contents'=>"Contenidos",
  'group:contents:empty'=>"No existe ning&uacute;n contenido en este grupo",

//
  'content:owner'=>"Asignar a",
  'my:profile'=>"Mi perfil",
  'publish:for'=>"publicado en %s",

);
add_translation("es",$spanish);

?>
