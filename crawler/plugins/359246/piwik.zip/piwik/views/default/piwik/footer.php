<?php /* Piwik plugin for the Elgg social network engine. */ ?>

<?php
$data = get_entities("object", "modpiwik", 0, "", 9999);
if(isset($data[0])) {
	$entity = $data[0];
	if($entity->showga) {
?>
<script type="text/javascript">
var pkBaseURL = (("https:" == document.location.protocol) ? "https://<?php echo $entity->trackurl; ?>/" : "http://<?php echo $entity->trackurl; ?>/");
document.write(unescape("%3Cscript src='" + pkBaseURL + "piwik.js' type='text/javascript'%3E%3C/script%3E"));
</script><script type="text/javascript">
try {
var piwikTracker = Piwik.getTracker(pkBaseURL + "piwik.php", <?php echo $entity->trackid; ?>);
piwikTracker.trackPageView();
piwikTracker.enableLinkTracking();
} catch( err ) {}
</script>
<noscript><p><img src="http://<?php echo $entity->trackurl; ?>/piwik.php?idsite=<?php echo $entity->trackid; ?>" style="border:0" alt=""/></p></noscript>
<?php }
	} else {
		if ($_SESSION['user']->admin || $_SESSION['user']->siteadmin) {
			system_message("You've installed the Piwik plugin but you still need to go to the Piwik section from within the admin panel.");
		}
	}
?>
