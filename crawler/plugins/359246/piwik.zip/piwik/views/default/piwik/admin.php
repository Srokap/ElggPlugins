<p><?php echo elgg_echo('piwik:description'); ?></p>

<form action="<?php echo $vars['url']; ?>action/piwik/modify" method="post">
<p>
	<?php	echo elgg_echo('piwik:formenabled');
			echo elgg_view('input/radio',array('internalname' => "showga", 'options' => array('yes' => 1,'no' => 0), 'value' => $vars['showga']));
	?>
</p>
<p>
<label>
	<?php 	echo elgg_echo('piwik:modify'); ?>
	<?php	echo elgg_view('input/text',array(
				'internalname' => 'trackid',
				'value' => $vars['trackid']
			)); 
	?>
</label>
<label>
	<?php 	echo elgg_echo('piwik:trackurl'); ?>
	<?php	echo elgg_view('input/text',array(
				'internalname' => 'trackurl',
				'value' => $vars['trackurl']
			)); 
	?>
</label>
<?php
	echo elgg_view('input/hidden',array('internalname' => '__elgg_token', 'value' => $vars['token']));
	echo elgg_view('input/hidden',array('internalname' => '__elgg_ts', 'value' => $vars['ts']));
?>
</p>
<p>
<input type="submit" value="<?php echo elgg_echo('piwik:submit'); ?>" />
</p>

</form>


	<?php
	$idSite = $vars['trackid'];
	$start = date( "Y-m-d", time() - ( 31 * 24 * 60 * 60 ) );
	$end = date( "Y-m-d" );
	?>
	<div id="content_area_user_title">
		<h2><?php echo elgg_echo('piwik:statistics_heading' ); ?></h2>
	</div>
	<?php echo elgg_echo('piwik:statistics' ); ?>

	<object style="visibility: visible;" id="VisitsSummarygetEvolutionGraphChart_swf" data="http://<?php echo $vars['trackurl']; ?>/libs/open-flash-chart/open-flash-chart.swf?piwik=0.5.4" bgcolor="#FFFFFF" type="application/x-shockwave-flash" height="150" width="100%">
		<param value="always" name="allowScriptAccess">
		<param value="opaque" name="wmode">
		<param value="data-file=http://<?php echo $vars['trackurl']; ?>/index.php%3Fmodule%3DVisitsSummary%26action%3DgetEvolutionGraph%26columns%5B%5D%3Dnb_visits%26idSite%3D<?php echo $idSite; ?>%26period%3Dday%26date%3D<?php echo $start; ?>%2C<?php echo $end; ?>%26viewDataTable%3DgenerateDataChartEvolution&loading=Laden..." name="flashvars">
	</object>
