hypeForum is part of the hypeJunction plugin bundle

============
www.hypeJunction.com
hypeJunction is here for you to connect, innovate, integrate, collaborate and indulge.
hypeJunction is a bundle of plugins that will help you kick start your Elgg-based social network and spice it up with cool features and functionalities.
============

PLUGIN DESCRIPTION
------------------
hypeForum is a traverse discussion plugin for Elgg.
hypeForum creates a site-wide forum. Multiple instances of forums can be created in the backend.

Main features include:
-- Unlimited forum depth
-- Sticky and closed topics
-- Topic Categories
-- Topic Icons

REQUIREMENTS
------------
1) Elgg 1.8.3+
2) hypeFramework 1.8.5

INTEGRATION / COMPATIBILITY
---------------------------
-- hypeForum plays nicely with all other hypeJunction plugins and can be extended to include additional features

INSTALLATION
------------
-- Standard installation procedure

USER GUIDE
----------

BUG REPORTS
-----------
Bugs and feature requests can be submitted at:
http://hypeJunction.com/trac

