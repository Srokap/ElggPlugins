<div class="contentWrapper">
<div align="center">

<?php
echo "<iframe src='$CONFIG->wwwroot/mod/farm/farm/farm.swf"."' width='900' height='566'></iframe>";
?>


</div>
</div>