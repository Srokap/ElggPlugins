<?php
		function farm_init() 
		{
		global $CONFIG;
		add_menu(elgg_echo('farm'), $CONFIG->wwwroot . "mod/farm");
		}
		
	register_elgg_event_handler('init','system','farm_init');

?>