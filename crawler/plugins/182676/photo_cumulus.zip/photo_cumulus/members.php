<?php

	/**
	 * Photo Cumulus
	 * 
	 * @package photo_cumulus
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Pedro Prez
	 * @version 1.0
	 * @copyright 2009
	 * @link http://www.pedroprez.com.ar/
	 * @link Profile http://community.elgg.org/pg/profile/pedroprez
	 * 
 	*/

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	global $CONFIG;
	
	$size = get_input('iconsize',null);
	if(is_null($size)){
		
		$size = get_plugin_setting('iconsize','photo_cumulus');
	
		if(!$size)
			$size = PHOTO_CUMULUS_ICONSIZE;
	}
	
	//Get number of user to show
	$usernumber= get_input('usernumber',null);
	if(is_null($usernumber)){
		
		$usernumber = get_plugin_setting('usernumber','photo_cumulus');
	
		if(!$usernumber)
			$usernumber = PHOTO_CUMULUS_USERNUMBER;
	}
	
	$newest_members = get_entities_from_metadata('icontime', '', 'user', '', 0, $usernumber);
	
	if($newest_members){
		
		foreach($newest_members as $member){
		
			$images .= "<image href=\"" . $member->getURL() . "\" >" . $member->getIcon($size) . "</image>"; 
		
		}
		
		if($images){
			$images = "<images>$images</images>";
			
			elgg_set_viewtype('xml');
			page_draw('',trim(str_replace('&', '&amp;', $images)));
			
		}
		
	}
	
?>