<?php

	$background_color = $vars['entity']->background_color;
	$background_transparent = $vars['entity']->background_transparent;
	$show_owner_block = $vars['entity']->show_owner_block;
	$width = $vars['entity']->default_width;
	$height = $vars['entity']->default_height;
	$iconsize = $vars['entity']->iconsize;
	$usernumber = $vars['entity']->usernumber;
	
	if(!$background_color)
		$background_color = PHOTO_CUMULUS_BACKGROUND;
		
	if(!$background_transparent)
		$background_transparent = PHOTO_CUMULUS_BACKGROUND_TRANSPARENT;

	if(!$show_owner_block)
		$show_owner_block = PHOTO_CUMULUS_SHOW_OWNER_BLOCK;

	if(!$width)
		$width = PHOTO_CUMULUS_WIDTH;
		
	if(!$height)
		$height = PHOTO_CUMULUS_HEIGHT;
	
	if(!$iconsize)
		$iconsize = PHOTO_CUMULUS_ICONSIZE;
		
	if(!$usernumber)
		$usernumber = PHOTO_CUMULUS_USERNUMBER;
		
		
	$sizes = array('large'=>elgg_echo('large'),'medium'=>elgg_echo('medium'),'small'=>elgg_echo('small'),'tiny'=>elgg_echo('tiny'));
		
	$body = "<p><label>" . elgg_echo('photo_cumulus:background') . "<br />" . elgg_view('input/text', array('internalname' => 'params[background_color]', 'value' => $background_color)) . "</label></p>";
	$body .= "<p><label>" . elgg_echo('photo_cumulus:backgroundtransparent') . "<br />";
	$body .= "<select name='params[background_transparent]'>
				<option value=\"yes\"" . ($background_transparent == 'yes' ? "selected='yes'" : "") . ">" . elgg_echo('option:yes') . "</option>
				<option value=\"no\"" . ($background_transparent != 'yes' ? "selected='yes'" : "") . ">" . elgg_echo('option:no') . "</option>
			</select></label></p><br />";
	
	$body .= "<p><label>" . elgg_echo('photo_cumulus:showownerblock') . "<br />";
	$body .= "<select name='params[show_owner_block]'>
				<option value=\"yes\"" . ($show_owner_block == 'yes' ? "selected='yes'" : "") . ">" . elgg_echo('option:yes') . "</option>
				<option value=\"no\"" . ($show_owner_block != 'yes' ? "selected='yes'" : "") . ">" . elgg_echo('option:no') . "</option>
			</select></label></p><br />";

	$body .= "<p><label>" . elgg_echo('photo_cumulus:width') . "<br />" . elgg_view('input/text', array('internalname' => 'params[default_width]', 'value' => $width)) . "</label></p>";
	$body .= "<p><label>" . elgg_echo('photo_cumulus:height') . "<br />" . elgg_view('input/text', array('internalname' => 'params[default_height]', 'value' => $height)) . "</label></p>";
	
	
	$body .= "<p><label>" . elgg_echo('photo_cumulus:iconsize') . "<br />" . elgg_view("input/pulldown", array('options_values' => $sizes, 'internalname' => 'params[iconsize]', 'value' => $iconsize));
	//$body .= "<p><label>" . elgg_echo('photo_cumulus:iconsize') . "<br />" . elgg_view('input/text', array('internalname' => 'params[iconsize]', 'value' => $iconsize)) . "</label></p>";
	
	$body .= "<p><label>" . elgg_echo('photo_cumulus:usernumber') . "<br />" . elgg_view('input/text', array('internalname' => 'params[usernumber]', 'value' => $usernumber)) . "</label></p>";
	
	echo $body;
	
?>


<p>
	<a href="<?php echo $vars['url'] ?>mod/photo_cumulus/example.php"><?php echo elgg_echo('photo_cumulus:viewexample'); ?></a>
</p>