<?php

	/**
	 * Photo Cumulus
	 * 
	 * @package photo_cumulus
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Pedro Prez
	 * @version 1.0
	 * @copyright 2009
	 * @link http://www.pedroprez.com.ar/
	 * @link Profile http://community.elgg.org/pg/profile/pedroprez
	 * 
 	*/

	$width = $vars['width'];
	if(!$width)
		$width = '200';

	$height = $vars['height'];
	if(!$height)
		$height = '200';
		
	$background = $vars['background'];
	if(!$background){
		$background = get_plugin_setting('background_color','photo_cumulus');
		
		if(!$background)
			$background = PHOTO_CUMULUS_BACKGROUND;
	}
	
	$background_transparent = $vars['background_transparent'];
	if(!$background_transparent){
		$background_transparent = get_plugin_setting('background_transparent','photo_cumulus');
		
		if(!$background_transparent)
			$background_transparent = PHOTO_CUMULUS_BACKGROUND_TRANSPARENT;
	}
	
	$width = $vars['width'];
	if(!$width){
		$width = get_plugin_setting('default_width','photo_cumulus');
		
		if(!$width)
			$width = PHOTO_CUMULUS_WIDTH;
	}
	
	$height = $vars['width'];
	if(!$height){
		$height = get_plugin_setting('default_height','photo_cumulus');
		
		if(!$height)
			$height = PHOTO_CUMULUS_HEIGHT;
	}
	
	

	$query = array();	
	$iconsize = $vars['iconsize'];
	if($iconsize)
		$query[] = "iconsize=$iconsize";
		
	$usernumber = $vars['usernumber'];
	if($usernumber)
		$query[] = "usernumber=$usernumber";
		
	if(!empty($query))
		$query = '?' . implode('&',$query);
	else
		$query = '';	
	
		
   
?>

	<div class="contentWrapper">
			<object type="application/x-shockwave-flash" data="<?php echo "{$vars['url']}" ?>mod/photo_cumulus/vendors/photowidget.swf" width="<?php echo $width; ?>" height="<?php echo $height; ?>">
				<param name="movie" value="<?php echo "{$vars['url']}" ?>mod/photo_cumulus/vendors/photowidget.swf" />
				<param name="bgcolor" value="#<?php echo $background ?>" />
				<?php 
					if($background_transparent=='yes'){
				?>		
						<param name="wmode" value="transparent" />	
				<?php
					} 
				?>	
				
				<param name="AllowScriptAccess" value="always" />
				<param name="flashvars" value="feed=<?php echo "{$vars['url']}" ?>mod/photo_cumulus/members.php<?php echo $query ?>" />
				<p><?php echo elgg_echo('photo_cumulus:requireflash9') ?></p>
			</object>
	</div>