<?php

	/**
	 * Photo Cumulus
	 * 
	 * @package photo_cumulus
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Pedro Prez
	 * @version 1.0
	 * @copyright 2009
	 * @link http://www.pedroprez.com.ar/
	 * @link Profile http://community.elgg.org/pg/profile/pedroprez
	 * 
 	*/

	//Example
	
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	global $CONFIG;
	
	$title = elgg_echo("photo_cumulus:example");
	
	$body = elgg_view_title($title);
	
	$body .= elgg_view('photo_cumulus/view', array('width' => '800', 'height' => '800'));
	
	$body .= elgg_view('photo_cumulus/view', array('width' => '200', 'height' => '200', 'background' => 'ff00ff', 'usernumber' => '2', 'background_transparent' => 'no'));
    
	
	$body = elgg_view_layout('one_column', $body);
	
	// Finally draw the page
	page_draw($title, $body);
?>