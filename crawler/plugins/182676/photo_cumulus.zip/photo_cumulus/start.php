<?php

	/**
	 * Photo Cumulus
	 * 
	 * @package photo_cumulus
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Pedro Prez
	 * @version 1.0
	 * @copyright 2009
	 * @link http://www.pedroprez.com.ar/
	 * @link Profile http://community.elgg.org/pg/profile/pedroprez
	 * 
 	*/

	
	//Defaul Settings
		define('PHOTO_CUMULUS_BACKGROUND','FFFFFF');
		define('PHOTO_CUMULUS_BACKGROUND_TRANSPARENT','yes');
 		define('PHOTO_CUMULUS_SHOW_OWNER_BLOCK','yes');
		define('PHOTO_CUMULUS_WIDTH','170');
 		define('PHOTO_CUMULUS_HEIGHT','170');
 		define('PHOTO_CUMULUS_ICONSIZE','medium');
 		define('PHOTO_CUMULUS_USERNUMBER','10');
 	
 		
 	function photo_cumulus_init(){
		
 		$owner_block = get_plugin_setting('show_owner_block','photo_cumulus');
		
		if(!$owner_block)
			$owner_block = PHOTO_CUMULUS_SHOW_OWNER_BLOCK;
			
		if($owner_block == 'yes')
			extend_view('page_elements/owner_block','photo_cumulus/owner_block');
	}
	
	//**BEGIN
	register_elgg_event_handler('init','system','photo_cumulus_init');
?>
