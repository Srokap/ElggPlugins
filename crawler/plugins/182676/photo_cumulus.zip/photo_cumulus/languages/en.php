<?php

	/**
	 * Photo Cumulus
	 * 
	 * @package photo_cumulus
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Pedro Prez
	 * @version 1.0
	 * @copyright 2009
	 * @link http://www.pedroprez.com.ar/
	 * @link Profile http://community.elgg.org/pg/profile/pedroprez
	 * 
 	*/

	$english = array(

	//Messages and Titles
		'photo_cumulus' => 'Photo Cumulus',
		'photo_cumulus:example' => 'Photo Cumulus Example',
		'photo_cumulus:viewexample' => 'View example',
		'photo_cumulus:requireflash9' => "This widget requires Flash Player 9 or better",
	
	/*	Settings	*/
		'photo_cumulus:background' => 'Background Color',
		'photo_cumulus:backgroundtransparent' => 'Background Transparent',
		'photo_cumulus:showownerblock' => 'Show in owner block',
		'photo_cumulus:width' => 'Width',
		'photo_cumulus:height' => 'Height',
		'photo_cumulus:iconsize' => 'Iconsize',
		'photo_cumulus:usernumber' => 'Number of users to show',
	
	);
	
	add_translation("en",$english);

?>