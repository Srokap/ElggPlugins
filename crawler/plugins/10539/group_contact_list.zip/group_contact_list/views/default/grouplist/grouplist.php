<?PHP

	/**
	 * Group Contact List - Plugin
	 * 
	 * @package Group Contact List
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Tomas Feltl
	 * @copyright TFSoft 2008
	 * @link http://www.tfsoft.cz/
	 */

global $CONFIG;

admin_gatekeeper();

$query = "SELECT guid, name FROM {$CONFIG->dbprefix}groups_entity"; 
$result = get_data($query);

//Page Navigation
{
	$groups_per_page = 30;  //groups diplayed per page
	
	$total_groups = count($result);
	echo "<div><b>".elgg_echo("groupclist:totalpages")."</b> ".$total_groups."<br /></div>";
	echo "<i>(Groups <b>deleting</b> is experimental feature only, please, backup database before use it!)</i><br />";
	$page = get_input("page");
	if($page=="")
		$page = 1;
	$total_pages = ceil(floatval($total_groups)/floatval($group_per_page));
	if($page > 1)
		echo "<a href=\"".$vars['url']."pg/group_contact_list/page/".($page - 1)."\">".elgg_echo("groupclist:lastpage")."</a>";
	echo " | ".elgg_echo("groupclist:onpage1")." ".$page." ".elgg_echo("groupclist:onpage2")." ".$total_pages." ".elgg_echo("groupclist:onpage3")." | ";
	if(($total_pages - $page) > 0)
		echo "<a href=\"".$vars['url']."pg/group_contact_list/page/".($page + 1)."\">".elgg_echo("groupclist:nextpage")."</a>";
	echo "<br />";
}

echo "<table class=\"gv_list\"><tr><td><b>Id</b></td><td><b>Name</b></td><td><b>Members</b> (owner bold)</td></tr>";

$offset = ($page-1)*$groups_per_page;

for($i=$offset;$i<$offset+$groups_per_page;$i++)
{
	if ($i < $total_groups) {
      $row = $result[$i];
    	echo "<tr>";
    	echo "<td>".$row->guid." [<a href=\"".$vars['url']."action/group_contact_list/deletegroup?guid=".$row->guid."\">delete</a>]</td>";
      echo "<td><a href=\"{$CONFIG->wwwroot}pg/groups/{$row->guid}\">".$row->name."</a></td>";
    	echo "<td>";
    	echo " [<a href=\"?slct=1&guid=".$row->guid."\">edit</a>]";
       $members = get_group_members($row->guid, $limit = 100, $offset = 0, $site_guid = 0, $count = false);
    	 $members_count = get_group_members($row->guid, $limit = 100, $offset = 0, $site_guid = 0, $count = true);
    	 echo "[".$members_count."] ";
       
       $e_group = get_entity($row->guid);
       //$test = get_group_entity_as_row($row->guid);
       //echo print_r($e_group);
      	foreach ($members as $c_member) {
         if ($e_group->owner_guid == $c_member->guid) {
          echo "<a class=\"u_owner\" href=\"{$CONFIG->wwwroot}pg/profile/{$c_member->username}\">".$c_member->name."</a>, ";
         } else {
          echo "<a href=\"{$CONFIG->wwwroot}pg/profile/{$c_member->username}\">".$c_member->name."</a>, ";
         }
        }
       $members = ""; 
      echo "</td>";
    	echo "</tr>";
	}
}

echo "</table>";

?>