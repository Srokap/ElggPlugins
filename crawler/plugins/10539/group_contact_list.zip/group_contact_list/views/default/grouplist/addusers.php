<?PHP

	/**
	 * Group Contact List - Plugin
	 * 
	 * @package Group Contact List
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Tomas Feltl
	 * @copyright TFSoft 2008
	 * @link http://www.tfsoft.cz/
	 */

global $CONFIG;

admin_gatekeeper();

// Get the Group 
$guid = get_input('guid');
$obj = get_entity($guid);
	
if ( ($obj instanceof ElggGroup) && ($obj->canEdit())) {
  //print group info 
  echo "<div>Select/unselect users for group: <b>".$obj->name."</b><br /><i>(This is experimental feature only, please, backup database before use it!)</i></div>";
  //get group owner id
  $g_owner = get_entity($obj->guid)->owner_guid;
  //echo print_r($g_owner);  
  
  //list all users
  $query = "SELECT guid, name, username FROM {$CONFIG->dbprefix}users_entity ORDER BY username"; 
  $result = get_data($query);
  echo "<div><form action=\"".$vars['url']."action/group_contact_list/modusergroup\" method=\"post\">";
  //echo "<div><form enctype=\"text/plain\" action=\"".$vars['url']."mod/group_contact_list/actions/admin/group/modusergroup.php\" method=\"post\">";
  foreach ($result as $e_user) {
    //is user group member?
    $checked_start = 0;
    $checked = "";
    if (is_group_member($obj->guid,$e_user->guid)) { 
      $checked = "checked";
      $checked_start = 1; 
    }
    //is user owner?
    //hide group owner from list
    if ($g_owner != $e_user->guid) {
      echo "<span class=\"select_user\" title=\"".$e_user->username."\">[<input class=\"gv_select\" type=\"checkbox\" name=\"uid[]\" value=\"".$e_user->guid."\" ".$checked." />&nbsp;".$e_user->name."]</span> \n";
      echo "<input type=\"hidden\" name=\"cuid[".$checked_start."][]\" value=\"".$e_user->guid."\" /> \n";
    }  
  }
  echo "<input type=\"hidden\" name=\"guid\" value=\"".$obj->guid."\" />";
  echo "<br /><input type=\"submit\" accept=\"text/html\" value=\"Submit\">";
  echo "</form></div>"; 
}
?>