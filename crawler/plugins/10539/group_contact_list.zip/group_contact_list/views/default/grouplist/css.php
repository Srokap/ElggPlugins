<?php

	/**
	 * Group Contact List - Plugin
	 * 
	 * @package Group Contact List
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Tomas Feltl
	 * @copyright TFSoft 2008
	 * @link http://www.tfsoft.cz/
	 */
?>

/* tables still need cellspacing="0" (for ie6) */
.gv_list {
	margin-top: 10px;
  border: 1px solid #333333;
	border-collapse: collapse;
	width: 655px;
}

.gv_list td, .gv_list tr {
  border: 1px solid #333333;
  border-collapse: collapse;
  padding: 3px; 
}

.u_owner {
  color: #be4f21 !important;
  font-weight: bold;
}

.gv_select{
 background: none;
 border:none;
 vertical-align: middle;;
}

.select_user {
 background-color: #fcd18e;
 padding: 0 2px 2px 2px; 
}