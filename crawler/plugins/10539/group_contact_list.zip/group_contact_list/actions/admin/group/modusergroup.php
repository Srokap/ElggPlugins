<?php

	/**
	 * Group Contact List Actions - Plugin
	 * 
	 * @package Group Contact List
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Tomas Feltl
	 * @copyright TFSoft 2008
	 * @link http://www.tfsoft.cz/
	 */
	 
	require_once(dirname(dirname(dirname(dirname(dirname(dirname(__FILE__)))))) . "/engine/start.php");

	global $CONFIG;
	
	// block non-admin users
	admin_gatekeeper();
	
	// Get the Group 
	$guid = get_input('guid');
	$obj = get_entity($guid);
  // Get Users checkboxes output Array
  $uid = get_input('uid');	
  // Get Users checkboxes input Array;
  $cuid = get_input('cuid');

  //echo $guid.'<br />';
  //echo print_r($obj).'<br />';
  //echo print_r($uid).'<br />';
  //echo print_r($cuid).'<br />';
  	
	if (($obj instanceof ElggGroup) && ($obj->canEdit()))
	{
      $leave_err == 0;
      
      foreach ($cuid[1] as $c_cuid) {
        //prochazim puvodne zapnuta policka a hledam nejake vypnute
        //pokud najdu, tak uzivatele vyradim ze skupiny  
        if (!in_array($c_cuid, $uid) && is_group_member($obj->guid,$c_cuid)) {
          $result = leave_group($obj->guid,$c_cuid);
          if (!$result) {
            $leave_err = 1;
            break;
          } 
        }   		
      }
      if ($leave_err == 0) {  	
         foreach ($uid as $c_uid) {
           //Test checkbox state and input state
           //Is user group member now?
           if (!is_group_member($obj->guid,$c_uid)) {
             $result = join_group($obj->guid,$c_uid);
             if (!$result) break;
           }   		
         }
      }   		

      if ($result) {
  			system_message(elgg_echo('groupclist:addmember:yes'));
      } else {
  			register_error(elgg_echo('groupclist:addmember:no'));
  	  }
  } else {
     register_error(elgg_echo('groupclist:addmember:no'));	
	}
	
	forward($_SERVER['HTTP_REFERER']);

?>