<?php

	/**
	 * Group Contact List Actions - Plugin
	 * 
	 * @package Group Contact List
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Tomas Feltl
	 * @copyright TFSoft 2008
	 * @link http://www.tfsoft.cz/
	 */
	 
	require_once(dirname(dirname(dirname(dirname(dirname(dirname(__FILE__)))))) . "/engine/start.php");

	global $CONFIG;
	
	// block non-admin users
	admin_gatekeeper();
	
	// Get the Group 
	$guid = get_input('guid');
	$obj = get_entity($guid);
	
	if ( ($obj instanceof ElggGroup) && ($obj->canEdit()))
	{
    
    // delete extra group data
    $result = delete_group_entity($obj->getGUID());
    if ($result)
      $result = delete_entity($obj->getGUID()); 		
		
		if ($result)
			system_message(elgg_echo('groupclist:delete:yes'));
		else
			register_error(elgg_echo('groupclist:delete:no'));
	}
	else
		register_error(elgg_echo('groupclist:delete:no'));	
	
	forward($_SERVER['HTTP_REFERER']);

?>