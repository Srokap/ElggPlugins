<?php
	/**
	 * Group Contact List - Plugin
	 * 
	 * @package Group Contact List
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Tomas Feltl
	 * @copyright TFSoft 2008
	 * @link http://www.tfsoft.cz/
	 */

$english = array(
		'groupclist:title' => 'Group Contact List',
		'groupclist:title_users' => 'Group Contact List: select/unselect group users',
		'groupclist:lastpage' => '<< Last Page',
		'groupclist:nextpage' => 'Next Page >>',
		'groupclist:totalpages' => 'Total Groups:',
		'groupclist:onpage1' => 'displaying page',
		'groupclist:onpage2' => 'of',
		'groupclist:onpage3' => 'total pages',
		'groupclist:delete:yes' => 'Group deleted',
		'groupclist:delete:no' => 'Error: Group not deleted',
    'groupclist:addmember:yes' => 'All selected users are now group members',
		'groupclist:addmember:no' => 'Error adding user to group',
		);

add_translation("en",$english);
?>