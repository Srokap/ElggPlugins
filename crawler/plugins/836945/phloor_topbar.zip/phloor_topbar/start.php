<?php

elgg_register_event_handler('init',      'system', 'phloor_topbar_init');
elgg_register_event_handler('pagesetup', 'system', 'phloor_topbar_pagesetup');

function phloor_topbar_init() {
    /**
     * Internal JS
     */
    //elgg_extend_view('page/elements/foot', 'phloor_topbar/js/foot', 501);

    /**
     * Internal CSS
     */
    elgg_extend_view('css/elgg', 'phloor_topbar/css/elements/layout',     501);
    elgg_extend_view('css/elgg', 'phloor_topbar/css/elements/navigation', 502);
    elgg_extend_view('css/elgg', 'phloor_topbar/css/misc',                503);
    elgg_extend_view('css/elgg', 'phloor_topbar/css/topbar_menu',         504);
}

/**
 * setup topbar menutimes
 */
function phloor_topbar_pagesetup() {
    /**
     *  unregister elgg-logo
     */
    elgg_unregister_menu_item('topbar', 'elgg_logo');

    // add phloor quick link
    $enable_phloor_topbar_plugin_link = elgg_get_plugin_setting('enable_phloor_topbar_plugin_link', 'phloor_topbar');
    if(elgg_is_admin_logged_in() && strcmp('true', $enable_phloor_topbar_plugin_link) == 0) {
        elgg_register_menu_item('topbar', array(
			'name' => 'phloor_plugins',
			'href' => 'admin/plugins?category=PHLOOR&sort=priority',
			'text' => elgg_view_icon('settings-alt') . elgg_echo('admin:plugins:category:PHLOOR'),
			'section' => 'alt',
    	    'priority' => 2
        ));
    }

    // add search input form
    $enable_search_input = elgg_get_plugin_setting('enable_search_input', 'phloor_topbar');
    if(strcmp('true', $enable_search_input) == 0) {
        elgg_register_menu_item('topbar', array(
    		'name' => 'search',
    		'href' => false,
    		'text' => elgg_view('search/search_box', array('class' => 'phloor-search-topbar')),
    		'section' => 'alt',
    	    'priority' => 1
        ));
    }

    // add drop-down login
    $enable_dropdown_login_link = elgg_get_plugin_setting('enable_dropdown_login_link', 'phloor_topbar');
    if(strcmp('true', $enable_dropdown_login_link) == 0) {
        elgg_register_menu_item('topbar', array(
    		'name' => 'login',
    		'href' => false,
    		'text' => elgg_view('phloor_topbar/core/account/login_dropdown'),
    		'section' => 'alt',
    	    'priority' => 999
        ));
    }
}