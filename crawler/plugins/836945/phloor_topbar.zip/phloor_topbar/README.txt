/**
 * Phloor Topbar¹
 * 
 * @package phloor_topbar
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author void <void@13net.at>
 * @copyright 2012 by 13net
 * @link http://www.13net.at
 */

/**
 * Description
 */
Enables a stylish topbar on your Elgg site.

This plugin enables a topbar that integrates well with the default theme 
but can also be adapted to your specific requirements very easily.

The admin can enable/disable following elements:
* Login link (only visible for not logged in users/guests)
* Search field
* Quick link to phloor plugins

/**
 * Languages
 */
English
German


