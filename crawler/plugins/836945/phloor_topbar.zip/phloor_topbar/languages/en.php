<?php

$english = array(
	'phloor_topbar' => 'phloorTopbar',

	'phloor_topbar:settings:enable_phloor_topbar_plugin_link' => 'Display "PHLOOR Plugins" link? ',
	'phloor_topbar:settings:enable_phloor_topbar_plugin_link:description' => ' (only visible to admins)',

	'phloor_topbar:settings:enable_dropdown_login_link' => 'Display a dropdown login form? ',
	'phloor_topbar:settings:enable_dropdown_login_link:description' => ' (only visible to not logged in users/guests)',

	'phloor_topbar:settings:enable_search_input' => 'Display a search input field? ',
	'phloor_topbar:settings:enable_search_input:description' => ' ',
);

add_translation("en", $english);
