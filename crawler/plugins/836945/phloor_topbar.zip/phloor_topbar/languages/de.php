<?php

$german = array(
	'phloor_topbar' => 'phloorTopbar',

	'phloor_topbar:settings:enable_phloor_topbar_plugin_link' => '"PHLOOR Plugins"-Link anzeigen? ',
	'phloor_topbar:settings:enable_phloor_topbar_plugin_link:description' => ' (nur für Administratoren sichtbar)',

	'phloor_topbar:settings:enable_dropdown_login_link' => 'Dropdown Login-Formular anzeigen? ',
	'phloor_topbar:settings:enable_dropdown_login_link:description' => ' (nur füg ausgeloggte User/Gäste sichtbar)',

	'phloor_topbar:settings:enable_search_input' => 'Suchfeld anzeigen? ',
	'phloor_topbar:settings:enable_search_input:description' => ' ',
);

add_translation("de", $german);
