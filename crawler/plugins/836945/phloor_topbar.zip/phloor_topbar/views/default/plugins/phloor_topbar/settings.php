<?php 
/*****************************************************************************
 * Phloor                                                                    *
 *                                                                           *
 * Copyright (C) 2011, 2012 Alois Leitner                                    *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php

$enable_phloor_topbar_plugin_link = $vars['entity']->enable_phloor_topbar_plugin_link;
$enable_dropdown_login_link       = $vars['entity']->enable_dropdown_login_link;
$enable_search_input              = $vars['entity']->enable_search_input;

if (strcmp('true', $enable_phloor_topbar_plugin_link) != 0) {
	$enable_phloor_topbar_plugin_link = 'false';
}
if (strcmp('true', $enable_dropdown_login_link) != 0) {
	$enable_dropdown_login_link = 'false';
}
if (strcmp('true', $enable_search_input) != 0) {
	$enable_search_input = 'false';
}

?>
<?php 

echo '<div style="padding:13px;">';

echo elgg_echo('phloor_topbar:settings:enable_phloor_topbar_plugin_link'); 
echo elgg_view('phloor/input/enable', array(
	'name' => 'params[enable_phloor_topbar_plugin_link]',
	'value' => $enable_phloor_topbar_plugin_link,
));
	
echo elgg_echo('phloor_topbar:settings:enable_phloor_topbar_plugin_link:description'); 

echo '</div>';


echo '<div style="padding:13px;">';

echo elgg_echo('phloor_topbar:settings:enable_dropdown_login_link'); 
echo elgg_view('phloor/input/enable', array(
	'name' => 'params[enable_dropdown_login_link]',
	'value' => $enable_dropdown_login_link,
));
	
echo elgg_echo('phloor_topbar:settings:enable_dropdown_login_link:description'); 

echo '</div>';


echo '<div style="padding:13px;">';

echo elgg_echo('phloor_topbar:settings:enable_search_input'); 
echo elgg_view('phloor/input/enable', array(
	'name' => 'params[enable_search_input]',
	'value' => $enable_search_input,
));
	
echo elgg_echo('phloor_topbar:settings:enable_search_input:description'); 

echo '</div>';
