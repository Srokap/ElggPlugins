<?php 
?>

.elgg-page-topbar {
	border-bottom: 1px solid #2D2D2D;
	z-index: 9000;
	position: relative;
	/*position:fixed;
	width:100%;*/

    height:30px;
    background:#2D2D2D;
}
.elgg-page-topbar > .elgg-inner {
	padding: 0 10px;
}
