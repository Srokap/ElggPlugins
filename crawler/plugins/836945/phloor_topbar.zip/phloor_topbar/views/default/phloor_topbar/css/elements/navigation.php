<?php 
?>

.elgg-menu-topbar {
	float: left;
	
	list-style:none;
    margin:0;
    padding:0 0 0 10px;
}

.elgg-menu-topbar li {
	padding:0;
	float:left;
	height:30px;
}

.elgg-menu-topbar > li {
	float: left;
	margin-left:1px;
	margin-right:1px;
}
	
.elgg-menu-topbar > li > a {
    margin-top: 1px;    
    padding-top: 5px;
}

.elgg-menu-topbar-default > li > a,
.elgg-menu-topbar-alt > li > a {
    color: #EEEEEE;
    margin-bottom: 0;
    margin-left: 5px;
    margin-right: 5px;
    margin-top: 1px;
    padding-left: 10px;
    padding-right: 10px;
    padding-top: 7px;
}

.elgg-menu-topbar-alt > li > a {
    height:21px;
	text-decoration:none;
	display:block;
	position:relative;
	color: white;
}
.elgg-menu-topbar-alt > li > a:hover {
	background-color:#4690D6;
	text-decoration:none;    
	border-bottom-left-radius: 6px;
    border-bottom-right-radius: 6px;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
}

.elgg-menu-topbar-default > li:hover {
    background-color:#2d2d2d;
    -webkit-box-shadow:1px 0 1px 1px #CCC;
    -moz-box-shadow:1px 0 1px 1px #CCC;
    box-shadow:1px 0 1px 1px #CCC;
}

.elgg-menu-topbar-default > li:hover > a,
.elgg-menu-topbar-alt > li:hover > a{
	text-decoration: none;
    color:#EEEEEE;
}

.elgg-menu-topbar-alt {
	float: right;
}

.elgg-menu-topbar .phloor-icon {
	margin-top: -3px;
}

.elgg-menu-topbar > li > a.elgg-topbar-avatar {
	width: 18px;
	height: 18px;
}

.elgg-menu-topbar-more > li:hover {
	box-shadow:0 0 0;
}

.elgg-menu-topbar-more > li > a:hover {
	text-decoration: none;
    color:#4690D6;
}

.elgg-menu-topbar-more > li:hover {
    background-color:#2d2d2d;
}

.elgg-menu-topbar-default > li.elgg-state-selected,
.elgg-menu-topbar-alt > li.elgg-state-selected, {
    border-top:2px solid #4690D6;
    border-bottom:0;
    height:28px;
    color:#FFFFFF;
    font-weight:bold;
}
