<?php 
/*****************************************************************************
 * Phloor Menuitem                                                           *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php 
/**
 * Topbar Dropdown Menu
 */
?>
ul.elgg-menu-topbar > li > ul {
	display:none;
    position: absolute;
    min-width: 300px;
    margin-top: 3px;
}
ul.elgg-menu-topbar > li > ul li {
    min-width: 200px;
}

ul.elgg-menu-topbar > li:hover > ul,
ul.elgg-menu-topbar > li > ul:hover,
ul.elgg-menu-topbar > li > ul li:hover,
ul.elgg-menu-topbar > li > ul li a:hover {
	display:block;

}

ul.elgg-menu-topbar > li > ul  li {
    height: 26px;
    background-color: #2d2d2d;
    margin: 0;
}

ul.elgg-menu-topbar > li > ul > li {    
    -webkit-box-shadow:1px 1px 1px 1px #CCCCCC;
    -moz-box-shadow:1px 1px 1px 1px #CCCCCC;
    box-shadow:1px 1px 1px 1px #CCCCCC;
}

ul.elgg-menu-topbar li ul > li > a {
    font-weight: bold;
    height: 23px;
    padding-bottom: 0;
    padding-left: 13px;
    padding-right: 13px;
    padding-top: 3px;
    margin:0;
    color: #eee;
}

ul.elgg-menu-topbar li ul > li:hover > a,
ul.elgg-menu-topbar li ul > li > a:hover {
    color:#4690D6;
    text-decoration: none;
}

ul.elgg-menu-topbar li ul > li:last-child,
ul.elgg-menu-topbar li ul > li:last-child > a, 
ul.elgg-menu-topbar li ul > li:last-child > a:hover {
    border-bottom-left-radius: 6px;
    border-bottom-right-radius: 6px;
    border-top-left-radius: 0;
    border-top-right-radius: 0;
}

