<?php 
/*****************************************************************************
 * Phloor Menuitem                                                           *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php 
/**
 * Login Dropdown Menu
 */
?>
#phloor-login-dropdown {
    margin-top:4px;
	right:0;
	z-index:9001;
	color:#EEEEEE;
}
.elgg-module-dropdown {
	z-index:9002;
}
#phloor-login-dropdown > a.elgg-button-dropdown:hover {
	background-color:#4690D6;
	border:0;
	color: #333;
	text-decoration:none;
}

#phloor-login-dropdown > a.elgg-state-active {
	background: #ccc;
	outline: none;
	color: #333;
	margin-top: 6px;
	border:0;
	/*border-bottom:1px solid #ccc;*/
	
	border-bottom-left-radius: 0;
    border-bottom-right-radius: 0;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
}
<?php 
/**
 * Topbar Search From
 */
?>
.phloor-search-topbar {
	margin: 5px 25px 0 15px;
	height: 23px;
}

.elgg-search.phloor-search-topbar input[type=text] {	
	border: 1px solid #ccc;
}