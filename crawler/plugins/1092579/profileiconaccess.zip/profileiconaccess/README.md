profileiconaccess
=================

Provides access controls for user icons