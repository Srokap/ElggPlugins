<?php

$english = array(
    'profileiconaccess:label' => 'Who can see your avatar?',
    'profileiconaccess:current:access' => 'Current access: %s',
    'profileiconaccess:error' => 'An error has occurred, your avatar access has not been saved',
    'profileiconaccess:success' => 'Avatar access has been saved'
);
					
add_translation("en",$english);
