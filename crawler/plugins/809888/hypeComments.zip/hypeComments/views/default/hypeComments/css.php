.river_item .river_item_useravatar {
margin-right:2%;
width:45px;
}

.river_item_body_wrapper {
}

.river_item:hover {
background:none;
}

.river_item p {
padding-left:0px;
}

p.river_item_body {
font-size:0.9em;
line-height:1.1em;
color:#808080;
min-height:40px;
}

.river_item_body a {
font-weight:bold;
}

.river_content_display {
margin:8px 12px;
padding:4px 8px;
border-left:2px solid #e4e4e4;
font-size:0.9em;
}

.hypeComments_item_extras_bar {
min-height:16px;
vertical-align:middle;
font-size:0.8em;
color:#808080;
margin:5px 0;
}

.hypeComments_item_extras_bar a {
}

.hypeComments_item_extras_bar a:hover {
text-decoration:underline;
}

.hypeComments_item_time {
padding-top:2px;
padding-left:18px;
background:transparent url(<?php echo $vars['url'] ?>mod/hypeComments/graphics/hypeComments/clock.png) no-repeat 0 2px;
height:16px;
line-height:16px;
}

.hypeComments_item_like {
padding-top:2px;
margin-left:10px;
height:16px;
line-height:16px;
}

.hypeComments_item_extras_bar .like {
padding-left:18px;
background:transparent url(<?php echo $vars['url'] ?>mod/hypeComments/graphics/hypeComments/like.png) no-repeat 0 2px;
}

.hypeComments_item_extras_bar .unlike {
padding-left:18px;
background:transparent url(<?php echo $vars['url'] ?>mod/hypeComments/graphics/hypeComments/unlike.png) no-repeat 0 2px;
}

.hypeComments_item_extra_boxes {
margin-top:10px;
width:90%;
}

.hypeComments_item_like_bar {
padding:5px 5px 5px 24px;
background:#f4f4f4 url(<?php echo $vars['url'] ?>mod/hypeComments/graphics/hypeComments/like.png) no-repeat 5px 5px;
min-height:16px;
line-height:16px;
margin:0 0 2px;
width:100%;
}

.hypeComments_item_comments_bar {
padding:5px 5px 5px 24px;
background:#f4f4f4 url(<?php echo $vars['url'] ?>mod/hypeComments/graphics/hypeComments/comments.png) no-repeat 5px 5px;
min-height:16px;
line-height:16px;
margin:0 0 2px;
width:100%;
}

.hypeComments_item_comments {
padding-top:2px;
margin-left:10px;
padding-left:18px;
background:transparent url(<?php echo $vars['url'] ?>mod/hypeComments/graphics/hypeComments/comments.png) no-repeat 0 2px;
height:16px;
line-height:16px;
}

.hypeComments_item_comments_container {

}

.hypeComments_item_comment {
padding:5px 24px 5px 5px;
background:#f4f4f4;
min-height:16px;
line-height:16px;
margin:0 0 2px;
width:100%;
}

.hypeComments_item_comment_content {
max-width:85%;
}

.hypeComments_item_comment_icon {
padding:3px 10px 3px 3px;
}

.hypeComments_item_comment_value {
color:#333333;
font-size:1.1em;
}

.hypeComments_item_comment_owner {
padding-right:8px;
font-size:1.1em;
font-weight:bold;
}

.hypeComments_item_share {
padding-top:2px;
margin-left:10px;
padding-left:18px;
background:transparent url(<?php echo $vars['url'] ?>mod/hypeComments/graphics/hypeComments/share.png) no-repeat 0 2px;
height:16px;
line-height:16px;
}

.comment_delete {
margin-left:15px;
}

.following_icon {
width:20px;
height:40px;
margin:0 2px 0 2px;
background: url(<?php echo $vars['url']; ?>mod/hypeComments/graphics/hypeComments/follow_icon.png) no-repeat left top;
}

.small_ajax_loader {
width:16px;
height:16px;
display:block;
background:transparent url(<?php echo $vars['url'] ?>mod/hypeComments/graphics/hypeComments/ajax-loader.gif) no-repeat;
}

.hypeComments_small_button {
font-size:.9em;
color:#666666;
font-weight:bold;
}

.left {
float:left;
}

.right {
float:right;
}


