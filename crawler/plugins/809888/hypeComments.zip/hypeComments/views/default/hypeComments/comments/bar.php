<?php
if (isloggedin ()) {
    $object = $vars['entity'];
?>

<?php
    if ($object instanceof ElggObject) {
        $page_owner = page_owner_entity();
?>
        <div id="<?php echo $object->guid ?>" class="hypeComments_item_extras_bar">
            <div class="hypeComments_item_like left"><a href="javascript:void(0)"></a></div>

    <?php if (!$page_owner instanceof ElggGroup || ($page_owner instanceof ElggGroup && $page_owner->isMember(get_loggedin_user()))) {
 ?>
            <div class="hypeComments_item_comments left"><a href="javascript:void(0)"><?php echo elgg_echo('hypeComments:commentsbutton') ?></a></div>
<?php } ?>
        <!--
        <div class="hypeComments_item_share left"><?php echo elgg_echo('hypeComments:sharebutton') ?></div>
        -->

        <div class="clearfloat"></div>
        <div class="hypeComments_item_extra_boxes">
            <div class="hypeComments_item_like_bar"></div>
            <div class="hypeComments_item_comments_bar"></div>
            <div class="hypeComments_item_comments_container" style="display:none"></div>
        </div>
        <div class="clearfloat"></div>
    </div>
<?php
    }
}
?>
