<script type="text/javascript">

    function riverOnLoad() {
        refreshLikes();
        refreshComments();

        //timedRefresh(15000);
        
        var bar = $('div.hypeComments_item_extras_bar');
        bar.each(function(key){
            var id = $(this).attr('id');
            var commentsContainer = $('.hypeComments_item_comments_container', $(this));
            //commentsContainer.hide();

            var commentButton = $('.hypeComments_item_comments', $(this));
            commentButton.click(function(){
                commentsContainer.toggle();
            });
        });
    }

    function getLikes(guids) {
        var bar = $('div.hypeComments_item_extras_bar');
        var temp;
        $.ajax ({
            url: '<?php echo elgg_add_action_tokens_to_url($vars['url'] . 'action/comments/get_likes') ?>',
            type: 'GET',
            //async: false,
            dataType: 'json',
            data: {
                guids: guids.join(',')
            },
            success: function(likes) {
                bar.each(function(key){
                    var id = $(this).attr('id');
                    var likesContainer = $('.hypeComments_item_like_bar', $(this));

                    var likesButtonContainer = $('.hypeComments_item_like', $(this));
                    var current_user = '<?php echo get_loggedin_user()->name ?>';
                    var current_likes = likes[key].likes;
                    var like_status = false;

                    if (current_likes instanceof Object) {
                        for (var i=0; i<current_likes.length;i++) {
                            if (current_likes[i].username == current_user) {
                                like_status = true;
                            }
                        }
                    }
                    if (like_status) {
                        likesButtonContainer.removeClass('like').addClass('unlike');
                        likesButtonContainer.children('a').html('<?php echo elgg_echo('hypeComments:unlikebutton') ?>');
                        likesButtonContainer.unbind().click(function(){
                            unlikeIt(id);
                        });
                    } else {
                        likesButtonContainer.removeClass('unlike').addClass('like');
                        likesButtonContainer.children('a').html('<?php echo elgg_echo('hypeComments:likebutton') ?>');
                        likesButtonContainer.unbind().click(function(){
                            likeIt(id);
                        });
                    }

                    getObjectLikes(likes, key, likesContainer);
                });
            }
        });
        //return temp;
    }

    function getObjectLikes(likes, key, result_container) {
        var objectLikes = likes[key].likes;
        if (objectLikes instanceof Object) {
            var text = getLikesLanguage(objectLikes);
            result_container.html(text[0]);
            $('a.likes_short', result_container).click(function() {
                $(this).html(text[1]);
            });
        } else {
            result_container.hide();
        }
    }

    function getLikesLanguage(likes) {
        var text_owner = '<?php echo elgg_echo('hypeComments:lang:you') ?> ';
        var text_and = '<?php echo elgg_echo('hypeComments:lang:and') ?>';
        var text_others = '<?php echo elgg_echo('hypeComments:lang:others') ?>';
        var text_others_one = '<?php echo elgg_echo('hypeComments:lang:othersone') ?>';
        var text_people = '<?php echo elgg_echo('hypeComments:lang:people') ?>';
        var text_people_one = '<?php echo elgg_echo('hypeComments:lang:peopleone') ?>';
        var text_likethis = ' <?php echo elgg_echo('hypeComments:lang:likethis') ?>';
        var text_likesthis = ' <?php echo elgg_echo('hypeComments:lang:likesthis') ?>';
        
        var current_user = '<?php echo get_loggedin_user()->name ?>';

        var prefix = '';
        var html = new Array();
        $.each(likes, function(key, val) {
            if (likes[key].username == current_user) {
                prefix = text_owner;
            } else {
                html.push('<span class="likes_names"><a href="' + likes[key].url + '">' + likes[key].username + '</a></span>');
            }
        });

        var string = '';
        var likes_long = html.join(', ');

        if (prefix !== '' && html.length == 0) {
            string = prefix + text_likethis;
        } else if (prefix !== '' && html.length == 1) {
            var likes_short = '<a class="likes_short" href="javascript:void(0)">' + html.length + ' ' + text_others_one + '</a>';
            string = prefix + text_and + likes_short + text_likethis;
        } else if (prefix !== '' && html.length > 1) {
            var likes_short = '<a class="likes_short" href="javascript:void(0)">' + html.length + ' ' + text_others + '</a>';
            string = prefix + text_and + likes_short + text_likethis;
        } else if (prefix == '' && html.length == 1) {
            var likes_short = '<a class="likes_short" href="javascript:void(0)">' + html.length + ' ' + text_people_one + '</a>';
            string = likes_short + text_likesthis;
        } else if (prefix == '' && html.length > 1) {
            var likes_short = '<a class="likes_short" href="javascript:void(0)">' + html.length + ' ' + text_people + '</a>';
            string = likes_short + text_likethis;
        }
        
        var result = [string, likes_long];
        return result;
    }
    
    function likeIt(guid) {
        $.ajax ({
            url: '<?php echo elgg_add_action_tokens_to_url($vars['url'] . 'action/comments/like') ?>',
            type: 'POST',
            dataType: 'json',
            data: {
                guid: guid
            },
            success: function(data) {
                refreshLikes();
            }
        });   
    }

    function unlikeIt(guid) {
        $.ajax ({
            url: '<?php echo elgg_add_action_tokens_to_url($vars['url'] . 'action/comments/unlike') ?>',
            type: 'GET',
            dataType: 'json',
            data: {
                guid: guid
            },
            success: function(data) {        
                refreshLikes();
            }
        });
    }

    function getComments(guids) {
        var bar = $('div.hypeComments_item_extras_bar');
        var temp;
        $.ajax ({
            url: '<?php echo elgg_add_action_tokens_to_url($vars['url'] . 'action/comments/get_comments') ?>',
            type: 'GET',
            async: false,
            dataType: 'json',
            data: {
                guids: guids.join(',')
            },
            success: function(comments) {
                bar.each(function(key) {
                    var id = $(this).attr('id');
                    var commentsBar = $('.hypeComments_item_comments_bar', $(this));
                    var commentsContainer = $('.hypeComments_item_comments_container', $(this));
                    getObjectComments(comments, key, commentsBar, commentsContainer);
                });
            }
        });
        return temp;
    }

    function getObjectComments(comments, key, comments_bar, comments_container) {
        var objectComments = comments[key].comments;
        var objectCommentInput = comments[key].input;
        var new_comment = objectCommentInput;
        comments_container.html(new_comment);
        bindNewComment(comments_container);
        if (objectComments instanceof Object) {
            var html = showComments(objectComments);
            comments_container.html(html[1] + new_comment);
            if (html[0] !== '') {
                comments_bar.html(html[0]);
                comments_bar.unbind().click(function(){
                    //$(this).hide();
                    comments_container.html(html[2] + html[1] + new_comment).show();
                    bindDelete(comments_container);
                    bindNewComment(comments_container);
                });
            } else {
                comments_bar.hide();
            }
            comments_container.show();
            bindDelete(comments_container);
            bindNewComment(comments_container);
        } else {
            comments_bar.hide();
        }
    }

    function showComments(comments) {
        var comments_array = new Array();
        $.each(comments, function(key, val){
            comments_array.push('<div id="' + comments[key].id + '" class="hypeComments_item_comment">' +
                '<div class="hypeComments_item_comment_icon left">' + comments[key].icon + '</div>' +
                '<div class="hypeComments_item_comment_content left">' + comments[key].owner +
                '<div class="hypeComments_item_comment_value left">' + comments[key].text + '</div>' +
                '<div class="clearfloat"></div>' +
                '<div class="hypeComments_item_comment_extras left><span>' + comments[key].time + '</span>' +
                '<span>' + comments[key].deletebutton + '</span>' +
                '</div>' + '</div>' +
                '<div class="clearfloat"></div>' +
                '</div>');
        });

        var comments_count = comments_array.length;
        var show_all = '<a href="javascript:void(0)" class="hypeComments_item_comments_show_all"><?php echo elgg_echo('hypeComments:viewall') ?> ' + comments_array.length + ' <?php echo elgg_echo('hypeComments:comments') ?>';
        var recent_comments = '';
        var hidden_comments = '';

        var i;
        for (i=0;i<=comments_count-1;i++) {
            if (i == comments_count - 1 || i == comments_count - 2) {
                recent_comments = recent_comments + comments_array[i];
            } else {
                hidden_comments = hidden_comments + comments_array[i];
            }
        }
        if (comments_count <= 2) {
            var result = ['', recent_comments, ''];
            return result;
        } else {
            var result = [show_all, recent_comments, hidden_comments];
            return result;
        }
    }

    function refreshLikes() {
        var bar = $('div.hypeComments_item_extras_bar');

        var guids = new Array();

        bar.each(function(key){
            var id = $(this).attr('id');
            $(this).attr('key', key);
            var ajax_loader = '<div class="small_ajax_loader"></div>';
            var likesContainer = $('.hypeComments_item_like_bar', $(this));
            likesContainer.show().html(ajax_loader);
            guids.push(id);
        });

        getLikes(guids);

        return true;
    }

    function refreshComments() {
        var bar = $('div.hypeComments_item_extras_bar');

        var guids = new Array();

        bar.each(function(key){
            var id = $(this).attr('id');
            $(this).attr('key', key);
            var ajax_loader = '<div class="small_ajax_loader"></div>';
            var commentsBar = $('.hypeComments_item_comments_bar', $(this));
            commentsBar.show().html(ajax_loader);
            guids.push(id);
        });

        getComments(guids);

       
    }

    function bindDelete(comments_bar, comments_container) {
        var deleteButton = $('.comment_delete', comments_container);
        deleteButton.unbind().click(function(){
            deleteComment($(this).attr('id'));
            refreshComments();
        });
    }

    function deleteComment(id) {
        $.ajax ({
            url: '<?php echo elgg_add_action_tokens_to_url($vars['url'] . 'action/comments/delete_comment') ?>',
            type: 'GET',
            async: false,
            dataType: 'json',
            data: {
                id: id
            }
        });
    }

    function bindNewComment(comments_container) {
        var comment_input = $('input[name=hypeComments_item_comment_input]', comments_container);
        var temp_value = comment_input.val();
        comment_input
        .focus(function() {
            $(this).val('');
        })
        .keydown(function(event) {
            if (event.keyCode == '13') {
                if ($(this).val() !== '') {
                    submitNewComment($(this).val(), $(this).attr('id'));
                    refreshComments();
                } else {
                    alert('<?php echo elgg_echo('hypeComments:commentmissing') ?>');
                }
            }
        });
    }

    function submitNewComment(value, entity) {
        $.ajax ({
            url: '<?php echo elgg_add_action_tokens_to_url($vars['url'] . 'action/comments/new_comment') ?>',
            type: 'GET',
            //async: false,
            dataType: 'json',
            data: {
                entity_guid: entity,
                value: value
            }
        });
    }

    function timedRefresh(time) {
        var refresh = setInterval(function(){
            refreshLikes();
            refreshComments();
        }, time);
    }
    
    $(document).ready(function(){
        riverOnLoad();
    });

</script>