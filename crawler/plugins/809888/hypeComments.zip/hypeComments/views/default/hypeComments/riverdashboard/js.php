<script type="text/javascript">
    riverOnLoad();
</script>