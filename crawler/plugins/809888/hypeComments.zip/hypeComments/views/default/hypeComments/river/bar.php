<?php
if (isloggedin ()) {
    $item_id = $vars['item']->id;
    $object_guid = $vars['item']->object_guid;
    $object = get_entity($object_guid);
    $type = $vars['item']->type;
    //elgg_view_comments($entity);
?>

<?php
    if ($type == 'object') {
?>
        <div class="hypeComments_item_like left"><a href="javascript:void(0)"></a></div>

        <div class="hypeComments_item_comments left"><a href="javascript:void(0)"><?php echo elgg_echo('hypeComments:commentsbutton') ?></a></div>

        <!--
        <div class="hypeComments_item_share left"><?php echo elgg_echo('hypeComments:sharebutton') ?></div>
        -->
        
        <div class="clearfloat"></div>
        <div class="hypeComments_item_extra_boxes">
            <div class="hypeComments_item_like_bar"></div>
            <div class="hypeComments_item_comments_bar"></div>
            <div class="hypeComments_item_comments_container" style="display:none"></div>
        </div>
        <div class="clearfloat"></div>

<?php
    }
}
?>
