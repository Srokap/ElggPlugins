<div id="hypeComments_latest_forums">
    <?php
    if ($vars['entity']->isMember(get_loggedin_user())) {
        echo elgg_view('hypeComments/js/group_canvas');
    ?>
        <div id="addNewForumTopicForm" group="<?php echo $vars['entity']->guid ?>" class="contentWrapper" style="display:none"><form>
            <?php
            echo elgg_view('input/text', array(
                'internalname' => 'forum_topic_title',
                'value' => elgg_echo('hypeComments:forumtopictitle'),
                'js' => 'onfocus=$(this).val("")'
            ));
            echo elgg_view('input/text', array(
                'internalname' => 'forum_topic_description',
                'value' => elgg_echo('hypeComments:forumtopicdescription'),
                'js' => 'onfocus=$(this).val("")'
            ));
            ?>
        </form></div>
    <?php
        }
    ?>
    <?php
        $forum = elgg_get_entities_from_annotations(array('types' => 'object', 'subtypes' => 'groupforumtopic', 'annotation_names' => 'group_topic_post', 'container_guid' => $vars['entity']->guid, 'limit' => 5, 'order_by' => 'maxtime desc'));

        if ($forum) {
            foreach ($forum as $f) {
                $count_annotations = $f->countAnnotations("group_topic_post");
                echo "<div class=\"forum_latest\">";
                echo "<div class=\"topic_owner_icon\">" . elgg_view('profile/icon', array('entity' => $f->getOwnerEntity(), 'size' => 'tiny', 'override' => true)) . "</div>";
                echo "<div class=\"topic_title\"><p><a href=\"{$f->getURL()}\">" . $f->title . "</a></p> <p class=\"topic_replies\">" . elgg_view('hypeComments/comments/bar', array('entity' => $f)) . "</p></div>";
                echo "</div>";
            }
        } else {
            echo "<div class=\"forum_latest\">";
            echo elgg_echo("grouptopic:notcreated");
            echo "</div>";
        }
    ?>
</div>