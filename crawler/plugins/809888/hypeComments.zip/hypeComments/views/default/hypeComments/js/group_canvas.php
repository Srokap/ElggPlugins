<script type="text/javascript">

    function sendForumData(form) {
        var input_forum_topic = $('input[name=forum_topic_title]', form);
        var input_forum_desc = $('input[name=forum_topic_description]', form);
        var group_guid = form.attr('group');
        form.children('form').html('<div class="small_ajax_loader"></div>');
        $.ajax ({
            url: '<?php echo elgg_add_action_tokens_to_url($vars['url'] . 'action/comments/new_topic') ?>',
            type: 'POST',
            dataType: 'html',
            data: {
                topictitle: input_forum_topic.val(),
                topicmessage: input_forum_desc.val(),
                group_guid: group_guid
            },
            success: function(data) {
                $('#hypeComments_latest_forums').html(data);
                riverOnLoad();
            }
        });
    }

    $(document).ready(function() {

        var toggle_form_button = $('#addNewForumTopicButton');
        var add_topic_form = $('#addNewForumTopicForm');

        var input_forum_topic = $('input[name=forum_topic_title]', add_topic_form);
        var input_forum_desc = $('input[name=forum_topic_description]', add_topic_form);
        var input_forum_submit = $('submit[name=forum_topic_add_button]', add_topic_form);

        toggle_form_button.click(function(){
            add_topic_form.toggle();
        });

        input_forum_desc.keydown(function(event) {
            if (event.keyCode == '13') {
                var send = true;
                if (input_forum_topic.val() == '') {
                    send = false;
                    alert('<?php echo elgg_echo('hypeComments:topicmissing') ?>');
                }

                if (input_forum_desc.val() == '') {
                    send = false;
                    alert('<?php echo elgg_echo('hypeComments:bodymissing') ?>');
                }
                if (send) {
                    sendForumData(add_topic_form);
                }
            }
        });
    });

</script>
