<?php
/**
 * Elgg river item wrapper.
 * Wraps all river items.
 *
 * @package Elgg
 */
?>
<div class="river_item">
    <span class="river_item_useravatar">
        <?php
        echo elgg_view("profile/icon", array('entity' => get_entity($vars['item']->subject_guid), 'size' => 'small'));
        ?>
    </span>

    <div class="river_item_body_wrapper">
        <p class="river_item_body">
            <?php
            echo $vars['body'];
            ?>
        </p>
        <div id="<?php echo $vars['item']->object_guid ?>" class="hypeComments_item_extras_bar">
            <div class="hypeComments_item_time left">
                <?php
                echo friendly_time($vars['item']->posted);
                ?>
            </div>
            <?php echo elgg_view('hypeComments/river/bar', $vars); ?>
        </div>

    </div>
    <div class="clearfloat"></div>
</div>