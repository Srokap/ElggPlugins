<?php
// Latest forum discussion for the group home page
//check to make sure this group forum has been activated
if ($vars['entity']->forum_enable != 'no') {
?>

    <div class="contentWrapper">
        <h2><?php echo elgg_echo('groups:latestdiscussion'); ?>
        <?php if ($vars['entity']->isMember(get_loggedin_user())) {
 ?>
            <div id="addNewForumTopicButton" class="hypeComments_small_button right"><a href="javascript:void(0)"><?php echo elgg_echo('hypeComments:addtopic') ?></a></div>
            <div class="clearfloat"></div>
<?php } ?>
    </h2>
<?php echo elgg_view('hypeComments/groups/forum_latest', array('entity' => $vars['entity'])); ?>
        <div class="clearfloat" /></div>
    </div>
<?php
    }
?>