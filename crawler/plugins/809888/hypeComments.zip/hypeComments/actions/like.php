<?php
global $CONFIG;
action_gatekeeper();
gatekeeper();

$guid = get_input('guid');
$entity = get_entity($guid);
$user = get_loggedin_userid();

if ($entity instanceof ElggObject) {
    $count_likes = count_annotations($entity->guid, 'object', $entity->getSubtype(), 'likes', 1, '', $user);
    $count_unlikes = count_annotations($entity->guid, 'object', $entity->getSubtype(), 'likes', 0, '', $user);
    if ($count_likes == 0 && $count_unlikes == 0) {
        $result = $entity->annotate('likes', 1, $entity->access_id, $user, $vartype);
    } else if ($count_unlikes > 0) {
        $likes = get_annotations($entity->guid, 'object', $entity->getSubtype(), 'likes', 0, $user, 500);
        if (is_array($likes)) {
            foreach ($likes as $like) {
                $result = update_annotation($like->id, 'likes', 1, '', $user, $entity->access_id);
            }
        }
    }
    print(json_decode($result));
}
die();
?>
