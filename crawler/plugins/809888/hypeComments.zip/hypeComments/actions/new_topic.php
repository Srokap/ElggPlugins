<?php
global $CONFIG;
action_gatekeeper();
gatekeeper();

$group_guid = get_input('group_guid');
$group_entity = get_entity($group_guid);

if ($group_entity->isMember(get_loggedin_user())) {

    $title = strip_tags(get_input('topictitle'));
    $message = get_input('topicmessage');
    $user = get_loggedin_userid();

    $grouptopic = new ElggObject();
    $grouptopic->subtype = "groupforumtopic";
    $grouptopic->owner_guid = $user;
    $grouptopic->container_guid = $group_guid;
    $grouptopic->access_id = get_default_access();
    $grouptopic->title = $title;
    $grouptopic->save();

    $grouptopic->annotate('group_topic_post', $message, $grouptopic->access_id, $user);

    add_to_river('river/forum/topic/create', 'create', get_loggedin_userid(), $grouptopic->guid);
    
}

echo elgg_view('hypeComments/groups/forum_latest', array('entity' => $group_entity));

?>