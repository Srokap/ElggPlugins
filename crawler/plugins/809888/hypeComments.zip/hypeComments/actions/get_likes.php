<?php
global $CONFIG;
action_gatekeeper();
gatekeeper();

$user = get_loggedin_userid();
$guids = explode(',', get_input('guids'));

foreach ($guids as $guid) {
    $entity = get_entity($guid);
    if ($entity instanceof ElggObject) {
        $count = count_annotations($entity->guid, 'object', $entity->getSubtype(), 'likes', 1);
        $annotations = get_annotations($entity->guid, 'object', $entity->getSubtype(), 'likes', 1, "", 500);
        if ($count > 0) {
            foreach ($annotations as $annotation) {
                $owner = get_entity($annotation->owner_guid);
                $object_likes[] = array('username' => $owner->name, 'url' => $owner->getURL());
            }
        }
    }
    $data[] = array('guid' => $entity->guid, 'likes' => $object_likes);
    $object_likes = null;
}
print(json_encode($data));
die();
?>
