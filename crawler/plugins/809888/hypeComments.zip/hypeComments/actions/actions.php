<?php
global $CONFIG;
action_gatekeeper();
gatekeeper();

$action = get_input('action');

switch ($action) {

    case 'get_likes' :
        $guid = get_input('guid');
        $entity = get_entity($guid);
        $user = get_loggedin_userid();

        if ($entity instanceof ElggObject) {
            $count = count_annotations($entity->guid, 'object', $entity->getSubtype(), 'likes', 1, "", 500);
            $annotations = get_annotations($entity->guid, 'object', $entity->getSubtype(), 'likes', 1, "", 500);
            if (is_array($annotations) && $count > 0) {
                foreach ($annotations as $annotation) {
                    $owner = get_entity($annotation->owner_guid);
                    $data[] = array('username' => $owner->name, 'url' => $owner->getURL());
                }
                print(json_encode($data));
            }
        }
        break;

    case 'like':
        $guid = get_input('guid');
        $entity = get_entity($guid);
        $user = get_loggedin_userid();

        if ($entity instanceof ElggObject) {
            $count_likes = count_annotations($entity->guid, 'object', $entity->getSubtype(), 'likes', 1, '', $user);
            $count_unlikes = count_annotations($entity->guid, 'object', $entity->getSubtype(), 'likes', 0, '', $user);
            if ($count_likes == 0 && $count_unlikes == 0) {
                $result = $entity->annotate('likes', 1, $entity->access_id, $user, $vartype);
            } else if ($count_unlikes > 0) {
                $likes = get_annotations($entity->guid, 'object', $entity->getSubtype(), 'likes', 0, $user, 500);
                if (is_array($likes)) {
                    foreach ($likes as $like) {
                        $result = update_annotation($like->id, 'likes', 1, '', $user, $entity->access_id);
                    }
                }
            }
            print(json_decode($result));
        }

        break;

    case 'unlike' :
        $guid = get_input('guid');
        $entity = get_entity($guid);
        $user = get_loggedin_userid();

        if ($entity instanceof ElggObject) {
            $likes = get_annotations($entity->guid, 'object', $entity->getSubtype(), 'likes', 1, $user, 500);
            if (is_array($likes)) {
                foreach ($likes as $like) {
                    $result = update_annotation($like->id, 'likes', 0, '', $user, $entity->access_id);
                }
            }
            print(json_decode($result));
        }
        break;

    case 'get_comments' :
        $guid = get_input('guid');
        $entity = get_entity($guid);

        if ($entity instanceof ElggObject) {
            if (elgg_count_comments($entity) > 0) {
                $comments = get_annotations($entity->guid, "", "", "generic_comment", "", "", 500);
                foreach ($comments as $comment) {
                    $icon = elgg_view('profile/icon', array('entity' => get_entity($comment->owner_guid), 'size' => 'tiny'));
                    if ($entity->canEdit() or $comment->canEdit()) {
                        $delete = '<a href="javascript:void(0)" class="comment_delete">' . elgg_echo('hypeComments:deletecomment') . '</a>';
                    }
                    $details[] = array('id' => $comment->id, 'time' => friendly_time($comment->time_created), 'text' => $comment->value, 'icon' => $icon, 'deletebutton' => $delete);
                }
                print(json_decode($details));
            }
        }


        break;
}

die();
?>
