<?php
global $CONFIG;
action_gatekeeper();
gatekeeper();

$id = get_input('id');

$comment = get_annotation($id);
$entity = get_entity($comment->entity_guid);

if ($comment->canEdit() || $entity->canEdit()) {
    $comment->delete();
}
die();
?>
