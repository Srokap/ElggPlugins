<?php
global $CONFIG;
action_gatekeeper();
gatekeeper();

$value = get_input('value');
$entity_guid = (int) get_input('entity_guid');
$entity = get_entity($entity_guid);

if ($entity instanceof ElggObject) {
    if ($entity->getSubtype() == 'groupforumtopic') {
        $annotation_type = 'group_topic_post';
    } else {
        $annotation_type = 'generic_comment';
    }
    create_annotation($entity->getGUID(), $annotation_type, $value, '', get_loggedin_userid(), $entity->access_id);
}
die();
?>
