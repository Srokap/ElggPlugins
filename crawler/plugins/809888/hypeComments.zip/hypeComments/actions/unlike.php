<?php
global $CONFIG;
action_gatekeeper();
gatekeeper();

$guid = get_input('guid');
$entity = get_entity($guid);
$user = get_loggedin_userid();

if ($entity instanceof ElggObject) {
    $likes = get_annotations($entity->guid, 'object', $entity->getSubtype(), 'likes', 1, $user, 500);
    if (is_array($likes)) {
        foreach ($likes as $like) {
            $result = update_annotation($like->id, 'likes', 0, '', $user, $entity->access_id);
        }
    }
    print(json_decode($result));
}
die();
?>
