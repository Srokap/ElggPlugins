<?php

$english = array(
    'hypeComments:likebutton' => 'Like',
    'hypeComments:unlikebutton' => 'Unlike',
    'hypeComments:commentsbutton' => 'Comment',
    'hypeComments:sharebutton' => 'Share',
    
    'hypeComments:lang:you' => 'You ',
    'hypeComments:lang:and' => 'and ',
    'hypeComments:lang:others' => 'other people ',
    'hypeComments:lang:othersone' => 'other person ',
    'hypeComments:lang:people' => 'people ',
    'hypeComments:lang:peopleone' => 'person ',
    'hypeComments:lang:likethis' => 'like this',
    'hypeComments:lang:likesthis' => 'likes this',

    'hypeComments:count' => 'comments',
    'hypeComments:comments' => 'comments',
    'hypeComments:deletecomment' => 'Delete',
    'hypeComments:viewall' => 'View all',
    'hypeComments:newcomment' => 'Write a comment',

    'hypeComments:addtopic' => 'Add new topic',
    'hypeComments:forumtopictitle' => 'Enter your forum title...',
    'hypeComments:forumtopicdescription' => 'Enter your forum message...',
    'eComents:forumtopicaddbutton' => 'Add',

    'hypeComments:commentmissing' => 'Oh, your comment is missing',
    'hypeComments:bodymissing' => 'Oh, you have not entered any text',
    'hypeComments:topicmissing' => 'Oh, you need to enter a name for your forum topic',
    
    
    
);

add_translation("en", $english);

?>