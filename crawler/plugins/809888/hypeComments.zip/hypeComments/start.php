<?php

/* hype Comments
 *
 * Comments for hype
 * Likes for hype
 *
 * @package hype
 * @subpackage Comments
 *
 * @author Ismayil Khayredinov <ismayil.khayredinov@gmail.com>
 * @copyright Copyrigh (c) 2011, Ismayil Khayredinov
 */

function hypeComments_init() {

    global $CONFIG;
    
    register_action('comments/actions', false, $CONFIG->pluginspath . 'hypeComments/actions/actions.php', false);
    register_action('comments/delete_comment', false, $CONFIG->pluginspath . 'hypeComments/actions/delete_comment.php', false);
    register_action('comments/get_comments', false, $CONFIG->pluginspath . 'hypeComments/actions/get_comments.php', false);
    register_action('comments/get_likes', false, $CONFIG->pluginspath . 'hypeComments/actions/get_likes.php', false);
    register_action('comments/like', false, $CONFIG->pluginspath . 'hypeComments/actions/like.php', false);
    register_action('comments/new_comment', false, $CONFIG->pluginspath . 'hypeComments/actions/new_comment.php', false);
    register_action('comments/new_topic', false, $CONFIG->pluginspath . 'hypeComments/actions/new_topic.php', false);
    register_action('comments/unlike', false, $CONFIG->pluginspath . 'hypeComments/actions/unlike.php', false);

    if (!is_plugin_enabled('hypeFramework')) {
        register_error('hypeFramework is not enabled. hypeComments will not work properly. Visit www.hypeJunction.com for details');
    }
    elgg_extend_view('css', 'hypeComments/css');

    if (isloggedin ()) {
        elgg_extend_view('hypeComments/comments/bar', 'hypeComments/js/canvas');
        //elgg_extend_view('hypeComments/river/bar', 'hypeComments/js/canvas');

        // Extention for summary object views
        //extend_view('object/default', 'hypeComments/comments/bar');
        //$subtypes = get_registered_entity_types('object');
        //if(is_array($subtypes) && sizeof($subtypes) > 0) {
        //    foreach ($subtypes as $subtype) {
        //        extend_view("object/{$subtype}", 'hypeComments/comments/bar');
        //    }
        //}

        elgg_extend_view('hypeStyler/index', 'hypeComments/js/canvas');
        elgg_extend_view('widgets/river_widget/view', 'hypeComments/js/canvas');
        elgg_extend_view('riverdashboard/js', 'hypeComments/js/canvas');
        //elgg_extend_view('riverdashboard/js', 'hypeComments/riverdashboard/js');
    }
    register_plugin_hook('comments', 'all', 'hypeComments_replacement');
    register_plugin_hook('hype:tabs:ajaxsuccess', 'all', 'hypeComments_ajax');
}

function hypeComments_replacement($hook, $entity_type, $returnvalue, $params) {
    if ($entity_type == 'object') {
        return elgg_view('hypeComments/comments/bar', $params);
    }
}

function hypeComments_ajax($hook, $entity_type, $returnvalue, $params) {
    return 'riverOnLoad();';
}

register_elgg_event_handler('init', 'system', 'hypeComments_init');
?>
