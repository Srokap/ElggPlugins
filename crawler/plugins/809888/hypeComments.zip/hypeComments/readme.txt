hypeComments is part of the hypeJunction bundle

hypeComments is a Facebook-style Likes and Commenting functionality. Unlike other plugins available in the Community, hypeComments attaches the comments directly to content objects, thus retaining them for future reference and use.

Main features include:
- Easy and user-friendly approach
- Fully AJAXed real-time functionality - no need to reload pages
- Enhanced user experience with Riverdashboard, Content Comments, Group Discussions

INSTALLATION
1. Download and install hype Framework from www.elgg.org or www.hypeJunction.com
2. Download and install hypeComments

Notes for developers:

You can add the comments to any view by calling 'eComments/comments/bar' (uses $vars['entity'])

For timed refresh of the likes and comments uncomment timedRefresh function in 'eComments/js/canvas'

If you are calling content dynamically via ajax calls, e.g. tabs, make sure you add riverOnLoad(); to your callback/success.