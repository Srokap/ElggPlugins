<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_soccer:title' => "ESPN SOCCER UPDATES",

	        'myhtml_soccer:description' => "Allows to add specific HTML Code"

	        

		

	);

					

	add_translation("en",$english);



?>