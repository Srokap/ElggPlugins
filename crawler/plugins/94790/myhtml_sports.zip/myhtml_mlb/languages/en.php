<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_mlb:title' => "LIVE ESPN MLB UPDATES",

	        'myhtml_mlb:description' => "ESPN MLB FEED WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>