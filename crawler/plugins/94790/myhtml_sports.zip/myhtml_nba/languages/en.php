<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_nba:title' => "LIVE ESPN NBA UPDATES",

	        'myhtml_nba:description' => "ESPN NBA FEED WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>