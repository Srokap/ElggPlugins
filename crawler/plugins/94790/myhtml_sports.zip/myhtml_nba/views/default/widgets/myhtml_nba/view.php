<?php

    

	/**

	 * Elgg MyHTML Plugin

	 * 

	 * @package MyHtml

	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2

	 * @author Dirk Pelzer aka HiTo81

	 * @copyright Dirk Pelzer 2009

	 * @link http://elgg.org/

	 * 

	 */

	 



?>

<div class="contentWrapper user_settings">

  <p><?php echo $vars['entity']->myhtml_nba; ?></p>



  <p>
    <object type="application/x-shockwave-flash" data="http://widgets.espn.go.com/o/471f78291c6f69c6/4a009242a83b567d/471f78291c6f69c6/3eae2ee1" id="W471f78291c6f69c64a009242a83b567d" width="290" height="387">
      <param name="movie" value="http://widgets.espn.go.com/o/471f78291c6f69c6/4a009242a83b567d/471f78291c6f69c6/3eae2ee1" />
      <param name="wmode" value="transparent" />
      <param name="allowNetworking" value="all" />
      <param name="allowScriptAccess" value="always" />
    </object>
  </p>
