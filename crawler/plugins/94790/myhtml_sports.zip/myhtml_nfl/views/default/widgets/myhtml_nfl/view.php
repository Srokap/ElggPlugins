<?php

    

	/**

	 * Elgg MyHTML Plugin

	 * 

	 * @package MyHtml

	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2

	 * @author Dirk Pelzer aka HiTo81

	 * @copyright Dirk Pelzer 2009

	 * @link http://elgg.org/

	 * 

	 */

	 



?>

<div class="contentWrapper user_settings">

  <p><?php echo $vars['entity']->myhtml_nfl; ?></p>
  <p><object type="application/x-shockwave-flash" data="http://widgets.clearspring.com/o/47606bd521007408/49ef97aa83d25075/47606bd521007408/2e7b6cc7" id="W47606bd52100740849ef97aa83d25075" width="285" height="250">
    <param name="movie" value="http://widgets.clearspring.com/o/47606bd521007408/49ef97aa83d25075/47606bd521007408/2e7b6cc7" /><param name="wmode" value="transparent" /><param name="allowNetworking" value="all" /><param name="allowScriptAccess" value="always" /></object>&nbsp;  </p>
</div>



