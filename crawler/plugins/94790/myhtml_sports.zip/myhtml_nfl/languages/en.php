<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_nfl:title' => "LIVE ESPN NFL UPDATES",

	        'myhtml_nfl:description' => "ESPN NFL FEED WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>