<?php

    

	/**

	 * Elgg MyHTML Plugin

	 * 

	 * @package MyHtml

	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2

	 * @author Dirk Pelzer aka HiTo81

	 * @copyright Dirk Pelzer 2009

	 * @link http://elgg.org/

	 * 

	 */

	 



?>

<div class="contentWrapper user_settings">

  <p><?php echo $vars['entity']->myhtml_nhl; ?></p>



  <p>
    <object type="application/x-shockwave-flash" data="http://widgets.clearspring.com/o/471f7877dd408ef2/4a008ce0712b6e4a/471f7877dd408ef2/ed325a62" id="W471f7877dd408ef24a008ce0712b6e4a" width="290" height="387">
      <param name="movie" value="http://widgets.clearspring.com/o/471f7877dd408ef2/4a008ce0712b6e4a/471f7877dd408ef2/ed325a62" />
      <param name="wmode" value="transparent" />
      <param name="allowNetworking" value="all" />
      <param name="allowScriptAccess" value="always" />
    </object>
</p>
