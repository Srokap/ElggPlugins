<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_nhl:title' => "LIVE ESPN NHL UPDATES",

	        'myhtml_nhl:description' => "ESPN NHL FEED WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>