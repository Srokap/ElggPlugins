<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_nascar:title' => "ESPN NASCAR UPDATES",

	        'myhtml_nascar:description' => "ESPN NASCAR FEED WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>