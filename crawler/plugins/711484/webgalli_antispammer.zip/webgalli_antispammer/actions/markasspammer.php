<?php
	/**
	 * Elgg Antispam Registration plugin 
	 * Developed by Dr Sanu P Moideen @ Team Webgalli
	 * http://webgalli.com
	 * Looking for Elgg development/hosting ? Visit us
	 * webgalli@gmail.com
	 * Skype : "drsanupmoideen" or "team.webgalli" 
	 * @package Webgalli_antispammer
	 */
	global $CONFIG;
	admin_gatekeeper();
	action_gatekeeper();
	$user_guid = get_input('user_guid');
	$user = get_entity($user_guid);
		$username = $user ->username;
		$ip = $user ->ip_address;
		$email = $user->email;
		$api_key = get_plugin_setting('api_key', 'webgalli_antispammer');
		$deleteuser = get_plugin_setting('deleteuser', 'webgalli_antispammer');
					if ($api_key) {
						if($user){
									if (!empty ($ip)) {
										add_to_stopformspam_db('username='.$username.'&ip_addr='.$ip.'&email='.$email.'&api_key='.$api_key);
									} else {
									register_error(elgg_echo("webgalli_antispammer:noip"));
									}
									if ($deleteuser == 'yes') {
										$user ->delete();
									}
								} else {
								register_error(elgg_echo("webgalli_antispammer:nouserfound"));
								}
						}else {
					register_error(elgg_echo("webgalli_antispammer:getanapi"));
					}
	forward($_SERVER["HTTP_REFERER"]);
	?>