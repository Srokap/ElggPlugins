<?php

	// Load Elgg engine
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");	
	$ip = get_input('ip');
	// Set title
	$body = elgg_view_title(sprintf(elgg_echo('webgalli_antispammer:title'), $ip));
		
	// Get the list of all donators
	$body .= list_entities_from_metadata("ip_address",$ip,"user","",0,10,false,$viewtypetoggle = true,true,false);		

	//set a view to the donation box
	$sidebar = elgg_view("webgalli_antispammer/search");

	// Display them in the page
    $page = elgg_view_layout("sidebar_boxes", $sidebar, $body);
		
	// Display page
	page_draw(sprintf(elgg_echo('webgalli_antispammer:title'), $ip),$page);
		
?>
