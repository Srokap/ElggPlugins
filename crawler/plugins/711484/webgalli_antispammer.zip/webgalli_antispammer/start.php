<?php
	/**
	 * Elgg Antispam Registration plugin 
	 * Developed by Dr Sanu P Moideen @ Team Webgalli
	 * http://webgalli.com
	 * Looking for Elgg development/hosting ? Visit us
	 * webgalli@gmail.com
	 * Skype : "drsanupmoideen" or "team.webgalli" 
	 * @package Webgalli_antispammer
	 */

	function webgalli_antispammer_init()
	{	
		register_plugin_hook('action', 'register', 'webgalli_antispammer_register', 500);
		register_elgg_event_handler('login', 'user', 'webgalli_antispammer_log_ip');
		register_page_handler('webgalli_antispammer', 'webgalli_antispammer_page_handler');
		if (isadminloggedin()) {
				$api_key = get_plugin_setting('api_key', 'webgalli_antispammer');
				if (!$api_key) {
				register_error(elgg_echo("webgalli_antispammer:noapikeyfound"));
				}
			elgg_extend_view('profile/menu/adminlinks','webgalli_antispammer/usermenu');
			elgg_extend_view('profile/status', 'webgalli_antispammer/profile_ip');
		}
		elgg_extend_view('css','webgalli_antispammer/css');    
	}
	
	function checkSpambots($w_a_email,$w_a_ip,$w_a_username){
	global $CONFIG;
    $spambot = false;
    //put the main domains in the array
	$webgalli_antispammer_maindomains = get_plugin_setting('maindomains', 'webgalli_antispammer');
    $main_domains = array($webgalli_antispammer_maindomains);
    //check the e-mail adress
		$url = "http://www.stopforumspam.com/api?email=".$w_a_email."&f=serial";
		$data = unserialize(file_get_contents($url));
		$email_frequency = $data[email][frequency];
			if($email_frequency != '0'){
				register_error(elgg_echo("webgalli_antispammer:youareaspammer")); //We found a spambot! call 911!!!
				forward('mod/webgalli_antispammer/spam.php?p=em&value='.urlencode($w_a_email));
                $spambot = true;
			}
    if($spambot != true){
    //e-mail not found in the database, now check the ip
        $url = "http://www.stopforumspam.com/api?ip=".$w_a_ip."&f=serial";
		$data = unserialize(file_get_contents($url));
		$ip_frequency = $data[ip][frequency];
			if($ip_frequency != '0'){
				register_error(elgg_echo("webgalli_antispammer:youareaspammer")); //We found a spambot! call 911!!!
				forward('mod/webgalli_antispammer/spam.php?p=ip');
                $spambot = true;
			}
	}	if($spambot != true){
	//e-mail and ip not found in the database, now check the username
        $url = "http://www.stopforumspam.com/api?username=".$w_a_username."&f=serial";
		$data = unserialize(file_get_contents($url));
		$username_frequency = $data[username][frequency];
            if($username_frequency != '0'){
				register_error(elgg_echo("webgalli_antispammer:youareaspammer")); //We found a spambot! call 911!!!
				forward('mod/webgalli_antispammer/spam.php?p=un&value='.urlencode($w_a_username));
                $spambot = true;
			}
	}
    //check the main domains if there is still no spammer found, you can add more if you want in the $main_domains array
    if($spambot != true){
        for($i = 0; $i < count($main_domains); $i++){
            if(strpos($main_domains[$i],$w_a_email) !== false){
                $spambot = true;
            }
        }
    }
    // create a .txt file with the info of the spambot, if this one already exists, increase its amount of try's
    if($spambot == true){
			if(file_exists('mod/webgalli_antispammer/spambots/'.$w_a_email.'.txt')){
				$spambot_old_info = file_get_contents('spambots/'.$w_a_email.'.txt');
				$spambot_old_info = explode(',',$spambot_old_info);
				$spambot_old_info[2] = $spambot_old_info[2]+1;
				$spambot_old_info = implode(',',$spambot_old_info);
				file_put_contents('mod/webgalli_antispammer/spambots/'.$w_a_email.'.txt',$spambot_old_info);
			}else{
				$spambot_info = $ip.','.$w_a_name.',1';
				file_put_contents('mod/webgalli_antispammer/spambots/'.$w_a_email.'.txt',$spambot_info);
			}
    	} else {
				create_metadata($object->guid, 'ip_address', $w_a_ip, 'text', $_SESSION['guid'], ACCESS_PUBLIC);
				return true; //he can register as usual
		}
	}
	
    function webgalli_antispammer_log_ip($event, $object_type, $object) {
      if (($object) && ($object instanceof ElggUser)) {
        $ip_address = $_SERVER['REMOTE_ADDR'];
		if (empty($object->ip_address)){
        create_metadata($object->guid, 'ip_address', $ip_address, '', 0, ACCESS_PUBLIC);
		} else {
        update_metadata($object->guid, 'ip_address', $ip_address, '', 0, ACCESS_PUBLIC);
		}
      }
    }

	function webgalli_antispammer_register(){
		global $CONFIG;
		$w_a_username = get_input('username');
		$w_a_email = get_input('email');
		$w_a_ip = $_SERVER['REMOTE_ADDR'];
		if (empty($w_a_ip)) {
			register_error(elgg_echo("webgalli_antispammer:hide")); //NO IP == NO REGISTRATION
			forward($_SERVER['HTTP_REFERER']);
		} else {
			checkSpambots($w_a_email,$w_a_ip,$w_a_username);
		}
	}
	
	function add_to_stopformspam_db($data) {
		$url = 'http://www.stopforumspam.com/add.php?'.$data;
		if (fopen($url, 'r')){
			system_message(elgg_echo('webgalli_antispammer:addedtodb'));
			} else {
			register_error(elgg_echo("webgalli_antispammer:cannotaddtodb"));
			}
	}
	register_action("webgalli_antispammer/markasspammer",false,$CONFIG->pluginspath . "webgalli_antispammer/actions/markasspammer.php");
	register_elgg_event_handler('init','system','webgalli_antispammer_init');
?>