<br/>
<div class="contentWrapper">
<?php
	/**
	 * Elgg Antispam Registration plugin 
	 * Developed by Dr Sanu P Moideen @ Team Webgalli
	 * http://webgalli.com
	 * Looking for Elgg development/hosting ? Visit us
	 * webgalli@gmail.com
	 * Skype : "drsanupmoideen" or "team.webgalli" 
	 * @package Webgalli_antispammer
	 */
		$p = get_input('p');
		$value = get_input('value');
		echo "Sorry, We could not register you. You are Identified as a Spammer.<br/>";
		if ($p == 'em') { ?>
		This is because, your <a href="http://www.stopforumspam.com/search/?q=<?php echo $value;?>" target="_blank">email</a> is listed in the International spam database..<br/>
        <?php } elseif ($p == 'un') { ?>
		This is because, your <a href="http://www.stopforumspam.com/search/?q=<?php echo $value;?>" target="_blank">username</a> is listed in the International spam database..<br/>
        <?php } else { ?>
This may because your IP is in the <a href = "http://www.stopforumspam.com/ipcheck/<?php echo $_SERVER['REMOTE_ADDR'];?>" target="_blank">International Spam Database</a>.<br/>
		<?php } ?>
If you think this is an error you can contact us using the "contact us link".
</div>