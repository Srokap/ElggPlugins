<?php
	/**
	 * Elgg Antispam Registration plugin 
	 * Developed by Dr Sanu P Moideen @ Team Webgalli
	 * http://webgalli.com
	 * Looking for Elgg development/hosting ? Visit us
	 * webgalli@gmail.com
	 * Skype : "drsanupmoideen" or "team.webgalli" 
	 * @package Webgalli_antispammer
	 */
?>