<?php

	$ip_string = elgg_echo('webgalli_antispammer:search:ip');
	$ip_info = elgg_echo('webgalli_antispammer:search:info');
	$ip_address = get_input('ip');
	$tracker_url = 'http://en.utrace.de/?query='.$ip_address;
	$tracker_link = "<a href=\"$tracker_url\" target=\"_blank\" class=\"tracker_button\" />$ip_info</a>";

?>

<div class="sidebarBox">

<h3><?php echo elgg_echo('webgalli_antispammer:searchip'); ?></h3>
<form id="trackersearchform" action="<?php echo $vars['url']; ?>mod/webgalli_antispammer/ip.php?" method="get">
	<input type="text" name="ip" value="<?php echo $ip_address; ?>" class="search_input" />
	<input type="submit" value="<?php echo elgg_echo('search'); ?>" />
</form>

</div>

<?php
	echo $tracker_link;
?>

