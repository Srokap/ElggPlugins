<?php

	// Only admins should see this
	if (isadminloggedin()) {
		// Get GUID of the user who owns this profile
		$owner_guid = $vars['entity']->guid;
 
		// Get owner entity
		$owner_ent = get_entity($owner_guid);
 
		// Get IP address
		$ip_address = $owner_ent->ip_address;

		// Get URL for IP information
		$tracker_url = 'http://en.utrace.de/?query='.$ip_address;

		// Create tracker link
		$tracker_link = "<a href=\"$tracker_url\" target=\"_blank\" title=\"" . elgg_echo('webgalli_antispammer:moreinfo') . "\" />" . elgg_echo('webgalli_antispammer:info') . "</a>";
    
		// Display IP address
		echo "<small>IP: ";
		echo "<a href=\"". $CONFIG->wwwroot . "mod/webgalli_antispammer/ip.php?ip=$ip_address\" title=\"" . elgg_echo('webgalli_antispammer:find') . "\" />$ip_address</a>";
		echo " | $tracker_link</small>";
	}                          

?>
