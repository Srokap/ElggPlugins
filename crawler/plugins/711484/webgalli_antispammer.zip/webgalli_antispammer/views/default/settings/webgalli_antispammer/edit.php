<?php
	/**
	 * Elgg Antispam Registration plugin 
	 * Developed by Dr Sanu P Moideen @ Team Webgalli
	 * http://webgalli.com
	 * Looking for Elgg development/hosting ? Visit us
	 * webgalli@gmail.com
	 * Skype : "drsanupmoideen" or "team.webgalli" 
	 * @package Webgalli_antispammer
	 */

	$maindomains = $vars['entity']->maindomains;
	$api_key = $vars['entity']->api_key;
	$deleteuser = $vars['entity']->deleteuser;
	if (!$maindomains) {
		$value = "'mail.ru','bigmir.net'";
		set_plugin_setting('maindomains',$value,'webgalli_antispammer') ;
		}
		
?>
<p>
	<?php echo elgg_echo('webgalli_antispammer:maindomains'); ?>
	
<?php 
	echo elgg_view('input/text', array('internalname' => "params[maindomains]", 'value' => $vars['entity']->maindomains)); 
?>
</p>
<p>
	<?php echo elgg_echo('webgalli_antispammer:inputapi'); ?><br/>
	Get your API key from <a href="http://www.stopforumspam.com/signup">here</a>
	
<?php 
	echo elgg_view('input/text', array('internalname' => "params[api_key]", 'value' => $vars['entity']->api_key)); 
?>
</p>
<p>
	<?php echo elgg_echo('webgalli_antispammer:deleteuser'); ?><br/>
	<?php
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[deleteuser]',
			'options_values' => array(
				'yes' => elgg_echo('webgalli_antispammer:yes'),
				'no' => elgg_echo('webgalli_antispammer:no'),
				),
			'value' => $deleteuser
		));
	?>
</p>

<p>
Found this plugin usefull? Support the future developmant of it, make a donation now.
<a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=9796540" target="_blank"><img  src="<?php echo $vars['url'];?>mod/webgalli_antispammer/images/donate.jpg"  alt="Donate Button"></a>

</p>