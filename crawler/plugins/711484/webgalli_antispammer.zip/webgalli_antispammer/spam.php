<?php

	/**
	 * Elgg Antispam Registration plugin 
	 * Developed by Dr Sanu P Moideen @ Team Webgalli
	 * http://webgalli.com
	 * Looking for Elgg development/hosting ? Visit us
	 * webgalli@gmail.com
	 * Skype : "drsanupmoideen" or "team.webgalli" 
	 * @package Webgalli_antispammer
	 */

require_once(dirname(dirname(dirname(__FILE__))) . '/engine/start.php');


$body = elgg_view('webgalli_antispammer/form');
$body = elgg_view_layout('one_column',  $body);

page_draw(elgg_echo('webgalli_antispammer:problem'), $body);
