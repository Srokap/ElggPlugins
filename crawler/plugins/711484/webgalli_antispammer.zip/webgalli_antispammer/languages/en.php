<?php
	/**
	 * Elgg Antispam Registration plugin 
	 * Developed by Dr Sanu P Moideen @ Team Webgalli
	 * http://webgalli.com
	 * Looking for Elgg development/hosting ? Visit us
	 * webgalli@gmail.com
	 * Skype : "drsanupmoideen" or "team.webgalli" 
	 * @package Webgalli_antispammer
	 */

$english = array(
		// IP related
	'webgalli_antispammer:title' => "Members with IP address: %s",
	'webgalli_antispammer:find' => "Find others with same IP",
	'webgalli_antispammer:moreinfo' => "Get extended information about IP address",
	'webgalli_antispammer:info' => "Info",
	'webgalli_antispammer:searchip' => "Find IP address",
	'webgalli_antispammer:search:info' => "Extended IP info",
	'webgalli_antispammer:adminlink' => "Check IP address",

	'webgalli_antispammer:addedtodb' => "Successfully added the user",
	'webgalli_antispammer:cannotaddtodb' => "Failed to add the user to database",
	'webgalli_antispammer:nouserfound' => "User could not be found",
	'webgalli_antispammer:getanapi' => "Get an api key from Stop forum spam to use this plugin",
	'webgalli_antispammer:markasspammer' => "Mark as spammer",
	'webgalli_antispammer:checkip' => "Check IP",
	'webgalli_antispammer:maindomains' => "Main spam domains, you can add more domains below as comma seperated. Use the format 'domain1','domain2'",
	'webgalli_antispammer:inputapi' => "Input your API key below",
	'webgalli_antispammer:problem' => "We have a problem!!!",
	'webgalli_antispammer:noapikeyfound' => "You have enabled the Webgalli_Antispammer plugin, but have not provided the API Key",
	'webgalli_antispammer:noip' => "IP address of the user is not found",
	'webgalli_antispammer:deleteuser' => "Delete the user after adding to the spam database?",
	'webgalli_antispammer:yes' => "Yes",
	'webgalli_antispammer:no' => "No",
	'webgalli_antispammer:youareaspammer' => "Sorry, we could not register you. You are identified as a Spammer",
	'webgalli_antispammer:hide' => "Sorry, we could not register you. We could not get an IP address. Joining this site requires you to share your IP address with the site."

	);

add_translation("en",$english);
?>