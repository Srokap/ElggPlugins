<?php
/**
 * highlight CSS
 *
 */
?>
/*D*/
pre .d .no_format {color: green;}
pre .d .comment     {color: green;}
pre .d .string       {color: red;}
pre .d .keyword     {color: blue;}
/* end D*/
pre code {
  display: block; padding: 0.5em;
  color: #000;
  background: #fff;
}

pre .subst,
pre .title {
  font-weight: normal;
  color: #000;
}

pre .comment,
pre .template_comment,
pre .javadoc,
pre .diff .header {
  color: #808080;
  font-style: italic;
}

pre .annotation,
pre .decorator,
pre .preprocessor,
pre .doctype,
pre .pi,
pre .chunk,
pre .shebang,
pre .apache .cbracket,
pre .input_number,
pre .http .title {
  color: #808000;
}

pre .tag,
pre .pi {
  background: #efefef;
}

pre .tag .title,
pre .id,
pre .attr_selector,
pre .pseudo,
pre .literal,
pre .keyword,
pre .hexcolor,
pre .css .function,
pre .ini .title,
pre .css .class,
pre .list .title,
pre .nginx .title,
pre .tex .command,
pre .request,
pre .status {
  font-weight: bold;
  color: #000080;
}

pre .attribute,
pre .rules .keyword,
pre .number,
pre .date,
pre .regexp,
pre .tex .special {
  font-weight: bold;
  color: #0000ff;
}

pre .number,
pre .regexp {
  font-weight: normal;
}

pre .string,
pre .value,
pre .filter .argument,
pre .css .function .params,
pre .apache .tag {
  color: #008000;
  font-weight: bold;
}

pre .symbol,
pre .ruby .symbol .string,
pre .ruby .symbol .keyword,
pre .ruby .symbol .keymethods,
pre .char,
pre .tex .formula {
  color: #000;
  background: #d0eded;
  font-style: italic;
}

pre .phpdoc,
pre .yardoctag,
pre .javadoctag {
  text-decoration: underline;
}

pre .variable,
pre .envvar,
pre .apache .sqbracket,
pre .nginx .built_in {
  color: #660e7a;
}

pre .addition {
  background: #baeeba;
}

pre .deletion {
  background: #ffc8bd;
}

pre .diff .change {
  background: #bccff9;
}
