<?php
/**
 * Initialize the TinyMCE Jquery script
 */
 
elgg_load_js('tinymce_jquery');
elgg_load_js('elgg.tinymce_jquery');