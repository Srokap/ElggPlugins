Adding a language
======================
1. Download the language pack from [TinyMCE][1]
2. Extract the files from the zip file.
3. Copy the langs, plugins, and themes directories into mod/tinymce/vendor/tinymce/jscripts/tiny_mce/.
There are already directories with those names. You do not want to delete those directories.
Instead, copy the new directories on top of the old ones.
4. Flush the Elgg caches.

[1]: http://www.tinymce.com/i18n/index.php?ctrl=lang&act=download	"TinyMCE"
