<?php
	/**
	* Dutch translation.
	* 
	* @package dutch_translation
	* @author ColdTrick IT Solutions
	* @copyright Coldtrick IT Solutions 2009
	* @link http://www.coldtrick.com/
	*/
if(is_plugin_enabled('friends')){
	$dutch = array(

		/**
		* Friends widget
		*/
		'friends:widget:description' => "Laat sommige van je vrienden zien.",

	);
	
	add_translation("nl", $dutch);
}
?>