<?php
	/**
	* Dutch translation.
	* 
	* @package dutch_translation
	* @author ColdTrick IT Solutions
	* @copyright Coldtrick IT Solutions 2009
	* @link http://www.coldtrick.com/
	*/
if(is_plugin_enabled('tinymce')){
	$dutch = array(

		/**
		* Menu items and titles
		*/

		'tinymce:remove' => "Voeg toe/verwijder editor",

	);
	
	add_translation("nl", $dutch);
}
?>