<?php

	/**
	 * Elgg artfolio: upload extra image to existing post action
	 * 
	 * @package Artfolio
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Frederqiue Hermans
	 * @copyright ANN-Designs 2008
	 * @link www.frederiquehermans.be
	 */

	// Make sure we're logged in (send us to the front page if not)
		if (!isloggedin()) forward();


	// Get input data
		$guid = (int) get_input('artfoliopost');

	// Make sure we actually have permission to edit
		$artfolio = get_entity($guid);
		if ($artfolio->getSubtype() == "artfolio" && $artfolio->canEdit()) {
			
	// Get owning user
		$owner = get_entity($artfolio->getOwner());
				
	// Get the acces id of the artfolio post
		$access  = $artfolio->getAccessID();
		
		
	foreach ( $_FILES['upload']['name'] AS $key => $file ) {
		if ( $_FILES['upload']['name'][$key] != '' ) {

		

		// Make sure image is not to big, is the right filetype and is an uploaded file

			if ($_FILES['upload']['size'][$key] > 1048576) {
				register_error(elgg_echo("artfolio:tobig"));
				forward("mod/artfolio/upload.php?artfoliopost=" . $guid);

			 } else {
			if ( $_FILES['upload']['type'][$key] != 'image/jpeg' && $_FILES['upload']['type'][$key] != 'image/pjpeg') {
				register_error(elgg_echo("artfolio:notjpg"));
				forward("mod/artfolio/upload.php?artfoliopost=" . $guid);

		// Otherwise, upload the image	
			} else {

		// Create a user artfoliofolder based on GUID, if it doen't have one
			if (!is_dir( $CONFIG->path . '/artfolio/' . $_SESSION['user']->getGUID())){
					mkdir($CONFIG->path . '/artfolio/' . $_SESSION['user']->getGUID(), 0777, true);
				}

		// Create a unique but logical filename based on title and unique numeric string
				
				$filename = strtolower($title);
				$filename = str_replace(' ', '_', $filename);
				$filename = preg_replace('/[^a-z0-9_]/i', '', $filename);
				$filename = $filename . '_' .  md5(uniqid(mt_rand()));

		// Copy the uploaded image to the user folder

				copy($_FILES['upload']['tmp_name'][$key], $CONFIG->path . '/artfolio/' . $_SESSION['user']->getGUID() . '/' . $filename . '.jpg');

		// Adding the filelocation to the artfolio post#
		// echo $_SESSION['user']->getGUID();
				$artfolio->annotate('artfoliolocation', 'artfolio/' . $_SESSION['user']->getGUID() . '/' . $filename, $access, $_SESSION['user']->getGUID(), "string");

				// print_r($artfolio);
				
 
		

		// Create a small thumbnail	
				$img = $CONFIG->path . '/artfolio/' . $_SESSION['user']->getGUID() . '/' . $filename . '.jpg';

				$canvas_width  = 60;
				$canvas_height = 60;

				$canvas = imagecreatetruecolor($canvas_width, $canvas_height);

				list($img_width, $img_height) = getimagesize($img);

				$original = imagecreatefromjpeg($img);

				if ($img_width >= 460 or $img_height >= 460){

						imagecopyresampled($canvas, $original, 0, 0, 
								 (($img_width / 2 ) - ( ($canvas_width / 2) * 4 ) ),
														 (($img_height / 2 ) - ( ($canvas_height / 2) * 4 ) ),
														 $img_width / 4,
														 $img_height / 4,
														 $img_width,
														 $img_height
														 );								 
						} else {

						imagecopyresampled($canvas, $original, 0, 0, 
								 (($img_width / 2 ) - ($canvas_width / 2) ),
														 (($img_height / 2 ) - ($canvas_height / 2) ),
														 $img_width,
														 $img_height,
														 $img_width,
														 $img_height
														 );		
						}

				imagejpeg($canvas, $CONFIG->path . '/artfolio/' . $_SESSION['user']->getGUID() . '/' . $filename . '_thumbsmall.jpg', 100);

		// Create a large thumbnail	
				$canvas_width  = 153;
				$canvas_height = 153;

				$canvaslarge = imagecreatetruecolor($canvas_width, $canvas_height);

				if ($img_width >= 460 or $img_height >= 460){

						imagecopyresampled($canvaslarge, $original, 0, 0, 
								 (($img_width / 2 ) - ( ($canvas_width / 2) * 3 ) ),
														 (($img_height / 2 ) - ( ($canvas_height / 2) * 3 ) ),
														 $img_width / 3,
														 $img_height / 3,
														 $img_width,
														 $img_height
														 );								 
						} else {

						imagecopyresampled($canvaslarge, $original, 0, 0, 
								 (($img_width / 2 ) - ($canvas_width / 2) ),
														 (($img_height / 2 ) - ($canvas_height / 2) ),
														 $img_width,
														 $img_height,
														 $img_width,
														 $img_height
														 );		
						}

				imagejpeg($canvaslarge, $CONFIG->path . '/artfolio/' . $_SESSION['user']->getGUID() . '/' . $filename . '_thumblarge.jpg', 100);

		// Create an image of smaller resolution for webviewing, if needed	

				$canvas_width  = 1000;
				$canvas_height = 600;

				if ($img_width > $canvas_width or $img_height > $canvas_height){

						$ratio_orig = $img_width / $img_height;

						if ($canvas_width / $canvas_height > $ratio_orig){
								$canvas_width = $canvas_height * $ratio_orig;	
							} else {
								$canvas_height = $canvas_width / $ratio_orig;
							}

						$canvasfull = imagecreatetruecolor($canvas_width, $canvas_height);

					imagecopyresampled($canvasfull, $original, 0, 0, 0, 0, $canvas_width, $canvas_height, $img_width, $img_height);

						imagejpeg($canvasfull, $CONFIG->path . '/artfolio/' . $_SESSION['user']->getGUID() . '/' . $filename . '_full.jpg', 80);
					} else {
						copy($img, $CONFIG->path . '/artfolio/' . $_SESSION['user']->getGUID() . '/' . $filename . '_full.jpg');
					}
		// Delete the original image	
				unlink($img);
				$url = $artfolio->getURL();
			}
		   }
		// Success message
		system_message(elgg_echo("artfolio:uploaded"));
		}	
	   }
	  }

		// If all fields where empty
		if ( !isset($url) ) {
			system_message(elgg_echo("artfolio:notjpg"));
			$url = "mod/artfolio/upload.php?artfoliopost=" . $guid;
		} 
		
		forward($url);
		
		
?>