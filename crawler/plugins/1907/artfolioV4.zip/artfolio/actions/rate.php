<?php

	/**
	 * Elgg artfolio: rate project action
	 * 
	 * @package Artfolio
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Frederqiue Hermans
	 * @copyright ANN-Designs 2008
	 * @link www.frederiquehermans.be
	 */

	// Make sure we're logged in (send us to the front page if not)
		if (!isloggedin()) forward();

	// Get input data
		$guid = (int) get_input('artfoliopost');
		$access = (int) get_input('artfoliopostacces');
		$rate = (int) get_input('rating');
		
	// Cashe to session
		$_SESSION['artfoliorated'] = $guid;
		
	// Get the post
		$artfolio = get_entity($guid);
		$owner = $artfolio->getOwner();
	
	// Get old rating (this code should be cleaned up)
		$getoldrates = $artfolio->getAnnotations('artfoliorating');
			foreach ($getoldrates as $getoldrate){
					$oldrate = $getoldrate['value'];
			}
		$getnumvotes = $artfolio->getAnnotations('artfolionumvotes');
			foreach ($getnumvotes as $getnumvote){
					$numvotes = $getnumvote['value'];
			}
	
	// Calculate new rating
		$oldrate = ($oldrate * $numvotes);
		$newrate = ($oldrate + $rate);
		$newcount = ($numvotes + 1.00);
		$newrate = ($newrate / $newcount);
		
	// Delete old ratings
		$artfolioratings = $artfolio->getAnnotations('artfoliorating');
				foreach ($artfolioratings as $artfoliorating){
					$rating_id = $artfoliorating['id'];
					$ratingobject = get_annotation($rating_id);
					$ratingobject->delete();
				}
				
				$artfolionumvotes = $artfolio->getAnnotations('artfolionumvotes');
				foreach ($artfolionumvotes as $artfolionumvote){
					$numvotes_id = $artfolionumvote['id'];
					$numvotesobject = get_annotation($numvotes_id);
					$numvotesobject->delete();
				}
	
	// Save new rating
		$artfolio->annotate('artfoliorating', $newrate, $access, $owner, "integer");
		$artfolio->annotate('artfolionumvotes', $newcount, $access, $owner, "integer");
	
	// Succes message
		system_message(elgg_echo("artfolio:ratesucces"));
	
	// Forward to the artfolio page
	/**
	*/
		//forward("mod/artfolio/?username=" . $owner->username);
		forward($artfolio->getURL());
?>