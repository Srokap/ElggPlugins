<?php

	/**
	 * Elgg artfolio: delete project action
	 * 
	 * @package Artfolio
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Frederqiue Hermans
	 * @copyright ANN-Designs 2008
	 * @link www.frederiquehermans.be
	 */

	// Make sure we're logged in (send us to the front page if not)
		if (!isloggedin()) forward();

	// Get input data
		$guid = (int) get_input('artfoliopost');
		
	// Make sure we actually have permission to edit
		$artfolio = get_entity($guid);
		if ($artfolio->getSubtype() == "artfolio" && $artfolio->canEdit()) {
	
		// Get owning user
				$owner = get_entity($artfolio->getOwner());
				
		// Delete the images
				$annotations = $artfolio->getAnnotations('artfoliolocation');
				foreach ($annotations as $annotation){
					unlink($CONFIG->path . '/' . $annotation['value'] . '_thumbsmall.jpg');
					unlink($CONFIG->path . '/' . $annotation['value'] . '_thumblarge.jpg');
					unlink($CONFIG->path . '/' . $annotation['value'] . '_full.jpg');
					
					// Delete the annotations
					$annotation_id = $annotation['id'];
					$object = get_annotation($annotation_id);
					$object->delete();
				}
				
		// Delete the rating
				$artfolioratings = $artfolio->getAnnotations('artfoliorating');
				foreach ($artfolioratings as $artfoliorating){
					$rating_id = $artfoliorating['id'];
					$ratingobject = get_annotation($rating_id);
					$ratingobject->delete();
				}
				
				$artfolionumvotes = $artfolio->getAnnotations('artfolionumvotes');
				foreach ($artfolionumvotes as $artfolionumvote){
					$numvotes_id = $artfolionumvote['id'];
					$numvotesobject = get_annotation($numvotes_id);
					$numvotesobject->delete();
				}
				
		// Delete the artfolio post
				$rowsaffected = $artfolio->delete();
				if ($rowsaffected > 0) {
		
		// Success message
					system_message(elgg_echo("artfolio:deleted"));
				} else {
					register_error(elgg_echo("artfolio:notdeleted"));
				}
				
		// Forward to the main artfolio page
				forward("mod/artfolio/?username=" . $owner->username);
		}
		
?>