<?php

	/**
	 * Elgg artfolio CSS extender
	 * 
	 * @package Artfolio
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Frederqiue Hermans
	 * @copyright ANN-Designs 2008
	 * @link www.frederiquehermans.be
	 */

?>


.artfolio_post {
	margin-bottom: 15px;
	border-bottom: 1px solid #aaaaaa;
}

.artfolio_post_icon {
	float:left;
	margin:3px 0 0 0;
	padding:0;
}

.artfolio_post h3 {
	font-size: 150%;
	margin-bottom: 5px;
}

.artfolio_post h3 a {
	text-decoration: none;
}

.artfolio_post p {
	margin: 0 0 5px 0;
}

.artfolio_post .strapline {
	margin: 0 0 0 35px;
	padding:0;
	color: #666666;
	line-height:1em;
}
.artfolio_post p.tags {
	background:transparent url(<?php echo $vars['url']; ?>_graphics/icon_tag.gif) no-repeat scroll left 2px;
	margin:0 0 0 35px;
	padding:0pt 0pt 0pt 16px;
	min-height:22px;
}
.artfolio_post .options {
	margin:0;
	padding:0;
}

.artfolio_post_body img[align="left"] {
	margin: 10px 10px 10px 0;
	float:left;
}
.artfolio_post_body img[align="right"] {
	margin: 10px 0 10px 10px;
	float:right;
}

.artfolio-comments h3 {
	font-size: 150%;
	margin-bottom: 10px;
}
.artfolio-comment {
	margin-top: 10px;
	margin-bottom:20px;
	border-bottom: 1px solid #aaaaaa;
}
.artfolio-comment img {
	float:left;
	margin: 0 10px 0 0;
}
.artfolio-comment-menu {
	margin:0;
}
.artfolio-comment-byline {
	background: #dddddd;
	height:22px;
	padding-top:3px;
	margin:0;
}
.artfolio-comment-text {
	margin:5px 0 5px 0;
}
.artfolio-largethumb a {
	height: 100px;
	width: 100px;
	margin: 2px;
	float: left;
	border-color: #000000;
	border-width: 1px;
	border-style: solid;
}
.artfolio-largethumb a:hover {
	border-color: #dddddd;
}
.artfolio-smallthumb a {
	height: 60px;
	width: 60px;
	margin: 2px;
	float: left;
	border-color: #000000;
	border-width: 1px;
	border-style: solid;
}
.artfolio-smallthumb a:hover {
	border-color: #dddddd;
}
.artfolio-tinythumb a {
	height: 25px;
	width: 25px;
	margin: 1px;
	float: left;
	border-color: #000000;
	border-width: 1px;
	border-style: solid;
}
.artfolio-tinythumb a:hover {
	border-color: #dddddd;
}
.artfolio_title_owner_wrapper {
	min-height:60px;
    margin-bottom: 10px;
    padding:0 0 0 10px;
	background-color: #eeeeee;
}
.artfolio_title{
	margin:0;
	padding:6px 5px 0 8px;
	line-height: 1.2em;
}
.artfolio_details_holder {
	padding:0 0 0 10px;
    margin-left: 0px !important;
}
.artfolio_details_holder .usericon {
	margin-right: 5px;
	float: left;
}

/* GALLERY VIEW */

.artfolio_gallery_item {
	margin:0;
	padding:0;
}
.artfolio_gallery_title {
	font-weight: bold;
	line-height: 1.1em;
	margin:0 0 10px 0;
}
.artfolio_gallery_content {
	font-size:90%;
    color:#666666;
	margin:0;
    padding:0;
}
.artfolio_gallery_rating {
	font-size:90%;
    color:#aaaaaa;
	margin:0;
    padding:0;
}
.artfolio_gallery_link {
	float:right;
	margin:5px 5px 5px 50px;
}
.artfolio_gallery_link a {
	padding:2px 25px 5px 0;
	background: transparent url(<?php echo $vars['url']; ?>_graphics/icon_gallery.gif) no-repeat right top;
	display:block;
}
.artfolio_gallery_link a:hover {
	background-position: right -40px;
}