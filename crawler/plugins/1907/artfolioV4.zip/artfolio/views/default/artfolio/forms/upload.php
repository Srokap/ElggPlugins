<?php

	/**
	 * Elgg artfolio upload more images page
	 * 
	 * @package Artfolio
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Frederqiue Hermans
	 * @copyright ANN-Designs 2008
	 * @link www.frederiquehermans.be
	 * 
	 * @uses $vars['object'] Optionally, the artfolio post to edit
	 */

	// form destination
			$action = "artfolio/upload";

?>

	<form action="<?php echo $vars['url']; ?>action/<?php echo $action; ?>" enctype="multipart/form-data" method="post">
        <p>
        	<label><?php echo elgg_echo("artfolio:uploadimages"); ?></label><br />
        		   <?php echo elgg_echo("artfolio:imagelimitation"); ?><br />
			<?php
			for ( $i=0; $i<5; $i++ ) { ?>
					
					<p><?php echo elgg_view("input/file",array('internalname' => 'upload['.$i.']')); ?></p>
					
			<?php }
					
			?>
            		<!-- <br /><?php echo elgg_echo("artfolio:imagelater"); ?><br /> -->
            
         </p>
		<p>
			<?php

				if (isset($vars['entity'])) {
					?><input type="hidden" name="artfoliopost" value="<?php echo $vars['entity']->getGUID(); ?>" /><?php
				}
			
			?>
			<input type="submit" name="submit" value="<?php echo elgg_echo('save'); ?>" />
		</p>
	
	</form>