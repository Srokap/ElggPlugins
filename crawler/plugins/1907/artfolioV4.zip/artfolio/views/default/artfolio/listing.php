<?php

	/**
	 * Elgg artfolio listing
	 * 
	 * @package Artfolio
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Frederqiue Hermans
	 * @copyright ANN-Designs 2008
	 * @link www.frederiquehermans.be
	 */

		$owner = $vars['entity']->getOwnerEntity();
		$friendlytime = friendly_time($vars['entity']->time_created);
			$annotations = $vars['entity']->getAnnotations('artfoliolocation',1);
			foreach ($annotations as $annotation){
				$icon = "<p><a href=\"{$vars['entity']->getURL()}\"><img src=\"" . $CONFIG->wwwroot . $annotation['value'] . '_thumbsmall.jpg' . "\"/></a></p>";
			}
		$info = "<p><a href=\"{$vars['entity']->getURL()}\">{$vars['entity']->title}</a></p>";
		$info .= "<p class=\"owner_timestamp\"><a href=\"{$owner->getURL()}\">{$owner->name}</a> {$friendlytime}</p>";
		echo elgg_view_listing($icon,$info);
?>