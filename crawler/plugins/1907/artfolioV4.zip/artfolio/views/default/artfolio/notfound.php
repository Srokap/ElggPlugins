<?php

	/**
	 * Elgg artfolio not found page
	 * 
	 * @package Artfolio
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Frederqiue Hermans
	 * @copyright ANN-Designs 2008
	 * @link www.frederiquehermans.be
	 */

?>

	<p>
		<?php

			echo elgg_echo("artfolio:notfound");
		
		?>
	</p>