<?php

	/**
	 * Elgg artfolio individual post view
	 * 
	 * @package Artfolio
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Frederqiue Hermans
	 * @copyright ANN-Designs 2008
	 * @link www.frederiquehermans.be
	 * 
	 * @uses $vars['entity'] Optionally, the artfolio post to view
	 */

		if (isset($vars['entity'])) {
			
			if (get_context() == "search") {
				
				//display the correct layout depending on gallery or list view
				if (get_input('search_viewtype') == "gallery") {

					//display the gallery view
            				echo elgg_view("artfolio/gallery",$vars);

				} else {
				
					echo elgg_view("artfolio/listing",$vars);

				}

				
			} else {
		
		// Get rating
			$getoldrates = $vars['entity']->getAnnotations('artfoliorating',1);
				foreach ($getoldrates as $getoldrate){
						$article_rating = $getoldrate['value'];
				}
			$getnumvotes = $vars['entity']->getAnnotations('artfolionumvotes',1);
				foreach ($getnumvotes as $getnumvote){
						$numvotes = $getnumvote['value'];
				}	
		
		// Match rating to image		
		if($numvotes == 0){
				$rating_image = "rateempty.gif";
		} else {
			if((($article_rating >= 0)or($article_rating == 0)) && ($article_rating <= 0.50)){
				$rating_image = "rate00.gif";
				}
			if((($article_rating >= 0.50)or($article_rating == 0.50)) && ($article_rating <= .99)){
				$rating_image = "rate05.gif";
				}
			if((($article_rating >= 1.00)or($article_rating == 1.50)) && ($article_rating <= 1.49)){
				$rating_image = "rate10.gif";
				}
			if((($article_rating >= 1.50)or($article_rating == 1.50)) && ($article_rating <= 1.99)){
				$rating_image = "rate15.gif";
				}
			if((($article_rating >= 2.00)or($article_rating == 2.00)) && ($article_rating <= 2.49)){
				$rating_image = "rate20.gif";
				}
			if((($article_rating >= 2.50)or($article_rating == 2.50)) && ($article_rating <= 2.99)){
				$rating_image = "rate25.gif";
				}
			if((($article_rating >= 3.00)or($article_rating == 3.00)) && ($article_rating <= 3.49)){
				$rating_image = "rate30.gif";
				}
			if((($article_rating >= 3.50)or($article_rating == 3.50)) && ($article_rating <= 3.99)){
				$rating_image = "rate35.gif";
				}
			if((($article_rating >= 4.00)or($article_rating == 4.00)) && ($article_rating <= 4.49)){
				$rating_image = "rate40.gif";
				}
			if((($article_rating >= 4.50)or($article_rating == 4.50)) && ($article_rating <= 4.99)){
				$rating_image = "rate45.gif";
				}
			if($article_rating == 5.0){
				$rating_image = "rate50.gif";
				}
			}		
?>

    <div class="artfolio_post">
    	<!-- displaying header -->
			<div class="artfolio_title_owner_wrapper">
			<?php
				//get the user and a link to their gallery
				$user_gallery = $CONFIG->wwwroot . "pg/artfolio/" . $vars['entity']->getOwnerEntity()->username . "&search_viewtype=gallery";
			?>
			<div class="artfolio_gallery_link"><a href="<?php echo $user_gallery; ?>"><?php echo $vars['entity']->getOwnerEntity()->name; ?>: <?php echo elgg_echo("artfolio"); ?></a></div>
			<div class="artfolio_title"><h2><?php echo $vars['entity']->title; ?></h2><img src="<?php echo $CONFIG->wwwroot; ?>mod/artfolio/images/<?php echo $rating_image; ?>"/></div>
			<div class="artfolio_details_holder">
					<?php

						echo elgg_view("profile/icon",array('entity' => $vars['entity']->getOwnerEntity(), 'size' => 'tiny'));
				
					?>
					<p class="strapline">
				<?php
	                
					echo sprintf(elgg_echo("artfolio:strapline"),
									date("F j, Y",$vars['entity']->time_created)
					);
				
				?>
				<?php echo elgg_echo('by'); ?> <a href="<?php echo $vars['url']; ?>pg/artfolio/<?php echo $vars['entity']->getOwnerEntity()->username; ?>"><?php echo $vars['entity']->getOwnerEntity()->name; ?></a> <BR> 
				<!-- display the comments link -->
				<?php
			        //get the number of comments
			    	$num_comments = elgg_count_comments($vars['entity']);
			    ?>
			    <?php echo "(" . $num_comments . " " . sprintf(elgg_echo("comments")) . ")"; ?><?php echo (" (". $numvotes . " " . elgg_echo('artfolio:votes').")"); ?><br />
			</p>
			<!-- display tags -->
			<p class="tags">
				<?php
	
					echo elgg_view('output/tags', array('tags' => $vars['entity']->tags));
				
				?>
			</p>
			</div>
			</div>
		<!-- displaying the images -->            
            <div class="artfolio_post_body">
				<?php
						$annotations = $vars['entity']->getAnnotations('artfoliolocation');
						
						foreach ($annotations as $annotation){ 
				?>
                		<div class="artfolio-largethumb">
                        		<a href="<?php echo ($CONFIG->wwwroot . $annotation['value'] . '_full.jpg'); ?>" rel="lightbox[gallery]" title="<?php echo $vars['entity']->title; ?>">
                                <img src= "<?php echo ($CONFIG->wwwroot . $annotation['value'] . '_thumblarge.jpg'); ?>" width="100" height="100" />
                                </a>
                        </div>	
				<?php		
                        }		
				?>
			</div>
            <div class="clearfloat"></div>
			<!-- display the actual artfolio post -->
           	<!-- displaying the body -->
            <div class="artfolio_post_body">
            	<?php
							echo autop($vars['entity']->description);
				?>
			</div>
			<!-- display edit options if it is the artfolio post owner -->
			<p class="options">
			<?php
	
				if ($vars['entity']->canEdit()) {
					
				?>
					<a href="<?php echo $vars['url']; ?>mod/artfolio/upload.php?artfoliopost=<?php echo $vars['entity']->getGUID(); ?>"><?php echo elgg_echo("upload"); ?></a>  &nbsp;
                    <a href="<?php echo $vars['url']; ?>mod/artfolio/edit.php?artfoliopost=<?php echo $vars['entity']->getGUID(); ?>"><?php echo elgg_echo("edit"); ?></a>  &nbsp; 
					<?php
					
						echo elgg_view("output/confirmlink", array(
																	'href' => $vars['url'] . "action/artfolio/delete?artfoliopost=" . $vars['entity']->getGUID(),
																	'text' => elgg_echo('delete'),
																	'confirm' => elgg_echo('deleteconfirm'),
																));
	
						// Allow the menu to be extended
						echo elgg_view("editmenu",array('entity' => $vars['entity']));
					
					?>
				<?php
				}
			?>
			</p>
		</div>
         <!-- display the rating form, if user is logged in and has no previous vote sessios for this post -->
            <div class="artfolio_post">
            	<?php
					if (isloggedin() && $vars['artfoliorated'] != $vars['entity']->getGUID()) {
				?>
            		<form id="form1" name="form1" method="post" action="<?php echo $vars['url']; ?>action/artfolio/rate">
  						<p>
                            <label><?php echo elgg_echo("artfolio:rate"); ?><br />
  								<select name="rating" id="rating">
							  		<option value="5.00">5 - <?php echo elgg_echo('artfolio:rate5'); ?></option>
  								    <option value="4.00">4 - <?php echo elgg_echo('artfolio:rate4'); ?></option>
        							<option value="3.00">3 - <?php echo elgg_echo('artfolio:rate3'); ?></option>
        							<option value="2.00">2 - <?php echo elgg_echo('artfolio:rate2'); ?></option>
        							<option value="1.00">1 - <?php echo elgg_echo('artfolio:rate1'); ?></option>
        							<option value="0.00">0 - <?php echo elgg_echo('artfolio:rate0'); ?></option>
  								</select>
                            </label>
                            <input type="hidden" name="artfoliopost" value="<?php echo $vars['entity']->getGUID(); ?>" />
                            <input type="hidden" name="artfoliopostacces" value="<?php echo $vars['entity']->access_id; ?>" />
                            <input type="submit" name="submit" value="<?php echo elgg_echo("artfolio:rate"); ?>" />
            			</p>
                    </form>
                <?php
					}
				?>
                    <div class="artfolio_gallery_rating">
                    	<img src="<?php echo $CONFIG->wwwroot; ?>mod/artfolio/images/<?php echo $rating_image; ?>"/><BR>
                        <?php echo ("(" . $numvotes . " " . elgg_echo('artfolio:votes') . ")"); ?>
                    </div>
            </div>
<?php

			// If we've been asked to display the full view
				if (isset($vars['full']) && $vars['full'] == true) {
					echo elgg_view_comments($vars['entity']);
				}
				
			}

		}

?>