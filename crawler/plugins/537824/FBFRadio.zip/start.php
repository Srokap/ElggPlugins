<?php

	/**
	 * Elgg FBFRadio Plugin
	 * 
	 * @package FBFRadio
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Malaga Jack
	 * @copyright Malaga Jack 2010
	 * @link http://FBFRadio.com/
	 * 
	 */
	
		function FBFRadio_init() {
    		
    		
			
    		//add a widget
			    add_widget_type('FBFRadio',elgg_echo("FBFRadio:title"),elgg_echo("FBFRadio:description"));
			
		}
		
		register_elgg_event_handler('init','system','FBFRadio_init');

?>