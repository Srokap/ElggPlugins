<?php

	$english = array(
	
		/**
		 * My HTML details
		 */
		
	        
	        'FBFRadio:title' => "FBFRadio",
	        'FBFRadio:description' => "Pop out Radio"
	        
		
	);
					
	add_translation("en",$english);

?>