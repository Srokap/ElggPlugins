<?php
    
	/**
	 * Elgg FBFRadio Plugin
	 * 
	 * @package FBFRadio
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Malaga Jack
	 * @copyright Malaga Jack
	 * @link http://FBFRadio.com/
	 * <A HREF="javascript:void(window.close('http://FBFRadio.com/FBFRadio.html'))">close radio</A><BR>
	 */
	 

?>

<SCRIPT LANGUAGE="JavaScript">

function goradio() {

TheNewWin =window.open("http://FBFRadio.com/FBFRadio.html",'TheNewpop','toolbar=0,location=0,directories=0,status=0,menubar=0,scrollbars=0,resizable=0,width=300, height=120' ); 

TheNewWin.blur();

}
</SCRIPT> 
<center>

<FORM>
<input type="image" src="<?php echo $vars['url']; ?>mod/FBFRadio/image/Button3.jpg"alt="Pop Radio" border="0" width="264" height="44"onClick="goradio()">
</FORM>


</center>
