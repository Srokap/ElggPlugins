<?php

	/**
	 * Elgg TheGameBox Plugin
	 * 
	 * @package The GameBox
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Malaga Jack
	 * @copyright Malaga Jack 2009
	 * @link http://fbfkids.com/
	 * 
	 */

?>
 

<h6><a href="http://fbfkids.com" title="FBFKids" target="_blank"><span style="text-decoration:none;color:#400000;">Courtesy of FBFKids</span></a><br></h6>

