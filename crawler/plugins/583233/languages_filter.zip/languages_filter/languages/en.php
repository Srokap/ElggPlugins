<?php

	$english = array(
		'languages_filter:settings' => 'Select the languages you want to show in user settings page'
	);

	add_translation("en",$english);
?>