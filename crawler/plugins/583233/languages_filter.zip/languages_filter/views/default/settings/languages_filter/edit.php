<?php echo elgg_echo('languages_filter:settings'); ?>
<p>
	<select id="languages_filter_select_field" multiple="multiple">
	<?php
	$languages = get_installed_translations();
	$selected_languages = explode(',', $vars['entity']->selected_languages);
	foreach($languages as $key => $name){
		$selected = in_array($key, $selected_languages) ? ' selected="selected"' : '';
		echo "<option value=\"$key\"$selected>$name</option>";
	}
	?>
	</select>
	<input type="hidden" id="languages_filter_real_field" name="params[selected_languages]" value="<?php echo $vars['entity']->selected_languages; ?>" />
	<script>
		$("#languages_filter_select_field").change(function(){
			var value = [];
			$("#languages_filter_select_field option:selected").each(function(){
				value.push($(this).val());
			});
			$("#languages_filter_real_field").val(value.join(","));
		});
	</script>
</p>