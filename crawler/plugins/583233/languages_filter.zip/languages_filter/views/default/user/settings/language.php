<?php
/**
 * Provide a way of setting your language prefs
 *
 * @package Elgg
 * @subpackage Core
 * @author Curverider Ltd
 * @link http://elgg.org/
 */

global $CONFIG;
$user = page_owner_entity();

if ($user) {
?>
<h3><?php echo elgg_echo('user:set:language'); ?></h3>
<p>

	<?php echo elgg_echo('user:language:label'); ?>: <?php

		$value = $CONFIG->language;
		if ($user->language) {
			$value = $user->language;
		}

		$selected_languages = explode(',', get_plugin_setting('selected_languages', 'languages_filter'));
		$instaled_languages = get_installed_translations();
		foreach($selected_languages as $key){
			$languages[$key] = $instaled_languages[$key];
		}

		echo elgg_view("input/pulldown", array('internalname' => 'language', 'value' => $value, 'options_values' => $languages));

	?>

</p>

<?php
}