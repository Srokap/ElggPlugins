<?php
	$inactive = $vars['entity']->inactive;
	if (!$inactive) $inactive = 10;
	else if(!is_numeric($inactive) || $inactive < 0 ){
		register_error(elgg_echo("group_expire:integer"));
		
	}

	$recipients = $vars['entity']->recipients;
	if (!$recipients) $recipients = elgg_echo('group_expire:recipients:admins');

	$method = $vars['entity']->method;
	if (!$method) $method = elgg_echo('group_expire:method:manual');
?>

<p>
	<?php echo elgg_echo('group_expire:inactive'); ?>
	
	<?php
		echo elgg_view('input/text', array(
			'internalname' => 'params[inactive]',
			'value' => $inactive,
			'class' => 'group_expire-textarea',
		));
	?>
</p><br/>

<p>
	<?php echo elgg_echo('group_expire:recipients'); ?>
	
	<?php
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[recipients]',
			'options_values' => array(
				elgg_echo('group_expire:recipients:admins')  => 'Admins',
				elgg_echo('group_expire:recipients:none') => 'None',
			),
			'value' => $recipients
		));
	?>
</p><br/>

<p>
	<?php echo elgg_echo('group_expire:method'); ?>
	
	<?php
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[method]',
			'options_values' => array(
				elgg_echo('group_expire:method:auto') => 'Auto',
				elgg_echo('group_expire:method:manual') => 'Manual',
			),
			'value' => $method
		));
	?>
</p><br/>