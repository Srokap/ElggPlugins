<script type="text/javascript">
$(document).ready(function(){
		var confirm = false;
        $("#group_expire").submit(function(event){
			$('<div></div>').html('<p>Are you sure you want to permanently delete these inactive entites?</p><p>You will lose all associated content with no chance of recovery!!</p>').dialog({
				buttons:{
					"Confirm": function(){confirm = true;
									$("#group_expire").submit();},
					"Cancel": function(){$(this).dialog('close');}},
				modal: true
				});
					
                        
            return confirm;
            }); 
    });  
</script>