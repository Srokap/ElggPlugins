<?php
	global $CONFIG;
	admin_gatekeeper();
	forward($CONFIG->wwwroot);
?>

	

	