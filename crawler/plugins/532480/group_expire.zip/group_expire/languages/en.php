<?php
	/**
	 * Elgg log rotator language pack.
	 * 
	 * @package ElggLogRotate
	 * @author Curverider Ltd
	 * @link http://elgg.com/
	 */

	$english = array(
		'group_expire:inactive' => 'Set limit for inactivity (in days):',
		'group_expire:recipients' => 'Select the recipients of the inactivity report:',
		'group_expire:recipients:none' => 'none',
		'group_expire:recipients:admins' => 'admins',
		'group_expire:recipients:owners' => 'owners',
		'group_expire:recipients:both' => 'both',
		'group_expire:method' => 'Select deletion method:',
		'group_expire:method:auto' => 'auto',
		'group_expire:method:manual' => 'manual',
		'group_expire:integer' => 'You must provide a numerical value greater than 0 for this entry!',
	);
					
	add_translation("en",$english);
?>