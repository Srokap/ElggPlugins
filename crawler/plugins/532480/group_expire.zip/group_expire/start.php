<?php
	/**
	 * Group Expire Plugin
	 * 
	 * @package Group Expire Plugin
	 * @author Michael Nixon
	 * @link None
	 */

	/**
	 * Initialise the plugin.
	 *
	 */
	function group_expire_init(){
		
		global $CONFIG;
		
		elgg_extend_view('metatags', 'group_expire/metatags');

		elgg_extend_view('css', 'group_expire/css');
		
		// Register cron hook
		register_plugin_hook('cron', 'daily', 'group_expire_cron');
		
		// Register messages/send hook
		register_plugin_hook('action', 'messages/send', 'group_expire_approved');
		
		// Register group_expire/submit hook
		register_plugin_hook('action', 'group_expire/submit', 'group_expire_cron');
		
		// Create menu entry for Admins only
		$url = elgg_add_action_tokens_to_url($CONFIG->wwwroot."action/group_expire/submit"); 
		if(isloggedin() && $_SESSION['user']->isAdmin()){
			add_menu('Inactivity Check', $url);}

	}

	/**
	 * Processes an array of group entities for deletion
	 *
	 */
	function group_expire_remove($array){
		
		global $CONFIG;
		
		foreach($array as $myObj){
			$groupsExpired = get_entity($myObj->guid);
			if(!$groupsExpired->delete())
				return false;
		}
		
		return true;
			
	}

	/**
	 * Processes an array of group entities and attaches the `inactive` annotation to each one.
	 * This creates a queue for the approval process.
	 */
	function group_expire_annotate($array){
		
		global $CONFIG;

		foreach($array as $myObj){
			$groupsExpired = get_entity($myObj->guid);

			if(!count_annotations($groupsExpired->guid))
				if(!$groupsExpired->annotate('inactive', 'yes', $groupsExpired->access_id))
					return false;
		}
		
		return true;
	}

	/**
	 * Processes all inactive entites approved for deletion by the admin via the approval message.
	 * Deletes previous approval message or resends the approval message with current info in case 
	 * an admin trys to approve deletion for an entity that no longer exists.
	 */
	function group_expire_approved($hook, $entity_type, $returnvalue, $params){
	
		global $CONFIG;
		
		//Build URL to have notification message deleted
		$url = elgg_add_action_tokens_to_url($CONFIG->wwwroot."action/messages/delete?message_id=".trim(strrchr($_SERVER['HTTP_REFERER'],'/'),'/')."&type=inbox&submit=".elgg_echo('delete')); 													
															
		if($_POST['group_expire']){
			foreach($_POST as $k => $v){
				if($v == "Delete"){
					if(!get_entity($k)){
						register_error("One or more of the groups were unavailable. Please review the new inactivity log that has been sent. We will attempt to delete your previous log.");
						register_error("If you do not recieve a new log, there are no instances of inactivity to report");
						group_expire_cron();
						forward($url);}
					$groupExpired = get_entity($k);
					if($groupExpired->delete())
						system_message($groupExpired->name." was successfully removed");
					else{
						forward($url);
						register_error($groupExpired->name." could not be removed");}
				}
			}
			return forward($url);}
		else{
			
			register_error("Your request could not be completed");
			return true;}
	}

	/**
	 * Creates the approval message or deletion log of inactive entities based on plugin settings.
	 * 
	 */
	function group_expire_mailer($recipients, $method){
		
		global $CONFIG;
		
		$query = "SELECT guid, name, admin FROM {$CONFIG->dbprefix}users_entity"; 
		$results = get_data($query);
//		$method = get_plugin_setting('method','group_expire');
		$annotations = get_entities_from_annotations('group','','inactive','');

		if($recipients != elgg_echo('group_expire:recipients:none')){
			if($method != elgg_echo('group_expire:method:auto')){
				if(!$annotations) return system_message("There are no instances of inactivity");
				else{
					$body = "<h3>Inactivity Report</h3></br><p>Please verify each listing before clicking on \"Approve\"!</p><h4>**All listings are checked by default!**</h4><hr/>";
					$body .= "<form action=\"{$CONFIG->wwwroot}action/messages/send\" method=\"post\" name=\"group_expire\">";
					$body .= "<input type=\"hidden\" name=\"group_expire\" value=\"true\" />";
					foreach($annotations as $groupsExpired) {
						$guid = $groupsExpired->guid;
						$group = get_entity($guid);					
						$body .= "<div class=\"inactivity_report\" ><table width=\"100%\" cellspacing='0'><tr>";
						$body .= "<td width='250px'><div class='inactivity_entry'><b>".$group->name." - "."</b><small>Reason: Has reached an inactive status</small></div></td>";
						$body .= "<td><div class='inactivity_check'>";
						$body .= "<input checked=\"yes\" type=\"checkbox\" name=\"{$group->guid}\" value=\"Delete\" /></td>";
						$body .= "</td></tr></table></div>";
						$body .= "</div>"; // close the message background div
					}//end of for each loop
					$body .= elgg_view('input/securitytoken');
					$body .= "<input id=\"expired\" type=\"submit\" class=\"submit_button\" value=\"Approve\" /></form>";
					$subject = "Your Approval Is Needed";}
			}else{
				$body = "<h3>Inactivity Report</h3></br><p>The following cases of inactivity have been removed from the system!</p><hr/>";
				foreach($annotations as $groupsExpired){
					$guid = $groupsExpired->guid;
					$group = get_entity($guid);
					$body .= "<div class=\"inactivity_report\" ><table width=\"100%\" cellspacing='0'><tr>";
					$body .= "<td width='250px'><div class='inactivity_entry'><b>" . $group->name."</b></div></td>";
					$body .= "</tr></table></div>";
				}//end of for each loop
				$subject = "Inactivty Report";
			}

				foreach($results as $users){
					$admin = $users->admin;
					$to = $users->guid;
					if($admin == 'yes')
						if(!notify_user($to, '2', $subject, $body, null, 'site')) return register_error("1: fail");
				}
		return system_message("Inactivity Reports Sent!");
		}
		else return true;
			

	}
	/**
	 * Triggers the group expire plugin
	 *
	 */
	function group_expire_cron($hook, $entity_type, $returnvalue, $params){
	
		global $CONFIG;
		
		$subject = "";
		$body = "";
		$time = time();
		$day = 86400;
		$inactive = get_plugin_setting('inactive','group_expire');
		$recipients = get_plugin_setting('recipients','group_expire');
		$method = get_plugin_setting('method','group_expire');
		$killTime = $time - ($day * $inactive);		
		$groupArray = get_data("SELECT * from {$CONFIG->dbprefix}entities WHERE `type`=\"group\" AND `time_updated` < {$killTime}");

		if($groupArray > 0){
			if($method != elgg_echo('group_expire:method:auto')){
				group_expire_annotate($groupArray);
				group_expire_mailer($recipients, $method);				
			}else{
				group_expire_annotate($groupArray);
				group_expire_mailer($recipients, $method);
				group_expire_remove($groupArray);		
			}
		}else{
				group_expire_mailer($recipients, $method);
			}

	}
	
	// Initialise plugin
	register_elgg_event_handler('init','system','group_expire_init');

	// Register group_expire/submit action
	register_action('group_expire/submit', false, $CONFIG->pluginspath . 'group_expire/actions/submit.php', true);
	
	//

?>