PHPUnit Test Runner
-------------------
See ExampleTest.php for an example test case.

See ElggTestCase.php for methods facilitating tests within the Elgg framework.

Methods of note:
* action: run an elgg action, automatically handling form tokens
* run_as_request: run the given test function as if it were a web request
* get/post: invoke an arbitrary GET/POST request
* addTestUser: add or note a user scoped to the test lifetime