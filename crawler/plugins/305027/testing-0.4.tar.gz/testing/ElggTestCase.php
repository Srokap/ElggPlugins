<?php

require_once('PHPUnit/Framework/TestSuite.php');

/** Base test class for anything that needs to run under Elgg. */
// TODO: need facilities for logging in as a given user for the duration
// of a test
abstract class ElggTestCase extends PHPUnit_Framework_TestCase
{
  const TEST_USER = 'test_user';
  const TEST_PASSWORD = 'ATestUser';
  const TEST_EMAIL = 'test_user@testing.org';

  // Setting $backupGlobals false prevents PHPUnit from restoring globals'
  // state and erasing the results of any elgg lazy init.
  protected $backupGlobals = FALSE;

  // Any elgg users created during this test
  protected $users;

  // Current cURL session, if any
  protected $curl;
  private $cookies;

  /** Extract a single error message. */
  // TODO: return an array of all of them
  protected function extract_error($response) {
    if (preg_match('/^.*<div class="messages_error">(.*?)<\\/div.*$/s',
                   $response, $matches)) {
      return preg_replace('/^.*<p>(.*?)<\\/p>.*$/s', '\\1', $matches[1]);
    }
    return false;
  }

  /** Extract a single system message. */
  // TODO: return an array of all of them
  protected function extract_message($response) {
    if (preg_match('/^.*<div class="messages">(.*?)<\\/div.*$/s',
                   $response, $matches)) {
      return preg_replace('/^.*<p>(.*?)<\\/p>.*$/s', '\\1', $matches[1]);
    }
    return false;
  }

  protected function get_cookies($headers, &$cookies) {
    $lines = explode("\r\n", $headers);
    foreach($lines as $line) {
      if (strpos($line, 'Set-Cookie: ') === 0) {
        if (preg_match('/[^:]:\\s*([^=]+)=([^;]+);.*/', $line, $matches)) {
          $cookies[$matches[1]] = urldecode($matches[2]);
        }
      }
    }
    return $cookies;
  }

  // This method should be used for any requests which require session
  // information
  protected function get($url, $data = false, &$cookies = false) {
    if (is_array($data)) {
      if (strpos($url, '?') === false)
        $url .= '?';
      $url .= http_build_query($data);
    }

    if (!$this->curl) {
      $this->curl = curl_init();
      $this->cookies = tempnam('/tmp', 'CURLCOOKIES');
      if ($cookies) {
        foreach($cookies as $key=>$value) {
          $cookie_data .= "{$key}={$value}; ";
        }
      }
    }
    curl_setopt_array($this->curl, array(CURLOPT_URL=>$url,
                                         CURLOPT_HTTPGET=>true,
                                         CURLOPT_FOLLOWLOCATION=>1,
                                         CURLOPT_RETURNTRANSFER=>true,
                                         CURLOPT_COOKIEJAR=>$this->cookies,
                                         CURLOPT_COOKIEFILE=>$this->cookies,
                                         CURLOPT_COOKIE=>$cookie_data,
                                         CURLOPT_HEADER=>true,
                                         ));

    $response = curl_exec($this->curl);
    if ($response === false) {
      throw new Exception("GET from {$url} failed: {$php_errormsg}");
    }

    list($headers, $body) = explode("\r\n\r\n", $response, 2);

    if ($cookies) {
      $cookies = $this->get_cookies($headers, $cookies);
    }

    return $body;
  }

  // This method should be used for any requests which require session
  // information
  protected function post($url, $data = array(), &$cookies=false) {

    if (!$this->curl) {
      $this->curl = curl_init();
      $this->cookies = tempnam('/tmp', 'CURLCOOKIES');
      if ($cookies) {
        foreach($cookies as $key=>$value) {
          $cookie_data .= "{$key}={$value}; ";
        }
      }
    }

    curl_setopt_array($this->curl, array(CURLOPT_URL=>$url,
                                         CURLOPT_POST=>true,
                                         CURLOPT_POSTFIELDS=>$data,
                                         CURLOPT_FOLLOWLOCATION=>1,
                                         CURLOPT_RETURNTRANSFER=>true,
                                         CURLOPT_COOKIEJAR=>$this->cookies,
                                         CURLOPT_COOKIEFILE=>$this->cookies,
                                         CURLOPT_COOKIE=>$cookie_data,
                                         CURLOPT_HEADER=>true,
                                         ));

    $response = curl_exec($this->curl);
    if ($response === false) {
      throw new Exception("POST to {$url} failed: {$php_errormsg}");
    }

    list($headers, $body) = explode("\r\n\r\n", $response, 2);
    // FIXME do this properly: handle HTTP/1.1 100 Continue
    if (strpos($body, 'HTTP') === 0) {
      list($headers, $body) = explode("\r\n\r\n", $body, 2);
    }

    if ($cookies) {
      $cookies = $this->get_cookies($headers, $cookies);
    }

    return $body;
  }

  /** Return the results of an elgg action (via POST). */
  protected function action($action, $data = array(), &$cookies = false) {
    global $CONFIG;
    $form = json_decode($this->get("{$CONFIG->url}pg/testing/action-tokens"));
    $data = array_merge($data, array('__elgg_ts'=>$form->ts,
                                     '__elgg_token'=>$form->token));
    $url = "{$CONFIG->url}action/{$action}";

    return $this->post($url, $data, $cookies);
  }

  /** Run a function in the context of a separate GET/POST request
      @uses $function method of this test class to invoke
      @uses $data array of name/value pairs
      @uses $cookies array of cookies
      @uses $method 'GET' or 'POST'
      @uses $user_guid defaults to currently logged in user (usually admin)
   */
  protected function run_as_request($function, $data = array(), &$cookies = false, $method='GET', $user_guid=0) {
    global $CONFIG;
    // HACK: preserve current user login, since elgg allows only one at a time
    $saved_user = get_loggedin_user();
    if (!$user_guid) $user_guid = $saved_user->getGUID();
    $class = get_class($this);
    // Avoid using actions or page handler which modify inputs
    $url = "{$CONFIG->url}mod/testing/run_test_method.php";
    $data = array_merge($data, array('__file'=>$file,
                                     '__user'=>$user_guid,
                                     '__class'=>$class,
                                     '__method'=>$function));
    if (preg_match('/^get$/i', $method)) {
      $response = $this->get($url, $data, $cookies);
    }
    else {
      $response = $this->post($url, $data, $cookies);
    }
    // HACK: restore current user login
    login($saved_user);
    return $response;
  }

  /** Add another user for testing. */
  protected function addTestUser($username, $password, $email, $validate=false) {
    $user = get_user_by_username($username);
    if (!$user) {
      $guid = register_user($username, $password, $username, $email);
      if (!$guid) {
        throw new Exception("register_user failed for '".$username."'");
      }
      $user = get_user($guid);
    }
    if ($validate) {
      request_user_validation($user->getGUID());
    }
    else {
      $user->validated = true;
    }
    $this->users[$username] = $user;
    return $user;
  }

  protected function setUp() {
    // always add a test user
    $user = get_user_by_username(self::TEST_USER);
    if ($user) {
      if ($user->delete()) {
        throw new Exception("Test user not removed in previous test, aborting");
      }
      else {
        throw new Exception("Test user already exists and can't delete it, aborting");
      }
    }
    $this->addTestUser(self::TEST_USER, self::TEST_PASSWORD, self::TEST_EMAIL);
  }

  // clear any system error messages generated by tests
  protected function clearMessages() {
    $msgs = system_messages("messages");
    $errs = system_messages("errors");
  }

  protected function tearDown() {
    if ($this->curl) {
      curl_close($this->curl);
    }
    if (file_exists($this->cookies)) {
      unlink($this->cookies);
    }

    $this->clearMessages();

    $users = $this->users;
    $this->users = false;
    $failed = array();
    if ($users) foreach($users as $user) {
      if (!$user->delete()) {
        $failed[] = $user;
      }
    }
    if (count($failed)) {
      throw new Exception("could not remove one or more test users after test");
    }
    $user = get_user_by_username(self::TEST_USER);
    if ($user) {
      if (!$user->delete()) {
        throw new Exception("could not remove default test user after test ($user->guid}");
      }
    }
  }
}

?>