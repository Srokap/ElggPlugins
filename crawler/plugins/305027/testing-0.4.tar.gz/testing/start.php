<?php

  /**
   * Testing Plugin
   * Facilitate execution of various types of tests
   *
   * Run PHPUnit from the web server to avoid any potential differences with
   * the CLI environment.
   *
   * @package famos
   * @author famos LLC <info@famos.com>
   * @copyright famos LLC 2009
   * @link http://famos.com/
   */
function testing_init() {

  if (preg_match('/\/testing\/log/', current_page_url())) {
    // Turn off logging for display of this page
    ini_set('error_log', '/dev/null');
    require_once('Log.php');
    $logger = Log::singleton('error_log');
    $logger->setMask(0);
  }

  register_translations(dirname(__FILE__) . '/languages/');
  register_page_handler('testing', 'testing_page_handler');
}

function testing_page_handler($page) {

  switch($page[0]) {
  case 'action-tokens':
    $ts = time();
    $token = generate_action_token($ts);
    echo json_encode(array('ts'=>$ts, 'token'=>$token));
    break;
  case 'log':
    if (!isadminloggedin()) {
      forward();
    }
    echo elgg_view('pageshells/basic', array('title'=>'Log', 'body'=>elgg_view('testing/log')));
    break;
  case 'info':
    if (!isadminloggedin()) {
      forward();
    }
    // When you want to get some info...
    $body = 'get_metastring_id(false)=' . get_metastring_id(false)."<br/>";
    $body .= 'get_metastring_id(0)=' . get_metastring_id(0)."<br/>";
    $body .= 'get_metastring_id("")=' . get_metastring_id("")."<br/>";
    $body .= 'get_metastring_id("0")=' . get_metastring_id("0")."<br/>";

    echo elgg_view('pageshells/basic', array('title'=>'Info', 'body'=>$body));
    break;
  default:
    if (!isadminloggedin()) {
      forward();
    }
    testing_run_tests($page[0], $page[1]);
    break;
  }
}

function testing_get_search_paths() {
  global $CONFIG;
  $paths = array();
  if (get_plugin_setting('autoscan', 'testing')) {
    $paths[] = realpath($CONFIG->path);
  }
  else {
    $plugins = array_values(get_plugin_list());
    foreach($plugins as $plugin) {
      if (is_plugin_enabled($plugin)
          && get_plugin_setting("test_{$plugin}", 'testing')) {
        $paths[] = realpath($CONFIG->pluginspath . '/' . $plugin);
      }
    }

    $more = explode(' ', get_plugin_setting('additional', 'testing'));
    foreach ($more as $dir) {
      if (empty($dir)) continue;
      $paths[] = realpath($CONFIG->path . '/' . $dir);
    }
  }
  return $paths;
}

function testing_find_file($name, $dir = false) {
  $file = false;
  if (!$dir) {
    $paths = testing_get_search_paths();
    foreach ($paths as $path) {
      if (($file = testing_find_file($name, $path)) !== false) {
        break;
      }
    }
  }
  else {
    $path = "{$dir}/{$name}";
    if (file_exists($path)) {
      $file = $path;
    }
    else {
      $d = dir($dir);
      while (($entry = $d->read()) !== false) {
        $path = "{$dir}/{$entry}";
        if (is_dir($path)) {
          if ($entry == '.' || $entry == '..') {
            continue;
          }
          if (($file = testing_find_file($name, $path)) !== false) {
            break;
          }
        }
      }
      $d->close();
    }
  }
  return $file;
}

function testing_run_tests($class=false, $method=false) {

  require_once('PHPUnit/TextUI/TestRunner.php');
  require_once('PHPUnit/Framework/TestSuite.php');
  require_once(dirname(__FILE__) . '/ElggTestCase.php');

  $runner = new PHPUnit_TextUI_TestRunner;
  $suite = new PHPUnit_Framework_TestSuite();

  global $CONFIG;

  if ($class) {
    require_once(testing_find_file($class . ".php"));
    if ($method) {
      // Methods need special handling for annotations
      $suite->addTest($suite->createTest(new ReflectionClass($class), $method));
    }
    else {
      $suite->addTest(new ReflectionClass($class));
    }
  }
  else {
    $paths = testing_get_search_paths();
    foreach ($paths as $dir) {
      // Let the test runner scan each directory
      $suite->addTest($runner->getTest($dir));
    }
  }

  try {
    ob_start();
    // TODO: use a custom runner to emit the output as it is produced
    // and format it the way we want instead of parsing text

    $config = find_plugin_settings('testing');
    // FIXME: runner is picky about boolean values
    $arguments = array('convertErrorsToExceptions'=>$config->convertErrorsToExceptions?true:false,
                       'convertWarningsToExceptions'=>$config->convertWarningsToExceptions?true:false,
                       'convertNoticesToExceptions'=>$config->convertNoticesToExceptions?true:false,
                       'verbose'=>$config->verbose?true:false);
    $runner->doRun($suite, $arguments);
    $results = ob_get_clean();

    $url = $CONFIG->url . 'pg/testing/';
    $errors = preg_match('/^There .* errors?:$/m', $results);
    $failures = preg_match('/^There .* failures?:$/m', $results);

    $results = preg_replace('/^(There.*errors?:\n\n)(([1-9][0-9]*\\).*?\n\n)*)/ms', '<span id="error-header">\\1</span><div id="phpunit-errors">\\2</div>', $results);
    $results = preg_replace('/^(There.*failures?:\n\n)(([1-9][0-9]*\\).*?\n\n)*)/ms', '<span id="failure-header">\\1</span><div id="phpunit-failures">\\2</div>', $results);
    
    if ($errors && $failures) {
      list($errors, $failures) = explode('--', $results, 2);
      $body = preg_replace('/([1-9][0-9]*\\) )([^\\(]+)\\(([^\\)]+)\\)([^\n]*)(\n.*?)\n\n/ms',
                           "<span class='phpunit error'>\\1<a title='Re-run this test' href='{$url}\\3/\\2'>\\2(\\3)</a>\\4\\5</span>\n\n", $errors);
      $body .= "--\n\n";
      $body .= preg_replace('/([1-9][0-9]*\\) )([^\\(]+)\\(([^\\)]+)\\)([^\n]*)(\n.*?)\n\n/ms',
                            "<span class='phpunit failure'>\\1<a title='Re-run this test' href='{$url}\\3/\\2'>\\2(\\3)</a>\\4\\5</span>\n\n", $failures);
    }
    else {
      $type = $class ? 'error' : 'failure';
      $body = preg_replace('/([1-9][0-9]*\\) )([^\\(]+)\\(([^\\)]+)\\)([^\n]*)(\n.*?\n\n)/ms',
                           "<span class='phpunit {$type}'>\\1<a title='Re-run this test' href='{$url}\\3/\\2'>\\2(\\3)</a>\\4\\5</span>\n\n", $results);
    }

    $body = str_replace("--\n\n\n\n\n", "\n", $body);
    $body = str_replace("\n", "<br/>", $body);

    $body .= <<<END
<script type='text/javascript'>
$(document).ready(function() {
    $('#error-header').click(function() { $('#phpunit-errors').slideToggle(); });
    $('#failure-header').click(function() { $('#phpunit-failures').slideToggle(); });
});
</script>
END;

    // Clear elgg system error messages
    system_messages(null, "messages");
    system_messages(null, "errors");
  }
  catch(Exception $e) {
    $body = 'Could not create and run test suite: ' . $e->getMessage();
    $body .= "<br/>" . str_replace("\n", "<br/>", $e->getTraceAsString());
  }
  // TODO: display settings form inline
  $body .= "<p><a href='{$CONFIG->url}pg/admin/plugins'>Change Settings</a></p>";
  if ($class) {
    $body .= "<p><a href='{$CONFIG->url}pg/testing'>Run All Tests</a></p>";
  }

  $manifest = load_plugin_manifest('testing');
  $version = $manifest['version'];
  $body = "Elgg Test Runner {$version} by Timothy Wall.<br/>{$body}";
  
  page_draw("PHPUnit Test Results", $body);
}

register_elgg_event_handler('init','system','testing_init');

?>