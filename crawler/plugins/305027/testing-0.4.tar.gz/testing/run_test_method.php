<?php

require_once(dirname(dirname(dirname(__FILE__))) . '/engine/start.php');

if (!preg_match('/^(?i:localhost|127.0.0.1)$/', $_SERVER['REMOTE_ADDR'])) {
  forward();
}

login(get_entity(get_input('__user')));

$class = get_input('__class');
$method = get_input('__method');
$file = get_input('__file');
if (!$file) {
  $file = testing_find_file($class . '.php');
}

unset($_REQUEST['__class']);
unset($_REQUEST['__method']);
unset($_REQUEST['__file']);
unset($_REQUEST['__user']);

unset($_GET['__class']);
unset($_GET['__method']);
unset($_GET['__file']);
unset($_GET['__user']);

unset($_POST['__class']);
unset($_POST['__method']);
unset($_POST['__file']);
unset($_POST['__user']);

require_once('PHPUnit/Framework/TestSuite.php');
require_once(dirname(__FILE__) . '/ElggTestCase.php');
require_once($file);
$test = new $class;
$test->$method();

?>