<?php

  /**
   * Elgg checkbox input
   * Displays a checkbox input field.  Provides a form input whether or not
   * the checkbox is checked.  Will work for widgets.
   * 
   * @package famos
   * @subpackage elggx
   * @link http://famos.com/
   * 
   * @uses $vars['value'] The current value, if any
   * @uses $vars['js'] Any Javascript to enter into the input tag
   * @uses $vars['internalname'] The name of the input field
   * @uses $vars['option'] The option name
   * @uses $vars['label'] The checkbox label (of omitted, 'option' is used)
   * 
   */

  // If "option" provided, use option or an empty string as the value
  // if value provided, use true/false, 1/0, depending on value

$class = $vars['class'];
if (!$class) $class = "input-checkbox";
	
if (isset($vars['option'])) {
  $option = $vars['option'];
  $value = $vars['value'] ? $option : "";
  $value = htmlentities($value, null, 'UTF-8');
  $true = $vars['option'];
  $cbname = $vars['internalname'];
  $hidden = "";
}
else {
  $option = $vars['internalname'];
  $value = strtolower("{$vars['value']}");
  if ($value == "0") $value = "";
  $true = "1";
  $cbname = "__fake_" . $vars['internalname'];
  $hidden = "<input type='hidden' name='{$vars['internalname']}' value='{$value}'/>";
}

$label = isset($vars['label']) ? $vars['label'] : $option;
$selected = !empty($value) ? "checked = \"checked\"" : "";
$disabled = $vars['disabled'] ? $disabled = ' disabled="yes" ' : ""; 
$labelid = 'label'.mt_rand();

echo <<<EOT
<label id='{$labelid}'><input type='checkbox' $disabled {$vars['js']} name='__fake_{$vars['internalname']}' {$selected} class='{$class}' />{$label}{$hidden}</label>
<script type='text/javascript'>
  $(document).ready(function() {
      $('#{$labelid} input[type=checkbox]').change(function() {
          var value = $(this).attr('checked')?"{$true}":"";
          $('#{$labelid} input[type=hidden]').val(value);
        });
    });
</script>
EOT;

?> 