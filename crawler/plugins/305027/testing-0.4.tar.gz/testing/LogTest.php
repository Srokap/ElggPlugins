<?php

require_once('Log.php');

class LogTest extends ElggTestCase
{
  public function testSingletonToErrorLog() {
    $handler = 'error_log';

    $a = &Log::singleton($handler, 0, 'module1');
    $b = &Log::singleton($handler, 0, 'module2');

    $a->log('(a) first message');
    $b->log('(b) second message');
  }
}


?>