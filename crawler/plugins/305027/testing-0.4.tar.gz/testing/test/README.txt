This directory includes self tests and various tests of the elgg framework.

Include tests for bugs/fixes to core elgg here.
