<?php
class SelfTest extends ElggTestCase {

  public function runPOSTTest() {
    setcookie('server_cookie', isset($_COOKIE['client_cookie'])?$_COOKIE['client_cookie']:'client cookie missing', 0, '/');
    echo $_POST['data'];
  }

  public function runGETTest() {
    setcookie('server_cookie', isset($_COOKIE['client_cookie'])?$_COOKIE['client_cookie']:'client cookie missing', 0, '/');
    echo $_GET['data'];
  }

  public function testRunMethodFromGET() {
    global $CONFIG;
    $value = 'data value';
    $cookie_value = 'my cookie';
    $cookies = array('client_cookie'=>$cookie_value);
    $contents = $this->run_as_request('runGETTest', array('data'=>$value), $cookies, 'GET');
    $this->assertEquals($value, $contents, 'Wrong GET data');
    $this->assertEquals($cookie_value, $cookies['server_cookie'], 'Server cookie data missing');
  }

  public function testRunMethodFromPOST() {
    $value = "value";
    $cookie_value = 'my cookie';
    $cookies = array('client_cookie'=>$cookie_value);
    $contents = $this->run_as_request('runPOSTTest', array('data'=>$value), $cookies, 'POST');
    $this->assertEquals($value, $contents, 'Wrong POST data');
    $this->assertEquals($cookie_value, $cookies['server_cookie'], 'Server cookie data missing');
  }

  public function testExtractError() {
    $value = "this is an error";
    $doc = <<<END
<html><body>
<div class="messages_error">
<span class="closemessages"><a href="#">click to dismiss</a></span>
<p>
<p>{$value}</p>
</p>
</div>
</body></html>
END;
    $this->assertEquals($value, $this->extract_error($doc), 'Error message not extracted');
  }

  public function testTestUserAutoSetup() {
    $this->assertEquals(1, count($this->users), "One test user should be created in test setup");
    $user = $this->addTestUser(self::TEST_USER, self::TEST_PASSWORD, self::TEST_EMAIL);
    $this->assertEquals(1, count($this->users), "One test user should exist after superfluous addTestUser");
    $this->assertEquals(self::TEST_USER, $user->username, "Wrong username for test user");
  }

}
?>