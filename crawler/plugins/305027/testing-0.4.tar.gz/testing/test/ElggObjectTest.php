<?php

class ElggObjectTest extends ElggTestCase
{
  protected $obj = null;

  protected function setUp() {
    parent::setUp();
    $this->obj = new ElggObject();
    $this->title = 'Test Object for ElggObjectTest';
    if ($this->obj->getGUID() != 0) {
      throw new Exception("Test object unexpectedly has GUID");
    }
  }

  protected function tearDown() {
    if ($this->obj && $this->obj->getGUID()) {
      if (!$this->obj->delete()) {
        throw new Exception("Could not delete object '{$this->obj->title}', GUID {$this->obj->getGUID()}");
      }
      $this->obj = null;
    }
    parent::tearDown();
  }

  public function testObjectSave() {
    if (!$this->obj->save()) {
      $this->fail("Could not save object '{$this->obj->title}' {$this->obj->getGUID()}");
    }
    $this->assertTrue($this->obj->getGUID() != 0,
                      "Generated GUID should be non-zero");
  }

  public function testObjectDefaultAccess() {
    $this->assertEquals($this->obj->getAccessID(), ACCESS_PRIVATE,
                        "Wrong default access");
    $this->obj->save();
    $this->assertEquals($this->obj->getAccessID(), ACCESS_PRIVATE,
                        "Wrong default access after save");
  }

  public function testObjectSubtype() {
    $subtype = 'test-object';
    $this->obj->subtype = $subtype;
    $this->obj->save();
    $this->assertType('string', $this->obj->subtype,
                      'Subtype should be an integer after save');

    $obj = get_entity($this->obj->getGUID());
    $this->assertEquals($subtype, $obj->getSubtype(),
                        'Wrong subtype via getSubtype() (fresh object)');
    // XFAIL, bug in elgg, entity subtype not updated
    $this->assertType('string', $this->obj->getSubtype(),
                      'getSubtype should return a string after save');
    $this->assertEquals($subtype, $this->obj->getSubtype(),
                        'Wrong subtype via getSubtype()');
  }

}


?>