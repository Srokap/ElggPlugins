﻿<?php

	$russian = array(
	
	'item:object:event_calendar' => "Календарь событий",
	'event_calendar:new_event' => "Новое событие",
	'event_calendar:no_such_event_edit_error' => "Ошибка: Событие отсутствует.",
	'event_calendar:add_event_title' => "Добавить событие",
	'event_calendar:manage_event_title' => "Редактировать событие",
	'event_calendar:manage_event_description' => "Детализация события "
		."Название, дата события - обязательны для заполнения "
		."Нажмите на календарь, чтобы установить дату",
	'event_calendar:title_label' => "Заголовок",
	'event_calendar:title_description' => "Требуется 1-4 слова",
	'event_calendar:brief_description_label' => "Краткое описание",
	'event_calendar:brief_description_description' => "Необязательно. Короткая фраза.",
	'event_calendar:venue_label' => "Место",
	'event_calendar:venue_description' => "Место проведения",
	'event_calendar:start_date_label' => "Дата начала",
	'event_calendar:start_date_description'	=> "Время начала",
	'event_calendar:end_date_label' => "Дата окончания",
	'event_calendar:end_date_description'	=> "Необязательно. Время окончания"
		."used as the end date if this is not supplied.",
	'event_calendar:fees_label' => "Цена",
	'event_calendar:fees_description'	=> "Пояснение к цене",
	'event_calendar:contact_label' => "Контакты",
	'event_calendar:contact_description'	=> "Информация для справок "
			."желательно номер телефона, ICQ или e-mail",
	'event_calendar:organiser_label' => "Организатор",
	'event_calendar:organiser_description'	=> "",
	'event_calendar:event_tags_label' => "Тэги",
	'event_calendar:event_tags_description'	=> "",
	'event_calendar:long_description_label' => "Описание события",
	'event_calendar:long_description_description'	=> "",
	'event_calendar:manage_event_response' => "Ваше событие сохранено.",
	'event_calendar:add_event_response' => "Ваше событие добавлено",
	'event_calendar:manage_event_error' => "Ошибка: Событие не сохранено "
			."Заполните все поля",
	'event_calendar:show_events_title' => "Календарь событий",
	'event_calendar:day_label' => "День",
	'event_calendar:week_label' => "Неделя",
	'event_calendar:month_label' => "Месяц",
	'event_calendar:group' => "Календарь групп",
	'event_calendar:new' => "Добавить событие",
	'event_calendar:submit' => "Отправить",
	'event_calendar:cancel' => "Отмена",
	'event_calendar:widget_title' => "Календарь событий",
	'event_calendar:widget:description' => "Показывать события.",
	'event_calendar:num_display' => "Количество событий на экране",
	'event_calendar:groupprofile' => "Наступающие события",
	'event_calendar:view_calendar' => "смотреть календарь",
	'event_calendar:when_label' => "Когда",
	'event_calendar:site_wide_link' => "Все события",
	'event_calendar:view_link' => "Смотреть событие",
	'event_calendar:edit_link' => "Редактировать событие",
	'event_calendar:delete_link' => "Удалить событие",
	'event_calendar:delete_confirm_title' => "Подтвердите удаление",
	'event_calendar:delete_confirm_description' => "Вы уверены, что хотите удалить это событие?",
	'event_calendar:delete_response' => "Событие удалено.",
	'event_calendar:error_delete' => "Событие отсутствует или у вас нет прав для его редактирования.",
	'event_calendar:delete_cancel_response' => "Удаление отменено.",
	'event_calendar:add_to_my_calendar' => "Добавить в мой календарь",
	'event_calendar:remove_from_my_calendar' => "Удалить из моего календаря",
	'event_calendar:add_to_my_calendar_response' => "Событие добавлено в календарь.",
	'event_calendar:remove_from_my_calendar_response' => "Событие удалено из календаря.",
	'event_calendar:users_for_event_title' => "Заинтересованные событием: \"%s\"'",
	'event_calendar:personal_event_calendars_link' => "Личный календарь событий (%s)",
	'event_calendar:settings:group_profile_display:title' => "Календарь группы",
	'event_calendar:settings:group_profile_display_option:left' => "левая колонка",
	'event_calendar:settings:group_profile_display_option:right' => "правая колонка",
	'event_calendar:settings:group_profile_display_option:none' => "-",
	'event_calendar:settings:autopersonal:title' => "Автоматически добавлять события, которые пользователь создает в личном календаре.",
	'event_calendar:settings:yes' => "да",
	'event_calendar:settings:no' => "нет",
	'event_calendar:settings:site_calendar:title' => "Календарь сайта",
	'event_calendar:settings:site_calendar:admin' => "да, только админы могут добавлять события",
	'event_calendar:settings:site_calendar:loggedin' => "да, любой зарегестрированный пользователь",	
	'event_calendar:settings:group_calendar:title' => "Календарь групп",
	'event_calendar:settings:group_calendar:admin' => "да, только админы и владельцы групп",
	'event_calendar:settings:group_calendar:members' => "да, только участники групп",
	'event_calendar:settings:group_default:title' => "По умолчанию, у новых групп должны быть календари",
	'event_calendar:settings:group_default:no' => "нет (но админы или владельцы группы могут включить календарь группы если желают)",
	'event_calendar:settings:group_default:yes' => "да (но админы или владельцы группы могут включить календарь группы если желают)",
	'event_calendar:enable_event_calendar' => "Включить календарь групп",
	'event_calendar:no_events_found' => "События не найдены.",
			
	/**
	 * Event calendar river
	 **/
			 
	//generic terms to use
    'event_calendar:river:created' => "%s добавил",
    'event_calendar:river:updated' => "%s обновил",
    'event_calendar:river:annotated1' => "%s добавил",
	'event_calendar:river:annotated2' => "к его/ее личному календарю.",
	 
	//these get inserted into the river links to take the user to the entity
    'event_calendar:river:create' => "создал новое событие",
    'event_calendar:river:the_event' => "создал событие",
	);
					
	add_translation("ru",$russian);

?>
