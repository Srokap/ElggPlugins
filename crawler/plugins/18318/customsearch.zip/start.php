<?php
 
function customsearch_init() 
{
  //register_plugin_hook('search','','new_search');

  /* extend_view('metatags','customindex/metatags');

  eregister_plugin_hook('search'xtend_view('css','customindex/css'); */

  //register_page_handler('search','new_search');

  register_plugin_hook('search', 'all', 'new_search');

  //register_page_handler('search','new_search_pagehandler');

} 
	
function new_search() 
{
  if (!@include_once(dirname(__FILE__) . "/index.php")) 
  {
    return false;
  }

  return true;
}

function new_search_pagehandler($page)
{
  @include(dirname(__FILE__) . "/index.php");
  
  return true;
}

register_elgg_event_handler('init', 'system', 'customsearch_init');

?>