<?php
	echo $vars['url'] . "mod/web1/graphics/user_icons/defaultlarge.gif";
?>