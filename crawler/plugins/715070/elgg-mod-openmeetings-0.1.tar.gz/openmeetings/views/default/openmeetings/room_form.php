<?php

global $CONFIG;
require_once $CONFIG->pluginspath . '/openmeetings/openmeetings_gateway.php';
$openmeetings_gateway = new openmeetings_gateway();

global $plugin;
$plugin = find_plugin_settings('openmeetings');
$recordings = array('' => '---');
if ($openmeetings_gateway->openmeetings_loginuser()) {
	$recordingsArray = $openmeetings_gateway->openmeetings_getRecordingsByExternalRooms();
	foreach ($recordingsArray as $key => $value) {
		//there is a bug, if a List has the length of 1 the type is wrong
		if (is_array($value)) {
			$recordings[$value["flvRecordingId"]] = $value["fileName"];
		} else {
			$recordings[$recordingsArray["flvRecordingId"]] = $recordingsArray["fileName"];
			break;
		}
	}
}

$form_body = '';

// Get input data
$guid = (int) get_input('room_id');
if ($guid) {
	$form_body .= elgg_view('input/hidden',array('internalname' => 'room_id', 'value' => $guid));
	$room = get_entity($guid);
	$room_name = $room->title;
	$room_type = $room->room_type;
	$room_recording_id = $room->room_recording_id;
	$room_max_users = $room->room_max_users;
	$room_is_moderated = $room->room_is_moderated;
	$room_language = $room->room_language;
	$room_comment = $room->room_comment;
	$access_id = $room->access_id;
	$container_guid = $room->container_guid;
}

if (isset($_SESSION['openmeetings_room'])) {
	foreach (array('room_name', 'room_type', 'room_recording_id', 'room_max_users', 'room_is_moderated', 'room_language', 'room_comment', 'access_id', 'container_guid') as $f) {
		$$f = isset($_SESSION['openmeetings_room'][$f]) ? $_SESSION['openmeetings_room'][$f] : '';
	}
}

// default values for a new room
if (!$guid && !isset($_SESSION['openmeetings_room'])) {
	$room_type = 1;
}

$action = $vars['url'] . 'action/openmeetings/save_room';
	
$form_body .= "<p>" . elgg_echo('openmeetings:room:name') . "<br />";
$form_body .= elgg_view("input/text",array('internalname' => 'room_name', 'value' => $room_name)) . "</p>";

$form_body .= '<p>' . elgg_echo('openmeetings:room:type') .  '<br />' . elgg_view('input/pulldown', array(
									'internalname' => 'room_type',
									'options_values' => array( '1' => elgg_echo('openmeetings:room:type:conference'),
															   '2' => elgg_echo('openmeetings:room:type:audience'),
															   '3' => elgg_echo('openmeetings:room:type:restricted'),
						                                 	   '0' => elgg_echo('openmeetings:room:type:show_recording'),
									                         ),
									'value' => $room_type
								)) . '</p>';

$form_body .= '<p>' . elgg_echo('openmeetings:room:recording_id') .  '<br />' . elgg_view('input/pulldown', array(
									'internalname' => 'room_recording_id',
									'options_values' => $recordings,
									'value' => $room_recording_id
								)) . '</p>';

$form_body .= '<p>' . elgg_echo('openmeetings:room:max_users') .  '<br />' . elgg_view('input/pulldown', array(
									'internalname' => 'room_max_users',
									'options_values' => array(
										"2" => "2",
										"4" => "4",
										"8" => "8",
										"16" => "16",
										"24" => "24",
										"36" => "36",
										"50" => "50",
										"100" => "100",
										"200" => "200",
										"500" => "500",
										"1000" => "1000",
									),
									'value' => $room_max_users
								)) . '</p>';

$form_body .= '<p>' . elgg_echo('openmeetings:room:is_moderated') .  '<br />' . elgg_view('input/pulldown', array(
									'internalname' => 'room_is_moderated',
									'options_values' => array( '1' => elgg_echo('openmeetings:room:is_moderated_1'),
															   '2' => elgg_echo('openmeetings:room:is_moderated_2'),
									                         ),
									'value' => $room_type
								)) . '</p>';

$form_body .= '<p>' . elgg_echo('openmeetings:room:language') .  '<br />' . elgg_view('input/pulldown', array(
									'internalname' => 'room_language',
									'options_values' => array (
										"1" => "english",
										"2" => "deutsch",
										"3" => "deutsch (studIP)",
										"4" => "french",
										"5" => "italian",
										"6" => "portugues",
										"7" => "portugues brazil",
										"8" => "spanish",
										"9" => "russian",
										"10" => "swedish",
										"11" => "chinese simplified",
										"12" => "chinese traditional",
										"13" => "korean",
										"14" => "arabic",
										"15" => "japanese",
										"16" => "indonesian",
										"17" => "hungarian",
										"18" => "turkish",
										"19" => "ukrainian",
										"20" => "thai",
										"21" => "persian",
										"22" => "czech",
										"23" => "galician",
										"24" => "finnish",
										"25" => "polish",
										"26" => "greek",
										"27" => "dutch",
										"28" => "hebrew",
										"29" => "catalan",
										"30" => "bulgarian",
										"31" => "danish",
										"32" => "slovak",
									),
									'value' => $room_language
								)) . '</p>';


$form_body .= "<p>" . elgg_echo('openmeetings:room:comment') . "<br />";
$form_body .= elgg_view("input/longtext",array('internalname' => 'room_comment', 'value' => $room_comment)) . "</p>";

$objects = get_entities('group', '', 0, "", 999, 0);
$groups_menu = array('' => '---');
foreach ($objects as $g) {
	$groups_menu[$g->guid] = $g->name;
}
$form_body .= '<p>' . elgg_echo('openmeetings:room:group') .  '<br />' . elgg_view('input/pulldown', array(
									'internalname' => 'container_guid',
									'options_values' => $groups_menu,
									'value' => $container_guid
								)) . '</p>';

$form_body .= '<p>' . elgg_echo('access') . '<br />' . elgg_view('input/access', array('internalname' => 'access_id','value' => $access_id)) . '</p>';
$form_body .= elgg_view('input/submit', array('value' => elgg_echo("save")));

if (isset($_SESSION['openmeetings_room'])) {
	unset($_SESSION['openmeetings_room']);
}

?>
<div class="contentWrapper">	

<?php
	echo elgg_view('input/form', array('action' => $action, 'body' => $form_body));
?>
</div>

