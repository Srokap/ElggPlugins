<?php

global $CONFIG;

echo '<div id="openmeetings_widget_layout">';
echo '<a href="' .  $CONFIG->wwwroot . "pg/openmeetings/" . page_owner_entity()->username . '"><h2>' . elgg_echo('openmeetings:group_rooms') . '</h2></a>';

set_context('group_page_listing');

$rooms =  list_entities_groups('openmeetings_room', 0, $vars['entity']->guid);

if($rooms){
	echo $rooms;
	echo '<br /><div class="forum_latest" align="right"><a href="'.$CONFIG->wwwroot . "pg/openmeetings/".'">'.elgg_echo('openmeetings:all_rooms').'</a></div>';
} else{
	echo '<div class="forum_latest">' . elgg_echo('openmeetings:not_found') . '</div>';
}
echo '<div class="clearfloat"></div></div>';
