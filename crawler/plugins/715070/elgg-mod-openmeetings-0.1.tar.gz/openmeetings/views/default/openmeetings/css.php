<?php
?>

#openmeetings_widget_layout {
	-webkit-border-radius: 8px;
	-moz-border-radius: 8px;
	background:#FFFFFF none repeat scroll 0 0;
	margin:0 0 20px;
	border:1px solid #ccc;
	padding:0 0 5px;
}

.openmeetings_room_listing_options {
	float:right;
	width:65px;
}

.openmeetings_room_listing .delete_room {
	width:14px;
	height:14px;
	margin:3px 0 0 0;
	float:right;
}
.openmeetings_room_listing .delete_room a {
	display:block;
	cursor: pointer;
	width:14px;
	height:14px;
	background: url("<?php echo $vars['url']; ?>_graphics/icon_customise_remove.png") no-repeat 0 0;
	text-indent: -9000px;
}
.openmeetings_room_listing .delete_room a:hover {
	background-position: 0 -16px;
}
/* IE 6 fix */
* html .openmeetings_room_listing .delete_room a { background-position-y: 2px; }
* html .openmeetings_room_listing .delete_room a:hover { background-position-y: -14px; }
