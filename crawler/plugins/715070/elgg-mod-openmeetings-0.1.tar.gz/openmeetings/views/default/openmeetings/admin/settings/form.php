<?php

$plugin = find_plugin_settings('openmeetings');

$action = $vars['url'] . 'action/openmeetings/admin_settings';
	
$form_body .= "<p>" . elgg_echo('openmeetings:settings:red5host') . "<br />";
$form_body .= elgg_view("input/text",array('internalname' => 'params[red5host]', 'value' => $plugin->red5host)) . "</p>";

$form_body .= "<p>" . elgg_echo('openmeetings:settings:red5port') . "<br />";
$form_body .= elgg_view("input/text",array('internalname' => 'params[red5port]', 'value' => $plugin->red5port)) . "<small>" . elgg_echo('openmeetings:settings:default_red5port') . "</small></p>";

$form_body .= "<p>" . elgg_echo('openmeetings:settings:admin_user') . "<br />";
$form_body .= elgg_view("input/text",array('internalname' => 'params[admin_user]', 'value' => $plugin->admin_user)) . "</p>";

$form_body .= "<p>" . elgg_echo('openmeetings:settings:admin_password') . "<br />";
$form_body .= elgg_view("input/text",array('internalname' => 'params[admin_password]', 'value' => $plugin->admin_password)) . "</p>";

$form_body .= "<p>" . elgg_echo('openmeetings:settings:module_key') . "<br />";
$form_body .= elgg_view("input/text",array('internalname' => 'params[module_key]', 'value' => $plugin->module_key)) . "</p>";

$form_body .= elgg_view('input/submit', array('value' => elgg_echo("save")));

?>
<div class="contentWrapper">	
<?php
	echo elgg_view('input/form', array('action' => $action, 'body' => $form_body));
?>
</div>

