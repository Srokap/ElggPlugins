<?php

if (isset($vars['entity'])) {
	$object = $vars['entity'];
	$user_name = $object->getOwnerEntity()->name;
	$url = $object->getURL();
	$link = "<a href=\"" . $object->getURL() . "\">" . $object->title . "</a>";
?>

<?php if(get_context() == 'group_page_listing') { ?>
  <div style="padding-left: 10px;">
    <?php echo "$link <br />"; ?>
  </div>
<?php } else { ?>
<div class="search_listing openmeetings_room_listing">
	<div class="search_listing_icon">
		<?php
	        echo elgg_view("profile/icon",array('entity' => $vars['entity']->getOwnerEntity(), 'size' => 'small'));
		?>
    </div>
    <div class="search_listing_info">

	<div class="openmeetings_room_listing_options">
	    <div class="clearfloat"></div>
			<?php
				if ($vars['entity']->canEdit()) {
					   echo "<div class='delete_room'>" . elgg_view("output/confirmlink",array(
															'href' => $vars['url'] . "action/openmeetings/delete_room?room_id=" . $vars['entity']->getGUID(),
															'text' => elgg_echo('delete'),
															'confirm' => elgg_echo('deleteconfirm'),
														)) . "</div>";

				}
			?>
		</div>
        <?php
	        echo "$link <br />";
			$desc = $vars['entity']->description;
			echo $desc;
			if ($vars['entity']->canEdit()) {
	  			echo '&nbsp;<a href="' . $vars['url'] . "pg/openmeetings/edit_room?room_id=" . $vars['entity']->getGUID() . '" style="">Modifier</a>';
  			}
		?>
	</div>          
</div>
<?php
}
?>

<?php
}
?>
