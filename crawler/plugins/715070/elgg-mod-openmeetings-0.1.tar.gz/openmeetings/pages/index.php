<?php

$area2 = elgg_view_title(elgg_echo('openmeetings:rooms'));
$area2 .= list_entities('object','openmeetings_room');
$body = elgg_view_layout("two_column_left_sidebar", '', $area2);
page_draw(elgg_echo('openmeetings:rooms'),$body);

