<?php

if (!isloggedin()) forward();
$title = elgg_echo('openmeetings:rooms:edit');
$area2 = elgg_view_title($title);
$area2 .= elgg_view('openmeetings/room_form');
$body = elgg_view_layout("two_column_left_sidebar", '', $area2);
page_draw($title, $body);
