<?php

global $CONFIG;
global $plugin;
$plugin = find_plugin_settings('openmeetings');

$guid = (int) get_input('room_id');
$room = get_entity($guid);
if (!$room->getGUID()) {
	forward("pg/openmeetings");
}

$user = get_loggedin_user();

require_once $CONFIG->pluginspath . '/openmeetings/openmeetings_gateway.php';
$openmeetings_gateway = new openmeetings_gateway();

$becomemoderator = isadminloggedin();

if ($openmeetings_gateway->openmeetings_loginuser()) {

	if ($room->room_type != 0){
		$returnVal = $openmeetings_gateway->openmeetings_setUserObjectAndGenerateRoomHashByURL($user->username,$user->name,
						$user->name,$user->picture,$user->email,$user->getGUID(),$plugin->module_key,$room->room_id, intval($becomemoderator));
	} else {
		$returnVal = $openmeetings_gateway->openmeetings_setUserObjectAndGenerateRecordingHashByURL($user->username,$user->name,
						$user->name,$user->getGUID(),$plugin->module_key,$room->room_recording_id);

	}
}		

$scope_room_id = $room->room_id;
if ($scope_room_id == 0) {
	$scope_room_id = "hibernate";
}

$iframe_d = "http://".$plugin->red5host . ":" . $plugin->red5port .
	 	"/" . "openmeetings/?" .
		"secureHash=" . $returnVal . 
		"&scopeRoomId=" . $scope_room_id .
		//"&swf=maindebug.swf8.swf" .
		"&language=" . $room->room_language . 
		"&picture=" . $user->picture . 
		"&user_id=". $user->getGUID() . 
		"&elggRoom=1" .   
		"&wwwroot=". $CONFIG->wwwroot;                                                                                                

//print $iframe_d;exit;
$area1 = sprintf("<iframe src='%s' width='%s' height='%s' />",$iframe_d,"100%",640);		

$body = elgg_view_layout("one_column", $area1);
page_draw(elgg_echo('openmeetings:rooms'),$body);

