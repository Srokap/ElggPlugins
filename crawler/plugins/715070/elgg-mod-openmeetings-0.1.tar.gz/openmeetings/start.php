<?php

/**
 * Openmeetings integration
 * 
 * @author Krasi <krasi.zlatev@activesolutions.bg>
 */

/**
 * Init module
 *
 */
function openmeetings_init() {

	// handlers
	register_page_handler('openmeetings', 'openmeetings_page_handler');

    // Register a URL handler for rooms
	register_entity_url_handler('openmeetings_room_url','object','openmeetings_room');

	// Extend system CSS with our own styles
	extend_view('css','openmeetings/css');

	// Room page
	extend_view('groups/left_column', 'openmeetings/group_rooms', 1000);
}

/**
 * Menu
 *
 */
function openmeetings_pagesetup(){
	global $CONFIG;
	if (get_context() == 'admin' && isadminloggedin()) {
		add_menu(elgg_echo('openmeetings'), $CONFIG->wwwroot . "pg/openmeetings/");
		add_submenu_item(elgg_echo('openmeetings'), $CONFIG->wwwroot . 'pg/openmeetings/admin_settings/');
	} else if (isloggedin()) {
		add_menu(elgg_echo('openmeetings'), $CONFIG->wwwroot . "pg/openmeetings/");
		if (get_context() == "openmeetings") {
			add_submenu_item(elgg_echo('openmeetings:rooms'),$CONFIG->wwwroot."pg/openmeetings/");
			if (isadminloggedin()) {
				add_submenu_item(elgg_echo('openmeetings:rooms:create'),$CONFIG->wwwroot."pg/openmeetings/create_room");
			}

		}
	}		
}

/**
 * Creating friendly URLs using the page handler
 * 
 */
function openmeetings_page_handler($page) {

	switch ($page[0]) {
		case 'admin_settings';
	        include 'pages/admin_settings.php';
			break;
		case 'create_room';
	        include 'pages/create_room.php';
			break;
		case 'edit_room';
	        include 'pages/edit_room.php';
			break;
		default:
			if (is_numeric($page[0])) {
				set_input('room_id', $page[0]);
		        include 'pages/view.php';
			} else {
		        include 'pages/index.php';
			}
			break;
	}
}

/**
 * Populates the ->getUrl() method for openmeetings_room objects
 */
function openmeetings_room_url($room) {
	global $CONFIG;
	$title = $room->title;
	$title = friendly_title($title);
	return $CONFIG->url . "pg/openmeetings/" . $room->getGUID() . "/" . urlencode($title);
}

// register actions
register_action("openmeetings/admin_settings", false, $CONFIG->pluginspath . "openmeetings/actions/admin_settings.php");
register_action("openmeetings/save_room", false, $CONFIG->pluginspath . "openmeetings/actions/save_room.php");
register_action("openmeetings/delete_room", false, $CONFIG->pluginspath . "openmeetings/actions/delete_room.php");

// init
register_elgg_event_handler('init','system','openmeetings_init');
register_elgg_event_handler('pagesetup','system','openmeetings_pagesetup');
