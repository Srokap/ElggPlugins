<?php

function crossial_init(){

}

register_elgg_event_handler('init','system','crossial_init');

?>
