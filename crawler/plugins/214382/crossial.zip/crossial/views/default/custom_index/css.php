<?php 

/**
* Custom Index page css extender
*
* @package custom_index
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author Curverider <info@elgg.com>
* @copyright Curverider Ltd 2008-2009
* @link http://elgg.org/
*/

?>

#custom_index {
	margin: 0;
}

#index_left {
	width: 465px;
	float: left;
}

#index_right {
	width: 505px;
	float: right;
}

#index_welcome {
	background: white;
    margin-bottom: 20px;
}

#index_welcome #login-box {
	padding: 0 0 10px 0;
	background: #f7f7f7;
	width: 463px;
	border:1px solid #b7b7b7;
}

#index_welcome #login-box form {
	margin: 0 10px 0 10px;
	padding: 10px 9px 4px 9px;
	background: white;
	width: 424px;
	border: 1px solid #cccccc;
}

#index_welcome #login-box h2,
.index_box h2 {
	color: #0054A7;
	font-size: 1.35em;
    line-height:1.2em;
	margin: 0 0 0 8px;
	padding: 5px 5px 5px 0;
}

#index_welcome #login-box h2 {
	padding-bottom: 5px;
}

.index_box {
	background: #f7f7f7;
	padding: 0 0 5px 0;
	border: 1px solid #b7b7b7;
    margin-bottom: 20px;
}

.index_box .search_listing {

}

.index_box .index_members {
	float: left;
	margin: 2pt 5px 3px 0pt;
}

#persistent_login {
	color: #1d2a5b;
	font-size: 11px;
}

#persistent_login td {
	text-align: right;
}
