<?php

/**
* Elgg embed CSS
*
* @package embed
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author Curverider <info@elgg.com>
* @copyright Curverider Ltd 2008-2009
* @link http://elgg.org/
*/

?>

#facebox {
	position: absolute;
	top: 0;
	left: 0;
	z-index: 100;
	text-align: left;
}

#facebox .popup {
	position: relative;
}

#facebox .body {
	padding: 10px;
	background: #F7F7F7;
	width: 730px;
	border: 1px solid #B7B7B7;
}

#facebox .loading {
	text-align: center;
	padding: 100px 10px 100px 10px;
}

#facebox .image {
	text-align: center;
}

#facebox .footer {
	float: right;
	width: 22px;
	height: 22px;
	margin: 0;
	padding: 0;
}

#facebox .footer img.close_image {
	background: url(<?php echo $vars['url']; ?>mod/embed/images/close_button.gif) no-repeat left top;
}

#facebox .footer img.close_image:hover {
	background: url(<?php echo $vars['url']; ?>mod/embed/images/close_button.gif) no-repeat left -31px;
}

#facebox .footer a {
	-moz-outline: none;
	outline: none;
}

#facebox_overlay {
	position: fixed;
	top: 0;
	left: 0;
	height: 100%;
	width: 100%;
}

.facebox_hide {
	z-index: -100;
}

.facebox_overlayBG {
	background-color: #000000;
	z-index: 99;
}

/* ie6 hack */

* html #facebox_overlay {
	position: absolute;
	height: expression(document.body.scrollHeight > document.body.offsetHeight ? document.body.scrollHeight : document.body.offsetHeight + 'px');
}

/* EMBED MEDIA TABS */

#embed_media_tabs {
	margin: 10px 0 0 10px;
	padding: 0;
}

#embed_media_tabs ul {
	list-style: none;
	padding-left: 0;
}

#embed_media_tabs ul li {
	float: left;
	margin: 0;
}

#embed_media_tabs ul li a {
	font-weight: bold;
	font-size: 1.35em;
	text-align: center;
	text-decoration: none;
	color: #999999;
	background: #EEEEEE;
	display: block;
	padding: 0 10px 0 10px;
	margin: 0 10px 0 10px;
	height: 25px;
	width: auto;
	border-top: 1px solid #CCCCCC;
	border-left: 1px solid #CCCCCC;
	border-right: 1px solid #CCCCCC;
}

/* IE6 fix */

* html #embed_media_tabs ul li a {
	display: inline;
}

#embed_media_tabs ul li a:hover {
	background: #5C74A3;
	color: white;
}

#embed_media_tabs ul li a.embed_tab_selected {
	border-top: 1px solid #CCCCCC;
	border-left: 1px solid #CCCCCC;
	border-right: 1px solid #CCCCCC;
	background: white;
	color: #1D2A5B;
	position: relative;

	/* only needed if selected tab needs to sit over a border */

	top: 1px;
}

#mediaUpload, 
#mediaEmbed {
	margin: 0 5px 10px 5px;
	padding: 10px;
	border: 1px solid #CCCCCC;
	background: white;
}

#mediaEmbed .search_listing {
	margin: 0 0 5px 0;
}

h1.mediaModalTitle {
	color: #0054A7;
	font-size: 1.35em;
	line-height: 1.2em;
	margin: 0 0 0 8px;
	padding: 5px;
}

#mediaEmbed .pagination, 
#mediaUpload .pagination {
	float: right;
	margin: 0;
}

#mediaUpload label {
	font-size: 120%;
}

#mediaEmbed p.embedInstructions {
	margin: 10px 0 5px 0;
}

a.embed_media {
	margin: 0;
	float: right;
	display: block;
	text-align: right;
	font-size: 1.0em;
	font-weight: normal;
}

label a.embed_media {
	font-size: 0.8em;
}

.content p {
	background: white;
	border: 1px solid #CCCCCC;
}

#mediaUpload p {
	background: white;
	border: 1px solid #FFFFFF;
}
