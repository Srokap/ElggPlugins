<?php

	/*** styler Theme language file*/
	
	$english = array(
            'hypeaddcontent' => 'Post Site Content',
            'hypeaddcontent:widget:description' => 'Post new content without leaving your dashboard/profile',

	);

add_translation("en",$english);
?>