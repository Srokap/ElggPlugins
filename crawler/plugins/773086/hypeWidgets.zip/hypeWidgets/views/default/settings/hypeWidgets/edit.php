<h2>Post Content Widget</h2>

<?php
echo "Please list object subtypes you would like to add to the Post Content Widget. Current supported subtypes are: " . $supported_subtypes . ". To add more subtypes, add an approprite form to hypeWidgets/forms/subtypes/";
echo elgg_view('input/tags', array('value' => $vars['entity']->allowed_object_types,
    'internalname' => 'params[allowed_object_types]'));
echo '<br>';