<?php

$subtypes = get_plugin_setting('allowed_object_types', 'hypeWidgets');
$subtypes = string_to_tag_array($subtypes);

if (!empty($subtypes)) {
    foreach ($subtypes as $subtype) {
        echo '.hypeWidget_subtype_' . $subtype . " {
            width:18px;
            height:18px;
            display:block;
            background:transparent url({$vars['url']}mod/hypeWidgets/graphics/{$subtype}.png) no-repeat;
        }
        ";
    }
}

?>
