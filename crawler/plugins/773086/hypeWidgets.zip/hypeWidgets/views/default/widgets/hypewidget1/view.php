<?php 
if ($vars['entity']->access_id !== 0) {
    save_widget_info($vars['entity']->guid, array('access_id' => 0));
}
if ($vars['entity']->owner_guid == get_loggedin_userid()) { ?>

<div id="hypeWidget_button_container">
    <?php
    $subtypes = get_plugin_setting('allowed_object_types', 'hypeWidgets');
    $subtypes = string_to_tag_array($subtypes);

    if (!empty($subtypes)) {
        foreach ($subtypes as $subtype) {
            echo '<div class="hypeWidget_selector left padded">';
            echo '<a href="javascript:void(0)" title="' . $subtype . '" subtype="' . $subtype . '" class="hypeWidget_subtype_' . $subtype . '"></a>';
            echo '</div>';
        }
        echo elgg_view('hypewidget1/extend', $vars);
        echo '<div class="clearfloat"></div>';
    }
    ?>
</div>
<div id="hypeWidget_form_container"></div>

<script type="text/javascript">
    $(document).ready(function(){
        var ajax_loader = '<div class="ajax_loader"></div>';
        var buttons_container =  $('#hypeWidget_button_container');
        var result_container = $('#hypeWidget_form_container');
        $('.hypeWidget_selector', buttons_container).each(function(){
            $(this).click(function(){
               result_container.html(ajax_loader);
               var user_guid = '<?php echo $vars['entity']->owner_guid ?>';
               var subtype = $(this).find('a').attr('subtype');
               $.ajax ({
                    url: '<?php echo elgg_add_action_tokens_to_url($vars['url'] . 'action/hypewidget/getform') ?>',
                    type: 'POST',
                    dataType: 'html',
                    data: {
                        user_guid: user_guid,
                        subtype: subtype
                    },
                    success: function(data) {
                        result_container.html(data);
                    }
                });
            });
        });
    });
</script>
<?php } ?>