<?php
$user_guid = get_input('user_guid');
$user = get_entity($user_guid);

$subtype = get_input('subtype');

$form = elgg_view('hypeFramework/ajax/metatags');
$form .= elgg_view('hypeWidgets/forms/subtypes/' . $subtype);

echo $form;
die();
?>
