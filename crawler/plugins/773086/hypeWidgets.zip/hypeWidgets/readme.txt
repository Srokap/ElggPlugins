hypeWidgets is part of the hypeJunction bundle

hypeWidgets is a collection of widgets for your Elgg site

Widgets include:
1. Post content
    - Blogs
    - Bookmarks
    - Files
    - Pages

Installation:
1. Download and install hypeFramework
2. Upload hypeWidgets into your mod folder, enable it
3. Change settings to specify which content types you want to keep / add

