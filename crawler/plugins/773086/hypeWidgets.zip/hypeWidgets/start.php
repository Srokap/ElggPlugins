<?php

/* hypeWidgets
 *
 * Widgets for Elgg
 *
 * @package hype
 * @subpackage Widgets
 *
 * @author Ismayil Khayredinov <ismayil.khayredinov@gmail.com>
 * @copyright Copyrigh (c) 2011, Ismayil Khayredinov
 */

function hypeWidgets_init() {
    global $CONFIG;

    if (!is_plugin_enabled('hypeFramework')) {
        register_error('hypeFramework is not enabled. hypeWidgets will not work properly. Visit www.hypeJunction.com for details');
    }
    register_action('hypewidget/getform', false, $CONFIG->pluginspath . 'hypeWidgets/actions/getform.php', false);

    elgg_extend_view('css', 'hypeWidgets/css/css');
    add_widget_type('hypewidget1', elgg_echo('hypeaddcontent'), elgg_echo('hypeaddcontent:widget:description'));

    $supported_subtypes = "blog, bookmarks, file, page_top";
    if (!get_plugin_setting('allowed_object_types', 'hypeWidgets')) {
        set_plugin_setting('allowed_object_types', $supported_subtypes, 'hypeWidgets');
    }
}

register_elgg_event_handler('init', 'system', 'hypeWidgets_init');
?>
