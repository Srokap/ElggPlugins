<?php

	$turkish = array(

		/**
		 * Sites
		 */
	
			'item:site' => 'Sites',
	
		/**
		 * Sessions
		 */
			
			'login' => "Giriş",
			'loginok' => "Giriş başarılı.",
			'loginerror' => "Giriş yapılamadı. Bunun nedeni, hesabınızı doğrulamamış olmanız, verdiğiniz bilgilerin hatalı olması veya çok fazla yanlış giriş yapmanız olabilir. Lütfen bilgilerinizi kontrol edip, tekrar deneyiniz.",
	
			'logout' => "Çıkış",
			'logoutok' => "Çıkış başarılı.",
			'logouterror' => "Çıkış başarısız. Lütfen tekrar deneyiniz",
	
		/**
		 * Errors
		 */
			'exception:title' => "Elgg'e Hoşgeldiniz.",
	
			'InstallationException:CantCreateSite' => "Verdiğiniz İsim:%s, Url: %s bilgileriyle, varsayılan bir Elgg sitesi yaratılamıyor.",
		
			'actionundefined' => "İstenilen (%s) talebi sistemde belirlenmemiş.",
			'actionloggedout' => "Üzgünüz, çıkış yapmışken bunu yapamazsınız..",
	
			'notfound' => "İstenilen kaynak bulunamadı veya erişim yetkiniz yok.",
			
			'SecurityException:Codeblock' => "Denied access to execute privileged code block",
			'DatabaseException:WrongCredentials' => "Elgg verilen bilgiler ile veritabanına bağlanamıyor.",
			'DatabaseException:NoConnect' => "Elgg '%s' veritabanını seçemiyor, lütfen veritabanının yaratıldığını ve sizin erişim yetkiniz olduğunu doğrulayınız.",
			'SecurityException:FunctionDenied' => "Access to privileged function '%s' is denied.",
			'DatabaseException:DBSetupIssues' => "Birkaç hata var: ",
			'DatabaseException:ScriptNotFound' => "Elgg istenilen veritabanı scriptini bulamadı. Burada: %s.",
			
			'IOException:FailedToLoadGUID' => "Failed to load new %s from GUID:%d",
			'InvalidParameterException:NonElggObject' => "Passing a non-ElggObject to an ElggObject constructor!",
			'InvalidParameterException:UnrecognisedValue' => "Unrecognised value passed to constuctor.",
			
			'InvalidClassException:NotValidElggStar' => "GUID:%d is not a valid %s",
			
			'PluginException:MisconfiguredPlugin' => "%s eklentisi eksik ayarlanmış.",
			
			'InvalidParameterException:NonElggUser' => "Passing a non-ElggUser to an ElggUser constructor!",
			
			'InvalidParameterException:NonElggSite' => "Passing a non-ElggSite to an ElggSite constructor!",
			
			'InvalidParameterException:NonElggGroup' => "Passing a non-ElggGroup to an ElggGroup constructor!",
	
			'IOException:UnableToSaveNew' => "Yeni %s kaydedilemedi.",
			
			'InvalidParameterException:GUIDNotForExport' => "GUID has not been specified during export, this should never happen.",
			'InvalidParameterException:NonArrayReturnValue' => "Entity serialisation function passed a non-array returnvalue parameter",
			
			'ConfigurationException:NoCachePath' => "Ön bellek yolu silindi!",
			'IOException:NotDirectory' => "%s bir klasör değil.",
			
			'IOException:BaseEntitySaveFailed' => "Unable to save new object's base entity information!",
			'InvalidParameterException:UnexpectedODDClass' => "import() passed an unexpected ODD class",
			'InvalidParameterException:EntityTypeNotSet' => "İçeriğin tipi belirlenmeli.",
			
			'ClassException:ClassnameNotClass' => "%s bir %s değil.",
			'ClassNotFoundException:MissingClass' => "'%s' sınıfı bulunamadı, eksik eklenti olabilir mi?",
			'InstallationException:TypeNotSupported' => "%s tipi desteklenmiyoru. Bu kurulumda oluşmuş olan bir hataya işarettir, çoğunlıkla tam yapılmamış bir güncellemeden kaynaklanır.",

			'ImportException:ImportFailed' => "%d elemanı içe aktarılamadı.",
			'ImportException:ProblemSaving' => "%s kaydederken bir problem çıktı.",
			'ImportException:NoGUID' => "New entity created but has no GUID, this should not happen.",
			
			'ImportException:GUIDNotFound' => "Entity '%d' could not be found.",
			'ImportException:ProblemUpdatingMeta' => "There was a problem updating '%s' on entity '%d'",
			
			'ExportException:NoSuchEntity' => "No such entity GUID:%d", 
			
			'ImportException:NoODDElements' => "No OpenDD elements found in import data, import failed.",
			'ImportException:NotAllImported' => "Bütün elementler içe aktarılamadı.",
			
			'InvalidParameterException:UnrecognisedFileMode' => "Tanımlanamayan dosya modu '%s'",
			'InvalidParameterException:MissingOwner' => "%s (%d) dosyasının sahibi yok!",
			'IOException:CouldNotMake' => "%s yapılamadı!",
			'IOException:MissingFileName' => "Bir dosya açmadan önce isim belirlemelisiniz.",
			'ClassNotFoundException:NotFoundNotSavedWithFile' => "Filestore not found or class not saved with file!",
			'NotificationException:NoNotificationMethod' => "Bildirim metodu belirtilmedi.",
			'NotificationException:NoHandlerFound' => "No handler found for '%s' or it was not callable.",
			'NotificationException:ErrorNotifyingGuid' => "There was an error while notifying %d",
			'NotificationException:NoEmailAddress' => "Could not get the email address for GUID:%d",
			'NotificationException:MissingParameter' => "Gerekli bir parametre eksik, '%s'",
			
			'DatabaseException:WhereSetNonQuery' => "Where set contains non WhereQueryComponent",
			'DatabaseException:SelectFieldsMissing' => "Fields missing on a select style query",
			'DatabaseException:UnspecifiedQueryType' => "Unrecognised or unspecified query type.",
			'DatabaseException:NoTablesSpecified' => "Sorguda tablo belirtilmemiş.",
			'DatabaseException:NoACL' => "No access control was provided on query",
			
			'InvalidParameterException:NoEntityFound' => "No entity found, it either doesn't exist or you don't have access to it.",
			
			'InvalidParameterException:GUIDNotFound' => "GUID:%s could not be found, or you can not access it.",
			'InvalidParameterException:IdNotExistForGUID' => "Sorry, '%s' does not exist for guid:%d",
			'InvalidParameterException:CanNotExportType' => "Üzgünüm, Bunu nasıl dışa aktaracağımı bilmiyorum '%s'",
			'InvalidParameterException:NoDataFound' => "Herhangi bir veri bulunamadı.",
			'InvalidParameterException:DoesNotBelong' => "Does not belong to entity.",
			'InvalidParameterException:DoesNotBelongOrRefer' => "Does not belong to entity or refer to entity.",
			'InvalidParameterException:MissingParameter' => "Missing parameter, you need to provide a GUID.",
			
			'SecurityException:APIAccessDenied' => "Üzgünüz, API erişimi yönetici tarafından engellendi.",
			'SecurityException:NoAuthMethods' => "No authentication methods were found that could authenticate this API request.",
			'APIException:ApiResultUnknown' => "API Result is of an unknown type, this should never happen.", 
			
			'ConfigurationException:NoSiteID' => "No site ID has been specified.",
			'InvalidParameterException:UnrecognisedMethod' => "Unrecognised call method '%s'",
			'APIException:MissingParameterInMethod' => "Missing parameter %s in method %s",
			'APIException:ParameterNotArray' => "%s does not appear to be an array.",
			'APIException:UnrecognisedTypeCast' => "Unrecognised type in cast %s for variable '%s' in method '%s'",
			'APIException:InvalidParameter' => "Invalid parameter found for '%s' in method '%s'.",
			'APIException:FunctionParseError' => "%s(%s) has a parsing error.",
			'APIException:FunctionNoReturn' => "%s(%s) returned no value.",
			'SecurityException:AuthTokenExpired' => "Authentication token either missing, invalid or expired.",
			'CallException:InvalidCallMethod' => "%s must be called using '%s'",
			'APIException:MethodCallNotImplemented' => "Method call '%s' has not been implemented.",
			'APIException:AlgorithmNotSupported' => "Algorithm '%s' is not supported or has been disabled.",
			'ConfigurationException:CacheDirNotSet' => "Cache directory 'cache_path' not set.",
			'APIException:NotGetOrPost' => "Request method must be GET or POST",
			'APIException:MissingAPIKey' => "Missing X-Elgg-apikey HTTP header",
			'APIException:MissingHmac' => "Missing X-Elgg-hmac header",
			'APIException:MissingHmacAlgo' => "Missing X-Elgg-hmac-algo header",
			'APIException:MissingTime' => "Missing X-Elgg-time header",
			'APIException:TemporalDrift' => "X-Elgg-time is too far in the past or future. Epoch fail.",
			'APIException:NoQueryString' => "No data on the query string",
			'APIException:MissingPOSTHash' => "Missing X-Elgg-posthash header",
			'APIException:MissingPOSTAlgo' => "Missing X-Elgg-posthash_algo header",
			'APIException:MissingContentType' => "Missing content type for post data",
			'SecurityException:InvalidPostHash' => "POST data hash is invalid - Expected %s but got %s.",
			'SecurityException:DupePacket' => "Packet signature already seen.",
			'SecurityException:InvalidAPIKey' => "Invalid or missing API Key.",
			'NotImplementedException:CallMethodNotImplemented' => "Call method '%s' is currently not supported.",
	
			'NotImplementedException:XMLRPCMethodNotImplemented' => "XML-RPC method call '%s' not implemented.",
			'InvalidParameterException:UnexpectedReturnFormat' => "Call to method '%s' returned an unexpected result.",
			'CallException:NotRPCCall' => "Call does not appear to be a valid XML-RPC call",
	
			'PluginException:NoPluginName' => "The plugin name could not be found",
	
			'ConfigurationException:BadDatabaseVersion' => "Kurduğunuz veritabanı arkayüzü Elgg sistemini çalıştırmak için gereken minimum gereklilikleri karşılayamıyor. Lütfen dökümanlara başvurun.",
			'ConfigurationException:BadPHPVersion' => "Elgg sistemini çalıştırmak için en az PHP 5.2 sürümü gereklidir.",
			'configurationwarning:phpversion' => "Elgg PHP 5.2 sürümüne ihtiyaç duyar. PHP 5.1.6 sürümüne de kurabilirsiniz ama bazı özellikler çalışmayacaktır. Mesüliyet kabul edilmez.",
	
	
			'InstallationException:DatarootNotWritable' => "%s veri klasörünüz yazılabilir değil.",
			'InstallationException:DatarootUnderPath' => "%s veri klasörü kurulum yolunun dışında olmalıdır.",
			'InstallationException:DatarootBlank' => "Bir veri klasötü belirtmemişsiniz.",
	
			'SecurityException:authenticationfailed' => "Kullanıcı doğrulanamıyor.",
	
			'CronException:unknownperiod' => '%s is not a recognised period.',
	
			'SecurityException:deletedisablecurrentsite' => 'Şu an görüntülenen siteyi silemez veya devre dışı bırakamazsınız!',
	
			'memcache:notinstalled' => 'PHP memcache modülü kurulmamış, php5-memcache kurmanız gereklidir.',
			'memcache:noservers' => 'Herhangi bir memcache sunucusu belirtilmemiş, Lütfen, $CONFIG->memcache_servers değişkenini ayarlayınız.',
			'memcache:versiontoolow' => 'Memcache needs at least version %s to run, you are running %s',
			'memcache:noaddserver' => 'Çoğul sunucu desteği devre dışı bırakılmış, PECL memcache kütüphanenizi güncellemeniz gerekebilir.',
	
			'deprecatedfunction' => 'Warning: This code uses the deprecated function \'%s\' and is not compatible with this version of Elgg',
	
			'pageownerunavailable' => 'Warning: The page owner %d is not accessible!',
		/**
		 * API
		 */
			'system.api.list' => "Sistemde yer alan bütün etkin API'leri listele.",
			'auth.gettoken' => "This API call lets a user log in, returning an authentication token which can be used in leu of a username and password for authenticating further calls.",
	
		/**
		 * User details
		 */

			'name' => "Profil ismi",
			'email' => "E-Posta",
			'username' => "Kullanıcı adı",
			'password' => "Şifre",
			'passwordagain' => "Şifre (tekrar)",
			'admin_option' => "Bu kullanıcıyı yönetici yap?",
	
		/**
		 * Access
		 */
	
			'PRIVATE' => "Özel",
			'LOGGED_IN' => "Kayıtlı kullanıcılar",
			'PUBLIC' => "Herkese açık",
			'access:friends:label' => "Arkadaşlar",
			'access' => "Erişim",
	
		/**
		 * Dashboard and widgets
		 */
	
			'dashboard' => "Panel",
            'dashboard:configure' => "Sayfayı düzenle",
			'dashboard:nowidgets' => "Paneliniz bu siteye açılan bir kapıdır. 'Sayfayı düzenle' bağlantısına tıklayarak widgetlar ekleyebilir ve bunlar sayesinde içerikleri ve site içerisindeki aktivitelerinizi kolaylıkla takip edebilirsiniz.",

			'widgets:add' => 'Sayfanıza widget ekleyin',
			'widgets:add:description' => "İstediğiniz özellikleri eklemek için, sağdaki <b>Widget galerisi</b>nden seçip, istediğiniz üç widget alanından birine, nerede gözükmesini istediğiniz şekilde sürükleyerek bırakabilirsiniz.

Bir widgetı kaldırmak için onu tekrar <b>Widget galeri</b>sine sürüklemeniz yeterlidir.",
			'widgets:position:fixed' => '(Fixed position on page)',
	
			'widgets' => "Widgetlar",
			'widget' => "Widget",
			'item:object:widget' => "Widgetlar",
			'layout:customise' => "Düzeni kişiselleştir",
			'widgets:gallery' => "Widget galerisi",
			'widgets:leftcolumn' => "Sol widgetlar",
			'widgets:fixed' => "Fixed position",
			'widgets:middlecolumn' => "Orta widgetlar",
			'widgets:rightcolumn' => "Sağ widgetlar",
			'widgets:profilebox' => "Profil kutusu",
			'widgets:panel:save:success' => "Widgetlarınız başarıyla kaydedildi.",
			'widgets:panel:save:failure' => "Widgetlarınızı kaydederken bir problem oluştu. Lütfen tekrar deneyiniz.",
			'widgets:save:success' => "Widget başarıyla kaydedildi.",
			'widgets:save:failure' => "Widgetınızı kaydederken bir problem oluştu. Lütfen tekrar deneyiniz",
			'widgets:handlernotfound' => 'Bu widget hatalı veya site yöneticileri tarafından engellenmiş.',
	
		/**
		 * Groups
		 */
	
			'group' => "Grup", 
			'item:group' => "Gruplar",
	
		/**
		 * Profile
		 */
	
			'profile' => "Profil",
			'profile:edit:default' => 'Profil alanlarını değiştir',
			'profile:preview' => 'Önizleme',
			'user' => "Kullanıcı",
			'item:user' => "Kullanıcılar",
			'riveritem:single:user' => 'kullanıcı',
			'riveritem:plural:user' => 'bazı kullanıcılar',
	
	

		/**
		 * Profile menu items and titles
		 */
	
			'profile:yours' => "Profiliniz",
			'profile:user' => "%s'ın profili",
	
			'profile:edit' => "Profili düzenle",
			'profile:profilepictureinstructions' => "Profil resmi profil sayfanızda gözüken resimdir.. <br /> İstediğiniz sıklıkla değiştirebilirsiniz (Sadece GIF, JPG veya PNG biçimleri geçerlidir.)",
			'profile:icon' => "Profil resmi",
			'profile:createicon' => "Avatar yarat",
			'profile:currentavatar' => "Şuanki avatar",
			'profile:createicon:header' => "Profil resmi",
			'profile:profilepicturecroppingtool' => "Profil resmi kırpma aracı",
			'profile:createicon:instructions' => "Tıklayıp sürükleyerek resminizin kırpılmasını istediğiniz alanı seçebilirsiniz.  Kırpılmış resminizin bir önizlemesi sağdaki kutuda gözükecektir. Önizlemeden memnun kaldığınızda, 'Avatar yarat' bağlantısına tıklayarak avatarınızı yaratabilirsiniz.",
	
			'profile:editdetails' => "Detayları düzenle",
			'profile:editicon' => "Profil simgesini düzenle",
	
			'profile:aboutme' => "Hakkımda", 
			'profile:description' => "Hakkımda",
			'profile:briefdescription' => "Kısa açıklama",
			'profile:location' => "Yer",
			'profile:skills' => "Yetenekler",  
			'profile:interests' => "İlgi Alanları", 
			'profile:contactemail' => "İletişim E-Postası",
			'profile:phone' => "Telefon",
			'profile:mobile' => "Cep telefonu",
			'profile:website' => "Websitesi",
	
			'profile:banned' => 'Bu kullanıcı hesabı askıya alınmıştır..',
			'profile:deleteduser' => 'Silinmiş kullanıcı',

			'profile:river:update' => "%s profilini güncelledi.",
			'profile:river:iconupdate' => "%s profil simgesini güncelledi.",
	
			'profile:label' => "Profil etiketi",
			'profile:type' => "Profil tipi",
	
			'profile:editdefault:fail' => 'Varsayılan profil kaydedilemedi.',
			'profile:editdefault:success' => 'Başarıyla profilinize eklendi',
	
			
			'profile:editdefault:delete:fail' => 'Removed default profile item field failed',
			'profile:editdefault:delete:success' => 'Varsayılan profil elemanı silindi!',
	
			'profile:defaultprofile:reset' => 'Varsayılan profil ayarlarına geri dönüldü.',
	
			'profile:resetdefault' => 'Varsayılan profil ayarlarına geri dön',
			'profile:explainchangefields' => 'Varolan profil alanlarını, aşağıdaki formu kullanarak, istediklerinizle değiştirebilirsiniz. İlk olarak, yeni profil alanınıza istediğiniz gibi bir etiket ismi verin, örnek olarak; \'En sevdiği sanatçı\'. Daha sonra alanın tipini seçmeniz gerekir, örnek olarak; etiketler, url, yazı gibi. İstediğiniz zaman yaptığınız değişikleri geri alarak varsayılan profil ayarlarına geri dönebilirsiniz.',
	

	
		/**
		 * Profile status messages
		 */
	
			'profile:saved' => "Profiliniz başarıyla kaydedildi.",
			'profile:icon:uploaded' => "Profiliniz başarıyla güncellendi.",
	
		/**
		 * Profile error messages
		 */
	
			'profile:noaccess' => "Bu profili düzenlemek için yetkiniz yok.",
			'profile:notfound' => "Üzgünüz; belirtilen profil bulunamadı.",
			'profile:cantedit' => "Üzgünüz; bu profili düzenlemek için izniniz yok.",
			'profile:icon:notfound' => "Üzgünüz; Profil resminizi güncellerken bir hata oluştu.",
	
		/**
		 * Friends
		 */
	
			'friends' => "Arkadaşlar",
			'friends:yours' => "Arkadaşlarınız",
			'friends:owned' => "%s'ın arkadaşları",
			'friend:add' => "Arkadaş ekle",
			'friend:remove' => "Arkadaş sil",
	
			'friends:add:successful' => "%s isimli kişiyi arkadaşınız olarak eklediniz.",
			'friends:add:failure' => "%s isimli kişiyi arkadaş olarak ekleyemedik. Lütfen tekrar deneyiniz.",
	
			'friends:remove:successful' => "%s adlı kişiyi arkadaş listenizden çıkardınız.",
			'friends:remove:failure' => "%s adlı kişiyi arkadaş listenizden çıkartamadık. Lütfen tekrar deneyiniz.",
	
			'friends:none' => "Bu kullanıcının şimdilik bir arkadaşı yok",
			'friends:none:you' => "Hiç arkadaşınız yok! İlgili olduğunuz konularda arama yaparak, takip edebileceğiniz insanlar bulmaya başlayabilirsiniz.",
	
			'friends:none:found' => "Hiç arkadaş bulunamadı.",
	
			'friends:of:none' => "Hiç kimse bu kişiyi arkadaş olarak eklemedi.",
			'friends:of:none:you' => "Hiç kimse sizi arkadaş olarak eklemedi. İnsanların size ulaşması için düşüncelerinizi yazın ve profil bilgilerinizi doldurun!",
	
			'friends:of:owned' => "%s adlı kişiyi arkadaş olarak ekleyenler",

			 'friends:num_display' => "Gösterilecek arkadaş sayısı",
			 'friends:icon_size' => "Simge boyutu",
			 'friends:tiny' => "ufak",
			 'friends:small' => "küçük",
			 'friends:of' => "Arkadaşları",
			 'friends:collections' => "Arkadaş koleksiyonu",
			 'friends:collections:add' => "Yeni arkadaşlar koleksiyonu",
			 'friends:addfriends' => "Arkadaş ekle",
			 'friends:collectionname' => "Koleksiyon ismi",
			 'friends:collectionfriends' => "Koleksiyondaki arkadaşlar",
			 'friends:collectionedit' => "Bu koleksiyonu düzenle",
			 'friends:nocollections' => "Bir koleksiyonunuz yok.",
			 'friends:collectiondeleted' => "Koleksiyonunuz silindi.",
			 'friends:collectiondeletefailed' => "Koleksiyonunuzu silemezsiniz. Buna yetkiniz yok veya başka bir problem oluştu.",
			 'friends:collectionadded' => "Your collection was successfuly created",
			 'friends:nocollectionname' => "Koleksiyon oluşturmadan önce bir isim vermelisiniz.",
			'friends:collections:members' => "Koleksiyon üyeleri",
			'friends:collections:edit' => "Koleksiyon düzenle",
		
	        'friends:river:created' => "%s adlı kişi arkadaşlar widgetını ekledi.",
	        'friends:river:updated' => "%s adlı kişi arkadaşlar widgetını güncelledi.",
	        'friends:river:delete' => "%s adlı kişi arkadaşlar widgetını kaldırdı",
	        'friends:river:add' => "%s artık arkadaş:",
	
			'friendspicker:chararray' => 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
	
		/**
		 * Feeds
		 */
			'feed:rss' => 'Besleme için kayıt ol',
			'feed:odd' => 'Syndicate OpenDD',
			
		/**
          * links
		 **/

			'link:view' => 'bağlantıyı görüntüle',

	
		/**
		 * River
		 */
			'river' => "Nehir",			
			'river:relationship:friend' => 'artık arkadaş ile',
			'river:noaccess' => 'Bunu görmek için izniniz yok.',
			'river:posted:generic' => '%s posted',

		/**
		 * Plugins
		 */
			'plugins:settings:save:ok' => "%s eklentisinin ayarları başarıyla kaydedildi.",
			'plugins:settings:save:fail' => "%s eklentisinin ayarları kaydedilirken bir hata oluştu.",
			'plugins:usersettings:save:ok' => "%s eklentisinin kullanıcı ayarları başarıyla kaydedildi.",
			'plugins:usersettings:save:fail' => "%s eklentisinin kullanıcı ayarları kaydedilirken bir hata oluştu.",
			'admin:plugins:label:version' => "Sürüm",
			'item:object:plugin' => 'Eklenti yapılandırma ayarları',
			
		/**
		 * Notifications
		 */
			'notifications:usersettings' => "Bildirim ayarları",
			'notifications:methods' => "Lütfen hangi metotlara izin vermek istediğinizi belirtiniz.",
	
			'notifications:usersettings:save:ok' => "Bildirim ayarlarınız başarıyla kaydedildi.",
			'notifications:usersettings:save:fail' => "Bildirim ayarlarınızı kaydederken bir hata oluştu.",
	
			'user.notification.get' => 'Belirli bir kullanıcı için bildirim ayarlarına dön.',
			'user.notification.set' => 'Belirli bir kullanıcı için bildirim ayarları belirle.',
		/**
		 * Search
		 */
	
			'search' => "Ara",
			'searchtitle' => "Ara: %s",
			'users:searchtitle' => "Kullanıcılarda aranıyor: %s",
			'groups:searchtitle' => "Gruplarda aranıyor: %s",
			'advancedsearchtitle' => "%s ile uyan sonuçlar %s",
			'notfound' => "Hiçbir sonuç bulunamadı.",
			'next' => "İleri",
			'previous' => "Geri",
	
			'viewtype:change' => "Listeleme şeklini değiştir",
			'viewtype:list' => "Liste görünümü",
			'viewtype:gallery' => "Galeri",
	
			'tag:search:startblurb' => "Uyan etiketler '%s':",

			'user:search:startblurb' => "Uyan kullanıcılar '%s':",
			'user:search:finishblurb' => "Daha fazla görüntülemek için tıklayın.",
	
			'group:search:startblurb' => "Uyan gruplar '%s':",
			'group:search:finishblurb' => "Daha fazla görüntülemek için tıklayın.",
			'search:go' => 'Ara',
	
		/**
		 * Account
		 */
	
			'account' => "Hesap",
			'settings' => "Ayarlar",
            'tools' => "Araçlar",
            'tools:yours' => "Araçlarınız",
	
			'register' => "Kayıt Ol",
			'registerok' => "%s için başarıyla kayıt oldunuz.",
			'registerbad' => "Kayıt işleminiz başarısız oldu. Seçtiğiniz kullanıcı adı var, şifreleriniz uyuşmuyor veya kullanıcı adınız veya şifreniz kısa olabilir.",
			'registerdisabled' => "Kayıt işlemi yöneticiler tarafından donduruldu.",
	
			'firstadminlogininstructions' => 'Yeni Elgg siteniz başarıyla kuruldu ve yönetici hesabınız oluşturuldu. Kurulu eklentileri aktif ederek sitenizi yönetmeye başlayabilirsiniz.',
	
			'registration:notemail' => 'Girdiğiniz e-posta adresi hatalı gözüküyor.',
			'registration:userexists' => 'Bu kullanıcı adı daha önceden kayıt edilmiş',
			'registration:usernametooshort' => 'Kullanıcı adınız en az 4 karakterden oluşmalı.',
			'registration:passwordtooshort' => 'Şifreniz en az 6 karakterden oluşmalı.',
			'registration:dupeemail' => 'Bu e-posta adresi daha önceden kayıt edilmiş.',
			'registration:invalidchars' => 'Üzgünüz, kullanıcı adınızda geçersiz karakterler var.',
			'registration:emailnotvalid' => 'Üzgünüz, girdiğiniz e-posta adresi bu sistemde kabul görmüyor.',
			'registration:passwordnotvalid' => 'Üzgünüz, girdiğiniz şifre bu sistemde kabul görmüyor.',
			'registration:usernamenotvalid' => 'Üzgünüz, girdiğiniz kullanıcı adı bu sistemde kabul görmüyor.',
	
			'adduser' => "Kullanıcı Ekle",
			'adduser:ok' => "Başarıyla yeni kullanıcı eklediniz.",
			'adduser:bad' => "Yeni kullanıcı eklenemedi.",
			
			'item:object:reported_content' => "Rapor edilmiş itemlar",
	
			'user:set:name' => "Hesap ismi ayarları",
			'user:name:label' => "İsminiz",
			'user:name:success' => "İsminizi başarıyla sistemde değiştirdiniz.",
			'user:name:fail' => "İsminiz sistemde değiştirilemedi.",
	
			'user:set:password' => "Hesap Şifresi",
			'user:password:label' => "Yeni şifreniz",
			'user:password2:label' => "Yeni şifreniz (tekrar)",
			'user:password:success' => "Şifreniz değiştirildi.",
			'user:password:fail' => "Şifreniz değiştirilemedi!.",
			'user:password:fail:notsame' => "İki alandaki şifrede aynı olmalı!",
			'user:password:fail:tooshort' => "Şifreniz en az 6 karakter olmalı!",
	
			'user:set:language' => "Dil ayarları",
			'user:language:label' => "Diliniz",
			'user:language:success' => "Dil ayarlarınız güncellendi.",
			'user:language:fail' => "Dil ayarlarınız güncellenemedi!",
	
			'user:username:notfound' => '%s kullanıcı adı bulunamadı.',
	
			'user:password:lost' => 'Şifremi kaybettim',
			'user:password:resetreq:success' => 'Yeni şifreniz belirtmiş olduğunuz e-posta adresine yollandı.',
			'user:password:resetreq:fail' => 'Yeni şifre verilemedi!',
	
			'user:password:text' => 'Yeni şifre almak için kullanıcı adınızı aşağıdaki kutuya yazınız. Size e-posta aracılığıyla bir doğrulama bağlantısı yollayacağız. Bağlantıyı açtıktan sonra yeni şifrenizi size yollayacağız.',
	
			'user:persistent' => 'Beni hatırla',
		/**
		 * Administration
		 */

			'admin:configuration:success' => "Ayarlarınız kaydedildi.",
			'admin:configuration:fail' => "Ayarlarınız kaydedilemedi!",
	
			'admin' => "Yönetim",
			'admin:description' => "Yöneticiti paneli, kullanıcı yönetiminden, eklentilerin davranışlarına kadar her türlü yönde sistemi yönetmenizi sağlar. Başlamak için aşağıdan bir seçenek seçin.",
			
			'admin:user' => "Kullanıcı Yönetimi",
			'admin:user:description' => "Bu yönetici paneli sitenizin kullanıcı ayarlarını kontrol etmenize yardımcı olur. Başlamak için aşağıdan bir seçenek seçin.",
			'admin:user:adduser:label' => "Yeni kullanıcı eklemek için tıklayın...",
			'admin:user:opt:linktext' => "Kullanıcıları yönet...",
			'admin:user:opt:description' => "Kullanıcı ve hesap bilgilerini yönet. ",
			
			'admin:site' => "Site Yönetimi",
			'admin:site:description' => "Bu yönetici paneli sitenizin genel ayarlarını kontrol etmenize yardımcı olur. Başlamak için aşağıdan bir seçenek seçin.",
			'admin:site:opt:linktext' => "Siteyi Yönet...",
			'admin:site:opt:description' => "Teknik ve teknik olmayan site ayarlarını yönet. ",
			'admin:site:access:warning' => "Erişim ayarlarını değiştirmek sadece ileride yaratılacak içeriklere olan izinleri etkileyecektir.", 
			
			'admin:plugins' => "Araç Yönetimi",
			'admin:plugins:description' => "Bu yönetim paneli sitenizde kurulu olan araçları yönetmenize ve kontrol etmenize yardımcı olur..",
			'admin:plugins:opt:linktext' => "Araçları yönet...",
			'admin:plugins:opt:description' => "Sitede kurulu olan araçları yönet. ",
			'admin:plugins:label:author' => "Yazar",
			'admin:plugins:label:copyright' => "Telif hakkı",
			'admin:plugins:label:licence' => "Licence",
			'admin:plugins:label:website' => "URL",
			'admin:plugins:label:moreinfo' => 'daha fazla bilgi',
			'admin:plugins:label:version' => 'Sürüm',
			'admin:plugins:warning:elggversionunknown' => 'Uyarı: Bu eklenti için uyumlu bir Elgg sürümü belirtilmemiş.',
			'admin:plugins:warning:elggtoolow' => 'Uyarı: Bu eklentiyi kullanmak için Elgg\'in daha yeni sürümü gerekmektedir!',
			'admin:plugins:reorder:yes' => "%s eklentisi başarıyla tekrar sıralandı.",
			'admin:plugins:reorder:no' => "%s eklentisi tekrar sıralanamadı.",
			'admin:plugins:disable:yes' => "%s eklentisi başarıyla devre dışı bırakıldı.",
			'admin:plugins:disable:no' => "%s eklentisi devre dışı bırakılamadı.",
			'admin:plugins:enable:yes' => "%s eklentisi başarıyla etkinleştirildi.",
			'admin:plugins:enable:no' => "%s eklentisi etkinleştirilemedi.",
	
			'admin:statistics' => "İstatistikler",
			'admin:statistics:description' => "Bu sitenizin kısa istatistikleridir. Eğer daha detaylı istatistiki bilgilere ihtiyacınız varsa, profesyonel bir yönetim özelliği vardır",
			'admin:statistics:opt:description' => "Sitenizdeki kullanıcılar ve nesneler hakkından istatiktiksel bilgiler görüntüle.",
			'admin:statistics:opt:linktext' => "İstatistikleri gör...",
			'admin:statistics:label:basic' => "Basit site istatistikleri",
			'admin:statistics:label:numentities' => "Entities on site",
			'admin:statistics:label:numusers' => "Kullanıcı sayısı",
			'admin:statistics:label:numonline' => "Çevrimiçi kullanıcı sayısı",
			'admin:statistics:label:onlineusers' => "kullanıcı şu an çevrimiçi.",
			'admin:statistics:label:version' => "Elgg sürümü",
			'admin:statistics:label:version:release' => "Release",
			'admin:statistics:label:version:version' => "Sürüm",
	
			'admin:user:label:search' => "Kullanıcıları bul:",
			'admin:user:label:seachbutton' => "Ara", 
	
			'admin:user:ban:no' => "Kullanıcı yasaklanamaz",
			'admin:user:ban:yes' => "Kullanıcı yasaklandı.",
			'admin:user:unban:no' => "Kullanıcı yasağı kaldırılamaz",
			'admin:user:unban:yes' => "Kullanıcı yasağı kaldırıldı.",
			'admin:user:delete:no' => "Kullanıcı silinemez",
			'admin:user:delete:yes' => "Kullanıcı silindi.",
	
			'admin:user:resetpassword:yes' => "Şifre resetlendi, kullanıcı bilgilendirildi.",
			'admin:user:resetpassword:no' => "Şifre resetlenemez.",
	
			'admin:user:makeadmin:yes' => "Kullanıcı şimdi bir yönetici.",
			'admin:user:makeadmin:no' => "Bu kullanıcıyı yönetici yapamıyoruz.",
	
			'admin:user:removeadmin:yes' => "Bu kullanıcı artık admin değil.",
			'admin:user:removeadmin:no' => "Bu kullanıcının yönetici ayrıcalıklarını silemiyoruz.",
			
		/**
		 * User settings
		 */
			'usersettings:description' => "Kullanıcı ayarları paneli tüm kişisel ayarlarınızı, kullanıcı yönetiminden eklentilerin davranışlarına kadar kontrol etmenize yardımcı olur. Başlamak için aşağıdan bir seçenek seçin.",
	
			'usersettings:statistics' => "İstatistikleriniz",
			'usersettings:statistics:opt:description' => "Sitenizdeki kullanıcılar ve nesneler hakkından istatiktiksel bilgiler görüntüle.",
			'usersettings:statistics:opt:linktext' => "Hesap İstatistikleri",
	
			'usersettings:user' => "Ayarlarınız",
			'usersettings:user:opt:description' => "Bu kullanıcı ayarlarınızı kontrol etmenizi sağlar.",
			'usersettings:user:opt:linktext' => "Kullanıcı ayarlarınızı değiştirin",
	
			'usersettings:plugins' => "Araçlar",
			'usersettings:plugins:opt:description' => "Aktif araçlarınızı yönetmenizi sağlar.",
			'usersettings:plugins:opt:linktext' => "Araçlarınızı yönetin",
	
			'usersettings:plugins:description' => "Bu panel, yöneticilerimiz tarafından kurulmuş araçlar için kişisel ayarlarınızı kontrol ve yönetmenizi sağlar.",
			'usersettings:statistics:label:numentities' => "Your entities",
	
			'usersettings:statistics:yourdetails' => "Bilgileriniz",
			'usersettings:statistics:label:name' => "İsim",
			'usersettings:statistics:label:email' => "E-Posta",
			'usersettings:statistics:label:membersince' => "Üyelik tarihi",
			'usersettings:statistics:label:lastlogin' => "Son giriş",
	
			
	
		/**
		 * Generic action words
		 */
	
			'save' => "Kaydet",
			'publish' => "Yayınla",
			'cancel' => "İptal",
			'saving' => "Kaydediliyor",
			'update' => "Güncelle",
			'edit' => "Düzenle",
			'delete' => "Sil",
			'accept' => "Kabul Et",
			'load' => "Yükle",
			'upload' => "Yükle",
			'ban' => "Yasakla",
			'unban' => "Yasağı Kaldır",
			'enable' => "Etkinleştir",
			'disable' => "Devre dışı bırak",
			'request' => "İstek",
			'complete' => "Tamamla",
			'open' => 'Aç',
			'close' => 'Kapat',
			'reply' => "Yanıtla",
			'more' => 'Daha Fazla',
			'comments' => 'Yorumlar',
			'import' => 'İçe Aktar',
			'export' => 'Dışa Aktar',
	
			'up' => 'Yukarı',
			'down' => 'Aşağı',
			'top' => 'Üst',
			'bottom' => 'Alt',
	
			'invite' => "Davet Et",
	
			'resetpassword' => "Şifre Sıfırlama",
			'makeadmin' => "Yönetici yap",
			'removeadmin' => "Yöneticiliği kaldır",
	
			'option:yes' => "Evet",
			'option:no' => "Hayır",
	
			'unknown' => 'Bilinmiyor',
	
			'active' => 'Aktif',
			'total' => 'Toplam',
	
			'learnmore' => "Daha fazla öğrenmek için tıklayın.",
	
			'content' => "içerik",
			'content:latest' => 'En son eylemler',
			'content:latest:blurb' => 'Siteye en son eklenen içerikleri görmek için burayı tıklayın.',
	
			'link:text' => 'bağlantıyı görüntüle',
	
			'enableall' => 'Hepsini Etkinleştir',
			'disableall' => 'Hepsini Devre dışı bırak',
	
		/**
		 * Generic questions
		 */
	
			'question:areyousure' => 'Emin misiniz?',
	
		/**
		 * Generic data words
		 */
	
			'title' => "Başlık",
			'description' => "Açıklama",
			'tags' => "Etiketler",
			'spotlight' => "Spotlight",
			'all' => "Hepsi",
	
			'by' => 'tarafından',
	
			'annotations' => "Dipnotlar",
			'relationships' => "İlişkiler",
			'metadata' => "Üstveri",
	
		/**
		 * Input / output strings
		 */

			'deleteconfirm' => "Bunu silmek istediğinize emin misiniz?",
			'fileexists' => "Bu dosya daha önce yüklenmiş. Eski dosya üzerine kaydetmek için lütfen aşağıdan seçiniz:",
			
		/**
		 * User add
		 */

			'useradd:subject' => 'Kullanıcı hesabı oluşturuldu.',
			'useradd:body' => '
%s,

%s\'da\' sizin için bir hesap oluşturuldu. Giriş yapmak için lütfen aşağıdaki bağlantıyı ziyaret ediniz:

	%s

Kullanıcı hesap bilgileriniz:

	Kullanıcı adı: %s
	Şifre: %s
	
Sitemize ilk girişinizde şifrenizi değiştirmenizi rica ederiz.
',
			
	    /**
         * System messages
         **/

			'systemmessages:dismiss' => "kapatmak için tıklayınız.",

	
		/**
		 * Import / export
		 */
			'importsuccess' => "Verinin içe aktarılması başarını",
			'importfail' => "OpenDD veri içe aktarması başarısız!",
	
		/**
		 * Time
		 */
	
			'friendlytime:justnow' => "şimdi",
			'friendlytime:minutes' => "%s dakika önce",
			'friendlytime:minutes:singular' => "bir dakika önce",
			'friendlytime:hours' => "%s saat önce",
			'friendlytime:hours:singular' => "bir saat önce",
			'friendlytime:days' => "%s gün önce",
			'friendlytime:days:singular' => "dün",
	
			'date:month:01' => 'Ocak %s',
			'date:month:02' => 'Şubat %s',
			'date:month:03' => 'Mart %s',
			'date:month:04' => 'Nisan %s',
			'date:month:05' => 'Mayıs %s',
			'date:month:06' => 'Haziran %s',
			'date:month:07' => 'Temmuz %s',
			'date:month:08' => 'Ağustos %s',
			'date:month:09' => 'Eylül %s',
			'date:month:10' => 'Ekim %s',
			'date:month:11' => 'Kasım %s',
			'date:month:12' => 'Aralık %s',
	
	
		/**
		 * Installation and system settings
		 */
	
			'installation:error:htaccess' => "Elgg requires a file called .htaccess to be set in the root directory of its installation. We tried to create it for you, but Elgg doesn't have permission to write to that directory. 

Creating this is easy. Copy the contents of the textbox below into a text editor and save it as .htaccess

",
			'installation:error:settings' => "Elgg couldn't find its settings file. Most of Elgg's settings will be handled for you, but we need you to supply your database details. To do this:

1. Rename engine/settings.example.php to settings.php in your Elgg installation.

2. Open it with a text editor and enter your MySQL database details. If you don't know these, ask your system administrator or technical support for help.

Alternatively, you can enter your database settings below and we will try and do this for you...",
	
			'installation:error:configuration' => "Once you've corrected any configuration issues, press reload to try again.",
	
			'installation' => "Installation",
			'installation:success' => "Elgg's database was installed successfully.",
			'installation:configuration:success' => "Your initial configuration settings have been saved. Now register your initial user; this will be your first system administrator.",
	
			'installation:settings' => "System settings",
			'installation:settings:description' => "Now that the Elgg database has been successfully installed, you need to enter a couple of pieces of information to get your site fully up and running. We've tried to guess where we could, but <b>you should check these details.</b>",
	
			'installation:settings:dbwizard:prompt' => "Enter your database settings below and hit save:",
			'installation:settings:dbwizard:label:user' => "Database user",
			'installation:settings:dbwizard:label:pass' => "Database password",
			'installation:settings:dbwizard:label:dbname' => "Elgg database",
			'installation:settings:dbwizard:label:host' => "Database hostname (usually 'localhost')",
			'installation:settings:dbwizard:label:prefix' => "Database table prefix (usually 'elgg')",
	
			'installation:settings:dbwizard:savefail' => "We were unable to save the new settings.php. Please save the following file as engine/settings.php using a text editor.",
	
			'installation:sitename' => "The name of your site (eg \"My social networking site\"):",
			'installation:sitedescription' => "Short description of your site (optional)",
			'installation:wwwroot' => "The site URL, followed by a trailing slash:",
			'installation:path' => "The full path to your site root on your disk, followed by a trailing slash:",
			'installation:dataroot' => "The full path to the directory where uploaded files will be stored, followed by a trailing slash:",
			'installation:dataroot:warning' => "You must create this directory manually. It should sit in a different directory to your Elgg installation.",
			'installation:sitepermissions' => "The default access permissions:",
			'installation:language' => "The default language for your site:",
			'installation:debug' => "Debug mode provides extra information which can be used to diagnose faults, however it can slow your system down so should only be used if you are having problems:",
			'installation:debug:label' => "Turn on debug mode",
			'installation:httpslogin' => "Enable this to have user logins performed over HTTPS. You will need to have https enabled on your server for this to work.",
			'installation:httpslogin:label' => "Enable HTTPS logins",
			'installation:usage' => "This option lets Elgg send anonymous usage statistics back to Curverider.",
			'installation:usage:label' => "Send anonymous usage statistics",
			'installation:view' => "Enter the view which will be used as the default for your site or leave this blank for the default view (if in doubt, leave as default):",

			'installation:siteemail' => "Site email address (used when sending system emails)",
	
			'installation:disableapi' => "The RESTful API is a flexible and extensible interface that enables applications to use certain Elgg features remotely.",
			'installation:disableapi:label' => "Enable the RESTful API",
			
			'installation:allow_user_default_access:description' => "If checked, individual users will be allowed to set their own default access level that can over-ride the system default access level.",
			'installation:allow_user_default_access:label' => "Allow user default access",
	
			'installation:simplecache:description' => "The simple cache increases performance by caching static content including some CSS and JavaScript files. Normally you will want this on.",
			'installation:simplecache:label' => "Use simple cache (recommended)",
	
			'installation:viewpathcache:description' => "The view filepath cache decreases the loading times of plugins by caching the location of their views.",
			'installation:viewpathcache:label' => "Use view filepath cache (recommended)",
	
			'upgrading' => 'Upgrading',
			'upgrade:db' => 'Your database was upgraded.',
			'upgrade:core' => 'Your elgg installation was upgraded',
	
		/**
		 * Welcome
		 */
	
			'welcome' => "Hoşgeldiniz",
			'welcome:user' => '%s, hoşgeldiniz.',
			'welcome_message' => "Elgg kurulumuna hoşgeldiniz.",
	
		/**
		 * Emails
		 */
			'email:settings' => "E-Posta ayarları",
			'email:address:label' => "E-Posta adresiniz",
			
			'email:save:success' => "Yeni E-Posta adresi kayıt edildi, onaylama isteği yapıldı.",
			'email:save:fail' => "Yeni E-Posta adresiniz kayıt edilemedi.",
	
			'friend:newfriend:subject' => "%s sizi arkadaşı olarak ekledi!",
			'friend:newfriend:body' => "%s sizi arkadaşı olarak ekledi!

Profilini görmek için burayı tıklayınız:

	%s

Bu mesaja yanıt vermeyiniz. İyi günler dileriz.",
	
	
	
			'email:resetpassword:subject' => "Şifre Sıfırlama!",
			'email:resetpassword:body' => "Merhaba %s,
			
Yeni şifreniz: %s",
	
	
			'email:resetreq:subject' => "Yeni şifre talebiniz.",
			'email:resetreq:body' => "Merhaba %s,
			
Birileri (bu IP adresinden: %s) bu e-posta adresine kayıtlı hesap için yeni şifre talebinde bulundu.

Eğer bu kişi sizseniz lütfen aşağıdaki bağlantıya tıklayınız. Aksi taktirde ise bu mesajı gözardı etmenizde hiç bir sakınca yoktur.

%s
",

		/**
		 * user default access
		 */
	
		'default_access:settings' => "Varsayılan erişim düzeyiniz",
		'default_access:label' => "Varsayılan erişim",
		'user:default_access:success' => "Yeni varsayılan erişim düzeyiniz başarıyla kayıt edildi.",
		'user:default_access:failure' => "Yeni varsayılan erişim düzeyiniz kayıt edilemedi..",
	
		/**
		 * XML-RPC
		 */
			'xmlrpc:noinputdata'	=>	"Giriş verisi eksik",
	
		/**
		 * Comments
		 */
	
			'comments:count' => "%s adlı kişinin yorumları",
			
			'riveraction:annotation:generic_comment' => '%s adlı kişi %s olayını yorumladı.',
	
			'generic_comments:add' => "Yorumunuzu ekleyin",
			'generic_comments:text' => "Yorum",
			'generic_comment:posted' => "Yorumunuz başarıyla eklendi.",
			'generic_comment:deleted' => "Yorumunuz başarıyla silindi .",
			'generic_comment:blank' => "Üzgünüz; yorum eklenmeden önce, yorum alanına birşeyler yazmanız gereklidir.",
			'generic_comment:notfound' => "Üzgünüz; belittiğiniz şeyi bulamadık.",
			'generic_comment:notdeleted' => "Üzgünüz; bu yorumu silemedik.",
			'generic_comment:failure' => "Yorumunuz eklenirken beklenmedik bir hata oluştu. Lütfen tekrar deneyiniz.",
	
			'generic_comment:email:subject' => 'Yeni bir yorumunuz var!',
			'generic_comment:email:body' => "\"%s\" içeriğinizde %s adlı kişiden yeni bir yorumunuz var. Diyor ki:

			
%s


Yanıt vermek veya içeriği görüntülemek için lütfen tıklayınız:

	%s

%s adlı kişinin profilini görmek için lütfen tıklayınız:

	%s

Bu mesaja yanıt vermeyiniz. İyi günler dileriz.",
	
		/**
		 * Entities
		 */
			'entity:default:strapline' => '%s tarihinde %s tarafından oluşturuldu.',
			'entity:default:missingsupport:popup' => 'Bu içerik doğru görüntülenemiyor. Bunun nedeni içeriğin, artık kurulu olmayan bir eklentiyi kullanmak istemesi olabilir.',
	
			'entity:delete:success' => '%s içeriği silindi.',
			'entity:delete:fail' => '%s içeriği silinemedi!',
	
	
		/**
		 * Action gatekeeper
		 */
			'actiongatekeeper:missingfields' => 'Form is missing __token or __ts fields',
			'actiongatekeeper:tokeninvalid' => "We encountered an error (token mismatch). This probably means that the page you were using expired. Please try again.",
			'actiongatekeeper:timeerror' => 'Kullandığınız sayfa zaman aşımına uğradı. Lütfen sayfayı yenileyiniz ve tekrar deneyiniz.',
			'actiongatekeeper:pluginprevents' => 'A extension has prevented this form from being submitted.',
	
		/**
		 * Word blacklists
		 */
			'word:blacklist' => 'and, the, then, but, she, his, her, him, one, not, also, about, now, hence, however, still, likewise, otherwise, therefore, conversely, rather, consequently, furthermore, nevertheless, instead, meanwhile, accordingly, this, seems, what, whom, whose, whoever, whomever',
	
		/**
		 * Languages according to ISO 639-1
		 */
			"aa" => "Afar",
			"ab" => "Abkhazian",
			"af" => "Afrikaans",
			"am" => "Amharic",
			"ar" => "Arabic",
			"as" => "Assamese",
			"ay" => "Aymara",
			"az" => "Azerbaijani",
			"ba" => "Bashkir",
			"be" => "Byelorussian",
			"bg" => "Bulgarian",
			"bh" => "Bihari",
			"bi" => "Bislama",
			"bn" => "Bengali; Bangla",
			"bo" => "Tibetan",
			"br" => "Breton",
			"ca" => "Catalan",
			"co" => "Corsican",
			"cs" => "Czech",
			"cy" => "Welsh",
			"da" => "Danish",
			"de" => "German",
			"dz" => "Bhutani",
			"el" => "Greek",
			"en" => "English",
			"eo" => "Esperanto",
			"es" => "Spanish",
			"et" => "Estonian",
			"eu" => "Basque",
			"fa" => "Persian",
			"fi" => "Finnish",
			"fj" => "Fiji",
			"fo" => "Faeroese",
			"fr" => "French",
			"fy" => "Frisian",
			"ga" => "Irish",
			"gd" => "Scots / Gaelic",
			"gl" => "Galician",
			"gn" => "Guarani",
			"gu" => "Gujarati",
			"he" => "Hebrew",
			"ha" => "Hausa",
			"hi" => "Hindi",
			"hr" => "Croatian",
			"hu" => "Hungarian",
			"hy" => "Armenian",
			"ia" => "Interlingua",
			"id" => "Indonesian",
			"ie" => "Interlingue",
			"ik" => "Inupiak",
			//"in" => "Indonesian",
			"is" => "Icelandic",
			"it" => "Italian",
			"iu" => "Inuktitut",
			"iw" => "Hebrew (obsolete)",
			"ja" => "Japanese",
			"ji" => "Yiddish (obsolete)",
			"jw" => "Javanese",
			"ka" => "Georgian",
			"kk" => "Kazakh",
			"kl" => "Greenlandic",
			"km" => "Cambodian",
			"kn" => "Kannada",
			"ko" => "Korean",
			"ks" => "Kashmiri",
			"ku" => "Kurdish",
			"ky" => "Kirghiz",
			"la" => "Latin",
			"ln" => "Lingala",
			"lo" => "Laothian",
			"lt" => "Lithuanian",
			"lv" => "Latvian/Lettish",
			"mg" => "Malagasy",
			"mi" => "Maori",
			"mk" => "Macedonian",
			"ml" => "Malayalam",
			"mn" => "Mongolian",
			"mo" => "Moldavian",
			"mr" => "Marathi",
			"ms" => "Malay",
			"mt" => "Maltese",
			"my" => "Burmese",
			"na" => "Nauru",
			"ne" => "Nepali",
			"nl" => "Dutch",
			"no" => "Norwegian",
			"oc" => "Occitan",
			"om" => "(Afan) Oromo",
			"or" => "Oriya",
			"pa" => "Punjabi",
			"pl" => "Polish",
			"ps" => "Pashto / Pushto",
			"pt" => "Portuguese",
			"qu" => "Quechua",
			"rm" => "Rhaeto-Romance",
			"rn" => "Kirundi",
			"ro" => "Romanian",
			"ru" => "Russian",
			"rw" => "Kinyarwanda",
			"sa" => "Sanskrit",
			"sd" => "Sindhi",
			"sg" => "Sangro",
			"sh" => "Serbo-Croatian",
			"si" => "Singhalese",
			"sk" => "Slovak",
			"sl" => "Slovenian",
			"sm" => "Samoan",
			"sn" => "Shona",
			"so" => "Somali",
			"sq" => "Albanian",
			"sr" => "Serbian",
			"ss" => "Siswati",
			"st" => "Sesotho",
			"su" => "Sundanese",
			"sv" => "Swedish",
			"sw" => "Swahili",
			"ta" => "Tamil",
			"te" => "Tegulu",
			"tg" => "Tajik",
			"th" => "Thai",
			"ti" => "Tigrinya",
			"tk" => "Turkmen",
			"tl" => "Tagalog",
			"tn" => "Setswana",
			"to" => "Tonga",
			"tr" => "Türkçe",
			"ts" => "Tsonga",
			"tt" => "Tatar",
			"tw" => "Twi",
			"ug" => "Uigur",
			"uk" => "Ukrainian",
			"ur" => "Urdu",
			"uz" => "Uzbek",
			"vi" => "Vietnamese",
			"vo" => "Volapuk",
			"wo" => "Wolof",
			"xh" => "Xhosa",
			//"y" => "Yiddish",
			"yi" => "Yiddish",
			"yo" => "Yoruba",
			"za" => "Zuang",
			"zh" => "Chinese",
			"zu" => "Zulu",
	);
	
	add_translation("tr",$turkish);

?>
