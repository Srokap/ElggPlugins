<?php
	/**
	 * Elgg garbage collector language pack.
	 * 
	 * @package ElggGarbageCollector
	 * @author Curverider Ltd
	 * @link http://elgg.com/
	 */

	$turkish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'garbagecollector:period' => 'Elgg çöp toplayıcı ne kadar sıklıkla çalıştırılsın?',
	
			'garbagecollector:weekly' => 'Haftada bir',
			'garbagecollector:monthly' => 'Ayda bir',
			'garbagecollector:yearly' => 'Yılda bir',
	
			'garbagecollector' => "ÇÖP TOPLAYICI\n",
			'garbagecollector:done' => "TAMAMLANDI\n",
			'garbagecollector:optimize' => "%s optimize ediliyor",
	
			'garbagecollector:error' => "HATA",
			'garbagecollector:ok' => "TAMAM",
	
			'garbagecollector:gc:metastrings' => 'Linklenmemiş üstsatırlar siliniyor: ',
	
	);
					
	add_translation("tr",$turkish);
?>