<?php
	/**
	 * Elgg file plugin language pack
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	$turkish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'file' => "Dosya",
			'files' => "Doslayar",
			'file:yours' => "Dosyalarınız",
			'file:yours:friends' => "Arkadaşlarınızın dosyaları",
			'file:user' => "%s adlı kişinin dosyaları",
			'file:friends' => "%s adlı kişinin arkadaşlarının dosyları",
			'file:all' => "Tüm dosyalar",
			'file:edit' => "Dosyayı düzenle",
			'file:more' => "Daha fazla dosya",
			'file:list' => "liste görünümü",
			'file:group' => "Grup dosyaları",
			'file:gallery' => "galeri görünümü",
			'file:gallery_list' => "Galeri veya liste görünümü",
			'file:num_files' => "Gösterilecek dosya sayısı",
			'file:user:gallery'=>'%s adlı kişinin galerisini görüntüle', 
	        'file:via' => 'dosyalar ile',
			'file:upload' => "Dosya yükle",
	
			'file:newupload' => 'Yeni dosya yükle',
			
			'file:file' => "Dosya",
			'file:title' => "Başlık",
			'file:desc' => "Açıklama",
			'file:tags' => "Etiketler",
	
			'file:types' => "Yüklenen dosya tipleri",
	
			'file:type:all' => "Tüm dosyalar",
			'file:type:video' => "Videolar",
			'file:type:document' => "Dökümanlar",
			'file:type:audio' => "Ses",
			'file:type:image' => "Resimler",
			'file:type:general' => "Genel",
	
			'file:user:type:video' => "%sadlı kişinin videoları",
			'file:user:type:document' => "%s adlı kişinin dökümanları",
			'file:user:type:audio' => "%s adlı kişinin sesleri",
			'file:user:type:image' => "%s adlı kişinin resimleri",
			'file:user:type:general' => "%s adlı kişinin genel dosyaları",
	
			'file:friends:type:video' => "Arkadaşlarının videoları",
			'file:friends:type:document' => "Arkadaşlarının dökümanları",
			'file:friends:type:audio' => "Arkadaşlarının sesleri",
			'file:friends:type:image' => "Arkadaşlarının resimleri",
			'file:friends:type:general' => "Your friends' general files",
	
			'file:widget' => "Dosya widgetı",
			'file:widget:description' => "Son dosyalarınız",
	
			'file:download' => "İndir",
	
			'file:delete:confirm' => "Bu dosyayı silmek istediğinize emin misiniz?",
			
			'file:tagcloud' => "Etiket bulutu",
	
			'file:display:number' => "Gösterilecek dosya sayısı",
	
			'file:river:created' => "%s adlı kişi yükledi",
			'file:river:item' => "bir dosya",
			'file:river:annotate' => "bu dosya yorulandı.",

			'item:object:file' => 'Dosyalar',
			
	    /**
		 * Embed media
		 **/
		 
		    'file:embed' => "Medya yerleştir",
		    'file:embedall' => "Hepsi",
	
		/**
		 * Status messages
		 */
	
			'file:saved' => "Dosyanız başarıyla kaydedildi.",
			'file:deleted' => "Dosyanız başarıyla silindi.",
	
		/**
		 * Error messages
		 */
	
			'file:none' => "Şu an herhangi bir dosya bulamadık.",
			'file:uploadfailed' => "Üzgünüz; dosyanız kaydedilemedi.",
			'file:downloadfailed' => "Üzgünüz; bu dosya şu anda etkin değil.",
			'file:deletefailed' => "Dosyanız şu anda silinemez.",
	
	);
					
	add_translation("tr",$turkish);
?>