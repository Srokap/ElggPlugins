<?php

	$turkish = array(
	
		/**
		 * Site info details
		 */
		
		'members:members' => "Üyeler",
	    'members:online' => "Çevrimiçi üyeler",
	    'members:active' => "üyeler",
	    'members:searchtag' => "Etiketle üye arama",
	    'members:searchname' => "İsim ile üye arama",
	   
		'members:label:newest' => 'En yeni',
		'members:label:popular' => 'Popüler',
		'members:label:active' => 'Çevrimiçi',
		
	);
					
	add_translation("tr",$turkish);

?>