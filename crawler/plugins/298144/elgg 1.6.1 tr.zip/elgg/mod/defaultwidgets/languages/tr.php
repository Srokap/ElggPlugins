<?php

$turkish = array (

	/**
	 * Nice name for the entity (shown in admin panel)
	 */
	'item:object:moddefaultwidgets' => 'Varsayılan widget ayarları',

	/**
	 * Menu items
	 */
	'defaultwidgets:menu:profile' => 'Varsayılan profil widgetları',
    'defaultwidgets:menu:dashboard' => 'Varsayılan pano widgetları',

    'defaultwidgets:admin:error' => 'Hata: yönetici olarak giriş yapılmadı.',
	'defaultwidgets:admin:notfound' => 'Hata: Sayfa bulunamadı.',
	'defaultwidgets:admin:loginfailure' => 'Uyarı: Şu an yönetici olarak giriş yapmamışsınız.',

	'defaultwidgets:update:success' => 'Widget ayarlarınız başarıyla kaydedildi.',
	'defaultwidgets:update:failed' => 'Hata: ayarlar kaydedilemedi',
	'defaultwidgets:update:noparams' => 'Hata: hatalı parametre',

	'defaultwidgets:profile:title' => 'Yeni kullanıcı profili için varsayılan widget ayarla',
	'defaultwidgets:dashboard:title' => 'Yeni kullanıcı panosu için varsayılan widget ayarla',
);

add_translation ( "tr", $turkish );
