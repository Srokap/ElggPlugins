Embed plugin
(c) 2009 Curverider Ltd
Released under the GNU Public License version 2
http://www.gnu.org/licenses/old-licenses/gpl-2.0.html

The embed plugin requires Elgg 1.5 (or prior to the Elgg 1.5
release, Elgg revision 2634 or above) and the file plugin.

It makes use of the jQuery form plugin, available at:
http://malsup.com/jquery/form/