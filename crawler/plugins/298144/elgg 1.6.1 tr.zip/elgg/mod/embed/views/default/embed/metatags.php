		<script type="text/javascript">
		 jQuery(document).ready(function($) {
		  $('a[rel*=facebox]').facebox()
		});
		</script>
