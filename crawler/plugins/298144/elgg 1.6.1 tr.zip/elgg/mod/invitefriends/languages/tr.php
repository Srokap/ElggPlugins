<?php

	/**
	 * Elgg invite page
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @link http://elgg.org/
	 */

	$turkish = array(

		'friends:invite' => 'Arkadaşlarını davet et',
		'invitefriends:introduction' => 'Arkadaşlarınızı davet etmek için aşağıdaki alana onların e-posta adreslerini yazabilirsiniz. (her satıra bir e-posta yazınız.):',
		'invitefriends:message' => 'Davet mesajınızı yazınız:',
		'invitefriends:subject' => '%s ağına davet',
	
		'invitefriends:success' => 'Arkadaşlarınız davet edildi.',
		'invitefriends:failure' => 'Arkadaşlarınız davet edilemedi.',
	
		'invitefriends:message:default' => '
Meraba,

Sizi %s ağına davet etmek istiyorum.',
		'invitefriends:email' => '
%s ağına %s tarafından davet edildiniz. Bu mesajıda ekledi:

%s

Katılmak için aşağıdaki bağlantıya tıklayabilirsiniz:

	%s

Davet eden kişi ağınıza arkadaş olarak eklenecektir.',
	
	);
					
	add_translation("tr",$turkish);
?>