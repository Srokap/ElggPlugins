<?php

	$turkish = array(
	
			'custom:bookmarks' => "En son yerimleri",
			'custom:groups' => "En son gruplar",
			'custom:files' => "En son dosyalar",
			'custom:blogs' => "En son blog gönderileri",
			'custom:members' => "En yeni kullanıcılar",
			'custom:nofiles' => "Şimdilik bir dosya yok",
			'custom:nogroups' => "Şimdilik bir grup yok",	
	
	);
					
	add_translation("tr",$turkish);

?>