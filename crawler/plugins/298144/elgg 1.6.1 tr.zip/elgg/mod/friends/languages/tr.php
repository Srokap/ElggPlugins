<?php

	$turkish = array(
	
		/**
		 * Friends widget
		 */
			'friends:widget:description' => "Arkadaşlarınızı gösterir.",
	        
		
	);
					
	add_translation("tr",$turkish);

?>