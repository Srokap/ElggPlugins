<?php

	$english = array(
	
		/**
		 * Friends widget
		 */
			'friends:widget:description' => "Displays some of your friends.",
	        
		
	);
					
	add_translation("en",$english);

?>