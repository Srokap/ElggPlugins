<?php

	$turkish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messageboard:board' => "Mesaj panosu",
			'messageboard:messageboard' => "Mesaj panosu",
			'messageboard:viewall' => "Hepsini gör",
			'messageboard:postit' => "Gönder",
			'messageboard:history' => "geçmiş",
			'messageboard:none' => "Bu mesaj panosunda birşey yok",
			'messageboard:num_display' => "Gösterilecek mesajların sayısı",
			'messageboard:desc' => "Bu profilinize oyabileceğiniz ve diğer kişilerin yorumlarını yazacakları bir mesaj panosudur.",
	
			'messageboard:user' => "%s adlı kişinin mesaj panosu",
	
			'messageboard:history' => "Geçmiş",
			'messageboard:replyon' => 'yanıtladı',
			
         /**
	     * Message board widget river
	     **/
	        
	        'messageboard:river:annotate' => "%s adlı kişi mesaj panosuna yeni yorum yaptı.",
	        'messageboard:river:create' => "%s adlı kişi profiline mesaj panosu ekledi.",
	        'messageboard:river:update' => "%s adlı kişi mesaj panosunu güncelledi.",
	        'messageboard:river:added' => "%s adlı kişi yolladı",
		    'messageboard:river:messageboard' => "mesaj panosu",

			
		/**
		 * Status messages
		 */
	
			'messageboard:posted' => "Mesaj panosuna başarıyla gönderi yaptınız.",
			'messageboard:deleted' => "Mesajı başarıyla sildiniz.",
	
		/**
		 * Email messages
		 */
	
			'messageboard:email:subject' => 'Mesaj panonuza yeni bir yorum var!',
			'messageboard:email:body' => "%s tarafından mesaj panonuza yeni bir yorum eklendi. Diyor ki:

			
%s


Mesaj panosu yorumlarınızı görmek için buraya tıklayınız:

	%s

%s adlı kişinin profilini görmek için buraya tıklayınız:

	%s

Lütfen bu e-postaya yanıt yazmayınız.",
	
		/**
		 * Error messages
		 */
	
			'messageboard:blank' => "Üzgünüz; mesaj alanına birşeyler yazmadan kaydedemezsiniz.",
			'messageboard:notfound' => "Üzgünüz; belirtilen nesneyi bulunamadı.",
			'messageboard:notdeleted' => "Üzgünüz; bu mesaj silinemedi.",
			'messageboard:somethingwentwrong' => "Mesajınız kaydedilirken bir hata oluştu, bir mesaj yazdığınızdan emin olunuz.",
	     
			'messageboard:failure' => "Mesajınız eklenirken beklenmeyen bir hata oluştu. Lütfen tekrar deneyiniz.",
	
	);
					
	add_translation("tr",$turkish);

?>