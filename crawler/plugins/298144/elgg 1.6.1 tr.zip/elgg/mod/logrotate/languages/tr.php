<?php
	/**
	 * Elgg log rotator language pack.
	 * 
	 * @package ElggLogRotate
	 * @author Curverider Ltd
	 * @link http://elgg.com/
	 */

	$turkish = array(
		'logrotate:period' => 'Sistem logları ne kadar sıklıkla arşivlensin?',
	
		'logrotate:weekly' => 'Hatada bir',
		'logrotate:monthly' => 'Ayda bir',
		'logrotate:yearly' => 'Yılda bir',
	
		'logrotate:logrotated' => "Loglar arşivlendi\n",
		'logrotate:lognotrotated' => "Loglar arşivlenirken hata oluştu\n",
	);
					
	add_translation("tr",$turkish);
?>