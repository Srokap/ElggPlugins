<?php

?>
<a href="<?php echo $vars['url']; ?>mod/logbrowser/?user_guid=<?php echo $vars['entity']->guid; ?>"><?php echo elgg_echo("logbrowser:explore"); ?></a>