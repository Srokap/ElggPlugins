<?php
	/**
	 * Elgg log browser plugin language pack
	 * 
	 * @package ElggLogBrowser
	 * @author Curverider Ltd
	 * @link http://elgg.com/
	 */

	$turkish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'logbrowser' => 'Log gezgini',
			'logbrowser:browse' => 'Sistem loglarını görüntüle',
			'logbrowser:search' => 'Sonuçları gör',
			'logbrowser:user' => 'Kullanıcı adına göre ara',
			'logbrowser:starttime' => 'Başlangıç zamanı (örnek olarak "en son pazartesi", "bir saat önce")',
			'logbrowser:endtime' => 'Bitiş zamanı',
	
			'logbrowser:explore' => 'Logları araştır',
	
	);
					
	add_translation("tr",$turkish);
?>