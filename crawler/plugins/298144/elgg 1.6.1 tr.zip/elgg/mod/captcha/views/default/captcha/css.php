
.captcha-input-image {
	align: center;
	margin: auto;
}

