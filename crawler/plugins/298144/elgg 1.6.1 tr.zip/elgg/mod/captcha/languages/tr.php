<?php
	/**
	 * Elgg diagnostics language pack.
	 * 
	 * @package ElggDiagnostics
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	$turkish = array(
	
		'captcha:entercaptcha' => 'Görüntüdeki karakterleri yazınız',
		'captcha:captchafail' => 'Üzgünüz, girdiğiniz karakterler görüntü ile uyuşmuyor.',
	
	);
					
	add_translation("tr",$turkish);
?>