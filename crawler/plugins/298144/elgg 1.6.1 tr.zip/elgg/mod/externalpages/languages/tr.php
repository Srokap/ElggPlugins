<?php

	$turkish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'expages' => "Harici sayfalar",
			'expages:frontpage' => "Ön Sayfa",
			'expages:about' => "Hakkında",
			'expages:terms' => "Kullanım Şartları",
			'expages:privacy' => "Gizlilik",
			'expages:analytics' => "Analytics",
			'expages:contact' => "İletişim",
			'expages:nopreview' => "Önizleme etkin değil.",
			'expages:preview' => "Önizleme",
			'expages:notset' => "Bu sayfa daha yapılandırılmamış.",
			'expages:lefthand' => "Sol bölüm bilgisi",
			'expages:righthand' => "Sağ bölüm bilgisi",
			'expages:addcontent' => "Buraya yönetim araçları ile içerik ekleyebilirsiniz. Yönetici sayfasında harici sayfalara bakınız.",
			'item:object:front' => 'Öz sayfa nesneleri',
	
		/**
		 * Status messages
		 */
	
			'expages:posted' => "Sayfanız başarıyla eklendi.",
			'expages:deleted' => "Sayfanız başarıyla silindi.",
	
		/**
		 * Error messages
		 */
	
			'expages:deleteerror' => "Eski sayfayı silerken bir hata oluştu.",
			'expages:error' => "Bir hata oluştu, lütfen tekrar deneyiniz. Eğer sorununuz devam ederse yönetici ile bağlantı kurunuz.",
	
	);
					
	add_translation("tr",$turkish);

?>