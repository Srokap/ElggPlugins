<?php

	$turkish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messages' => "Mesajlar",
            'messages:back' => "mesajlara geri dön",
			'messages:user' => "Gelen kutusu",
			'messages:sentMessages' => "Gönderilenler",
			'messages:posttitle' => "%s adlı kişinin mesajları: %s",
			'messages:inbox' => "Gelen kutusu",
			'messages:send' => "Mesaj gönder",
			'messages:sent' => "Gönderilenler",
			'messages:message' => "Mesaj",
			'messages:title' => "Başlık",
			'messages:to' => "Kime",
            'messages:from' => "Kimden",
			'messages:fly' => "Gönder",
			'messages:replying' => "Alıntı",
			'messages:inbox' => "Gelen kutusu",
			'messages:sendmessage' => "Mesaj gönder",
			'messages:compose' => "Mesaj yaz",
			'messages:sentmessages' => "Gönderilenler",
			'messages:recent' => "Son mesajlar",
            'messages:original' => "Orjinal mesaj",
            'messages:yours' => "Mesajınız",
            'messages:answer' => "Yanıtla",
			'messages:toggle' => 'Aç / Kapat',
			'messages:markread' => 'Okundu olarak işaretle',
			
			'messages:new' => 'Yeni mesaj',
	
			'notification:method:site' => 'Site',
	
			'messages:error' => 'Mesajınız kaydedilirken bir hata oluştu. Lütfen tekrar deneyiniz.',
	
			'item:object:messages' => 'Mesajlar',
	
		/**
		 * Status messages
		 */
	
			'messages:posted' => "Mesajınız başarıyla gönderildi.",
			'messages:deleted' => "Mesajınız başarıyla silindi.",
			'messages:markedread' => "Mesajlarınız okundu olarak işaretlendi.",
	
		/**
		 * Email messages
		 */
	
			'messages:email:subject' => 'Yeni bir mesajınız var!',
			'messages:email:body' => "%s tarafından yeni bir mesajınız var. Diyor ki:

			
%s


Mesajlarınızı görmek için tıklayınız:

	%s

%s adlı kişiye bir mesaj yollamak için tıklayınız:

	%s

Lütfen bu e-postaya yanıt vermeyiniz.",
	
		/**
		 * Error messages
		 */
	
			'messages:blank' => "Üzgünüz; kaydetmeden önce mesaj gövdesine birşeyler yazmanız gereklidir.",
			'messages:notfound' => "Üzgünüz; belirttiğiniz mesaj bulunamadı.",
			'messages:notdeleted' => "Üzgünüz; bu mesaj silinemedi.",
			'messages:nopermission' => "Bu mesajı değiştirmek için yetkiniz yok.",
			'messages:nomessages' => "Görüntülenecek bir mesaj yok.",
			'messages:user:nonexist' => "Kullanıcılar arasında belirttiğiniz alıcı bulunamadı.",
			'messages:user:blank' => "Bunu göndermek için bir kişi seçmelisiniz.",
	
	);
					
	add_translation("tr",$turkish);

?>