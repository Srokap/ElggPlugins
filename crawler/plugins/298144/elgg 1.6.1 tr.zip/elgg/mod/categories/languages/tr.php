<?php

	$turkish = array(
	
		'categories' => 'Kategoriler',
		'categories:settings' => 'Site kategorilerini ayarla',	
		'categories:explanation' => 'Sitenizin genelinde kullanılmak üzere, önceden belirlenmiş kategorileri ayarlamak için, kategori isimlerini, aralarına virgül koyarak aşağıya yazınız. Kullanıcılarınız bir içerik eklerken veya değiştirirken, uygun araçlar bunları göstereceklerdir.',	
		'categories:save:success' => 'Site kategorileri başarıyla kaydedildi.',
	
	);
					
	add_translation("tr",$turkish);

?>