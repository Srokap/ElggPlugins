<?php
	/**
	 * Elgg groups plugin language pack
	 * 
	 * @package ElggGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	$turkish = array(
	
		/**
		 * Menu items and titles
		 */
			
			'groups' => "Gruplar",
			'groups:owned' => "Sizin gruplarınız",
			'groups:yours' => "Grupların",
			'groups:user' => "%s adlı kişinin grupları",
			'groups:all' => "Tüm gruplar",
			'groups:new' => "Yeni grup oluştur",
			'groups:edit' => "Grubu düzenle",
			'groups:delete' => 'Grubu sil',
			'groups:membershiprequests' => 'Giriş isteklerini yönet',
	
			'groups:icon' => 'Grup simgesi (değişmemesi için boş bırakın)',
			'groups:name' => 'Grup ismi',
			'groups:username' => 'Kısa isim (bağlantılarda görüntülenecektir, A-Z,a-z ve 0-9 arasındaki karakterlerden oluşmaludır.)',
			'groups:description' => 'Açıklama',
			'groups:briefdescription' => 'Kısa açıklama',
			'groups:interests' => 'Etiketler',
			'groups:website' => 'Websitesi',
			'groups:members' => 'Grup üyeleri',
			'groups:membership' => "Grup üyelik izinleri",
			'groups:access' => "İzinlere eriş",
			'groups:owner' => "Sahip",
	        'groups:widget:num_display' => 'Gösterilecek grup sayısı',
	        'groups:widget:membership' => 'Grup üyeliği',
	        'groups:widgets:description' => 'Üye olduğunuz grupları gösterir.',
			'groups:noaccess' => 'Gruba erişim yok',
			'groups:cantedit' => 'Bu gurubu düzenleyemezsiniz',
			'groups:saved' => 'Grup kaydedilde',
			'groups:featured' => 'Önerilen gruplar',
			'groups:makeunfeatured' => 'Önerilmez',
			'groups:makefeatured' => 'Öner',
			'groups:featuredon' => 'Bu grubu önerdiniz.',
			'groups:unfeature' => 'Bu grubu önerilen gruplardan çıkardınız',
			'groups:joinrequest' => 'Üye isteği',
			'groups:join' => 'Gruba katıl',
			'groups:leave' => 'Gruptan ayrıl',
			'groups:invite' => 'Davet et',
			'groups:inviteto' => "Arkadaşlarını davet et '%s'",
			'groups:nofriends' => "Bu gruba davet edilmemiş bir arkadaşınız yok.",
			'groups:viagroups' => "gruplar ile",
			'groups:group' => "Grup",
	
			'groups:notfound' => "Grup bulunamadı",
			'groups:notfound:details' => "İstediğiniz grup bulunamadı veya buna erişiminiz yok.",
			
			'groups:requests:none' => 'Şu an göze çarpan bir üyelik başvurusu yok.',
	
			'item:object:groupforumtopic' => "Tartışma konuları",
	
			'groupforumtopic:new' => "Yeni tartışma gönderisi",
			
			'groups:count' => "yaratılmış gruplar",
			'groups:open' => "açık grup",
			'groups:closed' => "kapalı grup",
			'groups:member' => "üyeler",
			'groups:searchtag' => "Etiketlere göre grup ara",
	
			
			/*
			 * Access
			 */
			'groups:access:private' => 'Kapalı - Üyelikler davet ile olur.',
			'groups:access:public' => 'Açık - Herkes üye olabilir.',
			'groups:closedgroup' => 'Bu grupta kapalı üyelik vardır.. To ask to be added, click the "request membership" menu link.',
			'groups:visibility' => 'Bu grubu kimler görebilir?',
	
			/*
			   Group tools
			*/
			'groups:enablepages' => 'Grup sayfalarını etkinleştir',
			'groups:enableforum' => 'Grup tartışmalarını etkinleştir',
			'groups:enablefiles' => 'Grup dosyalarını etkinleştir',
			'groups:yes' => 'evet',
			'groups:no' => 'hayır',
	
			'group:created' => '%s tarafından %d gönderisiyle oluşturuldu',
			'groups:lastupdated' => 'Son güncellenme %s, %s tarafından',
			'groups:pages' => 'Grup sayfaları',
			'groups:files' => 'Grup dosyaları',
	
			/*
			  Group forum strings
			*/
			
			'group:replies' => 'Yanıtlar',
			'groups:forum' => 'Grup tartışması',
			'groups:addtopic' => 'Konu ekle',
			'groups:forumlatest' => 'Son forumlar',
			'groups:latestdiscussion' => 'Son tartışmalar',
			'groups:newest' => 'Yeniler',
			'groups:popular' => 'Popüler',
			'groupspost:success' => 'Yorumunuz başarıyla eklendi',
			'groups:alldiscussion' => 'Tüm tartışmalar',
			'groups:edittopic' => 'Konuyu düzenle',
			'groups:topicmessage' => 'Konu mesajı',
			'groups:topicstatus' => 'Konu durumu',
			'groups:reply' => 'Yorum yolla',
			'groups:topic' => 'Konu',
			'groups:posts' => 'Gönderiler',
			'groups:lastperson' => 'Son kişi',
			'groups:when' => 'Ne zaman',
			'grouptopic:notcreated' => 'Hiçbir konu oluşturulmadı.',
			'groups:topicopen' => 'Açık',
			'groups:topicclosed' => 'Kapalı',
			'groups:topicresolved' => 'Çözüldü',
			'grouptopic:created' => 'Konunuz oluşturuldu.',
			'groupstopic:deleted' => 'Konu silindi.',
			'groups:topicsticky' => 'Yapışkan',
			'groups:topicisclosed' => 'Konu kapatıldı.',
			'groups:topiccloseddesc' => 'Bu konu kapatıldı. Yeni yorum kabul edilmiyoru.',
			'grouptopic:error' => 'Grup konunuz oluşturulamadı. Lütfen tekrar deneyiniz veya yönetici ile iletişime geçiniz.',
			'groups:forumpost:edited' => "Forum gönderisini başarıyla düzenlediniz.",
			'groups:forumpost:error' => "Forum gönderisini düzenlemede bir hata oluştu.",
			'groups:privategroup' => 'Bu grup özeldir, üyelik gereklidir.',
			'groups:notitle' => 'Grupların başlığı olmalıdır',
			'groups:cantjoin' => 'Gruba katılınamadı',
			'groups:cantleave' => 'Gruptan çıkılamadı',
			'groups:addedtogroup' => 'Kullanıcı başarılı olarak gruba eklendi',
			'groups:joinrequestnotmade' => 'Giriş isteği yapılamadı',
			'groups:joinrequestmade' => 'Giriş isteği başarıyla yapıldı',
			'groups:joined' => 'Gruba başarıyla girildi!',
			'groups:left' => 'Grup başarıyla terkedildi',
			'groups:notowner' => 'Üzgünüz, bu grubun sahibi değilsiniz.',
			'groups:alreadymember' => 'Siz zaten bu grubun üyesisiniz!',
			'groups:userinvited' => 'Kullanıcı davet edildi.',
			'groups:usernotinvited' => 'Kullanıcı davet edilemedi.',
			'groups:useralreadyinvited' => 'Kullanıcı önceden davet edilmiş',
			'groups:updated' => "Son yorum",
			'groups:invite:subject' => "%s %s grubuna davet edildiniz!",
			'groups:started' => "Başlatan",
			'groups:joinrequest:remove:check' => 'Bu giriş isteğini kaldırmak istediğinizden emin misiniz?',
			'groups:invite:body' => "Merhaba %s,

  '%s' gurubuna davet edildiniz, aşağıdaki bağlantıya tıklayarak daveti onaylayabilirsiniz:

%s",

			'groups:welcome:subject' => "%s grubuna hoşgeldiniz!",
			'groups:welcome:body' => "Merhaba %s!
		
Artık '%s' grubunun üyesisiniz! Gönderi yapmak için aşağıdaki bağlantıya tıklayabilirsiniz!

%s",
	
			'groups:request:subject' => "%s adlı kullanıcı %s grubuna girmek için başvurdu.",
			'groups:request:body' => "Merhaba %s,

%s adlı kişi '%s' grubuna girmek için başvurdu, bu kişinin profilini görmek için aşağıdaki bağlantıya tıklayabilirsiniz:

%s

veya onaylamak için aşağıdaki bağlantıya tıklayabilirsiniz:

%s",
	
            /*
				Forum river items
			*/
	
			'groups:river:member' => 'adlı kişi artık bu grubun üyesi:',
			'groupforum:river:updated' => '%s güncellendi',
			'groupforum:river:update' => 'bu tartışma konusu',
			'groupforum:river:created' => '%s oluşturuldu',
			'groupforum:river:create' => 'yeni tartışma konu başlığı',
			'groupforum:river:posted' => '%s adlı kişi yeni yorum gönderdi.',
			'groupforum:river:annotate:create' => 'bu tartışma konusunda',
			'groupforum:river:postedtopic' => '%s adlı kişi bu konu başlığında yeni bir tartışma başlattı',
			'groups:river:member' => '%s adlı kişi artık bu grubun üyesi:',
	
			'groups:nowidgets' => 'Bu grup için herhangi bir widget belirlenmedi.',
	
	
			'groups:widgets:members:title' => 'Grup üyeleri',
			'groups:widgets:members:description' => 'Grup üyeleri listesi.',
			'groups:widgets:members:label:displaynum' => 'Gösterilecek grup üyesi sayısı.',
			'groups:widgets:members:label:pleaseedit' => 'Lütfen bu widgetı ayarlayınız.',
	
			'groups:widgets:entities:title' => "Gruptaki nesneler",
			'groups:widgets:entities:description' => "Bu grupta olan nesnelerin listesi",
			'groups:widgets:entities:label:displaynum' => 'Gösterilecek nesnelerin sayısı.',
			'groups:widgets:entities:label:pleaseedit' => 'Lütfen bu widgetı ayarlayınız.',
		
			'groups:forumtopic:edited' => 'Forum konusu başarıyla değiştirildi.',
	
			'groups:allowhiddengroups' => 'Özel (gizli) gruplara izin verilsin mi?',
	
			/**
			 * Action messages
			 */
			'group:deleted' => 'Grup ve grup içeriği silindi.',
			'group:notdeleted' => 'Grup silinemedi.',
	
			'grouppost:deleted' => 'Grup gönderileri başarıyla silindi.',
			'grouppost:notdeleted' => 'Grup gönderileri silinemedi.',
			'groupstopic:deleted' => 'Konu silindi.',
			'groupstopic:notdeleted' => 'Konu silinemedi',
			'grouptopic:blank' => 'Konu yok.',
			'groups:deletewarning' => "Bu grubu silmek istediğinize emin misiniz? Bunun geri dönüşü yoktur!",
	
			'groups:joinrequestkilled' => 'Giriş isteği silindi.',
	);
					
	add_translation("tr",$turkish);
?>