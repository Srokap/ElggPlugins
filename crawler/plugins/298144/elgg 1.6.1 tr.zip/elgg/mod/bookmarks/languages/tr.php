<?php

	$turkish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'bookmarks' => "Yerimleri",
			'bookmarks:add' => "Yerimlerine ekle",
			'bookmarks:read' => "%s adlı kişinin yerimleri",
			'bookmarks:friends' => "Arkadaşlarınızın yerimleri",
			'bookmarks:everyone' => "Tüm yerimleri",
			'bookmarks:this' => "Yerimlerine ekle",
			'bookmarks:this:group' => "%s yerimlerine eklendi",
			'bookmarks:bookmarklet' => "bookmarklet al",
			'bookmarks:bookmarklet:group' => "grup bookmarkletı al",
			'bookmarks:inbox' => "Yerimleri gelen kutusu",
			'bookmarks:more' => "Daha fazla",
			'bookmarks:shareditem' => "Yerimlerine eklenmiş nesneler",
			'bookmarks:with' => "Paylaş",
			'bookmarks:new' => "Yeni eklenmiş yerimi",
			'bookmarks:via' => "yerimleri ile",
			'bookmarks:address' => "Yerimi kaynağının adresi",
	
			'bookmarks:delete:confirm' => "Bu kaynağı silmek istediğinizden emin misiniz?",
	
			'bookmarks:numbertodisplay' => 'Gösterilen yerimi sayısı',
	
			'bookmarks:shared' => "Yerimlerine eklendi",
			'bookmarks:visit' => "Kaynağı ziyaret et",
			'bookmarks:recent' => "En son yerimleri",
	
			'bookmarks:river:created' => '%s yerimlerine eklendi',
			'bookmarks:river:annotate' => 'bu yerimine yorup yaptı.',
			'bookmarks:river:item' => 'bir nesne',
	
			'item:object:bookmarks' => 'Yerimlerine eklenen nesneler',
	
			'bookmarks:group' => 'Grup yerimleri',
			'bookmarks:enablebookmarks' => 'Grup yerimlerini etkinleştir',
	
	
		/**
		 * More text
		 */
		    
		    'bookmarks:widget:description' => 
		            "Bu widget panonuzda, son eklenen yerimleri ve nesneleri göstermeniz için tasarlandı.",
	
			'bookmarks:bookmarklet:description' =>
					"The bookmarks bookmarklet allows you to share any resource you find on the web with your friends, or just bookmark it for yourself. To use it, simply drag the following button to your browser's links bar:",

	        'bookmarks:bookmarklet:descriptionie' =>
					"If you are using Internet Explorer, you will need to right click on the bookmarklet icon, select 'add to favorites', and then the Links bar.",

			'bookmarks:bookmarklet:description:conclusion' =>
					"You can then save any page you visit by clicking it at any time.",
	
		/**
		 * Status messages
		 */
	
			'bookmarks:save:success' => "Yeriminiz başarıyla eklendi.",
			'bookmarks:delete:success' => "Yeriminiz başarıyla silindi.",
	
		/**
		 * Error messages
		 */
	
			'bookmarks:save:failed' => "Yeriminiz kaydedilemedi. Lütfen tekrar deneyiniz.",
			'bookmarks:delete:failed' => "Yeriminiz silinemedi. Lütfen tekrar deneyiniz.",
	
	
	);
					
	add_translation("tr",$turkish);

?>