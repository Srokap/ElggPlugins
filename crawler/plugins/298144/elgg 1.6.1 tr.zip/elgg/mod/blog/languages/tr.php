<?php

	$turkish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'blog' => "Blog",
			'blogs' => "Bloglar",
			'blog:user' => "%s adlı kişinin bloğu",
			'blog:user:friends' => "%s adlı kişinin arkadaşlarının bloğu",
			'blog:your' => "Bloğunuz",
			'blog:posttitle' => "%s adlı kişinin bloğu: %s",
			'blog:friends' => "Arkadaşlarının bloğu",
			'blog:yourfriends' => "Arkadaşlarının son blogları",
			'blog:everyone' => "Tüm bloglar",
			'blog:newpost' => "Yeni blog gönderileri",
			'blog:via' => "blog ile",
			'blog:read' => "Bluğu oku",
	
			'blog:addpost' => "Blog gönderisi yaz",
			'blog:editpost' => "Blog gönderisini değiştir",
	
			'blog:text' => "Blog text",
	
			'blog:strapline' => "%s",
			
			'item:object:blog' => 'Blog gönderileri',
	
			'blog:never' => 'hiçbir zaman',
			'blog:preview' => 'Önizleme',
	
			'blog:draft:save' => 'Taslak olarak kaydet',
			'blog:draft:saved' => 'Taslak kaydedildi',
			'blog:comments:allow' => 'Yorumlara izin ver',
	
			'blog:preview:description' => 'Blog gönderinizin kaydedilmemiş önizlemesidir.',
			'blog:preview:description:link' => 'Gönderinizi değiştirmeye veya kaydetmeye devam etmek için burayı tıklayınız.',
	
			'blog:enableblog' => 'Grup bloğunu etkinleştir',
	
			'blog:group' => 'Grup bloğu',
			
         /**
	     * Blog river
	     **/
	        
	        //generic terms to use
	        'blog:river:created' => "%s yazdı",
	        'blog:river:updated' => "%s güncellendi",
	        'blog:river:posted' => "%s gönderdi",
	        
	        //these get inserted into the river links to take the user to the entity
	        'blog:river:create' => "yeni blog gönderisi adlandırıldı",
	        'blog:river:update' => "bolg gönderisi adlandırıldı",
	        'blog:river:annotate' => "bu blog gönderisine bir yorum var",
			
	
		/**
		 * Status messages
		 */
	
			'blog:posted' => "Blog gönderiniz başarıyla eklendi.",
			'blog:deleted' => "Blog gönderiniz başarıyla silindi.",
	
		/**
		 * Error messages
		 */
	
			'blog:error' => 'Birşeyler ters gidiyor. Lütfen tekrar deneyiniz.',
			'blog:save:failure' => "Blog gönderiniz kaydedilemedi. Lütfen tekrar deneyiniz.",
			'blog:blank' => "Üzgünüz; göndermeden önce başlık ve gövde alanlarını doldurmanız gereklidir.",
			'blog:notfound' => "Üzgünüz; belirtilen blog gönderisi bulunamadı.",
			'blog:notdeleted' => "Üzgünüz; bu blog gönderisi silinemedi..",
	
	);
					
	add_translation("tr",$turkish);

?>