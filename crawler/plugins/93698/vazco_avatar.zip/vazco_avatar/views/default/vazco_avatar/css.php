.avatar_icon_container{
	height:100px;
}
.avatar_wrapper{
	height: 130px;
	width:100%;
}

#profile_picture_croppingtool .avatar_container{
	margin:15px 20px;
}

.avatar_delete_link{
	display:block;
}
.avatar_box{
	float:left;
	margin: 5px;
	width:110px;
	height:120px;
}

.avatar_container{
	margin: 15px 40px;
}