<?php
/**
 *	GENEALOGY PLUGIN
 *	@package genealogy
 *	@author Fernando Graells
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Fernando Graells 2009
 *	@link 
 **/
	 global $CONFIG;
	// Start engine
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	
	//Aseguramos la acci�n - Make sure action is secure
	gatekeeper();
	//action_gatekeeper();
	
	
	if ($user_guid = (int) get_input('guid')){
		$user = get_user($user_guid);
	} else {
		forward('pg/genealogy/world');
	}
	
	//add submenu options
	add_submenu_item(elgg_echo("members list"), $CONFIG->wwwroot . "pg/genealogy");
	add_submenu_item(elgg_echo("surnames list"), $CONFIG->wwwroot . "pg/genealogy/surnames");
	add_submenu_item(elgg_echo("descendants of ".$user->name), $CONFIG->wwwroot . "pg/genealogy/descendants/".$user_guid);
		
	$title = elgg_view_title(sprintf(elgg_echo('genealogy:familyparents'),$user->name.' '.$user->lastname.' '.$user->secondlastname));
	//$title = elgg_view_title(elgg_echo('genealogy:title'));
	
	// Format page
	//$body = elgg_view_layout('one_column', $title . elgg_view('genealogy/parents_tree', array('user'=>$userid)));
	$body = elgg_view_layout('two_column_left_sidebar', '',$title . elgg_view('genealogy/parents_tree', array('user'=>$user_guid)));
		
	// Draw it
	echo page_draw(elgg_echo('genealogy:title'),$body);



?>