<?php

	//global $CONFIG;
	// Start engine
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	
	//Aseguramos la acci�n - Make sure action is secure
	gatekeeper();
	//action_gatekeeper();
	
	
	//add submenu options
	add_submenu_item(elgg_echo("members list"), $CONFIG->wwwroot . "pg/genealogy/");
	add_submenu_item(elgg_echo("surnames list"), $CONFIG->wwwroot . "mod/genealogy/index.php?list=1");
	
	$users_max = 300; //temporal
	$users = get_entities('user','',null,null,$users_max,0);
	//$users = get_data("select a.guid from {$CONFIG->dbprefix}users_entity as a,{$CONFIG->dbprefix}entities as b  where a.guid =b.guid and b.enabled = 'yes'  order by a.name ASC");
	
	//set_context("genealogy");
	
	$autofeed = true;
	//shuffle($users); reorganiza aleatoriamente el array
	
	if (get_input('list',0) == 1){		
		$title = elgg_view_title(elgg_echo('genealogy:titlesurnames'));
		$list = 1;
	} else {
		$title = elgg_view_title(elgg_echo('genealogy:title'));
	}
	
	// Format page
	$body = elgg_view_layout('two_column_left_sidebar', '',$title . elgg_view('genealogy/list_users', array('users'=>$users, 'list'=>$list)));
		
	// Draw it
	echo page_draw(elgg_echo('genealogy:title'),$body);

?>