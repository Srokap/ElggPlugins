<?php
/**
 *	GENEALOGY PLUGIN
 *	@package genealogy
 *	@author Fernando Graells
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Fernando Graells 2009
 *	@link 
 **/
	 global $CONFIG;
	// Start engine
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	
	//Aseguramos la acci�n - Make sure action is secure
	gatekeeper();
	//action_gatekeeper();
	
	$limit = get_input('limit', 10);
	$offset = get_input('offset', 0);
	
	if ($surname = get_input('surname')){
	} else {
		forward('pg/genealogy/surnames');
	}
	
	//add submenu options
	add_submenu_item(elgg_echo("members list"), $CONFIG->wwwroot . "pg/genealogy");
	add_submenu_item(elgg_echo("surnames list"), $CONFIG->wwwroot . "pg/genealogy/surnames");
	
	//$title = elgg_view_title(sprintf(elgg_echo('genealogy:familyparents'),$user->name.' '.$user->lastname.' '.$user->secondlastname));
	$title = elgg_view_title($surname.' '.elgg_echo('genealogy:title'));
	
	$terms = array();
	$terms['lastname'] = $surname;
	$terms['secondlastname'] = $surname;
	
	//$users = get_entities_from_metadata_multi ($terms, 'user',"", 0, $limit=10, $offset=0,'', 0, false, $meta_array_operator= 'or'); error in elgg core
	//$count = get_entities_from_metadata_multi ($terms, 'user',"", 0, $limit=10, $offset=0,'', 0, true, $meta_array_operator= 'or'); error in elgg core
	$users = get_entities_from_metadata ('lastname',$surname, 'user',"",0, $limit=10, $offset,'',0, $count=false);
	$count = get_entities_from_metadata ('lastname',$surname, 'user',"",0, $limit=10, 0,'',0, true);
	
	
	$area1 = elgg_view_entity_list ($users, $count, $offset, $limit,true,true,true);
	
	// Format page
	$body = elgg_view_layout('two_column_left_sidebar', '',$title . $area1);
		
	// Draw it
	echo page_draw(elgg_echo('genealogy:title'),$body);



?>