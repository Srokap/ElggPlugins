<?php

/**
 	 * This view is overriden to display user's location on the listings properly. Make sure it don't interfere with your other customizations.
 	 * 
 	 *  
	 * @package Elgg
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Michal Zacher [michal.zacher@gmail.com]
	 * @remarks In case you need any help with this plugin, geocoding or reverse geocoding, please contact me and I may be able to help.
 */

		$icon = elgg_view(
				"profile/icon", array(
										'entity' => $vars['entity'],
										'size' => 'small',
									  )
			);
			
		$banned = $vars['entity']->isBanned();
	
		// Simple XFN
		$rel = "";
		if (page_owner() == $vars['entity']->guid)
			$rel = 'me';
		else if (check_entity_relationship(page_owner(), 'friend', $vars['entity']->guid))
			$rel = 'friend';
		
		if (!$banned) {
			if (get_context() == "genealogy"){
				
				// load genealogy model
				require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/models/model.php");
				
				$nameuser = htmlentities($vars['entity']->name, ENT_QUOTES, 'UTF-8').' '.$vars['entity']->lastname.' '.$vars['entity']->secondlastname;
				$info .= "<p><b><a href=\"" . $vars['entity']->getUrl() . "\" rel=\"$rel\">" . $nameuser . "</a></b>";
				
				$info .= " ".iconfamily($vars['entity']->guid, 'descendants', '');// draw if there are childrens
				$info .= " ".iconfamily($vars['entity']->guid, 'parents', '');// draw if there are parents
				
				$info .= "</p><p>";
				
				if ($vars['entity']->birthday) {
					$info .= personaldate($vars['entity']->birthday, 'born','F j, Y');
				}
				if ($vars['entity']->dieday) {
					$info .= " - ".personaldate($vars['entity']->dieday, 'death','F j, Y');
				}
				$info .= "</p>";
				
			} else {
				$info .= "<p><b><a href=\"" . $vars['entity']->getUrl() . "\" rel=\"$rel\">" . $vars['entity']->name . "</a></b></p>";
				//create a view that a status plugin could extend - in the default case, this is the wire
	 			$info .= elgg_view("profile/status", array("entity" => $vars['entity']));

				$location = $vars['entity']->location;
				if (!empty($location)) {
					//get address from user's metadata. If it's not there, get it from webservice and save to metadata.
					$info .= "<p class=\"owner_timestamp\">" . elgg_echo("profile:location") . ": " . elgg_view("output/tags",array('value' => $vars['entity']->location)) . "</p>";
				}
			}
		}
		else
		{
			$info .= "<p><b><strike>";
			if (isadminloggedin())
				$info .= "<a href=\"" . $vars['entity']->getUrl() . "\">";
			$info .= $vars['entity']->name;
			if (isadminloggedin())
				$info .= "</a>";
			$info .= "</strike></b></p>";
		
			//$info .= "<p class=\"owner_timestamp\">" . elgg_echo('profile:banned') . "</p>";
			
		}
		
		echo elgg_view_listing($icon, $info);
			
?>