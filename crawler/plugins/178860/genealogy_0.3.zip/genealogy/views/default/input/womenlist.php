<?php

	/**
	 * Elgg userlist input
	 * Displays a list of users
	 * 
	 * @package Elgg
	 * @subpackage plugin genealogy
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fernando Graells
	 * @copyright Fernando graells 2009
	 * @link 
	 * 
	 * @uses $vars['value'] The current value, if any
	 * @uses $vars['js'] Any Javascript to enter into the input tag
	 * @uses $vars['internalname'] The name of the input field
	 * @uses $vars['disabled'] If true then control is read-only
	 * @uses $vars['class'] Class override
	 */

	
	$class = $vars['class'];
	if (!$class) $class = "input-pulldown";

	//$users = get_entities('user','',null,null,'300',0);
	$users = get_data("select * from {$CONFIG->dbprefix}users_entity as a,{$CONFIG->dbprefix}entities as b  where a.guid =b.guid and b.enabled = 'yes'  order by a.name ASC");
	
		$rowwomen = array();
		foreach($users as $women){
			if (($women->guid != $_SESSION['guid']) || isadminloggedin()){		
				$allwomen = get_user($women->guid);
				if ((isset($allwomen->gender)) && ($allwomen->gender == 'F')){
					$name = $allwomen->name." ".$allwomen->lastname." ".$allwomen->secondlastname;
					if ($name == ""){	$name = $allwomen->username;	}
					$rowwomen[] = array('name' => $name, 'id' => $allwomen->guid);
				} elseif (!isset($allwomen->gender)){ 
				//	register_error(sprintf(elgg_echo('genealogy:unable_gender_field'), $allwomen->name)); it's say all the users without gender defined
				}
			} elseif (($women->guid != $_SESSION['guid']) && (!isset($allwomen->gender))){
					register_error(sprintf(elgg_echo('genealogy:unable_gender_field'), $allwomen->name));
			}
		} 
	
	function so2 ($a, $b) { return (strcmp ($a['name'],$b['name'])); } //orden alfabetico
?>


<select <?php if ($vars['disabled']) echo ' disabled="yes" '; ?> name="<?php echo $vars['internalname']; ?>" id="<?php echo $vars['internalname']; ?>" class="<?php echo $class ?>" >
<option value=""><?php echo elgg_echo('genealogy:desconegut') ?></option>
	<?php

		if ($rowwomen){
			uasort($rowwomen, 'so2'); //reorder by alpha
			foreach($rowwomen as $key => $val) {
				echo '<option value="' . $val['id'] . '"';
				if ($val['id'] == $vars['value']) {
					echo ' selected="selected"';
				}
				echo '>' . $val['name'] . '</option>' . chr(10);
			}
		
		}

	?>
</select>

<br />