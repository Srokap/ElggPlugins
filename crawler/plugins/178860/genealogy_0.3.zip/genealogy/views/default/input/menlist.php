<?php

	/**
	 * Elgg userlist input
	 * Displays a list of users
	 * 
	 * @package Elgg
	 * @subpackage plugin genealogy
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fernando Graells
	 * @copyright Fernando graells 2009
	 * @link 
	 * 
	 * @uses $vars['value'] The current value, if any
	 * @uses $vars['js'] Any Javascript to enter into the input tag
	 * @uses $vars['internalname'] The name of the input field
	 * @uses $vars['disabled'] If true then control is read-only
	 * @uses $vars['class'] Class override
	 */

	//global $CONFIG;
	
	$class = $vars['class'];
	if (!$class) $class = "input-pulldown";

	//$users = get_entities('user','',null,null,'300',0);
	$users = get_data("select * from {$CONFIG->dbprefix}users_entity as a,{$CONFIG->dbprefix}entities as b  where a.guid =b.guid and b.enabled = 'yes'  order by a.name ASC");
	
		$rowmen = array();
		foreach($users as $men){
			if (($men->guid != $_SESSION['guid']) || isadminloggedin()){
				$allmen = get_user($men->guid);
				if ((isset($allmen->gender)) && ($allmen->gender == 'M')){
					$name = $allmen->name." ".$allmen->lastname." ".$allmen->secondlastname;
					if ($name == ""){	$name = $allmen->username;	}
					$rowmen[] = array('name' => $name, 'id' => $allmen->guid);
				} elseif (!isset($allmen->gender)) {
					//register_error(sprintf(elgg_echo('genealogy:unable_gender_field'), $allmen->name)); it's say all the users without gender defined
				}
			} elseif (($men->guid != $_SESSION['guid']) && (!isset($allmen->gender))) {
					register_error(sprintf(elgg_echo('genealogy:unable_gender_field'), $allmen->name));
			}
		} 
	
	function so ($a, $b) { return (strcmp ($a['name'],$b['name'])); } //orden alfabetico
?>


<select <?php if ($vars['disabled']) echo ' disabled="yes" '; ?> name="<?php echo $vars['internalname']; ?>" id="<?php echo $vars['internalname']; ?>" class="<?php echo $class ?>" >
<option value=""><?php echo elgg_echo('genealogy:desconegut') ?></option>
	<?php
		if ($rowmen){
			uasort($rowmen, 'so'); //reorder by alpha
			foreach($rowmen as $key => $val) {
				echo '<option value="' . $val['id'] . '"';
				if ($val['id'] == $vars['value']) {
					echo ' selected="selected"';
				}
				echo '>' . $val['name'] . '</option>' . chr(10);
			}
		
		}

	?>
</select>

<br />