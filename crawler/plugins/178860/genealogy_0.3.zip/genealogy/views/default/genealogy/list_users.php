<div class='contentWrapper' align='center'>
<table border=0 width=100%>
<?php
global $CONFIG;

	foreach($vars['users'] as $user){
		$user = get_user($user->guid);
		$even_odd = ( 'FFFFFF' != $even_odd ) ? 'FFFFFF' : 'F3F3F3';
		
		
		$url = $user->getURL();
		$icon = $user->getIcon('topbar');
		
		echo "<tr bgcolor=\"#{$even_odd}\">";
		echo '<td>';
		echo '<img class="user_mini_avatar" src="'.$icon.'"><a href="'.$url.'"> ';
		echo htmlentities($user->name, ENT_QUOTES, 'UTF-8').' '.$user->lastname.' '.$user->secondlastname;
		echo '</a></td>';
		
		echo "<td>";
		if ($user->birthday) {
			echo gmdate("F j, Y", $user->birthday);
		}
		echo "</td><td> - </td><td>";
		if ($user->dieday) {
			echo gmdate("F j, Y", $user->dieday);
		}
		echo "</td>";
		
		//check if children with parameter true in get_entities_from_relationship
		if ((!get_entities_from_relationship('father', $user->guid, true)) && (!get_entities_from_relationship('mother', $user->guid, true))){
			echo "<td>&nbsp;</td>";
		} else {
			echo "<td><a href='".$CONFIG->url."pg/genealogy/descendants/".$user->guid."' title='".elgg_echo('genealogy:descendants')."'><img src=\"".$CONFIG->url."mod/genealogy/graphics/children.gif\" border=\"0\" /></a></td>";
		}
		// check if there are parents
		if ((!get_entities_from_relationship('father', $user->guid, false)) && (!get_entities_from_relationship('mother', $user->guid, false))){
			echo "<td>&nbsp;</td>";
		} else {
			echo "<td><a href='".$CONFIG->url."pg/genealogy/parents/".$user->guid."' title='".elgg_echo('genealogy:parents')."'><img src=\"".$CONFIG->url."mod/genealogy/graphics/parents.gif\" border=\"0\" /></a></td>";
		}
		echo "</tr>\n";

	}

?>
</table>
</div>

