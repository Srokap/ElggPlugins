<?php

?>

		<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/genealogy/wz_jsgraphics.js"></script>
		<!--[if IE]>
		<style type="text/css"> 
		/* place css fixes for all versions of IE in this conditional comment */
		.shadow{width: 185px;}
		</style>
		<![endif]-->
        
