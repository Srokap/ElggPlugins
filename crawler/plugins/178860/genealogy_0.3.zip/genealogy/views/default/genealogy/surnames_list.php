<div class="contentWrapper" align="center">
<table border="0" width="100%">
<?php
	if ($vars['surnames']){
		foreach($vars['surnames'] as $lastname){
			$even_odd = ( 'FFFFFF' != $even_odd ) ? 'FFFFFF' : 'F3F3F3';
			echo "<tr bgcolor=\"#{$even_odd}\"><td>";
			//echo "<a href=\"".$CONFIG->url."mod/form/search_results_simple.php?type=user&form_data[lastname]=".$lastname."\">".$lastname."</a></td></tr>";
			echo "<a href=\"".$CONFIG->url."pg/genealogy/surname/".$lastname."\">".$lastname."</a></td></tr>";
		}
	}

?>
</table>
</div>