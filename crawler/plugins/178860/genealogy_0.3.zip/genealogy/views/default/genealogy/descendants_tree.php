<div class='contentWrapper' align='center'>
<?php
// load genealogy model
require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/models/model.php");


//$i = 10;
//$line = "";
$height = 0;

function drawfamiliar($user,$type,$num){
	global $CONFIG;
	static $i = 10;
	static $h = 140;
	static $h2 = 140;
	$num == 0 ? $top = $i : $top = ($i+100);
	
	if ($type == 1){
		$class2 = "backblanco";
		$style = 'left:10px;';
	} elseif ($type == 2){
		$class2 = "backgris";
		$style = 'left:265px;';
		if ($num == 1){
			$line .= "jg.setColor(\"#999999\");".chr(10)."jg.drawPolyline(new Array(197, 226, 226, 256), new Array(40, 40, 140, 140));".chr(10);
			$line .= "jg.setColor(\"#000000\");".chr(10)."jg.drawPolyline(new Array(197, 221, 221, 256), new Array(35, 35, 135, 135));".chr(10);
			
		} else {
			$line .= "jg.setColor(\"#999999\");".chr(10)."jg.drawPolyline(new Array(226, 226, 256), new Array(".$h2.", ".($h+100).", ".($h+100)."));".chr(10);
			$line .= "jg.setColor(\"#000000\");".chr(10)."jg.drawPolyline(new Array(221, 221, 256), new Array(".($h2-5).", ".($h+95).", ".($h+95)."));".chr(10);
			$h = $h+100;
			$h2 = $h;
		}
	
	} elseif ($type == 3){
		$class2 = "backgris";
		$style = 'left:520px;';
		if ($num == 0){
			$line .= "jg.setColor(\"#999999\");".chr(10)."jg.drawPolyline(new Array(452, 511), new Array(".$h.", ".$h."));".chr(10);
			$line .= "jg.setColor(\"#000000\");".chr(10)."jg.drawPolyline(new Array(452, 511), new Array(".($h-5).", ".($h-5)."));".chr(10);
			
		} else {
			$line .= "jg.setColor(\"#999999\");".chr(10)."jg.drawPolyline(new Array(481, 481, 511), new Array(".$h.", ".($h+100).", ".($h+100)."));".chr(10);
			$line .= "jg.setColor(\"#000000\");".chr(10)."jg.drawPolyline(new Array(476, 476, 511), new Array(".($h-5).", ".($h+95).", ".($h+95)."));".chr(10);
			$h = $h+100;
		}
	}
	
	//if (!$top){ $top = 10;}
	$style .= ' top:'.$top.'px;';
	isset($user['birthday']) ? $birthday = personaldate($user['birthday'],'born','j-m-Y') : $birthday = "";
	isset($user['dieday']) ? $deathday = personaldate($user['dieday'],'death','j-m-Y') : $deathday = "";
	
	echo '<div class="boxuser" style="'.$style.'"><div class="shadow"><div id="contenido" class="content '.$class2.'">';
	echo '<p><img class="user_mini_avatar" src="'.$user['icon'].'"> <a href="'.$user['url'].'"><strong>'.$user['name'].'</strong></a><br/>';
	echo $birthday."<br/>";
	echo $deathday;
	$hasparents = checkparents($user['guid']);// check if there are parents
	$haschildrens = checkchildrens($user['guid']);// check if there are childrens
	
	if (($haschildrens == 1) || ($hasparents == 1)){
		print '<br/><span class="boxicons">';
		if ($hasparents == 1){
			echo iconfamily($user['id'], 'parents','2');
		}
		if ($haschildrens == 1){
			echo " ".iconfamily($user['id'], 'descendants','2');
		}
		print '</span>';
	}
	echo "</p></div></div></div>";
	$i = $top;
	$GLOBALS['height'] = $h;
	return $line;
	
}

//function so ($a, $b) { return (strcmp ($a['birthday'],$b['birthday'])); } //orden por nacimiento

function comparebirthday($x, $y){
 if ( $x['birthday'] == $y['birthday'] )
  return 0;
 else if ( $x['birthday'] < $y['birthday'] )
  return -1;
 else
  return 1;
}


$row = array();
$rowuser = array();
$rowchildren = array();
$rowchild2 = array();
$rowchild3 = array();

if ($vars['user']){
	$user = get_user($vars['user']);
	$name = htmlentities($user->name, ENT_QUOTES, 'UTF-8').' '.$user->lastname.' '.$user->secondlastname;
	$row = array('name' => $name, 'id' => $user->guid, 'type' => 1, 'birthday' => $user->birthday, 'dieday' => $user->dieday, 'url' => $user->getURL(), 'icon' => $user->getIcon('topbar'), 'gender'=> $user->gender);
	
	//search childrens
	if (isset($user->gender)){
		$user->gender == "M" ? $type = 'father' : $type = 'mother';
	}
	if($type){
		if ($rowchild = checkfamiliar($type,$user->guid,2,true)){
			uasort($rowchild, 'comparebirthday'); //sort by birthday
			$row['children'] = $rowchild;
			foreach ($rowchild as $rowchild2){
				$rowchild2['gender'] == "M" ? $type = 'father' : $type = 'mother';
				if ($rowchild = checkfamiliar($type,$rowchild2['id'],3,true)){
					uasort($rowchild, 'comparebirthday'); //sort by birthday
					$row['children'][$rowchild2['id']]['grandchildren']= $rowchild;
				}			
			}
		}
		//print'<div style="clear:both"></div>';
		echo '<div id="tree" align="left" class="relative">';
		
		if ($row['type'] == 1){
			drawfamiliar($row,1,0);
				
			//We draw the childrens, second level of the array
			$childrens = $row['children'];
			$numchild = 1;
			foreach ($childrens as $children){
				if ($children['type'] == 2){
					$script .= drawfamiliar($children,2,$numchild);
					$numchild++;
					
					//We draw the grandchildrens, third level of the array
					$grandchildrens = $children['grandchildren'];
					$numgrandchild = 0;
					foreach ($grandchildrens as $grandchildren){
						if ($grandchildren['type'] == 3){
							$script .= drawfamiliar($grandchildren,3,$numgrandchild);
							$numgrandchild++;
						}
					}
				}
			}
	
		}
		print "</div>";
		
	} else {
		register_error('el usuario especificado no tiene genero definido');
	}
	
}
	

?>

<script type="text/javascript">
<!--

function myDrawFunction()
{
<?php
	print $script;
?>
  jg.paint(); // draws, in this case, directly into the document
  height = <?php echo $GLOBALS['height']; ?>;
  el2 = document.getElementById("tree");
  if (!height){
	  height = 470;
  }
  document.getElementById("tree").style.height=height + 40 +"px";
}

var jg = new jsGraphics("tree");

myDrawFunction();

//-->
</script>
</div>