.boxuser{
	position:absolute;
	display:inline;/*hace que la caja se limite al contenido y no al 100% de ancho pantalla */
}
.userbox, .fatherbox, .motherbox, .grandfather1box, .grandmother1box, .grandfather2box, .grandmother2box{
	position:absolute;
	display:inline;/*hace que la caja se limite al contenido y no al 100% de ancho pantalla */
}
.relative p{
	width:195px;/*hace que explorer 7 haga todas las cajas de este ancho */
}
.userbox{
	top: 197px;
	left: 520px;/* el top y left posiciona la caja correctamente con sombra y todo*/
}
.fatherbox{
	top:72px;
	left:265px;/* el top y left posiciona la caja correctamente con sombra y todo*/
}
.motherbox{
	top:322px;
	left:265px;/* el top y left posiciona la caja correctamente con sombra y todo*/
}
.grandfather1box{
	top:10px;
	left:10px;/* el top y left posiciona la caja correctamente con sombra y todo*/
}
.grandmother1box{
	top:135px;
	left:10px;/* el top y left posiciona la caja correctamente con sombra y todo*/
}
.grandfather2box{
	top:260px;
	left:10px;/* el top y left posiciona la caja correctamente con sombra y todo*/
}
.grandmother2box{
	top:385px;
	left:10px;/* el top y left posiciona la caja correctamente con sombra y todo*/
}

.shadow,.content{
	position: relative;
	bottom: 4px;
	right: 4px;
    -webkit-border-radius: 8px;
    -moz-border-radius: 8px;
}
.shadow{
	background-color: #999; /*shadow color*/
	color: inherit;
	width: 195px;/* controla el ancho del contenido y de la sombra*/
	/*height: 73px;no añadir height aqui*/
}

.content{
	/*background-color: #fff; background color of content*/
	/*color: #000; text color of content*/
	border: 1px solid #000; /*border color*/
	font-size:11px;
	padding:5px;
	/*width: 190px; este width desajusta la sombra y la caja*/
	height: 65px; /*este height hace que la caja incluya todo el contenido */
}
.backblanco{
	background-color: #fff;
}
.backgris{
	background-color: #ccc;
}
.contentWrapper{
	height:100%;
}
.relative{
	position:relative;
    min-height: 470px;/*con el height se amplia el alto de la zona blanca de elgg*/
}
.boxicons{
	float:right;
    margin-right:10px;
}
