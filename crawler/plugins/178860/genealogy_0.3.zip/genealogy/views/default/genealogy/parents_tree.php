<div class='contentWrapper' align='center'>
<?php
// load genealogy model
require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/models/model.php");

$row = array();
$row2 = array();
$row3 = array();

if ($vars['user']){
	$user = get_user($vars['user']);
	$name = htmlentities($user->name, ENT_QUOTES, 'UTF-8').' '.$user->lastname.' '.$user->secondlastname;
	$row['user'] = array('name' => $name, 'id' => $user->guid, 'type' => 'user', 'birthday' => $user->birthday, 'dieday' => $user->dieday, 'url' => $user->getURL(), 'icon' => $user->getIcon('topbar'));
	//check for father
	if ($row2 = checkfamiliar('father',$user->guid,'father',false)){
		$father = $row2['id'];
		$row['father'] = $row2;
		//check for father's grandfather
		if ($grandfather1 = checkfamiliar('father',$father,'grandfather1',false)){
			$row['grandfather1'] = $grandfather1;
		}
		//check for father's grandmother
		if ($grandmother1 = checkfamiliar('mother',$father,'grandmother1',false)){
			$row['grandmother1'] = $grandmother1;
		}
	}

	//check for mother
	if ($row3 = checkfamiliar('mother',$user->guid,'mother',false)){
		$mother = $row3['id'];
		$row['mother'] = $row3;
		//check for mother's grandfather
		if ($grandfather2 = checkfamiliar('father',$mother,'grandfather2',false)){
			$row['grandfather2'] = $grandfather2;
		}
		//check for mother's grandmother
		if ($grandmother2 = checkfamiliar('mother',$mother,'grandmother2',false)){
			$row['grandmother2'] = $grandmother2;
		}
	}
	
	print'<div style="clear:both"></div>';
	echo '<div id="tree" align="left" class="relative">';
	
	foreach($row as $userdata){
		isset($userdata['birthday']) ? $birthday = personaldate($userdata['birthday'],'born','j-m-Y') : $birthday = "";
		isset($userdata['dieday']) ? $deathday = personaldate($userdata['dieday'],'death','j-m-Y') : $deathday = "";
		
		if ($userdata['type'] == "user"){
			echo '<div class="userbox"><div class="shadow"><div class="content backblanco">';
			echo '<p><strong><img class="user_mini_avatar" src="'.$userdata['icon'].'"> <a href="'.$userdata['url'].'">'.$userdata['name'].'</a></strong><br/>';
    		echo $birthday."<br/>";
			echo $deathday;
	
		} else {
			
			echo '<div class="'.$userdata['type'].'box"><div class="shadow"><div class="content backgris">';
			echo "<p>";
			if ($userdata['id'] == 0) {
				echo "<strong>".elgg_echo('genealogy:unknown')."</strong>";
			} else {
				echo '<img class="user_mini_avatar" src="'.$userdata['icon'].'"><a href="'.$userdata['url'].'"><strong> '.$userdata['name'].'</strong></a><br/>';
				echo $birthday."<br/>";
				echo $deathday;
				
				$hasparents = checkparents($userdata['id']);// check if there are parents
				$haschildrens = checkchildrens($userdata['id']);// check if there are childrens
	
				if (($haschildrens == 1) || ($hasparents == 1)){
					print '<br/><span class="boxicons">';
					if ($hasparents == 1){
						echo iconfamily($userdata['id'], 'parents','2');
					}
					if ($haschildrens == 1){
						echo " ".iconfamily($userdata['id'], 'descendants','2');
					}
					print '</span>';
				}
			}
		}
		
		echo "</p></div></div></div>";
	}
	
	
?>
<script type="text/javascript">
<!--


function myDrawFunction()
{
  jg.setColor("#999999");//father-grandfather1-grandmother1 grey
  jg.drawPolyline(new Array(256, 226, 226, 197), new Array(102, 102, 40, 40));
  jg.drawPolyline(new Array(226, 226, 197), new Array(102, 164, 164));
  jg.setColor("#000000");//father-grandfather1-grandmother1 black
  jg.drawPolyline(new Array(256, 221, 221, 197), new Array(97, 97, 35, 35));
  jg.drawPolyline(new Array(221, 221, 197), new Array(97, 159, 159));
  jg.setColor("#999999");//father-grandfather2-grandmother2 grey
  jg.drawPolyline(new Array(256, 226, 226, 197), new Array(352, 352, 290, 290));
  jg.drawPolyline(new Array(226, 226, 197), new Array(352, 414, 414));
  jg.setColor("#000000");//father-grandfather2-grandmother2 black
  jg.drawPolyline(new Array(256, 221, 221, 197), new Array(347, 347, 285, 285));
  jg.drawPolyline(new Array(221, 221, 197), new Array(347, 409, 409));
  jg.setColor("#999999"); //user-father-mother grey
  jg.drawPolyline(new Array(511, 481, 481, 452), new Array(227, 227, 102, 102));
  jg.drawPolyline(new Array(481, 481, 452), new Array(227, 352, 352));
  jg.setColor("#000000"); //user-father-mother black
  jg.drawPolyline(new Array(511, 476, 476, 452), new Array(222, 222, 97, 97));
  jg.drawPolyline(new Array(476, 476, 452), new Array(222, 347, 347));
  jg.paint(); // draws, in this case, directly into the document

}


var jg = new jsGraphics("tree");

myDrawFunction();

//-->
</script> 

<?php		

	echo "</div>";
} else {
	register_error('genealogy:senseusuari');
	forward('pg/genealogy/');
}

?>
</div>

