<?php

	global $CONFIG;
	// Start engine
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	
	//Aseguramos la acci�n - Make sure action is secure
	gatekeeper();
	
	$limit = get_input('limit', 20);
	$offset = get_input('offset', 0);
	
	
	
	$users = get_data("select a.guid from {$CONFIG->dbprefix}users_entity as a,{$CONFIG->dbprefix}entities as b  where a.guid =b.guid and b.enabled = 'yes' order by a.name ASC limit {$offset},{$limit}");
	$users2 = get_data("select a.guid from {$CONFIG->dbprefix}users_entity as a,{$CONFIG->dbprefix}entities as b  where a.guid =b.guid and b.enabled = 'yes' order by a.name ASC");
	$count=count($users2);
	
	//add submenu options
	add_submenu_item(elgg_echo("members list"), $CONFIG->wwwroot . "pg/genealogy");
	add_submenu_item(elgg_echo("surnames list"), $CONFIG->wwwroot . "pg/genealogy/surnames");
	
	//$users_max = 300; //temporal
	//$users = get_entities('user','',null,null,$users_max,0);
	
	
	set_context("genealogy");
	
	$autofeed = true;
	//shuffle($users); reorganiza aleatoriamente el array
	
	$title = elgg_view_title(elgg_echo('genealogy:title'));
	
	//prueba
		//$area1 = list_entities ($type="user", $subtype="", $owner_guid=0, $limit=15, $fullview=true, $viewtypetoggle=false, $pagination=true);
	if ($count > $limit){
		$pagination = elgg_view('navigation/pagination',array('baseurl' => $_SERVER['REQUEST_URI'], 'offset' => $offset, 'count' => $count, 'limit' => $limit));
	} else {
		$pagination = "";
	}	
	
	// Format page
	$area2 = $title.$pagination.elgg_view('genealogy/list_users', array('users'=>$users)).$pagination;
	$body = elgg_view_layout('two_column_left_sidebar', '',$area2.$area1);
		
	// Draw it
	echo page_draw(elgg_echo('genealogy:title'),$body);

?>