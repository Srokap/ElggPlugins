<?php

/*
 * 
 * In case you want to add some additional fields from this list to Elgg's forms plugin, please contact me at michal.zacher@gmail.com
 * 
form_custom_field_type_manager(
	//type	
		'birthdate',
	//label
		elgg_echo('form:profile_birthdate_label'),
	//input_view
		'input/birthdate', //form/input/shorttext
	//output view
		'output/birthdate'
);

*/
form_custom_field_type_manager(
	//type	
		'date',
	//label
		elgg_echo('genealogy:profile_birthdate_label'),
	//input_view
		'input/date',
	//output view
		'output/fecha'
);
form_custom_field_type_manager(
	//type	
		'menusers',
	//label
		elgg_echo('genealogy:men_list_label'),
	//input_view
		'input/menlist',
	//output view
		'output/parent'
);
form_custom_field_type_manager(
	//type	
		'womenusers',
	//label
		elgg_echo('genealogy:women_list_label'),
	//input_view
		'input/womenlist',
	//output view
		'output/parent'
);
?>