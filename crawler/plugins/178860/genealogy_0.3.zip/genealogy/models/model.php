<?php

function checkparents($id){
	if ((!get_entities_from_relationship('father', $id, false)) && (!get_entities_from_relationship('mother', $id, false))){
		return 0;
	} else {
		return 1;
	}
}
function checkchildrens($id){
	if ((!get_entities_from_relationship('father', $id, true)) && (!get_entities_from_relationship('mother', $id, true))){
		return 0;
	} else {
		return 1;
	}
}

function iconfamily($id,$type,$graph){
	global $CONFIG;
	$icon = "";
	$text = "genealogy:".$type;
	if ($type == "parents"){
		$basegenealogy = checkparents($id);
	} else if ($type == "descendants") {
		$basegenealogy = checkchildrens($id);
	}
	if ($basegenealogy){
		$result = "<a href='".$CONFIG->url."pg/genealogy/$type/$id' title='".elgg_echo($text)."'><img src=\"".$CONFIG->url."mod/genealogy/graphics/$type$graph.gif\" border=\"0\" /></a>";
	}
	return $result;
}

function personaldate($date,$type,$dateformat){
	global $CONFIG;
	$result = "";
	$text = "genealogy:".$type;
	$date = gmdate("$dateformat", $date);
	$result = "<img src=\"".$CONFIG->url."mod/genealogy/graphics/$type.gif\" alt=\"".elgg_echo($text)."\" border=\"0\" /> ".$date;
	
	return $result;
}


function createuser($user,$familytype,$guid){
	$name = htmlentities($user->name, ENT_QUOTES, 'UTF-8').' '.$user->lastname.' '.$user->secondname;
	isset($user->birthday) ? $birthday = $user->birthday : $birthday = "";
	isset($user->dieday) ? $dieday = $user->dieday : $dieday = "";
	$rowuser = array('name' => $name, 'id' => $user->guid, 'type' => $familytype, 'birthday' => $birthday, 'dieday' => $dieday, 'url' => $user->getURL(), 'icon' => $user->getIcon('topbar'), 'parent' => $guid, 'gender'=> $person->gender);
	
	return $rowuser;
}


function checkfamiliar($type,$guid,$familytype,$child){
	$rowuser = array();	
	if (($guid != 0) && ($users = get_entities_from_relationship($type, $guid, $child))){
		if (!$child) {
			if ($person = get_user($users[0]['guid'])){
				$rowuser = createuser($person,$familytype,$guid);
			}
		} else{
			foreach ($users as $children){
				if ($person = get_user($children->guid)){
					$rowuser[$person->guid] = createuser($person,$familytype,$guid);
				}
			}
		}
	} else {
		if(!$child){
			$rowuser = array('id' => '0', 'type' => $familytype);
		} else {
			return false;
		}
	}
	return $rowuser;
}

?>