<?php

	/**
	 * Elgg Genealogy Plugin
	 * 
	 * @package MyHtml
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author DFernando Graells ferg
	 * @copyright Fernando Graells 2009
	 * @link 
	 * 
	 */
	
		function genealogy_init() {
		global $CONFIG;
	
		add_menu(elgg_echo('genealogy:shorttitle') , $CONFIG->wwwroot . "pg/genealogy");
		
		// Register a page handler, so we can have nice URLs
		register_page_handler('genealogy','genealogy_page_handler');
		
		// Register URL handler
		//register_entity_url_handler('genealogy_url','object', 'genealogy');
		
		
		//extend form fields
		require_once(dirname(__FILE__) . "/models/field_types_extended.php");
		
   		//add a widget
			 //add_widget_type('today_celebrations',elgg_echo("today_celebrations:title"),elgg_echo("today_celebrations:description"));
		}
		
		//add to the css
		extend_view('css', 'genealogy/css');
		

		
		function genealogy_page_handler($page){
			global $CONFIG;
			if (isset($page[0])) {
				switch($page[0]) {
					case "surnames":
						include($CONFIG->pluginspath . "genealogy/surnames.php");
					break;

					case "descendants":
						if (isset($page[1])) set_input('guid',$page[1]);
						extend_view('metatags','genealogy/metatags');
						include($CONFIG->pluginspath . "genealogy/descendantstree.php");
					break;

					case "parents":
						if (isset($page[1])) set_input('guid',$page[1]);
						extend_view('metatags','genealogy/metatags');
						include($CONFIG->pluginspath . "genealogy/parentstree.php");
					break;

					case "surname":
						if (isset($page[1])) set_input('surname',$page[1]);
						include($CONFIG->pluginspath . "genealogy/searchsurnames.php");
					break;
					
					default:
						include($CONFIG->pluginspath . "genealogy/index.php");

				}
			} else{
				// going to the index because something is wrong with the page handler 
				include($CONFIG->pluginspath . "genealogy/index.php"); 
			}			
		}
		
		/*function genealogy_url($entity) {		
			global $CONFIG;		
			return $CONFIG->url . 'pg/genealogy/view/'.$entity->getGUID();		
		}*/
	
	
		
		function profile_update_genealogy($event, $object_type, $object){
			global $CONFIG;
			include_once($CONFIG->pluginspath . "genealogy/actions/add.php");
				//if (($event == 'profileupdate') || (($event == 'create') && ($object_type == 'user'))){
					//system_message(sprintf('el objeto padre ES'.$object->father));
					if (isset($object->father) && ($object->father != "")){
						addparents($object->guid, father, $object->father);
						
					} 
					if (isset($object->mother) && ($object->mother != "")){
						addparents($object->guid, mother, $object->mother);
					}
					if (($object->father == "") || ($object->mother == "")){
						if ($object->father == ""){
							deleteparents($object->guid, "father");
						} else if ($object->mother == ""){
							deleteparents($object->guid, "mother");
						}
					}
					//$username = $entity->username;
				//}
			return true;
			
				
		
		}
		
		register_elgg_event_handler('init','system','genealogy_init');
		register_elgg_event_handler('profileupdate','user','profile_update_genealogy');
		
		

		
		
		//Acciones - Actions
		//register_action("genealogy/add",false,$CONFIG->pluginspath . "genealogy/actions/add.php");


?>