<?php
/**
 *	GENEALOGY PLUGIN
 *	@package genealogy
 *	@author Fernando Graells
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Fernando Graells 2009
 *	@link 
 **/

//Aseguramos la acción - Make sure action is secure
gatekeeper();
//action_gatekeeper();

function addparents($user_guid, $type, $parent_guid){
			if (!check_entity_relationship($parent_guid, $type, $user_guid)) {
				deleteparents($user_guid, $type);
				if (!get_entities_from_relationship($type, $user_guid, false)){
						add_entity_relationship($user_guid,$type,$parent_guid);
				}
			}
	
}

function deleteparents($user_guid, $type){
	$numparents = get_entities_from_relationship($type, $user_guid, false);
	$actiondel = "true";
	if ($numparents){
		foreach ($numparents as $parent){
			$result = remove_entity_relationship($user_guid, $type, $parent->guid);
			if($result == false) {
				$actiondel = "false";
				register_error(sprintf(elgg_echo('genealogy:unable_delete_parent'), $parent->guid));
			}
		}
	}
	return $actiondel;
}
?>