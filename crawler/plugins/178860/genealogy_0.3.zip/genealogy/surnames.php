<?php

	global $CONFIG;
	// Start engine
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	
	//Aseguramos la acci�n - Make sure action is secure
	gatekeeper();
	
	$limit = get_input('limit', 20);
	$offset = get_input('offset', 0);
	
	
	$users = get_data("select a.guid from {$CONFIG->dbprefix}users_entity as a,{$CONFIG->dbprefix}entities as b  where a.guid =b.guid and b.enabled = 'yes' order by a.name ASC");
	
	//add submenu options
	add_submenu_item(elgg_echo("members list"), $CONFIG->wwwroot . "pg/genealogy");
	add_submenu_item(elgg_echo("surnames list"), $CONFIG->wwwroot . "pg/genealogy/surnames");
	
	
	set_context("genealogy");
	
	$autofeed = true;
	//shuffle($users); reorganiza aleatoriamente el array
	$title = elgg_view_title(elgg_echo('genealogy:titlesurnames'));
	

	$surname = array();
	foreach($users as $user){
		$user = get_user($user->guid);
		$surname[] = $user->lastname;
	}
	$result = array_unique($surname);
	asort($result);
	$count = count($result);
	
	// Re-index:
	$result = array_values($result);
	$resultfilter = array();
	($offset+$limit) < $count ? $totalsurnames = $offset+$limit : $totalsurnames = $count;
	for ($i = $offset; $i < $totalsurnames; $i++) {
	    $resultfilter[] = $result[$i];
	}
	
	if ($count > $limit){
		$pagination = elgg_view('navigation/pagination',array('baseurl' => $_SERVER['REQUEST_URI'], 'offset' => $offset, 'count' => $count, 'limit' => $limit));
	} else {
		$pagination = "";
	}
	
	// Format page
	$area1 = $title.$pagination.elgg_view('genealogy/surnames_list', array('surnames' => $resultfilter)).$pagination;
	$body = elgg_view_layout('two_column_left_sidebar', '',$area1);
		
	// Draw it
	echo page_draw(elgg_echo('genealogy:title'),$body);

?>