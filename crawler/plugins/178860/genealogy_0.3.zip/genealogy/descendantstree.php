<?php
/**
 *	GENEALOGY PLUGIN
 *	@package genealogy
 *	@author Fernando Graells
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Fernando Graells 2009
 *	@link 
 **/

	 global $CONFIG;
	// Start engine
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	
	//Aseguramos la acci�n - Make sure action is secure
	gatekeeper();
	
	if ($user_guid = (int) get_input('guid')){
		$user = get_user($user_guid);
	} else {
		forward('pg/genealogy/world');
	}
	
	
	//add submenu options
	add_submenu_item(elgg_echo("members list"), $CONFIG->wwwroot . "pg/genealogy");
	add_submenu_item(elgg_echo("surnames list"), $CONFIG->wwwroot . "pg/genealogy/surnames");
	add_submenu_item(elgg_echo("parents of ".$user->name), $CONFIG->wwwroot . "pg/genealogy/parents/".$user_guid);
	
	$title = elgg_view_title(sprintf(elgg_echo('genealogy:familydescendants'),$user->name.' '.$user->lastname.' '.$user->secondlastname));
	
	// Format page
	$body = elgg_view_layout('two_column_left_sidebar', '', $title . elgg_view('genealogy/descendants_tree', array('user'=>$user_guid)));
		
	// Draw it
	echo page_draw(elgg_echo('genealogy:title'),$body);



?>