<?php
	$english = array(
		/**
		 * Genealogy details
		 */

		// pagina
			'genealogy:title' => "Family members",
			'genealogy:titlesurnames' => "Surnames list",
			'genealogy:shorttitle' => "Genealogy tree",
			'genealogy:familydescendants' => "%s family descendants",
			'genealogy:familyparents' => "%s family parents",
			
		
		// widget
	        
			
			/* Form fields */
	        'genealogy:desconegut' => "undefined",
	        'genealogy:men_list_label' => "men",
	        'genealogy:women_list_label' => "women",
	        'genealogy:profile_birthdate_label' => "Date (dd/mm/yyyy)",
			
			/* errors */
			'genealogy:unable_gender_field' => "Add the field gender to %s profile, please",
			'genealogy:unable_delete_parent' => "Unable to delete user %s relationships",
			
			/* list users */
			'genealogy:parents' => "Parents",
			'genealogy:descendants' => "Childrens",
			
			/* genealogy tree */
			'genealogy:senseusuari' => "User undefined",
			'genealogy:unknown' => "Unknown",
			'genealogy:born' => "Birthday",
	        'genealogy:santo' => "Feast Day",
	        'genealogy:death' => "Dieday",
			
			
			/* Month name */
			"month:1" => "January",
			"month:2" => "February",
			"month:3" => "March",
			"month:4" => "April",
			"month:5" => "May",
			"month:6" => "June",
			"month:7" => "July",
			"month:8" => "Agoust",
			"month:9" => "September",
			"month:10" => "October",
			"month:11" => "November",
			"month:12" => "December"
			
			
	);
	add_translation("en",$english);



?>