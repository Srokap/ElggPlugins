<?php
/*function print_array($var) {
	$var = $var['config'];
	$var = $var->input;
	//print_r($var);
	$title = $var['newtitle'];
	//echo "<p> TITLE: $title";
//	foreach ($var as $v => $val) {
	//		echo "<p><p>$v"; print_r($val); 
		//}
	//}
	//print_r($var);
/*	echo "&nbsp;";
	if (is_array($var)) {
		foreach ($var as $v) {
			print_array($v);
		}
	} else {
		echo "var: $var<br>"; 
	}
	*/
	

//	print_r($v);//
//}

/*foreach ($vars as $var) {
	echo "<p>$var:"; print_r($var);
}*/
//print_r($_GET);

//print_array($vars);
$var = $vars['config'];
$var = $var->input;
$title = $var['newtitle'];
$title = urldecode($title);
 
if ($title != '') {
?>
	<script language="javascript">
    //document.getElementById("title").value = "TEST";
    $('[name="title"]').val(<?php echo "\"$title\""; ?>);
    //alert('test');
    </script>
<?php
}
?>
