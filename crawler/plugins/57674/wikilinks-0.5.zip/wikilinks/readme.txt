/**
	 * Wiki Links
	 * 
	 * @package wikilinks
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Jussi Ahtikari / Intunex oy
	 * @copyright Intunex 2009
	 * @link http://www.intunex.fi/
*/


Install: 
1) Drop mod into the mod directory


/* Not needed
2) Modify mod/pages/view.php:
	Add the following row after row 21
	trigger_elgg_event('pages:load', $pages->type, $pages);
	
	old code:
	$pages = get_entity($page_guid);
	if (!$pages) forward();
	
	new code:
	$pages = get_entity($page_guid);
	trigger_elgg_event('pages:load', $pages->type, $pages);
	if (!$pages) forward();
*/


