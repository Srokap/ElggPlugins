<?php

	/**
	 * Wikilinks
	 * Functions for searching correct objects from database
	 * 
	 * @package wiklinks
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Jussi Ahtikari / Intunex 
	 * @copyright Intunex 2009
	 * @link http://www.intunex.fi/
	 */
	

	/**
	 * Return the page that has given title. If many pages
	 * have the same title returns the first one.
	 * 
	 * @param String $title
	 */
	function get_page_by_title($title)
	{
		global $CONFIG;
		
//		$guid = (int)$guid;
		
		/*$row = retrieve_cached_entity_row($guid);
		if ($row)
		{
			// We have already cached this object, so retrieve its value from the cache
			if (isset($CONFIG->debug) && $CONFIG->debug)
				error_log("** Retrieving sub part of GUID:$guid from cache");
				
			return $row;
		}
		else
		{*/
			$sql = "SELECT * from {$CONFIG->dbprefix}objects_entity where title='$title'";
			//echo $sql;
			$data_array = get_data($sql);
			return $data_array[0];
		//}
	}
	
?>	