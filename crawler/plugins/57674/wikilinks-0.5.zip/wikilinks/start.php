<?php

	/**
	 * Wiki links
	 * 
	 * @package wikilinks
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Jussi Ahtikari / Intunex 
	 * @copyright Intunex 2009
	 * @link http://www.intunex.fi/
	 */
	 
	 global $CONFIG;


	/**
	 * Profile init function; sets up the profile functions
	 *
	 */
	function wikilinks_init() {

		// Extend view that is used to create new page
		extend_view('forms/pages/edit', 'wikilinks/pages_new');
	}
		
	/**
	 * Return the page that has given title. If many pages
	 * have the same title returns the first one.
	 * 
	 * @param String $title
	 */
	function get_page_by_title($title)
	{
		global $CONFIG;
		$data_array = get_data("SELECT * from {$CONFIG->dbprefix}objects_entity where title='$title'");
		return $data_array[0];
	}	
	
	/**
	 * Creates a html link based on wiki link. For example, if parameter
	 * is [[test]]�this would find a page called 'test' and would return 
	 * a link to it, something like <a href="http://localhost/elgg/pg/pages/view/7/">test</a> 
	 * @param String $wiki_link A like, for example [[test]] that is replaced with html link
	 * @param $current_page_guid Page where we are linking from. Needed as parent page if a new page is linked.
	 */
	function create_html_link($wiki_link, $source_page_guid) {
	
		global $CONFIG;
	
		// $wiki_link is something like: [[competence management | See a link to competence management]]
		
	
		// 1. Remove [[ and ]] so the result will be: competence management | See a link to competence management
		$link = str_replace('[[', '', $wiki_link);
		$link = str_replace(']]', '', $link);
		
		// 2. Split possible page name and text, for example $parts[0]�would be 'competence management' and 
		// $parts[1] would be 'See a link to competence management'
		$link_parts = explode('|', $link);
		$title = $link_parts[0]; // for example: competence management
		$link_text = $link_parts[1]; // for example: See a link to competence management
		if ($link_text == '') {
			$link_text = $title; // default value
		}
		
		// 3. Find page based on link
		$page = get_page_by_title($title);
		$page_url = get_entity_url($page->guid); 
		
		
		
		// 4. Check if page is found, check style and link if it is not found
		$link_text_html = $link_text;
		if ($page == null)  {
			// Find source page information
			$source = get_entity($source_page_guid);
		
			$link_text_html = "<font color=\"red\">$link_text</font>"; // TODO: replace this with css styles
			$page_url = $CONFIG->wwwroot . "/pg/pages/new/?parent_guid=$source->guid&container_guid=$source->container_guid&newtitle=" . urlencode($link_text);
		}
		
		
		// 5. Replace wiki expression with html link
		$html_link = "<a href=\"$page_url\">$link_text_html</a>";
		return $html_link;
	}
		
	/**
	 * This function loads a set of default fields into the profile
	 *
	 */
	function wikilinks_render($hook, $entity_type, $returnvalue, $params)
	{
		global $CONFIG;
		
		if (isset($params['view']) && $params['view'] == 'output/longtext') {
		
			// Get current page we are linking from
			$page_guid = $_GET['page']; // something like "view/8/"
			$page_guid = str_replace('view', '', $page_guid); // something like "/8/"
			$page_guid = str_replace('/', '', $page_guid); // something like "8"
			
		
			// Find all wiki links (something like [[text]]) from the text
			$links = array();
			preg_match_all('/\[\[.+]]/U', $returnvalue, $links);
			foreach ($links[0] as $wiki_link) {
				$returnvalue = str_replace($wiki_link, create_html_link($wiki_link, $page_guid), $returnvalue);	
			}
			
		}		
		return $returnvalue;
	}
		


	register_elgg_event_handler('init','system','wikilinks_init',1);
		

	// Register our plugin hook to setup our profile fields
	register_plugin_hook('display', 'view', 'wikilinks_render', 900);
		

?>