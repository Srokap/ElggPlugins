@CHARSET "UTF-8"; 
.messageboxok {
	margin: 0 0 0 412px;
	width: 250px;
	height: auto;
	border: 1px solid #218534;
	background: #b9dec0;
	color: #218534;
	position: absolute;
	font-family: Times, Thoma, Futura;

}
.messageboxerror {
	margin: 0 0 0 412px;
	width: 250px;
	height: auto;
	border: 1px solid #b82c2c;
	background: #ffc6c6;
	color: #b82c2c;
	position: absolute;	
	font-family: Times, Thoma, Futura;
	
}