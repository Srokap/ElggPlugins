//popup message
//SETTING UP OUR POPUP  
//0 means disabled; 1 means enabled;

var popupStatus = 0

//loading popup with jQuery magic!  

function loadPopup(){  
//loads popup only if it is disabled  
if(popupStatus ==0){  
$("#backgroundPopup").css({  
"opacity": "0.3"  
});  
$("#backgroundPopup").fadeIn("slow");  
$("#popupContact").fadeIn("slow");  
popupStatus = 1;  
}  
}  

//disabling popup with jQuery magic!  

function disablePopup(){  
//disables popup only if it is enabled  
if(popupStatus==1){  
$("#backgroundPopup").fadeOut("slow");  
$("#popupContact").fadeOut("slow");  
popupStatus = 0;  
}  
}  

//centering popup  

function centerPopup(){  
//request data for centering  
var windowWidth = document.documentElement.clientWidth;  
var windowHeight = document.documentElement.clientHeight;  
var popupHeight = $("#popupContact").height();  
var popupWidth = $("#popupContact").width();  
//centering  
$("#popupContact").css({  
"position": "absolute",  
"top": windowHeight/2-popupHeight/2,  
"left": windowWidth/2-popupWidth/2  
});  
//only need force for IE6  
  
$("#backgroundPopup").css({  
"height": windowHeight  
});  
  
}
 
//CLOSING POPUP  
//Click the x event!  
$("#popupContactClose").click(function(){  
disablePopup();  
});  
//Click out event!  
$("#backgroundPopup").click(function(){  
disablePopup();  
});  
//Press Escape event!  
$(document).keypress(function(e){  
  

}); 
//

$(document).ready(function(){
	//variable declaration
		var name = $('#name');
		var emailaddress =$('#emailaddress');
		var username =$('#username');
		var password1 =$('#password');
		var password2 =$('#password2');
		var signup =$('#signup');
		
	// limitaions for the fields
    	name.attr('maxlength','40');
		emailaddress.attr('maxlength','35');
		username.attr('maxlength', '20');
	//
	//filters
	var namerepeat = /^(\\w)\\1+$/; 
	var namefix = /^[a-zA-Z.\s]+$/;
	var namefix1 = /^[0-9]+$/;
	var namefix2 = /^[a-z]+[0-9]/;
	var emailfilter = /^[a-zA-Z0-9]+[a-zA-Z0-9_.-]+@[a-zA-Z0-9]+[a-zA-Z0-9.-]+[a-zA-Z0-9]+.[a-z]{2,4}$/;
	var usernamefilter = /^[a-z0-9]{4,20}$/i;
	var mobilefilter = /^[A-Z0-9-+ \s]+$/;
	var addressfilter =/^[a-zA-Z0-9"&()\/,-:.#\s]+$/;
	//event declaration
		name.blur(validateName);
		 emailaddress.blur(validateEmailaddress);
		 username.blur(validateUsername);
		password1.blur(validatePassword);
		password2.blur(validatePassword2);
		
	//submit form 
	
	signup.submit(function(){
		if(validateName() & validateEmailaddress() & validateUsername() & validatePassword() & validatePassword2())
		return true;
		else
			//LOADING POPUP  
			//Click the button event!   
			//centering with css  
			centerPopup();  
			//load popup  
			loadPopup();
			$("#popupContactClose").click(function(){  
				disablePopup();  
				});  
				//Click out event!  
				$("#backgroundPopup").click(function(){  
				disablePopup();  
				});
		return false;
		
		}); 
	
	//function declaration
		//name validation function
				function validateName() {
		//creating a span
			var i = name.val().indexOf(".");
			var j = name.val().lastIndexOf(".");
			var k = name.val().indexOf(" ");
			var l = name.val().lastIndexOf(" ");
			//var j = name.val().lastIndexOf(".");
		name.before('<span id="namebox"></span>');
		//conditions starts here
		for(;i<=j;i++){
			if(name.val().charAt(i) == name.val().charAt(i+1) && !(name.val().length<1)) {
						$('#namebox').html('Your name cannot contain more than one dot').addClass('messageboxerror');
						return false;
				}
			
				}
		for(;k<=l;k++){
			if(name.val().charAt(k) == name.val().charAt(k+1) && !(name.val().length<1)) {
						$('#namebox').html('Your name cannot contain more than one space').addClass('messageboxerror');
						return false;
				}
			
				}
		if(name.val().length ==0) {
			$('#namebox').html('Enter your name').addClass('messageboxerror');
					return false;
			}else if(namefix2.test(name.val())){
				$('#namebox').html('Numericals are not allowed').addClass('messageboxerror');
					return false;
				}
			else if(namefix1.test(name.val())){
				$('#namebox').html('Numericals are not allowed').addClass('messageboxerror');				
					return false;
				}else if(name.val().length >40){
				$('#namebox').html('Enter your name (2-40 characters)').addClass('messageboxerror');	
					return false;
				}else if(!namefix.test(name.val())){
				$('#namebox').html('Special characters other than space and dot are not allowed').addClass('messageboxerror');
					return false;
				}else if(name.val().charAt(0) =="."){
						$('#namebox').html("Your name cannot start with dot").addClass('messageboxerror');
							return false;
						}else if(name.val().charAt(0) ==" ") {
							$('#namebox').html('Your name cannot start with space').addClass('messageboxerror');
								return false;
							}else {
				$('#namebox').html('ok').removeClass().addClass('messageboxok');	
					return true;
				}
			}
		
		//email validation function
		function validateEmailaddress() {
			//creating a span
			emailaddress.before('<span id="Rmailbox"></span>');
				//adding styles to span
				//conditions starts here
			if(emailaddress.val().length ==0 ) {
				$('#Rmailbox').html('Enter your Email address').addClass('messageboxerror');
						return false;
				}else if(!emailfilter.test(emailaddress.val())) {
					$('#Rmailbox').html('Enter a valid email address').addClass('messageboxerror');
						return false;
				}else {
					$('#Rmailbox').html('ok').removeClass().addClass('messageboxok');
						return true;
					}
			} 
		//username validation
		function validateUsername() {
			//creating a span
			username.before('<span id="Rusernamebox"></span>');
			//adding styles to span
			//conditions starts here
			if(username.val().length <1) {
				$('#Rusernamebox').html('Enter your username').addClass('messageboxerror');
						return false;
				}else if (!usernamefilter.test(username.val())) {
					$('#Rusernamebox').html('Enter a valid username').addClass('messageboxerror');
						return false;
				}else{
					$('#Rusernamebox').html('ok').removeClass().addClass('messageboxok');
						return true;
					}
			} 
		//password validation
		function validatePassword() {
			//creating a span
			password1.before('<span id="passwordbox1"></span>');
			//adding styles to span
			//conditions strats here
			if(password1.val().length == 0) {
				$('#passwordbox1').html('Enter your password').addClass('messageboxerror');
						return false;
				}else if(password1.val().length <=5) {
				$('#passwordbox1').html('Password should contain 6 or more characters').addClass('messageboxerror');
					
					return false;
					}
				else {
					$('#passwordbox1').html('ok').removeClass().addClass('messageboxok');	
							return true;
					}
			} 
			//password validation
			
		function validatePassword2() {
			//creating a span
			password2.before('<span id="passwordbox2"></span>');
			//adding styles to span
			//conditions starts here
			if(password1.val().length ==0){
				$('#passwordbox2').html('Retype your password').addClass('messageboxerror');
				return false;
				}else if(password1.val() == password2.val() && password2.val().length <6){
					$('#passwordbox2').html('Password and retype password should contain 6 or more characters').addClass('messageboxerror');
							return false;
					}else if(password1.val() != password2.val() || password2.val().length <6){
					$('#passwordbox2').html('Your password entries do not match').addClass('messageboxerror');
							return false;
					}else {
						$('#passwordbox2').html('ok').removeClass().addClass('messageboxok');
							return true;
						}
				} 
			
	});
