<?php 
	//Nothing to hook>> check this out.
	// Extend system CSS with our own styles, which are defined in the thewire/css view
	function registrationForm_init() {
		elgg_extend_view('js','registrationForm/js');
		elgg_extend_view('css','registrationForm/css');
		
	}
	register_elgg_event_handler('init', 'system', 'registrationForm_init');
				
?>