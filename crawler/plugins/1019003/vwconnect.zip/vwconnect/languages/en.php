<?php
/**
 * vwconnect widget language file
 */

$english = array(

	'vwconnect' => 'Social Connect',
	'item:object:vwconnectfb' => "Social connect Facebook objects",
	'item:object:vwconnecttw' => "Social connect Twitter objects",
	'item:object:vwsocialaccountfb' => 'Facebook account',
	'item:object:vwsocialaccounttw' => 'Twitter account',
	'vwconnect:setting' => 'Setting',
	'vwconnect:fb_floodProtection' => "Facebook flood protection",
	'vwconnect:tw_floodProtection' => "Twitter flood protection",
	
	'vwconnect:settingsaved' => 'Setting Saved',	
	'vwconnect:twitter_ck' => 'Twitter consumer key',
	'vwconnect:twitter_csk' => 'Twitter consumer secret key',
	'vwconnect:facebook_appId' => 'Facebook app id',
	'vwconnect:facebook_secret' => 'Facebook app secret',

	'vwconnect:twitter_ck_descr' => 'A value used by the Consumer to identify itself to the Service Provider.',
	'vwconnect:twitter_csk_descr' => 'A secret used by the Consumer to establish ownership of the Consumer Key. ',
	'vwconnect:twitter_ckcsk_descr' => 'To get Consumer Key & Consumer Secret, you have to create an app in Twitter via https://dev.twitter.com/apps, then you will be taken to a page containing Consumer Key & Consumer Secret.',
	'vwconnect:facebook_appId_descr' => 'Set facebook app_id.',
	'vwconnect:facebook_secret_descr' => 'Set facebook app_secret.',
	'vwconnect:facebook_appIdsecret_descr' => 'You can find app_id and app_secret of your facebook apps in http://facebook.com/developers/apps.php.',
	'vwconnect:fb_floodProtection_descr' => "Set Facebook flood protection (delay between posts in minutes).",
	'vwconnect:tw_floodProtection_descr' => "Set Twitter flood protection (delay between posts in minutes).",
	
	'vwconnect:error' => 'error !!',
	'vwconnect:nocookie' => 'You need a cookie enabled browser!',
	'vwconnect:noaccount' => 'There is no account on this website associated with your Twitter/Facebook account: register one below.',
	'vwconnect:accountfbcreated' => 'Your Facebook account was associated.',
	'vwconnect:accounttwcreated' => 'Your Twitter account was associated.',
	'vwconnect:fbenable' => 'Facebook',
	'vwconnect:fbenable_descr' => 'Allow users to register and login using their account in Facebook.',
	'vwconnect:twenable' => 'Twitter',
	'vwconnect:twenable_descr' => 'Allow users to register and login using their account in Twitter.',
	'vwconnect:vwenable' => 'VideoWhisper',
	'vwconnect:vwenable_descr' => 'Shows VideoWhisper application info links.',
	'vwconnect:h3fbsetting' => 'Facebook Settings',
	'vwconnect:h3twsetting' => 'Twitter Settings',
	'vwconnect:notfilledadminfb' => 'You must fill the fields in Facebook Settings',
	'vwconnect:notfilledadmintw' => 'You must fill the fields in Twitter Settings',
	'vwconnect:notfilleduser' => 'You cannot register or login with Facebook/Twitter because due to lack of backend configuration.',
);
					
add_translation("en", $english);
