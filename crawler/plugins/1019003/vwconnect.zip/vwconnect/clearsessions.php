<?php
/**
 * @file
 * Clears PHP sessions and redirects to the connect page.
 */
require_once(dirname(dirname(dirname(__FILE__))) . '/engine/start.php');
require_once('config.php');
global $CONFIG;
 
/* Load and clear sessions */
session_start();
// session_destroy();
unset($_SESSION['access_token']);
 
/* Redirect to page with the connect to Twitter option. */
// header('Location: '.$CONFIG->url);
/**	if (!isset($twitter_ref)) {
		header('Location: '.$CONFIG->url);
	} else {
		header('Location: '.$twitter_ref); //$CONFIG->url);
	}**/

  $location = get_input('location');
  	 switch ($location) {
		  case 'videoconference':
		    forward ('videoconference/showrooms');
			  break;
		  case 'videoconsultation':
		    forward ('videoconsultation/showrooms');
			  break;
		  case 'videochat':
		    forward ('videochat/showrooms');
			  break;
		  case 'livestreaming':
		    forward ('livestreaming/showrooms');
			  break;
		  default:
		    forward ();
			  break;
     }
