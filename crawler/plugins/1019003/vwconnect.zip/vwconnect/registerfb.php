<?php

	// Get the Elgg engine
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	global $CONFIG;
  
$appId = datalist_get('vwconnect_facebook_appId');
$redirect=$CONFIG->wwwroot."vwconnect/connect?service=facebook";
$redirect=urlencode ($redirect);

// set cookie for indexroom
setcookie("regfb","1",time()+60,'/');

$url = "https://www.facebook.com/dialog/permissions.request?app_id=".$appId."&display=popup&next=".$redirect."&response_type=code&state=00b74d87e82c50559898eddf6484fa97&fbconnect=1&perms=email%2Cfriends_birthday%2Cfriends_education_history%2Cfriends_events%2Cfriends_location%2Cfriends_status%2Cfriends_work_history%2Coffline_access%2Cpublish_stream%2Cread_stream%2Cuser_about_me%2Cuser_activities%2Cuser_birthday%2Cuser_education_history%2Cuser_events%2Cuser_groups%2Cuser_interests%2Cuser_likes%2Cuser_location%2Cuser_religion_politics%2Cuser_status%2Cuser_work_history%2Cxmpp_login";
header('Location: '.$url);

?>
