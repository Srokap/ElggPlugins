<?php

/**
 * @file
 * A single location to store configuration.
 */
global $CONFIG;
$twitter_ck = datalist_get('vwconnect_twitter_ck');
$twitter_csk = datalist_get('vwconnect_twitter_csk');

   function esip($ip_addr)
{
  //first of all the format of the ip address is matched
  if(preg_match("/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/",$ip_addr))
  {
    //now all the intger values are separated
    $parts=explode(".",$ip_addr);
    //now we need to check each part can range from 0-255
    foreach($parts as $ip_parts)
    {
      if(intval($ip_parts)>255 || intval($ip_parts)<0)
      return FALSE; //if number is not within range of 0-255
    }
    return TRUE;
  }
  else
    return FALSE; //if format of ip address doesn't matches
}

   
   
    function domain($domainb)
    {
    $bits = explode('/', $domainb);
    if ($bits[0]=='http:' || $bits[0]=='https:')
    {
    $domainb= $bits[2];
    } else {
    $domainb= $bits[0];
    }
    unset($bits);
    $bits = explode('.', $domainb);
    $idz=count($bits);
    $idz-=3;
    if (strlen($bits[($idz+2)])==2) {
    $url=$bits[$idz].'.'.$bits[($idz+1)].'.'.$bits[($idz+2)];
    } else if (strlen($bits[($idz+2)])==0) {
    $url=$bits[($idz)].'.'.$bits[($idz+1)];
    } else {
    $url=$bits[($idz+1)].'.'.$bits[($idz+2)];
    }
    return $url;
    } 
		
// if (isloggedin()) {
$ver=explode('.', get_version(true));			
if ($ver[1]>7) $ElggUser=elgg_get_logged_in_user_entity();
else $ElggUser=get_loggedin_user();

if ($ElggUser) {
	$twitter_ref = datalist_get($ElggUser->get("username").'vwconnect_twitter_ref');
	if (!isset($twitter_ref)) {
		$addressx=$_SERVER['HTTP_REFERER'];
		$parsed_urlx = parse_url($addressx);
		$checkx = esip($parsed_urlx['host']);
		$hostx = $parsed_urlx['host'];
		if ($checkx == FALSE){
			if ($hostx != ""){
				$hostx = domain($hostx);
			}else{
				$hostx = domain($addressx);   
			}
		}
		$address=$CONFIG->url;
		$parsed_url = parse_url($address);
		$check = esip($parsed_url['host']);
		$host = $parsed_url['host'];
		if ($check == FALSE){
			if ($host != ""){
				$host = domain($host);
			}else{
				$host = domain($address);   
			}
		}
		if ($host == $hostx) {
			datalist_set($ElggUser->get("username").'vwconnect_twitter_ref', $_SERVER["HTTP_REFERER"]);
		}
	} else {
		$addressx=$_SERVER['HTTP_REFERER'];
		$parsed_urlx = parse_url($addressx);
		$checkx = esip($parsed_urlx['host']);
		$hostx = $parsed_urlx['host'];
		if ($checkx == FALSE){
			if ($hostx != ""){
				$hostx = domain($hostx);
			}else{
				$hostx = domain($addressx);   
			}
		}
		$address=$CONFIG->url;
		$parsed_url = parse_url($address);
		$check = esip($parsed_url['host']);
		$host = $parsed_url['host'];
		if ($check == FALSE){
			if ($host != ""){
				$host = domain($host);
			}else{
				$host = domain($address);   
			}
		}
		if ($host == $hostx) {
			datalist_set($ElggUser->get("username").'vwconnect_twitter_ref', $_SERVER["HTTP_REFERER"]);
		}
	}
	$twitter_ref = datalist_get($ElggUser->get("username").'vwconnect_twitter_ref');
} else {
}
define('CONSUMER_KEY', $twitter_ck);
define('CONSUMER_SECRET', $twitter_csk);
define('OAUTH_CALLBACK', $CONFIG->url.'mod/vwconnect/callback.php');
//echo $twitter_ref; // exit;

//echo '<BR />'.$_SERVER['HTTP_HOST'].' -> '.$hostx;

//echo '<BR />'.$host;
