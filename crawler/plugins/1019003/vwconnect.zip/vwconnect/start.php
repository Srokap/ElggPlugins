<?php
/**
* Elgg vwconnect widget
* This plugin allows users to pull in their vwconnect feed to display on their profile
* 
* @package Elggvwconnect
*/

function vwconnect_init() {
	global $CONFIG;
	// Set up menu for logged in users
	if (isadminloggedin()) {
		
		$ver=explode('.', get_version(true));			
		if ($ver[1]>7)	{
			//		add_menu(elgg_echo('vwconnect'), $CONFIG->wwwroot . "mod/vwconnect/admin.php");
			$item = new ElggMenuItem('vwconnect', elgg_echo('vwconnect'), 'vwconnect/settings');
			elgg_register_menu_item('site', $item);
		}
		else
		{
			add_menu(elgg_echo('vwconnect'), $CONFIG->wwwroot . "mod/vwconnect/admin.php");
		}
	}
	elgg_extend_view('css', 'vwconnect/css');
	//	elgg_extend_view('page/elements/footer', 'page/elements/footer');

	//register a page
	register_page_handler('vwconnect', 'vwconnect_page_handler');

}

//page setup
function vwconnect_pagesetup() {

	global $CONFIG;

	//add submenu options
	$ver=explode('.', get_version(true));			
	if ($ver[1]>7)
  {
    if (elgg_get_context() == "vwconnect") {
    	if ((elgg_get_page_owner_guid() == $_SESSION['guid'] || !elgg_get_page_owner_guid()) && elgg_is_logged_in() && elgg_is_admin_logged_in()) {
    		$url =  "vwconnect/settings";
    		$item = new ElggMenuItem('vwconnect:setting', elgg_echo('vwconnect:setting'), $url);
    		elgg_register_menu_item('page', $item);
    	}
    }
  }
  else
  {
    if (get_context() == "vwconnect") {
  	 if ((page_owner() == $_SESSION['guid'] || !page_owner()) && isloggedin() && $_SESSION['guid'] == '2') {
  	   //if (user_flag_get("admin",$_SESSION['guid'])) {
  		 add_submenu_item(elgg_echo('vwconnect:setting'),$CONFIG->wwwroot."mod/vwconnect/admin.php");
  	 }
  	}
  }
}

function vwconnect_page_handler($page) {

	$sc = $_GET['service'];
	switch ($sc) {
	case 'facebook':
		include(dirname(__FILE__) . "/fbconnect.php");
		return true;
		break;
	case 'twitter':
		include(dirname(__FILE__) . "/redirect.php");
		return true;
		break;
	case 'loginfb':
		include(dirname(__FILE__) . "/loginfb.php");
		return true;
		break;
	case 'logintw':
		include(dirname(__FILE__) . "/logintw.php");
		return true;
		break;
	case 'registerfb':
		include(dirname(__FILE__) . "/registerfb.php");
		return true;
		break;
	case 'registertw':
		include(dirname(__FILE__) . "/registertw.php");
		return true;
		break;
	case 'register':
		include(dirname(__FILE__) . "/register.php");
		return true;
		break;
	}
	
	if ($page[0] == 'settings') {
		include(dirname(__FILE__) . "/admin.php");
		return true;
	} elseif ($page[0] == 'clearsessions') {
		set_input('location', $page[1]);
		include(dirname(__FILE__) . "/clearsessions.php");
		return true;
	}
}

/**
	* Populates the ->getUrl() method for vwconnect objects
	*/
function vwconnect_url() {
	global $CONFIG;
	
	$ver=explode('.', get_version(true));			
	if ($ver[1]>7)	
	return $CONFIG->url . "vwconnect/connect";
	else return $CONFIG->url . "pg/vwconnect/connect";
}

register_elgg_event_handler('pagesetup','system','vwconnect_pagesetup');

register_elgg_event_handler('init', 'system', 'vwconnect_init');

// Register actions
global $CONFIG;
register_action('vwconnect/setting',false,$CONFIG->pluginspath . "vwconnect/actions/vwconnect/setting.php");	
register_action('vwconnect/register',true,$CONFIG->pluginspath . "vwconnect/actions/vwconnect/register.php");
