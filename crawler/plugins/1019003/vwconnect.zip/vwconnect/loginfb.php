<?php

	// Get the Elgg engine
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	global $CONFIG;
  
$appId = datalist_get('vwconnect_facebook_appId');
$redirect=$CONFIG->wwwroot."vwconnect/connect?service=facebook";
$redirect=urlencode ($redirect);

//$url = "http://www.facebook.com/r.php?possible_fb_user=1&fbconnect=1&api_key=179323222134179&app_id=179323222134179&cancel_url=http%3A%2F%2Fdev.camflock.com%2Felgg2%2Fpg%2Fvwconnect%2Fconnect%3Fservice%3Dfacebook%26error_reason%3Duser_denied%26error%3Daccess_den ed%26error_description%3DThe%2Buser%2Bdenied%2Byour%2Brequest.%26state%3D10afb9da23c8ba05842a5438360549ec&is_enabled=1&next=https%253A%252F%252Fwww.facebook.com%252Fdialog%252Fpermissions.request%253F_path%253Dpermissions.request%2526app_id%253D179323222134179%2526redirect_uri%253Dhttp%25253A%25252F%25252Fdev.camflock.com%25252Felgg2%25252Fpg%25252Fvwconnect%25252Fconnect%25253Fservice%25253Dfacebook%2526display%253Dpage%2526response_type%253Dcode%2526state%253D10afb9da23c8ba05842a5438360549ec%2526fbconnect%253D1%2526perms%253Demail%25252C";
$url = "https://www.facebook.com/dialog/permissions.request?app_id=".$appId."&display=popup&next=".$redirect."&response_type=code&state=00b74d87e82c50559898eddf6484fa97&fbconnect=1&perms=email%2Cfriends_birthday%2Cfriends_education_history%2Cfriends_events%2Cfriends_location%2Cfriends_status%2Cfriends_work_history%2Coffline_access%2Cpublish_stream%2Cread_stream%2Cuser_about_me%2Cuser_activities%2Cuser_birthday%2Cuser_education_history%2Cuser_events%2Cuser_groups%2Cuser_interests%2Cuser_likes%2Cuser_location%2Cuser_religion_politics%2Cuser_status%2Cuser_work_history%2Cxmpp_login";
//$url = "http://www.facebook.com/r.php?possible_fb_user=1&fbconnect=1&api_key=".$appId."&app_id=".$appId."&cancel_url=".$redirect."%26error_reason%3Duser_denied%26error%3Daccess_den ed%26error_description%3DThe%2Buser%2Bdenied%2Byour%2Brequest.%26state%3D10afb9da23c8ba05842a5438360549ec&is_enabled=1&next=https%253A%252F%252Fwww.facebook.com%252Fdialog%252Fpermissions.request%253F_path%253Dpermissions.request%2526app_id%253D".$appId."%2526redirect_uri%253D".$redirect."%2526display%253Dpage%2526response_type%253Dcode%2526state%253D10afb9da23c8ba05842a5438360549ec%2526fbconnect%253D1%2526perms%253Demail%25252C";
header('Location: '.$url);

?>
