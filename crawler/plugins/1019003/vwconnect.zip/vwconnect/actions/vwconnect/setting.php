<?php

/**
	* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	*/


// Make sure we're logged in (send us to the front page if not)
if (!isloggedin()) forward();

$fbenable = get_input('fbenable');
$twenable = get_input('twenable');
$vwenable = get_input('vwenable');

$twitter_ck = get_input('twitter_ck');
$twitter_csk = get_input('twitter_csk');
$facebook_appId = get_input('facebook_appId');
$facebook_secret = get_input('facebook_secret');		
$fb_floodProtection = get_input('fb_floodProtection');
$tw_floodProtection = get_input('tw_floodProtection');
$fb_floodProtection = $fb_floodProtection*60; //convert to second
$tw_floodProtection = $tw_floodProtection*60; //convert to second

datalist_set('vwconnect_fbenable',$fbenable);
datalist_set('vwconnect_twenable',$twenable);
datalist_set('vwconnect_vwenable',$vwenable);

datalist_set('vwconnect_twitter_ck',$twitter_ck);
datalist_set('vwconnect_twitter_csk',$twitter_csk);
datalist_set('vwconnect_facebook_appId',$facebook_appId);		
datalist_set('vwconnect_facebook_secret',$facebook_secret);		
datalist_set('vwconnect_fb_floodProtection',$fb_floodProtection);
datalist_set('vwconnect_tw_floodProtection',$tw_floodProtection);

// Success message
system_message(elgg_echo("vwconnect:settingsaved"));

if ($fbenable) {
	if (!$facebook_appId || !$facebook_secret) register_error(elgg_echo("vwconnect:notfilledadminfb"));
}

if ($twenable) {
	if (!$twitter_ck || !$twitter_csk) register_error(elgg_echo("vwconnect:notfilledadmintw"));
}

// Forward
$ver=explode('.', get_version(true));	
if ($ver[1]>7) forward("vwconnect/settings");
else		forward("mod/vwconnect/admin.php");

?>
