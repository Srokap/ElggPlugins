<?php


if (defined('ACCESS_DEFAULT')) $access_id = ACCESS_DEFAULT;
else $access_id=2;

// function view select_setting
function selectSetting ($data,$vwconnect_data,$default) {
  $select_name = array ("Disable","Enable");
  echo "<select name=$data>";
  $datax = datalist_get($vwconnect_data);
  if (isset ($datax)) {
    for ($no=0; $no<2; $no++) {
      if ($no==datalist_get($vwconnect_data))
        echo "<option selected='selected' value=$no>$select_name[$no]</option>";
        else
        echo "<option value=$no>$select_name[$no]</option>";
    }
  } else for ($no=0; $no<2; $no++) {
          if ($no==$default)
          echo "<option selected='selected' value=$no>$select_name[$no]</option>";
            else
            echo "<option value=$no>$select_name[$no]</option>";
        }
          echo "</select> <br />"; 
}

?>
<div id="vwconnect_settings">
	<form action="<?php echo elgg_add_action_tokens_to_url($vars['url']."action/vwconnect/setting"); ?>" method="post" name="settingForm">
  <?php echo elgg_echo("vwconnect:twenable"); ?>:<br />
  <?php selectSetting ('twenable','vwconnect_twenable',1); ?>
  <?php echo elgg_echo("vwconnect:twenable_descr"); ?><br /><br />
  
  <?php echo elgg_echo("vwconnect:fbenable"); ?>:<br />
  <?php selectSetting ('fbenable','vwconnect_fbenable',1); ?>
  <?php echo elgg_echo("vwconnect:fbenable_descr"); ?><br /><br />
  
 
  <?php echo elgg_echo("vwconnect:vwenable"); ?>:<br />
  <?php selectSetting ('vwenable','vwconnect_vwenable',1); ?>
  <?php echo elgg_echo("vwconnect:vwenable_descr"); ?><br /><br />
  
  <h3 class="settings"><?php echo elgg_echo('vwconnect:h3twsetting'); ?></h3>
	<?php echo elgg_echo("vwconnect:twitter_ck"); ?>:<br /> 
	<input name='twitter_ck' value="<?php if (datalist_get('vwconnect_twitter_ck')) echo datalist_get('vwconnect_twitter_ck'); else echo ''; ?>" size="70"><br /> 
	<?php echo elgg_echo("vwconnect:twitter_ck_descr"); ?><br /><br />
	<?php echo elgg_echo("vwconnect:twitter_csk"); ?>:<br /> 
	<input name='twitter_csk' value="<?php if (datalist_get('vwconnect_twitter_csk')) echo datalist_get('vwconnect_twitter_csk'); else echo ''; ?>" size="70"><br /> 
	<?php echo elgg_echo("vwconnect:twitter_csk_descr"); ?><br /><br />
	<?php echo elgg_echo("vwconnect:twitter_ckcsk_descr"); ?><br /><br />
	<?php echo elgg_echo("vwconnect:tw_floodProtection"); ?>:<br />
	<input name='tw_floodProtection' value="<?php if (datalist_get('vwconnect_tw_floodProtection')) echo (datalist_get('vwconnect_tw_floodProtection')/60); else echo '15'; ?>" size="10"><br />
    <?php echo elgg_echo("vwconnect:tw_floodProtection_descr"); ?><br /> <br />
<h3 class="settings"><?php echo elgg_echo('vwconnect:h3fbsetting'); ?></h3>
	<?php echo elgg_echo("vwconnect:facebook_appId"); ?>:<br /> 
	<input name='facebook_appId' value="<?php if (datalist_get('vwconnect_facebook_appId')) echo datalist_get('vwconnect_facebook_appId'); else echo ''; ?>" size="70"><br /> 
	<?php echo elgg_echo("vwconnect:facebook_appId_descr"); ?><br /><br />
	<?php echo elgg_echo("vwconnect:facebook_secret"); ?>:<br /> 
	<input name='facebook_secret' value="<?php if (datalist_get('vwconnect_facebook_secret')) echo datalist_get('vwconnect_facebook_secret'); else echo ''; ?>" size="70"><br /> 
	<?php echo elgg_echo("vwconnect:facebook_secret_descr"); ?><br /><br />
	<?php echo elgg_echo("vwconnect:facebook_appIdsecret_descr"); ?><br /><br />
    <?php echo elgg_echo("vwconnect:fb_floodProtection"); ?>:<br />
    <input name='fb_floodProtection' value="<?php if (datalist_get('vwconnect_fb_floodProtection')) echo (datalist_get('vwconnect_fb_floodProtection')/60); else echo '15'; ?>" size="10"><br />
    <?php echo elgg_echo("vwconnect:fb_floodProtection_descr"); ?><br /> <br />

	<br />
<?php
echo elgg_view('input/submit', array(
	'value' => elgg_echo('save'),
	'name' => 'save',
));
?>
	</form>
</div>
