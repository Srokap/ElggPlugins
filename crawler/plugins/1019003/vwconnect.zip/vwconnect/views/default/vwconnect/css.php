<?php
 
    /**
	 * Elgg vwconnect CSS
	 * 
	 * @package Elggvwconnect
	 */
     
?>

.vwconnect1 {
margin:0 10px 0 10px; -webkit-border-radius: 8px; -moz-border-radius: 8px; background: white; margin-bottom:5px;
}

.vwconnect2 {
margin-bottom:10px;	-webkit-border-radius: 8px;	-moz-border-radius: 8px; border-bottom:1px solid #aaaaaa; border-right:1px solid #aaaaaa;	font-size:90%; color:#666666; padding:0;
}

#vwsocialconnect {
	width: auto;
	padding: 0 10px 10px;
}

#vwconnect_settings {
	padding:5px 10px 5px 10px;	
	margin:0 0 20px 0;	
	border:1px solid silver;	
	background: white;	
	-moz-border-radius: 8px;	
	-webkit-border-radius: 8px;
}