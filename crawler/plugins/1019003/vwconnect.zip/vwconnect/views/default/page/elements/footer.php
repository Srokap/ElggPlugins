<?php

  // vwconnect
  $is_vwconnectEnabled = false;
  $ver=explode('.', get_version(true));			
	if ($ver[1]>7) $is_vwconnectEnabled = elgg_is_active_plugin (vwconnect, 0);
  else $is_vwconnectEnabled = is_plugin_enabled (vwconnect);
  if ($is_vwconnectEnabled) {
    if ($ver[1]>7) $context = elgg_get_context();
    else $context = get_context();
    $arrvid = array ("videoconference","videoconsultation","videochat","livestreaming");
    if (in_array ($context, $arrvid)) {
    // is admin enable twitter and facebook ?
    $twitterEnable = datalist_get('vwconnect_twenable');
    $facebookEnable = datalist_get('vwconnect_fbenable');
  	$videowhisperEnable = datalist_get('vwconnect_vwenable');

    // twitter
    if ($twitterEnable) {
	/* Load required lib files. */
	$vwconnect = 0;
	if (is_dir('../vwconnect')) {
		session_start();
		require_once('../vwconnect/twitteroauth/twitteroauth.php');
		require_once('../vwconnect/config.php');
		$vwconnect = 1;
	} elseif (is_dir('../../mod/vwconnect')) {
		session_start();
		require_once('../../mod/vwconnect/twitteroauth/twitteroauth.php');
		require_once('../../mod/vwconnect/config.php');
		$vwconnect = 2;
	}
	if ($vwconnect > 0) {
	if (empty($_SESSION['access_token']) || empty($_SESSION['access_token']['oauth_token']) || empty($_SESSION['access_token']['oauth_token_secret'])) {
			$socialconnect2 = "".
											 "<br /><a href=\"".$CONFIG->url."vwconnect/connect?service=twitter\">".
											 //"<img alt=\"Sign in with Twitter\" src=\"mod/vwconnect/graphics/lighter.png\">".
											 "Connect Twitter Account</a>";
	} else {
		/* Get user access tokens out of the session. */
		$access_token = $_SESSION['access_token'];

		/* Create a TwitterOauth object with consumer/user tokens. */
		$connection = new TwitterOAuth(CONSUMER_KEY, CONSUMER_SECRET, $access_token['oauth_token'], $access_token['oauth_token_secret']);

		/* If method is set change API call made. Test is called by default. */
		$twitter = $connection->get('account/verify_credentials');
		// $connection->post('statuses/update', array('status' => date(DATE_RFC822)));
		$socialconnect2 = "<br />Connected with Twitter Account: <a href=\"http://twitter.com/".$twitter->screen_name."\">".$twitter->screen_name."</a>, <a href=\"".$CONFIG->url."vwconnect/clearsessions/".$context."\">Disconnect</a>";
	}
	}}
	// akhir twitter
	
    // facebook
  if ($facebookEnable) {
	if ($vwconnect == 1)
		require '../vwconnect/src/facebook.php';
	else 
		require '../../mod/vwconnect/src/facebook.php';
		
// Create our Application instance (replace this with your appId and secret).
$appId = datalist_get('vwconnect_facebook_appId');
$secret = datalist_get('vwconnect_facebook_secret');

$facebook = new Facebook(array(
  'appId' => $appId,
  'secret' => $secret,
  'cookie' => true,
));

	// Get User ID
	$fbuser = $facebook->getUser();

	// We may or may not have this data based on whether the user is logged in.
	//
	// If we have a $user id here, it means we know the user is logged into
	// Facebook, but we don't know if the access token is valid. An access
	// token is invalid if the user logged out of Facebook.
	$socialconnect1 = "<br /><a href=\"".$CONFIG->url."vwconnect/connect?service=facebook\">Connect Facebook Account</a>";

	if ($fbuser) {
		try {
			// Proceed knowing you have a logged in user who's authenticated.
			$user_profile = $facebook->api('/me');
			$logoutUrl = $facebook->getLogoutUrl();
			$socialconnect1 = "<br />Connected with Facebook Account: <a href=\"".$user_profile['link']."\">".$user_profile['email']."</a> <a href=\"".$logoutUrl."\">Disconnect</a>";
		} catch (FacebookApiException $e) {
			error_log($e);
			$user = null;
			$socialconnect1 = "<br /><a href=\"".$CONFIG->url."vwconnect/connect?service=facebook\">Connect Facebook Account</a>";
		}
	 } }	// akhir fb
  }	// end in_array
} // end vwconnect

// like button facebook and twitter
function curPageURL() {
 $pageURL = 'http';
 if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
 $pageURL .= "://";
 if ($_SERVER["SERVER_PORT"] != "80") {
  $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
 } else {
  $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
 }
 return $pageURL;
}

  echo elgg_view_menu('footer', array('sort_by' => 'priority', 'class' => 'elgg-menu-hz'));
	
	echo "<br />";	 
	echo $socialconnect1.''.$socialconnect2; 
    $currenturl = urlencode(curPageURL());
    echo "<br />";
    echo elgg_view('output/url', array(
	'href' => 'http://twitter.com/share',
	'text' => "Tweet",
	'class' => 'twitter-share-button',
	'is_trusted' => true,
    ));
    echo "<script type=\"text/javascript\" src=\"http://platform.twitter.com/widgets.js\"></script>";
    echo "<iframe src=\"http://www.facebook.com/plugins/like.php?app_id=" . $appId . "&amp;href=";
    echo $currenturl."&amp;send=false&amp;layout=button_count&amp;width=450&amp;show_faces=false&amp;action=like&amp;colorscheme=light&amp;font&amp;height=21\" scrolling=\"no\" frameborder=\"0\" style=\"border:none; overflow:hidden; width:450px; height:21px;\" allowTransparency=\"true\"></iframe>";

  
  
  if ($videowhisperEnable) $state = 'block';
  else $state = 'none';	
		
  echo '<div id="VideoWhisper" style="display: ' . $state . ';">';
	
  echo "<BR><BR>For more details about this application visit the homepage of ";
  echo elgg_view('output/url', array(
      	'href' => 'http://www.videowhisper.com',
      	'text' => "VideoWhisper",
      	'class' => '',
      	'is_trusted' => true,
        ));		  
	
    if ($ver[1]>7) $context = elgg_get_context();
    else $context = get_context();
  	switch ($context) {
		
		case 'videoconference':
		echo ", ";
        echo elgg_view('output/url', array(
      	'href' => 'http://www.videowhisper.com/?p=Video+Conference',
      	'text' => "Video Conference Software",
      	'class' => '',
      	'is_trusted' => true,
        ));
		echo ", ";
        echo elgg_view('output/url', array(
      	'href' => 'http://www.videowhisper.com/?p=Elgg+Video+Conference',
      	'text' => "Elgg Video Conference Plugin",
      	'class' => '',
      	'is_trusted' => true,
        ));
		break;
		
		case 'videoconsultation':
 		echo ", ";
        echo elgg_view('output/url', array(
      	'href' => 'http://www.videowhisper.com/?p=Video+Consultation',
      	'text' => "Video Consultation Software",
      	'class' => '',
      	'is_trusted' => true,
        ));
		echo ", ";
        echo elgg_view('output/url', array(
      	'href' => 'http://www.videowhisper.com/?p=Elgg+Video+Consultation',
      	'text' => "Elgg Video Consultation Plugin",
      	'class' => '',
      	'is_trusted' => true,
        ));
		break;
		
		case 'videochat':
  		echo ", ";
        echo elgg_view('output/url', array(
      	'href' => 'http://www.videowhisper.com/?p=2+Way+Video+Chat',
      	'text' => "2 Way Video Chat Software",
      	'class' => '',
      	'is_trusted' => true,
        ));
		echo ", ";
        echo elgg_view('output/url', array(
      	'href' => 'http://www.videowhisper.com/?p=Elgg+Video+Chat',
      	'text' => "Elgg Video Chat Plugin",
      	'class' => '',
      	'is_trusted' => true,
        ));		
		break;
		
		case 'livestreaming':
 		echo ", ";
        echo elgg_view('output/url', array(
      	'href' => 'http://www.videowhisper.com/?p=Live+Streaming',
      	'text' => "Live Streaming Software",
      	'class' => '',
      	'is_trusted' => true,
        ));
		echo ", ";
        echo elgg_view('output/url', array(
      	'href' => 'http://www.videowhisper.com/?p=Elgg+Live+Video+Streaming',
      	'text' => "Elgg Live Video Streaming Plugin",
      	'class' => '',
      	'is_trusted' => true,
        ));
		break;
		
		default:
		break;
		
     }
	echo ".";
	echo '</div>';

    echo '<div class="mts clearfloat float-alt">';
    echo '</div>';
