<?php

/**
 * dumpcache.php
 * Used for testing only to inspect the contents of the livetranslate cache
 *  
 * @package livetranslate
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Tristan Colson
 * @copyright IntraPace, Inc. 2011
 */

// Load Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
require_once dirname(__FILE__) . '/TranslatedText.php';

if (!isadminloggedin()) {
    echo ("ERROR: you must be logged in as admin to run this script.");
    return;
}


$format = get_input("format");
if (!isset($format)) {
    $format = "all";
}

if ($format == "all") {
    echo ("<h3>Live Translate Cache (all) </h3>");
    $cacheItems = TranslatedText::getAllFromCache();
    echo ("Total Number of Items in Cache: " . count($cacheItems) . "<br/>");
    foreach ($cacheItems as $c) {
        echo ("<br/> Cache Item: <br/>");
        echo ("&nbsp;&nbsp;Type: " . $c->trans_type . "<br/>");
        echo ("&nbsp;&nbsp;Lang: " . $c->lang . "<br/>");
        echo ("&nbsp;&nbsp;Text: " . htmlentities($c->text) . "<br/>");
        echo ("&nbsp;&nbsp;Time Created: " . $c->time_created . "<br/>");
        echo ("&nbsp;&nbsp;Guid: " . $c->guid . "<br/>");
        echo ("&nbsp;&nbsp;Container Guid: " . $c->container_guid . "<br/>");
        echo ("<br/>");
    }

}
else if ($format == "structured") {
    echo ("<h3>Live Translate Cache (structured) </h3>");
    // get just the top level items 
    $origCacheItems = TranslatedText::getAllFromCache('o');
    $numOrig = count($origCacheItems);
    $numTrans = 0;
    foreach ($origCacheItems as $c) {
        echo ("<b>Cache Item:</b> <br/>");
        echo ("&nbsp;&nbsp;Lang: " . $c->lang . "&nbsp;&nbsp;");
        echo ("&nbsp;&nbsp;Text: " . htmlentities($c->text) . "<br/>");
        echo ("&nbsp;&nbsp;Time Created: " . $c->time_created . "<br/>");
        echo ("&nbsp;&nbsp;Guid: " . $c->guid . "<br/>");
        echo ("&nbsp;&nbsp;Container Guid: " . $c->container_guid . "<br/>");
        echo ("<br/>");

        // get its children
        $transCacheItems = TranslatedText::getChildren($c);
        $i = 1;
        foreach ($transCacheItems as $t) {
            echo ("&nbsp;&nbsp;Translation $i: <br/>");
            echo ("&nbsp;&nbsp;&nbsp;&nbsp;Lang: " . $t->lang . "&nbsp;&nbsp;");
            echo ("&nbsp;&nbsp;&nbsp;&nbsp;Text: " . htmlentities($t->text) . "<br/>");
            echo ("&nbsp;&nbsp;&nbsp;&nbsp;Time Created: " . $t->time_created . "<br/>");
            echo ("&nbsp;&nbsp;&nbsp;&nbsp;Guid: " . $t->guid . "<br/>");
            echo ("&nbsp;&nbsp;&nbsp;&nbsp;Container Guid: " . $t->container_guid . "<br/>");
            echo ("<br/>");
            $i++;
            $numTrans++;
        }
    }
    $cacheItems = TranslatedText::getAllFromCache();
    echo ("Total Number of Items in Cache: " . count($cacheItems) . "<br/>");
    echo ("Total Number of Original Items in Cache " . $numOrig . "<br/>");
    echo ("Total Number of Translations in Cache " . $numTrans . "<br/>");
    if (count($cacheItems) != $numOrig + $numTrans) {
        echo ("Houston, we have a problem<br/>");
    }
 

}
else {
    echo ("ERROR: unknown format specified");

}


