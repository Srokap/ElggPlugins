<?php
/**
 * showDescription.php
 * 
 * Returns the description of LiveTranslate
 *  
 * @package livetranslate
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Mike Hedman
 * @copyright IntraPace, Inc. 2011
 */

require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
echo elgg_view('description');

