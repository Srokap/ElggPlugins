<?php
/**
 * Testing the regular expression replacer (used to create clean id's in groupprofile.php
 *  
 * @package livetranslate
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Mike Hedman
 * @copyright IntraPace, Inc.  2011
 */
global $CONFIG;
require_once $CONFIG->pluginspath . 'testing/ElggTestCase.php';

class regTest extends ElggTestCase {
    
    public static function provider()
    {
        return array(
          array('id', 'id'),
          array('id.', 'id'),
          array(' id ', 'id'),
          array('/id', 'id'),
          array('_id ', 'id'),
          array('id id', 'idid')
        );
    } 
    /**
     * @dataProvider provider
     */    
    public function testReg($in, $expected) {
        $this->assertEquals($expected, preg_replace("/[^A-Za-z0-9]/", "", $in));
    }
}
