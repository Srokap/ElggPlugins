<?php
global $CONFIG;
require_once($CONFIG->pluginspath . 'IP_testing/IPTestCase.php');

/**
 * @TestCaseName 
 * @TestCaseId 
 * @TestCaseDescription 
 */
class TestLiveTranslateGui extends IPTestCase {
    private $groupName = "LTTestGroup1";
    private $groupDescription = 'Il y a beaucoup de chats';
    private $groupBriefDescription = "J'aime les chats";
    private $topicTitle = "Je veux un chien";
    private $topicDescription = "Mon chien est petit";
    private $commentText = "Je veux un chien";

    /**
     * @TestItemId 
     * @TestItemRequirement 
     * @TestItemDescription 
     */
    public function testGroupTopicTranslate() {
        // we clear the cache first 
        $this->clearLiveTranslateCache();

        // log in
        $this->guiLogIn();

        // create a new group with a topic and a comment
        $this->createGroupWithTopicAndComment();

        // now translate all the text on this page
        // we assume we have just created the comment and are on that page
        $this->pressTranslateButton();

        // verify that the translations occurred correctly
        sleep(4); // translation sometimes takes a while
        $titleElement = $this->getElement('xpath=//div[@id="content_area_group_title"]/h2');
        $this->assertEquals("I want a dog", $titleElement->get_text());

        $topicElement = $this->getElement('xpath=//div[@id="topic_posts"]/div[3]/table/tbody/tr/td[2]/p');
        $this->assertEquals("My dog is small", $topicElement->get_text());

        $commentElement = $this->getElement('xpath=//div[@id="topic_posts"]/div[4]/table/tbody/tr/td[2]/p');
        $this->assertEquals("I want a dog", $commentElement->get_text());


        $this->pressTranslateButton();   // to restore
        // verify that the restores occurred correctly
        $titleElement = $this->getElement('xpath=//div[@id="content_area_group_title"]/h2');
        $this->assertEquals("Je veux un chien", $titleElement->get_text());

        $topicElement = $this->getElement('xpath=//div[@id="topic_posts"]/div[3]/table/tbody/tr/td[2]/p');
        $this->assertEquals("Mon chien est petit", $topicElement->get_text());

        $commentElement = $this->getElement('xpath=//div[@id="topic_posts"]/div[4]/table/tbody/tr/td[2]/p');
        $this->assertEquals("Je veux un chien", $commentElement->get_text());

        // now translate all the text on this page again
        // it should be in the cache this time
        $this->pressTranslateButton();   // to translate again

        // verify that the translations occurred correctly
        $titleElement = $this->getElement('xpath=//div[@id="content_area_group_title"]/h2');
        $this->assertEquals("I want a dog", $titleElement->get_text());

        $topicElement = $this->getElement('xpath=//div[@id="topic_posts"]/div[3]/table/tbody/tr/td[2]/p');
        $this->assertEquals("My dog is small", $topicElement->get_text());

        $commentElement = $this->getElement('xpath=//div[@id="topic_posts"]/div[4]/table/tbody/tr/td[2]/p');
        $this->assertEquals("I want a dog", $commentElement->get_text());

        // delete the group
        $this->guiDeleteGroup($this->groupName);

        // log out
        $this->guiLogOut();

    } // testGroupTopicTranslate


    public function createGroupWithTopicAndComment() {

        // create a new group
        $this->guiCreateGroup($this->groupName, $this->groupDescription, $this->groupBriefDescription);


        // add a topic to the group
        $this->guiAddTopicToGroup($this->groupName, $this->topicTitle, $this->topicDescription);

        // add a topic to the group
        $this->guiAddCommentToGroupTopic($this->groupName, $this->topicTitle, $this->commentText);

    } // createGroupWithTopicAndComment

} // TestLiveTranslateGui
