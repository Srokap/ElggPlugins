<?php

global $CONFIG;
require_once $CONFIG->pluginspath . 'testing/ElggTestCase.php';
require_once $CONFIG->pluginspath . 'livetranslate/TranslationController.php';
require_once $CONFIG->pluginspath . 'livetranslate/tests/TestTranslationController.php';
require_once $CONFIG->pluginspath . 'livetranslate/TranslatedText.php';

class TranslationControllerTest extends ElggTestCase {

    public function setUp() {
        parent::setUp();
        // clear the live translate cache
        TranslatedText::expireFromCache(null);
    } // setUp


    // *************** start of tests *********************************

    // no text to translate specified
    public function testTranslateNoText() {
        $wrapper = new TranslationController();
        $translatedText = json_decode($wrapper->translate("", "en"), true);

        // empty text gets marked as "no translate"
        $this->assertEquals(STATUS_NOTRANSLATE, $translatedText['status']);
    } // testTranslateNoText
    
    // no target language specified
    public function testTranslateNoLang() {
        $wrapper = new TranslationController();
        $translatedText = json_decode($wrapper->translate("foo", ""), true);

        // this should never happen, but if it does, we treat it as if the text
        // should not be translated
        $this->assertEquals(STATUS_NOTRANSLATE, $translatedText['status']);
    } // testTranslateNoLang
    
    /**
      * Translate where the original translation not found in the cache
      */
    public function testTranslateOrigNotInCache() {
        $cacheItems = TranslatedText::getAllFromCache();
        $this->assertEquals(0, count($cacheItems));

        $wrapper = new TestTranslationController();
        $translatedText = json_decode($wrapper->translate("Bon Chien", "en"), true);

        $this->assertEquals('Good Dog', $translatedText['translatedText']);
        $this->assertEquals(STATUS_OK, $translatedText['status']);
        // if we called google, then we didn't find anything in the cache
        $this->assertTrue($wrapper->calledGoogle);

        $cacheItems = TranslatedText::getAllFromCache();
        $this->assertEquals(2, count($cacheItems));

    } // testTranslateOrigNotInCache

    /**
      * Translate where the original translation is found in the cache
      * but no translation has been done for this language
      */
    public function testTranslateOrigInCacheNoTranslation() {
        $cacheItems = TranslatedText::getAllFromCache();
        $this->assertEquals(0, count($cacheItems));

        $wrapper = new TestTranslationController();
        $translatedText = json_decode($wrapper->translate("bonne lapin", "en"), true);
        $this->assertEquals('good rabbit', $translatedText['translatedText']);
        $this->assertEquals(STATUS_OK, $translatedText['status']);
        $this->assertTrue($wrapper->calledGoogle);

        $cacheItems = TranslatedText::getAllFromCache();
        $this->assertEquals(2, count($cacheItems));

        $wrapper = new TestTranslationController();
        $translatedText = json_decode($wrapper->translate("bonne lapin", "de"), true);
        $this->assertEquals('gute Kaninchen', $translatedText['translatedText']);
        $this->assertEquals(STATUS_OK, $translatedText['status']);
        // we should call google since translation not found in cache
        $this->assertTrue($wrapper->calledGoogle);

        $cacheItems = TranslatedText::getAllFromCache();
        $this->assertEquals(3, count($cacheItems));

    } // testTranslateOrigInCacheNoTranslation

    /**
      * Translate where the original translation is found in the cache
      * in the requested language
      */
    public function testTranslateOrigInCacheCurrentLanguage() {
        $cacheItems = TranslatedText::getAllFromCache();
        $this->assertEquals(0, count($cacheItems));

        $wrapper = new TestTranslationController();
        $translatedText = json_decode($wrapper->translate("Bon Chien", "en"), true);
        $this->assertEquals('Good Dog', $translatedText['translatedText']);
        $this->assertEquals(STATUS_OK, $translatedText['status']);
        $this->assertTrue($wrapper->calledGoogle);

        $cacheItems = TranslatedText::getAllFromCache();
        $this->assertEquals(2, count($cacheItems));

        $wrapper = new TestTranslationController();
        $translatedText = json_decode($wrapper->translate("Bon Chien", "fr"), true);
        $this->assertEquals(STATUS_NOTRANSLATE, $translatedText['status']);
        // we should NOT call google since translation found in cache
        $this->assertFalse($wrapper->calledGoogle);

        $cacheItems = TranslatedText::getAllFromCache();
        $this->assertEquals(2, count($cacheItems));

    } // testTranslateOrigInCacheCurrentLanguage

    /**
      * Translate where the original translation is found in the cache
      * and a translation exists in this language
      */
    public function testTranslateOrigInCacheHasTranslation() {
        $cacheItems = TranslatedText::getAllFromCache();
        $this->assertEquals(0, count($cacheItems));

        $wrapper = new TestTranslationController();
        $translatedText = json_decode($wrapper->translate("Bon Chien", "en"), true);
        $this->assertEquals('Good Dog', $translatedText['translatedText']);
        $this->assertEquals(STATUS_OK, $translatedText['status']);
        $this->assertTrue($wrapper->calledGoogle);

        $cacheItems = TranslatedText::getAllFromCache();
        $this->assertEquals(2, count($cacheItems));

        $wrapper = new TestTranslationController();
        $translatedText = json_decode($wrapper->translate("Bon Chien", "en"), true);
        $this->assertEquals('Good Dog', $translatedText['translatedText']);
        $this->assertEquals(STATUS_OK, $translatedText['status']);
        // we should NOT call google since translation found in cache
        $this->assertFalse($wrapper->calledGoogle);

        $cacheItems = TranslatedText::getAllFromCache();
        $this->assertEquals(2, count($cacheItems));

    } // testTranslateOrigInCacheHasTranslation

} // TranslationControllerTest
