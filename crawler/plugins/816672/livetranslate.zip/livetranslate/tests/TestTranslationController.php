<?php
/**
 * TestTranslationController
 * This is a wrapper around TranslationController, used for unit testing
 * @package livetranslate
 * @author Tristan Colson
 * @copyright IntraPace, Inc. 2011
 */

global $CONFIG;
require_once($CONFIG->pluginspath . "livetranslate/TranslationController.php");

class TestTranslationController extends TranslationController {

    public $calledGoogle = false;

protected function remoteQuery($queryType) {
   $this->calledGoogle = true;
   return parent::remoteQuery($queryType);
}
    
} // TestTranslationController
