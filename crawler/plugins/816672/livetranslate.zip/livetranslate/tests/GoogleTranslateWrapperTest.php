<?php

/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
global $CONFIG;
require_once $CONFIG->pluginspath . 'testing/ElggTestCase.php';
require_once $CONFIG->pluginspath . 'livetranslate/GoogleTranslateWrapper.php';

class GoogleTranslateWrapperTest extends ElggTestCase {
    
    public function testTranslate() {
        $wrapper = new GoogleTranslateWrapper();
        $wrapper->googleTranslate('Bonjour', 'en', 'fr');
        $this->assertEquals('Hello', $wrapper->translatedText);
        $this->assertTrue($wrapper->isSuccess);
    } // testTranslate

    public function testTranslateHtml() {
        $wrapper = new GoogleTranslateWrapper();
        $wrapper->googleTranslate('<br>Bonjour</br> Je suis un chat.', 'en', 'fr');
        // Note that Google Translate inserts spaces around the text in the tag
        $this->assertEquals('<br> Hello </br> I am a cat.', $wrapper->translatedText);
        $this->assertTrue($wrapper->isSuccess);
    } // testTranslateHtml

    public function testEmptyText() {
        $wrapper = new GoogleTranslateWrapper();
        $wrapper->googleTranslate('', 'en', 'fr');
        $this->assertFalse($wrapper->isSuccess);
    } // testEmptyText


    public function testEmptyTo() {
        $wrapper = new GoogleTranslateWrapper();
        $wrapper->googleTranslate('Bonjour', '', 'fr');
        $this->assertFalse($wrapper->isSuccess);
    } // testEmptyTo

    public function testEmptyFrom() {
        $wrapper = new GoogleTranslateWrapper();
        $translatedText = $wrapper->googleTranslate('Bonjour', 'en', '');
        $this->assertFalse($wrapper->isSuccess);
    } // testEmptyFrom

    public function testDetectMissingText() {
        $wrapper = new GoogleTranslateWrapper();
        $wrapper->googleDetectLanguage("");
        $this->assertFalse($wrapper->isSuccess);
    } // testDetectMissingText


    public function testDetectFrench() {
        $wrapper = new GoogleTranslateWrapper();
        $wrapper->googleDetectLanguage("mon chien");
        $this->assertEquals("fr", $wrapper->detectedLanguage);
        $this->assertTrue($wrapper->isSuccess);
    } // testDetectFrench

    public function testSplitChunks() {
        $wrapper = new GoogleTranslateWrapper();
        $s = "Now is the time for the quick brown fox to jump over the lazy dog.";
        $chunks = $wrapper->splitStringIntoChunks($s, 20);
        $newS = implode("", $chunks);
        $this->assertEquals($s, $newS);

        $s = "Nospacesinthisverylongstringsowillhavetosplititanyway";
        $chunks = $wrapper->splitStringIntoChunks($s, 20);
        $newS = implode("", $chunks);
        $this->assertEquals($s, $newS);

        $s = "short string";
        $chunks = $wrapper->splitStringIntoChunks($s, 20);
        $newS = implode("", $chunks);
        $this->assertEquals($s, $newS);

    } // testSplitChunks


    public function testTranslateChunks() {
        $wrapper = new GoogleTranslateWrapper();
        $wrapper->setChunkLength(20);
        $translatedText = $wrapper->googleTranslate('Bears eat honey and live in the woods. They are very big and dangerous.', 'fr', 'en');
        $this->assertTrue($wrapper->isSuccess);
        $this->assertEquals('Les ours mangent du miel et vivent dans les bois. Ils sont très gros et dangereux.', $wrapper->translatedText);
    } // testChunks

    public function testSplitDetect() {
        $wrapper = new GoogleTranslateWrapper();
        $newChunkLength = 22;
        $wrapper->setChunkLength($newChunkLength);
        $truncatedText = $wrapper->truncateOnSpace('Bears eat honey and live in the woods.', $newChunkLength);
        $this->assertEquals("Bears eat honey and", $truncatedText);
    } // testSplitDetect



} // GoogleTranslateWrapperTest
