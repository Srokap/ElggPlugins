<?php
 /**
 * @package livetranslate
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Mike Hedman
 * @copyright IntraPace, Inc.  2010
 */

	$english = array(
        'livetranslate:translate' => "Translate",
        'livetranslate:translations' => "Translations",
        'livetranslate:restore' => "Restore",

        'livetranslate:description:version' => "1",
        'livetranslate:description' => "The LiveTranslate feature translates member content, such as group topics and messages.<br><br>
The translations are performed through the Google Translate service.  As such, we do not guarantee that the translation of user content will be accurate, complete, or meaningful.  Please be aware that the translated words may not be the best representation of the original author's intent. In fact, sometimes the computer translated version can be quite humorous!",
        'livetranslate:description:title' => "Please read",
        'livetranslate:ok' => "OK",

        'livetranslate:api_key' => "API key",
        'livetranslate:translated_color_description' => "Select a color, in the form of a valid CSS color format: '#FCE6CF' (the default), or the word 'none' if you want no color.",
        'livetranslate:icon_parent' => "Default icon_parent element, in the form of a valid jQuery selector: '#searchform' (the default):",
        'livetranslate:branding_parent' => "Default branding_parent element, in the form of a valid jQuery selector: '#layout_footer' (the default):",
        'livetranslate:clear_cache' => "Clear Cache",
        'livetranslate:clear_cache_confirm' => "Are you sure you want to clear the Live Translate Cache?",
	);
					
	add_translation("en",$english);
