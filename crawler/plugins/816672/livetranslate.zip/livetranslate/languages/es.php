<?php
 /**
 * @package livetranslate
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Mike Hedman
 * @copyright IntraPace, Inc.  2010
 */

	$spanish = array(
        'livetranslate:translate' => "Traducir",
        'livetranslate:translations' => "Traducciones",
        'livetranslate:restore' => "Restaurar",
        'livetranslate:description' => "La función LiveTranslate traduce el contenido de los miembros, por ejemplo, los temas y mensajes en los grupos.<br><br>
Las traducciones se realizan a través del servicio Traductor de Google. Por lo tanto, no garantizamos que la traducción del contenido sea exacta, esté completa o resulte significativa. Tenga presente que puede que las palabras traducidas no reflejen perfectamente la intención del autor original. De hecho, a veces la versión traducida por ordenadores puede resultar cómica.",
        'livetranslate:description:title' => "Lea esto",
        'livetranslate:ok' => "Aceptar",
    );
					
	add_translation("es",$spanish);
