<?php
 /**
 * @package livetranslate
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Mike Hedman
 * @copyright IntraPace, Inc.  2010
 */

	$german = array(
        'livetranslate:translate' => "Übersetzen",
        'livetranslate:translations' => "Übersetzungen",
        'livetranslate:restore' => "Wiederherstellen",
        'livetranslate:description' => "Mit der LiveTranslate-Funktion werden Inhalte für Mitglieder übersetzt, z.&nbsp;B. Gruppenthemen und Nachrichten.<br><br>
Die Übersetzungen werden über den Google Übersetzerservice durchgeführt.  Daher können wir nicht garantieren, dass die Übersetzung des Benutzerinhalts genau, vollständig oder sinngemäß ist.  Beachten Sie bitte, dass die übersetzten Worte die Absicht des ursprünglichen Verfassers nicht unbedingt optimal wiedergeben. Es kann sogar sein, dass die vom Computer angefertigte Übersetzung etwas zum Lachen bietet!",
        'livetranslate:description:title' => "Bitte lesen",
        'livetranslate:ok' => "OK",
	);
					
	add_translation("de",$german);
