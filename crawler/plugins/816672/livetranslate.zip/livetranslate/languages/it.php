<?php
 /**
 * @package livetranslate
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Mike Hedman
 * @copyright IntraPace, Inc.  2010
 */

	$italian = array(
        'livetranslate:translate' => "Traduci",
        'livetranslate:translations' => "Traduzioni",
        'livetranslate:restore' => "Ripristina",
        'livetranslate:description' => "La funzionalità LiveTranslate traduce il contenuto degli iscritti, ad esempio gli argomenti e i messaggi dei gruppi.<br><br>
Le traduzioni si basano sul motore Google Translate e pertanto non se ne può garantire l'assoluta correttezza, completezza o comprensibilità. Tenere presente che la traduzione automatica può non riflettere correttamente il significato originale delle parole dell'autore al punto che, talvolta, il testo tradotto automaticamente può risultare addirittura comico!",
        'livetranslate:description:title' => "Avviso",
        'livetranslate:ok' => "OK",
	);
					
	add_translation("it",$italian);
