<?php
/**
 *  This file extends the groupforumtopic to auto-translate the group name and the topic
 *  
 * @package livetranslate
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Mike Hedman
 * @copyright IntraPace, Inc.  2011
 */

	$selectors = ".search_listing_info>p>a";
	addTranslator($selectors);
