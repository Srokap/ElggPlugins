<?php
/**
 *  This file extends the Profile display page to auto-translate the text and tags
 *  
 * @package livetranslate
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Mike Hedman
 * @copyright IntraPace, Inc.  2010
 */

$selectors = ".groupmembershipwidget .search_listing_info>p";
	addTranslator($selectors);
