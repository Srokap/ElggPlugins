<?php
/**
 *  This file extends the messages listing to auto-translate the subjects
 *  
 * @package livetranslate
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Mike Hedman
 * @copyright IntraPace, Inc.  2011
 */

	addTranslator('.actiontitle, .messagebody');
