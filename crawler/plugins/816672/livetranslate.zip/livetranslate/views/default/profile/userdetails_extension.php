<?php
/**
 *  This file extends the Profile display page to auto-translate the text and tags
 *  
 * @package livetranslate
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Mike Hedman
 * @copyright IntraPace, Inc.  2010
 */

	//#profile_info_column_middle>p>span:not(:has(a:visible)) - this is a tricky one, it selects the text which isn't an A tag, 
	// since if we did, it would prune off the A elements and just leave the text.  They are instead picked up in the next selector.
	$selectors = "#aboutme>p,#profile_info_column_middle>p>span:not(:has(a:visible)),#profile_info_column_middle>p>span>a";
	addTranslator($selectors);
