<?php
/**
 *  This file extends the Group sort menu (used on the main Groups page) to auto-translate the text and tags
 *  
 * @package livetranslate
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Mike Hedman
 * @copyright IntraPace, Inc.  2010
 */

$selectors[] = '#content_area_group_title h2';  //Group name
$selectors[] = '#groups_info_column_left #description>p'; //Group description
$selectors[] = '.group_properties:not(:has(a:visible)):not(#description)'; //Group items, excluding tags 
$selectors[] = '.group_properties>a'; //tags
$selectors[] = '.topic_title>p>a'; //topic title
addTranslator($selectors);    