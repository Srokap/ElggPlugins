<?php
	/**
     * IP Override
     * Extending original to wrap the group attributes in a div tag so they can be found by LiveTranslate
     * Also cleaning up the HTML structure by removing embedded <p> tag in description
     * 
	 * Elgg groups plugin full profile view.
	 *
	 * @package ElggGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider
	 * @copyright Curverider Ltd 2008-2010
	 * @link http://elgg.com/
	 */

	if ($vars['full'] == true) {
		$iconsize = "large";
	} else {
		$iconsize = "medium";
	}

?>

<div id="groups_info_column_right"><!-- start of groups_info_column_right -->
	<div id="groups_icon_wrapper"><!-- start of groups_icon_wrapper -->

		<?php
			echo elgg_view(
					"groups/icon", array(
												'entity' => $vars['entity'],
												//'align' => "left",
												'size' => $iconsize,
											)
					);
		?>

	</div><!-- end of groups_icon_wrapper -->
	<div id="group_stats"><!-- start of group_stats -->
		<?php

			echo "<p><b>" . elgg_echo("groups:owner") . ": </b><a href=\"" . get_user($vars['entity']->owner_guid)->getURL() . "\">" . get_user($vars['entity']->owner_guid)->name . "</a></p>";

		?>
		<p><?php echo elgg_echo('groups:members') . ": " . get_entities_from_relationship('member', $vars['entity']->guid, true, 'user', '', 0, '', 9999, 0, true); ?></p>
	</div><!-- end of group_stats -->
</div><!-- end of groups_info_column_right -->

<div id="groups_info_column_left"><!-- start of groups_info_column_left -->
	<?php
		if ($vars['full'] == true) {
			if (is_array($vars['config']->group) && sizeof($vars['config']->group) > 0){

				foreach($vars['config']->group as $shortname => $valtype) {
					if ($shortname != "name") {
						$value = $vars['entity']->$shortname;

						if (!empty($value)) {
							//This function controls the alternating class
							$even_odd = ( 'odd' != $even_odd ) ? 'odd' : 'even';
						}
                        //IP Override, beginning of modification
                        //using a <div> instead of a <p> since the description can contain <p> tags
						echo "<div class=\"{$even_odd}\">";
						echo "<b>";
						echo elgg_echo("groups:{$shortname}");
						echo ": </b>";

                        //end the description div early so it has a rounded right side
                        if ($shortname == 'description') {
                            echo "</div>";
                        }
						$options = array(
							'value' => $vars['entity']->$shortname
						);

						if ($valtype == 'tags') {
							$options['tag_names'] = $shortname;
						}

                        // create an id for the span from the shortname 
                        //the regex removes anything other than a character or number
                        $cleanId = preg_replace("/[^A-Za-z0-9]/", "", $shortname);
                        echo '<div class="group_properties" id="' . $cleanId . '">';
						echo elgg_view("output/{$valtype}", $options);
                        echo '</div>';
                        if ($shortname != 'description') {
                            echo "</div>";
                        }
                        //end of modification
					}
				}
			}
		}
	?>
</div><!-- end of groups_info_column_left -->

<div id="groups_info_wide">

	<p class="groups_info_edit_buttons">

<?php
	if ($vars['entity']->canEdit())
	{

?>

		<a href="<?php echo $vars['url']; ?>mod/groups/edit.php?group_guid=<?php echo $vars['entity']->getGUID(); ?>"><?php echo elgg_echo("edit"); ?></a>


<?php

	}

?>

	</p>
</div>
<div class="clearfloat"></div>