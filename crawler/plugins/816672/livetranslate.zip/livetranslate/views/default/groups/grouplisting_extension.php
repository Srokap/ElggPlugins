<?php
/**
 *  This file extends the grouplisting to auto-translate the text and tags
 *  
 * @package livetranslate
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Mike Hedman
 * @copyright IntraPace, Inc.  2010
 */

	$selectors = "div.groupdetails + p>b>a, div.groupdetails ~ p.owner_timestamp";
	addTranslator($selectors);
