<?php
/**
 * @package livetranslate
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Mike Hedman
 * @copyright IntraPace, Inc.  2010
 */

global $CONFIG;
?>

.livetranslate_selector, .livetranslate_exclusion{
    display: none;
}
.wasTranslated {
<?php
    $translated_color = get_plugin_setting('translated_color', 'livetranslate');
    if ($translated_color) {
        //if the plugin in setting has been set, use it, unless the admin wants 'none'
        if (strcasecmp('none', $translated_color) != 0) {
            echo 'background-color: ' . $translated_color . ' !important;';
        }    
    } else {
        //use the default
        echo 'background-color: ' . DEFAULT_TRANSLATED_COLOR . ' !important;';
    }
?>    
}

#translateButton {
    background: transparent url('<?php echo $CONFIG->url; ?>mod/livetranslate/graphics/bg_button_a.gif') no-repeat scroll top right;
    color: #444;
    display: block;
    float: left;
    /*font: normal 12px arial, sans-serif;*/
    height: 24px; 
    margin-top: -4px;
    margin-right: 20px; 
    padding-right: 18px; /* sliding doors padding */
    text-decoration: none;
    cursor: pointer;
}
/*keep backround image from shifting*/
#translateButton:hover {
	background-position: top right;
}
#translateButton span {
    background: transparent url('<?php echo $CONFIG->url; ?>mod/livetranslate/graphics/bg_button_span.gif') no-repeat;
    display: block;
    line-height: 14px;
    padding: 5px 0 5px 33px;
}
#translateButton:active {
    background-position: bottom right;
    color: #000;
    outline: none; /* hide dotted outline in Firefox */
}
#translateButton:active span {
    background-position: bottom left;
    padding: 6px 0 4px 33px; /* push text down 1px */
}
#groups_info_column_left .odd, .even {
	margin-bottom: 7px;    
}
.group_properties {
    display: inline;
}
