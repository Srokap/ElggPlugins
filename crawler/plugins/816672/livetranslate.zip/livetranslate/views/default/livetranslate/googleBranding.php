<?php
/**
 * googleBranding.php 
 * View to draw the Google branding elements.  Gets passed into translate.js for display
 * 
 * Note: this MUST return only one line, so JavaScript will be able to handle it as a string.
 *  
 * @package livetranslate
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Mike Hedman
 * @copyright IntraPace, Inc. 2011
 */
?>
<span id="brandWrapper" style="display:none"><?php echo elgg_echo('livetranslate:translations'); ?><br/><span id="GoogleBrand"><a href="http:translate.google.com/"><img src="<?php echo $vars['url']; ?>mod/livetranslate/graphics/attr1.png"/></a></span></span>