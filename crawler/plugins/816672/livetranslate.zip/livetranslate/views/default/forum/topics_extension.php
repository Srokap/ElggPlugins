<?php
/**
 *  This file extends the group forum topics page to auto-translate the topic titles
 *  
 * @package livetranslate
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Mike Hedman
 * @copyright IntraPace, Inc.  2010
 */

	$selectors = ".search_listing_info p a";
	addTranslator($selectors);
