<?php
/**
 * This file extends the group topicposts page to auto-translate the topic title and the postings
 *  
 * @package livetranslate
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Mike Hedman
 * @copyright IntraPace, Inc.  2010
 */

	$selectors = "td[width='70%'], #content_area_group_title h2";
	addTranslator($selectors);
