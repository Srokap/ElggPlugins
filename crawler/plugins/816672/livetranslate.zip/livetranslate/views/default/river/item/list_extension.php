<?php
/**
 *  This file extends the River list to auto-translate the text of group related items
 *  
 * @package livetranslate
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Mike Hedman
 * @copyright IntraPace, Inc.  2010
 */

	$selectors[] = '.river_content_display';  //the body of a river post
    $selectors[] = '.river_object_groupforumtopic_create a:nth-child(2)'; //name of the topic 
    $selectors[] = '.river_group_join a:nth-child(2)'; //name of joined group
    $exclusions[] = '.river_user_friend .river_content_display'; //exlcude friendship creation notifications
	addTranslator($selectors, $exclusions);