<?php
/**
 * This view is used to display the LiveTranslate description to the user
 * This should be displayed the first time a user uses the feature.
 * 
 */
echo '<img src="' . $vars['url'] . 'mod/livetranslate/graphics/alert.png">&nbsp;&nbsp;';
echo elgg_echo('livetranslate:description');