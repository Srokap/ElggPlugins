<?php
/**
 * livetranslate plugin settings view
 *  
 * @package livetranslate
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Mike Hedman
 * @copyright IntraPace, Inc. 2011
 */

$api_key = $vars['entity']->api_key;

$translated_color = $vars['entity']->translated_color;
if (!$translated_color) {
    $translated_color = DEFAULT_TRANSLATED_COLOR;
}
$icon_parent = $vars['entity']->icon_parent;
if (!$icon_parent) {
    $icon_parent = DEFAULT_ICON_PARENT;
}    
$branding_parent = $vars['entity']->branding_parent;
if (!$branding_parent) {
    $branding_parent = DEFAULT_BRANDING_PARENT;
}    

echo '<p>'; 
echo elgg_echo('livetranslate:api_key');
echo '<br>';
echo elgg_view('input/text', array(
    'internalname' => 'params[api_key]',
    'value' => $api_key
));

echo '<p>'; 
echo elgg_echo('livetranslate:translated_color_description');
echo '<br>';
echo elgg_view('input/text', array(
    'internalname' => 'params[translated_color]',
    'value' => $translated_color
));

echo '<br>';    
echo elgg_echo('livetranslate:icon_parent');
echo '<br>';
echo elgg_view('input/text', array(
    'internalname' => 'params[icon_parent]',
    'value' => $icon_parent
));    

echo '<br>';    
echo elgg_echo('livetranslate:branding_parent');
echo '<br>';
echo elgg_view('input/text', array(
    'internalname' => 'params[branding_parent]',
    'value' => $branding_parent
));    


// clear cache button
global $CONFIG;
echo '<script type="text/javascript" charset="utf-8">';
echo ' var elggUrl = "' . $CONFIG->url . '";';
echo ' var clearCacheConfirmString = "' . elgg_echo('livetranslate:clear_cache_confirm') . '";';
echo '</script>';
echo '<script src="' . $CONFIG->url. 'mod/livetranslate/javascript/translate.js?version=1.0" type="text/javascript" charset="utf-8"></script>';
echo '<br>';
echo elgg_view('input/button', array('value' => elgg_echo('livetranslate:clear_cache'),
                                     'type' => 'button',
                                     'js' => 'onclick="clearLiveTranslateCache()"',
                                    ));
echo '<br>';



echo '</p>';
