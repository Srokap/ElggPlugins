<?php
/**
  * TranslatedText.php
  * Encapsulation of a piece of translated text
  * @author Tristan Colson/ IntraPace, Inc.
  * @link http://intrapace.com
  */

class TranslatedText extends ElggObject {

    function __construct($guid = null) {
        parent::__construct($guid);
    }

    protected function initialise_attributes() {
        parent::initialise_attributes();
        $this->attributes['subtype'] = 'translatedtext';
        $this->attributes['access_id'] = ACCESS_PUBLIC;
    }

    /**
      * This is the 'real' constructor that will create a new piece of translated text
      * @param string $text   The translated text
      * @param string $lang   The language code for the text
      * @param string $transType   "o for original text, "t" for translated text
      * @param integer $containerGuid   Guid of the container object (e.g. the original text)
      * @return the object created
      */
    public static function addToCache($text, $lang, $transType, $containerGuid=null) {
        // do not add if it already exists
        $cacheItem = self::getFromCache($text, $transType, $lang, $containerGuid);
 
        if (!$cacheItem) {
            $cacheItem = new self();
            if ($containerGuid != null) {
                $cacheItem->container_guid = $containerGuid;
            }
            $cacheItem->save();
            $cacheItem->text = $text;
            $cacheItem->lang = $lang;
            $cacheItem->trans_type = $transType;
        }
        return $cacheItem;
    } // addToCache

    /**
      * Get the translatedtext entity from the cache if it exists
      * @param string $text   The translated text
      * @param string $lang   The language code for the text
      * @param string $transType   "o for original text, "t" for translated text
      * @param integer $containerGuid   Guid of the container object (e.g. the original text)
      * @return the object found, or FALSE if not found
      */
    public static function getFromCache($text, $transType, $lang=null, $containerGuid=null) {

        $metaArray = array('trans_type' => $transType);
        if ($transType == ORIGINALTEXT_TYPE) {
            $metaArray['text'] = $text;
        }
        if ($lang != null) {
            $metaArray['lang'] = $lang;
        }
        $optionsArray = array(
                           'metadata_name_value_pairs' => $metaArray,
                           'types' => 'object',
                           'subtypes' => 'translatedtext',
                           'limit' => '99999',
                           );
        if ($containerGuid != null) {
            $optionsArray['container_guid'] = $containerGuid;
        }

        $cachedEntities = elgg_get_entities_from_metadata($optionsArray);
        if (!$cachedEntities) {
            return false;
        }
 
        // we should never find more than one matching cached translation
        // but if we do, we'll treat it as non-fatal
        if (count($cachedEntities) > 1) {
            error_log("ERROR: Found more than one cached translation $transType/$lang/$text/$containerGuid");
        }
        $cacheItem = $cachedEntities[0];

        return $cacheItem;
    } // getFromCache

    /**
      * Expire the cache entries
      * @param integer $expirationTime  Cache entries older than this should be expired
      *                                 If null, expire all entries
      */
    public static function expireFromCache($expireTime) {

        $options = array('type' => 'object',
                         'subtype' => 'translatedtext',
                         'limit' => 99999);

        if ($expireTime != null) {
            $options['created_time_upper'] = $expireTime;
        }
        
        $cacheItems = elgg_get_entities($options);
        if ($cacheItems) {
            foreach ($cacheItems as $c) {
                $c->delete(); // will delete any children as well
            }
        }
    } // expireFromCache

    /**
      * Get all the entries in the cache (used for testing only)
      * @param string $trans_type type of entries to get
      * @return list of cached entries 
      */
    public static function getAllFromCache($transType=null) {

        if ($transType == null) {
            $options = array('type' => 'object',
                             'subtype' => 'translatedtext',
                             'limit' => 99999);
            $cacheItems = elgg_get_entities($options);
            if (!$cacheItems) {
                return array();
            }
            return ($cacheItems);
        }
        else {
            $metaArray = array('trans_type' => $transType);
            $optionsArray = array(
                               'metadata_name_value_pairs' => $metaArray,
                               'types' => 'object',
                               'subtypes' => 'translatedtext',
                               'limit' => '99999',
                           );
            $cachedEntities = elgg_get_entities_from_metadata($optionsArray);
            if (!$cachedEntities) {
                return array();
            }
 
            return $cachedEntities;

        }

    } // getAllFromCache

    /**
      * Get the translations (e.g. the children) of this cache entry
      * @param object $cacheEntry the cache entry
      * @return list of cached entries that are children of this one
      */
    public static function getChildren($cacheEntry) {
        $options = array('type' => 'object',
                         'subtype' => 'translatedtext',
                         'limit' => 99999,
                         'container_guid' => $cacheEntry->guid);

        $cacheChildren = elgg_get_entities($options);
        if ($cacheChildren) {
            return $cacheChildren;
        }
        else {
            return array();
        }

    } // getChildren

} // TranslatedText


