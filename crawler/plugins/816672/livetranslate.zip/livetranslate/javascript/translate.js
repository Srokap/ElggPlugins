/**
 * livetranslate
 *  
 * @package livetranslate
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Mike Hedman, Tristan Colson
 * @copyright IntraPace, Inc.  2011
 */
var TRANSLATE = 1;
var PROCESSING = 2;
var RESTORE = 3;
var state = TRANSLATE;
var ALTERNATE_TEXT = 'ALTERNATE_TEXT';

// These are also defined in php in TranslationController.php
var TRANSLATE_STATUS_OK = 1;
var TRANSLATE_STATUS_ERROR = -1;
var TRANSLATE_STATUS_NOTRANSLATE = 0;


function clearLiveTranslateCache() {
    if (confirm(clearCacheConfirmString)) {
        var clearCacheUrl = elggUrl + "mod/livetranslate/clearcache.php";
        $.ajax({
              url: clearCacheUrl,
              datatype: 'html',
              async: false,
              success: function(data){
              }
            });

    }
} // clearLiveTranslateCache

function collectSelectors(selectorId) {
    var selectorsArray = [];
    $(selectorId).each( function() {
        var selector = $(this).text();
        //only add each selector once - so make sure we haven't already added this one
        var selectorFound = false;
        for (var i=0; i<selectorsArray.length; i++) {
            if (selectorsArray[i] == selector) {
                selectorFound = true;
                break;
            }
        }
        if (! selectorFound) {
            selectorsArray.push(selector);
        }
    });
    return selectorsArray.toString();	
}

function translate() {
    if (showDescription) {
        displayDescription();
        showDescription = false;
    }

    // we will store the text strings to be translated here, as keys to an array
    // where the value is a list of DOM objects that contain the text
    var textStrings = new Object();

    switch (state) {
    case TRANSLATE:
        // text needs to be translated
        state = PROCESSING;
        //collect selectors
        var selectors = collectSelectors('.livetranslate_selector');
        var exclusions = '.livetranslate_nevertranslate,' + collectSelectors('.livetranslate_exclusion');

        // handle translation for each piece of text
        // we will collect the text first and then go back and translate it so that
        // if there are duplicates on the page we don't translate them multiple times
        $(selectors).not(exclusions).each(function() {           
            var $field = $(this);	
            var originalText;
            // text has already been translated once, and is stored locally
            if (typeof $field.data(ALTERNATE_TEXT) != "undefined") {
                originalText = $field.html();
                $field.html($field.data(ALTERNATE_TEXT));
                $field.data(ALTERNATE_TEXT, originalText);
                $field.addClass("wasTranslated");                
            } 
            else {    
                originalText = $.trim($field.html());
                // save the text in the list of strings to be translated
                if (originalText != '') {
                    if (typeof(textStrings[originalText]) == "undefined") {
                        textStrings[originalText] = new Array(); 
                    }
                    textStrings[originalText].push($field);
                }
            }
        });  // each


        for (var oText in textStrings) { 
            // submit the text for translation                    
            $.ajax({
                url: elggUrl + "mod/livetranslate/translate.php",
                dataType: 'json',
                data: "v=2.0&q=" + encodeURIComponent(oText),
                async: true, 
                success: function (translateData) {
                    // for each field that contains the text
                    var fields = textStrings[translateData.text];
                    for (var i = 0; i < fields.length; i++) {
                        var $field = fields[i];
                        if (translateData.status == TRANSLATE_STATUS_OK) {
                            $field.data(ALTERNATE_TEXT, translateData.text);
                            $field.html(translateData.translatedText);
                            $field.addClass("wasTranslated");
                        }
                        else if (translateData.status == TRANSLATE_STATUS_NOTRANSLATE) {
                            // set this text as excluded so we don't try to translate it 
                            $field.addClass("livetranslate_nevertranslate");
                        }
                        else {
                           // for error, do nothing, maybe it will work the next time
                        }
                    }
                }
            });
        };
	state = RESTORE;        
	$("#translateButton>span").text(restoreTitle);
	$("#brandWrapper").show();
        break;

    case PROCESSING:
        //do nothing
        break;

    case RESTORE:
        // restore the original text
        $(".wasTranslated").each(function(){
            var translatedText = $(this).html();
            $(this).html($(this).data(ALTERNATE_TEXT));
            $(this).data(ALTERNATE_TEXT, translatedText);
            $(this).removeClass("wasTranslated");
        });
	
        state = TRANSLATE;
        $("#translateButton>span").text(translateTitle);
    } //switch (state)
} // translate

/**
 * Inject the icon into the icon_parent element, and the Google Branding element
 */
$(document).ready(function(){
    //add the translate button if it's not already there
	if ($('#translateButton').length==0 && typeof icon_parent != "undefined") {
		//the variables not declared here will have been written out by PHP
        $(icon_parent).prepend(translateButton);

        $("#translateButton").click(function() {
            translate(); 
        });

        //branding is initially hidden, shown when translation is performed
        $(branding_parent).append(branding);
    }
});	

function displayDescription() {
    var dialogDiv = '<div id="livetranslate_description" title="' + descriptionTitle + '" style="display:none"></div>'
    var $dialog = $(dialogDiv).appendTo('body');
    $dialog.load(
        elggUrl + 'mod/livetranslate/showDescription.php', 
        {},
        function (responseText, textStatus, XMLHttpRequest) {
            var dialogButtons = {};
            dialogButtons[okButtonText] = function(){ 
                $.ajax({url: elggUrl + 'mod/livetranslate/recordVersion.php'}); 
                $(this).dialog('close');
            }
            $dialog.dialog({ modal: true,
                             buttons: dialogButtons,
                             closeOnEscape: false,
                             open: function(event, ui) {
                                 $(this).closest('.ui-dialog').find('.ui-dialog-titlebar-close').hide(); 
                             }

            });
        }
    );
}
