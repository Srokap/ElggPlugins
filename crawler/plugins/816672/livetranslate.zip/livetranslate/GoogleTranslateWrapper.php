<?php
/**
 * GoogleTranslateWrapper
 * This class is based upon the class described in the next comment block
 * This version has been modified to use version 2 of the Google Translate API
 * It has also been trimmed down to only provide functionality needed for LiveTranslate
 *  
 * @package livetranslate
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Mike Hedman
 * @copyright IntraPace, Inc. 2011
 */

/**
 * This class is based upon (modified to work with REST calls)
 * (source downloaded from: http://code.google.com/p/google-translate-php-wrapper/source/browse/trunk/googleTranslate.class.php?spec=svn13&r=13)
 * GoogleTranslateWrapper: PHP wrapper for Google Translation services
 * Copyright (C) 2010  Sameer Borate
 * 
 * GoogleTranslateWrapper is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * GoogleTranslateWrapper is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with GoogleTranslateWrapper; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @category    GoogleTranslateWrapper 
 * @package     GoogleTranslateWrapper
 * @author      Sameer Borate
 * @copyright   2010 Sameer Borate
 */

define ("GOOGLE_TRANSLATE_URL", 'https://www.googleapis.com/language/translate/v2');
define ("GOOGLE_DETECT_URL", 'https://www.googleapis.com/language/translate/v2/detect');

class GoogleTranslateWrapper
{
    /**
     * The Google API key, which is pulled from plugin settings in the constructor
     * @var string
     */
    private $api_key;
    
    /**
     * Language to translate from
     * @var string
     */
    public $fromLang = '';
    
    /**
     * Language to translate to
     * @var string
     */
    public $toLang = '';
    
    /**
     * Text to translate
     * @var string
     */
    public $text = '';
    
    /**
     * Max length of a chunk of text to be translated
     * @var integer
     */
    public $chunkLength;

    /**
     * Translated Text
     * @var string
     */
    public $translatedText;
    
    /**
     * Detected Language
     * @var string
     */
    public $detectedLanguage;

    public $confidentDetection = false; 

    /**
     * Whether the translation was a success (false if an error of any kind returned)
     */
    public $isSuccess = true;


    const DETECT = 1;
    const TRANSLATE = 2;
    const GOOGLE_MAXSTRLENGTH = 5000; // max number of chars that can be translated at one time, with a post
    
    
    /**
     * Constructor
     */
    public function __Construct() {
        $this->chunkLength = self::GOOGLE_MAXSTRLENGTH;
        $this->api_key = get_plugin_setting('api_key', 'livetranslate');
    }

    /**
     * Used in unit tests so we don't have to test with 5000 characters
     */
    public function setChunkLength($chunkLength) {
        $this->chunkLength = $chunkLength;
    } // setChunkLength
    

    /**
     * Send the request to Google
     * 
     * @param string $params query parameters
     * @param int $queryType Specifies whether this is a Translate or a Detect query
     * @return string The response from Google or FALSE if error
     */
    protected function remoteQuery($queryType = self::TRANSLATE)
    {
        global $CONFIG;
        if(!function_exists('curl_init'))
        {
            error_log('LiveTranslate error: cURL not installed.');
            return false; 
        }

        if ($queryType == self::TRANSLATE)
        {
            $params = array('q'           => $this->text,
                            'source'      => $this->fromLang,
                            'target'      => $this->toLang,
                            'key'         => $this->api_key,
                            'prettyprint' => 'false',
                            'format'      => 'html');
        }
        else if ($queryType == self::DETECT)
        {
            $params = array('q'           => $this->text,
                            'key'         => $this->api_key,
                           );
        }

        $postParams = http_build_query($params, '', "&");

        /* Setup CURL and its options*/
        $ch = curl_init();

        $url = ($queryType == self::DETECT) ? GOOGLE_DETECT_URL : GOOGLE_TRANSLATE_URL;
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_REFERER, $CONFIG->wwwroot);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('X-HTTP-Method-Override: GET') );
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        }
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postParams);

        $contents = curl_exec($ch); 
        $response = curl_getinfo($ch);
        if ($response['http_code'] == 200) {
            return $contents;
        }
        else {
            error_log("LiveTranslate error: call to $url failed with error code " . $response['http_code']);
            error_log("Post params are " . print_r($postParams, true));
            return false;
        }
    } // remoteQuery
    
    
    /**
     * Translate the given text
     * @param string $text text to translate
     * @param string $to language to translate to
     * @param string $from language to translate from
     * @return no explicit return value, but isSuccess flag is set in the object
     */
    public function googleTranslate($text, $to, $from)
    {
        // error if we are missing parameters
        if (!isset($text) || strlen($text) == 0 || !isset($to) || strlen($to) == 0||
                !isset($from) || strlen($from) == 0) {
            $this->isSuccess = false;
            return;
        }

        $textChunks = array();
        if (strlen($text) > $this->chunkLength) {
            $textChunks = $this->splitStringIntoChunks($text, $this->chunkLength);
        }
        else {
            $textChunks[] = $text;
        }
        $this->toLang = $to;
        $this->fromLang = $from;


        foreach ($textChunks as $chunk) {
            $this->text = $chunk;

            // google translate seems to strip whitespace from the translation, so we need to remember it
            $hasInitialSpace = ($this->text[0] == " ");
            $hasTrailingSpace = ($this->text[strlen($this->text)-1] == " ");

            $contents = $this->remoteQuery(self::TRANSLATE);
            if ($contents === false) {
                $this->isSuccess = false;
                return;
            }
            $json = json_decode($contents, true);
            $this->translatedText .= ($hasInitialSpace ? " " : "") . $json['data']['translations'][0]['translatedText'] . ($hasTrailingSpace ? " " : "");
        }

        $this->isSuccess = true;
        return;
    } // translate
    
    /**
     * Detect the language of the given text
     * @param string $text text language to detect
     * @return no explicit return value, but isSuccess and confidentDetection are set in the object
     */
    public function googleDetectLanguage($text)
    {
        if(strlen($text) == 0) {
            $this->isSuccess = false;
            return;
        }

        // just use the first chunk of characters to detect the language
        if (strlen($text) > $this->chunkLength) {
            $this->text = $this->truncateOnSpace($text, $this->chunkLength);
        }
        else {
            $this->text = $text;
        }
        
              
        $contents = $this->remoteQuery(self::DETECT);
        if ($contents === false) {
            $this->isSuccess = false;
            return;
        }

        $json = json_decode($contents, true);
        $this->detectedLanguage = $json['data']['detections'][0][0]['language'];
        $this->confidentDetection = ($json['data']['detections'][0][0]['confidence'] > 0);
        $this->isSuccess = true;
        return;
            
    } // detectLanguage


    /**
     * Split the string into chunks, no larger than the max allowed size
     * broken on a space if possible
     * @param string $text text   the string of text
     * @param int $maxLength maxLength   max length of a chunk
     * @return array of strings
     */
    public function splitStringIntoChunks($text, $maxLength) {
        $chunks = array();
        $done = false;
        do {
            // remaining string shorter than length of a chunk
            if (strlen($text) < $maxLength) {
                $done = true;
                $chunks[] = $text;
            }
            else {
                $t = substr($text, 0, $maxLength);
                $spacePos = strrpos($t, ' ');
 
                // there were no spaces in this chunk
                if ($spacePos === false) { 
                    $chunks[] = $t;
                    $text = substr($text, $maxLength);
                }
                else {
                    $t = substr($t, 0, $spacePos+1);
                    $chunks[] = $t;
                    $text = substr($text, $spacePos+1);
                }
            }
        } while (!$done);
        
        return $chunks;


    } // splitStringIntoChunks

    /**
     * Return the substring of the string up to the last space
     * @param string $text the string of text
     * @param int $chunkLength  max length of one chunk
     * @return string
     */
    public function truncateOnSpace($text, $chunkLength) {
        $text = substr($text, 0, $chunkLength);
        $spacePos = strrpos($text, ' ');
        // there were no spaces in this chunk
        if ($spacePos === false) { 
            return $text;
        }
        else {
            $newText = substr($text, 0, $spacePos);
            return $newText;
        }
    } // truncateOnSpace


} // GoogleTranslateWrapper
