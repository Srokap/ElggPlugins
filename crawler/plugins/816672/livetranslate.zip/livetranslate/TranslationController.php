<?php
/**
 * TranslationController
 * @package livetranslate
 * @author Tristan Colson
 * @copyright IntraPace, Inc. 2011
 */

require_once("GoogleTranslateWrapper.php");
require_once("TranslatedText.php");

define ("ORIGINALTEXT_TYPE", "o");
define ("TRANSLATEDTEXT_TYPE", "t");

define ("STATUS_OK", 1);
define ("STATUS_ERROR", -1);
define ("STATUS_NOTRANSLATE", 0);

class TranslationController extends GoogleTranslateWrapper {

    public $status;  // return the status of the translation
    
    /**
     * Translate the given text
     * @param string $text text to translate
     * @param string $targetLanguage the target language
     * @return json encapsulation of TranslationController object
     */
    public function translate($text, $targetLanguage) {

        $this->text = $text;

        if (!$text || strlen($text) == 0 || !$targetLanguage || strlen($targetLanguage) == 0) {
            $this->status = STATUS_NOTRANSLATE;
            return (json_encode($this));
        }

        // check to see if the text is in the translation cache
        list($cacheStatus, $cachedText) = $this->getTextFromCache($text, $targetLanguage);

        // text was found in the cache
        if ($cacheStatus == STATUS_OK) { 
            $this->translatedText = $cachedText;
            $this->status = STATUS_OK;
            return (json_encode($this));

        }
        else if ($cacheStatus == STATUS_NOTRANSLATE) {
            $this->status = STATUS_NOTRANSLATE;
            return (json_encode($this));
        }
        // text not found in cache
        else { 
            $this->googleDetectLanguage($text);
            // unable to detect the language, just return the original text
            if (!$this->isSuccess) {
                $this->status = STATUS_ERROR;
                return json_encode($this);
            }

            // if Google had no confidence in the translation, don't try to translate it
            if (!$this->confidentDetection) {
                $this->status = STATUS_NOTRANSLATE;
                return (json_encode($this));
            }

            // no translation necessary
            if ($this->detectedLanguage == $targetLanguage) {
                $this->status = STATUS_NOTRANSLATE;
                TranslatedText::addToCache($text, $this->detectedLanguage, ORIGINALTEXT_TYPE);
                return json_encode($this);
            }

            // perform the translation
            $this->googleTranslate($text, $targetLanguage, $this->detectedLanguage);
            if (!$this->isSuccess) {
                $this->status = STATUS_ERROR;
                return (json_encode($this));
            }
            $this->status = STATUS_OK;

            // save the translation in the translation cache
            $originalText = TranslatedText::addToCache($text, $this->detectedLanguage, ORIGINALTEXT_TYPE);
    
            TranslatedText::addToCache($this->translatedText, $targetLanguage, TRANSLATEDTEXT_TYPE, $originalText->guid);

            return json_encode($this);
        }
        
    } // translate


    /**
     * Check if the text string is in the cache
     * @param string $text text to look up in the cache
     * @param string $lang language to look up 
     * @return  array (status, text) where ok=found in cache, error=not found in cache, notranslate = no translation needed
     */
    private function getTextFromCache($text, $targetLanguage) {

        // look up the original text in the cache, without specifying language
        // to see if it has ever been translated before
        $originalTranslation = TranslatedText::getFromCache($text, ORIGINALTEXT_TYPE, null, null);

        // the text has been translated in some languages
        if ($originalTranslation) {
            // if the language is the same as the current language, just return this text
            if ($originalTranslation->lang == $targetLanguage) {
                return array(STATUS_NOTRANSLATE, $originalTranslation->text);
            }
            else {
                // is there a child of this text with the translation in the current language?
                $childTranslation = TranslatedText::getFromCache($text, TRANSLATEDTEXT_TYPE, $targetLanguage, $originalTranslation->guid);
                if ($childTranslation) {
                    return array(STATUS_OK, $childTranslation->text);
                }          
                return array(STATUS_ERROR, null);
            }
        }
        else {
            return array(STATUS_ERROR, null);
        }

    } // getTextFromCache
    
} // TranslationController
