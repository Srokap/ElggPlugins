<?php

/**
 * recordVersion.php
 * 
 * Called by ajax when the user clicks the OK button after viewing the description.
 *  
 * @package livetranslate
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Mike Hedman
 * @copyright IntraPace, Inc. 2011
 */

// Load Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

//mark this user as having seen the description
$user = get_loggedin_user();
$user->LiveTranslateDescriptionVersion = elgg_echo('livetranslate:description:version');
