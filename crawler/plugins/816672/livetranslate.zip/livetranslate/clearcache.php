<?php

/**
 * clearcache.php
 *  
 * @package livetranslate
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Tristan Colson
 * @copyright IntraPace, Inc. 2011
 */

// Load Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
require_once dirname(__FILE__) . '/TranslatedText.php';

if (isadminloggedin()) {
    TranslatedText::expireFromCache(null);
}



