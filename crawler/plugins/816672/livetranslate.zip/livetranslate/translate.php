<?php

/**
 * translate.php
 *  
 * @package livetranslate
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Mike Hedman
 * @copyright IntraPace, Inc. 2011
 */

// Load Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
require_once dirname(__FILE__) . '/TranslationController.php';

$originalText = get_input('q');
$targetLanguage = get_current_language();
if ($targetLanguage == "en-gb") {
    $targetLanguage = "en";
}
$wrapper = new TranslationController();
echo $wrapper->translate($originalText, $targetLanguage);


