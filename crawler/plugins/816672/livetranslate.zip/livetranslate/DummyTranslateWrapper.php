<?php
/**
 * DummyTranslateWrapper
 * To be used only for testing
 */

class DummyTranslateWrapper
{
    /**
     * Language to translate from
     * @var string
     */
     public $fromLang = '';
    
    /**
     * Language to translate to
     * @var string
     */
    public $toLang = '';
    
    /**
     * Text to translate
     * @var string
     */
    public $originalText = '';
    
    /**
     * Site url using the code
     * @var string
     */
    public $siteUrl = '';
    
    /**
     * POST fields
     * @var string
     */
    public $postParams;
    
    /**
     * Max length of a chunk of text to be translated
     * @var integer
     */
    public $chunkLength;

    /**
     * Translated Text
     * @var string
     */
    public $translatedText;
    
    /**
     * Detected Language
     * @var string
     */
    public $detectedLanguage;

    /**
     * Whether the translation was a success (false if an error of any kind returned)
     * In an error case, the translatedText will contain the original text
     * @var string
     */
    public $isSuccess = true;


    const DETECT = 1;
    const TRANSLATE = 2;
    const GOOGLE_API_KEY = 'AIzaSyCnNxTuYk-RaVSOIdxeVuZFVbjMFYPET9o';
    const GOOGLE_MAXSTRLENGTH = 5000; // max number of chars that can be translated at one time, with a post
    
    
    /**
     * Constructor
     */
    public function __Construct() {
        global $CONFIG;
        $this->siteUrl = $CONFIG->wwwroot;
        $this->chunkLength = self::GOOGLE_MAXSTRLENGTH;
    }

    /**
     * Used in unit tests so we don't have to test with 5000 characters
     */
    public function setChunkLength($chunkLength) {
        $this->chunkLength = $chunkLength;
    } // setChunkLength
    
    
    /**
     * Translate the given text
     * @param string $originalText text to translate
     * @param string $to language to translate to
     * @param string $from language to translate from
     * @return boolean false if error, true if success
     */
    public function googleTranslate($originalText, $to, $from)
    {
        // error if we are missing parameters
        if($originalText == '' || $to == '' || $from == '') {
            $this->translatedText = $originalText;
            $this->isSuccess = false;
            return;
        }

        $textChunks = array();
        if (strlen($originalText) > MAXSTRLENGTH) {
            // TODO - split at whitespace or a sentence break
            $textChunks = str_split($originalText, $this->chunkLength);
        }
        else {
            $textChunks[] = $originalText;
        }
        $this->toLang = $to;
        $this->fromLang = $from;


        foreach ($textChunks as $chunk) {
            $this->originalText = $chunk;

            if ($to == "en") {
                $this->translatedText .= "Good Cat";
            }
            else if ($to == "fr") {
                $this->translatedText .= "Bon Chat";
            }
            else if ($to == "de") {
                $this->translatedText .= "Gute Katze";
            }
            else if ($to == "es") {
                $this->translatedText .= "Buen Gato";
            }
            else {
                $this->translatedText .= "Translation Unknown";
            }

        }
        $this->isSuccess = true;
        return;
    } // googleTranslate
    
    /**
     * Detect the language of the given text
     * @param string $originalText text language to detect
     */
    public function googleDetectLanguage($originalText)
    {
        if(strlen($originalText) == 0) {
            $this->translatedText = $text;
            $this->isSuccess = false;
            return;
        }

        $this->isSuccess = true;
        if (strpos($originalText, "Bon Chat") !== FALSE) {
            $this->detectedLanguage = "fr";
        }
        else if (strpos($originalText, "Gute Katze") !== FALSE) {
            $this->detectedLanguage = "de";
        }
        else if (strpos($originalText, "Buen Gato") !== FALSE) {
            $this->detectedLanguage = "es";
        }
        else if (strpos($originalText, "Good Cat") !== FALSE) {
            $this->detectedLanguage = "en";
        }
        else if (strpos($originalText, "this is an error") !== FALSE) {
            $this->isSuccess = false;
        }
        else {
            $this->detectedLanguage = "en";
        }

        return;
            
    } // googleDetectLanguage
}
