/**
 * livetranslate
 *  
 * @package livetranslate
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Mike Hedman and Tristan Colson
 * @copyright IntraPace, Inc.  2011
 * @version 1.0
 */

About the livetranslate plugin.
This plugin provides a framework that can be used to add a live translation service to Elgg.  This is "live" in that it is not intended to be used for the static parts of a page (where you would use Elgg's existing language system), but rather for translating user provided data, such as in Groups.

AUDIENCE - It is presumed that users of this plugin understand Elgg, plugins, and jQuery.  If you don't, you REALLY don't want to use this plugin!!

INSTALLATION:
 - Just unzip the contents into the \mod directory, and enable the plugin in the Administration | Tools Administration page.
 - You MUST enter your Google API key in the plugin settings screen on the Administration | Tools Administration page. 

USE:
- To add translation to your own pages, you need to add something similar to the following:
 	  $selectors = "td[width='70%'] p, #content_area_group_title h2";
	  addTranslator($selectors);
   In this example we're saying that we want to translate all <p> tags within table rows that are 70% wide (these are group postings), and also <h2> elements in the group title.
   It is also possible to add an array of selectors.
   
 - To add translations to other people's pages, you need to extend their views.  The livetranslate plugin includes view extensions for adding live translation to some of the Groups views.  Look in the views\default directories for examples, and the associated extend_view() calls in start.php.

USER FLOW -  Page loads, user clicks on the translate icon, text of the selected controls is replaced with translated text.  Translate icon switches to a Restore icon.  If user clicks Restore the original text is replaced.  

BRANDING - This plugin utilizes the Google Translate API - so it's not "Free".  It doesn't cost money, but it does cost some screen real estate.  By default, the plugin will display Google's required branding once the user chooses to translate a page.  The branding is attached to the layout_footer by default - but you can specify a different location.

TESTING - We make use of the "Unit Test Runner" plugin by Timothy Wall.  The TestLiveTranslateGui test uses an internal Selenium test structure that we're just now getting going.

THANKS! 
 - (as of v1.0, no longer using this icon) Thanks to Casey Bisson for granting permission to use his "translate" icon.  http://maisonbisson.com/blog/
 - The alert.png image was obtained through http://www.veryicon.com/icon/32/Application/Crystal%20Project%20Application/alert.png

CHANGELIST:
 v0.2
	- Changed the look of the Translate icon
	- Changed the location of the icon, it's now always next to the Search box (it was hard to find a consistent place within different views).
	- Added extension for Profile.  
	- Added fuller support for the various places a Group description, brief description, and topics show up.
	- Revised the JavaScript generation to better account for dealing with one page with multiple views with translation extensions.
	- I started adding support for the Group Membership widget, but since it loads through Ajax, all the JavaScript gets doubled up.  Need to come up with a clean solution for this (the static variables in addTranslator() aren't enough.
 v1.0
	- Added server side caching
      - Added client side caching of individual translations, so clicking the translation button just restores the prior results (this is not a cookie kind of cache, just for the current pageload)
      - Added exclusion selectors, in case your selectors are too greedy.
	- Can now pass in an array of selectors or exclusion selectors. See views/default/groups/groupprofile_extension.php.
	- Added more view extensions in Groups
	- Added view extensions to handle Messages 
	- Restructured some of the architecture to deal with pages that only had translatable content which was delivered via AJAX.  The icon wasn't showing up because the loading of the Google library wasn't happening.  Moved that to the pageshell_extension, so it happens all the time, first thing.
      - Fixed a bug where the Google branding would be displayed multiple times, once for each time the user hits the translate button
      - Added coloration of the translated text.  Change, or eliminate, the background-color in the plugin settings on the Administration | Tools Administration page.
      - Changed the Translate icon again.  It's a Google requirement that the icon show that it's a Google supported action.
  

