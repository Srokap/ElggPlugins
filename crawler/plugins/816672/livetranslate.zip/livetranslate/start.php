<?php
/**
 * livetranslate
 *  
 * @package livetranslate
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Mike Hedman
 * @copyright IntraPace, Inc. 2011
 */

require_once("TranslationController.php");
define('DEFAULT_TRANSLATED_COLOR', '#FCE6CF');
define('DEFAULT_ICON_PARENT', '#searchform');
define('DEFAULT_BRANDING_PARENT', '#layout_footer');
/**
 * livetranslate plugin initialisation
 */
function livetranslate_init() {
    extend_view('css','livetranslate/css');

    //add additional extend_view() calls for all views in which you want to add translation
    extend_view('forum/topicposts', 'forum/topicposts_extension');			
    extend_view('groups/grouplisting', 'groups/grouplisting_extension');			
    extend_view('groups/groupprofile', 'groups/groupprofile_extension');			
    extend_view('messages/messages', 'messages/messages_extension');			
    extend_view('messages/view', 'messages/view_extension');			
    extend_view('object/groupforumtopic', 'object/groupforumtopic_extension');			
    extend_view('profile/userdetails', 'profile/userdetails_extension');			
    extend_view('river/item/list', 'river/item/list_extension');			
    extend_view('widgets/a_users_groups/view', 'widgets/a_users_groups/view_extension');							

    register_plugin_hook('cron', 'daily', 'livetranslate_cache_expire');
    register_plugin_hook('container_permissions_check', 'object', 'livetranslate_can_edit_container');
}

/**
 * Outputs the necessary JavaScript to auto translate the DOM elements selected by the $selectors
 * This method will typically be called from a view extension.
 * @param mixed $selectors An array, or a comma delimited string of the jQuery selectors to pick the items to be translated:
 *   "td[width='70%'] p, #content_area_group_title h2";
 *   Note - be sure to provide specific selectors!  For example, if you don't include the 'h2' in the example, 
 *   you will wipe out the <h2> tags around the text.
 * @param mixed $exclusions An array or a comma delimited string of the jQuery selectors to identify elements to be excluded
 * @param String $icon_parent Optionally, a jQuery selector identifying the element which will hold the translate icon.
 *  The icon will be added as the first child of the icon_parent
 * @param String $branding_parent Optionally, a jQuery selector identifying the element which will hold the Google Branding div.
 *  The div will be added as the last child of the branding_parent
 */
function addTranslator($selectors, $exclusions = null, $icon_parent = null, $branding_parent = null) {
    global $CONFIG;
    //only let logged in members use the translation feature
    if (!isloggedin()) {
        return;
    }

    //pass the selectors over to javascript
    if (!is_array($selectors)) {
        $selectors = explode(',', $selectors);
    }
    foreach ($selectors as $selector) {
        echo '<span class="livetranslate_selector">' . trim($selector) . '</span>';                    
    }

    if (!is_null($exclusions)) {
        if (!is_array($exclusions)) {
            $exclusions = explode(',', $exclusions);
        }
        foreach ($exclusions as $exclusion) {
            echo '<span class="livetranslate_exclusion">' . trim($exclusion) . '</span>';                    
        }
    }
    
    //set JavaScript variables that will be used in translate.js
    //only add them once!
    static $translatorAdded;
    if (! $translatorAdded) {
        if (is_null($icon_parent)) {
            $settings_icon_parent = get_plugin_setting('icon_parent', 'livetranslate');
            if ($settings_icon_parent) {
                $icon_parent = $settings_icon_parent;
            } else {
                $icon_parent = DEFAULT_ICON_PARENT;
            }
        }
        if (is_null($branding_parent)) {
            $settings_branding_parent = get_plugin_setting('branding_parent', 'livetranslate');
            if ($settings_branding_parent) {
                $branding_parent = $settings_branding_parent;
            } else {
                $branding_parent = DEFAULT_BRANDING_PARENT;
            }
        }        

        echo '<script type="text/javascript" charset="utf-8">';
        //in the case of ajax calls, the translatorAdded won't inhibit the sending of the variables a second time
        // so let Javascript do it

        echo 'if (typeof icon_parent=="undefined") {';
        echo ' var icon_parent = "' . $icon_parent . '";';
        echo ' var branding_parent = "' . $branding_parent . '";';
        echo " var branding = '" . trim(elgg_view('livetranslate/googleBranding')) . "';";
        echo " var translateButton = '" . trim(elgg_view('livetranslate/translateButton')) . "';";
        echo ' var translateTitle = "' . elgg_echo('livetranslate:translate') . '";';
        echo ' var restoreTitle = "' . elgg_echo('livetranslate:restore') . '";';
        echo ' var elggUrl = "' . $CONFIG->url . '";';
        echo ' var descriptionTitle = "' . elgg_echo('livetranslate:description:title') . '";';
        echo ' var okButtonText = "' . elgg_echo('livetranslate:ok') . '";';
        $preferredLanguage = get_current_language();
        //clean up UK English to a code that Google will accept
        if ($preferredLanguage == 'en-gb') {
            $preferredLanguage = 'en';
        }
        echo ' var preferredLanguage = "' . $preferredLanguage . '";';
        echo showDescription();
        echo '}';
        echo '</script>';
        echo '<script src="' . $CONFIG->url. 'mod/livetranslate/javascript/translate.js?version=1.0" type="text/javascript" charset="utf-8"></script>';		

        $translatorAdded = true;	
    }
}

/**
 * @return string A chunk of JavaScript which declares and initializes the showDescription variable
 */
function showDescription() {
    $user = get_loggedin_user();
    $usersVersion = $user->LiveTranslateDescriptionVersion;
    if (elgg_echo('livetranslate:description:version') != $usersVersion) {
        return ' var showDescription = true;';
    } else {
        return ' var showDescription = false;';
    }
}

/**
  *  Delete any cache entries that have expired
  */
function livetranslate_cache_expire() {
    $now = time();
    // cache entries expire after 60 days
    $cacheExpireDays = 60;

    $expireTime = $now - $cacheExpireDays*24*60*60;
    // we have to set ignore access because this particular function is run by a cron job
    $oldAccess = elgg_set_ignore_access(TRUE);
    TranslatedText::expireFromCache($expireTime);
    elgg_set_ignore_access($oldAccess);

} // livetranslate_cache_expire 

/**
  * Anyone can edit live translate cache entries
  *
  */
function livetranslate_can_edit_container($hook_name, $entity_type, $return_value, $parameters) {

    if ($parameters['container']->getSubtype() == "translatedtext") {
        return true;
    }

    return $return_value;

}



register_elgg_event_handler('init','system','livetranslate_init');
