<?php
 
    // pages on the group index page

    //check to make sure this group forum has been activated
    if($vars['entity']->pages_enable != 'no'){

?>

<div id="group_bookmarks_widget">
<h2><?php echo elgg_echo("bookmarks:group"); ?></h2>
<?php

	set_context('search');
    $objects = list_entities("object", "bookmarks", page_owner(), 5, false);
	set_context('groups');
	$users_bookmark_url = $vars['url'] . "pg/bookmarks/" . page_owner_entity()->username;
	 
    if($objects){
		echo $objects;
		echo "<div class=\"forum_latest\"><a href=\"{$users_bookmark_url}\">" . elgg_echo('bookmarks:more') . "</a></div>";
	}
	else
		echo "<div class=\"forum_latest\">" . elgg_echo("bookmarks:nogroup") . "</div>";
	
?>
<br class="clearfloat" />
</div>

<?php
    }
?>