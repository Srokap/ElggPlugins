<?php
	$english = array(
		'twitterservice:postwire' => 'Do you want to post your public messages from the wire to Twitter?',
		'twitterservice:twittername' => 'Twitter username',
		'twitterservice:twitterpass' => 'Twitter password',
	);
					
	add_translation("en",$english);
?>