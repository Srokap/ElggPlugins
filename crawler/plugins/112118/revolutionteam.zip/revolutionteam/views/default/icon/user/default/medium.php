<?php
	echo $vars['url'] . "mod/natural_brown_theme/graphics/user_icons/defaultmedium.gif";
?>