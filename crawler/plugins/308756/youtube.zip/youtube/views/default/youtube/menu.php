<?php

	
?>
<p class="user_menu_ad">
	<a href="<?php echo $vars['url']; ?>pg/youtube/<?php echo $vars['entity']->getGUID(); ?>"><?php echo elgg_echo("youtube:user:owned"); ?></a>	
</p>