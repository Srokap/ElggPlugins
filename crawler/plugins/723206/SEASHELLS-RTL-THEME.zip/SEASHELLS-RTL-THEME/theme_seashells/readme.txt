By installing this theme you agree to the Licensing Agreement, which can be found at http://pragueprogrammes.com/seashells/

Please note the following license variations:

Free - distributed free of charge, may be used by non-business entities on sites under 500 members

Extended Non-for-Profit - distributed under a licensing fee, may be used by non-business entities (private individuals, registered NGOs, unofficial associations/groups) on sites under 500 members. 1 license = 1 site

Extended Business - distributed under a licensing free, may be used by non-business and business entities on sited with over 500 members. 1 license = 1 site

====================================================

INSTALLATION

1. Load the archive folder to your server: your-elgg-installation.com/mod/

2. Ensure that the unarchiving folder is not nested, that is the filepath to start.php is as follow: 

your-elgg-installation.com/mod/theme_seashells/start.php

3. Go to your Elgg site -> Administration -> Tool Administration.

4. Find theme_seashells and enable it.

5. Ensure that the theme_seashells is at the bottom of the plugin list.

 

CONFIGURATION

1. Once enabled, you will see Settings (next to plugin name)

2. Before editing your Settings, ensure that you have disabled htmlawed. (You need to ensure that htmlawed is disabled every time, otherwise you may loose bits of script you have entered into the textfields, when editing the settings previously)

3. Make all the necessary changes and Save.

4. For some settings to take effect, you may need to Disable the plugin, and re-enable it (that is for the cached settings to reload)

====================================================

I hope you enjoy the theme. Please share your feedback, suggestions and feature requests.

You can contact me at ismayil.khayredinov@pragueprogrammes.com

====================================================

UPDATES

Up to date information about known issues, revealed bugs and fixes can be found at http://pragueprogrammes.com/seashells/