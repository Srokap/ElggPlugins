<?php

	/*** Seashells Theme language file*/
	
	$hebrew = array(
	'seashells:myprofile' => "הפרופיל שלי",
	'seashells:dashboard' => "מה חדש",
	'seashells:addpost' => "כתיבת פוסט",
	'seashells:addfile' => "העלאת קובץ",
	'seashells:addbookmarks' => "הוספת קישור",
	'seashells:addgroups' => "יצירת קבוצה",
	'seashells:addpages' => "כתבית דף ויקי",
	'seashells:addphotos' => "העלאת תמונות",
	'seashells:addvideos' => "הוספת וידאו",
	'seashells:addpolls' => "יצירת סקר",
	'seashells:addevent' => "Promote an event",
	'seashells:addquestion' => "שאילת שאלה",
	'seashells:onlineusers' => "עכשיו ברשת",
	'seashells:noonlineusers' => "אין כרגע חברים מחוברים",
	'seashells:upcomingevents' => "אירועים",
	'seashells:index:blogs' => "פוסטים אחרונים",
	'seashells:index:files' => "קבצים אחרונים",
	'seashells:index:bookmarks' => "קישורים אחרונים",
	'seashells:index:members' => "חברי רשת חדשים",
	'seashells:index:groups' => "קבוצות חדשות",
	'seashells:publish' => "פרסם",
	'seashells:new'=> "חדש",
	'seashells:emptyinbox' => "אין הודעות נכנסות",
	'seashells:status' => "הסטטוס שלי",
	'seashells:noevents' => "אין לך אירועים בקרוב"
	
	);

add_translation("he",$hebrew);
?>