<?php

    global $CONFIG;
    echo elgg_view('canvas/default', $vars);

?>