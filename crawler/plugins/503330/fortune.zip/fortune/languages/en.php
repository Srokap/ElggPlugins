<?php
$english = array(
	'fortune:pagetitle'	=> 'Fortune',

);

add_translation("en",$english);
?>