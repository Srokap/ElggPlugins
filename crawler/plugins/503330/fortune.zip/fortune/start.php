<?php
/*******************************************************************************
 * fortune
 *
 * @author mybook
 ******************************************************************************/

	function fortune_init()
	{
		global $CONFIG;







		add_menu(fortune, $CONFIG->wwwroot . 'mod/fortune/pages/index.php');




		
		
		return true;
	}






	
	register_elgg_event_handler('init', 'system', 'fortune_init');
?>