<?php

	/**
	 * Elgg Simple Datepicker
	 * 
	 * @package ElggSimpleDatepicker
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
	 * @copyright (C) Sergio De Falco 2008
	 * @link http://www.gonk.it/
	 */
	 
    function simple_datepicker_init() {
	
        // Extend system CSS with our own styles
			elgg_extend_view('css','simple_datepicker/css');

    }

    // Make sure the init function is called
		    register_elgg_event_handler('init','system','simple_datepicker_init');

?>