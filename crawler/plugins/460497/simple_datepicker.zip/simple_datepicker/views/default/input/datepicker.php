<?php 

	/**
	* Elgg Simple Datepicker
	* 
	* @package ElggSimpleDatepicker
	* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	* @author Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
	* @copyright (C) Sergio De Falco 2010
	* @link http://www.gonk.it/
	*/
	
	global $datepicker;

    $internal_id = sanitise_string(str_replace("]", "_", str_replace("[" , "_" ,$vars['internalname']))) . $datepicker;
    $val = $vars['value']; // timestamp value

	$bd_month = date("n", $val);
	$bd_year = date("Y", $val);
	$bd_day = date("j", $val);

?>
<script type="text/javascript">

function ajax_call_server(url,vars){var xml=null;try{xml=new ActiveXObject("Microsoft.XMLHTTP")}catch(exception){xml=new XMLHttpRequest()}if(xml!=null){xml.open("GET",url+vars,false);xml.send(null);if(xml.status==404)alert("Error 404: Incorrect url.");return xml.responseText}alert("Your browser does not support XMLHTTP.");return""}function get_days_of_month(){var dayopt=<?php echo $bd_day-1;?>;var year=document.getElementById("theyear").value;var month=document.getElementById("themonth").value;var response=ajax_call_server("<?php echo $vars['url']; ?>mod/simple_datepicker/ajax/calculatedays.php","?y="+year+"&m="+month);eval(response);document.getElementById("theday").options[dayopt].selected=true;set_date()}function toTimestamp(strDate){var datum=Date.parse(strDate);return datum/1000}function set_date(){var day=document.getElementById("theday").value;var year=document.getElementById("theyear").value;var month=document.getElementById("themonth").value;var timestampdate=toTimestamp(month+'/'+day+'/'+year);if(year==0||month==0){timestampdate=""}else{timestampdate=timestampdate+<?php echo date("Z");?>}document.getElementById('<?php echo $internal_id; ?>_alt').value=timestampdate}

</script>
<script type="text/javascript">
	$(document).ready(function(){
		get_days_of_month();
	});
</script>
<input class="datepicker_hidden" type="text" READONLY name="<?php echo $vars['internalname']; ?>" value="<?php echo $val; ?>" id="<?php echo $internal_id; ?>_alt" /> 
<select id="theday" name="theday" size="1" onchange="set_date();">
</select>
<select id="themonth" name="themonth" size="1" onchange="get_days_of_month();">
	<option value="0"><?php echo elgg_echo("datepicker:month"); ?></option>
	<option value="0"></option>
<?php
	/*
	*  Printed code here is Javascript code
	*  evaluated in real time with include(...)
	*
	*  date("F",mktime(0,0,0,$i,1,date("Y"))) returns
	*  the name of the month $i
	*
	*/

	// Default month is January
	$default_month=1;
	for($i=1;$i<=12;$i++)
		if($i==$bd_month)
			echo '<option selected="selected" value="'.$i.'">'.
				elgg_echo("datepicker:month:" . date("F",mktime(0,0,0,$i,1,date("Y")))).
					'</option>';
				else
					echo '<option value="'.$i.'">'.
						elgg_echo("datepicker:month:" . date("F",mktime(0,0,0,$i,1,date("Y")))).
					'</option>';
?>
</select>
<select id="theyear" name="theyear" size="1" onchange="get_days_of_month();">
	<option value="0"><?php echo elgg_echo("datepicker:year"); ?></option>
	<option value="0"></option>
<?php

	// Expected target users with ages
	// from 15 to 50 years old
	$min_year=date("Y")-50;
	$max_year=date("Y")-15;

	// Mean of users age: 25 years old
	$default_year=date("Y")-34;

	for($i=$max_year;$i>=$min_year;$i--)
		if($i==$bd_year)
			echo '<option selected="selected" value="'.$i.'">'.
				$i.'</option>';
			else
				echo '<option value="'.$i.'">'.
					$i.'</option>';
?>
</select>