<?php

	/**
	* Elgg Simple Datepicker English Language File
	* 
	* @package ElggSimpleDatepicker
	* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	* @author Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
	* @copyright (C) Sergio De Falco 2010
	* @link http://www.gonk.it/
	*/

$english = array(

/**
 * Simple Datepicker
 */

	'datepicker:month' => 'month',
	'datepicker:day' => 'day',
	'datepicker:year' => 'year',

/**
 * Simple Datepicker Months
 */

	'datepicker:month:January' => 'January',
	'datepicker:month:February' => 'February',
	'datepicker:month:March' => 'March',
	'datepicker:month:April' => 'April',
	'datepicker:month:May' => 'May',
	'datepicker:month:June' => 'June',
	'datepicker:month:July' => 'July',
	'datepicker:month:August' => 'August',
	'datepicker:month:September' => 'September',
	'datepicker:month:October' => 'October',
	'datepicker:month:November' => 'November',
	'datepicker:month:December' => 'December',

);

add_translation("en",$english);

?>