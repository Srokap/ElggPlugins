<?php

	/**
	* Elgg Simple Datepicker Italian Language File
	* 
	* @package ElggSimpleDatepicker
	* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	* @author Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
	* @copyright (C) Sergio De Falco 2010
	* @link http://www.gonk.it/
	*/

$italian = array(

/**
 * Simple Datepicker
 */

	'datepicker:month' => 'mese',
	'datepicker:day' => 'giorno',
	'datepicker:year' => 'anno',

/**
 * Simple Datepicker Months
 */

	'datepicker:month:January' => 'Gennaio',
	'datepicker:month:February' => 'Febbraio',
	'datepicker:month:March' => 'Marzo',
	'datepicker:month:April' => 'Aprile',
	'datepicker:month:May' => 'Maggio',
	'datepicker:month:June' => 'Giugno',
	'datepicker:month:July' => 'Luglio',
	'datepicker:month:August' => 'Agosto',
	'datepicker:month:September' => 'Settembre',
	'datepicker:month:October' => 'Ottobre',
	'datepicker:month:November' => 'Novembre',
	'datepicker:month:December' => 'Dicembre',
);

add_translation("it",$italian);

?>