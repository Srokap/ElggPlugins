<?php

	$russian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'status' => "Статус",
			'status:user' => "Статус пользователя %s",
			'status:current'=> "Текущий статус",
			'status:desc'=> "Этот элемент показывает Ваш последний статус (например, \"дома\" или \"на работе\").",
			'status:posttitle' => "Статус пользователя %s: %s",
			'status:everyone' => "Все статусы",
			'status:strapline' => "%s",
			'status:addstatus' => "Установить свой статус",
		    'status:messages' => "Сообщения",
			'status:text' => "Статус:",
			'status:set' => "установить ",
			'status:clear' => "очистить",
			'status:delete' => "удалить",
			'status:nostatus' => "Статус не установлен.",
			'status:viewhistory' => "смотреть историю",
	
			'item:object:status' => 'Сообщения',
	
	
        /**
	     * Status river
	     **/
	        
	        //generic terms to use
	        'status:river:created' => "Пользователь %s обновил",
	        
	        //these get inserted into the river links to take the user to the entity
	        'status:river:create' => "статус.",
	        
	        
	
		/**
		 * Status messages
		 */
	
			'status:posted' => "Статус установлен.",
			'status:deleted' => "Статус удален.",
	
		/**
		 * Error messages
		 */
	
			'status:blank' => "Вы не написали текст.",
			'status:notfound' => "Простите, сообщение не найдено.",
			'status:notdeleted' => "Простите, сообщение не удалено.",
			'status:notsaved' => "Простите, произошла ошибка при сохранении, попробуйте снова.",
			'status:problem' => "Простите, произошли неполадки. Вы не можете редактировать статус.",
	
	);
					
	add_translation("ru",$russian);

?>