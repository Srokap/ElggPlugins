<?php
	/**
	 * Elgg file plugin language pack
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$russian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'file' => "Файлы",
			'files' => "Файлы",
			'file:yours' => "Ваши файлы",
			'file:yours:friends' => "Файлы Ваших друзей",
			'file:user' => "Файлы %s",
			'file:friends' => "Файлы друзей %s",
			'file:all' => "Все файлы",
			'file:edit' => "Редактировать файл",
			'file:more' => "еще файлы",
			'file:list' => "в виде списка",
			'file:group' => "Файлы группы",
			'file:gallery' => "в виде галереи",
			'file:gallery_list' => "В виде галереи или списка",
			'file:num_files' => "Число отображаемых файлов",
			'file:user:gallery'=>'Просмотреть галерею %s', 
	
			'file:upload' => "Загрузить файл",
			
			'file:file' => "Файл",
			'file:title' => "Заглавие",
			'file:desc' => "Описание",
			'file:tags' => "Теги",
	
			'file:types' => "Типы загружаемых файлов",
	
			'file:type:all' => "Все файлы",
			'file:type:video' => "Видео",
			'file:type:document' => "Документы",
			'file:type:audio' => "Аудио",
			'file:type:image' => "Изображения",
			'file:type:general' => "Основные файлы",
	
			'file:user:type:video' => "Видео %s",
			'file:user:type:document' => "Документы %s",
			'file:user:type:audio' => "Аудио %s",
			'file:user:type:image' => "Изображения %s",
			'file:user:type:general' => "Основные файлы %s",
	
			'file:friends:type:video' => "Видео Ваших друзей",
			'file:friends:type:document' => "Документы Ваших друзей",
			'file:friends:type:audio' => "Аудио Ваших друзей",
			'file:friends:type:image' => "Изображения Ваших друзей",
			'file:friends:type:general' => "Основные файлы Ваших друзей",
	
			'file:widget' => "Файлы",
			'file:widget:description' => "Ваши последние файлы",
	
			'file:download' => "Скачать",
	
			'file:delete:confirm' => "Удалить этот файл?",
			
			'file:tagcloud' => "Облако тегов",
	
			'file:display:number' => "Число отображаемых файлов",
	
			'file:river:created' => "Загруженное %s",
			'file:river:item' => "файл",
			'file:river:annotate' => "комментарий от %s",

			'item:object:file' => 'Файлы',
			
	    /**
		 * Embed media
		 **/
		 
		    'file:embed' => "Вложенное",
		    'file:embedall' => "Все",
	
		/**
		 * Status messages
		 */
	
			'file:saved' => "Ваш файл успешно сохранен.",
			'file:deleted' => "Ваш файл успешно удален.",
	
		/**
		 * Error messages
		 */
	
			'file:none' => "Файлов нет.",
			'file:uploadfailed' => "Простите, файл не сохранен.",
			'file:downloadfailed' => "Простите, файл сейчас недоступен.",
			'file:deletefailed' => "Простите, файл не удален.",
	
	);
					
	add_translation("ru",$russian);
?>