<?php
	/**
	 * Elgg diagnostics language pack.
	 * 
	 * @package ElggDiagnostics
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$russian = array(
	
			'diagnostics' => 'Диагностика системы',
	
			'diagnostics:description' => 'Этот отчет о диагностике полезен для диагностирования проблем Elgg и должен быть приложен к любому сообщаемому багу.',
	
			'diagnostics:download' => 'Скачать .txt',
	
	
			'diagnostics:header' => '========================================================================
Отчет о диагностике Elgg
Создан %s от %s
========================================================================
			
',
			'diagnostics:report:basic' => '
Elgg релиз %s, версия %s

------------------------------------------------------------------------',
			'diagnostics:report:php' => '
PHP-сведения:
%s
------------------------------------------------------------------------',
			'diagnostics:report:plugins' => '
Установленные плагины и детали:

%s
------------------------------------------------------------------------',
			'diagnostics:report:md5' => '
Установленные файлы и их сумма:

%s
------------------------------------------------------------------------',
			'diagnostics:report:globals' => '
Глобальные переменные:

%s
------------------------------------------------------------------------',
	
	);
					
	add_translation("ru",$russian);
?>