<?php
	/**
	 * Elgg garbage collector language pack.
	 * 
	 * @package ElggGarbageCollector
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$russian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'garbagecollector:period' => 'Как часто Вы хотите запускать Мусорщика?',
	
			'garbagecollector:weekly' => 'Раз в неделю',
			'garbagecollector:monthly' => 'Раз в месяц',
			'garbagecollector:yearly' => 'Раз в год',
	
			'garbagecollector' => "МУСОРЩИК\n",
			'garbagecollector:done' => "ВЫПОЛНЕНО\n",
			'garbagecollector:optimize' => "Optimizing %s ",
	
			'garbagecollector:error' => "ОШИБКА",
			'garbagecollector:ok' => "OK",
	
			'garbagecollector:gc:metastrings' => 'Очистить: ',
	
	);
					
	add_translation("ru",$russian);
?>