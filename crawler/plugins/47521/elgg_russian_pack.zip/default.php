<table id="spotlight_table" width="100%"cellspacing="0">
	<tr>
		<td align="left" valign="top">
		<!-- spotlight LHS content -->
  				<h2>Добро пожаловать! :)</h2>
  				<p>
  				
				Хай-Ап – это сообщество целеустремленных людей, заинтересованных в своем продвижении или уже удовлетворивших свои амбиции. Мы создали Хай-Ап как учащимся и студентам, так и вполне состоявшимся личностям, для которых "цель" - не просто четыре буквы алфавита. 
				Планируйте будущие достижения, узнавайте о своих возможностях, общайтесь и делитесь опытом!


				</p>
				
				
				
		</td>		
		
		<td width="250" align="left" valign="top" rowspan="2">
		<!-- spotlight RHS content -->
		<!-- /spotlight RHS content -->
		<img src="/_graphics/concert.jpg"></a>
		</td>
	</tr>
	<tr>
		<td align="left" valign="top">
		<!-- spotlight LHS content -->
  				<h2></h2>
  				<ul>
  											 
<!-- start Link.Ru -->
<script language="JavaScript">
// <!--
var LinkRuRND = Math.round(Math.random() * 1000000000);
document.write('<iframe src="http://link.link.ru/show?squareid=71968&showtype=4&output_style=1&shift_count=1&cat_id=1&tar_id=1&sc=3&bg=FFFFFF&bc=FFFFFF&tc=D5EFFF&tt=5066CD&tu=0202FF&th=050005&bwidth=468&bheight=60&r='+LinkRuRND+'&ref='+escape(document.referrer)+'&url='+escape(window.location.href)+'" frameborder="0" vspace="0" hspace="0" marginwidth="0" marginheight="0" scrolling="no" width="468" height="76"></iframe>');
// -->
</script>
<noscript>
<iframe src="http://link.link.ru/show?squareid=71968&showtype=4&output_style=1&shift_count=1&cat_id=1&tar_id=1&sc=3&bg=FFFFFF&bc=FFFFFF&tc=D5EFFF&tt=5066CD&tu=0202FF&th=050005&bwidth=468&bheight=60" frameborder="0" vspace="0" hspace="0" marginwidth="0" marginheight="0" scrolling="no" width="468" height="76"></iframe>
</noscript>
<!-- end Link.Ru -->

 <!-- start Link.Ru -->
<script language="JavaScript">
// <!--
var LinkRuRND = Math.round(Math.random() * 1000000000);
document.write('<iframe src="http://link.link.ru/show?squareid=71968&showtype=1&output_style=2&shift_count=1&cat_id=1&tar_id=1&sc=3&bg=FFFFFF&bc=FFFFFF&tc=f4f4f4&tt=434343&tu=000002&th=0954a5&bwidth=468&bheight=60&r='+LinkRuRND+'&ref='+escape(document.referrer)+'&url='+escape(window.location.href)+'" frameborder="0" vspace="0" hspace="0" marginwidth="0" marginheight="0" scrolling="no" width="468" height="60"></iframe>');
// -->
</script>
<noscript>
<iframe src="http://link.link.ru/show?squareid=71968&showtype=1&output_style=2&shift_count=1&cat_id=1&tar_id=1&sc=3&bg=FFFFFF&bc=FFFFFF&tc=f4f4f4&tt=434343&tu=000002&th=0954a5&bwidth=468&bheight=60" frameborder="0" vspace="0" hspace="0" marginwidth="0" marginheight="0" scrolling="no" width="468" height="60"></iframe>
</noscript>
<!-- end Link.Ru -->


				</ul>
		</td>
	</tr>
</table>