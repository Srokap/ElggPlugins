﻿<?php

	/**
	 * Update client language pack.
	 * 
	 * @package ElggUpdateClient
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */	

	$russian = array(
	
		'updateclient:label:core' => 'Ядро',
		'updateclient:label:plugins' => 'Плагины',
	
		'updateclient:settings:days' => 'Проверять обновления ',
		'updateclient:days' => 'дни',
	
		'updateclient:settings:server' => 'Сервер обновлений',
	
		'updateclient:message:title' => 'Вышла новая версия Elgg!',
		'updateclient:message:body' => 'Вышла новая версия Elgg (%s %s) под кодовым названием "%s"!
		
Для загрузки перейдите по ссылке: %s

Также можете прочитать релизные записи:

%s',
	);
					
	add_translation("ru", $russian);
?>