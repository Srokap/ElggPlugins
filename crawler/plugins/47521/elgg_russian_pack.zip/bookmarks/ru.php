<?php

	$russian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'bookmarks' => "Закладки",
			'bookmarks:add' => "Добавить закладку",
			'bookmarks:read' => "Закладки",
			'bookmarks:friends' => "Закладки друзей",
			'bookmarks:everyone' => "Все закладки",
			'bookmarks:this' => "Добавить в закладки",
			'bookmarks:bookmarklet' => "Добавить закладки",
			'bookmarks:inbox' => "Ваши закладки",
			'bookmarks:more' => "Еще закладки",
			'bookmarks:shareditem' => "Закладки",
			'bookmarks:with' => "Обменяться с",
	
			'bookmarks:address' => "Адрес сайта",
	
			'bookmarks:delete:confirm' => "Вы действительно хотите удалить закладку?",
	
			'bookmarks:shared' => "Закладки",
			'bookmarks:visit' => "Зайти на сайт",
			'bookmarks:recent' => "Закладки",
	
			'bookmarks:river:created' => 'Пользователь %s добавил закладки',
			'bookmarks:river:annotate' => 'Пользователь %s сделал',
			'bookmarks:river:item' => 'закладку',
	
			'item:object:bookmarks' => 'Закладки',
	
	
		/**
		 * More text
		 */
		    
		    'bookmarks:widget:description' => 
		            "Этот элемент показывает Ваши закладки.",
	
			'bookmarks:bookmarklet:description' =>
					"Закладки позволяют добавлять адреса понравившихся сайтов, советовать друзьям или просто отмечать для себя. Чтобы использовать элемент, перетащите кнопку в адресную строку Вашего браузера:",

	        'bookmarks:bookmarklet:descriptionie' =>
					"Если Вы используете Internet Explorer, Вам нужно нажать правой кнопкой мыши на значок закладок, выбрать 'Добавить в избранное', а затем на адресную строку.",

			'bookmarks:bookmarklet:description:conclusion' =>
					"Вы можете сохранить любую страницу в любое время.",
	
		/**
		 * Status messages
		 */
	
			'bookmarks:save:success' => "Закладка добавлена.",
			'bookmarks:delete:success' => "Закладка удалена.",
	
		/**
		 * Error messages
		 */
	
			'bookmarks:save:failed' => "Простите, Ваша закладка не может быть сохранена. Попробуйте снова.",
			'bookmarks:delete:failed' => "Простите, Ваша закладка не может быть удалена. Попробуйте снова.",
	
	
	);
					
	add_translation("ru",$russian);

?>