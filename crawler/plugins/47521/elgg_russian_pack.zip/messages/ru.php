<?php

	$russian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messages' => "Сообщения",
            'messages:back' => "назад к сообщениям",
			'messages:user' => "Входящие",
			'messages:sentMessages' => "Отправленные",
			'messages:posttitle' => "Сообщения %s: %s",
			'messages:inbox' => "Входящие",
			'messages:send' => "Написать сообщение",
			'messages:sent' => "Отправленные",
			'messages:message' => "Сообщение",
			'messages:title' => "Тема",
			'messages:to' => "",
            'messages:from' => "От",
			'messages:fly' => "Отправить",
			'messages:replying' => "Ответ",
			'messages:inbox' => "Входящие",
			'messages:sentmessages' => "Отправленные",
			'messages:sendmessage' => "Написать сообщение",
			'messages:compose' => "Написать сообщение",
			'messages:recent' => "Недавние сообщения",
            'messages:original' => "Оригинал",
            'messages:yours' => "Ваше сообщение",
            'messages:answer' => "Ответить",
			
			'item:object:messages' => 'Сообщения',
	
		/**
		 * Status messages
		 */
	
			'messages:posted' => "Сообщение отправлено.",
			'messages:deleted' => "Сообщение удалено.",
	
		/**
		 * Email messages
		 */
	
			'messages:email:subject' => 'У Вас новое сообщение.',
			'messages:email:body' => "У Вас новое сообщение от %s. Оно гласит:

			
%s


Чтобы посмотреть Ваши сообщения, нажмите здесь:

	%s

Чтобы отправить %s сообщение, кликните сюда:

	%s

Это письмо составлено роботом. Пожалуйста, не отвечайте на него.",
	
		/**
		 * Error messages
		 */
	
			'messages:blank' => "Простите, но Вы должны что-нибудь написать перед отправкой.",
			'messages:notfound' => "Простите, данное сообщение не найдено.",
			'messages:notdeleted' => "Простите, сообщение не может быть удалено.",
			'messages:nopermission' => "Вы не можете удалить это сообщение.",
			'messages:nomessages' => "Нет сообщений для отображения.",
			'messages:user:nonexist' => "Простите, невозможно найти получателя.",
	
	);
					
	add_translation("ru",$russian);

?>