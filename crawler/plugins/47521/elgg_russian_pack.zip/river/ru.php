<?php

	$russian = array(
	
		/**
		 * Manifest
		 */
		
	
		'river:widget:noactivity' => 'Активность не обнаружена.',
		'river:widget:title' => "Активность",
		'river:widget:description' => "Показать Вашу последнюю активность.",
		'river:widget:title:friends' => "Активность друзей",
		'river:widget:description:friends' => "Показать, что сделали Ваши друзья.",
	
		'river:widget:label:displaynum' => "Число отображаемых данных:",
	);
					
	add_translation("ru",$russian);

?>