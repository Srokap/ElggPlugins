<?php
	/**
	 * Elgg log rotator language pack.
	 * 
	 * @package ElggLogRotate
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$russian = array(
		'logrotate:period' => 'Как часто архивировать лог?',
	
		'logrotate:weekly' => 'Раз в неделю',
		'logrotate:monthly' => 'Раз в месяц',
		'logrotate:yearly' => 'Раз в год',
	
		'logrotate:logrotated' => "Log rotated\n",
		'logrotate:lognotrotated' => "Error rotating log\n",
	);
					
	add_translation("ru",$russian);
?>