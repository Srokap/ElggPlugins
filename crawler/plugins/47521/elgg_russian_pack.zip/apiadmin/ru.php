<?php
	/**
	 * API Admin language pack.
	 * 
	 * @package ElggAPIAdmin
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */


	$russian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'apiadmin' => 'Администрирование API',
	
	
			'apiadmin:keyrevoked' => 'Отмена API-ключа',
			'apiadmin:keynotrevoked' => 'API-ключ не может быть отменен.',
			'apiadmin:generated' => 'API-ключ сгенерирован.',
	
			'apiadmin:yourref' => 'Ваша ссылка',
			'apiadmin:generate' => 'Генерировать новую ключевую пару',
	
			'apiadmin:noreference' => 'Вы должны указать ссылку для Вашего нового ключа.',
			'apiadmin:generationfail' => 'Произошла ошибка при генерации нового ключа.',
			'apiadmin:generated' => 'Новая пара API-ключей сгенерирована.',
	
			'apiadmin:revoke' => 'Отменить ключ',
			'apiadmin:public' => 'Публичный',
			'apiadmin:private' => 'Приватный',

	
			'item:object:api_key' => 'API-ключи',
	);
					
	add_translation("ru",$russian);
?>