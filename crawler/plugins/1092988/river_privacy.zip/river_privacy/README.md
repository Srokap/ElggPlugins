River-Privacy-1.8.x
===================

Makes non-object oriented river items private - eg. friendship creation