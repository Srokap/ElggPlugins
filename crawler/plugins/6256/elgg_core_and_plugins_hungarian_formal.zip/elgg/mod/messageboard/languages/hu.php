<?php

	$hungarian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messageboard:board' => "Üzenőfal",
			'messageboard:messageboard' => "üzenőfal",
			'messageboard:viewall' => "Összeset megjelenít",
			'messageboard:postit' => "Üzenem",
			'messageboard:history' => "arhívum",
			'messageboard:none' => "Még nincs üzenet az üzenőfalon",
			'messageboard:num_display' => "Megjelenítendő üzenetek száma",
			'messageboard:desc' => "Ez egy üzenőfal, amelyet az adatlapodhoz illeszthets, ahol a többi felhasználó üzeneteket, kommentárokat tehet meg.",
			
         /**
	     * Message board widget river
	     **/
	        
	        'messageboard:river:annotate' => "%s üzenőfala új üzenettel bővült.",
	        'messageboard:river:create' => "%s hozzáadta adatlapjához az üzenőfal eszközt.",
	        'messageboard:river:update' => "%s frissítette üzenőfal eszközét.",
			
		/**
		 * Status messages
		 */
	
			'messageboard:posted' => "Üzenet sikeresen elküldve.",
			'messageboard:deleted' => "Üzenet sikeresen törölve.",
	
		/**
		 * Email messages
		 */
	
			'messageboard:email:subject' => 'Új üzenőfal üzenete érkezett!',
			'messageboard:email:body' => "Egy új üzenete érkezett az üzenőfalán. %s üzente:

			
%s


Üzenőfala üzenetei megtekintéséhez kattintson ide:

	%s

%s adatlapjának megtekintéséhez kattintson ide:

	%s

Kérem, ne válaszoljon erre az e-mailre.",
	
		/**
		 * Error messages
		 */
	
			'messageboard:blank' => "Kérem, írja meg az üzenet szövegét.",
			'messageboard:notfound' => "Nem található a kért elem.",
			'messageboard:notdeleted' => "Nem sikerült az üzenet törlése.",
	     
			'messageboard:failure' => "Ismeretlen hiba lépett fel az üzenet hozzáadásakor. Kérem, próbálja újból.",
	
	);
					
	add_translation("hu",$hungarian);

?>