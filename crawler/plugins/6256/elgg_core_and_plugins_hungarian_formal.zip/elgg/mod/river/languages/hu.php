<?php

	$hungarian = array(
	
		/**
		 * Manifest
		 */
		
	
		'river:widget:noactivity' => 'Nem található aktivitás.',
		'river:widget:title' => "Aktivitás",
		'river:widget:description' => "Utolsó aktivitásaim.",
		'river:widget:title:friends' => "Barátok aktivitásai",
		'river:widget:description:friends' => "Megjeleníti, mivel foglalkoznak a barátai.",
	
		'river:widget:label:displaynum' => "Megjelenítendő elemek száma:",
	);
					
	add_translation("hu",$hungarian);

?>