<?php
	/**
	 * Elgg file plugin language pack
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$hungarian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'file' => "Fileok",
			'files' => "Fileok",
			'file:yours' => "Filejaim",
			'file:yours:friends' => "Barátok filejai",
			'file:user' => "%s filejai",
			'file:friends' => "%s barátainak filejai",
			'file:all' => "A weboldal filejai",
			'file:more' => "több file",
			'file:list' => "lista megtekintés",
			'file:group' => "Csoport filejai",
			'file:gallery' => "galéria megjelenítés",
			'file:gallery_list' => "Galéria vagy lista megjelenítés",
			'file:num_files' => "Megjelenítendő file-ok száma",
	
			'file:upload' => "File feltöltése",
			
			'file:file' => "File",
			'file:title' => "Cím",
			'file:desc' => "Leírás",
			'file:tags' => "Címkék",
	
			'file:types' => "Feltöltött fileok típusai",
	
			'file:type:all' => "Összes file",
			'file:type:video' => "Videók",
			'file:type:document' => "Dokumentumok",
			'file:type:audio' => "Audio",
			'file:type:image' => "Képek",
			'file:type:general' => "Általános",
	
			'file:user:type:video' => "%s videói",
			'file:user:type:document' => "%s dokumentumai",
			'file:user:type:audio' => "%s hangfilejai",
			'file:user:type:image' => "%s képei",
			'file:user:type:general' => "%s általános filejai",
	
			'file:friends:type:video' => "Barátaim videói",
			'file:friends:type:document' => "Barátaim dokumentumai",
			'file:friends:type:audio' => "Barátaim hangfilejai",
			'file:friends:type:image' => "Barátaim képei",
			'file:friends:type:general' => "Barátaim általános filejai",
	
			'file:widget' => "Fileok",
			'file:widget:description' => "Kirakom a legújabb filejaim",
	
			'file:download' => "Letöltés",
	
			'file:delete:confirm' => "Biztosan le szeretné törölni ezt a filet?",
			
			'file:tagcloud' => "Címke halmaz",
	
			'file:display:number' => "Megjelenítendő fileok száma",
	
			'file:river:created' => "%s feltöltött",
			'file:river:item' => "egy filet",
			'file:river:annotate' => "%s kommentált",

			'item:object:file' => 'Fileok',
	
		/**
		 * Status messages
		 */
	
			'file:saved' => "File sikeresen mentve.",
			'file:deleted' => "File sikeresen törölve.",
	
		/**
		 * Error messages
		 */
	
			'file:none' => "Jelenleg nincs a csoportnak fileja.",
			'file:uploadfailed' => "Nem sikerült a file mentése.",
			'file:downloadfailed' => "Ez a file nem elérhető jelenleg.",
			'file:deletefailed' => "Nem sikerült a file törlése.",
	
	);
					
	add_translation("hu",$hungarian);
?>