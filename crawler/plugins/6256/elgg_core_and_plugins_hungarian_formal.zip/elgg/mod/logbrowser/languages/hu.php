<?php
	/**
	 * Elgg log browser plugin language pack
	 * 
	 * @package ElggLogBrowser
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$hungarian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'logbrowser' => 'Böngésző naplózása',
			'logbrowser:browse' => 'Rendszernapló tallózása',
			'logbrowser:search' => 'Eredmények finomítása',
			'logbrowser:user' => 'Keresési alapul vett felhasználónév',
			'logbrowser:starttime' => 'Kezdeti idő (például "múlt hétfő", "egy órája")',
			'logbrowser:endtime' => 'Befejezési idő',
	
			'logbrowser:explore' => 'Napló felderítése',
	
	);
					
	add_translation("hu",$hungarian);
?>