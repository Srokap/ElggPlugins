<?php

	$hungarian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messages' => "Üzenetek",
			'messages:user' => "Bejövő üzenetek",
			'messages:sentMessages' => "Elküldött üzenetek",
			'messages:posttitle' => "%s üzenetei: %s",
			'messages:inbox' => "Bejövő postafiók",
			'messages:send' => "Üzenet írása",
			'messages:sent' => "Elküldött üzenetek",
			'messages:message' => "Üzenet",
			'messages:title' => "Cím",
			'messages:to' => "Címzett",
			'messages:fly' => "Mehet",
			'messages:replying' => "Válaszüzenet ",
			'messages:inbox' => "Bejövő postafiók",
			'messages:sendmessage' => "Üzenet írása",
			'messages:compose' => "Üzenet írása",
			'messages:sentmessages' => "Elküldött üzenetek",
			'messages:recent' => "Friss üzenetek",
			
			'item:object:messages' => 'Üzenetek',
	
		/**
		 * Status messages
		 */
	
			'messages:posted' => "Üzenete sikeresen elküldve.",
			'messages:deleted' => "Üzenete sikeresen törölve.",
	
		/**
		 * Email messages
		 */
	
			'messages:email:subject' => 'Új üzenete érkezett!',
			'messages:email:body' => "%s új üzenetet írt önnek:

			
%s


Üzenetei megtekintéséhez kattintson ide:

	%s

%s számára történő üzenet küldéséhez kattintson ide:

	%s

Kérem, ne válaszoljon erre az e-mailre.",
	
		/**
		 * Error messages
		 */
	
			'messages:blank' => "Kérem, adja meg az üzenet szövegét. Enélkül nem elmenthető az üzenet.",
			'messages:notfound' => "Nem megtalálható a keresett üzenet.",
			'messages:notdeleted' => "Nem sikerült az üzenet törlése.",
			'messages:nopermission' => "Nincs joga ezen üzenet törléséhez.",
			'messages:nomessages' => "Nincs megjeleníthető üzenet.",
			'messages:user:nonexist' => "A címzett nem található meg a felhasználói adatbázisban.",
	
	);
					
	add_translation("hu",$hungarian);

?>