<?php
	/**
	 * Email user validation plugin language pack.
	 * 
	 * @package ElggUserValidationByEmail
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$hungarian = array(
	
		'email:validate:subject' => "%s, kérem erősítse meg e-mail címének hitelességét!",
		'email:validate:body' => "Üdvözöljük %s,

Kérem, erősítse meg e-mail címe hitelességét az alábbi linkre kattintva:

%s
",
		'email:validate:success:subject' => "E-mailcím sikeresen hitelesítve %s!",
		'email:validate:success:body' => "Üdvözöljük %s,
			
Az ön e-mail címe sikeresen hitelesíttetett.",
	
		'uservalidationbyemail:registerok' => "A számlája aktiválásához kérem, erősítse meg e-mail címe hitelességét az önnek küldött linkre kattintva."
	
	);
					
	add_translation("hu",$hungarian);
?>