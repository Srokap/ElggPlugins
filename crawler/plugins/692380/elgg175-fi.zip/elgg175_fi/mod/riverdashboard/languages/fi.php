<?php

// Luotu Käännösselaimella. 

$finnish = array( 
	 'mine'  =>  "Minun" , 
	 'filter'  =>  "Suodatin" , 
	 'riverdashboard:useasdashboard'  =>  "Korvaa oletuskojelauta aktiivisuussyötteillä?" , 
	 'activity'  =>  "Toiminta" , 
	 'riverdashboard:recentmembers'  =>  "Viimeisimmät jäsenet" , 
	 'sitemessages:announcements'  =>  "Sivuston uutiset" , 
	 'sitemessages:posted'  =>  "Sivuston viesti lähetetty" , 
	 'sitemessages:river:created'  =>  "Sivuston ylläpitäjä, %s," , 
	 'sitemessages:river:create'  =>  "lähetti uuden sivustonlaajuisen viestin" , 
	 'sitemessages:add'  =>  "Lisää sivustonlaajuinen viesti syötesivulle" , 
	 'sitemessage:deleted'  =>  "Sivuston viesti poistettu" , 
	 'sitemessage:error'  =>  "Virhe tallennettaessa sivustonlaajuista viestiä." , 
	 'sitemessages:blank'  =>  "Et voi lähettää tyhjää viestiä" , 
	 'river:widget:noactivity'  =>  "Ei löytynyt toimintaa." , 
	 'river:widget:title'  =>  "Toiminta" , 
	 'river:widget:description'  =>  "Näytä ystäviesi tai itsesi viimeisin toiminta." , 
	 'river:widgets:friends'  =>  "Ystävät" , 
	 'river:widgets:mine'  =>  "Minun" , 
	 'river:widget:label:displaynum'  =>  "Näytettävien kohteiden määrä:" , 
	 'river:widget:type'  =>  "Minkä syötevirran haluat nähdä? Sen joka näyttää oman toimintasi vai sen joka näyttää ystäviesi toiminnan?" , 
	 'item:object:sitemessage'  =>  "Sivuston viestit" , 
	 'riverdashboard:avataricon'  =>  "Haluatko käyttää käyttäjien ikoneja tai avatar-kuvia sivuston toimintalistauksessa?" , 
	 'option:icon'  =>  "Ikonit" , 
	 'option:avatar'  =>  "Avatarit"
); 

add_translation('fi', $finnish); 

?>