<?php

// Luotu Käännösselaimella. 

$finnish = array( 
	 'members:members'  =>  "Jäsenet" , 
	 'members:online'  =>  "Jäsenet jotka ovat juuri nyt aktiivisia" , 
	 'members:active'  =>  "sivuston jäsentä" , 
	 'members:searchtag'  =>  "Jäsenten etsintä tagien perusteella" , 
	 'members:searchname'  =>  "Jäsenten etsintä nimen perusteella" , 
	 'members:label:newest'  =>  "Uusimmat" , 
	 'members:label:popular'  =>  "Suositut" , 
	 'members:label:active'  =>  "Aktiiviset" , 
	 'members:search:name'  =>  "Käyttäjän nimi" , 
	 'members:search:tags'  =>  "Tagit"
); 

add_translation('fi', $finnish); 

?>