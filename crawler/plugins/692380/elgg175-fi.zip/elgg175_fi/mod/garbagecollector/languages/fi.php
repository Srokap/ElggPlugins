<?php

// Generate By translationbrowser. 

$finnish = array( 
	 'garbagecollector:period'  =>  "Kuinka usein Elggin roskankerääjän pitäisi toimia?" , 
	 'garbagecollector:weekly'  =>  "Kerran viikossa" , 
	 'garbagecollector:monthly'  =>  "Kerran kuussa" , 
	 'garbagecollector:yearly'  =>  "Kerran vuodessa" , 
	 'garbagecollector'  =>  "Roskankerääjä" , 
	 'garbagecollector:done'  =>  "VALMIS" , 
	 'garbagecollector:optimize'  =>  "Optimoidaan %s" , 
	 'garbagecollector:error'  =>  "VIRHE" , 
	 'garbagecollector:ok'  =>  "OK" , 
	 'garbagecollector:gc:metastrings'  =>  "Poista linkittämättömät metaketjut:"
); 

add_translation('fi', $finnish); 

?>