<?php

// Luotu Käännösselaimella. 

$finnish = array( 
	 'media:insert'  =>  "Upota / hae mediatiedosto" , 
	 'embed:instructions'  =>  "Napsauta mitä tahansa tiedostoa upottaaksesi sen sisältöön." , 
	 'embed:media'  =>  "Upota mediatiedosto" , 
	 'upload:media'  =>  "Hae mediatiedosto" , 
	 'embed:file:required'  =>  "Tiedoston hakeminen ei onnistunut. Ylläpitäjän pitää ottaa käyttöön tiedostoliitännäinen tai vastaava."
); 

add_translation('fi', $finnish); 

?>