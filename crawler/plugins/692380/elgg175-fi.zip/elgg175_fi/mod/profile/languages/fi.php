<?php

// Luotu Käännösselaimella. 

$finnish = array( 
	 'profile'  =>  "Profiili" , 
	 'profile:edit:default'  =>  "Korvaa profiilikentät" , 
	 'profile:preview'  =>  "Esikatsele" , 
	 'profile:yours'  =>  "Oma profiilisi" , 
	 'profile:user'  =>  "Käyttäjän %s profiili" , 
	 'profile:edit'  =>  "Muokkaa profiilia" , 
	 'profile:profilepictureinstructions'  =>  "Profiilikuvasi on kuva joka näytetään profiilisivullasi.
Voit vaihtaa sen aina kun haluat. (Sallitut tiedostomuodot ovat: GIF, JPG ja PNG)" , 
	 'profile:icon'  =>  "Profiilikuva" , 
	 'profile:createicon'  =>  "Luo profiilikuva" , 
	 'profile:currentavatar'  =>  "Nykyinen profiilikuva" , 
	 'profile:createicon:header'  =>  "Profiilikuva" , 
	 'profile:profilepicturecroppingtool'  =>  "Profiilikuvan rajaustyökalu" , 
	 'profile:createicon:instructions'  =>  "Napsauta ja vedä neliötä alapuolella määritelläksesi haluamasi kuvan rajauksen. Esikatselu rajatusta kuvasta näytetään oikealla olevassa laatikossa. Kun olet tyytyväinen esikatselukuvaan, napsauta \"Luo profiilikuva\". Tätä rajattua kuvaa käytetään profiilikuvanasi koko sivustolla." , 
	 'profile:editdetails'  =>  "Muokkaa yksityiskohtia" , 
	 'profile:editicon'  =>  "Muokkaa profiilikuvaa" , 
	 'profile:aboutme'  =>  "Tietoa minusta" , 
	 'profile:description'  =>  "Tietoa minusta" , 
	 'profile:briefdescription'  =>  "Lyhyt kuvaus" , 
	 'profile:location'  =>  "Sijainti" , 
	 'profile:skills'  =>  "Taidot" , 
	 'profile:interests'  =>  "Kiinnostuksen kohteet" , 
	 'profile:contactemail'  =>  "Sähköpostiosoite" , 
	 'profile:phone'  =>  "Puhelin" , 
	 'profile:mobile'  =>  "Matkapuhelin" , 
	 'profile:website'  =>  "Web-sivu" , 
	 'profile:banned'  =>  "Tämä käyttäjätunnus on poistettu käytöstä." , 
	 'profile:deleteduser'  =>  "Poistettu käyttäjä" , 
	 'profile:river:update'  =>  "%s päivitti profiilinsa" , 
	 'profile:river:iconupdate'  =>  "%s päivitti profiilikuvansa" , 
	 'profile:label'  =>  "Profiilin otsikko" , 
	 'profile:type'  =>  "Profiilin tyyppi" , 
	 'profile:editdefault:fail'  =>  "Oletusprofiilia ei voitu tallentaa" , 
	 'profile:editdefault:success'  =>  "Kohde lisätty oletusprofiiliin" , 
	 'profile:editdefault:delete:fail'  =>  "Kohteen poistaminen oletusprofiilista epäonnistui" , 
	 'profile:editdefault:delete:success'  =>  "Oletusprofiilin kohde poistettu!" , 
	 'profile:defaultprofile:reset'  =>  "Järjestelmän oletusprofiili nollattu" , 
	 'profile:resetdefault'  =>  "Nollaa oletusprofiili" , 
	 'profile:explainchangefields'  =>  "Voit korvata olemassa olevat profiilikentät omilla kentillä käyttämällä alla olevaa lomaketta. Kirjoita ensin uuden profiilikentän otsikko, esimerkiksi 'Suosikkijoukkue'. Valitse seuraavaksi kentän tyyppi, esimerkiksi tagit, url, teksti ja niin edelleen. Voit milloin tahansa palauttaa oletusprofiilin kentät." , 
	 'profile:saved'  =>  "Profiili tallennettiin onnistuneesti." , 
	 'profile:icon:uploaded'  =>  "Profiilikuvasi ladattiin onnistuneesti." , 
	 'profile:noaccess'  =>  "Sinulla ei ole oikeuksia muokata tätä profiilia." , 
	 'profile:notfound'  =>  "Määriteltyä profiilia ei löytynyt." , 
	 'profile:icon:notfound'  =>  "Virhe ladattaessa profiilikuvaa." , 
	 'profile:icon:noaccess'  =>  "Et voi muuttaa tätä profiilikuvaa" , 
	 'profile:field_too_long'  =>  "Profiilin tietoja ei voitu tallentaa koska \"%s\" -kenttä on liian pitkä."
); 

add_translation('fi', $finnish); 

?>