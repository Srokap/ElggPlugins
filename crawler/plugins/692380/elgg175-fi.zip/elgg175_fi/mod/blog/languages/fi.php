<?php

// Luotu Käännösselaimella. 

$finnish = array( 
	 'blog'  =>  "Blogi" , 
	 'blogs'  =>  "Blogit" , 
	 'blog:user'  =>  "Käyttäjän %s blogi" , 
	 'blog:user:friends'  =>  "Käyttäjän %s ystävien blogit" , 
	 'blog:your'  =>  "Sinun blogisi" , 
	 'blog:posttitle'  =>  "Käyttäjän %s blogi: %s" , 
	 'blog:friends'  =>  "Ystävien blogit" , 
	 'blog:yourfriends'  =>  "Ystäviesi viimeisimmät blogit" , 
	 'blog:everyone'  =>  "Kaikki sivuston blogit" , 
	 'blog:newpost'  =>  "Uusi blogiviesti" , 
	 'blog:via'  =>  "blogista" , 
	 'blog:read'  =>  "Lue blogia" , 
	 'blog:addpost'  =>  "Kirjoita blogiviesti" , 
	 'blog:editpost'  =>  "Muokkaa blogiviestiä" , 
	 'blog:text'  =>  "Blogin teksti" , 
	 'blog:strapline'  =>  "%s" , 
	 'item:object:blog'  =>  "Blogiviestit" , 
	 'blog:never'  =>  "ei koskaan" , 
	 'blog:preview'  =>  "Esikatsele" , 
	 'blog:draft:save'  =>  "Tallenna luonnos" , 
	 'blog:draft:saved'  =>  "Luonnos viimeksi tallennettu " , 
	 'blog:comments:allow'  =>  "Salli kommentit" , 
	 'blog:preview:description'  =>  "Tämä on tallentamaton esikatselunäkymä blogiviestistä." , 
	 'blog:preview:description:link'  =>  "Jatkaaksesi muokkausta tai tallentaaksi viestin, klikkaa tästä." , 
	 'groups:enableblog'  =>  "Salli ryhmän blogit" , 
	 'blog:group'  =>  "Ryhmän blogi" , 
	 'blog:nogroup'  =>  "Tällä ryhmällä ei ole blogiviestejä" , 
	 'blog:more'  =>  "Lisää blogiviestejä" , 
	 'blog:read_more'  =>  "Näytä koko viesti" , 
	 'blog:widget:description'  =>  "Tämä vimpain näyttää viimeisimmät blogiviestit." , 
	 'blog:moreblogs'  =>  "Lisää blogiviestejä" , 
	 'blog:numbertodisplay'  =>  "Näytettävien blogiviestien määrä" , 
	 'blog:river:created'  =>  "%s kirjoitti" , 
	 'blog:river:updated'  =>  "%s päivitti" , 
	 'blog:river:posted'  =>  "%s lähetti" , 
	 'blog:river:create'  =>  "uuden blogiviestin otsikolla" , 
	 'blog:river:update'  =>  "blogiviestin otsikolla " , 
	 'blog:river:annotate'  =>  "kommentin blogiviestiin" , 
	 'blog:posted'  =>  "Blogiviestisi lähetettiin onnistuneesti." , 
	 'blog:deleted'  =>  "Blogiviestisi poistettiin." , 
	 'blog:error'  =>  "Jokin meni vikaan. Yritä uudelleen." , 
	 'blog:save:failure'  =>  "Blogiviestiäsi ei voitu tallentaa. Yritä uudelleen." , 
	 'blog:blank'  =>  "Sinun täytyy täyttää sekä otsikko että viestikenttä ennen kuin voit postittaa viestin." , 
	 'blog:notfound'  =>  "Haluamaasi blogiviestiä ei löydetty." , 
	 'blog:notdeleted'  =>  "Blogiviestiä ei voitu poistaa." , 
	 'blog:conversation'  =>  "Keskustelu"
); 

add_translation('fi', $finnish); 

?>