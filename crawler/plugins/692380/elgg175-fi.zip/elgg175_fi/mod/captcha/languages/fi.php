<?php

// Luotu Käännösselaimella. 

$finnish = array( 
	 'captcha:entercaptcha'  =>  "Kirjoita kuvan teksti" , 
	 'captcha:captchafail'  =>  "Kirjoittamasi teksti ei vastannut kuvassa olevaa."
); 

add_translation('fi', $finnish); 

?>