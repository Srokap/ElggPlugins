<?php

// Luotu Käännösselaimella. 

$finnish = array( 
	 'thewire'  =>  "Tila" , 
	 'thewire:user'  =>  "Käyttäjän %s tilapäivitykset" , 
	 'thewire:posttitle'  =>  "Käyttäjän %s lisäämät tilapäivitykset: %s" , 
	 'thewire:everyone'  =>  "Kaikki tilapäivitykset" , 
	 'thewire:read'  =>  "Tilapäivitykset" , 
	 'thewire:strapline'  =>  "%s" , 
	 'thewire:add'  =>  "Päivitä tila" , 
	 'thewire:text'  =>  "Kommentoi tilaa" , 
	 'thewire:reply'  =>  "Vastaa" , 
	 'thewire:wired'  =>  "Lähetti tilapäivityksen" , 
	 'thewire:charleft'  =>  "merkkiä jäljellä" , 
	 'item:object:thewire'  =>  "Tilapäivitykset" , 
	 'thewire:notedeleted'  =>  "viesti poistettu" , 
	 'thewire:doing'  =>  "Mitä teet? Kerro se kaikille tilapäivityksellä:" , 
	 'thewire:newpost'  =>  "Uusi tilapäivitys" , 
	 'thewire:addpost'  =>  "Lähetä tilapäivitys" , 
	 'thewire:by'  =>  "Käyttäjän %s tilapäivitys" , 
	 'thewire:update'  =>  "päivitä" , 
	 'thewire:river:created'  =>  "%s lähetti" , 
	 'thewire:river:create'  =>  "tilapäivityksen." , 
	 'thewire:sitedesc'  =>  "Tämä vimpain näyttää viimeisimmät tilapäivitykset" , 
	 'thewire:yourdesc'  =>  "Tämä vimpain näyttää viimeisimmät tilapäivitykset" , 
	 'thewire:friendsdesc'  =>  "Tämä vimpain näyttää ystäviesi viimeisimmät tilapäivitykset" , 
	 'thewire:friends'  =>  "Ystäviesi tilapäivitykset" , 
	 'thewire:num'  =>  "Näytettävien viestien määrä" , 
	 'thewire:moreposts'  =>  "Lisää tilapäivityksiä" , 
	 'thewire:posted'  =>  "Viesti lähetetty." , 
	 'thewire:deleted'  =>  "Viesti poistettu." , 
	 'thewire:blank'  =>  "Sinun pitää kirjoittaa tekstikenttään jotain ennen tallennusta." , 
	 'thewire:notfound'  =>  "Määriteltyä tilapäivitystä ei löytynyt." , 
	 'thewire:notdeleted'  =>  "Tilapäivitystä ei voitu poistaa." , 
	 'thewire:smsnumber'  =>  "SMS-puhelinnumerosi, jos eroaa matkapuhelinnumerostasi (matkapuhelinnumero pitää asettaa julkiseksi että sitä voidaan käyttää pikaviestimessä). Kaikki puhelinnumerot pitää olla kansainvälisessä muodossa." , 
	 'thewire:channelsms'  =>  "Numero johon SMS-viestit lähetetään on: %s" , 
	 'thewire:via_method'  =>  "%s kautta" , 
	 'thewire:friends:title'  =>  "Käyttäjän %s tilapäivitykset" , 
	 'thewire:yours'  =>  "Omat tilapäivityksesi" , 
	 'thewire:theirs'  =>  "Käyttäjän %s tilapäivitykset" , 
	 'thewire:twitterservice:desc'  =>  "Lähettää kaikki tilapäivitykset Twitteriin."
); 

add_translation('fi', $finnish); 

?>