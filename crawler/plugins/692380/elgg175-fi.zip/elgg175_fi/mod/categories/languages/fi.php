<?php

// Luotu Käännösselaimella. 

$finnish = array( 
	 'categories'  =>  "Kategoriat" , 
	 'categories:settings'  =>  "Aseta sivuston kategoriat" , 
	 'categories:explanation'  =>  "Asettaaksesi ennalta määritellyt sivustokohtaiset kategoriat, syötä ne alla olevaan kenttään pilkulla eroteltuna. Kategoriat on valittavissa tietyissä työkaluissa kun käyttäjä luo tai muokkaa sisältöä." , 
	 'categories:save:success'  =>  "Sivuston kategoriat tallennettiin onnistuneesti." , 
	 'categories:results'  =>  "Tulokset sivuston kategorialle: %s"
); 

add_translation('fi', $finnish); 

?>