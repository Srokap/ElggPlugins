<?php

// Luotu Käännösselaimella. 

$finnish = array( 
	 'search:enter_term'  =>  "Kirjoita hakuehto: " , 
	 'search:no_results'  =>  "Ei tuloksia." , 
	 'search:matched'  =>  "Tulokset: " , 
	 'search:results'  =>  "Tuloksia haulle %s" , 
	 'search:no_query'  =>  "Kirjoita hakusana" , 
	 'search:search_error'  =>  "Virhe" , 
	 'search:more'  =>  "+%s lisää %s" , 
	 'search_types:tags'  =>  "Tagit" , 
	 'search_types:comments'  =>  "Kommentit" , 
	 'search:comment_on'  =>  "Kommentit kohteelle \"%s\"" , 
	 'search:comment_by'  =>  "käyttäjältä" , 
	 'search:unavailable_entity'  =>  "Kohdetta ei saatavilla"
); 

add_translation('fi', $finnish); 

?>