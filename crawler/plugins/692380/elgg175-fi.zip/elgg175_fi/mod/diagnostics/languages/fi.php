<?php

// Luotu Käännösselaimella. 

$finnish = array( 
	 'diagnostics'  =>  "Järjestelmän diagnostiikka" , 
	 'diagnostics:unittester'  =>  "Yksikkötestit" , 
	 'diagnostics:description'  =>  "Seuraava diagnostiikkaraportti on hyödyllinen Elggin virheiden jäljityksessä, ja se tulisi liittää kaikkiin lähetettäviin ongelmaraportteihin." , 
	 'diagnostics:unittester:description'  =>  "Yksikkötestit tarkistavat Elggin ytimen mahdollisten API-virheiden ja bugien osalta." , 
	 'diagnostics:unittester:debug'  =>  "Sivuston pitää olla virheidenjäljitysmoodissa yksikkötestien suorittamiseksi." , 
	 'diagnostics:unittester:warning'  =>  "VAROITUS: Nämä testit voivat jättää joitakin virheidenjäljitys-objekteja tietokantaan. ÄLÄ KÄYTÄ TUOTANTOSIVUSTOLLA!" , 
	 'diagnostics:test:executetest'  =>  "Suorita testi" , 
	 'diagnostics:test:executeall'  =>  "Suorita kaikki" , 
	 'diagnostics:unittester:notests'  =>  "Yksikkötestausmoduuleja ei ole asennettuna." , 
	 'diagnostics:unittester:testnotfound'  =>  "Raporttia ei voitu luoda koska testiä ei löytynyt" , 
	 'diagnostics:unittester:testresult:nottestclass'  =>  "EPÄONNISTUI - Tulos ei ole testiluokka" , 
	 'diagnostics:unittester:testresult:fail'  =>  "EPÄONNISTUI" , 
	 'diagnostics:unittester:testresult:success'  =>  "ONNISTUI" , 
	 'diagnostics:unittest:example'  =>  "Esimerkki yksikkötestistä, käytettävissä ainoastaan virheidenjäljitysmoodissa." , 
	 'diagnostics:unittester:report'  =>  "Testiraportti: %s" , 
	 'diagnostics:download'  =>  "Lataa .txt" , 
	 'diagnostics:header'  =>  "========================================================================
Elggin Diagnostiikkaraportti
Luotu: %s, luonut: %s
========================================================================
			
" , 
	 'diagnostics:report:basic'  =>  "Elgg-julkaisu: %s, versio: %s

------------------------------------------------------------------------" , 
	 'diagnostics:report:php'  =>  "PHP info:
%s
------------------------------------------------------------------------" , 
	 'diagnostics:report:plugins'  =>  "Asennetut liitännäiset ja yksityiskohdat:

%s
------------------------------------------------------------------------" , 
	 'diagnostics:report:md5'  =>  "Asennetut tiedostot ja tarkistussummat:

%s
------------------------------------------------------------------------" , 
	 'diagnostics:report:globals'  =>  "Globaalit muuttujat:

%s
------------------------------------------------------------------------"
); 

add_translation('fi', $finnish); 

?>