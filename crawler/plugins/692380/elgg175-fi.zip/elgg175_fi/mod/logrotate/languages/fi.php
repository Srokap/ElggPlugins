<?php

// Luotu Käännösselaimella. 

$finnish = array( 
	 'logrotate:period'  =>  "Kuinka usein loki pitäisi arkistoida?" , 
	 'logrotate:weekly'  =>  "Kerran viikossa" , 
	 'logrotate:monthly'  =>  "Kerran kuussa" , 
	 'logrotate:yearly'  =>  "Kerran vuodessa" , 
	 'logrotate:logrotated'  =>  "Loki kierrätetty" , 
	 'logrotate:lognotrotated'  =>  "VIrhe lokien kierrätyksessä"
); 

add_translation('fi', $finnish); 

?>