<?php

$finnish = array(

	/**
	 * Menu items and titles
	 */

	 'messageboard:board'  =>  "Sein�" , 
	 'messageboard:messageboard'  =>  "sein�" , 
	 'messageboard:viewall'  =>  "N�yt� kaikki" , 
	 'messageboard:postit'  =>  "L�het� " , 
	 'messageboard:history:title'  =>  "Historia" , 
	 'messageboard:none'  =>  "T�ll� sein�ll� ei ole viel� mit��n" , 
	 'messageboard:num_display'  =>  "N�ytett�vien viestien m��r�" , 
	 'messageboard:desc'  =>  "T�m� on sein� jonka voit lis�t� profiilisivullesi ja muut k�ytt�j�t voivat j�tt�� sinulle viestej�." , 

	 'messageboard:user'  =>  "K�ytt�j�n %s sein�" , 

	 'messageboard:replyon'  =>  "vastaus viestiin" , 
	 'messageboard:history'  =>  "historia" , 

	/**
	 * Message board widget river
	 **/

	 'messageboard:river:annotate'  =>  "K�ytt�j�n %s sein�ll� on uusi viesti." , 
	 'messageboard:river:create'  =>  "%s lis�si sein�-vimpaimen." , 
	 'messageboard:river:update'  =>  "%s p�ivitti sein�-vimpaimen." , 
	 'messageboard:river:added'  =>  "%s l�hetti viestin" , 
	 'messageboard:river:messageboard'  =>  "sein�lle" , 


	/**
	 * Status messages
	 */

	'messageboard:posted' => "L�hetit viestin sein�lle.",
	'messageboard:deleted' => "Poistit viestin.",

	/**
	 * Email messages
	 */

	 'messageboard:email:subject'  =>  "Sinulla on uusi viesti sein�ll�si." , 
	 'messageboard:email:body'  =>  "%s on j�tt�nyt sinulle uuden viestin sein�llesi. Siin� lukee: 

			
%s


Katsoaksesi sein�si viestej� napsauta linkki�:

%s

N�hd�ksesi k�ytt�j�n %s profiilin, napsauta linkki�:

%s

Et voi vastata t�h�n s�hk�postiin." , 



	/**
	 * Error messages
	 */

	 'messageboard:blank'  =>  "Sinun t�ytyy kirjoittaa viestikentt��n jotain, jotta se voidaan tallentaa." , 
	 'messageboard:notfound'  =>  "M��ritelty� kohdetta ei l�ytynyt." , 
	 'messageboard:notdeleted'  =>  "Viesti� ei voitu poistaa." , 
	 'messageboard:somethingwentwrong'  =>  "Jokin meni pieleen tallennettaessa viesti�, varmista ett� kirjoitit viestin." , 
	 'messageboard:failure'  =>  "Tapahtui odottamaton virhe lis�tt�ess� viesti�. Yrit� uudelleen."

);

add_translation("fi",$finnish);
