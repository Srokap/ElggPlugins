<?php

// Luotu Käännösselaimella. 

$finnish = array( 
	 'logbrowser'  =>  "Lokiselain" , 
	 'logbrowser:browse'  =>  "Selaa järjestelmälokia" , 
	 'logbrowser:search'  =>  "Suodatetut tulokset" , 
	 'logbrowser:user'  =>  "Käyttäjänimi jonka mukaan haluat etsiä" , 
	 'logbrowser:starttime'  =>  "Alkamisaika (esimerkiksi \"viime maanantai\", \"tunti sitten\")" , 
	 'logbrowser:endtime'  =>  "Loppumisaika" , 
	 'logbrowser:explore'  =>  "Tutki lokia"
); 

add_translation('fi', $finnish); 

?>