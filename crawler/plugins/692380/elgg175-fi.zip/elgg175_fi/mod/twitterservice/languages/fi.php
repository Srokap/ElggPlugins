<?php
/**
 * An english language definition file
 */

$finnish = array(
	'twitterservice' => 'Twitter-palvelut',

	'twitterservice:consumer_key' => 'Consumer Key',
	'twitterservice:consumer_secret' => 'Consumer Secret',

	'twitterservice:usersettings:description' => "Linkit� {$CONFIG->site->name} -tilisi Twitteriin.",
	'twitterservice:usersettings:request' => "Sinun pit�� <a href=\"%s\">auktorisoida</a> {$CONFIG->site->name} kytke�ksesi Twitter-tilisi.",
	'twitterservice:authorize:error' => 'Twitter-aauktorisointi ep�onnistui.',
	'twitterservice:authorize:success' => 'Twitter-p��sy pit�� auktorisoida.',

	'twitterservice:usersettings:authorized' => "Olet auktorisoinut {$CONFIG->site->name} -palvelun Twitter-tiliisi: @%s.  Jos twiittaukset ei n�y, saatat joutua auktorisoimaan uudelleen.  Napsauta palauta alapuolelta, ja mene osoitteeseen <a href=\"http://twitter.com/settings/connections\">Twitter-yhteysasetukset</a> ja palauta oikeudet tiliin %s.  Palaa sen j�lkeen takaisin t�lle sivulle ja auktorisoi uudelleen.",
	'twitterservice:usersettings:revoke' => 'Napsauta <a href="%s">t�st�</a> palauttaaksesi oikeudet.',
	'twitterservice:revoke:success' => 'Twitter-oikeudet palautettu.',

	'twitterservice:usersettings:allowed_plugins' => 'Sallitut liit�nn�iset',
);

add_translation('fi', $finnish);
