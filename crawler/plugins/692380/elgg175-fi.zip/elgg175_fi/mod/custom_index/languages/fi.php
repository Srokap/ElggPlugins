<?php

// Luotu Käännösselaimella. 

$finnish = array( 
	 'custom:bookmarks'  =>  "Viimeisimmät kirjanmerkit" , 
	 'custom:groups'  =>  "Viimeisimmät ryhmät" , 
	 'custom:files'  =>  "Viimeisimmät tiedostot" , 
	 'custom:blogs'  =>  "Viimeisimmät blogiviestit" , 
	 'custom:members'  =>  "Uusimmat jäsenet" , 
	 'custom:nofiles'  =>  "Ei lisättyjä tiedostoja" , 
	 'custom:nogroups'  =>  "Ei ryhmiä vielä"
); 

add_translation('fi', $finnish); 

?>