<?php

// Luotu Käännösselaimella. 

$finnish = array( 
	 'bookmarks'  =>  "Kirjanmerkit" , 
	 'bookmarks:add'  =>  "Lisää kirjanmerkki" , 
	 'bookmarks:read'  =>  "Käyttäjän %s kirjanmerkit" , 
	 'bookmarks:friends'  =>  "Ystävien kirjanmerkit" , 
	 'bookmarks:everyone'  =>  "Kaikki sivuston kirjanmerkit" , 
	 'bookmarks:this'  =>  "Lisää kirjanmerkiksi" , 
	 'bookmarks:this:group'  =>  "Kirjanmerkit kohteessa %s" , 
	 'bookmarks:bookmarklet'  =>  "Lataa Boorkmarklet-sovellus" , 
	 'bookmarks:bookmarklet:group'  =>  "Lataa ryhmän Bookmarklet-sovellus." , 
	 'bookmarks:inbox'  =>  "Kirjanmerkit-kansio" , 
	 'bookmarks:morebookmarks'  =>  "Lisää kirjanmerkkejä" , 
	 'bookmarks:more'  =>  "Lisää kirjanmerkkejä" , 
	 'bookmarks:shareditem'  =>  "Kirjanmerkitty kohde" , 
	 'bookmarks:with'  =>  "Jaa käyttäjille" , 
	 'bookmarks:new'  =>  "Uusi kirjanmerkki" , 
	 'bookmarks:via'  =>  "kirjanmerkkien kautta" , 
	 'bookmarks:address'  =>  "Kirjanmerkin lähteen osoite" , 
	 'bookmarks:delete:confirm'  =>  "Haluatko varmasti poistaa tämän lähteen?" , 
	 'bookmarks:numbertodisplay'  =>  "Näytettävien kirjanmerkkien määrä" , 
	 'bookmarks:shared'  =>  "Kirjanmerkitty" , 
	 'bookmarks:visit'  =>  "Avaa linkki" , 
	 'bookmarks:recent'  =>  "Viimeisimmät kirjanmerkit" , 
	 'bookmarks:river:created'  =>  "%s kirjanmerkitty" , 
	 'bookmarks:river:annotate'  =>  "kommentoi tätä kirjanmerkkiä" , 
	 'bookmarks:river:item'  =>  "kohde" , 
	 'item:object:bookmarks'  =>  "Kirjanmerkityt kohteet" , 
	 'bookmarks:group'  =>  "Ryhmän kirjanmerkit" , 
	 'groups:enablebookmarks'  =>  "Salli ryhmän kirjanmerkit" , 
	 'bookmarks:nogroup'  =>  "Tällä ryhmällä ei ole kirjanmerkkejä" , 
	 'bookmarks:widget:description'  =>  "Tämä vimpain näyttää viimeisimmät kirjanmerkkisi." , 
	 'bookmarks:bookmarklet:description'  =>  "Boorkmarklet-sovelluksen avulla voit lisätä minkä tahansa www-sivun kirjanmerkiksi ja jakaa sen ystäviesi kanssa, tai tallentaa sen ainoastaan itsellesi. Käyttääksesi sitä, vedä alla oleva painike selaimesi linkkivalikkoon:" , 
	 'bookmarks:bookmarklet:descriptionie'  =>  "Jos käytät Internet Exploreria täytyy sinun klikata hiiren oikealla painikkeella Bookmarklet-sovelluksen kuvaketta ja sieltä vaihtoehto \"lisää suosikkeihin\" ja tämän jälkeen valita Linkit-palkki." , 
	 'bookmarks:bookmarklet:description:conclusion'  =>  "Silloin voit tallentaa minkä tahansa sivun, jolla vierailet vain klikkaamalla sitä. " , 
	 'bookmarks:save:success'  =>  "Kohde lisättiin kirjanmerkkeihin." , 
	 'bookmarks:delete:success'  =>  "Kirjanmerkittu kohde poistettiin." , 
	 'bookmarks:save:failed'  =>  "Kirjanmerkittua kohdetta ei voitu tallentaa. Tarkista että syötit kaikki vaaditut tiedot ja yritä uudelleen." , 
	 'bookmarks:delete:failed'  =>  "Kirjanmerkittua kohdetta ei voitu poistaa. Yritä uudelleen." , 
	 'bookmarks:no_title'  =>  "Ei otsikkoa"
); 

add_translation('fi', $finnish); 

?>