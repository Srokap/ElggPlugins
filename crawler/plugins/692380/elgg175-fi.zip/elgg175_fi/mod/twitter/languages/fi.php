<?php

// Luotu Käännösselaimella. 

$finnish = array( 
	 'twitter:username'  =>  "Kirjoita Twitter-käyttäjänimesi." , 
	 'twitter:num'  =>  "Näytettävien \"viserrysten\" määrä." , 
	 'twitter:visit'  =>  "Vieraile omassa Twitterissä" , 
	 'twitter:notset'  =>  "Twitter-vimpainta ei ole vielä määritelty. Nähdäksesi viimeisimmät viserrykset, napsauta - muokkaa - ja täytä tarvittavat tiedot" , 
	 'twitter:river:created'  =>  "%s lisäsi Twitter-vimpaimen." , 
	 'twitter:river:updated'  =>  "%s päivitti Twitter-vimpaimen." , 
	 'twitter:river:delete'  =>  "%s poisti Twitter-vimpaimen."
); 

add_translation('fi', $finnish); 

?>