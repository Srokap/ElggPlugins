<?php

// Luotu Käännösselaimella. 

$finnish = array( 
	 'friends:widget:description'  =>  "Näyttää joitakin ystäviäsi." , 
	 'friends:num_display'  =>  "Näytettävien ystävien määrä" , 
	 'friends:icon_size'  =>  "Kuvakkeen koko" , 
	 'friends:tiny'  =>  "minimaalinen" , 
	 'friends:small'  =>  "pieni"
); 

add_translation('fi', $finnish); 

?>