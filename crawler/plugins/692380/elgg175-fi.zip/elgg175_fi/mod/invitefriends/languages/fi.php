<?php

// Luotu Käännösselaimella. 

$finnish = array( 
	 'friends:invite'  =>  "Kutsu ystäviä" , 
	 'invitefriends:introduction'  =>  "Kutsuaksesi ystäviä omaan verkostoosi, kirjoita heidän sähköpostiosoitteensa alapuolelle (yksi per rivi):" , 
	 'invitefriends:message'  =>  "Kirjoita viesti jonka ystäväsi saavat kutsun yhteydessä:" , 
	 'invitefriends:subject'  =>  "Kutsu liittyä yhteisöön %s" , 
	 'invitefriends:success'  =>  "Ystäväsi kutsuttiin." , 
	 'invitefriends:invitations_sent'  =>  "Kutsut lähetetty: %s. Seuraavat ongelmat havaittiin:" , 
	 'invitefriends:email_error'  =>  "Seuraavat osoitteet eivät ole kelvollisia: %s" , 
	 'invitefriends:already_members'  =>  "Seuraavat henkilöt ovat jo jäseninä: %s" , 
	 'invitefriends:noemails'  =>  "Sähköpostiosoitetta ei määritelty." , 
	 'invitefriends:message:default'  =>  "Hei,

Haluaisin kutsua sinut liittymään verkostooni palvelussa %s." , 
	 'invitefriends:email'  =>  "Sinut on kutsuttu jäseneksi yhteisöön %s, kutsun lähetti %s. Kutsuun sisältyy seuraava viesti:

%s

Liittyäksesi, napsauta alla olevaa linkkiä:

%s

Lisäät kutsun lähettäjän automaattisesti ystäväksesi kun rekisteröidyt."
); 

add_translation('fi', $finnish); 

?>