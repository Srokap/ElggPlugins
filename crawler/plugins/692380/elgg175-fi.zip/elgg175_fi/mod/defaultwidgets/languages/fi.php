<?php

// Luotu Käännösselaimella. 

$finnish = array( 
	 'item:object:moddefaultwidgets'  =>  "Oletusvimpainten asetukset" , 
	 'defaultwidgets:menu:profile'  =>  "Profiilin oletusvimpaimet" , 
	 'defaultwidgets:menu:dashboard'  =>  "Kojelaudan oletusvimpaimet" , 
	 'defaultwidgets:admin:error'  =>  "Virhe: Et ole kirjautunut ylläpitäjänä" , 
	 'defaultwidgets:admin:notfound'  =>  "Virhe: Sivua ei löydy" , 
	 'defaultwidgets:admin:loginfailure'  =>  "Varoitus: Et ole kirjautuneena ylläpitäjänä" , 
	 'defaultwidgets:update:success'  =>  "Vimpainasetukset tallennettiin onnistuneesti" , 
	 'defaultwidgets:update:failed'  =>  "Virhe: asetuksia ei tallennettu" , 
	 'defaultwidgets:update:noparams'  =>  "Virhe: virheelliset lomakkeen parametrit" , 
	 'defaultwidgets:profile:title'  =>  "Aseta oletusvimpaimet uusien käyttäjien profiilisivulle" , 
	 'defaultwidgets:dashboard:title'  =>  "Aseta oletusvimpaimet uusien käyttäjien kojelaudalle"
); 

add_translation('fi', $finnish); 

?>