<?php
/** original version by http://www.aperto-elearning.com/
 * Altered significantly by Ed Lyons (June 2008, ejlyons@ix.netcom.com)
 * Adapted by Facyla http://id.facyla.net
 * http://www.gnu.org/copyleft/gpl.html
*/

/* Elgg database info --------------------------- */
define('ELGG_DB_HOST', 'localhost');
define('ELGG_DB_NAME', '');
define('ELGG_DB_USER', '');
define('ELGG_DB_PASSWORD', '');
define('ELGG_DB_PREFIX', 'elgg');

require_once('ElggAuthPlugin.i18n.php');

/*
  RUN_MODE is here so that you can control what happens when something goes wrong.  If you leave it at testing, users who try to do things
  you don't want to will get information about your setup that you might not want them to have
  Values : testing, anything else
*/
define('RUN_MODE', 'production');
define('ELGG_MW_MW_SSO_MODE', 'sso');  // Should MW be considered as fully integrated into Elgg OR able to operate independantly ? Values : slave | sso

/*
 You can use this to limit what domain you use for this integration:
 You might want to know why we have two variables here.  Well, if I just used the VALID_DOMAIN to www.yoursite.com - people might forget
 to change this setting, and wonder why it isn't working.  So if you want to do this, change it to true, then change the site name.
*/
define('CHECK_DOMAIN', true);
define('VALID_DOMAIN', '');
define('ELGG_MW_MW_WIKI_COOKIE_PREFIX', 'yourdomainprefix_');  // MW cookie prefix_ (with the underscore) ; check your cookies if you're not sure

/* ELGG_MW_ELGG_AUTH_COOKIE_NAME: the name of the authentication cookie set by Elgg.
This must match the value set in the AUTH_COOKIE constant in (was in <elgg_dir>/units/users.conf.php in v1.1) ???
Default is "Elgg".
*/
define('ELGG_MW_ELGG_AUTH_COOKIE_NAME', 'Elgg');

/* ELGG_PATH: the path relative to the host where Elgg is installed.
  The default value here ('../') is if MW is a subdirectory of your Elgg installation
*/
define('ELGG_PATH', '../');

/* ELGG_MW_PUBLIC_ACTIONS: comma-delimited list of wiki actions that can be performed without being logged in to Elgg. DO NOT INCLUDE SPACES.
If you want a walled garden, leave this as '' as that will mean that the user cannot see anything without being logged in.
If you wanted the wiki to be readable without a login (probabaly more common) then you might want:
define('ELGG_MW_PUBLIC_ACTIONS', 'view,history');
*/
//    define('ELGG_MW_PUBLIC_ACTIONS', '');
define('ELGG_MW_PUBLIC_ACTIONS', 'view,history');

/* ELGG_MW_PUBLIC_PAGE_ACTIONS: an associative array of page titles and their comma-delimited public actions. DO NOT INCLUDE SPACES. 
This takes precedence over ELGG_MW_PUBLIC_ACTIONS.
I didn't fully understand this setting.  I wanted a walled garden, so I made it accept nothing.  I think this means what pages you want 
to be available no matter what happens - so you could do something like this and make sure that at least the CSS shows....
array(
    'MediaWiki:Common.css'=>'view,raw',
    'MediaWiki:Earthblog.css'=>'view,raw',
    '-'=>'raw');

Note that the preceding example was what the original default was.
*/
$ELGG_MW_PUBLIC_PAGE_ACTIONS = array(
  ''=>''  
  );

/* ELGG_MW_ELGG_WIKI_COOKIE_EXPIRY: specifies the number of seconds before Wiki cookies expire. (This value will be written to MediaWiki's
$wgCookieExpiration global variable.) When these cookies expire, the plugin will force an authentication check against the Elgg database. 
If the check passes, the cookies are recreated automatically. */
define('ELGG_MW_ELGG_WIKI_COOKIE_EXPIRY', 3600);

?>
