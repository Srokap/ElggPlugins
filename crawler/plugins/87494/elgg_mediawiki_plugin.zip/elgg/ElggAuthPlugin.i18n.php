<?php
/** original version by http://www.aperto-elearning.com/
 * Altered significantly by Ed Lyons (June 2008, ejlyons@ix.netcom.com)
 * Adapted by Facyla http://id.facyla.net
*/

/* ELGG_MW_ERR_AUTH_FAILURE: error message if the cookie is missing. */
define('ELGG_MW_ERR_AUTH_FAILURE', 'Vous devez être enregistré pour accomplir cette action.');
define('ELGG_MW_ERR_AUTH_FAILURE_PROD', "Un problème d'identification est survenu ; vous ne pouvez pas vous rendre directement sur cette page");

/* ELGG_MW_ERR_USER_NOT_FOUND: error message if the user was not found in the Elgg database. */
define('ELGG_MW_ERR_USER_NOT_FOUND', "Cet utilisateur n'existe pas dans Elgg.");
define('ELGG_MW_ERR_USER_NOT_FOUND_PROD', "Un problème est survenu lors de votre identification ; votre nom d'utilisateur n'a pas été trouvé.");

/* ELGG_MW_ERR_USER_BANNED: error message if the user is banned from Elgg */
define('ELGG_MW_ERR_USER_BANNED', 'Votre compte a été bloqué.');
define('ELGG_MW_ERR_USER_BANNED_PROD', "Ce compte n'est pas activé.");

/* For translation : all messages here */
define('ELGG_MW_ERR_DB_CONNECT_FAIL', "Impossible de se connecter à la base de données: ");
define('ELGG_MW_ERR_DB_CONNECT_FAIL_PROD', "Impossible de vous identifier. Condition d&apos;erreur ");
define('ELGG_MW_ERR_DB_TABLE_SELECT', "Impossible de sélectionner la base de données: ");
define('ELGG_MW_ERR_DB_REQUEST_FAIL', "Impossible d'effectuer la requête: ");
?>
