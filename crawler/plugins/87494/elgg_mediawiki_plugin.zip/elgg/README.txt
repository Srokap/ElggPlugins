============================================
=                                          =
= Elgg Authentication Plugin for MediaWiki =
= Originally by Aperto Elearning Sols.     =
= Modified and updated by Ed Lyons         =
= Modified and updated by Facyla           =
============================================


X--------------------------------------------------X
QUICK NOTE by Facyla (added last ;)
=> My modifications :
  1. update to meet Elgg v1.5 (DB scheme...)
  2. divided "constant" file into more standard packages : "settings" and "i18n" files
  3. added new setting : "sso" mode (you may login directly into MW) or "slave" (MW *need* Elgg to work. Beware: still not tested !)
  4. some small improvements i just don't remember, including utf-8 for error messages, etc.
  5. TODO : I didn't modify this readme file at all to reflect changes
=> tested with Elgg 1.5 and Mediawiki 1.13
=> and btw : no core modification !
X--------------------------------------------------X

Sections in this doc

* Requirements
* Installation
* How it works
* Including the Toolbar, Adding Wiki Button to It


Requirements
------------
This plugin has been tested with the following:

    - PHP 5.2.1 (don't know about earlier versions)
    - MySQL 5.0.2 (should work with earlier versions)
    - Elgg 0.9x
    - MediaWiki 1.12 (don't know about earlier versions)


Installation
------------

IMPORTANT: The Elgg instance and the MediaWiki instance must reside in the same
           domain.


1.  Create a subdirectory under <mediawiki_dir>/extensions named elgg.

2.  Extract these files into <mediawiki_dir>/extensions/elgg.

3.  Open <mediawiki_dir>/extensions/elgg/constants.php in a text editor and
    make sure the following settings are configured correctly:

        - ELGG_PATH: the path to access Elgg relative to the server. For example,
          if the URL to Elgg is http://www.myhost.com/elgg, then enter
          "elgg" (without the quotation marks).

        - ELGG_MW_ELGG_WIKI_COOKIE_EXPIRY: the number of seconds before
          MediaWiki cookies expire. When these cookies expire, the plugin will
          force an authentication check against the Elgg database. If the check
          passes, the cookies are recreated automatically.

        - ELGG_DB_HOST: the hostname of the machine hosting the Elgg database.

        - ELGG_DB_NAME: the name of the Elgg database.

        - ELGG_DB_USER: the user name with permissions on the Elgg database.

        - ELGG_DB_PASSWORD: the password of the Elgg database user.

        - ELGG_DB_PREFIX: Enter the database table prefix.
        
        - ELGG_RUN_MODE: Anything other than testing will result in not showing
          the user detailed error messages.
          
        - CHECK_DOMAIN: Set this to true to check for a valid domain
        - VALID_DOMAIN: Put the valid domain here
        
        (Domain checking is turned off by default.)


    You may want to change the other settings.
    You can refine the permissions by configuring the following:

        - ELGG_MW_PUBLIC_ACTIONS: comma-delimited list of wiki actions that
          can be performed without being logged in to Elgg. DO NOT INCLUDE SPACES.

        - ELGG_MW_PUBLIC_PAGE_ACTIONS: an associative array of page titles and their
          comma-delimited public actions. DO NOT INCLUDE SPACES. This takes precedence
          over ELGG_MW_PUBLIC_ACTIONS.
          
          Note that these two settings are for a walled garden by default. Check
          the documentation in that file for how to make the wiki readable
          by all.

4.  Open <mediawiki_dir>/LocalSettings.php in a text editor and add the
    following lines immediately before the PHP end-code delimiter (the "?>"):

        require_once('extensions/elgg/ElggAuthPlugin.php');
        $wgAuth = new ElggAuthPlugin();


How It Works
------------

All actions require a valid Elgg authentication cookie and the user must not be
banned from Elgg. When a user tries to visit a page, the
plugin first checks for the Elgg authentication cookie ("elggperm"). If the
cookie is missing, the user is denied access to the page and redirected to the
Elgg login page. If the cookie exists, the plugin uses the cookie value to
generate a hash which is used to look up the user in the Elgg database. If the
user is valid and has not been banned, the plugin creates the necessary cookies
in MediaWiki and starts a session. If the user does not exist in the Elgg
database, the user is redirected to the Elgg login page.

If the user exists in the Elgg database, but does not exist in the MediaWiki
database, a new account is created automatically. Once this is done, the user
is redirected to the appropriate wiki page.

The Elgg authentication cookie check is performed each time the user tries to
perform an action in the wiki. This means that if the user logs out of Elgg,
he will be denied access to the wiki until he logs in to Elgg again.

The user account lookup is only performed if the MediaWiki cookies do not
exist. This means that if a user is logged in to Elgg and MediaWiki and is
subsequently banned while still logged in, he will be denied access to Elgg
but continue to have access to the wiki until the MediaWiki cookies expire.

Thus, to ensure that the user's status in Elgg is rechecked at a reasonable
interval, the default MediaWiki cookie expiry is reduced to one hour.


Including the Toolbar, Adding Wiki Button to It
-------------------------------------------------
A lot of people probably want to have the toolbar above the wiki.  I will
explain how I did it - which definitely would need a little tweaking by
a serious CSS person.  But this will point you in the proper direction...

First of all, you might want to put the word 'Wiki' in your toolbar to get
to MW from some other part of Elgg.  You could create a simple plugin to
do this, or you can cheat and add it to code you already have that is already
adding something to the toolbar.  So..... you could go to

elgg/mod/newsclient/lib.php

and make sure line 12 has code like this:

if (isloggedin()) {
    if (defined("context") && context == "resources" && $page_owner == $_SESSION['userid']) {
	$PAGE->menu[] = array( 'name' => 'feeds',
	                       'html' => "<li><a href=\"{$CFG->wwwroot}{$_SESSION['username']}/feeds/\" class=\"selected\" >" .__gettext("Your Resources").'</a></li>',
                               'name' => 'wiki',
                	       'html' => "<li><a href=\"{$CFG->wwwroot}wiki/\" class=\"selected\" >" .__gettext("Wiki").'</a></li>');
    } else {
        $PAGE->menu[] = array( 'name' => 'feeds',
                                'html' => "<li><a href=\"{$CFG->wwwroot}{$_SESSION['username']}/feeds/\" >" .__gettext("Your Resources").'</a></li>',
                                'name' => 'wiki',
				'html' => "<li><a href=\"{$CFG->wwwroot}wiki/\" >" .__gettext("Wiki").'</a></li>');
	        }
	    }


You get the idea: you're telling it to add 'Wiki' up there and not just 'Your
Resources'.  Not the best way to do it, but it works.

As far as adding the toolbar itself, the magic line is:

<script src="/mod/toolbar/js.php"></script>

I don't think it matters 'where' it goes in the file (thanks to CSS) but I put
it on line 96 or so, right before: <div id="globalWrapper">

(That file maybe being wiki/skins/MonoBook.php)

But just putting it there kind of messes stuff up.  You really have to go into
the monobook folder (if or whatever theme you're using) and edit the main.css
file.  I kind of did a quick-and-dirty change.

So, in the out-of-the-box main.css, make these changes:

Line 7:  margin: 1.5em 0 0 12.2em;
Line 14: padding-top: 80px;
Line 23: top: 20pt;
Line 28: height: 80px;
Line 37: height: 80px;
Line 46: top: 25pt;
Line 55: top: 3.0em;

And while you're in there, add these lines to the very end to get rid of the
login/logout links:

li#pt-login
{
	display: none;
}
li#pt-logout
{
	display: none;
}
