<?php

function fbconnect_get_authorize_url($next='') {
	global $CONFIG;
	
	if (!$next) {
		// default to login page
		$next = "{$CONFIG->wwwroot}mod/fbconnect/pages/login.php";
	}
	
	$facebook = fbconnect_client();
	return $facebook->getLoginUrl(array(
		'next' => $next,
		'req_perms' => 'offline_access,email',
	));
}

function fbconnect_login() {
	$fc = fbconnect_client();
	$fbuid = $fc->getUser();
	if ($fbuid) {    
		$entities = get_entities_from_metadata('facebook_uid', $fbuid, 'user', 'facebook');
		$do_login = false;
		$duplicate_acccount = false;
	
		if (!$entities || $entities[0]->active == 'no') {
			if (!$entities) {
				$entities = get_entities_from_metadata('facebook_uid', $fbuid, 'user');
				if (!$entities) {
					// this account does not exist, so create it
					
					// check to make sure that a non-Facebook account with the same user name
					// does not already exist
					$fbprofile = fbconnect_get_info_from_fb($fbuid, 'username');
					$username = $fbprofile['username'];
					// Basic, check length
					if (!isset($CONFIG->minusername)) {
						$CONFIG->minusername = 4;
					}			
					if ((strlen($username) < $CONFIG->minusername) || get_user_by_username($username)) {
						// too short or a duplicate, so try another approach
						$username = 'facebook_'.$fbuid;
					}
					if(get_user_by_username($username)) {
							$duplicate_account = true;			
							register_error(sprintf(elgg_echo("fbconnect:account_duplicate"),$username));
					}
					if (!$duplicate_account) {								    
				        $user = new ElggUser();
						$data = fbconnect_get_info_from_fb($fbuid, 'me');
						if ($data['email']) {
							$user->email = $data['email'];
						} else {
					    	$user->email = '';
						}
					    $user->access_id = ACCESS_PUBLIC;
					    $user->subtype = 'facebook';
					    $user->username = $username;
					    $user->facebook_uid = $fbuid;
					    $user->facebook_controlled_profile = 'yes';
					    			
					    if ($user->save()) {
					    	$new_account = true;
						    $do_login = true;
						    // need to keep track of subtype because getSubtype does not work
						    // for newly created users in Elgg 1.5
						    $subtype = 'facebook';
					    } else {
				    	    register_error(elgg_echo("fbconnect:account_create"));
					    }
					} else {
						
					}
				} else {
					$user = $entities[0];
					
					// account is using a Facebook slave login, check to see if this user has been banned
				
				    if (isset($user->banned) && $user->banned == 'yes') { // this needs to change.
				        register_error(elgg_echo("fbconnect:banned"));
				    } else {
					    $do_login = true;
					    $new_account = false;
					    $subtype = 'elgg';
				    }				
				}
			} else {
				// this is an inactive account
				register_error(elgg_echo("fbconnect:inactive"));
			}
			
		} else {		
			$user = $entities[0];
			// account is active, check to see if this user has been banned
		    if (isset($user->banned) && $user->banned == 'yes') { // this needs to change.
		        register_error(elgg_echo("fbconnect:banned"));
		    } else {
			    $do_login = true;
			    $new_account = false;
			    $subtype = 'facebook';
		    }		    
		}
	
		if ($do_login) {				
			$rememberme = get_input('remember',0);
			if (!empty($rememberme)) {
				login($user,true);
			} else {
				login($user);
			}
			
			if (($subtype == 'facebook') && ($user->facebook_controlled_profile != 'no')) {
				// update from Facebook at each login
				fbconnect_update_profile($user,$new_account);
			}
			
			if ($new_account) {
				$fbprofile = fbconnect_get_info_from_fb($fbuid,'status');
				if ($fbprofile) {
					$message = trim($fbprofile['message']);
					if ($message) {
						thewire_save_post($message, ACCESS_PUBLIC, 0, 'facebook');
					}
				}
			}
		}
	} else {
		register_error(elgg_echo("fbconnect:fail"));
	}
	
	forward();
	
	exit;
	
}

function fbconnect_user_settings_save() {
	gatekeeper();
	 
	$user = page_owner_entity();
	if (!$user) {
		$user = $_SESSION['user'];
	}
	 
	$subtype = $user->getSubtype();
	 
	if ($subtype == 'facebook') {
		 
		$facebook_controlled_profile = get_input('facebook_controlled_profile','yes');
		 
		if ((!$user->facebook_controlled_profile && ($facebook_controlled_profile == 'no'))
		|| ($user->facebook_controlled_profile && ($user->facebook_controlled_profile != $facebook_controlled_profile))
		) {
			$user->facebook_controlled_profile = $facebook_controlled_profile;
			system_message(elgg_echo('fbconnect:user_settings:save:ok'));
		}
	} else if (!$subtype) {

		// users with no subtype (regular Elgg users) are allowed a
		// slave Facebook login
		$facebook_uid = get_input('facebook_uid');
		if ($facebook_uid != $user->facebook_uid) {
			$user->facebook_uid = $facebook_uid;
			system_message(elgg_echo('fbconnect:facebook_login_settings:save:ok'));
		}
	}
}

/**
 * Get the facebook client object for easy access.
 * @return object
 *   Facebook Api object
 */
function fbconnect_client() {
	global $CONFIG;
	static $fb = NULL;
	if (!$fb instanceof Facebook) {
		//include_once($CONFIG->pluginspath.'fbconnect/facebook-platform/facebook.php');
		include_once($CONFIG->pluginspath.'fbconnect/models/facebook.php');
		$fb = new Facebook(array(
			'appId' => get_plugin_setting('api_key', 'fbconnect'),
			'secret' => get_plugin_setting('api_secret', 'fbconnect'),
		));
	}
	return $fb;
}

/**
 * Query information from facebook user table.
 *
 * @return array
 */
function fbconnect_get_info_from_fb($fbuid, $fields)
{
	if (($fc = fbconnect_client()) && $fields) {
		try {
			if ($fields == 'status') {
				$result = $fc->api(
					array(	'method'=>'fql.query',
							'query'=> "SELECT message FROM stream WHERE source_id = $fbuid limit 1"
				));
			} else if ($fields == 'username') {
				$result = $fc->api(
					array(	'method'=>'fql.query',
							'query'=> "SELECT username FROM profile WHERE id = $fbuid"
				));
			} else if ($fields == 'email') {
				$data = $fc->api('/me');
				return $data;
			} else if ($fields == 'me') {
				$data = $fc->api('/me');
				return $data;
			} else {
				$result = $fc->api(
					array(	'method'=>'fql.query',
							'query'=> "SELECT $fields FROM user WHERE uid = $fbuid"
				));
			}
			return $result[0];
			
		} catch (Exception $e) {
			error_log('Exception thrown from Facebook Connect: '. $e->getMessage());
		}
	}
}

function fbconnect_update_profile($user,$add_to_river=TRUE)
{
	$fbuid = $user->facebook_uid;
	$fbprofile = fbconnect_get_info_from_fb($fbuid,'name, pic_big_with_logo, interests, hometown_location, about_me');
	if ($fbprofile) {
		$user->description = $fbprofile['about_me'];
		$user->name = $fbprofile['name'];
		$location = $fbprofile['hometown_location'];
		//error_log("hometown_location:".print_r($location,true));
		// hometown_location is currently a structure with city, state, country and zip keys
		// ignore zip for now
		$location2 = array();
		foreach(array('city','state','country') as $key) {
			// ignore empty values
			if (trim($location[$key])) {
				// take care of case where a comma appears
				$sublocations = explode(",",trim($location[$key]));
				foreach($sublocations as $loc) {
					// don't put the same phrase in more than once
					if (!in_array(trim($loc),$location2)) {
						$location2[] = trim($loc);
					}
				}
			}
		}
		$user->location = $location2;
		$user->interests = explode(',',$fbprofile['interests']);

		$user->facebook_sync_time = time();
		$user->save();
		/*if (is_plugin_enabled('thewire')) {
			$fbstatus = fbconnect_get_info_from_fb($fbuid, 'status');
			thewire_save_post($fbstatus['message'], ACCESS_PUBLIC, 0, 'facebook');
		}*/
		//Add images to profile
		if(!isset($fbprofile['pic_big_with_logo']))
		{
			return TRUE;
		}
		else if(fbconnect_get_image_from_fb($fbprofile['pic_big_with_logo'], $user, $add_to_river))
		{
			return TRUE;
		}
		else
		{
			return FALSE;
		}


	}
}

function fbconnect_setup_directory($dir) {
	if (!file_exists($dir)) {
		return @mkdir($dir, 0700, true); 
	} else {
		return true;
	}
}

function fbconnect_get_image_from_fb($link, $user, $add_to_river=TRUE)
{
	global $CONFIG;

	if(!$user)
	{
		$user = page_owner_entity();
	}
	
	$dir = $CONFIG->dataroot.'fbconnect/';
	
	if (!fbconnect_setup_directory($dir)) {
		return false;
	}

	$file_dir = $dir.'temp.jpg';
	$file = file_get_contents($link);

	$file_w = fopen($file_dir, 'w');
	if($file_w)
	{
		$write_file = fwrite($file_w, $file);
		fclose($file_w);
	}
	else
	{
		echo `touch `.$file_dir;
		$write_file = fwrite($file_w, $file);
		fclose($file_w);
	}
	
	// TODO: look into implementing these
	$profile_iconw = get_plugin_setting('profile_iconw', 'fbconnect');
	$profile_iconh = get_plugin_setting('profile_iconh', 'fbconnect');
	$topbar_iconw = get_plugin_setting('top_bar_iconw', 'fbconnect');
	$topbar_iconh = get_plugin_setting('top_bar_iconh', 'fbconnect');

	if($profile_iconw != false && $profile_iconh != false)
	{
		$large = get_resized_image_from_existing_file($file_dir,$profile_iconw,$profile_iconh);
	}
	else
	{
		$large = get_resized_image_from_existing_file($file_dir,200,200);
	}

	if($topbar_iconw != false && $topbar_iconh != false)
	{
		$topbar = get_resized_image_from_existing_file($file_dir,$topbar_iconw,$topbar_iconh, true);
	}
	else
	{
		$topbar = get_resized_image_from_existing_file($file_dir,16,16, true);
	}

	$tiny = get_resized_image_from_existing_file($file_dir,25,25, true);
	$small = get_resized_image_from_existing_file($file_dir,40,40, true);
	$medium = get_resized_image_from_existing_file($file_dir,100,100, true);

	$master = get_resized_image_from_existing_file($file_dir,550,550);

	if ($small !== false && $medium !== false && $large !== false && $tiny !== false)
	{

		$filehandler = new ElggFile();
		$filehandler->owner_guid = $user->getGUID();
		$filehandler->setFilename("profile/" . $user->username . "large.jpg");
		$filehandler->open("write");
		$filehandler->write($large);
		$filehandler->close();
		$filehandler->setFilename("profile/" . $user->username . "medium.jpg");
		$filehandler->open("write");
		$filehandler->write($medium);
		$filehandler->close();
		$filehandler->setFilename("profile/" . $user->username . "small.jpg");
		$filehandler->open("write");
		$filehandler->write($small);
		$filehandler->close();
		$filehandler->setFilename("profile/" . $user->username . "tiny.jpg");
		$filehandler->open("write");
		$filehandler->write($tiny);
		$filehandler->close();
		$filehandler->setFilename("profile/" . $user->username . "topbar.jpg");
		$filehandler->open("write");
		$filehandler->write($topbar);
		$filehandler->close();
		$filehandler->setFilename("profile/" . $user->username . "master.jpg");
		$filehandler->open("write");
		$filehandler->write($master);
		$filehandler->close();
			
		$user->icontime = time();
			
		trigger_elgg_event('profileiconupdate',$user->type,$user);
		
		if ($add_to_river) {			
			add_to_river('river/user/default/profileiconupdate','update',$user->guid,$user->guid);
		}
		return true;
	}
	else
	{
		system_message(elgg_echo("profile:icon:notfound"));
		return false;
	}
}