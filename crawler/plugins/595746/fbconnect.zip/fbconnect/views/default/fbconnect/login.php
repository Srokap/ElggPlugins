<?php
$facebook_link = fbconnect_get_authorize_url();

$login = <<< END
<div id="facebook_connect">
	<a href="$facebook_link">
		<img src="{$vars['url']}mod/fbconnect/graphics/login-button.png" />
	</a>
</div>
END;

echo $login;
