<?php

include_once(dirname(dirname(__FILE__))) . "/configurable_profile/code/lib.php";

function configurable_profile_init()
{
    global $CONFIG;

    // registering plugin hook to setup profile fields set
    register_plugin_hook('profile:fields',                  'profile', 'configurable_profile_fields_init');
    // registering plugin hook to setip profile fields options values
    register_plugin_hook('profile:fields:options',          'profile', 'configurable_profile_fields_options_init');
    // registering plugin hook to setup default profile fields access level
    register_plugin_hook('profile:fields:access:default',   'profile', 'configurable_profile_fields_access_default_init');
    // registering plugin hook to setup profile fields user can select own access level
    register_plugin_hook('profile:fields:access:user',      'profile', 'configurable_profile_fields_access_user_init');
    // registering plugin hook to setup fields groups
    register_plugin_hook('profile:fields:groups',           'profile', 'configurable_profile_fields_groups_init');
    // registering plugin hook to setup visible fields set based on profile fields values
    register_plugin_hook('profile:fields:filter',           'profile', 'configurable_profile_fields_filter_init');
        
    extend_view('css', 'configurable_profile/css');
}



function configurable_profile_fields_init($hook, $entity_type, $return_value, $params)
{
    return $return_value;
}


function configurable_profile_fields_options_init($hook, $entity_type, $return_value, $params)
{
    return $return_value;
}

function configurable_profile_fields_access_default_init($hook, $entity_type, $return_value, $params)
{
    return $return_value;
}

function configurable_profile_fields_access_user_init($hook, $entity_type, $return_value, $params)
{
    return $return_value;
}

function configurable_profile_fields_groups_init($hook, $entity_type, $return_value, $params)
{
    global $CONFIG;
    // define all standart fields into group
    $return_value = array(
        ''          => array_keys($CONFIG->profile),
    );
    return $return_value;
}

function configurable_profile_fields_filter_init($hook, $entity_type, $return_value, $params)
{
    return $return_value;
}



function configurable_profile_fields_setup()
{
    global $CONFIG;
 
    // storing profile fields set
    $CONFIG->profile = trigger_plugin_hook('profile:fields', 'profile', NULL, (is_array($CONFIG->profile) ? $CONFIG->profile : array()) ); 
    // storing profile radio options values
    $CONFIG->profile_options = trigger_plugin_hook('profile:fields:options', 'profile', NULL, (is_array($CONFIG->profile_options) ? $CONFIG->profile_options : array()));
    // storing profile fields default access level
    $CONFIG->profile_predefined_access_level = trigger_plugin_hook('profile:fields:access:default', 'profile', NULL, (is_array($CONFIG->profile_predefined_access_level) ? $CONFIG->profile_predefined_access_level : array()) );
    // storing fields list for choose access level by user
    $CONFIG->profile_choose_access_by_user = trigger_plugin_hook('profile:fields:access:user', 'profile', NULL, (is_array($CONFIG->profile_choose_access_by_user) ? $CONFIG->profile_choose_access_by_user : array()));
    // storing filds groups for accordion or other tabbed view
    $CONFIG->profile_fields_groups = trigger_plugin_hook('profile:fields:groups', 'profile', NULL, (is_array($CONFIG->profile_fields_groups) ? $CONFIG->profile_fields_groups : array()));
    // ctoring profile fields filter by metadata value, for ability to have different profiles for different user type
    $CONFIG->profile_fields_filter_by_metadata = trigger_plugin_hook('profile:fields:filter', 'profile', NULL, (is_array($CONFIG->profile_fields_filter_by_metadata) ? $CONFIG->profile_fields_filter_by_metadata : array()) );
    
}



//register_plugin_hook('profile:fields', 'profile', 'pgb_profile_fields_init');

register_elgg_event_handler('init','system','configurable_profile_init',2);
register_elgg_event_handler('init','system','configurable_profile_fields_setup', 100000 ); // Ensure this runs after other plugins and after the profile plugin

register_action("profile/edit", false, $CONFIG->pluginspath . "configurable_profile/actions/edit.php");

?>