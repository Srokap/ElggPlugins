<?php


function configurable_profile_get_avaliable_fields($entity)
{
    global $CONFIG;
    $fields = array();
    if ( is_array($CONFIG->profile_fields_filter_by_metadata) && count($CONFIG->profile_fields_filter_by_metadata) )
    {
        foreach ( $CONFIG->profile_fields_filter_by_metadata as $meta_name => $meta_restriction)
        {
            $meta_value = $entity->$meta_name;
            $meta_fields = $meta_restriction[$meta_value];
            $fields = array_unique(array_merge($fields, $meta_fields));
        }
    } 
    else 
    {
        $fields = array_keys($CONFIG->profile);
    }
    
    return $fields;
}

function configurable_profile_get_field_access($field, $default_access = ACCESS_DEFAULT)
{
    global $CONFIG;
    if ( is_array($CONFIG->profile_predefined_access_level) )
    {
        if ( isset($CONFIG->profile_predefined_access_level[$field]) )
            return $CONFIG->profile_predefined_access_level[$field];
    }
    return $default_access;
}

function configurable_profile_get_choose_access_by_user($field, $default_access = true)
{
    global $CONFIG;
    if ( is_array($CONFIG->profile_choose_access_by_user) )
    {
        if ( count($CONFIG->profile_choose_access_by_user) )
            return in_array($field, $CONFIG->profile_choose_access_by_user);
    }    
    return $default_access;
}

function configurable_profile_get_field_options($field)
{
    global $CONFIG;
    if ( is_array($CONFIG->profile_options) )
    {
        if ( isset($CONFIG->profile_options[$field]) )
            return $CONFIG->profile_options[$field];
    }
    return array();
}

function configurable_profile_get_fields_groups($entity)
{
    global $CONFIG;
    $result = array();
    if ( is_array($CONFIG->profile_fields_groups) )
    {
        $available_fields = configurable_profile_get_avaliable_fields($entity);
        foreach ($CONFIG->profile_fields_groups as $group_name => $group_fields )
        {
            $result[$group_name] = array_values(array_intersect($group_fields, $available_fields));
        }
    }
    return $result; 
}

?>