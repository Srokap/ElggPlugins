<?php

    $fields = $vars['display_fields'];
    $fields_groups = $vars['groups'];
    if ( !is_array($fields_groups) || count($fields_groups) == 0 )
        $fields_groups = array ( '' => array_keys($fields) ); 


    foreach ( $fields_groups as $group_name => $group_fields )
    {
        if ( count($group_fields) == 0 ) continue;
?>
		<div class="profile_group_title">
            <?php echo $group_name; ?>
        </div>
        <div class="profile_group_body">
<?php
        foreach ( $group_fields as $field_name )
        {
            if ( !isset($fields[$field_name]) ) continue;
?>
	<p>
		<label>
			<?php echo $fields[$field_name]['title']; ?><br />
			<?php echo $fields[$field_name]['display']; ?>
		</label>
			<?php echo $fields[$field_name]['access']; ?>
	</p>

<?php            
        }
?>
        </div>
<?php
    }

?>
