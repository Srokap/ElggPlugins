<?php

	/**
	 * Elgg profile edit form
	 * 
	 * @package ElggProfile
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 * 
	 * @uses $vars['entity'] The user entity
	 * @uses $vars['profile'] Profile items from $CONFIG->profile, defined in profile/start.php for now 
	 */

?>
<div class="contentWrapper">
<form action="<?php echo $vars['url']; ?>action/profile/edit" method="post">
<?php echo elgg_view('input/securitytoken') ?>
<?php

	//var_export($vars['profile']);
	if (is_array($vars['config']->profile) && sizeof($vars['config']->profile) > 0)
    {
        $available_fields = configurable_profile_get_avaliable_fields($vars['entity']);
        $display_fields = array();
		foreach($vars['config']->profile as $shortname => $valtype) {
		      
            // check is fields available for user, this related to field filters by user account type
            if ( is_array($available_fields) && count($available_fields) && !in_array($shortname, $available_fields) )
                    continue;
          
			if ($metadata = get_metadata_byname($vars['entity']->guid, $shortname)) {
				if (is_array($metadata)) {
					$value = '';
					foreach($metadata as $md) {
						if (!empty($value)) $value .= ', ';
						$value .= $md->value;
						$access_id = $md->access_id;
					}
				} else {
					$value = $metadata->value;
					$access_id = $metadata->access_id;
				}
			} else {
				$value = '';
				$access_id = configurable_profile_get_field_access($shortname, ACCESS_DEFAULT);
			}
            $access_visibility = configurable_profile_get_choose_access_by_user($shortname, false);
            $field = array (
                'title'     => elgg_echo("profile:{$shortname}"),
                'display'   => elgg_view("input/{$valtype}",array(
															'internalname' => $shortname,
															'value' => $value,
                                                            'options' => configurable_profile_get_field_options($shortname)
															)),
                'access'    => elgg_view('input/' . ($access_visibility ? 'access' :'hidden'), array('internalname' => 'accesslevel['.$shortname.']', 'value' => $access_id)),
            );
            $display_fields[$shortname] = $field;
        }
        echo elgg_view('profile/show_fields_edit', array('display_fields' => $display_fields, 'groups' => configurable_profile_get_fields_groups($vars['entity'])));
    }

?>

	<p>
		<input type="hidden" name="username" value="<?php echo page_owner_entity()->username; ?>" />
		<input type="submit" class="submit_button" value="<?php echo elgg_echo("save"); ?>" />
	</p>

</form>
</div>