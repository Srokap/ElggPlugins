<?php
				//This function controls the alternating class
                $even_odd = ( 'odd' != $even_odd ) ? 'odd' : 'even';					
    $fields = $vars['display_fields'];
    $fields_groups = $vars['groups'];
    if ( !is_array($fields_groups) || count($fields_groups) == 0 )
        $fields_groups = array ( '' => array_keys($fields) ); 
        	
    foreach ( $fields_groups as $group_name => $group_fields )
    {
        if ( count($group_fields) == 0 ) continue;
?>
		<div class="profile_group_title_display">
            <?php echo $group_name; ?>
        </div>
        <div class="profile_group_body_display">
<?php
        $even_odd = null;
        foreach ( $group_fields as $field_name )
        {
            if ( !isset($fields[$field_name]) ) continue;
            //This function controls the alternating class
            $even_odd = ( 'odd' != $even_odd ) ? 'odd' : 'even';
?>
	<p class="<?php echo $even_odd; ?>">
		<b><?php echo $fields[$field_name]['title']; ?>:</b>
		<?php echo $fields[$field_name]['display']; ?>
	</p>

<?php            
        }
?>
        </div>
<?php
    }

?>