<?php

?>
.profile_group_title, .profile_group_title_display
{
 	font-weight: bold;
	background-color: #DEDEDE;    
    padding: 5px;
}

.profile_group_body, .profile_group_body_display
{
    border: 1px solid #DEDEDE;
}

.profile_group_title_display
{
    background-color: #AEAEAE;    
}

.profile_group_title, .profile_group_body, .profile_group_title_display, .profile_group_body_display 
{
    -moz-background-clip:border;
    -moz-background-inline-policy:continuous;
    -moz-background-origin:padding;
    -moz-border-radius-bottomleft:8px;
    -moz-border-radius-bottomright:8px;
    -moz-border-radius-topleft:8px;
    -moz-border-radius-topright:8px;
}
