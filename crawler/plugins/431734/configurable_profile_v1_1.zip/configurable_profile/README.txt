/**

    README.txt, part of configurable_profile
    Copyright (C) 2010, Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
        
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
                
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
                        
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.

    Elgg version: 1.6.1
    Title: Configurable profile
    Intro: Configarable profile is profile engine replacement and extention.
    Description:   Configurable profile provide ability to setup flexible profile fields 
    configuration such as define filds set, options values, default access levels, allowed 
    for user access setup fields, fields groups and fields filter regards values for any field. 
    Also this plugin redefine user profile rendering to allow simple customization for fields displaying.
    Example for profile configuration is showed in configurable_profile_conf_example plugin.
    Example for profile display customization is showed in configurable_profile_accordion plugin.
    
    Plugin is developed by Web100 Net Technology Center, Ltd. http://web100.com.ua under the assignment of Lorinthe,BV.
    Dependencies: No
    Version: 1.1
    Licence: GPL v.2

                                
 */



*Activating the configurable_profile plugin*

Simply extract the plugin into the mod directory and
activate it as usual using the Elgg 1.x tool administration.


*Plugin settings*

Plugin registering series of plugin hooks to provide ability for 
configurations and customizations inside other plugins.
See configurable_profile_conf_example plugin for profile fields configuration example.
See configurable_profile_accordion plugin for fields displaying customization.

