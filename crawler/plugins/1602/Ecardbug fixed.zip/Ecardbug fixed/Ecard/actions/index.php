<HTML><HEAD><TITLE>E Greetings</TITLE>
<META content="text/html; charset=windows-1252" http-equiv=Content-Type>
<STYLE type=text/css>A:link {
COLOR: #6666ff; FONT-SIZE: 13px; FONT-WEIGHT: normal; TEXT-DECORATION: none
}
A:visited {
	COLOR: #005177; FONT-SIZE: 13px; FONT-WEIGHT: normal; TEXT-DECORATION: none
}
A:hover {
	COLOR: #cc3333; FONT-SIZE: 13px; TEXT-DECORATION: none
}
BODY {
	FONT-FAMILY: Verdana, Helvetica, Arial; FONT-SIZE: 12px; MARGIN-LEFT: 0px; MARGIN-RIGHT: 0px; MARGIN-TOP: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; PADDING-TOP: 0px; scrollbar-face-color: #AFC6DB; scrollbar-shadow-color: #000000; scrollbar-highlight-color: #DEE7EF; scrollbar-3dlight-color: #FFFFFF; scrollbar-darkshadow-color: #AFC6DB; scrollbar-track-color: #F5F5F5; scrollbar-arrow-color: ##DEE7EF
}
text {
	FONT-FAMILY: Verdana, Helvetica, Arial; FONT-SIZE: 10px
}
TD {
	COLOR: #000000; FONT-FAMILY: Verdana, Helvetica, Arial; FONT-SIZE: 11px
}
TEXTAREA         {font-family:verdana,helvetica,sans-serif;font-size:10pt;BACKGROUND-COLOR:#ffffff;color:#000000;} 
INPUT {
	BACKGROUND-COLOR: #f5f5f5; COLOR: #000000; FONT-FAMILY: Verdana, Helvetica, Arial; FONT-SIZE: 9pt
}
SELECT {
	BACKGROUND-COLOR: #f5f5f5; COLOR: #000000; FONT-FAMILY: Verdana, Helvetica, Arial; FONT-SIZE: 9pt
}
HR{ color:#afc6db;
	}
.copyright {
	FONT-FAMILY: Helvetica, Thoma,Verdana; FONT-SIZE: 20px
}
.windowbg {
	BACKGROUND-COLOR: #6633ff; COLOR: #000000; FONT-FAMILY: Verdana; FONT-SIZE: 11px
}
.windowbg2 {
	BACKGROUND-COLOR: #f8f8f8; COLOR: #000000; FONT-FAMILY: Verdana; FONT-SIZE: 11px
}
.bordercolor {
	BACKGROUND-COLOR: #AFC6DB
}
.yhmpabd{border-left:solid #AFC6DB 1px;border-right:solid #AFC6DB 1px;border-bottom:solid #AFC6DB 1px;}
.yhmnwbd{border-left:solid #AFC6DB 1px;border-right:solid #AFC6DB 1px;}
.yhmnwbm{border-left:solid #AFC6DB 1px;border-right:solid #AFC6DB 1px;border-bottom:solid #AFC6DB 1px;}


</STYLE>
<META content="MSHTML 5.00.2614.3500" name=GENERATOR></HEAD>
<BODY bgColor=#f5f5f5 link=#0033ff text=#000000 marginwidth=5 ><BR>
<TABLE align=center border=0 cellPadding=1 cellSpacing=0 class=bordercolor 
width="92%">
<TBODY>
<TR>
<TD class=bordercolor width="100%">
<TABLE bgColor=#ffffff cellPadding=0 cellSpacing=0 width="100%">
<TBODY>
<TR>
<TD>
<TABLE bgColor=#ffffff border=0 cellPadding=0 cellSpacing=8 
 width="100%">
<TBODY>
<TR><td></td></tr><tr><td align=right><form method=post action="?action=browse">Jump to Category:<select name='category'><option value='Birthdays'>Birthdays<option value='Events and Milestones'>Events and Milestones<option value='Love and Romance'>Love and Romance<option value='Forgiveness'>Forgiveness<option value='Holiday and Seasons'>Holiday and Seasons<option value='Friendship'>Friendship<option value='For Any Occasion'>For Any Occasion<option value='Invitations'>Invitations</select><input type=submit value=go><hr></form></td></tr>
<TD align=middle><?php
include "main.php";
?><HTML>
<body topmargin="50" leftmargin="50">
<td><img src="clear.gif" width=1 height=330>	
</TD><FONT class=titlebg>
 </FONT></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD></TR>
  <TR>
    <TD align=middle class=bordercolor>
      <TABLE align=center bgColor=#afc6db cellPadding=0 cellSpacing=0 
      width="100%">
        <TBODY>
        <TR>
          <TD align=middle width="100%">
            <TABLE align=center bgColor=#afc6db border=0 cellPadding=3 
            cellSpacing=0 width="100%">
              <TBODY>
              <TR></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD></TR>
  <TR>
    <TD align=middle class=bordercolor>
      <TABLE align=center bgColor=#ffffff cellPadding=0 cellSpacing=0 
      width="100%">
        <TBODY>
        <TR>
          <TD align=middle width="100%">
            <TABLE align=center bgColor=#ffffff border=0 cellPadding=5 
            cellSpacing=0 width="100%">
              <TBODY>
              <TR>
                    <TD align=middle bgColor=#ffffff vAlign=center><FONT 
                  color=#00000
        size=2 class=code>&nbsp;</TD>
                  </TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE><BR>
<CENTER><TR></TR></TBODY></TABLE>
Powered by <a href="http://www.webgalli.com" target="new">Webgalli</a><BR>
</BODY></HTML>