<LINK
href="st.css" rel=stylesheet
type=text/css>
<head><script language="JavaScript">
<!--
function emo(emo){
document.all.message.value += emo;
document.all.message.focus();
return;
}
//-->
</script></head>
<?php
extract($HTTP_GET_VARS);
extract($HTTP_POST_VARS);
//==========================================================================================
// Copyright Scriptsez.net
//==========================================================================================
//MAKE NECESSARY CHANGES BELOW

 $listings_per_page = "8"; //Number of listings per page

//END OF CONFIGURATION
//==========================================================================================
$io=  "expire.txt";
$fd = fopen ($io, "r"); 
$expire = fread ($fd, filesize ($io)); 
fclose ($fd);
$mo=  "pwd.txt";
$bd = fopen ($mo, "r"); 
$psord = fread ($bd, filesize ($mo)); 
fclose ($bd);
$rop=base64_decode($psord);
$vup=explode("||&@23||password>||&~||",$rop);
$password=base64_decode($vup[0]);
if ($action == "admin" ){
?><center><table align=middle><td align=left width=20%>
<tr><td height="27" colspan="2"><FONT SIZE="4" COLOR="#000000">:: E Greetings ::</FONT></td><tr><td>Password Required (Default is: administrator)</td></tr><tr><form method=post action="?action=login"><td>Password:</td><td><input type=password name=pass>&nbsp;<input type=submit value=Submit></td></tr></form></table></center>
<?php
}
if ($action=="login"){
if(strlen($m)>="1"){
$n=base64_decode($m);
$pass=$n;
}
if ($pass==$password){
echo "Successfully Loged In<br><hr>";
$m=base64_encode($password);
echo"<table align=left width=80%><tr><td><A HREF=?action=add_gre&m=$m>Add Greeting	Card</A></td></tr><tr><td><A HREF=?action=edit_gre&m=$m>Edit Greeting Card</A></td></tr><tr><td><A HREF=?action=add_event&m=$m>Add Upcomming Event</A></td></tr><tr><td><A HREF=?action=edit_event&m=$m>Edit Upcomming Events</A></td></tr><tr><td><A HREF=?action=change_expiry&m=$m>Change Message expiry date</A></td></tr><tr><td><A HREF=?action=change_password&m=$m>Change Password</A></td></tr><tr><td><A HREF=?action=admin>Logout</A></td></tr></table>";
}else {
echo "Invalid Passsword";
}
}
if ($action=="change_expiry"){
$l=base64_decode($m);
if ($l==$password){
$ho=  "expire.txt";
$fj = fopen ($ho, "r"); 
$exp = fread ($fj, filesize ($ho)); 
fclose ($fj);
echo "<form method=post action=?action=do_change_expiry>Message will expire after <input type=text size=8 name=p value=$exp> Days<br><input type=hidden name=m value=$m><input type=\"reset\" value=\"Reset\">&nbsp;<input type=submit value=Change></form><BR><a href=?action=login&m=$m>Back To main Menu</a>";
}else{
echo "Please Login Again";
}}
if ($action=="do_change_expiry"){
$l=base64_decode($m);
if ($l==$password){
$vd = fopen ($io, "w");
fwrite ($vd, "$p");
fclose($vd);
echo "Message Expiry date has been successfully changed. <BR><a href=?action=login&m=$m>Back To main Menu</a>";
}else{
echo "Please Login Again";
}
}
if ($action=="add_event"){
$l=base64_decode($m);
if ($l==$password){
$ho=  "expire.txt";
$fj = fopen ($ho, "r"); 
$exp = fread ($fj, filesize ($ho)); 
fclose ($fj);
echo "<form method=post action=?action=do_add_event><table><tr><td></td><td>Name of event:</td><td><input type=text size=18 name='p'></td><td>Category:</td><td><input type=text size=18 name=c></td></tr><tr><td>Notify From:</td><td>Month</td><td><input type=text name=nmonth size=4 maxlength=2></td><td>Day</td><td><input type=text name=nday size=4 maxlength=2></td><tr><td>Notify upto:</td><td>Month</td><td><input type=text name=emonth size=4 maxlength=2></td><td>Day</td><td><input type=text name=eday size=4 maxlength=2></td>";
echo"</tr><td></td><td><input type=hidden name=m value=$m><input type=submit value='Add Event'><BR><BR><BR></td></form><tr><td><a href=?action=login&m=$m>Back To main Menu</a></td></tr></table>";
}else{
echo "Please Login Again";
}
}
if ($action=="do_add_event"){
$p = stripslashes ($p);
$c = stripslashes ($c);
$l=base64_decode($m);
if ($l==$password){
$fmi=fopen("events.txt","a+");
fwrite($fmi,$p);
fwrite($fmi,";");
fwrite($fmi,$c);
fwrite($fmi,";");
fwrite($fmi,$nmonth);
fwrite($fmi,";");
fwrite($fmi,$nday);
fwrite($fmi,";");
fwrite($fmi,$emonth);
fwrite($fmi,";");
fwrite($fmi,$eday);
fwrite($fmi,";");
fwrite($fmi,"\n");
fclose($fmi);
echo"<table><td>Event $p Added Successfully</td><tr><td><a href=?action=login&m=$m>Back To main Menu</a></td></tr></table>";
}else{
echo "Please Login Again";
}
}
if($action == "edit_event") {
$l=base64_decode($m);
if($l==$password){
$filename="events.txt";
$fp = @fopen($filename, 'r');
if ($filename) {
$array = explode("\n", fread($fp, filesize($filename)));
$listed = count($array)-1;
?>
<table border="0" cellpadding="2" cellspacing="0" width="100%">
<tr>
<td width="99%"><font size="3">Edit Events</font></td>
</tr>
<td><A HREF="?action=login&m=<?php echo "$m"; ?>">Back</A></td></table><table width=90%>
<br>
<?php
echo "Click on event to edit :: Viewing all ($listed)<P><P>";

				for($x=0;$x<$listed;$x++) {
					$temp = explode(";",$array[$x]);

				echo "<tr><td align=left><li><A HREF=\"?action=change_event&id=$x&m=$m\">$temp[0]</A></td></tr>";

			}
		}
		echo "</table>";
}else{
echo "Please Login";
}
}
if($_GET['action'] == "change_event") {
$l=base64_decode($m);
if($l==$password){
		if($_GET['id'] >= 0){
$filename="events.txt";
				$id = $_GET['id'];
				$fp = @fopen($filename, 'r');
				$array = explode("\n", fread($fp, filesize($filename)));
				for($x=0;$x<sizeof($array);$x++) {
					$temp = explode(";",$array[$x]);
					$line[$x] = "$temp[0];$temp[1];$temp[2];$temp[3];$temp[4];$temp[5];";
				}
				$data_submitted = time();
				$mod = explode(";", $line[$id]);
				echo "Update event: $mod[0]";
echo "<form method=\"POST\" action=\"?action=change_event2\" method=\"post\">";
echo "<table><tr><td></td><td>Name of event:</td><td><input type=text size=18 name=p value='$mod[0]'></td><td>Category:</td><td><input type=text size=18 name=c value='$mod[1]'></td></tr><tr><td>Notify From:</td><td>Month</td><td><input type=text name=nmonth size=4 maxlength=2 value='$mod[2]'></td><td>Day</td><td><input type=text name=nday size=4 maxlength=2 value='$mod[3]'></td><tr><td>Notify upto:</td><td>Month</td><td><input type=text name=emonth size=4 maxlength=2 value='$mod[4]'></td><td>Day</td><td><input type=text name=eday size=4 maxlength=2 value='$mod[5]'></td>";
echo"</tr><td></td>";
echo "<tr><td></td><input type=\"hidden\" name=m value=\"$m\"><td><input type=\"submit\" value=\"submit\">&nbsp;";
echo "<input type=\"reset\" value=\"Reset\"></td></tr>";
echo "<input type=\"hidden\" name=\"id\" value=\"$id\">";
echo "</form></table>";
}
else{
print "Error!! Unable to determine ID";
}
}else{
	echo "Please Login Again";
}
}
else if($_GET['action'] == "change_event2") {
$p = stripslashes ($p);
$l=base64_decode($m);
if($l==$password){
$filename="events.txt";
$fp = @fopen($filename, 'r');
$array = explode("\n", fread($fp, filesize($filename)));
for($x=0;$x<sizeof($array)-1;$x++) {
$temp = explode(";",$array[$x]);
$line[$x] = "$temp[0];$temp[1];$temp[2];$temp[3];$temp[4];$temp[5];";
}
				$line[$id]= "$p;$c;$nmonth;$nday;$emonth;$eday;";
				sort($line);
				$fp = fopen ("events.txt", "w");
				fwrite ($fp, $line[0]);
				for($i=0; $i<sizeof($line);$i++){
				fwrite ($fp, $line[$i]);
				fwrite ($fp, "\n");
				}
				fclose ($fp);
				print "<p><p>Edited successfully<br><br><A HREF=?action=edit_event&m=$m>Back to edit list</A><BR><A HREF=?action=login&m=$m>Main Page</A><BR>";
}else{
	echo "Please Login Again";
}
}
if ($action=="change_password"){
$l=base64_decode($m);
if ($l==$password){
echo "<table><form method=post action=?action=do_change_password><td width=30%>Enter new password</td><td width=70%><input type=password size=18 name=pwd></td><tr><td>Confirm new password</td><td><input type=password size=18 name=qwd></td><tr><td></td><td><input type=hidden name=m value=$m>&nbsp;<input type=submit value=Change></form></td><tr><td></td><td><a href=?action=login&m=$m>Back To main Menu</a></td></table>";
}else{
echo "Please Login Again";
}}
if ($action=="do_change_password"){
$l=base64_decode($m);
if ($l==$password){
if($pwd==$qwd){
$po="pwd.txt";
$fgh=base64_encode($pwd);
$asd=base64_encode($fgh."||&@23||password>||&~||");
$vp = fopen ($po, "w");
fwrite ($vp, "$asd");
fclose($vp);
echo "Password has been successfully changed. <BR><a href=?action=admin>Login using new password</a>";
}else{
echo "Please go back, change password and confirm new password donot match";
}
}else{
echo "Please Login Again";
}
}
$message = str_replace ("\n","<br>", $message);
$message = str_replace (":)","<img src=smile/smile.gif>", $message);
$message = str_replace (":(","<img src=smile/sad.gif>", $message);
$message = str_replace (":P","<img src=smile/tongue.gif>", $message);
$message = str_replace (":o","<img src=smile/scared.gif>", $message);
$message = str_replace (":C","<img src=smile/mad.gif>", $message);
$message = str_replace (";)","<img src=smile/rolleyes.gif>", $message);
$message = str_replace (";Y","<img src=smile/thumbsup.gif>", $message);
$message = str_replace (":D","<img src=smile/laugh.gif>", $message);
$message = str_replace (":s","<img src=smile/shocking.gif>", $message);
$message = str_replace (":r","<img src=smile/naughty.gif>", $message);
$message = str_replace (":/","<img src=smile/sweatdrop.gif>", $message);
$message = str_replace (":O)","<img src=smile/clown.gif>", $message);
$message = str_replace (":H)","<img src=smile/heart.gif>", $message);
$message = str_replace (":i)","<img src=smile/info.gif>", $message);
$message = str_replace (":Q)","<img src=smile/question.gif>", $message);
$message = str_replace ("|~~|","|~|", $message);
$message = stripslashes ($message);
$date = date("D M:d:Y");
if ($action == "sendmail"){
$today=time();
$mfile=$today.".dat";
$n_compteur=fopen("dt/$mfile", "w");
fputs ($n_compteur, "$name|~|");
fputs ($n_compteur, "$from");
fputs ($n_compteur, "|~|");
fputs ($n_compteur, "$mess");
fputs ($n_compteur, "|~|");
fputs ($n_compteur, "$bg");
fputs ($n_compteur, "|~|");
fputs ($n_compteur, "$pic");
fputs ($n_compteur, "|~|");
fputs ($n_compteur, "$mus");
fputs ($n_compteur, "|~|");
fputs ($n_compteur, "$rname");
fputs ($n_compteur, "|~|$date|~|");
fputs ($n_compteur, "$effect");
fputs ($n_compteur, "|~|");
fputs ($n_compteur, "\n");
fclose($n_compteur);
$link="http://cmccochin.org/demo/mod/Ecard/actions/index.php?action=view&id=$today";
$im="Hello $rname\n $name has send you an E Greeting\n Click on the link below to see the greeting.\n $link\n\n If this link is not working paste it in the address bar of your browser \n\n PLEASE NOTE THAT THIS GREETING WILL EXPIRE AFTER $expire DAYS.\n==========================================================\n Powered By Webgalli (http://www.webgalli.com)";
$mess = "From: $name\n $im\n";
$mailheaders="Return-path: $name <$from>\n";
$mailheaders.="From: $name <$from>\n";
$mailheaders.="Reply-To: $from\n";
$sent=mail(trim($to), $subject, $mess, $mailheaders);
if($sent){echo"<FONT SIZE=2 face=arial>Your Ecard has been sent to <B>$to</B></FONT>";}else{echo"<h3>Ecard Could Not Be Sent! Please check you have provided correct email address<BR>You can send ecard to one email at a time.</h3>";}
}
$filename = "file.txt";
$ecard_path = str_replace ("\n","<br>", $ecard_path);
$ecard_path = str_replace (";", ",", $ecard_path);
$ecard_path = stripslashes ($ecard_path);
$thumbnail = str_replace ("<",",", $thumbnail);
$thumbnail = str_replace (";",",", $thumbnail);
$category = str_replace (";", ",", $category);
$cat = str_replace (";", ",", $cat);
$cat = stripslashes ($cat);
$thumbnail = stripslashes ($thumbnail);
$category = stripslashes ($category);
$copyright = "www.webgalli.com";
if($action == "detail" && "cat" && "id"){
$user = file("file.txt");
if(strlen($id) <= 0){
	premain();
	print "<p><BR><BR><BR><b>Your category must be arleast one character</b><br><BR><BR><BR>";
}else{
	for($x=0;$x<sizeof($user);$x++) {
		$temp = explode(";",$user[$x]);
		$opp[$x] = "$temp[0];$temp[1];$temp[2];$temp[3];$temp[4];$temp[5];$temp[6];";
			$meta = $id;
			$meta2 = $temp[5];
			$such = stristr($meta2,$meta);
			if($such) {
				$list[0] = $opp[$x];
				$list;
			}

$temp = explode(";",$user[$x]);
}
if(sizeof($list) != "0") {
for($y=0;$y<sizeof($list);$y++) {
$temp = explode(";",$list[$y]);
premain();
$image_info = getimagesize("$temp[2]");
$v=basename("$temp[2]");
$w=explode(".",$v);
if (strlen($temp[3])>3){
$bgmusic="Background Music: <select name=music><option value=1>On<option value=0>Off</select>";
$player="<embed src='$temp[3]' width=0 height=0></embed>";
}else{
$bgmusic="";
$player="";
}
if ($w[1]=="swf"){
	$image="<embed src='$temp[2]' height='$image_info[1]' width='$image_info[0]'></embed>";
}
elseif($w[1]!="swf"){
$image="<img src='$temp[2]' height='$image_info[1]' width='$image_info[0]'>";
}
echo "<table align=center><td width=70% align=middle><font face=arial size=2><b>Personalize Your Greeting Card<BR>$image</b></table>";
?>
<body bgcolor=#f5f5f5>
<?php
function smiles(){
?>
<a href="javascript:emo(' :) ')"><img src="smile/smile.gif" border=0 alt=":)"></a>
    <a href="javascript:emo(' :( ')"><img src="smile/sad.gif" border=0 alt=":("></a>
    <a href="javascript:emo(' :P ')"><img src="smile/tongue.gif" border=0 alt=":P"></a>
    <a href="javascript:emo(' :o ')"><img src="smile/scared.gif"  border=0 alt=":o"></a>
    <a href="javascript:emo(' :C ')"><img src="smile/mad.gif" border=0 alt=":C"></a>
    <a href="javascript:emo(' ;Y ')"><img src="smile/thumbsup.gif" border=0 alt=";Y"></a>
	<a href="javascript:emo(' :O) ')"><img src="smile/clown.gif"border=0 alt=":0"></a>
    <a href="javascript:emo(' :D ')"><img src="smile/laugh.gif" border=0 alt=":D"></a>
    <a href="javascript:emo(' :/ ')"><img src="smile/sweatdrop.gif" border=0 alt=":/"></a>
    <a href="javascript:emo(' :s ')"><img src="smile/shocking.gif" border=0 alt=":s"></a>
    <a href="javascript:emo(' :r ')"><img src="smile/naughty.gif" border=0 alt=":r"></a>
    <a href="javascript:emo(' ;) ')"><img src="smile/rolleyes.gif"border=0 alt=";)"></a>
    <a href="javascript:emo(' :H) ')"><img src="smile/heart.gif"border=0 alt=":H)"></a>
    <a href="javascript:emo(' :i) ')"><img src="smile/info.gif"border=0 alt=":i)"></a>
    <a href="javascript:emo(' :Q) ')"><img src="smile/question.gif"border=0 alt=":Q)"></a>
	<?php
}
	?>

<form name=mail method=post action="?action=preview">
<table>
      <td>Your Name:</td>
      <td>
        <input type=hidden name=id value=<?php echo $id; ?>>
        <input type=hidden name=cat value=<?php echo $category; ?>>
        <input type=text name=name size=28>
      </td>
      <td>Your Email:</td>
      <td>
        <input type=text name=email size=28>
      </td>
    </tr>
      <tr>
      <td width=59>Recipient Name:</td>
      <td width=187>
        <input type=text name=rname value="" size=28>
      </td>
	  <td width=59>Recipient Email:</td>
      <td width=187>
        <input type=text name=recipient value="" size=28>
      </td>
    </tr><tr><td></td><td><?php echo"</table><table><tr align=center><td>$bgmusic&nbsp; Emotions:"; smiles(); ?></td><td>
        </td></tr><tr></table><table>
        <td width=59>Message:</td>
      <td width=187>
        <textarea name=message wrap=VIRTUAL cols=75 rows=15></textarea>
      </td>
    </tr>
	  </table><?php echo "$player"; ?>
<table align=center>
<tr>
<td>
<input type=submit name=submit value=Next>
</td>
</form>
</tr>
</table>
</body></html>
<?php
}
}
}
}
if ($action == "preview" && "cat" && "id"){
$user = file("file.txt");
if(strlen($id) <= 3){
	premain();
	print "<p><BR><BR><BR><b>Your category must be longer than 3 characters</b><br><BR><BR><BR>";
}else{
	for($x=0;$x<sizeof($user);$x++) {
		$temp = explode(";",$user[$x]);
		$opp[$x] = "$temp[0];$temp[1];$temp[2];$temp[3];$temp[4];$temp[5];$temp[6];";
			$meta = $id;
			$meta2 = $temp[5];
			$such = stristr($meta2,$meta);
			if($such) {
				$list[0] = $opp[$x];
				$list;
			}

$temp = explode(";",$user[$x]);
}
if(sizeof($list) != "0") {
for($y=0;$y<sizeof($list);$y++) {
$temp = explode(";",$list[$y]);
premain();
$image_info = getimagesize("$temp[2]");
$v=basename("$temp[2]");
$w=explode(".",$v);
if ($w[1]=="swf"){
	$image="<embed src='$temp[2]' height='$image_info[1]' width='$image_info[0]'></embed>";
}
else{
	$image="<img src='$temp[2]' height='$image_info[1]' width='$image_info[0]'>";
}
echo "<table align=center><tr><td align=middle><font face=arial size=2><b>Preview</b></tr><tr><td align=middle>$image</td></tr></table>";
?>
<html><head>
<body bgcolor=#f5f5f5>
<form name=mail method=post action="?action=sendmail">
<table>
      <td align=left><FONT SIZE="3" COLOR="#000000" face="Arial">Hello <?php echo $rname; ?>,</FONT></td>
    </tr>
      <tr></table><table>
      <td width=80%>
	  <?php echo "<FONT SIZE=3 COLOR=#000000 face=Arial><B>$message</B></font>"; ?>
      </td>
    </tr><tr><td></td></table>
	<?php
if ($music=="0"){
	$p="";
}else{
$p="<embed src='$temp[3]' width=0 height=0></embed>";
}
echo "<FONT SIZE=3 COLOR=#000000 face=Arial>From $name</font>";
echo "$p";
echo "<table align=center>
<form method=post action='?action=sendmail'>
<input type=hidden name='name' value='$name'>
<input type=hidden name='rname' value='$rname'>
<input type=hidden name='from' value='$email'>
<input type=hidden name='to' value='$recipient'>
<input type=hidden name='subject' value='E Greeting from $name'>
<input type=hidden name='toname' value='$rname'>
<input type=hidden name='bg' value='$music'>
<input type=hidden name='mess' value='$message'>
<input type=hidden name='pic' value='$temp[2]'>
<input type=hidden name='mus' value='$temp[3]'>
<input type=hidden name='effect' value='$temp[6]'>
<td><input type=button value=Back onclick='javascript:history.back()'>
<input type=submit value=Send></td></table>";
?>
<?php
}
}
}
}
if ($action == "view" && "cat" && "id"){
$filename = "dt/$id".".dat";
if(file_exists($filename)) {
$fd = fopen ($filename, "r");
$stuff = fread ($fd, filesize ($filename));
fclose ($fd);
$temp = explode ("|~|",$stuff);
$image_info = getimagesize("$temp[4]");
$v=basename("$temp[4]");
$w=explode(".",$v);
if ($w[1]=="swf"){
	$image="<embed src='$temp[4]' height='$image_info[1]' width='$image_info[0]'></embed>";
}
else{
$image="<img src='$temp[4]' height='$image_info[1]' width='$image_info[0]'>";
}
echo "<table align=center><tr><td align=middle><font face=arial size=2><b>E Greetings</b></tr><tr><td align=middle>$image</td></tr></table>";
?>
<html><head><style type="text/css">
TD                 {font-family: Arial; color: #000000; font-size: 8pt;}
INPUT           {font-family:Verdana;font-size:10pt;BACKGROUND-COLOR: #FFFFFF;color:#000000;}
TEXTAREA         {font-family:verdana,helvetica,sans-serif;font-size:10pt;BACKGROUND-COLOR:#ffffff;color:#000000;}
</style></head>
<body bgcolor=#f5f5f5>
<form name=mail method=post action="?action=sendmail">
<table>
      <td align=left><FONT SIZE="3" COLOR="#000000">Hello <?php echo $temp[6]; ?>,</FONT></td>
    </tr>
      <tr></table><table>
      <td width=80%>
	  <?php echo "<b><FONT SIZE=4 COLOR=#000000>$temp[2]</FONT></b>"; ?>
      </td>
    </tr><tr><td></td></table>
	<?php
if ($temp[3]=="0"){
	$p="";
}else{
$p="<embed src='$temp[5]' width=0 height=0></embed>";
}
echo "<FONT SIZE=3 COLOR=#000000>From $temp[0]</font>";
echo "$p";
?>
</body></html>
<?php
}else{
echo "<FONT SIZE=4 COLOR=#000000 face=arial>Sorry Your Greeting has expired.</font><BR>Powered By:<a href=http://www.webgalli.com>Webgalli</a></FONT>";
}
}
function premain(){
}
if($action == "add_gre") {
$l=base64_decode($m);
if($l==$password){
echo " <center><font face=arial>Add an Ecard:</center><br></font><form name=\"add_gre\" method=\"post\" action=\"?action=submit_dict\">";
 				echo "<table><tr><td>Thumbnail Path:</td><td><input type=\"text\" name=\"thumbnail\" size=\"50\" value=\"images/\"></td></tr>";
				echo "<font face=arial size=2><tr><td>E-card Path:</td><td><input type=text name=ecard_path size=50 value=\"images/\"></td></font></tr>";
				echo "<tr><font face=arial size=2><td>Music Path:</td><td><input type=text name=category size=50 maxlength=300 value=\"sound/\">*Blank for no music</font></td></tr>";
                echo "<tr><font face=arial size=2><td>Category:</td><td></font><input type=text name=cat size=50 >*CaSe SeNsEtIvE</td></tr>";
				echo "<tr><td></td><td><input type=hidden name=m value=$m><input type=\"submit\" value=\"submit\"></td></tr></table></form>";
}else{
echo "Login Again";
}
}
if($action == "submit_dict") {
$l=base64_decode($m);
if($l==$password){
$fi=base64_encode($password);
$fp = fopen ("file.txt", "a+");
$data_submitted = time();
fwrite ($fp, "[new];");
fwrite ($fp, $thumbnail);
fwrite ($fp, ";");
fwrite ($fp, $ecard_path);
fwrite ($fp, ";");
fwrite ($fp, $category);
fwrite ($fp, ";");
fwrite ($fp, $cat);
fwrite ($fp, ";");
fwrite ($fp, $data_submitted);
fwrite ($fp, ";");
fwrite ($fp, $effect);
fwrite ($fp, ";");
fwrite ($fp, "\n");
fclose ($fp);
print "<BR><font face=arial size=3>Ecard added successfully.<br><A HREF=?action=add_gre&m=$m>add another Ecard</A><BR><A HREF=?action=login&m=$m>Go to Admin Panel</A>";
}else{
echo "Please Login Again";
}
}
$filename = "file.txt";
$update = time();
?>
<HTML>
<HEAD>
</HEAD>
<body topmargin="50" leftmargin="50">
<?php
if(!$_GET['action']){
		$date = date("l jS F, Y");
		?>
  <?php
}
else if($_GET['action'] == "change_greet") {
$l=base64_decode($m);
if($l==$password){
		if($_GET['id'] >= 0){
				global $filename;
				$id = $_GET['id'];
				$fp = @fopen($filename, 'r');
				$array = explode("\n", fread($fp, filesize($filename)));
				for($x=0;$x<sizeof($array);$x++) {
					$temp = explode(";",$array[$x]);
					$line[$x] = "$temp[0];$temp[1];$temp[2];$temp[3];$temp[4];$temp[5];$temp[6];";
				}
				$data_submitted = time();
				$mod = explode(";", $line[$id]);
				echo "Update $mod[1]";
				echo "<form method=\"POST\" action=\"?action=change_greet2\" method=\"post\">";
 				echo "<table><tr><td>Thumbnail Path/URL:</td><td><input type=\"text\" value=\"$mod[1]\" name=\"thumbnail\" size=\"50\"></td></tr>";
				echo "<font face=arial size=2><tr><td>E-card Path/URL:</td><td><input type=text name=ecard_path value='$mod[2]' size=50></td></font></tr>";
				echo "<tr><font face=arial size=2><td>Music Path:</td><td><input type=text name=category size=50 maxlength=300 value='$mod[3]'>*Blank for no music</font></td></tr>";
                echo "<tr><font face=arial size=2><td>Category:</td><td></font><input type=text name=cat size=50 value='$mod[4]'>*CaSe SeNsEtIvE</td></tr>";
				echo "<input type=\"hidden\" name=data_submitted value=\"$data_submitted\"> ";
				echo "<tr><td></td><input type=\"hidden\" name=m value=\"$m\"><td><input type=\"submit\" value=\"submit\">&nbsp;";
				echo "<input type=\"reset\" value=\"Reset\"></td></tr>";
				echo "<input type=\"hidden\" name=\"id\" value=\"$id\">";
				echo "</form></table>";

		}
		else{
			print "No ID specified";
		}
}else{
	echo "Please Login Again";
}
}
else if($_GET['action'] == "change_greet2") {
$l=base64_decode($m);
if($l==$password){
		if($_POST['thumbnail'] && $_POST['id'] >= 0){
				global $filename;
				$new="[new]";
				$new = stripslashes($_POST['new']);
				$thumbnail = stripslashes($_POST['thumbnail']);
				$ecard_path = stripslashes($_POST['ecard_path']);
				$cat = stripslashes($_POST['cat']);
				$category = stripslashes($_POST['category']);
				$data_submitted = stripslashes($_POST['data_submitted']);
				$id = $_POST['id'];
				$fp = @fopen($filename, 'r');
				$array = explode("\n", fread($fp, filesize($filename)));
				for($x=0;$x<sizeof($array)-1;$x++) {
					$temp = explode(";",$array[$x]);
					$line[$x] = "$temp[0];$temp[1];$temp[2];$temp[3];$temp[4];$temp[5];$temp[6];";
				}
				$line[$id]= "[new];$thumbnail;$ecard_path;$category;$cat;$data_submitted;$effect;";
				sort($line);
				$fp = fopen ("file.txt", "w");
				fwrite ($fp, $line[0]);
				for($i=0; $i<sizeof($line);$i++){
				fwrite ($fp, $line[$i]);
				fwrite ($fp, "\n");
				}
				fclose ($fp);
				print "<p><p>Edited successfully<br><br><A HREF=?action=edit_gre&m=$m>Back to edit list</A><BR><BR>";
		}
		else{
			print "Please go back and fill in the form properly.";
		}
}else{
	echo "Please Login Again";
}
}
if($action == "browse") {
$user = file("file.txt");
$lis = 0;
if(strlen($category) <= 0){
print "<p><BR><BR><BR><b>There has been an error.</b><br><BR><BR><BR><BR><BR><BR>";
}
else{

 echo "<table width=100% border=0 valign=middle><td width=80% align=middle border=1 style='Background:#ffffff'>";
	for($x=0;$x<sizeof($user);$x++) {
		$temp = explode(";",$user[$x]);
		$opp[$x] = "$temp[0];$temp[1];$temp[2];$temp[3];$temp[4];$temp[5];$temp[6];";
		$such = stristr($temp[4],$category);
			$meta = $category;
			$meta2 = $temp[4];
			$such = stristr($meta2,$meta);
			if($such) {
				$list[$lis] = $opp[$x];
				$lis++;
			}
	}
	if(sizeof($list) != "0") {
	if(sizeof($list) == "1") {
	$spellcards="card";
	}else{
	$spellcards="cards";
	}
	echo "<BR><font face=arial><p><b>",sizeof($list),"</b> $spellcards in category \"$category\"<BR></p></font>";
	}else{
	echo "<p><b>&nbsp;No Cards in $category.</b><BR>";
	}
$latest_max = sizeof($list);
$u = $a - $latest_max;
if (is_file("file.txt"))
	{
	$s=sizeof($list);

if ($page=='' or !$page) { $page=1; }
$end=$listings_per_page*$page;
$start=$end-$listings_per_page;

if ($start<>'0') {
	$new_page=$page-1;
	$prev="<a href='?action=browse&category=$category&page=$new_page'><---Previous page</a>";
}
else {
	$prev="";
}

if ($end<$s) {
	$new_page1=$page+1;
	$next="<a href='?action=browse&category=$category&page=$new_page1'>Next page---></a>";
}
else {
	$next="";
}
$today = time();
for ($i=$start; $i<$end; $i++){
	if(substr($list[$i], 0, 5 )== "[new]")
	{
	sort($list);
    $p=explode(';', $list[$i]);
	$v=basename("$p[2]");
$w=explode(".",$v);
if ($w[1]=="swf"){
	$val="Requires Flash";
}elseif(strlen($p[6])>="3"){$val="Requires Java enabled browser";}
else{$val="";}
echo " <a href='?action=detail&category=$category&id=$p[5]'><img src='$p[1]' alt='$val'></a> ";
}
}
$pages=$s/$listings_per_page;
$pages1=round($pages, 2);
$p= explode(".", $pages1);
$pcount=count($p);
$ext=$p[$pcount-2];
if ($ext!=0) {
	$num=$p[0]+1;
}

else {
	$num=$p[0];
}
echo "</td></table><table width='100%'><tr><td align='left'>$prev</td><td align='center'>";
for ($i=1; $i<=$num; $i++) {
	if ($i==$page) {
echo "<B>&nbsp;$i&nbsp;</B> ";

	}
	else {
echo "&nbsp;<a href='?action=browse&category=$category&page=$i'>$i</a>";
}
}
echo "</td><td align='right'>$next</td></tr></table>";
}
}
}
if($action == "edit_gre") {
$l=base64_decode($m);
if($l==$password){
global $filename;
global $password;
$fp = @fopen($filename, 'r');
if ($filename) {
$array = explode("\n", fread($fp, filesize($filename)));
$listed = count($array)-1;
?>
<table border="0" cellpadding="2" cellspacing="0" width="100%">
<tr>
<td width="99%"><font size="3">Edit</font></td>
</tr>
<td><A HREF="?action=login&m=<?php echo "$m"; ?>">Back</A></td></table><table width=90%>
<br>
<?php
echo "Click thumbnail to edit :: Viewing all ($listed) listed by Thumbnail<P><P>";

for($x=0;$x<$listed;$x++) {
$temp = explode(";",$array[$x]);

				echo "<tr><td align=left><A HREF=\"?action=change_greet&id=$x&m=$m\"><img src='$temp[1]'></A><BR>$temp[4]</td></tr>";

			}
		}
		echo "</table>";
}else{
echo "Please Login";
}
}
if($action == "") {
$f=date("m");
$g=date("d");
$user=file("events.txt");
$kid="0";
for($x=0;$x<sizeof($user);$x++) {
$temp = explode(";",$user[$x]);
$opp[$x] = "$temp[0];$temp[1];$temp[2];$temp[3];$temp[4];$temp[5];";
$list[$kid] = $opp[$x];
$kid++;
}
$dir="./dt";
$handle = @opendir($dir);
while (false !== ($file = readdir($handle))) {
$n= explode(".",$file);
$et=time() - $n[0];
if (file_exists("$dir/".$file)&& $et >= ("86400"*$expire) && filesize("$dir/$file")>= 10){
if (strlen($n[0])>=3){
unlink("$dir/$file");
}
}else{
}
}
?>
<table><td>
<?php include "category.php"; ?></td><td><BR><table border=0 cellspacing=0 cellpadding=0 width=100%><td bgcolor=#afc6db height=17 rowspan=2 nowrap><font face=verdana size=-2 color=white>&nbsp;&nbsp;<b>Upcomming Events:</b></font></td><td bgcolor=#afc6db valign=top><img id=cti1 src='tr14x15_1.gif' width=14 height=15 alt=""></td><td align=left width=100% ><font face=verdana size=-2><b></b></font></td></tr><tr><td bgcolor=#afc6db colspan=2><table border=0 cellspacing=0 cellpadding=0><tr><td height=3></td></tr></table></td></tr></table><table width=100% cellpadding=4 cellspacing=0 border=0 bgcolor=#f8f8f8 class=yhmpabd><tr><td align=left><font face=arial size=-1><?php
if(sizeof($list)!="0"){
for($y=0;$y<=sizeof($list);$y++) {
$temp = explode(";",$list[$y]);
$calc=(($temp[2]*"30")+($temp[3]));
$calc2=(($temp[4]*"30")+($temp[5]));
$calc1=(($f*"30")+($g));
if( $calc1 >= $calc && $calc1 <= $calc2){
$events = "<li><A HREF='?action=browse&category=$temp[1]'>$temp[0]</A><BR>";
$cd=1;
}else{
$events="";
}
echo "$events";
}
if($cd!="1"){echo "No upcomming events";}
}
?></font></td></table></td></tr></table>
</CENTER><p>&nbsp;</p><p>&nbsp;</p>
<?php
}
?>