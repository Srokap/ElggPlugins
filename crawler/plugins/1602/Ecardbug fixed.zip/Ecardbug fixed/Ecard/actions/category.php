<!-- You can change the category from here -->
<table bordercolor="#AFC6DB" border=1>
<CENTER>Pick a category</CENTER>
    <TD align=center><font size=4><A
      href="?action=browse&category=Birthdays">Birthdays</A></TD>
    <TD align=center><font size=4><A
      href="?action=browse&category=Events and Milestones">Events and Milestones</A></TD>
    <TD align=center><font size=4><A
      href="?action=browse&category=Love and Romance">Love and Romance</A></TD>
    <TD align=center><font size=4><A
      href="?action=browse&category=Forgiveness">Forgiveness</A></TD><tr>
    <TD align=center><font size=4><A
      href="?action=browse&category=Holiday and Seasons">Holiday and Seasons</A></TD>
    <TD align=center><font size=4><A
      href="?action=browse&category=Friendship">Friendship</A></TD>
    <TD align=center><font size=4><A
      href="?action=browse&category=For Any Occasion">For Any Occasion</A></TD>
    <TD align=center><font size=4><A
      href="?action=browse&category=Invitations">Invitations</A></TD>
</font></table>