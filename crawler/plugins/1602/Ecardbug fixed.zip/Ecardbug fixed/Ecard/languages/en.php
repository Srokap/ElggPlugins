<?php

	/**
	 * Elgg E Card plugin
	 * This plugin allows to send message to custom email you specify at module configuration area
	 * 
	 * @package ElggE Card
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @author Dr. Sanu P Moideen <drsanupmoideen@gmail.com>
	 * @copyright Curverider Ltd 2008
	 * @copyright Dr. Sanu P Moideen @ webgalli.com 2008
	 * @link http://elgg.com/
	 */
		
		$english = array(
	
		/**
		 * Plugin button, menu title, page title, default email
		 */
	
			'ECard:plugin:name' => "E Card",
			'ECard:page:title' => "Send an E Card",			
			

	);
					
	add_translation("en",$english);

?>