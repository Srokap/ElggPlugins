<?php

	/**
	 * Elgg E Card plugin
	 * This plugin allows to send message to custom email you specify at module configuration area
	 * 
	 * @package ElggE Card
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @author Dr. Sanu P Moideen <drsanupmoideen@gmail.com>
	 * @copyright Curverider Ltd 2008
	 * @copyright Dr. Sanu P Moideen @ webgalli.com 2008
	 * @link http://elgg.com/
	 */
	 
	 global $CONFIG;
	 	 	
	// Register a page handler, so we can have nice URLs
		register_page_handler('Ecard','Ecard_page_handler');
	
	// Page handler
		function Ecard_page_handler($page) {
			global $CONFIG;
			include($CONFIG->pluginspath . "Ecard/index.php");
		}
		
	// Load menu
		add_menu(elgg_echo('E Cards'),$CONFIG->wwwroot."pg/Ecard");
		
	// Register action
	register_action('Ecard/send',false,$CONFIG->pluginspath . "Ecard/actions/send.php");
?>