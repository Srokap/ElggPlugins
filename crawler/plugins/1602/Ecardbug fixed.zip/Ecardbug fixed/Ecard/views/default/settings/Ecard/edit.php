<?php

	/**
	 * Elgg hack plugin
	 * This plugin allows to send message to custom email you specify at module configuration area
	 * 
	 * @package Elgghack
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @author Tim Timalsina <info@timalsina.com>
	 * @copyright Curverider Ltd 2008
	 * @copyright TIMALSINA 2008
	 * @link http://elgg.com/
	 */
	
?>	 
<p>
<iframe name="iFrame1" width="660" height="500" src="<?php echo $vars['url']; ?>mod/Ecard/actions/index.php?action=admin" scrolling="auto" frameborder="0"></iframe>
</p>