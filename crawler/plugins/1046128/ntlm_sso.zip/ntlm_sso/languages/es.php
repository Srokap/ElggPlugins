<?php

    /**
     * Elgg LDAP authentication
     *
     * @package ElggLDAPAuth
     * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
     */

    $spanish = array(
        'ldap_auth:settings:label:host' => "Configuraci&oacute;n del servidor",
        'ldap_auth:settings:label:connection_search' => "Configuración del servidor LDAP",
        'ldap_auth:settings:label:hostname' => "Servidor",
        'ldap_auth:settings:help:hostname' => "Nombre canonico del servidor, por ejemplo <i>ldap.yourcompany.com</i>",
        'ldap_auth:settings:label:port' => "Puerto del servidor LDAP",
        'ldap_auth:settings:help:port' => "Puerto del servidor LDAP. Por defecto es 389, el que usar&aacute;n la mayor&iacute;a de los servidores.",
        'ldap_auth:settings:label:version' => "Versi&oacute;n del protocolo LDAP",
        'ldap_auth:settings:help:version' => "Versi&oacute;n del protocolo LDAP. Por defecto es 3, es la que usar&aacute;n la mayor&iacute;a de los servidores LDAP actuales.",
        'ldap_auth:settings:label:ldap_bind_dn' => "DN de conexión LDAP",
        'ldap_auth:settings:help:ldap_bind_dn' => "¿Qu&eacute; DN  se usar&aacute; para los enlaces no an&oacute;nimos?, por ejemplo <i>cn=admin,dc=yourcompany,dc=com</i>",
        'ldap_auth:settings:label:ldap_bind_pwd' => "Contrase&ntilde;a del enlace LDAP",
        'ldap_auth:settings:help:ldap_bind_pwd' => "¿Qu&eacute; contrase&ntilde se usar&aacute; para los enlaces no an&oacute;nimos?",
        'ldap_auth:settings:label:basedn' => "DN base",
        'ldap_auth:settings:help:basedn' => "DN base. Separa con dos puntos (:) para introducir varios DNs, por ejemplo <i>dc=yourcompany,dc=com : dc=othercompany,dc=com</i>",
        'ldap_auth:settings:label:filter_attr' => "Atributo de filtrado de nombre de usuario (Username filter attribute)",
        'ldap_auth:settings:help:filter_attr' => "El filtro para el nombre de usuario, normalmente son <i>cn</i>, <i>uid</i> o <i>sAMAccountName</i>.",
        'ldap_auth:settings:label:search_attr' => "Atributos de b&uacute;squeda",
        'ldap_auth:settings:help:search_attr' => "Introduzca atributos de b&uacute;squeda como clave, los pares de valor con la clave como atributo de descripci&oacute;n, y el valor como el atribuo LDAP actual.",
        'ldap_auth:settings:label:user_create' => "Crear usuarios",
        'ldap_auth:settings:help:user_create' => "Opcionalmente, una cuenta puede ser creada cuando alguien se autentica desde LDAP.",
        'ldap_auth:settings:label:start_tls' => "Inicio de sesi&oacute;n TLS",
        'ldap_auth:settings:help:start_tls' => "Inicio de sisi&oacute;n TLS para securizar la autenticaci&oacute; LDAP (el servidor necesita tener soporte de LDAPS).",
        'ldap_auth:no_account' => "Sus credenciales son v&aacute;lidas pero no se encontr&oacute; ninguna cuenta. Por favor, contacte con el administrador del sistema",
        'ldap_auth:no_register' => 'No se puedo crear una cuenta para usted. Por favor, contacte con el administrador del sistema.'
    );
   
    add_translation('es', $spanish);
?>
