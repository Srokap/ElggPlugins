<?php
    /**
	 * Elgg LDAP authentication
	 * 
	 * @package ElggLDAPAuth
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @link http://elgg.com
	 */

	/**
	 * LDAP Authentication init
	 * 
	 * These parameters are required for the event API, but we won't use them:
 	 * 
	 * @param unknown_type $event
	 * @param unknown_type $object_type
	 * @param unknown_type $object 
	 */
	function ldap_auth_init()
	{
	    global $CONFIG;
	    
	    // Register the authentication handler
	    register_pam_handler('ldap_auth_authenticate');

        register_translations($CONFIG->pluginspath . "ldap_auth/languages/");
	}
	
	// Register the initialisation function
	//elgg_register_event_handler('init','system','ldap_auth_init');

	function ntlm_auth_init()
	{
		global $CONFIG;
		$credentials['username'] = 'dummy';
		$credentials['password'] = 'user';
		// Override save method
		elgg_register_action('ntlm_sso/settings/save',$CONFIG->pluginspath . 'ntlm_sso/actions/plugins/settings/save.php');
		// Register the authentication handler
		register_pam_handler('ntlm_auth_authenticate');
		register_translations($CONFIG->pluginspath . "ntlm_sso/languages/");
		if (!elgg_is_logged_in() && $_SERVER['PHP_AUTH_USER'])
		{
			$username = $_SERVER['PHP_AUTH_USER'];
				$result=elgg_authenticate($username,'dummy');
			if ($result !== true) {
				register_error($result);
			}
			else
			{
				forward(REFERER);
			}
		}
	}
	/**
	* NTLM authentication
	* 
	* @param mixed $credentials PAM handler specific credentials
	* @return boolean
	*/
	function ntlm_auth_authenticate($credentials = null)
	{
		// Nothing to do if LDAP module not installed
		$user_create = elgg_get_plugin_setting('user_create', 'ntlm_sso');
		// Get configuration settings
		$config = find_plugin_settings('ntlm_sso');
				
		// Nothing to do if not configured
		if (!$config)
		{
			return false;
		}
		$username      = null;
		// Check SERVER variables to check if user was authenticated (nothing to do otherwise)
		//if ($_SERVER['PHP_AUTH_USER'] && ($_SERVER['AUTH_TYPE'] == 'NTLM'))
		if ($_SERVER['PHP_AUTH_USER'])
		{
			$username = $_SERVER['PHP_AUTH_USER'];
		} else {
			return false;
		}
		
		// Perform the authentication
		return ldap_auth_check($config, $username,$user_create);
	}
	
	/**
	 * LDAP authentication
	 * 
	 * @param mixed $credentials PAM handler specific credentials
	 * @return boolean
	 */
	function ldap_auth_authenticate($credentials = null)
    {
        // Nothing to do if LDAP module not installed
        if (!function_exists('ldap_connect')) return false;

        // Get configuration settings
        $config = find_plugin_settings('ldap_auth');
        
        // Nothing to do if not configured
        if (!$config)
        {
            return false;
        }
        
        $username      = null;
        $password      = null;
        
        if (is_array($credentials) && ($credentials['username']) && ($credentials['password']))
        {
            $username = $credentials['username'];
            $password = $credentials['password'];
        }
        else
        {
            return false;
        }
        
        // Perform the authentication
        return ldap_auth_check($config, $username, $password);
    }
    
    /**
     * Perform an LDAP authentication check
     *
     * @param ElggPlugin $config
     * @param string $username
     * @param string $password
     * @return boolean
     */
	function ldap_auth_check($config, $username,$user_create)
	{
		if ($user = get_user_by_username($username))
		{
			return login($user);
		}
		else
		{
		
			if ($user_create == 'on')
			{
				if (!function_exists('ldap_connect'))
				{
					 elgg_log("BRUNO ntlm_sso no ldap_connect", 'NOTICE');
					 return false;
				}
				$host        = elgg_get_plugin_setting('hostname', 'ntlm_sso');
		
				// No point continuing
				if(empty($host))
				{
					elgg_log("LDAP error: no host configured.",'ERROR');
				return;
				}
		
				$port        = elgg_get_plugin_setting('port', 'ntlm_sso');
				$version     = elgg_get_plugin_setting('version', 'ntlm_sso');
				$basedn      = elgg_get_plugin_setting('basedn', 'ntlm_sso');
				$filter_attr = elgg_get_plugin_setting('filter_attr', 'ntlm_sso');
				$search_attr = elgg_get_plugin_setting('search_attr', 'ntlm_sso');
				$bind_dn     = elgg_get_plugin_setting('ldap_bind_dn', 'ntlm_sso');
				$bind_pwd    = elgg_get_plugin_setting('ldap_bind_pwd', 'ntlm_sso');
				$user_create = elgg_get_plugin_setting('user_create', 'ntlm_sso');
				$start_tls   = elgg_get_plugin_setting('start_tls', 'ntlm_sso');
			
				($user_create == 'on') ? $user_create = true : $user_create = false;
				($start_tls == 'on') ? $start_tls = true : $start_tls = false;
				$port        ? $port        : $port = 389;
				$version     ? $version     : $version = 3;
				$filter_attr ? $filter_attr : $filter_attr = 'uid';
				$basedn      ? $basedn = array_map('trim', explode(':', $basedn)) : $basedn = array();
		
				if (!empty($search_attr))
				{
					// $search_attr as in "email:email_address, name:name_name";
					$pairs = array_map('trim',explode(',', $search_attr));
					$values = array();
					foreach ($pairs as $pair)
					{
						$parts = array_map('trim', explode(':', $pair));
						$values[$parts[0]] = $parts[1];
					}
					$search_attr = $values;
				} else {
					$search_attr = array('dn' => 'dn');
				}
		
				// Create a connection
				if ($ds = ldap_auth_connect($host, $port, $version, $bind_dn, $bind_pwd))
				{
					if ($start_tls and !ldap_start_tls($ds)) return false;
					// Perform a search
					foreach ($basedn as $this_ldap_basedn)
					{
					
						$ldap_user_info = ldap_auth_do_auth($ds, $this_ldap_basedn, $username, $filter_attr, $search_attr);

						if($ldap_user_info)
						{
										// Valid login but user doesn't exist
							//$name  = $ldap_user_info['lastname'];
							$name  = $ldap_user_info[0];
					 
							//if (isset($ldap_user_info['firstname']))
							if (isset($ldap_user_info[1]))
							{
								//$name  = $ldap_user_info['lastname']." ".$name;
								$name  = $ldap_user_info[1]." ".$name;
							}
							//($ldap_user_info['mail']) ? $email = $ldap_user_info['mail'] : $email = null;
							($ldap_user_info[2]) ? $email = $ldap_user_info[2] : $email = "";


					    try {
						$user = new ElggUser();
							     $user->username = $username;
							     $user->email = $email;
							     $user->name = $name;
							     $user->access_id = ACCESS_PUBLIC;
							     $user->salt = generate_random_cleartext_password(); // Note salt generated before password!
							     $user->password = generate_user_password($user, $password); 
							     $user->owner_guid = 0; // Users aren't owned by anyone, even if they are admin created.
							     $user->container_guid = 0; // Users aren't contained by anyone, even if they are admin created.
							     $user->save();
							    $guid = $user->getGUID();
							    return true;
					    }
					    catch ( RegistrationException $e ){
						    echo $e;
							$guid = 0;
								register_error(elgg_echo('ntlm_sso:no_register'));
												return false;
					    }
							
							
							////Need to do something with password field since password cannot be empty
							//$password=rand();
							//if ($user_guid = register_user($username, $password, $name, $email))
							//{
							//	// Success, credentials valid and account has been created                                
							//	return true;
							//} else {
							//	register_error(elgg_echo('ntlm_sso:no_register'));
							//					return false;
							//				}
						}
					}
					// Close the connection
					ldap_close($ds);
					register_error(elgg_echo("ntlm_sso:no_account"));
					return false;
					}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		}
	}
		
    
    /**
     * Create an LDAP connection
     *
     * @param string $host
     * @param int $port
     * @param int $version
     * @param string $bind_dn
     * @param string $bind_pwd
     * @return mixed LDAP link identifier on success, or false on error
     */
    function ldap_auth_connect($host, $port, $version, $bind_dn, $bind_pwd)
    {
        $ds = ldap_connect($host, $port);

        ldap_set_option($ds, LDAP_OPT_PROTOCOL_VERSION, $version);
	ldap_set_option($ds, LDAP_OPT_REFERRALS, 0);

        // Start the LDAP bind process

        $ldapbind = null;

        if ($ds)
        {
            if ($bind_dn != '')
            {
                $ldapbind = ldap_bind($ds, $bind_dn, $bind_pwd);
            }
            else
            {
                // Anonymous bind
                $ldapbind = ldap_bind($ds);
            }
        }
        else
        {
            // Unable to connect
            elgg_log('Unable to connect to the LDAP server: '.ldap_error($ds),'ERROR');
            
            return false;
        }

        if (!$ldapbind)
        {
            elgg_log('Unable to bind to the LDAP server with provided credentials: '.ldap_error($ds),'ERROR');
            
            ldap_close($ds);
            
            return false;
        }

        return $ds;
    }
    
    /**
     * Performs actual LDAP authentication
     *
     * @param object $ds LDAP link identifier
     * @param string $basedn
     * @param string $username
     * @param string $password
     * @param string $filter_attr
     * @param string $search_attr
     * @return mixed array with search attributes or false on error
     */
    function ldap_auth_do_auth($ds, $basedn, $username, $password, $filter_attr, $search_attr)
    {
    	
	$search_attr = array("givenname","sn","mail");
        $filter_attr = "(&(objectCategory=person)(sAMAccountName=$username))";
	$sr = ldap_search($ds, $basedn, $filter_attr, array_values($search_attr));
	
	// Above 3 lines replace below criteria
        //$sr = ldap_search($ds, $basedn, $filter_attr ."=". $username, array_values($search_attr));
	
        if(!$sr)
        {
		//register_error(elgg_echo("ldapsearch no entries"));

	        elgg_log('Unable to perform LDAP search: '.ldap_error($ds),'ERROR');
	        return false;
		}
	
        $entry = ldap_get_entries($ds, $sr);

	//if($entry["count"] > 0){
	//register_error(elgg_echo("Name".$entry[0]['displayname'][0]));
	//register_error(elgg_echo("Name".$entry[0]['sn'][0]));
	//register_error(elgg_echo("Name".$entry[0]['givenname'][0]));
	//}
	
        if(!$entry or !$entry[0])
        {
        	return false; // didn't find username
		}

        // Username exists, perform a bind for testing credentials

        //if (ldap_bind($ds, $entry[0]['dn'], $password) )
        //{
            // We have a bind, a valid login

            foreach (array_keys($search_attr) as $attr)
            {
	    //register_error(elgg_echo("[$attr] = ".$entry[0][$search_attr[$attr]][0]));
	        	$ldap_user_info[$attr] = $entry[0][$search_attr[$attr]][0];
		}
            return $ldap_user_info;
		//}

        //return false;
    }
	
	// Register the initialisation function
	elgg_register_event_handler('init','system','ntlm_auth_init');

?>
