<?php

	/**
	 * Elgg thewire view page
	 * 
	 * @package ElggTheWire
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider <info@elgg.com>
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 * 
	 */
	 
?>
<div id="content_area_user_title">
<h2><?php echo sprintf(elgg_echo('riverdashboard:welcome'),$_SESSION['user']->name); ?></h2>
</div>