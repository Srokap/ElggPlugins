<?php
	/**
	 * 
	 *
	 * @package PackOfARoamingCat
	 */
	/**
	 * @author Snow.Hellsing <snow.hellsing@firebloom.cc>
	 * @copyright FireBloom Studio
	 * @link http://firebloom.cc
	 */
	 global $CONFIG;
?>
.preloadImg{
	display:none;
}
/* IE6 */
.mceLayout{
	width:675px !important;
}