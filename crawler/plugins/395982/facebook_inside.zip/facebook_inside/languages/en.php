<?php

	$english = array(
	
		'help' => "Conecta FACEBOOK",
		
		'facebook_inside:facebook' => "Facebook en Red Social Linux&fiends",
	);

	add_translation("es",$english);

?>
