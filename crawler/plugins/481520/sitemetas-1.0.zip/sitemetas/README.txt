Some header metas for elgg.
------------------------

Allows to configure translatable site metas, supported for the moment:
  * keywords
  * description
  * Content-Language

Installation: Put inside your mod/ folder and enjoy!!

Tickets and source repository:
	http://bitbucket.org/rhizomatik/elgg_sitemetas/

License: See COPYING (GPLv2)

--
devel@lorea.cc
