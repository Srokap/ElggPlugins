<?php
/**
         * Elgg spotlight lorea
         * 
         * @package
         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author lorea
         * @copyright lorea
         * @link http://lorea.cc
         */

	$english = array(
		'sitemetas:keywords' => 'section for your keywords',
		'sitemetas:keywords:default' => 'elgg,social network,photos,videos,tasks,calendar,social',
		'sitemetas:description:default' => 'an elgg social network',
		'sitemetas:keywords:n1' => 'elgg,social network,photos,videos,tasks,calendar,social',
		'sitemetas:description:n1' => 'an elgg social network',
		'sitemetas:keywords:ald' => 'elgg,social network,photos,videos,tasks,calendar,social',
		'sitemetas:description:ald' => 'an elgg social network'
	);
	
	add_translation("en",$english);

?>
