<?php
/**
         * Elgg spotlight lorea
         * 
         * @package
         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author lorea
         * @copyright lorea
         * @link http://lorea.cc
         */

	$spanish = array(
                'sitemetas:keywords' => 'seccion de traduccion para tus metas',
                'sitemetas:keywords:default' => 'elgg,red social,fotos,videos,tareas,calendario,social',
                'sitemetas:description:default' => 'una red social en elgg',
                'sitemetas:keywords:n1' => 'elgg,red social,fotos,videos,tareas,calendario,social',
                'sitemetas:description:n1' => 'una red social en elgg',
                'sitemetas:keywords:ald' => 'elgg,red social,fotos,videos,tareas,calendario,social',
                'sitemetas:description:ald' => 'una red social en elgg'
	);
	
	add_translation("es",$spanish);

?>
