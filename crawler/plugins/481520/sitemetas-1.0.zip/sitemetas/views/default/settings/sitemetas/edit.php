<?php
/**
 *	Sitemetas Plugin
 *	@package Sitemetas
 **/

	$sitemetas = get_plugin_setting("sitesection", "sitemetas");
	if (!$sitemetas) {
		$sitemetas = 'default';
	}

	
?>
<p>
	<?php echo elgg_echo('sitemetas:keywords'); ?>
	<?php echo elgg_view('input/text', array('internalname' => 'params[sitesection]','value' => $sitemetas)); ?>
</p>

