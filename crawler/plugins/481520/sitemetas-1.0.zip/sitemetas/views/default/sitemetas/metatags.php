<?php
	$keywords = get_plugin_setting('sitesection', 'sitemetas');
	if (!$keywords) {
		$keywords = 'default';
	}
	$lang = get_current_language();
?>
<meta name="keywords" content="<?php echo elgg_echo('sitemetas:keywords:'.$keywords); ?>" />
<meta name="description" content="<?php echo elgg_echo('sitemetas:description:'.$keywords); ?>" />
<meta http-equiv="Content-Language" content="<?php echo $lang; ?>" />

