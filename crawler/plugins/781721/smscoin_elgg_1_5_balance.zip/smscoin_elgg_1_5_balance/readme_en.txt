SmsCoin Balance sms:bank

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
All information within this software product is the
intellectual property of SmsCoin, Israel.

Given software can be used by http://smscoin.com/ clients
for sms:key service only. Any other use of the software
is violation of the company's right and will be pursued
according to operating law.

SmsCoin. Israel will not be held liable for any loss
or damage of any kind as a result of using this software,
including any lost revenues and/or data.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=


 To use this plug-in you have to be registered on smscoin.net
http://smscoin.net/account/register/ , approve
your e-mail account, in addition to sms:bank service connection.

 Registration and set up process are free of charge.


 Installation process:

	1. Copy folder smscoinuserbalance to /mod/ folder.
	2. Activate the module in your website admin.
	3. Set write permission to mod/smscoinuserbalance/lib/local.js file.
	4. Open module configuration Tools->SmsCoin Balance->Balance Config and set it up.
	5. In sms:bank control panel specify file paths:
		http://example.com/smsbank_json/success.php
		http://example.com/smsbank_json/failure.php
		http://example.com/smsbank_json/result_77.php
		And the password is the same as in module settings (any set of characters is possible).

 How it works:

	Module which enables user to replenish their balance with credits by sending sms message.



 Uninstall:
	1. Open module configuration Tools->SmsCoin Balance and click the Drop Tables button.
	2. Disconnected module.
	3. Remove folder /mod/smscoinuserbalance/


 Support
-------------
 For further questions, please contact SmsCoin technical support
via support@smscoin.com

