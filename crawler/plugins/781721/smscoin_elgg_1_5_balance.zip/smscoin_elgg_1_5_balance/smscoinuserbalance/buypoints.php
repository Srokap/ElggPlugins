<?php
	/**
	 * @package ElggPages
	 * @author smscoin.com
	 * @copyright smscoin.com 2009
	 * @link http://smscoin.com/
	 */

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	global $CONFIG;

	// Get the current page's owner
	$page_owner = page_owner_entity();
	if ($page_owner === false || is_null($page_owner)) {
		$page_owner = $_SESSION['user'];
		set_page_owner($_SESSION['guid']);
	}

	#Get database entries
	$amount = floatval(get_input("s_amount"));

	$res = get_data_row("SHOW TABLES LIKE '{$CONFIG->dbprefix}smscoin_balance'");
	if(!$res) {
		# Create table
		update_data("CREATE TABLE IF NOT EXISTS {$CONFIG->dbprefix}smscoin_balance (
			bank_id int,
			language varchar(32),
			code varchar(255),
			cron_time int default 0,
			points float unsigned default 100,
			description varchar(255),
			PRIMARY KEY (bank_id)
			)
		");
		update_data("INSERT IGNORE INTO {$CONFIG->dbprefix}smscoin_balance (bank_id, language, code, cron_time, points, description)
			VALUES (3849,'russian','1234', 0, 100, 'Buy Points')
		");
		update_data("ALTER IGNORE TABLE {$CONFIG->dbprefix}users_entity ADD COLUMN balance FLOAT DEFAULT 0");
	}
	$res = get_data_row("SELECT * FROM {$CONFIG->dbprefix}smscoin_balance");

	$credits = get_data_row("SELECT * FROM {$CONFIG->dbprefix}users_entity WHERE guid = '".$_SESSION['user']->guid."'");
	#View forms
	if($amount == 0) {
		$smsform = '
			<script type="text/javascript">
				JSON_URL = "'. $CONFIG->wwwroot .'/mod/smscoinuserbalance/lib/local.js?r="+Math.random();
				POINTS = 100;
				CREDITS = "'.elgg_echo('SMSCOIN_CREDITS').'";
				SELECT_AMOUNT = "'.elgg_echo('SMSCOIN_SMS_PRICE').'";
			</script>
			<script src="'. $CONFIG->wwwroot .'/mod/smscoinuserbalance/dropdown.js" type="text/javascript"></script>
			<style>
				#ui h1 {
					font: 12pt "Verdana", sans-serif;
				}
				#ui h2 {
					font: 12pt "Verdana", sans-serif;
				}
			</style>
			<div class = "post_to_wire" >
				<div align = "center">
					<div id="ui" class="dropdown" style="display: none">
						<h1>'.elgg_echo('SMSCOIN_ACCOUNT_BALANCE').': <b>'.$credits->balance.'</b> '.elgg_echo('SMSCOIN_CREDITS').'!</h1><br />
						<h1>'.elgg_echo('SMSCOIN_REFOUND_BALANCE').'</h1><br />
						<h2>'.elgg_echo('SMSCOIN_SELECT_COUNTRY').':</h2>
						<select id="select_country">
							<option value="-">'.elgg_echo('SMSCOIN_SELECT_COUNTRY').'</option>
						</select>
						<div id="providers" style="display: none"><br />
							<h1>'.elgg_echo('SMSCOIN_SELECT_PROVIDER').':</h1>
							<select id="select_provider">
								<option value="-">'.elgg_echo('SMSCOIN_SELECT_PROVIDER').':</option>
							</select>
						</div>
						<div id="instructions" style="display: none"><br />
							<h2>'.elgg_echo('SMSCOIN_SMS_PRICE').':</h2>
								<select id="select_cost">
									<option value="-">'.elgg_echo('SMSCOIN_SMS_PRICE').'</option>
								</select>
							<p id="notes" style="display: none"></p>
						</div><br />
						<form action="" method="POST">
							<p>
								<input name="s_amount" id = "s_amount" type="hidden" value="0" /><br />
								<input type="submit" value="'.elgg_echo('SMSCOIN_PAY').'" style="display: none" id = "sub"/>
							</p>
						</form>
					</div>
					<div id="fail" style="display: none">
						<h1>Error connecting to server</h1>
					</div>
				</div>
			</div>';
	} else {
		# Payment form
		$sign = ref_sign($res->bank_id, $_SESSION['user']->guid, $amount, 0,$res->description, $res->code);
		$smsform = '
			<form action="http://service.smscoin.com/bank/?s_language='.$res->language.'" method="POST">
				<div class = "post_to_wire">
					<input name="s_purse" type="hidden" value="'.$res->bank_id.'" />
					<input name="s_order_id" type="hidden" value="'.$_SESSION['user']->guid.'" />
					<input name="s_amount" type="hidden" value="'.$amount.'" />
					<input name="s_clear_amount" type="hidden" value="0" />
					<input name="s_description" type="hidden" value="'.$res->description.'" />
					<input name="s_sign" type="hidden" value="'.$sign.'" />
					<div align = "center">'.elgg_echo('SMSCOIN_AFTER_ACTION').' <input type="submit" value="'.elgg_echo('SMSCOIN_PAY').'" /> '.elgg_echo('SMSCOIN_NEXT_STEP').'.</div>
				</div>
			</form>';
	}
	# Cron launch

	if(($res->cron_time+3600) < time()) {
		run_sms_cron($res);
	}
	set_context($context);

	$title = "SmsCoin Balance";
	$body = elgg_view_title($title);
	$body .= $smsform;
	$body = elgg_view_layout('two_column_left_sidebar','',$body);

	// Finally draw the page
	page_draw($title, $body);

	##
	#   Signature creation function
	##
	function ref_sign() {
		$params = func_get_args();
		$prehash = implode("::", $params);
		return md5($prehash);
	}
	###
	#   Rates update
	#
	###
	function run_sms_cron($res) {
		global $CONFIG;
		$bank_id = $res->bank_id;
		$s_lang = $res->language;
		@ini_set('user_agent', 'smscoin_key_cron');
		$cron_info = "<br />";
		if(is_numeric($bank_id) && $bank_id != 0) {
			$response = file_get_contents("http://bank.smscoin.com/language/$s_lang/json/bank/".$bank_id."/");
			if ($response !== false) {
				$filename = dirname(__FILE__).'/lib/local.js';
				if (($hnd = @fopen($filename, 'w')) !== false) {
					if (@fwrite($hnd, $response) !== false) {
						# Rate scale is updated
						$cron_info .= ('Success, file local.js updated @ '.date("r"));
						update_data("UPDATE {$CONFIG->dbprefix}smscoin_balance SET cron_time = ".time());
					} else {
						$cron_info .= ('File local.js not writable');
					}
					fclose($hnd);
				} else {
					$cron_info .= ('Could not open file local.js');
				}
			} else {
				$cron_info .= ('Unable to connect to remote server');
			}
		}
	}
?>
