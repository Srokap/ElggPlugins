<?php
/*
=====================================================
 Elgg plugin - by SmsCoin
-----------------------------------------------------
 http://smscoin.com
-----------------------------------------------------
 Copyright (c) 2008 SmsCoin
=====================================================
 File: result.php
-----------------------------------------------------
 Purpose: payment via SMS module
=====================================================
*/
	chdir("../../");
	define('externalpage',true);
	require_once("engine/start.php");
	global $CONFIG;


	// the function returns an MD5 of parameters passed
	// функция возвращает MD5 переданных ей параметров
	function ref_sign() {
		$params = func_get_args();
		$prehash = implode("::", $params);
		return md5($prehash);
	}

	// filtering junk off acquired parameters
	// парсим полученные параметры на предмет мусора
	foreach($_REQUEST as $request_key => $request_value) {
		$_REQUEST[$request_key] = substr(strip_tags(trim($request_value)), 0, 250);
	}

	// collecting required data
	// собираем необходимые данные
	$purse		= $_REQUEST["s_purse"];		// sms:bank id		идентификатор смс:банка
	$order_id	 = $_REQUEST["s_order_id"];	 // operation id	   идентификатор операции
	$amount	   = $_REQUEST["s_amount"];	   // transaction sum	сумма транзакции
	$clear_amount = $_REQUEST["s_clear_amount"]; // billing algorithm  алгоритм подсчета стоимости
	$inv		  = $_REQUEST["s_inv"];		  // operation number   номер операции
	$phone		= $_REQUEST["s_phone"];		// phone number	   номер телефона
	$sign		 = $_REQUEST["s_sign_v2"];	  // signature		  подпись

	$res = get_data_row("SELECT * FROM {$CONFIG->dbprefix}smscoin_balance");

	$secret_code = $res->code;

	// making the reference signature
	// создаем эталонную подпись
	$reference = ref_sign($secret_code, $purse, $order_id, $amount, $clear_amount, $inv, $phone);
	// validating the signature
	// проверяем, верна ли подпись
	if($sign == $reference) {
		// success, proceeding
		// обрабатываем полученные данные
		//mail('your mail','new sms','-->'.print_r($_REQUEST,true).' -->'.http_build_query($_POST));
		update_data("UPDATE {$CONFIG->dbprefix}users_entity SET balance = balance+".($amount*$res->points)." WHERE guid = ".$order_id);
		echo "OK";
	} else {
		// failure, reporting error
		// неправильно составлен запрос
		echo "Direct access not allowed";
	}

?>
