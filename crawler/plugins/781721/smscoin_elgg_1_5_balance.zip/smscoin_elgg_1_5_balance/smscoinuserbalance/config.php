<?php
	/**
	 * @package ElggPages
	 * @author smscoin.com
	 * @copyright smscoin.com 2009
	 * @link http://smscoin.com/
	 */

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	global $CONFIG;

	// Get the current page's owner
	$page_owner = page_owner_entity();
	if ($page_owner === false || is_null($page_owner)) {
		$page_owner = $_SESSION['user'];
		set_page_owner($_SESSION['guid']);
	}
	#Get variables
	$bank_id = intval(get_input("bank_id"));
	$lang = addslashes(get_input("lang"));
	$code = addslashes(get_input("code"));
	$description = addslashes(get_input("description"));
	$points = floatval(get_input("points"));
	$save = get_input("save");
	$drop = get_input("drop");
	$tariffs = get_input("tariffs");

	$title = "SmsCoin Balance Config";

	$res = get_data_row("SHOW TABLES LIKE '{$CONFIG->dbprefix}smscoin_balance'");
	#Do action
	if(!$res) {
		# Create tables
		update_data("CREATE TABLE IF NOT EXISTS {$CONFIG->dbprefix}smscoin_balance (
			bank_id int,
			language varchar(32),
			code varchar(255),
			cron_time int default 0,
			points float unsigned default 100,
			description varchar(255),
			PRIMARY KEY (bank_id)
			)
		");
		update_data("INSERT IGNORE INTO {$CONFIG->dbprefix}smscoin_balance (bank_id, language, code, cron_time, points, description)
			VALUES (3849,'russian','1234', 0, 100, 'Buy Points')
		");
		update_data("ALTER IGNORE TABLE {$CONFIG->dbprefix}users_entity ADD COLUMN balance FLOAT DEFAULT 0");
	}
	if($save == 'Save') {
		# Update settings
		update_data("UPDATE {$CONFIG->dbprefix}smscoin_balance SET
			bank_id = ".$bank_id.",
			language = '".$lang."',
			code = '".$code."',
			points = ".$points.",
			description = '".$description."'
		");
		$info = "Saved";
	}
	$res = get_data_row("SELECT * FROM {$CONFIG->dbprefix}smscoin_balance");
	if($drop == 'Drop Tables') {
		# Drop tables
		update_data("DROP TABLE {$CONFIG->dbprefix}smscoin_balance");
		update_data("ALTER IGNORE TABLE {$CONFIG->dbprefix}users_entity DROP COLUMN balance");
		$info = "Droped";
	}
	# Upload tariffs
	if($tariffs == 'Upload Tariffs') {
		$info = run_sms_cron($res);
	}
	// Get objects
	$objects = "
		<div align = 'center' class = 'post_to_wire'>
			<h3>$info</h3>
			<form action = '' method = 'post'>
				<table>
					<tr>
						<td>
							<p>".elgg_echo('SMSCOIN_BANK_ID').":</p>
						</td>
						<td>
							<input type = 'text' value = '$res->bank_id' name = 'bank_id' />

						</td>
					</tr>
					<tr>
						<td>
							<p>".elgg_echo('SMSCOIN_LANGUAGE').":</p>
						</td>
						<td>
							<select name = 'lang'>
								<option value = 'russian' ".($res->language == 'russian'?'selected':'').">russian</option>
								<option value = 'english' ".($res->language == 'english'?'selected':'').">english</option>
							</select>

						</td>
					</tr>
					<tr>
						<td>
							<p>".elgg_echo('SMSCOIN_CODE').":</p>
						</td>
						<td>
							<input type = 'text' value = '$res->code' name = 'code' />

						</td>
					</tr>
					<tr>
						<td>
							<p>".elgg_echo('SMSCOIN_POINTS').":</p>
						</td>
						<td>
							<input type = 'text' value = '$res->points' name = 'points' />

						</td>
					</tr>
					<tr>
						<td>
							<p>".elgg_echo('SMSCOIN_DESCRIPTION').":</p>
						</td>
						<td>
							<input type = 'text' value = '$res->description' name = 'description' />

						</td>
					</tr>
					<tr>
						<td celspan = '2'>
							<input type = 'submit' value = 'Save' name = 'save' />&nbsp;&nbsp;&nbsp;<input type = 'submit' value = 'Upload Tariffs' name = 'tariffs' />&nbsp;&nbsp;&nbsp;<input type = 'submit' value = 'Drop Tables' name = 'drop' />
						</td>
					</tr>
				</table>
			</form>
		</div>
	";

	set_context($context);

	$body = elgg_view_title($title);
	$body .= $objects;
	$body = elgg_view_layout('two_column_left_sidebar','',$body);

	// Finally draw the page
	page_draw($title, $body);

	###
	#	Rate update
	#
	###
	function run_sms_cron($res) {
		global $CONFIG;
		$bank_id = $res->bank_id;
		$s_lang = $res->language;
		@ini_set('user_agent', 'smscoin_key_cron');
		$cron_info = "<br />";
		if(is_numeric($bank_id) && $bank_id != 0) {
			$response = file_get_contents("http://bank.smscoin.com/language/$s_lang/json/bank/".$bank_id."/");
			if(preg_match('|(JSONResponse = \[.*\])|is', $response, $feed) > 0) {
				if ($response !== false) {
					$filename = dirname(__FILE__).'/lib/local.js';
					if (($hnd = @fopen($filename, 'w')) !== false) {
						if (@fwrite($hnd, $response) !== false) {
							# Rate scale is updated
							$cron_info .= ('Success, file local.js updated @ '.date("r"));
							update_data("UPDATE {$CONFIG->dbprefix}smscoin_balance SET cron_time = ".time());
						} else {
							$cron_info .= ('File local.js not writable');
						}
						fclose($hnd);
					} else {
						$cron_info .= ('Could not open file local.js');
					}
				} else {
					$cron_info .= ('Unable to connect to remote server');
				}
			}
		}
		return $cron_info;
	}

?>
