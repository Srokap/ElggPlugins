<?php
	/**
	 * @package ElggPages
	 * @author smscoin.com
	 * @copyright smscoin.com 2009
	 * @link http://smscoin.com/
	 */

	function smscoinuserbalance_init() {
		global $CONFIG;
		if (isloggedin()) {
			add_menu(elgg_echo('SmsCoin Balance'), $CONFIG->wwwroot."mod/smscoinuserbalance/buypoints.php");
		}
		if (isloggedin() && get_context() == "smscoinuserbalance") {
			add_submenu_item(elgg_echo('SMSCOIN_BUY_CREDITS'),$CONFIG->wwwroot."mod/smscoinuserbalance/buypoints.php");
		}
		if (isadminloggedin() && get_context() == "smscoinuserbalance") {
			add_submenu_item(elgg_echo('Balance Config'),$CONFIG->wwwroot."mod/smscoinuserbalance/config.php");
		}
	}

	// Initialise
	register_elgg_event_handler('init','system','smscoinuserbalance_init');

?>
