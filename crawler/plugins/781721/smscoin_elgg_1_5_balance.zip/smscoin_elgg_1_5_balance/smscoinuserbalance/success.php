<?php
	/**
	 * @package ElggPages
	 * @author smscoin.com
	 * @copyright smscoin.com 2009
	 * @link http://smscoin.com/
	 */

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	global $CONFIG;

	// Get the current page's owner
	$page_owner = page_owner_entity();
	if ($page_owner === false || is_null($page_owner)) {
		$page_owner = $_SESSION['user'];
		set_page_owner($_SESSION['guid']);
	}


	$title = "SmsCoin Balance Success";

	set_context($context);

	$body = elgg_view_title($title);
	$body .= "<div class = 'post_to_wire'>".elgg_echo('SMSCOIN_SUCCESSFUL')."!</div>";
	$body = elgg_view_layout('two_column_left_sidebar','',$body);

	// Finally draw the page
	page_draw($title, $body);

?>
