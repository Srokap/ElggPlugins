<?php
    /**
     * @package ElggPages
     * @author smscoin.com
     * @copyright smscoin.com 2009
     * @link http://smscoin.com/
     */

    $english = array(
    
        "SMSCOIN_BANK_ID" => "Bank ID",
        "SMSCOIN_LANGUAGE" => "Language",
        "SMSCOIN_CODE" => "Passwod",
        "SMSCOIN_POINTS" => "Credits per 0.1 dollar",
        "SMSCOIN_DESCRIPTION" => "Description",
        "SMSCOIN_BUY_CREDITS" => "Buy Credits",

        'SMSCOIN_ACCOUNT_BALANCE' => 'Your balance',
        'SMSCOIN_CREDITS' => 'Credits',
        'SMSCOIN_REFOUND_BALANCE' => 'ДSend SMS to buy credits',
        'SMSCOIN_AFTER_ACTION' => 'Click the button than',
        'SMSCOIN_NEXT_STEP' => 'you will continue to payment gateway',
        'SMSCOIN_PAY' => 'Continue',
        'SMSCOIN_SELECT_COUNTRY' => 'Choose country',
        'SMSCOIN_SELECT_PROVIDER' => 'Choose mobile carrier',
        'SMSCOIN_SMS_PRICE' => 'Choose amount',
        'SMSCOIN_TRANSACTION_ERROR' => 'Error.',
        'SMSCOIN_SUCCESSFUL' => 'Successful',

    );
                    
    add_translation("en",$english);
?>
