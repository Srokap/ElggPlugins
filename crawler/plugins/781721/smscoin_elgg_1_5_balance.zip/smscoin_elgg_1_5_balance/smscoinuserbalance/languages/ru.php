<?php
    /**
     * @package ElggPages
     * @author smscoin.com
     * @copyright smscoin.com 2009
     * @link http://smscoin.com/
     */

    $russian = array(
    
        "SMSCOIN_BANK_ID" => "ID смс: банка",
        "SMSCOIN_LANGUAGE" => "Язык",
        "SMSCOIN_CODE" => "Пароль",
        "SMSCOIN_POINTS" => "Курс -кредитов за 0.1 доллар",
        "SMSCOIN_DESCRIPTION" => "Покупка кредитов за смс.",
        "SMSCOIN_BUY_CREDITS" => "Покупка кредитов",
        
        'SMSCOIN_ACCOUNT_BALANCE' => 'На вашем счету',
        'SMSCOIN_CREDITS' => 'Кредитов',
        'SMSCOIN_REFOUND_BALANCE' => 'Для пополнения баланса отправьте смс',
        'SMSCOIN_AFTER_ACTION' => 'После нажатия на кнопку',
        'SMSCOIN_NEXT_STEP' => 'вы перейдете на шлюз оплаты.',
        'SMSCOIN_PAY' => 'Оплатить',
        'SMSCOIN_SELECT_COUNTRY' => 'Выберите страну',
        'SMSCOIN_SELECT_PROVIDER' => 'Выберите оператора',
        'SMSCOIN_SMS_PRICE' => 'Стоимость сообщения',
        'SMSCOIN_TRANSACTION_ERROR' => 'Ошибка транзакции.',
		'SMSCOIN_SUCCESSFUL' => 'Транзакция прошла успешно',
 
    );
                    
    add_translation("ru",$russian);
?>
