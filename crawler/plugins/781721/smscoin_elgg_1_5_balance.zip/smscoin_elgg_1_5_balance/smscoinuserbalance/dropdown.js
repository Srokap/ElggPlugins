first_countries = Array('RU','IL','UA'); // Country (two-letter code) will be the first on the list

function show(node) {
    node.style.display = '';
    return node;
}

function hide(node) {
    node.style.display = 'none';
    return node;
}

function update(node, text) {
    node.appendChild(document.createTextNode(text));
    return node;
}

function clear(node) {
    while (node.hasChildNodes()) {
        node.removeChild(node.firstChild);
    }
    return node;
}

function get(id) { return document.getElementById(id) }

function showget(id) { return show(get(id)) }

function hideget(id) { return hide(get(id)) }

function updateget(id, text) { return update(get(id), text) }

function clearget(id) { return clear(get(id)) }

function selectCost(cost){
    document.getElementById('s_amount').value = cost-0.01;
    if(cost)showget('sub');
    else hideget('sub');
}
function updateInstructions(json,data) {
    showget('instructions');
    show(clearget('select_cost'));
    hideget('sub');
    var select_cost = clearget('select_cost');
    var def = document.createElement('option');
    update(def, SELECT_AMOUNT+':').value = '-';
    select_cost.appendChild(def);
    for(var i=0;i<json.length;++i){
        if(json[i].country_name == data.country_name && json[i].name == data.name){
            var opt = document.createElement('option');
            update(opt, json[i].price +" "+ json[i].currency +" "+(parseInt(json[i].vat)? '(including VAT)': '(excluding VAT)')+" => "+Math.floor(json[i].usd*POINTS)+" "+CREDITS).value = i;
            select_cost.appendChild(opt);
            if (json[i].special) show(update(clearget('notes'), json[i].special));
            else hide(clearget('notes'));
        }
    }
    select_cost.onchange = function() {
        var cost = this.value == '-'?0:json[this.value].usd;
        selectCost(cost);
    }
}

function selectProvider(i,DATA) {
    if (i == '-') {
        hideget('instructions');
        return;
    }
    hideget('sub');
    updateInstructions(DATA.providers,DATA.providers[i]);
}

function selectCountry(i) {
    if (i == '-') {
        hideget('providers');
        hideget('instructions');
        hideget('sub');
        return;
    }
    if (JSONResponse[i].providers && JSONResponse[i].providers.length) {
        hideget('instructions');
        hideget('sub');
        showget('providers');
        DATA = JSONResponse[i];
        var select_provider = clearget('select_provider');
        var def = document.createElement('option');
        update(def, 'Choose operator').value = '-';
        var oldprovider='';
        select_provider.appendChild(def);
        for (var j = 0; j < DATA.providers.length; ++j) {
            var opt = document.createElement('option');
            update(opt, DATA.providers[j].name).value = j;
            if(oldprovider != DATA.providers[j].name)
                select_provider.appendChild(opt);
            oldprovider = DATA.providers[j].name;
        }
        select_provider.onchange = function() {
            selectProvider(this.value,DATA);
        }
    }
    else {
        hideget('providers');
        hideget('sub');
        updateInstructions(JSONResponse,JSONResponse[i]);
    }
}

function JSONHandleResponse() {
    var n = 0;
    //document.body.style.backgroundImage = 'none';
    if (!window.JSONResponse) {
        showget('fail');
        return;
    }
    for (var i = 0; i < JSONResponse.length; i++) {
        for(var c= 0 ; c < first_countries.length; c++)
            if(JSONResponse[i].country == first_countries[c]) n++;
    }
    for (var i = 0; i < (JSONResponse.length-1); i++) {
        for (var j = (i+1); j < JSONResponse.length; j++) {
            for(var c = first_countries.length-1; c >= 0; c--) {
                if(JSONResponse[j].country == first_countries[c]){
                    var temp = JSONResponse[i];
                    JSONResponse[i] = JSONResponse[j];
                    JSONResponse[j] = temp;
                }
            }
        }
    }
    for (var i = n; i < (JSONResponse.length-1); i++) {
        for (var j = (i+1); j < JSONResponse.length; j++) {
            if (JSONResponse[i].country_name > JSONResponse[j].country_name){
                var temp = JSONResponse[i];
                JSONResponse[i] = JSONResponse[j];
                JSONResponse[j] = temp;
            }
        }
    }
    showget('ui');
    var select_country = get('select_country');
    var oldcountry='';
    for (var i = 0; i < JSONResponse.length; ++i) {
            var opt = document.createElement('option');
            update(opt, JSONResponse[i].country_name).value = i;
        if(oldcountry != JSONResponse[i].country_name)
            select_country.appendChild(opt);
        oldcountry = JSONResponse[i].country_name; 
    }
    select_country.onchange = function() {
        selectCountry(this.value);
    }
}

function JSONSendRequest() {
    var head_node = document.getElementsByTagName('head').item(0);
    var js_node = document.createElement('script');
    js_node.src = JSON_URL;
    js_node.type = 'text/javascript';
    js_node.charset = 'utf-8';
    if (navigator.product == 'Gecko' || navigator.userAgent.indexOf('Opera') != -1) {
        js_node.onload = JSONHandleResponse;
    }
    else {
        js_node.onreadystatechange = function(evt) {
            evt? 1: evt = window.event;
            var rs = (evt.target || evt.srcElement).readyState;
            if (rs == 'loaded' || rs == 'complete') {
                JSONHandleResponse();
            }
        }
    }
    head_node.appendChild(js_node);
}

if (window.addEventListener) {
    window.addEventListener('load', JSONSendRequest, false);
}
else if (window.attachEvent) {
    window.attachEvent('onload', JSONSendRequest);
}
