<?php

	$english = array(

		/**
		 * Menu items and titles
		 */

			'thewire' => "Posts",
			'thewire:user' => "%s's Posts",
			'thewire:posttitle' => "%s's notes on the Posts: %s",
			'thewire:everyone' => "All Posts",
			'thewire:friends:title' => "%s's Buddies on the Posts",
			'thewire:friends' => "Buddies' Posts",

			'thewire:yours' => "Your Posts",
			'thewire:theirs' => "%s's Posts",

			'thewire:strapline' => "%s",

			'thewire:add' => "Post",
			'thewire:text' => "A note on the Posts",
			'thewire:reply' => "Reply",
			'thewire:via_method' => "via %s",
			'thewire:wired' => "Posted",
			'thewire:charleft' => "characters left",
			'item:object:thewire' => "Posts",
			'thewire:notedeleted' => "note deleted",
			'thewire:doing' => "What are you doing? Tell everyone:",
			'thewire:newpost' => 'New Post',
			'thewire:addpost' => 'Post',
			'thewire:by' => "Posted by %s",
			'thewire:update' => 'update',


		/**
		 * The wire river
		 **/

			//generic terms to use
			'thewire:river:created' => "%s posted",

			//these get inserted into the river links to take the user to the entity
			'thewire:river:create' => "on the Posts.",

		/**
		 * Wire widget
		 **/

			'thewire:sitedesc' => 'This widget shows the latest site notes posted',
			'thewire:yourdesc' => 'This widget displays your latest Posts',
			'thewire:friendsdesc' => 'This widget will show the latest from your Buddies on the Posts',
			'thewire:num' => 'Number of items to display',
			'thewire:moreposts' => 'More Posts',


		/**
		 * Status messages
		 */

			'thewire:posted' => "Your message was successfully posted.",
			'thewire:deleted' => "Your post was successfully deleted.",

		/**
		 * Error messages
		 */

			'thewire:blank' => "Sorry; you need to actually put something in the textbox before we can save it.",
			'thewire:notfound' => "Sorry; we could not find the specified Post.",
			'thewire:notdeleted' => "Sorry; we could not delete this post.",


		/**
		 * Settings
		 */
			'thewire:smsnumber' => "Your SMS number if different from your mobile number (mobile number must be set to public for the Posts to be able to use it). All phone numbers must be in international format.",
			'thewire:channelsms' => "The number to send SMS messages to is <b>%s</b>",

		// twitter
			'thewire:twitterservice:desc' => 'Tweets all posts made.',

	);

	add_translation("en",$english);

?>
