<?php	

/*
** Rename the wire to Posts
**
** @author Zenin Easa
** @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
**
*/

function rename-wire_init()
{
	global $CONFIG;
			
	register_translations($CONFIG->pluginspath . "rename-wire/languages/");
}

// Initialise this plugin
register_elgg_event_handler('init','system','rename-wire_init');

?>
