<?php

	/**
	 * Rounded Icon Profile.
	 * 
	 * @package roundedprofile
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Pedro Prez
	 * @copyright 2009
	 * @link http://www.pedroprez.com.ar/
 	 
	 * @uses $vars['entity'] The user entity. If none specified, the current user is assumed.
	 * @uses $vars['size'] The size - small, medium or large. If none specified, medium is assumed. 
	 */

	$group = $vars['entity'];
	
	if ($group instanceof ElggGroup) {
	
	// Get size
	if (!in_array($vars['size'],array('small','medium','large','tiny','master','topbar')))
		$vars['size'] = "medium";
			
	// Get any align and js
	if (!empty($vars['align'])) {
		$align = " align=\"{$vars['align']}\" ";
	} else {
		$align = "";
	}
	
	if ($icontime = $vars['entity']->icontime) {
		$icontime = "{$icontime}";
	} else {
		$icontime = "default";
	}
	
	$rand_number = rand(1,99999);  
	$img_id = "{$size}{$rand_number}";
	switch($vars['size'])
	{
		 
		case 'topbar':
			$radio = '2';
			break;
		case 'tiny':
			$radio = '5';
			break;
		case 'small':
			$radio = '7';
			break;
		case 'medium':
			$radio = '12';
			break;
		default: 
			$radio = '6';
	}
	
	
?>

<div class="groupicon">
<a href="<?php echo $vars['entity']->getURL(); ?>" class="icon" ><img id='<?php echo $img_id?>' src="<?php echo $vars['entity']->getIcon($vars['size']); ?>" border="0" <?php echo $align; ?> title="<?php echo $name; ?>" <?php echo $vars['js']; ?> /></a>
</div>

<script type="text/javascript">
	img_<?php echo $img_id ?> = document.getElementById('<?php echo $img_id ?>');
	setTimeout("cvi_corners.add(img_<?php echo $img_id ?>, {xradius: <?php echo $radio ?>})",1000);
</script>

<?php

	}

?>

