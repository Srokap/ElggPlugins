<?php

?>

#elgg_topbar_container_left .user_mini_avatar {
	/*border:none;*/
}