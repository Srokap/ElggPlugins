<?php
	
	/**
	 * Rounded Icon Profile.
	 *
	 * @package roundedprofile
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Pedro Prez
	 * @copyright 2009
	 * @link http://www.pedroprez.com.ar/
 	*/
?>
	<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/roundedprofile/vendors/corner/cvi_corners_lib.js"></script>
	
	<script type="text/javascript">
		jQuery(document).ready(function(){
		
			if(jQuery('img[src*=icondirect.php]').length>0 || jQuery('img[src*=defaultlarge]').length>0)
			{
				<?php
					if(isset($vars['config']->roundedprofile)){
						
					 	$radius	= $vars['config']->roundedprofile->radius;
					 	
					 	$radius_str = '{'; 
					 	foreach($radius as $radio_size => $radio)
					 	{
					 		$radius_str .= "'$radio_size':'$radio',";	
					 	}
					 	$radius_str = substr($radius_str,0,strlen($radius_str)-1) . '}';
					}
				?>
				aRadius = <?php echo $radius_str ?>;
			
			}
			
			setInterval("roundedImages()",500);
			
		
		})
		
		
		function roundedImages(){
			jQuery('img[src*=icondirect.php]').each(function(){
				roundedImage(jQuery(this)[0]);
			});
			
			jQuery('img[src*=defaultlarge]').each(function(){
				roundedImage(jQuery(this)[0]);
			});
		}
		
		function roundedImage(oImg){
				<?php
					 $randon_number = rand(1,9999);
				?>
					src = oImg.src;
				 	size = src.match(/size=([\w]+)/);
				 	if(!size)
				 	{
				 		size = 'small';
					 	radius = 6;
				 	}else
				 	{
				 		radius = aRadius[size[1]];
				 	}
				 	
				 	<?php
				 
				 ?>
				img_<?php echo $randon_number ?> = oImg;
				setTimeout("setRounded(img_<?php echo $randon_number ?>," + radius + ")",1000);
		}
		
		
		function setRounded(oId, iRadius){
		
			//cvi_corners.add(oId,{'xradius': iRadius});
			cvi_corners.add(oId,{'xradius': 8});
			
		}
		
	</script>
