<?php

	/**
	 * Rounded Icon Profile.
	 * 
	 * @package roundedprofile
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Pedro Prez
	 * @copyright 2009
	 * @link http://www.pedroprez.com.ar/
 	*/
	
	function profilerounded_init()
	{
		global $CONFIG;
		extend_view('metatags','roundedprofile/javascript');
		
		if(!isset($CONFIG->roundedprofile)){
			$CONFIG->roundedprofile->radius = array("topbar" => "2",
													"tiny" 	 => "5",
													"small"  => "7",
													"medium" => "12",
													"large"  => "6",
													"master" => "6");
		}
		
		//** VIEWS	
		// Extend CSS
		    extend_view('css','roundedprofile/css');
		
	}
	
	//**BEGIN
	register_elgg_event_handler('init','system','profilerounded_init');
?>
