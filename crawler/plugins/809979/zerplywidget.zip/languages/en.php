<?php

        $english = array(
               
        'zerplywidget:title' => "Endorse me - Zerply",
		'zerplywidget:description' => "Add the Zerply's widget and profile",
        'zerplywidget:key_1' => "Insert the ",
        'zerplywidget:key_2' => " key",
        'zerplywidget:user' => "Insert your Zerply username",
        'zerplywidget:profile' => "Show Zerply user's profile",
        'zerplywidget:no_key' => "Insert your Zerply info and refresh the browser",

        );
          
        add_translation("en",$english);

?>
