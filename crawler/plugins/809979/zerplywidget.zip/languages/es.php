<?php

        $spanish = array(
               
        'zerplywidget:title' => "Aválame - Zerply",
		'zerplywidget:description' => "Agrega el widget y perfil de Zerply",
        'zerplywidget:key_1' => "Inserta el key del",
        'zerplywidget:key_2' => "",
        'zerplywidget:user' => "Inserta tu nombre de usuario de Zerply",
        'zerplywidget:profile' => "Mostrar el perfil del usuario de Zerply",
        'zerplywidget:no_key' => "Inserta tu informaci&oacute;n de Zerply y recarga el navegador",

        );
          
        add_translation("es",$spanish);

?>
