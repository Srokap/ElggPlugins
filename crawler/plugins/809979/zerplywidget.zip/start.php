<?php

/**************************************************

Author: Randy Brito
http://randybrito.com
Donations: donate@randybrito.com

***************************************************/

function zerplywidget_init() {
    
//add a widget
add_widget_type('zerplywidget',elgg_echo("zerplywidget:title"),elgg_echo("zerplywidget:description"));
        
}

register_elgg_event_handler('init','system','zerplywidget_init');

?>
