<?php

$zerply_key = $vars['entity']->zerplykey;
$zerply_user = $vars['entity']->zerplyuser;
$zerply_profile = $vars['entity']->zerplyprofile;


if (!isset($zerply_key)) {
	
	echo elgg_echo('zerplywidget:no_key');

} else {
	
	if (!isset($zerply_user)) {
?>	
		<script type="text/javascript" src="http://get.zerply.com/js/widget/remote.js"></script>
		<script type="text/javascript">
			widget = new zerplyTC({container: 'ZE-widget', key: '<?php echo $zerply_key;?>', width: '289'}); widget.init();
		</script>
		<div id="ZE-widget"></div>
	<?php	
	} else { 
	
		if ($zerply_profile == Yes) {
	?>
		<script type="text/javascript" src="http://get.zerply.com/js/widget/remote.js"></script>
		<script type="text/javascript">
			widget = new zerplyTC({container: 'ZE-widget', key: '<?php echo $zerply_key;?>', width: '289'}); widget.init();
		</script>
		<div id="ZE-widget"></div>
		<div id="zerplyprofile" style="padding:3px; padding-bottom:0px; background:#E3E3E3 url(http://f.cl.ly/items/2h0j3b1A3N2h460Y1C1l/main_bg.gif) top left repeat; -webkit-border-radius:5px; -moz-border-radius:5px; border-radius:5px;">
			<iframe src="http://m.zerply.com/<?php echo $zerply_user;?>" width="100%" height="300px" frameborder="0" style="padding:0px;">
				<p>Your browser does not support iframes.</p>
			</iframe>
		</div>
		<?php
		} else {
		?>
		<script type="text/javascript" src="http://get.zerply.com/js/widget/remote.js"></script>
		<script type="text/javascript">
			widget = new zerplyTC({container: 'ZE-widget', key: '<?php echo $zerply_key;?>', width: '289'}); widget.init();
		</script>
		<div id="ZE-widget"></div>
	<?php
			}
		}
	}
	?>