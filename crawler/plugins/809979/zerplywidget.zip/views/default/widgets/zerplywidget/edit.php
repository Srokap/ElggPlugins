<?php

if (!isset($vars['entity']->zerplyprofile)) {
	$vars['entity']->zerplyprofile = Yes;
}

$params = array(
	'name' => 'params[zerplyprofile]',
	'value' => $vars['entity']->zerplyprofile,
	'options' => array(Yes, No),
);
$dropdown = elgg_view('input/dropdown', $params);

?>

<p>
	<?php echo elgg_echo("zerplywidget:key_1"); ?>
	<a href="http://www.zerply.com/widget/" title="Zerply | Web Resources" target="_blank">Zerply's Widget</a>
	<?php echo elgg_echo("zerplywidget:key_2"); ?>
    <input type="text" name="params[zerplykey]" value="<?php echo htmlentities($vars['entity']->zerplykey); ?>" />	
</p>
<p>
	<?php echo elgg_echo('zerplywidget:user'); ?>
	<input type="text" name="params[zerplyuser]" value="<?php echo htmlentities($vars['entity']->zerplyuser); ?>" />
</p>
<p>	
	<?php echo elgg_echo('zerplywidget:profile'); ?>:
	<?php echo $dropdown; ?>
</p>