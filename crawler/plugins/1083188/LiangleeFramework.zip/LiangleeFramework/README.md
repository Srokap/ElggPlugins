LiangLeeFramework is part of the LiangLee plugins

See Documentation for intergation.