LiangLeeFramework 1.1.3

(August 26, 2012 from https://github.com/lianglee/LiangLeeFramework/tree/1.1.3)

 Bugfixes:

 * Fixed return value in LiangLee_inc_img() Ticket #7

 * Fixed return value in LiangLee_inc_js() Ticket #9

 * Fixed return value in  LiangLee_inc_css() Ticket #8


 Enhancements:

 * Added LiangLee_server() (by John Muller ) Ticket #5

 * Added LiangLee_putconents() (by Liang Lee ) Ticket #12

 * Added LiangLee_plugin_path() (by John Muller ) Ticket #10

 * Added LiangLee_apache() (by John Muller ) Ticket #13

 * Added LiangLee_apache() (by John Muller ) Ticket #14

 * Added LiangLee_time() (by John Muller ) Ticket #15

 * Added Depracted File (by Liang Lee ) Ticket #16
