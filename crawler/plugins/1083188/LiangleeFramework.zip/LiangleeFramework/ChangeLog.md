LiangLeeFramework 1.1.2
(July 11, 2012 from https://github.com/lianglee/LiangLeeFramework/tree/1.1.2)

 Bugfixes:
 * Security bug fixed which cause log problem. Ticket #1
 * Fixed Lianglee_include function. Ticket #2
 * Added error and error code translations.
 * ChangeLog.md is missing added thanks to John Muller, Ticket #4
 * Fix 'lianglee:err' Translation   Ticket #3

 Enhancements:
 * Added a John Muller as Contributor
 


LiangLeeFramework 1.1.1
* Upgrade Changes.md
* Change Mainfest.xml
* Added Dynmaic Method for Adding Version.
* Added Dynamic Method for Addmin Release.
* Changed LiangLee_inc_js.
* Changed LiangLee_img.
* Changed LiangLee_inc_css.
* Register Error if js,css,img not found to admins and in codes to Users.
