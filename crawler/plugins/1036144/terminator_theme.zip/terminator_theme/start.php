<?php
function terminator_theme_init() {
	elgg_extend_view ('page/elements/head','terminator_theme/meta');
	elgg_unregister_menu_item('topbar', 'elgg_logo');
}
elgg_register_event_handler('init', 'system', 'terminator_theme_init');
?>