Upgrade from cool_theme 1.0 :
-------------

1. Deactivate your cool_theme version
2. Delete it from your server
3. Upload this version to your mod/ directory
4. Activate cool_theme...
Easy :-)