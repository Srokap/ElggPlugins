<?php
/**
 * User statitsics
 *
 * Blank view that can be extended
 */
