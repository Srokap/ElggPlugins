<?php
/**
 * Account settings form wrapper
 * 
 * @package Elgg
 * @subpackage Core
 */

echo elgg_view_form('usersettings/save', array('class' => 'elgg-form-alt'));