<?php
// @deprecated Use input/date instead.

elgg_deprecated_notice('view: input/calendar is deprecated by input/date', 1.8);

echo elgg_view('input/datepicker', $vars);