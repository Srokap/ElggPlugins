<?php
	if($vars['entity'] && (page_owner() == get_loggedin_userid())){
		global $CONFIG;


			$url = elgg_add_action_tokens_to_url($CONFIG->wwwroot . 'action/deleteMe');
			$url = str_replace('&amp;','&', $url);
	 		$result = "
	 			<script type='text/javascript'>
	 				function deleteMe(user){
	 					if(confirm('" . elgg_echo("deleteme:confirm"). "')){
	 						var url = '" . $url . "';
	 						document.location.href = url + '&user=' + user;
	 					}
	 				}
	 			</script>
	 			";

	 		$result .= '<input type="button" class="submit_button" value="' . elgg_echo("deleteme") . '" onclick="deleteMe('.page_owner().');">';

		echo "<div class='contentWrapper'>";
		echo $result;
		echo "</div>";
	}
?>