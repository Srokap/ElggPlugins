<?php

	function deleteMe_init(){
		extend_view("profile/edit", "deleteMe/deleteMe");
	}


	// Default event handlers for plugin functionality
	register_elgg_event_handler('init', 'system', 'deleteMe_init');

	// actions
	register_action('deleteMe', false, $CONFIG->pluginspath . 'deleteMe/actions/deleteMe.php');
?>
