<?php
	// Load configuration
	global $CONFIG;
	gatekeeper();
	$obj = get_entity(get_loggedin_userid());
	if ( ($obj instanceof ElggUser) && ($obj->canEdit()) && (get_input('user') == get_loggedin_userid()))
	{
		if ($obj->delete()) {
			system_message(elgg_echo('admin:user:delete:yes'));

			$_SESSION = array();
			if (isset($_COOKIE["sessid"])) {
		    	setcookie("sessid", '', time()-42000, '/');
			}
			@session_destroy();
		} else {
			register_error(elgg_echo('admin:user:delete:no'));
		}
	} else {
		register_error(elgg_echo('admin:user:delete:no'));
	}

	forward($_SERVER['HTTP_REFERER']);
	exit;
?>

