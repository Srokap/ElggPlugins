<?php
	$english = array(
		'deleteme' => 'Remove my profile from system',
		'deleteme:confirm' => 'Do you REALLY want to remove your profile from system?',
		'deleteme:adminuser' => 'Please enter the username of an admin, created only for such administrative tasks.'
	);

	add_translation("en",$english);
?>