<?php
	$german = array(
		'deleteme' => 'Mein Profil aus dem System löschen',
		'deleteme:confirm' => 'Möchtest du WIRKLICH dein Profil aus dem System löschen?',
		'deleteme:adminuser' => 'Bitte gib den Usernamen eines Admins ein. Dieser sollte ausschließlich für adminitstrative Aufgaben angelegt werden.'
	);

	add_translation("de",$german);
?>