<?php
	/**
	 * Kneemail
	 * 
	 * @package kneemail
	 * @license The BSD License
	 * @author Greg Marine
	 * @copyright Greg Marine 2011
	 * @link http://www.iccnet.org/
	 */

	// Load configuration
	global $CONFIG;
	
	gatekeeper();
	set_context('kneemail');

	// Get group fields
	$input = array();
	foreach($CONFIG->kneemail as $shortname => $valuetype)
	{
		$input[$shortname] = get_input($shortname);
		if ($valuetype == 'tags')
			$input[$shortname] = string_to_tag_array($input[$shortname]);
	}
	
	// New or old?
	$page = NULL;
	$kneemail_guid = (int)get_input('kneemail_guid');
	if ($kneemail_guid)
	{
		$page = get_entity($kneemail_guid);
		if (!$page->canEdit())
			$page = NULL; // if we can't edit it, go no further.
	}
	else
	{
		$page = new ElggObject();
		$page->subtype = 'kneemail';
			
		// New instance, so set container_guid
		$container_guid = get_input('container_guid', $_SESSION['user']->getGUID());
		$page->container_guid = $container_guid;
	}
	
	// Have we got it? Can we edit it?
	if ($page instanceof ElggObject)
	{
		// Yes we have, and yes we can.
		
		// Save fields - note we always save latest description as both description and annotation
		if (sizeof($input) > 0)
		{
			foreach($input as $shortname => $value)
			{
				if ((!$kneemail_guid) || (($kneemail_guid) && ($shortname != 'subject')))
					$page->$shortname = $value;
			}
		}

		// Validate create
		if (!$page->subject)
		{
			register_error(elgg_echo("kneemail:nosubject"));
			
			forward($_SERVER['HTTP_REFERER']);
			exit;
		}

		// Access ids
		$page->access_id = (int)get_input('access_id', ACCESS_PRIVATE);
		
		// Write access id
		$page->write_access_id = (int)get_input('write_access_id', ACCESS_PRIVATE);
		
		// Ensure ultimate owner
		$page->owner_guid = ($page->owner_guid ? $page->owner_guid : $_SESSION['user']->guid); 
		
		// finally save
		if ($page->save())
		{	
			system_message(elgg_echo("kneemail:saved"));
			
			// Forward to the user's profile
			forward($page->getUrl());
			exit;
		}
		else
			register_error(elgg_echo('kneemail:notsaved'));

	}
	else
	{
		register_error(elgg_echo("kneemail:noaccess"));
	}
	
	// Forward to the user's profile
	forward($page->getUrl());
	exit;
?>