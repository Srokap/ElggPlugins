<?php
	/**
	 * Kneemail
	 * 
	 * @package kneemail
	 * @license The BSD License
	 * @author Greg Marine
	 * @copyright Greg Marine 2011
	 * @link http://www.iccnet.org/
	 */

	$entry = get_input('kneemail');
	
	if ($entry = get_entity($entry))
	{
		if ($entry->canEdit())
		{
			if ($entry->delete())
			{
				system_message(elgg_echo('kneemail:delete:success'));
				forward('pg/kneemail/owned/' . $_SESSION['user']->username);
				exit;
			}
		}
		
	}
	
	register_error(elgg_echo('kneemail:delete:failure'));
	forward($_SERVER['HTTP_REFERER']);
?>