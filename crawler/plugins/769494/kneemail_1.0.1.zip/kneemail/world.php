<?php
	/**
	 * Kneemail
	 * 
	 * @package kneemail
	 * @license The BSD License
	 * @author Greg Marine
	 * @copyright Greg Marine 2011
	 * @link http://www.iccnet.org/
	 */

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	global $CONFIG;
	
	// Get the current page's owner
	$page_owner = page_owner_entity();
	if ($page_owner === false || is_null($page_owner))
	{
		$page_owner = $_SESSION['user'];
		set_page_owner($_SESSION['guid']);
	}
		
    if (($page_owner instanceof ElggEntity) && ($page_owner->canWriteToContainer($_SESSION['user'])))
	{
        add_submenu_item(elgg_echo('kneemail:new'), $CONFIG->url . "pg/kneemail/new/", 'kneemailactions');
    }
    
    if(isloggedin())
    	add_submenu_item(sprintf(elgg_echo("kneemail:user"), page_owner_entity()->name), $CONFIG->url . "pg/kneemail/owned/" . page_owner_entity()->username, 'kneemaillinksgeneral');
    
    add_submenu_item(elgg_echo('kneemail:all'),$CONFIG->wwwroot."mod/kneemail/world.php", 'kneemaillinksgeneral');
    
	$limit = get_input("limit", 10);
	$offset = get_input("offset", 0);
	
	$title = sprintf(elgg_echo("kneemail:all"),page_owner_entity()->name);
	

	// Get objects
	$context = get_context();
	
	set_context('search');
	
	$objects = list_entities("object", "kneemail", 0, $limit, false);
	
	set_context($context);
	
	$body = elgg_view_title($title);
	$body .= $objects;
	$body = elgg_view_layout('two_column_left_sidebar','',$body);
	
	// Finally draw the page
	page_draw($title, $body);
?>