<?php
	/**
	 * Kneemail
	 * 
	 * @package kneemail
	 * @license The BSD License
	 * @author Greg Marine
	 * @copyright Greg Marine 2011
	 * @link http://www.iccnet.org/
	 */

    switch($vars['entity']->entry_status)
    {
        case 0:
            echo $vars['url'] . "mod/kneemail/images/active_60x60.png";
            break;
        
        case 1:
            echo $vars['url'] . "mod/kneemail/images/answered_60x60.png";
            break;
        
        case 2:
            echo $vars['url'] . "mod/kneemail/images/inactive_60x60.png";
            break;
    }
?>