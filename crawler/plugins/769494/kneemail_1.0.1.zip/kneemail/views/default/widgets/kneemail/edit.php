<?php
	/**
	 * Kneemail
	 * 
	 * @package kneemail
	 * @license The BSD License
	 * @author Greg Marine
	 * @copyright Greg Marine 2011
	 * @link http://www.iccnet.org/
	 */
?>
<p>
	<?php echo elgg_echo("kneemail:num"); ?>
	<input type="text" name="params[kneemail_num]" value="<?php echo htmlentities($vars['entity']->kneemail_num); ?>" />	
</p>