<style type="text/css">
#kneemail_widget .pagination
{
    display:none;
}
</style>
<?php
	/**
	 * Kneemail
	 * 
	 * @package kneemail
	 * @license The BSD License
	 * @author Greg Marine
	 * @copyright Greg Marine 2011
	 * @link http://www.iccnet.org/
	 */

     $num_display = (int) $vars['entity']->kneemail_num;
     
     $kneemail = list_entities("object", "kneemail", page_owner(), $num_display, false);
	 $kneemailurl = $vars['url'] . "pg/kneemail/owned/" . page_owner_entity()->username;
     $kneemail .= "<div class=\"kneemail_widget_singleitem_more\"><a href=\"{$kneemailurl}\">" . elgg_echo('kneemail:more') . "</a></div>";
     
     echo "<div id=\"kneemail_widget\">" . $kneemail . "</div>";
?>