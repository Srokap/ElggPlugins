<?php
	/**
	 * Kneemail
	 * 
	 * @package kneemail
	 * @license The BSD License
	 * @author Greg Marine
	 * @copyright Greg Marine 2011
	 * @link http://www.iccnet.org/
	 */

	$container_guid = get_input('container_guid');
	if (!$container_guid) $container_guid = page_owner();
	
	$new_page = false;
	if (!$vars['entity']) {
		$new_page = true;
		
		// bootstrap the access permissions in the entity array so we can use defaults
		if (defined('ACCESS_DEFAULT')) {
			$vars['entity']->access_id = ACCESS_DEFAULT;
			$vars['entity']->write_access_id = ACCESS_DEFAULT;
		} else {
			$vars['entity']->access_id = 0;
			$vars['entity']->write_access_id = 0;
		}
	}
?>
<div class="contentWrapper">
<form action="<?php echo $vars['url']; ?>action/kneemail/new" method="post">

<?php

	if (is_array($vars['config']->kneemail) && sizeof($vars['config']->kneemail) > 0)
		foreach($vars['config']->kneemail as $shortname => $valtype)
		{
			
			$disabled = "";
			
			if (!$new_page && ($shortname == 'subject'))
			{
				$disabled = true;
			}
			
			if($shortname == 'entry_type')
			{
?>
	<p>
			<b><?php echo elgg_echo("kneemail:{$shortname}") ?></b><br />
			<?php echo elgg_view("input/{$valtype}",array(
															'internalname' => $shortname,
															'value' => $vars['entity']->$shortname,
															'options_values' => array('0'=>elgg_echo('kneemail:entry:type:prayer'), '1'=>elgg_echo('kneemail:entry:type:praise'), '2'=>elgg_echo('kneemail:entry:type:general'))
															)); ?>
	</p>
<?php
			}
			elseif($shortname == 'entry_status')
			{
?>
	<p>
			<b><?php echo elgg_echo("kneemail:{$shortname}") ?></b><br />
			<?php echo elgg_view("input/{$valtype}",array(
															'internalname' => $shortname,
															'value' => $vars['entity']->$shortname,
															'options_values' => array('0'=>elgg_echo('kneemail:entry:status:active'), '1'=>elgg_echo('kneemail:entry:status:answered'), '2'=>elgg_echo('kneemail:entry:status:inactive'))
															)); ?>
	</p>
<?php
			}
			else
			{
?>
	<p>
			<b><?php echo elgg_echo("kneemail:{$shortname}") ?></b><br />
			<?php echo elgg_view("input/{$valtype}",array(
															'internalname' => $shortname,
															'value' => $vars['entity']->$shortname,
															'disabled' => $disabled
															)); ?>
	</p>
<?php
			}
		}
		$cats = elgg_view('categories',$vars);
		if (!empty($cats)) {
			
?>
	<p>
		<?php 
			echo $cats;
		?>
	</p>
<?php
			
		}

?>
	<p>
		<?php
			if (!$new_page)
			{ 
				?><input type="hidden" name="kneemail_guid" value="<?php echo $vars['entity']->getGUID(); ?>" /><?php 
			}
		?>
		<?php
			if ($container_guid)
			{
				?><input type="hidden" name="container_guid" value="<?php echo $container_guid; ?>" /><?php 
			}
                        
                        echo elgg_view('input/securitytoken'); // Added for Elgg 1.7
		?>
		<input type="hidden" name="owner_guid" value="<?php if (!$new_page) echo $vars['entity']->owner_guid; else echo page_owner(); ?>" />
		<input type="submit" class="submit_button" value="<?php echo elgg_echo("save"); ?>" />
	</p>

</form>
</div>