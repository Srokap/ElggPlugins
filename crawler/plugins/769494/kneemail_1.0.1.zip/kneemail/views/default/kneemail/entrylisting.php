<?php
	/**
	 * Kneemail
	 * 
	 * @package kneemail
	 * @license The BSD License
	 * @author Greg Marine
	 * @copyright Greg Marine 2011
	 * @link http://www.iccnet.org/
	 */

	$icon = elgg_view(
			"graphics/icon", array(
			'entity' => $vars['entity'],
			'size' => 'small',
		  )
		);

	$owner_guid = $vars['entity']->owner_guid;
	$owner = get_entity($owner_guid);
	$time_updated = $vars['entity']->time_updated;
	
	$info .= "<p><b><a href=\"" . $vars['entity']->getUrl() . "\">" . $vars['entity']->subject . "</a></b></p>";

	$info .= "<p class=\"owner_timestamp\">".sprintf(elgg_echo("kneemail:strapline"),
					friendly_time($time_updated),
					"<a href=\"" . $owner->getURL() . "\">" . $owner->name ."</a>"
	) . "</p>";

	
	echo elgg_view_listing($icon, $info);
?>