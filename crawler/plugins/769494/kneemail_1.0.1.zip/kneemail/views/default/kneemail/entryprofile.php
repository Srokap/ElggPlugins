<?php
	/**
	 * Kneemail
	 * 
	 * @package kneemail
	 * @license The BSD License
	 * @author Greg Marine
	 * @copyright Greg Marine 2011
	 * @link http://www.iccnet.org/
	 */

	// Output body
	$entity = $vars['entity'];
	
	$entry_type = "";
	switch($entity->entry_type)
	{
		case 0:
			$entry_type = elgg_echo('kneemail:entry:type:prayer');
			break;
		
		case 1:
			$entry_type = elgg_echo('kneemail:entry:type:praise');
			break;
		
		case 2:
			$entry_type = elgg_echo('kneemail:entry:type:general');
			break;
	}
	
	$entry_status = "";
	switch($entity->entry_status)
	{
		case 0:
			$entry_status = elgg_echo('kneemail:entry:status:active');
			break;
		
		case 1:
			$entry_status = elgg_echo('kneemail:entry:status:answered');
			break;
		
		case 2:
			$entry_status = elgg_echo('kneemail:entry:status:inactive');
			break;
	}
	
?>	
	<div class="contentWrapper">	
	<div id="kneemail_page">
	
<?php	
	if ($entity)
	{
		echo "<b>" . elgg_echo("kneemail:entry") . "</b><br />";
		echo elgg_view('output/longtext', array('value' => $entity->entry));

		echo "<b>" . elgg_echo("kneemail:entry_type") . "</b><br />";
		echo elgg_view('output/longtext', array('value' => $entry_type));

		echo "<b>" . elgg_echo("kneemail:entry_status") . "</b><br />";
		// echo elgg_view('output/longtext', array('value' => $entry_status));
        echo elgg_view("graphics/icon", array('entity' => $entity, 'size' => 'small'));

		$tags = $vars['entity']->tags;
		if (!empty($tags)) {
		
?>
		<!-- display tags -->
		<p class="tags">
			<?php

				echo elgg_view('output/tags', array('tags' => $tags));
			
			?>
		</p>
		
<?php

		}
		$cats = elgg_view('categories/view',$vars);
		if (!empty($cats)) {
			
?>
		<p class="categories">
			<?php echo $cats; ?>
		</p>
<?php
			
		}
	}

	// last edit & by whome
?>

	<p class="strapline">
		<?php
                
			$time_updated = $entity->time_updated;
			$owner_guid = $entity->owner_guid;
			$owner = get_entity($owner_guid);
		
			echo sprintf(elgg_echo("kneemail:strapline"),
							friendly_time($time_updated),
							"<a href=\"" . $owner->getURL() . "\">" . $owner->name ."</a>"
			);
		
		?>
	</p>
</div>

</div>