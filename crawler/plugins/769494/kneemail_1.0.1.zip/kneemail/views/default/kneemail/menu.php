<?php
	/**
	 * Kneemail
	 * 
	 * @package kneemail
	 * @license The BSD License
	 * @author Greg Marine
	 * @copyright Greg Marine 2011
	 * @link http://www.iccnet.org/
	 */
?>
<p class="user_menu_kneemail">
	<a href="<?php echo $vars['url']; ?>pg/kneemail/owned/<?php echo $vars['entity']->username; ?>"><?php echo elgg_echo("kneemail"); ?></a>	
</p>