<?php
	/**
	 * Kneemail
	 * 
	 * @package kneemail
	 * @license The BSD License
	 * @author Greg Marine
	 * @copyright Greg Marine 2011
	 * @link http://www.iccnet.org/
	 */
    
    // kneemail on the group index page

    //check to make sure this group forum has been activated
    if($vars['entity']->kneemail_enable != 'no'){

?>

<div id="group_kneemail_widget">
<h2><?php echo elgg_echo("kneemail:groupprofile"); ?></h2>
<?php

    $objects = list_entities("object", "kneemail", page_owner(), 5, false);
	
    if($objects)
		echo $objects;
	else
		echo "<div class=\"forum_latest\">" . elgg_echo("kneemail:nogroup") . "</div>";
	
?>
<br class="clearfloat" />
</div>

<?php
    }
?>