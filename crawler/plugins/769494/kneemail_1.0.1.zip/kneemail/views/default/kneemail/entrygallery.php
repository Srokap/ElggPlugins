<?php
	/**
	 * Kneemail
	 * 
	 * @package kneemail
	 * @license The BSD License
	 * @author Greg Marine
	 * @copyright Greg Marine 2011
	 * @link http://www.iccnet.org/
	 */

	$icon = elgg_view(
			"graphics/icon", array(
			'entity' => $vars['entity'],
			'size' => 'medium',
		  )
		);

	$info = "<div><p><b><a href=\"" . $vars['entity']->getUrl() . "\">" . $vars['entity']->subject . "</a></b></p></div>";

    $time_updated = $vars['entity']->time_updated;
    $owner_guid = $vars['entity']->owner_guid;
    $owner = get_entity($owner_guid);
        
    $info .= "<br /><div>".
        strip_tags(substr($vars['entity']->entry, 0, 100))
     . "</div>";

	echo elgg_view_listing($icon, $info);
?>