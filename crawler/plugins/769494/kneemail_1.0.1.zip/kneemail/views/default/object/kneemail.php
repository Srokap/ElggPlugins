<?php
	/**
	 * Kneemail
	 * 
	 * @package kneemail
	 * @license The BSD License
	 * @author Greg Marine
	 * @copyright Greg Marine 2011
	 * @link http://www.iccnet.org/
	 */

	if ($vars['full'])
    {
		echo elgg_view("kneemail/entryprofile",$vars);
	}
    else
    {
		if (get_input('search_viewtype') == "gallery")
        {
			echo elgg_view('kneemail/entrygallery',$vars); 				
		}
        else
        {
			echo elgg_view("kneemail/entrylisting",$vars);
		}
	}
?>