<?php
	/**
	 * Kneemail
	 * 
	 * @package kneemail
	 * @license The BSD License
	 * @author Greg Marine
	 * @copyright Greg Marine 2011
	 * @link http://www.iccnet.org/
	 */
    
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	global $CONFIG;
	
	// Add menus
	$owner = page_owner_entity();
	if (!($owner instanceof ElggGroup))
    {
    	add_submenu_item(sprintf(elgg_echo("kneemail:user"), page_owner_entity()->name), $CONFIG->url . "pg/kneemail/owned/" . page_owner_entity()->username, 'kneemaillinksgeneral');
	}
    if (($owner instanceof ElggEntity) && (can_write_to_container(0,$owner->guid)))
    {
        add_submenu_item(elgg_echo('kneemail:new'), $CONFIG->url . "pg/kneemail/new/?container_guid=" . page_owner(), 'kneemailactions');
    }
    
	add_submenu_item(elgg_echo('kneemail:all'),$CONFIG->wwwroot."mod/kneemail/world.php", 'kneemaillinksgeneral');
	
    if (is_callable('group_gatekeeper')) group_gatekeeper();
	
	$limit = get_input("limit", 10);
	$offset = get_input("offset", 0);
	
	if($owner instanceof ElggGroup)
    {
		$title = sprintf(elgg_echo("kneemail:group"),$owner->name);
	}
    else
    {
		$title = sprintf(elgg_echo("kneemail:user"),$owner->name);
	}

	// Get objects
	$context = get_context();
	
	set_context('search');
	
	$objects = list_entities("object", "kneemail", page_owner(), $limit, false);
	
	set_context($context);
	
	$body = elgg_view_title($title);
	$body .= $objects;
	$body = elgg_view_layout('two_column_left_sidebar', '', $body);
	
	// Finally draw the page
	page_draw($title, $body);
?>