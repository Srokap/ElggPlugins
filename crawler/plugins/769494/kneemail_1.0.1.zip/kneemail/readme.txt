Just drop this into your mod directory and enable it in tool administration.

There are no settings for this plugin.

http://www.iccnet.org