<?php
	/**
	 * Kneemail
	 * 
	 * @package kneemail
	 * @license The BSD License
	 * @author Greg Marine
	 * @copyright Greg Marine 2011
	 * @link http://www.iccnet.org/
	 */

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	gatekeeper();
	global $CONFIG;
	
	// Get the current page's owner
	if ($container = (int) get_input('container_guid'))
	{
		set_page_owner($container);
	}
	
	$page_owner = page_owner_entity();
	
	if ($page_owner === false || is_null($page_owner))
	{
		$page_owner = $_SESSION['user'];
		set_page_owner($page_owner->getGUID());
	}

    global $CONFIG;
	add_submenu_item(sprintf(elgg_echo("kneemail:user"), page_owner_entity()->name), $CONFIG->url . "pg/kneemail/owned/" . page_owner_entity()->username, 'kneemaillinksgeneral');
    
	$title = elgg_echo("kneemail:new");
	$area2 .= elgg_view_title($title);
	$area2 .= elgg_view("forms/kneemail/new");
	
	$body = elgg_view_layout('two_column_left_sidebar', $area1, $area2);
	
	page_draw($title, $body);
?>