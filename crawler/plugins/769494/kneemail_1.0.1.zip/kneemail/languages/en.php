<?php
	/**
	 * Kneemail
	 * 
	 * @package kneemail
	 * @license The BSD License
	 * @author Greg Marine
	 * @copyright Greg Marine 2011
	 * @link http://www.iccnet.org/
	 */


	$english = array(
    
        /**
         * Menu items and titles
         */
        'kneemail' => "Kneemail",
        'kneemail:yours' => "Your Kneemail",
        'kneemail:user' => "My Kneemail",
        'kneemail:group' => "Group Kneemail",
        'kneemail:all' => "All Kneemail",
        'kneemail:new' => "New Kneemail Entry",
        'kneemail:groupprofile' => "Group Kneemail",
        'kneemail:edit' => "Edit this entry",
        'kneemail:delete' => "Delete this entry",
        'kneemail:history' => "Entry History",
        'kneemail:view' => "View Entry",
        'kneemail:via' => "via Kneemail",
        'kneemail:nogroup' => 'This group does not have any entries yet',
        'kneemail:more' => 'More entries',
        'item:object:kneemail' => 'Kneemail Entries',
        
        /**
         * Form fields
         */
        'kneemail:subject' => 'Subject:',
        'kneemail:entry' => 'Entry:',
        'kneemail:entry_type' => 'Type:',
        'kneemail:entry_status' => 'Status:',
        'kneemail:tags' => 'Tags:',	
        'kneemail:access_id' => 'Access:',
        'kneemail:write_access_id' => 'Write Access:',
        'kneemail:entry:type:prayer' => 'Prayer',
        'kneemail:entry:type:praise' => 'Praise',
        'kneemail:entry:type:general' => 'General',
        'kneemail:entry:status:active' => 'Active',
        'kneemail:entry:status:answered' => 'Answered',
        'kneemail:entry:status:inactive' => 'Inactive',
    
        /**
         * Status and error messages
         */
        'kneemail:noaccess' => 'No access to entry',
        'kneemail:cantedit' => 'You can not edit this entry',
        'kneemail:saved' => 'Kneemail saved',
        'kneemail:notsaved' => 'Entry could not be saved',
        'kneemail:nosubject' => 'You must specify a subject for your entry.',
        'kneemail:delete:success' => 'Your entry was successfully deleted.',
        'kneemail:delete:failure' => 'The entry could not be deleted.',
    
		/**
		 * Page
		 */
		'kneemail:strapline' => 'Last updated %s by %s',
	
        /**
         * Widget
         **/
        'kneemail:num' => 'Number of kneemail to display',
        'kneemail:widget:description' => "This is a list of your entries.",
   
        /**
         * Submenu items
         */
        'kneemail:label:view' => "View entry",
        'kneemail:label:edit' => "Edit entry",
           
        // For groups
        'groups:enablekneemail' => "Enable Group Kneemail",
	);

	add_translation("en",$english);
?>