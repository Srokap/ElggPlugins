<?php
	/**
	 * Kneemail
	 * 
	 * @package kneemail
	 * @license The BSD License
	 * @author Greg Marine
	 * @copyright ICCNET.org 2008-2009
	 * @link http://www.iccnet.org/
	 */

	/**
	 * Initialise the kneemail plugin.
	 *
	 */
	function kneemail_init()
	{
		global $CONFIG;
		
		// Set up the menu for logged in users
		if (isloggedin()) 
		{
			add_menu(elgg_echo('kneemail'), $CONFIG->wwwroot . "pg/kneemail/owned/" . $_SESSION['user']->username,'kneemail');
		}
		else
		{
			add_menu(elgg_echo('kneemail'), $CONFIG->wwwroot . "mod/kneemail/world.php");
		}
		
		// Extend hover-over menu	
		extend_view('profile/menu/links','kneemail/menu');
		
		// Register an entry handler, so we can have nice URLs
		register_page_handler('kneemail','kneemail_entry_handler');
		
		// Register a url handler
		register_entity_url_handler('kneemail_url', 'object', 'kneemail');
		// register_entity_url_handler('kneemail_url','object', 'page');
		
		// Register some actions
		register_action("kneemail/new",false, $CONFIG->pluginspath . "kneemail/actions/kneemail/new.php");
		register_action("kneemail/edit",false, $CONFIG->pluginspath . "kneemail/actions/kneemail/edit.php");
		register_action("kneemail/delete",false, $CONFIG->pluginspath . "kneemail/actions/kneemail/delete.php");
		
		// Extend some views
		extend_view('css','kneemail/css');
		extend_view('groups/menu/links', 'kneemail/menu'); // Add to groups context
		extend_view('groups/right_column', 'kneemail/groupprofile_kneemail'); // Add to groups context
		
		// Register entity type
		// register_entity_type('object','page');
		register_entity_type('object','kneemail');
		
		// Register granular notification for this type
		if (is_callable('register_notification_object'))
			register_notification_object('object', 'kneemail', elgg_echo('kneemail:new'));

		// Listen to notification events and supply a more useful message
		register_plugin_hook('notify:entity:message', 'object', 'entry_notify_message');
			
		// add the group kneemail tool option     
		add_group_tool_option('kneemail',elgg_echo('groups:enablekneemail'),true);

		
		//add a widget
	    add_widget_type('kneemail',elgg_echo('kneemail'),elgg_echo('kneemail:widget:description'));
		
		// Language short codes must be of the form "kneemail:key"
		// where key is the array key below
		$CONFIG->kneemail = array(
			'subject' => 'text',
			'entry' => 'longtext',
			'entry_type' => 'pulldown',
			'entry_status' => 'pulldown',
			'tags' => 'tags',	
			'access_id' => 'access',
			'write_access_id' => 'access',
		);
		
		// expose_function('kneemail_login', 'kneemail_login_handler', array("username" => array("type" => "string"),"password" => array("type" => "string")), "Login for Kneemail", "GET", false, true);
		// expose_function('kneemail_logout', 'kneemail_logout_handler', NULL, "Logout for Kneemail", "GET", false, false);
		// expose_function('kneemail_groups', 'kneemail_groups_handler', NULL, "Get Groups for Kneemail", "GET", false, false);
	}
	
	function kneemail_url($entity)
    {
		global $CONFIG;
		return $CONFIG->url . "pg/kneemail/view/{$entity->guid}/";
	}
	
	/**
	 * Sets up submenus for the kneemail system.  Triggered on pagesetup.
	 *
	 */
	function kneemail_submenus() {
		
		global $CONFIG;
		
		$page_owner = page_owner_entity();
		
		// Group submenu option	
		if ($page_owner instanceof ElggGroup && get_context() == 'groups') {
			if($page_owner->kneemail_enable != "no"){
				add_submenu_item(sprintf(elgg_echo("kneemail:group"),$page_owner->name), $CONFIG->wwwroot . "pg/kneemail/owned/" . $page_owner->username);
			}
		}
    }
	
	/**
	 * kneemail entry handler.
	 *
	 * @param array $entry
	 */
	function kneemail_entry_handler($entry)
	{
		global $CONFIG;
		
		if (isset($entry[0]))
		{
			// See what context we're using
			switch($entry[0])
			{
				case "new" :
					include($CONFIG->pluginspath . "kneemail/new.php");
          		break;
    			case "world":  
   					include($CONFIG->pluginspath . "kneemail/world.php");
          		break;
    			case "owned" :
    				// Owned by a user
    				if (isset($entry[1]))
    					set_input('username',$entry[1]);
    					
    				include($CONFIG->pluginspath . "kneemail/index.php");	
    			break;
    			case "edit" :
    				if (isset($entry[1]))
    					set_input('kneemail_guid', $entry[1]);
    					
    				 $entity = get_entity($entry[1]);
    				 add_submenu_item(elgg_echo('kneemail:label:view'), $CONFIG->url . "pg/kneemail/view/{$entry[1]}", 'kneemaillinks');
    				 if (($entity) && ($entity->canEdit())) add_submenu_item(elgg_echo('kneemail:label:edit'), $CONFIG->url . "pg/kneemail/edit/{$entry[1]}", 'kneemailactions');

    				include($CONFIG->pluginspath . "kneemail/edit.php");
    			break;
    			case "view" :
    				if (isset($entry[1]))
    					set_input('kneemail_guid', $entry[1]);
    					
    				 $entity = get_entity($entry[1]);
    				 if (($entity) && ($entity->canEdit())) add_submenu_item(elgg_echo('kneemail:label:edit'), $CONFIG->url . "pg/kneemail/edit/{$entry[1]}", 'kneemailactions');
    					
    				include($CONFIG->pluginspath . "kneemail/view.php");
    			break;   
    			default:
    				include($CONFIG->pluginspath . "kneemail/new.php");
    			break;
			}
		}
		
	}
	
	/**
	* Returns a more meaningful message
	*
	* @param unknown_type $hook
	* @param unknown_type $entity_type
	* @param unknown_type $returnvalue
	* @param unknown_type $params
	*/
    function entry_notify_message($hook, $entity_type, $returnvalue, $params)
    {
        $entity = $params['entity'];
        $to_entity = $params['to_entity'];
        $method = $params['method'];
        if (($entity instanceof ElggEntity) && $entity->getSubtype() == 'kneemail')
        {
            $subject = $entity->subject;
            $entry = $entity->entry;
            global $CONFIG;
            $url = $CONFIG->wwwroot . "pg/view/" . $entity->guid;
            if ($method == 'sms') {
                $owner = $entity->getOwnerEntity();
                return $owner->username . ' ' . elgg_echo("kneemail:via") . ': ' . $url . ' (' . $subject . ')';
            }
            if ($method == 'email') {
                $owner = $entity->getOwnerEntity();
                return $owner->username . ' ' . elgg_echo("kneemail:via") . ': ' . $subject . "\n\n" . $entry. "\n\n" . $entity->getURL();
            }
            if ($method == 'web') {
                $owner = $entity->getOwnerEntity();
                return $owner->username . ' ' . elgg_echo("kneemail:via") . ': ' . $subject . "\n\n" . $entry . "\n\n" . $entity->getURL();
            }
        }
        return null;
    }
	
	/**
	 * Extend permissions checking to extend can-edit for write users.
	 *
	 * @param unknown_type $hook
	 * @param unknown_type $entity_type
	 * @param unknown_type $returnvalue
	 * @param unknown_type $params
	 */
	function kneemail_write_permission_check($hook, $entity_type, $returnvalue, $params)
	{
		if ($params['entity']->getSubtype() == 'kneemail')
        {
			$write_permission = $params['entity']->write_access_id;
			$user = $params['user'];

			if (($write_permission) && ($user))
			{
				// $list = get_write_access_array($user->guid);
				$list = get_access_array($user->guid); // get_access_list($user->guid);
					
				if (($write_permission!=0) && (in_array($write_permission,$list)))
					return true;
				
			}
		}
	}
	
	/**
	 * Extend container permissions checking to extend can_write_to_container for write users.
	 *
	 * @param unknown_type $hook
	 * @param unknown_type $entity_type
	 * @param unknown_type $returnvalue
	 * @param unknown_type $params
	 */
	function kneemail_container_permission_check($hook, $entity_type, $returnvalue, $params) {
		
		if (get_context() == "kneemail") {
			if (page_owner()) {
				if (can_write_to_container($_SESSION['user']->guid, page_owner())) return true;
			}
			if ($kneemail_guid = get_input('kneemail_guid',0))
            {
				$entity = get_entity($kneemail_guid);
			}
			if ($entity instanceof ElggObject) {
				if (
						can_write_to_container($_SESSION['user']->guid, $entity->container_guid) || in_array($entity->write_access_id,get_access_list())
					) {
						return true;
				}
			}
		}
		
	}
	
	// write permission plugin hooks
	register_plugin_hook('permissions_check', 'object', 'kneemail_write_permission_check');
	register_plugin_hook('container_permissions_check', 'object', 'kneemail_container_permission_check');
	
	// Make sure the kneemail initialisation function is called on initialisation
	register_elgg_event_handler('init','system','kneemail_init');
	register_elgg_event_handler('pagesetup','system','kneemail_submenus');
?>