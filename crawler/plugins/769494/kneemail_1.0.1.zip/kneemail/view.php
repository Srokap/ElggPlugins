<?php
	/**
	 * Kneemail
	 * 
	 * @package kneemail
	 * @license The BSD License
	 * @author Greg Marine
	 * @copyright Greg Marine 2011
	 * @link http://www.iccnet.org/
	 */

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	$kneemail_guid = get_input('kneemail_guid');
	set_context('kneemail');
	
	if (is_callable('group_gatekeeper')) group_gatekeeper();
	
	$kneemail = get_entity($kneemail_guid);
	if (!$kneemail) forward();

	$container = $kneemail->container_guid;
	
	if ($container)
	{
		set_page_owner($container);
	}
	else
	{
		set_page_owner($kneemail->owner_guid);
	}
	
	global $CONFIG;
	
	if ($kneemail->canEdit())
	{
		// add_submenu_item(elgg_echo('kneemail:delete'),"{$CONFIG->wwwroot}action/kneemail/delete?kneemail={$kneemail->getGUID()}", 'kneemailactions', true);
            
            $__elgg_ts = time();
            $__elgg_token = generate_action_token($__elgg_ts);
            
            add_submenu_item(elgg_echo('kneemail:delete'), "{$CONFIG->wwwroot}action/kneemail/delete?kneemail={$kneemail->getGUID()}&__elgg_ts={$__elgg_ts}&__elgg_token={$__elgg_token}", 'kneemailactions', true);
            
	}
	
	$owner = page_owner_entity();
	if (!($owner instanceof ElggGroup))
    {
		add_submenu_item(sprintf(elgg_echo("kneemail:user"), page_owner_entity()->name), $CONFIG->url . "pg/kneemail/owned/" . page_owner_entity()->username, 'kneemaillinksgeneral');
	}
	else
	{
		add_submenu_item(sprintf(elgg_echo("kneemail:group"), page_owner_entity()->name), $CONFIG->url . "pg/kneemail/owned/" . page_owner_entity()->username, 'kneemaillinksgeneral');
	}
	
	add_submenu_item(elgg_echo('kneemail:all'),$CONFIG->wwwroot."mod/kneemail/world.php", 'kneemaillinksgeneral');
	
	$title = $kneemail->subject;
	
	$body = elgg_view_title($kneemail->subject);
	$body .= elgg_view_entity($kneemail, true);
	
	//add comments
	$body .= elgg_view_comments($kneemail);
	
	$body = elgg_view_layout('two_column_left_sidebar', '', $body);
	
	// Finally draw the page
	page_draw($title, $body);
?>