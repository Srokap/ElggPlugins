<?php
	/**
	 * Kneemail
	 * 
	 * @package kneemail
	 * @license The BSD License
	 * @author Greg Marine
	 * @copyright Greg Marine 2011
	 * @link http://www.iccnet.org/
	 */

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	gatekeeper();
		
	$kneemail_guid = get_input('kneemail_guid');
	$kneemail = get_entity($kneemail_guid);
	
	// Get the current page's owner
	if ($container = $kneemail->container_guid)
	{
		set_page_owner($container);
	}
	
	$page_owner = page_owner_entity();
	
	if ($page_owner === false || is_null($page_owner))
	{
		$page_owner = $_SESSION['user'];
		set_page_owner($page_owner->getGUID());
	}
	
	$title = elgg_echo("kneemail:edit");
	$body = elgg_view_title($title);
	
	if (($kneemail) && ($kneemail->canEdit()))
	{
		$body .= elgg_view("forms/kneemail/edit", array('entity' => $kneemail));
	}
	else
	{
		$body .= elgg_echo("kneemail:noaccess");
	}
	
	$body = elgg_view_layout('two_column_left_sidebar', '', $body);
	
	page_draw($title, $body);
?>