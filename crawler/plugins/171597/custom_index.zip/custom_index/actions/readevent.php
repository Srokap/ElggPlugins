<?php
/* /**
	 * Elgg custom_index plugin
	 *
	 * @package ElggCinema
	 * @author VinSoft di Erminia Naccarato
	 * @copyright VinSoft 2009
	 * @link http://vinsoft.it
	 *
 *
 * An event that are 'read' do not insert in home page
 */
admin_gatekeeper();
	// Get input data
         $guid=get_input('eventpost');
	//print($guid);

                $event=get_entity($guid);
                print($event);
                $event->homepage='Read';

                 if($event->subtype==get_subtype_id('object', 'event_calendar')){
					system_message(elgg_echo("event_calendar:read"));
                   forward("mod/custom_index/approveEvent.php");
                    }elseif ($event->subtype==get_subtype_id('object', 'ad')){
                      system_message(elgg_echo("ad:read"));
                    forward("mod/custom_index/approveAd.php");
                    }else{
                         system_message(elgg_echo("poll:read"));
                    forward("mod/custom_index/approvePoll.php");
                    }
					




?>
