<?php

/*Elgg custom_index plugin
	 *
	 * @package ElggCinema
	 * @author VinSoft di Erminia Naccarato
	 * @copyright VinSoft 2009
	 * @link http://vinsoft.it
	 */



	require_once(dirname(dirname(dirname(__FILE__))) . '/engine/start.php');
		admin_gatekeeper();

	// Set context

		set_context("admin");


	// Get objects
	$context = get_context();
    $area2 = elgg_view_title(elgg_echo('event_calendar:homepage'));


    $date=strtotime(date(Y)."/".date(m)."/".date(d));

   // $meta_array_event[]=array('name'=>'start_date', 'operand'=>'>=', 'value'=>$date);
    $meta_array_event[] = array('name'=>'end_date', 'operand'=>'>=', 'value'=>$date);
    $meta_array_event[]=array('name'=>'homepage', 'operand'=>'=', 'value'=>'No');
    $events = get_entities_from_metadata_by_value($meta_array_event, 'object', 'event_calendar','','','',10,'');
    foreach($events as $e){
        $events_calendar .=elgg_view_entity(get_entity($e->guid));
    //  print_r(date("Y/m/d",$e->start_date));echo " ";
        //creo dei link di modifica per l'entità
        $events_calendar .="<h4><a href=\"".$CONFIG->wwwroot."action/custom_index/approveevent?eventpost=".$e->guid."\"/>Approve</a></h4>";
        $events_calendar .="<h4><a href=\"".$CONFIG->wwwroot."action/custom_index/readevent?eventpost=".$e->guid."\"/>Read</a></h4>";



    }

   $area2 .=$events_calendar;




	$body = elgg_view_layout('two_column_left_sidebar',$area1, $area2);

	// Finally draw the page
	page_draw($title, $body);


?>
