<?php

	/**
	 * Elgg custom index
	 * 
	 * @package ElggCustomIndex
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
     * "Code modified by Vinsoft di Erminia Naccarato, www.vinsoft.it"
	 */

	// Get the Elgg engine
		require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
		
    //get required data		
	set_context('search');//display results in search mode, which is list view
	//grab the latest 4 blog posts. to display more, change 4 to something else
	$blogs = list_entities('object','blog',0,4,false, false, false);
	//grab the latest bookmarks
	$bookmarks = list_entities('object','bookmarks',0,4,false, false, false);
	//grab the latest files
	$files = list_entities('object','file',0,4,false, false, false);
	//get the newest members who have an avatar
	$newest_members = get_entities_from_metadata('icontime', '', 'user', '', 0, 10);
	//newest groups
	$groups = list_entities('group','',0,4,false, false, false);
	//grab the login form
	$login = elgg_view("account/forms/login");

    //load last shows that are programming now in the cinemas
    $date1=date(Y)."/".date(m)."/".date(d);

    $meta_array[]=array('name'=>'show_startdate', 'operand'=>'<', 'value'=>$date1);
    $meta_array[] = array('name'=>'show_enddate', 'operand'=>'>', 'value'=>$date1);
    $show = get_entities_from_metadata_by_value($meta_array, 'object', 'show','','','',4);
    foreach($show as $s){
        $array_show.=elgg_view_entity(get_entity($s->guid));
    }

    //load all the events of users that administrator has approved but they are not declined
    
    $date=strtotime(date(Y)."/".date(m)."/".date(d));
    $meta_array_event[] = array('name'=>'end_date', 'operand'=>'>=', 'value'=>$date);
    $meta_array_event[]=array('name'=>'homepage', 'operand'=>'=', 'value'=>'Yes');
    $events = get_entities_from_metadata_by_value($meta_array_event, 'object', 'event_calendar','','','',4);
    foreach($events as $e){

       $entity=get_entity($e->guid);
       $events_calendar .=elgg_view_entity($e);
//       $venue=$entity->venue;
//
//       print($description);
//       $events_calendar .=date('d-m-Y',$entity->start_date);
//       (int)$numcar=10;
//                if(strlen($venue)<$numcar){
//                    $events_calendar .="<h4><a href=\"".$CONFIG->wwwroot."pg/event_calendar/view/".$e->guid."\"/>$venue</a></h4>";
//                }
//                else{
//                    $venue=explode(" ",substr($venue,0,$numcar));
//                    array_pop($venue); //toglie l'ultima parola (monca)
//                    $venue=(implode(" ",$venue));
//                    $events_calendar .="<h4><a href=\"".$CONFIG->wwwroot."pg/event_calendar/view/".$e->guid."\"/>".sprintf(strip_tags($venue)).sprintf(' ...')."</a></h4>";
//                }
//       $events_calendar .=$entity->description;
//       $events_calendar .=sprintf('<br />').sprintf('<br />');
//
    }
    
    
	//load all the ads of users that administrator has approved
    $meta_array_ad[]=array('name'=>'homepage', 'operand'=>'=', 'value'=>'Yes');
    $ads = get_entities_from_metadata_by_value($meta_array_ad, 'object', 'ad','','','',4);
    foreach($ads as $a){
        $ad_array.=elgg_view_entity(get_entity($a->guid));
    }


  //load all the polls of users and groups that administrator has approved
  $array_polls[]=array('name'=>'homepage', 'operand'=>'=', 'value'=>'Yes');
  $polls=get_entities_from_metadata_by_value($array_polls, 'object', 'poll','','','',4);

  foreach($polls as $p){
        $poll_array.=elgg_view_entity(get_entity($p->guid));
    }


  //load meteo
    $date_today=date(Y)."/".date(m)."/".date(d);
    $date_after_tomorrow=date('Y/m/d', time()+172800);

//    print($date_today);
//    print($date_after_tomorrow);

    $meta_array_meteo[]=array('name'=>'day', 'operand'=>'>=', 'value'=>$date_today);
    $meta_array_meteo[] = array('name'=>'day', 'operand'=>'<=', 'value'=>$date_after_tomorrow);

    $entities = get_entities_from_metadata_by_value($meta_array_meteo, 'object', 'meteo','','','',4,'',"v1.string asc");
     $meteo_array="<h4><a href=\"".$CONFIG->wwwroot."mod/meteo/index.php"."\"/>".elgg_echo('meteo:week')."</a></h4>";
    foreach($entities as $en){
        $entity=get_entity($en->guid);
        if($entity->day ==$date_today){
            $meteo_array .=elgg_view_entity($entity);

        }
        if($entity->day == $date_after_tomorrow){
            $meteo_array .=elgg_view_entity($entity);
//             
        }
        if($entity->day >$date_today && ($entity->day)<$date_after_tomorrow){
            $meteo_array .=elgg_view_entity($entity);
//          
        }

    };



    //display the contents in our new canvas layout
	$body = elgg_view_layout('new_index',$login, $files, $newest_members, $blogs, $groups, $bookmarks, $array_show, $events_calendar, $ad_array,$poll_array, $meteo_array);
   
    page_draw($title, $body);
		
?>