<?php

	/**
	 * Elgg custom index page
	 * 
	 * @package ElggIndexCustom
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider <info@elgg.com>
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
     * "Code modified by Vinsoft di Erminia Naccarato, www.vinsoft.it"
	 */

	 
    function indexCustom_init() {
	
        // Extend system CSS with our own styles
				extend_view('css','custom_index/css');
				
       // Replace the default index page
			register_plugin_hook('index','system','custom_index');
			
				
    }
    
    function custom_index() {
			
			if (!@include_once(dirname(__FILE__) . "/index.php")) return false;
			return true;
			
		}




		function custom_index_pagesetup() {

			global $CONFIG;

        $page_owner = page_owner_entity();

		$context = get_context();
        
        if(is_plugin_enabled('event_calendar')){
        if (get_context () == 'admin' && isadminloggedin ()) {
                    global $CONFIG;
                    add_submenu_item ( elgg_echo ( 'event_calendar:homepage' ), $CONFIG->wwwroot . 'mod/custom_index/approveEvent.php' );
                    
                }
        
        }

        if(is_plugin_enabled('ad')){
        if (get_context () == 'admin' && isadminloggedin ()) {
                    global $CONFIG;
                    add_submenu_item ( elgg_echo ( 'ad:homepage' ), $CONFIG->wwwroot . 'mod/custom_index/approveAd.php' );
                    
                }

        }
        if(is_plugin_enabled('poll')){
        if (get_context () == 'admin' && isadminloggedin ()) {
                    global $CONFIG;
                    add_submenu_item ( elgg_echo ( 'poll:homepage' ), $CONFIG->wwwroot . 'mod/custom_index/approvePoll.php' );

                }

        }

        }


        /**
 *
 * @global <type> $CONFIG
 * @param <type> $meta_array Is a multidimensional array with the list of metadata to filter.
 * For each metadata you have to provide 3 values:
 * - name of metadata
 * - value of metadata
 * - operand ( <, >, <=, >=, =, like, in)
 * @param <type> $entity_type
 * @param <type> $entity_subtype
 * @param <type> $owner_guid
 * @param <type> $container_guid
 * @param <type> $limit
 * @param <type> $offset
 * @param <type> $order_by
 * @param <type> $site_guid
 * @param <type> $filter
 * @param <type> $count
 * @return <type>
 *
 *
 */
function get_entities_from_metadata_by_value($meta_array, $entity_type = "", $entity_subtype = "", $count = false,
                    $owner_guid = 0, $container_guid = 0, $limit = 10, $offset = 0,
                    $order_by = "", $site_guid = 0)
	{
		global $CONFIG;

        $where = array();

        $mindex = 1;
        $join_meta = "";
        $query_access = "";
        foreach($meta_array as $meta) {
			$join_meta .= "JOIN {$CONFIG->dbprefix}metadata m{$mindex} on e.guid = m{$mindex}.entity_guid ";
            $join_meta .= "JOIN {$CONFIG->dbprefix}metastrings v{$mindex} on v{$mindex}.id = m{$mindex}.value_id ";

            $meta_n = get_metastring_id($meta['name']);
			$where[] = "m{$mindex}.name_id='$meta_n'";


			if (strtolower($meta['operand']) == "like"){
                $where[] = "v{$mindex}.string LIKE ('".$meta['value']."') ";
            }elseif(strtolower($meta['operand']) == "in"){
                // TO DO
            }else{
                $where[] = "v{$mindex}.string".$meta['operand']."'".$meta['value']."'";
            }

            $query_access .= ' and ' . get_access_sql_suffix("m{$mindex}"); // Add access controls

			$mindex++;
		}

        $entity_type = sanitise_string($entity_type);
		$entity_subtype = get_subtype_id($entity_type, $entity_subtype);
		$limit = (int)$limit;
		$offset = (int)$offset;

        // ORDER BY
        if ($order_by == "") $order_by = "e.time_created desc";
		$order_by = sanitise_string($order_by);
        // --- ---

		$site_guid = (int) $site_guid;
		if ((is_array($owner_guid) && (count($owner_guid)))) {
			foreach($owner_guid as $key => $guid) {
				$owner_guid[$key] = (int) $guid;
			}
		} else {
			$owner_guid = (int) $owner_guid;
		}

		if ((is_array($container_guid) && (count($container_guid)))) {
			foreach($container_guid as $key => $guid) {
				$container_guid[$key] = (int) $guid;
			}
		} else {
			$container_guid = (int) $container_guid;
		}
		if ($site_guid == 0)
			$site_guid = $CONFIG->site_guid;

		//$access = get_access_list();

		if ($entity_type!="")
			$where[] = "e.type='$entity_type'";
		if ($entity_subtype)
			$where[] = "e.subtype=$entity_subtype";

		if ($site_guid > 0)
			$where[] = "e.site_guid = {$site_guid}";


			if (is_array($owner_guid)) {
				$where[] = "e.owner_guid in (".implode(",",$owner_guid).")";
			} else if ($owner_guid > 0) {
				$where[] = "e.owner_guid = {$owner_guid}";
			}


		if (is_array($container_guid)) {
			$where[] = "e.container_guid in (".implode(",",$container_guid).")";
		} else if ($container_guid > 0)
			$where[] = "e.container_guid = {$container_guid}";

		if (!$count) {
			$query = "SELECT distinct e.* ";
		} else {
			$query = "SELECT count(distinct e.guid) as total ";
            unset ($limit);
		}

        $query .= "FROM {$CONFIG->dbprefix}entities e ";
        // SELECT E JOIN
		$query .= $join_meta;

        $query .= "  WHERE ";
		foreach ($where as $w)
			$query .= " $w and ";
		$query .= get_access_sql_suffix("e"); // Add access controls
		$query .= $query_access;

        if ($limit>0)
            $lim = " limit $offset, $limit";

		if (!$count) {
			$query .= " order by $order_by $lim"; // Add order and limit
			return get_data($query, "entity_row_to_elggstar");
		} else {
            $row = get_data_row($query);
            //echo $query.mysql_error().__FILE__.__LINE__;
            if ($row)
				return $row->total;
		}
		return false;
	}



    // Make sure the
		    register_elgg_event_handler('init','system','indexCustom_init');
            register_elgg_event_handler('pagesetup','system','custom_index_pagesetup');

    // Register actions
		global $CONFIG;
		register_action("custom_index/approveevent",false,$CONFIG->pluginspath . "custom_index/actions/approveevent.php");
		register_action("custom_index/readevent",false,$CONFIG->pluginspath . "custom_index/actions/readevent.php");

?>