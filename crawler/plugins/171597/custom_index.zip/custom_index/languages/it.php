<?php

// Generate By translationbrowser. 

$italian = array( 
	 'custom:bookmarks'  =>  "Gli ultimi segnalibri" , 
	 'custom:groups'  =>  "Gli ultimi gruppi" , 
	 'custom:files'  =>  "Gli ultimi files" , 
	 'custom:blogs'  =>  "Gli ultimi messaggi nel blog" , 
	 'custom:members'  =>  "I membri più recenti" , 
	 'custom:nofiles'  =>  "Non ci sono ancora files" , 
	 'custom:nogroups'  =>  "Non ci sono ancora files",
    
     'custom:event_calendar'=>"Ultimi Eventi",
     'custom:show'=>"Ultimi Spettacoli",
     'custom:ad'=>"Ultimi Annunci inseriti",
     'custom:poll'=>"Ultimi Sondaggi inseriti",
     'event_calendar:homepage'=>"Eventi da inserire in Home",
     'ad:homepage'=>"Annunci da inserire in Home",
     'poll:homepage'=>"Sondaggi da inserire in Home",
     'event_calendar:read'=>"Evento letto",
     'ad:read'=>"Annuncio letto",
     'poll:read'=>"Sondaggio letto",
     'event_calendar:postedhomepage'=>"Evento inserito in Homepage",
     'ad:postedhomepage'=>"Annuncio inserito in Homepage",
     'poll:postedhomepage'=>"Sondaggio inserito in Homepage",
     'menu:dashboard'=>"Home",


); 

add_translation('it', $italian); 

?>
