<?php

	$english = array(
	
			'custom:bookmarks' => "Latest bookmarks",
			'custom:groups' => "Latest groups",
			'custom:files' => "Latest files",
			'custom:blogs' => "Latest blog posts",
			'custom:members' => "Newest members",
			'custom:nofiles' => "There are no files yet",
			'custom:nogroups' => "There are no files yet",

            'custom:event_calendar'=>"Latest events",
            'custom:show'=>"Latest shows",
            'custom:ad'=>"Last added Classifieds",
            'custom:poll'=>"Latest added Polls",
            'event_calendar:homepage'=>"Events to be included in Home",
            'ad:homepage'=>"Ads to be included in Home",
            'poll:homepage'=>"Polls to be included in Home",
            'event_calendar:read'=>"Event bed",
            'ad:read'=>"Ad read",
            'poll:read'=>"Poll read",
            'event_calendar:postedhomepage'=>"Event added to our Homepage",
            'ad:postedhomepage'=>"Ad added to our Homepage",
            'poll:postedhomepage'=>"Poll added to our Homepage",
            'menu:dashboard'=>"Home",
	
	);
					
	add_translation("en",$english);

?>