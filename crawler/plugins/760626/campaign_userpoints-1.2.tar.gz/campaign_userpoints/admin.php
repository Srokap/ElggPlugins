<?php
/**
 *	Campaign Userpoints Plugin
 *
 *	@package campaign_userpoints
 *	@author Liran Tal <liran.tal@gmail.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2010
 *	@link http://www.enginx.com
 */

gatekeeper();
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

// required admin to be logged-in
admin_gatekeeper();

global $CONFIG;

set_context('admin');
set_page_owner($_SESSION['guid']);

$tab = get_input('tab', 'settings');

$body = elgg_view_title(elgg_echo('campaign_userpoints:administration'));

$body .= elgg_view("campaign_userpoints/admin/campaign_userpoints", array('tab' => $tab));

page_draw(elgg_echo('campaign_userpoints:administration'), elgg_view_layout("two_column_left_sidebar", '', $body));
