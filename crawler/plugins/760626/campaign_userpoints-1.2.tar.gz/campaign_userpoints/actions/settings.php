<?php
/**
 *	Campaign Userpoints Plugin
 *
 *	@package campaign_userpoints
 *	@author Liran Tal <liran.tal@gmail.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2010
 *	@link http://www.enginx.com
 */

global $CONFIG;

gatekeeper();
admin_gatekeeper();
action_gatekeeper();

// settings parameters
$params = get_input('params');
$result = false;
foreach ($params as $k => $v) {
	error_log("k = $k \t\t | v = $v \n");
	if (!set_plugin_setting($k, $v, 'campaign_userpoints')) {
		register_error(sprintf(elgg_echo('plugins:settings:save:fail'), 'campaign_userpoints'));
		forward($_SERVER['HTTP_REFERER']);
	}
}

system_message(elgg_echo('campaign_userpoints:settings:successfully saved settings'));
forward($_SERVER['HTTP_REFERER']);

?>
