<?php
/**
 *	Campaign Userpoints Plugin
 *
 *	@package campaign_userpoints
 *	@author Liran Tal <liran.tal@gmail.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2010
 *	@link http://www.enginx.com
 */

$plugin = find_plugin_settings('campaign_userpoints');

$send_user_email_reached_goal = $plugin->send_user_email_reached_goal ? $plugin->send_user_email_reached_goal : "0"; 
$send_user_email_reached_goal_message_text = $plugin->send_user_email_reached_goal_message_text ? $plugin->send_user_email_reached_goal_message_text : "";

$send_admin_email_reached_goal = $plugin->send_admin_email_reached_goal ? $plugin->send_admin_email_reached_goal : "0";
$send_admin_email_reached_goal_message_text = $plugin->send_admin_email_reached_goal_message_text ? $plugin->send_admin_email_reached_goal_message_text : "";
$admin_email = $plugin->admin_email ? $plugin->admin_email : "";

$log_emails = $plugin->log_emails ? $plugin->log_emails : "0";
$log_file_location = $plugin->log_file_location ? $plugin->log_file_location : "";

$timestamp = time();
$token = generate_action_token($timestamp);

$action = $vars['url'] . "action/campaign_userpoints/settings";


$form_body = "";

// send_user_email_reached_goal
$form_body .= elgg_echo('campaign_userpoints:admin:send user an email when reached campaign goal');
$form_body .= elgg_view('input/pulldown', array(
                'internalname' => 'params[send_user_email_reached_goal]',
                'options_values' => array('1' => 'Yes', '0' => 'No'),
                'value' => $plugin->send_user_email_reached_goal
					)
				);
$form_body .= "<br/>";
$form_body .= elgg_echo('campaign_userpoints:admin:message text');
$form_body .= "<br/>";
$form_body .= elgg_view('input/plaintext', array('internalname' => 'params[send_user_email_reached_goal_message_text]',
										'value' => $plugin->send_user_email_reached_goal_message_text)
				);
// end

// send_admin_email_reached_goal
$form_body .= elgg_echo('campaign_userpoints:admin:send admin an email when user reached campaign goal');
$form_body .= elgg_view('input/pulldown', array(
                'internalname' => 'params[send_admin_email_reached_goal]',
                'options_values' => array('1' => 'Yes', '0' => 'No'),
                'value' => $plugin->send_admin_email_reached_goal
					)
				);
$form_body .= "<br/>";
$form_body .= elgg_echo('campaign_userpoints:admin:admin email address');
$form_body .= "<br/>";
$form_body .= elgg_view('input/email', array('internalname' => 'params[admin_email]',
										'value' => $plugin->admin_email)
				);
$form_body .= "<br/>";
$form_body .= elgg_echo('campaign_userpoints:admin:message text');
$form_body .= "<br/>";
$form_body .= elgg_view('input/plaintext', array('internalname' => 'params[send_admin_email_reached_goal_message_text]',
										'value' => $plugin->send_admin_email_reached_goal_message_text)
				);
// end

			
// log_emails
$form_body .= elgg_echo('campaign_userpoints:admin:should all emails sent be written to log file');
$form_body .= elgg_view('input/pulldown', array(
                'internalname' => 'params[log_emails]',
                'options_values' => array('1' => 'Yes', '0' => 'No'),
                'value' => $plugin->log_emails
					)
				);
$form_body .= "<br/>";
$form_body .= elgg_echo('campaign_userpoints:admin:log file location');
$form_body .= "<br/>";
$form_body .= elgg_view('input/text', array('internalname' => 'params[log_file_location]',
										'value' => $plugin->log_file_location)
				);
$form_body .= "<br/>";
// end





$form_body .= elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('save')));

$form .= elgg_view('input/form', array('action' => "$action", 'body' => $form_body));

echo $form;