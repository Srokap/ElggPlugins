<?php
/**
 *	Campaign Userpoints Plugin
 *
 *	@package campaign_userpoints
 *	@author Liran Tal <liran.tal@gmail.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2010
 *	@link http://www.enginx.com
 */

$plugin = find_plugin_settings('campaign_userpoints');

$campaign = $plugin->campaign ? $plugin->campaign : "2010-01-30,100";

$timestamp = time();
$token = generate_action_token($timestamp);

$action = $vars['url'] . "action/campaign_userpoints/settings";


$form_body = "";

// send_user_email_reached_goal
$form_body .= "<br/>";
$form_body .= elgg_echo('campaign_userpoints:admin:campaign settings');
$form_body .= "<br/>";
$form_body .= elgg_view('input/plaintext', array('internalname' => 'params[campaign]',
										'value' => $plugin->campaign)
				);
$form_body .= "<br/>";
$form_body .= elgg_echo('campaign_userpoints:admin:campaign settings:help');
$form_body .= "<br/>";
// end


				

$form_body .= elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('save')));

$form .= elgg_view('input/form', array('action' => "$action", 'body' => $form_body));

echo $form;