<?php
/**
 *	Campaign Userpoints Plugin
 *
 *	@package campaign_userpoints
 *	@author Liran Tal <liran.tal@gmail.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2010
 *	@link http://www.enginx.com
 */

	global $CONFIG;
	
	$tab = $vars['tab'];
	if (!$tab)
		$tab = "settings";
	
?>
<div class="contentWrapper">
	<div id="elgg_horizontal_tabbed_nav">
		<ul>
			<li <?php if ($tab == "settings") echo "class='selected'" ?>><a href="<?php echo $CONFIG->wwwroot . 'pg/campaign_userpoints/admin/settings'; ?>"><?php echo elgg_echo('campaign_userpoints:admin:settings'); ?></a></li>
			<li <?php if ($tab == "campaigns") echo "class='selected'" ?>><a href="<?php echo $CONFIG->wwwroot . 'pg/campaign_userpoints/admin/campaigns'; ?>"><?php echo elgg_echo('campaign_userpoints:admin:campaigns'); ?></a></li>
		</ul>
	</div>
<?php
	switch($tab) {
		case 'campaigns':
			echo elgg_view("campaign_userpoints/admin/campaigns");
			break;
		default:
		case 'settings':
			echo elgg_view("campaign_userpoints/admin/settings");
			break;
	}
?>
</div>
