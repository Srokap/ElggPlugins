<?php
/**
 *	Campaign Userpoints Plugin
 *
 *	@package campaign_userpoints
 *	@author Liran Tal <liran.tal@gmail.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2010
 *	@link http://www.enginx.com
 */


