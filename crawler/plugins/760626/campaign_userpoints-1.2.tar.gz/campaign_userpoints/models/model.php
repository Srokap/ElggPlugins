<?php
/**
 *	Campaign Userpoints Plugin
 *
 *	@package campaign_userpoints
 *	@author Liran Tal <liran.tal@gmail.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2010
 *	@link http://www.enginx.com
 */

function campaign_userpoints_pointsCheck($guid, $plugin) {

	global $CONFIG;
	
	$config = $plugin->campaign;
	
	$configs = explode("\r\n", $config);
	
	//$fullDay = 3600*24;
	
	foreach($configs as $campaign_config) {
			
		list($startDate, $expirationDate, $points) = explode(",", $campaign_config);
		$startDate .= " 00:00:00";
		$expirationDate .= " 23:59:59";
		$startDate = strtotime($startDate);
		$endDate = strtotime($expirationDate);
		$currDate = time();
		
		$userpoints = userpoints_get($guid);
		$user = get_user($guid);
		$username = $user->username;
		$name = $user->name;
		
		$msg = "\n\nWebsite points reached,\n\n".
				"Points target reached ($points) for user, details are: \n".
				"\tUser full name: $name\n".
				"\tUsername: $username\n".
				"\tUser GUID: $guid\n".
				"\tUserpoints (approved): ".$userpoints['approved']."\n".
				"\tUserpoints (pending): ".$userpoints['pending']."\n".
				"\tCurrentDate: ".date("Y-m-d H:i:s", $currDate)."\n".
				"\tStartDate: ".date("Y-m-d H:i:s", $startDate)."\n";
				"\tEndDate: ".date("Y-m-d H:i:s", $endDate)."\n\n";
		
		if ( ($currDate <= $endDate) && ($currDate >= $startDate) ) { 
			if ($userpoints['approved'] >= $points) {
				
				if ( (isset($plugin->send_admin_email_reached_goal)) && ($plugin->send_admin_email_reached_goal == 1 )) {
					
					$subject = elgg_echo('campaign_userpoints:admin_message_subjet');
					$body = $plugin->send_admin_email_reached_goal_message_text . "\n\n" . $msg;
					$to = (!empty($plugin->admin_email)) ? $plugin->admin_email : $CONFIG->site->email;
					if (function_exists('phpmailer_send')) {
						phpmailer_send($CONFIG->site->email, $CONFIG->site->name, $to, "Admin", $subject, $body);
					} else {
						mail($to, $subject, $body);
					}
				}
				
				if ( (isset($plugin->send_user_email_reached_goal)) && ($plugin->send_user_email_reached_goal == 1 )) {
					
					//$body includes the technical details regarding the campaign
					//$body .= $plugin->send_user_email_reached_goal_message_text . "\n\n" . $msg;

					//$body without technical campaign details
					$subject = elgg_echo('campaign_userpoints:user_message_subjet');
					$body = $plugin->send_user_email_reached_goal_message_text;
					if (function_exists('phpmailer_send')) {
						phpmailer_send($CONFIG->site->email, $CONFIG->site->name, $user->email, $user->name, $subject, $body);
					} else {
						mail($to, $subject, $body);
					}
				}
				
				
				
				if ( (isset($plugin->log_emails)) && ($plugin->log_emails == 1 )) {
					$body = $plugin->send_admin_email_reached_goal_message_text . "\n\n" . $msg;
					logToFile($body, $plugin);
				}
				
				
			 } // if users points reached
			 
		} //if campaign happens today
		
	} //foreach
	
}	
	

/*
 * logToFile
 * log campaign emails/messages to file
 * 
 * @param			$body		the body text to write to file
 */
function logToFile($body, $plugin) {
	
	global $CONFIG;
	
	if ( (isset($plugin->log_file_location)) && (!empty($plugin->log_file_location )) ) {
		
		$fh = fopen($plugin->log_file_location, "a");
		// error accessing file
		if (!$fh)
			return;
			
		$date = date('Y-m-d H:i:s');
		fwrite($fh, "====================================================================================\n");
		fwrite($fh, "=== START === $date \n");
		fwrite($fh, $body);
		fwrite($fh, "\n=== END   === \n");
		fwrite($fh, "====================================================================================\n\n");
		fclose($fh);
		
	}
	
}