<?php
/**
 *	Campaign Userpoints Plugin
 *
 *	@package campaign_userpoints
 *	@author Liran Tal <liran.tal@gmail.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2010
 *	@link http://www.enginx.com
 */

// set plugin name
$__PLUGIN_NAME = "campaign_userpoints";

global $CONFIG;



/**
 *	requires plugin functions
 */
require_once(dirname(__FILE__)."/models/model.php");



/**
 *	campaign_userpoints_plugin_init
 *	performs plugin initialization function calls
 */
function campaign_userpoints_plugin_init() {
	
	// register a plugin hook for the elggx_userpoints/add action 
	register_plugin_hook('action', 'elggx_userpoints/add', 'campaign_userpoints_handler');
	register_plugin_hook('userpoints:add', 'all', 'campaign_userpoints_handler');
	
	// page handler for admin menu
	register_elgg_event_handler('pagesetup','system','campaign_userpoints_adminmenu');
	
	// register a page handler for the /pg/ urls
	register_page_handler('campaign_userpoints','campaign_userpoints_page_handler');
}




/**
 * page handler
 *
 * @param array $page Array of page elements, forwarded by the page handling mechanism
 */
function campaign_userpoints_page_handler($page) {
	global $CONFIG;
	
	// URLs $page array:
	//		0 = <username>
	//		1 = <action>
	//		2 = <entityId>
	
	// The second component of the URL is the action
	if (isset($page[0]) && $page[0]) {
		switch ($page[0]) {
			case "admin":
				set_input('tab', $page[1]);
				include(dirname(__FILE__) . "/admin.php");
				break;
		}
		
	}
	
}




/**
 * campaign_userpoints_handler
 * handles the addition of new points awarded to a user
 * 
 * @param unknown_type $hook
 * @param unknown_type $action
 * @return unknown_type
 */
function campaign_userpoints_handler($hook, $entity_type, $returnvalue, $params) {

	
	$userpoint = $params['entity'];
	$user_guid = $userpoint->owner_guid;
	
	$plugin = find_plugin_settings('campaign_userpoints');
	
	campaign_userpoints_pointsCheck($user_guid, $plugin);
	
}



/**
 * campaign_userpoints_adminmenu
 * add sidemenu link in administration mode to plugin's settings 
 * 
 * @return unknown_type
 */
function campaign_userpoints_adminmenu()
{
	global $CONFIG;
	if (get_context() == 'admin' && isadminloggedin()) {
		add_submenu_item(elgg_echo('campaign_userpoints:admin'), $CONFIG->url . "pg/campaign_userpoints/admin");
	}
}

// plugin init hook
register_elgg_event_handler('init','system','campaign_userpoints_plugin_init');


// register CRUD actions
register_action("campaign_userpoints/settings", false, $CONFIG->pluginspath . "campaign_userpoints/actions/settings.php", true);
