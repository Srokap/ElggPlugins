<?php
/**
 *	Campaign Userpoints Plugin
 *
 *	@package campaign_userpoints
 *	@author Liran Tal <liran.tal@gmail.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2010
 *	@link http://www.enginx.com
 */


	$english = array(
	
	// General Items

		'campaign_userpoints' => "Campaign - Userpoints",
		'campaign_userpoints:admin:settings' => "Settings",
		'campaign_userpoints:admin' => "Manage Campaigns - Userpoints",
		'campaign_userpoints:administration' => "Campaign Userpoints Administration",
		'campaign_userpoints:admin:campaigns' => "Campaigns",
		'campaign_userpoints:admin:campaign settings' => "Campaign Settings",
		'campaign_userpoints:admin:campaign settings:help' => "Format is: campaign_start_date,campaign_end_date,points
		<br/> Example: <b>2010-04-01,2010-04-30,100</b>",
	
		'campaign_userpoints:user_message_subjet' => "זכית בפרס מאתר מלומדים!",
		'campaign_userpoints:admin_message_subjet' => "Userpoints campaign reached",
	
		'campaign_userpoints:admin:message text' => "Message text",
		'campaign_userpoints:admin:send admin an email when user reached campaign goal' => "Send admin an email when user reached campaign goal",
		'campaign_userpoints:admin:admin email address' => "Admin E-mail address",
		'campaign_userpoints:admin:should all emails sent be written to log file' => "Should all emails sent be written to log file",
		'campaign_userpoints:admin:log file location' => "Specify log file location",
		
	
		'campaign_userpoints:admin:send user an email when reached campaign goal' => "Send user an email when reached campaign goal",
		'campaign_userpoints:settings:successfully saved settings' => "Successfully saved settings",

	);
					
	add_translation("en", $english);

?>
