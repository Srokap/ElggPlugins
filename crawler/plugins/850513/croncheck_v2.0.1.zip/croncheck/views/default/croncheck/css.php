<?php ?>
#croncheck_information .elgg-head {
	cursor: default;
}

#croncheck_functions {
	display: none;
}