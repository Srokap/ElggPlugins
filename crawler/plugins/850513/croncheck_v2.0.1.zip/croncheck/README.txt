= Croncheck =
Offers a widget to the admins to check how/if the CRON of your site is working

Also the statistics overview is extended with information about CRON

== Content ==
1. Features
2. ToDo

== 1. Features ==
=== Admin widget ===
In the admin area a widget is offered which allows admin to check to workings of CRON

=== Statistics ===
The Statistics overview page is extended with with information about the workings of CRON

== 2. ToDo ==
- When Trac ticket #4186 is fixed some CSS can be removed