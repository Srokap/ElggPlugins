<?php

	$chinese = array(
		'toggle_details' => '展开/收起详细信息',
	);
					
	add_translation("zh",$chinese);

?>