<?php

	$english = array(
		'toggle_details' => 'Show/Hide details',	
	);
					
	add_translation("en",$english);

?>