<?php
	/**
	 * define exceptions here
	 *
	 * @package PybBusinessLogic
	 */
	/**
	 * @author Snow.Hellsing <snow@g7life.com>
	 * @copyright FireBloom Studio
	 * @link http://firebloom.cc
	 */
	/**
	 * BusinessLogicException
	 *
	 */
	class BusinessLogicException extends Exception {}
?>