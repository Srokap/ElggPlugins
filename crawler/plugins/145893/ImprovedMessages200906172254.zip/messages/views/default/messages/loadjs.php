<?php
	/**
	 * Load js into head
	 *
	 * @package ImprovedMessages
	 */
	/**
	 * @author Snow.Hellsing <snow@firebloom.cc>
	 * @copyright FireBloom Studio
	 * @link http://firebloom.cc
	 */
?>
<script type="text/javascript">	
	if($('#messages')){
		loadJS(site_url + 'mod/messages/js/msg_view.js');
	}
</script>