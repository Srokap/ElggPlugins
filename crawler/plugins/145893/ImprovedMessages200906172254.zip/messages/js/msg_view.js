/**
 *
 */
$(function(){
	processShowDetailsLink();	
	processHideDetailsLink();
	processShowReplyLink();	
	processDeleteLink();
	processReply();
});
function processShowDetailsLink(){
	$('#messages .show_details').click(function(){
		var guid = this.name;
		showMsgDetails(guid);
		return false;
	});
}
function processHideDetailsLink(){
	$('#messages .hide_details').click(function(){
		var guid = this.name;
		hideMsgDetails(guid);
		return false;
	});
}
function processShowReplyLink(){
	$('#messages .toggle_reply').click(function(){
		var guid = this.name;
		var msg_div = $('#msg-'+guid);
		var reply_div = $('.reply',msg_div)[0];
		
		$(reply_div).toggle('fast');
		return false;
	});
}
function processReply(){
	$('#messages .reply .submit_button').click(function(){
		var reply_div = this.parentNode;
		
		var msg_input = $("[name='message']",reply_div)[0];
		var msg = msg_input.value;
		var reply = $("[name='reply']",reply_div)[0].value;
		var send_to = $("[name='send_to']",reply_div)[0].value;
		
		var action = '../../mod/messages/ajax/reply.php';
		
		$.post(action,
			   {'message':msg,'reply':reply,'send_to':send_to},
			   function(response){
			$('body').append(response);
			
			msg_input.value = "";			
			hideMsgDetails(reply);
			$(reply_div).hide();
		});
		
		return false;
	});
}
function processDeleteLink(){
	$('#messages .delete_msg a,#messages .options .delete a').click(function(){
		var guid = this.href.match(/message_id=\d+/);
		guid = String(guid);
		guid = guid.replace(/message_id=/,'');
		var msg_div = $('#msg-'+guid);
		
		var action = '../../mod/messages/ajax/delete.php';
		
		$.post(action,
			   {'guid':guid},
			   function(response){
			$('body').append(response.message);
			
			if(response.success){
				
				if( msg_div.hasClass('notread') ){					
					decreaseNewMessageCount();
				}
				
				msg_div.remove();
			}
			
		},'json');
		
		return false;
	});
}
/**
 *
 */
function showMsgDetails(guid){	
	var msg_div = $('#msg-'+guid);
	
	var detail_div = $('.msg_details',msg_div)[0];
	var subject_div = $('.msg_summary',msg_div)[0];
	
	$(detail_div).show('fast');		
	$(subject_div).hide('fast');
	
	if( msg_div.hasClass('notread') ){
		markRead(guid);
		msg_div.removeClass('notread');
		msg_div.addClass('read');
		decreaseNewMessageCount();
	}
}

function hideMsgDetails(guid){
	var msg_div = $('#msg-'+guid);
	
	var detail_div = $('.msg_details',msg_div)[0];
	var subject_div = $('.msg_summary',msg_div)[0];
	
	$(detail_div).hide('fast');
	$(subject_div).show('fast');
}



function markRead(guid){
	var url = '../../mod/messages/ajax/mark_read.php';	
	$.post(url,{'guid':guid});	
}

function decreaseNewMessageCount(){
	var new_msg_link = $('.privatemessages_new')[0];
	
	if(new_msg_link){
		new_msg_link = $(new_msg_link);
		var new_msg_count = new_msg_link.html().replace(/[\[\]]/g,'');
		
		new_msg_count--;
		if( '0' == new_msg_count){
			new_msg_link.empty();				
			new_msg_link.removeClass('privatemessages_new');
			new_msg_link.addClass('privatemessages');				
		}else{				
			new_msg_link.html('['+new_msg_count+']');
		}			
	}
}