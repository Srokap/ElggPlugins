<?php
	/**
	 * mark a message as read via ajax
	 *
	 * @package
	 */
	/**
	 * @author Snow.Hellsing <snow@firebloom.cc>
	 * @copyright FireBloom Studio
	 * @link http://firebloom.cc
	 */
	require_once '../../../engine/start.php';
	
	gatekeeper();
	
	$guid = (int) get_input('guid');
	
	$msg = get_entity($guid);
	if ('messages' == $msg->getSubtype() ) {
		$msg->readYet = 1;
		$result = TRUE;
	}else {
		$result = FALSE;
	}
	
	echo json_encode($result);
?>