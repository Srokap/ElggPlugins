<?php
	/**
	 * delete a message via ajax
	 *
	 * @package ImprovedMessages
	 */
	/**
	 * @author Snow.Hellsing <snow@firebloom.cc>
	 * @copyright FireBloom Studio
	 * @link http://firebloom.cc
	 */	
	require_once '../../../engine/start.php';
	
	gatekeeper();
	
	$guid = (int) get_input('guid');
	
	$msg = get_entity($guid);
	if ('messages' == $msg->getSubtype()
		&& $msg->delete()) {
			
		$response['success'] = TRUE;
		$response['message'] = elgg_view('messages/messages/list',array('object'=>array(elgg_echo("messages:deleted"))));
		
	}else {
		$response['success'] = FALSE;
		$response['message'] = elgg_view('messages/errors/list',array('object'=>array(elgg_echo("messages:notdeleted"))));
	}
	
	echo json_encode($response);
?>