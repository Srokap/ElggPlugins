/*
#elgg_topbar_container_left a.new_friendrequests {
	margin:0 0 0 20px;
	color:white;
	padding:3px;
}
#elgg_topbar_container_left a.new_friendrequests:hover {
	background: #4690d6;
	text-decoration: none;
}
*/

#elgg_topbar_container_left a.new_friendrequests {
	background:transparent url(<?php echo $vars['url']; ?>mod/friend_request/graphics/icons/friendrequest.gif) no-repeat left;
	padding:0 0 0 18px;
	margin:0 15px 0 5px;
	color:white;
}

#elgg_topbar_container_left a.new_friendrequests:hover {
	text-decoration: none;
}

/*jed insert------------*/
.Friend_Request_Icon{
    background:transparent url(<?php echo $vars['url']; ?>mod/friend_request/graphics/icons/FriendRequestIcon.gif) no-repeat left;
    color:#000000;
    padding:3px 10px 3px 10px;
/*    z-index: 7500;*/
	margin:0;
	position:absolute;
	top:21px; /*Adjust this value until the image touches the topbar*/
	width:54px;
	height:48px;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	cursor: pointer;
}
/*jed insert end-----------*/