<?php 

?>
#friend_request_received_listing .elgg-image-block,
#friend_request_sent_listing .elgg-image-block {
	border: 1px solid transparent;
	
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	border-radius: 5px;
}

#friend_request_received_listing .elgg-image-block:hover,
#friend_request_sent_listing .elgg-image-block:hover {
	border-color: #cccccc;
}