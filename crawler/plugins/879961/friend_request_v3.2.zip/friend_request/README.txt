= Friend request =
Let users confirm friend requests. Make all friend requests reciprocal.

== Contents ==
1. Features
2. Credits
3. ToDo

== 2. Credits ==
The original idea for this plugin was made by Bosssumon and Zac Hopkinson

== 3. To Do ==
- custom message on request
- admin options for menu options
- notification to requester on accept
