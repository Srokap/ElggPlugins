LiangLeeLogo
=============

Most of Peoples in newbies in coomunity don't no how to change Logo from Header of hide logo from topbar
this plugins is specially designed for those peoples

Features
* Add Header Logo
* If header logo not set it display site name
* Hide Topbar Logo
* Unhide Topbar Logo