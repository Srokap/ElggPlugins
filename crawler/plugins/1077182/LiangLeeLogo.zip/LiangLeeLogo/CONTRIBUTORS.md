Unless otherwise stated within individual files of this package:
