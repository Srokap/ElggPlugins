<?php 
	
	$autorefreshrate = $vars['entity']->autorefreshrate;
	if (!$autorefreshrate) $autorefreshrate = '30';
	
	$addthewire = $vars['entity']->addthewire;
	if (!$addthewire) $addthewire = 'no';
?>
<p>Autodash refresh rate in seconds</p>
<p> 

<?php
	echo elgg_view('input/tags',array('value' => $autorefreshrate,
									  'internalname' =>'params[autorefreshrate]')); ?>
</p>
<?php
?>
<p>
	<?php echo elgg_echo('riverdashboard:useasdashboard'); ?>
	
	<select name="params[useasdashboard]">
		<option value="yes" <?php if ($vars['entity']->useasdashboard == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->useasdashboard != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
	
</p>
