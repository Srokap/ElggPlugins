<?php

function sc_ajax_libs_init() {
  global $CONFIG;
  
  $theme = get_plugin_setting('theme','sc_ajax_libs');
  $scope = get_plugin_setting('scope','sc_ajax_libs');
  
  set_input('sc_theme', $theme);
  set_input('sc_scope', $scope);
  
  if ($cssver = sc_ParseVersion(sc_JQueryUIVersion())) {
    extend_view('css', 'sc_themes/' . $theme . '/css-' . $cssver);
  }
  extend_view('css', 'sc_ajax_libs/css'); 
  
  if (isadminloggedin()) {
    add_menu(elgg_echo('sc_ajax_libs:menu'), $CONFIG->wwwroot . "mod/sc_ajax_libs/");
  }  
}

function sc_JQueryVersion() {
 return  get_plugin_setting('jquery_version','sc_ajax_libs');
}

function sc_JQueryUIVersion() {
 return  get_plugin_setting('jqueryui_version','sc_ajax_libs'); 
}

function sc_ParseVersion($ver) {
  list($major, $minor) = split('[.]', $ver);   
  $cssver = $major . $minor;
  switch($cssver) {
    case '15':
    case '16':
      return '15';
      break;
    case '17':
      return $cssver;
      break;
    default:
      return false;    
      break;
  }
}

function sc_PrototypeEnabled() {
  if($enabled = get_plugin_setting('prototype_enabled','sc_ajax_libs')) {
    $version = get_plugin_setting('prototype_version','sc_ajax_libs');
    return $version;
  }
  return false;    
}

function sc_ScriptaculousEnabled() {
  if($enabled = get_plugin_setting('scriptaculous_enabled','sc_ajax_libs')) {
    $version = get_plugin_setting('scriptaculous_version','sc_ajax_libs');
    return $version;
  }
  return false;    
}

function sc_MootoolsEnabled() {
  if($enabled = get_plugin_setting('mootools_enabled','sc_ajax_libs')) {
    $version = get_plugin_setting('mootools_version','sc_ajax_libs');
    return $version;
  }
  return false;    
}

function sc_DojoEnabled() {
  if($enabled = get_plugin_setting('dojo_enabled','sc_ajax_libs')) {
    $version = get_plugin_setting('dojo_version','sc_ajax_libs');
    return $version;
  }
  return false;    
}

function sc_SWFObjectEnabled() {
  if($enabled = get_plugin_setting('swfobject_enabled','sc_ajax_libs')) {
    $version = get_plugin_setting('swfobject_version','sc_ajax_libs');
    return $version;
  }
  return false;    
}

function sc_YuiEnabled() {
  if($enabled = get_plugin_setting('yui_enabled','sc_ajax_libs')) {
    $version = get_plugin_setting('yui_version','sc_ajax_libs');
    return $version;
  }
  return false;    
}

register_elgg_event_handler('init','system','sc_ajax_libs_init');

?>