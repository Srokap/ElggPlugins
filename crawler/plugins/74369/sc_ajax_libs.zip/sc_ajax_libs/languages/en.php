<?php

	$english = array(
	  'sc_ajax_libs:menu' => 'SC Lib Demo',
    'sc_ajax_libs:jquery' => 'JQuery',
    'sc_ajax_libs:jqueryui' => 'JQueryUI',
    'sc_ajax_libs:scope' => ' Scope:',
    'sc_ajax_libs:disable' => 'Disable',
    'sc_ajax_libs:enable' => 'Enable',
    'sc_ajax_libs:modify' => 'Modify',
    'sc_ajax_libs:version' => ' Version:',
    'sc_ajax_libs:confirm' => 'It is not safe to change these values are you sure you want to proceed?',
    'sc_ajax_libs:warning' => 'Warning! If you change this value certain elgg functionality will not work!',
    'sc_ajax_libs:theme' => ' Theme:',
    'sc_ajax_libs:prototype' => 'Prototype',
    'sc_ajax_libs:scriptaculous' => 'script.aculo.us',
    'sc_ajax_libs:mootools' => 'MooTools',
    'sc_ajax_libs:dojo' => 'Dojo',
    'sc_ajax_libs:swfobject' => 'SWFObject',
    'sc_ajax_libs:yui' => 'YUI'
    
	);
					
	add_translation("en",$english);
?>
