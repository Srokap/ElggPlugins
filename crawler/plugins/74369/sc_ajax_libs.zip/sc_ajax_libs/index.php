<?php
  require_once(dirname(dirname(dirname(__FILE__))) . '/engine/start.php');
  
  admin_gatekeeper();
  
  $body = elgg_view_layout('one_column', elgg_view('sc_ajax_libs/demo'));
  page_draw(elgg_echo('sc_ajax_libs:menu'), $body);
?>