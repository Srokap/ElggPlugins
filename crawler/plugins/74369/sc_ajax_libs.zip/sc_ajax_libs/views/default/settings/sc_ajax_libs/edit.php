<?php
  $entity = $vars['entity'];
  if ($entity) {
    $theme = $entity->theme;
    if (!$theme) $theme = 'smoothness';
    
    $entity->jquery_enabled = 1;
    if (!$entity->jquery_version)
      $entity->jquery_version = '1.2';
      
    $entity->jqueryui_enabled = 1;
    if (!$entity->jqueryui_version)
      $entity->jqueryui_version = '1.5';  
  }
?>
<script>
function sc_ajax_hover($obj) {
  $obj.hover(
    function() {
      $(this).css({'backgroundColor':'#0D58A6'}); 
    },
    function() {
      $(this).css({'backgroundColor':'#4188D2'});
    }
  );  
}

function sc_default_option($obj) {
  $id =  $obj.attr('id');
  sc_ajax_hover($obj);
  $enable = $('#' + $id + '_e');
  $input = $('#' + $id + '_v');
  if ($enable.val() == 1) {
    $obj.empty().append("<?php echo elgg_echo('sc_ajax_libs:disable'); ?>");
    $input.removeAttr('disabled');
    $input.css({'backgroundColor':'#FFFFFF'});
    $obj.css({'color':'#cccccc'}); 
  } else {
    $obj.empty().append("<?php echo elgg_echo('sc_ajax_libs:enable'); ?>");
    $input.css({'backgroundColor':'#DDDDDD'}); 
  }
}

function sc_toggle($obj) {
  $id = $obj.attr('id');
  $enable = $('#' + $id + '_e');
  $input = $('#' + $id + '_v');
  if ($enable.val() != 0) {
    $obj.empty().append("<?php echo elgg_echo('sc_ajax_libs:enable'); ?>");
    $obj.css({'color':'#ffffff'});
    $input.attr("disabled", true);
    $enable.val('0');
    $input.css({'backgroundColor':'#DDDDDD'}); 
  } else {
    $obj.empty().append("<?php echo elgg_echo('sc_ajax_libs:disable'); ?>");
    $obj.css({'color':'#cccccc'});
    $input.removeAttr('disabled');
    $enable.val('1'); 
    $input.css({'backgroundColor':'#FFFFFF'});
  }
}

function sc_toggle_m($obj) {
  $id = $obj.attr('id');
  $msg = $('#' + $id + '_m');
  $input = $('#' + $id + '_v');
  $c = confirm("<?php echo elgg_echo('sc_ajax_libs:confirm'); ?>");
  if ($c == true) { 
    $input.removeAttr('disabled');
    $input.css({'backgroundColor':'#FFFFFF'});
    $obj.hide();
    $msg.css({color:'red'});
    $msg.empty().append("<?php echo elgg_echo('sc_ajax_libs:warning'); ?>");  
  }
}  

$(document).ready(function(){
  $('#jquery').click(
    function() {sc_toggle_m($(this));}
  );
  $('#jqueryui').click(
    function() {sc_toggle_m($(this));}
  );
  $('#prototype').click(
    function() {sc_toggle($(this));}
  );
  $('#scriptaculous').click(
    function() {sc_toggle($(this));}
  );
  $('#mootools').click(
    function() {sc_toggle($(this));}
  );
  $('#dojo').click(
    function() {sc_toggle($(this));}
  );
  $('#swfobject').click(
    function() {sc_toggle($(this));}
  );
  $('#yui').click(
    function() {sc_toggle($(this));}
  );
  sc_ajax_hover($('#jquery'));
  sc_ajax_hover($('#jqueryui'));
  sc_default_option($('#prototype'));
  sc_default_option($('#scriptaculous'));
  sc_default_option($('#mootools'));
  sc_default_option($('#dojo'));
  sc_default_option($('#swfobject'));
  sc_default_option($('#yui'));

});

</script>
<div id="sc_ajax_settings">
<p>
  <label><?php echo elgg_echo('sc_ajax_libs:jquery') . elgg_echo('sc_ajax_libs:theme'); ?></label>
  <?php 
    echo elgg_view('input/pulldown', array(
      'internalname' => 'params[theme]',
      'options' => array(
                    'notheme',
                    'black-tie',
                    'blitzer',
                    'cupertino',
                    'dot-luv',
                    'excite-bike',
                    'hot-sneaks',
                    'humanity',
                    'mint-choc',
                    'redmond',
                    'smoothness',
                    'south-street',
                    'start',
                    'swanky-purse',
                    'trontastic',
                    'ui-darkness',
                    'ui-lightness',
                    'vader'
                    ),
      'value' => $theme
      )); 
  ?>
</p>
<p>
  <label><?php echo elgg_echo('sc_ajax_libs:jquery') . elgg_echo('sc_ajax_libs:scope'); ?></label>
  <input id="scope_v" name="params[jquery_version]" value="<?php echo $entity->jquery_scope; ?>"/>
  <div id="scope_m"></div>
</p>
<p>
  <label><?php echo elgg_echo('sc_ajax_libs:jquery') . elgg_echo('sc_ajax_libs:version'); ?></label>
  <input id="jquery_v" name="params[jquery_version]" disabled="true" value="<?php echo $entity->jquery_version; ?>"/>
  <input id="jquery_e" name="params[jquery_enabled]" type="hidden" value="<?php echo $entity->jquery_enabled; ?>" />
  <span id="jquery" /><?php echo elgg_echo('sc_ajax_libs:modify'); ?></span>
  <div id="jquery_m"></div>
</p>
<p>
  <label><?php echo elgg_echo('sc_ajax_libs:jqueryui') . elgg_echo('sc_ajax_libs:version'); ?></label>
  <input id="jqueryui_v" name="params[jqueryui_version]" disabled="true" value="<?php echo $entity->jqueryui_version; ?>"/>
  <input id="jqueryui_e" name="params[jqueryui_enabled]" type="hidden" value="<?php echo $entity->jqueryui_enabled; ?>" />
  <span id="jqueryui" /><?php echo elgg_echo('sc_ajax_libs:modify'); ?></span>
  <div id="jqueryui_m"></div>
</p>
<p>
  <label><?php echo elgg_echo('sc_ajax_libs:prototype') . elgg_echo('sc_ajax_libs:version'); ?></label>
  <input id="prototype_v" name="params[prototype_version]" disabled="true" value="<?php echo $entity->prototype_version; ?>"/>
  <input id="prototype_e" name="params[prototype_enabled]" type="hidden" value="<?php echo $entity->prototype_enabled; ?>" />
  <span id="prototype" /></span>
  <div id="prototype_m"></div>
</p>
<p>
  <label><?php echo elgg_echo('sc_ajax_libs:scriptaculous') . elgg_echo('sc_ajax_libs:version'); ?></label>
  <input id="scriptaculous_v" name="params[scriptaculous_version]" disabled="true" value="<?php echo $entity->scriptaculous_version; ?>"/>
  <input id="scriptaculous_e" name="params[scriptaculous_enabled]" type="hidden" value="<?php echo $entity->scriptaculous_enabled; ?>" />
  <span id="scriptaculous" /></span>
  <div id="scriptaculous_m"></div>
</p>
<p>
  <label><?php echo elgg_echo('sc_ajax_libs:mootools') . elgg_echo('sc_ajax_libs:version'); ?></label>
  <input id="mootools_v" name="params[mootools_version]" disabled="true" value="<?php echo $entity->mootools_version; ?>"/>
  <input id="mootools_e" name="params[mootools_enabled]" type="hidden" value="<?php echo $entity->mootools_enabled; ?>" />
  <span id="mootools" /></span>
  <div id="mootools_m"></div>
</p>
<p>
  <label><?php echo elgg_echo('sc_ajax_libs:dojo') . elgg_echo('sc_ajax_libs:version'); ?></label>
  <input id="dojo_v" name="params[dojo_version]" disabled="true" value="<?php echo $entity->dojo_version; ?>"/>
  <input id="dojo_e" name="params[dojo_enabled]" type="hidden" value="<?php echo $entity->dojo_enabled; ?>" />
  <span id="dojo" /></span>
  <div id="dojo_m"></div>
</p>
<p>
  <label><?php echo elgg_echo('sc_ajax_libs:swfobject') . elgg_echo('sc_ajax_libs:version'); ?></label>
  <input id="swfobject_v" name="params[swfobject_version]" disabled="true" value="<?php echo $entity->swfobject_version; ?>"/>
  <input id="swfobject_e" name="params[swfobject_enabled]" type="hidden" value="<?php echo $entity->swfobject_enabled; ?>" />
  <span id="swfobject" /></span>
  <div id="swfobject_m"></div>
</p>
<p>
  <label><?php echo elgg_echo('sc_ajax_libs:yui') . elgg_echo('sc_ajax_libs:version'); ?></label>
  <input id="yui_v" name="params[yui_version]" disabled="true" value="<?php echo $entity->yui_version; ?>"/>
  <input id="yui_e" name="params[yui_enabled]" type="hidden" value="<?php echo $entity->yui_enabled; ?>" />
  <span id="yui" /></span>
  <div id="yui_m"></div>
</p>
</div>
<div style="clear:both"></div>