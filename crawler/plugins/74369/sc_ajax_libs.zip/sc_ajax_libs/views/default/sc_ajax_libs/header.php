<script src="http://www.google.com/jsapi"></script>
<script>
  google.load("jquery", "<?php echo sc_JQueryVersion(); ?>");
  //google.load("jqueryui", "1.5");
  google.load("jqueryui", "<?php echo sc_JQueryUIVersion(); ?>");
  <?php if ($pver = sc_PrototypeEnabled()) { ?>
    google.load("prototype", "<?php echo $pver; ?>");
  <?php } ?>
  <?php if ($sver = sc_ScriptaculousEnabled()) { ?>
    google.load("scriptaculous", "<?php echo $sver; ?>");
  <?php } ?>
  <?php if ($mver = sc_MootoolsEnabled()) { ?>
    google.load("mootools", "<?php echo $mver; ?>");
  <?php } ?>
  <?php if ($dver = sc_DojoEnabled()) { ?>
    google.load("dojo", "<?php echo $dver; ?>");
  <?php } ?>
  <?php if ($wver = sc_SWFObjectEnabled()) { ?>
    google.load("swfobject", "<?php echo $wver; ?>");
  <?php } ?>
  <?php if ($yver = sc_YuiEnabled()) { ?>
    google.load("yui", "<?php echo $yver; ?>");
  <?php } ?>  
</script>
