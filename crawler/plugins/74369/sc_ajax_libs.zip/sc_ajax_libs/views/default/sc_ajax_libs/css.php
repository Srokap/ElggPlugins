#sc_ajax_settings {

}

#sc_ajax_settings p{
  margin-bottom: 5px;
}

#sc_ajax_settings span{
 	-webkit-border-radius: 3px; 
	-moz-border-radius: 3px;
  padding: 5px;
  border: 1px solid #000000;
  color: #ffffff;
  background-color: #4188D2;
}

#sc_ajax_settings div{
  text-align:center;
  margin-bottom: 5px;
  clear: both;
}

#sc_ajax_settings label{
  display:block;
  float:left;
  width:300px;
  text-align: right;
  margin-right: 5px;
}

#sc_ajax_settings #jquery_v {
  background-color: #DDDDDD;
}

#sc_ajax_settings #jqueryui_v {
  background-color: #DDDDDD;
}