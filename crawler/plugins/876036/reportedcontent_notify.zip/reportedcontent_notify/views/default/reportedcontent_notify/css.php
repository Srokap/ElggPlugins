
.reportedcontent_notify_adminlist {
  display: inline-block;
  padding: 5px 15px;
}
