<?php

$english = array(
    'reportedcontent_notify' => "Reported Content Notification",
    'reportedcontent_notify:description' => "Select Admins to notify about reported content",
    'reportedcontent_notify:message' => "Some content has been reported:
      
%s

You can view it here: %s",
    'reportedcontent_notify:subject' => "New Reported Content: %s",
);
					
add_translation("en",$english);
