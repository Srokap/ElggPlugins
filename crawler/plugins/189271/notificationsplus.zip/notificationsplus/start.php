<?php

	/**
	 * Elgg notificationsplus plugin
	 * 
	 * @package notificationsplus adapted from curverider notifications
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette <fabrice.Collette@free.fr>
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-conseil.com/
	 */

		
		function notificationsplus_plugin_init() {
      
			global $CONFIG;
			
			// ACtivate event handlers
			register_elgg_event_handler('create','member','notificationsplus_create_member',917);
		}

		register_elgg_event_handler('init','system','notificationsplus_plugin_init');
		
	
	  function notificationsplus_create_member($event, $object_type, $object) {
	  global $CONFIG;
		if (isloggedin()) {
	  if (($object instanceof ElggRelationship) && ($event == 'create') && ($object_type == 'member')) {
	
		$group_guid = get_entity($object->guid_two);
		
		set_input('group',$object->guid_two);
		@include(dirname(__FILE__) . "/setgroupnotification.php");
  	}
	 }
	return true;
	}
		
		
?>