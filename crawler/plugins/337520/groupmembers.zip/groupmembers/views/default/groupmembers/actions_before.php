<?php
/*
    This file is part of of the groups-invite-any plugin.

    Foobar is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Foobar is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with groups-invite-any.  If not, see <http://www.gnu.org/licenses/>.
*/

if (get_context() == 'groups' && get_loggedin_userid() == page_owner_entity()->owner_guid) {
    ?>
<div  class="reportedcontent_content active_report">
    <div class="groups_membershiprequest_buttons">
            <?php
            if ($vars['entity']->getGUID() != page_owner_entity()->owner_guid) {
                echo str_replace('<a', '<a class="delete_report_button" ', elgg_view('output/confirmlink', array(
                'is_action' => true,
                'href' => $vars['url'] . 'action/groupmembers/remove?group_guid=' . page_owner() . '&user_guid=' . $vars['entity']->getGUID(),
                'confirm' => elgg_echo('groupmembers:remove:check'),
                'text' => elgg_echo('delete'),
                )));
            }
            if (check_entity_relationship(page_owner(), 'invited', $vars['entity']->getGUID())) { ?>
        <a href="<?php echo $vars['url']; ?>action/groupmembers/reinvite?user_guid=<?php echo $vars['entity']->getGUID(); ?>&group_guid=<?php echo page_owner() ?>" class="archive_report_button"><?php echo elgg_echo('groupmembers:reinvite'); ?></a><?php
        /*if (check_entity_relationship(page_owner(), 'invited', $vars['entity']->getGUID())) {
            $body = elgg_view('input/hidden', array('internalname' => 'user_guid', 'value' => $vars['entity']->getGUID()));
            $body .= elgg_view('input/hidden', array('internalname' => 'group_guid', 'value' => page_owner()));
            $body .= elgg_view('input/submit',
                array('internalname' => 'submit', 'value' => elgg_echo('groupmembers:reinvite')));
            echo ' ' . elgg_view('input/form', array('body' => $body, 'action' => $vars['url'] . 'action/groupmembers/reinvite'));*/
            }
            ?>
    </div>
<div class="reportedcontent_detail">
        <?php } ?>