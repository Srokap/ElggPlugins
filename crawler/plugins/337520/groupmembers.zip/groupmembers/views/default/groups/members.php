<?php
/*
    This file is part of of the groupmembers plugin.

    Foobar is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Foobar is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with groupmembers.  If not, see <http://www.gnu.org/licenses/>.
*/

    global $CONFIG;
?>

<div id="group_members">
    <h2><a href="<?php echo $CONFIG->wwwroot . 'mod/groupmembers/members.php?group_guid=' .page_owner()?>"><?php echo elgg_echo("groups:members"); ?></a></h2>

<?php

    $members = $vars['entity']->getMembers(10);
    foreach($members as $mem){
           
        echo "<div class=\"member_icon\"><a href=\"".$mem->getURL()."\">" . elgg_view("profile/icon",array('entity' => $mem, 'size' => 'tiny', 'override' => 'true')) . "</a></div>";   
           
    }
    
?>
<div class="clearfloat" /></div>
</div>