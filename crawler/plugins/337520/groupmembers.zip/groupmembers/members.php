<?php
/*
    This file is part of of the groups-invite-any plugin.

    Foobar is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Foobar is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with groups-invite-any.  If not, see <http://www.gnu.org/licenses/>.
*/

require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

gatekeeper();

$group_guid = get_input('group_guid');

set_page_owner($group_guid);
set_context('groups');

$name = get_input('name');

if ($name) {
    $users = search_for_user($name, get_plugin_setting('maxusers', 'groupsfrommembers'));
    $nusers = search_for_user($name, 0, 0, '', true);
}

$title = elgg_echo("groups:members");

$area2 = elgg_view_title($title);
$area2 .= list_entities_from_relationship('member', $group_guid, true, 'user', '', 0, 10, false);
if (get_entities_from_relationship('invited', $group_guid, false, 'user', '', 0, '', 0, 0, true)) {
    $area2 .= elgg_view_title(elgg_echo('groupmembers:invited'));
    $area2 .= list_entities_from_relationship('invited', $group_guid, false, 'user', '', 0, 10, false);
}


//$area2 .= list_entities('user', '', 0, 10, false);


$body = elgg_view_layout('two_column_left_sidebar', $area1, $area2);

page_draw($title, $body);

?>