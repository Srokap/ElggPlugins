<?php

	/**
	 * Elgg youtube widget
	 * This plugin allows users to pull in their youtube video to display on their profile
	 * 
	 * @package Elggyoutube
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Robert Gay <robertg@windango.com>
	 * @copyright Windango, Inc. 2008
	 * @link http://elgg.com/
	 */
	
		function youtube_init() {
    		
    		
    		// Extend system JS with our own javascript, which are defined in the youtube/scripts view
				//extend_view('js','youtube/js/cycle'); //FIND OUT ABOUT THIS?
			
    		//add a widget
			    add_widget_type('youtube',"Youtube","This is your youtube feed");
			
		}
		
		register_elgg_event_handler('init','system','youtube_init');

?>