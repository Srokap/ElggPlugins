<?php

	$english = array(
	
		/**
		 * youtube widget details
		 */
		
	
		'youtube:id' => 'Enter your youtube video url.',
		'youtube:whatisid' => 'If you do not know what your youtube ID is, look for the code after the forward slash v equals in the youtube URL.',
		
		 /**
	     * youtube widget river
	     **/
	        
	        //generic terms to use
	        'youtube:river:created' => "%s added the youtube widget.",
	        'youtube:river:updated' => "%s updated their youtube widget.",
	        'youtube:river:delete' => "%s removed their youtube widget.",
	        
		
	);
					
	add_translation("en",$english);

?>