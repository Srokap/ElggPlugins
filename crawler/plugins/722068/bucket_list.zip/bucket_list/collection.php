<?php

// include the Elgg engine
include_once dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php"; 

// maybe logged in users only?
//gatekeeper();

// get any input
$username = (int) get_input('username');
// if username or owner_guid was not set as input variable, we need to set page owner
// Get the current page's owner
$page_owner = get_entity($username);
$page_owner_guid = $page_owner->guid;
set_page_owner($page_owner_guid);

$owner = page_owner_entity();
	$owner_guid = $owner->guid;
	$user_id = get_loggedin_userid();
if($user_id == $owner_guid){
				$title = elgg_echo('bucket_list:title:yourhome');
			}else{
				$title = $owner->name . elgg_echo('bucket_list:title:home');
			}

// create content for main column
$area1 = elgg_view_title($title);
$area1 .= elgg_view('bucket_list/tab_listing');
$area2 .= elgg_view('bucket_list/stats');

// layout the sidebar and main column using the default sidebar
$body = elgg_view_layout('two_column_left_sidebar', '', $area1, $area2);

// create the complete html page and send to browser
page_draw($title, $body);
