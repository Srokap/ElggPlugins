<?php


	if (!isloggedin()) forward();

	$guid = (int) get_input('bucketlist');
	
	$bucketlist = get_entity($guid);
				
	$on_my_list1 = check_entity_relationship($_SESSION['user']->guid,'bucket_list_incomplete_30', $bucketlist->guid);
	$on_my_list2 = check_entity_relationship($_SESSION['user']->guid,'bucket_list_incomplete_50', $bucketlist->guid);
	$on_my_list3 = check_entity_relationship($_SESSION['user']->guid,'bucket_list_incomplete_80', $bucketlist->guid);
	
	if($on_my_list1 !== FALSE){
	remove_entity_relationship($_SESSION['user']->guid, 'bucket_list_incomplete_30', $bucketlist->guid);
	add_entity_relationship($_SESSION['user']->guid, 'bucket_list_complete_30', $bucketlist->guid);		
	}elseif($on_my_list2 !== FALSE){
	remove_entity_relationship($_SESSION['user']->guid, 'bucket_list_incomplete_50', $bucketlist->guid);
	add_entity_relationship($_SESSION['user']->guid, 'bucket_list_complete_50', $bucketlist->guid);		
	}else{
	remove_entity_relationship($_SESSION['user']->guid, 'bucket_list_incomplete_80', $bucketlist->guid);
	add_entity_relationship($_SESSION['user']->guid, 'bucket_list_complete_80', $bucketlist->guid);		
	}
	
	add_to_river('river/object/bucket_list/complete','complete',$_SESSION['user']->guid,$bucketlist->guid);
	
	system_message(elgg_echo("bucketlist:item:complete"));
	
	forward($vars['url'] . "pg/bucketlist/{$_SESSION['user']->username}");
	
?>