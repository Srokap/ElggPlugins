<?php

	/**
	 * Elgg Jobs Plugin
	 * @package forked from Slyhne's market plugin
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Callum West
	 * @copyright TEAonline
	 * @link www.teaonline.ws
	 */

	// Make sure we're logged in (send us to the front page if not)
		if (!isloggedin()) forward();
		$user = get_loggedin_user();
		
	// Get input data
		$title = get_input('title');
		$body = get_input('bucketlist_description');
		$tags = get_input('bucketlist_tags');
		$age = get_input('bucketlist_age');
		
		
	// Cache to the session
		$_SESSION['title'] = $title;
		$_SESSION['bucketlist_description'] = $body;
		$_SESSION['bucketlist_tags'] = $tags;
		$_SESSION['bucketlist_age'] = $age;
		
	// Convert string of tags into a preformatted array
		$tagarray = string_to_tag_array($tags);
		
	// Make sure the title / description aren't blank
		if (empty($title) || empty($body)) {
			register_error(elgg_echo("bucketlist:item:add:blank"));
			forward("pg/bucketlist/" . $user->name . "/add");
			
	// Start Saving the Post
		} else {
		
	/** Lets deal with creating the post
	------------------------------------------------------------
	*/
	// Initialise a new ElggObject
			$bucketlist = new ElggObject();
			
	// Tell the system it's an market post
			$bucketlist->subtype = "bucketlist";
			
	// Set its owner to the current user
			$bucketlist->owner_guid = $_SESSION['user']->guid;
			
	// Set its access_id
			$bucketlist->access_id = 1;
			
	// Set its title and description appropriately
			$bucketlist->title = $title;
			$bucketlist->bucketlist_description = $body;
			$bucketlist->bucketlist_tags = $tags;
			
	// Before we can set metadata, we need to save the market post
			if (!$bucketlist->save()) {
				register_error(elgg_echo("bucketlist:item:add:error"));
				forward("pg/bucketlist/" . $user->name . "/add");
			}
			
	// Now let's add tags
			if (is_array($tagarray)) {
				$bucketlist->bucketlist_tags = $tagarray;
			}
			if($age == 30){
				add_entity_relationship($_SESSION['user']->guid, 'bucket_list_incomplete_30', $bucketlist->guid);
			}elseif($age == 50){
				add_entity_relationship($_SESSION['user']->guid, 'bucket_list_incomplete_50', $bucketlist->guid);
			}else{
				add_entity_relationship($_SESSION['user']->guid, 'bucket_list_incomplete_80', $bucketlist->guid);
			}
			
	
			
	// Success message
			system_message(elgg_echo("bucketlist:item:posted"));
			
	// Add to river
	        add_to_river('river/object/bucket_list/create','create',$_SESSION['user']->guid,$bucketlist->guid);
			
	// Remove the job post cache
			unset($_SESSION['title']); unset($_SESSION['bucketlist_description']); unset($_SESSION['bucketlist_tags']);unset($_SESSION['bucketlist_age']);
			remove_metadata($_SESSION['user']->guid,'title');
			remove_metadata($_SESSION['user']->guid,'bucketlist_description');
			remove_metadata($_SESSION['user']->guid,'bucketlist_tags');
			remove_metadata($_SESSION['user']->guid,'bucketlist_age');
			// Forward to the main job page
			forward("pg/bucketlist/" . $user->name);
		}
?>
