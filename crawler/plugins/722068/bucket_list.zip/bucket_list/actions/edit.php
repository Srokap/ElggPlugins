<?php

	

	// Make sure we're logged in (send us to the front page if not)
		if (!isloggedin()) forward();

	// Get input data
		$guid = (int) get_input('bucketlist');
		$title = get_input('title');
		$body = get_input('bucketlist_description');
		$tags = get_input('bucketlist_tags');
		$access = get_input('access_id');
		
	// Make sure we actually have permission to edit
		$bucketlist = get_entity($guid);
		if ($bucketlist->getSubtype() == "bucketlist" && $bucketlist->canEdit()) {
	
		// Cache to the session
			$_SESSION['title'] = $title;
			$_SESSION['bucketlist_description'] = $body;
			$_SESSION['bucketlist_tags'] = $tags;
			
		// Convert string of tags into a preformatted array
			$tagarray = string_to_tag_array($tags);
			
		// Make sure the title / description aren't blank
		if (empty($title) || empty($body)) {
			register_error(elgg_echo("bucketlist:item:add:blank"));
			forward("pg/bucketlist/" . $user->name . "/edit");
				
		// Otherwise, save the item 
			} else {
				
		// Get owning user
				$owner = get_entity($bucketlist->getOwner());
				$bucketlist->access_id = $access;
		// Set its title and description appropriately
				$bucketlist->title = $title;
				$bucketlist->bucketlist_description = $body;
				
		// Before we can set metadata, we need to save the item
				if (!$bucketlist->save()) {
				register_error(elgg_echo("bucketlist:item:edit:error"));
					forward("mod/bucketlist/edit.php?bucketlist=" . $guid);
				}
		// Now let's add tags. We can pass an array directly to the object property! Easy.
				$bucketlist->clearMetadata('bucketlist_tags');
				if (is_array($tagarray)) {
				$bucketlist->product_tags = $tagarray;
			}

		// Success message
				system_message(elgg_echo("bucketlist:item:edited"));
		// add to river
				add_to_river('river/object/bucket_list/update','update',$_SESSION['user']->guid,$bucketlist->guid);
		// Remove the item cache
			unset($_SESSION['title']); unset($_SESSION['bucketlist_description']); unset($_SESSION['bucketlist_tags']);
			remove_metadata($_SESSION['user']->guid,'title');
			remove_metadata($_SESSION['user']->guid,'bucketlist_description');
			remove_metadata($_SESSION['user']->guid,'bucketlist_tags');;
		
			// Forward to the main bucketlist page
			forward($vars['url'] . "pg/bucketlist/" . $_SESSION['user']->username);
			}
		
		}
		
?>
