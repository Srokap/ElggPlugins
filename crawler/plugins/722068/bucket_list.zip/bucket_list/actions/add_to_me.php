<?php


	if (!isloggedin()) forward();

	$guid = (int) get_input('bucketlist');
	$age = (int) get_input('age');
	$bucketlist = get_entity($guid);
				
	$on_my_list1 = check_entity_relationship($_SESSION['user']->guid,'bucket_list_incomplete_30', $bucketlist->guid);
	$on_my_list2 = check_entity_relationship($_SESSION['user']->guid,'bucket_list_incomplete_50', $bucketlist->guid);
	$on_my_list3 = check_entity_relationship($_SESSION['user']->guid,'bucket_list_incomplete_80', $bucketlist->guid);
	$on_my_list4 = check_entity_relationship($_SESSION['user']->guid,'bucket_list_complete_30', $bucketlist->guid);
	$on_my_list5 = check_entity_relationship($_SESSION['user']->guid,'bucket_list_complete_50', $bucketlist->guid);
	$on_my_list6 = check_entity_relationship($_SESSION['user']->guid,'bucket_list_complete_80', $bucketlist->guid);

	$listed = array($on_my_list1, $on_my_list2, $on_my_list3,$on_my_list4, $on_my_list5, $on_my_list6);
	foreach($listed as $list){
		if($list !== FALSE){
			register_error(elgg_echo("bucketlist:item:add:already"));
				forward("pg/bucketlist/" . $user->name);
		}else{
			
			if($age == 'bucket_list_incomplete_30'){
				add_entity_relationship($_SESSION['user']->guid, 'bucket_list_incomplete_30', $bucketlist->guid);
			}elseif($age == 'bucket_list_incomplete_50'){
				add_entity_relationship($_SESSION['user']->guid, 'bucket_list_incomplete_50', $bucketlist->guid);
			}elseif($age == 'bucket_list_incomplete_80'){
				add_entity_relationship($_SESSION['user']->guid, 'bucket_list_incomplete_80', $bucketlist->guid);
			}	

	
	add_to_river('river/object/bucket_list/create','create',$_SESSION['user']->guid,$bucketlist->guid);
	
	system_message(elgg_echo("bucketlist:item:added"));
	
	forward($vars['url'] . "pg/bucketlist/{$_SESSION['user']->username}");
	}}
?>