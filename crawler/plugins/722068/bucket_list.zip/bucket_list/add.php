<?php

// include the Elgg engine
include_once dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php"; 

// maybe logged in users only?
gatekeeper();
$page_owner = page_owner_entity();
		if ($page_owner === false || is_null($page_owner)) {
			$page_owner = $_SESSION['user'];
			set_page_owner($_SESSION['guid']);
		}

$title = elgg_echo('bucket_list:title:add');

// create content for main column
$area1 = elgg_view_title($title);
$area1 .= elgg_view('bucket_list/forms/add');
$area2 .= elgg_view('bucket_list/stats');

// layout the sidebar and main column using the default sidebar
$body = elgg_view_layout('two_column_left_sidebar', '', $area1, $area2);

// create the complete html page and send to browser
page_draw($title, $body);
