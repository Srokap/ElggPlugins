<?php
if (isset($vars['entity'])) {
		
		$edit = elgg_echo('edit');
		$url = $vars['url'];
		$itemlink = $vars['entity']->getURL();
		$GUID = $vars['entity']->getGUID();
		if ($vars['entity']->canEdit()) {
		$delete_button = elgg_view("output/confirmlink",array(
				'href' => $vars['url'] . "action/bucket_list/delete?bucketlist=" . $vars['entity']->getGUID(),
				'text' => elgg_echo('delete'),
				'confirm' => elgg_echo('deleteconfirm'),
				'class' => "market_delete_button"
								));
		$complete_link = elgg_view("output/confirmlink", array(
						'href' => $vars['url'] . "action/bucket_list/completer?bucketlist=" . $vars['entity']->getGUID(),
						'text' => elgg_echo('Complete'),
						'confirm' => elgg_echo('bucketlist:item:complete:sure'),
						));
		$edit_button = "<a class=\"market_button\" href=\"{$url}mod/bucket_list/edit.php?bucketlist={$GUID}\">{$edit}</a>";
		}
		$ownerGUID = $vars['entity']->getOwnerEntity()->guid;
		$user = page_owner_entity();
		$num_comments = elgg_count_comments($vars['entity']);
   		$comments = $num_comments . " " . sprintf(elgg_echo("bucketlist:item:replies"));
   		$comment_url = "";
   		$full_view = "<a style='cursor:pointer;'>{$comments}</a>";
		
		// Should we show full view?
		if (isset($vars['full']) && $vars['full'] == true) {
				$fullview = true;
		}
	
		if (get_context() == "search") {
				
			//display the correct layout depending on gallery or list view
			if (get_input('search_viewtype') == "gallery") {

				//display the gallery view
       				echo elgg_view("bucket_list/gallery",$vars);

			} else {
				
				echo elgg_view("bucket_list/listing",$vars);

			}
				
		} else {
?>
	<div class="contentWrapper">
<?php
			echo "<h2>" . $vars['entity']->title . "</h2>";
			
			echo $vars['entity']->bucketlist_description;
			
			$com = "<img src='{$vars['url']}mod/bucket_list/graphics/tick.png' title='Completed' style='vertical-align:text-top;'>";
			$incom = "<img src='{$vars['url']}mod/bucket_list/graphics/cross.png' title='Incomplete' style='vertical-align:text-top;'>";
			
			$com_30 = elgg_get_entities_from_relationship(array('relationship' => 'bucket_list_complete_30', 'relationship_guid' => $vars['entity']->guid, 'inverse_relationship' => TRUE, 'count' => TRUE));	
			$com_50 = elgg_get_entities_from_relationship(array('relationship' => 'bucket_list_complete_50', 'relationship_guid' => $vars['entity']->guid, 'inverse_relationship' => TRUE, 'count' => TRUE));	
			$com_80 = elgg_get_entities_from_relationship(array('relationship' => 'bucket_list_complete_80', 'relationship_guid' => $vars['entity']->guid, 'inverse_relationship' => TRUE, 'count' => TRUE));	
			$count_com = ($com_30 + $com_50 + $com_80);
			if((!$count_com) || ($count_com == 0)) {
				$count_com = 0;
			}
			$total_com = $com . " ({$count_com}) ";
			
			$incom_30 = elgg_get_entities_from_relationship(array('relationship' => 'bucket_list_incomplete_30', 'relationship_guid' => $vars['entity']->guid, 'inverse_relationship' => TRUE, 'count' => TRUE));	
			$incom_50 = elgg_get_entities_from_relationship(array('relationship' => 'bucket_list_incomplete_50', 'relationship_guid' => $vars['entity']->guid, 'inverse_relationship' => TRUE, 'count' => TRUE));	
			$incom_80 = elgg_get_entities_from_relationship(array('relationship' => 'bucket_list_incomplete_80', 'relationship_guid' => $vars['entity']->guid, 'inverse_relationship' => TRUE, 'count' => TRUE));	
			$count_incom = ($incom_30 + $incom_50 + $incom_80);
			if((!$count_incom) || ($count_incom == 0)) {
				$count_incom = 0;
			}
			$total_incom = $incom . " ({$count_incom}) ";
			
			echo $total_com . "<br>";
			echo $total_incom;
			
			if($vars['entity'] instanceof ElggObject){
		// If we've been asked to display the full view
			echo elgg_view_comments($vars['entity']);
			}
?>
</div>
<?php
}}
?>
