<?php

	$performed_by = get_entity($vars['item']->subject_guid); // $statement->getSubject();
	$object = get_entity($vars['item']->object_guid);
	$url = $object->getURL();
	
	$url = "<a href=\"{$performed_by->getURL()}\">{$performed_by->name}</a>";
	$contents = strip_tags($object->description); //strip tags from the contents to stop large images etc blowing out the river view
	$string = sprintf(elgg_echo("bucketlist:river:created"),$url) . " ";
	$string .= elgg_echo("bucketlist:river:create") . " <a href=\"" . $vars['url'] . "pg/bucketlist/{$performed_by->username}" . "\">" . $object->title . "</a>";
	echo $string;
?>