
<script>
$(document).ready(function(){
	  $("#bl_toggle_<?php echo $vars['entity']->guid;?>").click(function(){
	  $("#bl_cont_<?php echo $vars['entity']->guid;?>").slideToggle("fast");
	 });}); 
</script>
<?php
		
		$me = page_owner_entity();
		$owner = $vars['entity']->getOwnerEntity();
		
		$on_my_list1 = check_entity_relationship($me->guid,'bucket_list_complete_30', $vars['entity']->guid);
		if($on_my_list1 !== FALSE){
			$done = true;
		}else{
		$on_my_list2 = check_entity_relationship($me->guid,'bucket_list_complete_50', $vars['entity']->guid);
		if($on_my_list2 !== FALSE){
			$done = true;
		}else{
		$on_my_list3 = check_entity_relationship($me->guid,'bucket_list_complete_80', $vars['entity']->guid);
		if($on_my_list3 !== FALSE){
			$done = true;
		}else{
		}}}
		
		
		$com = "<img src='{$vars['url']}mod/bucket_list/graphics/tick.png' title='Completed' style='vertical-align:text-top;'>";
		$incom = "<img src='{$vars['url']}mod/bucket_list/graphics/cross.png' title='Incomplete' style='vertical-align:text-top;'>";
		
		$com_30 = elgg_get_entities_from_relationship(array('relationship' => 'bucket_list_complete_30', 'relationship_guid' => $vars['entity']->guid, 'inverse_relationship' => TRUE, 'count' => TRUE));	
		$com_50 = elgg_get_entities_from_relationship(array('relationship' => 'bucket_list_complete_50', 'relationship_guid' => $vars['entity']->guid, 'inverse_relationship' => TRUE, 'count' => TRUE));	
		$com_80 = elgg_get_entities_from_relationship(array('relationship' => 'bucket_list_complete_80', 'relationship_guid' => $vars['entity']->guid, 'inverse_relationship' => TRUE, 'count' => TRUE));	
		$count_com = ($com_30 + $com_50 + $com_80);
		if((!$count_com) || ($count_com == 0)) {
			$count_com = 0;
		}
		$total_com = $com . " ({$count_com}) | ";
		
		$incom_30 = elgg_get_entities_from_relationship(array('relationship' => 'bucket_list_incomplete_30', 'relationship_guid' => $vars['entity']->guid, 'inverse_relationship' => TRUE, 'count' => TRUE));	
		$incom_50 = elgg_get_entities_from_relationship(array('relationship' => 'bucket_list_incomplete_50', 'relationship_guid' => $vars['entity']->guid, 'inverse_relationship' => TRUE, 'count' => TRUE));	
		$incom_80 = elgg_get_entities_from_relationship(array('relationship' => 'bucket_list_incomplete_80', 'relationship_guid' => $vars['entity']->guid, 'inverse_relationship' => TRUE, 'count' => TRUE));	
		$count_incom = ($incom_30 + $incom_50 + $incom_80);
		if((!$count_incom) || ($count_incom == 0)) {
			$count_incom = 0;
		}
		$total_incom = $incom . " ({$count_incom}) ";
		
		
    	$num_comments = elgg_count_comments($vars['entity']);
 		$url = $vars['entity']->getURL();
// 		$comments = "<a rel='facebox' href='{$url}'>" . $num_comments . " " . sprintf(elgg_echo("bucketlist:item:replies")) . "</a> | ";

		if ($vars['entity']->canEdit()) {
		$edit_link = "<a href=\"".$vars['url']."mod/bucket_list/edit.php?bucketlist=".$vars['entity']->getGUID()."\">".elgg_echo("edit")."</a>";
		$edit_link .= " | ";
		
		$delete_link = elgg_view("output/confirmlink", array(
						'href' => $vars['url'] . "action/bucket_list/delete?bucketlist=" . $vars['entity']->getGUID(),
						'text' => elgg_echo('delete'),
						'confirm' => elgg_echo('deleteconfirm'),
									));
		$delete_link .= " | ";
		}
		if($_SESSION['user'] == $me){
		$complete_link = elgg_view("output/confirmlink", array(
						'href' => $vars['url'] . "action/bucket_list/completer?bucketlist=" . $vars['entity']->getGUID(),
						'text' => elgg_echo('Complete'),
						'confirm' => elgg_echo('bucketlist:item:complete:sure'),
									));
		$complete_link .= " | ";
		}
		$sesh = get_loggedin_userid();
		if($sesh !== $me->guid){
			$have_it_30_com = check_entity_relationship($_SESSION['user']->guid,'bucket_list_complete_30', $vars['entity']->guid);							
			$have_it_30_incom = check_entity_relationship($_SESSION['user']->guid,'bucket_list_incomplete_30', $vars['entity']->guid);							
			$have_it_50_com = check_entity_relationship($_SESSION['user']->guid,'bucket_list_complete_50', $vars['entity']->guid);							
			$have_it_50_incom = check_entity_relationship($_SESSION['user']->guid,'bucket_list_incomplete_50', $vars['entity']->guid);							
			$have_it_80_com = check_entity_relationship($_SESSION['user']->guid,'bucket_list_complete_80', $vars['entity']->guid);							
			$have_it_80_incom = check_entity_relationship($_SESSION['user']->guid,'bucket_list_incomplete_80', $vars['entity']->guid);							
			$rels = array($have_it_30_com, $have_it_30_incom, $have_it_50_com, $have_it_50_incom, $have_it_80_com, $have_it_80_incom);
			foreach ($rels as $rel){
			if($rel !== FALSE){
				$add_30 = "";
				$add_50 = "";
				$add_80 = "";
				break;
			}else{
				$add_30 = elgg_view("output/confirmlink", array('href' => $vars['url'] . "action/bucket_list/add_to_me?bucketlist=" . $vars['entity']->getGUID() . "&age=bucket_list_incomplete_30",'text' => elgg_echo('bucketlist:add_me:30'),'confirm' => elgg_echo('bucketlist:item:add_me:sure'),));							
				$add_30 .= " | ";
				$add_50 = elgg_view("output/confirmlink", array('href' => $vars['url'] . "action/bucket_list/add_to_me?bucketlist=" . $vars['entity']->getGUID() . "&age=bucket_list_incomplete_50",'text' => elgg_echo('bucketlist:add_me:50'),'confirm' => elgg_echo('bucketlist:item:add_me:sure'),));							
				$add_50 .= " | ";
				$add_80 = elgg_view("output/confirmlink", array('href' => $vars['url'] . "action/bucket_list/add_to_me?bucketlist=" . $vars['entity']->getGUID() . "&age=bucket_list_incomplete_80",'text' => elgg_echo('bucketlist:add_me:80'),'confirm' => elgg_echo('bucketlist:item:add_me:sure'),));										
				$add_80 .= " | ";
			}
		}
	}
		$toggle = "<img id='bl_toggle_{$vars['entity']->guid}' src='{$vars['url']}mod/bucket_list/graphics/toggle.png' style='float:right;'>";
					
		if($done == true){
			$info = "<div id='bucketlist_done'>";
			$info .= "<h3><a rel='facebox' href='{$vars['entity']->getURL()}'>" . $vars['entity']->title . "</a>{$toggle}</h3>";
			$info .= "<div class='bucketlist_content' id='bl_cont_{$vars['entity']->guid}'>";
			$info .= $vars['entity']->bucketlist_description . "<br>";
			$info .= elgg_view("elggx_fivestar/elggx_fivestar", array('entity' => $vars['entity']));
			$info .= $edit_link . $delete_link . $add_30 . $add_50 . $add_80 . $comments . $total_com . $total_incom;
			$info .= "</div></div>";
			echo $info;
		}else{
			$info = "<div id='bucketlist_not_done'>";
			$info .= "<h3><a rel='facebox' href='{$vars['entity']->getURL()}'>" . $vars['entity']->title . "</a>{$toggle}</h3>";
			$info .= "<div class='bucketlist_content' id='bl_cont_{$vars['entity']->guid}'>";
			$info .= $vars['entity']->bucketlist_description . "<br>";
			$info .= elgg_view("elggx_fivestar/elggx_fivestar", array('entity' => $vars['entity']));
			$info .= $edit_link . $delete_link . $complete_link . $add_30 . $add_50 . $add_80 . $comments . $total_com . $total_incom;
			$info .= "</div></div>";
			echo $info;
		}
		
		
?>
