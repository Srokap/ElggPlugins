<?php
	global $CONFIG;
	
	 
	 $user = page_owner_entity();
	 $user_id = $user->guid;
	 
	 //url
	 $filter = get_input("filter");
	 if (!$filter) {
		// active discussions is the default
		$filter = "30";
	}
	 $url = $vars['url'] . "pg/bucketlist/{$user->name}";
?>



<div id="elgg_horizontal_tabbed_nav">
<ul>
	<li <?php if($filter == "30") echo "class='selected'"; ?>><a href="<?php echo $url; ?>?filter=30"><?php echo elgg_echo('bucketlist:tabs:30'); ?></a></li>
	<li <?php if($filter == "50") echo "class='selected'"; ?>><a href="<?php echo $url; ?>?filter=50"><?php echo elgg_echo('bucketlist:tabs:50'); ?></a></li>
	<li <?php if($filter == "80") echo "class='selected'"; ?>><a href="<?php echo $url; ?>?filter=80"><?php echo elgg_echo('bucketlist:tabs:80'); ?></a></li>
</ul>
</div>
<?php
	// Get objects
	$context = get_context();
	
	set_context('search');
	
		switch($filter){
			case 'default':
			case "30":
			$completes = list_entities_from_relationship('bucket_list_complete_30',$user_id,$inverse_relationship = false,$type = 'object',$subtype = 'bucketlist',$owner_guid = '',$limit = '',$fullview = false,$viewtypetoggle = false,$pagination = false,$order_by = '');
			echo $completes;
			if (!$completes){
				echo elgg_echo('bucketlist:completed:none');
			}
			echo "<hr>";
			$incompletes = list_entities_from_relationship('bucket_list_incomplete_30',$user_id,$inverse_relationship = false,$type = 'object',$subtype = 'bucketlist',$owner_guid = '',$limit = '',$fullview = false,$viewtypetoggle = false,$pagination = false,$order_by = '');
			echo $incompletes;
			if (!$incompletes){
				echo elgg_echo('bucketlist:notcompleted:none');
			}
			break;
			
			case "50":
			$completes = list_entities_from_relationship('bucket_list_complete_50',$user_id,$inverse_relationship = false,$type = 'object',$subtype = 'bucketlist',$owner_guid = '',$limit = '',$fullview = false,$viewtypetoggle = false,$pagination = false,$order_by = '');
			echo $completes;
			if (!$completes){
				echo elgg_echo('bucketlist:completed:none');
			}
			echo "<hr>";
			$incompletes = list_entities_from_relationship('bucket_list_incomplete_50',$user_id,$inverse_relationship = false,$type = 'object',$subtype = 'bucketlist',$owner_guid = '',$limit = '',$fullview = false,$viewtypetoggle = false,$pagination = false,$order_by = '');
			echo $incompletes;
			if (!$incompletes){
				echo elgg_echo('bucketlist:notcompleted:none');
			}
			break;
			
			case "80":
			$completes = list_entities_from_relationship('bucket_list_complete_80',$user_id,$inverse_relationship = false,$type = 'object',$subtype = 'bucketlist',$owner_guid = '',$limit = '',$fullview = false,$viewtypetoggle = false,$pagination = false,$order_by = '');
			echo $completes;
			if (!$completes){
				echo elgg_echo('bucketlist:completed:none');
			}
			echo "<hr>";
			$incompletes = list_entities_from_relationship('bucket_list_incomplete_80',$user_id,$inverse_relationship = false,$type = 'object',$subtype = 'bucketlist',$owner_guid = '',$limit = '',$fullview = false,$viewtypetoggle = false,$pagination = false,$order_by = '');
			echo $incompletes;
			if (!$incompletes){
				echo elgg_echo('bucketlist:notcompleted:none');
			}
			break;
		}
?>


