<?php

	$owner = page_owner_entity();
	$owner_id = page_owner();
	$user_id = get_loggedin_userid();
	
	$com_30 = elgg_get_entities_from_relationship(array('relationship' => 'bucket_list_complete_30', 'relationship_guid' => $owner_id, 'inverse_relationship' => FALSE, 'count' => TRUE));	
	$com_50 = elgg_get_entities_from_relationship(array('relationship' => 'bucket_list_complete_50', 'relationship_guid' => $owner_id, 'inverse_relationship' => FALSE, 'count' => TRUE));	
	$com_80 = elgg_get_entities_from_relationship(array('relationship' => 'bucket_list_complete_80', 'relationship_guid' => $owner_id, 'inverse_relationship' => FALSE, 'count' => TRUE));	

	$incom_30 = elgg_get_entities_from_relationship(array('relationship' => 'bucket_list_incomplete_30', 'relationship_guid' => $owner_id, 'inverse_relationship' => FALSE, 'count' => TRUE));	
	$incom_50 = elgg_get_entities_from_relationship(array('relationship' => 'bucket_list_incomplete_50', 'relationship_guid' => $owner_id, 'inverse_relationship' => FALSE, 'count' => TRUE));	
	$incom_80 = elgg_get_entities_from_relationship(array('relationship' => 'bucket_list_incomplete_80', 'relationship_guid' => $owner_id, 'inverse_relationship' => FALSE, 'count' => TRUE));	

	$total_30 = ($com_30 + $incom_30);
	$total_50 = ($com_50 + $incom_50);
	$total_80 = ($com_80 + $incom_80);
?>

<div id="bucket_list_stats">
	<div id="bucket_list_stats_content">
		<?php 
			if($user_id == $owner_id){
				echo "<h3>" . elgg_echo('bucketlist:stats:yourtitle') . "</h3>";
			}else{
				echo "<h3>" . $owner->name . elgg_echo('bucketlist:stats:title') . "</h3>";
			}
		?>
		<div class="bucket_list_stats_box">
		<?php 
			
			echo "<h4>" . elgg_echo('bucketlist:tabs:30') . "</h4>";
			echo "<span class='complete'>" . elgg_echo('bucketlist:count:complete') . ": " . $com_30 . "</span><br>";
			echo "<span class='incomplete'>" . elgg_echo('bucketlist:count:incomplete') . ": " . $incom_30 . "</span><br>";
			echo elgg_echo('bucketlist:count:total') . ": " . $total_30 . "<br>";
		?>
		</div>
		<div class="bucket_list_stats_box">
		<?php 
			
			echo "<h4>" . elgg_echo('bucketlist:tabs:50') . "</h4>";
			echo "<span class='complete'>" . elgg_echo('bucketlist:count:complete') . ": " . $com_50 . "</span><br>";
			echo "<span class='incomplete'>" . elgg_echo('bucketlist:count:incomplete') . ": " . $incom_50 . "</span><br>";
			echo elgg_echo('bucketlist:count:total') . ": " . $total_50 . "<br>";
		?>
		</div>
		<div class="bucket_list_stats_box">
		<?php 
			echo "<h4>" . elgg_echo('bucketlist:tabs:80') . "</h4>";
			echo "<span class='complete'>" . elgg_echo('bucketlist:count:complete') . ": " . $com_80 . "</span><br>";
			echo "<span class='incomplete'>" . elgg_echo('bucketlist:count:incomplete') . ": " . $incom_80 . "</span><br>";
			echo elgg_echo('bucketlist:count:total') . ": " . $total_80 . "<br>";
		?>
		</div>
	</div>
</div>