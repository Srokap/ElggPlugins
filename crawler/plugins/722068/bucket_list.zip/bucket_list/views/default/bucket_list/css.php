/* CSS for bucket_list begin */

#bucket_list_stats {
	margin: 10px 0 10px 0;
	padding: 0;
	background: none;
}
#bucket_list_stats_content {
	margin: 0;
	padding: 5px;
}
#bucket_list_stats_content h3 {
	text-align: center;
}
.bucket_list_stats_box {
	margin: 0;
	padding: 4px;
	background: none;
	border: none;
}
#bucketlist_not_done {
	margin: 0 0 5px 0;
	padding: 5px;
	background: #FFFFFF;
	border: 3px solid #FA7373;
	width: 98%;
}
#bucketlist_done {
	margin: 0 0 5px 0;
	padding: 5px;
	background: #FFFFFF;
	border: 3px solid #72A379;
	width: 98%;
}
#bucketlist {
	margin: 0 0 5px 0;
	padding: 5px;
	background: #FFFFFF;
	border: 3px solid #A6A6A6;
	width: 98%;
}
.complete {
	color: #72A379;
}
.incomplete {
	color: #FA7373;
}
.bucketlist_content {
	display:none;
}



/* CSS for bucket_list end */
