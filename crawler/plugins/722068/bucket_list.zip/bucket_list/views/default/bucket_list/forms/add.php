<?php

	/**
	 * Elgg Jobs Plugin
	 * @package forked from Slyhne's market plugin
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Callum West
	 * @copyright TEAonline
	 * @link www.teaonline.ws
	 */

	// Set title, form destination
		if (isset($vars['entity'])) {
			$title = sprintf(elgg_echo("jobs:editpost"),$object->title);
			$action = "bucket_list/edit";
			$title = $vars['entity']->title;
			$body = $vars['entity']->bucketlist_description;
			$tags = $vars['entity']->bucketlist_tags;
			$access_id = $vars['entity']->access_id;
		} else {
			$title = elgg_echo("jobs:addpost");
			$action = "bucket_list/add";
			$tags = "";
			$title = "";
			$body = "";
			$access_id = 1;
		}

	// Just in case we have some cached details
		if (isset($vars['bucketlist_title'])) {
			$title = $vars['title'];
			$body = $vars['bucketlist_description'];
			$tags = $vars['bucketlist_tags'];
		}


?>
<div class="contentWrapper">

<form 
	action="<?php echo $vars['url']; ?>action/<?php echo $action; ?>" 
	enctype="multipart/form-data" 
	method="post" 
	name="BucketListForm"
	>
  <?php echo elgg_view('input/securitytoken') ?>
  <p> 
    <strong><?php echo elgg_echo("bucketlist:item:add:name"); ?></strong>
    <?php
	echo elgg_view("input/text", array(
					"internalname" => "title",
					"value" => $title,
					));
    ?>
  </p>
  <p>
     <strong><?php echo elgg_echo("bucketlist:item:add:description"); ?></strong><br>
<?php
		echo elgg_view("input/longtext", array("internalname" => "bucketlist_description", "value" => $body));
?>
	</p>
  	
	<p>
	<strong><?php echo elgg_echo("bucketlist:item:add:tags"); ?><br></strong>
    <?php
			echo elgg_view("input/tags", array(
			"internalname" => "bucketlist_tags",
			"value" => $tags,
			));
			?>
	
  	</p>
  		
  	<p> 
    <strong><?php echo elgg_echo("bucketlist:item:add:age"); ?><br></strong>
    <?php
			echo elgg_view("input/pulldown", array(
			'value'=>"$bucketlist_age",'internalname' => 'bucketlist_age','options_values' => array (
			"30"=>elgg_echo('bucketlist:tabs:30')
			,"50"=>elgg_echo('bucketlist:tabs:50')
			,"80"=>elgg_echo('bucketlist:tabs:80')
			)
			));
			?>
    
  	</p>
  
  	
  	
		<p>
		<?php
		if (isset($vars['entity'])) {
			echo "<input type=\"hidden\" name=\"bucketlist\" value=\"".$vars['entity']->getGUID()."\" />";
		}
		?>

		</p>
		<p>
			<input type="submit" name="submit" value="<?php echo elgg_echo('save'); ?>" />
		</p>
	
	</form></div>
