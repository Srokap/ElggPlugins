<div class="contentWrapper">
<?php
$num = $vars['entity']->num_display;

//if no number has been set, default to 4
if (!$num) {
	$num = 4;
}

$context = get_context();
set_context('search');
$content = elgg_list_entities(array('types' => 'object', 'subtypes' => 'bucketlist', 'container_guid' => $vars['entity']->owner_guid, 'limit' => $num, 'full_view' => FALSE, 'pagination' => FALSE));
set_context($context);

echo $content;

if ($content) {
	$url = $vars['url'] . "pg/bucketlist/" . page_owner_entity()->username;
	echo "<div class=\"widget_more_wrapper\"><a href=\"{$url}\">".elgg_echo('bucketlist:fulllist')."</a></div>";
}
?>
</div>