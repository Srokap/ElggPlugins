<?php
/**
 * bucket_list
 *
 * @author Callum
 */

function bucket_list_init() {
	global $CONFIG;

	extend_view('css','bucket_list/css');
	elgg_extend_view('profile/menu/links','bucket_list/menu');

	add_widget_type('bucket_list', elgg_echo('bucketlist:widget:title'), 'Description of my widget');


	register_page_handler('bucketlist','bucket_list_page_handler');

	$user = get_loggedin_user();
	add_menu(elgg_echo('bucket_list:menu:link'), $CONFIG->wwwroot . 'pg/bucketlist/' . $user->username);


	register_elgg_event_handler('pagesetup','system','bucket_list_submenus');
	
	// Register entity type
		register_entity_type('object','bucketlist');
// Register a URL handler for products
		register_entity_url_handler('bucketlist_url','object','bucketlist');
		
		
	register_action('bucket_list/add', false, $CONFIG->pluginspath . 'bucket_list/actions/add.php');
	register_action('bucket_list/edit', false, $CONFIG->pluginspath . 'bucket_list/actions/edit.php');
	register_action('bucket_list/delete', false, $CONFIG->pluginspath . 'bucket_list/actions/delete.php');
	register_action('bucket_list/completer', false, $CONFIG->pluginspath . 'bucket_list/actions/completer.php');
	register_action('bucket_list/add_to_me', false, $CONFIG->pluginspath . 'bucket_list/actions/add_to_me.php');
				
}

function bucket_list_page_handler($page) {
		// The first component of a market URL is the username
		if (isset($page[0])) {
			set_input('username',$page[0]);
		}
		
		// The second part dictates what we're doing
		if (isset($page[1])) {
			switch($page[1]) {
				case "viewitem":		set_input('bucketlist',$page[2]);
							@include(dirname(__FILE__) . "/read.php");
							break;
				case "add":		
							@include(dirname(__FILE__) . "/add.php");
							break;
			}
		// If the URL is just 'market/username', or just 'market/', load the standard market index
		} else {
			@include(dirname(__FILE__) . "/collection.php");
			return true;
		}
		return false;
	}

function bucket_list_url($bucketlist) {
		global $CONFIG;
		$title = $bucketlist->title;
		$title = friendly_title($title);
		return $CONFIG->url . "pg/bucketlist/" . $bucketlist->getOwnerEntity()->username . "/read/" . $bucketlist->getGUID();
	}
	
	
function bucket_list_submenus() {
	global $CONFIG;
	$user = get_loggedin_user();
	if (get_context() == 'bucketlist') {
		add_submenu_item(elgg_echo('bucket_list:submenu:home'), $CONFIG->wwwroot . 'pg/bucketlist/' . $user->username);
		add_submenu_item(elgg_echo('bucket_list:submenu:add'), $CONFIG->wwwroot . 'pg/bucketlist/' . $user->username . '/add/');
	}
}


	
register_elgg_event_handler('init', 'system', 'bucket_list_init');