<?php
$english = array(
	'bucket_list:title:yourhome' => 'Your Bucket List',
	'bucket_list:title:home' => "'s Bucket List",
	'bucket_list:param_label' => 'My Parameter',
	'bucket_list:success' => 'Your action was successful',
	'bucket_list:failure' => 'Your action failed',
	'bucket_list:menu:link' => "Bucket List",
	'bucket_list:submenu:home' => "Your Bucket List",
	'bucket_list:submenu:add' => "Add an Item",
	'bucket_list:title:add' => "Add Item To List",
	'bucket_list:title:edit' => "Edit This Item",
	
	'item:object:bucketlist' => "Bucketlist Items",
	
	'bucketlist:tabs:30' => "Before 30",
	'bucketlist:tabs:50' => "Before 50",
	'bucketlist:tabs:80' => "Before 80",
	'bucketlist:tabs:popular' => "Popular",
	
	'bucketlist:stats:title' => "'s Stats",
	'bucketlist:stats:yourtitle' => "Your Stats",
	
	'bucketlist:item:replies' => "Comments",
	
	'bucketlist:item:add:name' => "Item Name",
	'bucketlist:item:add:description' => "Add a Description",
	'bucketlist:item:add:age' => "Before What Age?",
	'bucketlist:item:add:bucketlist_complete' => "Have You Done It?",
	'bucketlist:item:add:tags' => "Tag Your Bucketlist Item",
	'bucketlist:item:completed:select' => "- Select -",
	'bucketlist:river:updated' => "I just updated",
	'bucketlist:river:update' => "this bucketlist item |",
	
	'bucketlist:item:add:blank' => "You didn't fill everything in",
	'bucketlist:item:add:error' => "We weren't able to save your item",
	'bucketlist:item:edited' => "Bucketlist item successfully edited",
	'bucketlist:item:deleted' => "Bucketlist item successfully deleted",
	'bucketlist:item:posted' => "Bucketlist item successfully added",
	'bucketlist:item:complete:sure' => "Are you sure you want to complete this item?",
	'bucketlist:item:complete' => "You successfully updated your bucketlist and completed this item.",
	'bucketlist:item:add:already' => "This is already on your list silly!",
	'bucketlist:item:add_me:sure' => "Are you sure you want to add this to your list?",
	'bucketlist:item:added' => "You've added a new item to your bucket list. Don't forget to go and do it!",
	
	
	'bucketlist:river:annotate' => "a comment on the bucketlist item",
	'bucketlist:river:created' => "%s added",
	'bucketlist:river:create' => "a new item to their bucketlist |",
	'bucketlist:river:completed' => "%s completed",
	'bucketlist:river:complete' => "an item on their bucketlist |",
	'bucketlist:numbertodisplay' => "Number of items to display",
	'bucketlist:widget:title' => "My Bucketlist",
	'bucketlist:fulllist' => "Full List",
	'bucketlist:add_me:30' => "Add(30)",
	'bucketlist:add_me:50' => "Add(50)",
	'bucketlist:add_me:80' => "Add(80)",
	'bucketlist:completed:none' => "There's nothing completed on this list yet.",
	'bucketlist:notcompleted:none' => "There is nothing left to complete on this list.",
	
	'bucketlist:count:complete' => "Complete",
	'bucketlist:count:incomplete' => "Incomplete",
	'bucketlist:count:total' => "Total",
	
);

add_translation("en", $english);
