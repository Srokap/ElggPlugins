<?php

// include the Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

// maybe logged in users only?
//gatekeeper();

// get any input

// if username or owner_guid was not set as input variable, we need to set page owner
// Get the current page's owner
$page_owner = page_owner_entity();
if (!$page_owner) {
	$page_owner_guid = get_loggedin_userid();
	if ($page_owner_guid)
		set_page_owner($page_owner_guid);
}	


$list = (int) get_input('bucketlist');
	if ($post = get_entity($list)) {
			
		if ($post->canEdit()) {
				
			$area1 = elgg_view_title(elgg_echo('bucket_list:title:edit'));
			$area1 .= elgg_view("bucket_list/forms/add", array('entity' => $post));

// create content for main column
$area2 .= elgg_view('bucket_list/stats');

// layout the sidebar and main column using the default sidebar
$body = elgg_view_layout('two_column_left_sidebar', '', $area1, $area2);

}

}
// create the complete html page and send to browser
page_draw($title, $body);
