<?php

// include the Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

// maybe logged in users only?
//gatekeeper();

// Get the specified market post
		$post = (int) get_input('bucketlist');

	// If we can get out the market post ...
		if ($bucketlist = get_entity($post)) {
			
	// Get any comments
			//$comments = $blogpost->getAnnotations('comments');
		
	// Set the page owner
			if ($bucketlist->container_guid) {
				set_page_owner($bucketlist->container_guid);
			} else {
				set_page_owner($bucketlist->owner_guid);
			}
			
	// Set the page owner
			set_page_owner($bucketlist->getOwner());
			$page_owner = get_entity($bucketlist->getOwner());
			
	// Display it
			$area2 = elgg_view_entity($bucketlist, true);
											
	// Set the title appropriately
	$content = sprintf(elgg_echo("market:posttitle"),$page_owner->name,$bucketlist->bucketlist_title);

// layout the sidebar and main column using the default sidebar
$content .= elgg_view_layout('two_column_left_sidebar', '', $area2);

// create the complete html page and send to browser
echo $content;
}