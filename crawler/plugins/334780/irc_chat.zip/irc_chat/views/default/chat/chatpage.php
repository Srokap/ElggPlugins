<div class="contentWrapper">
<div align="center">

<?php
$channelname = "elgg_irc_chat";
echo "<iframe src='http://webchat.freenode.net/?nick=".$_SESSION['user']->username."...&channels=".$channelname."' width='900' height='400'></iframe>";
?>


</div>
</div>