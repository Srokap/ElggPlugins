<?php
  /**
   * NoELab Media Embedly
   * @author NoELab.com
   * 
   * everyone
   */

	// Start engine
		require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	// access check for closed groups
	group_gatekeeper();
			
	//set get type	
	$type = get_input('type', '');
   
		
	// Get the current page's owner
		$page_owner = page_owner_entity();
		if ($page_owner === false || is_null($page_owner)) {
			$page_owner = $_SESSION['user'];
			set_page_owner($_SESSION['guid']);
		}
	
	//set the title
	$types_string = elgg_echo("mediaembedly:type:$type") . " " . elgg_echo("mediaembedly:type");
		if ($type != ''){
	    $title = $types_string;
	} else {
	    $title = sprintf(elgg_echo("mediaembedly:everyone"), page_owner_entity()->name, $types_string);
	}
		
	// List media
		$area2 = elgg_view_title($title);
		set_context('search');
		if ($type) {
	    $area2 .= list_entities_from_metadata('media_type', $type, 'object', 'media', '', 10, FALSE, FALSE);
    	}else {
		$offset = (int)get_input('offset', 0);
		$area2 .= elgg_list_entities(array('type' => 'object', 'subtype' => 'media', 'limit' => 10, 'offset' => $offset, 'full_view' => FALSE, 'view_type_toggle' => FALSE));
		}
	
		set_context('media');
		
	// Format page
		$body = elgg_view_layout('two_column_left_sidebar', $area1, $area2);
		
	// Draw it
		page_draw(elgg_echo('mediaembedly:everyone'),$body);

?>


	
