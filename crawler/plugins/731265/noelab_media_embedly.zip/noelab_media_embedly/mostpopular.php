<?php
  /**
   * NoELab Media Embedly
   * @author NoELab.com
   * 
   * mostpopular
   */

	// Start engine
		require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	// access check for closed groups
	group_gatekeeper();
		
		$page_owner = page_owner_entity();
		
		$title = sprintf(elgg_echo("mediaembedly:popular"), page_owner_entity()->name, $types_string);
		
	// List media
		$area2 = elgg_view_title($title);
		set_context('search');
        //Most Popular = viewed
		$area2 .= list_entities_from_annotation_count ($entity_type="object", $entity_subtype="media", $name="mediacount", $limit=10, $owner_guid=0, $group_guid=0, $asc=false, $fullview=false, $listtypetoggle=false, $pagination=true, $orderdir= 'desc');
		//$area2 .= elgg_view_entity($comments);
		set_context('media');
		
		
	// Format page
		$body = elgg_view_layout('two_column_left_sidebar', $area1, $area2);
		
	// Draw it
		page_draw($title, $body);

?>