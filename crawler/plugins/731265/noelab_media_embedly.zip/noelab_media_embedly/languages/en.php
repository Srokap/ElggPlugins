<?php
  /**
   * NoELab Video Embedly
   * @author NoELab.com
   */

	$english = array(
	
	       'item:object:media' => 'Media',
			
		 /**
		 * Item & Titles
		 */
            'mediaembedly' => "Media Library",
            'mediaembedly:shareditem' => "Media item",
            'mediaembedly:shared' => 'Media',
            'mediaembedly:read' => "%s's Media",
            'mediaembedly:this' => "Share Media",
			'mediaembedly:this:group' => "Media in %s",
			'mediaembedly:new' => "A new Media item",
			'mediaembedly:no_title' => 'No title',
			'mediaembedly:comments' => "%s Comments",
			'mediaembedly:counter' => "%s Views",
         
		 /**
		 * Submenu
		 */	
			'mediaembedly:add' => "Add Media",
			'mediaembedly:everyone' => "Latest Media",
			'mediaembedly:friends' => "Friends' Media",
			'mediaembedly:inbox:shared' => "Media shared",	
			'mediaembedly:featured' => 'Featured Media',	
			'mediaembedly:popular' => 'Most Popular Media',		
		
			
       /**
		 * Form
		 */
		    
		    'mediaembedly:address' => "Add a valid YouTube, Vimeo, Google or %s Media URL:",
			'mediaembedly:embedlyurls' => "others supported",
			'mediaembedly:editoptional' => 'Edit Optional Details',
			'mediaembedly:with' => "Share with",
			'mediaembedly:delete:confirm' => "Are you sure you want to delete this resource?",
			'mediaembedly:edittools' => 'Tools',
					 
       /**
		 * River  
		 */
		 
			'mediaembedly:river:created' => '%s added a new media',
			'mediaembedly:river:shared' => '%s shared a new media',
			'media:river:annotate' => 'a comment on this media item',
			'media:river:item' => 'an item',
			

        /**
		 * Group
		 */
		 
			'mediaembedly:group' => 'Group Media',
			'groups:enablemediaembedly' => 'Enable group Media',
			'mediaembedly:nogroup' => 'This group does not have any Media yet',
		    'mediaembedly:move_select' => "Move Media to the group:",
			
		
		/**
		 * Media Type
		 */
            
            'mediaembedly:type' => 'Media Type',
			'mediaembedly:type:select' => "Select a Media Type to be more specific:",
			'mediaembedly:type:video' => "Video",
			'mediaembedly:type:photo' => "Photo",
			'mediaembedly:type:link' => "Link",
			'mediaembedly:type:rich' => "Rich",
			
			//add here your specific media type:
			'mediaembedly:type:YouTube' => "YouTube",
			
		 	
		/**
		 * Metadata 
		 */	
            
            'mediaembedly:aboutitem' => "About this Media",
			'mediaembedly:mediaauthor' => 'Published by',
			'mediaembedly:via' => "via Media",
			'mediaembedly:by' => "shared by ",
			'mediaembedly:more' => "Show more",
			
		/**
		 * Admin Settings
		 */	

			'mediaembedly:admin:type' => 'Enable Media Type for:',	
			'mediaembedly:admin:option:user' => 'Users',	
			'mediaembedly:admin:option:admin' => 'Admin!',	
			'mediaembedly:custom:type' => 'Insert Custom Media Type (eg. video,photo,YouTube...)',	
			'mediaembedly:makeunfeatured' => '',	
			'mediaembedly:makefeatured' => '',	
			'mediaembedly:admin:activefeatured' => 'Active Featured',
			'mediaembedly:admin:activepopular' => 'Active Most Popular',	
			'mediaembedly:display_move' => "Active Move Media for",
			'mediaembedly:admin:sharing' => 'Enable Media Sharing',	
		
		/**
		 * Widget
		 */
            
            'mediaembedly:more' => 'More Media',
			'mediaembedly:showmedia' => 'Show Media',
			'mediaembedly:numbertodisplay' => 'Number of Media items to display',
			'mediaembedly:widget:description' =>"This widget displays your latest Media.",


		/**
		 * Status messages
		 */

			'mediaembedly:save:success' => "Your media item was successfully.",
			'mediaembedly:delete:success' => "Your media item was successfully deleted.",
			'mediaembedly:featuredon' => "Your media item was successfully featured.",
			'mediaembedly:move:success' => "Successfully moved the forum post",

		/**
		 * Error messages
		 */

			'mediaembedly:save:failed' => "Your media item could not be saved. Make sure you've entered a title and address and then try again.",
			'mediaembedly:delete:failed' => "Your media item could not be deleted. Please try again.",
            'mediaembedly:unfeatured' => "Your media item was successfully unfeatured.",
            'mediaembedly:move:error1' => "Error 1 to move media item in group.",
            'mediaembedly:move:error2' => "Error 2 to move media item in group.",
				
	);
					
	add_translation("en",$english);

?>