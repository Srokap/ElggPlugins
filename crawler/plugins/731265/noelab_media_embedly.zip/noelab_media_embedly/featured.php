<?php
  /**
   * NoELab Media Embedly
   * @author NoELab.com
   * 
   * featured
   */

	// Start engine
		require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	// access check for closed groups
	group_gatekeeper();
		
		$page_owner = page_owner_entity();
		
		$title = sprintf(elgg_echo("mediaembedly:featured"), page_owner_entity()->name, $types_string);
		
	// List media
		$area2 = elgg_view_title($title);
		set_context('search');
		$area2 .= list_entities_from_metadata('featured_media', 'yes', 'object', 'media', '', 10, FALSE, FALSE);
		set_context('media');
		
		
	// Format page
		$body = elgg_view_layout('two_column_left_sidebar', $area1, $area2);
		
	// Draw it
		page_draw($title, $body);

?>