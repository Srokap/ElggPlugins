<?php
  /**
   * NoELab media Embedly
   * @author NoELab.com
   * 
   */
		
			   
        gatekeeper();
		
		$title = strip_tags(get_input('title'));
		$guid = get_input('media_guid',0);
		$description = get_input('description');
		$address = get_input('address');
		$access = get_input('access');
		$shares = get_input('shares',array());
		//get type
		$media_type = get_input('media_type');


    //embedly api Authentication
    require_once (dirname(dirname(__FILE__))) . '/lib/Embedly.php';	

    $projectapp = $CONFIG->sitename;
  	$contactapp = $CONFIG->siteemail;
 	$api = new Embedly_API(array(
              'user_agent' => 'Mozilla/5.0 (compatible; '. $projectapp .'/elgg; '. $contactapp .')'
             ));			
			 			    
    //embedly api Data
    $oembeds = $api->oembed(array('url' => $address));
	
	
		if (!address) {
			register_error(elgg_echo('mediaembedly:save:failed'));
			forward(REFERER);
		}
		

		// don't allow malicious code.
		// put this in a context of a link so HTMLawed knows how to filter correctly.
		$xss_test = "<a href=\"$address\"></a>";
		if ($xss_test != filter_tags($xss_test)) {
			register_error(elgg_echo('mediaembedly:save:failed'));
			forward(REFERER);
		}

		$tags = get_input('tags');
		$tagarray = string_to_tag_array($tags);

		$new_media = FALSE;
		if ($guid == 0) {

			$entity = new ElggObject;
			$entity->subtype = "media";
			$entity->owner_guid = $_SESSION['user']->getGUID();
			$entity->container_guid = (int)get_input('container_guid', $_SESSION['user']->getGUID());

			$new_media = TRUE;

		} else {

			$canedit = false;
			if ($entity = get_entity($guid)) {
				if ($entity->canEdit()) {
					$canedit = true;
				}
			}
			if (!$canedit) {
				system_message(elgg_echo('notfound'));
				forward("pg/media");
			}

		}
		
		
		$entity->address = $address;

		//embedly api Values 		
		foreach ($oembeds as $k => $oembed) {
    	$oembed = (array) $oembed;				
								
				$oembed_html = $oembed['html'];
				$oembed_type =  $oembed['type'];
				$oembed_title =  $oembed['title'];
				$oembed_url =  $oembed['url'];
				$oembed_author_name =  $oembed['author_name'];
				$oembed_description =  $oembed['description'];
				//$oembed_author_url =  $oembed['author_url'];
				$oembed_provider_name =  $oembed['provider_name'];
				//$oembed_provider_url =  $oembed['provider_url'];
				$oembed_thumbnail_url =  $oembed['thumbnail_url'];
				$oembed_thumbnail_width =  $oembed['thumbnail_width'];
				$oembed_thumbnail_height =  $oembed['thumbnail_height'];
				
				
				
				//embedly api Save
				$entity->oembed_html = $oembed_html;
				$entity->oembed_type = $oembed_type;
				$entity->oembedtitle = $oembed_title;
				$entity->oembed_url = $oembed_url;
				$entity->oembed_author_name = $oembed_author_name;
				$entity->oembed_description = $oembed_description;
				//$entity->oembed_author_url= $oembed_author_url;
				$entity->oembed_provider_name = $oembed_provider_name;
				//$entity->mediaprovider_url = $oembed_provider_url;
				$entity->oembed_thumbnail_url = $oembed_thumbnail_url;
				$entity->oembed_thumbnail_width = $oembed_thumbnail_width;
				$entity->oembed_thumbnail_height = $oembed_thumbnail_height;
			    
				
 		}

        if(!$title) {
			$title =  $oembed_title;
		}
		
		$entity->title = $title;
		$entity->description = $description;
		$entity->access_id = $access;
		$entity->media_type = $media_type;
		$entity->tags = $tagarray;
		$entity->media_type = $media_type;
				
        
		if ($entity->save()) {
			//commented to support Edifice
			//$entity->clearRelationships();
			$entity->shares = $shares;

			if (is_array($shares) && sizeof($shares) > 0) {
				foreach($shares as $share) {
					$share = (int) $share;
					add_entity_relationship($entity->getGUID(),'share',$share);
				}
			}
			system_message(elgg_echo('mediaembedly:save:success'));
			//add to river
			if ($new_media) {
				add_to_river('river/object/media/create','create',$_SESSION['user']->guid,$entity->guid);
			}
			forward($entity->getURL());
		} else {
			register_error(elgg_echo('mediaembedly:save:failed'));
			forward("pg/media");
		}

?>
