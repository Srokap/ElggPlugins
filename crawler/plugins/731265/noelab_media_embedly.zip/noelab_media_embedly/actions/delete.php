<?php
  /**
   * NoELab media Embedly
   * @author NoELab.com
   */

		$guid = get_input('media_guid',0);
		if ($entity = get_entity($guid)) {

			$container = get_entity($entity->container_guid);
			if ($entity->canEdit()) {
				
				if ($entity->delete()) {
					
					system_message(elgg_echo("mediaembedly:delete:success"));
					forward("pg/media/owner/$container->username/");
					
				}
				
			}
			
		}
		
		register_error(elgg_echo("mediaembedly:delete:failed"));
		forward(REFERER);

?>