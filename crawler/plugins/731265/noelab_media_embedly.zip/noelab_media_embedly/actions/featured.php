<?php
  /**
   * NoELab Media Embedly
   * @author NoELab.com
   */

	// Load configuration
	global $CONFIG;
	
	admin_gatekeeper();
	
	$media_guid = get_input('media_guid');
	$action = get_input('action_type');
	
	$media = get_entity($media_guid);
	
	if($media){
		
		//get the action, is it to feature or unfeature
		if($action == "feature"){
		
			$media->featured_media = "yes";
			system_message(elgg_echo('mediaembedly:featuredon'));
			
		}
		
		if($action == "unfeature"){
			
			$media->featured_media = "no";
			system_message(elgg_echo('mediaembedly:unfeatured'));
			
		}
		
	}
	
	forward(REFERER);
	
?>