<?php
  /**
   * NoELab Media Embedly
   * @author NoELab.com
   */

$group_guid = get_input('group_guid');
$media_guid = get_input('media_guid');

$media = get_entity($media_guid);

if (!$media) {
	register_error(elgg_echo('mediaembedly:move:error1'));
	forward($_SERVER['HTTP_REFERER']);
}

if ($group_guid == 0) {
	register_error(elgg_echo('mediaembedly:move:error2'));
	forward($_SERVER['HTTP_REFERER']);
}

$orig_group_guid = $media->container_guid;

$media->container_guid = $group_guid;
$media->save();

system_message(elgg_echo('mediaembedly:move:success'));
forward($CONFIG->url . "pg/media/owner/group:{$orig_group_guid}/");

?>