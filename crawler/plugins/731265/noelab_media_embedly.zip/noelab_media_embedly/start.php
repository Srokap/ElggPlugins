<?php
  /**
   * NoELab Media Embedly
   * @author NoELab.com
   * 
   * start
   */
		 
/**
* Init function
*
*/  			 			 			 
function noelab_media_embedly_init() {
        	
		// Grab the config global
		global $CONFIG;

	    //add a tools menu option
		add_menu(elgg_echo('mediaembedly'), $CONFIG->wwwroot . "pg/media/all");
		// Add group menu option
		add_group_tool_option('media',elgg_echo('groups:enablemediaembedly'),true);
		elgg_extend_view('groups/right_column', 'media/groupprofile_media');
		// Shares widget
		add_widget_type('media',elgg_echo("mediaembedly"),elgg_echo("mediaembedly:widget:description"));
        
           
		   
            // Extend useful views with stuff we need for our embed modal
            elgg_extend_view('css', 'media/css');
			//elgg_extend_view('js/initialise_elgg','media/js');
			elgg_extend_view('metatags','media/metatags'); 
			// rss extensions
	        extend_view('extensions/xmlns', 'extensions/media/xmlns');
	        extend_view('extensions/channel', 'extensions/media/channel');
           

            // Page handler for the modal media embed
            register_page_handler('media','noelab_media_embedly_page_handler');
			// Register a URL handler for shared items
			register_entity_url_handler('noelab_media_embedly_url','object','media');
			// Register entity type
			register_entity_type('object','media');	
			// Listen to notification events and supply a more useful message
			register_plugin_hook('notify:entity:message', 'object', 'media_notify_message');
			// Register granular notification for this type
	        if (is_callable('register_notification_object')) {
		    register_notification_object('object', 'media', elgg_echo('mediaembedly:new'));
	        }

}


/**
 * Sidebar menu for noelab media embedly
 *
 */
function noelab_media_embedly_pagesetup() {
	global $CONFIG;

	$page_owner = page_owner_entity();

	//add submenu options
	if (get_context() == "media") {

		if (isloggedin()) {
			// link to add media form
			if ($page_owner instanceof ElggGroup) {
				if ($page_owner->isMember(get_loggedin_user())) {
					add_submenu_item(elgg_echo('mediaembedly:add'), $CONFIG->wwwroot."pg/media/addmedia/" . $page_owner->username);
				}
			} else {
				add_submenu_item(elgg_echo('mediaembedly:add'), $CONFIG->wwwroot."pg/media/addmedia/" . $_SESSION['user']->username);
				add_submenu_item(elgg_echo('mediaembedly:inbox:shared'),$CONFIG->wwwroot."pg/media/shared/" . $_SESSION['user']->username);
			}
			if (page_owner()) {
				add_submenu_item(sprintf(elgg_echo('mediaembedly:read'), $page_owner->name),$CONFIG->wwwroot."pg/media/owner/" . $page_owner->username);
			}
			if (!$page_owner instanceof ElggGroup) {
				add_submenu_item(elgg_echo('mediaembedly:friends'),$CONFIG->wwwroot."pg/media/friends/" . $_SESSION['user']->username);
			}
		}

		if (!$page_owner instanceof ElggGroup) {
			add_submenu_item(elgg_echo('mediaembedly:everyone'),$CONFIG->wwwroot."pg/media/all/");
			// Add Media Featured
            $feature = get_plugin_setting('featured', 'noelab_media_embedly');
            if ($feature != 'no'){ 
		        add_submenu_item(elgg_echo('mediaembedly:featured'),$CONFIG->wwwroot."pg/media/featured/");
			}
			// Add Media Popular
            $feature = get_plugin_setting('popular', 'noelab_media_embedly');
            if ($feature != 'no'){ 
		        add_submenu_item(elgg_echo('mediaembedly:popular'),$CONFIG->wwwroot."pg/media/popular/");
			}
		    //add Media Type
		    $media_types = get_tags(0, 10, 'media_type', 'object', 'media', '');
			foreach ($media_types as $type) {
			    $tag = $type->tag;
			    $label = elgg_echo("mediaembedly:type:" . $tag);
			    $url = "{$CONFIG->url}pg/media/all/$tag/";
				add_submenu_item($label, $url, 'mediatypes');
			}	
		}
		
	

	}

	if ($page_owner instanceof ElggGroup && get_context() == 'groups') {
		if ($page_owner->bookmarks_enable != "no") {
			add_submenu_item(sprintf(elgg_echo("mediaembedly:group"),$page_owner->name), $CONFIG->wwwroot . "pg/media/owner/" . $page_owner->username);
		}
	}

}
	
	
/**
* noelab media embedly page handler
*
* @param array $page Array of page elements, forwarded by the page handling mechanism
*/
function noelab_media_embedly_page_handler($page) {

	// group usernames
	if (substr_count($page[0], 'group:')) {
		preg_match('/group\:([0-9]+)/i', $page[0], $matches);
		$guid = $matches[1];
		if ($entity = get_entity($guid)) {
			noelab_media_embedly_url_forwarder($page);
		}
	}

	// user usernames
	$user = get_user_by_username($page[0]);
	if ($user) {
		noelab_media_embedly_url_forwarder($page);
	}

	switch ($page[0]) {
		case "read":
			set_input('guid', $page[1]);
			require(dirname(dirname(dirname(__FILE__))) . "/entities/index.php");
			break;
		case "friends":
			set_input('username', $page[1]);
			include(dirname(__FILE__) . "/friends.php");
			break;
		case "all":
			//set input type
			set_input('type', $page[1]);
	            if (isset($page[2])) {
	                set_input($page[2], $page[3]);
	            }
			include(dirname(__FILE__) . "/everyone.php");
			break;
		case "shared":
			set_input('username', $page[1]);
			include(dirname(__FILE__) . "/shared.php");
			break;
		case "owner":
			set_input('username', $page[1]);
			include(dirname(__FILE__) . "/index.php");
			break;
		case "addmedia":
			set_input('username', $page[1]);
			include(dirname(__FILE__) . "/addmedia.php");
			break;
		case "edit":
			set_input('media', $page[1]);
			include(dirname(__FILE__) . "/addmedia.php");
			break;
		case "featured":
			set_input('media', $page[1]);
			include(dirname(__FILE__) . "/featured.php");
			break;
		case "popular":
			set_input('media', $page[1]);
			include(dirname(__FILE__) . "/mostpopular.php");
			break;
			
		default:
			return false;
	}

	return true;
}
		
/**
 * Forward to the new style of URLs
 *
 * @param string $page
 */
function noelab_media_embedly_url_forwarder($page) {
	global $CONFIG;

	if (!isset($page[1])) {
		$page[1] = 'items';
	}

	switch ($page[1]) {
		case "read":
			$url = "{$CONFIG->wwwroot}pg/media/read/{$page[2]}/{$page[3]}";
			break;
		case "inbox":
			$url = "{$CONFIG->wwwroot}pg/media/shared/{$page[0]}/";
			break;
		case "friends":
			$url = "{$CONFIG->wwwroot}pg/media/friends/{$page[0]}/";
			break;
		case "addmedia":
			$url = "{$CONFIG->wwwroot}pg/media/addmedia/{$page[0]}/";
			break;
		case "items":
			$url = "{$CONFIG->wwwroot}pg/media/owner/{$page[0]}/";
			break;
		//add featured
		case "featured":
			$url = "{$CONFIG->wwwroot}pg/media/featured/{$page[0]}/";
			break;
		//add most popular
		case "popular":
			$url = "{$CONFIG->wwwroot}pg/media/popular/{$page[0]}/";
			break;

	}

	register_error(elgg_echo("changemediaembedly"));
	forward($url);
}

/**
 * Populates the ->getUrl() method for bookmarked objects
 *
 * @param ElggEntity $entity The bookmarked object
 * @return string bookmarked item URL
 */
function noelab_media_embedly_url($entity) {

	global $CONFIG;
	$title = $entity->title;
	$title = elgg_get_friendly_title($title);
	return $CONFIG->url . "pg/media/read/" . $entity->getGUID() . "/" . $title;
}

/**
 * Returns a more meaningful message
 *
 * @param unknown_type $hook
 * @param unknown_type $entity_type
 * @param unknown_type $returnvalue
 * @param unknown_type $params
 */
function noelab_media_embedly_notify_message($hook, $entity_type, $returnvalue, $params) {
	$entity = $params['entity'];
	$to_entity = $params['to_entity'];
	$method = $params['method'];
	if (($entity instanceof ElggEntity) && ($entity->getSubtype() == 'media')) {
		$descr = $entity->description;
		$title = $entity->title;
		global $CONFIG;
		$url = $CONFIG->wwwroot . "pg/view/" . $entity->guid;
		if ($method == 'sms') {
			$owner = $entity->getOwnerEntity();
			return $owner->name . ' ' . elgg_echo("media:via") . ': ' . $url . ' (' . $title . ')';
		}
		if ($method == 'email') {
			$owner = $entity->getOwnerEntity();
			return $owner->name . ' ' . elgg_echo("media:via") . ': ' . $title . "\n\n" . $descr . "\n\n" . $entity->getURL();
		}
		if ($method == 'web') {
			$owner = $entity->getOwnerEntity();
			return $owner->name . ' ' . elgg_echo("media:via") . ': ' . $title . "\n\n" . $descr . "\n\n" . $entity->getURL();
		}

	}
	return null;
}

	

        // initiate the plugin
        register_elgg_event_handler('init', 'system', 'noelab_media_embedly_init');
		register_elgg_event_handler('pagesetup','system','noelab_media_embedly_pagesetup');
		
		// Register actions
		global $CONFIG;
		register_action("media/addmedia", false, $CONFIG->pluginspath. "noelab_media_embedly/actions/addmedia.php");
		register_action("media/delete", false, $CONFIG->pluginspath. "noelab_media_embedly/actions/delete.php");
		register_action("media/featured",false,$CONFIG->pluginspath . "noelab_media_embedly/actions/featured.php");
		register_action("media/move_media", false, $CONFIG->pluginspath . "noelab_media_embedly/actions/move.php", true);