<?php
  /**
   * NoELab Video Embedly
   * @author NoELab.com
   * 
   * River create
   */ 
   
$performed_by = get_entity($vars['item']->subject_guid); // $statement->getSubject();
$object = get_entity($vars['item']->object_guid);
$url = $object->getURL();

$url = "<a href=\"{$performed_by->getURL()}\">{$performed_by->name}</a>";
$string = sprintf(elgg_echo("mediaembedly:river:shared"),$url) . " " . $object->oembed_type;

//media description
$contents .= "<div class='river_content_display'>";
$desc = strip_tags($object->description); //strip tags from the contents to stop large images etc blowing out the river view
if(strlen($desc) > 150) {
  $contents .= substr($desc, 0, 150) . "...";
}else {
  $contents .= $desc;
} 
$contents .= "</div><div class='clearfloat'></div>";


// minidescription 
if(strlen($object->oembed_description) > 450) {
//$mini_description = strip_tags($object->oembed_description);
$oembed_desc = substr($object->oembed_description,0,450). "...";
}else {
	$oembed_desc = $object->oembed_description;
}

//media content
$contents .= "<div class='river_content_display'>";
$contents .= "<a class='embed-thumbnail' href='#'><img src='" . $object->oembed_thumbnail_url ."'/><img class='embed-PlayButton' src='" . $vars['url'] . "mod/noelab_media_embedly/graphics/play-button-1.png' height='30' width='30' border'0'></a><div class='infoembedly'><a href=" . $object->getURL() . ">" . $object->oembedtitle . "</a><p>via ". $object->oembed_provider_name . "</p><p>" . $oembed_desc ."</p></div><div class='clearfloat'></div>";

switch($object->oembed_type) {
           case 'photo':
$contents .= "<div class=\"embed\"><img src=" . $object->oembed_url . " alt=" . $object->oembed_title . " title=" . $object->oembed_title . "</img></div>"; 
           break;  
		   case 'link':
  		   case 'rich':
  		   case 'video':
$contents .= "<div class=\"embed\">" . $object->oembed_html . "</div>"; 
						 case 'error':
                         default:
                         
}

$contents .= "</div><div class='clearfloat'></div>";

  $string .= $contents;

//print river content
echo $string;
?>