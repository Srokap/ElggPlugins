<?php
  /**
   * NoELab media Embedly
   * @author NoELab.com
   * 
   * Media objects
   */

	$owner = $vars['entity']->getOwnerEntity();
	$friendlytime = elgg_view_friendly_time($vars['entity']->time_created);
    
	//get type
	$media_type = $vars['entity']->media_type;
	
	//get embedly values
	$oembed_html = $vars['entity']->oembed_html;
	$oembed_type= $vars['entity']->oembed_type;
	$oembed_title= $vars['entity']->oembed_title;
	$oembed_url= $vars['entity']->oembed_url;
	$oembed_provider_name = $vars['entity']->oembed_provider_name;
	$oembed_author_name =  $vars['entity']->oembed_author_name;
	$oembed_description =  $vars['entity']->oembed_description;
	$oembed_thumbnail_url= $vars['entity']->oembed_thumbnail_url;


	if (!$title = $vars['entity']->title) {
		$title = elgg_echo('mediaembedly:no_title');
	}

    //Media Featured for admins display the feature or unfeature option
    $feature = get_plugin_setting('featured', 'noelab_media_embedly');
    if ($feature != 'no'){ 
		if($vars['entity']->featured_media == "yes"){
			$url = elgg_add_action_tokens_to_url($vars['url'] . "action/media/featured?media_guid=" . $vars['entity']->guid . "&action_type=unfeature");
			$wording = '&#9733;' . elgg_echo("mediaembedly:makeunfeatured");
		}else{
			$url = elgg_add_action_tokens_to_url($vars['url'] . "action/media/featured?media_guid=" . $vars['entity']->guid . "&action_type=feature");
			$wording = '&#9734;' . elgg_echo("mediaembedly:makefeatured");
		}
	}	
	
	if (get_context() == "search") {

			 if (!array_key_exists('mediathumbnail_url', $oembed_thumbnail_url)) {

				$icon = "<img src=\"{$oembed_thumbnail_url}\" />";
			 } else {
				$icon = elgg_view(
					"profile/icon", array(
										'entity' => $owner,
										'size' => 'small',
									)
				);
			}
            		
			$info .= "<p class=\"mediaembedly_gallery_title\"><a href=\"{$vars['entity']->getURL()}\">{$title}</a></p>";
            $info .= "<p class=\"owner_timestamp\">{$friendlytime} ". elgg_echo("mediaembedly:by") ." <a href=\"{$vars['url']}pg/media/owner/{$owner->username}\">{$owner->name}</a>";
			$info .= ", ". $oembed_type . " via $oembed_provider_name";
			$info .= "<br /><br />";
			$numcomments = elgg_count_comments($vars['entity']);
			if ($numcomments)
				$info .= sprintf(elgg_echo('mediaembedly:comments'),$numcomments); 
			$info .= '&nbsp;&nbsp;'; 
			// Media Count
			$current_count = $vars['entity']->getAnnotations("mediacount");
	   		 if(!$current_count){
		 		 $current_count = 0;
	   	     } else {
				 $current_count = $current_count[0]->value;
	    	 }
		    $info .= sprintf(elgg_echo('mediaembedly:counter'),$current_count);
			if(isadminloggedin())
				$info .= " <a class=\"mediaembedly_symbol\" href=\"{$url}\" title=\"Feature/Unfeature\">{$wording}</a>";		 
			$info .= "</p>";
			
			
		
			echo elgg_view_listing($icon, $info);


	} else {
	
?>
	<?php echo elgg_view_title(elgg_echo('mediaembedly:shareditem'), false); ?>
	<div class="contentWrapper">
	    <div class="mediaembedly_item">
		    <div class="mediaembedly_item_title">
				
				<h3><?php echo $title; ?></h3>
				
			
			</div>
            
            <div class="mediaembedly_content">
            	<div class="mediaembedly_wrapper">
            		
           			<?php
           			switch($oembed_type) {
                       case 'photo':
					   ?>

						   	<img src="<?php echo $oembed_url ?>" alt="<?php echo $oembed_title ?>" title="<?php echo $oembed_title ?>"</img>

					    <?php
                     	  
						 break;  
						 case 'link':
  						 case 'rich':
  						 case 'video':
					         //insert media address/url 
					         echo $oembed_html; 
						 case 'error':
                         default:
                         
                         }?>
					
					<div class="mediaembedly_meta">
            		
            		 <?php 
            		  $numcomments = elgg_count_comments($vars['entity']);
			      	  if ($numcomments)
					  $info = "<p>";
				  	  $info .= sprintf(elgg_echo('mediaembedly:comments'),$numcomments); 
					  $info .='&nbsp;&nbsp;'; 
					  
					  // Media Count
	                  $info .= elgg_view('media/tools/media_count', $vars);
					   				  
					  //if admin, show make featured option
					  if(isadminloggedin())
			          $info .= "<a class=\"mediaembedly_symbol\" href=\"{$url}\" title=\"Feature/Unfeature\">{$wording}</a>";		
            		  $info .= "</p>";
					  
					  // Media Sharing
					  $sharing = get_plugin_setting('sharing', 'noelab_media_embedly');
    				  if ($sharing != 'no'){ 
		                 
			                $info .= elgg_view('media/tools/media_sharing', $vars);
					     
	                  }	
					 
					  //Echo all info
            		  echo $info;
					 
            		 ?>
            			
                    <!-- end mediaembedly_wrapper -->
					</div>
				<!-- end mediaembedly_content -->
				</div>
				
				<div class="mediaembedly_info">
            		
            		<p><b><?php echo elgg_echo('mediaembedly:aboutitem'); ?></b></p>
					<?php
					// description 
                    if(strlen($oembed_description) > 620) {
                    $mini_description = strip_tags($oembed_description);
					echo substr($mini_description,0,620);                    
					echo "...</p>";
					}else {
                    echo '<p>' . $oembed_description . '</p>';
                    }
		            ?>
					<?php if ($oembed_author_name != '') { ?>
           			<p><b><?php echo elgg_echo('mediaembedly:mediaauthor'); ?>: </b><?php echo $oembed_author_name; ?></p>
					<?php }?>
					<p><b>Via:</b> <?php echo $oembed_provider_name; ?></p>
					
					
				</div>	
			
				
			</div>

	

			<div class="clearfloat"></div>
		   
			<div class="mediaembedly_item_owner">
				<div class="icon">
		   		 <?php
		     	   echo elgg_view("profile/icon",array('entity' => $owner, 'size' => 'small'));
				 ?>
	   		    </div>
			    <p class="strapline">
				<?php
	                //insert data d-m-y
					echo sprintf(date("F j, Y", $vars['entity']->time_created));
				?>
				
				<?php echo elgg_echo('mediaembedly:by'); ?> <a href="<?php echo $vars['url']; ?>pg/media/owner/<?php echo $owner->username; ?>"><?php echo $owner->name; ?></a> &nbsp;
				
				
			   </p>
			
			   
			    
			   
			   
			   
			   
			   <?php
               //insert tags	
			   $tags = elgg_view('output/tags', array('tags' => $vars['entity']->tags));
			   if (!empty($tags)) {
				    	 echo '<p class="tags">' . $tags . '</p>';
			   }
			
			   //insert category	
			   if(is_plugin_enabled('edifice')){
			   	  // EDIFICE CATEGORIES VIEW
			   	  
                
			   } else {
			       $categories = elgg_view('categories/view', $vars);
			       if (!empty($categories)) {
						echo '<p class="categories">' . $categories . '</p>';
			       }
			   }	
               ?>
            
		   <!-- end mediaembedly_item_owner -->
	       </div>
	       <div class="clearfloat"></div>

			
		   <div class="mediaembedly_item_description">
				<?php echo elgg_view('output/longtext', array('value' => $vars['entity']->description)); ?>
		   </div>
		   <div class="clearfloat"></div>

		<?php
		//controls
		if ($vars['entity']->canEdit()) {
           
		   
		    
		
		?>
		<div class="mediaembedly_item_controls">
			<p>
				<a href="<?php echo $vars['url']; ?>pg/media/edit/<?php echo $vars['entity']->getGUID(); ?>"><?php echo elgg_echo('edit'); ?></a> &nbsp;
				<?php
						echo elgg_view('output/confirmlink',array(

							'href' => $vars['url'] . "action/media/delete?media_guid=" . $vars['entity']->getGUID(),
							'text' => elgg_echo("delete"),
							'confirm' => elgg_echo("mediaembedly:delete:confirm"),

						));
				// Media Move admin or user?
				$setting = get_plugin_setting("display_move_controls", "noelab_media_embedly");
				if(empty($setting)){
					// default value
					$setting = "user";
				} 
		
				// Media Move can user edit? or just admins
				if($setting == "user" || isadminloggedin()){
      	      	    echo " &nbsp; <a onclick=\"$('#mediaembedly_option').toggle()\">" . elgg_echo('mediaembedly:edittools') . "</a>";
				    //Media Tools
				    echo "<div id=\"mediaembedly_option\">";					  
		            echo elgg_view('media/tools/media_move', array('media' => $vars['entity']));
				    echo "</div>";
				//end 
				}
				
				
				?>
				
			</p>
		<!-- end mediaembedly_item_controls -->
		</div>
		<?php
			  
			}

		?>
		<div class="clearfloat"></div>
	  
      <!-- end mediaembedly_item -->
	  </div>
   <!-- end contentwrapper -->
   </div>
<?php
//comments
  
	if ($vars['full'])
		echo elgg_view_comments($vars['entity']);

?>

<?php

	}

?>