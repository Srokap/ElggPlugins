<?php
  /**
   * NoELab media Embedly
   * @author NoELab.com
   * 
   * Widgets
   */

	    //get the num of shares the user want to display
		$num = $vars['entity']->num_display;
		
		//if no number has been set, default to 4
		if(!$num)
			$num = 4;
		
		set_context('search');
		$content = elgg_list_entities(array('type' => 'object', 'subtype' => 'media', 'container_guid' => $vars['entity']->owner_guid, 'limit' => $num, 'offset' => 0, 'pagination' => FALSE ));
		set_context('media');
		
		
	    // Show medias
		echo  $content;
		
		$user_inbox = $vars['url'] . "pg/media/owner/" . page_owner_entity()->username;
		echo "<div class=\"widget_more_wrapper\"><a href=\"{$user_inbox}\">".elgg_echo('mediaembedly:more')."</a></div>";
	
?>