<?php
  /**
   * NoELab media Embedly
   * @author NoELab.com
   * 
   * add disable count for own group
   */
	

	$page_owner = page_owner_entity();
	$current_count = $vars['entity']->getAnnotations("mediacount");
	if(!$current_count){
		$vars['entity']->annotate('mediacount', 1, 2);
	} else {
		$updateable = true;
		if(isloggedin()){
			if(get_loggedin_user()->getGUID() == $page_owner->getGUID()){
				// dont count own media visits
				$updateable = false;
			}
		}
		
		if($updateable){
			update_annotation($current_count[0]->id,  "mediacount", ($current_count[0]->value + 1), $current_count[0]->value_type,$current_count[0]->owner_guid, $current_count[0]->access_id); 
	
		}
		
	}
    
	$current_count = $vars['entity']->getAnnotations("mediacount");
	if(!$current_count){
	    $current_count = 0;
	} else {
		$current_count = $current_count[0]->value;
	}
	
	echo sprintf(elgg_echo('mediaembedly:counter'),$current_count); 
?>
	