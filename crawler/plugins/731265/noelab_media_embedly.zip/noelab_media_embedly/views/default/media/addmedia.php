<?php
  /**
   * NoELab media Embedly
   * @author NoELab.com
   * 
   * addmedia
   */
   

	// Have we been supplied with an entity?
		if (isset($vars['entity'])) {
			
			$guid = $vars['entity']->getGUID();
			$title = $vars['entity']->title;
			$description = $vars['entity']->description;
			$address = $vars['entity']->address;
			$tags = $vars['entity']->tags;
			$access_id = $vars['entity']->access_id;
			$shares = $vars['entity']->shares;
			$owner = $vars['entity']->getOwnerEntity();
			$highlight = 'default';
			//edit type
			$media_type = $vars['entity']->media_type;
			$media_custom_type = get_plugin_setting('media_custom_type', 'noelab_media_embedly');
			
		} else {
			
			$guid = 0;
			$title = get_input('title',"");
			$title = stripslashes($title); // strip slashes from URL encoded apostrophes
			$description = "";
			$address = get_input('address',"");
			$highlight = 'all';
			//add type
			$media_type = array();
			$media_custom_type = get_plugin_setting('media_custom_type', 'noelab_media_embedly');

			
			if ($address == "previous")
				$address = $_SERVER['HTTP_REFERER'];
			$tags = array();
			
			if (defined('ACCESS_DEFAULT'))
				$access_id = ACCESS_DEFAULT;
			else
				$access_id = 0;
			$shares = array();
			$owner = page_owner_entity();		
		}

?>
<div class="contentWrapper">
	<form id="submit_media" action="<?php echo $vars['url']; ?>action/media/addmedia" method="post">
		<?php echo elgg_view('input/securitytoken'); ?>

		<p>
			<label>
				<?php 
				$embedly = '<a href="'. $vars['url'] .'mod/noelab_media_embedly/graphics/embedly_services.png" rel="facebox">'. elgg_echo('mediaembedly:embedlyurls')  . '</a>';
				echo sprintf(elgg_echo('mediaembedly:address'), $embedly);
				?>
				
				<?php

						echo elgg_view('input/url',array(
								'internalname' => 'address',
								'value' => $address,
						)); 
				
				?>
			</label>
		</p>
		<p>
			<a onclick="$('#mediaembedly_option').toggle()"><?php echo elgg_echo('mediaembedly:editoptional'); ?><a/>
		</p>
		

    <div id="mediaembedly_option">
		<p>
			<label>
				<?php 	echo elgg_echo('title') ; ?>
				<?php

						echo elgg_view('input/text',array(
								'internalname' => 'title',
								'value' => $title,
						)); 
				
				?>
			</label>
		</p>
		
		<p class="longtext_editarea">
			<label>
				<?php 	echo elgg_echo('description'); ?>
				<br />
				<?php

						echo elgg_view('input/longtext',array(
								'internalname' => 'description',
								'value' => $description,
						)); 
				
				?>
			</label>
		</p>
				
		<?php 
		// Media type selector
		$setting = get_plugin_setting("media_type_selection", "noelab_media_embedly");
		if(empty($setting)){
			// default value
			$setting = "user";
		} 
		
		// can user edit? or just admins
		if($setting == "user" || isadminloggedin()){
			// get profile types
			if ($media_custom_type != '') {
			?>
			<p>
				<label>
					<?php echo elgg_echo('mediaembedly:type:select'); ?>
				    <br />
					<?php
					
							echo elgg_view('input/checkboxes', array(
							"internalname" => "media_type",
							"value" => $media_type,
							'options' => string_to_tag_array($media_custom_type),
							
							));
					?>
				</label>
			</p>
		
		 <?php 
        	 }
		 }
		 ?>
		
   </div>
	
		
		
		
		<p>
			<label>
				<?php 	echo elgg_echo('tags'); ?>
				<?php

						echo elgg_view('input/tags',array(
								'internalname' => 'tags',
								'value' => $tags,
						)); 
				
				?>
			</label>
		</p>
			<?php

				//echo elgg_view('media/sharing',array('shares' => $shares, 'owner' => $owner));
				if ($friends = elgg_get_entities_from_relationship(array('relationship' => 'friend', 'relationship_guid' => $owner->getGUID(), 'inverse_relationship' => FALSE, 'type' => 'user', 'limit' => 9999))) {
?>
		<p>
					<label><?php echo elgg_echo("mediaembedly:with"); ?></label><br />
<?php
					echo elgg_view('friends/picker',array('entities' => $friends, 'internalname' => 'shares', 'highlight' => $highlight));
?>
		</p>
<?php
				}
			
			?>
			
		<p>
			<label>
				<?php 	echo elgg_echo('access'); ?>
				<?php

						echo elgg_view('input/access',array(
								'internalname' => 'access',
								'value' => $access_id,
						)); 
				
				?>
			</label>
		</p>
		
		     <?php 
		     // ELGG CATEGORIES INPUT
		     echo elgg_view('categories',$vars); 
		     ?>	
		
		 <p>
             <?php
             // EDIFICE CATEGORIES INPUT
             if(is_plugin_enabled('edifice')){
                if (isset($vars['entity'])) {
                    $current_category = get_item_categories($vars['entity']->guid);
                } else {
                    $current_category = NULL;
                }
                if (in_array('media', string_to_tag_array(get_plugin_setting('allowed_object_types', 'edifice')))) {
                    echo elgg_view('edifice/forms/assign', array('current_category' => $current_category));
                }
             }
             ?>
        </p>	
		
		<p>
			<?php echo $vars['container_guid'] ? elgg_view('input/hidden', array('internalname' => 'container_guid', 'value' => $vars['container_guid'])) : ""; ?>
			<input type="hidden" name="media_guid" value="<?php echo $guid; ?>" />
			<input type="submit" value="<?php echo elgg_echo('save'); ?>" />
		</p>
	
	</form>
</div>