<?php
  /**
   * NoELab media Embedly
   * @author NoELab.com
   * 
   * Media Sharing
   */
  
?>
<!-- AddThis Button BEGIN -->
<div class="addthis_toolbox addthis_default_style addthis_32x32_style">
<a class="addthis_button_facebook"></a>
<a class="addthis_button_twitter"></a>
<a class="addthis_button_google"></a>
<a class="addthis_button_email"></a>
<a class="addthis_button_compact"></a>
<a class="addthis_counter addthis_bubble_style"></a>
<a class="addthis_button_facebook_like" fb:like:layout="box_count"></a>
</div>
<!-- AddThis Button END -->
