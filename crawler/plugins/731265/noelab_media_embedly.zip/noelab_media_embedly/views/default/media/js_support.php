<?php
  /**
   * NoELab media Embedly
   * @author NoELab.com
   * Support for embed.ly
   */
?>

<script type="text/javascript">
$(document).ready(function() {
  
 $('a').embedly({}, function(oembed, dict){
    $this = $(dict.node);
    $this.html(oembed.title)
         .after('<div class="clearfloat" style="margin:5px 0 0 20px;"></div><a class="embed-thumbnail" href="#"><img src="'+oembed.thumbnail_url+'"/><img class="embed-PlayButton" src="<?php echo $vars['url']; ?>mod/noelab_media_embedly/graphics/play-button-1.png" height="30" width="30" border"0"></a><div class="infoembedly"><a href="'+oembed.url+'">'+oembed.title+'</a><p>via '+oembed.provider_name+'</p></div><div class="clearfloat"></div>');
  });
  
  
  var anchors = $("a");  anchors.embedly();  anchors.filter("[href*=flx.me]").addClass("custom_embed");
  
});
</script>
