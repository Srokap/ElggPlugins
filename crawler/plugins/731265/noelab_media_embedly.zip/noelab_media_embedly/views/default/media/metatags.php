<?php
  /**
   * NoELab Video Embedly
   * @author NoELab.com
   * 
   * metatags
   */ 
?>

<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/noelab_media_embedly/vendors/jquery.embedly.min.js"></script>

<script type="text/javascript">
$(document).ready(function() {


 $('a').embedly({}, function(oembed, dict){
    $this = $(dict.node);
    $this.html(oembed.title)
         .after('<div class="clearfloat" style="margin:5px 0 0 20px;"></div><a class="embed-thumbnail" href="#"><img src="'+oembed.thumbnail_url+'"/><img class="embed-PlayButton" src="<?php echo $vars['url']; ?>mod/noelab_media_embedly/graphics/play-button-1.png" height="30" width="30" border"0"></a><div class="infoembedly"><a href="'+oembed.url+'">'+oembed.title+'</a><p>via '+oembed.provider_name+'</p></div><div class="clearfloat"></div>');
  });
  
  var anchors = $("a");  anchors.embedly();  anchors.filter("[href*=flx.me]").addClass("custom_embed");
   $('a.embed-thumbnail').live("click", function(e){
     e.preventDefault();
     $(this).parent().find('.embed').toggle("slow");
     $(this).parent().find('a.embed-thumbnail').hide("slow");
  });
  
});
</script>

<?php
// Media Sharing
$sharing = get_plugin_setting('sharing', 'noelab_media_embedly');
if (get_context() == "media" && $sharing != 'no'){
?> 

	<!-- AddThis  -->
	<script type="text/javascript">
    	var addthis_config = {"data_track_clickback":true};
	</script>
	<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=[YOUR PROFILE ID]"></script>


<?php } ?>	