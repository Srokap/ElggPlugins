<?php
/**
 * User hover over menu item
 */
?>
<p class="user_menu_profile">
	<a href="<?php echo $vars['url']; ?>pg/media/<?php echo $vars['entity']->username; ?>"><?php echo elgg_echo("mediaembedly"); ?></a>
</p>