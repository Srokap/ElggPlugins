<?php

	/**
	 * NoELAb Video Embedly CSS
	 * 
	 */
?>

.embed-thumbnail {
  float: left;
  max-width: 150px;
  cursor: pointer;
  margin-right:10px;
  position: relative; 
  z-index:1;
}

.embed-thumbnail img {
  max-height: 130px;
  max-width: 130px;
}

.embed-PlayButton {
	position: absolute; 
	top: 2px; 
	left: 2px; 
	z-index:2;
} 
	
.infoembedly {
    padding-left:1em;
}
.infoembedly a{
	text-align:left;
	font-family:"Lucida Grande",Verdana,sans-serif;
	font-size:12px;
	font-weight:bold;
}
.infoembedly p{
	text-align:left;
	font-family:"Lucida Grande",Verdana,sans-serif;
	font-size:9px;
}

.embed object, .embed  embed, .embed  iframe, .embed  img {
   margin:auto;
   padding-top:5px;
   width: 100%;
}
.embed iframe {
   margin:auto;
   padding-top:5px;
   width: 100%;
   height: 360px;
}
a.custom_embed { background-color:#ff00fa; }
div.embed { display:none;}

/* ***************************************
MEDIA LIBRARY
*************************************** */
.mediaembedly_content {
   width:675px;
   position: relative;
   padding:0;
   margin:15px 0 0 0;
}
.mediaembedly_wrapper{
   float: left;
   width: 450px; 
}
.mediaembedly_wrapper img {
   max-width: 100%;
}
.mediaembedly_wrapper object, .mediaembedly_wrapper embed, .mediaembedly_wrapper iframe {
   width: 100%;
}
.mediaembedly_wrapper iframe {
   width: 100%;
   height: 360px;
}
.mediaembedly_info {
   float: right;
   width: 220px;
   line-height:1em;
   color:#666666;
}
.mediaembedly_meta {
    position: relative;
    width: 400px;
    height49px;
	color:#666666;
	padding:10px 10px 10px 10px;
}
.mediaembedly_symbol {
	font-size:15px;
	padding:0px 5px;
	text-decoration:none;
}
#mediaembedly_option {
   display:none;
}
.mediaembedly_tools {
}

/* ***************************************
SEARCH LISTINING
*************************************** */
.search_listing_icon img {
  max-width: 40px;
  max-height: 40px; 
}

/* ***************************************
MEDIA ITEM
*************************************** */
.mediaembedly_item_title h3 {
	font-size: 150%;
	margin-bottom: 5px;
}
.mediaembedly_item_title h3 a {
	text-decoration: none;
}
.mediaembedly_item_owner {
	font-size: 90%;
	margin: 10px 0 0 0;
}
.mediaembedly_item_owner .icon {
	float:left;
	margin:0px 0 0 0;
	padding:0;
}
.mediaembedly_item_owner .strapline {
	margin: 0 0 0 45px;
	padding:0;
	line-height:1em;
	color:#666666;
}
.mediaembedly_item_owner p.tags {
	background:transparent url(<?php echo $vars['url']; ?>_graphics/icon_tag.gif) no-repeat scroll left 2px;
	margin:0 0 7px 45px;
	padding:0pt 0pt 0pt 16px;
	min-height:22px;
}
.mediaembedly_item_description p {
	margin:0;
	padding:5px 0 5px 0;
}
.mediaembedly_item_address a {
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #ffffff;
	background:#4690d6;
	border: 1px solid #4690d6;
	-webkit-border-radius: 3px; 
	-moz-border-radius: 3px;
	width: auto;
	height: 25px;
	padding: 2px 6px 2px 6px;
	margin:10px 0 10px 0;
	cursor: pointer;
}
.mediaembedly_item_address a:hover {
	background: #0054a7;
	border: 1px solid #0054a7;
	text-decoration: none;
}
.mediaembedly_item_controls p {
	margin:0;
}


/* ***************************************
MEDIA WIDGET VIEW 
*************************************** */


/* ***************************************
timestamp and user info in gallery and list view
*************************************** */
.search_listing_info .mediaembedly_gallery_user,
.share_gallery_info .mediaembedly_gallery_user,
.share_gallery_info .mediaembedly_gallery_comments {
	color:#666666;
	margin:0;
	font-size: 90%;	
}

/* ***************************************
RIVER
*************************************** */
.river_object_media_create {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_plugin.gif) no-repeat left -1px;
}
.river_object_media_comment {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_plugin.gif) no-repeat left -1px;
}
