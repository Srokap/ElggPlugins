<?php
  /**
   * NoELab media Embedly
   * @author NoELab.com
   * 
   * List most recent media on group profile page
   * */

if ($vars['entity']->media_enable != 'no') {

//get the num of shares the user want to display
		$num = $vars['entity']->num_display;
		
		//if no number has been set, default to 4
		if(!$num)
			$num = 5;
		
		set_context('search');
		$content = elgg_list_entities(array('type' => 'object', 'subtype' => 'media', 'container_guid' => $vars['entity']->guid, 'limit' => $num, 'offset' => 0, 'full_view' => FALSE, 'pagination' => FALSE ));
		set_context('media');
		
?>

<div class="group_widget">
<h2><?php echo elgg_echo('mediaembedly:group'); ?></h2>
        
        <?php
        if ($content) {
	    // Show medias
		echo  $content;
		
		$more_url = "{$vars['url']}pg/media/owner/group:{$vars['entity']->guid}/";
			echo "<div class=\"forum_latest\"><a href=\"$more_url\">" . elgg_echo('mediaembedly:more') . "</a></div>";
	    } else {
			echo "<div class=\"forum_latest\">" . elgg_echo("mediaembedly:nogroup") . "</div>";
	    }
?>

</div>
<?php
}