<?php
  /**
   * NoELab Media Embedly
   * @author NoELab.com
   */

if (get_plugin_setting('display_move_controls', 'noelab_media_embedly') == 'no') {
	return '';
}
?>

<div class="mediaembedly_tools">
<?php
	$groups = get_users_membership(get_loggedin_userid());
	$options = array();
	foreach ($groups as $group) {
		if ($group->guid != $vars['media']->container_guid) {
			$options[$group->guid] = $group->name;
		}
	}
	$form_body = '<label>';
	$form_body .= elgg_echo('mediaembedly:move_select');
	$form_body .= '</label>';
	$form_body .= elgg_view('input/pulldown', array('internalname' => 'group_guid',
													'options_values' => $options));
	$form_body .= elgg_view('input/hidden', array('internalname' => 'media_guid',
													'value' => $vars['media']->guid));
	$form_body .= '<br />';
	$form_body .= elgg_view('input/submit', array('value' => elgg_echo('submit')));

	echo elgg_view('input/form', array('action' => $CONFIG->url . 'action/media/move_media',
										'body' => $form_body,
										'js' => 'style="margin-top: 0; padding: 0;"'));

?>
</div>