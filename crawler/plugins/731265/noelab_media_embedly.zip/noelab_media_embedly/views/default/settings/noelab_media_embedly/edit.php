<?php
  /**
   * NoELab media Embedly
   * @author NoELab.com
   */

	// Get settings
	$media_custom_type = $vars['entity']->media_custom_type;
   
   //Media Move
   echo elgg_echo('mediaembedly:display_move'); 
?>

			<select name="params[display_move_controls]">
				<option value="user" <?php if ($vars['entity']->display_move_controls != 'admin') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('mediaembedly:admin:option:user'); ?></option>
				<option value="admin" <?php if ($vars['entity']->display_move_controls == 'admin') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('mediaembedly:admin:option:admin'); ?></option>
			</select>
			
<?php

   echo '<br />';
   //Media Featured
   echo elgg_echo('mediaembedly:admin:activefeatured');
?>

			<select name="params[featured]">
  			<option value="no" <?php if($vars['entity']->featured == 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
  			<option value="yes" <?php if($vars['entity']->featured != 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
			</select> 		

<?php

   echo '<br />';
   //Media Most Popular
   echo elgg_echo('mediaembedly:admin:activepopular');
?>

			<select name="params[popular]">
  			<option value="no" <?php if($vars['entity']->popular == 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
  			<option value="yes" <?php if($vars['entity']->popular != 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
			</select> 		
					
<?php
    echo '<br />';
	//Media Type
    echo elgg_echo('mediaembedly:admin:type');
?>

			<select name="params[media_type_selection]">
				<option value="user" <?php if ($vars['entity']->media_type_selection != 'admin') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('mediaembedly:admin:option:user'); ?></option>
				<option value="admin" <?php if ($vars['entity']->media_type_selection == 'admin') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('mediaembedly:admin:option:admin'); ?></option>
			</select>
			
<?php

	echo '<br />';
	//Media Type	
	echo elgg_echo('mediaembedly:custom:type');
	
	echo '<br />';
	echo elgg_view('input/tags',array('value' => $media_custom_type, 'internalname' => 'params[media_custom_type]'));
   
    echo '<br />';
	//Media Sharing
    echo elgg_echo('mediaembedly:admin:sharing');
?>

			<select name="params[sharing]">
  				<option value="no" <?php if($vars['entity']->sharing == 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
  				<option value="yes" <?php if($vars['entity']->sharing != 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
			</select> 	
   




