<?php if(is_plugin_enabled('tidypics')){ 
?>
  xmlns:atom="http://www.w3.org/2005/Atom"	
<?php 
}else{
?>
 xmlns:media="http://search.yahoo.com/mrss/" xmlns:atom="http://www.w3.org/2005/Atom"
<?php } ?>