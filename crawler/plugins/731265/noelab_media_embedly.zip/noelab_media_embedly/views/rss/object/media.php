<?php

	$title = $vars['entity']->title;
	if (empty($title)) {
		$title = substr($vars['entity']->description,0,32);
		if (strlen($vars['entity']->description) > 32)
			$title .= " ...";
	}
	$descr = $vars['entity']->description;
	$media_type= $vars['entity']->oembed_type;
	$mediadescr = $vars['entity']->oembed_description;
	$media_url = $vars['entity']->oembed_url;
	//$media_html = $vars['entity']->oembed_html;
	$media_thumb = $vars['entity']->oembed_thumbnail_url;


    switch($media_type) {
    	case 'photo':
			
?>

	<item>
	  <title><![CDATA[<?php echo $title; ?>]]></title>
	  <link><?php echo $vars['entity']->getURL(); ?></link>
	  <guid isPermaLink='true'><?php echo $vars['entity']->getURL(); ?></guid>
	  <pubDate><?php echo date("r",$vars['entity']->time_created) ?></pubDate>
	  <description><![CDATA[<?php echo (autop($mediadescr)); ?>]]></description>
	  <media:title><?php echo $title; ?></media:title>
	  <media:description><?php echo $mediadescr; ?></media:description>
	  <media:thumbnail url="<?php echo $media_thumb; ?>"/>
      <media:content url="<?php echo $media_url; ?>"/>
	</item>

<?php
                     	  
		break;  
		case 'link':
  		case 'rich':
  		case 'video':
?>	
    
    <item>
	  <title><![CDATA[<?php echo $title; ?>]]></title>
	  <link><?php echo $vars['entity']->getURL(); ?></link>
	  <guid isPermaLink='true'><?php echo $vars['entity']->getURL(); ?></guid>
	  <pubDate><?php echo date("r",$vars['entity']->time_created) ?></pubDate>
	  <description><![CDATA[<?php echo (autop($mediadescr)); ?>]]></description>
	  <media:title><?php echo $title; ?></media:title>
	  <media:description><?php echo $mediadescr; ?></media:description>
	  <media:thumbnail url="<?php echo $media_thumb; ?>"/>
      <media:content type="application/x-shockwave-flash" url="<?php echo $media_url; ?>"/>
	</item>
	
<?php   
        break;  
        case 'error':
        default:
}
?>
