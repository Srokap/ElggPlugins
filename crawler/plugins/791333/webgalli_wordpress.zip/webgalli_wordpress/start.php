<?php
/**
 *	Elgg - Wordpress bridge plugin
 *	Author : Mohammed Aqeel | Team Webgalli
 *	Team Webgalli | Elgg developers and consultants
 *	Mail : info@webgalli.com
 *	Web	: http://webgalli.com | http://plugingalaxy.com
 *	Skype : 'team.webgalli'
 *	@package Elgg-Wordpress bridge
 * 	Plugin info : Allow single signin/signon to between Wordpress and Elgg with Elgg as master and Wordpress as slave
 *	Licence : GNU2
 *	Copyright : Team Webgalli 2011-2012
 */

    function webgalli_wordpress_init() {
		elgg_extend_view('css','webgalli_wordpress/css');    
		elgg_extend_view('footer/analytics','webgalli_wordpress/wp_adminbar');    
    }    
    register_elgg_event_handler('init','system','webgalli_wordpress_init',999);
		
?>