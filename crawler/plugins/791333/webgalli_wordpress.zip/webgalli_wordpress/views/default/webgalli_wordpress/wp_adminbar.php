<?php
/**
 *	Elgg - Wordpress bridge plugin
 *	Author : Mohammed Aqeel | Team Webgalli
 *	Team Webgalli | Elgg developers and consultants
 *	Mail : info@webgalli.com
 *	Web	: http://webgalli.com | http://plugingalaxy.com
 *	Skype : 'team.webgalli'
 *	@package Elgg-Wordpress bridge
 * 	Plugin info : Allow single signin/signon to between Wordpress and Elgg with Elgg as master and Wordpress as slave
 *	Licence : GNU2
 *	Copyright : Team Webgalli 2011-2012
 */
?>
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/webgalli_wordpress/js/admin-bar.js"></script>
		<div id="wpadminbar_elgg">
			<?php if (isloggedin()) {
				$user = get_loggedin_user();
				$site_url = $vars['url'];
				$menu = get_register('menu');
				if (is_array($menu) && sizeof($menu) > 0) {
					$alphamenu = array();
					foreach($menu as $item) {
						$alphamenu[$item->name] = $item;
					}
					ksort($alphamenu);
				}
			?>									
			<div class="quicklinks">
			<ul>
					<li id="wp-admin-bar-my-account-with-avatar" class="menupop">
					<a href="<?php echo $user->getURL(); ?>"><span><img alt='' src='<?php echo $user->getIcon('topbar'); ?>' class='avatar avatar-16 photo' height='16' width='16' /><?php echo $user->name;?></span></a>
				<ul>
												
					<li id="wp-admin-bar" class="">
					<a href="<?php echo $site_url;?>pg/profile/<?php echo $user->username;?>/edit/"><?php echo elgg_echo('profile:edit'); ?></a>
					</li>	
					<li id="wp-admin-bar" class="">
					<a href="<?php echo $site_url;?>pg/profile/<?php echo $user->username;?>/editicon/"><?php echo elgg_echo('profile:editicon'); ?></a>
					</li>	
					
					<li id="wp-admin-bar" class="">
					<?php echo elgg_view('output/url', array('href' => "{$vars['url']}action/logout", 'text' => elgg_echo('logout'), 'is_action' => TRUE)); ?>
					</li>
				
				</ul>
			
					</li>													
					<li id="wp-admin-bar" class="">
					<a href="<?php echo $site_url;?>pg/dashboard/"><?php echo elgg_echo('dashboard'); ?></a>
					</li>	
				
				<li id="wp-admin-bar" class="menupop">
				<a href=""><span><?php echo(elgg_echo('tools')); ?></span></a>
					<ul>	
						<?php foreach($alphamenu as $item) { ?>
						<li id="wp-admin-bar" class="">
						<a href="<?php echo $item->value;?>"><?php echo $item->name;?></a>		
						</li>		
						<?php } ?>
					</ul>		
				</li>

				<?php if (is_plugin_enabled('messages')) { 
						$num_messages = count_unread_messages();
						if($num_messages){
							$num = $num_messages;
						} else {
							$num = 0;
						}
				?>
				<li id="wp-admin-bar" class="">
				<a href="<?php echo $site_url; ?>pg/messages/inbox/<?php echo $user->username; ?>"><span><?php echo elgg_echo("messages"); ?> <?php if ($num > 0) { echo "[$num]"; } ?></span></a>
				</li>	
				<?php } ?>

				<li id="wp-admin-bar" class="">
				<a href="<?php echo $site_url; ?>pg/settings/" class="usersettings"><?php echo elgg_echo('settings'); ?></a>
				</li>	
				
				<?php if (isadminloggedin()) { ?>
				<li id="wp-admin-bar" class="menupop">
				<a href="<?php echo $site_url; ?>pg/admin/statistics/"><span><?php echo elgg_echo("admin"); ?></span></a>
					<ul>					
						<li id="wp-admin-bar" class="">
						<a href="<?php echo $site_url;?>pg/admin/site"><?php echo elgg_echo('admin:site');?></a>
						</li>
						<li id="wp-admin-bar" class="">
						<a href="<?php echo $site_url;?>pg/admin/plugins"><?php echo elgg_echo('admin:plugins');?></a>
						</li>
						<li id="wp-admin-bar" class="">
						<a href="<?php echo $site_url;?>pg/admin/user"><?php echo elgg_echo('admin:user');?></a>
						</li>
					</ul>
				</li>	
				<?php } ?>
			</ul>

			</div>
			<div id="adminbarsearch-wrap">
				<form action="<?php echo $site_url; ?>pg/search/" method="get" id="adminbarsearch">
					<input class="adminbar-input" name="q" id="adminbar-search" type="text" onclick="if (this.value=='<?php echo elgg_echo('search'); ?>') { this.value='' }" value="<?php echo elgg_echo('search'); ?>" maxlength="150" />
					<?php echo elgg_view('input/securitytoken');?>
					<input type="submit" class="adminbar-button" value="Search"/>
				</form>
			</div>
			<?php } else { 
			$login_url = $vars['url'];
			if ((isset($CONFIG->https_login)) && ($CONFIG->https_login)) {
				$login_url = str_replace("http://", "https://", $vars['url']);
			}
			?>
			<div id="adminbarsearch-wrap">
				<form action="<?php echo $login_url."action/login";?>" method="post" id="adminbarsearch">
					<?php echo elgg_view('input/securitytoken');?>
					<input class="adminbar-input" name="username" id="adminbar-search" type="text" onclick="if (this.value=='<?php echo elgg_echo('username'); ?>') { this.value='' }" value="<?php echo elgg_echo('username'); ?>" maxlength="150" />
					<input class="adminbar-input" name="password" id="adminbar-search" type="password" onclick="if (this.value=='<?php echo elgg_echo('password'); ?>') { this.value='' }" value="<?php echo elgg_echo('password'); ?>" maxlength="150" />
					<input type="submit" class="adminbar-button" value="Login"/>
					<input class="adminbar-checkbox" name="s" id="adminbar-search" type="checkbox" value="" /><span class="remember">Remember me | <a href="<?php echo $vars['url'];?>pg/register">Register</a> | <a href="<?php echo $vars['url'];?>account/forgotten_password.php">Forgot password?</a></span>
				</form>
			</div>
			
			<?php } ?>
		</div>