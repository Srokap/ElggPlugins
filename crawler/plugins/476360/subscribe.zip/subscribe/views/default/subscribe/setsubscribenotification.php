<?php


		/**
	 * Subscriber
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette
	 * this plugin has been founded by Fondation Maison des Sciences de l'Homme - Paris	 
	 * @copyright Fabrice Collette 2010
	 * @link http://www.meleze-conseil.com
	 */


	global $NOTIFICATION_HANDLERS;
	

		if (isset($vars['group']) && !empty($vars['group'])) {
		$group = $vars['group'];
			

?>

		<?php
			echo elgg_view('notifications/subscriptions/jsfuncs',$vars);
		?>
		
		<p>
			<?php
			 if ($group instanceof ElggUser) {
				echo sprintf(elgg_echo('subscribe:notifications:single:subscriptions:description'), $group->name);
				} else {
        echo sprintf(elgg_echo('subscribe:notifications:single:subscriptions:description:group'), $group->name);
        }
			
			?>
		</p>

<table id="notificationstable" cellspacing="0" cellpadding="4" border="1" width="100%">
  <tr>
    <td>&nbsp;</td>
<?php
	$i = 0; 
	foreach($NOTIFICATION_HANDLERS as $method => $foo) {
		if ($i > 0)
			echo "<td class=\"spacercolumn\">&nbsp;</td>";
?>
	<td class="<?php echo $method; ?>togglefield"><?php echo elgg_echo('notification:method:'.$method); ?></td>
<?php
		$i++;
	}
?>
    <td>&nbsp;</td>
  </tr>
<?php	
      
			
				
				$fields = '';
				
				
				foreach($NOTIFICATION_HANDLERS as $method => $foo) {
					//if (in_array($group->guid,$subsbig[$method])) {
					if (check_entity_relationship($vars['user']->guid,'notify'.$method, $group->guid)){
						$checked[$method] = 'checked="checked"';
					} else {
						$checked[$method] = '';
					}
					$fields .= "<td class=\"spacercolumn\">&nbsp;</td>";
					$fields .= <<< END
					    <td class="{$method}togglefield">
					    <a border="0" id="{$method}{$group->guid}" class="{$method}toggleOff" onclick="adjust{$method}_alt('{$method}{$group->guid}');">
					    <input type="checkbox" name="{$method}subscriptions[]" id="{$method}checkbox" onclick="adjust{$method}('{$method}{$$group->guid}');" value="{$group->guid}" {$checked[$method]} /></a></td>
END;
			}
				
?>
	<tr>
		<td class="namefield">
	    	<p>
	    		<?php echo $group->name; ?>
	    	</p>
	    </td>
<?php
				echo $fields;
?>
		<td>&nbsp;</td>
	</tr>

</table>
<?php
		}

		 $ts = time();
	   $token = generate_action_token($ts);
	
	   echo elgg_view('input/hidden', array('internalname' => '__elgg_token', 'value' => $token));
	   echo elgg_view('input/hidden', array('internalname' => '__elgg_ts', 'value' => $ts));


?>
		<input type="submit" value="<?php echo elgg_echo('save'); ?>" />