<?php

		/**
	 * Subscriber
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette
	 * this plugin has been founded by Fondation Maison des Sciences de l'Homme - Paris	 
	 * @copyright Fabrice Collette 2010
	 * @link http://www.meleze-conseil.com
	 */

?>

#owner_block_subscribe {
	padding:5px 0 5px 0;
}

#owner_block_subscribe a {
	font-size: 90%;
	color:#999999;
	padding:0 0 4px 20px;
	background: url(<?php echo $vars['url']; ?>mod/subscribe/graphics/icon_followme.gif) no-repeat left top;
}

#owner_block_subscribe a:hover {
	color: #0054a7;
}

.jqpopup {
   background:#FFFFFF;
   position:absolute;
   z-index:1;border-left:1px solid #CCCCCC;border-top:1px solid #CCCCCC;border-right:2px solid #CCCCCC;border-bottom:2px solid #CCCCCC;
  -webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
   display:none;
}


.jqpopup_header{
   margin:0;padding:0;top:0;left:0;padding-left:10px;padding-right:5px;padding-bottom:2px;font-size:15px;font-weight:bold;
   cursor:move;
}

.jqpopup_footer{
   padding-left:10px;padding-right:10px;padding-bottom:5px;text-align:right;font-size:10px;
}

.jqpopup_content{
   padding-left:10px;padding-right:10px;
}

.jqpopup_message{
   padding-top:10px;padding-left:10px;padding-right:10px;padding-bottom:5px;color:red;font-size:12px;font-weight:bold;
}

.jqpopup_resize{
   background: url(<?php echo $vars['url']; ?>mod/subscribe/vendor/images/jqresize.gif) no-repeat;
   height:14px;
   width: 16px;
   position: absolute;
   padding-bottom:2px;
   padding-right:2px;
   bottom: 0;
   right: 0;
   cursor: se-resize;
}

.jqpopup_cross{
   background: url(<?php echo $vars['url']; ?>mod/subscribe/vendor/images/jqcross.jpg) no-repeat;
   height:14px;
   width: 16px;
   position: absolute;
   top: 0;
   right: 0;
   cursor: pointer;
}

.jqpopup_center{
   height:14px;
   width: 16px;
   position: absolute;
   top: 0;
   right: 18px;
   cursor: pointer;
}

.stdbtn { 
  width:280px; 
}
