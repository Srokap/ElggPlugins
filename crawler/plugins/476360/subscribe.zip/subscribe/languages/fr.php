<?php
	/**
	 * Subscriber
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette
	 * this plugin has been founded by Fondation Maison des Sciences de l'Homme - Paris	 
	 * @copyright Fabrice Collette 2010
	 * @link http://www.meleze-conseil.com
	 */


	$french = array(
	       'subscribe:owner_block_menu' => 'Suivre ce membre',
	       'subscribe:owner_block_menu:unsubscribe' => 'Ne plus suivre',
	       'subscribe:owner_block_menu:group' => 'Suivre ce groupe',
	       'subscribe:owner_block_menu:unsubscribe:group' => 'ne plus suivre',
	       'subscribe:notifications:single:subscriptions:description' => "En choisissant de suivre %s, vous serez informé chaque fois qu'il(elle) postera un nouveau contenu sur le site. Choisissez la méthode par laquelle vous souhaitez être informé(e) :",
	       'subscribe:notifications:single:subscriptions:description:group' => "En choisissant de suivre le groupe '%s', vous serez informé chaque fois qu'un nouveau contenu sera posté sur ce groupe. Choisissez la méthode par laquelle vous souhaitez être informé(e) :",
	       'subscribe:subscribers:widget:title' => 'Suivi(e) par',
	       'subscribe:num_display' => 'Nombre à afficher',
	       'subscribe:icon_size' => 'Taille des icônes',
	       'subscribe:subscribed:widget:title' => "Il(elle) les suit",
	       'subscribe:subscribers:widget:description' => 'Affiche les membres abonnés à vos contenus',
	       'subscribe:subscribed:widget:description' => 'Affiche les membres dont vous suivez les contenus',
	       'subscribe:notify:subject' => "%s s'est abonné(e) à vos contenus",
	       'subscribe:notify:message' => "%s s'est abonné à vos contenus. Il(elle) sera maintenant informé chaque fois que vous publierez un nouveau contenu. Cependant, il(elle) ne sera informé que des contenus auquels vous lui aurez donné accès en fonction de votre choix de niveau d'accès quand vous posterez un nouveau contenu.
         
Vous pouvez consulter son profil ici :
         
%s",
	       
	       
		
	);
					
	add_translation("fr",$french);
?>