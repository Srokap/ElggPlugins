<?php

		/**
	 * Subscriber
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette
	 * this plugin has been founded by Fondation Maison des Sciences de l'Homme - Paris	 
	 * @copyright Fabrice Collette 2010
	 * @link http://www.meleze-conseil.com
	 */
		
		function subscribe_plugin_init() {
			extend_view('css','subscribe/css');
      extend_view('owner_block/extend','subscribe/extendownerblock',100);
      // Extend hover-over menu	
			extend_view('profile/menu/links','subscribe/extend',400);
			global $CONFIG;
			// Load the language file
			register_translations($CONFIG->pluginspath . "subscribe/languages/");
			
      // add/remove  notification by email when joining/leaving a group
			register_elgg_event_handler('create','member','subscribe_create_member',800);
			register_elgg_event_handler('delete','member','subscribe_delete_member',800);
			register_plugin_hook('action', 'groups/join', 'subscribe_joingroup_popup');
			
		//add widgets
	    add_widget_type('subscribers',elgg_echo("subscribe:subscribers:widget:title"),elgg_echo('subscribe:subscribers:widget:description'));
	    add_widget_type('subscribed',elgg_echo("subscribe:subscribed:widget:title"),elgg_echo('subscribe:subscribed:widget:description'));
		}

		register_elgg_event_handler('init','system','subscribe_plugin_init');
		
		function is_follower($member_guid) {
    $user_guid = $_SESSION['user']->guid;
        if (!(check_entity_relationship($user_guid,'notifyemail', $member_guid)) && !(check_entity_relationship($user_guid,'notifysite', $member_guid)) ) {
        return false;
            } else { return true;}
    }
		
		function subscribe_create_member($event, $object_type, $object) {
	  global $CONFIG;
		if (isloggedin()) {
	  if (($object instanceof ElggRelationship) && ($event == 'create') && ($object_type == 'member')) {
	
		add_entity_relationship($object->guid_one, 'notifyemail', $object->guid_two);
		
  	}
	 }
	return true;
	}
	
	 function subscribe_delete_member($event, $object_type, $object) {
	  global $CONFIG;
		if (isloggedin()) {
	  if (($object instanceof ElggRelationship) && ($event == 'create') && ($object_type == 'member')) {
	
		remove_entity_relationship($object->guid_one, 'notifyemail', $object->guid_two);
		
  	}
	 }
	return true;
	}
	
	function subscribe_joingroup_popup($hook, $entity_type, $returnvalue, $params) {
	global $CONFIG;
	system_messages('dummy','subscribealert');
	return true;
}


		
?>