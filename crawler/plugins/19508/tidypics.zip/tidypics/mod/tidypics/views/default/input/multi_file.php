<?php
/**
 * Elgg multifile uploader field
 *
 * @package ElggFile
 * @author Liu Fanchao
 * @link http://simophin.cn/
 */

global $CONFIG;

$ucode = $_SESSION['user']->code;

?>

<script language="JavaScript"
	src="<?php echo $vars['url']; ?>vendors/swfupload/swfupload.js "
	type="text/javascript"></script>

<style type="text/css">
#MultiFileUploaderContainer {
	background-color: #D5D5D5;
	font-size: 12px;
	width: 400px;
}

#MultiFileUploaderTitle {
	background-color: #BEBEBE;
	font-size: 14px;
	padding: 4px;
}

#MultiFileUploaderQueue {
	padding: 5px;
}

#MultiFileUploaderButtonRow {
	padding: 3px;
	text-align: center;
}

#MultiFileUploaderButtonRow input[type=button] {
	background-color: #E7E7E7;
	border: 1px solid #BEBEBE;
	padding: 2px;
	font-size: 13px;
}

.MultiFileUploaderFileItem {
	border: 1px solid #BFBFBF;
	background-color: #E3E3E3;
	padding: 3px;
	margin: 5px 0 5px 0;
}

.MultiFileUploaderFileItemTitle {
	font-size: 13px;
	font-weight: bold;
}

.MultiFileUploaderFileItemHover {
	border: 1px solid #BFBFBF;
	background-color: #FFFFFF;
	padding: 3px;
	margin: 5px 0 5px 0;
}

.MultiFileUploaderFileItemCloseButton {
	text-align: right;
}

.MultiFileUploaderFileItemCloseButton a:link,.MultiFileUploaderFileItemCloseButton a:visited
	{
	padding: 2px;
	font-size: 12px;
	text-decoration: none;
	color: #000000;
}

.MultiFileUploaderFileItemCloseButton a:hover {
	padding: 2px;
	font-size: 12px;
	color: red;
	text-decoration: none;
}

.MultiFileUploaderFileItemProgress {
	font-size: 11px;
	color: red;
}

.ProgressBar {
	padding: 2px;
	background-color: #6E6E6E;
	border: 1px solid #BEBEBE;
	display: none;
	height: 12px;
	margin: 3px;
	text-align: center;
	font-size: 11px;
	color: #FFFFFF;
}

.ShortButton {
	background: url('<?php echo $vars['url']; ?>mod/tidypics/graphics/multifile_uploader/shortbutton.gif');
	background-repeat: no-repeat;
	background-position: center;
	font-size: 15px;
	padding: 6px;
	text-align: center;
	cursor: pointer;
	color: #FFFFFF;
	width: 100px;
	float: left;
	vertical-align: middle;
}
</style>

<script type="text/javascript" language="javascript">
var swfu;
var settings;
var success_list = new Array();

function fileQueued(fileObj)
{
	// add item in UI
	var html = '';
	var container = $("#MultiFileUploaderQueue");

	html += '<div class="MultiFileUploaderFileItem" id="'+fileObj.id+'">';
	html += '<table cellpadding="0" cellspacing="0" border="0" width="100%">';
	html += '<tr><td align="left"><div class="MultiFileUploaderFileItemTitle">'+fileObj.name +'</div></td>';
	html += '<td rowspan="2" align="right"><div class="MultiFileUploaderFileItemCloseButton" ><a href="javascript: cancelUpload(\''+fileObj.id+'\',this); "><?php echo elgg_echo('image:uploader:canceltext'); ?></a></div></td></tr>';

	html += '<tr><td align="left"><div class="MultiFileUploaderFileItemProgress" id="progess_'+fileObj.id+'"><div class="ProgressBar">&nbsp;</div></div></td></tr></table>';
	html += '</div>';
	container.append(html);
	updateHoverEffect();
}

function cancelUpload(id)
{
	swfu.cancelUpload(id,false);
	$("#"+id).fadeOut('slow');
}

function cancelAll()
{
	var queue = $("#MultiFileUploaderQueue");
	queue.children().each(function(){
		cancelUpload(this.id);
	});
}

function fileQueueError(file_obj, error_code, message)
{
	alert(message);
}

function fileDialogComplete(selected_num, queued_num, total_queued_num)
{
	
}

function uploadStart(fileObj)
{
	$("#"+fileObj.id).find('.MultiFileUploaderFileItemCloseButton').hide();
}

function uploadProgress(fileObj, bytes_completed, total_bytes)
{
	var pdiv = $("#progess_"+fileObj.id).children('div');
	//alert(pdiv.css('display') );
	if(pdiv.css('display')=='none' )
		pdiv.fadeIn('slow');
	pdiv.width( bytes_completed/total_bytes*100 + 'px' );
	pdiv.html(parseInt(bytes_completed/total_bytes*100)+'%');

}

function uploadError(fileObj, error_code, message)
{
	var s = $("#"+fileObj.id).find('.MultiFileUploaderFileItemCloseButton');
	s.show();
	s.html("Error: " + message );

}

function uploadSuccess(fileObj,data)
{
	if(data != '%error%')
	{
		$("#progess_"+fileObj.id).html('<?php echo elgg_echo('image:upload:success'); ?>');
		setTimeout("$('#"+fileObj.id+"').fadeOut('slow')",2000);
		success_list.push(data);
	}else{
		$("#progess_"+fileObj.id).html('<?php echo elgg_echo('image:upload:fail'); ?>');
	}
}

function uploadComplete()
{
	if(swfu.getStats().files_queued == 0 )
		queueComplete(swfu.getStats());
	else
		swfu.startUpload();
}

function queueComplete(status)
{
	alert("<?php echo elgg_echo('image:upload:uploadsuccessinfo'); ?>: " + status.successful_uploads + "\r\n<?php echo elgg_echo('image:upload:uploaderrorinfo'); ?>: "+status.upload_errors );
	if(success_list.length > 0 ){
		var str = success_list.join('-');
		location.href="<?php echo $vars['url']; ?>mod/tidypics/edit_multi.php?files="+str;
	}
}


function updateHoverEffect()
{
	$(".MultiFileUploaderFileItem").hover(function(){
		this.className = "MultiFileUploaderFileItemHover";
	}, function(){
		this.className = "MultiFileUploaderFileItem";
	});
}

function SWFUploadInit(file_field_id)
{
	var file = $("#"+file_field_id);
	//console.log("%o",file.get() );
	var i=0;
	var form = file;
	while( form.get(0).tagName!= "FORM" )
	{
		form = form.parent();
		if(i++ > 10 )
		 return;
	};
	form=form.get(0);
	
	var access_id_e = $(form).children('input[name=access_id]');
	var container_id_e = $(form).children('input[name=container_guid]');
	
	
	if(access_id_e.length > 0 ){
		settings['post_params']['access_id']=access_id_e.val();
	}
	
	if(container_id_e.length > 0 ){
		settings['post_params']['container_guid'] = container_id_e.val();
	}
	
	settings['upload_url'] = form.action;
	settings['file_post_name'] = $(file).attr('name');
	
	swfu = new SWFUpload(settings);
}

$( function() {
settings = {
flash_url : "<?php echo $vars['url']; ?>vendors/swfupload/swfupload.swf",
upload_url: "",
post_params: {"ucode":"<?php echo $ucode; ?>"},
file_size_limit : "2 MB",
file_types : "*.jpg;*.gif;*.png;*.pjpeg",
file_types_description : "<?php echo elgg_echo("image:uploader:acceptfiletype"); ?>",
file_upload_limit : 60,
file_queue_limit : 0,
file_post_name: 'file',
debug: false,

// Button settings
button_image_url: "<?php echo $vars['url']; ?>mod/tidypics/graphics/multifile_uploader/longbutton.gif",
button_width: "114",
button_height: "30",
button_placeholder_id: "spanButtonPlaceHolder",
button_text: '<span class="theFont"><?php echo elgg_echo("image:uploader:buttonselectfiles"); ?></span>',
button_text_style: ".theFont {font-size: 15;  color: #FFFFFF; }",
button_text_left_padding: 12,
button_text_top_padding: 3,


file_queued_handler : fileQueued,
file_queue_error_handler : fileQueueError,
file_dialog_complete_handler : fileDialogComplete,
upload_start_handler : uploadStart,
upload_progress_handler : uploadProgress,
upload_error_handler : uploadError,
upload_success_handler : uploadSuccess,
upload_complete_handler : uploadComplete
};



SWFUploadInit("MultiFileUploader");
updateHoverEffect();
     });
	

		 
	</script>

<div id="MultiFileUploaderContainer">
<div id="MultiFileUploaderTitle"><?php echo elgg_echo("image:uploader:title"); ?></div>
<div id="MultiFileUploaderButtonRow">
<table cellpadding="0" cellspacing="0" border="0" width="100%">
	<tr>
		<td align="center"><span id="spanButtonPlaceHolder"></span></td>
		<td align="center">
		<div class="ShortButton" onclick="swfu.startUpload()"><?php echo elgg_echo("image:uploader:buttonupload"); ?></div>
		</td>
		<td align="center">
		<div class="ShortButton" onclick="cancelAll()"><?php echo elgg_echo("image:uploader:buttoncancelall"); ?></div>
		</td>
	</tr>
</table>
</div>

<div id="MultiFileUploaderQueue"></div>
</div>

<input type="file"
	id="MultiFileUploader" style="display: none"
	name="<?php echo $vars['internalname']; ?>" />
