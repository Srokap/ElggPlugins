<?php
	/**
	 * Elgg multifile uploader form
	 * 
	 * @package ElggFile
	 * @author Liu Fanchao
	 * @link http://simophin.cn/
	 */
	global $CONFIG;
	//print_r($CONFIG);
	//this is for image uploads only. Image edits are handled by edit.php form
	
	$container_guid = get_input('container_guid');
	$access_id = get_entity($vars['album'])->access_id;
	$ucode = $_SESSION['user']->code;

?>

			
  <form id="form1" action="<?php echo $vars['url']; ?>action/tidypics/upload" method="post" enctype="multipart/form-data">
	<?php  echo elgg_view('input/multi_file'); ?> 
	<label><?php echo sprintf(elgg_echo('access'), 'image'); ?></label>
	<?php echo elgg_view('input/accessRead', array('internalname' => 'access_id','value' => $access_id)); ?>
	<?php				
				if ($container_guid)
					echo '<input type="hidden" name="container_guid" value="'.$container_guid.'" />';
	
			?>
  </form>