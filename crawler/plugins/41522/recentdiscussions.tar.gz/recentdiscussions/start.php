<?php

  /**
   * Elgg Online widget
   * This plugin list all the in which discussions a user recently took part of.
   * 
   * @package ElggOnline
   * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
   * @Author Jean-Baptiste Perriot <jb@perriot.fr>
   */

function recentdiscussions_init() {
  // Load system configuration
  global $CONFIG;
  
  // Load the language file
  register_translations($CONFIG->pluginspath . "recentdiscussions/languages/");
  
  //add a widget
  add_widget_type('recentdiscussions',elgg_echo("Recent discussions"),elgg_echo('recentdiscussions:widget:description'));

  // Register for index page
  extend_view('index/recentdiscussions', 'recentdiscussions/indexview');
  }

register_elgg_event_handler('init','system','recentdiscussions_init');

?>