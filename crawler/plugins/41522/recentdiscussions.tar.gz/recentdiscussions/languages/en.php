<?php

$english = array(
		 'recentdiscussions:title' => "Recent discussions",
		 );

add_translation("en",$english);

?>