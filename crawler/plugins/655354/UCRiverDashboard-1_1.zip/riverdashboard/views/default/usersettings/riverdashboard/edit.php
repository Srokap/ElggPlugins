<p>
<?php 
// get user set value or use default
$mydashboard = get_plugin_setting('useasdashboard', 'riverdashboard');
if (isset($vars['entity']->mydashboard)) {
	$mydashboard = $vars['entity']->mydashboard;
}
echo elgg_echo('riverdashboard:useasdashboard').' '; 
$options = array('no'=>elgg_echo('option:no'),'yes'=>elgg_echo('option:yes'));
echo elgg_view(	'input/pulldown',
				array(
					'internalname' => 'params[mydashboard]',
					'options_values' => $options,
					'value' => $mydashboard
				)
);
?>
</p>