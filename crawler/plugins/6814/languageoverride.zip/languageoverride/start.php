<?php
function languageoverride_init() {

}

register_elgg_event_handler('init','system','languageoverride_init');
?>