<?php
  function weather_init() {        
    add_widget_type('weather', 'Wetter', 'Widget zum anzeigen des aktuellen Wetters');
  }
 
  register_elgg_event_handler('init','system','weather_init');       
?>