<!-- some css for display -->
<style type="text/css">
    .weatherIcon { 
	float:left;
	padding: 8px;
        
     }
          
</style>
<?php

//Widget to show weather using Google weather API
//Author:J Croucher

function getWeather($loc, $tempFormat) {
	$requestAddress = "http://www.google.com/ig/api?weather=".urlencode($loc)."&hl=de&oe=utf-8";
	$xml_str = file_get_contents($requestAddress,0);
	
	// Parses XML 
	$xml = new SimplexmlElement($xml_str);
	// Loops XML
	$count = 0;
	echo '<b><div id="weather"></b>';

	foreach($xml->weather as $item) {

		foreach($item->forecast_conditions as $new) {
			$lowVal = $new->low['data'];
			$hiVal = $new->high['data'];
			echo '<div class="weatherIcon" style="text-align:center">';
			echo '<b>'.$new->day_of_week['data'].'</b>'.'<br/>';
			echo '<img title="'.$new->condition['data'].'" src="http://www.google.com/' .$new->icon['data'] . '"/><br/>';
			echo $new->condition['data'].'<br/>';			
			if($tempFormat == "Celsius")
			{			
			echo 'n. Wert: '.$lowVal.' &deg;C'.'<br/>';
			echo 'h. Wert: '.$hiVal.' &deg;C'.'<br/>';
			}
			else
			{			
			echo 'n. Wert: '. round((($lowVal * 9) /5 ) + 32) .' &deg;F'.'<br/>';
			echo 'h. Wert: '. round((($hiVal * 9) /5 ) + 32) .' &deg;F'.'<br/>';
			};
			echo '</div>';
		}
	}

	echo '</div>';
}
?>

<div class="contentWrapper">

<?php
	
	$loc = $vars['entity']->location;
	$tempFormat = $vars['entity']->tempFormat;
	echo '<div style="text-align:center;font-size:1.5em">'.'<b>'.$loc.'</b>'.'</div>'.'</br>'.'<hr>';
	getWeather($loc, $tempFormat);

?>
<div style="clear:left;"></div>
</div>