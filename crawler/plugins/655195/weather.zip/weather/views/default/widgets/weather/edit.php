<p>Ort: 
<?php 
    echo elgg_view('input/text', array( 'internalname' => 'params[location]', 
                                        'value' => $vars['entity']->location,
                                        'class' => 'weather-input-text', ) ); 
?>
</p>
<p>Temperatur Format:
<?php
    echo elgg_view('input/pulldown',array('internalname' => 'params[tempFormat]', 
					'options_values'=>array('Fahrenheit'=>'Fahrenheit','Celsius'=>'Celsius'),
					'value'=>$vars['entity']->tempFormat));
?>
</p>
