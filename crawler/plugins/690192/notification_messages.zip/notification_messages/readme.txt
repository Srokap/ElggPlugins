lang:fr
Installation :
Copier le dossier du plugin dans le dossier /mod puis l'éctiver via le panneau d'administration. Placer le plugin à la fin de la liste, ou du moins après les plugins dont il modifie le comportement : groups, messages, bookmarks, pages, blog, etc.

Comment vérifier que le plugin fonctionne ?
Vérifier le titre (et le corps des messages) des notifications envoyées : si elles diffèrent de celles par défaut, c'est bon !

0.3 TODO : différencier les messages selon les types d'édition
0.2 Correction des variables (bon éditeur et owner)
0.1 Interception des notifications


##########################################
lang:en
Installation :
Put into mod and enable in the admin panel. Place as the bottom of the list, as it overrides several plugins behaviours.

How to confirm the plugin is working ?
Check the header of an email that was sent after the plugin was enabled. Title and message content should change from the default.

