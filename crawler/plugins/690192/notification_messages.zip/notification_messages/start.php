<?php
/**
 * Elgg notification messages plugin
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Facyla
 * @copyright (cc) Facyla 2010
 * @link http://id.facyla.net/
 * Description :
 ** Mode Elgg par défaut : tous nouveaux contenus notifiés sauf les page_top (corrigé par ce plugin: page_top aussi notifiés). Par contre les sous-pages sont notifiées sans tenir compte des droits (=> pages à corriger)
 ** Seuls les contenus d'accès "Public" et "Membres du site" sont notifiés (corrigé par ce plugin: tous types d'accès sont notifiés)
 ** Pas de notification sur les commentaires sauf dans les forums (corrigé par ce plugin: prise en charge des autres types d'objets)
 ** Messages maintenant différenciés selon le type d'événement, la méthode utilisée et le contexte (groupe ou non)
 */

function notificationmessages_init() {
  global $CONFIG;
  
  /* GESTION DES MESSAGES PAR DEFAUT (HOOKS DE NOTIFICATION) */
  // Use following code to suppress existing default subject hooks (useless with this plugin - only for information)
  // Pour retirer les hooks de notification et redéfinir les intitulés proprement (inutile avec ce plugin qui les redéfinit sans utiliser ces titres par défaut)
  /*
  if (isset($CONFIG->hooks['notify:entity:message']['object']))
    // Messages par défaut des notifications
    foreach($CONFIG->hooks['notify:entity:message']['object'] as $key => $function) {
      if ($function == 'blog_notify_message') unset($CONFIG->hooks['notify:entity:message']['object'][$key]);
      if ($function == 'bookmarks_notify_message') unset($CONFIG->hooks['notify:entity:message']['object'][$key]);
      if ($function == 'file_notify_message') unset($CONFIG->hooks['notify:entity:message']['object'][$key]);
      if ($function == 'groupforumtopic_notify_message') unset($CONFIG->hooks['notify:entity:message']['object'][$key]);
      if ($function == 'messages_notification_msg') unset($CONFIG->hooks['notify:entity:message']['object'][$key]);
      if ($function == 'page_notify_message') unset($CONFIG->hooks['notify:entity:message']['object'][$key]);
      if ($function == 'thewire_notify_message') unset($CONFIG->hooks['notify:entity:message']['object'][$key]);
      if ($function == 'tidypics_notify_message') unset($CONFIG->hooks['notify:entity:message']['object'][$key]);
    }
  */

  /* GESTION DES HOOKS DE NOTIFICATION */
  // Suppression des hooks existants : seuls les groupes l'utilisent (et ce plugin)
  /*
    if (isset($CONFIG->hooks['object:notifications']['object']))
      foreach($CONFIG->hooks['object:notifications']['object'] as $key => $function) {
        if ($function == 'group_object_notifications_intercept') unset($CONFIG->hooks['object:notifications']['object'][$key]);
      }
  */
  // Intercepts and rewrites object_notifications fonction
  register_plugin_hook('object:notifications','object','notificationmessages_object_notifications', 1000);
  
  
  /* GESTION DES OBJETS A NOTIFIER OU PAS */
  // Register subtypes that weren't handled yet / Ajoute les types d'objets non enregistrés
  register_notification_object('object', 'page_top', elgg_echo('pages:new')); // Top-level pages weren't registered yet
  // Pour désactiver les notifications sur certains objets, utiliser // if (isset($CONFIG->register_objects['object']['page'])) unset($CONFIG->register_objects['object']['page']);

  
  /* GESTION DES HANDLERS DE PRISE EN CHARGE DES EVENEMENTS */
  // Interception des événements - seul object_notifications le fait (on pourrait carrément l'invalider et remplacer, mais pas très utile, le hook suffit)
  // On supprimer carrément le système par défaut (qui intercepte create,object) pour le remplacer par celui de ce plugin, MAIS on l'utilise quand même
  if (isset($CONFIG->events['create']['object']))
    foreach($CONFIG->events['create']['object'] as $key => $function)
      if ($function == 'object_notifications') unset($CONFIG->events['create']['object'][$key]);
	// Variables à récupérer (sinon on a le contenu de l'article d'origine au lieu de celui de l'annotation). Entretemps, on ne met pas le contenu, point.
	// @todo: find how to get the current annotation content, instead of previous comment. No content should be send before it's done.
	// Note : Owner is notified correctly (directly, when adding the comment, no hook provided)
	register_elgg_event_handler('create','object','notificationmessages_create_handler', 1000); // Suite à une création
	register_elgg_event_handler('update','object','notificationmessages_update_handler', 1000); // Suite à une modification
	register_elgg_event_handler('annotate','object','notificationmessages_annotate_handler', 1000); // Suite à un commentaire

}



/* Filter which elements are notified on "create" event type */
function notificationmessages_create_handler($event, $object_type, $object) {
  static $notification_messages_flag2; if (!isset($notification_messages_flag2)) $notification_messages_flag2 = 0;
  if (is_callable('object_notifications')) {
    if ($object instanceof ElggObject) {
      $object_subtype = $object->getSubtype();
      // A few valid subtypes (if activated) : blog,bookmarks,event_calendar,file,groupforumtopic,izap_videos,page,page_top,thewire
      // Admin settings allowed subtypes - default is empty (it's a filter)
      $createsubtypes = trim(get_plugin_setting('createsubtypes'));
      if (strlen($createsubtypes) > 0) { $a_subtypes = array('object' => string_to_tag_array($createsubtypes)); } else { $a_subtypes = ""; }
      if (in_array($object_subtype, $a_subtypes)) {
        if ($notification_messages_flag2 == 0) {
          $notification_messages_flag2 = 1;
          object_notifications($event, $object_type, $object);
        }
      }
    }
  }
}


/* Filter which elements are notified on "update" event type */
function notificationmessages_update_handler($event, $object_type, $object) {
  static $notification_messages_flag2; if (!isset($notification_messages_flag2)) $notification_messages_flag2 = 0;
  if (is_callable('object_notifications')) {
    if ($object instanceof ElggObject) {
      $object_subtype = $object->getSubtype();
      // A few valid subtypes (if activated) : blog,bookmarks,event_calendar,file,groupforumtopic,izap_videos,page,page_top,thewire
      // Admin settings allowed subtypes - default is empty (it's a filter)
      $updatesubtypes = trim(get_plugin_setting('updatesubtypes'));
      if (strlen($updatesubtypes) > 0) { $a_subtypes = array('object' => string_to_tag_array($updatesubtypes)); } else { $a_subtypes = ""; }
      if (in_array($object_subtype, $a_subtypes)) {
        if ($notification_messages_flag2 == 0) {
          $notification_messages_flag2 = 1;
          object_notifications($event, $object_type, $object);
        }
      }
    }
  }
}

/* Filter which elements are notified on "annotate" event type */
function notificationmessages_annotate_handler($event, $object_type, $object) {
  static $notification_messages_flag; if (!isset($notification_messages_flag)) $notification_messages_flag = 0;
  if (is_callable('object_notifications')) {
    if ($object instanceof ElggObject) {
      $object_subtype = $object->getSubtype();
      // A few valid subtypes (if activated) : blog,bookmarks,event_calendar,file,groupforumtopic,izap_videos,page,page_top,thewire
      // Admin settings allowed subtypes - default is empty (it's a filter)
      $annotatesubtypes = trim(get_plugin_setting('annotatesubtypes'));
      if (strlen($annotatesubtypes) > 0) { $a_subtypes = array('object' => string_to_tag_array($annotatesubtypes)); } else { $a_subtypes = ""; }
      if (in_array($object_subtype, $a_subtypes)) {
        if ($notification_messages_flag == 0) {
          $notification_messages_flag = 1;
          object_notifications($event, $object_type, $object);
        }
      }
    }
  }
}



/* Defines subject and message body for any event, object subtype, notification method and publication context (ie. group)
 * Replaces the object_notifications default content
 * Doesn't consider the existing default messages hooks (as it intercepts them before they're used)
 * As it is a hook, we already know that $object is a valid ElggEntity
*/
function notificationmessages_object_notifications($hook, $entity_type, $returnvalue, $params) {
  if (isset($params)) { $event = $params['event']; $object = $params['object']; $object_type = $params['object_type']; }
  global $CONFIG, $SESSION, $NOTIFICATION_HANDLERS; // Get config data
  // This checks that only 1 notification is sent to each unique user, even if called by various plugins ou settings - change timeframe if it doesn't work as expected (e.g. if <= time() + 10)
//  if ( $CONFIG->notifiedusers != time() ) { $CONFIG->notifiedusers = time(); } else { return true; }
  if ( !isset($CONFIG->notifiedusers) ) { $CONFIG->notifiedusers = time(); } else { return true; }

//  $object_type = $object->getType(); // Inutile a priori
  if ($object_type == 'object') {
    $object_subtype = $object->getSubtype();
    if (empty($object_subtype)) { $object_subtype = 'default'; }
    
    // Configurable hook return value (let's define how we handle unknown subtypes)
    $hookreturnvalue = trim(get_plugin_setting('hookbehaviour'));
    if (strlen($hookreturnvalue) > 1) {
      if ($hookreturnvalue === "null") { $hookreturnvalue === null; } 
      else if ($hookreturnvalue === "true") { $hookreturnvalue === true; } 
      else if ($hookreturnvalue === "false") { $hookreturnvalue === false; } 
      else { $hookreturnvalue = false; } // Use default (there is no other valid value)
    } else {
      $hookreturnvalue = false; // Default is false = use standard system if subtype not handled
    }
    // This a double-filter as it's already defined before, but may not be defined, or we might want a global filter instead of sevral ones..
    // We don't want to intercept subtypes that are not handled
    // On vérifie ici qu'on est dans la bonne gamme de subtypes, sinon on renvoie false pour passer sur le comportement standard, null pour le comportement par défaut, ou true pour ne rien faire du tout
    // A few valid subtypes (if activated) : blog,bookmarks,event_calendar,file,groupforumtopic,izap_videos,page,page_top,thewire
    // Messages : à ajouter une fois le message standard invalidé
    // Admin settings allowed subtypes - default is empty (it's a filter)
    $globalsubtypes = trim(get_plugin_setting('globalsubtypes'));
    if (strlen($globalsubtypes) > 0) { $a_subtypes = array('object' => string_to_tag_array($globalsubtypes)); } else { $a_subtypes = ""; }
    if (in_array($object_subtype, $a_subtypes)) {
    
      // S'il y a des notifications pour ce type d'objets
      if (isset($CONFIG->register_objects[$object_type][$object_subtype])) {
        
        // On définit ici les variables à utiliser
        $descr = $CONFIG->register_objects[$object_type][$object_subtype];  // The default string for notification title (static string, one per object)
        $content_link = $object->getURL();  // nouvelle version : seulement le lien vers l'objet (string)
        $owner = $object->getOwnerEntity();
        $container_guid = $object->container_guid;  // le GUID du conteneur : intéressant si c'est un groupe (TODO: filtrer si pas groupe pour éviter de l'afficher)
        $container = get_entity($container_guid);
        if ($object->getOwner()) { $owner_guid = $object->getOwner(); } else { $owner_guid = NULL; }
        if ($object->container_guid) { $container_name = get_entity($object->container_guid)->name; } else { $container_name = ""; }
        if ($owner->name) { $owner_name = $owner->name; } else { $owner_name =""; } // Owner du sujet (owner de l'objet notifié - pas des commentaires)
        $editor = $SESSION['user']->name; // éditeur de l'objet : auteur du commentaire ou de la modification
        
        // Distinction entre contexte de groupe ou en dehors (perso)
        $translate_owner = "";
        if ($container->getType() == 'group' && ($event == 'create') ) {
          if ($container->name) { $owner_name = "le groupe " . $container->name; } else { $owner_name =""; } // Owner différencié si c'est un groupe
          $translate_owner = ":group";
        }
        if ($object->description) { $description = $object->description; } else { $description = ""; }  // description : on teste les valeurs tant qu'on n'a pas obtenu un contenu pertinent
        if (empty($description)) $description = $object->content;
        if (empty($description)) $description = $object->value;
        if (empty($description)) $description = $object->briefdescription;
        if (empty($description)) $description = $object->msg;
        if (empty($description)) $description = get_input('topicmessage');
        if (empty($description)) $description = get_input('topic_post');
        
        // Dernier commentaire : on ne récupère en fait que l'avant-dernier...
        $latestcomment = $object->getAnnotations('generic_comment', 1, 0, 'desc');
        if ($latestcomment) { $lastcomment = $latestcomment[0]->value; }
        
/*
        // Description de la page modifiée : sauvée à la fois dans -> description et comme annotation de type 'page'
        if ($object_subtype == "page" || $object_subtype == "page_top" ) {
          // S'il existe une annotation, la dernière est la description actuelle, sinon on prend la description
          // Facyla : @todo problème = l'annotation n'est sauvée que +tard, on a seulement l'avant -dernière...
          $latestpage = $object->getAnnotations('page', 1, 0, 'desc');
          if ($latestpage) { $description = $latestpage[0]->value; }
        }
*/
        if ($object->fromId) { $sender = $object->fromId; } else { $sender = ""; }  // Auteur du message
        if ($object->title) { $title = $object->title; } else { $title = ""; }  // Titre du message
        if ($CONFIG->sitename) { $sitename = $CONFIG->sitename; } else { $sitename = ""; }  // Nom du site
        if ($CONFIG->url) { $site_url = $CONFIG->url; } else { $site_url = ""; }  // URL du site (racine)

        $usedmethods = array(); $notifiedusers = array();
        // Get users interested in content from this person and notify them
        // (Person defined by container_guid so we can also subscribe to groups if we want)
        foreach($NOTIFICATION_HANDLERS as $method => $foo) {
          if (in_array($method, $usedmethods)) { continue; } $usedmethods[] = $method; /* Dédoublonnage des méthodes de notification */
          $interested_users = null;
          if ($interested_users = get_entities_from_relationship('notify' . $method,$object->container_guid,true,'user','',0,'',99999, 0, false, -1)) { // compatible multisite
            if (is_array($interested_users)) {
              $user = null;
              foreach($interested_users as $user) {
                $tests = null;
                /* Dédoublonnage des destinataires (pour chaque méthode) */
                $usermethod = $method . $user->guid;
                if (in_array($usermethod, $notifiedusers)) { continue; }
                $notifiedusers[] = $usermethod;
                if ( ($user instanceof ElggUser) && (!$user->isBanned()) ) {
/* VERY IMPORTANT : has_access_to_entity defaults to loggedin user, which results in serious information leaks if access rights are not carefully checked */
// $notify_self = true; // @todo Settings : Self notify ? / S'envoyer un message à soi-même ?
                    if (($user->guid != $SESSION['user']->guid) && has_access_to_entity($object,$user) && $object->access_id != ACCESS_PRIVATE) {

                    // Clear the message strings to avoid duplicates or leaks
                    $subject = null; $method_message = null; $username = null; $name = null; $msg_url = null; $reply_url = null;
                    if ($user) { $username = $user->username; $name = $user->name; } else { $username = ""; $name = ""; }
                    
                    // Build messages URL depending on multisite messages use or not - useful only for messages
                    $msg_url = ""; $reply_url = "";
                    if ($object_subtype == 'messages') {
                      if (is_plugin_enabled('multimsg')) { $msg_plugin = 'multimsg'; } else {  $msg_plugin = 'messages'; }
                      $msg_url = $site_url . "pg/$msg_plugin/$username";
                      $reply_url = $site_url . "mod/$msg_plugin/send.php?send_to=$sender";
                    }
                    
                    // Translation string
                    switch($method) {
                       case 'email': $translate_method = ""; break;
                       case 'sms': $translate_method = "sms:"; break;
                       case 'site': $translate_method = "site:"; break;
                       default: $translate_method = ""; break; // Default is like email
                    }

                    /* Differentiate messages depending on : event, subtype, method, and whether it's in a group or not
                      Syntaxe : notification_messages: SUBTYPE : EVENT : (METHOD:) OTHER (:GROUP)
                      Principe d'ordre des variables dans les sprintf à normaliser : du primordial et générique à l'accessoire
                      Pour passer le nom "officiel" de l'objet dans les traductions du système => elgg_echo("item:object:$object_subtype")
                    */
                    
/* Default values : use the object_subtypes switches ONLY to handle special types (modify default values, eg. messages, or disallow notification..).
* Default values can be used safely, as they default to smthg meaningful if supplied types are not handled
* object_subtypes defaults to "default"
* event doesn't defaults, but there are only 3 types : create, update, annotate
* translate_method defaults to (empty)
* translate_owner defaults to (empty)
*/
                    switch($event) {
                      case 'create': /* CREATION D'UN CONTENU */
                        $subject = sprintf(elgg_echo('notification_messages:' . $object_subtype . ':' . $event . ':' . $translate_method . 'subject' . $translate_owner), $title, $editor, $container_name, $owner_name);
                        $method_message = sprintf(elgg_echo('notification_messages:' . $object_subtype . ':' . $event . ':' . $translate_method . 'message' . $translate_owner), $content_link, $title, $name, $container_name, $editor, $description, $owner_name);
                        switch($object_subtype) {
                          case 'blog': break;
                          case 'bookmarks': break;
                          case 'event_calendar': break;
                          case 'file': break;
                          case "izap_videos": break;
                          case 'multipublisher': break;
                          case 'multipublisher_comment': break;
                          case 'page_top': break;
                          case 'page': break;
                          case 'thewire': // Jamais dans un groupe
                            $subject = sprintf(elgg_echo('notification_messages:thewire:create:' . $translate_method . 'subject'), $title, $editor);
                            $method_message = sprintf(elgg_echo('notification_messages:thewire:create:' . $translate_method . 'message'), $content_link, $title, $name, $container_name, $editor, $description, $owner_name);
                            break;
                          case 'messages': // Peuvent être envoyés par un groupe (mais groupe pas owner ?)
                            $subject = sprintf(elgg_echo('notification_messages:messages:create:' . $translate_method . 'subject'), $title, $editor);
                            $method_message = sprintf(elgg_echo('notification_messages:messages:create:' . $translate_method . 'message'), $content_link, $title, $name, $container_name, $editor, $description, $sender, $sitename, $msg_url, $reply_url, $owner_name);
                            break;
                          case "groupforumtopic": // Forcément dans un groupe
                            $subject = sprintf(elgg_echo('notification_messages:groupforumtopic:create:' . $translate_method . 'subject'), $title, $editor, $container_name, $owner_name);
                            $method_message = sprintf(elgg_echo('notification_messages:groupforumtopic:create:' . $translate_method . 'message'), $content_link, $title, $name, $container_name, $editor, $description, $owner_name);
                            break;
                          default: break;
                        }
                        break;

                      case 'update': /* MISE A JOUR D'UN CONTENU */
                        //return false; // Méthode radicale pour utiliser les notifications standard (aucun intérêt..)
                        $description = ""; // We want to check that every notification has the right content before enabling this by default - @todo : find how to get the current content and not the former !
                        $subject = sprintf(elgg_echo('notification_messages:' . $object_subtype . ':' . $event . ':' . $translate_method . 'subject' . $translate_owner), $title, $editor, $container_name, $owner_name);
                        $method_message = sprintf(elgg_echo('notification_messages:' . $object_subtype . ':' . $event . ':' . $translate_method . 'message' . $translate_owner), $content_link, $title, $name, $container_name, $editor, $description, $owner_name);
                        switch($object_subtype) {
                          case 'blog': break;
                          case 'bookmarks': break;
                          case 'event_calendar': break;
                          case 'file': break;
                          case "izap_videos": break;
                          case 'multipublisher': break;
                          case 'multipublisher_comment': break;
                          case 'page_top': break;
                          case 'page': break;
                          case 'thewire': // Jamais dans un groupe
                            $subject = sprintf(elgg_echo('notification_messages:thewire:update:' . $translate_method . 'subject'), $title, $editor);
                            $method_message = sprintf(elgg_echo('notification_messages:thewire:update:' . $translate_method . 'message'), $content_link, $title, $name, $container_name, $editor, $description, $owner_name);
                            break;
                          case 'messages': // Peuvent être envoyés par un groupe (mais groupe pas owner ?)
                            $subject = sprintf(elgg_echo('notification_messages:messages:update:' . $translate_method . 'subject'), $title, $editor);
                            $method_message = sprintf(elgg_echo('notification_messages:messages:update:' . $translate_method . 'message'), $content_link, $title, $name, $container_name, $editor, $description, $sender, $sitename, $msg_url, $reply_url, $owner_name);
                            break;
                          case "groupforumtopic": // Forcément dans un groupe
                            $subject = sprintf(elgg_echo('notification_messages:groupforumtopic:update:' . $translate_method . 'subject'), $title, $editor, $container_name, $owner_name);
                            $method_message = sprintf(elgg_echo('notification_messages:groupforumtopic:update:' . $translate_method . 'message'), $content_link, $title, $name, $container_name, $editor, $description, $owner_name);
                            break;
                          default: break;
                        }
                        break;

                      case 'annotate': /* COMMENTAIRE SUR UN CONTENU */
                        //return false; // Méthode radicale pour utiliser les notifications standard (aucun intérêt..)
                        $description = ""; // We don't want to notify former annotation - @todo : find how to get the current annotation !
                        $subject = sprintf(elgg_echo('notification_messages:' . $object_subtype . ':' . $event . ':' . $translate_method . 'subject' . $translate_owner), $title, $editor, $container_name, $owner_name);
                        $method_message = sprintf(elgg_echo('notification_messages:' . $object_subtype . ':' . $event . ':' . $translate_method . 'message' . $translate_owner), $content_link, $title, $name, $container_name, $editor, $description, $owner_name);
                        switch($object_subtype) {
                          case 'blog': break;
                          case 'bookmarks': break;
                          case 'event_calendar': break;
                          case 'file': break;
                          case "izap_videos": break;
                          case 'multipublisher': break;
                          case 'multipublisher_comment': break;
                          case 'page_top': break;
                          case 'page': break;
                          case 'thewire': // Jamais dans un groupe
                            $subject = sprintf(elgg_echo('notification_messages:thewire:annotate:' . $translate_method . 'subject'), $title, $editor);
                            $method_message = sprintf(elgg_echo('notification_messages:thewire:annotate:' . $translate_method . 'message'), $content_link, $title, $name, $container_name, $editor, $description, $owner_name);
                            break;
                          case 'messages': // Peuvent être envoyés par un groupe (mais groupe pas owner ?)
                            $subject = sprintf(elgg_echo('notification_messages:messages:annotate:' . $translate_method . 'subject'), $title, $editor);
                            $method_message = sprintf(elgg_echo('notification_messages:messages:annotate:' . $translate_method . 'message'), $content_link, $title, $name, $container_name, $editor, $description, $sender, $sitename, $msg_url, $reply_url, $owner_name);
                            break;
                          case "groupforumtopic": // Forcément dans un groupe
                            $subject = sprintf(elgg_echo('notification_messages:groupforumtopic:annotate:' . $translate_method . 'subject'), $title, $editor, $container_name, $owner_name);
                            $method_message = sprintf(elgg_echo('notification_messages:groupforumtopic:annotate:' . $translate_method . 'message'), $content_link, $title, $name, $container_name, $editor, $description, $owner_name);
                            break;
                          default:break;
                        }
                        break;
                        
                      // Should never happen.. & events default to "default:" anyway, so no need to handle this explicitely
                      default: break;
                    }
                    
                    if (!empty($subject)) {
/* TESTS : uncomment and add to subject or message body to use */
/*
object_subtype : $object_subtype
\n event : $event
\n content_link $content_link 
\n editor $editor 
\n name : $name 
\n method : $method
\n translate_method : $translate_method 
\n translate_owner : $translate_owner 
\n sender : $sender
\n sitename : $sitename
\n msg_url : $msg_url
\n reply_url : $reply_url
\n object->msg : ".$object->msg."
\n topicmessage : ".get_input('topicmessage')."
\n topic_post : ".get_input('topic_post')." 
$tests .= "
\n object_subtype : $object_subtype
\n title : $title 
\n container_name : $container_name 
\n owner_name : $owner_name 
\n lastcomment : $lastcomment 
\n description : ".$object->description."
\n\n";
*/

                      // $eventtype = sprintf(elgg_echo('notification_messages:events:update'), $object_subtype);
                      $eventtype = "";
                      $subject = sprintf(elgg_echo('notification_messages:subject:' . $translate_method  . 'wrapper'), $subject);
                      $method_message = sprintf(elgg_echo('notification_messages:message:' . $translate_method . 'wrapper'), $method_message, $name, $sitename);
                      
                      // Envoi effectif du message (sans bypasser les méthodes du core)
                      notify_user($user->guid, $object->container_guid, $subject, $method_message, NULL, array($method));
                    }
                  }
                }
              }
            }
          }
        }
      }
      // True signale que le hook a fonctionné correctement, sinon on envoie en doublon avec l'ancien système
      return true;
    /* Si mis à true, on n'utilise pas la fonction de notification d'elgg par défaut lorsque 
     * le type de contenu est intercepté mais pas pris en charge (par ex. les messages envoyés suite aux 
     * notifications) ; si false ou null, on reçoit aussi des mails adressés à d'autres.
    */
//    } else { return false; }
    } else { return $hookreturnvalue; }
  }
}


register_elgg_event_handler('init','system','notificationmessages_init', 1000);
