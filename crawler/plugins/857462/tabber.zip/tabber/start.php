<?php
elgg_register_event_handler('init','system','tabber_init');
function tabber_init() {
	// Extend system CSS and JS with our own styles
	elgg_extend_view('css/elgg', 'tabber/css');
	elgg_extend_view('js/elgg', 'tabber/js');
}		

