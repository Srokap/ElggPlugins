# iShouvik Tabber Framework for elgg #
This elgg plugin basically is a framework to allow developers to create tabbed content based on Tabber Tabs.

## How to ##
*	Please, put the plugin at the top of the plugin order and use the following format to create tabber pages.

*	See the example.php file for coding examples
