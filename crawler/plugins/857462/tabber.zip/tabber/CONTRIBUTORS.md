* BarelyFitz Designs, Original Tabber Author <http://www.barelyfitz.com/projects/tabber/>
* Shouvik Mukherjee, Tabber plugin for Elgg <contact@ishouvik.com>

