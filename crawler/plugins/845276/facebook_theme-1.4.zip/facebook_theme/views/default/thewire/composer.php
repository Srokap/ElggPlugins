<?php
echo elgg_view_form('thewire/add');