<?php
elgg_load_library('elgg:bookmarks');
echo elgg_view_form('bookmarks/save', array(), $vars);