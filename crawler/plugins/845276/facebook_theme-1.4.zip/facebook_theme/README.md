# Facebook Theme for Elgg #
This Elgg plugin is a theme built for Elgg 1.8 that will make your site look very much like Facebook.
It is meant to be a demonstration of what is possible with the very strong theming capabilities of Elgg 1.8.

## Disclaimers ##
*	This theme is written for Elgg 1.8. It is guaranteed to break on 1.7.

*	This theme will not be backported to 1.7. Instead, I strongly recommend that you upgrade.

*	This theme is not in any way affiliated with Facebook or anyone working at Facebook.

*	This theme has been written without any research into the legality of its use on a production site, 
	therefore I urge you not to use it on a production site until you have done proper research. If you
	are unwilling to do the research, please use this theme only as an example or starting point, and 
	not as your final theme.