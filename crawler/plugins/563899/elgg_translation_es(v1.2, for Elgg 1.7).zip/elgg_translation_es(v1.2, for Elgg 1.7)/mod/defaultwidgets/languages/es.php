<?php

$spanish = array (

	/**
	 * Nice name for the entity (shown in admin panel)
	 */
	'item:object:moddefaultwidgets' => 'Configuración por defecto de los Widgets',

	/**
	 * Menu items
	 */
	'defaultwidgets:menu:profile' => 'Perfil por defecto',
    	'defaultwidgets:menu:dashboard' => 'Escritorio por defecto',

    	'defaultwidgets:admin:error' => 'Error! No eres administrador',
	'defaultwidgets:admin:notfound' => 'Error! La página no existe. Intentalo de nuevo o ponte en contacto con el administrador',
	'defaultwidgets:admin:loginfailure' => 'Qué haces!!, no estas logueado como administrador',

	'defaultwidgets:update:success' => 'La configuración de tu widget ha sido salvada con éxito',
	'defaultwidgets:update:failed' => 'Error!. la configuración no ha sido guardada. Intentalo de nuevo o ponte en contacto con el administrador',
	'defaultwidgets:update:noparams' => 'Error!, parámetros incorrectos. Prueba de nuevo o ponte en contacto con el admnistrador',

	'defaultwidgets:profile:title' => 'Elige los widgets que quieres por defecto para los perfiles de los usuarios nuevos',
	'defaultwidgets:dashboard:title' => 'Eligue los widgets por defecto para el escritorio de los usuarios nuevos',
);

add_translation ( "es", $spanish );
