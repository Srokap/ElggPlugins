<?php

// Generado por translationbrowser 

$spanish = array( 
	 'categories'  =>  "Categorías" , 
	 'categories:settings'  =>  "Edita las categorías del sitio" , 
	 'categories:explanation'  =>  "Para establecer algunas categorías globales para el sitio que serán usadas a través de tu sistema, introdúcelas abajo separadas por comas. Serán mostradas por las herramientas compatibles cuando el usuario cree o edite contenido." , 
	 'categories:save:success'  =>  "Las categorías del sitio se han grabado correctamente."
); 

add_translation('es', $spanish); 

?>