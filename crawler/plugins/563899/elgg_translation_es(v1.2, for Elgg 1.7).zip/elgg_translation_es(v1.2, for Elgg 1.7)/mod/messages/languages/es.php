<?php

// Generado por translationbrowser 

$spanish = array( 
	 'messages'  =>  "Mensajes" , 
	 'messages:back'  =>  "volver a mensajes" , 
	 'messages:user'  =>  "Buzón de correo" , 
	 'messages:sentMessages'  =>  "Enviar mensaje" , 
	 'messages:posttitle'  =>  "mensaje de %s: %s" , 
	 'messages:inbox'  =>  "Buzón de correo" , 
	 'messages:send'  =>  "Enviar un mensaje" , 
	 'messages:sent'  =>  "Enviar mensaje" , 
	 'messages:message'  =>  "Mensaje" , 
	 'messages:title'  =>  "Título" , 
	 'messages:to'  =>  "Para" , 
	 'messages:from'  =>  "Desde" , 
	 'messages:fly'  =>  "Enviar" , 
	 'messages:replying'  =>  "Mensaje respondido a" , 
	 'messages:sendmessage'  =>  "Enviar un mensaje" , 
	 'messages:compose'  =>  "Enviar un mensaje" , 
	 'messages:sentmessages'  =>  "Ver mensajes enviados" , 
	 'messages:recent'  =>  "Mensajes recientes" , 
	 'messages:original'  =>  "Mensaje original" , 
	 'messages:yours'  =>  "Tu mensaje" , 
	 'messages:answer'  =>  "Contestar" , 
	 'messages:toggle'  =>  "Seleccionar todos" , 
	 'messages:markread'  =>  "Marcar como leído" , 
	 'messages:new'  =>  "Nuevo mensaje" , 
	 'notification:method:site'  =>  "Red" , 
	 'messages:error'  =>  "Hubo un problema al guardar tu mensaje. Por favor, vuelve a intentarlo." , 
	 'item:object:messages'  =>  "Mensajes" , 
	 'messages:posted'  =>  "El mensaje se ha enviado con éxito" , 
	 'messages:deleted'  =>  "El mensaje se ha eliminado con éxito" , 
	 'messages:markedread'  =>  "Los mensajes se han marcado como leídos con éxito" , 
	 'messages:email:subject'  =>  "Tienes un mensaje nuevo en tu buzón de correo!" , 
	 'messages:email:body'  =>  "Tienes un mensaje nuevo de %s. Dice:

			
%s


Para ver tus mensajes haz click aqui:

	%s

Para enviar un mensaje a %s haz click aqui:

	%s

Por cierto... no respondas a este correo. Es una máquina quien te lo envia ;)" , 
	 'messages:blank'  =>  "Fijate bien!, tienes que poner algo en el cuerpo del mensaje antes de que podamos guardar el mensaje." , 
	 'messages:notfound'  =>  "Vaya!, no hemos podido encontrar el mensaje solicitado. Intentalo de nuevo o ponte en contacto con el administrador" , 
	 'messages:notdeleted'  =>  "0ps!, no hemos podido eliminar el mensaje. Intentalo de nuevo o ponte en contacto con el administrador" , 
	 'messages:nopermission'  =>  "No flipes!, no tienes permisos para modificar este mensaje" , 
	 'messages:nomessages'  =>  "No hay ningún mensaje que mostrar" , 
	 'messages:user:nonexist'  =>  "No hemos podido encontrar el destinatario en la base de datos de usuarios. Intentalo de nuevo o ponte en contacto con el administrador" , 
	 'messages:enable:privacy'  =>  "Activar privacidad de usuario" , 
	 'messages:friendsonly'  =>  "Selecciona \"Si\" si solamente quieres recibir mensajes de tus amigos:" , 
	 'messages:noaccess'  =>  "El usuari@ ha decidido que solo quiere recibir mensajes de sus amig@s" , 
	 'messages:user:blank'  =>  "No has seleccionado a nadie para enviarle ésto :)"
); 

add_translation('es', $spanish); 

?>
