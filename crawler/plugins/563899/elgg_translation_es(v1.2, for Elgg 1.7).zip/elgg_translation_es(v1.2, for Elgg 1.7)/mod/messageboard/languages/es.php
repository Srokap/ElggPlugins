<?php

// Generado por translationbrowser 

$spanish = array( 
	 'messageboard:board'  =>  "Tablón de anuncios" , 
	 'messageboard:messageboard'  =>  "tablón de anuncios" , 
	 'messageboard:viewall'  =>  "Ver todos" , 
	 'messageboard:postit'  =>  "Publicar" , 
	 'messageboard:history'  =>  "historia" , 
	 'messageboard:none'  =>  "No hay nada en este tablón de anuncios aún" , 
	 'messageboard:num_display'  =>  "Número de mensajes a mostrar" , 
	 'messageboard:desc'  =>  "Este es un tablón de anuncios que puedes poner en tu perfil y donde otros usuarios pueden dejar un comentario." , 
	 'messageboard:user'  =>  "tablón de anuncios de %s" , 
	 'messageboard:replyon'  =>  "responder a" , 
	 'messageboard:river:annotate'  =>  "%s tiene un comentario nuevo en su tablón de anuncios." , 
	 'messageboard:river:create'  =>  "%s ha añadido el widget de tablón de anuncios." , 
	 'messageboard:river:update'  =>  "%s ha actualizado su widget de tablón de anuncios." , 
	 'messageboard:river:added'  =>  "%s ha escrito un mensaje a" , 
	 'messageboard:river:messageboard'  =>  "tablón de anuncios" , 
	 'messageboard:posted'  =>  "El comentario ha sido publicado con éxito en el tablón de anuncios." , 
	 'messageboard:deleted'  =>  "El comentario ha sido borrado." , 
	 'messageboard:email:subject'  =>  "¡Tienes un mensaje nuevo en el tablón de anuncios!" , 
	 'messageboard:email:body'  =>  "%s te ha dejado el siguiente comentario:

			
%s


Para ver los comentarios en tu tablón de anuncios, haz click en el siguiente link:

	%s

Para consultar el perfil  de %s, haz click en este link:

	%s

No respondas a este email." , 
	 'messageboard:blank'  =>  "Necesitas poner algo en el área de mensaje antes de enviarlo." , 
	 'messageboard:notfound'  =>  "Lo siento; no se encontró el elemento especificado." , 
	 'messageboard:notdeleted'  =>  "Lo siente; el mensaje no ha podido ser borrado." , 
	 'messageboard:somethingwentwrong'  =>  "Algo extraño a sucedido. Inténtalo de nuevo o ponte en contacto con el administrador." , 
	 'messageboard:failure'  =>  "Fallo inesperado al añadir tu mensaje. Por favor, inténtalo de nuevo." , 
	 'messageboard:history:title'  =>  "Historia"
); 

add_translation('es', $spanish); 

?>