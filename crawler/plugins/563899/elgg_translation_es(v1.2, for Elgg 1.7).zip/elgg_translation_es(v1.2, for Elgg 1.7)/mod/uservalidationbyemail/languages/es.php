<?php
	/**
	 * Email user validation plugin language pack.
	 * 
	 * @package ElggUserValidationByEmail
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	$spanish = array(
	
		'email:validate:subject' => "%s confirma tu dirección de correo!",
		'email:validate:body' => "Hola %s,

Por favor confirme su dirección de correo electrónico haciendo clic en el siguiente enlace:

%s

Sino quieres seguir con la inscripción, simplemente, olvida este email.
",
		'email:validate:success:subject' => "Tu cuenta ha sido registrada %s",
		'email:validate:success:body' => "Enhorabuena! %s,
			
Felicidades, tu cuenta ha sido validada correctamente
",
	
		
		'email:confirm:success' => "La cuenta de correo es válida!. Ya puedes comenzar a utilizar la red social. Lo primero, meter tu Usuari@/Password en el panel de abajo",
		'email:confirm:fail' => "Ops!, por alguna razón tu cuenta de correo no puede ser verificada. Intentalo de nuevo, prueba con otra cuenta de correo que tengas, o ponte en contacto con el administrador...",
	
		'uservalidationbyemail:registerok' => "Para activar la cuenta, debes confirmar la suscripción a la red haciendo -click- en un enlace que el sistema te acaba de enviar. Si algo falla, intentalo de nuevo o ponte en contacto con el administrador "
	
	);
					
	add_translation("es",$spanish);
?>
