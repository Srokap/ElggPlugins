<?php

	$spanish = array(
	
			'custom:bookmarks' => "Últimos favoritos",
			'custom:groups' => "Últimos grupos",
			'custom:files' => "Últimos ficheros subidos",
			'custom:blogs' => "Últimas entradas",
			'custom:members' => "Nuevos miembros de la red",
			'custom:nofiles' => "No existen ficheros todavia",
			'custom:nogroups' => "No existen grupos todavia",	
	
	);
					
	add_translation("es",$spanish);

?>
