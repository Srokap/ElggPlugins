<?php

   /**
    * Rise Software Inc. - Groups spotlight
    * 
    * The spotlight area that displays on the Groups page
    * 
    * @package Rise_Spotlight
    * @author Jayson Smith
    * @copyright Rise Software Inc. 2009-2010
    * @link http://www.risesoftware.com
    * 
    */
?>

<div id="spotlight_table">
  
   <!-- spotlight LHS content -->
   <div class="spotlightLHS">
      <?php 
         echo "<h2>" . elgg_echo('spotlight:groups:lhs:title') . "</h2>";
         echo "<ul>" . elgg_echo('spotlight:groups:lhs:description'). "</ul>"; 
      ?>
   </div>
   
   <!-- spotlight RHS content -->
   <div class="spotlightRHS">
      <?php 
         echo "<h2>" . elgg_echo('spotlight:groups:rhs:title') . "</h2>";
         echo "<ul>" . elgg_echo('spotlight:groups:rhs:description'). "</ul>";
      ?> 
   </div>
   <div class="clearfloat"></div>
</div>

