<?php

   /**
    * Rise Software Inc. - Pages spotlight
    * The spotlight area that displays on the Pages page
    * 
    * @package Rise_Spotlight
    * 
    * @author I_Arttist
    * @copyright Rise Software Inc. 2009-2010
    * 
    * @link http://www.risesoftware.com
    * 
    */
?>

<div id="spotlight_table">
  
   <!-- spotlight LHS content -->
   <div class="spotlightLHS">
      <?php 
         echo "<h2>" . elgg_echo('spotlight:pages:lhs:title') . "</h2>";
         echo "<ul>" . elgg_echo('spotlight:pages:lhs:description'). "</ul>"; 
      ?>
   </div>
   
   <!-- spotlight RHS content -->
   <div class="spotlightRHS">
      <?php 
         echo "<h2>" . elgg_echo('spotlight:pages:rhs:title') . "</h2>";
         echo "<ul>" . elgg_echo('spotlight:pages:rhs:description'). "</ul>";
      ?> 
   </div>
   <div class="clearfloat"></div>
</div>

