<?php
   /**
    * Rise Software - File spotlight
    * 
    * The spotlight area that displays on the File page
    * 
    * @package Rise_Spotlight
    * @author Jayson Smith
    * @copyright Rise Software Inc. 2009-2010
    * @link http://www.risesoftware.com
    */
?>

<div id="spotlight_table">
  
   <!-- spotlight LHS content -->
   <div class="spotlightLHS">
      <?php 
         echo "<h2>" . elgg_echo('spotlight:file:lhs:title') . "</h2>";
         echo "<ul>" . elgg_echo('spotlight:file:lhs:description'). "</ul>"; 
      ?>
   </div>
   
   <!-- spotlight RHS content -->
   <div class="spotlightRHS">
      <?php 
         echo "<h2>" . elgg_echo('spotlight:file:rhs:title') . "</h2>";
         echo "<ul>" . elgg_echo('spotlight:file:rhs:description'). "</ul>";
      ?> 
   </div>
   <div class="clearfloat"></div>
</div>

