<?php
   /**
    * Rise Software Inc. - External Pages spotlight
    * 
    * The spotlight area that displays on the External Pages page
    * 
    * @package Rise_Spotlight
    * @author Jayson Smith
    * @copyright Rise Software Inc. 2009-2010
    * @link http://www.risesoftware.com
    * 
    */
?>

<div id="spotlight_table">
  
   <!-- spotlight LHS content -->
   <div class="spotlightLHS">
      <?php 
         echo "<h2>" . elgg_echo('spotlight:xpages:lhs:title') . "</h2>";
         echo "<ul>" . elgg_echo('spotlight:xpages:lhs:description'). "</ul>"; 
      ?>
   </div>
   
   <!-- spotlight RHS content -->
   <div class="spotlightRHS">
      <?php 
         echo "<h2>" . elgg_echo('spotlight:xpages:rhs:title') . "</h2>";
         echo "<ul>" . elgg_echo('spotlight:xpages:rhs:description'). "</ul>";
      ?> 
   </div>
   <div class="clearfloat"></div>
</div>

