<?php

   /**
    * Rise Software Inc - Blog spotlight
    * The spotlight area that displays on a blog page
    * 
    * @package Rise_Spotlight

    * @author I_Artist
    * @copyright Rise Software Inc. 2009-2010

    * @link http://www.risesoftware.com
    * 
    */
?>

<div id="spotlight_table">
  
   <!-- spotlight LHS content -->
   <div class="spotlightLHS">
      <?php 
         echo "<h2>" . elgg_echo('spotlight:blog:lhs:title') . "</h2>";
         echo "<ul>" . elgg_echo('spotlight:blog:lhs:description'). "</ul>"; 
      ?>
   </div>
   
   <!-- spotlight RHS content -->
   <div class="spotlightRHS">
      <?php 
         echo "<h2>" . elgg_echo('spotlight:blog:rhs:title') . "</h2>";
         echo "<ul>" . elgg_echo('spotlight:blog:rhs:description'). "</ul>";
      ?> 
   </div>
   <div class="clearfloat"></div>
</div>

