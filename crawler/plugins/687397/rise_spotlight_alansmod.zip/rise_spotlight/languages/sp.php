<?php
	/**
	 * Rise Software - Spotlight plugin language pack
	 * 
	 * @package RiseReviewGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Rise Software Inc.
	 * @copyright Rise Software Inc. 2009
	 * @link http://www.risesoftware.com/
	 */

	$english = array(


   'spotlight:title' => 'Help Desk',

   /*
    * Dashboard
    */
   'spotlight:dashboard:lhs:title' => 'Salpicadero',
   'spotlight:dashboard:lhs:description' => "Su tablero de instrumentos es su p�gina principal donde usted ver� what' s que se enciende en ManFling. La p�gina que usted ve aqu� es lo que llamamos el r�o. Esto le demuestra todo que est� sucediendo en el sitio. Preste la especial atenci�n a los mensajes del administrador, etiquetado el sitio Admin, como �stos son actualizaciones cr�ticas dadas sobre las herramientas y su estado en el sitio.",
   
   'spotlight:dashboard:rhs:title' => '&nbsp;',
   'spotlight:dashboard:rhs:description' => "&nbsp;",   
	
   /*
    * Blog
    */
   'spotlight:blog:lhs:title' => 'Blog',
   'spotlight:blog:lhs:description' => "
      <li>Un blog normal de la tela.</li>
      <li>�Los miembros pueden crear sus propios blogs para libre!</li>",
   
   'spotlight:blog:rhs:title' => 'Help',
   'spotlight:blog:rhs:description' => "
      <li>You can subscribe to a member's blog RRS feed to be notified of changes</li>
      <li>You can bookmark a blog to gain easy access to it</li>",
	  
	/*
	* Messageboard
	*/
	'spotlight:messageboard:lhs:title' => 'Messageboard',
	'spotlight:messageboard:lhs:description' =>"<b>ONLY post here if you're having issues with the site.</b>",
	
	'spotlight:messageboard:rhs:title' => 'Stuff',
	'spotlight:messageboard:rhs:description' => "Das right.",

   
   /*
    * Pages
    */
   'spotlight:pages:rhs:title' => 'Help',
   'spotlight:pages:rhs:description' => "
      <li>You can subscribe to a Pages' RRS feed to be notified of changes</li>
      <li>You can bookmark a Page to gain easy access to it</li>",

	'spotlight:pages:lhs:title' => 'Pages',
   'spotlight:pages:lhs:description' => "
      <li>Pages are blank sheets that you can turn into whatever you want.</li>
      <li>Pages can be public, or shown only to logged on users, your friends, groups </li>
      <li>You can even allow people to write on your Pages.</li>,",
      
	/*
	 * Friends
	 */
   'spotlight:friends:lhs:title' => 'Friends',
   'spotlight:friends:lhs:description' => "
      <li>Here are your friends.</li>
      <li>You can give special permissions to your friends, such as letting them view personal information</li>
      <li>You can see your friends and invite folks.</li>
      <li>You can also see who considers you a friend.</li>
      <li>Don't be a stranger!</li>",
      
   'spotlight:friends:rhs:title' => 'Help',
   'spotlight:friends:rhs:description' => "
      <li>Hovering over a person's photo will show you a menu where you can add them as a friend.</li>
      <li>Or click on a person to go to their profile and add them.</li>
      <li>Being friends isn't mutual so Joe can be your friend but you may not be his!</li>",

	/*
	 * Groups
	 */
   'spotlight:groups:rhs:title' => 'Help',
   'spotlight:groups:rhs:description' => "   <li>To create your Group:</li>
      <ul>
         <li>Give it a name and description.  These will be seen throughout the site.</li>
         <li>Decide if you have a public (open) or private (closed) group with Membership Permissions.</li>
         <li>Enable or disable the features that you want in your group.</li>
         </ul>",

	'spotlight:groups:lhs:title' => 'Groups',
   'spotlight:groups:lhs:description' => "    <li>A Group brings together people around a certain topic.<li>
      <li>Use this area to discuss anything related to the group topic.<li>
      <li>Say hi and please feel free to contribute. You CAN create your own groups.</li>
	  </ul>",

   /*
	 * Bookmarks
	 */
   'spotlight:bookmarks:lhs:title' => 'Bookmarks',
   'spotlight:bookmarks:lhs:description' => "
      <li>Here are your favorite links and pages on Rise.<li>
      <li>You can also add bookmarks to webpages on other sites.<li>
      <li>Add as many as you like.</li>
      <li>You can share your bookmarks also view your friends bookmarks!</li>
      <li>There can be many uses for this feature...</li>",
	
   'spotlight:bookmarks:rhs:title' => 'Help',
   'spotlight:bookmarks:rhs:description' => "
      <li>To add sites to this page, click the <i>Bookmark This</i> link in the top left of the site. </li>
      <li>To remove bookmarks, select <i>View Bookmark</i> and then select <i>Delete</i>.</li>
      <li>Use the <i>Get Bookmarklet</i> to easily bookmark any website you visit!</li>",

   /*
    *  Files
	* technically, this is the files section, but i have replaced the languaging with vids related terms
	*/
   'spotlight:file:lhs:title' => 'Videos',
   'spotlight:file:lhs:description' => "
      <li>Upload your videos here.<li>
      <li>Use this area to upload videos of yourself and/or you and your fuckbuddy that you'd like to show off!</li>
      <li>You can also view your friends videos!</li>",

   'spotlight:file:rhs:title' => 'Help',
   'spotlight:file:rhs:description' => "
      <li>Use the <i>". elgg_echo('file:upload') ."</i> link and fill out the requested fields!</li>
      <li>Please no viruses or anything malicious!</li>",

   
  /*
    *  Messages
    */
   'spotlight:messages:lhs:title' => 'Messages',
   'spotlight:messages:lhs:description' => "
      <li>This is your inbox, sent mail and friend requests area. It operates like most other inboxes you already know about.<p>;)</p></li>",

   'spotlight:messages:rhs:title' => '&nbsp;',
   'spotlight:messages:rhs:description' => "&nbsp;",

   
	/*
    * Profile
    */
   'spotlight:profile:lhs:title' => 'Profile',
   'spotlight:profile:lhs:description' => "
      <li>It's all about you!<li>
      <li>This is your public profile, tell everyone about yourself. Show us that cute mug of yours.</li>
	  <li>(And don't forget the cock and bod pics.)</li>
      <li>Please configure the layout and widgets to your liking.</li>",
      
   'spotlight:profile:rhs:title' => 'Help',
   'spotlight:profile:rhs:description' => "
      <li>You can change your profile information with the <i>Edit profile</i> link</li>
         <ul>
            <li>Fill in the <i>About me</i> section</li>
            <li>You can set your privacy settings for each field</li>
         </ul>
      <li>You can change your layout to however you'd like through the <i>Edit page</i> link</li>
         <ul>
            <li>Hover your mouse over the blue information icons to see the description of the widget</li>
            <li>Drag and drop widgets from the Widget Gallery to your Profile Page by clicking on the '4 arrows' icon.</li>
            <li>Don't forget to click <i>Save</i> when you are done.</li>
        </ul>
     <li>Once back on your Profile Page adjust the settings of your widgets by clicking on their <i>Edit</i> button</li>",
   

   
   /*
    * Settings
    */
   'spotlight:settings:lhs:title' => 'Settings',
   'spotlight:settings:lhs:description' => "
      <li>Here you can configure your personal settings and see your statistics for the site.</li>
      <li>You must configure your Notification settings if you want to be notified of changes on the site</li>
      <li>You may also receive notifications when your friends create content on the site</li>
	  <b><li>For some reason, if you change your username in <i>Settings</i>, it only changes your display name. It doesn't change your actual username, so you will still have to login with the old username.</li></b>",
      
   'spotlight:settings:rhs:title' => 'Help',
   'spotlight:settings:rhs:description' => "
      <li>Click on to <i>" . elgg_echo('usersettings:user:opt:linktext') . "</i> to change your password.</li>
      <li>Your notifications can be sent to two destinations:</li>
         <ul>
            <li>Email: notifications are sent to the email you registered.</li>
            <li>Site: notifications are sent to your account on the site.</li>
        </ul>
     <li>Don't forget to click on the <i>Save</i> button at the bottom of the page.</li>",
   
	/*
	 * externalpages
	 */
   'spotlight:externalpages:lhs:title' => 'Welcome to the' . elgg_echo('spotlight:title') . '!',
   'spotlight:externalpages:lhs:description' => "If you are lost, the spotlight can guide you.  
    Here you will find information about where you are in the site, what you can do, where to go, and so on. 
    You can also close the Spotlight by clicking on the 'minus' sign on the right side of Spotlight title bar.",
   
	'spotlight:externalpages:rhs:title' => 'Home page Help',
   'spotlight:externalpages:rhs:description' => "
	<li>Once logged in you will see more options in the upper black bar under the Tools menu</li>
	  </ul>
	</li>",
	
	/*
	* Members
	*/
	'spotlight:members:lhs:title' => 'Members',
	'spotlight:members:lhs:description' => "&nbsp;",
	'spotlight:members:rhs:title' => '&nbsp;',
	'spotlight:members:rhs:description' => "&nbsp;",
	
	/*
	* FAQ
	*/
	'spotlight:faq:lhs:title' => 'FAQ',
	'spotlight:faq:lhs:description' => "&nbsp;",
	'spotlight:faq:rhs:title' => '&nbsp;',
	'spotlight:faq:rhs:description' => "&nbsp;",	
	
	/*
	* The Wire
	*/
	'spotlight:thewire:lhs:title' => 'The Wire',
	'spotlight:thewire:lhs:description' => "&nbsp;",
	'spotlight:thewire:rhs:title' => '&nbsp;',
	'spotlight:thewire:rhs:description' => "&nbsp;",
	
	/*
	 * Photos
	 */
	 'spotlight:photos:rhs:title' => '&nbsp;',
	 'spotlight:photos:rhs:description' => "&nbsp;",
	 'spotlight:photos:lhs:title' => 'Photos Help & Suggestions',
	 'spotlight:photos:lhs:description' => "It's pretty self-explanatory. The upload link lets you upload. The albums link lets you view albums. And, of course, there is the <i>all</i> link. All of this is in the left-hand column.
	 <p><p>Know that when you upload photos, you can set them to totally <i>private</i>, <i>only friends</i>, or <i>logged in users</i>. I caution against using the <i>public</i> setting, though, as then its all visible to anyone who happens by on the web. At minimum, you're safer using the <i>logged in users</i> setting.
	 <p>Enjoy!",

  /*
	* Custom Index (main)
	*/   
   'spotlight:xpages:lhs:title' => 'Welcome to ManFling.net!',
	'spotlight:xpages:lhs:description' => "Our site may be a little different than what you are accustomed to.  The guides that you find in the Spotlight areas will assist you while you are learning the ropes.  
    Here you will find information about where you are on the site, what you can do, where to go, and so on.  The left side will contain a description of the section you are in
    while the right side will contain help on how to use the section. 
    Once you feel comfortable on the site you can minimize the Help Desk by clicking on the 'minus' sign on the right side of the Help Desk title bar.",
   
   'spotlight:xpages:rhs:title' => "Home page help",
   'spotlight:xpages:rhs:description' => "&nbsp;",
   
     /*
	* Custom Index (main)
	*/  
	/* removed 
   'spotlight:custom_index:lhs:title' => 'Welcome to the Help Desk !',
	'spotlight:custom_index:lhs:description' => "Our site may be a little different than what you are accustomed to.  The guides that you find in the Spotlight areas will assist you while you are learning the ropes.  
    Here you will find information about where you are on the site, what you can do, where to go, and so on.  The left side will contain a description of the section you are in
    while the right side will contain help on how to use the section. 
    Once you feel comfortable on the site you can minimize the Help Desk by clicking on the 'minus' sign on the right side Help Desk title bar.",
   
   'spotlight:custom_index:rhs:title' => "Home page help",
   'spotlight:custom_index:rhs:description' => "&nbsp;",
   */
   
        /*
	* Index
	*/   
   'spotlight:index:lhs:title' => 'Guess ...',
	'spotlight:index:lhs:description' => "Our site may be a little different than what you are accustomed to.  But not to worry! The guides that you find in the Spotlight areas at the bottom of each page can assist you while you are learning the ropes.  
    Here you will find information about where you are on the site, what you can do, where to go, and so on.  The left side will contain a description of the section you are in
    while the right side will contain help on how to use the section. 
    Once you feel comfortable on the site you can minimize the Help Desk by clicking on the 'minus' sign on the right side Help Desk title bar.<p>
	<b>And don't forget: if you need help, it could be either answered in the ". elgg_echo('faq') .", or a great question to ask, so that we can add it there!</b>",
   
   'spotlight:index:rhs:title' => "&nbsp;",
   'spotlight:index:rhs:description' => "&nbsp;",
   
	
	);
					
	add_translation("en",$english);
?>
