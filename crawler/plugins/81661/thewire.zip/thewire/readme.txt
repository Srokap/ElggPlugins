/**
	 * Elgg the wire
	 * 
	 * @package ElggTheWire
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider <info@elgg.com>
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
*/

This is a twitter style, short message service that allows users to post notes to the wire.

Install: Just drop it into the mod directory and that should be it.