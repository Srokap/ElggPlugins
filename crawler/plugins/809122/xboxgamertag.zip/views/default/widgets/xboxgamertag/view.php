<?php

$xbox_gamertag = $vars['entity']->gamertag;
$style = $vars['entity']->style;

if($xbox_gamertag) {
 
?>
	<!-- Show the image if the gamertag is inserted in options -->
	<div style="text-align:center;">
		<a href="http://live.xbox.com/es-ES/MyXbox/Profile?gamertag=<?php echo $xbox_gamertag;?>" title="Visit <?php echo $xbox_gamertag;?>'s profile on Xbox Live">
			<img src="http://card.josh-m.com/live/<?php echo $style;?>/<?php echo $xbox_gamertag;?>.png" style="max-width:100%;" />
		</a>
	</div>
 
<?php
 
    } else {
        echo elgg_echo('xboxgamertag:no_gamertag');
    }

?>