<?php

/**************************************************

Author: Randy Brito
http://randybrito.com
Donations: donate@randybrito.com

***************************************************/

function xboxgamertag_init() {
    
//add a widget
add_widget_type('xboxgamertag',elgg_echo("xboxgamertag:title"),elgg_echo("xboxgamertag:description"));
        
}

register_elgg_event_handler('init','system','xboxgamertag_init');

?>
