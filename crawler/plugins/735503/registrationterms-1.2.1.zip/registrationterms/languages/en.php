<?php

add_translation("en", array(
	'registrationterms:agree' => 'I have read and agree to the <a href="%s">Terms of Service</a>',
	'registrationterms:required' => "You must first agree to the terms",
));