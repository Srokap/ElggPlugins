# Registration Terms for Elgg 1.8 #

This is a simple little plugin that adds a checkbox to your registration form
and forces users to check it before they can proceed.

## Customization ##

If you'd like to customize the wording or translate it into other languages,
just override the language strings in languages/en.php