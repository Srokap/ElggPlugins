<?php
  // Load Elgg engine
  require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

// make sure only logged in users can see this page	
    gatekeeper();
    
  global $CONFIG;
    
  if (!class_exists('SimplePie'))
  {
    require_once $CONFIG->pluginspath . '/simplepie/simplepie.inc';
  }
  
  $blog_tags = '<a><p><br><b><i><em><del><pre><strong><ul><ol><li>';
  $feedobject = get_entity($_GET["id"]);
  $feed_url = $feedobject->description;
  $feed_guid = $feedobject->getGUID();
  $container_guid = $feedobject->container_guid;
  //Get last feed item for duplicate feed check
  //$allfeeds = get_entities("object","groupfeed",$feedobject->owner_guid,"guid desc",1000,0,true,0,$container_guid,0,0); 
  //$lastfeeditemarray = get_entities_from_metadata("feed",$feed_guid,"object","feeditem",$feedobject->container_guid,1,0,"guid desc",0,false); 
  $lastfeeditemarray = get_entities_from_metadata("feed",$feed_guid,"object","blog",$feedobject->container_guid,1,0,"guid desc",0,false); 
  //$allfeeditems = get_entities("object","feeditem",$feedobject->owner_guid,"guid desc",100,0,false,0,$container_guid,0,0);		
  $lastguid = 0;
  if ($lastfeeditemarray) {
  foreach ($lastfeeditemarray as $feeditemdetails){
    $lastfeeditem = $feeditemdetails;
  	  break;
  }
  $lastguid = $lastfeeditem->getGUID();
  }
  //$test = " ";
  //if ($allfeeditems){
  //foreach ($allfeeditems as $feeditemdetails){
  //  $test .= $feeditemdetails->getGUID() . " ";
  //  if ($feeditemdetails->feed = $feedobject->getGUID()){
  //     $lastguid = $feeditemdetails->getGUID();
  //     break;
  //  }
  //  }
  //  }
  //if ($lastguid > 0) {
  //$lastfeeditem = get_entity($lastguid);
  //}
  //Start of create new feed items
  if($feed_url){

    $excerpt   = 1;
    $num_items = 10;
    $post_date = 1;
     
    $cache_loc = $CONFIG->pluginspath . '/simplepie/cache';
    
    $feed = new SimplePie($feed_url, $cache_loc);
    
    // doubles timeout if going through a proxy
    //$feed->set_timeout(20);
    
    $num_posts_in_feed = $feed->get_item_quantity();
    
    // only display errors to profile owner
    //if (get_loggedin_userid() == page_owner())
    //{        
      if (!$num_posts_in_feed)
        register_error('simplepie:notfind');
    //}

  if ($num_items > $num_posts_in_feed){
    $num_items = $num_posts_in_feed;
}
//Get New Items only
$count = 0;
$new_items = $num_items;
$test2 = " ";
if ($lastfeeditem) {
foreach ($feed->get_items(0,$num_items) as $item){
	$test2 .= $lastfeeditem->permalink . " " . $item->get_permalink(). " + ";
	if ($lastfeeditem->permalink == $item->get_permalink()){
		$new_items = $count;
		break;
	}
	$count = $count + 1;
}
}
//$real_new_items = $new_items;
//$new_items = 1;
if ($new_items > 0) {
$newfeeditems = array_reverse($feed->get_items(0,$new_items));
  foreach ($newfeeditems as $item){
	      // create a new feed item
   $feeditem = new ElggObject();
   $feeditem->title = $item->get_title();
   $feeditem->description = strip_tags($item->get_description(true),$blog_tags);
   $feeditem->permalink = $item->get_permalink();
   $feeditem->owner_guid = $feedobject->owner_guid;
   //$feeditem->subtype = "feeditem";
   $feeditem->subtype = "blog";
   $feeditem->access_id = ACCESS_PUBLIC;
   $feeditem->container_guid = $container_guid;
   $feeditem->content_owner = $container_guid;
   $feeditem->post_date = $item->get_date('j F Y | g:i a');
   $feeditem->feed = $feedobject->getGUID();
   $feeditem->feedtype = true;
   //$feeditem->lastfeeditem = $lastguid;
   //$feeditem->newitems = $new_items;
   //$feeditem->testing2 = $test2;
   $feeditem->save();
   //add_to_river('river/object/blog/create','create',$feeditem->container_guid,$feeditem->getGUID());
   }
}
	$container_entity = get_entity($container_guid);
//forward($CONFIG->wwwroot . "mod/simplepiegroupplugin/allfeeditems.php?username=" . $container_entity->username);
forward($CONFIG->wwwroot . "mod/simplepiegroupplugin/allfeeditems?id=" . $feed_guid ."&username=group:". $container_guid);

  } else {    
        register_error('simplepie:notfind');
        //forward($CONFIG->wwwroot . "mod/simplepiegroupplugin/allfeeditems.php");
        
  }
?>
