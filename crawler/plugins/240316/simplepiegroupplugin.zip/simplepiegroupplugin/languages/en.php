<?php
	$english = array(
    'simplepiegroupplugin:addgroupfeed' => "Add Group Feed",
    );
	add_translation("en",$english);
?>