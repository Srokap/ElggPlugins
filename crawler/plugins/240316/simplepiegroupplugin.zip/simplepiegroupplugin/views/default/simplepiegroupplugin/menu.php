
<p class="user_menu_file" ><a href="<?php echo $vars['url']?>mod/simplepiegroupplugin/addfeed.php">Add Group Feed</p>