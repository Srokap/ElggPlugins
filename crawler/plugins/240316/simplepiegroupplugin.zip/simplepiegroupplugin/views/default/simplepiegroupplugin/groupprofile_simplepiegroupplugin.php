<?php
#Attemot 1
#echo 'HELLLO';
#echo '<div id="group_pages_widget">';
#echo '<h2>'.elgg_echo("simplepiegroupplugin:groupprofile").'</h2>';
#echo '<div class="forum_latest"><a>Hello World</a></div>';
#echo '</div>';
#Attempt 2
#    $page_owner = page_owner_entity();
#    $user_guid = $page_owner->getGUID();
#    $feedview = list_user_objects($user_guid,'groupfeed',10,false);
#
#    $feedview = elgg_view_layout('one_column', $feedview);
#     
#    page_draw("List of feeds",$feedview);

?>