<!--<div class="contentWrapper"></div> -->
<!--<p><?php echo elgg_view_entity($_GET["id"], 'user/user'); ?></p>-->
<!--, array('entity' => $_GET["id"], 'size' => 'small')) -->
<!--<?php echo elgg_view("profile/icon") ?> -->
<a><?php echo $_GET["id"] ?> </a>
