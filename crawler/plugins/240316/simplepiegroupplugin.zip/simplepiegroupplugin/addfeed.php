<?php

  // Load Elgg engine
  require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

// make sure only logged in users can see this page	
    gatekeeper();

  

    // set the title
    //$groupinfoid = get_entity ($_GET["id"]);
    $title = "Add a new group feed";
    
    //$area1 = "<a href=\"". $CONFIG->wwwroot ."pg/groups/". $_GET["id"] . "/my-group/\">Back to Group Page</a>";
    //$area1 = elgg_view("simplepiegroupplugin/left_sidebar");
    //$area1 .= elgg_view_entity($_GET["id"], 'user/user');
    //$area2 = elgg_view("profile/icon",array('entity' => $user, 'size' => 'small'))
 
    // start building the main column of the page
    $area2 = elgg_view_title($title);
 
    // Add the form to this section
    $area2 .= elgg_view("simplepiegroupplugin/form");
 
    // layout the page
    $body = elgg_view_layout('two_column_left_sidebar', $area1, $area2);
 
    // draw the page
    page_draw($title, $body);
?>