<?php

  // Load Elgg engine
  require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

// make sure only logged in users can see this page	
    gatekeeper();
    if (page_owner_entity()) {
    $page_owner = page_owner_entity();
    $user_guid = $page_owner->getGUID();
    $title = "List of all feeds for ". $page_owner->name;
    $area2 = elgg_view_title($title);
    $area2 .= list_user_objects($user_guid,'groupfeed',10,false);
    } else {
	$title = "List of all feeds";
    $area2 = elgg_view_title($title);
	$area2 .= list_entities('object','groupfeed',0,10,false);
    }
    #$area2 = elgg_view("groups/icon", array('entity' => $vars['entity'], 'align' => "left", 'size' => $iconsize, ) ); 
    #$groupinfoid = get_entities("group",,,,,,,, $user_guid);
    #$area1 = "<a href=\"". $CONFIG->wwwroot ."pg/groups/". $user_guid . "/my-group/\">Back to Group Page</a>";

    $body = elgg_view_layout('two_column_left_sidebar', $area1, $area2);
     
    page_draw("List of feeds",$body);
?>