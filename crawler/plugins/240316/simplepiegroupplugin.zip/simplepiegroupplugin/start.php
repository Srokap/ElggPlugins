

<?php    
    #Uncomment to add to user profile
	#extend_view('profile/menu/actions', 'simplepiegroupplugin/menu');
	#Below doesn't work attempt to add group menu items to my group pages
	#extend_view('groups/left_column','simplepiegroupplugin/form');
	#extend_view('groups/rightcolumn','simplepiegroupplugin/groupprofile_files');
    
    
    function simplepiegroupplugin_submenus() {
	global $CONFIG;
	$page_owner = page_owner_entity();
	if ($page_owner instanceof ElggGroup && get_context() == "groups") {
    # TODO Get Translation to work
	#add_submenu_item(elgg_echo('simplepiegroupplugin:addgroupfeed'), $CONFIG->wwwroot . "mod/simplepiegroupplugin/addfeed.php");
	add_submenu_item(elgg_echo('Add RSS Feed'), $CONFIG->wwwroot . "mod/simplepiegroupplugin/addfeed.php?username=group:". $page_owner->getGUID());
	add_submenu_item(elgg_echo('View Feeds'), $CONFIG->wwwroot . "mod/simplepiegroupplugin/allfeeds.php?username=group:". $page_owner->getGUID());
	//add_submenu_item(elgg_echo('View Feed Items'), $CONFIG->wwwroot . "mod/simplepiegroupplugin/allfeeditems.php?username=group:". $page_owner->getGUID());
    }
    }
    //function simplepiegroupplugin_init() {
	//global $CONFIG;
	//if (isloggedin()) {
    //add_menu(elgg_echo('RSS Import'), $CONFIG->wwwroot . "mod/simplepiegroupplugin/allfeeds.php?username=" . $_SESSION['user']->username);
    //}
    //}
    #TODO create init function
	//register_elgg_event_handler('init','system','simplepiegroupplugin_init');
	
	#TODO Register a page handler, so we can have nice URLs
	#register_page_handler('simplepiegroupplugin','simplepiegroupplugin_page_handler');
	
	register_elgg_event_handler('pagesetup','system','simplepiegroupplugin_submenus');
	
	
	register_action("simplepiegroupplugin/save", false, $CONFIG->pluginspath . "simplepiegroupplugin/actions/save.php");
	#if generate feeds is an action and in action folder use code below
	#register_action("simplepiegroupplugin/generatefeeditems", false, $CONFIG->pluginspath . "simplepiegroupplugin/actions/generatefeeditems.php");
	
	?>