<?php
	require_once dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php";
	
	global $CONFIG;
	
	$query = "UPDATE {$CONFIG->dbprefix}private_settings set value='latest_photos' WHERE name='handler' AND value='latest'";
	
	$ret = update_data($query);
	if ($ret === true)
	{
		$num_widgets = mysql_affected_rows();
		
		system_message("Updated $num_widgets widgets");
	}
	else
	{
		register_error("Unable to perform update");
	}

	forward($_SERVER["HTTP_REFERER"]);
?>