<?php

/**

This moves the widgets called latest to latest_photos for the Tidypics plugin

**/

?>