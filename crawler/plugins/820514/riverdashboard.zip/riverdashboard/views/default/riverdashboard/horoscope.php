<?php

	/**
	 * 3 Column River Dashboard
	 *
	 * @package ElggRiverDash
	 * Full Creadit goes to ELGG Core Team for creating a beautiful social networking script
	 *
	 * @author ColdTrick IT Solutions
	 * @copyright Coldtrick IT Solutions 2009
	 * @link http://www.coldtrick.com/
	 * @version 1.0
	 */


?>

<div class="sidebarBox">
<h3><?php echo elgg_echo('riverdashboard:horoscope') ?></h3>
<div class="membersWrapper" align="justify">
<marquee direction="left" scrollamount="2" onmouseover="stop()" onmouseout="start()" style="overflow:hidden;"><iframe src="http://www.eastrolog.com/webmaster-new/daily-horoscope/webmaster-horoscope-1.php" name="Daily_Horoscopes_720x85" width="720" height="85" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" title="Daily Horoscopes 720x85"></iframe></marquee>
<div class="clearfloat"></div>
</div>
</div>
