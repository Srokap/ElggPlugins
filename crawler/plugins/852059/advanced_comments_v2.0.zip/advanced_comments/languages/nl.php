<?php
$language = array (
  'advanced_comments' => 'Geadvanceerde reacties',
  'advanced_comments:header:order' => 'Reactie volgorde',
  'advanced_comments:header:order:asc' => 'Oudste eerst',
  'advanced_comments:header:order:desc' => 'Nieuwste eerst',
  'advanced_comments:header:limit' => 'Aantal',
  'advanced_comments:header:auto_load' => 'Automatisch laden',
);
add_translation("nl", $language);