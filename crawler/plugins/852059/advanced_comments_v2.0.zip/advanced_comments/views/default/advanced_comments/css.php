<?php ?>
#advanced-comments-more {
	border: 1px solid #CCCCCC;
	color: #4690D6;
	text-align: center;
	font-weight: bold;
	height: 20px;
	padding: 10px;
}

#advanced-comments-more:hover {
	cursor: pointer;
	border-color: #B6B6B6;
}

#advanced-comments-more .elgg-ajax-loader {
	margin-top: -6px;
}

.advanced-comments-more-list {
	border-top: none;
}