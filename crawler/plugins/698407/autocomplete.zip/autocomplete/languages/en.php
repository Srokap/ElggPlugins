<?php

	$english = array(
	
		'autocomplete:adduser' => "Add more users",
		'autocomplete:removeuser' => "Remove user",
		
	);
					
	add_translation("en",$english);

?>