<?php
require_once(dirname(__FILE__) . "/models/model.php");

function autocomplete_init() {
	extend_view('css','autocomplete/css');
	extend_view('metatags','autocomplete/metatags');
}
register_elgg_event_handler('init','system','autocomplete_init');
?>