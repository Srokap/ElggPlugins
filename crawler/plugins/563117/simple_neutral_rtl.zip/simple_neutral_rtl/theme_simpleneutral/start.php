<?php

    /**
     * Simple Neutral theme
     **/
     
     /**
	 * Initialise the theme 
	 *
	 */
	function simpleneutral_init(){
	
    }
	
	// Initialise log browser
	register_elgg_event_handler('init','system','simpleneutral_init');
	
?>