<p>
<?php echo elgg_echo('Example'); ?>
	<a href="<?php echo $vars['url'] ?>mod/autocomplete/example.php">Example</a>
</p>