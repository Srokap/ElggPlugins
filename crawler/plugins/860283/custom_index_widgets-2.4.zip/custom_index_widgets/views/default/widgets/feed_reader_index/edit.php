<?php 
  include elgg_get_plugins_path() . 'simplepie/views/default/widgets/feed_reader/edit.php';	
  //echo elgg_view("simplepie/edit", $vars);
?>

