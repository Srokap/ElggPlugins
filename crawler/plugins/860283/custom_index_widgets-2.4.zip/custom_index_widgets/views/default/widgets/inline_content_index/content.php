<div class="contentWrapper">
    <?php
    echo $vars[entity]->html_content;
    ?>
    <div class="clearfloat">
    </div>
</div>
