<?php

	/* Elgg Theme Simple Example */
	
	
	/* Initialise the theme */
	function theme_eosx_init(){
	
	}
	
	// Initialise log browser
	register_elgg_event_handler('init','system','theme_eosx_init');
	
?>