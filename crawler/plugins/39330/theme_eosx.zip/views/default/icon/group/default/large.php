<?php
	echo $vars['url'] . "mod/theme_eosx/graphics/group_icons/defaultlarge.gif";
?>