<?php
	echo $vars['url'] . "mod/theme_eosx/graphics/group_icons/defaultmedium.gif";
?>