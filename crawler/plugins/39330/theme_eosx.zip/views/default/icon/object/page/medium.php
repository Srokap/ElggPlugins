<?php
	echo $vars['url'] . "mod/theme_eosx/graphics/file_icons/pages_lrg.gif";
?>