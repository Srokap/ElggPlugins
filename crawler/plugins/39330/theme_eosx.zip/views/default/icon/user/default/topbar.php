<?php
	echo $vars['url'] . "mod/theme_eosx/graphics/user_icons/defaulttopbar.gif";
?>