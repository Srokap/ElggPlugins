.editablecomments_form {
	display: none;
	padding: 15px 0;
}

a.editablecomments_toggle {
	cursor: pointer;
}

.elgg-river-item form.elgg-form-editablecomments-edit {
	height: auto;
}