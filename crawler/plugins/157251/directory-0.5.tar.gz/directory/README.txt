Directory Plugin
=================

This plugin provides the following features:
	- List of Users, Groups or Objects Sort by Alphabetic
	- Pagination for big lists
	- Functions acording elgg standard to give help another devs
	

Install
-------

Just drop it on your mod directory and then go to the admin panel and activate it. 

For see a default list of users go to http://yoursite.com/pg/directory


Info for Developers
-------------------
For show alphabetic list of users, groups or objects use list_entities_alpha() function and pass
the folowing parameters:

	* Type: possible values => user, group or object 
	* Subtype: For especific use
	* Letter: Filter for the first letter in name or title
	* Limit: Value for Paginate, 10 by default
	* Offset: Value for Paginate, 0 by default