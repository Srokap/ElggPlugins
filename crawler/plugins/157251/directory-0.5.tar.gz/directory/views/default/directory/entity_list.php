<?php
/**
  * View for listing of entities, sorten by Alphabetic
  *
  * @package ElggDirectory
  * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
  * @author Daniel Aristizabal Romero <daniel@somosmas.org>
  * @copyright Corporación Somos más - 2009
  * @link http://www.somosmas.org
  */

		$context = $vars['context'];
		$entities = $vars['entities'];
		$limit = $vars['limit'];
		$offset = $vars['offset'];
		$count = $vars['count'];
		$baseurl = $vars['baseurl'];
		$viewtype = $vars['viewtype']; // Se puede usar la vista Gallery?
		$fullview = $vars['fullview'];
		$directory = true;
		$pagination = $vars['pagination'];
		$letter = $vars['letter'];
		$letters = range('a', 'z');

		$html = "";
		$nav = "";



		/**
		 * Code Commented by not suport for Gallery View
		 */
		/*if (isset($vars['viewtypetoggle'])) {
			$viewtypetoggle = $vars['viewtypetoggle'];
		} else {
			$viewtypetoggle = true;
		}*/

			/*if ($context == "search" && $count > 0 && $viewtypetoggle) {
				$nav .= elgg_view("navigation/viewtype",array(

												'baseurl' => $baseurl,
												'offset' => $offset,
												'count' => $count,
												'viewtype' => $viewtype,

														));
			}*/

			if ($directory) {
				$html .= elgg_view('directory/directory',array(
    			'letter' => $letter,
				'baseurl' => $baseurl,
    			'letters' => $letters
				));
			}

			if ($pagination) {
			  $nav = elgg_view('directory/pagination', array(
			    'letter' => $letter,
			    'count' => $count,
			    'limit' => $limit,
			    'offset' => $offset
			    ));
			}
			//$html .= $nav;

			if ($viewtype == "list") {
				if (is_array($entities) && sizeof($entities) > 0) {
					foreach($entities as $entity) {
						$html .= elgg_view_entity($entity, $fullview);
					}
				}
			} else {
				if (is_array($entities) && sizeof($entities) > 0)
					$html .= elgg_view("search/gallery",array('entities' => $entities));
			}

			if ($count)
				$html .= $nav;

		    if (!$entities) {
		      $html .= "<h2>".elgg_echo('directory:noresults')."</h2>";
		    }
			echo $html;

?>