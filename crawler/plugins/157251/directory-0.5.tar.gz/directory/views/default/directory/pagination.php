<?php
/**
 * Elgg Directory List pagination
 *
 * @package ElggDirectory
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Daniel Aristizabal Romero <daniel@somosmas.org>
 * @copyright Corporación Somos más - 2009
 * @link http://www.somosmas.org
 */

if ((!isset($vars['limit'])) || (!$vars['limit'])) {
  $limit = 10;
} else {
  $limit = (int)$vars['limit'];
}

if (!isset($vars['offset'])) {
  $offset = 0;
} else {
  $offset = $vars['offset'];
}

if (!isset($vars['count'])) {
  $count = 0;
} else {
  $count = $vars['count'];
}

if (empty($vars['letter'])) {
  $letter = "";
} else {
  $letter = $vars['letter'];
}

?>
<!--  Begin Pagination Bar -->
<?php
	$totalpages = ceil($count / $limit);
	$currentpage = ceil($offset / $limit) + 1;
	$baseurl = $baseurl.'?letter='.$letter.'&limit=10';
	$word = 'offset';

	//only display if there is content to paginate through or if we already have an offset
	if (($count > $limit || $offset > 0) && get_context() != 'widget') {

?>

<div class="pagination">
<?php

	if ($offset > 0) {

		$prevoffset = $offset - $limit;
		if ($prevoffset < 0) $prevoffset = 0;

		$prevurl = $baseurl;
		if (substr_count($baseurl,'?')) {
			$prevurl .= "&{$word}=" . $prevoffset;
		} else {
			$prevurl .= "?{$word}=" . $prevoffset;
		}

		echo "<a href=\"{$prevurl}\" class=\"pagination_previous\">&laquo; ". elgg_echo("previous") ."</a> ";

	}

	if ($offset > 0 || $offset < ($count - $limit)) {

		$currentpage = round($offset / $limit) + 1;
		$allpages = ceil($count / $limit);

		$i = 1;
		$pagesarray = array();
		while ($i <= $allpages && $i <= 4) {
			$pagesarray[] = $i;
			$i++;
		}
		$i = $currentpage - 2;
		while ($i <= $allpages && $i <= ($currentpage + 2)) {
			if ($i > 0 && !in_array($i,$pagesarray))
				$pagesarray[] = $i;
			$i++;
		}
		$i = $allpages - 3;
		while ($i <= $allpages) {
			if ($i > 0 && !in_array($i,$pagesarray))
				$pagesarray[] = $i;
			$i++;
		}

		sort($pagesarray);

		$prev = 0;
		foreach($pagesarray as $i) {

			if (($i - $prev) > 1) {

				echo "<span class=\"pagination_more\">...</span>";

			}

			$counturl = $baseurl;
			$curoffset = (($i - 1) * $limit);
			if (substr_count($baseurl,'?')) {
				$counturl .= "&{$word}=" . $curoffset;
			} else {
				$counturl .= "?{$word}=" . $curoffset;
			}
			if ($curoffset != $offset) {
				echo " <a href=\"{$counturl}\" class=\"pagination_number\">{$i}</a> ";
			} else {
				echo "<span class=\"pagination_currentpage\"> {$i} </span>";
			}
			$prev = $i;

		}

	}

	if ($offset < ($count - $limit)) {

		$nextoffset = $offset + $limit;
		if ($nextoffset >= $count) $nextoffset--;

		$nexturl = $baseurl;
		if (substr_count($baseurl,'?')) {
			$nexturl .= "&{$word}=" . $nextoffset;
		} else {
			$nexturl .= "?{$word}=" . $nextoffset;
		}

		echo " <a href=\"{$nexturl}\" class=\"pagination_next\">" . elgg_echo("next") . " &raquo;</a>";

	}

?>
<div class="clearfloat"></div>
</div>
<?php
    } // end of pagination check if statement
?>
<!-- End Pagination Bar -->
