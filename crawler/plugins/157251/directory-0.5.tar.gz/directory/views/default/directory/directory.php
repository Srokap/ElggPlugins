<?php
/**
  * View for letters in a Directory Plugin
  *
  * @package ElggDirectory
  * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
  * @author Daniel Aristizabal Romero <daniel@somosmas.org>
  * @copyright Corporación Somos más - 2009
  * @link http://www.somosmas.org
  */

//Filter for letter
if(isset($vars['letter']) && !empty($vars['letter'])) {
  $filter = strtolower($vars['letter']);
}

if (isset($vars['letters']) && is_array($vars['letters'])) {
  $letters = $vars['letters'];
}

$baseurl = $vars['baseurl'];

?>
<div class="pagination"><?php

foreach($letters as $i) {
  $i = strtoupper($i);
  $counturl = $baseurl.'?letter='.$i.'&limit=10&offset=0';

  if (strtoupper($filter) != $i) {
    echo " <a href=\"{$counturl}\" class=\"pagination_number\">{$i}</a> ";
  } else {
    echo "<span class=\"pagination_currentpage\"> {$i} </span>";
  }
}

echo "<a href=\"{$baseurl}\" class=\"pagination_number\">".elgg_echo('directory:all')."</a>";

?>
<div class="clearfloat"></div>
</div>