<?php
/**
 * Elgg Directory plugin
 *
 * @package ElggDirectory
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Daniel Aristizabal Romero
 * @copyright Corporación Somos más - 2009
 * @link http://www.somosmas.org
 */

/**
 * Directory initialization
 */
function directory_init() {
    register_page_handler('directory', 'directory_page_handler');
}

/**
 * Page Handler for directory
 */
function directory_page_handler() {
  global $CONFIG;

  include($CONFIG->pluginspath . "directory/listing.php");
}

/**
 * Returns a viewable list of entities sort by Alphabetic
 *
 * @param string $type The type of entity (eg "user", "object" etc)
 * @param string $subtype The arbitrary subtype of the entity
 * @param string $letter The letter use to consult
 * @param int $limit Limit for results
 * @param int $offset Offset of results
 * @todo Implementar el uso de $limit y $offset
 * @return string A viewable list of entities
 */
function list_entities_alpha($type= "", $subtype = "", $letter = "", $limit = 10, $offset = 0) {

  if (empty($letter)) {
    $limit = 10;
    //forward('pg/directory?letter=&limit=10&offset=0');
  }

  if (is_string($letter)){
    // If the letter is a word
    $letters = str_split($letter);
    $letter = strtolower($letters[0]);
  } else {
    $letter = "";
  }

  $count = get_entities_alpha($type, $subtype, $owner_guid, $letter, $limit, $offset, true);
  $entities = get_entities_alpha($type, $subtype, $owner_guid, $letter, $limit, $offset);

  return elgg_view_alpha_entity_list($entities, $letter, $limit, $offset, $count);

}

/**
 * Return entities matching a given query, or the number thereof
 *
 * @param string $type The type of entity (eg "user", "object" etc)
 * @param string $subtype The arbitrary subtype of the entity
 * @param int $owner_guid The GUID of the owning user
 * @param string $letter The Letter filter
 * @param int $limit The number of entities to return; 10 by default
 * @param int $offset The indexing offset, 0 by default
 * @param boolean $count Set to true to get a count rather than the entities themselves (limits and offsets don't apply in this context). Defaults to false.
 * @param int $site_guid The site to get entities for. Leave as 0 (default) for the current site; -1 for all sites.
 * @param int|array $container_guid The container or containers to get entities from (default: all containers).
 * @param int $timelower The earliest time the entity can have been created. Default: all
 * @param int $timeupper The latest time the entity can have been created. Default: all
 * @return array A list of entities.
 */
function get_entities_alpha($type = "", $subtype = "", $owner_guid = 0, $letter = "", $limit = 10, $offset = 0, $count = false, $site_guid = 0, $container_guid = null, $timelower = 0, $timeupper = 0)
{
	global $CONFIG;

	if ($subtype === false || $subtype === null || $subtype === 0)
		return false;

    switch($type) {
      case 'user':
        $table = $CONFIG->dbprefix.'users_entity';
        $name = 'name';
        break;
      case 'group':
        $table = $CONFIG->dbprefix.'groups_entity';
        $name = 'name';
        break;
      case 'object':
        $table = $CONFIG->dbprefix.'objects_entity';
        $name = 'title';
        break;
      default:
        return false;
        break;
    }

    $order_by = $name." asc";
	$order_by = sanitise_string($order_by);
	$letter = sanitise_string($letter);
	$limit = (int)$limit;
	$offset = (int)$offset;
	$site_guid = (int) $site_guid;
	$timelower = (int) $timelower;
	$timeupper = (int) $timeupper;

	if ($site_guid == 0)
		$site_guid = $CONFIG->site_guid;

	$where = array();

	if (is_array($subtype)) {
		$tempwhere = "";
		if (sizeof($subtype))
		foreach($subtype as $typekey => $subtypearray) {
			foreach($subtypearray as $subtypeval) {
				$typekey = sanitise_string($typekey);
				if (!empty($subtypeval)) {
					$subtypeval = (int) get_subtype_id($typekey, $subtypeval);
				} else {
					$subtypeval = 0;
				}
				if (!empty($tempwhere)) $tempwhere .= " or ";
				$tempwhere .= "(type = '{$typekey}' and subtype = {$subtypeval})";
			}
		}
		if (!empty($tempwhere)) $where[] = "({$tempwhere})";

	} else {

		$type = sanitise_string($type);
		if ($subtype !== "")
			$subtype = get_subtype_id($type, $subtype);

		if ($type != "")
			$where[] = "type='$type'";
		if ($subtype!=="")
			$where[] = "subtype=$subtype";

	}

	if ($owner_guid != "") {
		if (!is_array($owner_guid)) {
			$owner_array = array($owner_guid);
			$owner_guid = (int) $owner_guid;
		} else if (sizeof($owner_guid) > 0) {
			$owner_array = array_map('sanitise_int', $owner_guid);
		}
		if (is_null($container_guid)) {
			$container_guid = $owner_array;
		}
	}
	if ($site_guid > 0)
		$where[] = "site_guid = {$site_guid}";

	if (!is_null($container_guid)) {
		if (is_array($container_guid)) {
			foreach($container_guid as $key => $val) $container_guid[$key] = (int) $val;
			$where[] = "container_guid in (" . implode(",",$container_guid) . ")";
		} else {
			$container_guid = (int) $container_guid;
			$where[] = "container_guid = {$container_guid}";
		}
	}
	if ($timelower)
		$where[] = "time_created >= {$timelower}";
	if ($timeupper)
		$where[] = "time_created <= {$timeupper}";



	if (!$count) {
	    $where[] = "tabla.guid = entities.guid";
		$query = "SELECT entities.*, tabla.{$name}, tabla.guid from {$CONFIG->dbprefix}entities as entities, {$table} as tabla where ";

		if (!empty($letter))
	      $query .= $name." like '{$letter}%' and";

	} else {
	    $where[] = "tabla.guid = entities.guid";
		$query = "SELECT count(tabla.guid) as total from {$CONFIG->dbprefix}entities as entities, {$table} as tabla where ";

		if (!empty($letter))
	      $query .= $name." like '{$letter}%' and";
	}
	foreach ($where as $w)
		$query .= " $w and ";

	$query .= get_access_sql_suffix(); // Add access controls
	if (!$count) {
		$query .= " order by $order_by";
		if ($limit) $query .= " limit $offset, $limit"; // Add order and limit
		$dt = get_data($query, "entity_row_to_elggstar");
		return $dt;
	} else {
		$total = get_data_row($query);
		return $total->total;
	}
}

/**
 * Returns a view of a list of entities, plus Index Directory and Pagination
 *
 * @param array $entities List of entities
 * @param string $letter Letter select to filter
 * @param int $limit The number of entities to display per page
 * @param int $offset The current indexing offset
 * @param int $count The total number of entities across all pages
 * @param bool $fullview Whether or not to display the full view (default: false)
 * @param bool $pagination Whether pagination is offered (default: true)
 * @return string The list of entities
 */
function elgg_view_alpha_entity_list($entities, $letter, $limit, $offset, $count, $fullview = false, $pagination = true) {

	$limit = (int) $limit;

	$context = get_context();
	$baseurl = substr($_SERVER['REQUEST_URI'], 0, strpos($_SERVER['REQUEST_URI'], '?'));

	$html = elgg_view('directory/entity_list',array(
											'entities' => $entities,
											'letter' => $letter,
											'limit' => $limit,
	                                        'offset' => $offset,
	                                        'count' => $count,
											'fullview' => $fullview,
											'viewtype' => get_input('search_viewtype','list'),
	                                        'baseurl' => $baseurl,
	                                        'context' => $context,
											'pagination' => $pagination
										  ),false,false);

	return $html;

}

register_elgg_event_handler('init', 'system', 'directory_init');
?>
