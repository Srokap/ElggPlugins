<?php
/**
*
* @author Daniel Aristizabal Romero <daniel@somosmas.org>
* @copyright Corporación Somos más - 2009
*/

require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

set_context('search');
$letter = get_input('letter');
$limit = get_input('limit');
$offset = get_input('offset');

// Consultar todos los entities respectivos
$objects = list_entities_alpha('user', "", $letter, (int)$limit, (int)$offset);

$title = elgg_echo('directory:listing');
$area2 = elgg_view_title($title);
$area2 .= $objects;

$body = elgg_view_layout('two_column_left_sidebar',$area1, $area2);

page_draw($title, $body);
?>