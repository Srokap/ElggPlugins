<?php
/**
  * File for translate strings
  *
  * @package ElggDirectory
  * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
  * @author Daniel Aristizabal Romero <daniel@somosmas.org>
  * @copyright Corporación Somos más - 2009
  * @link http://www.somosmas.org
  */

$english = array(
  'directory:listing'=>"List",
  'directory:noresults'=>"Sorry. No Results",
  'directory:all'=>"View All",
);

add_translation("en",$english);
?>