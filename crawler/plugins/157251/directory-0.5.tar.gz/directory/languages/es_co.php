<?php
/**
  * File for translate strings
  *
  * @package ElggDirectory
  * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
  * @author Daniel Aristizabal Romero <daniel@somosmas.org>
  * @copyright Corporación Somos más - 2009
  * @link http://www.somosmas.org
  */

$spanish = array(
  'directory:listing'=>"Listado",
  'directory:noresults'=>"No hubo Resultados",
  'directory:all'=>"Ver Todos",
);

add_translation("es_co",$spanish);
?>