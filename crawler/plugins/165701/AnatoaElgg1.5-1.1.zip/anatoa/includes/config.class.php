<?php
/* Anatoa Elgg Plugin v1.1
*  Copyright 2009 Univalence Ltd
*  All rights reserved
*
* DISCLAIMER
* Anatoa or Univalence Ltd shall not be liable for any of the following losses or damage
* (whether such damage or losses were foreseen, foreseeable, known or otherwise):
* (a) loss of data;
* (b) loss of revenue or anticipated profits;
* (c) loss of business;
* (d) loss of opportunity;
* (e) loss of goodwill or injury to reputation;
* (f) losses suffered by third parties; or
* (g) any indirect, consequential, special or exemplary damages
* arising from the use of Anatoa.com or associated web services regardless of the
* form of action, including the use of this source code.
*/

class anatoaConfiguration
{
	public $soapURL;
	public $anatoaURL;
	public $serverIPAddress;
	public $tempDir;
	public $pluginName;
	public $pluginVersion;

	public $communityBuilderEnabled;
	public $communityBuilderInstalled;
	public $osDateCommentEnabled;
	public $osDateCommentInstalled;
	public $joomGalleryEnabled;
	public $joomGalleryInstalled;
	public $uddeIMEnabled;
	public $uddeIMInstalled;


	//public $impDates  = array();
	public $ProfileTable = array();
	public $MasterTables = array();
	public $Tables = array();

	public $genMsg = array();
	public $soapResponse = array();
	public $rejectionThreshold = array();
	public $reasonForProfileDeletion = array();
	public $reasonForReportingProfile = array();
	public $reqMod = array();

	function __construct()
	 {
	 	global $CONFIG;
	 	$this->soapURL =  'http://ws.anatoa.com/ws/?wsdl';
		$this->anatoaURL = "<a href='http://www.anatoa.com' target='_blank'>Anatoa.com</a>";
		$this->tempDir = "tmp";
		$this->pluginName = "Elgg";
		$this->pluginVersion = "1.1";
		$this->serverIPAddress = $_SERVER['SERVER_ADDR'];

		$this->rejectionThreshold = array('Low' => 3.0,'Standard' => 6.0,'High' => 9.0,'Disable'=>10.0);

		$this->reasonForProfileDeletion = array('Profile' => 'Suspected fraudulent profile',
												'Message' => 'Suspected fraudulent message',
												'Image' => 'Suspected fraudulent image'
												);

		$this->reasonForReportingProfile = array('Abused other member',
												'Asked member for money',
												'Membership fee fraud',
												'Posted inappropriate content',
												'Spammed other members',
												'Other'
												);

		$this->ProfileTable = array(
							$this->pluginName => array(
										'tblName'=>'users_entity',
										'priKey'=>'guid',
										'UserName'=>'username',
										'Password'=>'password',
										'Email'=>'email',
										'DateCreated'=>'userEntity.time_created',
										'DateModified'=>'userEntity.time_updated',
										'LastLogin'=>'last_login',
										'JOIN'=>" LEFT JOIN {$CONFIG->dbprefix}entities AS userEntity ON userEntity.guid = Users.guid AND userEntity.type = 'user' ".
												" LEFT JOIN {$CONFIG->dbprefix}metadata AS metaData ON metaData.entity_guid = Users.guid AND metaData.name_id = 10 ", // for admin
										'REQUIRED' =>' metaData.value_id IS NULL  '
										),
						  	'Anatoa' => array(
										'tblName'=>'anatoa_users',
										'priKey'=>'guid',
										'UserName'=>'username',
										'Password'=>'password',
										'Email'=>'email',
										'DateCreated'=>'userEntity.time_created',
										'DateModified'=>'userEntity.time_updated',
										'LastLogin'=>'last_login',
										'JOIN'=>" LEFT JOIN {$CONFIG->dbprefix}entities AS userEntity ON userEntity.guid = anatoaUsers.guid AND userEntity.type = 'user' ".
												" LEFT JOIN {$CONFIG->dbprefix}metadata AS metaData ON metaData.entity_guid = Users.guid AND metaData.name_id = 10 ", // for admin
										'REQUIRED' =>'  metaData.value_id IS NULL  '
										)
								);

		$this->MasterTables = array('Profile' => 'anatoa_mst_profiles',
						  			'Message' => 'anatoa_mst_messages',
						  			'Image'	=> 'anatoa_mst_images'
								);

		$this->MessagesType = array('messages','blog','thewire','comments');
		$this->ImagesType = array('image','profileImage');

	 }

	// this implements the 'singleton' design pattern.
	function getInstance()
    {
        static $instance;
        if (!isset($instance)) {
            $c = __CLASS__;
            $instance = new $c;
        }
        return $instance;
    }

}