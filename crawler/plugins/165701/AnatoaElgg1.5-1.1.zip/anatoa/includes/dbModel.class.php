<?php
/* Anatoa Elgg Plugin v1.1
*  Copyright 2009 Univalence Ltd
*  All rights reserved
*
* DISCLAIMER
* Anatoa or Univalence Ltd shall not be liable for any of the following losses or damage
* (whether such damage or losses were foreseen, foreseeable, known or otherwise):
* (a) loss of data;
* (b) loss of revenue or anticipated profits;
* (c) loss of business;
* (d) loss of opportunity;
* (e) loss of goodwill or injury to reputation;
* (f) losses suffered by third parties; or
* (g) any indirect, consequential, special or exemplary damages
* arising from the use of Anatoa.com or associated web services regardless of the
* form of action, including the use of this source code.
*/

class dbModel
{
    /**
     * Anatoas data array
     *
     * @var array
     */
    var $_data;

    public $profile_ids = array();

    function dbModel()
    {

    }

    function getConfig()
    {
    	global $CONFIG;
    	return get_data_row("SELECT * FROM {$CONFIG->dbprefix}anatoa_config LIMIT 1");
    }

    function updateConfig(&$data)
    {
    	global $CONFIG;
		update_data("UPDATE {$CONFIG->dbprefix}anatoa_config
							SET APIKey = '{$data['APIKey']}',
							Rejection_Threshold = '{$data['Rejection_Threshold']}',
							Action = '{$data['Action']}',
							Check_full_email = '{$data['Check_full_email']}',
							keyChecked = 'Valid',
							ModifiedBy = '1',
							LastModified = NOW()");
    }

    function setConfig($field,$value)
    {
    	global $CONFIG;
    	update_data("UPDATE {$CONFIG->dbprefix}anatoa_config SET $field = '$value'");
    }

    function getlast24hrStat()
	{
		global $CONFIG;
		$anatoaConfig = anatoaConfiguration::getInstance();
		$APIconfig = $this->getConfig();

		foreach ($anatoaConfig->MasterTables as $type => $tableName)
		{
			$result = get_data_row("SELECT count(*) AS totalChecked FROM {$CONFIG->dbprefix}$tableName WHERE CheckStatus = 'Checked' AND checkDate > '".date('Y-m-d H:i:s',strtotime('- 24 hours'))."'");
			$temp["Checked$type"] = $result->totalChecked;

			$thrashHoldValue = $APIconfig->Rejection_Threshold.'Value';
			$result = get_data_row("
				SELECT count(*) AS totalFraud FROM {$CONFIG->dbprefix}$tableName
						WHERE CheckStatus = 'Checked' AND
							Status <> 'Unconfirmed'  AND
							( checkReturnValue > {$APIconfig->$thrashHoldValue} OR ( CheckStatus = 'Checked' AND ReportStatus = 'Unreported') ) AND
							checkDate > '".date('Y-m-d H:i:s',strtotime('- 24 hours'))."' ");
			$temp["Fraudulent$type"] = $result->totalFraud;
		}

		$result = get_data_row("SELECT count(*) AS reportedProfiles FROM {$CONFIG->dbprefix}{$anatoaConfig->MasterTables['Profile']} WHERE reportReturnValue = 'SUBMITTED_PROFILE_SUCCESS' AND reportDate > '".date('Y-m-d H:i:s',strtotime('- 24 hours'))."'");
		$temp['ReportedProfiles'] = $result->reportedProfiles;

		$usageTypes = array('Profile','Message','Image');
		foreach ($usageTypes as $type)
		{
			$var = 'check'.$type.'LimitReached';
			if($APIconfig->$var)
				$temp['Notify'][$type]=str_replace('{--ServiceType--}',$type,elgg_echo('USAGE_COMPLETE'));
		}

		if(strtotime($APIconfig->CronRunnedAt) < strtotime('-5 minutes'))
		{
			$temp['Notify'][] = elgg_echo('CRON_NOT_RUN_WARNING');
		}

		return $temp;
	}

	/**
	 * Restores select member deleted by anatoa
	 *
	 * @param array $arrUserIds array of user Id's
	 */
	function restoreMembers($arrUserIds)
	{
		global $CONFIG;
		$anatoaConfig = anatoaConfiguration::getInstance();
		$prefix_profile_table = $CONFIG->dbprefix.$anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['tblName'];
		$profile_table_pk     = $anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['priKey'];
		$prefix_backup_table  = $CONFIG->dbprefix.$anatoaConfig->ProfileTable['Anatoa']['tblName'];
		$backup_table_pk      = $anatoaConfig->ProfileTable['Anatoa']['priKey'];
		$prefix_master_table  = $CONFIG->dbprefix.$anatoaConfig->MasterTables['Profile'];
		$strUserIDs = implode(',',$arrUserIds);

		$query = "SELECT * FROM $prefix_backup_table
					WHERE $backup_table_pk IN ($strUserIDs)";
		$result = get_data( $query );

		foreach ($result as $member)
		{
			$comma='';
			$fieldList = '';
			foreach ($member as $fieldName=>$values)
			{
				$fieldList .= "$comma $fieldName";
				$comma = ',';
			}
			$comma = '';
			$fieldListValues = '';
			foreach ($member as $fieldName=>$values)
			{
				$fieldListValues .= $comma."'".addslashes($values)."' ";
				$comma = ',';
			}

			insert_data( "INSERT IGNORE INTO $prefix_profile_table ($fieldList) VALUES ($fieldListValues)" );
		}

		// restore data to entity table
		$query = "SELECT * FROM ".$CONFIG->dbprefix."anatoa_entities WHERE guid IN ($strUserIDs) AND type='user'";
		$result = get_data( $query );

		foreach ($result as $member)
		{
			$comma='';
			$fieldList = '';
			foreach ($member as $fieldName=>$values)
			{
				$fieldList .= "$comma $fieldName";
				$comma = ',';
			}
			$comma = '';
			$fieldListValues = '';
			foreach ($member as $fieldName=>$values)
			{
				$fieldListValues .= $comma."'".addslashes($values)."' ";
				$comma = ',';
			}

			insert_data( "INSERT IGNORE INTO ".$CONFIG->dbprefix."entities ($fieldList) VALUES ($fieldListValues)" );
		}

		$query="UPDATE $prefix_master_table AS Master
				LEFT JOIN $prefix_backup_table AS Backup
					ON Master.ProfileID = Backup.$backup_table_pk
				SET Master.Status = 'Restored'
				WHERE Master.ProfileID IN ($strUserIDs)";
		update_data($query);

		delete_data("DELETE
							  FROM $prefix_backup_table
							  WHERE $backup_table_pk IN ($strUserIDs)");
	}

	/**
	 * Gets Number of Old Profiles to be check
	 *
	 * @param int $maxLimit
	 * @param boolean $recheck
	 * @return int (Number of Profiles)
	 */
	function getNumberProfileUnchecked($maxLimit=250,$recheck='')
 	{
 		global $CONFIG;
 		$anatoaConfig = anatoaConfiguration::getInstance();
		$prefix_profile_table	= $CONFIG->dbprefix.$anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['tblName'];
		$profile_table_pk		= $anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['priKey'];
		$user_created			= $anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['DateCreated'];
		$prefix_master_table	= $CONFIG->dbprefix.$anatoaConfig->MasterTables['Profile'];
		$APIconfig = $this->getConfig();
 		$installationDate = strtotime($APIconfig->AddedDate);

 		$strRecheckCondition = $recheck == 'Recheck' ?  "OR ( Master.CheckedWithIP = 'No' AND
														Master.checkStatus = 'Checked' AND
														Master.Status <> 'Deleted' AND
														Master.IPAddress <> '' AND
														Master.IPAddress IS NOT NULL)"
 													 :  '' ;
 		if(!empty($maxLimit))
 			$maxLimit = "LIMIT $maxLimit";
 	    else $maxLimit = '';

 		$query = "SELECT Users.$profile_table_pk AS userID
 					FROM $prefix_profile_table AS Users
				  	LEFT JOIN $prefix_master_table AS Master
				  		ON  Users.$profile_table_pk = Master.ProfileID ";

 		if(!empty($anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['JOIN']))
 		   $query .= $anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['JOIN'];

		$query .= "WHERE	(( Master.CheckStatus='Unchecked' AND Master.Status <> 'Deleted' ) OR Master.ID IS NULL $strRecheckCondition) AND	$user_created < $installationDate ";

		if(!empty($anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['REQUIRED']))
			$query .= " AND ".$anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['REQUIRED'];

		$query .= "ORDER BY Master.IPAddress DESC $maxLimit";

		$result = get_data($query);
		$this->profile_ids = array();

		if(!empty($result))
			foreach ($result as $row)
				$this->profile_ids[] = $row->userID;

		return count($this->profile_ids);
 	}

 	function getNumberImageUnchecked()
 	{
 		global $CONFIG;
 		$anatoaConfig = anatoaConfiguration::getInstance();
 		$APIconfig = $this->getConfig();
 		$albArr = array();
		$this->returnValue = 0;

		foreach ($this->profile_ids as $profileID)
	 	{
	 			$albums = get_entities('object','album',$profileID);

	 			if(!empty($albums))
				foreach ($albums as $album)
					$albArr[] = $album->guid;

				if(!empty($albArr))
				{
					$Images = get_entities('object','image',$albArr);

					if(!empty($Images))
					foreach ($Images as $img)
					{
						if($img->time_created < strtotime($APIconfig->AddedDate))
							$this->returnValue ++;
					}
				}

				$albums = array();
				$Images = array();
				$albArr = array();
	 	}
		return $this->returnValue;
 	}

 	function getNumberMessageUnchecked()
 	{
 		global $CONFIG;
		$anatoaConfig = anatoaConfiguration::getInstance();
		$APIconfig = $this->getConfig();
 		$this->returnValue = 0;
	 	foreach ($this->profile_ids as $profileID)
	 	{
	 		foreach ($anatoaConfig->MessagesType as $objSubtype)
			{
				switch ($objSubtype)
				{
					case 'comments' : $Messages = $this->getUserComments($profileID); break;
					case 'messages' : $Messages = get_entities_from_metadata('fromId',$profileID,'object',$objSubtype,$profileID); break;
					case 'blog'		:
					case 'thewire'	:
					default 		: $Messages = get_entities('object',$objSubtype,$profileID);
				}

				if(!empty($Messages))
				foreach ($Messages as $msg)
				{

					if($msg->time_created < strtotime($APIconfig->AddedDate))
						$this->returnValue ++;
				}
				$Messages = array();
			}
 		}
		return $this->returnValue;
 	}

 	 /**
	 *  Get Profile Detail record for database
	 *
	 * @param int $profileId (Profile ID)
	 * @return Array(associative) of profile record
	 */
	function getProfileDetails($profileId)
	{
		global $CONFIG;
		$anatoaConfig  = anatoaConfiguration::getInstance();
		$profile_table    = $anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['tblName'];
		$profile_table_pk = $anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['priKey'];
		$prefix_profile_table = $CONFIG->dbprefix.$profile_table;
		$backup_table     = $anatoaConfig->ProfileTable['Anatoa']['tblName'];
		$backup_table_pk  = $anatoaConfig->ProfileTable['Anatoa']['priKey'];
		$prefix_backup_table = $CONFIG->dbprefix.$backup_table;
		$prefix_master_table = $CONFIG->dbprefix.$anatoaConfig->MasterTables['Profile'];

 		$query ="SELECT $profile_table.*, Master.IPAddress, Master.ProxyIP, Master.Country,Master.CheckedWithIP,
 						$backup_table.email AS altEmail,$backup_table.username AS altUsername, Master.FirstName, Master.LastName,Master.CheckStatus
 					FROM $prefix_profile_table AS $profile_table
 				 LEFT JOIN $prefix_master_table AS Master
 				 		ON Master.ProfileID = $profile_table.$profile_table_pk
 				 LEFT JOIN $prefix_backup_table AS $backup_table
 				 		ON $backup_table.$backup_table_pk = $profile_table.$profile_table_pk
 				 WHERE $profile_table.$profile_table_pk = $profileId;";

 		return get_data_row($query);
	}

	/**
	 * Get all related Images of profiles
	 *
	 * @param int $profileId
	 * @param int $chkOrRpt  mode reporting or checking profile
	 * @return Array(associative) of Image Records
	 */
	function getAllImagesOfProfile($profileId,$chkOrRpt = 'Check')
	{
		global $CONFIG;
		$anatoaConfig = anatoaConfiguration::getInstance();
		$prefix_master_table = $CONFIG->dbprefix.$anatoaConfig->MasterTables['Image'];
		$imageArray = array();
		$chkRptWhere = ($chkOrRpt == 'Check') ? "Master.CheckStatus='Unchecked'" : "Master.ReportStatus='Unreported'" ;

		$i = 0;
		if(!empty($anatoaConfig->Tables['Images']))
		{
	 		foreach ($anatoaConfig->Tables['Images'] as $imgTables)
	 		{
	 			$img_table		= $imgTables['tblName'];
	 			$img_table_pk	= $imgTables['priKey'];
				$prefix_img_table = $CONFIG->dbprefix.$img_table;

				$query = "SELECT $img_table.$img_table_pk,
							{$imgTables['File']} AS File,
							{$imgTables['Extension']} AS Extension,
							'$img_table' AS tableName,
							$i as tblIndex
						  FROM $prefix_img_table as $img_table
							LEFT JOIN $prefix_master_table AS Master
							ON $img_table.$img_table_pk = Master.ImageID AND Master.TableName = '$img_table'";

		      	$query .= " WHERE (	( $chkRptWhere AND
		      						  Master.Status <> 'Deleted'
		      						) OR Master.ID IS NULL
		      					  )	AND $img_table.{$imgTables['MemberId']} IN ( $profileId )";

		      	$r = array();
		      	$result = get_data($query);
		      	foreach ($result as $r)
			 		$imageArray[] = (array) $r;

			 	++$i;
	 		}
		}

 		return $imageArray;
	}

	function getAllMessagesOfProfile($profileId,$chkOrRpt = 'Check')
	{
		global $CONFIG;
		$anatoaConfig = anatoaConfiguration::getInstance();
		$prefix_master_table = $CONFIG->dbprefix.$anatoaConfig->MasterTables['Message'];
 		$msgArray = array();
 		$chkRptWhere = ($chkOrRpt == 'Check') ? "Master.CheckStatus='Unchecked'" : "Master.ReportStatus='Unreported'" ;
		$i = 0;

		if(!empty($anatoaConfig->Tables['Message']))
		{
			foreach ($anatoaConfig->Tables['Message'] as $msgTables)
	 		{
	 			$msg_table		= $msgTables['tblName'];
	 			$msg_table_pk	= $msgTables['priKey'];
	 			$prefix_msg_table = $CONFIG->dbprefix.$msg_table;

				if (isset($msgTables['FilterColumn']))
					$filter = "$msg_table.{$msgTables['FilterColumn']}='{$msgTables['FilterValue']}'";
				else
					$filter = "1=1";

				$query = "SELECT $msg_table.$msg_table_pk,{$msgTables['Message']},
				 				'$msg_table' AS tableName,	$i as tblIndex
							FROM $prefix_msg_table AS $msg_table
							LEFT JOIN $prefix_master_table as Master ON
								 $msg_table.$msg_table_pk = Master.MessageID AND
								 Master.TableName = '$msg_table'
						    WHERE (	( $chkRptWhere AND
		      						  Master.Status <> 'Deleted'
		      						) OR Master.ID IS NULL
		      					  )	AND $filter AND $msg_table.{$msgTables['Sender']} IN ( $profileId )";

			 	$r = array();
		      	$result = get_data($query);
		      	foreach ($result as $r)
			 		$msgArray[] = (array) $r;
			 	++$i;
	 		}
		}
		return $msgArray;
	}

	function updateWithSoapCheckResult($memberId, $idField, $id, $table, $mstTable, $result, $fraudulent, $action, $file='',$reason='')
	{
		global $CONFIG;
		$anatoaConfig = anatoaConfiguration::getInstance();
		$prefix_master_table = $CONFIG->dbprefix.$anatoaConfig->MasterTables[$mstTable];
		$prefix_action_table = $CONFIG->dbprefix.$table;

		$extraField = (!empty($file) && $file != 'WithIP') ? ', Master.ImageFile = \''.addslashes($file)."' " : '';
		$extraField = (!empty($file) && $file == 'WithIP') ? ', Master.CheckedWithIP =\'Yes\'' : $extraField;

		if($fraudulent != 1) $action = 'Unconfirmed';
		if($action == "Delete") $action = "Deleted";
		if($action == "Block")  $action = "Blocked";
		if($action == "Suspend")  $action = "Blocked";

		$insertProfileIDColumn = ($table != 'users_entity') ? " ProfileID," : '';
		$insertprofileID = ($table != 'users_entity') ? " $memberId," : '';

		$query = "INSERT IGNORE INTO $prefix_master_table ($insertProfileIDColumn {$mstTable}ID, TableName)
				    VALUES ($insertprofileID $id, '$table')";
		insert_data( $query );

		$fieldName = strpos(strtolower($table),'image') ? 'ImageId' : 'MessageId';

		if(strpos($table,'Object')!==false)
			$query = "UPDATE $prefix_master_table AS Master
						SET
						 Master.Status = '$action',
						 Master.CheckStatus = 'Checked',
						 Master.checkDate = '".date('Y-m-d H:i:s')."',
						 Master.checkReturnValue = '$result',
						 Master.checkReasons = 'before Plugin Installed',
						 Master.checkMode = 'Manul : Admin' $extraField
						WHERE Master.$fieldName = '$id' AND Master.TableName = '$table' AND ProfileId = $memberId";
		else
			$query = "UPDATE $prefix_action_table AS $table
						INNER JOIN $prefix_master_table AS Master ON Master.{$mstTable}ID = $table.$idField
						SET
						 Master.Status = '$action',
						 Master.CheckStatus = 'Checked',
						 Master.Recheck = 'No',
						 Master.checkDate = '".date('Y-m-d H:i:s')."',
						 Master.checkReturnValue = '$result',
						 Master.checkReasons = 'before Plugin Installed',
						 Master.Reason = '$reason',
						 Master.checkMode = 'Manul : Admin' $extraField
						WHERE $table.$idField = '$id' AND Master.TableName = '$table'";
		update_data( $query );

		if( mysql_affected_rows(get_db_link('read')) == 0)
			update_data(str_replace("$table","anatoa_$table",$query));

		if(strpos($table,'Object') === false) {
		if($action == 'Deleted')
		{
			$query = "SELECT * FROM $prefix_action_table WHERE $idField = $id ";
			$t1 = get_data_row($query);
			$tableData = (array) $t1;

			if($table == $anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['tblName'])
				$Anatoatable = $anatoaConfig->ProfileTable['Anatoa']['tblName'];
			else $Anatoatable = 'anatoa_'.$table;

			if(!empty($tableData))
			{
				$query = 'INSERT INTO '.$CONFIG->dbprefix.$Anatoatable ;
				$comma = '(';
				foreach ($tableData as $key => $value)
				{
					$query .= $comma.$key;
					$comma = ',';
				}
				$query .= ') VALUES ';
				$comma = '(';
				foreach ($tableData as $key => $value)
				{
					$query .= $comma.'\''.addslashes($value).'\'';
					$comma = ',';
				}
				$query .= ')';
				insert_data($query);

			}

			$query = "DELETE FROM $prefix_action_table WHERE $idField='$id';";
			delete_data($query);

			// =========================   delete from entity table
			if($table == 'users_entity')
			{
				$query = "SELECT * FROM ".$CONFIG->dbprefix."entities WHERE guid = $id AND type='user'";
				$t1 = get_data_row($query);
				$tableData = (array) $t1;

				if(!empty($tableData))
				{
					$query = 'INSERT IGNORE INTO '.$CONFIG->dbprefix.'anatoa_entities' ;
					$comma = '(';
					foreach ($tableData as $key => $value)
					{
						$query .= $comma.$key;
						$comma = ',';
					}
					$query .= ') VALUES ';
					$comma = '(';
					foreach ($tableData as $key => $value)
					{
						$query .= $comma.'\''.addslashes($value).'\'';
						$comma = ',';
					}
					$query .= ')';
					insert_data($query);

				}

				$query = "DELETE FROM ".$CONFIG->dbprefix."entities WHERE guid = $id AND type='user';";
				delete_data($query);
			}
		}
		elseif (($mode == 'Blocked' || $mode == 'Block') && $table == 'users_entity')
		{
			update_data("UPDATE ".$CONFIG->dbprefix."users_entity SET banned = 'yes' WHERE $idField = '$id';");
		}}
	}

	function updateWithSoapReportResult($memberId,$idField,$id,$table,$mstTable,$result,$reason ='Reported By Admin',$file='',$action='Blocked',$calledBy = '',$exception=':')
	{
		global $CONFIG;
		$anatoaConfig = anatoaConfiguration::getInstance();
		$prefix_master_table = $CONFIG->dbprefix.$anatoaConfig->MasterTables[$mstTable];
		$prefix_action_table = $CONFIG->dbprefix.$table;
		$exceptional = explode(':',$exception);

		$insertProfileIDColumn = ($table != 'users_entity') ? " ProfileID," : '';
		$insertProfileID = ($table != 'users_entity') ? " $memberId," : '';

		if($action == "Delete") $action = "Deleted";
		if($action == "Block")  $action = "Blocked";
		if($action == "Suspend")  $action = "Blocked";

		$query = "INSERT IGNORE INTO $prefix_master_table ($insertProfileIDColumn {$mstTable}ID, TableName)
				    VALUES ($insertProfileID $id, '$table')";
		insert_data( $query );

		$fieldName = strpos(strtolower($table),'image') ? 'ImageId' : 'MessageId';

		if(strpos($table,'Object')!==false)
			$query = "UPDATE $prefix_master_table AS Master
						SET
						 Master.Status = '$action',
						 Master.ReportStatus = 'Reported',
						 Master.reportDate = '".date('Y-m-d H:i:s')."',
						 Master.reportReturnValue = '$result',
						 Master.reportReasons = '$reason',
						 Master.reportMode = 'Manul : Admin'
						WHERE Master.$fieldName = '$id' AND Master.TableName = '$table' AND ProfileId = $memberId";
		else
			$query = "UPDATE ".$CONFIG->dbprefix."$table AS $table
						INNER JOIN $prefix_master_table AS Master ON Master.{$mstTable}ID = $table.$idField AND Master.TableName = '$table'
						 SET
						 Master.Status = '$action' ,
						 Master.ReportStatus = 'Reported',
						 Master.Recheck = 'No',
						 Master.reportDate = '".date('Y-m-d H:i:s')."',
						 Master.reportReturnValue = '$result',
						 Master.reportReasons  = '$reason',
						 Master.reportMode = 'Manul : Admin'
						WHERE $table.$idField = '$id' AND Master.TableName = '$table'";
		update_data( $query );

		// Delete or block the profile
		if(strpos($table,'Object') === false) {
		if($exceptional[0] != $id || $exceptional[1]!= $table)
		{
			if($action == 'Deleted')
			{
				$query= "SELECT * FROM $prefix_action_table WHERE $idField = $id ";
				$t1 = get_data_row($query);
				$member = (array) $t1;

				if($table == $anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['tblName'])
					$Anatoatable = $anatoaConfig->ProfileTable['Anatoa']['tblName'];
				else $Anatoatable = 'anatoa_'.$table;

				if(!empty($member))
				{
					$query = 'INSERT INTO '.$CONFIG->dbprefix.$Anatoatable ;
					$comma = '(';
					foreach ($member as $key => $value)
					{
						$query .= $comma.$key;
						$comma = ',';
					}
					$query .= ') VALUES ';
					$comma = '(';
					foreach ($member as $key => $value)
					{
						$query .= $comma.'\''.addslashes($value).'\'';
						$comma = ',';
					}
					$query .= ')';
					insert_data($query);
				}

				$query = "DELETE FROM $prefix_action_table WHERE $idField=$id";
				delete_data($query);

				// =========================   delete from entity table
				if($table == 'users_entity')
				{
					$query = "SELECT * FROM ".$CONFIG->dbprefix."entities WHERE guid = $id AND type='user'";
					$t1 = get_data_row($query);
					$tableData = (array) $t1;

					if(!empty($tableData))
					{
						$query = 'INSERT IGNORE INTO '.$CONFIG->dbprefix.'anatoa_entities' ;
						$comma = '(';
						foreach ($tableData as $key => $value)
						{
							$query .= $comma.$key;
							$comma = ',';
						}
						$query .= ') VALUES ';
						$comma = '(';
						foreach ($tableData as $key => $value)
						{
							$query .= $comma.'\''.addslashes($value).'\'';
							$comma = ',';
						}
						$query .= ')';
						insert_data($query);

					}

					$query = "DELETE FROM ".$CONFIG->dbprefix."entities WHERE guid = $id AND type='user';";
					delete_data($query);
				}
			}
			elseif ($action == 'Blocked' && $table == 'users_entity')
			{
				update_data("UPDATE ".$CONFIG->dbprefix."$table SET banned = 'yes' WHERE $idField = '$id'");
			}}
		}
	}

	/**
	 * Enter Log into database about Web Sevice used
	 *
	 * @param String $type (type of webservice used)
	 * @param int $by (calling user id)
	 * @param int $memberId (associated member id of message,image or profile)
	 * @param int $recordId (record id withing actual table)
	 * @param String $tableName (table name)
	 * @param String $para (serialized varible for parameter passed with SOAP Service)
	 * @param String $result (result returned by SOAP service)
	 * @param String $reason (reason behind calling report or check web service)
	 */
	function enterLog($type,$by,$memberId,$recordId,$tableName,$para,$result,$reason='')
	{
		global $CONFIG;
		$query = "INSERT INTO ".$CONFIG->dbprefix."anatoa_transactionlog
					SET calledBy = '$by', RecordID='$recordId', TableName = '$tableName',
					    TransactionType = '$type', MemberId = $memberId, parameters = '$para',
						ReturnValue = '$result', Reasons = '$reason', LogDate = '".date('Y-m-d H:i:s')."'
				  ON DUPLICATE KEY UPDATE
				  	calledBy = '$by',
					TransactionType = '$type',
					MemberId = $memberId,
					parameters = '$para',
					ReturnValue = '$result',
					Reasons = '$reason',
					LogDate = '".date('Y-m-d H:i:s')."'";
		insert_data($query);
	}

	function getMemberListForUpdating()
 	{
 		global $CONFIG;
 		$anatoaConfig = anatoaConfiguration::getInstance();
 		$APIconfig = $this->getConfig();
		$installationDate = strtotime($APIconfig->AddedDate);
		$cronLastRunDate = strtotime($APIconfig->CronRunnedAt);
		$cronLastRunDate = empty($cronLastRunDate) ? $installationDate : $cronLastRunDate ;

		$profile_table			= $anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['tblName'];
		$profile_table_pk		= $anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['priKey'];
		$prefix_profile_table	= $CONFIG->dbprefix.$profile_table;
		$profile_table_created	= $anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['DateCreated'];
		$profile_table_Modified	= $anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['DateModified'];
		$prefix_master_table	= $CONFIG->dbprefix.$anatoaConfig->MasterTables['Profile'];

 		$query = "SELECT Users.*, Master.IPAddress, Master.ProxyIP
					FROM $prefix_profile_table AS Users
       				LEFT JOIN $prefix_master_table AS Master
       					ON Master.ProfileID = Users.$profile_table_pk";

 		if(!empty($anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['JOIN']))
 		   $query .= $anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['JOIN'];

       	$query .="WHERE ( Master.ID IS NULL OR ((Master.CheckStatus = 'Unchecked' OR Master.Recheck = 'Yes') AND Master.Status != 'Restored')) AND
						  $profile_table_created > $installationDate";

       	if(!empty($anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['REQUIRED']))
			$query .= " AND ".$anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['REQUIRED'];

 		return get_data($query);
	}

	function get_admin_list()
	{
		global $CONFIG;
		$query = "SELECT guid FROM {$CONFIG->dbprefix}entities
					INNER JOIN {$CONFIG->dbprefix}metadata  AS metaData
						ON metaData.entity_guid = {$CONFIG->dbprefix}entities.guid AND {$CONFIG->dbprefix}entities.type = 'user'
					INNER JOIN {$CONFIG->dbprefix}metastrings AS metaStr
						ON metaData.name_id = metaStr.id AND metaStr.string = 'admin'
					INNER JOIN {$CONFIG->dbprefix}metastrings AS metaStr2
						ON metaData.value_id = metaStr2.id AND metaStr.string = 'admin'
						AND (metaStr2.string = 'yes' OR metaStr2.string = '1')";
		$result = get_data($query);
		$arrAdminIds = array();
		foreach ($result as $row) $arrAdminIds[] = $row->guid;

		return $arrAdminIds;
	}

	function getExtraFields()
	{
		global $CONFIG;
		$query = "SELECT metaStr.id, pvtSet.name , pvtSet.value FROM {$CONFIG->dbprefix}private_settings AS pvtSet
					INNER JOIN {$CONFIG->dbprefix}metastrings AS metaStr
						ON pvtSet.name = metaStr.string OR pvtSet.name = REPLACE(metaStr.string, ' ', '_')
				  WHERE pvtSet.name like '%profile%';";
		return get_data($query);
	}

	function getAdditionalAttri($attribute,$profileId)
	{
		global $CONFIG;
		$query = "SELECT string FROM {$CONFIG->dbprefix}metadata AS metaData
					INNER JOIN {$CONFIG->dbprefix}metastrings AS metaStr1  ON metaData.value_id = metaStr1.id
					WHERE metaData.name_id = (SELECT $attribute from {$CONFIG->dbprefix}anatoa_config LIMIT 1)
							AND metaData.name_id != 0
							AND metaData.owner_guid = $profileId";
		$result = get_data_row($query);
		if($result)
			return $result->string;
		else return '';
	}

	function getUserComments($userId = '')
	{
		global $CONFIG;
		$comments = array();

		if($userId)
			$whereStr = "WHERE annotation.owner_guid = $userId";

		$query= "SELECT annotation.id,metaStr2.string,annotation.owner_guid,annotation.time_created
					FROM {$CONFIG->dbprefix}annotations AS annotation
					INNER JOIN {$CONFIG->dbprefix}metastrings AS metaStr1
							ON annotation.name_id = metaStr1.id AND metaStr1.string = 'generic_comment'
					INNER JOIN {$CONFIG->dbprefix}metastrings AS metaStr2
							ON annotation.value_id = metaStr2.id $whereStr";
		$result=get_data($query);
		if($result)
		{
			foreach ($result as $com)
			 {
			 	$temp = array();
			 	$temp['guid'] = $com->id;
			 	$temp['title'] = '';
			 	$temp['owner_guid'] = $com->owner_guid;
			 	$temp['description'] = $com->string;
			 	$temp['time_created'] = $com->time_created;
			 	$comments[] = (object) $temp;
			 }
		}
		return $comments;
	}

	function getProfileImage($userId = '')
	{
		global $CONFIG;
		$ProfileImage = array();

		if($userId)
			$whereStr = "WHERE metaData.entity_guid = $userId AND user.guid = $userId";

		$query= "SELECT metaData.id, metaStr2.string, user.guid, user.username ,metaData.time_created
					FROM {$CONFIG->dbprefix}users_entity as user
					INNER JOIN {$CONFIG->dbprefix}metadata AS metaData
							ON metaData.entity_guid = user.guid
					INNER JOIN {$CONFIG->dbprefix}metastrings AS metaStr1
							ON metaData.name_id = metaStr1.id AND metaStr1.string = 'icontime'
					INNER JOIN {$CONFIG->dbprefix}metastrings AS metaStr2
							ON metaData.value_id = metaStr2.id $whereStr";
		$result=get_data($query);
		if($result)
		{
			foreach ($result as $com)
			 {
			 	$temp = array();
			 	$temp['guid'] = $com->id;
			 	$temp['owner_guid'] = $com->guid;
			 	$temp['username'] = $com->username;
			 	$temp['icontime'] = $com->string;
			 	$temp['time_created'] = $com->string; //$com->time_created;
			 	$ProfileImage[] = (object) $temp;
			 }
		}
		return $ProfileImage;
	}

}
