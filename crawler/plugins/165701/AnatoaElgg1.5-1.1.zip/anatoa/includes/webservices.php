<?php
/* Anatoa Elgg Plugin v1.1
*  Copyright 2009 Univalence Ltd
*  All rights reserved
*
* DISCLAIMER
* Anatoa or Univalence Ltd shall not be liable for any of the following losses or damage
* (whether such damage or losses were foreseen, foreseeable, known or otherwise):
* (a) loss of data;
* (b) loss of revenue or anticipated profits;
* (c) loss of business;
* (d) loss of opportunity;
* (e) loss of goodwill or injury to reputation;
* (f) losses suffered by third parties; or
* (g) any indirect, consequential, special or exemplary damages
* arising from the use of Anatoa.com or associated web services regardless of the
* form of action, including the use of this source code.
*/

class anatoaWebService
{
	var $lang;

	function __construct()
	{

	}

	/**
	* This function will report a given profile, together with any profile images to Anatoa using SOAP.
	*  It will log each SOAP call.
	*/
	function reportProfile($profileID,$reasonForReporting='Reported By Site Admin',$mode='Blocked',$calledBy = 'Profile Listing Page',$rptDetail=':')
	{
		global $CONFIG;
		$anatoaConfig = anatoaConfiguration::getInstance();
		$objDBModel = new dbModel();
		$soapclient = new anatoaSoapClient();
		$reportForDetail = explode(':',$rptDetail);
		$APIconfig = $objDBModel->getConfig();

		if(empty($APIconfig->APIKey) || $APIconfig->keyChecked != 'Valid')
			return "Error:APIKey";
		if(!$soapclient->init())
			return  "Error:Connection";

		// =============================== Report Profile =====================================

		$Profile = (array) $objDBModel->getProfileDetails($profileID);
		if(empty($Profile['email'])) $Profile['email'] = $Profile['altEmail'];

		if(strtolower($Profile['banned']) == 'yes' && $mode == 'Blocked' )
			return '';

		$profileParams = array(	'UserName'=>$Profile[$anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['UserName']],
								'Email'=>$Profile[$anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['Email']],
								'IPAddress'=>$Profile['IPAddress'],
								'ProxyIP'=>$Profile['ProxyIP'],
								'Reason'=> $reasonForReporting );

		if($APIconfig->FirstName)
			$profileParams['FirstName'] = $objDBModel->getAdditionalAttri('FirstName',$profileID);
		if($APIconfig->LastName)
			$profileParams['LastName'] = $objDBModel->getAdditionalAttri('LastName',$profileID);
		if($APIconfig->Country)
			$profileParams['Country'] = $objDBModel->getAdditionalAttri('Country',$profileID);

		if( !$soapclient->callMethod( $APIconfig->APIKey, 'reportProfile', 'Profiles', array( 'Profile'=>$profileParams ), $returnValues ) )
			return "Error:Connection";

		$return = $returnValues[0];
		$profileParams['APIKey'] = $APIconfig->APIKey;

		$objDBModel->updateWithSoapReportResult($profileID,
												$anatoaConfig->ProfileTable['Anatoa']['priKey'],
												$profileID,
												$anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['tblName'],
												'Profile',
												$return,
												$reasonForReporting,
												'',
												$mode,
												$calledBy,
												$rptDetail);
		$objDBModel->enterLog('Report Profile',
							  "Manul:Admin ($calledBy)",
							  $profileID,
							  $profileID,
							  $anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['tblName'],
							  serialize($profileParams),
							  $return,
							  $reasonForReporting);


	//================================================= Report Images ========================================================

	foreach ($anatoaConfig->ImagesType as $objSubtype)
		{
			if($objSubtype == 'profileImage')
				$Images = $objDBModel->getProfileImage($profileID);
			else
			{
				$albums = get_entities('object','album',$profileID);
				$albArr = array();

				if(!empty($albums))
				foreach ($albums as $album)
					$albArr[] = $album->guid;

				if(!empty($albArr))
					$Images = get_entities('object','image',$albArr);
				else
					$Images = array();
			}

			foreach ($Images as $image)
			{
				$imgTable = "Object - $objSubtype";
				$id = $image->guid;
				$idField = 'guid';
				$fileName = $objSubtype == 'image' ? $image->filename : "profile/". $image->username ."master.jpg";

				$readfile = new ElggFile();
				$readfile->owner_guid = $image->owner_guid;
				$readfile->setFilename($fileName);
				$contents = $readfile->grabFile();

				$imageContent = $contents;

				if ($imageContent)
				{
					$imageHash = md5($imageContent);
					$imageParams = array(	'Image'=>base64_encode($imageContent),
											'Email'=>$Profile['email'] );

					if( !$soapclient->callMethod( $APIconfig->APIKey, 'reportImage', 'Images', array( 'Image'=>$imageParams ), $returnValues ) )
						return "Error:Connection";

					$return = $returnValues[0];

					$forLogParameters = array('APIKey'=>$APIconfig->APIKey, 'ImageHash'=>$imageHash, 'Email'=>$Profile['email']);

					$exceptions = ($rptDetail=':' || empty($rptDetail)) ? ':' : $id.':'.$imgTable ;

					$objDBModel->updateWithSoapReportResult($profileID,
															$idField,
															$id,
															$imgTable,
															'Image',
															$return,
															$reasonForReporting,
															$fileName,
															$mode,
															$calledBy,
															$exceptions);
					$objDBModel->enterLog('Report Image',
										  "Manul:Admin ($calledBy)",
										  $profileID,
										  $id,
										  $imgTable,
										  serialize($forLogParameters),
										  $return,
										  $reasonForReporting);
				}
			}
		}
	}

	function ajaxCheckProfile($profileID)
	{
		global $CONFIG;
		$anatoaConfig = anatoaConfiguration::getInstance();
		$objDBModel = new dbModel();
		$soapclient = new anatoaSoapClient();
		$reasonForReporting = 'Check Old profile';
		$suspendDeleteReason = '';

		$fp = 0;
		$fi = 0;
		$fm = 0;
		$fraudulent = 0;
		$profileReported = 0;

		$APIconfig = $objDBModel->getConfig();
		$varRejTh = $APIconfig->Rejection_Threshold.'Value';

		if(empty($APIconfig->APIKey) || $APIconfig->keyChecked != 'Valid' || $APIconfig->APIKey == 'NOTCONFIGURED')
			return "Error:APIKey";

		if(!$soapclient->init())
			return "Error:Connection";

		// =============================== Profile Check =======================================

		$Profile = (array) $objDBModel->getProfileDetails($profileID);

		if($APIconfig->Check_full_email == 'Yes')
		{
			$emailAddressHash = '';
			$emailAddress = $Profile[$anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['Email']];
		}
		else
		{
			$emailAddressHash = md5($Profile[$anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['Email']]);
			$emailAddress = '';
		}

		$profileParams = array(	'UserName'=>$Profile[$anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['UserName']],
								'Email'=>$Profile[$anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['Email']],
								'IPAddress'=>$Profile['IPAddress'],
								'ProxyIP'=>$Profile['ProxyIP'],
								'Reason'=> $reasonForReporting );

		if($APIconfig->FirstName)
			$profileParams['FirstName'] = $objDBModel->getAdditionalAttri('FirstName',$profileID);
		if($APIconfig->LastName)
			$profileParams['LastName'] = $objDBModel->getAdditionalAttri('LastName',$profileID);
		if($APIconfig->Country)
			$profileParams['Country'] = $objDBModel->getAdditionalAttri('Country',$profileID);

		if( !$soapclient->callMethod( $APIconfig->APIKey, 'checkProfile', 'Profiles', array( 'Profile'=>$profileParams ), $returnValues ) )
			return  "Error:Connection";

		$return = $returnValues[0];
		$profileParams['APIKey'] = $APIconfig->APIKey;

		if(!is_numeric($return))
		{
			if($return == 'USAGE_COMPLETE')
				return "Error:Processing your request.<br> Server Response : ".str_replace('{--ServiceType--}','Profile',elgg_echo('USAGE_COMPLETE'));

			$query ="INSERT INTO ".$CONFIG->dbprefix."{$anatoaConfig->MasterTables['Profile']}
    	 	 				SET ProfileID = {$profileID},
    	 	 					TableName = '".$anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['tblName']."',
    	 	 					UserName = '{$Profile[$anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['UserName']]}',
    	 	 					Email = '{$Profile[$anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['Email']]}',
    	 						CheckStatus = 'Failed Check',
    	 						checkReasons = '$return',
    	 						checkDate = NOW(),
    	 						checkMode='Check Old Profile'
   		 				 ON DUPLICATE KEY UPDATE
   		 				 		UserName = '{$Profile[$anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['UserName']]}',
    	 	 					Email = '{$Profile[$anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['Email']]}',
    	 						CheckStatus = 'Failed Check',
    	 						checkReasons = '$return',
    	 						checkDate = NOW(),
    	 						checkMode='Check Old Profile'";
    	 	$db->query( $query );

			$objDBModel->enterLog('Check Profile',
								  'Check Old Profile',
								  $profileID,
								  $profileID,
								  $anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['tblName'],
								  addslashes(serialize($profileParams)),
								  $return);
		}
		elseif($return > $APIconfig->$varRejTh)
		{
			$fp++;
			$fraudulent =1;
			$suspendDeleteReason = 'Profile found to be fraudulent';
		}

		if($return > 6.0 && !($Profile['CheckStatus'] == 'Checked' && $Profile['CheckedWithIP'] == 'No'))
		{
			$contents = '';
			$contents = $this->reportProfile($profileID,
											 'Profile found to be fraudulent',
											 $APIconfig->Action,
											 'Check Old Profiles',
											 $profileID.':'.$anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['tblName']);

			if($contents == 'Error:Connection' || $contents == 'Error:APIKey' || $contents == 'Error:Processing' )
				return $contents;

			$profileReported = 1;
		}

		if(is_numeric($return))
		{
			$extra = !empty($Profile['IPAddress']) ? 'WithIP' : '';
			$objDBModel->updateWithSoapCheckResult($profileID,
												   $anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['priKey'],
												   $profileID,
												   $anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['tblName'],
												   'Profile',
												   $return,
												   $fraudulent,
												   $APIconfig->Action,
												   $extra,$suspendDeleteReason);
			$objDBModel->enterLog('Check Profile',
								  'Check Old Profile',
								  $profileID,
								  $profileID,
								  $anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['tblName'],
								  addslashes(serialize($profileParams)), $return);
		}

		if($profileReported)
		  	return "1;1";

		if($Profile['CheckStatus'] == 'Checked' && $Profile['CheckedWithIP'] == 'No')
		   return "1;$fp";

	//=================================== Image Check ======================================

	foreach ($anatoaConfig->ImagesType as $objSubtype)
	{
		if($objSubtype == 'profileImage')
			$Images = $objDBModel->getProfileImage($profileID);
		else
		{
			$albums = get_entities('object','album',$profileID);
			$albArr = array();

			if(!empty($albums))
			foreach ($albums as $album)
				$albArr[] = $album->guid;

			if(!empty($albArr))
				$Images = get_entities('object','image',$albArr);
			else
				$Images = array();
		}

		foreach ($Images as $image)
			{
				if($image->time_created > strtotime($APIconfig->AddedDate)) continue;

				$imgTable = "Object - $objSubtype";
				$id = $image->guid;
				$idField = 'guid';
				$fileName = $objSubtype == 'image' ? $image->filename : "profile/". $image->username ."master.jpg";

				$readfile = new ElggFile();
				$readfile->owner_guid = $image->owner_guid;
				$readfile->setFilename($fileName);
				$contents = $readfile->grabFile();

				$imageContent = $contents;
				$imageHash = md5($imageContent);
				$imageParams = array('ImageHash'=>$imageHash );

				if( !$soapclient->callMethod( $APIconfig->APIKey, 'checkImage', 'Images', array( 'Image'=>$imageParams ), $returnValues ) )
						return  "Error:Connection";

				$return = $returnValues[0];
				$fraudulent = 0;
				$imageParams['APIKey'] = $APIconfig->APIKey;

				if(!is_numeric($return))
				{
					if($return == 'USAGE_COMPLETE')
						return "Error:Processing your request.<br> Server Response : ".str_replace('{--ServiceType--}','Image',elgg_echo('USAGE_COMPLETE'));

					$query ="INSERT INTO ".$CONFIG->dbprefix."{$anatoaConfig->MasterTables['Image']}
			    	 	 				SET ProfileID = {$profileID},
			    	 	 					ImageID=$id,
			    	 	 					TableName = '".$imgTable."',
			    	 	 					CheckStatus = 'Failed Check',
			    	 	 					checkReasons = '$return' ,
			    	 	 					checkDate = NOW(),
			    	 	 					checkMode='Check Old Profile'
			    	 	 				ON DUPLICATE KEY UPDATE
			    	 	 					CheckStatus = 'Failed Check',
			    	 	 					checkReasons = '$return' ,
			    	 	 					checkDate = NOW(),
			    	 	 					checkMode='Check Old Profile'";
			    	$db->query( $query );
					$objDBModel->enterLog('Check Image',
										  'Check Old Profile',
										  $profileID,
										  $id,
										  $imgTable,
										  addslashes(serialize($imageParams)),
										  $return);
					continue;
				}
				elseif($return > $APIconfig->$varRejTh)
				{
					$fi++;
					$fraudulent =1;
				}

				if($return > 6.0)
				{
					$contents = '';
					$contents = $this->reportProfile($profileID,'Image found to be fraudulent', $APIconfig->Action,'Check Old Profiles', $id.':'.$imgTable);

					if($contents == 'Error:Connection' || $contents == 'Error:APIKey' || $contents == 'Error:Processing' )
						return $contents;

					$profileReported = 1;
				}

				$objDBModel->updateWithSoapCheckResult($profileID,
													   $idField,
													   $id,
													   $imgTable,
													   'Image',
													   $return,
													   $fraudulent,
													   $APIconfig->Action,$fileName);
				$objDBModel->enterLog('Check Image',
									  'Check Old Profile',
									  $profileID,
									  $id,
									  $imgTable,
									  addslashes(serialize($imageParams)),
									  $return);

				if($profileReported)
			  		return "1;1";
			}
	}

	//====================================================   Message Check  =================================================

	foreach ($anatoaConfig->MessagesType as $objSubtype)
	{
		switch ($objSubtype)
		{
			case 'comments' : $Messages = $objDBModel->getUserComments($profileID); break;
			case 'messages' : $Messages = get_entities_from_metadata('fromId',$profileID,'object',$objSubtype,$profileID); break;
			case 'blog'		:
			case 'thewire'	:
			default 		: $Messages = get_entities('object',$objSubtype,$profileID);
		}

		foreach ($Messages as $messgs)
		{
			if($messgs->time_created > strtotime($APIconfig->AddedDate)) continue;

			$msgData = empty($messgs->title) ? $messgs->description : $messgs->title.' '.$messgs->description ;
		    $messageParams = array( 'Message'=>strip_tags(stripslashes($msgData)) );

			if( !$soapclient->callMethod( $APIconfig->APIKey, 'checkMessage', 'Messages', array( 'Message'=>$messageParams ), $returnValues ) )
				return  "Error:Connection";

			$id =  $messgs->guid;
			$msgTableAlt = "Object - $objSubtype";
			$return = $returnValues[0];
			$fraudulent = 0;
			$messageParams['APIKey'] = $APIconfig->APIKey;

			if(!is_numeric($return))
			{
				if($return == 'USAGE_COMPLETE')
					return "Error:Processing your request.<br> Server Response : ".str_replace('{--ServiceType--}','Message',elgg_echo('USAGE_COMPLETE'));
				elseif($return == 'MESSAGE_REQUIRED')
					$return = 0;

				if($return!=0)
				{
					$query ="INSERT INTO ".$CONFIG->dbprefix."{$anatoaConfig->MasterTables['Message']}
		    	 	 				SET	CheckStatus = 'Failed Check',
		    	 	 					checkReasons = '$return' ,
		    	 	 					checkDate = NOW(),
		    	 	 					checkMode='Check Old Profile',
		    	 	 					ProfileID = {$profileID},
		    	 	 					MessageID=$id,
		    	 	 					TableName = '".$msgTableAlt."'
		    	 	 				ON DUPLICATE KEY UPDATE
		    	 	 					CheckStatus = 'Failed Check',
		    	 	 					checkReasons = '$return' ,
		    	 	 					checkDate = NOW(),
		    	 	 					checkMode='Check Old Profile'";
		    	 	$db->query( $query );
					$objDBModel->enterLog('Check Message',
										  'Check Old Profile',
										  $profileID,
										  $id,
										  $msgTableAlt,
										  addslashes(serialize($messageParams)),
										  $return);
					continue;
				}
			}
			elseif($return > $APIconfig->$varRejTh)
				{
					$fi++;
					$fraudulent =1;
				}

			if($return > 6.0)
			{
				$contents = '';
				$contents = $this->reportProfile($profileID,
												 'Message found to be fraudulent',
												 $APIconfig->Action,
												 'Check Old Profiles',
												 $id.':'.$msgTableAlt);
				if($contents == 'Error:Connection' || $contents == 'Error:APIKey' || $contents == 'Error:Processing' )
						return $contents;
				$profileReported = 1;
			}

			$objDBModel->updateWithSoapCheckResult($profileID,
												   $anatoaConfig->Tables['Message'][$i]['priKey'],
												   $id,
												   $msgTableAlt,
												   'Message',
												   $return,
												   $fraudulent,
												   $APIconfig->Action);
			$objDBModel->enterLog('Check Message',
								  'Check Old Profile',
								  $profileID,
								  $id,
								  $msgTableAlt,
								  addslashes(serialize($messageParams)),
								  $return);

			if($profileReported)
		  		return "1;1";
			}
		}

		return "1;$fp";
	}


	////////////////////////     CRON JOB      //////////////////////////////////////////////////////

	function cronJob()
	{
		global $CONFIG;
		$anatoaConfig = anatoaConfiguration::getInstance();
		$objDBModel = new dbModel();
		$soapclient = new anatoaSoapClient();
		$suspendDeleteReason = '';

		$APIconfig = $objDBModel->getConfig();
		$rejVar = $APIconfig->Rejection_Threshold.'Value';

		$arrAdminIds = $objDBModel->get_admin_list();

		if($APIconfig->cronRunning == 1 && $APIconfig->numberOfTimesFailed < 1)
		{
			// error_log('Anatoa cron script : Other instance of Anatoa cron script is still running......');
			$objDBModel->setConfig('numberOfTimesFailed',$APIconfig->numberOfTimesFailed+1);
			exit;
		}
		else
		{
			//error_log('Anatoa cron script : Anatoa cron script started at '.date('Y-m-d H:i:s'));
			$objDBModel->setConfig('cronRunning',1);
			$objDBModel->setConfig('numberOfTimesFailed',0);
		}

		$fp = 0;
		$fi = 0;
		$fm = 0;
		$exitOuterForLoop = 0;
		$errorConnectionThreshHold = 0;
		$errorResponseThreshHold = 10;
		$connectionFailure = 0;
		$errorResponse = 0;
		$ProfileUsageCompleted = 0;
		$MessageUsageCompleted = 0;
		$ImageUsageCompleted = 0;
		$connectionError = 0;
		$arrReportedProfileIDs = array();
		$installationDate = $APIconfig->AddedDate;

		if(!$soapclient->init())
		{
			error_log('Anatoa cron script : Unable to initialize Anatoa SOAP web service.....');
			$objDBModel->setConfig('cronRunning',0);
			return ;
		}

		if(empty($APIconfig->APIKey) || $APIconfig->keyChecked != 'Valid')
		{
			error_log('( Anatoa Cron Script -> checkAPIKey ) : Incorrect APIKey, Please configure your API Key.');
			$objDBModel->setConfig('cronRunning',0);
			return ;
		}

		$profile_master_table = $anatoaConfig->MasterTables['Profile'];
		$prefix_profile_master_table = $CONFIG->dbprefix.$profile_master_table;
		$arrMembers = $objDBModel->getMemberListForUpdating();

		if(!empty($arrMembers))
		foreach ($arrMembers as $memberObj)
		{
			$antoaCurrentProcess = '( Anatoa Cron Script -> checkProfile )';
			$p_tblName     = $anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['tblName'];
			$p_priKey      = $memberObj->{$anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['priKey']};
			$p_UserName    = $memberObj->{$anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['UserName']};
			$p_Email       = $memberObj->{$anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['Email']};
			$p_DateCreated = $memberObj->{$anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['DateCreated']};

			$query = "INSERT IGNORE INTO $prefix_profile_master_table SET
						UserName = '$p_UserName',
						Email = '$p_Email',
						ProfileID = $p_priKey,
						TableName = '$p_tblName'";
			insert_data( $query );

			if($APIconfig->Check_full_email == 'Yes')
			{
				$emailAddressHash = '';
				$emailAddress = $memberObj->email;
			}
			else
			{
				$emailAddressHash = md5($memberObj->email);
				$emailAddress = '';
			}

			$profileIPAddress = anatoaUtility::validateIpAddress($memberObj->IPAddress) ? $memberObj->IPAddress : '';
			$profileProxyIPAddress = anatoaUtility::validateIpAddress($memberObj->ProxyIP) ? $memberObj->ProxyIP : '';

			$profileParams = array(	'UserName'=>$p_UserName,
									'EmailHash'=>$emailAddressHash,
									'Email'=>$emailAddress,
									'IPAddress'=>$profileIPAddress,
									'ProxyIP'=>$profileProxyIPAddress
									);

			if($APIconfig->FirstName)
				$profileParams['FirstName'] = $objDBModel->getAdditionalAttri('FirstName',$p_priKey);
			if($APIconfig->LastName)
				$profileParams['LastName'] = $objDBModel->getAdditionalAttri('LastName',$p_priKey);
			if($APIconfig->Country)
				$profileParams['Country'] = $objDBModel->getAdditionalAttri('Country',$p_priKey);

			////////////////////////////////////////   Call WEBSERVICE VIA SOAP
			if( !$soapclient->callMethod( $APIconfig->APIKey, 'checkProfile', 'Profiles', array( 'Profile'=>$profileParams ), $returnValues ) )
			{
				error_log(" Anatoa cron script : $antoaCurrentProcess : [ Error Connection ] Unable to connect. ");
				$connectionError = 1;
				$objDBModel->setConfig('cronConnectionError',1);
				$objDBModel->setConfig('cronRunning',0);
				return ;
			}

			$return = $returnValues[0];

			$fraudulent = 0;
			$profileParams['APIKey'] = $APIconfig->APIKey;

			if(!is_numeric($return))
			{
				error_log(" Anatoa cron script : $antoaCurrentProcess : [ Error Response : $return ] Error in processing your request. ");
				if($return == 'USAGE_COMPLETE')
				{
					$ProfileUsageCompleted = 1;
					break;
				}
				if($errorResponse < $errorResponseThreshHold)
				{
					$errorResponse++;
					$query = "UPDATE $profile_master_table
								SET CheckStatus = 'Failed Check',
									checkReasons = '$return'
								WHERE TableName = '$p_tblName' AND ProfileID = $p_priKey";
					$db->query( $query );

					$objDBModel->enterLog('Check Profile',
										  'Auto Check : Cron Job',
										  $p_priKey,
										  $p_priKey,
										  $p_tblName,
										  addslashes(serialize($profileParams)),
										  $return);
					continue;
				}
				else
				{
					error_log(" Anatoa cron script : $antoaCurrentProcess : [ Error Response : $return ]. ");
					$objDBModel->setConfig('cronRunning',0);
					return ;
				}
			}
			elseif($return > $APIconfig->$rejVar)
			{
				$fp++;
				$fraudulent = 1;
				$suspendDeleteReason = 'Profile found to be fraudulent';
			}

			$extra = !empty($memberObj->IPAddress) ? 'WithIP' : '';

			if($return > 6.0)
			{
				$contents = '';
				$contents = $this->reportProfile($p_priKey,
												 'Profile found to be fraudulent',
												 $APIconfig->Action,
												 'Auto Check : Cron Job',$p_priKey.':'.$p_tblName);
				$arrReportedProfileIDs[] = $p_priKey;

				if($contents == 'Error:Connection' || $contents == 'Error:APIKey')
				{
					error_log(" Anatoa cron script : $antoaCurrentProcess : [ Error Response : Connection error ] Error while reporting profile for fraudulent profile found. ");
					$connectionError = 1;
					$objDBModel->setConfig('cronConnectionError',1);
					$objDBModel->setConfig('cronRunning',0);
					return ;
				}
			}

			$objDBModel->updateWithSoapCheckResult($p_priKey,
												   $anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['priKey'],
												   $p_priKey,
												   $p_tblName,
												   'Profile',
												   $return,
												   $fraudulent,
												   $APIconfig->Action,
												   $extra,$suspendDeleteReason);
			$objDBModel->enterLog('Check Profile',
								  'Auto Check : Cron Job',
								  $p_priKey,
								  $p_priKey,
								  $p_tblName,
								  addslashes(serialize($profileParams)),
								  $return);


		}

		//====================================================   Message Check  =================================================
		$objSubtype ='';
		foreach ($anatoaConfig->MessagesType as $objSubtype)
		{
			switch ($objSubtype)
			{
				case 'comments' : $Messages = $objDBModel->getUserComments(); break;
				case 'messages' :
				case 'blog'		:
				case 'thewire'	:
				default 		: $Messages = get_entities('object',$objSubtype);
			}

			$message_master_table = $anatoaConfig->MasterTables['Message'];
			$prefix_message_master_table = $CONFIG->dbprefix.$message_master_table;
			$query = "SELECT MessageID FROM $prefix_message_master_table
					WHERE ( CheckStatus!='Unchecked' OR ReportStatus != 'Unreported' ) AND TableName = 'Object - $objSubtype'";
			$result = get_data($query);
			$arrMsgIds = array();
			if(!empty($result))
			{	foreach ($result as $row)
					$arrMsgIds[] = $row->MessageID;
			}

			if(!empty($Messages))
			foreach ($Messages as $messgs)
			{
				if(in_array($messgs->guid,$arrMsgIds) || $messgs->time_created < strtotime($APIconfig->AddedDate) || in_array( $messgs->owner_guid,$arrAdminIds) )	continue; // || (in_array($messgs->title,$arrTitles) && in_array($messgs->description,$arrDesc))

				$message_sender = $profileID = $messgs->owner_guid;

				$antoaCurrentProcess = '( Anatoa Cron File -> checkMessage )';
				$msgData = $messgs->title.' '.$messgs->description;
			    $messageParams = array( 'Message'=>strip_tags(stripslashes($msgData)) );

				$message_id = $id =  $messgs->guid;
				$m_tblName = $msgTableAlt = "Object - $objSubtype";

				if($objSubtype == 'messages')
				{
					$msgTemp = array();
					$msgTemp = get_entities_from_metadata('fromId',$messgs->owner_guid,'object',$objSubtype);
					$ownerMesgsIds = array();
					if(!empty($msgTemp))
					{
						foreach ($msgTemp as $msg)
							$ownerMesgsIds[] = $msg->guid;
					}
					if(!in_array($messgs->guid,$ownerMesgsIds)) continue;
				}

				$query = "INSERT IGNORE INTO $prefix_message_master_table SET
							ProfileID = {$messgs->owner_guid},
							MessageID = {$messgs->guid},
							TableName = '$m_tblName'";
				insert_data($query);

				if( !$soapclient->callMethod( $APIconfig->APIKey, 'checkMessage', 'Messages', array( 'Message'=>$messageParams ), $returnValues ) )
				{
					error_log(" Anatoa cron script : $antoaCurrentProcess : [ Error Connection ] Unable to connect. ");
					$connectionError = 1;
					$objDBModel->setConfig('cronConnectionError',1);
					$objDBModel->setConfig('cronRunning',0);
					return ;
				}

				$return = $returnValues[0];
				$fraudulent = 0;
				$messageParams['APIKey'] = $APIconfig->APIKey;

				if(!is_numeric($return))
				{
					error_log(" Anatoa cron script : $antoaCurrentProcess : [ Error Response : $return ] Error in processing your request. ");

					if($return == 'USAGE_COMPLETE')
					{
						$MessageUsageCompleted = 1;
						//$exitOuterForLoop = 1;
						break;
					}
					if($errorResponse < $errorResponseThreshHold)
					{
						$errorResponse++;

						$query = "UPDATE $prefix_message_master_table
									SET CheckStatus = 'Failed Check',
									   checkReasons = '$return'
									WHERE ProfileID = $message_sender
									  AND MessageID = $message_id
									  AND TableName = '$m_tblName'";
						update_data($query);
						$objDBModel->enterLog('Check Message',
											  'Auto Check : Cron Job',
											  $message_sender,
											  $message_id,
											  $m_tblName,
											  addslashes(serialize($messageParams)),
											  $return);
						continue;
					}
					else
					{
						error_log(" Anatoa cron script : $antoaCurrentProcess : [ Error Response : $return ] ");
						$objDBModel->setConfig('cronRunning',0);
						return ;
					}
				}
				elseif($return > $APIconfig->$rejVar)
				{
					$fm++;
					$fraudulent = 1;
				}

				if(($return > 6.0) && (!in_array($message_sender, $arrReportedProfileIDs)))
				{
					$contents = $this->reportProfile($message_sender,
													 'Message found to be fraudulent',
													 $APIconfig->Action,
													 'Auto Check : Cron Job',
													 $message_id.':'.$m_tblName);

					if($contents == 'Error:Connection' || $contents == 'Error:APIKey')
					{
						error_log(" Anatoa cron script : $antoaCurrentProcess : [ Error Response : Connection error ] Error while reporting profile for fraudulent message sender. ");
						$connectionError = 1;
						$objDBModel->setConfig('cronConnectionError',1);
						$objDBModel->setConfig('cronRunning',0);
						return ;
					}

					$arrReportedProfileIDs[] = $message_sender;
				}

				$objDBModel->updateWithSoapCheckResult($message_sender,
													   $m_priKey,
													   $message_id,
													   $m_tblName,
													   'Message',
													   $return,
													   $fraudulent,
													   $APIconfig->Action);
				$objDBModel->enterLog('Check Message',
				                      'Auto Check : Cron Job',
									  $message_sender,
									  $message_id,
									  $m_tblName,
									  addslashes(serialize($messageParams)),
									  $return);
			}
		}

		//////////////////////////////////////   Image Scan Start /////////////////////////////

		foreach ($anatoaConfig->ImagesType as $objSubtype)
		{
			if($objSubtype == 'profileImage')
				$Images = $objDBModel->getProfileImage();
			elseif($objSubtype == 'image')
				$Images = get_entities('object','image');

			$image_master_table = $anatoaConfig->MasterTables['Image'];
			$prefix_image_master_table = $CONFIG->dbprefix.$image_master_table;

			$query = "SELECT ImageID FROM $prefix_image_master_table
						WHERE ( CheckStatus!='Unchecked' OR ReportStatus != 'Unreported' ) AND TableName = 'Object - $objSubtype'";
			$result = get_data($query);
			$arrImageIds = array();
			if(!empty($result))
			{
				foreach ($result as $row)
					$arrImageIds[] = $row->ImageID;
			}

			if(!empty($Images))
			foreach ($Images as $tempImg)
			{
				if( $objSubtype == 'profileImage' && ($tempImg->time_created < strtotime($APIconfig->CronRunnedAt) || $tempImg->time_created < strtotime($APIconfig->AddedDate) || in_array( $tempImg->owner_guid,$arrAdminIds) ))
					continue;
				elseif( $objSubtype != 'profileImage' && ( in_array($tempImg->guid,$arrImageIds) || $tempImg->time_created < strtotime($APIconfig->AddedDate) || in_array( $tempImg->owner_guid,$arrAdminIds) ))
				  	continue;

				$antoaCurrentProcess = '( Anatoa Cron File -> Images )';
				$image_id = $tempImg->guid;
				$image_member_id = $tempImg->owner_guid;
				$file_name = $objSubtype == 'image' ? $tempImg->filename : "profile/". $tempImg->username ."master.jpg";
				$i_tblName = "Object - $objSubtype";

				$query = "INSERT IGNORE INTO $prefix_image_master_table (ProfileID, ImageID, TableName)
							VALUES ($image_member_id, $image_id, '$i_tblName')";
				insert_data($query);

				$readfile = new ElggFile();
				$readfile->owner_guid = $tempImg->owner_guid;
				$readfile->setFilename($file_name);
				$fileContent = $contents = $readfile->grabFile();

				if(!empty($fileContent))
				{

					$imageHash = md5($fileContent);
					$imageParams = array( 'ImageHash'=>$imageHash );

					if( !$soapclient->callMethod( $APIconfig->APIKey, 'checkImage', 'Images', array( 'Image'=>$imageParams ), $returnValues ) )
					{

						error_log(" Anatoa cron script : $antoaCurrentProcess : [ Error Connection ] Unable to connect to anatoa.com. ");
						$connectionError = 1;
						$objDBModel->setConfig('cronConnectionError',1);
						$objDBModel->setConfig('cronRunning',0);
						return ;
					}

					$return = $returnValues[0];
					$fraudulent = 0;
					$imageParams['APIKey'] = $APIconfig->APIKey;

					if(!is_numeric($return))
					{
						error_log(" Anatoa cron script : $antoaCurrentProcess : [ Error Response : $return ] Error in processing your request. ");

						if($return == 'USAGE_COMPLETE')
						{
							$ImageUsageCompleted = 1;
							break;
						}
						if($errorResponse < $errorResponseThreshHold)
						{
							$errorResponse++;
							$query = "UPDATE $prefix_image_master_table
							 			SET CheckStatus = 'Failed Check',
										    checkReasons = '$return'
										WHERE ProfileID = $image_member_id AND ImageID = $image_id AND TableName = '$i_tblName'";
							update_data($query);

							$objDBModel->enterLog('Check Image',
												  'Auto Check : Cron Job',
												  $image_member_id,
												  $image_id,
												  $i_tblName,
												  addslashes(serialize($imageParams)),
												  $return);
							continue;
						}
						else
						{
							error_log(" Anatoa cron script : $antoaCurrentProcess : [ Error Response : $return ] ");
							$objDBModel->setConfig('cronRunning',0);
							return ;
						}
					}
					elseif($return > $APIconfig->$rejVar)
					{
						$fi++;
						$fraudulent =1;
					}

					if(($return[0] > 6.0) && (!in_array($image_member_id, $arrReportedProfileIDs)))
					{
						$contents = '';
						$contents = $this->reportProfile($image_member_id,
														 'Image found to be fraudulent',
														 $APIconfig->Action,
														 'Auto Check : Cron Job',
														 $image_id.':'.$i_tblName);

						if($contents == 'Error:Connection' || $contents == 'Error:APIKey')
						{
							error_log(" Anatoa cron script : $antoaCurrentProcess : [ Error Response : Connection error ] Error while reporting profile for fraudulent image. ");
							$connectionError = 1;
							$objDBModel->setConfig('cronConnectionError',1);
							$objDBModel->setConfig('cronRunning',0);
							return ;
						}

						$arrReportedProfileIDs[] = $image_member_id;
					}

					$objDBModel->updateWithSoapCheckResult($image_member_id,
														   $i_priKey,
														   $image_id,
														   $i_tblName,
														   'Image',
														   $return,
														   $fraudulent,
														   $APIconfig->Action,$file_name);
					$objDBModel->enterLog('Check Image',
										  'Auto Check : Cron Job',
										  $image_member_id,
										  $image_id,
										  $i_tblName,
										  addslashes(serialize($imageParams)),
										  $return);
				}
				else
				{
					$query = "UPDATE $prefix_image_master_table
								SET CheckStatus = 'Failed Check',
								checkReasons = 'File Not Found'
							   WHERE TableName = '$i_tblName' AND ImageID = $image_id";
					update_data($query);
					error_log(" Anatoa cron script : $antoaCurrentProcess : File Content Not Found ".$file_name);
				}
			}
		}

		///////////// Image Scanned finished  //////////////////////////////

		$usageTypes = array('Profile', 'Message', 'Image');
		$lastLogCleared  = strtotime($APIconfig->lastLogCleared);

		if($lastLogCleared < strtotime('-15 days'))
		{
			delete_data("DELETE FROM ".$CONFIG->dbprefix."anatoa_transactionlog
							WHERE (TransactionType = 'Check Image' OR TransactionType = 'Check Message')
							  AND LogDate < '".date('Y-m-d H:i:s',strtotime('-1 Month'))."'");
			$objDBModel->setConfig('lastLogCleared',date('Y-m-d H:i:s'));
		}

		if($connectionError)
			$objDBModel->setConfig('Error',"< Anatoa Cron Job > : Currently unable to connect to <a href='http://www.anatoa.com' target='_blank'>Anatoa.com</a> - queueing requests for later retry.");
		else
			$objDBModel->setConfig('Error','');

		foreach ($usageTypes as $type)
		{
			$varName = $type.'UsageCompleted';
			if($$varName)
				$objDBModel->setConfig("Check{$type}LimitReached",1);
			else
				$objDBModel->setConfig("Check{$type}LimitReached",0);
		}


		$objDBModel->setConfig('CronRunnedAt',date('Y-m-d H:i:s'));
		$objDBModel->setConfig('cronRunning',0);
		//error_log("Anatoa cron script : Anatoa Script for cron finished........");

		exit;
	}


}