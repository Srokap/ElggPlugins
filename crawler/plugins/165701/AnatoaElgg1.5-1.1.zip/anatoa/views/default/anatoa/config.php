<div id="dhtmltooltip" style="position: absolute;text-align: justify;width: 150px;border: 1px solid black;padding: 4px;background-color: lightGray;visibility: hidden;z-index: 100;"></div>
<script type="text/javascript">
/* <![CDATA[ */
function verifyFormDate(form1)
{
	if(form1.APIKey.value == '')
	{
		alert('APIKey cannot be blank');
		form1.APIKey.focus();
		return false;
	}
	else return true;
}
/* ]]> */
</script>
<script type="text/javascript" language="javascript" src="../../mod/anatoa/js/tooltip.js"> </script>
<div class="contentWrapper" >
  <div style="margin:0px 5px 0px 5px;">
    <div style="text-align:justify"> <?php echo elgg_echo('configIntro'); ?><br> </div><br>
	<div align="center"><font color="Green"><?php echo $vars['success_msg']; ?></font><font color="Red"><?php echo $vars['error_msg']; ?></font></div>
	<form name=form1 action="" method="POST" onsubmit="return verifyFormDate(this);">
		<table border="0" width="100%">
			<tr>
			  <td width="30%"><div style="margin-top:15px" align="left">API Key</div></td>
			  <td width="70%"><input type="text" name="APIKey" value="<?php echo $vars['APIKey']; ?>" size="45" class="input"> <input type="submit" class=formbutton name="testAPI" value="Test API Key">
			  </td>
			</tr>
			<tr >
			  <td width="30%" align="right"  style="padding:3px">Profile Rejection Threshold</td>
			  <td width="70%"><?php echo $vars['profileRejDD'];?> <img src='../../mod/anatoa/images/info.gif' onMouseover="ddrivetip('<?php echo elgg_echo('ProfileRejectionHelptip') ?>','#eeeeee', 300)" onMouseout="hideddrivetip()" border=0  align='absmiddle' >
			  </td>
			</tr>
			<tr>
			  <td width="30%" align="right"  style="padding:3px">Action</td>
			  <td width="70%"><?php echo $vars['actionDD']; ?> <img src='../../mod/anatoa/images/info.gif' onMouseover="ddrivetip('<?php echo elgg_echo('ActionHelptip') ?>','#eeeeee', 300)" onMouseout="hideddrivetip()" border=0  align='absmiddle' >
		  		</td>
			</tr>
			<tr>
			  <td width="30%" align="right"  style="padding:3px">Check full email address</td>
			  <td width="70%"><?php echo $vars['checkEmailDD']; ?> <img src='../../mod/anatoa/images/info.gif' onMouseover="ddrivetip('<?php echo elgg_echo('FullEmailHelptip') ?>','#eeeeee', 300)" onMouseout="hideddrivetip()" border=0  align='absmiddle' >
				</td>
			</tr>
			<tr>
			  <td colspan="2" align="center"> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;   &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp;
			  <input type="submit" name="Save" value="Save" class=formbutton > &nbsp;  <?php echo $vars['cancelButton']; ?>
			  </td>
			</tr>
		</table>
	</form>
  </div>
</div>

<div class="contentWrapper">
  <h2> Map Profile Fields </h2>
  <div style="margin:0px 5px 0px 5px;"> <br><div style="text-align:justify"> <?php echo elgg_echo('mapIntro'); ?> </div><br>
  <div align="center"><font color="Green"><?php echo $vars['success_msg2']; ?></font><font color="Red"><?php echo $vars['error_msg2']; ?></font></div>
	<form name=form2 action="" method="POST">
		<table border="0" width="100%" >
			<tr>
			  <td width="30%" align="right" style="padding:3px"> First Name </td>
			  <td width="70%"> <?php echo $vars['firstNameField']; ?>	</td>
			</tr>
			<tr>
			  <td width="30%" align="right" style="padding:3px"> Last Name</td>
			  <td width="70%"> <?php echo $vars['lastNameField']; ?>	</td>
			</tr>
			<tr>
			  <td width="30%" align="right" style="padding:3px"> Country</td>
			  <td width="70%"> <?php echo $vars['countryField']; ?>	</td>
			</tr>
			<tr>
			  <td colspan="2" align="left"> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;   &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp;
			  <input type="submit" name="Save2" value="Save" class=formbutton > &nbsp;  <?php echo $vars['cancelButton']; ?>
			  </td>
			</tr>
		</table>
	</form>
  </div>
</div>