<style>
.msg { color:green;}
.error {color:red;}
</style>
<div class="contentWrapper" >
  <div style="margin:0px 0px 0px 0px;">
  <div style="text-align:justify"> <?php echo elgg_echo('profileArchiveIntro'); ?> <br/> <br/></div>
  <?php echo $vars['msg'] ?>
  <form name=form1 action="" method="POST">
	<table width="100%" cellspacing="2" cellpadding="3" border="0">
		<tr  >
		 <th style="background:#F0F0F0 none repeat scroll 0 0;border:1px solid #DDD;border-bottom:1px solid #444;color:#666666;text-align:center;">&nbsp;</th>
	    <?php
	    	foreach ( $vars['fieldsName'] as $key => $field)
	    	{ ?>
	    		<th class="tableHeader"> <div align="center">
			 		<?php
			 			if (!($key=='Image' || $key =='Message'))
			 			{  ?>
			 				 <a href="?section=profileArchive&type=<?php echo $vars['type']; ?>&sortby=<?php echo $field ?>&seq=<?php echo $vars['newSeq'] ?>&offset=<?php echo $vars['offset']; ?>&limit=<?php echo $vars['limit']; ?>" > <?php echo $key ?> </a>
			 				 <?php
			 			}
			 			else { echo '<a href="#">'.$key.'</a>'; }
			 		  ?>
			 	  </div>
			 </th>
	    	<?
	    	}
		?>
		</tr>
		<?php if($vars['count']) foreach ($vars['dataRows'] as $row) { ?>
			<tr >
			<td align="center" class="tableCol"><input type="checkbox" name="txtchk[]" value="<?php echo $row->guid; ?>"> </td>
			<?php foreach ( $vars['fieldsName'] as $key => $field)
			{
				$temp = explode('.',$field); ?>
			 	<td  align="center" class="tableCol"> <?php
			 	if( $key == 'Result')
			 	{
			 		if ($row->Status == 'Unconfirmed') echo $t = ($row->CheckStatus == 'Checked') ? 'Pass' : 'Failed Check';
				 	elseif ($row->Status == 'Deleted') echo 'Possible Fraud - Deleted';
				 	elseif ($row->Status == 'Blocked') echo 'Possible Fraud - Blocked';
				 	elseif ($row->Status == 'Restored') echo 'Possible Fraud - Restored';
				 }
			 	elseif ($key == 'UserName')
			 		echo ($row->username) ? "<a href='?section=userprofiledetail&profileId={$row->guid}' >{$row->username}</a>" : "<a href='#' >{$row->AnatoaUserName}</a>";
			 	elseif ($key == 'Email')
			 		echo $row->email ? "<a href='mailto:{$row->email}'>{$row->email}</a>" : "<a href='mailto:{$row->AnatoaEmail}'>{$row->AnatoaEmail}</a>";
			 	elseif ($key == 'Image')
			 		echo "<div align='center'><a href='' target=_blank><img src='' longdesc='image' border='0'/></a></div>";
			 	elseif ($key == 'Date')
			 		echo $row->LogDate;
			 	elseif ($key == 'Message')
			 	{
			 		$values = unserialize($row->Parameters);
			 		echo $values['Message'];
			 	}
			 	else
			 		echo $row->$temp[1]
			 	 ?>
			 	</td>
			<?php } ?>
			</tr>
		<?php
		}
		if($vars['count'])
		 	echo "<tfoot style='border-top:1px solid #999999;text-align:center;'><tr ><td colspan=".(count($vars['fieldsName'])+1)." align='left' style='border-top:1px solid #999999;' ><b>".elgg_view("navigation/pagination",
		 																array('baseurl' => $vars['baseurl'],
																				'offset' => $vars['offset'],
																				'count' => $vars['count'],
																				'limit' => $vars['limit'],
																				'viewtype' => '',
																			)).
													"</b></tr></tfoot>";
		else echo "<tr ><td colspan=".(count($vars['fieldsName'])+1)." align='center' style='border-top:1px solid #999999;' ><div align=center><b >No Data Found</b></div></td></tr>";

		?>
	</table><br />
		<?php
		if($vars['count'])
		  { ?>
		     <div align="center">
		     		<input type="submit" name="Restore" value="Restore" class="formbutton"/>
			  		<input type="submit" name="Cancel" value="Cancel" class="formbutton"/>
			 </div>
		<? }
		  else
		   echo "<div align=center> <input type=\"submit\" name=\"Cancel\" value=\"Cancel\" class=\"formbutton\"/> </div>";
		 ?>
		 </form>
   </div>
</div>