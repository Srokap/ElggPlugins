<div class="contentWrapper">
  <div style="margin:0px 5px 0px 5px;">
  <a href='http://anatoa.com'><img src='../../mod/anatoa/images/anatoa.gif' border=0 ></a><br/>
    <div style="text-align:justify"> <br>  <?php echo elgg_echo('anatoa:intro'); ?> <br/> <br/></div>
	<h3 ><?php echo elgg_echo('last24hrLabel'); ?></h3>
	<div >
	   <?php echo elgg_echo('profiles'); ?> <?php echo elgg_echo('checked'); ?> : <?php echo $vars['fraudulentStat']['CheckedProfile']; ?> ( <?php echo $vars['fraudulentStat']['FraudulentProfile']; ?> <?php echo elgg_echo('possibleFraudDect'); ?>)<br>
	   <?php echo elgg_echo('images'); ?> <?php echo elgg_echo('checked'); ?> : <?php echo $vars['fraudulentStat']['CheckedImage']; ?> ( <?php echo $vars['fraudulentStat']['FraudulentImage']; ?> <?php echo elgg_echo('possibleFraudDect'); ?>)<br>
	   <?php echo elgg_echo('messages'); ?> <?php echo elgg_echo('checked'); ?> : <?php echo $vars['fraudulentStat']['CheckedMessage']; ?> ( <?php echo $vars['fraudulentStat']['FraudulentMessage']; ?> <?php echo elgg_echo('possibleFraudDect'); ?>)<br>
	   <?php echo elgg_echo('profiles'); ?> <?php echo elgg_echo('reported'); ?> : <?php echo $vars['fraudulentStat']['ReportedProfiles']; ?><br><br><br>
	</div>
	<div >
		<div><b><a href="?section=config" ><?php echo elgg_echo('configTitle'); ?></a></b></div>
		<div ><?php echo elgg_echo('configDesc'); ?></div>
	</div><br>
	<div >
		<div ><b><a href="?section=log" ><?php echo elgg_echo('logTitle'); ?></a></b></div>
		<div ><?php echo elgg_echo('logDesc'); ?></div>
	</div><br>
	<div >
		<div><b><a href="?section=checkProfile" ><?php echo elgg_echo('checkProfileTitle'); ?></a></b></div>
		<div ><?php echo elgg_echo('checkProfileDesc'); ?></div>
	</div><br>
	<div >
		<div><b><a href="?section=reportProfiles" ><?php echo elgg_echo('reportProfileTitle'); ?></a></b></div>
		<div ><?php echo elgg_echo('reportProfileDesc'); ?></div>
	</div><br/>
	<div><?php
	    if(!empty($vars['updateInfo'])){ ?>
		<br/><b>Update Information </b>: <?php echo $vars['updateInfo'] ?> <br> <? }
		if(@count($vars['fraudulentStat']['Notify']))
		{	echo '<b style="color:red;">Notice : </b>';
			foreach ($vars['fraudulentStat']['Notify'] as $item)
			{
				echo "<p>$item</p>";
			}
		} ?>

	</div>
  </div>

</div>