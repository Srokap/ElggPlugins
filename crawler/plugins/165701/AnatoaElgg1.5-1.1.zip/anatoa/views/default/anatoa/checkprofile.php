<script type="text/javascript" language="javascript">
	var APIKeyNotConfigured = "<?php echo elgg_echo('APIKEY_NOT_CONFIGURED'); ?>";
	var ConnectionError = "<?php echo elgg_echo('CONNECTION_ERROR'); ?>";
	var noResponse = "<?php echo elgg_echo('NO_RESPONSE'); ?>";
	var errorResponse = "<?php echo elgg_echo('SERVER_ERROR_RESPONSE'); ?>";
	var Processing_Error = "<?php echo elgg_echo('Processing_Error'); ?>";
	var noProfileBlank = "<?php echo elgg_echo('noProfileBlank'); ?>";
	var invalidnoProfile = "<?php echo elgg_echo('invalidnoProfile'); ?>";
	var invalidnum = "<?php echo elgg_echo('invalidnum'); ?>";

	var profileIDs = new Array(<?php echo $vars['strProfileIds'] ?>);
	var totalItems = <?php echo $vars['jsCount'];?> ;
	var ProfileToScan = <?php echo $vars['jsCount'];?> ;
	var chkProfileUrl = '?section=checkProfile';

	var error = 0;
	var debugMsg ='';
	var fProfile = 0;
	var ProfilesScanned = 0;
	var runStatus = 0; 
	var temp = new Array();
	var scanned = new Array();
	var foundFraud = new Array();
	var percentageCompleted=1;
	var i=0;
</script>
<style >
.elggButtonEnabled {
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #ffffff;
	background:#4690d6;
	border: 1px solid #4690d6;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	width: auto;
	height: 25px;
	padding: 2px 6px 2px 6px;
	margin:10px 0 10px 0;
	cursor: pointer;
}
.elggButtonEnabled:hover{
	background:#0054A7 none repeat scroll 0 0;
	border-color:#0054A7;
}
.elggButtonDisabled {
	font: 12px/100% Arial, Helvetica, sans-serif;
	border: 1px solid #4690d6;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	width: auto;
	height: 25px;
	padding: 2px 6px 2px 6px;
	margin:10px 0 10px 0;
}
.mgs { color:green;}
.error {color:red;}
</style>
<script type="text/javascript" language="javascript" src="../../mod/anatoa/js/checkProfile.js" ></script>
<div class="contentWrapper" >
  <div style="margin:0px 0px 0px 0px;">
    <div style="text-align:justify"> <br><?php echo $vars['checkProfileIntro']; ?></div> <br>
    <div style="text-align:justify"> <?php echo $vars['extraMsg']; ?> </div> <br>
	<div align="center" ><font color="Green"><?php echo $vars['success_msg']; ?></font><font color="Red"><?php echo $vars['error_msg']; ?></font></div>
	<form id="form1" name="form1" method="post" action="" onsubmit="return validateForm(this)">
		<table border="0" cellpadding="2" width="100%">
			<tr>
				<td align="right">Recheck profiles with collected IP addresses</td>
				<td align="left" width="50%"><input type="checkbox" name="Recheck" value="Recheck" <?php echo $vars['checked']; ?> /></td>
			</tr>
			<tr>
				<td align="right">Maximum number of profiles to be checked</td>
				<td align="left" width="50%"><input type="text" name="NoProfileCheck" id="textfield" value="<?php echo $vars['NoProfileCheck']; ?>" /><?php echo $vars['star']; ?></td>
			</tr>
			<tr>
				<td colspan="2" align="center">
					<input type="submit"  name="check" id="startbgProcbutton" class="elggButtonDisabled" value="Prepare for background processing" />
				</td>
			</tr>
		</table>
	</form>
<br>
</div>
</div>
<?php if($vars['totalProfiles'] > 0) { ?>
<div class="contentWrapper" >
<div align="left" id='anatoaMsg' style="color:red;" > </div>
<table border="0" width="100%" >
	<tr>
		<td  align="center">
		<table border="0">
			<tr>
				<td>Total number of Profiles to Check :</td>
				<td><b><?php echo $vars['totalProfiles']; ?></b></td>
			</tr>
		</table>
		</td>
		<td width="8" bgcolor="#333333" style="width: 0px;"></td>
		<td  align="center">
		<table border="0">
			<tr>
				<td>Number of Fraudulent Profiles found :</td>
				<td><b style="color: red;"><div id='fP'>0</div></b></td>
			</tr>
		</table>
		</td>
	</tr>
</table>
<br>
<div align="center" align="center" >
   <div align="center">
		<div style="width: 95%; height: 20px; background-color: #CCCCCC; margin-left:10px;" align="left">
			<div id='divPercent' style="width: 0.5%; height: 20px; background-color: #009966; text-align: center; vertical-align: middle;">
				<div id='percentageStatus' align="center" style="vertical-align: middle; color:white;"></div>
			</div>
		</div>
		<div style="width: 90%;margin-left:20px;" align="left" id='noOfScanned'>(<span id='fPComplete'>0</span> of <?php echo $vars['totalProfiles']; ?>) profiles scanned</div>
	</div>
	<div style="width: 100%;" align="center"><br>
		<input type="button" name="Start"  id='startButton' value="Start" style="width: 100px;" onclick="Start();" class="elggButtonEnabled"> &nbsp;&nbsp;
		<input type="button" name="pause" id='pauseButton' value="Pause" style="width: 100px" onclick="Pause();" disabled class="elggButtonDisabled" > &nbsp;&nbsp;
	</div>
</div>
<div id='log' style="display:none;" ></div><br>
</div>
<?php } ?>
