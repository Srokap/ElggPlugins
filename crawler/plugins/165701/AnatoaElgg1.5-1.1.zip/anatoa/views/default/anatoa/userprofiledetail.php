<div class="contentWrapper" >
  <div style="margin:0px 0px 0px 0px;">
		<TABLE >
		 <tr>
		 	<td>UserName</td>
		 	<td>: <?php echo $vars['user']->username; ?></td>
		 </tr>
		 <tr>
		 	<td>Email</td>
		 	<td>: <?php echo $vars['user']->email; ?></td>
		 </tr>
		 <tr>
		 	<td>Name</td>
		 	<td>: <?php echo $vars['user']->name; ?></td>
		 </tr>
		 <tr>
		 	<td>Registration Date</td>
		 	<td>: <?php	echo $vars['user']->time_created ? date( 'F j, Y, g:i a' ,$vars['user']->time_created) : ' -- '; ?></td>
		 </tr>
		<tr>
		 	<td>Last Login :</td>
		 	<td>: <?php echo $vars['user']->last_login ? date( 'F j, Y, g:i a' ,$vars['user']->last_login) : ' -- '; ?></td>
		 </tr>
		 <?php if(!empty($vars['reason']->Reason) || !empty($vars['reason']->reportReasons))
		 { ?>
		 <tr>
		 	<td> <?php echo $vars['reason']->Reason ? 'Reason for blocking/deleting' : 'Reason for reporting';?></td>
		 	<td>: <?php echo $vars['reason']->Reason ? $vars['reason']->Reason : $vars['reason']->reportReasons; ?></td>
		 </tr>
		 <? } ?>
		</TABLE>
  </div>
</div>
<?php if(!empty($vars['messages']))  { ?>
<div class="contentWrapper" >
<H2>User Messages </H2>
  <div style="margin:0px 0px 0px 0px;"> <br>
  <table width="100%" cellspacing="2" cellpadding="3" border="0">
    <tr>
    	<th class="tableHeader"> <div align="center"> Title </div> </th>
    	<th class="tableHeader"> <div align="center"> Body </div> </th>
    </tr>
		<?php
		foreach ($vars['messages'] as $msg)
		{ ?><tr >
				<td class="tableCol"> <?php echo $msg->title;?></td>
				<td class="tableCol"> <?php echo $msg->description;?></td>
			</tr>
<?		}
		?>
		<tr><td colspan=4 align='left' style='border-top:1px solid #999999;' > &nbsp; </td> </tr>
	</TABLE>
  </div>
</div>
<?php } if(!(empty($vars['images']) && empty($vars['imageUrl']))) { ?>
<div class="contentWrapper" >
<H2>User Images </H2>
  <div style="margin:0px 0px 0px 0px;"> <br>
      <?php if(!empty($vars['imageUrl'])) { ?>
  		<a href='<?php echo $vars['imageUrl'] ?>' target=_blank><img src='<?php echo $vars['imageUrl'] ?>' longdesc='image' border='0' width="150px" height="150px"/></a> &nbsp; &nbsp; &nbsp; <? } ?>
		<?php
		if(!empty($vars['images']))
		foreach ($vars['images'] as $image)
		{ ?>
			<a href='?section=showimage&imageId=<?php echo $image->guid; ?>&size=large' target=_blank><img src='?section=showimage&imageId=<?php echo $image->guid; ?>&size=small' longdesc='image' border='0'/></a> &nbsp; &nbsp; &nbsp;
<?		}
		?>
  </div>
</div> <? } ?>