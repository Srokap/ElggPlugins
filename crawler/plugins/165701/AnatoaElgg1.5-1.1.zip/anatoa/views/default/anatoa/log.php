<?php
	 //type
	 $type = $vars['type'];
	 //set the url
	 $url = $vars['url'] . "pg/anatoa/?section=log&type=";
	 $ProfileClass = $ImageClass = $MessageClass = '';
	 ${$type.'Class'} = "class = 'selected'";
?>
<div class="contentWrapper" >
  <div style="margin:0px 0px 0px 0px;">
	<div id="elgg_horizontal_tabbed_nav">
	<ul>
		<li <?php echo $ProfileClass ?>><a href="<?php echo $url; ?>Profile"><?php echo elgg_echo('log:Profile'); ?></a></li>
		<li <?php echo $ImageClass ?>><a href="<?php echo $url; ?>Image"><?php echo elgg_echo('log:Image'); ?></a></li>
		<li <?php echo $MessageClass ?>><a href="<?php echo $url; ?>Message"><?php echo elgg_echo('log:Message'); ?></a></li>
	</ul>
	</div><br>
	<table width="100%" cellspacing="2" cellpadding="3" border="0">
		<tr  >
	    <?php
	    	foreach ( $vars['fieldsName'] as $key => $field)
	    	{ ?>
	    		<th class="tableHeader"> <div align="center">
			 		<?php
			 			if (!($key=='Image' || $key =='Message'))
			 			{  ?>
			 				 <a href="?section=log&type=<?php echo $vars['type']; ?>&sortby=<?php echo $field ?>&seq=<?php echo $vars['newSeq'] ?>&offset=<?php echo $vars['offset']; ?>&limit=<?php echo $vars['limit']; ?>" > <?php echo $key ?> </a>
			 				 <?php
			 			}
			 			else { echo '<a href="#">'.$key.'</a>'; }
			 		  ?>
			 	  </div>
			 </th>
	    	<?
	    	}
		?>
		</tr>
		<?php if($vars['count']) foreach ($vars['dataRows'] as $row) { ?>
			<tr >
			<?php foreach ( $vars['fieldsName'] as $key => $field)
			{
				$temp = explode('.',$field); ?>
			 	<td align="center" class="tableCol" > <?php
			 	if( $key == 'Result')
			 	{
			 		if ($row->Status == 'Unconfirmed') echo $t = ($row->CheckStatus == 'Checked') ? 'Pass' : 'Failed Check';
				 	elseif ($row->Status == 'Deleted') echo 'Possible Fraud - Deleted';
				 	elseif ($row->Status == 'Blocked') echo 'Possible Fraud - Blocked';
				 	elseif ($row->Status == 'Restored') echo 'Possible Fraud - Restored';
				 }
			 	elseif ($key == 'UserName')
			 		echo ($row->username) ? "<a href='?section=userprofiledetail&profileId={$row->MemberId}' >{$row->username}</a>" : "<a href='?section=userprofiledetail&profileId={$row->MemberId}' >{$row->AnatoaUserName}</a>";
			 	elseif ($key == 'Email')
			 		echo $row->email ? "<a href='mailto:{$row->email}'>{$row->email}</a>" : "<a href='mailto:{$row->AnatoaEmail}'>{$row->AnatoaEmail}</a>";
			 	elseif ($key == 'Image')
			 	{
			 		if(strpos($row->TableName,'profileImage') === false)
			 			echo "<div align='center'><a href='?section=showimage&imageId=".urlencode($row->ImageId)."&size=large' target=_blank><img src='?section=showimage&imageId=".urlencode($row->ImageId)."&size=small' longdesc='image' border='0' width=100 height=100/></a></div>";
			 		else echo "<div align='center'><a href='?section=showimage&profileId=".urlencode($row->MemberId)."' target=_blank><img src='?section=showimage&profileId=".urlencode($row->MemberId)."' longdesc='image' border='0' width=100 height=100/></a></div>";
			 	}
			 	elseif ($key == 'Date')
			 		echo $row->LogDate;
			 	elseif ($key == 'Message')
			 	{
			 		$values = unserialize($row->Parameters);
			 		echo $values['Message'];
			 	}
			 	else
			 		echo $row->$temp[1]
			 	 ?>
			 	</td>
			<?php } ?>
			</tr>
		<?php
		}
		if($vars['count'])
		 	echo "<tfoot style='border-top:1px solid #999999;text-align:center;'><tr ><td colspan=".count($vars['fieldsName'])." align='left' style='border-top:1px solid #999999;' ><b>".elgg_view("navigation/pagination",
		 																array('baseurl' => $vars['baseurl'],
																				'offset' => $vars['offset'],
																				'count' => $vars['count'],
																				'limit' => $vars['limit'],
																				'viewtype' => '',
																			)).
													"</b></tr></tfoot>";
		else echo "<tr ><td colspan=".count($vars['fieldsName'])." align='center' style='border-top:1px solid #999999;' ><div align=center><b >No Data Found</b></div></td></tr>";
		?>
	</table>

   </div>
</div>