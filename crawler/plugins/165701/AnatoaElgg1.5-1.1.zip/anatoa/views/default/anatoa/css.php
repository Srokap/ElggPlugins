<?php

	/**
	 * Anatoa CSS
	 *
	 * @package Anatoa
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License Version 2
	 * @author anatoa.com
	 * @copyright Univalence Ltd. 2009-2010
	 * @link http://www.anatoa.com/
	 */

?>

.tableHeader
{
	background:#F0F0F0 none repeat scroll 0 0;
	border:1px solid #DDD;
	border-bottom:1px solid #444;
	color:#666666;
	text-align:center;
}
.tableCol
{
	border-left:1px solid #EFEFEF;
	border-right:1px solid #EFEFEF;
	padding:1px;
	text-align:center;
}
