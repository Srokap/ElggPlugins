<?php

  $english = array(
	'anatoa' => 'Anatoa',
	'anatoa:linkname' => 'Anatoa',
	'anatoa:intro' => "Anatoa is a web service for collaborative profile fraud protection. Sign up for a free account at <a href='http://www.anatoa.com' target=_blank>Anatoa.com</a> in order to start using the plugin and take advantage of up to the minute fraud reports from all our participating websites. The plugin will automatically ban profiles registered by fraudsters and criminals attempting to approach your legitimate members. It will also monitor the activity of members and take immediate action if fraudulent actions are detected.",
	'FRAUDULENT_LOGOUT' =>  ' Your user profile is pending investigation.<br> You have been logged out.',

	// for Anatoa main page
	'mainTitle' => '',
	'intro' => "Anatoa is a web service for collaborative profile fraud protection. Sign up for a free account at <a href='http://www.anatoa.com' target=_blank>Anatoa.com</a> in order to start using the plugin and take advantage of up to the minute fraud reports from all our participating websites. The plugin will automatically ban profiles registered by fraudsters and criminals attempting to approach your legitimate members. It will also monitor the activity of members and take immediate action if fraudulent actions are detected.",
	'last24hrLabel' => 'Last 24 hour statistics',
	'possibleFraudDect'=>'possible fraud detections',
	'checked' => 'checked',
	'reported' => 'reported',
	'profiles' => 'Profiles',
	'images' => 'Images',
	'messages' => 'Messages',
	'configTitle' => 'Configuration',
	'logTitle' => 'Fraud Detection Log',
	'profileArchiveTitle' => 'Deleted Profile Archive',
	'checkProfileTitle' => 'Check Old Profiles',
	'reportProfileTitle' => 'Report User Profiles',
	'configDesc' => 'Configure the Anatoa profile fraud detection plugin.',
	'logDesc' => 'View log of all profile fraud checks performed by the Anatoa plugin.',
	'profileArchiveDesc' => 'View and restore backups of profiles deleted by the Anatoa plugin.',
	'checkProfileDesc' => 'Use this page to start a background fraud check of profiles created before installation of the Anatoa plugin.',
	'reportProfileDesc' => 'Use this page to review profiles and report profile(s) which are fradulent.',
	'USAGE_COMPLETE' => "You have reached the maximum number of Anatoa {--ServiceType--} checks for the current month. Please go to <a href='http://www.anatoa.com' target='_blank'>Anatoa.com</a> and upgrade your subscription in order to keep your members protected.",
	'PLG_UPDATED' =>  'Your plugin is up to date.',
	'PLG_OUTDATED' =>  'Your plugin is out of date. Version {--NewVersion--} is now available at <a href=\'http://www.anatoa.com/\'>anatoa.com</a>.',
	'TEMP_FOLDER_READONLY' =>  ' {--Path--} is not writable. Please set write permission for this folder.',
	'CRON_NOT_RUN_WARNING' => "Anatoa's cron script has not run during the last five minutes. Please enable all elgg cron. For more information please visit <a href='http://docs.elgg.org/wiki/Cron' target=_blank>http://docs.elgg.org/wiki/Cron</a>",

	// for Anatoa configuration page
	'configTitle'=>'Configuration',
	'configIntro' => "A (free) account at <a href='http://anatoa.com' target='_blank'>anatoa.com</a> is required to use the Anatoa fraud detection plugin. Please go to anatoa.com, sign up for an account, and enter your assigned API key below.",
	'APIKEY_BLANK'=>"API key cannot be blank.",
	'APIKEY_NO_RESPONSE' => 'Failed to verify APIKey from Anatoa.com via SOAP Webservice.',
	'ANATOA_CONNECTION_ERROR' => 'Unable to connect to web server, please check your connection or setting.',
	'INVALID_API_KEY' => "Your API Key has been verified and found to be incorrect by <a href='http://www.anatoa.com' target='_blank'>Anatoa.com</a>.",
	'VALID_API_KEY' => "Your API Key has been verified and found to be correct by <a href='http://www.anatoa.com' target='_blank'>Anatoa.com</a>.",
	'APIKEY_SAVED' => "Anatoa API configured successfully.",
	'APIKEY_NOT_CONFIGURED' => "API Key is not configured. Please, configure it for proper working of this plugin.",
	'CONNECTION_ERROR' => "Unable to connect to web server, please check your connection or setting. Process Stopped.",
	'mapIntro' => "If you have created custom profile fields for your member's first name, last name and country, you can configure the plugin to use these fields to improve the quality of the fraud detection process. Please assign any of these fields using the drop-downs below.",
	'ProfileRejectionHelptip' => "<b>Low :</b> only the most obvious fraudulent profiles are rejected. <br> <b>Standard : </b> recommended setting.<br><b>High :</b> any small indication of possible fraud could cause rejection. This setting could cause \\'false positives\\'. e.g. rejection of legitimate profiles.<br> <b>Disabled :</b> do not reject any profiles.",
	'ActionHelptip' => "<b>Suspend profile :</b> profile will be suspended, for manual review.", //<b>Delete profile : </b> profile will be automatically deleted. <br>
	'FullEmailHelptip' => "<b>Yes :</b> The full email address will be checked against Anatoa. <br> <b>No :</b> A one way hash value is used instead which means Anatoa will never see the actual email address. A setting of \\'Yes\\' is recommended as it helps the detection process.",
	'NO_EXTRA_FIELDS_ADDED' => '<b>No extra profile fields added</b>',
	'IPADDRESS_APIKEY_MISMATCH' => "The IP address of your server does not match the address configured for your API key. Please contact Anatoa Support.",

	//for Anatoa log page
	'logTitle'=>'Fraud Detection Log',
	'log:Profile' => 'Profile Log',
	'log:Image' => 'Image Log',
	'log:Message' => 'Message Log',
	'ALL_PROFILE_RESTORED'=>'All selected profiles restored',

	//for Anatoa check old profiles page
	'checkprofileTitle'=>'Check Old Profiles',
	'checkProfileIntro' => "Your database contains {--UncheckProfile--} profiles, {--UncheckImage--} images and {--UncheckMessage--} messages which have not been checked by Anatoa. You can use this page to check this data against our fraud detection service. Please be aware that the checks you run from this page will count against your monthly quota, which depends on your subscription level. If you have a large amount of data to check, we suggest you (temporarily) increase your subscription level, or spread usage of this page over several months.",
	'IPcheckIntro' => "The Anatoa plugin has collected user IP address for {--NumIPUncheck--} of your previously checked old profiles. It is recommended that you recheck these profiles with this additional information.",
	'numProRequired' => 'Maximum number of profiles to be checked field is required.',
	'NO_RESPONSE'=>'There is no response from server.<br> Possible case: <br><b> &nbsp;&nbsp; 1) Your internet connection failed while processing request. <br> &nbsp;&nbsp; 2) Server not responding. </b>',
	'SERVER_ERROR_RESPONSE' =>'Server error while processing your request.<br> Server Response :',
	'Processing_Error' =>'Error while Processing your Request.',
	'noProfileBlank'=>'Number of Profiles cannot be blank',
	'invalidnoProfile'=>'Enter a valid number of Profiles to be checked',
	'invalidnum'=>'Enter a valid number greater than 0',

	//for Anatoa profile archive
	'profilearchiveTitle' => 'Deleted Profile Archive',
	'profileArchiveIntro' => 'The Anatoa fraud detection plugin has automatically deleted the following profiles from your member database based on your configuration settings. Use this page to review profiles and optionally restore any \'false positives\' (profiles which you believe are legitimate and would like to allow on your system).',
	'NO_PROFILE_SELECTED' => 'No user profile is selected to restore, please select at least one user.',

	//for Anatoa report profiles
	'reportprofilesTitle' => 'Report User Profiles',
	'reportProfilesIntro' => 'Use this page to review profiles and report profile(s) which are fradulent.',
	'PROFILES_REPORTED' => 'Profile(s) reported to Anatoa.com. Thank you for your contribution.',
	'REPORTED_CONNECTION_ERROR' => 'Could not report profile due to error in connecting to web server via SOAP call.',
	'REPORTED_UNKNOWN_ERROR' => 'Unexpected error occurred while reporting profile. <br> Server response',

	//for User profile page
	 'userprofiledetailTitle' => 'User Profile'

	);

  add_translation("en",$english);