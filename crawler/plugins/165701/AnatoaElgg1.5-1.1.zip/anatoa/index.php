<?php
	/**
	 * Anatoa Elgg Plugin.
	 *
	 * @package Anatoa
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License Version 2
	 * @author anatoa.com
	 * @copyright Univalence Ltd. 2009-2010
	 * @link http://www.anatoa.com/
	 */

	require_once(dirname(dirname(dirname(__FILE__)))."/engine/start.php");
	define('ANATOA_PLUGIN_PATH',dirname(__FILE__));
	require_once(ANATOA_PLUGIN_PATH.'/includes/dbModel.class.php');
	require_once(ANATOA_PLUGIN_PATH.'/includes/config.class.php');
	require_once(ANATOA_PLUGIN_PATH.'/includes/nusoap.php');
	require_once(ANATOA_PLUGIN_PATH.'/includes/soapclient.class.php');
	require_once(ANATOA_PLUGIN_PATH.'/includes/utility.php');
	require_once(ANATOA_PLUGIN_PATH.'/includes/webservices.php');
	require_once(ANATOA_PLUGIN_PATH.'/includes/class.wsdlcache.php');

	admin_gatekeeper();
	set_context('admin');
	$type = get_input('section'); //the type of page e.g config, log etc
	$type = $type ? strtolower($type) : "main"; //default to the main page

	// Set admin user for user block
	set_page_owner($_SESSION['guid']);

	$forOrderGetPara = '';
	foreach ($_REQUEST as $key => $value)
       	{
       	   if($key != 'seq' && $key != 'sortby')
			 $forOrderGetPara .= "$key=$value&";
       	}

	$vars = array();
	switch ($type)
	{
		case 'config'		: $vars = configPage();	 break;
		case 'log' 			: $vars = logPage(); break;
		case 'checkprofile'	: $vars = checkProfilePage();	break;
		case 'profilearchive': $vars = profileArchive();	break;
		case 'reportprofiles': $vars = reportProfiles();	break;
		case 'userprofiledetail': $vars = userProfileDetail();	break;
		case 'showimage'	: showImage(); break;
		case 'main'			:
		default:
			checkInstallation();

			$anatoaConfig = anatoaConfiguration::getInstance();
			$dbModel = new dbModel();
			$soapclient = new anatoaSoapClient();
			$APIconfig = $dbModel->getConfig();
			$fraudStat = &$dbModel->getlast24hrStat();

			if(!is_writable(ANATOA_PLUGIN_PATH.'/includes/tmp'))
				$fraudStat['Notify'][] = str_replace('{--Path--}',ANATOA_PLUGIN_PATH.'/includes/tmp',elgg_echo('TEMP_FOLDER_READONLY'));

			if($soapclient->init() && $soapclient->callMethod( $APIconfig->APIKey, 'getLatestVersion', '', '', $return ) )
			{
				if( $return == $anatoaConfig->pluginVersion )
					$updateMsg = elgg_echo('PLG_UPDATED');
				else
					$updateMsg = str_replace('{--NewVersion--}',$return,elgg_echo('PLG_OUTDATED'));
			}
			$vars['updateInfo']=$updateMsg;
			$vars['fraudulentStat']=$fraudStat;
	}

	if($type)
	{
		$title = elgg_view_title(elgg_echo("{$type}Title"));
		$body = elgg_view("anatoa/$type", $vars);
		page_draw(elgg_echo('anatoa'),elgg_view_layout("two_column_left_sidebar", '', $title.$body ));
	}

	function & configPage()
	{
		$dataConfig = array();
		$dbModel = new dbModel();
		$arrExtraFields = $dbModel->getExtraFields();

		if(get_input('APIKey'))
		{
			$msgType = 'error';
			$dataConfig = &$_POST;
			if (empty($dataConfig['APIKey']))
			{
				// We notify the form API that this field has failed validation.
				$vars['error_msg'] = elgg_echo('APIKEY_BLANK');
			}
			else
			{
				$anatoaConfig = anatoaConfiguration::getInstance();
				$soapclient = new anatoaSoapClient();

				if(!$soapclient->init())
					$vars['error_msg'] = elgg_echo('APIKEY_NO_RESPONSE');
				else
				{
					$soapclient->callMethod( trim($dataConfig['APIKey']), 'verifyKey', '', '', $return );

					if($return === false)
					 	$vars['error_msg'] = elgg_echo('ANATOA_CONNECTION_ERROR');
					elseif($return == 'VALID_API_KEY')
					{ $vars['success_msg'] = elgg_echo('VALID_API_KEY'); $msgType = 'message'; }
					elseif(!empty($return) && !empty($anatoaConfig->soapResponse[$return]))
						$vars['error_msg'] = elgg_echo($return);
					elseif(!empty($return))
					  	$vars['error_msg'] = elgg_echo($return);
					else
						$vars['error_msg'] = elgg_echo('APIKEY_NO_RESPONSE');
				}
			}

			if ($msgType != 'error' && $dataConfig['Save'] == 'Save')
			{
				$vars['success_msg'] = elgg_echo('APIKEY_SAVED');
				$dbModel->updateConfig($dataConfig);
			}

		}
		else
			$dataConfig = (array) $dbModel->getConfig();

		if(get_input('Save2')=='Save')
		{
			$dbModel->setConfig('FirstName',get_input('firstName'));
			$dbModel->setConfig('LastName',get_input('lastName'));
			$dbModel->setConfig('Country',get_input('country'));
			$dataConfig = (array) $dbModel->getConfig();
		}

		if(count($arrExtraFields))
		{
			$options = array('0'=>'Select');

			if(!empty($arrExtraFields))
			foreach ($arrExtraFields as $fields)
				$options[$fields->id] = $fields->value;

			$fieldConfig = (get_input('APIKey')) ? (array) $dbModel->getConfig() : $dataConfig ;

			$vars['firstNameField'] = dropDowns('firstName',$options,$fieldConfig['FirstName'],'associativeArray');
			$vars['lastNameField'] = dropDowns('lastName',$options,$fieldConfig['LastName'],'associativeArray');
			$vars['countryField'] = dropDowns('country',$options,$fieldConfig['Country'],'associativeArray');
		}
		else $vars['firstNameField'] = $vars['lastNameField'] = $vars['countryField'] = elgg_echo('NO_EXTRA_FIELDS_ADDED');

		if($dataConfig['APIKey'] != '' || $dataConfig['APIKey']!='NOTCONFIGURED')
			$vars['cancelButton'] ="<input type='submit' name='Cancel' value=Cancel class=formbutton onClick=\"window.location='?section=main'; return false;\">";
		$vars['APIKey'] = $dataConfig['APIKey'];
		$vars['profileRejDD'] = dropDowns('Rejection_Threshold',array('Low','Standard','High','Disable'),$dataConfig['Rejection_Threshold']);
		$vars['actionDD'] = dropDowns('Action',array('Suspend'),$dataConfig['Action']); //,'Delete'
		$vars['checkEmailDD'] = dropDowns('Check_full_email',array('Yes','No'),$dataConfig['Check_full_email']);
		return $vars;
	}

	function & logPage()
	{
		global $CONFIG;
		$anatoaConfig = anatoaConfiguration::getInstance();
		$ttype = $vars['type']= get_input('type') ? get_input('type') : 'Profile';
		$offset = get_input('offset') ? get_input('offset') : 0;
		$vars['offset']		= $offset;
		$vars['limit'] 		= 20;
		$vars['baseurl'] 	= $_SERVER['REQUEST_URI'];

		$filter_order		= get_input('sortby') ? get_input('sortby') : 'log.LogDate' ;
		$vars['newSeq']	= get_input('seq') ? get_input('seq')  : 'DESC' ;

		$commanFieldsBegin	= array('ID'=>'log.MemberId', 'UserName'=>'user.username');
       	$commanFieldsEnd	= array('Result'=>'Master.Status', 'Date'=>'log.LogDate');
		$where = array();

		switch ( $ttype )
		{
			case 'Image'	: $fields = array_merge($commanFieldsBegin,array('Image'=>'Master.ImageId'),$commanFieldsEnd);	break;
			case 'Message'	: $fields = array_merge($commanFieldsBegin,array('Message'=>'log.Parameters'),$commanFieldsEnd); break;
			default			: $fields = array_merge($commanFieldsBegin,array('Email'=>'user.email'),$commanFieldsEnd);
		}

		$userTable = $CONFIG->dbprefix.$anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['tblName'];
		$userPK = $anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['priKey'];
		$mstTable = $CONFIG->dbprefix.$anatoaConfig->MasterTables[$ttype];
		$anatoaUserTbl = $CONFIG->dbprefix.$anatoaConfig->ProfileTable['Anatoa']['tblName'];
		$anatoaUserTblPK = $anatoaConfig->ProfileTable['Anatoa']['priKey'];

		$fieldsNotListed = array('Master.TableName','log.TransactionLogId',"anatoaUser.$userPK AS AnatoaUserId",'CheckStatus','anatoaUser.username AS AnatoaUserName',"user.$userPK as UserId",'anatoaUser.email AS AnatoaEmail');
		$where[] = " log.TransactionType='Check $ttype'";
		$where[] = " (CheckStatus='Checked' OR CheckStatus='Failed Check')";
		$strWhere	 =  count( $where ) ? ' WHERE ' . implode( ' AND ', $where ) : '' ;
		$orderby = ' ORDER BY '. $filter_order .' '. $vars['newSeq'] .', log.LogDate DESC';
		$memberFrom = " FROM {$CONFIG->dbprefix}anatoa_transactionlog AS log
						INNER JOIN $mstTable Master	ON log.RecordID = Master.{$ttype}ID AND	log.TableName = Master.TableName AND Master.ProfileID=log.MemberId
	       				LEFT JOIN $userTable AS user ON user.$userPK = log.MemberId
	       				LEFT JOIN $anatoaUserTbl AS anatoaUser	ON anatoaUser.$anatoaUserTblPK = log.MemberId";

		$query = "SELECT COUNT(*) AS TotalRows $memberFrom $strWhere";
		$rowCount = get_data_row( $query );
		$vars['count'] = $rowCount->TotalRows;

		$query = "SELECT ".implode( ', ', array_merge($fields,$fieldsNotListed))."
       				$memberFrom	$strWhere $orderby";

		$query .= " LIMIT {$vars['offset']}, {$vars['limit']}";
		$rows = get_data($query);

		$vars['newSeq'] = $vars['newSeq'] == 'DESC' ? 'ASC' : 'DESC';
		$vars['getOrderParas'] = $forOrderGetPara;
		$vars['fieldsName'] = $fields;
		$vars['dataRows'] = $rows;

		return $vars;
	}

	function & checkProfilePage()
	{
		$profileID = get_input('profileId');
		if(!empty($profileID))
		{
			$objwebService = new anatoaWebService();
			$response = $objwebService->ajaxCheckProfile((int) $profileID);
			ob_end_clean();
			header('Content-Type: text/javascript; charset=utf-8');
			echo "{ 'responseText': '$response' }";
			exit; die;
		}
		else
		{
			$objDBModel = new dbModel();

			$numProfilesUnchecked = $objDBModel->getNumberProfileUnchecked(0);
			if($numProfilesUnchecked > 0)
			{
				$numImagesUnchecked = $objDBModel->getNumberImageUnchecked();
				$numMessagesUnchecked = $objDBModel->getNumberMessageUnchecked();
			}
			else $numImagesUnchecked = $numMessagesUnchecked = 0;

			$vars['checkProfileIntro'] = str_replace(array('{--UncheckProfile--}','{--UncheckImage--}','{--UncheckMessage--}'),array($numProfilesUnchecked,$numImagesUnchecked,$numMessagesUnchecked),elgg_echo('checkProfileIntro'));

			$numProfilesUncheckedwithIPaddr = $objDBModel->getNumberProfileUnchecked(0,'Recheck');
			$profDiff = $numProfilesUncheckedwithIPaddr-$numProfilesUnchecked;
			if($profDiff > 0)
				$extraMsg = "<div >".str_replace('{--NumIPUncheck--}',$profDiff,elgg_echo('IPcheckIntro'))." </div>";

			$vars['extraMsg'] = $extraMsg;
			$numProfileToCheck = get_input('NoProfileCheck');
			if(isset($_POST['NoProfileCheck']) && empty($numProfileToCheck))
			  	$vars['error_msg'] = elgg_echo('numProRequired');

			if($numProfileToCheck > 0)
			{
				$recheck = get_input('Recheck') ? 'Recheck' : '';
				$numProfileToCheck = $objDBModel->getNumberProfileUnchecked($numProfileToCheck,$recheck);
			}

			$checked = (!get_input('NoProfileCheck') || get_input('Recheck')=='Recheck') ? 'checked' : '' ;

			$strProfileIds = implode(',',$objDBModel->profile_ids);
			if($numProfileToCheck == 1)
	  			$strProfileIds = "'$strProfileIds'";

			$jsCount = $numProfileToCheck ? $numProfileToCheck : 0;
	  		$vars['NoProfileCheck'] = get_input('NoProfileCheck');
	  		$vars['checked'] = $checked;
	  		$vars['totalProfiles'] = $numProfileToCheck;
	  		$vars['strProfileIds'] = $strProfileIds;
	  		$vars['jsCount'] = $jsCount;

	  		return $vars;
		}
	}

	function & profileArchive()
	{
		global $CONFIG;
		$anatoaConfig = anatoaConfiguration::getInstance();

		$msg = '';
		$where = array();
		$fieldsNotListed = array();

		$offset = get_input('offset') ? get_input('offset') : 0;
		$vars['offset']		= $offset;
		$vars['limit'] 		= 20;
		$vars['baseurl'] 	= $_SERVER['REQUEST_URI'];

		if(strtolower(get_input('Cancel'))=='cancel')
		  	header('Location:?section=main');
		elseif(strtolower(get_input('Restore'))=='restore')
		{
			$arrUserIDs = get_input('txtchk');
			if(empty($arrUserIDs))
				$msg = array('error'=>elgg_echo('NO_PROFILE_SELECTED'));
			else
			{
				$objDBModel = new dbModel();
				$objDBModel->restoreMembers($arrUserIDs);
				$msg = array('msg'=>elgg_echo('ALL_PROFILE_RESTORED'));
			}
		}



		$userTable = $CONFIG->dbprefix.$anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['tblName'];
		$userPK = $anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['priKey'];
		$mstTable = $CONFIG->dbprefix.'anatoa_mst_profiles';
		$anatoaUserTbl = $CONFIG->dbprefix.$anatoaConfig->ProfileTable['Anatoa']['tblName'];
		$anatoaUserTblPK = $anatoaConfig->ProfileTable['Anatoa']['priKey'];

		$fields = array('ID'=>"anatoaUser.$anatoaUserTblPK",
       					'UserName'=>'anatoaUser.username',
       					'Email'=>'anatoaUser.email'
       					);

       	$filter_order	= get_input('sortby') ? get_input('sortby') : "anatoaUser.$anatoaUserTblPK" ;
		$vars['newSeq']	= get_input('seq') ? get_input('seq')  : 'DESC' ;

		$memberFrom = " FROM $anatoaUserTbl AS anatoaUser
       					 JOIN $mstTable AS Master ON Master.ProfileID = anatoaUser.$anatoaUserTblPK";
		$orderby = ' ORDER BY '. $filter_order .' '. $vars['newSeq'] .", anatoaUser.$anatoaUserTblPK DESC";

		$query = "SELECT COUNT(*) AS TotalRows	$memberFrom";
		$rowCount = get_data_row( $query );
		$vars['count'] = $rowCount->TotalRows;

		$query = "SELECT ".implode(', ', array_merge($fields,$fieldsNotListed))."  $memberFrom $orderby ";
		$query .= " LIMIT $offset, {$vars['limit']}";
		$rows = get_data($query);

		$vars['msg'] = displayMsgs($msg);
		$vars['newSeq'] = $vars['newSeq'] == 'DESC' ? 'ASC' : 'DESC';
		$vars['getOrderParas'] = $forOrderGetPara;
		$vars['fieldsName'] = $fields;
		$vars['dataRows'] = $rows;

		return $vars;
	}

	function & reportProfiles()
	{
		global $CONFIG;
		$anatoaConfig = anatoaConfiguration::getInstance();
		$msg = '';
		$where = array();
		$fieldsNotListed = array();

		if(strtolower(get_input('cancel'))=='cancel')
		  	header('Location:?section=main');
		elseif(get_input('ReportBlock') || get_input('ReportDelete'))
		{
			$mode = get_input('ReportBlock') ? 'Blocked' : 'Deleted';
			$objwebService = new anatoaWebService();

			$j=0;
			$resonsOther = 0;
			$userIDs = get_input('txtchk');
			$options = get_input('myoption');
			$text = get_input('text');

			foreach ($userIDs as $uid)
			{
				if($options[$j] != 'Other')
					$return = $objwebService->reportProfile($uid,$options[$j],$mode);
				else
				{
					$return = $objwebService->reportProfile($uid,"Other : ".$text[$resonsOther],$mode);
					$resonsOther++;
				}

				if($return == 'Error:Connection' || $return == 'Error:APIKey')
					break;
				$j++;
			}

			if(empty($return))
			    $msg = '<div align=center><font color=green> '.elgg_echo('REPORTED_THANKS').' </font></div>';
			elseif($return == 'Error:Connection' || $return == 'Error:APIKey')
				$msg = '<div align=center><font color=red> '.elgg_echo('REPORTED_CONNECTION_ERROR').' </font></div>';
			else $msg = "<div align=center><font color=red> ".elgg_echo('REPORTED_UNKNOWN_ERROR')." : $return </font></div>";

		}

		$offset = get_input('offset') ? get_input('offset') : 0;
		$vars['offset']		= $offset;
		$vars['limit'] 		= 20;
		$vars['baseurl'] 	= $_SERVER['REQUEST_URI'];

		$userTable = $CONFIG->dbprefix.$anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['tblName'];
		$userPK = $anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['priKey'];
		$mstTable = $CONFIG->dbprefix.'anatoa_mst_profiles';
		$anatoaUserTbl = $CONFIG->dbprefix.$anatoaConfig->ProfileTable['Anatoa']['tblName'];
		$anatoaUserTblPK = $anatoaConfig->ProfileTable['Anatoa']['priKey'];

		//$where[] = " Users.banned !='yes' ";

		$filter_order	= get_input('sortby') ? get_input('sortby') : "Users.$userPK" ;
		$vars['newSeq']	= get_input('seq') ? get_input('seq')  : 'DESC' ;

		$fields = array('ID'=>'Users.'.$userPK,
       					'UserName'=>'Users.username',
       					'Email'=>'Users.email',
       					'Banned'=> 'Users.banned'
       					);

		$whereStr	 =  count( $where ) ? ' WHERE ' . implode( ' AND ', $where ) : ' WHERE 1=1 ' ;
		$orderby = ' ORDER BY '. $filter_order .' '. $vars['newSeq'] .', Users.'.$userPK.' DESC';

		$query = "SELECT COUNT(*) AS TotalRows FROM $userTable AS Users ";
		if(!empty($anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['JOIN']))
 		   $query .= $anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['JOIN'];
		$query .= " $whereStr ";
		if(!empty($anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['REQUIRED']))
			$query .= " AND ".$anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['REQUIRED'];
		$rowCount = get_data_row( $query );
		$vars['count'] = $rowCount->TotalRows;

		$query = "SELECT ".implode(', ', array_merge($fields,$fieldsNotListed))."
       				FROM $userTable AS Users ";
		if(!empty($anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['JOIN']))
 		   $query .= $anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['JOIN'];
		$query .= " $whereStr ";
		if(!empty($anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['REQUIRED']))
			$query .= " AND ".$anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['REQUIRED'];
		$query .= " $orderby ";
		$query .= " LIMIT $offset, {$vars['limit']}";
		$rows = get_data($query);

		$options=array();
		foreach ($anatoaConfig->reasonForReportingProfile as $resons)
			$options[] = $resons;
		$reportResons = dropDowns('myoption[]',$options,'','simple','',"size='1' disabled onchange='resons(this)'");

		$vars['msg'] = $msg;
		$vars['newSeq'] = $vars['newSeq'] == 'DESC' ? 'ASC' : 'DESC';
		$vars['getOrderParas'] = $forOrderGetPara;
		$vars['fieldsName'] = $fields;
		$vars['dataRows'] = $rows;
		$vars['userPriKey'] = $userPK;
		$vars['reportResons'] = $reportResons;

		return $vars;
	}

	function dropDowns($name,$Options,$selected='',$optArrType = 'simple',$class='input-pulldown',$otherOpt="style='width:100px;'")
	{
		$strHtml = '<select name ="'.$name.'" class=\''.$class."' $otherOpt>";
		foreach ($Options as $key => $opt)
		{
			if($optArrType == 'simple')
			  $optValue = $opt;
			 else $optValue = $key;

			if($selected == $optValue) $sel = 'selected ';
			else $sel = '';

			$strHtml .= '<option value="'.$optValue."\" $sel> $opt </option>";
		}
		$strHtml .='</select>';
		return $strHtml;
	}

	function showImage()
	{
		$profileId = get_input('profileId','');
		if(!empty($profileId))
		{
			$objDBModel = new dbModel();
			$Images = $objDBModel->getProfileImage($profileId);

			$readfile = new ElggFile();
			$readfile->owner_guid = $Images[0]->owner_guid;
			$readfile->setFilename("profile/". $Images[0]->username ."master.jpg");
			$contents = $readfile->grabFile();

			ob_end_clean();
			header("Content-type: image");
			echo $contents;
			exit;
		}
		else
		{
			$size = get_input('size','small');
			if ($size != 'small') {
				$size = 'large';
			}
			$Images = get_metadata_for_entity(get_input('imageId'));
			$readfile = new ElggFile();
			$readfile->owner_guid = $Images[0]->owner_guid;
			$thumbfile = $size == "small" ? $Images[6]->value : $Images[0]->value;

			$readfile->setFilename($thumbfile);
			$contents = $readfile->grabFile();
			ob_end_clean();
			header("Content-type: {$Images[1]->value}");
			echo $contents;
			exit;
		}
	}

	function checkInstallation()
	{
		$tables = get_data("SHOW TABLES LIKE '%anatoa%'");
		if( $tables === false )
			run_sql_script(dirname(__FILE__) . "/sql/install.sql");

	}

	function & userProfileDetail()
	{
		global $CONFIG;
		$dbModel = new dbModel();
		$anatoaConfig = anatoaConfiguration::getInstance();
		$profileId = get_input('profileId');
		$user = get_user($profileId);

		if(empty($user->email))
			$user = get_data_row('SELECT * FROM '.$CONFIG->dbprefix.$anatoaConfig->ProfileTable['Anatoa']['tblName'].' WHERE '.$anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['priKey'].' = '.$profileId);

		$reason = get_data_row('SELECT Reason,reportReasons FROM '.$CONFIG->dbprefix.$anatoaConfig->MasterTables['Profile'].' WHERE ProfileID = '.$profileId);

		$albums = get_entities('object','album',$profileId);
		$albArr = array();

		if(!empty($albums))
		foreach ($albums as $album)
			$albArr[] = $album->guid;
		if(!empty($albArr))
			$Images = get_entities('object','image',$albArr);
		else $Images = array();

		$Messages = get_entities_from_metadata('fromId',$profileId,'object','messages',$profileId);

		$profileImage = $dbModel->getProfileImage($profileId);

		if($profileImage)
		{
			$user_master_image = "../icon/" . $profileImage[0]->username . "/master/" . $profileImage[0]->icontime . ".jpg";
			$vars['imageUrl'] = $user_master_image;
		}
		$vars['user'] = $user;
		$vars['images'] = $Images;
		$vars['messages'] = $Messages;
		$vars['reason'] = $reason;

		return $vars;
	}

	function displayMsgs($errorMessages = array())
	{
		$returnHtml = '';
		foreach ($errorMessages as $type => $msg)
			$returnHtml = "<div class='$type'>$msg</div>";
		return $returnHtml;
	}