/** Anatoa elgg Plugin v1.0
 *  Copyright 2009 Univalence Ltd
 *  All rights reserved
 */


function validateForm(form)
{
	if(form.NoProfileCheck.value == '')
	{
		alert(noProfileBlank);
		form.NoProfileCheck.focus();
		return false;
	}
	else if (isNaN(form.NoProfileCheck.value))
	{
		alert(invalidnoProfile);
		form.NoProfileCheck.focus();
		return false;
	}
	else if (form.NoProfileCheck.value <= 0)
	{
		alert(invalidnum);
		form.NoProfileCheck.focus();
		return false;
	}
	else
		return true;
}

var Start =  function (){
		if(runStatus == 0 || runStatus == 2)
			runStatus = 1;
		if(profileIDs.length > 0)
			Run();
		$('#startButton').attr("disabled", true);
		$('#startButton').removeClass("elggButtonEnabled").addClass("elggButtonDisabled");
		$('#startbgProcbutton').attr("disabled", true);
		$('#startbgProcbutton').css({
								"background" : "#ECE9D8",
								"color" : "#666666",
								"font-weight" : "normal"
								});
		$('#pauseButton').attr("disabled", false);
		$('#pauseButton').removeClass("elggButtonDisabled").addClass("elggButtonEnabled");
}

var Pause = function (){
		if(runStatus == 1){
			runStatus = 2;
			$('#pauseButton').val('Resume');
		}
		else if(runStatus == 2){
			$('#pauseButton').val('Pause');
			runStatus = 1;
		    Run();
		}
}

var Stop = function (){runStatus = 0;}

var Run = function () {
		$.ajax({
			type: 'POST',
			url: chkProfileUrl,
			dataType: 'json',
			success: function (req)
			{
		          if(req.responseText == 'Error:APIKey')
		          {
		          	$("#anatoaMsg").html(APIKeyNotConfigured);
		          	error = 1;
		          }
		          else if(req.responseText == 'Error:Connection')
		          {
		          	$("#anatoaMsg").html(ConnectionError);
		          	error = 1;
		          }
		          else if(req.responseText.substring(0,16) == 'Error:Processing')
		          {
		          	 $("#anatoaMsg").html(Processing_Error);
		          	 error = 1;

		          	 if(req.responseText.length > 16)
		          	 	$("#anatoaMsg").html(req.responseText);
		          }
		          else if(req.responseText == '')
		          {
		          	$("#anatoaMsg").html(noResponse);
		          	error = 1;
		          }
		          else if( i < profileIDs.length )
			        {
					    temp = req.responseText.split(';');

					    if(isNaN(parseInt(temp[0])) || isNaN(parseInt(temp[1])))
					    {
					    	debugMsg = req.responseText;
					    	$("#anatoaMsg").html(errorResponse+'<b>'+debugMsg+'</b><hr>');
					    	error = 1;
					    }
						else
						{
						    ProfilesScanned = ProfilesScanned + parseInt(temp[0]);
						    fProfile = fProfile + parseInt(temp[1]);

						    $("#fPComplete").html(ProfilesScanned);
						    $("#fP").html(fProfile);

						    percentageCompleted = Math.round(( ProfilesScanned ) * 100 / totalItems );
						    $("#divPercent").width( percentageCompleted + "%");

						    if(percentageCompleted > 19)
						      $("#percentageStatus").html(percentageCompleted + "% completed");

						    i++;
						    if(i < profileIDs.length && runStatus==1)
							    Run();
						    else if(i >= profileIDs.length )
						    {
							    $('#startButton').attr("disabled", true);
								$('#startbgProcbutton').attr("disabled", false);
								$('#startbgProcbutton').css({
															"background" : "#4690d6",
															"color" : "#ffffff",
															"font-weight" : "bold"
															});
								$('#pauseButton').attr("disabled", true);
								$('#pauseButton').removeClass("elggButtonEnabled").addClass("elggButtonDisabled");

							    $("#anatoaMsg").css({'color':'green', 'text-align':'center'});
							    $("#anatoaMsg").html('Selected profiles have been checked.<hr>');
						    }
						}
			        }

			        if(error)
			        {
						$('#startButton').attr("disabled", true);
						$('#startbgProcbutton').attr("disabled", false);
						$('#startbgProcbutton').css({"background" : "#4690d6",
													 "color" : "#ffffff",
													 "font-weight" : "bold"	});
						$('#pauseButton').attr("disabled", true);
						$('#pauseButton').removeClass("elggButtonEnabled").addClass("elggButtonDisabled");
			        	
						Stop();
			        	return;
			        }
	           }, 
			data: 'profileId='+profileIDs[i]
		  });
}