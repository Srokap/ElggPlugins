<?php
	/**
	 * Anatoa elgg Plugin.
	 *
	 * @package Anatoa
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License Version 2
	 * @author anatoa.com
	 * @copyright Univalence Ltd. 2009-2010
	 * @link http://www.anatoa.com/
	 */

	function anatoa_init()
	{
		global $CONFIG;

		// Register a URL handler for external pages
		register_entity_url_handler('anatoa_url','object','anatoa');

		// Register a page handler, so we can have nice URLs
		register_page_handler('anatoa','anatoa_page_handler');

		// Extend CSS
		extend_view('css','anatoa/css');


    }

    /**
    * anatoa Cron job
    *
    */
    function anatoa_cron($hook, $entity_type, $returnvalue, $params)
    {
    	if(!empty($params))
    	{
		 	global $ENTITY_SHOW_HIDDEN_OVERRIDE,$CONFIG, $is_admin;
		 	$is_admin = 1;
		 	$ENTITY_SHOW_HIDDEN_OVERRIDE = 1;

			$plgDir = dirname(__FILE__);
			require_once($plgDir.'/includes/dbModel.class.php');
			require_once($plgDir.'/includes/config.class.php');
			require_once($plgDir.'/includes/nusoap.php');
			require_once($plgDir.'/includes/soapclient.class.php');
			require_once($plgDir.'/includes/utility.php');
			require_once($plgDir.'/includes/webservices.php');
			require_once($plgDir.'/includes/class.wsdlcache.php');

			$objwebService = new anatoaWebService();
			$objwebService->cronJob();

			exit;
    	}
    }


	function anatoa_url($expage) {
			global $CONFIG;
			return $CONFIG->url . "pg/anatoa/";
	}

	/**
	 * Adding the log browser to the admin menu
	 *
	 */
	function anatoa_pagesetup()
	{
		if (get_context() == 'admin' && isadminloggedin()) {
			global $CONFIG;
			add_submenu_item(elgg_echo('anatoa:linkname'), $CONFIG->wwwroot . 'pg/anatoa/?section=main');
		}
	}

	/**
	 * anatoa page handler
	 *
	 * @param array $page Array of page elements, forwarded by the page handling mechanism
	 */
	function anatoa_page_handler($page)
	{
		global $CONFIG;
		include($CONFIG->pluginspath . "anatoa/index.php");
	}

	function anatoa_userLoginUpdate_handler($event, $object_type, $object)
	{
		global $CONFIG;
		if (($object) && ($object instanceof ElggUser) && !isadminloggedin() && get_context()!='admin')
		{

			$plgDir = dirname(__FILE__);
			require_once($plgDir.'/includes/config.class.php');
			require_once($plgDir.'/includes/utility.php');
			$anatoaConfig = anatoaConfiguration::getInstance();

	        $IP = anatoaUtility::getIPAddress();
	        $ip_address = addslashes($IP['IPAddress']);
	        $proxy_ip = addslashes($IP['ProxyIP']);

	        //$extraFieldUpdate = $event == 'update' ? "Recheck = 'Yes'," : '';
	        $extraFieldUpdate = $event == 'profileupdate' ? "Recheck = 'Yes'," : '';

	        $query = "INSERT INTO ".$CONFIG->dbprefix."{$anatoaConfig->MasterTables['Profile']}
	                    SET ProfileID = {$object->guid},
	                    	Email     = '{$object->email}',
	                        TableName = '{$anatoaConfig->ProfileTable[$anatoaConfig->pluginName]['tblName']}',
	                        IPAddress = '$ip_address',
	                        ProxyIP   = '$proxy_ip'
	                    ON DUPLICATE KEY UPDATE $extraFieldUpdate
	                    	Email     = '{$object->email}',
	                        IPAddress = '$ip_address',
	                        ProxyIP   = '$proxy_ip'";

			insert_data($query);


		}
	}

	register_elgg_event_handler('login', 'user', 'anatoa_userLoginUpdate_handler');
	//register_elgg_event_handler('update', 'user', 'anatoa_userLoginUpdate_handler');
	register_elgg_event_handler('profileupdate', 'user', 'anatoa_userLoginUpdate_handler');
	register_elgg_event_handler('init','system','anatoa_init');
	register_elgg_event_handler('pagesetup','system','anatoa_pagesetup');
	register_plugin_hook('cron', 'fiveminute', 'anatoa_cron');