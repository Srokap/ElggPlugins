
DROP TABLE IF EXISTS `prefix_anatoa_config`;

CREATE TABLE `prefix_anatoa_config` (
  `APIKey` char(32) NOT NULL,
  `Rejection_Threshold` enum('Low','Standard','High','Disabled') NOT NULL default 'Standard',
  `Action` enum('Delete','Suspend') NOT NULL default 'Suspend',
  `Check_full_email` enum('Yes','No') NOT NULL default 'Yes',
  `keyChecked` enum('Other','Valid','Invalid') NOT NULL default 'Other',
  `ModifiedBy` int(11) unsigned NOT NULL default '1',
  `LastModified` datetime NOT NULL default '0000-00-00 00:00:00',
  `AddedDate` datetime NOT NULL default '0000-00-00 00:00:00',
  `DisabledValue` float(4,2) unsigned NOT NULL default '10.00',
  `HighValue` float(4,2) unsigned NOT NULL default '9.00',
  `StandardValue` float(4,2) unsigned NOT NULL default '6.00',
  `LowValue` float(4,2) unsigned NOT NULL default '3.00',
  `checkProfileLimitReached` tinyint(1) NOT NULL default '0',
  `checkImageLimitReached` tinyint(1) NOT NULL default '0',
  `checkMessageLimitReached` tinyint(1) NOT NULL default '0',
  `cronConnectionError` tinyint(1) NOT NULL default '0',
  `cronRunning` tinyint(1) NOT NULL default '0',
  `numberOfTimesFailed` tinyint(3) NOT NULL default '0',
  `lastLogCleared` datetime NOT NULL default '0000-00-00 00:00:00',
  `CronRunnedAt` datetime NOT NULL default '0000-00-00 00:00:00',
  `Error` varchar(255) NOT NULL default '',
  `CronKey` varchar(15) default 'CRONKEY007',
  `FirstName` int(11) default '0',
  `LastName` int(11) default '0',
  `Country` int(11) default '0',
  PRIMARY KEY  (`APIKey`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `prefix_anatoa_mst_images`;

CREATE TABLE `prefix_anatoa_mst_images` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  `ProfileID` int(10) unsigned NOT NULL,
  `ImageID` int(10) unsigned NOT NULL,
  `TableName` varchar(125) default '',
  `ImageFile` varchar(255) default '',
  `Status` enum('Unconfirmed','Blocked','Deleted') NOT NULL default 'Unconfirmed',
  `CheckStatus` enum('Checked','Unchecked','Failed Check') NOT NULL default 'Unchecked',
  `ReportStatus` enum('Reported','Unreported','Failed Report') NOT NULL default 'Unreported',
  `checkDate` datetime NOT NULL default '0000-00-00 00:00:00',
  `reportDate` datetime NOT NULL default '0000-00-00 00:00:00',
  `checkReturnValue` varchar(125) default '',
  `reportReturnValue` varchar(125) default '',
  `checkReasons` varchar(125) default '',
  `reportReasons` varchar(125) default '',
  `checkMode` varchar(255) default '',
  `reportMode` varchar(255) default '',
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `ImageCustomIndex` (`ImageID`,`TableName`,`ProfileID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `prefix_anatoa_mst_messages`;

CREATE TABLE `prefix_anatoa_mst_messages` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  `ProfileID` int(10) unsigned NOT NULL,
  `MessageID` int(10) unsigned NOT NULL,
  `TableName` varchar(125) default '',
  `Status` enum('Unconfirmed','Blocked','Deleted') NOT NULL default 'Unconfirmed',
  `CheckStatus` enum('Checked','Unchecked','Failed Check') NOT NULL default 'Unchecked',
  `ReportStatus` enum('Reported','Unreported','Failed Report') NOT NULL default 'Unreported',
  `checkDate` datetime NOT NULL default '0000-00-00 00:00:00',
  `reportDate` datetime NOT NULL default '0000-00-00 00:00:00',
  `checkReturnValue` varchar(125) default '',
  `reportReturnValue` varchar(125) default '',
  `checkReasons` varchar(125) default '',
  `reportReasons` varchar(125) default '',
  `checkMode` varchar(255) default '',
  `reportMode` varchar(255) default '',
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `CustomIndex` (`MessageID`,`TableName`,`ProfileID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `prefix_anatoa_mst_profiles`;

CREATE TABLE `prefix_anatoa_mst_profiles` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  `ProfileID` int(10) unsigned NOT NULL,
  `TableName` varchar(125) default '',
  `UserName` varchar(255) default '',
  `Email` varchar(255) default '',
  `FirstName` varchar(255) default '',
  `LastName` varchar(255) default '',
  `UserType` varchar(125) default '',
  `Country` varchar(255) default '',
  `IPAddress` varchar(16) default '',
  `ProxyIP` varchar(16) default '',
  `Status` enum('Unconfirmed','Blocked','Deleted','Restored') NOT NULL default 'Unconfirmed',
  `CheckStatus` enum('Checked','Unchecked','Failed Check') NOT NULL default 'Unchecked',
  `Recheck` enum('Yes','No') DEFAULT 'No',
  `CheckedWithIP` enum('Yes','No') default 'No',
  `ReportStatus` enum('Reported','Unreported','Failed Report') NOT NULL default 'Unreported',
  `checkDate` datetime NOT NULL default '0000-00-00 00:00:00',
  `reportDate` datetime NOT NULL default '0000-00-00 00:00:00',
  `checkReturnValue` varchar(125) default '',
  `reportReturnValue` varchar(125) default '',
  `Reason` varchar(255) default '',
  `checkReasons` varchar(125) default '',
  `reportReasons` varchar(125) default '',
  `checkMode` varchar(255) default '',
  `reportMode` varchar(255) default '',
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `profileKeys` (`ProfileID`,`TableName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `prefix_anatoa_transactionlog`;

CREATE TABLE `prefix_anatoa_transactionlog` (
  `TransactionLogId` int(11) unsigned NOT NULL auto_increment,
  `calledBy` varchar(255) default NULL,
  `MemberId` int(11) unsigned default NULL,
  `RecordID` int(10) unsigned default NULL,
  `TableName` varchar(64) default NULL,
  `TransactionType` enum('Check Profile','Check Message','Check Image','Report Profile','Report Image','Report Message') default NULL,
  `Parameters` mediumtext,
  `ReturnValue` varchar(125) default NULL,
  `Reasons` varchar(125) default NULL,
  `LogDate` datetime default NULL,
  PRIMARY KEY  (`TransactionLogId`),
  UNIQUE KEY `uniqueCalls` (`MemberId`,`RecordID`,`TableName`,`TransactionType`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `prefix_anatoa_users`;

CREATE TABLE `prefix_anatoa_users` (
  `guid` bigint(20) unsigned NOT NULL,
  `name` text NOT NULL,
  `username` varchar(128) NOT NULL default '',
  `password` varchar(32) NOT NULL default '',
  `salt` varchar(8) NOT NULL default '',
  `email` text NOT NULL,
  `language` varchar(6) NOT NULL default '',
  `code` varchar(32) NOT NULL default '',
  `banned` enum('yes','no') NOT NULL default 'no',
  `last_action` int(11) NOT NULL default '0',
  `prev_last_action` int(11) NOT NULL default '0',
  `last_login` int(11) NOT NULL default '0',
  `prev_last_login` int(11) NOT NULL default '0',
  PRIMARY KEY  (`guid`),
  UNIQUE KEY `username` (`username`),
  KEY `password` (`password`),
  KEY `email` (`email`(50)),
  KEY `code` (`code`),
  KEY `last_action` (`last_action`),
  KEY `last_login` (`last_login`),
  FULLTEXT KEY `name` (`name`),
  FULLTEXT KEY `name_2` (`name`,`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `prefix_anatoa_entities`;

CREATE TABLE `prefix_anatoa_entities` (
  `guid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('object','user','group','site') NOT NULL,
  `subtype` int(11) DEFAULT NULL,
  `owner_guid` bigint(20) unsigned NOT NULL,
  `site_guid` bigint(20) unsigned NOT NULL,
  `container_guid` bigint(20) unsigned NOT NULL,
  `access_id` int(11) NOT NULL,
  `time_created` int(11) NOT NULL,
  `time_updated` int(11) NOT NULL,
  `enabled` enum('yes','no') NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`guid`),
  KEY `type` (`type`),
  KEY `subtype` (`subtype`),
  KEY `owner_guid` (`owner_guid`),
  KEY `site_guid` (`site_guid`),
  KEY `container_guid` (`container_guid`),
  KEY `access_id` (`access_id`),
  KEY `time_created` (`time_created`),
  KEY `time_updated` (`time_updated`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


INSERT  INTO `prefix_anatoa_config` values('NOTCONFIGURED','Standard','Suspend','Yes','Other',1,NOW(),NOW(),10.00,9.00,6.00,3.00,0,0,0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','CRONKEY007',0,0,0);