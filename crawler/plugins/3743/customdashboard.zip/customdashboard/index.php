<?php
	/**
	 * Elgg customdashboard plugin
	 * This plugin substitutes the dashboard with a custom one
	 * Based on customindex plugin by Boris Glumper
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Ted Ostrem
	 * @copyright Ted Ostrem 2008
	 * @link /www.inque.se
	 */
	 
	// Load Elgg engine
	require_once(dirname(dirname(dirname(__FILE__))) . '/engine/start.php');

	// Get view
	$area1 = elgg_view('customdashboard/content', $vars);

	// Format
	$body = elgg_view_layout('one_column', $area1);

	// Draw page
	echo page_draw(elgg_echo('the page title'), $body);

?>