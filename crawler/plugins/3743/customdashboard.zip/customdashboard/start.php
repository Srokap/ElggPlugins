<?php
	/**
	 * Elgg customdashboard plugin
	 * This plugin substitutes the dashboard with a custom one
	 * Based on customindex plugin by Boris Glumper
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Ted Ostrem
	 * @copyright Ted Ostrem 2008
	 * @link /www.inque.se
	 */
	
	function customdashboard_init() {
    
        // Extend  CSS
         extend_view('css','customdashboard/css');
                
        // Register page handler
        register_page_handler('dashboard','new_dashboard');
                
    }
    
    /**
         * Dashboard page handler;
         *
         */
    function new_dashboard($page) {
		if (!@include_once(dirname(dirname(__FILE__))) . "/customdashboard/index.php") return false;
		return true;
    }

	register_elgg_event_handler('init','system','customdashboard_init');
?>