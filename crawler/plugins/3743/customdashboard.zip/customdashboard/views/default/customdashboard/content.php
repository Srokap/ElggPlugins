<?php
	/**
	 * Elgg customdashboard plugin
	 * This plugin substitutes the dashboard with a custom one
	 * Based on customindex plugin by Boris Glumper
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Ted Ostrem
	 * @copyright Ted Ostrem 2008
	 * @link /www.inque.se
	 */

	// Put your content below
?>

	