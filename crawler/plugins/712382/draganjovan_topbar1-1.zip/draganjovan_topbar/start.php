<?php

	/**
	 * Elgg draganjovan_topbar plugin
	 *
	 * @author Dragan Jovanovic
	 * @website www.draganjovan.info
	 */

    function draganjovan_topbar_init() {

		extend_view('css','draganjovan_topbar/css');
    }

		
     // Make sure the status initialisation function is called on initialisation
	register_elgg_event_handler('init','system','draganjovan_topbar_init');
	
?>
