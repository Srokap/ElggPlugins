<?php

	/*** draganjovan_topbar language file*/
	
	$english = array(
	'draganjovan:account' => "Account",
        'draganjovan:adminsettings' => "Enter the link text and URL for the custom topbar link. If you need to use a special character in the link attribute, like a quote character, please enter it using a special entity code, e.g. &amp;quot;.",
        'draganjovan:admintext' => "Link text:",
        'draganjovan:adminurl' => "Link URL:",
        'draganjovan:admintarget' => "Link target:",

	);

add_translation("en",$english);
?>