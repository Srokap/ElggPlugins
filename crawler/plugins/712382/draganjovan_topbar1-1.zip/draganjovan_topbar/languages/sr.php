<?php

	/*** draganjovan_topbar language file*/
	
	$serbian = array(
	'draganjovan:account' => "Nalog",

	);

add_translation("sr",$serbian);
?>