<?php
/**
 * Elgg translation browser.
 *
 * @package translationbrowser
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Mariusz Bulkowski
 * @author v2 Pedro Prez
 * @copyright 2009
 * @link http://www.pedroprez.com.ar/
 */

/**
 * Initialise the log browser and set up the menus.
*/

require_once(dirname(__FILE__) . '/functions_translatebrowser.php');

function translationbrowser_init()
{
    global $CONFIG;

    // Register a page handler, so we can have nice URLs
    register_page_handler(
        'translationbrowser','translationbrowser_page_handler'
    );

    // Extend CSS
    extend_view('css','translationbrowser/css');

    // Extend context menu with admin logbrowsre link
    if (isadminloggedin())
    {
         extend_view(
             'profile/menu/adminlinks',
             'translationbrowser/adminlinks',
             10000
         );
    }

    register_action(
        "translationbrowser/get_text",
        false,
        $CONFIG->pluginspath . "translationbrowser/actions/get_text.php",
        true
    );
    register_action(
        "translationbrowser/translate",
        false,
        $CONFIG->pluginspath . "translationbrowser/actions/translate.php",
        true
    );
}

/**
 * Adding the log browser to the admin menu
 *
 */
function translationbrowser_pagesetup()
{
    if (get_context() == 'admin' && isadminloggedin()) {
        global $CONFIG;
        add_submenu_item(
            elgg_echo('translationbrowser'),
            $CONFIG->wwwroot . 'pg/translationbrowser/'
        );
    }
}

/**
 * Log browser page handler
 *
 * @param array $page Array of page elements,
 *        forwarded by the page handling mechanism
 */
function translationbrowser_page_handler($page) 
{
    global $CONFIG;


    if (isset($page[0]) && !empty($page[0]))
    {
        switch($page[0])
        {
            case 'translate':
                if (isset($page[1]) && !empty($page[1]))
                {
                    set_input('translationbrowser_session',$page[1]);
                }
                include dirname(__FILE__) . "/translate.php";
                break;
            default:
                include $CONFIG->pluginspath . "translationbrowser/index.php";
                break;
       }
    }
    else
    {
        include $CONFIG->pluginspath . "translationbrowser/index.php";
    }
   
}

register_elgg_event_handler('init','system','translationbrowser_init');
register_elgg_event_handler('pagesetup','system','translationbrowser_pagesetup');
?>