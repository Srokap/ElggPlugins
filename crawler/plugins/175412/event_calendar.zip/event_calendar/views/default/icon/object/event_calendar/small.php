<?php
	echo $vars['url'] . "mod/event_calendar/images/event_icon.gif";
?>