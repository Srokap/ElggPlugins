<?php

function AnimetedText_init() 
		{
		global $CONFIG;
		add_menu(elgg_echo('AnimetedText'), $CONFIG->wwwroot . "mod/AnimetedText");
		}
		
	register_elgg_event_handler('init','system','AnimetedText_init');

?>