<?php
 /**
 * Bad Word filter/cencoe
 * 
 * @package Bad word censor 1.8
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author liang
 * @copyright Liang 2011 month 9 date 17 sat time 3:43am

 * @link http://community.elgg.org/pg/profile/arsalanlee
 **/
?>
<?Php

$reported_content_description = 'Bad wrod Filtered automatically detected inappropriate content from a user.  See below for full details and original context:
<pre style="font-family: monospace;">

%s

%s
</pre>';

$settings_blurb = '
<p>Words must be separated by commas in one of the styles below:</p> 

<h4>Style</h4>
<code>
word1,word2,word3,word4,word5,word6
<code>
';

$english = array(
	'badwords:censored' => 'You have used an inappropriate word.  This has been reported to the adminstrators.',
	'badwords:reported_content_title' => 'Reported Content from Bad Word filter',
	'badwords:reported_content_description' => $reported_content_description,
	
	'badwords:settings_blurb' => $settings_blurb,
	'badwords:naughty_words_list' => 'A comma-separated list of words to censor.',
	'badwords:replacement_string_enabled' => 'Replace naughty words?',
	'badwords:replacement_string' => 'Replace naughty words with the following string.',
	'badwords:report_censored_page' => 'Automatically add censored pages to Reported Content?',
	'badwords:use_regexp_censor' => 'Please Select me no!',
	'badwords:notify_user_on_censor' => 'Show the user a message if they use an inappropriate word?',
	
	'badwords:report_username' => 'Logged in user\'s username: ',
	'badwords:report_display_name' => 'Logged in user\'s display name: ',
	'badwords:report_date' => 'Added on: ',
	'badwords:report_object_type' => 'Object Type: ',
	
	'badwords:malformed_regexp' => 'Site Contain Error no : #702 Please Inform to Administrator of this website.',
);

add_translation("en", $english);
?>
