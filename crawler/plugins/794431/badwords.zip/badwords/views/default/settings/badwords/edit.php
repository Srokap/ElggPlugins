<?php
/**
 * Bad Word filter/cencor
 * 
 * @package Bad word censor 1.8
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author liang
 * @copyright Liang 2011 month 9 date 17 sat time 3:43am
 * @link http://community.elgg.org/pg/profile/arsalanlee
 */

$text_area_options = array(
	'internalname' => 'params[naughty_word_list]', 
	'value' => str_replace(',', ",\n", get_plugin_setting('naughty_word_list', 'badwords')),
);
$text_area = elgg_view('input/text', $text_area_options);

$replacement_string_enabled_field = elgg_view('input/pulldown', array(
	'internalname' => 'params[replacement_string_enabled]',
	'value' => get_plugin_setting('replacement_string_enabled', 'badwords'),
	'options_values' => array(
		1 => elgg_echo('option:yes'),
		0 => elgg_echo('option:no')
	)
));

$replacement_string = get_plugin_setting('replacement_string', 'badwords');
$replacement_string_field = elgg_view('input/text', array('internalname'=>'params[replacement_string]', 'value'=>$replacement_string));

$report_censored_page_field = elgg_view('input/pulldown', array(
	'internalname' => 'params[report_censored_page]',
	'value' => get_plugin_setting('report_censored_page', 'badwords'),
	'options_values' => array(
		1 => elgg_echo('option:yes'),
		0 => elgg_echo('option:no')
	)
));

$notify_user_on_censor_field = elgg_view('input/pulldown', array(
	'internalname' => 'params[notify_user_on_censor]',
	'value' => get_plugin_setting('notify_user_on_censor', 'badwords'),
	'options_values' => array(
		1 => elgg_echo('option:yes'),
		0 => elgg_echo('option:no')
	)
));

// @todo disabled for now...
$use_regexp_censor_field = elgg_view('input/pulldown', array(
	'internalname' => 'params[use_regexp_censor]',
	'value' => get_plugin_setting('use_regexp_censor', 'badwords'),
	'options_values' => array(
		1 => elgg_echo('option:yes'),
		0 => elgg_echo('option:no')
	)
));

// these only pull in the plugin-created subtypes.
// there seems to be no way to get a list of all possible subtypes and types.
$subtypes = get_data("SELECT `subtype` FROM `{$CONFIG->dbprefix}entity_subtypes`");

// special case to deal with no subtype:
$subtypes_form .= elgg_view('input/pulldown', array(
		'internalname' => "params[no_subtype_monitor_enabled]",
		'value' => get_plugin_setting('no_subtype_monitor_enabled', 'badwords'),
		'options_values' => array(
			1 => elgg_echo('option:yes'),
			0 => elgg_echo('option:no')
		)
	)
);
$subtypes_form .= '<br />';
 
foreach($subtypes as $object) {
	$subtype = $object->subtype;

	$subtypes_form .= elgg_view('input/pulldown', array(
			'internalname' => 'params[subtype_' . $subtype . '_monitor_enabled]',
			'value' => get_plugin_setting('subtype_' . $subtype . '_monitor_enabled', 'badwords'),
			'options_values' => array(
				1 => elgg_echo('option:yes'),
				0 => elgg_echo('option:no')
			)
		)
	);
	$subtypes_form .= '<br />';
}
/*
<label><?php echo elgg_echo('badwords:subtypes_blurb') ; echo $subtypes_form; ?></label><br />
*/
?>
<?php echo elgg_echo('badwords:settings_blurb'); ?>
<p>
	<label><?php echo elgg_echo('badwords:naughty_words_list'); echo '<br />' . $text_area; ?> </label><br />
	<label><?php echo elgg_echo('badwords:use_regexp_censor'); echo $use_regexp_censor_field; ?></label><br />
	<label><?php echo elgg_echo('badwords:replacement_string_enabled'); echo $replacement_string_enabled_field; ?></label><br />
	<label><?php echo elgg_echo('badwords:replacement_string'); echo $replacement_string_field; ?></label><br />
	<label><?php echo elgg_echo('badwords:report_censored_page'); echo $report_censored_page_field; ?></label><br />
	<label><?php echo elgg_echo('badwords:notify_user_on_censor'); echo $notify_user_on_censor_field; ?></label><br />
	
</p>