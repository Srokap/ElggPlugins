<?php

	/**
	 * Elgg google plugin
	 *
	 * @package Elgggoogle
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Untamed
	 * @copyright Untamed 2008-2010
	 */

	/**
	 * My Custom Text init function; defines what to do when plugin is enabled
	 *
	 */
		function google_init() {

			// Get config
				global $CONFIG;


			 register_page_handler('google','google_page_handler');
				
			// Add menu link
				add_menu(elgg_echo('google'), $CONFIG->wwwroot . "pg/google/");
				
				}

					function google_page_handler($page)
						{
							global $CONFIG;
							switch ($page[0])
							{
								default:
									include $CONFIG->pluginspath . 'google/index.php';
									break;	
							}
							exit;
						}

				
				//Startup stuff... links to google_init function
		register_elgg_event_handler('init', 'system', 'google_init');
?>