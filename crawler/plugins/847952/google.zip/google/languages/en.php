<?php
	/**
	 * Elgg google plugin
	 *
	 * @package Elgggoogle
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Untamed
	 * @copyright Untamed 2008-2010
	 */

	$english = array(

	/**
	 * My CustomText
	 */

		'google' => "Google",
	);

	add_translation("en",$english);