<?php

	/**
	 * Elgg Google Search plugin
	 *
	 * @package Google Search
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author BUMBABlog
	 * @copyright BUMBABlog 2008-2010
	 */

	// Get the Elgg engine
		require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
		
		//Link text php file to body and display page
		$body = elgg_view('mytext');
		$title = elgg_echo("google");
		page_draw($title, $body);
		
?>