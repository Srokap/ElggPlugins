<?php
	/**
	 *	WISH LIST PLUGIN
	 *	@package wlist
	 *	@author Miguel Montes mmontesp@gmail.com
	 *	@license GNU General Public License (GPL) version 2
	 *	@copyright (c) Miguel Montes 2008
	 *	@link http://community.elgg.org/pg/profile/mmontesp
	 **/

	// Make sure we're logged in (send us to the front page if not)
		gatekeeper();

        // Make sure action is secure
        action_gatekeeper();

	// Get input data
		$title = get_input('wishtitle');
		$body = get_input('wishbody');
		//$tags = get_input('wishtags');
		$access = get_input('access_id');
		$url = get_input('wishurl');

	// Cache to the session
		$_SESSION['wlisttitle'] = $title;
		$_SESSION['wishbody'] = $body;
		//$_SESSION['wishtags'] = $tags;
		$_SESSION['wishurl'] = $url;
		
	// Convert string of tags into a preformatted array
		//$tagarray = string_to_tag_array($tags);
		
	// Make sure the title / description aren't blank
		if (empty($title) || empty($body)) {
			register_error(elgg_echo("wlist:blank"));
			forward("mod/wlist/edit.php");
			
	// Otherwise, save the wish
		} else {
			
	// Initialise a new ElggObject
			$wish = new ElggObject();
	// Tell the system it's a blog post
			$wish->subtype = "wish";
	// Set its owner to the current user
			$wish->owner_guid = $_SESSION['user']->getGUID();
	// For now, set its access to public (we'll add an access dropdown shortly)
			$wish->access_id = $access;
	// Set its title and description appropriately
			$wish->title = $title;
			$wish->description = $body;
	// Before we can set metadata, we need to save the wish
			if (!$wish->save()) {
				register_error(elgg_echo("wlist:error"));
				forward("mod/wlist/edit.php");
			}
	// Now let's add tags. We can pass an array directly to the object property! Easy.
			/*if (is_array($tagarray)) {
				$wish->tags = $tagarray;
			}*/
			
			$wish->url = $url;
	// Success message
			system_message(elgg_echo("wlist:saved"));
	// Remove the blog post cache
			unset($_SESSION['wishtitle']); unset($_SESSION['wishbody']);unset($_SESSION['wishurl']);
			//unset($_SESSION['wishtags']);
	// Forward to the main blog page
			forward("mod/wlist/?username=" . $_SESSION['user']->username);
				
		}
		
?>
