<?php
	/**
	 *	WISH LIST PLUGIN
	 *	@package wlist
	 *	@author Miguel Montes mmontesp@gmail.com
	 *	@license GNU General Public License (GPL) version 2
	 *	@copyright (c) Miguel Montes 2008
	 *	@link http://community.elgg.org/pg/profile/mmontesp
	 **/
	
	// Make sure we're logged in (send us to the front page if not)
		gatekeeper();

	// Get input data
		$guid = (int) get_input('wish');
		
	// Make sure we actually have permission to edit
		$wish = get_entity($guid);
		if ($wish->getSubtype() == "wish" && $wish->canEdit()) {
	
		// Get owning user
				$owner = get_entity($wish->getOwner());
		// Delete it!
				$rowsaffected = $wish->delete();
				if ($rowsaffected > 0) {
		// Success message
					system_message(elgg_echo("wlist:deleted"));
				} else {
					register_error(elgg_echo("wlist:notdeleted"));
				}		
		}else{
			register_error(elgg_echo("wlist:notpermission"));
		}
		
		// Forward to the main wlist
		forward("mod/wlist/?username=" . $owner->username);
		
?>