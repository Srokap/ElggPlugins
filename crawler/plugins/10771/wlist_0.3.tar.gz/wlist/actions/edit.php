<?php
	/**
	 *	WISH LIST PLUGIN
	 *	@package wlist
	 *	@author Miguel Montes mmontesp@gmail.com
	 *	@license GNU General Public License (GPL) version 2
	 *	@copyright (c) Miguel Montes 2008
	 *	@link http://community.elgg.org/pg/profile/mmontesp
	 **/
	
	// Make sure we're logged in (send us to the front page if not)
		gatekeeper();

        // make sure action is secure
        action_gatekeeper();

	// Get input data
		$guid = (int) get_input('wish');
		$title = get_input('wishtitle');
		$body = get_input('wishbody');
		$access = get_input('access_id');
		//$tags = get_input('wishtags');
		$url = get_input('wishurl');
		
	// Make sure we actually have permission to edit
		$wish = get_entity($guid);
		if ($wish->getSubtype() == "wish" && $wish->canEdit()) {
	
		// Cache to the session
			$_SESSION['wishtitle'] = $title;
			$_SESSION['wishbody'] = $body;
			//$_SESSION['wishtags'] = $tags;
			$_SESSION['wishurl'] = $url;
			
		// Convert string of tags into a preformatted array
			//$tagarray = string_to_tag_array($tags);
			
		// Make sure the title / description aren't blank
			if (empty($title) || empty($body)) {
				register_error(elgg_echo("wlist:blank"));
				forward("mod/wlist/edit.php");
				
		// Otherwise, save the wish
			} else {
				
		// Get owning user
				$owner = get_entity($wish->getOwner());
		// For now, set its access to public (we'll add an access dropdown shortly)
				$wish->access_id = $access;
		// Set its title and description appropriately
				$wish->title = $title;
				$wish->description = $body;
		// Before we can set metadata, we need to save the wish
				if (!$wish->save()) {
					register_error(elgg_echo("wish:error"));
					forward("mod/wlist/edit.php?wish=" . $guid);
				}
		// Now let's add tags. We can pass an array directly to the object property! Easy.
				/*$wish->clearMetadata('tags');
				if (is_array($tagarray)) {
					$wish->tags = $tagarray;
				}*/
				
				$wish->url = $url;
				
		// Success message
				system_message(elgg_echo("wlist:saved"));
		// Remove the wish cache
				unset($_SESSION['wishtitle']); unset($_SESSION['wishbody']);unset($_SESSION['wishurl']);
				//unset($_SESSION['wishtags']);
		// Forward to the wish page
				forward("pg/wlist/" . $owner->username);
					
			}
		
		}
		
?>
