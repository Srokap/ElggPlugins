<?php
	/**
	 *	WISH LIST PLUGIN
	 *	@package wlist
	 *	@author Miguel Montes mmontesp@gmail.com
	 *	@license GNU General Public License (GPL) version 2
	 *	@copyright (c) Miguel Montes 2008
	 *	@link http://community.elgg.org/pg/profile/mmontesp
	 **/
	
	// Load Elgg engine
		require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	// Get the specified blog post
		$wish = (int) get_input('wish');

	// If we can get out the blog post ...
		if ($wish= get_entity($wish)) {
			
	// Get any comments
			$comments = $wish->getAnnotations('comments');
		
	// Set the page owner
			set_page_owner($wish->getOwner());
			$page_owner = get_entity($wish->getOwner());
			
	// Display it
			$area2 = elgg_view("object/wish",array(
											'entity' => $wish,
											'entity_owner' => $page_owner,
											'comments' => $comments,
											'full' => true
											));

	// Display through the correct canvas area
		$body = elgg_view_layout("two_column_left_sidebar", '', $area1 . $area2);
			
	// If we're not allowed to see the blog post
		} else {
			
	// Display the 'post not found' page instead
			$body = elgg_view("wish/notfound");
			$title = elgg_echo("wish:notfound");
			
		}
		
	// Display page
		page_draw($title,$body);
?>
