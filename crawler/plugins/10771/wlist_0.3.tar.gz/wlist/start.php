<?php
	/**
	 *	WISH LIST PLUGIN
	 *	@package wlist
	 *	@author Miguel Montes mmontesp@gmail.com
	 *	@license GNU General Public License (GPL) version 2
	 *	@copyright (c) Miguel Montes 2008
	 *	@link http://community.elgg.org/pg/profile/mmontesp
	 **/
	
	function wlist_init(){
		
		global $CONFIG;
		
		//menu
		if (isloggedin()) {
    		add_menu(elgg_echo('wlist'), $CONFIG->wwwroot . "pg/wlist/" . $_SESSION['user']->username);
		}
		
		//menu	sobre el usuario
		extend_view('profile/menu/links','wlist/menu');
		
		//extender css
		extend_view('css','wlist/css');extend_view('js','wlist/js');
		
		// Load the language file
		register_translations($CONFIG->pluginspath . "wlist/languages/");
		
		//registrar page handler
		register_page_handler('wlist', 'wlist_page_handler');
		
		// Register a URL handler for blog posts
		register_entity_url_handler('wish_url','object','wish');
		
		// Add generic new file widget
		add_widget_type('mywishes',elgg_echo("wlist:widget:mywishes"),elgg_echo("wlist:widget:mywishes:description"));
		add_widget_type('myfriendswishes',elgg_echo("wlist:widget:myfriendswishes"),elgg_echo("wlist:widget:myfriendswishes:description"));
		
		//registrar la entidad wish
		register_entity_type('object','wish');
	}
	
	function wlist_page_handler($page) {
		// The first component of a blog URL is the username
		if (isset($page[0])) {
			set_input('username',$page[0]);
		}
		// The second part dictates what we're doing
		if (isset($page[1])) {
			switch($page[1]) {
				case "read": set_input('wish',$page[2]);
							@include(dirname(__FILE__) . "/read.php");
							break;
				case "friends":	@include(dirname(__FILE__) . "/friends.php");
								break;
			}
		// If the URL is just 'wlist/username', or just 'wlist/', load the standard blog index
		} else {
			@include(dirname(__FILE__) . "/index.php");
			return true;
		}
			
		return false;
	}
	
	function wish_url($wish) {
			
			global $CONFIG;
			$title = $wish->title;
			$title = friendly_title($title);
			return $CONFIG->url . "pg/wlist/" . $wish->getOwnerEntity()->username . "/read/" . $wish->getGUID() . "/" . $title;
			
	}
	
	function wlist_pagesetup() {
			
			global $CONFIG;
			//add submenu options
				if (get_context() == "wlist") {
					if ((page_owner() == $_SESSION['guid'] || !page_owner()) && isloggedin()) {
						add_submenu_item(elgg_echo('wlist:your'),$CONFIG->wwwroot."pg/wlist/" . $_SESSION['user']->username);
						add_submenu_item(elgg_echo('wlist:friends'),$CONFIG->wwwroot."pg/wlist/" . $_SESSION['user']->username . "/friends/");
						add_submenu_item(elgg_echo('wlist:addwish'),$CONFIG->wwwroot."mod/wlist/edit.php");
					} else if (page_owner()) {
						$page_owner = page_owner_entity();
						add_submenu_item(sprintf(elgg_echo('wlist:user'),$page_owner->name),$CONFIG->wwwroot."pg/wlist/" . $page_owner->username);
						if ($page_owner instanceof ElggUser) // Sorry groups, this isn't for you.
							add_submenu_item(sprintf(elgg_echo('wlist:user:friends'),$page_owner->name),$CONFIG->wwwroot."pg/wlist/" . $page_owner->username . "/friends/");
					}
				}
			
	}
	
	
	register_elgg_event_handler('init', 'system','wlist_init');
	register_elgg_event_handler('pagesetup','system','wlist_pagesetup');
	global $CONFIG;
	register_action("wish/add",false,$CONFIG->pluginspath . "wlist/actions/add.php");
	register_action("wish/edit",false,$CONFIG->pluginspath . "wlist/actions/edit.php");
	register_action("wish/delete",false,$CONFIG->pluginspath . "wlist/actions/delete.php");
?>