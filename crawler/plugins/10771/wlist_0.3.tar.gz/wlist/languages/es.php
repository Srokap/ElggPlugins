<?php
	/**
	 *	WISH LIST PLUGIN
	 *	@package wlist
	 *	@author Miguel Montes mmontesp@gmail.com
	 *	@license GNU General Public License (GPL) version 2
	 *	@copyright (c) Miguel Montes 2008
	 *	@link http://community.elgg.org/pg/profile/mmontesp
	 **/

$spanish = array( 
   'wlist'  =>  "Regalos" , 
   'wlists'  =>  "Regalos" , 
   'wlist:user'  =>  "Regalos para %s" , 
   'wlist:user:friends'  =>  "Regalos para los amigos de %s" , 
   'wlist:your'  =>  "Tu lista de regalos" , 
   'wlist:text'  =>  "Descripción" , 
   'wlist:url'  =>  "Enlace" , 
   'wlist:friends'  =>  "Regalos para amigos" , 
   'wlist:yourfriends'  =>  "Últimos regalos para tus amigos" , 
   'wlist:addwish'  =>  "Pide un deseo" , 
   'wlist:editwish'  =>  "Edita un deseo" , 
   'item:object:wish'  =>  "Regalos" , 
   'wlist:saved'  =>  "Tu deseo ha sido guardado." , 
   'wlist:deleted'  =>  "Tu deseo ha sido borrado." , 
   'wlist:save:failure'  =>  "Tu deseo no pudo ser guardado. Inténtalo de nuevo" , 
   'wlist:blank'  =>  "Necesitas indicar un titulo y una descripción antes de pedir un deseo." , 
   'wlist:notfound'  =>  "Lo sentimos, no hemos podido encontrar el deseo indicado." , 
   'wlist:notdeleted'  =>  "Lo sentimos, no podemos borrar este deseo."
);


add_translation("es",$spanish);



?>