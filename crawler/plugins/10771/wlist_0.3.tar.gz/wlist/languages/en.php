<?php
	/**
	 *	WISH LIST PLUGIN
	 *	@package wlist
	 *	@author Miguel Montes mmontesp@gmail.com
	 *	@license GNU General Public License (GPL) version 2
	 *	@copyright (c) Miguel Montes 2008
	 *	@link http://community.elgg.org/pg/profile/mmontesp
	 **/
	
	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'wlist' => "Wish List",
			'wlists' => "WIsh Lists",
			'wlist:user' => "%s's wishes",
			'wlist:user:friends' => "%s's friends' wishes",
			'wlist:your' => "Your Wish List",
			//'wlist:posttitle' => "%s's wlist: %s",
			'wlist:text' => "Description",
			'wlist:url' => "Link",
			'wlist:friends' => "Friends' Wish Lists",
			'wlist:yourfriends' => "Your friends' latest wishes",
	
			'wlist:addwish' => "Make a wish",
			'wlist:editwish' => "Edit a wish",
			'item:object:wish' => "Wishes",
	
			
         /**
	     * Wlist river
	     **/
	        
	        //generic terms to use
	        'wlist:river:created' => "%s wrote",
	        'wlist:river:updated' => "%s updated",
	        'wlist:river:posted' => "%s posted",
	        
	        //these get inserted into the river links to take the user to the entity
	        'wlist:river:create' => "a new wish.",
	        'wlist:river:update' => "a wish.",
	        'wlist:river:annotate:create' => "a comment on a wish.",
		/**
		 * Wlist widgets
		 */
			'wlist:widget:mywishes' => "My Wishes",
			'wlist:widget:myfriendswishes' => "My Friends Wishes",
			'wlist:widget:label:displaynum' => "Number of wishes to display",

	
		/**
		 * Status messages
		 */
	
			'wlist:saved' => "Your wish was successfully saved.",
			'wlist:deleted' => "Your wish was successfully deleted.",
	
		/**
		 * Error messages
		 */
	
			'wlist:save:failure' => "Your wish could not be saved. Please try again.",
			'wlist:blank' => "Sorry; you need to fill in both the title and description before you can make a wish.",
			'wlist:notfound' => "Sorry; we could not find the specified wish.",
			'wlist:notdeleted' => "Sorry; we could not delete this wish.",
	
	);
					
	add_translation("en",$english);

?>
