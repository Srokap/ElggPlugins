<?php
	/**
	 *	WISH LIST PLUGIN
	 *	@package wlist
	 *	@author Miguel Montes mmontesp@gmail.com
	 *	@license GNU General Public License (GPL) version 2
	 *	@copyright (c) Miguel Montes 2008
	 *	@link http://community.elgg.org/pg/profile/mmontesp
	 **/
	
	$statement = $vars['statement'];
	$performed_by = $statement->getSubject();
	$object = $statement->getObject();
	
	$url = "<a href=\"{$performed_by->getURL()}\">{$performed_by->name}</a>";
	$string = sprintf(elgg_echo("wlist:river:updated"),$url) . " ";
    $string .= "<a href=\"" . $object->getURL() . "\">" . elgg_echo("wlist:river:update") . "</a>";
    
?>

<?php echo $string; ?>
