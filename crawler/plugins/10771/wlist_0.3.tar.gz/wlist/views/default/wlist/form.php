<?php
	/**
	 *	WISH LIST PLUGIN
	 *	@package wlist
	 *	@author Miguel Montes mmontesp@gmail.com
	 *	@license GNU General Public License (GPL) version 2
	 *	@copyright (c) Miguel Montes 2008
	 *	@link http://community.elgg.org/pg/profile/mmontesp
	 **/
	
	// Set title, form destination
		if (isset($vars['entity'])) {
			$title = sprintf(elgg_echo("wlist:editwish"),$object->title);
			$action = "wish/edit";
			$title = $vars['entity']->title;
			$body = $vars['entity']->description;
			//$tags = $vars['entity']->tags;
			$access_id = $vars['entity']->access_id;
			$url = $vars['entity']->url;
		} else  {
			$title = elgg_echo("wlist:addwish");
			$action = "wish/add";
			//$tags = "";
			$title = "";
			$description = "";
			$access_id = 0;
			$url = "";
		}

	// Just in case we have some cached details
		if (isset($vars['wishtitle'])) {
			$title = $vars['wishtitle'];
			$body = $vars['wishbody'];
			//$tags = $vars['wishtags'];
			$url = $vars['wishurl'];
		}

?>

<?php
                $title_label = elgg_echo('title');
                $title_textbox = elgg_view('input/text', array('internalname' => 'wishtitle', 'value' => $title));
                $text_label = elgg_echo('wlist:text');
                $text_textarea = elgg_view('input/longtext', array('internalname' => 'wishbody', 'value' => $body));
                $url_label = elgg_echo('wlist:url');
				$url_textbox = elgg_view('input/url', array('internalname' => 'wishurl', 'value' => $url));
				//$tag_label = elgg_echo('tags');
                //$tag_input = elgg_view('input/tags', array('internalname' => 'wishtags', 'value' => $tags));
                $access_label = elgg_echo('access');
                $access_input = elgg_view('input/access', array('internalname' => 'access_id', 'value' => $access_id));
                $submit_input = elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('save')));

                if (isset($vars['entity'])) {
                  $entity_hidden = elgg_view('input/hidden', array('internalname' => 'wish', 'value' => $vars['entity']->getGUID()));
                } else {
                  $entity_hidden = '';
                }

		/*<p>
			<label>$tag_label</label><br />
                        $tag_input
		</p>*/

                $form_body = <<<EOT
		<p>
			<label>$title_label</label><br />
                        $title_textbox
		</p>
		<p>
			<label>$text_label</label><br />
                        $text_textarea
		</p>
		<p>
			<label>$url_label</label><br />
                        $url_textbox
		</p>
		<p>
			<label>$access_label</label><br />
                        $access_input
		</p>
		<p>
			$entity_hidden
			$submit_input
		</p>
EOT;

      echo elgg_view('input/form', array('action' => "{$vars['url']}action/$action", 'body' => $form_body));
?>



