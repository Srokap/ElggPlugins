<?php
	/**
	 *	WISH LIST PLUGIN
	 *	@package wlist
	 *	@author Miguel Montes mmontesp@gmail.com
	 *	@license GNU General Public License (GPL) version 2
	 *	@copyright (c) Miguel Montes 2008
	 *	@link http://community.elgg.org/pg/profile/mmontesp
	 **/
?>
.river_wish_update, .river_wish_create {
	background-image: url(<?php echo $CONFIG->wwwroot;?>/mod/wlist/images/river_icon_wish.gif);
	background-repeat: no-repeat;
}

.wlist_wish {
	margin-bottom: 15px;
	border-bottom: 1px solid #aaaaaa;
}

.wlist_wish div.usericon {
	float:left;
	margin:3px 5px 5px 0;
	padding:0;
}
