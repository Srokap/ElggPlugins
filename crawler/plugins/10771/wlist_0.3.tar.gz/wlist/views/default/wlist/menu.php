<?php
	/**
	 *	WISH LIST PLUGIN
	 *	@package wlist
	 *	@author Miguel Montes mmontesp@gmail.com
	 *	@license GNU General Public License (GPL) version 2
	 *	@copyright (c) Miguel Montes 2008
	 *	@link http://community.elgg.org/pg/profile/mmontesp
	 **/
?>

<p class="user_menu_blog">
	<a href="<?php echo $vars['url']; ?>pg/wlist/<?php echo $vars['entity']->username; ?>"><?php echo elgg_echo("wlist"); ?></a>
</p>