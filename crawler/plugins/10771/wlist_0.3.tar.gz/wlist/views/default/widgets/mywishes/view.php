<?php
	/**
	 *	WISH LIST PLUGIN
	 *	@package wlist
	 *	@author Miguel Montes mmontesp@gmail.com
	 *	@license GNU General Public License (GPL) version 2
	 *	@copyright (c) Miguel Montes 2008
	 *	@link http://community.elgg.org/pg/profile/mmontesp
	 **/
	
	//get the num of shares the user want to display
	$limit = $vars['entity']->limit;
		
	//if no number has been set, default to 4
	if(!$limit) $limit = 5;
	
	//the page owner
	$owner = $vars['entity']->owner_guid;
	
	$wishes = get_user_objects($owner, 'wish', $limit, 0);
	
	if ($wishes){
		foreach($wishes as $wish) {
			echo elgg_view("wlist/widget", array('entity' => $wish));
		}
	}
	
	
	//echo elgg_view("wlist/listing", array('entity' => $wishes));
	
?>