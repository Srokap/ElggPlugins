<?php
	/**
	 *	WISH LIST PLUGIN
	 *	@package wlist
	 *	@author Miguel Montes mmontesp@gmail.com
	 *	@license GNU General Public License (GPL) version 2
	 *	@copyright (c) Miguel Montes 2008
	 *	@link http://community.elgg.org/pg/profile/mmontesp
	 **/
	
	if (get_context() == "search") {
		//display the correct layout depending on gallery or list view
		if (get_input('search_viewtype') == "gallery") {
			//display the gallery view
            echo elgg_view("wlist/gallery",$vars);
		} else {
			echo elgg_view("wlist/listing",$vars);
		}
	}else{
		//SHORT VIEW
		$owner = $vars['entity']->getOwnerEntity();
		$friendlytime = friendly_time($vars['entity']->time_created);
		$icon = elgg_view(
			"profile/icon", array(
				'entity' => $owner,
				'size' => 'small',
			)
		);
		$num_comments = elgg_count_comments($vars['entity']);
		
		echo "<div class='wlist_wish'>";
		echo $icon;
		echo "<h2><a href=\"{$vars['entity']->getURL()}\">{$vars['entity']->title}</a></h2>";
		echo "<p class=\"owner_timestamp\"><a href=\"{$owner->getURL()}\">{$owner->name}</a> {$friendlytime} &nbsp;<a href=\"{$vars['entity']->getURL()}\">".sprintf(elgg_echo("comments"))." ($num_comments)</a></p>";
		//FULL VIEW
		if (isset($vars['full']) && $vars['full'] == true) {
			echo "<p>{$vars['entity']->description}</p>";
			if ($vars['entity']->url){
				echo "<p><a href=\"{$vars['entity']->url}\">[".elgg_echo('wlist:url')."]</a></p>";
			}
			if ($vars['entity']->canEdit()){
				echo "<p class='options'>";
					echo "<a href=\"{$CONFIG->wwwroot}mod/wlist/edit.php?wish={$vars['entity']->guid}\">".elgg_echo('edit')."</a> &nbsp&nbsp";
					echo elgg_view("output/confirmlink", array(
							'href' => $CONFIG->wwwroot."action/wish/delete.php?wish=".$vars['entity']->guid,
							'text' => elgg_echo('delete'),
							'confirm' => elgg_echo('deleteconfirm'),
					));	
				echo "</p>";
			}
			echo "</div>";
			echo elgg_view_comments($vars['entity']);
		}else{
			echo "</div>";
		}
		
	}
	
	
?>