<?php

date_default_timezone_set('UTC');

elgg_register_event_handler('init', 'system', 'birthdaygroup_init');

function birthdaygroup_init() {
    elgg_register_plugin_hook_handler('cron', 'minute','birthdaygroup_bday_mailer');
}
function birthdaygroup_bday_mailer($hook, $entity_type, $returnvalue, $params){
$bday = elgg_get_plugin_setting('birth_day', 'river_activity_3C');

    $from = 'deepan.palaniappan@treeshore.com';

            $options = array(
            'metadata_names' => $bday,
            'types' => 'user',
    'limit' => false,
    'full_view' => false,
    'pagination' => false,
    'list_type' => 'gallery',
    'gallery_class' => 'elgg-gallery-users',
                        );
         /*   $options1 = array(
            'metadata_names' => $bday,
            'types' => 'user',
    'limit' => false,
    'full_view' => false,
    'pagination' => false,
    'list_type' => 'gallery',
    'gallery_class' => 'elgg-gallery-users',
                        );*/
						
        $siteurl=elgg_get_site_url();
        $bd_users = elgg_get_entities_from_metadata($options);
        
       
        $bd_today = date('m/d');
        $sitename="RMDAlumni";
        $siteaddress="http://experimentsite.in/rmdalumini";
		
	
		
        foreach ($bd_users as $bd_user)
	{
	/*if($g_en->isMember($bd_user))
	*/
            $bd_name = $bd_user->name;
            $bd_email = $bd_user->email;
            $bd = $bd_user->$bday;
            $bd_day = date('m/d',strtotime($bd));
            $bd_mobile="mobile";
            $bd_phone="phone";
            
           if($bd_mobile=="")
           {
           $bd_contactno=$bd_phone;
           }elseif($bd_phone=="")
           {
           $bd_contactno=$bd_mobile;
           }
           else
           {
           $bd_contactno="Not mentioned any contact no";
           }
           
        if ($bd_day == $bd_today){
           //$message = sprintf(elgg_echo('Today yours friend Birthday'),$bd_name,$bd_day, $sitename, $siteaddress);          
            elgg_send_email($from, "deepansrec@gmail.com", elgg_echo('Birthday wishes from RMDALUMNI site'),"Wish you many more happy returns of the Day"); 
        $all_groups = elgg_get_entities(array("type" => "group", "limit" => false));
	
	foreach($all_groups as $group)
	{
	//elgg_send_email($from,"deepansrec@gmail.com",elgg_echo('Birthday Remainder from RMDALUMNI site'),"deepan groups running");
	if($group->isMember($bd_user))
	{
	$options1 = array(
		"type" => "user",
		"limit" => false,
		"relationship" =>'member',
		"relationship_guid" => $group,
		"inverse_relationship" => true,
	);
	$wusers = elgg_get_entities_from_metadata($options1);
	
            foreach($wusers as $rec_user)
               {
			//if($g_en->isMember($rec_user))
			//{
			if(($group->isMember($rec_user)))
			{
			if($rec_user->email != $bd_user->email)
			   {
            $rec_email = $rec_user->email;
           
            $mess = "Today your Group member`s Birthday,\n"."Group:".$group->name."\n".$bd_user->name."\n"."Make a wish : in email"."\n".$bd_user->email."\n Mobile/phone:".$bd_contactno."\n"."siteaddress:". $siteurl;
            elgg_send_email($from,$rec_email,elgg_echo('Birthday Remainder from RMDALUMNI site'),$mess);
                            }
		        }	//}
            
              }
         }    
       }
	}
}//foreach
    return true;
}
?>