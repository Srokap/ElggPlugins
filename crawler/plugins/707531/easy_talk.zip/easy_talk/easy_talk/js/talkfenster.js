  /*
	 * @Plugin easy_talk
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Ilja Konrad & Dieter Konrad
     * @link http://www.onere.net/ & http://allesubuntu.de/
	 * @contact <onerenet@gmail.com>
	 * @copyright Ilja Konrad 2010
	 */

function talkfenster(talknewloc) 
{
 var width  = 900;
 var height = 500;
 var left   = (screen.width  - width)/2;
 var top    = (screen.height - height)/2;
 var params = 'width='+width+', height='+height;
 params += ', location=yes';
 params += ', menubar=no';
 params += ', resizable=no';
 params += ', scrollbars=yes';
 params += ', top='+top+', left='+left;
 params += ', directories=no';
 params += ', status=no';
 params += ', toolbar=no';
 talkloc=window.open(talknewloc,'', params);
 if (window.focus) {talkloc.focus()}
 return false;
}
