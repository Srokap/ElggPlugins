<?php
/*
	 * @Plugin easy_talk
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Ilja Konrad & Dieter Konrad
     * @link http://www.onere.net/ & http://allesubuntu.de/
	 * @contact <onerenet@gmail.com>
	 * @copyright Ilja Konrad 2010
	 */
	include_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	//  nur f�r eingeloggte user Das ist die Gatekeeper funktion	
	gatekeeper();
	$idres = get_loggedin_userid ();
	$datencode = "{$CONFIG->dbprefix}";
	
		$abfrage = mysql_query(
						"SELECT *
						FROM `{$CONFIG->dbprefix}entities`
						WHERE `access_id` = '5555' ORDER by time_created DESC
						LIMIT 1"
					);

					while ($row = mysql_fetch_array($abfrage))
					{
						$tyz = $row["guid"];
			
	
	$abfrage = mysql_query(
						"SELECT *
						FROM `{$CONFIG->dbprefix}objects_entity`
						WHERE `guid` = '$tyz' 
						LIMIT 1"
					);

					while ($row = mysql_fetch_array($abfrage))
					{
						$tx01 = $row["title"];
						$tx02 = $row["description"];
					}
					}

$txx=$tx02;$txxst = strpos($txx, '<vorreceiver>'); $txxst += 13; $txxen = strpos($txx, '</vorreceiver>', $txxst); 
$vorreceiver = substr($txx, $txxst, $txxen - $txxst); 

$txx2=$tx02;$txxst2 = strpos($txx2, '<fortransmitter>'); $txxst2 += 16; $txxen2 = strpos($txx2, '</fortransmitter>', $txxst2); 
$fortransmitter = substr($txx2, $txxst2, $txxen2 - $txxst2); 
		
$txx21=$tx02;$txxst21 = strpos($txx21, '<isbetreff>'); $txxst21 += 11; $txxen21 = strpos($txx21, '</isbetreff>', $txxst21); 
$isbetreff = substr($txx21, $txxst21, $txxen21 - $txxst21); 	
?>
<h3><?php echo elgg_echo('easy_talk:e:mail:content'); ?></h3>

<strong><?php echo elgg_echo('easy_talk:e:mail:from'); ?></strong>
<form action="" method="POST">
	<input type="hidden" name="savecode" value="savecodes">
	<textarea name="emailcontent" cols="60" rows="1"><?php echo "$tx01"; ?></textarea><br/>
	<strong><?php echo elgg_echo('easy_talk:e:mail:betreff'); ?></strong> <br/><textarea name="isbetreff" cols="60" rows="1"><?php echo "$isbetreff"; ?></textarea>
	<br/>
	<strong><?php echo elgg_echo('easy_talk:e:mail:empfaenger'); ?></strong><input type="text" name="vorreceiver" value="<?php echo "$vorreceiver"; ?>" />
	<strong><?php echo elgg_echo('easy_talk:e:mail:absender'); ?></strong><input type="text" name="fortransmitter" value="<?php echo "$fortransmitter"; ?>" />
	<br/>
	<strong><?php echo elgg_echo('easy_talk:e:mail:nachricht'); ?></strong><br/> 
	<?php
		$tx02 = str_replace ("<isbetreff>$isbetreff</isbetreff>", "", $tx02);
		$tx02 = str_replace ("<vorreceiver>$vorreceiver</vorreceiver>", "", $tx02);
		$tx02 = str_replace ("<fortransmitter>$fortransmitter</fortransmitter>", "", $tx02);
	?>

	<textarea name="talkhomebody" cols="60" rows="10"><?php echo "$tx02"; ?></textarea>
	<br/>
	<input type="hidden" name="coder" value="1">
	<input type="hidden" name="sendname" value="<?php echo "$talkaktusernameres"; ?>">

	<?php echo elgg_view('input/securitytoken'); ?>

	<?php echo elgg_echo('easy_talk:e:mail:content:alowed'); ?>
	<br/>
	<input class="button" type="submit" value="<?php echo "Save"; ?>" >

</form>
<a href=""><?php echo elgg_echo('easy_talk:e:mail:clear'); ?></a>




<?php
$isbetreff=$_POST["isbetreff"];
$vorreceiver=$_POST["vorreceiver"];
$fortransmitter=$_POST["fortransmitter"];
$homecontent=$_POST["talkhomebody"];
$talkhomebodycontent="
$homecontent
<isbetreff>$isbetreff</isbetreff><vorreceiver>$vorreceiver</vorreceiver><fortransmitter>$fortransmitter</fortransmitter>
";

if($_POST["coder"]=="1") {
$neuertext=$_POST["talkhomebody"]; 
// create a new blog object
						$blogpost = new ElggObject();
						$blogpost->subtype = "easy_talk";
						$blogpost->title = $_POST["emailcontent"]; 
						$blogpost->description = "$talkhomebodycontent"; 
						$blogpost->site_guid = "5555";
						$blogpost->access_id = "5555";
						// owner is logged in user
						$blogpost->owner_guid = "5555";
						// save to database
						$blogpost->save();
		
					
}
?>