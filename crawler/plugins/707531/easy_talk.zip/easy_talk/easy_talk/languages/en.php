<?php  /*
	 * @Plugin easy_talk
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Ilja Konrad & Dieter Konrad
     * @link http://www.onere.net/ & http://www.novalive.org
	 * @contact <onerenet@gmail.com>
	 * @copyright Ilja Konrad 2010
	 */
	 
	 
	 $english = array(

	'easy_talk:title' => "Easy Talk",
	'easy_talk:search:button' => "search",
	'easy_talk:welcome:message' => "Search for users on the left hand side or pick up a user to start a conversation.",
	'easy_talk:message:to' => "message subject:",
	'easy_talk:user:search:field' => "Find User",
	'easy_talk:message:send' => "Send",
	'easy_talk:messages:history' => "<< Messages History",
	'easy_talk:avatar:menu:link' => "Easy Talk",
	
	
	//begin email edit content
	'easy_talk:message:topic:recieved' => "You recieved a message",
	'easy_talk:message:recieved:hello' => "Hello",
	'easy_talk:message:body1' => "You got a message from ",
	'easy_talk:message:body2' => "",
	'easy_talk:message:body3' => "This Mail is a notification from ",
	'easy_talk:message:body4' => "You can't reply on this mail.",
	'easy_talk:message:urlhomename' => "you test urlhomename.",
	'easy_talk:message:talkaktuseremailadmin' => "test@email.cc",
	//end email edit content
	'easy_talk:e:mail:content' => "E-Mail Settings",
	'easy_talk:e:mail:empfaenger' => "Recipient",
	'easy_talk:e:mail:absender' => "Sender",
	'easy_talk:e:mail:nachricht' => "Your text: *",
	'easy_talk:e:mail:betreff' => "To:",
	'easy_talk:e:mail:content:alowed' => "* do not use special characters. Alowed aharacters A-Z 0-9",
	'easy_talk:e:mail:clear' => "Clear",
	
	'easy_talk:e:mail:from' => "From: (E-Mail showed to user)",

);

add_translation("en",$english);