<?php
  /*
	 * @Plugin easy_talk
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Ilja Konrad & Dieter Konrad
     * @link http://www.onere.net/ & http://www.novalive.org
	 * @contact <onerenet@gmail.com>
	 * @copyright Ilja Konrad 2010
	 */


$german = array(

	'easy_talk:title' => "Easy Talk",
	'easy_talk:search:button' => "suchen",
	'easy_talk:welcome:message' => "Wähle auf der linken Seite einen Unterhaltungspartner um Nachrichten zu lesen oder neue Nachricht zu schreiben",
	'easy_talk:message:to' => "Nachricht an:",
	'easy_talk:user:search:field' => "Benutzersuche",
	'easy_talk:message:send' => "Absenden",
	'easy_talk:messages:history' => "<< Nachrichtenverlauf",
	'easy_talk:avatar:menu:link' => "Schnellnachricht",
	
	
	//begin email edit content
	'easy_talk:message:topic:recieved' => "Sie haben gerade eine neue Nachricht bekommen.",
	'easy_talk:message:recieved:hello' => "Hallo",
	'easy_talk:message:body1' => "Sie haben gerade eine neue Nachricht von",
	'easy_talk:message:body2' => "bekommen",
	'easy_talk:message:body3' => "Du erhälst diese Info-E-Mail, weil du auf",
	'easy_talk:message:body4' => "Angemeldet bist.",
	'easy_talk:message:urlhomename' => "Deine Domain",
	'easy_talk:message:talkaktuseremailadmin' => "test@email.cc",
    //end email edit content
	'easy_talk:e:mail:content' => "E-Mail Einstellungen",
	'easy_talk:e:mail:empfaenger' => "Empfänger",
	'easy_talk:e:mail:absender' => "Absender",
	'easy_talk:e:mail:nachricht' => "Text der Nachricht: *",
	'easy_talk:e:mail:betreff' => "Betreff:",
	'easy_talk:e:mail:content:alowed' => "* Benutze keine Sonderzeichen. Erlaubte Zeichen: A-Z 0-9",
	'easy_talk:e:mail:clear' => "Inhalt löschnen",
	
	'easy_talk:e:mail:from' => "Von: (E-Mail die dem User angezeigt wird.)",

);

add_translation("de",$german);