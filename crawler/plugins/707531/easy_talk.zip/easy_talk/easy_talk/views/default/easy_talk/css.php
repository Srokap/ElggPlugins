<?php
  /*
	 * @Plugin easy_talk
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Ilja Konrad & Dieter Konrad
     * @link http://www.onere.net/ & http://allesubuntu.de/
	 * @contact <onerenet@gmail.com>
	 * @copyright Ilja Konrad 2010
	 */
	 ?>


.et_talkicon
{
	position: absolute;
	margin: -17px 0 0 27px;
	font-size:9px;
}
/* IE 6 */
* html .et_talkicon {
	position: absolute;
	margin: 3px 0 0 -12px;
}
/* IE 7 */
* + html .et_talkicon {
	position: absolute;
	margin: 3px 0 0 -12px;
}
.et_talkicon :hover
{
	text-decoration: none;
}
.et_talkicon P
{
	position: relative;
	left: 23px;
	top: -16px;
}
/* IE 6 */
* html .et_talkicon P
{

	position: relative;
	left: 23px;
	top: -20px;

}
/* IE 7 */
* + html .et_talkicon P
{

	position: relative;
	left: 23px;
	top: -20px;

}


