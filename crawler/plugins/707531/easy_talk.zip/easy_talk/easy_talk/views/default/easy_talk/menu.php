<?php
  /*
	 * @Plugin easy_talk
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Ilja Konrad & Dieter Konrad
     * @link http://www.onere.net/ & http://allesubuntu.de/
	 * @contact <onerenet@gmail.com>
	 * @copyright Ilja Konrad 2010
	 */

$baseuser = $vars['entity']->name;

?>
				
<p class="user_menu_profile">	
 <a href="javascript: void(0)" onclick="talkfenster('<?php echo $vars['url']; ?>mod/easy_talk/index.php?&btalkcode=<?php echo "$baseuser"; ?>&codetalks=talks&numcode=0&coder=1')"><?php echo elgg_echo("easy_talk:avatar:menu:link"); ?></a>

</p>

