<p>
	<p>
		<select name="params[schowAvatarMenuLink]">
		<option value="yes" <?php if ($vars['entity']->schowAvatarMenuLink == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->schowAvatarMenuLink == 'no' || empty($vars['entity']->schowAvatarMenuLink)) echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
		</select>
		<?php echo elgg_echo("Avatar Menülink anzeigen?");?><br /><br />

	</p>
</p>

<a href="javascript: void(0)" 
   onclick="talkfenster('<?php echo $vars['url']; ?>mod/easy_talk/save.php')"><strong><?php echo elgg_echo('easy_talk:e:mail:content'); ?></strong></a>	
