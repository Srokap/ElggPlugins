
	<?php
	
  /*
	 * @Plugin easy_talk
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Ilja Konrad & Dieter Konrad
     * @link http://www.onere.net/ & http://allesubuntu.de/
	 * @contact <onerenet@gmail.com>
	 * @copyright Ilja Konrad 2010
	 */
 
		// Load Elgg engine 
		include_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

		//  nur f�r eingeloggte user Das ist die Gatekeeper funktion 
		gatekeeper();
		$idres = get_loggedin_userid ();
		$datencode = "{$CONFIG->dbprefix}";


		$abfrage = mysql_query("SELECT * FROM {$CONFIG->dbprefix}entities WHERE site_guid = '$idres' and type = 'object' and access_id = '1000' and enabled = 'yes'");
		$numr = mysql_num_rows($abfrage);

if ($numr == '0')
{
?>

<a href="javascript: void(0)" 
   onclick="talkfenster('<?php echo $vars['url']; ?>mod/easy_talk/index.php')"><strong>TALK</strong></a>	


<?php 
} 
else
{
$abfrage = mysql_query("SELECT * FROM {$CONFIG->dbprefix}entities WHERE site_guid = '$idres' and type = 'object' and access_id = '1000' and enabled = 'yes'");
$numr = mysql_num_rows($abfrage);
?>

<a href="javascript: void(0)" 
   onclick="talkfenster('<?php echo $vars['url']; ?>mod/easy_talk/index.php')"><strong>TALK</strong></a>
	<u style="color:green;"><?php  echo $numr; ?></u>


<?php
}
?>