<?php
    /*
	 * @Plugin easy_talk
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Ilja Konrad & Dieter Konrad
     * @link http://www.onere.net/ & http://allesubuntu.de/
	 * @contact <onerenet@gmail.com>
	 * @copyright Ilja Konrad 2010
	 */

// Load Elgg engine 
include_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

gatekeeper();

$idres = get_loggedin_userid ();
$urlcode = $inurlhost;

$abfrage = mysql_query("SELECT * FROM {$CONFIG->dbprefix}entities WHERE owner_guid = '$idres' and type = 'object' and access_id > '100' and enabled = 'yes'");
$numrsortuser1 = mysql_num_rows($abfrage);

for ($T01=0; $T01<=$numrsortuser1; $T01++)
{
	$abfrage = mysql_query(
		"SELECT *
		FROM {$CONFIG->dbprefix}entities
		WHERE owner_guid = '$idres'
		AND TYPE = 'object'
		and access_id > '100'
		ORDER BY guid DESC
		LIMIT $T01 , 1"
	);

	while ($row = mysql_fetch_array($abfrage))
	{
		$in_title1 = $row["site_guid"];
		$inguiduser1 = $row["guid"];

		$abfrage = mysql_query(
			"SELECT *
			FROM `{$CONFIG->dbprefix}users_entity`
			WHERE `guid` LIKE '$in_title1'
			LIMIT 1"
		);
		
		while ($row = mysql_fetch_array($abfrage))
		{
			$nameofuser1 = $row["name"];			
			$talkusersortcode[$inguiduser1] = "$nameofuser1";
		}
	}
}            	

$abfrage = mysql_query("SELECT * FROM {$CONFIG->dbprefix}entities WHERE site_guid = '$idres' and type = 'object' and access_id > '100' and enabled = 'yes'");
$numrsortuser2 = mysql_num_rows($abfrage);

for ($T02=0; $T02<=$numrsortuser2; $T02++)
{
	$abfrage = mysql_query(
		"SELECT *
		FROM {$CONFIG->dbprefix}entities
		WHERE site_guid = '$idres'
		AND TYPE = 'object'
		and access_id > '100'
		ORDER BY guid DESC
		LIMIT $T02 , 1"
	);

	while ($row = mysql_fetch_array($abfrage))
	{
		$in_title2 = $row["owner_guid"];
		$inguiduser2 = $row["guid"];

		$abfrage = mysql_query(
			"SELECT *
			FROM `{$CONFIG->dbprefix}users_entity`
			WHERE `guid` LIKE '$in_title2' 
			LIMIT 1"
		);
		
		while ($row = mysql_fetch_array($abfrage))
		{
			$nameofuser2 = $row["name"];
			$talkusersortcode[$inguiduser2] = "$nameofuser2";
		}
	}
}

?>

