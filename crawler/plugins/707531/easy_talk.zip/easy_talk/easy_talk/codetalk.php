<?php
  /*
	 * @Plugin easy_talk
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Ilja Konrad & Dieter Konrad
     * @link http://www.onere.net/ & http://allesubuntu.de/
	 * @contact <onerenet@gmail.com>
	 * @copyright Ilja Konrad 2010
	 */
// Load Elgg engine
    include_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
  // make sure only logged in users can see this page	
    gatekeeper();
	
	$idres = get_loggedin_userid ();

	//abfrage guiduser
	$btalkcode = $_GET["btalkcode"];
$abfrage = mysql_query(
			"SELECT *
			FROM `{$CONFIG->dbprefix}users_entity`
			WHERE `name` = '".mysql_real_escape_string($_GET['btalkcode'])."' 
			LIMIT 1"
		);
while ($row = mysql_fetch_array($abfrage))
		{
			$nameofuser = $row["guid"];
}	

if ($_GET[codetalks] == 'talks') { 


//ausgabe nachrichten
$n1 = $_GET[numcode]-1;

//�ndern zahl nachrichten
$abfrage = mysql_query("UPDATE {$CONFIG->dbprefix}entities SET access_id = '1001' WHERE access_id = '1000' and type = 'object' and enabled = 'yes' and site_guid = '$idres' and owner_guid = '$nameofuser'") 
or die(mysql_error());

//abfrage db

//wieviel nachrichten

	//abfrage guiduser
$abfrage = mysql_query(
			"SELECT *
			FROM `{$CONFIG->dbprefix}users_entity`
			WHERE `name` = '".mysql_real_escape_string($_GET['btalkcode'])."' 
			LIMIT 1"
		);
while ($row = mysql_fetch_array($abfrage))
		{
			$nameofuser = $row["guid"];
}

	$abfrage = mysql_query("SELECT * FROM {$CONFIG->dbprefix}entities WHERE site_guid = '$idres' and owner_guid = '$nameofuser' and type = 'object' and enabled = 'yes'");
	$allnumruser1 = mysql_num_rows($abfrage); 
	$abfrage = mysql_query("SELECT * FROM {$CONFIG->dbprefix}entities WHERE site_guid = '$nameofuser' and owner_guid = '$idres' and type = 'object' and enabled = 'yes'");
	$allnumruser2 = mysql_num_rows($abfrage); 
	$allnumrusers = $allnumruser1+$allnumruser2;
	
if ($allnumrusers < '10')
{
$nummerdbminus = $allnumrusers-1;
$nummerdb = $nummerdbminus;
$startcode = $_GET[numcode];
}
else
{

if ($_GET[numcode] == '0')
{
$startcode = $_GET[numcode];
$nummerdb = "9";
}
else
{
$startcode = $_GET[numcode]+1;
$nummerdb = $_GET[numcode]+10;
}

}
//ge�ndert
for ($i1=$startcode; $i1<=$nummerdb; $i1++)
		{
		
$abfrage = mysql_query(
"SELECT owner_guid, title, description, time_created, guid, site_guid
FROM {$CONFIG->dbprefix}entities
NATURAL JOIN {$CONFIG->dbprefix}objects_entity
WHERE owner_guid = '$idres' and site_guid = '$nameofuser' and access_id = '1000' and enabled = 'yes'
OR owner_guid = '$nameofuser' and site_guid = '$idres' and access_id = '1000' and enabled = 'yes'
OR owner_guid = '$idres' and site_guid = '$nameofuser' and access_id = '1001' and enabled = 'yes'
OR owner_guid = '$nameofuser' and site_guid = '$idres' and access_id = '1001' and enabled = 'yes'
ORDER BY `time_created` DESC LIMIT $i1, 1");


			while ($row = mysql_fetch_array($abfrage))
			{
				$tx1 = $row["title"];
				$tx2 = $row["description"];	
				$t1 = $row["time_created"];
				$useridres = $row["site_guid"];
				$g1 = $row["guid"];
				$useridan = $row["owner_guid"];
	}
//ge�ndert

	$abfrage = mysql_query(
						"SELECT *
						FROM `{$CONFIG->dbprefix}users_entity`
						WHERE `username` LIKE '%$tx1%' 
						LIMIT 1"
					);

					while ($row = mysql_fetch_array($abfrage))
					{
						$txusername = $row["name"];

}

$diezeit = date("H:i",$t1);
$diezeittitle = date("d.m.Y",$t1);

$codetx2 = $tx2;
if($idres == $useridres)
		{
			$talksortcode[] = "<div class=\"et_nachricht\"><div style=\"color:#228DF0;\" class=\"et_username_nachricht\">
			$txusername
			</div> 
			<div class=\"et_nachricht_text\"> 
			<div class=\"et_time_right\"><ref name=\"#\" title=\"$diezeittitle\">$diezeit</a> </div> 
			$codetx2 
			</div>
			</div>
			<div class=\"et_clearfloat\"></div>";
		}
		else
		{	
			$talksortcode[] = "<div class=\"et_nachricht\"><div style=\"color:#8C8E91;\" class=\"et_username_nachricht\">
			$txusername
			</div> 
			<div class=\"et_nachricht_text\"> 
			<div class=\"et_time_right\"><ref name=\"#\" title=\"$diezeittitle\">$diezeit</a> </div> 
			$codetx2 
			</div>
			</div>
			<div class=\"et_clearfloat\"></div>";
		}

}	

	
//weitere nachrichten
	$abfrage = mysql_query("SELECT * FROM {$CONFIG->dbprefix}entities WHERE site_guid = '$idres' and owner_guid = '$nameofuser' and type = 'object' and enabled = 'yes'");
	$allnumr1 = mysql_num_rows($abfrage); 
	$abfrage = mysql_query("SELECT * FROM {$CONFIG->dbprefix}entities WHERE site_guid = '$nameofuser' and owner_guid = '$idres' and type = 'object' and enabled = 'yes'");
	$allnumr2 = mysql_num_rows($abfrage); 
	$allnumr = $allnumr1+$allnumr2;

if ($_GET[numcode] == '0')
{	
$nums3 = $_GET[numcode]+9;
}
else
{	
$nums3 = $_GET[numcode]+10;
}
$mincode = $allnumr-$numcode;
$n10 = "10";

	if($mincode > $n10)
  {
  echo "<a href='?btalkcode=$btalkcode&codetalks=talks&numcode=$nums3&coder=1'>";
  ?>
  
  <div id='af'><?php echo elgg_echo("easy_talk:messages:history"); ?></div>
  
  <?php
  echo "</a>";
  }

krsort($talksortcode);
				
foreach ($talksortcode as $keytalkcodessort => $valtalkcodessort) {
				$wwwtalkcodesort = "$valtalkcodessort";
				echo "$wwwtalkcodesort";
				 }		
		
		
if ($_POST[aktuelltime] == 'uhrzeitcontent') { 
$timestamp = time();
  $uhrzeitcontent = date("H:i",$timestamp);

  echo "<p>";
			echo "<div style=\"color:#8C8E91;\" class=\"et_username_nachricht\">\n"; 
			echo "$_POST[sendname]\n"; 
			echo "</div>\n"; 
			echo "<div class=\"et_nachricht_text\">\n"; 
			echo "<div class=\"et_time_right\">$uhrzeitcontent</div>\n"; 
			echo "$_POST[talkhomebody]\n"; 
			echo "</div>\n";
			echo "<div class=\"et_clearfloat\"></div>\n";
	echo "</p>";		
	
	}		
				

}
?>