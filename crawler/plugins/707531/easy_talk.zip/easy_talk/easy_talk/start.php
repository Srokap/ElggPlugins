<?php

	function easy_talk_init()	{
	
		// Load system configuration
		global $CONFIG;
		
		//css erweitern
		elgg_extend_view('css','easy_talk/css');
		elgg_extend_view('css','easy_talk/css2');
		
		//javascriptcode von fancybox
		elgg_extend_view('js/initialise_elgg','easy_talk/js');
		
		//fancybox link f�r head bereich
		elgg_extend_view('metatags','easy_talk/metatags');
		
		//brief icon im topbar
		elgg_extend_view('elgg_topbar/extend','brief');
		
		//men� link f�r den avatar
		$schowAvatarMenuLink = get_plugin_setting("schowAvatarMenuLink","easy_talk");
		if(empty($schowAvatarMenuLink) || $schowAvatarMenuLink == "no"){

		} else {
			elgg_extend_view('profile/menu/links','easy_talk/menu', 501);
		}	
	}

	register_elgg_event_handler('init', 'system', 'easy_talk_init');
