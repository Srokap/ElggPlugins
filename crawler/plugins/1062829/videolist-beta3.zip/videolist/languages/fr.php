<?php
$fr = array (
  'videolist' => 'Mes videos',
  'videolist:home' => '%s \'s Videos',
  'videolist:new' => 'ajouter une video',
  'videolist:find' => 'toutes les videos',
  'videolist:search' => 'toutes les videos',
  'videolist:submit' => 'envoie',
  'videolist:widget' => 'Mes videos',
  'videolist:widget:description' => 'tes videos de youtube',
  'videolist:num_videos' => 'nombre de videos à afficher',
  'profile:videoheader' => 'ma galerie video',
  'videolist:tags' => 'ajoute des tags',
  'videolist:browse' => 'cherche des videos - %s',
  'videolist:browsemenu' => 'cherche des videos',
  'videolist:title_search_tube' => 'cherche des videos de',
  'videolist:searchTubeVideos' => 'cherche sur youtube.com',
  'videolist:comments' => 'commentaires',
  'videolist:commentspost' => 'poste',
  'videolist:river:item' => 'une video',
  'videolist:river:created' => '%s a ajouté',
  'videolist:group' => 'Videos',
  'videolist:groupall' => 'toutes les vidoes du groupe',
  'videolist:none' => 'ce groupe n\'as pas encore de videos',
);

add_translation("fr", $fr);

