<?php
$gl = array (
  'videolist' => 'Os meus vídeos',
  'videolist:home' => 'Vídeos de %s',
  'videolist:new' => 'Engadir vídeos',
  'videolist:find' => 'Vídeos de toda a rede',
  'videolist:search' => 'Procurar vídeos',
  'videolist:submit' => 'Aceptar',
  'videolist:widget' => 'Os meus vídeos',
  'videolist:widget:description' => 'Podes comparti-la túa galería de vídeos personalizada co resto da rede',
  'videolist:num_videos' => 'Número de vídeos a mostrar',
  'profile:videoheader' => 'As miñas galerías de vídeos',
  'videolist:tags' => 'Engadir etiquetas',
  'videolist:browse' => 'Procura-los vídeos de %s',
  'videolist:browsemenu' => 'Procurar vídeos',
  'videolist:title_search_tube' => 'Procurar vídeos en:',
  'videolist:searchTubeVideos' => 'Procurar en youtube',
  'videolist:comments' => 'Comentarios',
  'videolist:commentspost' => 'Entrada',
  'videolist:river:item' => 'un vídeo titulado:',
  'videolist:river:created' => '%s engadiu',
  'videolist:group' => 'Vídeos do grupo',
  'videolist:groupall' => 'Tódolos vídeos do grupo',
  'videolist:none' => 'O non hai vídeos subidos.',
  'videolist:edit' => 'Editar vídeo %s',
);

add_translation("gl", $gl);

