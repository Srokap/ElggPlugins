<?php
/**
 * Elgg Videolist CSS
 */
?>

.videolist-watch {
	margin-top: 40px;
	margin-left: 20px;
}
