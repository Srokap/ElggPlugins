<?php
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	$comment_guid = get_input('comment_guid',0);
	$comments = null;
	if ($comment_guid){ 
		$comments = vazco_comments::getChildComments($comment_guid);
	}
	if ($comments){
		foreach($comments as $comment){
			echo elgg_view('annotation/generic_comment', array('annotation' => $comment));
		}
	}else{
		//echo elgg_echo('vazco_comments:nochildcomments');
	}
?>