<?php

	/**
	 * Elgg generic comment
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.org/
	 * 
	 */

	$owner = get_user($vars['annotation']->owner_guid);
	
	$comment = $vars['annotation']->value;
	$parent_guid = $vars['annotation']->parent_id;
	global $CONFIG;
?>


	<div class="generic_comment"><!-- start of generic_comment div -->
	    
		<div class="generic_comment_icon">	        
    		<?php
    			echo elgg_view("profile/icon",
    						array(
    							'entity' => $owner, 
    							'size' => 'small'));
    		?>
		</div>
		<div class="generic_comment_details">
    		
		    <!-- output the actual comment -->
		    <?php echo elgg_view("output/longtext",array("value" => $comment)); ?>
		    
		    <p class="generic_comment_owner">
    	        <a href="<?php echo $owner->getURL(); ?>"><?php echo $owner->name; ?></a> <?php echo friendly_time($vars['annotation']->time_created); ?>
    		</p>
		    

		    <p class="v_comments_inteply">
		    <?php
		        // if the user looking at the comment can edit, show the delete link
			    if ($vars['annotation']->canEdit() || $vars['annotation']->owner_guid == get_loggedin_userid()) {
			        echo elgg_view("output/confirmlink",array(
														'href' => $vars['url'] . "action/comments/delete?annotation_id=" . $vars['annotation']->id,
														'text' => elgg_echo('delete'),
														'confirm' => elgg_echo('deleteconfirm'),
			        									'class' => 'v_comments_reply_delete',
													));
			    } //end of can edit if statement
		    ?>
		        <a id="v_comments_inteply_<?php echo $vars['annotation']->id;?>" class="v_comments_reply_link" href="#comment_reply"><?php echo elgg_echo('vazco_comment:reply');?></a>
		    </p>
			<p>
				
			</p>
		</div><!-- end of generic_comment_details -->
	</div><!-- end of generic_comment div -->
	<?php echo elgg_view('vazco_comments/js', array('annotation' => $vars['annotation'], 'owner' => $owner, 'action' => 'mod/vazco_comments/comments.php?comment_guid='.$vars['annotation']->id));?>
</script>