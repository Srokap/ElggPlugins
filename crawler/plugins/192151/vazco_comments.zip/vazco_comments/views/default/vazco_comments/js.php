<?php 
global $CONFIG;
$annotation = $vars['annotation'];
$owner = $vars['owner'];
$action = $vars['action'];
$displayAllAtOnce = (get_plugin_setting('displayall','vazco_comments') == 'yes');
$action = $CONFIG->wwwroot.$action;
$function = null;
if ($vars['function'])
	$function = $vars['function'];
?>
<script type='text/javascript'>
$(document).ready(function() {
   $("#v_comments_inteply_<?php echo $annotation->id;?>").click(function() {
	   $("#v_comments_inteply_content").html("<?php echo $owner->name.' ('.friendly_time($annotation->time_created).')';?>");
	   $("#v_comments_reply").val("<?php echo $owner->name;?>");
	   $("#v_comments_inteply").animate({ opacity: 'hide' }, 'fast').animate({ opacity: 'show' }, 'slow');
	   $(".forum_edit_hidden").show('slow');
	   $("#v_parent_comment_id").val("<?php echo $annotation->id;?>");
   });
});

<?php if ($displayAllAtOnce){?>
	$("#sub_comments_content_<?php echo $annotation->id;?>").load("<?php echo $action;?>");
	$("#sub_comments_<?php echo $annotation->id;?>").hide();
<?php }else{?>
	$(document).ready(function() {
	   $("#sub_comments_<?php echo $annotation->id;?>").click(function() {
		   $("#sub_comments_content_<?php echo $annotation->id;?>").load("<?php echo $action;?>");
		   $("#sub_comments_<?php echo $annotation->id;?>").hide();
		   return false;
	   });
	});
<?php }?>
</script>