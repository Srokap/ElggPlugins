#v_comments_inteply{
	display: none;
	float: right;
}
	
p.v_comments_inteply a{
	float:left;
}

p.v_comments_inteply .v_comments_reply_link{
	float:right;
	margin-left: 65px;
}

p.v_comments_inteply{
	height: 20px;
}

#v_comments_inteply_content{
	font-weight: bold;
}

.v_post_reply{
	display: inline;
}

.topic-post-menu .v_comments_reply_link{
	float:right;
	margin-left: 65px;
}

.collapsibleboxlink,
.postdeletelink{
	float: left;
}
.generic_comment .generic_comment{
	padding: 10px 0;
	margin: 0;
}

.v_sub_content{
	marign: 0;
	padding:0;
}
.topic_post .topic_post .topic_post{
	padding: 0;
}

.v_collapsible_box{
	display: none;
}

.v_edit_forum_comments{
	width: 650px;
}

.topic_post p.topic-post-menu a.v_collapsibleboxlink {
	padding-left: 10px;
}

.forum_edit_hidden{
	display: none;
}

.topic_post .topic_post{
	-moz-border-radius:8px;
	background:white none repeat scroll 0 0;
	margin:0 0 5px;
	padding:10px;

}
.topic_post .postBox{
	background: white;
	-moz-border-radius:8px;
	padding: 10px;
	margin:0;
}

.topic_post .topic_post .postBox{
	background: none;
	padding: 0;
	margin: 0 0 0 25px;
}

.topic_post .topic_post .topic_post .postBox{
	margin-left:50px;
}

.topic_post .topic_post .topic_post .topic_post .postBox{
	margin-left:75px;
}


.topic_post {
	padding:5px 0;
}