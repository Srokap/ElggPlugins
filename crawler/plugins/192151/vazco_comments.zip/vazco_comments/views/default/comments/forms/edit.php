<?php

    /**
	 * Elgg comments add form
	 * 
	 * @package Elgg
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 * 
	 * @uses $vars['entity']
	 */
?>
<?php 

	 $commentReplyTitle =  "<div id='v_comments_inteply'><a name='comment_reply'>&nbsp;</a> ".elgg_echo('vazco_comment:inreply')." <span id='v_comments_inteply_content'></span><input name='parent_id' type='hidden' id='v_parent_comment_id' value='0'></div>";
	 if (isset($vars['entity']) && isloggedin()) {
		 $form_body = "<div class=\"contentWrapper\">".$commentReplyTitle."<p class='longtext_editarea'><label>".elgg_echo("generic_comments:text")."<br />" . elgg_view('input/longtext',array('internalname' => 'generic_comment')) . "</label></p>";
		 $form_body .= "<p>" . elgg_view('input/hidden', array('internalname' => 'entity_guid', 'value' => $vars['entity']->getGUID(), 'js' => 'id="comment_entity_guid"'));
		 $form_body .= elgg_view('input/submit', array('value' => elgg_echo("save"))) . "</p></div>";
		$form_body .='<input type="hidden" id="v_comments_reply" name="v_comments_reply" value="">';
		 echo elgg_view('input/form', array('body' => $form_body, 'action' => "{$vars['url']}action/comments/add"));

    }
    
?>