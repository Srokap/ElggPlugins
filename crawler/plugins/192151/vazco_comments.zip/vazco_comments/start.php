<?php

	/**
	 * Elgg invite page
	 * 
	 * @author Micha� Zacher
	 * @copyright Curverider Ltd 2008
	 */

	function vazco_comments_init() {		
		global $CONFIG;

		extend_view('css','vazco_comments/css');
		register_action("vazco_comments/setup",false,$CONFIG->pluginspath . "vazco_comments/actions/database.php");
		register_elgg_event_handler('create', 'annotation', 'vazco_comments_annotation_handler');
	}
	
	
	function vazco_comments_annotation_handler($event, $object_type, $object){
		if ($object->name == 'generic_comment' 
			|| $object->name == 'group_topic_post'){
			$parent_id = (int) get_input('parent_id');
			$prefix = get_input('v_comments_reply','');
			if ($prefix != '')
				$prefix = elgg_echo('vazco_comments:inreply:start').$prefix.elgg_echo('vazco_comments:inreply:end');
			$object->value = $prefix.$object->value;
			$object->save();
			//in case this is answer to some other post, set entity_guid to this post's id 
		}
	}
	
	register_elgg_event_handler('init','system','vazco_comments_init');
?>