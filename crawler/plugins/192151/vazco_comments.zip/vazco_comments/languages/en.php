<?php

	$english = array(
		'vazco_comment:inreply' => 'In reply to:',
		'vazco_comment:reply' => 'Reply',
		'vazco_comments:database' => 'Setup database',
		'vazco_comments:database:success' => 'Database set up succesfully',
		'vazco_comments:database:error' => 'Error while setting up database',
		'vazco_comments:number' => 'View answers: %s',
		'vazco_comments:nochildcomments' => 'This comment has no answers yet',
		'vazco_topbar:settings:displayall' => 'Display all child comments at once',
		'vazco_comments:post:edit' => 'Edit post',
		'vazco_comments:settings:forumanswersonly' => 'Posts in forum can be only answers to other posts or only new topics',
		'vazco_comments:inreply:start' => 'In reply to: ',
		'vazco_comments:inreply:end' => '<br/>',
	);
					
	add_translation("en",$english);
?>