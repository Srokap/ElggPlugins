<?php
/**
 * Elgg Feedback plugin
 * Feedback interface for Elgg sites
 *
 * for Elgg 1.8 by iionly
 * iionly@gmx.de
 *
 * Widget edit view
 */
?>

.submitted-feedback {
    margin: 5px 0 0;
    padding: 5px 7px 3px 9px;
    border: 1px solid #666666;
    -webkit-border-radius: 5px;
    -moz-border-radius: 5px;
    border-radius: 5px;
}
