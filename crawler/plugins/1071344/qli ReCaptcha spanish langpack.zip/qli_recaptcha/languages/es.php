<?php
	/**
	 * Elgg recaptcha language pack extension.
	 * 
	 * @package qli_recaptcha
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author RPGRealms
	 * @copyright RPGRealms 2010
	 */

	// Note, the captcha:lang may not actually do anything currently
	// And would be strictly for audio
	
	$english = array(
	
		'captcha:privatekey' => "Clave privada reCAPTCHA",
		'captcha:publickey' => "Clave pública reCAPTCHA",
		'captcha:captchafail' => "El reCAPTCHA no fue ingresado correctamente. Regresa a la página anterior e intenta de nuevo.", 
		'captcha:instructions_visual' => "Escribe las dos palabras:",
		'captcha:instructions_audio' => "Escribe lo que oyes:",
		'captcha:play_again' => "Reproducir sonido de nuevo",
		'captcha:cant_hear_this' => "Descargar sonido como MP3",
		'captcha:visual_challenge' => "Obtener prueba vusial",
		'captcha:audio_challenge' => "Obtener prueba de audio",
		'captcha:refresh_btn' => "Nueva prueba",
		'captcha:help_btn' => "Ayuda",
		'captcha:incorrect_try_again' => "Incorrecto. Intentalo de nuevo.",
		'captcha:lang' => "es", 					
		'captcha:theme' => "blue",

	);
	add_translation("es",$spanish);
?>