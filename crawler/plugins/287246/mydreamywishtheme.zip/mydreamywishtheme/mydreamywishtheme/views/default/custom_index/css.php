<?php
	/**
	 * Custom Index page css extender
	 * 
	 * @package custom_index
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider <info@elgg.com>
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.org/
	 */
?>

#custom_index {
    width:925px;
    padding:0px;
}
#index_left {
    width:300px;
    float:left;
    height:auto;
    margin:0 10px 5px 0;
    padding:2px;
}

#index_middle {
    width:300px;
    float:left;
    margin:0 10px 20px 0;
    padding:0 0px 10px 0;
}
#index_right {
    width:300px;
    float:right;
    margin:0 0 10px 0;
    padding:0 0px 10px 0;
}
#index_welcome {
margin:0 0 10px;
padding:0px;
border:1px solid #78b503;
background:#fff url(<?php echo $vars['url']; ?>mod/buddytalk/graphics/index_back.gif) repeat-x top;

}
#index_welcome h2{
text-transform:uppercase;
font-size:15px;
font-family:arial;
text-align:left;
font-weight:bold;
line-height:30px;
padding-left:10px;
color:#78b503;
padding-left:10px;
margin:0;
margin-bottom:20px;
}
#index_welcome #login-box {
	margin:5px 0 10px 0;
    padding:0 0 10px 0;
	width:200px;
}
#welcomemessage{
 background: #d6ebc5;
 width:600px;
 padding:5px;
 height: 200px;
}
#welcomemessage h2{
color:#fff;
background:#d6ebc5;
width:160px;
border:1px solid #ccc;
font-size:1px;
padding:2px;
}
#welcomemessage.content{
color:white;
font-size:18px;
padding-left:10px;

}

#index_welcome #login-box h2,
.index_box h2 {
color:#333;
text-transform:uppercase;
font-size:14px;
font-family:arial;
text-align:left;
font-weight:bold;
line-height:30px;
padding-left:10px;
margin:5px;


}
#index_welcome #login-box h2 {
	padding-bottom:10px;
}

.index_box {
margin:0 0 10px;
padding:0px;
border:1px solid #ccc;
}

.index_box h2{
color:#78b503;
padding-left:10px;
margin:0;
margin-bottom:10px;
}
.index_box .search_listing {

}
.index_box .index_members {
	float:left;
	margin:2pt 5px 3px 0pt;
    border:1px solid #78b503;
}
#persistent_login {
	float:right;
	display:block;
	margin-top:-30px;
}


#intro_box1{
  float:right;
  height:222px;
  margin-top:3px;
  width:608px;
  clear:right;
  margin-bottom:11px;
background:#d6ebc5 url(<?php echo $vars['url']; ?>mod/buddytalk/graphics/index_back.gif) repeat-x top;
  border:1px solid #78b503;
}

#menuback1{
  height:48px;
  width:564px;
  margin-left:25px;
  padding:10px;
  background: transparent url(<?php echo $vars['url']; ?>mod/buddytalk/graphics/topmenu.png) no-repeat;
}
#menuback1 a{
color:white;
font-size:12px;
text-transform:uppercase;
}