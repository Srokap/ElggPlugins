<?php

      
	global $CONFIG;
	
	$form_body = "<p class=\"loginbox\"><label>" . elgg_echo('username') . elgg_view('input/text', array('internalname' => 'username', 'class' => 'login-textarea')) . "</label>";
	$form_body .= "<br />";
	$form_body .= "<label>" . elgg_echo('password') . "&nbsp;" . elgg_view('input/password', array('internalname' => 'password', 'class' => 'login-textarea')) . "</label><br />";
	$form_body .= elgg_view('input/submit', array('value' => elgg_echo('login')))."<br />";
    $form_body .= "<label><input type=\"checkbox\" name=\"persistent\" value=\"true\" />&nbsp;".elgg_echo('user:persistent')."</label><br /><br />";
	$form_body .= "<a href=\"{$vars['url']}account/forgotten_password.php\">" . elgg_echo('user:password:lost') . "</a>  |  ";  
	$form_body .= "<a href=\"{$vars['url']}account/forgotten_password.php\">" . elgg_echo('register') . "</a>";  
	

	$login_url = $vars['url'];
	if ((isset($CONFIG->https_login)) && ($CONFIG->https_login))
		$login_url = str_replace("http", "https", $vars['url']);
?>
	
	<div id="login-box">
    
		<?php 
			echo elgg_view('input/form', array('body' => $form_body, 'action' => "{$login_url}action/login"));
		?>
		
	</div>