<?php

	/**
	 * Elgg header contents 
	 * This file holds the header output that a user will see
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2009
	 * @link http://elgg.org/
	 **/
	 
?>
<style type="text/css">
<!--
.style2 {color: #FFFFFF}
-->
</style>

<div id="page_container">
<div id="page_wrapper">

<div id="layout_header">
<div id="wrapper_header">
   <div style="margin-left:12px; width:230px; height:80px;">
     <a href="<?php echo $vars['url']; ?>"><img src="<?php echo $vars['url']; ?>mod/mydreamywishtheme/graphics/logo.png" width="222" height="72" border="0" /></a>      </div>

  
</div>
<!-- /#wrapper_header -->
</div><!-- /#layout_header -->