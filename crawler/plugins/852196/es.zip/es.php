<?php

$spanish = array(

	'hj:events' => 'Eventos',
	'hj:events:menu:owner_block' => 'Eventos',

	'item:object:hjevent' => 'Evento',
	'items:object:hjevent' => 'Eventos',
	
	'hj:hjportfolio:hjevent' => 'Eventos',
	'hj:portfolio:hjevent' => 'Eventos',
	
	'hj:events:timeformat' => 'H:i',
	'hj:events:dateformat' => 'F j, Y',
	'hj:events:fulltimeformat' => 'F j, Y G:i T',

	'hj:label:form:new:hypeEvents:event' => 'Crear un evento',
	'hj:label:form:edit:hypeEvents:event' => 'Editar evento',

	'item:object:hjevent' => 'Evento',
	'items:object:hjevent' => 'Eventos',
	
	'river:create:object:hjevent' => '%s Cre&oacute; un nuevo evento | %s',
	'river:update:object:hjevent' => '%s Actualiz&oacute; un evento | %s',

	'hj:label:hjevent:icon' => 'Icono del evento',
	'hj:label:hjevent:title' => 'T&iacute;tulo',
	'hj:label:hjevent:description' => 'Descripci&oacute;n',
	'hj:label:hjevent:calendar_start' => 'Comienza',
	'hj:label:hjevent:calendar_end' => 'Finaliza',
	'hj:label:hjevent:host' => 'Anfitri&oacute;n/Organizador',
	'hj:label:hjevent:venue' => 'Lugar',
	'hj:label:hjevent:location' => 'Direcci&oacute;n',
	'hj:label:hjevent:contact_details' => 'Informaci&oacute;n de contacto',
	'hj:label:hjevent:www' => 'Website',
	'hj:label:hjevent:costs' => 'Coste',
	'hj:label:hjevent:tags' => 'Etiquetas',
	'hj:label:hjevent:access_id' => 'Qui&eacute;n puede ver este evento',

	'hj:events:starttime' => 'Comienzo: %s',
	'hj:events:endtime' => 'Fin: %s',

	'hj:events:rsvp' => 'Confirme Asistencia',
	'hj:events:rsvp:attending' => 'Asistir&aacute;',
	'hj:events:rsvp:not_attending' => 'No Asistir&aacute;',
	'hj:events:rsvp:maybe_attending' => 'Quiz&aacute; asista',

	'hj:events:rsvp:success' => 'Confirmaci&oacute;n de asistencia aceptada',
	'hj:events:rsvp:error' => 'Lo siento, no se pudo confirmar la asistencia',

	'hj:events:event:details' => 'Detalles del evento',
	'hj:events:map' => 'Mapa',
	
	'hj:events:eventfilter' => 'Filtrado de eventos',
	'hj:events:filtered' => 'Resultados de b&uacute;squeda',
	'hj:events:addnew' => 'A&ntilde;adir evento',
	'hj:events:upcoming' => 'Pr&oacute;ximos eventos',
	'hj:events:past' => 'Eventos pasados',
	'hj:events:allevents' => 'Todos los eventos',
	'hj:events:myevents' => 'Mis eventos',
	'hj:events:friendevents' => 'Eventos de amigos',

	'hj:events:calendar' => 'Buscar eventos por fecha',
	'hj:events:search' => 'Buscar eventos',
	'hj:events:searching' => 'Buscando ...',
	'hj:events:search:after' => 'Eventos posteriores',
	'hj:events:search:before' => 'Eventos anteriores',
	'hj:events:search:location' => 'Eventos en',
	'hj:events:search:notfound' => 'No se encontraron eventos',

	'hj:events:owned' => 'Eventos creados por %s',
	'hj:events:user:attending' => 'Eventos a los que asistir&aacute; %s',
	'hj:events:user:maybeattending' => 'Eventos a los que quiz&aacute; asista %s',

	'hj:events:guestlist' => 'Otros asistentes',
	'river:attending:object:hjevent' => '%s asistir&aacute; al evento | %s',

	'hj:events:ical' => 'Descargar fichero iCal',
	'hj:events:import' => 'Importar iCal',
	'hj:events:import:instructions' => 'Selecciona un fichero .ics o especifica una URL a un fichero .ics (comenzando por http:// o webcal://.) Ten en cuenta que los eventos se importar&aacute;n como Privados. Por favor, modifica la configuraci&oacute;n si deseas que aparezcan en la web',
	'hj:events:import:file' => 'Subir un fichero ',
	'hj:events:import:url' => 'Especificar una URL',
	'hj:events:import:status' => 'Importar resultados: <br />
		Importados: %s <br />
		Actualizados: %s <br />
		Errores: %s
	',
	'hj:events:export:site' => 'Exportar calendario',
	'hj:events:export:attending' => 'Exportar eventos a los que voy a asistir',

	'hj:events:import:checkupdates' => 'Guardar esta URL',
	'hj:events:fetchfeed' => 'Obtener actualizaciones',
	'hj:events:mysavedfeeds' => 'Mis entradas',

	'hj:events:nourltoparse' => 'El calendario que tratas de procesar est&aacute; vac&iacute;o.',
	

);


add_translation("es", $spanish);
?>