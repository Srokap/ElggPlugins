<?php
	
$english = array(

'group_admin_adder:body' => "%s has submitted %s.

Click below to view:

%s",

'group_admin_adder:subject' => "New submission from %s",
'group_admin_adder:notify' => 'Notify admins when they have been added:',
'group_admin_adder:true' => 'true',
'group_admin_adder:false' => 'false');

add_translation("en",$english);

?>