<?php	

/*
** Group Admin Adder
**
** @author Michael Nixon
** @copyright Michael Nixon 2010
** @link None
** @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
**
*/

// Register a handler for create groups	
register_elgg_event_handler('create','group','group_admin_adder');

// Register a handler for update groups
register_elgg_event_handler('update','group','group_admin_adder');
	
// Finds all users with Admin status and adds them to the created/updated group
function group_admin_adder($event, $object_type, $object){
	
	global $CONFIG;

	$notify = get_plugin_setting('notify','group_admin_adder');
	$user = $_SESSION['guid'];
	$group = $object['guid'];
	$group_entity = get_entity($group);
	$owner = $group_entity->get('owner_guid');
	$query = "SELECT guid, name, admin FROM {$CONFIG->dbprefix}users_entity"; 
	$result = get_data($query);
	$subject = "New Case Created";
	$body = $_SESSION['name']." has created a case!";


	foreach($result as $k => $v){
		$guid = $v->guid;
		$admin = get_entity($guid);
		if($admin->isAdmin()){
			$group_entity->join($admin);
			if($notify == elgg_echo('group_admin_adder:true'))
			notify_user($guid, $user,
								sprintf(elgg_echo('group_admin_adder:subject'), $_SESSION['name']),
								sprintf(elgg_echo('group_admin_adder:body'), $_SESSION['name'],$group_entity->name, $group_entity->getURL()),
								NULL);
		}
	}
	
}

?>
