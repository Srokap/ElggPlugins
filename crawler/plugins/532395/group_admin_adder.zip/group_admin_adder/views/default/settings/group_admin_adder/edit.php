<?php

	$notify = $vars['entity']->notify;

?>
<p>
	<?php echo elgg_echo('group_admin_adder:notify'); ?>
	
		<?php
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[notify]',
			'options_values' => array(
				elgg_echo('group_admin_adder:true')  => 'Enable',
				elgg_echo('group_admin_adder:false') => 'Disable',
			),
			'value' => $notify
		));
	?>
</p>