<?php

// Wygenerowane przez plugin translationbrowser 

$polish = array( 
	 'translationbrowser'  =>  "Przeglądarka tłumaczeń" , 
	 'translationbrowser:translate'  =>  "Tłumacz" , 
	 'translationbrowser:selectlanguage'  =>  "Wybierz język" , 
	 'translationbrowser:selecttypeexport'  =>  "Wybierz format eksportu" , 
	 'translationbrowser:yourselectedlanguage'  =>  "Twój wybrany język" , 
	 'translationbrowser:languagecore'  =>  "- Systemowe napisy" , 
	 'translationbrowser:generatefile'  =>  "Generuj plik php " , 
	 'translationbrowser:highlight'  =>  "Podświetl nieprzetłumaczone pola" , 
	 'translationbrowser:canyouedit'  =>  "Możesz edytować tą wartość" , 
	 'translationbrowser:blankmodule'  =>  "Musisz wybrać co najmniej jeden moduł" , 
	 'translationbrowser:blanklang'  =>  "Musisz wybrać co najmniej jeden język" , 
	 'translationbrowser:error'  =>  "Wewnętrzny błąd. Spróbuj później. " , 
	 'translationbrowser:success'  =>  "Sukces tłumaczenia." , 
	 'translationbrowser:generatedby'  =>  "Wygenerowane przez plugin translationbrowser" , 
	 'translationbrowser:save'  =>  "Przetłumacz" , 
	 'translationbrowser:downloadallinzip'  =>  "Pobierz całe tłumaczenie w jednym pliku zip" , 
	 'translationbrowser:notadmincanedit'  =>  "Nie admin może edytować tłumaczenie"
); 

add_translation('pl', $polish); 

?>