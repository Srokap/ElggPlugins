<?php
?>
<p>
	<?php echo elgg_echo('translationbrowser:notadmincanedit'); ?>
	
	<select name="params[notadmincanedit]">
		<option value="yes" <?php if ($vars['entity']->notadmincanedit == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->notadmincanedit != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
	
</p>
