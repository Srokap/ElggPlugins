<?php
	/**
	 * Elgg translation browser.
	 * 
	 * @package translationbrowser
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Mariusz Bulkowski
	 * @author v2 Pedro Prez
	 * @copyright 2009
	 * @link http://www.pedroprez.com.ar/
	 */

  require_once(dirname(__FILE__) . "/countries.php");
  require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
  
  if(get_plugin_setting('notadmincanedit','translationbrowser')=="yes")
  {
  }
  else
  {	
	admin_gatekeeper();
  }	
	

 $callback = get_input('callback');
 if (!empty($callback)) 
 {
    $tmp_lang=get_input('language');
//    echo count($iso_639_1);
//    exit;
    $tmp_name = $iso_639_1[$tmp_lang];
    
    header('Content-Type: application/xml; charset=ISO-8859-1');
    $tab_out = array();
    translationbrowser_scandir(dirname(dirname(dirname(__FILE__))),$tab_out);
  
    //Ordenamos
    asort($tab_out);
    // print_r($tab_out);
  
    echo "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>
    <modules>\n";
 
 
  foreach($tab_out as $key => $opt)
  {
    $str     = translationbrowser_module_rate($key,$tmp_lang,$tmp_name);
    echo "<h1>$str </h1>";
    $tmp_key=md5($key);    
    echo "<module id=\"{$tmp_key}\">\n
    <title>{$str}</title>\n
    </module>\n";
  }
  
  echo "</modules>\n";
  
  exit;
 }
 
																 


	 set_context('admin');
	// Set admin user for user block
	set_page_owner($_SESSION['guid']);
	
	//clean session
	unset($_SESSION['translationbrowser']);
	
  // my output stringl
  $body = "";
  // small caption 
  $body .= elgg_echo("translationbrowser:selectlanguage");

  if(isset($iso_639_1['en'])) unset($iso_639_1['en']);
  
  $title = elgg_view_title(elgg_echo('translationbrowser'));
  
  
  // read to tab_out list translation files in elgg
  $tab_out = array();
  translationbrowser_scandir(dirname(dirname(dirname(__FILE__))),$tab_out);
  
  //Ordenamos
  asort($tab_out);
  
	//print results
  $body .= elgg_view("translationbrowser/forms/select_module", array('languages' => $iso_639_1, 'modules' => $tab_out)); //Get the form	
		
	// Display main admin menu
	page_draw(elgg_echo('translationbrowser'),elgg_view_layout("two_column_left_sidebar", '', $title . $body));

?>

