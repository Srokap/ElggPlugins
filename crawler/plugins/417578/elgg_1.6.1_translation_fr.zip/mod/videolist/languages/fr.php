<?php

// Generate By translationbrowser. 

$french = array( 
	 'videolist'  =>  "Mes videos" , 
	 'videolist:home'  =>  "%s 's Videos" , 
	 'videolist:new'  =>  "ajouter une video" , 
	 'videolist:find'  =>  "toutes les videos" , 
	 'videolist:search'  =>  "toutes les videos" , 
	 'videolist:title_videourl'  =>  "entre l'url de la video" , 
	 'videolist:submit'  =>  "envoie" , 
	 'videolist:videoTitle'  =>  "Titre" , 
	 'videolist:error'  =>  "erreur d'enregistrement de la video, essaie encore" , 
	 'videolist:posted'  =>  "ta video est enregistrée correctement" , 
	 'video:more'  =>  "voir toutes les videos" , 
	 'video:none'  =>  "désolé , aucune video trouvée" , 
	 'candidateprofile:candidatevideo'  =>  "Mes videos" , 
	 'videos:deleted'  =>  "ta video a été éffacée" , 
	 'videos:notdeleted'  =>  "cette video n'as pas pu être effacée , réessaie plus tard" , 
	 'videolist:widget'  =>  "Mes videos" , 
	 'videolist:widget:description'  =>  "tes videos de youtube" , 
	 'videolist:num_videos'  =>  "nombre de videos à afficher" , 
	 'profile:videoheader'  =>  "ma galerie video" , 
	 'videolist:title_access'  =>  "accès" , 
	 'item:object:videolist'  =>  "videos" , 
	 'videolist:tags'  =>  "ajoute des tags" , 
	 'videolist:browse'  =>  "cherche des videos - %s" , 
	 'videolist:browsemenu'  =>  "cherche des videos" , 
	 'videolist:title_search_tube'  =>  "cherche des videos de" , 
	 'videolist:searchTubeVideos'  =>  "cherche sur youtube.com" , 
	 'videolist:comments'  =>  "commentaires" , 
	 'videolist:commentspost'  =>  "poste" , 
	 'videolist:river:annotate'  =>  "%s à commenté sur" , 
	 'videolist:river:item'  =>  "une video" , 
	 'videolist:river:created'  =>  "%s a ajouté" , 
	 'videolist:searchTubeVideos:metacafe'  =>  "cherche sur metacafe.com" , 
	 'videolist:searchTubeVideos:vimeo'  =>  "cherche sur vimeo.com" , 
	 'videolist:searchTubeVideos:googlevideos'  =>  "cherche sur video.google.com" , 
	 'videolist:group'  =>  "videos du groupe" , 
	 'videolist:groupall'  =>  "toutes les vidoes du groupe" , 
	 'videolist:none'  =>  "ce groupe n'as pas encore de videos"
); 

add_translation('fr', $french); 

?>