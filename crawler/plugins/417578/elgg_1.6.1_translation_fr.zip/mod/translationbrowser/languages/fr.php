<?php

// Generate By translationbrowser. 

$french = array( 
	 'translationbrowser'  =>  "Traducteur du site" , 
	 'translationbrowser:translate'  =>  "traduire" , 
	 'translationbrowser:exporttranslations'  =>  "exporte la traduction" , 
	 'translationbrowser:selectlanguage'  =>  "selection de langue" , 
	 'translationbrowser:selecttypeexport'  =>  "sélection un type d'importation" , 
	 'translationbrowser:languagebase'  =>  "langue de base" , 
	 'translationbrowser:yourselectedlanguage'  =>  "langage sélectionné" , 
	 'translationbrowser:youwilltranslate'  =>  "tu traduis de :" , 
	 'translationbrowser:to'  =>  "vers" , 
	 'translationbrowser:languagecore'  =>  "langage système" , 
	 'translationbrowser:selectmodule'  =>  "sélectionne le module que tu veux traduire et clique sur le bouton \"traduire\"" , 
	 'translationbrowser:updatefile'  =>  "mettre à jour le fichier" , 
	 'translationbrowser:generatefile'  =>  "générer un fichier PHP" , 
	 'translationbrowser:highlight'  =>  "mettre en surbrillance les champs non traduits" , 
	 'translationbrowser:canyouedit'  =>  "editez la valeur de ce champs" , 
	 'translationbrowser:blankmodule'  =>  "il faut sélectionner au moins un module" , 
	 'translationbrowser:languageerror'  =>  "le langage sélectionné est incorrect , essaye encore ou choisis une autre langue" , 
	 'translationbrowser:blanklang'  =>  "sélectionne au moins une langue" , 
	 'translationbrowser:emptyfields'  =>  "complète au moins un champs" , 
	 'translationbrowser:error'  =>  "erreur interne, réessaye plus tard " , 
	 'translationbrowser:problem:permiss'  =>  "erreur d'accès au dossier : CHMOD permissions" , 
	 'translationbrowser:error:filecreate'  =>  "erreur de création de fichier : CHMOD" , 
	 'translationbrowser:success'  =>  "la traduction est réussie" , 
	 'translationbrowser:generatedby'  =>  "générée par translationbrowser" , 
	 'translationbrowser:save'  =>  "traduis" , 
	 'translationbrowser:downloadallinzip'  =>  "télécharge en Zip" , 
	 'translationbrowser:userscanedit'  =>  "utilisateurs peuvent éditer" , 
	 'translationbrowser:exportdescription'  =>  "si tu veux exporter la traduction , selectionne la langue et clique le bouton exporter" , 
	 'translationbrowser:export'  =>  "exporter" , 
	 'translationbrowser:infotxt'  =>  "This file created by Translation Browser Elgg
@author Mariusz Bulkowski http://seo4you.pl/
@author v2 Pedro Prez http://www.pedroprez.com.ar/"
); 

add_translation('fr', $french); 

?>