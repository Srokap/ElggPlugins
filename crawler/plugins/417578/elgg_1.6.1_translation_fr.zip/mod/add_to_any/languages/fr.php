<?php
	/**
	 * Elgg add_to_any plugin
	 * 
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette fabrice.collette@free.fr
	 * @copyright Fabrice Collette
	 * @link http://www.meleze-online.net
	 */




	$french = array(
	       'add_to_any:owner_block_menu:add_to_any' => 'Partager sur le web'
		
	);
					
	add_translation("fr",$french);
?>