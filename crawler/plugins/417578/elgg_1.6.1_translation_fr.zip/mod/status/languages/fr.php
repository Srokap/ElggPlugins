<?php

	$french = array(
	
		/**
		 * Menu items and titles
		 */
	
			'status' => "Statut",
			'status:user' => "Statut de %s",
			'status:current'=> "Current status",
			'status:desc'=> "Ce widget de statut montre votre statut le plus r&eacute;cent.",
			'status:posttitle' => "Statut de %s : %s",
			'status:everyone' => "Statut de tous les usagers du site.",
			'status:strapline' => "%s",
			'status:addstatus' => "Fixez votre statut.",
		    'status:messages' => "Messages de statut",
			'status:text' => "Statut :",
			'status:set' => "Fix&eacute;",
			'status:clear' => "Autoriser statut",
			'status:delete' => "Supprimer statut",
			'status:nostatus' => "Aucun statut n'a &eacute;t&eacute; fix&eacute;.",
			'status:viewhistory' => "Voir historique",
	
			'item:object:status' => 'Messages de statut',
	
	
        /**
	     * Status river
	     **/
	        
	        //generic terms to use
	        'status:river:created' => "%s a mis",
	        
	        //these get inserted into the river links to take the user to the entity
	        'status:river:create' => "son statut � jour.",
	        
	        
	
		/**
		 * Status messages
		 */
	
			'status:posted' => "Votre statut a &eacute;t&eacute; affich&eacute;.",
			'status:deleted' => "Votre statut a &eacute;t&eacute; supprim&eacute;.",
	
		/**
		 * Error messages
		 */
	
			'status:blank' => "D&eacute;sol&eacute;s : vous devez r&eacute;diger un message de statut avant qu'il ne puisse &ecirc;tre sauvegard&eacute;.",
			'status:notfound' => "D&eacute;sol&eacute;s : nous n'avons pas pu trouver le message de statut en question.",
			'status:notdeleted' => "D&eacute;sol&eacute;s : nous n'avons pas pu supprimer ce message de statut.",
			'status:notsaved' => "Une erreur s'est produite au cours de la sauvegarde. Veuillez essayer de nouveau ou consulter votre administateur.",
			'status:problem' => "Un probl�me s'est pos&eacute;. Il semble que vous ne puissiez pas modifier ce statut.",
	
	);
					
	add_translation("fr",$french);

?>