<?php

// Generate By translationbrowser. 

$french = array( 
	 'friends:widget:description'  =>  "Afficher quelques amis"
); 

add_translation('fr', $french); 

?>