<?php

	$french = array(
	
		/**
		 * Menu items and titles
		 */
	
			'bookmarks' => "Signets",
			'bookmarks:add' => "Apposer un signet",
			'bookmarks:read' => "Articles auxquels un signet est associ&eacute;",
			'bookmarks:friends' => "Signets des ami-e-s",
			'bookmarks:everyone' => "Tous les signets du site",
			'bookmarks:this' => "Associez un signet &agrave; ceci",
			'bookmarks:bookmarklet' => "Obtenir un applisignet",
			'bookmarks:inbox' => "Bo&icirc;te aux lettres des signets",
			'bookmarks:more' => "Autres signets",
			'bookmarks:shareditem' => "Article auquel un signet est associ&eacute;",
			'bookmarks:with' => "Partager avec",
	
			'bookmarks:address' => "Adresse de la ressource &agrave; laquelle un signet doit &ecirc;tre associ&eacute;",
	
			'bookmarks:delete:confirm' => "&Euml;tes-vous s&ucirc;r-e de vouloir rayer cette ressource?",
	
			'bookmarks:shared' => "Signet associ&eacute;",
			'bookmarks:visit' => "Visiter la ressource",
			'bookmarks:recent' => "Signets r&eacute;cents",
	
			'bookmarks:river:created' => '%s a associ&eacute; un signet',
			'bookmarks:river:annotate' => '%s a comment&eacute;',
			'bookmarks:river:item' => 'un article',
	
			'item:object:bookmarks' => 'Articles auxquels un signet est associ&eacute;',
	
	
		/**
		 * More text
		 */
		    
		    'bookmarks:widget:description' => 
		            "Ce widget est destin&eacute; &agrave; &ecirc;tre port&eacute; &agrave; votre tableau de bord et vous indiquera les articles les plus r&eacute;cents arriv&eacute;s dans votre bo�te aux lettres de signets.",
	
			'bookmarks:bookmarklet:description' =>
					"L'applisignet vous permet de partager toute ressource que vous trouvez sur le Web avec vos ami-e-s ou d'y associer un signet &agrave; vos propres fins. Pour vous en servir, il vous suffit de faire glisser le bouton suivant jusqu'&agrave; la barre des liens de votre navigateur :",

	        'bookmarks:bookmarklet:descriptionie' =>
					"Si vous employez Internet Explorer, vous devrez cliquez &agrave; droite sur l'ic�ne de l'applisignet, choisir 'ajouter aux favoris' et cliquer sur la barre des liens.",

			'bookmarks:bookmarklet:description:conclusion' =>
					"Ensuite, vous pourrez sauvegarder toute page que vous visitez en cliquant dessus.",
	
		/**
		 * Status messages
		 */
	
			'bookmarks:save:success' => "Un signet a bien &eacute;t&eacute; associ&eacute; &agrave; Votre article.",
			'bookmarks:delete:success' => "Votre article auquel un signet &eacute;tait associ&eacute; a bien &eacute;t&eacute; supprim&eacute;.",
	
		/**
		 * Error messages
		 */
	
			'bookmarks:save:failed' => "Votre article associ&eacute; &agrave; un signet n'a pas pu &ecirc;tre sauvegard&eacute;. Veuillez essayer de nouveau.",
			'bookmarks:delete:failed' => "Votre article associ&eacute; &agrave; un signet n'a�pas pu &ecirc;tre supprim&eacute;. Veuillez essayer de nouveau.",
	
	
	);
					
	add_translation("fr",$french);

?>