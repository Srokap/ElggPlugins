<?php

	$french = array(
	
		/**
		 * Menu items and titles
		 */
	
			'thewire' => "Le fil",
			'thewire:user' => "Fil de %s",
			'thewire:posttitle' => "Notes de %s sur le fil :",
			'thewire:everyone' => "Fils sur le site",
	
			'thewire:read' => "Votre fil",
			
			'thewire:strapline' => "%s",
	
			'thewire:add' => "Afficher &agrave; votre fil",
		    'thewire:text' => "Note sur le fil",
			'thewire:reply' => "R&eacute;ponse",
			'thewire:via' => "via",
			'thewire:wired' => "Affich&eacute; sur le fil",
			'thewire:charleft' => "Caract&egrave;res restants",
			'item:object:thewire' => "Messages affich&eacute;s",
	
        /**
	     * Blog river
	     **/
	        
	        //generic terms to use
	        'thewire:river:created' => "%s a post&eacute;",
	        
	        //these get inserted into the river links to take the user to the entity
	        'thewire:river:create' => "sur le fil.",
	        
	    /**
	     * Wire widget
	     **/
	     
	        'thewire:sitedesc' => 'Ce widget indique les note sur le site les plus r&eacute;centes post&eacute;es sur le fil.',
	        'thewire:yourdesc' => 'Ce widget indique vos notes les plus r&eacute;centes affich&eacute;es sur le fil.',
	        'thewire:friendsdesc' => 'Ce widget indiquera les &eacute;l&eacute;ments les plus r&eacute;cents affich&eacute;s par vos ami-e-s sur le fil.',
	        'thewire:friends' => 'Vos ami-e-s sur le fil.',
	        'thewire:num' => 'Nombre de messages &agrave; afficher.',
	        
	        
	
		/**
		 * Status messages
		 */
	
			'thewire:posted' => "Votre message a &eacute;t&eacute; post&eacute; sur le fil.",
			'thewire:deleted' => "Votre note a &eacute;t&eacute; supprim&eacute;e.",
	
		/**
		 * Error messages
		 */
	
			'thewire:blank' => "D&eacute;sol&eacute;s : vous devez inscrire quelque chose dans la bo�te de texte avant de pouvoir la sauvegarder.",
			'thewire:notfound' => "D&eacute;sol&eacute;s : nous n'avons pas pu trouver la note en question.",
			'thewire:notdeleted' => "D&eacute;sol&eacute;s : nous n'avons pas pu supprimer cet &eacute;l&eacute;ment.",
	
	
		/**
		 * Settings
		 */
			'thewire:smsnumber' => "Votre num&eacute;ro de SMS s'il diff&egrave;re de votre num&eacute;ro de t&eacute;l&eacute;phone mobile (votre num&eacute;ro de mobile doit �tre en mode public pour que le fil puisse l'utiliser). Tous les num&eacute;ros de t&eacute;l&eacute;phone doivente �tre en format international.",
			'thewire:channelsms' => "Le num&eacute;ro auquel envoyer des messages SMS est %s",
			
	);
					
	add_translation("fr",$french);

?>