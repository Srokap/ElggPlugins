<?php

// Generate By translationbrowser. 

$french = array( 
	 'blog'  =>  "Blog" , 
	 'blogs'  =>  "Blogs" , 
	 'blog:user'  =>  "%s's blog" , 
	 'blog:user:friends'  =>  "%s's blogs d'amis" , 
	 'blog:your'  =>  "ton blog" , 
	 'blog:posttitle'  =>  "%s's blog %s" , 
	 'blog:friends'  =>  "blogs d'amis" , 
	 'blog:yourfriends'  =>  "dernier posts de tes amis" , 
	 'blog:everyone'  =>  "tous les blogs" , 
	 'blog:newpost'  =>  "nouveau post" , 
	 'blog:via'  =>  "via blog" , 
	 'blog:read'  =>  "lire blog" , 
	 'blog:addpost'  =>  "écrire un post" , 
	 'blog:editpost'  =>  "editer ce post" , 
	 'blog:text'  =>  "texte du blog" , 
	 'blog:strapline'  =>  "%s" , 
	 'item:object:blog'  =>  "posts du blog" , 
	 'blog:never'  =>  "jamais" , 
	 'blog:preview'  =>  "prévisualisation" , 
	 'blog:draft:save'  =>  "enregistrer le brouillon" , 
	 'blog:draft:saved'  =>  "dernier brouillon enregistré" , 
	 'blog:comments:allow'  =>  "autoriser les commentaires" , 
	 'blog:preview:description'  =>  "ceci est une prévisualisation non enregistrée de ton post" , 
	 'blog:preview:description:link'  =>  "pour continuer à éditer ou pour enregistrer clique ici" , 
	 'blog:enableblog'  =>  "activer le blog du groupe" , 
	 'blog:group'  =>  "blog du groupe" , 
	 'blog:river:created'  =>  "%s a écrit" , 
	 'blog:river:updated'  =>  "%s a mis à jour" , 
	 'blog:river:posted'  =>  "%s a posté" , 
	 'blog:river:create'  =>  "un nouveau post titré" , 
	 'blog:river:update'  =>  "un post titré" , 
	 'blog:river:annotate'  =>  "un commentaire sur ce post" , 
	 'blog:posted'  =>  "ton post a été enregistré" , 
	 'blog:deleted'  =>  "ton post a été effacé" , 
	 'blog:error'  =>  "erreur , réessaye " , 
	 'blog:save:failure'  =>  "ton post n'as pas pu être enregistré , réessaye" , 
	 'blog:blank'  =>  "il faut écrire le titre et le post avant de pouvoir poster :)" , 
	 'blog:notfound'  =>  "impossible de trouver ce post" , 
	 'blog:notdeleted'  =>  "impossible d'effacer ce post"
); 

add_translation('fr', $french); 

?>