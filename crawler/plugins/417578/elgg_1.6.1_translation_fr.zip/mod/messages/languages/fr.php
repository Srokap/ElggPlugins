<?php

	$french = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messages' => "Messages",
            'messages:back' => "Retour au messages",
			'messages:user' => "Votre bo&icirc;te de r&eacute;ception",
			'messages:sentMessages' => "Messages transmis",
			'messages:posttitle' => "Messages de %s : %s",
			'messages:inbox' => "Bo&icirc;te de r&eacute;ception",
			'messages:send' => "Transmettre un message",
			'messages:sent' => "Messages transmis",
			'messages:message' => "Message",
			'messages:title' => "Titre",
			'messages:to' => "Destinataire",
            'messages:from' => "Exp&eacute;diteur",
			'messages:fly' => "Transmettre",
			'messages:replying' => "Message en r&eacute;ponse &agrave;",
			'messages:inbox' => "Bo&icirc;te de r&eacute;ception",
			'messages:sendmessage' => "Transmettre un message",
			'messages:compose' => "Transmettre un message",
			'messages:sentmessages' => "Messages transmis",
			'messages:recent' => "Messages r&eacute;cents",
            'messages:original' => "Message initial",
            'messages:yours' => "Votre message",
            'messages:answer' => "R&eacute;ponse",
			
			'item:object:messages' => 'Messages',
	
		/**
		 * Status messages
		 */
	
			'messages:posted' => "Votre message a &eacute;t&eacute; transmis.",
			'messages:deleted' => "Votre message a &eacute;t&eacute; supprim&eacute;.",
	
		/**
		 * Email messages
		 */
	
			'messages:email:subject' => 'Vous avez un nouveau message!',
			'messages:email:body' => "Vous avez un nouveau message de %s. Il est r&eacute;dig&eacute; comme suit :

			
%s


Pour voir vos messages,cliquez ici :

	%s

Pour transmettre un message &agrave; %s, cliquez ici :

	%s

Vous ne pouvez pas r&eacute;pondre &agrave; ce message de courriel.",
	
		/**
		 * Error messages
		 */
	
			'messages:blank' => "D&eacute;sol&eacute;s : Vous devez inscrire quelque chose dans le corps du message avant qu'il puisse &ecirc;tre sauvegard&eacute;.",
			'messages:notfound' => "D&eacute;sol&eacute;s : nous n'avons pas pu trouver le message indiqu&eacute;.",
			'messages:notdeleted' => "D&eacute;sol&eacute;s : nous n'avons pas pu supprimer ce message.",
			'messages:nopermission' => "Vous n'avez pas la permission de supprimer ce message.",
			'messages:nomessages' => "Il n'y a pas de messages &agrave; afficher.",
			'messages:user:nonexist' => "Nous n'avons pas pu trouver le destinataire dans le base de donn&eacute;es des usagers.",
	
	);
					
	add_translation("fr",$french);

?>