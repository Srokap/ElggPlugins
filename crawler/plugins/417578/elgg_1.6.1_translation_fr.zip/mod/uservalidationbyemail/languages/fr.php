<?php
	/**
	 * Email user validation plugin language pack.
	 * 
	 * @package ElggUserValidationByEmail
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$french = array(
	
		'email:validate:subject' => "%s, veuillez confirmer votre adresse email !",
		'email:validate:body' => "Salut %s,

Veuillez s'il vous plait confirmer votre adresse email en suivant le lien suivant:

%s
",
		'email:validate:success:subject' => "Email validé %s !",
		'email:validate:success:body' => "Salut %s,
			
Féliciations, votre adresse email a été validée, vous pouvez désormais vous connecter sur notre site. Merci.",
	
		'uservalidationbyemail:registerok' => "Un email vous a été envoyé, merci de cliquer sur le lien qu'il contient pour activer votre compte."
	
	);
					
	add_translation("fr",$french);
?>