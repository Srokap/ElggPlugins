<?php
$lang = array(
	'sw:title' => 'Sticky Widgets',
	'sw:title:swtype' => 'Subtipos de usuario',
	'sw:title:swwhere' => 'Dónde',
	'sw:usercheck:fail' => 'Hubo un problema obteniendo la configuración de su perfil debido a un error de configuración en un plugin. Por favor notifique al administrador de la página.',

	'sw:title:defaults'=>"Widgets: configuración por defecto",
    'sw:member:access'=>"Configuración de acceso para el usuario",
    'sw:widgets:noconfig'=>"No ha hecho la<a href=\"%s\">la configuración por defecto de los widgets</a> para los usuarios. Por favor haga esto antes de asignar widgets a las diferentes áreas.",
);


add_translation("es_CO",$lang);
?>