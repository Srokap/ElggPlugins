<?php

	/**
	 * Elgg default sticky widget view
	 *
	 * @package Elgg
	 * @subpackage StickyWidgets
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Diego Andrés Ramírez Aragón <diego@somosmas.org>
	 */

		echo elgg_view('sticky_widgets/wrapper',$vars);

?>