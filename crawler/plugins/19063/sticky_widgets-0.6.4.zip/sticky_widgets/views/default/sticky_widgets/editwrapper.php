<?php

	/**
	 * Elgg edit sticky widget layout
	 *
	 * @package Elgg
	 * @subpackage StickyWidgets
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Diego Andrés Ramírez Aragón <diego@somosmas.org>
	 */

	$guid = $vars['entity']->getGUID();

//    $guid = 2;

	$form_body = $vars['body'];
	$form_body .= "<p><label>" . elgg_echo('sw:member:access') . ": " . elgg_view('input/access', array('internalname' => 'params[user_access_id]','value' => $vars['entity']->user_access_id)) . "</label></p>";
	$form_body .= "<p>" . elgg_view('input/hidden', array('internalname' => 'guid', 'value' => $guid)) . elgg_view('input/hidden', array('internalname' => 'noforward', 'value' => 'true')) . elgg_view('input/submit', array('internalname' => "submit$guid", 'value' => elgg_echo('save'))) . "</p>";

	echo elgg_view('input/form', array('internalid' => "widgetform$guid", 'body' => $form_body, 'action' => "{$vars['url']}action/sticky_widgets/save"))
?>


<script type="text/javascript">
$(document).ready(function() {

	$("#widgetform<?php echo $guid; ?>").submit(function () {

		$("#submit<?php echo $guid; ?>").attr("disabled","disabled");
		$("#submit<?php echo $guid; ?>").attr("value","<?php echo elgg_echo("saving"); ?>");
		$("#widgetcontent<?php echo $guid; ?>").html('<?php echo elgg_view('ajax/loader',array('slashes' => true)); ?>');
		$("#widget<?php echo $guid; ?> .toggle_box_edit_panel").click();

		var variables = $("#widgetform<?php echo $guid; ?>").serialize();
		$.post($("#widgetform<?php echo $guid; ?>").attr("action"),variables,function() {
			$("#submit<?php echo $guid; ?>").attr("disabled","");
			$("#submit<?php echo $guid; ?>").attr("value","<?php echo elgg_echo("save"); ?>");
			$("#widgetcontent<?php echo $guid; ?>").load("<?php echo $vars['url']; ?>pg/view/<?php echo $guid; ?>?shell=no&username=<?php echo page_owner_entity()->username; ?>&context=<?php echo get_context(); ?>&callback=true");
		});
		return false;

	});

});
</script>