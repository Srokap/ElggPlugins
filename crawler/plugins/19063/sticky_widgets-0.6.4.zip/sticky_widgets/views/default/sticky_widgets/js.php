<?php
/**
*
* @author Diego Andrés Ramírez Aragón
* @copyright Corporación Somos más - 2008
*/

?>
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/sticky_widgets/js/ui.tabs.js"></script>
