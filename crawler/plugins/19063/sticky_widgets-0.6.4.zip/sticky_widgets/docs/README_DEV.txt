TODOS:
--------------------
*  Diego Andr�s Ram�rez Arag�n graciously created a GUI for configuring the default SETTINGS, which Steve
Suppe updated for usertypes.  This needs to be connected somehow.
	* How to do this?  When the user's widgets are created, need to clone these settings somehow. But
	  settings are individual to the widgets - how to know what to clone?
	  
* Make a toggle setting to turn off/on user editing of Sticky Widget page/widget edits.
	* This could be done via hooks into the permissions of an entity, I believe.
	
Testing needs to be done!