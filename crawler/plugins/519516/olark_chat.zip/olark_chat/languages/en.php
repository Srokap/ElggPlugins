<?php
	/**
         * Olark Chat for Elgg
         * 
         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author Tingxi Tan <txtan@redmelonconsulting.com>
         * @link http://redmelonconsulting.com
         */

	$english = array(
		'olark_chat:settings:uid'=>'Enter your Olark Chat Key',
	);	
	add_translation("en",$english);

?>
