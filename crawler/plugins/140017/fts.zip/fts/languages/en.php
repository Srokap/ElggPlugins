<?php
	/**
	 * Elgg Full Text Search language pack
	 * 
	 * @package ElggFTS
	 * @license ???
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	$english = array(
	
		/**
		 * Menu items and titles
		 */
			
			'fts:search:startblurb' => "Full text search matching '%s':",
			'fts:search:finishblurb' => "To view more, click here.",
	
			'fts:searchtitle' => 'Full text search using: %s',
	);
					
	add_translation("en",$english);
?>