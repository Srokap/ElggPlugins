-- Full Text Search schema
--
-- This file contains the index for full text searches.

-- The main FTS entity index, maintained by the FTS plugin
CREATE TABLE `prefix_fts_entity_index` (

	`guid` bigint(20) unsigned  NOT NULL,

	summary text NOT NULL,

	primary key (`guid`),
	FULLTEXT KEY (`summary`)

) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `prefix_fts_annotation_index` (

	annotation_id bigint(20) unsigned  NOT NULL,
	`guid` bigint(20) unsigned  NOT NULL,

	summary text NOT NULL,

	primary key (`annotation_id`),
	key (guid),
	FULLTEXT KEY (`summary`)

) ENGINE=MyISAM DEFAULT CHARSET=utf8;