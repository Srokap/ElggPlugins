<?php
	/**
	 * Elgg Full Text Search
	 * 
	 * @package ElggFTS
	 * @license ???
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	// Current FTS schema version (used for upgrading)
	global $FTS_VERSION;
	$FTS_VERSION = 2009052201;


	/**
	 * Initialise
	 *
	 */
	function fts_init()
	{
		global $CONFIG;
		global $FTS_VERSION, $CONFIG;
		
		// Register runonce hook
		run_function_once("fts_runonce");
		
		// Register indexing cron hook to pick up stragglers 
		register_plugin_hook('cron', 'daily', 'fts_index_on_cron');
		
		// Listen to create events and index (but as the last thing we do
		register_elgg_event_handler('create', 'all', 'fts_event_indexer', 999);
		register_elgg_event_handler('update', 'all', 'fts_event_indexer', 999);
		register_elgg_event_handler('delete', 'all', 'fts_event_cleanup', 999);
		
		// Listen to search hook
		register_plugin_hook('search','all','fts_search_list');
		
		// Replace search pages
		register_page_handler('search','fts_search_page_handler');
	}
	
	/**
	 * Index a specified entity, updating its entry if it exists.
	 *
	 * @param ElggEntity $entity
	 */
	function fts_index_entity(ElggEntity $entity)
	{
		global $CONFIG;
		
		$composite = array();
		
		$composite[] = $entity->title;
		$composite[] = $entity->name;
		$composite[] = $entity->username;
		$composite[] = $entity->description;
		$composite[] = $entity->url;
		
		// Create a serialised version of the entity
		$summary = sanitise_string(implode(", ", $composite));
		$guid = (int)$entity->guid;
		
		// Now inject into index
		return insert_data("INSERT DELAYED into {$CONFIG->dbprefix}fts_entity_index (guid, summary) VALUES ($guid, '$summary') ON DUPLICATE KEY UPDATE summary='$summary'");
	}
	
	function fts_deindex_entity(ElggEntity $entity)
	{
		global $CONFIG;
		
		$guid = (int)$entity->guid;
		
		return delete_data("DELETE from {$CONFIG->dbprefix}fts_entity_index WHERE guid=$guid");
	}
	
	/**
	 * Index a specified annotation, updating it's entry if it exists
	 *
	 * @param ElggAnnotation $annotation
	 */
	function fts_index_annotation(ElggAnnotation $annotation)
	{
		global $CONFIG;
		
		$composite = array();
		
		$composite[] = $annotation->value;
		
		// Create a serialised version of the entity
		$summary = sanitise_string(implode(", ", $composite));
		$guid = (int)$annotation->entity_guid;
		$id = (int)$annotation->id;
		
		// Now inject into index
		return insert_data("INSERT DELAYED into {$CONFIG->dbprefix}fts_annotation_index (annotation_id, guid, summary) VALUES ($id, $guid, '$summary') ON DUPLICATE KEY UPDATE summary='$summary'");
		
	}
	
	/**
	 * De-index a given annotation.
	 *
	 * @param ElggAnnotation $entity
	 * @return unknown
	 */
	function fts_deindex_annotation(ElggAnnotation $entity)
	{
		global $CONFIG;
		
		$id = (int)$entity->id;
		
		return delete_data("DELETE from {$CONFIG->dbprefix}fts_annotation_index WHERE annotation_id=$id");
	}
	
	/**
	 * Listen to create events, and if we can index it then we will.
	 *
	 * @param unknown_type $event
	 * @param unknown_type $object_type
	 * @param unknown_type $object
	 * @return unknown
	 */
	function fts_event_indexer($event, $object_type, $object)
	{
		if ($object instanceof ElggEntity)
			fts_index_entity($object);
			
		if ($object instanceof ElggAnnotation)
			fts_index_annotation($object);
		
		return true;
	}
	
	/**
	 * Remove a given item from the index
	 *
	 * @param unknown_type $event
	 * @param unknown_type $object_type
	 * @param unknown_type $object
	 * @return unknown
	 */
	function fts_event_cleanup($event, $object_type, $object)
	{
		if ($object instanceof ElggEntity)
			fts_deindex_entity($object);
			
		if ($object instanceof ElggAnnotation)
			fts_deindex_annotation($object);
		
		return true;
	}
	
	/**
	 * Perform a full text search on the given criteria.
	 *
	 * @param string $criteria The search criteria
	 * @param string $entity_type Entity type to refine the search
	 * @param string $entity_subtype Subtype
	 * @param int $limit
	 * @param int $offset
	 * @param string $order_by Order results (default by relevancy)
	 * @param bool $count
	 */
	function fts_search($criteria, $entity_type = "", $entity_subtype = "", $limit = 10, $offset = 0, $order_by = "", $count = false)
	{
		global $CONFIG;
		
		$criteria = sanitise_string($criteria); 
		$limit = (int)$limit;
		$offset = (int)$offset;
		$order_by = sanitise_string($order_by);
		$entity_type = sanitise_string($entity_type);
		$entity_subtype = sanitise_string($entity_subtype);
		
		$where = array();
		
		// Match criteria
		$where[] = "((MATCH (fts_e.summary) AGAINST ('$criteria')) OR (MATCH (fts_a.summary) AGAINST ('$criteria')))";
		
		if ($entity_type != "")
			$where[] = "e.type='$entity_type'";
		if (($entity_subtype!=="") && ($entity_type!="")) {
			$entity_subtype = get_subtype_id($entity_type, $entity_subtype);
			$where[] = "e.subtype=$entity_subtype";
		}
		
		//if ($order_by == "") $order_by = "e.time_created desc";
		
		if ($count) {
			$query = "SELECT count(distinct e.guid) as total ";
		} else {
			$query = "SELECT distinct e.* "; 
		}
		
		//$query .= "from {$CONFIG->dbprefix}entities e RIGHT JOIN {$CONFIG->dbprefix}fts_entity_index fts_e ON e.guid=fts_e.guid RIGHT JOIN {$CONFIG->dbprefix}fts_annotation_index fts_a ON e.guid=fts_a.guid WHERE";
		$query .= "from ({$CONFIG->dbprefix}entities e RIGHT JOIN {$CONFIG->dbprefix}fts_entity_index fts_e ON e.guid=fts_e.guid) RIGHT JOIN {$CONFIG->dbprefix}fts_annotation_index fts_a ON e.guid=fts_a.guid WHERE";
		
		
		foreach ($where as $w)
			$query .= " $w and ";
		$query .= get_access_sql_suffix("e");
		
		if (!$count) {
			if ($order_by) $query = " order by $order_by ";
			$query .= " limit $offset, $limit"; // Add order and limit
			
			return get_data($query, "entity_row_to_elggstar");
		} else {
			if ($count = get_data_row($query)) {
				return $count->total;
			}
		}
		return false;
	}
	
	/**
	 * Displays a list of objects that have been searched for using full text search.
	 *
	 * @see elgg_view_entity_list
	 * 
	 * @param string $tag Search criteria
	 * @param string $type Entity type to refine the search
	 * @param string $subtype Subtype
	 * @param int $limit The number of entities to display on a page
	 * @return string The list in a form suitable to display
	 */
	function fts_list_search($tag, $type="", $subtype= "", $limit = 10) {
		
		$offset = (int) get_input('offset');
		$limit = (int) $limit;
		$count = (int) fts_search($tag, $type, $subtype, 10, 0, "", true); 
		$entities = fts_search($tag, $type, $subtype, $limit, $offset);
		
		return elgg_view_entity_list($entities, $count, $offset, $limit, $fullview, false);
		
	}
	
	/**
	 * Plugin hook to return values from a search.
	 *
	 * @param unknown_type $hook
	 * @param unknown_type $user
	 * @param unknown_type $returnvalue
	 * @param unknown_type $tag
	 * @return unknown
	 */
	function fts_search_list($hook, $user, $returnvalue, $tag) {

		// Change this to set the number of users that display on the search page
		$threshold = 4;

		$object = get_input('object');
		$subtype = get_input('subtype');
		
		$result = fts_search($tag, $object, $subtype);
		
		if ($result)
		{
			$count = fts_search($tag, $object, $subtype, "", "", "", true);
			
			$return = elgg_view('fts/search/startblurb',array('count' => $count, 'tag' => $tag));
			foreach($result as $r) {
				$return .= elgg_view_entity($r);
			}
			$return .= elgg_view('fts/search/finishblurb',array('count' => $count, 'threshold' => $threshold, 'tag' => $tag));
			return $return;
			
		}
		
	}
	
	/**
	 * Index non indexed entities.
	 * 
	 * This function creates the initial index from unindexed entities and annotations, further updates additions and deletions will be handled
	 * off events. 
	 *
	 * @param unknown_type $hook
	 * @param unknown_type $entity_type
	 * @param unknown_type $returnvalue
	 * @param unknown_type $params
	 * @return unknown
	 */
	function fts_index_on_cron($hook, $entity_type, $returnvalue, $params)
	{
		global $CONFIG;
		
		// How many should we index at one time
		$limit = (int)get_plugin_setting('fts_index_limit', 'fts');
		if (!$limit) $limit = 100;
		
		$entities = get_data("SELECT * from {$CONFIG->dbprefix}entities WHERE guid NOT IN (SELECT guid FROM {$CONFIG->dbprefix}fts_entity_index) LIMIT $limit", 'entity_row_to_elggstar');
		foreach ($entities as $entity)
			fts_index_entity($entity);
			
		$entities = null;
		
		$annotations = get_data("SELECT * from {$CONFIG->dbprefix}annotations WHERE id NOT IN (SELECT guid FROM {$CONFIG->dbprefix}fts_annotation_index) LIMIT $limit", 'row_to_elggannotation');
		foreach ($annotations as $annotation)
			fts_index_annotation($annotation);
			
		$annotations = null;	
	}
	
	/**
	 * Page handler for search
	 *
	 * @param array $page Page elements from pain page handler
	 */
	function fts_search_page_handler($page) 
	{
		global $CONFIG;
		
		if (isset($page[0])) {
			switch ($page[0]) {
				case 'users' : include_once($CONFIG->path . "search/users.php"); break;
				
				case 'groups' : include_once($CONFIG->path . "search/groups.php"); break;
				
				case 'fts' : include_once($CONFIG->pluginspath . "fts/fts.php"); break;
				
				default: include_once($CONFIG->path . "search/index.php");
			}
		}
		else
			include_once($CONFIG->path . "search/index.php");
	}
	
	/**
	 * Install the FTS schema extension.
	 *
	 */
	function fts_runonce()
	{
		global $FTS_VERSION, $CONFIG;
		
		// Install schema
		run_sql_script($CONFIG->pluginspath . 'fts/schema/mysql.sql');
		
		// Set version
		set_plugin_setting('fts_schema_version', "$FTS_VERSION", 'fts');

	}
	
	/**
	 * Perform any upgrades necessary to the schema.
	 *
	 * @param unknown_type $event
	 * @param unknown_type $object_type
	 * @param unknown_type $object
	 */
	function fts_upgrade($event, $object_type, $object)
	{
		global $FTS_VERSION;
		
		// Ensure schema is installed in the first place
		run_function_once("fts_runonce");
		
		// Perform upgrade
		$old_version = get_plugin_setting('fts_schema_version', 'fts');
		db_upgrade($old_version, $CONFIG->pluginspath . 'fts/schema/upgrades/');
		
		// Update version
		set_plugin_setting('fts_schema_version', "$FTS_VERSION", 'fts');
	}
	
	// Initialisation
	register_elgg_event_handler('init','system','fts_init');
	
	// Register an upgrade hook
	register_elgg_event_handler('upgrade', 'upgrade', 'fts_upgrade');
?>