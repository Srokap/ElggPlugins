<?php
	/**
	 * Elgg Full Text Search
	 * 
	 * @package ElggFTS
	 * @license ???
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	
	// Set context
		set_context('search');
		
	// Get input
		$tag = get_input('tag');
		$object = get_input('object');
		$subtype = get_input('subtype');
		
		if (!empty($tag)) {
			$title = sprintf(elgg_echo('fts:searchtitle'),$tag);
			$body = "";
			$body .= elgg_view_title($title); // elgg_view_title(sprintf(elgg_echo('searchtitle'),$tag));
			$body .= elgg_view('fts/search/startblurb',array('tag' => $tag));
			$body .= fts_list_search($tag, $object, $subtype);
			//$body = elgg_view_layout('two_column_left_sidebar','',$body);
		} else {
			$title = elgg_echo('item:group');
			$body .= elgg_view_title($title);
			$body .= list_entities('groups');
		}
		
		$body = elgg_view_layout('two_column_left_sidebar','',$body);
		page_draw($title,$body);
?>