<?php

	if ($vars['count'] > $vars['threshold']) {

?>
<div class="contentWrapper"><a href="<?php echo $vars['url']; ?>search/fts/?tag=<?php echo urlencode($vars['tag']); ?>"><?php 
	
		echo elgg_echo("fts:search:finishblurb"); 
	
	?></a></div>
<?php

	}

?>