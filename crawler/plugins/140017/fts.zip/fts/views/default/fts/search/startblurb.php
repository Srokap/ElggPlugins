
<div class="contentWrapper">
	<?php 
	
		echo sprintf(elgg_echo("fts:search:startblurb"),$vars['tag']); 
	
	?>
</div>