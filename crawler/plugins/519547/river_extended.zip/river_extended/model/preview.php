<?php
	/**
	* Preview Module
	* 
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2009-2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/
	
	define('SHOW_PREVIEW_URL', 'http://images.pageglimpse.com/v1/thumbnails?url=%s&devkey=%s&size=%s&root=%s');
	define('REQUEST_PREVIEW_URL', 'http://images.pageglimpse.com/v1/thumbnails/request?url=%s&devkey=%s');
	define('EXISTS_PREVIEW_URL', 'http://images.pageglimpse.com/v1/thumbnails/exists?url=%s&devkey=%s&size=%s');
	
	class Preview {
		
			/*
			 *	devkey  	string (required)  	All requests to PageGlimpse service require a devkey. Sign-up and get your own devkey. 
			*/
			private $dev_key;

			/*
			 * Sizes
			 * small  	150x108  	~ 4kb
			 * medium 	280x202 	~ 11kb
			 * large 	430x310 	~ 25kb
			 *  
			 *  size  	string The size of thumbnail. Available sizes are: small, medium, large. If the parameter value is not set, the small size will be returned.
			*/
			private $size;
			
			/*
			 * root  	string  	Indicates if the thumbnails for the domain root should be displayed. If set to "no", it will display the not found image, otherwise it will display the thumbnails for root domain page. Default value is "yes". 
			*/
			private $root;
			
			/*
			 *	nothumb  	string  	If the thumbnail for the website is not yet taken, it will be queued and the value of this parameter will be sent back. If this parameter is not set a PageGlimpse default image will be returned. Example of value: http://www.yoursite.com/nothumb.jpg 
			*/
			private $nothumb;
				
		
		//Construct	
			public function __construct($dev_key){
				$this->size = 'medium';
				$this->root = 'no';
				$this->nothumb = NULL;
				$this->dev_key = $dev_key;
			}
			
			/*
			 * Get single thumbnail 
			*/	
			public function showPreview($url, $size = NULL, $root = NULL) {
				if (is_null($size)) {
					$size = $this->size; 
				}
				if (is_null($root)) {
					$root = $this->root; 
				}
				$url = sprintf(SHOW_PREVIEW_URL, $url, $this->dev_key, $size, $this->root);
				/*if ($this->existsPreview($url)) {
					$url = sprintf(SHOW_PREVIEW_URL, $url, $this->dev_key, $this->size, $this->root);
				} else {
					$this->requestPreview($url);
				}*/
				return $url;
			}
			
			/*
			 * Check if a thumbnail exists
			*/
			public function existsPreview($url, $size = NULL) {
				if (is_null($size)) {
					$size = $this->size; 
				}
				$url = sprintf(EXISTS_PREVIEW_URL, $url, $this->dev_key, $size);
				
				$ch = curl_init();
			    curl_setopt($ch, CURLOPT_URL, $url);
			    curl_setopt($ch, CURLOPT_POST,"GET");
		      	
		      	ob_start();
		      
			    curl_exec($ch);
			    curl_close($ch);
			    $cache = ob_get_contents();
			    ob_end_clean();
			    
			    if ($cache) {
					$cache = json_decode($cache);
					if (is_array($cache) && isset($cache[1]) && $cache[1] == 'yes') {
						return true;
					}
				}
				return false;
			}
			
			/*
			 * Use this method to add an url to the queue to be captured and generate thumbnails.
			*/
			public function requestPreview($url) {
				$url = sprintf(REQUEST_PREVIEW_URL, $url, $this->dev_key);
				
				$ch = curl_init();
			    curl_setopt($ch, CURLOPT_URL, $url);
			    curl_setopt($ch, CURLOPT_POST,"GET");
		      	
		      	ob_start();
		      
			    curl_exec($ch);
			    curl_close($ch);
			    $cache = ob_get_contents();
			    ob_end_clean();
			    
			    if ($cache) {
					$cache = json_decode($cache);
					if (is_array($cache) && isset($cache[1]) && $cache[1] == 'success') {
						return true;
					}
				}
				return false;
			}
		
	}
		
?>