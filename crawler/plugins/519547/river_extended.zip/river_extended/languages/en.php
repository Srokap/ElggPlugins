<?php
	/**
	* river_extended
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	$english = array(
		'river_extended:admin' => 'river_extended Settings',		
		//Translation Here
		//Settings
		'river_extended:preview:settings:apikey:label' => 'Enter your Pageglimpse API Key',
		'river_extended:preview:settings:apikey:help' => 'You can obtain an API Key %s.',
	);
					
	add_translation("en",$english);
?>