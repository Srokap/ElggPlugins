<?php
	/**
	* river_extended
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	$preview_developer_key = $vars['entity']->preview_developer_key;
?>

<p>
	<?php 	
		echo elgg_echo('river_extended:preview:settings:apikey:label'); 
	?><br />
	<small>
	<?php
		$link_help_api =  "<a target=\"_blank\" href=\"http://www.pageglimpse.com/account\">here</a>";
		echo sprintf(elgg_echo('river_extended:preview:settings:apikey:help'),$link_help_api);
	?>
	</small>
	
	<?php 
		echo elgg_view('input/text', array(
			'internalname' => 'params[preview_developer_key]',
            'value' => $preview_developer_key
		));
	?>
</p>