<?php
	/**
	* river_extended
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	//Add preview suppor
	require_once(dirname(__FILE__) . '/model/preview.php');

	function river_extended_init() {
		global $CONFIG;
		register_plugin_hook('display', 'view', 'river_extended_view_rewrite');
		
		// define views we want to rewrite codes on (means we don't have to process *everything*)
		$CONFIG->rivertags_views = array(
			'river/item/wrapper'
		);
		
		//Page Handler
		register_page_handler('river_extended','river_extended_page_handler');
		
	}
	
	function river_extended_view_rewrite($hook, $entity_type, $returnvalue, $params) {
		global $CONFIG;
		
		$view = $params['view'];
		
		if (($view) && (in_array($view, $CONFIG->rivertags_views)))
		{
			// Search and replace file codes
			$returnvalue =  preg_replace_callback('/(#)([A-Za-z0-9\_\-\/]+)/i', 
		       	create_function(
		            '$matches',
		            '
		       			global $CONFIG; 
		       			foreach($matches as $key => $match) {
							$matches[$key] = strip_tags($match);		       			
		       			}
		       			return "<a href=\"{$CONFIG->url}tag/{$matches[2]}\">{$matches[0]}</a>";
		       		'
		    ), $returnvalue);
		    
		    $url_site = $CONFIG->url;
		    $url_site = trim($url_site, '/');
			$url_site = str_replace('/', '\/', $url_site);
			
			//Works only for external links
		    if (!preg_match("/[\s]$url_site/", $returnvalue)) {
			    if (get_plugin_setting('preview_developer_key', 'river_extended') != "") {
			    	$returnvalue =  preg_replace_callback("/(\s)(http(s?):\/\/)?(www.)?(\w|-)+(\.(\w|-)+)*((\.[a-zA-Z]{2,3})|\.(aero|coop|info|museum|name))+(\/)?([^\s|\>|\<]+)?/i", 
			       	create_function(
			            '$matches',
			            '	
			            	$original_url = $matches[0];
			            	$url = trim($matches[0], ">, \' \'");
			            	if (!preg_match("/^http/", $url)) {
			            		$url = "http://{$url}";
			            	}
			            	$content ="<a target=\"_blank\" href=\"{$url}\"> {$original_url}</a> <br />";
			            	$dev_key = get_plugin_setting("preview_developer_key", "river_extended"); 
							$prev_object = new Preview($dev_key);
							$content .= "<a target=\"_blank\" href=\"{$url}\"><img src=\"" . $prev_object->showPreview($url, "small") . "\" /></a><br />";
			            	return $content;
			       		'
			       		
			    	), $returnvalue);
				}
		    }
			return $returnvalue;
		}
	}
	
	function river_extended_page_handler($page) {
		global $CONFIG;
		if (isset($page[0])) {
			switch($page[0]) {
				case "admin":
					!@include_once(dirname(__FILE__) . "/admin.php");
					return false;
          			break;
          		case "test":
					!@include_once(dirname(__FILE__) . "/test.php");
					return false;
          			break;	
			}
		}
	}
	
	function river_extended_setup() {
		global $CONFIG;
		if (get_context()=='admin') {
    		add_submenu_item(elgg_echo("river_extended:admin"), $CONFIG->wwwroot . "pg/river_extended/admin" );
		}
	}
	
	//Generate url for accept action on elgg 1.7
	if(!is_callable('url_compatible_mode')) {
	    function url_compatible_mode($hook = '?') {
	    	$now = time();
			$query[] = "__elgg_ts=" . $now;
			$query[] = "__elgg_token=" . generate_action_token($now);
			$query_string = implode("&", $query);
			return $hook . $query_string;
	    }
	}
	
	register_elgg_event_handler('init','system','river_extended_init');
	register_elgg_event_handler('pagesetup','system','river_extended_setup');