<?php
	/**
	 * @file see_demo_entities.php
	 * @brief Show the demo entities created for test
	 */

	require_once(dirname(dirname(dirname(__FILE__))).'/engine/start.php');
	
	admin_gatekeeper();
	set_context('admin');
	
	$title = elgg_echo('get_input_plus:see_demo_entities');
	
	$area2 = elgg_view_title($title);
	
	$options = array(
		'types'=>'object',
		'subtypes'=>'get_input_plus_demo',
		'full_view'=>false
		);
	$area2 .= elgg_list_entities($options);
	
	$page_body = elgg_view_layout('two_column_left_sidebar',$area1,$area2);

	page_draw($title,$page_body);
?>