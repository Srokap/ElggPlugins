<?php
	/**
	 * @file edit_entity.php
	 * @brief Displays the form for handle get_input_plus attributes and metadatas
	 */

	require_once(dirname(dirname(dirname(__FILE__))).'/engine/start.php');
	
	admin_gatekeeper();
	set_context('admin');
	
	$entity_guid = get_input('entity_guid');
	$entity = get_entity($entity_guid);
	
	$title = elgg_echo('get_input_plus:edit');
	
	$area2 = elgg_view_title($title);
	$area2 .= elgg_view('get_input_plus/edit_entity',array('entity'=>$entity));
	
	$page_body = elgg_view_layout('two_column_left_sidebar',$area1,$area2);

	page_draw($title,$page_body);
?>