<?php
	/**
	 * @file lib/get_input_plus.php
	 * @brief The basic lib of get_input_plus plugin
	 */

	/**
	 * An advanced and commun procedure while It's required to get inputs from a form:
	 *   * Displays errors for required fields not filled
	 *   * Cache the values filled for the user on $_SESSION
	 *   * Forward the user to the last page
	 *   
	 * @param $options
	 * @return <-> Forward the user to the last page in case of error and existing
	 *             error_forward_url
	 *         <-> System messages errors following using a elgg_echo('errors:blank_'.$input_name)
	 *             for each required field not filled by the user
	 *         <-> In case of non errors, returns a list of all inputs passed as $input_names
	 *             after using the get_input() function 
	 */
	function get_input_plus($options) {
	
		// Load default values as elgg like system :)
		$defaults = array(
			'input_names'=>array(),
			'forward'=>true,
			'display_error'=>true,
			'error_forward_url'=>$_SERVER['HTTP_REFERER']
			);
		$options = array_merge($defaults,$options);
	
		$params = array();

		if ($options['input_names']) {
			// If you are getting only one parameter, It is not required to pass one array, We will convert It for you :)
			if (!is_array($options['input_names'])) {
				$options['input_names'] = array($options['input_names']);
			}
			
			$error_message = '';
	
			// If the parameter is required than pass the $key as "required" string
			foreach($options['input_names'] as $key=>$input_name) {
	
				// TODO: Put some error handler using elgg hook system
				// Checking if the parameter is required
				if ($key != 'required_inputs') {
					// Setting the params array which will be returned at end of this function
					$params[$input_name] = get_input($input_name);
				} else {
					
					if (!is_array($input_name)) {
						$input_name = array($input_name);
					}
					
					foreach ($input_name as $required_field) {
						if (!$params[$required_field] = get_input($required_field)) {
							if ($error_message) {
								$error_message = '<br />';
							}
							$error_message .= elgg_echo('errors:blank_'.$required_field);
						}
					}
				}
			}
		}
		
		if ($error_message) {
			// Cache the inputs for be recovered while the form be displayed again
			cache_inputs($params);
			
			// Show display errors if the options says to do It
			if ($options['display_error']) {
				system_messages($error_message,'errors');
			}
			
			// In case of error forward the user to an appropriate page
			if ($options['error_forward_url']) {
				forward($options['error_forward_url']);
			}
		} else {
			
			$input_names = $options['input_names'];
			if ($input_names['required_inputs']) {
				if (is_array($input_names['required_inputs'])) {
					foreach ($input_names['required_inputs'] as $required_input) {
						$input_names[] = $required_input;
					}
				} else {
					$input_names[] = $input_names['required_inputs'];
				}
				
				unset($input_names['required_inputs']);
				
			}
			
			uncache_inputs($input_names);
		}
		
		return $params;
	}
	
	/**
	 * Caches the inputs into $_SESSION to be recovered for get_cached_inputs()
	 * 
	 * @param $inputs List of inputs
	 */
	function cache_inputs($inputs) {
		foreach($inputs as $input_name=>$input_value) {			
			if ($input_value) {
				// If the input is an array eg. <select> input, than serialize the value.
				if (is_array($input_value)) {
					$input_value = serialize($input_value);
				}
			}
			$_SESSION['cached_'.$input_name] = $input_value;
		}
	}
	
	/**
	 * Uncache the inputs from $_SESSION setted by the cache_inputs() function
	 * 
	 * @param $inputs List of inputs
	 * @return true|false Depends on if something was cached into $_SESSION while this function was executed
	 */
	function uncache_inputs($input_names) {
		
		$was_cached = false;
		
		if ($input_names) {
			if (!is_array($input_names)) {
				$input_names = array($input_names);
			}
			foreach($input_names as $input_name) {
				unset($_SESSION['cached_'.$input_name]);
				$was_cached = true;
			}
		}
		
		return $was_cached;
	}
	
	/**
	 * Get cached inputs from two possibilities sources: the $_SESSION or $options['entity']
	 *   
	 * @param $options
	 * @return List of cached inputs
	 */
	function get_cached_inputs($options) {
		// Load default values as elgg like system :)
		$defaults = array(
			'input_names'=>array(),
			);
		$options = array_merge($defaults,$options);		
		
		$cached_inputs = array();
		foreach ($options['input_names'] as $input) {
			
			if (!$options['entity']) {
				// If the input is serialize than use unserialize() to get the correct value
				if (is_serialized_string($_SESSION['cached_'.$input])) {
					$cached_inputs[$input] = unserialize($_SESSION['cached_'.$input]); 
				} else {
					// If It was selected to prioritize the $_SESSION than get values from $_SESSION
					$cached_inputs[$input] = $_SESSION['cached_'.$input];
				}
			} else {
				// If we are editing some entity than get values from It
					$cached_inputs[$input] = $options['entity']->$input;
			}
		}
		
		return $cached_inputs;
	}
	
	/**
	 * Check if one string is serialized or not
	 * 
	 * @param unknown_type $string
	 * @return true|false Depends on success
	 */
	function is_serialized_string($string) {
		$serialized_false = serialize(false);
		if((($unserialized_string = unserialize($string)) === false) && ($string != $serialized_false)) {
			return false;
		}
		return true;
	}
	
?>
