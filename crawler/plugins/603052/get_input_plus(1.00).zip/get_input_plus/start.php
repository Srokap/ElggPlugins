<?php
	/**
	 * @file start.php
	 * @brief Set the get_input_plus plugin on elgg system
	 */

	/**
	 * Set the get_input_plus basic configuration on elgg system
	 */
	function get_input_plus_init() {
		global $CONFIG;
		
		register_translations($CONFIG->pluginspath.'get_input_plus/languages',true);
		register_page_handler('get_input_plus','get_input_plus_page_handler');
	}
	
	include('lib/get_input_plus.php');
	
	/**
	 * Set get_input_plus submenu items on elgg system 
	 */
	function get_input_plus_pagesetup() {
		if ((get_context() == 'admin') && (isadminloggedin())) {
			global $CONFIG;
			
			add_submenu_item(elgg_echo('get_input_plus:demo'),$CONFIG->wwwroot.'pg/get_input_plus/demo','get_input_plus');
			add_submenu_item(elgg_echo('get_input_plus:see_demo_entities'),$CONFIG->wwwroot.'pg/get_input_plus/see_demo_entities','get_input_plus');
			add_submenu_item(elgg_echo('get_input_plus:doc'),$CONFIG->wwwroot.'mod/get_input_plus/doc/index.html','get_input_plus');
		}
	}
	
	/**
	 * Handle the get_input_plus pages
	 * 
	 * @param $page
	 */
	function get_input_plus_page_handler($page) {
		
		if (isset($page[0])) {
			global $CONFIG;
			switch($page[0])
			{
				case 'demo':
					include($CONFIG->pluginspath.'get_input_plus/demo.php');
					break;
					
				case 'see_demo_entities':
					include($CONFIG->pluginspath.'get_input_plus/see_demo_entities.php');
					break;
					
				case 'edit_entity':
					set_input('entity_guid',$page[1]);
					include($CONFIG->pluginspath.'get_input_plus/edit_entity.php');
					break;
			}
		}
	}
	
	register_elgg_event_handler('init','system','get_input_plus_init');
	register_elgg_event_handler('pagesetup','system','get_input_plus_pagesetup');
	
	global $CONFIG;
	
	register_action('get_input_plus/edit_entity',true,$CONFIG->pluginspath.'get_input_plus/actions/edit_entity.php');
	register_action('get_input_plus/delete_entity',true,$CONFIG->pluginspath.'get_input_plus/actions/delete_entity.php');
?>