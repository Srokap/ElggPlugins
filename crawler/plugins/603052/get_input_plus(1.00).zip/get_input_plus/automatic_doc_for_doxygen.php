<?php
	/**
	 * @file automatic_doc_for_doxygen.php
	 * @brief Provides some information for doxygen
	 */

	/**
	 * @mainpage get_input_plus
	 * 
	 * Provides a very useful function for get inputs from forms and stock them into $_SESSION in case of error during the action
	 * <br />
	 * <br />
	 * 
	 * <b>Author: </b>José Gomes; email: juniordesiron@gmail.com
	 * <br />
	 * <b>Elgg Version: </b>1.7.3
	 * <br />
	 * <b>Published: </b>27/10/2010
	 * <br />
	 * <b>Last update: </b>27/10/2010
	 * <br />
	 * <b>Functionality: </b><br />
	 * (version 1.00)<br />
	 * 1 - The main functions: get_input_plus() and get_cached_inputs().<br />
	 * 2 - Demo page where It's possible to see how the functions works (looking the files of course).<br />
	 * <br />
	 */
?>