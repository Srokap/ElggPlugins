<?php
	/**
	 * @file demo.php
	 * @brief Displays the demo of how to use the get_input_plus plugin
	 */

	require_once(dirname(dirname(dirname(__FILE__))).'/engine/start.php');
	
	admin_gatekeeper();
	set_context('admin');
	
	$title = elgg_echo('get_input_plus:demo');
	
	$area2 = elgg_view_title($title);
	$area2 .= elgg_view('get_input_plus/edit_entity');
	
	$page_body = elgg_view_layout('two_column_left_sidebar',$area1,$area2);

	page_draw($title,$page_body);
?>