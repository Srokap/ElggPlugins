<?php
	/**
	 * @file languages/en.php
	 * @brief Set get_input_plus english translation on elgg system
	 */

	$english = array(
		'get_input_plus:delete'=>'Delete',
		'get_input_plus:demo'=>'get_input_plus demo',
		'get_input_plus:description'=>'Description',
		'get_input_plus:doc'=>'Get input plus doc',
		'get_input_plus:edit'=>'Edit',
		'get_input_plus:entity_deleted_successfully'=>'The entity with GUID "%d" was deleted successfully',
		'get_input_plus:entity_saved_successfully'=>'The entity was saved successfully,<br /> but you need to leave the title or description blank to see how works the cached inputs system',
		'get_input_plus:metadata1'=>'Metadata 1',
		'get_input_plus:metadata2'=>'Metadata 2',
		'get_input_plus:save'=>'Save',
		'get_input_plus:see_demo_entities'=>'See demo entities',
		'get_input_plus:title'=>'Title',
	
		// Error messages
		
		'errors:blank_title'=>'The required field <b>title</b> was not filled',
		'errors:blank_description'=>'The required field <b>description</b> was not filled',
		);
		
	add_translation('en',$english);
?>