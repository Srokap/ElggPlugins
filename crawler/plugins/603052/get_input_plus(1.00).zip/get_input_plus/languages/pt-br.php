<?php
	/**
	 * @file languages/pt-br.php
	 * @brief Set get_input_plus portuguese translation on elgg system
	 */

	$portuguese = array(
		'pt-br'=>'Português (Brasil)',
	
		'get_input_plus:delete'=>'Deletar',
		'get_input_plus:demo'=>'get_input_plus demo',
		'get_input_plus:description'=>'Descrição',
		'get_input_plus:doc'=>'Documentação do get_input_plus',
		'get_input_plus:entity_deleted_successfully'=>'A entidade com GUID "%d" foi deletada com sucesso',
		'get_input_plus:entity_saved_successfully'=>'The entity was saved successfully,<br /> but you need to leave the title or description blank to see how works the cached inputs system',
		'get_input_plus:entity_saved_successfully'=>'A entidade foi salva com successo,<br /> porém você precisa deixar o título ou descrição em branco para ver como o sistema de cache para as inputs funciona',
		'get_input_plus:metadata1'=>'Metadata 1',
		'get_input_plus:metadata2'=>'Metadata 2',
		'get_input_plus:save'=>'Salvar',
		'get_input_plus:see_demo_entities'=>'Ver entitidades de teste',
		'get_input_plus:title'=>'Título',
	
		// Error messages
		'errors:blank_title'=>'O campo obrigatório field <b>Título</b> não foi preenchido',
		'errors:blank_description'=>'O campo obrigatório <b>Descrição</b> não foi preenchido',
		);
		
	add_translation('pt-br',$portuguese);
?>