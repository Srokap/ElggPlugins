<?php
	/**
	 * @file views/default/get_input_plus/edit_entity.php
	 * @brief Displays the form for edit entity using the get_input_plus system
	 */

	// If $vars['entity'] exists than pass It for get_cached_inputs() function
	$options = array(
		'entity'=>$vars['entity'],
		'input_names'=>array('title','description','metadata1','metadata2'),
		);
	$inputs = get_cached_inputs($options);
	
	$action = $vars['url'].'action/get_input_plus/edit_entity';
	
	$form_body = '';
	
	// Setting input title
	$form_body .= '<label>';
	$form_body .= elgg_echo('get_input_plus:title');
	$form_body .= elgg_view('input/text',array('internalname'=>'title','value'=>$inputs['title']));
	$form_body .= '</label>';
	$form_body .= '<br /><br />';
	
	// Setting input description
	$form_body .= '<label>';
	$form_body .= elgg_echo('get_input_plus:description');
	$form_body .= elgg_view('input/longtext',array('internalname'=>'description','value'=>$inputs['description']));
	$form_body .= '</label>';
	$form_body .= '<br /><br />';
	
	// Setting input metadata 1
	$form_body .= '<label>';
	$form_body .= elgg_echo('get_input_plus:metadata1');
	$form_body .= elgg_view('input/text',array('internalname'=>'metadata1','value'=>$inputs['metadata1']));
	$form_body .= '</label>';
	$form_body .= '<br /><br />';
	
	// Setting input metadata 2
	$form_body .= '<label>';
	$form_body .= elgg_echo('get_input_plus:metadata2');
	$form_body .= '<br />';
	$options = array(
		'Label 1'=>'value_1',
		'Label 2'=>'value_2',
		'Label 3'=>'value_3',
		'Label 4'=>'value_4'
		);
	$form_body .= elgg_view('input/checkboxes',array('internalname'=>'metadata2','options'=>$options,'value'=>$inputs['metadata2']));
	$form_body .= '</label>';
	$form_body .= '<br /><br />';
	
	// Setting the form submit button
	$form_body .= elgg_view('input/submit',array('value'=>elgg_echo('get_input_plus:save')));
	
	// Setting the form in according with elgg views system
	$form = elgg_view('input/form',array('body'=>$form_body,'action'=>$action));
	
	echo $form;
?>