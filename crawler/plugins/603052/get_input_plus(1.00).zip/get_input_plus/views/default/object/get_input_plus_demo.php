<?php
	/**
	 * @file views/default/object/get_input_plus_demo.php
	 * @brief Displays the demo entities created for test
	 */

	$edit_link = $vars['url'].'pg/get_input_plus/edit_entity/'.$vars['entity']->guid;
	echo '<a href="'.$edit_link.'">'.elgg_echo('get_input_plus:edit').'</a>';
	
	echo ' / ';
	$delete_link = $vars['url'].'action/get_input_plus/delete_entity?entity_guid='.$vars['entity']->guid;
	echo elgg_view('output/confirmlink',array('text'=>elgg_echo('get_input_plus:delete'),'href'=>$delete_link));
	
	if ($vars['full']) {
		echo elgg_view('export/entity', $vars);
	} else {
	
		$icon = elgg_view(
				'graphics/icon', array(
				'entity' => $vars['entity'],
				'size' => 'small',
			)
		);
	
	
		$title = $vars['entity']->title;
		if (!$title) {
			$title = $vars['entity']->name;
		}
		if (!$title) {
			$title = get_class($vars['entity']);
		}
	
		$controls = "";
		if ($vars['entity']->canEdit()) {
			$delete = elgg_view('output/confirm_link', array(
				'href' => "{$vars['url']}action/entities/delete?guid={$vars['entity']->guid}", 
				'text' => elgg_echo('delete')
			));
			$controls .= " ($delete)";
		}
	
		$info = "<div><p><b><a href=\"" . $vars['entity']->getUrl() . "\">" . $title . "</a></b> $controls </p></div>";
	
		if (get_input('search_viewtype') == "gallery") {
			$icon = "";
		}
	
		$owner = $vars['entity']->getOwnerEntity();
		$ownertxt = elgg_echo('unknown');
		if ($owner) {
			$ownertxt = "<a href=\"" . $owner->getURL() . "\">" . $owner->name ."</a>";
		}
	
		$info .= "<div>".sprintf(elgg_echo("entity:default:strapline"),
			elgg_view_friendly_time($vars['entity']->time_created),
			$ownertxt
		);
	
		$info .= "</div>";
	
		$info = "<span title=\"" . elgg_echo('entity:default:missingsupport:popup') . "\">$info</span>";
		$icon = "<span title=\"" . elgg_echo('entity:default:missingsupport:popup') . "\">$icon</span>";
	
		echo elgg_view_listing($icon, $info);
	}
