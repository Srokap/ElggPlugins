<?php
	/**
	 * @file actions/delete_entity.php
	 * @brief Handle the action to delete the demo entities created for test
	 */

	action_gatekeeper();
	
	if ($entity_guid = get_input('entity_guid')) {
		delete_entity($entity_guid);
		
		system_message(sprintf(elgg_echo('get_input_plus:entity_deleted_successfully'),$entity_guid));
	}
	
	forward($_SERVER['HTTP_REFERER']);
?>