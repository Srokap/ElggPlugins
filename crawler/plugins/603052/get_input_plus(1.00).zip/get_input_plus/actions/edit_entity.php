<?php
	/**
	 * @file actions/edit_entity.php
	 * @brief Edit get_input_plus demo entities
	 */

	action_gatekeeper();
	
	$options['input_names'] = array(
		'required_inputs'=>array('title','description'),
		'metadata1',
		'metadata2');	
	$inputs = get_input_plus($options);
	
	$demo_entity = new ElggObject();
	$demo_entity->title = $inputs['title'];
	$demo_entity->description = $inputs['description'];
	$demo_entity->access_id = 2;
	$demo_entity->subtype = 'get_input_plus_demo';
	
	$demo_entity->save();
	
	$demo_entity->metadata1 = $inputs['metadata1'];
	$demo_entity->metadata2 = $inputs['metadata2'];
	
	system_message(elgg_echo('get_input_plus:entity_saved_successfully'));
	
	forward($_SERVER['HTTP_REFERER']);
?>