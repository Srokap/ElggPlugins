<?php

add_translation('en', array(
	'follow:user' => 'Follow',
	'unfollow:user' => 'Unfollow',

	'widgets:following:name' => 'Following',
	'widgets:following:description' => 'A list of the users you are following',

	'widgets:followers:name' => 'Followers',
	'widgets:followers:description' => 'A list of your followers',
));