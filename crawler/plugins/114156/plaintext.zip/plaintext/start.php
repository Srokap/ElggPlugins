<?php
 
    function plaintext_init()
    {
    }
 
    register_elgg_event_handler('init','system','plaintext_init');
 
?>