<?php
/**
	 * Elgg scroll_on_top plugin
	 * 
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Matthias Sutter email@matthias-sutter.de
	 * @copyright cubeyoo.de
	 * @link http://cubeyoo.de
	 */
?>

	<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/scroll_on_top/views/default/scroll_on_top/js/scrolltopcontrol.js"></script> 

