<?php
/**
	 * Elgg scroll_on_top plugin
	 * 
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Matthias Sutter email@matthias-sutter.de
	 * @copyright cubeyoo.de
	 * @link http://cubeyoo.de
	 */




	$german = array(
	       'scrolltotop:back_to_top' => 'Hochscrollen',

		 

	       
		
	);
					
	add_translation("de",$german);
?>