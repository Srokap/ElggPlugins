<?php

/**
	 * Elgg scroll_on_top plugin
	 * 
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Matthias Sutter email@matthias-sutter.de
	 * @copyright cubeyoo.de
	 * @link http://cubeyoo.de
	 */
	
	
	/* Initialise the plugin */
    function scroll_on_top_init() {
			
	    // Load system configuration
		elgg_extend_view('page_elements/header','scroll_on_top/js', 499);
				elgg_extend_view('scroll_on_top/pageshell');
					global $CONFIG;
			// Load the language file
					register_translations($CONFIG->pluginspath . "scroll_on_top/languages/");

     }
     
     // Make sure the status initialisation function is called on initialisation

			register_elgg_event_handler('pagesetup','system','scroll_on_top_pagesetup');
       
?>
