<?php
	function wp_export_renderAuthors($authors) {
		foreach($authors as $author) {
			$author_id = $author['id'];
			$author_username = $author['username'];
			$author_email = $author['email'];
			$author_name = $author['name'];

			$names = explode($author_name,' ');
			$author_firstname = array_shift($names);
			if(!empty($names)) $author_lastname = implode($names,' ');
			else $author_lastname = '';

			include('templates/author_template.php');
		}
	}

	function wp_export_getUserByID($userid) {
		GLOBAL $users;
		foreach($users as $user) {
			if($user['id']==$userid) return $user;
		}
		return array('id'=>0,'username'=>$username,'name'=>$username,'email'=>'','url'=>'','admin'=>'no');
	}

	function wp_export_renderPosts($posts) {
		GLOBAL $base_blog_url;
		/* render posts */
		foreach($posts as $post) {
//debug($post);
			$author = wp_export_getUserByID($post['author_id']);

			$post_id = $post['id'];
			$post_title = $post['title'];
			$post_url = str_replace('{post_id}',$post['id'],$base_blog_url);
			$post_pubdate = date('D, d M Y H:i:s +0000',$post['time_created']);
			$post_date = date('D, d M Y H:i:s',$post['time_created']);
			$post_date_gmt = $post_date; // I'm assuming all times in GMT.  If anyone needs otherwise, they'll have to add the functionality.
			$post_author_username = $author['username'];
			$post_description = xmlentities($post['title']);
			$post_content = xmlentities($post['content']);
			$post_excerpt = ''; // I'm not using excerpts, so I don't need this.  Maybe someone can extend this if they do need it.
			$post_name = str_replace(' ','_',strtolower($post['title'])); //attempt to create wordpress style name... ( fingers crossed! :-o )

			$post_tags = array();
			$post_comments = $post['comments'];

			include('templates/post_template.php');
		}
	}

	function wp_export_renderPostTags($tags) {
		/* TO DO */
	}

	function wp_export_renderPostComments($comments) {
		foreach($comments as $comment) {
//debug($comment);
			$author = wp_export_getUserByID($comment['author_id']);

			$comment_id = $comment['comment_id'];
			$comment_user_id = $comment['author_id']; 
			$comment_author = $author['username'];
			$comment_author_email = $author['email'];
			$comment_author_url = '';  // not doing these yet.  Don't think anything meaningful can come from elgg?
			$comment_author_IP = ''; // not saved.
			$comment_date = date('D, d M Y H:i:s',$comment['time_created']);
			$comment_date_gmt = $comment_date; 
			$comment_content = xmlentities($comment['content']);

			include('templates/comment_template.php');
		}
	}

	function xmlentities($string) {
		// based on answer by mario on stackoverflow
		// http://stackoverflow.com/questions/5362195/need-php-to-encode-special-characters-but-not-html-tags-for-inclusion-in-a-wordp/5362427#5362427
		$string=utf8_encode($string);
		$string = preg_replace_callback("/(?!\w)\p{L}/u", "xmlent", $string);
		return $string;
	}

	function xmlent($m) {
		// from answer by mario on stackoverflow
		// http://stackoverflow.com/questions/5362195/need-php-to-encode-special-characters-but-not-html-tags-for-inclusion-in-a-wordp/5362427#5362427
		$str = mb_convert_encoding( $m[0] , "UCS-2BE", "UTF-8");
		return "&#x" . bin2hex($str) . ";";
	}

	function debug() {
		// This is a just a handy function for debugging
		// Uncomment to use
		$prefix = '';
		for($i = 0 ; $i < func_num_args(); $i++) {
			$arg = func_get_arg($i);
			if(is_object($arg) or is_array($arg)) {
				if(is_object($arg)) {
					// Make sure we don't accidentally display things we shouldn't
					// during debug operations...
					
					if(isset($arg->pswd)) {
						$arg->pswd = '*******************';
						$temp_pswd = $arg->pswd;
					}
				}
				echo '<pre>'.$prefix.print_r($arg,true).'</pre>';
				$prefix = '';
				if(is_object($arg)) {					
					if(isset($arg->pswd)) {
						$arg->pswd = $temp_pswd;
					}
				}
			} else $prefix .= $arg;
		}
		echo '<pre>'.$prefix.'</pre>';
	}
?>
