<?php
	// Script to export Elgg data to WordPress eXtended RSS format...

	// Load Elgg settings
	require_once("../../engine/settings.php");

	require_once("wpexport_output_functions.php");
	require_once("wpexport_getdata_functions.php");
	require_once("class_mysql_db.php");

	$host=$_SERVER['HTTP_HOST'];
	$base_blog_url='http://'.$host.'/pg/blog/read/{post_id}'; // may need to edit this for different installs?

	$db = new wpexport_MySQLDataBase($CONFIG->dbhost,$CONFIG->dbuser,$CONFIG->dbpass,$CONFIG->dbname);

	// First get all the users into an array
	$users = wpexport_get_users();

	// Then get all the posts
	$posts = wpexport_get_blogposts();

	// Then for each post, get its replies
	foreach($posts as $id => $post) {
		$posts[$id]['comments'] =  wpexport_get_comments($post['id']);
	}

//debug($posts);
	
	// Display Data:
	header ("Content-Type:text/xml");
	include("templates/page_template.php");
?>
