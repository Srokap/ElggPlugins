		<wp:comment>
			<wp:comment_id><?php echo $comment_id; ?></wp:comment_id>
			<wp:comment_author><![CDATA[<?php echo $comment_author; ?>]]></wp:comment_author>
			<wp:comment_author_email><?php echo $comment_author_email; ?></wp:comment_author_email>
			<wp:comment_author_url><?php echo $comment_author_url; ?></wp:comment_author_url>
			<wp:comment_author_IP><?php echo $comment_author_IP; ?></wp:comment_author_IP>
			<wp:comment_date><?php echo $comment_date; ?></wp:comment_date>
			<wp:comment_date_gmt><?php echo $comment_date_gmt; ?></wp:comment_date_gmt>
			<wp:comment_content><![CDATA[<?php echo $comment_content; ?>]]></wp:comment_content>
			<wp:comment_approved>1</wp:comment_approved>
			<wp:comment_type></wp:comment_type>
			<wp:comment_parent>0</wp:comment_parent>
			<wp:comment_user_id><?php echo $comment_user_id; ?></wp:comment_user_id>
		</wp:comment>
