	<item>
		<title><?php echo $post_title; ?></title>
		<link><?php echo $post_url; ?></link>
		<pubDate><?php echo $post_pubdate; ?></pubDate>
		<dc:creator><?php echo $post_author_username; ?></dc:creator>
		<guid isPermaLink="false"><?php echo $post_url; ?></guid>
		<description><?php echo $post_description; ?></description>
		<content:encoded><![CDATA[<?php echo $post_content; ?>]]></content:encoded>
		<excerpt:encoded><![CDATA[<?php echo $post_excerpt; ?>]]></excerpt:encoded>
		<wp:post_id><?php echo $post_id; ?></wp:post_id>
		<wp:post_date><?php echo $post_date; ?></wp:post_date>
		<wp:post_date_gmt><?php echo $post_date_gmt; ?></wp:post_date_gmt>
		<wp:comment_status>open</wp:comment_status>
		<wp:ping_status>open</wp:ping_status>
		<wp:post_name><?php echo $post_name; ?></wp:post_name>
		<wp:status>publish</wp:status>
		<wp:post_parent>0</wp:post_parent>
		<wp:menu_order>0</wp:menu_order>
		<wp:post_type>post</wp:post_type>
		<wp:post_password></wp:post_password>
		<wp:is_sticky>0</wp:is_sticky>
		<?php wp_export_renderPostTags($post_tags); ?>
		<?php wp_export_renderPostComments($post_comments); ?>
	</item>
