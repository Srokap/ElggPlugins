<category domain="<?php echo $tag_domain; ?>" nicename="<?php echo $tag_nicename; ?>"><![CDATA[<?php echo $tag_name; ?>]]></category>
