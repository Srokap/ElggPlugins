<?php
	class wpexport_MySQLDataBase {
		public $host;
		public $user;
		public $pswd;
		public $schm;

		public $conn = false;

		public $sql = '';
		public $result = false;
		public $err = array();

		function __construct($host='',$user='',$pswd='',$schm='') {
			$this->host = $host;
			$this->user = $user;
			$this->pswd = $pswd;
			$this->schm = $schm;
		}

		// Execute a query with no results
		function execute($sql = '',$buffer=false) {
			if($sql != '') $this->sql = $sql;

			$this->connect();

			$this->result = false;
			if($buffer) $this->result = mysql_unbuffered_query($this->sql, $this->conn);
			else $this->result = mysql_query($this->sql, $this->conn);

			if(!$this->result) {
				$this->err[] = 'Error occurred executing query ('.$this->sql.')';
				debug($this->err);
			}
		}

		// Get a single value from database
		function getValue($sql = '') {
			if($row = $this->getRow($sql,false)) return $row[0];
			else return false;
		}

		// Get a single row from database as an array
		function getRow($sql = '',$assoc=true) {
			$this->execute($sql,true);
			$row = false;
			if($assoc) {
				$row = mysql_fetch_assoc($this->result);
			} else {
				$row = mysql_fetch_row($this->result);				
			}
			mysql_free_result($this->result);
			return $row;
		}

		// Get a single column from database as an array
		// or Get two columns from database as an associative array
		function getCol($sql = '',$assoc=false) {
			$this->execute($sql,true);

			$data = array();
			while($row = mysql_fetch_row($this->result)) {
				if($assoc) $data[$row[0]] = $row[1];
				else $data[] = $row[0];
			}
			mysql_free_result($this->result);
			return $data;
		}

		// Get two dimensional array from database
		function getData($sql = '',$assoc_col=true,$assoc_row=false) {
			$this->execute($sql,true);

			$data = array();
			if($assoc_col) {
				while($row = mysql_fetch_assoc($this->result)) {
					if($assoc_row) {
						$key = array_shift($row);
						$data[$key] = $row;
					} else {
						$data[] = $row;
					} 
				}
			} else {
				while($row = mysql_fetch_row($this->result)) {
					if($assoc_row) {
						$key = array_shift($row);
						$data[$key] = $row;
					} else {
						$data[] = $row;
					} 
				}
			}

			mysql_free_result($this->result);
			return $data;
		}

		// Ensure database is connected
		function connect($reconnect = false) {
			if($reconnect) {
				if(!mysql_ping($this->conn)) {
					$this->disconnect();
				}
			}

			if(!$this->conn) {
				$this->conn = mysql_connect($this->host,$this->user,$this->pswd);
				
				if(!$this->conn) $err[] = 'Could not connect to database on '.$this->host.' as '.$this->user;
				else {
					$connected = mysql_select_db($this->schm, $this->conn);
					if(!$connected) $err[] = 'Could not select database '.$this->schm;
				}
			}
		}

		// Force a disconnect from the database
		function disconnect() {
			if($this->conn) {
				mysql_close($this->conn);
				$this->conn = false;
			}
		}
	}
?>
