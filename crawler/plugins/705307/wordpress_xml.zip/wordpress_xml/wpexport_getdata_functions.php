<?php
	function wpexport_get_users() {
		global $CONFIG;
		global $db;

		$sql = "SELECT distinct u.guid id, u.name, u.username, u.email, u.admin from {$CONFIG->dbprefix}users_entity u where u.last_login > 0 order by u.guid asc";

		$results = $db->getData($sql);

		return $results;
	}

	function wpexport_get_blogposts() {
		global $CONFIG;
		global $db;

		$sql = "SELECT en.guid id, en.owner_guid author_id, en.time_created, en.time_updated, en.last_action, en.enabled, ob.title, ob.description content
FROM `{$CONFIG->dbprefix}entities` en
JOIN `{$CONFIG->dbprefix}objects_entity` ob ON en.guid = ob.guid
JOIN `{$CONFIG->dbprefix}entity_subtypes` st ON en.subtype = st.id AND st.subtype = 'blog'"; 
//debug('[',$sql,']');

		$results = $db->getData($sql);
//debug($db,'{',$results,'}');

		return $results;
	}

	function wpexport_get_comments($post_id) {
		global $CONFIG;
		global $db;

		// This is the tricky bit in elgg.  Comments are stored as 'annotations' in a weird way along with lots
		// of other miscellaneous meta-data, rather than as entities or posts in their own right.

		$sql = "SELECT a.id comment_id, a.owner_guid author_id, a.time_created, n.string name, v.string content 
FROM `{$CONFIG->dbprefix}annotations` a
join `{$CONFIG->dbprefix}entities` en ON en.guid = a.entity_guid AND en.guid = $post_id
join `{$CONFIG->dbprefix}metastrings` v ON a.value_id = v.id  
join `{$CONFIG->dbprefix}metastrings` n ON a.value_id = n.id";
//debug('[',$sql,']');

		$results = $db->getData($sql);
//debug('{',$results,'}');

		return $results;		
	}
?>
