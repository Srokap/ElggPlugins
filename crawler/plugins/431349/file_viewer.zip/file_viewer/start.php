<?php
/*
 * © Copyright by Laboratorio de Redes 2009–2010
 */

/*
 *  This is needed to let the plugin remove the metadata */
function socialwire_permissions_check($hook, $entity_type, $returnvalue, $params) {
    if (get_context() != 'socialwire_file_viewer') {
        return $returnvalue;
    }

    return true;
}

/* This function is called for us to have full admin rights. It is a kinda hack,
 * put it works.  Simply returning the user/id of a admin, on the contrary,
 * is no enough :(.
 *
 * Trac bug #1078
 */
function socialwire_session_get_hook($hook, $entity_type, $returnvalue, $params) {
    if (get_context() != 'socialwire_file_viewer') {
        return $returnvalue;
    }
    global $is_admin;

    $is_admin = true;

    return $returnvalue;
}

function file_viewer_remove_old_tokens($files) {
    foreach ($files as $file) {
        $metadata = get_metadata_for_entity($file->getGUID());

        foreach ($metadata as $datum) {
            if ($datum->value == 'token') {
                if ((time() - (int)$datum->time_created) > 7200) {
                    $datum->delete();
                }
            }
        }
    }
}

function file_viewer_clean_tokens() {
    /* If there is any logged in user and is not an admin, refrain to run, as it
     * only causes problems with permissions. Maybe in a later Elgg code base...
     */
    $user = get_loggedin_user();
    if ($user && !$user->admin) {
        error_log('Do not run as an unprivileged user.');
        return;
    }

    $context = get_context();
    /* Lets pretend we are an admin and get edit permissions at the same time */
    set_context('socialwire_file_viewer');

    $nfiles = (int)get_entities('object', 'file', 0, '', 0, 0, true);
    $offset = 0;
    while ($nfiles > 0) {
        $nfiles -= 100;
        $files = get_entities('object', 'file', 0, '', 100, $offset);
        $offset += 100;

        file_viewer_remove_old_tokens($files);
    }

    set_context($context);
}

function file_viewer_page_handler($page) {

    global $CONFIG;

    if (isset($page[2])) {
        switch($page[0]) {
            case 'view':
                set_input('file_guid', $page[1]);
                set_input('token', $page[2]);
                @include(dirname(__FILE__) . '/view.php');
                return;
        }
    }

    return false;
}

function file_viewer_init() {
    global $CONFIG;

    register_page_handler('file_viewer', 'file_viewer_page_handler');
    register_plugin_hook('gc', 'system', 'file_viewer_clean_tokens');
    register_plugin_hook('session:get', 'all', 'socialwire_session_get_hook');
    register_plugin_hook('permissions_check', 'object', 'socialwire_permissions_check');
}

register_elgg_event_handler('init', 'system', 'file_viewer_init');

?>
