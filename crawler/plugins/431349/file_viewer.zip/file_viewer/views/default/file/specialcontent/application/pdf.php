<?php
/*
 * © Modifications by Laboratorio de Redes 2009–2010
 */

function getUniqueCode($length = "") {
    srand();
    $code = md5(uniqid(rand(), true));
    if ($length != "")
        return substr($code, 0, $length);
    else
        return $code;
}

if (get_context() == 'file') {
    $token = getUniqueCode();
    $entity = $vars['entity'];
    $entity->$token = 'token';

    $url = $vars['url'] . 'pg/file_viewer/view/' . $entity->getGUID() . '/' . $token;
    ?>
<iframe src="http://docs.google.com/viewer?embedded=true&url=<?php
            echo urlencode($url);?>" width="100%" height="780" style="border: none;">
</iframe>
<?php
}
?>