<?php

?>

#logbrowser_search_area {
	margin: 3px;
}

#logbrowserSearchform {
	background-color: #1c1c1c;
	padding:10px 0 10px;
}
#logbrowserSearchform .submit_button {
	margin:0 10px 0 10px;
}

.log_entry {
	margin: 2px 10px 2px 10px;
	width: 720px;
	font-size: 90%;
}
.log_entry td {
}

.log_entry_user {
	width: 120px;
	background-color: #1c1c1c;
}

.log_entry_time {
	width: 280px;
	background-color: #1c1c1c;
	padding:2px;
}

.log_entry_item {
	background-color: #1c1c1c;
	
}

.log_entry_action {
	width: 75px;
	background-color: #1c1c1c;
}