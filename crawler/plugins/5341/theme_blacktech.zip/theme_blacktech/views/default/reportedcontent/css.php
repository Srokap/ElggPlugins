/* ***************************************
	ADMIN AREA - REPORTED CONTENT 
*************************************** */
.reportedcontent_content {
	padding:10px;
	margin:0 0 10px 0;
}
.reportedcontent_content p.reportedcontent_detail,
.reportedcontent_content p {
	margin:0;
	color:#333333;
}
.active_report {
	border:1px solid #D3322A;
    background:#F7DAD8; /* red */
}
.archived_report {
	border:1px solid #666666;
    background:#dedede;
}

a.archive_report_button {
	float:right;
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: black;
	background:#990000; /* red */
	border: 1px solid #990000; /* red */
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	width: auto;
	padding: 4px;
	margin:15px 0 0 20px;
	cursor: pointer;
}
a.archive_report_button:hover {
	background: black;
	color:#990000; /* red */
	text-decoration: none;
}

a.delete_report_button {
	float:right;
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #ffffff;
	background:#999999;
	border: 1px solid #999999;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	width: auto;
	padding: 4px;
	margin:15px 0 0 20px;
	cursor: pointer;
}
a.delete_report_button:hover {
	background: #333333;
	text-decoration:none;
}

a.manifest_details {
	cursor:pointer;
}
