<?php

	/**
	 * Elgg twitter CSS extender 
	 * 
	 * @package ElggTwitter
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

?>

#twitter_widget {
    
}

#twitter_widget ul {
	margin:0;
	padding:0;
}

#twitter_widget li {
    margin:0 0 5px 0;
    padding:7px 7px 28px 7px;
    list-style:none;
	background: #252525 url(<?php echo $vars['url']; ?>mod/theme_blacktech/graphics/twitter_arrow.gif) no-repeat right bottom;
}
#twitter_widget li span {
	color:#cccccc;
}

p.visit_twitter {
    background:url(<?php echo $vars['url']; ?>mod/twitter/graphics/twitter.png) left no-repeat;
    padding:0 0 0 20px;
    margin:0;
}