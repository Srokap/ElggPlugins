<?php
	echo $vars['url'] . "mod/theme_blacktech/graphics/file_icons/pages.gif";
?>