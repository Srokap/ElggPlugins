#forgotten_box{
	margin:10px;
	padding:10px;
	background:white;
	-moz-border-radius:8px;
}