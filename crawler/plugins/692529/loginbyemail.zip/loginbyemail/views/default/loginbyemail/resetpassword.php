<?php
	//require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	$user_guid = $vars['user_guid'];
	$code = $vars['code'];
	
	$form_body = elgg_echo('user:resetpassword:reset_password_confirm') . "<br />";

	$form_body .= elgg_view('input/hidden', array(
		'internalname' => 'u',
		'value' => $user_guid
	));

	$form_body .= elgg_view('input/hidden', array(
		'internalname' => 'c',
		'value' => $code
	));

	$form_body .= elgg_view('input/submit', array(
		'value' => elgg_echo('resetpassword')
	));

	$form .= elgg_view('input/form', array(
		'body' => $form_body,
		'action' => $CONFIG->site->url . 'action/user/passwordreset'
	));

	$title = elgg_echo('resetpassword');
	$content = elgg_view_title(elgg_echo('resetpassword')) . $form;

	echo elgg_view_layout('one_column', $content);
?>