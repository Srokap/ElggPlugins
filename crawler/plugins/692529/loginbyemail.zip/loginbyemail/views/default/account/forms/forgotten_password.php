<?php
	/**
	 * Login by Email
	 * 
	 * @author Pedro Prez
	 * @link http://community.elgg.org/pg/profile/pedroprez
	 * @copyright (c) Keetup 2009
	 * @link http://www.keetup.com/
	 * @license GNU General Public License (GPL) version 2
	 */

	//$form_body = "PING<p>" . elgg_echo('user:password:text:loginbyemail') . "</p>";
	//$form_body .= "<p><b>". elgg_echo('username/email') . "</b> " 
	//. elgg_view('input/text', array('internalname' => 'username')) . "</p>";
	//$form_body .= elgg_view('input/captcha');
	//$form_body .= "<p>" . elgg_view('input/submit', array('value' => elgg_echo('request'))) . "</p>";

	//echo elgg_view('input/form', array('action' => "{$vars['url']}action/loginbyemail/requestnewpassword", 'body' => $form_body)); 
	//echo elgg_view('account/forms/register', array('action' => "{$vars['url']}action/loginbyemail/requestnewpassword", 'body' => $form_body)); 
	//echo elgg_view('account/forms/register', $form_body);
	//page_draw($title, elgg_view_layout('account/forms/register', $form_body));
/*
		<form class="box-form" method="post" action="<?php echo "{$vars['url']}action/loginbyemail/requestnewpassword";?>">
			<?php echo elgg_view('input/securitytoken');?>
			<fieldset>
				<div class="bf-head">
					<h2><span class="one-line"><?php echo elgg_echo('user:password:lost'); ?></span></h2>
				</div>
				<div class="bf-content">
					<div class="row">
						<?php echo elgg_echo('user:password:text:loginbyemail')?>
					</div>
					<div class="row">
						<label><?php echo elgg_echo('username/email');?></label>
						<?php echo elgg_view('input/text', array('internalname' => 'username'));?>
					</div>
					<?php echo elgg_view('input/captcha');?>				
					<div class="row row-send">
						<input type="submit" class="submit" value="<?php echo elgg_echo('request');?>">
					</div>
				</div>
			</fieldset>
		</form>*/

$form_body = "<p>" . elgg_echo('user:password:text') . "</p>";
$form_body .= "<p><label>". elgg_echo('username') . " "
	. elgg_view('input/text', array('internalname' => 'username')) . "</label></p>";
$form_body .= elgg_view('input/captcha');
$form_body .= "<p>" . elgg_view('input/submit', array('value' => elgg_echo('request'))) . "</p>";

?>
<div class="contentWrapper">
<?php
echo elgg_view('input/form', array(
	'action' => "{$vars['url']}action/user/requestnewpassword",
	'body' => $form_body)
);
?>
</div>