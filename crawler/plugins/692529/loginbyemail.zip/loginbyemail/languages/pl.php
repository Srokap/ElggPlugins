<?php
	/**
	 * Login by Email
	 * 
	 * @author Pedro Prez
	 * @link http://community.elgg.org/pg/profile/pedroprez
	 * @copyright (c) Keetup 2009
	 * @link http://www.keetup.com/
	 * @license GNU General Public License (GPL) version 2
	 */

	$polish = array(
			'user:email:notfound' => 'Email %s nie znaleziony.',
			'username/email' => 'Login/Email',
			'email:resetreq:body:wusername' => "Witaj %s,
			
Ktoś (z adresu IP: %s) poprosił o nowe hasło do Twojego konta.

Jeśli Ty to zleciłeś, to kliknij na poniższy link aby przenieść się na stronę umożliwiającą zmianę hasła, lub zignoruj tą wiadomość w przeciwnym przypadku.

Przypominamy, że Twoja nazwa użytkownika to: %s

%s",
	'user:password:text:loginbyemail' => 'Aby wygenerować nowe hasło podaj swoją nazwę użytkowanika lub adres e-mail podany przy rejestracji. Na adres e-mail zostanie wysłany unikalny link weryfikacyjny. Kliknij na link w treści otrzymanej wiadomości, a nowe hasło zostanie Ci przesłane.',
	'challengesd:requestnewpassword:text' => 'Aby wygenerować nowe hasło podaj swoją nazwę użytkowanika lub adres e-mail podany przy rejestracji. Na adres e-mail zostanie wysłany unikalny link weryfikacyjny. Kliknij na link w treści otrzymanej wiadomości, a nowe hasło zostanie Ci przesłane.'
	
	);
					
	add_translation("pl",$polish);
?>