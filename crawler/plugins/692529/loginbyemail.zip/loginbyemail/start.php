<?php
	
	/**
	 * Login by Email
	 * 
	 * @author Pedro Prez
	 * Modified by Mike Zacher, Elggdev
	 * @link http://community.elgg.org/pg/profile/pedroprez
	 * @copyright (c) Keetup 2009
	 * @link http://www.keetup.com/
	 * @license GNU General Public License (GPL) version 2
	 */

	function loginbyemail_init()
	{
		global $CONFIG;

		//Load functions
		require_once(dirname(__FILE__) . "/auth_functions.php");	
				
		// Register actions
		register_action("login", true, $CONFIG->pluginspath . "loginbyemail/actions/login.php");
		register_action("loginbyemail/requestnewpassword",true,$CONFIG->pluginspath . "loginbyemail/actions/requestnewpassword.php");
		register_action("usersettings/save",false,$CONFIG->pluginspath . "loginbyemail/actions/usersettings/save.php");
		//extend_view('css','loginbyemail/css');
		
		register_plugin_hook('usersettings:save:loginbyemail','user','users_settings_save_loginbyemail');
		register_plugin_hook('actionlist', 'captcha', 'vazco_loginbyemail_captcha_actionlist_hook',501);		
		register_pam_handler('pam_auth_emailpass');
		
		register_page_handler('resetpassword', 'vazco_loginbyemail_user_resetpassword_page_handler');		
	}

	function vazco_loginbyemail_captcha_actionlist_hook($hook, $entity_type, $returnvalue, $params){

		if (!is_array($returnvalue))
			$returnvalue = array();

		$returnvalue[] = 'loginbyemail/requestnewpassword';
			
		return $returnvalue;
	}

	function users_settings_save_loginbyemail()
	{
		global $CONFIG;

		@include($CONFIG->path . "actions/user/name.php");
		@include($CONFIG->path . "actions/user/password.php");
		@include(dirname(__FILE__) .  "/actions/email/save.php");
		@include($CONFIG->path . "actions/user/language.php");
	}
	
	/**
	 * Generate and send a password request email to a given user's registered email address.
	 * This is a modified default function, which send the username to the email.
	 * @param int $user_guid
	 */
	function send_new_password_request_with_username($user_guid)
	{
		global $CONFIG;
		
		$user_guid = (int)$user_guid;
		
		$user = get_entity($user_guid);
		if ($user)
		{
			// generate code
			$code = generate_random_cleartext_password();
			//create_metadata($user_guid, 'conf_code', $code,'', 0, ACCESS_PRIVATE);
			set_private_setting($user_guid, 'passwd_conf_code', $code);
			
			// generate link
			//$link = $CONFIG->site->url . "action/user/passwordreset?u=$user_guid&c=$code";
			$link = $CONFIG->site->url . "pg/resetpassword?u=$user_guid&c=$code";
	
			// generate email
			$email = sprintf(elgg_echo('email:resetreq:body:wusername',$user->language), $user->name, $_SERVER['REMOTE_ADDR'], $user->username, $link);
			
			$return = notify_user($user->guid, $CONFIG->site->guid, elgg_echo('email:resetreq:subject',$user->language), $email, NULL, 'email');
			
			return $return;
		}
		return false;
	}
	
	function vazco_loginbyemail_user_resetpassword_page_handler($page) {
		global $CONFIG;
	
		$user_guid = get_input('u');
		$code = get_input('c');
		$user = get_entity($user_guid);	
	
		// don't check code here to avoid automated attacks
		if (!$user instanceof ElggUser) {
			register_error(elgg_echo('user:passwordreset:unknown_user'));
			forward();
		}
		
		page_draw($title, elgg_view('loginbyemail/resetpassword', array('user_guid'=>$user_guid, 'code'=>$code)));
	}
    
	// Initialise
	register_elgg_event_handler('init','system','loginbyemail_init',400);
?>