
<p align="center">

		 <p align="center"><a href="<?php echo $vars['url']; ?>profile/<?php echo $_SESSION['user']->username; ?>"><img src="<?php echo $_SESSION['user']->getIconURL('medium'); ?>" style="border: 1px solid #cccccc;padding:3px;" /></a></p>
</br>
		 <div style="background:#303134 url(<?php echo $vars['url']; ?>mod/velletri/css/26.png) no-repeat center left; margin-bottom: 5px; padding-left: 20px; padding-top: 5px; padding-bottom: 5px; border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><a href="<?php echo $vars['url']; ?>profile/<?php echo $_SESSION['user']->username; ?>/edit" style="color:white;">Edit Profile</a></h3></div>

      <div style="background:#303134 url(<?php echo $vars['url']; ?>mod/velletri/css/38.png) no-repeat center left; margin-bottom: 5px; padding-left: 20px; padding-top: 5px; padding-bottom: 5px; border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><a href="<?php echo $vars['url']; ?>avatar/edit/<?php echo $_SESSION['user']->username; ?>/editicon" style="color:white;">Edit Avatar</a></h3></div>

      

      <div style="background:#303134 url(<?php echo $vars['url']; ?>mod/velletri/css/7.png) no-repeat center left; margin-bottom: 5px; padding-left: 20px; padding-top: 5px; padding-bottom: 5px; border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><a href="<?php echo $vars['url']; ?>file/all" style="color:white;">Files</a></h3></div>

      <div style="background:#303134 url(<?php echo $vars['url']; ?>mod/velletri/css/24.png) no-repeat center left; margin-bottom: 5px; padding-left: 20px; padding-top: 5px; padding-bottom: 5px; border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><a href="<?php echo $vars['url']; ?>blog/all" style="color:white;">Blog</a></h3></div>

      <div style="background:#303134 url(<?php echo $vars['url']; ?>mod/velletri/css/16.png) no-repeat center left; margin-bottom: 5px; padding-left: 20px; padding-top: 5px; padding-bottom: 5px; border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><a href="<?php echo $vars['url']; ?>thewire/all/" style="color:white;">The Wire</a></h3></div>

      <div style="background:#303134 url(<?php echo $vars['url']; ?>mod/velletri/css/18.png) no-repeat center left; margin-bottom: 5px; padding-left: 20px; padding-top: 5px; padding-bottom: 5px; border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><a href="<?php echo $vars['url']; ?>messageboard/owner/<?php echo $_SESSION['user']->username; ?>" style="color:white;">Message Board</a></h3></div>

      <div style="background:#303134 url(<?php echo $vars['url']; ?>mod/velletri/css/41.png) no-repeat center left; margin-bottom: 5px; padding-left: 20px; padding-top: 5px; padding-bottom: 5px; border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><a href="<?php echo $vars['url']; ?>friends/<?php echo $_SESSION['user']->username; ?>" style="color:white;">Friends</a></h3></div>

      <div style="background:#303134 url(<?php echo $vars['url']; ?>mod/velletri/css/72.png) no-repeat center left; margin-bottom: 5px; padding-left: 20px; padding-top: 5px; padding-bottom: 5px; border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><a href="<?php echo $vars['url']; ?>settings/user/<?php echo $_SESSION['user']->username; ?>" style="color:white;">Settings</a></h3></div>
	</br>
	</br></br></br></br></br></br></br></br></br></br>
	</br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br>