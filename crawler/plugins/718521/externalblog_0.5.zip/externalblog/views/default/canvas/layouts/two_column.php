<?php
	/**
	 * Elgg two_column  layout
	 * 
	 * @package Elgg
	 * @subpackage Externalblog
	 * @author Facyla
	 * @link http://id.facyla.net/
	 */
?>

<!-- sidebar -->
<div id="externalblog_two" style="float:right;">
  <?php echo $vars['area1']; ?>
</div><!-- /sidebar -->

<!-- main content -->
<div id="externalblog_main" style="float:left;">
  <?php echo $vars['area2']; ?>
</div><!-- /left_column -->
