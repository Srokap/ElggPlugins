<?php
/**
 * Elgg right_column  layout
 * 
 * @package Elgg
 * @subpackage Externalblog
 * @author Facyla
 * @link http://id.facyla.net/
 */
?>

<!-- sidebar -->
<div id="externalblog_two" style="float:right; margin:0 !important; padding:0 !important; border:0 !important; width:30% !important;">
  <?php echo $vars['area1']; ?>
</div><!-- /sidebar -->

<!-- main content -->
<div id="externalblog_main" style="float:left; margin:0 !important; padding:0 !important; border:0 !important; width:70% !important;">
    <?php echo $vars['area2']; ?>
</div><!-- /left_column -->
