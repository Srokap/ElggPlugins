<?php

	/**
	 * Elgg one-column layout
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @author Curverider Ltd
	 * @link http://elgg.org/
	 */
?>

<!-- main content -->
<div id="externalblog_main">
    <?php echo $vars['area1']; ?>
</div><!-- /one_column -->	