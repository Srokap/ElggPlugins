<?php

	$english = array(
		'googlegeocoder:googleapi' => 'Google Maps API key',
);
					
	add_translation("en",$english);

?>
