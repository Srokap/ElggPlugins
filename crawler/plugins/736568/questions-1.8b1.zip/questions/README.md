# Questions for Elgg 1.8 #

Questions is a plugin for Elgg to provide your network with
Q&A functionality analagous to Quora, Stack Overflow, or Facebook Questions

## Features ##

* Ask questions as an individual or to a group.
* Comment on questions + answers (ala StackOverflow)
* Like questions + answers