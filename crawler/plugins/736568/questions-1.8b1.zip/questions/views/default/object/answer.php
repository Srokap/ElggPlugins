<?php
/**
 * answer entity view
 *
 * @package comments
*/

echo elgg_view('object/answer/full', $vars);