<?php

// Gerado pelo browser de tradução. 

$portuguese = array( 
	 'dokuwiki:wiki'  =>  "Wiki" , 
	 'dokuwiki:title'  =>  "Wikis" , 
	 'dokuwiki:wikifrom'  =>  "%s Wiki" , 
	 'dokuwiki:pages'  =>  "%s páginas" , 
	 'dokuwiki:dokuwiki'  =>  "Wiki" , 
	 'dokuwiki:groupwiki'  =>  "Wiki do grupo" , 
	 'dokuwiki:userwiki'  =>  "Minha Wiki" , 
	 'groups:enabledokuwiki'  =>  "Habilitar Wiki do grupo" , 
	 'dokuwiki'  =>  "Wikis" , 
	 'dokuwiki:river:modified'  =>  "%s modificou a página %s em %s"
); 

add_translation('pt', $portuguese); 

?>