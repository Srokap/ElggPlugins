<?php

// Generate By translationbrowser. 

$polish = array( 
	 'dokuwiki:wiki'  =>  "Wiki" , 
	 'dokuwiki:title'  =>  "Wiki" , 
	 'item:object:dokuwiki'  =>  "Wiki" , 
	 'dokuwiki:wikifrom'  =>  "%s wiki" , 
	 'dokuwiki:pages'  =>  "%s strony" , 
	 'dokuwiki:dokuwiki'  =>  "Wiki" , 
	 'dokuwiki:groupwiki'  =>  "Wiki Grupy" , 
	 'dokuwiki:userwiki'  =>  "Twoje Wiki" , 
	 'groups:enabledokuwiki'  =>  "Włącz wiki grupy" , 
	 'dokuwiki'  =>  "Wiki" , 
	 'dokuwiki:river:modified'  =>  "%s modyfikacja strony %s na %s"
); 

add_translation('pl', $polish); 

?>