<?php

// Generate By translationbrowser. 

$catalan = array( 
	 'dokuwiki:wiki'  =>  "Wiki" , 
	 'dokuwiki:groupwiki'  =>  "Wiki del grup" , 
	 'dokuwiki:userwiki'  =>  "La meva Wiki" , 
	 'dokuwiki'  =>  "Wikis" , 
	 'item:object:dokuwiki'  =>  "Wikis" , 
	 'dokuwiki:title'  =>  "Wikis" , 
	 'dokuwiki:wikifrom'  =>  "la wiki de %s" , 
	 'dokuwiki:pages'  =>  "%s pàgines" , 
	 'dokuwiki:dokuwiki'  =>  "Wiki" , 
	 'groups:enabledokuwiki'  =>  "Activar la wiki del grup" , 
	 'dokuwiki:river:modified'  =>  "%s ha modificat la pàgina %s el %s"
); 

add_translation('ca', $catalan); 

?>