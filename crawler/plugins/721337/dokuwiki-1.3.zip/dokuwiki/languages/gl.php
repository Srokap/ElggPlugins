<?php

// Generado por translationbrowser 

$galician = array( 
	 'dokuwiki:wiki'  =>  "Wiki" , 
	 'dokuwiki:groupwiki'  =>  "Wiki do grupo" , 
	 'dokuwiki:userwiki'  =>  "A miña Wiki" , 
	 'dokuwiki'  =>  "Wikis" , 
	 'item:object:dokuwiki'  =>  "Wikis" , 
	 'dokuwiki:title'  =>  "Wikis" , 
	 'dokuwiki:wikifrom'  =>  "%s wiki" , 
	 'dokuwiki:pages'  =>  "%s páxinas" , 
	 'dokuwiki:dokuwiki'  =>  "Wiki" , 
	 'groups:enabledokuwiki'  =>  "Habilitar wiki do grupo" , 
	 'dokuwiki:river:modified'  =>  "%s modificou a páxina %s en %s"
); 

add_translation('gl', $galician); 

?>