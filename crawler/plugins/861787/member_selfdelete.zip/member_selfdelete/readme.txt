This plugin allows members to delete their own accounts.

Optionally they can leave feedback about why they are leaving
that could be useful for admins to improve their site.

Installation:
Place this directory into the mod directory of your elgg installation.
Activate in the Tools Administration interface.