hypeStarRating is part of the hypeJunction plugin bundle

============
www.hypeJunction.com
hypeJunction is here for you to connect, innovate, integrate, collaborate and indulge.
hypeJunction is a bundle of plugins that will help you kick start your Elgg-based social network and spice it up with cool features and functionalities.
============

PLUGIN DESCRIPTION
------------------
hypeStarRating provides AJAXed rating for Elgg entities

This plugin:
- Creates an entity menu item with star rating
- Provides input/starrating and output/starrating to easily add star ratings to entity views

REQUIREMENTS
------------
1) Elgg 1.8.3+
2) hypeFramework 1.8.5+

INTEGRATION / COMPATIBILITY
---------------------------


INSTALLATION
------------
1. Upload and enable hypeFramework
2. Place hypeStarRation below hypeFramework and enable


UPGRADING FROM PREVIOUS VERSION
-------------------------------
-- Disable all hype plugins, except hypeFramework
-- Disable hypeFramework
-- Backup your database and files
-- Remove all hype plugins from your server and upload the new version
-- Enable hypeFramework
-- Enable other hype plugins


USER GUIDE
----------

NOTES / WARNINGS
----------------


TODO
----


BUG REPORTS
-----------
Bugs and feature requests can be submitted at:
http://hypeJunction.com/trac

