/**
 * Glee Theme Draft One
 * 
 * @package glee_theme_draft_one
 * @license http://www.gnu.org/licenses/gpl-3.0.txt
 * @author void <void@13net.at>
 * @copyright 2012 by 13net
 * @link http://www.13net.at/
 */

/**
 * Description
 */
A bootstrap theme for your Elgg site.

Top: Topbar + Header
Left: Site menu
Right: Body 
Bottom: Footer

/**
 * Languages
 */
English
German

