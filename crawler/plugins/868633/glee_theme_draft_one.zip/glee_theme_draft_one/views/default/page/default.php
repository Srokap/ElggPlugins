<?php

echo elgg_view('glee_theme_draft_one/page/fixed', $vars);
//echo elgg_view('glee_theme_draft_one/page/fluid', $vars);