<?php

// Deprecated in favor of type/elements/summary
echo elgg_view('object/elements/summary', $vars);
