<?php
/**
 * Elgg topbar
 */

$site = elgg_get_site_entity();
$site_name = $site->name;
$site_url = elgg_get_site_url();

$content_left  = "";
$content_right = "";

// BRAND NAME
$brand_name = <<<HTML
	<a href="$site_url"><h1 class="brand">$site->name</h1></a>
HTML;

// TOPBAR NAVIGATION
$topbar_menu = elgg_view_menu('topbar', array('sort_by' => 'priority'));

// LOGIN DROPDOWN
if (!elgg_is_logged_in()) {
    // drop-down login
    $login_dropdown =  elgg_view('core/account/login_dropdown');
    
    // add it to the right
    $content_right .= $login_dropdown;
}

$output = <<<HTML
    $brand_name
    <div class="nav-collapse">  
        $login_dropdown
        $topbar_menu
    </div>
HTML;

// $output = <<<HTML
//     <a class="btn btn-navbar" data-target=".nav-collapse" data-toggle="collapse">
//         <span class="icon-bar"></span>
//         <span class="icon-bar"></span>
//         <span class="icon-bar"></span>
//     </a>
//     $brand_name
//     <div class="nav-collapse collapse" style="height:0px;">  
//         $login_dropdown
//         $topbar_menu
//     </div>
// HTML;

echo $output;

