<?php
/**
 * Main content sidebar
 *
 * @uses $vars['content] The content for the sidebar
 */

echo $vars['content'];
