<?php
/**
 * Main content footer
 *
 * @uses $vars['content'] The content for the footer
 */

echo $vars['content'];
