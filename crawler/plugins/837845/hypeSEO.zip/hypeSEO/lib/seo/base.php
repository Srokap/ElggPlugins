<?php


function hj_seo_get_datalist($value) {
	global $CONFIG, $DATALIST_VALUE_CACHE;

	$value = trim($value);

	$value = sanitise_string($value);
	if (isset($DATALIST_VALUE_CACHE[$value])) {
		return $DATALIST_VALUE_CACHE[$value];
	}

	// If memcache enabled then cache value in memcache
	$name = null;
	static $datalist_value_memcache;
	if ((!$datalist_value_memcache) && (is_memcache_available())) {
		$datalist_value_memcache = new ElggMemcache('datalist_value_memcache');
	}
	if ($datalist_value_memcache) {
		$name = $datalist_value_memcache->load($value);
	}
	if ($name) {
		return $name;
	}

	$dbprefix = elgg_get_config('dbprefix');

	$result = get_data("SELECT * from {$dbprefix}datalists WHERE value = '$value'");

	if ($result) {
		foreach ($result as $row) {
			$DATALIST_VALUE_CACHE[$row->value] = $row->name;

			// Cache it if memcache is available
			if ($datalist_value_memcache) {
				$datalist_value_memcache->save($row->value, $row->name);
			}
		}

		if (isset($DATALIST_VALUE_CACHE[$value])) {
			return $DATALIST_VALUE_CACHE[$value];
		}
	}

	return null;
}

function hj_seo_unset_datalist($name) {
	
	global $CONFIG, $DATALIST_CACHE;

	$name = trim($name);

	$name = sanitise_string($name);
	if (isset($DATALIST_CACHE[$name])) {
		unset($DATALIST_CACHE[$name]);
	}

	// If memcache is available then invalidate the cached copy
	static $datalist_memcache;
	if ((!$datalist_memcache) && (is_memcache_available())) {
		$datalist_memcache = new ElggMemcache('datalist_memcache');
	}

	if ($datalist_memcache) {
		$datalist_memcache->delete($name);
	}

	$dbprefix = elgg_get_config('dbprefix');

	$result = delete_data("DELETE FROM {$dbprefix}datalists WHERE name = '$name'");

	return true;
}
function hj_seo_is_url_sef($url) {
	if (hj_seo_get_datalist($url)) {
		return true;
	}
	return false;
}