hypeSEO is part of the hypeJunction plugin bundle

This plugin is released under a GPL compatible license, as a courtesy of hypeJunction Club
Release of this plugin available at elgg.org might not always correspond to the latest stable release available at www.hypeJunction.com


PLUGIN DESCRIPTION
------------------
hypeSEO is a tool to help you rewrite Elgg URLs into a search engine friendly format

Main features include:
- Any URLs containing an entity GUID are automatically converted to GUID-entity-title format
- SEF URLs can be edited in the admin backend

IMPORTANT NOTES:
- DO NOT USE ON PRODUCTION SITES. THIS RELEASE IS FOR TESTING PURPOSES ONLY. YOU CAN CAUSE DAMAGE TO YOUR PRODUCTION SITE IF YOU DO SOMETHING WRONG
- This is not a rewriting tool, but a forwarding tool, which means it does not rewrite actual links present in your html dom. For as long as there are no appropriate hooks in Elgg to overwrite entity urls, this will stay this way
- The first segment of your URL can not containt file extentions, e.g.:
	YOU CAN USE:
	blog/215-my-blog-name
	215-blog-name
	blog/myblog-name

	YOU CAN NOT USE:
	215-blog-name.html
	215-blog-name.php

- All SEF URLs must be unique

For the SEF URLs to appear in your settings you need to manually click on all the links, or use a crawler that will do that for you.


REQUIREMENTS
------------
1) Elgg 1.8.3+
2) hypeFramework 1.8.5+

INTEGRATION / COMPATIBILITY
---------------------------


INSTALLATION
------------


UPGRADING FROM PREVIOUS VERSION
-------------------------------


USER GUIDE
----------


TODO
-----


WARNINGS / NOTES
----------------


BUG REPORTS
-----------
Bugs and feature requests can be submitted at:
http://hypeJunction.com/trac
