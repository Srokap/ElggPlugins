<?php

/* hypeSEO
 *
 * @package hypeJunction
 * @subpackage hypeSEO
 *
 * @author Ismayil Khayredinov <ismayil.khayredinov@gmail.com>
 * @copyright Copyrigh (c) 2011, Ismayil Khayredinov
 */

elgg_register_event_handler('init', 'system', 'hj_seo_init');

/**
 * Initialize hypeSEO
 */
function hj_seo_init() {

	$plugin = 'hypeSEO';

	if (!elgg_is_active_plugin('hypeFramework')) {
		register_error(elgg_echo('hj:framework:disabled', array($plugin, $plugin)));
		disable_plugin($plugin);
	}

	$shortcuts = hj_framework_path_shortcuts($plugin);

	elgg_register_plugin_hook_handler('route', 'all', 'hj_seo_reroute');

	elgg_register_admin_menu_item('administer', 'seo', 'hj', 500);

	elgg_register_library('hj:seo:base', $shortcuts['lib'] . 'seo/base.php');
	elgg_load_library('hj:seo:base');

	elgg_register_action('hj/seo/sef_settings', $shortcuts['actions'] . 'hj/seo/sef_settings.php', 'admin');

	$css = elgg_get_simplecache_url('css', 'hj/seo/base');
	elgg_register_css('hj.seo.base', $css);
}

/**
 * We will grab the existing $page and forward to sef_page_handler, which will call_user_func the original handler
 */
function hj_seo_reroute($hook, $type, $return, $params) {

	$segments = elgg_extract('segments', $return, '');
	$handler = elgg_extract('handler', $return);

	// We don't need sef URLs for the following handlers
	$handler_exceptions = array(
		'action',
		'cache',
		'services',
		'export',
		'mt',
		'xml-rpc',
		'rewrite',
		'tag',
		'pg',
		'admin',
		'cron',
		'js',
		'css',
		'ajax',
		'livesearch',
		'activity',
		'setting',
		'friends',
		'friendsof',
		'register',
		'forgotpassword',
		'resetpassword',
		'login',
		'avatar',
		'profile',
		'collections',
		'seo'
	);

	if (in_array($handler, $handler_exceptions)) {
		return $return;
	}

	// This is our current url
	if (sizeof($segments) > 0) {
		$segments_url = '/' . implode('/', $segments);
	}
	$full_url = "{$handler}{$segments_url}";

	// Now, let's see if our current url is sef and render the page if so
	if ($nonsef_page = hj_seo_get_datalist($full_url)) {

		$segments = str_replace('sef:', '', $nonsef_page);
		$segments = explode('/', $segments);

		$handler = $segments[0];
		array_shift($segments);

		$params = array(
			'segments' => $segments,
			'handler' => $handler
		);

		return $params; // Let's pass the old params to the original handler
	}

	// It looks like our url is not sef
	// We have to see if we have previously sef-coded it and forward
	// Or if it hasn't been coded, we want to make a sef url and forward
	$nonsef_dl_name = "sef:{$full_url}";

	// Datalist Table name can only be 255 characters long
	// @todo: let's see if this causing any problems with super long urls
	$nonsef_dl_name = (strlen($nonsef_dl_name) > 255) ? substr($nonsef_dl_name, 0, 255) : $nonsef_dl_name;

	$sef_url = datalist_get($nonsef_dl_name);

	$query = $_REQUEST;
	unset($query['handler']);
	unset($query['page']);

	$query = http_build_query($query);
	if ($query) {
		$query = "?$query";
	}
	if ($sef_url) {
		forward($sef_url . $query); // The user was trying to view a non-sef URL, so forwarding to the sef URL
	} 

	$requires_sef = false;
	foreach ($segments as $segment) {
		$prepend_guid = elgg_get_plugin_setting('prepend_guid', 'hypeSEO');
		$all_segments = elgg_get_plugin_setting('all_segments', 'hypeSEO');

		if (is_numeric($segment)) {
			$entity = get_entity((int) $segment);
			if (elgg_instanceof($entity) ) {
				if (!$title = $entity->title) {
					$title = $entity->name;
				}
				$friendly = elgg_get_friendly_title($title);
				if ($segment !== $friendly && !in_array($segment, $new_page)) {
					if ($prepend_guid !== 'off') {
						$new_page[] = "$entity->guid-$friendly";
					} else {
						$new_page[] = "$friendly";
					}
					$requires_sef = true;
				}
			}
		} elseif (!in_array($segment, $new_page) && $all_segments !== 'off') { // make sure we do not have duplicating segments
			$new_page[] = $segment;
		}
	}

	if (!is_array($new_page) || !$requires_sef) {
		return $return;  // Looks like no point in sef-coding this url, let's go back to original handler
	}

	array_unshift($new_page, $handler);
	$sef_url = implode('/', $new_page);
	//$sef_url .= '.html';
	
	datalist_set($nonsef_dl_name, $sef_url);

	forward($sef_url . $query);
}