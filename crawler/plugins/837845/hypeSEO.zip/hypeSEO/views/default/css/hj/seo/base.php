.hj-seo-admin {
	width:100%;
	font-size:10px;
}

.hj-seo-admin > tr td {
	padding:5px;
	width:45%;
}

.hj-seo-admin tr:nth-child(odd) {
	background: #f4f4f4;
}

tr.hj-seo-admin-header > td {
	text-align:center;
	font-weight:bold;
	border-bottom:2px solid #666;
}

.hj-seo-admin-non-sef {
	padding:7px;
}