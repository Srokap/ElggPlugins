<?php

echo elgg_view_form('hj/seo/sef_settings');