<?php

elgg_load_css('hj.seo.base');

$dbprefix = elgg_get_config('dbprefix');
$sef_urls = get_data("SELECT * from {$dbprefix}datalists WHERE name LIKE 'sef:%'");

if ($sef_urls) {
	$form_body = '<table class="hj-seo-admin">';
	$form_body .= <<<HTML
	<tr class="hj-seo-admin-header">
		<td>
			Original Non-SEF URL
		</td>
		<td>
			Optimized SEF URL
		</td>
	</tr>
HTML;

	foreach ($sef_urls as $key => $row) {
		$non_sef_url = str_replace('sef:', '', $row->name);
		$non_sef_input = elgg_view('input/hidden', array(
			'name' => "non_sef[$key]",
			'value' => $non_sef_url
		));
		$sef_url = $row->value;
		$sef_input = elgg_view('input/text', array(
			'name' => "sef[$key]",
			'value' => $sef_url
		));

		$form_body .= <<<HTML
			<tr>
				<td>
					<div class="hj-seo-admin-non-sef">
						$non_sef_url
					</div>
					$non_sef_input
				</td>
				<td>
					$sef_input
				</td>
			</tr>
HTML;

	}
}

$form_body .= '</table>';

$form_body .= elgg_view('input/submit', array('value' => 'Submit'));

echo $form_body;