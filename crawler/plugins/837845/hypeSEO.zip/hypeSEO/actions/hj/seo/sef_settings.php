<?php

$non_sef = get_input('non_sef');
$sef = get_input('sef', array());

if (!empty($sef)) {

	foreach ($sef as $key => $sef_url) {
		global $$DATALIST_CACHE;
		$non_sef_dl = "sef:{$non_sef[$key]}";
		$sef_dl = $sef_url;
		unset($DATALIST_CACHE[$non_sef_dl]);
		if (!empty($sef_dl)) {
			datalist_set($non_sef_dl, $sef_dl);
		} else {
			hj_seo_unset_datalist($non_sef_dl);
		}
	}

}

system_message(elgg_echo('hj:seo:sef_settings:complete'));

forward(REFERER);
