<?php

$english = array(
    'admin:hj:seo' => 'SEO',
	'hj:seo:sef_settings:complete' => 'SEF URLs successfully updated',
	
);

add_translation("en", $english);
?>