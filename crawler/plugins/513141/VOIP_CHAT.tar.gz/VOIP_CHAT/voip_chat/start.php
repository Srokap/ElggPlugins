<?php
		function voip_chat_init() 
		{
		global $CONFIG;
		add_menu(elgg_echo('Voip'), $CONFIG->wwwroot . "mod/voip_chat/");
		}

	register_elgg_event_handler('init','system','voip_chat_init');

?>
