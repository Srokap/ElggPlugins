<div class="contentWrapper">
<div align="center">

<?php
echo "<iframe src='../../customer/?Log-in=".$_SESSION['user']->username."' width='900' height='400'></iframe>";
?>


</div>
</div>
