<style type="text/css">
	hr.pme-hr		     { border: 0px solid; padding: 0px; margin: 0px; border-top-width: 1px; height: 1px; }
	table.pme-main 	     { border: #004d9c 1px solid; border-collapse: collapse; border-spacing: 0px; width: 100%; }
	table.pme-navigation { border: #004d9c 0px solid; border-collapse: collapse; border-spacing: 0px; width: 100%; }
	td.pme-navigation-0, td.pme-navigation-1 { white-space: nowrap; }
	th.pme-header	     { border: #004d9c 1px solid; padding: 4px; background: #add8e6; }
	td.pme-key-0, td.pme-value-0, td.pme-help-0, td.pme-navigation-0, td.pme-cell-0,
	td.pme-key-1, td.pme-value-1, td.pme-help-0, td.pme-navigation-1, td.pme-cell-1,
	td.pme-sortinfo, td.pme-filter { border: #004d9c 1px solid; padding: 3px; }
	td.pme-buttons { text-align: left;   }
	td.pme-message { text-align: center; }
	td.pme-stats   { text-align: right;  }
</style>
<h3> Group Talk</h3>
<?php

$accountcode = $_SESSION['cardnumber'];
$idcard = $_SESSION['idcard'];
 

// DB Access 
include ("includes/config.php");
$opts['hn'] = $cfg['db']['host'] ;
$opts['un'] = $cfg['db']['user'] ;
$opts['pw'] = $cfg['db']['pwd'] ;
$opts['db'] = $cfg['db']['base'] ;
 
$callback = $_POST['callback'];
if ($callback == 1) 
{

	$chandle = mysql_pconnect($opts['hn'], $opts['un'], $opts['pw']) 
	or die("Connection Failure to Database");
	$error =false;
	mysql_select_db($opts['db'], $chandle) or die ("Database not found.");

	$QUERY = "SELECT  username, credit,  activated FROM cc_card WHERE id = ".intval($idcard); 
	$q = mysql_query($QUERY);
	 $r=mysql_fetch_assoc($q);
	 if ($r) {
		$card_credit  = $r['credit'];
		$card_activated = $r['activated'];
		}
	mysql_free_result($q);
	if (($card_credit > 0) && ($card_activated =='t') )
	{
	$res = 1;
	}
	else
	{
		$error_msg ="Sorry,you don't have enough credit or your account is blocked,you cannot initial this function.";
		$res =  0 ;
	}

	$calling0 = $_REQUEST['calling0'];
	$calling1 = $_REQUEST['calling1'];
	$calling2 = $_REQUEST['calling2'];
	$calling3 = $_REQUEST['calling3'];
	$calling4 = $_REQUEST['calling4'];
	$calling5 = $_REQUEST['calling5'];

	$exten = $calling0 ;

	$context ="grouptalk_legb";
	$id_server_group = 1;
	$priority=1;
	$timeout = 90000;
	$application='';
	$callerid ="64288890099";
	$account = $accountcode; 
	
	$uniqueid 	=  MDP_NUMERIC(5).'-'.MDP_STRING(7);
	$status = 'PENDING';
	$server_ip = 'localhost';
	$num_attempt = 0;
	$variable = "CALLED=$exten|CALLING=$exten|CBID=$uniqueid|LEG=".$A2B->cardnumber;
	
 if ($res && (strlen($calling0) > 0)) {
	$channel = "Local/".$calling0."@grouptalk_lega/n";

	$uniqueid 	=  MDP_NUMERIC(5).'-'.MDP_STRING(7);
	$QUERY = " INSERT INTO cc_callback_spool (uniqueid, status, server_ip, num_attempt, channel, exten, context, priority, variable, id_server_group, callback_time, account, callerid, timeout ) VALUES ('$uniqueid', '$status', '$server_ip', '$num_attempt', '$channel', '$exten', '$context', '$priority', '$variable', '$id_server_group',  now(), '$account', '$callerid', '60000')";
	$res =  mysql_query($QUERY);
 	}
	
	 if ($res && (strlen($calling1) > 0)) {
	$channel = "Local/".$calling1."@grouptalk_lega/n";

	$uniqueid 	=  MDP_NUMERIC(5).'-'.MDP_STRING(7);
	$QUERY = " INSERT INTO cc_callback_spool (uniqueid, status, server_ip, num_attempt, channel, exten, context, priority, variable, id_server_group, callback_time, account, callerid, timeout ) VALUES ('$uniqueid', '$status', '$server_ip', '$num_attempt', '$channel', '$exten', '$context', '$priority', '$variable', '$id_server_group',  now(), '$account', '$callerid', '60000')";
	$res = mysql_query($QUERY);
	}
	
	 if ($res && (strlen($calling2) > 0)) {
	$channel = "Local/".$calling2."@grouptalk_lega/n";

	$uniqueid 	=  MDP_NUMERIC(5).'-'.MDP_STRING(7);
	$QUERY = " INSERT INTO cc_callback_spool (uniqueid, status, server_ip, num_attempt, channel, exten, context, priority, variable, id_server_group, callback_time, account, callerid, timeout ) VALUES ('$uniqueid', '$status', '$server_ip', '$num_attempt', '$channel', '$exten', '$context', '$priority', '$variable', '$id_server_group',  now(), '$account', '$callerid', '60000')";
	$res = mysql_query($QUERY);
	
	}
	
	 if ($res && (strlen($calling3) > 0)) {
	$channel = "Local/".$calling3."@grouptalk_lega/n";

	$uniqueid 	=  MDP_NUMERIC(5).'-'.MDP_STRING(7);
	$QUERY = " INSERT INTO cc_callback_spool (uniqueid, status, server_ip, num_attempt, channel, exten, context, priority, variable, id_server_group, callback_time, account, callerid, timeout ) VALUES ('$uniqueid', '$status', '$server_ip', '$num_attempt', '$channel', '$exten', '$context', '$priority', '$variable', '$id_server_group',  now(), '$account', '$callerid', '60000')";
	$res = mysql_query($QUERY);
	}
	
		 if ($res && (strlen($calling4) > 0)) {
	$channel = "Local/".$calling4."@grouptalk_lega/n";

	$uniqueid 	=  MDP_NUMERIC(5).'-'.MDP_STRING(7);
	$QUERY = " INSERT INTO cc_callback_spool (uniqueid, status, server_ip, num_attempt, channel, exten, context, priority, variable, id_server_group, callback_time, account, callerid, timeout ) VALUES ('$uniqueid', '$status', '$server_ip', '$num_attempt', '$channel', '$exten', '$context', '$priority', '$variable', '$id_server_group',  now(), '$account', '$callerid', '60000')";
	$res = mysql_query($QUERY);
	}
	
	 if ($res && (strlen($calling5) > 0)) {
	$channel = "Local/".$calling5."@grouptalk_lega/n";

	$uniqueid 	=  MDP_NUMERIC(5).'-'.MDP_STRING(7);
	$QUERY = " INSERT INTO cc_callback_spool (uniqueid, status, server_ip, num_attempt, channel, exten, context, priority, variable, id_server_group, callback_time, account, callerid, timeout ) VALUES ('$uniqueid', '$status', '$server_ip', '$num_attempt', '$channel', '$exten', '$context', '$priority', '$variable', '$id_server_group',  now(), '$account', '$callerid', '60000')";
	$res = mysql_query($QUERY);
	}
		
	if ($res) {
		$error_msg ='';
		$info_msg ="Group talk initiated, system will call these numbers immediately,once connected,they will be in group talk mode";
	}else
		{
		
		$info_msg ="";
		}

 
 
}
?>
  	  
	<p> <font   color='red'> 	<?php echo $error_msg ?>  </font><font color='green'><?php echo $info_msg;?></font>
	</p>
	 <ul>
 	 <li> <?php echo gettext("Invite users to Group Talk.  You can input PSTN Numbers or SIP Numbers to call!");?></li>
 	 <li><?php echo gettext("If you call INTERNATIONAL   PSTN number, please use 0011 + Country Code + Number");?></li>
	 </ul>
	 	<form name="theForm" action="index.php?option=grouptalk" method="POST" >
 	   <table  >
	
		<INPUT type="hidden" name="callback" value="1">
		<tr >
		<td><?php echo gettext("My PhoneNumber");?> :</td>
		<td><input class="form_input_text" name="calling0" value="<?php echo $calling0; ?>" size="30" maxlength="40" ></td>
		</tr>
		<tr >	 
			<td> <?php echo gettext("Attendee 1's Phone Number");?> : </td>
			<td> <input class="form_input_text" name="calling1" value="<?php echo $calling1; ?>" size="30" maxlength="40"></td>
		</tr>
		<tr >	 
			<td> <?php echo gettext("Attendee 2's Phone Number");?> : </td>
			<td><input class="form_input_text" name="calling2" value="<?php echo $calling2; ?>" size="30" maxlength="40"></td>
		</tr>
		<tr>
			<td><?php echo gettext("Attendee 3's Phone Number");?> :</td>
			<td><input class="form_input_text" name="calling3" value="<?php echo $calling3; ?>" size="30" maxlength="40"></td>
		</tr>
		<tr>	 
			<td><?php echo gettext("Attendee 4's Phone Number");?> :</td>
			<td><input class="form_input_text" name="calling4" value="<?php echo $calling4; ?>" size="30" maxlength="40"></td>
		</tr>
		<tr>	 
			<td><?php echo gettext("Attendee 5's Phone Number");?> :</td>
			<td><input class="form_input_text" name="calling5" value="<?php echo $calling5; ?>" size="30" maxlength="40"></td>
		</tr>
		</table>	 
		<input class="form_input_button"  value="[ <?php echo gettext("Click here to Place Call");?> ]" type="submit"> 
			  
		</form>
    
