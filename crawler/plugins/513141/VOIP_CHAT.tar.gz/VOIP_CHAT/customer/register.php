<?php

require_once ("includes/config.php");
require_once ("includes/mysql.php");
require_once ("includes/sessions.php");
require_once ("includes/forms.php");
global $cfg;
?>


<html>
<head>
<title><? echo $cfg['main']['sitename'];?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--

a:link {  color: #FFFFFF; text-decoration: none}

a:visited {  text-decoration: none; color: #FFCC66}

a:hover {  color: #99CCFF; text-decoration: underline}
body {  font-family: "Arial", "Helvetica", "sans-serif"}

-->
</style>
</head>

<body bgcolor="#FFFFFF" link="#FFFFFF">

<table background="image/top.gif" width="700" border="0" cellspacing="0" cellpadding="0" height="75" align="center" > 
<tr background="image/top.gif"> <td colspan="2"><FONT FACE="Tahoma" SIZE="6">
  <? echo $cfg['main']['sitename'];?></FONT><pre><FONT FACE="Tahoma"><?php echo $cfg['web']['urlbase']; ?></FONT></pre></td></tr> 
</table><table width="700" border="0" cellspacing="0" cellpadding="0" height="20" align="center"> 
<tr bgcolor="#000000"> <td BGCOLOR="#336666"> <div align="center"> 
<font color="#FFFFFF" face="Tahoma">|</font><font face="Tahoma"> <a href="/dialer/company/">Home</a> <font color="#FFFFFF"> 
<font color="#FFFFFF" face="Tahoma">|</font><font face="Tahoma"> <a href="#">Help</a> <font color="#FFFFFF">
<font color="#FFFFFF" face="Tahoma">|</font><font face="Tahoma"> <a href="#">Contact Us</a> <font color="#FFFFFF">|

</font></font></div></td></tr> </table><table width="700" border="0" cellspacing="0" cellpadding="0" height="13" background="image/top1.gif" align="center"> 
<tr> <td><FONT FACE="Tahoma"><img src="image/pixel.gif" width="1" height="1"></FONT></td></tr> 
</table>







</font></p><p align="right"><FONT FACE="Tahoma"> </FONT></p>
</table><FONT FACE="Tahoma"><br> </FONT><table width="700" border="0" cellspacing="0" cellpadding="0" align="center"> 
<tr> <td align=center>

  <h2>Create a New Account <hr><br>

<?
  session_start();
  if($_GET['md5']!=NULL){
    $q=mysql_query("SELECT * FROM Company WHERE Hash=" . qt($_GET['md5']));
    $r=mysql_fetch_assoc($q);
    if($r['Hash']!=NULL){
      $q2=mysql_query("UPDATE Company SET Validated=1 WHERE Hash=" . qt($_GET['md5']));
      echo "<b> Thanks,please wait for administrator review and activate this account</b><hr>";
    } else {
      echo "<b> Invalid Link</b><hr>";
    }
    exit(0);
}
  


  //    idUsers, Firstname, Lastname, Address, City, State, ZIP, Login, Pass
  // Fields Name / Description
$Form['Fields']['Name']="First Name";
$Form['Fields']['Address']="Address";
$Form['Fields']['City']="City";
$Form['Fields']['State']="State";
$Form['Fields']['ZIP']="ZIP";
$Form['Fields']['Phone']="Phone Number";
$Form['Fields']['Login']="User Name";
$Form['Fields']['Pass']="Password";
$Form['Fields']['EMail']="E-mail";
$Form['Fields']['security_code']="<img src='includes/captcha.php'/>";

// Field Types
$Form['Types']['Pass']="password";
// Hidden Fields
$Form['HiddenFields']['option']="details";

if ($_GET['Send']=='Save'){
  if(($_SESSION['security_code'] == $_GET['security_code']) && (!empty($_SESSION['security_code'])) ) {
    unset($_SESSION['security_code']);
  } else {
    echo  "Please enter the security code<br>";
    return;
  }
    foreach($Form['Fields'] as $key=> $value){
      if($_GET[$key]==NULL){
	echo "<br><b>You have to complete all fields.</b><br>";
	return;
      }
	   if ($key =='ZIP')
	  {
		if (strlen($_GET[$key])!= 5) {
		echo "<br><b> The Zip Code must be 5 digit</b><br>";
		return ;
		}
	  }
    }

  $hash=md5(rand(1111111111,99999999999));
  $q="INSERT INTO Company (Name, Address, City, State, ZIP, Phone, EMail, Login, Pass, Hash) VALUES (" . qt($_GET['Name']) . ", " . qt($_GET['Address']) . ", " . qt($_GET['City']) . ", " . qt($_GET['State']) . ", " . qt($_GET['ZIP']) . ", " . qt($_GET['Phone']) . ", " . qt($_GET['EMail']) . ", " . qt($_GET['Login']) . ", " . qt($_GET['Pass']) .  ", '" . $hash . "')";
  
  $a=mysql_query($q);
  $last=mysql_affected_rows();
  if($last==0 or $last==-1){
      echo "<b> There was an error creating your account. Please check your information.</b><br>";
      exit(0);
  }
  echo "<b> Account Created. You will receive a confirmation e-mail.</b><br>";
  $toaddr=$_GET['EMail'];
  $HTML="<br><b>Thanks for Registering</b><br><hr><br>Please click <a href=" . $cfg['web']['urlbase'] . "/company/register.php?md5=$hash> here </a> to confirm your account<br><br>Regards, <br>" . $cfg['main']['sitename'];
    $subject = "Account validation";
    $headers = "Content-Type: text/html; charset=\"windows-1251\"\r\n";
    $headers .= "MIME-Version: 1.0 ";
    $headers .= 'To: ' . $toaddr . "\r\n";
    $headers .= 'From:' .  $cfg['main']['sitename'] . '  <info@gnualmafuerte.com.ar>';
    $HTML_ARRAY=explode("\n",$HTML);
    $HTML = implode("\r\n", $HTML_ARRAY);
    $message=$HTML;
    $error=mail($toaddr, $subject, $message, $headers, "-f" . $toaddr);
}else {
  form($Form, $r);
}

																																	     
?>


<br>
<br>


<div align="left"></div><DIV ALIGN="CENTER"><FONT SIZE="2" FACE="Tahoma">Copyright 
2007 <? echo  $cfg['main']['sitename'];?>. All Rights Reserved</FONT></DIV><TABLE WIDTH="700" BORDER="0" CELLSPACING="0" CELLPADDING="0" HEIGHT="20" ALIGN="center"> 
<TR BGCOLOR="#000000"> <TD BGCOLOR="#336666">&nbsp;</TD></TR> </TABLE></td></tr> 
</table><FONT FACE="Tahoma"></FONT> 



</body>
</html>

			<center>&nbsp;</center><br><br>