<style type="text/css">
	hr.pme-hr		     { border: 0px solid; padding: 0px; margin: 0px; border-top-width: 1px; height: 1px; }
	table.pme-main 	     { border: #004d9c 1px solid; border-collapse: collapse; border-spacing: 0px; width: 100%; }
	table.pme-navigation { border: #004d9c 0px solid; border-collapse: collapse; border-spacing: 0px; width: 100%; }
	td.pme-navigation-0, td.pme-navigation-1 { white-space: nowrap; }
	th.pme-header	     { border: #004d9c 1px solid; padding: 4px; background: #add8e6; }
	td.pme-key-0, td.pme-value-0, td.pme-help-0, td.pme-navigation-0, td.pme-cell-0,
	td.pme-key-1, td.pme-value-1, td.pme-help-0, td.pme-navigation-1, td.pme-cell-1,
	td.pme-sortinfo, td.pme-filter { border: #004d9c 1px solid; padding: 3px; }
	td.pme-buttons { text-align: left;   }
	td.pme-message { text-align: center; }
	td.pme-stats   { text-align: right;  }
</style>
<h3> Call Your Contact</h3>
<?php

$accountcode = $_SESSION['cardnumber'];
$idcard = $_SESSION['idcard'];
 

// DB Access 
include ("includes/config.php");
$opts['hn'] = $cfg['db']['host'] ;
$opts['un'] = $cfg['db']['user'] ;
$opts['pw'] = $cfg['db']['pwd'] ;
$opts['db'] = $cfg['db']['base'] ;
 
if ( strlen($_REQUEST['contactphone']) > 0 ) $calling = $_REQUEST['contactphone'] ;

$callback = $_POST['callback'];
if ($callback == 1) 
{
	$calling = $_POST['calling'];
	$called = $_POST['called'];

	$chandle = mysql_pconnect($opts['hn'], $opts['un'], $opts['pw']) 
	or die("Connection Failure to Database");
	$error =false;
	mysql_select_db($opts['db'], $chandle) or die ("Database not found.");

	$QUERY = "SELECT  username, credit,  activated FROM cc_card WHERE id = ".intval($idcard); 
	$q = mysql_query($QUERY);
	 $r=mysql_fetch_assoc($q);
	 if ($r) {
		$card_credit  = $r['credit'];
		$card_activated = $r['activated'];
		}
	mysql_free_result($q);
	if (($card_credit > 0) && ($card_activated =='t') )
	{
	$res = 1;
	}
	else
	{
		$error_msg ="Sorry,you don't have enough credit or your account is blocked,you cannot initial this function.";
		$res =  0 ;

	}
 	$exten = $calling;
	$context = $A2B -> config["callback"]['context_callback'];
	$id_server_group = 1;
	$priority=1;
	$timeout = 60000 ;
	$application='';
	$callerid =  "64288890099";
	$account =  $accountcode ;
	
	$uniqueid 	=  MDP_NUMERIC(5).'-'.MDP_STRING(7);
	$status = 'PENDING';
	$server_ip = 'localhost';
	$num_attempt = 0;
	$variable = "CALLED=$called|CALLING=$calling|CBID=$uniqueid|LEG=".$accountcode;
						
 	
 if ($res && strlen($called)>4 && strlen($calling)>4 && is_numeric($called) && is_numeric($calling)) {
	$channel = "Local/".$called."@a2billing-callback/n";

	$uniqueid 	=  MDP_NUMERIC(5).'-'.MDP_STRING(7);
	$QUERY = " INSERT INTO cc_callback_spool (uniqueid, status, server_ip, num_attempt, channel, exten, context, priority, variable, id_server_group, callback_time, account, callerid, timeout ) VALUES ('$uniqueid', '$status', '$server_ip', '$num_attempt', '$channel', '$exten', '$context', '$priority', '$variable', '$id_server_group',  now(), '$account', '$callerid', '60000')";
	$res =  mysql_query($QUERY);
 	}
	
 
 		
	if ($res) {
		$error_msg ='';
		$info_msg ="call is   initiated, system will call you  immediately,once connected,system will help you call your contact,and your contact phone will ring";
	}else
		{
		
		$info_msg ="";
		}

 
 
}
?>
  	  
	<p> <font   color='red'> 	<?php echo $error_msg ?>  </font><font color='green'><?php echo $info_msg;?></font>
	</p>
	 <ul>
 	 <li> <?php echo gettext("Call your contact.  You can input PSTN Numbers or SIP Numbers to call!");?></li>
 	 <li><?php echo gettext("If you call INTERNATIONAL   PSTN number, please use 0011 + Country Code + Number");?></li>
	 </ul>
	 	<form name="theForm" action="index.php?option=callback" method="POST" >
 	   <table  >
	
		<INPUT type="hidden" name="callback" value="1">
		<tr >
		<td><?php echo gettext("My PhoneNumber");?> :</td>
		<td><input class="form_input_text" name="called" value="<?php echo $called; ?>" size="30" maxlength="40" ></td>
		</tr>
		<tr >	 
			<td> <?php echo gettext("Contact 's Phone Number");?> : </td>
			<td> <input class="form_input_text" name="calling" value="<?php echo $calling; ?>" size="30" maxlength="40"></td>
		</tr>
	 	</table>	 
		<input class="form_input_button"  value="[ <?php echo gettext("Click here to Place Call");?> ]" type="submit"> 
			  
		</form>
    
