###  Installation instructions  ###

1) Edit config.php accordingly
2) Upload to your server
3) Use IE/Firefox and go to script location
4) Import CSV files to MySQL!


Here are the terms of use.  Be sensible and you won't have to worry!

###  Terms of use  ###

- From hereon in, "The Script" refers to the PHP CSV Importer
- From hereon in, "The Author" refers to myself, Matthew Lindley, sole author of the The Script.
- From hereon in, "The Website" refers to http://www.phpcsvimporter.co.uk

1) You are NOT allowed to redistribute The Script, either in part or whole, for any direct or indirect financial gain without written consent directly from The Author.
2) You are NOT allowed to edit any part of The Script in any such way that it deceives others from thinking another other than The Author has written it.
3) You are NOT allowed to edit any part of The Script in any such way that it prohibits the user from obtaining information such as:
	i) The Author's name.
	ii) The website address as supplied by The Author.
	iii) The version of The Script.
4) You ARE allowed to redistribute The Script providing that you give full credit to The Author.
5) You ARE allowed to edit The Script in the event that it is unable to complete its designed function, known as "bug-fixing".
6) You ARE allowed to alter its superficial appearance without breaching rules 2 or 3 and also conforming to the following:
	i) At all times must the user be able to see The Author's Name with direct reference to being the author of The Script.
	ii) At all times must the user be able to see and access (via a direct link) The Website.
	iii) All all times must the user be able to see the version of the script.
7) Any directly or indirectly redistributed version of The Script must contain a wholely unedited version of this file, "readme.en.txt".
8) No liability will be accepted by The Author for any loss and/or damaged caused at any time during the installation, use or misuse of this script.
9) No liability will be accepted by The Author for any unauthorised access gained directly or indirectly via the installation, use or misuse of this script.
10) In all cases full accreditation should be given to The Author.
11) In all cases where there are any issues not covered by any of the above, you should contact The Author via The Website.