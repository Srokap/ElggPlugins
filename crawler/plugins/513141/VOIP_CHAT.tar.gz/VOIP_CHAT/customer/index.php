<?php
require_once ("includes/config.php");
require_once ("includes/mysql.php");
require_once ("includes/sessions.php");
require_once ("includes/forms.php");
global $cfg;
?>


<html>
<head>
<script language="JavaScript" src="includes/calendar.js"></script>
<title><? echo $cfg['main']['sitename'];?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
 <link href="style.css" rel="stylesheet" type="text/css">
  <style type="text/css">
ul.makeMenu, ul.makeMenu ul {
  width: 200px;                 /* sets the size of the menu blocks */
  border: 1px solid #000;      /* puts a black border around the menu blocks */
  background-color: 216db0;      /* makes the menu blocks light blue - a bg-color MUST be included for IE to work properly! */
  padding-left: 0px;           /* stops the usual indent from ul */
  cursor: default;             /* gives an arrow cursor */
  margin-left: 0px;            /* Opera 7 final's margin and margin-box model cause problems */
}
ul.makeMenu li {
  list-style-type: none;       /* removes the bullet points */
  margin: 0px;                 /* Opera 7 puts large spacings between li elements */
  position: relative;          /* makes the menu blocks be positioned relative to their parent menu item
                                  the lack of offset makes these appear normal, but it will make a difference
                                  to the absolutely positioned child blocks */
  color: #fff;                 /* sets the default font colour to white */
}
ul.makeMenu li > ul {          /* using the > selector prevents many lesser browsers (and IE - see below) hiding child ULs */
  display: none;               /* hides child menu blocks - one of the most important declarations */
  position: absolute;          /* make child blocks hover without leaving space for them */
  top: 2px;                    /* position slightly lower than the parent menu item */
  left: 190px;                  /* this must not be more than the width of the parent block, or the mouse will
                                  have to move off the element to move between blocks, and the menu will close */
}
ul.makeMenu li:hover, ul.makeMenu li.CSStoHighlight {
  background-color: #ffa;      /* gives the active menu items a yellow background */
  color: #000;                 /* makes the active menu item text black */ 
}
ul.makeMenu ul.CSStoShow {     /* must not be combined with the next rule or IE gets confused */
  display: block;              /* specially to go with the className changes in the behaviour file */
}
ul.makeMenu li:hover > ul {    /* one of the most important declarations - the browser must detect hovering over arbitrary elements
                                  the > targets only the child ul, not any child uls of that child ul */
  display: block;              /* makes the child block visible - one of the most important declarations */
}
/* and some link styles */
ul.makeMenu li a { color: #fff; display: block; width: 100%; text-decoration: underline; }
ul.makeMenu li a:hover, ul.makeMenu li a.CSStoHighLink { color: #000; }
ul.makeMenu li:hover > a { color: #000; } /* supports links in branch headings - should not be display: block; */
body {
	background-color: #D7D7D7;
}
  .style1 {color: #216db0}
  </style>
<!--[if gt IE 5.0]><![if lt IE 7]>
<style type="text/css">
/* that IE 5+ conditional comment makes this only visible in IE 5+ */
ul.makeMenu li {  /* the behaviour to mimic the li:hover rules in IE 5+ */
  behavior: url( IEmen.htc );
}
ul.makeMenu ul {  /* copy of above declaration without the > selector, except left position is wrong */
  display: none; position: absolute; top: 2px; left: 190 px;
}
</style>
<![endif]><![endif]-->
</head>

<body  >

<table bgcolor="#0099cc" width="1000" border="0" cellspacing="0" cellpadding="0" height="74" align="center" > 
<tr >  <td  align="center" class="titletext"   background="images/tx.jpg">
<center>
</center>
   </td></tr> 
</table><table width="1000" border="0" cellspacing="0" cellpadding="0" height="20" align="center"> 
<tr  > <td  > <div align="center"> 
  | <a href="#" class="style1">Home</a>  
 |  <a href="#" class="style1">Help</a>  
 |  <a href="#" class="style1">Contact Us</a>  
 |  <a href="?option=logout" class="style1">Log Out</a>   |
 </div></td></tr> </table><table width="766" border="0" cellspacing="0" cellpadding="0" height="13"   align="center"> 
<tr> <td> <img src="images/pixel.gif" width="1" height="1"> </td></tr> 
</table>

<?php 
session();
?>

<br> 
<table width="1000" border="1" cellspacing="1" cellpadding="1" align="center"> 
<tr> <td valign="top" width="200"> <table width="188"   border="0" cellspacing="1" cellpadding="1"> 
<tr> <td   height="28" align="center" >   <strong> VaS SUBSCRIBER MENU</strong> 
</tr>
 <tr> 
  <td   height="76" > 
  <!-- Menu -->
     <ul class="makeMenu">
  <li> VaS SUBSCRIBER DETAILS
    <ul>    
      <li><a href="?option=details">My  VaS Account Information</a></li>
	   <li><a href="?option=friends">My  VaS SIP Number</a></li>
	   <li><a href="?option=did">My  VaS D.I.D. Numbers</a></li>
    </ul>
  </li>
 <li> VaS ACCOUNT RECHARGE
    <ul>
       <li><a href="?option=vouchcust">Recharge Me</a></li>
    </ul>
  </li>
   <li> VaS CALL RATES  
    <ul>
	 	<li><a href="?option=buyrate"> VaS Calling Rates</a></li>
     </ul>
    </li>
  <li> VaS EXTRA SERVICES
	 <ul>
	  <li><a href="?option=speeddial">My  VaS Speed Dial</a></li>
	   <li><a href="?option=privacy">My  VaS Privacy Settings</a></li>
		<li><a href="?option=findme">My  VaS Find Me Feature</a></li>
		<li><a href="?option=contact">My  VaS Contacts List</a></li>
 		<li><a href="?option=grouptalk">My  VaS Group Talk</a></li>
 		<li><a href="?option=wakeup">My  VaS Wakeup Call</a></li>
     </ul>
  </li>
    <li>Calendar 
	 <ul>
	  <li><a href="?option=calendar">My  VaS Calendar</a></li>
     </ul>
  </li>
  <li> VaS CALL ANALYSIS
    <ul>
      <li><a href="?option=history">My  VaS Call History</a></li>
    </ul>
  </li>
    <ul>
<li><a href="?option=logout">LOGOUT</a></li>
    <ul>
  <li>
</ul>


</td>
  </tr>

  </table>


 </td><td bgcolor="#FFFFFF" >
 <?php
 $option = $_REQUEST['option'];
 if  ($option !='')
 $_SESSION['adm_option']=$option ;
 
 switch($_SESSION['adm_option']){
 case "details":
 
   com_edit_details();
   break;
case "speeddial":
	require("speeddial.php");  
   break;
case "calendar":
 ?>
	 <iframe height="800" width="800"  src="phpcalendar/index.php">
    
 </iframe>
 <?php
   break;
case "wakeup":
	require("wakeupcall.php");  
   break;
  case "privacy":
	require("privacy.php");  
   break;
    case "grouptalk":
	require("grouptalk.php");  
   break;
  case "findme":
	require("findme.php");  
   break;
  case "contact":
	require("contactlist.php");  
   break;
   case "callback":
	require("contactcall.php");  
   break;
 case "friends":
    com_friends();
   break;
    case "rate":
    com_rates();
   break;
case "buyrate";
	com_buyrates();
	break;
case "vouchcust":
	require("vouchcust.php");
	break;
  case "booth":
    com_booth();
     break;
case "did":
        require("didmgr.php");
        break;
 case "history":
    usr_calls();
    break;
case "dailyhis":
	daily_his();
	break;
case "monthlyhis":
	monthly_his();
	break;
case "importrate":
   echo "<iframe height=\"500\" width=\"700\"  src=\"importdata.php\">";
    import_rates();
 echo "</iframe>";
    break;

 case "logout":
    usr_logout();
    break;
	case "operator":
	com_operator();
	break;
 case "main":
    display_flash(); 
}
?>
  </td>
</tr>
 </table>
 <br>
 <table width="1000" border="0" cellspacing="0" cellpadding="0" align="center"> 
<tr> <td> <div align="left"></div>
<DIV ALIGN="CENTER">Copyright 
2009 voip telecom Limited. All Rights Reserved</DIV>
 </td>
</tr> 
</table> 



</body>
</html>

			<center>&nbsp;</center><br><br>
