<?php

/*

	File: config.php
	Purpose: Define the settings for your setup, such as MySQL

*/


################################################
//  Filesystem
################################################

//  Absolute path to index.php *WITH* trailing slash
define('_DIR_HOME', '/var/www/vhosts/default/htdocs/callshop/');



################################################
//  Language
################################################

//  Default language to be used.  Multi-lingual options are being added now for ease-of-use.
//  I'm sure some kind people will want to help in translating it at a later date.
define('_LANG_DEFAULT', 'en');



################################################
//  MySQL Settings
################################################


// DB Access 
include ("includes/config.php");
 

//  Settings used to connect to the database
define('_MYSQL_HOST',  $cfg['db']['host'] );
define('_MYSQL_USERNAME', $cfg['db']['user']);
define('_MYSQL_PASSWORD', $cfg['db']['pwd']);
define('_MYSQL_DB_NAME', $cfg['db']['base']);









#######################################################################################
#
##
###==>  WARNING!
##
#
#
#  If you alter anything below here, it's very likely things could stop working!
#  Only experienced PHP-ers should alter any of this - and they shouldn't need to.
#  It's here for reference only.
#
#######################################################################################






################################################
//  Filesystem
################################################

//  Directory where uploaded CSV files will be stored (with trailing slash)
define('_DIR_UPLOAD', 'csv_bin/');


//  Main includes dir
define('_DIR_INCLUDES', _DIR_HOME . 'includes/');

//  PHP directories
define('_DIR_PHP', _DIR_INCLUDES . 'php/');
	define('_DIR_PHP_ACTIONS', _DIR_PHP . 'actions/');
	define('_DIR_PHP_CLASSES', _DIR_PHP . 'classes/');
	define('_DIR_PHP_LANG', _DIR_PHP . 'lang/');

//  HTML directories
define('_DIR_HTML', _DIR_INCLUDES . 'html/');
	define('_DIR_HTML_TEMPLATES', _DIR_HTML . 'templates/');
	define('_DIR_HTML_THEMES', _DIR_HTML . 'themes/');

//  Other directories
define('_DIR_CSS', 'includes/css/');
define('_DIR_IMAGES', 'includes/images/');


?>
