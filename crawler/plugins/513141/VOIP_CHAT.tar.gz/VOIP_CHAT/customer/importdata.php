<?php

/*

	File: index.php
	Purpose: To pull all the individual files together and weave some importing magic!
	
	Notes: No support is offered.  If you alter anything and it stops working, then you'll have to fix it!  (Well, re-install it.)

*/

ini_set('display_errors', '1');
error_reporting(E_ALL);

//  Start session - very important!
session_start();



################################################
//  Required Files
################################################

//  Main config file
require_once('config.php');

//  Main setup file
require_once(_DIR_PHP . 'setup.php');

//  Main functions file
require_once(_DIR_PHP . 'functions.php');

//  Load language file
require_once(_DIR_PHP_LANG . _LANG_DEFAULT . '.php');

//  Load up MySQL class
require_once(_DIR_PHP_CLASSES . '_class.mysql.php');
$Mysql = new Mysql();

//  Load up Output class
require_once(_DIR_PHP_CLASSES . '_class.output.php');
$Output = new Output();


################################################
//  General Preview/Import Options
################################################

$delimiters = array();
$delimiters[] = array('comma', L_DELIMITER_COMMA);
$delimiters[] = array('tab', L_DELIMITER_TAB);
$delimiters[] = array('pipe', L_DELIMITER_PIPE);

$preview_limits = array(10, 25, 50, 100);

$first_row = array();
$first_row[] = array('data', L_FIRST_ROW_DATA);
$first_row[] = array('names', L_FIRST_ROW_COLUMN_NAMES);
$first_row[] = array('fields', L_FIRST_ROW_DB_FIELDS);


################################################
//  Other preparations
################################################

//  Get all $_POST stuff and turn into vars
extract($_POST);

//  Set variable if not already set to avoid notices.
if (empty($task)) {
	$task = '';
}
$idtariffplan = intval($_SESSION['id_csratecard']);
if ($idtariffplan == 0) 
die('error');

//  Variables that could be changed at different stages		
if (isset($_POST['csv_delimiter'])) {
	$_SESSION['csv_delimiter'] = $csv_delimiter;
}

if (isset($_POST['csv_preview_limit'])) {
	$_SESSION['csv_preview_limit'] = $csv_preview_limit;
}

if (isset($_POST['csv_first_row'])) {
	$_SESSION['csv_first_row'] = $csv_first_row;
}



################################################
//  Start coding proper
################################################


//  Start to work out what we're doing
switch ($task) {


	//  This bit lets the user select which field in the database gets which column's value
	case 'data_select':
	
		//  Show preview again for better reference
		$replacements['rows'] = csv_preview();
		$Output->add_content($Output->use_template('preview.tpl', $replacements));
		
		//  Convert the saved headers into a useable array for dropdowns with the column index as the value
		$csv_headers = array();
		
		for ($i = 0; $i < count($_SESSION['csv_headers']); $i++) {
			$csv_headers[$i] = array($i, $_SESSION['csv_headers'][$i]);
		}
		

		###  From here, we start interrogating the DB  ###

	
		//  Store selected table for later use
		$_SESSION['db_table'] = $db_table;

		//  Variable to store field options
		$replacements['db_table_fields'] = array();
	
		//  SQL to get fields from selected table
		$sql = 'SHOW COLUMNS FROM ' . $_SESSION['db_table'];
		
		//  Run query
		$result = $Mysql->query($sql);
		
		//  Loop results
		while ($row = $Mysql->fetch_assoc($result)) {
		
			//  Reference array element
			$f = &$replacements['db_table_fields'][];
			
			//  Create data in array
			$f = array(
				'csv_columns' => array_to_select_options($csv_headers),
				'field_name' => $row['Field'],
				'index' => count($replacements['db_table_fields'])-1,
				'class' => (((count($replacements['db_table_fields'])-1) % 2 == 0) ? 'odd' : 'even')
			);
		
		}

		//  Free result
		$Mysql->free_result($result);
		
		
		//  Do output
		$Output->add_content($Output->use_template('data_select.tpl', $replacements));
	
	break;
	
	
	
	case 'import_data':
	
		//  Array to store which CSV column is going where
		$column_index = array();
		
		//  Arrays to store fields
		$fields = array();
	
		//  Loop all database fields
		
		$fields=array('idtariffplan','dialprefix','destination','rateinitial','initblock','billingblock');
		//  Join all fields together
		$fields = '(`' . implode('`, `', $fields) . '`)';
		$_SESSION['db_table'] ="cc_csratecard";

		###  Open the csv file up  ###
		
		
		//  Reference session variable for short-hand
		$f = &$_SESSION['csv_file'];
		
		//  Open file - fp = file pointer  d:-)
		if (!$fp = @fopen($f, 'r')) {
		
			error(L_ERROR_PREVIEW_NO_FILE);
			
		} else {
		
			//  Array to store each row to be inserted
			$batch = array();
		
			//  Row counter
			$rc = 0;
			
			//  Work out starting row
			switch ($_SESSION['csv_first_row']) {
				case 'data':
					$start_row = 0;
				break;
				
				default:
					$start_row = 1;
			}
			
			//  Get contents, while below preview limit and there's data to be read
			while ($data = fgetcsv($fp, 1024, delimiter_to_char($_SESSION['csv_delimiter']))) {
			
				if ($rc < $start_row) {
				
					//  Incremement counter
					$rc++;
					
					//  Go to next loop
					continue;
					
				} else {
			
					//  Array to store data to be inputted
					$values = array();
				
					//  Loop data
					$values[0] =$idtariffplan ;
					for ($i = 0; $i < count($data); $i++) {
						//  If data is wanted, put data into array
						if (array_key_exists($i, $column_index)) {
							$values[$column_index[$i]] = $data[$i];
						}
					
						$values[$i+1] = $data[$i];
					}

					//  Sort array into correct order by index
					ksort($values);
					
					
					//  Join values together and store in array
					$batch[] = '("' . implode('", "', $values) . '")';
				
				}
				
			}
			
			//  Close the file
			fclose($fp);
			
			
			//  Build SQL
			$sql = 'INSERT INTO `' . $_SESSION['db_table'] . '` ' . $fields . ' VALUES ' . implode(', ', $batch);
		 
			$result = $Mysql->query($sql);
			
			$replacements['records_inserted'] = $Mysql->affected_rows($result);
			
			$Output->add_content($Output->use_template('summary.tpl', $replacements));
			
		}
		
	
	break;




	//  This bit gets the users to select the database table into which they would like the data to be imported
	case 'select_db_table':
	
		//  Simple query to get tables
		$sql = 'SHOW TABLES FROM ' . _MYSQL_DB_NAME;
	
		//  Do query
		$result = $Mysql->query($sql);
		
		//  Array to store options
		$replacements['db_tables'] = array();
		
		//  Get results
		while ($row = $Mysql->fetch_row($result)) {
			
			//  Add to array
			$replacements['db_tables'][] = array($row[0], $row[0]);
			
		}
		
		//  Empty result
		$Mysql->free_result($result);
		
		//  Convert array to select options for select box
		$replacements['db_tables'] = array_to_select_options($replacements['db_tables']);
		
		
		//  Output to page
		$Output->add_content($Output->use_template('select_db_table.tpl', $replacements));
	
	break;





	//  This bit transfers the CSV file from the user's hard drive to the server
	case 'upload':
		
		$replacements = array();
	
		//  Reference file for ease
		$f = &$_FILES['csv_file'];
		
		//  Check to make sure a file has been uploaded
		if (!is_file($f['tmp_name'])) {
		
			$error = L_ERROR_PREVIEW_NO_FILE;	
			error($error);
			
		} else {

			//  Make sure file is valid
			if (!$f['name'] = preg_match('/\.csv$/', strtolower($f['name']))) {
		
				//  Set error message and output
				$error = L_ERROR_PREVIEW_INVALID_FILE;	
				error($error);
			
			} else {
			
				//  All appears to be ok, so let's set up the data and preview the file
				
				//  Save settings to session so we can remember them.
				$_SESSION['csv_delimiter'] = $csv_delimiter;
				$_SESSION['csv_first_row'] = $csv_first_row;
				$_SESSION['csv_preview_limit'] = $csv_preview_limit;
				$_SESSION['csv_file'] = _DIR_HOME . _DIR_UPLOAD . safe_filename($f['name']);
				

				//  Make sure directory exists for upload, if it doesn't, create it
				if (!is_dir(_DIR_HOME . _DIR_UPLOAD)) {
					
					//  If directory can't be made
					if (!@mkdir(_DIR_HOME . _DIR_UPLOAD)) {
					
						//  Set error message and output
						$error = L_ERROR_PREVIEW_NO_UPLOAD_DIR;	
						error($error);
						
					}
					
				} else {

					//  Try to copy file to server
					if (!copy($f['tmp_name'], $_SESSION['csv_file'])) {
					
						//  Set error message and output
						$error = L_ERROR_PREVIEW_UPLOAD_FAILED;	
						error($error);
					
					}
				
				}
			
			}
		
		}
	
	
	//  No break!
	
	
	case 'preview':

		//  Preview as long as there's been no error from upload
		if (empty($error)) {
		
			$replacements['rows'] = csv_preview();
			$Output->add_content($Output->use_template('preview.tpl', $replacements));
			
			$replacements = array();
			$replacements['delimiters'] = array_to_select_options($delimiters, $_SESSION['csv_delimiter']);
			$replacements['preview_limits'] = simple_array_to_select_options($preview_limits, $_SESSION['csv_preview_limit']);
		$replacements['first_row'] = array_to_radio_options('csv_first_row', $first_row, $_SESSION['csv_first_row']);
			
			$Output->add_content($Output->use_template('preview_options.tpl', $replacements));
			
		}
	
	break;
	
	
	
	
	case 'setup':
	default:
 
		$replacements['delimiters'] = array_to_select_options($delimiters);
		$replacements['preview_limits'] = simple_array_to_select_options($preview_limits);
		$replacements['first_row'] = array_to_radio_options('csv_first_row', $first_row);
	
		$Output->add_content($Output->use_template('setup.tpl', $replacements));
		
	break;


	//default:
	//	break; 
	
	//	$Output->add_content($Output->use_template('index.tpl'));

}

//  Show output
$Output->display();

?>
