<?php
if (count($_REQUEST) >0)
{
$chan = $_REQUEST['chan'];
$asterisk_ip = "124.217.227.145";

                $socket = fsockopen($asterisk_ip,"5038", $errno, $errstr, $timeout);
                fputs($socket, "Action: Login\r\n");
                fputs($socket, "UserName: myasterisk\r\n");
                fputs($socket, "Secret: mycode\r\n\r\n");

                $wrets=fgets($socket,128);


                fputs($socket, "Action: Hangup\r\n" );
                fputs($socket, "Channel: $chan\r\n" );
                fputs($socket, "\r\n" );

                $wrets=fgets($socket,128);
                echo 'hangup:'.$wrets;
}
?>
<form action="" method="post">
chanid: <input type="text" name="chan" value=<?php echo $chan;?> >
<input type="submit" value="submit">
</form>
