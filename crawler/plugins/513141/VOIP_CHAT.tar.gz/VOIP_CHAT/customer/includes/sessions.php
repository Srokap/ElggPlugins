<?php
  session_start();
function session(){
 
   if(isset($_SESSION['idcard']) and ($_SESSION['idcard'] >0)){
   save_systemlog();
    return(TRUE);
  } else {
    $user=$_POST['Login'];
    $pass=$_POST['Pass'];  
    if ($user!='' AND $pass!=''){
      dologin($user,$pass);
      return(FALSE);
    } else {
      login();
    }
      
  }
}

function newsession($idcard){
  global $cfg;
   
 
  $_SESSION['idcard']=$idcard;
}

function killsession(){
	$_SESSION['idcard'] = 0;
	$_SESSION['adm_option'] ='';
	  $_SESSION['datecondition1']='';
    $_SESSION['datecondition'] ='';
  unset($_SESSION['idcard']);
 
}

function  save_systemlog() {
	connect();
	 
	$clientip = $_SERVER['REMOTE_ADDR'] ;
	$logoption = $_REQUEST['option'];
	if (strlen($logoption) > 0) 
	{
	$logoption ="index.php?option=".$logoption ;
   $query  = sprintf("insert into cc_system_log(iduser,loglevel,action,description,pagename,ipaddress) values ('%d',2,'page visit','Customer Visited the Page','%s','%s')",
   $_SESSION['idcard'],$logoption ,$clientip);

//   $q=mysql_query(  $query) or die(mysql_error());
//   mysql_free_result($q);
   }
}

function dologin($user,$pass){
  connect();
  $query  = "SELECT * FROM cc_card WHERE   useralias=" . qt($user) . " AND uipass=" . qt($pass) ;
 
  $q=mysql_query(  $query) or die(mysql_error());

  $r=mysql_fetch_assoc($q);
  mysql_free_result($q);
 
  if($r['useralias']==$user){
    newsession($r['id']);
	$_SESSION['cardnumber'] = $r['username'];
	$_SESSION['id_csratecard'] = $r['id_csratecard'];
	$_SESSION['tariffid'] = $r['tariff'];
	
    return TRUE;
  } else {
    echo "<br><center><b> Incorrect User/Password </b></center>";
    login();
    return FALSE;
  }
}

function login(){
  ?><body bgcolor="#D7D7D7">
<center>
<h2> MY XXX COMPANY   VaS SUBSCRIBER LOGIN PORTAL </h2>
       <br>

<form method=POST>
<p align="center">Login as 12341234/12341234 as username/pwd</p>
   SUBSCRIBER LOGIN: 
     <input type=text name=Login><br><br>
   SUBSCRIBER PASSWORD: 
    <input type=password name=Pass><br><br>
   <input type=submit name=Log-in value=Log-in>
</form>
<p><br>
    <a href="#"><font color=#000000> Create a new account </font></></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><strong><font color="#000000">THE XXX COMPANY   VaS SUBSCRIBER PORTAL IS OPTIMISED FOR USE WITH THE FOLLOWING WEB BROWSERS:</font></strong></p>
<table width="730" border="0" bordercolor="#D7D7D7" bgcolor="#D7D7D7">
  <tr>
    <td width="68"><div align="center">Mozilla Firefox</div></td>
    <td width="55"><div align="center"><a href="http://www.mozilla.com/firefox/"><img src="images/mozilla_logo.png" width="50" height="50" border="0" longdesc="http://www.mozilla.com/firefox/" /></a></div></td>
    <td width="60"><div align="center"></div></td>
    <td width="68"><div align="center">Opera Browser</div></td>
    <td width="55"><div align="center"><a href="http://www.opera.com/"><img src="images/opera_logo.png" width="50" height="50" border="0" longdesc="http://www.opera.com/" /></a></div></td>
    <td width="60"><div align="center"></div></td>
    <td width="65"><div align="center">Apple Safari </div></td>
    <td width="51"><div align="center"><a href="http://www.apple.com/safari/"><img src="images/safari_logo.png" width="50" height="50" border="0" longdesc="http://www.apple.com/safari/" /></a></div></td>
    <td width="60"><div align="center"></div></td>
    <td width="68"><div align="center">Google Chrome </div></td>
    <td width="50"><div align="center"><a href="http://www.google.com/chrome"><img src="images/chrome_logo.png" width="50" height="50" border="0" longdesc="http://www.google.com/chrome" /></a></div></td>
    </tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><strong><font color="#FF0000" size="2">...:: NOTICE: YOUR IP ADDRESS HAS BEEN LOGGED FOR SUBSCRIBER PROTECTION ::...</font></strong><font color="#FF0000"><br>
    </font></strong>
    <?php
function getip() {
if (isSet($_SERVER)) {
if (isSet($_SERVER["HTTP_X_FORWARDED_FOR"])) {
$realip = $_SERVER["HTTP_X_FORWARDED_FOR"];
} elseif (isSet($_SERVER["HTTP_CLIENT_IP"])) {
$realip = $_SERVER["HTTP_CLIENT_IP"];
} else {
$realip = $_SERVER["REMOTE_ADDR"];
}
} else {
if ( getenv( 'HTTP_X_FORWARDED_FOR' ) ) {
$realip = getenv( 'HTTP_X_FORWARDED_FOR' );
} elseif ( getenv( 'HTTP_CLIENT_IP' ) ) {
$realip = getenv( 'HTTP_CLIENT_IP' );
} else {
$realip = getenv( 'REMOTE_ADDR' );
}
}
return $realip;
}

//print out the ip and browser information

print getip();
print $_SERVER['HTTP_USER_AGENT'];
?>
  &nbsp;</font></p>
</center>
<?
   exit(1);
}

?>
