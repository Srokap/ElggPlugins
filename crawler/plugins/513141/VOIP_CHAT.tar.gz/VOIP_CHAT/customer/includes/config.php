<?php

// 2010 - Juan Sebastian Gomez & Jacob Maldonado

// config.php
// System Configuration

// Main
$cfg['main']['sitename'] = 'iVoS IPSTAR SUBSCRIBER PORTAL';   // Site Name

// DB Access 
$cfg['db']['host'] = 'localhost';   // Hostname
$cfg['db']['user'] = 'dbuser'; // User
$cfg['db']['pwd'] = 'dbpass';  // Password
$cfg['db']['base'] = 'dbname'; // DB

// Web

$cfg['web']['urlbase'] = ""; //Base URL

// Misc

$cfg['misc']['admin'] = '';

?>
