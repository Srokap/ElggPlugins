<?php

/*

	File: en.php
	Purpose: Stores all English language text.  English is default.

*/


###############################################
//  Basic error messages
###############################################

define('L_ERROR_MYSQL_CONNECT', 'The script is unable to connect to MySQL.&nbsp; Please check MySQL is running and the settings in "config.php" are correct.&nbsp; The message below gives more information on the error:<hr />');
define('L_ERROR_MYSQL_DB_SELECT', 'The script is unable to find the selected database.&nbsp; Please check its name is entered correctly in "config.php".&nbsp; The message below gives more information on the error:<hr />');
define('L_ERROR_OUTPUT_TEMPLATE_NOT_FOUND', 'The template "{$template}" specified does not exist.&nbsp; Please check and try again.');
define('L_ERROR_OUTPUT_TEMPLATE_NOT_OPENED', 'The template "{$template}" specified could not be opened.&nbsp; Please check file rights (CHMOD) and try again.');


###############################################
//  Delimiter names
###############################################

define('L_DELIMITER_COMMA', 'Comma');		//  ,
define('L_DELIMITER_TAB', 'Tab');			//  TAB (the one to the left of "Q"; the ->| key
define('L_DELIMITER_PIPE', 'Pipe');			//  |


###############################################
//  First row options
###############################################

define('L_FIRST_ROW_DATA', 'Data');
define('L_FIRST_ROW_COLUMN_NAMES', 'Column names');
define('L_FIRST_ROW_DB_FIELDS', 'Database fields');


###############################################
//  Buttons
###############################################

define('L_BUTTON_CONTINUE', 'Continue &raquo;');
define('L_BUTTON_IMPORT', 'Import a file');
define('L_BUTTON_PREVIEW', 'Preview');
define('L_BUTTON_VISIT_WEBSITE', 'Go to website');


###############################################
//  Setup stage
###############################################

define('L_SETUP_TITLE', 'File setup');
define('L_SETUP_SELECT_FILE', 'Select the file on your hard drive');
define('L_SETUP_CHOOSE_DELIMITER', 'How are the columns separated?');
define('L_SETUP_PREVIEW_LIMIT', 'How many rows would you like to preview?');
define('L_SETUP_FIRST_ROW', 'What does the first row contain?');


###############################################
//  Upload stage
###############################################

//  Errors

define('L_ERROR_PREVIEW_NO_FILE', 'No file appears to have been uploaded or it has been deleted or moved.&nbsp; Please try again.');
define('L_ERROR_PREVIEW_INVALID_FILE', 'The file uploaded does not appear to be a valid .csv file.&nbsp; Please check it and try again.');
define('L_ERROR_PREVIEW_NO_UPLOAD_DIR', 'The upload directory does not exist and it could not be created.&nbsp; Either create the folder &quot;' . _DIR_UPLOAD . '&quot; yourself or check file permissions (CHMOD) and try again.');
define('L_ERROR_PREVIEW_UPLOAD_FAILED', 'The file could not be copied to the server.&nbsp; Check file permissions (CHMOD) and try again.');


###############################################
//  Preview stage
###############################################

define('L_PREVIEW_TITLE', 'Preview your file');
define('L_PREVIEW_DESCRIPTION', 'Check to see if your file looks right in the preview window.');
define('L_PREVIEW_OPTIONS_TITLE', 'File setup');


###############################################
//  Database table section stage
###############################################
define('L_DB_TABLE_SELECT_TITLE', 'Database table select');
define('L_DB_TABLE_SELECT_DESCRIPTION', 'Please select the table into which you would like to import the CSV file.');


###############################################
//  Data selection section stage
###############################################
define('L_DATA_SELECT_TITLE', 'Database table select');
define('L_DATA_SELECT_DESCRIPTION', 'Please select the table into which you would like to import the CSV file.&nbsp; Use the priview window to help you match the columns up correctly.');
define('L_DATA_SELECT_NO_VALUE', 'None');
define('L_DATA_SELECT_DATABASE_FIELD', 'Database Field');
define('L_DATA_SELECT_COLUMN', 'Column from CSV file');


###############################################
//  Summary stage
###############################################

define('L_SUMMARY_TITLE', 'Action summary');
define('L_SUMMARY_DESCRIPTION', 'Here is a summary of actions performed:');
define('L_SUMMARY_RECORDS_INSERTED', 'Records inserted');
define('L_SUMMARY_ANOTHER_FILE', 'Import another file');



?>