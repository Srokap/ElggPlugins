<?php


#######################################################################################
#
##
###==>  WARNING!
##
#
#
#  If you alter anything in here, it's very likely things could stop working!
#  Only experienced PHP-ers should alter any of this - and they shouldn't need to.
#  It's here for reference only.
#
#######################################################################################



################################################
//  Template/Ouput Values
################################################

define('_THEME_DEFAULT', 'default');
define('_TMPL_L_DELIM', '{');
define('_TMPL_R_DELIM', '}');


################################################
//  Script Info
################################################

define('_SCRIPT_AUTHOR', 'Matthew Lindley');
define('_SCRIPT_DONATE_EMAIL', 'matt[at]asafeplace.co.uk');
define('_SCRIPT_NAME', 'PHP CSV Importer');
define('_SCRIPT_VERSION', '3.0.1a');
define('_SCRIPT_WEBSITE', 'http://www.phpcsvimporter.co.uk');


?>