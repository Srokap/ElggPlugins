<?php


/*

	Class:  Mysql
	File:  _class.mysql.php
	Version: 1.1.0
	Purpose: Manages the MySQL connectivity and queries

*/


class Mysql {


	//  Constructor
	function Mysql() {
	
		//  Connect to MySQL
		$this->db_connection = mysql_connect(_MYSQL_HOST, _MYSQL_USERNAME, _MYSQL_PASSWORD) or die(L_ERROR_MYSQL_CONNECT . mysql_error());
		
		//  Select database
		mysql_select_db(_MYSQL_DB_NAME, $this->db_connection) or die(L_ERROR_MYSQL_DB_SELECT . mysql_error());
	}
	
	
	
	function affected_rows() {
		return mysql_affected_rows($this->db_connection);
	}
	
	
	
	function date_to_mysql_date($date) {

		if (($date == "") || (!preg_match("/^[0-3][0-9]\/[0-1][0-9]\/[0-9]{4}$/", $date))) {
			return false;
		}
		
		$date = implode("-", array_reverse(explode("/", $date)));
		
		return $date;
	
	}
	
	
	
	function error($sql) {
		return mysql_error() . "<hr />" . nl2br(str_replace("\t", str_repeat("&nbsp;", 5), $sql));
	}
	
	
	
	function fetch_array() {
	
		return mysql_fetch_array($this->result);
		
	}
	
	
	
	function fetch_assoc() {
		return mysql_fetch_assoc($this->result);
	}
	
	
	
	function free_result() {
		return mysql_free_result($this->result);
	}
	
	
	
	function fetch_row() {
		return mysql_fetch_row($this->result);
	}
	
	
	
	function insert_id() {
		return mysql_insert_id($this->db_connection);
	}
	
	
	
	function mysql_date_to_date($date, $sep = "-") {

		if (($date == "") || (!preg_match("/[0-9]{4}" . $sep . "[0-1][0-9]" . $sep . "[0-3][0-9]/", $date))) {
			return false;
		}
	
		return implode("/", array_reverse(explode($sep, $date)));
	
	}
	
	
	
	function num_rows() {
		return mysql_num_rows($this->result);
	}
	
	
	
	function query($sql) {
	
		$this->result = mysql_query($sql, $this->db_connection);
		
		if (!$this->result) {
			trigger_error($this->error($sql));
		}
	
		return $this->result;
	
	}
	
	
	
	function sql_to_array($sql) {
	
		//  Run query
		if (!$this->query($sql)) {
			return false;
		}
		
		$records = array();
		$i = 0;
		
		//  Loop records
		while ($row = $this->fetch_assoc()) {
			
			//  Add to array
			foreach ($row as $k => $v) {
				$records[$i][$k] = $v;
			}
			
			$records[$i]['_i'] = $i;
			
			$i++;
		}
		
		//  Free result
		$this->free_result();

		//  Return results
		return $records;

	}
	
	
	
	function sql_to_assoc($sql) {
	
		//  Run query
		if (!$this->query($sql)) {
			return false;
		}
		
		$array = array();
		
		//  Loop records
		while ($row = $this->fetch_assoc()) {
			
			//  Add to array
			foreach ($row as $k => $v) {
				$array[$k] = $v;
			}
		}
		
		//  Free result
		$this->free_result();

		//  Return results
		return $array;
		
	}
	
	
	
	function sql_to_select_options($sql, $selected_value = "") {
	
		$options = "";
		
		$this->query($sql);
		
		if (!$this->result) {
			return false;
		}
		
		while ($row = $this->fetch_row()) {
		
			$options .= "\n\t\t<option value=\"{$row[0]}\"" . (($row[0] == $selected_value) ? " selected" : "") .">{$row[1]}</option>";
			
		}
		
		//  Free result
		$this->free_result();
		
		return $options;
	}
	
	
	function sql_to_simple_array($sql) {
	
		//  Run query
		if (!$this->query($sql)) {
			return false;
		}
		
		$records = array();
		
		//  Loop records
		while ($row = $this->fetch_assoc()) {
			
			//  Add to array
			foreach ($row as $k => $v) {
				$records[] = $v;
			}
			
		}
		
		//  Free result
		$this->free_result();

		//  Return results
		return $records;

	}
	
	

	function test_sql($sql) {
		
		if (!$this->query($sql)) {
		
			trigger_error($this->error($sql));
			return false;
			
		} else {
		
			$results = "";
			
			while ($row = $this->fetch_assoc()) {
			
				foreach ($row as $k => $v) {
					
					$results .= "\n$k = $v\n<br />";
					
				}
				
				$results .= "\n\n<hr />\n";
				
			}
			
			$this->free_result();
		
			return $results;
			
		}
		
	}
	
	
}


?>