<?php

/*

	File: functions.php
	Purpose: Stores all the functions...

	I know doing using "global" isn't the best thing to do but the system relies on having $Output being available so it just makes things easier
*/



	
function array_to_radio_options ($name, $array, $selected_value = -1, $spacer = '&nbsp;&nbsp;&nbsp;') {
	//  example: $array[] = array("id", "text");

	if (count($array) == 0) {
	
		return;
	
	} else {
	
		$options = "";
	
		for ($i = 0; $i < count($array); $i++) {
			$options .= "\n\t\t<input type='radio' name='$name' value=\"{$array[$i][0]}\"" . (($array[$i][0] == $selected_value) ? ' checked' : '') .">{$array[$i][1]}$spacer";
		}

		return $options;
	
	}
	
}


	
function array_to_select_options ($array, $selected_value = -1) {
	//  example: $array[] = array("id", "text");

	if (count($array) == 0) {
	
		return;
	
	} else {
	
		$options = "";
	
		for ($i = 0; $i < count($array); $i++) {
			$options .= "\n\t\t<option value=\"{$array[$i][0]}\"" . (($array[$i][0] == $selected_value) ? ' selected' : '') .">{$array[$i][1]}</option>";
		}

		return $options;
	
	}
	
}



function csv_preview() {

	global $Output;
	
	//  Reference session variable for short-hand
	$f = &$_SESSION['csv_file'];
	
	//  Open file - fp = file pointer  d:-)
	if (!$fp = @fopen($f, 'r')) {
	
		error(L_ERROR_PREVIEW_NO_FILE);
		
	} else {
	
		//  Set row counter
		$rc = 0;
		
		//  Array to store preview
		$data = array();
		
		//  Count largest number of columns to allow dropdowns on data select page
		$_SESSION['csv_max_cols'] = 0;
		
		//  Get contents, while below preview limit and there's data to be read
		while (($rc < $_SESSION['csv_preview_limit']) && ($row = fgetcsv($fp, 1024, delimiter_to_char($_SESSION['csv_delimiter'])))) {
		
			//  If this row's column number is bigger than what's already recorded, save it
			if (count($row) > $_SESSION['csv_max_cols']) {
				$_SESSION['csv_max_cols'] = count($row);
			}
		
			//  Add row to data
			$data[$rc] = array();
			$data[$rc]['cols'] = array();
			
			//  If we're on the first row, work out whether to save the headers or not and work out the css class
			if ($rc == 0) {
				switch ($_SESSION['csv_first_row']) {
					case 'data':
						$data[$rc]['class'] = (($rc % 2) == 0) ? 'odd' : 'even';
					break;
					
					default:
						$_SESSION['csv_headers'] = $row;
						$data[$rc]['class'] = 'header';
				}
				
			} else {
			
				$data[$rc]['class'] = (($rc % 2) == 0) ? 'odd' : 'even';
				
			}
			
			//  Put data from CSV file into array for use by the template
			foreach ($row as $k => $v) {
				$data[$rc]['cols'][]['value'] = $v;
			}
			
			
			//  Increment counter
			$rc++;
			
		}
		
		//  Close file
		fclose($fp);
		
		
		//  See if first row is just data, if so, we need to add generic headers
		switch ($_SESSION['csv_first_row']) {
			case 'data':
			
				//  Define array(s)
				$new_headers = array();
				$new_headers['cols'] = array();
				
				//  Set class
				$new_headers['class'] = 'header';
				
				//  Get headers
				$columns = make_column_options();
				
				//  Loop columns and add to array
				foreach ($columns as $k => $v) {
					$new_headers['cols'][]['value'] = $v;
				}
				
				//  Prepend to data array
				array_unshift($data, $new_headers);

				//  Save for dropdowns
				$_SESSION['csv_headers'] = $new_headers;
			break;
			
			default:
			
		}
		
		
		//  Send data back
		return $data;
	
	}

}


function delimiter_to_char($delimiter = 'comma') {

	switch ($delimiter) {
	
		case 'pipe';
			return '|';
		break;
	
		case 'tab':
			return "\t";		//  Note use of " to ensure it returns as a proper tab
		break;
		
		default:
			return ',';
	
	}

}


function error($error) {

	global $Output;
	
	$replacements['error'] = $error;
	
	$Output->add_content($Output->use_template('error.tpl', $replacements));

}



function make_column_options() {
	
	$array = array();
	
	for ($i = 1; $i <= $_SESSION['csv_max_cols']; $i++) {
		$array[] = 'Column ' . $i;
	}
	
	return $array;
	
}



function safe_filename($filename) {

	//  Convert to lower case
	$filename = strtolower($filename);
	
	//  Replace spaces with underscores
	$filename = str_replace(' ', '_', $filename);
	
	//  Remove anything not a-z, 0-9, _ or .
	$filename = preg_replace('/[^[a-z0-9_\.]/', '', $filename);
	
	//  Send filename back
	return $filename;

}
	
	
	
function simple_array_to_select_options ($array, $selected_value = "") {
	//  example: $array[] = "text";
	$options = "";
	
	foreach($array as $a) {
		$options .= "\n\t\t<option value=\"$a\"" . (($a == $selected_value) ? " selected" : "") .">$a</option>";
	}
	
	return $options;
}
	
	

?>