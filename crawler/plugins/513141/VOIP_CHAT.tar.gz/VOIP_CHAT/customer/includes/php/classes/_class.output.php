<?php

/*

	Class:  Output
	File:  _class.output.php
	Version: 1.0.0
	Purpose: Merges data and templates to create output

*/


class Output {

	//  Constructor
	function Output() {
		$this->content['content'] = '';
		$this->theme = 'default';
		$this->theme_file = 'theme.tpl';
	}
	
	
	//  Function to concatenate content
	function add_content($content) {
		$this->content['content'] .= $content;
	}
	
	
	//  Function to output content
	function display() {
	
		if (!$this->is_theme($this->theme)) {
			$theme = _DIR_HTML_THEMES  . $this->theme . '/' . $this->theme_file;
		}

		echo $this->process_template($theme, $this->content);
	
	}
	
	
	//  Function to check whether a theme exists
	function is_theme($theme) {
		return is_file(_DIR_HTML_THEMES . $this->theme_file);
	}
	
	
	//  Function to take all the strings etc and process within the speficied template via token replacements
	function process_template($template, $replacements) {
		
		//  Check to see if template exists
		if (!is_file($template)) {

			//  No - error message and return false
			echo str_replace('{$template}', $template, L_ERROR_OUTPUT_TEMPLATE_NOT_FOUND);
			return false;

		} else {
		
			//  Template exists, so let's try to open it up
			if (!$fp = @fopen($template, 'r')) {

				echo str_replace('{$template}', $template, L_ERROR_OUTPUT_TEMPLATE_NOT_OPENED);
				return false;

			} else {
			
				$theme_replacements = array();
			
				//  Get contents of file
				$content = fread($fp, filesize($template));
			
				//  Close file
				fclose($fp);
							
			}
		
		}
	

		//  Do straight-forward replacement of strings
		$this->_pt_strings($content, $replacements);
	

		//  Do straight-forward replacement of defined variables
		$this->_pt_defined($content);
		

		//  Send content back all done
		return $content;
	
	}
	
	
	######################################
	//  Process template sub-functions  //
	######################################
		
		
		function _pt_defined (&$contents) {
	
			$regexp = '/' . _TMPL_L_DELIM . '%([A-Z0-9_])*' . _TMPL_R_DELIM . '/';
	
			while (preg_match($regexp, $contents, $matched)) {
	
				//  Variable to be replaced
				$var = substr($matched[0], 2, -1);
	
				//  Get variable value via eval()
				eval("\$replacer = $var;");
	
				//  Do replacing
				$contents = str_replace($matched[0], $replacer, $contents);
			
			}
		
		}
		
		
		function _pt_repeat ($contents, $tag, $replacements) {
		
			//  Variable to store concatenated repeating data
			$repeat_data = '';
			
			//  Repeat area start and finish tags
			$start_tag = _TMPL_L_DELIM . '#' . $tag . _TMPL_R_DELIM;
			$finish_tag = _TMPL_L_DELIM . '\/#' . $tag . _TMPL_R_DELIM;
			
			//  Regexp to pick out area
			$regexp = "/" . $start_tag . "[\d\D\s\S\w\W_'\(\)]*" . $finish_tag . "/";

			//  Do regexp stuff
			if (preg_match($regexp, $contents, $repeater)) {

				for ($i = 0; $i < count($replacements); $i++) {
				
					//  Variable to store data on a row-by-row basis
					$row_data = $repeater[0];
					
					//  Remove start and finish tags which denote repeat area
					$row_data = str_replace(stripslashes($start_tag), '', $row_data);
					$row_data = str_replace(stripslashes($finish_tag), '', $row_data);
				
					foreach ($replacements[$i] as $x => $y) {
					
						if (is_array($y)) {

							$row_data = $this->_pt_repeat($row_data, $x, $y);
						} else {
							$row_data = str_replace(_TMPL_L_DELIM . '$' .$x . _TMPL_R_DELIM, $y, $row_data);
						}
					}
		
					$repeat_data .= $row_data;
				}
				
				$contents = preg_replace($regexp, $repeat_data, $contents);
			
			}
			
			return $contents;
		
		}
	
	
		function _pt_strings (&$content, $replacements) {

			//  If we are doing replacements
			if (is_array($replacements)) {

				//  Loop
				foreach ($replacements as $k => $v) {
					
					//  If it's an array it's a repeater, so parse as such
					if (is_array($v)) {

						$content = $this->_pt_repeat($content, $k, $v);
					
					} else {
					
						//  Plain ol' string so just replace
						$content = str_replace('{$'.$k.'}', $v, $content);
						
					}
					
				}
				
			}
		
		}
	
	
	
	//  Function to say which theme we should use
	function set_theme($theme = _THEME_DEFAULT) {
		$this->theme = ($this->is_theme($theme)) ? $theme : _THEME_DEFAULT;
	}
	
	
	
	function use_template($template = '', $replacements = '') {
	
		//  Prepend template directory to template
		$template = _DIR_HTML_TEMPLATES . $template;

		//  Process file (do token replacements)
		return $this->process_template($template, $replacements);
		
	}

}

?>