<?php

connect();

function display_flash() {
 include "callshop.php";
}
function com_edit_details(){
  
   include "callshopdetail.php";
	 
}

function  com_booth(){
  include "booth.php";
}

function  com_operator(){
  include "boothoperator.php";
}

function com_rates(){
  include "boothrate.php";
}
function com_buyrates() {
   include "buyrates.php";
}

function com_friends(){
   include "sipfriends.php";
}
 
 function usr_calls(){
 include "boothcalls.php";
}

function daily_his(){
 include "dailyboothcalls.php";
}
function monthly_his(){
 include "monthlyboothcalls.php";
}
function import_rates(){
   include "importdata.php";
}


function usr_logout(){
  killsession();
  echo "Thanks for using the system. <br> You are now logged out. ".$_SESSION['idcard'];
  
}

function sql_update_fields($Form){
  foreach ($Form['Fields'] as $Key => $Value){
    $fields[]=$Key . "=" . qt($_GET[$Key]);
  }
  $query=implode(", ", $fields);
  return($query);
}


function MDP_NUMERIC($chrs =10){
	$pwd = ""  ;
	mt_srand ((double) microtime() * 1000000);
	while (strlen($pwd)<$chrs)
	{
		$chr = mt_rand (0,9);
		if (eregi("^[0-9]$", $chr))
		$pwd = $pwd.$chr;
	};
	return strtolower($pwd);
}


function MDP($chrs = 10){
	$pwd = ""  ;
	mt_srand ((double) microtime() * 1000000);
	while (strlen($pwd)<$chrs)
	{
		$chr = chr(mt_rand (0,255));
		if (eregi("^[0-9]$", $chr))
		$pwd = $pwd.$chr;
	};
	return $pwd;
}  
function MDP_STRING($chrs = 10){
	$pwd = ""  ;
	mt_srand ((double) microtime() * 1000000);
	while (strlen($pwd)<$chrs)
	{
		$chr = chr(mt_rand (0,255));
		if (eregi("^[0-9a-z]$", $chr))
		$pwd = $pwd.$chr;
	};
	return strtolower($pwd);
}

?>
