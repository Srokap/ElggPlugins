<?php

//error_reporting(E_ALL);
error_reporting(E_STRICT);


date_default_timezone_set('America/Toronto');
//date_default_timezone_set(date_default_timezone_get());

include_once('class.phpmailer.php');


mysql_connect('localhost','allvoip_mydrupal','mydrupal') or die ("Error connecting to MySQL server" . mysql_error());
 mysql_select_db('allvoip_mydrupal') or die ("Error selecting database: " . mysql_error());
  
  $query ="select name,mail from users" ;
  
  $q=mysql_query(  $query) or die(mysql_error());

  $r=mysql_fetch_assoc($q);
  while ($r)  {
  $name  = $r['name'];
  $mailaddr=$r['mail'];
  
  $mail             = new PHPMailer();
$body             = $mail->getFile('contents.html');
$body             = eregi_replace("[\]",'',$body);

$mail->IsSendmail(); // telling the class to use SendMail transport

$mail->From       = "hfvoip@allvoipsolutions.org";
$mail->FromName   = "Allvoipsolutions";

$mail->Subject    = "voip solutions for you,cheap,reliable,honest, this is yearly sent email";

$mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test

$mail->MsgHTML($body);

$mail->IsHTML(true); // send as HTML
   
  $mail->AddAddress($mailaddr,$name);
	if(!$mail->Send()) {
	  echo "Mailer Error: " . $mail->ErrorInfo.$name.'\n';
	} else {
	  echo "Message sent to !: ".$name.'\n';
	}
    $r=mysql_fetch_assoc($q);
   
  }
  mysql_free_result($q);
 
?>

