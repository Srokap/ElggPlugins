<?php
function qt($cadena){
  if (!is_numeric($cadena)) {
    $cadena = "'" . mysql_real_escape_string($cadena) . "'";
  }
  return $cadena;
}

// just like quote but for use in like statements
function qtlike($cadena){
  if (!is_numeric($cadena)) {
    $cadena = "'%" . mysql_real_escape_string($cadena) . "%'";
  }
  return $cadena;
}
 // Connect to DB and select database
function connect(){
 
    global $cfg;
  $conexion=mysql_connect($cfg['db']['host'],$cfg['db']['user'],$cfg['db']['pwd']) or die ("Error connecting to MySQL server" . mysql_error());
  mysql_select_db($cfg['db']['base']) or die ("Error selecting database: " . mysql_error());

}
?>