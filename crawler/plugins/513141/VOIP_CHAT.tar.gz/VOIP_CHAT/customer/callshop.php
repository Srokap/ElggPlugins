 
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
 
<style>
body { margin: 0px; overflow:auto }
</style>
 
</head>

<body   >
 
	 
 
  	<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="680" height="520"
			codebase="http://fpdownload.macromedia.com/get/flashplayer/current/swflash.cab">
			<param name="movie" value="callshop.swf" />
			<param name="quality" value="high" />
			<param name="bgcolor" value="#ffffff" />
			<param name="flashVars" value="uid=<?=$_SESSION['idcard']?>">
			<param name="allowScriptAccess" value="sameDomain" />
			<embed src="callshop.swf" quality="high" bgcolor="#ffffff"
				width="660" height="500" name="callshop" align="middle"
				play="true"
				loop="false"
				quality="high"
				flashVars="uid=<?=$_SESSION['idcard']?>"
				allowScriptAccess="sameDomain"
				type="application/x-shockwave-flash"
				pluginspage="http://www.adobe.com/go/getflashplayer">
			</embed>
</object>
 
</body>
</html>
