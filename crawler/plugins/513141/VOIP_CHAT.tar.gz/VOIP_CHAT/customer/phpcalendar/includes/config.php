<?
$version = "2.0";
$installed = 1;
$use_auth = 0;

// MYSQL DB INFO
$DBHost = "localhost";
$DBName = "allvoip_voip2";
$DBUser = "allvoip_voip";
$DBPass = "58493580";
$TBL_PR = "calendar_";
?>
