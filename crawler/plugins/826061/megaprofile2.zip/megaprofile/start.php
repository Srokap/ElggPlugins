<?php

//megaprofile star.php
//megaprofile v2
//diseñado por www.floops.com.ar
//la red social argentina
//para la comunidad elgg.org

function megaprofile_init(){}
extend_view('css', 'megaprofile/css');
register_elgg_event_handler('init','system','megaprofile_init');

register_action("megaprofile/add", FALSE, $CONFIG->pluginspath . "megaprofile/actions/add.php", TRUE);
?>
