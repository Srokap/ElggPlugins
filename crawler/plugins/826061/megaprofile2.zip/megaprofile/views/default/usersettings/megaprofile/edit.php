<?php

//megaprofile v1.1 edit.php
//dise�ado por www.floops.com.ar
//la red social argentina
//para la comunidad elgg.org

    $user_id = get_loggedin_userid();
	$friends_shows_beta_enabled = $vars["entity"]->friends_shows_beta_enabled;
	$friends_shows_beta = $vars["entity"]->friends_shows_beta;
	$paginas_shows_beta_enabled = $vars["entity"]->paginas_shows_beta_enabled;
	$paginas_shows_beta = $vars["entity"]->paginas_shows_beta;
    $fotos_shows_beta_enabled = $vars["entity"]->fotos_shows_beta_enabled;
	$fotos_shows_beta = $vars["entity"]->fotos_shows_beta;
	$estado_shows_beta_enabled = $vars["entity"]->estado_shows_beta_enabled;
	$estado_shows_beta = $vars["entity"]->estado_shows_beta;
	$videos_shows_beta_enabled = $vars["entity"]->videos_shows_beta_enabled;
	$videos_shows_beta = $vars["entity"]->videos_shows_beta;
	$marcadores_shows_beta_enabled = $vars["entity"]->marcadores_shows_beta_enabled;
	$marcadores_shows_beta = $vars["entity"]->marcadores_shows_beta;
	$grupos_shows_beta_enabled = $vars["entity"]->grupos_shows_beta_enabled;
	$grupos_shows_beta = $vars["entity"]->grupos_shows_beta;
	$blog_shows_beta_enabled = $vars["entity"]->blog_shows_beta_enabled;
	$blog_shows_beta = $vars["entity"]->blog_shows_beta;
	$wire_shows_beta_enabled = $vars["entity"]->wire_shows_beta_enabled;
	$wire_shows_beta = $vars["entity"]->wire_shows_beta;
?>

<?php echo elgg_echo("megaprofile:privacy:friends"); ?>
	<select name="params[friends_shows_beta]">
		<option value="all" <?php if($friends_shows_beta == "all" || empty($friends_shows_beta_enabled)) echo "selected='yes'"; ?>><?php echo elgg_echo("todos"); ?></option>
		<option value="friends"<?php if($friends_shows_beta == "friends") echo "selected='yes'"; ?>><?php echo elgg_echo("amigos"); ?></option>
		<option value="none"<?php if($friends_shows_beta == "none") echo "selected='yes'"; ?>><?php echo elgg_echo("nadie"); ?></option>
	</select>
	<br/>	
    
    <?php echo elgg_echo("megaprofile:privacy:pages"); ?>
	<select name="params[paginas_shows_beta]">
		<option value="all" <?php if($paginas_shows_beta == "all" || empty($paginas_shows_beta_enabled)) echo "selected='yes'"; ?>><?php echo elgg_echo("todos"); ?></option>
		<option value="friends"<?php if($paginas_shows_beta == "friends") echo "selected='yes'"; ?>><?php echo elgg_echo("amigos"); ?></option>
		<option value="none"<?php if($paginas_shows_beta == "none") echo "selected='yes'"; ?>><?php echo elgg_echo("nadie"); ?></option>
	</select>
	<br/>	
    
<?php echo elgg_echo("megaprofile:privacy:photo"); ?>
	<select name="params[fotos_shows_beta]">
		<option value="all" <?php if($fotos_shows_beta == "all" || empty($fotos_shows_beta_enabled)) echo "selected='yes'"; ?>><?php echo elgg_echo("todos"); ?></option>
		<option value="friends"<?php if($fotos_shows_beta == "friends") echo "selected='yes'"; ?>><?php echo elgg_echo("amigos"); ?></option>
		<option value="none"<?php if($fotos_shows_beta == "none") echo "selected='yes'"; ?>><?php echo elgg_echo("nadie"); ?></option>
	</select>
	<br/>	
    
<?php echo elgg_echo("megaprofile:privacy:status"); ?>
	<select name="params[estado_shows_beta]">
		<option value="all" <?php if($estado_shows_beta == "all" || empty($estado_shows_beta_enabled)) echo "selected='yes'"; ?>><?php echo elgg_echo("todos"); ?></option>
		<option value="friends"<?php if($estado_shows_beta == "friends") echo "selected='yes'"; ?>><?php echo elgg_echo("amigos"); ?></option>
		<option value="none"<?php if($estado_shows_beta == "none") echo "selected='yes'"; ?>><?php echo elgg_echo("nadie"); ?></option>
	</select>
	<br/>	

<?php echo elgg_echo("megaprofile:privacy:videos"); ?>
	<select name="params[videos_shows_beta]">
		<option value="all" <?php if($videos_shows_beta == "all" || empty($videos_shows_beta_enabled)) echo "selected='yes'"; ?>><?php echo elgg_echo("todos"); ?></option>
		<option value="friends"<?php if($videos_shows_beta == "friends") echo "selected='yes'"; ?>><?php echo elgg_echo("amigos"); ?></option>
		<option value="none"<?php if($videos_shows_beta == "none") echo "selected='yes'"; ?>><?php echo elgg_echo("nadie"); ?></option>
	</select>
	<br/>	
    
    
    <?php echo elgg_echo("megaprofile:privacy:blog"); ?>
	<select name="params[blog_shows_beta]">
		<option value="all" <?php if($blog_shows_beta == "all" || empty($blog_shows_beta_enabled)) echo "selected='yes'"; ?>><?php echo elgg_echo("todos"); ?></option>
		<option value="friends"<?php if($blog_shows_beta == "friends") echo "selected='yes'"; ?>><?php echo elgg_echo("amigos"); ?></option>
		<option value="none"<?php if($blog_shows_beta == "none") echo "selected='yes'"; ?>><?php echo elgg_echo("nadie"); ?></option>
	</select>
	<br/>	
    
    
    <?php echo elgg_echo("megaprofile:privacy:bookmarks"); ?>
	<select name="params[marcadores_shows_beta]">
		<option value="all" <?php if($marcadores_shows_beta == "all" || empty($marcadores_shows_beta_enabled)) echo "selected='yes'"; ?>><?php echo elgg_echo("todos"); ?></option>
		<option value="friends"<?php if($marcadores_shows_beta == "friends") echo "selected='yes'"; ?>><?php echo elgg_echo("amigos"); ?></option>
		<option value="none"<?php if($marcadores_shows_beta == "none") echo "selected='yes'"; ?>><?php echo elgg_echo("nadie"); ?></option>
	</select>
	<br/>	
    
    
    <?php echo elgg_echo("megaprofile:privacy:groups"); ?>
	<select name="params[grupos_shows_beta]">
		<option value="all" <?php if($grupos_shows_beta == "all" || empty($grupos_shows_beta_enabled)) echo "selected='yes'"; ?>><?php echo elgg_echo("todos"); ?></option>
		<option value="friends"<?php if($grupos_shows_beta == "friends") echo "selected='yes'"; ?>><?php echo elgg_echo("amigos"); ?></option>
		<option value="none"<?php if($grupos_shows_beta == "none") echo "selected='yes'"; ?>><?php echo elgg_echo("nadie"); ?></option>
	</select>
	<br/>	
    
    <?php echo elgg_echo("megaprofile:privacy:wall"); ?>
	<select name="params[wire_shows_beta]">
		<option value="all" <?php if($wire_shows_beta == "all" || empty($wire_shows_beta_enabled)) echo "selected='yes'"; ?>><?php echo elgg_echo("todos"); ?></option>
		<option value="friends"<?php if($wire_shows_beta == "friends") echo "selected='yes'"; ?>><?php echo elgg_echo("amigos"); ?></option>
		<option value="none"<?php if($wire_shows_beta == "none") echo "selected='yes'"; ?>><?php echo elgg_echo("nadie"); ?></option>
	</select>
	<br/>	