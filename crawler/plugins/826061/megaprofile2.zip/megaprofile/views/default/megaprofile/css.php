<?php
//megaprofile v1.0 css.php
//diseñado por www.floops.com.ar
//la red social argentina
//para la comunidad elgg.org       
?>

.widget_title { 
      
border-top:1px solid #d2d2d2;
background: #F2F2F2;
font-size: 12px;
font-weight: bold;
padding:4px;

}
.sidebarBox {
margin: 0px 0 22px 0;
padding: 4px 10px 10px 10px;
border-bottom: 1px solid #F2F2F2;
}


