<?php
/**
 * Elgg diagnostics language pack.
 * 
 * @package ElggDiagnostics
 * @author Saket Saurabh
 */

$english = array(
	'spellcheck:check' => 'Check Spelling',
);
				
add_translation("en", $english);
