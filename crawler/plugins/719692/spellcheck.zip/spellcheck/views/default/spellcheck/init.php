<?php
/**
 * Initialize the SpellChecker script
 */

elgg_load_js('spellcheck');