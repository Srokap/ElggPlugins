<?php

add_translation('en', array(
	'object:plugin:google:site_verification_code:label' => "Google Webmaster Tools site verification code",
	'object:plugin:google:tracking_code:label' => "Google Analytics tracking code",
	'object:plugin:google:tracking_domain:label' => "Google Analytics tracking domain",
));