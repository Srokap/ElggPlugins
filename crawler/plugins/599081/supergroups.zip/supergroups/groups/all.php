<?php
	/**
	 * Elgg groups plugin
	 * 
	 * @package ElggGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2010
	 * @link http://elgg.com/
	 */

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
  	global $CONFIG;
	$limit = get_input("limit", 10);
	$offset = get_input("offset", 0);
	$tag = get_input("tag");
	$filter = get_input("filter");
	if (!$filter) {
		// active discussions is the default
		$filter = "active";
	}
	
	
	// Get objects
	$context = get_context();
	$supertype = getsupertype();

	
	
	
	//elgg_list_entities ()
	set_context('search');
	if ($tag != "") {
		$filter = 'search';
		// groups plugin saves tags as "interests" - see groups_fields_setup() in start.php
	
		$objects = list_entities_from_metadata_supergroups('interests',$tag,'group',"","", $limit, false, false, true, false,$supertype);
	} else {
		switch($filter){
			case "newest":
			$objects = elgg_list_entities_supergroup(array('types' => 'group', 'owner_guid' => 0, 'limit' => $limit, 'offset' => $offset, 'full_view' => false,'supertype'=>$supertype));
			break;
			
			case "pop":
			$objects =list_entities_by_relationship_count_supergroups('member', true, "", "", 0, $limit, false,'','',$supertype);
			//elgg_view_entity_list( elgg_get_entities_from_relationship(array('relationship'=>'member','types' => 'group','metadata_names'=>'supertype','metadata_values'=>$supertype,'group','limit' => $limit,'offset'=>$offset)),'','','',false);
			break;
			
			case "active":
			case 'default':			
			$objects =list_entities_from_annotations_supergroups("object", "groupforumtopic", "group_topic_post", "", 40, 0, 0, false, true,false,$supertype);			    
			break;
		}
	}
	


	//get a group count

	$allgroups = elgg_get_entities(array('types' => 'group', 'limit' => 10, 'count' => False));
	
		$i=0;
		
		
		if ($supertype != "All"){
		foreach ($allgroups as $check){
		$dump= get_metadata_byname($check['guid'],'supertype');
		
		if ($dump ['value']!= $supertype)
		{
			unset($allgroups [$i]);
		}
		$i++;
		}
		}
	
	$group_count = count($allgroups);
	
	//find groups
	$area1 = elgg_view("groups/find");
	
	//menu options

	$area1 .= elgg_view("groups/side_menu");
	
	//featured groups
	/**
	 * this needs work
	 * @TODO make featured groups supertypes
	 */
	$featured_groups = elgg_get_entities_from_metadata(array('metadata_name' => 'featured_group', 'metadata_value' => 'yes', 'types' => 'group', 'limit' => 10));
	
	$i=0;
		
		
		if ($supertype != "All"){
		foreach ($featured_groups as $check){
		$dump= get_metadata_byname($check['guid'],'supertype');
		
		if ($dump ['value']!= $supertype)
		{
			unset($featured_groups [$i]);
		}
		$i++;
		}
		}
	
	
	$area1 .= elgg_view("groups/featured", array("featured" => $featured_groups));
		
		
	set_context($context);
	
	$title = sprintf(elgg_echo("groups:all"),page_owner_entity()->name);
	$area2 = elgg_view_title($title);
	$area2 .= elgg_view('groups/contentwrapper', array('body' => elgg_view("groups/group_sort_menu", array("count" => $group_count, "filter" => $filter)) . $objects));
	$body = elgg_view_layout('sidebar_boxes',$area1, $area2);
	
	// Finally draw the page
	page_draw($title, $body);



?>