<?php
	/**
	 * Elgg groups plugin language pack
	 *
	 * @package ElggGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2010
	 * @link http://elgg.com/
	 */
	Global $CONFIG;
	$supertype=getsupertype();
	if (!empty($supertype)){
		
	switch($supertype){
		
		/** Language support is decided by switching case. 
		 * 
		 *  To create a case for your specific supergroup, copy/paste the next three lines
		 *  Make sure to paste each case before the default
		 *  
		 */
		case 'EVUAS Support': // this needs to changed to an actual supergroup name set in groups settings in the admin panel
			include($CONFIG->pluginspath . "groups/languages/en/Evuas_Support.php");//the php file needs to reflect the appropriate file as well
			break;
		
		//This is the default Groups language file	
		default:

		include($CONFIG->pluginspath . "groups/languages/en/en.php");
		break;
	}
	}
	else {
		include($CONFIG->pluginspath . "groups/languages/en/en.php");
	}
	add_translation("en",$english);
?>
