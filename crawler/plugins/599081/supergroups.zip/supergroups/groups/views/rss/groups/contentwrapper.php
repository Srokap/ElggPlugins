<?php

	echo $vars['body'];

?>