<?php
	$hidden_groups = $vars['entity']->hidden_groups;
	if (!$hidden_groups) $hidden_groups = 'no';
	
	$supergroups = $vars['entity']->supergroups;
	if (!$supergroups) $supergroups = 'Groups';
	
	$subgroups = $vars['entity']->subgroups;
	if (!$subgroups) $subgroups = 'no';
?>	
<p>
	<?php echo elgg_echo('groups:allowhiddengroups'); ?>
	
	<?php
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[hidden_groups]',
			'options_values' => array(
				'no' => elgg_echo('option:no'),
				'yes' => elgg_echo('option:yes')
			),
			'value' => $hidden_groups
		));
	?>
	</p>
	<br/>
	<?php echo elgg_echo('groups:groupsupertypes'); ?>
<p> <?php
	echo elgg_view('input/tags',array('value' => $supergroups,
									  'internalname' =>'params[supergroups]')); ?>
</p>
<br/>
<p>
<?php echo elgg_echo('Sub Group Menu On?'); ?>
 <?php
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[subgroups]',
			'options_values' => array(
				'no' => elgg_echo('option:no'),
				'yes' => elgg_echo('option:yes')
			),
			'value' => $subgroups
		));
	?>
</p>

