<?php
    echo elgg_view(
                'graphics/icon', array(
                'entity' => $vars['entity'],
                'size' => 'small',
            )
        );
?>