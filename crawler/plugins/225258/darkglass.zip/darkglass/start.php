<?php

    /**
     * darkglass theme
     **/
     
     /**
	 * Initialise the theme 
	 *
	 */
	function blueglass_init(){
	
    }
	
	// Initialise log browser
	register_elgg_event_handler('init','system','darkglass_init');
	
?>