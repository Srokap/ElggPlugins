<?php	
	
	/* Initialise the theme */
	function beauty_init(){
	
	}
	
	// Initialise log browser
	register_elgg_event_handler('init','system','beauty_init');
	
?>