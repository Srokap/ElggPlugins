
/* Styles for icon in topbar */
#elgg_topbar_container_left a.chat_open,
#elgg_topbar_container_left a.chat_open_query {
  padding-left: 18px;
  background: no-repeat left;
  margin: 0;
}

#elgg_topbar_container_left a.chat_open {
  background-image: url(<?php echo $vars['url']; ?>mod/pfchat/chat_open.png);
}

#elgg_topbar_container_left a.chat_open_query {
  background-image: url(<?php echo $vars['url']; ?>mod/pfchat/chat_open_query.png);
}
