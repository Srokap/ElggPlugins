/**
 * Open the pfchat in a popup window
 */
function chat_open(url) {
  window.open(url, "pfchat", "width=580,height=630,resizable=yes");
  //return false;
}
