<?php

	$english = array(
        /**
         * Misc
         */
            'pfchat:open' => 'Open pfchat'
	
	);
					
	add_translation("en", $english);

?>
