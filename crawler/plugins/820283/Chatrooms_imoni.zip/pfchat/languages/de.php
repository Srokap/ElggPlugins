<?php

	$deutsch = array(
	
        /**
         * Misc
         */
            'pfchat:open' => 'pfchat &ouml;ffnen'
	
	);
					
	add_translation("de", $deutsch);

?>
