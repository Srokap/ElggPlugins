<?php

/**
 * 
 * longtext field variation
 * 
 * Displays a large amount of text, with new lines converted to line breaks
 *
 * This version also substitutes embed tags for
 * video sharing websites using code from the embedvideo plugin.
 *
 * @author Brian Jorgensen (brian@moosetrout.com)
 * @copyright 2010 Brian Jorgensen
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
  */


require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/lib/au_longtext_video_filter.php');

// this is how the ususal input/longtext view works:
//echo autop(parse_urls(filter_tags($vars['value'])));

echo autop(au_parse_embed_urls(filter_tags($vars['value'])));