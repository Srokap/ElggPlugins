<?php

/**
 * Longtext filter plugin usersettings
 * 
 * @author Brian Jorgensen (brian@moosetrout.com)
 * @copyright 2010 Brian Jorgensen
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
  */

global $CONFIG;

$dependency_url = $CONFIG->wwwroot . 'mod/au_longtext_video_filter/dependency_test.php';
echo('<p>');
echo('<a href="' . $dependency_url . '">' . elgg_echo('au_longtext_video_filter:dep_test_title') . '</a>');
echo('</p>');
echo("<hr />");
?>