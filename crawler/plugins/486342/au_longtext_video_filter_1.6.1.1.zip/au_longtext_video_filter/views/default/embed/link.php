<a class='help_link' href='#youtube_help' rel='facebox'><?php echo elgg_echo('au_longtext_video_filter:helplink') ?></a><a class="embed_media" href="<?php echo $vars['url'] . 'pg/embed/media'; ?>?internalname=<?php echo $vars['internalname']; ?>" rel="facebox"><?php echo elgg_echo('embed:title'); ?></a><br />

<div id="youtube_help" style="display:none;">
  <h2><?php echo elgg_echo('au_longtext_video_filter:helplink') ?></h2>
  <p><?php echo elgg_echo('au_longtext_video_filter:helpcontent') ?></p>
</div>