<?php
/**
 * au_longtext_video_filter css file
 * 
 * @author Brian Jorgensen (brian@moosetrout.com)
 * @copyright 2010 Brian Jorgensen
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
  */
?>
a.help_link {
	font-weight:normal;
}