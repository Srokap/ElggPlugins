Captcha Plugin for Elgg 1.8
Latest Version: 1.8.0
Released: 2012-07-07
Contact: iionly@gmx.de
Website: https://github.com/iionly
License: GNU General Public License version 2
Copyright: (C) iionly 2012, (C) Curverider 2008-2012


Provides captcha support (Requires the php_gd library).


Installation and configuration:

1. Copy the captcha plugin folder into you mod folder,
2. Enable the captcha plugin in the admin section of your site.

The captcha plugin also works with the walled-garden option of Elgg core enabled. If you use the alternative walled-garden plugin loginrequired released by me, you need to place the captcha plugin above the loginrequired plugin in the plugin list on your site.


Changelog:

1.8.0:

 - Upgraded for Elgg 1.8 (by iionly).
