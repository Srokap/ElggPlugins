<div id="two_column_right_river_boxes">
    <?php if (isset($vars['area3'])) echo $vars['area3']; ?>
</div>
<div id="two_column_left_river_boxes">
	<?php if (isset($vars['area1'])) echo $vars['area1']; ?>
</div>
<div id="two_column_left_river_maincontent_boxes">
<?php if (isset($vars['area2'])) echo $vars['area2']; ?>
</div>

