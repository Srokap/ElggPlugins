<script type="text/javascript">$(document).ready(function(){$('a.toggletext').click(function () {$(".toggletext_box").slideToggle("fast");$("#minim").slideToggle("fast");return false;});if( $('#d2').is(':visible') ) {$("#d2").addClass("loadingit");$("#d2").load("<?php echo $vars['url']; ?>mod/riverdashboard/ajax/event_calendar.php?randval="+ Math.random(),function(){$('#d2').removeClass("loadingit");});}if( $('#d3').is(':visible') ) {$("#d3").addClass("loadingit");$("#d3").load("<?php echo $vars['url']; ?>mod/riverdashboard/ajax/videolist.php?randval="+ Math.random(),function(){$('#d3').removeClass("loadingit");});}if( $('#d4').is(':visible') ) {$("#d4").addClass("loadingit");$("#d4").load("<?php echo $vars['url']; ?>mod/riverdashboard/ajax/edal.php?randval="+ Math.random(),function(){$('#d4').removeClass("loadingit");});}if( $('#d5').is(':visible') ) {$("#d5").addClass("loadingit");$("#d5").load("<?php echo $vars['url']; ?>mod/riverdashboard/ajax/termekb_rate.php?randval="+ Math.random(),function(){$('#d5').removeClass("loadingit");});}if( $('#d6').is(':visible') ) {$("#d6").addClass("loadingit");$("#d6").load("<?php echo $vars['url']; ?>mod/riverdashboard/ajax/pages_top.php?randval="+ Math.random(),function(){$('#d6').removeClass("loadingit");});}if( $('#d7').is(':visible') ) {$("#d7").addClass("loadingit");$("#d7").load("<?php echo $vars['url']; ?>mod/riverdashboard/ajax/termekb_asc.php?randval="+ Math.random(),function(){$('#d7').removeClass("loadingit");});}if( $('#d8').is(':visible') ) {$("#d8").addClass("loadingit");$("#d8").load("<?php echo $vars['url']; ?>mod/riverdashboard/ajax/termekb_desc.php?randval="+ Math.random(),function(){$('#d8').removeClass("loadingit");});}});</script>
<?php
// sitemessage
	$site_message = get_entities("object", "sitemessage", 0, "", 1);
	foreach($site_message as $mes){
		$message = $mes->description;
		if(!$message){$message = '';}
		$dateStamp = friendly_time($mes->time_created);
		$delete = elgg_view("output/confirmlink",array(
															'href' => $vars['url'] . "action/riverdashboard/delete?message=" . $mes->guid,
															'text' => elgg_echo('delete'),
															'confirm' => elgg_echo('deleteconfirm'),
														));
	}
?>
	<div class="onlinemembers welcomemessage">
<?php if($site_message){ ?>
	<?php
		echo "<div style='padding:10px;'>";
		echo "<h3>" . elgg_echo("sitemessages:announcements") . "</h3>";
		echo "<p><small>" . elgg_echo("sitemessages:posted") . ": " . $dateStamp;
		if(isadminloggedin())
			echo " " . $delete . " ";	
		echo "<div style='padding-top:2px;width:40%;border-bottom:1px solid #DFD0A7;'></div></small></p>";
		if ( strlen ($message) >= 60){
				$messageB = substr_replace($message, '...', 57);
				echo "<div id='minim'>".$messageB."</div>";
				echo "<p><a class='toggletext' style='border-bottom:1px solid #DFD0A7;'><b>Megjelenítés</b></a></p>";
				echo "<div class='toggletext_box' style='display:none;'>" . $message . "</div>";
			}else{
				echo "<div id='site_message'>" . $message . "</div>";
			}
		echo "</div>";
		if(isadminloggedin()){
			$link = elgg_echo("sitemessages:add");
			$input_area = elgg_view('input/plaintext', array('internalname' => 'sitemessage', 'value' => ''));
			$submit_input = elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('save')));
			$form_body = <<<EOT
			<p><a class="collapsibleboxlink">{$link}</a></p>
			<div class="collapsible_box">
				{$input_area}<br />{$submit_input}
			</div>
EOT;
?>
			<?php echo elgg_view('input/form', array('action' => "{$vars['url']}action/riverdashboard/add", 'body' => $form_body)); 
		}
		
	}else{
		if(isadminloggedin()){
			$link = elgg_echo("sitemessages:add");
			$input_area = elgg_view('input/plaintext', array('internalname' => 'sitemessage', 'value' => ''));
			$submit_input = elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('save')));
			$form_body = <<<EOT
			<p><a class="collapsibleboxlink">{$link}</a></p>
			<div class="collapsible_box">
				{$input_area}<br />{$submit_input}
			</div>
EOT;
?>
<?php
			echo elgg_view('input/form', array('action' => "{$vars['url']}action/riverdashboard/add", 'body' => $form_body));
		}
	}
?>
</div>
<?php /* Events */ 
if(is_plugin_enabled("event_calendar")){ ?>
<div id="d2" class="onlinemembers welcomemessage" style="display:none;padding:5px 0 5px 0;"></div>
<?php }

/* Videos */
if(is_plugin_enabled("videolist")){ ?>
<div id="d3" class="onlinemembers welcomemessage" style="display:none;padding:5px 0 5px 0;"></div>
<?php }

/* e-Song albums */
if(is_plugin_enabled("audio")){ ?>
<div id="d4" class="onlinemembers welcomemessage" style="display:none;padding:5px 0 5px 0;"></div>
<?php }

/* Ads */
if(is_plugin_enabled("ad")){ ?>
<div id="d5" class="onlinemembers welcomemessage" style="display:none;padding:5px 0 5px 0;"></div>
<?php }

/* Pages */
if(is_plugin_enabled("pages")){ ?>
<div id="d6" class="onlinemembers welcomemessage" style="display:none;padding:5px 0 5px 0;"></div>
<?php }

/* Ads asc */
if(is_plugin_enabled("ad")){ ?>
<div id="d7" class="onlinemembers welcomemessage" style="display:none;padding:5px 0 5px 0;"></div>
<?php }

/* Ads desc */
if(is_plugin_enabled("ad")){ ?>
<div id="d8" class="onlinemembers welcomemessage" style="display:none;padding:5px 0 5px 0;"></div>
<?php } ?>

<script type="text/javascript">
divs = ['d2','d3','d4','d5','d6','d7','d8'];function showDiv() {var randomDiv = divs[Math.floor(Math.random()*divs.length)];var div = document.getElementById(randomDiv).style.display = 'block';}
window.onload = showDiv();
</script>