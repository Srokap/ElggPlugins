<?php
/*
?>
<div class="onlinemembers">
<div class="sidebarBox">
<div class="membersWrapper">

<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="221" height="400">
  <param name="movie" value="tesztmovie.swf" />
  <param name="quality" value="high" />
  <param name="allowScriptAccess" value="always" />
  <param name="wmode" value="transparent">
     <embed src="http://www.3liteclub.hu/adverts/tesztmovie.swf"
      quality="high"
      type="application/x-shockwave-flash"
      WMODE="transparent"
      width="221"
      height="400"
      pluginspage="http://www.macromedia.com/go/getflashplayer"
      allowScriptAccess="always" />
</object>

</div>
</div>
</div>
<?php
*/
?>