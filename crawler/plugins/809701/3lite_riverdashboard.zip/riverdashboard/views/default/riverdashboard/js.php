<?php
global $CONFIG;
$offset = (int) get_input('offset');
$offset = $offset+10;
	$Bcase = $_COOKIE["DTselect"];
	if($Bcase == "all"){ $subject_guid = 0; $relationship_type = '';
	}else if($Bcase == "friend"){ $subject_guid = $_SESSION['user']->guid; $relationship_type = 'friend';
	}else if($Bcase == "mine"){ $subject_guid = $_SESSION['user']->guid; $relationship_type = '';
	}
?>
<?php /* by me works just with hidden input... hmm... why?*/ ?>
<input type="hidden" id="subtype" value="<?php echo $vars['subtype']; ?>" />

<script type="text/javascript">
	$(function() {
		$
$("div.river_pagination").empty();
$("div.river_pagination").html('<div id="load_before" style="position:absolute;margin-top:-500px;height:1px;"></div><div id="advanced_river_more" class="" style="height:30px;overflow:hidden;"></div>');		
function lastPostFunc(){
var display = $.cookie('DTselect');
if(display == 'all'){var subject_guid = '0';var relationship_type = '';}
if(display == 'friend'){var subject_guid = '<?php echo $_SESSION['user']->guid; ?>';var relationship_type = 'friend';}
if(display == 'mine'){var subject_guid = '<?php echo $_SESSION['user']->guid; ?>';var relationship_type = '';}
if(!display){var subject_guid = '<?php echo $_SESSION['user']->guid; ?>';var relationship_type = 'friend';var display = 'frien';}
$('div.river_pagination').addClass('loadingR');var selcont = $('select#content').val();var inpcont = $('#subtype').val();if(selcont == 'all'){var selcontz = inpcont;}else{var selcontz = selcont;}
$.post("<?php echo $vars['url']; ?>mod/riverdashboard/?type=<?php echo $vars['type']; ?>&offset=<?php echo $offset; ?>&display="+display+"&content="+selcontz+"&callback=true&scroller=true&subject_guid="+subject_guid+"&relationship_type="+relationship_type,function(data){if (data != "") {$(".river_item:last").after(data);}$('div.river_pagination').removeClass('loadingR');});
};
$('#advanced_river_more').click(function(){lastPostFunc();});
$(window).unbind('scroll.advanced_river').bind('scroll.advanced_river', function(){
if(isScrolledIntoView($("#load_before:visible"))){
if( $('div.river_pagination').hasClass('loadingR') ){ }else{$("#advanced_river_more").click();}}});
function isScrolledIntoView(elem){var docViewTop = $(window).scrollTop();var docViewBottom = docViewTop + $(window).height();var elemTop = $(elem).offset().top;var elemBottom = elemTop + $(elem).height();return ((elemBottom >= docViewTop) && (elemTop <= docViewBottom));}
	});
</script>