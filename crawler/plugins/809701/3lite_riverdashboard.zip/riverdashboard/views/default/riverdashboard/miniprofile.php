<?php 
?>
<div id="dashboard1">

<div id="river_avatar"> <!-- displayes user's avatar -->
    <img class="river_avatar" src="<?php echo get_loggedin_user()->getIcon('large'); ?>" alt="User avatar" />
</div> <!-- /river_avatar -->

<div id="lastloggedin">
	<?php 
		$name = '';
		if (isloggedin()) {
			$name = get_loggedin_user()->name;
			echo sprintf(elgg_echo('welcome:user'), $name) . "!<br />";
		}
    ?>
</div> <!-- /lastloggedin -->

<div id="dashboard_navigation">
	<ul>
        <li><a href="<?php echo $vars['url']; ?>pg/profile/<?php echo $_SESSION['user']->username; ?>/edit/">Edit details</a></li>
        <li><a href="<?php echo $vars['url']; ?>pg/profile/<?php echo $_SESSION['user']->username; ?>/editicon/">Change image</a></li>
        <li><a href="<?php echo $vars['url']; ?>pg/settings/user/<?php echo $_SESSION['user']->username; ?>">Account settings</a></li>
    </ul>
    
    <ul>
    
    <?php	 
    gatekeeper();
    $num_messages = count_unread_messages();
    if($num_messages){
    	$num = $num_messages;
    }
    else {
    	$num = 0;
    }
    if($num == 0){
    ?>
    
    	<li><a href="<?php echo $vars['url']; ?>pg/messages/inbox/<?php echo $_SESSION['user']->username; ?>">Messages <span style="color:#FF0000">[0 new]</span></a></li>
    <?php }else{ ?>
    	<li><a href="<?php echo $vars['url']; ?>pg/messages/inbox/<?php echo $_SESSION['user']->username; ?>">New messages <span style="color:#FF0000">[<?php echo $num; ?> new]</span></a></li>
    <?php } ?>
     <?php if(is_plugin_enabled('friend_request')){ 
    gatekeeper();
    $user = get_loggedin_user();
    $count = get_entities_from_relationship('friendrequest', $user->guid, true, "", "", 0, "", 0, 0, true);
    if(empty($count)){
    ?>
        <li><a href="<?php echo $vars['url']; ?>pg/friends/<?php echo $_SESSION['user']->username; ?>"><?php echo elgg_echo('friends') ?> <span style="color:#FF0000">[0 new]</span></a></li>
    <?php }else { ?>
        <li><a href="<?php echo $vars['url']; ?>pg/friend_request/"><?php echo elgg_echo('friends') ?> <span style="color:#FF0000">[<?php echo $count ?> new]</span></a></li>
    <?php }
	} else { ?>
    <li><a href="<?php echo $vars['url']; ?>pg/friends/<?php echo $_SESSION['user']->username; ?>"><?php echo elgg_echo('friends') ?></a></li>
	<?php } ?>
    </ul>
</div> <!-- /dashboard_navigation -->
</div> <!-- /dasboard1 -->