<?php
?>
.sidebarBox{-webkit-border-radius:6px;-moz-border-radius:6px;-khtml-border-radius:6px;border-radius:6px;color:#000;font-weight:bold;background:#FFFFFF;}
.onlinemembers{height:auto;-webkit-border-bottom-right-radius:8px;-webkit-border-bottom-left-radius:8px;-moz-border-radius-bottomleft:8px;-moz-border-radius-bottomright:8px;margin:0 0 20px;background:#FFFFFF;border-left:2px solid #E8E0CE;border-right:2px solid #E8E0CE;border-bottom:2px solid #E8E0CE;padding:2px;}
.ames{border:1px solid #D8AD50;-webkit-border-radius:6px;-moz-border-radius:6px;padding:5px;background:white;}
.amestxt{color:#E0C790;}
a.viewall{font-weight:bold;}
.sidebarBox #thewire_sidebarInputBox{width:178px;}
.sidebarBox .last_wirepost{margin:20px 0;}
.sidebarBox .last_wirepost .thewire-singlepage{margin:0;}
.sidebarBox .last_wirepost .thewire-singlepage .thewire_options{display:none;}
.sidebarBox .last_wirepost .thewire-singlepage .note_date{line-height:1em;width:142px;padding:3px 0 0;}
.sidebarBox .last_wirepost .thewire-singlepage .note_body{color:#666666;line-height:1.2em;}
.sidebarBox .last_wirepost .thewire-singlepage .thewire-post{background:130px bottom;}
.sidebarBox .thewire_characters_remaining{float:right;}
.sidebarBox input.thewire_characters_remaining_field{background:#dedede;}
.sidebarBox input.thewire_characters_remaining_field:focus{border:none;background:#dedede;}
.sidebarBox input#thewire_submit_button{height:auto;margin:2px 0 0;padding:2px 2px 1px;}
.sidebarBox .membersWrapper{margin-bottom:20px;-webkit-border-radius:5px;-moz-border-radius:5px;padding:7px;background:#EFEBE0;}
.membersWrapper h3{font-size:13px;font-weight:bold;border-bottom:8px;}
.sidebarBox .membersWrapper .recentMember{float:left;margin:2px;}
.sidebarBox .membersWrapper .recentMember .usericon img{width:25px;height:25px;}
.sidebarBox .membersWrapper br{height:0;line-height:0;}
.welcomemessage{background:white;}
.riverdashboard_filtermenu{margin:10px 0;}
.river_pagination .forward,.river_pagination .back{display:block;float:left;border:1px solid #9E7540;color:#9E7540;text-align:center;font-size:12px;font-weight:normal;cursor:pointer;-webkit-border-radius:4px;-moz-border-radius:4px;margin:0 6px 0 0;padding:0 4px 1px;}
.river_pagination .forward:hover,.river_pagination .back:hover{color:white;text-decoration:none;border:1px solid #9E7540;background:#9E7540;}
.river_pagination .back{margin:0 20px 0 0;}
* html .river_pagination{margin-top:17px;}
:first-child+html .river_pagination{margin-top:17px;}
.collapsable_box_content .river_item p{color:#333333;}
.river_content_display_admin{position:relative;border:3px solid #AF8F62;color:#FFFFFF;font-weight:bold;font-size:90%;-moz-border-radius:8px;-webkit-border-radius:8px;border-radius:8px;margin:4px 0 2px 30px;padding:0 10px 10px;background:#6F4C1B;}
.river_item{border-bottom:2px solid #EFEBE0;padding:10px 0;}
.collapsable_box_content .content_area_user_title h2{font-size:1.25em;line-height:1.2em;color:#4690d6;margin:0;padding:0 0 2px;}
.river_content img{margin:2px 0 2px 20px;}
.river_content_display{border-left:1px solid #ddd;font-size:90%;margin:4px 0 2px 40px;padding:2px 10px 0;}
.river_content_display p{margin:0;padding:0;}
.following_icon{width:20px;height:40px;margin:0 2px;background:url("<?php echo $vars['url']; ?>mod/riverdashboard/graphics/follow_icon.png") no-repeat left top;}
.river_content_display div.usericon a.icon img{width:40px;height:40px;}
textarea#thewire_large-textarea{width:463px;height:40px;font-family:Arial, 'Trebuchet MS','Lucida Grande', sans-serif;font-size:100%;color:#666666;padding:6px;}
* html textarea#thewire_large-textarea{width:463px;}
#dashboard1{margin-bottom:20px;}
#river_avatar{text-align:center;margin-bottom:20px;}
img.river_avatar{border:1px solid #cccccc;text-align:center;padding:3px;}
#lastloggedin{color:#777777;font-size:12px;font-weight:bold;text-align:center;}
#dashboard_navigation{margin-top:20px;width:100%;font-size:12px;}
#dashboard_navigation ul{margin:0 0 15px;padding:0;}
#dashboard_navigation ul li{list-style:none;float:none;font-weight:bold;border-bottom:1px solid #cccccc;text-decoration:none;padding:5px;}
#dashboard_navigation ul li:hover{background:#E5F6FF;}
#dashboard_navigation ul li a{font-weight:bold;text-decoration:none;}
.riverwire{margin:-18px 0 0 30px;padding:15px 15px 15px 30px;background:url("<?php echo $vars['url']; ?>mod/riverdashboard/graphics/riverwire.gif") no-repeat top left #fff7d3;}
#two_column_right_river_boxes{width:210px;min-height:360px;float:right;margin:0 0 5px 0;padding:0;}
#two_column_left_river_maincontent_boxes{width:538px;float:left;-webkit-border-radius:6px;-moz-border-radius:6px;-khtml-border-radius:6px;border-radius:6px;margin:0 0 5px 5px;padding:10px 0 5px;background:white;}
#two_column_left_river_boxes{width:200px;min-height:360px;float:left;margin:0 0 20px;padding:0;}
.search_listingz{padding:2px;border:2px solid #FFFFFF;border-top:5px solid #FFFFFF;border-bottom:5px solid #FFFFFF;-webkit-border-radius:8px;-moz-border-radius:8px;border-radius:8px;}.loadingit{height:100px;background: #FFFFFF url("<?php echo $vars['url']; ?>_graphics/ajax_loader.gif") no-repeat center 30px;}
.loadingZ{height:200px;background: #FFFFFF url("http://www.3liteclub.hu/_graphics/ajax_loader.gif") no-repeat center 30px;}
.loadingR{height:30px;background: #FFFFFF url("http://www.3liteclub.hu/_graphics/ajax_loader.gif") no-repeat center;}
#left_menu_dashboard{font-size:12px;	border-left:5px solid #FFFFFF;}
#left_menu_dashboard:hover{background:#E8E0CE;border-left:5px solid #683F04;}
.usermhref:hover {color:#683F04;}
#hiteles{text-align:center;position:relative;top:-5px;border-left:3px solid #EDDDB4;border-right:3px solid #EDDDB4;border-top:5px solid #EFEBE0;border-bottom:5px solid #EFEBE0;background: #EFEBE0;background: -moz-linear-gradient(left, #EFEBE0 0%, #EDDDB4 50%, #EDDDB4 50%, #EFEBE0 100%);background: -webkit-gradient(linear, left top, right top, color-stop(0%,#EFEBE0), color-stop(50%,#EDDDB4), color-stop(50%,#EDDDB4), color-stop(100%,#EFEBE0));filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#EFEBE0', endColorstr='#EFEBE0',GradientType=1 );}
#varea.active, #marea.active{background:#FFFFFF;border:0;padding:5px;-moz-border-radius:6px;-webkit-border-radius:6px;-khtml-border-radius:6px;border-radius:6px;}
#video.active, #message.active{background:#FFFFFF;border:0;}