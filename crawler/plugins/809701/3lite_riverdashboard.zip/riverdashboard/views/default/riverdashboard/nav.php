<?php

	$contents = array();
	$contents['all'] = 'all';
	if (!empty($vars['config']->registered_entities)) {
		foreach ($vars['config']->registered_entities as $type => $ar) {
			foreach ($vars['config']->registered_entities[$type] as $object) {
				if (!empty($object )) {
					$keyname = 'item:'.$type.':'.$object;
				} else $keyname = 'item:'.$type; 
				$contents[$keyname] = "{$type},{$object}";
			}
		}
	}
$Bcase = $_COOKIE["DTselect"];
	if($Bcase == "all"){ $case1 = 'friend'; $case2 = 'mine'; $case3 = 'default';
	}else if($Bcase == "friend"){ $case1 = 'default'; $case2 = 'mine'; $case3 = 'all';
	}else if($Bcase == "mine"){ $case1 = 'friend'; $case2 = 'default'; $case3 = 'all';
	}
	$allselect = ''; $friendsselect = ''; $mineselect = '';
if($vars['orient'] == "default"){
	switch($vars['orient']) { case $case1:	$friendsselect = 'class="selected"'; break; case $case2:	$mineselect = 'class="selected"'; break; case $case3:	$allselect = 'class="selected"'; break;
	}
}else{
	switch($vars['orient']) { case '':		$friendsselect = 'class="selected"'; break; case 'mine':	$mineselect = 'class="selected"'; break; case 'all':	$allselect = 'class="selected"'; break;
	}
}
?>
<div class="contentWrapper">
	<div id="elgg_horizontal_tabbed_nav">
		<ul>
			<li id="uli1" <?php echo $allselect; ?> >
<a onclick="javascript:$('.river_item_list').empty().addClass('loadingZ');
$('#river_container').load('<?php echo $vars['url']; ?>mod/riverdashboard/?type=<?php echo $vars['type']; ?>&display=all&content=<?php echo $vars['subtype']; ?>&callback=true');
$.cookie('DTselect', 'all', { expires: 1 });$('#river_container').load(function(){$('.river_item_list').removeClass('loadingZ');}); return false;" href="?type=<?php echo $vars['type']; ?>&display=all&content=<?php echo $vars['subtype']; ?>">
<?php echo elgg_echo('all'); ?></a></li>
			<li id="uli2" <?php echo $friendsselect; ?> >
<a onclick="javascript:$('.river_item_list').empty().addClass('loadingZ');
$('#river_container').load('<?php echo $vars['url']; ?>mod/riverdashboard/?type=<?php echo $vars['type']; ?>&content=<?php echo $vars['subtype']; ?>&callback=true');
$.cookie('DTselect', 'friend', { expires: 1 });$('#river_container').load(function(){$('.river_item_list').removeClass('loadingZ');}); return false;" href="?type=<?php echo $vars['type']; ?>&display=friend&content=<?php echo $vars['subtype']; ?>">
<?php echo elgg_echo('friends'); ?></a></li>
			<li id="uli3" <?php echo $mineselect; ?> >
<a onclick="javascript:$('.river_item_list').empty().addClass('loadingZ');
$('#river_container').load('<?php echo $vars['url']; ?>mod/riverdashboard/?type=<?php echo $vars['type']; ?>&display=mine&content=<?php echo $vars['subtype']; ?>&callback=true');
$.cookie('DTselect', 'mine', { expires: 1 });$('#river_container').load(function(){$('.river_item_list').removeClass('loadingZ');}); return false;" href="?type=<?php echo $vars['type']; ?>&display=mine&content=<?php echo $vars['subtype']; ?>">
<?php echo elgg_echo('mine'); ?></a></li>
		</ul>
	</div
	
	<div class="riverdashboard_filtermenu">
		<select name="content" id="content" onchange="javascript:$('.river_item_list').empty().addClass('loadingZ');
		$('#river_container').load('<?php echo $vars['url']; ?>mod/riverdashboard/?callback=true&display='+$('input#display').val() + '&content=' + $('select#content').val());
		$('#river_container').load(function(){$('.river_item_list').removeClass('loadingZ');}); return false;">
			<?php
				foreach($contents as $label => $content) {
					if ( ("{$vars['type']},{$vars['subtype']}" == $content) || (empty($vars['subtype']) && $content == 'all') ) {
						$selected = 'selected="selected"';
					} else { 
						$selected = '';
					}
					
					// No private and No Defect!
					if( $content != "object,mbook"){
						if( $content != "object,userpoint"){
							if( $content != "object,bill"){
								if( $content != "object,bill2"){
									if( $content != "object,notification"){
										if( $content != "object,answer"){
						echo "<option value=\"{$content}\" {$selected}>".elgg_echo($label)."</option>";
					}}}}}}
					
				}
			?>
		</select>
		<input type="hidden" name="display" id="display" value="<?php if($Bcase){echo $Bcase;}else{echo htmlentities($vars['orient']);} ?>" />
	</div>