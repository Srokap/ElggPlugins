<?php
// HITELESÍTETT DÁTUM //

	$profile_user = $_SESSION['user'];
	if($profile_user->protyp){$spotypro = $profile_user->protyp;}else{$spotypro = '';}
	if($profile_user->eDalprotyp){$edaltype = $profile_user->eDalprotyp;}else{$edaltype = '';}
	if($profile_user->expiration){$spotype = $profile_user->expiration;}else{$spotype = '';}
// Profile date //
// expiredate //
if($spotype){
		$bills = get_user_objects($_SESSION['guid'], "bill", 1, 0);
		if($bills){
			foreach($bills as $bill) {
				$timed = $bill->idoszakig;
				$cango = $bill->statusz;
				$timer = explode(".", $timed);
		    	$timerY = $timer[0]; // Year
		    	$timerM = $timer[1]; //Month
		    	$timerD = $timer[2]; //Day
		    	$itis = mktime(0, 0, 0, $timerM, $timerD, $timerY) ;
			}
		}
		
		$billslast = get_user_objects($_SESSION['guid'], "bill", 2, 0);
		if($billslast){
			foreach($billslast as $billt) {
				$timedt = $billt->idoszakig;
				$cangot = $billt->statusz;
				$timert = explode(".", $timedt);
		    	$timertY = $timert[0]; // Year
		    	$timertM = $timert[1]; //Month
		    	$timertD = $timert[2]; //Day
		    	$itist = mktime(0, 0, 0, $timertM, $timertD, $timertY) ;
			}
		}
		if($itist === $itis){$itist = "";}
		
		$today = time () ;
		
		if($cango == "Fizetve"){
				
				if($spotype > $today && $itis < $today){
				$difference =($spotype-$today+86400);
				}else{
				$difference =($itis-$today+86400);
				}
				$days =(int) ($difference/86400);
				if($spotype > $today && $itis < $today){
					$testime = date("Y.m.d", $spotype);
				}else{
					$testime = $timed;
				}
		}else{ //if($cango ...
				
				if($spotype > $today && $itist < "0"){
				$differencet =($spotype-$today+86400);
				}else{
				$differencet =($itist-$today+86400);
				}
				$days =(int) ($differencet/86400);
				if($spotype > $today && $itist < "0"){
					$testime = date("Y.m.d", $spotype);
				}else{
					$testime = $timedt;
				}
		} // else ... $cango
} // if $spotype
?>

      <div style="background:white;padding:2px;">
      <p align="center"><a href="<?php echo $vars['url']; ?>pg/profile/<?php echo $_SESSION['user']->username; ?>"><img width="182px" src="<?php echo $_SESSION['user']->getIcon('large'); ?>" style="border: 1px solid #E8E0CE;padding:3px;" /></a></p>
      
      <?php
      if($days < "0"){
	      echo "<a><div>";
      }else{
      echo "<a href=\"".$vars['url']."pg/bill/".$_SESSION['user']->username."\"><div id='hiteles'><span style='font-weight:bold;'>Kereskedői Profil</span><br>Érvényesség: ".$testime."<br>";   
  	  }
      if($days < "15" && $days > "0"){
      echo "<span style='color:#FF0000;'>(Még ".$days." nap)</span></div></a>";
	  } else if($days == "0"){
      echo "<span style='color:#FF0000;'>(Utolsó nap)</span></div></a>";
	  } else {
		echo "</div></a>";  
	  }
	  

	  ?>
      <div style="padding-bottom: 20px;">
 
      
      <a class="usermhref" href="<?php echo $vars['url']; ?>mod/profile/edit.php?username=<?php echo $_SESSION['user']->username; ?>"><div style="padding: 5px 10px 5px 3px; margin-bottom: 5px;  border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><?php echo elgg_echo("river:menu:edit_prof"); ?></h3></div></a>
      <a class="usermhref" href="<?php echo $vars['url']; ?>pg/photos/owned/<?php echo $_SESSION['user']->username; ?>"><div style="padding: 5px 10px 5px 3px; margin-bottom: 5px;  border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><?php echo elgg_echo("river:menu:photos"); ?></h3></div></a>
      <?php if(is_plugin_enabled('videolist')){ ?>
      <a class="usermhref" href="<?php echo $vars['url']; ?>pg/videolist/owned/<?php echo $_SESSION['user']->username; ?>"><div style="padding: 5px 10px 5px 3px; margin-bottom: 5px;  border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><?php echo elgg_echo("river:menu:videos"); ?></h3></div></a>
      <?php } ?>
      <?php if(is_plugin_enabled('speed_mail')){ ?>
      <a class="usermhref" href="javascript:void(0)" onclick="Mail_Toggle();this.blur();"><div style="padding: 5px 10px 5px 3px; margin-bottom: 5px;  border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><?php echo elgg_echo("river:menu:smt_mailer"); ?></h3></div></a>
      <?php } ?>
      <a class="usermhref" href="<?php echo $vars['url']; ?>pg/blog/<?php echo $_SESSION['user']->username; ?>"><div style="padding: 5px 10px 5px 3px; margin-bottom: 5px;  border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><?php echo elgg_echo("river:menu:blog"); ?></h3></div></a>
<?php if ( $edaltype == 'e-Dal' ) { ?>
      <a class="usermhref" href="<?php echo $vars['url']; ?>pg/audio/<?php echo $_SESSION['user']->username; ?>"><div style="padding: 5px 10px 5px 3px; margin-bottom: 5px;  border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><?php echo elgg_echo("river:menu:my_esong"); ?></h3></div></a>
<?php }else{ ?>
	  <a class="usermhref" href="<?php echo $vars['url']; ?>mod/audio/everyone.php"><div style="padding: 5px 10px 5px 3px; margin-bottom: 5px;  border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><?php echo elgg_echo("river:menu:esong"); ?></h3></div></a>
<?php } ?>
<?php if ($spotypro == 'Hitelesített') { ?>
       <a class="usermhref" href="<?php echo $vars['url']; ?>pg/ad/<?php echo $_SESSION['user']->username; ?>?&search_viewtype=list"><div style="padding: 5px 10px 5px 3px; margin-bottom: 5px;  border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><?php echo elgg_echo("river:menu:my_ads"); ?></h3></div></a>
<?php }else{ ?>
       <a class="usermhref" href="<?php echo $vars['url']; ?>mod/ad/everyone.php?&search_viewtype=list"><div style="padding: 5px 10px 5px 3px; margin-bottom: 5px;  border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><?php echo elgg_echo("river:menu:ads"); ?></h3></div></a>
<?php } ?>
      </div>
</div><br><br>