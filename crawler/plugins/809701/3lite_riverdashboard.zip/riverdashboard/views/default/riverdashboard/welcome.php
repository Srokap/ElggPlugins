<?php ?>
<script>$(document).ready(function(){$("#marea").addClass("active");$("#message").addClass("active");$("#video").click(function(){$(this).addClass("active");$("#message").removeClass("active");$("#marea").slideUp(1).removeClass("active");$("#varea").slideDown(1).addClass("active");});$("#message").click(function(){$(this).addClass("active");$("#video").removeClass("active");$("#varea").slideUp(1).removeClass("active");$("#marea").slideDown(1).addClass("active");});});</script>
<div id="content_area_user_title">
<h2><?php echo elgg_echo('welcome')." ".$_SESSION['user']->name; ?></h2>
</div>&nbsp;<br>
<?php
		$wire_user = get_input('wire_username');
		if (!empty($wire_user)) { $msg = '@' . $wire_user . ' '; } else { $msg = ''; }
?>
<div class="post_to_wire">
<?php $display = '<span style="font-size: 14px;font-weight:bold;">'.elgg_echo("river:wire:title").': </span>'; ?>
<script>function textCounter(field,cntfield,maxlimit) {if (field.value.length > maxlimit) {field.value = field.value.substring(0, maxlimit);} else {cntfield.value = maxlimit - field.value.length;}}</script>
	<form action="<?php echo $vars['url']; ?>action/riverdashboard/wireadd" method="post" name="noteForm">
			<?php
				$display .= "<b><a id='message' style='margin-left:10px;padding:5px;' >".elgg_echo('river:wire:message')."</a>";
			if(is_plugin_enabled('embed_extender')){
				$display .= "&nbsp;<a id='video' style='margin-left:10px;padding:5px;' >".elgg_echo('river:wire:video')."</a></b>";
			}
			    $display .= "<div id='marea'>".elgg_echo('river:wire:message').":<br><textarea onkeyup=\"this.value = this.value.replace(/(http|https):\/\/[\S]+(\b|$)/gim, '').replace(/(www).[\S]+(\b|$)/gim, '')\" style='width:96%; height:30px;' name='note' value='' onKeyDown=\"textCounter(document.noteForm.note,document.noteForm.remLen1,140)\" onKeyUp=\"textCounter(document.noteForm.note,document.noteForm.remLen1,140)\" id=\"thewire_large-textarea\">{$msg}</textarea></div>";
			if(is_plugin_enabled('embed_extender')){
			    $display .= "<div id='varea' style='display:none;'>".elgg_echo('river:wire:video_url').": <font color='#999999'>Pl.: http://www.youtube.com/watch?v=SnbQGxNpM58</font><br>
			    <input type='text' style='width:96%;' name='notevid' onKeyDown=\"textCounter(document.noteForm.note,document.noteForm.remLen1,140)\" onKeyUp=\"textCounter(document.noteForm.note,document.noteForm.remLen1,140)\" />
			    <font color='#999999'>".elgg_echo('river:wire:video_supported')."</font>
			    </div>";
		    }
                $display .= "<div class='thewire_characters_remaining'><input readonly type=\"text\" name=\"remLen1\" size=\"3\" maxlength=\"3\" value=\"140\" class=\"thewire_characters_remaining_field\">";
                echo $display;
                echo elgg_echo("thewire:charleft") . "</div>";
				echo elgg_view('input/securitytoken');
			?>
			<input type="hidden" name="method" value="site" />
			<input type="submit" value="<?php echo elgg_echo('save'); ?>" />
	</form>
</div>
<?php echo elgg_view('input/urlshortener'); ?>