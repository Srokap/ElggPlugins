<?php
require_once(dirname(dirname(dirname(__FILE__))) . '/engine/start.php');
if(isloggedin()){
$content = get_input('content','');
$content = explode(',' ,$content);
$type = $content[0];
if (isset($content[1])) {
	$subtype = $content[1];
} else {
	$subtype = '';
}
$orient = get_input('display');
$callback = get_input('callback');
$scroller = get_input('scroller');
$offset = get_input('offset');
$relationship_type = get_input('relationship_type');
$subject_guid = get_input('subject_guid');

if ($type == 'all') {
	$type = '';
	$subtype = '';
}

$body = '';
if (empty($callback)) {

	if (get_plugin_setting('useasdashboard', 'riverdashboard') == 'yes') {
		$title = elgg_echo('dashboard');
	} else {
		$title = elgg_echo('activity');
	}
	$area1 = elgg_view("riverdashboard/usermenu");
	$area1 .= elgg_view("riverdashboard/friends");
	$area1 .= elgg_view("riverdashboard/newestmembers");
	$area3 .= elgg_view("riverdashboard/sitemessage");
	$area3 .= elgg_view("riverdashboard/advert");
	$body .= elgg_view("riverdashboard/welcome");
}

	$Bcase = $_COOKIE["DTselect"];
	if($Bcase == "all"){ $case1 = 'mine'; $case2 = 'friend'; $case3 = 'default';
	}else if($Bcase == "friend"){ $case1 = 'mine'; $case2 = 'default'; $case3 = 'all';
	}else if($Bcase == "mine"){ $case1 = 'default'; $case2 = 'friend'; $case3 = 'all';
	}
if($Bcase){
$orient = "default";
switch($orient) {
			case $case1:	$subject_guid = $_SESSION['user']->guid; $relationship_type = ''; break;
			case $case2:	$subject_guid = $_SESSION['user']->guid; $relationship_type = 'friend'; break;
			case $case3:	$subject_guid = 0; $relationship_type = ''; break;
		}
}else{
switch($orient) {
			default:		$subject_guid = $_SESSION['user']->guid; $relationship_type = 'friend'; break;
			case 'all':		$subject_guid = 0; $relationship_type = ''; break;
			case 'mine':	$subject_guid = $_SESSION['user']->guid; $relationship_type = ''; break;
}
}

if(!empty($scroller)){
	if( !empty($relationship_type) ){
	$relationship_type = get_input('relationship_type');}
	if( !empty($subject_guid) ){
	$subject_guid = get_input('subject_guid');}
	$river = elgg_view_autoload_river_items($subject_guid, 0, $relationship_type, $type, $subtype, '',10,$offset,'','',false) . "</div>";
	$content = $river;
}else{
	$river = elgg_view_autoload_river_items($subject_guid, 0, $relationship_type, $type, $subtype, '',10,$offset) . "</div>";
		$river = str_replace('callback=true','replaced=88,334',$river);
	$nav = elgg_view('riverdashboard/nav',array(
		'type' => $type,
		'subtype' => $subtype,
		'orient' => $orient
	));
	$content = elgg_view('page_elements/contentwrapper', array('body' => $nav . $river));
}
if (empty($callback)) {
	global $autofeed;
	$autofeed = true;
	$body .= elgg_view('riverdashboard/container', array('body' => $content . elgg_view('riverdashboard/js')));
	page_draw($title, elgg_view_layout('river_boxes', $area1, $body , $area3));
} else {
	header("Content-type: text/html; charset=UTF-8");
	echo $content . elgg_view('riverdashboard/js');
}
}else{
	register_error(elgg_echo('river:just_for_signedin'));
	forward();
}