<?php
		function riverdashboard_init() {
			global $CONFIG;
			if (get_plugin_setting('useasdashboard', 'riverdashboard') == 'yes') {
				register_page_handler('dashboard','riverdashboard_page_handler');
			} else {
				if (isloggedin())
				{
					add_menu(elgg_echo('activity'), $CONFIG->wwwroot . "mod/riverdashboard/");
				}
			}
		
			register_page_handler('riverdashboard','riverdashboard_page_handler');
			elgg_extend_view('css','riverdashboard/css');
		}
		function riverdashboard_page_handler($page)
		{
			global $CONFIG;
			@include(dirname(__FILE__) . "/index.php");
			return true;
		}
		
		function riverdashboard_dashboard() {
			include(dirname(__FILE__) . '/index.php');
		}
		
		function elgg_view_autoload_river_items($subject_guid = 0, $object_guid = 0, $subject_relationship = '',
			$type = '', $subtype = '', $action_type = '', $limit = 20,$offset = 10, $posted_min = 0, $posted_max = 0, $pagination = true) {
			if(empty($offset)){
			$offset = (int) get_input('offset',0);
			}
			if ($riveritems = get_river_items($subject_guid,$object_guid,$subject_relationship,$type,$subtype,$action_type,($limit + 1),$offset,$posted_min,$posted_max)) {
		
				return elgg_view('river/item/list',array(
					'limit' => $limit,
					'offset' => $offset,
					'items' => $riveritems,
					'pagination' => $pagination
				));
		
			}
			return '';
		}
		
		register_elgg_event_handler('init','system','riverdashboard_init');
		global $CONFIG;
		register_action("riverdashboard/add",false,$CONFIG->pluginspath . "riverdashboard/actions/add.php");
		register_action("riverdashboard/delete",false,$CONFIG->pluginspath . "riverdashboard/actions/delete.php");
		register_action("riverdashboard/wireadd", FALSE, $CONFIG->pluginspath . "riverdashboard/actions/wireadd.php", FALSE);
?>