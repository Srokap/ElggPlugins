<?php

	$hungarian = array(
		'all' => 'Összes',
		'mine' => 'Saját',
		'filter' => 'Szűrő',
		'riverdashboard:useasdashboard' => "Kezdőlap lecserélése az eseményinfóra?",
		'activity' => 'Aktivitás',
		'riverdashboard:recentmembers' => 'Új felhasználók',
		
		/**
	     * River Widgets right
           **/
		
		'river:widgets:event_calendar' => 'Esemény naptár',
		'river:widgets:pages' => 'Friss oldalak',
		'river:widgets:ads_asc' => 'Árban növekvő Termékbemutatók',
		'river:widgets:ads_desc' => 'Árban csökkenő Termékbemutatók',
		'river:widgets:ads_best' => 'Legjobb Termékbemutatók',
		'river:widgets:videolist' => 'Friss videók',
		'river:widgets:audio' => 'Friss e-Dal albumok',
		'river:just_for_signedin' => 'A hírfolyam csak bejelentkezett felhasználóknak engedélyezett',
		
		/**
	     * River usermenu
           **/
           
		'river:menu:edit_prof' => 'Profilom Szerkesztése',
		'river:menu:photos' => 'Fényképeim',
		'river:menu:videos' => 'Videóim',
		'river:menu:smt_mailer' => 'SMT Levelező',
		'river:menu:blog' => 'Blogom',
		'river:menu:my_esong' => 'e-Dal Albumom',
		'river:menu:esong' => 'e-Dal Albumok',
		'river:menu:my_ads' => 'Termékbemutatóim',
		'river:menu:ads' => 'Termékbemutatók',
		
		/**
	     * River Wire
           **/
           
		'river:wire:title' => 'Firkálj a falra',
		'river:wire:message' => 'Üzenet',
		'river:wire:video' => 'Videó beillesztése',
		'river:wire:tell' => 'Oszd meg üzeneted',
		'river:wire:video_url' => 'Másold ide a videó URL-t',
		'river:wire:video_supported' => 'Megjeleníthető: Videa, Videakids, Indavideó, Youtube, Vimeo, Metacafe',
	
	    /**
	     * Site messages
           **/

		'sitemessages:announcements' => "Közlemény",
		'sitemessages:posted' => "Elküldve",
		'sitemessages:river:created' => "<div style='font-weight:bolder;font-size:18px;'>Adminisztrátori közlemény!</div>",
		'sitemessages:river:create' => "",
		'sitemessages:add' => "Új Közlemény",
		'sitemessage:deleted' => "Törölve",
		'sitemessage:error' => "Hiba.",
		
		'river:widget:noactivity' => 'Nincs aktivitás.',
		'river:widget:title' => "Aktivitás",
		'river:widget:description' => "Nemrégi aktivitás.",
		'river:widget:title:friends' => "Ismerősök aktivitása",
		'river:widget:description:friends' => "Ismerősök tevékenysége.",
		'river:widgets:friends' => "Ismerősök",
		'river:widgets:mine' => "Saját",
		'river:widget:label:displaynum' => "Megjelenítendő:",
		'river:widget:type' => "Megjelenítés:",
		'item:object:sitemessage' => "Oldal üzenetek",
		'riverdashboard:avataricon' => "Szeretnél Avatarokat látni az eseményinfónál?",
		'option:icon' => 'Ikonok',
		'option:avatar' => 'Avatarok',
	);
					
	add_translation("hu",$hungarian);

?>
