<?php
		gatekeeper();
		$guid = (int) get_input('message');
		$message = get_entity($guid);
		if ($message->getSubtype() == "sitemessage" && $message->canEdit()) {
				$rowsaffected = $message->delete();
				if ($rowsaffected > 0) {
					system_message(elgg_echo("sitemessage:deleted"));
				} else {
					register_error(elgg_echo("sitemessage:notdeleted"));
				}
				forward("pg/dashboard");
		}
?>