<?php
if (!isloggedin()) forward();

$body = get_input('note');
$vidbody = get_input('notevid');
				$youthttp = explode(":", $vidbody);
					$YH_1 = $youthttp[0]; // http
					$YH_2 = $youthttp[1];  // //www.youtube.com/watch?v=hV5mJTOD-Lc
					
					$youtubelink = explode("//", $YH_2);
					$YL_1 = $youtubelink[0];  // 
					$YL_2 = $youtubelink[1];  // www.youtube.com/watch?v=hV5mJTOD-Lc
					
					$videocode = explode("=", $YL_2);
					$YC_1 = $videocode[0];  // www.youtube.com/watch?v
					$YC_2 = $videocode[1]; // hV5mJTOD-Lc

$body .= $vidbody;
$access_id = (int)get_default_access();
if ($access_id == ACCESS_PRIVATE) {
	$access_id = ACCESS_LOGGED_IN;
}
$method = get_input('method');
$parent = (int)get_input('parent', 0);
if (!$parent) {
	$parent = 0;
}
if (empty($body) && empty($vidbody)) {
	register_error(elgg_echo("thewire:blank"));
	forward("pg/dashboard");
}
if( $vidbody != '' && $YC_1 != 'www.youtube.com/watch?v'){
	register_error(elgg_echo("Hibás videó URL!"));
	forward("pg/dashboard");
}

if (!thewire_save_post($body, $access_id, $parent, $method)) {
	register_error(elgg_echo("thewire:error"));
	forward("pg/dashboard");
}

system_message(elgg_echo("thewire:posted"));
forward("pg/dashboard");
?>