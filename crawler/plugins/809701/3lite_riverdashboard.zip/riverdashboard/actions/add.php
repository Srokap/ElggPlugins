<?php
		admin_gatekeeper();
        action_gatekeeper();
		$message = get_input('sitemessage');
		if (empty($message)) {
			register_error(elgg_echo("sitemessages:blank"));
			forward("pg/dashboard");
		} else {
			$sitemessage = new ElggObject();
			$sitemessage->subtype = "sitemessage";
			$sitemessage->owner_guid = $_SESSION['user']->getGUID();
			$sitemessage->access_id = 1; // this is for all logged in users
			$sitemessage->title = '';
			$sitemessage->description = $message;
			if (!$sitemessage->save()) {
				register_error(elgg_echo("sitemessage:error"));
				forward("pg/dashboard");
			}
		system_message(elgg_echo("sitemessages:posted"));
		add_to_river('river/sitemessage/create','create',$_SESSION['user']->guid,$sitemessage->guid);
		forward("pg/dashboard");
		}
?>