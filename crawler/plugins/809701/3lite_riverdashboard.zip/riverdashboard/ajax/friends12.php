<?php
require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/engine/start.php');
set_context('search');
$limit = get_input('limit', 10);
$offset = get_input('offset', 0);
?>
<a href="<?php echo $vars['url']; ?>pg/friends/<?php echo $_SESSION['user']->username; ?>"><h3 style="padding:4px 4px 4px 10px;"><?php echo elgg_echo('friends') ?></h3></a>
<div class="sidebarBox">
    
    <div class="membersWrapper"><br />
        <?php
        $friendsToDisplay = get_plugin_setting('friendsToDisplay','riverdashboard');
        $friends = get_entities_from_relationship('friend',$_SESSION['guid'],false,'user','',0,'',12);
        foreach($friends as $friend) {
        echo "<div class=\"recentMember\" >";
        echo "<a class=\"tooltip\" href=\"".$friend->getURL()."\" title=\"<b>".$friend->name."</b>\">" . elgg_view("profile/icon",array('entity' => $friend, 'size' => 'small', 'override' => 'true', 'title' => false)) . "</a>";
        /*echo "<div style=\"width:175px;font-weight:normal;\" >".$friend->name;*/
        echo "</div>";
        }
        ?>
    
    <div class="clearfloat"></div>
    </div>
</div>