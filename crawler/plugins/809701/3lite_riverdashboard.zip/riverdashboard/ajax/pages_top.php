<?php
require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/engine/start.php');
set_context('search');
	if (is_plugin_enabled('pages')){ 
		$limit = get_input('limit', 10);
		$offset = get_input('offset', 0);
		$objects = list_entities("object", "page_top", 0, $limit, false);
?>
	<div class="index_box">
		<a href="<?php echo $vars['url']; ?>mod/pages/world.php" ><h3 style="padding:4px 4px 4px 10px;"><?php echo elgg_echo("river:widgets:pages"); ?></h3></a>
		<?php 
		if ($objects != '')
			echo $objects;
		?>
	</div>
<?php }?>