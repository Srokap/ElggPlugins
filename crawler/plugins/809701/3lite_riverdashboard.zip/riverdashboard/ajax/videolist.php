<?php
require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/engine/start.php');
set_context('search');
$limit = get_input('limit', 10);
$offset = get_input('offset', 0);
$videos = list_entities("object","videolist", 0, 10, $fullview=true, $viewtypetoggle=false,$pagination=false);
?>
<div class="index_box">
	<a href="<?php echo $vars['url']; ?>pg/videolist/search/"><h3 style="padding:4px 4px 4px 10px;"><?php echo elgg_echo("river:widgets:videolist"); ?></h3></a>
	<?php 
		
		if(isset($videos)) {
			echo '<div class="river_images" style="">';
			echo $videos;
			echo '</div>';
		}else{
		}
	?>
</div>