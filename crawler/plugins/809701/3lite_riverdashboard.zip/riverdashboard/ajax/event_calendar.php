<?php
require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/engine/start.php');
set_context('search');
$limit = get_input('limit', 10);
$offset = get_input('offset', 0);
$event_calendar = list_entities("object","event_calendar", 0, 10, $fullview=false, $viewtypetoggle=false,$pagination=false);
?>
<div class="index_box">
	<a href="<?php echo $vars['url']; ?>pg/event_calendar/"><h3 style="padding:4px 4px 4px 10px;"><?php echo elgg_echo("river:widgets:event_calendar"); ?></h3></a>
	<?php 
		
		if(isset($event_calendar)) {
			echo '<div class="river_images" style="">';
			echo $event_calendar;
			echo '</div>';
		}else{
		}
	?>
</div>