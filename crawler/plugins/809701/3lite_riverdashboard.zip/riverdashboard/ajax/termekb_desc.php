<?php
require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/engine/start.php');
set_context('search');
$limit = get_input('limit', 10);
$offset = get_input('offset', 0);
$ads_options3 = array(
  'type' => 'object',
  'subtype' => 'ad',
  'offset' => $offset,
  'limit' => $limit,
  'order_by_metadata' => array('name' => 'price', 'direction' => 'desc', 'as' => 'integer')
);
$ads_count3 = elgg_get_entities_from_metadata(array_merge($ads_options3, array('count' => true)));
$ads_entities3 = elgg_get_entities_from_metadata($ads_options3);
$ads_area3 = elgg_view_entity_list($ads_entities3, $ads_count3, $offset, $limit, '', '', false);
?>
<div class="index_box">
<a href="<?php echo $vars['url']; ?>mod/ad/everyone.php"><h3 style="padding:4px 4px 4px 10px;"><?php echo elgg_echo("river:widgets:ads_desc"); ?></h3></a>
<?php
echo $ads_area3;
?>
</div>