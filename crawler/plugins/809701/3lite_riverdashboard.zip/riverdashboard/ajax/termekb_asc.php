<?php
require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/engine/start.php');
set_context('search');
$limit = get_input('limit', 10);
$offset = get_input('offset', 0);
$ads_options2 = array(
  'type' => 'object',
  'subtype' => 'ad',
  'offset' => $offset,
  'limit' => $limit,
  'order_by_metadata' => array('name' => 'price', 'direction' => 'asc', 'as' => 'integer')
);
$ads_count2 = elgg_get_entities_from_metadata(array_merge($ads_options2, array('count' => true)));
$ads_entities2 = elgg_get_entities_from_metadata($ads_options2);
$ads_area2 = elgg_view_entity_list($ads_entities2, $ads_count2, $offset, $limit, '', '', false);
?>
<div class="index_box">
<a href="<?php echo $vars['url']; ?>mod/ad/everyone.php"><h3 style="padding:4px 4px 4px 10px;"><?php echo elgg_echo("river:widgets:ads_asc"); ?></h3></a>
<?php
echo $ads_area2;
?>
</div>