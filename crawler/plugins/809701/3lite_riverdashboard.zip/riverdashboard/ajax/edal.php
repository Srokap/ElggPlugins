<?php
require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/engine/start.php');
$limit = get_input('limit', 10);
$offset = get_input('offset', 0);
set_context('search');
$audios = list_entities('object','audio',0,10,false);
?>
<div class="index_box">
	<a href="<?php echo $vars['url']; ?>mod/audio/everyone.php"><h3 style="padding:4px 4px 4px 10px;"><?php echo elgg_echo("river:widgets:audio"); ?></h3></a>
	<?php 
		
		if(isset($audios)) {
			echo '<div class="" style="">';
			echo $audios;
			echo '</div>';
		}else{
		}
	?>
</div>