
elgg.provide('elgg.riverjax');

elgg.riverjax.init = function() {
	var form = $('form[name=riverjax]');
	form.find('input[type=submit]').live('click', elgg.riverjax.submit);

};

elgg.riverjax.submit = function(e) {
	var form = $(this).parents('form');
	var data = form.serialize();

	elgg.action('rivertalk/save', {
		data: data,
		success: function(json) {
		
			};		
			form.find('textarea').val('');
	});
	e.preventDefault();
};
elgg.register_hook_handler('init', 'system', elgg.riverjax.init);