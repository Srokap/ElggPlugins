<?php
/**
 * New Rivertalk river entry
 *
 */

$object = $vars['item']->getObjectEntity();

//get excerpt of around 250, depending on spaces
	$num_chars = 250;
	$excerpt = $object->description;

	$string_length = elgg_strlen($excerpt);

	if ($string_length >= $num_chars) {
	$text = trim(elgg_strip_tags($excerpt)); //all NUL bytes, HTML and PHP tags stripped??
	if ($string_length == elgg_strlen($text)) {

	// handle cases
	$excerpt = elgg_substr($text, 0, $num_chars);
	$space = elgg_strrpos($excerpt, ' ', 0);

	// don't crop if can't find a space.
	if ($space === FALSE) {
		$space = $num_chars;
	}
	$excerpt = trim(elgg_substr($excerpt, 0, $space));

	if ($string_length != elgg_strlen($excerpt)) {
		$excerpt .= '...';

	$readmore_link = elgg_view('output/url', array(
		'href' => $object->getURL() . '#comments',
		'text' => elgg_echo('rivertalk:readmorelink'),
		'is_trusted' => true,
	));
	$excerpt .= $readmore_link;
	}
	}
	}

$description = $excerpt;


echo elgg_view('river/elements/layout', array(
	'item' => $vars['item'],
	'message' => $description,
));