.elgg-riverbox {
	margin-top: 20px;
}
.elgg-input-plaintext {
height: 4.5em;
}
.elgg-menu-plaintext {
float: right;
}