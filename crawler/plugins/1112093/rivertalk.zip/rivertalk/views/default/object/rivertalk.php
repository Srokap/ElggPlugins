<?php
/**
 * Rivertalk view object
 *
 */

$full = elgg_extract('full_view', $vars, FALSE);
$rivertalk = elgg_extract('entity', $vars, FALSE);

if (!$rivertalk) {
	return;
}

$owner = $rivertalk->getOwnerEntity();
$owner_icon = elgg_view_entity_icon($owner, 'tiny');
$container = $rivertalk->getContainerEntity();


$owner_link = elgg_view('output/url', array(
	'href' => "rivertalk/owner/$owner->username",
	'text' => $owner->name,
	'is_trusted' => true,
));
$author_text = elgg_echo('byline', array($owner_link));

$date = elgg_view_friendly_time($rivertalk->time_created);

$comments_count = $rivertalk->countComments();
//only display if there are commments
if ($comments_count != 0) {
	$text = elgg_echo("comments") . " ($comments_count)";
	$comments_link = elgg_view('output/url', array(
		'href' => $rivertalk->getURL() . '#comments',
		'text' => $text,
		'is_trusted' => true,
	));
} else {
	$comments_link = '';
}

$metadata = elgg_view_menu('entity', array(
	'entity' => $vars['entity'],
	'handler' => 'rivertalk',
	'sort_by' => 'priority',
	'class' => 'elgg-menu-hz',
));

$subtitle = "$author_text $date $comments_link"; //took out:  $categories

// do not show the metadata and controls in widget view
if (elgg_in_context('widgets')) {
	$metadata = '';
}

if ($full && !elgg_in_context('gallery')) {

	$params = array(
		'entity' => $rivertalk,
		'title' => false,
		'metadata' => $metadata,
		'subtitle' => $subtitle,
	);
	$params = $params + $vars;
	$summary = elgg_view('object/elements/summary', $params);

	$body = <<<HTML
<div class="rivertalk elgg-content mts">
	$rivertalk->description
</div>
HTML;

	echo elgg_view('object/elements/full', array(
		'entity' => $rivertalk,
		'icon' => $owner_icon,
		'summary' => $summary,
		'body' => $body,
	));

} elseif (elgg_in_context('gallery')) {
	echo <<<HTML
<div class="rivertalk-gallery-item">
	<p class='subtitle'>$owner_link $date</p>
	<h3 class="elgg-rivertitle">$rivertalk->description</h3>
</div>
HTML;

} else {
	// brief view
	$excerpt = elgg_get_excerpt($rivertalk->description);
	if ($excerpt) {
		$excerpt = " - $excerpt";
		$excerpt .= " please read more.";
	}

	//if (strlen($url) > 25) {
	//	$bits = parse_url($url);
	//	if (isset($bits['host'])) {
	//		$display_text = $bits['host'];
	//	} else {
	//		$display_text = elgg_get_excerpt($url, 100);
	//	}
	//}

	//$link = elgg_view('output/url', array(
	//	'href' => $rivertalk->address,
	//	'text' => $display_text,
	//));

	$params = array(
		'entity' => $rivertalk,
		'metadata' => $metadata,
		'subtitle' => $subtitle,
		'content' => $content,
	);
	$params = $params + $vars;
	$body = elgg_view('object/elements/summary', $params);
	
	echo elgg_view_image_block($owner_icon, $body);
}