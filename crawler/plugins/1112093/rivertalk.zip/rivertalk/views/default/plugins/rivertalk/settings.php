<?php
/**
 * Rivertalk settings
 * 
 */

	if (!isset($vars['entity']->show_sitetab)) {
		$vars['entity']->show_sitetab = 'yes';
	}
	if (!isset($vars['entity']->num_entries)) {
		$vars['entity']->num_entries = 12;
	}
	if (!isset($vars['entity']->show_embed)) {
		$vars['entity']->show_embed = 'yes';
	}

echo '<div>';
echo elgg_echo('rivertalk:label:showtab');
echo '<br />';
echo elgg_view('input/dropdown', array(
	'name' => 'params[show_sitetab]',
	'options_values' => array(
		'yes' => elgg_echo('option:yes'),
		'no' => elgg_echo('option:no')
	),
	'value' => $vars['entity']->show_sitetab,
));
echo '</div>';

echo '<div>';
echo elgg_echo('rivertalk:label:num_entries');
echo '<br />';
$params = array(
	'name' => 'params[num_entries]',
	'value' => $vars['entity']->num_entries,
	'options' => array(6, 12, 18, 24, 30, 36),
);
echo elgg_view('input/dropdown', $params);
echo '</div>';

echo '<div>';
echo elgg_echo('rivertalk:label:show_embed');
echo '<br />';
echo elgg_view('input/dropdown', array(
	'name' => 'params[show_embed]',
	'options_values' => array(
		'yes' => elgg_echo('option:yes'),
		'no' => elgg_echo('option:no')
	),
	'value' => $vars['entity']->show_embed,
));
echo '</div>';

echo '<div>';
echo '<p>Rivertalk v1.05<br />
Designers: Daniel White, Art Pitkin<br />
http://strablet.wordpress.com/<br />
@license http://www.gnu.org/licenses/gpl-2.0.html GNU General Public License v2<br />
</p>';
echo '</div>';
