<?php
/**
 * Edit / add a Rivertalk
 *
 */

// once elgg_view stops throwing all sorts of junk into $vars, we can use extract()
$title = elgg_echo('rivertalk:readmore');
$description = elgg_extract('description', $vars, '');
$access_id = ACCESS_PUBLIC;
$container_guid = elgg_extract('container_guid', $vars);
$guid = elgg_extract('guid', $vars, null);
$shares = elgg_extract('shares', $vars, array());

$textbox = elgg_extract('textbox', $vars);

?>
<div class="elgg-riverbox">
	<label><?php echo elgg_echo('rivertalk:formtitle'); ?></label><br />
	<?php echo elgg_view('input/' . $textbox, array('name' => 'description', 'value' => $description)); ?>
</div>

<div class="elgg-foot">
<?php

echo elgg_view('input/hidden', array('name' => 'container_guid', 'value' => $container_guid));

if ($guid) {
	echo elgg_view('input/hidden', array('name' => 'guid', 'value' => $guid));
}

echo elgg_view('input/submit', array('value' => elgg_echo("rivertalk:go")));

?>
</div>