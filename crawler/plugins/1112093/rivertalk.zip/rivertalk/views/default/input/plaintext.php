<?php
/**
 * Elgg long text input (plaintext)
 * Displays a long text input field that should not be overridden by wysiwyg editors.
 *
 * @package Elgg
 * @subpackage Core
 *
 * @uses $vars['value']    The current value, if any
 * @uses $vars['name']     The name of the input field
 * @uses $vars['class']    Additional CSS class
 * @uses $vars['disabled']  
 */

if (isset($vars['class'])) {
	$vars['class'] = "elgg-input-plaintext {$vars['class']}";
} else {
	$vars['class'] = "elgg-input-plaintext";
}

$defaults = array(
	'value' => '',
	'id' => 'elgg-input-' . rand(), //@todo make this more robust
);

$vars = array_merge($defaults, $vars);

$value = $vars['value'];
unset($vars['value']);

$context = elgg_get_context();

// we need to see a tab for embed content in the plaintext input box, activity page only
if (elgg_get_plugin_setting('show_embed', 'rivertalk') == 'yes' && ($context == 'activity')) {
echo elgg_view_menu('plaintext', array(
	'sort_by' => 'priority',
	'class' => 'elgg-menu-hz elgg-rivertalk-plaintext',
	'id' => $vars['id'],
));
}

?>

<textarea <?php echo elgg_format_attributes($vars); ?>>
<?php echo htmlspecialchars($value, ENT_QUOTES, 'UTF-8', false); ?>
</textarea>