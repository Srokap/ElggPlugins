<?php
/**
 * Save a Rivertalk
 *
 */

$title = elgg_echo('rivertalk:readmore');
$description = get_input('description');
$access_id = ACCESS_PUBLIC;
$guid = get_input('guid');
$share = get_input('share');
$container_guid = get_input('container_guid', elgg_get_logged_in_user_guid());

// make sure the post isn't blank
if (empty($description)) {
	register_error(elgg_echo("rivertalk:blank"));
	forward('activity');
}

elgg_make_sticky_form('rivertalk');

if ($guid == 0) {
	$rivertalk = new ElggObject;
	$rivertalk->subtype = "rivertalk";
	$rivertalk->container_guid = (int)get_input('container_guid', $_SESSION['user']->getGUID());
	$new = true;
} else {
	$rivertalk = get_entity($guid);
	if (!$rivertalk->canEdit()) {
		system_message(elgg_echo('rivertalk:save:failed'));
		forward(REFERRER);
	}
}

$rivertalk->title = $title;
$rivertalk->description = $description;
$rivertalk->access_id = $access_id;

if ($rivertalk->save()) {

	elgg_clear_sticky_form('rivertalk');

	// @todo
	if (is_array($shares) && sizeof($shares) > 0) {
		foreach($shares as $share) {
			$share = (int) $share;
			add_entity_relationship($rivertalk->getGUID(), 'share', $share);
		}
	}
	system_message(elgg_echo('rivertalk:save:success'));

	//add to river only if new
	if ($new) {
		add_to_river('river/object/rivertalk/create','create', elgg_get_logged_in_user_guid(), $rivertalk->getGUID());

	}

	forward('activity');
} else {
	register_error(elgg_echo('rivertalk:save:failed'));
	forward(REFERER);
}