<?php
/**
 * Delete a Rivertalk action
 *
 */

$guid = get_input('guid');
$rivertalk = get_entity($guid);

if (elgg_instanceof($rivertalk, 'object', 'rivertalk') && $rivertalk->canEdit()) {
	$container = $rivertalk->getContainerEntity();
	if ($rivertalk->delete()) {
		system_message(elgg_echo("rivertalk:delete:success"));
		if (elgg_instanceof($container, 'group')) {
			forward("rivertalk/group/$container->guid/all");
		} else {
			forward("rivertalk/owner/$container->username");
		}
	}
}

register_error(elgg_echo("rivertalk:delete:failed"));
forward(REFERER);