<?php
/**
 * Rivertalk plugin everyone page
 *
 */

elgg_pop_breadcrumb();
elgg_push_breadcrumb(elgg_echo('rivertalk'));

elgg_register_title_button();

$content = elgg_list_entities(array(
	'type' => 'object',
	'subtype' => 'rivertalk',
	'limit' => 10,
	'full_view' => true,
	'view_toggle_type' => false
));

if (!$content) {
	$content = elgg_echo('rivertalk:none');
}

$title = elgg_echo('rivertalk:everyone');

$body = elgg_view_layout('content', array(
	'filter_context' => 'all',
	'content' => $content,
	'title' => $title,
	'sidebar' => elgg_view('rivertalk/sidebar'),
));

echo elgg_view_page($title, $body);