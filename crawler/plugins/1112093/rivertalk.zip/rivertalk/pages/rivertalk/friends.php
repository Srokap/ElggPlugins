<?php
/**
 * Rivertalk plugin friends page
 *
 */

$page_owner = elgg_get_page_owner_entity();
if (!$page_owner) {
	forward('rivertalk/all');
}

elgg_push_breadcrumb($page_owner->name, "rivertalk/owner/$page_owner->username");
elgg_push_breadcrumb(elgg_echo('friends'));

elgg_register_title_button(); 

$title = elgg_echo('rivertalk:friends');

$content = list_user_friends_objects($page_owner->guid, 'rivertalk', 10, true);
if (!$content) {
	$content = elgg_echo('rivertalk:none');
}

$params = array(
	'filter_context' => 'friends',
	'content' => $content,
	'title' => $title,
);

$body = elgg_view_layout('content', $params);

echo elgg_view_page($title, $body);
