<?php
/**
 * Rivertalk English language file
 *
 */

$english = array(

	/**
	 * Menu items and titles
	 */
	'rivertalk' => "Rivertalk",
	'rivertalk:heading' => 'Reading Room',
	'rivertalk:formtitle' => 'What are you thinking? Write it here!',
	'rivertalk:title' => ' wanted to say ',
	'rivertalk:go' => 'Go',
	'rivertalk:readmore' => 'Read More', // used in sidebar??
	'rivertalk:readmorelink' => ' please read more.',
	'rivertalk:add' => "Add a Rivertalk",
	'rivertalk:edit' => "Edit a Rivertalk",
	'rivertalk:owner' => "%s's Rivertalk",
	'rivertalk:friends' => "Friends' Rivertalk",
	'rivertalk:everyone' => "All Rivertalks",
	'rivertalk:this:group' => "Rivertalk in %s",
	'rivertalk:inbox' => "Rivertalk inbox",
	'rivertalk:morerivertalk' => "More Rivertalks",
	'rivertalk:more' => "More",
	'rivertalk:with' => "Share with",
	'rivertalk:new' => "A new Rivertalk",
	'rivertalk:address' => "Address of the Rivertalk",
	'rivertalk:none' => 'No Rivertalk',
	'rivertalk:media' => 'Embed content',

	'rivertalk:notification' =>
'%s added a new Rivertalk:

%s - %s
%s

View and comment on the new Rivertalk:
%s
',

	/**
	 * General
	 */
	'rivertalk:delete:confirm' => "Are you sure you want to delete this resource?",
	'rivertalk:numbertodisplay' => 'Number of Rivertalks to display',
	'rivertalk:shared' => "Rivertalk shared",
	'rivertalk:visit' => "Visit resource",
	'rivertalk:recent' => "Recent Rivertalks",
	'item:object:rivertalk' => 'Rivertalk',
	'rivertalk:more' => 'More Rivertalks',
	'rivertalk:no_title' => 'No title',

	/**
	 * River
	 */
	'river:create:object:rivertalk' => '%s wanted to say ',
	'river:comment:object:rivertalk' => '%s commented on the Rivertalk %s',
	'rivertalk:river:annotate' => 'a comment on this Rivertalk',
	'rivertalk:river:item' => 'an item',

	/**
	 * Groups
	 */
	'rivertalk:group' => 'Group Rivertalk',
	'rivertalk:enablerivertalk' => 'Enable group Rivertalk',
	'rivertalk:nogroup' => 'This group does not have a Rivertalk yet',

	/**
	 * Settings
	 */
	'rivertalk:label:showtab' => 'Do you want to show the Rivertalk tab in the site menu?',
	'rivertalk:label:num_entries' 	=> 'How many entries do you want to show in the river per page?',
	'rivertalk:label:show_embed' => 'Do you want to show "embed content" above the Rivertalk entry form?<br /> Note: This requires the Embed content plugin.',

	/**
	 * Widget
	 */
	'rivertalk:widget:description' => "Display your latest Rivertalks.",

	/**
	 * Status messages
	 */

	'rivertalk:save:success' => "Your Rivertalk was successfully added.",
	'rivertalk:delete:success' => "Your Rivertalk was deleted.",

	/**
	 * Error messages
	 */

	'rivertalk:save:failed' => "Your Rivertalk could not be saved. Make sure you've entered a title and address and then try again.",
	'rivertalk:save:invalid' => "The address of the Rivertalk is invalid and could not be saved.",
	'rivertalk:delete:failed' => "Your Rivertalk could not be deleted. Please try again.",
	'rivertalk:blank' => "Sorry, you need to write something in the box!",

);


add_translation('en', $english);