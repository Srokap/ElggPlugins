<?php
/**
 * 
 * Traditional Chinese Rivertalk language file 
 *
 * Project leader: Daniel White
 * Translators: Frank Wu, Angela Hung, Yao-ching Lancelot, Emma Zhang
 * Location: Taipei, Taiwan
 * Date: October, 2012
 *
 */

$chinese = array(

	/**
	 * Menu items and titles
	 */
	'rivertalk:formtitle'=> '你在想些什麼呢?發表在互動牆吧!',

);

add_translation("zh",$chinese);
?>