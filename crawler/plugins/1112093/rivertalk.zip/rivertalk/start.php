<?php
/**
 * Rivertalk plugin v1.05
 *
 * Designers: Daniel White, Art Pitkin
 * http://strablet.wordpress.com/
 *
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU General Public License v2
 *
 * Main functionality: This plugin adds a form to the river on the activity page. 
 * Entries to the form appear in the river with comment bubbles, allowing people 
 * to comment on river entries.
 * 
 * 
 * Notes: Turn off the wire add-on if you are using it on the activity page. 
 * 
 */

elgg_register_event_handler('init', 'system', 'rivertalk_init');


/**
 * rivertalk init
 */
function rivertalk_init() {

	$root = dirname(__FILE__);
	elgg_register_library('elgg:rivertalk', "$root/lib/rivertalk.php");

	// actions
	$action_path = "$root/actions/rivertalk";
	elgg_register_action('rivertalk/save', "$action_path/save.php");
	elgg_register_action('rivertalk/delete', "$action_path/delete.php");
	$action_path = "$root/actions/comments";
	elgg_register_action('comments/add', "$action_path/add.php");
	elgg_register_action('comments/delete', "$action_path/delete.php");

	// site menu
	if (elgg_get_plugin_setting('show_sitetab', 'rivertalk') == 'yes'){
	elgg_register_menu_item('site', array(
		'name' => 'rivertalk',
		'text' => elgg_echo('rivertalk'),
		'href' => 'rivertalk/all'
	));
	}

	// hooks
	elgg_register_plugin_hook_handler('register', 'menu:page', 'rivertalk_page_menu');
	elgg_register_plugin_hook_handler('register', 'menu:plaintext', 'rivertalk_plaintext_menu');

	// pages
	elgg_register_page_handler('rivertalk', 'rivertalk_page_handler');
	elgg_unregister_page_handler('activity', 'elgg_river_page_handler');
	elgg_register_page_handler('activity', 'riverbox_river_page_handler');

	// views
	elgg_extend_view('css/elgg', 'rivertalk/css');
	//elgg_extend_view('js/elgg', 'js/riverjax');

	// widgets
	elgg_register_widget_type('rivertalk', elgg_echo('rivertalk'), elgg_echo('rivertalk:widget:description'));

	if (elgg_is_logged_in()) {
		$user_guid = elgg_get_logged_in_user_guid();
		$address = urlencode(current_page_url());
	}

	// Register granular notification for this type (unused)
	register_notification_object('object', 'rivertalk', elgg_echo('rivertalk:new'));

	// Listen to notification events and supply a more useful message
	elgg_register_plugin_hook_handler('notify:entity:message', 'object', 'rivertalk_notify_message');

	// Register a URL handler for rivertalk
	elgg_register_entity_url_handler('object', 'rivertalk', 'rivertalk_url');

	// Register entity type for search
	elgg_register_entity_type('object', 'rivertalk');

	// Groups
	add_group_tool_option('rivertalk', elgg_echo('rivertalk:enablerivertalk'), true);
	elgg_extend_view('groups/tool_latest', 'rivertalk/group_module');

}

/**
 * Dispatcher for Rivertalk
 *
 * URLs take the form of
 *  All rivertalk:        rivertalk/all
 *  User's rivertalk:     rivertalk/owner/<username>
 *  Friends' rivertalk:   rivertalk/friends/<username>
 *  View rivertalk:        rivertalk/view/<guid>/<title>
 *  New rivertalk:         rivertalk/add/<guid> (container: user, group, parent)
 *  Edit rivertalk:        rivertalk/edit/<guid>
 *  Group rivertalk:      rivertalk/group/<guid>/all
 *
 *
 * @param array $page
 * @return bool
 */
function rivertalk_page_handler($page) {
	elgg_load_library('elgg:rivertalk');

	elgg_push_breadcrumb(elgg_echo('rivertalk'), 'rivertalk/all');

	// old group usernames
	if (substr_count($page[0], 'group:')) {
		preg_match('/group\:([0-9]+)/i', $page[0], $matches);
		$guid = $matches[1];
		if ($entity = get_entity($guid)) {
			rivertalk_url_forwarder($page);
		}
	}

	// user usernames
	$user = get_user_by_username($page[0]);
	if ($user) {
		rivertalk_url_forwarder($page);
	}

	$pages = dirname(__FILE__) . '/pages/rivertalk';

	switch ($page[0]) {
		case "all":
			include "$pages/all.php";
			break;

		case "owner":
			include "$pages/owner.php";
			break;

		case "friends":
			include "$pages/friends.php";
			break;

		case "read":
		case "view":
			set_input('guid', $page[1]);
			include "$pages/view.php";
			break;

		case "add":
			gatekeeper();
			include "$pages/add.php";
			break;

		case "edit":
			gatekeeper();
			set_input('guid', $page[1]);
			include "$pages/edit.php";
			break;

		case 'group':
			group_gatekeeper();
			include "$pages/owner.php";
			break;

		default:
			return false;
	}

	elgg_pop_context();
	return true;
}


/**
 * Forward to the new style of URLs
 *
 * @param string $page
 */
function rivertalk_url_forwarder($page) {
	global $CONFIG;

	if (!isset($page[1])) {
		$page[1] = 'items';
	}

	switch ($page[1]) {
		case "read":
			$url = "{$CONFIG->wwwroot}rivertalk/view/{$page[2]}/{$page[3]}";
			break;
		case "inbox":
			$url = "{$CONFIG->wwwroot}rivertalk/inbox/{$page[0]}";
			break;
		case "friends":
			$url = "{$CONFIG->wwwroot}rivertalk/friends/{$page[0]}";
			break;
		case "add":
			$url = "{$CONFIG->wwwroot}rivertalk/add/{$page[0]}";
			break;
		case "items":
			$url = "{$CONFIG->wwwroot}rivertalk/owner/{$page[0]}";
			break;
	}

	register_error(elgg_echo("changerivertalk"));
	forward($url);
}

/**
 * Populates the ->getUrl() method for rivertalked objects
 *
 * @param ElggEntity $entity The rivertalked object
 * @return string rivertalked item URL
 */
function rivertalk_url($entity) {
	global $CONFIG;

	$title = $entity->title;
	$title = elgg_get_friendly_title($title);
	return $CONFIG->url . "rivertalk/view/" . $entity->getGUID() . "/" . $title;
}


/**
 * Returns the body of a notification message
 *
 * @param string $hook
 * @param string $entity_type
 * @param string $returnvalue
 * @param array  $params
 */
function rivertalk_notify_message($hook, $entity_type, $returnvalue, $params) {
	$entity = $params['entity'];
	$to_entity = $params['to_entity'];
	$method = $params['method'];
	if (($entity instanceof ElggEntity) && ($entity->getSubtype() == 'rivertalk')) {
		$descr = $entity->description;
		$title = $entity->title;
		$owner = $entity->getOwnerEntity();

		return elgg_echo('rivertalk:notification', array(
			$owner->name,
			$title,
			$entity->address,
			$descr,
			$entity->getURL()
		));
	}
	return null;
}


/**
 * Rivertalk activity page handler. 
 * Takes out the old river and puts in the new one plus the Rivertalk form.
 *
 */
function riverbox_river_page_handler($page)
{

   global $CONFIG;

	elgg_set_page_owner_guid(elgg_get_logged_in_user_guid());

	// make a URL segment available in page handler script
	$page_type = elgg_extract(0, $page, 'all');
	$page_type = preg_replace('[\W]', '', $page_type);
	if ($page_type == 'owner') {
		$page_type = 'mine';
	}
	set_input('page_type', $page_type);

	// content filter code here
	$entity_type = '';
	$entity_subtype = '';

	if(!require_once("{$CONFIG->path}mod/rivertalk/pages/rivertalk/riverbox.php"));
	
	return true;

}


/**
 * List rivertalk items
 *
 */
function rivertalk_list_river(array $options = array()) {
	global $autofeed;
	$autofeed = true;
	$num_entries = elgg_get_plugin_setting('num_entries', 'rivertalk');

	$defaults = array(
		'offset'     => (int) max(get_input('offset', 0), 0),
		'limit'      => (int) max(get_input('limit', $num_entries), 0),
		'pagination' => TRUE,
		'list_class' => 'elgg-list-river elgg-river', // @todo remove elgg-river in Elgg 1.9
	);

	$options = array_merge($defaults, $options);

	$options['count'] = TRUE;
	$count = elgg_get_river($options);

	$options['count'] = FALSE;
	$items = elgg_get_river($options);

	$options['count'] = $count;
	$options['items'] = $items;
	return elgg_view('page/components/list', $options);
}


/**
 * Add the embed menu item to the plain text menu
 *
 */
function rivertalk_plaintext_menu($hook, $type, $items, $vars) {

	if (elgg_get_context() == 'embed') {
		return $items;
	}

	// if the embed content menu is off, don't setup and load
	if (elgg_get_plugin_setting('show_embed', 'rivertalk') == 'yes') {

	$url = 'embed';
	if (elgg_get_page_owner_guid()) {
		$url = 'embed?container_guid=' . elgg_get_page_owner_guid();
	}
	
	$items[] = ElggMenuItem::factory(array(
		'name' => 'embed',
		'href' => $url,
		'text' => elgg_echo('rivertalk:media'),
		'rel' => 'lightbox',
		'link_class' => "elgg-longtext-control elgg-lightbox embed-control embed-control-{$vars['id']}",
		'priority' => 10,
	));
      
        elgg_register_menu_item('plaintext', $items);

	elgg_load_js('lightbox');
	elgg_load_css('lightbox');
	elgg_load_js('jquery.form');
	elgg_load_js('elgg.embed');

	}
	
	return $items;
}