Unless otherwise stated within individual files of this package:

Andreas Johannes Berchtold - http://www.freudenschaft.de/Erdschrei_Aura/profile/Andreas
Cheng Sun
Zhang Yuqi
Anna jones
Vance Burres
Chen Hao
Brett anderson
Felix Paul K�hne
