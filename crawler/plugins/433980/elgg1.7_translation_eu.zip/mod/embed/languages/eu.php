<?php

	$basque = array(
	
		'media:insert' => 'Media igo/txertatu',
	
		'embed:instructions' => 'Klik egin edozein fitxategitan edukian txertatzeko.',
	
		'embed:media' => 'Media txertatu',
		'upload:media' => 'Media igo',
	
		'embed:file:required' => 'Ez da fitxategiak igotzeko tresnarik aurkitu. Kudeatzaileak plugin-a igo behar du horretarako.',
	
	);
					
	add_translation("eu",$basque);

?>
