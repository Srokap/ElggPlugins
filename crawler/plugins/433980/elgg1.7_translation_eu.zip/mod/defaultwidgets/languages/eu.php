<?php

$basque = array (

	/**
	 * Nice name for the entity (shown in admin panel)
	 */
	'item:object:moddefaultwidgets' => 'Widget lehenetsien ezarpenak',

	/**
	 * Menu items
	 */
	'defaultwidgets:menu:profile' => 'Profileko widget lehenetsiak',
    'defaultwidgets:menu:dashboard' => 'Aginte-paneleko widget lehenetiska',

    'defaultwidgets:admin:error' => 'Errorea: Ez zaude kudeatzaile moduan izen emanda',
	'defaultwidgets:admin:notfound' => 'Errorea: Orrialdea ez da aurkitu',
	'defaultwidgets:admin:loginfailure' => 'Oharra: Ez zaude kudeatzaile moduan izen emanda',

	'defaultwidgets:update:success' => 'Widget-aren ezaugarriak ondo gorde dira',
	'defaultwidgets:update:failed' => 'Errorea: ezaugarriak ez dira gorde',
	'defaultwidgets:update:noparams' => 'Errorea: formularioko parametro okerrak',

	'defaultwidgets:profile:title' => 'Ezarri widget lehenetsiak erabiltzaileen profil orri berrietan',
	'defaultwidgets:dashboard:title' => 'Ezarri widget lehenetisak erabiltzaileen aginte-panel orri berrietan',
);

add_translation ( "eu", $basque );
