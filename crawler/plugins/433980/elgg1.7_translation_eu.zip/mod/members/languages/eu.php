<?php

// Translationbrowser-ek sortua. 

$basque = array( 
	 'members:members'  =>  "Guneko erabiltzaileak" , 
	 'members:online'  =>  "Gunean aktibo dauden erabiltzaileak" , 
	 'members:active'  =>  "guneko erabiltzaileak" , 
	 'members:searchtag'  =>  "Erabiltzaileak etiketa bidez bilatu" , 
	 'members:searchname'  =>  "Erabiltzaileak izenez bilatu" , 
	 'members:label:newest'  =>  "Berriena" , 
	 'members:label:popular'  =>  "Ezagunena" , 
	 'members:label:active'  =>  "Aktiboa" , 
	 'members:search:name'  =>  "Erabiltzaiearen izena" , 
	 'members:search:tags'  =>  "Etiketak"
); 

add_translation('eu', $basque); 

?>