<?php

// Translationbrowser-ek sortua. 

$basque = array( 
	 'friends:invite'  =>  "Lagunak gonbidatu" , 
	 'invitefriends:introduction'  =>  "Sare honetara lagunak gonbidatzeko, sartu beraien posta elektrokikoa hemen (helbide bat lerroko):" , 
	 'invitefriends:message'  =>  "Sartu zure lagunek jasoko duten gonbidapen testua:" , 
	 'invitefriends:subject'  =>  "Sartzeko gonbidapena %s" , 
	 'invitefriends:success'  =>  "Zure lagunek gonbidapena jasoko dute." , 
	 'invitefriends:failure'  =>  "Zure lagunei ezin izan zaie zure gonbidapena bidali." , 
	 'invitefriends:message:default'  =>  "
Kaixo,

Gure sarean %s sartzeko gonbidatu nahi zaitugu." , 
	 'invitefriends:email'  =>  "
%s sarean sartzeko gonbidapena egin dizu %s -(e)k. Mezu hau bidali nahi dizu:

%s

Sartzeko, sakatu esteka honetan:

	%s

Automatikoki zure lagun moduan ageriko da kontua sortu duzunean." , 
	 'invitefriends:email_error'  =>  "Gonbidapenak bidali dira, baina ondorengo helbide hauek ez dira egokiak: %s"
); 

add_translation('eu', $basque); 

?>