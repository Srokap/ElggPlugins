<?php

	$basque = array(
	
		/**
		 * Menu items and titles
		 */
	
			'thewire' => "Haria",
			'thewire:user' => "%sren haria",
			'thewire:posttitle' => "%sren mezuak harian: %s",
			'thewire:everyone' => "Hariko mezu guztiak",
	
			'thewire:read' => "Hariko mezua",
			
			'thewire:strapline' => "%s",
	
			'thewire:add' => "Harian argitaratu",
		    'thewire:text' => "Hariko mezu bat",
			'thewire:reply' => "Erantzun",
			'thewire:via' => "via",
			'thewire:wired' => "Harian argitaratua",
			'thewire:charleft' => "karaktere faltan",
			'item:object:thewire' => "Hariko mezuak",
			'thewire:notedeleted' => "mezua ezabatua",
			'thewire:doing' => "Zertan ari zara? Kontatu hariko guztiei:",
			'thewire:newpost' => 'Hariko mezu berria',
			'thewire:addpost' => 'Harira mezu bat bidali',

	
        /**
	     * The wire river
	     **/
	        
	        //generic terms to use
	        'thewire:river:created' => "%s argitaratua",
	        
	        //these get inserted into the river links to take the user to the entity
	        'thewire:river:create' => "harian.",
	        
	    /**
	     * Wire widget
	     **/
	     
	        'thewire:sitedesc' => 'Widget honek hariko azken mezuak erakusten ditu',
	        'thewire:yourdesc' => 'Widget honek hariko zure azken mezuak erakusten ditu',
	        'thewire:friendsdesc' => 'Widget honek zure lagunen hariko azken mezuak erakusten ditu',
	        'thewire:friends' => 'Zure lagunak harian',
	        'thewire:num' => 'Erakusteko elementu kopurua',
	        
	        
	
		/**
		 * Status messages
		 */
	
			'thewire:posted' => "Zure mezua ondo argitaratu da harian.",
			'thewire:deleted' => "Zure mezua haritik ezbatu da.",
	
		/**
		 * Error messages
		 */
	
			'thewire:blank' => "Barkatu; zerbait jarri behar duzu mezuan bidali ahal izateko.",
			'thewire:notfound' => "Barkatu; ez dugu eskatutako mezua aurkitu.",
			'thewire:notdeleted' => "Barkatu; ezin izan dugu eskatutako mezua ezabatu.",
	
	
		/**
		 * Settings
		 */
			'thewire:smsnumber' => "Zure SMS zenbakia zure mugikorreko zenbakiaren ezberdina da (mugikor zenbakia publiko egin behar 
da harian erabili ahal izateko). Mugikor zenbaki guztiak formatu internazionalean egon behar dute.",
			'thewire:channelsms' => "SMS mezuak bidaltzeko zenbakia <b>%s</b> da",
			
	);
					
	add_translation("eu",$basque);

?>
