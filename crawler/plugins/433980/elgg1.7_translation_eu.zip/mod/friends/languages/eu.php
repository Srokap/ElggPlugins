<?php

	$basque = array(
	
		/**
		 * Friends widget
		 */
			'friends:widget:description' => "Zure lagun batzuk erakusten ditu.",
	        
		
	);
					
	add_translation("eu",$basque);

?>