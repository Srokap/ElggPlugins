<?php

	$basque = array(
	
		'friends:all' => 'Lagun guztiak',
	
		'notifications:subscriptions:personal:description' => 'Jakinarazpenak jaso zure edukietan ekintzarik gertatuz gero.',
		'notifications:subscriptions:personal:title' => 'Jakinarazpen pertsonalak',
	
		'notifications:subscriptions:collections:title' => 'Lagun sarea ERAKUTSI',
		'notifications:subscriptions:collections:description' => 'Zure lagun sareko ezaugarriak ERAKUSTEKO, ikono hau erabili. Honek 
dagokion erabiltzaileei eragingo dio, orrialde azpian dagoen ezaugarri nagusien panelean.',
		'notifications:subscriptions:collections:edit' => 'Zure lagun sareak editatzeko, klik egin hemen.',
	
		'notifications:subscriptions:changesettings' => 'Jakinarazpenak',
		'notifications:subscriptions:changesettings:groups' => 'Talde jakinarazpenak',
		'notification:method:email' => 'Email',	
	
		'notifications:subscriptions:title' => 'Erabiltzailearen jakinarazpenak',
		'notifications:subscriptions:description' => 'Zure lagunek eduki berria sortzean jakinarazpenak jaso nahi badituzu, bilatu hemen 
eta aukeratu jakinarazpenetarako erabiliko den metodoa.',
	
		'notifications:subscriptions:groups:description' => 'Taldekide zaren talde batean eduki berria gehitzean jakinarazpenak jaso nahi 
badituzu, bilatu taldea eta aukeratu jakinarazpenetarako erabiliko den metodoa.',
	
		'notifications:subscriptions:success' => 'Zure jakinarazpen ezaugarriak gorde dira.',
	
	);
					
	add_translation("eu",$basque);

?>
