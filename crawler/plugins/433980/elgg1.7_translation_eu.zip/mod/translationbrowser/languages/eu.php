<?php
	/**
	 * Elgg translation browser.
	 * 
	 * @package translationbrowser
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Mariusz Bulkowski
	 * @copyright  2008
	 * @link http://elgg.com/
	 */

	$basque = array(
	
		/**
		 * Menu items and titles
		 */
		// Sections
			'translationbrowser' => 'Itzulpen Nabigatzailea',
			'translationbrowser:translate' => 'Itzuli',
			'translationbrowser:exporttranslations' => 'Itzulpenak esportatu',
			
		// Titles
			'translationbrowser:selectlanguage' => 'Hizkuntza hautatu',
			'translationbrowser:selecttypeexport' => 'Mesedez, hautatu ezazu esportazio mota',
			'translationbrowser:languagebase' => 'Hizkuntza Oinarria',
			
	
		// Words
			'translationbrowser:yourselectedlanguage' => 'Hautatutako hizkuntza',
			'translationbrowser:youwilltranslate' => "Hemendik itzuliko duzu ",
			'translationbrowser:to' => ', beste honetara: ',
			'translationbrowser:languagecore' => '- Sistemaren hizkuntza',
			'translationbrowser:selectmodule' => 'Orain, hautatu itzuli nahi duzun moduloa, eta ondoren, klik egin "Itzuli" botoian.',
			'translationbrowser:updatefile' => 'Barne fitxategia eguneratu',
			'translationbrowser:generatefile' => 'Php fitxategia sortu',
			'translationbrowser:highlight' => 'Nabarmendu itzultzeke dauden eremuak',
			'translationbrowser:canyouedit' => 'eremu balio hau editatu dezakezu',
	
		// Status
			'translationbrowser:blankmodule' => 'Modulu bat hautatu behera duzu gutxienez',
			'translationbrowser:languageerror' => 'Hautatutako moduloa ez da zuzena. Saiatu berriz edo beste hizkuntza bat aukeratu mesedez.',
			'translationbrowser:blanklang' => 'Hizkuntza bat hautatu behar duzu',
			'translationbrowser:emptyfields' => 'Eremu bat bete behar duzu gutxienez',
			'translationbrowser:error' => 'Barne errorea. Saiatu berriz beranduago mesedez',
			'translationbrowser:problem:permiss' => 'Karpeta atzitzerakoan arazo bat gertatu da. Baieztatu baimenak mesedez',
			'translationbrowser:error:filecreate' => 'Fitxategia sortzean arazoa gertatu da. Baieztatu baimenak mesedez',
			'translationbrowser:success' => 'Itzulpena egin da.',
			'translationbrowser:generatedby' => 'Translationbrowser-ek sortua.',
	
		// Actions
			'translationbrowser:save' => 'Gorde',
			'translationbrowser:save' => 'Itzuli',
			'translationbrowser:downloadallinzip' => 'Jaitsi dena ZIP formatuan',
		
		// Settings
		    'translationbrowser:userscanedit' => 'Erabiltzaileek editatu dezakete',
	
		// Export
			'translationbrowser:exportdescription' => 'Itzulpena esportatu nahi baduzu, hizkuntza autatu eta ondoren klik egin esportazio botoian',
			'translationbrowser:export' => 'Esportatu',
			
		// Credits
			'translationbrowser:infotxt' => "Fitxategi hau Translation Browser Elgg-ek sortua izan da\n".
	        	              				"\t@author Mariusz Bulkowski http://seo4you.pl/\n".
		              						"\t@author v2 Pedro Prez  http://www.pedroprez.com.ar/"	
			
	
	);
					
	add_translation("eu",$basque);
?>
