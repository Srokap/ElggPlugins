<?php

	$basque = array(

  'bookmarks' => 'Laster-markak',
  'bookmarks:add' => 'Zerbait laster-marketara gehitu',
  'bookmarks:read' => 'Laster-marketan dagoena',
  'bookmarks:friends' => 'Lagunen laster-markak',
  'bookmarks:everyone' => 'Laster-marka guztiak',
  'bookmarks:this' => 'Hau laster-marketara gehitu',
  'bookmarks:this:group' => 'Bookmark-a %s-(e)n',
  'bookmarks:bookmarklet' => 'Bookmarklet lortu',
  'bookmarks:bookmarklet:group' => 'Taldeko Bookmarkleta lortu',
  'bookmarks:inbox' => 'Laster-marken sarrerako ontzia',
  'bookmarks:more' => 'Laster-marka gehiago',
  'bookmarks:shareditem' => 'Laster-marketan dagoena',
  'bookmarks:with' => 'Honekin partekatu',
  'bookmarks:new' => 'Lotura berri bat',
  'bookmarks:via' => 'bookmark bidez',
  'bookmarks:address' => 'Laster-marketara gehitu nahi den baliabidearen helbidea',
  'bookmarks:delete:confirm' => 'Ziur baliabide hau ezabatu nahi duzula?',
  'bookmarks:numbertodisplay' => 'Laster-marketan dauden zenbat elementu erakutsi',
  'bookmarks:shared' => 'Laster-marketan',
  'bookmarks:visit' => 'Baliabidea bisitatu',
  'bookmarks:recent' => 'Laster-marka berriak',
  'bookmarks:river:created' => '%s laster-marketara gehituta',
  'bookmarks:river:annotate' => '%s-(e)k komentatu du',
  'bookmarks:river:item' => 'elementu bat',
  'item:object:bookmarks' => 'Laster-marketan dagoena',
  'bookmarks:group' => 'Taldeko Bookmarkak',
  'bookmarks:enablebookmarks' => 'Taldeko Bookmarkak gaitu',
  'bookmarks:widget:description' => 'Widget hau zure aginte-panelerako dago diseinatuta eta zure laster-marken sarrera ontzian sartutako azken elementuak erakutsiko dizkizu.',
  'bookmarks:bookmarklet:description' => 'Bookmarlet-ek topatzen dituzun baliabideak lagunekin partekatzeko edo zuretzako laster-marka sortzeko balio du. Erabiltzeko, arrastatu ondorengo botoia zure nabigatzailearen esteka barrara:',
  'bookmarks:bookmarklet:descriptionie' => 'Internet Explorer erabiltzen ari bazara, bookmarklet ikonoa eskuineko botoiarekin klikatu, aukeratu \'Gehitu gogokoetan\' eta egin gero esteka barrarena.',
  'bookmarks:bookmarklet:description:conclusion' => 'Ondoren, bisitatzen duzun edozein orrialde gorde ahalko duzu beran klik eginez.',
  'bookmarks:save:success' => 'Elementua laster-marketara gehitu da.',
  'bookmarks:delete:success' => 'Elementua laster-marketatik kendu da.',
  'bookmarks:save:failed' => 'Elementua ezin izan da laster-marketara gehitu. Saiatu berriro, mesedez.',
  'bookmarks:delete:failed' => 'Elementua ezin izan da ezabatu. Saiatu berriro, mesedez.',

	);
	
	add_translation("eu",$basque);

?>
