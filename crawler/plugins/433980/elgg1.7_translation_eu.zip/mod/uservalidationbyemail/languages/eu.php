<?php
	/**
	 * Email user validation plugin language pack.
	 * 
	 * @package ElggUserValidationByEmail
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$basque = array(
	
		'email:validate:subject' => "%s, egiaztatu zure posta elektroniko helbidea, mesedez!",
		'email:validate:body' => "Kaixo %s,

Mesedez, egiaztatu zure posta elektroniko helbidea ondorengo estekan klik eginez:

%s
",
		'email:validate:success:subject' => "Posta elektroniko helbidea balidatu da, %s!",
		'email:validate:success:body' => "Kaixo %s,
			
Zorionak, posta elektroniko helbidea balidatu egin duzu.",


		'email:confirm:success' => "Zure posta elektroniko helbidea egiaztatu duzu!",
		'email:confirm:fail' => "Zure posta elektroniko helbidea ezin izan da egiaztatu...",
	
		'uservalidationbyemail:registerok' => "Zure kontua aktibatzeko egiaztatu zure posta elektroniko helbidea bidali dizugun estekan klik eginez."
	
	);
					
	add_translation("eu",$basque);
?>
