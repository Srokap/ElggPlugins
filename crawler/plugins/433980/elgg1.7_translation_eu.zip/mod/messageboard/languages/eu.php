<?php

// Translationbrowser-ek sortua. 

$basque = array( 
	 'messageboard:board'  =>  "Mezu-taula" , 
	 'messageboard:messageboard'  =>  "mezu-taula" , 
	 'messageboard:viewall'  =>  "Ikusi guztiak" , 
	 'messageboard:postit'  =>  "Bidali" , 
	 'messageboard:history'  =>  "Historikoa" , 
	 'messageboard:none'  =>  "Oraindik ez dago ezer mezu-taula honetan" , 
	 'messageboard:num_display'  =>  "Erakutsi beharreko mezu kopurua" , 
	 'messageboard:desc'  =>  "Hau zure profilan ipini dezakezun mezu-taula da, non beste erabiltzaileek iruzkinak idazteko aukera duten." , 
	 'messageboard:user'  =>  "%s-ren mezu-taula" , 
	 'messageboard:replyon'  =>  "Erantzuna non" , 
	 'messageboard:river:annotate'  =>  "%s-(e)k iruzkin berria jaso du bere mezu-taulan." , 
	 'messageboard:river:create'  =>  "%s mezu-taula widget-a erabiltzen hasi da." , 
	 'messageboard:river:update'  =>  "%s-(e)k mezu-taula widget-a eguneratu du." , 
	 'messageboard:river:added'  =>  "%s-n argitaratua" , 
	 'messageboard:river:messageboard'  =>  "mezu-taula" , 
	 'messageboard:posted'  =>  "Zure mezua mezu-taulan gehitu da." , 
	 'messageboard:deleted'  =>  "Mezua ezabatu duzu." , 
	 'messageboard:email:subject'  =>  "Iruzkin berria duzu mezu-taulan!" , 
	 'messageboard:email:body'  =>  "%-(e)k iruzkin berria idatzi du zure mezu-taulan. Honakoa dio:

			
%s


Zure mezu-tauleko iruzkinak ikusteko egin klik hemen:

	%s

%s-(r)en profila ikusteko egin klik hemen:

	%s

Ez erantzun posta elektroniko honi." , 
	 'messageboard:blank'  =>  "Barkatu, baina mezuren bat idatzi behar duzu gorde aurretik." , 
	 'messageboard:notfound'  =>  "Barkatu, baina ez dugu zehaztutako elementua aurkitu." , 
	 'messageboard:notdeleted'  =>  "Barkatu, baina ezin izan dugu mezua ezabatu." , 
	 'messageboard:somethingwentwrong'  =>  "Zerbait gaizki joan da zure mezua gordetzean, ziurtatu mezua ondo idatzi duzula." , 
	 'messageboard:failure'  =>  "Espero ez zen errore bat gertatu da mezua bidaltzerakoan. Saiatu berriro, mesedez." , 
	 'messageboard:history:title'  =>  "Historia"
); 

add_translation('eu', $basque); 

?>