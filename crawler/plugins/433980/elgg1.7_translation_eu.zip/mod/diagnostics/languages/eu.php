<?php

// Translationbrowser-ek sortua. 

$basque = array( 
	 'diagnostics'  =>  "Sistemaren diagnostikoak" , 
	 'diagnostics:unittester'  =>  "Unitateen testak" , 
	 'diagnostics:description'  =>  "Ondorengo diagnostiko txostena erabilgarria da Elgg-en edozein arazo diagnostikatzeko eta gordetzen dituzun bug txosten guztietan gehitu beharko zenuke." , 
	 'diagnostics:unittester:description'  =>  "Diagnostikoko hurrengo probak pluginegatik erregistratua da eta Elgg-eko egitura arazteko burutzen da." , 
	 'diagnostics:test:executetest'  =>  "Testa exekutatu" , 
	 'diagnostics:test:executeall'  =>  "Exekutatu dena" , 
	 'diagnostics:unittester:notests'  =>  "Barkatu, ez daude instalatuta testerako unitate moduluak." , 
	 'diagnostics:unittester:testnotfound'  =>  "Barkatu, ezin izan da txostena sortu proba ez delako aurkitu" , 
	 'diagnostics:unittester:testresult:nottestclass'  =>  "Huts egitea - Emaitza ez da test klase bat" , 
	 'diagnostics:unittester:testresult:fail'  =>  "Huts egitea" , 
	 'diagnostics:unittester:testresult:success'  =>  "Arrakasta" , 
	 'diagnostics:unittest:example'  =>  "Unitate test adibidea arazketa moduan bakarrik erabilgarri." , 
	 'diagnostics:unittester:report'  =>  "%s-(r)en proba txostena" , 
	 'diagnostics:download'  =>  "Deskargatu .txt-a" , 
	 'diagnostics:header'  =>  "========================================================================
Elgg Diagnostiko txostena
%s sortuta %s-(r)en eskuz
========================================================================
			
" , 
	 'diagnostics:report:basic'  =>  "Elgg %s argitalpena, %s bertsioa

------------------------------------------------------------------------" , 
	 'diagnostics:report:php'  =>  "
PHP informazioa:
%s
------------------------------------------------------------------------" , 
	 'diagnostics:report:plugins'  =>  "
Instalatutako pluginak eta xehetasunak:

%s
------------------------------------------------------------------------" , 
	 'diagnostics:report:md5'  =>  "
Instalatutako fitxategiak eta kontroleko baturak:

%s
------------------------------------------------------------------------" , 
	 'diagnostics:report:globals'  =>  "
Aldagai globalak:

%s
------------------------------------------------------------------------" , 
	 'diagnostics:unittester:debug'  =>  "Guneak, debug moduan egon behar du proba unitarioak abiarazteko." , 
	 'diagnostics:unittester:warning'  =>  "ADI: Proba hauek, debug objetuak utzi ditzakete zure datubasean. EZ ERABILI PRODUKZIO GUNE BATEAN!"
); 

add_translation('eu', $basque); 

?>