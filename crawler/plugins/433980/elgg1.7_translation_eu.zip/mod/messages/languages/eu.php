<?php

	$basque = array(

  'messages' => 'Mezuak',
  'messages:back' => 'itzuli mezuetara',
  'messages:user' => 'Zure sarrera ontzia',
  'messages:sentMessages' => 'Bidalitako mezuak',
  'messages:posttitle' => '%s-(r)en mezuak: %s',
  'messages:inbox' => 'Sarrera ontzia',
  'messages:send' => 'Mezua bidali',
  'messages:sent' => 'Bidalitako mezuak',
  'messages:message' => 'Mezua',
  'messages:title' => 'Izenburua',
  'messages:to' => 'Nori',
  'messages:from' => 'Nork',
  'messages:fly' => 'Bidali',
  'messages:replying' => 'Honi erantzuten:',
  'messages:sendmessage' => 'Mezua bidali',
  'messages:compose' => 'Mezua bidali',
  'messages:sentmessages' => 'Bidalitako mezuak',
  'messages:recent' => 'Mezu berriak',
  'messages:original' => 'Jatorrizko mezua',
  'messages:yours' => 'Zure mezua',
  'messages:answer' => 'Erantzun',
  'messages:toggle' => 'Ezkutatu guztiak',
  'messages:markread' => 'Irakurri bezala markatu',
  'messages:new' => 'Mezu berria',
  'notification:method:site' => 'Gunea',
  'messages:error' => 'Arazo bat egon da zure mezua gordetzen. Mesedez saiatu berriro.',
  'item:object:messages' => 'Mezuak',
  'messages:posted' => 'Mezua bidali da.',
  'messages:deleted' => 'Mezua ezabatu da.',
  'messages:markedread' => 'Mezua irakurria bezala markatu da.',
  'messages:email:subject' => 'Mezu berria daukazu!',
  'messages:email:body' => '%s-(e)k mezu berri bat bidali dizu. Honakoa dio:

			
%s


Mezuak ikusteko egin klik hemen:

	%s

%s-(r)i mezu bat bidaltzeko egin klik hemen:

	%s

Ez erantzun posta elektroniko honi.',
  'messages:blank' => 'Barkatu, baina mezuren bat bidali behar duzu gorde aurretik.',
  'messages:notfound' => 'Barkatu, baina ezin izan dugu zehaztutako mezua aurkitu.',
  'messages:notdeleted' => 'Barkatu, baina ezin izan dugu mezu hau ezabatu.',
  'messages:nopermission' => 'Ez duzu mezu hau ezabatzeko baimenik.',
  'messages:nomessages' => 'Ez dago mezurik erakusteko.',
  'messages:user:nonexist' => 'Ezin izan dugu hartzailea aurkitu erabiltzaileen datu basean.',
  'messages:user:blank' => 'Ez duzu inor aukeratu hau bidaltzeko',


	);
	
	add_translation("eu",$basque);

?>
