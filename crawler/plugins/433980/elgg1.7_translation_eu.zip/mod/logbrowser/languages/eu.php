<?php
	/**
	 * Elgg log browser plugin language pack
	 * 
	 * @package ElggLogBrowser
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$basque = array(
	
		/**
		 * Menu items and titles
		 */
	
			'logbrowser' => 'Logaren nabigatzailea',
			'logbrowser:browse' => 'Sistemaren logan zehar nabigatu',
			'logbrowser:search' => 'Emaitzak findu',
			'logbrowser:user' => 'Bilatzeko erabiltzaile izena',
			'logbrowser:starttime' => 'Hasiera-data (esaterako "pasa den astelehenean", "orain dela ordubete")',
			'logbrowser:endtime' => 'Bukaera-data',
	
			'logbrowser:explore' => 'Loga esploratu',
	
	);
					
	add_translation("eu",$basque);
?>