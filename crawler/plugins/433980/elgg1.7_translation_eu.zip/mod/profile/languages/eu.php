<?php
	/**
	 * Elgg profile plugin language pack
	 *
	 * @package ElggProfile
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2010
	 * @link http://elgg.com/
	 */

	$basque = array(

	/**
	 * Profile
	 */

		'profile' => "Profila",
		'profile:edit:default' => 'Ordeztu profil eremuak',
		'profile:preview' => 'Aurrebista',

	/**
	 * Profile menu items and titles
	 */

		'profile:yours' => "Zure profila",
		'profile:user' => "%s-ren profila",

		'profile:edit' => "Profila editatu",
		'profile:profilepictureinstructions' => "Profilaren irudia, zure profilaren orrian bistaratzen den irdia da. <br /> Nahi duzunean aldatu dezakezu. (Onartutako fitxategi formatuak: GIF, JPG edo PNG)",
		'profile:icon' => "Profilaren irudia",
		'profile:createicon' => "Zure avatar-ra sortu",
		'profile:currentavatar' => "Uneko avatar-ra",
		'profile:createicon:header' => "Profilaren irudia",
		'profile:profilepicturecroppingtool' => "Profilaren irudi mozketa tresna",
		'profile:createicon:instructions' => "Klik egin eta arrastatu azpiko laukia, zuk nahi duzun neurrira argazkia moztutzeko. Moztutako argazkiaren aurrebista eskuineko kaxan agertuko da. Aurrebista gustukoa duzunean, click egin 'Zure avatar-ra sortu'-n. Moztutako argazki hau, gune osoan erabiliko da zure avatar gisa.",

		'profile:editdetails' => "Xehetasunak editatu",
		'profile:editicon' => "Profil ikonoa editatu",

		'profile:aboutme' => "Niri buruz",
		'profile:description' => "Niri buruz",
		'profile:briefdescription' => "Laburpen laburra",
		'profile:location' => "Kokapena",
		'profile:skills' => "Trebetasuanak",
		'profile:interests' => "Interesak",
		'profile:contactemail' => "Kontakturako eposta helbidea",
		'profile:phone' => "Telefonoa",
		'profile:mobile' => "Telefono mugikorra",
		'profile:website' => "Webgunea",

		'profile:banned' => 'Erabiltzile honen kontua eseki egin da.',
		'profile:deleteduser' => 'Erabiltzaile ezabatua',

		'profile:river:update' => "%s-k profila eguneratu zuten",
		'profile:river:iconupdate' => "%s-k bere profil ikonoa eguneratu zuten",

		'profile:label' => "Profilaren etiketa",
		'profile:type' => "Profil mota",

		'profile:editdefault:fail' => 'Lehenetsitako profila ezin izan da gordetu',
		'profile:editdefault:success' => 'Elementua lehenetsitako profilera egoki gehitu da',


		'profile:editdefault:delete:fail' => 'Ezin izan da lehenetsitako profilaren elementua ezabatu',
		'profile:editdefault:delete:success' => 'Lehenetsitako profilaren elementua ezabatu da!',

		'profile:defaultprofile:reset' => 'Sistemaren lehenetsitako profila berrezarri da',

		'profile:resetdefault' => 'Berrezarri lehenetsitako profila',
		'profile:explainchangefields' => 'Uneko profilaren eremuak ordeztu ditzakezu zureekin, azpiko datuorria ereabiliz. Lehendabizi, profilaren eremu berriari izen bat eman behar diozu, adibidez, \'Gustuko taldea\'. Ondoren, eremu mota hautatu behar duzu, adibidez: etiketa, url-a, edo testua. Edozein momentutan, lehenetsitako profilaren ezarpenak berreskuratu ditzakezu.',


	/**
	 * Profile status messages
	 */

		'profile:saved' => "Zure profila ongi gorde da.",
		'profile:icon:uploaded' => "Zure profilaren argazkia ongi kargatu da.",

	/**
	 * Profile error messages
	 */

		'profile:noaccess' => "Ez duzu profil hau editatzeko baimenik.",
		'profile:notfound' => "Barkatu, ezin dugu adierazitatko profila aurkitu.",
		'profile:icon:notfound' => "Barkatu, arazo bat gertatu da zure profileko argazkia kargatzean.",
		'profile:icon:noaccess' => 'Ezin duzu profil honen ikonoa aldatu',
		'profile:field_too_long' => 'Ezin izan da zure profila gorde "%s" sekzioa luzeegia delako.',

	);

	add_translation("eu",$basque);
