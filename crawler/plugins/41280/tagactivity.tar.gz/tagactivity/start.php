<?php

  /**
   * Elgg Online widget
   * This plugin list all the in which discussions a user recently took part of.
   * 
   * @package ElggOnline
   * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
   * @Author Jean-Baptiste Perriot <jb@perriot.fr>
   */

function tagactivity_init() {
  // Load system configuration
  global $CONFIG;
  
  // Load the language file
  register_translations($CONFIG->pluginspath . "tagactivity/languages/");

  // Extend some view
  extend_view('css','tagactivity/css');
  
  //add a widget
  add_widget_type('tagactivity', elgg_echo("Tag activity"), elgg_echo('tagactivity:widget:description'));
  }

register_elgg_event_handler('init','system','tagactivity_init');

?>