<?php

        $english = array(
                 /**
                  * widget
                  */
			 'tagactivity:widget:description' => "Tag activity",
			 'tagactivity:tag' => "Tag : ",
			 'tagactivity:more' => "More entries",
			 );

	add_translation("en",$english);

?>