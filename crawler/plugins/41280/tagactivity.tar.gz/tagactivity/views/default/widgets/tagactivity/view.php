<div>

<?php
$tag = $vars['entity']->tag;
$owner_guid_array = 0;
$owner_guid = -1;
$subtype = "";
$objecttype = "";
$md_type = "";			

set_context('search');
if (empty($objecttype) && empty($subtype)) {
  $title = sprintf(elgg_echo('searchtitle'),$tag); 
 } else {
  if (empty($objecttype)) $objecttype = 'object';
  $itemtitle = 'item:' . $objecttype;
  if (!empty($subtype)) $itemtitle .= ':' . $subtype;
  $itemtitle = elgg_echo($itemtitle);
  $title = sprintf(elgg_echo('advancedsearchtitle'),$itemtitle,$tag);
 }

if (!empty($tag)) {
  $body = "";
  $body .= list_entities_from_metadata($md_type, $tag, $objecttype, $subtype, $owner_guid_array, 5, false, false, false);
 }

$searchA = "<a href=\"" . $vars['url'] . "search/?tag=". urlencode($tag) . "\">" . elgg_echo('tagactivity:more') . "</a>";
$body .= "<div class=\"tag_activity_widget_singleitem_more\">$searchA</div>";

echo $body;
// $entities = get_entities_from_metadata("tags", $tag, "", "", 0, 10, 0);

// foreach ($entities as $entity) {
//   $date = sprintf(elgg_echo("blog:strapline"),
// 		  date("F j, Y",$entity->time_created)
// 		  );

//   echo "<div class=\"blog_post_icon\">";
//   echo elgg_view("profile/icon", array('entity' => $entity->owner, 'size' => 'tiny'));
//   echo "</div>";
//   echo "<p>&nbsp;";
//   echo "<a href=\"" . $entity->getURL() . "\">" . $entity->title . "</a> - " . $date;
//   //  echo "<br/>&nbsp;";
//   echo "</p>";
//   echo "<div class=\"clearfloat\"></div>";
// }
?>

</div>
<script type='text/javascript'>
  var title = "Activity for tag : <?php echo  $tag; ?>";
$('#widget<?php echo $vars['entity']->getGUID(); ?> h1').html(title);
</script>
