Extendafriend
======================

A more intuitive and useful UI for managing friends collections and per-user notifications for Elgg 1.8

This plugin should reside in mod/extendafriend