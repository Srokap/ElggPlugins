.extendafriendclear {
	clear:both;
	height: 1px;	
}

.extendafriendcollectionlist {
	width: 170px;
	float: left;
	padding: 5px;	
}

.extendafriend_form {
	width: 600px;
	margin: 0 auto;
}

#extendafriend_rtags {
	width: 500px;
}