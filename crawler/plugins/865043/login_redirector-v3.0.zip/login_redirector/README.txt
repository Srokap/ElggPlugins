= Features = 

- Redirect users after each login to a specific page.
- Redirect users after first login
- Allows for users to have a personal preference regarding login redirections.
- Respects "last forwarded from"