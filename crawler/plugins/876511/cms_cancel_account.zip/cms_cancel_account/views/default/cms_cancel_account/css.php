<?php
/**
 * CSS for cms_cancel_account
 */
?>

.cms_cancel_account-module > .elgg-head * {
	color: white;
}
.cms_cancel_account-module > .elgg-body * {
	color: #333;
}