<?php

$defaults = array(
	'class' => 'elgg-input-time',
);

$vars = array_merge($defaults, $vars);

$vars['type'] = 'time';

?>

<input <?php echo elgg_format_attributes($vars); ?> />