article, aside, details, figcaption, figure, footer, header, hgroup,
menu, nav, section { display: block; }
