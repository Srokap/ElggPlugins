<?php
/**
 * Visual styling
 *
 * @package Elgg.Core
 * @subpackage UI
 */
?>
/* <style>
/**/
.elgg-quiet {color: #666;}.elgg-loud {color: #0054A7;}
/* ***************************************
	BORDERS AND SEPARATORS
*************************************** */
.elgg-border-plain {border: 1px solid #eeeeee;}.elgg-divide-top {border-top: 1px solid #CCCCCC;}.elgg-divide-bottom {border-bottom: 1px solid #CCCCCC;}.elgg-divide-left {border-left: 1px solid #CCCCCC;}.elgg-divide-right {border-right: 1px solid #CCCCCC;}