.profile .elgg-inner {
	margin: 0 0 0 5px;
	border: 0;
	width: 710px;
	-webkit-border-radius: 8px;
	-moz-border-radius: 8px;
	border-radius: 8px;
}

#elgg-widget-col-1 {
 width: 250px;
}

/* *************************
	TABBER
*************************** */
.ishouvik_profile_wrapper {
 width: 470px;
 min-height: 10px;
 float: right;
}

