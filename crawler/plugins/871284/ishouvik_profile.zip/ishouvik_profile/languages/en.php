<?php
/**
 * Elgg iShouvik Adverts plugin language pack
 *
 * @package iShouvikAdverts
 */

$english = array(

	'ishouvik:profile:info' => 'Info',
);

add_translation("en", $english);
