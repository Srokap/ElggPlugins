<?php

/* ***********************************************************************
 * @author : Purusothaman Ramanujam
 * @link http://www.iYaffle.com/
 * Under this agreement, No one has rights to sell this script further.
 * ***********************************************************************/

add_translation('en', array(
    'tweet-button:lblMedium'       => 'Medium',
    'tweet-button:lblLarge'        => 'Large',
    'tweet-button:lblCount'        => 'Button Layout',
    'tweet-button:lblRelated'      => 'Twitter account to Promote Example -> Elgg:A social source engine',
    'tweet-button:lblSize'         => 'Size of the Button',
    'tweet-button:lblText'         => 'Text to Go along with the Tweet',
    'tweet-button:lblStandard'     => 'Standard',
    'tweet-button:lblHorizontal'   => 'Horizontal Count',
    'tweet-button:lblVertical'     => 'Vertical Count',
    
));