<?php

function advbg_init() 
		{
		global $CONFIG;
		add_menu(elgg_echo('Adventure Buddy'), $CONFIG->wwwroot . "advbg");
		}		
	register_elgg_event_handler('init','system','advbg_init');

?>
