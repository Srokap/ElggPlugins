<?php
function customsearch_init(){
  // Register search hook
  register_plugin_hook('search', 'all', 'customsearch_search_hook');
//  register_page_handler('search','customsearch_page_handler');
}

// Note : le hook n'existant pas, il faut l'ajouter pour que la recherche fonctionne, et donc modifier /search/index.php
// Par contre on pourrait aussi mettre en place un page_handler via pg/search/ et overrider les vues adéquates pour faire pointer les liens aux bons endroits et intégrer la recherche fulltext sans modifier le core
function customsearch_search_hook(){
//  if (!@include_once(dirname(__FILE__) . "/index.php")) return false;
  @include_once(dirname(__FILE__) . "/index.php");
  return true;
}

/*
function customsearch_page_handler($page) {
//  if (!@include_once(dirname(__FILE__) . "/index.php")) return false;
  @include_once("index.php");
  return true;
}
*/

function get_all_subtypes(){
  global $CONFIG;
  $rows = get_data("SELECT subtype as regsubtypes FROM {$CONFIG->dbprefix}entity_subtypes");
  return $rows;
}

register_elgg_event_handler('init', 'system', 'customsearch_init');

