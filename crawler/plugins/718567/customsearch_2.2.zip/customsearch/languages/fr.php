<?php 
	$french = array(
		'customsearch' => "Recherche",
		'customsearch:search' => "Rechercher",
		'customsearch:all' => "Tous (aucun filtre)",
		
		'customsearch:search:title' => "Recherche : %s",
		'customsearch:search:found' => "Résultat de votre recherche %s:",
		'customsearch:search:no_param' => "Veuillez fournir un terme pour la recherche.",
		'customsearch:search:no_result' => "Pas de résultat",
		'customsearch:search:reservedwords' => "Terme de recherche trop large, merci d'essayer une autre recherche.",
		'customsearch:search:too_short' => "Les termes de la recherche sont trop courts (au moins %s caractères)",
		
		'customsearch:search:whitelist:desc' => "Liste Blanche (mode tag... séparateur ',')",
		
		'customsearch:settings:scope' => "Etendue de la recherche",
		'customsearch:settings:scope:help' => "Définit à quels contenus s'étend la recherche : contenus de ce site seulement (locale), ou tous les contenus accessibles (globale).",
  'customsearch:settings:local' => "Locale (par défaut)",
  'customsearch:settings:all' => "Globale",
  
	);
	
	add_translation("fr", $french);
?>
