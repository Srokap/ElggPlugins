<?php 
	$dutch = array(
		'customsearch' => "Full Text Search",
		
		'customsearch:search:title' => "Zoekresultaten voor: %s",
		'customsearch:search:found' => "Resultaten gevonden: %s",
		'customsearch:search:no_result' => "Geen zoekwoord(en) opgegeven",
		'customsearch:search:too_short' => "Zoekwoord is te kort (minimale lengte is %s)",
	);
	
	add_translation("nl", $dutch);
?>