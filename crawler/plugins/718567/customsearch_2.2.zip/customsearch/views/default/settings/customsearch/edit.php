<?php
global $CONFIG; 
$entity = $vars['entity'];
if (empty($entity->whitelist)){
	$entity->whitelist = 'blog,bookmarks,event_calendar,file,groupforumtopic,multispublisher,messages,page,page-top,thewire';
}

?>
<div class="search_box">
	<p><?php echo elgg_echo('customsearch:search:whitelist:desc');?></p>
	<p><?php echo elgg_view('input/text', array('internalname' 	=> 'params[whitelist]','value' 	=> $entity->whitelist)); ?></p>
</div>

<?php
// Etendue de la recherche
$scope_options = array( 
    'local' => elgg_echo('customsearch:settings:local'), 
    'all' => elgg_echo('customsearch:settings:all'), 
  );
echo '<p><label style="clear:left;">' . elgg_echo('customsearch:settings:scope') . '</label>';
echo elgg_view('input/pulldown', array('internalname' => 'params[scope]', 'options_values' => $scope_options, 'value' => $vars['entity']->scope)) . '</p>';
echo '<p>' . elgg_echo('customsearch:settings:scope:help') 
  . '<p>URL : <a href="' . $CONFIG->url . 'pg/search/">' . $CONFIG->url . 'pg/search/</a></p>';
