<?php
/* How to use ?
 * Modify /search/index.php to add following lines after the require_once call :
	// Load Elgg engine
		require_once(dirname(dirname(__FILE__)) . "/engine/start.php");
  // Facyla 20110322 : customsearch patch : ajout de cette boucle qui bascule sur customsearch ssi le plugin est activé
  // Attention : dans ce cas, customsearch doit aussi construire le menu - ce qui est le cas ici (avec un compteur)
    if (is_plugin_enabled('customsearch')) { trigger_plugin_hook('search','','',""); exit; }
 * Check $includemenu is set to true : you might also us regular menu. In that case you need to add the hook trigger right before following line, and put all what's next in the index.php file in a else { ... } loop
  if (empty($objecttype)) $objecttype = 'object';
 * 
*/

require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
global $CONFIG;

$dosearch = true;
global $search;
if ($search) $dosearch = false;
$search = true;

/*
// Ca c'est pour une utilisation hors-plugin
if (!is_plugin_enabled('customsearch') && !function_exists('get_all_subtypes')) {
  function get_all_subtypes(){
    global $CONFIG;
    $rows = get_data("SELECT subtype as regsubtypes FROM {$CONFIG->dbprefix}entity_subtypes");
    return $rows;
  }
}
*/

// sans modif du core, préférer "pg/search/?tag=" ; avec modif on peut utiliser "/search/?tag=" et "/tag/"
$searchurl = "pg/search/?tag=";

// Contenus autorisés : on utilise les types configurés le cas échéant, et à défaut ceux enregistrés
$withelist = array();
$searchlist = get_plugin_setting('whitelist', 'customsearch');
if (!empty($searchlist) ) {
  $whitelist = string_to_tag_array($searchlist);
} else $whitelist = get_registered_entity_types();
//$whitelist[]	= '';

set_context('search');

// Paramètres utiles à récupérer
$searchstring = sanitise_string( get_input('tag') );
$tag = stripslashes( trim($searchstring) );
if (!$objecttype = stripslashes(get_input('object'))) { $objecttype = ""; }
$objectType = $objecttype;
$subtype = stripslashes( get_input('subtype'));
if (!$md_type = stripslashes(get_input('tagtype'))) { $md_type = ""; }
$owner_guid = (int) get_input('owner_guid', 0);
$friends = (int) get_input('friends', 0);

$search_min_size = 2;

// Ajout d'un champ de recherche dans la page ? (défaut : non)
$searchform = get_plugin_setting('searchform', 'customsearch');
$searchform = ($searchform == 'yes') ? true : false;

// Ajout ou non du menu ?
$includemenu = true;

// Etendue de la recherche : local (recherche locale seulement), all (recherche globale multisite)
if ($scope = get_plugin_setting('scope', 'customsearch')) {} else { $scope = 'local'; }
$multisite = 0;
if (is_plugin_enabled('multisite') && ($scope != 'local')) $multisite = -1;

$currsite = $CONFIG->site->guid;

// @bug : si recherche == certains termes réservés, dépassement de mémoire.. donc on évite ce problème
$reserved_words = array('fing', 'blog', 'site');
if (in_array($tag, $reserved_words)) { $dosearch = false; }

// Recherche des contenus correspondant aux critères
if ($dosearch && !empty($tag) && (strlen($tag) >= $search_min_size)) {
  
  // Types de contenus autorisés
  $allowedTypes	= array();
  $added = array();
  $allowedT = get_all_subtypes();
  foreach ($allowedT as $key => $subT) {
    foreach($subT as $k => $v) {
      if (in_array($v, $whitelist)) { $allowedTypes[] = $v; }
    }
  }
  
  // Classic search - by tags
  if (substr_count($owner_guid, ',')) { $owner_guid_array = explode(",", $owner_guid); } else { $owner_guid_array = $owner_guid; }
  if ($friends > 0) {
    if ($friends = get_user_friends($friends,'',9999)) {
      $owner_guid_array = array();
      foreach ($friends as $friend) { $owner_guid_array[] = $friend->guid; }
    } else { $owner_guid = -1; }
  }
  if (empty($objecttype) && empty($subtype)) {} else {
    if (empty($objecttype)) $objecttype = 'object';
    $itemtitle = 'item:' . $objecttype;
    if (!empty($subtype)) $itemtitle .= ':' . $subtype;
    $itemtitle = elgg_echo($itemtitle);
  }
  $classicsearch = get_entities_from_metadata($md_type, elgg_strtolower($tag), $objecttype, $subtype, $owner_guid_array, 9999, 0, "", $multisite, false);
  if (!empty($classicsearch)) {
    foreach ($classicsearch as $entity) {
      if ( ($entity->type != 'site') && !array_key_exists($entity->guid, $added) ) { $added[$entity->guid] = $entity; }
    }
  }
  // Pour pouvoir différencier par la suite les résultats
  $classic_search = $added;
  
  // Search in Metadata
  $rows = get_data("SELECT a1.*,a2.* FROM {$CONFIG->dbprefix}metastrings as a1, {$CONFIG->dbprefix}metadata as a2  
    WHERE a1.string LIKE '%" . $searchstring . "%' AND a2.value_id=a1.id
    GROUP BY a2.entity_guid ORDER BY a2.time_created DESC");
  if(!empty($rows)){
    foreach($rows as $row){
      $entity_id = $row->entity_guid;
      if ($entities  = get_entity($entity_id)) {
        if((in_array(get_subtype_from_id($entities->subtype), $allowedTypes)) or (empty($entities->subtype))) {
          if ( ($entities->type != 'site') && !array_key_exists($entities->guid, $added) ) { $added[$entities->guid] = $entities; }
        }
      }
    }
  }
  
  // Search in Annotations
  $rowsA = get_data("SELECT a1.*,a2.* FROM {$CONFIG->dbprefix}metastrings as a1, {$CONFIG->dbprefix}annotations as a2  
    WHERE a1.string LIKE '%" . $searchstring . "%' AND a2.value_id=a1.id 
    GROUP BY a2.entity_guid ORDER BY a2.time_created DESC");
  if(!empty($rowsA)) {
    foreach($rowsA as $rowA){
      $entity_idA = $rowA->entity_guid;
      if ($entitiesA  = get_entity($entity_idA)) {
        if((in_array(get_subtype_from_id($entitiesA->subtype), $allowedTypes)) or (empty($entitiesA->subtype))) {
          if($entitiesA->type != 'site') {
            if(!array_key_exists($entities->guid, $added)){ $added[$entitiesA->guid] = $entitiesA; }
          }
        }
      }
    }
  }
  
  // Search in Objects
  $rows2 = get_data("SELECT * FROM {$CONFIG->dbprefix}objects_entity WHERE title LIKE '%" . $searchstring . "%' OR description LIKE '%" . $searchstring . "%'");
  if(!empty($rows2)) {
    foreach($rows2 as $row2){
      $entity_id2 = $row2->guid;
      if ($entities2  = get_entity($entity_id2)) {
        if((in_array(get_subtype_from_id($entities2->subtype), $allowedTypes)) or (empty($entities2->subtype))) {
          if($entities2->type != 'site') {
            if(!array_key_exists($entities2->guid, $added)) { $added[$entities2->guid] = $entities2; }
          }
        }
      }
    }
  }
  
  // Search in Groups
  $rows3 = get_data("SELECT * FROM {$CONFIG->dbprefix}groups_entity 
    WHERE  name LIKE '%" . $searchstring . "%' OR description LIKE '%" . $searchstring . "%'");
  if(!empty($rows3)) {
    foreach($rows3 as $row3) {
      $entity_id3 = $row3->guid;
      if ($entities3  = get_entity($entity_id3)) {
        if((in_array(get_subtype_from_id($entities3->subtype), $allowedTypes)) or (empty($entities3->subtype))){ 
          if($entities3->type != 'site'){
            if(!array_key_exists($entities3->guid, $added)){ $added[$entities3->guid] = $entities3; }
          }
        }
      }
    }
  }
  
  // Search for Users
  $user_count = search_for_user($tag, 0, 0, "", true);
  if(!empty($user_count)){
    $users = search_for_user($tag, $user_count);
    foreach($users as $user){
      if(!array_key_exists($user->guid, $added)){ $added[$user->guid] = $user; }
    }
  }
  
  
  // Filter search results
  $entitiesList = array();
  $countbytypes = array();
  if (!empty($added)) {
    foreach ($added as $guid => $entity){
      $type = $entity->type;
      $stype = $entity->getSubtype();
      if (empty($objectType) || (!empty($objectType) && $type == $objectType)){
        if (empty($subtype) || (!empty($subtype) && $stype == $subtype)) {
          // Filtrage des résultats locaux ou multisite
          if ($multisite || ($entity->site_guid == $currsite) || (empty($entity->site_guid))) {
            $entitiesList[] = $entity;
            // Add subtype counter
            if ($countbytypes[$type][$stype]) $countbytypes[$type][$stype]++; else $countbytypes[$type][$stype] = 1;
          }
        }
      }
    }
  }
  
  // Traduire et mettre un switch sur les comportements affinés (fulltext ou non, en plus de locale ou non)
  // count($added) : total de résultats (sans les filtres)
  // count($classic_search) : total de résultats classiques (sans les filtres)
  // count($entitiesList) : total des résultats éligibles (filtrés)
  if (count($entitiesList) > 0) $report = count($entitiesList) . " résultats au total en recherche plein texte, dont " . count($classic_search) . " correspondant au tag <em>$tag</em> (en début de liste). ";
  
  
  // Make search result view
  $total = count($entitiesList);
  $offset = get_input("offset", 0);
  $limit = 10;
  $fullview = false;
  $viewToggle = false;
  $multiPage = true;
  
  // Facyla 20110415 : controls the RSS output (avoid injecting un-held content that doesn't fit into XML)
  $viewtype = get_input('view');
  if ($viewtype != "rss") { $body .= '<div class="contentWrapper">' . $report; }
  $limitedEntities = array_slice($entitiesList, $offset, $limit);
  if (sizeof($limitedEntities) > 0) {
    $body .= elgg_view_entity_list($limitedEntities, $total, $offset, $limit, $fullview, $viewToggle, $multiPage);
  } else {
    if ($viewtype != "rss") { $body .= elgg_echo('customsearch:search:no_result'); }
  }
  if ($viewtype != "rss") { $body .= '</div>'; }
  
  // Show search result counter
  $results_found_message = '';
  if ($total && ($viewtype != "rss")) { $results_found_message = sprintf(elgg_echo('customsearch:search:found'), $total); }
  $body .= $results_found_message;
  
  
} else {
  // @todo : pb des mots réservés : cause ?
  if ($dosearch) {
    $body = sprintf(elgg_echo(empty($tag) ? 'customsearch:search:no_result' : 'customsearch:search:too_short'), $search_min_size);
  } else $body .= elgg_echo('customsearch:search:reservedwords');
}


//if ($includemenu && isloggedin()) {
if ($includemenu) {
  // Set up submenus
//  if ($object_types = get_registered_entity_types()) {
  if ($object_types = get_registered_entity_types()) {
    // Ajout des entités non prises en charge mais filtrées (plus pertinent)
    foreach ($whitelist as $otype) {
      if (!in_array($otype, $object_types['object'])) $object_types['object'][] = $otype;
    }
    add_submenu_item(elgg_echo('customsearch:all'), $CONFIG->wwwroot . $searchurl . urlencode($tag) ."&owner_guid=" . urlencode($owner_guid));
    foreach($object_types as $object_type => $subtype_array) {
      if (is_array($subtype_array) && sizeof($subtype_array)) {
        foreach($subtype_array as $object_subtype) {
          $label = 'item:' . $object_type;
          if (!empty($object_subtype)) $label .= ':' . $object_subtype; else $object_subtype= 0;
          global $CONFIG;
          // Add subtype counter
          if (!$countbytypes[$object_type][$object_subtype]) $countbytypes[$object_type][$object_subtype] = 0;
          if (empty($objectType) || ($object_type == $objectType) && (empty($object_subtype) || ($object_subtype == $subtype))) {
            if ($object_type == 'object' && empty($object_subtype)) add_submenu_item(elgg_echo($label), $CONFIG->wwwroot . $searchurl . urlencode($tag) ."&subtype=" . $object_subtype . "&object=". urlencode($object_type) ."&tagtype=" . urlencode($md_type) . "&owner_guid=" . urlencode($owner_guid));
            else add_submenu_item(elgg_echo($label) . ' (' . $countbytypes[$object_type][$object_subtype] . ')', $CONFIG->wwwroot . $searchurl . urlencode($tag) ."&subtype=" . $object_subtype . "&object=". urlencode($object_type) ."&tagtype=" . urlencode($md_type) . "&owner_guid=" . urlencode($owner_guid));
          } else {
            add_submenu_item(elgg_echo($label), $CONFIG->wwwroot . $searchurl . urlencode($tag) ."&subtype=" . $object_subtype . "&object=". urlencode($object_type) ."&tagtype=" . urlencode($md_type) . "&owner_guid=" . urlencode($owner_guid));
          }
        }
      }
    }
  }
}


if (!empty($itemtitle)) $title .= " ($itemtitle)";
$title = elgg_view_title( sprintf(elgg_echo("customsearch:search:title"), $tag) . $title);

if ($searchform) {
  $searchform = '<form id="searchform" action="' . $CONFIG->url . 'pg/search/" method="get">
    <input type="text" size="21" name="tag" value="' . $tag . '" onclick="if (this.value==\'' . elgg_echo("customsearch:search") . '\') { this.value=\'\' }" class="search_input" />
    <input type="submit" value="' . elgg_echo("customsearch:search") . '" class="search_submit_button" />
    </form>';
}

page_draw( elgg_echo('search') . " : $tag", elgg_view_layout('two_column_left_sidebar', '', $searchform . $title . $body) );
