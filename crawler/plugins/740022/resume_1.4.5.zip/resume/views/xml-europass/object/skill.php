      <?php echo $vars['entity']->skilltype; ?>

<?php
/**
$vars['entity']->skilltype
  elgg_echo('resume:skill:' . $vars['entity']->skilltype)
$vars['entity']->title

// pour texte html dans code XML : <![CDATA[    ]]>

