<?php
$page_owner = $vars['owner'];

$body = '<style>
.resume_body_printer { padding:3ex; }
.tabla_idiomas th, .tabla_idiomas td { border:1px solid darkgrey !important; }
</style>';

// -------- BEGIN MAIN PAGE CONTENT ---------
if ((get_context() != 'profile') && (get_context() != "index")) {
  $body .= '<div class="resume">';
  $body .=  "<p class=\"profile_info_edit_buttons\"><a href=\"" . $CONFIG->wwwroot . "pg/profile/" . $page_owner->username . "\")>" . elgg_echo("resume:profile:goto") . "</a></p>";
  $body .=  "<p class=\"profile_info_edit_buttons\"><a href=\"" . $CONFIG->wwwroot . "pg/resumesprintversion/" . $page_owner->username . "\" target=\"_blank\" \">" . elgg_echo("resume:profile:gotoprint") . "</a></p>";
  $body .=  "<p class=\"profile_info_edit_buttons\"><a href=\"" . $CONFIG->wwwroot . "pg/profile/" . $page_owner->username . "?view=xml-europass\" target=\"_blank\" \">" . elgg_echo("resume:profile:xml-europass") . "</a></p>";
  $body .= "<div class=\"clearfloat\"></div>";
  $body .= "<br />";
}

if ((get_plugin_setting('education', 'resume') == 'yes') && (list_user_objects($page_owner->guid, 'education', 0, false, false, false))) {
  $body .= '<div class="contentWrapper resume_contentWrapper" width=716>
      <p><a class="collapsibleboxlink resume_collapsibleboxlink">+</a></p>
      <h3>' . elgg_echo('resume:educations') . '</h3>
      <div style="display:none;" class="collapsible_box resume_collapsible_box">' . list_user_objects($page_owner->guid, 'education', 0, false, false, false) . '</div>
    </div>';
}

if ((get_plugin_setting('workexperience', 'resume') == 'yes') && (list_user_objects($page_owner->guid, 'workexperience', 0, false, false, false))) {
  $body .= '<div class="contentWrapper resume_contentWrapper" width=716>
      <p><a class="collapsibleboxlink resume_collapsibleboxlink">+</a></p>
      <h3>' . elgg_echo('resume:workexperiences') . '</h3>
      <div style="display:none;" class="collapsible_box resume_collapsible_box">' . list_user_objects($page_owner->guid, 'workexperience', 0, false, false, false) . '</div>
    </div>';
}

if ((get_plugin_setting('experience', 'resume') == 'yes') && (list_user_objects($page_owner->guid, 'experience', 0, false, false, false))) {
  $body .= '<div class="contentWrapper resume_contentWrapper" width="716">
      <p><a class="collapsibleboxlink resume_collapsibleboxlink">+</a></p>
      <h3>' . elgg_echo('resume:experiences') . '</h3>
      <div style="display:none;" class="collapsible_box resume_collapsible_box">' . list_user_objects($page_owner->guid, 'experience', 0, false, false, false) . '</div>
    </div>';
}

if ((get_plugin_setting('skill', 'resume') == 'yes') && (list_user_objects($page_owner->guid, 'skill', 0, false, false, false))) {
  $body .= '<div class="contentWrapper resume_contentWrapper" width=716>
      <p><a class="collapsibleboxlink resume_collapsibleboxlink">+</a></p>
      <h3>' . elgg_echo('resume:skills') . '</h3>
      <div style="display:none;" class="collapsible_box resume_collapsible_box">' . list_user_objects($page_owner->guid, 'skill', 0, false, false, false) . '</div>
    </div>';
}

if ((get_plugin_setting('skill_ciiee', 'resume') == 'yes') && (list_user_objects($page_owner->guid, 'skill_ciiee', 0, false, false, false))) {
  $body .= '<div class="contentWrapper resume_contentWrapper" width=716>
      <p><a class="collapsibleboxlink resume_collapsibleboxlink">+</a></p>
      <h3>' . elgg_echo('resume:skill_ciiees') . '</h3>
      <div style="display:none;" class="collapsible_box resume_collapsible_box">' . list_user_objects($page_owner->guid, 'skill_ciiee', 0, false, false, false) . '</div>
    </div>';
}

if ((get_plugin_setting('language', 'resume') == 'yes') && (list_user_objects($page_owner->getGUID(), 'language', 0, true, true, true))) {
  $body .= '<div class="contentWrapper resume_contentWrapper">
      <p><a class="collapsibleboxlink resume_collapsibleboxlink">+</a></p>
      <h3>' . elgg_echo('resume:languages') . '</h3>
      <div style="display:none;" class="collapsible_box resume_collapsible_box_hidden ">';
  // Ultra compact view
  if (get_context() != "index") {
    $body .= '<table class="tabla_idiomas">
      <tr class="t_h">
        <td rowspan="2">' . elgg_echo('resume:languages:language') . '</td>
        <td colspan="2">' . elgg_echo('resume:languages:understanding') . '</td>
        <td colspan="2">' . elgg_echo('resume:languages:speaking') . '</td>
        <td rowspan="2">' . elgg_echo('resume:languages:writing') . '</td>
      </tr>
      <tr class="t_h">
        <td>' . elgg_echo('resume:languages:listening') . '</td>
        <td>' . elgg_echo('resume:languages:reading') . '</td>
        <td>' . elgg_echo('resume:languages:spokeninteraction') . '</td>
        <td>' . elgg_echo('resume:languages:spokenproduction') . '</td>
      </tr>';
  }
  $body .= list_user_objects($page_owner->getGUID(), 'language', 0, true, true, true);
  // Ultra compact view
  if (get_context() != "index") { $body .= '</table>'; }
  $body .= '</div></div>';
}

// Show a message if there aren't any user objects.
if (!list_user_objects($page_owner->getGUID(), 'experience', 0, true, true, true)
    && !list_user_objects($page_owner->getGUID(), 'language', 0, true, true, true)
    && !list_user_objects($page_owner->getGUID(), 'workexperience', 0, true, true, true)
    && !list_user_objects($page_owner->getGUID(), 'education', 0, true, true, true)
    && !list_user_objects($page_owner->getGUID(), 'skill', 0, true, true, true)
    && !list_user_objects($page_owner->getGUID(), 'skill_ciiee', 0, true, true, true)
  ) {
  ?>
    <h3><?php
    if ($page_owner->guid == get_loggedin_user()->guid) {
      echo '<a href="' . $CONFIG->wwwroot . "pg/resumes/" . $page_owner->username . '">' . elgg_echo('resume:noentries:create') . '</a>';
    } else {
      echo elgg_echo('resume:noentries');
    }
    ?>
    </h3>
<?php }

$body .= '</div>';

echo $body;
