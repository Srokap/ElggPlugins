<?php
	/**
	* dislikes
	*
	* @author dislikes
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	$object = $vars['entity'];
	
	//We count the quantity of people that dislikes this.
	$dislikes_no = (int) count_annotations($object->getGUID(), "", "", 'dislike');
	
	if ($object instanceof ElggEntity && isloggedin()) {
		//Do you dislike this object?
		$doyoudislike = false;
		
		//Now we check if the user that is logged in dislikes this object.
		$dislikes_no_by_user = count_annotations($object->getGUID(), "", "", 'dislike', 1, '', get_loggedin_userid());
		if ($dislikes_no_by_user > 0) {
			//You already disliked it
			$doyoudislike = true;
			$annotation = get_annotations($object->getGUID(), "", "", 'dislike', 1, get_loggedin_userid(), 1);
			if (!empty($annotation)) {
				$annotation = array_shift($annotation);
			}
			$link = "{$vars['url']}action/undislike?dislike_id={$annotation->id}" . url_compatible_mode('&');
			$content .=  "<a href=\"$link\">" . elgg_echo('undislike') . "</a> · ";
		} else {
			//You can dislike it
			//always generate missing action tokens
			$link = "{$vars['url']}action/dislike?guid={$object->guid}" . url_compatible_mode('&');
			$end_sentence = ($dislikes_no > 0 ? ' · ' : '');
			$content .=  "<a href=\"$link\">" . elgg_echo('dislike') . "</a>$end_sentence";	
		} // if ($dislikes_no_by_user > 0) {
		
		if ($dislikes_no > 0) {
			
			// If more than two users, and if you are not there then the translation must finish with: 3 people dislikes it (dislike:lotofpeopledislikethis)
			// If more than two users, and you are in that list then the translation must finish with: you and 2 more people dislikes it.
			
			// If there are two users that dislikes it and you are not then the translation must be: user1 and user2 dislikes it. (dislike:others2dislikethis)
			// If there are two users that dislikes it and you are not then the translation must be: user1 and you dislikes it. (dislike:otherandyoudislikethis)
			
			// If just one user dislikes it and that user is you then it must say: You dislikes it. (dislike:youdislikethis)
			// If just one user dislikes it and that user is not you then it must say: user1 dislikes it. (dislike:otherdislikesthis)
			
			if ($dislikes_no < 3) {
				$annotations = get_annotations($object->getGUID(), "", "", 'dislike', "", "", $dislikes_no);
				
				$first_annotation = current($annotations);
				$user = get_entity($first_annotation->owner_guid);
				$username = "<a href=\"{$user->getURL()}\">$user->name</a>"; 
				
				if ($dislikes_no == 1) {
					if ($doyoudislike) {
						$content .= elgg_echo("dislike:youdislikethis");
					} else {
						$content .= sprintf(elgg_echo("dislike:otherdislikesthis"), $username);
					}
				} else {
					$last_annotation = end($annotations);
					$user2 = get_entity($last_annotation->owner_guid);
					$username2 = "<a href=\"{$user2->getURL()}\">$user2->name</a>";
					
					//Dislikes == 2
					if ($user == get_loggedin_user() || $user2 == get_loggedin_user()) {
						//TODO Make it better.
						if ($user2 == get_loggedin_user()) {
							$aux = $username;
							$username = $username2;
							$username2 = $aux;  
						}
						$content .= sprintf(elgg_echo("dislike:otherandyoudislikethis"), $username2);
					} else {
						$content .= sprintf(elgg_echo("dislike:others2dislikethis"), $username2, $username);
					}
				} //if ($dislikes_no == 1) {
			} else {
				if ($doyoudislike) {
					$content .= sprintf(elgg_echo("dislike:youandalotofpeopledislikethis"), "<strong>" . sprintf(elgg_echo("dislike:others"),$dislikes_no-1) . "</strong>");
				} else {
					$content .= sprintf(elgg_echo("dislike:lotofpeopledislikethis"), "<strong>" . sprintf(elgg_echo("dislike:others"),$dislikes_no). "</strong>");
				}
			} //if ($dislikes_no < 3) {
		}
		echo "<div class='dislike'>$content</div><div style='clear:both;'></div>";
	} //if ($object instanceof ElggEntity && isloggedin())
