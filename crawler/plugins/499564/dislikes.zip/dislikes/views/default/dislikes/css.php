<?php
	/**
	* dislikes
	*
	* @author dislikes
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/
?>
        .like {
float: left;
                background: url(<?php echo $vars['url' ] ?>mod/likes/graphics/like.gif) no-repeat;
                margin: 4px 0 4px 0px;
                padding: 0px 0 0 17px;
        }

	.dislike {
float: left;
		background: url(<?php echo $vars['url' ] ?>mod/dislikes/graphics/dislike.gif) no-repeat;
		margin: 4px 0 4px 0px;
		padding: 0px 0 0 17px;
	}
	
	.river_item .dislike {
		font-size: 0.9em;
		margin: 4px 0 0 15px;
		padding: 2px 0 0 17px;
	}
	
	.dislike strong {
		font-weight: bolder;
	}
	
