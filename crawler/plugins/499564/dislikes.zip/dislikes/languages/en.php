<?php
	/**
	* dislikes
	*
	* @author dislikes
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	$english = array(
			'dislikes:admin' => 'Dislike Settings',
			'dislikes:admin:subtitle' => 'Do you dislike show the "dislike this" button for...',
			
			'dislike:show:thewire' => 'the wire on the river?',
			'dislike:show:messageboard' => 'messageboard on the river?',
			'dislike:show:bookmarks' => 'bookmarks on the river?',
			'dislike:show:blog' => 'blog on the river?',
			'dislike:show:file' => 'file on the river?',
			'dislike:show:page' => 'page on the river?',
			'dislike:show:topic' => 'discussion topic on the river?',
			
			'dislike' => 'Dislike',
			'undislike' => 'Undislike',
	
			'dislike:youdislikethis' => 'You dislike this.',
			'dislike:otherdislikesthis' => '%s dislikes this.',
	
			'dislike:otherandyoudislikethis' => 'You and %s dislike this.',
			'dislike:others2dislikethis' => '%s and %s dislike this.',
	
			'dislike:others' => '%s others',
	
			'dislike:lotofpeopledislikethis' => '%s people dislike this.',
			'dislike:youandalotofpeopledislikethis' => 'You and %s dislike this.',
	
			/*Actions*/
			'dislike:posted' => 'Your "dislike" was successfully posted.',
			'dislike:failure' => 'An unexpected error occurred when adding your "dislike". Please try again.',

			'dislike:deleted' => 'Your "dislike" was successfully deleted.',
			'dislike:notdeleted' => 'Sorry, we could not delete this "dislike".',
	
	);
					
	add_translation("en",$english);
?>