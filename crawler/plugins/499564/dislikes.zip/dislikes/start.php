<?php
	/**
	* dislikes
	*
	* @author dislikes
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	function dislikes_init() {
		global $CONFIG;
		if (get_plugin_setting('show_thewire', 'dislikes') != 'no') {
			extend_view('river/object/thewire/create', 'dislikes/river/item');
		}
		if (get_plugin_setting('show_messageboard', 'dislikes') != 'no') {
			extend_view('river/object/messageboard/create', 'dislikes/river/item');
		}
		if (get_plugin_setting('show_bookmarks', 'dislikes') != 'no') {
			extend_view('river/object/bookmarks/create', 'dislikes/river/item');
		}
		if (get_plugin_setting('show_file', 'dislikes') != 'no') {
			extend_view('river/object/file/create', 'dislikes/river/item');
		}
		if (get_plugin_setting('show_blog', 'dislikes') != 'no') {
			extend_view('river/object/blog/create', 'dislikes/river/item');
		}
		if (get_plugin_setting('show_page', 'dislikes') != 'no') {
			extend_view('river/object/page/create', 'dislikes/river/item');
		}
		if (get_plugin_setting('show_topic', 'dislikes') != 'no') {
			extend_view('river/forum/topic/create', 'dislikes/river/item');
		}
		
		extend_view('css', 'dislikes/css');
		
		//Page Handler
		register_page_handler('dislikes','dislikes_page_handler');
		
		//Actions
		register_action("dislike",false, $CONFIG->pluginspath . "/dislikes/actions/dislike.php");
		register_action("undislike",false, $CONFIG->pluginspath . "/dislikes/actions/undislike.php");
	}
	
	function dislikes_page_handler($page) {
		global $CONFIG;
		if (isset($page[0])) {
			switch($page[0]) {
				case "admin":
					!@include_once(dirname(__FILE__) . "/admin.php");
					return false;
          			break;
			}
		}
	}
	
	function dislikes_setup() {
		global $CONFIG;
		if (get_context()=='admin') {
    		add_submenu_item(elgg_echo("dislikes:admin"), $CONFIG->wwwroot . "pg/dislikes/admin" );
		}
	}
	
	//Generate url for accept action on elgg 1.7
	if(!is_callable('url_compatible_mode')) {
	    function url_compatible_mode($hook = '?') {
	    	$now = time();
			$query[] = "__elgg_ts=" . $now;
			$query[] = "__elgg_token=" . generate_action_token($now);
			$query_string = implode("&", $query);
			return $hook . $query_string;
	    }
	}
	
	register_elgg_event_handler('init','system','dislikes_init');
	register_elgg_event_handler('pagesetup','system','dislikes_setup');
