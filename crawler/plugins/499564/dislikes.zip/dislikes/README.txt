dislikes v0.1
Copyright (c) 2010 Keetup Development

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307  
USA


** ABOUT **
This module allows to marc the objects as "I dislike it" as facebook style ;) 
 
dislikes is released under the GNU Public License (GPL), which
is supplied in this distribution as LICENSE.


** CONTRIBUTORS **

See CONTRIBUTORS.txt for the development credits.


** LICENSE INFORMATION **

This software is governed under rights, privileges, and restrictions in 
addition to those provided by the GPL v2.  Please carefully read the
LICENSE.txt file for more information.


** INSTALLATION **

	* Unzip the file into the elgg/mods/ directory.

	* Go to your Elgg tools administration section, find the new tool, and 
	  enable it.
	  
	* Enjoy!
	  
	 
** TODO **
	  
	* Nothing TODO at the moment.
	
	
** CHANGES **

	* No CHANGES at the moment.