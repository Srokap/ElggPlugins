<?php
	/**
	* dislikes
	*
	* @author dislikes
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	// Ensure we're logged in
		if (!isloggedin()) {
			forward();
		}
		
		$forward_url = "";
		//Forward
		if (isset($_SERVER['HTTP_REFERER'])) {
			//Go to referer page
			$forward_url = $_SERVER['HTTP_REFERER'];	
		}

	// Make sure we can get the "dislike" in question
		$dislike_id = (int) get_input('dislike_id');
		if ($dislike = get_annotation($dislike_id)) {
	
			$entity = get_entity($dislike->entity_guid);
	
			if ($dislike->canEdit()) {
				$dislike->delete();
				system_message(elgg_echo("dislike:deleted"));
				forward($forward_url);
			}
		}
		
		register_error(elgg_echo("dislike:notdeleted"));
	//Go to home
		forward($forward_url);