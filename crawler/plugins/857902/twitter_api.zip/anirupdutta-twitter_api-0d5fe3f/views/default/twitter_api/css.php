<?php
/**
 * Elgg Twitter API CSS
 */
?>

#login_with_twitter {
	padding: 10px 0 0 0;
}

.twitter-secret {
	width: 400px;
}