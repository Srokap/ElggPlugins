First of all, I'd like to mention that all credit for this plugin belongs to its creator, Diego Andr�s Ram�rez Arag�n. Be sure to support him by visiting http://www.somosmas.org/ - He's a great guy who creates amazing Elgg plugins! Groupextended is an extremely useful plugin and has become a very important tool for many people who run Elgg!

ABOUT THIS PLUGIN:
This release of this plugin is only for the purpose of better explanation on how to add different types of "group types". Many people have had quite a bit of trouble understanding how to set up "handlers", deal with "functions", etc. etc. As I tell exactly step-by-step instructions, hopefully you get the answer you're looking for with this release!

By default, this plugin came with the addition of "Network" as well as "Organization", to go along with just a standard "Group" for you to choose from as a "Group Type". Let's say you want to add an additional group type to go along with these, something like "Corporation". This meaning that when you go to create a group, you want to see the options "Network", "Organization", "Group" and "Corporation". First thing is first...


A. ***MODIFYING THE LANGUAGE FILE***

From the groupextended mod root directory, go to the "languages" folder, and open "en.php". Here, let's examine lines 10 through 12, they should look like this:

--------------------------------------------------------------------------
'groupextended:type:network'=>"Network",
'groupextended:type:organization'=>"Organization",
'groupextended:type:group'=>"Group",
--------------------------------------------------------------------------

What we want to do here is create one of these for "Corporation", so it should look like this:

--------------------------------------------------------------------------
'groupextended:type:corporation'=>"Corporation",
--------------------------------------------------------------------------

All we need to do is insert this under the other three, on line 13.

That's it for this file, let's move on to...



B. ***CREATING THE PHP FILE****

If you go into the root of the groupextended mod folder, you'll see a few PHP files that read "networks.php", and "organizations.php". We need to create one of these PHP files for "Corporation", and call it "corporation.php". Now, I am by no means a programmer, but if you look at the "networks.php" and the "organizations.php" files, they do have some differences... However, if you use "organizations.php" as a template, it will work fine. It's what I did and I have had absolutely no problems thus far! All right, so here is what "organizations.php" will look like word-for-word:

----------------------------------------------------------------------------------------------
<?php
/**
 * Elgg groupextended plugin's organizations list
 *
 * @package ElggGroupExtended
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Diego Andr�s Ram�rez Arag�n <diego@somosmas.org>
 * @copyright Corporaci�n Somos m�s - 2008
 * @link http://www.somosmas.org
 */

require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

$limit = get_input("limit", 7);
$offset = get_input("offset", 0);
$tag = get_input("tag");


// Get objects
$context = get_context();

set_context('search');
if ($tag != ""){
  $objects = list_entities_from_metadata('tags',$tag,'group',"","", $limit, false);
}else{
  $objects = list_entities_from_metadata('group_type',"groupextended:type:organization",'group',"","", $limit, false,false);
  }
set_context($context);

$title = sprintf(elgg_echo("organizations:all"),page_owner_entity()->name);
$area2 = elgg_view_title($title);
$area2 .= $objects;
$body = elgg_view_layout('two_column_left_sidebar',$area1, $area2);

// Finally draw the page
page_draw($title, $body);



?>
-------------------------------------------------------------------------------------------




What we need to do is change anywhere that says "organization" to the word "corporation". So our final result will look like this:



----------------------------------------------------------------------------------------------
<?php
/**
 * Elgg groupextended plugin's Corporation list
 *
 * @package ElggGroupExtended
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Diego Andr�s Ram�rez Arag�n <diego@somosmas.org>
 * @copyright Corporaci�n Somos m�s - 2008
 * @link http://www.somosmas.org
 */

require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

$limit = get_input("limit", 7);
$offset = get_input("offset", 0);
$tag = get_input("tag");


// Get objects
$context = get_context();

set_context('search');
if ($tag != ""){
  $objects = list_entities_from_metadata('tags',$tag,'group',"","", $limit, false);
}else{
  $objects = list_entities_from_metadata('group_type',"groupextended:type:corporation",'group',"","", $limit, false,false);
  }
set_context($context);

$title = sprintf(elgg_echo("corporation:all"),page_owner_entity()->name);
$area2 = elgg_view_title($title);
$area2 .= $objects;
$body = elgg_view_layout('two_column_left_sidebar',$area1, $area2);

// Finally draw the page
page_draw($title, $body);



?>
-------------------------------------------------------------------------------------------





Save this php file as "corporation.php". That's it for this, now let's move on to...






C. *** MODIFYING "Start.php" ***

- From the root of the groupextended mod folder, let's open "start.php". If you use Dreamweaver like I do, if you look somewhere around line 17, there is a new function that begins, the line should look like this:

function groupextended_init(){

If you continue down the page, you'll see a lot of code that starts with the prefix "register_". If you look somewhere around line 40 or 41, there should be two page handlers that look like this:

register_page_handler('networks','networks_page_handler');
register_page_handler('organizations','organizations_page_handler');

What we want to do is create a page handler for our "Corporation" group type that we'd like to add, so we'd create a page handler that looks exactly like this:

register_page_handler('corporation','corporation_page_handler');

We want to place this new "Corporation" page handler one line under where the page handler for "organizations" is. On my version of Dreamweaver, the "organizations" page handler is on line 41, so I'd put the page handler for "Corporation" on line 42. Make sure that you have the code exactly like my reference above, or else you may encounter syntax errors. 

All right, so we've registered our page handler for "Corporation", now what else do we have to do? It's time to create an elgg_echo that uses the text element that we created in the "en.php" file (within the language folder). So, while you're still in "start.php", scroll down to somewhere around line 105 and you'll see code that looks exactly like this:

--------------------------------------------------------------------------
elgg_echo("groupextended:type:network")=>"groupextended:type:network",
elgg_echo("groupextended:type:organization")=>"groupextended:type:organization",
elgg_echo("groupextended:type:group")=>"groupextended:type:group"
--------------------------------------------------------------------------

What we want to do is create an elgg_echo statement for our "Corporation" group type to go along with the other group types. This means we'll create an elgg_echo that looks exactly like this:

--------------------------------------------------------------------------
elgg_echo("groupextended:type:corporation")=>"groupextended:type:corporation",
--------------------------------------------------------------------------

We will insert this one line under the elgg_echo for "group". The elgg_echo for "group" shows on line 107, so I have inserted the elgg_echo for "corporation" on line 108.

OK, so we've created our text in the "en.php" file, we've went over to the "start.php" file and have registered a page handler for "Corporation", and then created an elgg_echo to display our "Corporation" text, what's next? For the purpose of explanation, scroll down and take a look at a couple different functions - On my screen the first function goes from line 301-317 and it reads:

--------------------------------------------------------------------------
/**
 * Networks page handler
 *
 * @param mixed $page
 */
function networks_page_handler($page){
  global $CONFIG;
  if (isset($page[0])){
    switch($page[0]){
      case "world":
        set_context('networks');
        set_page_owner(0);
        include($CONFIG->pluginspath . "groupextended/networks.php");
        break;
    }
  }
}
--------------------------------------------------------------------------



The next function we should look at is between lines 319 and 335 that read:



--------------------------------------------------------------------------
/**
 * Organizations page handler
 *
 * @param mixed $page
 */
function organizations_page_handler($page){
  global $CONFIG;
  if (isset($page[0])){
    switch($page[0]){
      case "world":
        set_context('organizations');
        set_page_owner(0);
        include($CONFIG->pluginspath . "groupextended/organizations.php");
        break;
    }
  }
}
--------------------------------------------------------------------------



If you look at the way these are compiled, they are the same code, just replacing the word "networks" with "organizations" on the second one (right above this sentence). So we want to make one of these for "Corporation" and insert it about a line or two under the one for "organizations (the one right above this sentence). Make sure that you insert in the correct web site address or else this will not work properly - If you look down below, you'll see "groupextended/corporation.php", just make sure that the php file matches the one that you created for "Corporation" located in the root of the groupextended mod directory. So it will look like this:

--------------------------------------------------------------------------
/**
 * Corporation page handler
 *
 * @param mixed $page
 */
function corporation_page_handler($page){
  global $CONFIG;
  if (isset($page[0])){
    switch($page[0]){
      case "world":
        set_context('corporation');
        set_page_owner(0);
        include($CONFIG->pluginspath . "groupextended/corporation.php");
        break;
    }
  }
}
--------------------------------------------------------------------------




Make sure that you keep the last few lines of php code that look like this:

--------------------------------------------------------------------------
register_elgg_event_handler('init','system','groupextended_init');
register_elgg_event_handler('pagesetup','system','groupextended_pagesetup');

?>
--------------------------------------------------------------------------



*** WE'RE DONE! ***
If you've done everything correctly, it should work like a charm! Go take a look on your elgg site and you should see the new group types!