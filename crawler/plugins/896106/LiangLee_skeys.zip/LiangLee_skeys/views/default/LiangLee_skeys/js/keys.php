<?php
/* LiangLee Shortcuts Keys
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @package LiangLeeFramework( LEFW )
 * @subpackage LiangLee Shortcuts Keys
 * @author Liang Lee
 * @copyright Copyright (c) 2012, Liang Lee
 * @File keys.php
 */
echo "<style type=\"text/css\">\n"; 
echo "<!--\n"; 
echo ".LiangLee_Skeys_footer {color: #999999}\n"; 
echo "-->\n"; 
echo "</style>\n"; 
echo "	<script type=\"text/javascript\">\n"; 
echo "		$(document).ready(function() {\n"; 
echo "	\n"; 
echo "			$(\"#lianglee_sekys_info\").fancybox({\n"; 
echo "				'titlePosition'		: 'inside',\n"; 
echo "				'transitionIn'		: 'none',\n"; 
echo "				'transitionOut'		: 'none'\n"; 
echo "			});\n"; 
echo "		});\n"; 
echo "	</script>\n";
?>