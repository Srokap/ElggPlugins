<?php
/* LiangLee Shortcuts keys
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @package LiangLeeFramework( LEFW )
 * @subpackage LiangLee Shortcuts keys
 * @author Liang Lee
 * @copyright Copyright (c) 2012, Liang Lee
 * @File version.php
 */

$LiangLee_version = '29062012';
$LiangLee_release = '1.1.0'; 
