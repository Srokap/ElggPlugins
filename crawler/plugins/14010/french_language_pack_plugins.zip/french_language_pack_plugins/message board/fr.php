<?php

	$french = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messageboard:board' => "Messagerie",
			'messageboard:messageboard' => "Messagerie",
			'messageboard:viewall' => "Voir",
			'messageboard:postit' => "Afficher",
			'messageboard:history' => "Historique",
			'messageboard:none' => "Il n'y a pas encore de message dans cette messagerie",
			'messageboard:num_display' => "Nombre de messages &agrave; afficher",
			'messageboard:desc' => "Vous pouvez incorporer cette messagerie &agrave; votre profil afin que d'autres puissent commenter.",
			
         /**
	     * Message board widget river
	     **/
	        
	        'messageboard:river:annotate' => "%s a un nouveau commentaire dans sa messagerie",
	        'messageboard:river:create' => "%a a ajout&eacute; un widget de messagerie",
	        'messageboard:river:update' => "%s a mis &agrave; jour son widget de messagerie",
			
		/**
		 * Status messages
		 */
	
			'messageboard:posted' => "Vous avez r&eacute;ussi &agrave; afficher un message sur la messagerie.",
			'messageboard:deleted' => "Vous avez r&eacute;ussi &agrave; rayer le message.",
	
		/**
		 * Email messages
		 */
	
			'messageboard:email:subject' => 'Vous avez un nouveau commentaire sur votre messagerie!',
			'messageboard:email:body' => "Vous avez un nouveau commentaire de messagerie de %s. Il est r&eacute;dig&eacute; comme suit :

			
%s


Pour voir vos commentaires de messagerie, cliquez ici :

	%s

Pour voir le profil de %s, cliquez ici :

	%s

Vous ne pouvez pas r&eacute;pondre &agrave; ce message de courriel.",
	
		/**
		 * Error messages
		 */
	
			'messageboard:blank' => "D&eacute;sol&eacute;s : vous devez inscrire quelque chose dans la zone du message pour qu'elle puisse �tre sauvegard&eacute;e.",
			'messageboard:notfound' => "D&eacute;sol&eacute;s : nous n'avons pas r&eacute;ussi &agrave; trouver l'article recherch&eacute;.",
			'messageboard:notdeleted' => "D&eacute;sol&eacute;s : nous n'avons pas r&eacute;ussi &agrave; supprimer ce message.",
	     
			'messageboard:failure' => "Une erreur inattendue s'est produite pendant l'addition de votre message. Veuillez essayer de nouveau.",
	
	);
					
	add_translation("fr",$french);

?>