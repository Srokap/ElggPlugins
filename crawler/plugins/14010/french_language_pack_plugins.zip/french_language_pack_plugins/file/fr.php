<?php
	/**
	 * Elgg file plugin language pack
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$french = array(
	
		/**
		 * Menu items and titles
		 */
	
			'file' => "Fichiers",
			'files' => "Fichiers",
			'file:yours' => "Vos Fichiers",
			'file:yours:friends' => "Fichiers de vos ami-e-s",
			'file:user' => "Fichiers de %s",
			'file:friends' => "Fichiers des ami-e-s de %s",
			'file:all' => "Tous les fichiers du site",
			'file:edit' => "Modifier fichier",
			'file:more' => "Autres fichiers",
			'file:list' => "Liste",
			'file:group' => "Fichiers de groupe",
			'file:gallery' => "Gallerie",
			'file:gallery_list' => "Gallerie ou liste",
			'file:num_files' => "Nombre de fichiers &agrave; afficher",
			'file:user:gallery'=>'Voir la gallerie de %s', 
	
			'file:upload' => "T&eacute;l&eacute;charger un fichier",
			
			'file:file' => "Fichier",
			'file:title' => "Titre",
			'file:desc' => "Description",
			'file:tags' => "Mot-cl&eacute;",
	
			'file:types' => "Types de fichiers t&eacute;l&eacute;charg&eacute;s",
	
			'file:type:all' => "Tous les fichiers",
			'file:type:video' => "Vid&eacute;os",
			'file:type:document' => "Documents",
			'file:type:audio' => "Audio",
			'file:type:image' => "Photos",
			'file:type:general' => "G&eacute;n&eacute;ral",
	
			'file:user:type:video' => "Vid&eacute;os de %s",
			'file:user:type:document' => "Documents de %s",
			'file:user:type:audio' => "Audio de %s",
			'file:user:type:image' => "Photos de %s",
			'file:user:type:general' => "Fichiers g&eacute;n&eacute;raux de %s",
	
			'file:friends:type:video' => "Vid&eacute;os de vos ami-e-s",
			'file:friends:type:document' => "Documents de vos ami-e-s",
			'file:friends:type:audio' => "Audio de vos ami-e-s",
			'file:friends:type:image' => "Photos de vos ami-e-s",
			'file:friends:type:general' => "Fichiers g&eacute;n&eacute;raux de vos ami-e-s",
	
			'file:widget' => "Widget de fichier",
			'file:widget:description' => "Montrer les fichiers les plus r&eacute;cents",
	
			'file:download' => "T&eacute;l&eacute;chargher ceci",
	
			'file:delete:confirm' => "&Ecirc;tes-vous s�r-e de vouloir supprimer ce fichier?",
			
			'file:tagcloud' => "Nuage de mots-cl&eacute;s",
	
			'file:display:number' => "Nombre de fichiers &agrave; afficher",
	
			'file:river:created' => "Fichiers t&eacute;l&eacute;charg&eacute;s par %s",
			'file:river:item' => "un Fichier",
			'file:river:annotate' => "Fichier sur lequel %s a exprim&eacute; un commentaire",

			'item:object:file' => 'Fichier',
			
	    /**
		 * Embed media
		 **/
		 
		    'file:embed' => "Int&eacute;grer des m&eacute;dias",
		    'file:embedall' => "Tous",
	
		/**
		 * Status messages
		 */
	
			'file:saved' => "Votre fichier a bien &eacute;t&eacute; sauvegard&eacute;.",
			'file:deleted' => "Votre fichier a bien &eacute;t&eacute; supprim&eacute;.",
	
		/**
		 * Error messages
		 */
	
			'file:none' => "Nous ne pouvons pas trouver de fichier pour le moment.",
			'file:uploadfailed' => "D&eacute;sol&eacute;s : nous n'avons pas pu sauvegarder votre fichier.",
			'file:downloadfailed' => "D&eacute;sol&eacute;s : ce fichier n'est pas disponible pour le moment.",
			'file:deletefailed' => "Votre fichier ne peut pas �tre supprim&eacute; pour le moment.",
	
	);
					
	add_translation("fr",$french);
?>