<?php
	/**
	 * Elgg groups plugin language pack
	 * 
	 * @package ElggGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$french = array(
	
		/**
		 * Menu items and titles
		 */
			
			'groups' => "Groupes",
			'groups:owned' => "Groupes qui vous appartiennent",
			'groups:yours' => "Vos groupes",
			'groups:user' => "Groupes de %s",
			'groups:all' => "Tous les groupes du site",
			'groups:new' => "Cr&eacute;er un groupe",
			'groups:edit' => "Modifier un groupe",
	
			'groups:icon' => 'Ic&ocirc;ne de groupe (ne rien inscrire pour laisser inchang&eacute;)',
			'groups:name' => 'Nom du groupe',
			'groups:username' => 'Nom court du groupe (en URL, caract&agrave;res alphanum&eacute;riques seulement)',
			'groups:description' => 'Description',
			'groups:briefdescription' => 'Br&agrave;ve description',
			'groups:interests' => 'Int&eacute;r&ecirc;ts',
			'groups:website' => 'Site Web',
			'groups:members' => 'Membres du groupe',
			'groups:membership' => "Membres",
			'groups:access' => "Permissions d'acc&agrave;s",
			'groups:owner' => "Propri&eacute;taire",
	        'groups:widget:num_display' => 'Nombre de groupes &agrave; afficher',
	        'groups:widget:membership' => 'Membres des groupes',
	        'groups:widgets:description' => 'Afficher les groupes dont je fais partie avec mon profil',
			'groups:noaccess' => "Pas d'acc&agrave;s au groupe",
			'groups:cantedit' => 'Vous ne pouvez pas modifier ce groupe',
			'groups:saved' => 'Groupe sauvegard&eacute;',
	
			'groups:joinrequest' => "Demande d'adh&eacute;sion au groupe",
			'groups:join' => 'Adh&eacute;rer au groupe',
			'groups:leave' => 'Quitter le groupe',
			'groups:invite' => 'Invitez des amis',
			'groups:inviteto' => "Invitez des amis chez %s",
			'groups:nofriends' => "Aucun de vos ami-e-s n'a pas &eacute;t&eacute; invit&eacute; &agrave; ce groupe ",
	
			'groups:group' => "Groupe",
			
			'item:object:groupforumtopic' => "Sujets du forum",
	
			/*
			  Group forum strings
			*/
			
			'groups:forum' => 'Forum de groupe',
			'groups:addtopic' => 'Ajouter un sujet',
			'groups:forumlatest' => 'Forum le plus r&eacute;cent',
			'groups:latestdiscussion' => 'Discussion la plus r&eacute;cente',
			'groupspost:success' => 'Votre commentaire a &eacute;t&eacute; avec succ&agrave;s signal&eacute;',
			'groups:alldiscussion' => 'Message sur le sujet',
			'groups:edittopic' => 'Modifier le sujet',
			'groups:topicmessage' => 'Message sur le sujet',
			'groups:topicstatus' => 'Situation du sujet',
			'groups:reply' => 'Afficher un commentaire',
			'groups:topic' => 'Sujet',
			'groups:posts' => 'Articles affich&eacute;s',
			'groups:lastperson' => 'Derni&agrave;re personne',
			'groups:when' => 'Quand',
			'grouptopic:notcreated' => "Aucun sujet n'a &eacute;t&eacute; cr&eacute;&eacute;",
			'groups:topicopen' => 'Ouvert',
			'groups:topicclosed' => 'Ferm&eacute;',
			'groups:topicresolved' => 'R&eacute;gl&eacute;',
			'grouptopic:created' => 'Votre sujet a &eacute;t&eacute; cr&eacute;&eacute;.',
			'groupstopic:deleted' => 'Le sujet a &eacute;t&eacute; supprim&eacute;.',
			'groups:topicsticky' => '&eacute;pineux',
			'groups:topicisclosed' => 'Ce sujet est ferm&eacute;.',
			'groups:topiccloseddesc' => "Ce sujet a &eacute;t&eacute; ferm&eacute; et aucun nouveau commentaire n'est accept&eacute;.",
			'grouptopic:error' => "Votre sujet de groupe n'a pas pu &ecirc;tre cr&eacute;&eacute;. Veuillez essayer de nouveau ou communiquer avec un administrateur du syst&agrave;me.",
	
			'groups:privategroup' => 'Ce groupe est priv&eacute;; il faut y adh&eacute;rer.',
			'groups:notitle' => 'Les groupes doivent avoir un titre',
			'groups:cantjoin' => 'Vous ne pouvez pas adh&eacute;rer au groupe',
			'groups:cantleave' => "Vous n'avez pas r&eacute;ussi &agrave; quitter le groupe",
			'groups:addedtogroup' => "L'usager a &eacute;t&eacute; ajout&eacute; au groupe",
			'groups:joinrequestnotmade' => "La demande d'adh&eacute;sion n'a pas pu &ecirc;tre pr&eacute;sent&eacute;e",
			'groups:joinrequestmade' => "La demande d'adh&eacute;sion au groupe a &eacute;t&eacute; approuv&eacute;e",
			'groups:joined' => 'Vous avez adh&eacute;r&eacute; au groupe!',
			'groups:left' => 'Vous avez quitt&eacute; le groupe',
			'groups:notowner' => "D&eacute;sol&eacute;s, mais vous n'&ecirc;tes pas le propri&eacute;taire de ce groupe.",
			'groups:alreadymember' => 'Vous faites d&eacute;j&agrave; partie de ce groupe!',
			'groups:userinvited' => "L'usge a &eacute;t&eacute; invit&eacute;",
			'groups:usernotinvited' => "L'usage n'a pas pu &ecirc;tre invit&eacute;.",
	
			'groups:invite:subject' => "%s, vous avez &eacute;t&eacute; invit&eacute; &agrave; vous joindre &agrave; %s!",
			'groups:invite:body' => "Bonjour, %s,

Vous avez &eacute;t&eacute; invit&eacute; &agrave; vous joindre au groupe %s. Cliquez ci-dessous pour confirmer:

%s",

			'groups:welcome:subject' => "Bienvenue au groupe %s!",
			'groups:welcome:body' => "Bonjour, %s!
		
Vous faites maintenant partie du groupe %s! Cliquez ci-dessous pour commencer &agrave; afficher!

%s",
	
			'groups:request:subject' => "%s vous a demand&eacute; de vous joindre &agrave; %s",
			'groups:request:body' => "Bonjour, %s,

%s a vous demand&eacute; de vous joindre au groupe %s. Cliquez ci-dessous pour voir votre profil :

%s

ou cliquez cidessous pour confirmer la demande :

%s",
	
			'groups:river:member' => 'fait maintenant partie du',
	
			'groups:nowidgets' => "Aucun widget n'a &eacute;t&eacute; d&eacute;fini pour ce groupe.",
	
	
			'groups:widgets:members:title' => 'Membres des groupes',
			'groups:widgets:members:description' => "Liste des membres d'un groupe",
			'groups:widgets:members:label:displaynum' => "Liste des membres d'un groupe",
			'groups:widgets:members:label:pleaseedit' => 'Veuillez configurer ce widget',
	
			'groups:widgets:entities:title' => "Objet du groupe",
			'groups:widgets:entities:description' => "Liste des objets gard&eacute;s par ce groupe",
			'groups:widgets:entities:label:displaynum' => "Liste des objets d'un groupe",
			'groups:widgets:entities:label:pleaseedit' => 'Veuillez confidurer ce widget',
		
			'groups:forumtopic:edited' => 'Le forum a &eacute;t&eacute; modifi&eacute;.',
	);
					
	add_translation("fr",$french);
?>