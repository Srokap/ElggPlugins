<?php

	$french = array(
	
		/**
		 * Menu items and titles
		 */
	
			'blog' => "Blog",
			'blogs' => "Blogs",
			'blog:user' => "blog de %s",
			'blog:user:friends' => "Blog d'un-e ami-e de %s",
			'blog:your' => "Votre blogue",
			'blog:posttitle' => "Blogue de %s : %s",
			'blog:friends' => "Blogues d'ami-e-s",
			'blog:yourfriends' => "Blogues les plus r&eacute;cents de vos ami-e-s",
			'blog:everyone' => "Tous les blogues du site",
	
			'blog:read' => "Lire blogue",
	
			'blog:addpost' => "R&eacute;diger un article de blogue",
			'blog:editpost' => "Modifier un article de blogue",
	
			'blog:text' => "Texte de blogue",
	
			'blog:strapline' => "%s",
			
			'item:object:blog' => 'Articles de blogue',
	
			
         /**
	     * Blog river
	     **/
	        
	        //generic terms to use
	        'blog:river:created' => "%s a &eacute;crit",
	        'blog:river:updated' => "%s a mis &agrave; jour",
	        'blog:river:posted' => "%s a affich&eacute;",
	        
	        //these get inserted into the river links to take the user to the entity
	        'blog:river:create' => "nouvel article de blogue.",
	        'blog:river:update' => "article de blogue.",
	        'blog:river:annotate:create' => "commentaire sur un article de blogue.",
			
	
		/**
		 * Status messages
		 */
	
			'blog:posted' => "votre artiche de blogue a &eacute;t&eacute; affich&eacute;.",
			'blog:deleted' => "votre article de blogue a &eacute;t&eacute; ray&eacute;.",
	
		/**
		 * Error messages
		 */
	
			'blog:save:failure' => "Votre article de blogue n'a pas pu &ecirc;tre sauvegard&eacute;. Veuillez essayer de nouveau.",
			'blog:blank' => "D&eacute;sol&eacute;s : vous devez &eacute;tablir un titre et le corps du message pour pouvoir pr&eacute;senter un article.",
			'blog:notfound' => "D&eacute;sol&eacute;s : nous n'avons pas pu trouver l'article de blogue en question.",
			'blog:notdeleted' => "D&eacute;sol&eacute;s : nous n'avons pas pu rayer cet article de blogue.",
	
	);
					
	add_translation("fr",$french);

?>