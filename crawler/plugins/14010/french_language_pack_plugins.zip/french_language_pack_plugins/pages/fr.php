<?php
	/**
	 * Elgg pages plugin language pack
	 * 
	 * @package ElggPages
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$french = array(
	
		/**
		 * Menu items and titles
		 */
			
			'pages' => "Pages",
			'pages:yours' => "Vos pages",
			'pages:user' => "Accueil aux pages",
			'pages:group' => "Pages de %s",
			'pages:all' => "Toutes les pages du site",
			'pages:new' => "Nouvelle page",
			'pages:groupprofile' => "Pages de groupe",
			'pages:edit' => "Modifier cette page",
			'pages:delete' => "Supprimer cette page",
			'pages:history' => "Historique de la page",
			'pages:view' => "Voir la page",
			'pages:welcome' => "Modifier le message d'accueil",
			'pages:welcomeerror' => "Votre message d'accueil n'a pas pu &ecirc;tre sauvegard&eacute;",
			'pages:welcomeposted' => "Votre message d'accueil sera affich&eacute;",
			'pages:navigation' => "Navigation de page",
	
			'item:object:page_top' => "Pages du haut",
			'item:object:page' => "Pages",
			'item:object:pages_welcome' => "Blocs d'accueil aux pages",
	
	
		/**
		 * Form fields
		 */
	
			'pages:title' => "Titre des pages",
			'pages:description' => "Votre inscription aux pages",
			'pages:tags' => "Mots-cl&eacute;s",	
			'pages:access_id' => "Acc&egrave;s",
			'pages:write_access_id' => "Acc&egrave;s en &eacute;criture",
		
		/**
		 * Status and error messages
		 */
			'pages:noaccess' => "Pas d'acc&egrave;s &agrave; la page",
			'pages:cantedit' => "Vous ne pouvez pas modifier cette page",
			'pages:saved' => "Pages sauvegard&eacute;es",
			'pages:notsaved' => "La page n'a pas pu &ecirc;tre sauvegard&eacute;e",
			'pages:notitle' => "Vous devez donner un titre &agrave; votre page.",
			'pages:delete:success' => "Votre page a bien &eacute;t&eacute; supprim&eacute;e.",
			'pages:delete:failure' => "La page n'a pas pu &ecirc;tre supprim&eacute;e.",
	
		/**
		 * Page
		 */
			'pages:strapline' => "Derni&egrave;re mise &agrave; jour par %s",
	
		/**
		 * History
		 */
			'pages:revision' => "R&eacute;vision cr&eacute;&eacute;e par %s",
			
		/**
		 * Wdiget
		 **/
		 
		    'pages:num' => "Nombre de pages &agrave; afficher",
	
		/**
		 * Submenu items
		 */
			'pages:label:view' => "Voir page",
			'pages:label:edit' => "Modifier page",
			'pages:label:history' => "Historique de page",
	
		/**
		 * Sidebar items
		 */
			'pages:sidebar:this' => "Cette page",
			'pages:sidebar:children' => "Sous-pages",
			'pages:sidebar:parent' => "Parent",
	
			'pages:newchild' => "Cr&eacute;er une sous-page",
			'pages:backtoparent' => "Retour &agrave; %s",
	);
					
	add_translation("fr",$french);
?>