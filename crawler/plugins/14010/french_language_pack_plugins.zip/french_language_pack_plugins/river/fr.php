<?php

	$french = array(
	
		/**
		 * Manifest
		 */
		
	
		'river:widget:noactivity' => "Nous n'avons pas pu trouver d'activit&eacute;.",
		'river:widget:title' => "Activit&eacute;",
		'river:widget:description' => "Montrer votre activit&eacute; la plus r&eacute;cente.",
		'river:widget:title:friends' => "Activit&eacute; de vos ami-e-s",
		'river:widget:description:friends' => "Montrer ce que vos ami-e-s font.",
	
		'river:widget:label:displaynum' => "Nombre d'articles &agrave; afficher :",
	);
					
	add_translation("fr",$french);

?>