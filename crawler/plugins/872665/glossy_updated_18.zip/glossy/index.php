<?php
if (elgg_is_logged_in()) forward('activity');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
    <head>
        <title>Glossy Theme</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
        <meta name="description" content="Put something here for SEO" />
        <meta name="keywords" content="Put something here for SEO"/>
		<link rel="shortcut icon" href="../favicon.ico" type="image/x-icon"/>
        <link rel="stylesheet" type="text/css" href="mod/glossy/css/style.css" />
		<script src="mod/glossy/js/cufon-yui.js" type="text/javascript"></script>
		<script src="mod/glossy/js/ChunkFive_400.font.js" type="text/javascript"></script>
		<script type="text/javascript">
			Cufon.replace('h1',{ textShadow: '1px 1px #fff'});
			Cufon.replace('h2',{ textShadow: '1px 1px #fff'});
			Cufon.replace('h3',{ textShadow: '1px 1px #000'});
			Cufon.replace('.back');
		</script>
    </head>
	
	
	

<?php 
echo elgg_view('page/elements/messages', array('object' => $_SESSION['msg']));
unset($_SESSION['msg']);

////////////////////////////////////////////////////////////////////////////////////////////////
?>
    <body>
		<div class="wrapper">
			<h1 style="color: white;">Welcome</h1>
			
			<div class="content">
				<div id="form_wrapper" class="form_wrapper">
				
					
						<h3>Login</h3>
						<div>
							<?php
									$form_body = 
									"
										
										<label style='color:#333;'>"
										.elgg_echo('username')
										."<br />"
										.elgg_view
										(
											'input/text'
											,array
											(
												'internalname' => 'username'
												,'class' => 'login-textarea'
											)
										)
										."</label><br />
									";
									$form_body .=
										"<label style='color:#333;'>"
										.elgg_echo('password')
										."<br />" 
										.elgg_view
										(
											'input/password'
											,array
											(
												'internalname' => 'password'
												,'class' => 'login-textarea'
											)
										)
										."</label><br />
									";
									$form_body .=
										elgg_view
										(
											 'input/submit'
											,array
											(
												'value' => elgg_echo('login')
											)
										)
										."</p>
									";
									echo elgg_view
									(
										'input/form'
										,array
										(
											 'body' => $form_body
											,'action' => ""
											.$vars['url']
											."action/login"
										)
									);
									?>
										 
						</div>
						<div class="bottom">
							
						
							<a href="register" rel="register" class="linkform"  style="color: white;" >Wanna join? Get an account here!</a>
							<div class="clear"></div>
						</div>
					
					
				</div>
				<div class="clear"></div>
			</div>
			<a class="back"  style="color: white;" href="http://www.swsocialweb.com/shop">Developed by SW Social Web LLC</a>
		</div>
		

		<!-- The JavaScript -->
		<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
		<script type="text/javascript">
			 
        </script>
		
		
    </body>
</html>