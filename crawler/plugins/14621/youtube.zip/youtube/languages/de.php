<?php

	$german = array(
	
		/**
		 * youtube widget details
		 */
		
	
		'youtube:id' => 'Gib den Link zum YouTube-Video an:',
		'youtube:whatisid' => 'Falls es nicht funktioniert kannst du alternativ die YouTubeID des Videos angeben, sie steht im Link nach v=',
		'youtube:caption' => 'Titel',
		'youtube:novideo' => 'Do hast noch keinen YouTube-Link angegeben, dieser ist aber n&ouml;tig um ein Video anzuzeigen.',
		
		 /**
	     * youtube widget river
	     **/
	        
	        //generic terms to use
	        'youtube:river:created' => "%s hat ein Youtube Widget hinzugef&uuml;gt.",
	        'youtube:river:updated' => "%s hat ein Youtube Widget aktualisiert.",
	        'youtube:river:delete' => "%s hat ein Youtube Widget gel&ouml;scht.",
	        
		
	);
					
	add_translation("de",$german);

?>