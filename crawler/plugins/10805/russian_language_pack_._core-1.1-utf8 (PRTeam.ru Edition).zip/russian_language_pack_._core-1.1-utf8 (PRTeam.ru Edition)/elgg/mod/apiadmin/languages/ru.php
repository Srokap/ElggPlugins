<?php
	/**
	 * API Admin russian language pack.
	 * Русский перевод - PRTeam Promo (http://prteam.ru)
	 * Александр П. Ларченко (larry@prteam.ru)
	 * @package ElggAPIAdmin
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008 @ PRTeam Promo ( SBb) 2008
	 * @link http://elgg.com/
	 */


	$russian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'apiadmin' => 'API Администратор',
	
	
			'apiadmin:keyrevoked' => 'Отмена API Ключа',
			'apiadmin:keynotrevoked' => 'API ключ не может быть отменен',
			'apiadmin:generated' => 'API Ключ успешно сгенерирован',
	
			'apiadmin:yourref' => 'Ваша ссылка',
			'apiadmin:generate' => 'Генерировать новую ключевую пару',
	
			'apiadmin:noreference' => 'Вы должны обеспечить ссылку для вашего нового ключа.',
			'apiadmin:generationfail' => 'Существует проблема генерации нового ключа',
			'apiadmin:generated' => 'Новая пара API ключей успешно сгенерирована',
	
			'apiadmin:revoke' => 'Отменить ключ',
			'apiadmin:public' => 'Общедоступный',
			'apiadmin:private' => 'Приватный',

	
			'item:object:api_key' => 'API Ключи',
	);
					
	add_translation("ru",$russian);
?>