<?php
     /**
	 * Elgg groups plugin russian language pack
	 * @package ElggGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Alexandr P. Larchenko (larry@prteam.ru)
	 * @copyright PRTeam Promo SPb(http://prteam.ru)
	 * @link http://elgg.com/
	 */


	$russian = array(
	
		/**
		 * Menu items and titles
		 */
			
			'groups' => "Группы",
			'groups:owned' => "Мною созданные группы",
			'groups:yours' => "Мои группы",
			'groups:user' => "%s's группы",
			'groups:all' => "Все группы сайта",
			'groups:new' => "Создать новую группу",
			'groups:edit' => "Редактировать группу",
	
			'groups:icon' => 'Логотип группы',
			'groups:name' => 'Название группы',
			'groups:username' => 'Короткое название (отображается в URL, вводите только буквы и цифры)',
			'groups:description' => 'Описание',
			'groups:briefdescription' => 'Короткое описание',
			'groups:interests' => 'Интересы',
			'groups:website' => 'Web-сайт',
			'groups:members' => 'Члены группы',
			'groups:membership' => "Membership",
			'groups:access' => "Разрешения на доступ",
			'groups:owner' => "Владелец",
	          'groups:widget:num_display' => 'Число отображаемых групп',
	        'groups:widget:membership' => 'Group membership',
	        'groups:widgets:description' => 'Отображение групп в которых вы состоите в профиле',
			'groups:noaccess' => 'Нет доступа к группе (запрещен)',
			'groups:cantedit' => 'Вы не можете отредактировать эту группу',
			'groups:saved' => 'Группа сохранена',
	
			'groups:joinrequest' => 'Request membership',
			'groups:join' => 'Вступить в группу',
			'groups:leave' => 'Выйти из группы',
			'groups:invite' => 'Пригласить друзей',
			'groups:inviteto' => "Пригасить друзей в '%s'",
			'groups:nofriends' => "Все ваши друзья уже приглашены в эту группу",
	
			'groups:group' => "Группа",
			
			'item:object:groupforumtopic' => "Темы Форума",

	
		/*
			  Group forum strings
			*/
			
			'groups:forum' => 'Форум группы',
			'groups:addtopic' => 'Добавить тему',
			'groups:forumlatest' => 'Последние форумы',
			'groups:latestdiscussion' => 'Последние обсуждения',
			'groupspost:success' => 'Комментарий успешно добавлен',
			'groups:alldiscussion' => 'Все последние обсуждения',
			'groups:edittopic' => 'Редактировать тему',
			'groups:topicmessage' => 'Сообщения в теме',
			'groups:topicstatus' => 'Статус темы',
			'groups:reply' => 'Добавить комментарий',
			'groups:topic' => 'Тема',
			'groups:posts' => 'Сообщения',
			'groups:lastperson' => 'Последний автор',
			'groups:when' => 'Время последнего сообщения',
			'grouptopic:notcreated' => 'Темы не созданы',
			'groups:topicopen' => 'Открыта',
			'groups:topicclosed' => 'Закрыта',
			'groups:topicresolved' => 'Resolved',
			'grouptopic:created' => 'Ваша тема создана.',
			'groupstopic:deleted' => 'Ваша тема удалена.',
			'groups:topicsticky' => 'Sticky',
			'groups:topicisclosed' => 'Эта тема закрыта.',
			'groups:topiccloseddesc' => 'Эта тема закрыта и добаление комментариев невозможно',
			'grouptopic:error' => 'Ваша тема в группе не может быть создана. Попробуйте еще раз или обратитесь к системному администратору.',
	
			'groups:privategroup' => 'Эта группа частная, только для ченов группы',
			'groups:notitle' => 'У группы должно быть название.',
			'groups:cantjoin' => 'Не возможно присоединится к группе',
			'groups:cantleave' => 'Невозможно покинуть группу',
			'groups:addedtogroup' => 'Пользователь успешно добавлен в группу',
			'groups:joinrequestnotmade' => 'Join request could not be made',
			'groups:joinrequestmade' => 'Request to join group successfully made',
			'groups:joined' => 'Группа успешно присоединена!',
			'groups:left' => 'Группа успешо оставлена',
			'groups:notowner' => 'Вы не владелец этой группы.',
			'groups:alreadymember' => 'Вы уже состоите в этой группе!',
			'groups:userinvited' => 'Пользователь был приглашен',
			'groups:usernotinvited' => 'Пользователь не может быть приглашен.',
	
			'groups:invite:subject' => "%s вы были приглашены присоединится %s!",
			'groups:invite:body' => "Привет %s,

Вы приглашены в группу '%s', нажмите для подтверждения вступления в группу:

%s",

			'groups:welcome:subject' => "Добро пожаловать в %s!",
			'groups:welcome:body' => "Привет %s!
		
Теперь Вы член группы '%s'! Нажмите ниже для отправки сообщения!

%s",
	
			'groups:request:subject' => "%s предлагает присоединится к %s",
			'groups:request:body' => "Привет %s,

%s предлагает присоединится к группе '%s', нажмите ниже для просмотра профиля:

%s

или ниже чтобы подтвердить предложение:

%s",
	
			'groups:river:member' => 'is now a member of (теперь член)',
	
			'groups:nowidgets' => 'Виджеты не определены для этой группы.',
	
	
			'groups:widgets:members:title' => 'Члены группы',
			'groups:widgets:members:description' => 'Список членов группы',
			'groups:widgets:members:label:displaynum' => 'Список членов группы',
			'groups:widgets:members:label:pleaseedit' => 'Пожалуйста сконфигурируйте виджет.',
	
			'groups:widgets:entities:title' => "Объекты в группе",
			'groups:widgets:entities:description' => "Список объектов сохраненных в группе",
			'groups:widgets:entities:label:displaynum' => 'Список объектов в группе',
			'groups:widgets:entities:label:pleaseedit' => 'Пожалуйста сконфигурируйте виджет.',
		
			'groups:forumtopic:edited' => 'Тема форума успешно отредактирована',
	);
					
	add_translation("ru",$russian);
?>