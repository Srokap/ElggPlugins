<?php

	$russian = array(
	
		/**
		 *Russian 
		 *Перевод PRTeam Promo (http://prteam.ru) 
		 *Александр П. Ларченко (larry@prteam.ru)
		 *Санкт-Петербург
		 ****************************************
		 *Menu items and titles
		 */
	
			'bookmarks' => "Закладки",
			'bookmarks:add' => "Отметить кое-что",
			'bookmarks:read' => "Мои закладки",
			'bookmarks:friends' => "Закладки друзей",
			'bookmarks:everyone' => "Все закладки сайта",
			'bookmarks:this' => "Добавить в закладки",
			'bookmarks:bookmarklet' => "Получить bookmarklet",
			'bookmarks:inbox' => "Входящие закладки",
			'bookmarks:more' => "Больше закладок",
			'bookmarks:shareditem' => "Bookmarked item",
			'bookmarks:with' => "Share with",
	
			'bookmarks:address' => "Адрес ресурса, для добавления в закладки",
	
			'bookmarks:delete:confirm' => "Вы уверены, что хотите удалить этот ресурс?",
	
			'bookmarks:shared' => "Bookmarked",
			'bookmarks:visit' => "Посещенные ресурсы",
			'bookmarks:recent' => "Недавние закладки",
	
			'bookmarks:river:created' => '%s bookmarked',
			'bookmarks:river:annotate' => '%s commented on',
			'bookmarks:river:item' => 'an item',
	
			'item:object:bookmarks' => 'Bookmarked items',
	
	
		/**
		 * More text
		 */
		    
		    'bookmarks:widget:description' => 
		            "Этот виджет покажет Вам последние элементы во Входящих закладках.",
	
			'bookmarks:bookmarklet:description' =>
					"Кнопка bookmarklet - для быстрого добавления закладок с помощью панели Вашего браузера. Для использования этого инструмента, просто перетащите следующую кнопку к полосе ссылок своего браузера:",

	        'bookmarks:bookmarklet:descriptionie' =>
					"При нажатии на эту кнопку будет загружен интерфейс добавления ссылки в закладки.",

			'bookmarks:bookmarklet:description:conclusion' =>
					"Используя bookmarklet Вы можете быстро сохранить любую страницу сайта",
	
		/**
		 * Status messages
		 */
	
			'bookmarks:save:success' => "Ваш пункт успешно добавлен в закладки.",
			'bookmarks:delete:success' => "Ваша закладка успешно удалена.",
	
		/**
		 * Error messages
		 */
	
			'bookmarks:save:failed' => "Ваша закладка не может быть сохранена. Попробуйте еще раз.",
			'bookmarks:delete:failed' => "Ваша закладка не может быть удалена. Попробуйте еще раз.",
	
	
	);
					
	add_translation("ru",$russian);

?>