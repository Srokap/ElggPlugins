<?php
	/**
	 * Elgg file plugin language pack
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * Русификация - PRTeam Promo (http://prteam.ru)
	 * Александр П.Ларченко (larry@prteam.ru)
	 * @copyright Curverider Ltd 2008 @ PRTeam Promo 2008
	 * @link http://elgg.com/
	 */

	$russian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'file' => "Файлы",
			'files' => "Файлы",
			'file:yours' => "Мои файлы",
			'file:yours:friends' => "Файлы друзей",
			'file:user' => "%s's files",
			'file:friends' => "%s's friends' files",
			'file:all' => "Все файлы сайта",
			'file:edit' => "Редактировать файл",
			'file:more' => "больше файлов",
			'file:list' => "Просмотр списка",
			'file:group' => "Группа файлов",
			'file:gallery' => "Просмотр в виде галлереи",
			'file:gallery_list' => "Просмотр в виде списка или галлереи",
			'file:num_files' => "Число отображаемых файлов",
			'file:user:gallery'=>'Просмотр %s галлереи', 
	
			'file:upload' => "Загрузить файл",
			
			'file:file' => "Файл",
			'file:title' => "Название",
			'file:desc' => "Описание",
			'file:tags' => "Метки (тэги)",
	
			'file:types' => "Загружаемые типы файлов",
	
			'file:type:all' => "Все файлы",
			'file:type:video' => "Видео",
			'file:type:document' => "Документы",
			'file:type:audio' => "Аудио",
			'file:type:image' => "Изображения",
			'file:type:general' => "Общий",
	
			'file:user:type:video' => "%s's видео",
			'file:user:type:document' => "%s's документы",
			'file:user:type:audio' => "%s's аудио",
			'file:user:type:image' => "%s's изображения",
			'file:user:type:general' => "%s's общие файлы",
	
			'file:friends:type:video' => "Видео друзей",
			'file:friends:type:document' => "Документы друзей",
			'file:friends:type:audio' => "Аудио друзей",
			'file:friends:type:image' => "Изображения друзей",
			'file:friends:type:general' => "Общие файлы друзей",
	
			'file:widget' => "Файл-виджет",
			'file:widget:description' => "Последние файлы",
	
			'file:download' => "Скачать файл",
	
			'file:delete:confirm' => "Вы уверены, что хотите удалить этот файл?",
			
			'file:tagcloud' => "Облако тегов",
	
			'file:display:number' => "Число отображаемых файлов",
	
			'file:river:created' => "%s uploaded",
			'file:river:item' => "a file",
			'file:river:annotate' => "%s commented on",

			'item:object:file' => 'Файлы',
			
	    /**
		 * Embed media
		 **/
		 
		    'file:embed' => "Embed media",
		    'file:embedall' => "Все",
	
		/**
		 * Status messages
		 */
	
			'file:saved' => "Ваш файл успешно сохранен",
			'file:deleted' => "Ваш файл успешно удален",
	
		/**
		 * Error messages
		 */
	
			'file:none' => "На сайте нет доступных файлов",
			'file:uploadfailed' => "Файл не сохранен. Попробуйте снова.",
			'file:downloadfailed' => "Файл недоступен в настоящий момент.Попробуйте снова.",
			'file:deletefailed' => "Ваш файл не может быть удален в настоящий момент. Попробуйте снова.",
	
	);
					
	add_translation("ru",$russian);
?>