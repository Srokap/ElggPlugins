<?php

	$russian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'blog' => "Блог",
			'blogs' => "Блог",
			'blog:user' => "%s's blog",
			'blog:user:friends' => "%s's friends' blog",
			'blog:your' => "Твой блог",
			'blog:posttitle' => "%s's blog: %s",
			'blog:friends' => "Блоги друзей",
			'blog:yourfriends' => "Последние блоги Ваших друзей",
			'blog:everyone' => "Все блоги",
	
			'blog:read' => "Читать блог",
	
			'blog:addpost' => "Сделать запись в блог",
			'blog:editpost' => "Редактировать запись",
	
			'blog:text' => "Текст Блога",
	
			'blog:strapline' => "%s",
			
			'item:object:blog' => 'Сообщения в блоге',
	
			
         /**
	     * Blog river
	     **/
	        
	        //generic terms to use
	        'blog:river:created' => "%s написал",
	        'blog:river:updated' => "%s обновил",
	        'blog:river:posted' => "%s posted",
	        
	        //these get inserted into the river links to take the user to the entity
	        'blog:river:create' => "новое сообщение в блоге.",
	        'blog:river:update' => "сообщение в блоге.",
	        'blog:river:annotate:create' => "комментарий к сообщению в блоге.",
			
	
		/**
		 * Status messages
		 */
	
			'blog:posted' => "Ваше сообщение успешно отправленов блог.",
			'blog:deleted' => "Ваше сообщение успешно удалено из блога.",
	
		/**
		 * Error messages
		 */
	
			'blog:save:failure' => "Ошибка сохранения сообщения. Пожалуйста попробуйте еще раз.",
			'blog:blank' => "Вы должны заполнить заголовок и текст сообщения.",
			'blog:notfound' => "Не найдено указанное сообщение в блоге",
			'blog:notdeleted' => "Невозможно удалить сообщение",
	
	);
					
	add_translation("ru",$russian);

?>