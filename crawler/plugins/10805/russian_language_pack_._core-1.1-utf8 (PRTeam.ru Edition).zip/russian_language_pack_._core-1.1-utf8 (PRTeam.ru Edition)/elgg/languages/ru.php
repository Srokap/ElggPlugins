<?php

         /**
		 * Русский перевод PRTeam Promo (http://prteam.ru/ ,http://prteam.ru/forum/)
		 * Alexandr P. Larchenko (larry@prteam.ru)
		 * 2008 (c)
		 */

	$russian = array(

		/**
		 * Sites
		 */
	
			'item:site' => "Сайты",
	
		/**
		 * Sessions
		 */
			
			'login' => "Вход",
			'loginok' => "Вы авторизировались.",
			'loginerror' => "Не удалось авторизоваться. Это может быть вызвано тем, что Вы не подтвердили Ваш аккаунт, или введенные Вами данные оказались неверными. Проверьте правильность Ваших данных и попробуйте еще раз.",
			'logout' => "Выход",
			'logoutok' => "Вы вышли.",
			'logouterror' => "Не удалось выйти. Пожалуйста повторите попытку.",
	
		/**
		 * Errors
		 */
			'exception:title' => "Здравствуйте",
	
			'InstallationException:CantCreateSite' => "Не удается создать с данными Имя: %s, Url: %s",
		
			'actionundefined' => "Запрошенное действие (%s) не определено системой.",
			'actionloggedout' => "Извините, но Вы не можете выполнить это действие, надо авторизоваться в системе.",
	
			'notfound' => "Запрошенный ресурс не найден, или у Вас нету к нему доступа.",
			
			'SecurityException:Codeblock' => "Запрещен доступ к выполнению привилегированного блока кода",
			'DatabaseException:WrongCredentials' => "Elgg не может соединится с базой данной, используя данные %s@%s (pw: %s).",
			'DatabaseException:NoConnect' => "Elgg не может найти базу данных '%s', пожалуйста проверте что база создана и у Вас есть к ней доступ.",
			'SecurityException:FunctionDenied' => "Доступ к привилегированной функции '%s' запрещен.",
			'DatabaseException:DBSetupIssues' => "Возникли следующие проблемы: ",
			'DatabaseException:ScriptNotFound' => "Elgg не может найти запрошенный скрипт базы данных %s.",
			
			'IOException:FailedToLoadGUID' => "Не удалось загрузить новый %s с GUID:%d",
			'InvalidParameterException:NonElggObject' => "Передан не объект Elgg в конструктор объектов Elgg!",
			'InvalidParameterException:UnrecognisedValue' => "Неопознанное значение передано в конструктор.",
			
			'InvalidClassException:NotValidElggStar' => "GUID:%d не является правильным %s",
			
			'PluginException:MisconfiguredPlugin' => "%s неверно заданный плагин.",
			
			'InvalidParameterException:NonElggUser' => "В конструктор ElggUser передан пользователь, не принадлежащий Elgg!",
			
			'InvalidParameterException:NonElggSite' => "В конструктор ElggSite передан сайт, не принадлежащий Elgg!",
			
			'InvalidParameterException:NonElggGroup' => "В конструктор Передан ElggGroup передана группа, не принадлежащая Elgg!",
	
			'IOException:UnableToSaveNew' => "Не удается сохранить новый %s",
			
			'InvalidParameterException:GUIDNotForExport' => "GUID не был указан во время экспорта, это не должно никогда случаться.",
			'InvalidParameterException:NonArrayReturnValue' => "Обьект переданный функцией сериализации не является параметром массива",
			
			'ConfigurationException:NoCachePath' => "Не установлен путь к кешу!",
			'IOException:NotDirectory' => "%s не является папкой.",
			
			'IOException:BaseEntitySaveFailed' => "Не удается сохранить данные нового объекта!",
			'InvalidParameterException:UnexpectedODDClass' => "import() передал неожиданный ODD клас",
			'InvalidParameterException:EntityTypeNotSet' => "Вы должны заполнить тип обьекта.",
			
			'ClassException:ClassnameNotClass' => "%s не является %s.",
			'ClassNotFoundException:MissingClass' => "класс '%s' не найден, отсутствует плагин?",
			'InstallationException:TypeNotSupported' => "Тип %s не поддерживается. Это вызывает ошибку в Вашей установке, причиной может быть неполное обновление системы.",

			'ImportException:ImportFailed' => "Не удается импортировать элемент %d",
			'ImportException:ProblemSaving' => "Возникла проблема при сохранении %s",
			'ImportException:NoGUID' => "Новый объект создан, но ему не назначен GUID, этого не должно случатся.",
			
			'ImportException:GUIDNotFound' => "Обьект '%d' не найден.",
			'ImportException:ProblemUpdatingMeta' => "Возникла проблема при обновлении '%s' в объекте '%d'",
			
			'ExportException:NoSuchEntity' => "Нет такого обьекта с GUID:%d", 
			
			'ImportException:NoODDElements' => "Не найдены элементы OpenDD в данных для импорта, импорт отменен.",
			'ImportException:NotAllImported' => "Не все элементы были импортированы.",
			
			'InvalidParameterException:UnrecognisedFileMode' => "Неопознанный режим файла '%s'",
			'InvalidParameterException:MissingOwner' => "Все файлы должны иметь владельца!",
			'IOException:CouldNotMake' => "Не удается сделать %s",
			'IOException:MissingFileName' => "Вы должны ввести имя перед открытием файла.",
			'ClassNotFoundException:NotFoundNotSavedWithFile' => "Файловый архив не найден или класс не сохранен с файлом!",
			'NotificationException:NoNotificationMethod' => "Не определен метод уведомления.",
			'NotificationException:NoHandlerFound' => "Не найден обработчик для '%s' или он не был запущен.",
			'NotificationException:ErrorNotifyingGuid' => "Возникла ошибка во время уведомления %d",
			'NotificationException:NoEmailAddress' => "Не удается получить email адрес к GUID:%d",
			'NotificationException:MissingParameter' => "Не найден обязательный параметр, '%s'",
			
			'DatabaseException:WhereSetNonQuery' => "Where set contains non WhereQueryComponent",
			'DatabaseException:SelectFieldsMissing' => "Не найдены поля в запрое смены стиля",
			'DatabaseException:UnspecifiedQueryType' => "Неопознанный или неопределенный тип запроса.",
			'DatabaseException:NoTablesSpecified' => "Не указаны таблицы для запроса.",
			'DatabaseException:NoACL' => "В запросе не указан контроль доступа",
			
			'InvalidParameterException:NoEntityFound' => "Объект не найден, он не существует или у Вас нету к нему доступа.",
			
			'InvalidParameterException:GUIDNotFound' => "GUID:%s не найден, или у Вас нету к нему доступа.",
			'InvalidParameterException:IdNotExistForGUID' => "Извините, '%s' не существует для guid:%d",
			'InvalidParameterException:CanNotExportType' => "Извините, система не знает как экспортировать '%s'",
			'InvalidParameterException:NoDataFound' => "Данные не найдены.",
			'InvalidParameterException:DoesNotBelong' => "Не принадлежит объекту.",
			'InvalidParameterException:DoesNotBelongOrRefer' => "Не принадлежит объекту или не ссылается на объект.",
			'InvalidParameterException:MissingParameter' => "Не найден параметр, Вы должны указать GUID.",
			
			'SecurityException:APIAccessDenied' => "Извините, API доступ отключен администратором.",
			'SecurityException:NoAuthMethods' => "Не найдены методы проверки которые могли бы проверить API запрос.",
			'APIException:ApiResultUnknown' => "Результат API - неопределенного типа, этого не должно случатся.", 
			
			'ConfigurationException:NoSiteID' => "Не указан ID сайта.",
			'InvalidParameterException:UnrecognisedMethod' => "Неопознанный метод вызова '%s'",
			'APIException:MissingParameterInMethod' => "Не найден параметр %s в методе %s",
			'APIException:ParameterNotArray' => "%s не является массивом.",
			'APIException:UnrecognisedTypeCast' => "Неопознанный тип при передаче %s для переменной '%s' в метод '%s'",
			'APIException:InvalidParameter' => "Найден неверный параметр для '%s' в методе '%s'.",
			'APIException:FunctionParseError' => "%s(%s) имеет ошибку синтаксиса.",
			'APIException:FunctionNoReturn' => "%s(%s) не вернула значение.",
			'SecurityException:AuthTokenExpired' => "Значение Аутентификация не найдено, неверное или истекло.",
			'CallException:InvalidCallMethod' => "%s должен вызываться используя '%s'",
			'APIException:MethodCallNotImplemented' => "Вызов метода '%s' не выполнен.",
			'APIException:AlgorithmNotSupported' => "Алгоритм '%s' не поддерживается или отключен.",
			'ConfigurationException:CacheDirNotSet' => "Папка кэша 'cache_path' не указана.",
			'APIException:NotGetOrPost' => "Метод запроса должен быть GET или POST",
			'APIException:MissingAPIKey' => "Отсутствует X-Elgg-apikey HTTP header",
			'APIException:MissingHmac' => "Отсутствует X-Elgg-hmac header",
			'APIException:MissingHmacAlgo' => "Отсутствует X-Elgg-hmac-algo header",
			'APIException:MissingTime' => "Отсутствует X-Elgg-time header",
			'APIException:TemporalDrift' => "X-Elgg-time слишком далеко в прошлом или будущем. Ошибка периода.",
			'APIException:NoQueryString' => "Нет данных в строке запроса",
			'APIException:MissingPOSTHash' => "Отсутствует X-Elgg-posthash header",
			'APIException:MissingPOSTAlgo' => "Отсутствует X-Elgg-posthash_algo header",
			'APIException:MissingContentType' => "Отсутствует тип содержимого для POST данных",
			'SecurityException:InvalidPostHash' => "Хеш данных POST неверный - Ожидалось %s но получили %s.",
			'SecurityException:DupePacket' => "Повторная подпись пакета.",
			'SecurityException:InvalidAPIKey' => "Неверный или отсутствует API Key.",
			'NotImplementedException:CallMethodNotImplemented' => "Метод вызова '%s' на данный момент не поддерживается.",
	
			'NotImplementedException:XMLRPCMethodNotImplemented' => "XML-RPC метод вызова '%s' не реализован.",
			'InvalidParameterException:UnexpectedReturnFormat' => "Вызов метода '%s' вернул неожиданный результат.",
			'CallException:NotRPCCall' => "Вызов не является правильным вызовом XML-RPC",
	
			'PluginException:NoPluginName' => "Имя плагина не найдено",
	
			'ConfigurationException:BadDatabaseVersion' => "Установленная база данных не удовлетворяет минимальным требованиям для запуска Elgg. Пожалуйста прочитайте документацию.",
			'ConfigurationException:BadPHPVersion' => "Вам как минимум нужна версия PHP - 5.2 для запуска Elgg.",
			
	
			'InstallationException:DatarootNotWritable' => "Нет прав на запись в папку %s.",
			'InstallationException:DatarootUnderPath' => "Ваша папка данных %s должна быть вне пути инсталяции.",
			'InstallationException:DatarootBlank' => "Вы не указали папку данных.",
	
		/**
		 * User details
		 */

			'name' => "Отображаемое имя",
			'email' => "Email адрес",
			'username' => "Логин",
			'password' => "Пароль",
			'passwordagain' => "Пароль (повтор для проверки)",
			'admin_option' => "Сделать этого пользователя администратором?",
	
		/**
		 * Access
		 */
	
			'ACCESS_PRIVATE' => "Приватный",
			'ACCESS_LOGGED_IN' => "Авторизированным пользователям",
			'ACCESS_PUBLIC' => "Публичный",
			'PRIVATE' => "Приватный",
			'LOGGED_IN' => "Авторизированным пользователям",
			'PUBLIC' => "Публичный",
			'access' => "Доступ",
	
		/**
		 * Dashboard and widgets
		 */
	
			'dashboard' => "Информационная панель",
			'dashboard:configure' => "Редактировать страницу",
			'dashboard:nowidgets' => " Это ваша Информационная панель сайта. Настройте её как вам удобнее. Нажмите 'Редактировать страницу' для добавления виджетов.",

			'widgets:add' => 'Добавить виджеты на Вашу страницу',
			'widgets:add:description' => "Выберите элементы которые Вы хотите добавить на Вашу страницу, перетаскивая их с <b>Галереи виджетов</b> вправо, в одну с трёх зон ниже, и разместите их в таком порядке, в котором хотите.
Для удаления виджета перетяните его обратно в <b>Галерею виджетов</b>.",
			'widgets:position:fixed' => '(Фиксированная позиция на странице)',
	
			'widgets' => "Виджеты",
			'widget' => "Виджет",
			'item:object:widget' => "Виджеты",
			'layout:customise' => "Изменить размещение",
			'widgets:gallery' => "Галерея виджетов",
			'widgets:leftcolumn' => "Левые виджеты",
			'widgets:fixed' => "Фиксированная позиция",
			'widgets:middlecolumn' => "Виждеты по середине",
			'widgets:rightcolumn' => "Правие виджеты",
			'widgets:profilebox' => "Блок профиля",
			'widgets:panel:save:success' => "Ваши виджеты успешно сохранены.",
			'widgets:panel:save:failure' => "Ошибка при сохранении виджетов. Пожалуйста повторите.",
			'widgets:save:success' => "Виджет успешно сохранен.",
			'widgets:save:failure' => "Ошибка сохранения виджета. Пожалуйста повторите.",
			
	
		/**
		 * Groups
		 */
	
			'group' => "Группа", 
			'item:group' => "Группы",
	
		/**
		 * Profile
		 */
	
			'profile' => "Профиль",
			'user' => "Пользователь",
			'item:user' => "Пользователи",

		/**
		 * Profile menu items and titles
		 */
	
			'profile:yours' => "Ваш профиль",
			'profile:user' => "Профиль %s",
	
			'profile:edit' => "Редактировать профиль",
			'profile:editicon' => "Загрузить новое изображение профиля",
			'profile:profilepictureinstructions' => "Изображение профиля это изображение, которое отображается на странице Вашего профиля. <br /> Вы можете его менять настолько часто, сколько хотите. (Разрешенные форматы файлов: GIF, JPG или PNG)",
			'profile:icon' => "Изображение профиля",
			'profile:createicon' => "Создать Ваш аватар",
			'profile:currentavatar' => "Текущий аватар",
			'profile:createicon:header' => "Изображение профиля",
			'profile:profilepicturecroppingtool' => "Изменение размеров изображения профиля",
			'profile:createicon:instructions' => "Нажмите и переместите квадрат ниже настолько, как Вы хотите обрезать Ваше изображение.  Предварительный просмотр обрезанного изображения появится в блоке справа.  Если Вас удовлетворяет предварительный просмотр, нажмите 'Создать Ваш аватар'. Это обрезанное изображение будет использоваться как Ваш аватар на сайте. ",
	
			'profile:editdetails' => "Редактировать данные",
			'profile:editicon' => "Редактировать изображение профиля",
	
			'profile:aboutme' => "О мне", 
			'profile:description' => "О мне",
			'profile:briefdescription' => "Краткое описание",
			'profile:location' => "Размещение",
			'profile:skills' => "Навыки",  
			'profile:interests' => "Интересы", 
			'profile:contactemail' => "Контактный email",
			'profile:phone' => "Телефон",
			'profile:mobile' => "Мобильный телефон",
			'profile:website' => "Сайт",

			'profile:river:update' => "%s обновил профиль",
			'profile:river:iconupdate' => "%s обновил изображение профиля",
	
		/**
		 * Profile status messages
		 */
	
			'profile:saved' => "Ваш профиль успешно сохранен.",
			'profile:icon:uploaded' => "Изображение Вашего профиля успешно загружено.",
	
		/**
		 * Profile error messages
		 */
	
			'profile:noaccess' => "У Вас нет доступа к редактированию этого профиля.",
			'profile:notfound' => "Извините, не удается найти указанный профиль.",
			'profile:cantedit' => "Извините, у Вас нет доступа к редактированию этого профиля.",
			'profile:icon:notfound' => "Извините, возникли проблемы при загрузке изображения Вашего профиля.",
	
		/**
		 * Friends
		 */
	
			'friends' => "Друзья",
			'friends:yours' => "Ваши друзья",
			'friends:owned' => "Друзья %s",
			'friend:add' => "Добавить друга",
			'friend:remove' => "Удалить друга",
	
			'friends:add:successful' => "Вы успешно добавили %s в друзья.",
			'friends:add:failure' => "Не удается добавить %s в друзья. Пожалуйста повторите попытку.",
	
			'friends:remove:successful' => "Вы успешно удалили %s с Ваших друзей.",
			'friends:remove:failure' => "Не удается удалить %s с Ваших друзей. Пожалуйста повторите попытку.",
	
			'friends:none' => "Этот пользователь еще никого не добавил в друзья.",
			'friends:none:you' => "Вы еще никого не добавили в друзья! Ищите пользователей с интересами, подобными Вашим, чтобы добавить их в друзья.",
	
			'friends:none:found' => "Друзей не найдено.",
	
			'friends:of:none' => "Никто еще не добавил этого пользователя в друзья.",
			'friends:of:none:you' => "Никто еще не добавил Вас в друзья. Добавляйте информацию, заполните Ваш профиль, чтобы другие пользователи нашли Вас!",
	
			'friends:of' => "Друзья",
			'friends:of:owned' => "Пользователи добавившие %s в друзья",

			 'friends:num_display' => "Показывать количество друзей",
			 'friends:icon_size' => "Размер изображения",
			 'friends:tiny' => "очень маленькое",
			 'friends:small' => "маленькое",
			 'friends' => "Друзья",
			 'friends:of' => "Мои друзья",
			 'friends:collections' => "Группа друзей",
			 'friends:collections:add' => "Новая группа друзей",
			 'friends:addfriends' => "Добавить друзей",
			 'friends:collectionname' => "Название группы",
			 'friends:collectionfriends' => "Друзей в группе",
			 'friends:collectionedit' => "Редактировать эту группу",
			 'friends:nocollections' => "У Вас еще нет групп.",
			 'friends:collectiondeleted' => "Ваша группа удалена.",
			 'friends:collectiondeletefailed' => "Не удается удалить группу. У Вас не прав доступа, или возникла другая ошибка.",
			 'friends:collectionadded' => "Ваша группа успешно создана",
			 'friends:nocollectionname' => "Вы должны назвать группу перед ее созданием.",
		
	        'friends:river:created' => "%s добавил виджет друзей.",
	        'friends:river:updated' => "%s обновил виджет друзей.",
	        'friends:river:delete' => "%s удалил виджет друзей.",
	        'friends:river:add' => "%s добавил кого-то как друга .",
	
		/**
		 * Feeds
		 */
			'feed:rss' => 'Подписаться на RSS канал',
			'feed:odd' => 'Экспорт OpenDD',
	
		/**
		 * River
		 */
			'river' => "River",			
			'river:relationship:friend' => 'теперь друзья с',

		/**
		 * Plugins
		 */
			'plugins:settings:save:ok' => "Настройки плагина %s успешно сохранены.",
			'plugins:settings:save:fail' => "Возникла ошибка при сохранении настроек плагина %s.",
			'plugins:usersettings:save:ok' => "Пользовательские настройки плагина %s успешно сохранены.",
			'plugins:usersettings:save:fail' => "Возникла ошибка при сохранении пользовательских настроек плагина %s.",
			
		/**
		 * Notifications
		 */
			'notifications:usersettings' => "Настройки уведомления",
			'notifications:methods' => "Пожалуйста укажите которые методы Вы хотите разрешить.",
	
			'notifications:usersettings:save:ok' => "Настройки уведомления успешно сохранены.",
			'notifications:usersettings:save:fail' => "Возникла ошибка при сохранении настроек уведомления.",
		/**
		 * Search
		 */
	
			'search' => "Поиск",
			'searchtitle' => "Поиск: %s",
			'users:searchtitle' => "Поиск пользователей: %s",
			'advancedsearchtitle' => "%s результатов совпадает с %s",
			'notfound' => "Ничего не найдено.",
			'next' => "Следующая",
			'previous' => "Предыдущая",
	
			'viewtype:change' => "Изменить вид вывода",
			'viewtype:list' => "Список",
			'viewtype:gallery' => "Галерея",
	
			'tag:search:startblurb' => "Записи с тегами, которые совпадают с '%s':",

			'user:search:startblurb' => "Пользователи, совпадающие с '%s':",
			'user:search:finishblurb' => "Подробнее",
	
		/**
		 * Account
		 */
	
			'account' => "Аккаунт",
			'settings' => "Настройки",
			'tools' => "Инструменты",
            'tools:yours' => "Мои инструменты",
	
			'register' => "Регистрация",
			'registerok' => "Вы успешно зарегистрировались на %s. Для активации аккаунта, пожалуйста потвердите Ваш email нажав на ссылке в письме, которое мы Вам отправили.",
			'registerbad' => "Ваша регистрация приостановлена. Логин уже существует, Ваши пароли не совпадают, или логин или пароль слишком краткие.",
			'registerdisabled' => "Регистрация отключена администратором",
	
			'registration:notemail' => 'Указанный Вами email является неправильным.',
			'registration:userexists' => 'Этот логин уще существует',
			'registration:usernametooshort' => 'Ваш логин должен состоять как минимум с 4 символов.',
			'registration:passwordtooshort' => 'Пароль должен быть как минимум 6 символов.',
			'registration:dupeemail' => 'Такой email адрес уже зарегистрирован.',
	
			'adduser' => "Добавить пользователя",
			'adduser:ok' => "Вы успешно добавили нового пользователя.",
			'adduser:bad' => "Не удается создать нового пользователя.",
			
			'item:object:reported_content' => "Сообщенные элементы",
	
			'user:set:name' => "Настройки аккаунта",
			'user:name:label' => "Ваше имя",
			'user:name:success' => "Ваше имя в системе успешно изменено.",
			'user:name:fail' => "Не удается изменить имя в системе.",
	
			'user:set:password' => "Пароль аккаунта",
			'user:password:label' => "Ваш новый пароль",
			'user:password2:label' => "Ваш новый пароль (повтор)",
			'user:password:success' => "Пароль изменен",
			'user:password:fail' => "Не удается изменить пароль в системе.",
			'user:password:fail:notsame' => "Пароли не совпадают!",
			'user:password:fail:tooshort' => "Пароль должен быть длиннее!",
	
			'user:set:language' => "Настройки языка",
			'user:language:label' => "Ваш язык",
			'user:language:success' => "Настройки языка обновлены.",
			'user:language:fail' => "Ошибка сохранения смены языка.",
	
			'user:username:notfound' => 'Логин %s не найден.',
	
			'user:password:lost' => 'Потеряли пароль',
			'user:password:resetreq:success' => 'Успешный запрос нового пароля, email отправлен',
			'user:password:resetreq:fail' => 'Ошибка запроса нового пароля.',
	
			'user:password:text' => 'Для генерации нового пароля, введите Ваш логин ниже. Мы вышлем Вам адрес страницы проверки на email, нажмите на ссылку в письме и Вам будет отправлен новый пароль.',
	
	        'user:persistent' => 'Запомнить',
		/**
		 * Administration
		 */

			'admin:configuration:success' => "Ваши настройки сохранены.",
			'admin:configuration:fail' => "Ошибка при сохранении настроек.",
	
			'admin' => "Администрирование",
			'admin:description' => "Панель администрирования помогает контролировать все возможности системы, от управления пользователями до настроек плагинов. Нажмите ниже чтобы начать.",
			
			'admin:user' => "Управление пользователями",
			'admin:user:description' => "Эта панель управление позволяет управлять настройками пользователей на Вашем сайте. Выберите опцию ниже чтобы начать.",
			'admin:user:adduser:label' => "Нажмите здесь чтобы добавить нового пользователя...",
			'admin:user:opt:linktext' => "Управление пользователями...",
			'admin:user:opt:description' => "Управление пользователями и данными аккаунтов. ",
			
			'admin:site' => "Администрирование сайта",
			'admin:site:description' => "Эта панель управления позволяет управлять глобальными настройками Вашего сайта. Выберите опцию ниже чтобы начать.",
			'admin:site:opt:linktext' => "Управление сайтом...",
			'admin:site:opt:description' => "Управление техническими и нетехническими настройками сайта. ",
			
			'admin:plugins' => "Администрирование плагинов",
			'admin:plugins:description' => "Эта панель управления позволяет управлять и настраивать плагины, установленные на Вашем сайте.",
			'admin:plugins:opt:linktext' => "Управление плагинами...",
			'admin:plugins:opt:description' => "Настройка плагинов, установленных в Вашей системе. ",
			'admin:plugins:label:author' => "Автор",
			'admin:plugins:label:copyright' => "Copyright",
			'admin:plugins:label:licence' => "Лицензия",
			'admin:plugins:label:website' => "URL",
			'admin:plugins:disable:yes' => "Плагин %s успешно отключен.",
			'admin:plugins:disable:no' => "Плагин %s невозможно отключить.",
			'admin:plugins:enable:yes' => "Плагин %s успешно включен.",
			'admin:plugins:enable:no' => "Плагин %s невозможно включить.",
	
			'admin:statistics' => "Статистика",
			'admin:statistics:description' => "Это обзор статистики Вашего сайта. Если Вам нужна более детальная статистика, эта опция доступна.",
			'admin:statistics:opt:description' => "Просмотр статистической информации о пользователях и обьектах на Вашем сайте.",
			'admin:statistics:opt:linktext' => "Просмотр статистики...",
			'admin:statistics:label:basic' => "Простая статистика сайта",
			'admin:statistics:label:numentities' => "Объектов на сайте",
			'admin:statistics:label:numusers' => "Количество пользователей",
			'admin:statistics:label:numonline' => "Количество пользователей онлайн",
			'admin:statistics:label:onlineusers' => "Пользователи онлайн",
			'admin:statistics:label:version' => "Версия Elgg",
			'admin:statistics:label:version:release' => "Релиз",
			'admin:statistics:label:version:version' => "Версия",
	
			'admin:user:label:search' => "Поиск пользователей:",
			'admin:user:label:seachbutton' => "Поиск", 
	
			'admin:user:ban:no' => "Не удалось заблокировать пользователя",
			'admin:user:ban:yes' => "Пользователь заблокирован.",
			'admin:user:unban:no' => "Не удается разблокировать пользователя",
			'admin:user:unban:yes' => "Пользователь  разблокирован.",
			'admin:user:delete:no' => "Не удается удалить пользователя",
			'admin:user:delete:yes' => "Пользователь удален",
	
			'admin:user:resetpassword:yes' => "Пароль изменен, пользователь уведомлен.",
			'admin:user:resetpassword:no' => "Не удается изменить пароль.",
	
			'admin:user:makeadmin:yes' => "Пользователь стал администратором.",
			'admin:user:makeadmin:no' => "Не удается сделать этого пользователя администратором.",
			
		/**
		 * User settings
		 */
			'usersettings:description' => "Панель пользователя позволяет управлять всеми Вашими персональными настройками, от управления пользователем до отображения плагинов. Выберите опцию ниже чтобы начать.",
	
			'usersettings:statistics' => "Ваша статистика",
			'usersettings:statistics:opt:description' => "Просмотр статистической информации о пользователях и обьектах на Вашем сайте.",
			'usersettings:statistics:opt:linktext' => "Статистика аккаунта",
	
			'usersettings:user' => "Ваши настройки",
			'usersettings:user:opt:description' => "Управление настройками пользователя.",
			'usersettings:user:opt:linktext' => "Изменить Ваши настройки",
	
			'usersettings:plugins' => "Плагины",
			'usersettings:plugins:opt:description' => "Управление настройками активных плагинов.",
			'usersettings:plugins:opt:linktext' => "Настройка плагинов...",
	
			'usersettings:plugins:description' => "Эта панель позволяет управлять и настраивать персональными настройками плагинов, установленных системным администратором.",
			'usersettings:statistics:label:numentities' => "Ваши объекты",
	
			'usersettings:statistics:yourdetails' => "Ваши данные",
			'usersettings:statistics:label:name' => "Полное имя",
			'usersettings:statistics:label:email' => "Email",
			'usersettings:statistics:label:membersince' => "Пользователь с",
			'usersettings:statistics:label:lastlogin' => "Последний раз был на сайте",
	
			
	
		/**
		 * Generic action words
		 */
	
			'save' => "Сохранить",
			'cancel' => "Отмена",
			'saving' => "Сохранение ...",
			'update' => "Обновить",
			'edit' => "Редактировать",
			'delete' => "Удалить",
			'load' => "Скачать",
			'upload' => "Загрузить",
			'ban' => "Блокировка",
			'unban' => "Разблокировка",
			'enable' => "Включить",
			'disable' => "Выключить",
			'request' => "Запрос",
	
			'invite' => "Приглашение",
	
			'resetpassword' => "Скинуть пароль",
			'makeadmin' => "Сделать администратором",
	
			'option:yes' => "Да",
			'option:no' => "Нет",
	
			'unknown' => 'Неизвестно',
	
            'active' => 'Активных',
			'total' => 'Всего',
	
			'learnmore' => "Подробнее",
	
			'content' => "содержимое",
			'content:latest' => "Последняя активность",
			'content:latest:blurb' => "Для просмотра новой информации, добавленной на сайт, нажмите сюда.",
	
		/**
		 * Generic data words
		 */
	
			'title' => "Название",
			'description' => "Описание",
			'tags' => "Теги",
			'spotlight' => "Подсветка",
			'all' => "Все",
	
			'by' => '',
	
			'annotations' => "Примечания",
			'relationships' => "Связи",
			'metadata' => "Метаданные",
	
		/**
		 * Input / output strings
		 */

			'deleteconfirm' => "Вы уверены что хотите удалить этот элемент?",
			'fileexists' => "Файл уже загружен. Чтобы заменить его, выберите его ниже:",
	
	
		    /**
         * System messages
         **/

			'systemmessages:dismiss' => "закрыть сообщение",
	

		/**
		 * Import / export
		 */
			'importsuccess' => "Данные импортированы успешно",
			'importfail' => "Ошибка OpenDD импорта данных.",
	
		/**
		 * Time
		 */
	
			'friendlytime:justnow' => "сейчас",
			'friendlytime:minutes' => "%s минут назад",
			'friendlytime:minutes:singular' => "минуту назад",
			'friendlytime:hours' => "%s часов назад",
			'friendlytime:hours:singular' => "час назад",
			'friendlytime:days' => "%s дней назад",
			'friendlytime:days:singular' => "вчера",
	
		/**
		 * Installation and system settings
		 */
	
			'installation:error:htaccess' => "Для инсталляции Elgg нужно чтобы файл .htaccess был размещен в главной папке. Система пыталась его создать, но Elgg не имеет прав на запись в этой папке. 

Создать этот файл легко. Скопируйте содержимое текстового блока в текстовый редактор и сохраните его как .htaccess

",
			'installation:error:settings' => "Elgg не может найти файл настроек. Большинство настроек Elgg будут доступны Вам, но Вы должны указать данные соединения с базой данных. Для этого:

1. Переименуйте engine/settings.example.php на settings.php.

2. Откройте его в текстовом редакторе и впишите данные базы данных MySQL. Если Вы не знаете как это сделать, попросите помощи у Вашего администратора или технической поддержки хостинга.
Так же, Вы можете ввести настройки базы данных ниже и система попробует записать их в файл...",
	
			'installation:error:configuration' => "Если Вы исправили ошибки в настройках, пожалуйста обновите страницу для продолжения установки.",
	
			'installation' => "Установка",
			'installation:success' => "База данных Elgg установлена успешно.",
			'installation:configuration:success' => "Ваши настройки сохранены. Теперь зарегистрируйте пользователя, он будет системным администратором.",
	
			'installation:settings' => "Настройки системы",
			'installation:settings:description' => "Теперь, после того как база данных Elgg успешно установлена, Вы должны заполнить некоторые данные о сайте.",
	
			'installation:settings:dbwizard:prompt' => "Введите ниже настройки базы данных и нажмите сохранить:",
			'installation:settings:dbwizard:label:user' => "Пользователь базы данных",
			'installation:settings:dbwizard:label:pass' => "Пароль базы данных",
			'installation:settings:dbwizard:label:dbname' => "База данных Elgg",
			'installation:settings:dbwizard:label:host' => "Сервер базы данных (в большинстве случаев  'localhost')",
			'installation:settings:dbwizard:label:prefix' => "Префикс таблиц базы данных (в основном 'elgg')",
	
			'installation:settings:dbwizard:savefail' => "Ошибка при сохранении нового settings.php. Пожалуйста сохраните этот файл как engine/settings.php используя текстовый редактор.",
	
			'installation:sitename' => "Название Вашего сайта (Пример \"Мой социальный сайт\"):",
			'installation:sitedescription' => "Краткое описание Вашего сайта (не обязательно)",
			'installation:wwwroot' => "URL сайта, должен заканчиваться слешем:",
			'installation:path' => "Полный путь к корню сайта, должен заканчиваться слешем:",
			'installation:dataroot' => "Полный путь к папке где будут сохраняться загруженные файлы, должен заканчиваться слешем:",
			'installation:dataroot:warning' => "Вы должны создать эту папку вручную. Она должна размещаться в папке, которая не входит в путь установки Elgg.",
			'installation:language' => "Язык по умолчанию для Вашего сайта:",
			'installation:debug' => "Debug-режим показывает дополнительную информацию, которую можна использовать для проверки ошибок, но этот режим замедлит работу системы, поэтому рекомендуем его использовать только в случае возникновения ошибок:",
			'installation:debug:label' => "Включить debug-режим",
			'installation:usage' => "Эта опция позволяет Elgg отправлять анонимную статистику использования на Curverider.",
			'installation:usage:label' => "Отправка анонимной информации использования",
			'installation:view' => "Введите режим просмотра, который будет использоваться у Вас на сайте, или оставьте пустим для использования режима просмотра по умолчанию (если не уверены, оставьте пустым):",
	
		/**
		 * Welcome
		 */
	
			'welcome' => "Здравствуйте %s",
			'welcome_message' => "Приветствуем Вас в установке Elgg.",
	
		/**
		 * Emails
		 */
			'email:settings' => "Настройки Email",
			'email:address:label' => "Ваш email адрес",
			
			'email:save:success' => "Новый email адрес сохранен, отправлен запрос проверки реальности адреса.",
			'email:save:fail' => "Ваш новый email адрес не сохранен.",
	
			'email:confirm:success' => "Вы подтвердили Ваш email адрес!",
			'email:confirm:fail' => "Ваш email адрес не проверен...",
	
			'friend:newfriend:subject' => "%s добавил Вас в друзья!",
			'friend:newfriend:body' => "%s добавил Вас в друзья!

Для просмотра его профиля, нажмите здесь:

	%s

Не отвечайте на этот email.",
	
	
			'email:validate:subject' => "%s пожалуйста подтвердите Ваш email адрес!",
			'email:validate:body' => "Здравствуйте %s,

Пожалуйста подтвердите Ваш email адрес, нажав ссылку ниже:

%s
",
			'email:validate:success:subject' => "Email проверен %s!",
			'email:validate:success:body' => "Здравствуйте %s,
			
Поздравляем, Вы успешно подтвердили Ваш email.",
	
	
			'email:resetpassword:subject' => "Пароль изменен!",
			'email:resetpassword:body' => "Здравствуйте %s,
			
Ваш пароль изменен на: %s",
	
	
			'email:resetreq:subject' => "Запрос нового пароля.",
			'email:resetreq:body' => "Здравствуйте %s,
			
Кто-то (с IP адреса %s) запросил новый пароль для этого аккаунта.

Если запрос сделали Вы нажмите ссылку ниже, если не Вы - проигнорируйте этот email.

%s
",

	
		/**
		 * XML-RPC
		 */
			'xmlrpc:noinputdata'	=>	"Не найдены входящие данные",
	
		/**
		 * Comments
		 */
	
			'comments:count' => "%s комментариев",
			'generic_comments:add' => "Добавить комментарий",
			'generic_comments:text' => "Комментарий",
			'generic_comment:posted' => "Ваш комментарий успешно добавлен.",
			'generic_comment:deleted' => "Ваш комментарий успешно удален.",
			'generic_comment:blank' => "Извините, Вам нужно написать что-то в комментарии перед тем как его сохраненить.",
			'generic_comment:notfound' => "Извините, не найден указанный элемент.",
			'generic_comment:notdeleted' => "Извините, ошибка при удалении комментария.",
			'generic_comment:failure' => "Неожиданная ошибка возникла при добавлении комментария. Пожалуйста повторите еще раз.",
	
			'generic_comment:email:subject' => 'У Вас новый комментарий!',
			'generic_comment:email:body' => "Добавлен новый комментарий к Вашему элементу \"%s\" от %s. Он написал:

			
%s


Для ответа или просмотра элемента, нажмите здесь:

	%s

Для просмотра профиля %s, нажмите здесь:

	%s

Не отвечайте на этот email.",
	
		/**
		 * Entities
		 */
			'entity:default:strapline' => 'Создан в %s %s',
			'entity:default:missingsupport:popup' => 'Этот объект не удается корректно отобразить. Возможно ему нужен плагин, который уже удален.',

			'entity:delete:success' => 'Объект %s удален',
			'entity:delete:fail' => 'Ошибка удаления объекта %s',
	
	
		/**
		 * Action gatekeeper
		 */
			'actiongatekeeper:missingfields' => 'В форме не найдены поля __token или __ts',
			'actiongatekeeper:tokeninvalid' => 'Значение переданное формой не совпадает со значением сгенерированным сервером.',
			'actiongatekeeper:timeerror' => 'Время формы истекло, пожалуйста обновите страницу и попробуйте снова.',
			'actiongatekeeper:pluginprevents' => 'Компонент воспрепятствовал отправке этой формы.',
	
		/**
		 * Languages according to ISO 639-1
		 */
			"en" => "English",
			"ru" => "Русский",
			"uk" => "Українська",
			
	);
	
	add_translation("ru",$russian);

?>