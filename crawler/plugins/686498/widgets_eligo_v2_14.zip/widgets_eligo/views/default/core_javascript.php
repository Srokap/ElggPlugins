<?php 

		global $CONFIG;

        // Generate the action token separately because they need to be at the end of the URL
        // Using action tokens means the user can only fiddle with things for about five minutes
        $ts = time();
        $token = generate_action_token($ts);
		$move_link =  $CONFIG->url . "action/update/selectbox";
		$talking_to_server_image = '"'.$CONFIG->url.'mod/widgets_eligo/graphics/famfamfam_icons/server_go.png"';
		if (get_plugin_setting("eligo_ajax_icons", "widgets_eligo") == "no") $talking_to_server_image = '""'; 
        $server_problem = '"'.$CONFIG->url.'mod/widgets_eligo/graphics/famfamfam_icons/server_error.png"';
		

		echo '
		<SCRIPT type="text/javascript"><!--
			function addLoadEvent(func) {
			  var oldonload = window.onload;
			  if (typeof window.onload != "function") {
			    window.onload = func;
			  } else {
			    window.onload = function() {
			      if (oldonload) {
			        oldonload();
			      }
			      func();
			    }
			  }
			}

			// group - is the source multiple select box which to populate
			// context - is the multiple select box to update.
			// guid - This is the owner guid 
			// TODO - should probably cache results at some point.
			function CS_send_request(group, context, guid, sort_by) {
				//var multipleValues = $(element).val() || [];
				//var outbound = multipleValues.join("!");
				// Our Ajax handler needs to know both the context and the group in order to pull out the right
				// database records and format them properly.
				var tabOrder = "&context=" + context + "&group=" + group +"&guid=" + guid + "&sortby=" + sort_by + "&__elgg_ts='.$ts.'&__elgg_token='.$token.'";
				var result = 0;
				// jQuery works better with class names - this assumes the select box has an identical class and ID.
				var target_element = "." + group;
				// There are places, like GCL where
				try {
					document.getElementById("eligoajaxstatus"+guid).style.display = "block";
                	document.getElementById("eligoajaxstatus"+guid).src = '.$talking_to_server_image.';
                	document.getElementById("eligoajaxstatus"+guid).title = "'.elgg_echo("eligo:ajaxworking").'";
                } catch(E) {}
				$.ajax ({
					url: "'. $move_link .'",
					data: tabOrder,
					success: function(html)
					{
					    try {
					    	 $("#eligoajaxstatus"+guid).fadeOut("slow"); 
						} catch(E){
							alert ("An error occured, please refresh the page and try again...");
						}
						//  %%%  <!--- is used to find the ending of the number of <options and the options themselves.
						var size_of_location = html.indexOf("%%%");
						if (size_of_location > 10) { // Check to see if we got back an unexpected result, likely because the user is no longer logged in or security tokens expired.
							alert ("'.elgg_echo('eligo:ajax:refreshpage').'");
							$(target_element).html("<option>--- Refresh page ---</option>");
							// location.reload(true);  // Kinda forceful
						} else { 
							// result contains the number of option statements and has our special ending %%% so we can find it and strip it off
							result = html.substr(0,size_of_location);
							// Now strip off the size and use just the option tags
							html =  html.substr(size_of_location+3);
							$(target_element).html(html);
							// And then resize the select box properly
							if (result > 0) {
									if (result > 25) { result = 25; } 
									// Not to get it confused with the DIV that has the same ID
									fld=document.getElementById(group + "ID");
									fld.size=result;
							} // result is greater then zero
						} // size_of_location was valid
					},
					error: function(httpr, textStatus)
					{
						if (document.getElementByID("eligoajaxstatus"+guid)) {
					   		document.getElementById("eligoajaxstatus"+guid).src = '.$server_problem.';
                       		document.getElementById("eligoajaxstatus"+guid).title = "'.elgg_echo("eligo:ajaxerror").' - Error: " + textStatus;
                       	}
					}
				}); // ajax call
			};
			
			// Heart of the hide/unhide functionality.
			function toggleDisabled(el, action) {
				try {
					el.style.display = action;
				}
				catch(E) {
				}
			
				if (el.childNodes && el.childNodes.length > 0) {
					for (var x = 0; x < el.childNodes.length; x++) {
						toggleDisabled(el.childNodes[x], action);
					} //for var x
				}
			} //function toggleDisabled
			
			// Heart of the hide/unhide functionality.
			function switchDisabled(el, action) {
				try {
					el.disabled = action;
				}
				catch(E) {
				}
			
				if (el.childNodes && el.childNodes.length > 0) {
					for (var x = 0; x < el.childNodes.length; x++) {
						switchDisabled(el.childNodes[x], action);
					} //for var x
				}
			} //function switchDisabled
		//-->
		</SCRIPT>
		';


?>