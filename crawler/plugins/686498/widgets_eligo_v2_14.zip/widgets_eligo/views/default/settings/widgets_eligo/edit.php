<?php

// A bug with Elgg?  The settings are visible even if the plugin is not enabled, and it crashes becaues CS_display_plugin_settings has not been loaded yet
if (is_plugin_enabled("widgets_eligo")) { 
	global $CONFIG;
	
	echo elgg_echo ('eligo:plugin:checking_requirements');
	
	// First, check to see if the recommended support plugins are installed and if not, then generate an appropriate warning.
	if (!is_plugin_enabled("jquerycalendar")) { 
		echo " <span style='font-weight:bold'>jQuery Calendar plugin</span> (<span style='font-weight:bold;color:red'>".elgg_echo('eligo:plugin:jquery_missing')."</span> - <a href='http://community.elgg.org/pg/plugins/project/462966/developer/openid_138622/jquerycalendar'>Download</a> )";
	} else {
		echo " <span style='font-weight:bold'>jQuery Calendar plugin</span> (<span style='font-weight:bold;color:green'>".elgg_echo('eligo:plugin:found')."</span>)";
	}
	echo '<hr size="5" width="50%" align="center">';
	echo elgg_echo("eligo:plugin:select");
	
	// Now turn check to see which plugins are installed and if enabled, and generate the appropriate code for each.
	echo CS_display_plugin_settings ("group_custom_layout",elgg_echo ("eligo:plugin:gcl:text"), "group_custom_layout_plugin_enable", $vars['entity']->group_custom_layout_plugin_enable, "http://community.elgg.org/pg/plugins/release/619312/developer/tunist/group-custom-layout-updated-again");
	echo CS_display_plugin_settings ("bookmarks", elgg_echo("eligo:plugin:bookmark:text"), "bookmarks_plugin_enable", $vars['entity']->bookmarks_plugin_enable, "http://www.elgg.org/plugins.php");
	echo CS_display_plugin_settings ("blog",elgg_echo("eligo:plugin:blog:text"), "blog_plugin_enable", $vars['entity']->blog_plugin_enable, "http://www.elgg.org/plugins.php");	
	echo CS_display_plugin_settings ("groups",elgg_echo("eligo:plugin:groups:text"), "groups_plugin_enable", $vars['entity']->groups_plugin_enable, "http://www.elgg.org/plugins.php");	
	echo CS_display_plugin_settings ("file",elgg_echo("eligo:plugin:files:text"), "files_plugin_enable", $vars['entity']->files_plugin_enable, "http://www.elgg.org/plugins.php");	
	echo CS_display_plugin_settings ("pages",elgg_echo("eligo:plugin:pages:text"), "pages_plugin_enable", $vars['entity']->pages_plugin_enable, "http://www.elgg.org/plugins.php");
	echo '<hr size="5" width="50%" align="center"><br />';
	
	// For the nice icons beside the text names, defaults to OFF (nonstandard dude!)
	if (!get_plugin_setting("eligo_nice_icons", "widgets_eligo")) set_plugin_setting("eligo_nice_icons", "no","widgets_eligo");
	$current_value = $vars['entity']->eligo_nice_icons;
	echo '<select name="params[eligo_nice_icons]" >
		<option value="yes"';
	if($current_value != "no" ) echo "selected='selected'";
	echo '>'.elgg_echo("option:yes");
	echo '</option>
		<option value="no"'; 
	if($current_value == "no" ) echo "selected='selected'";
	echo '>'.elgg_echo("option:no"); 
	echo '</option></select> '.elgg_echo("eligo:plugin:niceicons")."(<img src='".$CONFIG->url."mod/widgets_eligo/graphics/famfamfam_icons/user.png' id='group_image_access' title='".elgg_echo('eligo:widget:my_icon')."' /><img src='".$CONFIG->url."mod/widgets_eligo/graphics/famfamfam_icons/group_key.png' id='group_image_access' title='".elgg_echo('eligo:widget:friends_icon')."'/><img src='".$CONFIG->url."mod/widgets_eligo/graphics/famfamfam_icons/group.png' id='group_image_access' title='".elgg_echo('eligo:widget:all_icon')."'/>)<br />";
	
	// For the ajax loading icons beside the text names, defaults to ON
	if (!get_plugin_setting("eligo_ajax_icons", "widgets_eligo")) set_plugin_setting("eligo_ajax_icons", "yes","widgets_eligo");
	$current_value = $vars['entity']->eligo_ajax_icons;
	echo '<select name="params[eligo_ajax_icons]" >
		<option value="yes"';
	if($current_value != "no" ) echo "selected='selected'";
	echo '>'.elgg_echo("option:yes");
	echo '</option>
		<option value="no"'; 
	if($current_value == "no" ) echo "selected='selected'";
	echo '>'.elgg_echo("option:no"); 
	echo '</option></select> '.elgg_echo("eligo:plugin:ajaxicons")."(<img src='".$CONFIG->url."mod/widgets_eligo/graphics/famfamfam_icons/server_go.png' id='group_image_access' title='".elgg_echo('eligo:ajaxworking')."' /><img src='".$CONFIG->url."mod/widgets_eligo/graphics/famfamfam_icons/server_error.png' id='group_image_access' title='".elgg_echo('eligo:ajaxerror')."' />)";

//  TODO #49 Someday, it would be nice to use the iPhone style checkboxes
} //is_plugin_enabled widgets_eligo?

?>
