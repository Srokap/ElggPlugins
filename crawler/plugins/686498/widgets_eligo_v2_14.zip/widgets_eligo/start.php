<?php 


// Includes the necessary library files
@include_once( dirname( __FILE__) . "/library/plus.inc" );


function widgets_eligo_init(){

	global $CONFIG;
	
	register_action('update/selectbox', false, $CONFIG->pluginspath . "widgets_eligo/actions/ajax_call_handler.php");
	set_view_location ('widgets_eligo/css', $CONFIG->pluginspath.'widgets_eligo/plus_views/');	
	// Extending css with a tiny adjustment we need for making sure the jquery library doesn't appear *under* the thickbox used in Group Custom Layout.	
	extend_view("css", "widgets_eligo/css");
	elgg_extend_view("metatags", "core_javascript");
	
	/*
	 * The default view directory is not used,  i.e. /views/default/etc because they cannot turned enabled/disabled in code.  Elgg
	 * looks for those directories and files automatically and overwrites the previous code.
	 * With "set_view_location", only certain files are overwritten when enabled in code and can hence, be controlled on an individual
	 * basis, which is at the heart of the dependency manager.  Controllable widgets is the reason the "plus_views" directory is not 
	 * named as the standard "views".  The dependency manager exists under /views/default/settings/widgets_eligo/edit.php
	 */

	if(is_plugin_enabled("group_custom_layout") && get_plugin_setting("group_custom_layout_plugin_enable", "widgets_eligo") == "yes") {
		// Views for Group Custom Layout Widgets
		// TODO - #50 - GCL widgets should be individually enabled or disabled.		
		set_view_location ('group_custom_layout/widget_wrapper', $CONFIG->pluginspath.'widgets_eligo/plus_views/');			
		set_view_location ('group_widgets', $CONFIG->pluginspath.'widgets_eligo/plus_views/');
		set_view_location ('group_widgets/blog/edit', $CONFIG->pluginspath.'widgets_eligo/plus_views/');	
		set_view_location ('group_widgets/blog/view', $CONFIG->pluginspath.'widgets_eligo/plus_views/');		
		set_view_location ('group_widgets/bookmarks/edit', $CONFIG->pluginspath.'widgets_eligo/plus_views/');	
		set_view_location ('group_widgets/bookmarks/view', $CONFIG->pluginspath.'widgets_eligo/plus_views/');
		set_view_location ('group_widgets/files/edit', $CONFIG->pluginspath.'widgets_eligo/plus_views/');	
		set_view_location ('group_widgets/files/view', $CONFIG->pluginspath.'widgets_eligo/plus_views/');
		set_view_location ('group_widgets/pages/edit', $CONFIG->pluginspath.'widgets_eligo/plus_views/');	
		set_view_location ('group_widgets/pages/view', $CONFIG->pluginspath.'widgets_eligo/plus_views/');	
		// Overwrite the default save action to include code for saving our multi-select boxes.				
		register_action("group_custom_layout/save", false, $CONFIG->pluginspath . "widgets_eligo/actions/save.php");			
	}
	
	if(is_plugin_enabled("bookmarks") && get_plugin_setting("bookmarks_plugin_enable", "widgets_eligo") == "yes") {
		set_view_location ('widgets/bookmarks/edit', $CONFIG->pluginspath.'widgets_eligo/plus_views/');			
		set_view_location ('widgets/bookmarks/view', $CONFIG->pluginspath.'widgets_eligo/plus_views/');	
	}
	
	if(is_plugin_enabled("blog") && get_plugin_setting("blog_plugin_enable", "widgets_eligo") == "yes") {
		set_view_location ('widgets/blog/edit', $CONFIG->pluginspath.'widgets_eligo/plus_views/');			
		set_view_location ('widgets/blog/view', $CONFIG->pluginspath.'widgets_eligo/plus_views/');	
	}
	
	if(is_plugin_enabled("groups") && get_plugin_setting("groups_plugin_enable", "widgets_eligo") == "yes") {
		set_view_location ('widgets/a_users_groups/edit', $CONFIG->pluginspath.'widgets_eligo/plus_views/');			
		set_view_location ('widgets/a_users_groups/view', $CONFIG->pluginspath.'widgets_eligo/plus_views/');	
	}
	
	if(is_plugin_enabled("file") && get_plugin_setting("files_plugin_enable", "widgets_eligo") == "yes") {
		set_view_location ('widgets/filerepo/edit', $CONFIG->pluginspath.'widgets_eligo/plus_views/');			
		set_view_location ('widgets/filerepo/view', $CONFIG->pluginspath.'widgets_eligo/plus_views/');	
	}
	
	if(is_plugin_enabled("pages") && get_plugin_setting("pages_plugin_enable", "widgets_eligo") == "yes") {
		set_view_location ('widgets/pages/edit', $CONFIG->pluginspath.'widgets_eligo/plus_views/');			
		set_view_location ('widgets/pages/view', $CONFIG->pluginspath.'widgets_eligo/plus_views/');	
	}
	
	// Various functions used by some of the Eligo widgets above
	if( (is_plugin_enabled("bookmarks") && get_plugin_setting("bookmarks_plugin_enable", "widgets_eligo") == "yes") 
		|| (is_plugin_enabled("blog") && get_plugin_setting("blog_plugin_enable", "widgets_eligo") == "yes")
		|| (is_plugin_enabled("groups") && get_plugin_setting("groups_plugin_enable", "widgets_eligo") == "yes") 
		|| (is_plugin_enabled("file") && get_plugin_setting("files_plugin_enable", "widgets_eligo") == "yes")
		|| (is_plugin_enabled("pages") && get_plugin_setting("pages_plugin_enable", "widgets_eligo") == "yes")) {
			// Kinda crappy, but overwrite the entire widget layout because we need a simple DIV with unique ID for changing the title in the edit panel
			// But only over write it if the context_switcher is not enabled.
			if (!is_plugin_enabled("context_switcher")) set_view_location ('canvas/layouts/widgets', $CONFIG->pluginspath.'widgets_eligo/plus_views/');  
			register_plugin_hook('action','widgets/save', 'CS_save_multiselect_hook');
		}
			
}


register_elgg_event_handler('init', 'system', 'widgets_eligo_init');
	
?>
