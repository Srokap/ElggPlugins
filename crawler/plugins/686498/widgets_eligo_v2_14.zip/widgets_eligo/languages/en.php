<?php 
	$english = array(
		/*
		 * Default Context Switcher Widget names
		 * 
		 * When adding new widgets, change these settings below 
		 * 
		 */
		'eligo:GROUP:restrictby:arbit_display_my' => "This group",
		'eligo:GROUP:restrictby:arbit_display_friends' => "Group's members",
		'eligo:GROUP:restrictby:arbit_display_all' => 'Everyone',
		'eligo:WIDGETS:restrictby:arbit_display_my' => "My Own",
		'eligo:WIDGETS:restrictby:arbit_display_friends' => "Those I am Following",
		'eligo:WIDGETS:restrictby:arbit_display_all' => 'My Groups',
	
	
		'eligo:CS_GROUP_BLOG:editpanel' => 'Group Blog: ',
		'eligo:CS_GROUP_BLOG:defaulttitle' => 'Our Blogs',	
		'eligo:CS_GROUP_BLOG:showselected' => 'Select group blogs to show:',
		'eligo:CS_GROUP_BLOG:restrictby:who' => "Whose blogs to show:",
		'eligo:CS_GROUP_BLOG:noposts' => 'No blogs to show.',
		'eligo:CS_GROUP_BLOG:restrictby' => 'Display only blogs according to:',
		'eligo:CS_GROUP_BLOG:restrictbydate' => 'Shows blogs by date range<br> From: ',
		'eligo:CS_GROUP_BLOG:restrictby:hide_title' => 'Display each blog according to:',
	
		'eligo:CS_GROUP_FILES:editpanel' => 'Group Files: ',
		'eligo:CS_GROUP_FILES:defaulttitle' => 'Our Files',
		'eligo:CS_GROUP_FILES:showselected' => 'Select group files to show:',
		'eligo:CS_GROUP_FILES:restrictby:who' => "Whose files to show:",
		'eligo:CS_GROUP_FILES:noposts' => 'No files to show.',	
		'eligo:CS_GROUP_FILES:restrictby' => 'Display only files according to:',
		'eligo:CS_GROUP_FILES:restrictbydate' => 'Shows files by date range<br> From: ',
		'eligo:CS_GROUP_FILES:restrictby:hide_title' => 'Display each file according to:',
	
		'eligo:CS_GROUP_PAGES:editpanel' => 'Group Pages: ',
		'eligo:CS_GROUP_PAGES:defaulttitle' => 'Our Pages',
		'eligo:CS_GROUP_PAGES:showselected' => 'Select group pages to show:',
		'eligo:CS_GROUP_PAGES:restrictby:who' => "Whose pages to show:",
		'eligo:CS_GROUP_PAGES:noposts' => 'No pages to show.',
		'eligo:CS_GROUP_PAGES:restrictby' => 'Display only pages according to:',
		'eligo:CS_GROUP_PAGES:restrictbydate' => 'Shows pages by date range<br> From: ',
		'eligo:CS_GROUP_PAGES:restrictby:hide_title' => 'Display each page according to:',
	
		'eligo:CS_GROUP_BOOKMARKS:editpanel' => 'Group Bookmarks: ',
		'eligo:CS_GROUP_BOOKMARKS:defaulttitle' => 'Our Bookmarks',
		'eligo:CS_GROUP_BOOKMARKS:showselected' => 'Select group bookmarks to show:',
		'eligo:CS_GROUP_BOOKMARKS:restrictby:who' => "Whose bookmarks to show:",
		'eligo:CS_GROUP_BOOKMARKS:noposts' => 'No bookmarks to show.',	
		'eligo:CS_GROUP_BOOKMARKS:restrictby' => 'Display only bookmarks according to:',
		'eligo:CS_GROUP_BOOKMARKS:restrictbydate' => 'Shows bookmarks by date range<br> From: ',
		'eligo:CS_GROUP_BOOKMARKS:restrictby:hide_title' => 'Display each bookmark according to:',
	
		'eligo:CS_BOOKMARKS:editpanel' => 'Bookmarks: ',
		'eligo:CS_BOOKMARKS:defaulttitle' => 'My Bookmarks',
		'eligo:CS_BOOKMARKS:showselected' => 'Select bookmarks to show:',	
		'eligo:CS_BOOKMARKS:restrictby:who' => "Whose bookmarks to show:",
		'eligo:CS_BOOKMARKS:noposts' => 'No bookmarks to show.',
		'eligo:CS_BOOKMARKS:restrictby' => 'Display only bookmarks according to:',
		'eligo:CS_BOOKMARKS:restrictbydate' => 'Shows bookmarks by date range<br> From: ',
		'eligo:CS_BOOKMARKS:restrictby:hide_title' => 'Display each bookmark according to:',
				
		'eligo:CS_BLOG:editpanel' => 'Blogs: ',
		'eligo:CS_BLOG:defaulttitle' => 'My Blog',
		'eligo:CS_BLOG:showselected' => 'Select blogs to show:',
		'eligo:CS_BLOG:restrictby:who' => "Whose blogs to show:",
		'eligo:CS_BLOG:noposts' => 'No blogs to show.',
		'eligo:CS_BLOG:restrictby' => 'Display only blogs according to:',
		'eligo:CS_BLOG:restrictbydate' => 'Shows blogs by date range<br> From: ',
		'eligo:CS_BLOG:restrictby:hide_title' => 'Display each blog according to:',
					
		'eligo:CS_GROUP:editpanel' => 'Group: ',
		'eligo:CS_GROUP:defaulttitle' => 'My Groups',
		'eligo:CS_GROUP:showselected' => 'Select groups to show:',
		'eligo:CS_GROUP:restrictby:who' => "Whose groups to show:",
		'eligo:CS_GROUP:noposts' => 'No groups to show.',
		'eligo:CS_GROUP:restrictby' => 'Display only groups according to:',
		'eligo:CS_GROUP:restrictbydate' => 'Shows groups by date range<br> From: ',
		'eligo:CS_GROUP:restrictby:hide_title' => 'Display each group according to:',	
		'eligo:group:nogroup' => '&nbsp;&nbsp;No groups to display',
	
		'eligo:CS_FILES:editpanel' => 'Files: ',
		'eligo:CS_FILES:defaulttitle' => 'My Files',
		'eligo:CS_FILES:showselected' => 'Select files to show:',
		'eligo:CS_FILES:restrictby:who' => "Whose files to show:",
		'eligo:CS_FILES:noposts' => 'No files to show.',
		'eligo:CS_FILES:restrictby' => 'Display only files according to:',
		'eligo:CS_FILES:restrictbydate' => 'Shows files by date range<br> From: ',
		'eligo:CS_FILES:restrictby:hide_title' => 'Display each files according to:',
		'eligo:files:nogroup' => '&nbsp;&nbsp;No files to display',

		'eligo:CS_PAGES:editpanel' => 'Pages: ',
		'eligo:CS_PAGES:defaulttitle' => 'My Pages',
		'eligo:CS_PAGES:showselected' => 'Select pages to show:',
		'eligo:CS_PAGES:restrictby:who' => "Whose pages to show:",
		'eligo:CS_PAGES:noposts' => 'No pages to show.',
		'eligo:CS_PAGES:restrictby' => 'Display only pages according to:',
		'eligo:CS_PAGES:restrictbydate' => 'Shows pages by date range<br> From: ',
		'eligo:CS_PAGES:restrictby:hide_title' => 'Display each page according to:',
		'eligo:pages:nogroup' => '&nbsp;&nbsp;No pages to display',
	
		'eligo:widget:restrictby:arbit_display_my' => "Just mine",
		'eligo:widget:restrictby:arbit_display_friends' => "My friends",
		'eligo:widget:restrictby:arbit_display_all' => 'All Sites',
	
	
		'eligo:plugin:gcl:text' => 'Enable Eligo Group Custom Layout Widgets',
		'eligo:plugin:bookmark:text' => 'Enable Eligo Bookmark Widget',
		'eligo:plugin:blog:text' => 'Enable Eligo Blog Widget',
		'eligo:plugin:groups:text' => 'Enable Eligo Groups Widget',
		'eligo:plugin:files:text' => 'Enable Eligo Files Widget',	
		'eligo:plugin:pages:text' => 'Enable Eligo Pages Widget',
		'eligo:plugin:niceicons' => 'Show icons beside widget titles for the type of record being shown. ',
		'eligo:plugin:ajaxicons' => 'Show icon beside widget titles for asyncronous select box loading. ',
		'eligo:record:private' => ' - This is a private (pr) record',
		'eligo:record:loggedin' => ' - This is a logged-in-user only (lg) record',		
		'eligo:record:public' => ' - This is a public (pb) record',	
		'eligo:record:group' => ' - This is a group only (gb) record',
	    'eligo:ajaxerror' => "Communication with the server has been lost or an error occured when trying to update select boxes (Eligo Ajax Error)",
        'eligo:ajaxworking' => "Loading records from the server...",
		'eligo:ajax:refreshpage' => 'An error occured when updating the select box, refresh the page...',
	
	
		/*
		 * It should not be necessary to change any of the text below this line for new widgets.
		 * 
		 * These are used by all the widgets:
		 * 
		 */
		'eligo:default:noposts' => 'No records found.',
		'eligo:widget:currently:are' => 'There are currently ',
	 	'eligo:widget:records:found' => ' record(s) found.',
		'eligo:widget:change_title' => 'Change widget name:',
		'eligo:widget:restrictbydate:to' => 'To: ',
		'eligo:widget:restrictby:date' => 'Date Range',
		'eligo:widget:restrictby:number' => 'Number',
		'eligo:widget:sortby' => 'Sort results: ',
		'eligo:widget:sortby:date' => 'By Date (default)',
		'eligo:widget:sortby:title' => 'By Title',
		'eligo:widget:sortby:owner' => 'By Owner',
		'eligo:widget:sortby:date:desc' => 'By Date, descending',
		'eligo:widget:sortby:title:desc' => 'By Title, descending',
		'eligo:widget:sortby:owner:desc' => 'By Owner, descending',
		'eligo:widget:numbertodisplay' => 'Number of recent items to display:',
		'eligo:widget:num_display:all' => "All",
		'eligo:widget:restrictbydate:to' => 'To: ',
		'eligo:widget:restrictby:showtitle' => 'Hide the following: ',
		'eligo:widget:restrictby:showtitle:title' => 'Title',
		'eligo:widget:restrictby:showtitle:date' => 'Date',
		'eligo:widget:restrictby:showtitle:both' => 'Both',
		'eligo:widget:restrictby:showlength' => 'How much to show of each post?',
		'eligo:widget:restrictby:showlength:whole' => 'Whole post',
		'eligo:widget:restrictby:showlength:firsttwo' => 'A few lines',
		'eligo:widget:restrictby:showlength:none' => 'None',
		'eligo:widget:restrictby:arbitrary' => 'Selected',	
		'eligo:widget:showselected:mine' => "Select from yours: (CTRL click)",
		'eligo:widget:showselected:friends' => "Select from friends: ",
		'eligo:widget:showselected:all' => "Select from all:",
		'eligo:widgets:bookmark:more' => "More",
		'eligo:option:loading' => '-- loading ',
		'eligo:option:loading:end' => ' records --',	
	
		'eligo:plugin:missing' => ' is missing',
		'eligo:plugin:notenabled' => ' is installed but not enabled',
		'eligo:plugin:wrongorder' => ' is installed, enabled but located after Widgets Eligo in the plugin list - it needs to be before',
		'eligo:plugin:checking_requirements' => 'Checking requirements - ',
		'eligo:plugin:jquery_missing' => ' missing or not enabled!',
		'eligo:plugin:found' => 'Found!',
		'eligo:plugin:select' => 'Select widgets to enable below:',
		
		'eligo:gcl:savesettings' => '<p>Before you can edit the settings for this widget you must save this group layout and then choose "edit group layout" once more from the menu.</p>',
		'eligo:widget:my_icon' => 'Currently showing yours or group only records.  This will only update after a page refresh.',
		'eligo:widget:friends_icon' => 'Currently showing records from friends or group members.  This will only update after a page refresh.',	
		'eligo:widget:all_icon' => 'Currently showing records from your group(s).  This will only update after a page refresh.',	
	
		
	);
	
	add_translation("en", $english);
?>
