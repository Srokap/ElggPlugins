<?php
/* 
 * Handles AJAX calls to update the search boxes of widgets.
 * Returns single HTML that is mushed together:
 *   XX%%% - "XX" contains the number of options statements, used to dynamically resize the select boxes
 *   <option... - All the option statements.
 *   
 *   For example "2%%%<option value="1">option one</option><optiong value="2">option two</option>
 */


// context - is the multiple select box to update.
 $context = get_input('context');
 // group - we need this information to tell what the current SELECTED values are for the select boxes.
$group = get_input('group');
// guid - This is the widgt ID
$widget_guid=get_input('guid');
// sortby - One of three types of constants used to determine what sort function should be used, CS_byName, CS_byAccess, CS_byDate.
$sort_by = get_input('sortby');

$widget = get_entity($widget_guid);
// changes "arbit_display_my<widget guid>" into "my"
$record_type = substr($group, 14, 2);
switch ($record_type){
  	case "my":
  		$selected_records = $widget->CS_arbit_display;
  		break;
  	case "al" :
  		$selected_records = $widget->CS_arbit_display_all;
  		$record_type = "all";				
  		break;
  	case "fr": // short for friends
		$selected_records = $widget->CS_arbit_display_friends;
		$record_type = "friends";
  		break;
}
// Now $results comes back as two arrays, $arr1 contains the $include_date and $width of the 
// select boxes.  $arr2 contains the list of records used to create the option statements for the select box.
list ($arr1, $arr2) = plus_view_get ($context, $widget['container_guid'], $record_type, false);

$include_date = $arr1[0];
$width = $arr1[1];

CS_sort_array_by ($arr2, $sort_by);

// The "%%%" is a unique identifier for the client side javascript code so it knows where the size is.  Both are stripped off.
$response = sizeof($arr2)."%%%".CS_generate_select_options($arr2, $selected_records, $include_date, $width);

/**
 * validate_action_tokens always seems to control the page no matter what $visibleerrors is set to!!??
 * Fixed this client side in the ajax calling script (core_javascript.php)
if (validate_action_token(false)) {
} else {
 $response = "1%%%<option>--- Refresh page ---</option>";	
} // checks security tokens
**/

echo $response;
exit;

?>
