<?php 
	$entity = $vars["entity"];

	echo '<h3 class="settings">'.elgg_echo("group_custom_layout:widgets:files:settings:title").'</h3>';
	
	if(!empty($entity) && $entity instanceof ElggObject && $entity->getSubtype() == GROUP_CUSTOM_LAYOUT_WIDGET){
		$widget_name = $entity->guid;
		$bookmark_count = $entity->bookmark_count;
		$post_prefix = "group_widgets_" . $entity->guid . "_settings";
		plus_edit_display_control ("CS_GROUP_FILES", $vars, $post_prefix);
	} else {
		// Brand new widget, unsaved FYI
		$widget_name = $vars["widget_name"];
		// Believe it or not, this is the temporary variable name used by GCL to temporarily save edit info until the widget is created.
		//$vars['entity']->guid = "bookmarks";
		echo elgg_echo("eligo:gcl:savesettings");   
	}
	