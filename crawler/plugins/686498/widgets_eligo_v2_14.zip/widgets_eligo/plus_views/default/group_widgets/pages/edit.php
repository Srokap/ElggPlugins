<?php 

	$entity = $vars["entity"];
	
	echo '<h3 class="settings">'.elgg_echo("group_custom_layout:widgets:pages:settings:title").'</h3>';
	
	if(!empty($entity) && $entity instanceof ElggObject && $entity->getSubtype() == GROUP_CUSTOM_LAYOUT_WIDGET){
		$post_prefix = "group_widgets_" . $entity->guid . "_settings";
		plus_edit_display_control ("CS_GROUP_PAGES", $vars, $post_prefix);
	} else {
		// Brand new widget, unsaved FYI
		echo elgg_echo("eligo:gcl:savesettings");   
	}	
 	
