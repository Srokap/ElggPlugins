<?php 

$group = $vars["group"];

echo '<div class="group_widget">';
$widget = $vars["widget"];
// Setup icon for display, if any
echo '<h2> '.CS_get_widget_icon($widget).' '.$widget->CS_display_title.'</span></h2>';  // The opening <span> is created in CS_get_widget_icon
if(is_plugin_enabled("pages") && $group->pages_enable != "no"){

	$shares = plus_view_display("CS_GROUP_PAGES", array('entity' => $vars['widget']), $group->guid);
	if($shares){
			foreach($shares as $share){
				echo CS_page_view (array('entity' => $share));
			} // For each $share.			
	}  else {
		echo "<div class=\"forum_latest more_content\">" . elgg_echo("eligo:pages:nogroup")  . "</div>";
	} // if $shares
		
} // if plugin
echo '</div>';
