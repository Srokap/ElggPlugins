<script type="text/javascript">
	$(document).ready(function () {
		$('a.show_file_desc').click(function () {
			$(this.parentNode).children("[class=filerepo_listview_desc]").slideToggle("fast");
			return false;
		});
	});
</script>

<?php 


$group = $vars["group"];

if(is_plugin_enabled("file") && $group->files_enable != "no"){
	$widget = $vars["widget"];
	$shares = plus_view_display("CS_GROUP_FILES", array('entity' => $vars['widget']), $group->guid);
	// Setup icon for display, if any
	echo '<div class="group_widget">
			<h2>'.CS_get_widget_icon($widget).' '.$widget->CS_display_title.'</span></h2>'; // The opening <span> is created in CS_get_widget_icon
		
			CS_files_view ($vars, $shares);	
	
	echo '</div>';		
} // if plugin

?>