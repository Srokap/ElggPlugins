<?php 
$group = $vars["group"];

if(is_plugin_enabled("blog")){
	$widget = $vars["widget"];
	//echo elgg_view('blog/groupprofile_blog', array('entity' => $group));
	$shares = plus_view_display("CS_GROUP_BLOG", array('entity' => $vars['widget']), $group->guid);
	// Setup icon for display, if any
	echo '<div class="group_widget">
			<h2>'.CS_get_widget_icon($widget).' '.$widget->CS_display_title.'</span></h2>'; 	// The opening <span> is created in CS_get_widget_icon
	if($shares){

			foreach($shares as $share){
				echo '<div class="search_listing">';				
				echo CS_blog_view ($share, $widget->CS_hide_title,  $widget->CS_length_display);
				echo '</div>';				
			} // For each $share.

	}  else {
		echo "<div class=\"forum_latest\">" . elgg_echo("blog:nogroup") . "</div>";
	} // if $shares
	echo '</div>';		
} // if plugin
