<?php  ?>

#datepick-div {
	z-index: 110;
}

input[type="radio"] {
    float:left;
    //clear:both;
}
label.radioinput {
	margin: 5px 5px 5px 0px;
	clear:both;

}
