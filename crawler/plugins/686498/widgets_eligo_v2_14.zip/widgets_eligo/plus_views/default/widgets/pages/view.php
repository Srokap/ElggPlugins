<style type="text/css">
#pages_widget .pagination {
    display:none;
}
</style>
<?php

	$shares = plus_view_display("CS_PAGES", $vars, $vars['entity']->owner_guid);
	
	if($shares){
			echo '<div id="pages_widget">';
			foreach($shares as $share){
				echo '<div class="search_listing">';
				echo CS_page_view (array('entity' => $share));
				echo '</div>';
			} // For each $share.
			echo '</div>';
	}  else {
		echo "<div class=\"forum_latest more_content\">" . elgg_echo("eligo:pages:nogroup")  . "</div>";
	} // if $shares
	

?>