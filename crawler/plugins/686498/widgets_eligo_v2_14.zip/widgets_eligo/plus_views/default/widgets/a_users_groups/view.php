<?php
 
	$shares = plus_view_display("CS_GROUP", $vars, $vars['entity']->owner_guid);

	if($shares){
			foreach($shares as $share){
				echo "<div class=\"groupmembershipwidget\">";
				$share->widget_guid = $vars['widget']->guid;
				echo CS_group_view ($share);
				echo "</div>";
			} // For each $share.			
	}  else {
		echo elgg_echo("eligo:group:nogroup");
	} // if $shares

?>

