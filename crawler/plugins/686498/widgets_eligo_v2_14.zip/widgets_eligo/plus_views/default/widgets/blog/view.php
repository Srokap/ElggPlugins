<?php


$widget = $vars["entity"]; // Used below to pass in the hide_title and length_display variables for the widget only, not the blogs entitys

//$shares = plus_view_display("CS_BLOG", $vars, $vars['guid']);
$shares = plus_view_display("CS_BLOG", $vars, $vars['entity']->owner_guid);
if($shares){
	foreach($shares as $share){
		echo '<div class="contentWrapper singleview">
			<div class="blog_post">';		
		echo CS_blog_view ($share, $widget->CS_hide_title,  $widget->CS_length_display);
		echo '</div></div>';
	} // For each $share.
}  else {
	echo elgg_echo('eligo:CS_BLOG:noposts');
} // if $shares

?>

