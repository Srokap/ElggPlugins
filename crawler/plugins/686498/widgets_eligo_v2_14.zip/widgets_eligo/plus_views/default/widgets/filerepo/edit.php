<?php
	// Call our superdupper helper function
 	plus_edit_display_control ("CS_FILES", $vars);
?>

<p>
    <?php echo elgg_echo("file:gallery_list"); ?>?
    <select name="params[gallery_list]">
        <option value="1" <?php if($vars['entity']->gallery_list == 1) echo "SELECTED"; ?>><?php echo elgg_echo("file:list"); ?></option>
	    <option value="2" <?php if($vars['entity']->gallery_list == 2) echo "SELECTED"; ?>><?php echo elgg_echo("file:gallery"); ?></option>
    </select>
</p>