<?php
	// Call our superdupper helper function
 	plus_edit_display_control ("CS_GROUP", $vars);
?>
