<script type="text/javascript">
$(document).ready(function () {

$('a.show_file_desc').click(function () {
	$(this.parentNode).children("[class=filerepo_listview_desc]").slideToggle("fast");
	return false;
});

}); /* end document ready function */
</script>


<?php
	$shares = plus_view_display("CS_FILES", $vars, $vars['entity']->owner_guid);
	if (!empty($shares)) { 
			CS_files_view ($vars, $shares);
	}  else {
		echo "<div class=\"forum_latest more_content\">" . elgg_echo("eligo:CS_FILES:noposts")  . "</div>";
	} // if $shares

	
?>