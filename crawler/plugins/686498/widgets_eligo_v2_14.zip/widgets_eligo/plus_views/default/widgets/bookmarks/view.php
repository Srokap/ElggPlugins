<script type="text/javascript">
$(document).ready(function () {
    $('a.share_more_info').click(function () {
		$(this.parentNode).children("[class=share_desc]").slideToggle("fast");
		return false;
    });
}); /* end document ready function */
</script>

<?php
 
	$shares = plus_view_display("CS_BOOKMARKS", $vars, $vars['entity']->owner_guid);

	if($shares){
			foreach($shares as $share){
				$share->widget_guid = $vars['widget']->guid;
				echo CS_bookmark_view ($share);
			} // For each $share.
	}  else {
		echo "<div class=\"forum_latest more_content\">" . elgg_echo("bookmarks:nogroup")  . "</div>";
	} // if $shares



