
<fb:login-button perms="<? echo $perms ?>"</fb:login-button>
<div id="fb-root">Facebok connect
<script src="http://connect.facebook.net/en_US/all.js"></script>
</div>

