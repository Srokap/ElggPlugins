<?php
require "facebook-platform/facebook.php";
require "twitter/EpiCurl.php";
require "twitter/EpiOAuth.php";
require "twitter/EpiTwitter.php";
$plugin_name = "fbconnect";

register_elgg_event_handler('init', 'system', 'fbconnect_init');
register_plugin_hook('entity:icon:url', 'user', 'fbconnect_icon_url');

function fbconnect_init() {

    global $CONFIG;
    register_action('fbconnect/condividi', true, $CONFIG->pluginspath . 'fbconnect/actions/condividi.php');
    register_translations($CONFIG->pluginspath . "fbconnect/languages/");


    extend_view('account/forms/register', 'fbconnect/register');
    extend_view("account/forms/login", "fbconnect/login");
}



function get_facebook_cookie($app_id, $application_secret) {
    global $CONFIG;
    $args = array();
    parse_str(trim($_COOKIE['fbs_' . $app_id], '\\"'), $args);
    ksort($args);
    $payload = '';
    foreach ($args as $key => $value) {
        if ($key != 'sig') {
            $payload .= $key . '=' . $value;
        }
    }
    if (md5($payload . $application_secret) != $args['sig']) {
        return null;
    }
    return $args;
    $CONFIG->uid = $cookie['uid'];
}


function fbconnect_client() {
    global $CONFIG;
    static $fb = NULL;
    if (!$fb instanceof Facebook) {
        include_once($CONFIG->pluginspath . 'fbconnect/facebook-platform/facebook.php');
        $api_key = get_plugin_setting('api_key', 'fbconnect');
        $api_secret = get_plugin_setting('api_secret', 'fbconnect');
        $fb = new Facebook($api_key, $api_secret);
        $fb->validate_fb_params();
    }
    return $fb;
}

function fbconnect_get_info_from_fb($fbuid, $fields) {
    if (fbconnect_client() && $fields) {
        try {
            $result = fbconnect_client()->api_client->fql_query("SELECT $fields FROM user WHERE uid = $fbuid");
            return $result[0];
        } catch (Exception $e) {
            error_log('Exception thrown while using FQL: ' . $e->getMessage());
        }
    }
}
function fql($query) {
    if (fbconnect_client() && $query) {
        try {
            $result = fbconnect_client()->api_client->fql_query($query);
            return $result;
        } catch (Exception $e) {
            error_log('Exception thrown while using FQL: ' . $e->getMessage());
        }
    }
}

///beta
function getFriendList($appUser = false, $fbuserId = 0)
	{
	
        // Does the friends need to add the app to be qualified ? ;)
   		if ($appUser == false)
   		{
	   		$usersArray = fbconnect_client()->api_client->fql_query("SELECT uid,name FROM user WHERE uid IN (SELECT uid2 FROM friend WHERE uid1 = {$fbuserId})");
   		}
   		else
   		{
	   		$usersArray = fbconnect_client()->api_client->fql_query("SELECT uid,name FROM user WHERE has_added_app = 1 AND uid IN (SELECT uid2 FROM friend WHERE uid1 = {$fbuserId})");
   		}
   		if (empty($usersArray))
   		{
		   return array();
   		}

   		return $usersArray;
	}
function renderInvite($friends, $url, $name){


			//$friends = implode(',', $friends);
			$content = 	"<fb:name uid=\"".$fb->fbuser."\" firstnameonly=\"true\" shownetwork=\"false\"/> ha iniziato ad usare <a href=\"".$url."/\">".$name."</a> e ti invita a provarlo!\n".
						"<fb:req-choice url=\" label=\"Aggiungi ".$name." al tuo profilo\"/>";
		?>
            <fb:request-form
                action="invite.php"
                method="post"
                type="<?php echo $name; ?>"
                content="<?php echo htmlentities($content); ?>">

                <fb:multi-friend-selector
                actiontext="Seleziona gli amici che vuoi invitare ad usare <?php echo $name; ?>!"
                exclude_ids="<?php echo $friends; ?>" />
            </fb:request-form>
		<?php
	}


?>