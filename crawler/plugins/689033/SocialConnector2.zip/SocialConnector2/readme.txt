Social Connect 2 plugin - Developed by Dario Agliottone  18/01/2011

FEATURES: TWITTER AND FACEBOOK

1. CREATE FACEBOOK APP : http://www.facebook.com/developers/apps.php 
	ANNOTATE  APIKEY, APISECRETKEY AND APPID
2. CREATE TWITTER APP http://dev.twitter.com/apps/
	ANNOTATE  Consumer key AND Consumer secret key
3. COPY THIS FOLDER FBCONNECT IN MOD DIRECTORY
4. GO IN TOOL PLUGIN ADMINISTRATION PAGE AND IN SETTINGS OF FBCONNECT PLUGIN SETS THE INFO KEY AND 
	SET YES.
5. YOU MUST BE SURE THAT THE KEYS ARE VALID!!

6.

1 open the file actions\register.php
-AND ADD THIS CODE 
-----------------------------------------
$gfcid=get_input('gfcid');
$uid=get_input('uid');
$twitter=get_input('twitter');
-------------------------------------------------
AND CHANGE THIS:

----------
$guid = register_user($username, $password, $name, $email, false, $friend_guid, $invitecode);
------------

WITH THIS:
-----------------
$guid = register_user($username, $password, $name, $email, false, $friend_guid, $invitecode,$gfcid,$uid,$twitter);
-----------------------

NOW open the file views\default\account\forms\register.php

-AND ADD THIS CODE 
---------------------------
$form_body .= elgg_view('input/hidden', array('internalname' => 'gfcid', 'value' => ''));
$form_body .= elgg_view('input/hidden', array('internalname' => 'uid', 'value' => ''));
$form_body .= elgg_view('input/hidden', array('internalname' => 'twitter', 'value' => ''));
----------------------------------------

NOW open the file engine\lib\user.php

AND CHANGE THIS:
---------------------------
function register_user($username, $password, $name, $email, $allow_multiple_emails = false, $friend_guid = 0, $invitecode = '') {
-----------------------

WITH THIS:
-----------------
function register_user($username, $password, $name, $email, $allow_multiple_emails = false, $friend_guid = 0, $invitecode = '',$gfcid='',$uid='',$twitter='') {
-------------------------

-AND ADD THIS CODE 
$user->gfcid = $gfcid;
$user->uid = $uid;
$user->twitter = $twitter;


