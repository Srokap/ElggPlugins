<?php

/**
 * Activity viewer
 *
 * @package Elgg
 * @subpackage Core
 * @license http://www.gnu.org/licenses/old-licenses/gpl-3.0.html  GNU Public License version 3
 * @author DiRaOL - diraol@diraol.eng.br
 * @link http://blog.diraol.eng.br
 * @published 09 March 2010
 */

$portugues_brasileiro = array(

/**
 * Sites
 * Sitios
 * Traduzido PT_BR
 */

	'item:site' => 'Sites',

/**
 * Sessions
 * Sessões
 * Traduzido PT_BR
 */

	'login' => "Entrar",
	'loginok' => "Você se conectou com sucesso.",
	'loginerror' => "Ocorreu um erro na tentativa se conectar. Isto pode ter ocorrido pois você não validou sua conta, as informações que você forneceu estão incorretas ou você tentou se conectar muitas vezes. Certifique-se de que seus dados estão corretos e tente novamente.",

	'logout' => "Sair",
	'logoutok' => "Você se desconectou com sucesso.",
	'logouterror' => "Nós não pudemos desconectá-lo com sucesso. Por favor, tente novamente.",

	'loggedinrequired' => "Você deve estar conectado para ver esta página.",
	'adminrequired' => "Você deve ser um administrador para ver esta página.",

/**
 * Errors
 * Erros
 * Não-Traduzido para PT_BR
 */
	'exception:title' => "Seja bem vindo ao Elgg.",

	'InstallationException:CantCreateSite' => "Não foi possível criar um ElggSite padrão com as credenciais Nome:%s, URL: %s",

	'actionundefined' => "A ação requerida (%s) não está definida no sistema.",
	'actionloggedout' => "Você não pode executar esta ação enquando desconectado.",

	'SecurityException:Codeblock' => "acesso negado para executar blocos de código privilegiado",
	'DatabaseException:WrongCredentials' => "Elgg não p&ocirc;de se conectar ao banco de dados usando as credenciais fornecidas.",
	'DatabaseException:NoConnect' => "Elgg não pode selecionar o banco de dados '%s', verifique se o banco de dados foi criado e se você tem acesso a ele.",
	'SecurityException:FunctionDenied' => "Acesso a função privilegiada '%s' foi negado.",
	'DatabaseException:DBSetupIssues' => "Houve um certo número de questões: ",
	'DatabaseException:ScriptNotFound' => "Elgg não consegui encontrar o script de banco de dados solicitado em %s.",

	'IOException:FailedToLoadGUID' => "Falha ao carregar novo %s de GUID: %d",
	'InvalidParameterException:NonElggObject' => "Foi passado um non-ElggObject para um construtor ElggObject!",
	'InvalidParameterException:UnrecognisedValue' => "valor não reconhecido passado para o constuctor.",

	'InvalidClassException:NotValidElggStar' => "GUID:%d não é válido %s",

	'PluginException:MisconfiguredPlugin' => "%s é um plugin mal configurado. Ele foi desativado. Por favor veja o Wiki Elgg para possíveis causas.",

	'InvalidParameterException:NonElggUser' => "Foi passado um non-ElggUser para um construtor ElggUser!",

	'InvalidParameterException:NonElggSite' => "Foi passado um non-ElggSite para um construtor ElggSite!",

	'InvalidParameterException:NonElggGroup' => "Foi passado um non-ElggGroup para um construtor ElggGroup!",

	'IOException:UnableToSaveNew' => "Não foi possível salvar um novo %s",

	'InvalidParameterException:GUIDNotForExport' => "GUID não foi especificado durante a exportação, isto nunca deve ocorrer.",
	'InvalidParameterException:NonArrayReturnValue' => "A função de serialização de entidade passou um par&acirc;metro de retorno de valor que não é um vetor.",

	'ConfigurationException:NoCachePath' => "Endereço do cache não definido",
	'IOException:NotDirectory' => "%s não é um diretório.",

/* Traduzido até aqui para Português (PT_BR) - CONTINUAR ABAIXO */

	'IOException:BaseEntitySaveFailed' => "Unable to save new object's base entity information!",
	'InvalidParameterException:UnexpectedODDClass' => "import() passed an unexpected ODD class",
	'InvalidParameterException:EntityTypeNotSet' => "Entity type must be set.",

	'ClassException:ClassnameNotClass' => "%s is not a %s.",
	'ClassNotFoundException:MissingClass' => "Class '%s' was not found, missing plugin?",
	'InstallationException:TypeNotSupported' => "Type %s is not supported. This indicates an error in your installation, most likely caused by an incomplete upgrade.",

	'ImportException:ImportFailed' => "Could not import element %d",
	'ImportException:ProblemSaving' => "There was a problem saving %s",
	'ImportException:NoGUID' => "New entity created but has no GUID, this should not happen.",

	'ImportException:GUIDNotFound' => "Entity '%d' could not be found.",
	'ImportException:ProblemUpdatingMeta' => "There was a problem updating '%s' on entity '%d'",

	'ExportException:NoSuchEntity' => "No such entity GUID:%d",

	'ImportException:NoODDElements' => "No OpenDD elements found in import data, import failed.",
	'ImportException:NotAllImported' => "Not all elements were imported.",

	'InvalidParameterException:UnrecognisedFileMode' => "Unrecognised file mode '%s'",
	'InvalidParameterException:MissingOwner' => "File %s (%d) is missing an owner!",
	'IOException:CouldNotMake' => "Could not make %s",
	'IOException:MissingFileName' => "You must specify a name before opening a file.",
	'ClassNotFoundException:NotFoundNotSavedWithFile' => "Filestore not found or class not saved with file!",
	'NotificationException:NoNotificationMethod' => "No notification method specified.",
	'NotificationException:NoHandlerFound' => "No handler found for '%s' or it was not callable.",
	'NotificationException:ErrorNotifyingGuid' => "There was an error while notifying %d",
	'NotificationException:NoEmailAddress' => "Could not get the email address for GUID:%d",
	'NotificationException:MissingParameter' => "Missing a required parameter, '%s'",

	'DatabaseException:WhereSetNonQuery' => "Where set contains non WhereQueryComponent",
	'DatabaseException:SelectFieldsMissing' => "Fields missing on a select style query",
	'DatabaseException:UnspecifiedQueryType' => "Unrecognised or unspecified query type.",
	'DatabaseException:NoTablesSpecified' => "No tables specified for query.",
	'DatabaseException:NoACL' => "No access control was provided on query",

	'InvalidParameterException:NoEntityFound' => "No entity found, it either doesn't exist or you don't have access to it.",

	'InvalidParameterException:GUIDNotFound' => "GUID:%s could not be found, or you can not access it.",
	'InvalidParameterException:IdNotExistForGUID' => "Sorry, '%s' does not exist for guid:%d",
	'InvalidParameterException:CanNotExportType' => "Sorry, I don't know how to export '%s'",
	'InvalidParameterException:NoDataFound' => "Could not find any data.",
	'InvalidParameterException:DoesNotBelong' => "Does not belong to entity.",
	'InvalidParameterException:DoesNotBelongOrRefer' => "Does not belong to entity or refer to entity.",
	'InvalidParameterException:MissingParameter' => "Missing parameter, you need to provide a GUID.",

	'APIException:ApiResultUnknown' => "API Result is of an unknown type, this should never happen.",
	'ConfigurationException:NoSiteID' => "No site ID has been specified.",
	'SecurityException:APIAccessDenied' => "Sorry, API access has been disabled by the administrator.",
	'SecurityException:NoAuthMethods' => "No authentication methods were found that could authenticate this API request.",
	'InvalidParameterException:APIMethodOrFunctionNotSet' => "Method or function not set in call in expose_method()",
	'InvalidParameterException:APIParametersArrayStructure' => "Parameters array structure is incorrect for call to expose method '%s'",
	'InvalidParameterException:UnrecognisedHttpMethod' => "Unrecognised http method %s for api method '%s'",
	'APIException:MissingParameterInMethod' => "Missing parameter %s in method %s",
	'APIException:ParameterNotArray' => "%s does not appear to be an array.",
	'APIException:UnrecognisedTypeCast' => "Unrecognised type in cast %s for variable '%s' in method '%s'",
	'APIException:InvalidParameter' => "Invalid parameter found for '%s' in method '%s'.",
	'APIException:FunctionParseError' => "%s(%s) has a parsing error.",
	'APIException:FunctionNoReturn' => "%s(%s) returned no value.",
	'APIException:APIAuthenticationFailed' => "Method call failed the API Authentication",
	'APIException:UserAuthenticationFailed' => "Method call failed the User Authentication",
	'SecurityException:AuthTokenExpired' => "Authentication token either missing, invalid or expired.",
	'CallException:InvalidCallMethod' => "%s must be called using '%s'",
	'APIException:MethodCallNotImplemented' => "Method call '%s' has not been implemented.",
	'APIException:FunctionDoesNotExist' => "Function for method '%s' is not callable",
	'APIException:AlgorithmNotSupported' => "Algorithm '%s' is not supported or has been disabled.",
	'ConfigurationException:CacheDirNotSet' => "Cache directory 'cache_path' not set.",
	'APIException:NotGetOrPost' => "Request method must be GET or POST",
	'APIException:MissingAPIKey' => "Missing API key",
	'APIException:BadAPIKey' => "Bad API key",
	'APIException:MissingHmac' => "Missing X-Elgg-hmac header",
	'APIException:MissingHmacAlgo' => "Missing X-Elgg-hmac-algo header",
	'APIException:MissingTime' => "Missing X-Elgg-time header",
	'APIException:MissingNonce' => "Missing X-Elgg-nonce header",
	'APIException:TemporalDrift' => "X-Elgg-time is too far in the past or future. Epoch fail.",
	'APIException:NoQueryString' => "No data on the query string",
	'APIException:MissingPOSTHash' => "Missing X-Elgg-posthash header",
	'APIException:MissingPOSTAlgo' => "Missing X-Elgg-posthash_algo header",
	'APIException:MissingContentType' => "Missing content type for post data",
	'SecurityException:InvalidPostHash' => "POST data hash is invalid - Expected %s but got %s.",
	'SecurityException:DupePacket' => "Packet signature already seen.",
	'SecurityException:InvalidAPIKey' => "Invalid or missing API Key.",
	'NotImplementedException:CallMethodNotImplemented' => "Call method '%s' is currently not supported.",

	'NotImplementedException:XMLRPCMethodNotImplemented' => "XML-RPC method call '%s' not implemented.",
	'InvalidParameterException:UnexpectedReturnFormat' => "Call to method '%s' returned an unexpected result.",
	'CallException:NotRPCCall' => "Call does not appear to be a valid XML-RPC call",

	'PluginException:NoPluginName' => "The plugin name could not be found",

	'ConfigurationException:BadDatabaseVersion' => "The database backend you have installed doesn't meet the basic requirements to run Elgg. Please consult your documentation.",
	'ConfigurationException:BadPHPVersion' => "You need at least PHP version 5.2 to run Elgg.",
	'configurationwarning:phpversion' => "Elgg requires at least PHP version 5.2, you can install it on 5.1.6 but some features may not work. Use at your own risk.",


	'InstallationException:DatarootNotWritable' => "Your data directory %s is not writable.",
	'InstallationException:DatarootUnderPath' => "Your data directory %s must be outside of your install path.",
	'InstallationException:DatarootBlank' => "You have not specified a data directory.",

	'SecurityException:authenticationfailed' => "User could not be authenticated",

	'CronException:unknownperiod' => '%s is not a recognised period.',

	'SecurityException:deletedisablecurrentsite' => 'You can not delete or disable the site you are currently viewing!',

	'memcache:notinstalled' => 'PHP memcache module not installed, you must install php5-memcache',
	'memcache:noservers' => 'No memcache servers defined, please populate the $CONFIG->memcache_servers variable',
	'memcache:versiontoolow' => 'Memcache needs at least version %s to run, you are running %s',
	'memcache:noaddserver' => 'Multiple server support disabled, you may need to upgrade your PECL memcache library',

	'deprecatedfunction' => 'Warning: This code uses the deprecated function \'%s\' and is not compatible with this version of Elgg',

	'pageownerunavailable' => 'Warning: The page owner %d is not accessible!',
/**
 * API
 * API
 * Traduzido para PT_BR
 */
	'system.api.list' => "Listar todas as chamadas para API disponíveis no sistema.",
	'auth.gettoken' => "This API call lets a user obtain a user authentication token which can be used for authenticating future API calls. Pass it as the parameter auth_token",

/**
 * User details
 * Detalhes de Usuários
 * Traduzido PT_BR
 */

	'name' => "Nome de exibição",
	'email' => "Email",
	'username' => "Nome de usuário",
	'password' => "Senha",
	'passwordagain' => "Senha (para verificação)",
	'admin_option' => "Fazer deste usuário um administrador?",

/**
 * Access
 * Acesso
 * Traduzido PT_BR
 */

	'PRIVATE' => "Privado",
	'LOGGED_IN' => "Usuários conectados",
	'PUBLIC' => "Público",
	'access:friends:label' => "Amigos",
	'access' => "Acesso",

/**
 * Dashboard and widgets
 * Painel e Widgets
 * Traduzido PT_BR
 */

	'dashboard' => "Painel",
	'dashboard:configure' => "Editar painel",
	'dashboard:nowidgets' => "Seu painel é sua porta de entrada para a comunidade. Clique em 'Editar painel' para adicionar dispositivos para seguir os conteúdos em nossa comunidade.",

	'widgets:add' => 'Adicionar dispositivos à sua página',
	'widgets:add:description' => "Escolha o dispositivo que você gostaria de adicionar ao seu painel arrastando-os da galeria à direita, para qualquer das três áreas abaixo, e posicione-o aonde deseja que ele apareça.

Para apagar um dispositivo arraste-o de volta à <b>galeria</b>.",
	'widgets:position:fixed' => '(Posição fixa na página)',

	'widgets' => "Dispositivo",
	'widget' => "Dispositivo",
	'item:object:widget' => "Dispositivos",
	'layout:customise' => "Customizar disposição",
	'widgets:gallery' => "Galeria de Dispositivos",
	'widgets:leftcolumn' => "Dispositivos à esquerda",
	'widgets:fixed' => "Posição fixa",
	'widgets:middlecolumn' => "Dispositivos centrais",
	'widgets:rightcolumn' => "Dispositivos à direita",
	'widgets:profilebox' => "Caixa de perfil",
	'widgets:panel:save:success' => "Seus dispositivos foram salvos com sucesso.",
	'widgets:panel:save:failure' => "Ocorreu um problema ao tentar salvar seus dispositivos. Por favor, tente novamente.",
	'widgets:save:success' => "O dispositivo foi salvo com sucesso.",
	'widgets:save:failure' => "Não foi possível salvar seu dispositivo, por favor tente novamente.",
	'widgets:handlernotfound' => 'Ou o dispositivo está com defeito ou foi desabilitado pelo administrador da comunidade.',

/**
 * Groups
 * Grupos
 * Traduzido PT_BR
 */

	'group' => "Grupo",
	'item:group' => "Grupos",

/**
 * Users
 * Usuários
 * Traduzido PT_BR
 */

	'user' => "Usuário",
	'item:user' => "Usuários",

/**
 * Friends
 * Amigos
 * Traduzido PT_BR
 */

	'friends' => "Amigos",
	'friends:yours' => "Seus amigos",
	'friends:owned' => "Amigos de %s",
	'friend:add' => "Adicionar amigo",
	'friend:remove' => "Apagar amigo",

	'friends:add:successful' => "Você adicionou %s como amigo.",
	'friends:add:failure' => "Não foi possível adicionar %s como amigo. Por favor, tente novamente.",

	'friends:remove:successful' => "Você apagou %s de sua lista de amigos com sucesso.",
	'friends:remove:failure' => "Não foi possível apagar %s de sua lista de amigos. Por favor, tente novamente.",

	'friends:none' => "Este usuário ainda não adicionou amigos.",
	'friends:none:you' => "Você ainda não adicionou ninguém como amigo! Pesquise por seus interesses para começar a encontrar pessoas para seguir.",

	'friends:none:found' => "Não foram encontrados amigos.",

	'friends:of:none' => "Ninguém adicionou esse usuário como amigo ainda.",
	'friends:of:none:you' => "Ninguém adicionou você como amigo até agora. Começe a adicionar conteúdos e preencher seu perfil para que as pessoas possam encontrá-lo!",

	'friends:of:owned' => "Pessoas que adicionaram %s como amigo",

	'friends:num_display' => "Número de amigos a serem exibidos",
	'friends:icon_size' => "Tamanho do ícone",
	'friends:tiny' => "minúsculo",
	'friends:small' => "pequeno",
	'friends:of' => "Amigos de",
	'friends:collections' => "Grupos de amigos",
	'friends:collections:add' => "Novo grupo de amigos",
	'friends:addfriends' => "Adicionar amigo",
	'friends:collectionname' => "Nome do grupo",
	'friends:collectionfriends' => "Amigos no grupo",
	'friends:collectionedit' => "Editar este grupo",
	'friends:nocollections' => "Você ainda não possui nenhum grupo.",
	'friends:collectiondeleted' => "Seu grupo foi apagado.",
	'friends:collectiondeletefailed' => "Não foi possível apagar seu grupo, ou você não possui permissão ou algum outro problema ocorreu.",
	'friends:collectionadded' => "Seu grupo foi criado com sucesso",
	'friends:nocollectionname' => "Você deve especificar um nome para seu grupo antes de criá-lo.",
	'friends:collections:members' => "Membros do grupo",
	'friends:collections:edit' => "Editar grupo",

	'friends:river:created' => "%s adicionou o dispositivo de amigos.",
	'friends:river:updated' => "%s atualizou seu dispositivo de amigos.",
	'friends:river:delete' => "%s apagou o dispositivo de amigos.",
	'friends:river:add' => "%s agora é um amigo de", /* CONFERIR */

	'friendspicker:chararray' => 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',

/**
 * Feeds
 * * TRADUZIR *
 * Traduzido PT_BR
 */
	'feed:rss' => 'Inscreva-se para receber atualizações (RSS)',
	'feed:odd' => 'Syndicate OpenDD', /* TRADUZIR */

/**
 * links
 * endereços
 * Traduzido PT_BR
 **/

	'link:view' => 'ver endereço',


/**
 * River
 * * TRADUZIR *
 * Traduzido para PT_BR
 */
	'river' => "River", /* TRADUZIR */
	'river:relationship:friend' => 'é agora amigo em comum.',
	'river:noaccess' => 'Você não possui permissão para visualizar este item.',
	'river:posted:generic' => '%s postado',
	'riveritem:single:user' => 'um usuário',
	'riveritem:plural:user' => 'algumas/alguns usuárias/os',

/**
 * Plugins
 * * TRADUZIR *
 * Traduzido para PT_BR
 */
	'plugins:settings:save:ok' => "Configurações para o plugin %s foram salvas com sucesso.",
	'plugins:settings:save:fail' => "Houve um problema ao salvar as configurações do plugin %s.",
	'plugins:usersettings:save:ok' => "Configurações do usuário para o plugin %s foram salvas com sucesso.",
	'plugins:usersettings:save:fail' => "Houve um problema ao salvar as configurações do usuárioo do plugin %s.",
	'admin:plugins:label:version' => "Versão",
	'item:object:plugin' => 'Configurações do Plugin',

/**
 * Notifications
 * Notificações
 * Traduzido para PT_BR
 */
	'notifications:usersettings' => "Configurações das notificações",
	'notifications:methods' => "Por favor, especifique quais métodos você gostaria de permitir.",

	'notifications:usersettings:save:ok' => "Sua configurações de notificações foram salvas com sucesso.",
	'notifications:usersettings:save:fail' => "Houve um problema ao tentar salvar suas configurações de notificações.",

	'user.notification.get' => 'Exibe as configurações de notificações de um determinado usuário.',
	'user.notification.set' => 'Aplica as configurações de notificações de um determinado usuário.',
/**
 * Search
 * Buscar
 * Traduzido para PT_BR
 */

	'search' => "Pesquisar",
	'searchtitle' => "Pesquisar: %s",
	'users:searchtitle' => "Pesquisando por usuários: %s",
	'groups:searchtitle' => "Pesquisando por grupos: %s",
	'advancedsearchtitle' => "%s com resultados que combinam com %s",
	'notfound' => "Nenhum resultado encontrado.",
	'next' => "Próxima",
	'previous' => "Anterior",

	'viewtype:change' => "Alterar o tipo de lista",
	'viewtype:list' => "Visualização da lista",
	'viewtype:gallery' => "Galeria",

	'tag:search:startblurb' => "Itens cujas tags batem com: '%s':",

	'user:search:startblurb' => "Usuários que combinam com '%s':",
	'user:search:finishblurb' => "Para ver mais, clique aqui.",

	'group:search:startblurb' => "Grupos que combinam com '%s':",
	'group:search:finishblurb' => "Para ver mais, clique aqui.",
	'search:go' => 'Pesquisar',
	'userpicker:only_friends' => 'Apenas amigos',

/**
 * Account
 * Conta de usuário
 * Traduzido para PT_BR
 */

	'account' => "Conta",
	'settings' => "Configurações",
	'tools' => "Ferramentas",
	'tools:yours' => "Suas ferramentas",

	'register' => "Registrar",
	'registerok' => "Você se registrou como %s com sucesso.",
	'registerbad' => "Não foi possível completar seu registro. O nome de usuário pode já existir, sua senha pode não combinar ou nome de usuário ou senha podem ser muito curtos.",
	'registerdisabled' => "Novos registros foram desabilitados pelo administrador do sistema.",

	'firstadminlogininstructions' => 'Seu novo site Elgg foi instalado com sucesso e sua conta administrativa criada. Você pode agora configurar seu site habilitando diversas ferramentas já instaladas.',

	'registration:notemail' => 'O email fornecido por você parece não ser um email válido.',
	'registration:userexists' => 'Este nome de usuário já existe',
	'registration:usernametooshort' => 'Seu nome de usuário deve conter no mínimo 4 caracteres.',
	'registration:passwordtooshort' => 'A senha deve conter no mínimo 6 caracteres.',
	'registration:dupeemail' => 'Este email já está registrado no sistema.',
	'registration:invalidchars' => 'Seu nome de usuário contém caracteres inválidos.',
	'registration:emailnotvalid' => 'O email utilizado é inválido neste sistema.',
	'registration:passwordnotvalid' => 'A senha utilizada é inválida neste sistema.',
	'registration:usernamenotvalid' => 'O nome de usuário utilizado é inválido neste sistema.',

	'adduser' => "Adicionar usuário",
	'adduser:ok' => "Você adicionou um novo usuário com sucesso.",
	'adduser:bad' => "O novo usuário não pode ser criado.",

	'item:object:reported_content' => "Itens denunciados",

	'user:set:name' => "Nome da conta",
	'user:name:label' => "Seu apelido",
	'user:name:success' => "Seu nome foi alterado com sucesso.",
	'user:name:fail' => "Não foi possível alterar seu nome. Certifique-se que seu nome não é muito longo e tente novamente.",

	'user:set:password' => "Senha",
	'user:password:label' => "Nova senha",
	'user:password2:label' => "Nova senha (confirmação)",
	'user:password:success' => "Senha alterada",
	'user:password:fail' => "Não foi possível alterar sua senha",
	'user:password:fail:notsame' => "Os dois campos de nova senha não conferem!",
	'user:password:fail:tooshort' => "Senha muito curta!",
	'user:resetpassword:unknown_user' => 'Usuário inválido.',
	'user:resetpassword:reset_password_confirm' => 'Resetar sua senha fará com que você receba uma nova senha em seu email registrado.',

	'user:set:language' => "Configurações de idioma",
	'user:language:label' => "Seu idioma",
	'user:language:success' => "Suas configurações de idioma foram atualizadas com sucesso.",
	'user:language:fail' => "Não foi possível salvar suas configurações de idioma.",

	'user:username:notfound' => 'Nome de usuário (%s) não encontrado.',

	'user:password:lost' => 'Recuperar senha',
	'user:password:resetreq:success' => 'Solicitação de nova senha realizada com sucesso.',
	'user:password:resetreq:fail' => 'Não foi possível solicitar uma nova senha.',

	'user:password:text' => 'Para gerar uma nova senha, insira seu nome de usuário abaixo. Nós enviaremos um endereço para uma página de verificação para você por email. Clique no endereço no corpo da mensagem e uma nova senha será enviada a você.',

	'user:persistent' => 'Lembrar de mim',
/**
 * Administration
 * Administração
 * Traduzir para PT_BR
 */

	'admin:configuration:success' => "Suas configurações foram salvas com sucesso.",
	'admin:configuration:fail' => "Não foi possível salvar suas configurações.",

	'admin' => "Administração",
	'admin:description' => "O painel de administração permite a você controlar todas as características do sistema, desde gerência de usuários até como os plugins se comportam. Escolha uma opção abaixo para começar.",

	'admin:user' => "Administrar usuário",
	'admin:user:description' => "Este painel de administração permite a você controlar as configurações dos usuários para seu site. Escolha uma opção abaixo para iniciar.",
	'admin:user:adduser:label' => "Clique aqui para adicionar um novo usuário.",
	'admin:user:opt:linktext' => "Configurar usuários...",
	'admin:user:opt:description' => "Configurar usuários e informações de contas.",

	'admin:site' => "Administrar site",
	'admin:site:description' => "This admin panel allows you to control global settings for your site. Choose an option below to get started.",
	'admin:site:opt:linktext' => "Configure site...",
	'admin:site:opt:description' => "Configure the site technical and non-technical settings. ",
	'admin:site:access:warning' => "Changing the access setting only affects the permissions on content created in the future.",

	'admin:plugins' => "Administrar ferramentas",
	'admin:plugins:description' => "This admin panel allows you to control and configure tools installed on your site.",
	'admin:plugins:opt:linktext' => "Configure tools...",
	'admin:plugins:opt:description' => "Configure the tools installed on the site. ",
	'admin:plugins:label:author' => "Author",
	'admin:plugins:label:copyright' => "Copyright",
	'admin:plugins:label:licence' => "Licence",
	'admin:plugins:label:website' => "URL",
	'admin:plugins:label:moreinfo' => 'more info',
	'admin:plugins:label:version' => 'Version',
	'admin:plugins:warning:elggversionunknown' => 'Warning: This plugin does not specify a compatible Elgg version.',
	'admin:plugins:warning:elggtoolow' => 'Warning: This plugin requires a later version of Elgg!',
	'admin:plugins:reorder:yes' => "Plugin %s was reordered successfully.",
	'admin:plugins:reorder:no' => "Plugin %s could not be reordered.",
	'admin:plugins:disable:yes' => "Plugin %s was disabled successfully.",
	'admin:plugins:disable:no' => "Plugin %s could not be disabled.",
	'admin:plugins:enable:yes' => "Plugin %s was enabled successfully.",
	'admin:plugins:enable:no' => "Plugin %s could not be enabled.",

	'admin:statistics' => "Estatísticas",
	'admin:statistics:description' => "Este é um sumário de estatísticas sobre o site. Se você deseja estatísticas mais detalhadas, um recurso de gerenciamento profissional está disponível.",
	'admin:statistics:opt:description' => "Exibir informações estatísticas sobre usuários e objetos no site.",
	'admin:statistics:opt:linktext' => "Exibir estatísticas...",
	'admin:statistics:label:basic' => "Estatísticas básicas do site",
	'admin:statistics:label:numentities' => "Entidades no site",
	'admin:statistics:label:numusers' => "Número de usuários",
	'admin:statistics:label:numonline' => "Número de usuários conectados",
	'admin:statistics:label:onlineusers' => "Usuários conectados agora",
	'admin:statistics:label:version' => "Versão do Elgg",
	'admin:statistics:label:version:release' => "Release",
	'admin:statistics:label:version:version' => "Version",

	'admin:user:label:search' => "Encontrar usuários:",
	'admin:user:label:searchbutton' => "Pesquisar",

	'admin:user:ban:no' => "Não foi possível banir o usuário",
	'admin:user:ban:yes' => "Usuário banido.",
	'admin:user:unban:no' => "Não foi possível desbanir o usuário",
	'admin:user:unban:yes' => "Usuário desbanido.",
	'admin:user:delete:no' => "Não foi possível apagar o usuário",
	'admin:user:delete:yes' => "Usuário apagado",

	'admin:user:resetpassword:yes' => "Senha zerada, usuário notificado.",
	'admin:user:resetpassword:no' => "A senha não pôde ser zerada.",

	'admin:user:makeadmin:yes' => "O usuário agora é um administrador.",
	'admin:user:makeadmin:no' => "Não foi possível tornar este usuário um administrador.",

	'admin:user:removeadmin:yes' => "O usuário não é mais um administrador.",
	'admin:user:removeadmin:no' => "Não foi possível apagar os privilégios de administrador deste usuário.",

/**
 * User settings
 * Configurações de usuários
 * Traduzido para PT_BR
 */
	'usersettings:description' => "O Painel de configurações do usuário permite a você controlar suas informações pessoais, desde configurar o usuário até como os plugins se comportam. Escolha uma opção abaixo para iniciar.",

	'usersettings:statistics' => "Suas estatísticas.",
	'usersettings:statistics:opt:description' => "Ver informações estatísticas sobre usuários e objetos em seu site.",
	'usersettings:statistics:opt:linktext' => "Estatísticas de conta",

	'usersettings:user' => "Suas configurações",
	'usersettings:user:opt:description' => "Isto permite a você controlar as configurações de usuários.",
	'usersettings:user:opt:linktext' => "Altere suas configurações",

	'usersettings:plugins' => "Ferramentas",
	'usersettings:plugins:opt:description' => "Configure as características (se tiver alguma) para suas ferramentas ativas.",
	'usersettings:plugins:opt:linktext' => "Configure suas ferramentas",

	'usersettings:plugins:description' => "Este painel permite a você controlar e configurar as informações pessoais referentes às ferramentas instaladas pelo administrador do sistema.",
	'usersettings:statistics:label:numentities' => "Seu conteúdo",

	'usersettings:statistics:yourdetails' => "Seus detalhes",
	'usersettings:statistics:label:name' => "Nome completo",
	'usersettings:statistics:label:email' => "Email",
	'usersettings:statistics:label:membersince' => "Membro desde",
	'usersettings:statistics:label:lastlogin' => "último acesso",



/**
 * Generic action words
 * Palavras genéricas de ação
 * Traduzido para PT_BR
 */

	'save' => "Salvar",
	'publish' => "Publicar",
	'cancel' => "Cancelar",
	'saving' => "Salvando ...",
	'update' => "Atualizar",
	'edit' => "Editar",
	'delete' => "Apagar",
	'accept' => "Aceitar",
	'load' => "Carregar",
	'upload' => "Enviar",
	'ban' => "Banir",
	'unban' => "Desbanir",
	'enable' => "Ativar",
	'disable' => "Desativar",
	'request' => "Solicitar",
	'complete' => "Completo",
	'open' => 'Abrir',
	'close' => 'Fechar',
	'reply' => "Responder",
	'more' => 'Mais',
	'comments' => 'Comentários',
	'import' => 'Importar',
	'export' => 'Exportar',
	'untitled' => 'Sem título',
	'help' => 'Ajuda',
	'send' => 'Enviar',
	'post' => 'Enviar',
	'submit' => 'Enviar',
	'site' => 'Site',

	'up' => 'Acima',
	'down' => 'Abaixo',
	'top' => 'Em cima',
	'bottom' => 'Em baixo',

	'invite' => "Convidar",

	'resetpassword' => "Reiniciar senha",
	'makeadmin' => "Tornar administrador",
	'removeadmin' => "Apagar administrador",

	'option:yes' => "Sim",
	'option:no' => "Não",

	'unknown' => 'Desconhecido',

	'active' => 'Ativo',
	'total' => 'Total',

	'learnmore' => "Clique aqui para aprender mais.",

	'content' => "conteúdo",
	'content:latest' => 'últimas atividades',
	'content:latest:blurb' => 'Alternativamente, clique aqui para exibir os últimos conteúdos da comunidade,',

	'link:text' => 'ver link',

	'enableall' => 'Ativar todos',
	'disableall' => 'Desativar todos',

/**
 * Generic questions
 * Questões genéricas
 * Traduzido para PT_BR
 */

	'question:areyousure' => 'Você tem certeza?',

/**
 * Generic data words
 * Palavras genéricas de informações
 * Traduzido para PT_BR
 */

	'title' => "Título",
	'description' => "Descrição",
	'tags' => "Tags",
	'spotlight' => "Destaque",
	'all' => "Todos",

	'by' => 'por',

	'annotations' => "Anotações",
	'relationships' => "Relacionamentos",
	'metadata' => "Metadados",

/**
 * Input / output strings
 * Frases de entrada / saída
 * Traduzido para PT_BR
 */

	'deleteconfirm' => "Você tem certeza de que deseja apagar este item?",
	'fileexists' => "Um arquivo já foi enviado. Para substituí-lo, selecione-o abaixo:",

/**
 * User add
 * Adicionar usuário
 * Traduzido para PT_BR
 */

	'useradd:subject' => 'Conta de usuário criada',
	'useradd:body' => '
%s,

Uma conta de usuário foi criada para você em %s. Para entrar, visite:

%s

Para conectar-se, utilize as informações de usuário abaixo:

Nome de usuário: %s
Senha: %s

Assim que você se conectar, nós recomendamos fortemente que você altere sua senha.
',

/**
 * System messages
 * Mensagens do sistema
 * Traduzir para PT_BR
 **/

	'systemmessages:dismiss' => "click to dismiss",


/**
 * Import / export
 * Importar / exportar
 * Traduzido para PT_BR
 */
	'importsuccess' => "Importação de dados realizada com sucesso",
	'importfail' => "OpenDD falhou ao importar dados.",

/**
 * Time
 * Tempo
 * Traduzido para PT_BR
 */

	'friendlytime:justnow' => "agora",
	'friendlytime:minutes' => "%s minutos atrás",
	'friendlytime:minutes:singular' => "um minuto atrás",
	'friendlytime:hours' => "%s horas atrás",
	'friendlytime:hours:singular' => "uma hora atrás",
	'friendlytime:days' => "%s dias atrás",
	'friendlytime:days:singular' => "ontem",
	'friendlytime:date_format' => 'j F Y @ g:ia', /* TRADUZIR */

	'date:month:01' => '%s de Janeiro',
	'date:month:02' => '%s de Fevereiro',
	'date:month:03' => '%s de Março',
	'date:month:04' => '%s de Abril',
	'date:month:05' => '%s de Maio',
	'date:month:06' => '%s de Junho',
	'date:month:07' => '%s de Julho',
	'date:month:08' => '%s de Agosto',
	'date:month:09' => '%s de Setembro',
	'date:month:10' => '%s de Outubro',
	'date:month:11' => '%s de Novmebro',
	'date:month:12' => '%s de Dezembro',


/**
 * Installation and system settings
 */

	'installation:error:htaccess' => "Elgg requires a file called .htaccess to be set in the root directory of its installation. We tried to create it for you, but Elgg doesn't have permission to write to that directory.

Creating this is easy. Copy the contents of the textbox below into a text editor and save it as .htaccess

",
	'installation:error:settings' => "Elgg couldn't find its settings file. Most of Elgg's settings will be handled for you, but we need you to supply your database details. To do this:

1. Rename engine/settings.example.php to settings.php in your Elgg installation.

2. Open it with a text editor and enter your MySQL database details. If you don't know these, ask your system administrator or technical support for help.

Alternatively, you can enter your database settings below and we will try and do this for you...",

	'installation:error:configuration' => "Once you've corrected any configuration issues, press reload to try again.",

	'installation' => "Installation",
	'installation:success' => "Elgg's database was installed successfully.",
	'installation:configuration:success' => "Your initial configuration settings have been saved. Now register your initial user; this will be your first system administrator.",

	'installation:settings' => "System settings",
	'installation:settings:description' => "Now that the Elgg database has been successfully installed, you need to enter a couple of pieces of information to get your site fully up and running. We've tried to guess where we could, but <b>you should check these details.</b>",

	'installation:settings:dbwizard:prompt' => "Enter your database settings below and hit save:",
	'installation:settings:dbwizard:label:user' => "Database user",
	'installation:settings:dbwizard:label:pass' => "Database password",
	'installation:settings:dbwizard:label:dbname' => "Elgg database",
	'installation:settings:dbwizard:label:host' => "Database hostname (usually 'localhost')",
	'installation:settings:dbwizard:label:prefix' => "Database table prefix (usually 'elgg_')",

	'installation:settings:dbwizard:savefail' => "We were unable to save the new settings.php. Please save the following file as engine/settings.php using a text editor.",

	'installation:sitename' => "The name of your site (eg \"My social networking site\"):",
	'installation:sitedescription' => "Short description of your site (optional)",
	'installation:wwwroot' => "The site URL, followed by a trailing slash:",
	'installation:path' => "The full path to your site root on your disk, followed by a trailing slash:",
	'installation:dataroot' => "The full path to the directory where uploaded files will be stored, followed by a trailing slash:",
	'installation:dataroot:warning' => "You must create this directory manually. It should sit in a different directory to your Elgg installation.",
	'installation:sitepermissions' => "The default access permissions:",
	'installation:language' => "The default language for your site:",
	'installation:debug' => "Debug mode provides extra information which can be used to diagnose faults. However, it can slow your system down so should only be used if you are having problems:",
	'installation:debug:none' => 'Turn off debug mode (recommended)',
	'installation:debug:error' => 'Display only critical errors',
	'installation:debug:warning' => 'Display errors and warnings',
	'installation:debug:notice' => 'Log all errors, warnings and notices',
	'installation:httpslogin' => "Enable this to have user logins performed over HTTPS. You will need to have https enabled on your server for this to work.",
	'installation:httpslogin:label' => "Enable HTTPS logins",
	'installation:view' => "Enter the view which will be used as the default for your site or leave this blank for the default view (if in doubt, leave as default):",

	'installation:siteemail' => "Site email address (used when sending system emails)",

	'installation:disableapi' => "The RESTful API is a flexible and extensible interface that enables applications to use certain Elgg features remotely.",
	'installation:disableapi:label' => "Enable the RESTful API",

	'installation:allow_user_default_access:description' => "If checked, individual users will be allowed to set their own default access level that can over-ride the system default access level.",
	'installation:allow_user_default_access:label' => "Allow user default access",

	'installation:simplecache:description' => "The simple cache increases performance by caching static content including some CSS and JavaScript files. Normally you will want this on.",
	'installation:simplecache:label' => "Use simple cache (recommended)",

	'installation:viewpathcache:description' => "The view filepath cache decreases the loading times of plugins by caching the location of their views.",
	'installation:viewpathcache:label' => "Use view filepath cache (recommended)",

	'upgrading' => 'Upgrading...',
	'upgrade:db' => 'Your database was upgraded.',
	'upgrade:core' => 'Your elgg installation was upgraded.',

/**
 * Welcome
 * Boas Vindas
 * Traduzido para PT_BR
 */

	'welcome' => "Seja bem vindo",
	'welcome:user' => 'Seja bem vindo %s',
	'welcome_message' => "Seja bem vindo a esta comunidade.",

/**
 * Emails
 * Traduzido para PT_BR
 */
	'email:settings' => "Configurações de Email",
	'email:address:label' => "Seu email",

	'email:save:success' => "Novo email gravado, verificação necessária.",
	'email:save:fail' => "Seu novo email não pôde ser gravado.",

	'friend:newfriend:subject' => "%s adicionou-o como amigo!",
	'friend:newfriend:body' => "%s adicionou-o como amigo!

Para ver o perfil dela(e), clique aqui:

%s

Não responda a este email.",



	'email:resetpassword:subject' => "Gerar nova senha!",
	'email:resetpassword:body' => "Olá %s,

Sua nova senha foi gerada e ela é: %s",


	'email:resetreq:subject' => "Solicitar nova senha.",
	'email:resetreq:body' => "Olá %s,

Alguém (do endereço de IP %s) solicitou uma nova senha para esta conta.

Se você fez esta solicitação, clique no link abaixo, caso contrário por favor ignore este email.

%s
",

/**
 * user default access
 * Acesso padrão dos usuários
 * Traduzido para PT_BR
 */

'default_access:settings' => "Seu nível de acesso padrão",
'default_access:label' => "Acesso padrão",
'user:default_access:success' => "Seu novo nível de acesso principal foi gravado com sucesso.",
'user:default_access:failure' => "Seu novo nível de acesso principal não pôde ser gravado.",

/**
 * XML-RPC
 * Traduzido para PT_BR
 */
	'xmlrpc:noinputdata'	=>	"Dados de entrada faltando",

/**
 * Comments
 * Traduzido para PT_BR
 */

	'comments:count' => "%s comentários",

	'riveraction:annotation:generic_comment' => '%s comentários em %s',

	'generic_comments:add' => "Adicionar comentário",
	'generic_comments:text' => "Comentário",
	'generic_comment:posted' => "Seu comentário foi enviado com sucesso.",
	'generic_comment:deleted' => "Seu comentário foi apagado com sucesso.",
	'generic_comment:blank' => "Você deve adicionar algum conteúdo antes de salvar seu comentário.",
	'generic_comment:notfound' => "Não foi possível encontrar o item específico.",
	'generic_comment:notdeleted' => "Não foi possível apagar este comentário.",
	'generic_comment:failure' => "Um erro inesperado ocorreu na tentativa de adicionar seu comentário, por favor, tente novamente.",

	'generic_comment:email:subject' => 'Você possui um novo comentário!',
	'generic_comment:email:body' => "Você possui um novo comentário em seu item \"%s\" de %s. Ele diz:


%s


Para responder ou ver o original, clique aqui:

%s

Para ver o perfil de %s, clique aqui:

%s

Não responda a este email.",

/**
 * Entities
 * Entidades
 * Traduzido para PT_BR
 */
	'entity:default:strapline' => 'Criado %s por %s',
	'entity:default:missingsupport:popup' => 'Esta entidade não pôde ser exibida corretamente. Isto deve ter ocorrido pois requer o suporte de um plugin que não está mais instalado.',

	'entity:delete:success' => 'Entidade %s foi apagada',
	'entity:delete:fail' => 'Entidade %s não pode ser apagada',


/**
 * Action gatekeeper
 */
	'actiongatekeeper:missingfields' => 'Form is missing __token or __ts fields',
	'actiongatekeeper:tokeninvalid' => "We encountered an error (token mismatch). This probably means that the page you were using expired. Please try again.",
	'actiongatekeeper:timeerror' => 'The page you were using has expired. Please refresh and try again.',
	'actiongatekeeper:pluginprevents' => 'A extension has prevented this form from being submitted.',

/**
 * Word blacklists
 * Lista proibida de palavras
 * Traduzido para PT_BR
 */
	'word:blacklist' => 'and, the, then, but, she, his, her, him, one, not, also, about, now, hence, however, still, likewise, otherwise, therefore, conversely, rather, consequently, furthermore, nevertheless, instead, meanwhile, accordingly, this, seems, what, whom, whose, whoever, whomever',

/**
 * Tag labels
 */

	'tag_names:tags' => 'Tags',

/**
 * Languages according to ISO 639-1
 */
	"aa" => "Afar",
	"ab" => "Abkhazian",
	"af" => "Afrikaans",
	"am" => "Amharic",
	"ar" => "Arabic",
	"as" => "Assamese",
	"ay" => "Aymara",
	"az" => "Azerbaijani",
	"ba" => "Bashkir",
	"be" => "Byelorussian",
	"bg" => "Bulgarian",
	"bh" => "Bihari",
	"bi" => "Bislama",
	"bn" => "Bengali; Bangla",
	"bo" => "Tibetan",
	"br" => "Breton",
	"ca" => "Catalan",
	"co" => "Corsican",
	"cs" => "Czech",
	"cy" => "Welsh",
	"da" => "Danish",
	"de" => "German",
	"dz" => "Bhutani",
	"el" => "Greek",
	"en" => "English",
	"eo" => "Esperanto",
	"es" => "Spanish",
	"et" => "Estonian",
	"eu" => "Basque",
	"fa" => "Persian",
	"fi" => "Finnish",
	"fj" => "Fiji",
	"fo" => "Faeroese",
	"fr" => "French",
	"fy" => "Frisian",
	"ga" => "Irish",
	"gd" => "Scots / Gaelic",
	"gl" => "Galician",
	"gn" => "Guarani",
	"gu" => "Gujarati",
	"he" => "Hebrew",
	"ha" => "Hausa",
	"hi" => "Hindi",
	"hr" => "Croatian",
	"hu" => "Hungarian",
	"hy" => "Armenian",
	"ia" => "Interlingua",
	"id" => "Indonesian",
	"ie" => "Interlingue",
	"ik" => "Inupiak",
	//"in" => "Indonesian",
	"is" => "Icelandic",
	"it" => "Italian",
	"iu" => "Inuktitut",
	"iw" => "Hebrew (obsolete)",
	"ja" => "Japanese",
	"ji" => "Yiddish (obsolete)",
	"jw" => "Javanese",
	"ka" => "Georgian",
	"kk" => "Kazakh",
	"kl" => "Greenlandic",
	"km" => "Cambodian",
	"kn" => "Kannada",
	"ko" => "Korean",
	"ks" => "Kashmiri",
	"ku" => "Kurdish",
	"ky" => "Kirghiz",
	"la" => "Latin",
	"ln" => "Lingala",
	"lo" => "Laothian",
	"lt" => "Lithuanian",
	"lv" => "Latvian/Lettish",
	"mg" => "Malagasy",
	"mi" => "Maori",
	"mk" => "Macedonian",
	"ml" => "Malayalam",
	"mn" => "Mongolian",
	"mo" => "Moldavian",
	"mr" => "Marathi",
	"ms" => "Malay",
	"mt" => "Maltese",
	"my" => "Burmese",
	"na" => "Nauru",
	"ne" => "Nepali",
	"nl" => "Dutch",
	"no" => "Norwegian",
	"oc" => "Occitan",
	"om" => "(Afan) Oromo",
	"or" => "Oriya",
	"pa" => "Punjabi",
	"pl" => "Polish",
	"ps" => "Pashto / Pushto",
	"pt" => "Português",
	"pt_br" => "Português - Brasil",
	"qu" => "Quechua",
	"rm" => "Rhaeto-Romance",
	"rn" => "Kirundi",
	"ro" => "Romanian",
	"ru" => "Russian",
	"rw" => "Kinyarwanda",
	"sa" => "Sanskrit",
	"sd" => "Sindhi",
	"sg" => "Sangro",
	"sh" => "Serbo-Croatian",
	"si" => "Singhalese",
	"sk" => "Slovak",
	"sl" => "Slovenian",
	"sm" => "Samoan",
	"sn" => "Shona",
	"so" => "Somali",
	"sq" => "Albanian",
	"sr" => "Serbian",
	"ss" => "Siswati",
	"st" => "Sesotho",
	"su" => "Sundanese",
	"sv" => "Swedish",
	"sw" => "Swahili",
	"ta" => "Tamil",
	"te" => "Tegulu",
	"tg" => "Tajik",
	"th" => "Thai",
	"ti" => "Tigrinya",
	"tk" => "Turkmen",
	"tl" => "Tagalog",
	"tn" => "Setswana",
	"to" => "Tonga",
	"tr" => "Turkish",
	"ts" => "Tsonga",
	"tt" => "Tatar",
	"tw" => "Twi",
	"ug" => "Uigur",
	"uk" => "Ukrainian",
	"ur" => "Urdu",
	"uz" => "Uzbek",
	"vi" => "Vietnamese",
	"vo" => "Volapuk",
	"wo" => "Wolof",
	"xh" => "Xhosa",
	//"y" => "Yiddish",
	"yi" => "Yiddish",
	"yo" => "Yoruba",
	"za" => "Zuang",
	"zh" => "Chinese",
	"zu" => "Zulu",
);

add_translation("en",$english);
add_translation("pt_br",$portugues_brasileiro);
