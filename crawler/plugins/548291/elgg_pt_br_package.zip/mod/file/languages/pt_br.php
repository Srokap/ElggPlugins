<?php
	/**
	 * Elgg file plugin language pack
	 *
	 * @package ElggFile
	 * @author DiRaOL - diraol@diraol.eng.br
	 * @link http://blog.diraol.eng.br
	 * @published 14 March 2010
	 */

	$portugues_brasileiro = array(

		/**
		 * Menu items and titles
		 */

			'file' => "Arquivo",
			'files' => "Arquivos",
			'file:yours' => "Seus arquivos",
			'file:yours:friends' => "Arquivos de seus amigos",
			'file:user' => "Arquivos de %s",
			'file:friends' => "Arquivos dos amigos de %s",
			'file:all' => "Todos os arquivos da comunidade",
			'file:edit' => "Editar arquivo",
			'file:more' => "Mais arquivos",
			'file:list' => "Visualizar em lista",
			'file:group' => "Arquivos do grupo",
			'file:gallery' => "Visualizar em galeria",
			'file:gallery_list' => "Visualizar em lista ou galeria",
			'file:num_files' => "Número de arquivos a serem exibidos",
			'file:user:gallery'=>'Ver a galeria de %s',
	        'file:via' => 'pelos arquivos',
			'file:upload' => "Enviar arquivo",
			'file:replace' => 'Substituir conteúdo do arquivo (deixe em branco para não alterá-lo)',

			'file:newupload' => 'Novo arquivo adicionado',

			'file:file' => "Arquivo",
			'file:title' => "Título",
			'file:desc' => "Descrição",
			'file:tags' => "Tags",

			'file:types' => "Tipos de arquivos enviados",

			'file:type:all' => "Todos os arquivos",
			'file:type:video' => "Vídeos",
			'file:type:document' => "Documentos",
			'file:type:audio' => "Sons",
			'file:type:image' => "Imagens",
			'file:type:general' => "Geral",

			'file:user:type:video' => "Vídeos de %s",
			'file:user:type:document' => "Documentos de %s",
			'file:user:type:audio' => "Sons de %s",
			'file:user:type:image' => "Imagens de %s",
			'file:user:type:general' => "Arquivos gerais de %s",

			'file:friends:type:video' => "Vídeos de seus amigos",
			'file:friends:type:document' => "Documentos de seus amigos",
			'file:friends:type:audio' => "Sons de seus amigos",
			'file:friends:type:image' => "Imagens de seus amigos",
			'file:friends:type:general' => "Arquivos gerais de seus amigos",

			'file:widget' => "Dispositivo de Arquivos",
			'file:widget:description' => "Apresentar seus últimos arquivos",

			'file:download' => "Baixar este",

			'file:delete:confirm' => "Você tem certeza de que deseja apagar este arquivo?",

			'file:tagcloud' => "Núvem de Tags",

			'file:display:number' => "Número de arquivos a serem exibidos",

			'file:river:created' => "%s arquivos enviados",
			'file:river:item' => "um arquivo",
			'file:river:annotate' => "um comentário neste arquivo",

			'item:object:file' => 'Arquivos',

	    /**
		 * Embed media
		 **/

		    'file:embed' => "Mídia incorporada",
		    'file:embedall' => "Todas",

		/**
		 * Status messages
		 */

			'file:saved' => "Seu arquivo foi salvo com sucesso.",
			'file:deleted' => "Seu arquivo foi apagado com sucesso.",

		/**
		 * Error messages
		 */

			'file:none' => "Nenhum arquivo enviado.",
			'file:uploadfailed' => "Não foi possível salvar seu arquivo.",
			'file:downloadfailed' => "Este arquivo não está disponível no momento.",
			'file:deletefailed' => "Seu arquivo não pôde ser apagado.",
			'file:noaccess' => "Você não possui permissão para editar este arquivo",
			'file:cannotload' => "Houve um erro ao carregar o arquivo",
			'file:nofile' => "Você deve selecionar um arquivo",
	);

	add_translation("en",$english);
	add_translation("pt_br",$portugues_brasileiro);
?>
