<?php

  $english = array(
    'tagcloud' => 'Tag Cloud',
	'tagcloud:widget:title' => 'Nuvem de Tags',
    'tagcloud:widget:description' => 'Exibe as tags atribuídas ao seu conteúdo',
    'tagcloud:widget:numtags' => 'Número de tags a serem exibidas',
	'tagcloud:color_instruct' => 'Cores'
	);

  add_translation('en', $english);
  add_translation("pt_br",$portugues_brasileiro);

?>