<?php

  $english = array(
    'tagcloud' => 'Tag Cloud',
	'tagcloud:widget:title' => 'Tag Cloud',
    'tagcloud:widget:description' => 'Displays the tags on your content',
    'tagcloud:widget:numtags' => 'Number of tags to show',
	'tagcloud:color_instruct' => 'Colors'
	);

  add_translation('en', $english);

?>