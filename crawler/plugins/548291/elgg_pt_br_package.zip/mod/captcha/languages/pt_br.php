<?php
	/**
	 * Elgg diagnostics language pack.
	 *
	 * @package ElggDiagnostics
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author DiRaOL - diraol@diraol.eng.br
	 * @link http://blog.diraol.eng.br
	 * @published 14 March 2010
	 */

	$portugues_brasileiro = array(

		'captcha:entercaptcha' => 'Inserir texto da imagem',
		'captcha:captchafail' => 'O texto inserido por você não combina com o texto da imagem.',

	);

	add_translation("en",$english);
	add_translation("pt_br",$portugues_brasileiro);
?>
