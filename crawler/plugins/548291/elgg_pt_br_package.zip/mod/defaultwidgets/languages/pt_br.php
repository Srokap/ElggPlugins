<?php
	/**
	 * Elgg Embed defaultwidgets language pack
	 *
	 * @package ElggDefaultWidgets
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author DiRaOL - diraol@diraol.eng.br
	 * @link http://blog.diraol.eng.br
	 * @published 14 March 2010
	 */

	$portugues_brasileiro = array(

	/**
	 * Nice name for the entity (shown in admin panel)
	 */
	'item:object:moddefaultwidgets' => 'Configurações dos dispositivos padrão',

	/**
	 * Menu items
	 */
	'defaultwidgets:menu:profile' => 'Dispositivos padrão de perfil',
    	'defaultwidgets:menu:dashboard' => 'Dispositivos padrão de painel',

    	'defaultwidgets:admin:error' => 'Erro: Você não está conectado como administrador',
	'defaultwidgets:admin:notfound' => 'Erro: Página não encontrada',
	'defaultwidgets:admin:loginfailure' => 'Aviso: Você não está conectado como administrador',

	'defaultwidgets:update:success' => 'As configurações de seu dispositivo foram salvas',
	'defaultwidgets:update:failed' => 'Erro: as configurações não foram salvas',
	'defaultwidgets:update:noparams' => 'Erro: parâmetros de formulário incorretos',

	'defaultwidgets:profile:title' => 'Definir dispositivos padrão para a página de perfil de novos usuários',
	'defaultwidgets:dashboard:title' => 'Definir dispositivos padrão para o painel de novos usuários',
);

	add_translation ( "en", $english );
	add_translation("pt_br",$portugues_brasileiro);
?>
