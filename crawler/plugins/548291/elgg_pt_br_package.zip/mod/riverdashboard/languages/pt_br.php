<?php

	/**
	 * Elgg riverdashboard plugin language pack
	 *
	 * @package ElggRiverDashboard
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author DiRaOL - diraol@diraol.eng.br
	 * @link http://blog.diraol.eng.br
	 * @published 14 March 2010
	 */

	$portugues_brasileiro = array(

		'mine' => 'Meu',
		'filter' => 'Filtro',
		'riverdashboard:useasdashboard' => "Substituir o painel padrão com este painel?",
		'activity' => 'Atividade',
		'riverdashboard:recentmembers' => 'Membros recentes',

	    /**
	     * Site messages
           **/

		'sitemessages:announcements' => "Anúncios da comunidade",
		'sitemessages:posted' => "Enviado",
		'sitemessages:river:created' => "Administrador da comunidade, %s,",
		'sitemessages:river:create' => "enviar uma nova mensagem por todo o site",
		'sitemessages:add' => "Adicionar uma mensagem site-wide para a página river",
		'sitemessage:deleted' => "Mensagem da comunidade apagada",
		'sitemessage:error' => "Falha ao salvar a mensagem da comunidade.",

		'river:widget:noactivity' => 'Não foi encontrada nenhum atividade.',
		'river:widget:title' => "Atividade",
		'river:widget:description' => "Exibir a última atividade.",
		'river:widget:title:friends' => "Atividades dos amigos",
		'river:widget:description:friends' => "Exibir o que seus amigos estão fazendo.",
		'river:widgets:friends' => "Amigos",
		'river:widgets:mine' => "Meu",
		'river:widget:label:displaynum' => "Número de entradas a exibir:",
		'river:widget:type' => "Qual river você deseja exibir? Um que exibe suas atividades ou um que exibe as atividades de seus amigos?",
		'item:object:sitemessage' => "Mensagem do site",
		'riverdashboard:avataricon' => "Você deseja utilizar os avatares dos usuários ou ícones nas áreas de atividades deles?",
		'option:icon' => 'Ícones',
		'option:avatar' => 'Avatares',
	);

	add_translation("en",$english);
	add_translation("pt_br",$portugues_brasileiro);
?>
