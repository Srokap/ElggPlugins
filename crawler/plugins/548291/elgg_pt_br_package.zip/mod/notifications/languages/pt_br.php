<?php

	/**
	 * Elgg Notifications plugin language pack
	 *
	 * @package ElggTinyMCE
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author DiRaOL - diraol@diraol.eng.br
	 * @link http://blog.diraol.eng.br
	 * @published 14 March 2010
	 */

	$portugues_brasileiro = array(

		'friends:all' => 'Todos os amigos',

		'notifications:subscriptions:personal:description' => 'Receber notificações quando mudanças forem realizadas em seus conteúdos.',
		'notifications:subscriptions:personal:title' => 'Notificações pessoais',

		'notifications:subscriptions:collections:title' => 'Alternar coleções de amigos',
		'notifications:subscriptions:collections:description' => 'Para alternar as configurações dos membros de suas coleções de amigos, utilize os ícones abaixo. Isso afetará os usuários correspondentes no painel principal de configurações de notificação na parte inferior da página.',
		'notifications:subscriptions:collections:edit' => 'Para editar suas coleções de amigos, clique aqui.',

		'notifications:subscriptions:changesettings' => 'Notificações',
		'notifications:subscriptions:changesettings:groups' => 'Notificações de grupo',
		'notification:method:email' => 'Email',

		'notifications:subscriptions:title' => 'Notificação por usuário',
		'notifications:subscriptions:description' => 'Para receber notificações de seus amigos quando eles criarem novos conteúdos, encontre-os abaixo e selecione o método de notificação que você deseja utilizar.',

		'notifications:subscriptions:groups:description' => 'Para receber notificações quando novos conteúdos forem adicionados a um grupo do qual você seja membro, encontre-o abaixo e selecione o método de notificação que você deseja utilizar.',

		'notifications:subscriptions:success' => 'Suas configurações de notificação foram salvas com sucesso.',

	);

	add_translation("en",$english);
	add_translation("pt_br",$portugues_brasileiro);

?>
