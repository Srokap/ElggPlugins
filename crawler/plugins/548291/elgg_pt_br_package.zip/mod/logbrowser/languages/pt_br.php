<?php
	/**
	 * Elgg log browser plugin language pack
	 *
	 * @package ElggLogBrowser
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author DiRaOL - diraol@diraol.eng.br
	 * @link http://blog.diraol.eng.br
	 * @published 14 March 2010
	 */

	$portugues_brasileiro = array(

		/**
		 * Menu items and titles
		 */

			'logbrowser' => 'navegador de logs',
			'logbrowser:browse' => 'navegar nos logs do sistema',
			'logbrowser:search' => 'refinar resultados',
			'logbrowser:user' => 'pesquisar pelo nome de usuário',
			'logbrowser:starttime' => 'Momento de início da busca (por exemplo "último segunda", "1 hora atrás")',
			'logbrowser:endtime' => 'Momento de fim da busca',

			'logbrowser:explore' => 'Explorar log',

	);

	add_translation("en",$english);
	add_translation("pt_br",$portugues_brasileiro);
?>
