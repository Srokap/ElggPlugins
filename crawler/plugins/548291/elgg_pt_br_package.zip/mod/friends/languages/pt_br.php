<?php

	/**
	 * Elgg Friends plugin language pack
	 *
	 * @package ElggFriends
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author DiRaOL - diraol@diraol.eng.br
	 * @link http://blog.diraol.eng.br
	 * @published 14 March 2010
	 */

	$portugues_brasileiro = array(

		/**
		 * Friends widget
		 */
			'friends:widget:description' => "Exibe alguns de seus amigos.",


	);

	add_translation("en",$english);
	add_translation("pt_br",$portugues_brasileiro);

?>
