<?php
	/**
	 * Elgg pages plugin language pack
	 *
	 * @package ElggPages
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2010
	 * @link http://elgg.com/
	 */

	$portugues_brasileiro = array(

		/**
		 * Menu items and titles
		 */

			'pages' => "Wiki",
			'pages:yours' => "Suas páginas wiki",
			'pages:user' => "Início da página wiki",
			'pages:group' => "Páginas wiki do grupo",
			'pages:all' => "Todas páginas wiki do site",
			'pages:new' => "Nova página wiki",
			'pages:groupprofile' => "Páginas wiki do grupo",
			'pages:edit' => "Modifique esta página wiki",
			'pages:delete' => "Apague esta página wiki",
			'pages:history' => "Histórico desta página wiki",
			'pages:view' => "Ver página wiki",
			'pages:welcome' => "Editar mensagem de boas vindas",
			'pages:welcomemessage' => "Bem-vindo à wiki de %s. Esta ferramenta permite que você crie páginas em formato wiki sobre qualquer assunto, e que selecione quem poderá visualizá-las e editá-las.",
			'pages:welcomeerror' => "Houve um problema ao salvar sua mensagem de boas vindas",
			'pages:welcomeposted' => "Sua mensagem de boas vindas foi enviada com sucesso",
			'pages:navigation' => "Navegação pela página wiki",
	        'pages:via' => "via wikies",
			'item:object:page_top' => 'Páginas wiki top-level',
			'item:object:page' => 'Wiki',
			'item:object:pages_welcome' => 'Pages welcome blocks',
			'pages:nogroup' => 'Este grupo ainda não possui páginas wiki',
			'pages:more' => 'Mais páginas wiki',

		/**
		* River
		**/

		    'pages:river:annotate' => "um comentário nesta página wiki",
		    'pages:river:created' => "%s escreveu",
	        'pages:river:updated' => "%s atualizou",
	        'pages:river:posted' => "%s publicou",
			'pages:river:create' => "uma nova página wiki entitulada",
	        'pages:river:update' => "uma página wiki entitulada",
	        'page:river:annotate' => "um comentário nesta página wiki",
	        'page_top:river:annotate' => "um comentário nesta página wiki",

		/**
		 * Form fields
		 */

			'pages:title' => 'Título da página wiki',
			'pages:description' => 'Sua descrição sobre a página wiki',
			'pages:tags' => 'Tags',
			'pages:access_id' => 'Permissão de leitura',
			'pages:write_access_id' => 'Permissão de escrita',

		/**
		 * Status and error messages
		 */
			'pages:noaccess' => 'Nenhum acesso à página wiki.',
			'pages:cantedit' => 'Você não pode editar esta página.',
			'pages:saved' => 'Página wiki salva com sucesso.',
			'pages:notsaved' => 'Página wiki não pôde ser salva corretamente.',
			'pages:notitle' => 'Você deve especificar um título para sua página wiki.',
			'pages:delete:success' => 'Sua página wiki foi apagada com sucesso.',
			'pages:delete:failure' => 'Página wiki não pôde ser apagada corretamente.',

		/**
		 * Page
		 */
			'pages:strapline' => 'Última atualização em %s por %s',

		/**
		 * History
		 */
			'pages:revision' => 'Revisão criada em %s por %s',

		/**
		 * Widget
		 **/

		    'pages:num' => 'Número de páginas wiki para exibir',
			'pages:widget:description' => "Esta é uma lista de suas páginas wiki.",

		/**
		 * Submenu items
		 */
			'pages:label:view' => "Visualizar página wiki",
			'pages:label:edit' => "Editar página wiki",
			'pages:label:history' => "Histórico da página wiki",

		/**
		 * Sidebar items
		 */
			'pages:sidebar:this' => "Esta página wiki",
			'pages:sidebar:children' => "Sub-páginas",
			'pages:sidebar:parent' => "Página pai",

			'pages:newchild' => "Criar uma sub-página",
			'pages:backtoparent' => "Voltar para '%s'",
	);

	add_translation("en",$english);
	add_translation("pt_br",$portugues_brasileiro);
?>