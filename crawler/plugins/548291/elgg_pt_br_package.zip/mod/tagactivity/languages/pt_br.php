<?php

        $english = array(
                 /**
                  * widget
                  */
			 'tagactivity:widget:description' => "Tag activity",
			 'tagactivity:tag' => "Tag : ",
			 'tagactivity:more' => "Mais tags lançadas",
			 );

	add_translation("en",$english);
	add_translation("pt_br",$portugues_brasileiro);

?>