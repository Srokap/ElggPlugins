<?php

	/**
	 * Elgg Messages plugin language pack
	 *
	 * @package ElggMessages
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author DiRaOL - diraol@diraol.eng.br
	 * @link http://blog.diraol.eng.br
	 * @published 14 March 2010
	 */

	$portugues_brasileiro = array(

		/**
		 * Menu items and titles
		 */

			'messages' => "Mensagens",
            'messages:back' => "voltar às mensagens",
			'messages:user' => "Caixa de Entrada",
			'messages:sentMessages' => "Mensagens enviadas",
			'messages:posttitle' => "Mensagens de %s: %s",
			'messages:inbox' => "Caixa de entrada",
			'messages:send' => "Enviar uma mensagem",
			'messages:sent' => "Mensagens enviadas",
			'messages:message' => "Mensagem",
			'messages:title' => "Assunto",
			'messages:to' => "Para",
            'messages:from' => "De",
			'messages:fly' => "Enviar",
			'messages:replying' => "Resposta de mensagem para",
			'messages:inbox' => "Caixa de entrada",
			'messages:sendmessage' => "Enviar uma mensagem",
			'messages:compose' => "Escrever uma mensagem",
			'messages:sentmessages' => "Mensagens enviadas",
			'messages:recent' => "Mensagens recentes",
            'messages:original' => "Mensagem original",
            'messages:yours' => "Sua mensagem",
            'messages:answer' => "Responder",
			'messages:toggle' => 'alternar todos',
			'messages:markread' => 'Marcar como lida',

			'messages:new' => 'Nova mensagem',

			'notification:method:site' => 'Site',

			'messages:error' => 'Ocorreu um erro ao salvar sua mensagem.',

			'item:object:messages' => 'Mensagens',

		/**
		 * Status messages
		 */

			'messages:posted' => "Sua mensagem foi enviada com sucesso.",
			'messages:deleted' => "Sua mensagem foi apagada com sucesso.",
			'messages:markedread' => "Suas mensagems foram marcadas como lidas.",

		/**
		 * Email messages
		 */

			'messages:email:subject' => 'Você possui uma nova mensagem!',
			'messages:email:body' => "Você possui uma nova mensagem de %s. Ela diz:


%s


Para ver sua mensagem, clique aqui:

	%s

Para enviar uma mensagem para %s, clique aqui:

	%s

Não responda este email.",

		/**
		 * Error messages
		 */

			'messages:blank' => "Você deve adicionar algum texto ao corpo da mensagem antes de salvá-la.",
			'messages:notfound' => "Não foi possível encontrar a mensagem especificada.",
			'messages:notdeleted' => "Não foi possível apagar a mensagem.",
			'messages:nopermission' => "Você não possui permissão para alterar esta mensagem.",
			'messages:nomessages' => "Não há mensagens a serem exibidas.",
			'messages:user:nonexist' => "Não foi possível encontrar o destinatário em nossa base de dados.",
			'messages:user:blank' => "Você não selecionou um destinatário para enviar esta mensagem.",

	);

	add_translation("en",$english);
	add_translation("pt_br",$portugues_brasileiro);

?>
