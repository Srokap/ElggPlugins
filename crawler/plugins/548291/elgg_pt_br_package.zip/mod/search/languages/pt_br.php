<?php
	/**
	 * Elgg Search plugin language pack
	 *
	 * @package ElggSearch
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author DiRaOL - diraol@diraol.eng.br
	 * @link http://blog.diraol.eng.br
	 * @published 14 March 2010
	 */

$portugues_brasileiro = array(
	'search:enter_term' => 'Insira um termo de pesquisa:',
	'search:no_results' => 'Nenhum resultado.',
	'search:matched' => 'Combinados: ',
	'search:results' => 'Resultados para %s',
	'search:no_query' => 'Por favor, insira uma expressão a ser pesquisada.',
	'search:search_error' => 'Erro',

	'search:more' => '+%s mais %s',

	'search_types:tags' => 'Tags',

	'search_types:comments' => 'Comentários',
	'search:comment_on' => 'Comentários sobre "%s"',
	'search:unavailable_entity' => 'Entidade não disponível',
);

add_translation('en', $english);
add_translation("pt_br",$portugues_brasileiro);
?>
