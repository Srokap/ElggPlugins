<?php

	/**
	 * Elgg Categories plugin language pack
	 *
	 * @package ElggCategories
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author DiRaOL - diraol@diraol.eng.br
	 * @link http://blog.diraol.eng.br
	 * @published 14 March 2010
	 */

	$portugues_brasileiro = array(

		'categories' => 'Categorias',
		'categories:settings' => 'Definir as categorias da comunidade',
		'categories:explanation' => 'Insira abaixo, separadas por vírgulas, as categorias gerais de sua comunidade. Ferramentas compatíveis exibirão as categorias quando o usuário criar ou editar conteúdos.',
		'categories:save:success' => 'Categorias salvas com sucesso.',

	);

	add_translation("en",$english);
	add_translation("pt_br",$portugues_brasileiro);
?>
