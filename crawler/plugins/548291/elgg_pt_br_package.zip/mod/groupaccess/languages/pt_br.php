<?php
/*******************************************************************************
 * groupaccess
 *
 * @author Leo de Carvalho
 ******************************************************************************/

$portugues_brasileiro = array(
                'groupaccess:admin:groupname' => 'Nome do grupo',
                'groupaccess:admin:groupdescription' => 'Descrição do grupo',
                'groupaccess:admin:groupownerusername' => 'Nome de usuário do proprietário do grupo',
                'groupaccess:admin:groupownername' => 'Nome do proprietário do grupo',
                'groupaccess:admin:groupdate' => 'Grupo criado em',
		'groupaccess:admin:links' => 'Ativado',
		'groupaccess:admin:menu' => 'Menú de acesso ao grupo',
                'groupaccess:waitmoderate' => 'Este grupo está aguardando aprovação por um administrador. Por enquanto ele está disponível apenas para você.',
		'groupaccess:admin:group_created:success' => 'Grupo criado com sucesso! Aguarde a ativação por um administrador.',
		'groupaccess:admin:group_created:error' => 'O grupo não pôde ser criado',
                'groupaccess:admin:group_delete:error' => 'O grupo não pôde ser apagado',
                'groupaccess:admin:group_activated' => 'Grupo ativado com sucesso',
                'groupaccess:admin:group_deleted' => 'Grupo apagado com sucesso',
                'groupaccess:list:group_templates' => 'Templates de Email',
		'groupaccess:list:group_created' => 'Grupo aguardando para ser ativado',
		'groupaccess:list:group_activated' => 'Grupos ativados',
                'groupaccess:email:default' => 'Reverter para configurações padrão',
                'groupaccess:email:valid:macros' => 'Possíveis macros de email',
                'groupaccess:email:delete:success' => 'Email apagado com sucesso!',
                'groupaccess:email:delete:fail' => 'O email não pôde ser apagado!',
                'groupaccess:email:update:success' => 'Email atualizado com sucesso!',
                'groupaccess:email:update:fail' => 'O email não pôde ser atualizado!',
                'groupaccess:email:label:subject' => 'Assunto:',
                'groupaccess:email:label:content' => 'Conteúdo:',
                'groupaccess:email:label:notify_admin' => 'Email de notificação ao administrador',
                'groupaccess:email:label:notify_create' => 'Email de notificação ao usuário sobre grupo criado',
                'groupaccess:email:label:notify_activate' => 'Email de notificação ao usuário sobre grupo ativado',
                'groupaccess:email:label:notify_delete' => 'Email de notificação ao usuário sobre grupo apagado',
                'groupaccess:notify_delete:subject' => '[%site_name%] Seu grupo %groupname% foi apagado.',
                'groupaccess:notify_delete:content' => 'Olá %name%,

Seu grupo %groupname% foi apagado por um administrador por ter sido considerado inapropriado.',
		'groupaccess:email:notify_admin:subject' => '[%site_name%] Grupos aguardando para serem ativados %username%!',
                'groupaccess:email:notify_admin:content' => 'Olá %name%,

Há grupos aguardando sua aprovação para serem ativados.

%admin_url%',
		'groupaccess:email:notify_create:subject' => "[%site_name%] %username% ,por favor, aguarde a ativação do grupo %groupname%!",
                'groupaccess:email:notify_create:content' => "Olá %name%,

Por favor, aguarde a ativação do grupo %groupname%.
Esta comunidade necessita que o administrador autorize seu grupo!

",
                'groupaccess:email:notify_activate:subject' => "[%site_name%] Seu grupo %groupname% foi ativada %username%!",
                'groupaccess:email:notify_activate:content' => "Olá %name%,

Parabéns, seu grupo %groupname% foi ativado com sucesso.

%site_url%",
		'groupaccess:authorize' => 'Esta comunidade necessita que o administrador autorize seu grupo!',

		'groupaccess:notify' => 'Digitar o nome de usuário a ser notificado sobre novos grupos na lista de ativação?',
		'groupaccess:hourly' => 'de hora em hora',
		'groupaccess:daily' => 'diariamente',
		'groupaccess:weekly' => 'semanalmente',
		'groupaccess:monthly' => 'mensalmente',
                'groupaccess:river:groupcreate' => '%s criou o grupo %s',
		'groupaccess:useriver' => 'Enviar eventos sobre criação de grupos para o River Dashboard?',
		'groupaccess:notify:options' => 'Opções de Notificação',
                'groupaccess:group_created:found' => 'Grupos criados encontrados',
                'groupaccess:group_activated:found' => 'Grupos ativados encontrados',
		'groupaccess:reg:options' => 'Opções de Criação de Grupos',

);

add_translation("en",$english);
add_translation("pt_br",$portugues_brasileiro);
?>