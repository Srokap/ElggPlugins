<?php
	/**
	 * Elgg garbage collector language pack.
	 *
	 * @package ElggGarbageCollector
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author DiRaOL - diraol@diraol.eng.br
	 * @link http://blog.diraol.eng.br
	 * @published 14 March 2010
	 */

	$portugues_brasileiro = array(

		/**
		 * Menu items and titles
		 */

			'garbagecollector:period' => 'Com que frequência o coletor de lixo do Elgg deve ser executado?',

			'garbagecollector:weekly' => 'Semanalmente',
			'garbagecollector:monthly' => 'Mensalmente',
			'garbagecollector:yearly' => 'Anualmente',

			'garbagecollector' => "COLETOR DE LIXO\n",
			'garbagecollector:done' => "FEITO\n",
			'garbagecollector:optimize' => "Otimizando %s ",

			'garbagecollector:error' => "ERRO",
			'garbagecollector:ok' => "OK",

			'garbagecollector:gc:metastrings' => 'Limpando metastrings desconexas: ',

	);

	add_translation("en",$english);
	add_translation("pt_br",$portugues_brasileiro);
?>
