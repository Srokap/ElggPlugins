<?php
	/**
	* Flyers
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	$english = array(
		
	//Submenu
		'flyer' => 'Flyer',
	
	//Button
		'flyer:disable' => "Hide the flyer",
		'flyer:enable' => "Show the flyer",
		'flyer:showsiteannounces' => "Show the 'site announcement' in the message instead of the message above.",
	
	//Status
		'flyer:enabled' => "Show flyer",
		'flyer:disabled' => "Hide the flyer",
		'flyer:contentsaved' => 'The content has been saved.',
		'flyer:contenterror' => 'There were an error saving the content, please try again.',
		
	//Other Stuff
		'flyer:description' => 'Do you want to show/hide the flyer?',
		'flyer:putacontent' => 'Please add the message to be shown into the flyer.',
	);
					
	add_translation("en",$english);
?>