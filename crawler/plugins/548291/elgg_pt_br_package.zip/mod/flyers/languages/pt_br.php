<?php
	/**
	* Flyers
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	$portugues_brasileiro = array(

	//Submenu
		'flyer' => 'Alerta',

	//Button
		'flyer:disable' => "Ocultar o alerta",
		'flyer:enable' => "Exibir o alerta",
		'flyer:showsiteannounces' => "Exibir o 'anúncio do site' na mensagem ao invés da mensagem acima.",

	//Status
		'flyer:enabled' => "Alerta será exibido",
		'flyer:disabled' => "Alerta será ocultado",
		'flyer:contentsaved' => 'O conteúdo foi salvo.',
		'flyer:contenterror' => 'Houve um erro ao salvar o conteúdo. Por favor, tente novamente.',

	//Other Stuff
		'flyer:description' => 'Você deseja exibir/ocultar o alerta?',
		'flyer:putacontent' => 'Por favor adicione a mensagem a ser exibida no alerta.',
	);

	add_translation("en",$english);
    add_translation("pt_br",$portugues_brasileiro);
?>