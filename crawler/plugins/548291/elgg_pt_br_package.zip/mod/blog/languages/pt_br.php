<?php
	/**
	 * Elgg Blog plugin language pack
	 *
	 * @package ElggBlog
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author DiRaOL - diraol@diraol.eng.br
	 * @link http://blog.diraol.eng.br
	 * @published 14 March 2010
	 */

	$portugues_brasileiro = array(

		/**
		 * Menu items and titles
		 */

			'blog' => "Blog",
			'blogs' => "Blogs",
			'blog:user' => "Blog de %s",
			'blog:user:friends' => "Blog dos amigos de %s",
			'blog:your' => "Seu blog",
			'blog:posttitle' => "Blog de %s: %s",
			'blog:friends' => "Blogs dos amigos",
			'blog:yourfriends' => "Últimas mensagens de seus amigos",
			'blog:everyone' => "Todos os blogs do site",
			'blog:newpost' => "Nova mensagem no blog",
			'blog:via' => "pelo blog",
			'blog:read' => "Ler blog",

			'blog:addpost' => "Escrever uma mensagem no blog",
			'blog:editpost' => "Editar uma mensagem do blog",

			'blog:text' => "Texto do Blog",

			'blog:strapline' => "%s",

			'item:object:blog' => 'Mensagens no blog',

			'blog:never' => 'nunca',
			'blog:preview' => 'Visualizar',

			'blog:draft:save' => 'Salvar rascunho',
			'blog:draft:saved' => 'Última versão salva do rascunho',
			'blog:comments:allow' => 'Permitir comentários',

			'blog:preview:description' => 'Esta é uma pré-visualização não salva de sua mensagem no blog.',
			'blog:preview:description:link' => 'Para continuar editando ou salvar sua mensagem, clique aqui.',

			'blog:enableblog' => 'Habilitar blog de grupos',

			'blog:group' => 'Blog do Grupo',

         /**
	     * Blog river
	     **/

	        //generic terms to use
	        'blog:river:created' => "%s criados",
	        'blog:river:updated' => "%s atualizados",
	        'blog:river:posted' => "%s enviados",

	        //these get inserted into the river links to take the user to the entity
	        'blog:river:create' => "uma nova mensagem de blog entitulada*",
	        'blog:river:update' => "uma mensagem de blog atualizada entitulada*",
	        'blog:river:annotate' => "um comentário nesta mensagem",


		/**
		 * Status messages
		 */

			'blog:posted' => "Sua mensagem foi enviada com sucesso.",
			'blog:deleted' => "Sua mensagem foi apagada com sucesso.",

		/**
		 * Error messages
		 */

			'blog:error' => 'Ocorreu um erro, tente novamente.',
			'blog:save:failure' => "Sua mensagem não pôde ser salvo, tente novamente.",
			'blog:blank' => "Você deve preencher o título e o corpo antes de enviar.",
			'blog:notfound' => "Não foi possível encontrar a mensagem.",
			'blog:notdeleted' => "Não foi possível apagar esta mensagem.",

	);

	add_translation("en",$english);
	add_translation("pt_br",$portugues_brasileiro);
?>
