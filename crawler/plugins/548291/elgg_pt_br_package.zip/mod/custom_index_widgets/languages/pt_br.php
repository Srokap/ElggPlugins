<?php

	$portugues_brasileiro = array(


		'custom_index_widgets:latest_bookmarks_index' => "Últimos links favoritos",
		'custom_index_widgets:latest_groups_index' => "Últimos grupos",
		'custom_index_widgets:latest_files_index' => "Últimos arquivos",
		'custom_index_widgets:latest_blogs_index' => "Últimas mensagens de blog",
		'custom_index_widgets:latest_members_index' => "Membros mais recentes",
		'custom_index_widgets:nofiles' => "Ainda não foram adicionados arquivos",
		'custom_index_widgets:nogroups' => "Ainda não foram adicionados grupos",
		'custom_index_widgets:latest_news_index' => "Últimas novidades",
		'custom_index_widgets:latest_pages_index' => "Últimas páginas wiki",
		'custom_index_widgets:latest_events_index' => 'Eventos chegando',
		'custom_index_widgets:latest_wire_index' => 'Últimas mensagens na rede',
		'custom_index_widgets:inline_content_index' => 'HTML livre',
		'custom_index_widgets:html_content' => 'Seu texto',
		'custom_index_widgets:latest_generic_index'=>"Conteúdo genérico",
		'custom_index_widgets:latest_tasks_index'=>"Últimas tarefas",
		'custom_index_widgets:latest_activity_index' => 'No diário de bordo',
		'custom_index_widgets:cloud_generic_index'=>"Nuvem de Tags",
		'custom_index_widgets:widget_subtype'=>"Tipo de dispositivo",
		'custom_index_widgets:metadata_name' => "Metadata",
		'custom_index_widgets:threshold'=> "Thresold",
		'custom_index_widgets:latest_izap_videos_index' => 'Últimos vídeos',
		'custom_index_widgets:display_avatar' => 'Avatar',

		'custom_index_widgets:rich_media_index' => "Conteúdo multimídia",
		'custom_index_widgets:widget_video_width' => "Largura (número sem px ou %)",
	    'custom_index_widgets:widget_video_height' => "Altura (número sem px ou %)",
	    'custom_index_widgets:widget_video_url' => "Link",
	    'custom_index_widgets:widget_video_caption' => "Legenda",

		'custom_index_widgets:layout' => "Layout",

		'custom_index_widgets:index_2rmsb' => '2 linhas, [Médio, Pequeno] - [Grande]',
		'custom_index_widgets:index_2rsmb' => '2 linhas, [Pequeno, Médio] - [Grande]',
		'custom_index_widgets:index_2rhhb' => '2 linhas, [Médio, Médio] - [Grande]',
		'custom_index_widgets:index_1rsss' => '1 linha, [Pequeno, Pequeno, Pequeno]',
		'custom_index_widgets:index_2rbhh' => '2 linhas, [Grande] -[Médio, Médio]',
		'custom_index_widgets:index_2rbsm' => '2 linhas, [Grande] -[Pequeno, Médio]',
		'custom_index_widgets:index_2rbms' => '2 linhas, [Grande] -[Médio, Pequeno]',

		'custom_index_widgets:area1' => 'Dispositivos Faixa 1',
		'custom_index_widgets:area2' => 'Dispositivos Faixa 2',
		'custom_index_widgets:area3' => 'Dispositivos Faixa 3',

		'custom_index_widgets:admin:notfound' => 'Página não encontrada',
		'custom_index_widgets:index' => "Organização dos dispositivos na página inicial",
		'custom_index_widgets:num_items' => "Número de itens",
		'custom_index_widgets:reset' => "Zerar todas as faixas de dispositivos",

		'custom_index_widgets:pleaselogin' => "Por favor, entre no sistema para ver mais...",

		'custom_index_widgets:widget_title' => "Sobrescrever título do dispositivo (será exibido apenas na página inicial em substituição ao título padrão do dispositivo)",
		'custom_index_widgets:context_mode' => "Estilo do layout",
		'custom_index_widgets:context_list' => "Lista",
		'custom_index_widgets:context_detail' => "Detalhe",

		'custom_index_widgets:login_style'=>"Posição do campo login",
		'custom_index_widgets:inlayout'=>"Na corpo da página",
		'custom_index_widgets:topbar'=>"Na barra superior",
		'custom_index_widgets:widget_all_groups' => "Todos os grupos",

	);

	add_translation("en",$english);
	add_translation("pt_br",$portugues_brasileiro);

?>
