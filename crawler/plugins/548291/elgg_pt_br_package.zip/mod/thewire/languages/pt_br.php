<?php

	$english = array(

		/**
		 * Menu items and titles
		 */

			'thewire' => "A Rede",
			'thewire:user' => "Rede de %s ",
			'thewire:posttitle' => "Notas de %s na rede: %s",
			'thewire:everyone' => "Todas as mensagens da rede",

			'thewire:read' => "Mensagens da Rede",

			'thewire:strapline' => "%s",

			'thewire:add' => "Enviar mensagem para a rede",
		    'thewire:text' => "Uma nota na rede",
			'thewire:reply' => "Responder",
			'thewire:via' => "via",
			'thewire:wired' => "Enviado para a rede",
			'thewire:charleft' => "Caracteres restantes",
			'item:object:thewire' => "Mensagens da rede",
			'thewire:notedeleted' => "mensagem apagada",
			'thewire:doing' => "O que voc� est� fazendo? Diga para todos na rede:",
			'thewire:newpost' => 'Nova mensagem na rede',
			'thewire:addpost' => 'Enviar para a Rede',
			'thewire:by' => "Mensagem da rede enviada por %s",


        /**
	     * The wire river
	     **/

	        //generic terms to use
	        'thewire:river:created' => "%s enviou",

	        //these get inserted into the river links to take the user to the entity
	        'thewire:river:create' => "na rede.",

	    /**
	     * Wire widget
	     **/

	        'thewire:sitedesc' => 'Este dispositivo exibe as �ltimas mensagens enviadas para a rede',
	        'thewire:yourdesc' => 'Este dispositivo exibe as �ltimas mensagens enviadas por voc� para a rede',
	        'thewire:friendsdesc' => 'Este dispositivo exibe as �ltimas mensagens enviadas por seus amigos para a rede',
	        'thewire:friends' => 'Seus amigos na rede',
	        'thewire:num' => 'N�mero de itens a serem exibidos',
	        'thewire:moreposts' => 'Mais mensagens da rede',


		/**
		 * Status messages
		 */

			'thewire:posted' => "Sua mensagem para a rede foi enviada com sucesso.",
			'thewire:deleted' => "Sua mensagem para a rede foi apagada com sucesso.",

		/**
		 * Error messages
		 */

			'thewire:blank' => "Desculpe; voc� precisa colocar algo na caixa de texto antes de salvar.",
			'thewire:notfound' => "Desculpe; n�o foi poss�vel localizar esta mensagem na rede.",
			'thewire:notdeleted' => "Desculpe; n�o foi poss�vel apagar esta mensagem da rede.",


		/**
		 * Settings
		 */
			'thewire:smsnumber' => "Seu n�mero de SMS caso seja diferente do seu n�mero de celular (o n�mero de celular deve ser classificado como p�blico para a rede poder us�-lo). Todos os n�meros de telefone devem estar no formato internacional.",
			'thewire:channelsms' => "O n�mero para enviar SMS � <b>%s</b>",

	);

	add_translation("en",$english);
	add_translation("pt_br",$portugues_brasileiro);

?>