<?php

	/**
	 * Elgg twitter plugin language pack
	 *
	 * @package ElggProfile
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author DiRaOL - diraol@diraol.eng.br
	 * @link http://blog.diraol.eng.br
	 * @published 14 March 2010
	 */

	$portugues_brasileiro = array(

		/**
		 * twitter widget details
		 */


		'twitter:username' => 'Insira seu nome de usuário do twitter.',
		'twitter:num' => 'Número de tweets a serem exibidos.',
		'twitter:visit' => 'visitar meu twitter',
		'twitter:notset' => 'Este dispositivo de Twitter ainda não está pronto para funcionar. Para exibir seus últimos tweets, clique em - editar - e preencha suas informações.',


		 /**
	     * twitter widget river
	     **/

	        //generic terms to use
	        'twitter:river:created' => "%s adicionou o dispositivo de twitter.",
	        'twitter:river:updated' => "%s atualizou seu dispositivo de twitter.",
	        'twitter:river:delete' => "%s removeu seu dispositivo de twitter.",


	);

	add_translation("en",$english);
	add_translation("pt_br",$portugues_brasileiro);

?>
