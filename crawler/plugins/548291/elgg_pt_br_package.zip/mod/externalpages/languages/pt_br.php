<?php

	/**
	 * Elgg ExternalPages plugin language pack
	 *
	 * @package ElggExternalPages
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author DiRaOL - diraol@diraol.eng.br
	 * @link http://blog.diraol.eng.br
	 * @published 14 March 2010
	 */

	$portugues_brasileiro = array(

		/**
		 * Menu items and titles
		 */

			'expages' => "Páginas externas",
			'expages:frontpage' => "Página inicial",
			'expages:about' => "Sobre",
			'expages:terms' => "Termos",
			'expages:privacy' => "Privacidade",
			'expages:analytics' => "Análises",
			'expages:contact' => "Contatos",
			'expages:nopreview' => "Ainda não há nenhuma pré-visualização disponível",
			'expages:preview' => "Visualização",
			'expages:notset' => "Esta página ainda não foi configurada.",
			'expages:lefthand' => "Painel de informações à esquerda",
			'expages:righthand' => "Painel de informações à direita",
			'expages:addcontent' => "Você pode adicionar conteúdos aqui pelas ferramentas de administração. Pesquise por 'Páginas externas' no painel de administração.",
			'item:object:front' => 'Itens da página inicial',

		/**
		 * Status messages
		 */

			'expages:posted' => "Sua página foi enviada com sucesso.",
			'expages:deleted' => "Sua página foi apagada com sucesso",

		/**
		 * Error messages
		 */

			'expages:deleteerror' => "Houve um erro ao apagar a página anterior",
			'expages:error' => "Ocorreu um erro, tente novamente e se o problema persistir contate um administrador",

	);

	add_translation("en",$english);
	add_translation("pt_br",$portugues_brasileiro);

?>
