<?php
	$portugues_brasileiro = array(
		// Main title
		'login_redirector' => "Redirecionar Login",

		// Admin configuration
		'login_redirector:admin:config' => "Selecione a página para a qual os usuários deverão ir após eles entrarem no sistema:",
		'login_redirector:admin:option:profile' => "Perfil do Usuário",
		'login_redirector:admin:option:dashboard' => "Dashboard",
		'login_redirector:admin:option:custom_redirect' => "Utilizar redirecionamento personalizado pelo próprio usuário",

		'login_redirector:admin:useroverride' => "Permitir que o usuário sobrescreva esta configuração?",

		'login_redirector:admin:custom_redirect' => "Insira um redirecionamento personalizado aqui",
		'login_redirector:admin:custom_redirect_info' => "Para redirecionar um usuário a um site ou página que você escolher, insira o link (URL) aqui. Utilizar esta opção impedirá que os usuários sobrescrevam o redirecionamento.<br />Insira o link (URL) completo (incluindo http ou https) ou utilize algum dos seguintes atalhos (incluindo os colchetes):",

		'login_redirector:user:config' => "Selecione a página para a qual você irá após entrar no sistema:",

	);

	add_translation("en", $english);
    add_translation("pt_br",$portugues_brasileiro);
?>
