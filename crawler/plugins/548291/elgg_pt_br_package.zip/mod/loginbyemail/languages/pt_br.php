<?php
	/**
	 * Login by Email
	 *
	 * @author Pedro Prez
	 * @link http://community.elgg.org/pg/profile/pedroprez
	 * @copyright (c) Keetup 2009
	 * @link http://www.keetup.com/
	 * @license GNU General Public License (GPL) version 2
	 */

	$portugues_brasileiro = array(
			'user:email:notfound' => 'Email %s não encontrado.',
			'username/email' => 'Nome de Usuário ou Email',
			'email:resetreq:body:wusername' => "Olá %s,

Alguém (a partir do endereço de IP %s) solicitou uma nova senha para uma conta existente.

Se foi realmente você quem solicitou uma nova senha, clique no link abaixo, ou então apenas ignore a presente mensagem.

Apenas como lembrete, seu nome de usuário é: %s

%s"
	);

	add_translation("en",$english);
    add_translation("pt_br",$portugues_brasileiro);
?>