<?php

	/**
	 * Elgg TinyMCE plugin language pack
	 *
	 * @package ElggTinyMCE
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author DiRaOL - diraol@diraol.eng.br
	 * @link http://blog.diraol.eng.br
	 * @published 14 March 2010
	 */

	$portugues_brasileiro = array(

		/**
		 * Menu items and titles
		 */

		'tinymce:remove' => "Adicionar/Remover editor",

	);

	add_translation("en",$english);
	add_translation("pt_br",$portugues_brasileiro);

?>
