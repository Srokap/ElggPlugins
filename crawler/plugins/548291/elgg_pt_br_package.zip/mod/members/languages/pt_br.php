<?php

	/**
	 * Elgg Members plugin language pack
	 *
	 * @package ElggMembers
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author DiRaOL - diraol@diraol.eng.br
	 * @link http://blog.diraol.eng.br
	 * @published 14 March 2010
	 */

	$portugues_brasileiro = array(

		'members:members' => "Membros",
	    'members:online' => "Usuários ativos no momento",
	    'members:active' => "usuários do site",
	    'members:searchtag' => "Pesquisar usuários por tag",
	    'members:searchname' => "Pesquisar usuários por nome",

		'members:label:newest' => 'Recentes',
		'members:label:popular' => 'Populares',
		'members:label:active' => 'Ativos',
		'members:search:name' => 'Nomes de usuários',
		'members:search:tags' => 'Tags',

	);

	add_translation("en",$english);
	add_translation("pt_br",$portugues_brasileiro);

?>
