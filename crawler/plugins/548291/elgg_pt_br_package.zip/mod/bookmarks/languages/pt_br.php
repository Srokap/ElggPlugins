<?php

	/**
	 * Elgg bookmark plugin language pack
	 *
	 * @package ElggBookmark
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author DiRaOL - diraol@diraol.eng.br
	 * @link http://blog.diraol.eng.br
	 * @published 14 March 2010
	 */

	$portugues_brasileiro = array(

		/**
		 * Menu items and titles
		 */

			'bookmarks' => "Favoritos",
			'bookmarks:add' => "Adicionar favorito",
			'bookmarks:read' => "%s itens adicionados aos favoritos",
			'bookmarks:friends' => "Favoritos dos amigos",
			'bookmarks:everyone' => "Todos os favoritos do site",
			'bookmarks:this' => "Adicionar aos favoritos",
			'bookmarks:this:group' => "Favoritos em %s",
			'bookmarks:bookmarklet' => "Get bookmarklet",
			'bookmarks:bookmarklet:group' => "Get group bookmarklet",
			'bookmarks:inbox' => "Caixa de entrada dos favoritos",
			'bookmarks:more' => "Mais",
			'bookmarks:shareditem' => "Itens marcados como favoritos",
			'bookmarks:with' => "Compartilhar com",
			'bookmarks:new' => "Um novo item adicionado aos favoritos",
			'bookmarks:via' => "via favoritos",
			'bookmarks:address' => "Link a ser marcado como favorito",

			'bookmarks:delete:confirm' => "Você tem certeza de que deseja apagar este item?",

			'bookmarks:numbertodisplay' => 'Número de favoritos a serem exibidos',

			'bookmarks:shared' => "Compartilhados",
			'bookmarks:visit' => "Visitar o link",
			'bookmarks:recent' => "Adicionados recentemente",

			'bookmarks:river:created' => '%s adicionados',
			'bookmarks:river:annotate' => 'adicionado um comentário neste link marcado como favorito',
			'bookmarks:river:item' => 'um item',

			'item:object:bookmarks' => 'Links favoritos',

			'bookmarks:group' => 'Favoritos do grupo',
			'bookmarks:enablebookmarks' => 'Habilitar favoritos de grupos',


		/**
		 * More text
		 */

		    'bookmarks:widget:description' =>
		            "Este dispositivo foi projetado para o seu painel e lhe exibirá os últimos itens da sua caixa de entrada de favoritos.",

			'bookmarks:bookmarklet:description' =>
					"O marcador de favoritos (bookmarks bookmarklet) permite que você compartilhe qualquer link que você encontrar na Internet com seus amigos, ou apenas marcá-lo como favorito para você mesmo. Para usar este recurso, apenas arraste o seguinte botão para a barra de links do seu navegador:",

	        'bookmarks:bookmarklet:descriptionie' =>
					"Se você está usando o Internet Explorer, você precisará clicar com o botão direito no ícone do marcador de favoritos (bookmarks bookmarklet), selecionar 'adicionar em favoritos', e então selecionar a barra de links.",

			'bookmarks:bookmarklet:description:conclusion' =>
					"Você poderá então salvar qualquer página que você visitar apenas clicando neste ícone a qualquer momento.",

		/**
		 * Status messages
		 */

			'bookmarks:save:success' => "Este link foi adicionado aos favoritos com sucesso.",
			'bookmarks:delete:success' => "Este link favorito foi apagado com sucesso.",

		/**
		 * Error messages
		 */

			'bookmarks:save:failed' => "Este link favorito não pôde ser salvo. Por favor, tente novamente.",
			'bookmarks:delete:failed' => "Este link favorito não pôde ser apagado. Por favor, tente novamente.",


	);

	add_translation("en",$english);
	add_translation("pt_br",$portugues_brasileiro);
?>
