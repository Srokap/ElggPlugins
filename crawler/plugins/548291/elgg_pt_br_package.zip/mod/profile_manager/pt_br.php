<?php
	/**
	* Profile Manager
	*
	* English language
	*
	* @package profile_manager
	* @author ColdTrick IT Solutions
	* @copyright Coldtrick IT Solutions 2009
	* @link http://www.coldtrick.com/
	*/

	$portugues_brasileiro = array(
		'profile_manager' => "Gerenciador de Perfil",
		'custom_profile_fields' => "Campos de Perfil Personalizados",
		'item:object:custom_profile_field' => 'Campo de Perfil Personalizado',
		'item:object:custom_profile_field_category' => 'Categoria de Campo de Perfil Personalizado',
		'item:object:custom_profile_type' => 'Selecionar Tipo de Perfil',
		'item:object:custom_group_field' => 'Selecionar Campo de Grupo',

		// admin
		'profile_manager:admin:metadata_name' => 'Nome',
		'profile_manager:admin:metadata_label' => 'Rótulo',
		'profile_manager:admin:metadata_hint' => 'Dica',
		'profile_manager:admin:metadata_description' => 'Descrição',
		'profile_manager:admin:metadata_label_translated' => 'Rótulo (traduzido)',
		'profile_manager:admin:metadata_label_untranslated' => 'Rótulo (não traduzido)',
		'profile_manager:admin:metadata_options' => 'Opções (separadas por vírgulas)',
		'profile_manager:admin:options:datepicker' => 'Datepicker',
		'profile_manager:admin:options:pulldown' => 'Pulldown',
		'profile_manager:admin:options:radio' => 'Radio',
		'profile_manager:admin:options:multiselect' => 'MultiSelect',
		'profile_manager:admin:show_on_members' => "Exibir como filtro na Página de Membros",

		'profile_manager:admin:additional_options' => 'Opções adicionais',
		'profile_manager:admin:show_on_register' => 'Exibir no formulário de registro',
		'profile_manager:admin:mandatory' => 'Obrigatório',
		'profile_manager:admin:user_editable' => 'Este campo pode ser editado pelo usuário',
		'profile_manager:admin:output_as_tags' => 'Exibir no perfil como tags',
		'profile_manager:admin:admin_only' => 'Campo disponível apenas para o administrador',
		'profile_manager:admin:simple_search' => 'Exibir no formulário de pesquisa simples',
		'profile_manager:admin:advanced_search' => 'Exibir no formulário de pesquisa avançada',
		'profile_manager:admin:option_unavailable' => 'Opção indisponível',

		'profile_manager:admin:profile_icon_on_register' => 'Adicionar campo obrigatório para inserir ícone de perfil no formulário de registro.',
		'profile_manager:admin:simple_access_control' => 'Exibir apenas um pulldown de controle de acesso ao editar o formulário de perfil',

		'profile_manager:admin:hide_non_editables' => 'Ocultar os campos não editáveis do formulário Editar Perfil',

		'profile_manager:admin:edit_profile_mode' => "Como exibir a tela 'Editar Perfil'",
		'profile_manager:admin:edit_profile_mode:list' => "Lista",
		'profile_manager:admin:edit_profile_mode:tabbed' => "Abas",

		'profile_manager:admin:show_full_profile_link' => 'Exibir um link para a página de perfil completo',

		'profile_manager:admin:display_categories' => 'Selecionar como as diferentes categorias são exibidas no perfil',
		'profile_manager:admin:display_categories:option:plain' => 'Plano',
		'profile_manager:admin:display_categories:option:accordion' => 'Sanfona',

		'profile_manager:admin:profile_type_selection' => 'Quem pode modificar o tipo de perfil?',
		'profile_manager:admin:profile_type_selection:option:user' => 'Usuário',
		'profile_manager:admin:profile_type_selection:option:admin' => 'Apenas administrador',

		'profile_manager:admin:show_admin_stats' => "Exibir estatísticas de administração",
		'profile_manager:admin:show_members_search' => "Exibir a página de pesquisa de 'Membros' no gerenciador de perfil",

		'profile_manager:admin:warning:profile' => "AVISO: Este plugin deve ficar abaixo do plugin Profile",

		// profile field additionals description
		'profile_manager:admin:show_on_register:description' => "Se você deseja que este campo esteja no formulário de registro.",
		'profile_manager:admin:mandatory:description' => "Se você deseja que este campo seja obrigatório (aplicável apenas no formulário de registro).",
		'profile_manager:admin:user_editable:description' => "Se selecionar 'Não' os usuários não poderão editar este campo (útil quando o dado é gerenciado em algum sistema externo).",
		'profile_manager:admin:output_as_tags:description' => "Saída de dados serão tratadas como tags (aplicável apenas no perfil de usuários).",
		'profile_manager:admin:admin_only:description' => "Selecione 'Sim' se o campo estiver disponível apenas para administradores.",
		'profile_manager:admin:simple_search:description' => "Selecione 'Sim' se o campo é procurável no formulário de pesquisa simples de perfil.",
		'profile_manager:admin:advanced_search:description' => "Selecione 'Sim' se o campo é procurável no formulário de pesquisa avançada no perfil.",

		// non_editable
		'profile_manager:non_editable:info' => 'Este campo não pode ser editado',

		// profile user links
		'profile_manager:show_full_profile' => 'Perfil Completo',

		// datepicker
		'profile_manager:datepicker:output:dateformat' => '%a %d %b %Y', // For available notations see http://nl.php.net/manual/en/function.strftime.php
		'profile_manager:datepicker:input:localisation' => '', // change it to the available localized js files in custom_profile_fields/vendors/jquery.datepick.package-3.5.2 (e.g. jquery.datepick-nl.js), leave blank for default
		'profile_manager:datepicker:input:dateformat' => '%m/%d/%Y', // Notation is based on strftime, but must result in output like http://keith-wood.name/datepick.html#format
		'profile_manager:datepicker:input:dateformat_js' => 'dd/mm/yy', // Notation is based on strftime, but must result in output like http://keith-wood.name/datepick.html#format

		// register form mandatory notice
		'profile_manager:register:mandatory' => "Itens marcados com um * são obrigatórios",

		// register profile icon
		'profile_manager:register:profile_icon' => 'Esta comunidade exige que você envie uma imagem para o seu perfil',

		// simple access control
		'profile_manager:simple_access_control' => 'Selecione quem pode visualizar as informações do seu perfil',

		// register pre check
		'profile_manager:register_pre_check:missing' => 'O próximo campo deve ser preenchido: %s',
		'profile_manager:register_pre_check:profile_icon:error' => 'Houve um erro ao enviar a imagem do seu perfil (provavelmente relacionado ao tamanho do arquivo)',
		'profile_manager:register_pre_check:profile_icon:nosupportedimage' => 'Imagem de perfil enviada não está num formato de arquivo válido (jpg, gif, png)',

		// actions
		// new
		'profile_manager:actions:new:success' => 'Novo campo de perfil personalizado adicionado com sucesso',
		'profile_manager:actions:new:error:metadata_name_missing' => 'Não foi fornecido um nome para o metadata',
		'profile_manager:actions:new:error:metadata_name_invalid' => 'Nome do metadata é um nome inválido',
		'profile_manager:actions:new:error:metadata_options' => 'Você precisa inserir opções quando utilizar este tipo',
		'profile_manager:actions:new:error:unknown' => 'Erro desconhecido ocorreu ao salvar o novo campo de perfil personalizado',
		'profile_manager:action:new:error:type' => 'Tipo (grupo ou perfil) de campo de perfil errado',

		// edit
		'profile_manager:actions:edit:error:unknown' => 'Erro ao pesquisar dado do campo de perfil',

		//reset
		'profile_manager:actions:reset' => 'Limpar',
		'profile_manager:actions:reset:description' => 'Apagar todos os campos de perfil personalizados.',
		'profile_manager:actions:reset:confirm' => 'Você tem certeza de que deseja apagar todos os campos de perfil?',
		'profile_manager:actions:reset:error:unknown' => 'Erro desconhecido ocorreu ao limpar todos os campos de perfil',
		'profile_manager:actions:reset:error:wrong_type' => 'Tipo (grupo ou perfil) de campo de perfil errado',
		'profile_manager:actions:reset:success' => 'Limpeza realizada com sucesso',

		//delete
		'profile_manager:actions:delete:confirm' => 'Você tem certeza de que deseja apagar este campo?',
		'profile_manager:actions:delete:error:unknown' => 'Erro desconhecido ocorreu ao apagar',

		// toggle option
		'profile_manager:actions:toggle_option:error:unknown' => 'Erro desconhecido ocorreu ao modificar a opção',

		// actions
		'profile_manager:actions:title' => 'Ações',

		// import from custom
		'profile_manager:actions:import:from_custom' => 'Importar campos personalizados',
		'profile_manager:actions:import:from_custom:description' => 'Importar campos de perfil definidos previamente (com a funcionalidade padrão do Elgg)',
		'profile_manager:actions:import:from_custom:confirm' => 'Você tem certeza de que deseja importar os campos personalizados?',
		'profile_manager:actions:import:from_custom:no_fields' => 'Nenhum campo personalizado disponível para importação',
		'profile_manager:actions:import:from_custom:new_fields' => '<b>%s</b> novos campos importados com sucesso',

		// import from default
		'profile_manager:actions:import:from_default' => 'Campos padrão importados',
		'profile_manager:actions:import:from_default:description' => "Importar campos padrão do Elgg.",

		'profile_manager:actions:import:from_default:confirm' => 'Você tem certeza de que deseja importar campos padrão?',
		'profile_manager:actions:import:from_default:no_fields' => 'Nenhum campo padrão disponível para importação',
		'profile_manager:actions:import:from_default:new_fields' => '<b>%s</b> novos campos importados com sucesso',
		'profile_manager:actions:import:from_default:error:wrong_type' => 'Tipo (grupo ou perfil) de campo de perfil errado',

		// category to field
		'profile_manager:actions:change_category:error:unknown' => "Erro desconhecido ocorreu ao tentar modificar a categoria",

		// add category
		'profile_manager:action:category:add:error:name' => "Não foi informado um nome para a categoria",
		'profile_manager:action:category:add:error:object' => "Erro ao criar o objeto categoria",
		'profile_manager:action:category:add:error:save' => "Erro ao salvar o objeto categoria",
		'profile_manager:action:category:add:succes' => "A categoria foi criada com sucesso",

		// delete category
		'profile_manager:action:category:delete:error:guid' => "Nenhum GUID foi informado",
		'profile_manager:action:category:delete:error:type' => "O GUID informado não é uma categoria de campo de perfil personalizado",
		'profile_manager:action:category:delete:error:delete' => "Um erro ocorreu ao apagar a categoria",
		'profile_manager:action:category:delete:succes' => "A categoria foi apagada com sucesso",

		// add profile type
		'profile_manager:action:profile_types:add:error:name' => "Não foi informado um nome para o tipo de perfil personalizado",
		'profile_manager:action:profile_types:add:error:object' => "Erro ao criar o tipo de perfil personalizado",
		'profile_manager:action:profile_types:add:error:save' => "Erro ao salvar o tipo de perfil personalizado",
		'profile_manager:action:profile_types:add:succes' => "O tipo de perfil personalizado foi criado com sucesso",

		// delete profile type
		'profile_manager:action:profile_types:delete:error:guid' => "Nenhum GUID foi informado",
		'profile_manager:action:profile_types:delete:error:type' => "O GUID informado não é um tipo de perfil personalizado",
		'profile_manager:action:profile_types:delete:error:delete' => "Um erro desconhecido ocorreu ao apagar o tipo de perfil personalizado",
		'profile_manager:action:profile_types:delete:succes' => "O tipo de perfil personalizado foi apagado com sucesso",

		// Custom Group Fields
		'profile_manager:group_fields' => "Substituir os campos do grupo",
		'profile_manager:group_fields:title' => "Substituir os campos de perfil do grupo",

		'profile_manager:group_fields:add:description' => "Aqui você pode editar os campos exibidos na página de perfil de um grupo",
		'profile_manager:group_fields:add:link' => "Adicionar um novo campo de perfil do grupo",

		'profile_manager:profile_fields:add:description' => "Aqui você pode editar os campos que um usuário pode editar no perfil dele",
		'profile_manager:profile_fields:add:link' => "Adicionar um novo campo de perfil",

		// Custom fields categories
		'profile_manager:categories:add:link' => "Adicionar uma nova categoria",

		'profile_manager:categories:list:title' => "Categorias",
		'profile_manager:categories:list:default' => "Padrão",
		'profile_manager:categories:list:view_all' => "Exibir todos os campos",
		'profile_manager:categories:list:no_categories' => "Nenhuma categoria definida",

		'profile_manager:categories:delete:confirm' => "Você tem certeza de que deseja apagar esta categoria?",

		// Custom Profile Types
		'profile_manager:profile_types:add:link' => "Adicionar um novo tipo de perfil",

		'profile_manager:profile_types:list:title' => "Tipos de Perfil",
		'profile_manager:profile_types:list:no_types' => "nenhum tipo de perfil foi definido",

		'profile_manager:profile_types:delete:confirm' => "Você tem certeza de que deseja apagar este tipo de perfil?",

		// Export
		'profile_manager:actions:export' => "Exportar Dados do Perfil",
		'profile_manager:actions:export:description' => "Exportar dados do perfil para um arquivo CSV",
		'profile_manager:export:title' => "Exportar Dados do Perfil",
		'profile_manager:export:description:custom_profile_field' => "Esta função exportará todos os metadados do <b>usuário</b> baseados nos campos selecionados.",
		'profile_manager:export:description:custom_group_field' => "Esta função exportará todos os metadados do <b>grupo</b> baseados nos campos selecionados.",
		'profile_manager:export:list:title' => "Selecione os campos que você deseja exportar",
		'profile_manager:export:nofields' => "Nenhum campo de perfil personalizado disponível para exportação",

		// Configuration Backup and Restore
		'profile_manager:actions:configuration:backup' => "Backupar Configuração dos Campos",
		'profile_manager:actions:configuration:backup:description' => "Backupar a configuração destes campos (<b>categorias e tipos não serão backupados</b>)",
		'profile_manager:actions:configuration:restore' => "Restaurar Configuração dos Campos",
		'profile_manager:actions:configuration:restore:description' => "Restaurar um arquivo de configuração backupado anteriormente (<b>você perderá as relações entre campos e categorias</b>)",

		'profile_manager:actions:configuration:restore:upload' => "Restaurar",

		'profile_manager:actions:restore:success' => "Restauração bem sucedida",
		'profile_manager:actions:restore:error:deleting' => "Erro ao restaurar: não foi possível apagar os campos atuais",
		'profile_manager:actions:restore:error:fieldtype' => "Erro ao restaurar: tipos de campos não combinam",
		'profile_manager:actions:restore:error:corrupt' => "Erro ao restaurar: arquivo de backup aparentemente está corrompido ou alguma informação está faltando",
		'profile_manager:actions:restore:error:json' => "Erro ao restaurar: arquivo JSON inválido",
		'profile_manager:actions:restore:error:nofile' => "Erro ao restaurar: nenhum arquivo enviado",

		// Tooltips
		'profile_manager:tooltips:profile_field' => "
			<b>Campo de Perfil</b><br />
			Aqui você pode adicionar um novo campo de perfil.<br /><br />
			Se você deixar o rótulo vazio, você poderá internacionalizar o rótulo do campo de perfil (<i>profile:[name]</i>).<br /><br />
			Use o campo dica para fornecer em formulários de entrada de dados (registro e edição de perfil/grupo) um ícone com uma descrição flutuante.<br /><br />
			Opções são obrigatórias apenas para tipos de campos <i>Pulldown, Radio and MultiSelect</i>.
		",
		'profile_manager:tooltips:profile_field_additional' => "
			<b>Exibir no formulário de registro</b><br />
			Se você desejar que este campo esteja no formulário de registro.<br /><br />

			<b>Obrigatório</b><br />
			Se você deseja que este campo seja obrigatório (aplicável apenas no formulário de registro).<br /><br />

			<b>Editável pelo usuário</b><br />
			Se selecionar 'Não' os usuários não poderão editar este campo (útil quando o dado é gerenciado em algum sistema externo).<br /><br />

			<b>Exibir como tags</b><br />
			A saída de dados será tratada como tags (aplicável apenas no perfil de usuário).<br /><br />

			<b>Campo apenas para administradores</b><br />
			Selecione 'Sim' se o campo estiver disponível apenas para administradores.
		",
		'profile_manager:tooltips:category' => "
			<b>Categoria</b><br />
			Aqui você pode adicionar uma nova categoria de perfil.<br /><br />
			Se você deixar o rótulo vazio, você poderá internacionalizar o rótulo da categoria (<i>profile:categories:[name]</i>).<br /><br />

			Se os Tipos de Perfil forem definidos você poderá escolher em qual tipo de perfil esta categoria é aplicável. Se nenhum perfil for especificado, a categoria será aplicada para todos os tipos de perfil (até mesmo quando indefinido).
		",
		'profile_manager:tooltips:category_list' => "
			<b>Categorias</b><br />
			Exibe uma lista com todas as categorias configuradas.<br /><br />

			<i>Padrão</i> é a categoria aplicada para todos os perfis.<br /><br />

			Adicionar campos para estas categorias arrastando-os para as categorias.<br /><br />

			Clique no rótulo da categoria para filtrar os campos visíveis. Clicando em visualizar todos os campos exibirá todos os campos.<br /><br />

			Além disso você pode modificar a ordem das categorias arrastando-as (<i>A categoria padrão não pode ser arrastada</i>. <br /><br />

			Clique no ícone de edição para editar a categoria.
		",
		'profile_manager:tooltips:profile_type' => "
			<b>Tipo de Perfil</b><br />
			Aqui você pode adicionar um novo tipo de perfil.<br /><br />
			Se você deixar o rótulo vazio, você poderá internacionalizar o rótulo do tipo de perfil (<i>profile:types:[name]</i>).<br /><br />
			Insira uma descrição que os usuários possam visualizar quando selecionarem este tipo de perfil ou deixe vazio para internacionalizar (<i>profile:types:[name]:description</i>).<br /><br />
			Você pode adicionar este tipo de perfil como filtrável na página de pesquisa de usuários<br /><br />

			Se as Categorias estão definidas você pode escolher quais categorias aplicar a este tipo de perfil.
		",
		'profile_manager:tooltips:profile_type_list' => "
			<b>Tipos de Perfil</b><br />
			Exibir uma lista com todos os tipos de perfil configurados.<br /><br />
			Clique no ícone de edição para editar o tipo de perfil.
		",
		'profile_manager:tooltips:actions' => "
			<b>Ações</b><br />
			Várias ações relacionadas a estes campos de perfil.
		",

		// Edit profile => profile type selector
		'profile_manager:profile:edit:custom_profile_type:label' => "Selecione seu tipo de perfil",
		'profile_manager:profile:edit:custom_profile_type:description' => "Descrição do tipo de perfil selecionado",
		'profile_manager:profile:edit:custom_profile_type:default' => "Padrão",

		// Admin Stats
		'profile_manager:admin_stats:title'=> "Estatísticas do Gerenciador de Perfil",
		'profile_manager:admin_stats:total'=> "Contador do total de usuários",
		'profile_manager:admin_stats:profile_types'=> "Quantidade de usuários com tipo de perfil",

		// Members
		'profile_manager:members:menu' => "Membros",
		'profile_manager:members:submenu' => "Pesquisar Membros",
		'profile_manager:members:searchform:title' => "Pesquisar por Membros",
		'profile_manager:members:searchform:simple:title' => "Pesquisa Simples",
		'profile_manager:members:searchform:advanced:title' => "Pesquisa Avançada",
		'profile_manager:members:searchform:sorting' => "Ordenação",
		'profile_manager:members:searchform:date:from' => "de",
		'profile_manager:members:searchform:date:to' => "para",
		'profile_manager:members:searchresults:title' => "Resultados da Pesquisa",
		'profile_manager:members:searchresults:query' => "QUERY",
		'profile_manager:members:searchresults:noresults' => "Sua pesquisa não encontrou usuários",


		// Admin add user form
		'profile_manager:admin:adduser:notify' => "Notificar usuário",
		'profile_manager:admin:adduser:use_default_access' => "Metadata extra criado com base no nível de acesso padrão da comunidade",
		'profile_manager:admin:adduser:extra_metadata' => "Adicionar dados de perfil extra",

	);

	add_translation("en", $english);
    add_translation("pt_br",$portugues_brasileiro);
?>