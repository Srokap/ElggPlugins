<?php

	/**
	 * Elgg TwitterService plugin language pack
	 *
	 * @package ElggTwitterService
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author DiRaOL - diraol@diraol.eng.br
	 * @link http://blog.diraol.eng.br
	 * @published 14 March 2010
	 */

	$portugues_brasileiro = array(
		'twitterservice' => 'Serviços de Twitter',
		'twitterservice:postwire' => 'Ao realizar estas configurações, todas suas mensagens nesta comunidade serão enviadas à sua conta do Twitter. Você deseja twitar suas mensagens desta comunidade em seu Twitter?',
		'twitterservice:twittername' => 'Nome de usuário do Twitter',
		'twitterservice:twitterpass' => 'Senha do Twitter',
	);

	add_translation("en",$english);
	add_translation("pt_br",$portugues_brasileiro);
?>
