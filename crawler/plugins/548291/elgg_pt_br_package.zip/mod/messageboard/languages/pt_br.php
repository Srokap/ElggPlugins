<?php

	/**
	 * Elgg MessageBoard plugin language pack
	 *
	 * @package messageboard
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author DiRaOL - diraol@diraol.eng.br
	 * @link http://blog.diraol.eng.br
	 * @published 14 March 2010
	 */

	$portugues_brasileiro = array(

		/**
		 * Menu items and titles
		 */

			'messageboard:board' => "Painel de Mensagens",
			'messageboard:messageboard' => "painel de mensagens",
			'messageboard:viewall' => "Ver todas",
			'messageboard:postit' => "Enviar",
			'messageboard:history:title' => "Histórico",
			'messageboard:none' => "Ainda não há mensagens no painel",
			'messageboard:num_display' => "Número de mensagens a serem exibidas",
			'messageboard:desc' => "Este é um painel de mensagens que você pode adicionar ao seu perfil no qual outros usuários podem comentar.",

			'messageboard:user' => "Painel de mensagens de %s",

			'messageboard:replyon' => 'Responder',
			'messageboard:history' => "Histórico",

         /**
	     * Message board widget river
	     **/

	        'messageboard:river:annotate' => "%s tem um novo comentário em seu painel de mensagens.",
	        'messageboard:river:create' => "%s adicionou o dispositivo 'painel de mensagens'.",
	        'messageboard:river:update' => "%s atualizou seu dispositivo 'painel de mensagens'.",
	        'messageboard:river:added' => "%s enviou em",
		    'messageboard:river:messageboard' => "painel de mensagens",


		/**
		 * Status messages
		 */

			'messageboard:posted' => "Sua mensagem foi adicionada com sucesso ao painel de mensagens.",
			'messageboard:deleted' => "A mensagem foi apagada com sucesso.",

		/**
		 * Email messages
		 */

			'messageboard:email:subject' => 'Você adicionou um novo comentário no painel de mensagens!',
			'messageboard:email:body' => "Você possui um novo comentário de %s no painel de mensagens. Ele diz:


%s


Para ver os comentários de seu painel de mensagens, clique aqui:

	%s

Para ver o perfil de %s, clique aqui:

	%s

Por favor, não responda este email.",

		/**
		 * Error messages
		 */

			'messageboard:blank' => "Você deve adicionar algum texto à mensagem antes de salvá-la.",
			'messageboard:notfound' => "Não foi possível encontrar o item especificado.",
			'messageboard:notdeleted' => "Não foi possível apagar esta mensagem.",
			'messageboard:somethingwentwrong' => "Ocorreu um erro ao tentar salvar sua mensagens. Certifique-se de que você realmente escreveu a mensagem.",

			'messageboard:failure' => "Ocorreu um erro ao adicionar a mensagem. Tente novamente.",

	);

	add_translation("en",$english);
	add_translation("pt_br",$portugues_brasileiro);

?>
