<?php
/**
         * Elgg spotlight lorea
         *
         * @package
         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author lorea
         * @copyright lorea
         * @link http://lorea.cc
         */

	$portugues_brasileiro = array(
                    "group_operators:title" => 'Moderadores do grupo',
                    "group_operators:addoperators" => 'Gerenciar moderadores do grupo',
                    "group_operators:operators" => 'Moderadores',
                    "group_operators:members" => 'Membros',
                    "group_operators:operators:instructions" => 'clique para apagar direitos do moderador',
                    "group_operators:members:instructions" => 'clique para tornar o membro um moderador do grupo',

	);

	add_translation("en",$english);
    add_translation("pt_br",$portugues_brasileiro);

?>
