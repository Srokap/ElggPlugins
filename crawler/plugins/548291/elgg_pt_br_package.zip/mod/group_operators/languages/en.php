<?php
/**
         * Elgg spotlight lorea
         * 
         * @package
         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author lorea
         * @copyright lorea
         * @link http://lorea.cc
         */

	$english = array(
                    "group_operators:title" => 'Group operators',
                    "group_operators:addoperators" => 'Manage group operators',
                    "group_operators:operators" => 'Operators',
                    "group_operators:members" => 'Members',
                    "group_operators:operators:instructions" => 'click to remove operator rights',
                    "group_operators:members:instructions" => 'click to make the member group operator',

	);
	
	add_translation("en",$english);

?>
