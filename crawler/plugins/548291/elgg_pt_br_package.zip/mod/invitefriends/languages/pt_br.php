<?php

	/**
	 * Elgg invite page
	 *
	 * @package ElggFile
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author DiRaOL - diraol@diraol.eng.br
	 * @link http://blog.diraol.eng.br
	 * @published 14 March 2010
	 */

	$portugues_brasileiro = array(

		'friends:invite' => 'Convidar amigos',
		'invitefriends:introduction' => 'Para convidar amigos para participar desta comunidade, coloque o email deles abaixo (um por linha):',
		'invitefriends:message' => 'Adicione uma mensagem para que eles recebam junto com o convite:',
		'invitefriends:subject' => 'Convite para participar de %s',

		'invitefriends:success' => 'Seus amigos foram convidados.',
		'invitefriends:email_error' => 'Convites enviados, mas o endereço abaixo não é válido: %s',
		'invitefriends:failure' => 'Seus amigos não puderam ser convidados.',

		'invitefriends:message:default' => '
Olá,

eu gostaria de convidá-lo para participar de %s.',
		'invitefriends:email' => '
Você foi convidados para participar de %s por %s. A seguinte mensagem foi adicionada:

%s

Para participar, clique no link abaixo:

%s

Ele(a) será automaticamente adicionado(a) como seu(ua) amigo(a) quando você criar uma conta.',

	);

	add_translation("en",$english);
	add_translation("pt_br",$portugues_brasileiro);
?>
