<?php
	/**
	 * Elgg diagnostics language pack.
	 *
	 * @package ElggDiagnostics
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author DiRaOL - diraol@diraol.eng.br
	 * @link http://blog.diraol.eng.br
	 * @published 14 March 2010
	 */

	$portugues_brasileiro = array(

			'diagnostics' => 'Diagnóstico do sistema',
			'diagnostics:unittester' => 'Testes unitários',

			'diagnostics:description' => 'O relatório de diagnóstico é útil para diagnosticar qualquer problema com o Elgg, e deve ser adicionado em qualquer relatório de erro que você fizer.',
			'diagnostics:unittester:description' => 'O que se segue são testes de diagnóstico registrados por dispositivos e devem ser realizados para depurar partes do sistema Elgg.',

			'diagnostics:unittester:description' => 'Os testes unitários verificam o núcleo do Elgg em busca de APIs quebradas ou com problemas.',
			'diagnostics:unittester:debug' => 'O site deve estar no modo de depuração (debug) para executar os testes unitários.',
			'diagnostics:unittester:warning' => 'ATENÇÃO: Estes testes podem deixar para trás objetos de depuração em seu banco de dados. NÃO UTILIZE EM UM SITE EM PRODUÇÃO!',

			'diagnostics:test:executetest' => 'Executar teste',
			'diagnostics:test:executeall' => 'Executar todos os testes',
			'diagnostics:unittester:notests' => 'Desculpe, não há módulos de testes unitários instalados.',
			'diagnostics:unittester:testnotfound' => 'Desculpe, o relatório não pôde ser gerado porque o teste não foi encontrado',

			'diagnostics:unittester:testresult:nottestclass' => 'FALHOU - Resultado não foi uma classe de testes',
			'diagnostics:unittester:testresult:fail' => 'FALHOU',
			'diagnostics:unittester:testresult:success' => 'SUCESSO',

			'diagnostics:unittest:example' => 'Teste unitário de exemplo, somente disponível em modo de depuração (debug).',

			'diagnostics:unittester:report' => 'Relatório de testes para %s',

			'diagnostics:download' => 'Baixar .txt',


			'diagnostics:header' => '========================================================================
Relatório de Diagnóstico do Elgg
%s gerado por %s
========================================================================

',
			'diagnostics:report:basic' => '
Elgg Release %s, versão %s

------------------------------------------------------------------------',
			'diagnostics:report:php' => '
PHP info:
%s
------------------------------------------------------------------------',
			'diagnostics:report:plugins' => '
Dispositivos instalados e detalhes:

%s
------------------------------------------------------------------------',
			'diagnostics:report:md5' => '
Arquivos instalados e checksums:

%s
------------------------------------------------------------------------',
			'diagnostics:report:globals' => '
Variáveis globais:

%s
------------------------------------------------------------------------',

	);

	add_translation("en",$english);
	add_translation("pt_br",$portugues_brasileiro);
?>
