<?php
	/**
	* ElggChat - Pure Elgg-based chat/IM
	*
	* English language file
	*
	* @package elggchat
	* @author ColdTrick IT Solutions
	* @copyright Coldtrick IT Solutions 2009
	* @link http://www.coldtrick.com/
	* @version 0.4
	*/

	$portugues_brasileiro = array(
		'elggchat' => "ElggChat",
		'elggchat:title' => "ElggChat",
		'elggchat:chat:profile:invite' => "Convidar para bate-papo",
		'elggchat:chat:send' => "Enviar",

		'elggchat:friendspicker:info' => "Amigos online",
		'elggchat:friendspicker:online' => "Online",
		'elggchat:friendspicker:offline' => "Offline",

		'elggchat:chat:invite' => "Convidar",
		'elggchat:chat:leave' => "Sair",
		'elggchat:chat:leave:confirm' => "Você tem certeza de que deseja sair desta sessão de bate-papo?",

		'elggchat:action:invite' => "<b>%s</b> convidado <b>%s</b>",
		'elggchat:action:leave' => "<b>%s</b> saiu da sessão",
		'elggchat:action:join' => "<b>%s</b> entrou na sessão",

		'elggchat:session:name:default' => "Sessão de bate-papo (%s)",
		'elggchat:session:onlinestatus' => "Última atividade: %s",

		// Plugin settings
		'elggchat:admin:settings:hours' => "%s hora(s)",

		'elggchat:admin:settings:maxsessionage' => "Tempo máximo que uma sessão pode permanecer em espera antes de limpar",

		'elggchat:admin:settings:chatupdateinterval' => "Intervalo de atualização (em segundos) da janela de bate-papo",
		'elggchat:admin:settings:maxchatupdateinterval' => "Cada 10 períodos de intervalo com nenhuma informação retornada o intervalo de atualização será multiplicado até alcançar seu máximo (em segundos)",
		'elggchat:admin:settings:monitorupdateinterval' => "Intervalo de atualização (em segundos) do monitor da sessão de bate-papo, a qual verifica novos pedidos de bate-papo",
		'elggchat:admin:settings:enable_sounds' => "Permitir sons",
		'elggchat:admin:settings:enable_flashing' => "Permitir alerta visual para novas mensagens",
		'elggchat:admin:settings:enable_extensions' => "Permitir extensões",

		'elggchat:admin:settings:online_status:active' => "Número máximo de segundos antes de o usuário entrar em espera",
		'elggchat:admin:settings:online_status:inactive' => "Número máximo de segundos antes de o usuário ficar inativo",

		// User settings
		'elggchat:usersettings:enable_chat' => "Permitir a barra do ElggChat?",
		'elggchat:usersettings:allow_contact_from' => "Permitir que o seguinte membro entre em contato comigo por bate-papo",
		'elggchat:usersettings:allow_contact_from:all' => "Todos os membros podem entrar em contato comigo por bate-papo",
		'elggchat:usersettings:allow_contact_from:friends' => "Apenas os meus amigos podem entrar em contato comigo por bate-papo",
		'elggchat:usersettings:allow_contact_from:none' => "Ninguém pode entrar em contato comigo por bate-papo",
		'elggchat:usersettings:show_offline_user' => "Exibir usuários offline",

		// Toolbar actions
		'elggchat:toolbar:minimize' => "Minimizar a barra do ElggChat",
		'elggchat:toolbar:maximize' => "Maximizar a barra do ElggChat",
	);

	add_translation("en", $english);
    add_translation("pt_br",$portugues_brasileiro);

?>
