<?php
	/**
	 * Elgg Embed plugin language pack
	 *
	 * @package ElggEmbed
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author DiRaOL - diraol@diraol.eng.br
	 * @link http://blog.diraol.eng.br
	 * @published 14 March 2010
	 */

	$portugues_brasileiro = array(

		'media:insert' => 'Incorporar / enviar mídia',

		'embed:instructions' => 'Clique em qualquer arquivo para incorporá-lo ao conteúdo.',

		'embed:media' => 'Incorporar mídia',
		'upload:media' => 'Enviar mídia',

		'embed:file:required' => 'Nenhuma ferramenta de envio foi encontrada. O administrador do sistema precisa instalar o plugin de arquivo ou similar.',

	);

	add_translation("en",$english);
	add_translation("pt_br",$portugues_brasileiro);
?>
