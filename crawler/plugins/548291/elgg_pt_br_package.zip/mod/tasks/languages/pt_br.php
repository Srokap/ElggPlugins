<?php

	$portugues_brasileiro = array(

		/**
		 * Menu items and titles
		 */

			'tasks' => "Tarefas",
			'tasks:add' => "Adicionar tarefa",
			'tasks:read' => "%s Tarefas registradas",
			'tasks:friends' => "Tarefas dos amigos",
			'tasks:everyone' => "Todas as tarefas do site",
			'tasks:this' => "Registrar tarefa",
			'tasks:this:group' => "registrada em %s",

			'tasks:more' => "Mais",
			'tasks:shareditem' => "Tarefa",
			'tasks:with' => "Compartilhar com",
			'tasks:new' => "Nova tarefa registrada",
			'tasks:via' => "por tarefas",

			'tasks:delete:confirm' => "Você realmente deseja apagar este item?",

			'tasks:numbertodisplay' => 'Número de tarefas registradas a serem exibidas',

			'tasks:shared' => "Tarefa compartilhada",
			'tasks:visit' => "Visitar tarefa",
			'tasks:recent' => "Tarefas recentes",

			'tasks:river:created' => '%s tarefas criadas',
			'tasks:river:annotate' => 'adicionado um comentário nesta tarefa',
			'tasks:river:item' => 'um item',

			'item:object:tasks' => 'Tarefas registradas',

			'tasks:group' => 'Tarefas em grupos',
			'tasks:enabletasks' => 'Permitir tarefas em grupos',


		/**
		 * More text
		 */

		    'tasks:widget:description' =>
		            "Este dispositivo foi projetado para o seu painel e exibirá os últimos itens da sua caixa de entrada de tarefas.",

			'tasks:tasklet:description' =>
					"O marcador de tarefas (tasks tasklet) permite que você compartilhe qualquer recurso que você encontrar na Internet com seus amigos, ou apenas atribuir esta tarefa para você próprio. Para usar este recurso, apenas arraste o seguinte botão para a barra de links do seu navegador:",

	        'tasks:tasklet:descriptionie' =>
					"Se você está usando Internet Explorer, você precisará clicar com o botão direito no ícone do marcador de tarefas (tasks tasklet), selecionar 'adicionar aos favoritos', e então selecionar a barra de links.",

			'tasks:tasklet:description:conclusion' =>
					"Você poderá então salvar qualquer página que você visitar apenas clicando neste botão a qualquer momento.",

		/**
		 * Status messages
		 */

			'tasks:save:success' => "Esta tarefa foi registrada com sucesso.",
			'tasks:delete:success' => "Esta tarefa foi apagada com sucesso.",

		/**
		 * Error messages
		 */

			'tasks:save:failed' => "Esta tarefa não pôde ser salva. Por favor, tente novamente.",
			'tasks:delete:failed' => "Esta tarefa não pôde ser apagada. Por favor, tente novamente.",

			'tasks:add' => "Adicionar uma tarefa",

			 'tasks:start_date' => "Início",
			 'tasks:end_date' => "Fim",
			 'tasks:percent_done' => " já realizado",
			 'tasks:work_remaining' => "Pendente.",


			 'tasks:task_type' => 'Tipo',
			 'tasks:status' => 'Situação',
			 'tasks:assigned_to' => 'Responsável',

			 'tasks:task_type_'=>"",
			 'tasks:task_type_0'=>"",
			 'tasks:task_type_1'=>"Análise",
			 'tasks:task_type_2'=>"Planejamento",
			 'tasks:task_type_3'=>"Desenvolvimento",
			 'tasks:task_type_4'=>"Teste",
			 'tasks:task_type_5'=>"Implantação",

			 'tasks:task_status_'=>"",
			 'tasks:task_status_0'=>"",
			 'tasks:task_status_1'=>"Aberta",
			 'tasks:task_status_2'=>"Em andamento",
			 'tasks:task_status_3'=>"Suspensa",
			 'tasks:task_status_4'=>"Cancelada",
			 'tasks:task_status_5'=>"Encerrada",

			 'tasks:task_percent_done_'=>"0%",
			 'tasks:task_percent_done_0'=>"0%",
			 'tasks:task_percent_done_1'=>"20%",
			 'tasks:task_percent_done_2'=>"40%",
			 'tasks:task_percent_done_3'=>"60%",
			 'tasks:task_percent_done_4'=>"80%",
			 'tasks:task_percent_done_5'=>"100%",

			 'tasks:access' => "Permissão de leitura",
			 'tasks:write_access' => "Permissão de escrita",

			 'tasks:tasksboard'=>"Painel de Tarefas",
			 'tasks:tasksmanage'=>"Gerenciar",
			 'tasks:tasksmanageone'=>"Gerenciar uma tarefa",
	);

	add_translation("en",$english);	add_translation("pt_br",$portugues_brasileiro);


?>