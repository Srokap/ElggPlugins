<?php
	/**
	 * Elgg groups plugin language pack
	 *
	 * @package ElggGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author DiRaOL - diraol@diraol.eng.br
	 * @link http://blog.diraol.eng.br
	 * @published 14 March 2010
	 */

	$portugues_brasileiro = array(

		/**
		 * Menu items and titles
		 */

			'groups' => "Grupos",
			'groups:owned' => "Grupos criados por você",
			'groups:yours' => "Seus grupos",
			'groups:user' => "Grupos de %s",
			'groups:all' => "Todos os grupos do site",
			'groups:new' => "Criar um novo grupo",
			'groups:edit' => "Editar grupo",
			'groups:delete' => 'Apagar grupo',
			'groups:membershiprequests' => 'Gerenciar solicitações de entrada',
			'groups:invitations' => 'Convites do grupo',

			'groups:icon' => 'Ícone do grupo (deixe em branco para não alterar)',
			'groups:name' => 'Nome do grupo',
			'groups:username' => 'Apelido do grupo (exibido nas URLs, apenas caracteres alfanuméricos)',
			'groups:description' => 'Descrição',
			'groups:briefdescription' => 'Breve descrição',
			'groups:interests' => 'Tags',
			'groups:website' => 'Sites',
			'groups:members' => 'Membros do grupo',
			'groups:membership' => "Permissões de adesão ao grupo",
			'groups:access' => "Permissões de acesso",
			'groups:owner' => "Proprietário",
			'groups:widget:num_display' => 'Número de grupos a serem exibidos',
			'groups:widget:membership' => 'Participar do grupo',
			'groups:widgets:description' => 'Exibir em seu perfil os grupos dos quais você participa',
			'groups:noaccess' => 'Sem acesso ao grupo',
			'groups:cantedit' => 'Você não pode editar este grupo',
			'groups:saved' => 'Grupo salvo',
			'groups:featured' => 'Grupos em destaque',
			'groups:makeunfeatured' => 'Sem destaques',
			'groups:makefeatured' => 'Destacar',
			'groups:featuredon' => 'Você destacou este grupo.',
			'groups:unfeature' => 'Você apagou este grupo da lista de destaques',
			'groups:joinrequest' => 'Solicitar inclusão como membro',
			'groups:join' => 'Participar deste grupo',
			'groups:leave' => 'Sair do grupo',
			'groups:invite' => 'Convidar amigos',
			'groups:inviteto' => "Convidar amigos para '%s'",
			'groups:nofriends' => "Você não possui amigos que ainda não tenham sido convidados para este grupo.",
			'groups:viagroups' => "via grupos",
			'groups:group' => "Grupo",
			'groups:search:tags' => "tag",

			'groups:notfound' => "Grupo não encontrado",
			'groups:notfound:details' => "Ou o grupo procurado não existe, ou você não possui permissão de acesso a ele.",

			'groups:requests:none' => 'Não existem solicitações de participação neste momento.',

			'groups:invitations:none' => 'Não existem convites neste momento.',

			'item:object:groupforumtopic' => "Tópicos de debate",

			'groupforumtopic:new' => "Nova mensagem de discussão",

			'groups:count' => "Grupos criados",
			'groups:open' => "grupo aberto",
			'groups:closed' => "grupo fechado",
			'groups:member' => "membros",
			'groups:searchtag' => "Pesquisar grupos por tag",


			/*
			 * Access
			 */
			'groups:access:private' => 'Fechado - usuário deve ser convidado',
			'groups:access:public' => 'Aberto - Qualquer usuário pode participar',
			'groups:closedgroup' => 'Este grupo possui participação fechada. Para solicitar sua inclusão, clique em "solicitar inclusão como membro".',
			'groups:visibility' => 'Quem pode visualizar este grupo?',

			/*
			Group tools
			*/
			'groups:enablepages' => 'Habilitar páginas wiki no grupo',
			'groups:enableforum' => 'Habilitar discussões no grupo',
			'groups:enablefiles' => 'Habilitar arquivos no grupo',
			'groups:yes' => 'sim',
			'groups:no' => 'não',

			'group:created' => 'Criado %s com %d mensagens enviadas',
			'groups:lastupdated' => 'Última atualização %s por %s',
			'groups:pages' => 'Páginas wiki do grupo',
			'groups:files' => 'Arquivos do grupo',

			/*
			Group forum strings
			*/

			'group:replies' => 'Respostas',
			'groups:forum' => 'Discussão do grupo',
			'groups:addtopic' => 'Adicionar tópico',
			'groups:forumlatest' => 'Última discussão',
			'groups:latestdiscussion' => 'Última discussão',
			'groups:newest' => 'Mais novo',
			'groups:popular' => 'Mais popular',
			'groupspost:success' => 'Seu comentário foi enviado com sucesso.',
			'groups:alldiscussion' => 'Última discussão',
			'groups:edittopic' => 'Editar tópico',
			'groups:topicmessage' => 'Mensagem do tópico',
			'groups:topicstatus' => 'Situação do tópico',
			'groups:reply' => 'Enviar um comentário',
			'groups:topic' => 'Tópico',
			'groups:posts' => 'Mensagens',
			'groups:lastperson' => 'Última pessoa',
			'groups:when' => 'Quando',
			'grouptopic:notcreated' => 'Nenhum tópico foi criado.',
			'groups:topicopen' => 'Aberto',
			'groups:topicclosed' => 'Fechado',
			'groups:topicresolved' => 'Resolvido',
			'grouptopic:created' => 'Seu tópico foi criado.',
			'groupstopic:deleted' => 'O tópico foi apagado.',
			'groups:topicsticky' => 'Adesivo',
			'groups:topicisclosed' => 'Este tópico está fechado.',
			'groups:topiccloseddesc' => 'Este tópico agora está fechado e não aceita novos comentários.',
			'grouptopic:error' => 'Não foi possível criar o tópico em seu grupo. Por favor, tente novamente ou entre em contato com o administrador da comunidade.',
			'groups:forumpost:edited' => "Você editou com sucesso a mensagem deste fórum.",
			'groups:forumpost:error' => "Houve um problema ao editar a mensagem deste fórum.",
			'groups:privategroup' => 'Este grupo é fechado, solicite ao moderador sua participação.',
			'groups:notitle' => 'Grupos devem ter um título',
			'groups:cantjoin' => 'Não foi possível participar o grupo',
			'groups:cantleave' => 'Não foi possível deixar o grupo',
			'groups:addedtogroup' => 'Usuário adicionado com sucesso ao grupo',
			'groups:joinrequestnotmade' => 'Não foi possível solicitar a participação no grupo',
			'groups:joinrequestmade' => 'Foi solicitada a entrada no grupo',
			'groups:joined' => 'Participação no grupo realizada com sucesso!',
			'groups:left' => 'Você deixou o grupo com sucesso!',
			'groups:notowner' => 'Você não é o proprietário deste grupo.',
			'groups:notmember' => 'Você não é membro deste grupo.',
			'groups:alreadymember' => 'Você já faz parte deste grupo!',
			'groups:userinvited' => 'Convite enviado com sucesso.',
			'groups:usernotinvited' => 'O convite não pôde ser enviado.',
			'groups:useralreadyinvited' => 'Este usuário já foi convidado para participar deste grupo',
			'groups:updated' => "Último comentário",
			'groups:invite:subject' => "%s você foi convidado a entrar no grupo %s!",
			'groups:started' => "Iniciado por",
			'groups:joinrequest:remove:check' => 'Você tem certeza de que deseja apagar esta solicitação de participação?',
			'groups:invite:body' => "Olá %s,

%s convidou você para participar do grupo '%s', clique abaixo para confirmar:

%s",

			'groups:welcome:subject' => "Seja bem vindo ao grupo %s!",
			'groups:welcome:body' => "Olá %s!

Agora você é membro do grupo '%s'! Clique abaixo para começar a enviar mensagens!

%s",

			'groups:request:subject' => "%s solicitou a participação no grupo %s",
			'groups:request:body' => "Olá %s,

%s solicitou a participação no grupo '%s', clique abaixo para ver seu perfil:

%s

ou clique abaixo para aceitar o pedido:

%s",

			/*
				Forum river items
			*/

			'groups:river:member' => 'agora é membro de',
			'groupforum:river:updated' => '%s foi atualizado',
			'groupforum:river:update' => 'este tópico de discussão',
			'groupforum:river:created' => '%s foi criado',
			'groupforum:river:create' => 'um novo tópico de discussão com título',
			'groupforum:river:posted' => '%s enviou um novo comentário',
			'groupforum:river:annotate:create' => 'neste tópico de discussão',
			'groupforum:river:postedtopic' => '%s iniciou um novo tópico de discussão com título',
			'groups:river:member' => '%s agora é membro de',
			'groups:river:togroup' => 'para o grupo',

			'groups:nowidgets' => 'Nenhum dispositivo foi definido para este grupo.',


			'groups:widgets:members:title' => 'Membros do grupo',
			'groups:widgets:members:description' => 'Listar os membros de um grupo.',
			'groups:widgets:members:label:displaynum' => 'Listar os membros de um grupo.',
			'groups:widgets:members:label:pleaseedit' => 'Por favor, configure este dispositivo.',

			'groups:widgets:entities:title' => "Objetos no grupo",
			'groups:widgets:entities:description' => "Listar os objetos salvos neste grupo",
			'groups:widgets:entities:label:displaynum' => 'Listar os objetos de um grupo.',
			'groups:widgets:entities:label:pleaseedit' => 'Por favor, configure este dispositivo.',

			'groups:forumtopic:edited' => 'Tópico do fórum editado com sucesso.',

			'groups:allowhiddengroups' => 'Você deseja permitir grupos privados (invisíveis)?',

			/**
			 * Action messages
			 */
			'group:deleted' => 'O grupo e todo seu conteúdo foram apagados com sucesso.',
			'group:notdeleted' => 'Não foi possível apagar o grupo',

			'grouppost:deleted' => 'Mensagem no grupo apagada com sucesso.',
			'grouppost:notdeleted' => 'Não foi possível apagar a mensagem do grupo.',
			'groupstopic:deleted' => 'Tópico apagado com sucesso',
			'groupstopic:notdeleted' => 'Não foi possível apagar o tópico',
			'grouptopic:blank' => 'Sem tópicos',
			'grouptopic:notfound' => 'Não foi possível encontrar o tópico',
			'grouppost:nopost' => 'Mensagem vazia',
			'groups:deletewarning' => "Você tem certeza de que deseja apagar este grupo? Não será possível desfazer esta ação!",

			'groups:joinrequestkilled' => 'O pedido de participação foi apagado.',
	);

	add_translation("en",$english);
	add_translation("pt_br",$portugues_brasileiro);
?>
