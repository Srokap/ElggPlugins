<?php
	/**
	 * Email user validation plugin language pack.
	 *
	 * @package ElggUserValidationByEmail
	 * @author DiRaOL - diraol@diraol.eng.br
	 * @link http://blog.diraol.eng.br
	 * @published 14 March 2010
	 */

	$portugues_brasileiro = array(

		'email:validate:subject' => "%s por favor, confirme seu endereço de email!",
		'email:validate:body' => "Olá %s,

Por favor, confirme seu endereço de email clicando no link abaixo:

%s
",
		'email:validate:success:subject' => "Email validado %s!",
		'email:validate:success:body' => "Olá %s,

Parabéns, seu endereço de email foi validado com sucesso.",


		'email:confirm:success' => "Você já confirmou seu endereço de email!",
		'email:confirm:fail' => "Seu endereço de email não pôde ser confirmado.",

		'uservalidationbyemail:registerok' => "Para ativar sua conta, por favor confirme seu endereço de email clicando no link que foi enviado para endereço de email que você registrou."

	);

	add_translation("en",$english);
	add_translation("pt_br",$portugues_brasileiro);
?>
