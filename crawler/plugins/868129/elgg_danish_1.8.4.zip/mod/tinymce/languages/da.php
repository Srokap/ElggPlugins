<?php
/**
 * TinyMCE Danish language file
 *
 */

$danish = array(	
	'tinymce:remove' => "Fjern editor",
	'tinymce:add' => "Tilføj editor",
	'tinymce:word_count' => 'Ord tæller: ',	
);
				
add_translation('da',$danish);

?>