<?php
/**
 * Search Danish language file
 *
 */

$danish = array(
	'search:enter_term' => 'Indtast et søgeord:',
	'search:no_results' => 'Ingen resultater...',
	'search:matched' => 'Match: ',
	'search:results' => 'Resultater for %s',
	'search:no_query' => 'Vær venlig at indtaste noget at søge efter.',
	'search:search_error' => 'Fejl',

	'search:more' => '+%s flere %s',

	'search_types:tags' => 'Tags',

	'search_types:comments' => 'Kommentarer',
	'search:comment_on' => 'Kommentér "%s"',
	'search:comment_by' => 'af',
	'search:unavailable_entity' => 'Utilgængelig søgeterm',
);

add_translation("da",$danish);

?>