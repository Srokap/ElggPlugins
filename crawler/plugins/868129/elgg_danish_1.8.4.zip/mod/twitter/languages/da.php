<?php
/**
 * Twitter widget Danish language file
 */

$danish = array(

	'twitter:title' => 'Twitter',
	'twitter:info' => 'Vis dine seneste tweets',	
	'twitter:username' => 'Skriv dit twitter brugernavn.',
	'twitter:num' => 'Antal tweets du vil vise.',
	'twitter:visit' => 'Besøg mig på twitter',
	'twitter:notset' => 'Denne twitter widget er ikke indstillet endnu. Klik på \'rediger\' og udfyld dine detaljer, for at vise dine seneste tweets.',
	
);
				
add_translation('da',$danish);

?>