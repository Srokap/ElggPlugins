<?php

	$english = array(
/*	
			'walltowall:walllink' => "wall to wall",	
			'walltowall:title' => "Wall to Wall",	
			'walltowall:heading' => "%s Wall to Wall with %s",
      'walltowall:me' => "me",	
      'walltowall:my' => "My",
      'walltowall:possessive' => "'s",
      'walltowall:replyon' => "reply on",
      'walltowall:board' => "board",
*/
			'walltowall:walllink' => "full conversation",	
			'walltowall:title' => "Conversation",	
			'walltowall:heading' => "%s Conversation with %s",
      'walltowall:me' => "me",	
      'walltowall:my' => "My",
      'walltowall:possessive' => "'s",
      'walltowall:replyon' => "reply on",
      'walltowall:board' => "scrapbook",

	);
					
	add_translation("en",$english);

?>
