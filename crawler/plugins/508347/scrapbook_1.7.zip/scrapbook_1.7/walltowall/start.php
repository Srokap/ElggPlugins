<?php
  global $CONFIG;
   
  register_action("walltowall/add", false, $CONFIG->pluginspath . "walltowall/actions/add.php");    
  register_action("walltowall/reply", false, $CONFIG->pluginspath . "walltowall/actions/reply.php");
?>
