﻿<?php
/**
 * TinyMCE language pack.
 *
 * @package ElggTinyMCE
 */

$finnish = array(
	'tinymce:remove' => "Poista Editori",
	'tinymce:add' => "Lisää Editori",
	'tinymce:word_count' => 'Sanalaskuri: ',
);

add_translation("fi", $finnish);