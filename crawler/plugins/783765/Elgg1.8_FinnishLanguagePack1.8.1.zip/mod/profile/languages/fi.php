﻿<?php
/**
 * Elgg profile plugin language pack
 */

$finnish = array(
	'profile' => 'Profiili',
	'profile:notfound' => 'emme löytäneet etsimääsi profiilia.',

);

add_translation('fi', $finnish);