﻿<?php
/**
 * Tag cloud Finnish language file
 */

$finnish = array(
	'tagcloud:widget:title' => 'Tagi Pilvi',
	'tagcloud:widget:description' => 'Tagi Pilvi',
	'tagcloud:widget:numtags' => 'Tagien määrä, jotka näytetään',
);

add_translation('fi', $finnish);
