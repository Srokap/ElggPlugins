Hello!

this is the finnish language file for elgg 1.8 Core. the place where you downloaded this, will be updated with the basic plugins also translated to finnish, so keep checking there ;)



Hei!

T�m� on suomenkielen kielitiedosto elgg 1.8 ytimelle. paikka mist� latasit t�m�n, p�ivitet��n my�hemmin ja siihen lis�t��n suomenkielen tiedostot kaikille perusliit�nn�isille. k�ypp� katselemassa siell� aina v�lill� jahka sellainen uusi paketti olisi lis�tty ;)









Best Regards/Terveisin,

Jushi85, your elggfanatic!

