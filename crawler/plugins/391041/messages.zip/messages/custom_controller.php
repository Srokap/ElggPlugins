<?
include(dirname(__FILE__) . "/controller.php");

class CustomController extends Controller {
	public function run($page) {
		parent::run($page);
	}


	protected function run_read($page) {
		parent::run_read($page);
	}


	protected function run_sent($page) {	
		parent::run_sent($page);
	}


	protected function run_send($page) {
		parent::run_send($page);
		
		// Extending page
		$this->area2 .= "<p>Sending a message to my friend</p>";
		$this->body = elgg_view_layout("two_column_left_sidebar", '', $this->area2);
	}


	protected function run_menu($page) {
		parent::run_menu($page);
		
		// Extending menu
		if (get_context() == "messages") {
			global $CONFIG;
			add_submenu_item("My page menu", $CONFIG->wwwroot . "pg/messages/", "messages_links");
		}
	}

}
?>