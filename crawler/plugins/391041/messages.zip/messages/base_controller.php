<?
abstract class BaseController {
	protected $page_owner = '';
	protected $title = '';
	protected $body = '';
	protected $draw = false;
	
	protected $area1 = '';
	protected $area2 = '';
	protected $area3 = '';
	
	
	public function __construct() {
		// Load Elgg engine
		require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
		
		// If we're not logged in, forward to the front page
		if (!isloggedin()) forward(); 
		
		// Get the logged in user
		$this->page_owner = $_SESSION['user'];
		set_page_owner($this->page_owner->guid);
	}
	
	
	public function run($page) {
		if ($this->draw) {
			page_draw($this->title, $this->body);
			return true;
		} else {
			return false;
		}
	}
	
}
?>