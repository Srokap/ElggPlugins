<?
require_once(dirname(__FILE__) . "/base_controller.php");

class Controller extends BaseController {
	protected	$username;
	
	
	public function __construct() {
		parent::__construct();
	}
	
	/**
	 * Main function run
	 *
	 * @param array $page
	 */	
	public function run($page) {
		$this->run_menu($page);
		if (isset($page[0])) {
			$this->username = $page[0];
			
			if (isset($page[1])) {
				switch($page[1]) {
					case "read":		
						$this->run_read($page);
						break;
					case "sent":
						$this->run_sent($page);
						break;
					case "send":
						$this->run_send($page);
						break;
				}
			} else {
				$this->run_inbox($page);
			}
		} else {
			$this->run_inbox($page);
		}
		
		parent::run($page);
	}


	/**
	 * run_inbox
	 *
	 * @param array $page
	 */	
	protected function run_inbox($page) {
		// Get offset
		$offset = get_input('offset',0);
		
		// Set limit
		$limit = 10;
		
		// Get the user's inbox, this will be all messages where the 'toId' field matches their guid 
		$messages = get_entities_from_metadata("toId", $this->page_owner->getGUID(), "object", "messages", $this->page_owner->guid, $limit + 1, $offset);
		
		// Set the page title
		$this->area2 = elgg_view_title(elgg_echo("messages:inbox"));
		
		// Display them. The last variable 'page_view' is to allow the view page to know where this data is coming from,
		// in this case it is the inbox, this is necessary to ensure the correct display
		$this->area2 .= elgg_view("messages/forms/view",array('entity' => $messages, 'page_view' => "inbox", 'limit' => $limit, 'offset' => $offset));
		
		$this->title = elgg_echo('messages:user');
		$this->body = elgg_view_layout("two_column_left_sidebar", '', $this->area2);
		$this->draw = true;
	}
	
	
	/**
	 * run_read
	 *
	 * @param array $page
	 */	
	protected function run_read($page) {
		$message_id = $page[2];
		$type = (isset($page[3])) ? $page[3] : '';
		
		// Get the full message object to read
		$message = get_entity($message_id);
			
		// If the message is being read from the inbox, mark it as read, otherwise don't.
		// This stops a user who checks out a message they have sent having it being marked as read for the recipient
		if ($type != "sent"){
			// Mark the message as being read now
			if ($message->getSubtype() == "messages") {
				//set the message metadata to 1 which equals read
				$message->readYet = 1;
			}
		}
				
		// Display it
		$this->area2 = elgg_view("messages/messages", array('entity' => $message, 'entity_owner' => $this->page_owner, 'full' => true));

		$this->title = sprintf(elgg_echo('messages:message'));
		$this->body = elgg_view_layout("two_column_left_sidebar", '', $this->area2);
		$this->draw = true;
	}


	/**
	 * run_sent
	 *
	 * @param array $page
	 */	
	protected function run_sent($page) {	
		// Get offset
		$offset = get_input('offset',0);
		
		// Set limit
		$limit = 10;
		
		// Display all the messages a user owns, these will make up the sentbox
		$messages = get_entities_from_metadata('fromId',$_SESSION['user']->guid,'object','messages', $this->page_owner->guid, $limit, $offset); 
		
		// Set the page title
		$this->area2 = elgg_view_title(elgg_echo("messages:sentmessages"));
		
		// Set content
		$this->area2 .= elgg_view("messages/forms/view",array('entity' => $messages, 'page_view' => "sent", 'limit' => $limit, 'offset' => $offset));
		
		$this->title = elgg_echo('messages:sentMessages');
		$this->body = elgg_view_layout("two_column_left_sidebar", '', $this->area2);
		$this->draw = true;
	}


	/**
	 * run_send
	 *
	 * @param array $page
	 */	
	protected function run_send($page) {
		// Get the users friends; this is used in the drop down to select who to send the message to
		$friends = $_SESSION['user']->getFriends('', 9999);
				
		// Set the page title
		$this->area2 = elgg_view_title(elgg_echo("messages:sendmessage"));
				
		// Get the send form
		$this->area2 .= elgg_view("messages/forms/message", array('friends' => $friends));
		
		$this->title = elgg_echo('messages:send');
		$this->body = elgg_view_layout("two_column_left_sidebar", '', $this->area2);
		$this->draw = true;
	}


	/**
	 * run_menu
	 */	
	protected function run_menu() {
		if (get_context() == "messages") {
			global $CONFIG;
			add_submenu_item(elgg_echo('messages:sendmessage'), 
					$CONFIG->wwwroot . "pg/messages/" . $_SESSION['user']->username . "/send", 'messages_actions');
			add_submenu_item(elgg_echo('messages:inbox'), 
					$CONFIG->wwwroot . "pg/messages/" . $_SESSION['user']->username, 'messages_links');
			add_submenu_item(elgg_echo('messages:sentmessages'), 
					$CONFIG->wwwroot . "pg/messages/" . $_SESSION['user']->username . "/sent", 'messages_links');
		}
	}

}
?>