<?php
	    /**
	     * Elgg Radius authentication
	     *
	     * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	     * @author M.R.A. Welkers (m.r.a.welkers@amc.uva.nl)
	     * @link http://synaps.amc.nl/pg/profile/mrwelkers
	     */
	
	    require_once('radius.class.php');

	     function radius_auth_init()
	    {
	        global $CONFIG;
	
	        // Register the authentication handler
	        register_pam_handler('radius_auth_authenticate');

	    }

	
	    // Register the initialisation function
	    register_elgg_event_handler('init','system','radius_auth_init');
    
	    function radius_auth_authenticate($credentials = null)
	    {
          		
	        // Get configuration settings
		  $config_radius = find_plugin_settings('radius_auth');
	        // Nothing to do if not configured
		  if (!$config_radius)
		  {
	           	return false;
	        }
		  
              $radiusip = $config_radius->radius_ip;
	        // No point continuing
	        if(empty($radiusip))
	        {
	            error_log("Radius error: no Radius server configured.");
	            return;
	        }
	
	        $authenticationport = $config_radius->radius_authenticationport;
	        // No point continuing
	        if(empty($authenticationport))
	        {
	            error_log("Radius error: no Radius authentication port configured.");
	            return;
	        }

	        $accountingport        = $config_radius->radius_accountingport;
	        // No point continuing
	        if(empty($accountingport))
	        {
	            error_log("Radius error: no Radius accounting port configured.");
	            return;
	        }
		  
		  $sharedsecret     = $config_radius->radius_sharedsecret;
	        // No point continuing
	        if(empty($sharedsecret))
	        {
	            error_log("Radius error: no shared secret entered.");
	            return;
	        }
	

	        $username      = null;
	        $password      = null;
	

	        if (is_array($credentials) && ($credentials['username']) && ($credentials['password']))
	        {
	            $username = utf8_encode($credentials['username']);
	            $password = utf8_encode(html_entity_decode($credentials['password']));
	        }

	        ($user_create == 'on') ? $user_create = true : $user_create = false;

	        // Create a connection
	  	if($radius = new Radius($radiusip, $sharedsecret, '',  5, $authenticationport, $accountingport));
			{            
		            if ($radius->AccessRequest($username,$password))   
           			            {
				     		//The user credentials are ok, see if this user logged in before
							if ($user = get_user_by_username($username))
	                   					 {
		                       			 // User exists, login
		                        		return login($user);
				                 			 }
							else
									{
								//Guess not, then we should make you a user
								register_error(elgg_echo("You have not logged in before, please register first."));
								forward('account/register.php?u='.$username);									
									}
            			
						}
					else
					   		{
						//There is a connection but the username and/or password is wrong
						register_error(elgg_echo("Wrong username and/or password. Please contact the ICT department."));
						//forward();
						forward('account/register.php?u='.$username);	
	                   		  	 }
						
			}
	}
?>
	
