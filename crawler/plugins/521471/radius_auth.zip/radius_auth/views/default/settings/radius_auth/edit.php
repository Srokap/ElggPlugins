<?php
	    /**
	         * Elgg Radius authentication
	         *
	         * @package ElggRadiusAuth
	         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	         * @author M.R.A. Welkers (m.r.a.welkers@amc.uva.nl)
	         * @link http://synaps.amc.nl/pg/profile/mrwelkers
	         */
	?>
	<p>
	    <fieldset style="border: 1px solid; padding: 15px; margin: 0 10px 0 10px">
	        <legend><?php echo elgg_echo('radius_auth:settings:label');?></legend>
	        
	        <label for="params[radius_ip]"><?php echo elgg_echo('radius_auth:settings:label:radius_ip');?></label><br/>
	        <input type="text" size="50" name="params[radius_ip]" value="<?php echo $vars['entity']->radius_ip;?>"/><br/>

	        <label for="params[radius_authenticationport]"><?php echo elgg_echo('radius_auth:settings:label:radius_authenticationport');?></label><br/>
	        <input type="text" size="10" name="params[radius_authenticationport]" value="<?php echo $vars['entity']->radius_authenticationport;?>"/><br/>

	        <label for="params[radius_accountingport]"><?php echo elgg_echo('radius_auth:settings:label:radius_accountingport');?></label><br/>
	        <input type="text" size="10" name="params[radius_accountingport]" value="<?php echo $vars['entity']->radius_accountingport;?>"/><br/>

	        <label for="params[radius_sharedsecret]"><?php echo elgg_echo('radius_auth:settings:label:radius_sharedsecret');?></label><br/>
	        <input type="password" size="50" name="params[radius_sharedsecret]" value="<?php echo $vars['entity']->radius_sharedsecret;?>"/><br/>

	    </fieldset>
	</p>
