<?php
	
	    /**
	     * Elgg Radius authentication
	     *
	     * @package ElggRadiusAuth
	     * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	     * @author M.R.A. Welkers
	     * @link http://synaps.amc.nl/pg/profile/mrwelkers
     */
	
		    $en = array(
	        'radius_auth:settings:label' => "Settings for a Radius authentication ",
	        'radius_auth:settings:label:radius_ip' => "Radius server IP",
	        'radius_auth:settings:label:radius_authenticationport' => "The radius server authentication port",
	        'radius_auth:settings:label:radius_accountingport' => "The radius server accounting port",
		  'radius_auth:settings:label:radius_sharedsecret' => "Shared secret",
	        'radius_auth:no_account' => "Your credentials are valid, but no account was found - please contact the system administrator",
	        'radius_auth:no_register' => 'An account could not get created for you - please contact the system administrator.'
	    );
	
	    add_translation('en', $en);
	?>