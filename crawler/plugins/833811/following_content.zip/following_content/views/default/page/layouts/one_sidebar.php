<HEAD>
 <style type="text/css">
  #followingcontent {
  position: fixed;
  right: 0%;
  left: 85%;
  top: 40%;
  width: 8em;
  margin-top: -2.5em;
}
  </style>
</head>
<?php
$class = 'elgg-layout elgg-layout-one-sidebar clearfix';
if (isset($vars['class'])) {
	$class = "$class {$vars['class']}";
}

// navigation defaults to breadcrumbs
$nav = elgg_extract('nav', $vars, elgg_view('navigation/breadcrumbs'));

?>

<div class="<?php echo $class; ?>">
	<div class="elgg-sidebar">
		<?php
			echo elgg_view('page/elements/sidebar', $vars);
		if ((elgg_get_context() == 'activity'))  {
		?>
		     

		

      

     

		<?php
		}
		?>
	</div>

	<div class="elgg-main elgg-body">
		<?php
			echo $nav;
			
			if (isset($vars['title'])) {
				echo elgg_view_title($vars['title']);
			}
			// @todo deprecated so remove in Elgg 2.0
			if (isset($vars['area1'])) {
				echo $vars['area1'];
			}
			if (isset($vars['content'])) {
				echo $vars['content'];
			}
		?>
		
	</div>
</div>
<div id="followingcontent">
<font size="30">Scrolling Text... Edit this at <br> mod/social_dashboard/views/default/page/layouts/<br>one_sidebar.php. on line 62.
<img src="http://www.linkorangutan.com/wp-content/themes/thesis_16/custom-sample/rotator/sample-4.jpg" width="100" height="100">
</div>

