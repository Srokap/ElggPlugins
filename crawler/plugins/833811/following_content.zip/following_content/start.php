<?php
function followingcontent_init() {
}
 
register_elgg_event_handler('init', 'system', 'followingcontent_init');
?>