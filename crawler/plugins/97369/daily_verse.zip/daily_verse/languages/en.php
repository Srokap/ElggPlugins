<?php
 
  $english = array(	
      'dailyverse:id' => 'Translation',
      'dailyverse:title' => 'Daily Bible Verse',	
      'dailyverse:widget_name' => 'Daily Bible Verse',
      'dailyverse:description' => 'This widget allows you to have a daily bible verse, powered by BibleGateway, on your profile',
	);
 
  add_translation("en",$english);
 
?>
