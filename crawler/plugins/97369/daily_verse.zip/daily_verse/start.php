<?php
     	/**
         * Daily Verse
         *
         * @package DailyVerse
         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author Lawrence L. Stockman III
         * @copyright Social Believers 2009
         * @link http://SocialBelievers.com
         */

	/**
         * Initialise the pages plugin.
         *
         */


  function dailyverse_init() {        
    add_widget_type('dailyverse', elgg_echo('dailyverse:widget_name'), elgg_echo('dailyverse:description'));
  }
 
  register_elgg_event_handler('init','system','dailyverse_init');       
?>
