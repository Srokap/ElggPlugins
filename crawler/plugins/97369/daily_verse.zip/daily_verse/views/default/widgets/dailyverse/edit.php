<p>
<?php 

/* VOTD List: http://www.biblegateway.com/usage/linking/votdlist.php */






echo elgg_echo("dailyverse:id"); ?>
<select name="params[versetranslation]">
<option value="" name"language">---------- English (EN) ----------</option>
<option value="8" name="ASV" <?php if ($vars['entity']->versetranslation == 8) echo " selected=\"yes\" "; ?>>American Standard Version</option>
<option value="45" name="AB" <?php if ($vars['entity']->versetranslation == 45) echo " selected=\"yes\" "; ?>>Amplified Bible</option>
<option value="16" name="DB" <?php if ($vars['entity']->versetranslation == 16) echo " selected=\"yes\" "; ?>>Darby Bible</option>
<option value="47" name="ESV" <?php if ($vars['entity']->versetranslation == 47) echo " selected=\"yes\" "; ?>>English Standard Version</option>
<option value="9" name="KJV" <?php if ($vars['entity']->versetranslation == 9) echo " selected=\"yes\" "; ?>>King James Version</option>
<option value="31" name="NIV" <?php if ($vars['entity']->versetranslation == 31) echo " selected=\"yes\" "; ?>>New International Version</option>
<option value="49" name="NASV" <?php if ($vars['entity']->versetranslation == 48) echo " selected=\"yes\" "; ?>>New American Standard Version</option>
<option value="76" name="NIRV" <?php if ($vars['entity']->versetranslation == 76) echo " selected=\"yes\" "; ?>>New International Reader's Version</option>
<option value="64" name="NIV-UK" <?php if ($vars['entity']->versetranslation == 64) echo " selected=\"yes\" "; ?>>New International Version - UK</option>
<option value="72" name="ASV" <?php if ($vars['entity']->versetranslation == 72) echo " selected=\"yes\" "; ?>>Today's New International Version</option>
<option value="15" name="YLT" <?php if ($vars['entity']->versetranslation == 15) echo " selected=\"yes\" "; ?>>Young's Literal Translation</option>

<option value="" name"language">---------- Espa&ntilde;ol (ES) ----------</option>
<option value="41" name="CAS" <?php if ($vars['entity']->versetranslation == 41) echo " selected=\"yes\" "; ?>>Castilian</option>
<option value="59" name="LBLA" <?php if ($vars['entity']->versetranslation == 59) echo " selected=\"yes\" "; ?>>La Biblia de las Am&eacute;ricas</option>
<option value="42" name="NVI" <?php if ($vars['entity']->versetranslation == 42) echo " selected=\"yes\" "; ?>>Nueva Versi&oacute;n Internacional</option>
<option value="6" name="RVA" <?php if ($vars['entity']->versetranslation == 6) echo " selected=\"yes\" "; ?>>Reina-Valera Antigua</option>

<option value="" name"language">---------- Fran&ccedil;ais (FR) ----------</option>
<option value="32" name="CAS" <?php if ($vars['entity']->versetranslation == 32) echo " selected=\"yes\" "; ?>>La Bible du Semeur</option>
<option value="2" name="LBLA" <?php if ($vars['entity']->versetranslation == 2) echo " selected=\"yes\" "; ?>>Louis Segond</option>

<option value="" name"language">---------- Deutsch (DE) ----------</option>
<option value="33" name="HFA" <?php if ($vars['entity']->versetranslation == 33) echo " selected=\"yes\" "; ?>>Hoffnung f&uuml;r Alle</option>
<option value="10" name="LB1545" <?php if ($vars['entity']->versetranslation == 10) echo " selected=\"yes\" "; ?>>Luther Bibel 1545</option>

</select>
</p>
 
    <p><?php echo elgg_echo("dailyverse:description"); ?></p>
