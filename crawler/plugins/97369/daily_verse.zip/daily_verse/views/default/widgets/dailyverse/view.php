<?

/* Version information for all Bible transalations can be found here: */
/* http://www.biblegateway.com/usage/linking/versionslist.php         */

/* NIV - ID 31 */
$feeder = "http://www.biblegateway.com/usage/votd/rss/votd.rdf?".$vars['entity']->versetranslation;
$feed = simplexml_load_file($feeder);
$content = $feed->channel->item->children('http://purl.org/rss/1.0/modules/content/');
$verse = $feed->channel->item->title;
echo "<div class=\"contentWrapper\">";
echo "<B>".$verse."</B><BR/>";
echo $content;
echo "</div>";
?>

