<?php
// English language file
$english = array(
		'widget:avatar' => "Avatar",
		'widget:avatar:description' => "Displays your avatar",
		'widget:profilemenu' => "Profile menu",
		'widget:profilemenu:description' => "Displays your profile menu.",
		'widget:details' => "Details",
		'widget:details:description' => "Displays the profile details you fill out.",
		'widget:status' => "Status",
		'widget:status:description' => "Displays your current wire post.",

);
add_translation("en", $english);

