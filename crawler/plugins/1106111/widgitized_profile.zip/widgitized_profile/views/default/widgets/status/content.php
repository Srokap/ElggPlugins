<?php
echo elgg_view("profile/status", array("entity" => $user));
?>