<?php
// Nothing is here because widgets would be in this area.
?>
