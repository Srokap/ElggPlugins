<?php

$english = array(
  'phloor_menu_sooperfish_theme_theme5:theme5' => 'Theme 5'
);
	
add_translation("en", $english);
