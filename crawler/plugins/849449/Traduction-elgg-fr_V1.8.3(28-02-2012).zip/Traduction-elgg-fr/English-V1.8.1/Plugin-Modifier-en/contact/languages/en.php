<?php
/**
 * Categories English language file
 */

$english = array(
	'contact:contactus' => "Contact Us!",
	'contact:head_message' => "</br>We wanna hear your feedback! </br></br> Let us know through our contact form!! </br></br>",
	'contact:contactform:contactus' => "Contact Us!",
	'contact:contactform:contactus_legend' => "Contact us",
	'contact:contactform:required_fields' => "* required fields",
	'contact:contactform:full_name' => "Your Full Name*: ",
	'contact:contactform:email_address' => "Email Address*:",
	'contact:contactform:phone_number' => "Phone Number:",
	'contact:contactform:message' => "Message:",
	'contact:contactform:anti-spam' => "Anti-spam question",
	'contact:contactform:simple_question_below' => "(Please answer the simple question below. This to prevent spam bots from submitting this form)",
	'contact:contactform:submit' => "Submit",
	'contact:thank_you_title' => "Thank you!",
	'contact:thank_you_message' => "Thanks for contacting us!",
	
	'contact:control_name' => "Please provide your name",
	'contact:control_email' => "Please provide your email address",
	'contact:control_email_valid' => "Please provide a valid email address",
	'contact:control_message' => "The message is too long!(more than 2KB!)",
	'contact:control_scaptcha' => "Please answer the anti-spam question",
	
	'contact:ask1' => "What color is the sky? ",
	'contact:answer1' => "blue",
	'contact:ask12' => "What is 1+1=",
	'contact:answer2' => "2",
	'contact:ask3' => "What is the color of grass?",
	'contact:answer3' => "green",
	'contact:ask4' => "Are you a robot? ",
	'contact:answer4' => "no",
	'contact:ask5' => "Are you human?",
	'contact:answer5' => "yes",
	'contact:antispam_question' => "Please answer the anti-spam question",
	'contact:antispam_ckeck' => "Failed the anti-spam check!",
);

add_translation("en", $english);
?>