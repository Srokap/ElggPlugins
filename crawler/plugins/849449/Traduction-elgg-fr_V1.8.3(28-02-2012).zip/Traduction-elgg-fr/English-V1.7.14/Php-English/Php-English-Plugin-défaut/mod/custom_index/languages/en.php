<?php

	$english = array(
	
			'custom:bookmarks' => "Latest bookmarks",
			'custom:groups' => "Latest groups",
			'custom:files' => "Latest files",
			'custom:blogs' => "Latest blog posts",
			'custom:members' => "Newest members",
			'custom:nofiles' => "There are no files yet",
			'custom:nogroups' => "There are no groups yet",
	
	);
					
	add_translation("en",$english);

?>