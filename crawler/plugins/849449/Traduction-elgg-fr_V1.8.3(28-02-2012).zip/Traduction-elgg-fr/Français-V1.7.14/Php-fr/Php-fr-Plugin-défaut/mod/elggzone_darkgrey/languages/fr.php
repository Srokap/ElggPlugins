<?php

$french = array(

	'elggzone:sig'						=> 'l\'équipe', 
	'elggzone_darkgrey:pagetitle'		=> 'Bienvenu sur mon site',
	'elggzone_darkgrey:copyright'       => 'Elggzone &copy; 2011',
	'elggzone_darkgrey:link'       		=> 'http://www.perjensen-online.dk',

	// topbar
	'elggzone_darkgrey:mygroups'		=> 'Groupes',
	'elggzone_darkgrey:myfriends'		=> 'Amis',
	
	// register form
	'elggzone_darkgrey:welcome'			=> 'Bienvenu',
	'elggzone_darkgrey:welcome_text'	=> 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce quis lectus quis sem lacinia nonummy. Proin mollis lorem non dolor. In hac habitasse platea dictumst. Nulla ultrices odio. Donec augue. Phasellus dui. Maecenas facilisis nisl vitae nibh. Proin vel est vitae eros pretium dignissim. Aliquam aliquam sodales orci. Suspendisse potenti. Nunc adipiscing euismod arcu. Quisque facilisis mattis lacus. Fusce bibendum, velit in venenatis viverra, tellus ligula dignissim felis, quis euismod mauris tellus ut urna.',
		
);

add_translation("fr", $french);
