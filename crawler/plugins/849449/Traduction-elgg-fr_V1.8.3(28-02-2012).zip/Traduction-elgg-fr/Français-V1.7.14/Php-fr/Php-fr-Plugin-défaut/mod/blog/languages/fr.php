<?php

	/**
	 * Traduction Française 1.5 Florian Daniel http://id.facyla.net/
	 * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
	 */

	$french = array(

		/**
		 * Menu items and titles
		 */

			'blog' => "Blog",
			'blogs' => "Blogs",
			'blog:user' => "Le blog de %s",
			'blog:user:friends' => "Le blog des contacts de %s",
			'blog:your' => "Votre blog",
			'blog:posttitle' => "Le blog de %s: %s",
			'blog:friends' => "Blogs des contacts",
			'blog:yourfriends' => "Les blogs les plus récents de vos contacts",
			'blog:everyone' => "Tous les blogs du site",
			'blog:newpost' => "Nouvel article de blog",
			'blog:via' => "via le blog",
			'blog:read' => "Lire le blog",

			'blog:addpost' => "Ecrire un article de blog",
			'blog:editpost' => "Editer un article de blog",

			'blog:text' => "Texte du blog",

			'blog:strapline' => "%s",

			'item:object:blog' => 'Articles du blog',

			'blog:never' => 'jamais',
			'blog:preview' => 'Aperçu',

			'blog:draft:save' => 'Enregistrer le brouillon',
			'blog:draft:saved' => 'Dernier brouillon enregistré',
			'blog:comments:allow' => 'Autoriser les commentaires',
			'blog:conversation' => 'Conversation',

			'blog:preview:description' => 'Ceci est un aperçu non enregistré de votre article de blog.',
			'blog:preview:description:link' => "Cliquez ici pour continuer l'édition ou enregistrer votre article.",

			'groups:enableblog' => 'Autoriser les blogs de groupe',
			'blog:group' => 'Blog de groupe',
			'blog:nogroup' => "Ce groupe n'a pas encore de messages de blog",
			'blog:more' => 'Plus de messages de blog',

			'blog:read_more' => "Lire le message complet",

		/**
		 * Blog widget
		 */
		'blog:widget:description' => 'Ce widget affiche votre dernier article de blog.',
		'blog:moreblogs' => 'Plus d\'articles du blog',
		'blog:numbertodisplay' => 'Nombre d\'articles du blog à afficher',

         /**
	     * Blog river
	     **/

	        //generic terms to use
	        'blog:river:created' => "a écrit %s",
	        'blog:river:updated' => "a mis à jour %s",
	        'blog:river:posted' => "a ajouté %s",

	        //these get inserted into the river links to take the user to the entity
	        'blog:river:create' => "un nouvel article intitulé",
	        'blog:river:update' => "un article intitulé",
	        'blog:river:annotate' => "un commentaire sur cet article de blog",


		/**
		 * Status messages
		 */

			'blog:posted' => "Votre article de blog a bien été ajouté.",
			'blog:deleted' => "Votre article de blog a bien été supprimé.",

		/**
		 * Error messages
		 */

			'blog:error' => "Une erreur s'est produite. Veuillez réessayer.",
			'blog:save:failure' => "Votre article n'a pas pu être enregistré, merci de réessayer.",
			'blog:blank' => "Désolé, vous devez compléter le titre et le corps de l'article avant de pouvoir publier.",
			'blog:notfound' => "Désolé, l'article de blog spécifié n'a pu être trouvé.",
			'blog:notdeleted' => "Désolé, cet article de blog n'a pu être supprimé.",

	);

	add_translation("fr",$french);

?>