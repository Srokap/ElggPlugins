<?php
/**
	 * Traduction Française Florian Daniel http://id.facyla.net/ (celle-la n'a pas été trop longue^^)
	 */
$french = array(

	/**
	 * Friends widget
	 */
	'friends:widget:description' => "Affiche certains de vos contacts.",
	'friends:num_display' => "Nombre d'amis à afficher",
	'friends:icon_size' => "Taille d'icône",
	'friends:tiny' => "miniature",
	'friends:small' => "petite",
);

add_translation("fr",$french);
?>