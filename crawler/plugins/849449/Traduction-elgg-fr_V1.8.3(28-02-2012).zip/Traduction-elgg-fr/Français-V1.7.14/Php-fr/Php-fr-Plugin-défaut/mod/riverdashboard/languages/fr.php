<?php
/**
	 * Traduction Française pour la 1.5 Florian Daniel http://id.facyla.net/
	 * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
	 * Ajout/modification pour la 1.7.14 Jean-Baptiste Duclos
	 */
$french = array(

	'mine' => 'Moi',
	'filter' => 'Filtre',
	'riverdashboard:useasdashboard' => "Remplacer le tableau de bord par défaut avec ce flux d'activité ?",
	'activity' => 'Activité',
	'riverdashboard:recentmembers' => 'Membres récents',

    /**
     * Site messages
          **/

	'sitemessages:announcements' => "Annonces du site",
	'sitemessages:posted' => "Posté",
	'sitemessages:river:created' => "Administrateur du site, %s,",
	'sitemessages:river:create' => "a posté un nouveau message pour l'ensemble du site",
	'sitemessages:add' => "Ajouter un message pour l'ensemble du site sur le flux d'activité",
	'sitemessage:deleted' => "Message du site effacé",
	'sitemessage:error' => "Impossible de sauvegarder ce message.",
	'sitemessages:blank' => "Impossible de poster un message vide.",
	'sitemessage:notdeleted' => "Impossible d'effacer le message du site. Vous ne devez pas avoir les permissions ou le message ne doit pas exister",

	'river:widget:noactivity' => "Aucune activité trouvée.",
	'river:widget:title' => "Activité",
	'river:widget:description' => "Montrer vos activités les plus récentes.",
	'river:widgets:friends' => "Contacts",
	'river:widgets:mine' => "Moi",
	'river:widget:label:displaynum' => "Nombre d'entrées à afficher:",
	'river:widget:type' => "Quel flux d'activité souhaitez-vous afficher ? Celui qui montre votre activité, ou celui qui montre celle de vos contacts ?",
	'item:object:sitemessage' => "Messages du site",
	'riverdashboard:avataricon' => "Voulez-vous utiliser les icônes ou avatars de vos contacts dans le flux d'activités ?",
	'option:icon' => 'Icônes',
	'option:avatar' => 'Avatars',
);

	add_translation("fr",$french);

?>