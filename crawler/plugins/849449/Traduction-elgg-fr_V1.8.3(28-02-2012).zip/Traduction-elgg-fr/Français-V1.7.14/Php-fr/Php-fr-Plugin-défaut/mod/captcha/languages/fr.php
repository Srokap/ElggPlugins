<?php
	/**
	 * Traduction Française pour la 1.7 Christophe Goddon chgoddon@gmail.com
	 */

	$french = array(

		'captcha:entercaptcha' => "Entrer le texte de l'image",
		'captcha:captchafail' => "Désolé, le texte que vous avez entré ne correspond pas au texte de l'image.",

	);

	add_translation("fr",$french);
?>