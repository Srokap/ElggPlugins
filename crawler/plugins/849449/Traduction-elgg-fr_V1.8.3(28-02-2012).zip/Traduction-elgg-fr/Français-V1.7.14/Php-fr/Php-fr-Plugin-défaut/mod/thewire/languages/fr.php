<?php
	/**
	* Traduction Française pour la 1.5 Florian Daniel http://id.facyla.net/
         * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
	 */
	$french = array(

		/**
		 * Menu items and titles
		 */

			'thewire' => "Le Fil",
			'thewire:user' => "Le Fil de %s",
			'thewire:posttitle' => "Notes de %s sur le fil: %s",
			'thewire:everyone' => "Tous les messages du fil",
			'thewire:friends:title' => "Amis de %s sur le fil",
			'thewire:friends' => "Messages d'amis sur le fil",

			'thewire:yours' => "Vos message sur le fil",
			'thewire:theirs' => "Messages de %s sur le fil",

			'thewire:strapline' => "%s",

			'thewire:add' => "Poster vers le fil",
			'thewire:text' => "Une note sur le fil",
			'thewire:reply' => "Répondre",
			'thewire:via_method' => "via",
			'thewire:wired' => "Posté sur le fil",
			'thewire:charleft' => "caractères restant",
			'item:object:thewire' => "Messages du Fil",
			'thewire:notedeleted' => "note effacée",
			'thewire:doing' => "Que faites-vous ? Dites-le à tout le monde sur le Fil :",
			'thewire:newpost' => 'Nouveau message sur le Fil',
			'thewire:addpost' => 'Poster sur le fil',
			'thewire:by' => "Message du fil par %s",
			'thewire:update' => 'Mise à jour',


        /**
	     * The wire river
	     **/

	        //generic terms to use
	        'thewire:river:created' => "%s a écrit",

	        //these get inserted into the river links to take the user to the entity
	        'thewire:river:create' => "sur le fil.",

	    /**
	     * Wire widget
	     **/

	        'thewire:sitedesc' => 'Ce widget affiche les messages les plus récents du site postés sur le fil',
	        'thewire:yourdesc' => 'Ce widget affiche vos messages les plus récents postés sur le fil',
	        'thewire:friendsdesc' => 'Ce widget affiche les messages les plus récents de vos contacts sur le fil',
	        'thewire:num' => "Nombre d'éléments à afficher",
	        'thewire:moreposts' => 'Plus de messages du fil',


		/**
		 * Status messages
		 */

			'thewire:posted' => "Votre message a bien été posté sur le fil.",
			'thewire:deleted' => "Votre note a bien été supprimée.",

		/**
		 * Error messages
		 */

			'thewire:blank' => "Désolé, vous devez d'abord écrire un message avant de l'enregistrer.",
			'thewire:notfound' => "Désolé, la note spécifiée n'a pu être trouvée.",
			'thewire:notdeleted' => "Désolé, ce message n'a pu être effacé.",


		/**
		 * Settings
		 */
			'thewire:smsnumber' => "Votre numéro SMS s'il est différent de celui de votre téléphone portable (le numéro de téléphone doit être 'Public' pour que le Fil puisse l'utiliser). Tous les numéros de téléphone doivent être écrits au format international.",
			'thewire:channelsms' => "Le numéro auquel envoyer des SMS est le <b>%s</b>",

		// twitter
			'thewire:twitterservice:desc' => 'Tweets all posts made to The Wire.',

	);

	add_translation("fr",$french);

?>