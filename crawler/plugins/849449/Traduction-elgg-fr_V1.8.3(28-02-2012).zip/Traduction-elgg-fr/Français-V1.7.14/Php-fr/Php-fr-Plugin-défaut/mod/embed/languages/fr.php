<?php
	/**
	 * Traduction Française pour la 1.5 Florian Daniel http://id.facyla.net/
         * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
	 */
	$french = array(

		'media:insert' => 'Embarquer / télécharger un média',

		'embed:instructions' => "Cliquez sur le fichier de votre choix pour l'embarquer dans votre contenu.",

		'embed:media' => 'Fichier embarqué',
		'upload:media' => 'Télécharger un fichier',

		'embed:file:required' => "Aucun service de téléchargement de fichier n'a été trouvé. L'administrateur du site pourrait avoir besoin d'installer le plugin de gestion des fichiers.",

	);

	add_translation("fr",$french);

?>