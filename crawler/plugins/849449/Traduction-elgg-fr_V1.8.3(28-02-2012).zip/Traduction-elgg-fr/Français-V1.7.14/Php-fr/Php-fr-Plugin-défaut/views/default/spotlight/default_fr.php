<?php
/**
 * Elgg default spotlight
 * The spotlight area that displays across the site
 *
 * @package Elgg
 * @subpackage Core
 *
 */
?>

<div id="spotlight_table">
	<!-- spotlight RHS content -->
	<div class="spotlightRHS">
		<h2>Information</h2>
		<ul>
			<li><a href="http://docs.elgg.org/">Elgg documentation</a></li>
			<li><a href="http://community.elgg.org/">Elgg communité open source </a></li>
			<li><a href="http://trac.elgg.org/">Elgg suivi des bugs</a></li>
		</ul>
	</div>
	<!-- spotlight LHS content -->
	<div class="spotlightLHS">
		<h2>Bienvenue sur Elgg</h2>
		<p>
			Elgg vous permet de réaliser votre propre site de réseau social, aussi bien public (comme
			Facebook) que privé, au sein de entreprise ou organisation.
			Vous trouverez des plugins et de l'aide pour votre système Elgg sur le site à l'adresse suivante
			<a href="http://community.elgg.org/">Elgg community site</a>.
		</p>
	</div><!-- /spotlight LHS content -->
	<div class="clearfloat"></div>
</div>