<?php
	/**
	 * Traduction Française pour la 1.5 Florian Daniel http://id.facyla.net/
         * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
	 */

	$french = array(

		/**
		 * Menu items and titles
		 */

			'bookmarks' => "Signets",
			'bookmarks:add' => "Mettre quelque chose en signet",
			'bookmarks:read' => "Eléments enregistrés comme signets",
			'bookmarks:friends' => "Signets des contacts",
			'bookmarks:everyone' => "Tous les signets du site",
			'bookmarks:this' => "Mettre en signet",
			'bookmarks:this:group' => "Mettre en signet dans %s",
			'bookmarks:bookmarklet' => "Récupérer le 'bookmarklet'",
			'bookmarks:bookmarklet:group' => "Récupérer le 'bookmarklet' du groupe",
			'bookmarks:inbox' => "Boîte de réception des signets",
			'bookmarks:morebookmarks' => "Plus de signets",
			'bookmarks:more' => "Plus",
			'bookmarks:shareditem' => "Elément mis en signet",
			'bookmarks:with' => "Partager avec",
			'bookmarks:new' => "Un nouvel élément mis en signet",
			'bookmarks:via' => "via les signets",
			'bookmarks:address' => "Adresse de la ressource à ajouter à vos signets",

			'bookmarks:delete:confirm' => "Etes-vous sûr(e) de vouloir supprimer cette ressource ?",

			'bookmarks:numbertodisplay' => 'Nombre de signets à afficher',

			'bookmarks:shared' => "Mis en signet",
			'bookmarks:visit' => "Voir la ressource",
			'bookmarks:recent' => "Signets récents",

			'bookmarks:river:created' => '%s a mis en signet',
			'bookmarks:river:annotate' => 'a posté un commentaire sur cet élément mis en signet',
			'bookmarks:river:item' => 'un élément',

			'item:object:bookmarks' => 'Eléments mis en signets',

			'bookmarks:group' => 'Signets du groupe',
			'groups:enablebookmarks' => 'Autoriser les signets pour un groupe',
			'bookmarks:nogroup' => "Ce groupe n'a pas encore de signets",
			'bookmarks:more' => 'Plus de signets',


		/**
		 * More text
		 */

		    'bookmarks:widget:description' =>
		            "Ce widget est conçu pour votre tableau de bord, et vous présentera les éléments les plus récents de votre boîte de réception des signets.",

			'bookmarks:bookmarklet:description' =>
					"Le 'bookmarklet' des signets vous permet de partager toute ressource que vous trouvez sur le web avec vos contacts, ou à la conserver pour vous-même. Pour l'utiliser, faites glisser cet icone dans la barre de liens de votre navigateur:",

	        'bookmarks:bookmarklet:descriptionie' =>
					"Si vous utilisez Internet Explorer, faites un clic droit sur l'icone du bookmarklet, sélectionnez 'ajouter aux favoris', puis choisissez la barre de liens.",

			'bookmarks:bookmarklet:description:conclusion' =>
					"Vous pouvez enregistrer toute page que vous visitez en cliquant dessus à tout moment.",

			'bookmarks:no_title' => 'Aucun titre',

		/**
		 * Status messages
		 */

			'bookmarks:save:success' => "Votre élément a bien été mis en signet.",
			'bookmarks:delete:success' => "Votre signet a bien été supprimé.",

		/**
		 * Error messages
		 */

			'bookmarks:save:failed' => "Votre élément n'a pu être correctement mis en signet. Merci de réessayer.",
			'bookmarks:delete:failed' => "Votre signet n'a pu être supprimé. Merci de réessayer.",


	);

	add_translation("fr",$french);

?>