<?php 
/**
 * @package :Text Captcha
 * @name : Liang
 * @ url:http://community.elgg.org/pg/profile/arsalanlee
 * @licnnce : GPL V2
 */
?>
<?php

	$french = array(
	
		'textcaptcha:entercaptcha' => "Répondre à une question simple",
		'textcaptcha:entercaptcha:description' => "Entrée votre réponse ci-desssous",
		'textcaptcha:captchafail' => "Désolé, le nombre que vous avez entré n'était pas correct.",
		'textcaptcha:tasks' => "Désactiver tous les éditeurs de texte, puis entrer les questions qui définissent les tâches additionelles :'
	);
					
	add_translation("fr",$french);
?>