<?php
	$french = array(
		'customtopbarlink:adminsettings' => "Entrez le texte du lien et l'URL du lien personnalisés de la barre d'entête. Si vous avez besoin d'utiliser un caractère spécial pour l'attribut du lien, par exemple un guillemet, entrer le à l'aide de son code spécial, (par exemple &amp;quot;). Entrez <i>class=customtopbarlink</i> comme attribut pour appliquer la configuration des couleurs personnalisées.",
		'customtopbarlink:admintext' => "Texte du lien :",
		'customtopbarlink:adminurl' => "URL du Lien :",
		'customtopbarlink:adminparam' => "Autre attribut du lien (ex : cible) (Optionnel) :",
		'customtopbarlink:admincolour' => "Couleur du lien HTML (ex : #999999) (Optionnel) :",
		'customtopbarlink:adminhover' => "Couleur du lien HTML lors du survol par la souris (ex : #eeeeee) (Optionnel) :",
	);
	add_translation("fr",$french);
?>