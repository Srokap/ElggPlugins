<?php

	$french = array(
		
		'vazco_topbar:settings:linklist' => "<b>Définir les liens pour le barre d'entête (topbar)</b><br/>
		<br/>
		<b>Pour ajouter une nouvelle boîte à outil, utiliser le format :</b><br/>
		|| Nom boîte à outil | Adresse du lien | type<br/>
		Les types sont :<br/>
		0 - visible pour tous<br/>
		1 - visible pour les utilisateurs connectés<br/>
		2 - visible pour les administrateurs seulement<br/>
		Les types ne sont pas obligatoires, le type par défaut est 0
		<b>Pour ajouter des éléments à la boîte à outils, utiliser le format :</b><br/>
		Nom lien | Adresse du lien | type<br/><br/>
		Mettre des adresses sur les boîtes n'est pas obligé :<br/>
		|| Nom boîte à outil<br/>
		Vous devez quand même mettre une adresse (même vide) si vous voulez définir le type de boîte :<br/>
		|| Nom boîte à outil | | 1<br/>",
		'vazco_topbar:title' => "Liens utilisateurs",
	
		'vazco_topbar:settings:loginbar' => "Afficher la barre d'outil avec le formulaire de connexion, pour les utilisateurs non connectées",
		'vazco_topbar:settings:loginbox' => "Afficher la boîte formulaire de connexion sur la page principale",
		'login:short' => "Connecter",
		'vazco_topbar:settings:loginremark' => "[ Vous ne pouvez pas désactiver la boîte formulaire de connexion et la barre d'outil à la fois. Il y aura toujours au moins une option de connexion active. ]",
	
		/*Plugin settings*/
		'vazco_topbar:settings:joinicontools' => "Joindre icônes et outils du profil utilisateur",
		'vazco_topbar:settings:joinsettings' => "Déplacer les paramètres de compte au menu déroulant \"mon profil\"",
		'vazco_topbar:settings:elgglogo' => "Montrer le logo Elgg dans la barre d'entête",
		'vazco_topbar:settings:topbar' => "Montrer/Cacher des éléments de la barre d'entête",
		'vazco_topbar:preview' => "Prévisualiser la page d'accueil",
		'vazco_topbar:preview:description' => "(Sauvegarder les changements dans votre plugin avant de prévisualiser)",
		'vazco_topbar:settings:homebutton' => "Montrer des boutons maisons",
		'vazco_topbar:settings:userlinks' => "Autoriser les utilisateurs à définir leur propre liens",
	
		/*Topbar texts*/
		'vazco_topbar:profile:icon' => "Mon profil",
		'vazco_topbar:editprofile' => "Editer le profil",
		'vazco_topbar:userslinks' => "Liens utilisateurs",
		'vazco_topbar:home' => "Accueil",
		'vazco_topbar:welcomemessage' => "Bienvenu,",
		'vazco_topbar:profile:editprofile' => "Editer le profil",
		'vazco_topbar:profile:editicon' => "Editer l'icone",
		'vazco_topbar:profile:settings' => "Paramètres",
	
		/*Administration*/
		'vazco_mainpage:menu:short' => "Page principale widgets",
		'defaultwidgets:menu:dashboard:short' => "Widgets chaire",
		'defaultwidgets:menu:profile:short' => "Widgets profil",
		'defaultwidgets:menu:user:short' => "Utilisateurs",
		'defaultwidgets:menu:forms:short' => "Formulaires",
		'vazco_avatar:menu:short' => "Avatars utilisateurs",
		'vazco_ads:menu:short' => "Publicités",
		'vazco_spotlight:menu:short' => "Annonces",
		'vazco_gifts:menu:short' => "Liste des dons",
		'vazco_topbar:tidypics:short' => "Tidypics",
		'vazco_topbar:menu:short' => "Barre d'entête",
		'vazco_moderation:menu:short' => "Moderation",
		'vazco_pages:menu:short' => "Pages",

		'vazco_topbar:title:administration' =>	"Lien barre d'entête (Topbar)",
	
		/*User links texts*/
		'vazco_topbar:link:desc' => "Définir le paramètre lien cible à :",
		'vazco_topbar:link:self' => "Automatique",
		'vazco_topbar:link:blank' => "Blanc",
		'vazco_topbar:link:nofollow' => "Donne un attribut nofollow au lien",
		'vazco_topbar:boxname' => "Nom boîte : ",
		'vazco_topbar:boxaddress' => "URL : ",
		'vazco_topbar:boxtype' => "Visible pour : ",
		'vazco_topbar:linkname' => "Nom : ",
		'vazco_topbar:linkaddress' => "URL : ",
		'vazco_topbar:linktype'	=> "Visible pour : ",
		'vazco_topbar:type:0' => "tous",
		'vazco_topbar:type:1' => "connectés",
		'vazco_topbar:type:2' => "administrateur",
		'vazco_topbar:showlinks' => "Montrer les liens",
		'vazco_topbar:hidelinks' => "Cacher les liens",
		
		/*Template*/
		'vazco_topbar:settings:template' => "Choisir le modèle de la barre d'entête :",
		'vazco_topbar:template:blue' => "Bleu",
		'vazco_topbar:template:violet' => "Violet",
		'vazco_topbar:template:red' => "Rouge",
		'vazco_topbar:template:ocean' => "Océan",
		'vazco_topbar:template:green' => "Vert",
		'vazco_topbar:settings:template:notactive' => "[ Vous pouvez optenir des modèles pour votre barre d'entête <a href=\"http://www.elggdev.com/vazco_topbar_template\">ici</a> ]",
		'vazco_topbar:messages' => "Messages: %s",
		'vazco_topbar:nomessages' => "Mon mail",
	);
					
	add_translation("fr",$french);
?>
