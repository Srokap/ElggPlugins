<?php
	$french = array(
		'customtopbarlink:adminsettings' => "Enter the link text and URL for the custom topbar link. If you need to use a special character in the link attribute, like a quote character, please enter it using a special entity code, e.g. &amp;quot;. Enter <i>class=customtopbarlink</i> as the attribute to apply the custom colour configuration.",

		'customtopbarlink:adminsettings' => "Entrez le texte du lien et l'URL du lien barre d'entête personnalisés. Si vous avez besoin d'utiliser un caractère spécial pour l'attribut du lien, par exemple un guillemet, entrer le à l'aide de son code spécial, (par exemple &amp;quot;). Entrez <i>class=customtopbarlink</i> comme attribut pour appliquer la configuration des couleurs personnalisées.",
		'customtopbarlink:admintext' => "Texte du lien :",
		'customtopbarlink:adminurl' => "URL du Lien :",
		'customtopbarlink:adminparam' => "(Optionnel) Autre attribut du lien (e.g. cible):",
		'customtopbarlink:admincolour' => "(Optionnel) Couleur de lien HTML (ex : #999999):",
		'customtopbarlink:adminhover' => "(Optionnel) Couleur du HTML lors du survol par la souris (ex : #eeeeee):",
	);
	add_translation("fr",$french);
?>