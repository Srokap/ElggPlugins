<?php
	/**
	 * Contact Us
	 * 
	 * @package contact_us
	 * @license The BSD License
	 * @author Greg Marine
	 * @copyright Greg Marine 2011
	 * @link http://www.iccnet.org/
	 */

	/**
	 * Initialise the kneemail plugin.
	 *
	 */
	function contact_us_init()
	{
        global $CONFIG;
        
		// Register an entry handler, so we can have nice URLs
		register_page_handler('contact_us','contact_us_handler');

        // Load menu if desired
        $menu = get_plugin_setting('menu', 'contact_us');
        if ($menu == "yes")
            add_menu(elgg_echo('contact_us'),$CONFIG->wwwroot."pg/contact_us");

        // extend views
        extend_view('footer/links', 'contact_us/footer_menu');
    }
	
	/**
	 * contact_us handler.
	 *
	 * @param array $nothing
	 */
	function contact_us_handler($nothing)
	{
		global $CONFIG;
        include($CONFIG->pluginspath . "contact_us/index.php");
    }
    
    // register action for send
    register_action('contact_us/send', true, $CONFIG->pluginspath . "contact_us/actions/send.php");
    
	// Make sure the contact_us initialisation function is called on initialisation
	register_elgg_event_handler('init','system','contact_us_init');
?>