<?php
	/**
	 * Contact Us
	 * 
	 * @package contact_us
	 * @license The BSD License
	 * @author Greg Marine
	 * @copyright Greg Marine 2011
	 * @link http://www.iccnet.org/
	 */

	// Load Elgg engine
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	// Display form
    $body = elgg_view_title(elgg_echo('contact_us')); // set the title	
    $body .= elgg_view("contact_us/form"); //Get the form	

	// Draw page
    page_draw(elgg_echo('contact_us'),elgg_view_layout("one_column", $body));
?>