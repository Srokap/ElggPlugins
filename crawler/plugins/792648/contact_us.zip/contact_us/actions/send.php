<?php
	/**
	 * Contact Us
	 * 
	 * @package contact_us
	 * @license The BSD License
	 * @author Greg Marine
	 * @copyright Greg Marine 2011
	 * @link http://www.iccnet.org/
	 */
 
	// Initialize action action_gatekeeper();
	// action_gatekeeper();

    // Get variables
    $name = get_input('name');
    $email = get_input('email');
    $subject = get_input('subject');
    $message = get_input('message');
    // $mailto = get_plugin_setting('email', 'contact_us');
	$mailto = get_input('mailto');
    
    // Setup HTML email header
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";

    $headers .= "From: $name<$email>";

    // Send the message
    if (ctype_print($name))
    {
        if (is_email_address($email))
        {
            if ($message != "")
            {
                if (($mailto != "") && ($name != "") && ($email != ""))
                {
                    mail($mailto,$subject,$message,$headers);
                    
                    if (get_plugin_setting('success_message', 'contact_us') != "")
                        system_message(get_plugin_setting('success_message', 'contact_us'));
                    else
                        system_message(elgg_echo("contact_us:send:successful"));
                    
                    forward('');
                }
                else
                {
                    register_error(elgg_echo("contact_us:send:unsuccessful"));			
                    $retry = explode('?',$_SERVER['HTTP_REFERER']);
                    $retry = $retry[0];
    
                    $retry .= "?n=" . urlencode($name) . "&e=" . urlencode($email) . "&m=" . urlencode($message);

                    forward($retry);
                }
            }
            else
            {
                register_error(elgg_echo("contact_us:invalid:message"));			
                $retry = explode('?',$_SERVER['HTTP_REFERER']);
                $retry = $retry[0];
    
                $retry .= "?n=" . urlencode($name) . "&e=" . urlencode($email) . "&m=" . urlencode($message);

                forward($retry);	  				
            }
        }
        else
        {
            register_error(elgg_echo("contact_us:invalid:email"));	
            $retry = explode('?',$_SERVER['HTTP_REFERER']);
            $retry = $retry[0];
    
            $retry .= "?n=" . urlencode($name) . "&e=" . urlencode($email) . "&m=" . urlencode($message);

            forward($retry);
        }
    }
    else
    {
           register_error(elgg_echo("contact_us:invalid:name"));			
           $retry = explode('?',$_SERVER['HTTP_REFERER']);
           $retry = $retry[0];
       
           $retry .= "?n=" . urlencode($name) . "&e=" . urlencode($email) . "&m=" . urlencode($message);

           forward($retry);
    }
?>