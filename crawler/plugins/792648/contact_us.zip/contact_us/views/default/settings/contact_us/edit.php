<?php
	/**
	 * Contact Us
	 * 
	 * @package contact_us
	 * @license The BSD License
	 * @author Greg Marine
	 * @copyright Greg Marine 2011
	 * @link http://www.iccnet.org/
	 */
	
	$DEFAULT_EMAIL = "Name:me@here.tld";	
?>	 
<p>
	<?php echo elgg_echo('contact_us:address'); ?><br />
	<?php
		echo elgg_view('input/longtext', array('internalname' => 'params[address]', 'value' => $vars['entity']->address));
	?>
</p>
<br />
<p>
	<?php echo elgg_echo('contact_us:phone'); ?><br />
	<?php
		echo elgg_view('input/text', array('internalname' => 'params[phone]', 'value' => $vars['entity']->phone));
	?>
</p>
<br />
<p>
	<?php echo elgg_echo('contact_us:subjects'); ?><br />
	<?php
		echo elgg_view('input/longtext', array('internalname' => 'params[subject]', 'value' => $vars['entity']->subject));
	?>
</p>
<br />
<p>
	<?php echo elgg_echo('contact_us:subject:textbox'); ?><br />
	<select name="params[subject_textbox]">
		<option value="yes" <?php if ($vars['entity']->subject_textbox == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->subject_textbox != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<br />
<p>
	<?php echo elgg_echo('contact_us:default:email'); ?><br />
	<?php
		$email = ($vars['entity']->mailto ? $vars['entity']->mailto : $DEFAULT_EMAIL);
		echo elgg_view('input/longtext', array('internalname' => 'params[mailto]', 'value' => $email));
	?>
</p>
<br />
<p>
	<?php echo elgg_echo('contact_us:successful:message'); ?><br />
	<?php
		echo elgg_view('input/text', array('internalname' => 'params[success_message]', 'value' => $vars['entity']->success_message));
	?>
</p>
<br />
<p>
	<?php echo elgg_echo('contact_us:menu'); ?><br />
	<select name="params[menu]">
		<option value="yes" <?php if ($vars['entity']->menu == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->menu != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<br />