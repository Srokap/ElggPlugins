<?php
	/**
	 * Contact Us
	 * 
	 * @package contact_us
	 * @license The BSD License
	 * @author Greg Marine
	 * @copyright Greg Marine 2011
	 * @link http://www.iccnet.org/
	 */

	if(isloggedin())
    {
	 	$name = ($_SESSION['user']->name);
	 	$email = ($_SESSION['user']->email);
	 	$message = get_input('m');
	}
    else
    {
	  	$name = get_input('n');
        $email = get_input('e');
        $message = get_input('m');
    }

    $body = "<div class=\"contentWrapper\">";

    if (get_plugin_setting('address', 'contact_us') != "")
        $body .= "<p><label>" . elgg_echo('contact_us:address') . "</label><br />" . str_replace("\n", "<br />", get_plugin_setting('address', 'contact_us')) . "</p><br />";

    if (get_plugin_setting('phone', 'contact_us') != "")
        $body .= "<p><label>" . elgg_echo('contact_us:phone') . "</label><br /><strong>" . get_plugin_setting('phone', 'contact_us') . "</strong></p><br />";

	$body .= "<p><label>" . elgg_echo('contact_us:emailform') . "</label><br />";

	$body .= "<p><label>" . elgg_echo('contact_us:name') . "<br />" . elgg_view('input/text' , array('internalname' => 'name', 'class' => "general-textarea", 'value' => $name)) . "</label><br />";
	$body .= "<label>" . elgg_echo('contact_us:email') . "<br />" . elgg_view('input/text' , array('internalname' => 'email', 'class' => "general-textarea", 'value' => $email)) . "</label><br />";
	
	if (get_plugin_setting('subject_textbox', 'contact_us') == 'yes')
	{
		$body .= "<label>" . elgg_echo('contact_us:subject') . "<br />" . elgg_view('input/text' , array('internalname' => 'subject', 'class' => "general-textarea", 'value' => '')) . "</label><br />";
	}
	else
	{
		$subject = explode("\n", get_plugin_setting('subject', 'contact_us'));
		if (count($subject) == 1)
			$body .= elgg_view('input/hidden', array('internalname' => 'subject', 'value' => "$subject[0]"));
		else
			$body .= "<label>" . elgg_echo('contact_us:subject') . "<br />" .elgg_view('input/pulldown' , array('internalname' => "subject", 'options' => $subject)) . "</label><br /><br />";
	}
		
	$body .= "<label>" . elgg_echo('contact_us:message') . "<br />" . elgg_view('input/longtext' , array('internalname' => 'message', 'class' => "general-textarea", 'value' => $message)) . "</label><br />";
	
	$options_values = array();
	$emailAddresses = explode("\n", get_plugin_setting('mailto', 'contact_us'));
	foreach($emailAddresses as $emailAddress)
	{
		$temp = explode(":", $emailAddress);
		$options_values[$temp[1]] = $temp[0];
	}
	
	$body .= "<label>" . elgg_echo('contact_us:mailto') . "<br />" . elgg_view('input/pulldown' , array('internalname' => 'mailto', 'options_values' => $options_values)) . "</label><br />";
	
	$body .= elgg_view('input/hidden', array('internalname' => 'action', 'value' => 'contact_us/send'));
    $body .= elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('contact_us:send'))) . "</p>";
    
    $body .= "</div>";

    echo elgg_view('input/form', array('action' => "{$vars['url']}action/contact_us/send", 'body' => $body));
?>