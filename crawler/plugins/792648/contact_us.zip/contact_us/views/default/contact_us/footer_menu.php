<?php
	/**
	 * Contact Us
	 * 
	 * @package contact_us
	 * @license The BSD License
	 * @author Greg Marine
	 * @copyright Greg Marine 2011
	 * @link http://www.iccnet.org/
	 */
?>

 <a href="<?php echo $vars['url']; ?>pg/contact_us/"><?php echo elgg_echo('contact_us'); ?></a>