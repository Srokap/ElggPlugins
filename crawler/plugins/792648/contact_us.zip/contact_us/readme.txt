Just drop this into your mod directory and enable it in tool administration.

The settings for this plugin are as follows:

Mailing Address - if you have one...leave blank to hide this from users.
Phone - if you have one...leave blank to hide this from users.
Email address - this is required.
Subjects - type what options you want users to have...one per line.
Successful Message - something to state when the email goes through.
Tools Menu - optional...yes to have it show up in the tools menu.

http://www.iccnet.org