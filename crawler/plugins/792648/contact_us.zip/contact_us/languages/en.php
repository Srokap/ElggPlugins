<?php
	/**
	 * Contact Us
	 * 
	 * @package contact_us
	 * @license The BSD License
	 * @author Greg Marine
	 * @copyright Greg Marine 2011
	 * @link http://www.iccnet.org/
	 */

	$english = array(
    
        // Title and labels for form and settings
        'contact_us' => "Contact Us",
        'contact_us:address' => "Mailing Address",
        'contact_us:phone' => "Phone",
        'contact_us:emailform' => "Email Form",
        'contact_us:name' => "Name",
        'contact_us:email' => "Email",
        'contact_us:subject' => "Subject",
        'contact_us:message' => "Message",
        'contact_us:mailto' => "Send Email To",
        'contact_us:send' => "Send",
        'contact_us:subjects' => "Supply subjects (one per line)",
        'contact_us:subject:textbox' => "Show a blank subject textbox instead of the above subjects?",
        'contact_us:default:email' => "Supply email addresses (one per line; e.g. John Doe:jdoe@domain.tld)",
        'contact_us:successful:message' => "Successful Message",
        'contact_us:menu' => "Would you like the contact page to appear in the Tools menu?",
        
        // Feedback messages
        'contact_us:invalid:name' => "The system could not accept the name you have supplied. A valid name can only contain alphabet letters, numbers and punctuation marks. Please try again.",
        'contact_us:invalid:email' => "The system could not accept the email you have supplied. Please try again with valid email address.",
        'contact_us:invalid:message' => "The message can't be blank.",
        'contact_us:send:unsuccessful' => "Your message could not be sent. Be sure you have supplied information for all of the fields.",
        'contact_us:send:successful' => "Your message was successfully sent. We will get back with you soon. Thank you.",

	);

	add_translation("en",$english);
?>