Blog extended plugin
=======================

This plugins adds blogs to the group profile.

Install
-------

Just drop it on your mod directory and then go to the admin panel and activate it. 
This plugin is completly independent of the blog's plugin, you can use it to avoid final user make blogs.
