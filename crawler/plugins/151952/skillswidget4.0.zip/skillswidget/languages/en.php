<?php

	$english = array(
	
	    //words & phrases used...
        'skillswidget:red' => 'red',
		'skillswidget:amber' => 'amber',
		'skillswidget:green' => 'green',
		'skillswidget:na' => 'n/a',
		'skillswidget:introduction' => '', //optional intro text
		'skillswidget:previousintro' => 'Previous level shown in (brackets)',
		'skillswidget:previous' => 'Show levels from last time',
		'skillswidget:average' => 'Average',
		
		'skillswidget:settings:intro' => '<strong>You can enter an introduction line here</strong> (or leave it blank)',
		'skillswidget:settings:enterskills' => '<strong>Enter your list of skills here. Put each one a separate line.</strong><br>(Blank lines are ignored so you can safely use them if it makes it easier to read)',
		'skillswidget:settings:collapsible' => 'You can also group skills together into collapsible sections.
			Simply include a section heading with a \'+\' at the beginning (the \'+\' sign won\'t display in the name) and a
			section end that is the same name but with a \'-\' at the beginning (this section end won\'t display at all, it is only a marker)
			<br><br>These sections are automatically levelled with an average.<br><br>For example...<br><br>
			+Section 1<br>
			&nbsp;&nbsp;skill 1a<br>
			&nbsp;&nbsp;skill 1b<br>
			-Section 1<br>
			    <br>
			+Section 2<br>
			&nbsp;&nbsp;skill 2a<br>
			&nbsp;&nbsp;skill 2b<br>
			-Section 2<br><br>
			Multiple nested sections are also possible.',
		'skillswidget:settings:override' => 'Override this and let users set the skills for themselves? (Settings > Configure your tools) ',

	    'skillswidget:widgetfoldername' => 'skillswidget', 
	    //used in view.php, saves changing it there if widget name is changed
			
	);
					
	add_translation("en",$english);


?>