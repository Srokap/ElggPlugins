<?php
  function skillswidget_init() { 
  
    extend_view('css','skillswidget/css');
    extend_view('metatags','skillswidget/metatags');	
	       
    add_widget_type('skillswidget', 'Skills Review', 'Skills review widget');
  }
 
  register_elgg_event_handler('init','system','skillswidget_init');       
?>