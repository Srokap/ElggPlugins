<?php 

//get the list of skills 
//check if set in Admin/Tools or User
if(get_plugin_setting("useroverride", elgg_echo('skillswidget:widgetfoldername')) == "no") //admin
{
 	$skills = get_plugin_setting('skills', elgg_echo('skillswidget:widgetfoldername'));
}
else //user
{
	$skills = get_plugin_usersetting('skills', $user_guid = 0, elgg_echo('skillswidget:widgetfoldername'));
}
//sort this list into an array
$skills = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $skills); //remove any blank lines
$skillsarray = explode("\n", $skills); //create array from the string

//set traffic light text with styles
$red = "<span class='red'>".elgg_echo("skillswidget:red")."</span>";
$amber = "<span class='amber'>".elgg_echo("skillswidget:amber")."</span>";
$green = "<span class='green'>".elgg_echo("skillswidget:green")."</span>";

//get plugin name to help uniquely identify collapsible sections
//needed just in case there are more than one instances of this widget with same section names
//(code taken from views/default/widgets/wrapper.php)
$widgettypes = get_widget_types();
$handler = $vars['entity']->handler;
$plugintitle = $widgettypes[$vars['entity']->handler]->name;
//$plugintitle used later on (twice) to name collapsible section, <a> and <div>

?>

<div id="edit">

<?php 
//cycle through selection for each skill
//foreach (elgg_echo("skillswidget:skills") as $value)  //old version
foreach ($skillsarray as $value) 
{
 
  //check to see if it is a section end (thus don't display it - skip the block of display instructions)
  if (substr($value, 0,1) != "-") { 

  //check to see if it is a section heading
  if (substr($value, 0,1) == "+") { ?>
   <div class="collapsablesectionheading_edit">
   	<?php
     //each collapsible section needs a unique name to function
     //unique for the entire site, so append widget title to section name
    ?>
   <a onclick="switchMenu('<?php echo $plugintitle.$value.'_edit';?>');" title="Click to expand/hide" class="collapsablesectiontoggle">
  <?php 
  //strip '+' from any skill section names before displaying it
  echo str_replace("+", "", $value).': </a></div>'; 
  //start the collapsable div before the r/a/g to make it look less confusing
  ?>
  <div id="<?php echo $plugintitle.$value.'_edit';?>" style="display:none;">
  <!-- <div class="collapsablesectionheading_edit">-->
  <?php
  }
  else {
  echo '<p>'.$value.': <br/>'; 
  }

  //Check to see if it is a section heading
  //These aren't levelled directly, an average is worked out
  if (substr($value, 0,1) != "+") {

  //display RED radio button
  echo '<input type="radio" name="params['.$value.']" value=1'; 
  if ($vars['entity']->$value == 1) { echo ' checked="checked"'; } 
  echo '>'.$red;
  
  //display AMBER radio button
  echo ' <input type="radio" name="params['.$value.']" value=2';
  if ($vars['entity']->$value == 2) { echo ' checked="checked"'; } 
  echo '>'.$amber;
  
  //display GREEN radio button
  echo ' <input type="radio" name="params['.$value.']" value=3'; 
  if ($vars['entity']->$value == 3) { echo ' checked="checked"'; } 
  echo '>'.$green;
  
  //display N/A radio button
  echo ' <input type="radio" name="params['.$value.']" value=""'; 
  if ($vars['entity']->$value == "") { echo ' checked="checked"'; } 
  echo '><span class="na">'.elgg_echo("skillswidget:na").'</span></p>';
  
  //current value passed on as hidden 
  //(to show as previous value next time form is updated)
  //previous value stored in the skill name appended with '_prev'
  $skill_prev = $value."_prev";
?>
  <input type="hidden" name="params[<?php echo $skill_prev; ?>]" 
         value="<?php echo $vars['entity']->$value;?>">

<?php

  } //end of IF that checks if it is a section start
  
  //check to see if it is a section heading, if so end the collapsableheading <div>
  //if (substr($value, 0,1) == "+") { echo "</div>"; }
  //else {
   echo '</p>'; //new para for next skill
  //}
  

  } //end of IF that checks if it is a section end
  //if it is a section end then close the collapsible div)
  else { echo"<br></div>";}


}  //end of foreach loop (next skill)  


  //show previous or not
  $previous = $vars['entity']->previous;
  if (!isset($previous)) $previous = 0;

  echo elgg_view('input/hidden', array('internalname' => 'params[previous]', 'js' => 'id="params[previous]"', 'value' => $previous ));
  echo "<input class='input-checkboxes' type='checkbox' value='' name='previouscheckbox' onclick=\"document.getElementById('params[previous]').value = 1 - document.getElementById('params[previous]').value;\" ";
  if ($previous) echo "checked='yes'";
  echo " />";
  echo ' ' . elgg_echo('skillswidget:previous');

?>


</div>

