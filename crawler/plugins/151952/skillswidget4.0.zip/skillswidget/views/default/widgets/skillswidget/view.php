<?php

//get the list of skills 
//check if set in Admin/Tools or User
if(get_plugin_setting("useroverride", elgg_echo('skillswidget:widgetfoldername')) == "no") //admin
{
 	$skills = get_plugin_setting('skills', elgg_echo('skillswidget:widgetfoldername'));
	$intro = get_plugin_setting('widgetintro', elgg_echo('skillswidget:widgetfoldername'));
}
else //user
{
	$skills = get_plugin_usersetting('skills', $user_guid = 0, elgg_echo('skillswidget:widgetfoldername'));
	$intro = get_plugin_usersetting('widgetintro', $user_guid = 0, elgg_echo('skillswidget:widgetfoldername'));
}
//sort this list into an array
$skills = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $skills); //remove any blank lines
$skillsarray = explode("\n", $skills); //create array from the string
 
//set traffic light text with styles
$red = "<span class='red'>".elgg_echo("skillswidget:red")."</span>";
$amber = "<span class='amber'>".elgg_echo("skillswidget:amber")."</span>";
$green = "<span class='green'>".elgg_echo("skillswidget:green")."</span>";
//...these used for previous values (single letter only))
$r = "<span class='red'>".substr(elgg_echo("skillswidget:red"),0,1)."</span>";
$a = "<span class='amber'>".substr(elgg_echo("skillswidget:amber"),0,1)."</span>";
$g = "<span class='green'>".substr(elgg_echo("skillswidget:green"),0,1)."</span>";

//set the level variable (used when calculating averages so that nested sections get their own average)
//and declare the array used to store level values for averages
$level = 0;
$averagearray = array();

//show previous value setting
$previous = $vars['entity']->previous;

//get plugin name to help uniquely identify collapsible sections
//needed just in case there are more than one instances of this widget with same section names
//(code taken from views/default/widgets/wrapper.php)
$widgettypes = get_widget_types();
$handler = $vars['entity']->handler;
$plugintitle = $widgettypes[$vars['entity']->handler]->name;
//$plugintitle used later on (twice) to name collapsible section, <a> and <div>

//main div begins=======================================
echo '<div id="view">';

//optional introduction line
echo '<p class="introduction">'.$intro.'</p>';

//show previous introduction line (if set) 
 if ($previous) {
  echo '<p class="introduction">'.elgg_echo("skillswidget:previousintro").'</p>';
 }
  
?>
	
<?php
//show each of the skills in turn
//foreach (elgg_echo("skillswidget:skills") as $value) //old version
foreach ($skillsarray as $value) 
{
  //check to see if it is a section end (thus don't display it - skip the block of display instructions)
  if (substr($value, 0,1) != "-") { 

  //check to see if it is a section heading
  if (substr($value, 0,1) == "+") { 
   
   $level = $level + 1; //expanding out a section level
   unset($averagearray[$level]); //reset the array used for storing values for this level to calculate the average
   
   ?>
   <div class="collapsablesectionheading_view">
    <?php
     //each collapsible section needs a unique name to function
     //unique for the entire site, so append widget title to section name
    ?>
   <a onclick="switchMenu('<?php echo $plugintitle.$value?>');" title="Click to expand/hide" class="collapsablesectiontoggle">
  <?php 
  //strip '+' from any skill section names before displaying it
  echo str_replace("+", "", $value).': '; 
  }
  else {
  echo '<p>'.$value.': '; 
  }
  
  //Check to see if it is a section heading
  //These aren't levelled directly, an average is worked out
  if (substr($value, 0,1) != "+") {
  
  //AVERAGE =======================================================================================================
  $val = $vars['entity']->$value; //to simplify IF statement that follows
  if ($val == 1||$val == 2||$val == 3) //if there IS a value then...
  {
  //append the current value to the average array for this level and any levels below it
  for ($i = 0; $i <= $level; $i++) 
   {
   	$averagearray[$i][] = $vars['entity']->$value;
   }
  }
  
  switch ($vars['entity']->$value) {

   case 1 : 
    echo $red;
   break;

   case 2 :
    echo $amber;
   break;

   case 3 : 
    echo $green;
   break;

   default : //'n/a' or not selected yet
    echo "-";
   break;

   }
 

 if ($previous) {
 //retrieve previous choice for this skill
 //NB: as the Edit form is only hidden (and not refreshed each time Edit is clicked)
 //    the previous values are those from the last time the page was refreshed 
 //    and the Save button clicked (likely to be from the last session)
 
 $skill_prev = $value."_prev"; //value stored in the skill name appended with '_prev'

  switch ($vars['entity']->$skill_prev) {

   case '1' : 
    echo ' ('.$r.')';
   break;

   case '2' :
    echo ' ('.$a.')';
   break;

   case '3' : 
    echo ' ('.$g.')';
   break;

   default : //'n/a' or not selected yet
    //echo ' (-)'; //decided not to show anything if it's not r/a/g
   break;

   }

  } //endIF checking if previous levels should be shown
  
  } //endIF checking if it is a section heading (and thus no level to show yet)
   
  //check to see if it is a section heading, if so start collapsable <div>
  if (substr($value, 0,1) == "+") { ?>
   </a>
   <div id="<?php echo $plugintitle.$value?>" style="display:none;">
   <?php//next div creates white space within the collapsable heading div ?>
   <div class="contents"> 
  <?php }
  else {
   echo '</p>'; //new para for next skill 
  }
  
  } //end of IF that checks if it is a section end
  //else if it is a section end then close the Contents (whitespace) and then the collapsible div)
  else { 
   echo '</div>'.elgg_echo("skillswidget:average").' is </div>&nbsp;';

   
   //work out average (round up - 1:red, 2:amber, 3:green)
   $av = array_sum($averagearray[$level]) / count($averagearray[$level]);
   $av = round($av);
   
   //show the average as red/amber/green
   switch ($av) {
    case 1 : 
     echo $red;
     break;
    case 2 :
     echo $amber;
     break;
    case 3 : 
     echo $green;
     break;
    default : //'n/a' or not selected yet
     echo "-";
     break;
   }
   //end the collapsable heading div
   echo '</div>';
   $level = $level - 1; //dropping back a section level 
  }

 
}  //end of foreach loop (next skill)



echo '</div>'; //main div ends ======================================


/* code used for collapsable block (my own because I couldn't get elgg's collapsable box to work in a widget!)
<a onclick="switchMenu('name');" title="Click to expand/hide" class="collapsablesection">
toggle text</a>
<div id="name" style="display:none;"> 
blocktext</div>
*/
   
   
?>