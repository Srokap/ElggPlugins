<?php
 
    /**
	 * @package skillswidget4dev
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Chris West <c.west@redhill.notts.sc.uk>
	 * @copyright Chris West 2009
	 * @link http://www.redhilllearningspace.org.uk/
	 */
     
?>

#view {
    font-size:0.85em; 
    background:white;
	  -webkit-border-radius: 8px; 
	  -moz-border-radius: 8px;
    padding:4px 7px 4px 5px;
    margin:0 5px 0px 5px;
}

#view p {
    line-height:1.2em;
    margin-bottom:4px;
}

#edit {
    font-size:0.85em; 
    line-height:1.8em;
}

#edit p {
    line-height:1.2em;
    margin-bottom:7px;
}

.red {
    background:red;
    color:white;
}

.amber {
    background:orange;
    color:white;
}

.green {
    background:green;
    color:white;
}

#view .red, #view .amber, #view .green {
    font-weight: bold;
}

#edit .red, #edit .amber, #edit .green {
    font-weight: normal;
}

#view .collapsablesectionheading_view .contents .red, 
#view .collapsablesectionheading_view .contents .amber, 
#view .collapsablesectionheading_view .contents .green {
    font-weight: bold;
    text-transform: none;
}

#view .collapsablesectionheading_view .red, 
#view .collapsablesectionheading_view .amber, 
#view .collapsablesectionheading_view .green {
    font-weight: bold;
    text-transform: uppercase;
}

.na {
    color:#777;
}

.introduction {
    font-size:0.9em;
    line-height:0.5em;
    color:#999;
    margin-bottom:6px;
}

.collapsablesectiontoggle {
    cursor:pointer;
}

.collapsablesectionheading_edit {
    background: #B4B4B4;
    border-bottom: 2px solid #CDCBCB;
    width: 100%;
    font-weight:bold;
    line-height:1.2em;
    padding:3px 0px 3px 2px;
}

/*first level section*/
.collapsablesectionheading_view {
    background: #ddd;
    margin: 0px 0px 5px 0px;
    width: 100%;
    font-weight:bold;
    -webkit-border-radius: 6px; 
	-moz-border-radius: 6px;
    line-height:1.2em;
    padding:5px 0px 5px 3px;
}

/*second level section*/
.collapsablesectionheading_view .collapsablesectionheading_view {
    background: #eee;
    margin: 0px 5px 5px 0px;
    width: 100%;
    font-weight:bold;
    -webkit-border-radius: 6px; 
	-moz-border-radius: 6px;
    line-height:1.2em;
    padding:2px 0px 2px 3px;
}

.collapsablesectionheading_view .contents{
    background:white;
    font-weight:normal;
    text-transform: none;
    margin: 3px 3px 0px 0px;
    padding:5px 5px 1px 2px;
}

sup {
    font-size:9px;
    vertical-align: super;
}





