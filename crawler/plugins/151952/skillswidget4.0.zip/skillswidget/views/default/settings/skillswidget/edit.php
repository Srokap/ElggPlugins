<p>
<?php echo elgg_echo('skillswidget:settings:intro') ?>
</p>
<?php 
  echo elgg_view('input/text', array('internalname' => "params[widgetintro]", 'value' => $vars['entity']->widgetintro)); 
?>
	
<br>
<p>
<?php echo elgg_echo("skillswidget:settings:enterskills") ?>
</p>
    
	<?php
	
	 //check if first time user, if so fill with example skills to get them going
	 if (!isset($vars['entity']->skills)) 
	 { 
	    $skills = "skill 1\nskill 2\nskill 3"; //have to use double quotes otherwise doesn't recognise \n
	 }
	 else 
	 {
	 	$skills = $vars['entity']->skills;
	 }
	?>
	<table width=100% border=0 ><tr><td>
	 <TEXTAREA NAME="params[skills]" COLS=120 ROWS=33 wrap='off' style="overflow-x: scroll; font-size:10px;"><?php echo $skills; ?></TEXTAREA>
	</td><td style="padding:5px;">
	<p style="font-size:10px;">
	 <?php echo elgg_echo("skillswidget:settings:collapsible") ?>
	</p>
	</td></tr></table>
	
	
	<p>
     <?php echo elgg_echo("skillswidget:settings:override") ?>
	<select name="params[useroverride]">
		<option value="no" <?php if ($vars['entity']->useroverride != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
		<option value="yes" <?php if ($vars['entity']->useroverride == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>		
	</select>
    </p>

