<?php

	$italian = array(	
      'lastfm:lastsong' => 'Last.Fm: Ultimi brani ascoltati',
	  'lastfm:widgetinfo' => 'Widget di Last.Fm: mostra un elenco delle ultime canzoni ascoltate.',
	  'lastfm:enterusername' => 'Inserisci il tuo username su Last.Fm:',
	  'lastfm:cannotfind' => 'Impossibile trovare canzoni per l\'utente specificato',
	  'lastfm:displaynum' => 'Elementi da visualizzare',
	  'lastfm:notset' => 'Username di Last.Fm non impostato, per farvore inseriscilo nelle opzioni del widget.',
	);
					
	add_translation("it",$italian);

?>
