<?php

	$english = array(	
      'lastfm:lastsong' => 'Last.Fm: Recent tracks',
	  'lastfm:widgetinfo' => 'Last.Fm Widget: recent tracks.',
	  'lastfm:enterusername' => 'Please insert your Last.Fm username:',
	  'lastfm:cannotfind' => 'No songs for the given username',
	  'lastfm:displaynum' => 'How many songs',
	  'lastfm:notset' => 'You have not yet entered your Last.Fm username which is required to display your recent tracks',
	);
					
	add_translation("en",$english);

?>
