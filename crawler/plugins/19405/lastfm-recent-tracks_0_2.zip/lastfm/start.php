<?php
 
    /**
     * Lastfm: Ultimi brani ascoltati
     * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
	 * @copyright Sergio De Falco aka SGr33n 2009
	 * @link http://www.ircaserta.com/
     **/
 
   function lastfm_init() {

	// Aggiungo il widget
		add_widget_type('lastfm',elgg_echo('lastfm:lastsong'),elgg_echo('lastfm:widgetinfo'));
	
	// Specifico il nuovo CSS
		extend_view('css','lastfm/css');
	}

	// Richiamo l'inizializzazione all'avvio
		register_elgg_event_handler('init','system','lastfm_init');
?>
