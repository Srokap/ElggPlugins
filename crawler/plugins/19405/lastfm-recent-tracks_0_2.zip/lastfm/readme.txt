 Licence: GNU General Public License (GPL) version 2

* Elgg Last.Fm Recent Tracks Widget
*
* @package ElggLastFm
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
* @link http://www.ircaserta.com/

-----

Hi People,

This the new, working, Last.Fm Recent tracks Widget.

It is based on the SimplePie class.

You can set how many songs display on your widget.

INSTALLATION
-----

Just copy the content in your mod directory and enable it from your
administration panel.

Comments and feedbacks very apreciated.


Cya ;)

UPDATES
-----

Last.Fm Recent Tracks Widget 0.1
- First release

Last.Fm Recent Tracks Widget 0.2
- Fixed: default access_id didn't work, removed now.

-----
Sergio De Falco aka SGr33n

www.ircaserta.com
