<?php

	global $CONFIG;

	if (!class_exists('SimplePie'))
	
	{
		require_once $CONFIG->pluginspath . '/lastfm/simplepie.inc';
	}

	$lastfmusername = $vars['entity']->lastfmusername;
	$num_songs = (int)$vars['entity']->limit;
	$lastfm_rss = 'http://ws.audioscrobbler.com/1.0/user/'.$lastfmusername.'/recenttracks.rss';

	if($lastfmusername){

		$cache_loc = $CONFIG->pluginspath . '/lastfm/cache';
		$songs = new SimplePie($lastfm_rss, $cache_loc);

		$num_songs_in_feed = $songs->get_item_quantity();
		if (!$num_songs_in_feed)
			
			// Se non ci sono canzoni
			echo elgg_echo('lastfm:cannotfind');

			if ($num_songs > $num_songs_in_feed)
				$num_songs = $num_songs_in_feed;

			// Apro la lista
			echo "<ul id=\"lastfmsonglist\">";

			foreach ($songs->get_items(0,$num_songs) as $song):		
	
				// Recupero singolarmente i valori della data per la conversione in timestamp
				$listendatey = $song->get_date('Y');
				$listendatem = $song->get_date('m');
				$listendated = $song->get_date('j');
				$listendateh = $song->get_date('H');
				$listendatei = $song->get_date('i');
				$listendates = $song->get_date('s');
				
				// Converto la data in timestamp
				$timestampdate = mktime($listendateh, $listendatei, $listendates, $listendatem, $listendated, $listendatey);
			?>

			<li><a href="<?php echo $song->get_permalink(); ?>" title="<?php echo $song->get_title(); ?>" target="_blank"><?php echo $song->get_title(); ?></a><br />
			<small>(<?php echo friendly_time($timestampdate); ?>)</small></li>
	<?php

			endforeach;

			// Chiudo la lista
			echo "</ul>";

	} else {    

	echo elgg_echo('lastfm:notset');      
	}
?>
