<?php

	/**
	 * Elgg LastFm Widget Edit
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
	 * @copyright Sergio De Falco aka SGr33n 2009
	 * @link http://www.ircaserta.com/
	 */

?>

<p>
	<?php echo elgg_echo('lastfm:enterusername'); ?><br />
	<input type="text" onclick="this.select();" name="params[lastfmusername]" value="<?php echo htmlentities($vars['entity']->lastfmusername); ?>" /></p>

<p>
	<?php echo elgg_echo('lastfm:displaynum'); ?><br />
	<select name="params[limit]">
		<option value="2" <?php if ($vars['entity']->limit == 2) echo " selected=\"yes\" "; ?>>2</option>
		<option value="5" <?php if ((!$vars['entity']->limit) || ($vars['entity']->limit == 5)) echo " selected=\"yes\" "; ?>>5</option>
		<option value="8" <?php if ($vars['entity']->limit == 8) echo " selected=\"yes\" "; ?>>8</option>
		<option value="10" <?php if ($vars['entity']->limit == 10) echo " selected=\"yes\" "; ?>>10</option>
	</select></p>