<?php

	$hebrew = array(
	
			'custom:bookmarks' => "קישורים חדשים",
			'custom:groups' => "קבוצות חדשות",
			'custom:files' => "קבצים חדשים",
			'custom:blogs' => "פוסטים חדשים בבלוגים",
			'custom:members' => "חברים חדשים",
			'custom:nofiles' => "אין קבצים עדיין",
			'custom:nogroups' => "אין קבוצות עדיין",	
	
	);
					
	add_translation("he",$hebrew);

?>