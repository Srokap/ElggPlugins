#!/usr/bin/env python

import sys, re, os
import xml.dom.minidom
import pprint

from optparse import OptionParser
from traceback import print_exc

class FileMaker(object):
    def makeDirectory( self ):
        try:
            if not self.rootDir:
                return False
            
            viewsDirectory = os.path.join( self.rootDir,
                                    "views" )
                                    
            languagesDirectory = os.path.join( self.rootDir,
                                    "languages" ) 
                                    
            for dirInQuestion in ( viewsDirectory, languagesDirectory ):  
                print dirInQuestion                     
                if not os.path.exists( dirInQuestion ) : 
                    os.mkdir( dirInQuestion ) 
                    
            self.generateManifestXML()
            self.generateStartPHP()        
            
            return True
        except AttributeError, e:
            print "Aborting! %s" % e.message
    def generateManifestXML( self ):
        srcXMLFile = os.path.join( self.rootDir, "manifest.xml" )
        manifestXML = xml.dom.minidom.getDOMImplementation()
        memXMLFile = manifestXML.createDocument( None , "plugin_manifest", None )
        
        rootNode = memXMLFile.getElementsByTagName("plugin_manifest")[0]
        vdict = { "key" : ["author","version","description",
                           "website", "copyright", "license"],
                  "value" : [self.optionList.author,
                             self.optionList.version,
                             self.optionList.description,
                             self.optionList.website,
                             self.optionList.copyright,
                             self.optionList.license] }
        for count in xrange(0,6):
            subNode = memXMLFile.createElement("field")
            for k,v in vdict.iteritems():
                subNode.setAttribute( k, v[count] )
            rootNode.appendChild( subNode )
        
        writerObject = open( srcXMLFile, "w+" )
        writerObject.write( memXMLFile.toprettyxml( encoding='utf-8' ) )
        writerObject.close()

    def generateStartPHP( self ):
        srcPHPFile = os.path.join( self.rootDir, "start.php" )
        phpFile = PHPFileWriter( srcPHPFile )
        phpFile.writePHPHeader()
        phpFile.writePHPHeaderComment([self.optionList.package,
                                       self.optionList.license,
                                       self.optionList.author,
                                       self.optionList.copyright,
                                       self.optionList.website])
        phpFile.writePHPFooter()
        phpFile.cleanUp()
        
class PHPFileWriter(object):
    def __init__( self, fileSource ):
        if not os.path.exists( os.path.dirname( fileSource ) ):
            raise IOError, "%s doesn't exist! " % os.path.dirname( fileSource )
        self.fileSource = fileSource
        self.fileHandle = open( fileSource, "w+" )
    def writeString( self, prettyObjectString ):
        self.fileHandle.write( prettyObjectString )
    def writePHPHeader( self ):
        self.fileHandle.write("<?php" + "\n")
    def writePHPFooter( self ):
        self.fileHandle.write("?>" + "\n")
    def writePHPHeaderComment( self, commentList, indent = "\t", newl = "\n" ):
        #TODO: This function needs to be more general to take any php comment
        #      and add it
        self.headerComment = [ indent + "/**" + newl ]
        self.headerTitles = ["@package",
                             "@license",
                             "@author",
                             "@copyright",
                             "@link"]
        self.footerComment = "*/"
        zippedCommentList = zip( self.headerTitles, commentList )
        for comment in zippedCommentList:
            self.headerComment.append( "".join( [ indent,
                                                  " * %s %s " % ( comment[0],
                                                                 comment[1] ),
                                                  newl ] ) )
        self.headerComment.append( "".join( [ indent,
                                              " ",
                                              self.footerComment,
                                              newl ] ) )
        self.writeString( "".join( self.headerComment ) )
    def cleanUp( self ):
        self.fileHandle.close()
class DoIt(object): 
    def start( self ):
        print self.optionlist, self.arguments
        fMaker = FileMaker()
        fMaker.rootDir = self.optionlist.rootDir
        fMaker.optionList = self.optionlist
        if not fMaker.makeDirectory():
            raise IOError, "Could not generate appropriate directories."
    def add_option_parser( self, option_parser ):
        self.optionlist, self.arguments = \
            option_parser.parse_args()
        
def generate_options():
    parser = OptionParser()
    parser.add_option("-d", "--default", help="Adds default views",
                      action="store_true", default=None)
    parser.add_option("--root-dir", help="The directory to create the folders in",
                      dest="rootDir", default=None)
    parser.add_option("--author", help="Author of plugin, defaults to Curverider",
                      default="Curverider")
    parser.add_option("--version",
                      help="Version of plugin, defaults to 1.0. If "
                            "update mode is enabled, updates the version "
                            "correspondingly",
                      default="1.0")
    parser.add_option("--description", help="Description of plugin.",
                      default="None given")
    parser.add_option("--website",
                      help="Website corresponding to plugin",
                      default="http://www.elgg.org/")
    parser.add_option("--copyright",
                      help="Copyright regarding plugin",
                      default="(c) free")
    parser.add_option("--license",
                      help="License type of the plugin, defaults to GPLv2",
                      default="GNU Public License version 2")    
    parser.add_option("--package",
                      help="Identification of package relationship. "
                           "Defaults to None ",
                      default="None")
    return parser
    
if __name__ == '__main__':
    try:
        inst = DoIt()
        inst.add_option_parser( generate_options() )          
        inst.start( )
    except KeyboardInterrupt, e:
        pass
    except SystemExit, e:
        if e.code != 0:
            raise
    except:
        print_exc()

