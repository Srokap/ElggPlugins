<?php

// Generiere vom Übersetzungsbrowser. 

$german = array( 
	 'userpoints_standard:blog'  =>  "Punkte fürs bloggen:" , 
	 'userpoints_standard:group'  =>  "Punkte für Gruppe gründen:" , 
	 'userpoints_standard:page_top'  =>  "Punkte für News schreiben:" , 
	 'userpoints_standard:poll'  =>  "Punkte für Posting ein Voting" , 
	 'userpoints_standard:pollvote'  =>  "Punkte fürs Voting:" , 
	 'userpoints_standard:login'  =>  "Punkte fürs einloggen:" , 
	 'userpoints_standard:phototag'  =>  "Punkte für einpflegen eines Foto:" , 
	 'userpoints_standard:riverpost'  =>  "Punkte für Posting einer Statusnachricht:" , 
	 'userpoints_standard:thewire'  =>  "Punkte für Posting zu Twitter:" , 
	 'userpoints_standard:group_topic_post'  =>  "Punkte für posten einer Gruppennachricht:" , 
	 'userpoints_standard:invite'  =>  "Punkte für Freunde einladen:" , 
	 'userpoints_standard:login_threshold'  =>  "Die Zeitmenge fürs Einloggen in die megaUNITY" , 
	 'userpoints_standard:1hour'  =>  "1 Stunde" , 
	 'userpoints_standard:4hours'  =>  "4 Stunden" , 
	 'userpoints_standard:8hours'  =>  "8 Stunden" , 
	 'userpoints_standard:12hours'  =>  "12 Stunden" , 
	 'userpoints_standard:1day'  =>  "1 Tag" , 
	 'userpoints_standard:1week'  =>  "1 Woche" , 
	 'userpoints_standard:1month'  =>  "1 Monat" , 
	 'userpoints_standard:delete'  =>  "Löschen Punkte, wenn der Inhalt, der schon zugesprochen wurde, gelöscht wird?"
); 

add_translation('de', $german); 

?>