<?php
 
    $english = array(	
        'userpoints_standard:blog' => 'Points for posting a blog entry:',
        'userpoints_standard:group' => 'Points for starting a group:',
        'userpoints_standard:page_top' => 'Points for adding a page:',
        'userpoints_standard:comment' => 'Points for posting a comment:',
        'userpoints_standard:poll' => 'Points for posting a poll:',
        'userpoints_standard:pollvote' => 'Points for voting on a poll:',
        'userpoints_standard:login' => 'Points for logging in:',
        'userpoints_standard:phototag' => 'Points for logging tagging a photo:',
        'userpoints_standard:riverpost' => 'Points for posting to the river:',
        'userpoints_standard:thewire' => 'Points for posting to the wire:',
        'userpoints_standard:group_topic_post' => 'Points for posting a group topic:',
        'userpoints_standard:invite' => 'Points for inviting a friend:',
        'userpoints_standard:login_threshold' => 'The amount of time to pass before awarding login points again?',
        'userpoints_standard:1hour' => '1 Hour',
        'userpoints_standard:4hours' => '4 Hours',
        'userpoints_standard:8hours' => '8 Hours',
        'userpoints_standard:12hours' => '12 Hours',
        'userpoints_standard:1day' => '1 Day',
        'userpoints_standard:1week' => '1 Week',
        'userpoints_standard:1month' => '1 Month',
        'userpoints_standard:delete' => 'Delete points if the content they were awarded for is deleted?'
    );
 
    add_translation("en", $english);
 
?>
