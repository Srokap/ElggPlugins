<?php

    function userpoints_standard_init() {        
        register_plugin_hook('action', 'invitefriends/invite', 'userpoints_standard_invite');
        register_elgg_event_handler('login','user','userpoints_standard_login');
        register_elgg_event_handler('create','object', 'userpoints_standard_object');
        register_elgg_event_handler('delete','object', 'userpoints_standard_object');
        register_elgg_event_handler('delete','entity', 'userpoints_standard_object');
        register_elgg_event_handler('create','annotation','userpoints_standard_annotate_create');
        register_elgg_event_handler('create','group','userpoints_standard_group');
        register_elgg_event_handler('delete','group','userpoints_standard_group');
        //register_elgg_event_handler('delete','annotation','userpoints_standard_annotate_delete');
    }

    function userpoints_standard_object($event, $object_type, $object) {
        if (function_exists('userpoints_add')) {
            if ($event == 'create') {
                $subtype = get_subtype_from_id($object->subtype);
                if ($points = get_plugin_setting($subtype)) {
                    userpoints_add($_SESSION['user']->guid, $points, $subtype, $subtype, $object->guid);
                }
            } else if ($event == 'delete') {
                userpoints_delete($_SESSION['user']->guid, $object->guid);
            }
        }
    }

    function userpoints_standard_annotate_create($event, $object_type, $object) {
        if ($points = get_plugin_setting($object->name)) {
            if (function_exists('userpoints_add')) {
                $description = $object->name;
                userpoints_add($_SESSION['user']->guid, $points, $description, $object_type, $object->entity_guid);
            }
        }
    }
 
    function userpoints_standard_group($event, $object_type, $object) {
        if (function_exists('userpoints_add')) {
            if ($event == 'create') {
                if ($points = get_plugin_setting($object_type)) {
                    userpoints_add($_SESSION['user']->guid, $points, $object_type, $object_type, $object->guid);
                }
            } else if ($event == 'delete') {
                userpoints_delete($_SESSION['user']->guid, $object->guid);
            }
        }
    }

    function userpoints_standard_login() {

        // Check to see if the configured amount of time 
        // has passed before awarding more login points
        $user = get_user_by_username($_SESSION['user']->username);
        $diff = time() - $user->userpoints_login;
        if ($diff > get_plugin_setting('login_threshold')) {

            // The login threshold has been met so now add the points
            if (function_exists('userpoints_add')) {
                userpoints_add($_SESSION['user']->guid, get_plugin_setting('login'), 'Login');
                $user->userpoints_login = time();
            }
        }
    }
 
    function userpoints_standard_invite() {
        if (function_exists('userpoints_add')) {
            userpoints_add($_SESSION['user']->guid, get_plugin_setting('invite'), 'Invite');
        }
    }
 
    register_elgg_event_handler('init','system','userpoints_standard_init');       
?>
