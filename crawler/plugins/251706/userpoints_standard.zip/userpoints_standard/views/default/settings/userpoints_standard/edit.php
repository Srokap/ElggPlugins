<?php

?>
<p>
    <?php echo elgg_echo('userpoints_standard:blog'); ?>
    <?php echo elgg_view('input/text', array('internalname' => "params[blog]", 'value' => $vars['entity']->blog)); ?>
    <br><br>

    <?php echo elgg_echo('userpoints_standard:group'); ?>
    <?php echo elgg_view('input/text', array('internalname' => "params[group]", 'value' => $vars['entity']->group)); ?>
    <br><br>

    <?php echo elgg_echo('userpoints_standard:page_top'); ?>
    <?php echo elgg_view('input/text', array('internalname' => "params[page_top]", 'value' => $vars['entity']->page_top)); ?>
    <br><br>

    <?php echo elgg_echo('userpoints_standard:comment'); ?>
    <?php echo elgg_view('input/text', array('internalname' => "params[generic_comment]", 'value' => $vars['entity']->generic_comment)); ?>
    <br><br>

    <?php echo elgg_echo('userpoints_standard:riverpost'); ?>
    <?php echo elgg_view('input/text', array('internalname' => "params[riverpost]", 'value' => $vars['entity']->riverpost)); ?>
    <br><br>

    <?php echo elgg_echo('userpoints_standard:thewire'); ?>
    <?php echo elgg_view('input/text', array('internalname' => "params[thewire]", 'value' => $vars['entity']->thewire)); ?>
    <br><br>

    <?php echo elgg_echo('userpoints_standard:poll'); ?>
    <?php echo elgg_view('input/text', array('internalname' => "params[poll]", 'value' => $vars['entity']->poll)); ?>
    <br><br>

    <?php echo elgg_echo('userpoints_standard:pollvote'); ?>
    <?php echo elgg_view('input/text', array('internalname' => "params[pollvote]", 'value' => $vars['entity']->pollvote)); ?>
    <br><br>

    <?php echo elgg_echo('userpoints_standard:phototag'); ?>
    <?php echo elgg_view('input/text', array('internalname' => "params[phototag]", 'value' => $vars['entity']->phototag)); ?>
    <br><br>

    <?php echo elgg_echo('userpoints_standard:group_topic_post'); ?>
    <?php echo elgg_view('input/text', array('internalname' => "params[group_topic_post]", 'value' => $vars['entity']->group_topic_post)); ?>
    <br><br>

    <?php echo elgg_echo('userpoints_standard:login'); ?>
    <?php echo elgg_view('input/text', array('internalname' => "params[login]", 'value' => $vars['entity']->login)); ?>
    <br><br>

	<?php echo elgg_echo('userpoints_standard:login_threshold'); ?>
    <select name="params[login_threshold]">
        <option value="3600" <?php if ($vars['entity']->login_threshold) echo " selected=\"yes\" "; ?>><?php echo elgg_echo('userpoints_standard:1hour'); ?></option>
        <option value="14400" <?php if (!$vars['entity']->login_threshold) echo " selected=\"yes\" "; ?>><?php echo elgg_echo('userpoints_standard:4hours'); ?></option>
        <option value="28800" <?php if (!$vars['entity']->login_threshold) echo " selected=\"yes\" "; ?>><?php echo elgg_echo('userpoints_standard:8hours'); ?></option>
        <option value="43200" <?php if (!$vars['entity']->login_threshold) echo " selected=\"yes\" "; ?>><?php echo elgg_echo('userpoints_standard:12hours'); ?></option>
        <option value="86400" <?php if (!$vars['entity']->login_threshold) echo " selected=\"yes\" "; ?>><?php echo elgg_echo('userpoints_standard:1day'); ?></option>
        <option value="604800" <?php if (!$vars['entity']->login_threshold) echo " selected=\"yes\" "; ?>><?php echo elgg_echo('userpoints_standard:1week'); ?></option>
        <option value="2592000" <?php if (!$vars['entity']->login_threshold) echo " selected=\"yes\" "; ?>><?php echo elgg_echo('userpoints_standard:1month'); ?></option>
    </select>
    <br><br>

    <?php echo elgg_echo('userpoints_standard:invite'); ?>
    <?php echo elgg_view('input/text', array('internalname' => "params[invite]", 'value' => $vars['entity']->invite)); ?>
    <br><br>

    <?php echo elgg_echo('userpoints_standard:delete'); ?>
    <?php echo elgg_view('input/pulldown', array(
                             'internalname' => 'params[delete]',
                             'options_values' => array('1' => 'Yes', '0' => 'No'),
                             'value' => $vars['entity']->delete
                             )
                        );
    ?>
</p>
