<?php

	/**
	 * Elgg CSS
	 * The standard CSS file
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @copyright Curverider Ltd 2008
	 * @Stephen J O'Connor 2008
	 * @link http://elgg.org/
	 * 
	 * @uses $vars['wwwroot'] The site URL
	 */

?>

/* ***************************************
	RESET BASE STYLES
*************************************** */
html, body, div, span, applet, object, iframe,
h1, h2, h3, h4, h5, h6, p, blockquote, pre,
a, abbr, acronym, address, big, cite, code,
del, dfn, em, font, img, ins, kbd, q, s, samp,
small, strike, strong, sub, sup, tt, var,
dl, dt, dd, ol, ul, li,
fieldset, form, label, legend,
table, caption, tbody, tfoot, thead, tr, th, td {
	margin: 0;
	padding: 0;
	border: 0;
	outline: 0;
	font-weight: inherit;
	font-style: inherit;
	font-size: 100%;
	font-family: inherit;
	vertical-align: baseline;
}
/* remember to define focus styles! */
:focus {
	outline: 0;
}
ol, ul {
	list-style: none;
}
/* tables still need cellspacing="0" (for ie6) */
table {
	border-collapse: separate;
	border-spacing: 0;
}
caption, th, td {
	text-align: left;
	font-weight: normal;
	vertical-align: top;
}
blockquote:before, blockquote:after,
q:before, q:after {
	content: "";
}
blockquote, q {
	quotes: "" "";
}
.clearfloat { 
	clear:both;
    height:0;
    font-size: 1px;
    line-height: 0px;
}

/* ***************************************
	DEFAULTS
*************************************** */

/* elgg open source		blue 			#00578A */
/* elgg open source		dark blue 		#0588BC */
/* elgg open source		light yellow 	#FDFFC3 */


body {
	text-align:left;
	margin:0 auto;
	padding:0;
	background: #6fa1B2;
	font: 80%/1.4  "Lucida Grande", Verdana, sans-serif;
	color: #333333;
	background: #6fa1B2;
}
a {
	color: #00578A;
	text-decoration: none;
	-moz-outline-style: none;
	outline: none;
}
a:visited {
	/* color: #0588BC; */
}
a:hover {
	color: #0588BC;
	text-decoration: underline;
}
p {
	margin: 0px 0px 15px 0;
}
img {
	border: none;
}
ul {
	margin: 5px 0px 15px;
	padding-left: 20px;
}
ul li {
	margin: 0px;
}
ol {
	margin: 5px 0px 15px;
	padding-left: 20px;
}
ul li {
	margin: 0px;
}
form {
	margin: 0px;
	padding: 0px;
}
small {
	font-size: 90%;
}
h1, h2, h3, h4, h5, h6 {
	font-weight: bold;
	line-height: normal;
}
h1 { font-size: 1.8em; }
h2 { font-size: 1.5em; }
h3 { font-size: 1.2em; }
h4 { font-size: 1.0em; }
h5 { font-size: 0.9em; }
h6 { font-size: 0.8em; }


/* ***************************************
    PAGE LAYOUT - MAIN STRUCTURE
*************************************** */
#page_container {
	margin:0;
	padding:0;
	background: #6fa1b2;
}
#page_wrapper {
	width:998px;
	margin:0 auto;
	padding:0;
	min-height: 300px;
	background: rgba(242,234,191,0.95);
	border-right: 0px solid #333333;
	border-bottom: 0px solid #333333;
}

#layout_header {
	text-align:left;
	width:100%;
	height:67px;
	border-bottom:0px solid #00578A;
	background-image: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/header.jpg);
}
#wrapper_header {
	margin:0;
	padding:10px 20px 20px 20px;
}

#layout_canvas {
	margin:0;
	padding:0;
	min-height: 360px;
}


/* canvas layout: 1 column, no sidebar */
#one_column {
	width:918px;
	margin:20px;
	min-height: 360px;
	background: white;
	padding:20px;
	border-right: 1px solid #f5f5f5;
	border-bottom: 1px solid #f5f5f5;
}

/* canvas layout: 2 column left sidebar */
#two_column_left_sidebar {
	width:210px;
	margin:20px 0 20px 20px;
	min-height:360px;
	float:left;
	padding:0px;
	border-bottom:1px solid #f5f5f5;
	border-right:1px solid #f5f5f5;
	background-color: #ffffff;
}

#two_column_left_sidebar_maincontent {
	width:685px;
	margin:20px;
	min-height: 360px;
	float:left;
	background: white;
	padding:20px;
	border-bottom:1px solid #f5f5f5;
	border-right:1px solid #f5f5f5;
}

/* canvas layout: 2 column right sidebar */
#two_column_right_sidebar_maincontent {
	width:685px;
	margin:20px;
	min-height:360px;
	float:left;
	background: white;
	padding:20px;
	border-bottom:1px solid #f5f5f5;
	border-right:1px solid #f5f5f5;
}

#two_column_right_sidebar {
	width:170px;
	margin:20px 20px 20px 0;
	min-height: 360px;
	float:left;
	background: white;
	padding:20px;
	border-bottom:1px solid #f5f5f5;
	border-right:1px solid #f5f5f5;
}

/* canvas layout: widgets (profile and dashboard) */
#widgets_left {
	width:306px;
	margin:20px;
	min-height:360px;
	/* background: white; */
	padding:0;
}
#widgets_middle {
	width:306px;
	margin:20px 0 20px 0;
	/* min-height:360px; */
	/* background: white; */
	padding:0;
}
#widgets_right {
	width:306px;
	margin:20px 20px 20px 20px;
	/* min-height:360px; */
	float:left;
	/* background: white; */
	padding:0;
}
#widget_table td {
	border:0;
	padding:0;
	margin:0;
	text-align: left;
	vertical-align: top;
}


/* IE 6 fixes */
* html #widgets_left { 
	height:360px;
}
* html #widgets_middle { 
	height:360px;
}
* html #widgets_right { 
	height:360px;
	float:none;
}

/* IE6 layout fixes */
* html #profile_info_column_left {
	margin:0 10px 0 0;
	width:200px;
}
* html #two_column_left_sidebar {
	width:210px;
	margin:20px 10px 20px 10px;
}
* html #two_column_left_sidebar_maincontent {
	width:685px;
	margin:20px 10px 20px 10px;
}
* html a.toggle_customise_edit_panel { 
	float:none;
	clear:none;
	color: #00578A;
	background: white;
	border:1px solid #f5f5f5;
	padding: 5px 10px 5px 10px;
	margin:20px 20px 0px 20px;
	width:284px;
	display:block;
	text-align: left;
}

* html #dashboard_info {
	width:585px;
}

#layout_spotlight {
	padding:0;
	margin:0;
}
#wrapper_spotlight {
	margin:0;
	padding:0;
	height:auto;
}
/* ***************************************
	SPOTLIGHT
*************************************** */
/* IE7 */
*:first-child+html #wrapper_spotlight .collapsable_box_content {
	width:958px;
}

#wrapper_spotlight #spotlight_table h2 {
	color:#00578A;
	font-size:1.25em;
	line-height:1.2em;
}
#wrapper_spotlight #spotlight_table li {
	list-style: square;
	line-height: 1.2em;
	margin:5px 20px 5px 0;
	color:#00578A;
}
#wrapper_spotlight .collapsable_box_content  {
	margin:0;
	padding:20px 20px 10px 20px;
	background: #fcfcfd url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/spotlight_back.gif) repeat-x left top;
	min-height:60px;
	border:none;
}
#layout_spotlight .collapsable_box_content p {
	padding:0;
}
#wrapper_spotlight .collapsable_box_header  {
	border-left: none;
	border-right: none;
}
/* ***************************************
	FOOTER
*************************************** */
#layout_footer {
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/footer_back.gif) repeat-x left top;
	height:80px;
}
#layout_footer table {
   margin:0 0 0 20px;
}
#layout_footer a, #layout_footer p {
   color:white;
   margin:0;
}
#layout_footer .footer_toolbar_links {
	text-align:right;
	padding:15px 0 0 0;
	font-size:1.2em;
}
#layout_footer .footer_legal_links {
	text-align:right;
}


/* ***************************************
  HORIZONTAL ELGG TOPBAR
*************************************** */
#elgg_topbar {
	background:#333333 url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/toptoolbar_background.gif) repeat-x top left;
	color:#eeeeee;
	border-bottom:1px solid #000000;
	min-width:998px;
	position:relative;
	width:100%;
	height:24px;
}

#elgg_topbar_container_left {
	float:left;
	height:24px;
	left:0px;
	top:0px;
	position:absolute;
	text-align:left;
	width:60%;
}

#elgg_topbar_container_right {
	float:right;
	height:24px;
	position:absolute;
	right:0px;
	top:0px;
	/* width:120px;*/
	text-align:right;
}

#elgg_topbar_container_search {
	float:right;
	height:21px;
	/*width:280px;*/
	position:relative;
	right:120px;
	text-align:right;
	margin:3px 0 0 0;
}

#elgg_topbar_container_left .toolbarimages {
	float:left;
	margin-right:20px;
}
#elgg_topbar_container_left .toolbarlinks {
	margin:0 0 10px 0;
	float:left;
}
#elgg_topbar_container_left .toolbarlinks2 {
	margin:3px 0 0 0;
	float:left;
}
#elgg_topbar_container_left a.loggedinuser {
	color:#eeeeee;
	font-weight:bold;
	margin:0 0 0 5px;
}
#elgg_topbar_container_left a.pagelinks {
	color:white;
	margin:0 15px 0 5px;
	display:block;
	padding:3px;
}
#elgg_topbar_container_left a.pagelinks:hover {
	background: #00578A;
	text-decoration: none;
}
#elgg_topbar_container_left a.privatemessages {
	background:transparent url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/toolbar_messages_icon.gif) no-repeat left 2px;
	padding:0 0 4px 16px;
	margin:0 15px 0 5px;
	cursor:pointer;
}
#elgg_topbar_container_left a.privatemessages:hover {
	text-decoration: none;
	background:transparent url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/toolbar_messages_icon.gif) no-repeat left -36px;
}
#elgg_topbar_container_left a.privatemessages_new {
	background:transparent url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/toolbar_messages_icon.gif) no-repeat left -17px;
	padding:0 0 0 18px;
	margin:0 15px 0 5px;
	color:white;
}
/* IE6 */
* html #elgg_topbar_container_left a.privatemessages_new { background-position: left -18px; } 
/* IE7 */
*+html #elgg_topbar_container_left a.privatemessages_new { background-position: left -18px; } 

#elgg_topbar_container_left a.privatemessages_new:hover {
	text-decoration: none;
}

#elgg_topbar_container_left a.usersettings {
	margin:0 0 0 20px;
	color:#999999;
	padding:3px;
}
#elgg_topbar_container_left a.usersettings:hover {
	color:#eeeeee;
}


#elgg_topbar_container_left img {
	margin:2px 0 0 5px;
}
#elgg_topbar_container_left .user_mini_avatar {
	border:1px solid #eeeeee;
	margin:0 0 0 20px;
}
#elgg_topbar_container_right {
	padding:3px 0 0 0;
}
#elgg_topbar_container_right a {
	color:#eeeeee;
	margin:0 5px 0 0;
	background:transparent url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/elgg_toolbar_logout.gif) no-repeat top right;
	padding:0 21px 0 0;
	display:block;
	height:20px;
}
/* IE6 fix */
* html #elgg_topbar_container_right a { 
	width: 120px;
}

#elgg_topbar_container_right a:hover {
	background-position: right -21px;
}

#elgg_topbar_panel {
	background:#333333;
	color:#eeeeee;
	height:200px;
	width:100%;
	padding:10px 20px 10px 20px;
	display:none;
	position:relative;
}

#searchform input.search_input {
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	background-color:#FFFFFF;
	border:1px solid #BBBBBB;
	color:#999999;
	font-size:12px;
	font-weight:bold;
	margin:0pt;
	padding:2px;
	width:180px;
	
	height:12px;
}
#searchform input.search_submit_button {
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	color:#333333;
	background: #f5f5f5;
	border:none;
	font-size:12px;
	font-weight:bold;
	margin:0px;
	padding:2px;
	width:auto;
	height:18px;
	cursor:pointer;
}
#searchform input.search_submit_button:hover {
	color:#ffffff;
	background: #0588BC;
}

/* ***************************************
	TOP BAR - VERTICAL TOOLS MENU
*************************************** */
#topbardropdownmenu, #topbardropdownmenu ul {
	margin:0;
	padding:0;
	display:inline;
	float:left;
	list-style-type: none;
	z-index: 99999999;
}
#topbardropdownmenu {
	margin:0pt 15px 0pt 5px;
}
#topbardropdownmenu ul {
	/* width:134px; */
}
/* Tools link in top menu */
#topbardropdownmenu a, #topbardropdownmenu a:visited {
	display:block;
	padding:3px 13px 3px 3px;
	text-decoration:none;
	color:white;
}
#topbardropdownmenu li ul a {
	width:120px;
	height:auto;
	float:left;
}

/* menu list items */
#topbardropdownmenu li {float:left; position:relative; background:#f5f5f5;}
#topbardropdownmenu ul a {
	border-left:1px solid #f5f5f5;
	border-right:1px solid #333333;
	color:#00578A !important;
	padding:2px 6px 2px 6px !important;
	background: #DEDEDE !important;
	border-top:1px solid #f5f5f5;
	border-bottom:1px solid #999999;
}

/* IE7 */
#topbardropdownmenu li:hover {position:relative;}
/* Make the Tools nav color persist */
#topbardropdownmenu li:hover > a {background: #00578A url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/toolbar_arrow.png) no-repeat right -18px;}
#topbardropdownmenu li ul {display:none;width:134px !important;}
#topbardropdownmenu li:hover > ul {
	display:block;
	position:absolute; 
	top:-11px;
	left:80px;
	padding:10px 30px 30px 30px;
	background:transparent url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/spacer.gif); 
	/* width:134px; */
}
/* Position the first sub level beneath the top level links */
#topbardropdownmenu > li:hover > ul {
	left:-30px;
	top:16px;
}
#topbardropdownmenu li a:active, #topbardropdownmenu li a:focus {
	background:#00578A;
	color:white;
}
#topbardropdownmenu li.drop {
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/toolbar_arrow.png) no-repeat right 9px;	
}
/* dropdown list links hover */
#topbardropdownmenu li.drop ul li a:hover {
	color:white !important;
	background: #00578A !important;
	border-left:1px solid #99ccff;
	border-top:1px solid #99ccff;	
}
/* IE6 ONLY - make the sublevels appear */
* html #topbardropdownmenu li ul {visibility:hidden; display:block; position:absolute; top:-11px; left:80px; padding:10px 30px 30px 30px; background:transparent url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/spacer.gif);}
#topbardropdownmenu li a:hover ul {visibility:visible; left:-30px; top:14px; lef\t:-31px; to\p:15px;}
#topbardropdownmenu table {position:absolute; border-collapse:collapse; top:0; left:0; z-index:99999; font-size:1em;}
* html #topbardropdownmenu li.drop {background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/toolbar_arrow_ie.gif) no-repeat right 9px;}
* html #topbardropdownmenu li a:hover {position:relative; background:#00578A url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/toolbar_arrow_ie.gif) no-repeat right -18px;}


/* ***************************************
  SYSTEM MESSSAGES
*************************************** */
.messages {
    border:1px solid #00cc00;
    background:#ccffcc;
    color:#000000;
    padding:3px 10px 3px 10px;
    margin:20px 20px 0px 20px;
    z-index: 9999;
    position:absolute;
    /* width:611px; */
    width:936px;
}
.messages_error {
    border:1px solid #D3322A;
    background:#F7DAD8;
    color:#000000;
    padding:3px 10px 3px 10px;
    margin:20px 20px 0px 20px;
    z-index: 9999;
    position:absolute;
    width:936px;
}


/* ***************************************
  COLLAPSABLE BOXES
*************************************** */

.collapsable_box {
	margin: 0 0 20px 0;
	/* background: white; */
	height:auto;
}
/* IE6 fix */
* html .collapsable_box  { 
	height:10px;
}
.collapsable_box_header {
	color: #00578A;
	background: #f5f5f5;
	border-top:2px solid #00578A;
	padding: 5px 10px 5px 10px;
	margin:0;
	
	border-left: 1px solid #f5f5f5;
	border-right: 1px solid #f5f5f5;
	border-bottom: 1px solid #f5f5f5;
}
.collapsable_box_content {
	padding: 10px;
	margin:0;
	height:auto;
	background: white;
	border-left: 1px solid #f5f5f5;
	border-right: 1px solid #f5f5f5;
	border-bottom: 1px solid #f5f5f5;
}
.collapsable_box_editpanel {
	display: none;
	background: #dedede;
	padding:5px 10px 5px 10px;
	/* font-size: 9px;*/
}
.collapsable_box_header a.toggle_box_contents {
	color: #00578A;
	cursor:pointer;
	font-family: Arial, Helvetica, sans-serif;
	font-size:20px;
	font-weight: bold;
	text-decoration:none;
	float:right;
	margin: 0;
	margin-top: -7px;
}
.collapsable_box_header a.toggle_box_edit_panel {
	color: #00578A;
	cursor:pointer;
	font-size:9px;
	text-transform: uppercase;
	text-decoration:none;
	font-weight: normal;
	float:right;
	margin: 3px 10px 0 0;
}
.collapsable_box_editpanel label {
	font-weight: normal;
	font-size: 100%;
}
/* used for collapsing a content box */
.display_none {
	display:none;
}
/* used on spotlight box - to cancel default box margin */
.no_space_after {
	margin: 0 0 0 0;
}



/* ***************************************
	GENERAL FORM ELEMENTS
*************************************** */
label {
	font-weight: bold;
	color:#333333;
	font-size: 140%;
}
input {
	font: 120% Arial, Helvetica, sans-serif;
	padding: 5px;
	border: 1px solid #f5f5f5;
	color:#666666;
}
textarea {
	font: 120% Arial, Helvetica, sans-serif;
	border: solid 1px #f5f5f5;
	padding: 5px;
	color:#666666;
}
textarea:focus, input[type="text"]:focus {
	border: solid 1px #00578A;
	background: #e4ecf5;
	color:#333333;
}

.submit_button {
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #ffffff;
	background:#00578A;
	border: 1px solid #00578A;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	width: auto;
	height: 25px;
	padding: 2px 6px 2px 6px;
	margin:10px 0 10px 0;
	cursor: pointer;
}
.submit_button:hover, input[type="submit"]:hover {
	background: #0588BC;
}

input[type="submit"] {
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #ffffff;
	background:#00578A;
	border: 1px solid #00578A;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	width: auto;
	height: 25px;
	padding: 2px 6px 2px 6px;
	margin:10px 0 10px 0;
	cursor: pointer;
}

.cancel_button {
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #999999;
	background:#dddddd;
	border: 1px solid #999999;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	width: auto;
	height: 25px;
	padding: 2px 6px 2px 6px;
	margin:10px 0 10px 10px;
	cursor: pointer;
}
.cancel_button:hover {
	background: #f5f5f5;
}

.input-text,
.input-tags,
.input-url,
.input-textarea {
	width:98%;
}

.input-textarea {
	height: 200px;
}


/* ***************************************
	LOGIN / REGISTER
*************************************** */
#login-box {
	margin: 10px;
    text-align:left;
    padding:10px;
    background: #ffffff;
}
#login-box .login-textarea {
	width:155px;
}
#login-box label,
#register-box label {
	font-size: 1.2em;
	color:gray;
}
#login-box input[type="text"],
#login-box input[type="password"],
#register-box input[type="text"],
#register-box input[type="password"] {
	margin:0 0 10px 0;
}

#login-box-openid {
	margin: 10px;
    text-align:left;
    padding:10px;
    background: #ffffff;
}
#login-box h2,
#login-box-openid h2,
#register-box h2,
#add-box h2 {
	background:#f5f5f5;
	border-top:2px solid #00578A;
	color:#0588BC;
	font-size:1.35em;
	line-height:1.2em;
	margin:0pt 0pt 5px;
	padding:5px;
}

#register-box {
    text-align:left;
    border:1px solid #ddd;
    width:400px;
    padding:20px;
    background: #ffffff;
    margin:20px;
}


/* ***************************************
	MAIN CONTENT ELEMENTS
*************************************** */
#wrapper_header h1 {
	margin:10px 0 0 0;
	letter-spacing: -0.03em;
}

/* title within main content area */
.page_title {
	padding:0px 10px 20px 0px;
}


.elggtoolbar .elggtoolbar_header h1,
.collapsable_box_header h1 {
	/*color: #00578A;*/
	color: #0588BC;
	font-size:1.25em;
	line-height: 1.2em;
}




/* ***************************************
	PROFILE
*************************************** */
#profile_info {
	margin:20px 0px 0 20px;
	padding:20px;
	border-bottom:1px solid #f5f5f5;
	border-right:1px solid #f5f5f5;
	background: white;
}
#profile_info_column_left {
	float:left;
	padding: 0;
	margin:0 20px 0 0;
}
#profile_info_column_middle {
	float:left;
	width:368px;
	padding: 0;
}
#profile_info_column_right {
	width:590px;
	margin:0 0 0 0;
	padding: 0;
}
#dashboard_info {
	margin:20px 0px 0 20px;
	padding:20px;
	border-bottom:1px solid #f5f5f5;
	border-right:1px solid #f5f5f5;
	background: white;
}


#profile_menu_wrapper {
	margin:10px 0 10px 0;
	width:200px;
}
#profile_menu_wrapper p {
	border-bottom:1px solid #f5f5f5;
}
#profile_menu_wrapper p:first-child {
	border-top:1px solid #f5f5f5;
}
#profile_menu_wrapper a {
	display:block;
	/* width:200px; */	
	padding:0 0 0 3px;
}
#profile_menu_wrapper a:hover {
	color:#ffffff;
	background:#00578A;
	text-decoration:none;
}
p.user_menu_friends, p.user_menu_profile, 
p.user_menu_removefriend, 
p.user_menu_friends_of {
	margin:0;
}
#profile_menu_wrapper .user_menu_admin {
	border-top:none;
}

#profile_info_column_middle p {
	margin:7px 0 7px 0;
	padding:2px 4px 2px 4px;
}
/* profile owner name */
#profile_info_column_middle h2 {
	padding:0 0 14px 0;
	margin:0;
}
#profile_info_column_middle .odd {
	background:#f5f5f5;
}
#profile_info_column_right p {
	margin:0 0 7px 0;
}
#profile_info_column_right .profile_aboutme_title {
	margin:0;
	padding:0;
	line-height:1em;
}
/* edit profile button */
.profile_info_edit_buttons {
	float:right;
	margin:0  !important;
	padding:0 !important;
	font-size: 90%;
}

/* ***************************************
	RIVER
*************************************** */
#river {
	border-top:1px solid #dddddd;
}
.river_item p {
	margin:0;
	padding:2px 0 0 20px;
	line-height:1.1em;
	min-height:17px;
}
.river_item {
	border-bottom:1px solid #dddddd;
	padding:2px 0 2px 0;
}
.river_item_time {
	font-size:90%;
	color:#666666;
}
/* IE6 fix */
* html .river_item p { 
	padding:3px 0 3px 20px;
}
/* IE7 */
*:first-child+html .river_item p {
	min-height:17px;
}
.river_user_update {
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/river_icons/river_icon_profile.gif) no-repeat left -1px;
}
.river_user_profileupdate {
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/river_icons/river_icon_profile.gif) no-repeat left -1px;
}
.river_user_profileiconupdate {
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/river_icons/river_icon_profile.gif) no-repeat left -1px;
}
.river_annotate {
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/river_icons/river_icon_comment.gif) no-repeat left -1px;
}
.river_create {
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/river_icons/dummy_river_icon.gif) no-repeat left -1px;
}
.river_bookmarks_create {
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/river_icons/river_icon_bookmarks.gif) no-repeat left -1px;
}
.river_status_create {
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/river_icons/river_icon_status.gif) no-repeat left -1px;
}
.river_file_create {
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/river_icons/river_icon_files.gif) no-repeat left -1px;
}
.river_widget_create {
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/river_icons/river_icon_plugin.gif) no-repeat left -1px;
}
.river_forums_create {
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/river_icons/river_icon_forum.gif) no-repeat left -1px;
}
.river_forums_update {
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/river_icons/river_icon_forum.gif) no-repeat left -1px;
}
.river_widget_update {
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/river_icons/river_icon_plugin.gif) no-repeat left -1px;	
}
.river_blog_create {
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/river_icons/river_icon_blog.gif) no-repeat left -1px;
}
.river_blog_update {
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/river_icons/river_icon_blog.gif) no-repeat left -1px;
}
.river_forumtopic_create {
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/river_icons/river_icon_forum.gif) no-repeat left -1px;
}
.river_relationship_friend_create {
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/river_icons/river_icon_friends.gif) no-repeat left -1px;
}
.river_relationship_member_create {
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/river_icons/river_icon_forum.gif) no-repeat left -1px;
}

/* ***************************************
	SEARCH LISTINGS	
*************************************** */
.search_listing {
	display: block;
	background-color: #eee;
	padding: 5px;
	margin-bottom: 10px;
}

.search_listing_icon {
	float:left;
}
.search_listing_icon img {
	width: 40px;
}
.search_listing_icon .avatar_menu_button img {
	width: 15px;
}
	
.search_listing_info {
	margin-left: 50px;
	min-height: 40px;
}
/* IE 6 fix */
* html .search_listing_info {
	height:40px;
}
.search_listing_info p {
	margin:0 0 3px 0;
	line-height:1.2em;
}
.search_listing_info p.owner_timestamp {
	margin:0;
	padding:0;
	color:#666666;
	font-size: 90%;
}

table.search_gallery {
	border-spacing: 5px;
	margin:0 0 20px 0;
	background: #f5f5f5;
}
.search_gallery td {
	padding: 5px;
}

.search_gallery_item {
	border:1px dotted silver;
    background-color: white;
}
.search_gallery_item:hover {
	border:1px dotted black;
}

.search_gallery_item .search_listing {
	background: none;
	text-align: center;
}

.search_gallery_item .search_listing_header {
	text-align: center;
}

.search_gallery_item .search_listing_icon {
	position: relative;
	text-align: center;
}

.search_gallery_item .search_listing_info {
	margin: 5px;
}

.search_gallery_item .search_listing_info p {
	margin: 5px;
	margin-bottom: 10px;
}

.search_gallery_item .search_listing {
	background: none;
	text-align: center;
}

.search_gallery_item .search_listing_icon {
	position: absolute;
	margin-bottom: 20px;
}

.search_gallery_item .search_listing_info {
	margin: 5px;
}

.search_gallery_item .search_listing_info p {
	margin: 5px;
	margin-bottom: 10px;
}


/* ***************************************
	FRIENDS
*************************************** */
/* friends widget */
#widget_friends_list {
	display:table;
	width:100%;
}
.widget_friends_singlefriend {
	float:left;
	margin:0 5px 5px 0;
}


/* ***************************************
	ADMIN AREA - PLUGIN SETTINGS
*************************************** */
.plugin_details {
	margin:0 0 10px 0;
	padding:5px 10px 5px 10px;
}
.active {
	border:1px solid #00cc00;
    background:#ccffcc;
}
.not-active {
    border:1px solid #D3322A;
    background:#F7DAD8;
}
.plugin_details p {
	margin:0;
	padding:4px 0 0 0;
}
.plugin_details a.manifest_details {
	cursor:pointer;
	font-size:80%;
}
.not-active .admin_plugin_enable_disable a {
	float:right;
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #ffffff;
	background:#00578A;
	border: 1px solid #00578A;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	width: auto;
	padding: 4px;
	margin:5px 0 0 0;
	cursor: pointer;
}
.not-active .admin_plugin_enable_disable a:hover {
	background: #0588BC;
}
.active .admin_plugin_enable_disable a {
	float:right;
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #ffffff;
	background:#999999;
	border: 1px solid #999999;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	width: auto;
	padding: 4px;
	margin:5px 0 0 0;
	cursor: pointer;
}
.active .admin_plugin_enable_disable a:hover {
	background: #333333;
}
.pluginsettings {
	margin:20px 0 0 0;
}
.pluginsettings h3 {
	padding:0 0 5px 0;
	margin:0 0 5px 0;
	border-bottom:1px solid #999999;
}
#updateclient_settings h3 {
	padding:0;
	margin:0;
	border:none;
}

/* ***************************************
	GENERIC COMMENTS
*************************************** */
.generic_comment_owner {
	font-size: 90%;
	color:#666666;
}

.generic_comment {
	margin-bottom: 10px;
	padding-bottom: 10px;
}

.generic_comment_icon {
	float:left;
}

.generic_comment_details {
	margin-left: 60px;
	border-bottom: 1px solid #aaaaaa;
}

.generic_comment_owner {
	color:#666666;
	margin: 0px;
	font-size:90%;
}

	
/* ***************************************
  PAGE-OWNER BLOCK
*************************************** */
#owner_block {
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/owner_block_back.jpg) no-repeat left top;
	padding:10px;
	border-bottom:1px dashed #f5f5f5;
}
#owner_block_icon {
	float:left;
	margin:0 10px 0 0;
}
#owner_block_rss_feed,
#owner_block_odd_feed,
#owner_block_bookmark_this,
#owner_block_report_this {
	padding:2px 0 3px 0;
}
#owner_block_report_this {
	border-bottom:1px solid #f5f5f5;
}
#owner_block_rss_feed a {
	font-size: 90%;
	color:#999999;
	padding:0 0 4px 20px;
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/icon_rss.gif) no-repeat left top;
}
#owner_block_odd_feed a {
	font-size: 90%;
	color:#999999;
	padding:0 0 4px 20px;
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/icon_odd.gif) no-repeat left top;
}
#owner_block_bookmark_this a {
	font-size: 90%;
	color:#999999;
	padding:0 0 4px 20px;
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/icon_bookmarkthis.gif) no-repeat left top;
}
#owner_block_report_this a {
	font-size: 90%;
	color:#999999;
	padding:0 0 4px 20px;
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/icon_reportthis.gif) no-repeat left top;
}
#owner_block_rss_feed a:hover,
#owner_block_odd_feed a:hover,
#owner_block_bookmark_this a:hover,
#owner_block_report_this a:hover {
	color: #0588BC;
}

#owner_block_desc {
	padding:4px 0 4px 0;
	margin:0 0 0 0;
	line-height: 1.2em;
	border-bottom:1px solid #f5f5f5;
	color:#666666;
}
#owner_block_content {
	margin:0 0 4px 0;
	padding:3px 0 0 0;
	min-height:35px;
	font-weight: bold;
}
.ownerblockline {
	padding:0;
	margin:0;
	border-bottom:1px solid #f5f5f5;
	height:1px;
}
#owner_block_submenu {
	margin:20px 0 20px 0;
	padding: 0;
	background-color: ffffff;
	/* border-bottom: 1px solid #f5f5f5; */	
	width:100%;
}

#owner_block_submenu ul {
	list-style: none;
	padding: 0;
	margin: 0;
}
#owner_block_submenu ul li.selected a {
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/owner_block_menu_arrow.gif) no-repeat left 6px;
	padding-left:10px;
}
#owner_block_submenu ul li a {
	text-decoration: none;
	display: block;
	padding: 0;
	margin: 0;
	color:#00578A;
	padding:4px 6px 4px 10px;
	border-top: 1px solid #f5f5f5;
	font-weight: bold;
	line-height: 1.1em;
}

#owner_block_submenu ul li a:hover {
	color:white;
	background: #00578A;
}

/* IE 6 + 7 menu arrow position fix */
* html #owner_block_submenu ul li.selected a {
	background-position: left 10px;
}
*:first-child+html #owner_block_submenu ul li.selected a {
	background-position: left 8px;
}

#owner_block_submenu .submenu_group {
	border-bottom: 1px solid #f5f5f5;
	margin:22px 0 0 0;
	background: #ffffff;
}

/* filetypes filter menu */
#owner_block_submenu .submenu_group .submenu_group_filetypes ul li a {
	color:#666666;
}
#owner_block_submenu .submenu_group .submenu_group_filetypes ul li.selected a {
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/owner_block_menu_dot.gif) no-repeat left 7px;
}
#owner_block_submenu .submenu_group .submenu_group_filetypes ul li a:hover {
	color:white;
	background: #999999;
}

/* pages actions menu */
#owner_block_submenu .submenu_group .submenu_group_pagesactions ul li a {
	color:#666666;
}
#owner_block_submenu .submenu_group .submenu_group_pagesactions ul li.selected a {
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/owner_block_menu_dot.gif) no-repeat left 7px;
}
#owner_block_submenu .submenu_group .submenu_group_pagesactions ul li a:hover {
	color:white;
	background: #999999;
}


/* ***************************************
	PAGINATION
*************************************** */
.pagination {
	margin:10px 0 20px 0;
	/* display: table; */
}

.pagination .pagination_number {
	display:block;
	float:left;
	background:#ffffff;
	border:1px solid #00578A;
	text-align: center;
	color:#00578A;
	font-size: 12px;
	font-weight: normal;
	margin:0 6px 0 0;
	padding:0px 4px;
	cursor: pointer;
}
.pagination .pagination_number:hover {
	background:#00578A;
	color:white;
	text-decoration: none;
}
.pagination .pagination_more {
	display:block;
	float:left;
	background:#ffffff;
	border:1px solid #ffffff;
	text-align: center;
	color:#00578A;
	font-size: 12px;
	font-weight: normal;
	margin:0 6px 0 0;
	padding:0px 4px;
}

.pagination .pagination_previous,
.pagination .pagination_next {
	display:block;
	float:left;
	border:1px solid #00578A;
	color:#00578A;
	text-align: center;
	font-size: 12px;
	font-weight: normal;
	margin:0 6px 0 0;
	padding:0px 4px;
	cursor: pointer;
}
.pagination .pagination_previous:hover,
.pagination .pagination_next:hover {
	background:#00578A;
	color:white;
	text-decoration: none;
}
.pagination .pagination_currentpage {
	display:block;
	float:left;
	background:#00578A;
	border:1px solid #00578A;
	text-align: center;
	color:white;
	font-size: 12px;
	font-weight: bold;
	margin:0 6px 0 0;
	padding:0px 4px;
	cursor: pointer;
}



	
/* ***************************************
	FRIENDS COLLECTIONS ACCORDIAN
*************************************** */	
ul#friends_collections_accordian {
	margin: 0 0 0 0;
	padding: 0;
	border-bottom:1px solid #f5f5f5;
}
#friends_collections_accordian li {
	margin: 0 0 0 0;
	padding: 0;
	list-style-type: none;
	color: #666666;
}
#friends_collections_accordian li h2 {
	background:#efefef;
	color: #999999;
	padding:4px 2px 4px 6px;
	margin:0;
	border-top:1px solid #f5f5f5;
	font-size:1.2em;
	cursor:pointer;
}
#friends_collections_accordian li h2:hover {
	background:#00578A;
	color:white;
}

#friends_collections_accordian .friends_picker {
	background:white;
	padding:0;
	display:none;
}
#friends_collections_accordian .friends_collections_controls {
	font-size:70%;
	float:right;
}
#friends_collections_accordian .friends_collections_controls a {
	color:#999999;
	font-weight:normal;
}

div.expandall {
	margin: 20px 0 0 0;
	padding:0;
}
div.expandall p {
	cursor:pointer;
	color:#999999;
	text-align:right;
	margin: 0;
	padding:0;
}
	
/* ***************************************
	FRIENDS PICKER SLIDER
*************************************** */		
.friendsPicker_container h3 { font-size:3em; text-align: left; margin:0 0 20px 0; color:#999999; }

.friendsPicker .friendsPicker_container .panel ul {
	text-align: left;
	margin: 0;
	padding:0;
}

.friendsPicker_wrapper {
	margin: 0;
	padding:0;
	position: relative;
	width: 100%;
}

.friendsPicker {
	position: relative;
	overflow: hidden; 
	margin: 0;
	padding:0;
	width: 685px;
	height: 300px;
	/*clear: right;*/
	background: white;
}

.friendsPicker .friendsPicker_container { /* long container used to house end-to-end panels. Width is calculated in JS  */
	position: relative;
	left: 0;
	top: 0;
	width: 100%;
	list-style-type: none;
	/* -moz-user-select: none; */
}

.friendsPicker .friendsPicker_container .panel {
	float:left;
	height: 100%;
	position: relative;
	width: 685px;
	margin: 0;
	padding:0;
}

.friendsPicker .friendsPicker_container .panel .wrapper {
	margin: 0;
	padding: 10px;
	background: #efefef;
	min-height: 230px;
}

.friendsPickerNavigation {
	margin: 0 0 10px 0;
	padding:0;
}

.friendsPickerNavigation ul {
	list-style: none;
	padding-left: 0;
}

.friendsPickerNavigation ul li {
	float: left;
	margin:0;
	background:white;
}

.friendsPickerNavigation a {
	font-weight: bold;
	text-align: center;
	background: white;
	color: #999999;
	text-decoration: none;
	display: block;
	padding: 0;
	width:20px;
}

.tabHasContent {
	background: white; color:#333333 !important;
}

.friendsPickerNavigation li a:hover {
	background: #333333;
	color:white !important;
}

.friendsPickerNavigation li a.current {
	background: #00578A;
	color:white !important;
}

.friendsPickerNavigationAll {
	margin:0px 0 0 20px;
	float:left;
}
.friendsPickerNavigationAll a {
	font-weight: bold;
	text-align: left;
	font-size:0.8em;
	background: white;
	color: #999999;
	text-decoration: none;
	display: block;
	padding: 0 4px 0 4px;
	width:auto;
}
.friendsPickerNavigationAll a:hover {
	background: #00578A;
	color:white;
}

.friendsPickerNavigationL, .friendsPickerNavigationR {
	position: absolute;
	top: 46px;
	text-indent: -9000em;
}

.friendsPickerNavigationL a, .friendsPickerNavigationR a {
	display: block;
	height: 43px;
	width: 43px;
}

.friendsPickerNavigationL {
	right: 58px;
	z-index:1;
}

.friendsPickerNavigationR {
	right: 20px;
	z-index:1;
}

.friendsPickerNavigationL {
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/friends_picker_arrow_left.gif") no-repeat center;
}

.friendsPickerNavigationR {
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/friends_picker_arrow_right.gif") no-repeat center;
}	

.friends_collections_controls a.delete_collection {
	display:block;
	cursor: pointer;
	width:14px;
	height:14px;
	margin:0 3px 0 0;
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/icon_customise_remove.png") no-repeat 0 0;
}
.friends_collections_controls a.delete_collection:hover {
	background-position: 0 -16px;
}


/* picker tabbed navigation */
#friendsPickerNavigationTabs {
	margin:10px 0 10px 0;
	padding: 0;
	border-bottom: 1px solid #f5f5f5;
	display:table;
	width:100%;
}

#friendsPickerNavigationTabs ul {
	list-style: none;
	padding: 0;
	margin: 0;
}

#friendsPickerNavigationTabs li {
	float: left;
	border: 1px solid #ffffff;
	border-bottom-width: 0;
	margin: 0;
}

#friendsPickerNavigationTabs a {
	text-decoration: none;
	display: block;
	padding: 0.22em 1em;
	color: #666666;
	text-align: center;
}

#friendsPickerNavigationTabs a:hover {
	color: #00578A;
}

#friendsPickerNavigationTabs .selected {
	border-color: #f5f5f5;
}

#friendsPickerNavigationTabs .selected a {
	position: relative;
	top: 1px;
	background: white;
	color: #00578A;
}
	
	

	
/* ***************************************
  WIDGET PICKER (PROFILE & DASHBOARD)
*************************************** */
/* 'edit page' button */
a.toggle_customise_edit_panel { 
	float:right;
	clear:right;
	color: #00578A;
	background: white;
	border:1px solid #f5f5f5;
	padding: 5px 10px 5px 10px;
	margin:20px 20px 0px 20px;
	width:284px;
	text-align: left;
}
a.toggle_customise_edit_panel:hover { 
	color: #ffffff;
	background: #0588BC;
	text-decoration:none;
}

#customise_editpanel {
	display:none;
	margin: 0;
	padding:20px;
	background: #dedede;
}

/* Top area - instructions */
.customise_editpanel_instructions {
	width:690px;
	padding:0 0 10px 0;
}
.customise_editpanel_instructions h2 {
	padding:0 0 10px 0;
}
.customise_editpanel_instructions p {
	margin:0 0 5px 0;
	line-height: 1.4em;
}

/* RHS (widget gallery area) */
#customise_editpanel_rhs {
	float:right;
	width:230px;
	background:white;
}
#customise_editpanel #customise_editpanel_rhs h2 {
	color:#333333;
	font-size: 1.4em;
	margin:0;
	padding:6px;
}
#widget_picker_gallery {
	border-top:1px solid #f5f5f5;
	background:white;
	width:210px; 
	height:340px;
	padding:10px;
	overflow:scroll;
	overflow-x:hidden;
}

/* main page widget area */
#customise_page_view {
	width:656px;
	padding:10px;
	margin:0 0 10px 0;
	background:white;
}
#customise_page_view h2 {
	border-top:1px solid #f5f5f5;
	border-right:1px solid #f5f5f5;
	border-left:1px solid #f5f5f5;
	margin:0;
	padding:5px;
	width:200px;
	color: #0588BC;
	background: #f5f5f5;
	font-size:1.25em;
	line-height: 1.2em;
}

#profile_box_widgets {
	width:422px;
	margin:0 10px 10px 0;
	padding:5px 5px 0px 5px;
	min-height: 50px;
	border:1px solid #f5f5f5;
	background: #f5f5f5;
}
#customise_page_view h2.profile_box {
	width:422px;
	color: #999999;
}
#profile_box_widgets p {
	color:#999999;
}

#leftcolumn_widgets {
	width:200px;
	margin:0 10px 0 0;
	padding:5px 5px 40px 5px;
	min-height: 190px;
	border:1px solid #f5f5f5;
}
#middlecolumn_widgets {
	width:200px;
	margin:0 10px 0 0;
	padding:5px 5px 40px 5px;
	min-height: 190px;
	border:1px solid #f5f5f5;
}
#rightcolumn_widgets {
	width:200px;
	margin:0;
	padding:5px 5px 40px 5px;
	min-height: 190px;
	border:1px solid #f5f5f5;
}

#rightcolumn_widgets.long {
	min-height: 288px;
}
/* IE6 fix */
* html #leftcolumn_widgets { 
	height: 190px;
}
* html #middlecolumn_widgets { 
	height: 190px;
}
* html #rightcolumn_widgets { 
	height: 190px;
}
* html #rightcolumn_widgets.long { 
	height: 338px;
}

#customise_editpanel table.draggable_widget {
	width:200px;
	background: #f5f5f5;
	margin: 10px 0 0 0;
	vertical-align:text-top;
	border:1px solid #f5f5f5;
}

#widget_picker_gallery table.draggable_widget {
	width:200px;
	background: #f5f5f5;
	margin: 10px 0 0 0;
}

/* take care of long widget names */
#customise_editpanel table.draggable_widget h3 {
	word-wrap:break-word;/* safari, webkit, ie */
	width:140px;
	line-height: 1.1em;
	overflow: hidden;/* ff */
	padding:4px;
}
#widget_picker_gallery table.draggable_widget h3 {
	word-wrap:break-word;
	width:145px;
	line-height: 1.1em;
	overflow: hidden;
	padding:4px;
}
#customise_editpanel img.drag_handle {
	cursor:move;
	padding-top: 4px;
}
#customise_editpanel img.remove_me {
	padding-top: 4px;
}
#customise_editpanel img.more_info {
	padding-top: 4px;
}
#widget_moreinfo {
	position:absolute;
	border:1px solid #333333;
	background:#e4ecf5;
	color:#333333;
	padding:5px;
	display:none;
	width: 200px;
}
/* droppable area hover class  */
.droppable-hover {
	background:#fdffc3;
}
/* target drop area class */
.placeholder {
	border:2px dashed #AAA;
	width:196px !important;
	margin: 10px 0 10px 0;
}
/* class of widget while dragging */
.ui-sortable-helper {
	background: #00578A;
	color:white;
	padding: 4px;
	margin: 10px 0 0 0;
	width:200px;
}
/* IE6 fix */
* html .placeholder { 
	margin: 0;
}
/* IE7 */
*:first-child+html .placeholder {
	margin: 0;
}
/* IE6 fix */
* html .ui-sortable-helper h3 { 
	padding: 4px;
}
* html .ui-sortable-helper img.drag_handle, * html .ui-sortable-helper img.remove_me, * html .ui-sortable-helper img.more_info {
	padding-top: 4px;
}
/* IE7 */
*:first-child+html .ui-sortable-helper h3 {
	padding: 4px;
}
*:first-child+html .ui-sortable-helper img.drag_handle, *:first-child+html .ui-sortable-helper img.remove_me, *:first-child+html .ui-sortable-helper img.more_info {
	padding-top: 4px;
}



/* ***************************************
	BREADCRUMBS
*************************************** */
#pages_breadcrumbs {
	font-size: 80%;
	color:#999999;
	padding:0;
	margin:0 0 10px 0;
}
#pages_breadcrumbs a {
	color:#999999;
	text-decoration: none;
}
#pages_breadcrumbs a:hover {
	color: #0588BC;
	text-decoration: underline;
}


/* ***************************************
	MISC.
*************************************** */
/* general page titles in main content area */
#content_area_user_title h2 {	
	background:#f5f5f5;
	border-top:2px solid #00578A;
	margin:0 0 5px 0;
	padding:5px;
	color:#0588BC;
	font-size:1.35em;
	line-height:1.2em;
}

#sidebar_page_tree {
	margin:10px;
}

#sidebar_page_tree h3 {
	background:#f5f5f5;
	border-top:2px solid #00578A;
	margin:0 0 5px 0;
	padding:5px;
	color:#0588BC;
	font-size:1.25em;
	line-height:1.2em;
}	

/* tag icon */	
.object_tag_string {
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/icon_tag.gif) no-repeat left 2px;
	padding:0 0 0 14px;
	margin:0;
}	

/* profile picture upload n crop page */	
#profile_picture_form {
	height:145px;
}	
#current_user_avatar {
	float:left;
	width:160px;
	height:130px;
	border-right:1px solid #f5f5f5;
	margin:0 20px 0 0;
}	
#profile_picture_croppingtool {
	border-top: 1px solid #f5f5f5;
	margin:20px 0 0 0;
	padding:10px 0 0 0;
}	
#profile_picture_croppingtool #user_avatar {
	float: left;
	margin-right: 20px;
}	
#profile_picture_croppingtool #applycropping {

}
#profile_picture_croppingtool #user_avatar_preview {
	float: left;
	position: relative;
	overflow: hidden;
	width: 100px;
	height: 100px;
}	


/* ***************************************
	SETTINGS & ADMIN
*************************************** */

.settings_form h3,
.usersettings_statistics h3,
.admin_statistics h3,
.admin_users_online h3 {
	background:#e4e4e4;
	border-bottom:1px solid #d0d0d0;
	color:#666666;
	font-size:1.1em;
	line-height:1em;
	margin:30px 0 10px 0;
	padding:5px;	
}
.settings_form label,
.admin_debug label,
.admin_usage label {
	color:#333333;
	font-size:100%;
	font-weight:normal;
}
.settings_form {
	border-bottom:1px solid #f5f5f5;
	padding:0 0 20px 0;
}
.admin_usage {
	border-bottom:1px solid #f5f5f5;
	padding:0 0 20px 0;
}

.usersettings_statistics .odd,
.admin_statistics .odd {
	background:#f5f5f5;
}
.usersettings_statistics .even,
.admin_statistics .even {
	background:#ffffff;
}
.usersettings_statistics td,
.admin_statistics td {
	padding:2px 4px 2px 4px;
}
.usersettings_statistics td.column_one,
.admin_statistics td.column_one {
	width:200px;
}

/* add user pane on user admin */
#add_user_showhide #add-box {
	padding:20px;
	background: #dedede;
}
.admin_adduser_link {
	margin:0 0 20px 0;
}
#search-box {
	margin:0 0 20px 0;
}

.manifest_file {
	display:none;
}






/* ***************************************
	AVATAR CONTEXTUAL MENU
*************************************** */	
#profile_icon_wrapper {
	float:left;
}
	
.usericon {
	position:relative;
}

.avatar_menu_button {
	width:15px;
	height:15px;
	position:absolute;
	cursor:pointer;
	display:none;
	right:0;
	bottom:0;
}

.usericon div.sub_menu { 
	display:none; 
	position:absolute; 
	padding:2px; 
	margin:0; 
	border-top:solid 1px #E5E5E5; 
	border-left:solid 1px #E5E5E5; 
	border-right:solid 1px #999999; 
	border-bottom:solid 1px #999999;  
	width:160px; 
	background:#FFFFFF; 
	text-align:left;
}
div.usericon a.icon img {
	z-index:10;
}

.usericon div.sub_menu a {margin:0;padding:2px;}
.usericon div.sub_menu a:link, 
.usericon div.sub_menu a:visited, 
.usericon div.sub_menu a:hover{ display:block;}	
.usericon div.sub_menu a:hover{ background:#f5f5f5; text-decoration:none;}

.usericon div.sub_menu h3 {
	font-size:1.2em;
	padding-bottom:3px;
	border-bottom:solid 1px #dddddd;
	color: #00578A;
	margin:0 !important;
	background:#ffffff !important;
}
.usericon div.sub_menu h3:hover {
	background:#f5f5f5 !important;
}

.user_menu_addfriend,
.user_menu_removefriend,
.user_menu_profile,
.user_menu_friends,
.user_menu_friends_of,
.user_menu_blog,
.user_menu_file,
.user_menu_messages,
.user_menu_admin {
	margin:0;
	padding:0;
}
.user_menu_admin {
	border-top:solid 1px #dddddd;
}
.user_menu_admin a {
	color:#cc0033;
}

.blog_post {
	margin-bottom: 15px;
	border-bottom: 1px solid #aaaaaa;
}

.blog_post_icon {
	float:left;
	margin:3px 0 0 0;
	padding:0;
}

.blog_post h3 {
	font-size: 150%;
	margin-bottom: 5px;
}

.blog_post h3 a {
	text-decoration: none;
}

.blog_post p {
	margin: 0 0 5px 0;
}

.blog_post .strapline {
	margin: 0 0 0 35px;
	padding:0;
	color: #aaa;
	line-height:1em;
}
.blog_post p.tags {
	background:transparent url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/icon_tag.gif) no-repeat scroll left 2px;
	margin:0 0 0 35px;
	padding:0pt 0pt 0pt 16px;
	min-height:22px;
}
.blog_post .options {
	margin:0;
	padding:0;
}

.blog_post_body img[align="left"] {
	margin: 10px 10px 10px 0;
	float:left;
}
.blog_post_body img[align="right"] {
	margin: 10px 0 10px 10px;
	float:right;
}

.blog-comments h3 {
	font-size: 150%;
	margin-bottom: 10px;
}
.blog-comment {
	margin-top: 10px;
	margin-bottom:20px;
	border-bottom: 1px solid #aaaaaa;
}
.blog-comment img {
	float:left;
	margin: 0 10px 0 0;
}
.blog-comment-menu {
	margin:0;
}
.blog-comment-byline {
	background: #dddddd;
	height:22px;
	padding-top:3px;
	margin:0;
}
.blog-comment-text {
	margin:5px 0 5px 0;
}





.sharing_item {
	margin-bottom: 50px;
	border-bottom:1px solid #AAAAAA;
}

.sharing_item_owner {
	font-size: 90%;
	margin: 10px 0 0 0;
	color:#666666;
}

.sharing_item_owner .icon {
	float: left;
	margin-right: 5px;

}
.sharing_item_title h3 {
	font-size: 150%;
	margin-bottom: 5px;
}
.sharing_item_title h3 a {
	text-decoration: none;
}
.sharing_item_description p {
	margin:0;
	padding:0 0 5px 0;
}
.sharing_item_tags {
	background:transparent url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/icon_tag.gif) no-repeat scroll left 2px;
	margin:0;
	padding:0 0 0 14px;
}

.sharing_item_address a {
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #ffffff;
	background:#00578A;
	border: 1px solid #00578A;
	-webkit-border-radius: 3px; 
	-moz-border-radius: 3px;
	width: auto;
	height: 25px;
	padding: 2px 6px 2px 6px;
	margin:10px 0 10px 0;
	cursor: pointer;
}
.sharing_item_address a:hover {
	background: #0588BC;
	text-decoration: none;
}
.sharing_item_controls p {
	margin:0;
}



/* SHARES WIDGET VIEW */
.shares_widget_wrapper {
	background-color: #eeeeee;
	margin:0 0 10px 0;
	padding:5px;
}
.shares_widget_icon {
	float: left;
	margin-right: 10px;
}
.shares_timestamp {
	color:#666666;
	margin:0;
}
.share_desc {
	display:none;
	line-height: 1.2em;
}
.shares_widget_content {
	margin-left: 35px;
}
.shares_title {
	margin:0;
	line-height: 1.2em;
}

/* timestamp and user info in gallery and list view */
.search_listing_info .shares_gallery_user,
.share_gallery_info .shares_gallery_user,
.share_gallery_info .shares_gallery_comments {
	color:#666666;
	margin:0;
	font-size: 90%;	
}





p.filerepo_owner {
	margin:0;
	padding:0;
}
.filerepo_owner_details {
	/* font-size: 90%; */
	margin:0;
	padding:0;
	line-height: 1.2em;
}
.filerepo_owner_details small {
	color:#666666;
}
.filerepo_owner .usericon {
	margin-right: 5px;
	float: left;
}

.filerepo_download a {
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #ffffff;
	background:#00578A;
	border: 1px solid #00578A;
	-webkit-border-radius: 3px; 
	-moz-border-radius: 3px;
	width: auto;
	height: 25px;
	padding: 2px 6px 2px 6px;
	margin:10px 0 10px 0;
	cursor: pointer;
}

.filerepo_download a:hover {
	background: #0588BC;
	text-decoration: none;
}

/* FILE REPRO WIDGET VIEW */
.filerepo_widget_singleitem {
	background-color: #eeeeee;
	margin:0 0 10px 0;
	min-height:60px;
	display:block;
}
.filerepo_listview_icon {
	float: left;
	margin-right: 10px;
}
.filerepo_timestamp {
	color:#666666;
	margin:0;
}
.filerepo_listview_desc {
	display:none;
	padding:0 5px 10px 0;
	line-height: 1.2em;
}
.filerepo_widget_content {
	margin-left: 70px;
}
.filerepo_title {
	margin:0;
	padding:6px 5px 0 0;
	line-height: 1.2em;
}

.collapsable_box #filerepo_widget_layout {
	margin:0;
}

/* widget gallery view */
.filerepo_widget_galleryview img {
	padding:2px;
    border:1px solid #efefef;
    margin:2px;
}

/* SINGLE ITEM VIEW */
.filerepo_file {
	margin-bottom: 50px;
}
.filerepo_file .filerepo_title_owner_wrapper {
	min-height:60px;
	background-color: #eeeeee;
}
.filerepo_title_owner_wrapper .filerepo_title,
.filerepo_title_owner_wrapper .filerepo_owner {
	margin-left: 70px !important;
}
.filerepo_file .filerepo_maincontent {
	margin-left: 70px;
}
.filerepo_file .filerepo_icon {
	width: 70px;
	position: absolute;
	background-color: #eeeeee;
}
.filerepo_file .filerepo_title {
	margin:0;
	padding:1px 4px 5px 10px;
	line-height: 1.2em;
}
.filerepo_file .filerepo_owner {
	padding:0 0 0 10px;
}
.filerepo_file .filerepo_description {
	margin:10px 0 0 0;
	padding:0 0 0 10px;
}
.filerepo_download,
.filerepo_controls {
	padding:0 0 0 10px;
	margin:0;
}
.filerepo_file .filerepo_description p {
	padding:0 0 5px 0;
	margin:0;
}
.filerepo_file .filerepo_specialcontent img {
	padding:5px;
	margin:0 0 0 10px;
	border:1px dotted silver; 
}
.filerepo_tags {
	padding:0 0 10px 10px;
	margin:0;
}

/* file repro gallery items */
.search_gallery .filerepo_controls {
	padding:0;
}
.search_gallery .filerepo_title {
	font-weight: bold;
	line-height: 1.1em;
	margin:0 0 10px 0;
}

.filerepo_gallery_item {
	margin:0;
	padding:0;
}
.filerepo_gallery_item p {
	margin:0;
	padding:0;
}
.search_gallery .filerepo_comments {
	font-size:90%;
}

.filerepo_user_gallery_link {
	float:right;
	margin:5px 5px 5px 50px;
}
.filerepo_user_gallery_link a {
	padding:2px 25px 5px 0;
	background: transparent url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/icon_gallery.gif) no-repeat right top;
	display:block;
}
.filerepo_user_gallery_link a:hover {
	background-position: right -40px;
}







#content_area_group_title h2 {
	background:#FDFFC3;
	padding:5px;
	margin:0 0 10px 0;
	border-top:2px solid #00578A;
	color:#0588BC;
	font-size:1.35em;
	line-height:1.2em;
}

#two_column_left_sidebar_maincontent #owner_block_content {
	margin:0 0 10px 0 !important;
}

#groups_info_column_left {
	float:left:
	width:465px;
	margin-left:220px;
}

#groups_info_column_left .odd {
	background:#f5f5f5;
}
#groups_info_column_left p {
	margin:0 0 7px 0;
	padding:2px 4px;
}

#groups_info_column_right {
	float:left;
	width:220px;
}
#group_stats {
	width:180px;
	background: #eeeeee;
	padding:10px;
	margin:10px 0 20px 0;
}
#group_stats p {
	margin:0;
}
#group_members {
	margin:10px;
}

.right_column {
	clear:left;
	float:right;
	width:330px;
}
#left_column {
	width:330px;
	float:left;
	margin:0 20px 0 0;

}
#group_members h2,
.right_column h2,
#left_column h2 {
	background:#f5f5f5;
	border-top:2px solid #00578A;
	margin:0 0 5px 0;
	padding:5px;
	color:#0588BC;
	font-size:1.25em;
	line-height:1.2em;
}

#left_column #mb_input_wrapper {
	background:white;
	border:none;
	padding:0px;
}
#left_column #mb_input_wrapper .input_textarea {
	width:318px;
}

.member_icon {
	margin:3px;
	float:left;
}


/* group forums overview page */
.forums_table_head {
    background: #00578A;
    color:#ffffff;
    padding:4px;
}
.forums_table_topics {
    padding:4px;
    border-bottom:1px solid #f5f5f5;
}
.forums_table_topics h3 a {
	font-size: 1.3em;
}
.forum_access {
	font-size: small;	
}
.forums_table_topics p {
	margin:0px 0px 5px 0;
}

/* topics overview page */
#topic_titles {
    background: #00578A;
    color:#ffffff;
    padding:4px;
    margin:20px 0 0 0;
}

/* topic posts pages */
.post_icon {
    float:left;
    margin:0 8px 4px 0;
}

.topic_post {
    border-bottom:1px solid #f5f5f5;
    margin:10px 0 10px 0;
}

.topic_post h2 {
    margin-bottom:20px;
}

.topic_post table, td {
    border:none;
}

.topic_title {
	font-size: 1.2em;
	line-height: 1.1em;
	margin:0;
	padding:0 0 4px 0;
}

.forum_topics {
    padding:0;
    margin:0;
    border:1px solid #ddd;
    border-top:0;
}

/* alternating bckgnd on topics */
.forum_topics .odd {
	background-color:#ebebeb;
	padding: 4px;
}
.forum_topics .even {
	background-color:#f5f5f5;
	padding: 4px;
}


/* group latest discussions widget */
#latest_discussion_widget {
	margin:0 0 20px 0;
}
.forum_latest {
	margin:0 0 10px 0;
}
.forum_latest .topic_owner_icon {
	float:left;
}
.forum_latest .topic_title {
	margin-left:35px;
}
.forum_latest .topic_title p {
	font-size: 0.8em;
	line-height: 1.0em;
    padding:0;
    margin:0;
}

.forum_latest p.topic_replies {
	color:#999999;
    padding:3px 0 0 0;
    margin:0;
}

a.add_topic_button {
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #ffffff;
	background:#00578A;
	border: 2px solid #00578A;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	/*
	width: auto;
	height: 25px;
	*/
	padding: 4px 6px 4px 6px;
	margin:0;
	cursor: pointer;
	display:table;
}
a.add_topic_button:hover {
	background: #0588BC;
	border: 2px solid #0588BC;
	text-decoration: none;
}

/* group files widget */
#filerepo_widget_layout {
	margin:0 0 20px 0;
}
/* group pages widget */
#group_pages_widget {
	margin:0 0 20px 0;
}

/* latest discussion listing */
p.latest_discussion_info {
	float:right;
	width:220px;
}

span.timestamp {
	color:#666666;
	font-size: 90%;
}




#logbrowser_search_area {
	margin: 3px;
}

#logbrowserSearchform {

	padding: 20px;
	background-color: #dedede;

}

.log_entry {
	margin: 2px;
	width: 678px;
	font-size: 80%;
}
.log_entry td {
}

.log_entry_user {
	width: 120px;
	background-color: #eee;
}

.log_entry_time {
	width: 210px;
	background-color: #eee;
	padding:2px;
}

.log_entry_item {
	background-color: #eee;
	
}

.log_entry_action {
	width: 75px;
	background-color: #eee;
}/*-------------------------------
MESSAGEBOARD PLUGIN
-------------------------------*/
/* input msg area */
#mb_input_wrapper {
	border:1px dotted #f5f5f5;
	background:#f5f5f5;
	padding:4px;
}

#mb_input_wrapper .input_textarea {
	width:94%;
}
.message_item_timestamp {
	font-size:90%;
	color:#666666;
	padding:10px 0 0 0;
}
p.message_item_timestamp {
	margin-bottom: 10px;
}
/* wraps each message */
.messageboard {
	margin:10px 0 10px 0;
    background:#EEEEEE;
}
.messageboard .message_sender {
	float:left;
	margin: 5px 10px 0 5px;
}
* html .messageboard .message_sender { margin: 5px 10px 0 2px; } /* IE6 */
*+html .messageboard .message_sender {  } /* IE7 */

.messageboard .message p {
	line-height: 1.2em;
	background:#fffcd9;
	margin:0 4px 4px 4px;
	padding:4px;
	border-bottom:1px dotted #f5f5f5;
}

.message_buttons {
	padding:0 0 3px 4px;
	margin:0;
	font-size: 90%;
	color:#666666;
}

.messageboard .delete_message a {
	display:block;
	float:right;
	cursor: pointer;
	width:14px;
	height:14px;
	margin:0 3px 3px 0;
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/icon_customise_remove.png") no-repeat 0 0;
	text-indent: -9000px;
}
.messageboard .delete_message a:hover {
	background-position: 0 -16px;
}





/*-------------------------------
MESSAGING PLUGIN
-------------------------------*/
.actiontitle {
	font-weight: bold;
	font-size: 110%;
	margin: 0 0 10px 0;
}

#messages td {
	text-align: left;
	vertical-align:middle;
	border-bottom: 1px solid #d6dbd2;
	padding: 5px;
}
#messages .message_notread td {
	 background: #F7DAD8; 
	 border-bottom: 1px solid #999999;
}
#messages .message_read td {
	 background: #ffffff; 
	 border-bottom: 1px solid #d6dbd2;
}

#messages .delete_msg a {
	display:block;
	cursor: pointer;
	width:14px;
	height:14px;
	margin:0;
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/icon_customise_remove.png") no-repeat right 0;
	text-indent: -9000px;
	float:right;
}
#messages .delete_msg a:hover {
	background-position: right -16px;
}
/* IE6 */
* html #messages .delete_msg a { background-position: right 4px; }
* html #messages .delete_msg a:hover { background-position: right 4px; } 

#messages .usericon {
	float: left;
	margin: 0 15px 0 0;
}

#messages .msgsender {
	color:#666666;
	line-height: 1em;
	margin:0;
	padding:0;
	float:left;
}
#messages .msgsender small {
	color:#AAAAAA;
}


#messages .msgsubject {
	font-size: 120%;
	line-height: 100%;
}

.msgsubject {
	font-weight:bold;
}

.messages_single_icon  {
	float: left;
}

.messages_single_icon .usericon {
	float: left;
	margin: 0 10px 10px 0;
}

/* view and reply to message view */
.message_body {
	margin-left: 120px;
}
.message_body .messagebody {
	padding:0;
	margin:10px 0 10px 0;
	font-size: 120%;
	border-bottom:1px solid #f5f5f5;
}

/* drop down message reply form */
#message_reply_form {
	display:none;

}
/* when displaying original msg in reply view */
.previous_message {
    background:#efefef;
    border:1px solid #ccc;
    padding:4px;
    margin:0 0 20px 0;
}
.previous_message p {
    padding:0;
    margin:0;
    font-size: 120%;
}

.new_messages_count {
	color:#666666;
}
/* tinyMCE container */
#message_reply_editor #message_tbl {
	width:680px !important;
}



.treeview, .treeview ul { 
	padding: 0;
	margin: 0;
	list-style: none;
}

.treeview ul {
	background-color: white;
	margin-top: 4px;
}

.treeview .hitarea {
	background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/mod/pages/images/treeview-default.gif) -64px -25px no-repeat;
	height: 16px;
	width: 16px;
	margin-left: -16px;
	float: left;
	cursor: pointer;
}
/* fix for IE6 */
* html .hitarea {
	display: inline;
	float:none;
}

.treeview li { 
	margin: 0;
	padding: 3px 0pt 3px 16px;
}

.treeview a.selected {
	background-color: #eee;
}

#treecontrol { margin: 1em 0; display: none; }

.treeview .hover { color: red; cursor: pointer; }

.treeview li { background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/mod/pages/images/treeview-default-line.gif) 0 0 no-repeat; }
.treeview li.collapsable, .treeview li.expandable { background-position: 0 -176px; }

.treeview .expandable-hitarea { background-position: -80px -3px; }

.treeview li.last { background-position: 0 -1766px }
.treeview li.lastCollapsable, .treeview li.lastExpandable { background-image: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/mod/pages/images/treeview-default.gif); }  
.treeview li.lastCollapsable { background-position: 0 -111px }
.treeview li.lastExpandable { background-position: -32px -67px }

.treeview div.lastCollapsable-hitarea, .treeview div.lastExpandable-hitarea { background-position: 0; }

.treeview-red li { background-image: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/mod/pages/images/treeview-red-line.gif); }
.treeview-red .hitarea, .treeview-red li.lastCollapsable, .treeview-red li.lastExpandable { background-image: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/mod/pages/images/treeview-red.gif); } 

.treeview-black li { background-image: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/mod/pages/images/treeview-black-line.gif); }
.treeview-black .hitarea, .treeview-black li.lastCollapsable, .treeview-black li.lastExpandable { background-image: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/mod/pages/images/treeview-black.gif); }  

.treeview-gray li { background-image: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/mod/pages/images/treeview-gray-line.gif); }
.treeview-gray .hitarea, .treeview-gray li.lastCollapsable, .treeview-gray li.lastExpandable { background-image: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/mod/pages/images/treeview-gray.gif); } 

.treeview-famfamfam li { background-image: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/mod/pages/images/treeview-famfamfam-line.gif); }
.treeview-famfamfam .hitarea, .treeview-famfamfam li.lastCollapsable, .treeview-famfamfam li.lastExpandable { background-image: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/mod/pages/images/treeview-famfamfam.gif); } 


.filetree li { padding: 3px 0 2px 16px; }
.filetree span.folder, .filetree span.file { padding: 1px 0 1px 16px; display: block; }
.filetree span.folder { background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/mod/pages/images/folder.gif) 0 0 no-repeat; }
.filetree li.expandable span.folder { background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/mod/pages/images/folder-closed.gif) 0 0 no-repeat; }
.filetree span.file { background: url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/mod/pages/images/file.gif) 0 0 no-repeat; }

.pagesTreeContainer {
		margin:0;
		min-height: 200px;
	}
	
/* delete, Dave's test addition */

#pages_page .strapline {
    text-align:right;
    border-top:1px solid #efefef;
    margin:10px 0 10px 0;
}

#pages_page .tags {
    padding:0 0 0 16px;
    margin:10px 0 4px 0;
	background:transparent url(<?php echo $vars['url']; ?>mod/blue_gneiss_theme/graphics/icon_tag.gif) no-repeat scroll left 2px;
}

#pages_page img[align="left"] {
	margin: 10px 20px 10px 0;
	float:left;
}
#pages_page img[align="right"] {
	margin: 10px 0 10px 10px;
	float:right;
}

/* ***************************************

	ADMIN AREA - REPORTED CONTENT

*************************************** */

.reportedcontent_content {

	padding:10px;

	margin:0 0 10px 0;

}

.reportedcontent_content p.reportedcontent_detail,

.reportedcontent_content p {

	margin:0;

}

.active_report {

	border:1px solid #D3322A;

    background:#F7DAD8;

}

.archived_report {

	border:1px solid #666666;

    background:#dedede;

}



a.archive_report_button {

	float:right;

	font: 12px/100% Arial, Helvetica, sans-serif;

	font-weight: bold;

	color: #ffffff;

	background:#00578A;

	border: 1px solid #00578A;

	-webkit-border-radius: 4px; 

	-moz-border-radius: 4px;

	width: auto;

	padding: 4px;

	margin:15px 0 0 20px;

	cursor: pointer;

}

a.archive_report_button:hover {

	background: #0588BC;

	text-decoration: none;

}



a.delete_report_button {

	float:right;

	font: 12px/100% Arial, Helvetica, sans-serif;

	font-weight: bold;

	color: #ffffff;

	background:#999999;

	border: 1px solid #999999;

	-webkit-border-radius: 4px; 

	-moz-border-radius: 4px;

	width: auto;

	padding: 4px;

	margin:15px 0 0 20px;

	cursor: pointer;

}

a.delete_report_button:hover {

	background: #333333;

	text-decoration:none;

}



a.manifest_details {

	cursor:pointer;

}


/* status clear and cancel buttons */
#status_clear #status_clear_button,
#status_update_form #status_cancel_button {

	font: 11px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #999999;
	background:#dddddd;
	border: 1px solid #999999;
	-webkit-border-radius: 3px; 
	-moz-border-radius: 3px;
	width: auto;
	padding:1px 3px 1px 3px;
	margin:5px 0 5px 0;
	cursor: pointer;

}

#status_clear #status_clear_button:hover,
#status_update_form #status_cancel_button:hover {
	color: #ffffff;
	background:#0588BC;
}

/* status save button */
#status_update_form #status_save_button {
	font: 11px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #ffffff;
	background:#00578A;
	border: 1px solid #00578A;
	-webkit-border-radius: 3px; 
	-moz-border-radius: 3px;
	width: auto;
	padding: 1px 3px 1px 3px;
	margin:5px 10px 5px 0;
	cursor: pointer;
}

#status_update_form #status_save_button:hover {
	background: #0588BC;
}

/* current displayed status message */
#status_message p,
.widget_status_statusmessage p {
	font-size:1.2em;
	line-height:1.2em;
	font-weight:bold;
	color:#666666;
	padding:3px;
	margin:0;	
}

/* widget status box - input */
.widget_status_statusmessage {
/*
	font-size:1.2em;
	line-height:1.2em;
	font-weight:bold;
*/
	color:#666666;
	background:#fdffc3;
	padding:3px;
}
/* widget status box - time */
.widget_status_messagetimestamp {
	font-size:0.9em;
	color:#999999;
	margin:0;
}

#status_update_form {
	display:none;
}

.status_input_form {
	border:0;
	background:transparent;
}

.status_input_form:focus {
	border: none;
	background:transparent;
	color:#333333;
}
/* textarea for writing new message */
#status_update_input {
	display:none;
	background:transparent;
	border:none;
	font-size:1.2em;
	line-height:1.2em;
	font-weight:bold;
	color:#666666;
	padding:3px;
	width:274px;
	height:66px;
}


/* status messages history */

/* wraps each status msg */
.status_message {
	border-bottom: 1px solid #aaaaaa;
	margin:10px 0 10px 0;
}
/* current status message */
.status_statusmessage p {
	margin:0;
	color:#666666;
	background:#fdffc3;
	padding:10px;
	font-size: 1.5em;
	line-height: 1.1em;
}
/* previous status messages */
.status_statusmessage_history p {
	margin:0;
}
/* status message timestamp */
.widget_status_messagetimestamp p {
	margin:0;
}


/* friends status on 'friends' page */
.friends_status {
	float:right;
	width:370px;
	text-align:right;
	margin: 0 4px 0 0;
	padding:0;
}
.friends_status p {
	margin: 0;
	padding:0;
	line-height:1.1em;
}
.friends_status_message {
	height:29px;
	overflow:hidden;
}
.status_timestamp {
	color:#666666;
	margin:0;
	padding:0;
}
/* IE 6 fix */
* html .friends_status p { 
	line-height:1.3em;
}
* html .friends_status_message {
	height: 30px;
}
/* IE7 */
*:first-child+html .friends_status_message {
	height: 30px;
}
*:first-child+html .friends_status p { 
	line-height:1.3em;
}




blockquote {
    margin:10px;
    border:1px solid #efefef;
    padding:4px;
}

strong {
    font-weight:bold;
}

ul {
   list-style: disc;
}

ol {
  list-style: decimal;
}