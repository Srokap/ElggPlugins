<?php

	/**
	 * Amazon Wish List widget
	 * This plugin allows users to display their amazon wish list on their profile
	 * 
	 * @package Amazon Wish List Widget
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Robert S. Robbins <rober@williamsportwebdeveloper.com>
	 * @copyright Williamsport Web Developer 2009
	 * @link http://www.williamsportwebdeveloper.com/
	 */
	
		function amazon_init() {
    		
    		//extend css if style is required
    		    extend_view('css','amazon/css');
    		
    		//add a widget
			    add_widget_type('amazon',elgg_echo('amazon:widget_name'), elgg_echo('amazon:widget_info'));
			
		}
		
		register_elgg_event_handler('init','system','amazon_init');

?>