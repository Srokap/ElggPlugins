<?php

	$english = array(
	
		/**
		 * amazon widget details
		 */
		
		'amazon:widget_name' => 'Amazon Wish List',
		'amazon:widget_info' => 'This is your amazon wish list',
		'amazon:listid' => 'List ID',
		'amazon:notset' => 'You have not yet entered your List ID which is required to display your wish list.',
		
		
		 /**
	     * amazon widget river
	     **/
	        
	        //generic terms to use
	        'amazon:river:created' => "%s added the amazon widget.",
	        'amazon:river:updated' => "%s updated their amazon widget.",
	        'amazon:river:delete' => "%s removed their amazon widget.",
	        
		
	);
					
	add_translation("en",$english);

?>