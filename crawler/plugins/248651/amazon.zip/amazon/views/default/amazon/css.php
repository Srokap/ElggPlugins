<?php
 
    /**
	 * Amazon Wish List widget CSS
	 * 
	 * @package Amazon Wish List Widget
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Robert S. Robbins <rober@williamsportwebdeveloper.com>
	 * @copyright Williamsport Web Developer 2009
	 * @link http://www.williamsportwebdeveloper.com/
	 */
     
?>

.AmazonTable {
    width: 290px;    
    /* cellspacing equivalent */  
    border-collapse: collapse;    
    border-spacing: 0;   
    /* centers the table */  
    margin-left: auto;   
    margin-right: auto;  
}
.AmazonTable td { 
	/* cellpadding equivalent */  
    padding: 0px;
	vertical-align: top;
	padding-bottom: 10px 
	background-color: #fff;
}
.AmazonTable td img {
	padding-right: 4px;
}