<?php

    /**
	 * Elgg amazon edit page
	 *
	 * @package Amazon Wish List
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Robert S. Robbins <robert@williamsportwebdeveloper.com>  
	 * @copyright Williamsport Web Developer 2009  
	 * @link http://www.williamsportwebdeveloper.com/ 
	 */

?>
<p>	
	<?php echo elgg_echo("amazon:listid"); ?>        
	<input type="text" name="params[ListID]" value="<?php echo htmlentities($vars['entity']->ListID); ?>" />	    
</p>       