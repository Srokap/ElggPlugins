Amazon Wish List Widget Notes
-------------------------------------------------------------------------------
The Amazon Wish List Widget had to be redesigned because Amazon now requires web requests to be signed.
This widget no longer uses JSON. It now deals directly with the XML returned by Amazon and requires XSL enabled in PHP.
You may need to modify your php.ini file to enable the XSL extension, especially on Windows systems.
Your Amazon AWS access key and secret key must be hard coded into the view.php file but users will never see it.
The number of items shown is determined in the AmazonWishList.xsl file. The XSL file controls how the XML is displayed. 
Look for the line <xsl:if test="position() &lt; 6"> and change the number 6 to show more items (up to 10).

Instructions
-------------------------------------------------------------------------------
1. Obtain an access key at: http://www.amazon.com/gp/aws/registration/registration-form.html
2. Copy the amazon folder into the mod folder 
3. Enable the amazon plugin in Tool Administration
4. Disable and then enable "simple cache" if you are using it to ensure that the CSS cache is refreshed
5. Open the file view.php found in the folder mod\amazon\views\default\widgets\amazon\view.php and enter your AWS access key and secret key for the PHP constants
^. Drag the Amazon Wish List Widget to a slot on your profile page or dashboard 

Contact Information
-------------------------------------------------------------------------------
Robert S. Robbins <rober@williamsportwebdeveloper.com>
http://www.williamsportwebdeveloper.com/