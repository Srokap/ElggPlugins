<?php

	$norwegian = array(

		/**
		 * Sites
		 */
	
			'item:site' => 'Sider',
	
		/**
		 * Sessions
		 */
			
			'login' => "Logg inn",
			'loginok' => "Du er n&aring; logget inn.",
			'loginerror' => "Vi kunne ikke logge deg i. Dette kan v&aelig;re fordi du ikke har bekreftet kontoen din enn&aring;, detaljene du var feil, eller du har gjort for mange feil p&aring;logging fors&oslash;k. Kontroller at informasjonen er korrekt, og pr&oslash;v igjen.",
	
			'logout' => "Logg ut",
			'logoutok' => "Du er n&aring; logget ut.",
			'logouterror' => "Vi kunne ikke logge deg ut. Vennligst pr&oslash;v igjen.",
	
		/**
		 * Errors - Some of these are translated - But not everyone because of different reasons - If you want these translated, please contact me at: simon@simithunder.org - Or on Elgg: Simox
		 */
			'exception:title' => "Velkommen til Elgg.",
	
			'InstallationException:CantCreateSite' => "	
Kan ikke opprette en standard ElggSite med legitimasjonsbeskrivelser Navn:%s, Url: %s",
		
			'actionundefined' => "Forespurt (%s) ble ikke funnet i systemet.",
			'actionloggedout' => "Beklager, du m&aring; v&aelig;re logget inn for og gj&oslash;re dette.",
	
			'notfound' => "Forespurt kode ble ikke funnet. Ellers har du ikke tilgang til det.",
			
			'SecurityException:Codeblock' => "Adgang nektes for &aring; utf&oslash;re det privilegerte kodestykket",
			'DatabaseException:WrongCredentials' => "Elgg kan ikke koble til databasen ved &aring; bruke gitt legitimasjonsbeskrivelser.",
			'DatabaseException:NoConnect' => "Elgg fant ikke databasen '%s', vennligst sjekk dette",
			'SecurityException:FunctionDenied' => "Tilgang til privilegert funksjon '%s' er nektet.",
			'DatabaseException:DBSetupIssues' => "Det oppstod noen problemer: ",
			'DatabaseException:ScriptNotFound' => "Elgg kunne ikke finne database script %s.",
			
			'IOException:FailedToLoadGUID' => "Feilet og laste %s fra GUID:%d",
			'InvalidParameterException:NonElggObject' => "Passerer non-ElggObject to an ElggObject constructor!",
			'InvalidParameterException:UnrecognisedValue' => "Unrecognised value passed to constuctor.",
			
			'InvalidClassException:NotValidElggStar' => "GUID:%d is not a valid %s",
			
			'PluginException:MisconfiguredPlugin' => "%s is a misconfigured plugin.",
			
			'InvalidParameterException:NonElggUser' => "Passing a non-ElggUser to an ElggUser constructor!",
			
			'InvalidParameterException:NonElggSite' => "Passing a non-ElggSite to an ElggSite constructor!",
			
			'InvalidParameterException:NonElggGroup' => "Passing a non-ElggGroup to an ElggGroup constructor!",
	
			'IOException:UnableToSaveNew' => "Lagring ble ikke godtatt av %s",
			
			'InvalidParameterException:GUIDNotForExport' => "GUID has not been specified during export, this should never happen.",
			'InvalidParameterException:NonArrayReturnValue' => "Entity serialisation function passed a non-array returnvalue parameter",
			
			'ConfigurationException:NoCachePath' => "Cache path set to nothing!",
			'IOException:NotDirectory' => "%s is not a directory.",
			
			'IOException:BaseEntitySaveFailed' => "Unable to save new object's base entity information!",
			'InvalidParameterException:UnexpectedODDClass' => "import() passed an unexpected ODD class",
			'InvalidParameterException:EntityTypeNotSet' => "Entity type must be set.",
			
			'ClassException:ClassnameNotClass' => "%s is not a %s.",
			'ClassNotFoundException:MissingClass' => "Class '%s' was not found, missing plugin?",
			'InstallationException:TypeNotSupported' => "Type %s is not supported. This indicates an error in your installation, most likely caused by an incomplete upgrade.",

			'ImportException:ImportFailed' => "Could not import element %d",
			'ImportException:ProblemSaving' => "There was a problem saving %s",
			'ImportException:NoGUID' => "New entity created but has no GUID, this should not happen.",
			
			'ImportException:GUIDNotFound' => "Entity '%d' could not be found.",
			'ImportException:ProblemUpdatingMeta' => "There was a problem updating '%s' on entity '%d'",
			
			'ExportException:NoSuchEntity' => "No such entity GUID:%d", 
			
			'ImportException:NoODDElements' => "No OpenDD elements found in import data, import failed.",
			'ImportException:NotAllImported' => "Not all elements were imported.",
			
			'InvalidParameterException:UnrecognisedFileMode' => "Unrecognised file mode '%s'",
			'InvalidParameterException:MissingOwner' => "All files must have an owner!",
			'IOException:CouldNotMake' => "Could not make %s",
			'IOException:MissingFileName' => "You must specify a name before opening a file.",
			'ClassNotFoundException:NotFoundNotSavedWithFile' => "Filestore not found or class not saved with file!",
			'NotificationException:NoNotificationMethod' => "No notification method specified.",
			'NotificationException:NoHandlerFound' => "No handler found for '%s' or it was not callable.",
			'NotificationException:ErrorNotifyingGuid' => "There was an error while notifying %d",
			'NotificationException:NoEmailAddress' => "Could not get the email address for GUID:%d",
			'NotificationException:MissingParameter' => "Missing a required parameter, '%s'",
			
			'DatabaseException:WhereSetNonQuery' => "Where set contains non WhereQueryComponent",
			'DatabaseException:SelectFieldsMissing' => "Fields missing on a select style query",
			'DatabaseException:UnspecifiedQueryType' => "Unrecognised or unspecified query type.",
			'DatabaseException:NoTablesSpecified' => "No tables specified for query.",
			'DatabaseException:NoACL' => "No access control was provided on query",
			
			'InvalidParameterException:NoEntityFound' => "No entity found, it either doesn't exist or you don't have access to it.",
			
			'InvalidParameterException:GUIDNotFound' => "GUID:%s could not be found, or you can not access it.",
			'InvalidParameterException:IdNotExistForGUID' => "Sorry, '%s' does not exist for guid:%d",
			'InvalidParameterException:CanNotExportType' => "Sorry, I don't know how to export '%s'",
			'InvalidParameterException:NoDataFound' => "Could not find any data.",
			'InvalidParameterException:DoesNotBelong' => "Does not belong to entity.",
			'InvalidParameterException:DoesNotBelongOrRefer' => "Does not belong to entity or refer to entity.",
			'InvalidParameterException:MissingParameter' => "Missing parameter, you need to provide a GUID.",
			
			'SecurityException:APIAccessDenied' => "Sorry, API access has been disabled by the administrator.",
			'SecurityException:NoAuthMethods' => "No authentication methods were found that could authenticate this API request.",
			'APIException:ApiResultUnknown' => "API Result is of an unknown type, this should never happen.", 
			
			'ConfigurationException:NoSiteID' => "No site ID has been specified.",
			'InvalidParameterException:UnrecognisedMethod' => "Unrecognised call method '%s'",
			'APIException:MissingParameterInMethod' => "Missing parameter %s in method %s",
			'APIException:ParameterNotArray' => "%s does not appear to be an array.",
			'APIException:UnrecognisedTypeCast' => "Unrecognised type in cast %s for variable '%s' in method '%s'",
			'APIException:InvalidParameter' => "Invalid parameter found for '%s' in method '%s'.",
			'APIException:FunctionParseError' => "%s(%s) has a parsing error.",
			'APIException:FunctionNoReturn' => "%s(%s) returned no value.",
			'SecurityException:AuthTokenExpired' => "Authentication token either missing, invalid or expired.",
			'CallException:InvalidCallMethod' => "%s must be called using '%s'",
			'APIException:MethodCallNotImplemented' => "Method call '%s' has not been implemented.",
			'APIException:AlgorithmNotSupported' => "Algorithm '%s' is not supported or has been disabled.",
			'ConfigurationException:CacheDirNotSet' => "Cache directory 'cache_path' not set.",
			'APIException:NotGetOrPost' => "Request method must be GET or POST",
			'APIException:MissingAPIKey' => "Missing X-Elgg-apikey HTTP header",
			'APIException:MissingHmac' => "Missing X-Elgg-hmac header",
			'APIException:MissingHmacAlgo' => "Missing X-Elgg-hmac-algo header",
			'APIException:MissingTime' => "Missing X-Elgg-time header",
			'APIException:TemporalDrift' => "X-Elgg-time is too far in the past or future. Epoch fail.",
			'APIException:NoQueryString' => "No data on the query string",
			'APIException:MissingPOSTHash' => "Missing X-Elgg-posthash header",
			'APIException:MissingPOSTAlgo' => "Missing X-Elgg-posthash_algo header",
			'APIException:MissingContentType' => "Missing content type for post data",
			'SecurityException:InvalidPostHash' => "POST data hash is invalid - Expected %s but got %s.",
			'SecurityException:DupePacket' => "Packet signature already seen.",
			'SecurityException:InvalidAPIKey' => "Invalid or missing API Key.",
			'NotImplementedException:CallMethodNotImplemented' => "Call method '%s' is currently not supported.",
	
			'NotImplementedException:XMLRPCMethodNotImplemented' => "XML-RPC method call '%s' not implemented.",
			'InvalidParameterException:UnexpectedReturnFormat' => "Call to method '%s' returned an unexpected result.",
			'CallException:NotRPCCall' => "Call does not appear to be a valid XML-RPC call",
	
			'PluginException:NoPluginName' => "The plugin name could not be found",
	
			'ConfigurationException:BadDatabaseVersion' => "The database backend you have installed doesn't meet the basic requirements to run Elgg. Please consult your documentation.",
			'ConfigurationException:BadPHPVersion' => "You need at least PHP version 5.2 to run Elgg.",
			'configurationwarning:phpversion' => "Elgg requires at least PHP version 5.2, you can install it on 5.1.6 but some features may not work. Use at your own risk.",
	
	
			'InstallationException:DatarootNotWritable' => "Your data directory %s is not writable.",
			'InstallationException:DatarootUnderPath' => "Your data directory %s must be outside of your install path.",
			'InstallationException:DatarootBlank' => "You have not specified a data directory.",
	
			'SecurityException:authenticationfailed' => "User could not be authenticated",
	
			'CronException:unknownperiod' => '%s is not a recognised period.',
	
			'SecurityException:deletedisablecurrentsite' => 'You can not delete or disable the site you are currently viewing!',
	
			'memcache:notinstalled' => 'PHP memcache module not installed, you must install php5-memcache',
			'memcache:noservers' => 'No memcache servers defined, please populate the $CONFIG->memcache_servers variable',
			'memcache:versiontoolow' => 'Memcache needs at least version %s to run, you are running %s',
			'memcache:noaddserver' => 'Multiple server support disabled, you may need to upgrade your PECL memcache library',
	
			'deprecatedfunction' => 'Warning: This code uses the deprecated function \'%s\' and is not compatible with this version of Elgg',
		/**
		 * API
		 */
			'system.api.list' => "Listevisning av alle API p&aring; systemet.",
			'auth.gettoken' => "Dette API anrop lar brukeren logge p&aring;, returnerer en autentisering token som kan brukes til brukernavn og passord for autentisering av videre samtaler.",
	
		/**
		 * User details
		 */

			'name' => "Visningsnavn",
			'email' => "Epost addresse",
			'username' => "Brukernavn",
			'password' => "Passord",
			'passwordagain' => "Passord (igjen for verifikasjon)",
			'admin_option' => "Skal bruker v&aelig;re admin?",
	
		/**
		 * Access
		 */
	
			'PRIVATE' => "Privat",
			'LOGGED_IN' => "Innloggede brukere",
			'PUBLIC' => "Publisert",
			'access:friends:label' => "Venner",
			'access' => "Tilgang",
	
		/**
		 * Dashboard and widgets
		 */
	
			'dashboard' => "Dashboard",
            'dashboard:configure' => "Endre side",
			'dashboard:nowidgets' => "Oversikten er inngangsporten til webomr&aring;det. Klikk 'Rediger side' for &aring; legge ting &aring; holde styr p&aring; innhold og ditt liv innenfor systemet.",

			'widgets:add' => 'Legg til widgets p&aring; siden din',
			'widgets:add:description' => "Velg funksjonene du vil legge til p&aring; siden din ved &aring; dra dem fra <b> Widget galleriet </b> p&aring; h&oslash;yre side, til en av de tre widget omr&aring;dene nedenfor, og plassere dem hvor du vil de skal vises.

Slik fjerner du en widget flytte den tilbake til <b> Widget galleriet </b>.",
			'widgets:position:fixed' => '(Fikset posisjon p&aring; side)',
	
			'widgets' => "Widgets",
			'widget' => "Widget",
			'item:object:widget' => "Widgets",
			'layout:customise' => "Endre utseende",
			'widgets:gallery' => "Widget galleri",
			'widgets:leftcolumn' => "Venstre widgets",
			'widgets:fixed' => "Fikset posisjon",
			'widgets:middlecolumn' => "Midt-widgets",
			'widgets:rightcolumn' => "H&oslash;yre widgets",
			'widgets:profilebox' => "Profil boks",
			'widgets:panel:save:success' => "Dine widgets ble lagret.",
			'widgets:panel:save:failure' => "Ett problem oppstod under lagring av widgets. Vennligst pr&oslash;v igjen.",
			'widgets:save:success' => "Widgeten ble lagret.",
			'widgets:save:failure' => "Vi kunne ikke lagre din widget, vennligst pr&oslash;v igjen.",
			'widgets:handlernotfound' => 'Denne widgeten er enten &oslash;delagt eller deaktivert.',
	
		/**
		 * Groups
		 */
	
			'group' => "Gruppe", 
			'item:group' => "Grupper",
	
		/**
		 * Profile
		 */
	
			'profile' => "Profil",
			'profile:edit:default' => 'Erstatt profil felt',
			'user' => "Bruker",
			'item:user' => "Brukere",
			'riveritem:single:user' => 'en bruker',
			'riveritem:plural:user' => 'noen brukere',
	

		/**
		 * Profile menu items and titles
		 */
	
			'profile:yours' => "Din profil",
			'profile:user' => "%s's profil",
	
			'profile:edit' => "Endre profil",
			'profile:profilepictureinstructions' => "Profilbildet er bildet som vises p&aring; din profilside. <br/> Du kan endre det s&aring; ofte du vil. (Fil formater  som godtas: GIF, JPG eller PNG)",
			'profile:icon' => "Profil-bilde",
			'profile:createicon' => "Lag din avatar",
			'profile:currentavatar' => "Gjeldende avatar",
			'profile:createicon:header' => "Profil-bilde",
			'profile:profilepicturecroppingtool' => "Profilbilde beskj&aelig;rings verkt&oslash;y",
			'profile:createicon:instructions' => "Klikk og dra en firkant nedenfor for &aring; matche hvordan du vil at bildet beskj&aelig;res. En forh&aring;ndsvisning av ditt beskj&aelig;rte Bilde vises i boksen til h&oslash;yre. N&aring;r du er forn&oslash;yd med forh&aring;ndsvisningen, klikker du Opprett din avatar. Dette beskj&aelig;rede bildet vil bli brukt i hele omr&aring;det som din avatar. ",
	
			'profile:editdetails' => "Endre detaljer",
			'profile:editicon' => "Endre profil-bilde",
	
			'profile:aboutme' => "Om meg", 
			'profile:description' => "Om meg",
			'profile:briefdescription' => "Kort beskrivelse",
			'profile:location' => "Bosted",
			'profile:skills' => "Ferdigheter",  
			'profile:interests' => "Interesser", 
			'profile:contactemail' => "Epost",
			'profile:phone' => "Telefon",
			'profile:mobile' => "Mobiltelefon",
			'profile:website' => "Hjemmeside",
	
			'profile:banned' => 'Denne brukeren er utestengt.',

			'profile:river:update' => "%s oppdaterte sin profil",
			'profile:river:iconupdate' => "%s oppdaterte sitt profil-bilde",
	
			'profile:label' => "Profil etikett",
			'profile:type' => "Profil type",
	
			'profile:editdefault:fail' => 'Standard profil ble ikke lagret',
			'profile:editdefault:success' => 'Element lagret',
	
			
			'profile:editdefault:delete:fail' => 'Fjernet standardprofilen element feltet mislyktes',
			'profile:editdefault:delete:success' => 'Standard profil element slettet!',
	
			'profile:defaultprofile:reset' => 'Tilbakestilling av standard profil',
	
			'profile:resetdefault' => 'Tilbakestilling av standarprofil',
	
		/**
		 * Profile status messages
		 */
	
			'profile:saved' => "Din profil ble lagret.",
			'profile:icon:uploaded' => "Ditt profil-bilde har blitt lastet opp!",
	
		/**
		 * Profile error messages
		 */
	
			'profile:noaccess' => "Du har ikke tilgang til denne profilen.",
			'profile:notfound' => "Beklager, denne profilen finnes ikke.",
			'profile:cantedit' => "Beklager, du har ikke tilgang til og endre denne profilen",
			'profile:icon:notfound' => "Beklager, en feil oppstod under lagring av profil-bilde.",
	
		/**
		 * Friends
		 */
	
			'friends' => "Venner",
			'friends:yours' => "Dine venner",
			'friends:owned' => "%s's venner",
			'friend:add' => "Legg til venn",
			'friend:remove' => "Fjern som venn",
	
			'friends:add:successful' => "Du har lagt til %s som din venn.",
			'friends:add:failure' => "Vi kunne ikke legge til %s som din venn.",
	
			'friends:remove:successful' => "Du har fjernet %s fra din venneliste.",
			'friends:remove:failure' => "Vi kunne ikke fjerne %s fra din venneliste. Pr&oslash;v igjen.",
	
			'friends:none' => "Denne brukeren har ingen venner enda.",
			'friends:none:you' => "Du har ingen venner enda, s&oslash;k etter dine interesser for og finne nye venner!",
	
			'friends:none:found' => "Ingen venner ble funnet.",
	
			'friends:of:none' => "Ingen har lagt til denne brukeren som venn enda.",
			'friends:of:none:you' => "Ingen har lagt deg til som venn enn&aring;. Begynn &aring; fylle ut profilen din for og f&aring; mer folk innp&aring; den!",
	
			'friends:of:owned' => "Brukere som har lagt til %s som sin venn",

			 'friends:num_display' => "Hvor mange skal vises",
			 'friends:icon_size' => "Ikon st&oslash;rrelse",
			 'friends:tiny' => "&oslash;rlite",
			 'friends:small' => "lite",
			 'friends:of' => "Venner av",
			 'friends:collections' => "Kolleksjon av venner",
			 'friends:collections:add' => "Lag en ny venne-samling",
			 'friends:addfriends' => "Legg til venner",
			 'friends:collectionname' => "Kolleksjonsnavn",
			 'friends:collectionfriends' => "Venner i kolleksjon",
			 'friends:collectionedit' => "Endre denne kolleksjonen",
			 'friends:nocollections' => "Du har ingen venne-kolleksjoner enda.",
			 'friends:collectiondeleted' => "Din kolleksjon har blitt slettet.",
			 'friends:collectiondeletefailed' => "Vi kunne ikke slette denne kolleksjonen. Det kan v&aelig;re fordi du ikke har tilgang til den.",
			 'friends:collectionadded' => "Din kolleksjon har blitt laget!",
			 'friends:nocollectionname' => "Du m&aring; skrive inn ett navn p&aring; samlingen din.",
			'friends:collections:members' => "Kolleksjonens medlemmer",
			'friends:collections:edit' => "Endre kolleksjon",
		
	        'friends:river:created' => "%s la til venne widgeten.",
	        'friends:river:updated' => "%s oppdaterte sin venne widget.",
	        'friends:river:delete' => "%s fjernet sin venne-widget.",
	        'friends:river:add' => "%s har n&aring; blitt venn med",
	
			'friendspicker:chararray' => 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
	
		/**
		 * Feeds
		 */
			'feed:rss' => 'Abonner p&aring; feed',
			'feed:odd' => 'Syndiker OpenDD',
			
		/**
          * links
		 **/

			'link:view' => 'se link',

	
		/**
		 * River
		 */
			'river' => "River",			
			'river:relationship:friend' => 'er n&aring; venn med',
			'river:noaccess' => 'Du har ikke tilgang til og se dette elementet.',
			'river:posted:generic' => '%s postet',

		/**
		 * Plugins
		 */
			'plugins:settings:save:ok' => "Innstillingene for %s pluginet har blitt lagret.",
			'plugins:settings:save:fail' => "Problem oppstod under lagring av innstillingene til %s pluginet.",
			'plugins:usersettings:save:ok' => "Brukerinnstillinger for %s pluginet har blitt lagret.",
			'plugins:usersettings:save:fail' => "Problem oppstod under lagring av innstillingene til %s pluginet.",
			'admin:plugins:label:version' => "Versjon",
			'item:object:plugin' => 'Plugin konfigurasjons innstillinger',
			
		/**
		 * Notifications
		 */
			'notifications:usersettings' => "Notifikasjons innstillinger",
			'notifications:methods' => "Vennligst velg hvordan du skal varsles.",
	
			'notifications:usersettings:save:ok' => "Dine notifikasjons-innstillinger ble lagret.",
			'notifications:usersettings:save:fail' => "Det oppstod et problem under lagring varslingsinnstillingene.",
	
			'user.notification.get' => 'Returnere varslingsinnstillinger for en bestemt bruker.',
			'user.notification.set' => 'Angi varslingsinnstillinger for en bestemt bruker.',
		/**
		 * Search
		 */
	
			'search' => "S&oslash;k",
			'searchtitle' => "S&oslash;k: %s",
			'users:searchtitle' => "S&oslash;ker etter brukere: %s",
			'advancedsearchtitle' => "%s med resultater som matcher %s",
			'notfound' => "Ingen resultater ble funnet.",
			'next' => "Neste",
			'previous' => "Forrige",
	
			'viewtype:change' => "Skift listevisning",
			'viewtype:list' => "Listevisning",
			'viewtype:gallery' => "Galleri",
	
			'tag:search:startblurb' => "Elementer med tagger '%s':",

			'user:search:startblurb' => "Brukere som matcher '%s':",
			'user:search:finishblurb' => "For og se mer, klikk her.",
	
		/**
		 * Account
		 */
	
			'account' => "Konto",
			'settings' => "Innstillinger",
            'tools' => "Verkt&oslash;y",
            'tools:yours' => "Dine verkt&oslash;y",
	
			'register' => "Registrer",
			'registerok' => "Du har registrert deg hos %s!",
			'registerbad' => "Registreringen var mislykket. Brukernavnet kan allerede finnes, passordene dine kanskje ikke samsvarer, eller ditt brukernavn eller passord kan v&aelig;re for kort.",
			'registerdisabled' => "Registrasjon er de-aktivert av en administrator. Pr&oslash;v igjen senere.",
	
			'firstadminlogininstructions' => 'Ditt nye Elgg omr&aring;de ble installert, og din administratorkonto opprettet. N&aring; kan du konfigurere din side ytterligere ved at ulike installert plugin verkt&oslash;y.',
	
			'registration:notemail' => 'Eposten du skrev inn ser ikke ut til og v&aelig;re en aktiv epost.',
			'registration:userexists' => 'Dette brukernavnet finnes allerede',
			'registration:usernametooshort' => 'Brukernavn m&aring; minst v&aelig;re 4 tegn.',
			'registration:passwordtooshort' => 'Passord m&aring; v&aelig;re p&aring; minst 6 tegn.',
			'registration:dupeemail' => 'Denne epost addressen er allerede registrert',
			'registration:invalidchars' => 'Beklager, brukernavnet ditt inneholder ugyldige tegn.',
			'registration:emailnotvalid' => 'Beklager, e-postadressen du oppga er ugyldig p&aring; dette systemet',
			'registration:passwordnotvalid' => 'Beklager, passordet du angav, er ugyldig p&aring; dette systemet',
			'registration:usernamenotvalid' => 'Beklager, brukernavnet du angav, er ugyldig p&aring; dette systemet',
	
			'adduser' => "Legg til en ny bruker",
			'adduser:ok' => "Du har laget en ny bruker!",
			'adduser:bad' => "Den nye brukeren ble ikke laget.",
			
			'item:object:reported_content' => "Rapporterte elementer",
	
			'user:set:name' => "Brukernavn-innstillinger",
			'user:name:label' => "Ditt navn",
			'user:name:success' => "Du har endret visnings-navn!",
			'user:name:fail' => "Ditt navn ble ikke endret.",
	
			'user:set:password' => "Passord",
			'user:password:label' => "Nytt passord",
			'user:password2:label' => "Nytt passord igjen",
			'user:password:success' => "Passord endret!",
			'user:password:fail' => "Passordet ble ikke endret pga systemet.",
			'user:password:fail:notsame' => "De to passordene var ikke like!",
			'user:password:fail:tooshort' => "Passord var for kort!",
	
			'user:set:language' => "Spr&aring;k innstillinger",
			'user:language:label' => "Ditt spr&aring;k",
			'user:language:success' => "Dine spr&aring;k-innstillinger ble lagret!",
			'user:language:fail' => "Dine spr&aring;k-innstillinger ble ikke lagret.",
	
			'user:username:notfound' => 'Brukernavn %s finnes ikke.',
	
			'user:password:lost' => 'Glemt passord',
			'user:password:resetreq:success' => 'Du har  bedt om et nytt passord, e-post sendt',
			'user:password:resetreq:fail' => 'Kan ikke be om et nytt passord.',
	
			'user:password:text' => 'For &aring; generere et nytt passord, skriv inn brukernavnet ditt nedenfor. Vi vil sende adressen til en unik side for bekreftelse til deg via eposten kan du klikke p&aring; linken i meldingsteksten og et nytt passord vil bli sendt til deg.',
	
			'user:persistent' => 'Husk meg',
		/**
		 * Administration
		 */

			'admin:configuration:success' => "Dine innstillinger har blitt lagret.",
			'admin:configuration:fail' => "Dine innstillinger kunne ikke bli lagret.",
	
			'admin' => "Administrasjon",
			'admin:description' => "Med Admin-panelet kan du styre alle deler av systemet, fra brukeradministrasjonssystem til hvordan plugins adferd. Velg et alternativ nedenfor for &aring; komme i gang.",
			
			'admin:user' => "Bruker administrasjon",
			'admin:user:description' => "Med dette admin panelet kan du styre brukerens innstillinger for webomr&aring;det ditt. Velg et alternativ nedenfor for &aring; komme i gang.",
			'admin:user:adduser:label' => "Klikk her for og legge til en ny bruker...",
			'admin:user:opt:linktext' => "Konfigurer brukere...",
			'admin:user:opt:description' => "Konfigurer brukere og deres kontoer. ",
			
			'admin:site' => "Nettsted administrasjon",
			'admin:site:description' => "Med dette admin panelet kan du styre globale innstillingene for ditt omr&aring;de. Velg et alternativ nedenfor for &aring; komme i gang.",
			'admin:site:opt:linktext' => "Konfigurer nettsted...",
			'admin:site:opt:description' => "Konfigurer omr&aring;det tekniske og ikke-tekniske innstillinger. ",
			'admin:site:access:warning' => "Endre tilgang innstillingen p&aring;virker bare tillatelser p&aring; innhold laget i fremtiden.", 
			
			'admin:plugins' => "Verkt&oslash;y administrasjon",
			'admin:plugins:description' => "Dette admin panelet gir deg mulighet til &aring; kontrollere og konfigurere verkt&oslash;y installert p&aring; din side.",
			'admin:plugins:opt:linktext' => "Konfigurer verkt&oslash;y...",
			'admin:plugins:opt:description' => "Konfigurer plugins p&aring; dette nettstedet ",
			'admin:plugins:label:author' => "Forfatter",
			'admin:plugins:label:copyright' => "Kopieringsrettigheter",
			'admin:plugins:label:licence' => "Lisens",
			'admin:plugins:label:website' => "URL",
			'admin:plugins:label:moreinfo' => 'mer info',
			'admin:plugins:label:version' => 'Versjon',
			'admin:plugins:warning:elggversionunknown' => 'Advarsel! Dette pluginet samsvarer ikke med din Elgg versjon.',
			'admin:plugins:warning:elggtoolow' => 'Advarsel! Dette pluginet trenger en nyere versjon av Elgg',
			'admin:plugins:reorder:yes' => "Plugin %s ble flyttet.",
			'admin:plugins:reorder:no' => "Plugin %s kunne ikke bli flyttet.",
			'admin:plugins:disable:yes' => "Plugin %s ble de-aktivert.",
			'admin:plugins:disable:no' => "Plugin %s kunne ikke bli de-aktivert.",
			'admin:plugins:enable:yes' => "Plugin %s ble aktivert.",
			'admin:plugins:enable:no' => "Plugin %s ble ikke aktivert.",
	
			'admin:statistics' => "Statistikk",
			'admin:statistics:description' => "Dette er en oversikt over statistikk p&aring; omr&aring;det. Hvis du trenger mer detaljert statistikk, er en profesjonell administrasjon funksjon tilgjengelig.",
			'admin:statistics:opt:description' => "Vis statistikk om brukere og nettstedet.",
			'admin:statistics:opt:linktext' => "Vis statistikk...",
			'admin:statistics:label:basic' => "Grunnleggende statistikk",
			'admin:statistics:label:numentities' => "Foretak p&aring; nettsted",
			'admin:statistics:label:numusers' => "Brukere",
			'admin:statistics:label:numonline' => "Brukere p&aring;logget",
			'admin:statistics:label:onlineusers' => "Brukere p&aring;logget n&aring;",
			'admin:statistics:label:version' => "Elgg versjon",
			'admin:statistics:label:version:release' => "Release",
			'admin:statistics:label:version:version' => "Versjon",
	
			'admin:user:label:search' => "Finn brukere:",
			'admin:user:label:seachbutton' => "S&oslash;k", 
	
			'admin:user:ban:no' => "Kan ikke utestenge bruker",
			'admin:user:ban:yes' => "Bruker utestengt.",
			'admin:user:unban:no' => "Kan ikke stenge ute bruker",
			'admin:user:unban:yes' => "Bruker un-banned.",
			'admin:user:delete:no' => "Kan ikke slette bruker",
			'admin:user:delete:yes' => "Bruker slettet",
	
			'admin:user:resetpassword:yes' => "Passord er tilbakestillt. Bruker er varslet",
			'admin:user:resetpassword:no' => "Password could not be reset.",
	
			'admin:user:makeadmin:yes' => "Bruker er n&aring; administrator.",
			'admin:user:makeadmin:no' => "Denne brukeren ble ikke administrator.",
	
			'admin:user:removeadmin:yes' => "Bruker er ikke administrator lenger.",
			'admin:user:removeadmin:no' => "Vi kunne ikke fjerne rettighetene fra denne brukeren.",
			
		/**
		 * User settings
		 */
			'usersettings:description' => "Brukerens innstillinger panelet kan du styre alle dine personlige innstillinger, fra brukeradministrasjonssystem til hvordan plugins adferd. Velg et alternativ nedenfor for &aring; komme i gang.",
	
			'usersettings:statistics' => "Din statistikk",
			'usersettings:statistics:opt:description' => "Se statistikk om nettstedet og brukerene.",
			'usersettings:statistics:opt:linktext' => "Konto statistikk",
	
			'usersettings:user' => "Dine innstillinger",
			'usersettings:user:opt:description' => "Dette tillater deg &aring; styre brukerinnstillinger.",
			'usersettings:user:opt:linktext' => "Endre dine innstillinger",
	
			'usersettings:plugins' => "Verkt&oslash;y",
			'usersettings:plugins:opt:description' => "Konfigurere innstillinger (hvis noen) for aktivt verkt&oslash;y.",
			'usersettings:plugins:opt:linktext' => "Konfigurer dine verkt&oslash;y",
	
			'usersettings:plugins:description' => "Dette panelet kan du kontrollere og konfigurere den personlige innstillinger for verkt&oslash;yene installert av systemadministratoren.",
			'usersettings:statistics:label:numentities' => "Dine foretak",
	
			'usersettings:statistics:yourdetails' => "Dine detaljer",
			'usersettings:statistics:label:name' => "Fullt navn",
			'usersettings:statistics:label:email' => "Epost",
			'usersettings:statistics:label:membersince' => "Medlem siden",
			'usersettings:statistics:label:lastlogin' => "Sist logget inn",
	
			
	
		/**
		 * Generic action words
		 */
	
			'save' => "Lagre",
			'publish' => "Publiser",
			'cancel' => "Avbryt",
			'saving' => "Lagrer ...",
			'update' => "Oppdater",
			'edit' => "Endre",
			'delete' => "Slett",
			'accept' => "Godta",
			'load' => "Last",
			'upload' => "Last opp",
			'ban' => "Ban",
			'unban' => "Unban",
			'enable' => "Aktiver",
			'disable' => "De-aktiver",
			'request' => "Send foresp&oslash;rsel",
			'complete' => "Fullf&oslash;r",
			'open' => '&aring;pne',
			'close' => 'Lukk',
			'reply' => "Svar",
			'more' => 'Mer',
			'comments' => 'Kommentarer',
			'import' => 'Importer',
			'export' => 'Exporter',
	
			'up' => 'Opp',
			'down' => 'Ned',
			'top' => 'Topp',
			'bottom' => 'Bunn',
	
			'invite' => "Inviter",
	
			'resetpassword' => "Tilbakestill passord",
			'makeadmin' => "Gj&oslash;r om til admin",
			'removeadmin' => "Fjern admin",
	
			'option:yes' => "Yes",
			'option:no' => "No",
	
			'unknown' => 'Ukjent',
	
			'active' => 'Aktive',
			'total' => 'Totalt',
	
			'learnmore' => "Klikk her for og l&aelig;re mer.",
	
			'content' => "innhold",
			'content:latest' => 'Siste aktivitet',
			'content:latest:blurb' => 'Eventuelt kan du klikke her for &aring; se det nyeste innholdet fra hele omr&aring;det.',
	
			'link:text' => 'se link',
	
			'enableall' => 'Aktiver Alle',
			'disableall' => 'De-aktiver Alle',
	
		/**
		 * Generic questions
		 */
	
			'question:areyousure' => 'Er du sikker?',
	
		/**
		 * Generic data words
		 */
	
			'title' => "Tittel",
			'description' => "Beskrivelse",
			'tags' => "Tagger",
			'spotlight' => "Spotlight",
			'all' => "Alle",
	
			'by' => 'av',
	
			'annotations' => "Annotations",
			'relationships' => "Forhold",
			'metadata' => "Metadata",
	
		/**
		 * Input / output strings
		 */

			'deleteconfirm' => "Er du sikker p&aring; at du vil slette dette??",
			'fileexists' => "	
En fil har blitt lastet opp. &aring; erstatte den, velger du det nedenfor:",
			
		/**
		 * User add
		 */

			'useradd:subject' => 'Brukerkonto er opprettet',
			'useradd:body' => '
%s,

	
En brukers konto er opprettet for deg hos %s. For og logge inn, bes&oslash;k:

	%s

Og logg inn med denne informasjonen:

	Brukernavn: %s
	Passord: %s
	
N&aring;r du har logget inn, anbefaler vi at du endrer passordet ditt.
',
			
	    /**
         * System messages
         **/

			'systemmessages:dismiss' => "fjern",

	
		/**
		 * Import / export
		 */
			'importsuccess' => "Importering av data er fullf&oslash;rt",
			'importfail' => "OpenDD importering feilet",
	
		/**
		 * Time
		 */
	
			'friendlytime:justnow' => "n&aring; nettopp",
			'friendlytime:minutes' => "%s minutter siden",
			'friendlytime:minutes:singular' => "ett minutt siden",
			'friendlytime:hours' => "%s timer siden",
			'friendlytime:hours:singular' => "en time siden",
			'friendlytime:days' => "%s dager siden",
			'friendlytime:days:singular' => "i g&aring;r",
	
			'date:month:01' => 'Januar %s',
			'date:month:02' => 'Februar %s',
			'date:month:03' => 'Mars %s',
			'date:month:04' => 'April %s',
			'date:month:05' => 'Mai %s',
			'date:month:06' => 'Juni %s',
			'date:month:07' => 'Juli %s',
			'date:month:08' => 'August %s',
			'date:month:09' => 'September %s',
			'date:month:10' => 'Oktober %s',
			'date:month:11' => 'November %s',
			'date:month:12' => 'Desember %s',
	
	
		/**
		 * Installation and system settings
		 */
	
			'installation:error:htaccess' => "ELGG krever en fil kalt. htaccess &aring; bli satt i rotkatalogen av sin installasjon. Vi pr&oslash;vde &aring; lage det for deg, men Elgg har ikke tillatelse til &aring; skrive til denne katalogen.

Opprettelse av dette er enkelt. Kopier innholdet i tekstboksen nedenfor i et tekstredigeringsprogram, og lagre det som. Htaccess

",
			'installation:error:settings' => "Elgg kunne ikke finne innstillingene fil. De fleste av Elgg innstillinger vil bli h&aring;ndtert for deg, men vi trenger du &aring; levere databasen detaljer. Slik gj&oslash;r du:

1. Rename motor / settings.example.php til settings.php i Elgg installasjon.

2. &aring;pne den med en tekst editor og angi MySQL database detaljer. Hvis du ikke vet dette, kan du be systemansvarlig eller teknisk support for hjelp.

Alternativt kan du angi din database nedenfor og vi vil pr&oslash;ve &aring; gj&oslash;re dette for deg ...",
	
			'installation:error:configuration' => "N&aring;r du har rettet eventuelle konfigurasjonsproblemer, trykk oppdater for &aring; pr&oslash;ve igjen.",
	
			'installation' => "Installasjon",
			'installation:success' => "Elgg database er installert.",
			'installation:configuration:success' => "Konfigurasjonsinnstillingene har blitt lagret. N&aring; m&aring; du registrere den f&oslash;rste brukeren, denne vil v&aelig;re hoved-administrator",
	
			'installation:settings' => "System innstillinger",
			'installation:settings:description' => "N&aring; som Elgg databasen er innstallert m&aring; du skrive inn litt informasjon for og f&aring; nettstedet ditt til og virke . Vi har pr&oslash;vd og finne informasjonen men <b>du b&oslash;r sjekke disse detaljene.</b>",
	
			'installation:settings:dbwizard:prompt' => "Skriv inn databaseinformasjonen og klikk lagre:",
			'installation:settings:dbwizard:label:user' => "Database bruker",
			'installation:settings:dbwizard:label:pass' => "Database passord",
			'installation:settings:dbwizard:label:dbname' => "Elgg database",
			'installation:settings:dbwizard:label:host' => "Database hostname (normalt 'localhost')",
			'installation:settings:dbwizard:label:prefix' => "Database table prefix (usually 'elgg')",
	
			'installation:settings:dbwizard:savefail' => "Vi klarte ikke &aring; lagre den nye settings.php. Lagre f&oslash;lgende fil i: engine/settings.php ved og bruke et tekstredigeringsprogram.",
	
			'installation:sitename' => "Navn p&aring; nettstedet (feks \"Mitt sosiale nettsted\"):",
			'installation:sitedescription' => "Kort beskrivelse av siden (valgfritt)",
			'installation:wwwroot' => "Webadressen, etterfulgt av en skr&aring;strek:",
			'installation:path' => "Hele banen til nettstedet roten p&aring; disken, etterfulgt av en skr&aring;strek:",
			'installation:dataroot' => "Den fullstendige banen til katalogen der opplastede filer vil bli lagret, etterfulgt av en skr&aring;strek:",
			'installation:dataroot:warning' => "Du m&aring; opprette denne mappen manuelt. Den burde sitte i en annen katalog til Elgg installasjon.",
			'installation:sitepermissions' => "Standard tilgangstillatelser:",
			'installation:language' => "Standard spr&aring;k:",
			'installation:debug' => "Feils&oslash;kingsmodus gir ekstra informasjon som kan brukes til &aring; diagnostisere feil, men det kan trege systemet nede s&aring; b&oslash;r bare brukes hvis du har problemer:",
			'installation:debug:label' => "Sl&aring; p&aring; feils&oslash;kingsmodus",
			'installation:httpslogin' => "Aktiver denne for &aring; ha Brukerp&aring;logginger utf&oslash;res via HTTPS. Du m&aring; ha https aktivert p&aring; serveren din for dette til &aring; fungere.",
			'installation:httpslogin:label' => "Aktiver HTTPS logins",
			'installation:usage' => "Dette alternativet lar Elgg sende anonym bruksstatistikk tilbake til Curverider.",
			'installation:usage:label' => "Send anonym bruksstatistikk",
			'installation:view' => "Angi visning som vil bli brukt som standard for omr&aring;det eller la dette st&aring; tomt for standard visning (hvis du er i tvil, la som standard):",

			'installation:siteemail' => "Site epostadresse (brukes n&aring;r du sender systemet epost)",
	
			'installation:disableapi' => "RESTful API er ett fleksibelt og utvidbart grensesnitt som gj&oslash;r det mulig for programmer &aring; bruke bestemte Elgg funksjoner eksternt.",
			'installation:disableapi:label' => "Aktiver RESTful API",
			
			'installation:allow_user_default_access:description' => "Hvis avkrysset, individuelle brukere kan benytte til &aring; sette sin egen standard tilgangsniv&aring; som kan over-ride system standard tilgangsniv&aring;.",
			'installation:allow_user_default_access:label' => "Tillat bruker standard tilgang",
	
			'installation:simplecache:description' => "Den enkle cache &oslash;ker ytelsen ved hurtigbufring statisk innhold, inkludert noen CSS og JavaScript filer. Normalt vil du ha denne p&aring;.",
			'installation:simplecache:label' => "Bruk simple cache",
	
			'upgrading' => 'Oppgraderer',
			'upgrade:db' => 'Din database ble oppgradert.',
			'upgrade:core' => 'Din Elgg pakke ble oppgradert',
	
		/**
		 * Welcome
		 */
	
			'welcome' => "Velkommen",
			'welcome_message' => "Velkommen til denne Elgg installasjonen.",
	
		/**
		 * Emails
		 */
			'email:settings' => "E-post innstillinger",
			'email:address:label' => "Din epost addresse",
			
			'email:save:success' => "Ny e-postadresse lagres, verifikasjon er sendt.",
			'email:save:fail' => "Din nye epost kunne ikke bli lagret.",
	
			'friend:newfriend:subject' => "%s har lagt deg til som en venn!",
			'friend:newfriend:body' => "%s har lagt deg til som en venn!

For og se denne brukerens profil, klikk her:

	%s

Denne epost kan ikke besvares.",
	
	
	
			'email:resetpassword:subject' => "Passord er tilbakestillt!",
			'email:resetpassword:body' => "Hei %s,
			
Ditt nye passord er: %s",
	
	
			'email:resetreq:subject' => "Foresp&oslash;rsel etter nytt passord.",
			'email:resetreq:body' => "Hei %s,
			
Noen (fra IP addressen %s) har sendt en foresp&oslash;rsel om tilbakestilling av passordet ditt for din brukerkonto.

Hvis dette var deg, klikk p&aring; linken under. Ellers kan du bare ignorere denne meldinen.

%s
",

		/**
		 * user default access
		 */
	
		'default_access:settings' => "Din standard tilgang er",
		'default_access:label' => "Standard tilgang",
		'user:default_access:success' => "Din nye standard tilgang er lagret.",
		'user:default_access:failure' => "Din nye standard tilgang ble ikke lagret.",
	
		/**
		 * XML-RPC
		 */
			'xmlrpc:noinputdata'	=>	"Input data missing",
	
		/**
		 * Comments
		 */
	
			'comments:count' => "%s kommentarer",
			
			'riveraction:annotation:generic_comment' => '%s kommenterte p&aring; %s',
	
			'generic_comments:add' => "Skriv en kommentar",
			'generic_comments:text' => "Kommentar",
			'generic_comment:posted' => "Din kommentar har blitt postet.",
			'generic_comment:deleted' => "Din kommentar ble slettet.",
			'generic_comment:blank' => "Beklager, du m&aring; skrive noe f&oslash;r du poster det.",
			'generic_comment:notfound' => "Beklager, vi kunne ikke finne dette.",
			'generic_comment:notdeleted' => "Beklager, vi kunne ikke slette denne kommentaren.",
			'generic_comment:failure' => "Det oppstod en uventet feil n&aring;r du la inn kommentaren din. Pr&oslash;v igjen.",
	
			'generic_comment:email:subject' => 'Du har en ny kommentar!',
			'generic_comment:email:body' => "Du har en ny kommentar p&aring; \"%s\" from %s. Det st&aring;r:

			
%s


For og se eller svare denne kommentaren, klikk her:

	%s

For og se %s's profil, klikk her:

	%s

Du kan ikke svare p&aring; denne eposten.",
	
		/**
		 * Entities
		 */
			'entity:default:strapline' => 'Laget for %s av %s',
			'entity:default:missingsupport:popup' => 'Dette foretaket kan ikke vises riktig. Dette kan v&aelig;re fordi det krever st&oslash;tte som en plugin som ikke lenger er installert.',
	
			'entity:delete:success' => 'Foretak %s har blitt slettet',
			'entity:delete:fail' => 'Foretak %s ble ikke slettet',
	
	
		/**
		 * Action gatekeeper
		 */
			'actiongatekeeper:missingfields' => '	
Form mangler __token eller __ts fields',
			'actiongatekeeper:tokeninvalid' => "Det oppstod en feil (token samsvarer ikke). Dette betyr trolig at siden du bruker utl&oslash;pt. Pr&oslash;v igjen.",
			'actiongatekeeper:timeerror' => 'Siden du pr&oslash;ver og vise har g&aring;tt ut. Vennligst oppdater for og se nytt innhold.',
			'actiongatekeeper:pluginprevents' => 'En utvidelse har hindret dette skjemaet i og bli sendt.',
	
		/**
		 * Word blacklists
		 */
			'word:blacklist' => 'og, den, da, men, hun, han, hun, han, en, og, ikke, ogs&aring;, om, n&aring;, derfor, har, imidlertid, fortsatt, det, samme, ellers, motsatt, heller, f&oslash;lgelig, dessuten, likevel, stedet, Samtidig, virker, hva, hvem, hvor',
	
		/**
		 * Languages according to ISO 639-1
		 */
			"aa" => "Afar",
			"ab" => "Abkhasisk",
			"af" => "Afrikaans",
			"am" => "Amharic",
			"ar" => "Arabic",
			"as" => "Assamese",
			"ay" => "Aymara",
			"az" => "Azerbaijani",
			"ba" => "Bashkir",
			"be" => "Byelorussian",
			"bg" => "Bulgarian",
			"bh" => "Bihari",
			"bi" => "Bislama",
			"bn" => "Bengali; Bangla",
			"bo" => "Tibetan",
			"br" => "Breton",
			"ca" => "Catalan",
			"co" => "Corsican",
			"cs" => "Czech",
			"cy" => "Welsh",
			"da" => "Dansk",
			"de" => "Tysk",
			"dz" => "Bhutani",
			"el" => "Gresk",
			"en" => "Engelsk",
			"eo" => "Esperanto",
			"es" => "Spansk",
			"et" => "Estonian",
			"eu" => "Basque",
			"fa" => "Persian",
			"fi" => "Finsk",
			"fj" => "Fiji",
			"fo" => "Faeroese",
			"fr" => "Fransk",
			"fy" => "Frisian",
			"ga" => "Irsk",
			"gd" => "Scots / Gaelic",
			"gl" => "Galician",
			"gn" => "Guarani",
			"gu" => "Gujarati",
			"he" => "Hebraisk",
			"ha" => "Hausa",
			"hi" => "Hindi",
			"hr" => "Croatian",
			"hu" => "Hungarian",
			"hy" => "Armenian",
			"ia" => "Interlingua",
			"id" => "Indonesian",
			"ie" => "Interlingue",
			"ik" => "Inupiak",
			//"in" => "Indonesian",
			"is" => "Icelandic",
			"it" => "Italiensk",
			"iu" => "Inuktitut",
			"iw" => "Hebrew (obsolete)",
			"ja" => "Japansk",
			"ji" => "Yiddish (obsolete)",
			"jw" => "Javanese",
			"ka" => "Georgian",
			"kk" => "Kazakh",
			"kl" => "Greenlandic",
			"km" => "Cambodian",
			"kn" => "Kannada",
			"ko" => "Korean",
			"ks" => "Kashmiri",
			"ku" => "Kurdish",
			"ky" => "Kirghiz",
			"la" => "Latin",
			"ln" => "Lingala",
			"lo" => "Laothian",
			"lt" => "Lithuanian",
			"lv" => "Latvian/Lettish",
			"mg" => "Malagasy",
			"mi" => "Maori",
			"mk" => "Macedonian",
			"ml" => "Malayalam",
			"mn" => "Mongolian",
			"mo" => "Moldavian",
			"mr" => "Marathi",
			"ms" => "Malay",
			"mt" => "Maltese",
			"my" => "Burmese",
			"na" => "Nauru",
			"ne" => "Nepali",
			"nl" => "Dutch",
			"no" => "Norsk",
			"oc" => "Occitan",
			"om" => "(Afan) Oromo",
			"or" => "Oriya",
			"pa" => "Punjabi",
			"pl" => "Polsk",
			"ps" => "Pashto / Pushto",
			"pt" => "Portuguese",
			"qu" => "Quechua",
			"rm" => "Rhaeto-Romance",
			"rn" => "Kirundi",
			"ro" => "Romanian",
			"ru" => "Russian",
			"rw" => "Kinyarwanda",
			"sa" => "Sanskrit",
			"sd" => "Sindhi",
			"sg" => "Sangro",
			"sh" => "Serbo-Croatian",
			"si" => "Singhalese",
			"sk" => "Slovak",
			"sl" => "Slovenian",
			"sm" => "Samoan",
			"sn" => "Shona",
			"so" => "Somali",
			"sq" => "Albanian",
			"sr" => "Serbian",
			"ss" => "Siswati",
			"st" => "Sesotho",
			"su" => "Sundanese",
			"sv" => "Svensk",
			"sw" => "Swahili",
			"ta" => "Tamil",
			"te" => "Tegulu",
			"tg" => "Tajik",
			"th" => "Thai",
			"ti" => "Tigrinya",
			"tk" => "Turkmen",
			"tl" => "Tagalog",
			"tn" => "Setswana",
			"to" => "Tonga",
			"tr" => "Turkish",
			"ts" => "Tsonga",
			"tt" => "Tatar",
			"tw" => "Twi",
			"ug" => "Uigur",
			"uk" => "Ukrainian",
			"ur" => "Urdu",
			"uz" => "Uzbek",
			"vi" => "Vietnamese",
			"vo" => "Volapuk",
			"wo" => "Wolof",
			"xh" => "Xhosa",
			//"y" => "Yiddish",
			"yi" => "Yiddish",
			"yo" => "Yoruba",
			"za" => "Zuang",
			"zh" => "Kinesisk",
			"zu" => "Zulu",
	);
	
	add_translation("no",$norwegian);

?>
