<?php

	$norwegian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'expages' => "Eksterne sider",
			'expages:frontpage' => "Fremside",
			'expages:about' => "Om",
			'expages:terms' => "Vilk&aring;r",
			'expages:privacy' => "Personvern",
			'expages:analytics' => "Analytics",
			'expages:contact' => "Kontakt",
			'expages:nopreview' => "Ingen forh&aring;ndsvisning tilgjengelig",
			'expages:preview' => "Forh&aring;ndsvis",
			'expages:notset' => "Denne siden er ikke laget enda.",
			'expages:lefthand' => "Venstre informasjons-side",
			'expages:righthand' => "H&oslash;yre informasjons-side",
			'expages:addcontent' => "Du kan legge til tekst her, vennligst sjekk Eksterne Sider p&aring; admin panelet.",
			'item:object:front' => 'Frem-side elementer',
	
		/**
		 * Status messages
		 */
	
			'expages:posted' => "Din side post har blitt postet.",
			'expages:deleted' => "Din sidepost har blitt slettet.",
	
		/**
		 * Error messages
		 */
	
			'expages:deleteerror' => "Ett problem oppstod under sletting av gammel side",
			'expages:error' => "Et problem oppstod, kontakt en administrator hvis du har sett denne meldingen f&oslash;r.",
	
	);
					
	add_translation("no",$norwegian);

?>