<?php

	$norwegian = array(
	
		'media:insert' => 'Sett inn / Last opp media',
	
		'embed:instructions' => 'Klikk p&aring; en fil for og sette den inn.',
	
		'embed:media' => 'Sett inn media',
		'upload:media' => 'Last opp media',
	
		'embed:file:required' => 'Ingen fil-opplastning plugins ble funnet. En systemadministrator m&aring; laste opp fil pluginet eller noe lignende.',
	
	);
					
	add_translation("no",$norwegian);

?>