<?php
	/**
	 * Elgg log rotator language pack.
	 * 
	 * @package ElggLogRotate
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	$norwegian = array(
		'logrotate:period' => 'Hvor ofte skal loggen bli arkivert?',
	
		'logrotate:weekly' => 'En gang i uken',
		'logrotate:monthly' => 'En gang i m&aring;neden',
		'logrotate:yearly' => 'En gang i &aring;ret',
	
		'logrotate:logrotated' => "Log rotated\n",
		'logrotate:lognotrotated' => "Error rotating log\n",
	);
					
	add_translation("no",$norwegian);
?>