<?php

	$norwegian = array(
	
		'friends:all' => 'Alle venner',
	
		'notifications:subscriptions:personal:description' => 'Motta varslinger n&aring;r noen kommenterer noe p&aring; dine ting',
		'notifications:subscriptions:personal:title' => 'Personlige notifikasjoner',
	
		'notifications:subscriptions:collections:title' => 'Velg venne-kolleksjoner',
		'notifications:subscriptions:collections:description' => 'For og veksle p&aring; innstillingene til vennekolleksjoner, bruk ikonene uder. ',
		'notifications:subscriptions:collections:edit' => 'For og endre dine vennekolleksjoner, klikk under.',
	
		'notifications:subscriptions:changesettings' => 'Notifikasjon',
		'notifications:subscriptions:changesettings:groups' => 'Gruppenotifikasjoner',
		'notification:method:email' => 'Epost',	
	
		'notifications:subscriptions:title' => 'Notifikasjoner etter brukere',
		'notifications:subscriptions:description' => 'For og motta notifikasjoner n&aring;r en venn gj&oslash;r noe p&aring; dette nettstedet. Velg denne funksjonen.',
	
		'notifications:subscriptions:groups:description' => 'For og f&aring; informasjon om n&aring;r en gruppe blir endret, nye poster eller bilder bruk denne funksjonen.',
	
		'notifications:subscriptions:success' => 'Dine notifikasjonsinnstillinger er lagret.',
	
	);
					
	add_translation("no",$norwegian);

?>