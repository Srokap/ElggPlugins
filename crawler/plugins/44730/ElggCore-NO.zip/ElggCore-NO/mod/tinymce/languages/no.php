<?php

	$norwegian = array(
	
		/**
		 * Menu items and titles
		 */
	
		'tinymce:remove' => "Legg til /fjern tekst endrer",
	
	);
					
	add_translation("no",$norwegian);

?>