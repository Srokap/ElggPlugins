<?php

	$norwegian = array(

		'mine' => 'Mitt',
		'filter' => 'Filter',
		'riverdashboard:useasdashboard' => "Erstatt normalt dashboard med river?",
		'activity' => 'Aktivitet',
	
	    /**
	     * Site messages
           **/

		'sitemessages:announcements' => "Sidens kunngj&oslash;ringer",
		'sitemessages:posted' => "Postet",
		'sitemessages:river:created' => "Side admin, %s,",
		'sitemessages:river:create' => "postet en ny side-kunngj&oslash;ring",
		'sitemessages:add' => "Skriv en ny kunngj&oslash;ring",
		'sitemessage:deleted' => "Kunngj&oslash;ring slettet",
		
		'river:widget:noactivity' => 'Vi kunne ikke finne noen aktivitet.',
		'river:widget:title' => "Aktivitet",
		'river:widget:description' => "Vis din siste aktivitet.",
		'river:widget:title:friends' => "Venners aktivitet",
		'river:widget:description:friends' => "Vis hva vennene dine gj&oslash;r.",
		'river:widgets:friends' => "Venner",
		'river:widgets:mine' => "Mitt",
		'river:widget:label:displaynum' => "Hvor mange skal vises:",
		'river:widget:type' => "Hva vil du vise? Din aktivitet, eller dine venners?",
		'item:object:sitemessage' => "Nettsteds meldinger",
	);
					
	add_translation("no",$norwegian);

?>