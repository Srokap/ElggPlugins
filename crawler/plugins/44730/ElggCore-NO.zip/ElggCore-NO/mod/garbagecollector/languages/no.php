<?php
	/**
	 * Elgg garbage collector language pack.
	 * 
	 * @package ElggGarbageCollector
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	$norwegian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'garbagecollector:period' => 'Hvor ofte skal Garbagekollektor kj&oslash;res?',
	
			'garbagecollector:weekly' => 'Once a week',
			'garbagecollector:monthly' => 'En gang i m&aring;neden',
			'garbagecollector:yearly' => 'En gang i &aring;ret',
	
			'garbagecollector' => "GARBAGE COLLECTOR\n",
			'garbagecollector:done' => "DONE\n",
			'garbagecollector:optimize' => "Optimizing %s ",
	
			'garbagecollector:error' => "ERROR",
			'garbagecollector:ok' => "OK",
	
			'garbagecollector:gc:metastrings' => 'Cleaning up unlinked metastrings: ',
	
	);
					
	add_translation("no",$norwegian);
?>