<?php
	$norwegian = array(
		'twitterservice' => 'Twitter Service',
		'twitterservice:postwire' => 'Vil du poste dine meldinger fra Tr�den til din Twitter?',
		'twitterservice:twittername' => 'Twitter brukernavn',
		'twitterservice:twitterpass' => 'Twitter passord',
	);
					
	add_translation("no",$norwegian);
?>