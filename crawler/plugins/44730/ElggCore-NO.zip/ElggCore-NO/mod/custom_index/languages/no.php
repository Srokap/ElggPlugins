<?php

	$norwegian = array(
	
			'custom:bookmarks' => "Siste bokmerker",
			'custom:groups' => "Siste grupper",
			'custom:files' => "Siste filer",
			'custom:blogs' => "Siste blog-poster",
			'custom:members' => "Nyeste medlemmer",
			'custom:nofiles' => "Det er ingen filer enda",
			'custom:nogroups' => "Det er ingen grupper enda",	
	
	);
					
	add_translation("no",$norwegian);

?>