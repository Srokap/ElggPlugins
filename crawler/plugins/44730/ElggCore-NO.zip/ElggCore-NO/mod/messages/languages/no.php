<?php

	$norwegian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messages' => "Meldinger",
            'messages:back' => "tilbake til meldinger",
			'messages:user' => "Din innboks",
			'messages:sentMessages' => "Sendte meldinger",
			'messages:posttitle' => "%s's melder: %s",
			'messages:inbox' => "Innboks",
			'messages:send' => "Send en melding",
			'messages:sent' => "Sendte meldinger",
			'messages:message' => "Melding",
			'messages:title' => "Tittel",
			'messages:to' => "Til",
            'messages:from' => "Fra",
			'messages:fly' => "La det fly!",
			'messages:replying' => "Message replying to",
			'messages:inbox' => "Innboks",
			'messages:sendmessage' => "Send en melding",
			'messages:compose' => "Send en melding",
			'messages:sentmessages' => "Sendte meldinger",
			'messages:recent' => "Siste meldinger",
            'messages:original' => "Original melding",
            'messages:yours' => "Din melding",
            'messages:answer' => "Svar",
			'messages:toggle' => 'Velg alle',
			'messages:markread' => 'Merk lest',
			
			'messages:new' => 'Ny melding',
	
			'notification:method:site' => 'Nettsted',
	
			'messages:error' => 'Problem oppstod under lagring av melding, vennligst pr&oslash;v igjen.',
	
			'item:object:messages' => 'Meldinger',
	
		/**
		 * Status messages
		 */
	
			'messages:posted' => "Din melding har blitt sendt.",
			'messages:deleted' => "Din melding ble slettet.",
			'messages:markedread' => "Melding er blitt merket som lest.",
	
		/**
		 * Email messages
		 */
	
			'messages:email:subject' => 'Du har en ny melding!',
			'messages:email:body' => "You have a new message from %s. It reads:

			
%s


To view your messages, click here:

	%s

To send %s a message, click here:

	%s

You cannot reply to this email.",
	
		/**
		 * Error messages
		 */
	
			'messages:blank' => "Beklager, du m&aring; skrive noe f&oslash;r du sender det.",
			'messages:notfound' => "Beklager, denne meldingen ser ikke ut til og finnes lenger.",
			'messages:notdeleted' => "Beklager, vi kunne ikke slette denne meldingen",
			'messages:nopermission' => "Du har ikke tillatelse og endre denne meldingen.",
			'messages:nomessages' => "Det er ingen meldinger og vise.",
			'messages:user:nonexist' => "Motaker finnes ikke i databasen.",
	
	);
					
	add_translation("no",$norwegian);

?>