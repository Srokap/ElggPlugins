<?php

	$norwegian = array(
	
		'categories' => 'Kategorier',
		'categories:settings' => 'Sett nettsted kategorier',	
		'categories:explanation' => 'For og angi noen forh&aring;ndsdefinerte kategorier som skal brukes i hele systemet, skriv dem nedenfor, atskilt med komma. Kompatible verkt&oslash;y vil deretter bli vist dem n&aring;r brukeren eller av redigering av innhold.',	
		'categories:save:success' => 'Nettsted kategorier er lagret.',
	
	);
					
	add_translation("no",$norwegian);

?>