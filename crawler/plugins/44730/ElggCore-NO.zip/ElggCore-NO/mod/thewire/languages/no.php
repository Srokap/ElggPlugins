<?php

	$norwegian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'thewire' => "Tr&aring;den",
			'thewire:user' => "%s's tr&aring;d",
			'thewire:posttitle' => "%s's notater p&aring; tr&aring;den: %s",
			'thewire:everyone' => "Alle tr&aring;dposter",
	
			'thewire:read' => "Tr&aring;dens poster",
			
			'thewire:strapline' => "%s",
	
			'thewire:add' => "Post p&aring; tr&aring;den",
		    'thewire:text' => "Ett notat p&aring; tr&aring;den",
			'thewire:reply' => "Svar",
			'thewire:via' => "via",
			'thewire:wired' => "Postet p&aring; tr&aring;den",
			'thewire:charleft' => "tegn igjen",
			'item:object:thewire' => "Tr&aring;d poster",
			'thewire:notedeleted' => "notat slettet",
			'thewire:doing' => "Hva gj&oslash;r du? Fortell det til de andre:",
			'thewire:newpost' => 'Ny tr&aring;d post',
			'thewire:addpost' => 'Post til tr&aring;den',

	
        /**
	     * The wire river
	     **/
	        
	        //generic terms to use
	        'thewire:river:created' => "%s postet",
	        
	        //these get inserted into the river links to take the user to the entity
	        'thewire:river:create' => "i tr&aring;den.",
	        
	    /**
	     * Wire widget
	     **/
	     
	        'thewire:sitedesc' => 'Denne widgeten viser de siste postene i tr&aring;den',
	        'thewire:yourdesc' => 'Denne widgeten viser dine siste poster i tr&aring;den',
	        'thewire:friendsdesc' => 'Denne widgeten viser hva vennene dine har postet i tr&aring;den',
	        'thewire:friends' => 'Dine venner i tr&aring;den',
	        'thewire:num' => 'Hvor mange skal vises',
	        
	        
	
		/**
		 * Status messages
		 */
	
			'thewire:posted' => "Din melding har blitt postet i tr&aring;den!",
			'thewire:deleted' => "Din melding har blitt slettet.",
	
		/**
		 * Error messages
		 */
	
			'thewire:blank' => "Beklager, du m&aring; skrive noe f&oslash;r du poster det.",
			'thewire:notfound' => "Beklager, vi kunne ikke finne dette.",
			'thewire:notdeleted' => "Beklager, vi kunne ikke slette denne posten.",
	
	
		/**
		 * Settings
		 */
			'thewire:smsnumber' => "Ditt SMS nummer er annerledes en ditt mobil-nummer. (mobilnummer m&aring; v&aelig;re satt til Publisert for at Tr&aring;den skal v&aelig;re aktivert til og bruke det) Alle telefonnummer m&aring; v&aelig;re i en internasjonal format",
			'thewire:channelsms' => "Nummeret for &aring; sende SMS-meldinger til, er <b>%s</b>",
			
	);
					
	add_translation("no",$norwegian);

?>