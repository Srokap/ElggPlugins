<?php
	/**
	 * Elgg pages plugin language pack
	 * 
	 * @package ElggPages
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	$norwegian = array(
	
		/**
		 * Menu items and titles
		 */
			
			'pages' => "Sider",
			'pages:yours' => "Dine sider",
			'pages:user' => "Sider - hjem",
			'pages:group' => "Gruppe sider",
			'pages:all' => "Alle sider",
			'pages:new' => "Ny side",
			'pages:groupprofile' => "Gruppesider",
			'pages:edit' => "Endre denne siden",
			'pages:delete' => "Slett denne siden",
			'pages:history' => "Side historie",
			'pages:view' => "Vis side",
			'pages:welcome' => "Endre velkomstmelding",
			'pages:welcomeerror' => "Problem oppstod under lagring",
			'pages:welcomeposted' => "Din velkommstmelding ble postet",
			'pages:navigation' => "Side navigasjon",
	        'pages:via' => "via sider",
			'item:object:page_top' => 'Top-level sider',
			'item:object:page' => 'Sider',
			'item:object:pages_welcome' => 'Siders velkommst blokk',
			'pages:nogroup' => 'Denne gruppen har ingen sider enda',
			'pages:more' => 'Mer sider',
			
		/**
		* River
		**/
		
		    'pages:river:annotate' => "en kommentar p&aring; denne siden",
		    'pages:river:created' => "%s skrev",
	        'pages:river:updated' => "%s oppdaterte",
	        'pages:river:posted' => "%s postet",
			'pages:river:create' => "en ny side som heter",
	        'pages:river:update' => "en side som heter",
	        'page:river:annotate' => "en kommentar p&aring; denne siden",
	        'page_top:river:annotate' => "en kommentar p&aring; denne siden",
	
		/**
		 * Form fields
		 */
	
			'pages:title' => 'Side tittler',
			'pages:description' => 'Din side-oppf&oslash;ring',
			'pages:tags' => 'Tagger',	
			'pages:access_id' => 'Tilgang',
			'pages:write_access_id' => 'Skrive-tilgang',
		
		/**
		 * Status and error messages
		 */
			'pages:noaccess' => 'Ingen tilgang til side',
			'pages:cantedit' => 'Du kan ikke endre denne siden',
			'pages:saved' => 'Side lagret',
			'pages:notsaved' => 'Side ble ikke lagret',
			'pages:notitle' => 'Du m&aring; skrive inn en tittel p&aring; siden.',
			'pages:delete:success' => 'Din side ble slettet.',
			'pages:delete:failure' => 'Siden kunne ikke bli slettet.',
	
		/**
		 * Page
		 */
			'pages:strapline' => 'Sist oppdatert for %s av %s',
	
		/**
		 * History
		 */
			'pages:revision' => 'Gjennomgang oppreted %s av %s',
			
		/**
		 * Widget
		 **/
		 
		    'pages:num' => 'Hvor mange skal vises',
			'pages:widget:description' => "Denne widgeten viser dine sider.",
	
		/**
		 * Submenu items
		 */
			'pages:label:view' => "Vis side",
			'pages:label:edit' => "Endre side",
			'pages:label:history' => "Side historie",
	
		/**
		 * Sidebar items
		 */
			'pages:sidebar:this' => "Denne siden",
			'pages:sidebar:children' => "Under-sider",
			'pages:sidebar:parent' => "Foreldre",
	
			'pages:newchild' => "Lag en under-side",
			'pages:backtoparent' => "Tilbake til '%s'",
	);
					
	add_translation("no",$norwegian);
?>