<?php

	$norwegian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messageboard:board' => "Meldingbrett",
			'messageboard:messageboard' => "meldinsbrett",
			'messageboard:viewall' => "vis alt",
			'messageboard:postit' => "Post det",
			'messageboard:history' => "historie",
			'messageboard:none' => "Ingenting har blitt postet her enda",
			'messageboard:num_display' => "Hvor mange meldinger skal vises",
			'messageboard:desc' => "Dette er en type gjestebok der andre brukere kan skrive p&aring; din profil.",
	
			'messageboard:user' => "%s's meldingsbrett",
	
			'messageboard:history' => "Historie",
			
         /**
	     * Message board widget river
	     **/
	        
	        'messageboard:river:annotate' => "%s har f&aring;tt en ny melding p&aring; sitt Meldingsbrett.",
	        'messageboard:river:create' => "%s la til gjestebok widgeten.",
	        'messageboard:river:update' => "%s oppdaterte sin gjestebok widget.",
	        'messageboard:river:added' => "%s posted p&aring;",
		    'messageboard:river:messageboard' => "meldings brettet",

			
		/**
		 * Status messages
		 */
	
			'messageboard:posted' => "Du har postet en melding.",
			'messageboard:deleted' => "Du har slettet en melding.",
	
		/**
		 * Email messages
		 */
	
			'messageboard:email:subject' => 'Du har en ny melding!',
			'messageboard:email:body' => "Du har en ny kommentar p&aring; din gjestebok fra %s. Det st&aring;r:

			
%s


For og se din gjestebok, klikk her:

	%s

For og se %s's profil, klikk her:

	%s

Denne epost kan ikke besvares.",
	
		/**
		 * Error messages
		 */
	
			'messageboard:blank' => "Beklager, du m&aring; skrive noe f&oslash;r du poster.",
			'messageboard:notfound' => "Beklager, dette finnes ikke.",
			'messageboard:notdeleted' => "Beklager, vi kunne ikke slette denne meldingen.",
			'messageboard:somethingwentwrong' => "En feil oppstod under posting, sjekk at du faktisk skrev noe.",
	     
			'messageboard:failure' => "En uvented feil oppstod under lagring av post. Vennligst pr&oslash;v igjen.",
	
	);
					
	add_translation("no",$norwegian);

?>