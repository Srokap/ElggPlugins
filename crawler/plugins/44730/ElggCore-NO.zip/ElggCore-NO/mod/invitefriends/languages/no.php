<?php

	/**
	 * Elgg invite page
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @link http://elgg.org/
	 */

	$norwegian = array(

		'friends:invite' => 'Inviter venner',
		'invitefriends:introduction' => 'For og invitere venner til denne nettsiden m&aring; du skrive inn deres e-post addresse (separert med komma):',
		'invitefriends:message' => 'Skriv inn meldingen som skal bli vist i invitasjonen:',
		'invitefriends:subject' => 'Invitasjon til og bli med i %s',
	
		'invitefriends:success' => 'Dine venner ble invitert.',
		'invitefriends:failure' => 'Dine venner kunne ikke bli invitert.',
	
		'invitefriends:message:default' => '
Hei,

Jeg vil invitere deg til nettstedet %s.',
		'invitefriends:email' => '
Du har blitt invitert til og bli med i %s dette er fra %s. Denne brukeren skrev inn denne meldingen:

%s

For og bli med, klikk linken:

	%s

Du vil automatisk bli venn med denne brukeren hvis du registrerer deg.',
	
	);
					
	add_translation("no",$norwegian);
?>