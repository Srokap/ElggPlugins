<?php

	$norwegian = array(
	
		/**
		 * Site info details
		 */
		
		'members:members' => "Nettstedets medlemmer",
	    'members:online' => "Medlemmer som er aktive n&aring;",
	    'members:active' => "nettstedets medlemmer",
	    'members:searchtag' => "S&oslash;k etter medlemmer via tags",
	    'members:searchname' => "S&oslash;k etter medlemmer via brukernavn",
	   
		
	);
					
	add_translation("no",$norwegian);

?>