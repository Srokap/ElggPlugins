<?php
	/**
	 * Elgg groups plugin language pack
	 * 
	 * @package ElggGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	$norwegian = array(
	
		/**
		 * Menu items and titles
		 */
			
			'groups' => "Grupper",
			'groups:owned' => "Grupper du eier",
			'groups:yours' => "Dine grupper",
			'groups:user' => "%s's grupper",
			'groups:all' => "Alle grupper",
			'groups:new' => "Lag en ny gruppe",
			'groups:edit' => "Endre gruppe",
			'groups:delete' => 'Slett gruppe',
			'groups:membershiprequests' => 'Administrer ventende brukere',
	
			'groups:icon' => 'Gruppe-bilde (hvis du har)',
			'groups:name' => 'Gruppenavn',
			'groups:username' => 'Gruppe-kort-navn (brukes i URL o.l)',
			'groups:description' => 'Beskrivelse',
			'groups:briefdescription' => 'Kort beskrivelse',
			'groups:interests' => 'Interesser',
			'groups:website' => 'Web-side',
			'groups:members' => 'Gruppens medlemmer',
			'groups:membership' => "Medlemskaps tilgang",
			'groups:access' => "Tilgang",
			'groups:owner' => "Eier",
	        'groups:widget:num_display' => 'Hvor mange skal vises',
	        'groups:widget:membership' => 'Gruppe medlemskap',
	        'groups:widgets:description' => 'Vis noen av gruppene du er med i p&aring; din profil',
			'groups:noaccess' => 'Ingen tilgang til gruppe',
			'groups:cantedit' => 'Du kan ikke endre denne gruppen',
			'groups:saved' => 'Gruppe lagret',
			'groups:featured' => 'Aktuelle grupper',
			'groups:makeunfeatured' => 'U-aktuell',
			'groups:makefeatured' => 'Gj&oslash;r om til aktuell',
			'groups:featuredon' => 'Denne gruppen er n&aring; i Aktuell kategorien.',
			'groups:unfeature' => 'Du har fjernet gruppen fra Aktuell kategorien',
			'groups:joinrequest' => 'Send foresp&oslash;rsel om medlemskap',
			'groups:join' => 'Bli med i gruppe',
			'groups:leave' => 'Forlat gruppe',
			'groups:invite' => 'Inviter venner',
			'groups:inviteto' => "Inviter venner til '%s'",
			'groups:nofriends' => "Du har ingen venner som kan inviteres til denne gruppen.",
			'groups:viagroups' => "via grupper",
			'groups:group' => "Gruppe",
	
			'groups:notfound' => "Gruppe ble ikke funnet",
			'groups:notfound:details' => "Gruppen du s&aring; etter finnes ikke i dette systemet",
			
			'groups:requests:none' => 'Det er ingen utest&aring;ende medlemskapsforesp&oslash;rsler.',
	
			'item:object:groupforumtopic' => "Diskusjonstr&aring;der",
	
			'groupforumtopic:new' => "New discussion post",
			
			'groups:count' => "grupper laget",
			'groups:open' => "&aring;pen gruppe",
			'groups:closed' => "stengt gruppe",
			'groups:member' => "medlemmer",
			'groups:searchtag' => "S&oslash;k etter grupped med tagger",
	
			
			/*
			 * Access
			 */
			'groups:access:private' => 'Stengt - Brukere m&aring; bli invitert',
			'groups:access:public' => '&aring;pen - Alle kan bli med',
			'groups:closedgroup' => 'Denne gruppen er stengt for alle. Du m&aring; sp&oslash;rre om tillatelse for og v&aelig;re med i denne gruppen.',
	
			/*
			   Group tools
			*/
			'groups:enablepages' => 'Aktiver gruppe-sider',
			'groups:enableforum' => 'Aktiver gruppe-forum',
			'groups:enablefiles' => 'Aktiver gruppe-filer',
			'groups:yes' => 'Ja',
			'groups:no' => 'Nei',
	
			'group:created' => 'Laget for %s med %d poster',
			'groups:lastupdated' => 'Sist oppdatert %s av %s',
			'groups:pages' => 'Gruppe sider',
			'groups:files' => 'Gruppe filer',
	
			/*
			  Group forum strings
			*/
			
			'group:replies' => 'Svar',
			'groups:forum' => 'Gruppe forum',
			'groups:addtopic' => 'Legg til en tr&aring;d',
			'groups:forumlatest' => 'Siste diskusjon',
			'groups:latestdiscussion' => 'Siste diskusjon',
			'groups:newest' => 'Nye',
			'groups:popular' => 'Popul&aelig;re',
			'groupspost:success' => 'Din kommentar har blitt postet',
			'groups:alldiscussion' => 'Siste diskusjon',
			'groups:edittopic' => 'Endre tr&aring;d',
			'groups:topicmessage' => 'Tr&aring;d melding',
			'groups:topicstatus' => 'Tr&aring;d-status',
			'groups:reply' => 'Post ett svar',
			'groups:topic' => 'Tr&aring;d',
			'groups:posts' => 'Poster',
			'groups:lastperson' => 'Siste person',
			'groups:when' => 'N&aring;r',
			'grouptopic:notcreated' => 'Ingen tr&aring;der har blitt laget.',
			'groups:topicopen' => '&aring;pen',
			'groups:topicclosed' => 'Stengt',
			'groups:topicresolved' => 'Fikset',
			'grouptopic:created' => 'Din tr&aring;d har blitt postet.',
			'groupstopic:deleted' => 'Tr&aring;den har blitt slettet.',
			'groups:topicsticky' => 'Klistre',
			'groups:topicisclosed' => 'Denne tr&aring;den er n&aring; stengt.',
			'groups:topiccloseddesc' => 'Denne tr&aring;den er stengt og du har ikke tilgang til og poste svar.',
			'grouptopic:error' => 'Tr&aring;den din ble ikke postet. Vennligst kontakt en system-administrator.',
			'groups:forumpost:edited' => "Du har endret din forumpost.",
			'groups:forumpost:error' => "Ett problem oppstod under lagring.",
			'groups:privategroup' => 'Denne gruppen er privat. S&oslash;ker tillatelse.',
			'groups:notitle' => 'Gruppen m&aring; ha en tittel',
			'groups:cantjoin' => 'Kan ikke bli med i denne gruppen',
			'groups:cantleave' => 'Du forlot ikke denne gruppen',
			'groups:addedtogroup' => 'Bruker er lagt til i gruppen!',
			'groups:joinrequestnotmade' => 'Join-Request ble ikke postet',
			'groups:joinrequestmade' => 'Foresp&oslash;rsel om og bli med i gruppen er sendt',
			'groups:joined' => 'Du er n&aring; med i denne gruppen!',
			'groups:left' => 'Du forlot n&aring; denne gruppen!',
			'groups:notowner' => 'Beklager, du er ikke eier av denne gruppen.',
			'groups:alreadymember' => 'Du er allerede medlem i denne gruppen!',
			'groups:userinvited' => 'Bruker har blitt invitert.',
			'groups:usernotinvited' => 'Bruker kunne ikke bli invitert.',
			'groups:useralreadyinvited' => 'Bruker har allerede blitt invitert',
			'groups:updated' => "Siste kommentar",
			'groups:invite:subject' => "%s du har blitt invitert til og bli med i %s!",
			'groups:started' => "Startet av",
			'groups:joinrequest:remove:check' => 'Er du sikker p&aring; at du vil fjerne dette?',
			'groups:invite:body' => "Hei %s,

Du har blitt invitert til og bli med i '%s' gruppen, klikk under for og bli med:

%s",

			'groups:welcome:subject' => "Velkommen til %s gruppen!",
			'groups:welcome:body' => "Hei %s!
		
Du er n&aring; medlem av '%s' gruppen! Klikk under for og g&aring; til forumet!

%s",
	
			'groups:request:subject' => "%s har spurt om og bli med i %s",
			'groups:request:body' => "Hei %s,

%s har spurt om og bli med i '%s' gruppen, klikk under for og se denne profilen:

%s

eller klikk under for og godta:

%s",
	
            /*
				Forum river items
			*/
	
			'groups:river:member' => 'er n&aring; medlem i',
			'groupforum:river:updated' => '%s har oppdatert',
			'groupforum:river:update' => 'denne tr&aring;den',
			'groupforum:river:created' => '%s har laget',
			'groupforum:river:create' => 'en ny tr&aring;d som heter',
			'groupforum:river:posted' => '%s har postet en ny kommentar',
			'groupforum:river:annotate:create' => 'i denne tr&aring;den',
			'groupforum:river:postedtopic' => '%s har startet en ny post som heter',
			'groups:river:member' => '%s er n&aring; medlem i',
	
			'groups:nowidgets' => 'Ingen widgets er laget for denne gruppen.',
	
	
			'groups:widgets:members:title' => 'Gruppe medlemmer',
			'groups:widgets:members:description' => 'Vis medlemmene i en gruppe.',
			'groups:widgets:members:label:displaynum' => 'Vis medlemmene i en gruppe.',
			'groups:widgets:members:label:pleaseedit' => 'Vennligst konfigurer denne widgeten.',
	
			'groups:widgets:entities:title' => "Objekter i gruppe",
			'groups:widgets:entities:description' => "List objektene lagret i gruppe",
			'groups:widgets:entities:label:displaynum' => 'Vis objekter i gruppe.',
			'groups:widgets:entities:label:pleaseedit' => 'Vennligst endre widget.',
		
			'groups:forumtopic:edited' => 'Forum tr&aring;d er endret.',
	
			/**
			 * Action messages
			 */
			'group:deleted' => 'Gruppe og gruppens innhold er n&aring; slettet',
			'group:notdeleted' => 'Gruppen kunne ikke bli slettet',
	
			'grouppost:deleted' => 'Gruppe-posting er slettet',
			'grouppost:notdeleted' => 'Gruppe-posting kunne ikke bli slettet',
			'groupstopic:deleted' => 'Tr&aring;d slettet',
			'groupstopic:notdeleted' => 'Tr&aring;d ble ikke slettet',
			'grouptopic:blank' => 'Ingen tr&aring;d',
			'groups:deletewarning' => "Er du sikker p&aring; at du vil slette denne gruppen? Dette kan ikke gj&oslash;res om!",
	
			'groups:joinrequestkilled' => 'Foresp&oslash;rsel slettet.',
	);
					
	add_translation("no",$norwegian);
?>