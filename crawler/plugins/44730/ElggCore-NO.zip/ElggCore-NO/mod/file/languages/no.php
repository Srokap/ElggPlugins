<?php
	/**
	 * Elgg file plugin language pack
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	$norwegian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'file' => "Filer",
			'files' => "Filer",
			'file:yours' => "Dine filer",
			'file:yours:friends' => "Dine venners filer",
			'file:user' => "%s's filer",
			'file:friends' => "%s's venners' filer",
			'file:all' => "Alle filer",
			'file:edit' => "Endre fil",
			'file:more' => "Mer filer",
			'file:list' => "listevisning",
			'file:group' => "Gruppe filer",
			'file:gallery' => "gallerivisning",
			'file:gallery_list' => "Galleri eller listevisning",
			'file:num_files' => "Hvor mange skal vises",
			'file:user:gallery'=>'Vis %s galleri', 
	        'file:via' => 'via filer',
			'file:upload' => "Last opp en fil",
	
			'file:newupload' => 'Ny fil lastet opp',
			
			'file:file' => "Fil",
			'file:title' => "Tittel",
			'file:desc' => "Beskrivelse",
			'file:tags' => "Tagger",
	
			'file:types' => "Opplastede filtyper",
	
			'file:type:all' => "Alle filer",
			'file:type:video' => "Videoer",
			'file:type:document' => "Dokumenter",
			'file:type:audio' => "Lyd",
			'file:type:image' => "Bilder",
			'file:type:general' => "Generellt",
	
			'file:user:type:video' => "%s's videoer",
			'file:user:type:document' => "%s's dokumenter",
			'file:user:type:audio' => "%s's lyder",
			'file:user:type:image' => "%s's bilder",
			'file:user:type:general' => "%s's generelle filer",
	
			'file:friends:type:video' => "Dine venners videoer",
			'file:friends:type:document' => "Dine venners dokumenter",
			'file:friends:type:audio' => "Dine venners lyder",
			'file:friends:type:image' => "Dine venners bilder",
			'file:friends:type:general' => "Dine venners generelle filer",
	
			'file:widget' => "Fil widget",
			'file:widget:description' => "Vis dine siste filer",
	
			'file:download' => "Last ned dette",
	
			'file:delete:confirm' => "Er du sikker p&aring; at du vil slette denne filen?",
			
			'file:tagcloud' => "Tag cloud",
	
			'file:display:number' => "Hvor mange skal vises",
	
			'file:river:created' => "%s lastet opp",
			'file:river:item' => "en fil",
			'file:river:annotate' => "en kommentar p&aring; denne filen",

			'item:object:file' => 'Filer',
			
	    /**
		 * Embed media
		 **/
		 
		    'file:embed' => "Sett inn media",
		    'file:embedall' => "Alle",
	
		/**
		 * Status messages
		 */
	
			'file:saved' => "Din fil ble lagret.",
			'file:deleted' => "Din fil ble slettet.",
	
		/**
		 * Error messages
		 */
	
			'file:none' => "Vi kunne ikke finne noen filer n&aring;.",
			'file:uploadfailed' => "Beklager, vi kunne ikke lagre din fil.",
			'file:downloadfailed' => "Beklager, denne fillen kan ikke bli lastet ned",
			'file:deletefailed' => "Din fil kunne ikke bli slettet.",
	
	);
					
	add_translation("no",$norwegian);
?>