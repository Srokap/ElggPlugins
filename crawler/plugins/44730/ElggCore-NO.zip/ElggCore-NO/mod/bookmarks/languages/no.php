<?php

	$norwegian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'bookmarks' => "Bokmerker",
			'bookmarks:add' => "Bokmerk noe",
			'bookmarks:read' => "Bokmerkete elementer",
			'bookmarks:friends' => "Venners bokmerker",
			'bookmarks:everyone' => "Alle bokmerker",
			'bookmarks:this' => "Bokmerk dette",
			'bookmarks:bookmarklet' => "Get bookmarklet",
			'bookmarks:inbox' => "Bookmerker inboks",
			'bookmarks:more' => "Mer",
			'bookmarks:shareditem' => "Bokmerkete elementer",
			'bookmarks:with' => "Del med",
			'bookmarks:new' => "Ett nytt bokmerke",
			'bookmarks:via' => "via bokmerker",
			'bookmarks:address' => "Addressen til det du vil bokmerke",
	
			'bookmarks:delete:confirm' => "Er du sikker p&aring; at du vil slette dette?",
	
			'bookmarks:numbertodisplay' => 'Hvor mange skal vises',
	
			'bookmarks:shared' => "Bokmerket",
			'bookmarks:visit' => "Bes&aring;k bokmerket",
			'bookmarks:recent' => "Siste bokmerker",
	
			'bookmarks:river:created' => '%s bokmerket',
			'bookmarks:river:annotate' => 'postet en kommentar p&aring; dette bokmerket',
			'bookmarks:river:item' => 'ett element',
	
			'item:object:bookmarks' => 'Bokmerkete elementer',
	
	
		/**
		 * More text
		 */
		    
		    'bookmarks:widget:description' => 
		            "Denne widgeten er designet for ditt Dashboard. Widgeten vil vise dine site bokmerker fra Bokmerker inboksen din.",
	
			'bookmarks:bookmarklet:description' =>
					"Med Bokmerkevisningen bookmarklet kan du dele noen ressurser du  finner p&aring; Internett med vennene dine, eller bare for og huske den selv. For og bruke den, drar du bare
f&aring;lgende til &aring; webleserens linker bar:",

	        'bookmarks:bookmarklet:descriptionie' =>
					"Hvis du bruker Internet Explorer, m&aring; du klikkr p&aring; bookmarklet ikonet og velge Legg til i favoritter, og deretter Koblinger.",

			'bookmarks:bookmarklet:description:conclusion' =>
					"Deretter kan du lagre en side du bes&aring;ker ved &aring; klikke p&aring; det til enhver tid.",
	
		/**
		 * Status messages
		 */
	
			'bookmarks:save:success' => "Dette elementer er n&aring; bokmerket.",
			'bookmarks:delete:success' => "Bokmerke er n&aring; slettet.",
	
		/**
		 * Error messages
		 */
	
			'bookmarks:save:failed' => "Bokmerket ble ikke lagret, vennligst pr&aring;v igjen.",
			'bookmarks:delete:failed' => "Ditt bokmerke ble ikke slettet, vennligst pr&aring;v igjen.",
	
	
	);
					
	add_translation("no",$norwegian);

?>