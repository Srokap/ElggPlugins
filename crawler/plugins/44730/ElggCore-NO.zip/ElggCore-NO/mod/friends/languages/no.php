<?php

	$norwegian = array(
	
		/**
		 * Friends widget
		 */
			'friends:widget:description' => "Vis noen av dine venner.",
	        
		
	);
					
	add_translation("no",$norwegian);

?>