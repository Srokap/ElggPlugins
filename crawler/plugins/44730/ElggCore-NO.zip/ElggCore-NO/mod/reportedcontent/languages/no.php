<?php
	/**
	 * Elgg reported content plugin language pack
	 * 
	 * @package ElggReportedContent
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	$norwegian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'item:object:reported_content' => 'Rapporterte elementer',
			'reportedcontent' => 'Rapportert innhold',
			'reportedcontent:this' => 'Rapporter dette',
			'reportedcontent:none' => 'Det er ikke noe rapportert innhold',
			'reportedcontent:report' => 'Rapporter til en admin',
			'reportedcontent:title' => 'Side tittel',
			'reportedcontent:deleted' => 'Rapportert innhold er slettet',
			'reportedcontent:notdeleted' => 'Vi kunne ikke slette denne rapporten',
			'reportedcontent:delete' => 'Slett det',
			'reportedcontent:areyousure' => 'Er du sikker p&aring; at du vil slette?',
			'reportedcontent:archive' => 'Arkiver det',
			'reportedcontent:archived' => 'Rapport arkivert',
			'reportedcontent:visit' => 'Bes&oslash;k rapportert element',
			'reportedcontent:by' => 'Rapportert av',
			'reportedcontent:objecttitle' => 'Objekt tittel',
			'reportedcontent:objecturl' => 'Objekt url',
			'reportedcontent:reason' => 'Grunn til rapportering',
			'reportedcontent:description' => 'Hvorfor rapporterer du dette?',
			'reportedcontent:address' => 'Hvor kan dette finnes',
			'reportedcontent:success' => 'Din rapport er blitt sendt',
			'reportedcontent:failing' => 'Din rapport ble ikke sendt',
			'reportedcontent:report' => 'Rapporter dette', 
			'reportedcontent:moreinfo' => 'Mer info',
	
			'reportedcontent:failed' => 'Beklager, rapportering av dette feilet.',
			'reportedcontent:notarchived' => 'Vi kunne ikke arkivere denne',
	);
					
	add_translation("no",$norwegian);
?>