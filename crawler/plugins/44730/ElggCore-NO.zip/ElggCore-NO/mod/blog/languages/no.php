<?php

	$norwegian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'blog' => "Blogg",
			'blogs' => "Blogger",
			'blog:user' => "%s's blogg",
			'blog:user:friends' => "%s's venners blogger",
			'blog:your' => "Din blogg",
			'blog:posttitle' => "%s's blogg: %s",
			'blog:friends' => "Venners blogger",
			'blog:yourfriends' => "Dine venners site blogger",
			'blog:everyone' => "Alle blogger",
			'blog:newpost' => "Post en ny blog-post",
			'blog:via' => "via blog",
			'blog:read' => "Les blogg",
	
			'blog:addpost' => "Skriv en blog-post",
			'blog:editpost' => "Endre blog-post",
	
			'blog:text' => "Blog tekst",
	
			'blog:strapline' => "%s",
			
			'item:object:blog' => 'Blog posts',
	
			'blog:never' => 'aldri',
			'blog:preview' => 'Forh&aring;ndsvisning',
	
			'blog:draft:save' => 'Hurtiglagring',
			'blog:draft:saved' => 'Hurtiglagret',
			'blog:comments:allow' => 'Godta kommentarer',
	
			'blog:preview:description' => 'Dette er en ulagret forh&aring;ndsvisning av posten.',
			'blog:preview:description:link' => 'For og fortsette og endre bloggen, klikk her.',
	
			
         /**
	     * Blog river
	     **/
	        
	        //generic terms to use
	        'blog:river:created' => "%s skrev",
	        'blog:river:updated' => "%s oppdaterte",
	        'blog:river:posted' => "%s postet",
	        
	        //these get inserted into the river links to take the user to the entity
	        'blog:river:create' => "en ny blog post som heter",
	        'blog:river:update' => "sin blogpost som heter",
	        'blog:river:annotate' => "en kommentar p&aring; denne blog posten",
			
	
		/**
		 * Status messages
		 */
	
			'blog:posted' => "Din blog-post har blitt postet!",
			'blog:deleted' => "Din blog-post ble slettet!",
	
		/**
		 * Error messages
		 */
	
			'blog:error' => 'Feil oppstod. Pr&oslash;v igjen.',
			'blog:save:failure' => "Din blog-post ble ikke lagret vennligst pr&oslash;v igjen.",
			'blog:blank' => "Beklager, du m&aring; fylle i b&aring;de tittel og tekst f&oslash;r du poster innlegget.",
			'blog:notfound' => "Beklager, denne blog-posten kan ha blitt slettet.",
			'blog:notdeleted' => "Beklager, vi kunne ikke slette denne blog-posten.",
	
	);
					
	add_translation("no",$norwegian);

?>