This translation is created by Simon A. Skaar.

Files in translation: Everyone in the Elgg core pack who you can get at Elgg.org

Every file is no.php and got the right values. 

If you got you're own plugin, and what it translated, please contact me at: simon@simithunder.org - Or at Elgg: Simox

Thank you for downloading this translation. - All credit goes to me for the Norwegian text, and this is licensed under: GNU General Public License (GPL) version 3.

Thanks to Elgg.org