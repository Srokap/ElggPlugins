AU-Files-Widget-1.8.x
=====================

Allows additional configuration for the files widget in Elgg 1.8

Plugin should reside in  mod/au_files_widget