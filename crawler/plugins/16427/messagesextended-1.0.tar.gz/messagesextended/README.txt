Messages extended plugin
=======================

This plugin add the following features:
  - a messages notification handler
  - a js prettifier for links inside internal messages.
  - some patchs for use this functionalities on current elgg notifications.
  
Provided patchs
===============
messages-notification.path
--------------------------
Update the send action for only send messages notifications to the email.

groups-notification.path
------------------------
Update the joinrequest and addtogroup action notifications to use all notification handlers.
