<?php
/**
 * Messages extended
 *
 * @package ElggMessagesExtended
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Diego Andrés Ramírez Aragón <diego@somosmas.org>
 * @copyright Corporación Somos más - 2008
 * @link http://www.somosmas.org
 *
 */


/**
 * Messages extended init function
 *
 * Register the notification handler and the configuration settings
 */
function messagesextended_init(){

  extend_view("metatags","messages/js");

  if(!is_plugin_enabled("messages")){
    register_error(elgg_echo("messagesextended:nomessages"));
    return;
  }
  register_notification_handler("messages", "messages_notify_handler");

  //@todo Add notificacions config settings page
  $users_updated = get_plugin_setting("usersupdated","messagesextended");
  if(!$users_updated || $users_updated=="no"){
    messagesextended_configure_users();
  }
}

/**
 * Configures messages notification for all registered users
 *
 */
function messagesextended_configure_users(){
  $users = get_entities("user","",0,"",null);
  if(!empty($users)){
    foreach($users as $user){
      $result = set_user_notification_setting($user->guid, "messages",true);
      if (!$result){
        register_error(elgg_echo('notifications:usersettings:save:fail'));
      }
    }
    set_plugin_setting("usersupdated","yes","messagesextended");
  }
}

/**
 * Messages notificacion handler
 *
 * @param ElggEntity $from
 * @param ElggUser $to
 * @param string $subject
 * @param string $message_contents
 * @param array $params
 */
function messages_notify_handler(ElggEntity $from, ElggUser $to, $subject, $message_contents, array $params = NULL){
  if (!$from){
    throw new NotificationException(sprintf(elgg_echo('NotificationException:MissingParameter'), 'from'));
  }
  if (!$to){
    throw new NotificationException(sprintf(elgg_echo('NotificationException:MissingParameter'), 'to'));
  }

  $subject = preg_replace("/(\r\n|\r|\n)/", " ", $subject); // Strip line endings
  $message_contents= strip_tags($message_contents); // Strip tags from message
  $message_contents = preg_replace("/(\r\n|\r)/", "<br>", $message_contents); // Convert to unix line endings in body

  // Initialise a new ElggObject
  $message = new ElggObject();
  // Tell the system it's a message
  $message->subtype = "messages";
  // Set its owner to the current user
  $message->owner_guid = $from->getGUID();
  // For now, set its access to public (we'll add an access dropdown shortly)
  $message->access_id = 2;
  // Set its description appropriately
  $message->title = $subject;
  $message->description = $message_contents;

  // set the metadata
  $message->toId = $to->getGUID(); // the user receiving the message
  $message->readYet = 0; // this is a toggle between 0 / 1 (1 = read)
  $message->hiddenFrom = 0; // this is used when a user deletes a message in their sentbox, it is a flag
  $message->hiddenTo = 0; // this is used when a user deletes a message in their inbox

  // Save 'send' the message
  if (!$message->save()) {
    register_error(elgg_echo("messages:error"));
  }
  // Success message
  system_message(elgg_echo("messages:posted"));
}

register_elgg_event_handler('init','system','messagesextended_init');
?>