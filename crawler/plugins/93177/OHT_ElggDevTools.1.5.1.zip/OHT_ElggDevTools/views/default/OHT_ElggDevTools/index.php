<?php 
/*******************************************************************************
 * Admin Form View
 * 
 * This is the form that the admin uses to change elgg dev tools options
 * 
 * @package OHT
 * @subpackage ElggDevTools
 * @author Aaron Saray (102degrees.com)
 ******************************************************************************/

echo '<div class="contentWrapper">';
echo '<p>' . elgg_echo('OHT_ElggDevTools:formexplanation') . '</p>';

/******************** build form *******************************/

/** delete views **/
$form_body = "<fieldset><legend>" . elgg_echo('OHT_ElggDevTools:OHTlegend') . "</legend>";
$form_body .= '<p>' . elgg_echo('OHT_ElggDevTools:OHTexplanation') . '</p>';

$form_body .= "<p><h3>" . elgg_echo('OHT_ElggDevTools:deleteviews:question') . "</h3>";
$value = (int) get_plugin_setting('deleteviews', 'OHT_ElggDevTools');
$form_body .= elgg_view('input/radio', array('value'=>$value, 'internalname'=>'deleteviews', 'options'=>array(elgg_echo('OHT_ElggDevTools:deleteviews:answer:yes')=>1, elgg_echo('OHT_ElggDevTools:deleteviews:answer:no')=>0)));
$form_body .= '<em>' . elgg_echo('OHT_ElggDevTools:deleteviews:explanation') . '</em></p>';
/** end delete views **/

/** firephp **/
$form_body .= '<p><h3>' . elgg_echo('OHT_ElggDevTools:enablefirephp:question') . '</h3>';
$value = (int) get_plugin_setting('enablefirephp', 'OHT_ElggDevTools');

/** helper - see if fire php extension is installed - sometimes is wrong - drat **/
if ($value) {
    if (class_exists('FirePHP')) {
        $fb = FirePHP::getInstance(TRUE);
        if (!$fb->detectClientExtension()) {
            $form_body .= '<em class="error" id="firephperror">' . elgg_echo('OHT_ElggDevTools:enablefirephp:warning') . '</em><br />';
        }
    } 
}

$form_body .= elgg_view('input/radio', array('value'=>$value, 'internalname'=>'enablefirephp', 'options'=>array(elgg_echo('OHT_ElggDevTools:enablefirephp:answer:yes')=>1, elgg_echo('OHT_ElggDevTools:enablefirephp:answer:no')=>0)));
$form_body .= '<em>' . elgg_echo('OHT_ElggDevTools:enablefirephp:explanation') . '</em></p>';
/** end firephp **/

/** display errors **/
$form_body .= "<p><h3>" . elgg_echo('OHT_ElggDevTools:displayerrors:question') . "</h3>";
$value = (int) get_plugin_setting('displayerrors', 'OHT_ElggDevTools');
$form_body .= elgg_view('input/radio', array('value'=>$value, 'internalname'=>'displayerrors', 'options'=>array(elgg_echo('OHT_ElggDevTools:displayerrors:answer:yes')=>1, elgg_echo('OHT_ElggDevTools:displayerrors:answer:no')=>0)));
$form_body .= '<em>' . elgg_echo('OHT_ElggDevTools:displayerrors:explanation') . '</em></p>';
/** end display errors **/

$form_body .= '</fieldset><br />';
$form_body .= '<fieldset><legend>' . elgg_echo('OHT_ElggDevTools:Defaultlegend') . '</legend>';
$form_body .= '<p>' . elgg_echo('OHT_ElggDevTools:Defaultexplanation') . '</p>';

/** simpel cache **/
$form_body .= "<p><h3>" . elgg_echo('OHT_ElggDevTools:simplecache:question') . "</h3>";
$value = $vars['config']->simplecache_enabled;
$form_body .= elgg_view('input/radio', array('value'=>$value, 'internalname'=>'usesimplecache', 'options'=>array(elgg_echo('OHT_ElggDevTools:simplecache:answer:yes')=>1, elgg_echo('OHT_ElggDevTools:simplecache:answer:no')=>0)));
$form_body .= '<em>' . elgg_echo('installation:simplecache:description') . '</em></p>';
/** end simple cache **/

/** debug **/
$form_body .= "<p><h3>" . elgg_echo('OHT_ElggDevTools:debug:question') . "</h3>";
$value = (int) $vars['config']->debug;
$form_body .= elgg_view('input/radio', array('value'=>$value, 'internalname'=>'debug', 'options'=>array(elgg_echo('OHT_ElggDevTools:debug:answer:yes')=>1, elgg_echo('OHT_ElggDevTools:debug:answer:no')=>0)));
$form_body .= '<em>' . elgg_echo('installation:debug') . '</em></p>';
/** end debug **/


$form_body .= '</fieldset>';

$form_body .= elgg_view('input/submit', array('value'=>elgg_echo('OHT_ElggDevTools:formbutton')));

echo elgg_view('input/form', array('body'=>$form_body, 'action'=>$CONFIG->wwwroot . 'action/OHT_ElggDevTools/updatesettings', 'internalid'=>'OHT_ElggDevTools_form'));

echo '</div>';