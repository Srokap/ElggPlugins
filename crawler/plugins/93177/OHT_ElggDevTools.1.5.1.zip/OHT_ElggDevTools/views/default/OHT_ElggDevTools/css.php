<?php 
/*******************************************************************************
 * CSS for Elgg Dev Tools
 * 
 * This is used to style the admin form
 * 
 * @package OHT
 * @subpackage ElggDevTools
 * @author Aaron Saray (102degrees.com)
 ******************************************************************************/
?>
#OHT_ElggDevTools_form em {
    font-size: 75%;
    font-style: italic;
}
#OHT_ElggDevTools_form fieldset, #OHT_ElggDevTools_form legend {
    border: 2px solid #DEDEDE;
    padding: 5px;
}
#OHT_ElggDevTools_form legend {
    font-weight: bold;
    background-color: #eee;
}
#OHT_ElggDevTools_form .error {
    color: #f00;
}