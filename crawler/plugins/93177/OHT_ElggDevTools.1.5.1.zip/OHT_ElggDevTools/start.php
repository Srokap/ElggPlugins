<?php
/*******************************************************************************
 * Extra Development Tools for Elgg Hackers
 * 
 * This script launches all of the plugin functionality for the dev tools
 * 
 * @package OHT
 * @subpackage ElggDevTools
 * @author Aaron Saray (102degrees.com)
 ******************************************************************************/

/**
 * The Initial Plugin launcher
 * 
 * This launches the dev tools code - as well as grabs additional CSS to extend
 * the view.  This is also the main hook that must be there.
 * 
 * @return boolean launched successfully?
 */
function OHT_ElggDevTools_init()
{
    /** bring in main logic -- also note: we still run this even if the user isn't admin - you may be testing **/
    require_once dirname(__FILE__) . '/includes/OHT_ElggDevTools.php';
    OHT_ElggDevTools::launcher();
    
    /** only bring in CSS when admin - cuz its for the menu/form **/
    if (isadminloggedin()) {
        extend_view('css', 'OHT_ElggDevTools/css');
    }
    
    return true;
}

/**
 * Page handler - used for making pretty URLs
 * 
 * Right now, we're only using one page - so this is pretty simple
 * 
 * @return boolean whether it included the file
 */
function OHT_ElggDevTools_page_handler()
{
    global $CONFIG;
    return require $CONFIG->pluginspath . "OHT_ElggDevTools/index.php"; 
}

/**
 * Page setup - adds menu options
 * @return boolean whether the menu option was added successfully
 */
function OHT_ElggDevTools_pagesetup()
{
    if (get_context () == 'admin' && isadminloggedin ()) {
        global $CONFIG;
        add_submenu_item (elgg_echo('OHT_ElggDevTools:adminlink'), $CONFIG->wwwroot . 'pg/OHT_ElggDevTools');
    }
    
    return true;
}

/** register event handlers **/
register_elgg_event_handler('init', 'system', 'OHT_ElggDevTools_init', 1);
register_elgg_event_handler('pagesetup', 'system', 'OHT_ElggDevTools_pagesetup');

/** make pretty URLs **/
register_page_handler('OHT_ElggDevTools','OHT_ElggDevTools_page_handler');

/** register actions **/
register_action("OHT_ElggDevTools/updatesettings", false,$CONFIG->pluginspath ."OHT_ElggDevTools/actions/updatesettings.php", true);
?>