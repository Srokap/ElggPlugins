<?php
/*******************************************************************************
 * Elgg Dev Tools Language File
 * 
 * @package OHT
 * @subpackage ElggDevTools
 * @author Aaron Saray (102degrees.com)
 ******************************************************************************/

/** build new array **/
$english = array(
    /** generics **/
    'OHT_ElggDevTools:Title'                    => '102 Degrees Elgg Dev Tools',
    'OHT_ElggDevTools:adminlink'                => 'Elgg Dev Tools',
    'OHT_ElggDevTools:message:successfulupdate' => 'The Dev Settings have been updated.',
        
    /** form elements **/
    'OHT_ElggDevTools:OHTlegend'                => '102 Degrees Elgg Dev Tools Options',
    'OHT_ElggDevTools:OHTexplanation'           => 'The following are options that have specifically added by 102 Degrees to add additional functionality for development.',
    'OHT_ElggDevTools:Defaultlegend'            => 'Default Elgg Settings',
    'OHT_ElggDevTools:Defaultexplanation'       => 'These are settings that exist elsewhere in the Elgg installation - but are also here for quick reference.  <strong>Important Note:</strong> Changing the settings here will also change them anywhere else they are located.',
    'OHT_ElggDevTools:formbutton'               => 'Update Dev Settings',
    'OHT_ElggDevTools:formexplanation'          => 'The following options should help make your Elgg hacking easier!',

    /** delete views **/
    'OHT_ElggDevTools:deleteviews:question'     => 'Delete Views Cache on every page load?',
    'OHT_ElggDevTools:deleteviews:answer:yes'   => 'Yes',
    'OHT_ElggDevTools:deleteviews:answer:no'    => 'No',
    'OHT_ElggDevTools:deleteviews:explanation'  => 'Normally, you have to run the /update.php script or disable/renable your plugin to read in a new view cache.  When you enable this, it deletes the view cache each page load.  While harder on the development server, it saves tons of time when adding new views.',

    /** fire php **/
    'OHT_ElggDevTools:enablefirephp:question'   => 'Enable FirePHP Logging?',
    'OHT_ElggDevTools:enablefirephp:answer:yes' => 'Yes',
    'OHT_ElggDevTools:enablefirephp:answer:no'  => 'No',
    'OHT_ElggDevTools:enablefirephp:explanation'=> 'Enable the FirePHP logging class - useful for ajax development.  See <a href="http://firephp.org">firephp.org</a>.',
    'OHT_ElggDevTools:enablefirephp:warning'    => "FirePHP is saying that you don't have the FirePHP Firefox extension installed.  If you really don't, check out <a href=\"http://firephp.org\">firephp.org</a> to get it.  Otherwise, just ignore this message.",

    /** display errors **/
    'OHT_ElggDevTools:displayerrors:question'   => 'Display Errors?',
    'OHT_ElggDevTools:displayerrors:answer:yes' => 'Yes',
    'OHT_ElggDevTools:displayerrors:answer:no'  => 'No',
    'OHT_ElggDevTools:displayerrors:explanation'=> 'This is normally an ini setting in php.ini - and is overwritten by the Elgg .htaccess file.  The philosophy I follow is not to patch any of the Elgg core files - so you can reset this value here.  Turn on only during development!',


    /** simple cache **/
    'OHT_ElggDevTools:simplecache:question'     => 'Use Simple Cache?',
    'OHT_ElggDevTools:simplecache:answer:yes'   => 'Yes',
    'OHT_ElggDevTools:simplecache:answer:no'   => 'No',

    /** debug **/
    'OHT_ElggDevTools:debug:question'     => 'Enable Debug?',
    'OHT_ElggDevTools:debug:answer:yes'   => 'Yes',
    'OHT_ElggDevTools:debug:answer:no'   => 'No',

);
                    
add_translation("en",$english);
?>