	<?php
	/**
	 * Elgg plugin to allow using the web cam to capture profile icons
	 * 
	 * @author  Lenny Urbanowski
	 * @link	http://www.itslennysfault.com
	 * @package photobooth
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 *
	 * Created for Gabriel Media Group (http://www.gabrielmediagroupinc.com
	 *
	 *	uploadicon.php - View for the upload icon tabs
	 *						Pretty much unmodified from profile module
	 */


	$currentuser = $_SESSION['user'];
?>
<div id="current_user_avatar">

	<label><?php echo elgg_echo('profile:currentavatar'); ?></label>
	<?php 
		
		$user_avatar = $currentuser->getIcon('medium');
		echo "<img src=\"{$user_avatar}\" alt=\"avatar\" />";

	?>

</div>

<div id="profile_picture_form">
	<form action="<?php echo $vars['url']; ?>action/profile/iconupload" method="post" enctype="multipart/form-data">
	<?php echo elgg_view('input/securitytoken'); ?>
	<input type="hidden" name="username" value="<?php echo $currentuser->username; ?>" />
	<p><label><?php echo elgg_echo("photobooth:upload"); ?></label><br />
	
		<?php
			
			echo elgg_view("input/file",array('internalname' => 'profileicon'));
		?>
		<br /><input type="submit" class="submit_button" value="<?php echo elgg_echo("upload"); ?>" />
	</p>
	</form>
</div>