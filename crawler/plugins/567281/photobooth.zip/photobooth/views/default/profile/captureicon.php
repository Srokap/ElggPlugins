	<?php
	/**
	 * Elgg plugin to allow using the web cam to capture profile icons
	 * 
	 * @author  Lenny Urbanowski
	 * @link	http://www.itslennysfault.com
	 * @package photobooth
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 *
	 * Created for Gabriel Media Group (http://www.gabrielmediagroupinc.com
	 *
	 *	captureicon.php - View for the Capture icon swf
	 */
	 global $CONFIG;
	?>
	<p><label><?php echo elgg_echo("photobooth:capture"); ?></label><br />
	<div id="flashArea" class="flashArea" style="height:100%;">
		<p align="center">This content requires the Adobe Flash Player.<br /><a href="http://www.adobe.com/go/getflashplayer">
		<img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Get Adobe Flash player" /><br />
		<a href="http://www.macromedia.com/go/getflash/">Get Flash</a></p>

	</div>
	 <script type="text/javascript" src="<?php echo($CONFIG->wwwroot); ?>mod/photobooth/js/swfobject.js"></script>
	  <script type="text/javascript">
		var mainswf = new SWFObject("<?php echo($CONFIG->wwwroot); ?>mod/photobooth/swf/take_picture.swf", "main", "680", "400", "9", "#ffffff");
		mainswf.addParam("scale", "noscale");
		mainswf.addParam("wmode", "window");
		mainswf.addParam("allowFullScreen", "true");
		//mainswf.addVariable("requireLogin", "false");
		mainswf.write("flashArea");
		
	  </script>
	</p>
