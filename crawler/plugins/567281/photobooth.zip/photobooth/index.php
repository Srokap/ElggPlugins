<?php
	/**
	 * Elgg plugin to allow using the web cam to capture profile icons
	 * 
	 * @author  Lenny Urbanowski
	 * @link	http://www.itslennysfault.com
	 * @package photobooth
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 *
	 * Created for Gabriel Media Group (http://www.gabrielmediagroupinc.com
	 */

	//Load engine
	require_once(dirname(dirname(dirname(__FILE__))) . '/engine/start.php');
	//Saftey First
	gatekeeper();
	//load GET value
	$display = get_input('display','');
	global $CONFIG;
	//display proper content for page
	if($display=="capture"){
		include(dirname(__FILE__)."/views/default/profile/captureicon.php");
	}else{
		include(dirname(__FILE__)."/views/default/profile/uploadicon.php");
	}	
?>