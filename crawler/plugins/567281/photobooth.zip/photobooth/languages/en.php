<?php
	/**
	 * Elgg plugin to allow using the web cam to capture profile icons
	 * 
	 * @author  Lenny Urbanowski
	 * @link	http://www.itslennysfault.com
	 * @package photobooth
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 *
	 * Created for Gabriel Media Group (http://www.gabrielmediagroupinc.com
	 *
	 *	en.php - English language variables
	 */

	$english = array(

	/**
	 * Profile
	 */

		'photobooth:upload' => "Upload Icon",
		'photobooth:capture' => "Capture Icon",
		'photobooth:saveerror' =>"Properly encoded JPEG information not received from flash object."

	);

	add_translation("en",$english);