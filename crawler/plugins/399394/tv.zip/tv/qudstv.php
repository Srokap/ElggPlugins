<?php
	 
	 
	// Load Me2all engine
		require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
		
	// Get the current page's owner
	 set_context('tv');

	//set stores title
		$title = elgg_view_title(elgg_echo('qudstv'));
	
		$area2 = <<<EOF
			{$title}
			<div >
		<center>	<object width="490" height="393" classid="CLSID:22d6f312-b0f6-11d0-94ab-0080c74c7e95"
id="mediaplayer1">
        <param name="Filename" value="mms://89.202.214.2/e5e0e37b-86ec-4ec7-bacc-b7f93f3b5283">
        <param name="AutoStart" value="True">
        <param name="ShowControls" value="true">
        <param name="ShowStatusBar" value="true">
        <param name="ShowDisplay" value="False">
        <param name="AutoRewind" value="True">
        <embed src="mms://89.202.214.2/e5e0e37b-86ec-4ec7-bacc-b7f93f3b5283" width="380" height="270" autostart="True" showcontrols="True" showstatusbar="False" showdisplay="False" autorewind="True"> 

</embed> </object><center></div>
EOF;
	

	// Create a layout
		$body = elgg_view_layout('two_column_left_sidebar', $area1, $area2);
	
	// Finally draw the page
		page_draw(sprintf(elgg_echo("qudstv"),'me2all'), $body);
	
?>