
<?php

	/**
	 * Me2all tv Plugin
	 * 
	 * @package tv
 	 * @author l'alchimiste
	 * @copyright me2all 2010
	 *freedom to palestine
	 * for free use
	 */

?>

<?php
 
		require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	 
	//set stores title
	 
			$title = elgg_view_title(elgg_echo("france24"));
	 $var=

		$area2 = <<<EOF
			{$title}
			<div >
			<object width="360" height="270"
classid="CLSID:22d6f312-b0f6-11d0-94ab-0080c74c7e95"
id="mediaplayer1">
        <param name="Filename" value="mms://stream1.france24.yacast.net/f24_livefrda">
        <param name="AutoStart" value="False">
        <param name="ShowControls" value="true">
        <param name="ShowStatusBar" value="true">
        <param name="ShowDisplay" value="False">
        <param name="AutoRewind" value="True">
        <embed src="mms://stream1.france24.yacast.net/f24_livefrda" width="380" height="270" autostart="True" showcontrols="True" showstatusbar="False" showdisplay="False" autorewind="True"> 

</embed> </object></div>
EOF;
	
	// These for left side menu $area1 .= gettags();
		
		
	// Create a layout
		$body = elgg_view_layout('two_column_left_sidebar', $area1, $area2);
	
	// Finally draw the page
		page_draw(sprintf(elgg_echo("france24"),page_owner_entity()->name), $body);
	
?>