
<?php

	/**
	 * Me2all tv Plugin
	 * 
	 * @package tv
 	 * @author l'alchimiste
	 * @copyright me2all 2010
	 *freedom to palestine
	 * for free use
	 */

?>

<?php
 
		require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	 
	//set stores title
	 
			$title = elgg_view_title(elgg_echo("TV"));
	//set_context('tv');

		$area2 = <<<EOF
<iframe id="ifrVideoStreaming" name="ifrVideoStreaming" src="http://www.aljazeera.net/Channel/LiveStreamingPlayer/index.html"
											frameborder="0" scrolling="no" width="390" height="293"></iframe>
EOF;
	
	// These for left side menu 
	//$area1 .= gettags();
		
		
	// Create a layout
		$body = elgg_view_layout('two_column_left_sidebar', $area1, $area2);
	
	// Finally draw the page
		page_draw(sprintf(elgg_echo("tv"),page_owner_entity()->name), $body);
	
?>