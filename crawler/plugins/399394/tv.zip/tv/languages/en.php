<?php

	$english = array(
	
		/**
		 * Menu items and titles
		 */
		'user:edit'=>"edit to choose your tv",
		 'tv:mode' => "full screen", 
		 'tv:choice' => "choose your tv",
		 	
			'tv:tv' => "tv streams", 
            'tv:disc' => "tv",  
	);
					
	add_translation("en",$english);

?>