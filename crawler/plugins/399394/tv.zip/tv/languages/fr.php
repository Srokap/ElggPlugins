<?php
 
 
 
$french = array( 
		/**
		 * Menu items and titles
		 */
	'user:edit' => "Cliquer sur Modifier pour choisir une cha&icirc;ne",
		 'tv:mode' => "plein ecran",
		 'tv:choice' => "Choisir tv",
			'tv:tv' => "tv en ligne",
			'tv:disc' => "pluging pour participer aux salon de discussion sur tv",
); 
 
add_translation('fr', $french); 
 
?>