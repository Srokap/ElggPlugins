<?php

	/**
	 * Me2all tv Plugin
	 * 
	 * @package tv
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author l'alchimiste
	 * @copyright me2all 2010
	 *freedom to palestine
	 * 
	 */

?>


<table   border="0" align="center" cellpadding="0" cellspacing="10">
  <tr>
    <th colspan="1" scope="col">
	 
 
	
	<div>
	<h3><b><?php echo elgg_echo('tv:choice'); ?></b></h3>
	<select name="params[tv]">
	    <option value="france24" <?php if ($vars['entity']->select == 'france24') echo " selected=\"france24\" "; ?>><?php echo elgg_echo('france24'); ?></option>
	  
		 <option value="qudstv" <?php if ($vars['entity']->select == 'qudstv') echo " selected=\"qudstv\" "; ?>><?php echo elgg_echo('Qudstv'); ?></option>
		
		<option value="aljazeera" <?php if ($vars['entity']->select == 'aljazeera') echo " selected=\"aljazeera\" "; ?>><?php echo elgg_echo('aljazeera'); ?></option>
		 
	 
	 
	 
   </p> 
	</div>
	</th>
  </tr>
  
  <tr> <th>
</div></th> </tr>

  <tr>
    <td valign="middle"><div>
<p>
	
</table>

<div><hr align="center" width="100%" size="1" noshade="noshade" />
</div>
