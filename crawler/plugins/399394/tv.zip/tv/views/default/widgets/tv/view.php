
<?php

	/**
	 * Me2all tv Plugin
	 * 
	 * @package tv
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author l'alchimiste
	 * @copyright me2all 2010
	 *freedom to palestine
	 * 
	 */

?>

	 <meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1251\">

		
 
	 
	 
<div class="contentWrapper user_settings">

<?php echo elgg_echo('user:edit'); ?>

<center>
 <a href="<?php echo $vars['url']; ?>pg/tv/<?php echo $vars['entity']->tv; ?>" ><img src="<?php echo $vars['url']; ?>mod/tv/graphics/<?php echo $vars['entity']->tv ; ?>.jpg"><br><?php echo elgg_echo('tv:mode'); ?></a>
 </center>
<br/>
