<?php
  function tv_init() {   
  // Load system configuration
			global $CONFIG;
	if (isloggedin()) {
    				
	 add_menu(elgg_echo('tv'), $CONFIG->wwwroot . "pg/tv/aljazeera" );//. $_SESSION['user']->username);
					
			// And for logged out users
				} 

		register_page_handler('tv','tv_page_handler');
	
 add_widget_type('tv', 'tv ', elgg_echo("tv:tv"));//last parametre pour info bull sur le tablo des widgets:)
  }
 function tv_page_handler($page) {
			
			// The first component of a blog URL is the username
		  set_context('tv');
			
			// In case we have further input
			/*if (isset($page[1])) {
				set_input('param1',$page[1]);					
			}*/
	  if (isset($page[0])) {
  set_input('tvstream',$page[0]);
			switch($page[0]) {
				case "qudstv":	
				 
	                @include(dirname(__FILE__) . "/qudstv.php");		
	                 break;	
					 case "france24":	
				 
	                @include(dirname(__FILE__) . "/france24.php");
					
	                 break;
					 case "aljazeera":	
				 
	                @include(dirname(__FILE__) . "/aljazeera.php");		
	                 break;
					 
										}
										}
																		
			else 
			
				@include(dirname(__FILE__) . "/index.php");
				return true;
		
			
		}
	

		function tv_pagesetup() {
		global $CONFIG;
  if (get_context() == "tv") 
		 {
			//if (isloggedin()) {
			//if ((page_owner() == $_SESSION['guid'] || !page_owner()) && isloggedin()) {
				
			    add_submenu_item(elgg_echo('aljazeera'),$CONFIG->wwwroot."pg/tv/aljazeera/",'tv');
				add_submenu_item(elgg_echo('qudstv'),$CONFIG->wwwroot."pg/tv/qudstv/",'tv');
				add_submenu_item(elgg_echo('france24'),$CONFIG->wwwroot."pg/tv/france24/",'tv');
		//	} 
	 
		 }
	}
	
	
	
  register_elgg_event_handler('init','system','tv_init');  
  register_elgg_event_handler('pagesetup','system','tv_pagesetup');
  
?>