<?php
	 
	 
	// Load Me2all engine
		require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
		
	// Get the current page's owner
	  set_context('tv');

	//set stores title
		$title = elgg_view_title(elgg_echo('Aljazeera'));
	
		$area2 = <<<EOF
			{$title}
			<div >
		<center>				 
<iframe id="ifrVideoStreaming" name="ifrVideoStreaming" src="http://www.aljazeera.net/Channel/LiveStreamingPlayer/index.html"
											frameborder="0" scrolling="no" width="390" height="293"></iframe>
		</center></div>
EOF;
		

	// Create a layout
		$body = elgg_view_layout('two_column_left_sidebar', $area1, $area2);
	
	// Finally draw the page
		page_draw(sprintf(elgg_echo("Aljazeera"),'me2all'), $body);
	
?>