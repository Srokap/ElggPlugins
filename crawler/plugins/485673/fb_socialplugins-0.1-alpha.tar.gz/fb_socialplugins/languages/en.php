<?php

$english = array(
    'fb_plugins:example:title'=>"Facebook plugins fields example page",
    'fb_plugins:like'=>"Like",
    'fb_plugins:like_box'=>"Like box",
    'fb_plugins:activity'=>"Activity",
    'fb_plugins:livefeed'=>"Livefeed",
    'fb_plugins:recommendations'=>"Recommendations",
);

add_translation('en',$english);
?>