<?php
	echo $vars['url'] . "mod/theme_eosx_fish_eye/graphics/group_icons/defaultmedium.gif";
?>