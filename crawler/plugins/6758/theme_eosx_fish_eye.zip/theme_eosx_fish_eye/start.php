<?php

    /**
     * eosx theme Fish Eye
     **/
     
     /**
	 * Initialise the theme 
	 *
	 */
	function eosxfisheye_init(){
	
    }
	
	// Initialise log browser
	register_elgg_event_handler('init','system','eosxfisheye_init');
	
?>