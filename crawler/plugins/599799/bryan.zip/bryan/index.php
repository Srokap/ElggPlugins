<center>
<div id="welcome-box">
<div id="login-box">
<?php
$form_body = "<p><label>" . elgg_echo('username') . "<br />" . elgg_view('input/text', array('internalname' => 'username', 'class' => 'login-textarea')) . "</label><br />";
$form_body .= "<label>" . elgg_echo('password') . "<br />" . elgg_view('input/password', array('internalname' => 'password', 'class' => 'login-textarea')) . "</label><br />";
$form_body .= elgg_view('input/submit', array('value' => elgg_echo('login'))) . "</p>";
$form_body .= "<p><a href=\"". $vars['url'] ."account/register.php\">" . elgg_echo('register') . "</a> | <a href=\"". $vars['url'] ."account/forgottn_password.php\">" . elgg_echo('user:password:lost') . "</a></p>";

echo elgg_view('input/form', array('body' => $form_body, 'action' => "". $vars['url'] ."action/login"));
?>


</center>