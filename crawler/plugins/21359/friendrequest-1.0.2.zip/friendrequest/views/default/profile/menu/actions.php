<?php

if (isloggedin()) {
	$user_guid = $_SESSION['user']->getGUID();
	$other_guid = $vars['entity']->getGUID();
	if ( $user_guid != $other_guid) {
		// If is a friend, then you can remove them
		if($vars['entity']->isFriend()) {
			echo "<p class=\"user_menu_removefriend\"><a href=\"{$vars['url']}action/friends/remove?friend={$vars['entity']->getGUID()}\">" . elgg_echo("friend:remove") . "</a></p>";
			return;
		// If YOU requested them, then you can cancel the request (assuming they haven't said yes yet)
		} else if (user_requested_friend($user_guid, $other_guid)) {
			echo "<p class=\"user_menu_addfriend\"><a href=\"{$vars['url']}action/friends/cancel?friend={$vars['entity']->getGUID()}\">" . elgg_echo("friends:cancel_request") . "</a></p>";
		// If THEY requested you, you can either confirm or deny
		} else if (user_requested_friend($other_guid, $user_guid)) {
			echo "<p class=\"user_menu_addfriend\"><a href=\"{$vars['url']}action/friends/confirm?friend={$other_guid}\">" . elgg_echo("friends:confirm_request") . "</a></p>";
			echo "<p class=\"user_menu_addfriend\"><a href=\"{$vars['url']}action/friends/refuse?friend={$other_guid}\">" . elgg_echo("friends:deny_request") . "</a></p>";
		// Otherwise, there is no relation, so there is just add	
		}else {
			echo "<p class=\"user_menu_addfriend\"><a href=
			\"{$vars['url']}action/friends/add?friend={$vars['entity']->getGUID()}
			\">" . elgg_echo("friend:add") . "</a></p>";
		}
	}
}

?>