<?php


// Ensure we are logged in
gatekeeper();

// Get the GUID of the user to friend
$friend_guid = get_input('friend');
$friend = get_entity($friend_guid);

$errors = false;

// If already a friend, certainly don't add them again!
if(user_is_friend($_SESSION['user']->guid, $friend_guid)) {
	register_error(sprintf(elgg_echo("friends:request:already"),$friend->name));
	forward("pg/friends/" . $_SESSION['user']->username . "/");
}

// Get the user
try {
	if(!user_confirm_friend_request($_SESSION['user']->guid, $friend_guid)) {
		register_error(sprintf(elgg_echo("friends:add:failure"),$friend->name));
		$errors = true;
	}

	//			$_SESSION['user']->addFriend($friend_guid);
} catch (Exception $e) {
	register_error(sprintf(elgg_echo("friends:add:failure"),$friend->name));
	$errors = true;
}
if (!$errors)
system_message(sprintf(elgg_echo("friends:add:successful"),$friend->name));

// Forward to the user friends page
forward("pg/friends/" . $_SESSION['user']->username . "/");

?>