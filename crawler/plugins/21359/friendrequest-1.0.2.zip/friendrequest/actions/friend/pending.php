<?php
// Start engine
require_once(dirname(dirname((__FILE__))) . "/engine/start.php");

// You need to be logged in for this one

if (!$owner = page_owner_entity()) {
	gatekeeper();
	set_page_owner($_SESSION['user']->getGUID());
	$owner = $_SESSION['user'];
}

$area2 = '';

set_context('friend_request_received');
$requests_received =
list_entities_from_relationship('friend_request',$owner->getGUID(),true,'user','',0,10,false);

if ( !empty($requests_received) ) {
	$area2  .= elgg_echo_headline('friends:requests_received',1);
	$area2  .= $requests_received;
}

set_context('friend_request_sent');
$requests_sent = list_entities_from_relationship('friend_request',
$owner->getGUID(),false,'user','',0,10,false);

if ( !empty($requests_sent) ) {
	$area2  .= elgg_echo_headline('friends:requests_sent',1);
	$area2  .= $requests_sent;
}

if ( empty($area2) ) {
	$area2  .= elgg_echo('friends:no_requests');
}

// Format page
$body = elgg_view_layout('two_column_left_sidebar', '',
elgg_view_title(elgg_echo('friends:requests')) . $area2);

// Draw it
echo page_draw(elgg_echo('friends:collections'),$body);
?>