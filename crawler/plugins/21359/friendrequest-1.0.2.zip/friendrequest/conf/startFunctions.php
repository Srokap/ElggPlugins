<?php

global $CONFIG;
/**
 * Adds a user to this user's friends list
 *
 * @param int $friend_guid The GUID of the user to add
 * @return true|false Depending on success
 */
function addFriendRequest($me_uid, $friend_guid) { return
user_add_friend_request($me_uid, $friend_guid); }

/**
 * Refuses a friend request
 *
 * @param int $friend_guid The GUID of the user to remove
 * @return true|false Depending on success
 */
function refuseFriendRequest($me_uid, $friend_guid) { return
user_refuse_friend_request($me_uid, $friend_guid); }

/**
 * Confirms a friend request
 *
 * @param int $friend_guid The GUID of the user to remove
 * @return true|false Depending on success
 */
function confirmFriendRequest($me_uid,$friend_guid) { return
user_confirm_friend_request($me_uid, $friend_guid); }

/**
 * Cancels a friend request
 *
 * @param int $friend_guid The GUID of the user to remove
 * @return true|false Depending on success
 */
function cancelFriendRequest($me_uid,$friend_guid) { return
user_cancel_friend_request($me_uid, $friend_guid); }

/**
 * Adds a friends request.
 *
 * @param int $user_guid The GUID of the friending user
 * @param int $friend_guid The GUID of the user to friend
 * @return true|false Depending on success
 */
function user_add_friend_request($user_guid, $friend_guid) {
	global $CONFIG;

	$user_guid = (int) $user_guid;
	$friend_guid = (int) $friend_guid;
	if (!$friend = get_entity($friend_guid)) return false;
	if (!$user = get_entity($user_guid)) return false;
	if (get_class($user) != "ElggUser" || get_class($friend) !=
"ElggUser") return false;

	// Notify target user
	//	function notify_user($to, $from, $subject, $message, array $params = NULL, $methods_override = "")
	notify_user($friend_guid, $user_guid,
	sprintf(elgg_echo('friend:newfriendrequest:subject'), $user->name),
	sprintf(elgg_echo("friend:newfriendrequest:body"), $user->name, $CONFIG->site->url . "pg/profile/" . $user->username, $CONFIG->site->url . "pg/notifications/") ,
	array('application_name'=>elgg_echo('friends:request'), 'links'=>
	array(sprintf(elgg_echo('friend:lookAtProfile'), $user->name) . "|" . $CONFIG->site->url . "pg/profile/" . $user->username,
	elgg_echo('friends:confirm_request') . "|" . $CONFIG->site->url . "action/friends/confirm?friend=" . $user->getGUID(),
	elgg_echo('friends:deny_request') . "|" . $CONFIG->site->url . "action/friends/refuse?friend=" . $user->getGUID())));
	return add_entity_relationship($user_guid, "friend_request",
	$friend_guid);
}

/**
 * Refuses a friend request
 *
 * @param int $user_guid The GUID of the friending user
 * @param int $friend_guid The GUID of the user on the friends list
 * @return true|false Depending on success
 */
function user_refuse_friend_request($user_guid, $friend_guid) {
	$user_guid = (int) $user_guid;
	$friend_guid = (int) $friend_guid;
	return remove_entity_relationship($user_guid, "friend_request",
	$friend_guid);
}

/**
 * Refuses a friend request
 *
 * @param int $user_guid The GUID of the friending user
 * @param int $friend_guid The GUID of the user on the friends list
 * @return true|false Depending on success
 */
function user_cancel_friend_request($user_guid, $friend_guid) {
	$user_guid = (int) $user_guid;
	$friend_guid = (int) $friend_guid;
	return remove_entity_relationship($user_guid, "friend_request",
	$friend_guid);
}

/**
 * Adds a friends request.
 *
 * @param int $user_guid The GUID of the friending user
 * @param int $friend_guid The GUID of the user to friend
 * @return true|false Depending on success
 */
function user_confirm_friend_request($user_guid, $friend_guid) {
	global $CONFIG;

	$user_guid = (int) $user_guid;
	$friend_guid = (int) $friend_guid;
	if (!$friend = get_entity($friend_guid)) return false;
	if (!$user = get_entity($user_guid)) return false;

	if(!check_entity_relationship($friend_guid, "friend_request",	$user_guid)) {
		return false;
	}

	if (get_class($user) != "ElggUser" || get_class($friend) !="ElggUser") return false;

	// Notify target user
	//	notify_user($friend_guid, $user_guid,sprintf(elgg_echo('friend:confirm:subject'), $user->name),
	//	sprintf(elgg_echo("friend:confirm:body", $user->name), $user->name, $CONFIG->site->url . "pg/profile/" . $user->username));

	remove_entity_relationship($user_guid, "friend_request",
	$friend_guid);
	remove_entity_relationship($friend_guid, "friend_request",
	$user_guid);
	add_entity_relationship($friend_guid, "friend", $user_guid);
	return add_entity_relationship($user_guid, "friend", $friend_guid);
}


/**
 * Determines whether or not a user has requested another user's
 friendship.
 *
 * @param int $user_guid The GUID of the user
 * @param int $friend_guid The GUID of the friend
 * @return true|false
 */
function user_requested_friend($user_guid, $friend_guid) {
	return check_entity_relationship($user_guid, "friend_request",	$friend_guid);
}

function user_remove_friend_2way($user_guid, $friend_guid) {
	$user_guid = (int) $user_guid;
	$friend_guid = (int) $friend_guid;
	remove_entity_relationship($friend_guid, "friend", $user_guid);
	return remove_entity_relationship($user_guid, "friend",
	$friend_guid);
}



?>