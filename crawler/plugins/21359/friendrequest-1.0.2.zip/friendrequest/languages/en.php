<?php
$english = array(
                'friends:requests' => "Friend Requests",
                'friends:requests_sent' => "Your friend requests",
                'friends:requests_received' => "New friend request",

                'friends:pending' => "You have sent a friend request to %s",

                'friends:confirm' => "accept",
                'friends:refuse' => "refuse",
                'friends:cancel' => "cancel",
                'friends:cancel_request' => "Cancel friend request",
				'friends:confirm_request' => 'Confirm friend request',
				'friends:deny_request' => "Deny friend request",
                'friends:no_requests' => "At the moment you don't have any open
friends requests",

                'friends:request:successful' => "Your friend request
was successfully send to <b>%s</b> .",
                'friends:request:failure' => "We couldn't complete your friend
request to <b>%s</b>. Please try again.",
		'friends:request:already' => 'You are already friends with this person!',


                'friends:refuse:successful' => "The friend request of <b>%s</b> was
successfully refused.",
                'friends:refuse:failure' => "We couldn't refuse the friend request
of <b>%s</b>. Please try again.",

                'friends:confirm:successful' => "The friend request of <b>%s</b>
was successfully confirmed.",
                'friends:confirm:failure' => "We couldn't confirm the friend
request of <b>%s</b>. Please try again.",

                'friends:cancel:successful' => "Your friend request to <b>%s</b>
was successfully canceled.",
                'friends:cancel:failure' => "We couldn't cancel your friend request
to <b>%s</b>. Please try again.",
'friend:newfriendrequest:body' => "%s wants to add you to his friends list. Please confirm his request.<br /><br />  To view their profile, click here:<br /><br /> %s <br /><br />  To view your notifications, click here<br />&nbsp;%s<br /><br />   You cannot reply to this email.",
'friend:confirm:body' => 'Your friend request with %s has been confirmed!',
'friend:confirm:subject' => '%s has requested to be your friend',
'friend:remove:failure' => "We couldn't remove the friend request of <b>%s</b>. Please try again.",
'friend:newfriendrequest:subject'=>'%s wants to be your friend',
'friend:lookAtProfile' => "Check out %s's profile"

);


add_translation("en",$english);



?>