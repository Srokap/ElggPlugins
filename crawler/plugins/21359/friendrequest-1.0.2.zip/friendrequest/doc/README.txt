Friend Request Plugin For Elgg
-----------------------------------------

This code is based on the code 'given' to the Elgg community on its Google Group
by a user named 'Franci.'  It's a nice piece of work that allows for 'Facebook-like'
friend requests and confirmations/denials. However, there code was incomplete 
(missing language elements, for one), required editing the core of Elgg, and as far
as I could tell, slightly broken due to it having some functions named the same as core
functions.

Steve's Contributions:  I fixed it.  I completed the language elements (albeit
somewhat informally), fixed the functions for testing for relationships, and changed
the view for profiles to adequately display the options for add/cancel/confirm/deny.  Most
importantly, no edits to the core of Elgg need to be done.

INSTALL:
	* Copy this entire 'friendrequest' folder to the 'mod' folder, enable the 'friendrequest'
		plugin in "Tools Administration," and the rest should be fine.

DEPENDENCIES:
	* Obviously depends on having the friends plugin.
	* Ensure that this module is below friends and profile, and
		everything should be fine.
		
TODOS:
	* I'm a little unsure how the notifications work and how far they can be customized.
	* Right now an email is generated to the people involved, but it would be nice to have
	  'notifications' like on Facebook.  Also, a place to see all pending requests.  
	  
(C) 2008 'Franci', initial code
(C) 2009 Steve Suppe, modifications/improvements
    GPL 2.0
    
CHANGELOG:
10 Jan 2009 : Fixed the 'notify_user' call in startFunctions (line 59) with
				Sharky's updates.

