<?php
global $CONFIG;

require_once 'conf/startFunctions.php';

register_translations($CONFIG->pluginspath . "friendrequest/languages/");

function friendrequest_init() {
	global $CONFIG;
	
	register_action("friends/add",false, $CONFIG->pluginspath . "friendrequest/actions/friend/add.php",false);
	register_action("friends/confirm",false, $CONFIG->pluginspath . "friendrequest/actions/friend/confirm.php",false);
	register_action("friends/refuse",false, $CONFIG->pluginspath . "friendrequest/actions/friend/refuse.php",false);
	register_action("friends/remove",false, $CONFIG->pluginspath . "friendrequest/actions/friend/remove.php",false);
	register_action("friends/cancel",false, $CONFIG->pluginspath . "friendrequest/actions/friend/cancel.php",false);
}

register_elgg_event_handler('init','system','friendrequest_init');

?>