<?php
/**
 * User Expo
 * 
 * @package user Expo
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Brett Profitt
 * @copyright Brett Profitt 2008
 * @link http://eschoolconsultants.com
 */

$english = array(
	'userexpo:order_by' => 'Sort by:',
	'userexpo:recently_updated' => 'Recently Updated',
	'userexpo:last_login' => 'Recently Logged In',
	'userexpo:time_created' => 'Account Creation',
	'userexpo:reverse_order' => 'Reverse',
	'userexpo:display_styles' => 'Display Style',
	'userexpo:view' => 'View',
	'userexpo:users' => 'Users',
	'userexpo:userexpo' => 'User Expo',
	'userexpo:require_login' => 'Require login to browse users.',

	// generic controls.
	'userexpo:pause' => 'Pause',
	'userexpo:resume' => 'Resume',
	'userexpo:close' => 'Close',

	// bounce display style
	'userexpo:start_bounce' => 'Show Bouncing Users',

	// parade display style
	'userexpo:start_parade' => 'Start User Parade',
	
);
					
add_translation("en",$english);

