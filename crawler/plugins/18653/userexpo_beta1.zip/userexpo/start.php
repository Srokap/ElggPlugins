<?php
/**
 * User Expo
 * 
 * @package user Expo
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Brett Profitt
 * @copyright Brett Profitt 2008
 * @link http://eschoolconsultants.com
 */

/**
 * Init.
 */
function userexpo_init() {
  global $CONFIG;
  
	register_translations($CONFIG->pluginspath . "userexpo/languages/");
	
	if (isloggedin()) {
		add_menu(elgg_echo('userexpo:userexpo'), $CONFIG->wwwroot ."pg/expo");
	}
	
	register_page_handler('expo','userexpo_page_handler');
}

/**
 * Redirect to index.php.
 * 
 * @param $page
 * @return unknown_type
 */
function userexpo_page_handler($page) {
	include(dirname(__FILE__) . "/index.php");
	return true;
}

/**
 * Returns support display styles for entities in the form of array(style_path => style_name);
 * 
 * @return array
 */
function userexpo_get_display_styles() {
	global $CONFIG;
	$dir = dirname(__FILE__) . '/views/default/userexpo/display_styles';
	$files = scandir($dir);
	$display_styles = array();
	foreach ($files as $file) {
		if ($file != '.' && $file != '..' && is_file($dir . '/' . $file)) {
			$path = str_replace(dirname(__FILE__) . '/views/default/', '', $dir . '/' . $file);
			$path = str_replace('.php', '', $path);
			$name = ucwords(str_replace('_', ' ', str_replace('.php', '', $file)));
			$display_styles[$path] = $name;
		}
	}

	return $display_styles;
}

register_elgg_event_handler('init','system','userexpo_init');
