<?php
/**
 * User Expo
 * 
 * @package user Expo
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Brett Profitt
 * @copyright Brett Profitt 2008
 * @link http://eschoolconsultants.com
 */

global $CONFIG;
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

if(get_plugin_setting('require_login', 'userexpo')) {
	gatekeeper();
}

$context = get_context();
$offset = get_input('offset', 0);
$only_with_photos = get_input('only_with_photos');
$order_by = get_input('order_by');
$reverse_order_dir = get_input('reverse_order_dir', false);
$limit = get_input('limit', 12);

$display_style = get_input('display_style', 'userexpo/display_styles/gallery');
$entity_type = get_input('entity_type', 'user');
$parent_guid = get_input('parent_guid');

$order_dir_sql = ($reverse_order_dir) ? 'ASC' : 'DESC';

switch($order_by) {
	default:
	case 'recently_updated':
		$order_by_sql = "time_updated $order_dir_sql";
		$entities = get_entities($type='user', $subtype='', $owner_guid=null, $order_by_sql, $limit, $offset);
		$count = get_entities($type='user', $subtype='', $owner_guid=null, $order_by_sql, $limit, $offset, true);
		break;
		
	case 'last_login':
		$order_by_sql = "last_login $order_dir_sql";
		// have to write our own SQL for this one.
		$sql = "SELECT a.guid FROM {$CONFIG->dbprefix}users_entity as a, {$CONFIG->dbprefix}entities as b
			WHERE a.guid = b.guid AND b.enabled = 'yes'
			ORDER BY a.last_login $order_dir_sql";
		$count = count(get_data($sql));
		
		$sql = "SELECT a.guid from {$CONFIG->dbprefix}users_entity as a, {$CONFIG->dbprefix}entities as b
			WHERE a.guid = b.guid and b.enabled = 'yes'
			ORDER BY a.last_login $order_br_sql 
			limit $offset, $limit";
	 	$guids = get_data($sql);
	 	$entities = array();
	 	foreach ($guids as $guid_obj) {
	 		$entities[] = get_entity($guid_obj->guid);
	 	}
		break;
		
	case 'time_created':
		$order_by_sql = "time_created $order_dir_sql";
		$entities = get_entities($type='user', $subtype='', $owner_guid=null, $order_by_sql, $limit, $offset);
		$count = get_entities($type='user', $subtype='', $owner_guid=null, $order_by_sql, $limit, $offset, true);
		break;
}


// filtering form.
$order_by_select_menu = elgg_view('input/pulldown', 
	array(
		'internalname' => 'order_by',
		'value' => $order_by,
		'options_values' => array(
			'recently_updated' => elgg_echo('userexpo:recently_updated'),
			'last_login' => elgg_echo('userexpo:last_login'),
			'time_created' => elgg_echo('userexpo:time_created'),
		)
	)
);

$photo_checkbox = elgg_view('input/checkboxes',
	array(
		'internalname' => 'only_with_photos',
		'value' => $only_with_photos,
		'options' => array(elgg_echo('userexpo:only_with_photos') => 'only_with_photos')
	)
);

$display_styles_select = elgg_view('input/pulldown',
	array(
		'internalname' => 'display_style',
		'value' => $display_style,
		'options_values' => userexpo_get_display_styles()
	)
);

$reverse_order_selected = ($reverse_order_dir) ? 'checked="checked"' : '';

$form_body = elgg_echo('userexpo:order_by') . $order_by_select_menu . "<br />\n";
$form_body .= elgg_echo('userexpo:reverse_order') . "<input type='checkbox' $reverse_order_selected name='reverse_order_dir' value='1' /><br />";
//$form_body .= "<label>" . $photo_checkbox . "</label><br />\n";
$form_body .= elgg_echo('userexpo:display_styles') . $display_styles_select . "<br />\n";
$form_body .= elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('userexpo:view'))); 

// for now, use GET to avoid pagination problems... 
$form = elgg_view('input/form', array('method'=>'get', 'action' => $CONFIG->url . 'pg/expo', 'body' => $form_body));

$title = elgg_view_title(elgg_echo('userexpo:userexpo'));
$body = elgg_view($display_style, 
	array(
		'entities'=>$entities,
		'offset'=>$offset,
		'limit'=>$limit,
		'count'=>$count
	)
);


// Display page
page_draw(
	elgg_echo("memberlist"),
	elgg_view_layout("two_column_left_sidebar", $form, $title . $body)
);