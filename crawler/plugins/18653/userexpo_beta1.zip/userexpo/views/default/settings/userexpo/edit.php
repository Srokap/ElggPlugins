<?php
/**
 * User Expo
 * 
 * @package user Expo
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Brett Profitt
 * @copyright Brett Profitt 2008
 * @link http://eschoolconsultants.com
 */

$require_login_selected = (get_plugin_setting('require_login', 'userexpo')) ? 'checked="checked"' : '';

?>
<p>
	<label><input <?php echo $require_login_selected; ?> type="checkbox" name="params[require_login]" value="1"> <?php echo elgg_echo('userexpo:require_login'); ?></label><br />
</p>