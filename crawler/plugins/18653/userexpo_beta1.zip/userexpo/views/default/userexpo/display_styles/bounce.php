<?php
/**
 * User Expo
 * 
 * @package user Expo
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Brett Profitt
 * @copyright Brett Profitt 2008
 * @link http://eschoolconsultants.com
 */

$entities = $vars['entities'];
$count = $vars['count'];
$offset = $vars['offset'];
$limit = $vars['limit'];
$context = get_context();

$pagination .= elgg_view('navigation/pagination', array(
	'baseurl' => $_SERVER['REQUEST_URI'],
	'offset' => $offset,
	'count' => $count,
	'limit' => $limit)
);

echo $pagination;

?>

<div id="userexpo_bounce_canvas" style="opacity: 0;">
<?php
foreach ($entities as $entity) {
	$icon = elgg_view("profile/icon", array(
		'entity' => $entity,
		'size' => 'medium')
	);
	
	$rel = "";
	if (page_owner() == $entity->getGUID())
		$rel = 'me';
	else if (check_entity_relationship(page_owner(), 'friend', $entity->getGUID()))
		$rel = 'friend';
		
	$info = "<p><b><a href=\"" . $entity->getUrl() . "\" rel=\"$rel\">" . $entity->name . "</a></b></p>";
	
	echo '<div class="userexpo_bounce_entity" style="display: none;">';
	echo "<div class='userexpo_bounce_icon'>$icon</div>";
	echo "<div class='userexpo_bounce_info'>$info</div>";
	echo '</div>';
	//break;
}
echo '</div>';

?>
<input type="button" onClick="startBounce();" value="<?php echo elgg_echo('userexpo:start_bounce'); ?>" />


<!-- Set up dimming overlay and the bounce canvas-->
<div id="userexpo_bounce_overlay" style="opacity: 0;">
<input id="haltBounceButton" type="button" onClick="haltBounce();" value="<?php echo elgg_echo('userexpo:pause'); ?>" />
<input id="resumeBounceButton" style="display: none;" type="button" onClick="resumeBounce();" value="<?php echo elgg_echo('userexpo:resume'); ?>" />
<input type="button" onClick="closeBounce();" value="<?php echo elgg_echo('userexpo:close'); ?>" />
</div>

<script language="javascript">

entities = $('div.userexpo_bounce_entity');
canvas = $('div#userexpo_bounce_canvas');
overlay = $('div#userexpo_bounce_overlay');

bouncerEntities = new Array();

bounceIntervalID = null;

function rand(lower, upper) {
	return Math.floor((Math.random() * (upper-lower+1))+lower);
}

function bouncer(object, startX, startY, speed, container) {
	var thisObject = this;	// workaround for setInterval scope problems
	this.object = $(object);
	this.container = $(container);
	this.startX = startX;
	this.startY = startY;
	this.speed = speed;		// time in ms to get to far side of container from starting position.

	
	this.intervalID = null;
	this.intervalFreq = 50;
	this.stepX = 0;
	this.stepY = 0;
	this.maxFrames = Math.floor(this.speed / this.intervalFreq);
	
	this.curX = startX;
	this.curY = startY;
	
	this.init = function() {
		this.object.css('position', 'absolute');
		this.object.css('top', this.startY + 'px');
		this.object.css('left', this.startX + 'px');
		this.object.css('display', 'inline');
		this.object.css('z-index', 100);

		distY = Math.abs(this.curY - this.container.height() + this.object.height());
		distX = Math.abs(this.curX - this.container.width() + this.object.width());
		
		this.stepX = Math.floor(distX/this.maxFrames);
		this.stepY = Math.floor(distY/this.maxFrames);

		// keep things interesting..
		if (this.stepY == 0) {
			this.stepY = rand(1,5);
		}
		if (this.stepX == 0) {
			this.stepX = rand(1,5);
		}
	}

	this.stop = function() {
		window.clearInterval(this.intervalID);
	}

	this.step = function() {
		if (this.curX + this.object.width() > this.container.width()) {
			this.stepX = (this.stepX > 0) ? 0 - this.stepX : Math.abs(this.stepX);
		}

		if (this.curX <= 0) {
			this.stepX = Math.abs(this.stepX); 
		}

		if (this.curY + this.object.height() > this.container.height()) {
			this.stepY = (this.stepY > 0) ? 0 - this.stepY : Math.abs(this.stepY);
		}

		if (this.curY <= 0) {
			this.stepY = Math.abs(this.stepY);
		}

		this.curY = this.curY + this.stepY;
		this.curX = this.curX + this.stepX;
		this.object.css('top', this.curY + 'px');
		this.object.css('left', this.curX + 'px');
	}

	this.start = function() {
		// this is hacky...I don't know if it's the best way to do this.
		this.intervalID = window.setInterval(
			function(e) { thisObject.step() },
			this.intervalFreq
		);
	}

	this.restart = function(endX, endY, speed) {
		this.reset();
		this.speed = speed;
		this.start();
	}

	this.reset = function() {
		this.curFrame = 0;
		this.curX = this.startX;
		this.curY = this.startY;
		this.setSteps();
	}
}

function startBounce() {
	//@todo have a nice fade out with ~25 pixel margins...
	canvas.width($('body').width()-100);
	canvas.height($('body').height()-100);
	canvas.css('position', 'absolute');
	canvas.css('top', 50);
	canvas.css('left', 50);
	//canvas.css('background-color', '#ffffff');
	canvas.css('z-index', 100);
	canvas.fadeTo('slow', 1);

	overlay.width($('body').width());
	overlay.height($('body').height());
	overlay.css('position', 'absolute');
	overlay.css('top', 0);
	overlay.css('left', 0);
	overlay.css('background-color', '#000000');
	overlay.css('z-index', 90);
	overlay.fadeTo('slow', 0.50);
	
	for (i=0; i<entities.length; i++) {
		entity = $(entities[i]);

		initBouncerEntity(entity);
	}
}

function initBouncerEntity(entity) {
	// make sure it fits in the container.
	startX = rand(canvas.offset().left, canvas.width());
	if (entity.width() + startX > canvas.width()) {
		startX = canvas.width() - entity.width();
	}

	startY = 0 - entity.height() - rand(0,1000);

	endX = rand(canvas.offset().left, canvas.width());
	endY = canvas.height() + entity.height();

	speed = rand(3000,10000);

	bouncerEntity = new bouncer(entity, startX, startY, speed, canvas);
	bouncerEntity.init();
	bouncerEntity.start();
	bouncerEntities.push(bouncerEntity);
}

function haltBounce() {
	for (i=0; i<bouncerEntities.length; i++) {
		bouncerEntities[i].stop();
	}
	$('#haltBounceButton').css('display', 'none');
	$('#resumeBounceButton').css('display', 'inline');
}

function resumeBounce() {
	for (i=0; i<bouncerEntities.length; i++) {
		bouncerEntities[i].start();
	}
	$('#haltBounceButton').css('display', 'inline');
	$('#resumeBounceButton').css('display', 'none');
}

function closeBounce() {
	haltBounce();
	canvas = $('div#userexpo_bounce_canvas');
	overlay = $('div#userexpo_bounce_overlay');

	//@todo odd resizing stuff.
	canvas.fadeTo('slow', 0);
	canvas.width(0);
	canvas.height(0);
	
	overlay.fadeTo('slow', 0);
	overlay.width(0);
	overlay.height(0);
}

</script>