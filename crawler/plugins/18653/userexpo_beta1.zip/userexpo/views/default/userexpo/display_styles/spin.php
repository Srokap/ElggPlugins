<?php

$entities = $vars['entities'];
$count = $vars['count'];
$offset = $vars['offset'];
$limit = $vars['limit'];
$context = get_context();

$pagination .= elgg_view('navigation/pagination', array(
	'baseurl' => $_SERVER['REQUEST_URI'],
	'offset' => $offset,
	'count' => $count,
	'limit' => $limit)
);

echo $pagination;

//echo '<div class="userexpo_entities" style="border: 3px solid green;">';

foreach ($entities as $entity) {
	$icon = elgg_view("profile/icon", array(
		'entity' => $entity,
		'size' => 'medium')
	);
	
	$rel = "";
	if (page_owner() == $entity->getGUID())
		$rel = 'me';
	else if (check_entity_relationship(page_owner(), 'friend', $entity->getGUID()))
		$rel = 'friend';
		
	$info = "<p><b><a href=\"" . $entity->getUrl() . "\" rel=\"$rel\">" . $entity->name . "</a></b></p>";
	
	echo '<div class="userexpo_spin_entity" style="display: none;">';
	echo "<div class='userexpo_spin_icon'>$icon</div>";
	echo "<div class='userexpo_spin_info'>$info</div>";
	echo '</div>';		
}
//echo '</div>';

?>
<input type="button" onClick="startSpin();" value="<?php echo elgg_echo('userexpo:start_spin'); ?>" />


<!-- Set up dimming overlay and the spin canvas-->
<div id="userexpo_spin_overlay" style="opacity: 0;"></div>
<div id="userexpo_spin_canvas" style="opacity: 0;">
<input type="button" onClick="closeSpin();" value="<?php echo elgg_echo('userexpo:close_spin'); ?>" />
</div>

<script language="javascript">

function rand(lower, upper) {
	return Math.floor((Math.random() * (upper-lower+1))+lower);
}

function marcher(object, startX, startY, endX, endY, speed, swagger) {
	this.object = $(object);
	this.startX = startX;
	this.startY = startY;
	this.endX = endX;
	this.endY = endY;
	this.speed = speed;
	this.swagger = swagger;
	
	this.init = function() {
		console.log(this.object);
		this.object.css('position', 'absolute');
		this.object.css('top', this.startY - this.object.height());
		this.object.css('left', this.startX);
		this.object.css('border', '3px solid red');
	}

	this.stop = function() {
		console.log('Stopping!');
	}

	this.start = function() {

	}

	this.step = function() {

	}

	this.drag = function() {

	}
}

function startSpin() {
	entities = $('div.userexpo_spin_entity');
	canvas = $('div#userexpo_spin_canvas');
	overlay = $('div#userexpo_spin_overlay');

	//@todo have a nice fade out with ~25 pixel margins...
	canvas.width($('body').width());
	canvas.height($('body').height());
	canvas.css('position', 'absolute');
	canvas.css('top', 0);
	canvas.css('left', 0);
	//canvas.css('background-color', '#ffffff');
	canvas.css('z-index', 100);
	canvas.fadeTo('slow', 1);

	overlay.width($('body').width());
	overlay.height($('body').height());
	overlay.css('position', 'absolute');
	overlay.css('top', 0);
	overlay.css('left', 0);
	overlay.css('background-color', '#000000');
	overlay.css('z-index', 90);
	overlay.fadeTo('slow', 0.50);
	
	console.log('Canvas: ' + canvas.width() + 'x' + canvas.height());

	offset = canvas.offset();
	width = canvas.width();
	height = canvas.height();
	
	console.log('Canvas is: ' + offset.left + ',' + width);
	
	for (i=0; i<entities.length; i++) {
		startX = rand(offset.left, offset.left+width);
		startY = offset.top;
		//console.log('Start is: ' + startX + ',' + startY);
		entityMarcher = new marcher(entities[i], startX, startY, 0, 0, 0, 0);
		entityMarcher.init();
	}
}

function closeSpin() {
	canvas = $('div#userexpo_spin_canvas');
	overlay = $('div#userexpo_spin_overlay');

	//@todo odd resizing stuff.
	canvas.fadeTo('slow', 0);
	canvas.width(0);
	canvas.height(0);
	
	overlay.fadeTo('slow', 0);
	overlay.width(0);
	overlay.height(0);
}

</script>