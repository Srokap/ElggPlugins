<?php
/**
 * User Expo
 * 
 * @package user Expo
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Brett Profitt
 * @copyright Brett Profitt 2008
 * @link http://eschoolconsultants.com
 */

$entities = $vars['entities'];
$count = $vars['count'];
$offset = $vars['offset'];
$limit = $vars['limit'];
$effect = $vars['effect'];
$context = get_context();
			
echo elgg_view('search/entity_list',array(
	'entities' => $entities,
	'count' => $count,
	'offset' => $offset,
	'limit' => $limit,
	'baseurl' => $_SERVER['REQUEST_URI'],
	'fullview' => true,
	'context' => $context, 
	'viewtypetoggle' => false,
	'viewtype' => 'list', 
	'pagination' => true
));

?>