<?php
/**
 * User Expo
 * 
 * @package user Expo
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Brett Profitt
 * @copyright Brett Profitt 2008
 * @link http://eschoolconsultants.com
 */

$entities = $vars['entities'];
$count = $vars['count'];
$offset = $vars['offset'];
$limit = $vars['limit'];
$context = get_context();

$pagination .= elgg_view('navigation/pagination', array(
	'baseurl' => $_SERVER['REQUEST_URI'],
	'offset' => $offset,
	'count' => $count,
	'limit' => $limit)
);

echo $pagination;

echo '<table class="userexpo_gallery">';
$col = 0;
foreach ($entities as $entity) {
	$icon = elgg_view("profile/icon", array(
		'entity' => $entity,
		'size' => 'medium')
	);
	
	$rel = "";
	if (page_owner() == $entity->getGUID())
		$rel = 'me';
	else if (check_entity_relationship(page_owner(), 'friend', $entity->getGUID()))
		$rel = 'friend';
		
	$info = "<p><b><a href=\"" . $entity->getUrl() . "\" rel=\"$rel\">" . $entity->name . "</a></b></p>";
	
	if ($col == 0) {
		echo "<tr>";
	}
	echo "<td class=\"search_gallery_item\">";
	echo '<div class="search_listing">';
	echo "<div class='userexpo_listing_icon'>$icon</div>";
	echo "<div class='search_listing_info'>$info</div>";
	echo '</div>';
	echo "</td>";
	$col++;
	if ($col > 3) {
		echo "</tr>";
		$col = 0;
	}					
}

if ($col > 0) echo "</tr>";

echo '</table>';
echo $pagination;
