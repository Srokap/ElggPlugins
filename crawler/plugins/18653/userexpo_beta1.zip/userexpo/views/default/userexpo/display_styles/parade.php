<?php
/**
 * User Expo
 * 
 * @package user Expo
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Brett Profitt
 * @copyright Brett Profitt 2008
 * @link http://eschoolconsultants.com
 */

$entities = $vars['entities'];
$count = $vars['count'];
$offset = $vars['offset'];
$limit = $vars['limit'];
$context = get_context();

$pagination .= elgg_view('navigation/pagination', array(
	'baseurl' => $_SERVER['REQUEST_URI'],
	'offset' => $offset,
	'count' => $count,
	'limit' => $limit)
);

echo $pagination;

//echo '<div class="userexpo_entities" style="border: 3px solid green;">';
?>
<div id="userexpo_parade_canvas" style="opacity: 0;">

<?php
foreach ($entities as $entity) {
	$icon = elgg_view("profile/icon", array(
		'entity' => $entity,
		'size' => 'medium')
	);
	
	$rel = "";
	if (page_owner() == $entity->getGUID())
		$rel = 'me';
	else if (check_entity_relationship(page_owner(), 'friend', $entity->getGUID()))
		$rel = 'friend';
		
	$info = "<p><b><a href=\"" . $entity->getUrl() . "\" rel=\"$rel\">" . $entity->name . "</a></b></p>";
	
	echo '<div class="userexpo_parade_entity" style="display: none;">';
	echo "<div class='userexpo_parade_icon'>$icon</div>";
	echo "<div class='userexpo_parade_info'>$info</div>";
	echo '</div>';
	//break;
}
echo '</div>';

?>
<input type="button" onClick="startParade();" value="<?php echo elgg_echo('userexpo:start_parade'); ?>" />


<!-- Set up dimming overlay and the parade canvas-->
<div id="userexpo_parade_overlay" style="opacity: 0;">
<input id="haltParadeButton" type="button" onClick="haltParade();" value="<?php echo elgg_echo('userexpo:pause'); ?>" />
<input id="resumeParadeButton" style="display: none;" type="button" onClick="resumeParade();" value="<?php echo elgg_echo('userexpo:resume'); ?>" />
<input type="button" onClick="closeParade();" value="<?php echo elgg_echo('userexpo:close'); ?>" />
</div>

<script language="javascript">

entities = $('div.userexpo_parade_entity');
canvas = $('div#userexpo_parade_canvas');
overlay = $('div#userexpo_parade_overlay');

marcherEntities = new Array();

paradeIntervalID = null;

function rand(lower, upper) {
	return Math.floor((Math.random() * (upper-lower+1))+lower);
}

function marcher(object, startX, startY, endX, endY, speed, swagger, container, callback) {
	var thisObject = this;	// workaround for setInterval scope problems
	this.object = $(object);
	this.container = $(container);
	this.startX = startX;
	this.startY = startY;
	this.endX = endX;
	this.endY = endY;
	this.speed = speed;		// time in ms to get to destination.
	this.swagger = swagger;
	this.callback = callback;	// callback function once a marcher has reached the end. takes thisObject as arg.

	this.intervalID = null;
	this.intervalFreq = 50;
	this.stepX = 0;
	this.stepY = 0;
	this.distX = 0;
	this.distY = 0;
	
	this.curX = startX;
	this.curY = startY;
	this.curFrame = 0;	// current frame number
	this.maxFrames = 0;  // max frame numbers
	
	this.init = function() {
		this.object.css('position', 'absolute');
		this.object.css('top', this.startY + 'px');
		this.object.css('left', this.startX + 'px');
		this.object.css('display', 'inline');
		this.object.css('z-index', 100);

		this.maxFrames = Math.floor(this.speed / this.intervalFreq);
		this.setSteps();
	}

	this.setSteps = function() {
		distY = Math.abs(this.curY - this.endY);
		distX = Math.abs(this.curX - this.endX);
		this.stepX = Math.floor(distX/this.maxFrames - this.curFrame);
		this.stepY = Math.floor(distY/this.maxFrames - this.curFrame);
		if (this.curY > this.endY) {
			this.stepY = 0 - this.stepY;
		}
		if (this.curX > this.endX) {
			this.stepX = 0 - this.stepX;
		}
	}

	this.stop = function() {
		window.clearInterval(this.intervalID);
	}

	this.step = function() {
		/*
		figure out the distance between the two point sets.
		divide the speed by 50 (setInterval) to get how many animation frames we have.
		divide the distance by the frames to see how far we need to move on each frame.
		Increment x (left) and y (top) for object.
		*/
		// check for swagger, call it if so.  else, normal stepping.
		// swagger function will look like a step function, but will alter the x and y steps.
		// will then need to re-evaluate the X and Y steps.
		
		if (this.curX + this.object.width() > this.container.width()) {
			this.stepX = (this.stepX > 0) ? 0 - this.stepX : this.stepX - 0;
		}
		
		if (this.curFrame > this.maxFrames) {
			this.stop();
			if (this.callback) {
				callback(thisObject);
			}
		}
		this.curY = this.curY + this.stepY;
		this.curX = this.curX + this.stepX;
		this.object.css('top', this.curY + 'px');
		this.object.css('left', this.curX + 'px');
		this.curFrame++;
	}

	this.start = function() {
		this.intervalID = window.setInterval(
			function(e) { thisObject.step() },
			this.intervalFreq
		);
	}

	this.drag = function() {

	}

	this.restart = function(endX, endY, speed, swagger) {
		this.reset();
		this.endX = endX;
		this.endY = endY;
		this.speed = speed;
		this.swagger = swagger;
		this.start();
	}

	this.reset = function() {
		this.curFrame = 0;
		this.curX = this.startX;
		this.curY = this.startY;
		this.setSteps();
	}
}

function startParade() {
	//@todo have a nice fade out with ~25 pixel margins...
	canvas.width($('body').width()-100);
	canvas.height($('body').height()-100);
	canvas.css('position', 'absolute');
	canvas.css('top', 50);
	canvas.css('left', 50);
	//canvas.css('background-color', '#ffffff');
	canvas.css('z-index', 100);
	canvas.fadeTo('slow', 1);

	overlay.width($('body').width());
	overlay.height($('body').height());
	overlay.css('position', 'absolute');
	overlay.css('top', 0);
	overlay.css('left', 0);
	overlay.css('background-color', '#000000');
	overlay.css('z-index', 90);
	overlay.fadeTo('slow', 0.50);
//
//	console.log('Body:' + $('body').width() + 'x' + $('body').height());
//	console.log('Canvas: ' + canvas.width() + 'x' + canvas.height());
//	console.log('Canvas is: ' + canvas.offset().left + ',' + canvas.width());
	
	for (i=0; i<entities.length; i++) {
		entity = $(entities[i]);

		initMarcherEntity(entity);
	}

	//paradeIntervalID = setInterval('stepParade()', 50);
}

function initMarcherEntity(entity) {
	// make sure it fits in the container.
	startX = rand(canvas.offset().left, canvas.width());
	if (entity.width() + startX > canvas.width()) {
		startX = canvas.width() - entity.width();
	}
	
	// put it somewhere above the canvas.  Randomly subtract so they don't all come out at once.
	//startY = canvas.offset().top - entity.height();
	// absolute is still relative to the containing div.
	startY = 0 - entity.height() - rand(0,1000);
//	
//	console.log('Entity height is ' + entity.height());
//	console.log('canvas offset is ' + canvas.offset().top);
//	console.log('Start is: ' + startX + ',' + startY);

	// straight line down for now.
	endX = rand(canvas.offset().left, canvas.width());
	endY = canvas.height() + entity.height();

	// takes between 3 and 15 seconds to get from top to bottom.
	speed = rand(3000,15000);

	// todo this will make a huge array.  fix that.
	//marcherEntity = new marcher(entities[i], startX, startY, endX, endY, speed, 0, canvas, function(e){e.restart()});
	marcherEntity = new marcher(entity, startX, startY, endX, endY, speed, 0, canvas, function(e){initMarcherEntity(e.object);});
	marcherEntity.init();
	marcherEntity.start();
	marcherEntities.push(marcherEntity);
}


function haltParade() {
	for (i=0; i<marcherEntities.length; i++) {
		marcherEntities[i].stop();
	}
	$('#haltParadeButton').css('display', 'none');
	$('#resumeParadeButton').css('display', 'inline');
}

function resumeParade() {
	for (i=0; i<marcherEntities.length; i++) {
		marcherEntities[i].start();
	}
	$('#haltParadeButton').css('display', 'inline');
	$('#resumeParadeButton').css('display', 'none');
}

function closeParade() {
	haltParade();
	canvas = $('div#userexpo_parade_canvas');
	overlay = $('div#userexpo_parade_overlay');

	//@todo odd resizing stuff.
	canvas.fadeTo('slow', 0);
	canvas.width(0);
	canvas.height(0);
	
	overlay.fadeTo('slow', 0);
	overlay.width(0);
	overlay.height(0);
}

</script>