<?php
/**
 * User Expo
 * 
 * @package user Expo
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Brett Profitt
 * @copyright Brett Profitt 2008
 * @link http://eschoolconsultants.com
 */

$entities = $vars['entities'];
$count = $vars['count'];
$offset = $vars['offset'];
$limit = $vars['limit'];
$context = get_context();

$pagination .= elgg_view('navigation/pagination', array(
	'baseurl' => $_SERVER['REQUEST_URI'],
	'offset' => $offset,
	'count' => $count,
	'limit' => $limit)
);

echo $pagination;
echo '<div class="userexpo_canvas">';

foreach ($entities as $entity) {
	$icon = elgg_view("profile/icon", array(
		'entity' => $entity,
		'size' => 'medium')
	);
	
	$rel = "";
	if (page_owner() == $entity->getGUID())
		$rel = 'me';
	else if (check_entity_relationship(page_owner(), 'friend', $entity->getGUID()))
		$rel = 'friend';
		
	$info = "<p><b><a href=\"" . $entity->getUrl() . "\" rel=\"$rel\">" . $entity->name . "</a></b></p>";
	
	echo '<div class="userexpo_swirl_entity">';
	echo "<div class='userexpo_swirl_icon'>$icon</div>";
	echo "<div class='userexpo_swirl_info'>$info</div>";
	echo '</div>';		
}
echo '</div>';

?>
<script language="javascript">

entities = $('div.userexpo_swirl_entity');
canvas = $('userexpo_canvas');

r = 0;

x1 = 0.1;
y1 = 0.5;

x2 = 0.25;
y2 = 0.24;

x3 = 1.6;
y3 = 0.24;

x4 = 300;
y4 = 200;

x5 = 300;
y5 = 200;

length = entities.length;

function swirl() {
	for (i=0; i-length; i++) {
		style = entities[i].style;
		style.position = 'absolute';
		style.left = (Math.sin(r*x1 + i*x2 + x3)*x4 + x5) + 'px';
		style.top = (Math.cos(r*y1 + i*y2 + y3)*y4 + y5) + 'px';
	}
	r++;
}

setInterval('swirl()', 75);

</script>