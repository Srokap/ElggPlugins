<?php

// Mit dem translation browser generiert 

$german = array( 
	 'dokuwiki:wiki'  =>  "Wiki" , 
	 'dokuwiki:groupwiki'  =>  "GruppenWiki" , 
	 'dokuwiki:userwiki'  =>  "Mein Wiki" , 
	 'dokuwiki'  =>  "Wikis" , 
	 'item:object:dokuwiki'  =>  "Wikis" , 
	 'dokuwiki:title'  =>  "Wikis" , 
	 'dokuwiki:wikifrom'  =>  "Wiki von %s" , 
	 'dokuwiki:pages'  =>  "Seiten von %s" , 
	 'dokuwiki:dokuwiki'  =>  "Wiki" , 
	 'groups:enabledokuwiki'  =>  "GruppenWiki einrichten" , 
	 'dokuwiki:river:modified'  =>  "%s hat die Seite %s im %s bearbeitet"
); 

add_translation('de', $german); 

?>