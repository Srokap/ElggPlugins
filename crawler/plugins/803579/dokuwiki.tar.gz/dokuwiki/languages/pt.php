<?php

// Gerado pelo browser de tradução. 

$portuguese = array( 
	 'dokuwiki:wiki'  =>  "Wiki" , 
	 'dokuwiki:title'  =>  "Wikis" , 
	 'dokuwiki:wikifrom'  =>  "%s Wiki" , 
	 'dokuwiki:pages'  =>  "%s páginas" , 
	 'dokuwiki:dokuwiki'  =>  "Wiki" , 
	 'dokuwiki:groupwiki'  =>  "Wiki" , 
	 'dokuwiki:userwiki'  =>  "Minha Wiki" , 
	 'groups:enabledokuwiki'  =>  "Habilitar Wiki do grupo" , 
	 'dokuwiki'  =>  "Wikis" , 
	 'dokuwiki:river:modified'  =>  "%s modificou a página %s em %s" , 
	 'item:object:dokuwiki'  =>  "Wikis" , 
	 'groups:enabledokuwiki_frontpage'  =>  "Mostrar a página wiki principal na página principal do grupo (só se a wiki estiver habilitada)" , 
	 'groups:enabledokuwiki_frontsidebar'  =>  "Mostrar a barra lateral de wiki na página principal do grupo (só se a wiki estiver habilitada)"
); 

add_translation('pt', $portuguese); 

?>
