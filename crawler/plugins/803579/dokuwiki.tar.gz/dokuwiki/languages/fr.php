<?php

// Generate By translationbrowser. 

$french = array( 
	 'dokuwiki:userwiki'  =>  "Mon wiki" , 
	 'groups:enabledokuwiki'  =>  "Habiliter le wiki groupe"
); 

add_translation('fr', $french); 

?>