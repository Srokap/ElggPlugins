<?php

// Xerado por translationbrowser 

$galician = array( 
	 'dokuwiki:wiki'  =>  "Wiki" , 
	 'dokuwiki:groupwiki'  =>  "Wiki do grupo" , 
	 'dokuwiki:userwiki'  =>  "A miña Wiki" , 
	 'dokuwiki'  =>  "Wikis" , 
	 'item:object:dokuwiki'  =>  "Wikis" , 
	 'dokuwiki:title'  =>  "Wikis" , 
	 'dokuwiki:wikifrom'  =>  "%s wiki" , 
	 'dokuwiki:pages'  =>  "%s páxinas" , 
	 'dokuwiki:dokuwiki'  =>  "Wiki" , 
	 'groups:enabledokuwiki'  =>  "Habilitar wiki do grupo" , 
	 'dokuwiki:river:modified'  =>  "%s modificou a páxina %s en %s" , 
	 'groups:enabledokuwiki_frontpage'  =>  "Amosa la wiki na portada do grupo" , 
	 'groups:enabledokuwiki_frontsidebar'  =>  "Amosa la barra da wiki na portada do grupo"
); 

add_translation('gl', $galician); 

?>