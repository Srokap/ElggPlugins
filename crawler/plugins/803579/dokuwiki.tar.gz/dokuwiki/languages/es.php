<?php
/**
         * Elgg spotlight lorea
         * 
         * @package
         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author lorea
         * @copyright lorea
         * @link http://lorea.cc
         */

	$spanish = array(
                "dokuwiki:wiki"=>'Wiki',
                "dokuwiki:group"=>'Wiki del grupo',
                "dokuwiki:userwiki"=>'Mi Wiki',
                "dokuwiki"=>'Wikis',
                "item:object:dokuwiki"=>'Wikis',
                "dokuwiki:title"=>'Wikis',
                "dokuwiki:wikifrom"=>'%s wiki',
                "dokuwiki:pages"=>'%s p&aacute;ginas',
                "dokuwiki:dokuwiki"=>'Wiki',
		"groups:enabledokuwiki_frontsidebar"=>'Mostrar el arbol del wiki en la página principal del grupo (solo si el wiki está activado para el grupo)',
		"groups:enabledokuwiki_frontpage"=>'Mostrar la página principal del wiki en la página principal el grupo (solo si el wiki está activado para el grupo)',
                "groups:enabledokuwiki"=>'Habilitar wiki del grupo',
                "dokuwiki:river:modified"=>'%s ha modificado la p&aacute;gina %s en %s',



	);
	
	add_translation("es",$spanish);

?>
