<?php
if (elgg_get_context() == "dokuwiki") {
	tpl_metaheaders();
}
?>
