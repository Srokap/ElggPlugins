div.dokuwiki input {
	width: auto;
}

div.dokuwiki .header {
    margin-bottom: 10px;
}

#sidebartop {
	position: relative !important;
	display: none;
}
