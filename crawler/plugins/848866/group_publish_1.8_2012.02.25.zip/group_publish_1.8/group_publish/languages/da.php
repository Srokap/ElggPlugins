<?php

$danish = array(

	'admin:group_module' 				=> 'Group Publish',
	'admin:group_module:settings'		=> 'General Settings',
	'admin:group_module:unpublished'	=> 'Unpublished Groups',
	
	'group_publish:admininfo'			=> 'Denne gruppe er endnu ikke offentliggjort af ejeren. Gruppen blev oprettet ',
	'group_publish:info' 				=> 'Information',
	'group_publish:failure'				=> 'Gruppen kunne ikke offentliggøres',
	'group_publish:infocreate'  		=> 'Velkommen til oprettelse af grupper. Når du har udfyldt formularen herunder med dine informationer, klikker du Gem.<p>Gruppen vil så blive oprettet, men vil ikke være synlig for andre end dig selv. Når du senere har tjekket om opsætningen passer dig, kan du vælge at offentliggøre gruppen.</p>',
	'group_publish:none' 				=> 'Ingen grupper fundet',
	'group_publish:notpublished' 		=> 'Du har nu oprettet din gruppe.<p>I øjeblikket er gruppen kun synlig for dig. Når du er tilfreds med din opsætning - billede, beskrivelse og andre oplysninger, skal du klikke på Udgiv for at gøre gruppen synlig for andre.</p><p>Bemærk: du kan <b>ikke</b> fortryde, når du først har valgt at offentliggøre gruppen, men selvfølgelig kan du altid redigere din gruppes indhold og opsætning.</p>',
	'group_publish:param:label'			=> 'Vis info boksen herunder på siden "Opret en ny gruppe".',
	'group_publish:publish' 			=> 'Offentliggør',
	'group_publish:settings:save:ok'	=> 'Indstillinger for Group Publish er gemt',
	'group_publish:success'				=> 'Din gruppe er nu synlig for andre brugere',
	
);

add_translation("da",$danish);

?>