<?php

$english = array(

	'admin:group_module' 				=> 'Group Publish',
	'admin:group_module:settings'		=> 'General Settings',
	'admin:group_module:unpublished'	=> 'Unpublished Groups',
			
	'group_publish:admininfo'			=> 'This group is not yet published by the owner. The group was created ',
	'group_publish:info'				=> 'Information',
	'group_publish:failure'				=> 'The group could not be published',
	'group_publish:infocreate'  		=> 'Welcome to create group. Once you have filled out the form below with your information, click Save.<p>The group will then be created, but will not be visible to anyone but you. Later, when you have checked the setup, you can choose to publish your group.</p>',
	'group_publish:none' 				=> 'No unpublished groups found',
	'group_publish:notpublished'		=> 'You\'ve created your group.<p>Currently the group is only visible to you. When you\'re happy with your setup - picture, description and other information, click Publish to make the group visible to others.</p><p>Note: <b>you can not undo</b> once you have chosen to publish the group, but of course you can always edit your group\'s content and configuration.</p>',
	'group_publish:param:label'			=> 'Show the info box below on page "Create a new group".',
	'group_publish:publish' 			=> 'Publish',
	'group_publish:settings:save:ok'	=> 'Group Publish settings saved',
	'group_publish:success'				=> 'Your group is now visible to other users',
			
);

add_translation("en", $english);
