<?php
 
$group = $vars['entity'];
$accepted = ($group->accepted != "no");

$friendlytime = elgg_view_friendly_time($group->time_created);

$publish_url = "action/group_publish/publish?group_guid=" . $group->getGUID();

$publish_button = elgg_view("output/url", array(
	"href" => $publish_url,
	"text" => elgg_echo("group_publish:publish"),
	"is_action" => true
));

$delete_url = 'action/groups/delete?guid=' . $group->getGUID();
$delete_button = elgg_view('output/confirmlink', array(
	'text' => elgg_echo('groups:delete'),
	'href' => $delete_url,
	'confirm' => elgg_echo('groups:deletewarning'),
));
			
if (elgg_is_admin_logged_in() && !$accepted){ 

	$title = elgg_echo("group_publish:info");	
	$content = '<ul>';
	$content .= "<li>" . elgg_echo('group_publish:admininfo') . $friendlytime . "</li>";
	$content .= "<li>" . $publish_button;
	$content .= $delete_button . "</li>";
	$content .= '</ul>';
	
	echo elgg_view_module('status', $title, $content);

} else if (!$accepted){ 

	$title = elgg_echo("group_publish:info");
	$content = '<ul>';
	$content .= "<li>" . elgg_echo('group_publish:notpublished') . "</li>";
	$content .= "<li>" . $publish_button;
	$content .= $delete_button . "</li>";
	$content .= '</ul>';
	
	echo elgg_view_module('status', $title, $content);

}

?>
