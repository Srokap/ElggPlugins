<?php

$plugin = elgg_get_plugin_from_id('group_publish');

// Info setting
$newgroup_info = $plugin->newgroup_info;
if (!$newgroup_info) $newgroup_info = "enabled";

$form_body .= '<p class="edit">' . elgg_view("input/checkboxes", array('options' => array(elgg_echo('group_publish:param:label') => 'enabled'), 'name' => 'newgroup_info', 'value' => $newgroup_info )) . "</p>";

$form_body .= '<div>';
$form_body .= elgg_view('page/elements/create');
$form_body .= '</div>';

$form_body .= elgg_view('input/submit', array('value' => elgg_echo("save")));
echo elgg_view('input/form', array('action' => $action, 'body' => $form_body));

?>