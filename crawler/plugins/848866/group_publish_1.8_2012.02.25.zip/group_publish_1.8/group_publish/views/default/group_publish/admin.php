<?php
/**
 * group_publish Admin CSS
 *
 */

?>

/* ***************************************
	MODULE
*****************************************/
.elgg-module-status {
	background: #EAF0F6;
	border: #C4D5E6 1px solid;
    padding: 10px;
    width: 680px;
}
.elgg-module-status li a{
    margin-right: 10px;
    padding-left: 0;
}
.elgg-module-status li:last-child{
    margin-top: 8px;
}
.elgg-module-status h3{
	padding-bottom: 5px;
    margin-bottom: 5px;
	border-bottom: #C4D5E6 1px solid;
}