<?php
		
admin_gatekeeper();
elgg_set_context('admin');

$content = elgg_list_entities_from_metadata(array(
	'type' => 'group',
	'metadata_name' => 'notpublished',
	'limit' => 10,
	'list_type_toggle' => FALSE, 
	'pagination' => TRUE,
	'full_view' => FALSE,
));

if (!$content) {
	$content = elgg_echo('group_publish:none');
}

echo $content;
		
?>