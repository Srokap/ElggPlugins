<?php

$group = $vars['entity'];
$accepted = $group->accepted;

if (!$accepted){

	$title = elgg_echo('group_publish:info');
	$content = elgg_echo('group_publish:infocreate');
	
	echo elgg_view_module('status', $title, $content);
			
}

?>
