<?php

echo elgg_view_form('group_publish/settings');

?>