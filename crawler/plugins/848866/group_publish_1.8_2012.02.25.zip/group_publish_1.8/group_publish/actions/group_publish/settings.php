<?php

global $CONFIG;
	
admin_gatekeeper();
action_gatekeeper();

// Params array - settings
$params = get_input('params');
$result = false;
foreach ($params as $k => $v) {
	if (!elgg_set_plugin_setting($k, $v, 'group_publish')) {
		register_error(sprintf(elgg_echo('plugins:settings:save:fail'), 'group_publish'));
		forward(REFERER);
	}
}
// Info setting
if (is_array(get_input('newgroup_info'))) {
	elgg_set_plugin_setting('newgroup_info', 'enabled', 'group_publish');
} else {
	elgg_set_plugin_setting('newgroup_info', 'disabled', 'group_publish');
}

system_message(elgg_echo('group_publish:settings:save:ok'));
forward(REFERER);