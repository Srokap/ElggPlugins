<?php

global $CONFIG;

$group_guid = get_input('group_guid');
$group = get_entity($group_guid);

$group->accepted = 'yes';
$group->access_id = ACCESS_PUBLIC;
$group->save();

if ($error) {
	register_error(elgg_echo('group_publish:failure'));
	forward();
}

$owner = $group->getOwnerEntity();
$user = get_user_by_username($owner->username);
	
$options = array(
	'guid' => $group->guid,
	'metadata_name' => 'notpublished',
	'limit' => 0
);
elgg_delete_metadata($options);

$view = 'river/group/create';

elgg_delete_river(array(
	'object_guid' => $group->guid, 
	'view' => $view
));
add_to_river($view, 'create', $user->guid, $group->guid);
		
// we had success so forward and display success message
system_message(elgg_echo('group_publish:success'));
forward(REFERER);

?>
