<?php

add_translation("en", array(
    /**
     * Status messages
     */
        'be_tom:removeFailed' => "Sorry, the system requires you to remain friends with %s.",
        'be_tom:settings' => "Enter the GUID values of user's you want to make as tom in comma seperated forms. Your GUID value is %s.",
));

