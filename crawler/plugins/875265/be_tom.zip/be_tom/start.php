<?php

/* Be Tom - Elgg plugin to maintain a friendship between a designated user and
 * every other site user.
 * 
 * Instructions:
 * *************
 * 1) Enable the plugin
 * 2) Enter the guid values of the users to be tommed
 * 
 * Version 1.4 - Team Webgalli: Support for Elgg 1.8.X
 * 
 * Version 1.3 - Team Webgalli: Modified such that friendship with multiple tom users are possible and 
 * a settings page to enter the guid values of the multiple toms.
 * 
 * Version 1.2 - Steve Clay: rewrote to maintain the friendship on every login
 * rather than registration. Also, non-admins cannot remove the tom user from friends.
 *
 * Version 1.1 - Zac
 * (version 1.1 fixes an issue where it works with the latest svn version, but not the 'stable' 1.0 release)
 * It's a low priority, but a future todo item will be a page in the admin interface to allow you to 
 * configure this plugin easily w/o messing with code. It's a very low priority, but if there is a lot
 * of interest I will start on it.
 */

//define('ELGG_BE_TOM_USERNAME', 'onlinesupport');
function betom_init(){
	global $CONFIG;
    elgg_register_event_handler('login', 'user', 'betom_handleUserLogin', 501);
    elgg_register_event_handler('delete', 'friend', 'betom_handleFriendDelete', 400);
}
function betom_handleUserLogin($event, $object_type, $object){
	global $CONFIG;
	if (!$to_be_tommed = elgg_get_plugin_setting('to_be_tommed','be_tom')) {
		return true;
	}	
	$split = explode(",",$to_be_tommed);
    $user = $object;
    $userGuid = $user->get('guid');
	$username = $user->get('username');
	foreach ($split as $tomGuid) {
		if (!($tom = get_user($tomGuid))) { // assignment intentional
			return true;
		}
		if ($userGuid == $tomGuid) { // this is tom
			return true;
		}
		if (user_is_friend($userGuid, $tomGuid)) {	// already friends
			continue;
		}
		// temporarily disable friend creation events
		$createFriendEvents = array();
		if (isset($CONFIG->events['create']['friend'])) {
			$createFriendEvents = $CONFIG->events['create']['friend'];
			$CONFIG->events['create']['friend'] = array();
		}
		// Add both directions. Necessary? Used in Post User Login Update Plugin
		try {
			$user->addFriend($tomGuid);
		} catch (Exception $e) {}
		try {
			$tom->addFriend($userGuid);
		} catch (Exception $e) {}
		if ($createFriendEvents) {
			$CONFIG->events['create']['friend'] = $createFriendEvents;
		}
	}
	return true;
}
function betom_handleFriendDelete($event, $object_type, $object) {
    global $CONFIG;
    static $messageSent = false;
	if (!$to_be_tommed = elgg_get_plugin_setting('to_be_tommed','be_tom')) {
		return true;
	}	
	$split = explode(",",$to_be_tommed);
    if (elgg_is_admin_logged_in()) {   // makes sure that user deletes initiated by an admin can continue
        return true;
    }
    if (isset($object->guid_one) && isset($object->guid_two)) {
		foreach ($split as $tomGuid) {
			if (!($tom = get_user($tomGuid))) { // assignment intentional
				return true;
			}
			if ($tomGuid == $object->guid_one || $tomGuid == $object->guid_two) {
				// due to the friends_request mod, this event handler might be called twice
				if (! $messageSent) {
					system_message(sprintf(elgg_echo('be_tom:removeFailed'), $tom->get('name')));
				}
				$messageSent = true;
				return false;
			}
		}
    }
    return true;
}

elgg_register_event_handler('init', 'system', 'betom_init');