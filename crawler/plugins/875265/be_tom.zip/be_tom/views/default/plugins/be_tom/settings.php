<?php
	/**
	 * Elgg Be Tom pluign
	 * @author Mohammed Aqeel @ Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.webgalli.com
	 */
	$to_be_tommed = $vars['entity']->to_be_tommed;
	echo "<p>";
	echo elgg_echo(('be_tom:settings'),array(elgg_get_logged_in_user_guid())); 
	echo elgg_view('input/text', array('name' => "params[to_be_tommed]", 'value' => $vars['entity']->to_be_tommed)); 
	echo "</p>";
?>