<?php
$english = array(
	'import:contacts' => 'Import contacts',
	);				
add_translation("en", $english);
