<?php
/**
 * AdminShout - send an email message to all site users and group members
 *
 * @package AdminShout
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author slyhne (forked from original Curverider plugin)
 * @link http://zurf.dk/elgg
*/ 

echo elgg_view_form('adminshout/siteshout', array('class' => 'elgg-form-settings'));
