<?php
/**
 * AdminShout CSS
 *
 * @package adminshout
*/
?>

/* adminshout Plugin */

#message_sending {
	position: absolute;
	z-index:1000;
	width: 100%;
	margin-top: 15px;
}
