<?php
 
    /**
	 * Elgg Google Buzz CSS
	 * 
	 * @package ElggGoogleBuzz
	 */
     
?>

#googlebuzz_widget {
    margin:0 10px 0 10px;
}
