<?php
/**
 * Google Buzz widget language file
 */

$english = array(

	'googlebuzz:title' => 'Google Buzz',
	'googlebuzz:info' => 'Display your latest Google Buzz',
	'googlebuzz:username' => 'Enter your googel username.',
	'googlebuzz:get' => 'The number of buzzes nedd to get from you Google buzz.',
	'googlebuzz:num' => 'The number of buzzes to show.',
	'googlebuzz:visit' => 'visit my Google Buzz',
	'googlebuzz:notset' => 'This Google Buzz widget is display your latest buzz, click edit and fill in your details',		
);
					
add_translation("en", $english);
