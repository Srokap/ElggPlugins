<?php

// Généré par le plugin translation browser 

$french = array( 
	 'expages'  =>  "Pages externes" , 
	 'expages:frontpage'  =>  "Page d'accueil" , 
	 'expages:about'  =>  "A propos" , 
	 'expages:aboutcontent'  =>  "Voici le texte qui s'affichera sur la page  \"à propos de nous\"" , 
	 'expages:terms'  =>  "Conditions" , 
	 'expages:termscontent'  =>  "Voici le texte qui s'affichera sur la page  des \"conditions\"" , 
	 'expages:privacy'  =>  "Protection des données" , 
	 'expages:privacycontent'  =>  "Voici le texte qui s'affichera sur la page de \"politique de protection des données\"" , 
	 'expages:analytics'  =>  "Analyses" , 
	 'expages:contact'  =>  "Contact" , 
	 'expages:nopreview'  =>  "Prévisualisation indisponiable" , 
	 'expages:preview'  =>  "Prévisualitsation" , 
	 'expages:notset'  =>  "Cette page n'a pas encore été configuré." , 
	 'expages:lefthand'  =>  "Bloc de gauche" , 
	 'expages:righthand'  =>  "Bloc de droite" , 
	 'expages:addcontent'  =>  "Vous pouvez ajouter du contenu ici grâce à vos outils d'administrateur. " , 
	 'item:object:front'  =>  "Elements de la page d'acceuil" , 
	 'expages:posted'  =>  "Votre page a été sauvé avec succès" , 
	 'expages:deleted'  =>  "Votre page a été effacé avec succès" , 
	 'expages:deleteerror'  =>  "Il y a eu un problème lors de l'effacement d'une ancienne page." , 
	 'expages:error'  =>  "Il y a eu une erreur, veuillez réessayer et si le problème persiste, veuillez prévenir l'administrateur"
); 

add_translation('fr', $french); 

?>
