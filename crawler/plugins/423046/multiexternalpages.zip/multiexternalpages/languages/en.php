<?php

// Généré par le plugin translation browser 

$english = array( 
	 'expages'  =>  "External pages" , 
	 'expages:frontpage'  =>  "Frontpage" , 
	 'expages:about'  =>  "About" , 
	 'expages:aboutcontent'  =>  "In this page, you can read the about us text" , 
	 'expages:terms'  =>  "Terms" , 
	 'expages:termscontent'  =>  "In this page, you can read the OSF terms" , 
	 'expages:privacy'  =>  "Privacy" , 
	 'expages:privacycontent'  =>  "In this page, you can read our \"privacy policy\"" , 
	 'expages:analytics'  =>  "Analytics" , 
	 'expages:contact'  =>  "Contact" , 
	 'expages:nopreview'  =>  "No preview yet available" , 
	 'expages:preview'  =>  "Preview" , 
	 'expages:notset'  =>  "This page has not been set up yet." , 
	 'expages:lefthand'  =>  "The lefthand information pane" , 
	 'expages:righthand'  =>  "The righthand information pane" , 
	 'expages:addcontent'  =>  "You can add content here via your admin tools. Look for the external pages link under admin." , 
	 'item:object:front'  =>  "Front page items" , 
	 'expages:posted'  =>  "Your page post was successfully posted." , 
	 'expages:deleted'  =>  "Your page post was successfully deleted." , 
	 'expages:deleteerror'  =>  "There was a problem deleting the old page" , 
	 'expages:error'  =>  "There has been an error, please try again and if the problem persists, contact the administrator"
); 

add_translation('en', $english); 

?>
