<?php

	$chinese = array(
	
		/**
		 * Site info details
		 */
		
		'members:members' => "成员",
	    'members:online' => "在线成员",
	    'members:active' => "在线成员",
	    'members:searchtag' => "随便搜",
	    'members:searchname' => "搜索名字",
		'members:filter:newest' => '新成员',
		'members:filter:random' => '随机成员',
		'members:filter:pop' => '红人',
		'members:filter:active' => '在线成员',
	   	'members:random:regenerate' => '看看别人'
		
	);
					
	add_translation("zh",$chinese);

?>