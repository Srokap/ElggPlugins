<?php

	$english = array(
	
		/**
		 * Site info details
		 */
		
		'members:members' => "Site members",
	    'members:online' => "Members active now",
	    'members:active' => "site members",
	    'members:searchtag' => "Member search via tag",
	    'members:searchname' => "Member search via name",
		'members:filter:newest' => 'Newest',
		'members:filter:random' => 'Random',
		'members:filter:pop' => 'Pop',
		'members:filter:active' => 'Online',
	   	'members:random:regenerate' => 'See some others'
		
	);
					
	add_translation("en",$english);

?>