<?php
function bibleverse_init() {        
    elgg_register_widget_type('dailybibleverse', 'Daily Bible Verse', 'The "Daily Bible Verse" widget');
}
 
elgg_register_event_handler('init', 'system', 'bibleverse_init');       
?>