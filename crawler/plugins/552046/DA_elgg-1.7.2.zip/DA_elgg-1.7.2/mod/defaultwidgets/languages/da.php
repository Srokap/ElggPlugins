<?php
/*
*
* Default widgets [Danish]
*
* @package language
* @version Id: da.php 2010-08-27
* @source file is Copyright (c) 2008-2010 Curverider Ltd
* @modified and translated by elggzone.com
* @link http://www.elggzone.com
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
*
* This file is part of the Danish language package for Elgg 1.7.2
* Copyright (c) 2010 elggzone.com
*
* The package is free software; you can redistribute it and/or modify it under the terms of the GNU
* General Public License as published by the Free Software Foundation, version 2 of the License.

* The Danish language package is distributed in the hope that it will be useful, but WITHOUT ANY
* WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
* A PARTICULAR PURPOSE. See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this language
* package. If not, see <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>.
*
*/

$danish = array(
	
	/**
	 * Nice name for the entity (shown in admin panel)
	 */
	'item:object:moddefaultwidgets' => 'Indstillinger for standard Widgets',
	
	/**
	 * Menu items
	 */
	'defaultwidgets:menu:profile' => 'Standard profil widgets',
	'defaultwidgets:menu:dashboard' => 'Standard widgets i instrumentpanel',
	
	'defaultwidgets:admin:error' => 'Fejl: Du er ikke logget ind som administrator',
	'defaultwidgets:admin:notfound' => 'Fejl: Side ikke fundet',
	'defaultwidgets:admin:loginfailure' => 'Advarsel: Du er ikke logget ind som administrator',
	
	'defaultwidgets:update:success' => 'Dine widget indstillinger er blevet gemt',
	'defaultwidgets:update:failed' => 'Fejl: dine indstillinger er ikke blevet gemt',
	'defaultwidgets:update:noparams' => 'Fejl: ukorrekt parameter',
	
	'defaultwidgets:profile:title' => 'Indstil standard widgets for ny brugers profilside',
	'defaultwidgets:dashboard:title' => 'Indstil standard widgets for ny brugers instrumentpanel',
	
);
	
add_translation("da",$danish);

?>