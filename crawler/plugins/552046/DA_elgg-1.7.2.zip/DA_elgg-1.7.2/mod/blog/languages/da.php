<?php
/*
*
* Elgg Blog [Danish]
*
* @package language
* @version Id: da.php 2010-08-27
* @source file is Copyright (c) 2008-2010 Curverider Ltd
* @modified and translated by elggzone.com
* @link http://www.elggzone.com
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
*
* This file is part of the Danish language package for Elgg 1.7.2
* Copyright (c) 2010 elggzone.com
*
* The package is free software; you can redistribute it and/or modify it under the terms of the GNU
* General Public License as published by the Free Software Foundation, version 2 of the License.

* The Danish language package is distributed in the hope that it will be useful, but WITHOUT ANY
* WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
* A PARTICULAR PURPOSE. See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this language
* package. If not, see <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>.
*
*/

$danish = array(

	/**
	 * Menu items and titles
	 */

	'blog'  =>  'Blog', 
	'blogs'  =>  'Blogge', 
	'blog:user'  =>  '%s\'s blog', 
	'blog:user:friends'  =>  '%s\'s venners blog', 
	'blog:your'  =>  'Din blog' , 
	'blog:posttitle'  =>  '%s\'s blog: %s', 
	'blog:friends'  =>  'Venners blogge', 
	'blog:yourfriends'  =>  'Dine venners seneste blogge', 
	'blog:everyone'  =>  'Alle blogge', 
	'blog:newpost' => "Ny blog post",
	'blog:via' => "via blog",
	'blog:read'  =>  'Læs blog',
		 
	'blog:addpost'  =>  'Skriv et blogindlæg', 
	'blog:editpost'  =>  'Rediger blogindlæg', 
	
	'blog:text'  =>  'Blogtekst',
	 
	'blog:strapline'  =>  '%s',
	 
	'item:object:blog'  =>  'Blogindlæg',
	
	'blog:never' => 'aldrig',
	'blog:preview' => 'Vis prøve',

	'blog:draft:save' => 'Gem kladde',
	'blog:draft:saved' => 'Kladde gemt',
	'blog:comments:allow' => 'Tillad kommentarer', 
	
	'blog:preview:description' => 'Dette er en prøve af dit blogindlæg, det er ikke gemt.',
	'blog:preview:description:link' => 'For at fortsætte med at redigere eller gemme dit indlæg, klik her.',
	
	'groups:enableblog' => 'Aktiver gruppe blog',	
	'blog:group' => 'Gruppe blog',
	'blog:nogroup' => 'Denne gruppe har ingen blogindlæg endnu',
	'blog:more' => 'Flere blogindlæg',

	'blog:read_more' => 'Læs hele indlægget',
		
/**
 * Blog widget
 */ 
	'blog:widget:description' => 'Denne widget viser dine seneste blogindlæg',
	'blog:moreblogs' => 'Flere blogindlæg',
	'blog:numbertodisplay' => 'Antal blogindlæg der skal vises',
	
/**
* Blog river
**/
 
	//generic terms to use
 	'blog:river:created'  =>  '%s skrev', 
	'blog:river:updated'  =>  '%s opdaterede', 
	'blog:river:posted'  =>  '%s udsendte',
	
	//these get inserted into the river links to take the user to the entity 
	'blog:river:create'  =>  'et nyt blogindlæg.', 
	'blog:river:update'  =>  'et blogindlæg.', 
	'blog:river:annotate'  =>  'en kommentar til et blogindlæg.',

	
/**
* Status messages
*/

	'blog:posted'  =>  'Dit blogindlæg er blevet udgivet.', 
	'blog:deleted'  =>  'Dit blogindlæg er blevet slettet.',
	
/**
* Error messages
*/

	'blog:error' => 'Noget gik galt. Prøv venligst igen.',	 
	'blog:save:failure'  =>  'Dit blogindlæg kunne ikke gemmes. Prøv venligst igen.', 
	'blog:blank'  =>  'Beklager, du er nødt til at udfylde både titel og tekst, før du kan poste et indlæg.', 
	'blog:notfound'  =>  'Beklager, det specificerede blogindlæg kunne ikke findes.', 
	'blog:notdeleted'  =>  'Beklager, blogindlægget kunne ikke slettes.'

);

add_translation('da',$danish);

?>