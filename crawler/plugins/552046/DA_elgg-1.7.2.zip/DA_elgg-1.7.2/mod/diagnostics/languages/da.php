<?php
/*
*
* Elgg diagnostics [Danish]
*
* @package language
* @version Id: da.php 2010-08-27
* @source file is Copyright (c) 2008-2010 Curverider Ltd
* @modified and translated by elggzone.com
* @link http://www.elggzone.com
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
*
* This file is part of the Danish language package for Elgg 1.7.2
* Copyright (c) 2010 elggzone.com
*
* The package is free software; you can redistribute it and/or modify it under the terms of the GNU
* General Public License as published by the Free Software Foundation, version 2 of the License.

* The Danish language package is distributed in the hope that it will be useful, but WITHOUT ANY
* WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
* A PARTICULAR PURPOSE. See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this language
* package. If not, see <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>.
*
*/

$danish = array(

	'diagnostics' => 'System diagnostik',
	'diagnostics:unittester' => 'Enhedstest',
	
	'diagnostics:description' => 'Den følgende diagnostik rapport er anvendelig til at diagnosticere ethvert problem med Elgg, og skal vedhæftes alle bug rapporter.',
	'diagnostics:unittester:description' => 'Det følgende er diagnostik test som er registreret af plugins og kan udføres for at debugge dele af Elgg frameworket.',
	
	'diagnostics:unittester:description' => 'Enhedstest kontrollerer Elgg Core for defekte eller buggy APIs.',
	'diagnostics:unittester:debug' => 'Siden skal være i debug mode for at køre enhedstest.',
	'diagnostics:unittester:warning' => 'Advarsel: Disse tests kan efterlade debugging objekter i din database. BRUG DEM IKKE PÅ EN FUNGERENDE ONLINE SIDE!',
	
	'diagnostics:test:executetest' => 'Udfør test',
	'diagnostics:test:executeall' => 'Udfør alle',
	'diagnostics:unittester:notests' => 'Beklager, der er ingen enhedstest moduler installeret.',
	'diagnostics:unittester:testnotfound' => 'Beklager, rapporten kunne ikke genereres fordi testen ikke blev fundet',
	
	'diagnostics:unittester:testresult:nottestclass' => 'Fejl - Resultatet er ikke en test class',
	'diagnostics:unittester:testresult:fail' => 'FEJL',
	'diagnostics:unittester:testresult:success' => 'SUCCES',
	
	'diagnostics:unittest:example' => 'Eksempel enhedstest er kun tilgængelig i debug mode.',
	
	'diagnostics:unittester:report' => 'Test rapport for %s',
	
	'diagnostics:download' => 'Download .txt',
	
	
	'diagnostics:header' => '========================================================================
	Elgg Diagnostic Report
	Generated %s by %s
	========================================================================
	
	',
	'diagnostics:report:basic' => '
	Elgg Release %s, version %s
	
	------------------------------------------------------------------------',
	'diagnostics:report:php' => '
	PHP info:
	%s
	------------------------------------------------------------------------',
	'diagnostics:report:plugins' => '
	Installed plugins and details:
	
	%s
	------------------------------------------------------------------------',
	'diagnostics:report:md5' => '
	Installed files and checksums:
	
	%s
	------------------------------------------------------------------------',
	'diagnostics:report:globals' => '
	Global variables:
	
	%s
	------------------------------------------------------------------------',

);

add_translation("da",$danish);

?>