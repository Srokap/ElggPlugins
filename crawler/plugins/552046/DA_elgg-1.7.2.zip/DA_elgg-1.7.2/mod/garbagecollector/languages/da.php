<?php
/*
*
* Elgg garbage collector [Danish]
*
* @package language
* @version Id: da.php 2010-08-27
* @source file is Copyright (c) 2008-2010 Curverider Ltd
* @modified and translated by elggzone.com
* @link http://www.elggzone.com
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
*
* This file is part of the Danish language package for Elgg 1.7.2
* Copyright (c) 2010 elggzone.com
*
* The package is free software; you can redistribute it and/or modify it under the terms of the GNU
* General Public License as published by the Free Software Foundation, version 2 of the License.

* The Danish language package is distributed in the hope that it will be useful, but WITHOUT ANY
* WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
* A PARTICULAR PURPOSE. See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this language
* package. If not, see <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>.
*
*/

$danish = array(

/**
* Menu items and titles
*/

	'garbagecollector:period' => 'Hvor ofte skal Elgg opsamle skrald?',
	
	'garbagecollector:weekly' => 'En gang om ugen',
	'garbagecollector:monthly' => 'En gang om måneden',
	'garbagecollector:yearly' => 'En gang om året',
	
	'garbagecollector' => "SKRALD OPSAMLER\n",
	'garbagecollector:done' => "Færdig\n",
	'garbagecollector:optimize' => "Optimerer %s ",
	
	'garbagecollector:error' => "FEJL",
	'garbagecollector:ok' => "OK",
	
	'garbagecollector:gc:metastrings' => 'Rydder op i uforbundne metastrenge: ',	
	
);
				
add_translation('da',$danish);

?>
