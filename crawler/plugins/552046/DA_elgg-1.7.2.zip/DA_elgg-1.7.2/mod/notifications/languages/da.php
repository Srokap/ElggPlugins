<?php
/*
*
* Notifications [Danish]
*
* @package language
* @version Id: da.php 2010-08-27
* @source file is Copyright (c) 2008-2010 Curverider Ltd
* @modified and translated by elggzone.com
* @link http://www.elggzone.com
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
*
* This file is part of the Danish language package for Elgg 1.7.2
* Copyright (c) 2010 elggzone.com
*
* The package is free software; you can redistribute it and/or modify it under the terms of the GNU
* General Public License as published by the Free Software Foundation, version 2 of the License.

* The Danish language package is distributed in the hope that it will be useful, but WITHOUT ANY
* WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
* A PARTICULAR PURPOSE. See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this language
* package. If not, see <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>.
*
*/

$danish = array(
	
	'friends:all' => 'Alle venner',

	'notifications:subscriptions:personal:description' => 'Modtag besked når der sker noget omkring dit indhold',
	'notifications:subscriptions:personal:title' => 'Personlig besked',

	'notifications:subscriptions:collections:title' => 'Indstil for venneliste',
	'notifications:subscriptions:collections:description' => 'Vælg beskedtype for alle dine venner og for vennelister med ikonerne herunder. Hvis du vil vælge beskedtype for hver enkelt ven, kan du nederst på siden klikke gennem dine venner og vælge individuel beskedtype.',
	'notifications:subscriptions:collections:edit' => 'Klik her for at redigere din vennesamling.',

	'notifications:subscriptions:changesettings' => 'Beskeder',
	'notifications:subscriptions:changesettings:groups' => 'Gruppe beskeder',
	'notification:method:email' => 'Email',	

	'notifications:subscriptions:title' => 'Indstil individuelt',
	'notifications:subscriptions:description' => 'Du kan vælge at modtage beskeder fra dine venner, når de opretter nyt indhold. Find dem herunder og vælg den type besked du foretrækker.',

	'notifications:subscriptions:groups:description' => 'Du kan vælge at modtage besked, når nyt indhold tilføjes en gruppe, du er medlem af. Find gruppen herunder og vælg den type besked du foretrækker.',

	'notifications:subscriptions:success' => 'Dine indstillinger for beskeder er blevet gemt.',
	
);
					
add_translation("da",$danish);

?>