<?php
/*
*
* Messageboard [Danish]
*
* @package language
* @version Id: da.php 2010-08-27
* @source file is Copyright (c) 2008-2010 Curverider Ltd
* @modified and translated by elggzone.com
* @link http://www.elggzone.com
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
*
* This file is part of the Danish language package for Elgg 1.7.2
* Copyright (c) 2010 elggzone.com
*
* The package is free software; you can redistribute it and/or modify it under the terms of the GNU
* General Public License as published by the Free Software Foundation, version 2 of the License.

* The Danish language package is distributed in the hope that it will be useful, but WITHOUT ANY
* WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
* A PARTICULAR PURPOSE. See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this language
* package. If not, see <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>.
*
*/

$danish = array(

/**
* Menu items and titles
*/

	'messageboard:board'  =>  "Opslagstavle", 
	'messageboard:messageboard'  =>  "opslagstavle", 
	'messageboard:viewall'  =>  "Se alle", 
	'messageboard:postit'  =>  "Send det", 
	'messageboard:history:title'  =>  "Historie", 
	'messageboard:none'  =>  "Der er ikke noget på denne opslagstavle endnu", 
	'messageboard:num_display'  =>  "Antal viste beskeder" , 
	'messageboard:desc'  =>  "Dette er en opslagstavle, som du kan placere på din profil, så andre brugere kan kommentere.",	
	
	'messageboard:user' => "%s's opslagstavle",
		
	'messageboard:replyon' => 'svar på',
	'messageboard:history' => "historie",

 /**
 * Message board widget river
 **/
	
	'messageboard:river:annotate'  =>  "%s har en ny kommentar på sin opslagstavle.", 
	'messageboard:river:create'  =>  "%s har tilføjet opslagstavle widget'en.",	  
	'messageboard:river:update'  =>  "%s opdaterede sin opslagstavle widget.",	
	'messageboard:river:added' => "%s skrev på",
	'messageboard:river:messageboard' => "opslagstavle",

	
/**
 * Status messages
 */

	'messageboard:posted'  =>  "Du har skrevet på opslagstavlen." , 
	'messageboard:deleted'  =>  "Du har slettet beskeden." , 

/**
 * Email messages
 */

	'messageboard:email:subject'  =>  "Du har en ny kommentar på opslagstavlen!" , 
	'messageboard:email:body'  =>  "Du har en ny kommentar på opslagstavle fra %s. Der står:
	
%s

For at se din opslagstavle, klik her:

%s

For at se %s's profil, klik her:

%s

Du kan ikke svare på denne mail." , 

/**
 * Error messages
 */

	'messageboard:blank'  =>  "Beklager, men du er nødt til at skrive noget i beskeden før, den kan gemmes." , 
	'messageboard:notfound'  =>  "Beklager, vi kunne ikke finde det specificerede emne." , 
	'messageboard:notdeleted'  =>  "Beklager, beskeden kunne ikke slettes." , 
	'messageboard:somethingwentwrong' => "Noget gik galt da din besked skulle gemmes, kontroller at du har skrevet en besked.",
	 
	'messageboard:failure'  =>  "Der opstod en uventet fejl under tilføjelsen af din besked. Prøv venligst igen."

);

add_translation("da",$danish);

?>