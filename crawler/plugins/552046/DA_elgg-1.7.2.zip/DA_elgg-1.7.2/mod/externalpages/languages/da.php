<?php
/*
*
* External pages [Danish]
*
* @package language
* @version Id: da.php 2010-08-27
* @source file is Copyright (c) 2008-2010 Curverider Ltd
* @modified and translated by elggzone.com
* @link http://www.elggzone.com
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
*
* This file is part of the Danish language package for Elgg 1.7.2
* Copyright (c) 2010 elggzone.com
*
* The package is free software; you can redistribute it and/or modify it under the terms of the GNU
* General Public License as published by the Free Software Foundation, version 2 of the License.

* The Danish language package is distributed in the hope that it will be useful, but WITHOUT ANY
* WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
* A PARTICULAR PURPOSE. See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this language
* package. If not, see <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>.
*
*/

$danish = array(

/**
* Menu items and titles
*/

	'expages' => "Eksterne sider",
	'expages:frontpage' => "Forside",
	'expages:about' => "Om",
	'expages:terms' => "Betingelser",
	'expages:privacy' => "Beskyttelse af personlige oplysninger",
	'expages:analytics' => "Analyser",
	'expages:contact' => "Kontakt",
	'expages:nopreview' => "Ingen prøve tilgængelig",
	'expages:preview' => "Vis prøve",
	'expages:notset' => "Denne side er ikke sat op endnu.",
	'expages:lefthand' => "Venstre informations boks",
	'expages:righthand' => "Højre informations boks",
	'expages:addcontent' => "Du kan ikke tilføje indhold via dit administrationsværktøj. Se efter linket \'Eksterne sider\' i menuen under administration.",
	'item:object:front' => 'Forside elementer',

/**
* Status messages
*/

	'expages:posted' => "Din tekst til siden er blevet sendt korrekt.",
	'expages:deleted' => "Din tekst til siden er blevet slettet korrekt.",

/**
* Error messages
*/

	'expages:deleteerror' => "Der opstod et problem med at slette den gamle side",
	'expages:error' => "Der opstod en fejl, prøv venligst igen og kontakt administrationen hvis problemet fortsætter",		
	
);
				
add_translation('da',$danish);

?>
