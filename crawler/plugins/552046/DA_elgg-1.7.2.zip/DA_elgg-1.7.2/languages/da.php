<?php
/*
* Core language file
*
* @package Elgg
* @subpackage Core
* @author Curverider Ltd
* @link http://elgg.org/
*/

/*
*
* Core [Danish]
*
* @package language
* @version Id: da.php 2010-08-27
* @source file is Copyright (c) 2008-2010 Curverider Ltd
* @modified and translated by elggzone.com
* @link http://www.elggzone.com
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
*
* This file is part of the Danish language package for Elgg 1.7.2
* Copyright (c) 2010 elggzone.com
*
* The package is free software; you can redistribute it and/or modify it under the terms of the GNU
* General Public License as published by the Free Software Foundation, version 2 of the License.

* The Danish language package is distributed in the hope that it will be useful, but WITHOUT ANY
* WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
* A PARTICULAR PURPOSE. See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this language
* package. If not, see <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>.
*
*/

$danish = array( 
	
	/**
	* Sites
	*/
	
	'item:site'  =>  "Sider",
	
	/**
	* Sessions
	*/
	
	'login'  =>  "Log ind", 
	'loginok'  =>  "Du er blevet logget ind.", 
	'loginerror'  =>  "Vi kunne ikke logge dig ind. Det kan være fordi, du ikke har valideret din konto endnu eller fordi de detaljer, du angav er forkerte. Undersøg om detaljerne er korrekte, og prøv venligst igen.",
	
	'logout'  =>  "Log ud", 
	'logoutok'  =>  "Du er blevet logget ud.", 
	'logouterror'  =>  "Vi kunne ikke logge dig ud. Prøv venligst igen.",
	
	'loggedinrequired' => "Du skal være logget ind for at se den side.",
	'adminrequired' => "Du skal være administrator for at se den side.",
	'membershiprequired' => "Du skal være medlem af gruppen for at se siden.",
	
	/**
	* Errors
	*/ 
	'exception:title'  =>  "Velkommen til Elgg.",
	
	'InstallationException:CantCreateSite'  =>  "Ude af stand til at oprette standard ElggSite med egenskaberne Navn:%s, Url: %s",
	
	'actionundefined'  =>  "Den de handling (%s) var ikke defineret i systemet.", 	  
	'actionloggedout'  =>  "Beklager, du kan ikke udføre denne handling når du er logget ud.",
	'actionunauthorized' => 'Du har ikke autorisation til at udføre denne handling',
	
	'SecurityException:Codeblock'  =>  "Adgang nægtet til at eksekvere privilegeret kodeblok", 
	'DatabaseException:WrongCredentials'  =>  "Elg kunne ikke oprette forbindelse til databasen med egenskaberne %s@%s (pw: %s).", 
	'DatabaseException:NoConnect'  =>  "Elgg kunne ikke vælge databasen '%s', undersøg venligst om databasen er oprettet, og at du har adgang til den.", 
	'SecurityException:FunctionDenied'  =>  "Adgang til priviligeret funktion '%s' nægtet.", 
	'DatabaseException:DBSetupIssues'  =>  "Der var følgende problemer: ", 
	'DatabaseException:ScriptNotFound'  =>  "Elgg kunne ikke finde det efterspurgte database script på %s.", 
	
	'IOException:FailedToLoadGUID'  =>  "Hentning af ny %s fra GUID:%d mislykkedes", 
	'InvalidParameterException:NonElggObject'  =>  "Sendte et non-ElggObject til en ElggObject constructor!", 
	'InvalidParameterException:UnrecognisedValue'  =>  "Ukendt værdi sendt til constructor",
		  
	'InvalidClassException:NotValidElggStar'  =>  "GUID:%d er ikke en gyldig %s",
	 
	'PluginException:MisconfiguredPlugin'  =>  "%s er en forkert opsat plugin. Den er blevet deaktiveret. Se venligst Elgg wiki for mulige årsager.",
	'InvalidParameterException:NonElggUser' => "Passing a non-ElggUser to an ElggUser constructor!",

	'InvalidParameterException:NonElggSite' => "Passing a non-ElggSite to an ElggSite constructor!",

	'InvalidParameterException:NonElggGroup' => "Passing a non-ElggGroup to an ElggGroup constructor!",
	 
	'IOException:UnableToSaveNew'  =>  "Ikke i stand til at gemme ny %s",
	 
	'InvalidParameterException:GUIDNotForExport'  =>  "GUID er ikke blevet specificeret under eksport. Dette burde aldrig ske.", 
	'InvalidParameterException:NonArrayReturnValue' =>  "Entity serialisation function sendte et non-array returnvalue parameter",
	 
	'ConfigurationException:NoCachePath'  =>  "Cache sti sat til intet!", 
	'IOException:NotDirectory'  =>  "%s er ikke en folder.",
	 
	'IOException:BaseEntitySaveFailed'  =>  "Ude af i stand til at gemme object's base entity information!", 
	'InvalidParameterException:UnexpectedODDClass'  =>  "import() sendte en uventet ODD class", 
	'InvalidParameterException:EntityTypeNotSet'  =>  "Entity type skal vælges.",
	 
	'ClassException:ClassnameNotClass'  =>  "%s er ikke en %s.", 
	'ClassNotFoundException:MissingClass'  =>  "Class '%s' blev ikke fundet, mangler der et plugin?", 
	'InstallationException:TypeNotSupported'  =>  "Type %s er ikke understøttet. Det indikerer en fejl ved din installation, sandsynligvis skabt af en ufuldstændig opdatering.",
	 
	'ImportException:ImportFailed'  =>  "Kunne ikke importere elementet %d",
	'ImportException:ProblemSaving'  =>  "Der var et problem med at gemme %s", 
	'ImportException:NoGUID'  =>  "Ny entity oprettet men uden GUID. Dette burde ikke ske.",
	
	'ImportException:GUIDNotFound'  =>  "Enhed '%d' blev ikke fundet.", 
	'ImportException:ProblemUpdatingMeta'  =>  "Der var et problem med at opdatere '%s' på entity '%d'",
	 
	'ExportException:NoSuchEntity'  =>  "Entity GUID:%d findes ikke.",
	 
	'ImportException:NoODDElements'  =>  "Ingen OpenDD elementer fundet i import data, import mislykkedes.", 
	'ImportException:NotAllImported'  =>  "Ikke alle elementer blev importeret.",
	
	'InvalidParameterException:UnrecognisedFileMode'  =>  "Unrecognised file mode '%s'", 
	'InvalidParameterException:MissingOwner'  =>  "File %s (file guid:%d) (owner guid:%d) is missing an owner!", 
	'IOException:CouldNotMake'  =>  "Kunne ikke udføre %s",
	'IOException:MissingFileName'  =>  "Du skal angive et navn for at åbne en fil.", 
	'ClassNotFoundException:NotFoundNotSavedWithFile'  =>  "Filestore ikke fundet, eller klasse ikke gemt med fil!", 
	'NotificationException:NoNotificationMethod'  =>  "Ingen metode er angivet for påmindelser.", 
	'NotificationException:NoHandlerFound'  =>  "Ingen handler fundet til '%s' eller det kunne ikke kaldes.", 
	'NotificationException:ErrorNotifyingGuid'  =>  "Der var en fejl med at informere %d", 
	'NotificationException:NoEmailAddress'  =>  "Kunne ikke finde email adresse til GUID:%d", 
	'NotificationException:MissingParameter'  =>  "Mangler et krævet parameter, '%s'",
	
	'DatabaseException:WhereSetNonQuery' => "Where set contains non WhereQueryComponent",
	'DatabaseException:SelectFieldsMissing' => "Fields missing on a select style query",
	'DatabaseException:UnspecifiedQueryType' => "Unrecognised or unspecified query type.",
	'DatabaseException:NoTablesSpecified' => "No tables specified for query.",
	'DatabaseException:NoACL' => "No access control was provided on query",
	
	'InvalidParameterException:NoEntityFound'  =>  "Ingen entity fundet, enten findes den ikke eller du har ikke adgang til den.",
	
	'InvalidParameterException:GUIDNotFound'  =>  "GUID:%s kunne ikke findes, eller du kunne ikke få adgang til den.", 
	'InvalidParameterException:IdNotExistForGUID'  =>  "Beklager, '%s' findes ikke med guid:%d", 
	'InvalidParameterException:CanNotExportType'  =>  "Beklager, kunne ikke eksporterer '%s'", 
	'InvalidParameterException:NoDataFound'  =>  "Kunne ikke finde nogen data.", 
	'InvalidParameterException:DoesNotBelong'  =>  "Passer ikke med enhed.", 
	'InvalidParameterException:DoesNotBelongOrRefer'  =>  "Passer ikke med entity eller refererer ikke til entity.", 
	'InvalidParameterException:MissingParameter'  =>  "Manglende parameter, du skal give en GUID.", 
	
	'APIException:ApiResultUnknown'  =>  "API resultat er af en ukendt type. Dette skulle aldrig ske.",
	'ConfigurationException:NoSiteID'  =>  "Ingen side ID specificeret.",
	'SecurityException:APIAccessDenied'  =>  "Beklager, API adgang er slået fra af administratoren.", 
	'SecurityException:NoAuthMethods'  =>  "Ingen autentificeringsmetoder metoder fundet til at autentificere denne API request.", 
	'InvalidParameterException:APIMethodOrFunctionNotSet' => "Method or function not set in call in expose_method()", 
	'InvalidParameterException:APIParametersArrayStructure' => "Parameters array structure is incorrect for call to expose method '%s'",	  
	'InvalidParameterException:UnrecognisedHttpMethod' => "Unrecognised http method %s for api method '%s'",
	'APIException:MissingParameterInMethod'  =>  "Missing parameter %s in method %s", 
	'APIException:ParameterNotArray' => "%s synes ikke at være en array.",
	'APIException:UnrecognisedTypeCast' => "Unrecognised type in cast %s for variable '%s' in method '%s'",
	'APIException:InvalidParameter' => "Invalid parameter found for '%s' in method '%s'.",
	'APIException:FunctionParseError' => "%s(%s) has a parsing error.",
	'APIException:FunctionNoReturn'  =>  "%s(%s) returnerede ingen værdi",
	'APIException:APIAuthenticationFailed' => "Method call failed the API Authentication",
	'APIException:UserAuthenticationFailed' => "Method call failed the User Authentication", 
	'SecurityException:AuthTokenExpired'  =>  "Autentificerings token enten mangler, er forkert eller er udløbet.", 
	'CallException:InvalidCallMethod'  =>  "%s skal kaldes med '%s'", 
	'APIException:MethodCallNotImplemented'  =>  "Medtodekald '%s' er ikke implementeret",
	'APIException:FunctionDoesNotExist' => "Function for method '%s' is not callable", 
	'APIException:AlgorithmNotSupported'  =>  "Algoritme '%s' er ikke understøttet, eller er blevet slået fra.", 
	'ConfigurationException:CacheDirNotSet' => "Cache directory 'cache_path' not set.",
	'APIException:NotGetOrPost' => "Request metode skal være GET eller POST", 
	'APIException:MissingAPIKey'  =>  "Manglende API key",
	'APIException:BadAPIKey' => "Bad API key", 
	'APIException:MissingHmac' => "Missing X-Elgg-hmac header",
	'APIException:MissingHmacAlgo' => "Missing X-Elgg-hmac-algo header",
	'APIException:MissingTime' => "Missing X-Elgg-time header",
	'APIException:MissingNonce' => "Missing X-Elgg-nonce header",
	'APIException:TemporalDrift' => "X-Elgg-time is too far in the past or future. Epoch fail.",
	'APIException:NoQueryString' => "No data on the query string",
	'APIException:MissingPOSTHash' => "Missing X-Elgg-posthash header",
	'APIException:MissingPOSTAlgo' => "Missing X-Elgg-posthash_algo header",
	'APIException:MissingContentType' => "Missing content type for post data",
	'SecurityException:InvalidPostHash' => "POST data hash is invalid - Expected %s but got %s.",
	'SecurityException:DupePacket' => "Packet signature already seen.",
	'SecurityException:InvalidAPIKey' => "Ugyldig eller manglende API Key.",
	'NotImplementedException:CallMethodNotImplemented' => "Call method '%s' is currently not supported.", 
	
	'NotImplementedException:XMLRPCMethodNotImplemented' => "XML-RPC method call '%s' not implemented.",
	'InvalidParameterException:UnexpectedReturnFormat' => "Call to method '%s' returned an unexpected result.",
	'CallException:NotRPCCall' => "Call does not appear to be a valid XML-RPC call",
	
	'PluginException:NoPluginName'  =>  "Plugin navnet kunne ikke findes",
	
	'ConfigurationException:BadDatabaseVersion'  =>  "Den database backend du har installeret opfylder ikke mindstekravene for at køre Elgg. Læs venligst din dokumentation.", 
	'ConfigurationException:BadPHPVersion'  =>  "Du skal mindst have PHP version 5.2 for at køre Elgg.", 
	'configurationwarning:phpversion'  =>  "Elgg kræver mindst PHP version 5.2, du kan installere det på 5.1.6 men nogle funtioner vil ikke virke. Forsøg på eget ansvar.",	
	
	'InstallationException:DatarootNotWritable'  =>  "Din datafolder er ikke skrivbar.", 
	'InstallationException:DatarootUnderPath'  =>  "Din datafolder %s skal være udenfor din installationssti.", 
	'InstallationException:DatarootBlank'  =>  "Du har ikke specificeret en datafolder.", 
	
	'SecurityException:authenticationfailed'  =>  "Bruger kunne ikke autoriseres",
	
	'CronException:unknownperiod'  =>  "%s er ikke en genkendt periode.",
	
	'SecurityException:deletedisablecurrentsite'  =>  "Du kan ikke deaktivere eller slette den side, som du selv ser på!", 
	
	'memcache:notinstalled' => 'PHP memcache module not installed, you must install php5-memcache',
	'memcache:noservers' => 'No memcache servers defined, please populate the $CONFIG->memcache_servers variable',
	'memcache:versiontoolow' => 'Memcache behøver mindst version %s for at fungere, du kører %s',
	'memcache:noaddserver' => 'Multiple server support disabled, you may need to upgrade your PECL memcache library',
	
	'deprecatedfunction' => 'Advarsen: Denne kode bruger en forældet funktion \'%s\' og er ikke kompatibel med denne version af Elgg',
	
	'pageownerunavailable' => 'Advarsel: Sideejeren %d kan ikke kontaktes!',
	/**
	* API
	*/	
	'system.api.list' => "List all available API calls on the system.",
	'auth.gettoken' => "This API call lets a user obtain a user authentication token which can be used for authenticating future API calls. Pass it as the parameter auth_token",
	
	/**
	* User details
	*/
	
	'name'  =>  "Fulde navn", 
	'email'  =>  "Email adresse", 
	'username'  =>  "Brugernavn", 
	'password'  =>  "Adgangskode", 
	'passwordagain'  =>  "Adgangskode (igen for verifikation)",
	'admin_option'  =>  "Skal denne bruger være administrator?",
	
	/**
	* Access
	*/
	
	'PRIVATE'  =>  "Privat", 
	'LOGGED_IN'  =>  "Brugere der er logget ind", 
	'PUBLIC'  =>  "Offentlig",
	'access:friends:label' => "Venner",
	'access' => "Adgang", 
	
	/**
	* Dashboard and widgets
	*/
	
	'dashboard'  =>  "Instrumentpanel", 
	'dashboard:configure'  =>  "Rediger side",
	'dashboard:nowidgets'  =>  "Dit instrumentpanel er din indgang til siden. Klik på \"Rediger side\" for at tilføje widgets til at holde styr på indhold og dit liv på siden.",
	
	'widgets:add'  =>  "Tilføj widgets til siden", 
	'widgets:add:description'  =>  "Vælg de funktioner du ønsker at tilføje til siden ved at trække dem fra <b>Widget galleriet</b> til højre til et hvilket som helst af de tre widgetområder nedenfor og placer dem, hvor du ønsker, de skal være.
	
En widget fjernes ved at trække den tilbage til <b>Widget galleriet</b>.", 
	'widgets:position:fixed'  =>  "(Fast placering på siden)",
	
	'widgets'  =>  "Widgets", 
	'widget'  =>  "Widget", 
	'item:object:widget'  =>  "Widgets", 
	'layout:customise'  =>  "Tilpas layout", 
	'widgets:gallery'  =>  "Widget galleri", 
	'widgets:leftcolumn'  =>  "Venstre widgets", 
	'widgets:fixed'  =>  "Fast position", 
	'widgets:middlecolumn'  =>  "Midterste widgets", 
	'widgets:rightcolumn'  =>  "Højre widgets", 
	'widgets:profilebox'  =>  "Profil boks", 
	'widgets:panel:save:success'  =>  "Dine widgets er blevet gemt.", 
	'widgets:panel:save:failure'  =>  "Der opstod et problem med at gemme dine widgets. Prøv venligst igen.", 
	'widgets:save:success'  =>  "Widgetten blev gemt.", 
	'widgets:save:failure'  =>  "Der opstod et problem med at gemme din widget. Prøv venligst igen.",
	'widgets:handlernotfound' => 'Denne widget er enten defekt eller blevet deaktiveret af en administrator.',
	
	/**
	* Groups
	*/
	
	'group'  =>  "Gruppe", 
	'item:group'  =>  "Grupper",
	
	/**
	* Users
	*/
	
	'user'  =>  "Bruger", 
	'item:user'  =>  "Brugere", 
	
	/**
	* Friends
	*/
	
	'friends'  =>  "Venner", 
	'friends:yours'  =>  "Dine venner", 
	'friends:owned'  =>  "%s's venner", 
	'friend:add'  =>  "Tilføj ven",
	'friend:remove'  =>  "Fjern ven",
	
	'friends:add:successful'  =>  "Du har tilføjet %s som ven.", 
	'friends:add:failure'  =>  "Vi kunne ikke tilføje %s som ven. Prøv venligst igen.",
	
	'friends:remove:successful'  =>  "Du har fjernet %s fra dine venner.", 
	'friends:remove:failure'  =>  "Vi kunne ikke fjerne %s fra dine venner. Prøv venligst igen.",
	
	'friends:none'  =>  "Denne bruger har ikke tilføjet nogen som ven endnu.", 
	'friends:none:you'  =>  "Du har ikke tilføjet nogen som ven! Søg på dine interesser for at finde personer du vil følge.",
	 
	'friends:none:found'  =>  "Ingen venner fundet.", 
	
	'friends:of:none'  =>  "Ingen har tilføjet denne bruger som ven endnu.", 
	'friends:of:none:you'  =>  "Ingen har tilføjet dig som ven endnu. Begynd at tilføje indhold og udfylde din profil for at lade folk finde dig!",	
	'friends:of:owned'  =>  "Personer der har tilføjet %s som ven",
	
	'friends:of'  =>  "Venner af",		
	'friends:collections'  =>  "Venneliste", 
	'friends:collections:add'  =>  "Ny venneliste", 
	'friends:addfriends'  =>  "Tilføj venner", 
	'friends:collectionname'  =>  "Listens navn", 
	'friends:collectionfriends'  =>  "Venner på listen", 
	'friends:collectionedit'  =>  "Rediger denne liste", 
	'friends:nocollections'  =>  "Du har endnu ikke nogen lister!", 
	'friends:collectiondeleted'  =>  "Din liste er blevet slettet!", 
	'friends:collectiondeletefailed'  =>  "Vi kunne ikke slette listen. Enter har du ikke tilladelse, eller også skete der en anden fejl.",
	 
	'friends:collectionadded'  =>  "Din liste er blevet oprettet", 
	'friends:nocollectionname'  =>  "Du er nødt til at give din liste et navn, før den kan oprettes.", 
	'friends:collections:members' => "Venneliste",
	'friends:collections:edit' => "Rediger liste",
	
	'friends:river:add'  =>  "%s blev venner med",

	'friendspicker:chararray' => 'ABCDEFGHIJKLMNOPQRSTUVWXYZÆØÅ',
	
	/**
	* Feeds
	*/
	'feed:rss'  =>  "Abonner på feed", 
	'feed:odd'  =>  "Syndiker OpenDD", 

	/**
	* links
	**/
	
	'link:view'  =>  "se link", 
	
	/**
	* River
	*/
	'river'  =>  "River", 	  
	'river:relationship:friend'  =>  "er nu ven med", 
	'river:noaccess' => 'Du har ikke tilladelse til at se dette emne.',
	'river:posted:generic' => '%s skrev',	  
	'riveritem:single:user'  =>  "en bruger", 
	'riveritem:plural:user'  =>  "nogle brugere",
	
	/**
	* Plugins
	*/	  
	'plugins:settings:save:ok'  =>  "Indstillinger for %s plugin'et blev gemt.", 
	'plugins:settings:save:fail'  =>  "Der var et problem med at gemme indstillingerne for %s plugin'et.", 
	'plugins:usersettings:save:ok'  =>  "Bruger indstillinger for %s plugin'et blev gemt.", 
	'plugins:usersettings:save:fail'  =>  "Der var et problem med at gemme bruger indstillingerne for %s plugin'et.",
	'admin:plugins:label:version' => "Version",
	'item:object:plugin'  =>  "Plugin opsætnings indstillinger ",
	
	/**
	* Notifications
	*/ 
	'notifications:usersettings'  =>  "Indstillinger for besked", 
	'notifications:methods'  =>  "Specificer hvilke metoder du ønsker at bruge.", 
	
	'notifications:usersettings:save:ok'  =>  "Dine indstillinger for besked blev gemt.", 
	'notifications:usersettings:save:fail'  =>  "Der opstod et problem med at gemme dine indstillinger for besked.",
	
	'user.notification.get'  =>  "Returner indstillingerne for besked for en given bruger.", 
	'user.notification.set'  =>  "Definer indstillinger for besked for en given bruger.",	  
	/**
	* Search
	*/
	
	'search'  =>  "Søg", 
	'searchtitle'  =>  "Søg: %s", 
	'users:searchtitle'  =>  "Søg efter brugere: %s",
	'groups:searchtitle' => "Søg efter grupper: %s",
	'advancedsearchtitle'  =>  "%s med resultater der matcher %s",
	'notfound'  =>  "Ingen resultater fundet.", 
	'next'  =>  "Næste", 
	'previous'  =>  "Forrige",
	
	'viewtype:change'  =>  "Skift listetype", 
	'viewtype:list'  =>  "Liste", 
	'viewtype:gallery'  =>  "Galleri", 
	
	'tag:search:startblurb'  =>  "Enheder med tags der matcher '%s':",
	
	'user:search:startblurb'  =>  "Brugere der matcher '%s':", 
	'user:search:finishblurb'  =>  "Klik her for at se mere.", 
	
	'group:search:startblurb' => "Grupper der matcher '%s':",
	'group:search:finishblurb' => "Klik her for at se mere.",
	'search:go' => 'Find',
	'userpicker:only_friends' => 'Kun venner',
	
	/**
	* Account
	*/
	
	'account'  =>  "Konto",
	'settings'  =>  "Indstillinger", 
	'tools'  =>  "Værktøjer", 
	'tools:yours'  =>  "Dine værktøjer",
	
	'register'  =>  "Registrer", 
	'registerok'  =>  "Du er blevet tilmeldt %s.", 
	'registerbad'  =>  "Din registrering mislykkedes. Brugernavnet kan allerede være i brug, dine adgangskoder var måske ikke ens, eller dit brugernavn eller adgangskoden var for kort.", 
	'registerdisabled'  =>  "Registrering er blevet lukket af systemadministratoren.",
	
	'firstadminlogininstructions' => 'Din nye Elgg side er blevet installeret og din administrator konto oprettet. Du kan nu konfigurere din side yderligere ved at aktivere diverse installerede plugin værktøjer.',
	
	'registration:notemail'  =>  "Den anførte email adresse ser ikke ud til at være ægte.",	   
	'registration:userexists'  =>  "Brugernavnet eksisterer allerede", 
	'registration:usernametooshort'  =>  "Dit brugernavn skal være mindst 4 tegn langt.",
	'registration:passwordtooshort'  =>  "Din adgangskode skal være mindst 6 tegn lang.", 
	'registration:dupeemail'  =>  "Denne email adresse er allerede registreret.", 
	'registration:invalidchars'  =>  "Beklager, dit brugernavn indeholder ugyldige tegn.", 
	'registration:emailnotvalid'  =>  "Beklager, den angivne email adresse er ikke tilladt på dette system.", 
	'registration:passwordnotvalid'  =>  "Beklager, det angivne adgangskode er ikke tilladt på dette system.", 
	'registration:usernamenotvalid'  =>  "Beklager, det angivne brugernavn er ikke tilladt på dette system.", 
	
	'adduser'  =>  "Tilføj bruger", 
	'adduser:ok'  =>  "Du har tilføjet en ny bruger.", 
	'adduser:bad'  =>  "Den nye bruger kunne ikke tilføjes.", 
	
	'item:object:reported_content'  =>  "Anmeldte artikler", 
	
	'user:set:name'  =>  "Kontonavn", 
	'user:name:label'  =>  "Dit navn", 
	'user:name:success'  =>  "Dit navn er blevet ændret.", 
	'user:name:fail'  =>  "Kunne ikke ændre dit navn. Kontroller at dit navn ikke er for langt og prøv igen", 
	
	'user:set:password'  =>  "Adgangskode", 
	'user:password:label'  =>  "Ny adgangskode", 
	'user:password2:label'  =>  "Gentag ny adgangskode", 
	'user:password:success'  =>  "Adgangskode ændret", 
	'user:password:fail'  =>  "Kunne ikke ændre din adgangskode", 
	'user:password:fail:notsame'  =>  "De to adgangskoder er ikke ens!", 
	'user:password:fail:tooshort'  =>  "Din adgangskode er for kort!", 
	'user:resetpassword:unknown_user' => 'Ugyldig bruger.',
	'user:resetpassword:reset_password_confirm' => 'Hvis du ændrer din adgangskode vil en email blive sendt til din registrerede email adresse.',	  
	'user:set:language'  =>  "Sprog", 
	'user:language:label'  =>  "Sprogvalg", 
	'user:language:success'  =>  "Dine sprogindstillinger er blevet opdateret", 
	'user:language:fail'  =>  "Dine sprogindstillinger kunne ikke gemmes.", 
	
	'user:username:notfound'  =>  "Brugernavn %s ikke fundet.",
	
	'user:password:lost'  =>  "Mistet adgangskode?", 
	'user:password:resetreq:success'  =>  "Anmodningen om ny adgangskode er behandlet, email sendt", 
	'user:password:resetreq:fail'  =>  "Kunne ikke ændre adgangskode.",
	
	'user:password:text'  =>  "Har du mistet adgangskoden, kan du få en ny ved at skrive dit brugernavn herunder. Vi sender en email med adressen på en godkendelses side. Klik på linket i teksten og en ny adgangskode vil blive sendt til dig.", 
	
	'user:persistent'  =>  "Husk mig",	  
	/**
	* Administration
	*/
	
	'admin:configuration:success'  =>  "Dine indstillinger er blevet gemt.", 
	'admin:configuration:fail'  =>  "Dine indstillinger kunne ikke gemmes.",
	
	'admin'  =>  "Administration", 
	'admin:description'  =>  "Administrator panelet gør dig i stand til at kontrollere alle aspekter af systemet, fra brugerstyring til hvordan plugins opfører sig. Vælg en mulighed herunder for at starte.",
	
	'admin:user'  =>  "Bruger Administration", 
	'admin:user:description'  =>  "Dette administratorpanel lader dig styre brugerindstillinger for din side. Vælg en mulighed nedenfor for at starte.", 
	'admin:user:adduser:label'  =>  "Klik her for at tilføje en ny bruger...", 
	'admin:user:opt:linktext'  =>  "Konfigurer brugere...", 
	'admin:user:opt:description'  =>  "Konfigurer bruger- og kontoinformation.", 
	
	'admin:site'  =>  "Side Administration", 
	'admin:site:description'  =>  "Med dette administrationspanel kan du kontrollere de globale indstillinger for din side.", 
	'admin:site:opt:linktext'  =>  "Indstil side...", 
	'admin:site:opt:description'  =>  "Konfigurer sidens tekniske og ikke-tekniske indstillinger.",
	'admin:site:access:warning' => "Ændring af instillingen for adgang vil kun have indflydelse på tilladelser for fremtidigt indhold.",
		
	'admin:plugins'  =>  "Værktøj Administration", 
	'admin:plugins:description'  =>  "Dette administrationspanel lader dig kontrollere og indstille værktøjer, der er installeret på din side.", 
	'admin:plugins:opt:linktext'  =>  "Indstillings værktøjer", 
	'admin:plugins:opt:description'  =>  "Konfigurer de værktøjer der er installeret på siden.", 
	'admin:plugins:label:author'  =>  "Forfatter", 
	'admin:plugins:label:copyright'  =>  "Copyright", 
	'admin:plugins:label:licence'  =>  "Licens", 
	'admin:plugins:label:website'  =>  "URL", 
	'admin:plugins:label:moreinfo'  =>  "mere information",
	'admin:plugins:label:version' => 'Version',	  
	'admin:plugins:warning:elggversionunknown' => 'Advarsel: Denne glugin angiver ikke en kompatibel Elgg version.',
	'admin:plugins:warning:elggtoolow' => 'Advarsel: Denne plugin kræver en nyere version af Elgg!',	   
	'admin:plugins:reorder:yes'  =>  "Plugin %s blev omorganiseret.", 
	'admin:plugins:reorder:no'  =>  "Plugin %s kunne ikke omorganiseres.", 
	'admin:plugins:disable:yes'  =>  "Plugin %s blev deaktiveret.", 
	'admin:plugins:disable:no'  =>  "Plugin %s kunne ikke deaktiveres.", 
	'admin:plugins:enable:yes'  =>  "Plugin %s blev aktiveret.", 
	'admin:plugins:enable:no'  =>  "Plugin %s kunne ikke aktiveres.",
	
	'admin:statistics'  =>  "Statistikker",
	'admin:statistics:description'  =>  "Dette er et overblik over statistikkerne for din side. Hvis du behøver mere detaljerede statistikker, findes der en professionel administrations funktion.", 
	'admin:statistics:opt:description'  =>  "Se statistisk information om brugere og objekter på din side.", 
	'admin:statistics:opt:linktext'  =>  "Se statistikker...", 
	'admin:statistics:label:basic'  =>  "Grundlæggende side statistikker", 
	'admin:statistics:label:numentities'  =>  "Enheder på siden", 
	'admin:statistics:label:numusers'  =>  "Antal brugere", 
	'admin:statistics:label:numonline'  =>  "Antal brugere online", 
	'admin:statistics:label:onlineusers'  =>  "Brugere online nu", 
	'admin:statistics:label:version'  =>  "Elgg version", 
	'admin:statistics:label:version:release'  =>  "Udgivelse", 
	'admin:statistics:label:version:version'  =>  "Version",
	
	'admin:user:label:search'  =>  "Find brugere:", 
	'admin:user:label:seachbutton'  =>  "Søg",
	
	'admin:user:ban:no'  =>  "Kan ikke bandlyse bruger", 
	'admin:user:ban:yes'  =>  "Bruger bandlyst.", 
	'admin:user:unban:no'  =>  "Kan ikke ophæve bandlysning af bruger", 
	'admin:user:unban:yes'  =>  "Bruger bandlysning ophævet", 
	'admin:user:delete:no'  =>  "Kan ikke slette bruger", 
	'admin:user:delete:yes'  =>  "Bruger slettet", 
	
	'admin:user:resetpassword:yes'  =>  "Adgangskode ændret, bruger underrettet.",
	'admin:user:resetpassword:no'  =>  "Adgangskode kunne ikke ændres.",
	
	'admin:user:makeadmin:yes'  =>  "Brugeren er nu administrator.", 
	'admin:user:makeadmin:no'  =>  "Vi kunne ikke gøre brugeren til en administrator.",
	
	'admin:user:removeadmin:yes' => "Brugeren er ikke længere administrator.",
	'admin:user:removeadmin:no' => "Vi kunne ikke fjerne administrator tilladelser fra denne bruger.",
	  
	/**
	* User settings
	*/ 
	'usersettings:description'  =>  "Bruger indstillingspanelet gør dig i stand til at kontrollere alle dine personlige indstilinger, fra brugerstrying til hvordan dine plugins skal fungere. Vælg en mulighed herunder for at begynde.",
	
	'usersettings:statistics'  =>  "Dine statistikker", 
	'usersettings:statistics:opt:description'  =>  "Vis statistisk information om brugere og objekter på din side.", 
	'usersettings:statistics:opt:linktext'  =>  "Konto statistikker",
	
	'usersettings:user'  =>  "Dine indstillinger", 
	'usersettings:user:opt:description'  =>  "Dette gør dig i stand til at styre dine brugerinstillinger.", 
	'usersettings:user:opt:linktext'  =>  "Rediger dine indstillinger", 
	
	'usersettings:plugins'  =>  "Værktøjer", 
	'usersettings:plugins:opt:description'  =>  "Skift indstillinger for dine aktive værktøjer.", 
	'usersettings:plugins:opt:linktext'  =>  "Indstillings værktøjer", 
	
	'usersettings:plugins:description'  =>  "Dette panel gør dig i stand til at styre og opsætte personlige indstillinger for de værktøjer, der er blevet installeret af systemadministratoren.", 
	'usersettings:statistics:label:numentities'  =>  "Dit indhold",
	
	'usersettings:statistics:yourdetails'  =>  "Dine detaljer", 
	'usersettings:statistics:label:name'  =>  "Fulde navn", 
	'usersettings:statistics:label:email'  =>  "Email", 
	'usersettings:statistics:label:membersince'  =>  "Medlem siden", 
	'usersettings:statistics:label:lastlogin'  =>  "Sidst logget ind",



	
	/**
	* Generic action words
	*/ 
	'save'  =>  "Gem",
	'publish' => "Offentliggør", 
	'cancel'  =>  "Annuller", 
	'saving'  =>  "Gemmer ...", 
	'update'  =>  "Opdater", 
	'edit'  =>  "Rediger", 
	'delete'  =>  "Slet",
	'accept' => "Accepter", 
	'load'  =>  "Hent", 
	'upload'  =>  "Tilføj", 
	'ban'  =>  "Bandlys", 
	'unban'  =>  "Ophæv bandlysning",
	'enable'  =>  "Aktiver", 
	'disable'  =>  "Deaktiver", 
	'request'  =>  "Anmod", 
	'complete'  =>  "Færdig", 
	'open'  =>  "Åbn", 
	'close'  =>  "Luk", 
	'reply'  =>  "Svar",
	'more' => 'Mere',
	'comments' => 'Kommentarer',
	'import' => 'Importer',
	'export' => 'Eksporter',
	'untitled' => 'Untitled',
	'help' => 'Hjælp',
	'send' => 'Send',
	'post' => 'Post',
	'submit' => 'Send',
	'site' => 'Side',
	
	'up'  =>  "Op", 
	'down'  =>  "Ned", 
	'top'  =>  "Top",
	'bottom'  =>  "Bund",
	
	'invite'  =>  "Inviter",
	
	'resetpassword'  =>  "Nulstil kodeord", 
	'makeadmin'  =>  "Gør til administrator", 
	'removeadmin' => "Fjern admin",
	
	'option:yes'  =>  "Ja", 
	'option:no'  =>  "Nej",
	
	'unknown'  =>  "Ukendt",
	
	'active'  =>  "Aktiv", 
	'total'  =>  "Total",
	
	'learnmore'  =>  "Klik her for at lære mere.", 
	
	'content'  =>  "indhold", 
	'content:latest'  =>  "Seneste aktivitet", 
	'content:latest:blurb'  =>  "Alternativt, klik her for at se det seneste indhold fra hele siden.", 
	
	'link:text'  =>  "se link",
	
	'enableall' => 'Aktiver alle',
	'disableall' => 'Deaktiver alle',
	
	/**
	* Generic questions
	*/
	
	'question:areyousure' => 'Er du sikker?',
	
	/**
	* Generic data words
	*/
	
	'title'  =>  "Titel", 
	'description'  =>  "Beskrivelse", 
	'tags'  =>  "Tags", 
	'spotlight'  =>  "Spotlight", 
	'all'  =>  "Alle",
	
	'by'  =>  "af", 
	
	'annotations'  =>  "Notater", 
	'relationships'  =>  "Forhold", 
	'metadata'  =>  "Metadata", 
	
	/**
	* Input / output strings
	*/
	
	'deleteconfirm'  =>  "Er du sikker på, at du vil slette dette?", 
	'fileexists'  =>  "En fil er allerede blevet uploadet. Vælg den herunder for at erstatte den:", 
	
	/**
	* User add
	*/
	
	'useradd:subject' => 'Brugerkonto oprettet',
	'useradd:body' => '
%s,

En brugerkonto er blevet oprettet til dig på %s. For at logge ind, besøg:

%s

Du kan logge ind med disse bruger oplysninger:

Brugernavn: %s
Adgangskode: %s

Vi anbefaler, at du ændrer din adgangskode, når du har logget ind.
',
	
	/**
	* System messages
	**/
	
	'systemmessages:dismiss'  =>  "klik for at lukke",
	
	/**
	* Import / export
	*/
	
	'importsuccess'  =>  "Data import lykkedes", 
	'importfail'  =>  "OpenDD data import mislykkedes",
	
	/**
	* Time
	*/
	
	'friendlytime:justnow' => "lige nu", 
	'friendlytime:minutes' => "%s minutter siden", 
	'friendlytime:minutes:singular' => "et minut siden", 
	'friendlytime:hours' => "%s timer siden", 
	'friendlytime:hours:singular' => "en time siden", 
	'friendlytime:days' => "%s dage siden", 
	'friendlytime:days:singular' => "i går",
	'friendlytime:date_format' => 'j. F Y | H:i',
	
	'date:month:01' => 'Januar %s',
	'date:month:02' => 'Februar %s',
	'date:month:03' => 'Marts %s',
	'date:month:04' => 'April %s',
	'date:month:05' => 'Maj %s',
	'date:month:06' => 'Juni %s',
	'date:month:07' => 'Juli %s',
	'date:month:08' => 'August %s',
	'date:month:09' => 'September %s',
	'date:month:10' => 'Oktober %s',
	'date:month:11' => 'November %s',
	'date:month:12' => 'December %s',

	
	/**
	* Installation and system settings
	*/
	
	'installation:error:htaccess'  =>  "Elgg skal bruge en fil kaldet .htaccess i rodfolderen af installationen. Vi prøvede at lave den for dig, men Elgg har ikke tilladelse til at skrive til den folder.
	
Det er nemt at lave denne fil. Kopier indholdet af følgende tekstboks ind i et tekstredigerings program og gem det som .htacess

", 
	'installation:error:settings'  =>  "Elgg kunne ikke finde settings filen. De fleste af Elgg's indstillinger vil blive klaret for dig, men vi har brug for, at du giver os dine database detaljer. For at gøre dette skal du:

1. Omdøbe engine/settings.example.php til settings.php i din Elgg installation.

2. Åbne filen i et tekstredigerings program og indtaste dine MySQL database detaljer. Kender du dem ikke, så spørg om hjælp hos din systemadminstrator eller teknisk support
	
Alternativt kan du indtaste dine database detaljer nedenfor og vi vil prøve at gøre det for dig...",
	
	'installation:error:db:title' => "Fejl i database indstillinger",
	'installation:error:db:text' => "Kontroller dine database indstillinger igen da Elgg ikke kunne forbinde og tilgå databasen.",
	'installation:error:configuration' => "Når du har rettet problemer i indstillingerne reload og prøv igen.", 
	
	'installation'  =>  "Installation", 
	'installation:success'  =>  "Elggs database blev installeret.", 
	'installation:configuration:success'  =>  "Dine første konfigurationsindstillinger er blevet gemt. Registrer nu din første bruger, der vil blive din første system administrator.",
	
	'installation:settings'  =>  "System indstillinger", 
	'installation:settings:description'  =>  "Nu hvor Elgg databasen er blevet installeret, er du nødt til at indtaste lidt mere information for at få din side helt op at køre. Vi har forsøgt at gætte så meget som muligt, men <b>du bør checke disse detaljer!</b>",
	
	'installation:settings:dbwizard:prompt'  =>  "Indtast dine database indstillinger nedenfor og tryk gem:", 
	'installation:settings:dbwizard:label:user'  =>  "Database bruger", 
	'installation:settings:dbwizard:label:pass'  =>  "Database adgangskode", 
	'installation:settings:dbwizard:label:dbname'  =>  "Elgg database", 
	'installation:settings:dbwizard:label:host'  =>  "Database hostname (som regel 'localhost')", 
	'installation:settings:dbwizard:label:prefix'  =>  "Database tabel præfiks (som regel 'elgg')",
	
	'installation:settings:dbwizard:savefail'  =>  "Vi var ikke i stand til at gemme den nye settings.php. Gem venligst den følgende fil som engine/settings.php med et tekstredigerings program.", 
	
	'installation:sitename'  =>  "Din sides navn (f.eks. \"Min sociale netværks side\"):", 
	'installation:sitedescription'  =>  "Kort beskrivelse af din side (valgfrit)", 
	'installation:wwwroot'  =>  "Sidens URL, efterfulgt af en skråstreg:", 
	'installation:path'  =>  "Den fulde sti til din sides rod på din disk, efterfulgt af en skråstreg:", 
	'installation:dataroot'  =>  "Den fulde sti til den folder, hvor tilføjede filer skal lagres, efterfulgt af en skråstreg:", 
	'installation:dataroot:warning'  =>  "Du skal oprette denne folder manuelt. Den bør være placeret i et anden bibliotek end din Elgg installation.",
	'installation:sitepermissions' => "Standard adgangstilladelser:", 
	'installation:language'  =>  "Standardsproget for din side:", 
	'installation:debug'  =>  "Debug mode giver ekstra information, der kan bruges til at diagnosticere fejl, men den gør dit system langsommere og bør kun bruges, hvis du har problemer.",	  
	'installation:debug:none' => 'Fravælg debug mode (anbefalet)',
	'installation:debug:error' => 'Vis kun kritiske fejl',
	'installation:debug:warning' => 'Vis fejl og advarsler',
	'installation:debug:notice' => 'Log alle fejl, advarsler og bemærkninger',	  
	'installation:httpslogin' => "Aktiver dette hvis du vil have brugeres log ind håndteret af HTTPS. Du skal have https aktiveret på din server for at dette fungerer.",
	'installation:httpslogin:label' => "Aktiver HTTPS log ind",
	'installation:view' => "Vælg det udseende der skal bruges som standard for din side eller lad være med at vælge for at bruge standard udseende (er du i tvivl, så brug standard):",
	
	'installation:siteemail'  =>  "Sidens email adresse (bruges når der sendes system emails)",
	
	'installation:disableapi'  =>  "RESTful API er en fleksibel grænseflade, der kan udvides og tillader programmer at tilgå visse Elgg funktioner udefra.", 
	'installation:disableapi:label'  =>  "Slå RESTful API til",
	
	'installation:allow_user_default_access:description' => "Hvis tilvalgt, vil individuelle brugere have tilladelse til at definere deres eget adgangsniveau, som kan overskrive systemets standard adgangsniveau.",
	'installation:allow_user_default_access:label' => "Tillad bruger standard adgang.",
	
	'installation:simplecache:description' => "Simple cache øger præstationen ved at cache statisk indhold inklusive nogle CSS og JavaScript filer. Normalt vil du have dette slået til.",
	'installation:simplecache:label' => "Brug simple cache (anbefalet)",
	
	'installation:viewpathcache:description' => "View filepath cache nedsætter load tiden på plugins ved at cache placeringen af deres  visninger.",
	'installation:viewpathcache:label' => "Brug view filepath cache (anbefalet)",
	
	'upgrading'  =>  "Opgraderer...", 
	'upgrade:db'  =>  "Din database blev opgraderet.", 
	'upgrade:core'  =>  "Din Elgg installation blev opgraderet",
	
	/**
	* Welcome
	*/ 
	
	'welcome'  =>  "Velkommen",
	'welcome:user' => 'Velkommen %s', 
	'welcome_message'  =>  "Velkommen til denne Elgg installation.",
	
	/**
	* Emails
	*/ 
	
	'email:settings'  =>  "Email", 
	'email:address:label'  =>  "Din email adresse",
	
	'email:save:success'  =>  "Ny email adresse gemt, verifikation afsendt.", 
	'email:save:fail'  =>  "Din nye email adresse kunne ikke gemmes.", 
	
	'friend:newfriend:subject'  =>  "%s har gjort dig til ven!", 
	'friend:newfriend:body'  =>  "%s har gjort dig til ven!
	
For at se vennens personlige profil, klik her;

%s

Du kan ikke besvare via denne mail.",


	
	'email:resetpassword:subject'  =>  "Adgangskode ændret!", 
	'email:resetpassword:body'  =>  "Hej %s,
		
Din adgangskode er blevet ændret til: %s", 

	
	'email:resetreq:subject'  =>  "Anmodning om ny adgangskode?", 
	'email:resetreq:body'  =>  "Hej %s,
		
En person (fra IP adressen %s) har bedt om en ny adgangskode til sin konto.
	
Hvis det var dig, der bad om det så klik på linket nedenfor - ellers ignorer venligst denne email.
	
%s
",
	
	/**
	* user default access
	*/
	
	'default_access:settings' => "Dit standard adgangsniveau",
	'default_access:label' => "Standard adgang",
	'user:default_access:success' => "Dit nye standard adgangsniveau er gemt.",
	'user:default_access:failure' => "Dit nye standard adgangsniveau kunne ikke gemmes.",
	
	/**
	* XML-RPC
	*/	
	'xmlrpc:noinputdata'  =>  "Ingen input data",
	
	/**
	* Comments
	*/
	
	'comments:count'  =>  "%s kommentarer",
	
	'riveraction:annotation:generic_comment'  =>  "%s har kommenteret %s",
	
	'generic_comments:add'  =>  "Tilføj kommentar", 
	'generic_comments:text'  =>  "Kommentér", 
	'generic_comment:posted'  =>  "Din kommentar er blevet tilføjet.", 
	'generic_comment:deleted'  =>  "Din kommentar er blevet slettet.", 
	'generic_comment:blank'  =>  "Beklager, men du er nødt til at skrive noget i din kommentar for, at vi kan gemme den.", 
	'generic_comment:notfound'  =>  "Beklager, vi kunne ikke finde det specifikke objekt.", 
	'generic_comment:notdeleted'  =>  "Beklager, vi kunne ikke slette denne kommentar.", 
	'generic_comment:failure'  =>  "En uforudset fejl opstop ved tilføjelsen af din kommentar. Prøv venligst igen.", 
	
	'generic_comment:email:subject'  =>  "Der er en ny kommentar!", 
	'generic_comment:email:body'  =>  "Der er en ny kommentar på din \"%s\" fra %s. Der står:
	
		
%s


Klik her for at svare eller se det oprindelige emne:

%s

Klik her for at se %s's profil:

%s

Du kan ikke svare via denne mail.",
	
	/**
	* Entities
	*/	
	'entity:default:strapline'  =>  "Oprettet %s af %s", 
	'entity:default:missingsupport:popup'  =>  "Denne enhed kan ikke vises korrekt. Dette kan være fordi det kræver understøttelse fra et plugin, der ikke længere er installeret.",
	
	'entity:delete:success'  =>  "Enheden %s er blevet slettet", 
	'entity:delete:fail'  =>  "Enheden %s kunne ikke slettes", 
	
	/**
	* Action gatekeeper
	*/
	
	'actiongatekeeper:missingfields'  =>  "Form mangler __token eller __ts felter", 
	'actiongatekeeper:tokeninvalid'  =>  "Vi stødte på en fejl (token mismatch). Det betyder sikkert at siden du brugte er udløbet. Prøv venligst igen.", 
	'actiongatekeeper:timeerror'  =>  "Siden du brugte er udløbet. Genopfrisk siden og prøv igen.", 
	'actiongatekeeper:pluginprevents'  =>  "En forlængelse har forhindret denne form i at blive sendt.", 
	
	/**
	* Word blacklists
	*/	
	'word:blacklist'  =>  "og, den, det, så, men hun, han, hendes, hans, en, et, ikke, også, om, nu, dermed, således, til, stadig, ligesom, derimod, derfor, omvendt, tværtimod, hellere, følge, yderligere, alligevel, imens, derefter, denne, dette, synes, hvem, hvad, hvor, hvornår, hvordan, hvorfor, hvorledes, hvormed",
	
	/**
	* Tag labels
	*/
	
	'tag_names:tags' => 'Tags',	  
	
	/**
	* Languages according to ISO 639-1
	*/	
	'aa'  =>  "Afar", 
	'ab'  =>  "Abkhasisk", 
	'af'  =>  "Afrikaans", 
	'am'  =>  "Amharisk", 
	'ar'  =>  "Arabisk", 
	'as'  =>  "Assamesisk", 
	'ay'  =>  "Aymaransk", 
	'az'  =>  "Azerbadjansk", 
	'ba'  =>  "Bashkir", 
	'be'  =>  "Hviderussisk", 
	'bg'  =>  "Bulgarsk", 
	'bh'  =>  "Bihari", 
	'bi'  =>  "Bislama", 
	'bn'  =>  "Bengalsk", 
	'bo'  =>  "Tibetansk", 
	'br'  =>  "Breton", 
	'ca'  =>  "Catalansk", 
	'co'  =>  "Corsicansk", 
	'cs'  =>  "Tjekkisk", 
	'cy'  =>  "Walisisk", 
	'da'  =>  "Dansk", 
	'de'  =>  "Tysk", 
	'dz'  =>  "Bhutani", 
	'el'  =>  "Græsk", 
	'en'  =>  "Engelsk", 
	'eo'  =>  "Esperanto", 
	'es'  =>  "Spansk", 
	'et'  =>  "Estisk", 
	'eu'  =>  "Baskisk", 
	'fa'  =>  "Persisk", 
	'fi'  =>  "Finsk", 
	'fj'  =>  "Fiji", 
	'fo'  =>  "Faeroese", 
	'fr'  =>  "Fransk", 
	'fy'  =>  "Frisian", 
	'ga'  =>  "Irsk", 
	'gd'  =>  "Skotsk / Gælisk", 
	'gl'  =>  "Galician", 
	'gn'  =>  "Guaranisk", 
	'gu'  =>  "Gujarati", 
	'he'  =>  "Hebraisk", 
	'ha'  =>  "Hausa", 
	'hi'  =>  "Hindi", 
	'hr'  =>  "Croatisk", 
	'hu'  =>  "Ungarsk", 
	'hy'  =>  "Armensk", 
	'ia'  =>  "Interlingua", 
	'id'  =>  "Indonesisk", 
	'ie'  =>  "Interlingue", 
	'ik'  =>  "Inupiak", 
	'is'  =>  "Islandsk", 
	'it'  =>  "Italiensk", 
	'iu'  =>  "Inuktitut", 
	'iw'  =>  "Hebraisk (forældet)", 
	'ja'  =>  "Japansk", 
	'ji'  =>  "Yiddish (obsolete)", 
	'jw'  =>  "Javanesisk", 
	'ka'  =>  "Georgisk", 
	'kk'  =>  "Kazakh", 
	'kl'  =>  "Grønlandsk", 
	'km'  =>  "Khmer", 
	'kn'  =>  "Kannada", 
	'ko'  =>  "Koreansk", 
	'ks'  =>  "Kashmiri", 
	'ku'  =>  "Kurdisk", 
	'ky'  =>  "Kirghizisk", 
	'la'  =>  "Latin", 
	'ln'  =>  "Lingala", 
	'lo'  =>  "Laothian", 
	'lt'  =>  "Lithauisk", 
	'lv'  =>  "Lettisk", 
	'mg'  =>  "Malagasy", 
	'mi'  =>  "Maori", 
	'mk'  =>  "Makedonsk", 
	'ml'  =>  "Malaysisk", 
	'mn'  =>  "Mongolsk", 
	'mo'  =>  "Moldovisk", 
	'mr'  =>  "Marathi", 
	'ms'  =>  "Malajisk", 
	'mt'  =>  "Maltesisk", 
	'my'  =>  "Burmesisk", 
	'na'  =>  "Naurisk", 
	'ne'  =>  "Nepalesisk", 
	'nl'  =>  "Hollandsk", 
	'no'  =>  "Norsk", 
	'oc'  =>  "Occitansk",
	'om'  =>  "Oromo", 
	'or'  =>  "Orija", 
	'pa'  =>  "Punjab", 
	'pl'  =>  "Polsk", 
	'ps'  =>  "Afghansk", 
	'pt'  =>  "Portuguisisk", 
	'qu'  =>  "Quechua", 
	'rm'  =>  "Retroromansk", 
	'rn'  =>  "Kirundi", 
	'ro'  =>  "Rumænsk", 
	'ru'  =>  "Russisk", 
	'rw'  =>  "Kinyarwanda", 
	'sa'  =>  "Sanskrit", 
	'sd'  =>  "Sindhi", 
	'sg'  =>  "Sangro", 
	'sh'  =>  "Serbokroatisk", 
	'si'  =>  "Singalesisk", 
	'sk'  =>  "Slovakisk", 
	'sl'  =>  "Slovensk", 
	'sm'  =>  "Samoansk",
	'sn'  =>  "Shona", 
	'so'  =>  "Somalisk", 
	'sq'  =>  "Albansk", 
	'sr'  =>  "Serbisk", 
	'ss'  =>  "Siswati", 
	'st'  =>  "Sesotho", 
	'su'  =>  "Sundanesisk", 
	'sv'  =>  "Svensk", 
	'sw'  =>  "Swahili", 
	'ta'  =>  "Tamilsk",
	'te'  =>  "Tegulu", 
	'tg'  =>  "Tajik", 
	'th'  =>  "Thai", 
	'ti'  =>  "Tigrinya", 
	'tk'  =>  "Turkmen", 
	'tl'  =>  "Tagalog", 
	'tn'  =>  "Setswana", 
	'to'  =>  "Tonga", 
	'tr'  =>  "Tyrkisk", 
	'ts'  =>  "Tsonga",
	'tt'  =>  "Tatar", 
	'tw'  =>  "Twi", 
	'ug'  =>  "Uigur", 
	'uk'  =>  "Ukrainsk", 
	'ur'  =>  "Urdu", 
	'uz'  =>  "Uzbek", 
	'vi'  =>  "Vietnamesisk", 
	'vo'  =>  "Volapuk", 
	'wo'  =>  "Wolof", 
	'xh'  =>  "Xhosa", 
	//'yi'  =>  "Yiddish",
	"yi"  => "Yiddish", 
	'yo'  =>  "Yoruba", 
	'za'  =>  "Zuang", 
	'zh'  =>  "Kinesisk", 
	'zu'  =>  "Zulu"	
);

add_translation("da",$danish);

?>