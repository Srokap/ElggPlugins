<?php
	/**
	* river_thumbnails
	*
	* @author Patrick Loibl ORIGINAL: Pedro Prez
	* @link http://frapper.cc/
	* @copyright (c) frapper.cc & http://www.keetup.com/ 
	* @link http://frapper.cc/
	* @license GNU General Public License (GPL) version 2
	*/

	$preview_developer_key = $vars['entity']->preview_developer_key;
?>

<p>
	<?php 	
		echo elgg_echo('river_extended:preview:settings:apikey:label'); 
	?><br />
	<small>
	<?php
		$link_help_api =  "<a target=\"_blank\" href=\"http://www.thumbalizr.com/apitools.php\">here</a>";
		echo sprintf(elgg_echo('river_extended:preview:settings:apikey:help'),$link_help_api);
	?>
	</small>
	
	<?php 
		echo elgg_view('input/text', array(
			'internalname' => 'params[preview_developer_key]',
            'value' => $preview_developer_key
		));
	?>
</p>