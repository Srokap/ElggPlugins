<?php
	/**
	* river_thumbnails
	*
	* @author Patrick Loibl ORIGINAL: Pedro Prez
	* @link http://frapper.cc/
	* @copyright (c) frapper.cc & http://www.keetup.com/ 
	* @link http://frapper.cc/
	* @license GNU General Public License (GPL) version 2
	*/
	
	define('SHOW_PREVIEW_URL', 'http://api.thumbalizr.com/?url=%s&width=1280&api_key=%s&quality=100');
	define('REQUEST_PREVIEW_URL', 'http://api.thumbalizr.com/?url=%s&width=1280&api_key=%s&quality=100');
	define('EXISTS_PREVIEW_URL', 'http://api.thumbalizr.com/?url=%s&width=1280&api_key=%s&quality=100');
	
	class Preview {
		
			/*
			 *	devkey  	string (required)  	All requests to PageGlimpse service require a devkey. Sign-up and get your own devkey. 
			*/
			private $width;
			
			private $api_key;

			
			
			/*
			 * root  	string  	Indicates if the thumbnails for the domain root should be displayed. If set to "no", it will display the not found image, otherwise it will display the thumbnails for root domain page. Default value is "yes". 
			*/
			private $root;
			
			/*
			 *	nothumb  	string  	If the thumbnail for the website is not yet taken, it will be queued and the value of this parameter will be sent back. If this parameter is not set a PageGlimpse default image will be returned. Example of value: http://www.yoursite.com/nothumb.jpg 
			*/
			private $nothumb;
				
		
		//Construct	
			public function __construct($api_key){
				$this->width = '1280';
				$this->api_key = $api_key;
			}
			
			/*
			 * Get single thumbnail 
			*/	
			public function showPreview($url, $width = NULL, $root = NULL) {
				if (is_null($width)) {
					$width = '1000'; 
				}
				if (is_null($root)) {
					$root = $this->root; 
				}
				$url = sprintf(SHOW_PREVIEW_URL, $url, $this->api_key);
				/*if ($this->existsPreview($url)) {
					$url = sprintf(SHOW_PREVIEW_URL, $url, $this->api_key, $this->width, $this->root);
				} else {
					$this->requestPreview($url);
				}*/
				return $url;
			}
			
			/*
			 * Check if a thumbnail exists
			*/
			public function existsPreview($url, $width = NULL) {
				if (is_null($width)) {
					$width = '1000'; 
				}
				$url = sprintf(EXISTS_PREVIEW_URL, $url, $this->api_key);
				
				$ch = curl_init();
			    curl_setopt($ch, CURLOPT_URL, $url);
			    curl_setopt($ch, CURLOPT_POST,"GET");
		      	
		      	ob_start();
		      
			    curl_exec($ch);
			    curl_close($ch);
			    $cache = ob_get_contents();
			    ob_end_clean();
			    
			    if ($cache) {
					$cache = json_decode($cache);
					if (is_array($cache) && isset($cache[1]) && $cache[1] == 'yes') {
						return true;
					}
				}
				return false;
			}
			
			/*
			 * Use this method to add an url to the queue to be captured and generate thumbnails.
			*/
			public function requestPreview($url) {
				$url = sprintf(REQUEST_PREVIEW_URL, $url, $this->api_key);
				
				$ch = curl_init();
			    curl_setopt($ch, CURLOPT_URL, $url);
			    curl_setopt($ch, CURLOPT_POST,"GET");
		      	
		      	ob_start();
		      
			    curl_exec($ch);
			    curl_close($ch);
			    $cache = ob_get_contents();
			    ob_end_clean();
			    
			    if ($cache) {
					$cache = json_decode($cache);
					if (is_array($cache) && isset($cache[1]) && $cache[1] == 'success') {
						return true;
					}
				}
				return false;
			}
		
	}
		
?>