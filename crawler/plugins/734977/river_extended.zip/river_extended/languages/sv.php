<?php
	/**
	* river_extended
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	$swedish = array(
		'river_extended:admin' => 'River thumbnails Settings',		
		//Translation Here
		//Settings
		'river_extended:preview:settings:apikey:label' => 'Ange ditt thumbalizr API-nyckel',
		'river_extended:preview:settings:apikey:help' => 'Du kan f� en API-nyckel %s.',
	);
					
	add_translation("sv",$swedish);
?>