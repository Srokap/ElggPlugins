<?php
	/**
	* river_extended
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	$english = array(
		'river_extended:admin' => 'River thumbnails Einstellungen',		
		//Translation Here
		//Settings
		'river_extended:preview:settings:apikey:label' => 'Gib deinen thumbalizr API Key ein',
		'river_extended:preview:settings:apikey:help' => 'Den bekommst du hier %s.',
	);
					
	add_translation("en",$english);
?>