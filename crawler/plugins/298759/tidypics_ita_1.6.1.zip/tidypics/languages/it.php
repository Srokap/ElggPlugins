<?php

     /**
	 * Elgg Plugin language pack
	 * 
     * @Italian Language Pack
     * @Plugin: TidyPics
     * @version: 1.6.1
     * @Italian Support Group: http://comunita.elgg.com/
     * @translation by Lord55  <lord55@nobiltadeipari.com> 
     * @link http://www.nobilityofequals.com
     ****************************************/

	$italian = array(
		// hack for core bug
			'untitled' => "senza titolo",

		// Menu items and titles  ###Argomenti del menu e titoli###

			'image' => "Immagine",
			'images' => "Immagini",
			'caption' => "Sottotitolo",
			'photos' => "Immagine",
			'images:upload' => "Invia Immagini",
			'images:multiupload' => "Strumento Flash Multi Invio",
			'images:multiupload:todo' => "Scegli uno o più file da indivare.",
			'album' => "Album",
			'albums' => "Album",
			'album:slideshow' => "Vedi Slideshow",
			'album:yours' => "I tuoi Album",
			'album:yours:friends' => "Album dei tuoi Amici",
			'album:user' => "Album di %s",
			'album:friends' => "Album degli amici di %s",
			'album:all' => "Album di tutto il sito",
			'album:group' => "Album del Gruppo",
			'item:object:image' => "Immagini",
			'item:object:album' => "Album",
			'tidypics:uploading:images' => "Per favore aspetta. Immagini in invio.",
			'tidypics:enablephotos' => 'Abilita Album del Gruppo',
			'tidypics:editprops' => 'Modifica Proprietà dell\'Immagine',
			'tidypics:mostcommented' => 'Immagini più commentate',
			'tidypics:mostcommentedthismonth' => 'Le più commentate del Mese',
			'tidypics:mostcommentedtoday' => 'Le più commentate Oggi',
			'tidypics:mostviewed' => 'Immagini più viste',
			'tidypics:mostvieweddashboard' => 'Dashboard più viste',
			'tidypics:mostviewedthisyear' => 'Le più viste dell\'Anno',
			'tidypics:mostviewedthismonth' => 'Le più viste del Mese',
			'tidypics:mostviewedlastmonth' => 'Le più viste nel Mese scorso',
			'tidypics:mostviewedtoday' => 'Le più viste oggi',
			'tidypics:recentlyviewed' => 'Immagini viste di recente',
			'tidypics:recentlycommented' => 'Immagini commentate di recente',
			'tidypics:mostrecent' => 'Immagini più recenti',
			'tidypics:yourmostviewed' => 'Tue Immagini più viste',
			'tidypics:yourmostrecent' => 'Tue Immagini più recenti',
			'tidypics:friendmostviewed' => "Immagini più viste di %s",
			'tidypics:friendmostrecent' => "Immagini più recenti di %s",
			'tidypics:highestrated' => "Immagini più votate",
			'tidypics:views' => "Vista: %s",
			'tidypics:viewsbyowner' => "da %s utenti (escluso tu)",
			'tidypics:viewsbyothers' => "(%s da te)",
			'tidypics:administration' => 'Amministrazione Tidypics',
			'tidypics:stats' => 'Statistiche',

		//settings  ###settaggi###
			'tidypics:settings' => 'Settaggi',
			'tidypics:admin:instructions' => 'Questi sono i settaggi di base di Tidypics. Cambiali in base alle tue esigenze e poi clicca Salva.',
			'tidypics:settings:image_lib' => "Libreria Immagine",
			'tidypics:settings:thumbnail' => "Creatore di Miniature",
			'tidypics:settings:download_link' => "Mostra il link download",
			'tidypics:settings:tagging' => "Abilita il tagging delle Immagini",  
			'tidypics:settings:photo_ratings' => "Abilita la votazione Immagini (richiede il rate plugin di Miguel Montes o compatibile)",
			'tidypics:settings:exif' => "Mostra i dati EXIF",
			'tidypics:settings:view_count' => "Mostra contatore",
			'tidypics:settings:grp_perm_override' => "Permetti ai Membri del Gruppo il pieno accesso agli Album del Gruppo",
			'tidypics:settings:maxfilesize' => "Grandezza immagine massima in megabytes (MB):",
			'tidypics:settings:quota' => "Quota Utente/Gruppo (MB) - 0 corrisponde a  nessuna quota",
			'tidypics:settings:watermark' => "Inserisci il testo da far apparire nel watermark - ancora in beta",
			'tidypics:settings:im_path' => "Inserisci il percorso dei tuoi comandi ImageMagick (con il trailing slash)",
			'tidypics:settings:img_river_view' => "Quante voci nel river per ogni blocco di Immagini inviate",
			'tidypics:settings:album_river_view' => "Mostra la copertina dell'Album o un set di Immagini per il nuovo Album",
			'tidypics:settings:largesize' => "Grandezza immagine principale",
			'tidypics:settings:smallsize' => "Grnadezza immagine dell'Album",
			'tidypics:settings:thumbsize' => "Grandezza immagine in miniatura",
			'tidypics:settings:im_id' => "ID Immagine",
	
		//actions  ###azioni###

			'album:create' => "Crea nuovo Album",
			'album:add' => "Aggiungi Album",
			'album:addpix' => "Aggiungi Immagini nell'Album",
			'album:edit' => "Modifica Album",
			'album:delete' => "Cancella Album",

			'image:edit' => "Modifica Immagine",
			'image:delete' => "Cancella Immagine",
			'image:download' => "Scarica Immagine",

		//forms   ###schede###

			'album:title' => "Titolo",
			'album:desc' => "Descrizione",
			'album:tags' => "Tag",
			'album:cover' => "Metti l'Immagine come copertina dell'Album?",
			'tidypics:quota' => "Quota disponibile:",

		//views   ###viste###

			'image:total' => "Immagini nell'Album:",
			'image:by' => "Immagine aggiunta da",
			'album:by' => "Album creato da",
			'album:created:on' => "Creato",
			'image:none' => "Nessun Immagine è stata ancora aggiunta.",
			'image:back' => "Indietro",
			'image:next' => "Avanti",

		// tagging  ###tagging###
			'tidypics:taginstruct' => 'Seleziona l\'area che vuoi taggare',
			'tidypics:deltag_title' => 'Seleziona i tag da cancellare',
			'tidypics:finish_tagging' => 'Ferma il tagging',
			'tidypics:tagthisphoto' => 'Tagga questa Immagine',
			'tidypics:deletetag' => 'Cancella Tag all\'immagine',
			'tidypics:actiontag' => 'Tag',
			'tidypics:actiondelete' => 'Cancella',
			'tidypics:actioncancel' => 'Cancella',
			'tidypics:inthisphoto' => 'In questa Immagine',
			'tidypics:usertag' => "Immagini taggate con l'utente %s",
			'tidypics:phototagging:success' => 'Il Tag all\'immagine è stato aggiunto con successo',
			'tidypics:phototagging:error' => 'E\' accaduto un Errore inaspettato durante il tagging',
			'tidypics:deletetag:success' => 'I Tag selezionati sono stati cancellati con successo',
			
			'tidypics:tag:subject' => "Sei stato taggato in una Immagine",
			'tidypics:tag:body' => "Sei stato taggato in una immagine %s da %s.			
			
L'Immagine può essere vista qui: %s",


		//rss  ###rss##
			'tidypics:posted' => 'ha inviato una foto:',

		//widgets   ###widgets###

			'tidypics:widget:albums' => "Immagini Album",
			'tidypics:widget:album_descr' => "Vetrina dei tuoi Album",
			'tidypics:widget:num_albums' => "Numero degli Album da visualizzare",
			'tidypics:widget:latest' => "Ultime Immagini",
			'tidypics:widget:latest_descr' => "Visualizza le tue ultime immagini",
			'tidypics:widget:num_latest' => "Numero di immagini da visualizzare",
			'album:more' => "Vedi tutti gli Album",

		//  river  ###river###

			//images
			'image:river:created' => "%s ha aggiunto l'immagine %s all'album %s",
			'image:river:item' => "una immagine",
			'image:river:annotate' => "un commento sull'immagine",
			'image:river:tagged' => "è stato taggato nell'immagine",

			//albums
			'album:river:created' => "%s ha creato un nuovo Album",
			'album:river:group' => "nel gruppo",
			'album:river:item' => "un album",
			'album:river:annotate' => "un commento sull'Album",

		// notifications   ###notifiche###
			'tidypics:newalbum' => 'Nuovo Album',


		//  Status messages  ###Messaggi di stato###

			'tidypics:upl_success' => "Le tue Immagini sono state inviate con successo.",
			'image:saved' => "Le tue Immagini sono state salvate con successo.",
			'images:saved' => "Tutte le Immagini sono state salvate con successo.",
			'image:deleted' => "Le tue Immagini sono state cancellate con successo.",
			'image:delete:confirm' => "Sei sicuro di voler cancellare questa Immagine?",

			'images:edited' => "Le tue Immagini sono state aggiornate con successo.",
			'album:edited' => "Il tuo Album è stato aggiornato con successo.",
			'album:saved' => "Il tuo Album è stato salvato con successo.",
			'album:deleted' => "Il tuo Album è stato cancellato con successo.",
			'album:delete:confirm' => "Sei sicuro di voler cancellare questo Album?",
			'album:created' => "Il tuo nuovo Album è stato creato con successo.",
			'tidypics:settings:save:ok' => 'I settaggi del plugin Tidypics sono stati salvati con successo',

			'tidypics:upgrade:success' => 'L\'aggiornamento di Tidypics è avvenuto con successo',

		//Error messages  ###Errori###

			'tidypics:partialuploadfailure' => "Ci sono stati degli errori nell'inviare alcune delle Immagini (%s di %s immagini).",
			'tidypics:completeuploadfailure' => "Invio delle Immagini fallito.",
			'tidypics:exceedpostlimit' => "Immagini troppo grandi - prova ad inviarne di meno o immagini meno grandi.",
			'tidypics:noimages' => "Nessuna Immagine è stata selezionata.",
			'tidypics:image_mem' => "L'Immagine è troppo grande - troppi bytes",
			'tidypics:image_pixels' => "L'Immagine ha troppi pixel",
			'tidypics:unk_error' => "Errore di invio sconosciuto",
			'tidypics:save_error' => "Errore sconosciuto nel salvataggio dell'Immagine sul server",
			'tidypics:not_image' => "Questa non è un tipo di Immagine riconoscibile",
			'image:deletefailed' => "La tua Immagine non può essere cancellata in questo momento.",
			'image:downloadfailed' => "Scusaci; questa Immagine non è disponibile in questo momento.",
			'tidypics:nosettings' => "L'Amministratore di questo sito non ha impostato i settaggi dell'Album.",
			'tidypics:exceed_quota' => "Hai superato la quota impostata dall'Amministratore",
			'images:notedited' => "Non tute le Immagini sono state invite con successo",

			'album:none' => "Nessun Album è stato ancora creato.",
			'album:uploadfailed' => "Scusaci; non possiamo salvare il tuo Album.",
			'album:deletefailed' => "Il tuo Album non può essere cancellato in questo momento.",
			'album:blank' => "Per favore dai all'Album un titolo e una descrizione.",

			'tidypics:upgrade:failed' => "L'aggiornamento di Tidypics è fallito",
	);

	add_translation("it",$italian);
?>