.pftn_list_title { padding: 5px 10px; }
