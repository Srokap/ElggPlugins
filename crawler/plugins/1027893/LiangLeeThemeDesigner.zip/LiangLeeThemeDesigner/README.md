Liang Lee Theme Designer
========================

Style your default Elgg theme with Lee's Theme Designer,

Features:

1.) Hide of UnHide Topbar logo. <- Added by John Muller.

2.) Change Body Background Color.

3.) Change Topbar Color.

4.) Add Background Image to Topbar.

5.) Add Background Image to Header.

6.) Add Background Color to Header.

7.) Change Header Logo.

5.) Change Header Search Bar Color


Note: If you want to add any new feature please infom us we will add to next release if it is possible.