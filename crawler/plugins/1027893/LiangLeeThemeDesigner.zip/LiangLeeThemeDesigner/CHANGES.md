LiangLeeThemeDesinger 1.0.0 <- initial release

(July 11, 2012 from https://github.com/lianglee/LiangLeeThemeDesigner/tree/1.0.0)
