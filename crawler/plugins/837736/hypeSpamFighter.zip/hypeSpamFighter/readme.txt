hypeSpamFighter is part of the hypeJunction plugin bundle

============
www.hypeJunction.com
hypeJunction is here for you to connect, innovate, integrate, collaborate and indulge.
hypeJunction is a bundle of plugins that will help you kick start your Elgg-based social network and spice it up with cool features and functionalities.
============

PLUGIN DESCRIPTION
------------------
hypeSpamFighter is an attempt to create a bulletproof spam-free Elgg sites
This plugin employs some of the more popular spamfighting techniques and libraries, including:
-- reCaptcha
-- Akismet
-- Stop Forum Spam

Registration:
-- Added reCaptcha to the registration form
-- Added real-time AJAXed validation - username / email verification against existing Elgg usernames and emails, as well as the Stop Forum Spam database

Content Posting:
-- New users will need to enter reCaptcha for the first X posts they make on the site. If more than X failed attemps were made within 24 hours, users are banned
-- All content items will be checked against Akismet database for spam
-- Users can report spam
-- Admin Console at your-site.com/spam to manage suspected spam

REQUIREMENTS
------------
1) Elgg 1.8.3+
2) hypeFramework 1.8.5+

INTEGRATION / COMPATIBILITY
---------------------------
-- reCaptcha fields integrate with hypeFormBuilder

INSTALLATION
------------
1. Upload and enable hypeFramework
2. Place hypeSpamFighter below hypeFramework and enable
3. Enter your API keys and other configuration details in plugin settings

UPGRADING FROM PREVIOUS VERSION
-------------------------------
-- Disable all hype plugins, except hypeFramework
-- Disable hypeFramework
-- Backup your database and files
-- Remove all hype plugins from your server and upload the new version
-- Enable hypeFramework
-- Enable other hype plugins

USER GUIDE
----------

NOTES / WARNINGS
----------------


TODO
----


BUG REPORTS
-----------
Bugs and feature requests can be submitted at:
http://hypeJunction.com/trac

