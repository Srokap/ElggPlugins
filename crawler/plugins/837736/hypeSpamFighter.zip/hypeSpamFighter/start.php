<?php

/* hypeSpamFighter
 *
 * Spam Fighting Tools for Elgg
 * @package hypeJunction
 * @subpackage hypeSound
 *
 * @author Ismayil Khayredinov <ismayil.khayredinov@gmail.com>
 * @copyright Copyrigh (c) 2011, Ismayil Khayredinov
 */

elgg_register_event_handler('init', 'system', 'hj_spamfighter_init');

function hj_spamfighter_init() {
    $plugin = 'hypeSpamFighter';
    if (!elgg_is_active_plugin('hypeFramework')) {
        register_error(elgg_echo('hj:framework:disabled', array($plugin, $plugin)));
        disable_plugin($plugin);
    }

    $shortcuts = hj_framework_path_shortcuts($plugin);

    elgg_register_library('hj:spamfighter:base', $shortcuts['lib'] . 'spamfighter/base.php');
    elgg_register_library('hj:spamfighter:setup', $shortcuts['lib'] . 'spamfighter/setup.php');
    elgg_register_library('hj:spamfighter:recaptcha', $shortcuts['lib'] . 'vendors/recaptcha.php');

    elgg_load_library('hj:spamfighter:base');

    $css_url = elgg_get_simplecache_url('css', 'hj/spamfighter/base');
    elgg_register_css('hj.spamfighter.base', $css_url);

    $js_url = elgg_get_simplecache_url('js', 'hj/spamfighter/base');
    elgg_register_js('hj.spamfighter.base', $js_url);

    $js_user_url = elgg_get_simplecache_url('js', 'hj/spamfighter/user');
    elgg_register_js('hj.spamfighter.user', $js_user_url);

    $js_admin_url = elgg_get_simplecache_url('js', 'hj/spamfighter/admin');
    elgg_register_js('hj.spamfighter.admin', $js_admin_url);

    if (!elgg_get_plugin_setting('hj:spamfighter:setup')) {
        elgg_load_library('hj:spamfighter:setup');
        if (hj_spamfighter_setup())
            system_message('hypeSpamFighter was successfully configured');
    }

    elgg_register_action('spam/validate/username', $shortcuts['actions'] . 'hj/spamfighter/validate_username.php', 'public');
    elgg_register_action('spam/validate/email', $shortcuts['actions'] . 'hj/spamfighter/validate_email.php', 'public');
    elgg_register_action('spam/validate/captcha', $shortcuts['actions'] . 'hj/spamfighter/validate_captcha.php', 'public');
    elgg_register_action('spam/user_reportspam', $shortcuts['actions'] . 'hj/spamfighter/user_reportspam.php');
    elgg_register_action('spam/admin_reportham', $shortcuts['actions'] . 'hj/spamfighter/admin_reportham.php');
    elgg_register_action('spam/admin_deleteuser', $shortcuts['actions'] . 'hj/spamfighter/admin_deleteuser.php');
    elgg_register_action('spam/admin_banuser', $shortcuts['actions'] . 'hj/spamfighter/admin_banuser.php');
    elgg_register_action('spam/admin_deletespam', $shortcuts['actions'] . 'hj/spamfighter/admin_deletespam.php');
    elgg_register_action('spam/admin_bulk_action', $shortcuts['actions'] . 'hj/spamfighter/admin_bulk_action.php');

    elgg_extend_view('forms/register', 'hj/spamfighter/registration');

    $user = elgg_get_logged_in_user_entity();

    $user_entities = elgg_get_entities(array(
        'types' => 'object',
        'owner_guid' => $user->guid,
        'count' => true
            ));

    elgg_extend_view('input/captcha', 'input/recaptcha');
    if ($user_entities <= elgg_get_plugin_setting('recaptcha_validation_count', 'hypeSpamFighter')) {
        elgg_extend_view('input/categories', 'input/recaptcha');
    }

    // Add hypeFormBuilder Field Types and processing algorithms
    elgg_register_plugin_hook_handler('hj:formbuilder:fieldtypes', 'all', 'hj_spamfighter_recaptcha_input');
    elgg_register_plugin_hook_handler('hj:framework:form:process', 'all', 'hj_spamfighter_recaptcha_process');

    //elgg_register_plugin_hook_handler('register', 'user', 'hj_spamfighter_captcha_check', 1);
    elgg_register_event_handler('create', 'object', 'hj_spamfighter_captcha_content_check');
    elgg_register_event_handler('create', 'object', 'hj_spamfighter_akismet_check');
    elgg_register_event_handler('update', 'object', 'hj_spamfighter_akismet_check');

    elgg_register_plugin_hook_handler('register', 'menu:entity', 'hj_spamfighter_entity_menu');
    elgg_register_plugin_hook_handler('register', 'menu:spamfighter', 'hj_spamfighter_admin_entity_menu');

    elgg_register_page_handler('spam', 'hj_spamfighter_page_handler');
}

//function hj_spamfighter_captcha_check($event, $type, $return, $params) {
//    if ($event == 'register' && $type == 'user' && elgg_extract('user', $params)) {
//        $pub_key = elgg_get_plugin_setting('recaptcha_pub_key', 'hypeSpamFighter');
//        $priv_key = elgg_get_plugin_setting('recaptcha_priv_key', 'hypeSpamFighter');
//
//        if (!$pub_key || !$priv_key) {
//            return $return;
//        }
//
//        elgg_load_library('hj:spamfighter:recaptcha');
//
//        if (get_input("recaptcha_challenge_field")) {
//            $resp = recaptcha_check_answer($priv_key, $_SERVER["REMOTE_ADDR"], get_input("recaptcha_challenge_field"), get_input("recaptcha_response_field"));
//            if ($resp && !$resp->is_valid) {
//                elgg_make_sticky_form('register');
//                $user = elgg_extract('user', $params);
//                if (elgg_instanceof($user)) {
//                    // workaround for uservalidationbyemail bug, where disabled entity doesn't get deleted
//                    $user->disable("wrongcaptcha");
//                }
//                register_error(elgg_echo('hj:spamfighter:wrongcaptcha', array($resp->error)));
//                return false;
//            }
//        }
//    }
//    return $return;
//}

function hj_spamfighter_captcha_content_check($event, $type, $entity) {

    if (!$entity || $entity->getType !== 'object') {
        return true;
    }

    $pub_key = elgg_get_plugin_setting('recaptcha_pub_key', 'hypeSpamFighter');
    $priv_key = elgg_get_plugin_setting('recaptcha_priv_key', 'hypeSpamFighter');

    if (!$pub_key || !$priv_key) {
        return true;
    }

    elgg_load_library('hj:spamfighter:recaptcha');

    if (get_input("recaptcha_challenge_field")) {
        $resp = recaptcha_check_answer($priv_key, $_SERVER["REMOTE_ADDR"], get_input("recaptcha_challenge_field"), get_input("recaptcha_response_field"));
        if ($resp && !$resp->is_valid) {
            register_error(elgg_echo('hj:spamfighter:wrongcaptcha', array($resp->error)));
            $user = elgg_get_logged_in_user_entity();
            $first_fail = $user->first_captcha_fail;
            $last_fail = $user->last_captcha_fail;
            $fail_count = $user->captcha_fail_count;

            if (!$first_fail || ((time() - (int) $first_fail) >= 24 * 60 * 60)) {
                $user->first_captcha_fail = time();
                $user->captcha_fail_count = 1;
            } else {
                $user->last_captcha_fail = time();
                $user->captcha_fail_count = $fail_count + 1;

                if (($fail_count >= elgg_get_plugin_setting('recaptcha_fail_count', 'hypeSpamFighter'))
                        && ((int) $user->last_captcha_fail - (int) $user->first_captcha_fail < 24 * 60 * 60)) {
                    register_error(elgg_echo('hj:spamfighter:captchafailurelimitexceeded'), array(elgg_get_config('siteemail')));
                    $user->ban("captcha failure limit exceeded");
                }
            }

            return false;
        }
    }

    return true;
}

function hj_spamfighter_recaptcha_input($hook, $type, $return, $params) {
    $return[] = 'recaptcha';
    return $return;
}

function hj_spamfighter_recaptcha_process($hook, $type, $return, $params) {
    $event = elgg_extract('event', $params, 'create');
    $guid = elgg_extract('guid', $params, null);
    $entity = get_entity($guid);

    $pub_key = elgg_get_plugin_setting('recaptcha_pub_key', 'hypeSpamFighter');
    $priv_key = elgg_get_plugin_setting('recaptcha_priv_key', 'hypeSpamFighter');

    if (!$pub_key || !$priv_key) {
        return true;
    }
    elgg_load_library('hj:spamfighter:recaptcha');

    if (get_input("recaptcha_challenge_field")) {
        $resp = recaptcha_check_answer($priv_key, $_SERVER["REMOTE_ADDR"], get_input("recaptcha_challenge_field"), get_input("recaptcha_response_field"));
        if ($resp && !$resp->is_valid) {
            register_error(elgg_echo('hj:spamfighter:wrongcaptcha', array($resp->error)));
            if ($event == 'create') {
                $entity->delete();
            }
            return false;
        }
    }

    return true;
}

function hj_spamfighter_akismet_check($event, $type, $entity) {
    $key = elgg_get_plugin_setting('akismet_key', 'hypeSpamFighter');

    if (!$key) {
        return true;
    }

    if (!elgg_instanceof($entity, 'object') || $entity->spamreport || $entity->spamsafe) {
        return true;
    }

	$subtypes_to_check = get_registered_entity_types('object');

	$subtypes_to_check = elgg_trigger_plugin_hook('hj:spamfighter:spamcheck:subtypes', 'object', null, $subtypes_to_check);

	if (!in_array($entity->getSubtype(), $subtypes_to_check)) {
		return true;
	}

    if (elgg_is_admin_logged_in() || elgg_trigger_plugin_hook('hj:spamfighter:spamcheck:exempt', 'object', $entity, false)) {
        return true;
    }

    $user = elgg_get_logged_in_user_entity();

    $akismet = hj_spamfighter_prepare_akismet($user, $entity);
    if ($akismet && $akismet->isCommentSpam()) {
        $entity->original_access_id = $entity->access_id;
        $entity->access_id = ACCESS_PRIVATE;
        $entity->spamreport = true;
        $entity->spamreport_source = 'akismet';
        $entity->save();

        register_error(elgg_echo('hj:spamfighter:markedasspam'));

        $admins = elgg_get_admins();
        foreach ($admins as $admin) {
            $to[] = $admin->guid;
        }
        $from = elgg_get_config('site')->guid;
        $subject = sprintf(elgg_echo('hj:spamfighter:notification:suspectedspam'));

        $entity_url = elgg_view('output/url', array(
            'href' => $entity->getURL(),
            'is_action' => false
                ));
        $approve_url = elgg_view('output/url', array(
            'href' => 'spam',
            'is_action' => false
                ));

        $message = elgg_echo('hj:spamfighter:notification:suspectedspambody', array($entity->title . '<br />' . $entity->description, $entity_url, $approve_url));
        notify_user($to, $from, $subject, $message);
    }

    return true;
}

function hj_spamfighter_entity_menu($hook, $type, $return, $params) {

    if (!elgg_is_logged_in()) {
        return $return;
    }

    $entity = elgg_extract('entity', $params, false);

    if (!$entity) {
        return $return;
    }

	if (!elgg_instanceof($entity, 'object')) {
		return $return;
	}

	if (!in_array($entity->getSubtype(), get_registered_entity_types('object'))) {
		return $return;
	}

    elgg_load_js('hj.spamfighter.user');
    elgg_load_css('hj.spamfighter.base');

    if ($entity->spamreport) {
        $spam = array(
            'name' => 'suspectedspam',
            'title' => elgg_echo('hj:spamfighter:suspectedspam'),
            'text' => elgg_view_icon('suspectedspam'),
            'href' => false,
            'is_action' => false
        );
    } else if ($entity->spamsafe) {
        $spam = array(
            'name' => 'spamsafe',
            'title' => elgg_echo('hj:spamfighter:spamsafe'),
            'text' => elgg_view_icon('spamsafe'),
            'href' => false,
            'is_action' => false
        );
    } else {
        $spam = array(
            'name' => 'reportspam',
            'title' => elgg_echo('hj:spamfighter:reportspam'),
            'text' => elgg_view_icon('reportspam'),
            'href' => "action/spam/user_reportspam?e=$entity->guid",
            'is_action' => true,
            'class' => 'hj-spamfighter-report-spam'
        );
    }
    $return[] = ElggMenuItem::factory($spam);
    return $return;
}

function hj_spamfighter_page_handler($page) {
    if (!elgg_is_admin_logged_in() && !elgg_trigger_plugin_hook('hj:spamfighter:canapprovespam', 'all', null, false)) {
        return false;
    }

    $plugin = "hypeSpamFighter";
    $shortcuts = hj_framework_path_shortcuts($plugin);
    $pages = $shortcuts['pages'] . 'spam/';

    elgg_load_js('hj.spamfighter.admin');

    include "{$pages}spam.php";
    return true;
}

elgg_register_event_handler('login', 'user', 'hj_spamfighter_set_last_ip');

function hj_spamfighter_set_last_ip($event, $type, $user) {
    if ($user) {
        $user->last_ip = $_SERVER["REMOTE_ADDR"];
    }
    return true;
}