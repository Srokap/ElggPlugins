<?php

$body = elgg_view('hj/spamfighter/bulk_form', array(
	'id' => 'spamfighter-admin-form',
	'action' => 'action/spam/admin_bulk_action'
));

$title = elgg_echo('hj:spamfighter:page');

$content = elgg_view_layout('one_sidebar', array(
    'title' => $title,
    'content' => $body
    ));

echo elgg_view_page($title, $content);
