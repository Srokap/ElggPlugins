<?php

$entity_guids = get_input('entity_guids');
$error = FALSE;

if (!$entity_guids) {
    register_error(elgg_echo('hj:spamfighter:error:unknown_entity'));
    forward(REFERRER);
}

$access = access_get_show_hidden_status();
access_show_hidden_entities(TRUE);

foreach ($entity_guids as $guid) {
    $entity = get_entity($guid);
    if (!elgg_instanceof($entity)) {
        $error = TRUE;
        continue;
    }
    $user = $entity->getOwnerEntity();

    switch ($entity->spamreport_source) {
        case 'user' :
            $akismet = hj_spamfighter_prepare_akismet($user, $entity);
            $akismet->submitSpam();

            break;

        default :
            $error = TRUE;
            break;
    }

    if ($key = elgg_get_plugin_setting('sps_key', 'hypeSpamFighter')) {
        $check = new StopForumSpam($key);
        $is_spammer = $check->add(array('username' => $user->name, 'ip' => $user->last_ip, 'email' => $user->email));
    }
    $user->delete();
}

access_show_hidden_entities($access);

if (count($uentity_guids) == 1) {
    $message_txt = elgg_echo('hj:spamfighter:admin:deletemessage');
    $error_txt = elgg_echo('hj:spamfighter:admin:deleteerror');
} else {
    $message_txt = elgg_echo('hj:spamfighter:admin:deletemessage:multi');
    $error_txt = elgg_echo('hj:spamfighter:admin:deleteerror:multi');
}

if ($error) {
    register_error($error_txt);
} else {
    system_message($message_txt);
}

forward(REFERRER);


