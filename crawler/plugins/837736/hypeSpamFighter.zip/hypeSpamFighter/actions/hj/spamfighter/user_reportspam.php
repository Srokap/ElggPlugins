<?php

$guid = get_input('e');
$entity = get_entity($guid);

$entity->spamreport = true;
$entity->spamreport_source = 'user';

system_message(elgg_echo('hj:spamfighter:reportsubmitted'));

$admins = elgg_get_admins();
foreach ($admins as $admin) {
    $to[] = $admin->guid;
}
$from = elgg_get_config('site')->guid;
$subject = sprintf(elgg_echo('hj:spamfighter:notification:spamreport'));

$entity_url = elgg_view('output/url', array(
    'href' => $entity->getURL(),
    'is_action' => false
        ));
$approve_url = elgg_view('output/url', array(
    'href' => 'spam',
    'is_action' => false
        ));

$message = elgg_echo('hj:spamfighter:notification:spamreportbody', array(elgg_view_entity($entity), $entity_url, $approve_url));
notify_user($to, $from, $subject, $message);

forward(REFERER);