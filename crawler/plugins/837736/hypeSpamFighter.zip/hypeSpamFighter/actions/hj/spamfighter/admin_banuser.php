<?php

$entity_guids = get_input('entity_guids');
$error = FALSE;

if (!$entity_guids) {
    register_error(elgg_echo('hj:spamfighter:error:unknown_entity'));
    forward(REFERRER);
}

$access = access_get_show_hidden_status();
access_show_hidden_entities(TRUE);

foreach ($entity_guids as $guid) {
    $entity = get_entity($guid);
    if (!elgg_instanceof($entity)) {
        $error = TRUE;
        continue;
    }
    $user = $entity->getOwnerEntity();

    switch ($entity->spamreport_source) {
        case 'user' :
            $akismet = hj_spamfighter_prepare_akismet($user, $entity);
            $akismet->submitSpam();

            break;

        default :
            $error = TRUE;
            break;
    }

    $title = $entity->title;
    if (!$user->spamcount) {
        $user->spamcount = 1;
    } else {
        $user->spamcount = $user->spamcount + 1;
    }
    register_error(elgg_echo('hj:spamfighter:bannedadmindecision', array(elgg_get_site_entity()->email)));
    if ($key = elgg_get_plugin_setting('sps_key', 'hypeSpamFighter')) {
        $check = new StopForumSpam($key);
        $is_spammer = $check->add(array('username' => $user->name, 'ip' => $user->last_ip, 'email' => $user->email));
    }

    $entity->delete();
    $user->ban("admin decision");
}

access_show_hidden_entities($access);

if (count($uentity_guids) == 1) {
    $message_txt = elgg_echo('hj:spamfighter:admin:banmessage');
    $error_txt = elgg_echo('hj:spamfighter:admin:banerror');
} else {
    $message_txt = elgg_echo('hj:spamfighter:admin:banmessage:multi');
    $error_txt = elgg_echo('hj:spamfighter:admin:banerror:multi');
}

if ($error) {
    register_error($error_txt);
} else {
    system_message($message_txt);
}

forward(REFERRER);


