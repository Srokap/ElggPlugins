<?php

$email = get_input('email');
$email = trim($email);

if (!hj_spamfighter_validate_email_address($email)) {
    //register_error(elgg_echo('registration:emailnotvalid'));
} else if (get_user_by_email($email)) {
        register_error(elgg_echo('registration:dupeemail'));
} else if ($key = elgg_get_plugin_setting('sps_key', 'hypeSpamFighter')) {
    $check = new StopForumSpam($key);
    $is_spammer = $check->is_spammer(array('email' => $email, 'ip' => $_SERVER["REMOTE_ADDR"]));
    if ($is_spammer) {
        register_error(elgg_echo('hj:spamfighter:spam:email'));
    }
}

return true;