<?php

$entity_guids = get_input('entity_guids');
$error = FALSE;

if (!$entity_guids) {
    register_error(elgg_echo('hj:spamfighter:error:unknown_entity'));
    forward(REFERRER);
}

$access = access_get_show_hidden_status();
access_show_hidden_entities(TRUE);

foreach ($entity_guids as $guid) {
    $entity = get_entity($guid);
    if (!elgg_instanceof($entity)) {
        $error = TRUE;
        continue;
    }
    $user = $entity->getOwnerEntity();

    switch ($entity->spamreport_source) {
        case 'user' :
            $akismet = hj_spamfighter_prepare_akismet($user, $entity);
            $akismet->submitSpam();

            break;

        default :
            $error = TRUE;
            break;
    }

    $title = $entity->title;
    if (!$user->spamcount) {
        $user->spamcount = 1;
    } else {
        $user->spamcount = $user->spamcount + 1;
    }

    if ($user->spamcount >= elgg_get_plugin_setting('akismet_fail_count', 'hypeSpamFighter')) {
        $user->ban("number of spam posts exceeded");
        register_error(elgg_echo('hj:spamfighter:spamexceeded', array(elgg_get_site_entity()->email)));
        if ($key = elgg_get_plugin_setting('sps_key', 'hypeSpamFighter')) {
            $check = new StopForumSpam($key);
            $is_spammer = $check->add(array('username' => $user->name, 'ip' => $user->last_ip, 'email' => $user->email));
        }
    } else {
        $to = $user->guid;
        $from = elgg_get_config('site')->guid;
        $subject = elgg_echo('hj:spamfighter:notification:spam');
        $message = elgg_echo('hj:spamfighter:notification:spambody', array($title, $user->spamcount, elgg_get_plugin_setting('akismet_fail_count', 'hypeSpamFighter')));
        notify_user($to, $from, $subject, $message);
    }
    $entity->delete();
}

access_show_hidden_entities($access);

if (count($uentity_guids) == 1) {
    $message_txt = elgg_echo('hj:spamfighter:admin:spammessage');
    $error_txt = elgg_echo('hj:spamfighter:admin:spamerror');
} else {
    $message_txt = elgg_echo('hj:spamfighter:admin:spammessage:multi');
    $error_txt = elgg_echo('hj:spamfighter:admin:spamerror:multi');
}

if ($error) {
    register_error($error_txt);
} else {
    system_message($message_txt);
}

forward(REFERRER);