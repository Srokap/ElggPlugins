<?php
$action_type = get_input('action_type');
$valid_actions = array('admin_deletespam', 'admin_reportham', 'admin_banuser', 'admin_deleteuser');

if (!in_array($action_type, $valid_actions)) {
	forward(REFERRER);
}

$action_name = "spam/$action_type";

action($action_name);