<?php

$username = get_input('username');
$username = trim($username);

$user = get_user_by_username($username);

if (elgg_instanceof($user, 'user')) {
    register_error(elgg_echo('registration:userexists'));
} else if (!hj_spamfighter_validate_username($username)) {
    //register_error(elgg_echo('registration:usernamenotvalid'));
} else if ($key = elgg_get_plugin_setting('sps_key', 'hypeSpamFighter')) {
    $check = new StopForumSpam($key);
    $is_spammer = $check->is_spammer(array('username' => $username, 'ip' => $_SERVER["REMOTE_ADDR"]));
    if ($is_spammer) {
        register_error(elgg_echo('hj:spamfighter:spam:username'));
    }
}

return true;