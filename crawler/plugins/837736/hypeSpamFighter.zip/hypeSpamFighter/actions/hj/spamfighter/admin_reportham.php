<?php

$entity_guids = get_input('entity_guids');
$error = FALSE;

if (!$entity_guids) {
    register_error(elgg_echo('hj:spamfighter:error:unknown_entity'));
    forward(REFERRER);
}

$access = access_get_show_hidden_status();
access_show_hidden_entities(TRUE);

foreach ($entity_guids as $guid) {
    $entity = get_entity($guid);
    if (!elgg_instanceof($entity)) {
        $error = TRUE;
        continue;
    }
    $user = $entity->getOwnerEntity();

    switch ($entity->spamreport_source) {
        case 'akismet' :
            $akismet = hj_spamfighter_prepare_akismet($user, $entity);
            $akismet->submitHam();
            $entity->spamreport = false;
            $entity->spamreport_source = null;
            $entity->spamsafe = true;
            $entity->access_id = $entity->original_access_id;
            $entity->save();

            $to = $user->guid;
            $from = elgg_get_config('site')->guid;
            $subject = elgg_echo('hj:spamfighter:notification:ham');

            $entity_url = elgg_view('output/url', array(
                'href' => $entity->getURL(),
                'is_action' => false
                    ));

            $message = elgg_echo('hj:spamfighter:notification:hambody', array(elgg_view_entity($entity), $entity_url));
            notify_user($to, $from, $subject, $message);

            break;

        case 'user' :
            $entity->spamreport = false;
            $entity->spamreport_source = null;
            $entity->spamsafe = true;
            $entity->save();
            break;

        default :
            $error = TRUE;
            break;
    }
}

access_show_hidden_entities($access);

if (count($uentity_guids) == 1) {
    $message_txt = elgg_echo('hj:spamfighter:admin:hammessage');
    $error_txt = elgg_echo('hj:spamfighter:admin:hamerror');
} else {
    $message_txt = elgg_echo('hj:spamfighter:admin:hammessage:multi');
    $error_txt = elgg_echo('hj:spamfighter:admin:hamerror:multi');
}

if ($error) {
    register_error($error_txt);
} else {
    system_message($message_txt);
}

forward(REFERRER);