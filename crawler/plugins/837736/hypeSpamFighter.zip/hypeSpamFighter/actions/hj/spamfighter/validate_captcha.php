<?php

$pub_key = elgg_get_plugin_setting('recaptcha_pub_key', 'hypeSpamFighter');
$priv_key = elgg_get_plugin_setting('recaptcha_priv_key', 'hypeSpamFighter');

if (!$pub_key || !$priv_key) {
    return true;
}

elgg_load_library('hj:spamfighter:recaptcha');

if (get_input("recaptcha_challenge_field")) {
    $resp = recaptcha_check_answer($priv_key, $_SERVER["REMOTE_ADDR"], get_input("recaptcha_challenge_field"), get_input("recaptcha_response_field"));
    if ($resp && !$resp->is_valid) {
        elgg_make_sticky_form('register');
        $user = elgg_extract('user', $params);
        if (elgg_instanceof($user)) {
            // workaround for uservalidationbyemail bug, where disabled entity doesn't get deleted
            $user->disable("wrongcaptcha");
        }
        register_error(elgg_echo('hj:spamfighter:wrongcaptcha', array($resp->error)));
    }
}