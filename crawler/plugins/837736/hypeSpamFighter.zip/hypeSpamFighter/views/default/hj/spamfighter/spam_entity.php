<?php
elgg_load_js('hj.framework.ajax');
elgg_load_css('hj.spamfighter.base');

$entity = elgg_extract('entity', $vars);

$checkbox = elgg_view('input/checkbox', array(
	'name' => 'entity_guids[]',
	'value' => $entity->guid,
	'default' => false,
));

$created = elgg_echo('hj:spamfighter:admin:time-created', array(elgg_view_friendly_time($entity->time_created)));

$params = array('params' => array(
	'entity_guid' => $entity->guid,
	'full_view' => true,
	'fbox_x' => '900',
	'target' => ''
	)
);
$params = htmlentities(json_encode($params), ENT_QUOTES, 'UTF-8');

$preview = elgg_view('output/url', array(
    'text' => elgg_echo('hj:spamfighter:admin:preview'),
    'rel' => 'fancybox',
    'class' => 'hj-ajaxed-view',
    'href' => "action/framework/entities/view?e=$entity->guid",
	'data-options' => $params,
    'is_action' => true
));

$delete = elgg_view('output/url', array(
	'href' => "action/spam/admin_deletespam?entity_guids[]=$entity->guid",
	'text' => elgg_echo('hj:spamfighter:admin:deletespam'),
	'title' => elgg_echo('hj:spamfighter:admin:deletespam:title'),
	'class' => 'hj-spamfighter-admin-submit-single',
	'is_action' => true,
	'is_trusted' => true
));

$approve = elgg_view('output/url', array(
	'href' => "action/spam/admin_reportham?entity_guids[]=$entity->guid",
	'text' => elgg_echo('hj:spamfighter:admin:reportham'),
	'title' => elgg_echo('hj:spamfighter:admin:reportham:title'),
	'class' => 'hj-spamfighter-admin-submit-single',
	'is_action' => true,
	'is_trusted' => true
));

$ban_user = elgg_view('output/url', array(
	'href' => "action/spam/admin_banuser?entity_guids[]=$entity->guid",
	'text' => elgg_echo('hj:spamfighter:admin:banuser'),
	'title' => elgg_echo('hj:spamfighter:admin:banuser:title'),
	'class' => 'hj-spamfighter-admin-submit-single',
	'is_action' => true,
	'is_trusted' => true
));

$delete_user = elgg_view('output/url', array(
	'href' => "action/spam/admin_deleteuser?entity_guids[]=$entity->guid",
	'text' => elgg_echo('hj:spamfighter:admin:deleteuser'),
	'title' => elgg_echo('hj:spamfighter:admin:deleteuser:title'),
	'class' => 'hj-spamfighter-admin-submit-single',
	'is_action' => true,
	'is_trusted' => true
));

$type = elgg_echo("item:{$entity->getType()}:{$entity->getSubtype()}");
$description = elgg_get_excerpt($entity->description);
$block = <<<___END
	<label>{$type}: "$entity->title"</label>
	<div class="hj-spamfighter-spam-entity-details">
		$description
	</div>
___END;

$menu = <<<__END
	<ul class="elgg-menu elgg-menu-general elgg-menu-hz float-alt">
		<li>$preview</li>
                <li>$approve</li>
                <li>$delete</li>
                <li>$ban_user</li>
                <li>$delete_user</li>
	</ul>
__END;

echo elgg_view_image_block($checkbox, $block . $menu);
