<?php
elgg_load_js('hj.spamfighter.base');
elgg_load_css('hj.spamfighter.base');
