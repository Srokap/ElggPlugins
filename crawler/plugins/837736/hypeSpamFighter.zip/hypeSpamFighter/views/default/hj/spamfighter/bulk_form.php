<?php

$limit = get_input('limit', 10);
$offset = get_input('offset', 0);

$ia = elgg_set_ignore_access(TRUE);
$hidden_entities = access_get_show_hidden_status();
access_show_hidden_entities(TRUE);

$options = array(
	'metadata_names' => 'spamreport',
    'metadata_values' => true,
	'limit' => $limit,
	'offset' => $offset,
	'count' => TRUE
);
$count = elgg_get_entities_from_metadata($options);

if (!$count) {
	access_show_hidden_entities($hidden_entities);
	elgg_set_ignore_access($ia);

	echo autop(elgg_echo('hj:spamfighter:nospamreports'));
	return TRUE;
}

$options['count']  = FALSE;

$entities = elgg_get_entities_from_metadata($options);

access_show_hidden_entities($hidden_entities);
elgg_set_ignore_access($ia);

// setup pagination
$pagination = elgg_view('navigation/pagination',array(
	'baseurl' => 'spam',
	'offset' => $offset,
	'count' => $count,
	'limit' => $limit,
));

$bulk_actions_checkbox = '<label><input type="checkbox" id="spamfighter-checkall" />'
	. elgg_echo('hj-spamfighter:check_all') . '</label>';

$delete = elgg_view('output/url', array(
	'href' => 'action/spam/admin_deletespam',
	'text' => elgg_echo('hj:spamfighter:admin:deletespam'),
	'title' => elgg_echo('hj:spamfighter:admin:deletespam:title'),
	'class' => 'hj-spamfighter-admin-submit',
	'is_action' => true,
	'is_trusted' => true
));

$approve = elgg_view('output/url', array(
	'href' => 'action/spam/admin_reportham',
	'text' => elgg_echo('hj:spamfighter:admin:reportham'),
	'title' => elgg_echo('hj:spamfighter:admin:reportham:title'),
	'class' => 'hj-spamfighter-admin-submit',
	'is_action' => true,
	'is_trusted' => true
));

$ban_user = elgg_view('output/url', array(
	'href' => 'action/spam/admin_banuser',
	'text' => elgg_echo('hj:spamfighter:admin:banuser'),
	'title' => elgg_echo('hj:spamfighter:admin:banuser:title'),
	'class' => 'hj-spamfighter-admin-submit',
	'is_action' => true,
	'is_trusted' => true
));

$delete_user = elgg_view('output/url', array(
	'href' => 'action/spam/admin_deleteuser',
	'text' => elgg_echo('hj:spamfighter:admin:deleteuser'),
	'title' => elgg_echo('hj:spamfighter:admin:deleteuser:title'),
	'class' => 'hj-spamfighter-admin-submit',
	'is_action' => true,
	'is_trusted' => true
));

$bulk_actions = <<<___END
	<ul class="elgg-menu elgg-menu-general elgg-menu-hz float-alt">
		<li>$approve</li>
                <li>$delete</li>
                <li>$ban_user</li>
                <li>$delete_user</li>
	</ul>

	$bulk_actions_checkbox
___END;

if (is_array($entities) && count($entities) > 0) {
	$html = '<ul class="elgg-list elgg-list-distinct">';
	foreach ($entities as $entity) {
		$html .= "<li id=\"spam-entity-{$entity->guid}\" class=\"elgg-item hj-spamfighter-spam-entity-item\">";
		$html .= elgg_view('hj/spamfighter/spam_entity', array('entity' => $entity));
		$html .= '</li>';
	}
	$html .= '</ul>';
}

echo "<form id=\"{$vars['id']}\" action=\"{$vars['action']}\">";
echo <<<___END
<div class="elgg-module elgg-module-inline spamfighter-module">
	<div class="elgg-head">
		$bulk_actions
	</div>
	<div class="elgg-body">
		$html
	</div>
</div>
___END;

echo $pagination;
echo elgg_view('input/securitytoken');

echo "</form>";