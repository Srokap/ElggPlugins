<?php if (FALSE) : ?>
    <script type="text/javascript">
<?php endif; ?>
elgg.provide('hj.spamfighter.admin');

hj.spamfighter.admin.init = function() {

	$('#spamfighter-checkall')
        .unbind('click')
        .click(function() {
		var checked = $(this).attr('checked') == 'checked';
		$('#spamfighter-admin-form .elgg-body').find('input[type=checkbox]').attr('checked', checked);
	});

	$('.hj-spamfighter-admin-submit')
        .unbind('click')
        .click(function(event) {
		var $form = $('#spamfighter-admin-form');
		event.preventDefault();

		// check if there are selected users
		if ($('#spamfighter-admin-form .elgg-body').find('input[type=checkbox]:checked').length < 1) {
			return false;
		}

		// confirmation
		if (!confirm($(this).attr('title'))) {
			return false;
		}

		$form.attr('action', $(this).attr('href')).submit();
	});
};


elgg.register_hook_handler('init', 'system', hj.spamfighter.admin.init);
elgg.register_hook_handler('success', 'hj:framework:ajax', hj.spamfighter.admin.init, 500);

<?php if (FALSE) : ?></script><?php endif; ?>

