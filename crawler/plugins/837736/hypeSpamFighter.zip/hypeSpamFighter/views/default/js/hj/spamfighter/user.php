<?php if (FALSE) : ?>
    <script type="text/javascript">
<?php endif; ?>
elgg.provide('hj.spamfighter.user');

hj.spamfighter.user.init = function() {

    $('.hj-spamfighter-report-spam')
    .unbind('click')
    .bind('click', hj.spamfighter.user.reportspam);
}

hj.spamfighter.user.reportspam = function(event) {
    event.preventDefault();

    var href = $(this).attr('href');
    elgg.system_message(elgg.echo('hj:framework:processing'));
    elgg.action(href);
}

elgg.register_hook_handler('init', 'system', hj.spamfighter.user.init);
elgg.register_hook_handler('success', 'hj:framework:ajax', hj.spamfighter.user.init, 500);

<?php if (FALSE) : ?></script><?php endif; ?>

