<?php if (FALSE) : ?>
    <script type="text/javascript">
<?php endif; ?>
elgg.provide('hj.spamfighter.base');

hj.spamfighter.base.init = function() {

    var form = $('.elgg-form-register');

    form
    .unbind('submit')
    .bind('submit', hj.spamfighter.base.validateform);

    $('input[name="name"]', form)
    .addClass('incomplete')
    .unbind('blur')
    .bind('blur', hj.spamfighter.base.validatename);

    $('input[name="email"]', form)
    .addClass('incomplete')
    .unbind('blur')
    .bind('blur', hj.spamfighter.base.validateemail);

    $('input[name="username"]', form)
    .addClass('incomplete')
    .unbind('blur')
    .bind('blur', hj.spamfighter.base.validateusername);

    $('input[name="password"]', form)
    .addClass('incomplete')
    .unbind('blur')
    .bind('blur', hj.spamfighter.base.validatepassword);

    $('input[name="password2"]', form)
    .addClass('incomplete')
    .unbind('blur')
    .bind('blur', hj.spamfighter.base.validatepasswordmatch);

    $('input[name="recaptcha_response_field"]')
    .addClass('incomplete')
    .unbind('blur')
    .bind('blur', hj.spamfighter.base.validatecaptcha);
}

hj.spamfighter.base.validateform = function(event) {
    if ($(this).find('input.invalid').length || $(this).find('input.incomplete').length) {
        elgg.register_error(elgg.echo('hj:spamfighter:formincomplete'));
        event.preventDefault();
    }
}
hj.spamfighter.base.validatename = function(event) {
    $(this)
    .removeClass('incomplete');

    if ($(this).val() == '') {
        $(this)
        .removeClass('valid')
        .addClass('invalid');
        elgg.register_error(elgg.echo('hj:spamfighter:emptyname'));
    } else {
        $(this)
        .removeClass('invalid')
        .addClass('valid')
    }
}

hj.spamfighter.base.validateemail = function(event) {
    $(this)
    .removeClass('incomplete');

    var val = $(this).val();
    if (!val.length || val.search('@') <= 0) {
        $(this)
        .removeClass('valid')
        .addClass('invalid');
        elgg.register_error(elgg.echo('registration:emailnotvalid'));
    } else {
        $(this)
        .removeClass('invalid')
        .removeClass('valid')
        .addClass('hj-input-processing');

        var input = $(this);

        elgg.action('action/spam/validate/email', {
            data : {
                email : val
            },
            success : function(data) {
                if (data.status >= 0) {
                    input
                    .removeClass('invalid')
                    .addClass('valid')
                    .removeClass('hj-input-processing');
                } else {
                    input
                    .removeClass('valid')
                    .addClass('invalid')
                    .removeClass('hj-input-processing');

                }

            }
        });

    }
}
hj.spamfighter.base.validateusername = function(event) {
    $(this)
    .removeClass('incomplete');

    var val = $(this).val();
    if (val.length <= 4) {
        $(this)
        .removeClass('valid')
        .addClass('invalid');
        elgg.register_error(elgg.echo('hj:spamfighter:usernametooshort'));
    } else {
        $(this)
        .removeClass('invalid')
        .removeClass('valid')
        .addClass('hj-input-processing');

        var input = $(this);

        elgg.action('action/spam/validate/username', {
            data : {
                username : val
            },
            success : function(data) {
                if (data.status >= 0) {
                    input
                    .removeClass('invalid')
                    .addClass('valid')
                    .removeClass('hj-input-processing');
                } else {
                    input
                    .removeClass('valid')
                    .addClass('invalid')
                    .removeClass('hj-input-processing');

                }

            }
        });

    }

}


hj.spamfighter.base.validatepassword = function(event) {
    $(this)
    .removeClass('incomplete');

    var val = $(this).val();
    if (val.length < 6) {
        $(this)
        .removeClass('valid')
        .addClass('invalid');
        elgg.register_error(elgg.echo('hj:spamfighter:passwordtooshort'));
    } else {
        elgg.system_message(elgg.echo('hj:spamfighter:passwordstrength') + elgg.echo(testPassword(val)));
        $(this)
        .removeClass('invalid')
        .addClass('valid');
    }
}

hj.spamfighter.base.validatepasswordmatch = function(event) {
    $(this)
    .removeClass('incomplete');

    var val = $(this).val();
    var pass = $(this).parents('form').find('input[name="password"]').val();

    if (val.length < 6 || val != pass) {
        $(this)
        .removeClass('valid')
        .addClass('invalid');
        elgg.register_error(elgg.echo('hj:spamfighter:passwordmismatch'));
    } else {
        $(this)
        .removeClass('invalid')
        .addClass('valid');
    }
}

hj.spamfighter.base.validatecaptcha = function(event) {
    $(this)
    .removeClass('incomplete');

    var val = $(this).val();
    var val2 = $(this).parents('form').find('input[name="recaptcha_challenge_field"]').val();
    if (!val.length) {
        $(this)
        .removeClass('valid')
        .addClass('invalid');
        elgg.register_error(elgg.echo('hj:spamfighter:emptycaptcha'));
    } else {
        $(this)
        .removeClass('invalid')
        .removeClass('valid')
        .addClass('hj-input-processing');

        var input = $(this);

        elgg.action('action/spam/validate/captcha', {
            data : {
                recaptcha_response_field : val,
                recaptcha_challenge_field : val2
            },
            success : function(data) {
                if (data.status >= 0) {
                    input
                    .removeClass('invalid')
                    .addClass('valid')
                    .removeClass('hj-input-processing');
                } else {
                    input
                    .removeClass('valid')
                    .addClass('invalid')
                    .removeClass('hj-input-processing');

                }

            }
        });

    }

}


elgg.register_hook_handler('init', 'system', hj.spamfighter.base.init);
//elgg.register_hook_handler('success', 'hj:framework:ajax', hj.spamfighter.base.init, 500);



//Created: 20060120
//Author:  Steve Moitozo <god at zilla dot us> -- geekwisdom.com
//Description: This is a quick and dirty password quality meter
//		 written in JavaScript so that the password does
//		 not pass over the network.
//License: MIT License (see below)
//Modified: 20060620 - added MIT License
//Modified: 20061111 - corrected regex for letters and numbers
//                     Thanks to Zack Smith -- zacksmithdesign.com
//---------------------------------------------------------------
//Copyright (c) 2006 Steve Moitozo <god at zilla dot us>
//
//Permission is hereby granted, free of charge, to any person
//obtaining a copy of this software and associated documentation
//files (the "Software"), to deal in the Software without
//restriction, including without limitation the rights to use,
//copy, modify, merge, publish, distribute, sublicense, and/or
//sell copies of the Software, and to permit persons to whom the
//Software is furnished to do so, subject to the following
//conditions:
//
//   The above copyright notice and this permission notice shall
//be included in all copies or substantial portions of the
//Software.
//
//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
//KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
//AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
//HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
//WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
//FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
//OR OTHER DEALINGS IN THE SOFTWARE.
//---------------------------------------------------------------

function testPassword(passwd)
{
    var intScore   = 0
    var strVerdict = "weak"
    var strLog     = ""

    // PASSWORD LENGTH
    if (passwd.length<5)                         // length 4 or less
    {
        intScore = (intScore+3)
        strLog   = strLog + "3 points for length (" + passwd.length + ")\n"
    }
    else if (passwd.length>4 && passwd.length<8) // length between 5 and 7
    {
        intScore = (intScore+6)
        strLog   = strLog + "6 points for length (" + passwd.length + ")\n"
    }
    else if (passwd.length>7 && passwd.length<16)// length between 8 and 15
    {
        intScore = (intScore+12)
        strLog   = strLog + "12 points for length (" + passwd.length + ")\n"
    }
    else if (passwd.length>15)                    // length 16 or more
    {
        intScore = (intScore+18)
        strLog   = strLog + "18 point for length (" + passwd.length + ")\n"
    }


    // LETTERS (Not exactly implemented as dictacted above because of my limited understanding of Regex)
    if (passwd.match(/[a-z]/))                              // [verified] at least one lower case letter
    {
        intScore = (intScore+1)
        strLog   = strLog + "1 point for at least one lower case char\n"
    }

    if (passwd.match(/[A-Z]/))                              // [verified] at least one upper case letter
    {
        intScore = (intScore+5)
        strLog   = strLog + "5 points for at least one upper case char\n"
    }

    // NUMBERS
    if (passwd.match(/\d+/))                                 // [verified] at least one number
    {
        intScore = (intScore+5)
        strLog   = strLog + "5 points for at least one number\n"
    }

    if (passwd.match(/(.*[0-9].*[0-9].*[0-9])/))             // [verified] at least three numbers
    {
        intScore = (intScore+5)
        strLog   = strLog + "5 points for at least three numbers\n"
    }


    // SPECIAL CHAR
    if (passwd.match(/.[!,@,#,$,%,^,&,*,?,_,~]/))            // [verified] at least one special character
    {
        intScore = (intScore+5)
        strLog   = strLog + "5 points for at least one special char\n"
    }

    // [verified] at least two special characters
    if (passwd.match(/(.*[!,@,#,$,%,^,&,*,?,_,~].*[!,@,#,$,%,^,&,*,?,_,~])/))
    {
        intScore = (intScore+5)
        strLog   = strLog + "5 points for at least two special chars\n"
    }


    // COMBOS
    if (passwd.match(/([a-z].*[A-Z])|([A-Z].*[a-z])/))        // [verified] both upper and lower case
    {
        intScore = (intScore+2)
        strLog   = strLog + "2 combo points for upper and lower letters\n"
    }

    if (passwd.match(/([a-zA-Z])/) && passwd.match(/([0-9])/)) // [verified] both letters and numbers
    {
        intScore = (intScore+2)
        strLog   = strLog + "2 combo points for letters and numbers\n"
    }

    // [verified] letters, numbers, and special characters
    if (passwd.match(/([a-zA-Z0-9].*[!,@,#,$,%,^,&,*,?,_,~])|([!,@,#,$,%,^,&,*,?,_,~].*[a-zA-Z0-9])/))
    {
        intScore = (intScore+2)
        strLog   = strLog + "2 combo points for letters, numbers and special chars\n"
    }


    if(intScore < 16)
    {
        strVerdict = "very weak"
    }
    else if (intScore > 15 && intScore < 25)
    {
        strVerdict = "weak"
    }
    else if (intScore > 24 && intScore < 35)
    {
        strVerdict = "mediocre"
    }
    else if (intScore > 34 && intScore < 45)
    {
        strVerdict = "strong"
    }
    else
    {
        strVerdict = "very strong"
    }

    return strVerdict;
}

<?php if (FALSE) : ?></script><?php endif; ?>
