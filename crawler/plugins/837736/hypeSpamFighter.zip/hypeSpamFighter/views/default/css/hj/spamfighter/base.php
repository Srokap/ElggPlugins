<?php
$base_url = elgg_get_site_url();
$graphics_url = $base_url . 'mod/hypeSpamFighter/graphics/';
?>

input.valid {
    background:#abdebe url(<?php echo $graphics_url ?>ok.png) no-repeat right;
    border-color:#008444;
}

input.invalid {
    background:#fbbcc8 url(<?php echo $graphics_url ?>notok.png) no-repeat right;
    border-color:#cc092f;
}

input.incomplete {
    background:white url(<?php echo $graphics_url ?>incomp.png) no-repeat right;
}

.elgg-icon-reportspam,
.elgg-icon-reportspam:hover {
    background:transparent url(<?php echo $graphics_url ?>reportspam.png) no-repeat center center;
}

.elgg-icon-spamsafe,
.elgg-icon-spamsafe:hover {
    background:transparent url(<?php echo $graphics_url ?>spamsafe.png) no-repeat center center;
}

.elgg-icon-suspectedspam,
.elgg-icon-suspectedspam:hover {
    background:transparent url(<?php echo $graphics_url ?>suspectedspam.png) no-repeat center center;
}

.spamfighter-module .elgg-head {
        padding:3px 20px;
        background:#f4f4f4;
        -moz-border-radius:10px;
        -webkit-border-radius:10px;
        border-radius:10px;
        margin-bottom:20px;
}

.elgg-menu-general > li {
	font-size:11px;
	margin:0 3px;
}