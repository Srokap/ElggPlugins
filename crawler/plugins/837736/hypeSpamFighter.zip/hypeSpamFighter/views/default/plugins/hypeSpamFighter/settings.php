<h3><a href="#">Spam Check (Akismet Support)</a></h3>
<div>
    <?php
    echo '<p>Include your Akistem API key if you would like the content to be checked for spam:</p>';

    echo elgg_view('input/text', array(
        'name' => 'params[akismet_key]',
        'value' => $vars['entity']->akismet_key,
    ));

    echo '<p>You can get your Akismet API Key <a href="https://akismet.com/signup/" target="_blank">here</a>.</p>';
    ?>
</div>


<h3><a href="#">reCaptcha Support</a></h3>
<div>
    <?php
    echo '<p>Include your reCaptcha Public and Private keys if you would like to add reCaptcha support:</p>';

    echo '<label>Public Key</label><br />';
    echo elgg_view('input/text', array(
        'name' => 'params[recaptcha_pub_key]',
        'value' => $vars['entity']->recaptcha_pub_key,
    ));

    echo '<label>Private Key</label><br />';
    echo elgg_view('input/text', array(
        'name' => 'params[recaptcha_priv_key]',
        'value' => $vars['entity']->recaptcha_priv_key,
    ));

    echo '<p>You can get your reCaptcha Key <a href="https://www.google.com/recaptcha/admin/create" target="_blank">here</a>.</p>';

    echo '<p>Please enter a number of posts that new users wil need to validate with reCaptcha:</p>';

    echo elgg_view('input/text', array(
        'name' => 'params[recaptcha_validation_count]',
        'value' => $vars['entity']->recaptcha_validation_count,
    ));

     echo '<p>Please enter a number of failed captcha attempts within 24 hours before the user is banned:</p>';

     echo elgg_view('input/text', array(
        'name' => 'params[recaptcha_fail_count]',
        'value' => $vars['entity']->recaptcha_fail_count,
    ));

    ?>
</div>



<h3><a href="#">Stop Forum Spam Support</a></h3>
<div>
    <?php
    echo '<p>Include your Stop Forum Spam key if you would like the check new user registrations against an SPS database of spammers:</p>';

    echo elgg_view('input/text', array(
        'name' => 'params[sps_key]',
        'value' => $vars['entity']->sps_key,
    ));

    echo '<p>You can get your SPS Key <a href="http://www.stopforumspam.com/forum/login" target="_blank">here</a>.</p>';

    echo '<p>Please enter a number of confirmed spam items before the user is banned:</p>';

     echo elgg_view('input/text', array(
        'name' => 'params[akismet_fail_count]',
        'value' => $vars['entity']->akismet_fail_count,
    ));
    ?>
</div>
