<?php

$pub_key = elgg_get_plugin_setting('recaptcha_pub_key', 'hypeSpamFighter');
$priv_key = elgg_get_plugin_setting('recaptcha_priv_key', 'hypeSpamFighter');

if (!$pub_key || !$priv_key) {
    return true;
}

//if (elgg_view_exists('input/captcha') && elgg_is_admin_logged_in()) {
//    register_error(elgg_echo('hj:spamfighter:anothercaptchaexists'));
//    return true;
//}

elgg_load_library('hj:spamfighter:recaptcha');

echo recaptcha_get_html($pub_key, null);
