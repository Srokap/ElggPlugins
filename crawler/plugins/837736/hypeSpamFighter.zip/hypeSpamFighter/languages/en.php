<?php

$english = array(
    'hj:spamfighter:reportspam' => 'Report Spam',
    'hj:spamfighter:spamsafe' => 'Spam Check Passed',
    'hj:spamfighter:suspectedspam' => 'Suspected Spam',
    'hj:spamfighter:page' => 'Let\'s fight some spam',

    'hj:spamfighter:wrongcaptcha' => 'reCaptcha did not match. Please try again (error reference: %s)',
    'hj:spamfighter:anothercaptchaexists' => 'Another plugin is already providing a captcha. Please disable that plugin or remove the reCaptcha key from your hypeSpamFighter settings',
    'hj:spamfighter:captchafailurelimitexceeded' => 'You have exceeded the number of failed captcha attempts and your account has been banned. Please contact the administrator at %s if you believe this has been a mistake',
    'hj:spamfighter:spamexceeded' => 'You have exceeded the number of allowed confirmed spam posts and your account has been banned. Please contact the administrator at %s if you believe this has been a mistake',
    'hj:spamfighter:emptyname' => 'Display Name can not be empty',

    'hj:spamfighter:spam:email' => 'This email is known to belong to spammers. You can\'t user it for registration',
    'hj:spamfighter:spam:username' => 'This username is known to belong to spammers. You can\'t user it for registration',

    'hj:spamfighter:usernametooshort' => 'Username must contain at least 4 characters',
    'hj:spamfighter:passwordtooshort' => 'Password must contain at least 6 characters',
    'hj:spamfighter:passwordmismatch' => 'Passwords do not match',

    'hj:spamfighter:formincomplete' => 'You can not proceed until the form is fully filled and validated',

    'hj:spamfighter:passwordstrength' => 'This password is: ',

    'hj:spamfighter:markedasspam' => 'The content you are trying to submit is suspected to be spam. It will not be visible in the system until approved by administrator',
    'hj:spamfighter:notification:suspectedspam' => 'New suspected spam submission',

    'hj:spamfighter:notification:suspectedspambody' => 'New item was submitted that is suspected to be spam: <br /><br />
            %s
            <br /><br />
            Original Post:<br />
            %s
            <br />
            Approve or Delete:<br />
            %s

',

    'hj:spamfighter:notification:spamreport' => 'New spam report',

    'hj:spamfighter:notification:spamreportbody' => 'An item was reported as spam: <br /><br />
            %s
            <br /><br />
            Original Post:<br />
            %s
            <br />
            Approve or Delete:<br />
            %s

',

    'hj:spamfighter:reportsubmitted' => 'Thank you. We have received your report and will review it shortly',


    'hj:spamfighter:notification:ham' => 'Spam flag has been lifted',
    'hj:spamfighter:notification:hambody' => 'Your item has been reviewed and unmarked as spam. We apologize for inconveniences <br /><br />
            %s
            <br />
            <br />
            Original Post:<br />
            %s
',
    'hj:spamfighter:notification:spam' => 'Spam flag has been confirmed',
    'hj:spamfighter:notification:spambody' => 'Your item %s has been reviewed and confirmed as spam <br /><br />
            Your spam count is %s of %s. Once you reach your limit, your account will be banned
    ',


    'hj-spamfighter:check_all' => 'Select All',

    'hj:spamfighter:admin:reportham' => 'Not Spam',
    'hj:spamfighter:admin:reportham:title' => 'Mark Spam Report as a false positive; Unmark as spam and publish',
    'hj:spamfighter:admin:deletespam' => 'Confirm as Spam',
    'hj:spamfighter:admin:deletespam:title' => 'Confirm this as spam and delete from the system',
    'hj:spamfighter:admin:banuser' => 'Ban Spammer',
    'hj:spamfighter:admin:banuser:title' => 'Ban the author of this post and report as spammer',
    'hj:spamfighter:admin:deleteuser' => 'Delete Spammer',
    'hj:spamfighter:admin:deleteuser:title' => 'Delete the author of this post and report as spammer',
    'hj:spamfighter:admin:preview' => 'Preview this item',

    'hj:spamfighter:error:unknown_entity' => 'No selection was made',

    'hj:spamfighter:bannedadmindecision' => 'Account was banned at admin\'s discretion. Please contact admin at %s for details',
    'hj:spamfighter:admin:banmessage' => 'Spammer was banned',
    'hj:spamfighter:admin:banmessage' => 'There was a problem with banning this spammer',
    'hj:spamfighter:admin:banmessage:multi' => 'Spammers were banned',
    'hj:spamfighter:admin:banerror:multi' => 'There was a problem banning one or more spammers',

    'hj:spamfighter:admin:spammessage' => 'Item was confirmed as spam and deleted',
    'hj:spamfighter:admin:spamerror' => 'We couldn\'t mark the item as spam',
    'hj:spamfighter:admin:spammessage:multi' => 'Items were confirmed as spam and deleted',
    'hj:spamfighter:admin:spamerror:multi' => 'We couldn\'t mark one or more items as spam',

    'hj:spamfighter:admin:deletemessage' => 'Spammer was deleted',
    'hj:spamfighter:admin:deleteerror' => 'Spammer could not be deleted',
    'hj:spamfighter:admin:deletemessage:multi' => 'Spammers were deleted',
    'hj:spamfighter:admin:deleteerror:multi' => 'One or more spammers could not be deleted',

    'hj:spamfighter:admin:hammessage' => 'Item was marked as false positive and restored in the system',
    'hj:spamfighter:admin:hamerror' => 'Item could not be marked as false positive',
    'hj:spamfighter:admin:hammessage:multi' => 'Items were marked as false positives and restored in the system',
    'hj:spamfighter:admin:hamerror:multi' => 'One or more items could not be marked as false positives',

	'hj:spamfighter:nospamreports' => 'No items have been marked for review',
	
);


add_translation("en", $english);
?>