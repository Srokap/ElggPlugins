<?php

function hj_spamfighter_validate_email_address($address) {
	if (!is_email_address($address)) {
		register_error(elgg_echo('registration:notemail'));
	}

	return elgg_trigger_plugin_hook('registeruser:validate:email', 'all', array('email' => $address), 'true');
}

function hj_spamfighter_validate_username($username) {
	// Blacklist for bad characters (partially nicked from mediawiki)
	$blacklist = '/[' .
			'\x{0080}-\x{009f}' . // iso-8859-1 control chars
			'\x{00a0}' . // non-breaking space
			'\x{2000}-\x{200f}' . // various whitespace
			'\x{2028}-\x{202f}' . // breaks and control chars
			'\x{3000}' . // ideographic space
			'\x{e000}-\x{f8ff}' . // private use
			']/u';

	if (
			preg_match($blacklist, $username)
	) {
		// @todo error message needs work
		register_error(elgg_echo('registration:invalidchars'));
	}

	// Belts and braces
	// @todo Tidy into main unicode
	$blacklist2 = '\'/\\"*& ?#%^(){}[]~?<>;|¬`@-+=';

	for ($n = 0; $n < strlen($blacklist2); $n++) {
		if (strpos($username, $blacklist2[$n]) !== false) {
			$msg = elgg_echo('registration:invalidchars', array($blacklist2[$n], $blacklist2));
			$msg = htmlentities($msg, ENT_COMPAT, 'UTF-8');
			register_error($msg);
		}
	}

	return elgg_trigger_plugin_hook('registeruser:validate:username', 'all', array('username' => $username), $true);
}

function hj_spamfighter_prepare_akismet(ElggUser $user, ElggEntity $entity) {
	$key = elgg_get_plugin_setting('akismet_key', 'hypeSpamFighter');

	if (!elgg_instanceof($user, 'user') || !elgg_instanceof($entity, 'object')) {
		return false;
	}

	$akismet = new Akismet(elgg_get_site_url(), $key);
	$akismet->setCommentAuthor($user->username);
	$akismet->setCommentAuthorEmail($user->email);
	if (!$user_url = $user->website) {
		if (!$user_url = $user->www) {
			$user_url = $user->getURL();
		}
	}
	$akismet->setCommentAuthorURL($user_url);
	$content = $entity->title;
	$content .= $entity->description;
	$metadata = array('title', 'description');
	$metadata = elgg_trigger_plugin_hook('hj:spamfighter:spamcheck:metatosend', 'object', array('entity' => $entity), $metadata);

	if (!empty($metadata)) {
		foreach ($metadata as $meta) {
			$content_meta[] .= $entity->$meta;
		}
	}
	$content .= implode(', ', $content_meta);

	$akismet->setCommentContent($content);
	$akismet->setPermalink($entity->getURL());

	return $akismet;
}