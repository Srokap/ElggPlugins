<?php

function hj_spamfighter_setup() {
    if (elgg_is_logged_in()) {
        elgg_set_plugin_setting('recaptcha_validation_count', 20, 'hypeSpamFighter');
        elgg_set_plugin_setting('recaptcha_fail_count', 10, 'hypeSpamFighter');
        elgg_set_plugin_setting('akismet_fail_count', 100, 'hypeSpamFighter');
        elgg_set_plugin_setting('hj:spamfighter:setup', true);
        return true;
    }
    return false;
}
