<?php

  function passwordchecker_init() 
  {
    global $CONFIG;
  }


  register_elgg_event_handler('init','system','passwordchecker_init');
?>
