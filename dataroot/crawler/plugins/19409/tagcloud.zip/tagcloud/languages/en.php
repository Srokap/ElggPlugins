<?php

	$english = array(
		"tagcloud:widget:title" => "Tag cloud",
		"tagcloud:widget:description" => "Tag cloud",
		"tagcloud:widget:notags" => "Number of tags to show",
		"item:object" => "all entries"
	);
					
	add_translation("en",$english);

?>
