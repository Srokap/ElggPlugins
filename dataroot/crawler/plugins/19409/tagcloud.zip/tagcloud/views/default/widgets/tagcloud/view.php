<div id="tagcloud_widget_container"><!-- start of tagcloud_widget_container div -->
<p>
<?php

	// Get the current page's owner
	$page_owner = page_owner_entity();
	if ($page_owner === false || is_null($page_owner)) {
		$page_owner = $_SESSION['user'];
	    set_page_owner($page_owner->getGUID());
	}

	$notags = 100;
	if ( $vars['entity']->notags ) {
        	$notags = $vars['entity']->notags;
	}
	
	echo display_tagcloud( 1, $notags, "tags" );
?>
</p>
</div><!-- end of tagcloud_widget_container -->
