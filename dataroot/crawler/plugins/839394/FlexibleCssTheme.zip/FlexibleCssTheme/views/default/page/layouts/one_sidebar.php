<head>
<style type="text/css">
body
{
background-image:url('http://www.freeimagehosting.net/newuploads/x7gdb.png');
}
h1
{
background-color:#000000;
}
h1 { font-family: ‘Metrophobic’, Arial, serif; font-weight: 400; }

body
{
font-family: 'Macondo', cursive;
font-size:13px;
}
</style>
<style type="text/css">
a:hover {background-color:#8F0000;}   /* mouse over link */
a:link {background-color:#000000;}    /* unvisited link */
a:active {background-color:#FF704D;}  /* selected link */
</style>
<script type="text/javascript">
  WebFontConfig = {
    google: { families: [ 'Macondo::latin' ] }
  };
  (function() {
    var wf = document.createElement('script');
    wf.src = ('https:' == document.location.protocol ? 'https' : 'http') +
      '://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js';
    wf.type = 'text/javascript';
    wf.async = 'true';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(wf, s);
  })(); </script>

</head>
<body>
<?php
/**
 * Layout for main column with one sidebar
 *
 * @package Elgg
 * @subpackage Core
 *
 * @uses $vars['content'] Content HTML for the main column
 * @uses $vars['sidebar'] Optional content that is displayed in the sidebar
 * @uses $vars['title']   Optional title for main content area
 * @uses $vars['class']   Additional class to apply to layout
 * @uses $vars['nav']     HTML of the page nav (override) (default: breadcrumbs)
 */

$class = 'elgg-layout elgg-layout-one-sidebar clearfix';
if (isset($vars['class'])) {
	$class = "$class {$vars['class']}";
}

// navigation defaults to breadcrumbs
$nav = elgg_extract('nav', $vars, elgg_view('navigation/breadcrumbs'));

?>

<div class="<?php echo $class; ?>">
	<div class="elgg-sidebar">
		<?php
			echo elgg_view('page/elements/sidebar', $vars);
		if ((elgg_get_context() == 'activity'))  {
		?><h1><font color="red">Welcome <?php echo $_SESSION['user']->username; ?>!</font></h1><br>
<a href="<?php echo $vars['url']; ?>profile/<?php echo $_SESSION['user']->username; ?>"><img src="<?php echo $_SESSION['user']->getIcon('large'); ?>"/></a>


		<?php
		}
		?></div>

	<div class="elgg-main elgg-body">
		<?php
			echo $nav;

			
			if (isset($vars['title'])) {
				echo elgg_view_title($vars['title']);
			}
			// @todo deprecated so remove in Elgg 2.0
			if (isset($vars['area1'])) {
				echo $vars['area1'];
			}
			if (isset($vars['content'])) {
				echo $vars['content'];
			}
		?>
	</div>
</div>
</body>