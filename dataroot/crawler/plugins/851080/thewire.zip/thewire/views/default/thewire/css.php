<?php
/**
 * The Wire CSS
 */

?>
/********************************
The Wire
*********************************/
#thewire-textarea {
	height: 40px;
	padding: 6px;
}
#thewire-characters-remaining {
	text-align: right;
	float: right;
	font-weight: bold;
	color: #333333;
}
.thewire-characters-remaining {
	color:#333333;
	border:none;
	font-size: 100%;
	font-weight: bold;
	padding:0 2px 0 0;
	margin:0;
	text-align: right;
	background: white;
}
.thewire-parent {
	margin-left: 40px;
}
