<?php
	/**
	 * Elgg Simple editing of external pages frontpage/about/term/contact and privacy
	 * 
	 * @package Elggxpages
	 */

	function xpages_init() {
		
		global $CONFIG;
		
		// Register a page handler, so we can have nice URLs
		register_page_handler('xpages','xpages_page_handler');
		
		// Register a URL handler for external pages
		register_entity_url_handler('xpages_url','object','xpages');
		
		// extend views
		elgg_extend_view('footer/links', 'xpages/footer_menu');
		elgg_extend_view('index/righthandside', 'xpages/front_right');
		elgg_extend_view('index/lefthandside', 'xpages/front_left');
		
		if (get_plugin_setting('xpages', 'xpages')=='') {
			set_plugin_setting('xpages', 'About, Privacy, Terms, Contacts', 'xpages');
		}
	}
	
	/**
	 * Page setup. Adds admin controls to the admin panel.
	 *
	 */
	function xpages_pagesetup()
	{
		if (get_context() == 'admin' && isadminloggedin()) {
			global $CONFIG;
			add_submenu_item(elgg_echo('xpages'), $CONFIG->wwwroot . 'pg/xpages/');
		}
	}
	
	function xpages_url($expage) {
			
			global $CONFIG;
			return $CONFIG->url . "pg/xpages/";
			
	}
	
	
	function xpages_page_handler($page) 
	{
		global $CONFIG;
		
		if ($page[0])
		{
			switch ($page[0])
			{
				case "read":		set_input('xpages',$page[1]);
										include(dirname(__FILE__) . "/read.php");
										break;
				default : include($CONFIG->pluginspath . "xpages/index.php"); 
			}
		}
		else
			include($CONFIG->pluginspath . "xpages/index.php"); 
	}
	
	// Initialise log browser
	register_elgg_event_handler('init','system','xpages_init');
	register_elgg_event_handler('pagesetup','system','xpages_pagesetup');
	
	// Register actions
		global $CONFIG;
		register_action("xpages/add",false,$CONFIG->pluginspath . "xpages/actions/add.php");
		register_action("xpages/addfront",false,$CONFIG->pluginspath . "xpages/actions/addfront.php");
		register_action("xpages/edit",false,$CONFIG->pluginspath . "xpages/actions/edit.php");
		register_action("xpages/delete",false,$CONFIG->pluginspath . "xpages/actions/delete.php");
		
		
			
?>