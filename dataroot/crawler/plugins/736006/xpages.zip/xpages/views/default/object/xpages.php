<?php

	/**
	 * Elgg xpages view
	 * 
	 * @package Elggxpages
	 * 
	 */

?>