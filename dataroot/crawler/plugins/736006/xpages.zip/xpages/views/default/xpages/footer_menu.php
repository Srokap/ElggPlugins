<?php

	/**
	 * Elgg External pages footer menu
	 * 
	 * @package Elggxpages
	 * 
	 */
	 
	 $xpages = string_to_tag_array(get_plugin_setting('xpages','xpages'));
?>

<div class="footer_toolbar_links">| 
<?php

	foreach ($xpages as $pagetype) {
		if ($pagetype !== 'front') {
			echo "<a href=\"".$vars['url']."pg/xpages/read/".$pagetype."\">".elgg_echo('xpages:'.$pagetype)."</a>  |  ";
		}
	}
	?>
</div>