<?php

	/**
	 * Elgg External pages menu
	 * 
	 * @package Elggxpages
	 * 
	 */
	 
	 //type
	 $type = $vars['type'];
	  
	 //set the url
	 $url = $vars['url'] . "pg/xpages/index.php?type=";

	 $xpages = string_to_tag_array(get_plugin_setting('xpages','xpages'));
?>

<div id="elgg_horizontal_tabbed_nav">
<ul>
	<li <?php if($type == 'front') echo "class = 'selected'"; ?>><a href="<?php echo $url; ?>front"><?php echo elgg_echo('xpages:frontpage'); ?></a></li>
	
	<?php foreach ($xpages as $pagetype) {
		if ($pagetype !== 'front') {
		echo "<li";
		if($type == $pagetype) {
			echo "class='selected'";	
		}
		echo "><a href=\"".$url.$pagetype."\">".elgg_echo('xpages:'.$pagetype)."</a></li>";
	}}
	?>
	</ul>
</div>