<?php
	
	echo "Please enter the titles for external pages you would like to be displayed on your site (comma separated)<br>";
	echo elgg_view('input/tags',array('value' => $vars['entity']->xpages,
									  'internalname' => 'params[xpages]'));

?>