<?php

	/**
	 * Elgg external pages: add/edit
	 * 
	 * @package Elggxpages
	 */

	// Make sure we're logged as admin
		admin_gatekeeper();

	// Get input data
		$contents = get_input('xpagescontent', '', false);
		$type = get_input('content_type');
		$previous_guid = get_input('expage_guid');

	// Cache to the session
		$_SESSION['xpages_content'] = $contents;
		$_SESSION['xpagestype'] = $type;
				
	// Make sure the content exists
		if (empty($contents)) {
			register_error(elgg_echo("xpages:blank"));
			forward("mod/xpages/add.php");
			
	// Otherwise, save the new external page
		} else {
			
	//remove the old external page
		if(get_entity($previous_guid)){
			delete_entity($previous_guid);
		}	
		
		// Initialise a new ElggObject
			$xpages = new ElggObject();
		// Tell the system what type of external page it is
			$xpages->subtype = $type;
		// Set its owner to the current user
			$xpages->owner_guid = get_loggedin_userid();
		// For now, set its access to public
			$xpages->access_id = ACCESS_PUBLIC;
		// Set its title and description appropriately
			$xpages->title = $type;
			$xpages->description = $contents;
		// Before we can set metadata, save
			if (!$xpages->save()) {
				register_error(elgg_echo("xpages:error"));
				forward("mod/xpages/add.php");
			}
						
		// Success message
			system_message(elgg_echo("xpages:posted"));
		// add to river
		    add_to_river('river/xpages/create','create',get_loggedin_userid(),$xpages->guid);
		// Remove the cache
			unset($_SESSION['xpages_content']); unset($_SESSION['xpagestitle']);
						
		
	// Forward back to the page
			forward("pg/xpages/index.php?type={$type}");
				
		}
		
?>