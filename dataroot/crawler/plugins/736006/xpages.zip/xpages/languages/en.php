<?php

	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'xpages' => "External pages",
			'xpages:frontpage' => "Frontpage",
			'xpages:about' => "About",
			'xpages:terms' => "Terms",
			'xpages:privacy' => "Privacy",
			'xpages:analytics' => "Analytics",
			'xpages:contact' => "Contact",
			'xpages:nopreview' => "No preview yet available",
			'xpages:preview' => "Preview",
			'xpages:notset' => "This page has not been set up yet.",
			'xpages:lefthand' => "The lefthand information pane",
			'xpages:righthand' => "The righthand information pane",
			'xpages:addcontent' => "You can add content here via your admin tools. Look for the external pages link under admin.",
			'item:object:front' => 'Front page items',
	
		/**
		 * Status messages
		 */
	
			'xpages:posted' => "Your page post was successfully posted.",
			'xpages:deleted' => "Your page post was successfully deleted.",
	
		/**
		 * Error messages
		 */
	
			'xpages:deleteerror' => "There was a problem deleting the old page",
			'xpages:error' => "There has been an error, please try again and if the problem persists, contact the administrator",
	
	);
	
	$xpages = string_to_tag_array(get_plugin_setting('xpages','xpages'));
	
	foreach ($xpages as $pagetype) {
	$english2 = array('xpages:'.$pagetype => ucwords($pagetype));
	add_translation("en",$english2);
	}
	
	add_translation("en",$english);

?>