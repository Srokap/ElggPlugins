<script type="text/javascript">
$(document).ready(function () {

$('a.show_blog_desc').click(function () {
	$(this.parentNode).children("[class=filerepo_listview_desc]").slideToggle("fast");
	return false;
});

}); /* end document ready function */
</script>

<?php 
	
elgg_set_ignore_access (true);

$number_of_blogs = elgg_get_entities (array('types' => 'object', 'subtypes' =>'blog',"count" => true));

echo "<span style='font-weight:bold;color:red'>Caution - this plugin ignores the entire Elgg access permission system and will modify all the blog entities it finds.</span><br/>There are currently ".$number_of_blogs." to modify.<br/>";

echo "<br/>".elgg_view("output/confirmlink", array('href' => $vars['url'] . "action/make_blogs_visible/revertblogs",
	'text' => elgg_echo('Revert blog view property'),
	'confirm' => elgg_echo('Are you sure you want to delete all the view properties of all the blogs?  Did you backup your database because there is no undo.'),
	'class' => 'submit_button',
	))."<br/><br/>";

$shares = elgg_get_entities(array('types' => 'object', 'subtypes' => "blog", 'limit' => 9999));
if($shares){
	foreach($shares as $share){
		$owner = $share->getOwnerEntity();
		$description .= '<div class="contentWrapper singleview">
			<div class="blog_post">';		
		$description .= elgg_echo("Blog Title: ").'<a href="'. $share->getURL() .'">'. $share->title .'</a> (';
		$description .= elgg_echo("Owner: ").$owner->name.')<br/>';
		if (isset($share->view)) {
			$description .= elgg_echo('The current blog view is set to : "')."<span style='font-weight:bold;color:red'>".$share->view.'"</span>'; 
		} else {
			$description .= "<span style='color:green'>The blog view property is not set - good!</span>";
		}
		$description .='</div></div>';
	} // For each $share.

}  else {
	$description = elgg_echo('There are currently no blog posts to modify...??');
} // if $shares

echo "<a href=\"javascript:void(0);\" class=\"show_blog_desc\">". elgg_echo('Click here to view all the blogs to be modified.') ."</a><br /><div class=\"filerepo_listview_desc\">" . $description . "</div>";

elgg_set_ignore_access (false);

?>
