<?php

register_action('make_blogs_visible/revertblogs', false, $CONFIG->pluginspath . "make_blogs_visible/actions/revertblogs.php");

?>
