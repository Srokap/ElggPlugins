<?php

elgg_set_ignore_access (true);
$shares = elgg_get_entities(array('types' => 'object', 'subtypes' => "blog", 'limit' => 9999));
if($shares){
	foreach($shares as $share){
		remove_metadata($share->guid, "view");
	} // For each $share.
	// success message
	system_message( elgg_echo( "Widgets have been modified, check under make_blogs_visible -> Settings to check" ) );
}  else {
	// failure message
	system_message( elgg_echo( "snafu!" ) );
} // if $shares

elgg_set_ignore_access (false);
forward($vars['url'].'pg/admin/plugins/');

?>
