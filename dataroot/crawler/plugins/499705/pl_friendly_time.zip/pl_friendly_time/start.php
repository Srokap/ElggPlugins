<?php
/**
 * User Friendly Time
 * Tries to improve upon the default Elgg friendly time display.
 *
 * @author Ademola "PHPlord" Morebise <amorebise@gmail.com>
 */
 
/*Nothing to initialise, but this file must really exist*/
?>