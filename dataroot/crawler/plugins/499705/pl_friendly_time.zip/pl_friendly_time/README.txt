=== Improved Friendly Time ===
Plugin Author: Ademola 'PHPlord' Morebise
Stable tag: 1.1

This is a simple plugin that tries to enhance Elgg's friendly time display.

== Description ==

*Improved Friendly Time* is a plugin that tries to enhance Elgg's friendly time display.  It overides an inbuilt Elgg function "friendly_time()" that converts UNIX timestamp to Human Readable time format, however, the function only outputs days e.g something that happened over a year ago would display as 453days ago! My plugin will smartly output dates as: last week, 2 weks ago and simply display the date if the day is too long ago.

== Installation ==

1. Unzip to your mod folder and activate, for Elgg 1.7, that's all
2. If your elgg is 1.5 or 1.6 then you need to hack a file:
3. open up engine/lib/elgglib.php find the line that contains
	function friendly_time($time) delete the WHOLE function
	and replace with
	function friendly_time($time) {
	return elgg_view('output/friendlytime', array('time' => $time));
	}
	You need a basic knowledge of PHP to do this.