<?php

  $english = array(
/**
 * Time strings
 */
	'friendlytime:weeks' => "about 2 weeks ago",
	'friendlytime:weeks:singular' => "last week",
	'friendlytime:date' => "j F Y",
	 );
	 
add_translation("en", $english);
?>