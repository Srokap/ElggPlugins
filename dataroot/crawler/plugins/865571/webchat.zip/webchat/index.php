<?php

	/**
	 * Elgg MyCustomText plugin
	 *
	 * @package ElggMyCustomText
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Untamed
	 * @copyright Untamed 2008-2010
	 */

	// Get the Elgg engine
		
		//Link text php file to body and display page
		$body = elgg_view('xat');
		$title = elgg_echo("WebChat");
		echo elgg_view_page($title, $body);
		
?>