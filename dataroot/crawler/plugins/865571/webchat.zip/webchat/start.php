<?php

	/**
	 * Elgg MyCustomText plugin
	 *
	 * @package ElggMyCustomText
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Untamed
	 * @copyright Untamed 2008-2010
	 */

	/**
	 * My Custom Text init function; defines what to do when plugin is enabled
	 *
	 */
		function webchat_init() {

			// Get config
				global $CONFIG;
				if (elgg_is_active_plugin('webchat')) {
			elgg_register_menu_item('page', array(
				'section' => 'profile',	
				'name' => 'Webchat',
				'text' => elgg_view_icon('speech-bubble-alt') . elgg_echo("webchat"),
				'href' => "/webchat",
				'contexts' => array('dashboard'),
			));
			}
// elgg_register_menu_item('page',array('text'=>'mycustomtext', 'href'=$CONFIG->wwwroot . "mycustomtext/");

			 elgg_register_page_handler('webchat','webchat_page_handler');
				
				
				
				}

					function webchat_page_handler($page)
						{
							global $CONFIG;
							switch ($page[0])
							{
								default:
									include $CONFIG->pluginspath . 'webchat/index.php';
									break;	
							}
							exit;
						}

				
				//Startup stuff... links to mycustomtext_init function
		elgg_register_event_handler('init', 'system', 'webchat_init');
?>