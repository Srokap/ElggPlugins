<center><br /><br /><h3><p> Chatea con toda la gente de la red y encuentra nuevos amigos !!!</p></h3><br /><br />
<p><IFRAME marginWidth="10" marginHeight="10" src="http://minichat.irc-hispano.es/?canal=irc-hispano" width="590" height="400" scrolling="no" frameborder="0"></IFRAME><br /></center></p>

