<?php

// Gerado pelo browser de tradução. 

$portuguese = array( 
	 'relatedgroups:owned'  =>  "Grupos relacionados com %s" , 
	 'relatedgroups:in_frontpage'  =>  "Mostrar os grupos relacionados na página do grupo" , 
	 'relatedgroups:addrelated'  =>  "Editar os grupos reelacionados" , 
	 'relatedgroups:related'  =>  "Grupos relacionados" , 
	 'relatedgroups:unrelated'  =>  "Grupos não relacionados" , 
	 'relatedgroups:related:instructions'  =>  "Clique para definir como não relacionado" , 
	 'relatedgroups:unrelated:instructions'  =>  "Clique para definir como relacionado"
); 

add_translation('pt', $portuguese); 

?>