<?php

// Generat per translationbrowser 

$catalan = array( 
	 'relatedgroups:in_frontpage'  =>  "Mostra els grups relacionats a la pàgina del grup" , 
	 'relatedgroups:owned'  =>  "Grups relacionats amb %s" , 
	 'relatedgroups:addrelated'  =>  "Gestionar grups relacionats" , 
	 'relatedgroups:related'  =>  "Grups relacionats" , 
         "relatedgroups:autocomplete" => 'Relaciona el grup',
	 'relatedgroups:unrelated'  =>  "Grups no relacionats" , 
	 'relatedgroups:related:instructions'  =>  "prem sobre la icona per fer el grup no relacionat" , 
         "relatedgroups:autocomplete:instructions" => 'introdueix el nom del grup i fes clic sobre "afegeix" per fer el grup relacionat',
         "add" => "Afegeix",
	 'relatedgroups:unrelated:instructions'  =>  "prem sobre la icona per fer el grup relacionat",
         "relatedgroups:unrelated:showall" => 'Mostra tots els grups',
         "relatedgroups:nopermissons" => 'No tens permisos per modificar els grups relacionats',
	 "relatedgroups:add:error" => 'S\'ha produït un error. Estàs segur que has introduït bé el nom del grup?',
); 

add_translation('ca', $catalan); 

?>
