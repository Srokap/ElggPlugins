<?php

// Xerado por translationbrowser 

$galician = array( 
	 'relatedgroups:in_frontpage'  =>  "Mostra-los grupos relacionados na portada do grupo" , 
	 'relatedgroups:owned'  =>  "Grupos relacionados con %s" , 
	 'relatedgroups:addrelated'  =>  "Xestiona-los grupos relacionados" , 
	 'relatedgroups:related'  =>  "Grupos relacionados" , 
	 'relatedgroups:unrelated'  =>  "Grupos non relacionados" , 
	 'relatedgroups:related:instructions'  =>  "clica sobre un icono para que o grupo deixe de estar relacionado" , 
	 'relatedgroups:unrelated:instructions'  =>  "clica sobre un icono para relacionar a dito grupo" , 
	 'relatedgroups:autocomplete'  =>  "Relaciona un grupo" , 
	 'relatedgroups:autocomplete:instructions'  =>  "Escribe o nome do grupo e clica en \"relacionar\" para crear un grupo relacionado" , 
	 'add'  =>  "Relacionar" , 
	 'relatedgroups:unrelated:showall'  =>  "Ver todo-los grupos" , 
	 'relatedgroups:nopermissons'  =>  "Non tes permisos para modificar estes grupos relacionados" , 
	 'relatedgroups:add:error'  =>  "Ocurriu un erro. Escribiches ben o nome do grupo?"
); 

add_translation('gl', $galician); 

?>