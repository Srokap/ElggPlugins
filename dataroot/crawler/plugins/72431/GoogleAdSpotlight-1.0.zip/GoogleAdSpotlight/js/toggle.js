/*
**
** Spotlight displaying Google Adverts
**
** @package GoogleAdSpotlight
** @author Philip Hart, Centre for Learning and Performance Technology (www.c4lpt.co.uk)
** @link http://www.c4lpt.co.uk/ElggConsultancy.html
** @copyright (c) Tesserae Ltd, 2009
** @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
**
*/

function toggle(tabClicked)
{
        // Ignore clicks on the currently selected tab
        if (!tabClicked.hasClass("selected"))
        {
                var tabContainer = tabClicked.parent();
                var tabs = tabContainer.children();
                var contentWrapper = tabContainer.parent().parent().parent();
                var gasParameters = contentWrapper.children(".gas");
                var gadService = contentWrapper.children(".gag").children("input[name='params[google_ad_service]']");

                // Toggle the tabs
                tabs.each(function() {
                        if ($(this).hasClass("selected"))
                        {
                                $(this).removeClass("selected");
                        }
                        else
                        {
                                $(this).addClass("selected");
                        }
                });

                // Toggle the Google Ad Sense parameters
                gasParameters.slideToggle("fast");

                // Record which Google Ad Service has been selected
                gadService.attr("value", tabClicked.attr("id"));
        }

        return false;
}
