<?php

        /*
        **
        ** Spotlight displaying Google Adverts
        ** 
	** @package GoogleAdSpotlight
        ** @author Philip Hart, Centre for Learning and Performance Technology (www.c4lpt.co.uk)
        ** @link http://www.c4lpt.co.uk/ElggConsultancy.html
        ** @copyright (c) Tesserae Ltd, 2009
        ** @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	**
        */

        // Obtain configuration settings for this plugin
        $settings = find_plugin_settings("GoogleAdSpotlight");

?>

<div id="layout_spotlight">
<div id="wrapper_spotlight">
<center>

<?php
	if ("gam" == $settings->google_ad_service)
	{
?>

<!-- Google Ad Manager -->
<script type="text/javascript" src="http://partner.googleadservices.com/gampad/google_service.js"></script>
<script type="text/javascript">
	GS_googleAddAdSenseService("<?php echo $settings->google_ad_client ?>");
	GS_googleEnableAllServices();
</script>

<script type="text/javascript">
	GA_googleAddSlot(<?php echo "\"", $settings->google_ad_client, "\", \"", $settings->google_ad_slot, "\"" ?>);
	GA_googleFetchAds();
	GA_googleFillSlot("<?php echo $settings->google_ad_slot ?>");
</script>

<?php
	}
	else
	{
?>

<!-- Google AdSense -->
<script type="text/javascript">
<!--
<?php
	echo "\tgoogle_ad_client = \"$settings->google_ad_client\";\n";
	echo "\tgoogle_ad_slot = \"$settings->google_ad_slot\";\n";
	echo "\tgoogle_ad_width = \"$settings->google_ad_width\";\n";
	echo "\tgoogle_ad_height = \"$settings->google_ad_height\";\n";
?>
-->
</script>
<script type="text/javascript" src="http://pagead2.googlesyndication.com/pagead/show_ads.js"></script>

<?php
	}
?>

</center>
</div><!-- /#wrapper_spotlight -->
</div><!-- /#layout_spotlight -->
