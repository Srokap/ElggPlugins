<?php
        /*
        **
        ** Spotlight displaying Google Adverts
        **
        ** @package GoogleAdSpotlight
        ** @author Philip Hart, Centre for Learning and Performance Technology (www.c4lpt.co.uk)
        ** @link http://www.c4lpt.co.uk/ElggConsultancy.html
        ** @copyright (c) Tesserae Ltd, 2009
        ** @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
        **
        */
?>

.gag a.gams_link {
        cursor:pointer;
}
