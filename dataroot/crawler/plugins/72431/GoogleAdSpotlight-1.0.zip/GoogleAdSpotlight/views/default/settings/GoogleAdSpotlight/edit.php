<?php
        /*
        **
        ** Spotlight displaying Google Adverts
        **
        ** @package GoogleAdSpotlight
        ** @author Philip Hart, Centre for Learning and Performance Technology (www.c4lpt.co.uk)
        ** @link http://www.c4lpt.co.uk/ElggConsultancy.html
        ** @copyright (c) Tesserae Ltd, 2009
        ** @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
        **
        */

	// Determine which tab appears first in the row (default: Google Ad Manager tab)
	$leadTab = $vars['entity']->google_ad_service;
	if (empty($leadTab)) $leadTab = 'gam';

	// Declare some visibility constants
	$gasHidden = "\"display: none;\"";
	$gasVisible = "\"display: block;\"";

?>

<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/GoogleAdSpotlight/js/toggle.js"></script>

<div class="contentWrapper">

	<!--This section contains parameters common to both Google Ad Manager and Google AdSense. It is static  -->
	<div class="gag">
		<div id="elgg_horizontal_tabbed_nav">
			<ul>
			<?php
				if ('gam' == $leadTab)
				{
			?>
				<li class="selected" id="gam"><a class="gams_link" onclick="toggle($(this.parentNode));"><?php echo elgg_echo('gams:gam'); ?></a></li>
				<li id="gas"><a class="gams_link" onclick="toggle($(this.parentNode));"><?php echo elgg_echo('gams:gas'); ?></a></li>
			<?php
				}
				else
				{
			?>
				<li class="selected" id="gas"><a class="gams_link" onclick="toggle($(this.parentNode));"><?php echo elgg_echo('gams:gas'); ?></a></li>
				<li id="gam"><a class="gams_link" onclick="toggle($(this.parentNode));"><?php echo elgg_echo('gams:gam'); ?></a></li>
			<?php
				}
			?>
			</ul>
		</div> <!-- elgg_horizontal_tabbed_nav -->

		<?php
			// Create a hidden field to remember the Google Ad Service choice
			echo elgg_view('input/hidden', array('internalname'=>'params[google_ad_service]', 'value'=>$leadTab));

			echo elgg_view('input/text', array('internalname'=>'params[google_ad_client]', 'label'=>elgg_echo('gams:pubid'), 'value'=>$vars['entity']->google_ad_client));
			echo elgg_view('input/text', array('internalname'=>'params[google_ad_slot]', 'label'=>elgg_echo('gams:slotname'), 'value'=>$vars['entity']->google_ad_slot));
		?>
	</div> <!-- gag -->

	<!--This section contains paramaters specific to Google Ad Sense. It can be toggled  -->
	<div class="gas" style=<?php if ('gam' == $leadTab) echo $gasHidden; else echo $gasVisible;?>>
	<?php
		echo elgg_view('input/text', array('internalname'=>'params[google_ad_width]', 'label'=>elgg_echo('gas:width'), 'value'=>$vars['entity']->google_ad_width));
		echo elgg_view('input/text', array('internalname'=>'params[google_ad_height]', 'label'=>elgg_echo('gas:height'), 'value'=>$vars['entity']->google_ad_height));
	?>
	</div> <!-- gas -->

</div> <!-- contentWrapper -->
