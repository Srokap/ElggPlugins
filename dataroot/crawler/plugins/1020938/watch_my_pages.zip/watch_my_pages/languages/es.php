<?php

/**
 * Watch my Pages language file
 */
$spanish = array(
    'wmp:link:load_more' => 'Cargar Más',
    'wmp:link:loading' => 'Cargando',
    
);

add_translation("es", $spanish);
