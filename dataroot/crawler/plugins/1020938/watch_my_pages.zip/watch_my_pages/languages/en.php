<?php

/**
 * Watch my Pages language file
 */
$english = array(
    'wmp:link:load_more' => 'Load More',
    'wmp:link:loading' => 'Loading',
);

add_translation("en", $english);
