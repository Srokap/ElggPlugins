watch_my_pages
==============

Elgg 1.8 ajax paginator


## This module replace the custom paginator, to a simple ajaxified one


### Screenshots

Replaced Paginator, watch the "Load More" text, when you click, content with automagically load inside.

![Ajax Paginator](https://github.com/KeetupTeam/watch_my_pages/raw/master/graphics/screen1.png "Ajax Paginator")


Loading the content

![Loading Ajax Paginator](https://github.com/KeetupTeam/watch_my_pages/raw/master/graphics/screen2.png "Loading Ajax Paginator")