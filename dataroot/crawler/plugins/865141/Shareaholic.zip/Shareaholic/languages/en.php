<?php

/**
 * LiHaiSlide
 * @license Commercial
 * @author Callum West
 * @copyright LiHai Learning 2012
 */

	$english = array(
		
	// General
	'LiHaiSlide' => "LiHaiSlide",
	
	
	);
					
	add_translation("en",$english);