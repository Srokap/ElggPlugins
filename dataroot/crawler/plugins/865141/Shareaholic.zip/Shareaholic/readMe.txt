
/**
 * Shareaholic
 * @license GNU Public License version 2
 * @author Callum West
 * @plugin - copyright LiHai Learning 2012
 * @functionality - copyright Shareaholic
 */
 
 
 
 This plugin uses the sassy sharing buttons from Shareaholic to allow users to share your pages on social networks
 
 	
 
 	
 	