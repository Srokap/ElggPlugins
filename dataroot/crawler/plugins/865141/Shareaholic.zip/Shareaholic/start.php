<?php

/**
 * Shareaholic
 * @license GNU Public License version 2
 * @author Callum West
 * @plugin - copyright LiHai Learning 2012
 * @functionality - copyright Shareaholic
 */



function Shareaholic_init() {

	// Extend Any object views with next & previous
	elgg_extend_view('object/summary/extend','Shareaholic/Shareaholic');
	
}

// call init
elgg_register_event_handler('init','system','Shareaholic_init');

?>