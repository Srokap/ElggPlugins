<?php

/**
	 * Loveloop theme for Elgg
	 * @package: Loveloop theme for Elgg
	 * @author azycraze
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @copyright azycraze 2011
	 */
 
    function loveloop_theme_init()
    {
	
 	}



 
    register_elgg_event_handler('init','system','loveloop_theme_init');
 
?>