<?php


/**
	 * Loveloop theme for Elgg
	 * @package: Loveloop theme for Elgg
	 * @author azycraze
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @copyright azycraze 2011
	 */
	 
?>
	<p>
		<b>Loveloop theme</b><br />
		<?php echo elgg_echo("Where would you like to show the navigation");?><br /><br />
				<select name="params[navstyle]">
			<option value="topbar" <?php if ($vars['entity']->navstyle == 'topbar') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('topbar'); ?></option>
			<option value="side" <?php if ($vars['entity']->navstyle == 'side') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('side'); ?></option>
	
		</select>
		
		
		</p>
		<!--designed by azycraze-->