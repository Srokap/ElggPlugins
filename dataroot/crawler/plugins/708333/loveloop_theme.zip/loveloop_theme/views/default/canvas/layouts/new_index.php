<?php


/**
	 * Loveloop theme for Elgg
	 * @package: Loveloop theme for Elgg
	 * @author azycraze
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @copyright azycraze 2011
	 */
	 
?>

<div id="custom_index">
    <?php
     if (!isloggedin()) {
	 
    ?>
         <div class="intro">
         <img src="<?php echo $vars['url']; ?>mod/loveloop_theme/graphics/social.gif" USEMAP="#social_Map"/>
		 <MAP NAME="social_Map">
         <AREA SHAPE="rect" ALT="Register" COORDS="732,203,898,252" HREF="<?php echo $vars['url']; ?>account/register.php">
         </MAP>
      	 </div>
	<? 
	} 
	?>
    <!-- left column content -->
    
    <?php
     if (isloggedin()) {
	 
    ?>
	
    <?php 
	} else { 
	?>
	<? 
	} 
	?>
	
	<div id="left"> 
    <?php
    if(is_plugin_enabled('file')){
    ?>
    <!-- display latest files -->
    <div class="index_box">
            <h2><?php echo elgg_echo("custom:files"); ?></h2>
            <?php 
                if (!empty($vars['area2'])) {
                    echo $vars['area2'];//this will display files
                }else{
                    echo "<p><?php echo elgg_echo('custom:nofiles'); ?></p>";
                }
            ?>
        </div>
	<?php
		}
		
		if(is_plugin_enabled('groups')){
	?> 
        <!-- display latest groups -->
	    <div class="index_box">
            <h2><?php echo elgg_echo("custom:groups"); ?></h2>
        <?php 
                if (!empty($vars['area5'])) {
                    echo $vars['area5'];//this will display groups
                }else{
                    echo "<p><?php echo elgg_echo('custom:nogroups'); ?>.</p>";
                }
            ?>
    	</div>
	<?php
		}
	?>
    
</div>
    
    <!-- right hand column -->
    <div id="right">
        <!-- more content -->
	    <?php
            //include a view that plugins can extend
            echo elgg_view("index/righthandside");
        ?>
        <!-- latest members -->
   <?php
     if (isloggedin()) {
	?> 
	
	<?php } else { ?>   
	
	<?php
	
		}
	?>
			
        
        <div class="index_box" style="margin-top:10px;">
            <h2><?php echo elgg_echo("custom:members"); ?></h2>
            <div class="contentWrapper">
            <?php 
                if(isset($vars['area3'])) {
                    //display member avatars
                    foreach($vars['area3'] as $members){
                        echo "<div class=\"index_members\">";
                        echo elgg_view("profile/icon",array('entity' => $members, 'size' => 'small'));
                        echo "</div>";
                    }
                }
            ?>
	        <div class="clearfloat"></div>
	        </div>
        </div>
	<?php
		if(is_plugin_enabled('blog')){
	?> 
			<!-- latest blogs -->
			<div class="index_box">
				<h2><?php echo elgg_echo("custom:blogs"); ?></h2>
				<?php 
					if (isset($vars['area4'])) 
						echo $vars['area4']; //display blog posts
				?>
			</div>
	<?php
		}
	
		if(is_plugin_enabled('bookmarks')){
	?>
			<!-- display latest bookmarks -->
    	<div class="index_box">
            <h2><?php echo elgg_echo("custom:bookmarks"); ?></h2>
            <?php 
                if (isset($vars['area6'])) 
                    echo $vars['area6']; //display bookmarks
            ?>
        </div>
<?php
		}
	?>
    </div>
    <div class="clearfloat"></div>
</div>
<!--designed by azycraze-->