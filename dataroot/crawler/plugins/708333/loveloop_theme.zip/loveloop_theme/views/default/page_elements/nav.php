<?php
/**
	 * Loveloop theme for Elgg
	 * @package: Loveloop theme for Elgg
	 * @author azycraze
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @copyright azycraze 2011
	 */
	 ?>

<?php
 $navstyle=get_plugin_setting("navstyle","loveloop_theme");
 if ($navstyle=='side')
 {
 ?>

	<div id="menu">
    <table width="60" height="300" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td width="50" height="50">
		    <?php
			if(!is_plugin_enabled('custom_index'))
			{
			?>
   			<a href="<?php echo $vars['url']; ?>pg/dashboard/" title="Home">
		    <img src="<?php echo $vars['url']; ?>mod/loveloop_theme/graphics/home.png" border="0" /></a>
			<?php 
			} else { 
			?>
			<a href="<?php echo $vars['url']; ?>" title="Home">
		    <img src="<?php echo $vars['url']; ?>mod/loveloop_theme/graphics/home.png" border="0" /></a>
			<?php 
			} 
			?>
   
		</td>
		</tr>
		<tr>
				<td width="50" height="50">
   		<a href="<?php echo $vars['url']; ?>pg/groups/member/<?=$_SESSION['user']->username ?>/" title="Groups">
		    <img src="<?php echo $vars['url']; ?>mod/loveloop_theme/graphics/group.png" border="0" /></a>

		</td>
		</tr>
			<tr>
		<td width="50" height="50">
   			<a href="<?php echo $vars['url']; ?>pg/photos/owned/<?=$_SESSION['user']->username?>/" title="Photos">
		    <img src="<?php echo $vars['url']; ?>mod/loveloop_theme/graphics/foto.png" border="0" /></a>
   
		</td>
		</tr>
		<tr>
				<td width="50" height="50">
   		<a href="<?php echo $vars['url']; ?>pg/videos/owned/<?=$_SESSION['user']->username?>/" title="Videos">
		    <img src="<?php echo $vars['url']; ?>mod/loveloop_theme/graphics/videos.png" border="0" /></a>

		</td>
		</tr>
				<tr>
				<td width="50" height="50" style="padding:10px 0 0 0;">
   		<a href="<?php echo $vars['url']; ?>pg/settings/" title="Settings">
		    <img src="<?php echo $vars['url']; ?>mod/loveloop_theme/graphics/settings.png" border="0" /></a>

		</td>
		</tr>
		<tr>
		<td width="50" height="50" style="padding:10px 0 0 0;">
		<?php

			// The administration link is for admin or site admin users only
			if ($vars['user']->isAdmin()) {

		?>

			<a href="<?php echo $vars['url']; ?>pg/admin/" title="Admin">
			<img src="<?php echo $vars['url']; ?>mod/loveloop_theme/graphics/admin.png" border="0" /></a>

		<?php

				}

		?>
		</td>
		</tr>
   </table>
   </div>
   <?php
   }
   ?>
   <!--designed by azycraze-->