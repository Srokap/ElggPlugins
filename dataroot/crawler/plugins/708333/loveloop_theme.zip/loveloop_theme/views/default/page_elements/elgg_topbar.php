<?php

/**
	 * Loveloop theme for Elgg
	 * @package: Loveloop theme for Elgg
	 * @author azycraze
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @copyright azycraze 2011
	 */
	 ?>

<style>
#login_btn
{
margin-top:2px;
margin-left:10px;
text-align:center;
width:30px;
background-color:#50D0DE;
border:1px solid #0D716F;
}
#login_box
{
width:200px;
font-family:Tahoma;
font-size:12px;
color:#0E7268;
background-color:#B3ECE4;
border:solid 2px #5ea0c1;
padding:8px;
margin-left:0px;
position:absolute;
display:none;
-moz-border-radius:6px;
-webkit-border-radius:6px;
}

.login_btn
{
background-color:green;
color:white;
border:solid 1px #5ea0c1;
padding:3px;
-moz-border-radius:2px;
-webkit-border-radius:2px;
}


</style>
<script type="text/javascript" src="mod/loveloop_theme/js/jquery.js"></script>
<script type="text/javascript">
$(document).ready(function()
{
	$(".login_btn").click(function()
	{
		$("#login_box").show();
		return false;
	});
		$("#site_logo").click(function()
	{
		$("#login_box").hide();
		return false;
	});
});
</script>
<body>

<?php

     if (isloggedin()) {
?>

<div id="elgg_topbar">

<div id="elgg_topbar_container_left">
	<div class="toolbarimages">
	
		<a href="<?php echo $_SESSION['user']->getURL(); ?>"><img class="user_mini_avatar" src="<?php echo $_SESSION['user']->getIcon('topbar'); ?>"></a>
		
	</div>
	<div class="toolbarlinks">
		<a href="<?php echo $vars['url']; ?>pg/dashboard/" class="pagelinks"><?php echo elgg_echo('dashboard'); ?></a>
	</div>
        <?php

	        echo elgg_view("navigation/topbar_tools");

        ?>  	
        <div class="toolbarlinks2">		
		<?php
		//allow people to extend this top menu
		echo elgg_view('elgg_topbar/extend', $vars);
		?>		
		
	</div>


</div>


<div id="elgg_topbar_container_right">
		<small>
			<?php echo elgg_view('output/url', array('href' => "{$vars['url']}action/logout", 'text' => elgg_echo('logout'), 'is_action' => TRUE)); ?>
		</small>
</div>
<?php 
$navstyle = get_plugin_setting("navstyle","loveloop_theme");
if ($navstyle == 'topbar') 
{
?>
		<div id="home">
            <?php
			if(!is_plugin_enabled('custom_index'))
			{
			?>
   			<a href="<?php echo $vars['url']; ?>pg/dashboard/" title="Home">
		    <img src="<?php echo $vars['url']; ?>mod/loveloop_theme/graphics/top_home.png" border="0" /></a>
			<?php 
			} else { 
			?>
			<a href="<?php echo $vars['url']; ?>" title="Home">
		    <img src="<?php echo $vars['url']; ?>mod/loveloop_theme/graphics/top_home.png" border="0" /></a>
			<?php 
			} 
			?>
			<a href="<?php echo $vars['url']; ?>pg/photos/owned/<?=$_SESSION['user']->username?>/" title="Photos">
		    <img src="<?php echo $vars['url']; ?>mod/loveloop_theme/graphics/top_foto.png" border="0" /></a>
			<a href="<?php echo $vars['url']; ?>pg/videos/owned/<?=$_SESSION['user']->username?>/" title="Videos">
		    <img src="<?php echo $vars['url']; ?>mod/loveloop_theme/graphics/top_videos.png" border="0" /></a>
			<a href="<?php echo $vars['url']; ?>pg/groups/member/<?=$_SESSION['user']->username?>/" title="Groups">
		    <img src="<?php echo $vars['url']; ?>mod/loveloop_theme/graphics/top_groups.png" border="0" /></a>
			<a href="<?php echo $vars['url']; ?>pg/settings/" title="Settings">
		    <img src="<?php echo $vars['url']; ?>mod/loveloop_theme/graphics/top_set.png" border="0" /></a>
		<?php 

			// The administration link is for admin or site admin users only
			if ($vars['user']->isAdmin()) {

		?>

			<a href="<?php echo $vars['url']; ?>pg/admin/" title="Admin">
			<img src="<?php echo $vars['url']; ?>mod/loveloop_theme/graphics/top_admin.png" border="0" /></a>

		<?php

				}

		?>
		</div>
		<? 
		} 
		?>




</div><!-- /#elgg_topbar -->

<div class="clearfloat"></div>

<?php
    } else {
?>
<div id="elgg_topbar">

<div id="elgg_topbar_container_left">
	<div class="toolbarimages">
	</div>
	<?php 
if (is_plugin_enabled('custom_index'))
{
?>

        		<div id="login_btn">
		<a href="#" class="login_btn"><?php echo elgg_echo('LOGIN'); ?></a>
		<div id="login_box">
				<?php
				$form_body = "<p><label>" . elgg_echo('username') . "<br />" . elgg_view('input/text', array('internalname' => 'username', 'class' => 'login-textarea')) . "</label><br />";
				$form_body .= "<label>" . elgg_echo('password') . "<br />" . elgg_view('input/password', array('internalname' => 'password', 'class' => 'login-textarea')) . "</label><br /><br />";
				$form_body .= elgg_view('input/submit', array('value' => elgg_echo('login'))) . "</p>";
				$form_body .= "<p><a href=\"". $vars['url'] ."account/forgotten_password.php\">" . elgg_echo('user:password:lost') . "</a></p>";

				echo elgg_view('input/form', array('body' => $form_body, 'action' => "". $vars['url'] ."action/login"));

	  ?>
	  </div>
	</div>
	<? } ?>
</div>
<div id="elgg_topbar_container_reg">
		<a href="<?php echo $vars['url']; ?>account/register.php"><small><?php echo elgg_echo('Register Now'); ?></small></a>
</div>
<?php 
if (is_plugin_enabled('custom_index'))
{
?>
<div id="home" style="top:4px;">
<a href="<?php echo $vars['url']; ?>"><small><?php echo elgg_echo('Home'); ?></small></a>
</div>
<?php
	}
	?>


</div>
<!-- /#topbar -->
<div class="clearfloat"></div>
<?php
	}
?>
</body>
<!--designed by azycraze-->