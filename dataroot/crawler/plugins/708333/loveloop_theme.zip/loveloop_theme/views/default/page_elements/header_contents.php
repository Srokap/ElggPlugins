<?php


/**
	 * Loveloop theme for Elgg
	 * @package: Loveloop theme for Elgg
	 * @author azycraze
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @copyright azycraze 2011
	 */
	 
?> 	
<div id="layout_header">
  <div id="wrapper_header"> 
    <!-- display the page title -->
    <div id="site_logo"> 
			<?php
		 if(!is_plugin_enabled('custom_index') && isloggedin()){
		 ?>
		<a href="<?php echo $vars['url']; ?>pg/dashboard/"><img src="<?php echo $vars['url']; ?>mod/loveloop_theme/graphics/site_logo.gif" border="0" /></a>
		<?php
		}else{
		?>
		<a href="<?php echo $vars['url']; ?>"><img src="<?php echo $vars['url']; ?>mod/loveloop_theme/graphics/site_logo.gif" border="0" /></a>
		<?php 
		} 
		?> 
		
    </div>

	
    <!--  /#site_logo-->
  </div>
  <div id="elgg_topbar_container_search">
<?php echo elgg_view('page_elements/searchbox'); ?>
</div>

 </div> <!-- /#wrapper_header -->
</div><!-- /#layout_header -->
<!--designed by azycraze-->