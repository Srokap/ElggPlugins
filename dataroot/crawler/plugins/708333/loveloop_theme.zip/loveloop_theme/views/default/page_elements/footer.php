<?php


/**
	 * Loveloop theme for Elgg
	 * @package: Loveloop theme for Elgg
	 * @author azycraze
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @copyright azycraze 2011
	 */
?>
<div id="layout_footer">
<table width="100%" height="60"  border="0" cellpadding="0" cellspacing="0">
	<tr >

		<td width="460" height="60" style="padding-top:12px;">
   			<a href="http://www.techmazter.com" target="_blank">
		    <img src="<?php echo $vars['url']; ?>mod/loveloop_theme/graphics/banner_left.gif" border="0" /></a>

		</td>
				<td width="460" height="60" style="padding-top:12px;">
   			<a href="http://www.techmazter.com" target="_blank">
		    <img src="<?php echo $vars['url']; ?>mod/loveloop_theme/graphics/banner_left.gif" border="0" /></a>

		</td>

		<td width="310" height="60" align="right">
		<p class="footer_toolbar_links">
		<?php
			echo elgg_view('footer/links');
		?>
		</p>
		</td>
	</tr>
</table>		
<td width="310" height="28" align="right">
		<p class="footer_legal_links"><a href="http://www.elgg.org" >Powered by Elgg</a> &amp; Design by azycraze</p>
</td>
</div><!-- /#layout_footer -->
</div><!-- /#page_wrapper -->
</div><!-- /#page_container -->
<?php
	echo elgg_view('footer/analytics');
?>
</body>
</html>
<!--designed by azycraze-->