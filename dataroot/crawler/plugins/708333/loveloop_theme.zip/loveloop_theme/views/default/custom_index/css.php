<?php

/**
	 * Loveloop theme for Elgg
	 * @package: Loveloop theme for Elgg
	 * @author azycraze
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @copyright azycraze 2011
	 */
?>

#custom_index {
width:980px;

}


#intro {
    width:940;
	margin:0 0 10px 0;
	}
#left{
    position:relative;
    width:380px;
    float:right;
    margin:10px 40px 0px 0;
    padding:0 0 0px 0px;
}

/* IE6 fix */
* html #left{ 
width:440px;
margin:10px 0px 10px -10px;
	
}
/* IE7 */
*:first-child+html #left{ 
width:440px;
margin:10px 0px 10px -10px;
}
#right {
    width:535px;
    float:left;
    margin:0;
    padding:0;
}

#index_welcome {
	padding:5px 10px 5px 10px;
	margin:0 0 20px 0;
    -webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	border:1px solid #CCC;
	background: #f5f5f5;

}
#index_welcome #login-box {
	margin:5px 0 10px 0;
    padding:0 0 10px 0;
	background: transparent;
	width:303px;
}
#welcomemessage{
 background: #fff;
 width:600px;
 padding:5px;
 height: 200px;

}
#welcomemessage h2{
color:#4d4d4d;
    -webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
background:#b6e9ff;
width:160px;
border:1px solid #ccc;
font-size:18px;
padding:2px;
}
#welcomemessage.content{
color:white;
font-size:18px;
padding-left:10px;

}

#index_welcome #login-box form {
	margin:0 10px 0 10px;
    padding:0 10px 4px 10px;
	background: transparent;
	width:262px;
}

#index_welcome #login-box h2,
.index_box h2 {
background: transparent;
color:#3b5998;
font-weight:bold;
text-transform:uppercase;
text-align:left;
font-size:14px;
line-height:1.2em;
margin:0 0 2px 0;
padding:5px 5px 5px 5px;
}
#index_welcome #login-box h2 {
	padding-bottom:5px;
}

.index_box {
margin:0 0 10px;
border: 1px solid #ccc;
padding:10px 0 10px 0;
-webkit-border-radius: 8px; 
-moz-border-radius: 8px;
background: #ff99ff;
}
* html #index_box{ 
margin:0;
width:380px
	
}
/* IE7 */
*:first-child+html #index_box{ 
margin:0; 
width:380px
}


.index_box .search_listing {

}
.index_box .index_members {
	float:left;
	margin:2pt 5px 3px 0pt;
}
#persistent_login {
	float:right;
	display:block;
	margin-top:-34px;
}
<!--designed by azycraze-->
