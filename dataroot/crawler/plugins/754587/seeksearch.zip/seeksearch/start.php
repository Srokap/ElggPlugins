<?php
	/**
	 * Override normal search with a site specific seeks search.
	 *
	 * @author psy <lorea.org>
	 * @copyright lorea.org 2011 
	 * @license GNU Public License version 2
	 */
	

	function seeksearch_init()
	{
    	global $CONFIG;
    
    	// Handle some specific pages
		register_page_handler('search','seeksearch_pagehandler');		

		// Extend css
		extend_view('css','seeksearch/css');
	}
	
	function seeksearch_pagehandler($page)
	{
		global $CONFIG;
		
		include($CONFIG->pluginspath . "seeksearch/index.php"); 
	}
	
		
	register_elgg_event_handler('init','system','seeksearch_init');

?>
