<?php

	$english = array(
		'seeksearch' => 'Seeks search',
	
		'seeksearch:poweredby' => 'Powered by Seeks',
		'seeksearch:cached' => 'Cached',
	);
					
	add_translation("en",$english);

?>
