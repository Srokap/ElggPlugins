<?php
	$entity = $vars['entity'];
?>
<div class="search_result">
	<div class="seeks_search_result">
		<div class="seeks_search_result_title"><u><?php echo $entity->title; ?></u></div>
	        <div class ="seeks_search_result_content"><?php echo elgg_view('output/url', array('value' => $entity->url, 'text' => $entity->cite)); ?></div>
		<div class="seeks_search_result_content"><?php echo $entity->summary; ?> <?php echo elgg_view('output/url', array('value' => $entity->cached, 'text' => elgg_echo('seeksearch:cached'))); ?></div><br />
	</div>
</div>
