.search_result {
	padding-bottom: 5px;
	padding-left: 5px;
}
.seeks_search_result_title {
        padding-left: 5px;
}
.seeks_search_result_content {
        padding-left: 5px;
}
