<div style="margin-left: 5px;"><id="node"><p>node: <a href="https://dev.lorea.org:8081">dev.lorea.org</a></p></div>
<?php

	$results = $vars['results'];
	$seek_results = array();
	$i = 0;
	if ($results)
	{
		foreach ($results->snippets as $result)
		{
			$tmp = new ElggObject();
			foreach ($result as $key => $value) {
				$tmp->$key = $value;
			}

			$tmp->type = "object";
			$tmp->subtype = "searchresult";

			$seek_results[] = $tmp;
	        $i += 1;
		}
	    $num_results = $i;
		//echo "<pre>" . print_r($seek_results, true) . "</pre>";
		echo elgg_view_entity_list($seek_results, $num_results, get_input('offset', 0), 8, true, false);

	}
?>
<!--<div id="poweredby"><p><?php echo elgg_echo('seeksearch:poweredby'); ?></p></div>-->
<div style="margin-left: 5px;"><id="poweredby"><p>Powered by: <a href="http://seeks-project.info/">Seeks</a></p></div>

