<?php
	require_once(dirname(dirname(dirname(__FILE__))) . '/engine/start.php');

	global $CONFIG;
	
	$host = parse_url($CONFIG->wwwroot);
	$start = "";
	if (get_input('offset'))
		$start = "&start=" . get_input('offset');
	
	$tag = get_input('tag');
	$results = file_get_contents('http://dev.lorea.org:8081/search?expansion=1&action=expand&output=json&q=' . urlencode("$tag"). $start);
	$results = json_decode($results);
	
	$body = elgg_view('seeksearch/form/search', array('results' => $results));
	
	page_draw(elgg_echo('seeksearch'), elgg_view_layout("one_column", $body));
?>
