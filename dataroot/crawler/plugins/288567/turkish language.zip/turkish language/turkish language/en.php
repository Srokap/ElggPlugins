<?php

	$english = array(

		/**
		 * Sites
		 */
	
			'item:site' => 'Sites',
	
		/**
		 * Sessions
		 */
			
			'login' => "Giris Yap",
			'loginok' => "Giri&#351; Yapt&#305;n&#305;z.",
			'loginerror' => "Giri&#351; ba&#351;ar&#305;s&#305;z. Bunun nedeni hesab&#305;n&#305;z&#305; aktifle&#351;tirmemi&#351; olman&#305;z olabilir, yada girmi&#351; oldu&#287;unuz detaylar hatal&#305;.",
	
			'logout' => "&#199;&#305;k&#305;&#351; Yap",
			'logoutok' => "Ba&#351;ar&#305;yla &#231;&#305;k&#305;&#351; yapt&#305;n&#305;z.",
			'logouterror' => "&#199;&#305;k&#305;&#351; yap&#305;lamad&#305;. L&#252;tfen taray&#305;c&#305; &#231;erezlerini temizleyiniz.",
	
		/**
		 * Errors
		 */
			'exception:title' => "Hosgeldiniz !",
	
			'InstallationException:CantCreateSite' => "Unable to create a default ElggSite with credentials Name:%s, Url: %s",
		
			'actionundefined' => "&#304;ste&#287;inizi ger&#231;ekle&#351;tiremiyorum (%s) sistemde tan&#305;ml&#305; bir i&#351;lem de&#287;il.",
			'actionloggedout' => "#220;zg&#252;n&#252;z, bu i&#351;lemi ger&#231;ekle&#351;tirmek i&#231;in giri&#351; yapmal&#305;s&#305;n&#305;z.",
	
			'notfound' => "Arad&#305;&#287;&#305;n&#305;z kayna&#287;a ula&#351;&#305;lam&#305;yor, yada ula&#351;maya yetkiniz yok.",
			
			'SecurityException:Codeblock' => "Denied access to execute privileged code block",
			'DatabaseException:WrongCredentials' => "Elgg database e ba&#287;lanam&#305;yor bu verilen bilgilerle %s@%s (pw: %s).",
			'DatabaseException:NoConnect' => "Elgg database'i secemiyor '%s', lutfen database'i kontrol edin ve tekrar deneyin.",
			'SecurityException:FunctionDenied' => "Access to privileged function '%s' is denied.",
			'DatabaseException:DBSetupIssues' => "There were a number of issues: ",
			'DatabaseException:ScriptNotFound' => "Elgg couldn't find the requested database script at %s.",
			
			'IOException:FailedToLoadGUID' => "Failed to load new %s from GUID:%d",
			'InvalidParameterException:NonElggObject' => "Passing a non-ElggObject to an ElggObject constructor!",
			'InvalidParameterException:UnrecognisedValue' => "Unrecognised value passed to constuctor.",
			
			'InvalidClassException:NotValidElggStar' => "GUID:%d is not a valid %s",
			
			'PluginException:MisconfiguredPlugin' => "%s is a misconfigured plugin.",
			
			'InvalidParameterException:NonElggUser' => "Passing a non-ElggUser to an ElggUser constructor!",
			
			'InvalidParameterException:NonElggSite' => "Passing a non-ElggSite to an ElggSite constructor!",
			
			'InvalidParameterException:NonElggGroup' => "Passing a non-ElggGroup to an ElggGroup constructor!",
	
			'IOException:UnableToSaveNew' => "Unable to save new %s",
			
			'InvalidParameterException:GUIDNotForExport' => "GUID has not been specified during export, this should never happen.",
			'InvalidParameterException:NonArrayReturnValue' => "Entity serialisation function passed a non-array returnvalue parameter",
			
			'ConfigurationException:NoCachePath' => "Cache path set to nothing!",
			'IOException:NotDirectory' => "%s is not a directory.",
			
			'IOException:BaseEntitySaveFailed' => "Unable to save new object's base entity information!",
			'InvalidParameterException:UnexpectedODDClass' => "import() passed an unexpected ODD class",
			'InvalidParameterException:EntityTypeNotSet' => "Entity type must be set.",
			
			'ClassException:ClassnameNotClass' => "%s is not a %s.",
			'ClassNotFoundException:MissingClass' => " '%s' bulunamad&#305;, eksik eklenti sorunu?",
			'InstallationException:TypeNotSupported' => "Type %s is not supported. This indicates an error in your installation, most likely caused by an incomplete upgrade.",

			'ImportException:ImportFailed' => "Could not import element %d",
			'ImportException:ProblemSaving' => "&#351;unu kaydederken problem var %s",
			'ImportException:NoGUID' => "New entity created but has no GUID, this should not happen.",
			
			'ImportException:GUIDNotFound' => "Entity '%d' bulunamad&#305;.",
			'ImportException:ProblemUpdatingMeta' => "There was a problem updating '%s' on entity '%d'",
			
			'ExportException:NoSuchEntity' => "No such entity GUID:%d", 
			
			'ImportException:NoODDElements' => "No OpenDD elements found in import data, import failed.",
			'ImportException:NotAllImported' => "Not all elements were imported.",
			
			'InvalidParameterException:UnrecognisedFileMode' => "Unrecognised file mode '%s'",
			'InvalidParameterException:MissingOwner' => "All files must have an owner!",
			'IOException:CouldNotMake' => "Could not make %s",
			'IOException:MissingFileName' => "You must specify a name before opening a file.",
			'ClassNotFoundException:NotFoundNotSavedWithFile' => "Filestore not found or class not saved with file!",
			'NotificationException:NoNotificationMethod' => "No notification method specified.",
			'NotificationException:NoHandlerFound' => "No handler found for '%s' or it was not callable.",
			'NotificationException:ErrorNotifyingGuid' => "There was an error while notifying %d",
			'NotificationException:NoEmailAddress' => "Could not get the email address for GUID:%d",
			'NotificationException:MissingParameter' => "Missing a required parameter, '%s'",
			
			'DatabaseException:WhereSetNonQuery' => "Where set contains non WhereQueryComponent",
			'DatabaseException:SelectFieldsMissing' => "Fields missing on a select style query",
			'DatabaseException:UnspecifiedQueryType' => "Unrecognised or unspecified query type.",
			'DatabaseException:NoTablesSpecified' => "No tables specified for query.",
			'DatabaseException:NoACL' => "No access control was provided on query",
			
			'InvalidParameterException:NoEntityFound' => "No entity found, it either doesn't exist or you don't have access to it.",
			
			'InvalidParameterException:GUIDNotFound' => "GUID:%s could not be found, or you can not access it.",
			'InvalidParameterException:IdNotExistForGUID' => "Sorry, '%s' does not exist for guid:%d",
			'InvalidParameterException:CanNotExportType' => "Sorry, I don't know how to export '%s'",
			'InvalidParameterException:NoDataFound' => "Could not find any data.",
			'InvalidParameterException:DoesNotBelong' => "Does not belong to entity.",
			'InvalidParameterException:DoesNotBelongOrRefer' => "Does not belong to entity or refer to entity.",
			'InvalidParameterException:MissingParameter' => "Missing parameter, you need to provide a GUID.",
			
			'SecurityException:APIAccessDenied' => "Sorry, API access has been disabled by the administrator.",
			'SecurityException:NoAuthMethods' => "No authentication methods were found that could authenticate this API request.",
			'APIException:ApiResultUnknown' => "API Result is of an unknown type, this should never happen.", 
			
			'ConfigurationException:NoSiteID' => "No site ID has been specified.",
			'InvalidParameterException:UnrecognisedMethod' => "Unrecognised call method '%s'",
			'APIException:MissingParameterInMethod' => "Missing parameter %s in method %s",
			'APIException:ParameterNotArray' => "%s does not appear to be an array.",
			'APIException:UnrecognisedTypeCast' => "Unrecognised type in cast %s for variable '%s' in method '%s'",
			'APIException:InvalidParameter' => "Invalid parameter found for '%s' in method '%s'.",
			'APIException:FunctionParseError' => "%s(%s) has a parsing error.",
			'APIException:FunctionNoReturn' => "%s(%s) returned no value.",
			'SecurityException:AuthTokenExpired' => "Authentication token either missing, invalid or expired.",
			'CallException:InvalidCallMethod' => "%s must be called using '%s'",
			'APIException:MethodCallNotImplemented' => "Method call '%s' has not been implemented.",
			'APIException:AlgorithmNotSupported' => "Algorithm '%s' is not supported or has been disabled.",
			'ConfigurationException:CacheDirNotSet' => "Cache directory 'cache_path' not set.",
			'APIException:NotGetOrPost' => "Request method must be GET or POST",
			'APIException:MissingAPIKey' => "Missing X-Elgg-apikey HTTP header",
			'APIException:MissingHmac' => "Missing X-Elgg-hmac header",
			'APIException:MissingHmacAlgo' => "Missing X-Elgg-hmac-algo header",
			'APIException:MissingTime' => "Missing X-Elgg-time header",
			'APIException:TemporalDrift' => "X-Elgg-time is too far in the past or future. Epoch fail.",
			'APIException:NoQueryString' => "No data on the query string",
			'APIException:MissingPOSTHash' => "Missing X-Elgg-posthash header",
			'APIException:MissingPOSTAlgo' => "Missing X-Elgg-posthash_algo header",
			'APIException:MissingContentType' => "Missing content type for post data",
			'SecurityException:InvalidPostHash' => "POST data hash is invalid - Expected %s but got %s.",
			'SecurityException:DupePacket' => "Packet signature already seen.",
			'SecurityException:InvalidAPIKey' => "Invalid or missing API Key.",
			'NotImplementedException:CallMethodNotImplemented' => "Call method '%s' is currently not supported.",
	
			'NotImplementedException:XMLRPCMethodNotImplemented' => "XML-RPC method call '%s' not implemented.",
			'InvalidParameterException:UnexpectedReturnFormat' => "Call to method '%s' returned an unexpected result.",
			'CallException:NotRPCCall' => "Call does not appear to be a valid XML-RPC call",
	
			'PluginException:NoPluginName' => "The plugin name could not be found",
	
			'ConfigurationException:BadDatabaseVersion' => "The database backend you have installed doesn't meet the basic requirements to run Elgg. Please consult your documentation.",
			'ConfigurationException:BadPHPVersion' => "You need at least PHP version 5.2 to run Elgg.",
			'configurationwarning:phpversion' => "Elgg requires at least PHP version 5.2, you can install it on 5.1.6 but some features may not work. Use at your own risk.",
	
	
			'InstallationException:DatarootNotWritable' => "Your data directory %s is not writable.",
			'InstallationException:DatarootUnderPath' => "Your data directory %s must be outside of your install path.",
			'InstallationException:DatarootBlank' => "You have not specified a data directory.",
	
			'SecurityException:authenticationfailed' => "User could not be authenticated",
	
			'CronException:unknownperiod' => '%s is not a recognised period.',
	
			'SecurityException:deletedisablecurrentsite' => 'You can not delete or disable the site you are currently viewing!',
	
			'memcache:notinstalled' => 'PHP memcache module not installed, you must install php5-memcache',
			'memcache:noservers' => 'No memcache servers defined, please populate the $CONFIG->memcache_servers variable',
			'memcache:versiontoolow' => 'Memcache needs at least version %s to run, you are running %s',
			'memcache:noaddserver' => 'Multiple server support disabled, you may need to upgrade your PECL memcache library',
	
			'deprecatedfunction' => 'Warning: This code uses the deprecated function \'%s\' and is not compatible with this version of Elgg',
		/**
		 * API
		 */
			'system.api.list' => "List all available API calls on the system.",
			'auth.gettoken' => "This API call lets a user log in, returning an authentication token which can be used in leu of a username and password for authenticating further calls.",
	
		/**
		 * User details
		 */

			'name' => "G&#246;r&#252;nen &#304;sim",
			'email' => "Email Adresi",
			'username' => "Kullan&#305;c&#305; Ad&#305;",
			'password' => "&#350;ifre",
			'passwordagain' => "&#350;ifre (do&#287;rulama i&#231;in)",
			'admin_option' => "Kullan&#305;c&#305; Adminmi?",
	
		/**
		 * Access
		 */
	
			'PRIVATE' => "Gizli",
			'LOGGED_IN' => "Kay&#305;tl&#305; Kullan&#305;c&#305;lar",
			'PUBLIC' => "Herkes",
			'access:friends:label' => "Arkada&#351;lar",
			'access' => "Eri&#351;im",
	
		/**
		 * Dashboard and widgets
		 */
	
			'dashboard' => "Anasayfam",
            'dashboard:configure' => "Edit page",
			'dashboard:nowidgets' => "Ho&#351;geldiniz! Anasayfam sizin ba&#351;lang&#305;&#231; noktan&#305;zd&#305;r. 'Sayfa D&#252;zenle' linkine t&#305;klayarak Anasayfan&#305;za Widgetler ekleyebilirsiniz.B&#246;ylece sitede olan bitenlerden daha kolay haberdar olursunuz.",

			'widgets:add' => 'Sayfan&#305;za Widget Ekleyin',
			'widgets:add:description' => "Eklemek istedi&#287;iniz &#246;zelli&#287;i Widgetleri s&#252;r&#252;kle b&#305;rak y&#246;ntemi ile sayfan&#305;za ekleyebilirsiniz <b>Widget Galerisi</b> sa&#287;da bulunmaktad&#305;r, sizlere ayr&#305;lm&#305;&#351; &#252;&#231; b&#246;l&#252;m mevcuttur buralara diledi&#287;iniz widgetleri yerle&#351;tirebilirsiniz.

Widgeti kald&#305;rmak i&#231;in tekrar geri s&#252;r&#252;kleyiniz <b>Widget Galerisi</b>.",
			'widgets:position:fixed' => '(sabit pozisyonda)',
	
			'widgets' => "Widgetler",
			'widget' => "Widget",
			'item:object:widget' => "Widgetler",
			'layout:customise' => "G&#246;r&#252;n&#252;m&#252; De&#287;i&#351;tir",
			'widgets:gallery' => "Widget Galerisi",
			'widgets:leftcolumn' => "Sol Widgetler",
			'widgets:fixed' => "Sabit Pozisyonda",
			'widgets:middlecolumn' => "Orta Widgetler",
			'widgets:rightcolumn' => "Sa&#287; Widgetler",
			'widgets:profilebox' => "Profil Kutusu",
			'widgets:panel:save:success' => "Widgetler ba&#351;ar&#305;yla kaydedildi.",
			'widgets:panel:save:failure' => "Widgetleri saklarken bir hata olu&#351;tu. L&#252;tfen tekrar deneyiniz.",
			'widgets:save:success' => "Widget ba&#351;ar&#305;yla eklendi.",
			'widgets:save:failure' => "Widgetleri saklarken bir hata olu&#351;tu. L&#252;tfen tekrar deneyiniz",
			'widgets:handlernotfound' => 'This widget is either broken or has been disabled by the site administrator.',
	
		/**
		 * Groups
		 */
	
			'group' => "Group", 
			'item:group' => "Grouplar",
	
		/**
		 * Profile
		 */
	
			'profile' => "Profil",
			'profile:edit:default' => 'Replace profile fields',
			'user' => "User",
			'item:user' => "Users",
			'riveritem:single:user' => 'a user',
			'riveritem:plural:user' => 'some users',
	

		/**
		 * Profile menu items and titles
		 */
	
			'profile:yours' => "Profiliniz",
			'profile:user' => "%s Profili",
	
			'profile:edit' => "Profil D&#252;zenle",
			'profile:profilepictureinstructions' => "Profil resmi profilinizde g&#246;r&#252;necek olan resimdir. <br /> &#304;stedi&#287;iniz s&#305;kl&#305;kta de&#287;i&#351;tirebilirsiniz. (Desteklenen Dosya T&#252;rleri: GIF, JPG or PNG)",
			'profile:icon' => "Profil Resmi",
			'profile:createicon' => "Profil Resmini Yarat",
			'profile:currentavatar' => "Current avatar",
			'profile:createicon:header' => "Profile picture",
			'profile:profilepicturecroppingtool' => "Profile picture cropping tool",
			'profile:createicon:instructions' => "Click and drag a square below to match how you want your picture cropped.  A preview of your cropped picture will appear in the box on the right.  When you are happy with the preview, click 'Create your avatar'. This cropped image will be used throughout the site as your avatar. ",
	
			'profile:editdetails' => "Edit details",
			'profile:editicon' => "Edit profile icon",
	
			'profile:aboutme' => "About me", 
			'profile:description' => "About me",
			'profile:briefdescription' => "Brief description",
			'profile:location' => "Location",
			'profile:skills' => "Skills",  
			'profile:interests' => "Interests", 
			'profile:contactemail' => "Contact email",
			'profile:phone' => "Telephone",
			'profile:mobile' => "Mobile phone",
			'profile:website' => "Website",
	
			'profile:banned' => 'This user account has been suspended.',

			'profile:river:update' => "%s updated their profile",
			'profile:river:iconupdate' => "%s updated their profile icon",
	
			'profile:label' => "Profile label",
			'profile:type' => "Profile type",
	
			'profile:editdefault:fail' => 'Default profile could not be saved',
			'profile:editdefault:success' => 'Item successfully added to default profile',
	
			
			'profile:editdefault:delete:fail' => 'Removed default profile item field failed',
			'profile:editdefault:delete:success' => 'Default profile item deleted!',
	
			'profile:defaultprofile:reset' => 'Default system profile reset',
	
			'profile:resetdefault' => 'Reset default profile',
	
		/**
		 * Profile status messages
		 */
	
			'profile:saved' => "Your profile was successfully saved.",
			'profile:icon:uploaded' => "Your profile picture was successfully uploaded.",
	
		/**
		 * Profile error messages
		 */
	
			'profile:noaccess' => "You do not have permission to edit this profile.",
			'profile:notfound' => "Sorry; we could not find the specified profile.",
			'profile:cantedit' => "Sorry; you do not have permission to edit this profile.",
			'profile:icon:notfound' => "Sorry; there was a problem uploading your profile picture.",
	
		/**
		 * Friends
		 */
	
			'friends' => "Arkada&#351;lar&#305;m",
			'friends:yours' => "Arkada&#351;lar&#305;n",
			'friends:owned' => "%s Arkada&#351;lar&#305;",
			'friend:add' => "Arkada&#351; Ekle",
			'friend:remove' => "Arkada&#351; Sil",
	
			'friends:add:successful' => "%s ba&#351;ar&#305;yla Arkada&#351;lar&#305;n&#305;za eklendi.",
			'friends:add:failure' => "%s eklenemiyor,L&#252;tfen daha sonra tekrar deneyiniz.",
	
			'friends:remove:successful' => "%s arkada&#351;lar&#305;n&#305;zdan silindi.",
			'friends:remove:failure' => "%s arkada&#351;lar&#305;n&#305;zdan silinemiyor,L&#252;tfen daha sonra tekrar deneyiniz.",
	
			'friends:none' => "Bu kullan&#305;c&#305; hen&#252;z kimseyi arkada&#351;&#305; olarak eklemedi.",
			'friends:none:you' => "Hi&#231; arkada&#351; eklemediniz! Arama yaparak arkada&#351;lar&#305;n&#305;za ula&#351;abilirsiniz.",
	
			'friends:none:found' => "Hiz arkada&#351; bulunamad&#305;.",
	
			'friends:of:none' => "Bu kullan&#305;c&#305; kimse taraf&#305;ndan arkada&#351; olarak eklenmedi.",
			'friends:of:none:you' => "Kimse sizi hen&#252;z arkada&#351; olarak eklemedi. Profil alanlar&#305;n&#305;z&#305; doldurarak sizi arayan arkada&#351;lar&#305;n&#305;z&#305; size daha kolay ula&#351;mas&#305;n&#305; sa&#287;layabilirsiniz!",
	
			'friends:of:owned' => "%s adl&#305; kullan&#305;c&#305;n&#305;n arkada&#351;lar&#305;",

			 'friends:num_display' => "G&#246;r&#252;nt&#252;lenmesini istedi&#287;iniz arkada&#351; say&#305;s&#305;",
			 'friends:icon_size' => "Icon boyutu",
			 'friends:tiny' => "ince",
			 'friends:small' => "k&#252;&#231;&#252;k",
			 'friends:of' => "rkada&#351;lar&#305;",
			 'friends:collections' => "Arkada&#351; Grubu",
			 'friends:collections:add' => "Yeni Arkada&#351; Grubu",
			 'friends:addfriends' => "Arkada&#351;lar&#305;n&#305; Ekle",
			 'friends:collectionname' => "Arkada&#351; Grubunuzun Ad&#305",
			 'friends:collectionfriends' => "Gruptaki Arkada&#351;lar",
			 'friends:collectionedit' => "Bu Grubu D&#252;zenle",
			 'friends:nocollections' => "Hi&#231; Arkada&#351; Grubunuz Yok..",
			 'friends:collectiondeleted' => "Arkada&#351; Grubu Silindi.",
			 'friends:collectiondeletefailed' => "Arkada&#351; Grubu silinemedi,Bu i&#351;lem i&#231;in yetkiniz yok yada bir hata buna engel oldu,L&#252;tfen daha sonra tekrar deneyiniz.",
			 'friends:collectionadded' => "rkada&#351; Grubunuz Ba&#351;ar&#305;yla Olu&#351;turuldu",
			 'friends:nocollectionname' => "Y&#214;nce Arkada&#351; Grubunuza bir isim vermelisiniz.",
			'friends:collections:members' => "Collection members",
			'friends:collections:edit' => "Edit collection",
		
	        'friends:river:created' => "%s arkada&#351;lar wingetini ekledi.",
	        'friends:river:updated' => "%s arkada&#351;lar widgetini g&#252;ncelledi.",
	        'friends:river:delete' => "%s arkada&#351;lar widgetini kald&#305;rd&#305;.",
	        'friends:river:add' => "%s birilerini arkada&#351; olarak ekledi.",
	
			'friendspicker:chararray' => 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
	
		/**
		 * Feeds
		 */
			'feed:rss' => 'Beslemelere Abone Ol',
			'feed:odd' => 'Syndicate OpenDD',
			
		/**
          * links
		 **/

			'link:view' => 'view link',

	
		/**
		 * River
		 */
			'river' => "G&#246;l",			
			'river:relationship:friend' => '&#351;u anda arkada&#351; oldular',
			'river:noaccess' => 'You do not have permission to view this item.',
			'river:posted:generic' => '%s posted',

		/**
		 * Plugins
		 */
			'plugins:settings:save:ok' => "%s eklentisi ayarlar&#305; kaydedildi.",
			'plugins:settings:save:fail' => "T%s eklentisi ayarlar&#305; kaydedilemedi,Ayarlar&#305; kaydederken bir hata olu&#351;tu .",
			'plugins:usersettings:save:ok' => "%s eklentisinde yapm&#305;&#351; oldu&#287;unuz de&#287;i&#351;iklikler kaydedildi.",
			'plugins:usersettings:save:fail' => "%s eklentisi ayarlar&#305; kaydedilemedi,Ayarlar&#305; kaydederken bir hata olu&#351;tu .",
			'admin:plugins:label:version' => "Version",
			'item:object:plugin' => 'Plugin configuration settings',
			
		/**
		 * Notifications
		 */
			'notifications:usersettings' => "Bildirim Ayarlar&#305;",
			'notifications:methods' => "L&#252;tfen hangi methodlara izin verdi&#287;inizi belirtiniz.",
	
			'notifications:usersettings:save:ok' => "Bildirim ayarlar&#305;n&#305;z de&#287;i&#351;tirildi .",
			'notifications:usersettings:save:fail' => "Bildirim ayarlar&#305; de&#287;i&#351;tirilemiyor.",
	
			'user.notification.get' => 'Return the notification settings for a given user.',
			'user.notification.set' => 'Set the notification settings for a given user.',
		/**
		 * Search
		 */
	
			'search' => "Ara",
			'searchtitle' => "Ara: %s",
			'users:searchtitle' => "Searching for users: %s",
			'advancedsearchtitle' => "%s tutan sonu&#231;lar %s",
			'notfound' => "Hi&#231;bir sonu&#231; bulunamad&#305;.",
			'next' => "Sonraki",
			'previous' => "&#214;nceki",
	
			'viewtype:change' => "Listeleme D&#252;zenini De&#287;i&#351;tir",
			'viewtype:list' => "Liste G&#246;r&#252;n&#252;m&#252;",
			'viewtype:gallery' => "Galeri G&#246;r&#252;n&#252;m&#252;",
	
			'tag:search:startblurb' => "Uyu&#351;an Etiketler '%s':",

			'user:search:startblurb' => "Uyu&#351;an Kullan&#305;c&#305;lar '%s':",
			'user:search:finishblurb' => "Daha fazla g&#246;r&#252;nt&#252;lemek i&#231;in t&#305;klay&#305;n&#305;z.",
	
		/**
		 * Account
		 */
	
			'account' => "Hesap",
			'settings' => "Ayarlar",
            'tools' => "Tools",
            'tools:yours' => "Your tools",
	
			'register' => "Kay&#305;t Ol",
			'registerok' => "Ba&#351;ar&#305;yla kayd&#305;n&#305;z al&#305;nd&#305; %s. Hesab&#305;n&#305;z&#305; aktive etmek i&#231;in size yollanan maildeki aktivasyon linkine t&#305;klay&#305;n&#305;z.",
			'registerbad' => "Kayd&#305;n&#305;z al&#305;n&#305;rken bir hata olu&#351;tu. Kullan&#305;c&#305; ad&#305; &#246;nceden al&#305;nm&#305;&#351; olabilir, &#350;ifreniz uyu&#351;muyor olabilir, yada kullan&#305;c&#305; ad&#305; ve &#351;ifreniz izin verilenden daha k&#305;sa.",
			'registerdisabled' => "&#220;ye Kayd&#305; &#351;u an i&#231;in kapat&#305;lm&#305;&#351;t&#305;r",
	
			'firstadminlogininstructions' => 'Your new Elgg site has been successfully installed and your administrator account created. You can now configure your site further by enabling various installed plugin tools.',
	
			'registration:notemail' => 'Belirtti&#287;iniz mail adresi ge&#231;erli olarak g&#246;r&#252;nm&#252;yor.',
			'registration:userexists' => 'Bu kullan&#305;c&#305; ad&#305; daha &#246;nce al&#305;nm&#305;&#351;',
			'registration:usernametooshort' => 'Kullan&#305;c&#305; ad&#305; en az 4 haneli olmal&#305;.',
			'registration:passwordtooshort' => '&#350;ifre en az 6 karakter uzunlu&#287;unda olmal&#305;.',
			'registration:dupeemail' => 'Bu mail adresi ile &#246;nceden kay&#305;t yap&#305;lm&#305;&#351;.',
			'registration:invalidchars' => 'Sorry, your username contains invalid characters.',
			'registration:emailnotvalid' => 'Sorry, the email address you entered is invalid on this system',
			'registration:passwordnotvalid' => 'Sorry, the password you entered is invalid on this system',
			'registration:usernamenotvalid' => 'Sorry, the username you entered is invalid on this system',
	
			'adduser' => "Kullan&#305;c&#305; Ekle",
			'adduser:ok' => "Ba&#351;ar&#305;yla yeni bir kullan&#305;c&#305; eklediniz.",
			'adduser:bad' => "Kullan&#305;c&#305; olu&#351;turulamad&#305;.",
			
			'item:object:reported_content' => "Rapor Edilenler",
	
			'user:set:name' => "Kullan&#305;c&#305; Ad&#305; Ayarlar&#305;",
			'user:name:label' => "&#304;sminiz",
			'user:name:success' => "Sistemdeki isminiz ba&#351;ar&#305;yla de&#287;i&#351;tirildi.",
			'user:name:fail' => "&#304;sminiz de&#287;i&#351;tirilemedi.",
	
			'user:set:password' => "Hesap &#350;ifreniz",
			'user:password:label' => "Yeni &#350;ifreniz",
			'user:password2:label' => "Yeni &#350;ifrenizin Tekrar&#305;",
			'user:password:success' => "&#350;ifre De&#287;i&#351;tirildi",
			'user:password:fail' => "&#350;ifre de&#287;i&#351;tirilemiyor.",
			'user:password:fail:notsame' => "&#350;ifreler uyu&#351;muyor!",
			'user:password:fail:tooshort' => "&#350;ifre &#199;ok K&#305;sa!",
	
			'user:set:language' => "Dil Ayarlar&#305;",
			'user:language:label' => "Kulland&#305;&#287;&#305;n&#305;z Dil",
			'user:language:success' => "Dil ayarlar&#305;n&#305;z ba&#351;ar&#305;yla kaydedildi",
			'user:language:fail' => "Dil ayarlar&#305;n&#305;z kaydedilemedi.",
	
			'user:username:notfound' => 'Kullan&#305;c&#305; Ad&#305; %s Bulunamad&#305;.',
	
			'user:password:lost' => 'Kay&#305;p &#350;ifre',
			'user:password:resetreq:success' => 'SYeni &#351;ifreniz i&#231;in mail adresinize gelen linke t&#305;klay&#305;n&#305;z.',
			'user:password:resetreq:fail' => 'Yeni &#351;ifre talebinizi &#351;u anda ger&#231;ekle&#351;tiremiyorum.',
	
			'user:password:text' => 'Yeni &#351;ifre olu&#351;turmak i&#231;in kullan&#305;c&#305; ad&#305;n&#305;z&#305; giriniz. Email adresinize tek defaya mahsus bir link g&#246;nderece&#287;iz bu linkin devam&#305;nda &#351;ifrenizi de&#287;i&#351;tirebilirsiniz.',
	
			'user:persistent' => 'Beni Hat�rla',
		/**
		 * Administration
		 */

			'admin:configuration:success' => "Ayarlar&#305;n&#305;z Kaydedildi.",
			'admin:configuration:fail' => "Ayarlar&#305;n&#305;z Kaydedilemedi.",
	
			'admin' => "Y&#246;netim",
			'admin:description' => "The admin panel allows you to control all aspects of the system, from user management to how plugins behave. Choose an option below to get started.",
			
			'admin:user' => "Kullan&#305;c&#305; Y&#246;netimi",
			'admin:user:description' => "This admin panel allows you to control user settings for your site. Choose an option below to get started.",
			'admin:user:adduser:label' => "Yeni bir &#252;ye eklemek i&#199;&#305;in t&#305;klay&#305;n...",
			'admin:user:opt:linktext' => "&#252;yeleri yap&#305;land&#305;r...",
			'admin:user:opt:description' => "Hesap bilgilerini ve &#252;yeleri yap&#305;land&#305;r. ",
			
			'admin:site' => "Site Y&#246;netim Panel",
			'admin:site:description' => "Bu y&ouml;netici paneli, site i&ccedil;i genel ayarlarin kontrolunu saglar.Baslamak i&ccedil;in asagidaki se&ccedil;eneklerden birini se&ccedil;in.",
			'admin:site:opt:linktext' => "Siteyi yap&#305;land&#305;r",
			'admin:site:opt:description' => "Configure the site technical and non-technical settings.",
			'admin:site:access:warning' => "Changing the access setting only affects the permissions on content created in the future.", 
			
			'admin:plugins' => "Tool Administration",
			'admin:plugins:description' => "Bu panel sitenize eklenti ve tema y&#252;klemenizde yard&#305;mc&#305; olur.",
			'admin:plugins:opt:linktext' => "Eklentileri yap&#305;land&#305;r...",
			'admin:plugins:opt:description' => "Configure the tools installed on the site. ",
			'admin:plugins:label:author' => "Yap&#305;mc&#305;",
			'admin:plugins:label:copyright' => "Copyright",
			'admin:plugins:label:licence' => "Licence",
			'admin:plugins:label:website' => "URL",
			'admin:plugins:label:moreinfo' => 'more info',
			'admin:plugins:label:version' => 'Version',
			'admin:plugins:warning:elggversionunknown' => 'Warning: This plugin does not specify a compatible Elgg version.',
			'admin:plugins:warning:elggtoolow' => 'Warning: This plugin requires a later version of Elgg!',
			'admin:plugins:reorder:yes' => "Plugin %s was reordered successfully.",
			'admin:plugins:reorder:no' => "Plugin %s could not be reordered.",
			'admin:plugins:disable:yes' => "Eklenti %s ba&#351;ar&#305;yla deaktifle&#351;tirildi.",
			'admin:plugins:disable:no' => "Eklenti %s deaktifle&#351;tirilemedi.",
			'admin:plugins:enable:yes' => "Eklenti %s ba&#351;ar&#305;yla aktifle&#351;tirildi.",
			'admin:plugins:enable:no' => "Eklenti %s aktifle&#351;tirilemedi.",
	
			'admin:statistics' => "Istatistikler",
			'admin:statistics:description' => "Bu basit bir istatistik diyagram&#305; E&#287;er daha fazla detaya ihtiyac&#305;n&#305;z varsa, profesy&#246;nel admin &#246;zellikleri bulunmaktad&#305;r.",
			'admin:statistics:opt:description' => "Uyelerle ve objelerle ilgili istatistiklere bak.",
			'admin:statistics:opt:linktext' => "Istatistiklere bak...",
			'admin:statistics:label:basic' => "Basit site istatistikleri",
			'admin:statistics:label:numentities' => "Entities on site",
			'admin:statistics:label:numusers' => "Toplam &#252;ye say&#305;s&#305;",
			'admin:statistics:label:numonline' => "Online &#252;ye say&#305;s&#305;",
			'admin:statistics:label:onlineusers' => "Siteniz'de kimler geziyor?",
			'admin:statistics:label:version' => "Elgg version",
			'admin:statistics:label:version:release' => "Release",
			'admin:statistics:label:version:version' => "Version",
	
			'admin:user:label:search' => "Uyeleri Bul:",
			'admin:user:label:seachbutton' => "Ara", 
	
			'admin:user:ban:no' => "&#252;ye banlanam&#305;yor",
			'admin:user:ban:yes' => "&#252;ye banlad&#305;.",
			'admin:user:unban:no' => "&#252;yenin ban&#305; kald&#305;r&#305;lamad&#305;",
			'admin:user:unban:yes' => "&#252;yenin ban&#305; kald&#305;r&#305;ld&#305;.",
			'admin:user:delete:no' => "&#252;ye silinemedi.",
			'admin:user:delete:yes' => "&#252;ye silindi",
	
			'admin:user:resetpassword:yes' => "&#351;ifre resetlendi &#252;ye bilgilendirildi.",
			'admin:user:resetpassword:no' => "&#351;ifre resetlenemedi.",
	
			'admin:user:makeadmin:yes' => "&#252;ye art&#305;k admin.",
			'admin:user:makeadmin:no' => "&#252;ye admin admin yap&#305;lamad&#305;..",
	
			'admin:user:removeadmin:yes' => "User is no longer an admin.",
			'admin:user:removeadmin:no' => "We could not remove administrator privileges from this user.",
			
		/**
		 * User settings
		 */
			'usersettings:description' => "u Kullan&#305;c&#305; Ayarlar&#305; paneli size t&#252;m ki&#351;isel ayarlar&#305;n&#305;z&#305; d&#252;zenleme olana&#287;&#305; verir, kullan&#305;c&#305; denetiminden eklentilerin davran&#305;&#351;lar&#305;na kadar bir &#231;ok ayar buradad&#305;r. Ba&#351;lamak i&#231;in bir se&#231;enek se&#231;iniz.",
	
			'usersettings:statistics' => "&#304;statistikleriniz",
			'usersettings:statistics:opt:description' => "Sitedeki kullan&#305;c&#305;lar ve di&#287;er her&#351;eyle ilgili bilgiler.",
			'usersettings:statistics:opt:linktext' => "Hesap Ayarlar&#305;",
	
			'usersettings:user' => "Ayarlar&#305;n&#305;z",
			'usersettings:user:opt:description' => "Kullan&#305;c&#305; ayarlar&#305;n&#305;z&#305; de&#287;i&#351;tirmenize yard&#305;mc&#305; olur.",
			'usersettings:user:opt:linktext' => "Ayarlar&#305; de&#287;i&#351;tir",
	
			'usersettings:plugins' => "Ara&#231;lar",
			'usersettings:plugins:opt:description' => "Aktif olan ara&#231;lar i&#231;in ayarlar&#305; de&#287;i&#351;tir.",
			'usersettings:plugins:opt:linktext' => "Ara&#231;lar&#305;n&#305;z&#305; d&#252;zenleyin...",
	
			'usersettings:plugins:description' => "Bu panel site y&#246;netimi taraf&#305;ndan y&#252;klenen ara&#231;lar&#305;n ayarlar&#305;n&#305; kendinize g&#246;re de&#287;i&#351;tirmenize yarar.",
			'usersettings:statistics:label:numentities' => "Giri&#351;leriniz",
	
			'usersettings:statistics:yourdetails' => "Detaylar&#305;n&#305;z",
			'usersettings:statistics:label:name' => "Tam Ad&#305;n&#305;z",
			'usersettings:statistics:label:email' => "Email",
			'usersettings:statistics:label:membersince' => "&#220;yelik Ba&#351;lang&#305;c&#305;",
			'usersettings:statistics:label:lastlogin' => "Son Giri&#351;",
	
			
	
		/**
		 * Generic action words
		 */
	
			'save' => "Kaydet",
			'publish' => "Yay&#305;nla",
			'cancel' => "&#304;ptal",
			'saving' => "Kaydediliyor ...",
			'update' => "G&#252;ncelle",
			'edit' => "D&#252;zenle",
			'delete' => "Sil",
			'accept' => "Kabul",
			'load' => "Haz&#305;rla",
			'upload' => "Y&#252;kle",
			'ban' => "Engelle",
			'unban' => "Engeli Kald&#305;r",
			'enable' => "Etkinle&#351;tir",
			'disable' => "Etkinle&#351;tirme",
			'request' => "Talep",
			'complete' => "Complete",
			'open' => 'A&ccedil;',
			'close' => 'Kapat',
			'reply' => "Yan&#305;tlamak",
			'more' => 'Daha fazla',
			'comments' => 'Yorumlar',
			'import' => 'Dosyayi y�kle',
			'export' => 'G�nder',
	
			'up' => 'yukar&#305;',
			'down' => 'A&#351;a&#287;&#305;',
			'top' => '&uuml;st',
			'bottom' => 'Alt',
	
			'invite' => "Davet",
	
			'resetpassword' => "&#350;ifre S&#305;f&#305;rla",
			'makeadmin' => "Admin Yap",
			'removeadmin' => "y&ouml;neticiyi kald&#305;r ",
	
			'option:yes' => "Evet",
			'option:no' => "Hay&#305;r",
	
			'unknown' => 'Bilinmiyor',
	
			'active' => 'Etkin',
			'total' => 'Toplam',
	
			'learnmore' => "Buraya t&#305;klay&#305;n daha fazla bilgi edinmek i&ccedil;in.",
	
			'content' => "&#304;&ccedil;erik",
			'content:latest' => 'Son Aktivite',
			'content:latest:blurb' => 'Alternatif olarak sitedeki t&#252;m i&#231;eri&#287;i g&#246;r&#252;nt&#252;lemek i&#231;in buraya t&#305;klayabilirsiniz.',
	
			'link:text' => 'view link',
	
			'enableall' => 'Enable All',
			'disableall' => 'Disable All',
	
		/**
		 * Generic questions
		 */
	
			'question:areyousure' => 'Emin misiniz?',
	
		/**
		 * Generic data words
		 */
	
			'title' => "Ba&#351;l&#305;k",
			'description' => "Tan&#305;m",
			'tags' => "Etiketler",
			'spotlight' => "Spotlight",
			'all' => "T&#252;m&#252;",
	
			'by' => 'by',
	
			'annotations' => "Ek A&#231;&#305;klama",
			'relationships' => "&#304;li&#351;ki",
			'metadata' => "Metaveri",
	
		/**
		 * Input / output strings
		 */

			'deleteconfirm' => "Silmek istedi&#287;inize eminmisiniz?",
			'fileexists' => "Y&#252;kleme tamamland&#305;. Yerine yenisini koymak i&#231;in a&#351;a&#287;&#305;dan se&#231;im yap&#305;n&#305;z:",
			
		/**
		 * User add
		 */

			'useradd:subject' => 'User account created',
			'useradd:body' => '
%s,

A user account has been created for you at %s. To log in, visit:

	%s

And log in with these user credentials:

	Username: %s
	Password: %s
	
Once you have logged in, we highly recommend that you change your password.
',
			
	    /**
         * System messages
         **/

			'systemmessages:dismiss' => "click to dismiss",

	
		/**
		 * Import / export
		 */
			'importsuccess' => "&#304;&#231;eri aktarma ba&#351;ar&#305;l&#305;",
			'importfail' => "OpenDD i&#231;eri aktarma ba&#351;ar&#305;s&#305;z.",
	
		/**
		 * Time
		 */
	
			'friendlytime:justnow' => "sadece &#351;imdi",
			'friendlytime:minutes' => "%s dakika &#246;nce",
			'friendlytime:minutes:singular' => "bir dakika &#246;nce",
			'friendlytime:hours' => "%s saat &#246;nce",
			'friendlytime:hours:singular' => "bir saat &#246;nce",
			'friendlytime:days' => "%s g&#252;n &#246;nce",
			'friendlytime:days:singular' => "d&#252;n",
	
			'date:month:01' => 'January %s',
			'date:month:02' => 'February %s',
			'date:month:03' => 'March %s',
			'date:month:04' => 'April %s',
			'date:month:05' => 'May %s',
			'date:month:06' => 'June %s',
			'date:month:07' => 'July %s',
			'date:month:08' => 'August %s',
			'date:month:09' => 'September %s',
			'date:month:10' => 'October %s',
			'date:month:11' => 'November %s',
			'date:month:12' => 'December %s',
	
	
		/**
		 * Installation and system settings
		 */
	
			'installation:error:htaccess' => "Elgg requires a file called .htaccess to be set in the root directory of its installation. We tried to create it for you, but Elgg doesn't have permission to write to that directory. 

Creating this is easy. Copy the contents of the textbox below into a text editor and save it as .htaccess

",
			'installation:error:settings' => "Elgg couldn't find its settings file. Most of Elgg's settings will be handled for you, but we need you to supply your database details. To do this:

1. Rename engine/settings.example.php to settings.php in your Elgg installation.

2. Open it with a text editor and enter your MySQL database details. If you don't know these, ask your system administrator or technical support for help.

Alternatively, you can enter your database settings below and we will try and do this for you...",
	
			'installation:error:configuration' => "Once you've corrected any configuration issues, press reload to try again.",
	
			'installation' => "Y&#252;kleme",
			'installation:success' => "Elgg database'i ba&#351;ar&#305;yla y&#252;klenmi&#351;tir. RhoD-Hi sizi tebrik eder =",
			'installation:configuration:success' => "Ba&#351;lang&#305;&#231;taki ayalar&#305;n&#305;z kaydedilmi&#351;tir. &#351;imdi kullan&#305;c&#305; ad&#305;n&#305;z ve &#351;ifrenizle login olun, bu sitenin administrator'u olacakt&#305;r.",
	
			'installation:settings' => "Sistem Ayarlar&#305;",
			'installation:settings:description' => "Elgg database'i ba&#351;ar&#305;yla y&#252;klendi, siteyi &#231;al&#305;&#351;t&#305;rmak i&#231;in bilgileri girmeniz gereklidir. Ben RhoD-Hi olarak bunlar&#305; sizin i&#231;in tahmin ettim ama <b> detaylar&#305; kontrol edebilirsiniz.",
	
			'installation:settings:dbwizard:prompt' => "Database bilgilerinizi girin ve ardindan kaydet e basin:",
			'installation:settings:dbwizard:label:user' => "Database Kullanici Adi",
			'installation:settings:dbwizard:label:pass' => "Database Password",
			'installation:settings:dbwizard:label:dbname' => "Elgg database",
			'installation:settings:dbwizard:label:host' => "Database hostname (usually 'localhost')",
			'installation:settings:dbwizard:label:prefix' => "Database table prefix (usually 'elgg')",
	
			'installation:settings:dbwizard:savefail' => "Yeni settings.php dosyasini kaydedemiyoruz. L&#252;tfen bir text edit&#246;r kullanarakengine/settings.php kaydediniz.",
	
			'installation:sitename' => "Sitenizin adi (&#246;rnek \"RhoD-Hi.Com | Sosyal ag Sitesi \")::",
			'installation:sitedescription' => "Sitenizin kisa a&#231;iklamasi(zorunlu degil)",
			'installation:wwwroot' => "Elgg dosyalarinin bulundugu adres(&#246;rnek olarak http://localhost):",
			'installation:path' => "Elgg dosyalarinin bulundugu directory(&#246;rnek olarak C:\wamp\www\elgg)",
			'installation:dataroot' => "Siteye upload edilecek olan dosyalarin toplanicagi klas&#246;r(&#246;rnek C:\wamp\www\data):",
			'installation:dataroot:warning' => "You must create this directory manually. It should sit in a different directory to your Elgg installation.",
			'installation:sitepermissions' => "The default access permissions:",
			'installation:language' => "Sitenizin genel dili:",
			'installation:debug' => "Debug mode provides extra information which can be used to diagnose faults, however it can slow your system down so should only be used if you are having problems:",
			'installation:debug:label' => "Onar&#305;m Moduna Ge&#231;",
			'installation:httpslogin' => "Enable this to have user logins performed over HTTPS. You will need to have https enabled on your server for this to work.",
			'installation:httpslogin:label' => "Enable HTTPS logins",
			'installation:usage' => "This option lets Elgg send anonymous usage statistics back to Curverider.",
			'installation:usage:label' => "Send anonymous usage statistics",
			'installation:view' => "Enter the view which will be used as the default for your site or leave this blank for the default view (if in doubt, leave as default):",

			'installation:siteemail' => "Site email address (used when sending system emails)",
	
			'installation:disableapi' => "The RESTful API is a flexible and extensible interface that enables applications to use certain Elgg features remotely.",
			'installation:disableapi:label' => "Enable the RESTful API",
			
			'installation:allow_user_default_access:description' => "If checked, individual users will be allowed to set their own default access level that can over-ride the system default access level.",
			'installation:allow_user_default_access:label' => "Allow user default access",
	
			'installation:simplecache:description' => "The simple cache increases performance by caching static content including some CSS and JavaScript files. Normally you will want this on.",
			'installation:simplecache:label' => "Use simple cache",
	
			'upgrading' => 'Upgrading',
			'upgrade:db' => 'Your database was upgraded.',
			'upgrade:core' => 'Your elgg installation was upgraded',
	
		/**
		 * Welcome
		 */
	
			'welcome' => "Ho&#351;geldiniz %s",
			'welcome_message' => "Elgg Kurulumuna Hosgeldiniz",
	
		/**
		 * Emails
		 */
			'email:settings' => "Email ayarlar&#305;",
			'email:address:label' => "Email adresiniz",
			
			'email:save:success' => "Yeni email adresi kaydedildi,onaylama g&#246;nderildi.",
			'email:save:fail' => "Yeni email adresiniz kaydedilemedi.",
	
			'friend:newfriend:subject' => "%s sizi arkada&#351; olarak ekledi!",
			'friend:newfriend:body' => "%s sizi arkada&#351; olarak ekledi!

Profiline g&#246;zatmak i&#231;in,T&#305;klay&#305;n&#305;z:

	%s

Bu maili cevaplayamazs&#305;n&#305;z.",
	
	
	
			'email:resetpassword:subject' => "%s l&#252;tfen email adresinizi onaylay&#305;n&#305;z!",
			'email:resetpassword:body' => "Merhaba %s,
			
Tebrikler, email adresinizi ba&#351;ar&#305;yla onaylad&#305;n&#305;z.",
	
	
			'email:resetreq:subject' => "&#350;ifre s&#305;f&#305;rlama!",
			'email:resetreq:body' => "Merhaba %s,
			
	
Birileri (from the IP address %s) bu hesap i&#231;in yeni &#351;ifre talebinde bulundu.

E&#287;er siz bulunduysan&#305;z a&#351;a&#287;&#305;daki linke t&#305;klay&#305;n&#305;z, e&#287;er siz de&#287;ilseniz bu maili g&#246;zard&#305; ediniz.


%s
",

		/**
		 * user default access
		 */
	
		'default_access:settings' => "Your default access level",
		'default_access:label' => "Default access",
		'user:default_access:success' => "Your new default access level was saved.",
		'user:default_access:failure' => "Your new default access level could not be saved.",
	
		/**
		 * XML-RPC
		 */
			'xmlrpc:noinputdata'	=>	"Input data missing",
	
		/**
		 * Comments
		 */
	
			'comments:count' => "%s yorumlar&#305;",
			
			'riveraction:annotation:generic_comment' => '%s commented on %s',
	
			'generic_comments:add' => "Yorum Ekle",
			'generic_comments:text' => "Yorum",
			'generic_comment:posted' => "Yorumunuz g&#246;nderildi.",
			'generic_comment:deleted' => "Yorumunuz silindi.",
			'generic_comment:blank' => "&#220;zg&#252;n&#252;z; bo&#351; yorum g&#246;nderemezsiniz.",
			'generic_comment:notfound' => "&#220;zg&#252;n&#252;z; belirtilen &#246;&#287;e bulunamad&#305;.",
			'generic_comment:notdeleted' => "&#220;zg&#252;n&#252;z; bu yorum silinemiyor.",
			'generic_comment:failure' => "Yorumunuz eklenirken beklenmeyen bir hata olu&#351;tu. L&#252;tfen tekrar deneyiniz.",
	
			'generic_comment:email:subject' => 'Yeni bir yorumunuz var!',
			'generic_comment:email:body' => "G&#246;nderdi&#287;iniz &#246;&#287;eye bir yorumda bulunuldu \"%s\" g&#246;nderen %s. Okuyunuz:
			
%s


%s


Cevap yazmak yada g&#246;r&#252;nt&#252;lemek i&#231;in t&#305;klay&#305;n&#305;z:

	%s

%s isimli kullan&#305;c&#305;n&#305;n profiline g&#246;zatmak i&#231;in, buraya t&#305;klay&#305;n&#305;z:

	%s

Bu maile cevap yazamazs&#305;n&#305;z.",

		/**
		 * Entities
		 */
			'entity:default:strapline' => 'Olu&#351;turuldu %s taraf&#305;ndan %s',
			'entity:default:missingsupport:popup' => 'Bu giri&#351; g&#246;r&#252;nt&#252;lenemiyor. Bu desteklenmeyen bir i&#231;erik oldu&#287;undan dolay&#305; olabilir.',

			'entity:delete:success' => 'Giri&#351; %s silindi',
			'entity:delete:fail' => 'Giri&#351; %s silinemiyor',
	
	
		/**
		 * Action gatekeeper
		 */
			'actiongatekeeper:missingfields' => 'Form is missing __token or __ts fields',
			'actiongatekeeper:tokeninvalid' => 'Token provided by form does not match that generated by server.',
			'actiongatekeeper:timeerror' => 'Form has expired, please refresh and try again.',
			'actiongatekeeper:pluginprevents' => 'A extension has prevented this form from being submitted.',
	
		/**
		 * Word blacklists
		 */
			'word:blacklist' => 'and, the, then, but, she, his, her, him, one, not, also, about, now, hence, however, still, likewise, otherwise, therefore, conversely, rather, consequently, furthermore, nevertheless, instead, meanwhile, accordingly, this, seems, what, whom, whose, whoever, whomever',
	
		/**
		 * Languages according to ISO 639-1
		 */
			"aa" => "Afar",
			"ab" => "Abkhazian",
			"af" => "Afrikaans",
			"am" => "Amharic",
			"ar" => "Arabic",
			"as" => "Assamese",
			"ay" => "Aymara",
			"az" => "Azerbaijani",
			"ba" => "Bashkir",
			"be" => "Byelorussian",
			"bg" => "Bulgarian",
			"bh" => "Bihari",
			"bi" => "Bislama",
			"bn" => "Bengali; Bangla",
			"bo" => "Tibetan",
			"br" => "Breton",
			"ca" => "Catalan",
			"co" => "Corsican",
			"cs" => "Czech",
			"cy" => "Welsh",
			"da" => "Danish",
			"de" => "German",
			"dz" => "Bhutani",
			"el" => "Greek",
			"en" => "English",
			"eo" => "Esperanto",
			"es" => "Spanish",
			"et" => "Estonian",
			"eu" => "Basque",
			"fa" => "Persian",
			"fi" => "Finnish",
			"fj" => "Fiji",
			"fo" => "Faeroese",
			"fr" => "French",
			"fy" => "Frisian",
			"ga" => "Irish",
			"gd" => "Scots / Gaelic",
			"gl" => "Galician",
			"gn" => "Guarani",
			"gu" => "Gujarati",
			"he" => "Hebrew",
			"ha" => "Hausa",
			"hi" => "Hindi",
			"hr" => "Croatian",
			"hu" => "Hungarian",
			"hy" => "Armenian",
			"ia" => "Interlingua",
			"id" => "Indonesian",
			"ie" => "Interlingue",
			"ik" => "Inupiak",
			//"in" => "Indonesian",
			"is" => "Icelandic",
			"it" => "Italian",
			"iu" => "Inuktitut",
			"iw" => "Hebrew (obsolete)",
			"ja" => "Japanese",
			"ji" => "Yiddish (obsolete)",
			"jw" => "Javanese",
			"ka" => "Georgian",
			"kk" => "Kazakh",
			"kl" => "Greenlandic",
			"km" => "Cambodian",
			"kn" => "Kannada",
			"ko" => "Korean",
			"ks" => "Kashmiri",
			"ku" => "Kurdish",
			"ky" => "Kirghiz",
			"la" => "Latin",
			"ln" => "Lingala",
			"lo" => "Laothian",
			"lt" => "Lithuanian",
			"lv" => "Latvian/Lettish",
			"mg" => "Malagasy",
			"mi" => "Maori",
			"mk" => "Macedonian",
			"ml" => "Malayalam",
			"mn" => "Mongolian",
			"mo" => "Moldavian",
			"mr" => "Marathi",
			"ms" => "Malay",
			"mt" => "Maltese",
			"my" => "Burmese",
			"na" => "Nauru",
			"ne" => "Nepali",
			"nl" => "Dutch",
			"no" => "Norwegian",
			"oc" => "Occitan",
			"om" => "(Afan) Oromo",
			"or" => "Oriya",
			"pa" => "Punjabi",
			"pl" => "Polish",
			"ps" => "Pashto / Pushto",
			"pt" => "Portuguese",
			"qu" => "Quechua",
			"rm" => "Rhaeto-Romance",
			"rn" => "Kirundi",
			"ro" => "Romanian",
			"ru" => "Russian",
			"rw" => "Kinyarwanda",
			"sa" => "Sanskrit",
			"sd" => "Sindhi",
			"sg" => "Sangro",
			"sh" => "Serbo-Croatian",
			"si" => "Singhalese",
			"sk" => "Slovak",
			"sl" => "Slovenian",
			"sm" => "Samoan",
			"sn" => "Shona",
			"so" => "Somali",
			"sq" => "Albanian",
			"sr" => "Serbian",
			"ss" => "Siswati",
			"st" => "Sesotho",
			"su" => "Sundanese",
			"sv" => "Swedish",
			"sw" => "Swahili",
			"ta" => "Tamil",
			"te" => "Tegulu",
			"tg" => "Tajik",
			"th" => "Thai",
			"ti" => "Tigrinya",
			"tk" => "Turkmen",
			"tl" => "Tagalog",
			"tn" => "Setswana",
			"to" => "Tonga",
			"tr" => "Turkish",
			"ts" => "Tsonga",
			"tt" => "Tatar",
			"tw" => "Twi",
			"ug" => "Uigur",
			"uk" => "Ukrainian",
			"ur" => "Urdu",
			"uz" => "Uzbek",
			"vi" => "Vietnamese",
			"vo" => "Volapuk",
			"wo" => "Wolof",
			"xh" => "Xhosa",
			//"y" => "Yiddish",
			"yi" => "Yiddish",
			"yo" => "Yoruba",
			"za" => "Zuang",
			"zh" => "Chinese",
			"zu" => "Zulu",
	);

	add_translation("en",$english);

?>
