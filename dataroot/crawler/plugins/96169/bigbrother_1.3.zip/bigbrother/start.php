<?php
/**
 * Big Brother
 * 
 * @package Big Brother
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Brett Profitt
 * @copyright Brett Profitt 2009
 * @link http://eschoolconsultants.com
 * 
 * 
 * @todo
 * 	Possibility that you can edit metadata without updating the entity -- in this case
 * 		the MD won't be filtered correctly.
 * 
 */

/**
 * Initialise the plugin.
 */
function bigbrother_init() {

	// this uses the action hooks.  it will get everything with an action
	// regardless if it creates an object or not...
	//register_plugin_hook('action', 'all', 'bigbrother_filter_action');

	// this uses a hook for entity creation and update.
	// not as all-encompassing, but should probably be enough...???
	//@todo pull this out into config.
	
	register_elgg_event_handler('create', 'all', 'bigbrother_filter_entity');
	register_elgg_event_handler('update', 'all', 'bigbrother_filter_entity');
	
	// trims up and caches the word list.
	// for < 1.4
	register_elgg_event_handler('plugin_settings_save', 'bigbrother', 'bigbrother_trim_word_list_depricated');
	// for >= 1.4
	register_plugin_hook('plugin:setting', 'plugin', 'bigbrother_trim_word_list');
	
	return true;
}

function bigbrother_filter_entity($event, $object_type, $object) {
	global $CONFIG;
	
	if (!is_object($object)) {
		return true;
	}
	
	$subtype = $object->getSubtype();
	switch($subtype) {
		case 'demerit':
		case 'reported_content':
		case 'plugin':
		case 'pluginorder':
		case 'enabled_plugins':
			return true;
	}
	
	if ($replacement_string_enabled = get_plugin_setting('replacement_string_enabled', 'bigbrother')) {
		$replacement_string = get_plugin_setting('replacement_string', 'bigbrother');
	} else {
		// required for string comparison
		$replacement_string = '*';
	}
	
	// disable all event handlers while we're filtering 
	// to avoid problems with recursion.
	// Any events that need to fire will be fired the first time the
	// entity is created.
	if(isset($CONFIG->events)) {
		$old_events = $CONFIG->events;
		$CONFIG->events = array();
	}
	
	// figure out which fields to look in for the object itself.
	switch ($object_type) {
		case 'annotation':
			$check_entity_fields = array('name', 'value');
			break;
			
		case 'object':
			$check_entity_fields = array('title', 'description');
			break;
			
		case 'metadata':
			$check_entity_fields = array('value');
			break;
			
		default:
			$check_entity_fields = array();
	}
	
	$censored_strings = array();
	foreach ($check_entity_fields as $fieldname) {
		$original_str = $object->$fieldname;
		$censored_str = bigbrother_censor_string($original_str, $replacement_string);
		
		if ($original_str != $censored_str) {
			$censored_strings[] = array('original'=>$original_str, 'censored'=>$censored_str);
			if ($replacement_string_enabled) {
				$object->$fieldname = $censored_str;
			}
		}
	}
	
	// this doesn't work.  at all.
	// the object is never saved.
	// this returns true on save, but it's a lie...?
	// we can save it outside of the if scope, though...
	//
	// the plot thickens.  If we do if (true) {} it works. 
//	if (!empty($censored_strings)) {
//	//if (true) {
//		print "inside the if statement\n";
//		if (!$object->save()) {
//			print "ERROR SAVING!!!\n";
//		} else {
//			print "Saved\n";
//		}
//	}
	// save the object even if we don't need to.
	$object->save();
	
	// grab all metadata for this object and monitor it also
	// don't use getGUID() because it'll error on non objects.
	if ($guid = $object->guid && $metadata_arr = get_metadata_for_entity($guid)) {
		foreach($metadata_arr as $metadata) {
			$original_value = $metadata->value;
			$censored_value = bigbrother_censor_string($original_value, $replacement_string);
			$name = $metadata->name;
			
			if ($original_value != $censored_value) {
				$censored_strings[] = array('original'=>$original_str, 'censored'=>$censored_str);
				if ($replacement_string_enabled) {
					$object->$name = $censored_value;
					//$object->save();
				}
			}
		}
	}
	
	if (!empty($censored_strings) && get_plugin_setting('report_censored_page', 'bigbrother')) {
		bigbrother_create_report($censored_strings, $object->getSubtype());
	}
	
	if (!empty($censored_strings) && get_plugin_setting('notify_user_on_censor', 'bigbrother')) {
		register_error(elgg_echo('bigbrother:censored'));
	}
	
	// restore events.
	// @todo should this be restored BEFORE the report is submitted?
	if(isset($CONFIG->events)) {
		$CONFIG->events = $old_events;
	}
	
	return true;
}
/**
 * Create a report in the Reported Content plugin.
 * 
 * @param $censored_strings like array('original'=>
 * @param $object
 * @return unknown_type
 */
function bigbrother_create_report($censored_strings, $subtype='Unknown', $extra_infomation=null) {
	if (!is_array($censored_strings[0])) {
		$censored_strings = array($censored_strings);
	}
	
	foreach ($censored_strings as $entry) {
		list($original, $censored) = str_replace(array("\n", "\r"), '', array($entry['original'], $entry['censored']));
		// fix this so it displays right.
		$original = strip_tags($original);
		$censored = strip_tags($censored);
		
		$original_arr = explode("\n", wordwrap($original, 35, "\n", true));
		$censored_arr = explode("\n", wordwrap($censored, 35, "\n", true));
		
		$max = (count($original_arr) > count($censored_arr)) ? count($original_arr) : count($censored_arr);
		for ($i=0; $i<$max; $i++) {
			$report_original = $original_arr[$i];

			// keep it pretty for the quasi-diff
			while(strlen($report_original) <= 35) {
				$report_original .= ' ';
			}
			
			$original_context .=  $report_original . ' | ' . $censored_arr[$i] . "\n";
		}
	}
	
	$details  = elgg_echo('bigbrother:report_username') . $_SESSION['user']->username . "\n";
	$details .= elgg_echo('bigbrother:report_display_name') . $_SESSION['user']->name . "\n";
	$details .= elgg_echo('bigbrother:report_date') . date('Y-m-d H:i:s') . "\n";
	$details .= elgg_echo('bigbrother:report_object_type') . $subtype;
	
	$title = elgg_echo('bigbrother:reported_content_title');
	$description = sprintf(elgg_echo('bigbrother:reported_content_description'), $details, $original_context);
	$address = $_SERVER['HTTP_REFERER'];
	
	$entity = new ElggObject;
	$entity->subtype = "reported_content";
	$entity->owner_guid = $_SESSION['user']->getGUID();
	$entity->content_owner = $_SESSION['user']->getGUID();
	$entity->title = $title;
	$entity->address = $address;
	$entity->description = $description;
	$entity->access_id = 0;
	$entity->save();
	if (!trigger_plugin_hook('reportedcontent:add', $entity->type, array('entity'=>$entity), true)) {
		$entity->delete();
		return false;
	}
}


/**
 * Returns censored version of string using defined word list. 
 * 
 * @param $regexp bool If set will run the word list through a regexp to increase accuracy.
 * @return mixed.
 */
function bigbrother_censor_string($string, $replacement_string) {
	$bad_words = explode(',', get_plugin_setting('naughty_word_list', 'bigbrother')); 
	$regexp_words = get_plugin_setting('use_regexp_censor', 'bigbrother');
	
	if ($regexp_words) {
		$search = $bad_words;
	} else {
		$count = 0;
		$search = array();
		foreach ($bad_words as $bad_word) {
			$word_array = array();
			for ($i=0; $i<strlen($bad_word); $i++) {
				$letter = $bad_word[$i];
				
				$regexp_chars = array(
					'.', '+', '*', '(', ')', '[', ']',
					'#', '^', '?', '$', '|', '\\'
				);
				
				// escape regexp chars
				// this is imperfect--it still has problems with +s
				if (in_array($letter, $regexp_chars)) {
						$letter = '\\' . $letter;
				}
				
				$word_array[] .=  $letter . '+';
			}
			// allow 's to avoid "he'll" problems.
			$word_split_regexp = '([^a-zA-Z\']?)+';
			$search[] = '/\b' . $word_split_regexp . implode($word_split_regexp, $word_array)
				. $word_split_regexp . '\b/i';
	
			$count++;
		}
	}
	
	$clean_string = preg_replace($search, $replacement_string, $string);
	
	// error in regexp.  return full string.
	// @todo should this display an error?
	//if (false === $clean_string) {
	// why oh why php do you return null on error in preg_replace?
	if (null === $clean_string) {
		$clean_string = $string;
		register_error(elgg_echo('bigbrother:malformed_regexp'));
	}
//	
//	register_error("######\n");
//	register_error($string);
//	register_error($clean_string);
//	register_error("######\n");
	
	/*
	 
	 
	//if ($regexp_words) {
	if (true) {
		$count = 0;
		$search = array();
		foreach ($words_arr as $bad_word) {
//			$word_array = array();
//			for ($i=0; $i<strlen($bad_word); $i++) {
//				$word_array[$i] .= $bad_word[$i];
//			}
			//$word_split_regexp = '([^a-zA-Z]?)+';
			//$search[$count] = '/\b' . implode($word_split_regexp, $word_array)	.  '\b/i';
			// @todo this regex sucks.
			//$search[$count] = '/([^a-zA-Z\'>])\b' . implode($word_split_regexp, $word_array)	.  '\b/i';
			
			$search[$count] = '/\b' . $bad_word . '\b/i';
			$count++;
	    }
	    $clean_string = preg_replace($search, ' ' . $replacement_string . ' ', $string);
	} else {
		$clean_string = str_replace($words_arr, $replacement_string, $string);
	}
	*/
	
    return $clean_string;
}

/**
 * Trim word list and subtypes to a CSV with no extra spaces and resave.
 * 
 * 
 * @param $event
 * @param $object_type
 * @param $object
 * @return unknown_type
 */
function bigbrother_trim_word_list($hook, $entity_type, $returnvalue, $params) {
	if ($params['plugin'] != 'bigbrother' && $params['name'] != 'naughty_word_list') {
		return $returnvalue;
	}
	
	$words = $params['value'];
	$words_str = str_replace(array("\n","\r"), '', $words);
	$words_str = str_replace(', ', ',', $words_str);
	$words_str = str_replace(',,', ',', $words_str);

	// check the array to make sure we don't have empty entries.
	$words_arr = explode(',', $words_str);
	$words_arr_filtered = array();
	foreach ($words_arr as $word) {
		$word = trim($word);
		if (!empty($word)) {
			$words_arr_filtered[] = $word;
		}
	}
	
	return implode(',', $words_arr_filtered);
}

function bigbrother_trim_word_list_depricated($event, $object_type, $object) {
	$words = get_plugin_setting('naughty_word_list', 'bigbrother');
	$words_str = str_replace(array("\n","\r"), '', $words);
	$words_str = str_replace(', ', ',', $words_str);
	$words_str = str_replace(',,', ',', $words_str);
	
	// check the array to make sure we don't have empty entries.
	$words_arr = explode(',', $words_str);
	$words_arr_filtered = array();
	foreach ($words_arr as $word) {
		$word = trim($word);
		if (!empty($word)) {
			$words_arr_filtered[] = $word;
		}
	}
	
	return set_plugin_setting('naughty_word_list', implode(',', $words_arr_filtered), 'bigbrother');
}

register_elgg_event_handler('init', 'system', 'bigbrother_init');
