<?php

$reported_content_description = 'Big Brother automatically detected inappropriate content from a user.  See below for full details and original context:
<pre style="font-family: monospace;">

%s

%s
</pre>';

$settings_blurb = '
<p style="color: red; font-weight: bold; font-size: large;">DISABLE ANY HTML EDITORS BEFORE ENTERING A WORD LIST.</p>

<p>Word lists can be in two formats: plain text, or regular expressions.
If you use regexp, each word must be a properly formed regular expression (to be inserted
between "/" and "/i" in a preg_replace.)  If you don\'t know what regexp is, do not enable it.</p>  

<p style="color: red;">Mal-formed regexp in the words list will cause problems.</p>

<p>In either format, words must be separated by commas in one of the styles below:</p> 

<h4>Style 1</h4>
<code>
swear1, swear2, swear3
<code>

<h4>Style 2</h4>
<pre><code>swear1,
swear2,
swear3</code></pre>

';

$english = array(
	'bigbrother:censored' => 'You have used an inappropriate word.  This has been reported to the adminstrators.',
	'bigbrother:reported_content_title' => 'Reported Content from Big Brother',
	'bigbrother:reported_content_description' => $reported_content_description,
	
	'bigbrother:settings_blurb' => $settings_blurb,
	'bigbrother:naughty_words_list' => 'A comma-separated list of words to censor.',
	'bigbrother:replacement_string_enabled' => 'Replace naughty words?',
	'bigbrother:replacement_string' => 'Replace naughty words with the following string.',
	'bigbrother:report_censored_page' => 'Automatically add censored pages to Reported Content?',
	//'bigbrother:use_regexp_censor' => 'Use a regexp filter on the words?  (Slower but harder to break)',
	'bigbrother:use_regexp_censor' => 'List is in regexp?',
	'bigbrother:notify_user_on_censor' => 'Show the user a message if they use an inappropriate word?',
	
	'bigbrother:report_username' => 'Logged in user\'s username: ',
	'bigbrother:report_display_name' => 'Logged in user\'s display name: ',
	'bigbrother:report_date' => 'Added on: ',
	'bigbrother:report_object_type' => 'Object Type: ',
	
	'bigbrother:malformed_regexp' => 'A malformed regexp expression exists in the Big Brother plugin settings.  Please notify the system administrator.',
);

add_translation("en", $english);
?>
