<?php

	$english = array(
	
	 'user_rest_create:import'  =>  "Importer users" , 
	 'user_rest_create:settings:user_account' => "Name account to use",
	 'user_rest_create:settings:user_password' => "Password account",
	 'user_rest_create:settings:iso_to_utf8_conversion' => "Convert les datas from iso8859-1 to utf8",
	 
	 'user_rest_create:option:normal' => "Metadata",
	 'user_rest_create:option:group' => "Group",
	 
	 
	 'user_rest_create:option:mandatory' => "Mandatory",
	 'user_rest_create:option:non_applicable' => "Non applicable",
	 
	 'user_rest_create:field_name' => "Field Name",
	 'user_rest_create:field_allow' => "Use",
	 'user_rest_create:field_type' => "Type",
	 'user_rest_create:field_help' => " Select the field actually set to you profile fields you want to use for import. They will be asked (mandatory) for both the restful API and the CSV import",
	 
	 'user_rest_create:file_csv_explain' => " Select a csv file with column names on the first line. Columns names must correspond to those configurated in the plugin settings : " ,
	 
	 "user_rest_create:processing_user" => "Processing user creation ...",
	 "user_rest_create:ko_user_created" => "Ko - User not created",
	 "user_rest_create:ok_user_created" => "Ok - User created",
	 
	 "user_rest_create:start_import" => "Start import all (ajax)",
	 "user_rest_create:stop_import" =>  "Stop",
	 "user_rest_create:help_import" =>  "You can either choose to import users one by one, cliqcking their corresponding links, or import them all clicking the starting process link below.",
	 
	 "user_rest_create:settings:default_password" => "Default password",
	 "user_rest_create:settings:actual_rest_url"=> "Your actual RESTFul url is :"

	
	);
					
	add_translation("en",$english);

?>
