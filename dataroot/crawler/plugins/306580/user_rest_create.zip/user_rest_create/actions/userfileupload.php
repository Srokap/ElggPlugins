<?php

	//require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	admin_gatekeeper();
	set_context('admin');
	// Set admin user for user block
	set_page_owner($_SESSION['guid']);

	$user = page_owner_entity();
	if (!$user)
		$user = $_SESSION['user'];
		
	
	if ((isloggedin()) &&	($user) &&	($user->canEdit())) {
				
				$str = get_uploaded_file('usercsvfile');
				
				$delimiter = empty($options['delimiter']) ? "," : $options['delimiter'];
		    $to_object = empty($options['to_object']) ? false : true;
		    $expr="/$delimiter(?=(?:[^\"]*\"[^\"]*\")*(?![^\"]*\"))/"; // added
		    
		    $lines = explode("\n", $str);
		    $field_names = explode($delimiter, array_shift($lines));
		    foreach ($lines as $line) {
		        // Skip the empty line
		        if (empty($line)) continue;
		        $fields = preg_split($expr,trim($line)); // added
		        $fields = preg_replace("/^\"(.*)\"$/s","$1",$fields); //added
		        //$fields = explode($delimiter, $line);
		        
		        $_res = $to_object ? new stdClass : array();
		        foreach ($field_names as $key => $f) {
		        	
		        		$colname = $f;
		        		
		        		$colname = substr_replace($colname, '', strpos($colname, '"'), 1);
            		$colname = substr_replace($colname, '', strrpos($colname, '"'), 1);
            		$colname = strtolower(str_replace('""', '"', $colname));
		        	
		            if ($to_object) {
		                $_res->{$colname} = $fields[$key];
		            } else {
		                $_res[$colname] = $fields[$key];
		            }
		        }
		         
		     $rest = $CONFIG -> wwwroot;
		     $rest = $rest.'pg/api/rest/json?method=user_rest_create.add';
             $rest = $rest.'&username='.$_res["username"];
             $rest = $rest.'&name='.$_res["name"];
             $rest = $rest.'&email='.$_res["email"];
             
             $picture_is_ok = get_plugin_setting("urc_picture_import_allow","user_rest_create");
             if ($picture_is_ok === 'yes')
                $rest = $rest.'&picture='.$_res["picture"];
            
            
            foreach($CONFIG->profile as $key=>$value){
              $field_is_ok = get_plugin_setting("urc_".$key."_import_allow","user_rest_create");
              if ($field_is_ok === 'yes')
                $rest = $rest."&".$key.'='.$_res[$key];
            }
		         $_res['url'] = $rest;
		         
		         $res[] = $_res;
		        
		    } 
  }
  	
	$title = elgg_view_title(elgg_echo('user_rest_create:import'));
	$script = elgg_view('user_rest_create/js_csv');
	$returnTable = elgg_view('user_rest_create/table_csv', array( 'params' => $res));
	$body = elgg_view('page_elements/contentwrapper', array('body' => 
											elgg_echo($script). 
											elgg_echo($returnTable)));
		
	page_draw(elgg_echo('user_rest_create:import'),elgg_view_layout("two_column_left_sidebar", '', $title . $body));

  

?>
