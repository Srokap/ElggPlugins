<?php 
    
    
    function expose_user_rest_create_function(){
    
        global $CONFIG;
        
        $expose_function_params = array();
        $expose_function_params['username'] = array('type' => 'string', 'required'=> false);
        $expose_function_params['name'] = array('type' => 'string', 'required'=> false);
        $expose_function_params['email'] = array('type' => 'string', 'required'=> false);
        
        $picture_is_ok = get_plugin_setting("urc_picture_import_allow");
        if ($picture_is_ok === 'yes')
          $expose_function_params['picture'] = array('type' => 'string', 'required'=> false);
        
        
        foreach($CONFIG->profile as $key=>$value){
            $field_is_ok = get_plugin_setting("urc_".$key."_import_allow");
            if ($field_is_ok === 'yes')
              $expose_function_params[$key] = array('type' => 'string', 'required'=> false);
        }
        
        expose_function('user_rest_create.add', 'user_rest_create_function_execute', 
                          $expose_function_params, 
                          elgg_echo('User creation restFull'), 
                          "GET", 
                          false, 
                          true);
    }
	
    function user_rest_create_iso_utf($field, $switch){
      if ( $switch === 'yes')
        return iconv("ISO-8859-1","UTF-8",trim($field));
      else
        return trim($field);
    }
    
    function user_rest_create_function_execute(){
      
        global $CONFIG;
        $params = array();
        $arg_list = func_get_args();
        $i=0;
        
        
        $user_account = get_plugin_setting("urc_user_account");
        $user_password = get_plugin_setting("urc_user_password");
        
        
        if ($user_account != NULL AND $user_password !=NULL){
            try{
              $user_trt = authenticate($user_account, $user_password);
            } 
            catch (Exception $E){
              return new ErrorResult(-1,"Connection failed" . $E->getMessage());
            }
        }
        
        $iso_utf = get_plugin_setting("urc_iso_to_utf8_conversion");
        $username = user_rest_create_iso_utf($arg_list[$i++], $iso_utf);
        $name = user_rest_create_iso_utf($arg_list[$i++],$iso_utf);
        $email = user_rest_create_iso_utf($arg_list[$i++],$iso_utf);
        
        $picture_is_ok = get_plugin_setting("urc_picture_import_allow");
        if ($picture_is_ok === 'yes')
            $picture = $arg_list[$i++];
            
        // 1- On prepare le tableau
        foreach($CONFIG->profile as $key=>$value){
          $field_is_ok = get_plugin_setting("urc_".$key."_import_allow");
          if ($field_is_ok === 'yes'){
            $params[$key] = $arg_list[$i];
            $i++;
          }
        }
        
        // 2 - On cree le user � partir des champs conventionnels:
        // $username,$password,$name,$email.
        // Voir si on peut passer une url pour le thumbnail, et nommer le champs
        // on unset ces variables pour faciliter le parcours des autres champs
        try{
        	$urc_default_password = get_plugin_setting("urc_default_password");
			if ($urc_default_password != NULL)
				$password = $urc_default_password;
			else
            	$password = $username.$username;
            
            $user_guid = user_rest_create_get_user($username,$password,$name,$email);
        } 
        catch (Exception $E){
            return new ErrorResult(-1,"Creation failed " . $username .", ". $name. ", ". $email. " : " .$E->getMessage(). print_r($arg_list, true));
        }
        
        unset($params['username']);
        unset($params['name']);
        unset($params['email']);
        
        if (isset($picture)){
          user_rest_create_get_thumbnail($user_guid, $picture);
        }
        
        // 3 -  On parcourt toutes les autres valeurs
        // a -  on remove le metadata
        // b - si la chaine contient des ###, on cree un multiple
        //     sinon on cree un simple.
        foreach($params as $key=>$value){
        
            remove_metadata($user_guid, $key);
            if ($value != NULL) {
              
              $field_import_type = get_plugin_setting("urc_".$key."_import_type");
              
              if ($field_import_type === 'group'){
                user_rest_create_attach_user_to_group($value,$user_guid);
                $elgg_value = user_rest_create_iso_utf($value, $iso_utf);
                create_metadata($user_guid, $key, $elgg_value , 'text', $user_guid, ACCESS_PUBLIC);
              }
              else if (strpos($value,":::") === FALSE){
                $elgg_value = user_rest_create_iso_utf(strtolower($value), $iso_utf);
                create_metadata($user_guid, $key, $elgg_value , 'text', $user_guid, ACCESS_PUBLIC);
              }
              else{
                $multiple_metadata = explode(':::', $value);
                $i = 0;
                foreach($multiple_metadata as $single_metadata) {
            	   $i++;
            	   if ($i == 1){
                   $multiple = false; 
                 } 
                 else{ 
                  $multiple = true; 
                 }
                 $elgg_value = user_rest_create_iso_utf(strtolower($single_metadata), $iso_utf);
            	   create_metadata($user_guid, $key , $elgg_value, 'text', $user_guid, ACCESS_PUBLIC , $multiple);
                }
              }
            }
        }
        set_user_validation_status($user_guid, true);
        return new SuccessResult("User ".$username." sucessfully created");
    }
    
    function user_rest_create_init() {
    
        expose_user_rest_create_function();
    }
   
    function user_rest_create_get_user($username,$password,$name,$email){
      $user = get_user_by_username($username);
      
      if ($user instanceof ElggUser)
      {
        $user_guid = $user->guid;
      }
      else 
      {
        $user_guid=register_user($username,$password,$name,$email);
        set_user_validation_status($user_guid, true);
      }
      
      return $user_guid;
   }
   
   function user_rest_create_get_group($group_name, $group_description = "Group description to be done")
   {
      global $CONFIG;
      
      $group_guid = get_data_row("SELECT guid from {$CONFIG->dbprefix}groups_entity WHERE name = '{$group_name}'");
      
      if ($group_guid == FALSE)
      {
        $group = new ElggGroup();
        $group->shortname = $group_name;
        $group->name = $group_name;
        $group->membership = 0; 		// Priv�
        $group->access_id = 2;			//$access_id; // Public
        $group->owner_guid = 2; 		//$owner_guid; // Utilisateur admin
        $group->container_guid = 2; //$container_guid; // Utilisateur admin
        $group->briefdescription = $group_description;
		    $group->save();
		    
		    return $group->guid;
		  }
      else
      { 
        $group = new ElggGroup($group_guid);
        $group->briefdescription = $group_description;
		    $group->save();
        return $group_guid->guid;
      }
   }
   
   function user_rest_create_attach_user_to_group($group_name,$user_guid, $group_description = "Group description to be done")
   {
   
      $group_guid = user_rest_create_get_group($group_name, $group_description);
      $group = new ElggGroup($group_guid);
      $user = get_user($user_guid);
      
      if(!$group->isMember($user))
        $group->join($user);
   }
   
   
   function user_rest_create_get_thumbnail($user_guid, $url_thumbnail_address){
    
    $fichier = file_get_contents($url_thumbnail_address);
    $nom_fichier= strtolower(time().'thumb_'.$user_guid.'.jpg');
    
    $filehandler = new ElggFile();
    $filehandler->owner_guid = $user_guid;
    $filehandler->setFilename("profile/".$nom_fichier);
    $filehandler->open("write");
		$filehandler->write($fichier);
		$FilenameOnFilestore = $filehandler->getFilenameOnFilestore();   	
    $filehandler->close();
    
    
    $user = get_user($user_guid);
    
    $topbar = get_resized_image_from_existing_file($FilenameOnFilestore,16,16, true);
		$tiny = get_resized_image_from_existing_file($FilenameOnFilestore,25,25, true);
		$small = get_resized_image_from_existing_file($FilenameOnFilestore,40,40, true);
		$medium = get_resized_image_from_existing_file($FilenameOnFilestore,100,100, true);
		$large = get_resized_image_from_existing_file($FilenameOnFilestore,200,200);
		$master = get_resized_image_from_existing_file($FilenameOnFilestore,550,550);
		
		$filehandler->delete();
		
		
		if ($small !== false
			&& $medium !== false
			&& $large !== false
			&& $tiny !== false) {
		
			$filehandler = new ElggFile();
			$filehandler->owner_guid = $user_guid;
			$filehandler->setFilename("profile/" . $user->username . "large.jpg");
			$filehandler->open("write");
			$filehandler->write($large);
			$filehandler->close();
			$filehandler->setFilename("profile/" . $user->username . "medium.jpg");
			$filehandler->open("write");
			$filehandler->write($medium);
			$filehandler->close();
			$filehandler->setFilename("profile/" . $user->username . "small.jpg");
			$filehandler->open("write");
			$filehandler->write($small);
			$filehandler->close();
			$filehandler->setFilename("profile/" . $user->username . "tiny.jpg");
			$filehandler->open("write");
			$filehandler->write($tiny);
			$filehandler->close();
			$filehandler->setFilename("profile/" . $user->username . "topbar.jpg");
			$filehandler->open("write");
			$filehandler->write($topbar);
			$filehandler->close();
			$filehandler->setFilename("profile/" . $user->username . "master.jpg");
			$filehandler->open("write");
      $filehandler->write($master);
			$filehandler->close();
			
			$user->icontime = time();
  		}
  	}
   
	/**
	 * Adding the log browser to the admin menu
	 *
	 */
	function user_rest_create_pagesetup()
	{
		if (get_context() == 'admin' && isadminloggedin()) {
			global $CONFIG;
			add_submenu_item(elgg_echo('user_rest_create:import'), $CONFIG->wwwroot . 'pg/user_rest_create/');
		}
	}
	
	
	function user_rest_create_page_handler($page){
		global $CONFIG;
		include($CONFIG->pluginspath . "user_rest_create/index.php");
	}
	
  // Add the plugin's init function to the system's init event
  register_elgg_event_handler('init','system','user_rest_create_init',15000);
  register_elgg_event_handler('pagesetup','system','user_rest_create_pagesetup');  
  
  register_page_handler('user_rest_create','user_rest_create_page_handler');
  register_action("user_rest_create/userfileupload",false,$CONFIG->pluginspath . "user_rest_create/actions/userfileupload.php");
   
   
?>
