	<div id="csv_file_form">
	<form action="<?php echo $vars['url']; ?>action/user_rest_create/userfileupload" method="post" enctype="multipart/form-data">
	<?php echo elgg_view('input/securitytoken'); ?>
	<p>
    <?php echo elgg_echo('user_rest_create:file_csv_explain'); ?>
    <br /><br />
    <i>username, name, email, 
	   <?php 
            $picture_is_ok = get_plugin_setting("urc_picture_import_allow");
            if ($picture_is_ok === 'yes')
              echo elgg_echo("picture").", ";
            foreach($CONFIG->profile as $key=>$value){
              $field_is_ok = get_plugin_setting("urc_".$key."_import_allow");
              if ($field_is_ok === 'yes')
                echo elgg_echo($key).", ";
            }
    ?></i>
    <br /><br />
		<?php
			echo elgg_view("input/file",array('internalname' => 'usercsvfile'));
		?>
		<br /><input type="submit" class="submit_button" value="<?php echo elgg_echo("upload"); ?>" />
	</p>
	</form>
	</div>
