<script>
	var scriptgo = 0;
	
	function startJob()
	{
		if (scriptgo == 0){
				scriptgo = 1;
				
				$(".cmd").each(function(column) {
					if (scriptgo == 1){
						cur_row = this;
						doImportOneRow(cur_row);
					}
				});
			}
	}
	
	function doImportOneRow(cur_row){
						$(cur_row).html('<?php echo elgg_echo("user_rest_create:processing_user"); ?>');
						cur_url = $(cur_row).attr("href");
						$.ajax({
									   type: "GET",
									   contentType: "application/json; charset=utf-8",
									    dataType: "json",
									   async: false,
									   url: cur_url,
									   success: function(data){
									   	  var result = data.api[0].result;
										  var status = data.api[0].status;
										  
										  if (status == 0) {
										  	$(cur_row).html('<?php echo elgg_echo("user_rest_create:ok_user_created"); ?>');
											return false; 
										  }
										  else {
										  	$(cur_row).html('<?php echo elgg_echo("user_rest_create:ko_user_created"); ?>');
											return false; 
										  }
										  
										  
					                      },
									   error: function(html){$(cur_row).html('<?php echo elgg_echo("user_rest_create:ko_user_created"); ?>');}
						});
	}
	
	function stopJob()
	{
		if (scriptgo == 1){
				scriptgo = 0;
			}
	}

	$(document).ready(function() {   
							$("#startbtn").click(function() { startJob(); return false;});
							$("#stopbtn").click(function() { stopJob(); return false;});
							$("a.cmd").click(function() { doImportOneRow(this); return false;});
  });
</script>




