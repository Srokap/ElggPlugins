<?php
	 $rest = $CONFIG -> wwwroot;
     $rest = $rest.'pg/api/rest/json?method=user_rest_create.add';
     $rest = $rest.'&username=SOMETHING';
     $rest = $rest.'&name=SOMETHING';
     $rest = $rest.'&email=SOMETHING';
     
     $picture_is_ok = get_plugin_setting("urc_picture_import_allow","user_rest_create");
     if ($picture_is_ok === 'yes')
        $rest = $rest.'&picture=SOMETHING_OR_NOTHING';
    
    
    foreach($CONFIG->profile as $key=>$value){
      $field_is_ok = get_plugin_setting("urc_".$key."_import_allow","user_rest_create");
      if ($field_is_ok === 'yes')
        $rest = $rest."&".$key.'=SOMETHING_OR_NOTHING';
    }
?>
<div>
  <div class="contentWrapper">
  	<?php echo elgg_echo("user_rest_create:settings:actual_rest_url"); ?>
	<br/><br/>
	<?php echo elgg_echo($rest); ?>
  </div>
  <div class="contentWrapper">
    <table>
      <tr>
        <td><?php echo elgg_echo("user_rest_create:settings:user_account"); ?></td>
  	    <td><input type="text" value="<?php echo $vars["entity"]->urc_user_account; ?>" name="params[urc_user_account]"></td>
  	  </tr>
  	  <tr>
  	     <td><?php echo elgg_echo("user_rest_create:settings:user_password"); ?></td>
  	     <td><input type="password" value="<?php echo $vars["entity"]->urc_user_password; ?>" name="params[urc_user_password]"></td>
      </tr>
	  <tr>
  	     <td><?php echo elgg_echo("user_rest_create:settings:default_password"); ?></td>
  	     <td><input type="text" value="<?php echo $vars["entity"]->urc_default_password; ?>" name="params[urc_default_password]"></td>
      </tr>
      <tr>
  	     <td><?php echo elgg_echo("user_rest_create:settings:iso_to_utf8_conversion"); ?></td>
  	     <td>
  	         <?php	echo elgg_view('input/pulldown', array(
          			'internalname' => 'params[urc_iso_to_utf8_conversion]',
          			'options_values' => array(
          				'no' => elgg_echo('option:no'),
          				'yes' => elgg_echo('option:yes')
          			),
          			'value' => $vars["entity"]->urc_iso_to_utf8_conversion
          		));
          	?>
         </td>
      </tr>
	  
      </table>
    </div>
    <div class="contentWrapper">
      <?php echo elgg_echo("user_rest_create:field_help");?>
      <br/>
      <br/>
      <table>
      <tr>
          <th style="width: 50%"><b><?php echo elgg_echo("user_rest_create:field_name");?></b></th>
          <th style="width: 20%"><b><?php echo elgg_echo("user_rest_create:field_allow");?></b></th>
          <th style="width: 20%"><b><?php echo elgg_echo("user_rest_create:field_type");?></b></th>
      </tr>
      <tr>
          <td>username</td>
          <td><b><?php echo elgg_echo("user_rest_create:option:mandatory");?></b></td>
          <td><b><?php echo elgg_echo("user_rest_create:option:non_applicable");?></b></td>
      </tr>
      <tr>
          <td>name</td>
          <td><b><?php echo elgg_echo("user_rest_create:option:mandatory");?></b></td>
          <td><b><?php echo elgg_echo("user_rest_create:option:non_applicable");?></b></td>    
      </tr>
      <tr>
          <td>email</td>
          <td><b><?php echo elgg_echo("user_rest_create:option:mandatory");?></b></td>
          <td><b><?php echo elgg_echo("user_rest_create:option:non_applicable");?></b></td>    
      </tr>
      <tr>
          <td>picture</td>
          <td><?php
  	         echo elgg_view('input/pulldown', array(
          			'internalname' => 'params[urc_picture_import_allow]',
          			'options_values' => array(
          			  'yes' => elgg_echo('option:yes'),
          				'no' => elgg_echo('option:no')
          			),
          			'value' => $vars["entity"]->urc_picture_import_allow
          		));
          	?>
          </td>
          <td><b><?php echo elgg_echo('user_rest_create:option:picture'); ?></b></td>    
      </tr>
      <tr><td colspan="3"><br/></td></tr>
	  <tr><td colspan="3"><?php echo 'Elgg Custom Profile Fields in Config are currently set to ' . (($CONFIG->profile_using_custom === true) ? 'On' : 'Off'); ?></td>
	  <tr><td colspan="3"><br/></td></tr>
      <?php
      	foreach($vars['config']->profile as $key=>$value){
      ?>
      <tr>
  	     <td><?php 	
		 			echo elgg_echo($key). " (" . elgg_echo("profile:{$key}") .")";
			 ?>
		 </td>
  	     <td><?php
  	         echo elgg_view('input/pulldown', array(
          			'internalname' => 'params[urc_'.$key.'_import_allow]',
          			'options_values' => array(
          			  'yes' => elgg_echo('option:yes'),
          				'no' => elgg_echo('option:no')
          			),
          			'value' => $vars["entity"]->{'urc_'.$key.'_import_allow'}
          		));
          	?>
         </td>
  	     <td><?php
  	         echo elgg_view('input/pulldown', array(
        			'internalname' => 'params[urc_'.$key.'_import_type]',
        			'options_values' => array(
        				'normal' => elgg_echo('user_rest_create:option:normal'),
        				'group' => elgg_echo('user_rest_create:option:group')
        			),
        			'value' => $vars["entity"]->{'urc_'.$key.'_import_type'}
        		));
            ?>
         </td>
      </tr>
      <?php
        }
      ?>
    </table>
  </div>
</div>
