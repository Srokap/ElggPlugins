
<?php echo elgg_echo("user_rest_create:help_import"); ?>
<br/><br/>
<a href="" id="startbtn" ><?php echo elgg_echo("user_rest_create:start_import"); ?></a>&nbsp;|&nbsp;
<a href="" id="stopbtn"><?php echo elgg_echo("user_rest_create:stop_import"); ?></a>
<br/><br/>
<table id="listusers" style="font-size: 80%">
<?php

  
  foreach($vars['params'] as $key=>$value){
      			echo elgg_echo('<tr><td style="width: 30%">'.$value["username"].'</td><td style="width: 30%">'.$value["name"].'</td><td style="width: 30%">'.$value["email"].'</td><td><a class="cmd" href="'.$value["url"].'"'.">Importer</a></td></tr>\n");
 	}
?>

</table>
