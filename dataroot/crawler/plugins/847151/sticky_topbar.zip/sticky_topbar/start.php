<?php
function stickytopbar_init() {
}
 
register_elgg_event_handler('init', 'system', 'stickytopbar_init');
?>