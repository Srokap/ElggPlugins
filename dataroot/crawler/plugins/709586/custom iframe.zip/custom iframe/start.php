<?php
  function custom_init() {        
    add_widget_type('custom', elgg_echo("custom:title"),elgg_echo("custom:description"));
  }
 
  register_elgg_event_handler('init','system','custom_init');       
?>