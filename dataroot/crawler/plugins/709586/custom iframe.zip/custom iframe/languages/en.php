<?php

	$english = array(
	
		/**
		 * Custom widget
		 */
		
	        
	        'custom:title' => "Custom widget",
	        'custom:description' => "Change your title in language file"
	        
		
	);
					
	add_translation("en",$english);

?>