<div class="contentWrapper">
<iframe src="http://www.dsportal.sk/praca-widget" width="280" height="400" frameborder="0" owerflow="hidden" > </iframe>