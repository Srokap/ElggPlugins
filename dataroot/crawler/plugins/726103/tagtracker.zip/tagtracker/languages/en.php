<?php

        $english = array(
                 /**
                  * widget
                  */
			 'tagtracker:widget:description' => "Tag tracker",
			 'tagtracker:tag' => "Tag(s) - comma delimited : ",
			 'tagtracker:more' => "More entries",
			 'tagtracker:tagcount' => "Entries to display per tag",
			 'tagtracker:widget:title' => "Activity for tag(s) : ", 
			 'group_custom_layout:widgets:tagtrack:tag' => "Tracked tags (comma delimited list, case sensitive) ",
			'group_custom_layout:widgets:tagtrack:settings:name' => "Title for this widget",
			'group_custom_layout:widgets:tagtrack:title' => "Tracked tag(s) ",
			'group_custom_layout:widgets:tagtrack:tagcount' => "Number of tags to show per tag ",

			 );

	add_translation("en",$english);

?>