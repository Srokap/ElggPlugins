<?php

  /**
   * Tag tracker widget
   * This plugin provides a widget to show activity relating to a specified tag.
   * @Version 1.0.2
   * @package TagTracker
   * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
   * @Author Jean-Baptiste Perriot <jb@perriot.fr>
	* @Author Jon Dron <jond@athabascau.ca>
	
   */

function tagtracker_init() {
  // Load system configuration
  global $CONFIG;
  
  // Extend some view
  extend_view('css','tagtracker/css');
  
  //add a widget
  add_widget_type('tagtracker', elgg_echo("Tag tracker"), elgg_echo('tagtracker:widget:description'));

// add group custom layout widget
if (is_plugin_enabled("group_custom_layout")){
	add_group_widget("tagtrack", elgg_echo("group_custom_layout:widgets:tagcloud:description"));
}		

  }

register_elgg_event_handler('init','system','tagtracker_init');

?>