<div>

<?php
//tag tracker widget

$title=$vars['entity']->widgettitle;
$tag = $vars['entity']->tag;
$artag=explode(",",$tag);
$tagcount=$vars['entity']->tagcount;
$owner_guid_array = 0;
$owner_guid = -1;
$subtype = "";
$objecttype = "";
$md_type = "";			
if (!isset($tagcount)){
	$tagcount=5;
}



//$searchA = "<a href=\"" . $vars['url'] . "search/?tag=". urlencode($tag) . "\">" . elgg_echo('tagtracker:more') . "</a>";

$entities = elgg_get_entities_from_metadata(array(types=>'object' ,'metadata_names'=>'tags','metadata_values'=>$artag, 'limit'=>$tagcount));

 foreach ($entities as $entity) {
   $date = sprintf(elgg_echo("blog:strapline"),
 		  date("F j, Y",$entity->time_created)
 		  );

   echo "<div class=\"blog_post_icon\">";
   echo elgg_view("profile/icon", array('entity' => $entity->getOwnerEntity(), 'size' => 'tiny'));
   echo "</div>";
   echo "<p>&nbsp;";
   echo "<a href=\"" . $entity->getURL() . "\">" . $entity->title . "</a> - " . $date;
  echo "<br/>&nbsp;";
   echo "</p>";
   echo "<div class=\"clearfloat\"></div>";
 }

 // echo "<p>".$searchA. "</p>";

?>

</div>
<?php
//widgets eligo 2.15 and above replace the name of the widget
// so this code is redundant if it is installed
//sadly, elgg appears to have no means to return the version number
// so need to check whether admin setting for override is set
//print_r($vars);
if(is_plugin_enabled('widgets_eligo')&&get_plugin_setting("eligo_show_titles","widgets_eligo")=="yes"){

	//print_r( find_plugin_settings('widgets_eligo'));
	//we do not need to do anything, Eligo will do it for us

}else{

// eligo not enabled or not taking control of titles so do it ourselves
?>

<script type='text/javascript'>
  var title = "<?php echo elgg_echo("tagtracker:widget:title"). $tag; ?>";
$('#widget<?php echo $vars['entity']->getGUID(); ?> h1').html(title);
</script>

<?php
} //endif check for widgets eligo
?>