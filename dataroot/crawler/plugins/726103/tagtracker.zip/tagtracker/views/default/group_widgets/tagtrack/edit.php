<?php
/* this makes use of code from tag_activity, by twister and 
is built for group custom layout (GCL). It adds a widget to GCL that
shows search results for a specified tag. This is useful
if a group is the centre of a network where individuals in that group
are using a specified tag in personal (or other group) posts)
Copyright: Jon Dron <jond@athabascau.ca>
Licence: GPL 2.0

*/


	$entity = $vars["entity"];
	if(!empty($entity) && $entity instanceof ElggObject && $entity->getSubtype() == GROUP_CUSTOM_LAYOUT_WIDGET){
		$widget_name = $entity->guid;
		$tag = $entity->tracktag;
		$tagtrack_count=$entity->tagtrack_count;
	}	
if (!isset($tag)) $tag = "";
if (!isset($tagtrack_count)) $tagtrack_count=6;

// this code is unneeded with widgets_eligo 2.15 and above
// if you have an earlier version, upgrade now!

if (is_plugin_enabled('widgets_eligo')&&get_plugin_setting("eligo_show_titles","widgets_eligo")=="yes"){

	//use eligo widget title

}else{
	?>
	<p>
		<?php echo elgg_echo("group_custom_layout:widgets:tagtrack:settings:name"); ?><br />	
		<input type="text" 
			name="group_widgets_<?php echo $widget_name; ?>_settings[widget_title]" 
			value="<?php echo $entity->widget_title; ?>" size="40" maxlength="250"/><br />
	</p>

<?php

} //endif check for widgets_eligo

?>
<p>
<?php echo elgg_echo("group_custom_layout:widgets:tagtrack:tag"); ?>
<br />
<input type="text"  name="group_widgets_<?php echo $widget_name; ?>_settings[tracktag]" value="<?php echo htmlentities($tag); ?>" />
</p>
<p>
<?php
	//create option list for number of tags to show
	$options = "";
	for($i = 3; $i <= 30; $i+=3){
		if($i == $tagtrack_count){
			$options .= "<option value='" . $i . "' selected='yes'>" . $i . "</option>\n";
		} else {
			$options .= "<option value='" . $i . "'>" . $i . "</option>\n";
		}
	}
?>
<?php echo elgg_echo("group_custom_layout:widgets:tagtrack:tagcount"); ?> <br />
<select name="group_widgets_<?php echo $widget_name; ?>_settings[tagtrack_count]">
		<?php echo $options; ?>
	</select>
</p>
