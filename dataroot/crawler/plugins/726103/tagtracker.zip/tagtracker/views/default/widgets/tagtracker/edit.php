<?php
$tag = $vars['entity']->tag;
if (!isset($tag)) $tag = "";
$tagtrack_count=$vars['entity']->tagtrack_count;
if (!isset($tagtrack_count)) $tagtrack_count=6;
?>

<p>
<?php echo elgg_echo("tagtracker:tag"); ?> <br />
<input type="text" onclick="this.select();" name="params[tag]" value="<?php echo htmlentities($vars['entity']->tag); ?>" />
</p>
<p>
<?php
	//create option list for number of tags to show
	$options = "";
	for($i = 3; $i <= 30; $i+=3){
		if($i == $tagtrack_count){
			$options .= "<option value='" . $i . "' selected='yes'>" . $i . "</option>\n";
		} else {
			$options .= "<option value='" . $i . "'>" . $i . "</option>\n";
		}
	}
?>
<?php echo elgg_echo("tagtracker:tagcount"); ?> <br />
<select name="params[tagcount]" value="<?php echo htmlentities($vars['entity']->tag);?>">
		<?php echo $options; ?>
	</select>
</p>

