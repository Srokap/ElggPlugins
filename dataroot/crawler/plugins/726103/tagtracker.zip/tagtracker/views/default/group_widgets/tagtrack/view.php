<div>
<?php
// group custom layout widget for tag tracking

	$group = $vars["group"];
	$widget=$vars["widget"];
	$widget_name=filter_tags($widget->widget_title);
	$numitems=$widget->tagtrack_count;
	if (!isset($widget->tagtrack_count)){
		$numitems=5;
	}
	

$tag = $widget->tracktag;
$artag=explode(",",$tag);
$owner_guid_array = 0;
$owner_guid = -1;
$subtype = "";
$objecttype = "";
$md_type = "";			


if (!empty($tag)) {
	//widgets eligo 2.15 and above replace the name of the widget
// so this code is redundant if it is installed
//sadly, elgg appears to have no means to return the version number of eligo
// so need to check whether admin setting for override is set
//print_r($vars);
	if(is_plugin_enabled('widgets_eligo')&&get_plugin_setting("eligo_show_titles","widgets_eligo")=="yes"){
		//don't show our name, use widget_elgio
		echo "<h2>".$widget->CS_display_title." (tags: ".$tag.")</h2>";
	
	}else{
		//show our widget name
	   	if(!empty($widget_name)){	
			echo  "<h2>".$widget_name." (tags: ". $tag.")</h2>";	
		}else{
			 echo "<h2>".elgg_echo('group_custom_layout:widgets:tagtrack:title')."</h2>"; 
		}
	}	

$entities = elgg_get_entities_from_metadata(array(types=>'object' ,'metadata_names'=>'tags','metadata_values'=>$artag, 'limit'=>$numitems));

 foreach ($entities as $entity) {
   $date = sprintf(elgg_echo("blog:strapline"),
 		  date("F j, Y",$entity->time_created)
 		  );
   echo "<div class=\"blog_post_icon\">";
	//print_r ($entity);
   echo elgg_view("profile/icon", array('entity' => $entity->getOwnerEntity(), 'size' => 'tiny'));
   echo "</div> ";

   echo "<p> ";
   echo " <a href=\"" . $entity->getURL() . "\">" . $entity->title . "</a> - " . $date;
  echo "<br/>&nbsp;";
   echo "</p>";

   echo "<div class=\"clearfloat\"></div>";
 }

//	$searchA = "<a href=\"" . $vars['url'] . "search/?tag=". urlencode(filter_tags($tag)) . "\">" . 	elgg_echo('tagtracker:more') . "</a>";
// echo "<p>".$searchA. "</p>";

}
?>

</div>

