   [0] =&gt; stdClass Object
        (
            [id] =&gt; 610
            [object_id] =&gt; 57
            [object_class] =&gt; ElggFile
            [object_type] =&gt; object
            [object_subtype] =&gt; file
            [event] =&gt; create
            [performed_by_guid] =&gt; 2
            [owner_guid] =&gt; 2
            [access_id] =&gt; 0
            [enabled] =&gt; yes
            [time_created] =&gt; 1230795800
        )
ElggObject Object
(
    [attributes:protected] =&gt; Array
        (
            [guid] =&gt; 55
            [type] =&gt; object
            [subtype] =&gt; 7
            [owner_guid] =&gt; 2
            [container_guid] =&gt; 2
            [site_guid] =&gt; 1
            [access_id] =&gt; 2
            [time_created] =&gt; 1230722365
            [time_updated] =&gt; 1230722365
            [enabled] =&gt; yes
            [tables_split] =&gt; 2
            [tables_loaded] =&gt; 2
            [title] =&gt; 
            [description] =&gt; geryte
        )

    [url_override:protected] =&gt; 
    [icon_override:protected] =&gt; 
    [temp_metadata:protected] =&gt; Array
        (
        )

    [temp_annotations:protected] =&gt; Array
        (
        )

    [valid:private] =&gt; 

)
