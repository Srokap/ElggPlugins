<?php
/**
 * Customize CSS
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Mike Tyler
 * @copyright Mike Tyler 2012
 * 
 **/

// the init function contains all of our code that we want the Elgg system to do during system initialization
function firsttheme_init() {
    $priority = 10;
	elgg_extend_view('css/elgg','firsttheme/css', $priority);
}

elgg_register_event_handler('init','system','firsttheme_init');
?>