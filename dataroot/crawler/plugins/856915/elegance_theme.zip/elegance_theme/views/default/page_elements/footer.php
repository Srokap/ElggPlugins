<?php


/**
	 * elegance theme for Elgg 
	 * Version 1.0
	 * @package: elegance theme for Elgg
	 * @author azycraze
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @copyright azycraze 2012
	 */
	 
?>
<div class="clearfloat"></div>

<div id="layout_footer">
<table width="700" height="30" border="0" align="center" cellpadding="0" cellspacing="0">
	<tr>
		
		<td width="443" height="28" align="left" valign="middle">
		<p align="left" class="footer_legal_links" ><a href="http://azywebcoder.blogspot.in" target="_blank"> Elegance Theme designed by Azycraze </a> </p>
		 
		</td>

		<td width="206" height="50" >
		<p align="right" class="footer_toolbar_links"> 
          <?php
			echo elgg_view('footer/links');
		?>
        </p>
		</td>

	</tr>
</table>
<a href="http://www.elgg.org" target="_blank"><img style="float:right;margin:-10px 105px 0 0;" src="<?php echo $vars['url']; ?>_graphics/powered_by_elgg_badge_drk_bckgnd.gif" border="0" /></a>  
</div><!-- /#layout_footer -->

<div class="clearfloat"></div>

</div><!-- /#page_wrapper -->
</div><!-- /#page_container -->
<!-- insert an analytics view to be extended -->
<?php
	echo elgg_view('footer/analytics');
?>
</body>
</html>