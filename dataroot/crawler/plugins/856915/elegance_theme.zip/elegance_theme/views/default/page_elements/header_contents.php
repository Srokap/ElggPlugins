<?php


/**
	 * elegance theme for Elgg 
	 * Version 1.0
	 * @package: elegance theme for Elgg
	 * @author azycraze
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @copyright azycraze 2012
	 */
	 
?>
<script type="text/javascript" src="<?php echo $vars['url']; ?>/mod/elegance_theme/js/jquery.tipsy.js"></script> 
<script type='text/javascript'>
  $(function() {
    $('#site_logo a').tipsy({fade: true});
	$('#menu a').tipsy({fade: true});
	$('#ddForm a').tipsy({gravity: $.fn.tipsy.autoWE});
	$('.logout a').tipsy({fallback: "Logout" ,gravity: $.fn.tipsy.autoWE});
	$('#elgg_topbar a').tipsy({fade: true,fallback: "Click me"}); 
	$('.icon img').tipsy({fallback: "Click to visit"});
  });
</script>
<div id="layout_header"> 
<div id="wrapper_header">  
    <!-- display the page title --> 
    <div id="site_logo">  
            <?php
			if (!is_plugin_enabled('custom_index') && isloggedin()) {
			?> 
       			 <a href="<?php echo $vars['url']; ?>pg/dashboard/" title="Go to home"><img src="<?php echo $vars['url']; ?>mod/elegance_theme/graphics/site_logo.gif" border="0" /></a> 
        	<?php
			} else {
			?> 
        		<a href="<?php echo $vars['url']; ?>" title="Go to home"><img src="<?php echo $vars['url']; ?>mod/elegance_theme/graphics/site_logo.gif" border="0" /></a> 
        	<?php
			}
			?>  
   	</div> 
		
	<div id="elgg_topbar_container_search"> 
	<?php echo elgg_view('page_elements/searchbox'); ?> 
	</div> 
		
		<?php
		if (!isloggedin()) {
		?> 
     	<script src="<?php echo $vars['url']; ?>/mod/elegance_theme/js/login.js"></script>  
    	<div id="loginContainer"> <a href="#" title="Login" id="loginButton"><span>Login</span><em></em></a> 
     	<div style="clear:both"></div>
      		<div id="loginBox"> 
        		<div id="loginForm"> 
          			<fieldset id="body">
          				<?php
						$form_body = "<p><label>" . elgg_echo('username') . "<br />" . elgg_view('input/text', array('internalname' => 'username', 'class' => '')) . "</label><br />";
						$form_body.= "<label>" . elgg_echo('password') . "<br />" . elgg_view('input/password', array('internalname' => 'password', 'class' => '')) . "</label><br /><br />";
						$form_body.= elgg_view('input/submit', array('value' => elgg_echo('login'))) . "</p>";
						$form_body.= "<p><a href=\"" . $vars['url'] . "account/forgotten_password.php\" title=\"Click here to recover\">" . elgg_echo('user:password:lost') . "</a></p>";
						echo elgg_view('input/form', array('body' => $form_body, 'action' => "" . $vars['url'] . "action/login"));
						?>
          			</fieldset>
       			</div>
      		</div>
    	</div> 
			
    <div id="link"> 
      <ul class="topbardropdownmenu" style="left:100px;">
        <a href="<?php echo $vars['url']; ?>account/register.php"  class="menuitemtools" title="Home"><?php echo(elgg_echo('Register')); ?></a> 
      </ul>
    </div>
        <!-- Login Ends Here --> 
		
		<?php
		} else {
		?> 			

			<div id="menu">
  			<a href="<?php echo $vars['url']; ?>pg/groups/member/<?=$_SESSION['user']->username ?>/" title="Groups">
		    <img src="<?php echo $vars['url']; ?>mod/elegance_theme/graphics/group.png" border="0" /></a>
			<a href="<?php echo $vars['url']; ?>pg/photos/owned/<?=$_SESSION['user']->username?>/" title="Photos">
		    <img src="<?php echo $vars['url']; ?>mod/elegance_theme/graphics/foto.png" border="0" /></a>
			<a href="<?php echo $vars['url']; ?>pg/videos/owned/<?=$_SESSION['user']->username?>/" title="Videos">
		    <img src="<?php echo $vars['url']; ?>mod/elegance_theme/graphics/videos.png" border="0" /></a>
		</div>

	<script src="<?php echo $vars['url']; ?>/mod/elegance_theme/js/dd.js"></script>  
			
    <div id="dd"> <a href="#" id="dd_button"><div id="trans"></div><em></em></a> 
    <div style="clear:both"></div>
   		<div id="dd_box">
	 		<div id="ddForm">  
			<div class='logout'>
	 		<?php echo elgg_view('output/url', array('href' => "{$vars['url']}action/logout",'text' => elgg_echo('logout'), 'is_action' => TRUE)); ?>
			</div>
	 		<a href="<?php echo $vars['url']; ?>pg/settings/" title="Edit your Settings">Account Settings</a>
	 		<?php
			// The administration link is for admin or site admin users only
			if ($vars['user']->isAdmin()) {
			?>
	 			<a href="<?php echo $vars['url']; ?>pg/admin/" title="Manage your site">Site Administration</a>
	 
			<?php
		   	}
		   	?>
		   </div>
		</div>
  	</div> 
<!--dddd---->

			
    <div id="link"> 
      <ul class="topbardropdownmenu">
        <a href="<?php echo $_SESSION['user']->getURL(); ?>" class="menuitemtools" title="View my profile"><?php echo(elgg_echo('My Profile')); ?></a> 
      </ul>
      <ul class="topbardropdownmenu">
        <a href="<?php echo $vars['url']; ?>pg/dashboard/" class="menuitemtools" title="Go to dashboard"><?php echo(elgg_echo('Dashboard')); ?></a> 
      </ul>
      <?php echo elgg_view("navigation/topbar_tools"); ?> </div>
<?php
}
?>
</div> <!-- /#wrapper_header --> 
</div><!-- /#layout_header --> 
<!--designed by azycraze--> 

