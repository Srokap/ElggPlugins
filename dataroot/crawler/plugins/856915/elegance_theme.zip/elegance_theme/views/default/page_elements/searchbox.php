<style>
#searchform input.search_input {
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	background-color:#FFFFFF;
	border:1px solid #BBBBBB;
	color:#999999;
	font-size:15px;
	font-weight:bold;
	padding:2px;
	width:300px;
	height:25px;
	}
#searchform input.search_input:focus{
	border:2px solid #f67ba3;
	padding:2px;
	}
#searchform input.search_submit_button {
    width:19px;
    height:19px;
    background:url(<?php echo $vars['url']; ?>/mod/elegance_theme/graphics/search-icon.png) no-repeat;
    border:0;
    position:absolute;
    top:7px; right:14px;
    z-index:5;
    cursor:pointer;
	}
#searchform input.search_submit_button:hover {
background:url(<?php echo $vars['url']; ?>/mod/elegance_theme/graphics/search-icon.png) no-repeat;
}
</style>
<?php

if (array_key_exists('value', $vars)) {
	$value = $vars['value'];
} elseif ($value = get_input('q', get_input('tag', NULL))) {
	$value = $value;
} else {
	$value = elgg_echo('search');
}

$value = stripslashes($value);

?>

<form id="searchform" action="<?php echo $vars['url']; ?>pg/search/" method="get">
	<input type="text" size="21" name="q" value="<?php echo $value; ?>" onclick="if (this.value=='<?php echo elgg_echo('search'); ?>') { this.value='' }" class="search_input" />
	<input type="submit" value="" class="search_submit_button"/>
</form>

