<?php


/**
	 * elegance theme for Elgg 
	 * Version 1.0
	 * @package: elegance theme for Elgg
	 * @author azycraze
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @copyright azycraze 2012
	 */
	 
?>

<body>

<?php

     if (isloggedin()) {
?>

<div id="elgg_topbar">

<div id="elgg_topbar_container_left">
	<div class="toolbarimages">
	
		<a href="<?php echo $_SESSION['user']->getURL(); ?>" title="My Profile"><img class="user_mini_avatar" src="<?php echo $_SESSION['user']->getIcon('topbar'); ?>"></a>
		
	</div>  
			
        <div class="toolbarlinks2">		
		<?php
		//allow people to extend this top menu
		echo elgg_view('elgg_topbar/extend', $vars);
		?>		
		
	</div>

</div>

</div><!-- /#elgg_topbar -->

<div class="clearfloat"></div>

<?php
    } else {
?>

</div>
<!-- /#topbar -->
<div class="clearfloat"></div>
<?php
	}
?>
</body>
<!--designed by azycraze-->