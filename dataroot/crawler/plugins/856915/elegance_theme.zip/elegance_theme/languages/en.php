<?php
$english = array(
	'quotes:param_label'	=> 'My Parameter',

);

add_translation("en", $english);
