// Login Form

$(function() {
    var button = $('#dd_button');
    var box = $('#dd_box');
    var form = $('#ddForm');
    button.removeAttr('href');
    button.mouseup(function(more) {
        box.toggle();
        button.toggleClass('active');
    });
    form.mouseup(function() { 
        return false;
    });
    $(this).mouseup(function(more) {
        if(!($(more.target).parent('#dd_button').length > 0)) {
            button.removeClass('active');
            box.hide();
        }
    });
});
