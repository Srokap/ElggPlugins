<?php
/**
 * urduEditor
 * 
 * urduEditor Plugin for Elgg 1.8
 * URDU 
 * @author Imran Ali Mughal
 * @urduSript by Nabeel Naqvi : http://www.urduweb.org/mehfil
 * @email mughalscomputers@gmail.com
**/

	
	/* Initialise the urduEditor */
	function urdu_editor(){
		
		global $CONFIG;	
		
	}
	
	

	/* Initialise log browser */
	register_elgg_event_handler('init','system','urdu_editor');