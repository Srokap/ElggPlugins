<?php

  
    function aaudio_init() 
    {	
        add_widget_type('aaudio',elgg_echo("Audio Player"),elgg_echo("Audio Player"));	    
    }
     
    // Make sure the status initialisation function is called on initialisation
    register_elgg_event_handler('init','system','aaudio_init');
		
?>