<?php

   //the page owner
   $owner = $vars['entity']->owner_guid;
   //The maximum mp3 files on playlist	
   $number = 10000;
   $playlist = "";
   $titles = "";
	
   //get the user's files
   $files = get_user_objects($vars['entity']->owner_guid, "file", $number, 0);

   //if there are some files, go get them
   if ($files) 
   {
      //display in list mode
      foreach($files as $f) {
            $mime = $f->mimetype;
            if (file_get_general_file_type($mime) == "audio") {
                if ($playlist) {
                    $playlist = $playlist . '|';
                    $titles = $titles . '|';
                }
                $playlist = $playlist . $vars['url'] . 'action/file/download?file_guid=' . $f->guid;
                $titles = $titles . $f->title;
            }
        }
    } 
    else 
    {
	    echo elgg_echo("No Files");
    }

?>

<!--width="200" height="100" -->
<div>
<object type="application/x-shockwave-flash" data="<?php echo $vars['url']; ?>mod/aaudio/audioplayer/player_mp3_multi.swf" width="300" height="200" >
  <param name="movie" value="<?php echo $vars['url']; ?>mod/aaudio/audioplayer/player_mp3_multi.swf" />
     <param name="FlashVars" value="mp3=<?php echo $playlist; ?>&amp;title=<?php echo $titles; ?>&amp;height=200&amp;width=300" />
</object>
 </div>
