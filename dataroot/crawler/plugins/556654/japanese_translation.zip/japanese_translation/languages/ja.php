<?php
/**
 * Activity viewer
 *
 * @package Elgg
 * @subpackage Core
 * @author Curverider Ltd
 * @link http://elgg.org/
 */

$japanese = array(

/**
 * Sites
 */

	'item:site' => 'サイト',//'Sites',

/**
 * Sessions
 */

	'login' => 'ログイン',//"Log in",
	'loginok' => "ログインしました。",//"You have been logged in.",
	'loginerror' => "あなたのアカウントの承認手続きが完了していないか、あなたの入力に間違いがあるか、何回もログインに失敗したせいかもしれません。 あなたのログイン情報が正しいか確認してください。",//"We couldn't log you in. This may be because you haven't validated your account yet, the details you supplied were incorrect, or you have made too many incorrect login attempts. Make sure your details are correct and please try again.",

	'logout' => "ログアウト",//"Log out",
	'logoutok' => "ログアウトしました。",//"You have been logged out.",
	'logouterror' => "ログアウトできません。もう一度試してください。",//We couldn't log you out. Please try again.",

	'loggedinrequired' => "このページを見るにはログインが必要です。",//"You must be logged in to view that page.",
	'adminrequired' => "このページを見るには管理者権限が必要です。",//"You must be an administrator to view that page.",

/**
 * Errors
 */
	'exception:title' => "ようこそ、このサイトへ！",//"Welcome to Elgg.",

	'InstallationException:CantCreateSite' => "指定のサイトの作成ができません（名称:%s, Url: %s）",//"Unable to create a default ElggSite with credentials Name:%s, Url: %s",

	'actionundefined' => "要求されたアクション(%s) はこのシステムで定義されていません。",//"The requested action (%s) was not defined in the system.",
	'actionloggedout' => "ログインしなければそのアクションは実行できません。",//"Sorry, you cannot perform this action while logged out.",

	'SecurityException:Codeblock' => "特権コードブロックの実行が拒否されました。",//"Denied access to execute privileged code block",
	'DatabaseException:WrongCredentials' => "Elggは入力された情報でデータベースに接続することができませんでした。",//"Elgg couldn't connect to the database using the given credentials.",
	'DatabaseException:NoConnect' => "Elggは次のデータベース '%s' を選択することができません。 データベースが作成済みでそのデータベースにアクセスできる権限をもっているか確認してください。",//"Elgg couldn't select the database '%s', please check that the database is created and you have access to it.",
	'SecurityException:FunctionDenied' => "特殊機能 '%s' へのアクセスが拒否されました。",//"Access to privileged function '%s' is denied.",
	'DatabaseException:DBSetupIssues' => "いくつかの問題があります: ",//"There were a number of issues: ",
	'DatabaseException:ScriptNotFound' => "Elggに要求された %s のデータベーススクリプトが見当たりません。",//"Elgg couldn't find the requested database script at %s.",

	'IOException:FailedToLoadGUID' => "GUID:%d の新しい %s の読み込みに失敗しました。",//"Failed to load new %s from GUID:%d",
	'InvalidParameterException:NonElggObject' => "ElggObjectではないオブジェクトがElggObject counstructorに渡されました！",//"Passing a non-ElggObject to an ElggObject constructor!",
	'InvalidParameterException:UnrecognisedValue' => "Constuctorに不明の値が渡されました。",//"Unrecognised value passed to constuctor.",

	'InvalidClassException:NotValidElggStar' => "GUID:%d は有効な %s ではありません。",//"GUID:%d is not a valid %s",

	'PluginException:MisconfiguredPlugin' => "%s がElggプラグインとして動作できません。Elgg wikiや他のドキュメントを参照して修正してください。",//"%s is a misconfigured plugin. It has been disabled. Please see the Elgg wiki for possible causes.",

	'InvalidParameterException:NonElggUser' => "ElggUserではないオブジェクトがElggUser counstructorに渡されました！",//"Passing a non-ElggUser to an ElggUser constructor!",

	'InvalidParameterException:NonElggSite' => "ElggSiteではないオブジェクトがElggSite counstructorに渡されました！",//"Passing a non-ElggSite to an ElggSite constructor!",

	'InvalidParameterException:NonElggGroup' => "ElggGroupではないオブジェクトがElggGroup counstructorに渡されました！",//"Passing a non-ElggGroup to an ElggGroup constructor!",

	'IOException:UnableToSaveNew' => "新しい $s が保存できません。",//"Unable to save new %s",

	'InvalidParameterException:GUIDNotForExport' => "GUID has not been specified during export, this should never happen.",
	'InvalidParameterException:NonArrayReturnValue' => "Entity serialisation function passed a non-array returnvalue parameter",

	'ConfigurationException:NoCachePath' => "キャッシュのパスが設定されていません。",//"Cache path set to nothing!",
	'IOException:NotDirectory' => "%s はディレクトリーではありません。",//"%s is not a directory.",

	'IOException:BaseEntitySaveFailed' => "Unable to save new object's base entity information!",
	'InvalidParameterException:UnexpectedODDClass' => "import() passed an unexpected ODD class",
	'InvalidParameterException:EntityTypeNotSet' => "Entity タイプをセットしてください。",//"Entity type must be set.",

	'ClassException:ClassnameNotClass' => "%s は %s ではありません。",//"%s is not a %s.",
	'ClassNotFoundException:MissingClass' => "Class '%s' was not found, missing plugin?",
	'InstallationException:TypeNotSupported' => "Type %s is not supported. This indicates an error in your installation, most likely caused by an incomplete upgrade.",

	'ImportException:ImportFailed' => "次の要素をインポートできません。: %d",//"Could not import element %d",
	'ImportException:ProblemSaving' => "保存中に問題が発生しました。:  %s",//"There was a problem saving %s",
	'ImportException:NoGUID' => "New entity created but has no GUID, this should not happen.",

	'ImportException:GUIDNotFound' => "Entity '%d' could not be found.",
	'ImportException:ProblemUpdatingMeta' => "There was a problem updating '%s' on entity '%d'",

	'ExportException:NoSuchEntity' => "No such entity GUID:%d",

	'ImportException:NoODDElements' => "No OpenDD elements found in import data, import failed.",
	'ImportException:NotAllImported' => "Not all elements were imported.",

	'InvalidParameterException:UnrecognisedFileMode' => "Unrecognised file mode '%s'",
	'InvalidParameterException:MissingOwner' => "ファイル %s (%d) はオーナーが不明です。",//"File %s (%d) is missing an owner!",
	'IOException:CouldNotMake' => "%s が作成できません。",//"Could not make %s",
	'IOException:MissingFileName' => "ファイルを開く前に名前を特定する必要があります。",//"You must specify a name before opening a file.",
	'ClassNotFoundException:NotFoundNotSavedWithFile' => "Filestore not found or class not saved with file!",
	'NotificationException:NoNotificationMethod' => "No notification method specified.",
	'NotificationException:NoHandlerFound' => "No handler found for '%s' or it was not callable.",
	'NotificationException:ErrorNotifyingGuid' => "There was an error while notifying %d",
	'NotificationException:NoEmailAddress' => "Could not get the email address for GUID:%d",
	'NotificationException:MissingParameter' => "Missing a required parameter, '%s'",

	'DatabaseException:WhereSetNonQuery' => "Where set contains non WhereQueryComponent",
	'DatabaseException:SelectFieldsMissing' => "Fields missing on a select style query",
	'DatabaseException:UnspecifiedQueryType' => "Unrecognised or unspecified query type.",
	'DatabaseException:NoTablesSpecified' => "No tables specified for query.",
	'DatabaseException:NoACL' => "No access control was provided on query",

	'InvalidParameterException:NoEntityFound' => "No entity found, it either doesn't exist or you don't have access to it.",

	'InvalidParameterException:GUIDNotFound' => "GUID:%s could not be found, or you can not access it.",
	'InvalidParameterException:IdNotExistForGUID' => "Sorry, '%s' does not exist for guid:%d",
	'InvalidParameterException:CanNotExportType' => "Sorry, I don't know how to export '%s'",
	'InvalidParameterException:NoDataFound' => "Could not find any data.",
	'InvalidParameterException:DoesNotBelong' => "Does not belong to entity.",
	'InvalidParameterException:DoesNotBelongOrRefer' => "Does not belong to entity or refer to entity.",
	'InvalidParameterException:MissingParameter' => "Missing parameter, you need to provide a GUID.",

	'APIException:ApiResultUnknown' => "API Result is of an unknown type, this should never happen.",
	'ConfigurationException:NoSiteID' => "No site ID has been specified.",
	'SecurityException:APIAccessDenied' => "Sorry, API access has been disabled by the administrator.",
	'SecurityException:NoAuthMethods' => "No authentication methods were found that could authenticate this API request.",
	'InvalidParameterException:APIMethodOrFunctionNotSet' => "Method or function not set in call in expose_method()",
	'InvalidParameterException:APIParametersArrayStructure' => "Parameters array structure is incorrect for call to expose method '%s'",
	'InvalidParameterException:UnrecognisedHttpMethod' => "Unrecognised http method %s for api method '%s'",
	'APIException:MissingParameterInMethod' => "Missing parameter %s in method %s",
	'APIException:ParameterNotArray' => "%s does not appear to be an array.",
	'APIException:UnrecognisedTypeCast' => "Unrecognised type in cast %s for variable '%s' in method '%s'",
	'APIException:InvalidParameter' => "Invalid parameter found for '%s' in method '%s'.",
	'APIException:FunctionParseError' => "%s(%s) has a parsing error.",
	'APIException:FunctionNoReturn' => "%s(%s) returned no value.",
	'APIException:APIAuthenticationFailed' => "Method call failed the API Authentication",
	'APIException:UserAuthenticationFailed' => "Method call failed the User Authentication",
	'SecurityException:AuthTokenExpired' => "Authentication token either missing, invalid or expired.",
	'CallException:InvalidCallMethod' => "%s must be called using '%s'",
	'APIException:MethodCallNotImplemented' => "Method call '%s' has not been implemented.",
	'APIException:FunctionDoesNotExist' => "Function for method '%s' is not callable",
	'APIException:AlgorithmNotSupported' => "Algorithm '%s' is not supported or has been disabled.",
	'ConfigurationException:CacheDirNotSet' => "キャッシュディレクトリ 'cache_path' が未設定です。",//"Cache directory 'cache_path' not set.",
	'APIException:NotGetOrPost' => "リクエストメソッドは GET か POST でなければなりません。",//"Request method must be GET or POST",
	'APIException:MissingAPIKey' => "Missing API key",
	'APIException:BadAPIKey' => "Bad API key",
	'APIException:MissingHmac' => "Missing X-Elgg-hmac header",
	'APIException:MissingHmacAlgo' => "Missing X-Elgg-hmac-algo header",
	'APIException:MissingTime' => "Missing X-Elgg-time header",
	'APIException:MissingNonce' => "Missing X-Elgg-nonce header",
	'APIException:TemporalDrift' => "X-Elgg-time is too far in the past or future. Epoch fail.",
	'APIException:NoQueryString' => "No data on the query string",
	'APIException:MissingPOSTHash' => "Missing X-Elgg-posthash header",
	'APIException:MissingPOSTAlgo' => "Missing X-Elgg-posthash_algo header",
	'APIException:MissingContentType' => "Missing content type for post data",
	'SecurityException:InvalidPostHash' => "POST data hash is invalid - Expected %s but got %s.",
	'SecurityException:DupePacket' => "Packet signature already seen.",
	'SecurityException:InvalidAPIKey' => "Invalid or missing API Key.",
	'NotImplementedException:CallMethodNotImplemented' => "Call method '%s' is currently not supported.",

	'NotImplementedException:XMLRPCMethodNotImplemented' => "XML-RPC method call '%s' not implemented.",
	'InvalidParameterException:UnexpectedReturnFormat' => "Call to method '%s' returned an unexpected result.",
	'CallException:NotRPCCall' => "Call does not appear to be a valid XML-RPC call",

	'PluginException:NoPluginName' => "The plugin name could not be found",

	'ConfigurationException:BadDatabaseVersion' => "The database backend you have installed doesn't meet the basic requirements to run Elgg. Please consult your documentation.",
	'ConfigurationException:BadPHPVersion' => "You need at least PHP version 5.2 to run Elgg.",
	'configurationwarning:phpversion' => "Elgg requires at least PHP version 5.2, you can install it on 5.1.6 but some features may not work. Use at your own risk.",


	'InstallationException:DatarootNotWritable' => "データディレクトリ %s に書き込み権限がありません。",//"Your data directory %s is not writable.",
	'InstallationException:DatarootUnderPath' => "データディレクトリ %s はelggのインストールしているパス以下に置くことはできません。",//"Your data directory %s must be outside of your install path.",
	'InstallationException:DatarootBlank' => "データディレクトリが見当たりません。",//"You have not specified a data directory.",

	'SecurityException:authenticationfailed' => "User could not be authenticated",

	'CronException:unknownperiod' => '%s is not a recognised period.',

	'SecurityException:deletedisablecurrentsite' => 'You can not delete or disable the site you are currently viewing!',

	'memcache:notinstalled' => 'PHP memcache module not installed, you must install php5-memcache',
	'memcache:noservers' => 'No memcache servers defined, please populate the $CONFIG->memcache_servers variable',
	'memcache:versiontoolow' => 'Memcache needs at least version %s to run, you are running %s',
	'memcache:noaddserver' => 'Multiple server support disabled, you may need to upgrade your PECL memcache library',

	'deprecatedfunction' => 'Warning: This code uses the deprecated function \'%s\' and is not compatible with this version of Elgg',

	'pageownerunavailable' => '警告： ページオーナー %d を許可できません。',//'Warning: The page owner %d is not accessible!',
/**
 * API
 */
	'system.api.list' => "システムから呼び出されるすべての有効なAPIリスト",//"List all available API calls on the system.",
	'auth.gettoken' => "This API call lets a user obtain a user authentication token which can be used for authenticating future API calls. Pass it as the parameter auth_token",

/**
 * User details
 */

	'name' => "氏名",//"Display name",
	'email' => "Eメール",//"Email address",
	'username' => "ユーザー名",//"Username",
	'password' => "パスワード",//"Password",
	'passwordagain' => "パスワード（確認）",//"Password (again for verification)",
	'admin_option' => "このユーザーに管理者権限を与える",//"Make this user an admin?",

/**
 * Access
 */

	'PRIVATE' => "非公開",//"Private",
	'LOGGED_IN' => "ログインユーザーのみ",//"Logged in users",
	'PUBLIC' => "すべてに公開",//"Public",
	'access:friends:label' => "友達のみ",//"Friends",
	'access' => "公開範囲",//"Access",

/**
 * Dashboard and widgets
 */

	'dashboard' => "ダッシュボード",//"Dashboard",
	'dashboard:configure' => "このページの編集",//"Edit page",
	'dashboard:nowidgets' => "ダッシュボードはこのサイトの入り口です。「このページの編集」をクリックするとウィジェットの追加、コンテンツの更新、あなたの公開情報の編集ができます。",//"Your dashboard is your gateway into the site. Click 'Edit page' to add widgets to keep track of content and your life within the system.",

	'widgets:add' => 'ウィジェットの追加',//'Add widgets to your page',
	'widgets:add:description' => "ページに追加したい機能を右の<b>ウィジェット一覧</b>から選んでください。 選んだ機能をウィジェット領域にドラッグして配置すると、その場所にウィジェットが表示されます。 ウィジェットを削除したい場合はドラッグして<b>ウィジェット一覧</b>に戻して下さい。",//"Choose the features you want to add to your page by dragging them from the <b>Widget gallery</b> on the right, to any of the three widget areas below, and position them where you would like them to appear.To remove a widget drag it back to the <b>Widget gallery</b>.",
	'widgets:position:fixed' => '（修正した位置）',//'(Fixed position on page)',

	'widgets' => "ウィジェット",//"Widgets",
	'widget' => "ウィジェット",//"Widget",
	'item:object:widget' => "ウィジェット",//"Widgets",
	'layout:customise' => "レイアウトのカスタマイズ",//"Customise layout",
	'widgets:gallery' => "ウィジェット一覧",//"Widget gallery",
	'widgets:leftcolumn' => "左のウィジェット",//"Left widgets",
	'widgets:fixed' => "修正した位置",//"Fixed position",
	'widgets:middlecolumn' => "中央のウィジェット",//"Middle widgets",
	'widgets:rightcolumn' => "右のウィジェット",//"Right widgets",
	'widgets:profilebox' => "プロフィール表示エリア",//"Profile box",
	'widgets:panel:save:success' => "ウィジェットを保存しました。",//"Your widgets were successfully saved.",
	'widgets:panel:save:failure' => "ウィジェットの保存に問題が発生しました。",//"There was a problem saving your widgets. Please try again.",
	'widgets:save:success' => "ウィジェットを保存しました。",//"The widget was successfully saved.",
	'widgets:save:failure' => "ウィジェットを保存できません。",//"We could not save your widget. Please try again.",
	'widgets:handlernotfound' => 'このウィジェットは壊れているか、管理者が利用禁止にしています。',//'This widget is either broken or has been disabled by the site administrator.',

/**
 * Groups
 */

	'group' => "グループ",//"Group",
	'item:group' => "グループ",//"Groups",

/**
 * Users
 */

	'user' => "ユーザー",//"User",
	'item:user' => "ユーザー",//"Users",

/**
 * Friends
 */

	'friends' => "友達",//"Friends",
	'friends:yours' => "あなたの友達",//"Your friends",
	'friends:owned' => "%s の友達",//"%s's friends",
	'friend:add' => "友達登録する",//"Add friend",
	'friend:remove' => "友達登録を解除する",//"Remove friend",

	'friends:add:successful' => "%s を友達登録しました。",//"You have successfully added %s as a friend.",
	'friends:add:failure' => "%s を友達登録できません。",//"We couldn't add %s as a friend. Please try again.",

	'friends:remove:successful' => "%s との友達登録を解除しました。",//"You have successfully removed %s from your friends.",
	'friends:remove:failure' => "%s との友達登録を解除できません。",//"We couldn't remove %s from your friends. Please try again.",

	'friends:none' => "このユーザーはまだ誰も友達登録していません。",//"This user hasn't added anyone as a friend yet.",
	'friends:none:you' => "あなたはまだ誰も友だち登録していません！ いろいろな人を探してみましょう。",//"You haven't added anyone as a friend! Search for your interests to begin finding people to follow.",

	'friends:none:found' => "友達が見つかりません。",//"No friends were found.",

	'friends:of:none' => "誰もこのユーザーを友達として登録していません。",//"Nobody has added this user as a friend yet.",
	'friends:of:none:you' => "誰もあなたを友達登録していません。ブログやWireを書いたり、プロフィールにあなたのことをいろいろ書いてみましょう。",//"Nobody has added you as a friend yet. Start adding content and fill in your profile to let people find you!",

	'friends:of:owned' => "%sを友達登録しているメンバー",//"People who have made %s a friend",

	'friends:num_display' => "一覧表示数",//"Number of friends to display",
	'friends:icon_size' => "アイコンのサイズ",//"Icon size",
	'friends:tiny' => "極小",//"tiny",
	'friends:small' => "小",//"small",
	'friends:of' => "このユーザーを友達登録しているメンバー",//"Friends of",
	'friends:collections' => "リスト",//"Collections of friends",
	'friends:collections:add' => "新規リストの作成",//"New friends collection",
	'friends:addfriends' => "友達の登録",//"Add friends",
	'friends:collectionname' => "リスト名",//"Collection name",
	'friends:collectionfriends' => "リストに登録された友達",//"Friends in collection",
	'friends:collectionedit' => "リストの編集",//"Edit this collection",
	'friends:nocollections' => "リストがありません。",//"You do not yet have any collections.",
	'friends:collectiondeleted' => "リストを削除しました。",//"Your collection has been deleted.",
	'friends:collectiondeletefailed' => "リストが削除できません。権限がないか、何らかの問題が発生しています。",//"We were unable to delete the collection. Either you don't have permission, or some other problem has occurred.",
	'friends:collectionadded' => "リストを作成しました。",//"Your collection was successfuly created",
	'friends:nocollectionname' => "リストの名前を入力してください。",//"You need to give your collection a name before it can be created.",
	'friends:collections:members' => "リストのメンバー",//"Collection members",
	'friends:collections:edit' => "リストの編集",//"Edit collection",

	'friends:river:created' => "%s は友達ウィジェットを追加しました。",//"%s added the friends widget.",
	'friends:river:updated' => "%s は友達ウィジェットを更新しました。",//"%s updated their friends widget.",
	'friends:river:delete' => "%s は友達ウィジェットを削除しました。",//"%s removed their friends widget.",
	'friends:river:add' => "%s は友達になりました。",//"%s is now a friend with",

	'friendspicker:chararray' => '',//'あかさたなはまやらわABCDEFGHIJKLMNOPQRSTUVWXYZ',

/**
 * Feeds
 */
	'feed:rss' => 'フィードを取得',//'Subscribe to feed',
	'feed:odd' => 'OpenDDを取得',//'Syndicate OpenDD',

/**
 * links
 **/

	'link:view' => 'リンク先をみる',//'view link',


/**
 * River
 */
	'river' => "River",
	'river:relationship:friend' => '友達登録しました。',//'is now friends with',
	'river:noaccess' => 'このアイテムを見る権限がありません。',//'You do not have permission to view this item.',
	'river:posted:generic' => '%s が投稿されました。',//'%s posted',
	'riveritem:single:user' => 'ユーザー',//'a user',
	'riveritem:plural:user' => 'ユーザー',//'some users',

/**
 * Plugins
 */
	'plugins:settings:save:ok' => "プラグイン %s の設定を保存しました。",//"Settings for the %s plugin were saved successfully.",
	'plugins:settings:save:fail' => "プラグイン %s の設定が保存できません。",//"There was a problem saving settings for the %s plugin.",
	'plugins:usersettings:save:ok' => "プラグイン %s のユーザー設定を保存しました。",//"User settings for the %s plugin were saved successfully.",
	'plugins:usersettings:save:fail' => "プラグイン %s のユーザー設定が保存できません。",//"There was a problem saving  user settings for the %s plugin.",
	'admin:plugins:label:version' => "バージョン",//"Version",
	'item:object:plugin' => 'プラグインの設定',//'Plugin configuration settings',

/**
 * Notifications
 */
	'notifications:usersettings' => "通知設定",//"Notification settings",
	'notifications:methods' => "通知の方法を選んで下さい。",//"Please specify which methods you want to permit.",

	'notifications:usersettings:save:ok' => "通知設定を保存しました。",//"Your notification settings were successfully saved.",
	'notifications:usersettings:save:fail' => "通知設定の保存に失敗しました。",//"There was a problem saving your notification settings.",

	'user.notification.get' => '特定のユーザーへの通知の設定を返します。',//'Return the notification settings for a given user.',
	'user.notification.set' => '特定のユーザーへの通知について設定してください。',//'Set the notification settings for a given user.',
/**
 * Search
 */

	'search' => "検索",// "Search",
	'searchtitle' => "検索: %s",//"Search: %s",
	'users:searchtitle' => "ユーザー検索: %s",//"Searching for users: %s",
	'groups:searchtitle' => "グループ検索",//"Searching for groups: %s",
	'advancedsearchtitle' => "%s と一致した結果は %s",//"%s with results matching %s",
	'notfound' => "検索結果なし",//"No results found.",
	'next' => "次へ",//"Next",
	'previous' => "前へ",//"Previous",

	'viewtype:change' => "表示の変更",//"Change listing type",
	'viewtype:list' => "一覧",//"List view",
	'viewtype:gallery' => "ギャラリ",//"Gallery",

	'tag:search:startblurb' => "タグに一致したのは '%s':",//"Items with tags matching '%s':",

	'user:search:startblurb' => "一致したユーザーは '%s':",//"Users matching '%s':",
	'user:search:finishblurb' => "もっとみる",//"To view more, click here.",

	'group:search:startblurb' => "一致したグループは '%s':",//"Groups matching '%s':",
	'group:search:finishblurb' => "もっとみる",//"To view more, click here.",
	'search:go' => 'Go',
	'userpicker:only_friends' => '友達のみ',//'Only friends',

/**
 * Account
 */

	'account' => "アカウント",//"Account",
	'settings' => "設定",//"Settings",
	'tools' => "ツール",//"Tools",
	'tools:yours' => "あなたのツール",//"Your tools",

	'register' => "新規登録",//"Register",
	'registerok' => "あなたは %s として登録されました。",//"You have successfully registered for %s.",
	'registerbad' => "登録ができません。そのユーザー名がすでに利用されているか、パスワードが一致しなかったか、ユーザー名とパスワードが短すぎた可能性があります。",//"Your registration was unsuccessful. The username may already exist, your passwords might not match, or your username or password may be too short.",
	'registerdisabled' => "システム管理者が新規登録を禁止しています。",//"Registration has been disabled by the system administrator",

	'firstadminlogininstructions' => 'これでelggのインストールは完了し、管理者アカウントも作成されました。いくつかのプラグインがインストールされているので、利用したいプラグインを有効にしてお試し下さい。',//'Your new Elgg site has been successfully installed and your administrator account created. You can now configure your site further by enabling various installed plugin tools.',

	'registration:notemail' => '無効なEメールアドレスが入力されたようです。',//'The email address you provided does not appear to be a valid email address.',
	'registration:userexists' => 'そのユーザ名はすでに使われています。',//'That username already exists',
	'registration:usernametooshort' => 'ユーザー名はアルファベットで4文字以上にしてください。',//'Your username must be a minimum of 4 characters long.',
	'registration:passwordtooshort' => 'パスワードはアルファベットで6文字以上にしてください。',//'The password must be a minimum of 6 characters long.',
	'registration:dupeemail' => 'そのEメールアドレスはすでに利用されています。',//'This email address has already been registered.',
	'registration:invalidchars' => '申し訳ありませんが、ユーザー名に利用できない文字が含まれています。',//'Sorry, your username contains invalid characters.',
	'registration:emailnotvalid' => '申し訳ありませんが、そのEメールアドレスは利用できません。',//'Sorry, the email address you entered is invalid on this system',
	'registration:passwordnotvalid' => '申し訳ありませんが、そのパスワードは利用できません。',//'Sorry, the password you entered is invalid on this system',
	'registration:usernamenotvalid' => '申し訳ありませんが、そのユーザー名は利用できません。',//'Sorry, the username you entered is invalid on this system',

	'adduser' => "ユーザー登録",//"Add User",
	'adduser:ok' => "新しいユーザーを登録しました。",//"You have successfully added a new user.",
	'adduser:bad' => "新しいユーザーが登録できません。",//"The new user could not be created.",

	'item:object:reported_content' => "報告されたアイテム",//"Reported items",

	'user:set:name' => "アカウント編集",//"Account name settings",
	'user:name:label' => "ハンドル名",//"Your name",
	'user:name:success' => "ハンドル名を変更しました。",//"Successfully changed your name on the system.",
	'user:name:fail' => "ハンドル名が変更できません。ハンドル名が長すぎた可能性があります。",//"Could not change your name on the system.  Please make sure your name isn't too long and try again.",

	'user:set:password' => "パスワード",//"Account password",
	'user:password:label' => "新しいパスワード",//"Your new password",
	'user:password2:label' => "新しいパスワード（確認）",//"Your new password again",
	'user:password:success' => "パスワードを変更しました。",//"Password changed",
	'user:password:fail' => "パスワードが変更できません。",//"Could not change your password on the system.",
	'user:password:fail:notsame' => "パスワードが一致しません。",//"The two passwords are not the same!",
	'user:password:fail:tooshort' => "パスワードが短いため登録できません。",//"Password is too short!",
	'user:resetpassword:unknown_user' => 'ユーザーが見当たりません。',//'Invalid user.',
	'user:resetpassword:reset_password_confirm' => '登録されたEメールアドレスに新しいパスワードを送信しました。',//'Resetting your password will email a new password to your registered email address.',

	'user:set:language' => "言語設定",// "Language settings",
	'user:language:label' => "利用する言語",//"Your language",
	'user:language:success' => "利用する言語設定を更新しました。",//"Your language settings have been updated.",
	'user:language:fail' => "言語設定が保存できません。",//"Your language settings could not be saved.",

	'user:username:notfound' => 'ユーザー名 %s が見当たりません。',//'Username %s not found.',

	'user:password:lost' => 'パスワードを忘れた場合',//'Lost password',
	'user:password:resetreq:success' => '新しいパスワード発行の手続きをスタートしました。ご登録のEメールあてに送信されました。',//'Successfully requested a new password, email sent',
	'user:password:resetreq:fail' => '新しいパスワード発行の手続きに失敗しました。',//'Could not request a new password.',

	'user:password:text' => '新しいパスワードを発行する場合は、下記にユーザー名を入力し送信してください。こちらよりEメールが届きます。その本文に本人確認用のリンクが書かれているのでそれをクリックして下さい。その後、パスワードが届きます。',//'To generate a new password, enter your username below. We will send the address of a unique verification page to you via email click on the link in the body of the message and a new password will be sent to you.',

	'user:persistent' => '次回入力を省略',//'Remember me',
/**
 * Administration
 */

	'admin:configuration:success' => "設定を保存しました。",//"Your settings have been saved.",
	'admin:configuration:fail' => "設定が保存できません。",//"Your settings could not be saved.",

	'admin' => "管理",//"Administration",
	'admin:description' => "この管理パネルでは、様々な機能についての設定・管理ができます。開始するには以下のオプションを選択してください。",//"The admin panel allows you to control all aspects of the system, from user management to how plugins behave. Choose an option below to get started.",

	'admin:user' => "ユーザー管理",//"User Administration",
	'admin:user:description' => "この管理パネルでは、サイト内のユーザー管理を行うことができます。",//"This admin panel allows you to control user settings for your site. Choose an option below to get started.",
	'admin:user:adduser:label' => "新しいユーザーを登録...",//"Click here to add a new user...",
	'admin:user:opt:linktext' => "ユーザーの設定...",//"Configure users...",
	'admin:user:opt:description' => "ユーザーとアカウント情報を設定",//"Configure users and account information. ",

	'admin:site' => "サイト管理",//"Site Administration",
	'admin:site:description' => "この管理パネルでは、インストールしたサイト全体に関わる設定を管理できます。",//"This admin panel allows you to control global settings for your site. Choose an option below to get started.",
	'admin:site:opt:linktext' => "サイトの設定..",//"Configure site...",
	'admin:site:opt:description' => "サイト全般の設定",//"Configure the site technical and non-technical settings. ",
	'admin:site:access:warning' => "公開範囲の設定です。これから作成するコンテンツにのみ適用されます。",//"Changing the access setting only affects the permissions on content created in the future.",

	'admin:plugins' => "ツール管理",//"Tool Administration",
	'admin:plugins:description' => "この管理パネルでは、インストールしたツールの有効・無効化やそれぞれの設定を行います。",//"This admin panel allows you to control and configure tools installed on your site.",
	'admin:plugins:opt:linktext' => "ツールの設定...",//"Configure tools...",
	'admin:plugins:opt:description' => "インストール済みツールの設定",//"Configure the tools installed on the site. ",
	'admin:plugins:label:author' => "開発者",//"Author",
	'admin:plugins:label:copyright' => "コピーライト",//"Copyright",
	'admin:plugins:label:licence' => "ライセンス",//"Licence",
	'admin:plugins:label:website' => "URL",//"URL",
	'admin:plugins:label:moreinfo' => 'もっとみる',//'more info',
	'admin:plugins:label:version' => "バージョン",//'Version',
	'admin:plugins:warning:elggversionunknown' => '警告：このプラグインはこのElggとの互換性の保証がありません。',//'Warning: This plugin does not specify a compatible Elgg version.',
	'admin:plugins:warning:elggtoolow' => '警告：このプラグインを利用するにはより最新のバージョンのElggが必要です。',//'Warning: This plugin requires a later version of Elgg!',
	'admin:plugins:reorder:yes' => "プラグイン %si並び替えました。",//"Plugin %s was reordered successfully.",
	'admin:plugins:reorder:no' => "プラグイン %s の並べ替えに失敗しました。",//"Plugin %s could not be reordered.",
	'admin:plugins:disable:yes' => "プラグイン %s を無効にしました。",//"Plugin %s was disabled successfully.",
	'admin:plugins:disable:no' => "プラグイン %s を無効にできませんでした。",//"Plugin %s could not be disabled.",
	'admin:plugins:enable:yes' => "プラグイン %s を有効にしました。",//"Plugin %s was enabled successfully.",
	'admin:plugins:enable:no' => "プラグイン %s を有効にできませんでした。",//"Plugin %s could not be enabled.",

	'admin:statistics' => "サイト統計情報",//"Statistics",
	'admin:statistics:description' => "これはあなたのサイトの統計情報です。専門の管理機能をご利用の場合はより詳細な統計情報利用できます。",//"This is an overview of statistics on your site. If you need more detailed statistics, a professional administration feature is available.",
	'admin:statistics:opt:description' => "サイト上のユーザとオブジェクトに関する統計情報を表示します。",//"View statistical information about users and objects on your site.",
	'admin:statistics:opt:linktext' => "統計情報をみる...",//"View statistics...",
	'admin:statistics:label:basic' => "サイト統計情報（概要）",//"Basic site statistics",
	'admin:statistics:label:numentities' => "サイト統計情報（数値）",//"Entities on site",
	'admin:statistics:label:numusers' => "ユーザー数",//"Number of users",
	'admin:statistics:label:numonline' => "ログイン中のユーザー数",//"Number of users online",
	'admin:statistics:label:onlineusers' => "ログイン中のユーザー",//"Users online now",
	'admin:statistics:label:version' => "Elgg バージョン",//"Elgg version",
	'admin:statistics:label:version:release' => "リリース",//"Release",
	'admin:statistics:label:version:version' => "バージョン",//"Version",

	'admin:user:label:search' => "ユーザー検索",//"Find users:",
	'admin:user:label:searchbutton' => "検索",//"Search",

	'admin:user:ban:no' => "ユーザーの投稿を禁止できません。",//"Can not ban user",
	'admin:user:ban:yes' => "ユーザーの投稿を禁止",//"User banned.",
	'admin:user:unban:no' => "ユーザーの投稿禁止を解除できません。",//"Can not unban user",
	'admin:user:unban:yes' => "ユーザーの投稿禁止を解除",//"User un-banned.",
	'admin:user:delete:no' => "ユーザーが削除できません。",//"Can not delete user",
	'admin:user:delete:yes' => "ユーザーの削除",//"User deleted",

	'admin:user:resetpassword:yes' => "パスワードをリセットすると、ユーザに通知します。",//"Password reset, user notified.",
	'admin:user:resetpassword:no' => "パスワードがリセットできません",//"Password could not be reset.",

	'admin:user:makeadmin:yes' => "このユーザーは管理者です。",//"User is now an admin.",
	'admin:user:makeadmin:no' => "このユーザーに管理者権限を与えることができません。",//"We could not make this user an admin.",

	'admin:user:removeadmin:yes' => "ユーザーはもう管理者ではありません。",//"User is no longer an admin.",
	'admin:user:removeadmin:no' => "このユーザーの管理者権限が解除できません。",//"We could not remove administrator privileges from this user.",

/**
 * User settings
 */
	'usersettings:description' => "ユーザー設定パネルでは、ユーザー管理からプラグイン管理といったすべての設定を行うことができます。以下のオプションを選択してください。",//"The user settings panel allows you to control all your personal settings, from user management to how plugins behave. Choose an option below to get started.",

	'usersettings:statistics' => "あなたの情報",//"Your statistics",
	'usersettings:statistics:opt:description' => "サイト上のユーザとオブジェクトに関する統計情報を表示します。",//"View statistical information about users and objects on your site.",
	'usersettings:statistics:opt:linktext' => "統計情報",//"Account statistics",

	'usersettings:user' => "あなたの設定",//"Your settings",
	'usersettings:user:opt:description' => "ユーザー設定の管理を行います。",//"This allows you to control user settings.",
	'usersettings:user:opt:linktext' => "設定の変更",//"Change your settings",

	'usersettings:plugins' => "ツール",//"Tools",
	'usersettings:plugins:opt:description' => "利用可能なツールの設定",//"Configure settings (if any) for your active tools.",
	'usersettings:plugins:opt:linktext' => "ツールの設定",//"Configure your tools",

	'usersettings:plugins:description' => "このパネルでは、利用可能なツールに関する設定ができます。",//"This panel allows you to control and configure the personal settings for the tools installed by your system administrator.",
	'usersettings:statistics:label:numentities' => "数値情報",//"Your content",

	'usersettings:statistics:yourdetails' => "詳細",//"Your details",
	'usersettings:statistics:label:name' => "氏名",//"Full name",
	'usersettings:statistics:label:email' => "Eメール",//"Email",
	'usersettings:statistics:label:membersince' => "利用開始時期",//"Member since",
	'usersettings:statistics:label:lastlogin' => "前回のログイン",//"Last logged in",



/**
 * Generic action words
 */

	'save' => "保存",//"Save",
	'publish' => "公開",//"Publish",
	'cancel' => "キャンセル",//"Cancel",
	'saving' => "保存中...",//"Saving ...",
	'update' => "更新",//"Update",
	'edit' => "編集",//"Edit",
	'delete' => "削除",//"Delete",
	'accept' => "承認する",//"Accept",
	'load' => "読込",//"Load",
	'upload' => "アップロード",//"Upload",
	'ban' => "投稿禁止",//"Ban",
	'unban' => "投稿禁止解除",//"Unban",
	'enable' => "有効にする",//"Enable",
	'disable' => "無効にする",//"Disable",
	'request' => "リクエスト",//"Request",
	'complete' => "完了",//"Complete",
	'open' => "開く",//'Open',
	'close' => '閉じる',//'Close',
	'reply' => "返信",//"Reply",
	'more' => 'もっとみる',//'More',
	'comments' => 'コメント',//'Comments',
	'import' => 'インポート',//'Import',
	'export' => 'エクスポート',//'Export',
	'untitled' => 'タイトルなし',//'Untitled',
	'help' => 'ヘルプ',//'Help',
	'send' => '送信',//'Send',
	'post' => '投稿',//'Post',
	'submit' => '送信',//'Submit',
	'site' => 'サイト',//'Site',

	'up' => '上へ',//'Up',
	'down' => '下へ',//'Down',
	'top' => '最初',//'Top',
	'bottom' => '最後',//'Bottom',

	'invite' => "招待する",//"Invite",

	'resetpassword' => "パスワードのリセット",//"Reset password",
	'makeadmin' => "管理者権限を与える",//"Make admin",
	'removeadmin' => "管理者権限を外す",//"Remove admin",

	'option:yes' => "はい",//"Yes",
	'option:no' => "いいえ",//"No",

	'unknown' => 'アンノウン',//'Unknown',

	'active' => 'アクティブ',//'Active',
	'total' => 'すべて',//'Total',

	'learnmore' => "詳細はこちら",//"Click here to learn more.",

	'content' => "コンテンツ",//"content",
	'content:latest' => '最近の操作',//'Latest activity',
	'content:latest:blurb' => 'サイト内の最新コンテンツを表示',//'Alternatively, click here to view the latest content from across the site.',

	'link:text' => 'リンク',//'view link',

	'enableall' => 'すべてを有効にする',//'Enable All',
	'disableall' => 'すべてを無効にする',//'Disable All',

/**
 * Generic questions
 */

	'question:areyousure' => 'よろしいですか？',//'Are you sure?',

/**
 * Generic data words
 */

	'title' => "タイトル",//"Title",
	'description' => "概要",//"Description",
	'tags' => "タグ",//"Tags",
	'spotlight' => "スポットライト",//"Spotlight",
	'all' => "全て",//"All",

	'by' => 'by',

	'annotations' => "注釈",//"Annotations",
	'relationships' => "関連",//"Relationships",
	'metadata' => "メタデータ",//"Metadata",

/**
 * Input / output strings
 */

	'deleteconfirm' => "このアイテムを削除してよいですか？",//"Are you sure you want to delete this item?",
	'fileexists' => "ファイルはすでにアップロードされています。置き換えるときは以下から選択してください。",//"A file has already been uploaded. To replace it, select it below:",

/**
 * User add
 */

	'useradd:subject' => 'ユーザーが作成されました。',//'User account created',
	'useradd:body' => '
%s さん,

%s にあなたのメールアドレスでユーザーアカウントが登録されました. こちらからご確認ください:

%s

ログインのためのユーザー名とパスワードは次の通りです。:

ユーザー名: %s
パスワード: %s

上記パスワードは暫定パスワードです。ログイン後に, 直ちにご自身でパスワードを変更することをおすすめします。

',
/*'
%s,

A user account has been created for you at %s. To log in, visit:

%s

And log in with these user credentials:

Username: %s
Password: %s

Once you have logged in, we highly recommend that you change your password.
',
*/

/**
 * System messages
 **/

	'systemmessages:dismiss' => "クリックすると消えます。",//"click to dismiss",


/**
 * Import / export
 */
	'importsuccess' => "データのインポートに成功しました。",//"Import of data was successful",
	'importfail' => "OpenDDデータ・インポート失敗",//"OpenDD import of data failed.",

/**
 * Time
 */

	'friendlytime:justnow' => "Now!",//"just now",
	'friendlytime:minutes' => "%s 分前",//"%s minutes ago",
	'friendlytime:minutes:singular' => "1分前",//"a minute ago",
	'friendlytime:hours' => "%s 時間前",//"%s hours ago",
	'friendlytime:hours:singular' => "1時間前",//"an hour ago",
	'friendlytime:days' => "%s 日前",//"%s days ago",
	'friendlytime:days:singular' => "機能",//"yesterday",
	'friendlytime:date_format' => 'Y年m月d日',//'j F Y @ g:ia',

	'date:month:01' => '1月 %s',//'January %s',
	'date:month:02' => '2月 %s',//'February %s',
	'date:month:03' => '3月 %s',//'March %s',
	'date:month:04' => '4月 %s',//'April %s',
	'date:month:05' => '5月 %s',//'May %s',
	'date:month:06' => '6月 %s',//'June %s',
	'date:month:07' => '7月 %s',//'July %s',
	'date:month:08' => '8月 %s',//'August %s',
	'date:month:09' => '9月 %s',//'September %s',
	'date:month:10' => '10月 %s',//'October %s',
	'date:month:11' => '11月 %s',//'November %s',
	'date:month:12' => '12月 %s',//'December %s',


/**
 * Installation and system settings
 */

	'installation:error:htaccess' => "Elggのインストールでは.htaccessファイルをElggのドキュメントルートに設置します。ですが、そのディレクトリにファイルを作成する権限がなく、.htaccessファイルを作成できません。テキストエディタで.htaccessファイルを作成し、下記のテキストボックス内のテキストをコピーして貼付けた後、保存したものをドキュメントルートの設置してください。、",//"Elgg requires a file called .htaccess to be set in the root directory of its installation. We tried to create it for you, but Elgg doesn't have permission to write to that directory. Creating this is easy. Copy the contents of the textbox below into a text editor and save it as .htaccess",

	'installation:error:settings' => "設定ファイルが見つかりません。Elggの設定はほぼアプリケーションが行いますが、データベースの情報はあなたが正しく把握し修正する必要があります。そのために以下のことをお願いします。

1. engine/settings.example.phpファイルをengine/settings.phpにコピー（または移動）します。

2. settings.phpをテキストエディタで開きます。MySQLデータベースの接続情報を編集します。よくわからない場合はシステム管理者に質問するか、テクニカルサポートに問い合わせてください。
",

/* "Elgg couldn't find its settings file. Most of Elgg's settings will be handled for you, but we need you to supply your database details. To do this:

1. Rename engine/settings.example.php to settings.php in your Elgg installation.

2. Open it with a text editor and enter your MySQL database details. If you don't know these, ask your system administrator or technical support for help.

Alternatively, you can enter your database settings below and we will try and do this for you...",
*/

	'installation:error:configuration' => "すべての設定の問題を修正した後、リロードして再度実施してみてください。",//"Once you've corrected any configuration issues, press reload to try again.",

	'installation' => "インストール",//"Installation",
	'installation:success' => "Elggデータベースをインストールしました。",//"Elgg's database was installed successfully.",
	'installation:configuration:success' => "最初の設定が保存されました。これで、最初のユーザ登録を登録して下さい。このユーザーは管理者権限を持ち、すべての設定を編集可能です。",//"Your initial configuration settings have been saved. Now register your initial user; this will be your first system administrator.",

	'installation:settings' => "システム設定",//"System settings",
	'installation:settings:description' => "これでElggのデータベースが構築されました。あとはあなたのサイトを完全に稼動させるために、いくつかの情報を入力する必要があります。",//"Now that the Elgg database has been successfully installed, you need to enter a couple of pieces of information to get your site fully up and running. We've tried to guess where we could, but <b>you should check these details.</b>",

	'installation:settings:dbwizard:prompt' => "データベース設定を入力し保存して下さい。",//"Enter your database settings below and hit save:",
	'installation:settings:dbwizard:label:user' => "データベースユーザー",//"Database user",
	'installation:settings:dbwizard:label:pass' => "パスワード",//"Database password",
	'installation:settings:dbwizard:label:dbname' => "利用するデータベース名",//"Elgg database",
	'installation:settings:dbwizard:label:host' => "接続先データベースホスト",//"Database hostname (usually 'localhost')",
	'installation:settings:dbwizard:label:prefix' => "データベーステーブルの接頭語",//"Database table prefix (usually 'elgg_')",

	'installation:settings:dbwizard:savefail' => "settings.php を保存することができませんでした。テキストエディターを利用して、以下の内容を engine/settings.php として直接編集し保存してください。",//"We were unable to save the new settings.php. Please save the following file as engine/settings.php using a text editor.",

	'installation:sitename' => "サイト名 (例えば \"私のソーシャル・ネットワーク・サイト\")",//"The name of your site (eg \"My social networking site\"):",
	'installation:sitedescription' => "サイト概要 (必須入力項目ではありません)",//"Short description of your site (optional)",
	'installation:wwwroot' => "サイトのURL（末尾にスラッシュが続く）",//"The site URL, followed by a trailing slash:",
	'installation:path' => "サイトルートのフルパス（末尾にスラッシュが続く）",//"The full path to your site root on your disk, followed by a trailing slash:",
	'installation:dataroot' => "アップロードしたファイルを保存するディレクトリのフルパス（末尾にスラッシュが続く）",//"The full path to the directory where uploaded files will be stored, followed by a trailing slash:",
	'installation:dataroot:warning' => "手動でディレクトリを作成する必要があります。 あなたがElggをインストールしたディレクトリとは別の位置に作成することをお勧めします。",//"You must create this directory manually. It should sit in a different directory to your Elgg installation.",
	'installation:sitepermissions' => "デフォルトの公開範囲",//"The default access permissions:",
	'installation:language' => "デフォルトの言語",//"The default language for your site:",
	'installation:debug' => "デバッグモードは、障害の診断に用いることができる、より多くの情報をもたらします。 しかしながらそれは、システムの停止が遅くなるので、問題が発生したときのみ利用するべきです。",//"Debug mode provides extra information which can be used to diagnose faults. However, it can slow your system down so should only be used if you are having problems:",
	'installation:debug:none' => 'デバッグモードをオフ（推奨）',//'Turn off debug mode (recommended)',
	'installation:debug:error' => '重大なエラーのみ表示',//'Display only critical errors',
	'installation:debug:warning' => 'エラーと警告を表示',//'Display errors and warnings',
	'installation:debug:notice' => 'すべてのエラー、警告、出力をログに記録',//'Log all errors, warnings and notices',
	'installation:httpslogin' => "チェックするとログインが強制的にhttpsを適用します。前提としてWebサーバーがhttpsを利用できることも必要です。",//"Enable this to have user logins performed over HTTPS. You will need to have https enabled on your server for this to work.",
	'installation:httpslogin:label' => "HTTPSログインを有効にする",//"Enable HTTPS logins",
	'installation:view' => "サイトテーマの選択",//"Enter the view which will be used as the default for your site or leave this blank for the default view (if in doubt, leave as default):",

	'installation:siteemail' => "サイト管理者Eメールアドレス（システムからのEメール配信を行う際に利用する送信元アドレスとなります）",//"Site email address (used when sending system emails)",

	'installation:disableapi' => "RESTful APIは外部アプリケーションがElggの機能と連携する際に利用できる柔軟で拡張性のあるAPIです。",//"The RESTful API is a flexible and extensible interface that enables applications to use certain Elgg features remotely.",
	'installation:disableapi:label' => "RESTful API　を有効にする。",//"Enable the RESTful API",

	'installation:allow_user_default_access:description' => "チェックすると、それぞれのユーザーが自分のコンテンツに対して公開範囲を設定できるようになります。",//"If checked, individual users will be allowed to set their own default access level that can over-ride the system default access level.",
	'installation:allow_user_default_access:label' => "ユーザーに公開範囲の設定を許可",//"Allow user default access",

	'installation:simplecache:description' => "シンプル キャッシュはCSSやJavaScriptを含めた静的コンテンツファイルをキャッシュすることによってパフォーマンスを向上させます。通常はチェックしておきましょう。",//"The simple cache increases performance by caching static content including some CSS and JavaScript files. Normally you will want this on.",
	'installation:simplecache:label' => "シンプルキャッシュを使う（推奨）",//"Use simple cache (recommended)",

	'installation:viewpathcache:description' => "ビュー・ファイルパス キャッシュはそれぞれのビューの
パスをキャッシュすることにより、プラグインの読込時間を減らします。",//"The view filepath cache decreases the loading times of plugins by caching the location of their views.",
	'installation:viewpathcache:label' => "ビュー・ファイルパス キャッシュ（推奨）",//"Use view filepath cache (recommended)",

	'upgrading' => 'アップグレード中',//'Upgrading...',
	'upgrade:db' => 'データベースをアップグレードしました。',//'Your database was upgraded.',
	'upgrade:core' => 'elggをアップグレードしました。',//'Your elgg installation was upgraded.',

/**
 * Welcome
 */

	'welcome' => "ようこそ",//"Welcome",
	'welcome:user' => 'ようこそ、%s',//'Welcome %s',
	'welcome_message' => "Elggのインストール、ありがとうございます",//"Welcome to this Elgg installation.",

/**
 * Emails
 */
	'email:settings' => "Eメール設定",//"Email settings",
	'email:address:label' => "あなたのEメールアドレス",//"Your email address",

	'email:save:success' => "新しいメールアドレスを保存しました。承認作業に進みます。",//"New email address saved, verification requested.",
	'email:save:fail' => "新しいEメールアドレスが保存できません。",//"Your new email address could not be saved.",

	'friend:newfriend:subject' => "%s はあなたを友達に登録しました！",//"%s has made you a friend!",
	'friend:newfriend:body' => "%s はあなたを友達として登録しました！

プロファイルは下記URLで確認できます。

%s

(※) このメールには返信しないでください。

",
/*
"%s has made you a friend!

To view their profile, click here:

%s

You cannot reply to this email.",
*/


	'email:resetpassword:subject' => "パスワードをリセットしました",//"Password reset!",
	'email:resetpassword:body' => "%s さん, こんにちは。

あなたのパスワードは再設定されました: %s
",
/*
"Hi %s,

Your password has been reset to: %s",

*/
	'email:resetreq:subject' => "新しいパスワードのリクエスト",//"Request for new password.",
	'email:resetreq:body' => "%s さん、こんにちは,

どなたか (from the IP address %s) があなたのアカウントの新しいパスワードの発行を求めています。

あなた自身がパスワードの再設定をリクエストしたのなら下記リンクをクリックすればパスワードを再設定できます
。そのようなリクエストをしていない場合は、要求したアカウント名を間違えたのかもしれません。このメールを無
視してください。

%s
",
/*
"Hi %s,

Somebody (from the IP address %s) has requested a new password for their account.

If you requested this click on the link below, otherwise ignore this email.

%s
",
*/
/**
 * user default access
 */

'default_access:settings' => "あなたのデフォルトの公開範囲",//"Your default access level",
'default_access:label' => "デフォルトの公開範囲",//"Default access",
'user:default_access:success' => "新しい公開範囲の設定を保存しました。",//"Your new default access level was saved.",
'user:default_access:failure' => "新しい公開範囲の設定が保存できません。",//"Your new default access level could not be saved.",

/**
 * XML-RPC
 */
	'xmlrpc:noinputdata'	=>	"入力データがありません",//"Input data missing",

/**
 * Comments
 */

	'comments:count' => "%s コメント",//"%s comments",

	'riveraction:annotation:generic_comment' => '%s が %s にコメントしました。',//'%s commented on %s',

	'generic_comments:add' => "コメントする",//"Add a comment",
	'generic_comments:text' => "コメント",//"Comment",
	'generic_comment:posted' => "コメントを投稿しました。",//"Your comment was successfully posted.",
	'generic_comment:deleted' => "コメントを削除しました。",//"Your comment was successfully deleted.",
	'generic_comment:blank' => "申し訳ありません。コメント内容が未入力のため送信できません。",//"Sorry, you need to actually put something in your comment before we can save it.",
	'generic_comment:notfound' => "申し訳ありません。アイテムが見つかりません。",//"Sorry, we could not find the specified item.",
	'generic_comment:notdeleted' => "申し訳ありません。このコメントが削除できません。",//"Sorry, we could not delete this comment.",
	'generic_comment:failure' => "コメントした際、予期せぬエラーが発生しました。",//"An unexpected error occurred when adding your comment. Please try again.",

	'generic_comment:email:subject' => '新しいコメントがあります！',//'You have a new comment!',
	'generic_comment:email:body' => "あなたの投稿 \"%s\" に、 %s さんから新しくコメントが書き込まれ>ました。:

%s

このコメントをWebで見るか、返信する場合は下記をクリックしてください: 

%s

%s のプロフィールを見る場合は下記をクリックしてください: 

%s

(※) このメールには返信しないでください。

",
/*
"You have a new comment on your item \"%s\" from %s. It reads:


%s


To reply or view the original item, click here:

%s

To view %s's profile, click here:

%s

You cannot reply to this email.",
*/
/**
 * Entities
 */
	'entity:default:strapline' => '作成 %s by %s',//'Created %s by %s',
	'entity:default:missingsupport:popup' => 'この情報を正確に表示できません。利用していたプラグインがうまく動作していないか、アンインストールされた可能性があります。',//'This entity cannot be displayed correctly. This may be because it requires support provided by a plugin that is no longer installed.',

	'entity:delete:success' => 'エンティティ %s を削除しました。',//'Entity %s has been deleted',
	'entity:delete:fail' => 'エンティティ %s が削除できません。',//'Entity %s could not be deleted',


/**
 * Action gatekeeper
 */
	'actiongatekeeper:missingfields' => 'Form is missing __token or __ts fields',
	'actiongatekeeper:tokeninvalid' => "We encountered an error (token mismatch). This probably means that the page you were using expired. Please try again.",
	'actiongatekeeper:timeerror' => 'ご覧のページは閲覧期限が切れています。再度ページを読み込んでください。',//'The page you were using has expired. Please refresh and try again.',
	'actiongatekeeper:pluginprevents' => 'A extension has prevented this form from being submitted.',

/**
 * Word blacklists
 */
	'word:blacklist' => 'and, the, then, but, she, his, her, him, one, not, also, about, now, hence, however, still, likewise, otherwise, therefore, conversely, rather, consequently, furthermore, nevertheless, instead, meanwhile, accordingly, this, seems, what, whom, whose, whoever, whomever',

/**
 * Tag labels
 */

	'tag_names:tags' => 'タグ',

/**
 * Languages according to ISO 639-1
 */
	"aa" => "Afar",
	"ab" => "Abkhazian",
	"af" => "Afrikaans",
	"am" => "Amharic",
	"ar" => "Arabic",
	"as" => "Assamese",
	"ay" => "Aymara",
	"az" => "Azerbaijani",
	"ba" => "Bashkir",
	"be" => "Byelorussian",
	"bg" => "Bulgarian",
	"bh" => "Bihari",
	"bi" => "Bislama",
	"bn" => "Bengali; Bangla",
	"bo" => "Tibetan",
	"br" => "Breton",
	"ca" => "Catalan",
	"co" => "Corsican",
	"cs" => "Czech",
	"cy" => "Welsh",
	"da" => "Danish",
	"de" => "German",
	"dz" => "Bhutani",
	"el" => "Greek",
	"en" => "English",
	"eo" => "Esperanto",
	"es" => "Spanish",
	"et" => "Estonian",
	"eu" => "Basque",
	"fa" => "Persian",
	"fi" => "Finnish",
	"fj" => "Fiji",
	"fo" => "Faeroese",
	"fr" => "French",
	"fy" => "Frisian",
	"ga" => "Irish",
	"gd" => "Scots / Gaelic",
	"gl" => "Galician",
	"gn" => "Guarani",
	"gu" => "Gujarati",
	"he" => "Hebrew",
	"ha" => "Hausa",
	"hi" => "Hindi",
	"hr" => "Croatian",
	"hu" => "Hungarian",
	"hy" => "Armenian",
	"ia" => "Interlingua",
	"id" => "Indonesian",
	"ie" => "Interlingue",
	"ik" => "Inupiak",
	//"in" => "Indonesian",
	"is" => "Icelandic",
	"it" => "Italian",
	"iu" => "Inuktitut",
	"iw" => "Hebrew (obsolete)",
	"ja" => "日本語",//"Japanese",
	"ji" => "Yiddish (obsolete)",
	"jw" => "Javanese",
	"ka" => "Georgian",
	"kk" => "Kazakh",
	"kl" => "Greenlandic",
	"km" => "Cambodian",
	"kn" => "Kannada",
	"ko" => "Korean",
	"ks" => "Kashmiri",
	"ku" => "Kurdish",
	"ky" => "Kirghiz",
	"la" => "Latin",
	"ln" => "Lingala",
	"lo" => "Laothian",
	"lt" => "Lithuanian",
	"lv" => "Latvian/Lettish",
	"mg" => "Malagasy",
	"mi" => "Maori",
	"mk" => "Macedonian",
	"ml" => "Malayalam",
	"mn" => "Mongolian",
	"mo" => "Moldavian",
	"mr" => "Marathi",
	"ms" => "Malay",
	"mt" => "Maltese",
	"my" => "Burmese",
	"na" => "Nauru",
	"ne" => "Nepali",
	"nl" => "Dutch",
	"no" => "Norwegian",
	"oc" => "Occitan",
	"om" => "(Afan) Oromo",
	"or" => "Oriya",
	"pa" => "Punjabi",
	"pl" => "Polish",
	"ps" => "Pashto / Pushto",
	"pt" => "Portuguese",
	"qu" => "Quechua",
	"rm" => "Rhaeto-Romance",
	"rn" => "Kirundi",
	"ro" => "Romanian",
	"ru" => "Russian",
	"rw" => "Kinyarwanda",
	"sa" => "Sanskrit",
	"sd" => "Sindhi",
	"sg" => "Sangro",
	"sh" => "Serbo-Croatian",
	"si" => "Singhalese",
	"sk" => "Slovak",
	"sl" => "Slovenian",
	"sm" => "Samoan",
	"sn" => "Shona",
	"so" => "Somali",
	"sq" => "Albanian",
	"sr" => "Serbian",
	"ss" => "Siswati",
	"st" => "Sesotho",
	"su" => "Sundanese",
	"sv" => "Swedish",
	"sw" => "Swahili",
	"ta" => "Tamil",
	"te" => "Tegulu",
	"tg" => "Tajik",
	"th" => "Thai",
	"ti" => "Tigrinya",
	"tk" => "Turkmen",
	"tl" => "Tagalog",
	"tn" => "Setswana",
	"to" => "Tonga",
	"tr" => "Turkish",
	"ts" => "Tsonga",
	"tt" => "Tatar",
	"tw" => "Twi",
	"ug" => "Uigur",
	"uk" => "Ukrainian",
	"ur" => "Urdu",
	"uz" => "Uzbek",
	"vi" => "Vietnamese",
	"vo" => "Volapuk",
	"wo" => "Wolof",
	"xh" => "Xhosa",
	//"y" => "Yiddish",
	"yi" => "Yiddish",
	"yo" => "Yoruba",
	"za" => "Zuang",
	"zh" => "Chinese",
	"zu" => "Zulu",
);

add_translation("ja",$japanese);

?>
