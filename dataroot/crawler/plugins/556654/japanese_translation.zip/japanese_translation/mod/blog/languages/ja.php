<?php

	$japanese = array(
	
		/**
		 * Menu items and titles
		 */
	
			'blog' => "ブログ",//"Blog",
			'blogs' => "ブログ",//"Blogs",
			'blog:user' => "%s のブログ",//"%s's blog",
			'blog:user:friends' => "%s' の友達のブログ",//"%s's friends' blog",
			'blog:your' => "あなたのブログ",//"Your blog",
			'blog:posttitle' => "%s のブログ： %s",//"%s's blog: %s",
			'blog:friends' => "友達のブログ",//"Friends' blogs",
			'blog:yourfriends' => "友達の最新ブログ",//"Your friends' latest blogs",
			'blog:everyone' => "サイト内の全ブログ",//"All site blogs",
			'blog:newpost' => "新着ブログ記事",//"New blog post",
			'blog:via' => "via ブログ",//"via blog",
			'blog:read' => "ブログを読む",//"Read blog",
	
			'blog:addpost' => "新規ブログ記事作成",//"Write a blog post",
			'blog:editpost' => "この記事を編集する",//"Edit blog post",
	
			'blog:text' => "本文",//"Blog text",
	
			'blog:strapline' => "%s",//"%s",
			
			'item:object:blog' => 'ブログ記事',//'Blog posts',
	
			'blog:never' => 'never',//'never',
			'blog:preview' => 'プレビュー',//'Preview',
	
			'blog:draft:save' => '下書き保存',//'Save draft',
			'blog:draft:saved' => '最後に保存した下書き',//'Draft last saved',
			'blog:comments:allow' => 'コメントを許可する',//'Allow comments',
	
			'blog:preview:description' => 'この記事はプレビューでまだ保存していません。',//'This is an unsaved preview of your blog post.',
			'blog:preview:description:link' => 'このまま編集するか、記事を保存する場合はここをクリックしてください。',//'To continue editing or save your post, click here.',
	
			'blog:enableblog' => 'グループブログの利用',//'Enable group blog',
	
			'blog:group' => 'グループブログ',//'Group blog',
			
         /**
	     * Blog river
	     **/
	        
	        //generic terms to use
	        'blog:river:created' => "%s が作成",//"%s wrote",
	        'blog:river:updated' => "%s が更新",//"%s updated",
	        'blog:river:posted' => "%s が投稿",//"%s posted",
	        
	        //these get inserted into the river links to take the user to the entity
	        'blog:river:create' => "新しいブログ記事が投稿されました。",//"a new blog post titled",
	        'blog:river:update' => "ブログ記事が更新されました。",//"a blog post titled",
	        'blog:river:annotate' => "ブログ記事にコメントが付きました。",//"a comment on this blog post",
			
	
		/**
		 * Status messages
		 */
	
			'blog:posted' => "記事を投稿しました。",//"Your blog post was successfully posted.",
			'blog:deleted' => "記事を削除しました。",//"Your blog post was successfully deleted.",
	
		/**
		 * Error messages
		 */
	
			'blog:error' => '問題が発生しました。',//'Something went wrong. Please try again.',
			'blog:save:failure' => "記事が保存できません。",//"Your blog post could not be saved. Please try again.",
			'blog:blank' => "申し訳ありません。タイトルと本文が空欄>のため投稿できません。",//"Sorry; you need to fill in both the title and body before you can make a post.",
			'blog:notfound' => "申し訳ありません。該当する記事が見つかりません。",//"Sorry; we could not find the specified blog post.",
			'blog:notdeleted' => "申し訳ありません。ブログ記事が削除
できません。",//"Sorry; we could not delete this blog post.",
	
	);
					
	add_translation("ja",$japanese);

?>
