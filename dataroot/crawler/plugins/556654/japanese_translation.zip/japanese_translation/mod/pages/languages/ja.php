<?php
	/**
	 * Elgg pages plugin language pack
	 * 
	 * @package ElggPages
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2010
	 * @link http://elgg.com/
	 */

	$japanese = array(
	
		/**
		 * Menu items and titles
		 */
			
			'pages' => "ページ",//"Pages",
			'pages:yours' => "あなたのページ",//"Your pages",
			'pages:user' => "ページホーム",//"Pages home",
			'pages:group' => "グループページ",//"Group pages",
			'pages:all' => "サイトすべてのページ",//"All site pages",
			'pages:new' => "新しいページ",//"New page",
			'pages:groupprofile' => "グループページ",//"Group pages",
			'pages:edit' => "このページの編集",//"Edit this page",
			'pages:delete' => "このページを削除",//"Delete this page",
			'pages:history' => "履歴",//"Page history",
			'pages:view' => "ページをみる",//"View page",
			'pages:welcome' => "ウェルカムメッセージの編集",//"Edit welcome message",
			'pages:welcomemessage' => "Elggページプラグインにようこそ！ ページプラグインはいろいろなセクションにWebページを作ることを可能にします。権限設定により、閲覧できる人や編集できる人を設定できます。",//"Welcome to this Elgg pages plugin. This feature allows you to create pages on any topic and select who can view them and edit them.",
			'pages:welcomeerror' => "ウェルカムメッセージを保存する際に問題が発生しました。",//"There was a problem saving your welcome message",
			'pages:welcomeposted' => "ウェルカムメッセージを保存しました。",//"Your welcome message has been posted",
			'pages:navigation' => "ページ送り",//"Page navigation",
	        'pages:via' => "via pages",
			'item:object:page_top' => 'トップレベルページ',//'Top-level pages',
			'item:object:page' => 'ページ',//'Pages',
			'item:object:pages_welcome' => 'ウェルカムブロック',//'Pages welcome blocks',
			'pages:nogroup' => 'このグループにはページがまだありません。',//'This group does not have any pages yet',
			'pages:more' => 'もっとみる',//'More pages',
			
		/**
		* River
		**/
		
		    'pages:river:annotate' => "このページへのコメント",//"a comment on this page",
		    'pages:river:created' => "%s が作成",//"%s wrote",
	        'pages:river:updated' => "%s が更新",//"%s updated",
	        'pages:river:posted' => "%s が投稿",//"%s posted",
			'pages:river:create' => "新しいページが作成されました。",//"a new page titled",
	        'pages:river:update' => "ページが更新されました。",//"a page titled",
	        'page:river:annotate' => "このページへのコメント",//"a comment on this page",
	        'page_top:river:annotate' => "このページへのコメント",//"a comment on this page",
	
		/**
		 * Form fields
		 */
	
			'pages:title' => 'タイトル',//'Pages Title',
			'pages:description' => '本文',//'Your page entry',
			'pages:tags' => 'タグ',//'Tags',	
			'pages:access_id' => '公開範囲',//'Access',
			'pages:write_access_id' => '編集可能な範囲',//'Write access',
		
		/**
		 * Status and error messages
		 */
			'pages:noaccess' => 'ページを閲覧できません。',//'No access to page',
			'pages:cantedit' => 'このページの編集はできません。',//'You can not edit this page',
			'pages:saved' => 'ページを保存しました。',//'Pages saved',
			'pages:notsaved' => 'ページを保存できません。',//'Page could not be saved',
			'pages:notitle' => 'タイトルを入力して下さい。',//'You must specify a title for your page.',
			'pages:delete:success' => 'ページを削除しました。',//'Your page was successfully deleted.',
			'pages:delete:failure' => 'ページが削除できません。',//'The page could not be deleted.',
	
		/**
		 * Page
		 */
			'pages:strapline' => '最終更新： %s （更新者 %s ）',//'Last updated %s by %s',
	
		/**
		 * History
		 */
			'pages:revision' => 'リビジョン作成： %s （作成者 %s ）',//'Revision created %s by %s',
			
		/**
		 * Widget
		 **/
		 
		    'pages:num' => '一覧表示数',//'Number of pages to display',
			'pages:widget:description' => "ページのリストです。",//"This is a list of your pages.",
	
		/**
		 * Submenu items
		 */
			'pages:label:view' => "ページをみる",//"View page",
			'pages:label:edit' => "ページの編集",//"Edit page",
			'pages:label:history' => "履歴",//"Page history",
	
		/**
		 * Sidebar items
		 */
			'pages:sidebar:this' => "このページ",//"This page",
			'pages:sidebar:children' => "子ページ",//"Sub-pages",
			'pages:sidebar:parent' => "親ページ",//"Parent",
	
			'pages:newchild' => "子ページを作成",//"Create a sub-page",
			'pages:backtoparent' => "「 %s 」にもどる",//"Back to '%s'",
	);
					
	add_translation("ja",$japanese);
?>
