<?php

$japanese = array(
	'search:enter_term' => '検索キーワードを入力して下さい。',//'Enter a search term:',
	'search:no_results' => '検索結果なし',//'No results.',
	'search:matched' => '一致：',//'Matched: ',
	'search:results' => '%s の検索結果',//'Results for %s',
	'search:no_query' => '検索問い合わせを入力して下さい。',//'Please enter a query to search.',
	'search:search_error' => 'エラー',//'Error',

	'search:more' => '+%s more %s',//'+%s more %s',

	'search_types:tags' => 'タグ',//'Tags',

	'search_types:comments' => 'コメント',//'Comments',
	'search:comment_on' => '%s へのコメント',//'Comment on "%s"',
	'search:unavailable_entity' => '利用不可なエンティティ',//'Unavailable Entity',
);

add_translation('ja', $japanese);
?>
