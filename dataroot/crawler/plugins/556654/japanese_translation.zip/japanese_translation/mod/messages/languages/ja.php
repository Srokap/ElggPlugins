<?php

	$japanese = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messages' => "メッセージ",//"Messages",
            'messages:back' => "メッセージにもどる",//"back to messages",
			'messages:user' => "受信箱",//"Your inbox",
			'messages:sentMessages' => "送信済み",//"Sent messages",
			'messages:posttitle' => "%s のメッセージ: %s",//"%s's messages: %s",
			'messages:inbox' => "受信箱",//"Inbox",
			'messages:send' => "メッセージの送信",//"Send a message",
			'messages:sent' => "送信済みメッセージ",//"Sent messages",
			'messages:message' => "メッセージ",//"Message",
			'messages:title' => "タイトル",//"Title",
			'messages:to' => "宛先",//"To",
            'messages:from' => "送信元",//"From",
			'messages:fly' => "送信",//"Send",
			'messages:replying' => "返信先",//"Message replying to",
			'messages:inbox' => "受信箱",//"Inbox",
			'messages:sendmessage' => "メッセージの送信",//"Send a message",
			'messages:compose' => "新規メッセージの作成",//"Compose a message",
			'messages:sentmessages' => "送信済みメッセージ",//"Sent messages",
			'messages:recent' => "最近のメッセージ",//"Recent messages",
            'messages:original' => "オリジナルメッセージ",//"Original message",
            'messages:yours' => "あなたのメッセージ",//"Your message",
            'messages:answer' => "返信",//"Reply",
			'messages:toggle' => '全てを選択',//'Toggle all',
			'messages:markread' => '既読マーク',//'Mark read',
			
			'messages:new' => '新しいメッセージ',//'New message',
	
			'notification:method:site' => 'サイト',//'Site',
	
			'messages:error' => 'メッセージの保存の際に問題が発生しました。',//'There was a problem saving your message. Please try again.',
	
			'item:object:messages' => 'メッセージ',//'Messages',
	
		/**
		 * Status messages
		 */
	
			'messages:posted' => "メッセージを送信しました。",//"Your message was successfully sent.",
			'messages:deleted' => "メッセージを削除しました。",//"Your messages were successfully deleted.",
			'messages:markedread' => "既読マークを付与しました。",//"Your messages were successfully marked as read.",
	
		/**
		 * Email messages
		 */
	
			'messages:email:subject' => '新しいメッセージが届きました！',//'You have a new message!',
			'messages:email:body' => "%s から新しいメッセージが届きました。

%s

メッセージをみるには下記をクリックして下さい。

        %s

%s に返信するには下記をクリックして下さい。

        %s

(※) このメールに返信しないでください。
",
/*
"You have a new message from %s. It reads:

			
%s


To view your messages, click here:

	%s

To send %s a message, click here:

	%s

You cannot reply to this email.",
*/	
		/**
		 * Error messages
		 */
	
			'messages:blank' => "申し訳ありません。何も入力がないため、送信できません。",//"Sorry; you need to actually put something in the message body before we can save it.",
			'messages:notfound' => "申し訳ありません。メッセージが見当たらいません。",//"Sorry; we could not find the specified message.",
			'messages:notdeleted' => "申し訳ありません。メッセージが削除できません。",//"Sorry; we could not delete this message.",
			'messages:nopermission' => "メッセージを変更する権限がありません。",//"You do not have permission to alter that message.",
			'messages:nomessages' => "メッセージがありません。",//"There are no messages to display.",
			'messages:user:nonexist' => "ユーザー一覧にその送信先がありません。",//"We could not find the recipient in the user database.",
			'messages:user:blank' => "送信先を指定してください。",//"You did not select someone to send this to.",
	
	);
					
	add_translation("ja",$japanese);

?>
