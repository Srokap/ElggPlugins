<?php
	/**
	 * Elgg log rotator language pack.
	 * 
	 * @package ElggLogRotate
	 * @author Curverider Ltd
	 * @link http://elgg.com/
	 */

	$japanese = array(
		'logrotate:period' => 'システムログを保管する周期',//'How often should the system log be archived?',
	
		'logrotate:weekly' => '１週間に１回',//'Once a week',
		'logrotate:monthly' => '１ヶ月に１回',//'Once a month',
		'logrotate:yearly' => '１年に１回',//'Once a year',
	
		'logrotate:logrotated' => 'ログを保管しました\n',//"Log rotated\n",
		'logrotate:lognotrotated' => "ログ保管の失敗\n",//"Error rotating log\n",
	);
					
	add_translation("ja",$japanese);
?>
