<?php
	/**
	 * Elgg groups plugin language pack
	 *
	 * @package ElggGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2010
	 * @link http://elgg.com/
	 */

	$japanese = array(

		/**
		 * Menu items and titles
		 */

			'groups' => "グループ",//"Groups",
			'groups:owned' => "あなたがリーダーのグループ",//"Groups you own",
			'groups:yours' => "あなたが所属するグループ",//"Your groups",
			'groups:user' => "%s の所属するグループ",//"%s's groups",
			'groups:all' => "すべてのグループ",//"All site groups",
			'groups:new' => "新規グループの作成",//"Create a new group",
			'groups:edit' => "グループの編集",//"Edit group",
			'groups:delete' => 'グループの削除',//'Delete group',
			'groups:membershiprequests' => '参加リクエストの管理',//'Manage join requests',
			'groups:invitations' => 'グループへの招待',//'Group invitations',

			'groups:icon' => 'グループアイコン',//'Group icon (leave blank to leave unchanged)',
			'groups:name' => 'グループ名',//'Group name',
			'groups:username' => 'URL用英数記名',//'Group short name (displayed in URLs, alphanumeric characters only)',
			'groups:description' => '説明',//'Description',
			'groups:briefdescription' => '短い説明（一覧表示用）',//'Brief description',
			'groups:interests' => 'タグ',//'Tags',
			'groups:website' => 'Web',//'Website',
			'groups:members' => 'グループメンバー',//'Group members',
			'groups:membership' => "グループ参加の許可",//"Group membership permissions",
			'groups:access' => "公開範囲の許可",//"Access permissions",
			'groups:owner' => "リーダー",//"Owner",
			'groups:widget:num_display' => '一覧表示数',//'Number of groups to display',
			'groups:widget:membership' => 'グループ参加',//'Group membership',
			'groups:widgets:description' => 'プロフィールに所属するグループの表示',//'Display the groups you are a member of on your profile',
			'groups:noaccess' => 'グループへのアクセスを許可しない',//'No access to group',
			'groups:cantedit' => 'このグループを編集できません。',//'You can not edit this group',
			'groups:saved' => '保存',//'Group saved',
			'groups:featured' => 'クローズアップ',//'Featured groups',
			'groups:makeunfeatured' => 'クローズアップをやめる',//'Unfeature',
			'groups:makefeatured' => 'クローズアップに登録する',//'Make featured',
			'groups:featuredon' => 'このグループをクローズアップに登録しました。',//'You have made this group a featured one.',
			'groups:unfeature' => 'このグループをクローズアップから外しました。',//'You have removed this group from the featured list',
			'groups:joinrequest' => '参加希望',//'Request membership',
			'groups:join' => 'グループへの参加',//'Join group',
			'groups:leave' => 'グループをやめる',//'Leave group',
			'groups:invite' => '友達を招待',//'Invite friends',
			'groups:inviteto' => "%s に友達を招待",//"Invite friends to '%s'",
			'groups:nofriends' => "このグループに招待できる人はいません。",//"You have no friends left who have not been invited to this group.",
			'groups:viagroups' => "via groups",
			'groups:group' => "グループ",//"Group",
			'groups:search:tags' => "タグ",//"tag",

			'groups:notfound' => "グループが見つかりません。",//"Group not found",
			'groups:notfound:details' => "グループは存在しないか、アクセス許可がありません。",//"The requested group either does not exist or you do not have access to it",

			'groups:requests:none' => '会員リクエストはありません。',//'There are no outstanding membership requests at this time.',

			'groups:invitations:none' => 'グループへの招待はありません。',//'There are no oustanding invitations at this time.',

			'item:object:groupforumtopic' => "フォーラムトピック",//"Discussion topics",

			'groupforumtopic:new' => "新規フォーラム投稿",//"New discussion post",

			'groups:count' => "グループ数",//"groups created",
			'groups:open' => "オープングループ",//"open group",
			'groups:closed' => "クローズドグループ",//"closed group",
			'groups:member' => "会員",//"members",
			'groups:searchtag' => "タグでグループを検索",//"Search for groups by tag",


			/*
			 * Access
			 */
			'groups:access:private' => 'クローズド - 招待制です。',//'Closed - Users must be invited',
			'groups:access:public' => 'フリー参加 - 誰でも参加できます。',//'Open - Any user may join',
			'groups:closedgroup' => 'このグループはクローズドな招待制なグループです。参加をしたい場合は「参加希望」をクリックしてリクエストを送ってください。',//'This group has a closed membership. To ask to be added, click the "request membership" menu link.',
			'groups:visibility' => 'このグループのコンテンツをみることができる人',//'Who can see this group?',

			/*
			Group tools
			*/
			'groups:enablepages' => 'グループページの利用',//'Enable group pages',
			'groups:enableforum' => 'グループフォーラムの利用',//'Enable group discussion',
			'groups:enablefiles' => 'グループファイル共有の利用',//'Enable group files',
			'groups:yes' => 'はい',//'yes',
			'groups:no' => 'いいえ',//'no',

			'group:created' => '作成 %s （ %d ）',//'Created %s with %d posts',
			'groups:lastupdated' => '最終更新 %s （更新者 %s ）',//'Last updated %s by %s',
			'groups:pages' => 'グループページ',//'Group pages',
			'groups:files' => 'ファイル共有',//'Group files',

			/*
			Group forum strings
			*/

			'group:replies' => '返信',//'Replies',
			'groups:forum' => 'グループフォーラム',//'Group discussion',
			'groups:addtopic' => '新規トピック作成',//'Add a topic',
			'groups:forumlatest' => '最新のやりとり',//'Latest discussion',
			'groups:latestdiscussion' => '最新のやりとり',//'Latest discussion',
			'groups:newest' => '新着',//'Newest',
			'groups:popular' => '人気',//'Popular',
			'groupspost:success' => 'コメントを投稿しました。',//'Your comment was succesfully posted',
			'groups:alldiscussion' => '最新のやりとり',//'Latest discussion',
			'groups:edittopic' => 'トピックの編集',//'Edit topic',
			'groups:topicmessage' => 'トピックメッセージ',//'Topic message',
			'groups:topicstatus' => 'トピックステータス',//'Topic status',
			'groups:reply' => 'コメントの投稿',//'Post a comment',
			'groups:topic' => 'トピック',//'Topic',
			'groups:posts' => '投稿',//'Posts',
			'groups:lastperson' => '最後に投稿した人',//'Last person',
			'groups:when' => 'いつ',//'When',
			'grouptopic:notcreated' => 'トピックはありません。',//'No topics have been created.',
			'groups:topicopen' => '稼働中',//'Open',
			'groups:topicclosed' => '終了',//'Closed',
			'groups:topicresolved' => '解決済み',//'Resolved',
			'grouptopic:created' => 'トピックを作成しました。',//'Your topic was created.',
			'groupstopic:deleted' => 'トピックを削除しました。',//'The topic has been deleted.',
			'groups:topicsticky' => 'スティッキー',//'Sticky',
			'groups:topicisclosed' => 'このトピックは終了しました。',//'This topic is closed.',
			'groups:topiccloseddesc' => 'このトピックは終了しました。新しいコメントは受け付けていません。',//'This topic has now been closed and is not accepting new comments.',
			'grouptopic:error' => 'グループトピックが作成できません。システム管理者に問い合わせください。',//'Your group topic could not be created. Please try again or contact a system administrator.',
			'groups:forumpost:edited' => "投稿を編集しました。",//"You have successfully edited the forum post.",
			'groups:forumpost:error' => "投稿の編集の際に問題が発生しました。",//"There was a problem editing the forum post.",
			'groups:privategroup' => 'このグループはクローズド - 招待制です。',//'This group is private, requesting membership.',
			'groups:notitle' => 'グループ作成にはグループ名が必要です。',//'Groups must have a title',
			'groups:cantjoin' => 'グループに参加できません。',//'Can not join group',
			'groups:cantleave' => 'グループをやめることができません。',//'Could not leave group',
			'groups:addedtogroup' => 'グループにユーザーを追加しました。',//'Successfully added the user to the group',
			'groups:joinrequestnotmade' => 'グループ参加のリクエストに失敗しました。',//'Could not request to join group',
			'groups:joinrequestmade' => 'グループ参加のリクエスト',//'Requested to join group',
			'groups:joined' => 'グループに参加しました！',//'Successfully joined group!',
			'groups:left' => 'グループをやめました。',//'Successfully left group',
			'groups:notowner' => '申し訳ありません。あなたはこのグループのリーダーではありません。',//'Sorry, you are not the owner of this group.',
			'groups:notmember' => '申し訳ありません。あなたはこのグループの会員ではありません。',//'Sorry, you are not a member of this group.',
			'groups:alreadymember' => 'あなたはすでにこのグループの会員です。',//'You are already a member of this group!',
			'groups:userinvited' => '招待しました。',//'User has been invited.',
			'groups:usernotinvited' => '招待ができません。',//'User could not be invited.',
			'groups:useralreadyinvited' => 'すでに招待済みです。',//'User has already been invited',
			'groups:updated' => "新着コメント",//"Last comment",
			'groups:invite:subject' => "%s さん、%s に招待されました！",//"%s you have been invited to join %s!",
			'groups:started' => "Started by",
			'groups:joinrequest:remove:check' => 'この招待リクエストを削除してよいですか？',//'Are you sure you want to remove this join request?',
			'groups:invite:body' => "%s さん、こんにちは。

%s があなたをグループ '%s' に招待しています。下記をご覧下さい。

%s",
/* "Hi %s,

%s invited you to join the '%s' group, click below to confirm:

%s",
*/
			'groups:welcome:subject' => "ようこそ、%s グループへ！",//"Welcome to the %s group!",
			'groups:welcome:body' => "%s さん、こんにちは。

You are now a member of the '%s' group! Click below to begin posting!
あなたは '%s' グループに参加しました！ 下記からグループページへアクセスできます。

%s",
/*
 "Hi %s!

You are now a member of the '%s' group! Click below to begin posting!

%s", 
*/

			'groups:request:subject' => "%s は %s へ招待されました。",//"%s has requested to join %s",
			'groups:request:body' => "%s さん、こんにちは。

%s はグループ '%s' に招待しています。グループのプロフィールは下記からご覧下さい。

%s

招待状は下記からご覧下さい。

%s",

/*
"Hi %s,

%s has requested to join the '%s' group, click below to view their profile:

%s

or click below to confirm request:

%s",
*/
			/*
				Forum river items
			*/

			'groups:river:member' => 'はメンバーになりました。',//'is now a member of',
			'groupforum:river:updated' => '%s が更新されました。',//'%s has updated',
			'groupforum:river:update' => 'トピックス',//'this discussion topic',
			'groupforum:river:created' => '%s が作成されました。',//'%s has created',
			'groupforum:river:create' => '新しいトピックが作成されました。',//'a new discussion topic titled',
			'groupforum:river:posted' => '%s にコメントがつきました。',//'%s has posted a new comment',
			'groupforum:river:annotate:create' => 'このトピック',//'on this discussion topic',
			'groupforum:river:postedtopic' => '%s はトピックを立ち上げました。',//'%s has started a new discussion topic titled',
			'groups:river:member' => '%s はメンバーになりました。',//'%s is now a member of',
			'groups:river:togroup' => 'グループに',//'to the group',

			'groups:nowidgets' => 'このグループに設定されているウィジェットはありません。',//'No widgets have been defined for this group.',


			'groups:widgets:members:title' => 'グループメンバー',//'Group members',
			'groups:widgets:members:description' => 'メンバー一覧',//'List the members of a group.',
			'groups:widgets:members:label:displaynum' => 'メンバー一覧',//'List the members of a group.',
			'groups:widgets:members:label:pleaseedit' => 'ウィジェットの設定',//'Please configure this widget.',

			'groups:widgets:entities:title' => 'オブジェクト',//"Objects in group",
			'groups:widgets:entities:description' => "保存されたオブジェクト一覧。",//"List the objects saved in this group",
			'groups:widgets:entities:label:displaynum' => 'オブジェクト一覧',//'List the objects of a group.',
			'groups:widgets:entities:label:pleaseedit' => 'ウィジェットの設定',//'Please configure this widget.',

			'groups:forumtopic:edited' => 'フォーラムトピックを編集しました。',//'Forum topic successfully edited.',

			'groups:allowhiddengroups' => 'プライベートなグループを許可しますか？',//'Do you want to allow private (invisible) groups?',

			/**
			 * Action messages
			 */
			'group:deleted' => 'グループとグループのコンテンツを削除しました。',//'Group and group contents deleted',
			'group:notdeleted' => 'グループが削除できません。',//'Group could not be deleted',

			'grouppost:deleted' => '投稿を削除しました。',//'Group posting successfully deleted',
			'grouppost:notdeleted' => '投稿が削除できません。',//'Group posting could not be deleted',
			'groupstopic:deleted' => '削除したトピック',//'Topic deleted',
			'groupstopic:notdeleted' => '削除していないトピック',//'Topic not deleted',
			'grouptopic:blank' => 'トピックはありません',//'No topic',
			'grouptopic:notfound' => 'トピックが見つかりません。',//'Could not find the topic',
			'grouppost:nopost' => '投稿がありません。',//'Empty post',
			'groups:deletewarning' => "このグループを削除していいですか？削除したら元に戻す事はできません！",//"Are you sure you want to delete this group? There is no undo!",

			'groups:joinrequestkilled' => '参加リクエストを削除しました。',//'The join request has been deleted.',
	);

	add_translation("ja",$japanese);
?>
