<?php

	$japanese = array(
	
		/**
		 * Friends widget
		 */
			'friends:widget:description' => "友達の表示",//"Displays some of your friends.",
	        
		
	);
					
	add_translation("ja",$japanese);

?>
