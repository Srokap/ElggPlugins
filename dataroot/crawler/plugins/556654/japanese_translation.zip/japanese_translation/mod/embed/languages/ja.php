<?php

	$japanese = array(
	
		'media:insert' => 'ファイル貼り付け',//'Embed / upload media',
	
		'embed:instructions' => '貼り付けるファイルを選択',//'Click on any file to embed it into your content.',
	
		'embed:media' => 'ファイルの貼り付け',//'Embed media',
		'upload:media' => 'ファイルのアップロード',//'Upload media',
	
		'embed:file:required' => 'アップロード機能がありません。ファイルアップロードプラグインを有効にする必要があります。',//'No file upload facilities were found. The system administrator may need to upload the file plugin or similar.',
	
	);
					
	add_translation("ja",$japanese);

?>
