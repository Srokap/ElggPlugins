<?php
	/**
	 * Elgg file plugin language pack
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2010
	 * @link http://elgg.com/
	 */

	$japanese = array(
	
		/**
		 * Menu items and titles
		 */
	
			'file' => "ファイル",//"Files",
			'files' => "ファイル",//"Files",
			'file:yours' => "あなたのファイル",//"Your files",
			'file:yours:friends' => "友達のファイル",//"Your friends' files",
			'file:user' => "%s のファイル",//"%s's files",
			'file:friends' => "%s の友達のファイル",//"%s's friends' files",
			'file:all' => "サイト全体のファイル",//"All site files",
			'file:edit' => "ファイル編集",//"Edit file",
			'file:more' => "もっとみる",//"More files",
			'file:list' => "リスト表示",//"list view",
			'file:group' => "グループファイル",//"Group files",
			'file:gallery' => "ギャラリー表示",//"gallery view",
			'file:gallery_list' => "ギャラリー表示 or リスト表示",//"Gallery or list view",
			'file:num_files' => "一覧表示数",//"Number of files to display",
			'file:user:gallery'=>'%s のギャラリーをみる',//'View %s gallery', 
	        	'file:via' => 'ファイルより',//'via files',
			'file:upload' => "ファイルのアップロード",//"Upload a file",
			'file:replace' => 'ファイルの置き換え',//'Replace file content (leave blank to not change file)',
	
			'file:newupload' => '新しいファイルのアップロード',//'New file upload',
			
			'file:file' => "ファイル",//"File",
			'file:title' => "タイトル",//"Title",
			'file:desc' => "説明",//"Description",
			'file:tags' => "タグ",//"Tags",
	
			'file:types' => "ファイルタイプ",//"Uploaded file types",
	
			'file:type:all' => "すべてのファイル",//"All files",
			'file:type:video' => "動画",//"Videos",
			'file:type:document' => "ドキュメント",//"Documents",
			'file:type:audio' => "音声",//"Audio",
			'file:type:image' => "画像",//"Pictures",
			'file:type:general' => "その他",//"General",
	
			'file:user:type:video' => "%s の動画",//"%s's videos",
			'file:user:type:document' => "%s のドキュメント",//"%s's documents",
			'file:user:type:audio' => "%s の音声",//"%s's audio",
			'file:user:type:image' => "%s の画像",//"%s's pictures",
			'file:user:type:general' => "%s のその他のファイル",//"%s's general files",
	
			'file:friends:type:video' => "友達の動画",//"Your friends' videos",
			'file:friends:type:document' => "友達のドキュメント",//"Your friends' documents",
			'file:friends:type:audio' => "友達の音声",//"Your friends' audio",
			'file:friends:type:image' => "友達の画像",//"Your friends' pictures",
			'file:friends:type:general' => "友達のその他のファイル",//"Your friends' general files",
	
			'file:widget' => "ファイル・ウィジェット",//"File widget",
			'file:widget:description' => "新着ファイル",//"Showcase your latest files",
	
			'file:download' => "このファイルのダウンロード",//"Download this",
	
			'file:delete:confirm' => "本当にこのファイルを削除しますか？",//"Are you sure you want to delete this file?",
			
			'file:tagcloud' => "タグクラウド",//"Tag cloud",
	
			'file:display:number' => "一覧表示数",//"Number of files to display",
	
			'file:river:created' => "%s がファイルをアップロードしました。",//"%s uploaded",
			'file:river:item' => "ファイル",//"a file",
			'file:river:annotate' => "このファイルにコメント",//"a comment on this file",

			'item:object:file' => 'ファイル',//'Files',
			
	    /**
		 * Embed media
		 **/
		 
		    'file:embed' => "ファイルの貼付け",//"Embed media",
		    'file:embedall' => "すべて",//"All",
	
		/**
		 * Status messages
		 */
	
			'file:saved' => "ファイルを保存しました。",//"Your file was successfully saved.",
			'file:deleted' => "ファイルを削除しました。",//"Your file was successfully deleted.",
	
		/**
		 * Error messages
		 */
	
			'file:none' => "ファイルがありません。",//"No files uploaded.",
			'file:uploadfailed' => "申し訳ありません。ファイルを保存できません。",//"Sorry; we could not save your file.",
			'file:downloadfailed' => "申し訳ありません。今、このファイルは利用できません。",//"Sorry; this file is not available at this time.",
			'file:deletefailed' => "今、このファイルは削除できません。",//"Your file could not be deleted at this time.",
			'file:noaccess' => "このファイルを変更する権限がありません。",//"You do not have permissions to change this file",
			'file:cannotload' => "ファイルを読み込む際にエラーが発生しました。",//"There was an error loading the file",
			'file:nofile' => "ファイルを選択して下さい。",//"You must select a file",
	);
					
	add_translation("ja",$japanese);
?>
