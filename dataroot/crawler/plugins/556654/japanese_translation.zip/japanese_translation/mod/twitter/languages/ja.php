<?php

	$japanese = array(
	
		/**
		 * twitter widget details
		 */
		
	
		'twitter:username' => 'twitterのユーザー名を入力して下さい。',//'Enter your twitter username.',
		'twitter:num' => '一覧表示数',//'The number of tweets to show.',
		'twitter:visit' => 'このtwitterをみる',//'visit my twitter',
		'twitter:notset' => 'Twitterウィジェットはまだセットアップが完了していません。最新のtweetを表示するには、右上の編集をクリックして情報を入力してください。',//'This Twitter widget is not yet set to go. To display your latest tweets, click on - edit - and fill in your details',
		
		
		 /**
	     * twitter widget river
	     **/
	        
	        //generic terms to use
	        'twitter:river:created' => "%s がtwitter ウィジェットを追加しました。",//"%s added the twitter widget.",
	        'twitter:river:updated' => "%s がtwitter ウィジェットを更新しました。",//"%s updated their twitter widget.",
	        'twitter:river:delete' => "%s がtwitter ウィジェットを削除しました。",//"%s removed their twitter widget.",
	        
		
	);
					
	add_translation("ja",$japanese);

?>
