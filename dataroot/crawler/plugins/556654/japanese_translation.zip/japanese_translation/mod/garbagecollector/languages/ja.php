<?php
	/**
	 * Elgg garbage collector language pack.
	 * 
	 * @package ElggGarbageCollector
	 * @author Curverider Ltd
	 * @link http://elgg.com/
	 */

	$japanese = array(
	
		/**
		 * Menu items and titles
		 */
	
			'garbagecollector:period' => 'ガベージコレクションを動かす周期',//'How often should the Elgg garbage collector run?',
	
			'garbagecollector:weekly' => '１週間に１回',//'Once a week',
			'garbagecollector:monthly' => '１ヶ月に１回',//'Once a month',
			'garbagecollector:yearly' => '１年に１回',//'Once a year',
	
			'garbagecollector' => "ガベージコレクター\n",//"GARBAGE COLLECTOR\n",
			'garbagecollector:done' => "完了\n",//"DONE\n",
			'garbagecollector:optimize' => "%s の最適化中",//"Optimizing %s ",
	
			'garbagecollector:error' => "エラー",//"ERROR",
			'garbagecollector:ok' => "OK!",//"OK",
	
			'garbagecollector:gc:metastrings' => 'どこからもリンクされていないメタ文字を除去中',//'Cleaning up unlinked metastrings: ',
	
	);
					
	add_translation("ja",$japanese);
?>
