<?php

	$japanese = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messageboard:board' => "メモ",//"Message board",
			'messageboard:messageboard' => "メモ",//"message board",
			'messageboard:viewall' => "すべてみる",//"View all",
			'messageboard:postit' => "投稿",//"Post it",
			'messageboard:history:title' => "過去のメモ",//"History",
			'messageboard:none' => "メモはありません。",//"There is nothing on this message board yet",
			'messageboard:num_display' => "一覧表示数",//"Number of messages to display",
			'messageboard:desc' => "「メモ」を使うとプロフィールページ上でいろいろな人から書き込みをしてもらえます。",//"This is a message board that you can put on your profile where other users can comment.",
	
			'messageboard:user' => "%s のメモ",//"%s's message board",
	
			'messageboard:replyon' => '返信',//'reply on',
			'messageboard:history' => "過去のメモ",//"history",
	
         /**
	     * Message board widget river
	     **/
	        
	        'messageboard:river:annotate' => "%s はメモに新しい書き込みをしました。",//"%s has had a new comment posted on their message board.",
	        'messageboard:river:create' => "%s はメモ・ウィジェットを追加しました。",//"%s added the message board widget.",
	        'messageboard:river:update' => "%s はメモ・ウィジェットを更新しました。",//"%s updated their message board widget.",
	        'messageboard:river:added' => "%s が書き込み",//"%s posted on",
		    'messageboard:river:messageboard' => "メモ",//"message board",

			
		/**
		 * Status messages
		 */
	
			'messageboard:posted' => "メモに書き込みをしました。",//"You successfully posted on the message board.",
			'messageboard:deleted' => "メモの書き込みを削除しました。",//"You successfully deleted the message.",
	
		/**
		 * Email messages
		 */
	
			'messageboard:email:subject' => 'メモに新しい書き込みがあります！',//'You have a new message board comment!',
			'messageboard:email:body' => "メモに %s から新しい書き込みがありました。

%s

この書き込みをみるには下記URLをクリックして下さい。

%s

%s のプロフィールはこちらです。

%s

(＊) このメールに返信しないでください。


",
/*
 "You have a new message board comment from %s. It reads:

			
%s


To view your message board comments, click here:

	%s

To view %s's profile, click here:

	%s

You cannot reply to this email.",
*/	
		/**
		 * Error messages
		 */
	
			'messageboard:blank' => "申し訳ありません。何か入力した後、保存して下さい。",//"Sorry; you need to actually put something in the message area before we can save it.",
			'messageboard:notfound' => "申し訳ありません。そのアイテムは見当たりません。",//"Sorry; we could not find the specified item.",
			'messageboard:notdeleted' => "申し訳ありません。書き込みを削除できません。",//"Sorry; we could not delete this message.",
			'messageboard:somethingwentwrong' => "書き込みの保存中、何らかの問題が発生しました。",//"Something went wrong when trying to save your message, make sure you actually wrote a message.",
	     
			'messageboard:failure' => "書き込みの際に何からのエラーが発生しました。",//"An unexpected error occurred when adding your message. Please try again.",
	
	);
					
	add_translation("ja",$japanese);

?>
