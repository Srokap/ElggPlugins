<?php

	$japanese = array(
	
		'categories' => 'カテゴリ',//'Categories',
		'categories:settings' => 'カテゴリの設定',//'Set site categories',	
		'categories:explanation' => 'サイト内カテゴリを設定することにより、サイトシステム全体でそのカテゴリが利用でき
るようになります。互換性のあるツールであれば、コンテンツを新規作成、または編集する画面にカテゴリ設定欄が表示されるでしょう。<br /><br />カテゴリはカンマで区切って列挙してください。',//'To set some predefined site-wide categories that will be used throughout your system, enter them below, separated with commas. Compatible tools will then display them when the user creates or edits content.',	
		'categories:save:success' => 'サイトカテゴリを保存しました。',//'Site categories were successfully saved.',
	
	);
					
	add_translation("ja",$japanese);

?>
