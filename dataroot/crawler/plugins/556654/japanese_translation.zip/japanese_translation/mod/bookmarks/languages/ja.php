<?php

	$japanese = array(
	
		/**
		 * Menu items and titles
		 */
	
			'bookmarks' => "ブックマーク",//"Bookmarks",
			'bookmark'  => "ブックマーク",
			'bookmarks:add' => "新規ブックマーク登録",//"Add bookmark",
			'bookmarks:read' => "%s のブックマーク",//"%s's bookmarked items",
			'bookmarks:friends' => "友達のブックマーク",//"Friends' bookmarks",
			'bookmarks:everyone' => "サイト全体のブックマーク",//"All site bookmarks",
			'bookmarks:this' => "このページをブックマークする",//"Bookmark this",
			'bookmarks:this:group' => "%s のブックマーク",//"Bookmark in %s",
			'bookmarks:bookmarklet' => "ブックマークレットの取得",//"Get bookmarklet",
			'bookmarks:bookmarklet:group' => "グループ用ブックマークレットの取得",//"Get group bookmarklet",
			'bookmarks:inbox' => "ブックマーク一覧",//"Bookmarks inbox",
			'bookmarks:more' => "もっとみる",//"More",
			'bookmarks:shareditem' => "ブックマークしたアイテム",//"Bookmarked item",
			'bookmarks:with' => "共有するメンバーの選択",//"Share with",
			'bookmarks:new' => "新着ブックマーク",//"A new bookmarked item",
			'bookmarks:via' => "via bookmarks",
			'bookmarks:address' => "URL",//"Address of the resource to bookmark",
	
			'bookmarks:delete:confirm' => "本当に削除しますか?",//"Are you sure you want to delete this resource?",
	
			'bookmarks:numbertodisplay' => '一覧表示数',//'Number of bookmarked items to display',
	
			'bookmarks:shared' => "ブックマーク済み",//"Bookmarked",
			'bookmarks:visit' => "ブックマーク先へ",//"Visit resource",
			'bookmarks:recent' => "最近のブックマーク",//"Recent bookmarks",
	
			'bookmarks:river:created' => '%s がブックマーク',//'%s bookmarked',
			'bookmarks:river:annotate' => 'このブックマークへのコメント',//'a comment on this bookmarked item',
			'bookmarks:river:item' => 'アイテム',//'an item',
	
			'item:object:bookmarks' => 'ブックマークアイテム',//'Bookmarked items',
	
			'bookmarks:group' => 'ブループブックマーク',//'Group bookmarks',
			'bookmarks:enablebookmarks' => 'グループブックマークの利用',//'Enable group bookmarks',
	
	
		/**
		 * More text
		 */
		    
		    'bookmarks:widget:description' => 
		            "新着ブックマークをダッシュボードに表示します。",//"This widget is designed for your dashboard and will show you the latest items in your bookmarks inbox.",
	
			'bookmarks:bookmarklet:description' =>
					"ブックマークレットはWebで見つけたサイトの情報を友達や自分のために素早く保存するためのものです。下のボタンをブラウザのリンクバーにドラッグするだけで利用が開始できます。",//"The bookmarks bookmarklet allows you to share any resource you find on the web with your friends, or just bookmark it for yourself. To use it, simply drag the following button to your browser's links bar:",

	        'bookmarks:bookmarklet:descriptionie' =>
					"Internet Explorerをお使いの方はブックマークレットアイコンを右クリックしてから「お気に入りに保存」を選択していただき、その後、リンクバーに登録してください。",//"If you are using Internet Explorer, you will need to right click on the bookmarklet icon, select 'add to favorites', and then the Links bar.",

			'bookmarks:bookmarklet:description:conclusion' =>
					"これでいつでもページをブックマーク登録できるようになりました。",//"You can then save any page you visit by clicking it at any time.",
	
		/**
		 * Status messages
		 */
	
			'bookmarks:save:success' => "ブックマークに登録しました。",//"Your item was successfully bookmarked.",
			'bookmarks:delete:success' => "ブックマークから削除しました。",//"Your bookmarked item was successfully deleted.",
	
		/**
		 * Error messages
		 */
	
			'bookmarks:save:failed' => "ブックマークに登録できません。",//"Your bookmarked item could not be saved. Please try again.",
			'bookmarks:delete:failed' => "ブックマークから削除できません。",//"Your bookmarked item could not be deleted. Please try again.",
	
	
	);
					
	add_translation("ja",$japanese);

?>
