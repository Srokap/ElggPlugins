<?php
	$japanese = array(
		'twitterservice' => 'Twitterサービス',//'Twitter Service',
		'twitterservice:postwire' => '下記オプションを設定することにより、あな
たのtwitterアカウントにこのサイトでのwireを同時投稿することができます。あなたはwireの>投稿をtwitterにも同時投稿しますか？',//'By setting the following option all messages you post to The Wire will be sent to your twitter account. Do you want to post your messages from The Wire to Twitter?',
		'twitterservice:twittername' => 'Twitterユーザー名',//'Twitter username',
		'twitterservice:twitterpass' => 'Twitterパスワード',//'Twitter password',
	);
					
	add_translation("ja",$japanese);
?>
