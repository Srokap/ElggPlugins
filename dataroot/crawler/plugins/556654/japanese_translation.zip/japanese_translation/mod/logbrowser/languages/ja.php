<?php
	/**
	 * Elgg log browser plugin language pack
	 * 
	 * @package ElggLogBrowser
	 * @author Curverider Ltd
	 * @link http://elgg.com/
	 */

	$japanese = array(
	
		/**
		 * Menu items and titles
		 */
	
			'logbrowser' => 'ログ',//'Log browser',
			'logbrowser:browse' => 'システムログの閲覧',//'Browse system log',
			'logbrowser:search' => '絞り込み',//'Refine results',
			'logbrowser:user' => 'ユーザー名での検索',//'Username to search by',
			'logbrowser:starttime' => 'Beginning time (for example "last monday", "1 hour ago")',
			'logbrowser:endtime' => 'End time',
	
			'logbrowser:explore' => 'ログの探索',//'Explore log',
	
	);
					
	add_translation("ja",$japanese);
?>
