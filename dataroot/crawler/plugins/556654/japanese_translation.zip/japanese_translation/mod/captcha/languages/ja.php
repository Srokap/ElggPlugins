<?php
	/**
	 * Elgg diagnostics language pack.
	 * 
	 * @package ElggDiagnostics
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2010
	 * @link http://elgg.com/
	 */

	$japanese = array(
	
		'captcha:entercaptcha' => '画像に書かれている文字列を入力して下さい。',//'Enter text from image',
		'captcha:captchafail' => '申し訳ありません。入力した文字が違います。',//'Sorry, the text that you entered didn\'t match the text in the image.',
	
	);
					
	add_translation("ja",$japanese);
?>
