<?php

	$japanese = array(

		'mine' => '自分',//'Mine',
		'filter' => 'フィルタ',//'Filter',
		'riverdashboard:useasdashboard' => "デフォルトのダッシュボードをriverダッシュボードに置き換えますか？",//"Replace the default dashboard with this activity river?",
		'activity' => 'アクティビティ',//'Activity',
		'riverdashboard:recentmembers' => '最近のメンバー',//'Recent members',
	
	    /**
	     * Site messages
           **/

		'sitemessages:announcements' => "アナウンス",//"Site announcements",
		'sitemessages:posted' => "投稿",//"Posted",
		'sitemessages:river:created' => "サイト管理者： %s",//"Site admin, %s,",
		'sitemessages:river:create' => "新しいサイトメッセージを投稿しました。",//"posted a new site wide message",
		'sitemessages:add' => "サイトメッセージの追加",//"Add a site-wide message to the river page",
		'sitemessage:deleted' => "サイトメッセージを削除しました。",//"Site message deleted",
		'sitemessage:error' => "サイトメッセージが保存できません。",//"Failed to save site message.",
		
		'river:widget:noactivity' => 'アクティビティがありません。',//'We could not find any activity.',
		'river:widget:title' => "アクティビティ",//"Activity",
		'river:widget:description' => '最近のあなたのアクティビティの表示',//"Show your latest activity.",
		'river:widget:title:friends' => "友達のアクティビティ",//"Friends' activity",
		'river:widget:description:friends' => "友達のアクティビティの表示",//"Show what your friends are up to.",
		'river:widgets:friends' => "友達",//"Friends",
		'river:widgets:mine' => "自分",//"Mine",
		'river:widget:label:displaynum' => "表示一覧数",//"Number of entries to display:",
		'river:widget:type' => "どちらのリバーを表示しますか？ ひとつはあなたのアクティビティを、もう一つは友達のアクティビティを表示します。",//"Which river would you like to display? One that shows your activity or one that shows your friends activity?",
		'item:object:sitemessage' => "サイトメッセージ",//"Site messages",
		'riverdashboard:avataricon' => "アクティビティタイムラインにアバターかアイコンを表示させますか？",//"Would you like to use user avatars or icons on your site activity stream?",
		'option:icon' => 'アイコン',//'Icons',
		'option:avatar' => 'アバター',//'Avatars',
	);
					
	add_translation("ja",$japanese);

?>
