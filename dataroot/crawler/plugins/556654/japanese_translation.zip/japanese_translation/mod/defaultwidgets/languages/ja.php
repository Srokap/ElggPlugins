<?php

$japanese = array (

	/**
	 * Nice name for the entity (shown in admin panel)
	 */
	'item:object:moddefaultwidgets' => '標準ウィジェット設定',//'DefaultWidgets settings',

	/**
	 * Menu items
	 */
	'defaultwidgets:menu:profile' => 'プロフィール標準ウィジェット',//'Default profile widgets',
    'defaultwidgets:menu:dashboard' => 'ダッシュボード標準ウィジェット',//'Default dashboard widgets',

    'defaultwidgets:admin:error' => 'エラー：管理者権限がありません。',//'Error: You are not logged in as an administrator',
	'defaultwidgets:admin:notfound' => 'エラー：ページがありません。',//'Error: Page not found',
	'defaultwidgets:admin:loginfailure' => '警告：管理者でログインしていません。',//'Warning: You are not currently logged is as an administrator',

	'defaultwidgets:update:success' => '設定を保存しました。',//'Your widget settings have been saved',
	'defaultwidgets:update:failed' => 'エラー： 設定が保存できません。',//'Error: settings have not been saved',
	'defaultwidgets:update:noparams' => 'エラー：入力が不正です。',//'Error: incorrect form parameters',

	'defaultwidgets:profile:title' => 'プロフィールページ用のデフォルトウィジェットを設定',//'Set default widgets for new user profile pages',
	'defaultwidgets:dashboard:title' => 'ダッシュボード用のデフォルトウィジェットを設定',//'Set default widgets for new user dashboard pages',
);

add_translation ( "ja", $japanese );
