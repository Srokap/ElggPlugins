<?php

	/**
	 * Elgg invite page
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2010
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @link http://elgg.org/
	 */

	$japanese = array(

		'friends:invite' => '友達を招待する',//'Invite friends',
		'invitefriends:introduction' => '記入力欄にEメールアドレスを入力して（1メールアドレスにつき行ずつ）、このネットワークに友達を招待しましょう。:',//'To invite friends to join you on this network, enter their email addresses below (one per line):',
		'invitefriends:message' => '招待を受け取る人へのメッセージを入力して下さい。',//'Enter a message they will receive with your invitation:',
		'invitefriends:subject' => '%s への招待',//'Invitation to join %s',
	
		'invitefriends:success' => 'あなたの友達を招待しました。',//'Your friends were invited.',
		'invitefriends:email_error' => '招待状を送信しましたが、次のアドレスは送信できませんでした。: %s',//'Invitations were sent, but the following addresses are not valid: %s',
		'invitefriends:failure' => 'その友達は招待できませんでした。',//'Your friends could not be invited.',
	
		'invitefriends:message:default' => '
こんにちは。

あなたを %s に招待します。',
/*
'
Hi,

I want to invite you to join my network here on %s.',

*/
                'invitefriends:email' => '
%s への招待が %s より届きました。

%s

参加する場合は、下のリンクをクリックしてください。

%s

アカウントを作成すると自動的に友達として登録されます。',

/*
You have been invited to join %s by %s. They included the following message:

%s

To join, click the following link:

%s

You will automatically add them as a friend when you create your account.',
*/	
	);
					
	add_translation("ja",$japanese);
?>
