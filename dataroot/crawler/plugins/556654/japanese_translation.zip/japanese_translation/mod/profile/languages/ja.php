<?php
	/**
	 * Elgg profile plugin language pack
	 *
	 * @package ElggProfile
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2010
	 * @link http://elgg.com/
	 */

	$japanese = array(

	/**
	 * Profile
	 */

		'profile' => "プロフィール",//"Profile",
		'profile:edit:default' => "プロフィール入力欄の変更",//'Replace profile fields',
		'profile:preview' => 'プレビュー',//'Preview',

	/**
	 * Profile menu items and titles
	 */

		'profile:yours' => "あなたのプロフィール",//"Your profile",
		'profile:user' => "%s のプロフィール",//"%s's profile",

		'profile:edit' => "プロフィールの編集",//"Edit profile",
		'profile:profilepictureinstructions' => "プロフィール用の画像はあなたのプロフィールペー>
ジで掲載されます。<br />この画像はいつでも変更可能です。（ファイルフォーマットはGIFかJPEG、PNGでお願いし
ます。）",//"The profile picture is the image that's displayed on your profile page. <br /> You can change it as often as you'd like. (File formats accepted: GIF, JPG or PNG)",
		'profile:icon' => "プロフィール用の画像",//"Profile picture",
		'profile:createicon' => "アバターの作成",//"Create your avatar",
		'profile:currentavatar' => "現在のアバター",//"Current avatar",
		'profile:createicon:header' => "プロフィール用の画像",//"Profile picture",
		'profile:profilepicturecroppingtool' => "プロフィール用画像のクロッピングツール",//"Profile picture cropping tool",
		'profile:createicon:instructions' => "アップロードした画像をクリック＆ドラッグして正方形にクロッピングできます。右側にプレビュー画像が表示されます。クロッピング具合がちょうどいいと確認したら「アバターの作成」をクリックするとその状態が保存されます。この画像は一覧表示等で利用されます。",//"Click and drag a square below to match how you want your picture cropped.  A preview of your cropped picture will appear in the box on the right.  When you are happy with the preview, click 'Create your avatar'. This cropped image will be used throughout the site as your avatar. ",

		'profile:editdetails' => "詳細を編集",//"Edit details",
		'profile:editicon' => "プロフィールアイコンを変更",//"Edit profile icon",

		'profile:aboutme' => "自己紹介",//"About me",
		'profile:description' => "自己紹介",//"About me",
		'profile:briefdescription' => "自己紹介（短め）",//"Brief description",
		'profile:location' => "場所",//"Location",
		'profile:skills' => "スキル",//"Skills",
		'profile:interests' => "興味",//"Interests",
		'profile:contactemail' => "連絡用Eメールアドレス",//"Contact email",
		'profile:phone' => "電話番号",//"Telephone",
		'profile:mobile' => "携帯電話番号",//"Mobile phone",
		'profile:website' => "Web",//"Website",

		'profile:banned' => 'このユーザーアカウントは停止されています。',//'This user account has been suspended.',
		'profile:deleteduser' => '削除済みユーザー',//'Deleted user',

		'profile:river:update' => "%s はプロフィールを更新しました。",//"%s updated their profile",
		'profile:river:iconupdate' => "%s はプロフィール用アイコンを更新しました。",//"%s updated their profile icon",

		'profile:label' => "入力欄見出し",//"Profile label",
		'profile:type' => "入力データタイプ",//"Profile type",

		'profile:editdefault:fail' => 'デフォルトプロフィールが保存できません。',//'Default profile could not be saved',
		'profile:editdefault:success' => 'デフォルトプロフィールに登録が完了しました。',//'Item successfully added to default profile',


		'profile:editdefault:delete:fail' => 'プロフィール入力欄の削除に失敗しました。',//'Removed default profile item field failed',
		'profile:editdefault:delete:success' => 'その項目を削除しました。',//'Default profile item deleted!',

		'profile:defaultprofile:reset' => 'デフォルトのシステムプロフィールをリセットしました。',//'Default system profile reset',

		'profile:resetdefault' => 'デフォルトプロフィールのリセット',//'Reset default profile',
		'profile:explainchangefields' => '既存のプロフィール入力欄をあなたが設定したフィールドに置き換わります。まずは「入力欄見出し」にユーザーに入力させたい項目名（例えば「お名前」、「住所」等）を入れてください。次に「入力データタイプ」でその入力欄はどういったデータとして入力させるのかを選択して下さい。尚、いつでもデフォルトの入力フィールドのセットに戻すことができます。',//'You can replace the existing profile fields with your own using the form below. First you give the new profile field a label, for example, \'Favourite team\'. Next you need to select the field type, for example, tags, url, text and so on. At any time you can revert back to the default profile set up.',


	/**
	 * Profile status messages
	 */

		'profile:saved' => "プロフィールは保存されました。",//"Your profile was successfully saved.",
		'profile:icon:uploaded' => "プロフィール用の画像はアップロードされました。",//"Your profile picture was successfully uploaded.",

	/**
	 * Profile error messages
	 */

		'profile:noaccess' => "プロフィールを編集する権限がありません。",//"You do not have permission to edit this profile.",
		'profile:notfound' => "申し訳ありません。そのプロフィールは見当たりません。",//Sorry, we could not find the specified profile.",
		'profile:icon:notfound' => "申し訳ありません。プロフィール用の画像をアップロードしている
際に何らかの問題が発生しました。",//"Sorry, there was a problem uploading your profile picture.",
		'profile:icon:noaccess' => 'このプロフィールアイコンは変更できません。',//'You cannot change this profile icon',
		'profile:field_too_long' => '"%s" に入力された内容が長すぎたため、プロフィールを保存でき
ませんでした。',//'Cannot save your profile information because the "%s" section is too long.',

	);

	add_translation("ja",$japanese);
?>
