<?php
	/**
	 * Email user validation plugin language pack.
	 * 
	 * @package ElggUserValidationByEmail
	 * @author Curverider Ltd
	 * @link http://elgg.com/
	 */

	$japanese = array(
	
		'email:validate:subject' => "%s Eメールアドレスの確認",//"%s please confirm your email address!",
		'email:validate:body' => "%sさん、こんにちは。

下記リンクをクリックしていただいた後、
あなたのEメールアドレスかどうかを承認します。

%s

",
/*
"Hi %s,

Please confirm your email address by clicking on the link below:

%s
",
*/
		'email:validate:success:subject' => "あなたのEメールアドレスが承認されました。",//"Email validated %s!",
		'email:validate:success:body' => "%s さん、こんにちは。

ありがとうございます！
あなたのEメールアドレスは承認されました。

",
/*
"Hi %s,
			
Congratulations, you have successfully validated your email address.",
*/	
		
		'email:confirm:success' => "Eメールアドレスは承認されました。",//"You have confirmed your email address!",
		'email:confirm:fail' => "Eメールアドレスが承認できません。",//"Your email address could not be verified...",
	
		'uservalidationbyemail:registerok' => "アカウントを有効にする前に、これから送信するメールにあるリンクをクリックしていただくことにより、Eメールアドレスがあなたのものであるかどうか確認します。",//"To activate your account, please confirm your email address by clicking on the link we just sent you."
	
	);
					
	add_translation("ja",$japanese);
?>
