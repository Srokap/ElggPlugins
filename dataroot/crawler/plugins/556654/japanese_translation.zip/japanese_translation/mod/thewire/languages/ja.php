<?php

	$japanese = array(
	
		/**
		 * Menu items and titles
		 */
	
			'thewire' => "ミニブログ",
			'thewire:user' => "%s の投稿",//"%s's wire",
			'thewire:posttitle' => "%s のミニブログ上のつぶやき: %s",//"%s's notes on the wire: %s",
			'thewire:everyone' => "みんなの投稿",//"All wire posts",
	
			'thewire:read' => "あなたの投稿",//"Wire posts",
			
			'thewire:strapline' => "%s",
	
			'thewire:add' => "ミニブログに投稿",//"Post to the wire",
		    'thewire:text' => "ミニブログの投稿",//"A note on the wire",
			'thewire:reply' => "返信",//"Reply",
			'thewire:via' => "経由",//"via",
			'thewire:wired' => "投稿されたwire",//"Posted to the wire",
			'thewire:charleft' => " 残り文字数",//"characters left",
			'item:object:thewire' => "ミニブログ",//"Wire posts",
			'thewire:notedeleted' => "削除",//"note deleted",
			'thewire:doing' => "いまどうしてる？",//"What are you doing? Tell everyone on the wire:",
			'thewire:newpost' => '新しい投稿',//'New wire post',
			'thewire:addpost' => 'ミニブログへの投稿',//'Post to the wire',

	
        /**
	     * The wire river
	     **/
	        
	        //generic terms to use
	        'thewire:river:created' => "%s 投稿",//"%s posted",
	        
	        //these get inserted into the river links to take the user to the entity
	        'thewire:river:create' => "ミニブログで",//"on the wire.",
	        
	    /**
	     * Wire widget
	     **/
	     
	        'thewire:sitedesc' => 'ミニブログに投稿された最新のノートを表示します。',//'This widget shows the latest site notes posted to the wire',
	        'thewire:yourdesc' => 'このウィジェットはミニブログに投稿されたあなたのノートを表示します。',//'This widget shows your latest notes posted to the wire',
	        'thewire:friendsdesc' => 'このウィジェットは友達のミニブログを表示します。',//'This widget will show the latest from your friends on the wire',
	        'thewire:friends' => '友達',//'Your friends on the wire',
	        'thewire:num' => '一覧表示数',//'Number of items to display',
	        
	        
	
		/**
		 * Status messages
		 */
	
			'thewire:posted' => "ミニブログに投稿しました。",//"Your message was successfully posted to the wire.",
			'thewire:deleted' => "ミニブログを削除しました。",//"Your wire post was successfully deleted.",
	
		/**
		 * Error messages
		 */
	
			'thewire:blank' => "申し訳ありません。入力欄が空のため、送信できません。",//"Sorry; you need to actually put something in the textbox before we can save it.",
			'thewire:notfound' => "申し訳ありません。そのwireは見つかりません。",//"Sorry; we could not find the specified wire post.",
			'thewire:notdeleted' => "申し訳ありません。そのwireを削除できませんでした。",//"Sorry; we could not delete this wire post.",
	
	
		/**
		 * Settings
		 */
			'thewire:smsnumber' => "Your SMS number if different from your mobile number (mobile number must be set to public for the wire to be able to use it). All phone numbers must be in international format.",
			'thewire:channelsms' => "The number to send SMS messages to is <b>%s</b>",
			
	);
					
	add_translation("ja",$japanese);

?>
