<?php

	$japanese = array(
	
			'custom:bookmarks' => "新着ブックマーク",//"Latest bookmarks",
			'custom:groups' => "新着グループ",//"Latest groups",
			'custom:files' => "新着ファイル",//"Latest files",
			'custom:blogs' => "新着ブログ記事",//"Latest blog posts",
			'custom:members' => "最近の参加メンバー",//"Newest members",
			'custom:nofiles' => "ファイルがありません。",//"There are no files yet",
			'custom:nogroups' => "ファイルがありません。",//"There are no files yet",	
	
	);
					
	add_translation("ja",$japanese);

?>
