<?php

	$japanese = array(
	
		/**
		 * Menu items and titles
		 */
	
		'tinymce:remove' => "WYSIWYG利用切替",//"Add/Remove editor",
	
	);
					
	add_translation("ja",$japanese);

?>
