<?php

	$japanese = array(
	
		/**
		 * Menu items and titles
		 */
	
			'expages' => "外部向け説明ページ",//"External pages",
			'expages:frontpage' => "フロントページ",//"Frontpage",
			'expages:about' => "このサイトについて",//"About",
			'expages:terms' => "利用条件",//"Terms",
			'expages:privacy' => "個人情報について",//"Privacy",
			'expages:analytics' => "Analytics",
			'expages:contact' => "お問い合わせ",//"Contact",
			'expages:nopreview' => "プレビューは利用できません。",//"No preview yet available",
			'expages:preview' => "プレビュー",//"Preview",
			'expages:notset' => "このページはまだ設置されていません。",//"This page has not been set up yet.",
			'expages:lefthand' => "左カラム",//"The lefthand information pane",
			'expages:righthand' => "右カラム",//"The righthand information pane",
			'expages:addcontent' => "管理ツールを使って、ここにコンテンツを追加す>ることができます。管理パネルの「外部向けページ」でお探し下さい",//"You can add content here via your admin tools. Look for the external pages link under admin.",
			'item:object:front' => 'フロントページアイテム',//'Front page items',
	
		/**
		 * Status messages
		 */
	
			'expages:posted' => "ページが作成されました。",//"Your page post was successfully posted.",
			'expages:deleted' => "ページが削除されました。",//"Your page post was successfully deleted.",
	
		/**
		 * Error messages
		 */
	
			'expages:deleteerror' => "古いページを削除する際に問題が発生しました。",//"There was a problem deleting the old page",
			'expages:error' => "何らかのエラーが発生しました。このまま続くようでしたら、管理者にご連絡ください。",//"There has been an error, please try again and if the problem persists, contact the administrator",
	
	);
					
	add_translation("ja",$japanese);

?>
