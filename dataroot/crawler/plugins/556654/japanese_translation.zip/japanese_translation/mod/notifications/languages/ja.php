<?php

	$japanese = array(
	
		'friends:all' => '全ての友達',//'All friends',
	
		'notifications:subscriptions:personal:description' => '自分のコンテンツについて何らかのアクションがあった場合、通知を受け取る。',//'Receive notifications when actions are performed on your content',
		'notifications:subscriptions:personal:title' => 'パーソナル通知',//'Personal notifications',
	
		'notifications:subscriptions:collections:title' => 'リストの切替',//'Toggle friends collections',
		'notifications:subscriptions:collections:description' => 'あなたの友達の所属ごとに通知の設定を変更することができます。'
			.'この設定は下のパネルに表示されるあなたの友達に関する通知に適応されます',
			//To toggle settings for members of your friends collections, 
			//use the icons below. This will affect the corresponding users in the main notification settings panel at the bottom of the page. ',
		'notifications:subscriptions:collections:edit' => 'リストの編集はこちら',//'To edit your friends collections, click here.',
	
		'notifications:subscriptions:changesettings' => '通知',//'Notifications',
		'notifications:subscriptions:changesettings:groups' => 'グループ通知',//'Group notifications',
		'notification:method:email' => 'Eメール',//'Email',	
	
		'notifications:subscriptions:title' => 'ユーザー単位の通知',//'Notifications per user',
		'notifications:subscriptions:description' => 'あなたの友達が新しいコンテンツを作った時に通知を受け取ります',
			//To receive notifications from your friends when they create new content,
			// find them below and select the notification method you would like to use.',
	
		'notifications:subscriptions:groups:description' => 'あなたが所属するグループに新しいコンテンツが作成されたら通知を受け取ることができます。'
			.'通知を受け取りたいグループにチェックを付けてください',
			//'To receive notifications when new content is added to a group you are a member of, find it below and select the notification method you would like to use.',
	
		'notifications:subscriptions:success' => '通知設定を保存しました。',//'Your notifications settings have been saved.',
	
	);
					
	add_translation("ja",$japanese);

?>
