<?php

	/**
	 * Elgg Shout-outs plugin
	 * 
	 * @package ElggShoutOuts
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider <info@elgg.com>
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.org/
	 */

	// shoutouts initialisation function
		function shoutouts_init() {
			
			// Grab the config file
				global $CONFIG;
			
			// Set up menu for logged in users
				if (isloggedin()){
					add_menu(elgg_echo('shoutouts'), $CONFIG->wwwroot . "pg/shoutouts/");	
			// And for logged out users
				} else {
					add_menu(elgg_echo('shoutouts'), $CONFIG->wwwroot . "pg/shoutouts/");
				}

			//add submenu options
				if (get_context() == "shoutouts") {
                                        add_submenu_item(elgg_echo('shoutouts:add'),$CONFIG->wwwroot."pg/shoutouts/" . $_SESSION['user']->username . "/add");
					add_submenu_item(elgg_echo('shoutouts:inbox'),$CONFIG->wwwroot."pg/shoutouts/" . $_SESSION['user']->username . "/inbox");
					add_submenu_item(elgg_echo('shoutouts:read'),$CONFIG->wwwroot."pg/shoutouts/" . $_SESSION['user']->username . "/items");
					add_submenu_item(elgg_echo('shoutouts:everyone'),$CONFIG->wwwroot."pg/shoutouts/everyone");
				}
				
			// Register a page handler, so we can have nice URLs
				register_page_handler('shoutouts','shoutouts_page_handler');
				
			// Add our CSS
				extend_view('css','shoutouts/css');
				
			// Register granular notification for this type
			if (is_callable('register_notification_object'))
				register_notification_object('object', 'shoutouts', elgg_echo('shoutouts:new'));

			// Listen to notification events and supply a more useful message
			   register_plugin_hook('notify:entity:message', 'object', 'shoutouts_notify_message');
                           
                        // Register a URL handler for shared items
                          register_entity_url_handler('shoutout_url','object','shoutouts');

			
				
			// Register entity type
				register_entity_type('object','shoutouts');
			    
		}
		
		/**
		 * shoutouts page handler; allows the use of fancy URLs
		 *
		 * @param array $page From the page_handler function
		 * @return true|false Depending on success
		 */
		function shoutouts_page_handler($page) {
			
			// The first component of a shoutouts URL is the username
			if (isset($page[0])) {
				set_input('username',$page[0]);
			}
			
			// The second part dictates what we're doing
			if (isset($page[1])) {
				switch($page[1]) {
					case "read":		set_input('guid',$page[2]);
										@include(dirname(dirname(dirname(__FILE__))) . "/entities/index.php"); return true;
										break;
					case "add":		@include(dirname(__FILE__) . "/add.php"); return true;
										break;
					case "inbox":		@include(dirname(__FILE__) . "/inbox.php"); return true;
										break;
					case "items":		@include(dirname(__FILE__) . "/index.php"); return true;
										break;
				}
			// If the URL is just 'shoutouts/username', or just 'shoutouts/', load the standard shoutouts index
			} else {
				@include(dirname(__FILE__) . "/everyone.php");
				return true;
			}
			
			return false;
			
		}

	/**
	 * Populates the ->getUrl() method for shoutout objects
	 *
	 * @param ElggEntity $entity The shoutout object
	 * @return string shoutout item URL
	 */
		function shoutout_url($entity) {
			
			global $CONFIG;
			$title = $entity->title;
			$title = friendly_title($title);
			return $CONFIG->url . "pg/shoutouts/" . $entity->getOwnerEntity()->username . "/read/" . $entity->getGUID() . "/" . $title;
			
		}
		
	    /**
		 * Returns a more meaningful message
		 *
		 * @param unknown_type $hook
		 * @param unknown_type $entity_type
		 * @param unknown_type $returnvalue
		 * @param unknown_type $params
	    */
		function shoutouts_notify_message($hook, $entity_type, $returnvalue, $params)
		{
			$entity = $params['entity'];
			$to_entity = $params['to_entity'];
			$method = $params['method'];
			if (($entity instanceof ElggEntity) && ($entity->getSubtype() == 'shoutouts'))
			{
				$descr = $entity->description;
				$title = $entity->title;
				global $CONFIG;
				$url = $CONFIG->wwwroot . "pg/view/" . $entity->guid;
				if ($method == 'sms') {
					$owner = $entity->getOwnerEntity();
					return $owner->username . ' ' . elgg_echo("shoutouts:via") . ': ' . $url . ' (' . $title . ')';
				}
				if ($method == 'email') {
					$owner = $entity->getOwnerEntity();
					return $owner->username . ' ' . elgg_echo("shoutouts:via") . ': ' . $title . "\n\n" . $descr . "\n\n" . $entity->getURL();
				}
				if ($method == 'web') {
					$owner = $entity->getOwnerEntity();
					return $owner->username . ' ' . elgg_echo("shoutouts:via") . ': ' . $title . "\n\n" . $descr . "\n\n" . $entity->getURL();
				}

			}
			return null;
		}

		
	// Make sure the initialisation function is called on initialisation
		register_elgg_event_handler('init','system','shoutouts_init');

	// Register actions
		global $CONFIG;
		register_action('shoutouts/add',false,$CONFIG->pluginspath . "shoutouts/actions/add.php");
		register_action('shoutouts/delete',false,$CONFIG->pluginspath . "shoutouts/actions/delete.php");
                register_action('shoutouts/appreciate',false,$CONFIG->pluginspath . "shoutouts/actions/appreciate.php");

?>