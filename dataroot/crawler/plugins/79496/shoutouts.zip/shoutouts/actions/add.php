<?php

	/**
	 * Elgg shoutouts add/save action
	 * 
	 * @package ElggShoutOuts
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Cina Saffary <info@elgg.com>
	 * @copyright 2009 Cina Saffary	 
	 */

		$guid = get_input('shoutout_guid',0);
		$title = get_input('title');
                $description = get_input('description');		
		$shoutees = get_input('shoutees',array());
                $appreciators = get_input('appreciators',array($_SESSION['user']->getGUID()));
                
       		$tags = get_input('tags');
		$tagarray = string_to_tag_array($tags);

				
		if ($guid == 0) {
			
			$entity = new ElggObject;
			$entity->subtype = "shoutouts";
			$entity->owner_guid = $_SESSION['user']->getGUID();
			
		} else {
			
			$canedit = false;
			if ($entity = get_entity($guid)) {
				if ($entity->canEdit()) {
					$canedit = true;
				}
			}
			if (!$canedit) {
				system_message(elgg_echo('notfound'));
				forward("pg/shoutouts");
			}
			
		}
		
		$entity->title = $title;
		$entity->description = $description;
       		$entity->tags = $tagarray;
		$entity->access_id = 2;
		
		if ($entity->save()) {
			$entity->clearRelationships();
			$entity->shoutees = $shoutees;
                        $entity->appreciators = $appreciators;
		
			if (is_array($shoutees) && sizeof($shoutees) > 0) {
				foreach($shoutees as $shoutee) {
					$shoutee = (int) $shoutee;
					add_entity_relationship($entity->getGUID(),'shoutee',$shoutee);
				}                                                                
			}
                        if (is_array($appreciators) && sizeof($appreciators) > 0) {
				foreach($appreciators as $appreciator) {
					$appreciator = (int) $appreciator;
					add_entity_relationship($entity->getGUID(),'appreciated_by',$appreciator);
				}
                        }
			system_message(elgg_echo('shoutouts:save:success'));
			//add to river
			add_to_river('river/object/shoutouts/create','create',$_SESSION['user']->guid,$entity->guid); 
                        
			forward($entity->getURL());
		} else {
			register_error(elgg_echo('shoutouts:save:failed'));
			forward("pg/shoutouts");
		}

?>