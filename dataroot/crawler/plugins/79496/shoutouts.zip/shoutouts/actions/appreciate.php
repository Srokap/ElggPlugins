<?php

	/**
	 * Elgg shoutouts appreciate action
	 * 
	 * @package ElggShoutOuts
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Cina Saffary <info@elgg.com>
	 * @copyright 2009 Cina Saffary	 
	 */
		$guid = get_input('shoutout_guid');
                if ($entity = get_entity($guid)) {
                  $user = $_SESSION['user']->getGUID();
                  $appreciators = (array)$entity->appreciators;
                  $key = array_search($user, $appreciators);
                  if ($key !== false) {
                      unset($appreciators[$key]);
                      remove_entity_relationship($guid,'appreciated_by',$user);
                  }
                  else {
                    $appreciators[] = $user;
                    add_entity_relationship($guid,'appreciated_by',$user);
                  }
                  
                  $entity->appreciators = $appreciators;

                  if ($entity->save()) {                        
                          forward("pg/shoutouts/");
                  }
                  else {
                          register_error(elgg_echo('shoutouts:save:failed'));
                          forward("pg/shoutouts/");
                  }                  
                }
                else {
                          register_error(elgg_echo('shoutouts:save:failed'));
                          forward("pg/shoutouts/");
                }


?>