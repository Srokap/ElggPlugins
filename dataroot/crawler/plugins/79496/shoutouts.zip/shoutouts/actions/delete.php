<?php

	/**
	 * Elgg shoutouts delete action
	 * 
	 * @package ElggShoutOuts
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Cina Saffary
	 * @link http://elgg.org/
	 */

		$guid = get_input('shoutout_guid',0);
		if ($entity = get_entity($guid)) {
			
			if ($entity->canEdit()) {
				
				if ($entity->delete()) {
					
					system_message(elgg_echo("shoutouts:delete:success"));
					forward("pg/shoutouts/");					
					
				}
				
			}
			
		}
		
		register_error(elgg_echo("shoutouts:delete:failed"));
		forward("pg/shoutouts/");

?>