<?php

	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'shoutouts' => "Shout-outs",
			'shoutouts:add' => "Make a shout-out",
                        'shoutouts:shoutout' => "shout-out",
			'shoutouts:read' => "Your shout-outs",
			'shoutouts:everyone' => "All shout-outs",
			'shoutouts:inbox' => "Shout-outs to you",
			'shoutouts:more' => "More",
			'shoutouts:shareditem' => "Shout-out",
			'shoutouts:new' => "A new shout-out",
	
			'shoutouts:delete:confirm' => "Are you sure you want to delete this shout-out?",
	
			'shoutouts:numbertodisplay' => 'Number of shout-outs to display',
	
			'shoutouts:shared' => "Made a shout-out to",
                        'shoutouts:with' => "Shout-out to:",
                        
			'shoutouts:recent' => "Recent shout-outs",
	
			'shoutouts:river:created' => '%s made a shout-out',
			'shoutouts:river:annotate' => 'a comment on this shout-out: ',
			'shoutouts:river:item' => 'an item',
	
			'item:object:shoutouts' => 'Shout-outs',
	
	
	
		/**
		 * Status messages
		 */
	
			'shoutouts:save:success' => "Your shout-out was heard far and wide.",
			'shoutouts:delete:success' => "Your shout-out was successfully deleted.",
	
		/**
		 * Error messages
		 */
	
			'shoutouts:save:failed' => "Your shout-out could not be saved. Please try again.",
			'shoutouts:delete:failed' => "Your shout-out could not be deleted. Please try again.",
	
	
	);
					
	add_translation("en",$english);

?>