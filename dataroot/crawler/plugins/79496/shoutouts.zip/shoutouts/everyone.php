<?php

	/**
	 * Elgg shout-outs plugin everyone page
	 * 
	 * @package ElggShoutOuts
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Cina Saffary
	 * @copyright Cina Saffary 2009
	 * @link http://elgg.org/
	 */

	// Start engine
		require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
		
	// Get the current page's owner
		$page_owner = page_owner_entity();
		if ($page_owner === false || is_null($page_owner)) {
			$page_owner = $_SESSION['user'];
			set_page_owner($_SESSION['guid']);
		}
	//get filter
		$limit = get_input('limit', 20);
		$offset = get_input('offset', 0);
		$filter = get_input("filter");
		if(!$filter)
			$filter = "new";

	// List shoutouts
		$area2 = elgg_view_title(elgg_echo('shoutouts:everyone'));
              

set_context('search');

	//get the correct view based on filter
		switch($filter){
			case "new":
			$content .= list_entities("object","shoutouts",0,10,false);
			break;
			case "app":
			$content .= list_entities_by_relationship_count('appreciated_by', false, 'object', 'shoutouts');
			break;    
			case 'default':
			$content .= list_entities("user","",0,10,false);
			break; 
                        }
                      
                        
                $area2 .= elgg_view('page_elements/contentwrapper',array('body' => elgg_view("shoutouts/shoutouts_sort_menu", array("filter" => $filter, "currentpage" => "everyone")) . $content, 'subclass' => 'shoutouts'));
 
                
		set_context('shoutouts');
		
	// Format page
		$body = elgg_view_layout('two_column_left_sidebar', $area1, $area2);
		
	// Draw it
		echo page_draw(elgg_echo('shoutouts:everyone'),$body);

?>