<?php

	/**
	 * A simple view to provide the user with group filters and the number of group on the site
	 **/
	 
	 $members = $vars['count'];
	 if(!$num_groups)
	 	$num_groups = 0;
	 	
	 $filter = $vars['filter'];
         $currentpage = $vars['currentpage'];         
	 
	 //url
	 $url = $vars['url'] . "pg/shoutouts/{$currentpage}";

?>
<div id="elgg_horizontal_tabbed_nav">
<ul>
	<li <?php if($filter == "new") echo "class='selected'"; ?>><a href="<?php echo $url; ?>?filter=new">Newest</a></li>
	<li <?php if($filter == "app") echo "class='selected'"; ?>><a href="<?php echo $url; ?>?filter=app">Most Appreciated</a></li>
</ul>
</div>
<br />