<?php

	$performed_by = get_entity($vars['item']->subject_guid); // $statement->getSubject();
	$object = get_entity($vars['item']->object_guid);
	$url = $object->getURL();
	
	$url = "<a href=\"{$performed_by->getURL()}\">{$performed_by->name}</a>";
	$string = sprintf(elgg_echo("shoutouts:river:created"),$url);
        
        $shoutees = (array)$object->shoutees;        
        $count = count($shoutees);
        if( $count > 0 ) {
          $string .= " to ";
           if( $count == 1) {
            $s0 = get_entity($shoutees[0]);
            $string .= "<a href=\"{$s0->getURL()}\">{$s0->name}</a>"; }
          else if ($count == 2) {
            $s0 = get_entity($shoutees[0]);
            $s1 = get_entity($shoutees[1]);
            $string .= "<a href=\"{$s0->getURL()}\">{$s0->name}</a> and <a href=\"{$s1->getURL()}\">{$s1->name}</a>"; }
          else if ($count == 3){
            $s0 = get_entity($shoutees[0]);
            $s1 = get_entity($shoutees[1]);
            $s2 = get_entity($shoutees[2]);
            $string .= "<a href=\"{$s0->getURL()}\">{$s0->name}</a>, <a href=\"{$s1->getURL()}\">{$s1->name}</a>, and <a href=\"{$s2->getURL()}\">{$s2->name}</a>";}
          else if ($count > 3){
            $s0 = get_entity($shoutees[0]);          
            $string .= "<a href=\"{$s0->getURL()}\">{$s0->name}</a> and <a href=\"{$object->getURL()}\">" . ($count - 1) . " others</a>";
           } 
        }     
        
        $string .= ": ";
	$string .= "<a href=\"" . $object->getURL() . "\">" . $object->title . "</a>"; //elgg_echo("shoutouts:river:item") . "</a>";
	
?>

<?php 
	echo $string;
?>