<?php

	/**
	 * Elgg shoutout view
	 * 
	 * @package ElggShoutOuts
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Cina Saffary
	 * @copyright Cina Saffary 2009	 
	 */

?>
                <script type="text/javascript">
                
                function showList(guid) {
                  list = document.getElementById("appreciators_list_" + guid);
                  //alert("appreciators_list_" + guid);

                  var showing = list.style.display;

                  if(showing == "inline") {
                    list.style.display = "none";
                  }
                  else {
                    list.style.display = "inline"; 
                  }
                }
              </script>
<?php


	$owner = $vars['entity']->getOwnerEntity();
	$friendlytime = friendly_time($vars['entity']->time_created);

	if (get_context() == "search") {

		if (get_input('search_viewtype') == "gallery") {

			$parsed_url = parse_url($vars['entity']->address);
			$faviconurl = $parsed_url['scheme'] . "://" . $parsed_url['host'] . "/favicon.ico";
		
			$info = "<p class=\"shares_gallery_title\">". elgg_echo("shoutouts:shared") .": <a href=\"{$vars['entity']->getURL()}\">{$vars['entity']->title}</a> (<a href=\"{$vars['entity']->address}\">".elgg_echo('shoutouts:visit')."</a>)</p>";
			$info .= "<p class=\"shares_gallery_user\">By: <a href=\"{$vars['url']}pg/shoutouts/{$owner->username}\">{$owner->name}</a> <span class=\"shared_timestamp\">{$friendlytime}</span></p>";
			$numcomments = elgg_count_comments($vars['entity']);
			if ($numcomments)
				$info .= "<p class=\"shares_gallery_comments\"><a href=\"{$vars['entity']->getURL()}\">".sprintf(elgg_echo("comments")). " (" . $numcomments . ")</a></p>";
			
			//display 
			echo "<div class=\"share_gallery_view\">";
			echo "<div class=\"share_gallery_info\">" . $info . "</div>";
			echo "</div>";


		} else {
				$icon = elgg_view(				"profile/icon", array(
										'entity' => $owner,
										'size' => 'small',));
                        
                        if ( isloggedin() && $owner != $vars['user']){
                        $info = "<div style=\"float:right;\"><form action=\"{$vars['url']}action/shoutouts/appreciate\" method=\"post\"><input type=\"hidden\" name=\"shoutout_guid\" value=\"{$vars['entity']->getGUID()}\"><input class=\"submit_button\" value=\"";
                        
                        if(in_array($_SESSION['user']->guid, (array)$vars['entity']->appreciators))
                          $info .= "Una";
                        else $info .= "A";
                        $info .= "ppreciate\" type=\"submit\"></form></div>";
                        }
                        
			$info .= "<p class='shares_gallery_subjects'><b><a href=\"{$vars['url']}pg/profile/{$owner->username}\">{$owner->name}</a></b> <img src=\"{$vars['url']}mod/shoutouts/graphics/arrow.gif\"/> ";

                        $shoutees = $vars['entity']->shoutees;
                        if (is_string($shoutees))
                          $info .= "<a href=\"{$vars['url']}pg/profile/" . get_entity($shoutees)->username. "\">" . get_entity($shoutees)->name ."</a></p>";
                        if (is_array($shoutees) && count($shoutees) > 0 ){
                          $last_shoutee = array_pop($shoutees);
                            foreach($shoutees as $shoutee){
                              $s_entity = get_entity($shoutee);
                              $info .= "<a href=\"{$vars['url']}pg/profile/{$s_entity->username}\">{$s_entity->name}</a>, "; }
                            $info .= "and ";
                          }
                          $s_entity = get_entity($last_shoutee);
                          $info .= "<a href=\"{$vars['url']}pg/profile/{$s_entity->username}\">{$s_entity->name}</a></p>";
                        
                        $info .= "<p class=\"shares_gallery_title\"><a href=\"{$vars['entity']->getURL()}\">{$vars['entity']->title}</a></p>";
			$info .= "<p class=\"shares_gallery_time\">Made {$friendlytime}";
                       
			$numcomments = elgg_count_comments($vars['entity']);
			if ($numcomments)
				$info .= ", <a href=\"{$vars['entity']->getURL()}\">".sprintf(elgg_echo("comments")). " (" . $numcomments . ")</a>";
                        $numappreciators = count($vars['entity']->appreciators);
                        if ($numappreciators > 1)
                          $info .= ", <a href=\"javascript:showList({$vars['entity']->getGUID()});\">{$numappreciators} people</a> appreciate this";
                    $info .= "</p>"; 
                    $info .= "<div class=\"appreciators_list\"><p id=\"appreciators_list_{$vars['entity']->getGUID()}\">";
                    
                    $appreciators = (array)$vars['entity']->appreciators;
                    $last_app = array_pop($appreciators);
                    foreach($appreciators as $app) {
                      $s_entity = get_entity($app);
                      $info .= "<a href=\"{$vars['url']}pg/profile/{$s_entity->username}\">{$s_entity->name}</a>, ";
                    }
                    $s_entity = get_entity($last_app);
                    $info .= "and <a href=\"{$vars['url']}pg/profile/{$s_entity->username}\">{$s_entity->name}</a>";
                  
                    //$info .= "[!!!]";
                    
                    $info .= "</p></div>";


			echo elgg_view_listing($icon, $info);

		}
		
	} else {

?>
	<?php echo elgg_view_title(elgg_echo('shoutouts:shareditem'), false); ?>
	<div class="contentWrapper">
	<div class="sharing_item">
	
		<div class="sharing_item_title">
			<h3>
                        <a href="<?php echo $vars['entity']->getURL(); ?>"><?php echo $vars['entity']->title; ?></a> 
			</h3>
                        <p class="shares_gallery_time"><?php echo $friendlytime; ?></p>
		</div>
		<div class="sharing_item_owner">
                <?php
			$info = "<p><a href=\"{$vars['url']}pg/profile/{$owner->username}\">{$owner->name}</a> <img src=\"{$vars['url']}mod/shoutouts/graphics/arrow.gif\"/> <b>";

                        $shoutees = $vars['entity']->shoutees;
                        if (is_string($shoutees))
                          $info .= "<a href=\"{$vars['url']}pg/profile/" . get_entity($shoutees)->username. "\">" . get_entity($shoutees)->name ."</a></p>";
                        if (is_array($shoutees) && count($shoutees) > 0 ){
                          $last_shoutee = array_pop($shoutees);
                            foreach($shoutees as $shoutee){
                              $s_entity = get_entity($shoutee);
                              $info .= "<a href=\"{$vars['url']}pg/profile/{$s_entity->username}\">{$s_entity->name}</a>, "; }
                            $info .= "and ";
                          }
                          $s_entity = get_entity($last_shoutee);
                          $info .= "<a href=\"{$vars['url']}pg/profile/{$s_entity->username}\">{$s_entity->name}</a></b></p>";
                          echo $info; ?>

		</div>
		<div class="sharing_item_description">
				<?php echo autop($vars['entity']->description); ?>
		</div>
<?php

	$tags = $vars['entity']->tags;
	if (!empty($tags)) {

?>
		<div class="sharing_item_tags">
			<p>
				<?php echo elgg_view('output/tags',array('value' => $vars['entity']->tags)); ?>
			</p>
		</div>
<?php

	}

?>
		<div class="sharing_item_address">
			<p>
				<?php 

					//echo elgg_view('output/url',array('value' => $vars['entity']->address));
                                        
                        if ( isloggedin() && $owner != $vars['user']){
                        $html = "<form action=\"{$vars['url']}action/shoutouts/appreciate\" method=\"post\"><input type=\"hidden\" name=\"shoutout_guid\" value=\"{$vars['entity']->getGUID()}\"><input class=\"submit_button\" value=\"";
                        
                        if(in_array($_SESSION['user']->guid, (array)$vars['entity']->appreciators))
                          $html .= "Una";
                        else $html .= "A";
                        $html .= "ppreciate\" type=\"submit\"></form>";
                        }
			echo $html	?>
			<?php	/* <a href="<?php echo $vars['entity']->address; ?>"><?php echo elgg_echo('shoutouts:visit'); ?></a> */ ?>
			</p>
		</div>		
		<?php

			if ($vars['entity']->canEdit()) {
		
		?>
                

                
                <?php

                $numappreciators = count($vars['entity']->appreciators);
                $info = "";
                    if ($numappreciators > 1)
                      $info = "<span class=\"shares_gallery_time\"><a href=\"javascript:showList({$vars['entity']->getGUID()});\">{$numappreciators} people</a> appreciate this";
                    $info .= "</span>"; 
                    $info .= "<div class=\"appreciators_list\"><p id=\"appreciators_list_{$vars['entity']->getGUID()}\">";
                    
                    $appreciators = (array)$vars['entity']->appreciators;
                    $last_app = array_pop($appreciators);
                    foreach($appreciators as $app) {
                      $s_entity = get_entity($app);
                      $info .= "<a href=\"{$vars['url']}pg/profile/{$s_entity->username}\">{$s_entity->name}</a>, ";
                    }
                    $s_entity = get_entity($last_app);
                    $info .= "and <a href=\"{$vars['url']}pg/profile/{$s_entity->username}\">{$s_entity->name}</a>";
                                      
                    $info .= "</p></div>";
                    
                    echo $info;
                ?>

                
		<div class="sharing_item_controls">
			<p>
				<a href="<?php echo $vars['url']; ?>mod/shoutouts/add.php?shoutout=<?php echo $vars['entity']->getGUID(); ?>"><?php echo elgg_echo('edit'); ?></a> &nbsp; 
				<?php 
						echo elgg_view('output/confirmlink',array(
						
							'href' => $vars['url'] . "action/shoutouts/delete?shoutout_guid=" . $vars['entity']->getGUID(),
							'text' => elgg_echo("delete"),
							'confirm' => elgg_echo("shoutouts:delete:confirm"),
						
						));  
					?>
			</p>
		</div>
		<?php

			}
		
		?>
	
	</div>
	</div>
<?php

	if ($vars['full'])
		echo elgg_view_comments($vars['entity']);

?>
	
<?php

	}

?>