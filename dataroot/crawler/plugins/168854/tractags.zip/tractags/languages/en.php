<?php

	$english = array(
	
		'tractags:baseurl' => 'Please enter the location of your trac repository',
			
	);
					
	add_translation("en",$english);

?>