<?php
	$trac_baseurl = $vars['entity']->trac_baseurl;
	if (!$trac_baseurl)
		$trac_baseurl = "https://trac.elgg.org/elgg/";

?>
<p>
	<?php echo elgg_echo('tractags:baseurl'); ?>
	<?php
		echo elgg_view('input/url', array(
			'internalname' => 'params[trac_baseurl]',
			
			'value' => $trac_baseurl
		));
	?>
	
</p>