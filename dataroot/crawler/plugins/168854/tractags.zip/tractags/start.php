<?php
	/**
	 * Trac tags for elgg.
	 * This is a simple mod which will map issue numbers (#xxxx) and changesets number [xxxx] to a ticket 
	 * or changeset which appear in a blog post or wire posting to a trac repo.
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Marcus Povey <marcus@dushka.co.uk>
	 * @copyright Marcus Povey 2009
	 * @link http://www.marcus-povey.co.uk/
	 */

	function tractags_init()
	{
		global $CONFIG;
		
		// Register our post processing hook
		register_plugin_hook('display', 'view', 'tractags_rewrite');
		
		// define views we want to rewrite codes on (means we don't have to process *everything*)
		$CONFIG->tractags_views = array(
			'object/thewire',
			'object/blog'
		);
		 
		// Get the base path
		$CONFIG->trac_baseurl = get_plugin_setting('trac_baseurl', 'tractags');
		
		if (!$CONFIG->trac_baseurl)
			$CONFIG->trac_baseurl = "https://trac.elgg.org/elgg/";
			
		// Sanitise path
		$CONFIG->trac_baseurl = trim($CONFIG->trac_baseurl,' /');
		$CONFIG->trac_baseurl .= "/";
	}
	
	function tractags_rewrite($hook, $entity_type, $returnvalue, $params)
	{
		global $CONFIG;
		
		$view = $params['view'];
		
		if (($view) && (in_array($view, $CONFIG->tractags_views)))
		{
			// Search and replace ticket numbers
			$returnvalue =  preg_replace_callback('/(#)([0-9]+)/i', 
		       	create_function(
		            '$matches',
		            '
		       			global $CONFIG; 
		       			
		       			return "<a href=\"{$CONFIG->trac_baseurl}ticket/{$matches[2]}\">{$matches[0]}</a>";
		       		'
		    ), $returnvalue);
			
		    // Search and replace changesets
		    $returnvalue =  preg_replace_callback('/(\[)([0-9]+)(\])/i', 
		       	create_function(
		            '$matches',
		            '
		       			global $CONFIG; 
		       			
		       			return "<a href=\"{$CONFIG->trac_baseurl}changeset/{$matches[2]}\">{$matches[0]}</a>";
		       		'
		    ), $returnvalue);
		    
		    return $returnvalue;
		}
	}
	
	register_elgg_event_handler('init','system','tractags_init');
?>