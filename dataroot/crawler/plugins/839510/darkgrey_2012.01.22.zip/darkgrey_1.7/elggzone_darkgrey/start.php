<?php
 
function elggzone_darkgrey_init() {
	global $CONFIG;		
		
}
register_elgg_event_handler('init','system','elggzone_darkgrey_init');

?>