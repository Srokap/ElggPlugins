<?php

	/**
	 * Elgg Messageboard CSS extender 
	 * 
	 * @package ElggMessageBoard
	 */

?>

/* input msg area */
#mb_input_wrapper {
	margin:0 0 5px 0px;
	padding:5px 0 5px 0;
}

#mb_input_wrapper .input_textarea {
	width:665px;
}
.collapsable_box_content #mb_input_wrapper .input_textarea {
	width:270px;
}
.message_item_timestamp acronym{
	font-size:88%;
	color:#788A9A;
	padding:10px 0 0 0;
}
.message_item_timestamp {
	font-size:90%;
	padding:10px 0 0 0;
}
p.message_item_timestamp {
	margin-bottom: 10px;
}
/* wraps each message */
.messageboard {
	margin:0 0 5px 0;
	padding:0;
	border-bottom: 1px solid #59626D;
}
.messageboard .message_sender {
	float:left;
	margin: 5px 10px 0 0;
}
/* IE6 */
* html .messageboard { width: 280px; } 
* html #two_column_left_sidebar_maincontent .messageboard { width: 667px; }
* html .messageboard .message_sender { margin: 5px 10px 0 2px; }
* html #mb_input_wrapper .input_textarea { width:645px; }
/* IE7 */
*:first-child+html .messageboard { width: 280px; } 
*:first-child+html #two_column_left_sidebar_maincontent .messageboard { width: 698px; }
*:first-child+html .messageboard .message_sender { margin: 5px 10px 0 2px; }

.messageboard .message p {
	line-height: 1.2em;
	margin:0 0 4px 0;
	padding:4px 0 4px 0;
	overflow-y:hidden;
	overflow-x:auto;
	color:#d2d8de;
}

.message_buttons {
	padding:0 0 3px 0;
	margin:0;
	font-size: 90%;
	color:#666666;
}

.messageboard .delete_message a {
	display:block;
	float:right;
	cursor: pointer;
	width:14px;
	height:14px;
	margin:0 3px 3px 0;
	background: url("<?php echo $vars['url']; ?>_graphics/icon_customise_remove.png") no-repeat 0 0;
	text-indent: -9000px;
}
.messageboard .delete_message a:hover {
	background-position: 0 -16px;
}





