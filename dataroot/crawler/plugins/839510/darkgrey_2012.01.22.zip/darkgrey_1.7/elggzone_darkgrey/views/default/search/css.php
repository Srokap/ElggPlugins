.searchtype {
background: #FFFACD;
color: black;
}

.searchtypes {
border: 1px #EEEEEE solid;
padding: 4px;
margin: 6px;
}

.searchListing {
	display: block;
	margin-bottom: 2em;
}

.searchMatch {
    background: url(<?php echo $vars['url']; ?>mod/elggzone_darkgrey/graphics/gradients/bgyellow40.png) repeat;
}

.searchMatchColor1 {
    background: url(<?php echo $vars['url']; ?>mod/elggzone_darkgrey/graphics/gradients/bgyellow40.png) repeat;
}

.searchMatchColor2 {
    background: url(<?php echo $vars['url']; ?>mod/elggzone_darkgrey/graphics/gradients/bglime40.png) repeat;
}

.searchMatchColor3 {
    background: url(<?php echo $vars['url']; ?>mod/elggzone_darkgrey/graphics/gradients/bgpink40.png) repeat;
}

.searchMatchColor4 {
    background: url(<?php echo $vars['url']; ?>mod/elggzone_darkgrey/graphics/gradients/bgpurple40.png) repeat;
}

.searchMatchColor5 {
    background: url(<?php echo $vars['url']; ?>mod/elggzone_darkgrey/graphics/gradients/bggreenlight40.png) repeat;
}

.searchTitle {
	text-decoration: underline;
}

#searchform input.search_input {
	font-family:Arial, Helvetica, sans-serif;
	background-color:#939BA5;
	border:1px solid #59626D;
	color:#59626D;
	font-size:12px;
	margin:0;
	width:180px;
	height:16px;
}
#searchform input.search_submit_button {
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #ffffff;
	background:#79828F;
	height: 26px;
	margin:0;
    padding:0 6px 2px 6px;
    border:none;
	cursor: pointer;
    width: auto;
}
#searchform input.search_submit_button:hover {
	color:#ffffff;
	background: #939BA5;
}
#searchform input.search_input:focus {
	background-color:#FFFFFF;
	border:1px solid #59626D;
	color:#363B42;
}
.search_listing {
	display: block;
	border-bottom: 1px solid #59626D;
	margin:0 0 5px 0;
	padding:10px 0 5px 0;
}

.entity_gallery_item .search_listing {
	background: none;
	text-align: center;
}

/* override the entity container piece */
.search_listing .search_listing {
	background: transparent;
	margin: 0;
	padding: 0;
}

/* formatting for the search results */

.search_listing .item_timestamp {
	font-size:88%;
	color:#788A9A;
}
