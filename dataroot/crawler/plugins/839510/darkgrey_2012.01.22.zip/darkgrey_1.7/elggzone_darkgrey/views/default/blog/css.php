<?php

	/**
	 * Elgg blog CSS extender
	 * 
	 * @package ElggBlog
	 */

?>
#blogPostForm{
	margin-top:10px;
}
#blogs .pagination {
	margin:5px 10px 0 10px;
	padding:5px;
	display:block;
}
#blogs #two_column_left_sidebar_maincontent {
	padding-bottom:10px;
}

.singleview {
	margin-top:10px;
}

.blog_post_icon {
	float:left;
	margin:3px 10px 0 0;
	padding:0;
}

.blog_post h3 {
	font-size: 150%;
	margin:0 0 10px 0;
	padding:0;
}

.blog_post h3 a {
	text-decoration: none;
}

.blog_post p {
	margin: 0 0 5px 0;
}

.blog_post .strapline {
	margin: 0 0 0 35px;
	padding:0;
	color: #d2d8de;
	line-height:1em;
}

.blog_post p.categories a{
	padding: 0;
    text-transform:capitalize;
}

.blog_post p.tags {
    background: url(<?php echo $vars['url']; ?>mod/elggzone_darkgrey/graphics/icons/icon_tag.png) no-repeat scroll left 2px;
	margin:0 0 7px 35px;
	padding:0 0 0 20px;
	min-height:22px;
}
.blog_post .options {
	margin:0;
	padding:0;
}
.blog_post_body{
	margin: 10px 0 0 0;
}
.blog_post_body img[align="left"] {
	margin: 10px 10px 10px 0;
	float:left;
}
.blog_post_body img[align="right"] {
	margin: 10px 0 10px 10px;
	float:right;
}
.blog_post_body img {
	margin: 10px !important;
}

.blog-comments h3 {
	font-size: 150%;
	margin-bottom: 10px;
}
.blog-comment {
	margin-top: 10px;
	margin-bottom:20px;
	border-bottom: 1px solid #59626D;
}
.blog-comment img {
	float:left;
	margin: 0 10px 0 0;
}
.blog-comment-menu {
	margin:0;
}
.blog-comment-byline {
	background: #dddddd;
	height:22px;
	padding-top:3px;
	margin:0;
}
.blog-comment-text {
	margin:5px 0 5px 0;
}

/* New blog edit column */
#blog_edit_page {
	/* background: #bbdaf7; */
	margin-top:-10px;
}
#blog_edit_page #content_area_user_title h2 {
	background: none;
	border-top: none;
	margin:0 0 10px 0px;
	padding:0px 0 0 0;
}
#blog_edit_page #blog_edit_sidebar #content_area_user_title h2 {
	background:none;
	border-top:none;
	margin:inherit;
	padding:10px 0 5px 11px;
	font-size:1.0em;
	line-height:1.2em;
}
#blog_edit_page #blog_edit_sidebar {
	margin:0px 0 22px 0;
	padding:5px;
    background: url(<?php echo $vars['url']; ?>mod/elggzone_darkgrey/graphics/gradients/bg40.png) repeat;
}
#blog_edit_page #two_column_left_sidebar_210 {
	width:210px;
	margin:0px 0 20px 0px;
	min-height:360px;
	float:left;
	padding:0;
}
#blog_edit_page #two_column_left_sidebar_maincontent {
	margin:0 0px 20px 20px;
	padding:10px 20px 20px 20px;
	width:670px;
    background: url(<?php echo $vars['url']; ?>mod/elggzone_darkgrey/graphics/gradients/bg40.png) repeat;
}
/* unsaved blog post preview */
.blog_previewpane {
    background: url(<?php echo $vars['url']; ?>mod/elggzone_darkgrey/graphics/gradients/bgred40.png) repeat;
	padding:10px;
	margin:20px 0 20px 0;
}
.blog_previewpane p {
	margin:0;
}

#blog_edit_sidebar .publish_controls,
#blog_edit_sidebar .blog_access,
#blog_edit_sidebar .publish_options,
#blog_edit_sidebar .publish_blog,
#blog_edit_sidebar .allow_comments,
#blog_edit_sidebar .categories {
	margin:0 11px 5px 11px;

}

.blog_categories .categories{
	padding-left:2px;
}

#blog_edit_page ul {
	padding-left:0px;
	margin:5px 0 5px 0;
	list-style: none;
}
#blog_edit_page p {
	margin:5px 0 5px 0;
}
#blog_edit_page #two_column_left_sidebar_maincontent p {
	margin:0 0 15px 0;
}
#blog_edit_page .publish_blog input[type="submit"] {
	font-weight: bold;
	padding: 4px 6px 5px 6px;
	height:auto;
}
        
#blog_edit_page .preview_button a {
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	background:#79828F;
	color:#FFF;
	width: auto;
	height: 16px;
	padding: 7px 6px 3px 6px;
	margin:11px 6px 5px 16px;
	cursor: pointer;
	float:right;
}
#blog_edit_page .preview_button a:hover {
	background:#939BA5;
	color:#FFF;
	text-decoration: none;

}
#blog_edit_page .allow_comments label {
	font-size: 100%;
    margin-left:-4px;
    font-weight:normal;
}






