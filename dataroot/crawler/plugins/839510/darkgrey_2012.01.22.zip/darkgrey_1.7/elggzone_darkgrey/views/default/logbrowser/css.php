<?php

	/**
	 * Elgg logbrowser CSS
	 * 
	 * @package logbrowser
	 */

?>

#logbrowserSearchform {
	padding: 0;
}

.log_entry {
	width: 676px;
	font-size: 80%;
	margin:0;
    padding:5px 0 5px 0;
	border-bottom:1px solid #CCECFA;
}
.log_entry td {
}

.log_entry_user {
	width: 120px;
}

.log_entry_time {
	width: 210px;
	padding:2px;
}

.log_entry_item {
	
}

.log_entry_action {
	width: 75px;
}