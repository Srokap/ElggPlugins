<?php
/**
 * Elgg forgotten password.
 *
 * @package Elgg
 * @subpackage Core
 */

$form_body .= "<p><label>". elgg_echo('username') . "<br />" . elgg_view('input/text', array('internalname' => 'username')) . "</label></p>";
$form_body .= elgg_view('input/captcha');
$form_body .= "<p>" . elgg_view('input/submit', array('value' => elgg_echo('request'))) . "</p>";

?>
<div id="register-right">
<div><?php echo elgg_echo('user:password:text'); ?></div>
</div>

<div id="register-box" class="lost-box">

<?php
echo elgg_view('input/form', array(
	'action' => "{$vars['url']}action/user/requestnewpassword",
	'body' => $form_body)
);
?>
</div>