<?php

	/**
	 * Elgg embed CSS - standard across all themes
	 * 
	 * @package embed
	 */

?>

#facebox {
	position: absolute;
	top: 0;
	left: 0;
	z-index: 10000;
	text-align: left;
}

#facebox .popup {
	position: relative;
}
#facebox .body {
	padding:16px 20px 16px 20px;
    background: #3E4246;
    border: 1px solid #59626D;
	width: 720px;
}
#facebox .loading {
	text-align: center;
	padding: 100px 10px 100px 10px;
}
#facebox .image {
	text-align: center;
}
#facebox .footer {
	float: right;
	width:22px;
	height:18px;
	margin:0;
	padding:0;
    overflow:hidden;
}
#facebox .footer img.close_image {
	background: url(<?php echo $vars['url']; ?>mod/embed/images/close_button.gif) no-repeat left top;
}
#facebox .footer img.close_image:hover {
	background: url(<?php echo $vars['url']; ?>mod/embed/images/close_button.gif) no-repeat left -31px;
}
#facebox .footer a {
	-moz-outline: none;
	outline: none;
}
#facebox_overlay {
	position: fixed;
	top: 0px;
	left: 0px;
	height:100%;
	width:100%;
}
.facebox_hide {
	z-index:-100;
}
.facebox_overlayBG {
	background-color: #000000;
	z-index: 9999;
}

* html #facebox_overlay { /* ie6 hack */
	position: absolute;
	height: expression(document.body.scrollHeight > document.body.offsetHeight ? document.body.scrollHeight : document.body.offsetHeight + 'px');
}

/* EMBED MEDIA TABS */

#embed_media_tabs {
	margin:10px 0 0 5px;
	padding:0;    
}
#embed_media_tabs ul {
	list-style: none;
    line-height:25px;
	padding: 0;
}
#embed_media_tabs ul li {
	float: left;
	margin:0;
}
#embed_media_tabs ul li a {
	font-size:1.0em;
	text-align: center;
	text-decoration: none;
	color:#d2d8de;
	display: block;
	padding: 0 10px 0 10px;
	margin:0 0 0 10px;
	height:25px;
	width:auto;
    background:#59626D;
	border-top:1px solid #59626D;
	border-left:1px solid #59626D;
	border-right:1px solid #59626D;  
	-moz-border-radius-topleft: 4px;
	-moz-border-radius-topright: 4px;
	-webkit-border-top-left-radius: 4px;
	-webkit-border-top-right-radius: 4px;
}
/* IE6 fix */
* html #embed_media_tabs ul li a { display: inline; }

#embed_media_tabs ul li a:hover {
	background:#939BA5;
	color:#FFF;
	border-top:1px solid #59626D;
	border-left:1px solid #59626D;
	border-right:1px solid #59626D;
}
#embed_media_tabs ul li a.embed_tab_selected {
	border-top:1px solid #59626D;
	border-left:1px solid #59626D;
	border-right:1px solid #59626D;
	-webkit-border-top-left-radius: 4px;
	-webkit-border-top-right-radius: 4px;
	-moz-border-radius-topleft: 4px;
	-moz-border-radius-topright: 4px;
	color:#FFF;
    background:none;
	position: relative;
	top: 1px;
}

#mediaUpload,
#mediaEmbed {
	margin:0 0 10px 0;
	padding:10px 0 10px 0;
	border-top:1px solid #59626D;
}
#mediaEmbed .search_listing {
	margin:0 0 5px 0;
}

h1.mediaModalTitle {
	/* color:#d2d8de; */
	font-size:1.2em;
	line-height:1.2em;
	margin:0;
	padding:5px 0 5px 0;
}

#mediaEmbed .pagination,
#mediaUpload .pagination {
	float:right;
	padding:5px 0 5px 5px;
}
#mediaUpload label {
	font-size:100%;
}
#mediaEmbed p.embedInstructions {
	margin:10px 0 5px 0;
}
a.embed_media {
	margin:0;
	float:right;
	display:block;
	text-align: right;
	font-size:1.0em;
	font-weight: normal;
}
label a.embed_media {
	margin:0 0 3px 0;

}

/* ***************************************
	PAGINATION
*************************************** */
#mediaEmbed .pagination .pagination_number {
	text-align: center;
	color:#d2d8de;
}
#mediaEmbed .pagination .pagination_number:hover {
	color:white;
}

#mediaEmbed .pagination .pagination_previous,
#mediaEmbed .pagination .pagination_next {
	color:#d2d8de;
}
#mediaEmbed .pagination .pagination_previous:hover,
#mediaEmbed .pagination .pagination_next:hover {
	color:white;
}
#mediaEmbed .pagination .pagination_currentpage {
	text-align: center;    
	color:white;
}










