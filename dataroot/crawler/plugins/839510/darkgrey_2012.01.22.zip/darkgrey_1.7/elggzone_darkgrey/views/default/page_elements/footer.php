<?php
/**
 * Elgg footer
 * The standard HTML footer that displays across the site
 *
 * @package Elgg
 * @subpackage Core
 *
 */

// get the tools menu
//$menu = get_register('menu');

?>
<div id="layout_footer">
        <div class="elggzone_line"></div>
        <div id="footer_links_left">        	
                        
            	<div class="float" id="elgg_badge"><a href="http://www.elgg.org" target="_blank"><img src="<?php echo $vars['url']; ?>_graphics/powered_by_elgg_badge_drk_bckgnd.gif" border="0" alt="www.elgg.org" /></a>
                
                </div>
                       
                <div class="float"><a href="<?php echo elgg_echo('elggzone_darkgrey:link'); ?>" target="_blank"><?php echo elgg_echo('elggzone_darkgrey:copyright'); ?></a></div>
                              
			<?php
            if (isloggedin()) {
                // The administration link is for admin or site admin users only
                if ($vars['user']->isAdmin()) {
            ?>
            
            	<div class="float">
    
                <a href="<?php echo $vars['url']; ?>pg/admin/" class="usersettings"><?php echo elgg_echo("admin"); ?></a>
                
                </div>
    
            <?php
                    }
                }
            ?>
        
        </div>
        
        <div id="footer_links_right">
                
		<?php
            echo elgg_view('footer/links');
        ?>
            
    	</div>


</div><!-- /#layout_footer -->

<div class="clearfloat"></div>

</div><!-- /#page_wrapper -->
</div><!-- /#page_container -->
</div><!-- /#elggzone_wrapper -->
<!-- insert an analytics view to be extended -->

<?php
	echo elgg_view('footer/analytics');
?>
</body>
</html>