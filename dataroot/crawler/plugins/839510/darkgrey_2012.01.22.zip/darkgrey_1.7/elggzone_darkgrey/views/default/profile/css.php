<?php

	/**
	 * Elgg Profile 
	 * 
	 * @package Profile
	 */
	 
?>

#profile_icon_wrapper {
	float:left;
}
	
.usericon {
	position:relative;
}

.avatar_menu_button {
	width:15px;
	height:15px;
	position:absolute;
	cursor:pointer;
	display:none;
	right:0;
	bottom:0;
}
.avatar_menu_arrow {
	background: url(<?php echo $vars['url']; ?>_graphics/avatar_menu_arrows.gif) no-repeat left top;
	width:15px;
	height:15px;
}
.avatar_menu_arrow_on {
	background: url(<?php echo $vars['url']; ?>_graphics/avatar_menu_arrows.gif) no-repeat left -16px;
	width:15px;
	height:15px;
}
.avatar_menu_arrow_hover {
	background: url(<?php echo $vars['url']; ?>_graphics/avatar_menu_arrows.gif) no-repeat left -32px;
	width:15px;
	height:15px;
}
.usericon div.sub_menu { 
	display:none; 
	position:absolute; 
	padding:10px; 
	margin:0; 
	width:180px; 
    background: #474E56;
	border:solid 1px #59626D;
	text-align:left;
}
div.usericon a.icon img {
	z-index:10;
}

.usericon div.sub_menu a {margin:0;padding:2px;}
.usericon div.sub_menu a:link, 
.usericon div.sub_menu a:visited, 
.usericon div.sub_menu a:hover{ display:block;}	
.usericon div.sub_menu a:hover{ color:#FFF; text-decoration:none;}

.usericon div.sub_menu h3 {
	font-size:1.2em;
	padding-bottom:3px;
	border-bottom:solid 1px #59626D;
	color: #4690d6;
	margin:0 !important;
}
.usericon div.sub_menu h3:hover {

}

.user_menu_addfriend,
.user_menu_removefriend,
.user_menu_profile,
.user_menu_friends,
.user_menu_friends_of,
.user_menu_blog,
.user_menu_file,
.user_menu_messages,
.user_menu_admin,
.user_menu_pages {
	margin:0;
	padding:0;
}
.user_menu_admin {
	border-top:solid 1px #59626D;
}
.user_menu_admin a {
	color:#371B15;
}
.user_menu_admin a:hover {
	color:white !important;

}

.resetdefaultprofile {
	padding:0;
}
.resetdefaultprofile input[type="submit"] {
	background: #79828F;
	color:#FFF;
}
.resetdefaultprofile input[type="submit"]:hover {
	background: red;
	color:FFFFFF;
}

/* Banned user */
#profile_banned {
    background: url(<?php echo $vars['url']; ?>mod/elggzone_darkgrey/graphics/gradients/bgred40.png) repeat;
	padding:2px;
    color:#FFF;
}