<?php

/**
 * Elgg reported content CSS
 * 
 * @package reportedcontent
 */

?>
/* ***************************************
PAGE-OWNER BLOCK
*************************************** */
#owner_block_report_this {
	padding:5px 0 0 0;
}
#owner_block_report_this a {
	font-size: 90%;
	color:#B5BFC9;
	padding:0 0 4px 24px;
    background: url(<?php echo $vars['url']; ?>mod/elggzone_darkgrey/graphics/icons/icon_reportthis.png) no-repeat left top;
}
#owner_block_report_this a:hover {
	color: #FFF;
}

/* ***************************************
	ADMIN AREA - REPORTED CONTENT
*************************************** */
.reportedcontent_content {
	margin:0 0 5px 0;
	padding:0 7px 4px 10px;
}
.reportedcontent_content p.reportedcontent_detail,
.reportedcontent_content p {
	margin:0;
}
.active_report {
    background: url(<?php echo $vars['url']; ?>mod/elggzone_darkgrey/graphics/gradients/bgred40.png) repeat;
}
.archived_report {
    background: url(<?php echo $vars['url']; ?>mod/elggzone_darkgrey/graphics/gradients/bg40.png) repeat;
}
a.archive_report_button {
	float:right;
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #ffffff;
	background:#79828F;
	width: auto;
	padding: 7px 6px 7px 6px;
	margin:15px 0 0 20px;
	cursor: pointer;
}
a.archive_report_button:hover {
	background: #939BA5;
	text-decoration: none;
}
a.delete_report_button {
	float:right;
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #ffffff;
	background:#79828F;
	width: auto;
	padding: 7px 6px 7px 6px;
	margin:15px 0 0 20px;
	cursor: pointer;
}
a.delete_report_button:hover {
	background:red;
	text-decoration:none;
}
.reportedcontent_content .collapsible_box {
	border-top:1px solid #59626D;
}
