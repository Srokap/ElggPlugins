<?php
/**
 * Elgg top toolbar
 * The standard elgg top toolbar
 *
 * @package Elgg
 * @subpackage Core
 *
 */
?>

<div id="elgg_topbar">

<div id="elgg_topbar_container_left">

    <ul>
        
        <li class="toolbarimages">
                
			<?php
            if (isloggedin()) {
            ?>
 				<a href="<?php echo get_loggedin_user()->getURL(); ?>"><img class="user_mini_avatar" src="<?php echo get_loggedin_user()->getIcon('topbar'); ?>" alt="User avatar" /></a>
                            
            <?php
            }
            ?> 
                   
        </li>
               
        <li class="toolbarlinks">
                
        	<a href="<?php echo $vars['url']; ?>pg/dashboard/" class="pagelinks"><?php echo elgg_echo('dashboard'); ?></a>  
                  
        </li>
        
        <li class="toolbartools">
                
        <?php
        if (isloggedin()) {

			echo elgg_view("navigation/topbar_tools");
			         
        }
        ?>
                
        </li>
        
        <li class="toolbarlinks2">
                
        <?php
        if (isloggedin()) {		
        
        	//allow people to extend this top menu
        	echo elgg_view('elgg_topbar/extend', $vars);
        
        ?>
                
            <li>
            	
                <a href="<?php echo $vars['url']; ?>pg/settings/" class="usersettings"><?php echo elgg_echo('settings'); ?></a>
                
            </li>
                    
        <?php
        }
        ?> 
               
        </li>
           
    </ul>

</div>

<div id="elgg_topbar_container_right">

    <ul>
    
		<?php
        if (isloggedin()) {
        ?>        
        
        <li><?php echo elgg_view('output/url', array('href' => "{$vars['url']}action/logout", 'text' => elgg_echo('logout'), 'is_action' => TRUE)); ?></li>
                
        <?php	
        }
        ?>

        <?php echo "<li><a href=\"{$vars['url']}pg/groups/member/{$_SESSION['user']->username}\">". elgg_echo('elggzone_darkgrey:mygroups') ."</a></li>"; ?>        
        <?php echo "<li><a href=\"{$vars['url']}pg/friends/{$_SESSION['user']->username}\">". elgg_echo('elggzone_darkgrey:myfriends') ."</a></li>"; ?>     
    	
    </ul>
    
</div>

<?php
if (isloggedin()) {
?>
        
<div id="elgg_topbar_container_search">

	<?php echo elgg_view('page_elements/searchbox'); ?>
    
</div>

<?php
}
?>
        
</div><!-- /#elgg_topbar -->
<div class="elggzone_line"></div>
<div class="clearfloat"></div>

<?php

