<?php
	/**
	 * Categories CSS extender
	 * 
	 * @package Elgg File Repository
	 */
?>

.categories .input-checkboxes {
	padding:0;
	margin:2px 5px 0 0;
}
.categories label {
	font-size: 100%;
	line-height:1.2em;
    font-weight:normal;
    text-transform:capitalize;
}

#two_column_left_sidebar_maincontent .contentWrapper h2.categoriestitle {
	margin:0;
	padding:0;
    border:none;
	color:#d2d8de;
	line-height:1.2em;
    font-size: 100%;
}
#two_column_left_sidebar_maincontent .contentWrapper .categories {
	padding:5px;
	margin:0 0 15px 0;	
}
#two_column_left_sidebar_maincontent .contentWrapper .categories p {
	margin:0;	
}
#two_column_left_sidebar_maincontent .contentWrapper .blog_post .categories {
	border:none;
	margin:0;
	padding:0;
}

#two_column_left_sidebar .blog_categories {
    text-transform:capitalize;
    padding:0 10px 10px 10px;
    margin:0 10px 10px 6px;
}
#two_column_left_sidebar .blog_categories h2 {
	background:none;
	border-top:none;
	margin:0;
	padding:0 0 5px 0;
	font-size:1.0em;
	line-height:1.2em;
	color:#d2d8de;
}
#two_column_left_sidebar .blog_categories ul {
	color:#d2d8de;
	margin:5px 0 0 0;
}