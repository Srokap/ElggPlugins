<?php
 
    /**
	 * Elgg Twitter CSS
	 * 
	 * @package ElggTwitter
	 */
     
?>

#twitter_widget {
    margin:0;
}

#twitter_widget ul {
	margin:0;
	padding:0;
}

#twitter_widget li {
	border-bottom: 1px solid #59626D;
	list-style-image:none;
	list-style-position:outside;
	list-style-type:none;
	margin:0 0 5px 0;
	padding:0;
	overflow-x: hidden;
}

#twitter_widget li span {
	color:#d2d8de;
	padding: 5px 0 5px 0;
	display:block;
}

p.visit_twitter a {
    padding:0;
    margin:0;
}
.visit_twitter {
	padding:2px 0 0 0;
	margin:0 0 5px 0;
}

#twitter_widget li a {
	display:block;
	margin:0 0 0 0;
    padding:0 5px 5px 5px;
}

#twitter_widget li span a {
	display:inline !important;
}