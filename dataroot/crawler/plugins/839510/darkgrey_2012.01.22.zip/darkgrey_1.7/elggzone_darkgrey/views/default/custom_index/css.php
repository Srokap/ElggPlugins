<?php
	/**
	 * Custom Index page css extender
	 * 
	 * @package custom_index
	 */
?>

#custom_index {
	margin:0;
    padding:0;
}
#custom_index h2 {
	padding:6px 0 6px 0;
    color:#FFF;
	font-size:1.1em;
	line-height:1.2em;
}
#index_left {
    width:442px;
    float:left;
    padding:16px;
    background: url(<?php echo $vars['url']; ?>mod/elggzone_darkgrey/graphics/gradients/bg40.png) repeat;
}
#index_right {
	padding:16px;
    width:410px;
    float:right;
    background: url(<?php echo $vars['url']; ?>mod/elggzone_darkgrey/graphics/gradients/bg40.png) repeat;
}
#login-box form{
	margin:0;
}
#index_left #index_welcome #login-box {
	padding:16px 0 16px 0;
	border:none;
    width:442px;
}
.index_box h2 {
	border-bottom:1px solid #6C7682;
    margin-bottom:5px;
}
.index_box .index_members {
	float:left;
    margin:5px;
}
#persistent_login {
	float:left;
	display:block;
	margin-top:0;
}



