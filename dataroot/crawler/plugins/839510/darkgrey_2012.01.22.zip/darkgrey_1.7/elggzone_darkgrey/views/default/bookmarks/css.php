<?php

	/**
	 * Elgg bookmarks CSS
	 * 
	 * @package ElggBookmarks
	 */

?>

.sharing_item {

}

.sharing_item_owner {
	font-size: 90%;
	margin: 10px 0 0 0;
	color:#d2d8de;
}
.sharing_item_owner acronym{
	font-size:88%;
	color:#788A9A;
	margin: 10px 0 0 0;
}

.sharing_item_owner .icon {
	float: left;
	margin-right: 5px;

}
.sharing_item_title h3 {
	font-size: 150%;
	margin-bottom: 5px;
}
.sharing_item_title h3 a {
	text-decoration: none;
}
.sharing_item_description p {
	margin:0;
	padding:0 0 5px 0;
}
.sharing_item_tags {
    background: url(<?php echo $vars['url']; ?>mod/elggzone_darkgrey/graphics/icons/icon_tag.png) no-repeat scroll left 2px;
	margin:0;
	padding:0 0 0 20px;
}

.sharing_item_address a {
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #FFF;
	background:#79828F;
	width: auto;
	height: 26px;
	padding: 5px 6px 5px 6px;
	margin:10px 0 10px 0;
	cursor: pointer;
}
.sharing_item_address a:hover {
	background: #939BA5;
	text-decoration: none;
}
.sharing_item_controls p {
	margin:10px 0 0 0;
}

/* SHARES WIDGET VIEW */
.shares_widget_wrapper {
	margin-bottom:5px;
	border-bottom: 1px solid #59626D;
    padding:5px 0 5px 0;
}
.shares_widget_icon {
	float: left;
	margin-bottom: 6px;
}
.shares_timestamp {
	color:#788A9A;
	margin:0;
}
.share_desc {
	display:none;
	line-height: 1.2em;
}
.shares_widget_content {
	margin:0 10px 0 32px;
    padding:0;
}
.shares_title {
	margin:0;
	line-height: 1.2em;
}

/* timestamp and user info in gallery and list view */
.search_listing_info .shares_gallery_user,
.share_gallery_info .shares_gallery_user,
.share_gallery_info .shares_gallery_comments {
	color:#d2d8de;
	margin:0;
	font-size: 90%;	
}


/* ***************************************
PAGE-OWNER BLOCK
*************************************** */
#owner_block_bookmark_this {
	padding:5px 0 0 0;
}
#owner_block_bookmark_this a {
	font-size: 90%;
	color:#B5BFC9;
	padding:0 0 4px 24px;
    background: url(<?php echo $vars['url']; ?>mod/elggzone_darkgrey/graphics/icons/icon_bookmarkthis.png) no-repeat left top;
}
#owner_block_bookmark_this a:hover {
	color: #FFF;
}

