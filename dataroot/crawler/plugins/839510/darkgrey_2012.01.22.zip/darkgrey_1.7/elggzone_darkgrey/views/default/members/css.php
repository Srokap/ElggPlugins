<?php

	/**
	 * Elgg Members 
	 * 
	 * @package Members
	 */

?>

/* new members page */
.members .search_listing {
	margin:0 0 5px 0;
}
.members .search_listing:hover {

}
.members .group_count {
	font-weight: bold;
	color: #d2d8de;
	margin:0 0 5px 4px;
}
.members .search_listing_info {
	color:#d2d8de;
}

.members .profile_status {
	line-height:1.2em;
	padding:2px 0;
}
.members .profile_status .status_update {
	font: 11px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #d2d8de;
}
.members .profile_status .status_update:hover {
	color:#FFF;
	text-decoration: none;
}
.members .profile_status span {
	font-size:88%;
	color:#788A9A;
}
.members  p.owner_timestamp {
	padding-left:0;
}
.members .pagination {
	margin:5px 0 5px 0;
}
#memberssearchform {
	margin-bottom: 10px;
}
#memberssearchform input[type="submit"] {
	padding:2px;
	height:auto;
	margin:4px 0 5px 0;
}
#memberssearchform .search_input {
	width:166px;
}

