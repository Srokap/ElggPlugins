<?php

$english = array(

	'elggzone:sig'						=> 'The Team', 
	'elggzone_darkgrey:pagetitle'		=> 'Welcome to mysite',
	'elggzone_darkgrey:copyright'       => 'Elggzone &copy; 2011',
	'elggzone_darkgrey:link'       		=> 'http://www.perjensen-online.dk',

	// topbar
	'elggzone_darkgrey:mygroups'		=> 'My groups',
	'elggzone_darkgrey:myfriends'		=> 'My Friends',
	
	// register form
	'elggzone_darkgrey:welcome'			=> 'Welcome',
	'elggzone_darkgrey:welcome_text'	=> 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce quis lectus quis sem lacinia nonummy. Proin mollis lorem non dolor. In hac habitasse platea dictumst. Nulla ultrices odio. Donec augue. Phasellus dui. Maecenas facilisis nisl vitae nibh. Proin vel est vitae eros pretium dignissim. Aliquam aliquam sodales orci. Suspendisse potenti. Nunc adipiscing euismod arcu. Quisque facilisis mattis lacus. Fusce bibendum, velit in venenatis viverra, tellus ligula dignissim felis, quis euismod mauris tellus ut urna.',
		
);

add_translation("en", $english);
