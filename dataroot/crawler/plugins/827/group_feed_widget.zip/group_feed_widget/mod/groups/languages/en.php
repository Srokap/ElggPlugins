<?php
/*

	THIS FILE IS NOT MEANT TO REPLACE en.php
	
	Instructions:
		
		1. add the following lines somewhere at the end of the page
		right next to where the other "groups:widgets...  lines are.


*/
			//group_feed
	
			'groups:widgets:feed:title' => "Group Feed",
			'groups:widgets:feed:description' => "Displays a feed of the 10 most recently updated resources in a specified group.",
			'groups:widgets:feed:label' => "Select a group to display feed for:",
			'groups:widgets:feed:label:pleaseedit' => 'Please select group feed to display in edit panel.',

					

?>