

<?

/*
THIS FILE IS NOT MEANT TO REPLACE YOUR START.PHP FILE

Instructions:

	1. Look for where the 2 current   "add_widget_type" functions are

	2. add the 3rd widget type below right after them. 

*/

add_widget_type('group_feed',elgg_echo('groups:widgets:feed:title'), elgg_echo('groups:widgets:feed:description'));
		
		
?>