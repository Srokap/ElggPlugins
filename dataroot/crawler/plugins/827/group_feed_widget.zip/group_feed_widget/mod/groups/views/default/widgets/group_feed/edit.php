<?php
	/**
	 * Edit group_feed widget
	 */
?>
<p>
	<?php echo elgg_echo('groups:widgets:feed:label'); ?>
		
	<select name="params[group]">
<?
	$owner = $vars['entity']->owner_guid;
    $limit = 20;
	$offset = 0;

    $groups = get_entities_from_relationship('member', $owner ,false,'group','', 0,'', $limit, $offset);
	
 foreach($groups as $gr){
	if($gr->guid == $vars['entity']->group)
		echo '<option value="' . $gr->guid . '" SELECTED>' . $gr->name . '</option>';
	else
		echo '<option value="' . $gr->guid . '">' . $gr->name . '</option>';
		
	}
?>
	</select>
</p>