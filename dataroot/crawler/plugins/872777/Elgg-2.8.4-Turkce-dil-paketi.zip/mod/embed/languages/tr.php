<?php
/**
 * Embed T&#252;rk&#231;e dil dizileri
 *
 */

$turkish = array(
	'embed:embed' => 'G&#246;m',
	'embed:media' => '&#304;&#231;eri&#287;i g&#246;m',
	'embed:instructions' => '&#304;&#231;eri&#287;inize g&#246;mmek i&#231;in bir dosyaya t&#305;klay&#305;n.',
	'embed:upload' => 'Medya y&#252;kle',
	'embed:upload_type' => 'Y&#252;kleme t&#252;r&#252;: ',

	// messages
	'embed:no_upload_content' => 'Y&#252;kleme i&#231;eri&#287;i yok!',
	'embed:no_section_content' => 'Hi&#231; &#246;&#287;e bulunamad&#305;.',

	'embed:no_sections' => 'Desteklenen g&#246;mme eklentisi bulunamad&#305;. Site y&#246;neticisinden g&#246;mme destekli bir eklenti etkinle&#351;tirmesini isteyin.',
);

add_translation("tr", $turkish);