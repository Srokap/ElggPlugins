<?php

$turkish = array(
	'search:enter_term' => 'Arama terimini girin:',
	'search:no_results' => 'Sonu&#231; yok.',
	'search:matched' => 'E&#351;le&#351;en: ',
	'search:results' => '%s i&#231;in sonu&#231;lar',
	'search:no_query' => 'L&#252;tfen aramak i&#231;in bir sorgu girin.',
	'search:search_error' => 'Hata',

	'search:more' => '+%s daha fazla %s',

	'search_types:tags' => 'Etiketler',

	'search_types:comments' => 'Yorumlar',
	'search:comment_on' => '"%s" hakk&#305;nda yorum',
	'search:comment_by' => 'taraf&#305;ndan',
	'search:unavailable_entity' => 'Kullan&#305;lamaz Varl&#305;k',
);

add_translation('tr', $turkish);
