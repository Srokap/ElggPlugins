<?php
/**
 * Custom Index T&#252;rk&#231;e dil dosyas&#305;
 */

$turkish = array(	
	'custom:bookmarks' => "Son ba&#287;lant&#305;lar",
	'custom:groups' => "Son gruplar",
	'custom:files' => "Son dosyalar",
	'custom:blogs' => "Son blog yaz&#305;lar&#305;",
	'custom:members' => "En yeni &#252;yeler",
);
					
add_translation("tr", $turkish);
