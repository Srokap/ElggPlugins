<?php
/**
 * Tag cloud English language file
 */

$turkish = array(
	'tagcloud:widget:title' => 'Etiket Bulutu',
	'tagcloud:widget:description' => 'Etiket bulutu',
	'tagcloud:widget:numtags' => 'G&#246;sterilecek etiket say&#305;s&#305;',
);

add_translation('tr', $turkish);
