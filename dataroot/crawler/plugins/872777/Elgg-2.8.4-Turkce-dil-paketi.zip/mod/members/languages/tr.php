<?php
/**
 * Members T&#252;rk&#231;e dil dosyas&#305;
 */

$turkish = array(
	'members:label:newest' => 'En yeni',
	'members:label:popular' => 'Pop&#252;ler',
	'members:label:online' => '&#199;evrimi&#231;i',
	'members:searchname' => '&#220;yeleri isimleriyle ara',
	'members:searchtag' => '&#220;yeleri etiketleriyle ara',
	'members:title:searchname' => '%s i&#231;in &#252;ye arama',
	'members:title:searchtag' => '%s ile etiketlenmi&#351; &#252;yeler',
);

add_translation('tr', $turkish);
