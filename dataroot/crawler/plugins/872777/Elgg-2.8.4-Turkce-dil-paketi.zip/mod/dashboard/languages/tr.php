<?php
/**
 * User dashboard T&#252;rk&#231;e dil dosyas&#305;
 */

$turkish = array(
	'dashboard:widget:group:title' => 'Grup aktivitesi',
	'dashboard:widget:group:desc' => 'Aktiviteyi gruplar&#305;n birinde g&#246;ster',
	'dashboard:widget:group:select' => 'Grup se&#231;',
	'dashboard:widget:group:noactivity' => 'Bu grupta hi&#231; aktivite yok',
	'dashboard:widget:group:noselect' => 'Bir grup se&#231;mek i&#231;in bu arac&#305; d&#252;zenle',
);

add_translation("tr", $turkish);
