<?php
/**
 * Elgg profile eklentisi T&#252;rk&#231;e dil paketi
 */

$turkish = array(
	'profile' => 'Profil',
	'profile:notfound' => '&#220;zg&#252;n&#252;z. Aran&#305;lan profil bulunamad&#305;.',

);

add_translation('tr', $turkish);