<?php
/**
 * TinyMCE T&#252;rk&#231;e dil paketi.
 *
 * @package ElggTinyMCE
 */

$turkish = array(
	'tinymce:remove' => "D&#252;zenleyiciyi kald&#305;r",
	'tinymce:add' => "D&#252;zenleyici ekle",
	'tinymce:word_count' => 'Kelime say&#305;s&#305;: ',
);

add_translation("tr", $turkish);