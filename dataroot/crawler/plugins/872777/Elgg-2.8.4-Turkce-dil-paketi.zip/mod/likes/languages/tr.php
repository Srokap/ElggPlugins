<?php
/**
 * Likes T&#252;rk&#231;e dil dosyas&#305;
 */

$turkish = array(
	'likes:this' => 'bunu be&#287;endi',
	'likes:deleted' => 'Be&#287;eniniz kald&#305;r&#305;ld&#305;',
	'likes:see' => 'Bunu kimlerin be&#287;endi&#287;ini g&#246;r',
	'likes:remove' => 'Bunu be&#287;enme',
	'likes:notdeleted' => 'Be&#287;eniniz kald&#305;r&#305;l&#305;rken hata meydana geldi',
	'likes:likes' => 'Bu &#246;&#287;eyi be&#287;endiniz',
	'likes:failure' => 'Bu &#246;&#287;e be&#287;enilirken hata meydana geldi',
	'likes:alreadyliked' => 'Bunu daha &#246;nce be&#287;endiniz',
	'likes:notfound' => 'Be&#287;enmeye &#231;al&#305;&#351;t&#305;&#287;&#305;n&#305;z &#246;&#287;e bulunam&#305;yor',
	'likes:likethis' => 'Bunu be&#287;en',
	'likes:userlikedthis' => '%s ki&#351;i be&#287;endi',
	'likes:userslikedthis' => '%s ki&#351;i be&#287;endi',
	'likes:river:annotate' => 'be&#287;enmeler',

	'river:likes' => 'be&#287;enmeler %s %s',

	// notifications. yikes.
	'likes:notifications:subject' => '%s "%s" g&#246;nderini be&#287;endi',
	'likes:notifications:body' =>
'Merhaba %1$s,

%2$s "%3$s" g&#246;nderini %4$s toplulu&#287;unda be&#287;endi

G&#246;nderini buradan inceleyebilirsin:

%5$s

ya da %2$s\'in profilini bu radan inceleyebilirsin:

%6$s

Te&#351;ekk&#252;rler,
%4$s
',
	
);

add_translation('tr', $turkish);
