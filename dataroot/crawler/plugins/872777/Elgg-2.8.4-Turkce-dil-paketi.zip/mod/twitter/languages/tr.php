<?php
/**
 * Twitter widget language file
 */

$turkish = array(

	'twitter:title' => 'Twitter',
	'twitter:info' => 'Son twitlerinizi g&#246;r&#252;nt&#252;leyin',
	'twitter:username' => 'Twitter kullan&#305;c&#305; ad&#305;n&#305;z&#305; girin.',
	'twitter:num' => 'G&#246;sterilecek twit say&#305;s&#305;.',
	'twitter:visit' => 'beni Twitter\'da ziyaret et',
	'twitter:notset' => 'Bu Twitter arac&#305; hen&#252;z yap&#305;land&#305;r&#305;lmad&#305;. Son twitlerinizi g&#246;r&#252;nt&#252;lemek i&#231;in, d&#252;zenleye t&#305;klay&#305;n ve ayr&#305;nt&#305;lar&#305; doldurun',
);

add_translation("tr", $turkish);
