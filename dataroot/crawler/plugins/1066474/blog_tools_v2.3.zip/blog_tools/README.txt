= Blog Tools =

Offers additional functionality for Blogs

== Contents ==

1. Features
2. ToDo

== 1. Features ==

- add an image to blogs
- feature blogs
- exta widgets, including extra functionality in existing widgets

== 2. ToDo ==
- navigate to previous/next blog
	- off user/group/site