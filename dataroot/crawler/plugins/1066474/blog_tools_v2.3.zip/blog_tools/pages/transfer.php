<?php

	/**
	 * fancybox view, so no page draw
	 */

	admin_gatekeeper();
	
	$guid = (int) get_input("guid");
	
	if(!empty($guid)){
		if(($entity = get_entity($guid)) && elgg_instanceof($entity, "object", "blog")){

			$title_text = sprintf(elgg_echo("blog_tools:transfer:title"), $entity->title);
			$title = elgg_view_title($title_text);
			
			$body = elgg_view("blog_tools/forms/transfer", array("entity" => $entity));
			
		} else {
			$body = elgg_view("page/components/module", array("body" => elgg_echo("InvalidClassException:NotValidElggStar", array($guid, "ElggBlog"))));
		}
	} else {
		$body = elgg_view("page/components/module", array("body" => elgg_echo("InvalidParameterException:MissingParameter")));
	}

	$page_data = "<div id='blog_tools_transfer_wrapper'>";
	$page_data .= $title;
	$page_data .= $body;
	$page_data .= "</div>";
	
	echo $page_data;