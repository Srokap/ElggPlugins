<?php
	
?>
<script type="text/javascript">
	$(document).ready(function(){
		$("li.elgg-menu-item-transfer-owner a").fancybox();
	});
</script>