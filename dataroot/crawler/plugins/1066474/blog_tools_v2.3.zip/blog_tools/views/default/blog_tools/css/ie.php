<?php
?>
.blog_tools_blog_wrapper * {
	zoom: 0;
}

.blog_tools_blog_wrapper span.elgg-icon {
	zoom: 1;
}