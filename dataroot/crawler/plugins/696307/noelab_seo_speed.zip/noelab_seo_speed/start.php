<?php
/**
 * NoELab Seo Speed
 * 
 * Italian Support Group for Elgg
 * @package Fast by Default - Elgg Performances and SEO by NoELAb.com 
 * @author Lord55
 * @link http://www.noelab.com/
**/

	
	/* Initialise the noelab_seo_speed */
	function noelab_seo_speed_init(){
		
		global $CONFIG;	
		
	}
	
	

	/* Initialise log browser */
	register_elgg_event_handler('init','system','noelab_seo_speed_init');