Installation:
Drop the folder 'simpleblue' in the directory 'mod' of your Elgg installation.
To make the template compatible for Elgg 1.5, please reverse the process described here - http://ishouvik.tk/?p=150

Replace some files:
Please, go to the 'account' folder associated with this folder, and replace the files at elgg/account directory.
But, DO take a backup before making the changes.

Enable the plugin from your adiminstration panel and enjoy.

Please, report your bugs here - info@ishouvik.tk

Feel free to modify the template. But, DO NOT change the link to ishouvik.tk blog on the footer.

Take care and spread the message of love, unity, acceptance and tolerance.