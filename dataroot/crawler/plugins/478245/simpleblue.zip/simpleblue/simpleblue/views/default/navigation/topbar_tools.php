<?php

	/**
	 * Elgg standard tools drop down
	 * This will be populated depending on the plugins active - only plugin navigation will appear here
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.org/
	 * 
	 */
	 
		$menu = get_register('menu');
		
		//var_export($menu);

		if (is_array($menu) && sizeof($menu) > 0) {
			$alphamenu = array();
			foreach($menu as $item) {
				$alphamenu[$item->name] = $item;
			}
			ksort($alphamenu);
		
?>





<ul class="topbardropdownmenu">

   <li class="drop"><a class="menuitemtools" title="Home" href="<?php echo $vars['url']; ?>pg/dashboard/" class="menuitemtools"><?php echo(elgg_echo('Home')); ?></a> 
   </li>

   <li class="drop"><a class="menuitemtools" title="Invite" href="<?php echo $vars['url']; ?>mod/invitefriends/" class="menuitemtools"><?php echo(elgg_echo('Invite')); ?></a> 
   </li>
   
   <li class="drop"><a class="menuitemtools" title="Profile" href="<?php echo $_SESSION['user']->getURL(); ?>" class="menuitemtools"><?php echo(elgg_echo('Profile')); ?></a> 
	  <ul>
      <li><a href="<?php echo $vars['url']; ?>mod/profile/edit.php">Edit Details</a></li>
      <li><a href="<?php echo $vars['url']; ?>mod/profile/editicon.php">Edit Icon</a></li>
      </ul>
      
   </li>
   
   <li class="drop"><a class="menuitemtools" title="Message board" href="<?php echo $vars['url']; ?>pg/messageboard/<?php echo $_SESSION['user']->username; ?>" class="menuitemtools"><?php echo(elgg_echo('Message board')); ?></a> 
   </li>
   
    <li class="drop"><a href="#" class="menuitemtools"><?php echo(elgg_echo('Tools')); ?></a>
	  <ul>
      <?php
			foreach($alphamenu as $item) {
    			echo "<li><a href=\"{$item->value}\">" . $item->name . "</a></li>";
			} 
     ?>
      </ul>
   </li>
    
</ul>

<script type="text/javascript">
  $(function() {
    $('ul.topbardropdownmenu').elgg_topbardropdownmenu();
  });
</script>

<?php
		}
?>
