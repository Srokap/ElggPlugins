<?php

	/**
	 * Elgg header contents
	 * This file holds the header output that a user will see
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2009
	 * @link http://elgg.org/
	 **/
	 
?>

<div id="page_container">
<div id="page_wrapper">

<div id="layout_header">
<div id="wrapper_header">
	<!-- display the page title -->

<div id="site_logo">
		<a href="<?php echo $vars['url']; ?>">
			<img src="<?php echo $vars['url']; ?>mod/simpleblue/images/simpleblue.png" border="0" />		</a>
	</div>
    
<br /><br />

<?php
     if (isloggedin()) {
?>

    
<div id="elgg_topbar_container_search">
<form id="searchform" action="<?php echo $vars['url']; ?>pg/search/" method="get">
	<input type="text" size="41" name="tag" value="<?php echo elgg_echo('search'); ?>" onclick="if (this.value=='<?php echo elgg_echo('search'); ?>') { this.value='' }" class="search_input" />
	<input type="submit" value="<?php echo elgg_echo('Go'); ?>" class="search_submit_button" />
</form>
</div>

<small><br /><br /><br /></small>


			<?php
		
			// The administration link is for admin or site admin users only
			if ($vars['user']->admin || $vars['user']->siteadmin) { 
		
		?>
<div id="elgg_topbar_container_left">
	<div class="toolbarlinks3">	

			<a href="<?php echo $vars['url']; ?>pg/admin/" class="admin"><?php echo elgg_echo("admin"); ?></a>
		
	</div>
</div>

<?php
		
				}
		
		?>


<div id="elgg_topbar_2">

<div id="elgg_topbar_container_left">


       
           
        <?php

	        echo elgg_view("navigation/topbar_tools");

        ?>
        	
        	
        <div class="toolbarlinks2">		
		<?php
		//allow people to extend this top menu
		echo elgg_view('elgg_topbar/extend', $vars);
		?>
		
	<a href="<?php echo $vars['url']; ?>pg/settings/" class="usersettings"><?php echo elgg_echo('settings'); ?></a>
    
    </div>

<div id="elgg_topbar_container_right">    
	<a href="<?php echo $vars['url']; ?>action/logout" class="usersettings"><?php echo elgg_echo('logout'); ?></a>

</div>


</div>

</div><!-- /#elgg_topbar -->


<?php } else { ?>

<br /><br /><br />

<div id="elgg_topbar_2">

	<div id="elgg_topbar_container_left">

	<div class="toolbarlinks">
		<a title="Register" href="<?php echo $vars['url']; ?>account/register.php/" class="pagelinks">Register</a>
      </div>
     <div class="toolbarlinks">
		<a title="Login" href="<?php echo $vars['url']; ?>account/login.php/" class="pagelinks">Login</a>
      </div>
	</div>
</div>

<br />


<div class="clearfloat"></div>

<?php
    }
?>

</div><!-- /#wrapper_header -->

</div><!-- /#layout_header -->

