<?php

	/**
       Autho: Le Van Luyen
       website: http://vietskygroup.com
       Location: Viet Nam
	 */

    require_once(dirname(dirname(__FILE__)) . "/engine/start.php");
	if (!isloggedin()) {
		$body = elgg_view_title(elgg_echo('login')) . elgg_view("account/forms/login");

		page_draw(elgg_echo('login'), elgg_view_layout("one_column", $body));
	} else {
		forward();
	}
 ?>
