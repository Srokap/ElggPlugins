<?php

/**
	 * Elgg Friend Requiest  plugin
	 * 
	 * @package Elgg Friend Requiest plugin
	 * @license: GNU Public License version 2
	 * @author: 
	 * @copyright: 
	 * @link: 
	 * ****************************************
     * @Italian Language Pack
     * @Plugin System: Friend Requiest plugin
     * @version: 0.2 
     * @Italian Support Group: http://community.elgg.org/pg/groups/271/italian-support-group/
     * @translation by Lord55  <lord55@nobiltadeipari.com> 
     * @link http://www.nobilityofequals.com
     ****************************************/

		
		$italian = array(
	'friendrequest' => "Richiesta di amicizia",
	'friendrequests' => "Richieste di amicizia",
	'friendrequests:title' => "Le richieste di amicizia di %s",
	'newfriendrequests' => "Una nuova richiesta di amicizia!",
	'friendrequest:add:exists' => "Hai già richiesto di diventare un amico di %s.",
	'friendrequest:add:failure' => "Scusaci, per un errore di sistema, non siamo abilitati a completare la tua richiesta. Per favore, riprova.",
	'friendrequest:add:successful' => "Hai richiesto di diventare amico di %s. Deve approvare la tua richiesta prima che possa essere visualizzato sulla tua lista degli amici.",
	'friendrequest:newfriend:subject' => "%s vuole diventare un tuo amico!",
	'friendrequest:newfriend:body' => "%s vuole diventare  un tuo amico! Ma sta aspettando l'approvazione della richiesta. Entra sul sito per poter approvare la richiesta!

Puoi vedere le tue richieste di amicizia a:

	%s

(Non puoi replicare a questa email.)",

	'friendrequest:successful' => "Ora sei amico con %s!",
	'friendrequest:remove:success' => "Richiesta di amicizia rimossa con successo.",
	'friendrequest:remove:fail' => "Inabilitati a rimuovere la richiesta di amicizia.",
	'friendrequest:approvefail' => "Errore sconosciuto mentre si stava provando ad aggiungere %s come amico!",
);
				
       add_translation("it",$italian);
?>