<?php


$user = get_loggedin_user();

// call the hook directly to avoid overrides and other logic
$wav = identicon_url($user, 'large');

$img = '<img src="' . $wav . '" alt="identicon" />';

$check = elgg_view('input/checkboxes', array('internalname' => 'preferIdenticon',
					     'options' => array('Prefer your Identicon image over the default profile photo.' => 'pref'),
					     'value' => ($user->preferIdenticon ? 'pref' : '')));

$submit = elgg_view('input/submit', array('value' => 'Save'));

$form = elgg_view('input/form', array('action' =>  $CONFIG->wwwroot . 'action/identicon/preference', 
				      'body' => $img . "\n" . $check . "\n" . $submit));

echo elgg_view_title('Identicon');
$explanation = '<p>A Identicon is an automatically generated user icon based off of your email address. It is randomly generated to be unique for each user.</p>';

echo elgg_view('page_elements/contentwrapper', array('body' => $explanation . $form));

?>
