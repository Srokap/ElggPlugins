<?php

  // must be logged in
gatekeeper();

// Get the logged in user
$user = get_loggedin_user();

$pref = get_input('preferIdenticon');

if (in_array('pref', $pref)) {
  $user->preferIdenticon = true;
  system_message('Your account will now use the Identicon image (as long as nothing else overrides it).');
} else {
  $user->preferIdenticon = false;
  system_message('Your account will no longer use the Identicon image (unless nothing else overrides it).');
}


forward($_SERVER['HTTP_REFERER']); // send us back

?>