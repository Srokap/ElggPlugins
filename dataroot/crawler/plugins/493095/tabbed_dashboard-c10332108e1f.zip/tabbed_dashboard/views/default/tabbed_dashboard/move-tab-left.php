<?php
    $tab = $vars[ 'tab' ];
    $context = $vars[ 'context' ];
    $position = $vars[ 'position' ];
    // First validate the link with time and security tokens
    $link = elgg_validate_action_url ( $vars['url'] . "action/tabs/move?direction=left&context=" . $context . "&guid=" . $tab->getGUID() );
    
    // Only show left if not first tab
    if ( $position > 0 ) {
?>
<a href="<?php echo $link ?>" title="<?php echo sprintf( elgg_echo( "tabbed_dashboard:move:left"), $tab->title ); ?>"><?php echo elgg_echo( "tabbed_dashboard:move:left:char" ); ?></a>
<?php 
    } else {
?>
&nbsp;
<?php
    }
?>
