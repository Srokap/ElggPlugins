<p>
<br />
<h3><?php echo elgg_echo('tabbed_dashboard:dashboard:settings:tabs:maximum'); ?>: </h3>
<?php
        $defaultMaxTabbedWidgets = ($vars['entity']->defaultMaxTabbedWidgets) ? $vars['entity']->defaultMaxTabbedWidgets : 6;
        
        $defaultMaxTabbedWidgetsOptions = array(
            'internalname' => 'params[defaultMaxTabbedWidgets]', 
            'value' => $defaultMaxTabbedWidgets,
            'options_values' => array(
                    // One (1) is the equivalent of no additional tabs!
                    "1" => "1",
                    "4" => "4",
                    "6" => "6",
                    "8" => "8",
                    "10" => "10",
                    "20" => "20",
                    // There is no unlimited option!
            )
        );
       
        echo elgg_view('input/pulldown', $defaultMaxTabbedWidgetsOptions);
?>
</p>
<br />
<p>
<br />
<h3><?php echo elgg_echo('tabbed_dashboard:profile:settings:tabs:maximum'); ?>: </h3>
<?php
        $defaultMaxTabbedWidgets = ($vars['entity']->defaultProfileMaxTabbedWidgets) ? $vars['entity']->defaultProfileMaxTabbedWidgets : 6;
        
        $defaultMaxTabbedWidgetsOptions = array(
            'internalname' => 'params[defaultProfileMaxTabbedWidgets]', 
            'value' => $defaultMaxTabbedWidgets,
            'options_values' => array(
                    // One (1) is the equivalent of no additional tabs!
                    "1" => "1",
                    "4" => "4",
                    "6" => "6",
                    "8" => "8",
                    "10" => "10",
                    "20" => "20",
                    // There is no unlimited option!
            )
        );
       
        echo elgg_view('input/pulldown', $defaultMaxTabbedWidgetsOptions);
?>
</p>
<br />
<br />
<p>
<?php echo elgg_echo( "tabbed_dashboard:settings:note" ); ?>
</p>
<br />