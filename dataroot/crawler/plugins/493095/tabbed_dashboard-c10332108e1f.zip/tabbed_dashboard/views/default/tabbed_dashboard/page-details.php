<?php 
    // Only allow of tab is found i.e. not for default dashboard
    $tab = false;
    if ( $vars[ 'tab' ]  ) {
        $tab = $vars[ 'tab' ];
        $access_id = $tab->access_id;
    }
    if ( $tab !== false ) { 
?>
<script language="javascript" type="text/javascript">
    function setTabValue( name, value ) {
        valNodeName = "#"+name;
        valNode = $( valNodeName )[0];

        if ( valNode != undefined ) {
            valNode.value = value;
        } else {
            formNodeName = "#pageform";
            formNode = $( formNodeName )[0];
            
            valNode = document.createElement( "input" );
            valNode.setAttribute( "type", "hidden" );
            valNode.setAttribute( "id", name );
            valNode.setAttribute( "name", name );
            valNode.setAttribute( "value", value );
            formNode.appendChild( valNode );
        }
    }
</script>
<div class="customise_editpanel_pagedetails">
    <table>
    <tr> 
    <td><label>
        <?php 
            echo elgg_echo( "tabbed_dashboard:page:name" );
            ?>
    </label></td>
    <td>  
    <input class="input-text" name="p1"  value="<?php echo $tab->title ?>" onChange="setTabValue( 'pagename', this.value )" />
    </td>
    </tr>
    <tr>
    <td><label>
        <?php echo elgg_echo( "access" ); ?>:
    </label></td>
    <td>
    <?php
        echo elgg_view('input/access', array('internalname' => 'aid', 'value' => $access_id, 'js' => "onChange=\"setTabValue( 'access_id', this.value )\""));
    ?>
    </td>
    </tr>
    </table>
</div>
<?php 
    } 
?>