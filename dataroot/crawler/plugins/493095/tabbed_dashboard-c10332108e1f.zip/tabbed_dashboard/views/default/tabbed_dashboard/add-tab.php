<?php
    $context = $vars['context'];
    $tabs = $vars[ 'tabs' ];
    // First validate the link with time and security tokens
   $link = elgg_validate_action_url( $vars['url'] . "action/tabs/add?context=" . $context . "&newtab=");
    
    if ( sizeof( $tabs ) < tabbed_dashboard_get_max_tabs( $context ) ) {
?>
<span class="tabbedpaneaddtab"><a href="<?php echo $link ?>" title="<?php echo sprintf( elgg_echo( "tabbed_dashboard:addtab:title" ), $context ); ?>">&nbsp;<?php echo elgg_echo( "tabbed_dashboard:add:char"); ?>&nbsp;</a></span>
<?php
    }
?>
