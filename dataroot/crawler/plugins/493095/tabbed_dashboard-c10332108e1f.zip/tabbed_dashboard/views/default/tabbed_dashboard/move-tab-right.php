<?php
    $tab = $vars[ 'tab' ];
    $context = $vars[ 'context' ];
    $tabs = $vars[ 'tabs' ];
    $position = $vars[ 'position' ];
    // First validate the link with time and security tokens
    $link = elgg_validate_action_url( $vars['url'] . "action/tabs/move?direction=right&context=" . $context . "&guid=" . $tab->getGUID());
    
    // Only show right if not last tab
    if ( $position < sizeof( $tabs ) - 1 ) {
?>
<a href="<?php echo $link ?>" title="<?php echo sprintf( elgg_echo( "tabbed_dashboard:move:right"), $tab->title ); ?>"><?php echo elgg_echo( "tabbed_dashboard:move:right:char" ); ?></a>&nbsp;
<?php 
    } else {
?>
&nbsp;
<?php
    }
?>
