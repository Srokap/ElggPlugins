<?php
    gatekeeper();
    
    $context = get_input( "context" );
    $new_tab = get_input( "newtab", false );
    $move_direction = get_input( "direction", false );
    $tab_guid = get_input( "guid", false );
    
    $tab = false;
    if ( $new_tab !== false ) {
        $tab = tabbed_dashboard_add_tab( $context, $new_tab );
    }
    
    if ( $move_direction !== false ) {
        $tab = tabbed_dashboard_move_tab( $context, $tab_guid, $move_direction );
    }
    
    if ( $tab === false ) {
    // Something went wrong
        forward($_SERVER['HTTP_REFERER']);  
    } 
    
    // Forward onto the tab (either new or moved tab)
    forward( $tab->getURL() ); 
?>