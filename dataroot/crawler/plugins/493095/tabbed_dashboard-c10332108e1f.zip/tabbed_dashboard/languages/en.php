<?php

    $english = array(
        "tabbed_dashboard:page:name" => "Page name:",
        "tabbed_dashboard:addtab:title" => "Add page to %s",
        "tabbed_dashboard:removetab:title" => "Delete page '%s'",
        "tabbed_dashboard:defaultnewtabname" => "New page",
        "tabbed_dashboard:maxtabsexceeded" => "Unable to create a new page, the maximum number of pages is %s!",
        "tabbed_dashboard:add:char" => " ",
        "tabbed_dashboard:add:unable" => "Unable to add new page '%s'!",
        "tabbed_dashboard:added" => "Added new page '%s'",
        "tabbed_dashboard:delete:char" => "x",
        "tabbed_dashboard:deleted" => "Deleted page '%s'",
        "tabbed_dashboard:delete:unable" => "Unable to delete page '%s', please try again!",
        "tabbed_dashboard:delete:notallowed" => "You do not have permission to delete the page!",
        "tabbed_dashboard:currenttab:title" => "Selected page, click 'Edit page' to rename",
        "tabbed_dashboard:changed" => "Changed page '%s'",
        "tabbed_dashboard:change:unable" => "Unable to change page, please try again!",
        "tabbed_dashboard:change:notallowed" => "You do not have permission to change the page!",
        "tabbed_dashboard:rename:blank" => "<b>You cannot specify a blank page name, please try again!</b>",
        "tabbed_dashboard:othertab:title" => "%s %s page",
        "tabbed_dashboard:move:left:char" => "<",
        "tabbed_dashboard:move:left" => "Move page '%s' tab left",
        "tabbed_dashboard:moved:left" => "Moved page '%s' tab left",
        "tabbed_dashboard:move:right:unable" => "Unable to move page '%s' tab left!",
        "tabbed_dashboard:move:right:char" => ">",
        "tabbed_dashboard:move:right" => "Move page '%s' tab right",
        "tabbed_dashboard:move:right:unable" => "Unable to move page '%s' tab right!",
        "tabbed_dashboard:moved:right" => "Moved page '%s' tab right",
        "tabbed_dashboard:move:notallowed" => "You do not have permission to move the page tab!",
        "tabbed_dashboard:dashboard:settings:tabs:maximum" => "Maximum number of dashboard pages",
        "tabbed_dashboard:profile:settings:tabs:maximum" => "Maximum number of profile pages",
        "tabbed_dashboard:settings:note" => "<b>Reducing the number of pages will NOT delete existing pages!</b>",

        "item:object:dashboard_widget_tab" => "Dashboard tab settings",
    );
                    
    add_translation("en",$english);

?>