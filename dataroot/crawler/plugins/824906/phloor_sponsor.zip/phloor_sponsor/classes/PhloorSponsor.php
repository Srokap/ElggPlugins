<?php 
/*****************************************************************************
 * Phloor Sponsor                                                            *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php

/**
 * PhloorSponsor
 * 
 * extend ElggObject
 * 
 */
class PhloorSponsor extends ElggObject {

	public function __construct($guid = null) {
		parent::__construct($guid);
	}
	
	/**
	 * Set subtype to phloor_sponsor.
	 */
	protected function initializeAttributes() {
		parent::initializeAttributes();

		$this->attributes['subtype'] = "phloor_sponsor";
		$this->attributes['access_id'] = ACCESS_PUBLIC;
		$this->attributes['comments_on'] = 'Off';
	}
	
	public function delete() {
		$this->deleteThumbnails();
		$this->deleteImage();
		return parent::delete();
	}
	
	public function save() {		
		$return = parent::save();
		return $return;
	}
	
	public function getIconURL($size = 'medium') {
		return $this->getImageURL($size);
	}
	
	/**
	 * get the url for the image
	 */
	public function getImageURL($size = 'medium') {
		$guid = $this->getGUID();
		
		$sizes = array('small', 'medium', 'large');
		if(!in_array($size, $sizes)) {
			$size = 'medium';		
		}
		
		$image_url = elgg_get_site_url() . "mod/phloor_sponsor/thumbnail.php?sponsor_guid={$guid}&size={$size}";
		
		return $image_url;
	}
	
	public function deleteImage() {
		$return = false;
		
		$sponsor_image_dir = elgg_get_data_path() . 'phloor_sponsor';
		$sponsor_image = $sponsor_image_dir . '/' . $this->image;
		
		if(isset($this->image) && !empty($this->image) &&
		   file_exists($sponsor_image) && is_file($sponsor_image)) {
			$return =  unlink($sponsor_image);
		}
		
		return $return; 
	}
	
	public function recreateThumbnails() {
		$this->deleteThumbnails();
		$this->createThumbnails();
		$this->save();
	}
	
	protected function deleteThumbnails() {
		$thumbnails = array('thumbnail', 'thumbsmall', 'thumblarge');
		
		// delete former thumbnails
		foreach ($thumbnails as $thumbkey) {
			$thumbnail = $this->get($thumbkey);
			if ($thumbnail && file_exists($thumbnail) && is_file($thumbnail)) {
				@unlink($thumbnail);
			}
			// unset attribute
			$this->set($thumbkey, '');
		}
	}
	
	public function createThumbnails() {
		$sponsor_image_dir = elgg_get_data_path() . 'phloor_sponsor';
		$sponsor_image = $sponsor_image_dir . '/' . $this->image;
		
		if(isset($this->image) && !empty($this->image) &&
		   file_exists($sponsor_image) && is_file($sponsor_image)) {
		   	
			$thumbs = array( // key => (width, height, square)
				'thumbnail'  => array( 60,  60, true),
				'thumbsmall' => array(153, 153, true),
				'thumblarge' => array(600, 600, false),
			);
			
			$thumb = new ElggFile();
			$time = time();
			foreach($thumbs as  $key => $options) {
				$thumbnail = get_resized_image_from_existing_file($sponsor_image, 
					$options[0], $options[1], $options[2]);
	
				$clean_title = ereg_replace("[^A-Za-z0-9]", "", $this->title);
				$filename = $time . '_' . $clean_title . '_' . $key . '.jpeg';
				if ($thumbnail) {
					$thumb->setMimeType($this->mime);
					$thumb->setFilename($filename);
					$thumb->open("write");
					$thumb->write($thumbnail);
					$thumb->close();
		
					$this->set($key, $thumb->getFilenameOnFilestore());
				}	
			}
		}
	}
	
	/**
	 * No one can comment on Sponsors
	 */
	public function canComment($user_guid = 0) {
		return false;
	}

	/**
	 * Getter/Setter
	 */
	
	/**
	 * Getter for description
	 */
	public function getTitle() {
		return $this->title;
	}	
	
	/**
	 * Setter for title
	 */
	public function setTitle($title) {
		$this->title = $title;
	}

	/**
	 * Getter for description
	 */
	public function getDescription() {
		return $this->description;
	}	
	
	/**
	 * Setter for description
	 */
	public function setDescription($description) {
		$this->description = $description;
	}
	
	/**
	 * Getter for website
	 */
	public function getWebsite() {
		return $this->website;
	}	
	
	/**
	 * Setter for website
	 */
	public function setWebsite($website) {
		$this->website = $website;
	}
	
	/**
	 * Getter for image
	 */
	public function getImage() {
		return $this->image;
	}	
	
	/**
	 * Setter for image
	 */
	public function setImage($image) {
		$this->image = $image;
	}
}