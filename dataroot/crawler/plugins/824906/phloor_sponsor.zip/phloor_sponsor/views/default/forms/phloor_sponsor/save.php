<?php 
/*****************************************************************************
 * Phloor Sponsor                                                            *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php
/**
 * Edit form for Sponsor objects
 *
 */

$phloor_sponsor = get_entity($vars['guid']);
$vars['entity'] = $phloor_sponsor;

$action_buttons = '';
$delete_link = '';

if ($vars['guid']) {
	// add a delete button if editing
	$delete_url = "action/phloor_sponsor/delete?guid={$vars['guid']}";
	$delete_link = elgg_view('output/confirmlink', array(
		'href' => $delete_url,
		'text' => elgg_echo('delete'),
		'class' => 'elgg-button elgg-button-delete elgg-state-disabled float-alt'
	));
}

$save_button = elgg_view('input/submit', array(
	'value' => elgg_echo('save'),
	'name' => 'save',
));
$action_buttons = $save_button . $delete_link;

$title_label = elgg_echo('phloor_sponsor:title');
$title_input = elgg_view('input/text', array(
	'name' => 'title',
	'value' => $vars['title']
));
$title_desc = elgg_echo('phloor_sponsor:title:description');

$description_label = elgg_echo('phloor_sponsor:description');
$description_input = elgg_view('input/longtext', array(
	'name' => 'description',
	'value' => $vars['description']
));
$description_desc = elgg_echo('phloor_sponsor:description:description');

$website_label = elgg_echo('phloor_sponsor:website');
$website_input = elgg_view('input/text', array(
	'name' => 'website',
	'value' => $vars['website']
));
$website_desc = elgg_echo('phloor_sponsor:website:description');

$image_label = elgg_echo('phloor_sponsor:image');
$image_input = elgg_view('input/file', array(
	'name' => 'image',
	'value' => $vars['image']
));
$image_desc = elgg_echo('phloor_sponsor:image:description');

$tags_label = elgg_echo('phloor_sponsor:tags');
$tags_input = elgg_view('input/tags', array(
	'name' => 'tags',
	'value' => $vars['tags']
));
$tags_desc = elgg_echo('phloor_sponsor:tags:description');

$categories_input = elgg_view('input/categories', $vars);

$access_id_label = elgg_echo('phloor_sponsor:access_id');
$access_id_input = elgg_view('input/access', array(
	'name' => 'access_id',
	'value' => $vars['access_id'],
));
$access_id_desc = elgg_echo('phloor_sponsor:access_id:description');


// hidden inputs
$container_guid_input = elgg_view('input/hidden', array('name' => 'container_guid', 'value' => elgg_get_page_owner_guid()));
$guid_input = elgg_view('input/hidden', array('name' => 'guid', 'value' => $vars['guid']));
$context_input = elgg_view('input/hidden', array('name' => 'context', 'value' => elgg_get_context()));

echo <<<___HTML
<div>
	<label for="phloor_sponsor_title">$title_label</label>
	$title_input
</div>
<div>
	<label for="phloor_sponsor_description">$description_label</label>
	$description_input
</div>
<div>
	<label for="phloor_sponsor_website">$website_label</label>
	$website_input
</div>
<div>
	<label for="phloor_sponsor_image">$image_label</label>
	$image_input
</div>
<div>
	<label for="phloor_sponsor_image">$tags_label</label>
	$tags_input
</div>
<div>
	<label for="phloor_sponsor_access_id">$access_id_label</label><br />
	$access_id_input
</div>
	
$categories_input

<div class="elgg-foot">
	$context_input
	$guid_input
	$container_guid_input

	$action_buttons
</div>

___HTML;
