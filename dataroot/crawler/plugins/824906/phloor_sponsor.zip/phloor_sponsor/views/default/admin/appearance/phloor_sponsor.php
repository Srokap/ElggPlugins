<?php 
/*****************************************************************************
 * Phloor Sponsor                                                            *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php 
// restrict to admins
admin_gatekeeper();

$title = elgg_view_title(elgg_echo('phloor_sponsor:admin:appearance:title')); 
$description = elgg_echo('phloor_sponsor:admin:appearance:description'); 

$count = phloor_sponsor_get_sponsor_entities(true);
$entity_count = elgg_echo('phloor_sponsor:admin:appearance:entity_count', array($count)); 

$sponor_list = '';
if($count > 0) {
	$sponsors = phloor_sponsor_get_sponsor_entities();
	foreach($sponsors as $sponsor) {
		$body_vars = phloor_sponsor_prepare_form_vars($sponsor);
		$sponors_forms .= elgg_view_form('phloor_sponsor/save', $vars, $body_vars);
	}
	
	$params = array(
		'offset' => (int) max(get_input('offset', 0), 0),
		'limit' => (int) max(get_input('limit', 10), 0),
		'full_view' => false,
		'list_type_toggle' => true,
		'pagination' => TRUE,
	);
	
	$sponor_list = elgg_view_entity_list($sponsors, $params);
}

$new_sponsor_title = elgg_view_title(elgg_echo('phloor_sponsor:admin:appearance:new_sponsor:title'));

// view form
$body_vars = phloor_sponsor_prepare_form_vars();
$vars['enctype'] = 'multipart/form-data';
$new_sponsor_form = elgg_view_form('phloor_sponsor/save', $vars, $body_vars);
unset($vars['enctype']);

//$form = elgg_view('input/form',array(	
//	'action' => $vars['url'] . 'action/phloor_custom_404/save',
//	'body' => elgg_view('forms/phloor_custom_404/save', $params),
//	'method' => 'post',
//));

echo <<<___HTML
{$title}
<p>{$description}</p>
<div>
{$sponor_list}
<p>{$entity_count}</p>
</div>
<div class="phloor-sponsor-admin-new-sponsor">
<p>{$new_sponsor_title}</p>
{$new_sponsor_form}
</div>
___HTML;

?>