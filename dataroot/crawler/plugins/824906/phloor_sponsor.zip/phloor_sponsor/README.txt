/**
 * Phloor Sponsor
 * 
 * @package phloor_sponsor
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author void <void@13net.at>
 * @copyright 13net
 * @link http://www.13net.at/
 */
 
Version: 1.8-11.12.06
Requires: Elgg 1.8 or higher


/**
 * Description
 */
Sponsors for your Elgg site. 
Enables creating 'Sponsor' entities by administrators.
Makes only sense in combination with other related plugins.

Check out the plugin: Phloor Sponsor Flip Wall 1.8

/**
 * Languages
 */
English
German


