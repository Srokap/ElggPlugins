<?php 
/*****************************************************************************
 * Phloor Sponsor                                                            *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php

/**
 * Default attributes
 * 
 * @return array with default values
 */
function phloor_sponsor_default_vars() {
	$defaults = array(
		'title' => '',
		'description' => '',
		'image' => '',
		'website' => '',
		'tags' => NULL,
		'access_id' => ACCESS_DEFAULT,
	);
	
	return $defaults;
}

/**
 * Load vars from post or get requests and returns them as array
 * 
 * @return array with values from the request
 */
function phloor_sponsor_get_input_vars() {
	// set defaults and required values
	$values = phloor_sponsor_default_vars();
	$values['container_guid'] = (int)get_input('container_guid', '');
		
	$user = elgg_get_logged_in_user_entity();
	// load from sponsor and do sanity and access checking
	foreach ($values as $name => $default) {
		$value = get_input($name, $default);
		switch ($name) {
			// get the image from $_FILES array
			case 'image':
				$values['image'] = $_FILES['image'];
				break;
			case 'container_guid':
				// this can't be empty or saving the base entity fails
				if (!empty($value)) {
					if (can_write_to_container($user->getGUID(), $value)) {
						$values['container_guid'] = $value;
					}
				}
				break;
			// don't try to set the guid
			case 'guid':
				unset($values['guid']);
				break;
			default:
				$values[$name] = $value;
				break;
		}
	}

	return $values;
}

/**
 * Load vars from given site into and returns them as array
 * 
 * @return array with stored values
 */
function phloor_sponsor_save_vars(PhloorSponsor $sponsor, $params) {	
	// check variables
	if(!phloor_sponsor_check_vars($params)) {
		return false;
	}
	
	// adopt variables
	foreach($params as $key => $value) {
		$sponsor->$key = $value;
	}
	
	// save and return status
	return $sponsor->save();
}

function phloor_sponsor_check_vars(&$params) {	
	// create sponsor image directory if not exists
	$sponsor_image_dir = elgg_get_data_path() . 'phloor_sponsor';
	if (!file_exists($sponsor_image_dir)) {
		if(!mkdir($sponsor_image_dir)) {
			register_error(elgg_echo('phloor_sponsor:couldnotcreatesponsorimagedir'));
			return false;
		}
		
		system_message(elgg_echo('phloor_sponsor:sponsorimagedircreated'));
	}
	
	if (isset($params['image']) && !empty($params['image']) && $params['image']['error'] != 4) {
		$mime = array(	
			'image/gif' => 'gif',
			'image/jpg' => 'jpeg',
			'image/jpeg' => 'jpeg',
			'image/pjpeg' => 'jpeg',
			'image/png' => 'png',
		);  
		
		if (!array_key_exists($params['image']['type'], $mime)) {
			register_error(elgg_echo('phloor_sponsor:image_mime_type_not_supported', array(
				$params['image']['type'],
			)));
			return false;
		}
		if ($params['image']['error'] != 0) {
			register_error(elgg_echo('phloor_sponsor:upload_error', array(
				$params['image']['error'],
			)));
			return false;
		}
		
		$tmp_filename = $params['image']['tmp_name'];
		$params['mime'] = $params['image']['type'];
		
		// determine filename (clean title)
		$clean_title = ereg_replace("[^A-Za-z0-9]", "", $params['title']); // just numbers and letters
		$filename = time() . '_' . $clean_title . '.' . $mime[$params['mime']];
		$params['image'] = $filename;
		
		// move the file to the data directory
		$move = move_uploaded_file($tmp_filename, $sponsor_image_dir . '/' . $params['image']);
		// report errors if that did not succeed
		if(!$move) {
			register_error(elgg_echo('phloor_sponsor:coultnotmoveuploadedfile'));
			return false;
		}
	}
	
	// fail if a required entity isn't set
	$required = array('title', 'description', 'image');
	
	// load from sponsor and do sanity and access checking
	foreach ($required as $name) {
		if (!isset($params[$name]) || empty($params[$name])) {
			register_error(elgg_echo("phloor_sponsor:error:missing:$name"));
			return false;
		}
	}
	
	return true;
}

/**
 * Get page components to view a sponsor post.
 *
 * @param int $guid GUID of a sponsor entity.
 * @return array
 */
function phloor_sponsor_get_page_content_read($guid = NULL) {

	$return = array();

	$sponsor = get_entity($guid);

	// no header or tabs for viewing an individual sponsor
	$return['filter'] = '';

	if (!elgg_instanceof($sponsor, 'object', 'phloor_sponsor')) {
		$return['content'] = elgg_echo('phloor_sponsor:error:sponsor_not_found');
		return $return;
	}

	$return['title'] = htmlspecialchars($sponsor->title);

	$container = $sponsor->getContainerEntity();
	$crumbs_title = $container->name;
	if (elgg_instanceof($container, 'group')) {
		elgg_push_breadcrumb($crumbs_title, "phloor_sponsor/group/$container->guid/all");
	} else {
		elgg_push_breadcrumb($crumbs_title, "phloor_sponsor/owner/$container->username");
	}

	elgg_push_breadcrumb($sponsor->title);
	$return['content'] = elgg_view_entity($sponsor, array('full_view' => true));
	
	//check to see if comment are on
	if ($sponsor->comments_on != 'Off') {
		$return['content'] .= elgg_view_comments($sponsor);
	}

	return $return;
}

/**
 * Get page components to list a user's or all sponsors.
 *
 * @param int $owner_guid The GUID of the page owner or NULL for all sponsors
 * @return array
 */
function phloor_sponsor_get_page_content_list($container_guid = NULL) {

	$return = array();

	$return['filter_context'] = $container_guid ? 'mine' : 'all';

	$options = array(
		'type' => 'object',
		'subtype' => 'phloor_sponsor',
		'full_view' => FALSE,
	);

	$loggedin_userid = elgg_get_logged_in_user_guid();
	if ($container_guid) {
		// access check for closed groups
		group_gatekeeper();

		$options['container_guid'] = $container_guid;
		$container = get_entity($container_guid);
		if (!$container) {

		}
		$return['title'] = elgg_echo('phloor_sponsor:title:user_phloor_sponsors', array($container->name));

		$crumbs_title = $container->name;
		elgg_push_breadcrumb($crumbs_title);

		if ($container_guid == $loggedin_userid) {
			$return['filter_context'] = 'mine';
		} else if (elgg_instanceof($container, 'group')) {
			$return['filter'] = false;
		} else {
			// do not show button or select a tab when viewing someone else's posts
			$return['filter_context'] = 'none';
		}
	} else {
		$return['filter_context'] = 'all';
		$return['title'] = elgg_echo('phloor_sponsor:title:all_phloor_sponsors');
		elgg_pop_breadcrumb();
		elgg_push_breadcrumb(elgg_echo('phloor_sponsor:phloor_sponsors'));
	}

	elgg_register_title_button();

	$list = elgg_list_entities_from_metadata($options);
	if (!$list) {
		$return['content'] = elgg_echo('phloor_sponsor:none');
	} else {
		$return['content'] = $list;
	}

	return $return;
}



/**
 * Get page components to edit/create a sponsor
 *
 * @param string  $page     'edit' or 'new'
 * @param int     $guid     GUID of phloor_sponsor post or container
 * @return array
 */
function phloor_sponsor_get_page_content_edit($page, $guid = 0) {

	$return = array(
		'filter' => '',
	);

	$vars = array();
	$vars['id'] = 'phloor_sponsor-post-edit';
	$vars['name'] = 'phloor_sponsor_post';
	$vars['class'] = 'elgg-form-alt';

	if ($page == 'edit') {
		$sponsor = get_entity((int)$guid);

		$title = elgg_echo('phloor_sponsor:edit');
		if (elgg_instanceof($sponsor, 'object', 'phloor_sponsor') && $sponsor->canEdit()) {
			$vars['entity'] = $sponsor;

			elgg_push_breadcrumb($sponsor->title, $sponsor->getURL());
			elgg_push_breadcrumb(elgg_echo('edit'));

			$form_vars = array(
				'enctype' => 'multipart/form-data'
			);
			$body_vars = phloor_sponsor_prepare_form_vars($sponsor);
			
			$title .= ": \"$sponsor->title\"";
			// create form
			$content = elgg_view_form('phloor_sponsor/save', $form_vars, $body_vars);
			$sidebar = '';
		} else {
			$content = elgg_echo('phloor_sponsor:error:cannot_edit_sponsor');
			$sidebar = '';
		}
	} else {
		elgg_push_breadcrumb(elgg_echo('phloor_sponsor:add'));

		$form_vars = array(
			'enctype' => 'multipart/form-data',
		);
		$body_vars = phloor_sponsor_prepare_form_vars(null);
		
		$content = elgg_view_form('phloor_sponsor/save', $form_vars, $body_vars);
		$title = elgg_echo('phloor_sponsor:add');
		$sidebar = '';
	}

	$return['title'] = $title;
	$return['content'] = $content;
	$return['sidebar'] = $sidebar;
	return $return;	
}


/**
 * Get page components to list of the user's friends' sponsors.
 *
 * @param int $user_guid
 * @return array
 */
function phloor_sponsor_get_page_content_friends($user_guid) {

	$user = get_user($user_guid);
	if (!$user) {
		forward('phloor_sponsor/all');
	}

	$return = array();

	$return['filter_context'] = 'friends';
	$return['title'] = elgg_echo('phloor_sponsor:title:friends');

	$crumbs_title = $user->name;
	elgg_push_breadcrumb($crumbs_title, "phloor_sponsor/owner/{$user->username}");
	elgg_push_breadcrumb(elgg_echo('friends'));

	elgg_register_title_button();

	if (!$friends = get_user_friends($user_guid, ELGG_ENTITIES_ANY_VALUE, 0)) {
		$return['content'] .= elgg_echo('friends:none:you');
		return $return;
	} else {
		$options = array(
			'type' => 'object',
			'subtype' => 'phloor_sponsor',
			'full_view' => FALSE,
		);

		foreach ($friends as $friend) {
			$options['container_guids'][] = $friend->getGUID();
		}

		$list = elgg_list_entities_from_metadata($options);
		if (!$list) {
			$return['content'] = elgg_echo('phloor_sponsor:none');
		} else {
			$return['content'] = $list;
		}
	}

	return $return;
}

/**
 * Pull together sponsor variables for the save form
 *
 * @param PhloorSponsor       $sponsor
 * @return array
 */
function phloor_sponsor_prepare_form_vars($sponsor = NULL) {
	// input names => defaults
	$values = array(
		'title' => NULL,
		'description' => NULL,
		'image' => NULL,
		'website' => 'http://',
		'tags' => NULL,	
		'access_id' => ACCESS_DEFAULT,
		'container_guid' => NULL,
		'guid' => NULL,
	);

	if ($sponsor) {
		foreach (array_keys($values) as $field) {
			if (isset($sponsor->$field)) {
				$values[$field] = $sponsor->$field;
			}
		}
	}

	if (elgg_is_sticky_form('phloor_sponsor')) {
		$sticky_values = elgg_get_sticky_values('phloor_sponsor');
		foreach ($sticky_values as $key => $value) {
			$values[$key] = $value;
		}
	}
	
	elgg_clear_sticky_form('phloor_sponsor');

	return $values;
}

/**
 * Get sponsor entities via elgg_get_entities
 * 
 * @param unknown_type $sponsor
 */
function phloor_sponsor_get_sponsor_entities($count = false) {
	$params = array(
		'type' => 'object',
		'subtype' => 'phloor_sponsor',
		'offset' => 0,
		'limit' => 999, //PHP_INT_MAX,
	);
	
	if($count == true) {
		$params['count'] = true;
	}
	
	return elgg_get_entities($params);
}

/**
 * Check if entity is instance of PhloorSponsor class
 * 
 * @param unknown_type $sponsor
 */
function phloor_sponsor_instanceof($sponsor) {
	return elgg_instanceof($sponsor, 'object', 'phloor_sponsor', 'PhloorSponsor');
}	

