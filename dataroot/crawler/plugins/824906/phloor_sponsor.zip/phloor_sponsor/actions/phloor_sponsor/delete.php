<?php 
/*****************************************************************************
 * Phloor Sponsor                                                            *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php
/**
 * Delete sponsor entity
 *
 */
// only admins are allowed to delete a sponsor
admin_gatekeeper();

$sponsor_guid = get_input('guid');
$sponsor = get_entity($sponsor_guid);

$url = elgg_get_site_url() . phloor_sponsor_url_handler($sponsor);

if (phloor_sponsor_instanceof($sponsor) && $sponsor->canEdit()) {
	$container = get_entity($sponsor->container_guid);

	$sponsor_image_dir = elgg_get_data_path() . 'phloor_sponsor/';
	
	$files = array(
		$sponsor_image_dir . $sponsor->image,
		$sponsor->thumbnail,
		$sponsor->thumbsmall,
		$sponsor->thumblarge,
	);
	
	// delete sponsor entity
	if ($sponsor->delete()) {
		system_message(elgg_echo('phloor_sponsor:message:deleted_sponsor'));
		
		// delete files
		foreach($files as $file) {
			if(is_file($file) && file_exists($file)) {
				@unlink($file);
				//system_message(elgg_echo('deleted file ') . $file);
			}
		}
		
		// if DID NOT came from object site.. refere him back..
		if(strpos($url, REFERER) === 0) {
			forward(REFERER);
		}
		
		if (elgg_instanceof($container, 'group')) {
			forward("phloor_sponsor/group/$container->guid/all");
		} else {
			forward("phloor_sponsor/owner/$container->username");
		}

		exit();
	} else {
		register_error(elgg_echo('phloor_sponsor:error:cannot_delete_sponsor'));
	}
} else {
	register_error(elgg_echo('phloor_sponsor:error:sponsor_not_found'));
}

forward(REFERER);