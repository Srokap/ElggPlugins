<?php 
/*****************************************************************************
 * Phloor Sponsor                                                            *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php

admin_gatekeeper();

// store errors to pass along
$error = FALSE;
$error_forward_url = REFERER;

// check if upload failed
if (!empty($_FILES['image']['name']) && $_FILES['image']['error'] != 0) {
	register_error(elgg_echo('phloor_sponsor:error:cannotloadimage'));
	forward(REFERER);
}

$sponsor = NULL;
$new_sponsor = TRUE;

// edit or create a new entity
$guid = get_input('guid');
if ($guid) {
	$sponsor = get_entity($guid);
	
	if (!phloor_sponsor_instanceof($sponsor) || !$sponsor->canEdit()) {
		register_error(elgg_echo('phloor_sponsor:error:sponsor_not_found'));
		forward(get_input('forward', REFERER));
		exit;
	}

	$new_sponsor = FALSE;
	
	// delete former image if new image was uploaded
	if (isset ($_FILES['image']['name']) && 
		!empty($_FILES['image']['name'])) {
		// delete old image
		$sponsor->deleteImage();
	}
} else {
	// must have a file if a new file upload
	if (empty($_FILES['image']['name'])) {
		register_error(elgg_echo('file:nofile'));
		forward(REFERER);
		exit;
	}
	
	$sponsor = new PhloorSponsor();
	$new_sponsor = TRUE;
}

// get form inputs from POST var
$params = phloor_sponsor_get_input_vars();

// get 'old' image name (needed when uploading new picture)
$old_image_name = $sponsor->image;

// save settings and display success message
if (phloor_sponsor_save_vars($sponsor, $params)) {
	// remove sticky form entries
	elgg_clear_sticky_form('phloor_sponsor');
	system_message(elgg_echo('phloor_sponsor:message:saved'));

	// delete former image if new image was uploaded
	if (isset ($_FILES['image']['name']) && 
		!empty($_FILES['image']['name'])) {		
		// recreate thumbnails
		$sponsor->recreateThumbnails();
	}
	
	$context = get_input('context', false);
	// if context was admin.. redirect to the REFERER
	if(elgg_is_admin_logged_in() && $context == 'admin') {
		forward($_SERVER['HTTP_REFERER']);
	}
	else {
		forward($sponsor->getURL());
	}	
} 
// ... or display an error message on failures.
else {
	register_error(elgg_echo('phloor_sponsor:error:cannot_save'));
	forward($_SERVER['HTTP_REFERER']);
}
