<?php 
/*****************************************************************************
 * Phloor Sponsor                                                            *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php

$english = array(
	"admin:plugins:category:PHLOOR" => "PHLOOR Plugins",
	'admin:appearance:phloor_sponsor' => 'Sponsors',
	
	'phloor_sponsor' => 'Sponsors',
	'phloor_sponsor:sponsors' => 'Sponsors',
	'phloor_sponsor:phloor_sponsors' => 'Sponsors',

	'phloor_sponsor:enablephloor_sponsor' => 'Enable group sponsors',

	'item:object:phloor_sponsor' => 'Sponsors',

	'phloor_sponsor:admin:appearance:title' => "Your site sponsors",
	'phloor_sponsor:admin:appearance:description' => "Here you can manage the sponsors of your site. ",
	'phloor_sponsor:admin:appearance:entity_count' => "Sponsor count: %s ",
	'phloor_sponsor:admin:appearance:new_sponsor:title' => 'Create new sponsor',

	'phloor_sponsor:title' => 'Name: ',
	'phloor_sponsor:description' => 'Description: ',
	'phloor_sponsor:website' => 'Website: ',
	'phloor_sponsor:image' => 'Image: ',
	'phloor_sponsor:tags' => 'Tags: ',
	'phloor_sponsor:access_id' => 'Read access: ',

	'phloor_sponsor:title:description' => '',
	'phloor_sponsor:description:description' => 'Describe the sponsor in a few words.  ',
	'phloor_sponsor:website:description' => 'Insert the sponsors website. ',
	'phloor_sponsor:image:description' => 'Upload an image. Please consider that in order to display correctly, the resolution of the image should be 180x180 pixel. ',
	'phloor_sponsor:tags:description' => '',
	'phloor_sponsor:access_id:description' => '',

	'phloor_sponsor:message:saved' => 'Sponsor as been successfully created. ',
	'phloor_sponsor:message:deleted_sponsor' => 'Sponsor has been successfully deleted. ',
	'phloor_sponsor:error:cannot_save' => 'Sponsor can not be saved. ',
	'phloor_sponsor:error:cannot_edit_sponsor' => 'Sponsor can not be edited. ',
	'phloor_sponsor:error:cannot_delete_sponsor' => 'Sponsor can not be deleted. ',

	'phloor_sponsor:error:sponsor_not_found' => 'Sponsor not found. ',
	'phloor_sponsor:error:wrong_mimetype' => 'The picture you\'ve uploaded is invalid. Error 483: Invalid mimetype %s ',
	'phloor_sponsor:error:missing:title' => 'Please insert a title. ',
	'phloor_sponsor:error:missing:description' => 'Please insert a description. ',
	'phloor_sponsor:error:missing:image' => 'Please upload an image. ',

	'phloor_sponsor:title:all_phloor_sponsors' => 'All sponsors',
	'phloor_sponsor:title:friends' => 'Friends sponsors',
	'phloor_sponsor:title:user_phloor_sponsors' => 'Your sponsors',

	'phloor_sponsor:edit' => 'Edit',
	'phloor_sponsor:add' => 'Add sponsor',
	'phloor_sponsor:none' => 'No sponsors found. ',	
);

add_translation("en", $english);
