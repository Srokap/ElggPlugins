<?php 
/*****************************************************************************
 * Phloor Sponsor                                                            *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php

$german = array(
	"admin:plugins:category:PHLOOR" => "PHLOOR Plugins",
	'admin:appearance:phloor_sponsor' => 'Sponsoren',
		
	'phloor_sponsor' => 'Sponsoren',
	'phloor_sponsor:sponsors' => 'Sponsoren',
	'phloor_sponsor:phloor_sponsors' => 'Sponsoren',

	'phloor_sponsor:enablephloor_sponsor' => 'Gruppen Sponsoren aktivieren',

	'item:object:phloor_sponsor' => 'Sponsoren',

	'phloor_sponsor:admin:appearance:title' => "Sponsoren Ihrer Seite",
	'phloor_sponsor:admin:appearance:description' => "Hier können Sie die Sponsoren Ihrer Seite verwalten. ",
	'phloor_sponsor:admin:appearance:entity_count' => "Anzahl der Sponsoren: %s ",
	'phloor_sponsor:admin:appearance:new_sponsor:title' => 'Neuen Sponsor erstellen',

	'phloor_sponsor:title' => 'Name: ',
	'phloor_sponsor:description' => 'Beschreibung: ',
	'phloor_sponsor:website' => 'Website: ',
	'phloor_sponsor:image' => 'Bild: ',
	'phloor_sponsor:tags' => 'Tags: ',
	'phloor_sponsor:access_id' => 'Lesezugriff: ',

	'phloor_sponsor:title:description' => '',
	'phloor_sponsor:description:description' => 'Beschreiben Sie den Sponsor mit kanppen, kurzen Worten',
	'phloor_sponsor:website:description' => 'Geben Sie hier die Website des Sponsors ein. ',
	'phloor_sponsor:image:description' => 'Logo hochladen. Bitte beachten Sie, dass Sie, um die korrekte Anzeige zu erhalten, ein Bild mit Auflösung 180x180 Pixel wählen sollten. ',
	'phloor_sponsor:tags:description' => '',
	'phloor_sponsor:access_id:description' => '',

	'phloor_sponsor:message:saved' => 'Sponsor wurde erfolgreich gespeichert. ',
	'phloor_sponsor:message:deleted_sponsor' => 'Sponsor erfolgreich gelöscht. ',
	'phloor_sponsor:error:cannot_save' => 'Sponsor kann gespeichert werden. ',
	'phloor_sponsor:error:cannot_edit_sponsor' => 'Sponsor kann nicht editiert werden. ',
	'phloor_sponsor:error:cannot_delete_sponsor' => 'Sponsor kann gelöscht werden. ',
	'phloor_sponsor:error:sponsor_not_found' => 'Sponsor konnte nicht gefunden werden. ',
	'phloor_sponsor:error:wrong_mimetype' => 'Das angegebene Bild ist invalid. Error 483: Invalid mimetype %s ',
	'phloor_sponsor:error:missing:description' => 'Bitte geben Sie eine Beschreibung für diesen Sponsor ein. ',
	'phloor_sponsor:error:missing:title' => 'Bitte geben Sie einen Namen für diesen Sponsor ein. ',

	'phloor_sponsor:title:all_phloor_sponsors' => 'Alle Sponsoren',
	'phloor_sponsor:title:friends' => 'Sponsoren von Freunden',
	'phloor_sponsor:title:user_phloor_sponsors' => 'Deine Sponsoren',

	'phloor_sponsor:edit' => 'Bearbeiten',
	'phloor_sponsor:add' => 'Sponsor hinzufügen',
	'phloor_sponsor:none' => 'Keine Sponsoren vorhanden. ',	
);

add_translation("de", $german);
