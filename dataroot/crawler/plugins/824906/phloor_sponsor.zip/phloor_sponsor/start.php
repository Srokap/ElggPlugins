<?php 
/*****************************************************************************
 * Phloor Sponsor                                                            *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php
/**
 * Phloor Sponsor
 */

elgg_register_event_handler('init', 'system', 'phloor_sponsor_init', 501);

function phloor_sponsor_init() {
	run_function_once("phloor_sponsor_run_once");
	
	/**
	 * LIBRARY
	 * register a library of helper functions
	 */
	$lib_path = elgg_get_plugins_path() . 'phloor_sponsor/lib/';
	elgg_register_library('phloor-sponsor-lib', $lib_path . 'phloor_sponsor.lib.php');

	/**
	 * Site Menu Item (just for admins)
	 */
	if(elgg_is_admin_logged_in()) {
		$item = new ElggMenuItem('sponsor', elgg_echo('phloor_sponsor:sponsors'), 'phloor_sponsor/all');
		elgg_register_menu_item('site', $item);
	}
	
	/**
	 * Search
	 */
	elgg_register_entity_type('object', 'phloor_sponsor');	
	
	/**
	 * Url handler
	 */
	elgg_register_entity_url_handler('object', 'phloor_sponsor', 'phloor_sponsor_url_handler');
	
	/**
	 * CSS
	 */
	elgg_extend_view('css/admin', 'phloor_sponsor/css/admin');
	elgg_extend_view('css/elgg',  'phloor_sponsor/css/elgg' );
	
	/**
	 * Admin menu
	 */
	elgg_register_admin_menu_item('configure', 'phloor_sponsor', 'appearance');
	
	/**
	 * Entity menu
	 */
	elgg_register_plugin_hook_handler('prepare', 'menu:entity', 'phloor_sponsor_prepare_entity_menu_setup', 999);
	
	/**
	 * Group options
	 
	elgg_extend_view('groups/tool_latest', 'phloor_sponsor/group_module');
	// only admins can see the option to enable sponsors for groups
	if(elgg_is_admin_logged_in()) {
		add_group_tool_option('phloor_sponsor', elgg_echo('phloor_sponsor:enablephloor_sponsor'), false);
	}*/
	
	/**
	 * Actions
	 */
	$action_path = elgg_get_plugins_path() . 'phloor_sponsor/actions/phloor_sponsor';
	elgg_register_action('phloor_sponsor/save', "$action_path/save.php", 'admin');
	elgg_register_action('phloor_sponsor/delete', "$action_path/delete.php", 'admin');

	/**
	 * Page handler
	 */
	global $CONFIG;
	elgg_register_page_handler('phloor_sponsor', 'phloor_sponsor_page_handler');
	if (!isset($CONFIG->pagehandler['sponsors'])) {
		elgg_register_page_handler('sponsors', 'phloor_sponsor_page_handler');
	}
	
	elgg_load_library('phloor-sponsor-lib');
}

/**
 * Adds the 'phloor_sponsor' subtype
 */
function phloor_sponsor_run_once() {
	add_subtype('object', 'phloor_sponsor', 'PhloorSponsor');
}

/**
 * 
 * Page handler for 'phloor_sponsor'
 * and (if not overwritten) 'sponsor'
 * 
 * @param unknown_type $page
 */
function phloor_sponsor_page_handler($page) {
	// push 'all' sponsors breadcrumb
	elgg_push_breadcrumb(elgg_echo('phloor_sponsor:sponsors'), "phloor_sponsor/all");

	if (!isset($page[0])) {
		$page[0] = 'all';
	}

	$page_type = $page[0];
	switch ($page_type) {
		case 'owner':
			$user = get_user_by_username($page[1]);
			$params = phloor_sponsor_get_page_content_list($user->guid);
			break;
		case 'group':
			$group = get_entity($page[1]);
			if(!elgg_instanceof($group, 'group')) {
				return false;
			}
			$params = phloor_sponsor_get_page_content_list($group->guid);
			break;
		case 'friends':
			$user = get_user_by_username($page[1]);
			$params = phloor_sponsor_get_page_content_friends($user->guid);
			break;
		case 'view':
			$params = phloor_sponsor_get_page_content_read($page[1]);
			break;
		case 'add':
			admin_gatekeeper();
			$params = phloor_sponsor_get_page_content_edit($page_type, $page[1]);
			break;
		case 'edit':
			admin_gatekeeper();
			$params = phloor_sponsor_get_page_content_edit($page_type, $page[1]);
			break;
		case 'all':
			$params = phloor_sponsor_get_page_content_list();
			break;
		default:
			return false;
	}

	if (isset($params['sidebar'])) {
		$params['sidebar'] .= elgg_view('phloor_sponsor/sidebar', array('page' => $page_type));
	} else {
		$params['sidebar'] = elgg_view('phloor_sponsor/sidebar', array('page' => $page_type));
	}

	$body = elgg_view_layout('content', $params);

	echo elgg_view_page($params['title'], $body);
	
	return true;
}

/**
 * Add/remove particular phloor_sponsor links/info to entity menu
 * 
 * @param unknown_type $hook
 * @param unknown_type $type
 * @param unknown_type $return
 * @param unknown_type $params
 */
function phloor_sponsor_prepare_entity_menu_setup($hook, $type, $return, $params) {
	$entity = elgg_extract('entity', $params, false);
	if(!phloor_sponsor_instanceof($sponsor)) {
		return $return;
	}
	
	$handler = elgg_extract('handler', $params, false);
	
	
	// unregister following menu items
	$unregister_items = array( 
		'likes', 'likes_count',
	);
	
	foreach ($return as $index => $section) {		
		if(is_array($section)) {
			foreach($section as $key => $item) {
				if(in_array($item->getName(), $unregister_items)) {
					unset($return[$index][$key]);
				}
			}
		}
	}

	return $return;
}

/**
 * Format and return the URL for sponsors.
 *
 * @param PhloorSponsor $entity sponsor object
 * @return string URL of sponsor.
 */
function phloor_sponsor_url_handler($entity) {
	if (!$entity->getOwnerEntity()) {
		// default to a standard view if no owner.
		return FALSE;
	}

	$friendly_title = elgg_get_friendly_title($entity->title);
	return "phloor_sponsor/view/{$entity->guid}/$friendly_title";
}
