<?php 
/*****************************************************************************
 * Phloor Sponsor                                                            *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 

/**
 * 
 */
// start elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

// get sponsor guid from GET params
$sponsor_guid = (int) get_input('sponsor_guid', 0);
// get sponsor entity
$sponsor = get_entity($sponsor_guid);
// check that its an instance of the Class Sponsor
if (elgg_instanceof($sponsor, 'object', 'phloor_sponsor', 'PhloorSponsor')) {
	// get size from GET params	
	$size = get_input('size', 'medium');

	$sponsor_image = '';
	switch($size) {
		case 'tiny':
		case 'small':
			$sponsor_image = $sponsor->thumbnail;
			break;
		case 'large':
			$sponsor_image = $sponsor->thumblarge;
			break;
		case 'medium':
		default:
			$sponsor_image = $sponsor->thumbsmall;
			//break;
			// orginal image (should never be viewed
			// as the size defaults to 'large')
			//$sponsor_image_dir = elgg_get_data_path() . 'phloor_sponsor/';
			//$sponsor_image = $sponsor_image_dir . $sponsor->image;
	}
	
	// check if the image file exists and display it
	if (file_exists($sponsor_image) && is_file($sponsor_image)) {
		// get file contents;
		$contents = file_get_contents($sponsor_image);
	
		// caching images for 10 days
		header("Content-type: image/jpeg");
		header('Expires: ' . date('r', time() + 864000));
		header("Pragma: public", true);
		header("Cache-Control: public", true);
		header("Content-Length: " . strlen($contents));
	
		echo $contents;
		exit();
	}
}
