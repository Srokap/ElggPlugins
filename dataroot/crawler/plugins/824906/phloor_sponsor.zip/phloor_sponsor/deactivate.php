<?php
/**
 * Deregister the PhloorSponsor
 */

update_subtype('object', 'phloor_sponsor');
