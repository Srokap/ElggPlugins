<?php
/**
 * Register the PhloorSponsor class
 */

if (get_subtype_id('object', 'phloor_sponsor')) {
	update_subtype('object', 'phloor_sponsor', 'PhloorSponsor');
} else {
	add_subtype('object', 'phloor_sponsor', 'PhloorSponsor');
}
