profile_url
===========

Member profile urls in the form of &lt;base_url>/&lt;username>

Changes:

1.1 - reduced sloc count to 27!
    - fixed 404's when username contains a dot