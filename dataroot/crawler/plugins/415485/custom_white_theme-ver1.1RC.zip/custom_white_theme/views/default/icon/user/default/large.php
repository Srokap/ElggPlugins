<?php
	echo $vars['url'] . "mod/custom_white_theme/graphics/user_icons/defaultlarge.gif";
?>