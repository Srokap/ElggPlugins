<?php
function randomquote_init() {        
    elgg_register_widget_type('randomquote', 'Random SK Quote', 'The "Random SK Quote" widget');
}
 
elgg_register_event_handler('init', 'system', 'randomquote_init');       
?>