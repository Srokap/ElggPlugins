<center>
<?php
//Chooses a random number 
$num = Rand (1,34); 
//Based on the random number, gives a quote 
switch ($num)
{
case 1:
echo "<b>It wasn't as dark and scary as it sounds. i had a lotto fun...killing somebody's a funny experience <BR> <font color=#aa0000>Albert de salvo</b></font>";
break;
case 2:
echo "<b>I didn't want to hurt them, I only wanted to kill them.</b> <BR> <b><font color=#aa0000>David Berkowitz</b></font>";
break;
case 3:
echo "<b>We serial killers are your sons, we are your husbands, we are everywhere. and there will be more of your children dead tomorrow</b> <BR> <b><font color=#aa0000>Ted Bundy</b></font>";
break;
case 4:
echo "<b>I always had the desire to inflict pain on others and to have others inflict pain on me. I always seemed to enjoy everything that hurt. The desire to inflict pain, that is all that is uppermost</b> <BR> <b><font color=#aa0000>Albert Fish</b></font>";
break;
case 5:
echo "<b>To me, this world is nothing but evil, and my own evil just happened to come out cause of the circumstances of what I was doing. <BR> <font color=#aa0000>Aileen Wuornos</font></b>";
break;
case 6:
echo "<b>None of us are saints. <BR> <font color=#aa0000>Albert Fish</b></font>";
break;
case 7:
echo "<b>People don't know me. They think they do, but they don't. <BR> <font color=#aa0000>Andrew Cunanan</b></font>";
break;
case 8:
echo "<b>When this monster entered my brain, I will never know, but it is here to stay. How does one cure himself? I can't stop it, the monster goes on, and hurts me as well as society. Maybe you can stop him. I can't. <BR> <font color=#aa0000>BTK</b></font>";
break;
case 9:
echo "<b>Look down on me, you will see a fool. Look up at me, you will see your Lord. Look straight at me, you will see yourself. <BR> <font color=#aa0000>Charles Manson</b></font>";
break;
case 10:
echo "<b>The more I looked at people, the more I hated them. <BR> <font color=#aa0000>Charles Starkweather</b></font>";
break;
case 11:
echo "<b>I have got to say this, it felt really, really, really good. One of the best things I have done in my life. <BR> <font color=#aa0000>Daniel Gonzalez</b></font>";
break;
case 12:
echo "<b>People like me don't come from films. Them films come from people like me. <BR> <font color=#aa0000>David Harker</b></font>";
break;
case 13:
echo "<b>People are like maggots, small, blind and worthless. <BR> <font color=#aa0000>David Smith</b></font>";
break;
case 14:
echo "<b>Even when she was dead, she was still bitching at me. I couldn't get her to shut up! <BR> <font color=#aa0000>Ed Kemper</b></font>";
break;
case 15:
echo "<b>Do I look like the Green River Killer? <BR> <font color=#aa0000>Gary Ridgeway</b></font>";
break;
case 16:
echo "<b>I can't stand a bitchy chick. <BR> <font color=#aa0000>Gerald Stano</b></font>";
break;
case 17:
echo "<b>I was born with the devil in me. I could not help the fact that I was a murderer, no more than the poet can help the inspiration to sing..I was born with the evil one standing as my sponsor beside the bed where I was ushered into the world, and he has been with me since. <BR> <font color=#aa0000>H.H Holmes</b></font>";
break;
case 18:
echo "<b>God didn't say to mutilate her. He just said to hit her until she was dead. <BR> <font color=#aa0000>Harvey Carnigan</b></font>";
break;
case 19:
echo "<b>I'm not dangerous now, but I won't say that I wouldn't be tomorrow. <BR> <font color=#aa0000>Harvey Carnigan</b></font>";
break;
case 20:
echo "<b>Every man to his own tastes. Mine is for corpses. <BR> <font color=#aa0000>Henry Blot</b></font>";
break;
case 21:
echo "<b>Satan gets into people and makes them do things they don't want to. <BR> <font color=#aa0000>Herbert Mullin</b></font>";
break;
case 22:
echo "<b>That is my ambition, to have killed more people<BR>more helpless people<BR>than any man or woman who has ever lived. <BR> <font color=#aa0000>Jane Toppan</b></font>";
break;
case 23:
echo "<b>I will in all probability be convicted,but I will not go away as a monster,but as a tragedy. <BR> <font color=#aa0000>Joel Rifkin</b></font>";
break;
case 24:
echo "<b>As I grew up I realized, though imperfectly, that I was different from other people, and that the way of life in my home was different from that in the homes of others....This stimulated me to introspection and strange mental questionings. <BR> <font color=#aa0000>John Haigh</b></font>";
break;
case 25:
echo "<b>For me a corpse has a beauty and dignity which a living body could never hold . . . there is a peace about death that soothes me. <BR> <font color=#aa0000>John Christie</b></font>";
break;
case 26:
echo "<b>There is no happiness without tears,no life without death.Beware! I am going to make you cry. <BR> <font color=#aa0000>Lucian Staniak</b></font>";
break;
case 27:
echo "<b>I shan't shed a tear. Life is full of shocks of all descriptions and they have to be faced. <BR> <font color=#aa0000>Patrick Mackay</b></font>";
break;
case 28:
echo "<b>Even psychopaths have emotions, then again, maybe not. <BR> <font color=#aa0000>Richard Ramirez</b></font>";
break;
case 29:
echo "<b>You maggots make me sick, I will be avenged. Lucifer dwells within us all. <BR> <font color=#aa0000>Richard Ramirez</b></font>";
break;
case 30:
echo "<b>We've all got the power in our hands to kill, but most people are afraid to use it. The ones who aren't afraid, control life itself. <BR> <font color=#aa0000>Richard Ramirez</b></font>";
break;
case 31:
echo "<b>I have an obsession with the unattainable. I have to eliminate what I cannot attain. <BR> <font color=#aa0000>Robert Barto</b></font>";
break;
case 32:
echo "<b>When I'm hurting somebody, I want to see them. I want to crash their skull. And I want to get them with that knife. And I like to hear the sounds of the pounding. And I like to see the breathing when I'm killing them. And when I'm killing somebody, I don't care I'm killing them. <BR> <font color=#aa0000>Sean Hanify</b></font>";
break;
case 33:
echo "<b>We all go a little mad sometimes. <BR> <font color=#aa0000>Ted Bundy</b></font>";
break;
case 34:
echo "<b>Take your worst nightmares, and put my face to them. <BR> <font color=#aa0000>Tommy Lynn Sells</b></font>";

}
?>