<?php

	/* Elgg 174test template */
	
	
	/* Initialise the theme */
	function socialpro_init(){
	
	}
	
	// Initialise log browser
	register_elgg_event_handler('init','system','socialpro_init');
	
?>