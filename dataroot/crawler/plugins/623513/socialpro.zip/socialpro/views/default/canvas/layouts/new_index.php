<?php

	/**
	 * Elgg custom profile 
	 * You can edit the layout of this page with your own layout and style. Whatever you put in the file
	 * will replace the frontpage of your Elgg site.
	 * 
	 * @package Elgg
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.org/
	 
	 * Elgg custom template devloped by Shouvik Mukherjee
	 * http://ishouvik.com
	 */
	 
?>

<?php if (isloggedin()) { 
	forward("pg/dashboard/");  //forwards logged-in users to riverdashboard
 } else
  { ?>
  
  
<div id="custom_index">

	<div id="welcome">
    	<div id="welcome_right">
			<?php
	            //this displays some content when the user is logged out
			    if (!isloggedin()){
	            	//display the login form
			    	echo $vars['area1'];
			    	echo "<div class=\"clearfloat\"></div>";
		        }
	        ?>
        
        </div> <!-- /welcome-right -->
    	<div id="welcome_left">
            <div id="left_content">
            	<h1>Get Conntected!</h1>
                <ul>
                	<li>Connect and expand your network</li>
                    <li>Share your status on <i>Wire</i></li>
                    <li>View profiles and add new friends</li>
                    <li>Share your photos and videos</li>
                    <li>Create your group orjoin others'</li>
                </ul>
            
            </div> <!-- /left content -->
            <a class="joinnow" href="<?php echo $vars['url']; ?>account/register.php" >Join Now</a>
        </div> <!-- /welcome_left -->
    
    </div> <!-- /welcome -->
 
    <!-- left column content -->
    <div id="index_left">
    	<div id="activity">
				<h2>Recent Activity</h2>
				<?php 
                  
                  $num_items = $vars['entity']->num_items;
                  if (!isset($num_items)) $num_items = 5;
                  
                  
                  $widgtet_datas = elgg_view_river_items(0, $widget_group, '', '', '', '', $num_items,0,0,false);
                  
                ?>        
                
                <div class="contentWrapper">
                  <?php 
                      if(isset($widgtet_datas)) {
                          echo $widgtet_datas;
                      }
                  ?>
                  <div class="clearfloat"></div>
        	</div>
         </div>
   


    	</div>

    </div>
    
    <!-- right hand column -->
    <div id="index_right">
        <!-- more content -->
	    <?php
            //include a view that plugins can extend
            echo elgg_view("index/righthandside");
        ?>
        <!-- latest members -->
        <div class="index_box">
            <h2><?php echo elgg_echo("custom:members"); ?></h2>
            <div class="contentWrapper">
            <?php 
                if(isset($vars['area3'])) {
                    //display member avatars
                    foreach($vars['area3'] as $members){
                        echo "<div class=\"index_members\">";
                        echo elgg_view("profile/icon",array('entity' => $members, 'size' => 'small'));
                        echo "</div>";
                    }
                }
            ?>
	        <div class="clearfloat"></div>
	        </div>
        </div>
        
        
        
        <?php
	
	
    if(is_plugin_enabled('groups')){
?> 
        <!-- display latest groups -->
	    <div class="index_box">
            <h2><?php echo elgg_echo("custom:groups"); ?></h2>
        <?php 
                if (!empty($vars['area5'])) {
                    echo $vars['area5'];//this will display groups
                }else{
                    echo "<p><?php echo elgg_echo('custom:nogroups'); ?>.</p>";
                }
            ?>
      </div>  
        
<?php
}
 }   
?> 
        
    </div>
    <div class="clearfloat"></div>
</div>