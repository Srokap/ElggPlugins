default theme in RTL

my website : www.lofol.com

i just edit css file for RTL Default theme Elgg 

