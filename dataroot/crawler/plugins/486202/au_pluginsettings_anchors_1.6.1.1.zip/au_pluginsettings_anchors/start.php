<?php
/**
 * Simple Elgg Plugin to override pluginsettings view
 * to add anchors for each plugin.
 *
 * @author Brian Jorgensen (brian@moosetrout.com)
 * @copyright 2010 Brian Jorgensen
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 */