<?php 
	$widget = $vars['widget'];
	$widget->id = $widget->name;
	
	if($widget instanceof ElggObject && $widget->getSubtype() == GROUP_CUSTOM_LAYOUT_WIDGET){
		$available_widgets = get_register('group_widgets');
		
		$widget->name = $widget->title;
		$widget->id = $widget->guid;
		$widget->value = $available_widgets[$widget->name]->value;  
	}
?>
<table class="draggable_group_widget" id="group_widget_<?php echo $widget->id;?>"> 
	<tr>
		<td>
			<h3><?php echo elgg_echo("group_custom_layout:widgets:" . $widget->name . ":title");?></h3>
			<input type="hidden" value="<?php echo $widget->value; ?>" name="description"/>
			<?php
				// show settings if available
				if($settings = elgg_view("group_widgets/" . $widget->name . "/edit" , array("widget_name" => $widget->name, "entity" => $widget))){
					//echo "<a class='fancybox' href='#group_widget_" . $widget->id . "_settings'>" . elgg_echo("group_custom_layout:widgets:edit") . "</a>";
					echo "<a class='thickbox' href='#TB_inline?height=300&width=300&inlineId=group_widget_" . $widget->id . "_settings'>" . elgg_echo("group_custom_layout:widgets:edit") . "</a>";
					echo "<div id='group_widget_" . $widget->id . "_settings' class='group_custom_layout_widget_settings'>" . $settings;
					//echo "<br /><input type='button' class='submit_button' value='" . elgg_echo("Ok") . "' onclick='$.fn.fancybox.close()'/>";
					echo "</div>";
				}
			?>
		</td>

		<td align="right" width="17"><a href="#"><img height="14" width="14" class="more_info" src="<?php echo $CONFIG->wwwroot;?>_graphics/spacer.gif"/></a></td>
		<td align="right" width="17"><a href="#"><img height="15" width="15" class="drag_handle" src="<?php echo $CONFIG->wwwroot;?>_graphics/spacer.gif"/></a></td>
		</tr>
</table>