<?php 
$group = $vars["group"];

if(is_plugin_enabled("event_calender") && $group->event_calendar_enable != "no"){
	
	$widget = $vars["widget"];
	
	// Get the upcoming events
	$start_date = time(); // now
	$end_date = $start_date + 60*60*24*365*2; // maximum is two years from now
	
	$events = event_calendar_get_events_between($start_date, $end_date, false, $widget->event_count, 0, $group->guid);
	
?>
<div class="contentWrapper">
	<h2><?php echo elgg_echo("event_calendar:groupprofile"); ?></h2>
	<?php 
		// If there are any events to view, view them
		if(!empty($events)) {
			foreach($events as $event) {
				echo elgg_view("object/event_calendar", array('entity' => $event));
			}
		}
	?>
	<div class="forum_latest">
		<a href="<?php echo $vars['url']; ?>pg/event_calendar/group/<?php echo $group->guid; ?>"><?php echo elgg_echo('event_calendar:view_calendar'); ?></a>
	</div>
</div>

<?php } ?>