<?php 
	$entity = $vars["entity"];
	
	if(!empty($entity) && $entity instanceof ElggObject && $entity->getSubtype() == GROUP_CUSTOM_LAYOUT_WIDGET){
		$widget_name = $entity->guid;
		$tweet_count = $entity->tweet_count;
	} else {
		$widget_name = $vars["widget_name"];
		$tweet_count = 4;
	}
	
	$options = "";
	for($i = 1; $i <= 10; $i++){
		if($i == $tweet_count){
			$options .= "<option value='" . $i . "' selected='yes'>" . $i . "</option>\n";
		} else {
			$options .= "<option value='" . $i . "'>" . $i . "</option>\n";
		}
	}
	
?>
<h3 class="settings"><?php echo elgg_echo("group_custom_layout:widgets:twitter:settings:title"); ?></h3>
<div>
	<?php echo elgg_echo("group_custom_layout:widgets:twitter:settings:twitter_username"); ?><br />
	<input type="text" name="group_widgets_<?php echo $widget_name; ?>_settings[twitter_username]" value="<?php echo $entity->twitter_username; ?>" size="15" maxlenght="100"/><br />
	<?php echo elgg_echo("group_custom_layout:widgets:twitter:settings:tweet_count"); ?>
	<select name="group_widgets_<?php echo $widget_name; ?>_settings[tweet_count]">
		<?php echo $options; ?>
	</select>
</div>