<?php 
$group = $vars["group"];

if(is_plugin_enabled("blog")){
	$widget = $vars["widget"];
	echo elgg_view('blog/groupprofile_blog', array('entity' => $group));
}