<?php 
	global $CONFIG;
	$available_widgets = get_register('group_widgets');
	$layout = $vars['group_custom_layout'];
	
	if(!empty($layout->left_widgets)){
		$left_widgets = explode(",", $layout->left_widgets);
	}
	if(!empty($layout->right_widgets)){
		$right_widgets = explode(",", $layout->right_widgets);
	}
	
?>

<div id="group_layout_editpanel">
	<div id="customise_page_view">
		
		<table>
			<tbody>
				<tr>
					<td>
						<h2><?php echo elgg_echo("widgets:leftcolumn"); ?></h2>
						<div id="leftcolumn_widgets">
						<?php 
							foreach($left_widgets as $widget_guid){
								$widget = get_entity($widget_guid);
								echo elgg_view("group_custom_layout/widget_wrapper", array('widget'=>$widget));
							}
						?>
						</div>
					</td>
					<td>
						<h2><?php echo elgg_echo("widgets:rightcolumn"); ?></h2>
						<div id="middlecolumn_widgets">
						<?php 
							foreach($right_widgets as $widget_guid){
								$widget = get_entity($widget_guid);
								echo elgg_view("group_custom_layout/widget_wrapper", array('widget'=>$widget));
							}
						?>
						</div>
					</td>
					<td align="left" valign="top" rowspan="2">
						<h2><?php echo elgg_echo("widgets:gallery"); ?></h2>
						<div id="rightcolumn_widgets">
						
							<?php
								
								foreach($available_widgets as $widget){

									echo elgg_view("group_custom_layout/widget_wrapper", array('widget'=>$widget, 'group_custom_layout' => $layout));			
								}
							?>
						</div>
				    </td>
				</tr>
			</tbody>
		</table>
	</div>
</div>