<?php 
	global $CONFIG;
	$entity = $vars["entity"];
	
	if(!empty($entity) && $entity instanceof ElggObject && $entity->getSubtype() == GROUP_CUSTOM_LAYOUT_WIDGET){
		$widget_name = $entity->guid;
		$rss_count = $entity->rss_count;
	} else {
		$widget_name = $vars["widget_name"];
		$rss_count = 4;
	}
	
	$options = "";
	for($i = 1; $i <= 10; $i++){
		if($i == $rss_count){
			$options .= "<option value='" . $i . "' selected='yes'>" . $i . "</option>\n";
		} else {
			$options .= "<option value='" . $i . "'>" . $i . "</option>\n";
		}
	}
	
	$compat_url = $CONFIG->wwwroot . "mod/group_custom_layout/vendors/simplepie/sp_compatibility_test.php";
	$permit_url = $CONFIG->wwwroot . "mod/group_custom_layout/vendors/simplepie/permissions.php";
?>
<h3 class="settings"><?php echo elgg_echo("group_custom_layout:widgets:rss:settings:title"); ?></h3>
<div>
	<?php echo elgg_echo("group_custom_layout:widgets:rss:settings:rssfeed"); ?><br />
	<input type="text" name="group_widgets_<?php echo $widget_name; ?>_settings[rssfeed]" value="<?php echo $entity->rssfeed; ?>" size="40" maxlenght="250"/><br />
	
	<?php echo elgg_echo("group_custom_layout:widgets:rss:settings:rss_count"); ?>
	<select name="group_widgets_<?php echo $widget_name; ?>_settings[rss_count]">
		<?php echo $options; ?>
	</select><br />
	
	<?php echo elgg_echo("group_custom_layout:widgets:rss:settings:excerpt"); ?>
	<select name="group_widgets_<?php echo $widget_name; ?>_settings[excerpt]">
		<option value="no" <?php if($entity->excerpt == "no"){ echo "selected='yes'"; } ?>><?php echo elgg_echo("option:no"); ?></option>
		<option value="yes" <?php if(empty($entity->excerpt) || $entity->excerpt != "no"){ echo "selected='yes'"; } ?>><?php echo elgg_echo("option:yes"); ?></option>
	</select><br />
	
	<?php echo elgg_echo("group_custom_layout:widgets:rss:settings:post_date"); ?>
	<select name="group_widgets_<?php echo $widget_name; ?>_settings[post_date]">
		<option value="no" <?php if($entity->post_date == "no"){ echo "selected='yes'"; } ?>><?php echo elgg_echo("option:no"); ?></option>
		<option value="yes" <?php if(empty($entity->post_date) || $entity->post_date != "no"){ echo "selected='yes'"; } ?>><?php echo elgg_echo("option:yes"); ?></option>
	</select><br /><br />
	
	<?php if(isadminloggedin()){ ?>
	<p>
		<a href="<?php echo $compat_url; ?>" target="_blank"><?php echo elgg_echo("group_custom_layout:widgets:rss:settings:compatibility"); ?></a><br />
		<a href="<?php echo $permit_url; ?>" target="_blank"><?php echo elgg_echo("group_custom_layout:widgets:rss:settings:permission"); ?></a>
	</p>
	<?php } ?>
</div>