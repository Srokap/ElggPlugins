<?php 
$group = $vars["group"];

if(is_plugin_enabled("izap_videos") && $group->izap_videos_enable != "no"){
	
	$widget = $vars["widget"];
	
?>
<div class="contentWrapper">
	<h2><?php echo elgg_echo('izap_videos:groupvideos'); ?></h2>
	<?php 
		$shares = get_entities('object', 'izap_videos', $group->guid, "", $widget->video_count);
		
		if(!empty($shares)){
			
			foreach($shares as $s){
				//	$izap_videos_image = $CONFIG->wwwroot . "mod/izap_videos/thumbs.php?what=image&id=" . $s->getGUID();			
				$dir = substr(strrchr($s->getUrl(), "/"), 1);
			      	$izap_videos_image = $CONFIG->wwwroot . "/pg/izap_videos_files/image/" . $s->getGUID() . "/" . $dir;

				$owner = $s->getOwnerEntity();
				$friendlytime = friendly_time($s->time_created);
				$icon = '<img src="'.$izap_videos_image.'" height="40" width="40">';
				
				echo "<div class='forum_latest'>";
				
				echo "<div class='izap_shares_widget_icon'>";
				echo "<a href='" . $s->getUrl() . "' class='screenshot' rel='" . $izap_videos_image . "'>" . $icon . "</a>";
				echo "</div>";
				
				echo "<div>";
				?>
				<p class="izap_shares_title">
					<a href="<?php echo $s->getUrl(); ?>" class="screenshot" rel="<?php echo $izap_videos_image; ?>"><?php echo substr($s->title,0,30); ?>..</a>
				</p>
				<p class="izap_shares_timestamp" align="right">
					<small>
						<!--
							<a href="<?php echo $owner->getUrl(); ?>"> by : <?php echo $owner->name; ?></a>
						-->
						<?php echo $friendlytime; ?>
					</small>
				</p>
				<?php
				echo "</div>";
				
				echo "<div class='clearfloat'></div>";
				echo "</div>";
				
			}
			
			$user_inbox = $CONFIG->wwwroot . "pg/izap_videos/" . $group->username;
			echo "<div class='forum_latest' align='right'>";
			echo "<a href='" . $user_inbox . "'>" . elgg_echo('izap_videos:everyone') . "</a>";
			echo "</div>";
			
		} else {
			echo '<div class="forum_latest">' . elgg_echo('izap_videos:notfound') . '</div>';
		}
		
	?>
</div>

<?php } ?>
