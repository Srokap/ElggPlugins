<?php 
	$group = $vars["group"];
	$widget = $vars["widget"];
	
?>
<div class="contentWrapper">
	<?php 
		if(!empty($widget->widget_title)){
			echo "<h2>" . $widget->widget_title . "</h2>";
		}
		
		echo $widget->html_content;
	?>
</div>