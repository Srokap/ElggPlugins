<?php 
$group = $vars["group"];

if(is_plugin_enabled("groupriver")){
	$widget = $vars["widget"];
	echo elgg_view('groupriver/groupprofile', array('entity' => $group));
}