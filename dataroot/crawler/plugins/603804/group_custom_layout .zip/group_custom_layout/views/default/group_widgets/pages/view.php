<?php 
$group = $vars["group"];

if(is_plugin_enabled("pages") && $group->pages_enable != "no"){
	
	$widget = $vars["widget"];
	
?>
<div class="contentWrapper">
<h2><?php echo elgg_echo("pages:groupprofile"); ?></h2>
<?php

    $objects = list_entities("object", "page_top", $group->guid, $widget->page_count, false, false, false);
	
    if(!empty($objects)){
		echo $objects;
    } else {
		echo "<div class=\"forum_latest\">" . elgg_echo("pages:nogroup") . "</div>";
    }
	
?>
</div>

<?php } ?>