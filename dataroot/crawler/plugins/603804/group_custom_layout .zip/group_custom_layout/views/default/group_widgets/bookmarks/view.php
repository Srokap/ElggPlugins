<?php 

$group = $vars["group"];

if(is_plugin_enabled("bookmarks") && $group->bookmarks_enable != "no"){

	$widget = $vars["widget"];
?>
<script type="text/javascript">
	$(document).ready(function () {
		$('a.share_more_info').click(function () {
			$(this.parentNode).children("[class=share_desc]").slideToggle("fast");
			return false;
		});
	});
</script>



<div class="group_widget">
<h2><?php echo elgg_echo('bookmarks:group'); ?></h2>
<?php
	$context = get_context();
	set_context('search');
	$content = elgg_list_entities(array('types' => 'object',
										'subtypes' => 'bookmarks',
										'container_guid' => $group->guid,
										'limit' => 5,
										'full_view' => FALSE,
										'pagination' => FALSE));
	set_context($context);

    if ($content) {
		echo $content;

		$more_url = "{$vars['url']}pg/bookmarks/group:{$group->guid}/items/";
		echo "<div class=\"forum_latest\"><a href=\"$more_url\">" . elgg_echo('bookmarks:more') . "</a></div>";
	} else {
		echo "<div class=\"forum_latest\">" . elgg_echo("bookmarks:nogroup") . "</div>";
	}
?>
</div>



<?php } ?>
