<?php 
 
	$group = $vars["group"];
	$layout = $vars["layout"];
        $img1_url = elgg_add_action_tokens_to_url($CONFIG->wwwroot . "action/group_custom_layout/get_background?group_guid=" . $group->guid . "&image_id=1");
        $img2_url = elgg_add_action_tokens_to_url($CONFIG->wwwroot . "action/group_custom_layout/get_background?group_guid=" . $group->guid . "&image_id=2");

?>
<style type="text/css">
	<?php if(!empty($layout->enable_background1) && $layout->enable_background1 == "yes"){ ?>
	body {background-image: url(<?php echo $img1_url ?>) !important;
background-repeat: <?php echo $layout->background1Repeat ?>;
background-position: <?php echo $layout->background1Position ?>;	
background-attachment: <?php echo $layout->background1Attachment ?>;		}
	<?php } ?>
	
	<?php if(!empty($layout->enable_background2) && $layout->enable_background2 == "yes"){ ?>
	#two_column_left_sidebar_maincontent {background-image: url(<?php echo $img2_url ?>) !important;
background-repeat: <?php echo $layout->background2Repeat ?>;
background-position: <?php echo $layout->background2Position ?>;	
background-attachment: <?php echo $layout->background2Attachment ?>;		}
	<?php } ?>

	



	<?php if(!empty($layout->enable_colors) && $layout->enable_colors == "yes"){ ?>
	#two_column_left_sidebar_maincontent_boxes,
	#two_column_left_sidebar_boxes .sidebarBox,
	#left_column .contentWrapper,
	#right_column .contentWrapper,
        .group_widget,  #group_river_widget, #group_stats   {
		background: <?php echo $layout->background_color; ?> !important;
		border: 1px solid <?php echo $layout->border_color; ?> !important; 
	}
	
	#page_wrapper h1,
	#page_wrapper h1 a,
	#page_wrapper h2,
	#page_wrapper h2 a,
	#page_wrapper h3,
	#page_wrapper h3 a,
	#page_wrapper h4, 
	#page_wrapper h4 a{
		color: <?php echo $layout->title_color; ?>;
	}
	
	
	<?php } ?>
	
	#left_column .contentWrapper,
	#right_column .contentWrapper {
		padding: 5px !important;
		margin: 0 0 10px !important;
	}
</style>
