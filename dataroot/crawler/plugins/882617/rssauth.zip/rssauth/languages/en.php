<?php

$english = array(
    'rssauth' => "RSSAuth",
    'rssauth:option:get_auth' => "Allow authentication through the URL (\$_GET variables)? (note: this is insecure)",
    'rssauth:option:authfail' => "What to do if username/password are incorrect?",
    'rssauth:option:authfail:default' => "Display public rss feed",
    'rssauth:option:authfail:forceauth' => "Re-display login box and force authentication"
);
					
add_translation("en",$english);
