<?php
/**
 * RSS image block view
 *
 * Only display the body
 */
echo $vars['body'];