<?php
/**
 * RSS url output view
 * 
 */
echo elgg_view('output/url', $vars, false, false, 'default');
