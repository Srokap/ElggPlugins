<?php
/*
 * RSS gallery view
 *
 * @uses $vars['items']
 */

echo elgg_view('page/components/list', $vars);
