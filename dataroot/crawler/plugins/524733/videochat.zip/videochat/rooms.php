<?php

        /**
         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         */

        // Load Elgg engine
                require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

                $area2 = elgg_view_title(elgg_echo("videochat:rooms"));

                //add form
                $area2 .= elgg_view("videochat/forms/add");

                $options = array();
                $options['types']='object';
                $options['subtypes']='videochat';
                
                $area2 .= elgg_list_entities($options);
                
    $body = elgg_view_layout("two_column_left_sidebar", '', $area2);

        // Display page
                page_draw(elgg_echo('videochat:rooms'),$body);

?>
