<?php
	$english = array(
			'videochat' => "Video Chat",
 			'item:object:videochat' => "Video Chat Rooms",
      'videochat:rooms' => "Video Chat Rooms",
      'videochat:create' => "Create Video Chat Room",
      'videochat:charleft' => "Characters Left",
      'videochat:river:created' => "%s created video chat room:",
      'videochat:number' => "Rooms to show",
      'videochat:name' => "Room Name",
      'videochat:description' => "Room Description",
      'videochat:room_exists' => "Room %s already exists. Try another room name!",
	);

	add_translation("en",$english);

?>