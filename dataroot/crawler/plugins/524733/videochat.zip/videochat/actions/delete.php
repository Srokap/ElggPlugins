<?php

	// Make sure we're logged in (send us to the front page if not)
		if (!isloggedin()) forward();

	// Get input data
		$guid = (int) get_input('videochatroom');

	// Make sure we actually have permission to edit
		$videochat = get_entity($guid);
		if ($videochat->getSubtype() == "videochat" && $videochat->canEdit()) {

		// Get owning user
				$owner = get_entity($videochat->getOwner());
		// Delete it!
				$rowsaffected = $videochat->delete();
				if ($rowsaffected > 0) {
		// Success message
					system_message(elgg_echo("videochat:deleted"));
				} else {
					register_error(elgg_echo("videochat:notdeleted"));
				}

		// Forward to the main page
				forward("mod/videochat/rooms.php");

		}

?>