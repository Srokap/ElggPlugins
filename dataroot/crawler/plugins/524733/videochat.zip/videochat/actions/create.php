<?php

        /**
         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         */


        // Make sure we're logged in (send us to the front page if not)
                if (!isloggedin()) forward();

        // Get input data
                $room = get_input('room');
                 $description = elgg_substr(strip_tags(get_input('description')), 0, 300);
    $access_id = get_input('access_id');

function roomName($title)
{
return strtolower(preg_replace("/[^0-9a-zA-Z]+/","-", trim($title)));
}

  $options = array();
  $options['metadata_name_value_pairs'] = array('room' => roomName($room));
  $options['types'] = 'object';
  $options['subtypes'] = 'videochat';
  $erooms = elgg_get_entities_from_metadata($options);
  
  if (count($erooms)&&$erooms)
  {
    $eroom = $erooms[0];
                        register_error(sprintf(elgg_echo("videochat:room_exists"), roomName($room)));
                        forward("mod/videochat/create.php");
  }

        // convert the room name into tags
          $params['tags'] = filter_string($room);
    $params['description'] = $description;

        // Make sure the title / description aren't blank
                if (empty($room)) {
                        register_error(elgg_echo("videochat:blank"));
                        forward("mod/videochat/create.php");

         // Otherwise, save the  room
                } else {

                        if (!videochat_save_room($room, $access_id, $params)) {
                                register_error(elgg_echo("videochat:error"));
                                if($location == "activity")
                                        forward("mod/riverdashboard/");
                                else
                                        forward("mod/videochat/create.php");
                        }

        // Success message
                        system_message(elgg_echo("videochat:created"));

        // Forward
                        if($location == "activity")
                                        forward("mod/riverdashboard/");
                        else
                                        forward("mod/videochat/rooms.php");

                }

     //create room
                function videochat_save_room($room, $access_id, $params = Array())
                {

                        global $SESSION;

                        // Initialise a new ElggObject
                        $videochat = new ElggObject();

                        // Tell the system it's a videochat
                        $videochat->subtype = "videochat";

                        // Set its owner to the current user
                        $videochat->owner_guid = get_loggedin_userid();

                        // For now, set its access to public (we'll add an access dropdown shortly)
                        $videochat->access_id = $access_id;

                        // Set its title, description appropriately
                        $videochat->title = elgg_substr(strip_tags($room), 0, 32);
      $videochat->description = $params['description'];
      $videochat->room = roomName($videochat->title);

            // Now let's add tags. We can pass an array directly to the object property! Easy.
                        if (is_array($params['tags'])) {
                                $videochat->tags = $params['tags'];
                        }

                  // add some metadata
            //$videochat->method = "site"; //method, e.g. via site, api, sms, etc

             //save
                        $save = $videochat->save();

                        if ($save)        add_to_river('river/object/videochat/create','create',$SESSION['user']->guid,$videochat->guid);

      return $save;

                }


?>
