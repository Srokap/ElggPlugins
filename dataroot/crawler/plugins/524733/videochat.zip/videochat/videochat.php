<?php



        // Load Elgg engine



        require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");







        // Get the specified blog post



        $roomname = get_input('roomname');



  if (!$roomname) $roomname="Lobby";







  global $CONFIG;



  //swf to load









  $title=$roomname;







 $area1 = <<< htmlEND



<div align="top">

 <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>

 <script type="text/javascript" src="http://tinychat.com/public/js/tinychat.js"></script>





  <div style="text-align:top;">

 <style>

#videoBox {

    width: 100%;

    height: 450px;

    overflow: hidden;

    text-align: center;

}

</style>

<script>

var tinychat = { room: "***YOUR SITE NAME***-$roomname", owner: "none", oper: "none", colorbk: "0xffffff" };

</script>

<script src='http://tinychat.com/js/embed.js'></script>



<div id="videoBox">

   <div id='client'></div>

</div>





</script>



 <!--////END TINYCHAT EMBED////-->















htmlEND;







         // Display through the correct canvas area



        $body = elgg_view_layout("one_column", $area1);











        // Display page



        page_draw($title,$body);







?>







