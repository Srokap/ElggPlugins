<?php


	if (isset($vars['entity'])) {
        $object=$vars['entity'];

    		$user_name = $object->getOwnerEntity()->name;
       	$url = $object->getURL();
        $link = "<a href=\"" . $object->getURL() . "\">" . $object->title . "</a>";
?>
<div class="videochat-singlepage">
	<div class="videochat-room">

	    <!-- the actual shout -->
		<div class="room_body">

	    <div class="videochat_icon">
	    <?php
		        echo elgg_view("profile/icon",array('entity' => $vars['entity']->getOwnerEntity(), 'size' => 'small'));
	    ?>
	    </div>

			<div class="videochat_options">
	    <div class="clearfloat"></div>
	    		<?php

			// if the user looking at videochat post can edit, show the delete link
			if ($vars['entity']->canEdit()) {


					   echo "<div class='delete_room'>" . elgg_view("output/confirmlink",array(
															'href' => $vars['url'] . "action/videochat/delete?videochatroom=" . $vars['entity']->getGUID(),
															'text' => elgg_echo('delete'),
															'confirm' => elgg_echo('deleteconfirm'),
														)) . "</div>";

			} //end of can edit if statement
		?>
	    </div>

		<?php
		    echo sprintf(elgg_echo('videochat:river:created'),"<b>{$user_name}</b>");
        echo " $link <BR>";
		    $desc = $vars['entity']->description;

		    $desc = preg_replace('/\@([A-Za-z0-9\_\.\-]*)/i','@<a href="' . $vars['url'] . 'pg/videochat/$1">$1</a>',$desc);
  			echo parse_urls($desc);
		?>


		<div class="clearfloat"></div>
		</div>
		<div class="room_date">
		<?php
				echo friendly_time($vars['entity']->time_created);
		?>
		</div>


	</div>
</div>
<?php

		}

?>