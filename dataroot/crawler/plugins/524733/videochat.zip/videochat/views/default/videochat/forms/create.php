<?php

$generated =  base_convert((time()-1224000000).rand(0,10),10,36);

if (defined('ACCESS_DEFAULT')) $access_id = ACCESS_DEFAULT;
else $access_id=2;

?>
<div class="videochat_new">
<script>
function textCounter(field,cntfield,maxlimit) {
    // if too long...trim it!
    if (field.value.length > maxlimit) {
        field.value = field.value.substring(0, maxlimit);
    } else {
        // otherwise, update 'characters left' counter
        cntfield.value = maxlimit - field.value.length;
    }
}
</script>
        <br>
        <br>Characters Allowed : A to Z, 0 to 9 and underscores - No Spaces
        <br>
        <br>
        <br>

        <form action="<?php echo elgg_add_action_tokens_to_url($vars['url']."action/videochat/create"); ?>" method="post" name="roomForm">
                        <?php echo elgg_echo("videochat:name"); ?>:<br />
                        <input name='room' value='<?php echo $generated ?>' onKeyDown="textCounter(document.roomForm.room,document.roomForm.remLen1,22)" onKeyUp="textCounter(document.roomForm.room,document.roomForm.remLen1,22)" id="videochat_large-textarea" maxlength="22" size="22"><?php echo $msg ?>
                           <div class='videochat_characters_remaining'><input readonly type="text" name="remLen1" size="3" maxlength="3" value="22" class="videochat_remaining_field">
            <?php
                echo elgg_echo("videochat:charleft");
                        ?></div>
            <br />


<input type="hidden" name="method" value="site" />
                        <br />
                        <br />
<input type="submit" value="<?php echo elgg_echo('save'); ?>" />
                    <p>
                        <label>
                                <?php echo elgg_echo('access'); ?><br />
                                <?php echo elgg_view('input/access', array('internalname' => 'access_id','value' => $access_id)); ?>
                        </label>
                  </p>
        </form>
</div>

<script>
textCounter(document.roomForm.room,document.roomForm.remLen1,22);
</script>
