<?php

        /**
         * Elgg  Video Chat
         *
         * @package ElggVideochat
         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author Pavoc.com
         * @copyright Pavoc.com 2009-2010
         * @link http://www.pavoc.com/
         */

class Videochat extends ElggObject {

  protected function initialise_attributes() {
    parent::initialise_attributes();
    $this->attributes['subtype'] = 'videochat';
  }

  public function __construct($guid = null) {
    parent::__construct($guid);
  }

  // more customizations here
}


                function videochat_init() {

                          // Load system configuration
                                global $CONFIG;

                          // Set up menu for logged in users
                                if (isloggedin()) {

                                        add_menu(elgg_echo('videochat'), $CONFIG->wwwroot . "mod/videochat/rooms.php");

                                }

        // Extend system CSS with our own styles
                                elgg_extend_view('css','videochat/css');

        //add a widget
        add_widget_type('videochatrooms',"Video Chat Rooms","Video Chat Rooms");

        //register a page
        register_page_handler('videochat', 'videochat_page_handler');

        // Register a URL handler for videochat rooms
                                register_entity_url_handler('videochat_url','object','videochat');

        register_entity_type('object', 'videochat');
        add_subtype('object', 'videochat', 'Videochat');
                }


    //page setup
    function videochat_pagesetup() {

                        global $CONFIG;

                        //add submenu options
                                if (get_context() == "videochat") {
                                        if ((page_owner() == $_SESSION['guid'] || !page_owner()) && isloggedin()) {
                                           add_submenu_item(elgg_echo('videochat:create'),$CONFIG->wwwroot."mod/videochat/create.php");
                                                add_submenu_item(elgg_echo('videochat:rooms'),$CONFIG->wwwroot."mod/videochat/rooms.php");
                                        }
                                }

                }

    function videochat_page_handler($page) {

      // The first component of a videochat URL is the room name
                        if (isset($page[0])) {
                                set_input('roomname',$page[0]);
                        }

      include(dirname(__FILE__) . "/videochat.php");
      return true;
    }

    /**
                 * Populates the ->getUrl() method for videochat objects
                 */
                function videochat_url($chatroom) {
                        global $CONFIG;
                        $room = $chatroom->room;
                        return $CONFIG->url . "pg/videochat/" . urlencode($room);
                }


        // Make sure the videochat initialisation function is called on initialisation
                register_elgg_event_handler('init','system','videochat_init');
                 register_elgg_event_handler('pagesetup','system','videochat_pagesetup');

        // Register actions
                global $CONFIG;
                register_action("videochat/create",false,$CONFIG->pluginspath . "videochat/actions/create.php");
    register_action('videochat/delete',false,$CONFIG->pluginspath . "videochat/actions/delete.php");
?>
