<?php
	/**
	 * Elgg Love Calculator plugin
	 * This is a funny plugin which allows users to calculate love percentages. Just created it for fun :)
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @link http://webgalli.com/
	 */

$english = array(
	'loveCalculator:wg:title' => "Love calculator",
	'loveCalculator:wg:detail' => "A funny widget for Calculating love percentage b/w 2 peoples.",
	'loveCalculator:info' => "Calculate the love between two people by entering their names below and then calculate their compatibility.",
	'loveCalculator:yourname' => "Your name",
	'loveCalculator:lovername' => "Lover name",
	'loveCalculator:calculate' => "Calculate",
);

add_translation("en", $english);
