<?php
 // No settings are needed for this widget
?>