<?php
	/**
	 * Elgg Love Calculator plugin
	 * This is a funny plugin which allows users to calculate love percentages. Just created it for fun :)
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @link http://webgalli.com/
	 */
?>
     
<p>
<script type="text/javascript" language="javascript">
/*
By Team Webgalli
www.webgalli.com
*/
function calc() {
	first = document.loveform.name1.value.toUpperCase();
	firstlength = document.loveform.name1.value.length;
	second = document.loveform.name2.value.toUpperCase();
	secondlength = document.loveform.name2.value.length;
	var LoveCount=0;
	for (Count=0; Count < firstlength; Count++) {
		letter1=first.substring(Count,Count+1);
		if (letter1=='L') LoveCount+=2; 
		if (letter1=='O') LoveCount+=2; 
		if (letter1=='V') LoveCount+=2;
		if (letter1=='E') LoveCount+=2; 
		if (letter1=='Y') LoveCount+=3; 
		if (letter1=='O') LoveCount+=1; 
		if (letter1=='U') LoveCount+=3;
	}
	for (Count=0; Count < secondlength; Count++) {
		letter2=second.substring(Count,Count+1);
		if (letter2=='L') LoveCount+=2;
		if (letter2=='O') LoveCount+=2; 
		if (letter2=='V') LoveCount+=2; 
		if (letter2=='E') LoveCount+=2;
		if (letter2=='Y') LoveCount+=3;
		if (letter2=='O') LoveCount+=1;
		if (letter2=='U') LoveCount+=3;
		}
	amount=0;
	if (LoveCount> 0) amount=  5-((firstlength+secondlength)/2)
	if (LoveCount> 2) amount= 10-((firstlength+secondlength)/2)
	if (LoveCount> 4) amount= 20-((firstlength+secondlength)/2)
	if (LoveCount> 6) amount= 30-((firstlength+secondlength)/2)
	if (LoveCount> 8) amount= 40-((firstlength+secondlength)/2)
	if (LoveCount>10) amount= 50-((firstlength+secondlength)/2)
	if (LoveCount>12) amount= 60-((firstlength+secondlength)/2)
	if (LoveCount>14) amount= 70-((firstlength+secondlength)/2)
	if (LoveCount>16) amount= 80-((firstlength+secondlength)/2)
	if (LoveCount>18) amount= 90-((firstlength+secondlength)/2)
	if (LoveCount>20) amount=100-((firstlength+secondlength)/2)
	if (LoveCount>22) amount=110-((firstlength+secondlength)/2)
	if (firstlength==0 || secondlength==0) amount= "Err";
	if (amount < 0) amount= 0;
	if (amount >99) amount=99;
	document.loveform.output.value=amount+"%";
}
</script>

<CENTER>
	<?php echo elgg_echo('loveCalculator:info');?>
	<FORM name="loveform">
	  <P><INPUT value="<?php echo elgg_echo('loveCalculator:yourname');?>" name="name1" type="text" size="10">  + <INPUT value="<?php echo elgg_echo('loveCalculator:lovername');?>" name="name2" type="text" size="10">  = <INPUT value name="output" type="text" size="6"> <BR>
	  <BR>
	  <INPUT value="<?php echo elgg_echo('loveCalculator:calculate');?>" name="calculate" type="button" class="elgg-button" onclick="calc()"> </P>
	</FORM>
</CENTER>
