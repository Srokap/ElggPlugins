<?php
	/**
	 * Elgg Love Calculator plugin
	 * This is a funny plugin which allows users to calculate love percentages. Just created it for fun :)
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @link http://webgalli.com/
	 */
	elgg_register_event_handler('init', 'system', 'loveCalculator_init');

	function loveCalculator_init() {
		elgg_register_widget_type('loveCalculator',elgg_echo("loveCalculator:wg:title"),elgg_echo("loveCalculator:wg:detail"));		
	}	
?>