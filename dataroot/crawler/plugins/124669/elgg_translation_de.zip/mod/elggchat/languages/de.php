<?php

// Generiere vom Übersetzungsbrowser. 

$german = array( 
	 'elggchat'  =>  "Chat" , 
	 'elggchat:title'  =>  "Chat" , 
	 'elggchat:chat:profile:invite'  =>  "Einladen" , 
	 'elggchat:chat:send'  =>  "Senden" , 
	 'elggchat:chat:invite'  =>  "Einladen" , 
	 'elggchat:chat:leave'  =>  "Verlassen" , 
	 'elggchat:chat:leave:confirm'  =>  "Bist Du sicher?" , 
	 'elggchat:chat:info'  =>  "Info´s" , 
	 'elggchat:action:invite'  =>  "%s lud %s ein" , 
	 'elggchat:action:invite_friends'  =>  "Freunde einladen" , 
	 'elggchat:action:leave'  =>  "%s hat den Chat verlassen" , 
	 'elggchat:session_info:title'  =>  "Session Info´s" , 
	 'elggchat:session_info:id'  =>  "ID:" , 
	 'elggchat:session_info:started'  =>  "gestartet:" , 
	 'elggchat:session_info:members'  =>  "Mitglieder" , 
	 'elggchat:session_info:invitations'  =>  "Offene Einladungen" , 
	 'elggchat:admin:settings:chatupdateinterval'  =>  "Intervall (Sekunden) des Chat Fensters" , 
); 

add_translation('de', $german); 

?>