<?php

// Generiere vom Übersetzungsbrowser. 

$german = array( 
	 'messages'  =>  "Nachrichten" , 
	 'messages:back'  =>  "zurück zu Nachrichten" , 
	 'messages:user'  =>  "Dein Posteingang" , 
	 'messages:sentMessages'  =>  "Gesendete Nachrichten" , 
	 'messages:posttitle'  =>  "%s's Nachrichten: %s" , 
	 'messages:inbox'  =>  "Posteingang" , 
	 'messages:send'  =>  "Nachricht senden" , 
	 'messages:sent'  =>  "Gesendete Nachrichten" , 
	 'messages:message'  =>  "Nachricht" , 
	 'messages:title'  =>  "Betreff" , 
	 'messages:to'  =>  "An" , 
	 'messages:from'  =>  "von" , 
	 'messages:fly'  =>  "Absenden" , 
	 'messages:replying'  =>  "Antwort auf" , 
	 'messages:sendmessage'  =>  "Nachricht senden" , 
	 'messages:compose'  =>  "Nachricht senden" , 
	 'messages:sentmessages'  =>  "Gesendete Nachrichten" , 
	 'messages:recent'  =>  "Letzten Nachrichten" , 
	 'messages:original'  =>  "Ursprüngliche Nachricht" , 
	 'messages:yours'  =>  "Deine Nachricht" , 
	 'messages:answer'  =>  "Antworten" , 
	 'messages:toggle'  =>  "Alle Markieren" , 
	 'messages:markread'  =>  "Als gelesen Markieren" , 
	 'messages:new'  =>  "Neue Nachricht" , 
	 'notification:method:site'  =>  "Seite" , 
	 'messages:error'  =>  "Beim Speichern deiner Nachricht ist ein Fehler aufgetreten. Bitte noch mal versuchen" , 
	 'item:object:messages'  =>  "Nachrichten" , 
	 'messages:posted'  =>  "Deine Nachricht wurde erfolgreich gesendet." , 
	 'messages:deleted'  =>  "Deine Nachricht wurde erfolgreich gelöscht." , 
	 'messages:markedread'  =>  "Deine Nachrichten wurden als \"Gelesen\" markiert." , 
	 'messages:email:subject'  =>  "Du hast eine neue Nachricht!" , 
	 'messages:email:body'  =>  "Du hast eine neue Nachricht von %s: %s Um deine Nachrichten anzuschauen, klick hier: %s Du kannst diese Mail nicht beantworten." , 
	 'messages:blank'  =>  "Sorry, du kannst keine leere Nachricht abspeichern." , 
	 'messages:notfound'  =>  "Sorry, die angegebene Nachricht konnte nicht gefunden werden." , 
	 'messages:notdeleted'  =>  "Sorry, diese Nachricht konnte nicht gelöscht werden." , 
	 'messages:nopermission'  =>  "Du hast keine Befugnisse, um diese Mail löschen zu können." , 
	 'messages:nomessages'  =>  "Es gibt keine Nachrichten, die angezeigt werden können." , 
	 'messages:user:nonexist'  =>  "Der Empfänger konnte nicht  gefunden werden."
); 

add_translation('de', $german); 

?>