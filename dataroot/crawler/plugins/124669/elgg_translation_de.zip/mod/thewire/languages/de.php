<?php

// Generate By translationbrowser. 

$german = array( 
	 'thewire'  =>  "Status Nachricht" , 
	 'thewire:user'  =>  "%s's Status" , 
	 'thewire:posttitle'  =>  "%s's Beiträge zu Schoutbox: %s" , 
	 'thewire:everyone'  =>  "Beiträge von allen" , 
	 'thewire:read'  =>  "Deine Beiträge" , 
	 'thewire:strapline'  =>  "%s" , 
	 'thewire:add'  =>  "Status-Beitrag schreiben" , 
	 'thewire:text'  =>  "Ein Beitrag zum Status" , 
	 'thewire:reply'  =>  "Antworten" , 
	 'thewire:via'  =>  "per" , 
	 'thewire:wired'  =>  "Beitrag geschrieben" , 
	 'thewire:charleft'  =>  "Symbole übrig" , 
	 'item:object:thewire'  =>  "Status-Beiträge" , 
	 'thewire:notedeleted'  =>  "Beitrag gelöscht" , 
	 'thewire:doing'  =>  "Was machst du grade? Lass es jeden wissen:" , 
	 'thewire:newpost'  =>  "Status-Beitrag" , 
	 'thewire:addpost'  =>  "Schreibe einen Status-Beitrag" , 
	 'thewire:river:created'  =>  "%s schrieb" , 
	 'thewire:river:create'  =>  "im Status" , 
	 'thewire:sitedesc'  =>  "Dieses Widget zeigt die zuletzt geschriebenen Seiten-Beiträge im Status" , 
	 'thewire:yourdesc'  =>  "Dieses Widget zeigt deine zuletzt geschriebenen Seiten-Beiträge im Status" , 
	 'thewire:friendsdesc'  =>  "Dieses Widget zeigt die zuletzt geschiebenen Beiträge deiner Freunde im Status" , 
	 'thewire:friends'  =>  "Deine Freunde im Status" , 
	 'thewire:num'  =>  "Anzahl der Objekte, die angezeigt werden sollen" , 
	 'thewire:posted'  =>  "Deine Nachricht wurde erfolgreich im Status erstellt." , 
	 'thewire:deleted'  =>  "Dein Beitrag wurde erfolgreich gelöscht." , 
	 'thewire:blank'  =>  "Sorry, du solltest aber etwas ins Textfeld eintragen, bevor du es abspeichert." , 
	 'thewire:notfound'  =>  "Sorry, der gesuchte Eintrag konnte nicht gefunden werden." , 
	 'thewire:notdeleted'  =>  "Sorry, diese Meldung konnte nicht gelöscht werden." , 
	 'thewire:smsnumber'  =>  "Deine SMS-Nummer, falls nicht mit deiner Handy-Nummer übereinstimmend (Die Handynummer muss auf \"öffentlich\" für den Schoutbox eingestellt werden, damit man sie nutzen kann). Alle Tel.Nummern müssen den internationelen Standards entsprechen (Bsp. +49 ... für Deutschland)" , 
	 'thewire:channelsms'  =>  "Die Nummer für die SMS-Nachrichten ist %s" ,
); 

add_translation('de',$german);

?>
