<?php

// Generiere vom Übersetzungsbrowser. 

$german = array( 
	 'msnme:widget:name'  =>  "Mein MSN" , 
	 'msnme:widget:desc'  =>  "Mein MSN Widget" , 
	 'msnme:widget:msnusername'  =>  "Deine MSN ID:
Um Deine Live MSN ID zu bekommen besuche bitte <a href=\"http://settings.messenger.live.com/applications/CreateHtml.aspx\" target=\"_blank\">diesen Link</a> und kopiere den Text zwischen [invitee= & @apps.messenger...].
Dies ist Deine MSN ID" , 
	 'msnme:widget:usernameerror'  =>  "Du musst noch Deine MSN ID eingeben. Drücke dazu die \"Bearbeiten\" Taste oben rechts" , 
	 'msnme:widget:webstatuswarning'  =>  "Du solltest Deine MSN Sicherheitseinstellungen bezüglich Deines Status bearbeiten. Besuche dazu den folgenden Link." , 
	 'msnme:widget:webstatuswarning2'  =>  "Um Deinen Messenger sehen zu können wähle bitte aus den folgenden Optionen aus." , 
	 'msnme:widget:webstatuslink'  =>  "Deinen MSN Status anzeigen" , 
	 'msnme:widget:refreshratemessage'  =>  "Dieses Widget aktualisiert sich automatisch um Deinen Status stets korrekt anzuzeigen. Du kannst die Intervalle hier ändern." , 
	 'msnme:widget:defaultrefreshrate'  =>  "Normaler Aktualisierungsintervall" , 
	 'msnme:widget:nocontact'  =>  "Dieser Benutzer hat den MSN Kontakt untersagt" , 
	 'msnme:widget:contact'  =>  "Kontaktiere mich hier:" , 
	 'msnme:widget:options:norefresh'  =>  "Keine Aktualisierung" , 
	 'msnme:widget:options:15seconds'  =>  "15 Sekunden" , 
	 'msnme:widget:options:30seconds'  =>  "30 Sekunden" , 
	 'msnme:widget:options:60seconds'  =>  "60 Sekunden" , 
	 'msnme:widget:options:1hour'  =>  "1 Stunde" , 
	 'msnme:widget:options:3hours'  =>  "3 Stunden" , 
	 'msnme:widget:action:message'  =>  "Du kannst hier bestimmen was passiert nach dem drücken des \"Mein MSN\" Buttons und in welcher Art Du dieses Widget einbinden möchtest: " , 
	 'msnme:widget:options:action:embed'  =>  "Eingebunden" , 
	 'msnme:widget:options:action:new'  =>  "Pop-up Seite" , 
	 'msnme:widget:options:action:widget'  =>  "Widget" , 
	 'msnme:widget:showmsnstatus'  =>  "Benutern erlauben mich zu kontaktieren?" , 
	 'msnme:widget:showmsnstatus:options:yes'  =>  "Ja" , 
	 'msnme:widget:showmsnstatus:options:no'  =>  "Nein" , 
	 'msnme:widget:showmsnstatus:refreshmessage'  =>  "Achtung: Falls Du das Kontaktieren untersagst wird sich dieses Widget auch nicht aktualisieren." , 
	 'msnme:settings'  =>  "Setup \"Mein MSN\" Plugin" , 
	 'msnme:settings:explanation'  =>  "Setup \"Mein MSN\" Plugin" , 
	 'msnme:save:success'  =>  "Gespeichert" , 
	 'msnme:settings:configColors'  =>  "Farben einstellen" , 
	 'msnme:settings:LanguageOption'  =>  "Sprache auswählen" , 
	 'msnme:settings:foreColor'  =>  "Vordergrund Farbe" , 
	 'msnme:settings:backColor'  =>  "Hintergrund Farbe" , 
	 'msnme:settings:linkColor'  =>  "Link Farbe" , 
	 'msnme:settings:borderColor'  =>  "Rand Farbe" , 
); 

add_translation('de', $german); 

?>