<?php

// Generate By translationbrowser. 

$german = array( 
	 'expages'  =>  "Externe Seiten" , 
	 'expages:frontpage'  =>  "Erste Seite" , 
	 'expages:about'  =>  "Über" , 
	 'expages:terms'  =>  "AGBs" , 
	 'expages:privacy'  =>  "Datenschutzerklärung" , 
	 'expages:analytics'  =>  "Analyse" , 
	 'expages:contact'  =>  "Kontakt" , 
	 'expages:nopreview'  =>  "Derzeit kein Vorschau verfügbar" , 
	 'expages:preview'  =>  "Vorschau" , 
	 'expages:notset'  =>  "Diese Seite wurde noch nicht konfiguriert." , 
	 'expages:lefthand'  =>  "Info-block auf der linken Seite" , 
	 'expages:righthand'  =>  "Info-block auf der rechten Seite" , 
	 'expages:addcontent'  =>  "Hier kannst du Inhalte per deine Admin-Werzeuge hinzufügen. Schaue nach dem \"Externe-Seiten\" Link unter \"Administration\"." , 
	 'item:object:front'  =>  "Objekte auf der ersten Seite" , 
	 'expages:posted'  =>  "Dein Seiten-Eintrag wurde erfolgreich erstellt." , 
	 'expages:deleted'  =>  "Dein Seiten-Eintrag wurde erfolgreich gelöscht." , 
	 'expages:deleteerror'  =>  "Beim Löschen der alten Seite ist ein Fehler aufgetreten" , 
	 'expages:error'  =>  "Ein Fehler ist aufgetreten. Bitte noch mal versuchen. Falls das Problem weiterhinbesteht, kontaktiere Administrator" ,
); 

add_translation('de',$german); 

?>