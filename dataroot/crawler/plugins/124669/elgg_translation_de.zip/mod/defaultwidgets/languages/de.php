<?php

// Generate By translationbrowser. 

$german = array( 
	 'item:object:moddefaultwidgets'  =>  "Standard Widgets Einstellungen", 
	 'defaultwidgets:menu:profile'  =>  "Standard Profilwidgets",
	 'defaultwidgets:menu:dashboard'  =>  "Standard Anzeigetafel-widgets",
	 'defaultwidgets:admin:error'  =>  "Fehler: Du bist nicht als Administrator eingeloggt.",
	 'defaultwidgets:admin:notfound'  =>  "Fehler: die Seite konnte nicht gefunden werden",
	 'defaultwidgets:admin:loginfailure'  =>  "Warnung: Du bist zur Zeit nicht als Administrator eingeloggt",
	 'defaultwidgets:update:success'  =>  "Deine widget Einstellungen sind gespeichert",
	 'defaultwidgets:update:failed'  =>  "Fehler: Einstellungen wurden nicht gespeichert",
	 'defaultwidgets:update:noparams'  =>  "Fehler: falsche Parameterform",
	 'defaultwidgets:profile:title'  =>  "Standardmäßige widgets werden für die Profilseiten des neuen Users eingerichtet",
	 'defaultwidgets:dashboard:title'  =>  "Standardmäßige widgets werden für die Anzeigetafel des neuen Users eingerichtet",
); 

add_translation('de',$german);

?>