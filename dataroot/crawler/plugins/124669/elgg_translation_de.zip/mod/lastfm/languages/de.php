<?php

// Generiere vom Übersetzungsbrowser. 

$german = array( 
	 'lastfm:lastsong'  =>  "Letzte LastFM Songs" , 
	 'lastfm:widgetinfo'  =>  "Letzte LastFM Songs" , 
	 'lastfm:enterusername'  =>  "Bitte gebe Deinen LastFM Benutzernamen ein." , 
	 'lastfm:cannotfind'  =>  "Noch keine Musik." , 
	 'lastfm:displaynum'  =>  "Wieviele Songs?" , 
	 'lastfm:notset'  =>  "Du hast noch nicht Deinen LastFM Benutzernamen eingegeben. Klicke auf \"Bearbeiten\"."
); 

add_translation('de', $german); 

?>