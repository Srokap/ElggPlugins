<?php

// Generiere vom Übersetzungsbrowser. 

$german = array( 
	 'custom:bookmarks'  =>  "Lesezeichen" , 
	 'custom:groups'  =>  "Neuste Gruppen" , 
	 'custom:files'  =>  "Letzte Dateien" , 
	 'custom:blogs'  =>  "Letzte Blogs" , 
	 'custom:members'  =>  "Neuste Mitglieder" , 
	 'custom:pages'  =>  "Letzte Seiten" , 
	 'custom:activity'  =>  "Zuletzt passiert" , 
	 'custom:tidypics'  =>  "Neuste Bilder in der P4T Datenbank" , 
); 

add_translation('de', $german); 

?>