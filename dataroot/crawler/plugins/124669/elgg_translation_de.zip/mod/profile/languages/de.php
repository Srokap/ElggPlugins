<?php

// Generiere vom Übersetzungsbrowser. 

$german = array( 
	 'unselected'  =>  "Bitte auswählen:" , 
	 'profile:toggle_details'  =>  "+/-" , 
	 'profile:category:basic'  =>  "Ein paar Informationen" , 
	 'profile:gender'  =>  "Geschlecht" , 
	 'profile:female'  =>  "Weiblich" , 
	 'profile:male'  =>  "Männlich" ,  
	 'profile:hometown'  =>  "Heimatstadt" , 
	 'profile:birthday'  =>  "Geburtstag" , 
	 'year'  =>  "Jahr" , 
	 'month'  =>  "Monat" , 
	 'day'  =>  "Tag" , 
	 'profile:birthday:show_year'  =>  "Zeige Geburts.: Jahr-Monat-Tag im Profil?" , 
	 'profile:birthday:hide_year'  =>  "Nur Monat und Tag anzeigen" , 
	 'profile:relationship_status'  =>  "Beziehungs Status" , 
	 'profile:single'  =>  "Single" , 
	 'profile:in_relationship'  =>  "In einer Partnerschaft" , 
	 'profile:engaged'  =>  "Verlobt" , 
	 'profile:married'  =>  "Verheiratet" , 
	 'profile:hard_to_tell'  =>  "Das ist kompliziert" , 
	 'profile:open_relationship'  =>  "In einer offenen Beziehung" , 
	 'profile:category:personal'  =>  "Persönliche Informationen" , 
	 	 	 'profile:goal'  =>  "Lebensziel" ,
	 'profile:category:contact'  =>  "Kontakt Information" , 
	 'profile:qq'  =>  "QQ" , 
	 	 'profile:msn'  =>  "MSN" , 
	 'profile:email'  =>  "Email Adresse" , 
	 'profile:category:profession'  =>  "Berufliches" , 
	 'profile:profession'  =>  "Berufliches" , 
	 'profile:company'  =>  "Firma" , 
	 'profile:position'  =>  "Position" , 
	 'profile:college'  =>  "Letzte Schule" , 
	 'profile:course'  =>  "Abschluss" , 
	 'DataFormatException:invalid_input_format'  =>  "%s hatte ein unbekanntes Format" , 
	 'DataFormatException:field_required'  =>  "Bette gebe ein %s" , 
	 'DataFormatException:empty_input'  =>  "Das Netzwerk hatte soeben ein kleines Problem." , 
	 'BusinessLogicException:unique_meta_duple'  =>  "Irgendwer hatte bereits %s" , 
	 'ConfigurationException:invalid_profile_config'  =>  "Falsche Profil Konfiguration. Bitte den Admin kontaktieren!"
 

); 

add_translation('de', $german); 

?>