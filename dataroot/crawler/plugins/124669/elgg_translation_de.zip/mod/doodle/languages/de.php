<?php

// Generiere vom Übersetzungsbrowser. 

$german = array( 
	 'doodle:title'  =>  "Meine Box" , 
	 'doodle:description'  =>  "Hier kannst Du ein einbinden was Du möchtest. (HTML ist erlaubt)"
); 

add_translation('de', $german); 

?>