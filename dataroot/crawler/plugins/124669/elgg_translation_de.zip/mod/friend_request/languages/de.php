<?php
$german = array(
	'friendrequest' => "Freundes Anfrage",
	'friendrequests' => "Freundes Anfragen",
	'friendrequests:title' => "%s's Freundes Anfrage",
	'newfriendrequests' => "Neue Freundes Anfragen!",
	'friendrequest:add:exists' => "Du hast bereits eine Anfrage an %s verschickt.",
	'friendrequest:add:failure' => "Sorry aber wegen einem Systemfehler konnten wir die Anfrage nicht versenden. Bitte versuche es erneut.",
	'friendrequest:add:successful' => "Du hast eine Freundschafts Anfrage an %s gesendet.Der Benutzer muss vorher Eure Freundschaft akzeptieren.",
	'friendrequest:newfriend:subject' => "%s m&ouml;chte Dein Freund sein!",
	'friendrequest:newfriend:body' => "%s m&ouml;chte mit Dir befreundet sein!

Du kannst Deine Freundes Anfragen hier sehen (Bitte einloggen um Deine Freundes Anfragen zu betrachten link andernfalls wirst du zur Startseite weitergeleitet.):

	%s

(Auf diese Email kann nicht geantwortet werden.)",

	'friendrequest:successful' => "Du bist ab jetzt befreundet mit %s!",
	'friendrequest:remove:success' => "Erfolgreich entfernt von der Anfrage.",
	'friendrequest:remove:fail' => "Unm&ouml;glich die Anfrage zu entfernen.",
	'friendrequest:approvefail' => "Error beim anschreiben von %s als Freundes Anfrage!",
);
				
add_translation("de",$german);
?>