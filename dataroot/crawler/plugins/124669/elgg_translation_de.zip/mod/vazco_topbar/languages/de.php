<?php

// Generiere vom Übersetzungsbrowser. 

$german = array( 
	 'vazco_topbar:settings:linklist'  =>  "Definiere die Links für die Topbar

Um eine neue Box Hinzuzufügen nutze folgendes Format:
| | Tool Box name

Um elemente in die Toolbox einzubinden nutze folgendes Format:
Link Name | Link Adresse" , 
	 'vazco_topbar:settings:loginbar'  =>  "Zeige die Toolbar unregistrierten Benutzern mit Login Fenstern" , 
	 'vazco_topbar:settings:loginbox'  =>  "Zeige die Login Box auf der Hauptseite" , 
	 'login:short'  =>  "Anmelden" , 
	 'vazco_topbar:settings:loginremark'  =>  "[ Du kannst die Login Box und die Toolbar nicht zugleich abschalten. Eine der beiden muss aktiv bleiben ]" , 
	 'vazco_topbar:settings:joinicontools'  =>  "Besuche die Benutzer Tools und dessen Icon" , 
	 'vazco_topbar:settings:joinsettings'  =>  "Verschiebe die Account Einstellungen zu \"mein Profil\"" , 
	 'vazco_topbar:settings:elgglogo'  =>  "Zeige das \"elgg\" Logo in der Topbar" , 
	 'vazco_topbar:settings:topbar'  =>  "Zeige/Verberge Topbar Elemente" , 
	 'vazco_topbar:profile:icon'  =>  "Mein Profil" , 
	 'vazco_mainpage:menu:short'  =>  "Startseiten Widgets" , 
	 'defaultwidgets:menu:dashboard:short'  =>  "Pulpite Widgets" , 
	 'defaultwidgets:menu:profile:short'  =>  "Profil Widgets" , 
	 'vazco_avatar:menu:short'  =>  "Benutzer Avatare"
); 

add_translation('de', $german); 

?>