<?php

// Generate By translationbrowser.

$german = array(
	 'logbrowser'  =>  "Protokoll Browser" ,
	 'logbrowser:browse'  =>  "Systemprotokoll durchsuchen" , 
	 'logbrowser:search'  =>  "Ergebnisse sortieren" , 
	 'logbrowser:user'  =>  "Suchen nach Benutzernamen" , 
	 'logbrowser:starttime'  =>  "angefangen um(zum Beispiel \"letzter Montag\", \"Vor 1 Stunde\")" , 
	 'logbrowser:endtime'  =>  "beendet um" , 
	 'logbrowser:explore'  =>  "Protokoll untersuchen",
); 

add_translation('de',$german);

?>