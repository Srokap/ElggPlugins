<?php
$english = array(
	'profile_manager_nagger_widget:missing_intro' => "The following fields are missing from your profile. "
		."Please click on the edit profile button below and complete this information when you can.",
	'profile_manager_nagger_widget:no_missing' => "Your profile is now complete. Thank you for providing this information.",
	'profile_manager_nagger_widget:title' => "Registration Reminder",
	'profile_manager_nagger_widget:description' => "Get reminders on profile fields to complete.",
	'profile_manager_nagger_widget:settings:fields:title' => "Internal names of fields to remind the user about (one per "
		." line). Use \"_icon\" to refer to the user profile image.",
	'profile_manager_nagger_widget:icon' => "Profile icon",
);
				
add_translation("en",$english);
?>
