<?php

function profile_manager_nagger_widget_init() {
	add_widget_type('profile_manager_nagger',elgg_echo('profile_manager_nagger_widget:title'),elgg_echo('profile_manager_nagger_widget:description'));
}
register_elgg_event_handler('init','system','profile_manager_nagger_widget_init');
