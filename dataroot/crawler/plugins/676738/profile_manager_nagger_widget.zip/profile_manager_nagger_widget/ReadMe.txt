This needs the mods in order:
Forms
Profile
Profile_Manager
Profile_Manager_Nagger_widget
