<?php
$profile_manager_nagger_widget_fields = get_plugin_setting('fields', 'profile_manager_nagger_widget');

if($profile_manager_nagger_widget_fields==NULL)
{
	$profile_user  = $CONFIG->profile;
	$userid=get_loggedin_userid();
	foreach ($profile_user as $field=>$value) {
			$profile_manager_nagger_widget_fields .= $field ."\n";
	}
}
	
echo elgg_echo('profile_manager_nagger_widget:settings:fields:title'). '<br />' .
	elgg_view('form/input/longtext',array('internalname'=>'params[fields]','value'=>$profile_manager_nagger_widget_fields));
?>