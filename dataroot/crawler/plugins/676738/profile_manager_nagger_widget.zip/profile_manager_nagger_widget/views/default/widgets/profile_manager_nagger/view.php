<?php
	/**
	* Profile Manager Audit tool
	* 
	* view to audit the user details
	* 
	* @package profile_manager_nagger_widget
	* @author Joel Mckay
	* @copyright Joel Mckay
	* @link http://www.joelmckay.com/
	*/
	global $CONFIG;
	$userid=get_loggedin_userid();
if($userid > 1)
{
	$crrent_site_guid = $CONFIG->site_guid;
	$profile_user  = $CONFIG->profile;		//will not have all the fields when you login
	
	
	$myProfileURL=get_loggedin_user()->getURL() . '/edit/';
	$queryTags='';
	$queryTagCount=0;
	$errorCode=0;
	$queryCodeCount=0;
	$requireFields = explode("\n",str_replace("\r","\n",str_replace("\r\n","\n",trim(get_plugin_setting('fields', 'profile_manager_nagger_widget')))));
	$content='';
		
	//Choose the meta string vars to pull
         foreach ($profile_user as $field=>$value) {
			
			if(in_array($field,$requireFields) == true)
			{
			$queryTags .= '\''. $field . '\',' ;	//only pull the required fields			
			$queryTagCount++; 
			}
	}
	$queryTags=rtrim($queryTags,',');
	 


	// flush caches so that we don't have memory issues
	$DB_QUERY_CACHE = $DB_PROFILE = $ENTITY_CACHE = array(); 


	if($queryTagCount > 0)		//do we need to check the meta?
	{
	
	$EntityObjectSubTypeName='profile_manager';	//Profile Manager items for this user
	
	//I was going to add a blank data check, but it woul limit a type specific check later 
	$sqlQuery=
	"SELECT DISTINCT M.entity_guid as DATA_Entity_guid, T.subtype as Entity_Object_subtype_guid, "
	." S.title as Entity_Object_SubType_Name, T.container_guid as User_Container_guid, "
	." A.string as Name,  B.string as Value, M.value_type as DataType"
	." FROM {$CONFIG->dbprefix}metadata M,  {$CONFIG->dbprefix}metastrings A,  {$CONFIG->dbprefix}metastrings B,"
	." {$CONFIG->dbprefix}entities T, {$CONFIG->dbprefix}objects_entity S "
	." WHERE T.owner_guid='$userid' "   	//entities owned by the current user?
	." AND T.container_guid='$userid' " 	//entities belong to the current user?
	." AND S.title='$EntityObjectSubTypeName' "	//limits the object subtype search, and stays on this site context
	." AND S.guid = T.subtype "
	." AND T.site_guid='$crrent_site_guid' " //this part limits the query to active user metadata 
	//." AND T.access_id='2' "		//is user Entity set to  public ?
	." AND T.type='object' "
	." AND T.owner_guid=M.owner_guid "
	." AND M.enabled='yes' "		//this part limits the size of the joins by removing un-required fields
	." AND M.name_id= A.id "
	." AND M.value_id= B.id"
	." AND A.string IN ($queryTags)"
	." LIMIT 0,$queryTagCount";


	$mysql_dblink2 = @mysql_connect($CONFIG->dbhost,$CONFIG->dbuser,$CONFIG->dbpass, true);
	if ($mysql_dblink2) {
		if (@mysql_select_db($CONFIG->dbname,$mysql_dblink2)) {

			// get dataroot and simplecache_enabled in one select for efficiency
			if ($result = mysql_query($sqlQuery,$mysql_dblink2)) {
				$row = mysql_fetch_object($result);
				while ($row) {
				
					//echo	'<br>'.$row->Name .'='. $row->Value . ' ['. $row->DataType . ', '. $row->EntityChild . ']';
						
					if((in_array($row->Name,$requireFields) == true) && ( strlen($row->Value) <= 0 ))
					{
						$content.= ' '. $row->Name . ',';   //TODO: translations ('profile:' . $row->Name)
						$errorCode=1;	//trip error state	
					}
					$queryCodeCount++;
					$row = mysql_fetch_object($result);	//next field
				}
			}

		}
		//@mysql_close($mysql_dblink2);	//TODO: cause elgg_access_collection_membership Fatal error: Exception thrown without a stack frame in Unknown on line 0
	}
	}

echo "<div class=\"contentWrapper\">";

//debug mode
/*
echo 'qt:'  . $queryTagCount .' qc:'.  $queryCodeCount .' UID:'. $userid . ' ERROR:' .$errorCode .' QC:' . $queryCodeCount .' QTC:' . $queryTagCount . ' <br>';
echo 'tags:'. $queryTags. ' <br>';
print_r($profile_user);
echo $sqlQuery. ' <br>';
*/

if(($errorCode == 1) ||  (($errorCode == 0 ) && ($queryTagCount != $queryCodeCount)))	//must disable widget to turn off blank nagger as New Users will be missing fields until they save
{

	echo '<a href="'. $myProfileURL. '" target="_self"><h2>Warning:</h2><br>'.
		'<i>Missing Registration entries in your private profile may prevent access to certain features on the site.</i>' .	
		'<br><b><u>[Click Here]</u> to add missing fields</b></a><br>' ;
	echo rtrim($content,',') ;
}else{
	echo '<a href="javascript:void(0);" onclick="$(\'a.toggle_customise_edit_panel\').click();" >Tip: You may use the [Edit page] link to remove this reminder, and add neat things like twitter support.</a>';
}

echo "</div>";
}

?>