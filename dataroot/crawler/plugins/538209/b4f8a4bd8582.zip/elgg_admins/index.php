<?php
/**
 * Elgg administration user system index
 *
 * @package ElggAdmins
 * @author  Lorea.cc
 * @link http://lorea.org/
 */

// pluralize(string, count)
function pluralize($string, $count)
{
    switch ((int)$count) {
     case 1:
	  return "one $string";
     case 0:
	return "no $string";
     default:
	  return $count . ' ' . inflect($string);
    }
}

// very lame
function inflect($string)
{
    return $string . 's';
}
 
 // Get the Elgg framework
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

// Make sure only valid admin users can see this
admin_gatekeeper();

set_context('admin');

// Set admin user for user block
set_page_owner($_SESSION['guid']);

$plugin_content = elgg_view('admins/main', array('count_admins' => admins_count_admin_users(), 'first_admin' => admins_get_first_admin(), 'entities' => admins_get_admin_users()));
$canvas_area    = elgg_view_layout("two_column_left_sidebar", '', $plugin_content);

page_draw($title, $canvas_area);
?>
