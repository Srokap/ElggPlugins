<?php

function admins_init()
{
    global $CONFIG;
    
//    extend_elgg_admin_page('admin/main', 'admin/main_opt/admins');
    elgg_extend_view('css', 'admins/css');
    
    register_page_handler('admins', 'admins_page_handler');
}

function admins_pagesetup()
{
    if (get_context() == 'admin' && isadminloggedin()) {
	global $CONFIG;

	add_submenu_item(elgg_echo('admins:title'), $CONFIG->wwwroot . 'pg/admins/');
    }
}

function admins_page_handler($page) 
{
    global $CONFIG;
    
    // Only one page
    $path = $CONFIG->pluginspath . "admins/index.php";
    
    include($path);
}

function admins_count_admin_users()
{
  $sql = admins_select('count');
  $res = get_data($sql);

  return $res[0]->count;
}

function admins_get_admin_users()
{
  $sql = admins_select();
  return get_data($sql, 'entity_row_to_elggstar');  
}

function admins_get_first_admin()
{
  $sql = admins_select('first_admin');
  $res = get_data($sql, 'entity_row_to_elggstar');
  return $res[0];  
}

function admins_select($what = 'entities')
{
  global $CONFIG;

  $from   = "FROM {$CONFIG->dbprefix}entities e ";
  $access = get_access_sql_suffix('e');
  $joins  = "LEFT JOIN {$CONFIG->dbprefix}users_entity u ON e.guid=u.guid WHERE u.admin='yes' AND $access";

  if ($what == 'count') {
    return "SELECT COUNT(*) AS count $from $joins";
  }

  if ($what == 'first_admin') {
    $search = '';
    $offset = 0;
    $limit  = 1;
  } else {
    $search = get_input('s');
    $offset = (int)get_input('offset', 0);
    $limit  = (int)get_input('limit', 10);
  }

  $sql    = "SELECT e.* $from $joins";
  if (!empty($search)) {
    $sql .= " AND u.name LIKE '" . sanitise_string($search) . "%'";
  }
  $sql .= " ORDER BY u.guid ASC LIMIT {$offset},{$limit}";

  return $sql;
}

register_elgg_event_handler('init','system','admins_init');
register_elgg_event_handler('pagesetup','system','admins_pagesetup');
