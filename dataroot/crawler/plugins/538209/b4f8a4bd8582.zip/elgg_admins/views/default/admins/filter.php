<?php
/**
 * Elgg admins filter box.
 *
 * @package ElggAdmins
 * @author  Lorea.cc
 * @link http://lorea.org/
 */
?>

<div id="admins_filter_box">
    <form action="<?php echo $vars['url']; ?>pg/admins/" method="get">
    <fieldset><legend><?php echo elgg_echo('admins:filter:legend'); ?></legend>
<?php echo elgg_view('input/text',array('internalname' => 's', 'class' => 'filter_input', 'value' => get_input('s'))); ?>
    <input type="submit" name="filter" value="<?php echo elgg_echo('admins:filter:submit'); ?>" />
    <?php echo elgg_echo('admins:filter:tip'); ?>
    </fieldset>
    </form>
</div>
 