<?php 
/**
 * Elgg administration admins main screen
 * 
 * @package elgg_admins
 * @author  Lorea.org
 * @license AGPL
 * @copyright 2010 Lorea.org
 * @link http://lorea.org/
 */
 
function admin_link($admin)
{ 
    return '<a href="' . $admin->getUrl() . '"><strong>' . $admin->name . '</strong></a>';
}

$html = "";
if ($vars['count_admins'] > 1) {
  $html.= '<p>There are ' . $vars['count_admins'] . ' administrators on your site.<br/>';
  $html.= 'Initial administrator is ' . admin_link($vars['first_admin']) . '.</p>';
} else {
  $html.= '<p>There is only one administrator: ' . admin_link($vars['entities'][0]) . '.</p>';
}
$html.= elgg_view('admins/filter');
  
echo elgg_view('admins/top');
echo elgg_view('page_elements/contentwrapper', array('body' => $html));
if (empty($vars['entities'])) {
    $html = '<p class="notice">Nobody there yet. ';
    $html.= '<a href="' . $vars['url'] / 'pg/admins/">View all administrators</a>.</p>';
    echo elgg_view('page_elements/contentwrapper', array('body' => $html));
} else {
    echo elgg_view_entity_list($vars['entities'], $vars['count_admins'], get_input('offset', 0), get_input('limit', 10), false, true, true);
}
