<?php
echo elgg_view_title(elgg_echo('admins:title'));
echo elgg_view('page_elements/contentwrapper', array('body' => elgg_echo('admins:description')));
//echo '<div class="contentWrapper"><span class="contentIntro">' . elgg_view('output/longtext', array('value' => elgg_echo('admins:description'))) . '</span></div>';
?>
