<?php

$icon = elgg_view("profile/icon", array('entity' => $vars['entity'], 'size' => 'small'));
$banned = $vars['entity']->isBanned();

if (get_context() == 'admin' && isadminloggedin()) {
    $info = '<p><a href="' . $vars['entity']->getUrl() . '"><strong>' . $vars['entity']->name . '</strong></a></p>';
    if (!$banned) $info .= elgg_view("profile/status", array("entity" => $vars['entity']));
    else          $info  = '<p class="warning">' . elgg_echo('admins:warning:banned', $vars['entity']->name) . '</p>';
    if ($vars['entity']->isAdmin()) {
        $first_admin = admins_get_first_admin();
 	if ($vars['entity']->guid == $first_admin->guid) {
	    $info.= '<p class="warning">' . elgg_echo('admins:warning:first_admin') . '</p>';
	} else {
	    $ts = time();
	    $token = generate_action_token($ts);
	    $info.= '<div class="admin_plugins_enable_disable">' . elgg_view('output/confirmlink', array('class' => '', 'text' => elgg_echo("removeadmin"), 'href' => "{$vars['url']}action/admin/user/removeadmin?guid={$vars['entity']->guid}&__elgg_token=$token&__elgg_ts=$ts")) . '</div>';
	}
    }
 
    echo elgg_view_listing($icon, $info);
    
} else {
    // Fallback to the original view
    include($CONFIG->pluginspath . 'profile/views/default/profile/listing.php');
}