<?php
/**
 * Elgg admins sub-component on the main menu.
 *
 * Adapted from:
 * 
 * @package Elgg
 * @subpackage Core
 * @author Curverider Ltd
 * @link http://elgg.org/
 */
?>
<div class="admin-menu-option">
	<h2><?php echo elgg_echo('admins:title'); ?> </h2>
	<p><?php echo elgg_echo('admins:opt:description'); ?><br />
	<a href="<?php echo $CONFIG->wwwroot . "pg/admins/"; ?>"><?php echo elgg_echo('admins:opt:anchor'); ?></a></p>
</div>