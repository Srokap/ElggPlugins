<?php 

?>
#admins_filter_box input.filter_input { width: 4em; display: inline; font-size: larger; font-weight: bold; }
#admins_filter_box legend { font-weight: bold; }

.warning { color: #c90; }