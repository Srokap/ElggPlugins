<?php

$english = array(
		 'admins:title'               => 'Manage Administrators',
		 'admins:description'         => 'View administrators and manage their privileges',
		 'admins:filter:legend'       => 'Only show admins whose name starts with',
		 'admins:filter:submit'       => 'Apply filter',
		 'admins:filter:tip'          => '(leave empty to reset filter and view all)',
 		 'admins:opt:anchor'          => 'manage administrators',
		 'admins:opt:description'     => 'View and manage administrators on your site.',
		 'admins:warning:banned'      => 'User <strong>%s</strong> was banned!',
		 'admins:warning:first_admin' => 'This is the original admin and cannot be deleted.',
		 );

add_translation("en", $english);
?>