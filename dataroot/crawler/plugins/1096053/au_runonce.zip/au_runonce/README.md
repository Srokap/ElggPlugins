AU-Run-Once-Collection
======================

A collection of run-once scripts to fix various such as plugin migration

This plugin should reside in mod/au_runonce