.au_runonce_run_script {
  border: 2px solid black;
  border-radius: 6px;
  padding: 5px;
  color: white;
  background-color: red;
}
