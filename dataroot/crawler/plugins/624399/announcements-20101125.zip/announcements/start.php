<?php

	/*
	** Announcements plugin
	**
	** Improves the River Dashboard by allowing multiple Site Announcements
	** 
	** @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	** @author Philip Hart, Centre for Learning and Performance Technology (http://www.c4lpt.co.uk/ElggConsultancy.html)
	** @copyright Institute of Physics, 2009
	** @link http://www.iop.org/
	*/

	function announcements_init()
	{	
		global $CONFIG;
			
		// Register message translations
		register_translations($CONFIG->pluginspath . "announcements/languages/");

		// Override Riverdashboard Sitemessage View
		set_view_location('riverdashboard/sitemessage',  $CONFIG->pluginspath . 'announcements/views/');
		
	}
		
	// Register Actions implemented by the announcements plugin
	register_action("riverdashboard/add",false,$CONFIG->pluginspath . "announcements/actions/add.php");
	register_action("riverdashboard/delete",false,$CONFIG->pluginspath . "announcements/actions/delete.php");

	// Finally initialise the plugin
	register_elgg_event_handler('init','system','announcements_init');
	
?>
