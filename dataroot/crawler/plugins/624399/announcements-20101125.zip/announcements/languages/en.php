<?php

$english = array(
		
	'sitemessage:numannouncements' => 'Number of site announcements to display',		

);

add_translation("en", $english);

?>
