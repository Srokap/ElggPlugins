<?php

	/**
	 * Site Announcements
	 *
	 * Modified version of River Dashboard to allow multiple Site Announcements
	 * 
	 * @package announcements
	 *
	 * Original Code
	 * =============
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider <info@elgg.com>
	 * @copyright Curverider Ltd 2008-2009, Institute of Physics 2009
	 * @link http://elgg.org/
	 *
	 * Modifications
	 * ============= 
	 * @author Philip Hart, Centre for Learning and Performance Technology (http://www.c4lpt.co.uk/ElggConsultancy.html)
	 * @copyright Institute of Physics 2009
	 * @link http://www.iop.org/
	 * 
	 */

	// Determine the number of site announcements to retrieve
	$settings = find_plugin_settings("announcements");
	$numAnnouncements = $settings->numAnnouncements;
	if ($numAnnouncements < 1) $numAnnouncements = 1;

	// Grab the current site messages
	$site_message = get_entities("object", "sitemessage", 0, "", $numAnnouncements);

?>

<!-- Content -->
<div class="sidebarBox">
	
<?php

	//if there is a site message
	if($site_message)
	{

		echo "<h3>" . elgg_echo("sitemessages:announcements") . "</h3>";

		// Output each message
		foreach($site_message as $mes)
		{
			$message = $mes->description;
			$dateStamp = friendly_time($mes->time_created);
			$delete = elgg_view("output/confirmlink",
						array(
								'href' => $vars['url'] . "action/riverdashboard/delete?message_guid=" . $mes->guid,
								'text' => elgg_echo('delete'),
								'confirm' => elgg_echo('deleteconfirm'),
						));

			//display the message
			echo '<p>' . $message;

			// Display message age
			echo " <small>($dateStamp)";

			// And, if admin, display the delete link
			if(isadminloggedin()) echo ' ' . $delete . ' ';	
			echo '</small></p>';

		}

		// Display an input form to add a new message
		if(isadminloggedin())
		{
			// Only display add message if the number of announcements exceeds the number specified by administrator
			if (sizeof($site_message) < $numAnnouncements)
			{
			//action
			$action = "riverdashboard/add";
			$link = elgg_echo("sitemessages:add");
			$input_area = elgg_view('input/plaintext', array('internalname' => 'sitemessage', 'value' => ''));
			$submit_input = elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('save')));
			$form_body = <<<EOT
	
			<p><a class="collapsibleboxlink">{$link}</a></p>
			<div class="collapsible_box">
				{$input_area}<br />{$submit_input}
			</div>
	
EOT;
			}
?>

<?php
			//display the form
			echo elgg_view('input/form', array('action' => "{$vars['url']}action/$action", 'body' => $form_body));

		}//end of admin if statement
?>
<?php
	// If there are no messages, add a form to create one
	}
	else
	{

		if(isadminloggedin())
		{
		
			//action
			$action = "riverdashboard/add";
			$link = elgg_echo("sitemessages:add");
			$input_area = elgg_view('input/text', array('internalname' => 'sitemessage', 'value' => ''));
			$submit_input = elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('save')));
			$form_body = <<<EOT
	
			<p><a class="collapsibleboxlink">{$link}</a></p>
			<div class="collapsible_box">
				{$input_area}<br />{$submit_input}
			</div>
EOT;
?>
<?php
		//display the form
		echo elgg_view('input/form', array('action' => "{$vars['url']}action/$action", 'body' => $form_body));

	}//end of admin check
	}//end of main if
?>
</div>
