<p>
<?php

	/*
	** 
	** @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	** @author Philip Hart, Centre for Learning and Performance Technology (http://www.c4lpt.co.uk/ElggConsultancy.html)
	** @copyright Institute of Physics, 2009
	** @link http://www.iop.org/
	*/

	// Number of Site Announcements Visible
	echo elgg_view('input/text', array('internalname'=>'params[numAnnouncements]', 'label'=>elgg_echo('sitemessage:numannouncements'), 'value'=>$vars['entity']->numAnnouncements ));

?>
</p>