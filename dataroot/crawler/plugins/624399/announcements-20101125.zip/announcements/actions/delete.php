<?php

	/**
	 * Elgg site message: delete
	 * 
	 * Modified version of riverdashboard file to forward correctly
	 *
	 * @package announcements
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.org/
	 */

	// Only Admin Users can delete site announcements
	//admingatekeeper();

	// Get input data
	$guid = (int) get_input('message_guid');
		
	// Make sure we actually have permission to edit
	$message = get_entity($guid);
	if ($message->getSubtype() == "sitemessage" && $message->canEdit())
	{
		// Delete it!
		$rowsaffected = $message->delete();

		// Test success and return appropriate status response
		if ($rowsaffected > 0)
		{
			system_message(elgg_echo("sitemessage:deleted"));
		}
		else
		{
			register_error(elgg_echo("sitemessage:notdeleted"));
		}
				
		// Return to the dashboard
		forward("pg/dashboard/");
		
	}
		
?>