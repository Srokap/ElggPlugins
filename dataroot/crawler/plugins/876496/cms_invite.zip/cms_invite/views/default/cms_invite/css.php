<?php
	/**
	 * cms_user_stats CSS
	 */
?>

.cms_invite_profile {
    padding: 3px 0 3px 5px;
    margin-top: 5px;
    background:blue;
}
.cms_invite_profile a {
    font-weight: bold;
    color: white;
}


