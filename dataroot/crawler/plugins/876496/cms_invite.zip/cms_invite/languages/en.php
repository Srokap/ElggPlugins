<?php
/**
 * cms_invite English language file
 */

$english = array(
	'cms_invite:joined' => "Members joined at %s's invitation ",
	'cms_invite:connector' => "Connector: ",
);

add_translation("en", $english);