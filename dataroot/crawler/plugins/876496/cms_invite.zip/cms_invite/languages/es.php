<?php
/**
 * cms_invite English language file
 */

$spanish = array(
	'cms_invite:joined' => "Miembros registrados por invitación de %s",
	'cms_invite:connector' => "Conector: ",
);

add_translation("es", $spanish);