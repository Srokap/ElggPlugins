<?php
if (isloggedin()) forward('activity');
?>
<html>
<head>
<?php
//Title configuration below
?>
<title>Welcome!</title>
        <?php
        //Favicon configuration below. Allows you to use a custom favicon for the HOMEPAGE only.
        ?>
        <link rel="shortcut icon" href=<?php echo $site_url; ?>"mod/homepage _1_8/icon.ico" type="image/x-icon"/>
    </head>
<?php $messages = system_messages();	
	$message = $messages['messages'];
	
	if(count($message) > 0){ 
		echo '<div  style="color: white;" class="messages">';
		echo '<span class="closeMessages"><a  style="color: white;" href="#">dismiss</a></span>';
			foreach($message as $message1)
					{
					echo '<p  style="color: white;">';
					echo $message1;
					echo '</p>';
					}
		echo '</div>';
	}

	$errors = register_error();
	$error = $errors['errors'];
	if(count($error) > 0){ 
		echo '<div class="messages_error">';
		echo '<span class="closeMessages"><a href="#">dismiss</a></span>';
			foreach($error as $error1)
					{
					echo '<p>';
					echo $error1;
					echo '</p>';
					}
		echo '</div>';
	}


////////////////////////////////////////////////////////////////////////////////////////////////
?>
<body>
<?php
//This is the body. Edit content here
?>

<body style="margin: 0px; padding: 0px; font-family: 'Trebuchet MS',verdana;">

<table width="100%" style="height: 100%;" cellpadding="10" cellspacing="0" border="0"><tr>

<!-- ============ LEFT COLUMN (MENU) ============== -->
<td width="20%" valign="top" bgcolor="#999f8e">
<?php
/**
 * Elgg login box
 *
 * @package Elgg
 * @subpackage Core
 *
 * @uses $vars['module'] The module name. Default: aside
 */

$module = elgg_extract('module', $vars, 'aside');

$login_url = elgg_get_site_url();
if (elgg_get_config('https_login')) {
	$login_url = str_replace("http:", "https:", $login_url);
}

$title = elgg_echo('login');
$body = elgg_view_form('login', array('action' => "{$login_url}action/login"));

echo elgg_view_module($module, $title, $body);
?>
</td>
<td width="80%" valign="top" bgcolor="#d2d8c7">
<center><h1>Welcome to the network.</h1></center>
<?php
// This is the place to put content in the body.
//If you have no html experiance use the html generator and copy and pasy at http://html.am
?>
<p><h3>ATTENTION WEBSITE OWNER</h3>
To edit this, in your file manager, go to yoursite/mod/homepage _1_8/homepage.php. If you have no HTML experience, use the 
html generator at <a  target="_blank" href="http://html.am">html.am</a>.</p>
<img src="http://www.thew2o.net/files/GlobalForumonOceans_oceanleadership.org_.jpg" width="810" height="300">
</td></tr></table>






