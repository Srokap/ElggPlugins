<?php

	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'quotes' => "Quotes",
			'quotes:add' => "Quote something",
			'quotes:add:group' => "Add quote to group",
			'quotes:read' => "Quoted items",
			'quotes:friends' => "Friends' quotes",
			'quotes:everyone' => "All site quotes",
			'quotes:this' => "Quote this",
			'quotes:this:group' => "Quote in %s",
			'quotes:quotelet' => "Get quotelet",
			'quotes:quotelet:group' => "Get group quotelet",
			'quotes:inbox' => "Quotes inbox",
			'quotes:more' => "More",
			'quotes:shareditem' => "Quoted item",
			'quotes:with' => "Share with",
			'quotes:new' => "A new quoted item",
			'quotes:via' => "via quotes",
			'quotes:address' => "Source Address of the quote - (Not Required)",
			'quotes:attrib' => "Attribution (Who said it?)",
			'quotes:quote' => "Quote",
			'quotes:delete:confirm' => "Are you sure you want to delete this resource?",
	
			'quotes:numbertodisplay' => 'Number of quoted items to display',
	
			'quotes:shared' => "Quoted",
			'quotes:visit' => "Visit resource",
			'quotes:recent' => "Recent quotes",
	
			'quotes:river:created' => '%s quoted',
			'quotes:river:annotate' => ' a comment on this quote',
			'quotes:river:item' => 'an item',
	
			'item:object:quotes' => 'Quoted items',
	
			'quotes:group' => 'Group quotes',
			'quotes:enablequotes' => 'Enable group quotes',
	
	
		/**
		 * More text
		 */
		    
		    'quotes:widget:description' => 
		            "This widget is designed for your dashboard and will show you the latest items in your quotes inbox.",
	
			'quotes:quotelet:description' =>
					"The quotes quotelet allows you to share any resource you find on the web with your friends, or just quote it for yourself. To use it, simply drag the following button to your browser's links bar:",

	        'quotes:quotelet:descriptionie' =>
					"If you are using Internet Explorer, you will need to right click on the quotelet icon, select 'add to favorites', and then the Links bar.",

			'quotes:quotelet:description:conclusion' =>
					"You can then save any page you visit by clicking it at any time.",
	
		/**
		 * Status messages
		 */
	
			'quotes:save:success' => "Your item was successfully quoted.",
			'quotes:delete:success' => "Your quoted item was successfully deleted.",
	
		/**
		 * Error messages
		 */
	
			'quotes:save:failed' => "Your quoted item could not be saved. Please try again.",
			'quotes:delete:failed' => "Your quoted item could not be deleted. Please try again.",
	
	
	);
					
	add_translation("en",$english);

?>
