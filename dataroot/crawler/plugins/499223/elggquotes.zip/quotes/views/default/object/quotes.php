<?php

	/**
	 * Elgg quote view
	 * 
	 * @package ElggQuotes
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider <info@elgg.com>
	 * @copyright Curverider Ltd 2008-2010
	 * @link http://elgg.org/
	 */

	$owner = $vars['entity']->getOwnerEntity();
	$friendlytime = friendly_time($vars['entity']->time_created);

	if (get_context() == "search") {

		if (get_input('search_viewtype') == "gallery") {

			$parsed_url = parse_url($vars['entity']->address);
			$faviconurl = $parsed_url['scheme'] . "://" . $parsed_url['host'] . "/favicon.ico";
		
			$info = "<p class=\"shares_gallery_title\">". elgg_echo("quotes:shared") .": <a href=\"{$vars['entity']->getURL()}\">{$vars['entity']->title}</a> (<a href=\"{$vars['entity']->address}\">".elgg_echo('quotes:visit')."</a>)</p>";
			$info .= "<p class=\"shares_gallery_user\">By: <a href=\"{$vars['url']}pg/quotes/{$owner->username}\">{$owner->name}</a> <span class=\"shared_timestamp\">{$friendlytime}</span></p>";
			$numcomments = elgg_count_comments($vars['entity']);
			if ($numcomments)
				$info .= "<p class=\"shares_gallery_comments\"><a href=\"{$vars['entity']->getURL()}\">".sprintf(elgg_echo("comments")). " (" . $numcomments . ")</a></p>";
			
			//display 
			echo "<div class=\"share_gallery_view\">";
			echo "<div class=\"share_gallery_info\">" . $info . "</div>";
			echo "</div>";


		} else {

			$parsed_url = parse_url($vars['entity']->address);
			$faviconurl = $parsed_url['scheme'] . "://" . $parsed_url['host'] . "/favicon.ico";
			if (@file_exists($faviconurl)) {
				$icon = "<img src=\"{$faviconurl}\" />";
			} else {
				$icon = elgg_view(
					"profile/icon", array(
										'entity' => $owner,
										'size' => 'tiny',
									  )
				);
			}
		
			$info = "<p class=\"shares_gallery_title\">
<a href=\"{$vars['entity']->getURL()}\">
<blockquote>{$vars['entity']->title}</blockquote>
<div style=\"text-align:right;\">{$vars['entity']->description}</div>
</a></p>";
$info .= '
&nbsp;&nbsp;&nbsp;
<script type="text/javascript">
tweetmeme_source = \'duuit\';
tweetmeme_style = \'compact\'; 
tweetmeme_url = \''.$vars['entity']->getURL().'\';
</script>
<script type="text/javascript" src="http://tweetmeme.com/i/scripts/button.js">
</script>';
//echo '<a title="Share with Friends" href="javascript:location.href=\'http://duuit.com/mod/bookmarks/add.php?address='.$vars['entity']->getURL().'&title='.$vars['entity']->title.'\'"><img align=top width="20" height="20" border="0" src="http://duuit.com/duuit-tiny.png" alt="Share with Friends" />lnx</a> ';

			$info .= "<p class=\"owner_timestamp\"><a href=\"{$vars['url']}pg/quotes/{$owner->username}\">{$owner->name}</a> {$friendlytime} from <a href=\"http://duuit.com/pg/pages/view/232581/\" title=\"What is this?\">Duuit!</a>";
			$numcomments = elgg_count_comments($vars['entity']);
			if ($numcomments)
				$info .= ", <a href=\"{$vars['entity']->getURL()}\">".sprintf(elgg_echo("comments")). " (" . $numcomments . ")</a>";
		    $info .= "</p>";
			echo elgg_view_listing($icon, $info);

		}
		
	} else {

?>
	<?php echo elgg_view_title(elgg_echo('quotes:shareditem'), false); ?>
	<div class="contentWrapper">
	<div class="sharing_item">
	
		<div class="sharing_item_title">
			<h1>
                                <a href="<?php echo $vars['entity']->getURL(); ?>"><?php echo elgg_view('output/longtext', array('value' => $vars['entity']->title)); ?></a>
			</h1>
		</div>
		<div class="sharing_item_description">
			<h4>
                               - <a href="/search/?searchType=fulltext&tag=<?php $turl = urlencode($vars['entity']->description); echo strtolower($turl); ?>"><?php echo $vars['entity']->description; ?></a>
			</h4>
		</div>
		<div class="sharing_item_owner">
			<p> 
&nbsp;&nbsp;&nbsp;
<script type="text/javascript">
tweetmeme_source = 'duuit';
tweetmeme_style = 'compact'; 
tweetmeme_url = '<?php echo $vars['entity']->getURL(); ?>';
</script>
<script type="text/javascript" src="http://tweetmeme.com/i/scripts/button.js"></script>
<a title="Share with Friends" href="javascript:location.href='http://duuit.com/mod/bookmarks/add.php?address=<?php echo $vars['entity']->getURL(); ?>&title=<?php echo $vars['entity']->title; ?>'"><img align=top width="20" height="20" border="0" src="http://duuit.com/duuit-tiny.png" alt="Share with Friends" />lnx</a>  

				<b>Posted by <a href="<?php echo $vars['url']; ?>pg/quotes/<?php echo $owner->username; ?>"><?php echo $owner->name; ?></a></b> 
				<?php echo $friendlytime; ?>
			</p>
		</div>
<?php

	$tags = $vars['entity']->tags;
	if (!empty($tags)) {

?>
		<div class="sharing_item_tags">
			<p>
				<?php echo elgg_view('output/tags',array('value' => $vars['entity']->tags)); ?>
			</p>
		</div>
<?php

	}

?>
		<div class="sharing_item_address">
			<p>
			</p>
		</div>		
		<?php

			if ($vars['entity']->canEdit()) {
		
		?>
		<div class="sharing_item_controls">
			<p>
				<a href="<?php echo $vars['url']; ?>mod/quotes/add.php?quote=<?php echo $vars['entity']->getGUID(); ?>"><?php echo elgg_echo('edit'); ?></a> &nbsp; 
				<?php 
						echo elgg_view('output/confirmlink',array(
						
							'href' => $vars['url'] . "action/quotes/delete?quote_guid=" . $vars['entity']->getGUID(),
							'text' => elgg_echo("delete"),
							'confirm' => elgg_echo("quotes:delete:confirm"),
						
						));  
					?>
			</p>
		</div>
		<?php

			}
		
		?>
	
	</div>
	</div>
<?php

	if ($vars['full'])
		echo elgg_view_comments($vars['entity']);

?>
	
<?php

	}

?>
