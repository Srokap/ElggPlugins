<?php

	/**
	 * Elgg get quotes quotelet view
	 * 
	 * @package ElggQuotes
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider <info@elgg.com>
	 * @copyright Curverider Ltd 2008-2010
	 * @link http://elgg.org/
	 */

	$page_owner = $vars['pg_owner'];
	
	$quotetext = elgg_echo("quotes:this");
	if ($page_owner instanceof ElggGroup)	
		$quotetext = sprintf(elgg_echo("quotes:this:group"), $page_owner->name)
?>
	<div class="contentWrapper">
	<p>
		<?php echo elgg_echo("quotes:quotelet:description"); ?>
	</p>
	<p class="sharing_quotelet">
		<a href="javascript:location.href='<?php echo $vars['url']; ?>pg/quotes/<?php echo $page_owner->username; ?>/add?address='+encodeURIComponent(location.href)+'&title='+encodeURIComponent(document.title)"> <img src="<?php echo $vars['url']; ?>_graphics/elgg_quotelet.gif" border="0" title="<?php echo $quotetext ?>" />   </a>
	</p>
	<p>
		<?php echo elgg_echo("quotes:quotelet:descriptionie"); ?>
	</p>
	<p>
		<?php echo elgg_echo("quotes:quotelet:description:conclusion"); ?>
	</p>
	</div>