<?php

	$portuguese	= array(

		/**
		 * Sites
		 */
	
			'item:site' => 'Sites',
	
		/**
		 * Sessions
		 */
			
			'login' => "Acessar",
			'loginok' => "Você acessou.",
			'loginerror' => "Acesso negado. Por favor, verifique seu usuário e senha e tente novamente.",
	
			'logout' => "Sair",
			'logoutok' => "Você deixou o Elgg.",
			'logouterror' => "Erro ao sair, por favor, tente novamente.",
	
		/**
		 * Errors
		 */
			'exception:title' => "Bem-vindo ao Elgg.",
	
			'InstallationException:CantCreateSite' => "Unable to create a default ElggSite with credentials Name:%s, Url: %s",
		
			'actionundefined' => "The requested action (%s) was not defined in the system.",
			'actionloggedout' => "Sorry, you cannot perform this action while logged out.",
	
			'notfound' => "The requested resource could not be found, or you do not have access to it.",
			
			'SecurityException:Codeblock' => "Denied access to execute privileged code block",
			'DatabaseException:WrongCredentials' => "Elgg couldn't connect to the database using the given credentials.",
			'DatabaseException:NoConnect' => "Elgg couldn't select the database '%s', please check that the database is created and you have access to it.",
			'SecurityException:FunctionDenied' => "Access to privileged function '%s' is denied.",
			'DatabaseException:DBSetupIssues' => "There were a number of issues: ",
			'DatabaseException:ScriptNotFound' => "Elgg couldn't find the requested database script at %s.",
			
			'IOException:FailedToLoadGUID' => "Failed to load new %s from GUID:%d",
			'InvalidParameterException:NonElggObject' => "Passing a non-ElggObject to an ElggObject constructor!",
			'InvalidParameterException:UnrecognisedValue' => "Unrecognised value passed to constuctor.",
			
			'InvalidClassException:NotValidElggStar' => "GUID:%d is not a valid %s",
			
			'PluginException:MisconfiguredPlugin' => "%s is a misconfigured plugin.",
			
			'InvalidParameterException:NonElggUser' => "Passing a non-ElggUser to an ElggUser constructor!",
			
			'InvalidParameterException:NonElggSite' => "Passing a non-ElggSite to an ElggSite constructor!",
			
			'InvalidParameterException:NonElggGroup' => "Passing a non-ElggGroup to an ElggGroup constructor!",
	
			'IOException:UnableToSaveNew' => "Unable to save new %s",
			
			'InvalidParameterException:GUIDNotForExport' => "GUID has not been specified during export, this should never happen.",
			'InvalidParameterException:NonArrayReturnValue' => "Entity serialisation function passed a non-array returnvalue parameter",
			
			'ConfigurationException:NoCachePath' => "Cache path set to nothing!",
			'IOException:NotDirectory' => "%s is not a directory.",
			
			'IOException:BaseEntitySaveFailed' => "Unable to save new object's base entity information!",
			'InvalidParameterException:UnexpectedODDClass' => "import() passed an unexpected ODD class",
			'InvalidParameterException:EntityTypeNotSet' => "Entity type must be set.",
			
			'ClassException:ClassnameNotClass' => "%s is not a %s.",
			'ClassNotFoundException:MissingClass' => "Class '%s' was not found, missing plugin?",
			'InstallationException:TypeNotSupported' => "Type %s is not supported. This indicates an error in your installation, most likely caused by an incomplete upgrade.",

			'ImportException:ImportFailed' => "Could not import element %d",
			'ImportException:ProblemSaving' => "There was a problem saving %s",
			'ImportException:NoGUID' => "New entity created but has no GUID, this should not happen.",
			
			'ImportException:GUIDNotFound' => "Entity '%d' could not be found.",
			'ImportException:ProblemUpdatingMeta' => "There was a problem updating '%s' on entity '%d'",
			
			'ExportException:NoSuchEntity' => "No such entity GUID:%d", 
			
			'ImportException:NoODDElements' => "No OpenDD elements found in import data, import failed.",
			'ImportException:NotAllImported' => "Not all elements were imported.",
			
			'InvalidParameterException:UnrecognisedFileMode' => "Unrecognised file mode '%s'",
			'InvalidParameterException:MissingOwner' => "All files must have an owner!",
			'IOException:CouldNotMake' => "Could not make %s",
			'IOException:MissingFileName' => "You must specify a name before opening a file.",
			'ClassNotFoundException:NotFoundNotSavedWithFile' => "Filestore not found or class not saved with file!",
			'NotificationException:NoNotificationMethod' => "No notification method specified.",
			'NotificationException:NoHandlerFound' => "No handler found for '%s' or it was not callable.",
			'NotificationException:ErrorNotifyingGuid' => "There was an error while notifying %d",
			'NotificationException:NoEmailAddress' => "Could not get the email address for GUID:%d",
			'NotificationException:MissingParameter' => "Missing a required parameter, '%s'",
			
			'DatabaseException:WhereSetNonQuery' => "Where set contains non WhereQueryComponent",
			'DatabaseException:SelectFieldsMissing' => "Fields missing on a select style query",
			'DatabaseException:UnspecifiedQueryType' => "Unrecognised or unspecified query type.",
			'DatabaseException:NoTablesSpecified' => "No tables specified for query.",
			'DatabaseException:NoACL' => "No access control was provided on query",
			
			'InvalidParameterException:NoEntityFound' => "No entity found, it either doesn't exist or you don't have access to it.",
			
			'InvalidParameterException:GUIDNotFound' => "GUID:%s could not be found, or you can not access it.",
			'InvalidParameterException:IdNotExistForGUID' => "Sorry, '%s' does not exist for guid:%d",
			'InvalidParameterException:CanNotExportType' => "Sorry, I don't know how to export '%s'",
			'InvalidParameterException:NoDataFound' => "Could not find any data.",
			'InvalidParameterException:DoesNotBelong' => "Does not belong to entity.",
			'InvalidParameterException:DoesNotBelongOrRefer' => "Does not belong to entity or refer to entity.",
			'InvalidParameterException:MissingParameter' => "Missing parameter, you need to provide a GUID.",
			
			'SecurityException:APIAccessDenied' => "Sorry, API access has been disabled by the administrator.",
			'SecurityException:NoAuthMethods' => "No authentication methods were found that could authenticate this API request.",
			'APIException:ApiResultUnknown' => "API Result is of an unknown type, this should never happen.", 
			
			'ConfigurationException:NoSiteID' => "No site ID has been specified.",
			'InvalidParameterException:UnrecognisedMethod' => "Unrecognised call method '%s'",
			'APIException:MissingParameterInMethod' => "Missing parameter %s in method %s",
			'APIException:ParameterNotArray' => "%s does not appear to be an array.",
			'APIException:UnrecognisedTypeCast' => "Unrecognised type in cast %s for variable '%s' in method '%s'",
			'APIException:InvalidParameter' => "Invalid parameter found for '%s' in method '%s'.",
			'APIException:FunctionParseError' => "%s(%s) has a parsing error.",
			'APIException:FunctionNoReturn' => "%s(%s) returned no value.",
			'SecurityException:AuthTokenExpired' => "Authentication token either missing, invalid or expired.",
			'CallException:InvalidCallMethod' => "%s must be called using '%s'",
			'APIException:MethodCallNotImplemented' => "Method call '%s' has not been implemented.",
			'APIException:AlgorithmNotSupported' => "Algorithm '%s' is not supported or has been disabled.",
			'ConfigurationException:CacheDirNotSet' => "Cache directory 'cache_path' not set.",
			'APIException:NotGetOrPost' => "Request method must be GET or POST",
			'APIException:MissingAPIKey' => "Missing X-Elgg-apikey HTTP header",
			'APIException:MissingHmac' => "Missing X-Elgg-hmac header",
			'APIException:MissingHmacAlgo' => "Missing X-Elgg-hmac-algo header",
			'APIException:MissingTime' => "Missing X-Elgg-time header",
			'APIException:TemporalDrift' => "X-Elgg-time is too far in the past or future. Epoch fail.",
			'APIException:NoQueryString' => "No data on the query string",
			'APIException:MissingPOSTHash' => "Missing X-Elgg-posthash header",
			'APIException:MissingPOSTAlgo' => "Missing X-Elgg-posthash_algo header",
			'APIException:MissingContentType' => "Missing content type for post data",
			'SecurityException:InvalidPostHash' => "POST data hash is invalid - Expected %s but got %s.",
			'SecurityException:DupePacket' => "Packet signature already seen.",
			'SecurityException:InvalidAPIKey' => "Invalid or missing API Key.",
			'NotImplementedException:CallMethodNotImplemented' => "Call method '%s' is currently not supported.",
	
			'NotImplementedException:XMLRPCMethodNotImplemented' => "XML-RPC method call '%s' not implemented.",
			'InvalidParameterException:UnexpectedReturnFormat' => "Call to method '%s' returned an unexpected result.",
			'CallException:NotRPCCall' => "Call does not appear to be a valid XML-RPC call",
	
			'PluginException:NoPluginName' => "The plugin name could not be found",
	
			'ConfigurationException:BadDatabaseVersion' => "The database backend you have installed doesn't meet the basic requirements to run Elgg. Please consult your documentation.",
			'ConfigurationException:BadPHPVersion' => "You need at least PHP version 5.2 to run Elgg.",
			'configurationwarning:phpversion' => "Elgg requires at least PHP version 5.2, you can install it on 5.1.6 but some features may not work. Use at your own risk.",
	
	
			'InstallationException:DatarootNotWritable' => "Your data directory %s is not writable.",
			'InstallationException:DatarootUnderPath' => "Your data directory %s must be outside of your install path.",
			'InstallationException:DatarootBlank' => "You have not specified a data directory.",
	
			'SecurityException:authenticationfailed' => "User could not be authenticated",
	
			'CronException:unknownperiod' => '%s is not a recognised period.',
	
			'SecurityException:deletedisablecurrentsite' => 'You can not delete or disable the site you are currently viewing!',
	
			'memcache:notinstalled' => 'PHP memcache module not installed, you must install php5-memcache',
			'memcache:noservers' => 'No memcache servers defined, please populate the $CONFIG->memcache_servers variable',
			'memcache:versiontoolow' => 'Memcache needs at least version %s to run, you are running %s',
			'memcache:noaddserver' => 'Multiple server support disabled, you may need to upgrade your PECL memcache library',
	
			'deprecatedfunction' => 'Warning: This code uses the deprecated function \'%s\' and is not compatible with this version of Elgg',
		/**
		 * API
		 */
			'system.api.list' => "List all available API calls on the system.",
			'auth.gettoken' => "This API call lets a user log in, returning an authentication token which can be used in leu of a username and password for authenticating further calls.",
	
		/**
		 * User details
		 */

			'name' => "Nome",
			'email' => "E-mail",
			'username' => "Usuário",
			'password' => "Senha",
			'passwordagain' => "Senha (novamente para verificação)",
			'admin_option' => "Tornar este usuário um administrador?",
	
		/**
		 * Access
		 */
	
			'PRIVATE' => "Privado",
			'LOGGED_IN' => "Usuários conectados",
			'PUBLIC' => "Público",
			'access:friends:label' => "Amigos",
			'access' => "Acesso",
	
		/**
		 * Dashboard and widgets
		 */
	
			'dashboard' => "Painel",
            'dashboard:configure' => "Editar página",
			'dashboard:nowidgets' => "Seu painel é sua porta de entrada para a rede social. Clique 'Editar página' para adicionar aplicativos para mantê-lo atualizado ao conteúdo e a sua vida na rede.",

			'widgets:add' => 'Adicionar aplicativos à sua página',
			'widgets:add:description' => "Escolha os aplicativos que deseja adicionar a sua página arrastandos-os a partir da <b>Galeria de Aplicativos</b> ao lado direito, para qualquer das três área de aplicativo abaixo, e os posicione onde desejar que eles apareçam.

Para remover um aplicativo arraste-o de volta para a <b>Galeria de Aplicativos</b>.",
			'widgets:position:fixed' => '(Posição fixa na página)',
	
			'widgets' => "Aplicativos",
			'widget' => "Aplicativo",
			'item:object:widget' => "Aplicativos",
			'layout:customise' => "Personalize o leiaute",
			'widgets:gallery' => "Galeria de Aplicativos",
			'widgets:leftcolumn' => "Aplicativos à esquerda",
			'widgets:fixed' => "Posição fixa",
			'widgets:middlecolumn' => "Aplicativos ao meio",
			'widgets:rightcolumn' => "Aplicativos à direita",
			'widgets:profilebox' => "Caixa de perfil",
			'widgets:panel:save:success' => "Seus aplicativos foram salvos com sucesso.",
			'widgets:panel:save:failure' => "Houve um problema ao salvar seu aplicativo. Por favor, tente novamente.",
			'widgets:save:success' => "O aplicativo foi salvo com sucesso.",
			'widgets:save:failure' => "Não foi possível salvar seu aplicativo. Por favor, tente novamente.",
			'widgets:handlernotfound' => 'Este aplicativo não está funcionando corretamente ou foi desabilitado pelo admninistrador.',
	
		/**
		 * Groups
		 */
	
			'group' => "Comunidade", 
			'item:group' => "Comunidades",
	
		/**
		 * Profile
		 */
	
			'profile' => "Perfil",
			'profile:edit:default' => 'Substituir os campos do perfil',
			'user' => "Usuário",
			'item:user' => "Usuários",
			'riveritem:single:user' => 'um usuário',
			'riveritem:plural:user' => 'alguns usuários',
	

		/**
		 * Profile menu items and titles
		 */
	
			'profile:yours' => "Seu perfil",
			'profile:user' => "Perfil de %s",
	
			'profile:edit' => "Editar perfil",
			'profile:profilepictureinstructions' => "A foto do perfil é a imagem apresentada na sua página. <br /> Você pode trocá-la quantas vezes quiser. (Formatos de arquivos aceitos: GIF, JPG ou PNG)",
			'profile:icon' => "Foto do peril",
			'profile:createicon' => "Crie seu avatar",
			'profile:currentavatar' => "Avatar atual",
			'profile:createicon:header' => "Foto do perfil",
			'profile:profilepicturecroppingtool' => "Ferramenta de cortar a foto do perfil",
			'profile:createicon:instructions' => "Clique e arraste um quadrado abaixo para delimitar a área para ajustar. Uma prévia da foto ajustada aparecerá na caixa à direita. Quando estiver satisfeito com a prévia, clique 'Criar avatar'. ESta imagem ajustada será usada em toda a rede social como o seu avatar. ",
	
			'profile:editdetails' => "Editar detalhes",
			'profile:editicon' => "Editar ícone do perfil",
	
			'profile:aboutme' => "Sobre mim", 
			'profile:description' => "Sobre mim",
			'profile:briefdescription' => "Descrição breve",
			'profile:location' => "Lotação",
			'profile:skills' => "Habilidades",  
			'profile:interests' => "Interesses", 
			'profile:contactemail' => "E-mail de contato",
			'profile:phone' => "Telefone",
			'profile:mobile' => "Celular",
			'profile:website' => "Website",
	
			'profile:banned' => 'Esta conta de usuário foi suspensa.',

			'profile:river:update' => "%s atualizou o perfil dele(a)",
			'profile:river:iconupdate' => "%s atualizou o ícone do perfil dele(a)",
	
			'profile:label' => "Rótulo do perfil",
			'profile:type' => "Tipo de perfil",
	
			'profile:editdefault:fail' => 'Perfil-padrão não pôde ser salvo',
			'profile:editdefault:success' => 'Ítem adicionado com sucesso ao perfil-padrão',
	
			
			'profile:editdefault:delete:fail' => 'Falha ao remover ítem do perfil-padrão',
			'profile:editdefault:delete:success' => 'Ítem do perfil-padrão apagado!',
	
			'profile:defaultprofile:reset' => 'Reiniciar perfil-padrão do sistema',
	
			'profile:resetdefault' => 'Reiniciar perfil-padrão',
	
		/**
		 * Profile status messages
		 */
	
			'profile:saved' => "Seu perfil foi salvo com sucesso.",
			'profile:icon:uploaded' => "Sua foto o perfil foi transferida com sucesso.",
	
		/**
		 * Profile error messages
		 */
	
			'profile:noaccess' => "Você não tem permissão para editar este perfil.",
			'profile:notfound' => "Não foi possível encontra o perfil especificado.",
			'profile:cantedit' => "Você não tem permissão para editar este perfil.",
			'profile:icon:notfound' => "Houve um problema ao transferir sua foto do perfil.",
	
		/**
		 * Friends
		 */
	
			'friends' => "Amigos",
			'friends:yours' => "Meus amigos",
			'friends:owned' => "Amigos de %s",
			'friend:add' => "Adicionar amigos",
			'friend:remove' => "Remover amigos",
	
			'friends:add:successful' => "Você adicionou %s como amigo.",
			'friends:add:failure' => "Não foi possível adicionar %s como amigo. Por favor, tente novamente.",
	
			'friends:remove:successful' => "Você removeu %s de sua lista de amigos.",
			'friends:remove:failure' => "Não foi possível remover %s de sua lista de amigos. Por favor, tente novamente.",
	
			'friends:none' => "Este usuário ainda não adicionou amigos.",
			'friends:none:you' => "Você aina não foi adicionado como amigo! Procure por seus interesses para começar a encontrar pessoas para seguir",
	
			'friends:none:found' => "Nenhum amigo foi encontrado.",
	
			'friends:of:none' => "Ninguém adicionou este usuário como amigo até agora.",
			'friends:of:none:you' => "Ninguém lhe adicionou como amigo até agora. Comece a adicionar conteúdo e a preencher seu perfil para que as pessoas possam encontrá-lo!",
	
			'friends:of:owned' => "Pessoas que tornaram %s amigo",

			 'friends:num_display' => "Número de amigos a mostrar",
			 'friends:icon_size' => "Tamanho do ícone",
			 'friends:tiny' => "mínimo",
			 'friends:small' => "pequeno",
			 'friends:of' => "Amigos de",
			 'friends:collections' => "Coleção de amigos",
			 'friends:collections:add' => "Nova coleção de amigos",
			 'friends:addfriends' => "Adicionar amigos",
			 'friends:collectionname' => "Nome da coleção",
			 'friends:collectionfriends' => "Amigos na coleção",
			 'friends:collectionedit' => "Editar esta coleção",
			 'friends:nocollections' => "Você ainda não tem coleções.",
			 'friends:collectiondeleted' => "Sua coleção foi apagada.",
			 'friends:collectiondeletefailed' => "Não foi possível apagar a coleção. Ou você não tem permissão,ou algum erro ocorreu.",
			 'friends:collectionadded' => "Sua coleção foi criada com sucesso",
			 'friends:nocollectionname' => "É preciso dar um nome à coleção antes de salvá-la.",
			'friends:collections:members' => "Membros das coleção",
			'friends:collections:edit' => "Editar coleção",
		
	        'friends:river:created' => "%s adicionou o aplicativo amigos.",
	        'friends:river:updated' => "%s atualizou o aplicativo amigos.",
	        'friends:river:delete' => "%s removeu o aplicativo amigos.",
	        'friends:river:add' => "%s agora é amigo de",
	
			'friendspicker:chararray' => 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
	
		/**
		 * Feeds
		 */
			'feed:rss' => 'Assinar o feed',
			'feed:odd' => 'Syndicate OpenDD',
			
		/**
          * links
		 **/

			'link:view' => 'ver link',

	
		/**
		 * River
		 */
			'river' => "River",			
			'river:relationship:friend' => 'é agora amigo de',
			'river:noaccess' => 'Você não tem permissão para ver este ítem.',
			'river:posted:generic' => '%s adicionou um post',

		/**
		 * Plugins
		 */
			'plugins:settings:save:ok' => "Configurações para o plugin %s salvas com sucesso.",
			'plugins:settings:save:fail' => "Houve um problema ao salvar as configurações para o plugin %s.",
			'plugins:usersettings:save:ok' => "Configurações de usuário para o plugin %s salvas com sucesso.",
			'plugins:usersettings:save:fail' => "Ocorreu um problema ao salvar as configurações de usuário para o plugin %s.",
			'admin:plugins:label:version' => "Versão",
			'item:object:plugin' => 'Configuração de plugin',
			
		/**
		 * Notifications
		 */
			'notifications:usersettings' => "Configuração de Notificação",
			'notifications:methods' => "Favor especificar quais métodos deseja permitir.",
	
			'notifications:usersettings:save:ok' => "Suas configurações de notificação foram salvas com sucesso.",
			'notifications:usersettings:save:fail' => "Houve um problema ao salvas as configurações de notificação.",
	
			'user.notification.get' => 'Informar as configurações de notificação para um determinado usuário.',
			'user.notification.set' => 'Definir as configurações de notificação para um determinado usuário.',
		/**
		 * Search
		 */
	
			'search' => "Procurar",
			'searchtitle' => "Procurar: %s",
			'users:searchtitle' => "Procurando usuários: %s",
			'advancedsearchtitle' => "%s com reultados iguais a %s",
			'notfound' => "Nenhum resultado foi encontrado.",
			'next' => "Próximo",
			'previous' => "Anterior",
	
			'viewtype:change' => "Mudar o modo de exibição",
			'viewtype:list' => "Lista",
			'viewtype:gallery' => "Galeria",
	
			'tag:search:startblurb' => "Itens com palavras-chave iguais a '%s':",

			'user:search:startblurb' => "Usuários iguais a '%s':",
			'user:search:finishblurb' => "Para ver mais, clique aqui.",
	
		/**
		 * Account
		 */
	
			'account' => "Conta",
			'settings' => "Configurações",
            'tools' => "Ferramentas",
            'tools:yours' => "Minhas ferramentas",
	
			'register' => "Register",
			'registerok' => "You have successfully registered for %s.",
			'registerbad' => "Your registration was unsuccessful. The username may already exist, your passwords might not match, or your username or password may be too short.",
			'registerdisabled' => "O registro de novos usuários foi desabilitado pelo administrador do sistema",
	
			'firstadminlogininstructions' => 'Your new Elgg site has been successfully installed and your administrator account created. You can now configure your site further by enabling various installed plugin tools.',
	
			'registration:notemail' => 'The email address you provided does not appear to be a valid email address.',
			'registration:userexists' => 'That username already exists',
			'registration:usernametooshort' => 'Your username must be a minimum of 4 characters long.',
			'registration:passwordtooshort' => 'The password must be a minimum of 6 characters long.',
			'registration:dupeemail' => 'This email address has already been registered.',
			'registration:invalidchars' => 'Sorry, your username contains invalid characters.',
			'registration:emailnotvalid' => 'Sorry, the email address you entered is invalid on this system',
			'registration:passwordnotvalid' => 'Sorry, the password you entered is invalid on this system',
			'registration:usernamenotvalid' => 'Sorry, the username you entered is invalid on this system',
	
			'adduser' => "Add User",
			'adduser:ok' => "You have successfully added a new user.",
			'adduser:bad' => "The new user could not be created.",
			
			'item:object:reported_content' => "Reported items",
	
			'user:set:name' => "Account name settings",
			'user:name:label' => "Your name",
			'user:name:success' => "Successfully changed your name on the system.",
			'user:name:fail' => "Could not change your name on the system.",
	
			'user:set:password' => "Account password",
			'user:password:label' => "Your new password",
			'user:password2:label' => "Your new password again",
			'user:password:success' => "Password changed",
			'user:password:fail' => "Could not change your password on the system.",
			'user:password:fail:notsame' => "The two passwords are not the same!",
			'user:password:fail:tooshort' => "Password is too short!",
	
			'user:set:language' => "Language settings",
			'user:language:label' => "Your language",
			'user:language:success' => "Your language settings have been updated.",
			'user:language:fail' => "Your language settings could not be saved.",
	
			'user:username:notfound' => 'Username %s not found.',
	
			'user:password:lost' => 'Lost password',
			'user:password:resetreq:success' => 'Successfully requested a new password, email sent',
			'user:password:resetreq:fail' => 'Could not request a new password.',
	
			'user:password:text' => 'To generate a new password, enter your username below. We will send the address of a unique verification page to you via email click on the link in the body of the message and a new password will be sent to you.',
	
			'user:persistent' => 'Remember me',
		/**
		 * Administration
		 */

			'admin:configuration:success' => "Your settings have been saved.",
			'admin:configuration:fail' => "Your settings could not be saved.",
	
			'admin' => "Administration",
			'admin:description' => "The admin panel allows you to control all aspects of the system, from user management to how plugins behave. Choose an option below to get started.",
			
			'admin:user' => "User Administration",
			'admin:user:description' => "This admin panel allows you to control user settings for your site. Choose an option below to get started.",
			'admin:user:adduser:label' => "Click here to add a new user...",
			'admin:user:opt:linktext' => "Configure users...",
			'admin:user:opt:description' => "Configure users and account information. ",
			
			'admin:site' => "Site Administration",
			'admin:site:description' => "This admin panel allows you to control global settings for your site. Choose an option below to get started.",
			'admin:site:opt:linktext' => "Configure site...",
			'admin:site:opt:description' => "Configure the site technical and non-technical settings. ",
			'admin:site:access:warning' => "Changing the access setting only affects the permissions on content created in the future.", 
			
			'admin:plugins' => "Tool Administration",
			'admin:plugins:description' => "This admin panel allows you to control and configure tools installed on your site.",
			'admin:plugins:opt:linktext' => "Configure tools...",
			'admin:plugins:opt:description' => "Configure the tools installed on the site. ",
			'admin:plugins:label:author' => "Author",
			'admin:plugins:label:copyright' => "Copyright",
			'admin:plugins:label:licence' => "Licence",
			'admin:plugins:label:website' => "URL",
			'admin:plugins:label:moreinfo' => 'more info',
			'admin:plugins:label:version' => 'Version',
			'admin:plugins:warning:elggversionunknown' => 'Warning: This plugin does not specify a compatible Elgg version.',
			'admin:plugins:warning:elggtoolow' => 'Warning: This plugin requires a later version of Elgg!',
			'admin:plugins:reorder:yes' => "Plugin %s was reordered successfully.",
			'admin:plugins:reorder:no' => "Plugin %s could not be reordered.",
			'admin:plugins:disable:yes' => "Plugin %s was disabled successfully.",
			'admin:plugins:disable:no' => "Plugin %s could not be disabled.",
			'admin:plugins:enable:yes' => "Plugin %s was enabled successfully.",
			'admin:plugins:enable:no' => "Plugin %s could not be enabled.",
	
			'admin:statistics' => "Statistics",
			'admin:statistics:description' => "This is an overview of statistics on your site. If you need more detailed statistics, a professional administration feature is available.",
			'admin:statistics:opt:description' => "View statistical information about users and objects on your site.",
			'admin:statistics:opt:linktext' => "View statistics...",
			'admin:statistics:label:basic' => "Basic site statistics",
			'admin:statistics:label:numentities' => "Entities on site",
			'admin:statistics:label:numusers' => "Number of users",
			'admin:statistics:label:numonline' => "Number of users online",
			'admin:statistics:label:onlineusers' => "Users online now",
			'admin:statistics:label:version' => "Elgg version",
			'admin:statistics:label:version:release' => "Release",
			'admin:statistics:label:version:version' => "Version",
	
			'admin:user:label:search' => "Find users:",
			'admin:user:label:seachbutton' => "Search", 
	
			'admin:user:ban:no' => "Can not ban user",
			'admin:user:ban:yes' => "User banned.",
			'admin:user:unban:no' => "Can not unban user",
			'admin:user:unban:yes' => "User un-banned.",
			'admin:user:delete:no' => "Can not delete user",
			'admin:user:delete:yes' => "User deleted",
	
			'admin:user:resetpassword:yes' => "Password reset, user notified.",
			'admin:user:resetpassword:no' => "Password could not be reset.",
	
			'admin:user:makeadmin:yes' => "User is now an admin.",
			'admin:user:makeadmin:no' => "We could not make this user an admin.",
	
			'admin:user:removeadmin:yes' => "User is no longer an admin.",
			'admin:user:removeadmin:no' => "We could not remove administrator privileges from this user.",
			
		/**
		 * User settings
		 */
			'usersettings:description' => "O painel de configurações de usuário permite controlar todas as suas configurações pessoais, de administração de usuários ao comportamento dos plugins. Escolha uma opção abaixo para começar.",
	
			'usersettings:statistics' => "Minhas estatísticas",
			'usersettings:statistics:opt:description' => "Ver informações estísticas sobre usuários e objetos na rede.",
			'usersettings:statistics:opt:linktext' => "Estatíscas de contas de usuários",
	
			'usersettings:user' => "Minhas configurações",
			'usersettings:user:opt:description' => "Este permite que você controle as configurações de usuários.",
			'usersettings:user:opt:linktext' => "Mude suas configurações",
	
			'usersettings:plugins' => "Ferramentas",
			'usersettings:plugins:opt:description' => "Configura suas ferramentas ativas, se houver.",
			'usersettings:plugins:opt:linktext' => "Configurar suas ferramentas",
	
			'usersettings:plugins:description' => "Este painel permite que você controle e configure as configurações pessoais para as ferramentas instaladas pelo administrador da rede.",
			'usersettings:statistics:label:numentities' => "Minhas entidades",
	
			'usersettings:statistics:yourdetails' => "Meus detalhes",
			'usersettings:statistics:label:name' => "Nome completo",
			'usersettings:statistics:label:email' => "E-mail",
			'usersettings:statistics:label:membersince' => "Membro desde",
			'usersettings:statistics:label:lastlogin' => "Último acesso em",
	
			
	
		/**
		 * Generic action words
		 */
	
			'save' => "Salvar",
			'publish' => "Publicar",
			'cancel' => "Cancelar",
			'saving' => "Salvando ...",
			'update' => "Atualizar",
			'edit' => "Editar",
			'delete' => "Apagar",
			'accept' => "Aceitar",
			'load' => "Carregar",
			'upload' => "Transferir",
			'ban' => "Banir",
			'unban' => "Desbanir",
			'enable' => "Habilitar",
			'disable' => "Desabilitar",
			'request' => "Requerer",
			'complete' => "Completar",
			'open' => 'Abrir',
			'close' => 'Fechar',
			'reply' => "Responer",
			'more' => 'Mais',
			'comments' => 'Commentários',
			'import' => 'Importar',
			'export' => 'Exportar',
	
			'up' => 'Subir',
			'down' => 'Descer',
			'top' => 'Topo',
			'bottom' => 'Base',
	
			'invite' => "Convidar",
	
			'resetpassword' => "Reiniciar senha",
			'makeadmin' => "Tornar administrador",
			'removeadmin' => "Remover administrador",
	
			'option:yes' => "Sim",
			'option:no' => "Não",
	
			'unknown' => 'Desconhecido',
	
			'active' => 'Ativo',
			'total' => 'Total',
	
			'learnmore' => "Clique para saber mais.",
	
			'content' => "conteúdo",
			'content:latest' => 'Últimas atividades',
			'content:latest:blurb' => 'Alternativamente, clique aqui para ver o conteúdo mais recente da rede.',
	
			'link:text' => 'ver link',
	
			'enableall' => 'Habilitar todos',
			'disableall' => 'Desabilitar todos',
	
		/**
		 * Generic questions
		 */
	
			'question:areyousure' => 'Você tem certeza?',
	
		/**
		 * Generic data words
		 */
	
			'title' => "Título",
			'description' => "Descrição",
			'tags' => "Palavras-chave",
			'spotlight' => "Destaque",
			'all' => "Todos",
	
			'by' => 'por',
	
			'annotations' => "Anotações",
			'relationships' => "Relacionamentos",
			'metadata' => "Metadata",
	
		/**
		 * Input / output strings
		 */

			'deleteconfirm' => "Você tem certeza que deseja apagar este item?",
			'fileexists' => "Um arquivo já foi transferido. Para substituí-lo, selecione-o abaixo:",
			
		/**
		 * User add
		 */

			'useradd:subject' => 'User account created',
			'useradd:body' => '
%s,

A user account has been created for you at %s. To log in, visit:

	%s

And log in with these user credentials:

	Username: %s
	Password: %s
	
Once you have logged in, we highly recommend that you change your password.
',
			
	    /**
         * System messages
         **/

			'systemmessages:dismiss' => "clique para sumir",

	
		/**
		 * Import / export
		 */
			'importsuccess' => "Importação de dados realizada com sucesso",
			'importfail' => "OpenDD import of data failed.",
	
		/**
		 * Time
		 */
	
			'friendlytime:justnow' => "agora",
			'friendlytime:minutes' => "%s minutos atrás",
			'friendlytime:minutes:singular' => "a minuto atrás",
			'friendlytime:hours' => "%s horas atrás",
			'friendlytime:hours:singular' => "uma hora atrás",
			'friendlytime:days' => "%s dias atrás",
			'friendlytime:days:singular' => "ontem",
	
			'date:month:01' => 'Janeiro %s',
			'date:month:02' => 'Fevereiro %s',
			'date:month:03' => 'Março %s',
			'date:month:04' => 'Abril %s',
			'date:month:05' => 'Maio %s',
			'date:month:06' => 'Junho %s',
			'date:month:07' => 'Julho %s',
			'date:month:08' => 'Agosto %s',
			'date:month:09' => 'Setembro %s',
			'date:month:10' => 'Outubro %s',
			'date:month:11' => 'Novembro %s',
			'date:month:12' => 'Dezembro %s',
	
	
		/**
		 * Installation and system settings
		 */
	
			'installation:error:htaccess' => "Elgg requires a file called .htaccess to be set in the root directory of its installation. We tried to create it for you, but Elgg doesn't have permission to write to that directory. 

Creating this is easy. Copy the contents of the textbox below into a text editor and save it as .htaccess

",
			'installation:error:settings' => "Elgg couldn't find its settings file. Most of Elgg's settings will be handled for you, but we need you to supply your database details. To do this:

1. Rename engine/settings.example.php to settings.php in your Elgg installation.

2. Open it with a text editor and enter your MySQL database details. If you don't know these, ask your system administrator or technical support for help.

Alternatively, you can enter your database settings below and we will try and do this for you...",
	
			'installation:error:configuration' => "Once you've corrected any configuration issues, press reload to try again.",
	
			'installation' => "Installation",
			'installation:success' => "Elgg's database was installed successfully.",
			'installation:configuration:success' => "Your initial configuration settings have been saved. Now register your initial user; this will be your first system administrator.",
	
			'installation:settings' => "System settings",
			'installation:settings:description' => "Now that the Elgg database has been successfully installed, you need to enter a couple of pieces of information to get your site fully up and running. We've tried to guess where we could, but <b>you should check these details.</b>",
	
			'installation:settings:dbwizard:prompt' => "Enter your database settings below and hit save:",
			'installation:settings:dbwizard:label:user' => "Database user",
			'installation:settings:dbwizard:label:pass' => "Database password",
			'installation:settings:dbwizard:label:dbname' => "Elgg database",
			'installation:settings:dbwizard:label:host' => "Database hostname (usually 'localhost')",
			'installation:settings:dbwizard:label:prefix' => "Database table prefix (usually 'elgg')",
	
			'installation:settings:dbwizard:savefail' => "We were unable to save the new settings.php. Please save the following file as engine/settings.php using a text editor.",
	
			'installation:sitename' => "The name of your site (eg \"My social networking site\"):",
			'installation:sitedescription' => "Short description of your site (optional)",
			'installation:wwwroot' => "The site URL, followed by a trailing slash:",
			'installation:path' => "The full path to your site root on your disk, followed by a trailing slash:",
			'installation:dataroot' => "The full path to the directory where uploaded files will be stored, followed by a trailing slash:",
			'installation:dataroot:warning' => "You must create this directory manually. It should sit in a different directory to your Elgg installation.",
			'installation:sitepermissions' => "The default access permissions:",
			'installation:language' => "The default language for your site:",
			'installation:debug' => "Debug mode provides extra information which can be used to diagnose faults, however it can slow your system down so should only be used if you are having problems:",
			'installation:debug:label' => "Turn on debug mode",
			'installation:httpslogin' => "Enable this to have user logins performed over HTTPS. You will need to have https enabled on your server for this to work.",
			'installation:httpslogin:label' => "Enable HTTPS logins",
			'installation:usage' => "This option lets Elgg send anonymous usage statistics back to Curverider.",
			'installation:usage:label' => "Send anonymous usage statistics",
			'installation:view' => "Enter the view which will be used as the default for your site or leave this blank for the default view (if in doubt, leave as default):",

			'installation:siteemail' => "Site email address (used when sending system emails)",
	
			'installation:disableapi' => "The RESTful API is a flexible and extensible interface that enables applications to use certain Elgg features remotely.",
			'installation:disableapi:label' => "Enable the RESTful API",
			
			'installation:allow_user_default_access:description' => "If checked, individual users will be allowed to set their own default access level that can over-ride the system default access level.",
			'installation:allow_user_default_access:label' => "Allow user default access",
	
			'installation:simplecache:description' => "The simple cache increases performance by caching static content including some CSS and JavaScript files. Normally you will want this on.",
			'installation:simplecache:label' => "Use simple cache",
	
			'upgrading' => 'Upgrading',
			'upgrade:db' => 'Your database was upgraded.',
			'upgrade:core' => 'Your elgg installation was upgraded',
	
		/**
		 * Welcome
		 */
	
			'welcome' => "Welcome",
			'welcome_message' => "Welcome to this Elgg installation.",
	
		/**
		 * Emails
		 */
			'email:settings' => "Email settings",
			'email:address:label' => "Your email address",
			
			'email:save:success' => "New email address saved, verification requested.",
			'email:save:fail' => "Your new email address could not be saved.",
	
			'friend:newfriend:subject' => "%s has made you a friend!",
			'friend:newfriend:body' => "%s has made you a friend!

To view their profile, click here:

	%s

You cannot reply to this email.",
	
	
	
			'email:resetpassword:subject' => "Password reset!",
			'email:resetpassword:body' => "Hi %s,
			
Your password has been reset to: %s",
	
	
			'email:resetreq:subject' => "Request for new password.",
			'email:resetreq:body' => "Hi %s,
			
Somebody (from the IP address %s) has requested a new password for their account.

If you requested this click on the link below, otherwise ignore this email.

%s
",

		/**
		 * user default access
		 */
	
		'default_access:settings' => "Your default access level",
		'default_access:label' => "Default access",
		'user:default_access:success' => "Your new default access level was saved.",
		'user:default_access:failure' => "Your new default access level could not be saved.",
	
		/**
		 * XML-RPC
		 */
			'xmlrpc:noinputdata'	=>	"Input data missing",
	
		/**
		 * Comments
		 */
	
			'comments:count' => "Comentários de %s",
			
			'riveraction:annotation:generic_comment' => '%s comentou sobre %s',
	
			'generic_comments:add' => "Adicionar um comentário",
			'generic_comments:text' => "Comentário",
			'generic_comment:posted' => "Seu comentário foi postado com sucesso.",
			'generic_comment:deleted' => "Seu comentário foi apagado com sucesso.",
			'generic_comment:blank' => "É preciso escrever algo antes de salvar um comentário.",
			'generic_comment:notfound' => "Não foi possível encontrar o item especificado.",
			'generic_comment:notdeleted' => "Não foi possível apagar este comentário.",
			'generic_comment:failure' => "Um erro inexperado ocorrei ao adicionar seu comentário. Por favor, tente novamente.",
	
			'generic_comment:email:subject' => 'Você tem um novo comentário!',
			'generic_comment:email:body' => "Você tem um novo comentário sobre seu item \"%s\" de %s. Ele diz:

			
%s


Para responder ou ver o item original, clique aqui:

	%s

Para ver o perfil de %s, clique aqui:

	%s

Você não pode responder a este e-mail.",
	
		/**
		 * Entities
		 */
			'entity:default:strapline' => 'Created %s by %s',
			'entity:default:missingsupport:popup' => 'This entity cannot be displayed correctly. This may be because it requires support provided by a plugin that is no longer installed.',
	
			'entity:delete:success' => 'Entity %s has been deleted',
			'entity:delete:fail' => 'Entity %s could not be deleted',
	
	
		/**
		 * Action gatekeeper
		 */
			'actiongatekeeper:missingfields' => 'Form is missing __token or __ts fields',
			'actiongatekeeper:tokeninvalid' => "We encountered an error (token mismatch). This probably means that the page you were using expired. Please try again.",
			'actiongatekeeper:timeerror' => 'The page you were using has expired. Please refresh and try again.',
			'actiongatekeeper:pluginprevents' => 'A extension has prevented this form from being submitted.',
	
		/**
		 * Word blacklists
		 */
			'word:blacklist' => 'and, the, then, but, she, his, her, him, one, not, also, about, now, hence, however, still, likewise, otherwise, therefore, conversely, rather, consequently, furthermore, nevertheless, instead, meanwhile, accordingly, this, seems, what, whom, whose, whoever, whomever',
	
		/**
		 * Languages according to ISO 639-1
		 */
			"aa" => "Afar",
			"ab" => "Abkhazian",
			"af" => "Afrikaans",
			"am" => "Amharic",
			"ar" => "Arabic",
			"as" => "Assamese",
			"ay" => "Aymara",
			"az" => "Azerbaijani",
			"ba" => "Bashkir",
			"be" => "Byelorussian",
			"bg" => "Bulgarian",
			"bh" => "Bihari",
			"bi" => "Bislama",
			"bn" => "Bengali; Bangla",
			"bo" => "Tibetan",
			"br" => "Breton",
			"ca" => "Catalan",
			"co" => "Corsican",
			"cs" => "Czech",
			"cy" => "Welsh",
			"da" => "Danish",
			"de" => "German",
			"dz" => "Bhutani",
			"el" => "Greek",
			"en" => "English",
			"eo" => "Esperanto",
			"es" => "Spanish",
			"et" => "Estonian",
			"eu" => "Basque",
			"fa" => "Persian",
			"fi" => "Finnish",
			"fj" => "Fiji",
			"fo" => "Faeroese",
			"fr" => "French",
			"fy" => "Frisian",
			"ga" => "Irish",
			"gd" => "Scots / Gaelic",
			"gl" => "Galician",
			"gn" => "Guarani",
			"gu" => "Gujarati",
			"he" => "Hebrew",
			"ha" => "Hausa",
			"hi" => "Hindi",
			"hr" => "Croatian",
			"hu" => "Hungarian",
			"hy" => "Armenian",
			"ia" => "Interlingua",
			"id" => "Indonesian",
			"ie" => "Interlingue",
			"ik" => "Inupiak",
			//"in" => "Indonesian",
			"is" => "Icelandic",
			"it" => "Italian",
			"iu" => "Inuktitut",
			"iw" => "Hebrew (obsolete)",
			"ja" => "Japanese",
			"ji" => "Yiddish (obsolete)",
			"jw" => "Javanese",
			"ka" => "Georgian",
			"kk" => "Kazakh",
			"kl" => "Greenlandic",
			"km" => "Cambodian",
			"kn" => "Kannada",
			"ko" => "Korean",
			"ks" => "Kashmiri",
			"ku" => "Kurdish",
			"ky" => "Kirghiz",
			"la" => "Latin",
			"ln" => "Lingala",
			"lo" => "Laothian",
			"lt" => "Lithuanian",
			"lv" => "Latvian/Lettish",
			"mg" => "Malagasy",
			"mi" => "Maori",
			"mk" => "Macedonian",
			"ml" => "Malayalam",
			"mn" => "Mongolian",
			"mo" => "Moldavian",
			"mr" => "Marathi",
			"ms" => "Malay",
			"mt" => "Maltese",
			"my" => "Burmese",
			"na" => "Nauru",
			"ne" => "Nepali",
			"nl" => "Dutch",
			"no" => "Norwegian",
			"oc" => "Occitan",
			"om" => "(Afan) Oromo",
			"or" => "Oriya",
			"pa" => "Punjabi",
			"pl" => "Polish",
			"ps" => "Pashto / Pushto",
			"pt" => "Portuguese",
			"qu" => "Quechua",
			"rm" => "Rhaeto-Romance",
			"rn" => "Kirundi",
			"ro" => "Romanian",
			"ru" => "Russian",
			"rw" => "Kinyarwanda",
			"sa" => "Sanskrit",
			"sd" => "Sindhi",
			"sg" => "Sangro",
			"sh" => "Serbo-Croatian",
			"si" => "Singhalese",
			"sk" => "Slovak",
			"sl" => "Slovenian",
			"sm" => "Samoan",
			"sn" => "Shona",
			"so" => "Somali",
			"sq" => "Albanian",
			"sr" => "Serbian",
			"ss" => "Siswati",
			"st" => "Sesotho",
			"su" => "Sundanese",
			"sv" => "Swedish",
			"sw" => "Swahili",
			"ta" => "Tamil",
			"te" => "Tegulu",
			"tg" => "Tajik",
			"th" => "Thai",
			"ti" => "Tigrinya",
			"tk" => "Turkmen",
			"tl" => "Tagalog",
			"tn" => "Setswana",
			"to" => "Tonga",
			"tr" => "Turkish",
			"ts" => "Tsonga",
			"tt" => "Tatar",
			"tw" => "Twi",
			"ug" => "Uigur",
			"uk" => "Ukrainian",
			"ur" => "Urdu",
			"uz" => "Uzbek",
			"vi" => "Vietnamese",
			"vo" => "Volapuk",
			"wo" => "Wolof",
			"xh" => "Xhosa",
			//"y" => "Yiddish",
			"yi" => "Yiddish",
			"yo" => "Yoruba",
			"za" => "Zuang",
			"zh" => "Chinese",
			"zu" => "Zulu",
	);
	
	add_translation("pt",$portuguese);

?>
