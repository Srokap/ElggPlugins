<h1><elgg:echo id="plugin:404:header" /></h1>
<p>
	<br />
	<elgg:echo id="plugin:404:content" /><br />
	<a href="<elgg:config var="wwwroot" />"><elgg:echo id="plugin:404:return" /></a>
</p>