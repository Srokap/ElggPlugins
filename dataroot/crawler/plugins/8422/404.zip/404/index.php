<?php

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");


	if (!trigger_plugin_hook('404', 'system', null, false)) 
	{

		elgg_throw_404();

	}
	
	

