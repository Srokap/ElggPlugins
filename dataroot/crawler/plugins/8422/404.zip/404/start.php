<?php

	/**
	 * Elgg 404 Plugin
	 * This plugin adds 404 pages to Elgg.
	 * 
	 * @package 404
	 * @license Modified BSD
	 * @author buggedcom <publicmail@buggedcom.co.uk>
	 * @copyright buggedcom 2008
	 * @link http://www.buggedcom.co.uk
	 */
	
	function elgg_throw_404()
	{
		if (strncasecmp(PHP_SAPI, 'cgi', 3))
		{
			$http_version = '1.0';
	        if (isset($_SERVER['SERVER_PROTOCOL']))
	        {
	            $http_version = substr($_SERVER['SERVER_PROTOCOL'], -3);
	        }
			header('HTTP/'. $http_version .' 404 File Not Found');
		}
		else
		{
			header('Status: 404 File Not Found');
		}

		$content = elgg_view_layout('two_column_left_sidebar', '', elgg_view('status/404'), '');
		
		echo page_draw(null, $content);
	}
