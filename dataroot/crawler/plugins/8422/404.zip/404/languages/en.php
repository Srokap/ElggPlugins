<?php

	$english = array(
	
		'plugin:404:header' => 'Page missing...',
		'plugin:404:content' => 'The page requested cannot be found!',
		'plugin:404:return' => 'Return to the frontpage.',
				
	);
					
	add_translation('en', $english);
