LiangLeeNews 1.0.0 <- initial release
(July 21, 2012 from https://github.com/lianglee/LiangLeeNews/tree/1.0.0)
