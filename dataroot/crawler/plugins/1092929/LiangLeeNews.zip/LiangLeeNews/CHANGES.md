LiangLeeNews 1.0.1

(August 12, 2012 from https://github.com/lianglee/LiangLeeNews/tree/1.0.1)


Bugfixes:

* fixed display news ( thanks to Pattyland ).

Enhancements :

* display news in custom page if need , suggested by kisssssss4ever ( thanks to mywife for adding this function )