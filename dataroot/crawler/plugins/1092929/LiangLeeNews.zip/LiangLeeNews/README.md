Liang Lee News Manager
========================

Features:

1.) News will displayed on All pages.

2.) Enable or Disable News.

3.) Add Text in Different Colors using.

4.) News can now be displayed on specficed page ( thanks to  my wife added in version 1.0.1 )