<?
/**
* Kaltura video client
* @package ElggKalturaVideo
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author Ivan Vergés - Ballo Microstudi SL <ivan@microstudi.net>
* @copyright Ballo Microstudi SL 2008
* @link http://microstudi.net/elgg/
* ****************************************
* @Italian Language Pack
* @Plugin System
* @Italian Support Group: http://community.elgg.org/pg/groups/271/italian-support-group/
* @translation by Milord <milord@nobiltadeipari.com> 
* @link http://www.nobilityofequals.com
****************************************/


$italian = array(
	'kalturavideo:label:partner_id' => 'Partner ID',
	'kalturavideo:label:subp_id' => 'Sub-Partner ID',
	'kalturavideo:label:admin_secret' => 'Administrator Secret',
	'kalturavideo:label:secret' => 'Web Service Secret',
	'kalturavideo:title:video' => 'I video di '.$CONFIG->sitename,
	'kalturavideo:descprefix:video' => 'Un video da Kaltura di',
	'kalturavideo:text:loginkaltura' => 'Puoi ottenere questo dato dal sito di kaltura in:',
	'kalturavideo:text:buttoninfo' => '(Premi il link "Account" -> "General Info")',
	'kalturavideo:text:signupkaltura' => 'Devi essere un partner per accedere, iscriviti qui se è richiesto:',
	'kalturavideo:label:videotitle' => 'Titolo del video creato',
	'kalturavideo:label:addvideo' => 'Aggiungi un video da Kaltura',
	'kalturavideo:label:uid_prefix' => 'Kaltura cms user prefix',
	'kalturavideo:error:misconfigured' => 'Plugin non configurato o errore di autenticazione su Kaltura!',
	'kalturavideo:label:closewindow' => 'Chiudi la finestra',
	'kalturavideo:label:select_size' => 'Seleziona la grandezza del player',
	'kalturavideo:label:large' => 'Grande',
	'kalturavideo:label:small' => 'Piccola',
	'kalturavideo:label:insert' => 'Inserisci il video',
	'kalturavideo:label:edit' => 'Edit video',
	'kalturavideo:label:miniinsert' => 'Inserisci',
	'kalturavideo:label:miniedit' => 'Modifica',
	'kalturavideo:label:cancel' => 'Cancella',
	'kalturavideo:label:back' => 'Indietro',
	'kalturavideo:label:publish' => 'Pubblica',
	'kalturavideo:label:gallery' => 'Galleria',
	'kalturavideo:label:next' => 'Avanti',
	'kalturavideo:label:prev' => 'Indietro',
	'kalturavideo:label:start' => 'Inizia',
	'kalturavideo:label:newvideo' => 'Crea un nuovo video',
	'kalturavideo:label:toolsadmin' => 'Amministrazione -> Amministrazione Strumenti (clicca "more info")',
	'kalturavideo:label:gotoconfig' => 'Per favore, configura correttamente Kaltura Video qui sotto ',
);

add_translation("it", $italian);

?>