<?php

/**
 * MNet Library 
 * Copyright (C) 2006-2008 Catalyst IT Ltd (http://www.catalyst.net.nz)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @package    mnet
 * @subpackage core
 * @author     Catalyst IT Ltd
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL
 * @copyright  (C) 2006-2008 Catalyst IT Ltd http://catalyst.net.nz
 * @copyright  (C) portions from Moodle, (C) Martin Dougiamas http://dougiamas.com
 *
 */


/**
 * This is the base class of all extensions, and includes some methods they
 * must implement
 */
abstract class mnet_extension {
    /**
     * This method must be overridden in extensions to perform an ACL check against
     * the provided client host and method name to make sure it may be called
     *
     * Additional validation may also be performed by overriding validate_call()
     *
     * @param mnet_client $client the client attempting to call (may be null during a system/keyswap call)
     * @param string $method the name of the method to be invoked (without the leading rpc_ prefix)
     * @return bool true if the call is allowed
     */
    public abstract function check_call_access($client, $method);

    /**
     * Checks whether the method and params specified may be called on this extension.
     * Note access is usually already checked by the implementation of check_call_access(),
     * this serves just to ensure that the method is callable.
     *
     * If you need to do ACL based on the passed parameters, you may override this method
     * and perform additional checking (having stashed the mnet_peer instance in check_call_access())
     *
     * Note that the method will be translated to rpc_$method when resolving the actual PHP method
     * to call, as all incoming calls are handled by rpc_* methods of extension implementations.
     *
     * @param string $method the method being called
     * @param array $params an array of parameters that would be passed to the method
     * @return bool true if the method is callable with these params
     */
    public function validate_call($method, $params) {
        // Does the corresponding PHP method even exist?
        if (!method_exists($this, 'rpc_'.$method)) {
            // nope - failed already!
            return false;
        }

        // Is this the right parameter count?
        $method_reflector = new ReflectionMethod(get_class($this), 'rpc_'.$method);
        if ($method_reflector->getNumberOfParameters() != count($params)) {
            // wrong parameter count
            return false;
        }

        // Seems good!
        return true;
    }
    
    
    /**
     * Returns an implementation (if required) of an extension, ready either to
     * process an incoming request, or to make an outgoing request
     *
     * Extensions should be registered by a previous call to mnet::init()
     *
     * The extensions registered must subclass mnet_extension_$id to be found
     *
     * @param string $id the extension ID, eg. authentication, system, etc
     */
    public static function get($id) {
        global $MNET_EXTENSIONS;

        foreach ($MNET_EXTENSIONS as $ext) {
            // handle completely custom extensions (extending mnet_extension only)
            // and standard extensions (extending mnet_extension_$id)
            if (is_subclass_of($ext, 'mnet_extension_'.$id) || get_class($ext) == 'mnet_extension_'.$id) {
                return $ext;
            }
        }

        // Haven't found an instance yet - try some other stuff before failing
        if ($id == 'system') {
            // This extension doesn't need to be implemented explicitly
            require_once MNET_DIR.'/extensions/system.php';
            return new mnet_extension_system();
        }

        // Unable to find that extension
        return null;
    }
}
