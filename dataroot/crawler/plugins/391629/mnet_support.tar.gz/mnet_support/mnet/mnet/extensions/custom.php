<?php

/**
 * MNet Library 
 * Copyright (C) 2006-2008 Catalyst IT Ltd (http://www.catalyst.net.nz)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @package    mnet
 * @subpackage core
 * @author     Catalyst IT Ltd
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL
 * @copyright  (C) 2006-2008 Catalyst IT Ltd http://catalyst.net.nz
 * @copyright  (C) portions from Moodle, (C) Martin Dougiamas http://dougiamas.com
 *
 */


/**
 * The "custom" extension is used for arbitrary code execution. It relies on
 * system-specific implementations for calling conventions, eg. Moodle will have
 * different custom invoke properties than Drupal. Each system should implement
 * the custom execute method for its system type, and this base class will take care
 * of denying others.
 * 
 * This class is primarily for backwards compatibility with MNet-1 in Moodle. Old
 * call with XML-RPC methods like 'mod/modname/funcname' will get mapped on to the
 * execute_moodle() method of this extension.
 * 
 * It would be a good idea to lock down access to this extension if it's not required,
 * as it presents a rather big security hole if improperly configured.
 * 
 */
class mnet_extension_custom extends mnet_extension {
    /**
     * Override the validate_call() method since we don't want to validate
     * the parameters, only the method name.
     *
     * @param string $method the method to execute
     * @param array $params the params passed
     * @return bool true if the call would work
     * @override
     */
    public function validate_call($method, $params) {
        if (method_exists($this, 'rpc_'.$method)) {
            return true;
        }

        return false;
    }
    
    /**
     * Stub for execution on a Moodle system
     * 
     * The Moodle system should implement this extension
     * 
     * @param string $module the module to load and invoke
     * @param string $file the filename to load within that module
     * @param string $function the function to invoke in that file
     * @param mixed additional parameters are to that function
     * @return mixed whatever comes back from that function 
     */
    public function rpc_execute_moodle($module, $file, $function) {
        $params = func_get_args();
        array_shift($params);
        array_shift($params);
        array_shift($params);

        // Implementation would then do something with this
        // ... but this one doesn't!

        // TODO need a "not implemented" fault
        throw new mnet_xmlrpc_fault(702, 'nosuchfunction');
    }
}
