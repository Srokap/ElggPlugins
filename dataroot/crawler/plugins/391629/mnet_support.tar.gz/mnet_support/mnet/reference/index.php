<?php

/**
 * This file simply exists to return a valid title for wwwroot name discovery in mnet_peer
 */
 
require 'bootstrap.php';
global $MNET, $MNET_APPLICATION;

header('Content-type: text/html', true);

?>
<html>
  <head>
    <title>MNet reference implementation at <?php echo htmlspecialchars($MNET->get_local_wwwroot()); ?></title>
  </head>
  <body>
    <h1>MNet reference implementation at <?php echo htmlspecialchars($MNET->get_local_wwwroot()); ?></h1>

  	<h2>Operations</h2>
    <ul>
    	<li><a href="add_peer.php">Add a new peer (automatically)</a></li>
    	<li><a href="add_peer_manual.php">Add a new peer (manually)</a></li>
    	<li><a href="ping.php">Ping a peer (test if it's there)</a></li>
    	<li><a href="publickey.php">View the local public key</a></li>
    	<li><a href="test_message.php">Do a loopback encryption test</a></li>
    	<li><a href="force_newkey.php">Force a local public/private keypair rotation</a></li>
    </ul>
    
    <h2>Known Peers</h2>
    <table border="1">
    	<tr>
    		<th>wwwroot</th>
    		<th>Protocol version</th>
    		<th>Server path</th>
    	</tr>
    	<?php
    	$peers = $MNET_APPLICATION->get_all_peers();
    	foreach ($peers as $peer) {
    		echo '<tr><td>'.htmlspecialchars($peer->get_wwwroot()).'</td><td>'.$peer->get_protocol().'</td><td>'.htmlspecialchars($peer->get_server_path()).'</td></tr>';
    	}
    	?>
    </table>
  </body>
</html>
