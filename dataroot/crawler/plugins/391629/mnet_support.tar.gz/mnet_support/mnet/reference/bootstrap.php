<?php

/**
 * MNet Library 
 * Copyright (C) 2006-2008 Catalyst IT Ltd (http://www.catalyst.net.nz)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @package    mnet
 * @subpackage reference
 * @author     Catalyst IT Ltd
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL
 * @copyright  (C) 2006-2008 Catalyst IT Ltd http://catalyst.net.nz
 * @copyright  (C) portions from Moodle, (C) Martin Dougiamas http://dougiamas.com
 *
 */


/**
 * This script bootstraps MNet for the reference implementation, including registering our
 * extension implementations.
 * 
 * Other MNet test scripts should include this one.
 */

header('Content-type: text/plain; charset=UTF-8');
ini_set('html_errors', 0);

// you may need to change this path
require_once '../mnet/mnet.php';

// Load our application abstraction layer
require_once 'lib/mnet_application_reference.php';

// Discover our wwwroot from Apache - this is up to the reference directory without 
// the script name or slash, eg. http://example.org/foo/test.php -> http://example.org/foo
$wwwroot = 'http://'.$_SERVER['SERVER_NAME'].$_SERVER['SCRIPT_NAME'];
$wwwroot = str_replace('/'.basename($_SERVER['SCRIPT_FILENAME']), '', $wwwroot);

// Our storage directory is constructed from the host and path of our wwwroot
// On UNIX systems this will usually be somewhere under /tmp/mnet
$url = parse_url($wwwroot);
$storage_dir = sys_get_temp_dir().'/mnet/'.$url['host'].'.'.str_replace('/', '', $url['path']);

// Discover and instantiate our extension implementations
$extensions = array();
foreach (glob(dirname(__FILE__).'/lib/mnet_extension_*_reference.php') as $extension_file) {
    include $extension_file;
    if (preg_match('@mnet_extension_(.+?)_reference.php$', $extension_file, $m)) {
        $class = 'mnet_extension_'.$m[1];
        if (class_exists($class)) {
            $extensions[] = new $class();
        }
    }
}

mnet::init(new mnet_reference_system($wwwroot, $storage_dir), $extensions);
