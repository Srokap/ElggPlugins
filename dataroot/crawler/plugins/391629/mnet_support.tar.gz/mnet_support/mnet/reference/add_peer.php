<?php

/**
 * Add a new peer, retrieving their public key over an untrusted channel
 *
 * Call this script with GET vars wwwroot and server_path
 * The protocol will be autodetected
 */

require 'bootstrap.php';
 
if (empty($_GET['wwwroot']) || empty($_GET['server_path'])) {
  die('require wwwroot and server_path vars');
}

$peer = mnet_peer::bootstrap($_GET['wwwroot'], null, $_GET['server_path']);

echo "New peer:\n".print_r($peer);
