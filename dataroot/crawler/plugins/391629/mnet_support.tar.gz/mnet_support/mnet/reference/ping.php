<?php

/**
 * Send a ping to a remote peer (also initiates a keyswap if necessary)
 *
 * Takes a GET parameter of remote_wwwroot to specify who to ping
 */
 
require 'bootstrap.php';
 
if (!isset($_GET['remote_wwwroot'])) {
  die ('Need remote_wwwroot GET param');
}

// Attempt to retrieve the peer
global $MNET_APPLICATION;
$peer = $MNET_APPLICATION->get_peer_by_wwwroot($_GET['remote_wwwroot']);

if (!$peer) {
  die('unknown remote peer');
}

// Make the ping call
$system = mnet_extension::get('system');

$res = $system->ping($peer);

echo "Ping result: $res\n";


