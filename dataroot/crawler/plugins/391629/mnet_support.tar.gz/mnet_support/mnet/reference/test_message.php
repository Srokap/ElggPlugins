<?php

/**
 * MNet Library 
 * Copyright (C) 2006-2008 Catalyst IT Ltd (http://www.catalyst.net.nz)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @package    mnet
 * @subpackage reference
 * @author     Catalyst IT Ltd
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL
 * @copyright  (C) 2006-2008 Catalyst IT Ltd http://catalyst.net.nz
 * @copyright  (C) portions from Moodle, (C) Martin Dougiamas http://dougiamas.com
 *
 */


/**
 * This is a test suite for mnet_message. It will take an XML string from cleartext through
 * to signed and encrypted, then reverse the process, using just our local keys
 */

require 'bootstrap.php';

$orig_xml = '<test><message>Hello, world!</message></test>';

echo "Original: $orig_xml\n";

$msg = new mnet_message($orig_xml);

echo 'State is now: '.$msg->get_state().PHP_EOL;

global $MNET;
$keypair_pem = $MNET->get_keypair_pem();
$certificate = $MNET->get_public_key_cert();

echo "Signing with private key PEM:\n".$keypair_pem."\n\n";

$msg->sign($keypair_pem);

echo "Message is state ".$msg->get_state().":\n".$msg->get_xml()."\n\n";

echo "Encrypting with public key certificate: \n",$certificate."\n\n";

$msg->encrypt($certificate);

echo "Message is state ".$msg->get_state().":\n".$msg->get_xml()."\n\n";

echo "Decrypting with private key\n";

$msg->decrypt($keypair_pem);

echo "Message is state ".$msg->get_state().":\n".$msg->get_xml()."\n\n";

echo "WWWroot is ".$msg->get_wwwroot().PHP_EOL;
echo "Timestamp is ".$msg->get_timestamp().PHP_EOL;
echo "Protocol is ".$msg->get_protocol().PHP_EOL;

echo "Checking signature against PK cert... ";

if ($msg->check_signature($certificate)) {
  echo "OK\n";
}
else {
  die ("Failed\n");
}

$msg->strip_signature();

echo "Stripped signature, state is ".$msg->get_state()." message is:\n".$msg->get_xml();
