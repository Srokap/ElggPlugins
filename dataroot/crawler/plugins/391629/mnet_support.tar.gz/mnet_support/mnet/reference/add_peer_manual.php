<?php

/**
 * Add a new peer by adding their public key manually and testing
 * with a ping
 *
 */

?>

<html>
<head>
	<title>Add peer manually</title>
</head>
<body>
<form action="" method="post">
<p>
	wwwroot: <input type="text" name="wwwroot" /><br />
	public key certificate (X.509): <textarea rows="10" cols="40" name="pubkey"></textarea><br />
	server path: <input type="text" name="server_path" />
	<input type="submit" />
</p>
</form>
<?php

if ($_POST) {
	require 'bootstrap.php';

	$peer = mnet_peer::bootstrap($_POST['wwwroot'], $_POST['pubkey'], $_POST['server_path']);
	
	echo "<p>New peer:<br /><pre>".htmlspecialchars(print_r($peer, true)).'</pre></p>';
}
?>
</body>
</html>
