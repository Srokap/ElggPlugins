<?php

  /**
   * MNET Support Plugin for ELGG
   * Copyright (C) 2009 Solution Grove (http://solutiongrove.com)
   *
   * This program is free software: you can redistribute it and/or modify
   * it under the terms of the GNU General Public License as published by
   * the Free Software Foundation, either version 3 of the License, or
   * (at your option) any later version.
   *
   * This program is distributed in the hope that it will be useful,
   * but WITHOUT ANY WARRANTY; without even the implied warranty of
   * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   * GNU General Public License for more details.
   *
   * You should have received a copy of the GNU General Public License
   * along with this program.  If not, see <http://www.gnu.org/licenses/>.
   *
   * @author     Solution Grove
   * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL
   * @copyright  (C) 2009 Solution Grove (http://solutiongrove.com)
   *
   * This plugin uses mnet-lib and some portions where inspired by
   * the mnet-lib Drupal implementation. (http://code.google.com/p/mnet-lib/)
   *
   * mnet-lib and mnet-lib Drupal implementation (C) Neil Bertram 
   *
   */

global $CONFIG;
include_once ($CONFIG->pluginspath . "mnet_support/includes/functions.php");

function mnet_support_init() {
}

register_elgg_event_handler('init','system','mnet_support_init');       

register_page_handler ( 'mnet_support', 'mnet_support_page_handler' );

register_elgg_event_handler ( 'pagesetup', 'system', 'mnet_support_pagesetup' );

register_action ( "mnet_support/peerdelete", false, $CONFIG->pluginspath . "mnet_support/actions/peerdelete.php" );


function mnet_support_page_handler($page) {
	global $CONFIG;
	if (isset ( $page [0] )) {
		switch ($page [0]) {
			case "admin" :
				include ($CONFIG->pluginspath . "mnet_support/pages/admin.php");
				break;
			case "newkey" :
				include ($CONFIG->pluginspath . "mnet_support/pages/force_newkey.php");
				break;
			case "publickey" :
				include ($CONFIG->pluginspath . "mnet_support/pages/publickey.php");
				break;
			case "peers" :
                if (isset ( $page [1] )) {
                    switch ($page [1]) {
                        case "ping" :
                          if (isset ( $page [2] )) {
                            set_input( 'peer_guid', $page[2] );
                            include ($CONFIG->pluginspath . "mnet_support/pages/ping.php");
                            break;
                          }
                        case "jump" :
                          if (isset ( $page [2] )) {
                            set_input( 'peer_guid', $page[2] );
                            include ($CONFIG->pluginspath . "mnet_support/pages/jump.php");
                            break;
                          }
                        case "world" :
                          include ($CONFIG->pluginspath . "mnet_support/pages/allpeers.php");
                          break;
                    }
                }
				include ($CONFIG->pluginspath . "mnet_support/pages/peers.php");
				break;
			default :
				break;
		}
	}
}

function mnet_support_pagesetup() {
	global $CONFIG;
    add_menu(elgg_echo('mnet_support:menu:mnet'), $CONFIG->wwwroot . "pg/mnet_support/peers/world/");
	if (get_context () == 'admin') {
      add_submenu_item ( elgg_echo('mnet_support:menu:configure_mnet_support'), $CONFIG->wwwroot . 'pg/mnet_support/admin/' );
	}
}

?>