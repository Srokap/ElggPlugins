<?php

  /**
   * MNET Support Plugin for ELGG
   * Copyright (C) 2009 Solution Grove (http://solutiongrove.com)
   *
   * This program is free software: you can redistribute it and/or modify
   * it under the terms of the GNU General Public License as published by
   * the Free Software Foundation, either version 3 of the License, or
   * (at your option) any later version.
   *
   * This program is distributed in the hope that it will be useful,
   * but WITHOUT ANY WARRANTY; without even the implied warranty of
   * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   * GNU General Public License for more details.
   *
   * You should have received a copy of the GNU General Public License
   * along with this program.  If not, see <http://www.gnu.org/licenses/>.
   *
   * @author     Solution Grove
   * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL
   * @copyright  (C) 2009 Solution Grove (http://solutiongrove.com)
   *
   * This plugin uses mnet-lib and some portions where inspired by
   * the mnet-lib Drupal implementation. (http://code.google.com/p/mnet-lib/)
   *
   * mnet-lib and mnet-lib Drupal implementation (C) Neil Bertram 
   *
   */

?>

<div class="sidebarBox">
  <div id="owner_block_submenu">
    <b><?php echo elgg_echo('mnet_support:mnet_support'); ?></b><br />
    <ul>
<?php
	global $CONFIG;
	if(isadminloggedin()){
        echo "<li><a href=\"".$CONFIG->wwwroot."pg/mnet_support/admin/\">" . elgg_echo('mnet_support:server_info') . "</a></li>";
        echo "<li><a href=\"".$CONFIG->wwwroot."pg/mnet_support/peers/\">" . elgg_echo('mnet_support:peers') . "</a></li>";
        echo "<li><a href=\"".$CONFIG->wwwroot."pg/mnet_support/publickey/\">" . elgg_echo('mnet_support:view_current_public_key') . "</a></li>";
        echo "<li>".elgg_view("output/confirmlink", array(
                                                          'href' => $CONFIG->wwwroot."pg/mnet_support/newkey/",
                                                          'text' => elgg_echo('mnet_support:force_new_key'),
                                                          'confirm' => elgg_echo('mnet_support:confirm_newkey'),
                                                          ))."</li>";

	}
?>
    </ul>
  </div>
</div>
