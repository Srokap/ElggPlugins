<?php

global $CONFIG;

if ( !$vars['entity']->organisation_name ) {
  $vars['entity']->organisation_name = "Example Org";
}
if ( !$vars['entity']->locality ) {
  $vars['entity']->locality = "Winchester";
}
if ( !$vars['entity']->country ) {
  $vars['entity']->country = "US";
}
if ( !$vars['entity']->certificate_email ) {
  $vars['entity']->certificate_email = "root@example.org";
}
if ( !$vars['entity']->debug ) {
  $vars['entity']->debug = "off";
}
      
$body = '';

$body .= "<p>";
$body .= elgg_echo('mnet_support:settings:organisation_name');
$body .= elgg_view('input/text', array('internalname' => "params[organisation_name]", 'value' => $vars['entity']->organisation_name)); 
$body .= "</p>";

$body .= "<p>";
$body .= elgg_echo('mnet_support:settings:locality');
$body .= elgg_view('input/text', array('internalname' => "params[locality]", 'value' => $vars['entity']->locality)); 
$body .= "</p>";

$body .= "<p>";
$body .= elgg_echo('mnet_support:settings:country');
$body .= elgg_view('input/text', array('internalname' => "params[country]", 'value' => $vars['entity']->country)); 
$body .= "</p>";

$body .= "<p>";
$body .= elgg_echo('mnet_support:settings:certificate_email');
$body .= elgg_view('input/text', array('internalname' => "params[certificate_email]", 'value' => $vars['entity']->certificate_email)); 
$body .= "</p>";

$body .= "<p>";
$body .= elgg_echo('mnet_support:settings:debug');
$debug_options = array("off"=> elgg_echo('option:no'), "on"=> elgg_echo('option:yes'));
$body .= elgg_view('input/pulldown', array('internalname' => "params[debug]", 'value' => $vars['entity']->debug, 'options_values'=>$debug_options)); 
$body .= "</p>";

echo $body

?>