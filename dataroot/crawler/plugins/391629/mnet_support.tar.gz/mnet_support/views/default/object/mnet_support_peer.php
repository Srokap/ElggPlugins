<?php

  /**
   * MNET Support Plugin for ELGG
   * Copyright (C) 2009 Solution Grove (http://solutiongrove.com)
   *
   * This program is free software: you can redistribute it and/or modify
   * it under the terms of the GNU General Public License as published by
   * the Free Software Foundation, either version 3 of the License, or
   * (at your option) any later version.
   *
   * This program is distributed in the hope that it will be useful,
   * but WITHOUT ANY WARRANTY; without even the implied warranty of
   * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   * GNU General Public License for more details.
   *
   * You should have received a copy of the GNU General Public License
   * along with this program.  If not, see <http://www.gnu.org/licenses/>.
   *
   * @author     Solution Grove
   * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL
   * @copyright  (C) 2009 Solution Grove (http://solutiongrove.com)
   *
   * This plugin uses mnet-lib and some portions where inspired by
   * the mnet-lib Drupal implementation. (http://code.google.com/p/mnet-lib/)
   *
   * mnet-lib and mnet-lib Drupal implementation (C) Neil Bertram 
   *
   */

if (isset($vars['entity'])) {
  $canedit = $vars['entity']->canEdit();
			
?>

	<div class="contentWrapper singleview">
	
	<div class="peer">
      <h3><a href="<?php echo $url; ?>"><?php echo $vars['entity']->title; ?></a></h3>
        <div class="peer_info">
        <p><?php echo elgg_echo('mnet_support:wwwroot'); ?> : <?php echo $vars['entity']->wwwroot; ?><br />
        <?php echo elgg_echo('mnet_support:protocol'); ?> : <?php echo $vars['entity']->protocol; ?><br />
        <?php echo elgg_echo('mnet_support:server_path'); ?> : <?php echo $vars['entity']->server_path; ?></p>
        <p><?php echo elgg_echo('mnet_support:public_key'); ?>:<br /><?php echo $vars['entity']->public_key; ?></p>
<?php

  if ( $canedit) {
    $peer_guid = $vars['entity']->getGUID();
    echo "<a href=\"" . $vars['url'] . "pg/mnet_support/peers/ping/" . $peer_guid ."/\">".elgg_echo('mnet_support:ping')."</a>";
    echo " | ";
    echo elgg_view("output/confirmlink", array(
                                               'href' => $vars['url'] . "action/mnet_support/peerdelete?entity_guid=" . $peer_guid,
                                               'text' => elgg_echo('delete'),
                                               'confirm' => elgg_echo('mnet_support:confirm_peer_delete'),
                                               ));
  }

?>
	    </div>
	</div>
 
    </div>

<?php

}

?>