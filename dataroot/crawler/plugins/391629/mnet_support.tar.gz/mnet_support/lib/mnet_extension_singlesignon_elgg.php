<?php

  /**
   * MNET Support Plugin for ELGG
   * Copyright (C) 2009 Solution Grove (http://solutiongrove.com)
   *
   * This program is free software: you can redistribute it and/or modify
   * it under the terms of the GNU General Public License as published by
   * the Free Software Foundation, either version 3 of the License, or
   * (at your option) any later version.
   *
   * This program is distributed in the hope that it will be useful,
   * but WITHOUT ANY WARRANTY; without even the implied warranty of
   * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   * GNU General Public License for more details.
   *
   * You should have received a copy of the GNU General Public License
   * along with this program.  If not, see <http://www.gnu.org/licenses/>.
   *
   * @author     Solution Grove
   * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL
   * @copyright  (C) 2009 Solution Grove (http://solutiongrove.com)
   *
   * This plugin uses mnet-lib and some portions where inspired by
   * the mnet-lib Drupal implementation. (http://code.google.com/p/mnet-lib/)
   *
   * mnet-lib and mnet-lib Drupal implementation (C) Neil Bertram 
   *
   */

require_once MNET_DIR.'/extensions/singlesignon.php';

/**
 * Implementation of the MNet single-sign-on protocol for Elgg
 *
 * This is still incomplete.
 *
 */
class mnet_extension_singlesignon_elgg extends mnet_extension_singlesignon {
  /**
   * Authenticate the SSO request against the client - are they allowed to request
   * SSO data from us. Note we shouldn't jump to them unless they're allowed to
   * check back with us...
   * 
   * TODO implement access control
   */
  public function check_call_access($client, $method) {
    return true;
  }

  /**
   * Save a session as an mnet_support_sso_session entity for the current user (who must be $username)
   *
   * @param string $username the username to start the session for
   * @param string $token a random token that the remote peer will call back with to identify this session
   * @param mnet_peer $destination_peer the remote peer's record
   */
  protected function save_session($username, $token, mnet_peer $destination_peer) {
    $user = $_SESSION['user'];

    if ($user->username != $username) {
      forward();
    }

    // Make absolutely sure a session doesn't already exist with the provided uid/token pair
    $session_entity = get_entities_from_metadata_multi(array("uid"=>$user->guid, "token"=>$token), "object", "mnet_support_sso_session", 0, 1);
    if ( count($session_entity) == 1 ) {
      delete_entity($session_entity[0]->guid);
    }


    // Construct the new session
    $sso_object = new ElggObject();
    $sso_object->title = elgg_echo('mnet_support:subtype:sso_session')." ".$user->username;
    $sso_object->description = "";
    $sso_object->subtype = "mnet_support_sso_session";
    $sso_object->access_id = ACCESS_PUBLIC;

    $sso_object->uid = $user->guid;
    $sso_object->token = $token;
    $sso_object->expires = date('c', time() + 60);
    $sso_object->wwwroot =  $destination_peer->get_wwwroot();
    $sso_object->user_agent = $_SERVER['HTTP_USER_AGENT'];
    $sso_object->session_id = session_id();
    $sso_object->confirm_timeout = time() + 60; // they have 60 seconds to SSO before this times out - should be well long enough
    
    $sso_object->save(); 

  }
  
  /**
   * Validate the token and wwwroot to make sure they're valid and not expired.
   * If ok, return their username.
   *
   * @param string $token a token, as saved to the session with save_session()
   * @param string $remote_wwwroot the wwwroot that this session was created towards
   * @return mixed if the session is valid, the username it is for, otherwise return false
   */
  protected function verify_session($token, $remote_wwwroot) {
    $session_entity = get_entities_from_metadata_multi(array("wwwroot"=>$remote_wwwroot, "token"=>$token), "object", "mnet_support_sso_session", 0, 1);
    if ( count($session_entity) == 1 ) {
      $user = get_user_entity_as_row($session_entity[0]->uid);
      if ( !empty($user) && $session_entity[0]->confirm_timeout > time() ) {
        return $user->username;
      }
    }

    return false;
  }
  
  /**
   * Returns as much of a MNet user profile as we can.
   * 
   * TODO: register a hook so that other modules 
   * can pitch in to the details if desired
   * 
   * @param string $username the username to get profile info for
   * @return array MNet profile info, see the base extension
   */
  protected function get_user_profile($username) {
    $user = get_user_by_username($username);
    if (!$user) {
      throw new mnet_exception('No such user during SSO');
    }

    if (preg_match('@(.+?) (.+?)$@', $user->name, $m)) {
      $user->firstname = $m[1];
      $user->lastname = $m[2];
    } else {
      $user->firstname = $user->name;
      $user->lastname = $user->name;
    }
    

    $details = array(
                     'username'    => $user->username,
                     'email'       => $user->email,
                     'confirmed'   => 1,
                     'deleted'     => 0,
                     'firstname'   => $user->firstname,
                     'lastname'    => $user->lastname,
                     'city'        => '',
                     'country'     => '',
                     'lang'        => 'en-utf8',
                     'timezone'    => '99',
                     'picture'     => '0'
                     );

    return $details;
  }

  /**
   * Determine what landing path should be used for the destination
   * 
   * TODO: This currently is hardcoded to the moodle landing page path.
   *       Need to change for better support for other networks.
   * 
   * @return string /auth/mnet/land.php right now. should be changed.
   */
  protected function get_remote_land_path(mnet_peer $destination_peer) {
    return '/auth/mnet/land.php';
  }

  /**
   * Checks the $ua hash and username against the MNet sessions table. If a match is found,
   * the PHP session ID recorded is removed, and all other sessions for the same uid are also
   * removed.
   * 
   * @param string $username the username to log out
   * @param string $ua the sha1 of the original user agent
   * @param bool $delete_only set this false if you would like to destroy the PHP session as well as delete the record from the MNet session table
   */
  protected function kill_local_user_session($username, $ua, $delete_only = true) {
    // Find user
    $account = get_user_by_username($username);
    if (!$account) {
      // can't do anything
      return;
    }

    // Find sessions belonging to this user
    $res = get_entities_from_metadata("uid", $account->guid, "object", "mnet_support_sso_session");
    foreach ( $res as $row) {
      if (sha1($row->user_agent) == $ua) {
        // ok we found their session
        if (!$delete_only) {
          logout();
        }

        delete_entity($row->guid);
      }
    }
  }
  
  /**
   * Discover any sessions we have open to other peers for this username, ua combo
   *
   * @param string $username the username for the session to kill
   * @param string $ua the sha1 of their user agent
   * @return array an array of mnet_peer records (or derivatives)
   */
  protected function get_remote_sessions($username, $ua) {
    global $MNET_APPLICATION;

    $user = get_user_by_username($username);
    if (!$user) {
      return array();
    }

    $peers = array();
    $res = get_entities_from_metadata("uid", $user->guid, "object", "mnet_support_sso_session");
    foreach ( $res as $session) {
      // check the user agent hash
      if (sha1($session->user_agent) == $ua) {
        // this is a valid session
        $peer = $MNET_APPLICATION->get_peer_by_wwwroot($session->wwwroot);
        if ($peer) {
          $peers[] = $peer;
        }
      }
    }

    return $peers;
  }
  
  protected function refresh_sessions($usernames) {
    // TODO implement
  }
}

?>