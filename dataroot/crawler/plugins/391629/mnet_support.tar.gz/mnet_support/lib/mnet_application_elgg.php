<?php

  /**
   * MNET Support Plugin for ELGG
   * Copyright (C) 2009 Solution Grove (http://solutiongrove.com)
   *
   * This program is free software: you can redistribute it and/or modify
   * it under the terms of the GNU General Public License as published by
   * the Free Software Foundation, either version 3 of the License, or
   * (at your option) any later version.
   *
   * This program is distributed in the hope that it will be useful,
   * but WITHOUT ANY WARRANTY; without even the implied warranty of
   * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   * GNU General Public License for more details.
   *
   * You should have received a copy of the GNU General Public License
   * along with this program.  If not, see <http://www.gnu.org/licenses/>.
   *
   * @author     Solution Grove
   * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL
   * @copyright  (C) 2009 Solution Grove (http://solutiongrove.com)
   *
   * This plugin uses mnet-lib and some portions where inspired by
   * the mnet-lib Drupal implementation. (http://code.google.com/p/mnet-lib/)
   *
   * mnet-lib and mnet-lib Drupal implementation (C) Neil Bertram 
   *
   */

include_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
require MNET_DIR.'/mnet_application.php';

/**
 * This class is a reference implementation of mnet_application,
 * the abstraction layer for integrating MNet with a host system.
 * 
 * This reference implementation stores data as elgg entities.
 *
 */
class mnet_application_elgg extends mnet_application {
  private $local_wwwroot;
  
  /**
   * Initialise this reference implementation
   * 
   */
  public function __construct() {
    global $CONFIG;
    $this->local_wwwroot = rtrim($CONFIG->wwwroot, "/");
  }
    
  /**
   * Return our discovered wwwroot
   *
   * @return string the discovered wwwroot of this reference instance
   */
  public function get_local_wwwroot() {
    return $this->local_wwwroot;
  }

  /**
   * Logs a message to stderr
   */
  public function log($type, $message) {
    global $CONFIG;
    error_log("MNET LOG - ".$type.": ".$message);
  }

  /**
   * Fetches the most recent keypair
   */
  public function get_current_keypair() {
    $keypair_entities = get_entities("object", "mnet_support_keypair", 0, "", 1);
    if (is_array($keypair_entities)) {
      // $object = get_entity($keypair_entities[0]->guid);
      return array(
                   'certificate' => $keypair_entities[0]->certificate."\n",
                   'keypair_PEM' => $keypair_entities[0]->keypair_pem."\n"
                   );
    }
    return null;
  }

  /**
   * Fetches all the keypairs
   */
  public function get_keypair_history() {
    $keypair_entities = get_entities("object", "mnet_support_keypair");
    $keypairs = array();
    if ( is_array($keypair_entities) ) {
      foreach ( $keypair_entities as $keypair ) {
        $keypairs[] = array(
                            'certificate' => $keypair->certificate."\n",
                            'keypair_PEM' => $keypair->keypair_pem."\n"
                            );
      }
    }
        
    return $keypairs;
  }

  /**
   * Generates a new keypair
   */
  public function set_new_keypair($certificate, $keypair_pem) {
    $keypair_object = new ElggObject();
    $keypair_object->title = elgg_echo('mnet_support:subtype:openssl_keypair');
    $keypair_object->description = "";
    $keypair_object->subtype = "mnet_support_keypair";
    $keypair_object->access_id = ACCESS_PUBLIC;

    $keypair_object->certificate = $certificate;
    $keypair_object->keypair_pem = $keypair_pem;

    $keypair_object->save();
  }

  /**
   * Fetch peer data based on wwwroot setting
   */
  public function get_peer_by_wwwroot($wwwroot) {
    $peer_entities = get_entities_from_metadata("wwwroot", $wwwroot, "object", "mnet_support_peer", 0, 1);
    if ( is_array($peer_entities) && count($peer_entities) > 0) {
      $peer = $peer_entities[0];
      return mnet_peer::populate($peer->wwwroot, $peer->public_key, $peer->server_path, $peer->protocol);
    }

    return null;
  }

  /**
   * The public key url
   */
  public function get_public_key_url() {
    return $this->get_local_wwwroot().'/mod/mnet_support/publickey.php';
  }

  /**
   * Create or update a peer entity
   */
  public function save_peer(mnet_peer &$peer) {
    if ($this->get_peer_by_wwwroot($peer->get_wwwroot())) {
      $peer_entities = get_entities_from_metadata("wwwroot", $peer->get_wwwroot(), "object", "mnet_support_peer", 0, 1);
      $peer_object = get_entity($peer_entities[0]->guid);
    }  else {
      $peer_object = new ElggObject();
      $peer_object->title = elgg_echo('mnet_support:subtype:peer')." ".$peer->get_wwwroot();
      $peer_object->description = "";
      $peer_object->subtype = "mnet_support_peer";
      $peer_object->access_id = ACCESS_PUBLIC;
            
      $peer_object->wwwroot = $peer->get_wwwroot();
    }

    $peer_object->public_key = $peer->get_public_key();
    $peer_object->server_path = $peer->get_server_path();
    $peer_object->protocol = $peer->get_protocol();
        
    $peer_object->save();

    return $peer;
  }

  /**
   * Currently set to false since we do the exchange using keys
   */
  public function peer_is_trusted(mnet_peer $peer) {
    return false;
  }
	
  /**
   * Helper function to get all peer entities
   */
  public function get_all_peers() {
    $peer_entities = get_entities("object", "mnet_support_peer");

    $peers = array();
    foreach ( $peer_entities as $peer ) {
      $peers[] = array("peer"=>$this->get_peer_by_wwwroot($peer->wwwroot), "entity"=>$peer);
    }
		
    return $peers;
  }

  /**
   * The path that handles the XML-RPC requests
   */
  public function get_server_path() {
    return $this->get_local_wwwroot().'/mod/mnet_support/server.php';
  }
	
  public function get_organisation_name() {
    $organisation_name = get_plugin_setting('organisation_name', 'mnet_support');
    if ( empty($organisation_name) )
      $organisation_name = "Example Org";
  
    return $organisation_name;
  }
  
  public function get_locality() {
    $locality = get_plugin_setting('locality', 'mnet_support');
    if ( empty($locality) )
      $locality = "Winchester";
  
    return $locality;
  }
  
  public function get_country() {
    $country = get_plugin_setting('country', 'mnet_support');
    if ( empty($country) )
      $country = "US";
  
    return $country;
  }
  
  public function get_certificate_email() {
    $certificate_email = get_plugin_setting('certificate_email', 'mnet_support');
    if ( empty($certificate_email) )
      $certificate_email = "root@example.org";
  
    return $certificate_email;
  }

}