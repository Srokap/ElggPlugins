<?php

	$english = array(
                     
                     'item:object:mnet_peer' => "MNET peer",
                     'item:object:mnet_support_keypair' => "MNET keypair",
                     'item:object:mnet_support_sso_session' => "MNET session",

                     'mnet_support:certificate_email' => "Contact email address",
                     'mnet_support:confirm_newkey' => "Are you sure you want to generate a new key?  This will replace the existing key and all your peers that use the current key will stop working.  You will need to update the stored keys on any peer that use the current key.  This action can't be undone.",
                     'mnet_support:confirm_peer_delete' => "Are you sure you want to delete and remove MNET services for this peer?  This action can't be undone.",
                     'mnet_support:country' => "Country",
                     'mnet_support:current_public_key' => "Current public key",
                     'mnet_support:existing_keypair' => "Existing keypair",
                     'mnet_support:force_new_key' => "Force regeneration of new key",
                     'mnet_support:locality' => "City",
                     'mnet_support:mnet_integration' => "MNET Integration",
                     'mnet_support:mnet_support' => "MNET Support",
                     'mnet_support:new_keypair' => "New keypair",
                     'mnet_support:not_a_peer' => "Delete failed. Invalid type/subtype.",
                     'mnet_support:organisation_name' => "Organization name",
                     'mnet_support:peer_not_found' => "Delete failed. Peer not found in the database",
                     'mnet_support:peer_returned_ping' => "Peer returned the ping response:",
                     'mnet_support:peers' => "Peers",
                     'mnet_support:ping' => "Ping",
                     'mnet_support:protocol' => "Protocol",
                     'mnet_support:public_key' => "Public key",
                     'mnet_support:server_info' => "Server information",
                     'mnet_support:server_path' => "Server path",
                     'mnet_support:view_current_public_key' => "View current public key",
                     'mnet_support:wwwroot' => "wwwroot",

                     'mnet_support:menu:configure_mnet_support' => "Configure MNET Support",
                     'mnet_support:menu:mnet' => "MNET",

                     'mnet_support:settings:certificate_email' => "Email address (to be used when generating certificate)",
                     'mnet_support:settings:country' => "Country code (2-letter code to be used when generating certificate)",
                     'mnet_support:settings:debug' => "Debug mode (log debug messages)",
                     'mnet_support:settings:locality' => "City (to be used when generating certificate)",
                     'mnet_support:settings:organisation_name' => "Organization name (to be used when generating certificate)",

                     'mnet_support:subtype:openssl_keypair' => "OpenSSL keypair",
                     'mnet_support:subtype:peer' => "MNET peer",
                     'mnet_support:subtype:sso_session' => "MNET SSO Session",

	);
					
	add_translation("en",$english);
?>