<?php
  
  error_reporting(E_ALL);
  ini_set('display_errors', 'on');
  
  // View when the user selects User Profile
  // view_user_profile.php
  
  $widget = $vars['entity'];
  $username = $widget->username;
  $feed_type = $widget->feed_type;
  
  // if we have the username and feed_type, then get the data that the user requested
  if($username && $feed_type) {
      $xml_doc = get_feed($username, $feed_type);
      $user_data = parse_xml($xml_doc);
      
      if($user_data) {
          //create the view in the widget
          echo '<b>' . $username . '</b><br />';
          
          $avatar = array_pop($user_data->xpath('avatar'));
          echo '<img src="' . $avatar . '" alt="' . $username . '" /><br />';
          
          if(($real_name = array_pop($user_data->xpath('realname'))) != '') {
              echo '<u>Real Name:</u> ' . $real_name . '<br />';
          }
          if(($nickname = array_pop($user_data->xpath('nickname'))) != '') {
              echo '<u>Nickname:</u> ' . $nickname . '<br />';
          }
          if($online_status = array_pop($user_data->xpath('status'))) {
              echo '<u>Online Status:</u> ' . $online_status . '<br />';
          }
          if(($gaming_style = array_pop($user_data->xpath('gaming_style'))) != '') {
              echo '<u>Gaming Style:</u> ' . $gaming_style . '<br />';
          }
          if(($occupation = array_pop($user_data->xpath('occupation'))) != '') {
              echo '<u>Occupation:</u> ' . $occupation . '<br />';
          }
          if(($website = array_pop($user_data->xpath('website'))) != '') {
              echo '<u>Website:</u> ' . $website . '<br />';
          }
          if(($interests = array_pop($user_data->xpath('interests'))) != '') {
              echo '<u>Interests:</u> ' . $interests . '<br />';
          }
          if(($bio = array_pop($user_data->xpath('bio'))) != '') {
              echo '<u>Bio:</u> ' . $bio;
          }
      }
  } else {
      echo '<div class="contentWrapper"><p>Please enter your information into the widget edit page.</p></div>';
  }