<?php
  
  // View when the user selects User Screenshots
  // view_user_screenshots.php
  
    $widget = $vars['entity'];
  $username = $widget->username;
  $feed_type = $widget->feed_type;
  
  // if we have the username and feed_type, then get the data that the user requested
  if($username && $feed_type) {
      $xml_doc = get_feed($username, $feed_type);
      $user_data = parse_xml($xml_doc);
      
      if($user_data) {
          //create the view in the widget
          echo '<h2>User Screenshots</h2>';
          if((array_pop($user_data->xpath('/xfire/screenshots/total'))) > 0) {
              // show the latest 5 screenshots
              for ( $i=1 ; $i<=5 && ($user_data->xpath('/xfire/screenshot[' . $i . ']')) ; $i++) {
                  // get the images of the screenshots in both small and natural sizes
                  $screenshot_url_small = array_pop($user_data->xpath('/xfire/screenshot[' . $i . ']/sizes/url[@size="small"]'));
                  $screenshot_url_natural = array_pop($user_data->xpath('/xfire/screenshot[' . $i . ']/sizes/url[@size="natural"]'));
                  $screenshot_game = array_pop($user_data->xpath('/xfire/screenshot[' . $i . ']/game'));
                  // create the view for each screenshot
                  // includes the screenshot, game, and description
                  echo '<br /><a href="' . $screenshot_url_natural . '"><img src="' . $screenshot_url_small . '" alt="User Screenshot ' . $i . '" /></a><br />';
                  echo '<b>Game: ' . $screenshot_game . '</b><br />';
                  if(($screenshot_description = array_pop($user_data->xpath('/xfire/screenshot[' . $i . ']/description'))) != "") {
                      echo 'Description: ' . $screenshot_description . '<br />';
                  }
              }
          } else {
              echo '<br />This user does not have any screenshots uploaded.';
          }
          echo '<br /><a href="http://www.xfire.com/profile/' . $username . '/screenshots/">See more screenshots from this user...</a>';
      }
  } else {
      echo '<div class="contentWrappter">Please enter your information into the widget edit page.</div>';
  }