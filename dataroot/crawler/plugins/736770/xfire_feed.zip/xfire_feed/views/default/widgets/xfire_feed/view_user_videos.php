<?php
  
  // View when the user selects User Videos
  // view_user_videos.php
  
  $widget = $vars['entity'];
  $username = $widget->username;
  $feed_type = $widget->feed_type;
  
  // if we have the username and feed_type, then get the data that the user requested
  if($username && $feed_type) {
      $xml_doc = get_feed($username, $feed_type);
      $user_data = parse_xml($xml_doc);
      
      if($user_data) {
          echo '<h2>User Videos</h2>';
          // check to see if the user has any vidoes
          if((array_pop($user_data->xpath('/xfire/videos/total'))) > 0) {
              // only show the last 5 videos uploaded
              for($i=1;$i<=5 && (array_pop($user_data->xpath('/xfire/video[' . $i . ']')));$i++) {
                  // get all of the variables needed for the view
                  $video_thumb_url = array_pop($user_data->xpath('/xfire/video[' . $i . ']/thumb_url'));
                  $video_xfire_url = array_pop($user_data->xpath('/xfire/video[' . $i . ']/url'));
                  $video_title = array_pop($user_data->xpath('/xfire/video[' . $i . ']/title'));
                  $video_duration = array_pop($user_data->xpath('/xfire/video[' . $i . ']/duration'));
                  $video_game = array_pop($user_data->xpath('/xfire/video[' . $i . ']/game'));
                  $video_description = array_pop($user_data->xpath('/xfire/video[' . $i . ']/description'));
                  // create the view for the user video
                  echo '<br /><b>' . $video_title . '</b><br />';
                  echo '<a href="' . $video_xfire_url . '"><img src="' . $video_thumb_url . '" alt="User Video ' . $i . '" /></a><br />';
                  echo '<u>Duration:</u> ' . $video_duration . '<br />';
                  echo '<u>Game:</u> ' . $video_game . '<br />';
                  echo '<u>Description:</u> ' . $video_description;
              }
          } else {
              echo 'This user does not have any videos uploaded to Xfire.';
          }
          echo '<br /><a href="">See more videos from this user...</a>';
      }
  } else {
      echo '<div class="contentWrapper">Please enter your information into the widget edit page.</div>';
  }