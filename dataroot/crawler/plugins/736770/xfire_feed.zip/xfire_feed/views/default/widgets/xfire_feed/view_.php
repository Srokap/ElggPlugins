<?php
  
  // this is an error handling view when the widget is first installed and the user has not updated their settings
  // view_.php
  
  echo '<div class="contentWrapper">You need to update your settings in the edit menu.</div>';