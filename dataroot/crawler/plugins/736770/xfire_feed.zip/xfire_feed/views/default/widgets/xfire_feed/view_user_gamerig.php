<?php
  
  // View when the user selects Gaming Rig
  // view_user_gamerig.php
  
  $widget = $vars['entity'];
  $username = $widget->username;
  $feed_type = $widget->feed_type;
  
  // if we have the username and feed_type, then get the data that the user requested
  if($username && $feed_type) {
      $xml_doc = get_feed($username, $feed_type);
      $user_data = parse_xml($xml_doc);
      
      if($user_data) {
          //create the view in the widget
          echo '<h2>Gaming Rig</h2>';
          if(($manufacturer = array_pop($user_data->xpath('manufacturer'))) != '') {
              echo '<u>Manufacturer:</u> ' . $manufacturer . '<br />';
          }
          if(($processor = array_pop($user_data->xpath('processor'))) != '') {
              echo '<u>Processor:</u> ' . $processor . '<br />';
          }
          if(($ram_memory = array_pop($user_data->xpath('memory'))) != '') {
              echo '<u>Memory:</u> ' . $ram_memory . '<br />';
          }
          if(($hdd = array_pop($user_data->xpath('harddrive'))) != '') {
              echo '<u>Hard Drive:</u> ' . $hdd . '<br />';
          }
          if(($video_card = array_pop($user_data->xpath('videocard'))) != '') {
              echo '<u>Video Card:</u> ' . $video_card . '<br />';
          }
          if(($sound_card = array_pop($user_data->xpath('soundcard'))) != '') {
              echo '<u>Sound Card:</u> ' . $sound_card . '<br />';
          }
          if(($keyboard = array_pop($user_data->xpath('keyboard')))!= '') {
              echo '<u>Keyboard:</u> ' . $keyboard . '<br />';
          }
          if(($mouse = array_pop($user_data->xpath('mouse'))) != '') {
              echo '<u>Mouse:</u> ' . $mouse . '<br />';
          }
          if(($operating_system = array_pop($user_data->xpath('operatingsystem'))) != '') {
              echo '<u>Operating System:</u> ' . $operating_system . '<br />';
          }
	      if(($motherboard = array_pop($user_data->xpath('motherboard'))) != '') {
	          echo '<u>Motherboard:</u> ' . $motherboard . '<br />';
	      }
	      if(($computer_case = array_pop($user_data->xpath('computer_case'))) != '') {
 	          echo '<u>Computer Case:</u> ' . $computer_case . '<br />';
	      }    
      }
  } else {
      echo '<div class="contentWrapper">There was a problem with the widget.  Please contact the creator of the widget.</div>';
  }
