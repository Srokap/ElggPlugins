<?php

	error_reporting(E_ALL);
	ini_set('display_errors', 'on');

	// Creates the view when the user selects the Friends option
	// view_user_friends.php
	
	$widget = $vars['entity'];
	$username = $widget->username;
	$feed_type = $widget->feed_type;

	if($username && $feed_type) {
		$xml_doc = get_feed($username, $feed_type);
		$user_data = parse_xml($xml_doc);
		
		$total_friends = count($user_data->xpath('/xfire/friend'));
		$online_friends = count($user_data->xpath('/xfire/friend[status="online"]'));
		echo '<h2>Currently ' . $online_friends . ' out of ' . $total_friends . ' friends online.</h2>';
        
		$rows = $user_data->xpath('/xfire/friend[status="online"]');
		foreach($rows as $friend) {  
            // get the information for the friend
			$friend_username = array_pop($friend->xpath('username'));
            $friend_online_status = array_pop($friend->xpath('status'));
            // get the feed for the friend user profile for their avatars
            $friend_xml_doc = get_feed($friend_username, 'user_profile');
            $friend_user_data = parse_xml($friend_xml_doc);
            // build the view
            $friend_avatar = '<img src="' . array_pop($friend_user_data->xpath('/xfire/avatar')) . '" />';
			$info =  '<b>' . $friend_username . '</b><br />';
			if(($friend_nickname = array_pop($friend->xpath('nickname'))) != '') {
				$info .= '<u>Nickname:</u> ' . $friend_nickname . '<br />';
			}
			$info .= '<u>Online Status:</u> ' . $friend_online_status . '<br />';
            // display the view
            echo elgg_view_listing($friend_avatar, $info);
		}
        
	} else {
		echo '<div class="contentWrapper">Please enter in your information into the edit page of this widget.</div>';
	}
