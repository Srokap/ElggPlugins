<?php
  
  // View when the user selects Favorite Servers
  // view_user_servers.php
  
  $widget = $vars['entity'];
  $username = $widget->username;
  $feed_type = $widget->feed_type;
  
  
  // if we have the username and feed_type, then get the data that the user requested
  if($username && $feed_type) {
      $xml_doc = get_feed($username, $feed_type);
      $user_data = parse_xml($xml_doc);
      
      if($user_data) {
          echo '<h2>Favorite Servers</h2>';
          // check if the user has any videos and display the latest 5 favorite ones
          for($i=1;$i<=5 && ($user_data->xpath('/xfire/server[' . $i . ']')); $i++) {
              // get all of the variables we will use in the view
              $server_game = array_pop($user_data->xpath('/xfire/server[' . $i . ']/game'));
              $server_name = array_pop($user_data->xpath('/xfire/server[' . $i . ']/name'));
              $server_country = array_pop($user_data->xpath('/xfire/server[' . $i . ']/country'));
              // create the view for user_servers in the widget
              echo '<br /><u>Server Name:</u> ' . $server_name . '<br />';
              echo '<u>Game:</u> ' . $server_game;
          }
      }      
  } else {
      echo '<div class="contentWrapper">Please enter your information into the widget edit page.</div>';
  }