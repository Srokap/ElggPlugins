/**
 * Glee Plugin Manager
 * 
 * @package glee_plugin_manager
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author void <void@13net.at>
 * @copyright 13net
 * @link http://www.13net.at/
 */

/**
 * Description
 */
A rapid alternative to the Elgg standard plugin manager.

/**
 * Languages
 */
English
German
