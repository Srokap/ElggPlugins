<?php
/*****************************************************************************
 * Glee Plugin Manager                                                       *
 *                                                                           *
 * Copyright (C) 2012 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php

$german = array(
	'glee_plugin_manager' => 'Glee Plugin Manager',
	'admin:glee_plugin_manager' => 'Glee Plugin Manager',
	'admin:glee_plugin_manager:rapid_plugins' => 'Glee Ansicht',

	'glee_plugin_manager:form:description' => '',

	'glee_plugin_manager:apply:failure' => 'Einstellungen konnte nicht übernommen werden',

	'glee_plugin_manager:plugin:activate' => 'Aktiviert: %s',
	'glee_plugin_manager:plugin:deactivate' => 'Deaktiviert: %s',

	'glee_plugin_manager:form:section:inactive' => 'Inaktiv',
	'glee_plugin_manager:form:section:cannotactivate' => 'Nicht aktivierbar',
	'glee_plugin_manager:form:section:active' => 'Aktiviert',
	'glee_plugin_manager:form:section:invalid' => 'Invalid',

);

add_translation('de', $german);
