<?php
/*****************************************************************************
 * Glee Plugin Manager                                                       *
 *                                                                           *
 * Copyright (C) 2012 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php

admin_gatekeeper();

$site = elgg_get_site_entity();

// load vars from post requests
$params = glee_plugin_manager_get_input_vars($site);

// save the object and show success message
if(glee_plugin_manager_process_request($site, $params)) {
	//system_message(elgg_echo('glee_plugin_manager:apply:success'));
}
// ...or display an error message if that was not possible
else {
	register_error(elgg_echo('glee_plugin_manager:apply:failure'));
}

forward($_SERVER['HTTP_REFERER']);

