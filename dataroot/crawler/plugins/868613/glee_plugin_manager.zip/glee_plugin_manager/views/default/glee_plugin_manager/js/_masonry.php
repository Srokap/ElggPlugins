<?php
?>
<script type="text/javascript">
$(document).ready(function(){
	$(function() {
		$('.checklist .checklist-item').css('width', '105px');
		$('.checklist .checklist-item').css('margin-bottom', '35px');
		$('.checklist .checklist-item').css('float', 'left');
		$(".checklist").masonry({
		    // options
		    itemSelector : '.checklist-item',
		    columnWidth : 135
		});
	});
});
</script>
<?php
