<?php
/*****************************************************************************
 * Glee Plugin Manager                                                       *
 *                                                                           *
 * Copyright (C) 2012 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php

// only admins are allowed to see the page
admin_gatekeeper();

elgg_load_js('jquery-ui');
elgg_load_js('jquery-masonry');
// js: enables sorting the plugins
elgg_extend_view('page/elements/foot', 'glee_plugin_manager/js/ui');

$status = get_input('status', 'all');

switch ($status) {
	case 'active'  :break;
	case 'inactive':break;
	case 'all':
	default:
		$status = "all";
}

$form_options = array(
    'status' => $status,
);

// display a description
echo elgg_echo('glee_plugin_manager:form:description');

// settings div
echo '<div id="phloor-rapid-plugins-form" style="width:100%; padding:10px 0 10px 0; float:left; clear:both;">';
// view the edit form
echo elgg_view_form('glee_plugin_manager/rapid_plugins', $form_options);
echo '</div>';

