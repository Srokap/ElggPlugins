<?php
?>
<script type="text/javascript">
//Create the tooltips only on document load
$(document).ready(function()
{
   var selector = '.checklist-item';
   // Make sure to only match links to wikipedia with a rel tag
   $(selector).each(function()
   {
      // We make use of the .each() loop to gain access to each element via the "this" keyword...
      $(this).qtip(
      {
         content: {
            text: $(this).find('label').find('a').attr('title'),
            title: {
               text: $(this).find('label').find('a').text(), // Give the tooltip a title using each elements text
               button: true
            }
         },
         position: {
             my: 'top left',
             target: 'mouse',
             viewport: $(window), // Keep it on-screen at all times if possible
             adjust: {
                x: 10,  y: 10
             }
          },
          hide: {
              fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
           },
           style: 'ui-tooltip-shadow ui-tooltip-youtube'
      })
   });
});
</script>
<?php
