<?php
/*****************************************************************************
 * Glee Plugin Manager                                                       *
 *                                                                           *
 * Copyright (C) 2012 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php

admin_gatekeeper();
/**
 *
 */
// get current site entity
$site = elgg_get_site_entity();

$action_buttons = '';

$save_button = elgg_view('input/submit', array(
	'value' => elgg_echo('save'),
	'name' => 'phloor:apply',
));

$action_buttons = $save_button ;

$status = elgg_extract('status', $vars, 'all');
switch ($status) {
	case 'active'  :break;
	case 'inactive':break;
	case 'all':
	default:
		$status = "all";
}

$settings = glee_plugin_manager_get_options();

$options = array(
	'active'   => array(),
	'inactive' => array(),
	'cannotactivate'  => array(),
	'invalid'  => array(),
);
$installed_plugins = elgg_get_plugins($status, $site->guid);
foreach ($settings as $id => $value) {
    $plugin = $installed_plugins[$id];
    if(!$plugin->isValid()) {
        $options['invalid'][$id] = $value;
    }
    else if(!$plugin->canActivate($site->guid)) {
        $options['cannotactivate'][$id] = $value;
    }
    else if($plugin->isActive($site->guid)) {
        $options['active'][$id] = $value;
    }
    else /*if(!$plugin->isActive($site->guid))*/ {
        $options['inactive'][$id] = $value;
    }
}

// form elements setup
$forms = array(
	'inactive' => elgg_view('phloor/input/vendors/prettycheckboxes/checklist', array(
		'options' => $options['inactive'],
		//'list_type' => 'container',
    )),
    'active' => elgg_view('phloor/input/vendors/prettycheckboxes/checklist', array(
		'options' => $options['active'],
		'list_type' => 'list',
    )),
     'cannotactivate' => elgg_view('phloor/input/vendors/prettycheckboxes/checklist', array(
		'options' => $options['cannotactivate'],
    )),
    'invalid' => elgg_view('phloor/input/vendors/prettycheckboxes/checklist', array(
		'options' => $options['invalid'],
    )),
);


// display action buttons top
echo <<<____HTML
<div class="elgg-head">
	$action_buttons
</div>
____HTML;

// view each section
foreach($forms as $section_name => $view) {
    if(!empty($view)) {
       	// display section title
    	echo elgg_view_title(elgg_echo('glee_plugin_manager:form:section:'.$section_name));
    	// view each form of a section
    	echo $view;
    }
}

// display action buttons bottom
echo <<<____HTML
<div class="elgg-foot">
	$action_buttons
</div>
____HTML;

