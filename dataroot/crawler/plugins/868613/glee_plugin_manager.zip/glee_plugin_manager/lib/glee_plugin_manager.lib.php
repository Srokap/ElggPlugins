<?php
/*****************************************************************************
 * Glee Plugin Manager                                                       *
 *                                                                           *
 * Copyright (C) 2012 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php

/**
 * Default attributes
 * returns the current plugin configuration
 *
 * just take valid and "activateable" plugins
 *
 * "id" => "enable"
 * e.g.
 * "blog" => "true"
 * "pages" => "false"
 * ...
 *
 */
function glee_plugin_manager_default_vars($site) {
    if(!$site) {
        $site = elgg_get_site_entity();
    }

    $defaults = array();

    $installed_plugins = elgg_get_plugins('any', $site->guid);
    foreach ($installed_plugins as $id => $plugin) {
        //if($plugin->isValid() && $plugin->canActivate($site->guid)) {
            $defaults[$id] = $plugin->isActive() ? 'true' : 'false';
        //}
    }

    return $defaults;
}

/**
 * Load vars from post or get requests and returns them as array
 *
 * @return array with values from the request
 */
function glee_plugin_manager_get_input_vars($site) {
    if(!$site) {
        $site = elgg_get_site_entity();
    }

    // get default values
	$defaults = glee_plugin_manager_default_vars($site);

    $params = array();

    foreach ($defaults as $id => $former_value) {
         $input = get_input($id, $former_value, true);
         $params[$id] = strcmp("true", $input) == 0 ? "true" : "false";
    }

	return $params;
}

function glee_plugin_manager_get_options() {
    if(!$site) {
        $site = elgg_get_site_entity();
    }

    $settings = glee_plugin_manager_default_vars();

    $options = array();

    $installed_plugins = elgg_get_plugins('any', $site->guid);
    foreach ($settings as $id => $value) {

        $plugin = $installed_plugins[$id];

        if($plugin->isValid()) {
            $blurb       = "";
            $description = "";
            $version     = "";

            $title = $plugin->title;
            $label = $plugin->getFriendlyName();

            $manifest = $plugin->getManifest();
            if ($manifest instanceof ElggPluginManifest) {
    			$blurb       = $manifest->getBlurb();
    			$description = $manifest->getDescription();
                $version     = htmlspecialchars($plugin->getManifest()->getVersion());

                $title = "$version";
                if(strcmp($blurb, $description) != 0) {
                    $title .= " | $description";
                }
    		}

            // check if plugin settings exist
            $settings_view = 'plugins/' . $plugin->getID() . '/settings';
            if (elgg_view_exists($settings_view)) {
            	$settings_link = elgg_get_site_url() . "admin/plugin_settings/" . $plugin->getID();

    		    $label_options = array(
        		    'title' => $title,
        		    'text'  => $plugin->getFriendlyName(),
        		    'href'  => $settings_link,
        		);

    		    $label = elgg_view("phloor/output/a", $label_options);

            }

            $options[$id] = array(
        		'name'        => $id,
        	 	'value'       => $value,
                'label'       => $label,
                'description' => $blurb,
        	);
        }
    }

    return $options;
}

function glee_plugin_manager_process_request($site, $params = array()) {
    if(!$site) {
        $site = elgg_get_site_entity();
    }

    // plugins that cannot be turned off
    $read_only = array(
        "phloor"              => elgg_get_plugin_from_id("phloor")->guid,
        "glee_plugin_manager" => elgg_get_plugin_from_id("glee_plugin_manager")->guid,
    );

    $activated   = array();
    $deactivated = array();


    $installed_plugins = elgg_get_plugins('any', $site->guid);
    foreach ($params as $id => $value) {
        $plugin = $installed_plugins[$id];

        if (elgg_instanceof($plugin, 'object', 'plugin') && $plugin->canEdit()) {
            // dont do anything on not activateable plugins
            if(!$plugin->canActivate($site->guid) || !$plugin->isValid()) {
                 continue;
            }

            // continue at read-only plugin (self, phloor,..)
            if(in_array($plugin->guid, $read_only)) {
                continue;
            }

            if(!$plugin->isActive()) {
                if(strcmp('true', $value) == 0) {
                    if($plugin->activate($site->guid)) {
                         $activated[] = $plugin->getFriendlyName();
                    }
                }
            }
            else if ($plugin->isActive()){
                if(strcmp('false', $value) == 0) {
                    if($plugin->deactivate($site->guid)) {
                         $deactivated[] = $plugin->getFriendlyName();
                    }
                }
            }
        }
    }

    if(!empty($activated)) {
        $comma_separated = implode(", ", $activated);
        $message = elgg_echo('glee_plugin_manager:plugin:activate', array($comma_separated));
        system_message($message);
    }
    if(!empty($deactivated)) {
        $comma_separated = implode(", ", $deactivated);
        $message = elgg_echo('glee_plugin_manager:plugin:deactivate', array($comma_separated));
        system_message($message);
    }

    return true;
}

