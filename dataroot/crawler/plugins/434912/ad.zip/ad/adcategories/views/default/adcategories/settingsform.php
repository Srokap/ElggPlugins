<?php

	echo elgg_view('input/tags',array('value' => $vars['adcategories'],
									  'internalname' => 'adcategories'));

?>
	<input type="submit" value="<?php echo elgg_echo('save'); ?>" />