<?php

	$linkstr = '';
	if (isset($vars['entity']) && $vars['entity'] instanceof ElggEntity) {
		
		$adcategories = $vars['entity']->universal_adcategories;
		if (!empty($adcategories)) {
			if (!is_array($adcategories)) $adcategories = array($adcategories);
			foreach($adcategories as $category) {
				$link = $vars['url'] . 'search?tagtype=universal_adcategories&tag=' . urlencode($category);
				if (!empty($linkstr)) $linkstr .= ', ';
				$linkstr .= '<a href="'.$link.'">' . $category . '</a>';
			}
		}
		
	}
	echo $linkstr;

?>