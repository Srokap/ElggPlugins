<?php

	$adcategories = $vars['config']->site->adcategories;
	
	if ($adcategories) {
		if (!is_array($adcategories)) $adcategories = array($adcategories);
		
	if (!empty($vars['subtype'])) {
		$flag = array();
		$owner_guid = '';
		if (isset($vars['owner_guid'])) $owner_guid = (int) $vars['owner_guid'];
		if ($cats = get_tags(0,999,'universal_adcategories','object',$vars['subtype'],$owner_guid))
			foreach($cats as $cat)
				$flag[] = $cat->tag;
				
	} else {
		$flag = null;
	}
	
	if (is_null($flag) || !empty($flag)) {
		
?>

	<h2><?php echo elgg_echo('adcategories'); ?></h2>
	<div class="adcategories">
		<?php

			$catstring = '';
			if (!empty($adcategories)) {
				foreach($adcategories as $category) {
					if (is_null($flag) || (is_array($flag) && in_array($category,$flag)))
						$catstring .= '<li><a href="'.$vars['baseurl'].urlencode($category).'">'. $category .'</a></li>';
				}
			}
			if (!empty($catstring)) echo "<ul>{$catstring}</ul>";
		
		?>
	</div>
<?php } 

}?>