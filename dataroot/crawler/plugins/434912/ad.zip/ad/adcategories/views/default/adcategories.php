<?php

	/**
	 * Elgg Classifieds Categories Pluggin V2
	 * This pluggin requires Classifieds pluggin to work. Download it from the Elgg Community.
	 * @package Classifieds Pluggin
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */

		if (isset($vars['entity']) && $vars['entity'] instanceof ElggEntity) {
			$selected_adcategories = $vars['entity']->universal_adcategories;
		}
		$adcategories = $vars['config']->site->adcategories;
		if (empty($adcategories)) $adcategories = array();
		if (empty($selected_adcategories)) $selected_adcategories = array(); 

		if (!empty($adcategories)) {
			if (!is_array($adcategories)) $adcategories = array($adcategories);
		
?>

		<div id="content_area_user_title"><h2 class="adcategoriestitle"><?php echo elgg_echo('adcategories'); ?></h2></div>
		<div class="adcategories">
			<p>
			
<?php

		echo elgg_view('input/checkboxes',array(
			'options' => $adcategories,
			'value' => $selected_adcategories,
			'internalname' => 'universal_adcategories_list'
												));

?>
			<input type="hidden" name="universal_category_marker" value="on" />
			</p>
		</div>
		
<?php

	} else {
		echo '<input type="hidden" name="universal_category_marker" value="on" />';
	}

?>