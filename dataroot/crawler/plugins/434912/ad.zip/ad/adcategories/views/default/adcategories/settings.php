<?php

	echo elgg_view_title(elgg_echo('adcategories:settings'));

?>

	<div class="contentWrapper">
		<p>
			<?php echo elgg_echo('adcategories:explanation'); ?>
		</p>
	

<?php

	echo elgg_view(
						'input/form',
						array(
							'action' => $vars['url'] . 'action/adcategories/save',
							'method' => 'post',
							'body' => elgg_view('adcategories/settingsform',$vars)
						)
					);

?>

</div>