<?php

	/**
	 * Elgg Classifieds Categories Pluggin V2
	 * This pluggin requires Classifieds pluggin to work. Download it from the Elgg Community.
	 * @package Classifieds Pluggin
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */

	/**
	 * Initialise adcategories actions etc
	 *
	 */
		function adcategories_init() {
			
			// Get config
				global $CONFIG;
				
			extend_view('css', 'adcategories/css');
			
			// Register action
				register_action('adcategories/save',false,$CONFIG->pluginspath . 'adcategories/actions/save.php',true);
			
		}
	
	/**
	 * Set up menu items
	 *
	 */
		function adcategories_pagesetup()
		{
			if (get_context() == 'admin' && isadminloggedin()) {
				global $CONFIG;
				add_submenu_item(elgg_echo('adcategories:settings'), $CONFIG->wwwroot . 'mod/adcategories/settings.php');
			}
		}
		
	/**
	 * Save adcategories
	 *
	 */
		function adcategories_save($event, $object_type, $object) {
			
			if ($object instanceof ElggEntity) {
				
				$marker = get_input('universal_category_marker');
				if ($marker == 'on') {
					
					$adcategories = get_input('universal_adcategories_list');
					if (empty($adcategories)) $adcategories = array();
					
					$object->universal_adcategories = $adcategories;
					
				}
				
			}
			return true;
			
		}
	

	register_elgg_event_handler('init','system','adcategories_init');
	register_elgg_event_handler('pagesetup','system','adcategories_pagesetup');
	register_elgg_event_handler('update','all','adcategories_save');
	register_elgg_event_handler('create','all','adcategories_save');

?>