<?php

	$english = array(
	
		'adcategories' => 'Classifieds category',
		'adcategories:settings' => 'Create Ad categories',	
		'adcategories:explanation' => 'Set here some predefined ad categories that will be used  as categories for posting Classifieds, enter them below, separated with commas.',	
		'adcategories:save:success' => 'Site adcategories were successfully saved.',
	
	);
					
	add_translation("en",$english);

?>