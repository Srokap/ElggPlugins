<?php

	/**
	 * Elgg Classifieds Categories Pluggin V2
	 * This pluggin requires Classifieds pluggin to work. Download it from the Elgg Community.
	 * @package Classifieds Pluggin
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */

	// Load engine and restrict to admins 

		require_once(dirname(dirname(dirname(__FILE__))) . '/engine/start.php');
		admin_gatekeeper();
		
	// Set context
	
		set_context('admin');
		
	// Get site and adcategories
		
		global $CONFIG;
		$site = $CONFIG->site;
		$adcategories = $site->adcategories;
		
		if (empty($adcategories)) $adcategories = array();
		
	// Load category save view
	
		$body = elgg_view('adcategories/settings',array(
							'adcategories' => $adcategories,
						));

	// Layout

		$body = elgg_view_layout('two_column_left_sidebar','', $body);
						
	// View page
		echo page_draw(elgg_echo('adcategories:settings'),$body);
		
?>