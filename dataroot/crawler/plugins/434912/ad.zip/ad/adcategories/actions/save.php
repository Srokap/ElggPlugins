<?php

	/**
	 * Elgg Classifieds Categories Pluggin V2
	 * This pluggin requires Classifieds pluggin to work. Download it from the Elgg Community.
	 * @package Classifieds Pluggin
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */

		action_gatekeeper();
		
		$adcategories = get_input('adcategories');
		$adcategories = string_to_tag_array($adcategories);
		
		global $CONFIG;
		$site = $CONFIG->site;
		$site->adcategories = $adcategories;
		system_message(elgg_echo("adcategories:save:success"));
		
		forward($_SERVER['HTTP_REFERER']);

?>