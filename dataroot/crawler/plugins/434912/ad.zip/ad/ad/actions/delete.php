<?php

	/**
	 * Elgg Classifieds Pluggin V2
	 * @package Classifieds Pluggin
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */

	// Make sure we're logged in (send us to the front page if not)
		if (!isloggedin()) forward();

	// Get input data
		$guid = (int) get_input('adpost');
		
	// Make sure we actually have permission to edit
		$ad = get_entity($guid);
		if ($ad->getSubtype() == "ad" && $ad->canEdit()) {
	
		// Get owning user
				$owner = get_entity($ad->getOwner());
				
		// Delete the images
				$annotations = $ad->getAnnotations('adlocation');
				foreach ($annotations as $annotation){
					unlink($CONFIG->path . '/' . $annotation['value'] . '_thumblarge.jpg');
					unlink($CONFIG->path . '/' . $annotation['value'] . '_thumbsmall.jpg');
					unlink($CONFIG->path . '/' . $annotation['value'] . '_full.jpg');
					// Delete the annotations
					$annotation_id = $annotation['id'];
					$object = get_annotation($annotation_id);
					$object->delete();
				}
				
		// Delete the ad post
				$rowsaffected = $ad->delete();
				if ($rowsaffected > 0) {
		
		// Success message
					system_message(elgg_echo("ad:deleted"));
				} else {
					register_error(elgg_echo("ad:notdeleted"));
				}
				
		// Forward to the main ad page
				forward("mod/ad/?username=" . $owner->username);
		}
		
?>