<?php

	/**
	 * Elgg Classifieds Pluggin V2
	 * @package Classifieds Pluggin
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */

		// Get info
			$owner = $vars['entity']->getOwnerEntity();
			$friendlytime = friendly_time($vars['entity']->time_created);
				$annotations = $vars['entity']->getAnnotations('adlocation',1);
				foreach ($annotations as $annotation){
					$icon = "<img src=\"" . $CONFIG->wwwroot . $annotation['value'] . '_thumblarge.jpg' . "\"/>";
				}
			$title = $vars['entity']->title;
			$info = "<a href=\"{$owner->getURL()}\">{$owner->name}</a> <BR> {$friendlytime}";
		
		// Make title fit in thumbs
			if ( strlen ($title) >= 19){
				$title = substr_replace($title, '...', 18);
			}
	
	

		// Display everything
		echo "<div class=\"ad_gallery_item\">";
		echo "<div class=\"ad_gallery_title\"><a href=\"{$vars['entity']->getURL()}\">" . $title . "</a></div>";
		echo "<a href=\"{$vars['entity']->getURL()}\">" . $icon ."</a>";
		echo "<div class=\"ad_gallery_content\">" . $info . "</div>";
		echo (autop($vars['entity']->price));
		echo "</div>";


?>