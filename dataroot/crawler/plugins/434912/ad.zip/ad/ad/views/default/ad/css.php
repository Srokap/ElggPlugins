<?php

	/**
	 * Elgg Classifieds Pluggin V2
	 * @package Classifieds Pluggin
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */

?>


.ad_post {
	margin-bottom: 15px;
	border-bottom: 1px solid #aaaaaa;
}

.ad_post_icon {
	float:left;
	margin:3px 0 0 0;
	padding:0;
}

.ad_post h3 {
	font-size: 150%;
	margin-bottom: 5px;
}

.ad_post h3 a {
	text-decoration: none;
}

.ad_post p {
	margin: 0 0 5px 0;
}

.ad_post .strapline {
	margin: 0 0 0 35px;
	padding:0;
	color: #666666;
	line-height:1em;
}
.ad_post p.tags {
	background:transparent url(<?php echo $vars['url']; ?>mod/ad/graphics/icon_tag.gif) no-repeat scroll left 2px;
	margin:0 0 0 35px;
	padding:0pt 0pt 0pt 16px;
	min-height:22px;
}
.ad_post .options {
	margin:0;
	padding:0;
}

.ad_post_body img[align="left"] {
	margin: 10px 10px 10px 0;
	float:left;
}
.ad_post_body img[align="right"] {
	margin: 10px 0 10px 10px;
	float:right;
}

.ad-comments h3 {
	font-size: 150%;
	margin-bottom: 10px;
}
.ad-comment {
	margin-top: 10px;
	margin-bottom:20px;
	border-bottom: 1px solid #aaaaaa;
}
.ad-comment img {
	float:left;
	margin: 0 10px 0 0;
}
.ad-comment-menu {
	margin:0;
}
.ad-comment-byline {
	background: #dddddd;
	height:22px;
	padding-top:3px;
	margin:0;
}
.ad-comment-text {
	margin:5px 0 5px 0;
}
.ad-largethumb {
	text-align:center;
	height: 153px;
	background: #ffffff;
	margin:5px;
}

.ad-largethumb #largethumb {
	height: 153px;
	width: 153px;
	margin: 2px;
	text-align:center;
	border-color: #000000;
	border-width: 1px;
	border-style: solid;
}
.ad-largethumb a:hover {
	border-color: #dddddd;
}
.ad-smallthumb a {
	height: 60px;
	width: 60px;
	margin: 2px;
	float: left;
	border-color: #000000;
	border-width: 1px;
	border-style: solid;
}
.ad-smallthumb a:hover {
	border-color: #dddddd;
}
.ad-tinythumb a {
	height: 25px;
	width: 25px;
	margin: 1px;
	float: left;
	border-color: #000000;
	border-width: 1px;
	border-style: solid;
}
.ad-tinythumb a:hover {
	border-color: #dddddd;
}
.ad_title_owner_wrapper {
	min-height:60px;
    margin-bottom: 10px;
    padding:0 0 0 10px;
	background-color: #eeeeee;
}
.ad_title{
	margin:0;
	padding:6px 5px 0 8px;
	line-height: 1.2em;
}
.ad_details_holder {
	padding:0 0 0 10px;
    margin-left: 0px !important;
}
.ad_details_holder .usericon {
	margin-right: 5px;
	float: left;
}

/* GALLERY VIEW */

.ad_gallery_item {
	margin:0;
	padding:0;
}
.ad_gallery_title {
	font-weight: bold;
	line-height: 1.1em;
	margin:0 0 10px 0;
}
.ad_gallery_content {
	font-size:90%;
    color:#666666;
	margin:0;
    padding:0;
}

.ad_gallery_link {
	float:right;
	margin:5px 5px 5px 50px;
}
.ad_gallery_link a {
	padding:2px 25px 5px 0;
	background: transparent url(<?php echo $vars['url']; ?>mod/ad/graphics/icon_gallery.gif) no-repeat right top;
	display:block;
}
.ad_gallery_link a:hover {
	background-position: right -40px;
}



/* ***************************************
	RIVER
*************************************** */

.river_object_ad_create {
	background: url(<?php echo $vars['url']; ?>mod/ad/graphics/river_icons/river_icon_ad.gif) no-repeat left -1px;
}
.river_object_ad_update {
	background: url(<?php echo $vars['url']; ?>mod/ad/graphics/river_icons/river_icon_ad.gif) no-repeat left -1px;
}
.river_object_ad_comment {
	background: url(<?php echo $vars['url']; ?>mod/ad/graphics/river_icons/river_icon_comment.gif) no-repeat left -1px;
}

