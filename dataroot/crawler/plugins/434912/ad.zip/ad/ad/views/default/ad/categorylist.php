<?php
	/**
	 * Elgg Classifieds Pluggin V2
	 * @package Classifieds Pluggin
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */

	$list = elgg_view('adcategories/list',$vars);
	if (!empty($list)) {
?>

	<div class="blog_categories">
		<?php echo $list; ?>
	</div>

<?php

	}

?>