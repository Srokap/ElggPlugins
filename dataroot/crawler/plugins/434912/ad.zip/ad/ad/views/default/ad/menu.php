<?php

	/**
	 * Elgg Classifieds Pluggin V2
	 * @package Classifieds Pluggin
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */

?>

	<p class="user_menu_ad">
		<a href="<?php echo $vars['url']; ?>pg/ad/<?php echo $vars['entity']->username; ?>"><?php echo elgg_echo("ad"); ?></a>	
	</p>