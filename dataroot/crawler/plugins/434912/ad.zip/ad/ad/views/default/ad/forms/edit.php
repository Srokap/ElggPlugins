<?php

	/**
	 * Elgg Classifieds Pluggin V2
	 * @package Classifieds Pluggin
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */

	// Set title, form destination
		if (isset($vars['entity'])) {
			$title = sprintf(elgg_echo("ad:editpost"),$object->title);
			$action = "ad/edit";
			$title = $vars['entity']->title;
			$body = $vars['entity']->description;
			$price = $vars['entity']->price;
			$tags = $vars['entity']->tags;
			$access_id = $vars['entity']->access_id;
		} else  {
			$title = elgg_echo("ad:addpost");
			$action = "ad/add";
			$tags = "";
			$title = "";
			$description = "";
			$access_id = 0;
		}

	// Just in case we have some cached details
		if (isset($vars['adtitle'])) {
			$title = $vars['adtitle'];
			$body = $vars['adbody'];
			$price = $vars['adprice'];
			$tags = $vars['adtags'];
		}
				$ts = time();
				$token = generate_action_token($ts);


?>
<div class="contentWrapper">

	<form action="<?php echo $vars['url']; ?>action/<?php echo $action; ?>" enctype="multipart/form-data" method="post">
  <p> 
    <label><?php echo elgg_echo("title"); ?><br />
    <?php

				echo elgg_view("input/text", array(
									"internalname" => "adtitle",
									"value" => $title,
													));
			
			?>
    </label>
  </p>

  
		<p>
			<label><?php echo elgg_echo("ad:text"); ?><br />
			<?php

				echo elgg_view("input/longtext",array(
									"internalname" => "adbody",
									"value" => $body,
													));
			?>
			</label>
		</p>
		
		
		    <p> 
    <label><?php echo elgg_echo("ad:price"); ?><br />
    <?php

				echo elgg_view("input/text", array(
									"internalname" => "adprice",
									"value" => $price,
													));
			
			?>
    </label>
  </p>
  

				<p>
			<label><?php echo elgg_echo("ad:tags"); ?><br />
    <?php

				echo elgg_view("input/tags", array(
									"internalname" => "adtags",
									"value" => $tags,
													));
			
			?>
			 </label>
  </p>
    <?php

		$adcategories = elgg_view('adcategories',$vars);
		if (!empty($adcategories)) {
?>
    <p>
			<?php echo $adcategories; ?>
		</p>

<?php
		}

?>	
		

        <!-- display upload if action is edit -->
        		<?php
				if ($action == "ad/add") {	
				?>
        				<p>
   					     	<label><?php echo elgg_echo("ad:uploadimages"); ?><br />
   				     		   <?php echo elgg_echo("ad:imagelimitation"); ?><br />
							<?php
									echo elgg_view("input/file",array('internalname' => 'upload'));
					
							?>
 				           </label>
 				        </p>
 		        <?php
					}
				?>
         <!-- display upload if action is edit end -->
		<p>
			<label>
				<?php echo elgg_echo('access'); ?><br />
				<?php echo elgg_view('input/access', array('internalname' => 'access_id','value' => $access_id)); ?>
			</label>
		</p>
		<p>
			<?php

				if (isset($vars['entity'])) {
					?><input type="hidden" name="adpost" value="<?php echo $vars['entity']->getGUID(); ?>" /><?php
				}
			
			?>
            <input name="__elgg_token" value="<?php echo $token; ?>" type="hidden">
            <input name="__elgg_ts" value="<?php echo $ts; ?>" type="hidden">
			<input type="submit" name="submit" value="<?php echo elgg_echo('save'); ?>" />
		</p>
	
	</form></div>