<?php

	/**
	 * Elgg Classifieds Pluggin V2
	 * @package Classifieds Pluggin
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */
	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'ad' => "Classified",
			'ads' => "Classifieds",
			'ad:user' => "%s's classified",
			'ad:user:friends' => "%s's friends' classified",
			'ad:your' => "Your classified",
			'ad:posttitle' => "%s's classified: %s",
			'ad:friends' => "Friends' classifieds",
			'ad:yourfriends' => "Your friends' latest classifieds",
			'ad:everyone' => "All site classifieds",
			'ad:read' => "Read classified",
			'ad:addpost' => "Create a new classified",
			'ad:editpost' => "Edit classified post",
			'ad:imagelimitation' => "Must be jpg, smaller than 1MB",
			'ad:text' => "Give a brief description about the classified matter",
			'ad:uploadimages' => "Would you like to upload an image?",
			'ad:imagelater' => "",
			'ad:strapline' => "%s",
			'item:object:ad' => 'Classified posts',
	

		/**
	     * ad widget
	     **/
			'ad:widget' => "Classified",
			'ad:widget:description' => "Showcase your latest classifieds",
			'ad:widget:viewall' => "View all my classifieds",
			'ad:num_display' => "Number of classifieds to display",
			'ad:icon_size' => "Icon size",
			'ad:small' => "small",
			'ad:tiny' => "tiny",
		
         /**
	     * ad river
	     **/
	        
	        //generic terms to use
	        'ad:river:created' => "%s wrote",
	        'ad:river:updated' => "%s updated",
	        'ad:river:posted' => "%s posted",
	        //these get inserted into the river links to take the user to the entity
	        'ad:river:create' => "a new classified post titled",
	        'ad:river:update' => "the classified post titled",
	        'ad:river:annotate' => "a reply on the classified post titled",
	
		/**
		 * Status messages
		 */
	
			'ad:posted' => "Your classified post was successfully posted.",
			'ad:deleted' => "Your classified post was successfully deleted.",
			'ad:uploaded' => "Your image was succesfully added.",
	
		/**
		 * Error messages
		 */
	
			'ad:save:failure' => "Your classified post could not be saved. Please try again.",
			'ad:blank' => "Sorry; you need to fill in both the title and body before you can make a post.",
			'ad:tobig' => "Sorry; your file is bigger then 1MB, please upload a smaller file.",
			'ad:notjpg' => "Please make sure the picture inculed is a .jpg file.",
			'ad:notuploaded' => "Sorry; your file doesn't apear to be uploaded.",
			'ad:notfound' => "Sorry; we could not find the specified classified post.",
			'ad:notdeleted' => "Sorry; we could not delete this classified post.",
		/**
		 * Tweeks new version
		 */
		 'ad:price' => "Expected Price",
		 'ad:tags' => "Tags",
		 'ad:replies' => "Replies",
	);
					
	add_translation("en",$english);

?>