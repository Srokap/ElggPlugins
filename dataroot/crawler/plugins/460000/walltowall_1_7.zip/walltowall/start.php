<?php
  global $CONFIG;
   
  register_action("walltowall/add", false, $CONFIG->pluginspath . "walltowall/actions/add.php");    
?>
