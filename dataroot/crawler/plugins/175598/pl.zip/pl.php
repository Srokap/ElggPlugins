<?php

	/**
	 * Elgg Classifieds Pluggin V2
	 * @package Classifieds Pluggin
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */
	$polish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'ad' => "Ogłoszenie",
			'ads' => "Ogłoszenia",
			'ad:user' => "Ogłoszenia %s",
			'ad:user:friends' => "Ogłoszenia znajomych %s",
			'ad:your' => "Twoje ogłoszenia",
			'ad:posttitle' => "%s ogłoszenie: %s",
			'ad:friends' => "Ogłoszenia znajomych",
			'ad:yourfriends' => "Ostatnie ogłoszenia Twoich znajomych",
			'ad:everyone' => "Wszystkie ogłoszenia",
			'ad:read' => "Czytaj ogłoszenie",
			'ad:addpost' => "Dodaj Nowe",
			'ad:editpost' => "Edytuj",
			'ad:imagelimitation' => "Musi być to plik w formacie jpg do 1MB",
			'ad:text' => "Dodaj opis zawartości ogłoszenia",
			'ad:uploadimages' => "Dodajemy zdięcie?",
			'ad:imagelater' => "",
			'ad:strapline' => "%s",
			'item:object:ad' => 'Classified posts',
            'ad:offer'=>"SZUKAM",
            'ad:sell'=>"SPRZEDAM",
            'ad:change'=>"ZAMIENIĘ",

		/**
	     * ad widget
	     **/
			'ad:widget' => "Ogłoszenia",
			'ad:widget:description' => "Pokazuje ostatnie ogłoszenia",
			'ad:widget:viewall' => "Pokaż wszystkie moje ogłoszenia",
			'ad:num_display' => "Ilość pozycji do wyświetlenia",
			'ad:icon_size' => "Wielkośc Ikonki",
			'ad:small' => "mała",
			'ad:tiny' => "tycia",
		
         /**
	     * ad river
	     **/
	        
	        //generic terms to use
	        'ad:river:created' => "%s napisał",
	        'ad:river:updated' => "%s uaktualnił",
	        'ad:river:posted' => "%s dodał wpis",
	        //these get inserted into the river links to take the user to the entity
	        'ad:river:create' => "nowe ogłoszenie",
	        'ad:river:update' => "wpis w ogłoszeniu",
	        'ad:river:annotate' => "odpowiedź w ogłoszeniu",
	
		/**
		 * Status messages
		 */
	
			'ad:posted' => "Twoje ogłoszenie zostało dodane.",
			'ad:deleted' => "Twoje ogłoszenie zostało usunięte.",
			'ad:uploaded' => "Twoje zdięcie zostało dodane.",
	
		/**
		 * Error messages
		 */
	
			'ad:save:failure' => "Your classified post could not be saved. Please try again.",
			'ad:blank' => "Sorry; you need to fill in both the title and body before you can make a post.",
			'ad:tobig' => "Sorry; your file is bigger then 1MB, please upload a smaller file.",
			'ad:notjpg' => "Please make sure the picture inculed is a .jpg file.",
			'ad:notuploaded' => "Sorry; your file doesn't apear to be uploaded.",
			'ad:notfound' => "Sorry; we could not find the specified classified post.",
			'ad:notdeleted' => "Sorry; we could not delete this classified post.",
		/**
		 * Tweeks new version
		 */
		 'ad:price' => "Oczekiwana cena",
		 'ad:tags' => "Tagi",
		 'ad:replies' => "Odpowiedzi",
		 'ad:type'  =>  "Typ",
     	 'ad:description'  =>  "Opis",
        'ad:categoria'=>"Kategoria",
        'ad:by'=>"przez ",

); 
					
	add_translation("pl",$polish);

?>
