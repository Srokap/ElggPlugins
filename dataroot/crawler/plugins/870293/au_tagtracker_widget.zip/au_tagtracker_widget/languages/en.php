<?php

$english = array(
  'au_tagtracker' => "Tag Tracker",
  'au_tagtracker:description' => "Find content based on user provided tags",
  'au_tagtracker:enter:tags' => "No tags configured",
  'au_tagtracker:no:results' => "No content found",
);
					
add_translation("en",$english);