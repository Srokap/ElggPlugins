<?php
/*****************************************************************************
 * Phloor Filebrowser                                                        *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php

elgg_register_event_handler('init',  'system', 'phloor_filebrowser_init');

/**
 *
 */
function phloor_filebrowser_init() {
    	
    /**
     * JS
     */
    $js_url = 'mod/phloor_filebrowser/vendors/elfinder-2.0/js/';
    elgg_register_js('jquery-elfinder-js', $js_url . 'elfinder.min.js', 'footer', 10);

    // load user language file:
    $js_url = 'mod/phloor_filebrowser/vendors/elfinder-2.0/js/i18n/';
    $lang = strtolower(get_language());
    $lang_js_file = $js_url . "elfinder.{$lang}.js";
    elgg_register_js('jquery-elfinder-LANG-js', $lang_js_file, 'footer', 20);

    /**
     * CSS
     */
    $css_url = 'http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.14/themes/smoothness/jquery-ui.css';
    elgg_register_css('jquery-elfinder-smoothness-css', $css_url, 700);

    $css_url = 'mod/phloor_filebrowser/vendors/elfinder-2.0/css/';
    elgg_register_css('jquery-elfinder-css', $css_url . 'elfinder.min.css', 701);
    elgg_register_css('jquery-elfinder-theme-css', $css_url . 'theme.css', 702);

    /**
     * Page handler
     */
    elgg_register_page_handler('phloor_filebrowser', 'phloor_filebrowser_page_handler');

    /**
     * Admin menu
     */
    elgg_register_admin_menu_item('administer', 'phloor_filebrowser', 'administer_utilities');

    /**
     * Site menu
     * add site navigation item
     */
    if(elgg_is_admin_logged_in()) {
        $item = new ElggMenuItem('phloor_filebrowser', elgg_echo('phloor_filebrowser:filebrowser'), 'phloor_filebrowser/all');
        elgg_register_menu_item('site', $item);
    }
}

function phloor_filebrowser_page_handler($page) {
    if(!elgg_is_admin_logged_in()) {
        return false;
    }

    /**
     * Extend views
     */
    elgg_extend_view('css/elgg',           'phloor_filebrowser/css/elgg');
    elgg_extend_view('page/elements/foot', 'phloor_filebrowser/js/foot' );

    elgg_load_js('jquery-elfinder-js');
    elgg_load_js('jquery-elfinder-LANG-js');

    elgg_load_css('jquery-elfinder-smoothness-css');
    elgg_load_css('jquery-elfinder-css');
    elgg_load_css('jquery-elfinder-theme-css');
    	
    $title = elgg_echo('phloor_filebrowser:page:title');

    $body = elgg_view_layout('one_column', array(
		'title'   => $title,
		'content' => elgg_view('phloor_filebrowser/filebrowser'),
    ));

    echo elgg_view_page($title, $body);

    return true;
}
