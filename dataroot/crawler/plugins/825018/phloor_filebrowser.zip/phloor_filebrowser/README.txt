/**
 * Phloor Filebrowser
 * 
 * @package phloor_filebrowser
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author void <void@13net.at>
 * @copyright 13net
 * @link http://www.13net.at/
 */
 
Version: 1.8-11.12.05b
Requires: Elgg 1.8 or higher

/**
 * Description
 */
Enables a filebrowser for Administrators on your Elgg site.  

/**
 * Languages
 */
English
German
