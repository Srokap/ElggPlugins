<?php

// start engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

admin_gatekeeper();

$options = array(
	// 'debug' => true,
	'roots' => array(
		array(
			'driver'        => 'LocalFileSystem',
			'path'          => elgg_get_root_path(),
			'alias'         => elgg_echo('phloor_filebrowser:directory:root'),
		),
		array(
			'driver'        => 'LocalFileSystem',
			'path'          => elgg_get_plugins_path(),
			'alias'         => elgg_echo('phloor_filebrowser:directory:plugins'),
		),
		array(
			'driver'        => 'LocalFileSystem',
			'path'          => elgg_get_data_path(),
			'alias'         => elgg_echo('phloor_filebrowser:directory:data'),
		),
	)
);

// run elFinder
$elfinder  = new elFinder($options);
$connector = new elFinderConnector($elfinder);
$connector->run();

