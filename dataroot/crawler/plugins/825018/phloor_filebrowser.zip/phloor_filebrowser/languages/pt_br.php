<?php

// Gerado pela extensão 'translationbrowser'  20111204-11:42:10 PM

$portugues_brasileiro = array( 
	 'phloor_filebrowser'  =>  "Phloor Navegador de Arquivos" , 
	 'phloor_filebrowser:page:title'  =>  "Navegador de Arquivos" , 
	 'phloor_filebrowser:filebrowser'  =>  "Navegador de Arquivos" , 
	 'admin:administer_utilities:phloor_filebrowser'  =>  "Navegador de Arquivos" , 
	 'phloor_filebrowser:directory:root'  =>  "/" , 
	 'phloor_filebrowser:directory:plugins'  =>  "/mod/" , 
	 'phloor_filebrowser:directory:data'  =>  "/data/"
); 

add_translation('pt_br', $portugues_brasileiro); 

?>