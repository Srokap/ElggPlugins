<?php
	$dutch = array(
		'small_world:profile:first_degree' => "Deze persoon is een eerstegraads connectie",
		'small_world:profile:second_degree' => "Deze persoon is een tweedegraads connectie",
	
		'small_world:friends:shared' => "Gedeeld",
		'small_world:friends:other' => "Andere",
	
		'small_world:second_degree_widget:title' => "Hoe ben je verbonden",
		'small_world:second_degree_widget:you' => "Jij",
	
	);
	
	add_translation("nl", $dutch);
?>
