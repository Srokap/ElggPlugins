<?php
	$english = array(
		'small_world:profile:first_degree' => "This person is a first degree connection",
		'small_world:profile:second_degree' => "This person is a second degree connection",
	
		'small_world:friends:shared' => "Shared",
		'small_world:friends:other' => "Other",
	
		'small_world:second_degree_widget:title' => "How you are connected",
		'small_world:second_degree_widget:you' => "You",
	
	);
	
	add_translation("en", $english);
?>
