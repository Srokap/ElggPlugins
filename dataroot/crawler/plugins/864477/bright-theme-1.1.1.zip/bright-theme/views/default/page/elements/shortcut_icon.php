<?php
/**
 * Displays the default shortcut icon
 */
?>
<link rel="SHORTCUT ICON" href="<?php echo elgg_get_site_url(); ?>mod/bright-theme/graphics/favicon.ico" />
