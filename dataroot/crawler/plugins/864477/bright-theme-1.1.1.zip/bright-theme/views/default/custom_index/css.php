<?php
/**
 * Custom Index CSS
 *
 */
?>

/*******************************
	Custom Index
********************************/
.custom-index {
	padding: 10px 0px;
}

.elgg-module-highlight h2 {
  padding: 0;
}
