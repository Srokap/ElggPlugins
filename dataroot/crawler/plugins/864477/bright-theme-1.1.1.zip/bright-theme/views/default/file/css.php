<?php
/**
 * File CSS extender 
 * 
 * @package ElggFile
 */
?>
.file-photo {
	text-align: center;
	margin: 15px 0px;
}
.file-gallery-item {
	text-align: center;
	width: 160px;
  margin: 10px;
}
