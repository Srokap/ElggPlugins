____________________

Bright Theme v1.1.1
____________________

Compatible Elgg version: 1.8.3

Bright Theme is a neat and friendly theme for Elgg. Ideal starter theme for developing your own.


____________________

Theme features
____________________

- Fixed width design
- Transparency, shadows, CSS3
- More space around the elements
- All the default plugins supported
- Gimp XCF and Inkscape SVG files included
- Slightly modified icon set
- Replaceable favicon and logo
- Tested in Chromium, Firefox, and Opera


____________________

Installation steps
____________________

1. Unzip the downloaded file and copy only the 'bright-theme' folder and its contents into the 'mod' folder inside your Elgg installation.

2. You might need to set the permissions for the 'bright-theme' folder and on its contents. Make sure you're in root mode if you're on Linux, and right click on the folder, or use the 'chmod' command. Set the permissions to 755.

3. Go to 'Administration/Configure/Plugins' on your Elgg site and set the priority of the theme if neccessary. Ideally it should be the last plugin to load. Then activate it!

4. You might also need to clear the cache at 'Administer/Dashboard', seek for 'Flush the caches'.


____________________

Tips for modders
____________________

*** Don't forget to flush the caches to see your modifications! ***
*** Or use the 'Developer Plugin' instead, but set its options correctly! ***

- Header height
  File:   bright-theme/views/default/css/elements/layout.php
  Class:  .elgg-page-default .elgg-page-header > .elgg-inner

- Repeating header background
  File:   bright-theme/graphics/header.png
          bright-theme/views/default/css/elements/layout.php
  Class:  .elgg-page-header

- Inner header background
  File:   bright-theme/graphics/header-gradients.png
          bright-theme/views/default/css/elements/layout.php
  Class:  .elgg-page-default .elgg-page-header > .elgg-inner

- Logo
  File:   bright-theme/graphics/logo.png
          bright-theme/views/default/css/elements/typography.php
  Class:  .elgg-heading-site, .elgg-heading-site:hover

- Hovered logo
  File:   bright-theme/graphics/logo-hover.png
          bright-theme/views/default/css/elements/typography.php
  Class:  .elgg-heading-site:hover

- Login button
  File:   bright-theme/views/default/css/elements/misc.php
  Class:  #login-dropdown


____________________

Miscellaneous
____________________

Bright Theme (c) 2012 by easy82 (easy82 dot contact at gmail dot com)

License: GNU Public License version 2

