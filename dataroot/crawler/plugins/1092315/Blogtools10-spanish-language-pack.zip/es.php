<?php

	$spanish = array(
		'blog_tools' => "Herramientas de Blog",
		
		'blog_tools:toggle:feature' => "Destacar",
		'blog_tools:toggle:unfeature' => "No destacar",
		'blog_tools:transfer' => "Transferir propietario",
		
		// widget
		'blog_tools:widget:featured' => "¿Mostrar sólo blogs destacados?",
		
		// views
		// blog edit
		'blog_tools:label:icon:exists' => "Cargar icono (dejar en blanco para mantener el icono actual)",
		'blog_tools:label:icon:new' => "Cargar icono",
		'blog_tools:label:icon:remove' => "Eliminar icono",
	
		// transfer owner
		'blog_tools:transfer:title' => "Transferir propietario de: %s",
		'blog_tools:transfer:description' => "Desde aquí puedes transferir la propiedad del blog. Escribe el nombre (o el nombre de usuario) del nuevo propietario y selecciónalo de la lista. Pulsa en Transferir y el blog será transferido.",
		'blog_tools:transfer:form:new_owner' => "Escribe el nombre del nuevo propietario",
		'blog_tools:transfer:form:submit' => "Transferir",
		
		// settings
		'blog_tools:settings:image' => "Configuración de imagen del Blog",
		'blog_tools:settings:other' => "Otras configuraciones",
		
		'blog_tools:settings:listing:image_align' => "Alineación de imagen en el listado de Blog",
		'blog_tools:settings:listing:image_size' => "Tamaño de imagen en el listado de Blog listing image size",
		
		'blog_tools:settings:full:image_align' => "Alineación de imagen en la vista completa de Blog",
		'blog_tools:settings:full:image_size' => "Tamaño de imagen en la vista completa de Blog",
		
		'blog_tools:settings:align:none' => "No hay imagen",
		'blog_tools:settings:align:left' => "Izquierda",
		'blog_tools:settings:align:right' => "Derecha",
		
		'blog_tools:settings:size:tiny' => "Minúsculo (16x16)",
		'blog_tools:settings:size:small' => "Pequeño (40x40)",
		'blog_tools:settings:size:medium' => "Mediano (100x100)",
		'blog_tools:settings:size:large' => "Grande (200x200)",
		
		'blog_tools:settings:listing:strapline' => "Mostrar titular en el listado",
		'blog_tools:settings:strapline:default' => "Por omisión (propietario y etiquetas)",
		'blog_tools:settings:strapline:time' => "Sólo tiempo",
		
		'blog_tools:settings:advanced_gatekeeper' => "Usar pasarela avanzada de blog",
		'blog_tools:settings:advanced_gatekeeper:description' => "Esto ayudará a los usuarios no logueados a encontrar el camino a un blog protegido más fácilmente",
		
		// actions
		'blog_tools:action:toggle_metadata:error' => "Ha ocurrido un error desconocido mientras se editaba el item, por favor, inténtalo de nuevo",
		'blog_tools:action:toggle_metadata:success' => "El item se ha editado exitosamente",
		
		'blog_tools:action:transfer:error:owner' => "No se puede transferir el blog al mismo usuario",
		'blog_tools:action:transfer:error:transfer' => "Ha ocurrido un error desconocido mientras se transfería el blog, por favor inténtalo de nuevo",
		'blog_tools:action:transfer:success' => "El Blog de ha transferido con éxito",
		
		// widget
		'blog_tools:widgets:index_blog:description' => "Muestra los últimos blogs de tu comunidad",
		
		'blog_tools:widgets:index_blog:view_mode' => "Cómo ver los blog",
		'blog_tools:widgets:index_blog:view_mode:list' => "Lista",
		'blog_tools:widgets:index_blog:view_mode:preview' => "Vista preliminar",
		'blog_tools:widgets:index_blog:view_mode:slider' => "Modo deslizador",
	);
	
	add_translation("es", $spanish);
