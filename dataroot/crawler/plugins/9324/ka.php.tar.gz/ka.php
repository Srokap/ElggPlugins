<?php

	$georgian = array(

		/**
		 * Sites
		 */
	
			'item:site' => 'Sites',
	
		/**
		 * Sessions
		 */
			
			'login' => "შესვლა",
			'loginok' => "თქვენ უკვე შესული ხართ.",
			'loginerror' => "შესვლა ვერ განხორციალდა. შესაძლოა თქვენ ჯერ არ გაგიაქტიურებიათ თქვენი ანგარიში, ან თქვენს მიერ მითითებული დეტალები არაა სწორი. გთხოვთ შეამოწმოთ, რომ თქვენს მიერ მითითებული დეტალები სწორია და კიდევ სცადეთ.",
	
			'logout' => "გამოსვლა",
			'logoutok' => "თქვენ უკვე გასული ხართ.",
			'logouterror' => "გამოსვლა ვერ განხორციალდა. გთხოვთ კიდევ სცადეთ.",
	
		/**
		 * Errors
		 */
			'exception:title' => "მოგესალმებათ Elgkdissert -caption "%c" %i %mg.",
	
			'InstallationException:CantCreateSite' => "შეუძლებელია ნაგულისხმევი ElggSite-ის შექმნა მანდატის სახელად:%s, Url: %s",
		
			'actionundefined' => "მოთხოვნილი მოქმედება (%s) სისტემაში განსაზღვრული არაა.",
			'actionloggedout' => "ბოდიში, თქვენ არ შეგიძლიათ ამ მოქმედების შესრულება, ვინაიდან არ ხართ შესული სისტემაში.",
	
			'notfound' => "მოთხოვნილი რესურსი ვერ მოიძებნა, ან თქვენ არ გაქვთ მასზე წვდომა.",
			
			'SecurityException:Codeblock' => "წვდომა პრივილიგირებული კოდის ბლოკთან აკრძალულია",
			'DatabaseException:WrongCredentials' => "Elgg მოცემული მანდატით %s@%s (pw: %s) ვერ დაუკავშირდა მონაცემთა ბაზას.",
			'DatabaseException:NoConnect' => "Elgg ვერ აირჩია მონაცემთა ბაზა '%s', გთხოვთ შეამოწმოთ რომ მონაცემთა ბაზა შექმნილია და მასთან გაქვთ წვდომა.",
			'SecurityException:FunctionDenied' => "წვდომა პრივილიგირებულ ფუნქციასთან '%s' აკრძალულია.",
			'DatabaseException:DBSetupIssues' => "აქ იყო შემდეგი მიზეზები: ",
			'DatabaseException:ScriptNotFound' => "Elgg ვერ მოძებნა მოთხოვნილი მონაცემთა ბაზის სკრიპტი %s -ზე.",
			
			'IOException:FailedToLoadGUID' => "ვერ მოხერხდა ახალი %s ჩატვირთვა GUID:%d-დან",
			'InvalidParameterException:NonElggObject' => "არა-ElggObject-ს გადაცემა ElggObject კონსტრუქტორისთვის!",
			'InvalidParameterException:UnrecognisedValue' => "კონსტრუქტორის გადაეცა ამოუცნობი მნიშვნელობა.",
			
			'InvalidClassException:NotValidElggStar' => "GUID:%d არაა მართებული %s",
			
			'PluginException:MisconfiguredPlugin' => "%s არის არასწორად გამართული ჩანართი.",
			
			'InvalidParameterException:NonElggUser' => "არა-ElggUser-ს ElggUser კონსტრუქტორისთვის გადაცემა!",
			
			'InvalidParameterException:NonElggSite' => "არა-ElggUser-ს ElggUser კონსტრუქტორისთვის გადაცემა!",
			
			'InvalidParameterException:NonElggGroup' => "არა-ElggUser-ს ElggUser კონსტრუქტორისთვის გადაცემა!",
	
			'IOException:UnableToSaveNew' => "ახალი %s-ს შენახვა შეუძლებელია",
			
			'InvalidParameterException:GUIDNotForExport' => "GUID არ იყო განსაზღვრული ექსპორტისას, ეს არ უნდა მოხდეს.",
			'InvalidParameterException:NonArrayReturnValue' => "ელემენტის სერიალიზაციის ფუნქცია გადაცემულია არა მასივის მნიშვნელობის დაბრუნების პარამეტრზე",
			
			'ConfigurationException:NoCachePath' => "ქეშის გეზში მოცემულია სიცარიელე!",
			'IOException:NotDirectory' => "%s არაა დირექტორია.",
			
			'IOException:BaseEntitySaveFailed' => "შეუძლებელია ახალი ობიექტის ძირითადი ინფორმაციის შენახვა!",
			'InvalidParameterException:UnexpectedODDClass' => "იმპორტი() გადმოეცა მოულოდნელი ODD კლასი",
			'InvalidParameterException:EntityTypeNotSet' => "ელემენტის ტიპი უნდა მიეთითოს.",
			
			'ClassException:ClassnameNotClass' => "%s არაა %s.",
			'ClassNotFoundException:MissingClass' => "კლასი '%s' ვერ მოიძებნა, არარსებული ჩანართი?",
			'InstallationException:TypeNotSupported' => "ტიპი %s არაა მხარდაჭერილი. ეს აღნიშნავს დაყენების შეცდომას, სავარაუდო მიზეზია არასრული განახლება.",

			'ImportException:ImportFailed' => "%d ელემენტის იმპორტი ვერ განხორციალდა",
			'ImportException:ProblemSaving' => "%s შენახვის პრობლემა",
			'ImportException:NoGUID' => "ახალი ელემენტი შეიქმნა, მაგრამ მას არ აქვს GUID, ეს არ უნდა მოხდეს.",
			
			'ImportException:GUIDNotFound' => "'%d' ელემენტი ვერ მოიძებნა.",
			'ImportException:ProblemUpdatingMeta' => "'%s' განახლებისას '%d ელემენტზე მოხდა შეცდომა'",
			
			'ExportException:NoSuchEntity' => "ასეთი ელემენტი GUID:%d არაა", 
			
			'ImportException:NoODDElements' => "იმპორტირებულ მონაცემებში OpenDD ელემენტები ვერ მოიძებნა, იმპორტი ვერ განხორციალდა.",
			'ImportException:NotAllImported' => "ყველა ელემენტი არ იყო იმპორტირებული.",
			
			'InvalidParameterException:UnrecognisedFileMode' => "ამოუცნობი ფაილის რეჟიმი '%s'",
			'InvalidParameterException:MissingOwner' => "ყველა ფაილს უნდა ჰყავდეს პატრონი!",
			'IOException:CouldNotMake' => "%s ვერ გაკეთდა",
			'IOException:MissingFileName' => "თქვენ უნდა მიუთითოთ სახელი ფაილის გახსნამდე.",
			'ClassNotFoundException:NotFoundNotSavedWithFile' => "ფაილთა ბაზა ვერ მოიძებნა ან კლასი ფაილთან ერთად არ იყო შენახული!",
			'NotificationException:NoNotificationMethod' => "შეტყობინების მეთოდი არაა განსაზღვრული.",
			'NotificationException:NoHandlerFound' => "'%s'სთვის დამმუშავებელი ვერ მოიძებნა ან იგი არაა გამოძახებადი.",
			'NotificationException:ErrorNotifyingGuid' => "%d-ს შეტყობინებისას მოხერხდა შეცდომა",
			'NotificationException:NoEmailAddress' => "GUID:%d-სთვის ელფოსტის მისამართის მიღება ვერ განხორციალდა",
			'NotificationException:MissingParameter' => "მოთხოვნილი პარამეტრი არაა, '%s'",
			
			'DatabaseException:WhereSetNonQuery' => "Where ნაკრები შეიცავს არა WhereQueryComponent",
			'DatabaseException:SelectFieldsMissing' => "არჩეულ სტილის გამოკითხვას აკლია ველები",
			'DatabaseException:UnspecifiedQueryType' => "ამოუცნობი ან განუსაზღვრელი გამოკითხვის ტიპი.",
			'DatabaseException:NoTablesSpecified' => "გამოკითხვისთვის არაა მითითებული ცხრილები.",
			'DatabaseException:NoACL' => "გამოკითხვაზე არ იყო მითითებული წვდომის კონტროლი",
			
			'InvalidParameterException:NoEntityFound' => "ელემენტი ვერ მოიძებნა, იგი ან არ არსებობს, ან თქვენ მასზე არ გაქვთ წვდომა.",
			
			'InvalidParameterException:GUIDNotFound' => "GUID:%s ვერ მოიძებნა, ან თქვენ მასზე არ გაქვთ წვდომა.",
			'InvalidParameterException:IdNotExistForGUID' => "ბოდიში, '%s' არ არსებობს guid:%d-სთვის",
			'InvalidParameterException:CanNotExportType' => "ბოდიში, არ ვიცი როგორ გავაკეთო '%s'-ს ექსპორტი",
			'InvalidParameterException:NoDataFound' => "მონაცემები ვერ მოიძებნა.",
			'InvalidParameterException:DoesNotBelong' => "არ ეკუთვნის ელემენტს.",
			'InvalidParameterException:DoesNotBelongOrRefer' => "არ ეკუთვნის ელემენტს ან არ მიუთითებს ელემენტზე.",
			'InvalidParameterException:MissingParameter' => "არ არსებული პარამეტრი, თქვენ უნდა მიუთითოთ GUID.",
			
			'SecurityException:APIAccessDenied' => "ბოდიში, API წვდომა ადმინისტრატორმა გააუქმა.",
			'SecurityException:NoAuthMethods' => "ამ API მოთხოვნის აუტენიფიკაციისთვის მეთოდები ვერ მოიძებნა.",
			'APIException:ApiResultUnknown' => "API შედეგი უცნობი ტიპისაა, ეს არ უნდა მოხდეს.", 
			
			'ConfigurationException:NoSiteID' => "ვებ გვერდის ID არ იყო მითითებული.",
			'InvalidParameterException:UnrecognisedMethod' => "გამოძახების ამოუცნობი მეთოდი '%s'",
			'APIException:MissingParameterInMethod' => "არ არსებული პარამეტრი %s %s მეთოდში",
			'APIException:ParameterNotArray' => "%s არ გამოიყურება როგორც მასივი.",
			'APIException:UnrecognisedTypeCast' => "ამოუცნობი ტიპი %s-ში '%s' ცვლადისთვის '%s' მეთოდში",
			'APIException:InvalidParameter' => "'%s' მეთოდში '%s'-ში მოიძებნა არასწორი პარამეტრი.",
			'APIException:FunctionParseError' => "%s(%s) აქვს დამუშავების შეცდომა.",
			'APIException:FunctionNoReturn' => "%s(%s) არ დააბრუნა მნიშვნელობა.",
			'SecurityException:AuthTokenExpired' => "აუტენიფიკაციის ნიშანი ან არაა, ან არასწორია ან ვადაგასულია.",
			'CallException:InvalidCallMethod' => "%s უნდა იყოს '%s'-თ გამოძახებული",
			'APIException:MethodCallNotImplemented' => "'%s' მეთოდის გამოძახილი ჯერ არაა რეალიზებული.",
			'APIException:AlgorithmNotSupported' => "'%s' ალგორითმი არაა მხარდაჭერილი ან გამორთულია.",
			'ConfigurationException:CacheDirNotSet' => "ქეშის დირექტორია 'cache_path' არაა მითითებული.",
			'APIException:NotGetOrPost' => "მოთხოვნილი მეთოდი უნდა იყოს GET ან POST",
			'APIException:MissingAPIKey' => "X-Elgg-apikey HTTP სათაური არაა",
			'APIException:MissingHmac' => "X-Elgg-hmac სათაური არაა",
			'APIException:MissingHmacAlgo' => "X-Elgg-hmac-algo სათაური არაა",
			'APIException:MissingTime' => "X-Elgg-time სათაური არაა",
			'APIException:TemporalDrift' => "X-Elgg-time ძალიან შორსაა წარსულსა და მომავალში. პერიოდი ჩავარდა.",
			'APIException:NoQueryString' => "გამოკითხვის სტრიქონში არაა მონაცემები",
			'APIException:MissingPOSTHash' => "X-Elgg-posthash სათაური არაა",
			'APIException:MissingPOSTAlgo' => "X-Elgg-posthash_algo სათაური არაა",
			'APIException:MissingContentType' => "პოსტ მონაცემისთვის კონტენტის ტიპი არაა",
			'SecurityException:InvalidPostHash' => "POST მონაცემთა ჰეში არასწორია - მოსალოდნელი იყო %s მაგრამ მიღებულია %s.",
			'SecurityException:DupePacket' => "პაკეტის ხელმოწერა უკვე ნანახია.",
			'SecurityException:InvalidAPIKey' => "არასწორი ან არ არსებული API გასაღები.",
			'NotImplementedException:CallMethodNotImplemented' => "'%s' გამოძახების მეთოდი ამჟამად არაა მხარდაჭერილი.",
	
			'NotImplementedException:XMLRPCMethodNotImplemented' => "XML-RPC გამოძახების მეთოდი '%s' არაა დანერგილი.",
			'InvalidParameterException:UnexpectedReturnFormat' => "'%s' მეთოდის გამოძახებამ დააბრუნა მოულოდნელი შედეგი.",
			'CallException:NotRPCCall' => "გამოძახილი არ ჰგავს სწორ XML-RPC გამოძახილს",
	
			'PluginException:NoPluginName' => "ჩანართის სახელი ვერ მოიძებნა",
	
			'ConfigurationException:BadDatabaseVersion' => "მონაცემთა ბაზის ძრავა, რომელიც გაქვთ დაყენებული, არ არის დამაკმყოფილებელი Elgg-ს გასაშვებად. გთხოვთ წაიკითხოთ დოკუმენტაცია.",
			'ConfigurationException:BadPHPVersion' => "თქვენ გჭირდებათ PHP ვერსია 5.2 Elgg-ს გასაშვებად.",
			'configurationwarning:phpversion' => "Elgg ესაჭიროება PHP ვერსია 5.2 მაინც, მისი დაყენება შესაძლოა 5.1.6-ზეც, მაგრამ ზოგი ფუნქცია არ იმუშავებს. გამოიყენეთ თუ გსურთ გარისკვა.",
	
	
			'InstallationException:DatarootNotWritable' => "თქვენი მონაცემთა დირექტორია %s არაა ჩაწერის უფლებით.",
			'InstallationException:DatarootUnderPath' => "თქვენი მონაცემთა დირექტორია %s უნდა იყოს საინსტალაციო გეზს გარეთ.",
			'InstallationException:DatarootBlank' => "თქვენ არ გაქვთ მითითებული მონაცემთა დირექტორია.",
	
			'SecurityException:authenticationfailed' => "მომხმარებლის აუტენიფიკაცია ვერ განხორციალდა",
	
			'CronException:unknownperiod' => '%s არაა ამოცნობადი პერიოდი.',
	
			'SecurityException:deletedisablecurrentsite' => 'თქვენ არ შეგიძლიათ წაშალოთ ან გამორთოთ გვერდი რომელსაც ახლა ათვალიერებთ!',
		/**
		 * API
		 */
			'system.api.list' => "სისტემაში ყველა ხელმისაწვდომი API გამოძახილების ჩამოთვლა.",
			'auth.gettoken' => "ამ API გამოძახილებითაა შესაძლო მომხმარებლის სისტემაში შესვლა, აუტენიფიკაციის ნიშნის დაბრუნება, რომლის გამოყენებაც შეიძლება გამოყენებულ იქნას მომხმარებლის სახელის და პაროლის შემდეგი აუტენიფიკაციისთვის გამოსაძახებლად.",
	
		/**
		 * User details
		 */

			'name' => "ასახული სახელი",
			'email' => "ელფოსტის მისამართი",
			'username' => "მომხმარებლის სახელი",
			'password' => "პაროლი",
			'passwordagain' => "პაროლი (ხელმეორედ შემოწმებისთვის)",
			'admin_option' => "ეს მომხმარებელი ადმინისტრატორია?",
	
		/**
		 * Access
		 */
	
			'ACCESS_PRIVATE' => "პირადი",
			'ACCESS_LOGGED_IN' => "შესულია მომხმარებლებში",
			'ACCESS_PUBLIC' => "საჯარო",
			'PRIVATE' => "პირადი",
			'LOGGED_IN' => "შესულია მომხმარებლებში",
			'PUBLIC' => "საჯარო",
			'access' => "წვდომა",
	
		/**
		 * Dashboard and widgets
		 */
	
			'dashboard' => "ხელსაწყოთა დაფა",
            'dashboard:configure' => "გვერდის რედაქტირება",
			'dashboard:nowidgets' => "თქვენი ხელსაწყოთა დაფა არის ვებ გვერდზე თქვენი კარიბჭე. დააწკაპეთ 'გვერდის რედაქტირებას' ჩანართების დასამატებლად, შიგთავსის ჩანაწერთა და თქვენი სისტემის ცხოვრების სათვალყუროდ.",

			'widgets:add' => 'ჩადგმების თქვენს გვერდზე დამატება',
			'widgets:add:description' => "აირჩიეთ შესაძლებლობა რომლის გვერდისთვის დამატება გსურთ მარჯვნივ <b>ჩანაწერთთა გალერეიდან</b> გადმოათრიეთ ქვემოთ მოცემულ ჩანართთა ნებისმიერ სამ სივრცეზე და დააფიქსირეთ ისინი სასურველ ადგილას.

ჩანართის ამოსაგდებად გადაათრიეთ იგი უკან <b>ჩანართთა გალერეაში</b>.",
			'widgets:position:fixed' => '(გვერდზე ფიქსირებული პოზიცია)',
	
			'widgets' => "ჩანართები",
			'widget' => "ჩანართი",
			'item:object:widget' => "ჩანართები",
			'layout:customise' => "სქემის მორგება",
			'widgets:gallery' => "ჩანაწერთთა გალერეა",
			'widgets:leftcolumn' => "მარცხენა ჩანართები",
			'widgets:fixed' => "ფიქსირებული პოზიცია",
			'widgets:middlecolumn' => "შუა ჩანართები",
			'widgets:rightcolumn' => "მარჯვენა ჩანართები",
			'widgets:profilebox' => "პროფილის უჯრა",
			'widgets:panel:save:success' => "თქვენი ჩანართები წარმატებით შეინახა.",
			'widgets:panel:save:failure' => "ჩანართების შენახვის პრობლემა. გთხოვთ კიდევ სცადეთ.",
			'widgets:save:success' => "ჩანართი წარმატებით შეინახა.",
			'widgets:save:failure' => "ჩვენ ვერ შევინახეთ თქვენი ჩანართი. გთხოვთ კიდევ სცადეთ.",
			
	
		/**
		 * Groups
		 */
	
			'group' => "ჯგუფი", 
			'item:group' => "ჯგუფები",
	
		/**
		 * Profile
		 */
	
			'profile' => "პროფილი",
			'profile:edit:default' => 'პლოფილის ველების ჩანაცვლება',
			'user' => "მომხმარებელი",
			'item:user' => "მომხმარებლები",
			'riveritem:single:user' => 'მომხმარებელი',
			'riveritem:plural:user' => 'ზოგი მომხმარებელი',

		/**
		 * Profile menu items and titles
		 */
	
			'profile:yours' => "თქვენი პროფილი",
			'profile:user' => "%s'ის პროფილი",
	
			'profile:edit' => "პროფილის რედაქტირება",
			'profile:profilepictureinstructions' => "პროფილის სურათი არის სურათი, რომელიც თქვენი პროფილის გვერდზე გამოჩნდება. <br /> მისი შეცვლა შეგიძლიათ როდესაც გნებავთ. (შესაძლო ფაილის ფორმატები: GIF, JPG ან PNG)",
			'profile:icon' => "პროფილის სურათი",
			'profile:createicon' => "შექმენით საკუთარი ავატარი",
			'profile:currentavatar' => "მიმდინარე ავატარი",
			'profile:createicon:header' => "პროფილის სურათი",
			'profile:profilepicturecroppingtool' => "პროფილის სურათის დაჭრის ხელსაწყო",
			'profile:createicon:instructions' => "დააწკაპეთ და გადაათრიეთ კვადრატი იმ ზონაზე, რომლის ამოჭრდაც გსურთ სურათისთვის. ამოჭრილი სურათის წინასწარ ხილვა შეგეძლებათ მარჯვნის უჯრაში.  თუ წინასწარ ხილვა გაკმაყოფილებთ, დააწკაპეთ 'ავატარის შექმნას'. ეს ამოჭრილი სურათი გამოყენებულ იქნება ვებ გვერდზე, როგორც თქვენი ავატარი. ",
	
			'profile:editdetails' => "დეტალების რედაქტირება",
			'profile:editicon' => "პროფილის ხატულის რედაქტირება",
	
			'profile:aboutme' => "ჩემს შესახებ", 
			'profile:description' => "ჩემს შესახებ",
			'profile:briefdescription' => "მოკლე აღწერა",
			'profile:location' => "მდებარეობა",
			'profile:skills' => "უნარები",  
			'profile:interests' => "ინტერესები", 
			'profile:contactemail' => "საკონტაქტო ელფოსტა",
			'profile:phone' => "ტელეფონი",
			'profile:mobile' => "მობილური",
			'profile:website' => "ვებგვერდი",

			'profile:river:update' => "%s განაახლეს თავისი პროფილი",
			'profile:river:iconupdate' => "%s განაახლეს თავისი პროფილის ხატულა",
	
			'profile:label' => "პროფილის ეტიკეტი",
			'profile:type' => "პროფილის ტიპი",
	
			'profile:editdefault:fail' => 'ნაგულისხმევი პროფილი ვერ იქნა შენახული',
			'profile:editdefault:success' => 'ელემენტი წარმატებით დაემატა ნაგულისხმევ პროფილს',
	
			
			'profile:editdefault:delete:fail' => 'ნაგულისხმევი პროფილის ელემენტის წაშლა ვერ განხორციალდა',
			'profile:editdefault:delete:success' => 'ნაგულისხმევი პროფილის ელემენტი წაშლილია!',
	
			'profile:defaultprofile:reset' => 'ნაგულისხმევი სისტემური პროფილი განულდა',
	
			'profile:resetdefault' => 'ნაგულისხმევი პროფილის საწყისი პარამეტრებით გამართვა',
	
		/**
		 * Profile status messages
		 */
	
			'profile:saved' => "თქვენი პროფილი წარმატებით შეინახა.",
			'profile:icon:uploaded' => "თქვენი პროფილის სურათი წარმატებით აიტვირთა.",
	
		/**
		 * Profile error messages
		 */
	
			'profile:noaccess' => "თქვენ არ გაქვთ ამ პროფილის რედაქტირების უფლება.",
			'profile:notfound' => "ბოდიში; ჩვენ ვერ ვიპოვეთ მითითებული პროფილი.",
			'profile:cantedit' => "ბოდიში; თქვენ არ გაქვთ ამ პროფილის რედაქტირების უფლება.",
			'profile:icon:notfound' => "ბოდიში; პროფილის სურათის ატვირთვის პრობლემა.",
	
		/**
		 * Friends
		 */
	
			'friends' => "მეგობრები",
			'friends:yours' => "თქვენი მეგობრები",
			'friends:owned' => "%s'ს მეგობრები",
			'friend:add' => "მეგობრის დამატება",
			'friend:remove' => "მეგობრის წაშლა",
	
			'friends:add:successful' => "თქვენ წარმატებით დაამატეთ %s როგორც მეგობარი.",
			'friends:add:failure' => "ჩვენ %s ვერ დავამატეთ როგორც მეგობარი. გთხოვთ კიდევ სცადეთ.",
	
			'friends:remove:successful' => "თქვენ წარმატებით ამოშალეთ %s თქვენი მეგობრების სიიდან.",
			'friends:remove:failure' => "ჩვენ ვერ ამოვშალეთ %s თქვენი მეგობრების სიიდან. გთხოვთ კიდევ სცადეთ.",
	
			'friends:none' => "ამ მომხმარებელს არ ჰყავს არავინ მეგობრად დამატებული ჯერ.",
			'friends:none:you' => "თქვენ არავინ დაგიმატებიათ მეგობრად! მმოძებნეთ ხალხი საერთო ინტერესებით.",
	
			'friends:none:found' => "მეგობრები ვერ მოიძებნა.",
	
			'friends:of:none' => "ეს მომხმარებელი მეგობრად ჯერ არავის დაუმატებია.",
			'friends:of:none:you' => "თქვენ მეგობრად ჯერ არავინ დაგამატათ. შეავსეთ პროფილის შიგთავსი, რათა ხალმხმა შეძლონ თქვენი მოძებნა!",
	
			'friends:of' => "-ს მეგობრები",
			'friends:of:owned' => "ხალხი, ვინც დაუმეგობრდა %s-ს",

			 'friends:num_display' => "ასასხი მეგობრების რაოდენობა",
			 'friends:icon_size' => "ხატულის ზომა",
			 'friends:tiny' => "პაწაწინა",
			 'friends:small' => "პატარა",
			 'friends' => "მეგობრები",
			 'friends:of' => "-ს მეგობრები",
			 'friends:collections' => "მეგობრების კოლექციები",
			 'friends:collections:add' => "ახალი მეგობრების კოლექციები",
			 'friends:addfriends' => "მეგობრების დამატება",
			 'friends:collectionname' => "კოლექციის სახელი",
			 'friends:collectionfriends' => "მეგობრები კოლექციაში",
			 'friends:collectionedit' => "ამ კოლექციის რედაქტირება",
			 'friends:nocollections' => "თქვენ არ გაქვთ კოლექციები.",
			 'friends:collectiondeleted' => "თქვენი კოლექციები წაშლილია.",
			 'friends:collectiondeletefailed' => "ჩვენ ვერ წავშალეთ კოლექცია. თქვენ ან არ გაქვთ უფლება, ან სხვა პრობლემა შეგვემთხვა.",
			 'friends:collectionadded' => "თქვენი კოლექცია წარმატებით შეიქმნა",
			 'friends:nocollectionname' => "თქვენ კოლექციას სახელი უნდა დაარქვათ სანამ იგი შეიქმნება.",
		
	        'friends:river:created' => "%s-მ დაამატა მეგობრების ჩანართი.",
	        'friends:river:updated' => "%s-მა განაახლეს თავისი მეგობრების ჩანართი.",
	        'friends:river:delete' => "%s-მ ამოშალეს თავისი მეგობრების ჩანართი.",
	        'friends:river:add' => "%s-მ დაამატა ვიღაცა მეგობრად.",
	
		/**
		 * Feeds
		 */
			'feed:rss' => 'არხის გამოწერა',
			'feed:odd' => 'Syndicate OpenDD',
			
		/**
          * links
		 **/

			'link:view' => 'ბმულის ნახვა',

	
		/**
		 * River
		 */
			'river' => "მდინარე",			
			'river:relationship:friend' => 'მეგობრობს',

		/**
		 * Plugins
		 */
			'plugins:settings:save:ok' => "%s ჩადგმების პარამეტრები წარმატებით შეინახა.",
			'plugins:settings:save:fail' => "%s ჩადგმისთვის პარამეტრების შენახვის პრობლემა.",
			'plugins:usersettings:save:ok' => "%s ჩადგმისთვის მომხმარებლის პარამეტრები წარმატებით იქნა შენახული.",
			'plugins:usersettings:save:fail' => "%s ჩადგმისთვის მომხმარებლის პარამეტრების შენახვის პრობლემა.",
	
			'item:object:plugin' => 'ჩადმის კონფიგურაციის პარამეტრები',
			
		/**
		 * Notifications
		 */
			'notifications:usersettings' => "შეტყობინების პარამეტრები",
			'notifications:methods' => "გთხოვთ განსაზღვროთ რომელი მეთოდების დაშვება გსურთ.",
	
			'notifications:usersettings:save:ok' => "თქვენი შეტყობინების პარამეტრები წარმატებით იქნა შენახული.",
			'notifications:usersettings:save:fail' => "თქვენი შეტყობინების პარამეტრების შენახვის პრობლემა.",
	
			'user.notification.get' => 'მოცემული მომხმარებლისთვის შეტყობინების პარამეტრების დაბრუნება.',
			'user.notification.set' => 'შეტყობინების პარამეტრების მოცემული მომხმარებლისთვის დაყენება.',
		/**
		 * Search
		 */
	
			'search' => "ძებნა",
			'searchtitle' => "ძებნა: %s",
			'users:searchtitle' => "მომხმარებლებისთვის ძიება: %s",
			'advancedsearchtitle' => "%s შედეგებით, რომლებიც ემთხვევა %s",
			'notfound' => "ვერაფერი მოიძებნა.",
			'next' => "შემდეგი",
			'previous' => "წინა",
	
			'viewtype:change' => "ჩამოთვლის ტიპის შეცვლა",
			'viewtype:list' => "ჩამონათვლის ნახვა view",
			'viewtype:gallery' => "გალერეა",
	
			'tag:search:startblurb' => "'%s'-ს დამთხვეული ჭდეებიანი ელემენტები:",

			'user:search:startblurb' => "'%s'-ს დამთხვეული მომხმარებლები:",
			'user:search:finishblurb' => "მეტის სანახავად აქ დააწკაპეთ.",
	
		/**
		 * Account
		 */
	
			'account' => "ანგარიში",
			'settings' => "პარამეტრები",
            'tools' => "ხელსაწყოები",
            'tools:yours' => "თქვენი ხელსაწყოები",
	
			'register' => "რეგისტრაცია",
			'registerok' => "თქვენ წარმატებით დარეგისტრირდით %s-ზე.",
			'registerbad' => "თქვენი რეგისტრაცია არ იყო წარმატებული. შესაძლოა ასეთი მომხმარებლის სახელი უკვე არსებობს, თქვენი პაროლები არ ემთხვევა, ან თქვენი მომხმარებლის სახელი და პაროლი ძალიან მოკლეა.",
			'registerdisabled' => "რეგისტრაცია სისტემურმა ადმინისტრატორმა გამორთო",
	
			'registration:notemail' => 'თქვენს მიერ მოწოდებული ელფოსტის მისამართი არ ჰგავს მართებულ ელფოსტის მისამართს.',
			'registration:userexists' => 'მომხმარებელი უკვე არსებობს',
			'registration:usernametooshort' => 'თქვენი მომხმარებლის სახელი მინიმუმ 4 სიმბოლოსგან უნდა შედგებოდეს.',
			'registration:passwordtooshort' => 'პაროლი მინიმუმ 6 სიმბოლოსგან უნდა შედგებოდეს.',
			'registration:dupeemail' => 'ეს ელფოსტის მისამართი უკვე დარეგისტრირებულია.',
			'registration:invalidchars' => 'ბოდიში, თქვენი მომხმარებლის სახელი შეიცავს არასწორ სიმბოლოებს.',
			'registration:emailnotvalid' => 'ბოდიში, შეყვანილი ელფოსტის მისამართი ამ სისტემისთვის არაა მართებული',
			'registration:passwordnotvalid' => 'ბოდიში, შეყვანილი პაროლი ამ სისტემისთვის არაა მართებული',
			'registration:usernamenotvalid' => 'ბოდიში, შეყვანილი მომხმარებლის სახელი ამ სისტემისთვის არაა მართებული',
	
			'adduser' => "მომხმარებლის დამატება",
			'adduser:ok' => "ახალი მომხმარებელი წარმატებით დაემატა.",
			'adduser:bad' => "ახალი მომხმარებელი ვერ შეიქმნა.",
			
			'item:object:reported_content' => "მოხსენებული ელემენტები",
	
			'user:set:name' => "ანგარიშის სახელის პარამეტრები",
			'user:name:label' => "თქვენი სახელი",
			'user:name:success' => "თქვენი სახელი სისტემაში წარმატებით შეიცვალა.",
			'user:name:fail' => "თქვენი სახელი სისტემაში ვერ შეიცვალა.",
	
			'user:set:password' => "ანგარიშის პაროლი",
			'user:password:label' => "თქვენი ახალი პაროლი",
			'user:password2:label' => "თქვენი ახალი პაროლი ხელმეორედ",
			'user:password:success' => "პაროლი შეცვლილია",
			'user:password:fail' => "თქვენი პაროლი სისტემაში ვერ შეიცვალა.",
			'user:password:fail:notsame' => "ორი პაროლი არაა ერთიდაიგივე!",
			'user:password:fail:tooshort' => "პაროლი ძალიან მოკლეა!",
	
			'user:set:language' => "ენის პარამეტრები",
			'user:language:label' => "თქვენი ენა",
			'user:language:success' => "თქვენი ენის პარამეტრები განახლდა.",
			'user:language:fail' => "თქვენი ენის პარამეტრები ვერ იქნა შენახული.",
	
			'user:username:notfound' => '%s მომხმარებლის სახელი ვერ მოიძებნა.',
	
			'user:password:lost' => 'დაკარგული პაროლი',
			'user:password:resetreq:success' => 'ახალი პაროლი წარმატებით იქნა მოთხოვნილი, ელწერილი გამოგზავნილია',
			'user:password:resetreq:fail' => 'ახალი პაროლის მოთხოვნა ვერ განხორციალდა.',
	
			'user:password:text' => 'ახალი პაროლის გენერაციისთვის ქვემოთ ჩაწერეთ მომხმარებლის სახელი. ჩვენ გამოგიგზავნით უნიკალურ მისამართს დასადასტურებლად ელფოსტით. დააწკაპეთ გამოგზავნილ ბმულზე და ახალი პაროლი მოგივათ.',
	
			'user:persistent' => 'დამიმახსოვრე',
		/**
		 * Administration
		 */

			'admin:configuration:success' => "თქვენი პარამეტრები შენახული იქნება.",
			'admin:configuration:fail' => "თქვენი პარამეტრების შენახვა ვერ განხორციალდა.",
	
			'admin' => "ადმინისტრირება",
			'admin:description' => "ადმინის დაფა საშუალებას გაძლევთ გააკონტროლოთ სისტემის ყველა ასპექტი, მომხმარებელთა მართვით დაწყებული ჩადგმების კონფიგურაციით დამთავრებული. გთხოვთ აიეჩიოთ პარამეტრი დასაწყებად.",
			
			'admin:user' => "მომხმარებელთა ადმინისტრირება",
			'admin:user:description' => "ამ ადმინისტრაციული დაფის მეშვეობით შეგიძლიათ მართოთ მომხმარებლების პარამეტრები თქვენს საიტზე. გთხოვთ აიეჩიოთ პარამეტრი დასაწყებად.",
			'admin:user:adduser:label' => "დააწკაპეთ აქ ახალი მომხმარებლის დასამატებლად...",
			'admin:user:opt:linktext' => "მომხმარებლების კონფიგურაცია...",
			'admin:user:opt:description' => "მომხმარებლების და ანგარიშის ინფორმაციის კონფიგურაცია. ",
			
			'admin:site' => "ვებ გვერდის ადმინისტრირება",
			'admin:site:description' => "ამ ადმინისტრაციული დაფის მეშვეობით შეგიძლიათ მართოთ თქვენი ვებ გვერდის გლობალური პარამეტრები. გთხოვთ აიეჩიოთ პარამეტრი დასაწყებად.",
			'admin:site:opt:linktext' => "ვებ გვერდის კონფიგურაცია...",
			'admin:site:opt:description' => "ვებ გვერდის ტექნიკური და არა ტექნიკური პარამეტრების გამართვა. ",
			
			'admin:plugins' => "ადმინისტრირების ხელსაწყო",
			'admin:plugins:description' => "ამ ადმინისტრაციული დაფის მეშვეობით შეგიძლიათ მართოთ და გამართეთ თქვენს ვებ გვერდზე დაყენებული ხელსაწყოები.",
			'admin:plugins:opt:linktext' => "კონფიგურაციის ხელსაწყოები...",
			'admin:plugins:opt:description' => "ვებ გვერდზე დაყენებული ხელსაწყოების გამართვა. ",
			'admin:plugins:label:author' => "ავტორი",
			'admin:plugins:label:copyright' => "საავტორო უფლებები",
			'admin:plugins:label:licence' => "ლიცენზია",
			'admin:plugins:label:website' => "URL",
			"admin:plugins:label:moreinfo" => 'მეტი ინფო',
			'admin:plugins:reorder:yes' => "ჩადგმა %s წარმატებით გადაჯგუფდა.",
			'admin:plugins:reorder:no' => "ჩადგმა %s ვერ გადაჯგუფდა.",
			'admin:plugins:disable:yes' => "ჩადგმა %s წარმატებით გამოირთო.",
			'admin:plugins:disable:no' => "ჩადგმა %s ვერ გამოირთო.",
			'admin:plugins:enable:yes' => "ჩადგმა %s წარმატებით ჩაირთო.",
			'admin:plugins:enable:no' => "ჩადგმა %s ვერ ჩაირთო.",
	
			'admin:statistics' => "სტატისტიკა",
			'admin:statistics:description' => "ეს არის თქვენი ვებ გვერდის სტატისტიკის მიმოხილვა. თუ უფრო დეტალური სტატისტიკა გჭირდებათ, ხელმისაწვდომია პროფესიული ადმინისტრირების ხელსაწყო.",
			'admin:statistics:opt:description' => "იხილეთ სტატისტიკა თქვენი ვებ გვერდის მომხმარებლების და ობიექტების შესახებ.",
			'admin:statistics:opt:linktext' => "სტატისტიკის ნახვა...",
			'admin:statistics:label:basic' => "ვებ გვერდის ძირითადი სტატისტიკა",
			'admin:statistics:label:numentities' => "ელემენტები ვებ გვერდზე",
			'admin:statistics:label:numusers' => "მომხმარებლების რაოდენობა",
			'admin:statistics:label:numonline' => "ხაზზე მყოფი მომხმარებლების რაოდენობა",
			'admin:statistics:label:onlineusers' => "ახლა ხაზზე მყოფი მომხმარებლები",
			'admin:statistics:label:version' => "Elgg ვერსია",
			'admin:statistics:label:version:release' => "რელიზი",
			'admin:statistics:label:version:version' => "ვერსია",
	
			'admin:user:label:search' => "მომხმარებლების მოძებნა:",
			'admin:user:label:seachbutton' => "ძებნა", 
	
			'admin:user:ban:no' => "შეუძლებელია მომხმარებლის დაბლოკვა",
			'admin:user:ban:yes' => "მომხმარებელი დაბლოკილია.",
			'admin:user:unban:no' => "შეუძლებელია მომხმარებლის განბლოკვა",
			'admin:user:unban:yes' => "მომხმარებელი განბლოკილია.",
			'admin:user:delete:no' => "შეუძლებელია მომხმარებლის წაშლა",
			'admin:user:delete:yes' => "მომხმარებელი წაშლილია",
	
			'admin:user:resetpassword:yes' => "პაროლი თავიდანაა დაყენებული, მომხმარებელი გაფრთხილებულია.",
			'admin:user:resetpassword:no' => "პაროლის თავიდან დაყენება ვერ განხორციალდა.",
	
			'admin:user:makeadmin:yes' => "მომხმარებელი ახლა ადმინისტრატორია.",
			'admin:user:makeadmin:no' => "ჩვენ ეს მომხმარებელი ვერ გავხადეთ ადმინისტრატორი.",
			
		/**
		 * User settings
		 */
			'usersettings:description' => "მომხმარებელთა პარამეტრების დაფა საშუალებას გაძლევთ მართოთ ყველა პირადი პარამეტრი, მომხმარებლის მართვით დაწყებული ჩადგმების პარამეტრებით დამთავრებული. გთხოვთ აიეჩიოთ პარამეტრი დასაწყებად.",
	
			'usersettings:statistics' => "თქვენი სტატისტიკა",
			'usersettings:statistics:opt:description' => "იხილეთ სტატისტიკა თქვენს გვერდზე მომხმარებლებისა და ობიექტების შესახებ.",
			'usersettings:statistics:opt:linktext' => "ანგარიშის სტატისტიკა",
	
			'usersettings:user' => "თქვენი პარამეტრები",
			'usersettings:user:opt:description' => "ეს საშუალებას გაძლევთ მართოთ მომხმარებლის პარამეტრები.",
			'usersettings:user:opt:linktext' => "შეცვალეთ თქვენი პარამეტრები",
	
			'usersettings:plugins' => "ხელსაწყოები",
			'usersettings:plugins:opt:description' => "გამართეთ თქვენი აქტიური ხელსაწყოების პარამეტრები.",
			'usersettings:plugins:opt:linktext' => "გამართეთ თქვენი ხელსაწყოები",
	
			'usersettings:plugins:description' => "ეს დაფა საშუალებას გაძლევთ მართოთ და გამართოთ პირადი პარამეტრები ადმინისტრატორის მიერ დაყენებული ხელსაწყოებისთვის.",
			'usersettings:statistics:label:numentities' => "თქვენი ელემენტები",
	
			'usersettings:statistics:yourdetails' => "თქვენი დეტალები",
			'usersettings:statistics:label:name' => "სრული სახელი",
			'usersettings:statistics:label:email' => "ელფოსტა",
			'usersettings:statistics:label:membersince' => "დარეგისტრირდით",
			'usersettings:statistics:label:lastlogin' => "უკანასკნელი შემოსვლა",
	
			
	
		/**
		 * Generic action words
		 */
	
			'save' => "შენახვა",
			'cancel' => "გაუქმება",
			'saving' => "ინახება ...",
			'update' => "განახლება",
			'edit' => "რედაქტირება",
			'delete' => "წაშლა",
			'load' => "ჩატვირთვა",
			'upload' => "ატვირთვა",
			'ban' => "ბლოკირება",
			'unban' => "განბლოკვა",
			'enable' => "ჩართვა",
			'disable' => "გამორთვა",
			'request' => "მოთხოვნა",
			'complete' => "დასრულება",
			'open' => 'გახსნა',
			'close' => 'დახურვა',
			'reply' => "პასუხი",
	
			'up' => 'ზემოთ',
			'down' => 'ქვემოთ',
			'top' => 'მაღლა',
			'bottom' => 'დაბლა',
	
			'invite' => "დაპატიჟება",
	
			'resetpassword' => "პაროლის თავიდან დაყენება",
			'makeadmin' => "ადმინისტრატორად გარდაქმნა",
	
			'option:yes' => "დიახ",
			'option:no' => "არა",
	
			'unknown' => 'უცნობი',
	
			'active' => 'აქტიური',
			'total' => 'ტოტალური',
	
			'learnmore' => "მეტის გასაგებად აქ დააწკაპეთ.",
	
			'content' => "შიგთავსი",
			'content:latest' => 'უკანასკნელი აქტივობა',
			'content:latest:blurb' => 'ალტერნატიულად, აქ დააწკაპეთ ვებ გვერდზე ბოლო ინფორმაციის სანახავად.',
	
			'link:text' => 'ბმულის ნახვა',
	
	
		/**
		 * Generic data words
		 */
	
			'title' => "სათაური",
			'description' => "აღწერა",
			'tags' => "ჭდეები",
			'spotlight' => "ხაზგასმული",
			'all' => "ყველაფერი",
	
			'by' => 'მიერ',
	
			'annotations' => "ანოტაციები",
			'relationships' => "კავშირები",
			'metadata' => "მეტამონაცემები",
	
		/**
		 * Input / output strings
		 */

			'deleteconfirm' => "დარწმუნებული ხართ რომ გსურთ ამ ელემენტის წაშლა?",
			'fileexists' => "ფაილი უკვე ატვირთულია. მის ჩასანაცვლებლად, მონიშნეთ იგი ქვემოთ:",
			
			
	    /**
         * System messages
         **/

			'systemmessages:dismiss' => "დააწკაპეთ უარსაყოფად",

	
		/**
		 * Import / export
		 */
			'importsuccess' => "მონაცემთა იმპორტი წარმატებულია",
			'importfail' => "OpenDD მონაცემთა იმპორტი ვერ განხორციალდა.",
	
		/**
		 * Time
		 */
	
			'friendlytime:justnow' => "ახლახანს",
			'friendlytime:minutes' => "%s წუთის წინ",
			'friendlytime:minutes:singular' => "ერთი წუთის წინ",
			'friendlytime:hours' => "%s საათის წინ",
			'friendlytime:hours:singular' => "ერთი საათის წინ",
			'friendlytime:days' => "%s დღის წინ",
			'friendlytime:days:singular' => "გუშინ",
	
		/**
		 * Installation and system settings
		 */
	
			'installation:error:htaccess' => "Elgg მოითხოვს რომ ფაილი სახელად .htaccess იყოს დაყენების ძირეულ დირექტორიაში. ჩვენ ვცადეთ მისი თქვენთვის შექმნა, მაგრამ Elgg-ს არ აქვს უფლება ჩაწეროს ამ დირექტორიაში. 

მისი შექმნა ადვილია. ქვემოთ მოცემული ტექსტის უჯრის შიგთავსის ასლი გააკეთეთ ტექსტურ რედაქტორში და შეინახეთ იგი როგორც .htaccess

",
			'installation:error:settings' => "Elgg-მ ვერ იპოვა პარამეტრების ფაილი. Elgg-ს პარამეტრების უმეტესობა თქვენს მიერ იქნება დამუშავებული, მაგრამ ჩვენ გვჭირდება მოგაწოდოთ მონაცემთა ბაზის დეტალები. ასე მოიქეცით:

1. სახელი გადაარქვით engine/settings.example.php-ს settings.php -ზე Elgg-ის თქვენს დაყენებაში.

2. გახსენით იგი ტექსტური რედაქტორით და ჩაწერეთ თქვენი MySQL მონაცემთა ბაზის დეტალები. თუ კი არ იცით ეს, მაშინ მიმართეთ თქვენს სისტემურ ადმინისტრატორს ან ტექნიკურ მხარდაჭერას დახმარებისთვის.

თქვენ ასევე შეგიძლიათ ქვემოთ ჩაწეროთ მონაცემთა ბაზის პარამეტრები და ჩვენ ვეცდებით ეს გავაკეთოთ თქვენთვის...",
	
			'installation:error:configuration' => "თუ უკვე მოაგვარეთ კონფიგურაციის საკითხები, დააწკაპეთ გადატვირთვას და კიდევ სცადეთ.",
	
			'installation' => "დაყენება",
			'installation:success' => "Elgg-ს მონაცემთა ბაზა წარმატებით დაყენდა.",
			'installation:configuration:success' => "თქვენი თავდაპირველი კონფიგურაციის პარამეტრები შენახულია. ახლა დაარეგისტრირეთ პირველი მომხმარებელი; ეს იქნება თქვენი პირველი სისტემური ადმინისტრატორი.",
	
			'installation:settings' => "სისტემური პარამეტრები",
			'installation:settings:description' => "ახლა, როდესაც Elgg მონაცემთა ბაზა წარმატებით დაყენდა, უნდა შეიყვანოთ ცოტაოდენ ინფორმაცია ვებ გვერდის სრულად გასაშვებად. ჩვენ ვცადეთ გამოგვეცნო, მაგრამ <b>თქვენ უნდა შეამოწმოთ ეს დეტალები.</b>",
	
			'installation:settings:dbwizard:prompt' => "ქვემოთ შეიყვანეთ თქვენი მონაცემთა ბაზის პარამეტრები და დააწკაპეთ შენახვას:",
			'installation:settings:dbwizard:label:user' => "მონაცემთა ბაზის მომხმარებელი",
			'installation:settings:dbwizard:label:pass' => "მონაცემთა ბაზის პაროლი",
			'installation:settings:dbwizard:label:dbname' => "Elgg მონაცემთა ბაზა",
			'installation:settings:dbwizard:label:host' => "მონაცემთა ბაზის ჰოსტი (როგორც წესი 'localhost')",
			'installation:settings:dbwizard:label:prefix' => "მონაცემთა ბაზის ცხრილის პრეფიქსი (როგორც წესი 'elgg')",
	
			'installation:settings:dbwizard:savefail' => "ჩვენ ვერ შევინახეთ ახალი settings.php. გთხოვთ შეინახეთ შემდეგი ფაილი როგორც engine/settings.php ტექნიკური რედაქტორის გამოყენებით.",
	
			'installation:sitename' => "ვებ გვერდის სახელი (მაგ \"ჩემი სოციალური ქსელის გვერდი\"):",
			'installation:sitedescription' => "თქვენი ვებ გვერდის მოკლე აღწეილობა (არასავალდებულო)",
			'installation:wwwroot' => "ვებ გვერდის მისამართი, მოაყოლეთ დამხურავი დახრილი ხაზი:",
			'installation:path' => "ვებ გვერდის ძირეული დირექტორიის სრული გეზი თქვენს დისკზე, მოაყოლეთ დამხურავი დახრილი ხაზი:",
			'installation:dataroot' => "ატვირთული ფაილების შესანახი დირექტორიის სრული გეზი, მოაყოლეთ დამხურავი დახრილი ხაზი:",
			'installation:dataroot:warning' => "ეს დირექტორია ხელით უნდა შექმნათ. იგი არ უნდა იყოს Elgg-ის დაყენების დირექტორიაში.",
			'installation:language' => "თქვენი ვებ გვერდის ნაგულისხმევი ენა:",
			'installation:debug' => "დამუშავების რეჟიმი აწვდის დამატებით ინფორმაციას, რომლის გამოყენებაც შეიძლება პრობლემების დიაგნოსტიკისთვის, თუმცა ეს შეანელებს თქვენს სისტემას, ამიტომ უნდა იქნას გამოყენებულო, მხოლოდ თუ პრობლემები გაქვთ:",
			'installation:debug:label' => "დამუშავების რეჟიმის ჩართვა",
			'installation:usage' => "ეს პარამეტრი Elgg-ს საშუალებას აძლევს გააგზავნოს მოხმარების სტატისტიკა ანონიმურად Curverider-სთან.",
			'installation:usage:label' => "მოხმარების სტატისტიკის ანონიმურად გაგზავნა",
			'installation:view' => "ჩაწერეთ ხედი, რომელიც ნაგულისხმევად აქნება გამოყენებული თქვენს ვებ გვერდზე ან დატოვეთ ეს გრაფა ცარიელი ნაგულისხმევი ხედისთვის (თუ ეჭვობთ, დატოვეთ ნაგულისხმევი):",

			'installation:siteemail' => "ვებ გვერდის ელფოსტის მისამართი (გამოიყენება როდესაც სისტემა აგზავნის წერილებს)",
	
			'installation:disableapi' => "RESTful API არის ფლექსიბური და მორგებადი ინტერფეისი, რომელიც პროგრამებს საშუალებას აძლევს გამოიყენონ მითითებული Elgg შესაძლებლობები შორიდან.",
			'installation:disableapi:label' => "RESTful API ჩართვა",

			'upgrading' => 'განახლება',
			'upgrade:db' => 'თქვენი მონაცემთა ბაზა განახლდა.',
			'upgrade:core' => 'თქვენი elgg დაყენება განახლდა',
	
		/**
		 * Welcome
		 */
	
			'welcome' => "მოგესალმებით %s",
			'welcome_message' => "კეთილი იყოს Elggის ეს დაყენება.",
	
		/**
		 * Emails
		 */
			'email:settings' => "ელფოსტის პარამეტრები",
			'email:address:label' => "თქვენი ელფოსტის მისამართი",
			
			'email:save:success' => "ახალი ელფოსტის მისამართი შენახულია, საჭიროა დადასტურება.",
			'email:save:fail' => "თქვენი ახალი ელფოსტის მისამართის შენახვა ვერ განხორციალდა.",
	
			'email:confirm:success' => "თქვენ დაადასტურეთ თქვენი ელფოსტის მისამართი!",
			'email:confirm:fail' => "თქვენი ელფოსტის მისამართის დადასტურება ვერ განხორციალდა...",
	
			'friend:newfriend:subject' => "%s დაგიმეგობრდათ!",
			'friend:newfriend:body' => "%s დაგიმეგობრდათ!

მათი პროფილის სანახავად აქ დააწკაპეთ:

	%s

ამ წერილზე პასუხის გაცემა არ შეგიძლიათ.",
	
	
	
			'email:resetpassword:subject' => "პაროლი თავიდანაა დაყენებული!",
			'email:resetpassword:body' => "სალამი %s,
			
თქვენი პაროლი განულდა და ახლა არის: %s",
	
	
			'email:resetreq:subject' => "ახალი პაროლის მოთხოვნა.",
			'email:resetreq:body' => "სალამი %s,
			
ვიღაცავ (%s IP მისამართიდან) მოითხოვა მისი ანგარიშისთვის ახალი პაროლი.

თუ ეს თქვენ მოითხოვეთ დააწკაპეთ ქვედა ბმულს, სხვა შემთხვევაში იგნორირება გაუკეთეთ ამ წერილს.

%s
",

	
		/**
		 * XML-RPC
		 */
			'xmlrpc:noinputdata'	=>	"შესაყვანი მონაცემები არაა",
	
		/**
		 * Comments
		 */
	
			'comments:count' => "%s კომენტარი",
			
			'riveraction:annotation:generic_comment' => '%s-მ გააკეთა %s-ზე კომენტარი',
	
			'generic_comments:add' => "კომენტარის დამატება",
			'generic_comments:text' => "კომენტარი",
			'generic_comment:posted' => "თქვენი კომენტარი წარმატებით დაემატა.",
			'generic_comment:deleted' => "თქვენი კომენტარი წარმატებით წაიშალა.",
			'generic_comment:blank' => "ბოდიში; შენახვამდე რაღაც უნდა ჩაწეროთ კომენტარში.",
			'generic_comment:notfound' => "ბოდიში; მითითებული ელემენტი ვერ ვიპოვეთ.",
			'generic_comment:notdeleted' => "ბოდიში; ვერ წავშალეთ ეს კომენტარი.",
			'generic_comment:failure' => "თქვენი კომენტარის დამატებისას მოულოდნელი შეცდომა მოხდა. გთხოვთ კიდევ სცადეთ.",
	
			'generic_comment:email:subject' => 'თქვენ ახალი კომენტარი გაქვთ!',
			'generic_comment:email:body' => "\"%s\"-ზე ახალი კომენტარი გაქვთ %s-სგან:

			
%s


პასუხის გასაცემად ან თავდაპირველი შეყობინების სანახავად აქ დააწკაპეთ:

	%s

%sს პროფილის სანახავად, აქ დააწკაპეთ:

	%s

ამ წერილზე პასუხის გაცემა არ შეგიძლიათ.",
	
		/**
		 * Entities
		 */
			'entity:default:strapline' => 'შექმნილია %s %s მიერ',
			'entity:default:missingsupport:popup' => 'ეს ელემენტი სწორად ვერ აისახება. შესაძლოა მას სჭირდება ჩანართი რომელიც აღარ არსებობს.',
	
			'entity:delete:success' => '%s ელემენტი წაშლილია',
			'entity:delete:fail' => '%s ელემენტი ვერ წაიშალა',
	
	
		/**
		 * Action gatekeeper
		 */
			'actiongatekeeper:missingfields' => 'ფორმა არაა ნიშანი ან __ts ველები',
			'actiongatekeeper:tokeninvalid' => "ჩვენ მოგვივიდა შეცდომა (ნიშანი არ ემთხვევა). ეს შესაძლოა ნიშნავს, რომ თქვენს მიერ გამოყენებულ გვერდს ვადა გაუვიდა. გთხოვთ კიდევ სცადეთ.",
			'actiongatekeeper:timeerror' => 'თქვენს მიერ გამოყენებულ გვერდს ვადა გაუვიდა. გთხოვთ განაახლოთ და კიდევ სცადეთ.',
			'actiongatekeeper:pluginprevents' => 'გაფართოვებამ არ მისცა ფორმას საშუალება გაგზავნილიყო.',
	
		/**
		 * Word blacklists
		 */
			'word:blacklist' => 'და, მაშინ, მაგრამ, ის, მისი, იგი, ერთი, არა, ასევე, შესახებ, ახლა, მაშასადამე, ჯერ, როგორც, სხვაგვარად, ვინაიდან, უკუ, უფრო, შედეგად, ამის გარდა, მიუხედავად, მაგივრად, ჯერ კიდევ, შესაბამისად, ეს, ჩანს, რა, ვინ, ვისი, ვისიც, რომელიმე',
	
		/**
		 * Languages according to ISO 639-1
		 */
			"aa" => "აფარი",
			"ab" => "აფხაზური",
			"af" => "აფრიკული",
			"am" => "ამჰარიკი",
			"ar" => "არაბული",
			"as" => "ასამცური",
			"ay" => "აიმარა",
			"az" => "აზერბაიჯანული",
			"ba" => "ბაშკირული",
			"be" => "ბელორუსული",
			"bg" => "ბულგარული",
			"bh" => "ბიჰარი",
			"bi" => "ბისლამა",
			"bn" => "ბენგალური",
			"bo" => "ტიბეტური",
			"br" => "ბრეტონული",
			"ca" => "კატალანური",
			"co" => "კორსიკული",
			"cs" => "ჩეხური",
			"cy" => "ველსური",
			"da" => "დანიური",
			"de" => "გერმანული",
			"dz" => "ბუტანური",
			"el" => "ბერძნული",
			"en" => "ინგლისური",
			"eo" => "ესპერანტო",
			"es" => "ესპანური",
			"et" => "ესტონური",
			"eu" => "ბასკური",
			"fa" => "სპარსული",
			"fi" => "ფინური",
			"fj" => "ფიჯი",
			"fo" => "ფარერული",
			"fr" => "ფრანგული",
			"fy" => "ფრისიული",
			"ga" => "ირლანდიური",
			"gd" => "შოტლანდიური",
			"gl" => "გალიციური",
			"gn" => "გუარანი",
			"gu" => "გუჯარატი",
			"he" => "ივრითი",
			"ha" => "ჰაუსა",
			"hi" => "ჰინდი",
			"hr" => "ხორვატიული",
			"hu" => "უნგრული",
			"hy" => "სომხური",
			"ia" => "ინტერლინგვა",
			"id" => "ინდონეზიური",
			"ie" => "ინტერლინგვა",
			"ik" => "ინუპიაკი",
			//"in" => "Indonesian",
			"is" => "ისლანდიური",
			"it" => "იტალიური",
			"iu" => "ინუკტიტუტი",
			//"iw" => "Hebrew (obsolete)",
			"ja" => "იაპონური",
			//"ji" => "Yiddish (obsolete)",
			"jw" => "ჯავური",
			"ka" => "ქართული",
			"kk" => "კაზა",
			"kl" => "გრენლანდიური",
			"km" => "კამბოჯური",
			"kn" => "კანადა",
			"ko" => "კორეული",
			"ks" => "კაშმირული",
			"ku" => "ქურთული",
			"ky" => "ყირგიზული",
			"la" => "ლათინური",
			"ln" => "ლინგალა",
			"lo" => "ლაოსური",
			"lt" => "ლიტვური",
			"lv" => "ლატვიური",
			"mg" => "მალაგასური",
			"mi" => "მაორი",
			"mk" => "მაკედონური",
			"ml" => "მალაიური",
			"mn" => "მონღოლური",
			"mo" => "მოლდოვური",
			"mr" => "მარათი",
			"ms" => "მალაი",
			"mt" => "მალტური",
			"my" => "ბირმული",
			"na" => "ნაურუ",
			"ne" => "ნეპალური",
			"nl" => "ნინდერლანდული",
			"no" => "ნორვეგიული",
			"oc" => "ოკიტანი",
			"om" => "ორომო",
			"or" => "ორია",
			"pa" => "პუნჯაბი",
			"pl" => "პოლონური",
			"ps" => "პუშტუნური",
			"pt" => "პორტუგალური",
			"qu" => "კეჩუა",
			"rm" => "რეტო-რომანული",
			"rn" => "კირუნდი",
			"ro" => "რუმინული",
			"ru" => "რუსული",
			"rw" => "კინარვანდა",
			"sa" => "სანსკრიტი",
			"sd" => "სინდჰი",
			"sg" => "სანგრო",
			"sh" => "სერბულ-ხორვატიული",
			"si" => "სინგჰალესი",
			"sk" => "სლოვაკური",
			"sl" => "სლოვენური",
			"sm" => "სამოური",
			"sn" => "შონა",
			"so" => "სომალური",
			"sq" => "ალბანური",
			"sr" => "სერბული",
			"ss" => "სისვატი",
			"st" => "სესოთო",
			"su" => "სუნდანესური",
			"sv" => "შვედური",
			"sw" => "სუაჰილი",
			"ta" => "ტამილი",
			"te" => "ტეგულუ",
			"tg" => "ტაჯიკური",
			"th" => "ტაი",
			"ti" => "ტიგრინა",
			"tk" => "თურქმენული",
			"tl" => "ტაგალოკი",
			"tn" => "სეცვანა",
			"to" => "ტონგა",
			"tr" => "თურქული",
			"ts" => "ცონგა",
			"tt" => "თათრული",
			"tw" => "თვი",
			"ug" => "უიგურული",
			"uk" => "უკრაინული",
			"ur" => "ურდუ",
			"uz" => "უზბეკური",
			"vi" => "ვიეტნამური",
			"vo" => "ვოლაპუკი",
			"wo" => "ვოლოფი",
			"xh" => "ხოსა",
			//"y" => "Yiddish",
			"yi" => "იდიში",
			"yo" => "იორუბა",
			"za" => "ზუანგი",
			"zh" => "ჩინური",
			"zu" => "ზულუ",
	);
	
	add_translation("ka",$georgian);

?>
