<?php
	$allow_ext = $vars['entity']->allow_ext;
	if (!$allow_ext) $allow_ext = '*';
?>	
<p>
	<?php echo elgg_echo('file:allowextension'); ?>
	
	<?php
		echo elgg_view('input/text', array(
			'internalname' => 'params[allow_ext]',
			'value' => $allow_ext
		));
	?><br />
	Each extension is separated by comma(,).Example: .jsp,.php,.mp3,.wmv<br />
	Use * for all extensions.
</p>