<?php

	/**
	 * Elgg add_to_any plugin
	 * 
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette fabrice.collette@free.fr
	 * @copyright Fabrice Collette
	 * @link http://www.meleze-online.net
	 */

		
		function add_to_any_init() {
			extend_view('css','add_to_any/css');
      extend_view('owner_block/extend','add_to_any/extend',600);
			global $CONFIG;
			// Load the language file
			register_translations($CONFIG->pluginspath . "add_to_any/languages/");
		}

		register_elgg_event_handler('init','system','add_to_any_init');
				
		
?>