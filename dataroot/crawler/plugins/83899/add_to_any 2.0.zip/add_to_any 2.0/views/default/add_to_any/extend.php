<?php

	/**
	 * Elgg add_to_any plugin
	 * 
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette fabrice.collette@free.fr
	 * @copyright Fabrice Collette
	 * @link http://www.meleze-online.net
	 */

	 
	    $lang = get_language();
	    $label = elgg_echo('add_to_any:owner_block_menu:add_to_any');	
	    $contents .= "<div id=\"owner_block_add_to_any\"><a class=\"a2a_dd\" href=\"http://www.addtoany.com/share_save\">{$label}</a><script type=\"text/javascript\">a2a_linkname=document.title;a2a_linkurl=location.href;a2a_onclick=1;</script><script type=\"text/javascript\" src=\"http://static.addtoany.com/menu/locale/{$lang}.js\" charset=\"utf-8\"></script><script type=\"text/javascript\" src=\"http://static.addtoany.com/menu/page.js\"></script></div>";
          echo $contents;
    
?>