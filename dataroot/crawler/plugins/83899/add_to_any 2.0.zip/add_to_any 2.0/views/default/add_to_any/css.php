<?php
/**
	 * Elgg add_to_any plugin
	 * 
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette fabrice.collette@free.fr
	 * @copyright Fabrice Collette
	 * @link http://www.meleze-online.net
	 */

?>

#owner_block_add_to_any {
	padding:5px 0 5px 0;
	border-bottom:1px solid #cccccc;
}

#owner_block_add_to_any a {
	font-size: 90%;
	color:#999999;
	padding:0 0 4px 20px;
	background: url(<?php echo $vars['url']; ?>mod/add_to_any/graphics/add_to_any.png) no-repeat left top;
}

#owner_block_add_to_any a:hover {
	color: #0054a7;
}