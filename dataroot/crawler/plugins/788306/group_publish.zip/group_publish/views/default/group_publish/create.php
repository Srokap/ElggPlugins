<?php

$group_guid = get_input('group_guid');
if ($group_guid == 0){
			
?>
    
<div class="contentWrapper" id="notpublished">
    <div id="publishinfo">
        <?php echo elgg_echo('group_publish:infocreate');?>
    </div>
</div>

<?php } ?>

