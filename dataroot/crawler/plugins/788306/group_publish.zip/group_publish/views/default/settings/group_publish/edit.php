<?php

	$admin_url = $CONFIG->wwwroot . 'pg/group_publish/admin';
	
?>

<div class="contentWrapper">
	<a href="<?php echo $admin_url; ?>"><?php echo elgg_echo('group_publish:gotoadmin') ?></a>
</div>
