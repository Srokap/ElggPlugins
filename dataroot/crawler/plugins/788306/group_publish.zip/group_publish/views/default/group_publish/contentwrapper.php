<?php
	echo $vars['body'];	
?>