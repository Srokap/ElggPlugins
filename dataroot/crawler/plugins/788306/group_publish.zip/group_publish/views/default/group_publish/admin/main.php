<?php

global $CONFIG;

$tab = $vars['tab'];

$publishselect = '';
$allselect = ''; 
$settingsselect = '';

switch($tab) {
	case 'publish':
		$publishselect = 'class="selected"';
		break;
	case 'all':
		$allselect = 'class="selected"';
		break;
	case 'settings':
		$settingsselect = 'class="selected"';
		break;
}

?>
<div class="contentWrapper">
	<div id="elgg_horizontal_tabbed_nav">
		<ul>
			<li <?php echo $publishselect; ?>><a href="<?php echo $CONFIG->wwwroot . 'pg/group_publish/admin/?tab=publish'; ?>"><?php echo elgg_echo('group_publish:unpublished'); ?></a></li>
			<li <?php echo $allselect; ?>><a href="<?php echo $CONFIG->wwwroot . 'pg/group_publish/admin/?tab=all'; ?>"><?php echo elgg_echo('group_publish:all'); ?></a></li>
			<li <?php echo $settingsselect; ?>><a href="<?php echo $CONFIG->wwwroot . 'pg/group_publish/admin/?tab=settings'; ?>"><?php echo elgg_echo('group_publish:settings'); ?></a></li>
		</ul>
	</div>
	<?php
	switch($tab) {
		case 'publish':
			echo elgg_view("group_publish/admin/publish");
			break;
		case 'all':
			echo elgg_view("group_publish/admin/all");
			break;
		case 'settings':
			echo elgg_view("group_publish/admin/settings");
			break;
	}
	?>
</div>
