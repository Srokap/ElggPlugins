<?php
	
$action = $vars['url'] . 'action/group_publish/edit';

$newgroup_info = get_plugin_setting('newgroup_info',	'group_publish'); 

$form_body .= '<div class="edit">' . elgg_echo('group_publish:param_label');

$form_body .= elgg_view('input/pulldown', array('internalname' => 'params[newgroup_info]','options_values' => array('no' => elgg_echo('option:no'), 'yes' => elgg_echo('option:yes')),'value' => $newgroup_info)) . '</div>';

$form_body .= '<p><a class="collapsibleboxlink">' . elgg_echo('group_publish:showtext') . '</a></p>';
$form_body .= '<div class="collapsible_box">';
$form_body .= elgg_view('group_publish/create');
$form_body .= '</div>';

$form_body .= elgg_view('input/submit', array('value' => elgg_echo("save")));
echo elgg_view('input/form', array('action' => $action, 'body' => $form_body));

?>