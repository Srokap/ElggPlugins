<?php
		
admin_gatekeeper();
set_context('admin');

$owner = get_entity($entity->owner_guid);
$group = $vars['entity'];
											
$options = array(
	'types' => 'group', 
	'metadata_name' => 'notpublished',
	'limit' => 1,
	'view_type_toggle' => FALSE, 
	'pagination' => TRUE,
	'full_view' => TRUE
);

$content = elgg_view_title($title);

$count = elgg_get_entities_from_metadata($options);	
if ($count){
	$content .= elgg_list_entities_from_metadata($options);
} else {
	$content .= '<div class="contentWrapper">' . elgg_echo('group_publish:nolist') . '</div>';
}

echo $content;
		
?>