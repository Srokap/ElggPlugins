<?php
 
$group = $vars['entity'];
$accepted = ($group->accepted != "no");

$ts = time();
$token = generate_action_token($ts);
$security = "?__elgg_token={$token}&__elgg_ts={$ts}";

$friendlytime = elgg_view_friendly_time($vars['entity']->time_created);
			
if (isadminloggedin() && !$accepted){ ?>

	<div class="contentWrapper" id="notpublished">
        <div id="publishinfo">
            <?php echo elgg_echo('group_publish:admininfo') . $friendlytime; ?>
        </div>
        <div class="elggzone_line"></div>
		<div>
			<a href="<?php echo $CONFIG->wwwroot;?>action/group_publish/accept<?php echo $security;?>&group_guid=<?php echo $vars['entity']->getGUID();?>"><?php echo elgg_echo('group_publish:publish'); ?></a> | 
            <a href="<?php echo $CONFIG->wwwroot;?>action/group_publish/delete<?php echo $security;?>&group_guid=<?php echo $vars['entity']->getGUID();?>"><?php echo elgg_echo('group_publish:delete_group'); ?></a>
		</div>
		<div class="clearfloat"></div>
	</div>
                        
<?php } elseif (!$accepted){ ?>

	<div class="contentWrapper" id="notpublished">
    	<div id="publishinfo">
			<?php echo elgg_echo('group_publish:notpublished');?>
        </div>
        <div class="elggzone_line"></div>
        <div>
        	<a href="<?php echo $vars['url']; ?>pg/groups/edit/<?php echo $vars['entity']->getGUID(); ?>"><?php echo elgg_echo("edit"); ?></a> |
            <a href="<?php echo $CONFIG->wwwroot;?>action/group_publish/accept<?php echo $security;?>&group_guid=<?php echo $vars['entity']->getGUID();?>"><?php echo elgg_echo('group_publish:publish'); ?></a> | 
            <a href="<?php echo $CONFIG->wwwroot;?>action/group_publish/delete<?php echo $security;?>&group_guid=<?php echo $vars['entity']->getGUID();?>"><?php echo elgg_echo('group_publish:delete_group'); ?></a>
		</div>
	</div>
    
<?php } ?>
