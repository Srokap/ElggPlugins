<?php
	
echo elgg_view("group_publish/forms/settings");

?>
