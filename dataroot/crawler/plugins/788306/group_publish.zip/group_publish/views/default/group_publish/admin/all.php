<?php

admin_gatekeeper();
set_context('admin');

$owner = get_entity($entity->owner_guid);
$group = $vars['entity'];
											
$options = array(
	'types' => 'group', 
	'limit' => 10,
	'view_type_toggle' => FALSE, 
	'pagination' => TRUE,
	'full_view' => FALSE,
);

$content = elgg_view_title($title);

if ($options){
	$content .= elgg_list_entities_from_metadata($options);
} else {
	$content .= '<div class="contentWrapper">' . elgg_echo('group_publish:nolist') . '</div>';
}

echo $content;
		
?>

