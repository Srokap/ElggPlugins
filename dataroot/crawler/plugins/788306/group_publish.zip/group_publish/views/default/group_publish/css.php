/* ***************************************
	SETTINGS
*****************************************/
div.edit{
    margin-top:10px;
    margin-bottom:10px;
    padding:0;
}
.edit .input_pulldown{
    padding: 0;
    margin: 0 0 0 10px;
    vertical-align: bottom;
    position: relative;
    *overflow: hidden;
}
#notpublished{
	background:#EAF0F6;
	border: #C4D5E6 1px solid;
    padding:10px;
    margin-bottom:15px;
}
#publishinfo{
	font-family:Arial, Helvetica, sans-serif;
	margin-bottom:10px;
}
