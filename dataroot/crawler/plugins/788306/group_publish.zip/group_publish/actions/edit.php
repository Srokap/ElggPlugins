<?php

global $CONFIG;
	
admin_gatekeeper();
action_gatekeeper();

	// Params array - settings
	$params = get_input('params', array());
	foreach($params as $name => $value){
		set_plugin_setting($name, $value, 'group_publish');	
	}	

if ($error) {
	register_error(elgg_echo('admin:configuration:fail'));
	forward(REFERER);
} else {
	system_message(elgg_echo('admin:configuration:success'));
	forward(REFERER);
}

?>
