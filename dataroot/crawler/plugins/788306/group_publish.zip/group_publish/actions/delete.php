<?php

global $CONFIG;
//admin_gatekeeper();
$group_guid = get_input('group_guid');
$group = get_entity($group_guid);
$group->delete();

if ($error) {
	register_error(elgg_echo('group:notdeleted'));
	forward();
}

// we had success so forward and display success message
system_message(elgg_echo('group:deleted'));
$url_name = $_SESSION['user']->username;
forward("{$vars['url']}pg/groups/member/{$url_name}");

?>
