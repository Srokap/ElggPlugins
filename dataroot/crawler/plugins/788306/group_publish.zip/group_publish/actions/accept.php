<?php

global $CONFIG;

$group_guid = get_input('group_guid');
$group = get_entity($group_guid);

$group->accepted = 'yes';
$group->access_id = ACCESS_PUBLIC;
$group->save();

if ($error) {
	register_error(elgg_echo('group_publish:failure'));
	forward();
}

$owner = $group->getOwnerEntity();
$user = get_user_by_username($owner->username);

$oldmetadata = get_metadata_byname($group->guid, 'notpublished');
delete_metadata($oldmetadata->id);

remove_from_river_by_object($group->guid);
add_to_river('river/object/create', 'create', $user->guid, $group->guid);
		
// we had success so forward and display success message
system_message(elgg_echo('group_publish:success'));
forward(REFERER);


?>
