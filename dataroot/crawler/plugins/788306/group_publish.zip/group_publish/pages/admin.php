<?php
/**
 * Group Publish Admin Page
 */
 
include_once dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php";

admin_gatekeeper();
set_context('admin');

$tab = get_input('tab', 'publish');

$body = elgg_view_title(elgg_echo('group_publish:admin'));
$body .= elgg_view("group_publish/admin/main", array('tab' => $tab));

page_draw(elgg_echo('group_publish:administration'), elgg_view_layout("two_column_left_sidebar", '', $body));
