<?php

$danish = array(

	'groups:river:create' 			=> '%s har oprettet (ikke offentliggjort) gruppen',
	
	'group_publish:admin' 			=> 'Gruppe administration',
	'group_publish:admininfo'		=> 'Denne gruppe er endnu ikke offentliggjort af ejeren. Gruppen blev oprettet ',
	'group_publish:all'				=> 'Alle grupper',
	'group_publish:delete_group' 	=> 'Slet gruppen',
	'group_publish:failure'			=> 'Gruppen kunne ikke offentliggøres',
	'group_publish:gotoadmin'		=> 'Gå til administration',
	'group_publish:infocreate'  	=> 'Velkommen til oprettelse af grupper. Når du har udfyldt formularen herunder med dine informationer, klikker du Gem.<p>Gruppen vil så blive oprettet, men vil ikke være synlig for andre end dig selv. Når du senere har tjekket om opsætningen passer dig, kan du vælge at offentliggøre gruppen.</p>',
	'group_publish:nolist' 			=> 'Ingen grupper fundet',
	'group_publish:notpublished' 	=> 'Du har nu oprettet din gruppe.<p>I øjeblikket er gruppen kun synlig for dig. Når du er tilfreds med din opsætning - billede, beskrivelse og andre oplysninger, skal du klikke på Udgiv for at gøre gruppen synlig for andre.</p><p>Bemærk: du kan <b>ikke</b> fortryde, når du først har valgt at offentliggøre gruppen, men selvfølgelig kan du altid redigere din gruppes indhold og opsætning.</p>',
	'group_publish:param_label'		=> 'Vis info tekst på siden Opret ny gruppe',
	'group_publish:publish' 		=> 'Offentliggør',
	'group_publish:river:create' 	=> '%s har oprettet gruppen',
	'group_publish:settings'		=> 'Indstillinger',
	'group_publish:showtext'		=> 'Se teksten',
	'group_publish:success'			=> 'Din gruppe er nu synlig for andre brugere',
	'group_publish:unpublished' 	=> 'Ikke offentligjort',
	
);

add_translation("da",$danish);

?>