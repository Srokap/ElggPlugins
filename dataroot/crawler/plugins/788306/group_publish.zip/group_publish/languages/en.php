<?php

$english = array(

	'groups:river:create' 			=> '%s has created (not published) the group',
	
	'group_publish:admin' 			=> 'Group Administration',
	'group_publish:admininfo'		=> 'This group is not yet published by the owner. The group was created ',
	'group_publish:all'				=> 'All groups',
	'group_publish:delete_group'	=> 'Delete group',
	'group_publish:failure'			=> 'The group could not be published',
	'group_publish:gotoadmin'		=> 'Go to administration',
	'group_publish:infocreate'  	=> 'Welcome to create group. Once you have filled out the form below with your information, click Save.<p>The group will then be created, but will not be visible to anyone but you. Later, when you have checked the setup, you can choose to publish your group.</p>',
	'group_publish:nolist' 			=> 'No groups found',
	'group_publish:notpublished'	=> 'You\'ve created your group.<p>Currently the group is only visible to you. When you\'re happy with your setup - picture, description and other information, click Publish to make the group visible to others.</p><p>Note: <b>you can not undo</b> once you have chosen to publish the group, but of course you can always edit your group\'s content and configuration.</p>',
	'group_publish:param_label'		=> 'Show info text on the page Create new group',
	'group_publish:publish' 		=> 'Publish',
	'group_publish:river:create' 	=> '%s has created the group',
	'group_publish:settings'		=> 'Settings',
	'group_publish:showtext'		=> 'See text',
	'group_publish:success'			=> 'Your group is now visible to other users',
	'group_publish:unpublished' 	=> 'Unpublished',	
			
);

add_translation("en", $english);
