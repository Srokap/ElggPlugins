<?php
/**
 *  Copyright (C) 2011-2012 Quanbit Software S.A.
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 */

/**
 * Elgg PHPUnit tests plugin language pack
 */

$english = array(

			//Settings section titles
				'QBElggTestsForPHPUnit:section:site' =>'Test Site',
				'QBElggTestsForPHPUnit:section:admin' => 'Admin Test User',
				'QBElggTestsForPHPUnit:section:user' => 'Normal Test User',
				'QBElggTestsForPHPUnit:section:private' => 'Private',
				'QBElggTestsForPHPUnit:section:metatests' => 'Metatests',		
			
			//Action button label				
				'QBElggTestsForPHPUnit:button_label:install' => 'Install Test Environment',
			
			//Errors when reading/writing config file
				'QBElggTestsForPHPUnit:error:reading_template' => 'Error reading the test config file template',
				'QBElggTestsForPHPUnit:error:write_config' => 'Error writing the test config file',

			//Settings form labels
				//Test site
				'QBElggTestsForPHPUnit:label:site:dbhost' => '1) The test DB host',
				'QBElggTestsForPHPUnit:label:site:dbname' => '2) The test DB name',
				'QBElggTestsForPHPUnit:label:site:dbuser' => '3) The test DB username', 
 				'QBElggTestsForPHPUnit:label:site:dbpass' => '4) The test DB password',
				'QBElggTestsForPHPUnit:label:site:dbprefix' => '5) The test DB table prefix',
				'QBElggTestsForPHPUnit:label:site:siteemail' => '6) The test site email address (used when sending system emails)',
				'QBElggTestsForPHPUnit:label:site:sitename' => '7) The test site name',
	 			'QBElggTestsForPHPUnit:label:site:wwwroot' =>  '8) The test site URL',
	 			'QBElggTestsForPHPUnit:label:site:dataroot' => '9) The full path of the test data directory',

				//Test Admin User
				'QBElggTestsForPHPUnit:label:admin:displayname' => '1) Display name',
 				'QBElggTestsForPHPUnit:label:admin:username' => '2) Username',
 				'QBElggTestsForPHPUnit:label:admin:password' => '3) Password',
 				'QBElggTestsForPHPUnit:label:admin:email' => '4) e-mail',
				
				//Test Standard User
				'QBElggTestsForPHPUnit:label:user:displayname' => '1) Display name:',
 				'QBElggTestsForPHPUnit:label:user:username' => '2) Username:',
 				'QBElggTestsForPHPUnit:label:user:password' => '3) Password:',
 				'QBElggTestsForPHPUnit:label:user:email' => '4) e-mail:',

 				//Private settings
				'QBElggTestsForPHPUnit:label:private:realdataroot' => 'Current data root:',
				
				//Metatests 
				'QBElggTestsForPHPUnit:label:metatests:elgg_modified_tables' => '1) Tables that get modified by the elgg engine when starting. Different elgg versions modify different tables:'
				);

add_translation("en", $english);