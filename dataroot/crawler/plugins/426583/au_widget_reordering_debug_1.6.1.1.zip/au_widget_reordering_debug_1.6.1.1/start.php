<?php

/**
 * au_widget_reordering_debug plugin start file
 *
 * @author Brian Jorgensen (brianj@athabascau.ca)
 * @copyright 2010 Brian Jorgensen
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
  */


register_elgg_event_handler('init', 'system', 'au_widget_reordering_debug_init');

/**
 * standard init function; extend css view
 */
function au_widget_reordering_debug_init() {
    	
    // extend css
    extend_view('css', 'au_widget_reordering_debug/au_widget_reordering_debug_css');

}