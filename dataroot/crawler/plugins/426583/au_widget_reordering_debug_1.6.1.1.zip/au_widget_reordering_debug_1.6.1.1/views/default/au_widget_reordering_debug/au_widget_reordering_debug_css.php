<?php
/**
 * css file to display widget reordering textareas;
 * 
 * has extra ids for custom_index_widget reset zones button textareas
 * 
 * uses !important to override inline styles
 * 
 * @author Brian Jorgensen (brianj@athabascau.ca)
 * @copyright 2010 Brian Jorgensen
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
  */

?>

#debugField1 {
	display:block !important;
}

#debugField2 {
	display:block !important;
}

#debugField3 {
	display:block !important;
}

/* extra ids for custom_index_widgets reset textareas */
#debugField1b {
	display:block !important;
}

#debugField2b {
	display:block !important;
}

#debugField3b {
	display:block !important;
}