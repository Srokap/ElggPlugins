<?php

	/**
	 * Elgg chat plugin (based on phpfreechat 1.2)
	 * 
	 * @package ElggChat
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Felix Stahlberg <fstahlberg@googlemail.com>
	 * @link http://www.dorfdesign.pytalhost.de/scripts/elggchat_en.php
	 * @link http://www.phpfreechat.net/
	 */

	require_once dirname(__FILE__)."/src/phpfreechat.class.php";
	
	$params = array();
	$params["title"] = "Elgg - Chat";
	$params["nick"] = "nobody";  // setup the intitial nickname
	$params["isadmin"] = false; // for debug set to true 
	$params["serverid"] = 'phpfreechat'; // calculate a unique id for this chat
	$params["debug"] = false;

	// Load Elgg engine
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	$params["nick"] = $_SESSION['user']->username;
	
	$chat = new phpFreeChat( $params );

	if ($_REQUEST['pfc_ajax'] != 1) {
		
		$body =  $chat->printChat(true);
	
		$body = elgg_view_layout('one_column', $body);
		page_draw("Elgg - Chat",$body);	
	}
?>