<?php

	/**
	 * Elgg chat plugin (based on phpfreechat 1.2)
	 * 
	 * @package ElggChat
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Felix Stahlberg <fstahlberg@googlemail.com>
	 * @link http://www.dorfdesign.pytalhost.de/scripts/elggchat_en.php
	 * @link http://www.phpfreechat.net/
	 */

	/**
	 * Chat initialisation
	 *
	 * These parameters are required for the event API, but we won't use them:
	 * 
	 * @param unknown_type $event
	 * @param unknown_type $object_type
	 * @param unknown_type $object
	 */

		function chat_init() {
			
			// Load system configuration
				global $CONFIG;
			// Set up menu for logged in users
				if (isloggedin()) {
					add_menu(elgg_echo('chat'), $CONFIG->wwwroot . "pg/chat/");
				}
			// Register a page handler, so we can have nice URLs
				register_page_handler('chat','chat_page_handler');
		}
		
	/**
	 * chat page handler
	 *
	 * @param array $page From the page_handler function
	 * @return true|false Depending on success
	 */
	
		function chat_page_handler($page) {
			if (isloggedin()) {
				@include(dirname(__FILE__) . "/index.php");
				return true;
			}
			
			return false;
			
		}

	// Make sure the blog initialisation function is called on initialisation
		register_elgg_event_handler('init', 'system', 'chat_init');
?>