<?php
	/**
	 * @file automatic_doc_for_doxygen.php
	 * @brief It has information for doxygen
	 */

	/**
	 * @mainpage rate_entities
	 * 
	 * The rate entities plugins provides a view that can be used to rate any elgg entity.
	 * You just have to call the view passing the entity in the $vars array named "entity".<br />
	 * 
	 * If you don't know to do it, don't panic, there is a way:
	 * 
	 * Go in the file: "rate_entities/views/default/object/demo_rate.php" and see how to use the rate_entities inputs views so 
	 * try to use the view for the entity that you want and include the rate system to it.
	 * <br />
	 * <br />
	 * 
	 * <b>Author: </b>José Gomes; email: juniordesiron@gmail.com
	 * <br />
	 * <b>Elgg Version: </b>1.7
	 * <br />
	 * <b>Published: </b>18/07/2010
	 * <br />
	 * <b>Last update: </b>13/01/2011
	 * <br />
	 * <b>Functionalities: </b><br />
	 * (version 1.0.0)<br />
	 * 1 - Provides a radio input view for rating.<br />
	 * 2 - Include the rate system for groups of plugin "groups"<br />
	 * 3 - Include the rate system for topics, of groups, of plugin "groups"<br />
	 * (version 1.1.1)<br />
	 * 4 - Provides a ajax input for rating.<br />
	 * (version 1.4.2)<br />
	 * 5 - Added rating system for user profile<br />
	 * 6 - Added rating system for blogs<br />
	 * 7 - Added rating system for tidypics images (but you have change the settings of tidypics administration submenu)<br />
	 * (version 1.4.5)<br />
	 * 8 - The cancel button will be displayed only if you had rated before<br />
	 * 9 - If you rated an entity, the rate input is ajax and you can reset your rate than you will see the "view_entity_rate" view and the ajax input view<br />  
	 * 10 - Made compatible with elgg 1.7.3<br />
	 * (version 2.0.0)<br />
	 * 11- The function gatekeeper() was replaced for a logic into the views: "rate_entities/input/ajax_input" and "rate_entities/input/radio_input"<br />
	 * 12- A small detail with the stars was corrected:<br />
	 *   If the decimal part of the rate is less than 0.5 so the decimal part will be removed<br />
	 *   If the decimal part is more than 0.8 than the rate will be rounded up<br />
	 *   If the decimal part is more equal to 0.5 and less than 0.8 than the half star will be used<br />
	 * 13- Users can not anymore evaluate their own profile<br />
	 * 14- Users can not anymore evaluate entities made by themselves
	 * 15- The view "rate_entities/input/default_input" was renamed to "rate_entities/rating" because of It works like a generic rating view where the whole settings will be checked. For example: Use radio or ajax input, check if the user is logged in, check if It is listing or full displaying the entity.<br />
	 * 16- The users can see the rate made by themselves<br />
	 * 17- The admin can choose between display the rate made by the users as text or a stars image<br />
	 * 18- The admin can allow rate for not loggedin users<br />
	 * 19- The admin can see rate historic for each entity<br />
	 * 20- The admin can allow another users see and manage rate historic for each entity<br />
	 * 21- The admin can choose who can see the rate historic based on the elgg groups entities<br />
	 * 22- The rate_entities plugin has been made compatible with "ajax_form_input" plugin<br />
	 * 23- The admin can choose who can rate the entities based on the elgg groups entities<br />
	 * 24- The admin can choose which subtype of entities can be evaluated by some elgg entity group entity using one intuitive matrix in the settings of rate_entities<br />
	 * 25- Allow users to evaluate pages instead entities<br />
	 * 26- Allow to include the evaluation system via javascript for one specific html element in accordance to the provided ID<br />
	 * (version 2.0.3)<br />
	 * 27- Just a small change in the function try_to_get_entity() for make compatible with some plugins (in special my plugin forum hehe)<br />
	 * 28- Bug correction while changing the plugin settings using any groups table (rating_permissions, configuration by elgg groups and rating links permissions)<br />
	 * 29- Now some rating information will be displayed only while full view of entity.<br />
	 * (version 2.3.3)<br />
	 * 30- A "neutral" view called "rating" for other plugins ask for some rating system without get dependent of any rating system plugin<br />
	 * 31- New functions that allow to get or list the entities ordered by the rate average: get_entities_by_rate_average() and list_entities_by_rate_average()<br />
	 * 32- Elgg hooks created that allow another plugins to use the functionality provide by rate_entites or any another rating system plugin without get dependent to some specific plugins<br />
	 * (version 2.3.4)<br />
	 * 33- Bug correction: While saving new links there was a problem and the links were being saved incorrectly then It was not possible to evaluate those links<br />
	 * 
	 * <br />
	 */
?>