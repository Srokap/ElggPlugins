<?php
	/**
	 * @file lib/rate_entities.php
	 * @brief The rate_entities plugin lib
	 */

	/**
	 * Set the default rate_entities settings
	 */
	function init_rate_entities_settings() {
		// This setting will ensure this funcion to be executed only one time 
		set_plugin_setting('init_settings',true);
		
		// This setting will ensure only admins can reset their rate that their did
		set_plugin_setting('allow_reset_rate','only_admins');

		$entity_subtypes = array('groups','group_topics','profile','blogs');
		set_plugin_setting('add_rating_system',serialize($entity_subtypes),'rate_entities');

		set_plugin_setting('rating_permissions_system','disabled','rate_entities');
		set_plugin_setting('default_input_type','ajax','rate_entities');
	}

	/**
	 * Extend the views of the other plugins according the settings defined by the admin
	 */
	function rate_entities_extend_views() {
		$add_rating = unserialize(get_plugin_setting('add_rating_system','rate_entities'));
		
		// Check if we have to incude the rate system for groups
		if (in_array('groups',$add_rating)) {
			//elgg_extend_view('group/group','rate_entities/rating',400);
		}
		
		if (in_array('profile',$add_rating)) {
			elgg_extend_view('user/default','rate_entities/rating',400);
		}
		
		if (in_array('blogs',$add_rating)) {
			elgg_extend_view('object/blog','rate_entities/rating',400);
		}
	}

	/**
	 * Get the entity rate
	 * 
	 * @param $guid
	 * @param $user
	 * @param $object
	 * @return unknown_type
	 */
	function get_entity_rate($guid,$user,$return_object=false) {
		$entity = get_entity($guid);

		if (!$user) {
			$user = get_loggedin_user();
		}
		
		if ($entity && $user) {
			if ($rate = get_annotations($guid,$entity->type,$entity->getSubtype(),'generic_rate','',$user->getGuid())) {
				if (is_array($rate)) {
					$rate = $rate[0];
				}

				if (!$return_object) {
					return $rate->value;
				}	else {
					return $rate;
				}
			}
		}
		
		return false;
	}

	/**
	 * Deletes a rate for an entity
	 * 
	 * @param $guid
	 * @return true|false Depends on success
	 */
	function delete_rate($id) {
		if($user = get_loggedin_user()) {
			if ($rate = get_annotation($id)) {
				if (can_manage_rates($user->guid)) {
					if (delete_annotation($rate->id)) {
						return true;
					}
				}
			}
		}
		
		return false;
	}

	/**
	 * Check if a user can reset him rate for an entity
	 * 
	 * @param $guid
	 * @param $user
	 * @return true|false Depends on success
	 */
	function can_reset_rate($guid,$user) {
		if ($guid) {
			if ($entity = get_entity($guid)) {
				if (!$user) {
					$user = get_loggedin_user();
					if (!$user) {
						return false;
					}
				}
				
				$plugin_setting = get_plugin_setting('allow_reset_rate','rate_entities');
				
				if ($plugin_setting) {
					switch ($plugin_setting) {
						case 'only_admins':
							if (isadminloggedin()) {
								return true;
							}
							break;
						case 'all_users':
							return true;
						default:
							$params = array('entity'=>$entity,'user'=>$user,'allow_reset_rate'=>$plugin_setting);
							$return = trigger_plugin_hook('reset_rate_permission_check',$entity->type,$params,false);
							return $return;
					}
				}
			}
		}
		
		return false;
	}

	/**
	 * Count how many ratings to an entity
	 * 
	 * @param $guid
	 * @return false|Integer The number of ratings to an entity
	 */
	function count_entity_rates($guid) {
		if ($entity = get_entity($guid)) {
			$rate_number = $entity->countAnnotations('generic_rate');

			return $rate_number;
		}
		return false;		
	}

	/**
	 * Get the average rate of an entity
	 * 
	 * @param $guid
	 * @return false|Integer The average of the rates of an entity
	 */
	function get_entity_rate_avg($guid) {
		if ($entity = get_entity($guid)) {
			$rate = $entity->getAnnotationsAvg('generic_rate');
			return $rate;
		}
		
		return false;
	}

	/**
	 * Return the options in the radio_input format
	 * 
	 * @return Array An array of options that will be used in the "input/radio" view
	 */
	function get_rate_options_array() {
		$opt = array(
			elgg_echo("rate_entities:1")=>1,
			elgg_echo("rate_entities:2")=>2,
			elgg_echo("rate_entities:3")=>3,
			elgg_echo("rate_entities:4")=>4,
			elgg_echo("rate_entities:5")=>5,
			);
		
		return $opt;
	}

	/**
	 * Verify if the loggedin user can rate an entity
	 * 
	 * @param $guid
	 * @return true|false Depends on success
	 */
	function allow_rate($entity_guid,$link,$user_guid) {
		if (!$user = get_entity($user_guid)) {
			$user = get_loggedin_user();
		}
		
		if ($entity = get_entity($entity_guid)) {
			$user_rate = get_entity_rate($entity->guid);
		} else {
			$entity = get_link_entity($link);
		}

		if ($entity) {
			$evaluators = get_allowed_evaluators($entity->guid);
			if ($user) {
				if ((!$user_rate || can_reset_rate($entity_guid)) && (($user->guid != $entity->getOwner()) && ($user->guid != $entity->guid))) {
					if (in_array(1,$evaluators)) {
						return true;
					}
					
					if (in_array(2,$evaluators)) {
						return true;
					}
					
					// Get the access collect IDs that the user has access for
					$access_array = get_access_array($user->guid);
					foreach($evaluators as $evaluator) {
						if(in_array($evaluator,$access_array)) {
							return true;
						}
					}
				}
			} else {
				if (in_array(2,$evaluators)) {
						return true;
				}
			}
		}
		
		return false;
	}

	/**
	 * Get corresponding rate average image url
	 * 
	 * @param $rate
	 * @return String URL of the corresponding image for the rate average
	 */
	function get_rate_image_url($rate=0)
	{
		$url = '';
		if ($rate >= 0 && $rate <= 5) {
			global $CONFIG;
			
			$int_rate = 0;
			while ($int_rate <= $rate) {
				$int_rate++;
			}
			$int_rate--;
			
			$dec_part = $rate - $int_rate;
						
			if ($dec_part < 0.5) {
				$rate = $int_rate;
			} else if (($dec_part >= 0.5) && ($dec_part < 0.8)) {
				$rate = $int_rate + 0.5;
			} else {
				$rate = $int_rate + 1;
			}
			
			$image = $rate * 2;
			
			$url = $CONFIG->wwwroot."mod/rate_entities/_graphics/{$image}.gif";
		}
		
		return $url;
	}
	
	/**
	 * Check if It is possible to rate some subtype
	 * Enter description here ...
	 * @param $subtype
	 * @return true|false Depends on success
	 */
	function is_enabled_rating_for($subtype) {
		if ($subtype) {
			$add_rating = unserialize(get_plugin_setting('add_rating_system','rate_entities'));
			
			if (in_array($subtype,$add_rating)) {
				return true;
			}
		}
		
		return false;
	}
	
	/**
	 * Get the ID for the rating container div that informs javascript where is the inputs and outputs divs
	 * 
	 * @param $vars
	 */
	function get_rating_container_id($vars) {
		$container_id = ($vars['container_id']) ? ($vars['container_id']) : get_input('container_id',1);
		
		return $container_id;
	}
	
	/**
	 * Inc the ID for the rating container div
	 * 
	 * @param $vars
	 */
	function inc_rating_container_id($vars) {
		// The container ID must to be setted if the rating view is being used more than one time per page
		$container_id = ($vars['container_id']) ? ($vars['container_id']) : get_input('container_id',0);
		$container_id++;
		set_input('container_id',$container_id);

		return $container_id;
	}
	
	/**
	 * Get the default rating input defined by the admin on the plugins tools
	 */
	function get_rating_default_input_type() {
		$default_input = get_plugin_setting('default_input_type','rate_entities');
		
		if (!$default_input) {
			set_rating_default_input_type('ajax');
		}
		
		return $default_input;
	}
	
	/**
	 * Set the default rating input type 
	 * @param $default_input
	 */
	function set_rating_default_input_type($default_input = 'ajax') {
		return set_plugin_setting('default_input_type','ajax','rate_entities');
	}
	
	/**
	 * Check if a user can manage rates
	 * @param $user_guid
	 */
	function can_manage_rates($user_guid) {
		if (!$user = get_entity($user_guid)) {
			$user = get_loggedin_user();
		}
		
		if ($user) {
			$allowed_groups = get_allowed_manage_rates();
			$access_array = get_access_array($user->guid);
			foreach ($allowed_groups as $allowed_group) {				
				if ($allowed_group != 'admins') {
					if (in_array($allowed_group,$access_array)) {
						return true;
					}
				} else {
					if (isadminloggedin()) {
						return true;
					}
				}
			}
		}
		
		return false;
	}
	
	/**
	 * Returns the texts that translate the meaning of evaluation
	 * 
	 * @param $rate
	 */
	function get_rate_text($rate=0) {
		if ($rate) {
			$rate = $rate.'';
			if (($rate >= 0) && ($rate < 1.5)) {
				return sprintf(elgg_echo('rate_entities:text_1'),$rate);
			} else if (($rate >= 1.5) && ($rate < 2.5)) {
				return sprintf(elgg_echo('rate_entities:text_2'),$rate);
			} else if (($rate >= 2.5) && ($rate < 3.5)) {
				return sprintf(elgg_echo('rate_entities:text_3'),$rate);
			} else if (($rate >= 3.5) && ($rate < 4.5)) {
				return sprintf(elgg_echo('rate_entities:text_4'),$rate);
			} else if (($rate >= 4.5) && ($rate <=5)) {
				return sprintf(elgg_echo('rate_entities:text_5'),$rate);
			}
		}
	}

	/**
	 * Get the access collections IDs allowed to manage rates
	 */
	function get_allowed_manage_rates() {
		$group_guids = unserialize(get_plugin_setting('allowed_manage_rates','rate_entities'));
		$allowed_manage = array();
		foreach ($group_guids as $group_guid) {
			if (($group_guid) && ($group_guid > 2)) {
				if ($group = get_entity($group_guid)) {
					$allowed_manage[] = $group->group_acl;
				}
			} else {
				$allowed_manage[] = $group_guid;
			}
		}

		return $allowed_manage;
	}
	
	/**
	 * Get the path of the elgg main directory
	 */
	function get_elgg_path() {
		global $CONFIG;
		
		$pathpart = str_replace("//","/",str_replace($_SERVER['DOCUMENT_ROOT'],"",$CONFIG->path));
		if (substr($pathpart,0,1) != "/") {
			$pathpart = "/" . $pathpart;
		}
		
		return $pathpart;
	}
	
	/**
	 * Get all link entities created for represent the page of the website
	 */
	function get_link_entities() {
		$options = array(
			'type'=>'object',
			'subtype'=>'link',
			'limit'=>999999,
			);			
		$links = elgg_get_entities($options);
		
		return $links;
	}
	
	/**
	 * Get a link entity based on their url
	 * 
	 * @param $url
	 */
	function get_link_entity($url) {
		global $CONFIG;
		
		if (!$url) {
			$url = get_current_url();
		} else {
			$url = url_handler($url);
		}
		
		if ($url) {
			$links = get_link_entities();

			foreach ($links as $link) {
				if($url == $link->title) {
					return $link;
				}
			}
		}
		
		return false;
	}
	
	/**
	 * Get the current url
	 */
	function get_current_url() {
		global $CONFIG;
		
		$pathpart = get_elgg_path();
		$url = str_replace($pathpart,'',$_SERVER['REQUEST_URI']);
		$url = $CONFIG->wwwroot.$url;
		if ($url[strlen($url)-1] != '/') {
			$url = $url.'/';
		}
		
		return $url;
	}
	
	/**
	 * Handle the url in according to rate_entities requirements 
	 * @param $url
	 */
	function url_handler($url) {
		if ($url) {
			global $CONFIG;
			
			// If there is $url variable then remove (if exists) the $CONFIG->wwwroot from It
			$url = str_replace($CONFIG->wwwroot,'',$url);

			// Add the $CONFIG->wwwroot to $url
			$url = $CONFIG->wwwroot.$url;

			// If the $url do not end with '/' character then add It
			if ($url[strlen($url)-1] != '/') {
				$url = $url.'/';
			}
			
			return $url;
		}
		return false;
	}
	
	/**
	 * Get the allowed evaluators groups guids based on the subtype of entity passed by param for this function
	 * 
	 * @param $entity_guid
	 */
	function get_allowed_evaluators($entity_guid) {
		
		if ($entity = get_entity($entity_guid)) {
			if (($entity->getSubtype() != 'link') && ($entity->type != 'user')) {
				$groups = unserialize(get_plugin_setting($entity->getSubtype().'_evaluators','rate_entities'));
			} else if ($entity->getSubtype() == 'link') {
				$groups = unserialize(get_plugin_setting($entity->title.'_evaluators','rate_entities'));
			} else if ($entity->type == 'user') {
				$groups = unserialize(get_plugin_setting('user_evaluators','rate_entities'));
			}
			
			$access_collections = array();
			foreach ($groups as $group_guid) {
				if ($group_guid > 2) {
					$group = get_entity($group_guid); 
					$access_collections[] = $group->group_acl;
				} else {
					$access_collections[] = $group_guid;
				}
			}
			
			return $access_collections;
		}
		
		return false;
	}
	
	/**
	 * Try to get some entity that is being displayed based on the patterns followed by elgg
	 * @param $vars
	 */
	function try_to_get_entity($vars) {
		if ($vars['entity']) {
			return $vars['entity'];
		}
		
		if ($vars['entity_guid']) {
			return get_entity($vars['entity_guid']);
		}
		
		if (!$entity = trigger_plugin_hook('try_to_get_entity','rate_entities',$vars)) {
			return get_link_entity();
		}
	}

	/**
	 * List entities ordered by the average
	 * 
	 * @param unknown_type $options
	 * @return Ambigous <string, Ambigous <string, boolean, mixed, NULL, Ambigous <mixed, unknown>>>
	 */
	function list_entities_by_rate_average($options) {
		$defaults = array(
			'offset' => (int) max(get_input('offset', 0), 0),
			'limit' => (int) max(get_input('limit', 10), 0),
			'full_view' => TRUE,
			'view_type_toggle' => FALSE,
			'pagination' => TRUE
		);
		$options = array_merge($defaults, $options);
	
		$count = elgg_get_entities_by_rate_average(array_merge(array('count' => TRUE), $options));
		$entities = elgg_get_entities_by_rate_average($options);
	
		return elgg_view_entity_list($entities, $count, $options['offset'],
			$options['limit'], $options['full_view'], $options['view_type_toggle'], $options['pagination']);
	}
	
	/**
	 * Get entities ordered by the rate average in decrescent or ascendent order
	 * 
	 * @param $options
	 */
	function get_entities_by_rate_average($options) {
		global $CONFIG;

		// Select the sum of the rates returned by the JOIN
		$select = 'avg(ms.string) as rate_avg';
		if (is_array($options['selects'])) {
			$options['selects'][] = $select;
		} else if($options['selects']) {
			$options['selects'] = array($options['selects'],$select);
		} else {
			$options['selects'] = array($select);
		}
		
		// Get the annotations "generic_rate" for each entity
		$metastring_id = get_metastring_id('generic_rate');
		$join = ' LEFT JOIN '.$CONFIG->dbprefix.'annotations a ON ((a.entity_guid=e.guid)AND(a.name_id='.$metastring_id.'))';
		if (is_array($options['joins'])) {
			$options['joins'][] = $join;
		} else if($options['joins']) {
			$options['joins'] = array($options['joins'],$join);
		} else {
			$options['joins'] = array($join);
		}

		// JOIN the value of the annotations. The value of the rates...
		$options['joins'][] = ' LEFT JOIN '.$CONFIG->dbprefix.'metastrings ms ON ((a.entity_guid=e.guid)AND(a.name_id='.$metastring_id.')AND(a.value_id=ms.id))';
		
		// Check if the user does not want to list by best average any value different of: 'desc' 
		if ($options['order_by'] != 'asc') {
			$options['order_by'] = 'rate_avg desc, e.time_created desc';
		} else {
			$options['order_by'] = 'rate_avg asc, e.time_created desc';
		}

		// Group the result of JOIN annotations by entity because each entity may have infinite annotations "generic_rate"
		$options['group_by'] .= ' e.guid ';

		// Let the elgg_get_entities() function make do work for us :)
		$entities = elgg_get_entities($options);
		
		return $entities;
	}
?>