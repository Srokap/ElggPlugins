<?php
	/**
	 * @file mod/rate_entities/rating_historic.php
	 * @brief Displays the rates done for one entity
	 */

	require_once(dirname(dirname(dirname(__FILE__))).'/engine/start.php');
	
	$entity_guid = get_input('entity_guid');
	$entity = get_entity($entity_guid);

	if (!can_manage_rates()) {
		forward($_SERVER['HTTP_REFERER']);
	}

	$area2 .= elgg_view('rate_entities/rating_historic',array('entity'=>$entity));
	$page_body = elgg_view_layout('two_column_left_sidebar',$area1,$area2);
	
	page_draw(elgg_echo('rate_entities:rating_historic'),$page_body);
?>