<?php
	/**
	 * @file actions/delete_entity.php
	 * @brief Action to delete entities.
	 *  Ps. It's a copy of the file "elgg_root_dir/actions/entities/delete.php"
	 */

	gatekeeper();

	$guid = get_input('guid');
	
	$entity = get_entity($guid);
	
	if (($entity)&&($entity->canEdit())) {
		if ($entity->delete()) {
			system_message(sprintf(elgg_echo('entity:delete:success'), $guid));
		} else {
			register_error(sprintf(elgg_echo('entity:delete:fail'), $guid));
		}
	} else {
		register_error(sprintf(elgg_echo('entity:delete:fail'), $guid));
	}
		
	forward($_SERVER['HTTP_REFERER']);
?>