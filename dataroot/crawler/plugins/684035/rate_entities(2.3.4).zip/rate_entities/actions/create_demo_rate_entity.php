<?php
	/**
	 * @file actions/create_demo_rate_entity.php
	 * @brief Create a new demo rate entity for tests 
	 */

	action_gatekeeper();
	
	$demoEntity = new ElggObject();
	$demoEntity->title = 'Demo Rate Entity';
	$demoEntity->subtype = 'demo_rate';
	$demoEntity->access_id = 2;
	
	if ($demoEntity->save()) {
		system_message(sprintf(elgg_echo('rate_entities:demo_entity_created'),$demoEntity->title));
	}
	
	forward($_SERVER['HTTP_REFERER']);
?>