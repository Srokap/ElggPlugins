<?php
	/**
	 * @file actions/ajax/refresh_rate_as_stars.php
	 * @brief Refresh the rate made by the user and the number of rates for one entity
	 */

	require_once(dirname(dirname(dirname(dirname(dirname(__FILE__))))).'/engine/start.php');
	
	$entity_guid = get_input('entity_guid');
	$rate = get_input('rate');
	$user = get_loggedin_user();
	
	if ($entity = get_entity($entity_guid)) {
		$rates_counter = count_entity_rates($entity_guid);
		if ($user) {
			$old_rate = get_entity_rate($entity_guid);
		}
		
		// If the refresh is being executed before update of rate via the other ajax request then make the necessary calculations for display the right rates counter and rate_avg
		if ($user && $rate && !$old_rate) {
			// Get the old rate (because the new one was not saved in database yet) and include the new rate
			$rate_avg = get_entity_rate_avg($entity_guid);
			$rate_avg = (($rate_avg * $rates_counter) + $rate) / ($rates_counter + 1);
			
			// Increment the rates counter because of the new rate
			$rates_counter++;
		// The same that above but in case of rate deletion
		} else if ($user && !$rate && $old_rate) {
			$rate_avg = get_entity_rate_avg($entity_guid);
			$rate_avg = (($rate_avg * $rates_counter) - $old_rate) / ($rates_counter - 1);
			
			$rates_counter--;
		}
		
		echo elgg_view('rate_entities/components_2/view_rate_as_stars',array('rates_counter'=>$rates_counter,'entity'=>$entity,'rate'=>$rate_avg));
		echo elgg_view('rate_entities/components_2/rating_feedback',array('entity'=>$entity,'rate'=>$rate));
	} else {
		echo elgg_echo('rate_entities:errors:invalid_entity_guid');
		register_error(elgg_echo('rate_entities:errors:invalid_entity_guid'));
	}
?>