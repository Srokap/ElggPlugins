<?php
	/**
	 * @file actions/ajax/refresh_links_table.php
	 * @brief Return the html for the links table
	 */

	require_once(dirname(dirname(dirname(dirname(dirname(__FILE__))))).'/engine/start.php');
	
	echo elgg_view('rate_entities/forms/elements/links_table');
?>