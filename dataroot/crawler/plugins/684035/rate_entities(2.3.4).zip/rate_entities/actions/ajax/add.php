<?php
	/**
	 * @file actions/ajax/add.php
	 * @brief Ajax action for add rating 
	 */

	require_once(dirname(dirname(dirname(dirname(dirname(__FILE__))))).'/engine/start.php');
	
	$guid = (int) get_input('entity_guid');
	$rate = (int) get_input('rate',0);
	$container_id = get_input('container_id');

	// Check if It is possible to rate the entity
	if (!allow_rate($guid)) {
		register_error(sprintf(elgg_echo('rate_entities:not_allowed_rate')));
		echo elgg_echo('rate_entities:errors:not_allowed_rate');
	}
	
	// If not exists entity then the entity_guid is a wrong ID
	if (!($entity = get_entity($guid))) {
		register_error(sprintf(elgg_echo('rate_entities:bad_guid'),$guid));
		echo sprintf(elgg_echo('rate_entities:bad_guid'),$guid);
		exit;
	}
	
	// Try to get the name of the entity (title for objects, name for groups and users
	$entity_name = ($entity->title) ? $entity->title : $entity->name;
	if (!$entity_name) {
		$entity_name = $entity->username;
	}
	
	// If rate == 0 then the user is trying to delete his rate
	if ($rate == 0) {
		$rate = get_entity_rate($guid,'',true);
		$result = delete_rate($rate->id);

		if ($result === false) {
			register_error(elgg_echo('rate_entities:errors:cant_reset_rate'));
			echo elgg_echo('rate_entities:errors:cant_reset_rate');
			exit;
		} else if ($result === null) {
			register_error(elgg_echo('rate_entities:errors:cant_reset_blank_rate'));
			echo elgg_echo('rate_entities:errors:cant_reset_blank_rate');
			exit;
		}
		echo sprintf(elgg_echo('rate_entities:rate_reseted'),$entity_name);
		exit;
	// If the rate is not a valid rate value then the rate has a wrong size
	} else if ($rate < 0 || $rate > 5) {
		register_error(sprintf(elgg_echo('rate_entities:errors:wrong_rate_size'),$rate));
		echo sprintf(elgg_echo('rate_entities:errors:wrong_rate_size'),$rate);
		exit;
	}

	// If the user already rated the entity then He is not allowed to rate It again
	if (get_entity_rate($guid)) {
		register_error(sprintf(elgg_echo('rate_entities:already_rated'),$entity_name));
		echo sprintf(elgg_echo('rate_entities:already_rated'),$entity_name);
		exit;
	}
	
	if ($entity->annotate('generic_rate',$rate,2)) {
		echo elgg_echo('rate_entities:thanks');
		echo '<br />';
		echo elgg_echo('rate_entities:saved');
	// If It was not possible annotate for some reason then record the error and inform the user
	} else {
		register_error(elgg_echo('rate_entities:cant_annotate'));
		echo elgg_echo('rate_entities:cant_annotate');
	}
?>