<?php
	/**
	 * @file actions/ajax/add_link.php
	 * @brief Create a new link entity
	 */

	require_once(dirname(dirname(dirname(dirname(dirname(__FILE__))))).'/engine/start.php');
	global $CONFIG;
	
	$new_link = get_input('new_link');
	if ($new_link = url_handler($new_link)) {
		if (!get_link_entity($new_link)) {
			$link_entity = new ElggObject();
			$link_entity->subtype = 'link';
			$link_entity->title = $new_link;
			$link_entity->access_id = 2;
			$link_entity->owner_guid = 0;
			$link_entity->save();
			echo sprintf(elgg_echo('rate_entities:link_created_successfully'),$new_link);
		} else {
			echo sprintf(elgg_echo('rate_entities:errors:link_already_exists'),$new_link);
		}
	}
	
	echo '.<br />';
?>