<?php
	/**
	 * @file actions/delete_rate.php
	 * @brief Delete rate
	 */

	$rate_id = get_input('rate_id');
	
	if (delete_rate($rate_id)) {
		system_message(elgg_echo('rate_entities:rate_deleted_successfully'));
	} else {
		system_messages(elgg_echo('rate_entities:rate_cant_be_deleted'),'errors');
	}
	
	forward($_SERVER['HTTP_REFERER']);
?>