<?php
	/**
	 * @file actions/add.php
	 * @brief Ajax action for add rating 
	 */

	action_gatekeeper();
	
	$guid = (int) get_input('entity_guid');
	$rate = (int) get_input('rate',0);
	$container_id = get_input('container_id');

	// Check if It is possible to rate the entity
	if (!allow_rate($guid)) {
		register_error(sprintf(elgg_echo('rate_entities:not_allowed_rate')));
		forward($_SERVER['HTTP_REFERER']);
	}
	
	// If not exists entity then the entity_guid is a wrong ID
	if (!($entity = get_entity($guid))) {
		register_error(sprintf(elgg_echo('rate_entities:bad_guid'),$guid));
		forward($_SERVER['HTTP_REFERER']);
	}
	
	if ($rate < 0 || $rate > 5) {
		register_error(sprintf(elgg_echo('rate_entities:errors:wrong_rate_size'),$rate));
		forward($_SERVER['HTTP_REFERER']);
	}

	// Try to get the name of the entity (title for objects, name for groups and users
	$entity_name = ($entity->title) ? $entity->title : $entity->name;
	if (!$entity_name) {
		$entity_name = $entity->username;
	}
	
	// If the user already rated the entity then He is not allowed to rate It again
	if (get_entity_rate($guid)) {
		register_error(sprintf(elgg_echo('rate_entities:already_rated'),$entity_name));
		forward($_SERVER['HTTP_REFERER']);
	}

	if ($entity->annotate('generic_rate',$rate,2)) {
		system_message(elgg_echo('rate_entities:thanks').'<br />'.elgg_echo('rate_entities:saved'));
	// If It was not possible annotate for some reason then record the error and inform the user
	} else {
		register_error(elgg_echo('rate_entities:cant_annotate'));
	}
	
	forward($_SERVER['HTTP_REFERER']);
?>