<?php
	/**
	 * @file views/default/rate_entities/components/stars.php
	 * @brief Displays one rate as a stars image
	 * 
	 * @uses $vars['entity']
	 * @uses $vars['rate']
	 */

	$class = ($vars['class']) ? ($vars['class']) : 'stars';
	$rate_avg = $vars['rate'];
	
	if (!$rate_avg) {
		if ($vars['entity']) {
			$rate_avg = get_entity_rate_avg($vars['entity']->guid);
		}
	}
	
	
	$image_url = get_rate_image_url($rate_avg);
	$rate_avg = round($rate_avg,2);

	$rate_title = get_rate_text($rate_avg);
?>

<span class="stars">
	<img class="<?php echo $class;?>" src='<?php echo $image_url; ?>' alt='<?php echo $rate_title; ?>' title='<?php echo $rate_title; ?>' />
</span>