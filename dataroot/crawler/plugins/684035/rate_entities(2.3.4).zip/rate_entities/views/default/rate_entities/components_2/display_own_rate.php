<?php
	/**
	 * @file views/default/rate_entities/components_2/display_own_rate.php
	 * @brief  Display own rate
	 */

	if ($vars['entity'])  {
		$display_own_rate = ($vars['display_own_rate']) ? $vars['display_own_rate'] : get_plugin_setting('display_own_rate','rate_entities');
		$container_id = get_rating_container_id($vars);
		$user_rate = $vars['rate'] = ($vars['rate']) ? ($vars['rate']) : (get_entity_rate($vars['entity']->guid));
		
		switch ($display_own_rate) {
			case 'image':
				$stars_view = elgg_view('rate_entities/components/stars',$vars);
				echo sprintf(elgg_echo('rate_entities:your_evaluation'),$stars_view);
				break;
			case 'text':
				$user_rate = get_entity_rate($vars['entity']->guid);
				echo sprintf(elgg_echo('rate_entities:your_evaluation'),$user_rate);
				break;
		}
	}
?>
