<?php
/**
 * @file views/default/input/check_boxes_without_label.php
 * @brief The same as elgg but without the tag <label>
 */

$class = (isset($vars['class'])) ? $vars['class'] : 'input-checkboxes';
$value = (isset($vars['value'])) ? $vars['value'] : NULL;
$value_array = (is_array($value)) ? array_map('strtolower', $value) : array(strtolower($value));
$internalname = (isset($vars['internalname'])) ? $vars['internalname'] : '';
$options = (isset($vars['options']) && is_array($vars['options'])) ? $vars['options'] : array();
$default = (isset($vars['default'])) ? $vars['default'] : 0;

$id = (isset($vars['internalid'])) ? $vars['internalid'] : '';
$disabled = (isset($vars['disabled'])) ? $vars['disabled'] : FALSE;
$js = (isset($vars['js'])) ? $vars['js'] : '';

if ($options) {
	// include a default value so if nothing is checked 0 will be passed.
	if ($internalname) {
		echo "<input type=\"hidden\" name=\"$internalname\" value=\"$default\">";
	}
	
	foreach($options as $label => $option) {
		// @hack - This sorta checks if options is not an assoc array and then
		// ignores the label (because it's just the index) and sets the value ($option)
		// as the label.
		// Wow.
		// @todo deprecate in Elgg 1.8
		if (is_integer($label)) {
			$label = $option;
		}

		if (!in_array(strtolower($option), $value_array)) {
			$selected = FALSE;
		} else {
			$selected = TRUE;
		}
		
		$attr = array(
			'type="checkbox"',
			'value="' . htmlentities($option, ENT_QUOTES, 'UTF-8') . '"'
		);
		
		if ($id) {
			$attr[] = "id=\"$id\"";
		}
		
		if ($class) {
			$attr[] = "class=\"$class\"";
		}
		
		if ($disabled) {
			$attr[] = 'disabled="yes"';
		}
		
		if ($selected) {
			$attr[] = 'checked = "checked"';
		}
		
		if ($js) {
			$attr[] = $js;
		}
		
		if ($internalname) {
			// @todo this really, really should only add the []s if there are > 1 element in options.
			$attr[] = "name=\"{$internalname}[]\"";
		}
		
		$attr_str = implode(' ', $attr);
		
		echo "<label class='rate_entities_label' ><input $attr_str />$label<br /></label>";
	}
}