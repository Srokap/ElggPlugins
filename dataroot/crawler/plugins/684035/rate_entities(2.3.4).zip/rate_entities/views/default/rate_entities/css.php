<?php
	/**
	 * @file views/default/rate_entities/css.php
	 * @brief Set the rate_entities css on elgg system
	 */
?>

.reduced_text{
	font-size: 70%;
}

.own_rate_stars{
	width: 55px;
}

.ext_table_container{
	border: solid 2px #777799;
	background-color: #FFDDAA;
	-moz-border-radius: 8px;
}

.groups_table_col{
	width: 100px;
}

.groups_table_first_col{
	width: 200px;
}

.rate_entities_table{
	padding-right: 10px;
}

.table_container{
	margin: 10px;
	height: 200px;
	overflow: scroll;
	text-align: center;
}

.rate_entities_td{
	border: 1px inset;
	text-align: center;
}

.rate_entities_label{
	font-weight: normal;
	font-size: 100%;
}

.settings_left_sidebar{
	float: left;
	width: 47%;
	padding-right: 10px;
}

.settings_right_sidebar{
	float: left;
	width: 47%;
	padding-left: 10px;
}

.rating_historic td,th{
	width: 135px;
	text-align: center;
}

.rating_historic_container {
	margin:10px;
	padding:10px;
	-moz-border-radius:8px;
	border: solid 2px #777799;
	background-color: #FFDDAA;
	min-height: 300px;
}

.link_rating{
	-moz-border-radius:8px 8px 8px 8px;
	border:2px solid #CCCCCC;
	margin:5px;
	padding:5px;
	float: right;
}

.max_width{
	max-width: 185px;
}

.navigation_container{
	float: right;
}

.add_url_form_container{
	float: left;
	text-align: left;
	-moz-border-radius: 8px;
	border: solid 2px #CCCCCC;
	padding: 5px;
	margin: 10px;
}

.button{
	-moz-border-radius: 4px 4px 4px 4px;
	background: none repeat scroll 0 0 #4690D6;
	border: 1px solid #4690D6;
	color: #FFFFFF;
	cursor: pointer;
	font: bold 14px/100% Arial,Helvetica,sans-serif;
	padding: 2px 4px;
	text-align: center;
}
.button:hover{
	background: #0054a7;
	border-color: #0054a7;
}

.button a{
	color: #FFFFFF;
	text-decoration: none;
}

.no_style{
	font-size: 100%;
	font-weight: normal;
}

.links_first_col{
	font-size:80%;
	padding-left:5px;
	text-align:left;
	width:400px;
}