<?php
	/**
	 * @file views/default/object/listing_demo_rate.php
	 * @brief Listing view for the demo rate entities
	 */

	$title = $vars['entity']->title;
		
	$controls = "";
	if ($vars['entity']->canEdit())
	{
		$action = $vars['url'].'action/rate_entities/delete_entity';
		$form_body = '';
		$form_body .= elgg_view('input/hidden',array('internalname'=>'guid','value'=>$vars['entity']->guid));
		$form_body .= elgg_view('input/submit',array('value'=>elgg_echo('rate_entities:delete')));
		
		$form = elgg_view('input/form',array('body'=>$form_body,'action'=>$action));
		$controls .= $form;
	}
	
	$info = "<div>";
	$info .= "<p><b><a href=\"" . $vars['entity']->getUrl() . "\">" . $title . "</a></b> $controls </p></div>";
	
	$owner = $vars['entity']->getOwnerEntity();
	$ownertxt = elgg_echo('unknown');
	if ($owner)
	{
		$ownertxt = "<a href=\"" . $owner->getURL() . "\">" . $owner->name ."</a>";
	}
	
	$info .= "<div>".sprintf(elgg_echo("entity:default:strapline"),friendly_time($vars['entity']->time_created),$ownertxt);
	$info .= "</div>";

	echo elgg_view_listing($icon, $info);
?>