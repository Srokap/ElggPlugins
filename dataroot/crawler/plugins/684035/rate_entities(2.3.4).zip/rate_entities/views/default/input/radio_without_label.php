<?php
	/**
	 * @file views/default/input/radio_without_label.php
	 * @brief Input radio without the text label
	 */

	if(!$name = $vars['radio_name'])
	{
		$name = 'rate_star';
	}
	
	if(!$class = $vars['class'])
	{
		$class = 'rate_star';
	}
	
	if($vars['disabled'])
	{
		$disabled = ' disabled="yes" ';
	}
	
	if($vars['checked'])
	{
		$checked = 'checked="checked"';
	}
?>

<input name="<?php echo $name; ?>" type="radio" class="<?php echo $class; ?>" value="<?php echo $vars['value']; ?>" <?php echo $vars['js']; echo $disabled; echo $checked; ?> />

