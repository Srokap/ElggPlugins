<?php
	/**
	 * @file views/default/rate_entities/input/ajax_input.php
	 * @brief Soon we will have a ajax input view for rating as a new option of viewing
	 */

	// If the user can rate or reset its rate then continue...
	if (allow_rate($vars['entity']->guid))	{
		// If the user has already rate the entity then the rating input will be hidden and will be showed only if the user reset its rate
		// TODO: Load the ajax input via ajax instead preload It every time
		if (get_entity_rate($vars['entity']->guid)) {
			$display = " style='display: none' ";
		}
		
		// Include the rate_entities javascript files required for ajax i
		echo elgg_view('rate_entities/components/rate_entities_js',$vars);

		// Necessary class for use of star rating javascript plugin
		$radio_vars = array();
		$radio_vars['class'] = 'rate_star {required:1}';
	
		// Load the five radio inputs that will be changed for stars by the star rating plugin
		$stars = '';
		for ($counter=1;$counter<=5;$counter++)	{	
			$radio_vars['value'] = $counter;
			$stars .= elgg_view('input/radio_without_label',$radio_vars);
		}
		
		// Get the container_id for the ajax input and output management
		$container_id = $vars['container_id'] = get_rating_container_id($vars);
		
?>
		<div <?php echo $display; ?>id="rating_input_container_<?php echo $container_id; ?>">
			<?php
				echo $stars;
				echo ' ('.elgg_echo('rate_entities:rateit').') ';
			?>
		</div>
<?php 
	}
?>