<?php
	/**
	 * @file views/default/js/add_link.php
	 * @brief Include the javascript used by the setting form for add links
	 */
?>

<script type="text/javascript">
	function refresh_links_table_container() {
		var url = "<?php echo $vars['url']; ?>mod/rate_entities/actions/ajax/refresh_links_table.php";
		var links_table_container = document.getElementById('links_table_container');
		
		if (window.XMLHttpRequest) { // code for IE7+, Firefox, Chrome, Opera, Safari
			var xmlhttp=new XMLHttpRequest();
		} else { // code for IE6, IE5
			var xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		}
		xmlhttp.onreadystatechange=function() {
			if (xmlhttp.readyState==4 && xmlhttp.status==200) {
				links_table_container.innerHTML = xmlhttp.responseText;
			}
		};

		xmlhttp.open("GET",url,true);
		xmlhttp.send();
	}
	
	function save_link_ajax_request(link) {
		var url = "<?php echo $vars['url']; ?>mod/rate_entities/actions/ajax/add_link.php?new_link=" + link;
		
		if (window.XMLHttpRequest) { // code for IE7+, Firefox, Chrome, Opera, Safari
			var xmlhttp=new XMLHttpRequest();
		} else { // code for IE6, IE5
			var xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		}
		xmlhttp.onreadystatechange=function() {
			if (xmlhttp.readyState==4 && xmlhttp.status==200) {
				refresh_links_table_container();

				var ajax_output = document.getElementById('links_form_ajax_output');
				ajax_output.innerHTML = xmlhttp.responseText + ajax_output.innerHTML;
			}
		};

		xmlhttp.open("GET",url,true);
		xmlhttp.send();
	}
	
	function save_link(){
		var input = document.getElementById('url_input');

		if (input) {
			link = input.value;

			save_link_ajax_request(link);
		}
	}
</script>