<?php
	/**
	 * @file views/default/object/demo_rate.php
	 * @brief A view that shows the demo rate entities both the entities in their listing view as in the their full view
	 *  Ps. Its almost a copy of the elgg view: "elgg_root_dir/views/defalt/object/default.php"
	 */

	if ($vars['full'] || $vars['fullview'])
	{
		// For use the rate_entities default (depends on your plugin setting) input view you have to pass the entity for it, named 'entity'
		echo elgg_view('rate_entities/rating',$vars);
		echo '<br />';
		echo elgg_echo('rate_entities:input_explaining');		
		echo elgg_view('export/entity', $vars);
		
	}
	else
	{
		// For use the rate_entities view_entity_rate you also have to pass the entity for it, named 'entity'
		echo elgg_view('rate_entities/view_entity_rate',$vars);
		echo '<br />';
				
		echo elgg_view('object/listing_demo_rate',$vars);
	}
