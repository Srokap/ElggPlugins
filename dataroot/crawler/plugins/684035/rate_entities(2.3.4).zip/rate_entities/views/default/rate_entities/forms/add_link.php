<?php
	/**
	 * @file views/default/rate_entities/forms/add_link.php
	 * @brief Displays the add url form into plugin settings page
	 */

	echo elgg_view('js/add_link');
?>

<div class="add_url_form_container">
	<b><?php echo elgg_echo('rate_entities:add_link'); ?></b>
	<br />
	<?php
		$form_body = '<label class="no_style">';
		$form_body .= $vars['url'];
		$form_body .= elgg_view('input/text',array('internalid'=>'url_input', 'internalname'=>'new_link','class'=>'url_input'));
		$form_body .= '</label>';
		$form_body .= ' ';
		echo $form_body;
	?>
	<span onclick="save_link(); " class="button"><?php echo elgg_echo('rate_entities:save'); ?></span>
	
	<div id="links_form_ajax_output"></div>
</div>