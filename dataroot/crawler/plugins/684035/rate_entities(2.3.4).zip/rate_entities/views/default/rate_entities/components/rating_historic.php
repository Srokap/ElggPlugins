<?php
	/**
	 * @file mod/rate_entities/views/default/rate_entities/components/rating_historic.php
	 * @brief Displays the rating historic for allowed users
	 */

	if (can_manage_rates($vars['entity']->guid)) {
		
	}
?>