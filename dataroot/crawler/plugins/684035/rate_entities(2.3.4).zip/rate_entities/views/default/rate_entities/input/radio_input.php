<?php
	/**
	 * @file views/default/rate_entities/input/radio_input.php
	 * @brief Shows the radio_input view for rating entities
	 */

	$rate = get_entity_rate($vars['entity']->guid);
	if (allow_rate($vars['entity']->guid)) {
?>
		<div id="radio_input">
			<script type="text/javascript">
				function hide_radio_form(container_counter,entity_guid,value) {
					var radio_form = document.getElementById('radio_input_' + container_counter);
					if (radio_form) {
						refresh_rate_as_stars(entity_guid,value,container_counter)
						radio_form.setAttribute('style','display: none');
						
					}
				}
			</script>
			
			<?php
				$action = $vars['url'].'action/rate_entities/add';
				$opt = get_rate_options_array();
		
				$form_body .= elgg_view('input/hidden',array('internalname'=>'entity_guid','value'=>$vars['entity']->getGUID()));
				
				// TODO: When the elgg team upgrade the view: "input/radio" allowing to remove the <br /> tag at end of the label line, we'll can use the elgg view: "input/radio" instead "input/rate_radio" of the rate_entities plugin
				$form_body .= elgg_view('input/rate_radio',array('internalname'=>'rate','options'=>$opt));
				$form_body .= elgg_view('input/submit',array('value'=>elgg_echo("rate_entities:rateit")));

				echo elgg_view('input/form', array('body'=>$form_body,'action'=>"{$action}"));
			?>
		</div>
<?php 
	}
?>