<?php
	/**
	 * @file views/default/rate_entities/rating_info.php
	 * @brief Shows the entity rate average
	 */

	if ($vars['entity']) {
		$container_id = $vars['container_id'] = get_rating_container_id($vars);
?>
		<div class="display_rating_info">
			<div id="rating_info_body_<?php echo $container_id; ?>">
				<?php
					echo elgg_view('rate_entities/components_2/view_rate_as_stars',$vars);
					
					if ($vars['full']) {
						echo elgg_view('rate_entities/components_2/rating_feedback',$vars);
					}
				?>
			</div>
			<?php
				if (can_manage_rates() && $vars['full']) {
			?> 
					<a class = "rating_feedback" href="<?php echo $vars['url']; ?>pg/rate_entities/rating_historic/<?php echo $vars['entity']->guid; ?>"><?php echo elgg_echo('rate_entities:rating_historic'); ?></a>
			<?php 
				}
			?>
			
			<div id="ajax_output_container_<?php echo $container_id; ?>"></div>
		</div>
<?php
	}
?>