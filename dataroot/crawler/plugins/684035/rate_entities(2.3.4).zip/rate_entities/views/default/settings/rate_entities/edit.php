<?php
	/**
	 * @file views/default/settings/rate_entities/edit.php
	 * @brief Include in the elgg system the settings form for the rate_entities plugin
	 */

	$opt = array(elgg_echo('rate_entities:yes')=>true,elgg_echo('rate_entities:no')=>false);
	$left_side = $right_side = '';
	
	$input_types = array(
		elgg_echo('rate_entities:ajax')=>'ajax',
		elgg_echo('rate_entities:radio')=>'radio',
	);
	$value = get_plugin_setting('default_input_type','rate_entities');
	$left_side .= '<h3>'.elgg_echo('rate_entities:default_input_type').'</h3>';
	$left_side .= elgg_view('input/radio_without_br',array('internalname'=>'params[default_input_type]','value'=>$value,'options'=>$input_types));
	$left_side .= '<br />';
	
	$input_types = array(
		elgg_echo('rate_entities:image')=>'image',
		elgg_echo('rate_entities:text')=>'text',
		elgg_echo('rate_entities:do_not_display')=>'none',
	);
	$value = get_plugin_setting('display_own_rate','rate_entities');
	if (!$value) { 
		$value = 'image';
	}
	$left_side .= '<br />';
	$left_side .= '<h3>'.elgg_echo('rate_entities:display_own_rate').'</h3>';
	$left_side .= elgg_view('input/radio_without_br',array('internalname'=>'params[display_own_rate]','value'=>$value,'options'=>$input_types));
	$left_side .= '<br />';
	
	$value = get_plugin_setting('rating_input_container','rate_entities');
	$left_side .= '<br />';
	$left_side .= '<h3>'.elgg_echo('rate_entities:rating_input_container').'</h3>';
	$left_side .= elgg_view('input/text',array('internalname'=>'params[rating_input_container]','class'=>'input_container','value'=>$value));
	$left_side .= '<br />';
	$left_side .= '<span class="reduced_text">';
	$left_side .= elgg_echo('rate_entities:rating_input_container_ps');
	$left_side .= '</span>';
	$left_side .= '<br />';
	
	$opt2 = array(
		elgg_echo('rate_entities:all_users')=>'all_users',
		elgg_echo('rate_entities:only_admins')=>'only_admins',
		elgg_echo('rate_entities:no')=>false,
		);
	$value = get_plugin_setting('allow_reset_rate','rate_entities');
	$right_side .= '<h3>'.elgg_echo('rate_entities:allow_reset_rate').'</h3>';
	$right_side .= elgg_view('input/radio_without_br',array('internalname'=>'params[allow_reset_rate]','value'=>$value,'options'=>$opt2));
	$right_side .= '<br />';

	$options = array(
		elgg_echo('rate_entities:groups')=>'groups',
		elgg_echo('rate_entities:group_topics')=>'group_topics',
		elgg_echo('rate_entities:profile')=>'profile',
		elgg_echo('rate_entities:blogs')=>'blogs',
		);
	$right_side .= '<br />';
	$right_side .= '<h3>'.elgg_echo('rate_entities:add_rating_system').'</h3>';
	$value = unserialize(get_plugin_setting('add_rating_system','rate_entities'));
	$right_side .= elgg_view('input/check_boxes_without_label',array('options'=>$options,'internalname'=>'params[add_rating_system]','value'=>$value));
?>

<div>
	<div class="settings_left_sidebar">
		<?php echo $left_side;?>
	</div>
	
	<div class="settings_right_sidebar">
		<?php echo $right_side; ?>
	</div>
	<div class="clearfloat"></div>
</div>
<?php
	echo elgg_view('rate_entities/forms/elements/groups_table');
	
	$input_types = array(
		elgg_echo('rate_entities:enabled')=>'enabled',
		elgg_echo('rate_entities:disabled')=>'disabled',
	);
	$value = get_plugin_setting('rating_permissions_system','rate_entities');
	echo '<br />';
	echo '<h3>'.elgg_echo('rate_entities:rating_permissions_system').'</h3>';
	echo elgg_view('input/radio_without_br',array('internalname'=>'params[rating_permissions_system]','value'=>$value,'options'=>$input_types));
	echo '<br />';
	
	echo elgg_view('rate_entities/forms/elements/subtype_x_groups_table');
	echo elgg_view('rate_entities/forms/elements/links_x_groups_table');
?>