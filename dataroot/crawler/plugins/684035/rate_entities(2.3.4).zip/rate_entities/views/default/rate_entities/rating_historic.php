<?php
	/**
	 * @file views/default/rate_entities/rating_historic.php
	 * @brief Displays the rate historic of one entity
	 */

	if (($vars['entity']) && can_manage_rates()) {
		$rates = get_annotations($vars['entity']->guid,'','','generic_rate','',0,999999,0);
		$count = count($rates);

		$offset = get_input('offset',0);
		$rates = array_slice($rates,$offset,20);

		$baseurl = $vars['url'].'pg/rate_entities/rating_historic/'.$vars['entity']->guid;
		
?>
		<div class="rating_historic_container">
			<div>
				<div class="navigation_container">
					<?php
						echo elgg_view('navigation/pagination',array('offset'=>$offset,'count'=>$count,'baseurl'=>$baseurl,'limit'=>20));
					?>
				</div>
				<div class="clearfloat"></div>
			</div>
			<table class="rating_historic">
				<tr>
					<th><b><?php echo elgg_echo('rate_entities:username'); ?></b></th>
					<th><b><?php echo elgg_echo('rate_entities:date'); ?></b></th>
					<th><b><?php echo elgg_echo('rate_entities:hour'); ?></b></th>
					<th><b><?php echo elgg_echo('rate_entities:rate'); ?></b></th>
					<th><b><?php echo elgg_echo('rate_entities:delete'); ?></b></th>
				</tr>
<?php
		foreach ($rates as $rate) {
?>
			<tr>
				<td>
					<?php
						if ($rate->owner_guid) {
							$owner = get_entity($rate->owner_guid);
							echo $owner->name;
						} else {
							echo elgg_echo('rate_entities:not_loggedin_user');
						}
					?>
				</td>
				<td>
					<?php 
						$date = date("Y/m/d",$rate->time_created);
						echo $date;
					?>
				</td>
				<td>
					<?php 
						$hour = date("H:i",$rate->time_created);
						echo $hour;
					?>
				</td>
				<td>
					<?php 
						echo elgg_view('rate_entities/components/stars',array('rate'=>$rate->value));
					?>
				</td>
				<td>
					<?php
						// delete link
						echo elgg_view("output/confirmlink",array(
							'href'=>$vars['url']."action/rate_entities/delete_rate?rate_id=".$rate->id,
							'text'=>elgg_echo('rate_entities:delete'),
							));
					?>
				</td>
			</tr>
<?php
		}
?>
			</table>
		</div>
<?php
	}
?>