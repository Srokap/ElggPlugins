<?php
	/**
	 * @file views/default/rate_entities/components/display_reset_link.php
	 * @brief Displays the reset rate link that delete the rate by ajax and insert the rate_entities input at some div via javascript. 
	 */

	$container_id = get_rating_container_id($vars);
	$entity_guid = $vars['entity']->guid;
	
	if ($vars['display_reset_link'] || can_reset_rate($entity_guid)) {
		if (!get_input('rate_entities_js_settedup')) {
			echo elgg_view('js/rate_entities_js_lib',$vars);
		}
		
		$reset_link = '<a href="javascript: reset_rate('.$entity_guid.','.$container_id.'); ">'.elgg_echo('rate_entities:reset').'</a>';
	
		echo sprintf(elgg_echo('rate_entities:reset_rate'),$reset_link);
	}
?>