<?php
	/**
	 * @file mod/rate_entities/views/default/rating.php
	 * @brief Alias for the view "rate_entities/rating" that make the rating system "independent" of the plugin rate_entities
	 */

	echo elgg_view('rate_entities/rating',$vars);
?>