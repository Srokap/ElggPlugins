<?php
	/**
	 * @file views/default/rate_entities/rating.php
	 * @brief Shows the default input view for rating entities
	 */

	// If the admin setted up the rating input ID so hidden the rating div and when the page loads move It to the container defined by the admin
	if (get_plugin_setting('rating_input_container','rate_entities')) {
		$hidden = ' style="display:none" ';
	}
?>

<div <?php echo $class; ?> id="rating" <?php echo $hidden;?> >
	<?php
	// It is necessary to set one ID for each rating container because the javascript functions are based on It
	$vars['container_id'] = inc_rating_container_id($vars);

	// Get the default_input setted up by the admin and save It on the $vars for not use this function again into other views
	$default_input = $vars['default_input'] = get_rating_default_input_type();

	// If theres is no entity try to get someone
	if (!$vars['entity']) {
		if ($vars['entity'] = try_to_get_entity($vars)) {
			$vars['full'] = true;
			if ($vars['entity']->getSubtype() == 'link') {

				$vars['link_rating'] = true;
			}
		}
	}

	$class = '';
	
	// If It is rating for link then apply some CSS to the rating container
	if ($vars['link_rating']) {
		$class .= " link_rating ";
	}
	
	if ($default_input == 'ajax') {
		$class .= ' max_width ';
	}
?>
	<div class="<?php echo $class; ?>">
		<?php
			// Don't show rating info if the configuration say to do It
			if (!$vars['hide_rating_info']) {
				echo elgg_view('rate_entities/rating_info',$vars);
			}
			
			// If does not exists $vars['entity'] so lets try evaluate the link
			if ($vars['full'] || $vars['fullview']) {
				if ($default_input == 'radio') {
					echo elgg_view('rate_entities/input/radio_input',$vars);
				} else {
					echo elgg_view('rate_entities/input/ajax_input',$vars);
				}
			}
		?>
	</div>
	<?php 
		// If It is rating for link then the previous div has clear float and We must to put some clearfloat here
		if ($vars['link_rating']) {
	?>
			<div class="clearfloat"></div>
	<?php 
		}
	?>	
</div>