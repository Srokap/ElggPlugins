<?php
	/**
	 * @file views/default/rate_entities/forms/elements/links_x_groups_table.php
	 * @brief Displays the table for subtypes x groups menu into plugin settings
	 */
?>

<br />
<h3><?php echo elgg_echo('rate_entities:set_links_rating_permissions'); ?></h3>
<div class="ext_table_container">
		<div id="links_table_container" class="table_container">
			<?php echo elgg_view('rate_entities/forms/elements/links_table'); ?>
			
		</div>
		<?php
			echo elgg_view('rate_entities/forms/add_link');
		?>
		<div class="clearfloat"></div>
</div>