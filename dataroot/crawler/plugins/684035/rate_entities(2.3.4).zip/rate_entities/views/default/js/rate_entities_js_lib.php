<?php
	/**
	 * @file views/default/js/rate_entities_js_lib.php
	 * @brief Callback function for star rating jquery plugin
	 */

	$can_reset_rate = can_reset_rate($vars['entity']->guid);
	$can_reset_rate = ($can_reset_rate) ? ($can_reset_rate) : 'false';
	$allowed_rate = allow_rate($vars['entity']->guid);
	$allowed_rate = ($allowed_rate) ? true : 'false';
?>

<script>
	var cumulative_ajax_output = '';
	window.onload = attach_rating_input;
	
	function attach_rating_input() {
		var rating_container = "<?php echo get_plugin_setting('rating_input_container','rate_entities'); ?>";
		var parent = document.getElementById(rating_container);

		if (parent) {
			var rating = document.getElementById('rating');
			parent.appendChild(rating);
			rating.setAttribute('style','');
		}
	}
	
	function refresh_rate_as_stars(entity_guid,value,container_id) {
		var url = "<?php echo $vars['url']; ?>mod/rate_entities/actions/ajax/refresh_rate_as_stars.php?entity_guid=" + entity_guid + "&rate=" + value;
		container_id = (container_id) ? (container_id) : 1;
		
		if (window.XMLHttpRequest) { // code for IE7+, Firefox, Chrome, Opera, Safari
			var xmlhttp=new XMLHttpRequest();
		} else { // code for IE6, IE5
			var xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		}
		xmlhttp.onreadystatechange=function() {
			if (xmlhttp.readyState==4 && xmlhttp.status==200) {
				var rating_info_container = document.getElementById('rating_info_body_' + container_id);
				rating_info_container.innerHTML = xmlhttp.responseText;
			}
		};

		xmlhttp.open("GET",url,true);
		xmlhttp.send();
	}
	
	// Execute the ajax request
	function loadXMLDoc(url,output_id,input_id) {
		var can_reset_rate = <?php echo $can_reset_rate; ?>;
		output_id = (output_id) ? (output_id) : 'ajax_output_container_1';
		input_id = (input_id) ? (input_id) : 'rating_input_container_1';

		if (window.XMLHttpRequest) { // code for IE7+, Firefox, Chrome, Opera, Safari
			var xmlhttp=new XMLHttpRequest();
		} else { // code for IE6, IE5
			var xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		}
		xmlhttp.onreadystatechange=function() {
			if (xmlhttp.readyState==4 && xmlhttp.status==200) {
				var div = document.getElementById(output_id);
				div.innerHTML = div.innerHTML + xmlhttp.responseText;
				if (!can_reset_rate) {
					var rating_input_div = document.getElementById(input_id);

					if (rating_input_div) {
						rating_input_div.innerHTML = '';
					}
				}
			}
		};

		xmlhttp.open("GET",url,true);
		xmlhttp.send();
	}

	// Get guid of the entity that is being full viewed provided via some TODO: handler function
	// Obs: Do not use this function while listing entities on php flow, of course It does not work...
	function get_entity_guid() {
		var entity_guid = <?php echo $vars['entity']->guid; ?>;

		return entity_guid;
	}

	// Reset the rate made by the loggedin user
	function reset_rate(entity_guid,container_id) {
		ajax_rate(entity_guid,0,container_id);
	}

	// To save a rate for one entity via ajax
	function ajax_rate(entity_guid,value,container_id) {
		var allowed_rate= <?php echo $allowed_rate; ?>;
		
		container_id = (container_id) ? (container_id) : 1;
		
		var input_id = 'rating_input_container_' + container_id;
		var output_id = 'ajax_output_container_' + container_id;
		var rating_feedback_container_id = 'rating_feedback_container_' + container_id;

		var ajax_file = "<?php echo $vars['url'];?>mod/rate_entities/actions/ajax/add.php";
		var url = ajax_file + '?entity_guid=' + entity_guid + '&rate=' + value + '&output_id=' + output_id;
		
		var feedback_container = document.getElementById(rating_feedback_container_id);
		var rating_input_container = document.getElementById(input_id);

		if (value) {
			feedback_container.setAttribute('style','display: on');
			rating_input_container.setAttribute('style','display: none');
		} else if (!value && allowed_rate) {
			feedback_container.setAttribute('style','display: none');
			if (rating_input_container) {
				rating_input_container.setAttribute('style','display: on');
			} 
		}

		loadXMLDoc(url,output_id,input_id);
		refresh_rate_as_stars(entity_guid,value,container_id);
	}
</script>