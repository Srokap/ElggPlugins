<?php
	/**
	 * @file views/default/rate_entities/components_2/rating_feedback.php
	 * @brief Displays info about the rate done by the user
	 */

	$display_own_rate = $vars['display_own_rate'] = ($vars['display_own_rate']) ? ($vars['display_own_rate']) : get_plugin_setting('display_own_rate','rate_entities'); 
	$display_reset_link = $vars['display_reset_link'] = ($vars['display_reset_link']) ? ($vars['display_reset_link']) :can_reset_rate($vars['entity']->guid);
	$container_id = $vars['container_id'] = get_rating_container_id($vars);
	
	if (($display_own_rate != 'none') || ($display_reset_link)) {
		$user_rate = $vars['rate'] = ($vars['rate']) ? ($vars['rate']) : (get_entity_rate($vars['entity']->guid));

		if (!$user_rate) {
			$hidden = ' style="display: none" ';
		}
?>
		<div <?php echo $hidden; ?> class="reduced_text" id="rating_feedback_container_<?php echo $container_id; ?>">
			<b>(<?php
				$own_rate_vars = $vars;
				$own_rate_vars['class'] = 'own_rate_stars';
				echo elgg_view('rate_entities/components_2/display_own_rate',$own_rate_vars);
				echo elgg_view('rate_entities/components/display_reset_link',$vars);
				?>)
			</b>
		</div>
<?php
	}
?>