<?php
	/**
	 * @file views/default/rate_entities/forms/elements/subtype_x_groups_table.php
	 * @brief Displays the table for subtypes x groups menu into plugin settings
	 */


	if (get_plugin_setting('rating_permissions_system','rate_entities')=='enabled') {
		$options = array(
			'types'=>'group',
			'limit'=>999999,
			);
		$groups = elgg_get_entities($options);
		$statistics = get_entity_statistics();
		
		if ($groups) {
?>
			<br />
			<h3><?php echo elgg_echo('rate_entities:set_subtype_rating_permissions'); ?></h3>
			<span class="reduced_text"><?php echo elgg_echo('rate_entities:rating_permissions_explanation');?></span>
			<div class="ext_table_container">
				<div class="table_container">
					<table class="rate_entities_table" >
						<tr>
							<th class="rate_entities_td"><div class="groups_table_first_col"></div></th>
							
							<th class="rate_entities_td">
								<div class="groups_table_col">
									<?php echo elgg_echo('rate_entities:public'); ?>
								</div>
							</th>
							
							<th class="rate_entities_td">
								<div class="groups_table_col">
									<?php echo elgg_echo('rate_entities:loggedin_users'); ?>
								</div>
							</th>
		
							<th class="rate_entities_td">
								<div class="groups_table_col">
									<?php echo elgg_echo('rate_entities:admins'); ?>
								</div>
							</th>
		
							<?php
								foreach($groups as $group) {
							?>
									<th class="rate_entities_td">
										<div class="groups_table_col">
											<a href="<?php echo $group->getUrl(); ?>"><?php echo $group->name; ?></a>
										</div>
									</th>
								<?php
								}
								?>
						</tr>
						
						<tr>
							<?php 
								$user_evaluators = unserialize(get_plugin_setting('user_evaluators','rate_entities'));
							?>
							<td class="rate_entities_td">
								<div class="groups_table_first_col">
									<?php echo elgg_echo('item:user'); ?>
								</div>
							</td>
							
							<td class="rate_entities_td">
								<div class="groups_table_col">
									<?php 
										$checked = '';
										if (in_array(2,$user_evaluators)) {
											$checked = ' checked="checked" ';
										}
									?>
									<input type="checkbox" name="params[user_evaluators][]" value="2" <?php echo $checked; ?> />
								</div>
							</td>
							
							<td class="rate_entities_td">
								<div class="groups_table_col">
									<?php
										$checked= '';
										if (in_array(1,$user_evaluators)) {
											$checked = ' checked="checked" '; 
										}
									?>
									<input type="checkbox" name="params[user_evaluators][]" value="1" <?php echo $checked; ?> />
								</div>
							</td>
							
							<td class="rate_entities_td">
								<div class="groups_table_col">
									<?php 
										$checked= '';
										if (in_array('admins',$evaluators)) {
											$checked = ' checked="checked" ';
										}
									?>
									<input type="checkbox" name="params[user_evaluators][]" value="admins" <?php echo $checked; ?> />
								</div>
							</td>
					<?php
						foreach($groups as $group) {
					?>
								<td class="rate_entities_td">
									<div class="groups_table_col">
										<?php 
											$checked = '';
											if (in_array($group->guid,$user_evaluators)) {
												$checked = ' checked="checked" ';
											}
										?>
										<input type="checkbox" name="params[user_evaluators][]" value="<?php echo $group->guid; ?>" <?php echo $checked; ?> />
									</div>
								</td>
						<?php
						}
						?>
						</tr>
						
						<?php
							foreach($statistics['object'] as $subtype=>$count) {
								$value = serialize(array($group->guid,$subtype));
								$evaluators = unserialize(get_plugin_setting($subtype.'_evaluators','rate_entities'));
						?>
									<tr>
										<td class="rate_entities_td">
											<div class="groups_table_first_col">
												<!-- If the user do not choose any option then We should pass a null group for the input value be setted up by the function set_plugin_setting() -->
												<input type="hidden" name="params[<?php echo $subtype; ?>_evaluators][]" value="null"/>
												<?php echo elgg_echo('item:object:'.$subtype); ?>
											</div>
										</td>
										
										<td class="rate_entities_td">
											<div class="groups_table_col">
												<?php 
													$checked = '';
													if (in_array(2,$evaluators)) {
														$checked = ' checked="checked" ';
													}
												?>
												<input type="checkbox" name="params[<?php echo $subtype; ?>_evaluators][]" value="2" <?php echo $checked; ?> />
											</div>
										</td>
										
										<td class="rate_entities_td">
											<div class="groups_table_col">
												<?php
													$checked= '';
													if (in_array(1,$evaluators)) {
														$checked = ' checked="checked" '; 
													}
												?>
												<input type="checkbox" name="params[<?php echo $subtype; ?>_evaluators][]" value="1" <?php echo $checked; ?> />
											</div>
										</td>
										
										<td class="rate_entities_td">
											<div class="groups_table_col">
												<?php 
													$checked= '';
													if (in_array('admins',$evaluators)) {
														$checked = ' checked="checked" ';
													}
												?>
												<input type="checkbox" name="params[<?php echo $subtype; ?>_evaluators][]" value="admins" <?php echo $checked; ?> />
											</div>
										</td>
								<?php
									foreach($groups as $group) {
								?>
											<td class="rate_entities_td">
												<div class="groups_table_col">
													<?php 
														$checked = '';
														if (in_array($group->guid,$evaluators)) {
															$checked = ' checked="checked" ';
														}
													?>
													<input type="checkbox" name="params[<?php echo $subtype; ?>_evaluators][]" value="<?php echo $group->guid; ?>" <?php echo $checked; ?> />
												</div>
											</td>
									<?php
									}
									?>
									</tr>
								<?php
								}
								?>
					</table>
				</div>
			</div>
<?php
		}
	}
?>