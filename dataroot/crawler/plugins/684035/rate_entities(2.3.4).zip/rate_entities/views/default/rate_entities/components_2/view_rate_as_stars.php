<?php
	/**
	 * @file views/default/rate_entities/components_2/view_rate_as_stars.php
	 * @brief Displays the rate average as one stars picture
	 * 
	 * @uses $vars['rate'] Used into "rate_entities/stars" view
	 * @uses $vars['rates_counter'] If filled It will overlap the rates counter of $vars['entity']
	 * @uses $vars['entity'] If pass $vars['rates_counter'] than $rate['entity'] will be not used
	 */

	$rates_counter = $vars['rates_counter'];
	
	if (!isset($rates_counter)) {
		if ($vars['entity']) {
			$rates_counter = count_entity_rates($vars['entity']->guid);
		}
	}
	
?>

<div class="view_rate_as_stars">
	<?php
		echo elgg_view('rate_entities/components/stars',$vars);
		echo '('.elgg_echo('rate_entities:rates').' '.$rates_counter.')';
	?>
</div>