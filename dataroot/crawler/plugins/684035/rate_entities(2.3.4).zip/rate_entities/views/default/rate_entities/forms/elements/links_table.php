<?php
	/**
	 * @file views/default/rate_entities/forms/elements/links_table.php
	 * @brief Mount the table for set links evaluators
	 */

	$options = array(
		'types'=>'group',
		'limit'=>999999,
		);
	$groups = elgg_get_entities($options);

	if ($groups) {
?>
		<table class="rate_entities_table" >
			<tr>
				<th class="rate_entities_td links_first_col"><div class="groups_table_first_col"></div></th>
				
				<th class="rate_entities_td">
					<div class="groups_table_col">
						<?php echo elgg_echo('rate_entities:public'); ?>
					</div>
				</th>
				
				<th class="rate_entities_td">
					<div class="groups_table_col">
						<?php echo elgg_echo('rate_entities:loggedin_users'); ?>
					</div>
				</th>
		
				<th class="rate_entities_td">
					<div class="groups_table_col">
						<?php echo elgg_echo('rate_entities:admins'); ?>
					</div>
				</th>
		
				<?php
					foreach($groups as $group) {
				?>
						<th class="rate_entities_td">
							<div class="groups_table_col">
								<a href="<?php echo $group->getUrl(); ?>"><?php echo $group->name; ?></a>
							</div>
						</th>
					<?php
					}
					?>
			</tr>
			
			<?php
				$options = array(
					'type'=>'object',
					'subtype'=>'link',
					'limit'=>999999
					);
				$link_entities = elgg_get_entities($options);
				
				if ($link_entities) {
					foreach($link_entities as $url_entity) {
						$value = serialize(array($group->guid,$url_entity->title));
						$evaluators = unserialize(get_plugin_setting($url_entity->title.'_evaluators','rate_entities'));
			?>
						<tr>
							<td class="rate_entities_td">
								<div class="links_first_col">
									<input type="hidden" name="params[<?php echo $url_entity->title; ?>_evaluators][]" value="null" />
									<?php echo elgg_echo($url_entity->title); ?>
								</div>
							</td>
							
							<td class="rate_entities_td">
								<div class="groups_table_col">
									<?php 
										$checked = '';
										if (in_array(2,$evaluators)) {
											$checked = ' checked="checked" ';
										}
									?>
									<input type="checkbox" name="params[<?php echo $url_entity->title; ?>_evaluators][]" value="2" <?php echo $checked; ?> />
								</div>
							</td>
							
							<td class="rate_entities_td">
								<div class="groups_table_col">
									<?php
										$checked= '';
										if (in_array(1,$evaluators)) {
											$checked = ' checked="checked" '; 
										}
									?>
									<input type="checkbox" name="params[<?php echo $url_entity->title; ?>_evaluators][]" value="1" <?php echo $checked; ?> />
								</div>
							</td>
							
							<td class="rate_entities_td">
								<div class="groups_table_col">
									<?php 
										$checked= '';
										if (in_array('admins',$evaluators)) {
											$checked = ' checked="checked" ';
										}
									?>
									<input type="checkbox" name="params[<?php echo $url_entity->title; ?>_evaluators][]" value="admins" <?php echo $checked; ?> />
								</div>
							</td>
					<?php
						foreach($groups as $group) {
					?>
							<td class="rate_entities_td">
								<div class="groups_table_col">
									<?php 
										$checked = '';
										if (in_array($group->guid,$evaluators)) {
											$checked = ' checked="checked" ';
										}
									?>
									<input type="checkbox" name="params[<?php echo $url_entity->title; ?>_evaluators][]" value="<?php echo $group->guid; ?>" <?php echo $checked; ?> />
								</div>
							</td>
					<?php
						}
					?>
						</tr>
			<?php
					}
				}
			?>
		</table>
<?php
	} 
?>