<?php
	/**
	 * @file views/default/rate_entities/components/rate_entities_js.php
	 * @brief Include the required javascript files for rate_entities ajax input
	 */

	if(!get_input('rate_entities_js_settedup')) {
		set_input('rate_entities_js_settedup',true);
?>
		<link rel="stylesheet" href="<?php echo $vars['url']; ?>mod/rate_entities/star_rating/jquery.rating.css" />
		<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/rate_entities/star_rating/jquery.rating.js" ></script>
		<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/rate_entities/star_rating/jquery.MetaData.js"></script>
<?php
		// Functions that set up the rate_entities plugin on the star rating javascript plugin
		echo elgg_view('js/set_rate_entities',$vars);
		// Javascript functions lib of rate_entities plugin 
		echo elgg_view('js/rate_entities_js_lib',$vars);
	}
?>