<?php
	/**
	 * @file views/default/js/set_rate_entities.php
	 * @brief Set rate_entities plugin on star rating system
	 */

	$container_id = get_rating_container_id($vars);
?>

<script type="text/javascript">
	// Register the callback function provided by javascript star rating plugin
	$(function(){
	 $('.rate_star').rating({
	  callback: function(value, link){
			ajax_rate(get_entity_guid(),value,<?php echo $container_id; ?>);
	  }
	 });
	});
</script>