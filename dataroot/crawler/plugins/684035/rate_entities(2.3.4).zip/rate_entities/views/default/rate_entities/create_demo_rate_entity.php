<?php
	/**
	 * @file views/default/rate_entities/create_demo_rate_entity.php
	 * @brief Create demo rate entity form
	 */

	$action = $vars['url'].'action/rate_entities/create_demo_rate_entity';
	
	$form_body = '';
	$form_body .= elgg_view('input/submit',array('value'=>elgg_echo('rate_entities:create')));
	
	$form = elgg_view('input/form',array('body'=>$form_body,'action'=>$action));
	echo $form;
?>