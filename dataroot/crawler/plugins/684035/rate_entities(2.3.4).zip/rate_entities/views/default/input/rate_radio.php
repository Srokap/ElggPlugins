<?php
	/**
	 * @file views/default/input/rate_radio.php
	 * @brief An view copied of elgg because we have have to remove a <br /> tag from it
	 */

	$class = $vars['class'];

	if(!$class)
	{
		$class = "input-radio";
	}

	foreach($vars['options'] as $label => $option)
	{
		if($option != $vars['value'])
		{
			$selected = "";
		}
		else
		{
			$selected = "checked = \"checked\"";
		}
		$labelint = (int) $label;
		if("{$label}" == "{$labelint}")
		{
			$label = $option;
		}
		if($vars['disabled'])
		{
			$disabled = ' disabled="yes" '; 
		}
			echo "<input type=\"radio\" $disabled {$vars['js']} name=\"{$vars['internalname']}\" value=\"".htmlentities($option, null, 'UTF-8')."\" {$selected} class=\"$class\" />{$label}";
    }
		echo "<br/>";
?> 