<?php
	/**
	 * @file views/default/rate_entities/forms/elements/groups_table.php
	 * @brief Displays the groups select table for plugin settings form
	 */

	
	$options = array(
		'types'=>'group',
		'limit'=>999999,
		);
	$groups = elgg_get_entities($options);
	if ($groups) {
?>
		<br />
		<hr />
		<br />
		<h3><?php echo elgg_echo('rate_entities:settings_by_groups'); ?></h3>
		<div class="ext_table_container">
			<div class="table_container">
				<table class="rate_entities_table">
					<tr>
						<th class="rate_entities_td"><div class="groups_table_first_col"></div></th>
						
						<th class="rate_entities_td">
							<div class="groups_table_col">
								<?php echo elgg_echo('rate_entities:loggedin_users'); ?>
							</div>
						</th>
						
						<th class="rate_entities_td">
							<div class="groups_table_col">
								<?php echo elgg_echo('rate_entities:admins'); ?>
							</div>
						</th>
						
						<?php
							foreach($groups as $group) {
						?>
								<th class="rate_entities_td">
									<div class="groups_table_col">
										<a href="<?php echo $group->getUrl(); ?>"><?php echo $group->name; ?></a>
									</div>
								</th>
						<?php
							}
						?>
					</tr>
		
					<!-- Manage rates table line -->
					<?php
						// Get the groups allowed to manage rates of entities
						$allowed_manage = unserialize(get_plugin_setting('allowed_manage_rates','rate_entities'));
					?>
					<tr>
						<td class="rate_entities_td">
							<div class="groups_table_first_col">
								<?php echo elgg_echo('rate_entities:allow_manage_rates'); ?>
								<input type="hidden" name="params[allowed_manage_rates][]" value="null" />
								</div>
						</td>
						
						<td class="rate_entities_td">
							<div class="groups_table_col">
								<input type="checkbox" name="params[allowed_manage_rates][]" value="1" disabled="disabled" />
								</div>
						</td>
						
						<td class="rate_entities_td">
							<div class="groups_table_col">
								<?php
									if (in_array('admins',$allowed_manage)) {
										$admin_checked = ' checked="checked" ';
									}
								?>
								<input type="checkbox" name="params[allowed_manage_rates][]" value="admins" <?php echo $admin_checked; ?>/>
							</div>
						</td>
						
						<?php
							foreach($groups as $group) {
						?>
								<td class="rate_entities_td">
									<div class="groups_table_col">
										<?php
											$checked= '';
											if (in_array($group->guid,$allowed_manage)) {
												$checked = ' checked="checked" ';
											}
										?>
										<input type="checkbox" name="params[allowed_manage_rates][]" value="<?php echo $group->guid; ?>" <?php echo $checked; ?>/>
									</div>
								</td>
						<?php
							}
						?>
					</tr>
				</table>
			</div>
		</div>
<?php
	}
?>