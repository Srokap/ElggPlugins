<?php
	/**
	 * @file views/default/rate/rate.php
	 * @brief For compatibily with Miguel Montes rate plugin
	 */

	if(!isset($vars['full']))
	{
		$vars['full']= true;
	}

	echo elgg_view('rate_entities/rating',$vars);
?>