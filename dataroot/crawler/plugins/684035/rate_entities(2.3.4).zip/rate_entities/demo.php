<?php
	/**
	 * @file demo.php
	 * @brief Shows a example of using the rate_entities plugin
	 */

	require_once(dirname(dirname(dirname(__FILE__))).'/engine/start.php');
	
	// Only admins can see it
	admin_gatekeeper();
	
	// To be possible see the admin subitems
	set_context('admin');

	$area2 = '';
	// Get the demo rate entity creating form
	$area2 .= elgg_view('rate_entities/create_demo_rate_entity');
	$options = array(
		'types'=>'object',
		'subtypes'=>'demo_rate',
		'limit'=>999999,
		'full_view'=>false,
		);
		
	$area2 .= '<hr />';
	$area2 .= elgg_echo('rate_entities:view_entity_rate_explaining');;
	$area2 .= '<br /><br />';
	
	
	// List the demo rate entities created in the current database
	$area2 .= elgg_list_entities($options);

	$body = elgg_view_layout('two_column_left_sidebar',$area1,$area2);
	
	page_draw(elgg_echo('rate_entities:demo'),$body);
?>