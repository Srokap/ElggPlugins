<?php
	/**
	 * @file start.php
	 * @brief Include the plugin in the elgg system
	 */

	/**
	 * Function that init the rate_entities plugin in the elgg
	 */
	function rate_entities_init()
	{
		global $CONFIG;

		register_page_handler('rate_entities','rate_entities_page_handler');
		
		register_translations($CONFIG->pluginspath.'rate_entities/languages/');
		
		elgg_extend_view('css','rate_entities/css');

		// Extend the views for including the rate system in the other plugins (only groups plugin for now) 
		//rate_entities_extend_views();
		
		elgg_extend_view('page_elements/header_contents','rate_entities/rating');
	}
	
	// Including the rate_entities functions lib
	include('lib/rate_entities.php');

	/**
	 * Handle the page request for rate_entities plugin
	 * 
	 * @param $page
	 */
	function rate_entities_page_handler($page)
	{
		if(isset($page[0]))
		{
			global $CONFIG;

			switch($page[0])
			{
				case 'demo':
					include($CONFIG->pluginspath.'rate_entities/demo.php');
					break;
				case 'rating_historic':
					set_input('entity_guid',$page[1]);
					include($CONFIG->pluginspath.'rate_entities/rating_historic.php');
					break;
			}
		}
	}

	/**
	 * Include the rate_entities submenu item for admins and set the default configuration for the plugin
	 * on the first time that the user has enabled the plugin
	 */
	function rate_entities_pagesetup() {
		if (((get_context()=='admin') || (get_context() == 'rate_entities')) && isadminloggedin())
		{
			global $CONFIG;

			// init_rate_entities_settings() will be executed only once
			if (!get_plugin_setting('init_settings','rate_entities')) {
				init_rate_entities_settings();
			}
			add_submenu_item(elgg_echo('rate_entities:demo'),$CONFIG->wwwroot.'pg/rate_entities/demo','rate_entities');
			add_submenu_item(elgg_echo('rate_entities:doc'),$CONFIG->wwwroot.'mod/rate_entities/doc/index.html','rate_entities');
		}
	}

	/**
	 * Serialize the settings passed as array because the plugin private setting do not support to array inputs
	 * @param $hook
	 * @param $type
	 * @param $returnvalue
	 * @param $params
	 */
	function rate_entities_settings_handler($hook,$type,$returnvalue,$params) {
		if ($params['plugin'] == 'rate_entities') {
			if (is_array($params['value'])) {
				return serialize($params['value']);
			}
		}
	}
	
	/**
	 * Register the rate_entities plugin as a rating system provider
	 * 
	 * @param $hook
	 * @param $type
	 * @param $returnvalue
	 * @param $params
	 */
	function rate_entities_register($hook,$type,$returnvalue,$params) {
		return 'rate_entities';
	}
	
	function get_entities_by_rate_average_hook($hook,$type,$returnvalue,$params) {
		return get_entities_by_rate_average($params);
	}
	
	global $CONFIG;

	register_elgg_event_handler('pagesetup','system','rate_entities_pagesetup');
	register_elgg_event_handler('init','system','rate_entities_init');

	register_action('rate_entities/add',true,$CONFIG->pluginspath.'rate_entities/actions/add.php');
	register_action('rate_entities/add_link',false,$CONFIG->pluginspath.'rate_entities/actions/add_link.php',true);
	register_action('rate_entities/delete_rate',false,$CONFIG->pluginspath.'rate_entities/actions/delete_rate.php');
	register_action('rate_entities/create_demo_rate_entity',false,$CONFIG->pluginspath.'rate_entities/actions/create_demo_rate_entity.php');
	register_action('rate_entities/delete_entity',false,$CONFIG->pluginspath.'rate_entities/actions/delete_entity.php');
	
	register_plugin_hook('plugin:setting','plugin','rate_entities_settings_handler');
	register_plugin_hook('rating_system','plugin','rate_entities_register');
	
	// Catch the hook of another plugins ask for the entities ordered by rate average
	register_plugin_hook('get_entities_by_rate_average','plugin','get_entities_by_rate_average_hook');
?>