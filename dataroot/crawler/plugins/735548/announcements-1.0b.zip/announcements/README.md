# Group Announcements for Elgg 1.8 #

## Features ##
* Adds the ability for groups to post announcements to all their members.  
* Group members get the announcements in their inbox and can comment on the announcements.
