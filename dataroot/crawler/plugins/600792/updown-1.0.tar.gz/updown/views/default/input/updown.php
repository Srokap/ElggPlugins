<?php


$entity = $vars['entity'];
$__elgg_ts = time();
$__elgg_token = generate_action_token($__elgg_ts);

$voteup = '<a href="'.$CONFIG->wwwroot.'pg/updown/edit?action=voteup&id='.$entity->guid.'&__elgg_ts='.$__elgg_ts.'&__elgg_token='.$__elgg_token.'">'.elgg_echo('updown:linktext:voteup').'</a>';
$votedown = '<a href="'.$CONFIG->wwwroot.'pg/updown/edit?action=votedown&id='.$entity->guid.'&__elgg_ts='.$__elgg_ts.'&__elgg_token='.$__elgg_token.'">'.elgg_echo('updown:linktext:votedown').'</a>';

$votelink = elgg_echo('updown:label:votecount').': '.$count_total = $entity->countAnnotations($name="generic_updown");


if($entity->owner_guid == get_loggedin_userid()){


	
}


elseif(updown_check_not_rated($entity)){
$votelink .= ' [ '.$voteup.' | ';
$votelink .= $votedown.' ]';
}

else{
	
$votelink .= ' | '.elgg_echo('updown:message:alreadyvoted');
	
}
echo $votelink;


?>