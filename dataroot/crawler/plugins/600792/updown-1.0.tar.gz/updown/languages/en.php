<?php
$english = array(
	'updown:success'	=> 'Your vote was reigstered',
	'updown:failure'	=> 'Could not register your vote',
	
	'updown:linktext:voteup'	=> 'Vote up',
	'updown:label:votecount'	=> 'Total Votes',
	'updown:linktext:votedown'	=> 'Vote down',
	'updown:message:alreadyvoted'	=> 'You have already voted on this item',
	'updown:river:upvoted' => "%s upvoted",
	'updown:river:upvote' => ' ',
	'updown:river:downvoted' => "%s downvoted",
	'updown:river:downvote' => ' ',

);

add_translation("en",$english);
?>