<?php
/**
 * A plugin to share links on an Elgg site
 *
 * @package FnxtUpDown
 * @author Shyam Somanadh
 * @author Frontiernxt
 * @link http://frontiernxt.com/
 */

	function updown_init()
	{
		global $CONFIG;

		register_page_handler('updown','updown_page_handler');
		register_action('updown/edit', false, $CONFIG->pluginspath.'updown/actions/edit.php');
		
		return true;
	}

	
	function updown_page_handler($page){
		
		global $CONFIG;
		$controller  = strtolower($page[0]);
		
		switch($controller){
		
			case 'edit':
			include $CONFIG->pluginspath . 'updown/actions/edit.php';
			break;
			
		}	
		
		
	}

	
	
	//Function to do a quick version check to x.x
	function updown_version_check(){
		
		
		$version = get_version($humanreadable=true);
		return $matched = substr($version, 0,3);
		
		
	}	
	
	
	//Function to check if you have already voted on the entity
	function updown_check_not_rated($entity){
		
		$annotations = $entity->getAnnotations('generic_updown');
			foreach ($annotations as $annotation){
				if ($annotation->owner_guid == $_SESSION['guid']){
					return false;
				}
			}
			return true;
		
	}

	
	//Object to store plugin-specific data in, not used for anything now
	function updown_get_counter_entity(){
		
			$matched = updown_version_check();

			if($matched == '1.6'){
				
				$counter = get_entities($type="object", $subtype="updown_stats", $owner_guid=0, $order_by="", $limit=1, $offset=0, $count=false, $site_guid=0, $container_guid=null, $timelower=0, $timeupper=0);
				
				if($counter)
				return $counter[0];
				
				else{
					
					$counter = new ElggObject();
					$counter->subtype = "updown_stats";
					
					if($counter->save())
					return $counter;
					else
					return false;
					
				}
				
			}
			
			if($matched == '1.7'){
				
				$options = array('type' => 'object',
								 'subtype' => 'updown_stats',
								'limit' => 1);
				$counter = elgg_get_entities($options);
				
				
				if($counter){
				return $counter[0];
				}
				
				else{
					
					$counter = new ElggObject();
					$counter->subtype = "updown_stats";
					
					if($counter->save())
					return $counter;
					else
					return false;
					
				}
				
			}
		
		
		
	}
	
	
	//Function to vote up an entity. $referer will determine if the forward will go the referring page or the entity's URL
	function updown_voteup($id, $referer = FALSE){
		
		
			$entity = get_entity($id);
			
			if($entity instanceof ElggEntity){
				$entity->annotate('generic_updown', $vote = 1, $access_id=ACCESS_PUBLIC, $_SESSION['guid']);
				add_to_river('river/object/updown/upvote','create',$_SESSION['user']->guid,$entity->guid);
				system_message(elgg_echo('updown:success'));
				if(!$referer)
				forward($entity->geturl());
				else
				forward($_SERVER['HTTP_REFERER']);
			
			}
			else{
				
				register_error(elgg_echo('updown:failure'));
				forward();
				
			}
		
	}
	
	
	//Function to vote down an entity. $referer will determine if the forward will go the referring page or the entity's URL
	function updown_votedown($id, $referer = FALSE){
		
		
			$entity = get_entity($id);
			
			if($entity instanceof ElggEntity){
				$entity->annotate('generic_updown', $vote = -1, $access_id=ACCESS_PUBLIC, $_SESSION['guid']);
				add_to_river('river/object/updown/downvote','create',$_SESSION['user']->guid,$entity->guid);			
				system_message(elgg_echo('updown:success'));
				if(!$referer)
				forward($entity->geturl());
				else
				forward($_SERVER['HTTP_REFERER']);
			
			}
			else{
				
				register_error(elgg_echo('updown:failure'));
				forward();
				
			}
		
	}	
	

		
		
	
	
	register_elgg_event_handler('init', 'system', 'updown_init');
?>