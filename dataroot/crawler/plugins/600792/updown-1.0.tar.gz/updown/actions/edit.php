<?php

	// must be logged in
	gatekeeper();
	
	// must have security token 
	action_gatekeeper();
	
	
	// get parameters that were posted
	$action = strtolower(get_input('action'));
	$id = (int)get_input('id');
	
		
		if($action == 'voteup'){
			
			updown_voteup($id, $referer = TRUE);
		}
		
		elseif($action == 'votedown'){
			
			updown_votedown($id, $referer = TRUE);
		}
		
		
		else{
			
			register_error(elgg_echo('updown:failure'));
			forward($_SERVER['HTTP_REFERER']);	
			
		}


?>