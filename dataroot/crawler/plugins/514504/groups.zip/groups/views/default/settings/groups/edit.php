<?php
	$hidden_groups = $vars['entity']->hidden_groups;
	if (!$hidden_groups) $hidden_groups = 'no';
	
	$ocultarinscripcion_groups = $vars['entity']->ocultarinscripcion_groups;
	if (!$ocultarinscripcion_groups) $ocultarinscripcion_groups = 'no';	
?>	
<p>
	<?php echo elgg_echo('groups:allowhiddengroups'); ?>
	
	<?php
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[hidden_groups]',
			'options_values' => array(
				'no' => elgg_echo('option:no'),
				'yes' => elgg_echo('option:yes')
			),
			'value' => $hidden_groups
		));
		?>
</p>
<!-- Para poder ocultar la creaci�n de grupos -->
<p>		
		<?php echo elgg_echo('groups:ocultarinscripciongroups'); ?>
		
		<?php				
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[ocultarinscripcion_groups]',
			'options_values' => array(
				'no' => elgg_echo('option:no'),
				'yes' => elgg_echo('option:yes')
			),
			'value' => $ocultarinscripcion_groups
		));		
	?>
</p>