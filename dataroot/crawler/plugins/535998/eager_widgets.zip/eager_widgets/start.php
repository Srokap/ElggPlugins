<?php
/**
 * Eager widget loading
 * @author Cash Costello
 * @license GPL 2
 */

// this space intentionally left blank
