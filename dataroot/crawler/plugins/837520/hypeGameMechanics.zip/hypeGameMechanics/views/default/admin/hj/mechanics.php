<?php

forward('points/badges');