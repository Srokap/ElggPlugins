<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of hjGift
 *
 * @author Ismayil Khayredinov
 */
class hjGift {
	//put your code here
}

?>
