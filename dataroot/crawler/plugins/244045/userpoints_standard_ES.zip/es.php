<?php
 
    $spanish= array(	
        'userpoints_standard:blog' => 'Puntos por hacer un nuevo tema en tu blog:',
        'userpoints_standard:group' => 'Puntos por comenzar un grupo:',
        'userpoints_standard:page_top' => 'Puntos por agregar una página:',
        'userpoints_standard:comment' => 'Puntos por dejar un comentario:',
        'userpoints_standard:poll' => 'Puntos por hacer una encuesta:',
        'userpoints_standard:pollvote' => 'Puntos por votar en una encuesta:',
        'userpoints_standard:login' => 'Puntos por ingresar el sitio (log in):',
        'userpoints_standard:phototag' => 'Puntos por dejar una etiqueta en una foto:',
        'userpoints_standard:riverpost' => 'Puntos por dejar un mensaje en el river:',
        'userpoints_standard:thewire' => 'Puntos por dejar un mensaje en La Red:',
        'userpoints_standard:group_topic_post' => 'Puntos por comenzar un tema en el foro de un grupo:',
        'userpoints_standard:invite' => 'Puntos por invitar un amigo:',
        'userpoints_standard:login_threshold' => 'Cuánto tiempo tiene que pasar antes de dar puntos por ingresar el sitio (login) de nuevo?',
        'userpoints_standard:1hour' => '1 Hora',
        'userpoints_standard:4hours' => '4 Horas',
        'userpoints_standard:8hours' => '8 Horas',
        'userpoints_standard:12hours' => '12 Horas',
        'userpoints_standard:1day' => '1 Día',
        'userpoints_standard:1week' => '1 Semana',
        'userpoints_standard:1month' => '1 Mes',
        'userpoints_standard:delete' => 'Borrar los puntos cuando está eliminado el contenido?'
    );
 
    add_translation("es", $spanish);
 
?>
