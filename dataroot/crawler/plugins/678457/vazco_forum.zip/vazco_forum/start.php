<?php

/**
 * Elgg vazco_forum plugin
 *
 * @author Michal Zacher [michal.zacher@gmail.com]
 * @website www.elggdev.com
 */

/********************************************
 * VAZCO_TOOLS (don't modify this code)
 *******************************************/
	//register handler for this plugin's tools library
	register_elgg_event_handler('init', 'tools', 'vazco_forum_tools_init',99999999999); //should be generated as 99999999999 - time()
	
	if (!function_exists('vazco_init_tools')){
		function vazco_init_tools($plugin, $time){
			//register handler that will invoke tools library in case it was not yet invoked
			if (!$_REQUEST['__toolshandler']){
				$_REQUEST['__toolshandler'] = 1;
				trigger_elgg_event('init','tools');
			}
		}
	}

	function vazco_forum_tools_init(){
		if (!$_REQUEST['__toolson']){
			$_REQUEST['__toolson'] = 1;
			require_once(dirname(__FILE__).'/models/tools.php');
		}
	}

/********************************************
 * END OF VAZCO_TOOLS
 *******************************************/


	function vazco_forum_init() {
		//init tools handler if it was not set before
		vazco_init_tools();
		//$forum = get_entities('object','forum');
		//dumpdie($forum[0]->contenttype);
		global $CONFIG;
		require_once(dirname(__FILE__)."/models/model.php");
		//vazco_forum::updateSticky();
		define('TOOLS_TRANSLATIONS','en,sv,de,fr,pl');
		// register page handler
		register_page_handler('forum','vazco_forum_page_handler');

		// extend views
		extend_view('css','vazco_forum/css');
		extend_view('metatags','metatags/jquery_tools');
		extend_view('css','vazco_forum/vazco_tools/css');
	
		// add menus
		add_menu(elgg_echo('vazco_forum:forum'),$CONFIG->wwwroot.'pg/forum/siteforum', 'forum');
		
		// Register some actions
		register_action('forum/edit', false, $CONFIG->pluginspath .'vazco_forum/actions/edit.php');
		register_action('forum/delete', false, $CONFIG->pluginspath .'vazco_forum/actions/delete.php');
		register_action('forum/comment', false, $CONFIG->pluginspath .'vazco_forum/actions/comment.php');
		register_action('forum/close', false, $CONFIG->pluginspath .'vazco_forum/actions/close.php');
		register_action('forum/sticky', false, $CONFIG->pluginspath .'vazco_forum/actions/sticky.php');
		register_action('forum/deletepost', false, $CONFIG->pluginspath .'vazco_forum/actions/deletepost.php');
		register_action('forum/subscribe', false, $CONFIG->pluginspath .'vazco_forum/actions/subscribe.php');
		register_action('forum/unsubscribe', false, $CONFIG->pluginspath .'vazco_forum/actions/unsubscribe.php');
		register_entity_url_handler('vazco_forum_url','object', 'forum');
		register_elgg_event_handler('create','annotation','vazco_forum_create_annotation');
		register_elgg_event_handler('create','object','vazco_forum_create');

		register_plugin_hook('permissions_check', 'site', 'vazco_forum_permission_check',1);
		register_plugin_hook('permissions_check:metadata', 'object', 'vazco_forum_metadata_permissions',1);
		
		register_plugin_hook('mainpagewidgets', 'vazco_mainpage', 'vazco_forum_add_mainpagewidgets',2);
	}

	function vazco_forum_add_mainpagewidgets($event, $object_type, $object, $params){
		$mainpageWidgets = $params['widgets'];
		
		$container1 = get_plugin_setting('forum1','vazco_forum');
		$container2 = get_plugin_setting('forum2','vazco_forum');
		$container3 = get_plugin_setting('forum3','vazco_forum');
	
		$widget = new mainpageWidget(
			'vazco_forum'
			,elgg_echo("vazco_forum:forum:widget")
			,elgg_echo("vazco_forum:forum:desc")
			,'vazco_forum/widgets/forum'
		);
		$mainpageWidgets->addWidget($widget);
	
		$widget = new mainpageWidget(
			'vazco_forum1'
			,elgg_echo("vazco_forum:forum:1")
			,elgg_echo("vazco_forum:forum:1:desc")
			,'vazco_forum/widgets/forum1'
		);
		if ($container1)
			$mainpageWidgets->addWidget($widget);
		
		$widget = new mainpageWidget(
			'vazco_forum2'
			,elgg_echo("vazco_forum:forum:2")
			,elgg_echo("vazco_forum:forum:2:desc")
			,'vazco_forum/widgets/forum2'
		);
		if ($container2)
			$mainpageWidgets->addWidget($widget);
		
		$widget = new mainpageWidget(
			'vazco_forum3'
			,elgg_echo("vazco_forum:forum:3")
			,elgg_echo("vazco_forum:forum:3:desc")
			,'vazco_forum/widgets/forum3'
		);
		if ($container3)
			$mainpageWidgets->addWidget($widget);
			
		return $mainpageWidgets;
	}

	//make sure we can update last post message for all forums
	function vazco_forum_metadata_permissions($event, $object_type, $object, $vars){
		if (substr($vars['metadata']['name'],0,14) =='lastannotation'){
			return true;
		}
		return $object;
	}
	
	function vazco_forum_create($event, $object_type, $object){
		
		if ($object->subtype == get_subtype_id('object','forum')){
			vazco_forum::notifyThread($object);
			vazco_forum::subscribe($object);
		}
	}
	
	//update last post message for the forum
	function vazco_forum_create_annotation($event, $object_type, $object){
		$entity = get_entity($object->entity_guid);

		//in case it's forum, update the latest post
		if ($entity->subtype == get_subtype_id('object','forum')){
			vazco_forum::updateLatestPost($entity, $object);
		}
	}
	
	function vazco_forum_permission_check($event, $object_type, $object, $vars){
		global $CONFIG;
		if ($_REQUEST['siteedit'])
			return true;
		return $object;
	}

	function vazco_forum_url($entity){
		global $CONFIG;
		return $CONFIG->url . "pg/forum/{$entity->guid}/{$entity->container_forum}";
	}

	function vazco_forum_page_handler($page) {
		global $CONFIG;
		// The first component of a forum URL is the username
		if (isset($page[0])) {
			if (is_numeric($page[0])) {
				set_input('topic',$page[0]);
				
				// In case we have further input
				if (isset($page[1])) {//must be set!
					set_input('group_guid',$page[1]);
					include "pages/topicposts.php";
				}
			}
			else {
				switch ($page[0]) {
					case 'topicposts':
						set_input('topic',$page[1]);
						set_input('group_guid',$page[2]);
						if (isset($page[3]))
							set_input('parent_forum',$page[3]);
						include "pages/topicposts.php";
						return true;
						break;
					case 'add':
						set_input('container_forum',$page[1]);
						if (isset($page[2]))
							set_input('parent_forum',$page[2]);
						include ('pages/addthread.php');

						return true;
						break;
					case 'edit':
						set_input('guid',$page[1]);
						set_input('container_forum',$page[2]);
						include 'pages/addthread.php';
						return true;
						break;
					case 'siteforum':
						set_input('guid',$page[1]);
						include 'pages/siteforum.php';
						return true;
						break;
				}
			}
		}
		
		return true;
	}

// Make sure the status initialisation function is called on initialisation
register_elgg_event_handler('init','system','vazco_forum_init');

?>