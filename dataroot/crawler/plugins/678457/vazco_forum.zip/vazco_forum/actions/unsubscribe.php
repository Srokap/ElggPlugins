<?php
	global $CONFIG;
	action_gatekeeper();
	$forum = get_entity(get_input('guid'));
	vazco_forum::unsubscribe($forum);
	exit();
?>