<?php
	global $CONFIG;
	$_REQUEST['siteedit'] = 1;
	/* Individual section */
	action_gatekeeper();
	
	$entity = null;
	$owner_guid = get_input('owner_guid');
	$parent_guid = get_input('parent_forum');
	
	$forum = null;
	if ($parent_guid != 1)
		$forum = new vazco_forum($parent_guid);

	$level = vazco_forum::getLevel($forum);

 	$container_guid = get_input('container_forum');
	set_page_owner($container_guid);
	
	$entity_guid = get_input('guid');
	if ($entity_guid){
		$entity = get_entity($entity_guid);
	}

	$adminstructure = (get_plugin_setting('adminstructure','vazco_forum') == 'yes');
	$forumsforadmins = (get_plugin_setting('forumsforadmins','vazco_forum') == 'yes');

	if (!$parent_guid && $adminstructure && !isadminloggedin() 
	|| ($forumsforadmins && $level <=1 && !isadminloggedin())){
		register_error(elgg_echo('vazco_forum:norightsfirstbranch'));
		forward($_SERVER['HTTP_REFERER']);
	}
	// must be set to group id
	
	
	/* Common section*/
	
	
	$fieldArray = vazco_forum::forumEditFormArray($entity);

	/*
	 * Form name is used to create unique translations for action. It has to be the same as the form name set in form. 
	 * The translations that are created are:
	 * 
	 * formName:saved
	 * formName:notsaved
	 * */
	$formName = 'forum_edit';

	$access = ACCESS_PRIVATE;

	elgg_view("vazco_forum/vazco_tools/actions/edit",
		array(
			'fieldArray' => $fieldArray,
			'formName' => $formName,
			//'redirectUrl' => null,// $container->getURL(),
			'entity' => $entity,
			'subtype' => 'forum',
			'access' => $access,
			'riverCreateView' => 'river/object/forum/create',
			'riverEditView' => 'river/object/forum/edit',
		)	
	);
?>