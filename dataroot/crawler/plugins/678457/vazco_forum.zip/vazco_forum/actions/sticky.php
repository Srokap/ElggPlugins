<?php
	global $CONFIG;	
	admin_gatekeeper();
	
	$forum = get_entity(get_input('guid'));
	$unstick = get_input('unstick');
	if (!isadminloggedin() || !$forum->owner_guid == get_loggedin_userid()){
		system_message(elgg_echo("vazco_forum:norights"));
		forward($_SERVER['HTTP_REFERER']);	
	}
	if ($unstick)
		$forum->sticky = 1;
	else
		$forum->sticky = 2;
		
	$forum->save();
	system_message(elgg_echo("vazco_forum:sticky:success"));
	forward($_SERVER['HTTP_REFERER']);
?>