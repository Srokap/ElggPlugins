<?php
	global $CONFIG;
	gatekeeper();
	$forum = get_entity(get_input('topic_guid'));
	if (vazco_forum::comment($forum)){
		system_message(elgg_echo('vazco_forum:comment:success'));
	}else{
		register_error(elgg_echo('vazco_forum:comment:failure'));
	}
	forward($_SERVER['HTTP_REFERER']);
?>