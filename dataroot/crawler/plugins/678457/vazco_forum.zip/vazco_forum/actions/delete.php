<?php
	global $CONFIG;
	
	gatekeeper();
	// get_entity(get_input('guid')) is not vazco_forum object
	$forum = get_entity(get_input('guid'));
	if (!isadminloggedin() && $forum->owner_guid != get_loggedin_userid()){
		register_error(elgg_echo("vazco_forum:norights"));
		forward($_SERVER['HTTP_REFERER']);	
	}
	
	$container_guid = $forum->container_forum;
	if (vazco_forum::deleteThread($forum)){
		system_message(elgg_echo("vazco_forum:deleted"));
		$parent = get_entity($parent_guid);
		if ($parent && $parent->getSubtype() == 'forum'){
			forward($parent->getURL());	
		}else{
			$container = get_entity($container_guid);
			if ($container && $container->getSubtype() == 'forum'){
				forward($container->getURL());
			}else{
				forward($CONFIG->wwwroot.'pg/forum/siteforum');
			}
		}
	}
	
	register_error(elgg_echo("vazco_forum:notdeleted"));
	forward($_SERVER['HTTP_REFERER']);
	