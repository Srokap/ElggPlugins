<?php
	global $CONFIG;
	admin_gatekeeper();
	$forum = get_entity(get_input('guid'));
	if (!isadminloggedin() || !$forum->owner_guid == get_loggedin_userid()){
		system_message(elgg_echo("vazco_forum:norights"));
		forward($_SERVER['HTTP_REFERER']);	
	}
	if (get_input('open')) {
		$forum->closed = 0;
		if ($forum->save())
			system_message(elgg_echo("vazco_forum:opened"));
	}
	else {
		$forum->closed = 1;
		if ($forum->save())
			system_message(elgg_echo("vazco_forum:closed"));
	}

	forward($_SERVER['HTTP_REFERER']);
?>