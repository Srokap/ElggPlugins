<?php
	$thread = $vars['thread'];
	$container_forum = $vars['container_guid'];
	$current = $vars['current'];
	$breadcrumbs = $thread->getBreadcrumbs($container_forum, $current);
?>
<div class="contentWrapper breadcrumbs">
	<?php echo $breadcrumbs;?>
</div>