<?php
	$entity = get_entity(get_input('guid'));
	$container_guid = get_input('container_forum');
	set_page_owner($container_guid);
	$fieldArray = vazco_forum::forumEditFormArray($entity);
	$actionUrl = $CONFIG->wwwroot.'action/forum/edit';
	$thread = new vazco_forum($entity->parent_forum);
	if (get_input('guid')){
		$title = elgg_echo('vazco_forum:editthread');
	}else{
		$title = elgg_echo('vazco_forum:addthread');
	}
	echo elgg_view('vazco_forum/breadcrumbs', array('thread' => $thread, 'container_guid' => $container_guid, 'current' => $title));
?>

<div class="contentWrapper">
	<?php 
		echo elgg_view('vazco_forum/vazco_tools/forms/edit',
			array(
				'fieldArray' => $fieldArray,
				'actionUrl' => $actionUrl,
				'formName' => 'forum_edit',
			)
		);
	?>
</div>