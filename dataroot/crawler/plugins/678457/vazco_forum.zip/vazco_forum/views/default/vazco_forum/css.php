<?php 
	global $CONFIG; 
?>
.translation-list{
	display:none;
	margin-top:5px;
}
.river_object_forum_create,
.river_object_forum_update{
	background:url("<?php echo $CONFIG->wwwroot;?>_graphics/river_icons/river_icon_comment.gif") no-repeat scroll left -1px transparent;
}

.translation-list div,
.translation-list span{
	float:left;
}
.vforum_settings{
	-moz-border-radius:8px;
	background:#FFFFFF;
	margin:10px 0;
	padding:5px;
}

#topic_posts a.add_topic_button{
	margin-left:5px;
}

.tools-delete{
	-moz-border-radius:4px;
	background:#4690D6;
	color:white;
	text-decoration:none;
	padding:6px 6px 4px;
	font-weight:bold;
	font-family:Arial,Helvetica,sans-serif;
	font-size:12px;
	float:right;
	margin:10px 0;
}

.tools-delete:hover{
	text-decoration:none;
	color:white;
	background:#0054A7;
}

.topic-post-menu a.collapsibleboxlink{
	margin:0 10px 0 0;
}

.forum-subscribe-button{
	float:right;
}
.add_topic{
	height:18px;
}
.topic .topic_owner_icon .usericon{
	margin:5px 20px 5px 5px;
}
.v_forum .narrow{
	width:80px;
	text-align:center;
}

.forum-listing{
	padding:10px;
}
.forum-listing div{
	margin:0 5px;
}

.forum-listing div.forum-time{
	float:none;
	clear:both;
	padding-top:5px;
}
.v_forum .forum-item-0{
	background:#ECE4BB;
}
.v_forum .forum-item-1{
	//background:#ECE4BB;
}


a.add_topic_button {
	float:left;
	padding:5px;
	margin-left:5px;
}

#topic_posts{
	padding: 10px;
	margin:0;
}

#topic_posts form{
	margin:0;
}
img.forum{
	padding:1px;
	-moz-border-radius:3px;
	background:white;
	margin-left:2px;
	border:1px solid white;
}

img.sticky{
	padding:1px 0 1px 1px;
	-moz-border-radius:3px;
	background:white;
	margin-left:3px;
	border:1px solid white;
}

.row1 img.sticky,
.row1 img.forum{
	border:1px solid #CCCCCC;
}

#topic_posts .breadcrumbs a{
	color:#BABABA;
}
#topic_posts .breadcrumbs{
	font-size:80%;
	color: #03474A;
}

#topic_posts .breadcrumbs .title{
	font-size:90%;
	color: black;
	font-weight:bold;
}

.v_forum a {
	color: #0054A7;
}
.v_forum a:hover {
	color: #000000;
}
.v_forum th {
	font-weight: bold;
	color:#888888;
	padding: 5px;
}

.v_forum td {
 	padding: 2px;
 	vertical-align: middle;
}


.v_forum-type {
	width: 55px;
}
.v_forum-blank {
	width: 30px;
}
.v_forum-title {
}
.v_forum-time {
	vertical-align: middle;
}
.v_forum-count,
.v_forum-views {
	font-align: center;
	vertical-align: middle;
}
.v_forum td.forum-count,
.v_forum td.forum-views{
	text-align:center;
}

.v_forum_post {
	margin-top: -1px;
}
.row2 {
	background-color: #4690D6 ;
}

.row1 {
	background-color: #FFFFFF;
}

.row0 {
	background-color: #DEDEDE;
	-moz-border-radius:8px;
	
}
.admin_links{
	width:200px;
}

.v_user_info {
	width: 100%;
	float: left;
	margin-left: 10px;
}
.usericon {
	float: left;
}
.topic-post-menu{
	margin-left: 10px;
}
.v_post_content {
	padding: 3px;
	width: 83%;
}

.admin_link {
	color: #880000 !important;
}

.admin_link2 {
	color: #CC0000 !important;
}