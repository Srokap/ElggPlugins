<?php 
	$type = $vars['type'];
	$languages = vazco_tools::getLanguages();
	$counter = 0;
	$defaultLanguageValue = $vars['value_'.get_language()];
	foreach($languages as $language){
		$fieldName = $vars['internalname']."__".$language;
		if($counter == 0){
			echo "<div class='transfirst'>";
		}elseif ($counter == 1){
			echo "<div id='trans_".$vars['internalname']."' class='translation-list'>";
			echo '<div>'.elgg_echo($language,$language).'</div>';
		}else{
			echo '<div>'.elgg_echo($language,$language).'</div>';
		}
		$value = $vars['value_'.$language];
		echo elgg_view("input/{$type}",array('value' => $vars['value_'.$language], 'internalname' => $fieldName));
		if ($counter == 0){
			echo "</div><div id='transtoggle_".$vars['internalname']."'><a href='#'>".elgg_echo('vazco_tools:transtoggle')."</a></div>";
		}
		$counter++;
	}
	if ($counter > 1){
		echo "</div>";
	}
?>
<script language="JavaScript">
$(document).ready(function() {
   $("#<?php echo "transtoggle_".$vars['internalname'];?>").click(function() {
		$("#<?php echo "trans_".$vars['internalname'];?>").animate({ height: 'show', opacity: 'show' }, 'slow');
		$("#<?php echo "transtoggle_".$vars['internalname'];?>").animate({ height: 'hide', opacity: 'hide' }, 'slow');
		return false;
   });
   $(".translation-list input").click(function() {
		if (this.value == '<?php echo $defaultLanguageValue;?>')
			this.value = '';
		return false;
   });
   
});
</script>