<?php
	$thread = $vars['thread'];
	$count = $vars['count'];
	$showType = (get_plugin_setting('showtype','vazco_forum')!= 'no');
	global $CONFIG;
	$security = get_security_token_str();
?>

<tr class="row<?php echo $vars['pair'];?><?php if ($thread->isForum()){?> forum-item-<?php echo $vars['pair']; } ?>">
	
	<td class="v_forum-type">
		<?php if (vazco_forum::isSticky($thread)){?>
			<img title="<?php echo elgg_echo('vazco_forum:sticky');?>" class="sticky" src="<?php echo $vars['url'];?>mod/vazco_forum/graphics/sticky.gif">
		<?php } elseif ($showType && $thread->forum_type){?>
				<img class="forum" title="<?php echo elgg_echo('vazco_forum:forum_type_'.$thread->forum_type);?>" src="<?php echo $vars['url'];?>mod/vazco_forum/graphics/icon<?php 
					if ($thread->forum_type)	echo $thread->forum_type;
					else						echo '0';
				?>.gif"/>
		<?php }?>
		<?php if ($thread->isForum()){?>
			<img class="forum" src="<?php echo $vars['url'];?>mod/vazco_forum/graphics/thread.gif" title="<?php echo elgg_echo('vazco_forum:containsthreads');?>"/>
		<?php }?>
	</td>
	
	<td class="forum-blank">
		<?php 
		echo "<div class=\"topic_owner_icon\">" 
	    . elgg_view('profile/icon',array('entity' => $thread->getOwnerEntity(), 'size' => 'tiny', 'override' => false)) 
	    . "</div>";
	    ?>
	</td>
	<td class="forum-title">
		<a  href="<?php echo $thread->getURL(); ?>"
			title="<?php echo strip_tags(elgg_translate($thread,'description')); ?>" ><?php echo htmlentities(elgg_translate($thread,'title'),ENT_NOQUOTES,'UTF-8'); ?></a>
		<br>
		<?php
			$author = get_entity($thread->owner_guid);
			echo elgg_echo('vazco_forum:author'), ': ' , 
				'<a href="'.$CONFIG->wwwroot.'pg/profile/',$author->username,'">',htmlentities($author->name,ENT_NOQUOTES,'UTF-8'),"</a> ".friendly_time($thread->time_created); 
		?>
		
		<?php
			// moderation
			if (get_loggedin_userid() == $author->guid || isadminloggedin()) {
				// edit and delete links
				
				$deleteLink = elgg_view("output/confirmlink", array(
					'href' => $CONFIG->wwwroot.'action/forum/delete'.$security.'&guid='.$thread->guid,
					'text' => elgg_echo('delete'),
					'confirm' => elgg_echo('deleteconfirm'),
					'class' => 'admin_link',
				));
																
				echo '<div class="admin_links">',$deleteLink,' ',
							'<a class="admin_link" href="'.$CONFIG->wwwroot.'pg/forum/edit/',$thread->guid,'">',elgg_echo('edit'),'</a>';
				if (isadminloggedin()){
					// status closed
					if (!$thread->closed) 
						echo ' <a class="admin_link" href="'.$CONFIG->wwwroot.'action/forum/close'.$security.'&guid=',$thread->guid,'">',elgg_echo('close'),'</a>';
					else
						echo ' <a class="admin_link" href="'.$CONFIG->wwwroot.'action/forum/close'.$security.'&guid=',$thread->guid,'&open=1">',elgg_echo('open'),'</a>';
						
					// sticky topic
					if (!vazco_forum::isSticky($thread))
						echo ' <a class="admin_link" href="'.$CONFIG->wwwroot.'action/forum/sticky'.$security.'&guid=',$thread->guid,'">',elgg_echo('vazco_forum:stick'),'</a>';
					else
						echo ' <a class="admin_link" href="'.$CONFIG->wwwroot.'action/forum/sticky'.$security.'&guid=',$thread->guid,'&unstick=1">',elgg_echo('vazco_forum:unstick'),'</a>';
				}
				echo '</div>';
			} 
		?>
	</td>
	<td class="forum-time">
	<?php 
			if ($thread->isForum()){
				//topic is in fact a forum
				$annotation = $thread->getLastThread();
				if ($annotation){
					echo "<div class='title'><a href='{$annotation->getURL()}'>{$annotation->title}</a></div>";
					echo friendly_time($annotation->time_created);
					$lastPostAuthor = get_entity($annotation->owner_guid);
					echo "<div class='by'>" , elgg_echo('vazco_forum:by') , ' ' , 
					'<a href="'.$CONFIG->wwwroot.'pg/profile/',$lastPostAuthor->name,'">',$lastPostAuthor->name,"</a></div>";
				}else{
					echo elgg_echo('vazco_forum:nolastthread');
				}
			}else{
				//topic is in fact a simple topic
				// get last annotation
				$annotation = vazco_forum::getLastPost($thread);
				if ($annotation){
					echo friendly_time($annotation->time_created);
					$lastPostAuthor = get_entity($annotation->owner_guid);
					echo "<div class='by'>" , elgg_echo('vazco_forum:by') , ' ' , 
					'<a href="'.$CONFIG->wwwroot.'pg/profile/',$lastPostAuthor->name,'">',$lastPostAuthor->name,"</a></div>";
				}else{
					echo elgg_echo('vazco_forum:nolastpost');
				}
			}
		?>
	</td>
	<td class="forum-count"><?php echo $count; ?></td>
	<td class="forum-views"><?php
		if ($thread->views)
			echo $thread->views;
		else
			echo '0'; 
	?></td>
</tr>
