<?php 
	echo vazco_tools::getIcon($vars, 'mod/vazco_forum/views/default/vazco_forum/vazco_tools/output');
?>