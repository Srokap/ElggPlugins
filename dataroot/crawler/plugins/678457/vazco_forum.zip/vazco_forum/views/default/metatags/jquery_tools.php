<?php //ł ?><?php
global $CONFIG;
$path = $CONFIG->wwwroot.'mod/vazco_forum/vendors/';
?>
<script src="<?php echo $path;?>jquery.tools.min.js" type="text/javascript"></script>