<?php /*?>
	<div class="vforum_settings">
	<p><b><?php echo elgg_echo('vazco_forum:generalsettings');?></b></p>
	<p>
	    <?php echo elgg_echo('vazco_forum:norightsfirstbranch'); ?> 
	    <select name="params[adminstructure]">
	        <option value="yes" <?php if ($vars['entity']->adminstructure == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
	        <option value="no" <?php if ($vars['entity']->adminstructure != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	    </select> 
	</p>
	<p>
	    <?php echo elgg_echo('vazco_forum:forumsforadmins'); ?> 
	    <select name="params[forumsforadmins]">
	        <option value="yes" <?php if ($vars['entity']->forumsforadmins == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
	        <option value="no" <?php if ($vars['entity']->forumsforadmins != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	    </select> 
	</p>
	<p>
	    <?php echo elgg_echo('vazco_forum:multilang'); ?> 
	    <select name="params[multilang]">
	        <option value="yes" <?php if ($vars['entity']->multilang == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
	        <option value="no" <?php if ($vars['entity']->multilang != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	    </select> 
	</p>
	<p>
	    <?php echo elgg_echo('vazco_forum:showtype'); ?> 
	    <select name="params[showtype]">
	        <option value="yes" <?php if ($vars['entity']->showtype != 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
	        <option value="no" <?php if ($vars['entity']->showtype == 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	    </select> 
	</p>
	<p>
	    <?php echo elgg_echo('vazco_forum:simplearchitecture'); ?> 
	    <select name="params[simplearch]">
	        <option value="yes" <?php if ($vars['entity']->simplearch != 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
	        <option value="no" <?php if ($vars['entity']->simplearch == 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	    </select> 
	</p>
	</div>
	<div class="vforum_settings">
		<p><b><?php echo elgg_echo('vazco_forum:forumwidgets');?></b></p>
		<p><span><?php echo elgg_echo('vazco_forum:forum:1:settings'); ?></span>
			<?php echo elgg_view('input/text', array('internalname' => 'params[forum1]','class' => ' ', 'value' => $vars['entity']->forum1)); ?>
		</p>
		<p><span><?php echo elgg_echo('vazco_forum:forum:2:settings'); ?></span>
			<?php echo elgg_view('input/text', array('internalname' => 'params[forum2]','class' => ' ', 'value' => $vars['entity']->forum2)); ?>
		</p>
		<p><span><?php echo elgg_echo('vazco_forum:forum:3:settings'); ?></span>
			<?php echo elgg_view('input/text', array('internalname' => 'params[forum3]','class' => ' ', 'value' => $vars['entity']->forum3)); ?>
		</p>
	</div>
<?php */?>