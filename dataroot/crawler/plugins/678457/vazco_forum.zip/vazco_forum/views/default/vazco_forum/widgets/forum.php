<?php 
	global $CONFIG;
	$limit = 5;
	$container = 0;
	$topics = elgg_get_entities(array('type' => 'object', 'subtype' => 'forum','limit' => $limit));
?>
<div class="index_box">
	<h2><?php echo elgg_echo('vazco_forum:lastposts:overall');?></h2>
	<div class="contentWrapper">
		<?php
		if ($topics){
			foreach($topics as $f){
	    		$f = new vazco_forum($f->guid);
	    		$count = $f->getNumOfReplies();
	    		echo elgg_view('vazco_forum/thread', array('thread' => $f, 'count' => $count, 'pair' => $i++%2));
	        }
		}else{
			echo elgg_echo('vazco_forum:notopics');
		}
		?>
		<div class="clearfloat"></div>
	</div>
</div>