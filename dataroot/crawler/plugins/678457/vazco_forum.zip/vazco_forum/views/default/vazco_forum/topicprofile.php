 <?php
	global $CONFIG;
	$thread = new vazco_forum($vars['entity']->guid);
	$thread->markVisit();
	$thread_guid = get_input('topic');
?>

<div id="topic_posts"><!-- open the topic_posts div -->
<?php echo elgg_view('vazco_forum/breadcrumbs', array('thread' => $thread, 'container_guid' => $thread->container_forum));?>
<?php

	echo elgg_view('vazco_forum/addtopic_button',array('parent_forum' => $thread_guid, 'container_guid' => $thread->container_forum));

    //display follow up comments
    $count = $thread->countAnnotations('forum_post');
    $offset = (int) get_input('offset',0);
    $postsPerPage = 5;
    
    $baseurl = $vars['url'] . "pg/forum/topicposts/{$thread->guid}/{$thread->container_forum}/";
    echo elgg_view('navigation/pagination',array(
    												'limit' => $postsPerPage,
    												'offset' => $offset,
    												'baseurl' => $baseurl,
    												'count' => $count,
    											));
	//now display thread
?>
	<div class="contentWrapper topic">
		<!-- topic conten -->
		<?php
		echo "<div class=\"topic_owner_icon\">" 
	    . elgg_view('profile/icon',array('entity' => $thread->getOwnerEntity(), 'size' => 'tiny', 'override' => false)) 
	    . "</div>";
			//display the actual message posted
			echo parse_urls(elgg_view("output/longtext",array("value" => elgg_translate($thread, 'description'))));
		?>
	</div>
        
<?php
	//if this is the thread with threads
    if ($thread->isForum()) {
    	$thread = vazco_forum::getForumTopics(999, 0, 0, page_owner(), $thread_guid);
    	echo elgg_view('vazco_forum/topicanswers',array('forum'=> $thread));
    }
    //if this is the thread with posts
    else {
    	$count = 1;
	    foreach($thread->getAnnotations('forum_post', $postsPerPage, $offset, "asc") as $post) {
		     echo elgg_view("vazco_forum/topiclisting",array('entity' => $post, 'pair' => $count++%2));
		}

		// check to find out the status of the topic and act
	    if($thread->closed){
	        //this topic has been closed by the owner
	        echo "<div class='contentWrapper topicclosed'>";
	        echo "<h2>" . elgg_echo("groups:topicisclosed") . "</h2>";
	        echo "<p>" . elgg_echo("groups:topiccloseddesc") . "</p>";
	        echo "</div>";
	    } else{
			if (isloggedin()){
		    	echo '<div class="contentWrapper addPost">';
		        //display the add comment form, this will appear after all the existing comments
			    echo elgg_view("vazco_forum/edit", array('entity' => $thread));
			    echo '</div>';
			}
	    }
    }
    

?>
</div>