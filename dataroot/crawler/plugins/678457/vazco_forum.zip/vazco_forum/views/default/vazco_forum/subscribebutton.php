<?php 
	global $CONFIG;
	$forum = $vars['forum'];
	$forum_guid = 1;
	if ($forum && $forum->guid){
		$forum_guid = $forum->guid;
	}
	$security = get_security_token_str();
?>
<script language="JavaScript">
	$(document).ready(function() {
		$('#subscribebutton').click(function() {
			$('#subscribebutton').animate({ opacity: 'hide' }, 'fast');
			if ($('#subscribebutton').attr('class') == 'forum-unsubscribe'){
				var href = '<?php echo $CONFIG->wwwroot; ?>action/forum/unsubscribe<?php echo $security; ?>&guid=<?php echo $forum_guid; ?>';
				$.ajax({
				    url: href,
				    type: 'GET',
				    dataType: 'html',
				    timeout: 10000,
				    error: function(){
				        //alert('Error loading document');
				    },
				    success: function(html){
				    	$('#subscribebutton').removeClass('forum-unsubscribe');
				    	$('#subscribebutton').addClass('forum-subscribe');
						$('#subscribebutton').text('<?php echo elgg_echo('vazco_forum:subscribe')?>');
						$('#subscribebutton').animate({ opacity: 'show' }, 'fast');
				    },
				    error: function(event, request, settings){
				    	//alert(request);
				    }
				});
			}else{
				var href = '<?php echo $CONFIG->wwwroot; ?>action/forum/subscribe<?php echo $security; ?>&guid=<?php echo $forum_guid; ?>';
				$.ajax({
				    url: href,
				    type: 'GET',
				    dataType: 'html',
				    timeout: 10000,
				    error: function(event, request, settings){
						//alert(request);
			    	},
				    success: function(html){
			    		$('#subscribebutton').removeClass('forum-subscribe');
				    	$('#subscribebutton').addClass('forum-unsubscribe');
						$('#subscribebutton').text('<?php echo elgg_echo('vazco_forum:unsubscribe')?>');
						$('#subscribebutton').animate({ opacity: 'show' }, 'fast');
				    }
				});
			}
			return false;
		});
	});
</script>
<div class="forum-subscribe-button">
<?php if (vazco_forum::subscribed($forum)){?>
	<a id="subscribebutton" class="forum-unsubscribe" href="<?php echo $CONFIG->wwwroot; ?>action/forum/unsubscribe<?php echo $security; ?>&guid=<?php echo $forum_guid; ?>"><?php echo elgg_echo('vazco_forum:unsubscribe')?></a>
<?php }else{?>
	<a id="subscribebutton" class="forum-subscribe" href="<?php echo $CONFIG->wwwroot; ?>action/forum/subscribe<?php echo $security; ?>&guid=<?php echo $forum_guid; ?>"><?php echo elgg_echo('vazco_forum:subscribe')?></a>
<?php }?>
</div>
<div class="clearfloat"></div>