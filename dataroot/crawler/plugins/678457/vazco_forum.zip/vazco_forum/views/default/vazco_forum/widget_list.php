<?php 
	/**
	 * Elgg vazco_mainpage plugin
	 * 
	 * @author Michal Zacher [michal.zacher@gmail.com]
	 */
$container1 = get_plugin_setting('forum1','vazco_forum');
$container2 = get_plugin_setting('forum2','vazco_forum');
$container3 = get_plugin_setting('forum3','vazco_forum');

	$mainpageWidgets = $_SERVER['mainpageWidgets'];

	$widget = new mainpageWidget(
		'vazco_forum'
		,elgg_echo("vazco_forum:forum:widget")
		,elgg_echo("vazco_forum:forum:desc")
		,'vazco_forum/widgets/forum'
	);
	$mainpageWidgets->addWidget($widget);

	$widget = new mainpageWidget(
		'vazco_forum1'
		,elgg_echo("vazco_forum:forum:1")
		,elgg_echo("vazco_forum:forum:1:desc")
		,'vazco_forum/widgets/forum1'
	);
	if ($container1)
		$mainpageWidgets->addWidget($widget);
	
	$widget = new mainpageWidget(
		'vazco_forum2'
		,elgg_echo("vazco_forum:forum:2")
		,elgg_echo("vazco_forum:forum:2:desc")
		,'vazco_forum/widgets/forum2'
	);
	if ($container2)
		$mainpageWidgets->addWidget($widget);
	
	$widget = new mainpageWidget(
		'vazco_forum3'
		,elgg_echo("vazco_forum:forum:3")
		,elgg_echo("vazco_forum:forum:3:desc")
		,'vazco_forum/widgets/forum3'
	);
	if ($container3)
		$mainpageWidgets->addWidget($widget);

	$_SERVER['mainpageWidgets'] = $mainpageWidgets;
?>