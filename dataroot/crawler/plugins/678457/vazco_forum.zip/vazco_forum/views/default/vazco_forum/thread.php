<?php
	$thread = $vars['thread'];
	$count = $vars['count'];
	$showType = (get_plugin_setting('showtype','vazco_forum')!= 'no');
	global $CONFIG;
?>

<div class="forum-listing row<?php echo $vars['pair'];?><?php if ($thread->isForum()){?> forum-item-<?php echo $vars['pair']; } ?>">
	
	<div class="forum-blank">
		<?php 
		echo "<div class=\"topic_owner_icon\">" 
	    . elgg_view('profile/icon',array('entity' => $thread->getOwnerEntity(), 'size' => 'tiny', 'override' => false)) 
	    . "</div>";
	    ?>
	</div>
	<div class="forum-title">
		<a  href="<?php echo $thread->getURL(); ?>"
			title="<?php echo strip_tags(elgg_translate($thread,'description')); ?>" ><?php echo elgg_translate($thread,'title'); ?></a>
		<br>
	</div>
	<div class="forum-time">
	<?php 
		if ($count) {
			if ($thread->isForum()){
				$annotation = $thread->getLastThread();
				echo "<a href='{$annotation->getURL()}'>{$annotation->title}</a> ";
				echo friendly_time($annotation->time_created);
				$lastPostAuthor = get_entity($annotation->owner_guid);
				echo ' '.elgg_echo('vazco_forum:by') , ' ' , 
				'<a href="'.$CONFIG->wwwroot.'pg/profile/',$lastPostAuthor->name,'">',$lastPostAuthor->name,"</a>";
			}else{
				//thread is in fact a simple thread
				//thread is in fact a forum
				// get last annotation
				$annotation = $thread->getAnnotations('forum_post',1,$count-1);
				$annotation = $annotation[0];
	//			print_r($annotation );
				echo friendly_time($annotation->time_created);
				$lastPostAuthor = get_entity($annotation->owner_guid);
				echo "<div class='by'>" , elgg_echo('vazco_forum:by') , ' ' , 
				'<a href="'.$CONFIG->wwwroot.'pg/profile/',$lastPostAuthor->name,'">',$lastPostAuthor->name,"</a></div>";				
			}
		}
		else {
			echo elgg_echo('vazco_forum:noposts');
		}
		?>
	</div>
</div>
