<?php 
if (isloggedin()){
	
	?>
<div class="add_topic">
	<?php
	$security = get_security_token_str();
	$e = get_entity(get_input('topic'));
	$container_guid = $vars['container_guid'];
	if (!$container_guid)
		$container_guid = $e->container_forum;
	$forum_guid = $vars['parent_forum'];	
	$forum = new vazco_forum($forum_guid);
	$level = vazco_forum::getLevel($forum);
	$simplearch = (get_plugin_setting('simplearch','vazco_forum')!= 'no');
	$addText = elgg_echo("vazco_forum:addthread");
	$editText = elgg_echo("vazco_forum:editthread");
	$deleteText = elgg_echo("vazco_forum:deletethread"); 
	if ($level == 1)
		$addText = elgg_echo("vazco_forum:addforum");
	elseif($level == 2){
		$editText = elgg_echo("vazco_forum:editforum");
		$deleteText = elgg_echo("vazco_forum:deleforum");
	}

	$adminstructure = (get_plugin_setting('adminstructure','vazco_forum') == 'yes');
	$forumsforadmins = (get_plugin_setting('forumsforadmins','vazco_forum') == 'yes');

	if (vazco_forum::canAddTopic($forum)){?>
	<a href="<?php echo $vars['url']; ?>pg/forum/add/<?php echo $container_guid; if ($vars['parent_forum']) echo "/",$vars['parent_forum'];?>" class="add_topic_button"><?php echo $addText; ?></a>
<?php }

	if (!$adminstructure && (!$forumsforadmins || $level > 1) && $forum && $forum->owner_guid == get_loggedin_userid() || isadminloggedin()){
	if ($e){
		if ($vars['container_guid'])
			$container_guid = $vars['container_guid'];
			
			
		$deleteLink = elgg_view("output/confirmlink", array(
							'href' => $CONFIG->wwwroot.'action/forum/delete'.$security.'&guid='.$forum_guid,
							'text' => $deleteText,
							'confirm' => elgg_echo('deleteconfirm'),
							'class' => 'add_topic_button',
						));
	}
?>
	<?php if ($e){?>
	<a class="add_topic_button" href="<?php echo $vars['url']; ?>pg/forum/edit/<?php echo $e->guid?>/<?php echo $e->container_forum;?>"><?php echo $editText; ?></a>
	<?php echo $deleteLink;?>
	<?php }
	}
	if ($level > 1)
		echo elgg_view('vazco_forum/subscribebutton', array('forum' => $forum));
?>
</div>
<?php 
}
?>

	
