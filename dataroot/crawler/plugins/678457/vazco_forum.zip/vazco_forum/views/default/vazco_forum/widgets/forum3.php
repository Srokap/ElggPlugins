<?php 
	global $CONFIG;
	$limit = 10;
	$container = 0;
	$forum_guid = get_plugin_setting('forum3','vazco_forum');
	$topics = vazco_forum::getForumTopics($limit, 0, false, $container, $forum_guid);
	$topic = new vazco_forum($forum_guid);

?>
<div class="index_box">
	<h2><?php echo sprintf(elgg_echo('vazco_forum:lastpostsof'),$topic->title);?></h2>
	<div class="contentWrapper ">
		<?php
		if (is_array($topics)){
			foreach($topics as $f){
	    		$f = new vazco_forum($f->guid);
	    		$count = $f->getNumOfReplies();
	    		echo elgg_view('vazco_forum/thread', array('thread' => $f, 'count' => $count, 'pair' => $i++%2));
	        }
		}else{
			if (!$forum_guid){
				$topics = elgg_echo('vazco_forum:setforumguid');
			}else{
				echo elgg_echo('vazco_forum:notopics');
			}
		}
		?>
		<div class="clearfloat"></div>
	</div>
</div>