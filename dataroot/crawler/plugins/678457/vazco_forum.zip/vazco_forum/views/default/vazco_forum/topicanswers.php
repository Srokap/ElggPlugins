<?php
	$forum = $vars['forum'];
	$count = $vars['count'];
	$limit = 10;

	$parent_guid = get_input('topic');//$vars['parent_forum'];
	$replies = elgg_echo('vazco_forum:threads');
	$lastText = elgg_echo('vazco_forum:lastthread');


	$navigation = elgg_view('navigation/pagination',array(
		'baseurl' => $_SERVER['REQUEST_URI'],
		'offset' => get_input('offset'),
		'count' => $count,
		'limit' => $limit,
		'word' => 'offset',
		'nonefound' => false,
	));

	if ($parent_guid && $parent_guid != 1){
		$replies = elgg_echo('vazco_forum:replies');
		$lastText = elgg_echo('vazco_forum:lastpost');
	}
	//$level = vazco_forum::getLevel($forum);
	
	echo "<div class=\"contentWrapper\">";
	if ($forum){ 
		echo $navigation;
		echo "<table width=\"100%\" class=\"v_forum\" border=\"1\">";
	    	echo "<tr><th colspan=\"2\">" 
	    			. "<th>" . elgg_echo('vazco_forum:thread_threadstarter') . "</th>"
	    			. "<th>" . $lastText . "</th>"
	    			. "<th class='narrow'>" . $replies . "</th>"
	    			. "<th class='narrow'>" . elgg_echo('vazco_forum:views') . "</th>"
	    		."</tr>";
	        $i = 0;
	    	foreach($forum as $f){
	    		$f = new vazco_forum($f->guid);
	    		$count = $f->getNumOfReplies();
	    		echo elgg_view('vazco_forum/topic', array('thread' => $f, 'count' => $count, 'pair' => $i++%2));
	        }
        echo "</tbody>";
        echo "</table>";
        echo $navigation;
	}else{
    	echo "<div class=\"forum_latest\">";
		echo elgg_echo("grouptopic:notcreated");
		echo "</div>";
	}
	echo "</div>";
?>