<?php 
	$forum_guid = get_input('guid');
	$forum = new vazco_forum($forum_guid);
	$topics = vazco_forum::getTopicsToWhichThisCanBeMoved($forum);
	$options = array();
	$options[$forum->parent_forum] = elgg_echo('vazco_forum:dontmove');
	if ($forum->parent_forum != 1)
		$options[1] = elgg_echo('vazco_forum:mainforum');
	
	foreach ($topics as $topic){
		$options[$topic->guid] = elgg_translate($topic,'title'); 
	}
	echo elgg_view('input/pulldown', array('options_values' => $options, 'value' => $forum->parent_forum, 'internalname' => $vars['internalname']));
?>