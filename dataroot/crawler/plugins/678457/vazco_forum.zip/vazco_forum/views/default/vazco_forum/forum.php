<?php 
	$entity_guid = $vars['guid'];
	$entity = get_entity($entity_guid);
	$parent_forum = get_input('parent_forum', null);
	$offset = get_input('offset',0);

	$owner_guid = 0;
	if ($vars['owner_guid']){
		$owner_guid = $vars['owner_guid'];	
	}
	if ($vars['parent_forum']){
		$parent_forum = $vars['parent_forum'];	
	}
	$container_guid = page_owner();
	if (isset($vars['guid'])){
		$container_guid = $vars['guid'];	
	}

	$limit = 10;
	if ($vars['limit'])
		$limit = $vars['limit'];
	if (!$entity->contenttype) {
		$forumCount = vazco_forum::getForumTopics($limit, 0, true, $container_guid, $parent_forum);
	    $forum = vazco_forum::getForumTopics($limit, $offset, false, $container_guid, $parent_forum);
	    if (!$vars['hideadd']){
	    	echo elgg_view('vazco_forum/addtopic_button',array('parent_forum' => $parent_forum, 'container_guid' => $container_guid));
	    }

	    echo elgg_view('vazco_forum/topicanswers',array('forum'=> $forum, 'parent_forum' => $container_guid, 'count' => $forumCount));

    }
    else {
    	echo elgg_view('vazco_forum/topicanswers',array('forum'=>$forum));
    }
?>