<?php

$english = array(

		'vazco_forum:forum' => 'Forum',
		'vazco_tools:transtoggle' => 'Show all translations',

		'vazco_forum:subscribe' => 'Subscribe to topic',
		'vazco_forum:unsubscribe' => 'Unsubscribe from topic',
		// form
		'sticky:no' => 'No',
		'sticky:yes' => 'Yes',
		'vazco_forum:title' => 'Site forum',
		'vazco_forum:field:title' => 'Title',
		'vazco_forum:tags' => 'Tags',
		'vazco_forum:description' => 'Description',
		'vazco_forum:processing' => 'Processing...',
		'vazco_forum:movetopic' => 'Move this topic to:',
		'vazco_forum:dontmove' => 'Don\'t move',
		'vazco_forum:mainforum' => 'Main forum',
		'vazco_forum:notdeleted' => 'Forum couldn\'t be deleted',
		'vazco_forum:tags:hint' => 'used when searching for topics',
		
		'vazco_forum:forum_type' => 'Topic type',
		'vazco_forum:forum_type_0' => 'Casual',
		'vazco_forum:forum_type_1' => 'Feedback',
		'vazco_forum:forum_type_2' => 'Important',
		'vazco_forum:forum_type_3' => 'Support question',
		'vazco_forum:comment:success' => 'Your comment was added succesfully',
		'vazco_forum:comment:fail' => 'Your comment couldn\'t be added to the forum',
		'vazco_forum:delete_subthread_error' => 'Can\'t delete topic with subtopics',
		
		'vazco_forum:type_threads' => 'topics',
		'vazco_forum:type_posts' => 'posts',
		'vazco_forum:contenttype' => 'Content type',

		'vazco_forum:access_private' => 'private',
		'vazco_forum:access_friend' => 'friends',
		'vazco_forum:access_loggedin' => 'logged in',
		'vazco_forum:access_public' => 'public',
		'vazco_forum:access_id' => 'Access type',
		
		'vazco_forum:order' => 'Order',
		'vazco_forum:noposts' => 'No posts yet',

		//settings
		'vazco_forum:generalsettings' => 'General settings',
		'vazco_forum:showtype' => 'Enable types for topics:',
		'vazco_forum:norightsfirstbranch' => 'Only admin can create new topics:',
		'vazco_forum:forumsforadmins' => 'Only admins can create new forums (1-st level topics):',
		'vazco_forum:simplearchitecture' => 'Use simple, three level architecture (adviced for most of the sites):',
		'vazco_forum:simplearch:desc' => 'Simple architecture: <br/>The sitewide forum has structure: Forums/Topics/Posts. You can define who can create forums and topics by using the settings above. Posts can be created by everyone. <br/><br/>Complex architecture:<br/> Sitewide forum contains threads, which can contain other threads. You can have multiple levels of threads. It\'s adviced to use this architecture only when you know what you\'re doing and with option of "Only admin can create new topics".',
		'vazco_forum:multilang' => 'Turn on multilanguage translation:',

		//Widgets
		'vazco_forum:lastposts:overall' => 'Latest forum posts',
		'vazco_forum:setforumguid' => 'Please choose topic GUID for this forum widget',
		'vazco_forum:forum:1' => 'Posts from the first thread',
		'vazco_forum:forum:1:settings' => 'Thread GUID of the first forum widget (leave blank if not used)',
		'vazco_forum:forum:1:desc' => 'Displays posts from the first thread',
		
		'vazco_forum:forum:2' => 'Posts from the second thread',
		'vazco_forum:forum:2:settings' => 'Thread GUID of the second forum widget (leave blank if not used)',
		'vazco_forum:forum:2:desc' => 'Displays posts from the second thread',
		
		'vazco_forum:forum:3' => 'Posts from the third thread',
		'vazco_forum:forum:3:settings' => 'Thread GUID of the third forum widget (leave blank if not used)',
		'vazco_forum:forum:3:desc' => 'Displays posts from the third thread',


		'vazco_forum:forum:widget' => 'Latest forum posts',
		'vazco_forum:forum:desc' => 'Displays latest forum posts',
		'vazco_forum:notopics' => 'No topics yet',
		// General
		'vazco_forum:lastpostsof' => '"%s" - last threads',
		'vazco_forum:addthread' => 'Add new topic',
		'vazco_forum:editthread' => 'Edit topic',
		
		'vazco_forum:latestdiscussion' => 'Latest discussion',
		'vazco_forum:reply' => 'Reply',
		'vazco_forum:posts' => 'Posts',
		'forum_edit:saved' => 'Topic was saved successfuly',
		
		'forum_edit:noreqfield' => 'Empty required field',
		'forum_edit:notsaved' => 'Topic couldn\'t be saved',
		'vazco_forum:deleted' => 'Topic (and all his subtopics) was successfuly removed',
		'vazco_forum:delete_subthread_error' => 'Topic contains other topics and can\'t be removed',
		'vazco_forum:nolastpost' => 'No posts yet',
		'vazco_forum:nolastthread' => 'No threads yet',

		//notifications
		'vazco_forum:newthread:title' => 'New forum thread was created',
		'vazco_forum:newtpost:title' => 'New forum post',
		'vazco_forum:newthread:body' => 'User <a href="%s">%s</a> created new forum thread "%s":

%s

You can view this thread on <a href="%s">this page</a>.',
		'vazco_forum:newpost:body' => 'User <a href="%s">%s</a> created new forum post:

%s

You can view full thread on <a href="%s">this page</a>.',


		// forum labels
		'vazco_forum:containsthreads' => 'Contains threads',
		'vazco_forum:forumwidgets' => 'Forum widgets for the vazco_mainpage plugin',
		'vazco_forum:thread_threadstarter' => 'Topic',
		'vazco_forum:lastpost' => 'Last post',
		'vazco_forum:lastthread' => 'Last topic',
		'vazco_forum:replies' => 'Replies',
		'vazco_forum:threads' => 'Topics',
		'vazco_forum:views' => 'Views',
		
		'vazco_forum:by' => 'by',
		'vazco_forum:author' => 'Created by',
		'vazco_forum:stick' => 'Stick',
		'vazco_forum:unstick' => 'Un-stick',
		'vazco_forum:sticky' => 'Sticky',
		'vazco_fields:checkbox:text' => '',

		//communicates
		'vazco_forum:sticky:success' => 'Sticky status was changes successfuly',
		'vazco_forum:closed' => 'Topic was successfuly closed',
		'vazco_forum:opened' => 'Topic was successfuly opened',
		'vazco_forum:field:open:state' => 'Closed',
		'vazco_forum:delete_subthread_error' => 'The topic has subtopics, please delete them first.',
		'vazco_forum:editthread' =>'Edit topic',
		'vazco_forum:deletethread' =>'Delete topic',
		'vazco_forum:addforum' => 'Add new forum',
		'vazco_forum:editforum' => 'Edit forum',
		'vazco_forum:deleforum' => 'Delete forum',
		'vazco_forum:norights' => 'You don\'t have rights to perform this action',

		//river
		'vazco_forum:river:commited' => '%s created forum topic ',
		'vazco_forum:river:commented' => '%s commented on a forum topic ',

		'vazco_forum:river:edited' => '%s edited forum topic ',
);
	
add_translation("en",$english);

?>
