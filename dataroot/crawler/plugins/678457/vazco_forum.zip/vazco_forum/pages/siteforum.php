<?php
	require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
	
	$title = elgg_echo('vazco_forum:title');
	vazco_forum::setContext();
	$user_login = get_input('user');
	$user = get_user_by_username($user_login);
	
	if (!$user)
		$user = get_loggedin_user();

	set_page_owner(1);

	$forum = elgg_view('vazco_forum/forum', array('guid' => 1, 'parent_forum' => 1));
	$body = $title . '';
	
	page_draw($title,elgg_view_layout("one_column", elgg_view_title($title).$forum));