<?php
	require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");

	gatekeeper();
	if (get_input('guid')){
		$title = elgg_echo('vazco_forum:editthread');
	}else{
		$title = elgg_echo('vazco_forum:addthread');
	}
	
	$user_login = get_input('user');
	$user = get_user_by_username($user_login);
	
	$container_guid = get_input('container_forum',0);
	set_page_owner($container_guid);
	vazco_forum::setContext();

	if (!$user)
		$user = get_loggedin_user();

	$body = elgg_view_title($title) . elgg_view('vazco_forum/addthread');
	
	if ($container_guid > 1){
	    	$body = elgg_view_layout("two_column_left_sidebar", '',$body);
	}else{
	    	$body = elgg_view_layout("one_column",$body);
	}
	page_draw($title,$body);