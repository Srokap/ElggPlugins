<?php
	echo $vars['url'] . "mod/custom_white_theme/graphics/file_icons/pages.gif";
?>