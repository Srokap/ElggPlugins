<?php
	echo $vars['url'] . "mod/custom_white_theme/graphics/group_icons/defaultsmall.gif";
?>