<?php

	/**
	 * Elgg thewire view page
	 * 
	 * @package ElggTheWire
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider <info@elgg.com>
	 * @copyright Curverider Ltd 2008-2010
	 * @link http://elgg.com/
	 * 
	 */

	$newest_members = elgg_get_entities_from_metadata(array('metadata_names' => 'icontime', 'types' => 'user', 'limit' => 18));
	
?>

<div class="sidebarBox">
<h3><?php echo elgg_echo('riverdashboard:recentmembers') ?></h3>
<div class="membersWrapper"><br />
<?php 
	foreach($newest_members as $mem){
		echo "<div class=\"recentMember\">" . elgg_view("profile/icon",array('entity' => $mem, 'size' => 'tiny')) . "</div>";
	}
?>
<div class="clearfloat"></div>
</div>
</div>
<div class="shortcuts">
<table
style="text-align: left; width: 190px; background-color: white; height: 46px; margin-left: auto; margin-right: auto;"
border="0" cellpadding="0" cellspacing="0">
<tbody>
<tr align="left">
<td colspan="2" rowspan="1"
style="vertical-align: middle; background-color: rgb(51, 51, 51); height: 22px; text-align: left;"><small
style="font-weight: bold;"><span
style="color: white; font-family: Verdana; font-size: 11px;">&nbsp;Shortcuts</span></small><br>
</td>
</tr>
<tr>
<td style="vertical-align: top;"><br>
</td>
<td style="vertical-align: top;"><br>
</td>
</tr>
<tr>
<td colspan="2" rowspan="1"
style="vertical-align: top; color: rgb(51, 102, 255);">&nbsp;<a
href="../mod/notifications/"><span
style="font-family: Verdana; font-size: 11px;">Notification Settings</span></a><br>
</td>
</tr>
<tr>
<td colspan="2" rowspan="1"
style="vertical-align: top; color: rgb(51, 102, 255);">&nbsp;<a
href="../mod/invitefriends/"><span
style="font-family: Verdana; font-size: 11px;">Invite Friends</span></a><br>
</td>
</tr>
<tr>
<td colspan="2" rowspan="1"
style="vertical-align: top; color: rgb(51, 102, 255);">&nbsp;<a
href="../mod/messages/send.php"><span
style="font-family: Verdana; font-size: 11px;">Send a Message</span></a><br>
</td>
</tr>
<tr>
<td colspan="2" rowspan="1"
style="vertical-align: top; color: rgb(51, 102, 255);">&nbsp;<a
href="../pg/groups/new/"><span
style="font-family: Verdana; font-size: 11px;">Create a Group</span></a><br>
</td>
</tr>
<tr>
</tr>
<tr>
<td colspan="2" rowspan="1"
style="vertical-align: top; color: rgb(51, 102, 255);">&nbsp;<a
href=""><span
style="font-family: Verdana; font-size: 11px;"></span></a><br>
</td>
</tr>
</tbody>
</table>
</div>