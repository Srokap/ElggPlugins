<?php
/* LiangLeeCatchDrones
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @Package Liang Lee Framework
 * @subpackage LiangLeeCatchDrones
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File play.php
 */
 
$graphics_url = 'mod/LiangleeFramework/media/';

if (elgg_get_plugin_setting('liang_lee_ctd', 'LiangLeeCatchDrones') == 'ctdl') {
if (!elgg_is_logged_in()) {
register_error(elgg_echo('lianglee:need:login'));
forward(REFERER);
   }
 }
if (elgg_get_plugin_setting('liang_lee_ctd', 'LiangLeeCatchDrones') == 'cdt0') {
if (elgg_is_active_plugin('LiangleeFramework')) {
$content = elgg_view('LiangLeeCatchDrones/head'); 
   }
}
$title = elgg_echo('LiangLeeCatchDrones');

$params = array(
	'content' => $content,
	'title' => $title,
	'sidebar' => elgg_view('LiangLeeCatchDrones/sidebar'),
	'filter_override' => false
);

$body = elgg_view_layout('content', $params);

echo elgg_view_page($title, $body);
