<?php
/* LiangLeeCatchDrones
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @Package Liang Lee Framework
 * @subpackage LiangLeeCatchDrones
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File version.php
 */
$LiangLee_ctd_version = '20120623';
$LiangLee_ctd_release = '1.0.0'; 
