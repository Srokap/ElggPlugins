<?php
/* LiangLeeCatchDrones
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @Package Liang Lee Framework
 * @subpackage LiangLeeCatchDrones
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File start.php
 */
 
elgg_register_event_handler('init', 'system', 'LiangLeeCatchDrones');

function LiangLeeCatchDrones() {
elgg_register_page_handler('LiangLeeCatchDrones', 'LiangLeeCatchDrones_handler');

$context = array('LiangLeeCatchDrones');

$url = elgg_get_site_url().'LiangLeeCatchDrones/play';	

$item = new ElggMenuItem('LiangLeeCatchDrones', elgg_echo('LiangLeeCatchDrones'), $url);

elgg_register_menu_item('site', $item);

if (!elgg_is_active_plugin('LiangleeFramework')) {
 if (elgg_is_admin_logged_in()) {
 register_error(elgg_echo('lianglee:framewrok:miss'));
 } else {
 register_error(elgg_echo('lianglee:framewrok:miss:code'));	
     }
    }  
  }
function LiangLeeCatchDrones_handler($page) {

	$base_dir = elgg_get_plugins_path() . 'LiangLeeCatchDrones/pages/LiangLeeCatchDrones';

	if (!isset($page[0])) {
		$page = array('all');
	}

	switch ($page[0]) {
		case "play":
			include "$base_dir/play.php";
			break;
			
		default:
			return false;
	}
	return true;
}


