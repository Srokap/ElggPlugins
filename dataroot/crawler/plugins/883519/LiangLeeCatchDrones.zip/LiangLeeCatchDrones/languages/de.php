<?php
/* LiangLeeCatchDrones
 * @package Liang Lee Framework
 * @subpackage Liang Lee Videos Download
 * @author Liang Lee
 * @copyright LIANG LEE 2012
 * @File en.php
 */

$germen = array(	
	'LiangLeeCatchDrones' => "Catch The Drones",
    'liangleecatchdrones' => "Catch The Drones",
	'lianglee:framewrok:miss' => "LiangLeeFramewrok is Missing",
	'lianglee:framewrok:miss:code' => "Error: #LF52 , Please inform site Administrator. ",
	
);
					
add_translation("de", $english);
