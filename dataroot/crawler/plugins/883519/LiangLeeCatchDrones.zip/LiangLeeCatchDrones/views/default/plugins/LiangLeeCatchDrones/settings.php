<?php
/* LiangLeeCatchDrones
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @Package Liang Lee Framework
 * @subpackage LiangLeeCatchDrones
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File settings.php
 */
 
 /**
* configue path
**/
$path = elgg_get_plugins_path();

/**
* Liang Lee ctd Url
**/
$liang_lee_ctd_url = "LiangLeeCatchDrones";

/**
* Load Version
**/

$Lianglee_ctd_ver = $path. $liang_lee_ctd_url. "/version.php";
/**
* Get Veersion
**/
include $Lianglee_ctd_ver;

/**
* Load Languages
**/
$liang_lee_ctd_copytights = elgg_echo('lianglee:copyr:12');

/**
* Save settings
**/

$liang_lee_ctd = elgg_view('input/dropdown', array(
    'name' => 'params[liang_lee_ctd]',
    'value' => $vars['entity']->liang_lee_ctd,
    'options_values' => array('ctdl' => 'Non-Logged in users can not play', 'cdt0' => 'Non-Looged in users can Play')
        ));				
/**
* Setting Page
**/
$settings = <<<__HTML

    <div>
	
        <p><i>$liang_lee_ctd_label</i><br>$liang_lee_ctd</p>
		<hr>
		<p><i>$liang_lee_ctd_copytights</i>

		<p>Release: $LiangLee_ctd_release</p>
		<p>Version: $LiangLee_ctd_version</p>
    </div>
    
</div>
__HTML;
echo $settings;