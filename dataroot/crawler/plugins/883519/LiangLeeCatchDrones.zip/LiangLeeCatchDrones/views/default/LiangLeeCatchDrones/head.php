<?php
/* LiangLeeCatchDrones
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @Package Liang Lee Framework
 * @subpackage LiangLeeCatchDrones
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File head.php
 */
$siteURL = elgg_get_site_url().'mod/LiangLeeCatchDrones/vendors/LiangLeeCatchDrones/LiangLeeCatchDrones.swf';
echo "<div align=\"center\">\n"; 
echo "  <object classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" codebase=\"http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0\" width=\"717\" height=\"465\">\n"; 
echo "    <param name=\"movie\" value=\"".$siteURL."\">\n"; 
echo "    <param name=\"quality\" value=\"high\">\n"; 
echo "    <embed src=\"".$siteURL."\" quality=\"high\" pluginspage=\"http://www.macromedia.com/go/getflashplayer\" type=\"application/x-shockwave-flash\" width=\"717\" height=\"465\"></embed>\n"; 
echo "  </object>\n"; 
echo "</div>\n"; 
echo "\n";
?>