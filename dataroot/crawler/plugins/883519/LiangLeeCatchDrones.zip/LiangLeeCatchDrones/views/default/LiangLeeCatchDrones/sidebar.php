<?php
/* LiangLeeCatchDrones
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @Package Liang Lee Framework
 * @subpackage LiangLeeCatchDrones
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File slidebar.php
 */
$url = elgg_get_site_url().'LiangLeeCatchDrones/play';	
 
elgg_register_menu_item('page', array(
				'name' => 'home',
				'text' => elgg_echo('lianglee:home'),
				'href' => elgg_get_site_url(),
			));
elgg_register_menu_item('page', array(
				'name' => 'reset',
				'text' => elgg_echo('lianglee:reset'),
				'href' => $url,
			));


?>