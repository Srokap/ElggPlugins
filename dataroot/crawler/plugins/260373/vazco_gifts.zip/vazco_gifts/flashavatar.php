<?php

	/**
	 * Tidypics Thumbnail
	 * 
	 */

	// Get engine
	include_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
		
	// Get file GUID
	$file_guid = (int) get_input('file_guid',0);
	$file = new ElggFile($file_guid);
	$contents = '';
	if ($file) {
		$contents = $file->grabFile();		
	}

	// Open error image if file was not found
	/*if (!isset($contents) || is_null($contents) || $file->getSubtype()!='avatar') {
		//forward('mod/tidypics/graphics/img_error.jpg');
	} //end of default error image
	*/
	// Return the thumbnail and exit
	header("Content-type: ".$file->mimetype);
	echo $contents;
	exit;
?>