<?php
	global $CONFIG;
	$path = $CONFIG->wwwroot.'mod/vazco_gifts/';
?>
<script type="text/javascript" src="<?php echo $path;?>js/thickbox/thickbox.php"></script>
<link rel="stylesheet" href="<?php echo $path;?>js/thickbox/thickbox.css" type="text/css" media="screen" />