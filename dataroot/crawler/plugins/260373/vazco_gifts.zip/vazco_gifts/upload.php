<?php 
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	set_context('vazco_gifts');
	$title = elgg_echo('vazco_gifts:upload');
	$body = elgg_view('vazco_gifts/upload');
	
	page_draw($title,elgg_view_layout("two_column_left_sidebar", '', elgg_view_title($title) . $body));	
	?>