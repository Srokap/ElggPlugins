<?php
	/**
	 * Elgg groups plugin
	 * 
	 * @package ElggGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	/**
	 * Initialise the groups plugin.
	 * Register actions, set up menus
	 */

    require_once(dirname(__FILE__)."/models/model.php");
    
	function vazco_gifts_init()
	{
		global $CONFIG;
		
		define('VAZCO_GIFTS_ADMIN',2);
		define('VAZCO_GIFTS_PATH','vazco_gifts');
		
		extend_view('css','vazco_gifts/css');
		extend_view('vazco_karma/history','vazco_gifts/funds',501);
		extend_view('profile/userdetails','vazco_gifts/gifts');

		if (isadminloggedin() && get_context() == 'admin' || get_context() == 'vazco_gifts')
			add_submenu_item ( elgg_echo ( 'vazco_gifts:menu:edit' ), $CONFIG->wwwroot . 'pg/vazco_gifts/edit' );
		if (isadminloggedin() && get_context() == 'vazco_gifts')
			add_submenu_item ( elgg_echo ( 'vazco_gifts:menu:upload' ), $CONFIG->wwwroot . 'pg/vazco_gifts/upload' );

		register_action("vazco_gifts/makegold",false,$CONFIG->pluginspath . "vazco_gifts/actions/makegold.php");
		register_action("vazco_gifts/upload",false,$CONFIG->pluginspath . "vazco_gifts/actions/upload.php");
		register_action("vazco_gifts/select",false,$CONFIG->pluginspath . "vazco_gifts/actions/select.php");
		register_action("vazco_gifts/delete",false,$CONFIG->pluginspath . "vazco_gifts/actions/delete.php");
		register_action("vazco_gifts/edit",false,$CONFIG->pluginspath . "vazco_gifts/actions/edit.php");
		
		//Extend hover-over menu	
		extend_view('profile/menu/links','vazco_gifts/menu');			
	}

	
	function vazco_gifts_page_handler($page) {
		
		global $CONFIG;
		
		if (isset($page[0])) 
		{
			switch($page[0]) 
			{
				case "upload":
					include(dirname(__FILE__) . "/upload.php");
					break;
				case "edit":
					include(dirname(__FILE__) . "/edit.php");
					break;
				case "select":
					$user_login = $page[1];
					include(dirname(__FILE__) . "/select.php");
					break;
			}
		}
	}
	
	register_page_handler('vazco_gifts','vazco_gifts_page_handler');	
	register_elgg_event_handler('init','system','vazco_gifts_init');
	
?>