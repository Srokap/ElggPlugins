<?php 
	require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/thickboxlibraries.php");
	admin_gatekeeper();
	//set owner to site admin.
	$owner = VAZCO_GIFTS_ADMIN;
	$limit = 400;
	$gifts = get_entities("object", "gift", $owner, "", $limit, 0, false);

?>

<div class="contentWrapper">
	<form action="<?php echo $vars['url']; ?>action/vazco_gifts/edit" method="post" name="editMulti">
	<?php echo elgg_echo('vazco_gifts:edit:description');?>
		<div class="avatar_container">
		<?php
			$counter = 0;
		 	echo '<div class=gifts_wrapper">';
			foreach($gifts as $gift) {
				$counter++;
				if ($counter == 6){
					echo '</div><div class="gift_wrapper">';
					$counter = 0;
				}	
				echo '<div class="gift_box">';
					echo '<div class="gift_icon">';
						echo elgg_view('vazco_gifts/icon', array('gift' => $gift));
					echo '</div><div class="gift_info">';
						echo '<div>';
							echo elgg_echo('vazco_gift:name');
							echo elgg_view('input/text', array('internalname' => "name[{$gift->guid}]", 'value' => $gift->name));
						echo '</div><div>';
							echo elgg_echo('vazco_gift:price');
							echo elgg_view('input/text', array('internalname' => "price[{$gift->guid}]", 'value' => $gift->price));
						echo '</div><div>';
							echo elgg_echo('vazco_gift:description');
							echo elgg_view('input/longtext', array('internalname' => "description[{$gift->guid}]", 'value' => $gift->desc));
						echo '</div><div>';
							echo elgg_view("output/confirmlink", array(
		                				'href' => $vars['url']."action/vazco_gifts/delete?file_guid=".$gift->guid,
		                				'text' => elgg_echo('vazco_gift:delete'),
		                				'confirm' => elgg_echo('vazco_gift:delete:confirm'),
		                		));	
							$checked = "";
							if ($gift->hidden)
								$checked = "checked=\"checked\"";
							echo '<span class="hide_gift">'.elgg_echo('vazco_gift:hidden').' <input type="checkbox" name="hidden['.$gift->guid.']" '.$checked.'></span>';	
						echo '</div>';
					echo '</div>';
				echo '<div class="clearfloat"></div></div>';
			}
			echo "</div>";
		?>
		</div>
	<p><input type="submit" class="submit_button" value="<?php echo elgg_echo("vazco_gift:edit:save"); ?>" /></p>	
	</form>		
</div>