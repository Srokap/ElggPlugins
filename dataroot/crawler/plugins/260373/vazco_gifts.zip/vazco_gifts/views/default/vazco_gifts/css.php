.user_menu_gifts{
	margin: 0;
	padding: 0;
}

.gift_picture{
	text-align: center;
	margin: 20px;	
}
.gift_desc_full{
	margin: 20px 80px;
	font-size: 120%;
}
.gift_full_title{
	text-align: center;
	font-weight: bold;
	font-family: Trebuchet MS, cursive, Times New Roman;
	font-size: 130%;
}
.gift_from a{
	display: block;
}
.gift_from{
	font-size: 80%;
	width: 110px;
}

.profile_gifts{
	-moz-border-radius:8px;
	background:#E9E9E9;
	border-bottom:1px solid #CCCCCC;
	border-right:1px solid #CCCCCC;
	margin: 0 0 20px;
	padding: 10px 0 0;
}

.profile_gifts .gift_box{
	float: left;
	margin: 3px;
	text-align:center;
}

.gift_icon,
.gift_info{
	float: left;
	font-size:90%;
}

.gift_title{
	text-align: center;
	font-weight: bold;
}

.gift_info .input-text{
	padding:3px;
}

.gift_icon_container{
	height:100px;
}
.gift_wrapper{
	height: 130px;
	width:100%;
}

.gift_delete_link{
	display:block;
}

.gift_box{
	margin: 20px 0 20px 10px;
}

.gift_info div.desc{
	margin-top:10px;
}

.gift_info div{
	margin: 3px 10px;
	width: 450px;
}

.hide_gift{
	float: right;
}

.gift_container{
	margin: 15px 40px;
}

.flash_icon{
	z-index:0;
	background: white;
	mox-border-radius:8px;
	border: 1px solid #CCCCCC;
}

.flash_large{
	width: 200px;
	height: 200px;
}

.flash_medium{
	width: 100px;
	height: 100px;
}
.flash_small{
	width: 40px;
	height: 40px;
}
.flash_tiny{
	width: 25px;
	height: 25px;
}
.flash_topbar{
	width: 16px;
	height: 16px;
}