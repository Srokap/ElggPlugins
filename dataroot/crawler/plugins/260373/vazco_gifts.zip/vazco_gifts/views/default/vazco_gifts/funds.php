<?php 
$login = $vars['user_login'];
$user = get_user_by_username($login);
?>
<div class="contentWrapper user_settings">
<h3><?php echo elgg_echo('vazco_gifts:funds');?></h3>
<p><?php echo sprintf(elgg_echo('vazco_gifts:funds:num'), vazco_funds::getFunds($user));?></p>
</div>