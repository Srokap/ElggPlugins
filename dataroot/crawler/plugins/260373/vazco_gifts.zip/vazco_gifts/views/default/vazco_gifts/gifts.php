<?php 
	require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/thickboxlibraries.php");
	$gifts = vazco_gifts::getGifts( page_owner_entity() );

	if (!empty($gifts)){
?>
<div class="profile_gifts">
	<div class="contentWrapper">
	<h4><?php echo elgg_echo('vazco_gifts:gifts');?></h4>
	<?php 
	foreach ($gifts as $giftArray){
		$gift = $giftArray[0];
		$sender = $giftArray[1];
		echo '<div class="gift_box">';
				echo '<a class="thickbox" href="'.$vars['url'].'mod/vazco_gifts/gift.php?file_guid='.$gift->guid.'&size=large"><img class="avatar_icon" src="'.$vars['url'].'mod/vazco_gifts/gifticon.php?file_guid='.$gift->guid.'&size=medium" border="0" class="tidypics_album_cover" title="'.$gift->name.'"  alt="gift' . $gift->guid . '"/></a>';
				echo '<div class="gift_from">';
					echo elgg_echo('vazco_gifts:from').' <a href="'.$sender->getURL().'">'.$sender->name.'</a>';
				echo '</div>';
		echo '</div>';
		
	}
	?>
	<div class="clearfloat">
	</div>
</div>
<?php }?>