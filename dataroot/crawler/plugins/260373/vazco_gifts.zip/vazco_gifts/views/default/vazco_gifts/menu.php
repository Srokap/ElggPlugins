<p class="user_menu_gifts">
		<a href="<?php echo $vars['url']; ?>pg/vazco_gifts/select/<?php echo $vars['entity']->username; ?>"><?php echo elgg_echo("vazco_gifts:select"); ?></a>	
</p>