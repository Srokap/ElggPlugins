<?php 
global $CONFIG;
?>

<a href="<?php echo $CONFIG->wwwroot?>action/vazco_gifts/makegold"><?php echo elgg_echo('vazco_gifts:makegold')?></a>