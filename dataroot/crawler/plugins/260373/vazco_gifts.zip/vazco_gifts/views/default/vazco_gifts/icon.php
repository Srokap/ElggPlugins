<?php
$gift = $vars['gift'];

if (vazco_gifts::isFlashAvatar($avatar)){
	echo elgg_view('vazco_gifts/flashicon', array('avatar' => $gift, 'size' => 'medium'));
}else{
	echo '<div class="gift_icon_container"><a class="thickbox" href="'.$vars['url'].'mod/vazco_gifts/gift.php?file_guid='.$gift->guid.'&size=large"><img src="'.$vars['url'].'mod/vazco_gifts/gifticon.php?file_guid='.$gift->guid.'" border="0" class="tidypics_album_cover"  alt="gift' . $gift->guid . '"/></a></div>';
}
?>