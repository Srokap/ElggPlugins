<?php 
	require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/thickboxlibraries.php");
	$receiver = $vars['receiver'];
	//set owner to site admin.
	$owner = VAZCO_GIFTS_ADMIN;
	$limit = 400;
	$gifts = get_entities("object", "gift", $owner, "", $limit, 0, false);

?>

<div class="contentWrapper">
	<p><?php echo elgg_echo('vazco_gifts:select:description');?></p>
	<p><?php echo elgg_echo('vazco_gifts:select:description2');?></p>
		<div class="avatar_container">
		<?php
			$counter = 0;
		 	echo '<div class=gifts_wrapper">';
			foreach($gifts as $gift) {
				$counter++;
				if ($counter == 6){
					echo '</div><div class="gift_wrapper">';
					$counter = 0;
				}	
				echo '<div class="gift_box">';
					echo '<div class="gift_icon">';
						echo '<div class="gift_icon_container"><a href="'.$vars['url'].'action/vazco_gifts/select?file_guid='.$gift->guid.'&receiver='.$receiver.'"><img class="avatar_icon" src="'.$vars['url'].'mod/vazco_gifts/gifticon.php?file_guid='.$gift->guid.'" border="0" class="tidypics_album_cover"  alt="gift' . $gift->guid . '"/></a></div>';
					echo '</div><div class="gift_info">';
						echo '<div>';
							echo '<span class="gift_title">'.$gift->name.'</span>';
						echo '</div><div>';
							echo sprintf(elgg_echo('vazco_gifts:select:price'),$gift->price);
						echo '</div><div class="desc">';
							echo $gift->desc;
						echo '</div>';
					echo '</div>';
				echo '<div class="clearfloat"></div></div>';
			}
			echo "</div>";
		?>
		</div>		
</div>
<?php echo elgg_view('vazco_gifts/funds', array('user_login' => get_loggedin_user()->username));?>