<?php 
	if (isset($vars['entity'])){
		$avatar = get_entity($vars['entity']->avatar);
	}else{
		$avatar = $vars['avatar'];
	}
	
	$filename = $vars['url'].'mod/vazco_gifts/flashavatar.php?file_guid='.$avatar->getGUID();
	$size = $vars['size'];
	if (!isset($size))
		$size = 'small';
	switch ($size){
		case 'large':
				$height = 200;
				$width = 200;
				break;
		case 'medium':
				$height = 100;
				$width = 100;
				break;
		case 'small':
				$height = 40;
				$width = 40;
				break;
		case 'tiny':
				$height = 25;
				$width = 25;
				break;
		case 'topbar':
				$height = 16;
				$width = 16;
				break;
		default:
				$height = 40;
				$width = 40;
				break;
	}
?>
<div class="flash_icon flash_<?php echo $size;?>">
<OBJECT class="flash_icon_object" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
	 codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" WIDTH=<?php echo $width;?> HEIGHT=<?php echo $height;?>>
	 <PARAM NAME=movie VALUE="<?php echo $filename;?>">
	 <PARAM NAME=quality VALUE=high>
	 <PARAM NAME=menu VALUE=false>
	 <param name="wmode" value="transparent">
	 <EMBED src="<?php echo $filename;?>" quality=high WIDTH=<?php echo $width;?> HEIGHT=<?php echo $height;?> wmode="transparent" TYPE="application/x-shockwave-flash" PLUGINSPAGE="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" menu="false">
	 </EMBED>
</OBJECT>
</div>