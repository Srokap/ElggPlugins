<?php
	require_once(dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "/thickboxlibraries.php");

	$performed_by = get_entity($vars['item']->subject_guid); // $statement->getSubject();
	$gift = get_entity($vars['item']->object_guid);
	$url = "<a href=\"{$performed_by->getURL()}\">{$performed_by->name}</a>";
	$string = sprintf(elgg_echo("vazco_gifts:river:selectgift"),$url, $gift->name);
	$string .= '<div class="river_content">'; 
	$string .= '<a class="thickbox" href="'.$vars['url'].'mod/vazco_gifts/gift.php?file_guid='.$gift->guid.'&size=large"><img class="avatar_icon" src="'.$vars['url'].'mod/vazco_gifts/gifticon.php?file_guid='.$gift->guid.'&size=small" border="0" class="tidypics_album_cover"  alt="gift' . $gift->guid . '"/></a>';
	$string .= '</div>'		
	
?>

<?php echo $string; ?>