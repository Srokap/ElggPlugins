<?php

	$polish = array(
	
		/*fields*/
		'vazco_gift:name' => 'Nazwa prezentu',
		'vazco_gift:price' => 'Cena (w punktach karmy)',
		'vazco_gift:description' => 'Opis',
	
		/*general*/
		'vazco_gifts:menu:edit' => 'Lista prezentów',
		'vazco_gifts:title:list' => 'Lista prezentów',
		'vazco_gifts:select' => 'Wręcz prezent',
		'vazco_gift:select:description' => 'Wręcz prezent',
		'vazco_gift:select:clicktochose' => 'Kliknij na obrazek prezentu aby wręczyć go znajomemu',
		'vazco_gift:edit:save' => 'Zapisz ustawienia prezentów',
		'vazco_gifts:edit:description' => 'Poniżej jest lista wszystkich prezentów dostępnych dla użytkowników. Prezent musi mieć nazwę i cenę aby być aktywnym.',
		'vazco_gifts:funds' => 'Fundusze',
		'vazco_gifts:funds:num' => 'Dostępne fundusze: %s',
		'vazco_gifts:gifts' => 'Prezenty',
		'vazco_gifts:from' => 'Od',
		'vazco_gifts:message' => '%s przesłał(a) Ci podarunek. Treść podarunku to:
%s

Odwiedź <a href="%s">swój profil</a> aby zobaczyć grafikę podarunku.',
		'vazco_gifts:message:title' => 'Ktoś przesłał Ci podarunek!',
	
		/**/
		'vazco_gifts:select:description' => 'Kliknij na prezent aby go wybrać. Odpowiednia ilość funduszy karma zostanie odliczona z twojego portfela.',
		'vazco_gifts:select:description2' => '(Twoje punkty karmy pozostaną niezmienione.)',
	
		'vazco_gifts:select:price' => 'Cena (w funduszach karmy): %s',
		
		
		/*administration*/
		'vazco_gifts:menu:upload' => 'Upload new gifts',
		'vazco_gifts:upload' => 'Upload new gifts',
		'vazco_gifts:settings:maxfilesize' => 'Maximum file size:',
		'vazco_gifts:upload:info' => 'Please upload image gifts in format: .jpg, .png, .gif',
		'vazco_gifts:norights' => 'You don\'t have proper rights',
		'vazco_gift:delete' => 'Delete',
		'vazco_gift:hidden' => 'Hidden',
		'vazco_gift:hidden' => 'Set gift as hidden',
		'vazco_gifts:makegold' => 'Generate karma funds from karma points fo all users',

	
		/*communicates*/
		'vazco_gifts:saved' => 'Prezent zamieszczony pomyślnie',
		'vazco_gifts:uploadfailed' => 'Wystąpił problem podczas zamieszczania prezentu',
		'vazco_gifts:notimage' => 'Nie wybrano obrazka',
		'vazco_gifts:limit' => 'Osiągnięto limit prezentów',
		'vazco_gifts:notdeleted' => 'Prezent nie mógł być skasowany',
		'vazco_gifts:deleted' => 'Prezent skasowany pomyślnie',
		'vazco_gift:delete:confirm' => 'Are you sure yo uwant to delete this gift?',
		'vazco_gifts:edit:success' => 'Settings saved succesfully',
		'vazco_gifts:toosmall' => 'The image has to be at least of size 200x200 px',
		'vazco_gifts:pricenotnumeric' => 'Price of at least one of the gifts is not numeric.',
		'vazco_gift:selected' => 'Prezent został pomyślnie dostarczony do użytkownika %s',
		'vazco_gift:notselected' => 'Prezent nie mógł być wysłany.',
		'vazco_gifts:nopoints' => 'Nie masz wystarczająco dużo funduszy karmy by kupić ten prezent',
		'vazco_gifts:goldmade' => 'Fundusze zostały pomyślnie wygenerowane',
		'vazco_gifts:goldnotmade' => 'Błąd podczas generowania funduszy karmy',
	
		/*River*/
		'vazco_gifts:river:selectgift' => '%s otrzymał(a) podarunek "%s"',	
	);
					
	add_translation("pl",$polish);

?>