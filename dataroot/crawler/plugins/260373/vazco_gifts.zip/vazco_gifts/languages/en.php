<?php

	$english = array(
	
		/*fields*/
		'vazco_gift:name' => 'Gift name',
		'vazco_gift:price' => 'Price (in karma points)',
		'vazco_gift:description' => 'Description',
	
		/*general*/
		'vazco_gifts:menu:edit' => 'Gift list',
		'vazco_gifts:title:list' => 'Gift list',
		'vazco_gifts:select' => 'Select a gift',
		'vazco_gift:select:description' => 'Select a gift',
		'vazco_gift:select:clicktochose' => 'Click a gift to choose it for your friend.',
		'vazco_gift:edit:save' => 'Save gift settings',
		'vazco_gifts:edit:description' => 'Below is the list of all the gifts available for users. Gift has to have name and price to be active.',
		'vazco_gifts:funds' => 'Funds',
		'vazco_gifts:funds:num' => 'Available funds: %s',
		'vazco_gifts:gifts' => 'Gifts',
		'vazco_gifts:from' => 'From',
		'vazco_gifts:message' => 'You received a gift from %s:
%s

The gift will be visible on <a href="%s">your profile.</a>',
		'vazco_gifts:message:title' => 'You received a gift!',
	
		/**/
		'vazco_gifts:select:description' => 'Click on a gift to select it. A proper amount of karma funds will be removed from your account.',
		'vazco_gifts:select:description2' => '(Your karma points will stay unchanged.)',
	
		'vazco_gifts:select:price' => 'Price (in karma funds): %s',
		
		
		/*administration*/
		'vazco_gifts:menu:upload' => 'Upload new gifts',
		'vazco_gifts:upload' => 'Upload new gifts',
		'vazco_gifts:settings:maxfilesize' => 'Maximum file size:',
		'vazco_gifts:upload:info' => 'Please upload image gifts in format: .jpg, .png, .gif',
		'vazco_gifts:norights' => 'You don\'t have proper rights',
		'vazco_gift:delete' => 'Delete',
		'vazco_gift:hidden' => 'Hidden',
		'vazco_gift:hidden' => 'Set gift as hidden',
		'vazco_gifts:makegold' => 'Generate karma funds from karma points fo all users',

	
		/*communicates*/
		'vazco_gifts:saved' => 'Gifts uploaded succesfully',
		'vazco_gifts:uploadfailed' => 'There was a problem uploading gift',
		'vazco_gifts:notimage' => 'No image selected',
		'vazco_gifts:limit' => 'Gift limit reached',
		'vazco_gifts:notdeleted' => 'Gift couldn\'t be deleted',
		'vazco_gifts:deleted' => 'Gift deleted succesfully',
		'vazco_gift:delete:confirm' => 'Are you sure yo uwant to delete this gift?',
		'vazco_gifts:edit:success' => 'Settings saved succesfully',
		'vazco_gifts:toosmall' => 'The image has to be at least of size 200x200 px',
		'vazco_gifts:pricenotnumeric' => 'Price of at least one of the gifts is not numeric.',
		'vazco_gift:selected' => 'The gift was sent to %s',
		'vazco_gift:notselected' => 'The gift couldn\'t be sent.',
		'vazco_gifts:nopoints' => 'You don\'t have enought points to buy this gift',
		'vazco_gifts:goldmade' => 'Points were succesfully generated',
		'vazco_gifts:goldnotmade' => 'Error while generating points',
	
		/*River*/	
		'vazco_gifts:river:selectgift' => '%s received a gift "%s"',
	);
					
	add_translation("en",$english);

?>