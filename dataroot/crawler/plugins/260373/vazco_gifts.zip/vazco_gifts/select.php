<?php 
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	set_context('friends');


	$title = elgg_echo('vazco_gifts:select');
	set_page_owner($user->guid);
	$body = elgg_view('vazco_gifts/select', array('receiver' => $user_login));
	    
	page_draw($title,elgg_view_layout("two_column_left_sidebar", '', elgg_view_title($title) . $body));	
?>