<?php 
	admin_gatekeeper();
	$names_array = get_input('name','');
	$hidden_array = get_input('hidden','');
	$price_array = get_input('price','');
	$description_array = get_input('description','');

	$error = false;
	foreach ($names_array as $guid=>$value){
		$gift = get_entity($guid);
		$gift->name 	= $value;
		$gift->hidden 	= $hidden_array[$guid];
		$gift->desc 	= $description_array[$guid];
		if (is_numeric($price_array[$guid])){
			$gift->price 	= (int) $price_array[$guid];
		}else{
			$error = true;
		}
	}
	if ($error){
		register_error(elgg_echo('vazco_gifts:pricenotnumeric'));
	}else{
		system_message(elgg_echo('vazco_gifts:edit:success'));
	}
	forward($_SERVER['HTTP_REFERER']);
?>