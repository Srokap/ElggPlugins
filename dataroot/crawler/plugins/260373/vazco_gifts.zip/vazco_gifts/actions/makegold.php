<?php 
	admin_gatekeeper();
	if (vazco_gifts::makegold()){
		system_message(elgg_echo('vazco_gifts:goldmade'));
	}else{
		register_error(elgg_echo('vazco_gifts:goldnotmade'));
	}
	forward($_SERVER['HTTP_REFERER']);
?>