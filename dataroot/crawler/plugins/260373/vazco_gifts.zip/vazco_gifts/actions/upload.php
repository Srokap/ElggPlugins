<?php
	require_once(dirname(dirname(__FILE__))."/models/model.php");
	global $CONFIG;

	if (!isadminloggedin()){
		register_error('vazco_gifts:norights');
		forward(get_input('forward_url', $_SERVER['HTTP_REFERER']));
	}
	// Get common variables
	$access_id = ACCESS_PUBLIC;
	$gift_path = VAZCO_GIFTS_PATH;
	//TODO: set it in settings
	$cropImagesToSquare = true;
	
	$not_uploaded = array();
	$uploaded_images = array();	
	
	//get maximum file size from plugin settings
	$maxFileSize = get_plugin_setting('maxfilesize','vazco_gifts');
		if (!$maxFileSize || ((int) $maxFileSize) < 1 || $maxFileSize > 1048576) {
			$maxfilesize = 2048; //if file size is less than 1KB or greater than 1GB, default to 2MB
		} else {
			$maxfilesize = (int) $maxFileSize;
		}
	$maxfilesize = 1024 * $maxfilesize; //convert to bytes

	vazco_gifts::vazco_gifts_start();

	foreach($_FILES as $key => $sent_file) {
		if ($sent_file->size <= $maxfilesize){
			if (!empty($sent_file['name'])) {
				$name = $_FILES[$key]['name'];
				$mime = $_FILES[$key]['type'];
				$prefix = "";
	
				//file is a flash animation. Simply upload a file with no thumbnails.
				if ($mime == 'application/x-shockwave-flash'  && vazco_gifts::checkL($prefix, $gift_path)){
					$file = vazco_gifts::newGift();
					$filestorename = strtolower(time().$name);
					$file->setFilename($prefix.$filestorename);
					$file->setMimeType($mime);
					$file->originalfilename = $name;	
					$file->subtype="gift";
					$file->access_id = $access_id;	
					$file->open("write");
					$file->write(get_uploaded_file($key));
					$file->close();
					$result = $file->save();
					array_push($uploaded_images, $file->guid);				
				}
				//file is an image			
				elseif ( ($mime == 'image/jpeg' || $mime == 'image/gif' || $mime == 'image/png' || $mime == 'image/pjpeg') && vazco_gifts::checkL($prefix, $gift_path) ) {
					
					//this will save to users folder in /image/ and organize by photo album
					$file = vazco_gifts::newGift();
					$filestorename = strtolower(time().$name);
					$file->setFilename($prefix.$filestorename);
					$file->setMimeType($mime);	
					$file->originalfilename = $name;	
					$file->subtype="gift";
					$file->access_id = $access_id;	
					$file->open("write");
					$file->write(get_uploaded_file($key));
					$file->close();
					$result = $file->save();
	
					if ($result) { //file was saved; now create some thumbnails
						//check file size and remove picture if it exceeds the maximum

						if (filesize($file->getFilenameOnFilestore())<= $maxfilesize) {
							//check if image is big enought

							if (vazco_gifts::isImageAtLeastOfSize($file, 200,200)){
								array_push($uploaded_images, $file->guid);

								// Generate thumbnail
								//TODO: This code needs a complete rewrite - hardcoded to ~2.5 MB
								if (filesize($file->getFilenameOnFilestore())<= 2500000) {
									try {
										$thumblarge = get_resized_image_from_existing_file($file->getFilenameOnFilestore(),200,200, $cropImagesToSquare); 
									} catch (Exception $e) { $thumblarge = false; }
									try {
										$thumbmedium = get_resized_image_from_existing_file($file->getFilenameOnFilestore(),100,100, $cropImagesToSquare); 
									} catch (Exception $e) { $thumbmedium = false; }
									
									try {
										$thumbsmall = get_resized_image_from_existing_file($file->getFilenameOnFilestore(),40,40, $cropImagesToSquare); 
									} catch (Exception $e) { $thumbsmall = false; }
									try {
										$thumbtiny = get_resized_image_from_existing_file($file->getFilenameOnFilestore(),25,25, $cropImagesToSquare); 
									} catch (Exception $e) { $thumbtiny = false; }
									try {
										$thumbtopbar = get_resized_image_from_existing_file($file->getFilenameOnFilestore(),16,16, $cropImagesToSquare); 
									} catch (Exception $e) { $thumbtopbar = false; }
									try {
										$thumbmaster = get_resized_image_from_existing_file($file->getFilenameOnFilestore(),1,1, $cropImagesToSquare); 
									} catch (Exception $e) { $thumbmaster = false; }
								}
		
								vazco_gifts::saveThumbnail($thumblarge,$prefix,$filestorename,"large");
								vazco_gifts::saveThumbnail($thumbmedium,$prefix,$filestorename,"medium");
								vazco_gifts::saveThumbnail($thumbsmall,$prefix,$filestorename,"small");
								vazco_gifts::saveThumbnail($thumbtiny,$prefix,$filestorename,"tiny");
								vazco_gifts::saveThumbnail($thumbtopbar,$prefix,$filestorename,"topbar");
								vazco_gifts::saveThumbnail($thumbmaster,$prefix,$filestorename,"master");

								$file->large	= $prefix."large".$filestorename;
								$file->medium 	= $prefix."medium".$filestorename;
								$file->small 	= $prefix."small".$filestorename;
								$file->tiny 	= $prefix."tiny".$filestorename;
								$file->topbar 	= $prefix."topbar".$filestorename;
								$file->master 	= $prefix."master".$filestorename;
							}else{
								$file->delete();
								array_push($not_uploaded, $name);
								register_error(elgg_echo('vazco_gifts:toosmall'));
							}
							
						} else { //file exceeds file size limit, so delete it
							$file->delete();
							array_push($not_uploaded, $name);
						} //end of file size check
					} else { //file was not saved for some unknown reason
						array_push($not_uploaded, $name);
					} //end of file saved check and thumbnail creation
				} else { // file is not a supported image type 
					array_push($not_uploaded, $name);
				} //end of mimetype block
			} //end of file name empty check
		}else{//end of file size
			array_push($not_uploaded, $name);
		}
	} //end of for loop

	if (count($not_uploaded) == 0) {
		system_message(elgg_echo("vazco_gifts:saved"));
	} else {
		$error = elgg_echo("vazco_gifts:uploadfailed") . '<br />';
		foreach($not_uploaded as $im_name){
			$error .= ' [' . $im_name . ']  ';
		}
		$error .= '  ' . elgg_echo("vazco_gifts:notimage");
		if (vazco_gifts::isLimitReached(2))
			$error .= '  <br/>	' . elgg_echo('vazco_gifts:limit');
		
		register_error($error);
	} //end of upload check
	
	if (count($uploaded_images)>0) {
		//upload succesfull, redirect to the list of avatars
		forward($CONFIG->wwwroot . 'pg/vazco_gifts/edit');
	} else {
		forward(get_input('forward_url', $_SERVER['HTTP_REFERER'])); //upload failed, so forward to previous page
	}

?>