<?php 
	global $CONFIG;
	gatekeeper();
	$gift_guid = get_input('file_guid',0);
	$gift = get_entity($gift_guid);

	$user_login = get_input('receiver');
	$user = get_user_by_username($user_login);

	if (!vazco_gifts::hasPointsForAGift($gift)){
		register_error(elgg_echo('vazco_gifts:nopoints'));
		forward($_SERVER['HTTP_REFERER']);
	}

	if (vazco_gifts::select($gift, $user)){
		// add to river
	    add_to_river('river/vazco_gifts/select','give',$user->guid,$gift->guid);
	    
	    $sender_name = get_loggedin_user()->name;
	    $message = sprintf(elgg_echo('vazco_gifts:message'), $sender_name, $gift->desc, $user->getURL());
	    notify_user($user->guid,1,elgg_echo('vazco_gifts:message:title'),$message, NULL, "site");

		system_message(sprintf(elgg_echo('vazco_gift:selected'),$user->username));
	} 
	else{
		register_error('vazco_gift:notselected');
	}
	forward($user->getURL());
?>