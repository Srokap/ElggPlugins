<?php

	/**
	 * Tidypics Thumbnail
	 * 
	 */

	// Get engine
	include_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	
	global $CONFIG;
	
	$file_guid = (int) get_input('file_guid',0);
	$gift = get_entity($file_guid);	


	echo '<div class="gift_picture">';
		echo '<img src="'.$CONFIG->wwwroot.'mod/vazco_gifts/gifticon.php?file_guid='.$gift->guid.'&size=large" border="0" class="tidypics_album_cover"  alt="gift' . $gift->guid . '"/>';
	echo '</div><div class="gift_full_title">';
		echo $gift->name;
	echo '</div><div class="gift_desc_full">';
		echo $gift->desc;
	echo '</div>';
?>