<?php

	// Load Elgg engine
		require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	// Get the specified mood post
		$post = (int) get_input('moodpost');

	// If we can get out the mood post ...
		if ($moodpost = get_entity($post)) {
			
	// Get any comments
			//$comments = $moodpost->getAnnotations('comments');
		
	// Set the page owner
			set_page_owner($moodpost->getOwner());
			$page_owner = get_entity($moodpost->getOwner());
			
	// Display it
			$area2 = elgg_view_entity($moodpost, true);
			/*$area2 = elgg_view("object/mood",array(
											'entity' => $moodpost,
											'entity_owner' => $page_owner,
											'comments' => $comments,
											'full' => true
											));
			*/								
	// Set the title appropriately
		$title = sprintf(elgg_echo("mood:posttitle"),$page_owner->name,$moodpost->title);

	// Display through the correct canvas area
		$body = elgg_view_layout("two_column_left_sidebar", '', $area1 . $area2);
			
	// If we're not allowed to see the mood post
		} else {
			
	// Display the 'post not found' page instead
			$body = elgg_view("mood/notfound");
			$title = elgg_echo("mood:notfound");
			
		}
		
	// Display page
		page_draw($title,$body);
		
?>
