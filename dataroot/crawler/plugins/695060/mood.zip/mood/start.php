<?php

	/**
	 * mood initialisation
	 *
	 * These parameters are required for the event API, but we won't use them:
	 * 
	 * @param unknown_type $event
	 * @param unknown_type $object_type
	 * @param unknown_type $object
	 */

		function mood_init() {
			
			// Load system configuration
				global $CONFIG;
				
			// Set up menu for logged in users
				if (isloggedin()) {
		
					add_menu(elgg_echo('mood'), $CONFIG->wwwroot . "mod/mood/everyone.php");
			
				} 
				
			// Extend system CSS with our own styles, which are defined in the mood/css view
				elgg_extend_view('css','mood/css');
        extend_view('metatags', 'mood/metatags');
				
		    //extend views
				elgg_extend_view('profile/status', 'mood/profile_status');
				
			// Register a page handler, so we can have nice URLs
				register_page_handler('mood','mood_page_handler');
				
			// Register a URL handler for mood posts
				register_entity_url_handler('mood_url','object','mood');
				
			// Your mood widget
			    add_widget_type('mood',elgg_echo("mood:read"),elgg_echo("mood:yourdesc"));
			    
			// Register entity type
				register_entity_type('object','mood');
				
			// Listen for SMS create event
			register_elgg_event_handler('create','object','mood_incoming_sms');
			
			// Register granular notification for this type
			if (is_callable('register_notification_object'))
				register_notification_object('object', 'mood', elgg_echo('mood:newpost'));
			
			// Listen to notification events and supply a more useful message for SMS'
			register_plugin_hook('notify:entity:message', 'object', 'mood_notify_message');
		}
		
		function mood_pagesetup() {
			
			global $CONFIG;

			//add submenu options
				if (get_context() == "mood") {
					if ((page_owner() == $_SESSION['guid'] || !page_owner()) && isloggedin()) {
						add_submenu_item(elgg_echo('mood:read'),$CONFIG->wwwroot."pg/mood/" . $_SESSION['user']->username);
						add_submenu_item(elgg_echo('mood:everyone'),$CONFIG->wwwroot."mod/mood/everyone.php");
						//add_submenu_item(elgg_echo('mood:add'),$CONFIG->wwwroot."mod/mood/add.php");
					} 
				}
			
		}
		
		/**
		 * mood page handler; allows the use of fancy URLs
		 *
		 * @param array $page From the page_handler function
		 * @return true|false Depending on success
		 */
		function mood_page_handler($page) {
			
			// The first component of a mood URL is the username
			if (isset($page[0])) {
				set_input('username',$page[0]);
			}
			
			// The second part dictates what we're doing
			if (isset($page[1])) {
				switch($page[1]) {
					case "friends":		// TODO: add friends mood page here
										break;
                                        case "read":            set_input('moodpost',$page[2]);
                                               include(dirname(__FILE__) . "/read.php"); return true;
                                                                                break;
				}
			// If the URL is just 'mood/username', or just 'mood/', load the standard mood index
			} else {
				require(dirname(__FILE__) . "/index.php");
				return true;
			}
			
			return false;
			
		}

		function mood_url($moodpost) {
			
			global $CONFIG;
			return $CONFIG->url . "pg/mood/" . $moodpost->getOwnerEntity()->username;
			
		}
		
		/**
		 * Returns a more meaningful message for SMS messages.
		 *
		 * @param unknown_type $hook
		 * @param unknown_type $entity_type
		 * @param unknown_type $returnvalue
		 * @param unknown_type $params
		 */
		function mood_notify_message($hook, $entity_type, $returnvalue, $params)
		{
			$entity = $params['entity'];
			$to_entity = $params['to_entity'];
			$method = $params['method'];
			if (($entity instanceof ElggEntity) && ($entity->getSubtype() == 'mood'))
			{
				$descr = $entity->description;
				if ($method == 'sms') {
					$owner = $entity->getOwnerEntity();
					return $owner->username . ': ' . $descr;
				}
				if ($method == 'email') {
					$owner = $entity->getOwnerEntity();
					return $owner->username . ': ' . $descr . "\n\n" . $entity->getURL();
				}
			}
			return null;
		}
		
		/**
		 * Create a new mood post.
		 *
		 * @param string $post The post
		 * @param int $access_id Public/private etc
		 * @param int $parent Parent post (if any)
		 * @param string $method The method (default: 'site')
		 * @return bool
		 */
		function mood_save_post($post, $access_id, $parent=0, $method = "site")
		{
			
			global $SESSION; 
			
			// Initialise a new ElggObject
			$mood = new ElggObject();
			
			// Tell the system it's a mood post
			$mood->subtype = "mood";
			
			// Set its owner to the current user
			$mood->owner_guid = get_loggedin_userid();
			
			// For now, set its access to public (we'll add an access dropdown shortly)
			$mood->access_id = $access_id;
			
			// Set its description appropriately
			$mood->description = elgg_substr(strip_tags($post), 0, 160);
			
		    // add some metadata
	        $mood->method = $method; //method, e.g. via site, sms etc
	        $mood->parent = $parent; //used if the note is a reply
	        
	        //save
			$save = $mood->save();

			if($save)
				add_to_river('river/object/mood/create','create',$SESSION['user']->guid,$mood->guid);
	        
	        return $save;

		}
		
		/**
		 * Listen and process incoming SMS'
		 */
		function mood_incoming_sms($event, $object_type, $object)
		{
			if (($object) && ($object->subtype == get_subtype_id('object', 'sms')))
			{
				// Get user from phone number
				if ((is_plugin_enabled('smsclient')) && (is_plugin_enabled('smslogin')))
				{
					// By this stage the owner should be logged in (requires SMS Login)
					if (mood_save_post($object->description, get_default_access(), 0, 'sms'))
						return false;
					
				}
			}
					
			return true; // always create the shout even if it can't be sent
		}
	
	// Make sure the mood initialisation function is called on initialisation
		register_elgg_event_handler('init','system','mood_init');
		register_elgg_event_handler('pagesetup','system','mood_pagesetup');
		
	// Register actions
		global $CONFIG;
		register_action("mood/add",false,$CONFIG->pluginspath . "mood/actions/add.php");
		register_action("mood/delete",false,$CONFIG->pluginspath . "mood/actions/delete.php");
		
?>
