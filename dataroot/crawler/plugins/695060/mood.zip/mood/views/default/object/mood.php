<?php

	if (isset($vars['entity'])) {
    		
    		$user_name = $vars['entity']->getOwnerEntity()->name;
    		$username = $vars['entity']->getOwnerEntity()->username;
    		
    		//if the note is a reply, we need some more info
    		
			$note_url = '';
			$note_owner = elgg_echo("mood:notedeleted");
    		
?>
<div class="mood-singlepage">
	<div class="mood-post">
			    
	    <!-- the actual shout -->
		<div class="note_body">

	    <div class="mood_icon">
	    <?php
		        echo elgg_view("profile/icon",array('entity' => $vars['entity']->getOwnerEntity(), 'size' => 'tiny'));
	    ?>
	    </div>

			<div class="mood_options">
			
	    <div class="clearfloat"></div>
	    		<?php
				   
			// if the user looking at mood post can edit, show the delete link
			if ($vars['entity']->canEdit()) {
						
	  
					   echo "<div class='delete_note'>" . elgg_view("output/confirmlink",array(
															'href' => $vars['url'] . "action/mood/delete?moodpost=" . $vars['entity']->getGUID(),
															'text' => elgg_echo('delete'),
															'confirm' => elgg_echo('deleteconfirm'),
														)) . "</div>";
			
			} //end of can edit if statement
		?>
	    </div>
	    
		
		<?php
		    echo "<a href=\"/pg/mood/{$username}/read/{$vars['entity']->guid}\"><b>{$username}</b> is</a> ";
		    

		    $desc = $vars['entity']->description;

$desc = str_replace('ace','Ace <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/ace.gif" />',$desc);
$desc = str_replace('alert','Alert <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/alert.gif" />',$desc);
$desc = str_replace('alien','Alien <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/alien.gif" />',$desc);
$desc = str_replace('angel','Angelic <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/angel.gif" />',$desc);
$desc = str_replace('angry','Angry <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/angry.gif" />',$desc);
$desc = str_replace('apple','Apples <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/apple.gif" />',$desc);
$desc = str_replace('bandit','Bandits <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/bandit.gif" />',$desc);
$desc = str_replace('bat','Batty <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/bat.gif" />',$desc);
$desc = str_replace('beard','Beards <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/beard.gif" />',$desc);
$desc = str_replace('beer','Beer <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/beer.gif" />',$desc);
$desc = str_replace('blushed','Blushed <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/blush.gif" />',$desc);
$desc = str_replace('bored','Bored <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/bored.gif" />',$desc);
$desc = str_replace('bulb','Bulbs <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/bulb.gif" />',$desc);
$desc = str_replace('calm','Calm <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/calm.gif" />',$desc);
$desc = str_replace('camera','Cameras <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/camera.gif" />',$desc);
$desc = str_replace('carrot','Carrots <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/carrot.gif" />',$desc);
$desc = str_replace('cat','Cats <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/cat.gif" />',$desc);
$desc = str_replace('cheeky','Cheeky <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/cheeky.gif" />',$desc);
$desc = str_replace('cheerful','Cheerful <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/cheerful.gif" />',$desc);
$desc = str_replace('cherry','Cherries <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/cherry.gif" />',$desc);
$desc = str_replace('chinese','Chinese <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/chinese.gif" />',$desc);
$desc = str_replace('classic','Classic <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/classic.gif" />',$desc);
$desc = str_replace('cobra','Cobra <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/cobra.gif" />',$desc);
$desc = str_replace('cocktail','Cocktail <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/cocktail.gif" />',$desc);
$desc = str_replace('coffee','Coffee <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/coffee.gif" />',$desc);
$desc = str_replace('confused','Confused <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/confused.gif" />',$desc);
$desc = str_replace('cool','Cool <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/cool.gif" />',$desc);
$desc = str_replace('cross-eyed','Cross-eyed <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/cross-eyed.gif" />',$desc);
$desc = str_replace('crying','Crying <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/cry.gif" />',$desc);
$desc = str_replace('cyclops','Cyclops <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/cyclops.gif" />',$desc);
$desc = str_replace('dead','Dead <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/dead.gif" />',$desc);
$desc = str_replace('depressed','Depressed <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/depressed.gif" />',$desc);
$desc = str_replace('devilish','Devilish <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/devil.gif" />',$desc);
$desc = str_replace('devious','Devious <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/devious.gif" />',$desc);
$desc = str_replace('dinosaur','Dinosaur <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/dinosaur.gif" />',$desc);
$desc = str_replace('disappointed','Disappointed <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/disappointed.gif" />',$desc);
$desc = str_replace('ditsy','Ditsy <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/ditsy.gif" />',$desc);
$desc = str_replace('dog','Dog <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/dog.gif" />',$desc);
$desc = str_replace('dragon','Dragons <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/dragon.gif" />',$desc);
$desc = str_replace('drink','Drinks <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/drink.gif" />',$desc);
$desc = str_replace('embarrassed','Embarrassed <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/embarrassed.gif" />',$desc);
$desc = str_replace('ermm','Ermm <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/ermm.gif" />',$desc);
$desc = str_replace('evil','Evil <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/evil.gif" />',$desc);
$desc = str_replace('evolved','Evolved <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/evolved.gif" />',$desc);
$desc = str_replace('eyerolling','Eyerolling <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/eyeRoll.gif" />',$desc);
$desc = str_replace('fish','Fish <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/fish.gif" />',$desc);
$desc = str_replace('foureyes','Foureyed <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/foureyes.gif" />',$desc);
$desc = str_replace('gasmask','Gased <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/gasmask.gif" />',$desc);
$desc = str_replace('glasses','Glasses <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/glasses.gif" />',$desc);
$desc = str_replace('globe','Global <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/globe.gif" />',$desc);
$desc = str_replace('graduate','Graduated <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/graduate.gif" />',$desc);
$desc = str_replace('grimreaper','Grim Reaper <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/grimreaper.gif" />',$desc);
$desc = str_replace('grinning','Grins <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/grin.gif" />',$desc);
$desc = str_replace('hammer','Hammers <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/hammer.gif" />',$desc);
$desc = str_replace('happy','Happy <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/happy.gif" />',$desc);
$desc = str_replace('heart broken','Heart Broken <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/heart broken.gif" />',$desc);
$desc = str_replace('heart','Hearts <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/heart.gif" />',$desc);
$desc = str_replace('helicopter','Helicopter <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/helicopter.gif" />',$desc);
$desc = str_replace('house','House <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/house.gif" />',$desc);
$desc = str_replace('hungry','Hungry <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/hungry.gif" />',$desc);
$desc = str_replace('hurt','Hurt <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/hurt.gif" />',$desc);
$desc = str_replace('info','Informative <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/info.gif" />',$desc);
$desc = str_replace('jaguar','Jaguars <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/jaguar.gif" />',$desc);
$desc = str_replace('knocked-out','Knocked-out <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/knocked-out.gif" />',$desc);
$desc = str_replace('laugh','Laughs <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/laugh.gif" />',$desc);
$desc = str_replace('letter','Letters <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/letter.gif" />',$desc);
$desc = str_replace('lick','Licks <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/lick.gif" />',$desc);
$desc = str_replace('love','Love <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/love.gif" />',$desc);
$desc = str_replace('mad','Mad <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/mad.gif" />',$desc);
$desc = str_replace('minus','Negative <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/minus.gif" />',$desc);
$desc = str_replace('mischief','Mischievious <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/mischief.gif" />',$desc);
$desc = str_replace('mushroom','Mushrooms <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/mushroom.gif" />',$desc);
$desc = str_replace('music','Music <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/music.gif" />',$desc);
$desc = str_replace('needle','Needles <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/needle.gif" />',$desc);
$desc = str_replace('nervous','Nervous <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/nervous.gif" />',$desc);
$desc = str_replace('ninja','Ninja <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/ninja.gif" />',$desc);
$desc = str_replace('normal','Normal <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/normal.gif" />',$desc);
$desc = str_replace('ogre','Ogre <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/ogre.gif" />',$desc);
$desc = str_replace('old-man','Old <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/old-man.gif" />',$desc);
$desc = str_replace('paranoid','Paranoid <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/paranoid.gif" />',$desc);
$desc = str_replace('party','Party <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/party.gif" />',$desc);
$desc = str_replace('penguin','Penguin <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/penguin.gif" />',$desc);
$desc = str_replace('person','Person <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/person.gif" />',$desc);
$desc = str_replace('phone','Phones <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/phone.gif" />',$desc);
$desc = str_replace('pill','Pills <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/pill.png" />',$desc);
$desc = str_replace('pirate','Pirates <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/pirate.gif" />',$desc);
$desc = str_replace('plain','Plain <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/plain.gif" />',$desc);
$desc = str_replace('plus','Positive <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/plus.gif" />',$desc);
$desc = str_replace('ponder','Ponder <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/ponder.gif" />',$desc);
$desc = str_replace('puzzled','Puzzled <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/puzzled.gif" />',$desc);
$desc = str_replace('rambo','Rambo <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/rambo.gif" />',$desc);
$desc = str_replace('robot','Robot <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/robot.gif" />',$desc);
$desc = str_replace('rolleyes','Roll-eyes <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/rolleyes.gif" />',$desc);
$desc = str_replace('sad','Sad <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/sad.gif" />',$desc);
$desc = str_replace('scared','Scared <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/scared.gif" />',$desc);
$desc = str_replace('shocked','Shocked <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/shocked.gif" />',$desc);
$desc = str_replace('silly','Silly <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/silly.gif" />',$desc);
$desc = str_replace('skull','Skulls <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/skull.gif" />',$desc);
$desc = str_replace('sleeping','Sleeping <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/sleeping.gif" />',$desc);
$desc = str_replace('sleepy','Sleepy <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/sleepy.gif" />',$desc);
$desc = str_replace('smile','Smiles <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/smile.gif" />',$desc);
$desc = str_replace('smiley','Smileys <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/smiley.gif" />',$desc);
$desc = str_replace('smoker','Smoke <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/smoker.gif" />',$desc);
$desc = str_replace('speaker','Speakers <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/speaker.gif" />',$desc);
$desc = str_replace('speechless','Speechless <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/speechless.gif" />',$desc);
$desc = str_replace('spin','Spinning <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/spin.gif" />',$desc);
$desc = str_replace('square-eyed','Square-eyed <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/square-eyed.gif" />',$desc);
$desc = str_replace('surprised','Surprised <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/surprised.gif" />',$desc);
$desc = str_replace('thirsty','Thirsty <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/drink.gif" />',$desc);
$desc = str_replace('thumbdown','Thumbdown <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/thumbdown.gif" />',$desc);
$desc = str_replace('thumbup','Thumbup <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/thumbup.gif" />',$desc);
$desc = str_replace('tired','Tired <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/tired.gif" />',$desc);
$desc = str_replace('tv','TV <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/tv.gif" />',$desc);
$desc = str_replace('vampire','Vampire <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/vampire.gif" />',$desc);
$desc = str_replace('wink','Wink <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/wink.gif" />',$desc);
$desc = str_replace('jammin','Jammin <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/jammin.gif" />',$desc);
			echo parse_urls($desc);
		?>
		
		
		<div class="clearfloat"></div>
		
		<?php
			
				echo /* elgg_echo("mood:moodd") . " " . */ "Posted " . sprintf(elgg_echo("mood:strapline"),
								friendly_time($vars['entity']->time_created) 
				);
				
				//echo " via " . elgg_echo($vars['entity']->method) . ".";
			
		?>
		</div>
		
		
	</div>
</div>
<?php

		}

?>
