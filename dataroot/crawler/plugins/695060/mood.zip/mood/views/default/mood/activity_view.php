<?php

	/**
	 * New mood post view for the activity stream
	 */

	//grab the users latest from the mood
	$latest_mood = list_entities("object", "mood", $_SESSION['user']->getGUID(), 1, true, false, false);

?>

<script>
function textCounter(field,cntfield,maxlimit) {
    // if too long...trim it!
    if (field.value.length > maxlimit) {
        field.value = field.value.substring(0, maxlimit);
    } else {
        // otherwise, update 'characters left' counter
        cntfield.value = maxlimit - field.value.length;
    }
}
</script>

<div class="sidebarBox">

	<form action="<?php echo $vars['url']; ?>action/mood/add" method="post" name="noteForm">
<?php echo elgg_view('input/securitytoken'); ?>			
		<?php
			$display .= "<b>" . elgg_echo('mood:newpost') . "</b><textarea name='note' value='' onKeyDown=\"textCounter(document.noteForm.note,document.noteForm.remLen1,140)\" onKeyUp=\"textCounter(document.noteForm.note,document.noteForm.remLen1,140)\" id=\"mood_sidebarInputBox\">{$msg}</textarea><br /> <br /><?php echo $vars['url']; ?>";
			$display .= "<div class='mood_characters_remaining'><input readonly type=\"text\" name=\"remLen1\" size=\"3\" maxlength=\"3\" value=\"140\" class=\"mood_characters_remaining_field\">";
			echo $display;
			echo elgg_echo("mood:charleft") . "</div>";
		?>
			<input type="hidden" name="method" value="site" />
			<input type="hidden" name="location" value="activity" />
			<input type="hidden" name="access_id" value="2" />
			<input type="submit" value="<?php echo elgg_echo('save'); ?>" id="mood_submit_button" />
	</form>

	<div class="last_moodpost">
		<?php
			echo $latest_mood;
		?>
	</div>
	
	<img src="<?php echo $vars['url']; ?>mod/mood/graphics/river_icon_mood.gif" alt="the mood" align="left" style="margin-right:5px;"/><a href="<?php echo $vars['url']; ?>mod/mood/everyone.php" />Read the mood</a>

</div>
