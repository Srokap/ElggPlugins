	<p>
		<?php

			echo elgg_echo("mood:notfound");
		
		?>
	</p>