<?php
	// If there are any mood notes to view, view them
		if (is_array($vars['entity']) && sizeof($vars['entity']) > 0) {
			
			foreach($vars['entity'] as $shout) {
				
				echo elgg_view_entity($shout);
				
			}
			
		}

?>