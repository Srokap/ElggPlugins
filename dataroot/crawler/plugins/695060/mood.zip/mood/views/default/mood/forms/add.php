<?php

	/**
	 * Elgg mood edit/add page
	 */

		$mood_user = get_input('mood_username');
		if (!empty($mood_user)) { $msg = '@' . $mood_user . ' '; } else { $msg = ''; }

?>
<div class="post_to_mood">
<b><?php echo elgg_echo("mood:doing"); ?></b> <br /> <br />
<script language="javascript">
$(document).ready(function(e) {
							$("body select").msDropDown();
						   });
</script>
<script>
function textCounter(field,cntfield,maxlimit) {
    // if too long...trim it!
    if (field.value.length > maxlimit) {
        field.value = field.value.substring(0, maxlimit);
    } else {
        // otherwise, update 'characters left' counter
        cntfield.value = maxlimit - field.value.length;
    }
}
</script>

	<form action="<?php echo $vars['url']; ?>action/mood/add" method="post" name="noteForm">
<?php echo elgg_view('input/securitytoken'); ?>
 <select name="note" id="mood_large-textarea" onchange="showValue(this.value)" style="width:125px; font-family:Verdana; font-size:11px;">
    <option value="ace" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/ace.gif">Ace</option>
    <option value="alert" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/alert.gif">Alert</option>
    <option value="alien" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/alien.gif">Alien</option>
    <option value="angel" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/angel.gif">Angel</option>
    <option value="angry" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/angry.gif">Angry</option>
    <option value="apple" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/apple.gif">Apple</option>
    <option value="bandit" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/bandit.gif">Bandit</option>
    <option value="bat" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/bat.gif">Bat</option>
    <option value="beard" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/beard.gif">Beard</option>
    <option value="beer" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/beer.gif">Beer</option>
    <option value="blushed" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/blush.gif">Blushed</option>
    <option value="bored" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/bored.gif">Bored</option>
    <option value="bulb" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/bulb.gif">Bulb</option>
    <option value="calm" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/calm.gif">Calm</option>
    <option value="camera" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/camera.gif">Camera</option>
    <option value="carrot" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/carrot.gif">Carrot</option>
    <option value="cat" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/cat.gif">Cat</option>
    <option value="cheeky" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/cheeky.gif">Cheeky</option>
    <option value="cheerful" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/cheerful.gif">Cheerful</option>
    <option value="cherry" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/cherry.gif">Cherry</option>
    <option value="chinese" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/chinese.gif">Chinese</option>
    <option value="classic" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/classic.gif">Classic</option>
    <option value="cobra" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/cobra.gif">Cobra</option>
    <option value="cocktail" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/cocktail.gif">Cocktail</option>
    <option value="coffee" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/coffee.gif">Coffee</option>
    <option value="confused" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/confused.gif">Confused</option>
    <option value="cool" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/cool.gif">Cool</option>
    <option value="cross-eyed" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/cross-eyed.gif">Cross-Eyed</option>
    <option value="crying" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/cry.gif">Crying</option>
    <option value="cyclops" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/cyclops.gif">Cyclops</option>
    <option value="dead" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/dead.gif">Dead</option>
    <option value="depressed" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/depressed.gif">Depressed</option>
    <option value="devilish" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/devil.gif">Devilish</option>
    <option value="devious" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/devious.gif">Devious</option>
    <option value="dinosaur" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/dinosaur.gif">Dinosaur</option>
    <option value="disappointed" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/disappointed.gif">Disappointed</option>
    <option value="ditsy" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/ditsy.gif">Ditsy</option>
    <option value="dog" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/dog.gif">Dog</option>
    <option value="dragon" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/dragon.gif">Dragon</option>
    <option value="drink" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/drink.gif">Drink</option>
    <option value="embarrassed" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/embarrassed.gif">Embarrassed</option>
    <option value="ermm" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/ermm.gif">Ermm</option>
    <option value="evil" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/evil.gif">Evil</option>
    <option value="evolved" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/evolved.gif">Evolved</option>
    <option value="eyerolling" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/eyeRoll.gif">Eye Roll</option>
    <option value="fish" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/fish.gif">Fish</option>
    <option value="foureyes" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/foureyes.gif">Four-Eyes</option>
    <option value="gasmask" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/gasmask.gif">Gasmask</option>
    <option value="glasses" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/glasses.gif">Glasses</option>
    <option value="globe" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/globe.gif">Globe</option>
    <option value="graduate" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/graduate.gif">Graduate</option>
    <option value="grimreaper" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/grimreaper.gif">Grim Reaper</option>
    <option value="grinning" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/grin.gif">Grinning</option>
    <option value="hammer" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/hammer.gif">Hammer</option>
    <option value="happy" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/happy.gif">Happy</option>
    <option value="heart broken" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/heart broken.gif">Heart Broken</option>
    <option value="heart" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/heart.gif">Heart</option>
    <option value="helicopter" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/helicopter.gif">Helicopter</option>
    <option value="house" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/house.gif">House</option>
    <option value="hungry" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/hungry.gif">Hungry</option>
    <option value="hurt" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/hurt.gif">Hurt</option>
    <option value="info" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/info.gif">Info</option>
    <option value="jaguar" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/jaguar.gif">Jaguar</option>
    <option value="jammin"  selected="selected" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/jammin.gif">Jammin</option>
    <option value="knocked-out" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/knocked-out.gif">Knocked-out</option>
    <option value="laugh" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/laugh.gif">Laughing</option>
    <option value="letter" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/letter.gif">Letter</option>
    <option value="lick" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/lick.gif">Lick</option>
    <option value="love" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/love.gif">Love</option>
    <option value="mad" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/mad.gif">Mad</option>
    <option value="minus" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/minus.gif">Minus</option>
    <option value="mischief" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/mischief.gif">Mischief</option>
    <option value="mushroom" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/mushroom.gif">Mushroom</option>
    <option value="music" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/music.gif">Music</option>
    <option value="needle" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/needle.gif">Needle</option>
    <option value="nervous" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/nervous.gif">Nervous</option>
    <option value="ninja" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/ninja.gif">Ninja</option>
    <option value="normal" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/normal.gif">Normal</option>
    <option value="ogre" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/ogre.gif">Ogre</option>
    <option value="old-man" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/old-man.gif">Old-Man</option>
    <option value="paranoid" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/paranoid.gif">Paranoid</option>
    <option value="party" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/party.gif">Party</option>
    <option value="penguin" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/penguin.gif">Penguin</option>
    <option value="person" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/person.gif">Person</option>
    <option value="phone" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/phone.gif">Phone</option>
    <option value="pill" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/pill.png">Pill</option>
    <option value="pirate" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/pirate.gif">Pirate</option>
    <option value="plain" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/plain.gif">Plain</option>
    <option value="plus" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/plus.gif">Plus</option>
    <option value="ponder" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/ponder.gif">Ponder</option>
    <option value="puzzled" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/puzzled.gif">Puzzled</option>
    <option value="rambo" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/rambo.gif">Rambo</option>
    <option value="robot" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/robot.gif">Robot</option>
    <option value="rolleyes" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/rolleyes.gif">Roll-Eyes</option>
    <option value="sad" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/sad.gif">Sad</option>
    <option value="scared" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/scared.gif">Scared</option>
    <option value="shocked" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/shocked.gif">Shocked</option>
    <option value="silly" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/silly.gif">Silly</option>
    <option value="skull" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/skull.gif">Skull</option>
    <option value="sleeping" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/sleeping.gif">Sleeping</option>
    <option value="sleepy" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/sleepy.gif">Sleepy</option>
    <option value="smile" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/smile.gif">Smile</option>
    <option value="smiley" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/smiley.gif">Smiley</option>
    <option value="smoker" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/smoker.gif">Smoker</option>
    <option value="speaker" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/speaker.gif">Speaker</option>
    <option value="speechless" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/speechless.gif">Speechless</option>
    <option value="spin" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/spin.gif">Spin</option>
    <option value="square-eyed" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/square-eyed.gif">Square-eyed</option>
    <option value="surprised" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/surprised.gif">Surprised</option>
    <option value="thirsty" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/drink.gif">Thirsty</option>
    <option value="thumbdown" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/thumbdown.gif">Thumb down</option>
    <option value="thumbup" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/thumbup.gif">Thumb up</option>
    <option value="tired" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/tired.gif">Tired</option>
    <option value="tv" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/tv.gif">TV</option>
    <option value="vampire" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/vampire.gif">Vampire</option>
    <option value="wink" title="<?php echo $vars['url']; ?>/mod/mood/graphics/emoticons/wink.gif">Wink</option>

  </select>
			<input type="hidden" name="method" value="site" />&nbsp; &nbsp;
			<input type="submit" value="<?php echo elgg_echo('save'); ?>" />
	</form>
</div>
<?php echo elgg_view('input/urlshortener'); ?>
