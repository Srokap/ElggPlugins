<?php

/**
 * Elgg mood: add shout action
*/

// Make sure we're logged in (send us to the front page if not)
if (!isloggedin()) forward();

// Get input data
$body = get_input('note');
$access_id = (int)get_default_access();
if ($access_id == ACCESS_PRIVATE) {
	$access_id = ACCESS_LOGGED_IN; // Private mood messages are pointless
}
$method = get_input('method');
$parent = (int)get_input('parent', 0);
if (!$parent) {
	$parent = 0;
}
// Make sure the body isn't blank
if (empty($body)) {
	register_error(elgg_echo("mood:blank"));
	forward("mod/mood/add.php");
}

if (!mood_save_post($body, $access_id, $parent, $method)) {
	register_error(elgg_echo("mood:error"));
	forward("mod/mood/add.php");
}


// Success message
system_message(elgg_echo("mood:posted"));

// Forward
forward("mod/mood/everyone.php");

?>