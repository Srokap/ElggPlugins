<?php

	/**
	 * Elgg mood: delete note action
	 */

	// Make sure we're logged in (send us to the front page if not)
		if (!isloggedin()) forward();

	// Get input data
		$guid = (int) get_input('moodpost');
		
	// Make sure we actually have permission to edit
		$mood = get_entity($guid);
		if ($mood->getSubtype() == "mood" && $mood->canEdit()) {
	
		// Get owning user
				$owner = get_entity($mood->getOwner());
		// Delete it!
				$rowsaffected = $mood->delete();
				if ($rowsaffected > 0) {
		// Success message
					system_message(elgg_echo("mood:deleted"));
				} else {
					register_error(elgg_echo("mood:notdeleted"));
				}
		// Forward to the main mood page
				forward("mod/mood/?username=" . $owner->username);
		
		}
		
?>