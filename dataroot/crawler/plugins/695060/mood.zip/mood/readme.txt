/**
	 * Elgg Mood 1.7.1.1
	 * 
	 * @package ElggMood
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dipak C. Gajjar <dipak2711@yahoo.co.uk>
	 * @copyright Infoway Web Solutions 2011
	 * @link http://www.infowaywebsolutions.com/
*/

Install: Just drop it into the mod directory and that should be it.
