<?php
    gatekeeper();

    $guid = get_input( "guid" );
    $context = get_input( "context" );
    
    tabbed_dashboard_delete_tab( $context, $guid );
?>