<?php
    @include( dirname( __FILE__) . "/lib/tabbed_dashboard.inc" );
    
    function tabbed_dashboard_url( $entity = null, $context = "" ) {
       global $CONFIG;
       $page_owner = page_owner_entity();
       
       if ( $context == "profile" && $page_owner === false ) {
           global $_SESSION;
           $page_owner = $_SESSION['user'];
       }
       if ( $entity == null ) {
       // No tab provided, basic context URL returned (Default dashboard/profile)
            $url = $CONFIG->url . "pg/" . $context . "/" . $page_owner->username;
       } else {
           $title = $entity->title;
           $title = friendly_title($title);
           $page_owner = get_entity( $entity->owner_guid );
           
           if ( $entity->context == "dashboard" ) {
           // Dashboard
                $url = $CONFIG->url . "pg/" . $entity->context . "/" . $entity->getGUID() . "/" . $title;
           } else {
           // Profile
                $url = $CONFIG->url . "pg/" . $entity->context . "/" . $page_owner->username . "/" . $entity->getGUID() . "/" . $title;
           }
       }
       
       return $url;
    }
    
    // Extend system CSS with our own styles, which are defined in the status/css view
    extend_view('css','tabbed_dashboard/css');

    // Page handler
    register_entity_url_handler('tabbed_dashboard_url','object', tabbed_dashboard_get_subtype( "dashboard") );;
    register_entity_url_handler('tabbed_dashboard_url','object', tabbed_dashboard_get_subtype( "profile") );;
    
    // Register tabbed dashboard actions
    register_action('widgets/savepage', false, $CONFIG->pluginspath . "tabbed_dashboard/actions/widgets/savepage.php");
    register_action('tabs/add', false, $CONFIG->pluginspath . "tabbed_dashboard/actions/tabs/savetabs.php");
    register_action('tabs/move', false, $CONFIG->pluginspath . "tabbed_dashboard/actions/tabs/savetabs.php");
    register_action('tabs/remove', false, $CONFIG->pluginspath . "tabbed_dashboard/actions/tabs/remove.php");
?>