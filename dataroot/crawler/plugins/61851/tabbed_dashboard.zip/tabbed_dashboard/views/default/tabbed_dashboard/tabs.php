<?php 
    $context = get_context();
    
    if ( tabbed_dashboard_is_tabbed( $context ) ) {
    
        $current_tab_guid = tabbed_dashboard_get_tab_guid();

        $selected = "";
        if ( $current_tab_guid == "" ) {
            $selected = "selected";
        }
?>
<span class="<?php echo $selected; ?>tabbedpanetab">
&nbsp;<a href="<?php echo tabbed_dashboard_url( null, $context ); ?>"><?php echo ucfirst( $context ); ?></a>&nbsp;
</span>
<?php
        $tabs = tabbed_dashboard_get_tabs();
        
        // Display tabs (walk tree)
        if ( is_array( $tabs )) {
            for ( $i = 0 ; $i < sizeof( $tabs ); $i++ ) {
                $selected="";
                $current_tab = false;
                if ( $tabs[$i]->getGUID() == $current_tab_guid ) {
                    $selected = "selected";
                }
?>
<span class="<?php echo $selected; ?>tabbedpanetab">
<?php 
                echo elgg_view( "tabbed_dashboard/tab", array( "current_tab_guid" => $current_tab_guid, "position" => $i, "tabs" => $tabs, "tab" => $tabs[$i], "context", $context, "widget_context" => $widget_context ));
                
                if ( tabbed_dashboard_can_edit() ) {
                    echo elgg_view( "tabbed_dashboard/move-tab-left", array( "current_tab_guid" => $current_tab_guid, "position" => $i, "tabs" => $tabs, "tab" => $tabs[$i], "context" => $context, "widget_context" => $widget_context ));
                    echo elgg_view( "tabbed_dashboard/delete-tab", array( "current_tab_guid" => $current_tab_guid, "position" => $i, "tabs" => $tabs, "tab" => $tabs[ $i ], "context" => $context, "widget_context", $widget_context ));
                    echo elgg_view( "tabbed_dashboard/move-tab-right", array( "current_tab_guid" => $current_tab_guid, "position" => $i, "tabs" => $tabs, "tab" => $tabs[$i], "context" => $context, "widget_context" => $widget_context ));
                }
?>
</span>
<?php
            }
        }
                                              
        if ( tabbed_dashboard_can_edit() ) {
            echo elgg_view( "tabbed_dashboard/add-tab", array( "tabs" => $tabs, "tab" => $tabs[$i], "context" => $context, "widget_context" => $widget_context ));
        }
    }
?>