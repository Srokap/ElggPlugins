<?php
    $tab = $vars[ 'tab' ];
    $context = $vars[ 'context' ];
    
    echo elgg_view("output/confirmlink", array(
        'href' => $vars['url'] . "action/tabs/remove?context=" . $context . "&guid=" . $tab->getGUID(),
        'text' => elgg_echo( 'tabbed_dashboard:delete:char'),
        'confirm' => elgg_echo('deleteconfirm'),
        'title' => sprintf( elgg_echo( "tabbed_dashboard:removetab:title" ),  $tab->title ),
    ));
?>
&nbsp;