<?php
    $tab = $vars[ 'tab' ];
    $context = $vars[ 'context' ];
    $current_tab_guid = $vars[ 'current_tab_guid' ];
    
    if ( $tab->getGUID() == $current_tab_guid ) {
        $title = sprintf( elgg_echo( "tabbed_dashboard:currenttab:title" ), $tab->title );
    } else {
        $title = sprintf( elgg_echo( "tabbed_dashboard:othertab:title" ), $tab->title, $context );
    }
?>
&nbsp;<a href="<?php echo $tab->getURL() ;?>" title="<?php echo $title; ?>"><?php echo $tab->title; ?></a>&nbsp;
