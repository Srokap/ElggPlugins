<?php
	/**
	 * Elgg tabbed widgets CSS
	 */
?>

.customise_editpanel_pagedetails {
    margin-bottom: 20px;
}

.customise_editpanel_pagedetails label {
    color: #ff9900;
    vertical-align: baseline;
}

.customise_editpanel_pagedetails input {
    width: 200px;
}

#tabbedpaneprofile {
    border-top: 0.1em solid #CCCCCC;
}

#tabbedpanewrapper {
    margin-top: 20px;
    margin-bottom: 10px;
    border-top: 0.1em solid #CCCCCC;
    border-bottom: 0.1em solid #CCCCCC;
}

.tabbedpanetab {
    border-left: 0.1em solid #CCCCCC;
    border-right: 0.1em solid #CCCCCC;
    border-bottom: 0.1em solid #CCCCCC;
    margin-right: 5px;
}

.selectedtabbedpanetab {
    border-left: 0.1em solid #CCCCCC;
    border-right: 0.1em solid #CCCCCC;
    border-bottom: 0.1em solid #CCCCCC;
    margin-right: 5px; 
    font-weight: 700;
}

.tabbedpaneaddtab {
    border-left: 0.1em solid #CCCCCC;
    border-right: 0.1em solid #CCCCCC;
    border-bottom: 0.1em solid #CCCCCC;
    margin-right: 5px;
    padding-left: 2px;
    padding-right: 2px;
}