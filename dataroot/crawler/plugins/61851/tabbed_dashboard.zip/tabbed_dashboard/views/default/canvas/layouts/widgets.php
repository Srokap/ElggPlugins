<?php
    echo elgg_view( "tabbed_dashboard/page", $vars );
?>