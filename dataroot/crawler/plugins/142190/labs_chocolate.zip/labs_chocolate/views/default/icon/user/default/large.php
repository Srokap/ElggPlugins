<?php
	echo $vars['url'] . "mod/labs_chocolate/graphics/user_icons/defaultlarge.gif";
?>