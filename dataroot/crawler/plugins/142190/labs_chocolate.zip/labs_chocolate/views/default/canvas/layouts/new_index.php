<?php

	/**
	 * Elgg custom profile 
	 * You can edit the layout of this page with your own layout and style. Whatever you put in the file
	 * will replace the frontpage of your Elgg site.
	 * 
	 * @package Elgg
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.org/
	 */
	 
?>
<!-- Dependencies -->
<!-- Sam Skin CSS for TabView -->
<link rel="stylesheet" type="text/css" href="<?php echo $vars['url']; ?>mod/labs_chocolate/views/default/pg/tabview.css">

<!-- JavaScript Dependencies for Tabview: -->
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/labs_chocolate/views/default/pg/yahoo-dom-event.js"></script>
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/labs_chocolate/views/default/pg/element-min.js"></script>

<!-- OPTIONAL: Connection (required for dynamic loading of data) -->
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/labs_chocolate/views/default/pg/connection-min.js"></script>

<!-- Source file for TabView -->
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/labs_chocolate/views/default/pg/tabview-min.js"></script>

<div id="custom_index">
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/labs_chocolate/views/default/pg/jquery-1.3.2.min.js"></script><SCRIPT 
src="jquery-1.3.2.min.js" 
type=text/javascript></SCRIPT>

<SCRIPT type=text/javascript>
$(document).ready(function() {	

	//Show Banner
	$(".main_image .desc").show(); //Show Banner
	$(".main_image .block").animate({ opacity: 0.85 }, 1 ); //Set Opacity

	//Click and Hover events for thumbnail list
	$(".image_thumb ul li:first").addClass('active'); 
	$(".image_thumb ul li").click(function(){ 
		//Set Variables
		var imgAlt = $(this).find('img').attr("alt"); //Get Alt Tag of Image
		var imgTitle = $(this).find('a').attr("href"); //Get Main Image URL
		var imgDesc = $(this).find('.block').html(); 	//Get HTML of block
		var imgDescHeight = $(".main_image").find('.block').height();	//Calculate height of block	
		
		if ($(this).is(".active")) {  //If it's already active, then...
			return false; // Don't click through
		} else {
			//Animate the Teaser				
			$(".main_image .block").animate({ opacity: 0, marginBottom: -imgDescHeight }, 250 , function() {
				$(".main_image .block").html(imgDesc).animate({ opacity: 0.85,	marginBottom: "0" }, 250 );
				$(".main_image img").attr({ src: imgTitle , alt: imgAlt});
			});
		}
		
		$(".image_thumb ul li").removeClass('active'); //Remove class of 'active' on all lists
		$(this).addClass('active');  //add class of 'active' on this list only
		return false;
		
	}) .hover(function(){
		$(this).addClass('hover');
		}, function() {
		$(this).removeClass('hover');
	});
			
	//Toggle Teaser
	$("a.collapse").click(function(){
		$(".main_image .block").slideToggle();
		$("a.collapse").toggleClass("show");
	});
	
});//Close Function
</SCRIPT>

<body class="yui-skin-sam"> 
<script type="text/javascript">
var myTabs = new YAHOO.widget.TabView("demo");
</script> 

<div id="demo" class="yui-navset">
    <ul class="yui-nav">
        <li class="selected"><a href="#tab1"><em>Tab One Label</em></a></li>
        <li><a href="#tab2"><em>Tab Two Label</em></a></li>
        <li><a href="#tab3"><em>Tab Three Label</em></a></li>
    </ul>            
    <div class="yui-content">
        <div><p>Tab One Content</p></div>
        <div><p>Tab Two Content</p></div>
        <div><p>Tab Three Content</p></div>
    </div>
</div>

<DIV class=BODY>
<DIV class=container>
<H4>Image Gallery w/ Teaser - CSS &amp; jQuery Tutorial<SMALL>elgg</SMALL></H4></DIV>
<DIV class=container id=main>

<DIV class=main_image><img src="<?php echo $vars['url']; ?>mod/labs_chocolate/graphics/banner1.jpg"/>

<DIV class=desc><A class="collapse" 
href="<?php echo $vars['url']; ?>#">Close 
Me!</A> 
<DIV class=block>
<H2>Slowing Down</H2><SMALL>04/10/09</SMALL> 
<P>Autem conventio nimis quis ad, nisl secundum sed, facilisi, vicis augue 
regula, ratis, autem. Neo nostrud letatio aliquam validus eum quadrum, volutpat 
et.<BR><A href="http://labs.web.id/index.php" target=_blank>Artwork 
By Glenn Jones</A> </P></DIV></DIV></DIV>
<DIV class=image_thumb>
<UL>
  <LI><A 
  href="<?php echo $vars['url']; ?>mod/labs_chocolate/graphics/banner1.jpg"/>
  <img src="<?php echo $vars['url']; ?>mod/labs_chocolate/graphics/banner1_thumb.jpg"/>

  <DIV class=block>
  <H2>Slowing Down</H2><SMALL>04/10/09</SMALL> 
  <P>Autem conventio nimis quis ad, nisl secundum sed, facilisi, vicis augue 
  regula, ratis, autem. Neo nostrud letatio aliquam validus eum quadrum, 
  volutpat et.<BR><A href="http://labs.web.id/index.php" 
  target=_blank>Iwans</A> </P></DIV></LI>
  <LI><A 
  href="<?php echo $vars['url']; ?>mod/labs_chocolate/graphics/banner2.jpg"/>
  <img src="<?php echo $vars['url']; ?>mod/labs_chocolate/graphics/banner2_thumb.jpg"/>

  <DIV class=block>
  <H2>Organized Food Fight</H2><SMALL>04/11/09</SMALL> 
  <P>Autem conventio nimis quis ad, nisl secundum sed, facilisi, vicis augue 
  regula, ratis, autem. Neo nostrud letatio aliquam validus eum quadrum, 
  volutpat et. Autem conventio nimis quis ad, nisl secundum sed, facilisi, vicis 
  augue regula, ratis, autem. Neo nostrud letatio aliquam validus eum quadrum, 
  volutpat et.</P>
  <P>Autem conventio nimis quis ad, nisl secundum sed, facilisi, vicis augue 
  regula, ratis, autem. Neo nostrud letatio aliquam validus eum quadrum, 
  volutpat et.<BR><A href="http://labs.web.id/index.php" 
  target=_blank>Iwans</A></P></DIV></LI>
  <LI><A 
  href="<?php echo $vars['url']; ?>mod/labs_chocolate/graphics/banner3.jpg"/>
  <img src="<?php echo $vars['url']; ?>mod/labs_chocolate/graphics/banner3_thumb.jpg"/>

  <DIV class=block>
  <H2>Endangered Species</H2><SMALL>04/12/09</SMALL> 
  <P>Autem conventio nimis quis ad, nisl secundum sed, facilisi, vicis augue 
  regula, ratis, autem. Neo nostrud letatio aliquam validus eum quadrum, 
  volutpat et.<BR><A href="http://labs.web.id/index.php" 
  target=_blank>Iwans</A></P></DIV></LI>
  <LI><A 
  href="<?php echo $vars['url']; ?>mod/labs_chocolate/graphics/banner4.jpg"/>
  <img src="<?php echo $vars['url']; ?>mod/labs_chocolate/graphics/banner4_thumb.jpg"/>

  <DIV class=block>
  <H2>Evolution</H2><SMALL>04/13/09</SMALL> 
  <P>Autem conventio nimis quis ad, nisl secundum sed, facilisi, vicis augue 
  regula, ratis, autem. Neo nostrud letatio aliquam validus eum quadrum, 
  volutpat et. Autem conventio nimis quis ad, nisl secundum sed, facilisi, vicis 
  augue regula, ratis, autem. Neo nostrud letatio aliquam validus eum quadrum, 
  volutpat et.<BR><A href="http://labs.web.id/index.php" 
  target=_blank>Iwans</A></P></DIV></LI>
  <LI><A 
  href="<?php echo $vars['url']; ?>mod/labs_chocolate/graphics/banner5.jpg"/>
  <img src="<?php echo $vars['url']; ?>mod/labs_chocolate/graphics/banner5_thumb.jpg"/>

  <DIV class=block>
  <H2>Puzzled Putter</H2><SMALL>04/14/09</SMALL> 
  <P>Autem conventio nimis quis ad, nisl secundum sed, facilisi, vicis augue 
  regula, ratis, autem. Neo nostrud letatio aliquam validus eum quadrum, 
  volutpat et. <BR><A href="http://labs.web.id/index.php" 
  target=_blank>Iwans</A></P></DIV></LI>
  <LI><A 
  href="<?php echo $vars['url']; ?>mod/labs_chocolate/graphics/banner6.jpg"/>
  <img src="<?php echo $vars['url']; ?>mod/labs_chocolate/graphics/banner6_thumb.jpg"/>

  <DIV class=block>
  <H2>Secret Habit</H2><SMALL>04/15/09</SMALL> 
  <P>Autem conventio nimis quis ad, nisl secundum sed, facilisi, vicis augue 
  regula, ratis, autem.<BR><A href="http://labs.web.id/index.php" 
  target=_blank>Iwans</A></P></DIV></LI></UL></DIV></DIV>
<DIV class=container>
 </DIV> </DIV>

    <!-- left column content -->
    <div id="index_left">
        <!-- welcome message -->
        <div id="index_welcome"> 
        	<?php
        		if (isloggedin()){
	        		echo "<h2>" . elgg_echo("welcome") . " ";
        			echo $vars['user']->name;
        			echo "</h2>";
    			}
        	?>
            <?php
            	//include a view that plugins can extend
            	echo elgg_view("index/lefthandside");
            ?>
	        <?php
	            //this displays some content when the user is logged out
			    if (!isloggedin()){
	            	//display the login form
			    	echo $vars['area1'];
			    	echo "<div class=\"clearfloat\"></div>";
		        }
	        ?>
        </div>
<?php
    if(is_plugin_enabled('file')){
?> 	
        <!-- display latest files -->
        <div class="index_box">
            <h2><?php echo elgg_echo("custom:files"); ?></h2>
            <?php 
                if (!empty($vars['area2'])) {
                    echo $vars['area2'];//this will display files
                }else{
                    echo "<p><?php echo elgg_echo('custom:nofiles'); ?></p>";
                }
            ?>
        </div>
<?php
	}
	
    if(is_plugin_enabled('groups')){
?> 
        <!-- display latest groups -->
	    <div class="index_box">
            <h2><?php echo elgg_echo("custom:groups"); ?></h2>
        <?php 
                if (!empty($vars['area5'])) {
                    echo $vars['area5'];//this will display groups
                }else{
                    echo "<p><?php echo elgg_echo('custom:nogroups'); ?>.</p>";
                }
            ?>
    	</div>
<?php
	}
?>
    </div>
    
    <!-- right hand column -->
    <div id="index_right">
        <!-- more content -->
	    <?php
            //include a view that plugins can extend
            echo elgg_view("index/righthandside");
        ?>
        <!-- latest members -->
        <div class="index_box">
            <h2><?php echo elgg_echo("custom:members"); ?></h2>
            <div class="contentWrapper">
            <?php 
                if(isset($vars['area3'])) {
                    //display member avatars
                    foreach($vars['area3'] as $members){
                        echo "<div class=\"index_members\">";
                        echo elgg_view("profile/icon",array('entity' => $members, 'size' => 'small'));
                        echo "</div>";
                    }
                }
            ?>
	        <div class="clearfloat"></div>
	        </div>
        </div>
<?php
    if(is_plugin_enabled('blog')){
?> 
        <!-- latest blogs -->
        <div class="index_box">
            <h2><?php echo elgg_echo("custom:blogs"); ?></h2>
            <?php 
                if (isset($vars['area4'])) 
                    echo $vars['area4']; //display blog posts
            ?>
        </div>
<?php
	}

    if(is_plugin_enabled('bookmarks')){
?>
        <!-- display latest bookmarks -->
    	<div class="index_box">
            <h2><?php echo elgg_echo("custom:bookmarks"); ?></h2>
            <?php 
                if (isset($vars['area6'])) 
                    echo $vars['area6']; //display bookmarks
            ?>
        </div>
<?php
	}
?>
    </div>
    <div class="clearfloat"></div>
</div>