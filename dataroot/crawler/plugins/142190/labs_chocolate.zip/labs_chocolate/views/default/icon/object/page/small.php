<?php
	echo $vars['url'] . "mod/labs_chocolate/graphics/file_icons/pages.gif";
?>