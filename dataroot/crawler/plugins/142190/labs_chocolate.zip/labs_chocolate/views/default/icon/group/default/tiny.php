<?php
	echo $vars['url'] . "mod/labs_chocolate/graphics/group_icons/defaulttiny.gif";
?>