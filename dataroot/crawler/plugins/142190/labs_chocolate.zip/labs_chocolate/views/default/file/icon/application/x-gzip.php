<?php

	echo elgg_view('file/icon/archive',$vars);

?>