<?php

	/**
	 * Elgg header contents
	 * This file holds the header output that a user will see
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2009
	 * @link http://elgg.org/
	 **/
	 
?>

<div id="page_container">
<div id="page_wrapper">

<div id="layout_header">
<div id="wrapper_header">
	<!-- display the page title 
	<h1><a href="<?php echo $vars['url']; ?>"><?php echo $vars['config']->sitename; ?></a></h1>
	-->
		<div id="site_logo">
		<a href="<?php echo $vars['url']; ?>">
			<img src="<?php echo $vars['url']; ?>mod/labs_chocolate/graphics/logo.png" border="0" />		</a>
	</div>
	</div><!-- /#wrapper_header -->
</div><!-- /#layout_header -->


<ul id="nav">
	<li class="top"><a class="top_link" href="<?php echo $vars['url']; ?>"><span>Home</span></a></li>
	<li class="top"><a class="top_link" id="products" href="<?php echo $vars['url']; ?>"><span class="down">Products</span><!--[if gte IE 7]><!--></a><!--<![endif]-->
		<!--[if lte IE 6]><table><tr><td><![endif]--><ul class="sub">
			<li><b>Cameras</b></li>
			<li><a class="fly" href="<?php echo $vars['url']; ?>">Cameras<!--[if gte IE 7]><!--></a><!--<![endif]-->
					<!--[if lte IE 6]><table><tr><td><![endif]--><ul>
						<li><a href="<?php echo $vars['url']; ?>#">Nikon</a></li>
						<li><a href="<?php echo $vars['url']; ?>#">Minolta</a></li>
						<li><a href="<?php echo $vars['url']; ?>#">Pentax</a></li>
					</ul><!--[if lte IE 6]></td></tr></table></a><![endif]-->
			</li>
			<li><a class="fly" href="<?php echo $vars['url']; ?>">Lenses<!--[if gte IE 7]><!--></a><!--<![endif]-->
					<!--[if lte IE 6]><table><tr><td><![endif]--><ul>
						<li><a href="<?php echo $vars['url']; ?>#">Wide Angle</a></li>
						<li><a href="<?php echo $vars['url']; ?>#">Standard</a></li>
						<li><a href="<?php echo $vars['url']; ?>#">Mirror</a></li>
						<li><a href="<?php echo $vars['url']; ?>#">Telephoto</a></li>
						<li><b>Zoom</b></li>
						<li><a href="<?php echo $vars['url']; ?>#">35mm to 125mm</a></li>
						<li><a href="<?php echo $vars['url']; ?>#">50mm to 250mm</a></li>
						<li><a href="<?php echo $vars['url']; ?>#">125mm to 500mm</a></li>
						<li><b>Zoom</b></li>
						<li><a href="<?php echo $vars['url']; ?>#">Bayonet mount</a></li>
						<li><a href="<?php echo $vars['url']; ?>#">Screw mount</a></li>
					</ul><!--[if lte IE 6]></td></tr></table></a><![endif]-->
			</li>
			<li><b>Accessories</b></li>
			<li><a href="<?php echo $vars['url']; ?>#">Flash Guns</a></li>
			<li><a href="<?php echo $vars['url']; ?>#">Tripods</a></li>
			<li><a href="<?php echo $vars['url']; ?>#">Filters</a></li>
		</ul><!--[if lte IE 6]></td></tr></table></a><![endif]-->
	</li>
	<li class="top"><a class="top_link" id="services" href="<?php echo $vars['url']; ?>"><span class="down">Services</span><!--[if gte IE 7]><!--></a><!--<![endif]-->
		<!--[if lte IE 6]><table><tr><td><![endif]--><ul class="sub">
			<li><a href="<?php echo $vars['url']; ?>#">Printing</a></li>
			<li><a href="<?php echo $vars['url']; ?>#">Photo Framing</a></li>
			<li><a href="<?php echo $vars['url']; ?>#">Retouching</a></li>
			<li><a href="<?php echo $vars['url']; ?>#">Archiving</a></li>
		</ul><!--[if lte IE 6]></td></tr></table></a><![endif]-->
	</li>
	<li class="top"><a class="top_link" id="contacts" href="<?php echo $vars['url']; ?>"><span class="down">Contacts</span><!--[if gte IE 7]><!--></a><!--<![endif]-->
		<!--[if lte IE 6]><table><tr><td><![endif]--><ul class="sub">
			<li><a href="<?php echo $vars['url']; ?>#">Support</a></li>
			<li><a class="fly" href="<?php echo $vars['url']; ?>">Sales<!--[if gte IE 7]><!--></a><!--<![endif]-->
				<!--[if lte IE 6]><table><tr><td><![endif]--><ul>
					<li><b>European</b></li>
					<li><a class="fly" href="<?php echo $vars['url']; ?>">British<!--[if gte IE 7]><!--></a><!--<![endif]-->
						<!--[if lte IE 6]><table><tr><td><![endif]--><ul>
							<li><b>City</b></li>
							<li><a href="<?php echo $vars['url']; ?>#">London</a></li>
							<li><a href="<?php echo $vars['url']; ?>#">Liverpool</a></li>
							<li><a href="<?php echo $vars['url']; ?>#">Glasgow</a></li>
							<li><a class="fly" href="<?php echo $vars['url']; ?>">Bristol<!--[if gte IE 7]><!--></a><!--<![endif]-->
								<!--[if lte IE 6]><table><tr><td><![endif]--><ul>
									<li><b>District</b></li>
									<li><a href="<?php echo $vars['url']; ?>#">Redland</a></li>
									<li><a href="<?php echo $vars['url']; ?>#">Hanham</a></li>
									<li><a href="<?php echo $vars['url']; ?>#">Eastville</a></li>
								</ul><!--[if lte IE 6]></td></tr></table></a><![endif]-->
							</li>
							<li><a href="<?php echo $vars['url']; ?>#">Cardiff</a></li>
							<li><a href="<?php echo $vars['url']; ?>#">Belfast</a></li>
						</ul><!--[if lte IE 6]></td></tr></table></a><![endif]-->
					</li>
					<li><a href="<?php echo $vars['url']; ?>#">French</a></li>
					<li><a href="<?php echo $vars['url']; ?>#">German</a></li>
					<li><a href="<?php echo $vars['url']; ?>#">Spanish</a></li>
					<li><b>Worldwide</b></li>
					<li><a href="<?php echo $vars['url']; ?>#">USA</a></li>
					<li><a href="<?php echo $vars['url']; ?>#">Canadian</a></li>
					<li><a href="<?php echo $vars['url']; ?>#">South American</a></li>
					<li><a href="<?php echo $vars['url']; ?>#">Australian</a></li>
					<li><a href="<?php echo $vars['url']; ?>#">Asian</a></li>
				</ul><!--[if lte IE 6]></td></tr></table></a><![endif]-->
			</li>
			<li><a href="<?php echo $vars['url']; ?>#">Buying</a></li>
			<li><a href="<?php echo $vars['url']; ?>#">Photographers</a></li>
			<li><a href="<?php echo $vars['url']; ?>#">Stockist</a></li>
			<li><a href="<?php echo $vars['url']; ?>#">General</a></li>
		</ul><!--[if lte IE 6]></td></tr></table></a><![endif]-->
	</li>
	<li class="top"><a class="top_link" id="shop" href="<?php echo $vars['url']; ?>"><span class="down">Shop</span><!--[if gte IE 7]><!--></a><!--<![endif]-->
		<!--[if lte IE 6]><table><tr><td><![endif]--><ul class="sub">
			<li><a href="<?php echo $vars['url']; ?>#">Online</a></li>
			<li><a href="<?php echo $vars['url']; ?>#">Catalogue</a></li>
			<li><a href="<?php echo $vars['url']; ?>#">Mail Order</a></li>
		</ul><!--[if lte IE 6]></td></tr></table></a><![endif]-->
	</li>
	<li class="top"><a class="top_link" id="privacy" href="<?php echo $vars['url']; ?>"><span>Privacy Policy</span></a></li>
</ul>
<?php
     if (isloggedin()) {
?>

<?php

    }
?>
