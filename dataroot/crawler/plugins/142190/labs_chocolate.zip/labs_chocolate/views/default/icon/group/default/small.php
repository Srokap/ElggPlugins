<?php
	echo $vars['url'] . "mod/labs_chocolate/graphics/group_icons/defaultsmall.gif";
?>