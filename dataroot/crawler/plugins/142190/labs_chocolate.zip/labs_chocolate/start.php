<?php

	/* Elgg Theme Simple Example */
	
	
	/* Initialise the theme */
	function labs_chocolate_init(){
	
	}
	
	// Initialise log browser
	register_elgg_event_handler('init','system','labs_chocolate_init');
	
?>