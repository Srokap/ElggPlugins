<?php
$portugues_brasileiro = array (
	'admin:administer_utilities:manageupdate'			=> "Gerenciar atualizações",
	'elgg_update_services:main_title'					=> "ELGG Update Services",
	'elgg_update_services:no_updates'					=> "Nenhuma atualização disponível",
	'elgg_update_services:subject'						=> "ELGG Update Services",
	'elgg_update_services:next_check'					=> "Próxima verificação: ",
	'elgg_update_services:message'						=> "Alguns plugins em seu site estão desatualizados. Confira na lista abaixo:",
	'elgg_update_services:version'						=> "Versão",
	'elgg_update_services:direct_download'				=> "Download direto",
	'elgg_update_services:mail_plugin_name'				=> "Nome: ",
	'elgg_update_services:mail_plugin_version'			=> "Versão: ",
	'elgg_update_services:mail_plugin_url'				=> "Endereço: ",
	'elgg_update_services:mail_download_url'			=> "Download direto: ",
	'elgg_update_services:notify_mail_address'			=> "Enviar notificações sobre atualizações usando o e-mail abaixo"
);
add_translation("pt_br", $portugues_brasileiro);