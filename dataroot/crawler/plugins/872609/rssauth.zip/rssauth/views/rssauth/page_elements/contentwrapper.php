<?php
/**
 * @package Elgg
 * @subpackage Core
 */

echo $vars['body'];