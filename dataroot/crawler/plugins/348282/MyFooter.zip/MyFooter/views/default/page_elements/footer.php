<?php

	/**
	 * My Footer
	 * The standard HTML footer that displays across the site
	 * @author Carlos Reo-Dero
	 */
	 
	 // get the tools menu
	//$menu = get_register('menu');

?>

<div class="clearfloat"></div>
                     <!--Site ads-->
<p align="center">YOUR AD CODE HERE</p>
                      <!--End ad-->
<div id="layout_footer" style="padding-right:50px;">
<table align="center" cellpadding="0" cellspacing="0" class="footContainer">
	<tr>
      	<!--Site name and/or copy right statement-->
		<td class="left"><b>&#169; 2009 Blog Fully All rights reserved</b></td>
            
      	<!--End Site name and/or copy right statement-->
            
		<td class="right">
            
            	<table align="right" cellpadding="0" cellspacing="0" class="footerLinks" style="border:none;">
                  	<tr>
                        	
			            <!--Footer Links // Modify these links as you need-->
                              
                              <td class="link"><a href="http://blogfully.com/pg/expages/read/About/" target="_self">About</a></td>
                              <td class="link"><a href="http://blogfully.com/pg/expages/read/Terms/" target="_self">Terms</a></td>
                              <td class="link"><a href="http://blogfully.com/pg/expages/read/Privacy/" target="_self">Privacy</a></td>
							  <td class="link"><a href="http://blogfully.com/pg/contact" target="_self">Contact</a></td>
                              <td class="link"><a href="http://blogfully.com/pg/sitemap/" target="_self">Sitemap</a></td>
                              
                              <!--End Footer Links-->
                              
                        </tr>
                  </table>
                  
            </td>
	</tr>
</table>
</div><!-- /#layout_footer -->

<div class="clearfloat"></div>

</div><!-- /#page_wrapper -->
</div><!-- /#page_container -->
<!-- insert an analytics view to be extended -->
<?php
	echo elgg_view('footer/analytics');
?>
</body>
</html>