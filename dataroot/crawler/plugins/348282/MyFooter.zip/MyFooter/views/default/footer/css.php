<?php

	/**
	 * My Footer CSS Extention
	 * @author Carlos Reo-Dero
	 */

?>

/*

CSS - MyFooter

*/

table.footContainer {
	width: 100%;
      border: none;
      height: 90px;
	font-family: Tahoma, "Lucida Console", Arial;
	font-size: 11px;
	color: #000000;
}

table.footContainer td.left {
	text-align:left; 
      vertical-align:middle; 
      padding-right:50px;
}

table.footContainer td.right {
	text-align:right; 
      vertical-align:middle; 
}

table.footerLinks {
	border: none;
	font-family: Tahoma, "Lucida Console", Arial;
	font-size: 11px;
	color: #000000;
}

table.footerLinks td {
	padding: 0px 8px 0px 8px;
}


table.footerLinks td a:link {
	color: #000000;
	text-decoration: none;
}

table.footerLinks td a:visited {
	color: #000000;
	text-decoration: none;
}

table.footerLinks td a:hover {
	color: #000000;
	text-decoration: underline;
}

table.footerLinks td a:visited:hover {
	color: #000000;
	text-decoration: underline;
}