<?php
/**
         * Elgg spotlight lorea
         * 
         * @package
         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author lorea
         * @copyright lorea
         * @link http://lorea.cc
         */

	$spanish = array(
                    "group_operators:title" => 'Admins del grupo',
                    "group_operators:addoperators" => 'Gestionar admins de grupo',
                    "group_operators:operators" => 'Admins',
                    "group_operators:members" => 'Miembros',
                    "group_operators:operators:instructions" => 'haz click sobre un icono para dar permisos de administracion',
                    "group_operators:members:instructions" => 'haz click sobre un icono para quitar los permisos de administracion',


	);
	
	add_translation("es",$spanish);

?>
