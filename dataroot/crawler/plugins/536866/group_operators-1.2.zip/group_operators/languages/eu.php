<?php

// Translationbrowser-ek sortua.

$basque = array(
         'group_operators:title'  =>  "Talde eragileak" ,
         'group_operators:addoperators'  =>  "Kudeatu talde eragileak" ,
         'group_operators:operators'  =>  "Eragileak" ,
         'group_operators:members'  =>  "Kideak" ,
         'group_operators:operators:instructions'  =>  "klik egin eragile baimenak kentzeko" ,
         'group_operators:members:instructions'  =>  "klik egin eragile taldekide egiteko"
);

add_translation('eu', $basque);

?>
