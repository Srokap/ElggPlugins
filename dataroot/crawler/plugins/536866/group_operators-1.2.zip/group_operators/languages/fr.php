<?php

$french = array(
                    "group_operators:title" => 'Administrateurs du groupe',
                    "group_operators:addoperators" => 'Gérer les administrateurs du groupe',
                    "group_operators:operators" => 'Administrateurs',
                    "group_operators:members" => 'Membres',
                    "group_operators:operators:instructions" => 'Cliquez pour supprimer les droits d\'un administrateur',
                    "group_operators:members:instructions" => 'Cliquez pour rendre un membre administrateur de groupe',

);

add_translation('fr', $french);

?>
