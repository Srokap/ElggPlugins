<?php

// Gerado pelo browser de tradução. 

$portuguese = array( 
	 'group_operators:title'  =>  "Operadores do grupo" , 
	 'group_operators:addoperators'  =>  "Administrar operadores do grupo" , 
	 'group_operators:operators'  =>  "Operadores" , 
	 'group_operators:members'  =>  "Membros" , 
	 'group_operators:operators:instructions'  =>  "clique para remover os direitos de operador" , 
	 'group_operators:members:instructions'  =>  "clique para transformar o membro do grupo em operador"
); 

add_translation('pt', $portuguese); 

?>