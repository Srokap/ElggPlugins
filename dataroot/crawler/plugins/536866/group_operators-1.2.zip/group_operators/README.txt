Group Operators for Elgg
------------------------

Allows groups to have several operators (a.k.a. admins).

The group owner is the initial operator (and cannot be removed), who can add or remove operators (and then operators can also add or remove operators).

Installation: Put inside your mod/ folder as 'group_operators' and enjoy!!

Tickets and source repository:
	http://bitbucket.org/rhizomatik/elgg_group_operators/

License: See COPYING (GPLv2)

--
devel@lorea.cc
