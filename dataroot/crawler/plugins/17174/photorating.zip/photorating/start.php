<?php
/**
 *	PHOTORATING PLUGIN based on the rate plugin
 *	@package photorating
 *	@author Julien Herbin julien.pm.herbin@gmail.com
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Julien Herbin 2009
 *	@link http://community.elgg.org/pg/profile/julien_hip
 **/

global $CONFIG;

// start
function photorating_init(){
	global $CONFIG;
	// record the languages files
	register_translations($CONFIG->pluginspath . "photorating/languages/");
	// extend css view
	extend_view('css', 'photorating/css');
}

// events
register_elgg_event_handler('init','system','photorating_init');

// actions
register_action("photorating/add",false, $CONFIG->pluginspath . "photorating/actions/add.php");
?>