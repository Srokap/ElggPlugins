<?php
/**
 *	PHOTORATING PLUGIN based on the rate plugin
 *	@package photorating
 *	@author Julien Herbin julien.pm.herbin@gmail.com
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Julien Herbin 2009
 *	@link http://community.elgg.org/pg/profile/julien_hip
 **/

	$english = array(
		'photorating:pt_rate' => "Rate :",
		'photorating:pt_average' => "average :",
		'photorating:pt_rating' => "rating(s)",
	);
	add_translation("en",$english);
?>