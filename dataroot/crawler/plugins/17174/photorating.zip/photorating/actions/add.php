<?php
/**
 *	PHOTORATING PLUGIN based on the rate plugin
 *	@package photorating
 *	@author Julien Herbin julien.pm.herbin@gmail.com
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Julien Herbin 2009
 *	@link http://community.elgg.org/pg/profile/julien_hip
 **/

 
// make sure action is secure
// gatekeeper();
// action_gatekeeper();
	
// take back the entity
$guid = (int) get_input('guid');
if (!$entity = get_entity($guid)){	
	register_error("error");
	forward();
} 

$entity->save();
$pt_rate = (int) get_input('rating');

// record
if ($entity->annotate('pt_rate', $pt_rate, 2, $_SESSION['guid'])){
	// system_message(elgg_echo('rate:saved'));
}
else{
	register_error(elgg_echo('rate:error'));
}

$entity->save();

$new_rate = $entity->getAnnotationsAvg('pt_rate');

echo $new_rate;

?>