<?php
/**
 *	PHOTORATING PLUGIN based on the rate plugin
 *	@package photorating
 *	@author Julien Herbin julien.pm.herbin@gmail.com
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Julien Herbin 2009
 *	@link http://community.elgg.org/pg/profile/julien_hip
 **/

$entity = $vars['entity']; 
$rate = $entity->getAnnotationsAvg('pt_rate');
$rate_rounded = round($rate); 
$rate = round($rate, 2);
$nb_rate = $entity->countAnnotations('pt_rate');
$member = $_SESSION['guid'];

$can_vote = true;

if (isloggedin()){
	$annotations = $entity->getAnnotations('pt_rate');
	foreach ($annotations as $annotation){
		if ($annotation->owner_guid == $member){
			$can_vote = false;
		}
	}
}
else{
	$can_vote = false;;
}
	

if ($can_vote) {
?>
	<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/photorating/views/default/photorating/js/jquery.rater.js">
	</script>
	<script type="text/javascript">
		$(function() {
			$('#photorating').rater({ postHref: '<?php echo $vars["url"]; ?>action/photorating/add', guid: '<?php echo($entity->getGUID());?>' }); 
		});	
	</script>
<?php
}
else {
?>
<?php	
// maybe something to display that the member has already voted
}	
?>

<span class="ui-rater">
	<?php elgg_echo("photorating:pt_rate");?>
	<span class="ui-rater-starsOff" style="width:90px;">
		<span class="ui-rater-starsOn" style="width:<?php echo ($rate_rounded * 20); ?>px;"></span>
	</span>
	<br/>
	<?php elgg_echo("photorating:pt_average"); ?><span class="ui-rater-rating"><?php echo ($rate); ?></span>
	-&nbsp;<span class="ui-rater-rateCount"><?php echo ($nb_rate); ?></span><?php elgg_echo("photorating:pt_rating");?>
</span>