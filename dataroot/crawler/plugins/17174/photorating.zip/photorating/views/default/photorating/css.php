<?php
/**
 *	PHOTORATING PLUGIN based on the rate plugin
 *	@package photorating
 *	@author Julien Herbin julien.pm.herbin@gmail.com
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Julien Herbin 2009
 *	@link http://community.elgg.org/pg/profile/julien_hip
 *  great thanks to the JQuery community, http://plugins.jquery.com/project/Rater
 **/
?>

#photorating {
	float:left;
	clear: left;
	margin-bottom:10px;	
}

#photorating .ui-rater>span {
	vertical-align:top;
}

#photorating .ui-rater-rating {
	margin-left:.8em
}

#photorating .ui-rater-starsOff, .ui-rater-starsOn {
	display:inline-block; 
	height:18px; 
	background:url("<?php echo $vars["url"]; ?>mod/photorating/_graphics/stars.png");  
	repeat-x 0 0px;
}

#photorating .ui-rater-starsOn {
	display:block; 
	max-width:90px; 
	top:0; 
	background-position: 0 -36px;
}

#photorating .ui-rater-starsHover {
	background-position: 0 -18px!important;
}