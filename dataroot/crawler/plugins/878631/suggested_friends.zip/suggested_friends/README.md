Suggested-Friends-1.8.x
=======================

Provides a page and a widget for suggesting friends based on mutual friends and group membership

Plugin should reside in mod/suggested_friends