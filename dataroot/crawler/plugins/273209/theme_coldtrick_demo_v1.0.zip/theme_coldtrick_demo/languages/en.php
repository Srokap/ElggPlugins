<?php
	$english = array(
		
		'theme:subtitle' => "Your partner for social network development",
			
	);
	
	add_translation("en", $english);
?>