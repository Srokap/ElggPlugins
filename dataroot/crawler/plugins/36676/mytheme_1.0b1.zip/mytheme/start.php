<?php
/**
 * MyTheme
 * 
 * @package MyTheme
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Brett Profitt
 * @copyright Brett Profitt 2009
 * @link http://eschoolconsultants.com
 */

/**
 * Initialise the plugin.
 *
 */
function mytheme_init() {
	global $CONFIG;
	
	//set_template_handler('mytheme_template_handler');
	register_page_handler('mytheme', 'mytheme_pagehandler');
}
// not used currently.
function mytheme_template_handler($view, $vars) {
	global $CONFIG;
	
	// Attempt to memcache views.
	/*$view_hash = elgg_get_viewhash($view, $vars);
	$cached_view = elgg_get_cached_view($view_hash);
	if ($cached_view) return $cached_view;*/

	// Get the current viewtype
	$viewtype = elgg_get_viewtype(); 

	// Set up any extensions to the requested view
	if (isset($CONFIG->views->extensions[$view])) {
		$viewlist = $CONFIG->views->extensions[$view];
	} else {
		$viewlist = array(500 => $view);
	}

	// if we have a theme override by either owner or pref,
	// go through the views, disable all other themes as marked in
	// the plugin's settings, and enable the theme as based on override
//
//	if ($user = get_loggedin_user()) {
//		$override_theme = get_plugin_usersetting('mytheme_selected_theme', $user->getGUID(), 'mytheme');
//	} else {
//		$override_theme = false;
//	}
//
//	// page owner theme overrides logged in user's theme.
//	if ($page_owner = page_owner()) {
//		$override_theme = get_plugin_usersetting('mytheme_selected_theme', $page_owner, 'mytheme');
//	}

//	
//	if (in_array($override_theme, mytheme_get_themes())) {
//		system_message("Overriding theme with $override_theme");
//	} else {
//		//system_message('No override!!');
//	}

	// Start the output buffer, find the requested view file, and execute it
	ob_start();
	foreach($viewlist as $priority => $view) {
		
		$view_location = elgg_get_view_location($view);
		
		// check for the mods dir, then check if it's
		// in the themes list.
		// cuts down on SOME intensive calls.
		if ($override_theme 
		//&& strpos($view_location, $CONFIG->pluginspath) 
		&& strpos($view_location, '/mod/')
		&& $theme_name = mytheme_view_location_is_theme($view_location)) {
		//) {
			system_message("$view_location for $view");
		}

		if (file_exists($view_location . "{$viewtype}/{$view}.php") && !include($view_location . "{$viewtype}/{$view}.php")) {
			$success = false;
			
			if ($viewtype != "default") {
				if (include($view_location . "default/{$view}.php")) {
					$success = true;
				}
			}
			if (!$success && isset($CONFIG->debug) && $CONFIG->debug == true) {
				error_log(" [This view ({$view}) does not exist] ");
			}
		} else if (isset($CONFIG->debug) && $CONFIG->debug == true && !file_exists($view_location . "{$viewtype}/{$view}.php")) {
		
			error_log($view_location . "{$viewtype}/{$view}.php");
			error_log(" [This view ({$view}) does not exist] ");
		}
	}

	// Save the output buffer into the $content variable
	$content = ob_get_clean();

	// Plugin hook
	$content = trigger_plugin_hook('display','view',array('view' => $view),$content);

	// Cache view
	//elgg_cache_view($view, $content, $view_hash);

	// Return $content
	return $content;

	
	
	
	
	
	
	

	// Get the current viewtype
	$viewtype = elgg_get_viewtype();
	//system_message("viewtype is '$viewtype' for view '$view'");
	
	// Set up any extensions to the requested view
	if (isset($CONFIG->views->extensions[$view])) {
		$viewlist = $CONFIG->views->extensions[$view];
	} else {
		$viewlist = array(500 => $view);
	}
	
	// Start the output buffer, find the requested view file, and execute it
	ob_start();
	foreach($viewlist as $priority => $view) {
		$view_location = elgg_get_view_location($view);
		if ($theme_name = mytheme_view_location_is_theme($view_location)) {
			$themes_all = mytheme_get_themes();
			$themes_available = mytheme_get_themes(true);
			
			$page_owner = page_owner();
			$user_theme = get_plugin_usersetting('mytheme_selected_theme', $page_owner, 'mytheme');
			
			if ($page_owner && $user_theme) {
				system_message("Replacing '$theme_name' with '$user_theme' for '$view_location'");
				$view_location = str_replace($theme_name, $user_theme, $view_location);
				system_message("New location is $view_location");
			}
			//system_message("Trying to include: ".  $view_location . "{$viewtype}/{$view}.php");
			//system_message('awdf: ' . file_exists($view_location . "{$viewtype}/{$view}.php"));
		}
		if (file_exists($view_location . "{$viewtype}/{$view}.php") && !@include($view_location . "{$viewtype}/{$view}.php")) {
			$success = false;
			
			if ($viewtype != "default") {
				if (@include($view_location . "default/{$view}.php")) {
					$success = true;
				}
			}
			if (!$success && isset($CONFIG->debug) && $CONFIG->debug == true) {
				error_log(" [This view ({$view}) does not exist] ");
			}
		//} else if (isset($CONFIG->debug) && $CONFIG->debug == true && !file_exists($view_location . "{$viewtype}/{$view}.php")) {
		} else {
			eschool_log($view_location . "{$viewtype}/{$view}.php");
			eschool_log(" [This view ({$view}) does not exist] ");
		}
	}
	
	$content = ob_get_clean();
	$content = trigger_plugin_hook('display','view',array('view' => $view),$content);

	return $content;
}



/**
 * Outputs the correct CSS headers and handles 
 * finding the right css for the get_input('theme')
 * @param $page
 * @return unknown_type
 */
function mytheme_pagehandler($page) {
	global $CONFIG;
	
	$theme_name = $page[0];
	
	if (array_key_exists($theme_name, mytheme_get_themes(true))) {
		
		$override_css_path = $CONFIG->pluginspath . $theme_name . 
			'/views/default/' . $theme_name. '/css.php';
			
		if (file_exists($override_css_path)) {
			header("Content-type: text/css", true);
			//header('Expires: ' . date('r',time() + 864000), true);
			header("Pragma: public", true);
			header("Cache-Control: public", true);

			// yes, this is duplicated from elgg_view()
			if (empty($vars)) {
				$vars = array();
			}
			
			// Load session and configuration variables into $vars
			if (isset($_SESSION) && is_array($_SESSION) ) {
				$vars = array_merge($vars, $_SESSION);
			}
			
			$vars['config'] = array();
			if (!empty($CONFIG))
				$vars['config'] = $CONFIG;
			    
			$vars['url'] = $CONFIG->url;
			    
			// Load page owner variables into $vars
			if (is_callable('page_owner')) {
				$vars['page_owner'] = page_owner();
			} else {
				$vars['page_owner'] = -1;
			}
			if (($vars['page_owner'] != -1) && (is_installed())) {
				if (!isset($usercache[$vars['page_owner']])) {
					$vars['page_owner_user'] = get_entity($vars['page_owner']);
					$usercache[$vars['page_owner']] = $vars['page_owner_user'];
				} else {
					$vars['page_owner_user'] = $usercache[$vars['page_owner']];
				}
			}
			if (!isset($vars['js'])) {
				$vars['js'] = "";
			}
			
			include($override_css_path);
		}
	}
}

function mytheme_intercept($event, $object_type, $object) {
	global $CONFIG;

	// page owner theme overrides logged in user's theme.
	if ($user = get_loggedin_user()) {
		$override_theme = get_plugin_usersetting('mytheme_selected_theme', $user->getGUID(), 'mytheme');
		//system_message("User theme is $override_theme");
	} else {
		$override_theme = false;
	}
	
	// for now, only users can change themes.
	// if the page owner hasn't set a theme, revert to site default.
	if ($page_owner_entity = page_owner_entity()) {
		if ($page_owner_entity instanceof ElggUser) {
			$override_theme = get_plugin_usersetting('mytheme_selected_theme', $page_owner_entity->getGUID(), 'mytheme');
			//system_message("Owner theme is $override_theme");
		} else {
			// the owner is a group, etc.  not yet supported.
			// the ElggGroup entity can be checked above easily enough.
		}
	}
	//system_message("Page owner is {$page_owner_entity->name}");
	//system_message("Override is $override_theme");
	
	if ($override_theme) {
		if (array_key_exists($override_theme, mytheme_get_themes(true))) {
//			system_message("Page owner is $page_owner for '$url'");
//			system_message("User theme is $override_theme");
//			system_message($override_css_path);
			
			// grab the overriding theme's views and autoregister_views() them
			// should override any views it has.
			$override_path = $CONFIG->pluginspath . $override_theme; 
			// register views with just this theme.
			if (is_dir($override_path . "/views")) {
				if ($handle = opendir($override_path . "/views")) {
					while ($viewtype = readdir($handle)) {
						if (!in_array($viewtype, array('.','..','.svn','CVS')) && is_dir($override_path . "/views/" . $viewtype)) {
							autoregister_views("", $override_path. "/views/" . $viewtype, $override_path . "/views/", $viewtype);
						}
					}
				}
			}
			
			// this should set up any extensions and non-autoregistered views.
			if (is_file($override_path . '/start.php') && include($override_path . '/start.php')) {
				$init_func = $override_theme . '_init';
				if (function_exists($init_func)) {
					//system_message("Calling $init_func");
					$init_func();
				}
			}
		}
	}
	
	return true;
}

/**
 * Lists all themes in the mod dir.
 * Requires themes to have "theme" in their name.
 * Returns in the form of array(theme_path => theme_name);
 * 
 * @param bool $enabled_only True for only themes enabled in config. 
 * @param bool $display_name Grab the display name from config
 * @return array
 */
function mytheme_get_themes($enabled_only=false, $display_name=false) {
	global $CONFIG;
	
	$themes = array();
	foreach (get_installed_plugins() as $plugin => $info) {
		if (stristr($plugin, 'theme') && ($plugin!='mytheme')) {
			//$path = str_replace($CONFIG->pluginspath, '', $dir . '/' . $file);
			$name = ucwords(str_replace('_', ' ', $plugin));
			if ($enabled_only) {
				if (get_plugin_setting($plugin . '_enabled', 'mytheme')) {
					$themes[$plugin] = ($display_name) ? get_plugin_setting($plugin . '_display_name', 'mytheme') : $name;
				}
			} else {
				$themes[$plugin] = ($display_name) ? get_plugin_setting($plugin . '_display_name', 'mytheme') : $name;
			}
		}
	}

	return $themes;
}

function mytheme_view_location_is_theme($view_location) {
	global $CONFIG;
	
	$themes = mytheme_get_themes();
	
	// check if this is a plugin (theme)
	if (strstr($view_location, $CONFIG->pluginspath)) {
		$plugin = str_replace('/views/', '', $view_location);
		$plugin = str_replace($CONFIG->pluginspath, '', $plugin);
		
		if (array_key_exists($plugin, $themes)) {
			return $plugin;
		}
	}
	return false;
}

register_elgg_event_handler('init', 'system', 'mytheme_init');
register_elgg_event_handler('pagesetup', 'system', 'mytheme_intercept');