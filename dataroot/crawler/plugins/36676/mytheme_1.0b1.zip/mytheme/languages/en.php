<?php

$config_blurb = 'Enable the themes you want users to be able to select.  You can also change what the user sees as the theme name.';

$user_config_blurb = 'Select the theme you want to use to browse the site.  This will also be the theme visitors will see on your profile.';

$english = array(
	'mytheme:themes_config_blurb' => $config_blurb,
	'mytheme:enabled' => 'Enabled',
	'mytheme:display_name' => 'Display Name',
	'mytheme:user_config_blurb' => $user_config_blurb,
	'mytheme:site_default' => 'Site Default'
);

add_translation("en", $english);
?>
