<?php
/**
 * MyTheme
 * 
 * @package MyTheme
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Brett Profitt
 * @copyright Brett Profitt 2009
 * @link http://eschoolconsultants.com
 *
 * $vars['override_theme_path'] = 
 *
 */



$theme_name = get_input('mytheme_theme_name');
$theme_url = $vars['url'] . 'pg/mytheme/' . $theme_name . '?lastcache=' .
	$vars['config']->lastcache . '&viewtype=' . $vars['view']; 

?>





<link rel="stylesheet" href="<?php echo $theme_url; ?>" type="text/css" />









