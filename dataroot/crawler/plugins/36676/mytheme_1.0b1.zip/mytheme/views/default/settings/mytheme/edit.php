<?php
/**
 * MyTheme
 * 
 * @package MyTheme
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Brett Profitt
 * @copyright Brett Profitt 2009
 * @link http://eschoolconsultants.com
 */ 


$themes = mytheme_get_themes();

$themes_form = '<table width="100%">';
$themes_form .= '<tr><th>' . elgg_echo('mytheme:enabled') . '</th><th>' . elgg_echo('mytheme:display_name') . "</th></tr>\n";
foreach ($themes as $theme_path => $theme_name) {
	if (!$display_name = get_plugin_setting($theme_path . '_display_name', 'mytheme')) {
		$display_name = $theme_name;
	}
	$theme_select = elgg_view('input/pulldown', array(
		'internalname' => "params[{$theme_path}_enabled]",
		'value' => get_plugin_setting($theme_path . '_enabled', 'mytheme'),
		'options_values' => array(
			1 => elgg_echo('option:yes'),
			0 => elgg_echo('option:no')
			)
		)
	);
	$themes_form .= '<tr>';
	$themes_form .= "<td width='50%'><label>$theme_select $theme_name</label></td>\n";
	$themes_form .= "<td width='50%'><input type='text' name='params[{$theme_path}_display_name]' value='$display_name' /><br /></td>\n";
	$themes_form .= '</tr>';
}
$themes_form .= '</table>';


?>
<p>
	<?php echo elgg_echo('mytheme:themes_config_blurb'); ?><br />
	<?php echo $themes_form; ?>
</p>
