<?php
/**
 * MyTheme
 * 
 * @package MyTheme
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Brett Profitt
 * @copyright Brett Profitt 2009
 * @link http://eschoolconsultants.com
 */ 


$themes = array_merge(
	array(''=>elgg_echo('mytheme:site_default')), 
	mytheme_get_themes(true, true)
);


$themes_form = elgg_view('input/pulldown', array (
	'internalname' => 'params[mytheme_selected_theme]',
	'options_values' => $themes,
	'value' => get_plugin_usersetting('mytheme_selected_theme', $vars['user']->getGUID(), 'mytheme')
	)
);

?>
<p>
	<?php echo elgg_echo('mytheme:user_config_blurb'); ?><br />
	<?php echo $themes_form; ?>
</p>
