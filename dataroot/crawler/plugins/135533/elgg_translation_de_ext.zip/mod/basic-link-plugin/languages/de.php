<?php

// Generiere vom Übersetzungsbrowser. 

$german = array( 
	 'basic-link-plugin:settings'  =>  "Edelpartner" , 
	 'basic-link-plugin:explanation'  =>  "Schreibe hier Deine Links rein (ein Link pro Linie).
Beispiel:
Google,http://google.de
yahoo,http://yahoo.com" , 
	 'basic-link-plugin:save:success'  =>  "Gespeichert" , 
	 'basic-link-plugin:Links'  =>  "Edelpartner"
); 

add_translation('de', $german); 

?>