<?php

	$deutsch = array(
	
        /**
         * Misc
         */
            'chat:open' => 'Chat &ouml;ffnen'
	
	);
					
	add_translation("de", $deutsch);

?>
