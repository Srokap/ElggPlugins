<?php

// Generiere vom Übersetzungsbrowser. 

$german = array( 
	 'tinymce:remove'  =>  "Editor (An/Aus)"
); 

add_translation('de', $german); 

?>