<?php

// Generiere vom Übersetzungsbrowser. 

$german = array( 
	 'skillswidget:red'  =>  "Schlecht" , 
	 'skillswidget:amber'  =>  "Mittel" , 
	 'skillswidget:green'  =>  "Super" , 
	 'skillswidget:na'  =>  "Keine Angabe"
); 

add_translation('de', $german); 

?>