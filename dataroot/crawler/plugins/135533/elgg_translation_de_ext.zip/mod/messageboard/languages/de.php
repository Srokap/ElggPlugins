<?php

// Generiere vom Übersetzungsbrowser. 

$german = array( 
	 'messageboard:board'  =>  "Pinnwand" , 
	 'messageboard:messageboard'  =>  "Pinnwand" , 
	 'messageboard:viewall'  =>  "Alles zeigen" , 
	 'messageboard:postit'  =>  "Abschicken" , 
	 'messageboard:history'  =>  "Alles zeigen" , 
	 'messageboard:none'  =>  "Bis jetzt kein Eintrag auf der Pinnwand" , 
	 'messageboard:num_display'  =>  "Anzahl Nachrichten" , 
	 'messageboard:desc'  =>  "Dies ist Deine persönliche Pinnwand, auf der Dir andere Nachrichten hinterlassen können." , 
	 'messageboard:user'  =>  "%s's Pinnwand" , 
	 'messageboard:river:annotate'  =>  "%s hat eine neue Nachricht hinterlassen." , 
	 'messageboard:river:create'  =>  "%s hat das Pinnwand Widget hinzugefügt." , 
	 'messageboard:river:update'  =>  "%s hat das Pinnwand Widget aktualisiert." , 
	 'messageboard:river:added'  =>  "%s schrieb auf" , 
	 'messageboard:river:messageboard'  =>  "Pinnwand" , 
	 'messageboard:posted'  =>  "Nachricht erfolgreich übermittelt." , 
	 'messageboard:deleted'  =>  "Nachricht erfolgreich gelöscht." , 
	 'messageboard:email:subject'  =>  "Du hast einen neuen Pinnwand Eintrag!" , 
	 'messageboard:email:body'  =>  "Hallo, Du hast einen neuen Eintrag auf Deiner Pinnwand von %s erhalten. Die Nachricht:

			
%s


Um alle Nachrichten Deiner Pinnwand zu lesen, klicke bitte hier:

	%s

Um das Profil von %s anzusehen, klicke bitte hier::

	%s

Dies ist eine Systemmitteilung. Antworten auf diese Nachricht erreichen den Empfänger nicht." , 
	 'messageboard:blank'  =>  "Sorry; Du musst den Eintrag aktualisieren, bevor er gespeichert werden kann." , 
	 'messageboard:notfound'  =>  "Sorry; Wir konnten diesen Eintrag nicht finden." , 
	 'messageboard:notdeleted'  =>  "Sorry; die Löschung war nicht erfolgreich ." , 
	 'messageboard:somethingwentwrong'  =>  "Speichern fehlgeschlagen. Hast Du überhaupt eine Nachricht eingegeben?" , 
	 'messageboard:failure'  =>  "Fehler beim speichern Deiner Nachricht. Bitte versuche es noch einmal."
); 

add_translation('de', $german); 

?>