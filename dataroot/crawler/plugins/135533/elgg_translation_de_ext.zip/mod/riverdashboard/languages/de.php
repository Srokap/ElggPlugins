<?php

// Generiere vom Übersetzungsbrowser. 

$german = array( 
	 'river:post:toolong'  =>  "Oooops, das war wohl zu lang. Bitte beachte die Zeichen!" , 
	 'generic_comment:empty'  =>  "Bitte gebe etwas ein!" , 
	 'river:doing'  =>  "Flurfunk (hier kannst Du etwas globales an alle schreiben)" , 
	 'river:post:charleft'  =>  "Buchstaben übrig" , 
	 'river:post:posted'  =>  "Flurfunk Beitrag eingetragen." , 
	 'river:post:failure'  =>  "Da ging was schief! Bitte versuche es nochmal." , 
	 'river:comment'  =>  "Irgendwas zu sagen?" , 
	 'river:item:toggle_comments'  =>  "Kommentare ein/ausblenden" , 
	 'river:comment:post'  =>  "Schreiben" , 
	 'sidebox:recent_members'  =>  "Letzte Mitglieder" , 
	 'sidebox:birthday_members'  =>  "Geburtstage" , 
	 'today'  =>  "Heute" , 
	 'tomorrow'  =>  "Morgen" , 
	 'aftertomorrow'  =>  "Übermorgen" , 
	 'riverdashboard:welcome'  =>  "Willkommen %s" , 
	 'river:image:goto_full'  =>  "In voller Grösse ansehen" , 
	 'river:image:toggle_size'  =>  "Toggle" , 
	 'mine'  =>  "Meine Aktivitäten" , 
	 'filter'  =>  "Filter" , 
	 'riverdashboard:useasdashboard'  =>  "Ersetze die benutzerdefinierte Aushangtafel mit diesem Aktivitätsfluss!" , 
	 'activity'  =>  "Aktivität" , 
	 'sitemessages:announcements'  =>  "Globale Ankündigungen" , 
	 'sitemessages:posted'  =>  "gesendet" , 
	 'sitemessages:river:created'  =>  "Seiten-Administrator, %s," , 
	 'sitemessages:river:create'  =>  "Eine neue umfassende Seiten-Nachricht wurde gesendet." , 
	 'sitemessages:add'  =>  "Füge eine umfassende Seiten-Nachricht in den Fluss der Seite" , 
	 'sitemessage:deleted'  =>  "Seiten-Nachricht wurde gelöscht" , 
	 'river:widget:noactivity'  =>  "Wir konnten keine Aktivität finden." , 
	 'river:widget:title'  =>  "Aktivität" , 
	 'river:widget:description'  =>  "Zeige Deine letzte Aktivität." , 
	 'river:widget:title:friends'  =>  "Aktivität von Freunden" , 
	 'river:widget:description:friends'  =>  "Zeige, was Deine Freunde machen." , 
	 'river:widgets:friends'  =>  "Freunde" , 
	 'river:widgets:mine'  =>  "Meine Aktivitäten" , 
	 'river:widget:label:displaynum'  =>  "Anzahl der Einträge anzeigen:" , 
	 'river:widget:type'  =>  "Welche Liste möchtest du angezeigt bekommen? Diejenige, die deine Aktivität zeigt oder diejenige, die Aktivität Deiner Freunde zeigt?" , 
	 'item:object:sitemessage'  =>  "Seiten-Nachrichten"
); 

add_translation('de', $german); 

?>