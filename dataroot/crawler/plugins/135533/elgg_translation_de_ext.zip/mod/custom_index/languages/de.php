<?php

// Generate By translationbrowser. 

$german = array( 
	 'custom:bookmarks'  =>  "Neuste Lesezeichen",
	 'custom:groups'  =>  "Neuste Gruppen",
	 'custom:files'  =>  "Neuste Dateien",
	 'custom:blogs'  =>  "Neuste Blogbeiträge",
	 'custom:members'  =>  "Neueste Mitglieder",
	 'custom:nofiles'  =>  "Es gibt noch immer keine Dateien",
	 'custom:nogroups'  =>  "Es gibt noch immer keine Dateien",
); 

add_translation('de',$german);

?>