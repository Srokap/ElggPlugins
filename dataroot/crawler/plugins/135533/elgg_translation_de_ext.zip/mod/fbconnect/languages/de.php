<?php

// Generiere vom Übersetzungsbrowser. 

$german = array( 
	 'item:user:facebook'  =>  "Facebook Benutzer" , 
	 'fbconnect:account_create'  =>  "Error: Wir konnten Dich mit diesem Account nicht einloggen. Bitte versuche es später erneut oder kontaktiere den Administrator." , 
	 'fbconnect:inactive'  =>  "Error: Dein Account konnte nicht aktiviert werden." , 
	 'fbconnect:banned'  =>  "Error: Wir konnten Dich mit diesem Account nicht einloggen. Bitte versuche es später erneut oder kontaktiere den Administrator." , 
	 'fbconnect:fail'  =>  "Error: Wir konnten Dich mit diesem Account nicht einloggen. Bitte versuche es später erneut oder kontaktiere den Administrator." , 
	 'fbconnect:facebookerror'  =>  "Error: Facebook gab folgendes zurück: %s" , 
	 'fbconnect:account_duplicate'  =>  "Error: Ein Account ohne Facebook (%s) exstiert bereits." , 
	 'fbconnect:settings:yes'  =>  "ja" , 
	 'fbconnect:settings:no'  =>  "nein" , 
	 'fbconnect:user_settings_title'  =>  "Facebook Profil" , 
	 'fbconnect:user_settings_description'  =>  "Lasse Facebook Deinen Account bei uns kontrollieren. Falls Du auf \"nein\" klickst wird Dein Profil nicht mehr von Facebook syncronisiert sondern mußt Du dich wie jedes andere Mitglied normal registrieren." , 
	 'fbconnect:user_settings:save:ok'  =>  "Deine Facebook Daten wurden gespeichert." , 
	 'fbconnect:facebook_login_settings:save:ok'  =>  "Deine Facebook UID wurde gespeichert." , 
	 'fbconnect:facebook_login_description'  =>  "Wenn Dun dich mit Facebook anmelden möchtest gebe bitte die Nummer Deines Profils ein (Diese steht in der URL Deines Profiles)." , 
	 'fbconnect:cron_report'  =>  "Syncronisierte %s Facebook Accounts."
); 

add_translation('de', $german); 

?>