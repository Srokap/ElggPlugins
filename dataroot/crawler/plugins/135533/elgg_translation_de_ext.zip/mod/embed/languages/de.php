<?php

// Generate By translationbrowser. 

$german = array( 
	 'media:insert'  =>  "Medien Browser",
	 'embed:instructions'  =>  "Klicke auf irgendeine Datei, um sie in deinen Inhalt einzufügen.",
	 'embed:media'  =>  "Dateien einfügen",
	 'upload:media'  =>  "Dateien hochladen",
	 'embed:file:required'  =>  "Es wurde keine Möglichkeit gefunden Dateien hochzuladen. Der System-Administrator muss ein Plugin oder Ähnliches dafür hochladen.",
); 

add_translation('de',$german);

?>