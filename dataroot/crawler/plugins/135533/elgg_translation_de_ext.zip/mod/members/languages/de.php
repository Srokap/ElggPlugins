<?php

// Generate By translationbrowser. 

$german = array( 
	 'members:members'  =>  "Mitglieder" , 
	 'members:online'  =>  "zur Zeit aktive Mitglieder" , 
	 'members:active'  =>  "Mitglieder" , 
	 'members:searchtag'  =>  "Mitglieder nach Tags suchen" , 
	 'members:searchname'  =>  "Mitglieder nach Namen suchen" ,
); 

add_translation('de',$german);

?>