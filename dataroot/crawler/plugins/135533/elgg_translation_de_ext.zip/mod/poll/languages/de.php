<?php

// Generiere vom Übersetzungsbrowser. 

$german = array( 
	 'poll'  =>  "Umfrage" , 
	 'polls'  =>  "Umfragen" , 
	 'poll:user'  =>  "%s's Umfrage" , 
	 'poll:user:friends'  =>  "%s's Freundes Umfrage" , 
	 'poll:your'  =>  "Deine Umfragen" , 
	 'poll:posttitle'  =>  "%s's Umfrage: %s" , 
	 'poll:friends'  =>  "Umfragen meiner Freunde" , 
	 'poll:yourfriends'  =>  "Letzte Umfragen Deiner Freunde" , 
	 'poll:everyone'  =>  "Alle Umfragen" , 
	 'poll:read'  =>  "Umfrage lesen" , 
	 'poll:addpost'  =>  "Umfrage erstellen" , 
	 'poll:editpost'  =>  "Umfrage Bearbeiten" , 
	 'poll:text'  =>  "Text" , 
	 'poll:strapline'  =>  "%s" , 
	 'item:object:poll'  =>  "Umfragen" , 
	 'poll:question'  =>  "Frage" , 
	 'poll:responses'  =>  "Antworten (mit KOMMA trennen)" , 
	 'poll:results'  =>  "[+] Zeige die Ergebnisse" , 
	 'poll:widget:label:displaynum'  =>  "Wieviele Umfragen anzeigen?" , 
	 'poll:river:created'  =>  "%s schrieb" , 
	 'poll:river:updated'  =>  "%s bearbeitete" , 
	 'poll:river:posted'  =>  "%s schrieb" , 
	 'poll:river:voted'  =>  "%s stimmt ab" , 
	 'poll:river:create'  =>  "eine neue Umfrage:" , 
	 'poll:river:update'  =>  "die Umfrage" , 
	 'poll:river:annotate'  =>  "ein Kommentar in der Umfrage:" , 
	 'poll:river:vote'  =>  "in der Umfrage:" , 
	 'poll:posted'  =>  "Umfrage erfolgreich gespeichert." , 
	 'poll:responded'  =>  "Vielen Dank. Der Vote wurde angenommen!" , 
	 'poll:deleted'  =>  "Erfolgreich entfernt." , 
	 'poll:totalvotes'  =>  "Anzahl der Umfragen:" , 
	 'poll:voted'  =>  "Vote gespeichert. Vielen Dank!" , 
	 'poll:save:failure'  =>  "Da ging etwas schief. Bitte versuche es noch einmal." , 
	 'poll:blank'  =>  "Sorry aber Du musst beide Felder ausf&uuml;llen." , 
	 'poll:notfound'  =>  "Wir konnten diese Umfrage nicht mehr in unserem System finden." , 
	 'polls:nonefound'  =>  "Von %s wurden keine Umfragen gefunden." , 
	 'poll:notdeleted'  =>  "Wir konnten diese Umfrage nicht l&ouml;schen!"
); 

add_translation('de', $german); 

?>