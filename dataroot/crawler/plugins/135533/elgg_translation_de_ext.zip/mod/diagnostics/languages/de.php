<?php

// Generiere vom Übersetzungsbrowser. 

$german = array( 
	 'diagnostics'  =>  "System Diagnose" , 
	 'diagnostics:description'  =>  "Die folgenden Einstellungen werden Dir helfen Deine elgg Version in Sachen \"Diagnose\" besser zu handeln." , 
	 'diagnostics:download'  =>  "Download die .txt" , 
	 'diagnostics:header'  =>  "========================================================================
Elgg Diagnose Bericht
Generiert %s von %s
========================================================================" , 
	 'diagnostics:report:basic'  =>  "Elgg Release %s, Version %s" , 
	 'diagnostics:report:php'  =>  "
PHP info:
%s
------------------------------------------------------------------------" , 
	 'diagnostics:report:plugins'  =>  "
Installierte Pluguns und Details:

%s
------------------------------------------------------------------------" , 
	 'diagnostics:report:md5'  =>  "Installierte Daten und Checksummen:

%s
------------------------------------------------------------------------" , 
	 'diagnostics:report:globals'  =>  "Globale Variablen:

%s
------------------------------------------------------------------------"
); 

add_translation('de', $german); 

?>