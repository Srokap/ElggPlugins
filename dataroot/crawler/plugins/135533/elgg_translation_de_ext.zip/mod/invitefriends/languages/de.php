<?php

// Generate By translationbrowser. 

$german = array( 
	 'friends:invite'  =>  "Freunde einladen" , 
	 'invitefriends:introduction'  =>  "Um Freunde in dein Netzwerk einzuladen, tippen deren e-mail Adressen unten ein.(eine pro Zeile):" , 
	 'invitefriends:message'  =>  "Schreibe eine Nachricht, die sie mit deiner Einladung bekommen sollen:" , 
	 'invitefriends:subject'  =>  "Einladung - komm zu %s" , 
	 'invitefriends:success'  =>  "Deine Freunde wurden eingeladen." , 
	 'invitefriends:failure'  =>  "Deine Freunde konnten nicht eingeladen werden." , 
	 'invitefriends:message:default'  =>  "Hi, Ich möchte dich zu meinem Netzwerk bei %s einladen." ,
	 'invitefriends:email'  =>  "Du wurdest  zu %s von %s eingeladen: %s Klick den folgenden Link, um dich anzumelden: %s Du wirst automatisch dem Absender als Freund hinzugefügt, sobald du ein Account erstellst." ,
); 

add_translation('de',$german); 

?>