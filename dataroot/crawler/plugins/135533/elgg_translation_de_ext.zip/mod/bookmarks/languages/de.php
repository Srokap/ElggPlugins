<?php

    $german = array(

		/**
		 * Menu items and titles
		 */

	 'bookmarks'  =>  "Lesezeichen",
     'bookmarks:add'  =>  "Lesezeichen hinzufügen",
	 'bookmarks:read'  =>  "Lesezeichen",
     'bookmarks:friends'  =>  "Lesezeichen der Freunde",
     'bookmarks:everyone'  =>  "Alle Community-Lesezeichen",
	 'bookmarks:this'  =>  "Lesezeichen hinzufügen",
     'bookmarks:bookmarklet'  =>  "Lesezeichen zum Browser hinzufügen",
	 'bookmarks:inbox'  =>  "Lesezeichen Eingangsbox",
  	 'bookmarks:more'  =>  "Mehr",
     'bookmarks:shareditem'  =>  "Lesezeichen",
   	 'bookmarks:with'  =>  "Teile mit",
   	 'bookmarks:new'  =>  "Ein neues Lesezeichen",
   	 'bookmarks:via'  =>  "per Lesezeichen",
  	 'bookmarks:address'  =>  "Quellenadresse des Lesezeichens",



	 'bookmarks:delete:confirm'  =>  "Bist du dir sicher, dass du dieses Lesezeichen löschen möchtest?",

	 'bookmarks:numbertodisplay'  =>  "Anzahl der Lesezeichen",

	 'bookmarks:shared'  =>  "Als Lesezeichen markiert",
	 'bookmarks:visit'  =>  "Zum Lesezeichen",
	 'bookmarks:recent'  =>  "Lesezeichen",

	 'bookmarks:river:created'  =>  "%s als Lesezeichen markiert",
	 'bookmarks:river:annotate'  =>  "schrieb einen Kommentar zum Lesezeichen",
	 'bookmarks:river:item'  =>  "ein Objekt",

     'item:object:bookmarks'  =>  "Lesezeichen",


		/**
		 * More text
		 */


	 'bookmarks:widget:description'  =>  "Dieses Widget zeigt die zuletzt als Lesezeichen versehenen Seiten in deiner Eingangbox" ,
	 'bookmarks:bookmarklet:description'  =>  "\"Lesezeichen zum Browser hinzufügen\" ermöglicht dir jegliche Web-Quelle, die du findest, mit deinen Freunden zu teilen oder selbst als Lesezeichen zu nutzen. Zieh einfach den folgenden Button zum \"Links\"-Menü deines Browsers hin: ",
	 'bookmarks:bookmarklet:descriptionie'  =>  "Falls Du den Internet Explorer benutzst, dann solltest Du beim Rechtsklick auf dem Button \"Zu Favoriten hinzufügen\" und dann \"Links\"-Menü auswählen.",
	 'bookmarks:bookmarklet:description:conclusion'  =>  "So kannst du beliebige von Dir besuchte Web-Seite abspeichern.",

		/**
		 * Status messages
		 */

     'bookmarks:save:success'  =>  "Erfolgreich mit einem Lesezeichen versehen.",
	 'bookmarks:delete:success'  =>  "Dein Lesezeichen wurde erfolgreich gelöscht",

		/**
		 * Error messages
		 */

	 'bookmarks:save:failed'  =>  "Dein Lesezeichen konnte nicht gespeichert werden. Bitte versuche es erneut.",
	 'bookmarks:delete:failed'  =>  "Dein Lesezeichen konnte nicht gelöscht werden. Bitte versuche es erneut.",
);

add_translation('de',$german);

?>