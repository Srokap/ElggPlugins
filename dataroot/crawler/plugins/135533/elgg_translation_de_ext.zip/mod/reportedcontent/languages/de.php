<?php

// Generiere vom Übersetzungsbrowser. 

$german = array( 
	 'item:object:reported_content'  =>  "Gemeldete Objekte" , 
	 'reportedcontent'  =>  "Gemeldeter Inhalt" , 
	 'reportedcontent:this'  =>  "Verstoss melden" , 
	 'reportedcontent:none'  =>  "Es gibt keinen gemeldeten Inhalt" , 
	 'reportedcontent:report'  =>  "Verstoss melden" , 
	 'reportedcontent:title'  =>  "Seitentitel" , 
	 'reportedcontent:deleted'  =>  "Der gemeldete Inhalt wurde gelöscht" , 
	 'reportedcontent:notdeleted'  =>  "Es ist nicht möglich diese Meldung zu löschen" , 
	 'reportedcontent:delete'  =>  "Löschen" , 
	 'reportedcontent:areyousure'  =>  "Bist du dir sicher, dass du es löschen möchtest?" , 
	 'reportedcontent:archive'  =>  "Archivieren" , 
	 'reportedcontent:archived'  =>  "Meldung wurde archiviert" , 
	 'reportedcontent:visit'  =>  "Gemeldetes Objekt anzeigen" , 
	 'reportedcontent:by'  =>  "Gemeldet von" , 
	 'reportedcontent:objecttitle'  =>  "Objekttitel" , 
	 'reportedcontent:objecturl'  =>  "URL des Obejkts" , 
	 'reportedcontent:reason'  =>  "Grund der Meldung" , 
	 'reportedcontent:description'  =>  "Warum möchtest du es melden?" , 
	 'reportedcontent:address'  =>  "Ort des Objekts" , 
	 'reportedcontent:success'  =>  "Deine Meldung wurde dem Seiten- Administrator gesendet" , 
	 'reportedcontent:failing'  =>  "Deine Meldung konnte nicht gesendet werden" , 
	 'reportedcontent:moreinfo'  =>  "Mehr Info" , 
	 'reportedcontent:failed'  =>  "Sorry, der Versuch diesen Inhalt zu melden ist fehlgeschlagen." , 
	 'reportedcontent:notarchived'  =>  "Diese Meldung konnte nicht archiviert werden",
); 

add_translation('de',$german);

?>