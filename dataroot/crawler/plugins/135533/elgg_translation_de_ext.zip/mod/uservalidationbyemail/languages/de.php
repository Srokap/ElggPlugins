<?php

// Generiere vom Übersetzungsbrowser. 

$german = array( 
	 'email:validate:subject'  =>  "%s bitte bestätige Deine Email Adresse!" , 
	 'email:validate:body'  =>  "Hallo %s,

Bitte bestätige Deine Email Adresse indem Du den unteren link anklickst:

%s
" , 
	 'email:validate:success:subject'  =>  "Email Bestätigung %s!" , 
	 'email:validate:success:body'  =>  "Hallo %s,
			
Herzlichen Glückwunsch! Deine Email Adresse wurde erfolgreich verifiziert." , 
	 'email:confirm:success'  =>  "Du hast Deine Email Adresse erfolgreich Bestätigt!" , 
	 'email:confirm:fail'  =>  "Die Email Adresse konnte nicht verifiziert werden..." , 
	 'uservalidationbyemail:registerok'  =>  " Um Deinen Account freizuschalten klicke bitte auf den Link den wir Dir zugeschickt haben."
); 

add_translation('de', $german); 

?>