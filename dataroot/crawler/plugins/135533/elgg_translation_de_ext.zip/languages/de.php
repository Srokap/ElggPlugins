<?php

// Generiere vom Übersetzungsbrowser.

$german = array(

		/**
		 * Sites
		 */

	 'item:site'  =>  "Seiten" ,

		/**
		 * Sessions
		 */
	 'login'  =>  "Anmelden" ,
	 'loginok'  =>  "Du bist angemeldet." ,
	 'logout'  =>  "Abmelden" ,
	 'logoutok'  =>  "Erfolgreich abgemeldet." ,
	 'logouterror'  =>  "Anmeldung nicht möglich. Bitte versuche noch mal." ,

		/**
		 * Errors
		 */
	 'exception:title'  =>  "Willkommen zu Pixel4Tune" ,

	 'InstallationException:CantCreateSite'  =>  "Die Standard-Seite kann so (Name:%s, Url: %s) nicht erstellt werden. " ,

	 'actionundefined'  =>  "Die aufgerufene Aktion (%s) ist nicht im System definiert worden." ,
	 'actionloggedout'  =>  "Ausgeloggt kannst du diese Aktion nicht ausführen." ,

	 'notfound'  =>  "Keine Ergebnisse gefunden." ,

	 'SecurityException:Codeblock'  =>  "Zugang verweigert zu dem priviligierten Codeblock." ,
	 'DatabaseException:WrongCredentials'  =>  "Zu der Datenbak kann keine Verbindung hergestellt werden. Überprüfen Sie bitte die Verbindungsdaten." ,
	 'DatabaseException:NoConnect'  =>  "Keine Verbindung zur Datenbank '%s', bitte überprüfe ob die Datenbank existiert und Du dazu Zugang hast." ,

 		/**
		 * API
		 */

			'system.api.list' => "Liste aller verfügbaren API Aufrufe im System.",
			'auth.gettoken' => "Dieser API Aufruf, der einen Benutzer sich einloggen lässt, gibt einen Authentifizierungsschlüssel zurück, der für zukünftige Authenfizierungen anstatt Benutzername und Passwort benutzt werden kann.",

		/**
		 * User details
		 */

		'name' => "Anzeigename",
		'email' => "Emailadresse",
		'username' => "Benutzername",
		'password' => "Passwort",
		'passwordagain' => "Passwort (Bestätigung)",
		'admin_option' => "Diesen Benutzer zum Admin machen?",

		/**
		 * Access
		 */

	 'PRIVATE'  =>  "Privat" ,
	 'LOGGED_IN'  =>  "Registrierte Benutzer" ,
	 'PUBLIC'  =>  "Öffentlich" ,
	 'access:friends:label'  =>  "Freunde" ,
	 'access'  =>  "Zugangsrechte" ,

		/**
		 * Dashboard and widgets
		 */

	 'dashboard'  =>  "Dashboard" ,
	 'dashboard:configure'  =>  "Seite Bearbeiten" ,
	 'dashboard:nowidgets'  =>  "Das Dashboard ist Dein ganz persönlicher Einstieg in unser Netzwerk. Klicke auf <b>Seite Bearbeiten</b> um Widgets (das sind kleine, interaktive Anzeigetools) in Dein Dashboard zu ziehen. Damit bestimmst Du selbst Deinen Überblick über die Aktivitäten des gesamten Netzwerks." ,

	 'widgets:add'  =>  "Füge Widgets zu Deiner Seite hinzu" ,
	 'widgets:add:description'  =>  "Wähle auf der rechten Seite aus, welches Widget Du nutzen möchtest. Fahre mit der Maus über das Kreuz eines Widgets und ziehe es bei gedrückter linker Maustaste an die gewünschte Stelle. Zum Ablegen eines Widgets einfach die linke Maustaste los lassen. Umgekehrt gehts genauso: möchtest Du ein Widget wieder entfernen, ziehe es einfach aus der jeweiligen Spalte zurück in die Auswahl der Widgets. Probiere es, es macht Spass ;-)" ,
	 'widgets:position:fixed'  =>  "(Feste Position auf der Seite)" ,
	 'widgets'  =>  "Widgets" ,
	 'widget'  =>  "Widget" ,
	 'item:object:widget'  =>  "Widgets" ,
	 'layout:customise'  =>  "Angepastes layout" ,
	 'widgets:gallery'  =>  "Widget Galerie" ,
	 'widgets:leftcolumn'  =>  "Linke widgets" ,
	 'widgets:fixed'  =>  "Feste Position" ,
	 'widgets:middlecolumn'  =>  "Mittlere widgets" ,
	 'widgets:rightcolumn'  =>  "Rechte widgets" ,
	 'widgets:profilebox'  =>  "Profil Box" ,
	 'widgets:panel:save:success'  =>  "Deine Widget Auswahl wurde gespeichert." ,
	 'widgets:panel:save:failure'  =>  "Up's - Beim speichern ist ein Fehler aufgetreten. Versuche es doch bitte noch einmal." ,
	 'widgets:save:success'  =>  "Deine Widget Auswahl wurde gespeichert." ,
	 'widgets:save:failure'  =>  "Wir konnten das Widget nicht speichern. Bitte versuche es noch einmal." ,
	 'widgets:handlernotfound'  =>  "Sorry: Dieses Widget ist defekt oder durch einen Administrator deaktiviert worden." ,

		/**
		 * Groups
		 */

	 'group'  =>  "Gruppe" ,
	 'item:group'  =>  "Gruppen" ,


		/**
		 * Profile
		 */

	 'profile'  =>  "Profil" ,
			'profile:edit:default' => 'Ersetze Profilfelder',
	 'user'  =>  "Benutzer" ,
	 'item:user'  =>  "Die Benutzer" ,
	 'riveritem:single:user'  =>  "Benutzer" ,
	 'riveritem:plural:user'  =>  "einige Benutzer" ,

		/**
		 * Profile menu items and titles
		 */

	 'profile:yours'  =>  "Dein Profil" ,
	 'profile:user'  =>  "%s's Profil" ,

	 'profile:edit'  =>  "Profil ändern" ,
			'profile:profilepictureinstructions' => "Das Profilbild wird auf deiner Profilseite angezeigt. <br /> Du kannst es so oft du willst ändern. (Mögliche Dateiformate: GIF, JPG or PNG)",
	 'profile:icon'  =>  "Profilbild" ,
	 'profile:createicon'  =>  "Erstelle dein Profilbild" ,
	 'profile:currentavatar'  =>  "Aktuelles Bild" ,
	 'profile:createicon:header'  =>  "Profil-Bild" ,
			'profile:profilepicturecroppingtool' => "Profilbild Schneidewerkzeug",
			'profile:createicon:instructions' => "Klicke und ziehe unten ein Quadrat, um dein Bild zu beschneiden. Eine Vorschau deines zugeschnitten Bildes wird in der Box rechts erscheinen. Wenn du mit dem Zuschnitt zufrieden bist, klicke auf 'Erstelle dein Profilbild'. Das Bild wird dann auf der ganzen Seite als neues Profilbild genutzt. ",
	 'profile:editdetails'  =>  "Details bearbeiten" ,
	 'profile:editicon'  =>  "Profilbild ändern" ,

	 'profile:aboutme'  =>  "Über mich" ,
	 'profile:description'  =>  "Über mich" ,
	 'profile:briefdescription'  =>  "Kurze Beschreibung" ,
	 'profile:location'  =>  "Ort" ,
	 'profile:skills'  =>  "Fähigkeiten" ,
	 'profile:interests'  =>  "Interessen" ,
	 'profile:contactemail'  =>  "E-Mail" ,
	 'profile:phone'  =>  "Tel." ,
	 'profile:mobile'  =>  "Mobil" ,
	 'profile:website'  =>  "Webseite" ,

	 'profile:banned'  =>  "Dieser Benutzer wurde vorerst (aus nicht öffentlichen Gründen) von unserer Community gesperrt." ,

	 'profile:river:update'  =>  "%s hat sein Profil aktualisiert" ,
	 'profile:river:iconupdate'  =>  "%s hat sein Profilbild bearbeitet" ,

	 'profile:label'  =>  "Profil label" ,
	 'profile:type'  =>  "Profilart" ,

	 'profile:editdefault:fail'  =>  "Standardprofil konnte nicht espeichert werden." ,
	 'profile:editdefault:success'  =>  "Erfolgreich hinzugefügt!" ,

	 'profile:editdefault:delete:fail'  =>  "Fehlgeschlagen... Bitte versuche es erneut." ,
	 'profile:editdefault:delete:success'  =>  "Gelöscht" ,

			'profile:defaultprofile:reset' => 'Standard Systemprofil zurücksetzen',

			'profile:resetdefault' => 'Standardprofil zurücksetzen',

		/**
		 * Profile status messages
		 */

	 'profile:saved'  =>  "Din profil wurde erfolgreich gespeichert." ,
	 'profile:icon:uploaded'  =>  "Dein Profilbild wurde erfolgreich hochgeladen." ,

		/**
		 * Profile error messages
		 */

	 'profile:noaccess'  =>  "Du hast keine Berechtigung dieses Profil zu Bearbeiten!" ,
	 'profile:notfound'  =>  "Sorry aber dieses Profil konnte nicht in unserer Datenbank gefunden werden." ,
	 'profile:cantedit'  =>  "Sorry aber Du hast keine Berechtigung dieses Profil zu Bearbeiten." ,
	 'profile:icon:notfound'  =>  "Sorry aber da lief was schief - bitte versuche es erneut." ,

		/**
		 * Friends
		 */

	 'friends'  =>  "Freunde" ,
	 'friends:yours'  =>  "Deine Freunde" ,
	 'friends:owned'  =>  "%s's Freunde" ,
	 'friend:add'  =>  "Als Freund hinzufügen" ,
	 'friend:remove'  =>  "Freundschaft kündigen" ,

	 'friends:add:successful'  =>  "%s wurde als Freund hinzugefügt." ,
	 'friends:add:failure'  =>  "Wir konnten %s nicht als Freund hinzufügen. Bitte versuche es erneut." ,

	 'friends:remove:successful'  =>  "%s wurde erfolgreich von Deiner Freundesliste entfernt." ,
	 'friends:remove:failure'  =>  "Wir konnten %s nicht aus Deiner Liste entfernen. Bitte versuche es erneut." ,

	 'friends:none'  =>  "Dieser Benutzer hat noch keine Freundschaften geknüpft." ,
	 'friends:none:you'  =>  "Du hast noch niemanden hinzugefügt. Benutze die Suche und finde Freunde mit Deinen Interessen." ,

	 'friends:none:found'  =>  "Keine Freunde gefunden." ,

	 'friends:of:none'  =>  "Dieser Benutzer wurde noch nicht als Freund hinzugefügt." ,
	 'friends:of:none:you'  =>  "Noch niemand hat Dich als Freund geaddet? Fülle Dein Profil aus und laß die Benutzer DICH finden. Auch die Suchfunktion kann Dir weiterhelfen." ,

	 'friends:of:owned'  =>  "Benutzer die %s als Freund hinzugefügt haben" ,

	 'friends:num_display'  =>  "Anzahl der Freunde anzeigen:" ,
	 'friends:icon_size'  =>  "Bildgröße" ,
	 'friends:tiny'  =>  "klein" ,
	 'friends:small'  =>  "normal" ,
	 'friends:of'  =>  "Freundes Freunde" ,
	 'friends:collections'  =>  "Auswahl der Freunde" ,
	 'friends:collections:add'  =>  "Neue Freundes Gruppe" ,
	 'friends:addfriends'  =>  "Freunde hinzufügen" ,
	 'friends:collectionname'  =>  "Gruppen Name" ,
	 'friends:collectionfriends'  =>  "Freunde in Gruppe" ,
	 'friends:collectionedit'  =>  "Bearbeite diese Gruppe" ,
	 'friends:nocollections'  =>  "Du hast derzeit keine Freundes Gruppe." ,
	 'friends:collectiondeleted'  =>  "Deine Freundes Gruppe wurde gelöscht." ,
	 'friends:collectiondeletefailed'  =>  "Leider kann diese Gruppe nicht gelöscht werden. Entweder hast Du keine Berechtigung dazu oder es ist ein Fehler aufgetreten." ,
	 'friends:collectionadded'  =>  "Deine Gruppe wurde erstellt." ,
	 'friends:nocollectionname'  =>  "Du musst Deiner neuen Gruppe einen Namen geben." ,
	 'friends:collections:members'  =>  "Gruppen Mitglieder" ,
	 'friends:collections:edit'  =>  "Bearbeite die Gruppe" ,

	 'friends:river:created'  =>  "%s hat das Freundes-Widget hinzugefügt." ,
	 'friends:river:updated'  =>  "%s hat sein Freundes Widget aktualisiert." ,
	 'friends:river:delete'  =>  "%s hat sein Freundes Widget entfernt." ,
	 'friends:river:add'  =>  "%s ist ein Freund von" ,

	 'friendspicker:chararray'  =>  "ABCDEFGHIJKLMNOPQRSTUVWXYZ" ,

		/**
		 * Feeds
		 */

	 'feed:rss'  =>  "Feed abonieren" ,
			'feed:odd' => 'Syndicate OpenDD',

		/**
          * links
		 **/

	 'link:view'  =>  "Link öffnen" ,

		/**
		 * River
		 */
	 'river:relationship:friend'  =>  "ist jetzt ein Freund von" ,
	 'river:noaccess'  =>  "Keine Berechtigung!" ,
	 'river:posted:generic'  =>  "%s schrieb" ,

		/**
		 * Plugins
		 */
			'plugins:settings:save:ok' => "Einstellungen für das Plugin %s erfolgreich gespeichert.",
			'plugins:settings:save:fail' => "Beim Speichern der Einstellungen des Plugins %s ist ein Fehler aufgetreten.",
			'plugins:usersettings:save:ok' => "Benutzer Einstellungen für das Plugin %s erfolgreich gespeichert.",
			'plugins:usersettings:save:fail' => "Beim Speichern der Benutzer Einstellungen des Plugins %s ist ein Fehler aufgetreten.",
			'admin:plugins:label:version' => "Version",
			'item:object:plugin' => 'Einstellungen des Plugins',

		/**
		 * Notifications
		 */

	 'notifications:usersettings'  =>  "Benachrichtigungs Optionen" ,
			'notifications:methods' => "Bitte spezifiziere, welche Methode du erlauben willst.",

			'notifications:usersettings:save:ok' => "Deine Benachrichtigungs Optionen wurden erfolgreich gespeichert.",
			'notifications:usersettings:save:fail' => "Beim Speichern der Benachrichtigungs Optionen ist ein Fehler aufgetreten.",

			'user.notification.get' => 'Zurück zu den Benachrichtigungs Optionen für einen bestimmten Benutzer.',
			'user.notification.set' => 'Benachrichtigungs Optionen für einen bestimmten Benutzer setzen.',

		/**
		 * Search
		 */
	 'search'  =>  "Suchen" ,
	 'searchtitle'  =>  "Suche: %s" ,
	 'users:searchtitle'  =>  "Suche nach Benutzern: %s" ,
	 'advancedsearchtitle'  =>  "%s mit passenden Ergebnissen &s" ,
			'notfound' => "Keine Ergebnisse gefunden.",
	 'next'  =>  "Nächste" ,
	 'previous'  =>  "Vorherige" ,

	 'viewtype:change'  =>  "Listentyp ändern" ,
	 'viewtype:list'  =>  "Listen Ansicht" ,
	 'viewtype:gallery'  =>  "Galerie Ansicht" ,

	 'tag:search:startblurb'  =>  "Inhalte mit Tag´s passend zu \"%s\":" ,

	 'user:search:startblurb'  =>  "Benutzer passend zu \"%s\":" ,
	 'user:search:finishblurb'  =>  "Hier klicken um mehr zu sehen." ,


		/**
		 * Account
		 */

	 'account'  =>  "Benutzerkonto" ,
	 'settings'  =>  "Einstellungen" ,
	 'tools'  =>  "Menü" ,
	 'tools:yours'  =>  "Deine Tools" ,

	 'register'  =>  "Registrieren" ,
	 'registerok'  =>  "Du bist erfolgreich für %s registriert" ,
	 'registerbad'  =>  "Da lief was schief und das schon am Start. Es könnte daran liegen, dass Dein benutzername bereits existiert, die Passwörter nicht übereinstimmen oder eines von beiden zu kurz war. Bitte versuche es erneut." ,
	 'registerdisabled'  =>  "Registrierungen wurden deaktiviert." ,

			'firstadminlogininstructions' => 'Deine neue Elgg Seite wurde erfolgreich installiert und dein Administrator Konto wurde erstellt. Du kannst nun deine Seite durch das Einschalten zahlreicher Plugins weiter konfigurieren.',

	 'registration:notemail'  =>  "Die Email Adresse passt nicht zu der validierten Adresse." ,
	 'registration:userexists'  =>  "Benutzername existiert bereits." ,
	 'registration:usernametooshort'  =>  "Dein Benutzername muss mindestens 4 Zeichen haben." ,
	 'registration:passwordtooshort'  =>  "Dein Passwort muss mindestens 6 Zeichen haben." ,
	 'registration:dupeemail'  =>  "Diese Email Adresse wurde bereits registriert." ,
	 'registration:invalidchars'  =>  "Der Benutzername enthält verbotene Zeichen." ,
	 'registration:emailnotvalid'  =>  "Diese Email Adresse ist unserem System unbekannt." ,
	 'registration:passwordnotvalid'  =>  "Das Passwort wird nicht von uns unterstützt (bitte keine speziellen Sonderzeichen)." ,
	 'registration:usernamenotvalid'  =>  "Der Benutzername wird nicht von unserem System unterstützt." ,

	 'adduser'  =>  "Benutzer hinzufügen" ,
	 'adduser:ok'  =>  "Du hast erfolgreich einen neuen Benutzer hinzugefügt." ,
			'adduser:bad' => "Der neue Benutzer konnte nicht erzeugt werden.",

			'item:object:reported_content' => "Gemeldete Punkte",

	 'user:set:name'  =>  "Benutzerkonto Einstellungen" ,
	 'user:name:label'  =>  "Dein Name" ,
	 'user:name:success'  =>  "Dein Benutzername wurde erfolgreich geändert." ,
	 'user:name:fail'  =>  "Deine Änderung konnte nicht gespeichert werden." ,

	 'user:set:password'  =>  "Benutzer Passwort" ,
	 'user:password:label'  =>  "Dein neues Passwort" ,
	 'user:password2:label'  =>  "Wiederhole die Passworteingabe" ,
	 'user:password:success'  =>  "Dein Passwort wurde erfolgreich geändert" ,
	 'user:password:fail'  =>  "Das Passwort konnte nicht im System geändert werden. Versuche es noch einmal oder wende Dioch an einen Administrator." ,
	 'user:password:fail:notsame'  =>  "Die beiden Passworteingaben stimmen nicht überein." ,
	 'user:password:fail:tooshort'  =>  "Das Passwort ist zu kurz!" ,

	 'user:set:language'  =>  "Sprach Optionen" ,
	 'user:language:label'  =>  "Deine Sprache" ,
	 'user:language:success'  =>  "Deine Sprachoptionen wurden auktualisiert." ,
	 'user:language:fail'  =>  "Deine Sprachoptionen können nicht gespeichert werden." ,

	 'user:username:notfound'  =>  "Benutzername %s nicht gefunden." ,

	 'user:password:lost'  =>  "Passwort vergessen?" ,
	 'user:password:resetreq:success'  =>  "Eine Email wurde an Dich versand." ,
	 'user:password:resetreq:fail'  =>  "Konnte kein neues Passwort beantragen." ,

	 'user:password:text'  =>  "Um ein neues Passwort zu beantragen gebe bitte Deinen Benutzernamen ein. Wir werden Dir dann eine Email mit weiteren Instruktionen senden." ,

	 'user:persistent'  =>  "Speichern" ,

		/**
		 * Administration
		 */
	 'admin:configuration:success'  =>  "Einstellungen gespeichert" ,
	 'admin:configuration:fail'  =>  "Die Einstellungen können nicht gespeichert werden." ,

	 'admin'  =>  "Administration" ,
			'admin:description' => "Das Administrationscockpit gibt dir Kontrolle über alle Teile des Systems, von Benutzerverwaltung bis zum Verhalten von Plugins. Wähle einen Punkt unten, um zu beginnen.",

	 'admin:user'  =>  "Benutzer Administration" ,
			'admin:description' => "Das Administrationscockpit gibt dir Kontrolle über die Benutzerverwaltung. Wähle einen Punkt unten, um zu beginnen.",
	 'admin:user:adduser:label'  =>  "Benutzer hinzufügen..." ,
			'admin:user:opt:linktext' => "Benutzer einstellen...",
			'admin:user:opt:description' => "Configure users and account information. ",

	 'admin:site'  =>  "Seiten Administration" ,
			'admin:site:opt:linktext' => "Seite einstellen...",
			'admin:site:access:warning' => "Änderungen an den Zugriffeinstellungen betreffen nur Rechte an zukünftigen Inhalten.",

			'admin:plugins' => "Tool Administration",
			'admin:plugins:opt:linktext' => "Tools einstellen...",
	 'admin:plugins:label:author'  =>  "Autor" ,
	 'admin:plugins:label:copyright'  =>  "Copyright" ,
	 'admin:plugins:label:licence'  =>  "Lizenz" ,
	 'admin:plugins:label:website'  =>  "URL" ,
	 'admin:plugins:label:moreinfo'  =>  "Mehr Info" ,
			'admin:plugins:warning:elggversionunknown' => 'Warnung: Dieses Plguin gibt keine kompatible Elgg Version an.',
			'admin:plugins:warning:elggtoolow' => 'Warnung: Diese Plugin erfordert eine neuere Version von Elgg!',
			'admin:plugins:reorder:yes' => "Plugin %s wurde erfolgreich umsortiert.",
			'admin:plugins:reorder:no' => "Plugin %s konnte nicht umsortiert werden.",
			'admin:plugins:disable:yes' => "Plugin %s wurde erfolgreich abgeschaltet.",
			'admin:plugins:disable:no' => "Plugin %s konnte nicht abgeschlatet werden.",
			'admin:plugins:enable:yes' => "Plugin %s wurde erfolgreich aktiviert.",
			'admin:plugins:enable:no' => "Plugin %s konnte nicht aktiviert werden.",

	 'admin:statistics'  =>  "Statistiken" ,
			'admin:statistics:opt:description' => "Zeige Statistiken über Benutzer und Objekte auf deiner Seite an.",
			'admin:statistics:opt:linktext' => "Zeigt Statistiken...",
			'admin:statistics:label:basic' => "Generell Seitenstatistiken",
			'admin:statistics:label:numentities' => "Objekte auf Seite",
			'admin:statistics:label:numusers' => "Anzahl der Benutzer",
			'admin:statistics:label:numonline' => "Anzahl der Benutzer online",
			'admin:statistics:label:onlineusers' => "Benutzer jetzt online",
			'admin:statistics:label:version' => "Elgg Version",
			'admin:statistics:label:version:release' => "Release",
			'admin:statistics:label:version:version' => "Version",

			'admin:user:label:search' => "Finde Benutzer:",
	 'admin:user:label:seachbutton'  =>  "Suche" ,

			'admin:user:ban:no' => "Benutzer kann nicht gesperrt werden",
			'admin:user:ban:yes' => "Benutzer gesperrt.",
			'admin:user:unban:no' => "Benutzer kann nicht entsperrt werden",
			'admin:user:unban:yes' => "Benutzer entsperrt.",
			'admin:user:delete:no' => "Benutzer kann nicht gelöscht werden",
			'admin:user:delete:yes' => "Benutzer gelöscht",

			'admin:user:resetpassword:yes' => "Passwort zurückgesetzt, Benutzer informiert.",
			'admin:user:resetpassword:no' => "Passwort konnte nicht zurückgesetzt werden.",

			'admin:user:makeadmin:yes' => "Benutzer ist nun ein Admin.",
			'admin:user:makeadmin:no' => "Benutzer konnte kein Admin werden.",

			'admin:user:removeadmin:yes' => "Benutzer ist kein Admin mehr.",
			'admin:user:removeadmin:no' => "Adminrechte konnte nicht entzogen werden.",

		/**
		 * User settings
		 */
	 'usersettings:description'  =>  "Hier kannst Du Deine persönlichen Einstellungen vornehmen." ,

	 'usersettings:statistics'  =>  "Profilstatistik" ,
	 'usersettings:statistics:opt:description'  =>  "Zeige Statistik Informartionen Deiner Seite." ,
	 'usersettings:statistics:opt:linktext'  =>  "Profil Statistik" ,

	 'usersettings:user'  =>  "Deine Einstellungen" ,
	 'usersettings:user:opt:description'  =>  "Hier kannst Du Deine persönlichen Einstellungen vornehmen." ,
	 'usersettings:user:opt:linktext'  =>  "Einstellungen ändern" ,

	 'usersettings:plugins'  =>  "Tools" ,
	 'usersettings:plugins:opt:description'  =>  "Configure settings (if any) for your active tools." ,
	 'usersettings:plugins:opt:linktext'  =>  "Tools verwalten" ,

	 'usersettings:plugins:description'  =>  "Hier kannst Du die Tools konfigurieren, welche Dir vom System freigegeben wurden. Tools sind optional und es kann sein, dass Dir keine Tools zur Verfügung stehen, wenn keine installiert wurden. Wenn diese Seite also leer ist, muss das kein Fehler sein ;-)" ,
	 'usersettings:statistics:label:numentities'  =>  "Objekt Statistik" ,

	 'usersettings:statistics:yourdetails'  =>  "Details" ,
	 'usersettings:statistics:label:name'  =>  "Dein Name" ,
	 'usersettings:statistics:label:email'  =>  "e-Mail" ,
	 'usersettings:statistics:label:membersince'  =>  "Anmeldedatum" ,
	 'usersettings:statistics:label:lastlogin'  =>  "Zuletzt eingeloggt" ,

		/**
		 * Generic action words
		 */

	 'save'  =>  "Speichern" ,
	 'publish'  =>  "Veröffentlichen" ,
	 'cancel'  =>  "Abbruch" ,
	 'saving'  =>  "speichere..." ,
	 'update'  =>  "Aktualisieren" ,
	 'edit'  =>  "Bearbeiten" ,
	 'delete'  =>  "Löschen" ,
	 'accept'  =>  "Akzeptieren" ,
	 'load'  =>  "Laden" ,
	 'upload'  =>  "Hochladen" ,
	 'ban'  =>  "Sperren" ,
	 'unban'  =>  "Sperre aufheben" ,
	 'enable'  =>  "Aktivieren" ,
	 'disable'  =>  "Deaktivieren" ,
	 'request'  =>  "Anfrage" ,
	 'complete'  =>  "Komplett" ,
	 'open'  =>  "Offen" ,
	 'close'  =>  "Geschlossen" ,
	 'reply'  =>  "Antwort" ,
	 'more'  =>  "Mehr" ,
	 'comments'  =>  "Kommentare" ,
	 'import'  =>  "Importieren" ,
	 'export'  =>  "Exportieren" ,

	 'up'  =>  "Hoch" ,
	 'down'  =>  "Herunter" ,
	 'top'  =>  "Oben" ,
	 'bottom'  =>  "Unten" ,

	 'invite'  =>  "Einladen" ,

	 'resetpassword'  =>  "Passwort zurücksetzen" ,
	 'makeadmin'  =>  "Adminrechte geben" ,
	 'removeadmin'  =>  "Adminrechte entfernen" ,

	 'option:yes'  =>  "Ja" ,
	 'option:no'  =>  "Nein" ,

	 'unknown'  =>  "Unbekannt" ,

	 'active'  =>  "Aktiv" ,
	 'total'  =>  "Gesamt" ,

			'learnmore' => "Hier klicken um mehr zu erfahren.",

			'content' => "Inhalt",
	 'content:latest'  =>  "Neueste Aktivitäten" ,
			'content:latest:blurb' => 'Alternativ, klick hier um die neuesten Inhalte auf der Seite zu sehen.',

	 'link:text'  =>  "Link>" ,

	 'enableall'  =>  "Erlaube alle" ,
	 'disableall'  =>  "Verbiete alle" ,

		/**
		 * Generic questions
		 */

	 'question:areyousure'  =>  "Bist du sicher?" ,

		/**
		 * Generic data words
		 */

	 'title'  =>  "Titel" ,
	 'description'  =>  "Beschreibung" ,
	 'tags'  =>  "Tags" ,
	 'spotlight'  =>  "Spotlight" ,
	 'all'  =>  "Alle" ,

	 'by'  =>  "bei" ,

	 'annotations'  =>  "Anmerkungen" ,
	 'relationships'  =>  "Beziehungen" ,
	 'metadata'  =>  "Metadaten" ,


		/**
		 * Input / output strings
		 */
	 'deleteconfirm'  =>  "Willst Du wirklich diesen Eintrag löschen?" ,
			'fileexists' => "Eine Datei wurde bereits hochgeladen. Um sie zu ersetzen, wähle dies bitte unten aus:",

		/**
		 * User add
		 */
	 'useradd:subject'  =>  "Benutzerkonto erstellt" ,
			'useradd:body' => '
%s,

Du hast ein Benutzerkonto auf %s erstellt. Um dich einzuloggen, besuche:

	%s

Log dich mit diesen Angabne ein:

	Username: %s
	Password: %s

Sobald du eingeloggt bist, raten wir dir dringend, dein Passwort zu ändern.
',

	    /**
         * System messages
         **/
			'systemmessages:dismiss' => "Hier ausblenden",

		/**
		 * Time
		 */

	 'friendlytime:justnow'  =>  "grade eben" ,
	 'friendlytime:minutes'  =>  "vor %s Minuten" ,
	 'friendlytime:minutes:singular'  =>  "vor einer Minute" ,
	 'friendlytime:hours'  =>  "vor %s Stunden" ,
	 'friendlytime:hours:singular'  =>  "vor einer Stunde" ,
	 'friendlytime:days'  =>  "vor %s Tagen" ,
	 'friendlytime:days:singular'  =>  "gestern" ,

	 'date:month:01'  =>  "Januar %s" ,
	 'date:month:02'  =>  "Februar %s" ,
	 'date:month:03'  =>  "März %s" ,
	 'date:month:04'  =>  "April %s" ,
	 'date:month:05'  =>  "Mai %s" ,
	 'date:month:06'  =>  "Juni %s" ,
	 'date:month:07'  =>  "Juli %s" ,
	 'date:month:08'  =>  "August %s" ,
	 'date:month:09'  =>  "September %s" ,
	 'date:month:10'  =>  "Oktober %s" ,
	 'date:month:11'  =>  "November %s" ,
	 'date:month:12'  =>  "Dezember %s" ,

		/**
		 * Installation and system settings
		 */

			'upgrading' => 'Upgrading',
			'upgrade:db' => 'Deine Datenbank wurde upgegraded.',
			'upgrade:core' => 'Deine Elgg Installation wurde upgegraded',
		/**
		 * Welcome
		 */

	 'welcome'  =>  "Willkommen" ,
			'welcome_message' => "Willkommen in dieser Elgg Installation.",

		/**
		 * Emails
		 */
	 'email:settings'  =>  "eMail Einstellungen" ,
	 'email:address:label'  =>  "Deine eMail Adresse" ,

	 'email:save:success'  =>  "E-Mail Adresse gespeichert," ,
	 'email:save:fail'  =>  "Deine neue eMail Adresse konnte nicht gespeichert werden." ,

	 'friend:newfriend:subject'  =>  "%s hat dich als Kontakt hinzugefügt" ,
	 'friend:newfriend:body'  =>  "%s hat dich als Kontakt hinzugefügt.

Um das Profil von %s zu sehen, klicke bitte hier:

	%s.

Auf diese E-Mail ist kein Antworten möglich." ,

			'email:resetpassword:subject' => "Passwort zurücksetzen!",
	 'email:resetreq:body'  =>  "Hi %s,

jemand hat ein neues Passwort (von dieser IP Adresse %s) für Dein Benutzerkonto angefordert.

Wenn Du das Passwort angefordert hast, klicke bitte auf den nachfolgenden Link unten.

%s

Anderenfalls ignoriere einfach diese E-Mail." ,

		/**
		 * user default access
		 */
	 'default_access:settings'  =>  "Dein Standard-Zugangslevel" ,
	 'default_access:label'  =>  "Standard Zugang" ,
		'user:default_access:success' => "Dein neues Standard-Zugangslevel wurde gespeichert.",
		'user:default_access:failure' => "Dein neues Standard-Zugangslevel konnte nicht gespeichert werden.",

		/**
		 * XML-RPC
		 */
	 'xmlrpc:noinputdata'  =>  "Eingegebene Daten fehlen" ,

		/**
		 * Comments
		 */
	 'comments:count'  =>  "% Kommentare" ,

	 'riveraction:annotation:generic_comment'  =>  "%s kommentiert auf %s" ,

	 'generic_comments:add'  =>  "Beitrag hinzufügen" ,
	 'generic_comments:text'  =>  "Beitrag" ,
	 'generic_comment:posted'  =>  "Dein Beitrag wurde erfolgreich gespeichert" ,
	 'generic_comment:deleted'  =>  "Dein Beitrag wurde erfolgreich gelöscht" ,
			'generic_comment:blank' => "Entschuldigung: du musst zuerst einen Kommentar schreiben, bevor wir es speichern können.",
			'generic_comment:notfound' => "Entschuldigung: wir konnten den angegebenen Eintrag nicht finden.",
			'generic_comment:notdeleted' => "Entschuldigung: wir konnten den angegebenen Eintrag nicht löschen.",
			'generic_comment:failure' => "Ein unerwarteter Fehler trat während des Speicherns auf. Bitte versuche es erneut.",

	 'generic_comment:email:subject'  =>  "Du hast einen neuen Kommentar!" ,
	 'generic_comment:email:body'  =>  "Du hast eine neue Antwort zu deinem Beitrag \"%s\" von %s. Hier ist die Antwort: %s  Um darauf zu Antworten oder den originalen Beitrag zu sehen, klicke bitte hier: %s Um das Profil von %s anzusehen, klicke bitte hier: %s Du kannst auf diese E-Mail nicht antworten." ,

	 'entity:default:strapline'  =>  "Erstellt %s von %s" ,

		/**
		 * Entities
		 */
			'entity:default:strapline' => 'Erstellt %s von %s',
			'entity:default:missingsupport:popup' => 'Dieses Objekt kann nicht korrekt angezeigt werden. Es kann sein, dass ein benötigtes Plugin nicht mehr installiert ist.',

			'entity:delete:success' => 'Objekt %s wurde gelöscht',
			'entity:delete:fail' => 'Objekt %s konnte nicht gelöscht werden',

		/**
		 * Action gatekeeper
		 */
			'actiongatekeeper:missingfields' => '__token oder __ts Felder fehlen im Formular',
			'actiongatekeeper:tokeninvalid' => "Ein Fehler ist aufgetreten (unpassendes Merkmal). Es könnte sein, dass die benutze Seite nicht mehr gültig ist. Bitte versuche es nochmals.",
			'actiongatekeeper:timeerror' => 'Die benutzte Seite ist abgelaufen. Bitte aktulisere sie and versuche es nochmals.',
			'actiongatekeeper:pluginprevents' => 'Eine Erweiterung verhinderte, dass das Formular gespeichert wurde.',

		/**
		 * Languages according to ISO 639-1
		 */
			"de" => "German",

);

add_translation('de', $german);

?>