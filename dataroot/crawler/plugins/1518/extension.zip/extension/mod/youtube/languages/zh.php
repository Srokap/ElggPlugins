<?php
	/**
	 *  Chinese Language Package
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @translator Cosmo Mao
	 * @copyright cOSmoCommerce.com 2008
	 * @link http://www.elggsns.cn/
	 * @version 0.1
	 */
	$chinese= array(
	
		/**
		 * youtube widget details
		 */
		
	
		'youtube:notset' => '没有视频可以编辑',
		'youtube:title' => '视频标题',
		'youtube:text' => 'Youtube嵌入代码',
		
		
		 /**
	     * youtube widget river
	     **/
	        
	        //generic terms to use
	        'youtube:river:created' => "%s 添加了 Youtube插件。",
	        'youtube:river:updated' => "%s 更新了 Youtube插件。",
	        'youtube:river:delete' => "%s 删除了 Youtube插件。",
	        
		
	);
					
	add_translation("zh",$chinese);

?>