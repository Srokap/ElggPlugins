<?php
	/**
	 *  Chinese Language Package
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @translator Cosmo Mao
	 * @copyright cOSmoCommerce.com 2008
	 * @link http://www.elggsns.cn/
	 * @version 0.1
	 */
	$chinese= array(
	
		/**
		 * Flickr widget details
		 */
		
	
		'flickr:id' => '输入您的Flickr ID号',
		'flickr:whatisid' => '如果您不知道自己的Flickr ID号是什么，可以通过链接的第三方机构查找<a href="http://idgettr.com/" target="_blank" >http://idgettr.com/</a>.',
		
		 /**
	     * Flickr widget river
	     **/
	        
	        //generic terms to use
	        'flickr:river:created' => "%s 添加了 Flickr 插件。",
	        'flickr:river:updated' => "%s  更新了 Flickr 插件。",
	        'flickr:river:delete' => "%s  删除了 Flickr 插件。",
	        
		
	);
					
	add_translation("zh",$chinese);

?>