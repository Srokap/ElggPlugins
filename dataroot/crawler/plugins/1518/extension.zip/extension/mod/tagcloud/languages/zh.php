<?php
	/**
	 *  Chinese Language Package
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @translator Cosmo Mao
	 * @copyright cOSmoCommerce.com 2008
	 * @link http://www.elggsns.cn/
	 * @version 0.1
	 */
	$chinese= array(
		"tagcloud:widget:title" => "标签云",
		"tagcloud:widget:description" => "标签云",
		"tagcloud:widget:notags" => "显示数量"
	);
					
	add_translation("zh",$chinese);

?>
