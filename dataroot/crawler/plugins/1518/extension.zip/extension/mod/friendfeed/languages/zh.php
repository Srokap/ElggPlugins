<?php
	/**
	 *  Chinese Language Package
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @translator Cosmo Mao
	 * @copyright cOSmoCommerce.com 2008
	 * @link http://www.elggsns.cn/
	 * @version 0.1
	 */
	$chinese= array(
	
		'friendfeed' => 'FriendFeed',
	
		'friendfeed:username' => 'FriendFeed 用户名',
		'friendfeed:apikey' => 'Friendfeed API key',
		'friendfeed:apikeyfind' => '查看您的API Key',
		'friendfeed:num_display' => '显示条目',
	
	
		'friendfeed:favorited' => "收藏: ",
	
		'friendfeed:nouser' => '本插件还未配置。',
		'friendfeed:nonefound' => '这次没有找到所要信息。',
		'friendfeed:epicfail' => '我们无法连接到这个用户的 FriendFeed 。',
			
	);
					
	add_translation("zh",$chinese);

?>