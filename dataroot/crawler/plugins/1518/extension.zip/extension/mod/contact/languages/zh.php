<?php

	/**
	 * Elgg contact plugin
	 * This plugin allows to send message to custom email you specify at module configuration area
	 * 
	 * @package ElggContact
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @author Tim Timalsina <info@timalsina.com>
	 * @copyright Curverider Ltd 2008
	 * @copyright TIMALSINA 2008
	 * @link http://elgg.com/
	 */

	/**
	 *  Chinese Language Package
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @translator Cosmo Mao
	 * @copyright cOSmoCommerce.com 2008
	 * @link http://www.elggsns.cn/
	 * @version 0.1
	 */
	 		
		$chinese= array(
	
		/**
		 * Plugin button, menu title, page title, default email
		 */
	
			'contact:plugin:name' => "联系我们",
			'contact:page:title' => "联系我们",			
			'contact:button:send' => "发送消息",
			'contact:default:email' => "默认联系邮箱",
			
		/**
		 * Input Form elements
		 */
			
			'contact:level:name' => "您的姓名",	
			'contact:level:email' => "邮箱地址",
			'contact:level:subject' => "主体",
			'contact:level:message' => "消息",
			'contact:option:feedback' => "反馈",
			'contact:option:bugreport' => "报告错误",
			'contact:option:press' => "信息",
			'contact:option:general' => "通常",			
			
         
		/**
		 * Plugin action feedback
		 */
	
			'contact:send:successful' => "您的信息已经成功发出,我们会尽快联系您的.谢谢.",
			'contact:send:unsuccessful' => "您的信息发送失败,请再试一次.",
			'contact:name:invalid' => "您输入的名字不是有效的,名字只能包括英文字幕,数字.请再试一次.",
			'contact:email:invalid' => "我们系统无法处理您输入的邮箱地址,请再次输入确保您输入的邮箱是正确的.",			
			'contact:message:invalid' => "请不要将消息留空.",
			
	
	);
					
	add_translation("zh",$chinese);

?>