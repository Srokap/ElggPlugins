<?
/**
* Kaltura video client
* @package ElggKalturaVideo
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author Ivan Vergés - Ballo Microstudi SL <ivan@microstudi.net>
* @copyright Ballo Microstudi SL 2008
* @link http://microstudi.net/elgg/
**/

	/**
	 *  Chinese Language Package
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @translator Cosmo Mao
	 * @copyright cOSmoCommerce.com 2008
	 * @link http://www.elggsns.cn/
	 * @version 0.1
	 */
$chinese = array(
	'kalturavideo:label:partner_id' => '合伙人 ID',
	'kalturavideo:label:subp_id' => '次级合伙人 ID',
	'kalturavideo:label:admin_secret' => '管理员密钥',
	'kalturavideo:label:secret' => 'Web Service 密钥',
	'kalturavideo:title:video' => $CONFIG->sitename.'的视频',
	'kalturavideo:descprefix:video' => 'Kaltura的一段视频来自',
	'kalturavideo:text:loginkaltura' => '你可以通过这个数据登陆到Kaltura网站:',
	'kalturavideo:text:buttoninfo' => '(点击按钮 "账户" -> "一般信息")',
	'kalturavideo:text:signupkaltura' => '您需要成为合伙人，注册点击这里:',
	'kalturavideo:label:videotitle' => '建立视频标题',
	'kalturavideo:label:addvideo' => '从Kaltura添加视频',
	'kalturavideo:label:uid_prefix' => 'Kaltura用户前缀',
	'kalturavideo:error:misconfigured' => '错误的配置，或者Kaltura登陆错误!',
	'kalturavideo:label:closewindow' => '关闭',
	'kalturavideo:label:select_size' => '选择播放器大小',
	'kalturavideo:label:large' => '大',
	'kalturavideo:label:small' => '小',
	'kalturavideo:label:insert' => '插入视频',
	'kalturavideo:label:edit' => '编辑视频',
	'kalturavideo:label:miniinsert' => '插入',
	'kalturavideo:label:miniedit' => '编辑',
	'kalturavideo:label:cancel' => '取消',
	'kalturavideo:label:back' => '返回',
	'kalturavideo:label:publish' => '发布',
	'kalturavideo:label:gallery' => '图库',
	'kalturavideo:label:next' => '下一页',
	'kalturavideo:label:prev' => '前一页',
	'kalturavideo:label:start' => '开始',
	'kalturavideo:label:newvideo' => '创建新视频',
	'kalturavideo:label:toolsadmin' => '管理 -> 插件管理 (点击更多信息)',
	'kalturavideo:label:gotoconfig' => '请对Kaltura视频插件进行相应配置',
);

add_translation("zh", $chinese);

?>