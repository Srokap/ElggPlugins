tinyMCE.addI18n('en.example_dlg',{
	title : 'TinyMCE Keyword Extractor'
});
