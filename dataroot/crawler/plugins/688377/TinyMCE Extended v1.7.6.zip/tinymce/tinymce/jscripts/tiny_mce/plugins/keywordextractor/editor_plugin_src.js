(function() {
	tinymce.PluginManager.requireLangPack('keywordextractor');
	tinymce.create('tinymce.plugins.KeywordExtractorPlugin', {
		init : function(ed, url) {
			ed.addCommand('mceKeywordExtractor', function() {
				ed.windowManager.open({
					file : url + '/dialog.htm',
					width : 400 + parseInt(ed.getLang('example.delta_width', 0)),
					height : 300 + parseInt(ed.getLang('example.delta_height', 0)),
					inline : 1
				}, {
					plugin_url : url,
					some_custom_arg : 'custom arg'
				});
			});
			ed.addButton('keywordextractor', {
				title : 'keywordextractor.desc',
				cmd : 'mceKeywordExtractor',
				image : url + '/img/keywordextractor.gif'
			});

			ed.onNodeChange.add(function(ed, cm, n) {
				cm.setActive('keywordextractor', n.nodeName == 'IMG');
			});
		},
		createControl : function(n, cm) {
			return null;
		},
		getInfo : function() {
			return {
				longname : 'Keyword Extractor plugin',
				author : 'Croll Multimedia',
				authorurl : 'http://www.crollmm.com',
				infourl : 'http://ke.crollmm.com',
				version : "0.5"
			};
		}
	});
	tinymce.PluginManager.add('keywordextractor', tinymce.plugins.KeywordExtractorPlugin);
})();
