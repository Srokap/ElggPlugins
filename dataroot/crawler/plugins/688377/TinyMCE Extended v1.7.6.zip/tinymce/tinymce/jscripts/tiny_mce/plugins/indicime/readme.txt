Indic IME 2.5.1 (http://www.vishalon.net/IndicResources/IndicIME.aspx)
Copyright (copy) Vishal Monpara
This plugin is developed using PramukhLib 2.5.1 (http://www.vishalon.net/IndicResources/PramukhLib.aspx)
TinyMCE Supported Version: 2.x, 3.x

Easily write in Bengali(Assamese, Bengali, Manipuri), Devanagari(Hindi, Marathi, Nepali, Sanskrit), Gujarati, Gurmukhi(Punjabi), Kannada, Malaylam, Oriya, Tamil and Telugu with easy-to-use transliterate keyboard. There is no need to download any special software.

--------------------------------------------------------------

Features:

    * Easily write in 9 Indian scripts
    * Click on Indic IME Help button for typing help.
    * No need to learn Indic language typing.
    * Switch to normal english keyboard by pressing F12.
    * Extremely fast Indic typing.
    * It's all magic of Javascript.

Plugin Installation:
   1. Unzip the file on your local hard disk.
   2. Upload "indicime" folder to TinyMCE_ROOT/plugins/
   3. In the init function for TinyMCE (in the Webpage), add "indicime" in a plugin list and add "indicime" and "indicimehelp" button for language dropdown list and help button

Plugin Customization:

   * If you want to customize a list of script to be displayed in dropdown list, add "indicime_scripts" parameter in tinyMCE.init() function.
   * Example 1 Name only - indicime_scripts:"Bengali;Gujarati;Devnagari" - will display only 3 scripts and English in dropdown list
   * Example 2 Name Value pair - indicime_scripts:"My Bengali:bengali;My Gujarati:gujarati;My Devanagari: devanagari" - will display custom names like "My Bengali", "My Gujarati" etc but when selected it will set bengali/gujarati scripts.
   
Need help in typing?
	
    Visit page http://www.vishalon.net/IndicResources/TypingTips.aspx ONLY ONCE in your lifetime and I bet you will never need to visit this page again. Typing is so easy.

Feedback/Suggestions:

    Drop me few lines at http://www.vishalon.net/ContactMe.aspx