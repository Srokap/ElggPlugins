Notes:

* A simple tinymce plugin

Instructions:

Drop into mod, enable in the admin planel and use.

License:

This plugin is licensed only under the GPL 2 because it bundles GPL 3 libraries.
This plugin is not distributed with the MIT version of Elgg, and the MIT
license does not apply to this plugin or any of its bundled software.

Bundled libraries retain their original licensing.

