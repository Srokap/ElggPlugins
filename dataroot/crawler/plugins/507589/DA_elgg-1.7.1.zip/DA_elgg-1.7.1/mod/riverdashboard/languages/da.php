<?php
/*
*
* River dashboard [Danish]
*
* @package language
* @version Id: da.php 2010-06-01
* @source file is Copyright (c) 2008-2010 Curverider Ltd
* @modified and translated by elggzone.com
* @link http://www.elggzone.com
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
*
* This file is part of the Danish language package for Elgg 1.7.1
* Copyright (c) 2010 elggzone.com
*
* The package is free software; you can redistribute it and/or modify it under the terms of the GNU
* General Public License as published by the Free Software Foundation, version 2 of the License.

* The Danish language package is distributed in the hope that it will be useful, but WITHOUT ANY
* WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
* A PARTICULAR PURPOSE. See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this language
* package. If not, see <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>.
*
*/

$danish = array(

	'mine' => 'Mine',
	'filter' => 'Filter',
	'riverdashboard:useasdashboard' => "Erstat standard instrumentpanel med denne aktivitetsstrøm?",
	'activity' => 'Aktivitet',
	'riverdashboard:recentmembers' => 'Seneste medlemmer',

	/**
	 * Site messages
	   **/

	'sitemessages:announcements' => "Bekendtgørelse",
	'sitemessages:posted' => "Postet",
	'sitemessages:river:created' => "Administrator, %s,",
	'sitemessages:river:create' => "postede en ny offentlig besked",
	'sitemessages:add' => "Udgiv en offentlig besked til aktivitetssiden",
	'sitemessage:deleted' => "Site besked slettet",
	'sitemessage:error' => "Kunne ikke gemme site beskeden.",
	
	'river:widget:noactivity' => 'Vi kunne ikke finde nogen aktivitet.',
	'river:widget:title' => "Aktivitet",
	'river:widget:description' => "Vis dine seneste aktiviteter.",
	'river:widget:title:friends' => "Venners aktivitet",
	'river:widget:description:friends' => "Vis hvad dine venner har gang i.",
	'river:widgets:friends' => "Venner",
	'river:widgets:mine' => "Mine",
	'river:widget:label:displaynum' => "Antal emner at vise:",
	'river:widget:type' => "Hvilken strøm vil du vise? En der viser din aktivitet eller en der viser dine venners aktivitet?",
	'item:object:sitemessage' => "Site beskeder",
	'riverdashboard:avataricon' => "Vil du bruge avatars eller ikoner på aktivitetsstrømmen?",
	'option:icon' => 'Ikoner',
	'option:avatar' => 'Avatars',

);

add_translation("da",$danish);

?>