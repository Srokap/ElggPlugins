<?php
/*
*
* Messages [Danish]
*
* @package language
* @version Id: da.php 2010-06-01
* @source file is Copyright (c) 2008-2010 Curverider Ltd
* @modified and translated by elggzone.com
* @link http://www.elggzone.com
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
*
* This file is part of the Danish language package for Elgg 1.7.1
* Copyright (c) 2010 elggzone.com
*
* The package is free software; you can redistribute it and/or modify it under the terms of the GNU
* General Public License as published by the Free Software Foundation, version 2 of the License.

* The Danish language package is distributed in the hope that it will be useful, but WITHOUT ANY
* WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
* A PARTICULAR PURPOSE. See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this language
* package. If not, see <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>.
*
*/

$danish = array(

/**
 * Menu items and titles
 */

	'messages' => "Beskeder",
	'messages:back' => "Tilbage til beskeder",
	'messages:user' => "Din indbakke",
	'messages:sentMessages' => "Sendte beskeder",
	'messages:posttitle' => "%s's beskeder: %s",
	'messages:inbox' => "Indbakke",
	'messages:send' => "Send en besked",
	'messages:sent' => "Sendte beskeder",
	'messages:message' => "Besked",
	'messages:title' => "Titel",
	'messages:to' => "Til",
	'messages:from' => "Fra",
	'messages:fly' => "Send",
	'messages:replying' => "Besked som svar til",
	'messages:inbox' => "Indbakke",
	'messages:sendmessage' => "Send en besked",
	'messages:compose' => "Opret en besked",
	'messages:sentmessages' => "Sendte beskeder",
	'messages:recent' => "Seneste beskeder",
	'messages:original' => "Original besked",
	'messages:yours' => "Din besked",
	'messages:answer' => "Svar",
	'messages:toggle' => 'Marker alle',
	'messages:markread' => 'Marker som læst',
	
	'messages:new' => 'Ny besked',

	'notification:method:site' => 'Site',

	'messages:error' => 'Der opstod et problem med at gemme din besked. Prøv venligst igen.',

	'item:object:messages' => 'Beskeder',

/**
 * Status messages
 */

	'messages:posted' => "Din besked blev sendt.",
	'messages:deleted' => "Din besked blev slettet.",
	'messages:markedread' => "Dine beskeder blev markeret som læst.",

/**
 * Email messages
 */

	'messages:email:subject' => 'Du har en ny besked!',
	'messages:email:body' => "Du har en ny besked fra %s. Den lyder:

	
%s


Klik her for at se dine beskeder:

%s

Klik her for at sende %s en besked:

%s

Du kan ikke svare via denne mail.",

/**
 * Error messages
 */

	'messages:blank' => "Beklager, du skal skrive noget i beskedfeltet før den kan gemmes.",
	'messages:notfound' => "Beklager, vi kunne ikke finde den specificerede besked.",
	'messages:notdeleted' => "Beklager, beskeden kunne ikke slettes.",
	'messages:nopermission' => "Du har ikke tilladelse til at ændre den besked.",
	'messages:nomessages' => "Der er ingen beskeder at vise.",
	'messages:user:nonexist' => "Modtageren kunne ikke findes i databasen.",
	'messages:user:blank' => "Du har ikke valgt nogen at sende til.",

);

add_translation("da",$danish);

?>