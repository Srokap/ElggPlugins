<?php
/*
*
* Elgg groups plugin [Danish]
*
* @package language
* @version Id: da.php 2010-06-01
* @source file is Copyright (c) 2008-2010 Curverider Ltd
* @modified and translated by elggzone.com
* @link http://www.elggzone.com
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
*
* This file is part of the Danish language package for Elgg 1.7.1
* Copyright (c) 2010 elggzone.com
*
* The package is free software; you can redistribute it and/or modify it under the terms of the GNU
* General Public License as published by the Free Software Foundation, version 2 of the License.

* The Danish language package is distributed in the hope that it will be useful, but WITHOUT ANY
* WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
* A PARTICULAR PURPOSE. See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this language
* package. If not, see <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>.
*
*/

$danish = array(

/**
 * twitter widget details
 */
	
	
	'twitter:username' => 'Skriv dit twitter brugernavn.',
	'twitter:num' => 'Antal tweets du vil vise.',
	'twitter:visit' => 'besøg mig på twitter',
	'twitter:notset' => 'Denne twitter widget er ikke indstillet endnu. Klik på \'rediger\' og udfyld dine detaljer, for at vise dine seneste tweets.',
	
	
 /**
 * twitter widget river
 **/
		
	//generic terms to use
	'twitter:river:created' => "%s tilføjede twitter widget.",
	'twitter:river:updated' => "%s opdaterede sin twitter widget.",
	'twitter:river:delete' => "%s fjernede sin twitter widget.",
	
);
				
add_translation('da',$danish);

?>