<?php
/*
*
* The Wire [Danish]
*
* @package language
* @version Id: da.php 2010-06-01
* @source file is Copyright (c) 2008-2010 Curverider Ltd
* @modified and translated by elggzone.com
* @link http://www.elggzone.com
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
*
* This file is part of the Danish language package for Elgg 1.7.1
* Copyright (c) 2010 elggzone.com
*
* The package is free software; you can redistribute it and/or modify it under the terms of the GNU
* General Public License as published by the Free Software Foundation, version 2 of the License.

* The Danish language package is distributed in the hope that it will be useful, but WITHOUT ANY
* WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
* A PARTICULAR PURPOSE. See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this language
* package. If not, see <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>.
*
*/

$danish = array(

/**
 * Menu items and titles
 */

	'thewire' => "The wire",
	'thewire:user' => "%s's wire",
	'thewire:posttitle' => "%s's tweets på the wire: %s",
	'thewire:everyone' => "Alle wire tweets",

	'thewire:read' => "Mine Wire tweets",
	
	'thewire:strapline' => "%s",

	'thewire:add' => "Skriv på the wire",
	'thewire:text' => "Et tweet på the wire",
	'thewire:reply' => "Svar",
	'thewire:via' => "via",
	'thewire:wired' => "Postet til the wire",
	'thewire:charleft' => "karakterer tilbage",
	'item:object:thewire' => "Wire tweets",
	'thewire:notedeleted' => "tweet slettet",
	'thewire:doing' => "Hvad laver du? Skriv til alle på the wire:",
	'thewire:newpost' => 'Ny wire tekst',
	'thewire:addpost' => 'Skriv til the wire',


/**
 * The wire river
 **/
	
	//generic terms to use
	'thewire:river:created' => "%s postet",
	
	//these get inserted into the river links to take the user to the entity
	'thewire:river:create' => "på the wire.",
	
/**
 * Wire widget
 **/
 
	'thewire:sitedesc' => 'Denne widget viser de seneste tweets på the wire',
	'thewire:yourdesc' => 'Denne widget viser dine seneste tweets på the wire',
	'thewire:friendsdesc' => 'Denne widget viser de seneste tweets fra dine venner på the wire',
	'thewire:friends' => 'Dine venner på the wire',
	'thewire:num' => 'Antal tweets der skal vises',
	
	

/**
 * Status messages
 */

	'thewire:posted' => "Dit tweet blev postet til the wire.",
	'thewire:deleted' => "Dit wire tweet er blevet slettet.",

/**
 * Error messages
 */

	'thewire:blank' => "Beklager, du skal skrive noget i tekstboksen før det kan gemmes.",
	'thewire:notfound' => "Beklager, vi kunne ikke finde det specificerede wire tweet.",
	'thewire:notdeleted' => "Beklager, vi kkunne ikke slette dette wire tweet.",


/**
 * Settings
 */
	'thewire:smsnumber' => "Dit SMS nummer er forskelligt fra dit mobilnummer (mobilnummer skal instilles til 'offentlig' for at the wire kan bruge det). Alle telefonnumre skal være i internationalt format.",
	'thewire:channelsms' => "Nummeret der skal sendes sms beskeder til er <b>%s</b>",
		
);
				
add_translation('da',$danish);

?>