<?php
/*
*
* Elgg pages plugin [Danish]
*
* @package language
* @version Id: da.php 2010-06-01
* @source file is Copyright (c) 2008-2010 Curverider Ltd
* @modified and translated by elggzone.com
* @link http://www.elggzone.com
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
*
* This file is part of the Danish language package for Elgg 1.7.1
* Copyright (c) 2010 elggzone.com
*
* The package is free software; you can redistribute it and/or modify it under the terms of the GNU
* General Public License as published by the Free Software Foundation, version 2 of the License.

* The Danish language package is distributed in the hope that it will be useful, but WITHOUT ANY
* WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
* A PARTICULAR PURPOSE. See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this language
* package. If not, see <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>.
*
*/
	 
$danish = array(

/**
 * Menu items and titles
 */ 

	'pages'  =>  "Sider" , 
	'pages:yours'  =>  "Dine sider" , 
	'pages:user'  =>  "Sider hjem" , 
	'pages:group'  =>  "%ss sider" , 
	'pages:all'  =>  "Alle sidens sider" , 
	'pages:new'  =>  "Ny side" , 
	'pages:groupprofile'  =>  "Gruppesider" , 
	'pages:edit'  =>  "Rediger denne side" , 
	'pages:delete'  =>  "Slet denne side" , 
	'pages:history'  =>  "Sidehistorik" ,	
	'pages:view'  =>  "Se side" , 
	'pages:welcome'  =>  "Rediger velkomstbesked" ,
	'pages:welcomemessage' => "Velkommen til denne Elgg side plugin. Denne funktion gør det muligt at oprette sider med et hvilket som helst indhold og vælge hvem der kan se dem og redigere dem.",
	'pages:welcomeerror' => "Der opstod et problem med at gemme din velkomstbesked",
	'pages:welcomeposted' => "Din velkomsbesked er blevet postet", 
	'pages:navigation'  =>  "Navigation på siden" ,
	'pages:via' => "via sider", 
	'item:object:page_top'  =>  "Top-niveau sider" , 
	'item:object:page'  =>  "Sider" , 
	'item:object:pages_welcome'  =>  "Sider velkomst blokke" ,
	'pages:nogroup' => 'Denne gruppe har ikke nogen sider endnu',
	'pages:more' => 'Flere sider',
	
	/**
	* River
	**/

	'pages:river:annotate' => "en kommentar til denne side",
	'pages:river:created' => "%s skrev",
	'pages:river:updated' => "%s opdaterede",
	'pages:river:posted' => "%s skrev",
	'pages:river:create' => "en ny side kaldt",
	'pages:river:update' => "en side kaldt",
	'page:river:annotate' => "en kommentar til siden",
	'page_top:river:annotate' => "en kommentar til denne side",

	/**
	 * Form fields
	 */

	'pages:title' => 'Sidetitler',
	'pages:description' => 'Dit side indhold',
	'pages:tags' => 'Tags',	
	'pages:access_id' => 'Adgang',
	'pages:write_access_id' => 'Skriveadgang',

/**
 * Status and error messages
 */
	  
	'pages:noaccess'  =>  "Igen adgang til side" , 
	'pages:cantedit'  =>  "Du kan ikke redigere denne side" , 
	'pages:saved'  =>  "Sider gemt" , 
	'pages:notsaved'  =>  "Side kunne ikke gemmes" , 
	'pages:notitle'  =>  "Din side skal have en titel." , 
	'pages:delete:success'  =>  "Din side er blevet slettet" , 
	'pages:delete:failure'  =>  "Siden kunne ikke slettes." , 

/**
 * Page
 */
	 	
	'pages:strapline'  =>  "Sidst opdateret %s af %s" ,
	
/**
 * History
 */
	  
	'pages:revision'  =>  "Revision lavet %s af %s" ,
	
/**
 * Widget
 **/
	  
	'pages:num'  =>  "Antal viste sider" ,
	'pages:widget:description' => "Dette er en liste med dine sider.",
	
/**
 * Submenu items
 */
			 
	'pages:label:view'  =>  "Se side" , 
	'pages:label:edit'  =>  "Rediger side" , 
	'pages:label:history'  =>  "Sidehistorik" ,
	
/**
 * Sidebar items
 */
	  
	'pages:sidebar:this'  =>  "Denne side" , 
	'pages:sidebar:children'  =>  "Undersider" , 
	'pages:sidebar:parent'  =>  "Forælder" ,
	 
	'pages:newchild'  =>  "Lav en underside" ,	
	'pages:backtoparent'  =>  "Tilbage til '%s'"	  
);

add_translation("da",$danish);

?>