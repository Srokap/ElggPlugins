<?php
/*
*
* Email user validation plugin [Danish]
*
* @package language
* @version Id: da.php 2010-06-01
* @source file is Copyright (c) 2008-2010 Curverider Ltd
* @modified and translated by elggzone.com
* @link http://www.elggzone.com
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
*
* This file is part of the Danish language package for Elgg 1.7.1
* Copyright (c) 2010 elggzone.com
*
* The package is free software; you can redistribute it and/or modify it under the terms of the GNU
* General Public License as published by the Free Software Foundation, version 2 of the License.

* The Danish language package is distributed in the hope that it will be useful, but WITHOUT ANY
* WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
* A PARTICULAR PURPOSE. See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this language
* package. If not, see <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>.
*
*/

$danish = array(

	'email:validate:subject' => "%s vær venlig at bekræfte din email adresse!",
	'email:validate:body' => "Hej %s,

Vær venlig at bekræfte din email adresse ved at klikke på linket herunder:

%s
",
	'email:validate:success:subject' => "Email godkendt %s!",
	'email:validate:success:body' => "Hej %s,
		
Du har godkendt din email adresse, tak.",

	
	'email:confirm:success' => "Du har bekræftet din email adresse!",
	'email:confirm:fail' => "Din email adresse kunne ikke bekræftes...",

	'uservalidationbyemail:registerok' => "Aktiver venligst din konto ved at bekræfte din email adresse i det link vi lige har sendt til dig."

);
				
add_translation("da",$danish);
	
?>