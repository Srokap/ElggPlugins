<?php
/*
*
* Elgg profile plugin [Danish]
*
* @package language
* @version Id: da.php 2010-06-01
* @source file is Copyright (c) 2008-2010 Curverider Ltd
* @modified and translated by elggzone.com
* @link http://www.elggzone.com
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
*
* This file is part of the Danish language package for Elgg 1.7.1
* Copyright (c) 2010 elggzone.com
*
* The package is free software; you can redistribute it and/or modify it under the terms of the GNU
* General Public License as published by the Free Software Foundation, version 2 of the License.

* The Danish language package is distributed in the hope that it will be useful, but WITHOUT ANY
* WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
* A PARTICULAR PURPOSE. See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this language
* package. If not, see <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>.
*
*/

$danish = array(

/**
 * Profile
 */

	'profile' => "Profil",
	'profile:edit:default' => 'Erstat profilfelter',
	'profile:preview' => 'Smugkig',

/**
 * Profile menu items and titles
 */

	'profile:yours' => "Din profil",
	'profile:user' => "%s's profil",

	'profile:edit' => "Rediger profil",
	'profile:profilepictureinstructions' => "Profilbilledet er det billede, der vises på din profilside. <br /> Du kan ændre det, så tit du vil. (Understøttede filformater: GIF, JPG eller PNG)",
	'profile:icon' => "Profilbillede",
	'profile:createicon' => "Opret avatar",
	'profile:currentavatar' => "Nuværende avatar",
	'profile:createicon:header' => "Profilbillede",
	'profile:profilepicturecroppingtool' => "Profilbillede til avatar - Beskæringsværktøj",
	'profile:createicon:instructions' => "Klik og træk et kvadrat herunder som passer med, hvordan du vil have dit billede beskåret.  Et smugkig af dit beskårne billede vises i boksen til højre. Når du er tilfreds klikker du 'Opret avatar'. Billedet vil blive brugt over hele siden som din avatar. ",

	'profile:editdetails' => "Rediger detaljer",
	'profile:editicon' => "Rediger profilbillede",

	'profile:aboutme' => "Om mig",
	'profile:description' => "Om mig",
	'profile:briefdescription' => "Kort beskrivelse",
	'profile:location' => "Sted",
	'profile:skills' => "Færdigheder",
	'profile:interests' => "Interesser",
	'profile:contactemail' => "Kontakt mail",
	'profile:phone' => "Telefon",
	'profile:mobile' => "Mobil",
	'profile:website' => "Website",

	'profile:banned' => 'Denne brugerkonto er blevet suspenderet.',
	'profile:deleteduser' => 'Slet medlem',

	'profile:river:update' => "%s opdaterede sin profil",
	'profile:river:iconupdate' => "%s opdaterede sit profilbillede",

	'profile:label' => "Navn",
	'profile:type' => "Felttype",

	'profile:editdefault:fail' => 'Standard profil kunne ikke gemmes',
	'profile:editdefault:success' => 'Emne tilføjet standard profil',


	'profile:editdefault:delete:fail' => 'Emne kunne ikke fjernes fra standard profil!',
	'profile:editdefault:delete:success' => 'Emne fjernet fra standard profil!',

	'profile:defaultprofile:reset' => 'Standard profil genoprettet.',

	'profile:resetdefault' => 'Genopret standard profil',
	'profile:explainchangefields' => 'Du kan erstatte de eksisterende profilfelter med dine egne ved at bruge formularen herunder. Først giver du profilfeltet et navn, f.eks. \'Favorit hold\'. Derefter vælger du en felttype, f.eks. tags, url, tekst og så videre. Du kan til enhver tid vende tilbage til standard profilopsætningen.',


/**
 * Profile status messages
 */

	'profile:saved' => "Din profil blev gemt.",
	'profile:icon:uploaded' => "Dit profilbillede blev uploaded.",

/**
 * Profile error messages
 */

	'profile:noaccess' => "Du har ikke tilladelse til at redigere denne profil.",
	'profile:notfound' => "Beklager, vi kunne ikke finde den specificerede profil.",
	'profile:icon:notfound' => "Beklager, der opstod et problem med uploadning af dit profilbillede.",
	'profile:icon:noaccess' => 'Du kan ikke ændre dette profilbillede',
	'profile:field_too_long' => 'Kan ikke gemme dine profil oplysninger da "%s" delen er for lang.',

);

add_translation("da",$danish);

?>