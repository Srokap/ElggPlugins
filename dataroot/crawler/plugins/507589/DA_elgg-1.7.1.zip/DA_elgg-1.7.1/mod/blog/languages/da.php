<?php
/*
*
* Elgg Blog [Danish]
*
* @package language
* @version Id: da.php 2010-06-01
* @source file is Copyright (c) 2008-2010 Curverider Ltd
* @modified and translated by elggzone.com
* @link http://www.elggzone.com
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
*
* This file is part of the Danish language package for Elgg 1.7.1
* Copyright (c) 2010 elggzone.com
*
* The package is free software; you can redistribute it and/or modify it under the terms of the GNU
* General Public License as published by the Free Software Foundation, version 2 of the License.

* The Danish language package is distributed in the hope that it will be useful, but WITHOUT ANY
* WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
* A PARTICULAR PURPOSE. See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this language
* package. If not, see <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>.
*
*/

$danish = array(

	/**
	 * Menu items and titles
	 */

	'blog'  =>  'Blog', 
	'blogs'  =>  'Bloggge', 
	'blog:user'  =>  '%ss blog', 
	'blog:user:friends'  =>  '%ss venners blog', 
	'blog:your'  =>  'Din blog' , 
	'blog:posttitle'  =>  '%ss blog: %s', 
	'blog:friends'  =>  'Venners blogge', 
	'blog:yourfriends'  =>  'Dine venners seneste blogge', 
	'blog:everyone'  =>  'Alle sidens blogge', 
	'blog:newpost' => "New blog post",
	'blog:via' => "via blog",
	'blog:read'  =>  'Læs blog',
	 
	'blog:addpost'  =>  'Skriv et blogindlæg', 
	'blog:editpost'  =>  'Rediger blogindlæg', 
	
	'blog:text'  =>  'Blogtekst',
	 
	'blog:strapline'  =>  '%s' , 
	'item:object:blog'  =>  'Blogindlæg',
	
	'blog:never' => 'aldrig',
	'blog:preview' => 'Vis prøve',

	'blog:draft:save' => 'Gem kladde',
	'blog:draft:saved' => 'Kladde gemt',
	'blog:comments:allow' => 'Tillad kommentarer', 
	
	'blog:preview:description' => 'Dette er en prøve af dit blogindlæg, det er ikke gemt.',
	'blog:preview:description:link' => 'For at fortsætte med at redigere eller gemme dit indlæg, klik her.',
	
	'blog:enableblog' => 'Aktiver gruppe blog',
	
	'blog:group' => 'Gruppe blog',
	
/**
* Blog river
**/
 
	//generic terms to use
 	'blog:river:created'  =>  '%s skrev', 
	'blog:river:updated'  =>  '%s opdateret', 
	'blog:river:posted'  =>  '%s udsendte',
	
	//these get inserted into the river links to take the user to the entity 
	'blog:river:create'  =>  'et nyt blogindlæg.', 
	'blog:river:update'  =>  'et blogindlæg.', 
	'blog:river:annotate'  =>  'en kommentar til et blogindlæg.',
	
/**
* Status messages
*/

	'blog:posted'  =>  'Dit blogindlæg er blevet udgivet.', 
	'blog:deleted'  =>  'Dit blogindlæg er blevet slettet.',
	
/**
* Error messages
*/

	'blog:error' => 'Noget gik galt. Prøv venligst igen.',	 
	'blog:save:failure'  =>  'Dit blogindlæg kunne ikke gemmes. Prøv venligst igen.', 
	'blog:blank'  =>  'Beklager, du er nødt til at udfylde både titel og tekst, før du kan lave et indlæg.', 
	'blog:notfound'  =>  'Beklager, vi kunne ikke finde det specificerede blogindlæg.', 
	'blog:notdeleted'  =>  'Beklager, vi kunne ikke slette dette blogindlæg.'

);

add_translation('da',$danish);

?>