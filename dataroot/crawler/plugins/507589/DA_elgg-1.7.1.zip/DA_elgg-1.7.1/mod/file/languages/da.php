<?php
/*
*
* Elgg file plugin [Danish]
*
* @package language
* @version Id: da.php 2010-06-01
* @source file is Copyright (c) 2008-2010 Curverider Ltd
* @modified and translated by elggzone.com
* @link http://www.elggzone.com
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
*
* This file is part of the Danish language package for Elgg 1.7.1
* Copyright (c) 2010 elggzone.com
*
* The package is free software; you can redistribute it and/or modify it under the terms of the GNU
* General Public License as published by the Free Software Foundation, version 2 of the License.

* The Danish language package is distributed in the hope that it will be useful, but WITHOUT ANY
* WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
* A PARTICULAR PURPOSE. See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this language
* package. If not, see <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>.
*
*/

$danish = array(

/**
 * Menu items and titles
 */ 

	'file' => "Filer", 
	'files' => "Filer", 
	'file:yours' => "Dine filer", 
	'file:yours:friends' => "Dine venners filer", 
	'file:user' => "%ss filer", 
	'file:friends' => "%ss venners filer", 
	'file:all' => "Alle filer", 
	'file:edit' => "Rediger fil", 
	'file:more' => "flere filer", 
	'file:list' => "se på liste", 
	
	'file:group' => "Gruppe filer", 
	'file:gallery' => "se i galleri", 
	'file:gallery_list' => "Se i liste eller galleri", 
	'file:num_files' => "Antal viste filer", 
	'file:user:gallery' => "Se %s galleri",
	'file:via' => 'via filer',
	'file:upload' => "Upload en fil",
	'file:replace' => 'Erstat fil indhold (lad være tom for ikke at ændre i fil)',
	
	'file:newupload' => 'Ny fil upload',
		 
	'file:file' => "Fil", 
	'file:title' => "Titel", 
	'file:desc' => "Beskrivelse", 
	'file:tags' => "Tags", 
	
	'file:types' => "Uploadede filtyper",
	 
	'file:type:all' => "Alle filer", 
	'file:type:video' => "Videoer", 
	'file:type:document' => "Dokumenter", 
	'file:type:audio' => "Lyd", 
	'file:type:image' => "Billeder", 
	'file:type:general' => "Generelt",
	 
	'file:user:type:video' => "%ss videoer", 
	'file:user:type:document' => "%ss dokumenter", 
	'file:user:type:audio' => "%ss lyd",	
	'file:user:type:image' => "%ss billeder", 
	'file:user:type:general' => "%ss generelle filer",
	 
	'file:friends:type:video' => "Dine venners videoer", 
	'file:friends:type:document' => "Dine venners dokumenter", 
	'file:friends:type:audio' => "Dine venners lyd", 
	'file:friends:type:image' => "Dine venners billeder", 
	'file:friends:type:general' => "Dine venners generelle filer",
	
	'file:widget' => "Fil widget", 
	'file:widget:description' => "Fremvis dine seneste filer",
	 
	'file:download' => "Hent dette", 
	
	'file:delete:confirm' => "Er du sikker på du vil slette denne fil?",
	 
	'file:tagcloud' => "Tag sky",
	 
	'file:display:number' => "Antal viste filer",
	 
	'file:river:created' => "%s uploadede", 
	'file:river:item' => "filen", 
	'file:river:annotate' => "%s kommenterede",
	 
	'item:object:file' => "Filer",
	
/**
* Embed media
**/
  
	'file:embed' => "Indflet medie", 
	'file:embedall' => "Alle", 
	
/**
* Status messages
*/
 
	'file:saved' => "Din fil blev gemt.", 	
	'file:deleted' => "Din fil blev slettet.",
	
/**
* Error messages
*/
  
	'file:none' => "Vi kan ikke finde nogle filer i øjeblikket", 
	'file:uploadfailed' => "Beklager, vi kunne ikke gemme din fil.", 
	'file:downloadfailed' => "Beklager, denne fil er ikke til rådighed lige nu.", 
	'file:deletefailed' => "Din fil kunne ikke slettes.",
	'file:noaccess' => "Du har ikke tilladelse ti at ændre denne fil",
	'file:cannotload' => "Der opstod en fejl med at loade filen",
	'file:nofile' => "Du skal vælge en fil",
	
);

add_translation('da',$danish);

?>