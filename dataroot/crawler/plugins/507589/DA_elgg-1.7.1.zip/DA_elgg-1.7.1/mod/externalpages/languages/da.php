<?php
/*
*
* External pages [Danish]
*
* @package language
* @version Id: da.php 2010-06-01
* @source file is Copyright (c) 2008-2010 Curverider Ltd
* @modified and translated by elggzone.com
* @link http://www.elggzone.com
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
*
* This file is part of the Danish language package for Elgg 1.7.1
* Copyright (c) 2010 elggzone.com
*
* The package is free software; you can redistribute it and/or modify it under the terms of the GNU
* General Public License as published by the Free Software Foundation, version 2 of the License.

* The Danish language package is distributed in the hope that it will be useful, but WITHOUT ANY
* WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
* A PARTICULAR PURPOSE. See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this language
* package. If not, see <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>.
*
*/

$danish = array(

/**
* Menu items and titles
*/

	'expages' => "Eksterne sider",
	'expages:frontpage' => "Forside",
	'expages:about' => "Om",
	'expages:terms' => "Betingelser",
	'expages:privacy' => "Beskyttelse af personlige oplysninger",
	'expages:analytics' => "Analyser",
	'expages:contact' => "Kontakt",
	'expages:nopreview' => "Ingen pr�ve tilg�ngelig",
	'expages:preview' => "Vis pr�ve",
	'expages:notset' => "Denne side er ikke sat op endnu.",
	'expages:lefthand' => "Venstre informations rude",
	'expages:righthand' => "H�jre informations rude",
	'expages:addcontent' => "Du kan ikke tilf�je indhold via dit administrationsv�rkt�j. Se efter linket \'Eksterne sider\' i menuen under administration.",
	'item:object:front' => 'Forside poster',

/**
* Status messages
*/

	'expages:posted' => "Dit indl�g til siden er blevet sendt korrekt.",
	'expages:deleted' => "Dit indl�g til siden er blevet slettet korrekt.",

/**
* Error messages
*/

	'expages:deleteerror' => "Der opstod et problem med at slette den gamle side",
	'expages:error' => "Der har v�ret en fejl, v�r venlig at pr�ve igen og kontakt administrationen hvis problemet forts�tter",		
	
);
				
add_translation('da',$danish);

?>
