<?php
/*
 * Activity viewer
 *
 * @package Elgg
 * @subpackage Core
 * @author Curverider Ltd
 * @link http://elgg.org/
 */
 
/*
*
* common [Danish]
*
* @package language
* @version Id: da.php 2010-06-01
* @source file is Copyright (c) 2008-2010 Curverider Ltd
* @modified and translated by elggzone.com
* @link http://www.elggzone.com
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
*
* This file is part of the Danish language package for Elgg 1.7.1
* Copyright (c) 2010 elggzone.com
*
* The package is free software; you can redistribute it and/or modify it under the terms of the GNU
* General Public License as published by the Free Software Foundation, version 2 of the License.

* The Danish language package is distributed in the hope that it will be useful, but WITHOUT ANY
* WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
* A PARTICULAR PURPOSE. See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this language
* package. If not, see <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>.
*
*/

$danish = array( 

/**
 * Sites
 */
 
      'item:site'  =>  "Sider",

/**
 * Sessions
 */
 
      'login'  =>  "Log ind", 
      'loginok'  =>  "Du er blevet logget ind.", 
      'loginerror'  =>  "Vi kunne ikke logge dig ind. Dette kan være fordi du ikke har valideret din konto endnu eller fordi de detaljer du angav er forkerte. Undersøg om detaljerne er korrekte, og prøv venligst igen.",
	   
      'logout'  =>  "Log ud", 
      'logoutok'  =>  "Du er blevet logget ud.", 
      'logouterror'  =>  "Vi kunne ikke logge dig ud. Prøv venligst igen.",
	  
	  'loggedinrequired' => "Du skal være logget ind for at se den side.",
	  'adminrequired' => "Du skal være administrator for at se den side.",
	  'membershiprequired' => "Du skal være medlem af gruppen for at se siden.",
	
/**
 * Errors
 */ 
      'exception:title'  =>  "Velkommen til Elgg.",
	  
      'InstallationException:CantCreateSite'  =>  "Ude af stand til at lave standard ElggSite med egenskaberne Navn:%s, Url: %s",
	  
      'actionundefined'  =>  "Den de handling (%s) var ikke defineret i systemet.", 	  
      'actionloggedout'  =>  "Beklager, du kan ikke udføre denne handling når du er logget ud.",
	  
      'SecurityException:Codeblock'  =>  "Adgang nægtet til at eksekvere privilegeret kodeblok", 
      'DatabaseException:WrongCredentials'  =>  "Elg kunne ikke oprette forbindelse til databasen med egenskaberne %s@%s (pw: %s).", 
      'DatabaseException:NoConnect'  =>  "Elgg kunne ikke vælge databasen '%s', undersøg venligst om databasen er oprettet, og at du har adgang til den.", 
      'SecurityException:FunctionDenied'  =>  "Adgang til priviligeret funktion '%s' nægtet.", 
      'DatabaseException:DBSetupIssues'  =>  "Der var følgende problemer: ", 
      'DatabaseException:ScriptNotFound'  =>  "Elgg kunne ikke finde det efterspurgte database script på %s.", 

      'IOException:FailedToLoadGUID'  =>  "Hentning af ny %s fra GUID:%d mislykkedes", 
      'InvalidParameterException:NonElggObject'  =>  "Sendte et ikke-ElggObject til en ElggObject konstruktør!", 
      'InvalidParameterException:UnrecognisedValue'  =>  "Ukendt værdi sendt til konsruktør",	  
      'InvalidClassException:NotValidElggStar'  =>  "GUID:%d er ikke en gyldig %s", 
      'PluginException:MisconfiguredPlugin'  =>  "%s er et forkert opsat plugin. Den er blevet deaktiveret. Se venligst Elgg wiki for mulige årsager.",
      'InvalidParameterException:NonElggUser'  =>  "Sendte en ikke-ElggUser til en ElggUser konstruktør!", 
      'InvalidParameterException:NonElggSite'  =>  "Sendte en ikke-ElggSite til en ElggSite konsturktør!", 
      'InvalidParameterException:NonElggGroup'  =>  "Sendte en ikke-ElggGroup til en ElggGroup konstruktør!", 
      'IOException:UnableToSaveNew'  =>  "Ikke i stand til at gemme ny %s", 
      'InvalidParameterException:GUIDNotForExport'  =>  "GUID er ikke blevet specificeret under eksport. Dette burde aldrig ske.", 
      'InvalidParameterException:NonArrayReturnValue' =>  "Enhedsserialisations funktion afviklede et non-array returnvalue parameter", 
      'ConfigurationException:NoCachePath'  =>  "Cache sti sat til intet!", 
      'IOException:NotDirectory'  =>  "%s er ikke en folder.", 
      'IOException:BaseEntitySaveFailed'  =>  "Ude af i stand til at gemme den nye enheds grundinformation!", 
      'InvalidParameterException:UnexpectedODDClass'  =>  "import() afviklede en uventet ODD class", 
      'InvalidParameterException:EntityTypeNotSet'  =>  "Enhedstype skal vælges.", 
      'ClassException:ClassnameNotClass'  =>  "%s er ikke en %s.", 
      'ClassNotFoundException:MissingClass'  =>  "Klassen '%s' blev ikke fundet, mangler der et plugin?", 
      'InstallationException:TypeNotSupported'  =>  "Type %s er ikke understøttet. Det indikerer en fejl ved din installation, sandsynligvis skabt af en ufærdig opdatering.", 
      'ImportException:ImportFailed'  =>  "Kunne ikke importere elementet %d",
      'ImportException:ProblemSaving'  =>  "Der var et problem med at gemme %s", 
      'ImportException:NoGUID'  =>  "Ny enhed oprettet uden GUID. Dette burde ikke ske.",
	   
      'ImportException:GUIDNotFound'  =>  "Enhed '%d' blev ikke fundet.", 
      'ImportException:ProblemUpdatingMeta'  =>  "Der var et problem med at opdatere '%s' på enhed '%d'", 
      'ExportException:NoSuchEntity'  =>  "Enheds GUID:%d findes ikke.", 
      'ImportException:NoODDElements'  =>  "Ingen OpenDD elementer fundet i import data, import mislykkedes.", 
      'ImportException:NotAllImported'  =>  "Ikke alle elementer blev importeret.",
	   
      'InvalidParameterException:UnrecognisedFileMode'  =>  "Ukendt fil mode '%s'", 
      'InvalidParameterException:MissingOwner'  =>  "Alle filer skal have en ejer!", 
      'IOException:CouldNotMake'  =>  "Kunne ikke lave %s",
      'IOException:MissingFileName'  =>  "Du skal angive et navn for at åbne en fil.", 
      'ClassNotFoundException:NotFoundNotSavedWithFile'  =>  "Filestore ikke fundet, eller klasse ikke gemt med fil!", 
      'NotificationException:NoNotificationMethod'  =>  "Ingen metode er angivet for påmindelser.", 
      'NotificationException:NoHandlerFound'  =>  "Ingen handler fundet til '%s' eller det kunne ikke kaldes.", 
      'NotificationException:ErrorNotifyingGuid'  =>  "Der var en fejl med at informere %d", 
      'NotificationException:NoEmailAddress'  =>  "Kunne ikke finde email adresse til GUID:%d", 
      'NotificationException:MissingParameter'  =>  "Mangler et krævet parameter, '%s'",
	   
      'DatabaseException:WhereSetNonQuery'  =>  "Where set indefolder ikke-WhereQueryComponent",	   
      'DatabaseException:SelectFieldsMissing'  =>  "Manglende felter på et select style query", 
      'DatabaseException:UnspecifiedQueryType'  =>  "Ukendt eller uspecificeret spørgetype.", 
      'DatabaseException:NoTablesSpecified'  =>  "Ingen tabeller specificeret for forespørgsel.", 
      'DatabaseException:NoACL'  =>  "Ingen adgangskontrol tilgængelig på forespørgsel", 
	  
      'InvalidParameterException:NoEntityFound'  =>  "Ingen enhed fundet, enten findes den ikke eller du har ikke adgang til den.",
	   
      'InvalidParameterException:GUIDNotFound'  =>  "GUID:%s kunne ikke findes, eller du kunne ikke få adgang til den.", 
      'InvalidParameterException:IdNotExistForGUID'  =>  "Beklager, '%s' findes ikke med guid:%d", 
      'InvalidParameterException:CanNotExportType'  =>  "Beklager, jeg ved ikke hvordan man eksporterer '%s'", 
      'InvalidParameterException:NoDataFound'  =>  "Kunne ikke finde nogen data.", 
      'InvalidParameterException:DoesNotBelong'  =>  "Passer ikke med enhed.", 
      'InvalidParameterException:DoesNotBelongOrRefer'  =>  "Passer ikke med enhen eller refererer ikke til enhed.", 
      'InvalidParameterException:MissingParameter'  =>  "Manglende parameter, du skal give en GUID.", 

      'APIException:ApiResultUnknown'  =>  "API resultat er af en ukendt type. Dette skulle aldrig ske.",
      'ConfigurationException:NoSiteID'  =>  "Ingen side ID specificeret.",
      'SecurityException:APIAccessDenied'  =>  "Beklager, API adgang er slået fra af administratoren.", 
      'SecurityException:NoAuthMethods'  =>  "Ingen autentificeringsmetoder metoder fundet til at autentificering API .", 
	  'InvalidParameterException:APIMethodOrFunctionNotSet' => "Method or function not set in call in expose_method()", 
	  'InvalidParameterException:APIParametersArrayStructure' => "Parameter array strukturen er ukorrekt til at eksponere metoden '%s'",	  
	  'InvalidParameterException:UnrecognisedHttpMethod' => "Unrecognised http method %s for api method '%s'",
      'APIException:MissingParameterInMethod'  =>  "Manglende parameter %s i metode %s", 
      'APIException:ParameterNotArray'  =>  "%s ser ikke ud til at være en array", 
      'APIException:UnrecognisedTypeCast'  =>  "Ukendt type i cast %s for variabel '%s' i metode '%s'", 
      'APIException:InvalidParameter'  =>  "Forkert parameter fundet for '%s' i metode '%s'.", 
      'APIException:FunctionParseError'  =>  "%s(%s) har en parsing fejl.",
      'APIException:FunctionNoReturn'  =>  "%s(%s) returnerede ingen værdi",
	  'APIException:APIAuthenticationFailed' => "Method call failed the API Authentication",
	  'APIException:UserAuthenticationFailed' => "Method call failed the User Authentication", 
      'SecurityException:AuthTokenExpired'  =>  "Autentificerings token enten mangler, er forkert eller er udløbet.", 
      'CallException:InvalidCallMethod'  =>  "%s skal kaldes med '%s'", 
      'APIException:MethodCallNotImplemented'  =>  "Medtodekald '%s' er ikke implementeret",
	  'APIException:FunctionDoesNotExist' => "Function for method '%s' is not callable", 
      'APIException:AlgorithmNotSupported'  =>  "Algoritme '%s' er ikke understøttet, eller er blevet slået fra.", 
      'ConfigurationException:CacheDirNotSet'  =>  "Cache mappe 'cache_path' ikke opsat.", 
      'APIException:NotGetOrPost'  =>  "Forespørgselsmethod skal være GET eller POST", 
      'APIException:MissingAPIKey'  =>  "Manglende X-Elgg-apikey HTTP header",
	  'APIException:BadAPIKey' => "Bad API key", 
      'APIException:MissingHmac'  =>  "Manglende X-Elgg-hmac header", 
      'APIException:MissingHmacAlgo'  =>  "Manglende X-Elgg-hmac-algo header",
      'APIException:MissingTime'  =>  "Manglende X-Elgg-time header",
	  'APIException:MissingNonce' => "Missing X-Elgg-nonce header", 
      'APIException:TemporalDrift'  =>  "X-Elgg-time er for langt tilbage i fortiden eller inde i fremtiden. Epoch fail!", 
      'APIException:NoQueryString'  =>  "Ingen stat på forespørsels streng", 
      'APIException:MissingPOSTHash'  =>  "Manglende X-Elgg-posthash header", 
      'APIException:MissingPOSTAlgo'  =>  "Manglende X-Elgg-posthash_algo header",	   
      'APIException:MissingContentType'  =>  "Manglende indholdstype for post data", 
      'SecurityException:InvalidPostHash'  =>  "POST data hash forkert - Forventede %s men fik %s.", 
      'SecurityException:DupePacket'  =>  "Pakkesignatur allerede set.", 
      'SecurityException:InvalidAPIKey'  =>  "Forkert eller manglende API Key.", 
      'NotImplementedException:CallMethodNotImplemented'  =>  "Kaldemetode '%s' er ikke understøttet i øjeblikket.", 

      'NotImplementedException:XMLRPCMethodNotImplemented'  =>  "XML-RPC metode kald '%s' ikke implementeret.", 
      'InvalidParameterException:UnexpectedReturnFormat'  =>  "Kald til metode '%s' gav et uventet resultat.", 
      'CallException:NotRPCCall'  =>  "Kald ser ikke ud til at være et gyldigt XML-RPC kald",
	   
      'PluginException:NoPluginName'  =>  "Plugin navnent kunne ikke findes",
	   
      'ConfigurationException:BadDatabaseVersion'  =>  "Den database backend du har installeret opfylder ikke mindstekravene for at køre Elgg. Læs venligst din dokumentation.", 
      'ConfigurationException:BadPHPVersion'  =>  "Du skal mindst have PHP version 5.2 for at køre Elgg.", 
      'configurationwarning:phpversion'  =>  "Elgg kræver mindst PHP version 5.2, du kan installere det på 5.1.6 men nogle funtioner vil ikke virke. Forsøg på eget ansvar.",
	   
      'InstallationException:DatarootNotWritable'  =>  "Din datafolder er ikke skrivbar.", 
      'InstallationException:DatarootUnderPath'  =>  "Din datafolder %s skal være udenfor din installationssti.", 
      'InstallationException:DatarootBlank'  =>  "Du har ikke specificeret en datafolder.", 

      'SecurityException:authenticationfailed'  =>  "Bruger kunne ikke autoriseres",
	   
      'CronException:unknownperiod'  =>  "%s er ikke en godkendt periode.",
	   
      'SecurityException:deletedisablecurrentsite'  =>  "Du kan ikke deaktivere eller slette den side, som du selv ser på!", 

	  'memcache:notinstalled' => 'PHP memcache module er ikke installeret, du skal installere php5-memcache',
	  'memcache:noservers' => 'Ingen memcache servere defineret, konfigurer $CONFIG->memcache_servers variablen',
	  'memcache:versiontoolow' => 'Memcache behøver mindst version %s for at fungere, du kører %s',
 	  'memcache:noaddserver' => 'Flere server support er deaktiveret, du skal opgradere dit PECL memcache library',

	  'deprecatedfunction' => 'Advarsen: Denne kode bruger en forældet funktion \'%s\' og er ikke kompatibel med denne version af Elgg',

	  'pageownerunavailable' => 'Advarsel: Sideejeren %d kan ikke kontaktes!',
/**
 * API
 */	
      'system.api.list'  =>  "List alle tilgængelig API calls i systemet.", 
      'auth.gettoken'  =>  "Dette API kald lader en bruger få en ægthedstoken som kan anvendes til at autentificere fremtidige API-kald.",
	  
/**
 * User details
 */
 
      'name'  =>  "Fulde navn", 
      'email'  =>  "Email adresse", 
      'username'  =>  "Brugernavn", 
      'password'  =>  "Adgangskode", 
      'passwordagain'  =>  "Adgangskode (igen for verifikation)",
      'admin_option'  =>  "Skal denne bruger være administrator?",
	  
/**
 * Access
 */
 
      'PRIVATE'  =>  "Privat", 
      'LOGGED_IN'  =>  "Brugere der er logget ind", 
      'PUBLIC'  =>  "Offentlig",
	  'access:friends:label' => "Venner",
	  'access' => "Adgang", 
	  
/**
 * Dashboard and widgets
 */
 
      'dashboard'  =>  "Instrumentpanel", 
      'dashboard:configure'  =>  "Rediger side",
      'dashboard:nowidgets'  =>  "Dit instrumentpanel er din indgang til siden. Klik på \"Rediger side\" for at tilføje widgets til at holde styr på indhold og dit liv på siden.",
	   
      'widgets:add'  =>  "Tilføj widgets til siden", 
      'widgets:add:description'  =>  "Vælg de funktioner du ønsker at tilføje til siden ved at trække dem fra <b>Widget galleriet</b> til højre til ethvert af de tre widgetområder nedenfor og placer dem, hvor du ønsker, de skal være.

For at fjerne en widget, træk den tilbage til <b>Widget galleriet</b>.", 
      'widgets:position:fixed'  =>  "(Fast placering på siden)",
	  
      'widgets'  =>  "Widgets", 
      'widget'  =>  "Widget", 
      'item:object:widget'  =>  "Widgets", 
      'layout:customise'  =>  "Tilpas layout", 
      'widgets:gallery'  =>  "Widget galleri", 
      'widgets:leftcolumn'  =>  "Venstre widgets", 
      'widgets:fixed'  =>  "Fast position", 
      'widgets:middlecolumn'  =>  "Midterste widgets", 
      'widgets:rightcolumn'  =>  "Højre widgets", 
      'widgets:profilebox'  =>  "Profil boks", 
      'widgets:panel:save:success'  =>  "Dine widgets er blevet gemt.", 
      'widgets:panel:save:failure'  =>  "Der opstod et problem med at gemme dine widgets. Prøv venligst igen.", 
      'widgets:save:success'  =>  "Widgetten blev gemt.", 
      'widgets:save:failure'  =>  "Der opstod et problem med at gemme din widget. Prøv venligst igen.",
	  'widgets:handlernotfound' => 'Denne widget er enten defekt eller blevet deaktiveret af en administrator.',
	  
/**
 * Groups
 */

      'group'  =>  "Gruppe", 
      'item:group'  =>  "Grupper",

/**
 * Users
 */

      'user'  =>  "Bruger", 
      'item:user'  =>  "Brugere", 

/**
 * Friends
 */
 
      'friends'  =>  "Venner", 
      'friends:yours'  =>  "Dine venner", 
      'friends:owned'  =>  "%ss venner", 
      'friend:add'  =>  "Tilføj ven",
      'friend:remove'  =>  "Fjern ven",
	   
      'friends:add:successful'  =>  "Du har tilføjet %s som en ven.", 
      'friends:add:failure'  =>  "Vi kunne ikke tilføje %s som en ven. Prøv venligst igen.",
	   
      'friends:remove:successful'  =>  "Du har fjernet %s fra dine venner.", 
      'friends:remove:failure'  =>  "Vi kunne ikke fjerne %s fra dine venner. Prøv venligst igen.",
	   
      'friends:none'  =>  "Denne bruger har ikke tilføjet nogen som ven endnu.", 
      'friends:none:you'  =>  "Du har ikke tilføjet nogen som ven! Søg efter dine interesser for at find folk at følge.", 
      'friends:none:found'  =>  "Ingen venner fundet.", 
	  
      'friends:of:none'  =>  "Ingen har tilføjet denne bruger som ven endnu.", 
      'friends:of:none:you'  =>  "Ingen har tilføjet dig som ven endnu. Begynd at tilføje indhold og udfylde din profil for at lade folk finde dig!",

      'friends:of'  =>  "Venner af", 
      'friends:of:owned'  =>  "Folk der har %s som ven",
	   
      'friends:num_display'  =>  "Antal viste venner", 
      'friends:icon_size'  =>  "Ikon størrelse", 
      'friends:tiny'  =>  "meget lille", 
      'friends:small'  =>  "lille", 
      'friends:collections'  =>  "Venneliste", 
      'friends:collections:add'  =>  "Ny venneliste", 
      'friends:addfriends'  =>  "Tilføj venner", 
      'friends:collectionname'  =>  "Listens navn", 
      'friends:collectionfriends'  =>  "Venner i listen", 
      'friends:collectionedit'  =>  "Rediger denne liste", 
      'friends:nocollections'  =>  "Du har endu ikke nogle lister!", 
      'friends:collectiondeleted'  =>  "Din liste er blevet slettet!", 
      'friends:collectiondeletefailed'  =>  "Vi kunne ikke slette listen. Enter har du ikke tilladelse, eller også skete der en anden fejl.", 
      'friends:collectionadded'  =>  "Din liste er blevet oprettet", 
      'friends:nocollectionname'  =>  "Du er nødt til at give din liste et navn, før den kan oprettes.", 
	  'friends:collections:members' => "Venneliste",
	  'friends:collections:edit' => "Rediger liste",
	  
	  	  
      'friends:river:created'  =>  "%s tilføjede venner widgetten.", 
      'friends:river:updated'  =>  "%s har opdateret deres venner widget.", 
      'friends:river:delete'  =>  "%s har fjernet deres venner widget.", 
      'friends:river:add'  =>  "%s blev venner med.",
	  
	  'friendspicker:chararray' => 'ABCDEFGHIJKLMNOPQRSTUVWXYZÆØÅ',
	  
/**
 * Feeds
 */
      'feed:rss'  =>  "Abonner på feed", 
      'feed:odd'  =>  "Syndiker OpenDD", 

/**
 * links
 **/

      'link:view'  =>  "se link", 
	  
/**
 * River
 */
      'river'  =>  "River", 	  
      'river:relationship:friend'  =>  "er nu venner med", 
	  'river:noaccess' => 'Du har ikke tilladelse til at se dette emne.',
	  'river:posted:generic' => '%s postet',	  
      'riveritem:single:user'  =>  "en bruger", 
      'riveritem:plural:user'  =>  "nogle brugere",
	  
/**
 * Plugins
 */	  
      'plugins:settings:save:ok'  =>  "Indstillinger for %s plugin'et blev gemt.", 
      'plugins:settings:save:fail'  =>  "Der var et problem med at gemme indstillingerne for %s plugin'et.", 
      'plugins:usersettings:save:ok'  =>  "Bruger indstillinger for %s plugin'et blev gemt.", 
      'plugins:usersettings:save:fail'  =>  "Der var et problem med at gemme bruger indstillingerne for %s plugin'et.",
	  'admin:plugins:label:version' => "Version",
      'item:object:plugin'  =>  "Plugin opsætnings indstillinger ",
	  
/**
 * Notifications
 */ 
      'notifications:usersettings'  =>  "Reminders", 
      'notifications:methods'  =>  "Specificer hvilke reminders du r at bruge.", 
	  
      'notifications:usersettings:save:ok'  =>  "Dine indstillinger for reminders blev gemt.", 
      'notifications:usersettings:save:fail'  =>  "Der opstod et problem med at gemme dine indstillinger for reminders.",
	   
      'user.notification.get'  =>  "Returner indstillingerne for reminders for en given bruger.", 
      'user.notification.set'  =>  "Indstil reminders for en given bruger.",	  
/**
 * Search
 */
 
      'search'  =>  "Søg", 
      'searchtitle'  =>  "Søg: %s", 
      'users:searchtitle'  =>  "Søg efter brugere: %s",
	  'groups:searchtitle' => "Søg efter grupper: %s",
      'advancedsearchtitle'  =>  "%s med resultater der matcher %s",
      'notfound'  =>  "Ingen resultater fundet.", 
      'next'  =>  "Næste", 
      'previous'  =>  "Forrige",
	   
      'viewtype:change'  =>  "Skift liste type", 
      'viewtype:list'  =>  "Se liste", 
      'viewtype:gallery'  =>  "Galleri", 
	  
      'tag:search:startblurb'  =>  "Artikler med tags der matcher '%s':",
	   
      'user:search:startblurb'  =>  "Brugere der matcher '%s':", 
      'user:search:finishblurb'  =>  "For at se mere, klik her.", 
	  
	  'group:search:startblurb' => "Gruppe match '%s':",
	  'group:search:finishblurb' => "Klik her for at se mere.",
	  'search:go' => 'Find',
	  'userpicker:only_friends' => 'Kun venner',

/**
 * Account
 */
 
      'account'  =>  "Konto",
      'settings'  =>  "Indstillinger", 
      'tools'  =>  "Værktøjer", 
      'tools:yours'  =>  "Dine værktøjer",
	   
      'register'  =>  "Registrer", 
      'registerok'  =>  "Du er blevet registreret til %s.", 
      'registerbad'  =>  "Din registrering mislykkedes. Brugernavnet kan allerede være i brug, dine passwords var måske ikke ens, eller dit brugernavn eller adgangskoden var for kort.", 
      'registerdisabled'  =>  "Registrering er blevet lukket af systemadministratoren.",
	  
	  'firstadminlogininstructions' => 'Din nye Elgg side er blevet installeret og din administrator konto oprettet. Du kan nu konfigurere din side yderligere ved at aktivere diverse installerede plugin værktøjer.',
	   
      'registration:notemail'  =>  "Den anførte email adresse ser ikke ud til at være ægte.",	   
      'registration:userexists'  =>  "Brugernavnet eksisterer allerede", 
      'registration:usernametooshort'  =>  "Dit brugernavn skal være mindst 4 tegn langt.",
      'registration:passwordtooshort'  =>  "Din adgangskode skal være mindst 6 tegn langt.", 
      'registration:dupeemail'  =>  "Denne email adresse er allerede registreret.", 
      'registration:invalidchars'  =>  "Beklager, dit brugernavn indeholder ugyldige tegn.", 
      'registration:emailnotvalid'  =>  "Beklager, den angivne email adresse er ikke tilladt på dette system.", 
      'registration:passwordnotvalid'  =>  "Beklager, det angivne adgangskode er ikke tilladt på dette system.", 
      'registration:usernamenotvalid'  =>  "Beklager, det angivne brugernavn er ikke tilladt på dette system.", 
	  
      'adduser'  =>  "Tilføj bruger", 
      'adduser:ok'  =>  "Du har tilføjet en ny bruger.", 
      'adduser:bad'  =>  "Den nye bruger kunne ikke tilføjes.", 
	  
      'item:object:reported_content'  =>  "Anmeldte artikler", 

      'user:set:name'  =>  "Kontonavn", 
      'user:name:label'  =>  "Dit navn", 
      'user:name:success'  =>  "Dit navn er blevet ændret.", 
      'user:name:fail'  =>  "Kunne ikke ændre dit navn. Kontroller at dit navn ikke er for langt", 
	  
      'user:set:password'  =>  "Adgangskode", 
      'user:password:label'  =>  "Ny adgangskode", 
      'user:password2:label'  =>  "Gentag ny adgangskode", 
      'user:password:success'  =>  "Adgangskode ændret", 
      'user:password:fail'  =>  "Kunne ikke ændre din adgangskode", 
      'user:password:fail:notsame'  =>  "De to adgangskoder er ikke ens!", 
      'user:password:fail:tooshort'  =>  "Din adgangskode er for kort!", 
	  'user:resetpassword:unknown_user' => 'Ugyldig bruger.',
	  'user:resetpassword:reset_password_confirm' => 'Hvis du ændrer din adgangskode vil en email blive sendt til din registrerede email adresse.',	  
      'user:set:language'  =>  "Sprog", 
      'user:language:label'  =>  "Sprogvalg", 
      'user:language:success'  =>  "Dine sprogindstillinger er blevet opdateret", 
      'user:language:fail'  =>  "Dine sprogindstillinger kunne ikke gemmes.", 
	  
      'user:username:notfound'  =>  "Brugernavn %s ikke fundet.",
	   
      'user:password:lost'  =>  "Mistet adgangskode?", 
      'user:password:resetreq:success'  =>  "Ny adgangskode skal bekræftet, email sendt", 
      'user:password:resetreq:fail'  =>  "Kunne ikke ændre adgangskode.",
	   
      'user:password:text'  =>  "Har du mistet adgangskoden, kan du få en ny ved at skrive dit brugernavn herunder. Vi sender en email med adressen til en godkendelses side. Klik på linket i teksten og en ny adgangskode vil blive sendt til dig.", 

      'user:persistent'  =>  "Husk mig",	  
/**
 * Administration
 */
 
      'admin:configuration:success'  =>  "Dine indstillinger er blevet gemt.", 
      'admin:configuration:fail'  =>  "Dine indstillinger kunne ikke gemmes.",
	   
      'admin'  =>  "Administration", 
      'admin:description'  =>  "Administrator panelet gør dig i stand til at kontrollere alle aspekter af systemet, fra brugerstyring til hvordan plugins opfører sig. Vælg en mulighed herunder for at starte.",
	   
      'admin:user'  =>  "Bruger Administration", 
      'admin:user:description'  =>  "Dette administratorpanel lader dig styre brugerindstillinger for din side. Vælg en mulighed nedenfor for at starte.", 
      'admin:user:adduser:label'  =>  "Klik her for at tilføje en ny bruger...", 
      'admin:user:opt:linktext'  =>  "Konfigurer brugere...", 
      'admin:user:opt:description'  =>  "Konfigurer bruger- og kontoinformation.", 

      'admin:site'  =>  "Side Administration", 
      'admin:site:description'  =>  "Dette administrationspanel lader dig kontrollere de globale indstillinger for din side. Vælg en mulighed nedenfor for at starte.", 
      'admin:site:opt:linktext'  =>  "Indstil side...", 
      'admin:site:opt:description'  =>  "Konfigurer sidens tekniske og ikke-tekinske indstillinger.",
	  'admin:site:access:warning' => "Ændring af instillingen for adgang vil kun have indflydelse på tilladelser for fremtidigt indhold.",	
      'admin:plugins'  =>  "Værktøj Administration", 
      'admin:plugins:description'  =>  "Dette administrationspanel lader dig kontrollere og indstille værktøjer, der er installeret på din side.", 
      'admin:plugins:opt:linktext'  =>  "Indstillings værktøjer", 
      'admin:plugins:opt:description'  =>  "Konfigurer de værktøje der er installeret på siden.", 
      'admin:plugins:label:author'  =>  "Forfatter", 
      'admin:plugins:label:copyright'  =>  "Copyright", 
      'admin:plugins:label:licence'  =>  "Licens", 
      'admin:plugins:label:website'  =>  "URL", 
      'admin:plugins:label:moreinfo'  =>  "mere information",	  
	  'admin:plugins:warning:elggversionunknown' => 'Advarsel: Dette glugin angiver ikke en kompatibel Elgg version.',
	  'admin:plugins:warning:elggtoolow' => 'Advarsel: Dette plugin kræver en senere version af Elgg!',	   
      'admin:plugins:reorder:yes'  =>  "Plugin %s blev omorganiseret.", 
      'admin:plugins:reorder:no'  =>  "Plugin %s kunne ikke omorganiseres.", 
      'admin:plugins:disable:yes'  =>  "Plugin %s blev slået fra.", 
      'admin:plugins:disable:no'  =>  "Plugin %s kunne ikke slås fra.", 
      'admin:plugins:enable:yes'  =>  "Plugin %s blev slået til.", 
      'admin:plugins:enable:no'  =>  "Plugin %s kunne ikke slås til.",
	  
      'admin:statistics'  =>  "Statistikker",
      'admin:statistics:description'  =>  "Dette er et overblik over statistikkerne for din side. Hvis du behøver mere detaljerede statistikker, findes der en professionel administrations funktion.", 
      'admin:statistics:opt:description'  =>  "Se statistisk information om brugere og objekter på din side.", 
      'admin:statistics:opt:linktext'  =>  "Se statistikker...", 
      'admin:statistics:label:basic'  =>  "Grundlæggende side statistikker", 
      'admin:statistics:label:numentities'  =>  "Enheder på siden", 
      'admin:statistics:label:numusers'  =>  "Antal brugere", 
      'admin:statistics:label:numonline'  =>  "Antal brugere online", 
      'admin:statistics:label:onlineusers'  =>  "Brugere online nu", 
      'admin:statistics:label:version'  =>  "Elgg version", 
      'admin:statistics:label:version:release'  =>  "Udgivelse", 
      'admin:statistics:label:version:version'  =>  "Version",
	   
      'admin:user:label:search'  =>  "Find brugere:", 
      'admin:user:label:seachbutton'  =>  "Søg",
	   
      'admin:user:ban:no'  =>  "Kan ikke bandlyse bruger", 
      'admin:user:ban:yes'  =>  "Bruger bandlyst.", 
      'admin:user:unban:no'  =>  "Kan ikke de-bandlyse bruger", 
      'admin:user:unban:yes'  =>  "Bruge de-bandlyst", 
      'admin:user:delete:no'  =>  "Kan ikke slette bruger", 
      'admin:user:delete:yes'  =>  "Bruger slettet", 
	  
      'admin:user:resetpassword:yes'  =>  "Adgangskode ændret, bruger underrettet.",
      'admin:user:resetpassword:no'  =>  "Adgangskode kunne ikke resettes.",
	   
      'admin:user:makeadmin:yes'  =>  "Bruger er nu en administrator.", 
      'admin:user:makeadmin:no'  =>  "Vi kunne ikke gøre bruger til en administrator.",
	  
	  'admin:user:removeadmin:yes' => "Brugeren er ikke længere administrator.",
	  'admin:user:removeadmin:no' => "Vi kunne ikke fjerne administrator tilladelser fra denne bruger.",
	  	  
/**
 * User settings
 */ 
      'usersettings:description'  =>  "Bruger indstillingspanelet gør dig i stand til at kontrollere alle dine personlige indstilinger, fra brugerstrying til hvordan dine plugins skal opføre sig. Vælg en mulighed herunder for at begynde.",
	   
      'usersettings:statistics'  =>  "Dine statistikker", 
      'usersettings:statistics:opt:description'  =>  "Vis statistisk information om brugere og objekter på din side.", 
      'usersettings:statistics:opt:linktext'  =>  "Konto statistikker",
	   
      'usersettings:user'  =>  "Dine indstillinger", 
      'usersettings:user:opt:description'  =>  "Dette gør dig i stand til at styre dine brugerinstillinger.", 
      'usersettings:user:opt:linktext'  =>  "Rediger dine indstillinger", 

      'usersettings:plugins'  =>  "Værktøjer", 
      'usersettings:plugins:opt:description'  =>  "Skift indstillinger for dine aktive værktøjer.", 
      'usersettings:plugins:opt:linktext'  =>  "Indstillings værktøjer", 
	  
      'usersettings:plugins:description'  =>  "Dette panel gør dig i stand til at styre og opsætte personlige indstillinger for de værktøjer, der er blevet installeret af systemadministratoren.", 
      'usersettings:statistics:label:numentities'  =>  "Dine enheder",
	   
      'usersettings:statistics:yourdetails'  =>  "Dine detaljer", 
      'usersettings:statistics:label:name'  =>  "Fulde navn", 
      'usersettings:statistics:label:email'  =>  "Email", 
      'usersettings:statistics:label:membersince'  =>  "Medlem siden", 
      'usersettings:statistics:label:lastlogin'  =>  "Sidst logget ind",
	   
/**
 * Generic action words
 */ 
      'save'  =>  "Gem",
	  'publish' => "Offentliggør", 
      'cancel'  =>  "Annuller", 
      'saving'  =>  "Gemmer ...", 
      'update'  =>  "Opdater", 
      'edit'  =>  "Rediger", 
      'delete'  =>  "Slet",
	  'accept' => "Accepter", 
      'load'  =>  "Hent", 
      'upload'  =>  "Upload", 
      'ban'  =>  "Bandlys", 
      'unban'  =>  "Ophæv bandlysning",
      'enable'  =>  "Aktiver", 
      'disable'  =>  "Deaktiver", 
      'request'  =>  "Anmod", 
      'complete'  =>  "Færdig", 
      'open'  =>  "Åbn", 
      'close'  =>  "Luk", 
      'reply'  =>  "Svar",
	  'more' => 'Mere',
	  'comments' => 'Kommentarer',
	  'import' => 'Importer',
	  'export' => 'Eksporter',
	  'untitled' => 'Untitled',
	  'help' => 'Hjælp',
	  'send' => 'Send',
	  'post' => 'Post',
	  'submit' => 'Send',
	  'site' => 'Side',
      'up'  =>  "Op", 
      'down'  =>  "Ned", 
      'top'  =>  "Top",
      'bottom'  =>  "Bund",
	   
      'invite'  =>  "Inviter",
	   
      'resetpassword'  =>  "Nulstil kodeord", 
      'makeadmin'  =>  "Gør til administrator", 
	  'removeadmin' => "Fjern admin",
	  
      'option:yes'  =>  "Ja", 
      'option:no'  =>  "Nej",
	   
      'unknown'  =>  "Ukendt",
	   
      'active'  =>  "Aktiv", 
      'total'  =>  "Total",
	   
      'learnmore'  =>  "Klik her for at lære mere.", 

      'content'  =>  "indhold", 
      'content:latest'  =>  "Seneste aktivitet", 
      'content:latest:blurb'  =>  "Alternativt, klik her for at se det seneste indhold fra hele siden.", 
	  
      'link:text'  =>  "se link",
	  
	  'enableall' => 'Aktiver alle',
	  'disableall' => 'Deaktiver alle',
	  
/**
 * Generic questions
 */
 
	  'question:areyousure' => 'Er du sikker?',

/**
 * Generic data words
 */
	  
      'title'  =>  "Titel", 
      'description'  =>  "Beskrivelse", 
      'tags'  =>  "Tags", 
      'spotlight'  =>  "Spotlight", 
      'all'  =>  "Alle",
	   
      'by'  =>  "af", 
	  
	  'annotations'  =>  "Notater", 
      'relationships'  =>  "Forhold", 
      'metadata'  =>  "Metadata", 
	  
/**
* Input / output strings
*/

      'deleteconfirm'  =>  "Er du sikker på, at du vil slette dette?", 
      'fileexists'  =>  "En fil er allerede blevet uploadet. Vælg den for at erstatte den:", 
	  
/**
* User add
*/

	  'useradd:subject' => 'Brugerkonto oprettet',
	  'useradd:body' => '
%s,

En brugerkonto er blevet oprettet til dig på %s. For at logge ind, besøg:

%s

Du kan logge ind med disse bruger oplysninger:

Brugernavn: %s
Adgangskode: %s

Vi anbefaler, at du ændrer din adgangskode, når du har logget ind.
',

/**
 * System messages
 **/
 
      'systemmessages:dismiss'  =>  "klik for at lukke",

/**
 * Import / export
 */
 	   
      'importsuccess'  =>  "Data import lykkedes", 
      'importfail'  =>  "OpenDD data import mislykkedes",

/**
 * Time
 */
  
	'friendlytime:justnow' => "lige nu", 
	'friendlytime:minutes' => "%s minutter siden", 
	'friendlytime:minutes:singular' => "et minut siden", 
	'friendlytime:hours' => "%s timer siden", 
	'friendlytime:hours:singular' => "en time siden", 
	'friendlytime:days' => "%s dage siden", 
	'friendlytime:days:singular' => "i går",
	'friendlytime:date_format' => 'j F Y @ g:ia',
	  
	'date:month:01' => 'Januar %s',
	'date:month:02' => 'Februar %s',
	'date:month:03' => 'Marts %s',
	'date:month:04' => 'April %s',
	'date:month:05' => 'Maj %s',
	'date:month:06' => 'Juni %s',
	'date:month:07' => 'Juli %s',
	'date:month:08' => 'August %s',
	'date:month:09' => 'September %s',
	'date:month:10' => 'Oktober %s',
	'date:month:11' => 'November %s',
	'date:month:12' => 'December %s',
	
/**
 * Installation and system settings
 */
	   
      'installation:error:htaccess'  =>  "Elgg kærver en fil kaldet .htaccess i rodfolderen af dens installation. Vi prøvede at lave den for dig, men Elgg har ikke tilladelse til at skrive i den folder.

Det er nemt at lave denne fil. Kopier indholdet af følgende tekstboks ind i et tekstredigerings program og gem det som .htacess

", 
      'installation:error:settings'  =>  "Elgg kunne ikke finde sin indstillingsfil. De fleste af Elggs indstillinger vil blive klaret for dig, men vi har brug for at du giver os dine database detaljer. For at gøre dette skal du:

1. Omdøbe engine/settings.example.php til settings.php i din Elgg installation.

2. Åbne den med et tekstredigerings program og indtaste dine MySQL database detaljer. Kender du dem ikke, så spørg om hjælp hos din systemadminstrator eller teknisk support

Alternativt kan du indtaste dine database detaljer nedenfor og vi vil prøve at gøre dette for dig...",
 
      'installation:error:configuration'  =>  "Når du har rettet eventuelle opsætningsproblemer, tryk opdater for at prøve igen.",
	  'installation:error:db:text' => "Kontroller dine database indstillinger igen da elgg ikke kunne forbinde og tilgå databasen.",
	  'installation:error:configuration' => "Når du har rettet problemer i indstillingerne reload og prøv igen.", 
	  
      'installation'  =>  "Installation", 
      'installation:success'  =>  "Elggs database blev installeret.", 
      'installation:configuration:success'  =>  "Dine første konfigurationsindstillinger er blevet gemt. Registrer nu din første bruger, der vil blive din første system administrator.",
	   
      'installation:settings'  =>  "System indstillinger", 
      'installation:settings:description'  =>  "Nu hvor Elgg databasen er blevet installeret, er du nødt til at indtaste lidt mere information for at få din side helt op at køre. Vi har forsøgt at gætte så meget som muligt, men <b>du bør checke disse detaljer!</b>",
	  
	   
      'installation:settings:dbwizard:prompt'  =>  "Indtast dine database indstillinger nedenfor og tryk gem:", 
      'installation:settings:dbwizard:label:user'  =>  "Database bruger", 
      'installation:settings:dbwizard:label:pass'  =>  "Database adgangskode", 
      'installation:settings:dbwizard:label:dbname'  =>  "Elgg database", 
      'installation:settings:dbwizard:label:host'  =>  "Database hostname (som regel 'localhost')", 
      'installation:settings:dbwizard:label:prefix'  =>  "Database table præfiks (som regel 'elgg')",
	   
      'installation:settings:dbwizard:savefail'  =>  "Vi var ikke i stand til at gamme den nye settings.php. Gem venligst den følgende fil som engine/settings.php med et tekstredigerings program.", 

      'installation:sitename'  =>  "Din sides navn (f.eks. \"Min sociale netværks side\"):", 
      'installation:sitedescription'  =>  "Kort beskrivelse af din side (Valgfrit)", 
      'installation:wwwroot'  =>  "Sidens URL, efterfulgt af en skråstreg:", 
      'installation:path'  =>  "Den fulde stil til din sides rod på din disk, efterfulgt af en skråstreg:", 
      'installation:dataroot'  =>  "Den fulde stil til den folder hvor uploadede filer bliver gemt, efterfulgt af en skråstreg:", 
      'installation:dataroot:warning'  =>  "Du skal oprette denne folder manuelt. Den bør være placeret i en anden folder en din Elgg installation.",
	  'installation:sitepermissions' => "Standard adgangstilladelser:", 
      'installation:language'  =>  "Standardsproget for din side:", 
      'installation:debug'  =>  "Debug mode giver ekstra information, der kan bruges til at diagnosticere fejl, men den gør dit system langsommere og bør kun bruges, hvis du har problemer.",	  
	  'installation:debug:none' => 'Fravælg debug mode (anbefalet)',
	  'installation:debug:error' => 'Vis kun kritiske fejl',
	  'installation:debug:warning' => 'Vis fejl og advarsler',
	  'installation:debug:notice' => 'Log alle fejl, advarsler og bemærkninger',	  
	  'installation:httpslogin' => "Aktiver dette hvis du vil have bruger log ind håndteret af HTTPS. Du skal have https aktiveret på din server for at dette fungerer.",
	  'installation:httpslogin:label' => "Aktiver HTTPS log ind",
	  'installation:view' => "Vælg det udseende der skal bruges som standard for din side eller lad være med at vælge for at bruge standard udseende (er du i tvivl, så brug standart):",
	  
	  'installation:siteemail'  =>  "Sidens email adresse (bruges når der sendes system emails)",
	  
	   'installation:disableapi'  =>  "RESTful API er en fleksibel og udvidelig grænseflade, der tillader programmer at tilgå visse Elgg funktioner udefra.", 
      'installation:disableapi:label'  =>  "Slå RESTful API til",
	  
	  'installation:allow_user_default_access:description' => "Hvis tilvalgt vil individuelle brugere have tilladelse til at definere deres eget adgangsniveau, som kan overskrive systemets standard adgangsniveau.",
	  'installation:allow_user_default_access:label' => "Tillad bruger standard adgang.",

	  'installation:simplecache:description' => "Simple cache øger præstationen ved at cache statisk indhold inklusive nogle CSS og JavaScript filer. Normalt vil du have dette slået til.",
	  'installation:simplecache:label' => "Brug simple cache (anbefalet)",

	  'installation:viewpathcache:description' => "View filepath cache nedsætter loadingtiden på plugins ved at cache placeringen af deres  visninger.",
	  'installation:viewpathcache:label' => "Brug view filepath cache (anbefalet)",
	  
	  'upgrading'  =>  "Opgraderer", 
      'upgrade:db'  =>  "Din database blev opgraderet.", 
      'upgrade:core'  =>  "Din Elgg installation blev opgraderet",
	  
/**
* Welcome
*/ 
 
      'welcome'  =>  "Velkommen",
	  'welcome:user' => 'Velkommen %s', 
      'welcome_message'  =>  "Velkommen til denne Elgg installation.",
	  
/**
* Emails
*/ 

      'email:settings'  =>  "Email", 
      'email:address:label'  =>  "Din email adresse",
	   
      'email:save:success'  =>  "Ny email adresse gemt, verifikation afsendt.", 
      'email:save:fail'  =>  "Din nye email adresse kunne ikke gemmes.", 

      'friend:newfriend:subject'  =>  "%s har gjort dig til ven!", 
      'friend:newfriend:body'  =>  "%s har gjort dig til ven!

For at se deres personlige profil, klik her;

	%s

Du kan ikke besvare via denne mail.",
 
      'email:resetpassword:subject'  =>  "Adgangskode ændret!", 
      'email:resetpassword:body'  =>  "Hej %s,
			
Dit password er blevet ændret til: %s", 

      'email:resetreq:subject'  =>  "s ny adgangskode?", 
      'email:resetreq:body'  =>  "Hej %s,
			
En (fra IP adressen %s) har t ny adgangskode for deres konto.

Hvis det var dig, der de dette, så klik på linket nedenfor ellers ignorer denne email.

%s
",

/**
 * user default access
*/

	  'default_access:settings' => "Dit standard adgangsniveau",
	  'default_access:label' => "Standard adgang",
	  'user:default_access:success' => "Dit nye standard adgangsniveau er gemt.",
	  'user:default_access:failure' => "Dit nye standard adgangsniveau kunne ikke gemmes.",

/**
* XML-RPC
*/
  
      'xmlrpc:noinputdata'  =>  "Ingen input data",
	  
/**
 * Comments
 */
  
      'comments:count'  =>  "%s kommntarer",
	   
      'riveraction:annotation:generic_comment'  =>  "%s har kommenteret %s",
	   
      'generic_comments:add'  =>  "Tilføj kommentar", 
      'generic_comments:text'  =>  "Kommentar", 
      'generic_comment:posted'  =>  "Din kommentar er blevet tilføjet.", 
      'generic_comment:deleted'  =>  "Din kommentar er blevet slettet.", 
      'generic_comment:blank'  =>  "Beklager, men du er nødt til at skrive noget i din kommentar for at vi kan gemme den.", 
      'generic_comment:notfound'  =>  "Beklager, vi kunne ikke finde det specifikke objekt.", 
      'generic_comment:notdeleted'  =>  "Beklager, vi kunne ikke slette denne kommentar.", 
      'generic_comment:failure'  =>  "En uforudset fejl skete ved tilføjelsen af din kommentar. Prøv venligst igen.", 
	  
      'generic_comment:email:subject'  =>  "Du har en ny kommentar!", 
      'generic_comment:email:body'  =>  "Du har en ny kommentar på din \"%s\" fra %s. Der står:

			
%s


Klik her for at svare eller se det oprindelige emne:

%s

Klik her for at se %s's profil:

%s

Du kan ikke svare via denne mail.",

/**
 * Entities
 */
 
      'entity:default:strapline'  =>  "Oprettet %s af %s", 
      'entity:default:missingsupport:popup'  =>  "Denne enhed kan ikke vises korrekt. Dette kan være fordi det kræver undersøttelse fra et plugin, der ikke længere er installeret.",
	   
      'entity:delete:success'  =>  "Enheden %s er blevet slettet", 
      'entity:delete:fail'  =>  "Enheden %s kunne ikke slettes", 
	  
/**
 * Action gatekeeper
 */
 
      'actiongatekeeper:missingfields'  =>  "Form mangler __token eller __ts felter", 
      'actiongatekeeper:tokeninvalid'  =>  "Vi stødte på en fejl (token mismatch). Det betyder formegentlig at siden du brugte er udløbet. Prøv venligst igen.", 
      'actiongatekeeper:timeerror'  =>  "Side du brugte er udløbet. Genopfrisk siden og prøv igen.", 
      'actiongatekeeper:pluginprevents'  =>  "En udvidelse har forhindret denne form i at blive indsendt.", 
	  
/**
 * Word blacklists
 */
 
      'word:blacklist'  =>  "og, den, det, så, men hun, han, hendes, hans, en, et, ikke, også, om, nu, dermed, således, til, stadig, ligesom, derimod, derfor, omvendt, tværtimod, hellere, følge, yderligere, alligevel, imens, derefter, denne, dette, synes, hvem, hvad, hvor, hvornår, hvordan, hvorfor, hvorledes, hvormed",
	  
/**
 * Tag labels
 */
 
 	  'tag_names:tags' => 'Tags',	  

/**
 * Languages according to ISO 639-1
 */
 
      'aa'  =>  "Afar", 
      'ab'  =>  "Abkhasisk", 
      'af'  =>  "Afrikaans", 
      'am'  =>  "Amharisk", 
      'ar'  =>  "Arabisk", 
      'as'  =>  "Assamesisk", 
      'ay'  =>  "Aymaransk", 
      'az'  =>  "Azerbadjansk", 
      'ba'  =>  "Bashkir", 
      'be'  =>  "Hviderussisk", 
      'bg'  =>  "Bulgarsk", 
      'bh'  =>  "Bihari", 
      'bi'  =>  "Bislama", 
      'bn'  =>  "Bengalsk", 
      'bo'  =>  "Tibetansk", 
      'br'  =>  "Breton", 
      'ca'  =>  "Catalansk", 
      'co'  =>  "Corsicansk", 
      'cs'  =>  "Tjekkisk", 
      'cy'  =>  "Walisisk", 
      'da'  =>  "Dansk", 
      'de'  =>  "Tysk", 
      'dz'  =>  "Bhutani", 
      'el'  =>  "Græsk", 
      'en'  =>  "Engelsk", 
      'eo'  =>  "Esperanto", 
      'es'  =>  "Spansk", 
      'et'  =>  "Estisk", 
      'eu'  =>  "Baskisk", 
      'fa'  =>  "Persisk", 
      'fi'  =>  "Finsk", 
      'fj'  =>  "Fiji", 
      'fo'  =>  "Faeroese", 
      'fr'  =>  "Fransk", 
      'fy'  =>  "Frisian", 
      'ga'  =>  "Irsk", 
      'gd'  =>  "Skotsk / Gælisk", 
      'gl'  =>  "Galician", 
      'gn'  =>  "Guaranisk", 
      'gu'  =>  "Gujarati", 
      'he'  =>  "Hebraisk", 
      'ha'  =>  "Hausa", 
      'hi'  =>  "Hindi", 
      'hr'  =>  "Croatisk", 
      'hu'  =>  "Ungarsk", 
      'hy'  =>  "Armensk", 
      'ia'  =>  "Interlingua", 
      'id'  =>  "Indonesisk", 
      'ie'  =>  "Interlingue", 
      'ik'  =>  "Inupiak", 
      'is'  =>  "Islandsk", 
      'it'  =>  "Italiensk", 
      'iu'  =>  "Inuktitut", 
      'iw'  =>  "Hebraisk (forældet)", 
      'ja'  =>  "Japansk", 
      'ji'  =>  "Yiddish (obsolete)", 
      'jw'  =>  "Javanesisk", 
      'ka'  =>  "Georgisk", 
      'kk'  =>  "Kazakh", 
      'kl'  =>  "Grønlandsk", 
      'km'  =>  "Khmer", 
      'kn'  =>  "Kannada", 
      'ko'  =>  "Koreansk", 
      'ks'  =>  "Kashmiri", 
      'ku'  =>  "Kurdisk", 
      'ky'  =>  "Kirghizisk", 
      'la'  =>  "Latin", 
      'ln'  =>  "Lingala", 
      'lo'  =>  "Laothian", 
      'lt'  =>  "Lithaunsk", 
      'lv'  =>  "Lettisk", 
      'mg'  =>  "Malagasy", 
      'mi'  =>  "Maori", 
      'mk'  =>  "Makedonsk", 
      'ml'  =>  "Malaysisk", 
      'mn'  =>  "Mongolsk", 
      'mo'  =>  "Moldovisk", 
      'mr'  =>  "Marathi", 
      'ms'  =>  "Malajisk", 
      'mt'  =>  "Maltesisk", 
      'my'  =>  "Burmesisk", 
      'na'  =>  "Naurisk", 
      'ne'  =>  "Nepalesisk", 
      'nl'  =>  "Hollandsk", 
      'no'  =>  "Norsk", 
      'oc'  =>  "Occitansk",
      'om'  =>  "Oromo", 
      'or'  =>  "Orija", 
      'pa'  =>  "Punjab", 
      'pl'  =>  "Polsk", 
      'ps'  =>  "Afghansk", 
      'pt'  =>  "Portuguisisk", 
      'qu'  =>  "Quechua", 
      'rm'  =>  "Retroromansk", 
      'rn'  =>  "Kirundi", 
      'ro'  =>  "Rumænsk", 
      'ru'  =>  "Russisk", 
      'rw'  =>  "Kinyarwanda", 
      'sa'  =>  "Sanskrit", 
      'sd'  =>  "Sindhi", 
      'sg'  =>  "Sangro", 
      'sh'  =>  "Serbokroatisk", 
      'si'  =>  "Singalesisk", 
      'sk'  =>  "Slovakisk", 
      'sl'  =>  "Slovensk", 
      'sm'  =>  "Samoansk",
      'sn'  =>  "Shona", 
      'so'  =>  "Somalisk", 
      'sq'  =>  "Albansk", 
      'sr'  =>  "Serbisk", 
      'ss'  =>  "Siswati", 
      'st'  =>  "Sesotho", 
      'su'  =>  "Sundanesisk", 
      'sv'  =>  "Svensk", 
      'sw'  =>  "Swahili", 
      'ta'  =>  "Tamilsk",
      'te'  =>  "Tegulu", 
      'tg'  =>  "Tajik", 
      'th'  =>  "Thai", 
      'ti'  =>  "Tigrinya", 
      'tk'  =>  "Turkmen", 
      'tl'  =>  "Tagalog", 
      'tn'  =>  "Setswana", 
      'to'  =>  "Tonga", 
      'tr'  =>  "Tyrkisk", 
      'ts'  =>  "Tsonga",
      'tt'  =>  "Tatar", 
      'tw'  =>  "Twi", 
      'ug'  =>  "Uigur", 
      'uk'  =>  "Ukrainsk", 
      'ur'  =>  "Urdu", 
      'uz'  =>  "Uzbek", 
      'vi'  =>  "Vietnamesisk", 
      'vo'  =>  "Volapuk", 
      'wo'  =>  "Wolof", 
      'xh'  =>  "Xhosa", 
      //'yi'  =>  "Yiddish", 
      'yo'  =>  "Yoruba", 
      'za'  =>  "Zuang", 
      'zh'  =>  "Kinesisk", 
      'zu'  =>  "Zulu"
);

add_translation("da",$danish);

?>