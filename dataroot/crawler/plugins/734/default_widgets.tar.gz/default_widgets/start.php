<?php
/**
 * Elgg default_widgets plugin.
 *
 * @package ElggAutoWidgets
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU
 Public License version 2 (whatever that means) basically do as you wish, but email either of us
 if you have any improvements/additions
 * @author Jade Dominguez, Chad Sowald
 * @copyright tastyseed,  2008
 * @copyright Chad Sowald, 2008
 * @link http://www.tastyseed.com
 * @link http://www.chadsowald.com
 * @author Diego Ramirez
 * @links http://www.somosmas.org
 */

/* EDITING INSTRUCTIONS
 please see the instruction manual supplied in the plugin folder
 */

global $default_widgets;

function AutoAdd_init(){
  global $CONFIG;

  register_elgg_event_handler('create', 'user', 'AutoAddWidgets');

  add_default_widget("status",array("profile_column"=>3));
  add_default_widget("friends",array("profile_column"=>3,"num_display"=>10));
  add_default_widget("a_users_groups",array("profile_column"=>3,"num_display"=>5));
  add_default_widget("river_widget",array("profile_column"=>1,"num_display"=>8));
  add_default_widget("messageboard",array("profile_column"=>2,"num_display"=>5));
  add_default_widget("river_widget_friends",array("dashboard_column"=>1,"num_display"=>8));
}
/**
 * This funcion adds the configuration of a new default_widget. 
 * 
 * This is the first step for have a web interface for this configuration.
 *
 * @param string $widget Widget name
 * @param array $options Configuration options. The profile_column or dashboard_columns are mandatory
 * @return boolean
 */
function add_default_widget($widget,$options){
  global $default_widgets;
  if(!is_array($default_widgets)){
    $default_widgets=array();
  }

  if(!array_key_exists($widget,$default_widgets)){
    if(array_key_exists("profile_column",$options) || array_key_exists("dashboard_column",$options)){
      $default_widgets[$widget]=$options;
      //@todo Add logging reporting
      return true;
    }
  }
  return false;
}

/**
 * Event hook 
 *
 * @param string $event
 * @param type of object $object_type
 * @param object $object
 */
function AutoAddWidgets($event, $object_type, $object){
  global $CONFIG,$default_widgets;

  //Get new user's guid
  $guid = $object->guid;

  //Get the current user
  //If this is a user, it's an admin
  if(isadminloggedin()){
    $user_orig = $_SESSION['user'];
  }
  else{
    $user_orig = false;
  }

  /*
   the add_widgets function only executes if the user has permissions to add widgets to his profile/dashboard.
   Since there is no user yet logged in, we need to artificially login the new user
   */
  $log_user_in = login($object);

  if($log_user_in){
    foreach($default_widgets as $widget=>$options){
      if (!empty($guid)) {
        if ($user = get_entity($guid)) {
          if ($user->canEdit()) {
            //add profile widgets if any
            if(array_key_exists("profile_column",$options)){
              $profile_result = add_widget($guid, $widget, 'profile', ($options["profile_column"]+1), $options["profile_column"]);
            }
            //add dashboard widgets if any
            else{
              $dashboard_result = add_widget($guid, $widget, 'dashboard', ($options["dashboard_column"]+1), $options["dashboard_column"]);
            }
          }
        }
      }
    }
    //Get the widgets we just added in each of the 3 columns
    $widgets_dashboard = array();
    $widgets_profile = array();
    for($i=1;$i<4;$i++){
      $widgets_dashboard_ = get_widgets($guid, "dashboard", $i);
      $widgets_profile_ = get_widgets($guid, "profile", $i);
      if(is_array($widgets_dashboard_)){
        $widgets_dashboard=array_merge($widgets_dashboard,$widgets_dashboard_);
      }
      if(is_array($widgets_profile_)){
        $widgets_profile=array_merge($widgets_profile,$widgets_profile_);
      }
    }

    //Get the widget handlers associated with each widget guid for this user
    //We have to do this because when we "get_widgets", there is no handler listed and
    //we need the handler to decide what parameters to set.
    $query = "SELECT e.guid AS 'guid', s.string AS 'Key', ss.string AS 'Value'
						FROM ". $CONFIG->dbprefix . "metadata m, ". $CONFIG->dbprefix . "entities e, ". $CONFIG->dbprefix . "metastrings s, ". $CONFIG->dbprefix . "metastrings ss
    WHERE e.guid = m.entity_guid
    AND m.name_id = s.id
    AND m.value_id = ss.id
    AND e.owner_guid = $guid
    AND s.string = 'handler'
    ORDER BY e.guid ASC";

    //Execute the query
    $user_handlers = get_data($query);
    if(!empty($user_handlers)){
      //Configure the widgets for both the dashboard and the profile
      autowidgets_config($widgets_dashboard, $user_handlers);
      autowidgets_config($widgets_profile, $user_handlers);
    }
    //If an admin created this user, log the new user out, log the admin back in and forward them to the add user page

    if(!empty($user_orig)){
      if(login($user_orig)){
        forward("pg/admin/user/");
        exit;
      }
    }
  }
}

/*******************
 Configure a set of widgets, where each set is a set of columns of widgets
 *******************/
function autowidgets_config($widgets_page_set, $handlers){
  if(is_array($widgets_page_set)){
    foreach($widgets_page_set as $widget){
      $handler = get_widget_handler($widget->guid,$handlers);
      if($handler){
        $params = get_widget_config($handler);
        if(!empty($params)){
          //Internal Elgg function to update the parameters for a widget
          save_widget_info($widget->guid, $params);
        }
      }
    }
  }
}

/**
 * Extract the widget handler from the list of handler
 *
 * @param int $guid Widget id
 * @param array $handlers Available handlers
 * @return 
 */
function get_widget_handler($guid, $handlers){
  //Go through the array of handlers and guids
  foreach($handlers as $handler){
    if($handler->guid == $guid){
      //Return the handler string
      return $handler->Value;
    }
  }
  //No handler found
  return false;
}

/**
 * Get the extra widget configuration options.
 *
 * @param string $handler
 * @return mixed
 */
function get_widget_config($handler){
  global $default_widgets;
  if(array_key_exists($handler,$default_widgets)){
    return array_diff_key($default_widgets[$handler],array("profile_column"=>"profile_column","dashboard_column"=>"dashboard_column"));
  }
  else {
    return false;
  }
}

//make sure **default_widgets plugin** functions loads on initialization
register_elgg_event_handler('init', 'system', 'AutoAdd_init');
?>