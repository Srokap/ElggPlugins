<?php

elgg_register_event_handler('init', 'system', 'socialapparatus_games18_init');

function socialapparatus_games18_init() {

	$item = new ElggMenuItem('socialapparatus_games18', elgg_echo('games'), 'socialapparatus_games18');
	elgg_register_menu_item('site', $item);
	elgg_register_page_handler('socialapparatus_games18', 'socialapparatus_games18_page_handler');
	elgg_extend_view('page/elements/head','socialapparatus_games18/meta');
}

function socialapparatus_games18_page_handler($page) {


	if (!isset($page[0])) {
		$page[0] = 'index';
	}

	$file_dir = elgg_get_plugins_path() . 'socialapparatus_games18/pages/socialapparatus_games18';

	$page_type = $page[0];
	switch ($page_type) {
		case 'poker':
		include "$file_dir/poker.php";
		break;
		
		case 'empire':
		include "$file_dir/empire.php";
		break;
		
		case 'mafia':
		include "$file_dir/mafia.php";
		break;
		
		case 'cafe':
		include "$file_dir/cafe.php";
		break;
		
		case 'fashion':
		include "$file_dir/fashion.php";
		break;
		
		case 'disco':
		include "$file_dir/disco.php";
		break;
		
		case 'hercules':
		include "$file_dir/hercules.php";
		break;
		
		case 'farmer':
		default:
			include "$file_dir/farmer.php";
			break;
	}
}