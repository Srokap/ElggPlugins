<?php

$english = array(
	'games' => 'Games',

);

add_translation('en', $english);
