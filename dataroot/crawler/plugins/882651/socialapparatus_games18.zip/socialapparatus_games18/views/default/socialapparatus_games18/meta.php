<?php
$code = elgg_get_plugin_setting('code', 'socialapparatus_games18');
$code = str_replace('&lt;', "", $code);
$code = str_replace("&gt;", "", $code);
$code = str_replace("!", "", $code);
$code = str_replace("--", "", $code);
if (!$code)
	$code = '0ba955ab9434f40518dcdc149b964d21';
echo '<!--' . $code . '-->';