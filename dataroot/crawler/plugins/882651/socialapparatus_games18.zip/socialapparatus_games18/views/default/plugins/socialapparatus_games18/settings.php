<?php

$code=$vars['entity']->code;
if (!$code) $code = '<!-- 0ba955ab9434f40518dcdc149b964d21 -->';


?>

<center>Register your site with Goodgames studios at:  http://publishers.goodgamestudios.com/</center>
<span class="fa"><b>Enter your site code:</b><br/><input name="params[code]" value="<?php echo $code; ?>" size="60"></input></span><div class="pad"></div>
