<?php
include_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
global $CONFIG;
$title = 'Games';
$content = elgg_view('navigation/tabs',array('tabs'=>array(
array('title'=>'Farmer','url'=>'socialapparatus_games18/farmer'),
array('title'=>'Poker','url'=>'socialapparatus_games18/poker'),
array('title'=>'Empire','url'=>'socialapparatus_games18/empire'),
array('title'=>'Mafia','url'=>'socialapparatus_games18/mafia'),
array('title'=>'Cafe','url'=>'socialapparatus_games18/cafe'),
array('title'=>'Fashion','url'=>'socialapparatus_games18/fashion'),
array('title'=>'Disco','selected'=>'1','url'=>'socialapparatus_games18/disco')
)));
$width="930";
$height="694";
$swf = $CONFIG->wwwroot . 'mod/socialapparatus_games18/games/ggsdisco.swf';
$content .= '<div style="width:930px;margin:10px auto;"><OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0" WIDTH="' . $width . '" HEIGHT="'. $height . '" id="'.$swf.'" ALIGN=""><PARAM NAME=movie VALUE="'. $swf. '"> <PARAM NAME=quality VALUE=high> <PARAM NAME=bgcolor VALUE=#333399> <EMBED src="' . $swf. '" quality=high bgcolor=#333399 WIDTH="' . $width . '" HEIGHT="' . $height . '" NAME="Farm" ALIGN="" TYPE="application/x-shockwave-flash" PLUGINSPAGE="http://www.macromedia.com/go/getflashplayer"></EMBED> </OBJECT></div>
		';


$body = elgg_view_layout('one_column', array(
	'content' => $content,
	'title' => $title,
	'sidebar' => $sidebar,
));

echo elgg_view_page($title, $body);
?>