<?php
	register_elgg_event_handler('init','system','theme_init');

	function theme_init() 
	{
           elgg_unregister_plugin_hook_handler('prepare', 'menu:site', 'elgg_site_menu_setup');
	}
?>