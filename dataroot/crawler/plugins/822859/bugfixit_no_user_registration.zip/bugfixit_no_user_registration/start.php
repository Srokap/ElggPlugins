<?php

    /**
    * Elgg No User Registration plug-in
    * @license: GPL v 2. 
    * @author: Karl San Gabriel
    * @copyright: Bug Fix It
    * @link: www.bugfixit.com
    */

    /* The order of the plugin on the Tools Administration
       will not matter.
    */
 
    function noop() {
        global $CONFIG;
        $CONFIG->disable_registration = true;
    }
    register_elgg_event_handler('init','system','noop');

?>