<?php
  function playlist_init() {        
    add_widget_type('playlist', 'playlist', 'Playlist.com');
  }
 
  register_elgg_event_handler('init','system','playlist_init');       
?>