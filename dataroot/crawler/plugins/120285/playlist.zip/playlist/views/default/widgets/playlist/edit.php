	<p>
		<?php echo elgg_echo("Playlist.com flashvars value:"); ?>
		<input type="text" name="params[playlist]" value="<?php echo htmlentities($vars['entity']->playlist); ?>" />	
	</p>
    <p>
        <?php echo elgg_echo("Player ID for external player:"); ?>
        <input type="text" name="params[playerID]" value="<?php echo htmlentities($vars['entity']->playerID); ?>" />
        </p>
     <p>Player Width:<br />
    <select name="params[width]">
    <option value="294"><?php echo elgg_echo('Right 294'); ?></option>
    <option value="375"><?php echo elgg_echo('Middle 375'); ?></option>
    <option value="213"><?php echo elgg_echo('Left 213'); ?></option>
    </select>
    </p>
	<hr />
	<p><u>Playlist.com flashvars value:</u><br/>
    Look for this line in the code:<br />
    <b><code>config=http%3A%2F%2Fwww.profileplaylist.net%2Fext%2Fpc%2Fconfig_black_noautostart.xml&amp;mywidth=285&amp;myheight=177&amp;playlist_url=http://www.profileplaylist.net/loadplaylist.php?playlist=26711503&t=1235660023&amp;wid=os</code></b><br />
    Copy your code and paste in the box..</p><br />
    
    <p><u>Player ID for external player:</u><br />
    Look for this line in code near the bottom:<br />
   <b><code>"http://www.mysocialgroup.com/download/63918210"</code>, Take the number at the end of it and paste into the box. The number will be different from what is seen here.</b></p>
   <hr />