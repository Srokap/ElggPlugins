<?php
	 $Playlist = $vars['entity']->playlist;
	 $playerID = $vars['entity']->playerID;
	 $width = $vars['entity']->width;

	 // if the flickr id is empty, then do not sure any photos
    if($Playlist){	 
print
	 "<style type=\"text/css\">
      #images img { 
          border:none;
      }
	  .clear {
		  clear:both;
	  }
</style>

<!-- div where the images will display -->

<div style=\"text-align: center; margin-left: auto; visibility:visible; margin-right: auto; width:$widthpx;\"> <object width=\"$width\" height=\"350\"> <param name=\"movie\" value=\"http://www.profileplaylist.net/mc/mp3player_new.swf\"></param> <param name=\"allowscriptaccess\" value=\"never\"></param> <param name=\"wmode\" value=\"transparent\"></param> <param name=\"flashvars\" value=\"$Playlist\"></param> <embed style=\"width:$widthpx; visibility:visible; height:350px;\" allowScriptAccess=\"never\" src=\"http://www.profileplaylist.net/mc/mp3player_new.swf\" flashvars=\"$Playlist\" width=\"$width\" height=\"350\" name=\"mp3player\" wmode=\"transparent\" type=\"application/x-shockwave-flash\" border=\"0\"/> </object><div style=\"padding:5px; font-size:12px;\"><div style=\"width:47%; float:left; text-align:center; background-color: #000000; padding:3px;\"><a href=\"http://www.mysocialgroup.com/standalone/$playerID\" target=\"_blank\" onclick=\"window.open('http://www.mysocialgroup.com/standalone/$playerID/','popout','width=490,height=385');return false;\">Launch External<br />Player</a></div><div style=\"width:47%; float:right; text-align:center; background-color: #000000; padding: 3px;\"><a href=\"http://www.profileplaylist.net\">Create Your Free<br />Playlist</a></div><div class=\"clear\"></div></div></div>"; ?>


<?php 

    }else{
        
        echo "Click edit to embed your <a href=\"http://www.playlist.com\" target=\"_blank\">playlist.com</a> playlist";
        
    }
?>