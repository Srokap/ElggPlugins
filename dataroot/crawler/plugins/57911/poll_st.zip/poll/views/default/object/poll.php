<?php

	/**
	 * Elgg poll individual post view
	 *  
	 * @package Elggpoll
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author John Mellberg
	 * @copyright John Mellberg 2009
	 * 
	 * @uses $vars['entity'] Optionally, the poll post to view
	 */

	if (isset($vars['entity'])) {
			
		if (get_context() == "search") {
				
			//display the correct layout depending on gallery or list view
			if (get_input('search_viewtype') == "gallery") {

				//display the gallery view
            	echo elgg_view("poll/gallery",$vars);

			} else {
				
				echo elgg_view("poll/listing",$vars);

			}

		} else {
			
	?>

	<div class="poll_post">
		<div class="poll_post_body">

			<!-- display the actual poll post -->
			<?php
				
				$isPgOwner = ($vars['entity']->getOwnerEntity()->guid == $vars['user']->guid);
				$priorVote = checkForPreviousVote($vars['entity'], $vars['user']->guid);
            
        $alreadyVoted = 0;
        if ( $priorVote !== false ) {
          $alreadyVoted = 1;
        }
				
				//if user has voted, show the results
				if ( $alreadyVoted ) {
          
          // show the user's vote
					echo "<p><h2>" . elgg_echo('poll:message:vote:thanks') . "</h2></p>";
          echo "<p><h3>" . sprintf(elgg_echo('poll:display:vote'),$priorVote) . "</h3></p>";
					
				} else {
					
					//else show the voting form
					echo elgg_view('poll/forms/vote', array('entity' => $vars['entity']));
					
				}
			?>
		
		</div>

    <!-- show results -->
    <?php if ( $alreadyVoted ) { ?>
      <div class="poll_results_link_div">
          <a href="javascript:void(0)" class="poll_results_link">
            <?php echo elgg_echo('poll:hide_results'); ?>
          </a>
      </div>

      <div id="poll_results" class="poll_post_body">
        <br />
        <?php echo elgg_view('poll/results',array('entity' => $vars['entity'])); ?>
      </div>
      <br />
    <?php } else { ?>
      <?php echo "<strong>".elgg_echo('poll:results:note')."</strong>"; ?>
      <br />
    <?php } ?>

    <div class="clearfloat"></div>
			
		<p class="strapline">
			<?php
	                
				echo sprintf(elgg_echo("poll:strapline"), date("F j, Y",$vars['entity']->time_created));
				
			?>
			<?php echo elgg_echo('by'); ?> <a href="<?php echo $vars['url']; ?>pg/poll/<?php echo $vars['entity']->getOwnerEntity()->username; ?>"><?php echo $vars['entity']->getOwnerEntity()->name; ?></a> &nbsp; 
			<!-- display the comments link -->
			<?php
				//get the number of responses
				$num_responses = $vars['entity']->countAnnotations('vote');
				
				echo "Responses (" . $num_responses . ") ";
				
				//get the number of comments
				$num_comments = elgg_count_comments($vars['entity']);
			?>
			<a href="<?php echo $vars['entity']->getURL(); ?>"><?php echo sprintf(elgg_echo("comments")) . " (" . $num_comments . ")"; ?></a>		
			<!-- display tags -->
			<p class="tags">
			<?php
				echo elgg_view('output/tags', array('tags' => $vars['entity']->tags));			
			?>
			</p>
		</p>
		
		<div class="clearfloat"></div>
						
		<!-- display edit options if it is the poll post owner -->
		<p class="options">
			<?php
	
				if ($vars['entity']->canEdit()) {
					
			?>
			<a href="<?php echo $vars['url']; ?>mod/poll/edit.php?pollpost=<?php echo $vars['entity']->getGUID(); ?>"><?php echo elgg_echo("edit"); ?></a>  &nbsp; 
			<?php
					
					echo elgg_view("output/confirmlink", array(
									'href' => $vars['url'] . "action/poll/delete?pollpost=" . $vars['entity']->getGUID(),
									'text' => elgg_echo('delete'),
									'confirm' => elgg_echo('deleteconfirm'),
									));
	
					// Allow the menu to be extended
					echo elgg_view("editmenu",array('entity' => $vars['entity']));
					
				}
			
			?>
		</p>
	</div>

<?php

			// If we've been asked to display the full view
			if (isset($vars['full']) && $vars['full'] == true) {
				echo elgg_view_comments($vars['entity']);
			}
				
		}

	}
	
function checkForPreviousVote($poll, $user_guid)
{
    $votes = get_annotations($poll->getGUID(), "", "", 'vote', "", $user_guid);
		
		if ( $votes && count($votes) > 0 ) {
      return $votes[0]->value;
    }
		
		return false;
}

?>

<script type="text/javascript">

  $(document).ready(function () {

    // click function to toggle panel
    $('a.poll_results_link').click(function () {

      state = state ? 0 : 1; // toggle state
      $('div#poll_results').slideToggle("medium");
      if ( state ) {
        $('a.poll_results_link').html("<?php echo elgg_echo('poll:hide_results'); ?>");
      } else {
        $('a.poll_results_link').html("<?php echo elgg_echo('poll:show_results'); ?>");
      }

      return false;
    });

    var state = 1;
  });

</script>
