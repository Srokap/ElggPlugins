<?php

	/**
	 * Elgg poll CSS extender
	 * 
	 * @package Elggpoll
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author John Mellberg
	 * @copyright John Mellberg 2009
	 */

?>

.poll_post p.tags {
	background:transparent url(<?php echo $vars['url']; ?>_graphics/icon_tag.gif) no-repeat scroll left 2px;
	margin:0 0 0 35px;
	padding:0pt 0pt 0pt 16px;
	min-height:22px;
}


.input-radio {
	border:none;
	text-align:left;
	vertical-align:middle;
}

#progress_indicator {
	width:400px;
	padding: 10px;
}
	
#progressBarContainer {
	height:12px;
	width:100%;
	border: 1px #D9541E solid;
}

