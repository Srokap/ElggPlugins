<?php

	/**
	 * Elgg poll not found page
	 * 
	 * @package Elggpoll
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author John Mellberg
	 * @copyright John Mellberg 2009
	 */
?>

	<p>
		<?php

			echo elgg_echo("poll:notfound");
		
		?>
	</p>