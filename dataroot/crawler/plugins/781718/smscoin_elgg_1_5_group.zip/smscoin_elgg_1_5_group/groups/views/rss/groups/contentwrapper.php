<?php

	echo $vars['body'];

?>