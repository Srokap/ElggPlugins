<?php
	/**
	 * @package ElggPages
	 * @author smscoin.com
	 * @copyright smscoin.com 2009
	 * @link http://smscoin.com/
	 */

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	global $CONFIG;
	
	// Get the current page's owner
	$page_owner = page_owner_entity();
	if ($page_owner === false || is_null($page_owner)) {
		$page_owner = $_SESSION['user'];
		set_page_owner($_SESSION['guid']);
	}
		    
	$points = intval(get_input("points"));
	$save = get_input("save");
	$drop = get_input("drop");
	
	$title = "SmsCoin Groups Config";

	$res = get_data_row("SHOW TABLES LIKE '{$CONFIG->dbprefix}smscoin_groups'");
	
	if(!$res) {
		update_data("CREATE TABLE IF NOT EXISTS {$CONFIG->dbprefix}smscoin_groups (
			id int,
			points int unsigned default 100,
			PRIMARY KEY (id)
			)
		");
		update_data("INSERT IGNORE INTO {$CONFIG->dbprefix}smscoin_groups (id, points)
			VALUES (1, 100)
		");
	}
	if($save == 'Save') {
		update_data("UPDATE {$CONFIG->dbprefix}smscoin_groups SET points = ".$points);
		$info = "Saved";
	}
	$res = get_data_row("SELECT * FROM {$CONFIG->dbprefix}smscoin_groups");
	if($drop == 'Drop Tables') {
		update_data("DROP TABLE {$CONFIG->dbprefix}smscoin_groups");
		$info = "Droped";
	}
	// Get objects
	$objects = "
		<div align = 'center' class = 'post_to_wire'>
			<h3>$info</h3><br /><br />
			<form action = '' method = 'post'>
				<table>
					<tr>
						<td>
							<p>".elgg_echo('SMSCOIN_POINTS').":&nbsp;&nbsp;&nbsp;</p>
						</td>
						<td>
							<input type = 'text' value = '$res->points' name = 'points' />
							
						</td>
					</tr>
					<tr>
						<td celspan = '2'>
							<br /><br /><input type = 'submit' value = 'Save' name = 'save' />&nbsp;&nbsp;&nbsp;<input type = 'submit' value = 'Drop Table' name = 'drop' />
						</td>
					</tr>
				</table>
			</form>
		</div>
	";
	
	set_context($context);
	
	$body = elgg_view_title($title);
	$body .= $objects;
	$body = elgg_view_layout('two_column_left_sidebar','',$body);
	
	// Finally draw the page
	page_draw($title, $body);

?>
