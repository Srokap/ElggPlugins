SmsCoin Group

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
All information within this software product is the
intellectual property of SmsCoin, Israel.

Given software can be used by http://smscoin.com/ clients
for sms:key service only. Any other use of the software
is violation of the company's right and will be pursued
according to operating law.

SmsCoin. Israel will not be held liable for any loss
or damage of any kind as a result of using this software,
including any lost revenues and/or data.
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-


 To use this module preset module smscoin_elgg_1.5_balance is necessary


 Installation process:

	1. Disconnect module Groups.
	2. Save /mod/groups module and change it with groups module from downloaded archive.
	3. Activate module Groups in your website admin.
	4. Open module configuration Tools->Groups->Groups SmsCoin Config and specify the cost
		of creating group in credits.

 How it works:

 Module enables user to create group for credits in user's balance which are replenished by smscoin_elgg_1.5_balance module via SMS.



Uninstall:
	1. Open module configuration Tools->Groups->Groups SmsCoin Config and click the Drop Table button.
	2. Disconnect module.
	3. Replace folder /mod/groups/ with the saved one at the time of the installation.

