<?php

	$hebrew = array(
	
		/**
		 * Menu items and titles
		 */
	
		'tinymce:remove' => "החלף ביון עורך ויזואלי ועורך פשוט",
	
	);
					
	add_translation("he",$hebrew);

?>