Notes:

* An extended tinymce plugin that does not incorporate a browse, upload and embed facility. Suitable for people that want to use the default Elgg upload/embed feature but like more facilities than the basic and simple tinymce.

Instructions:
Remove default Elgg tinymce from mod folder, put this tinymce into mod folder then enable it in admin panel.

