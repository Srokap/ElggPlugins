<?php

    /**
     * Oxford Blue theme
     * 
	 */
     
     /**
	 * Initialise the Oxford Blue theme 
	 *
	 */
	function oxfordblue_init(){

		
		/**
		 * Okay, so firstly, we're going to extend the standard CSS with our theme CSS: 
		 */
		
		extend_view('css','oxfordblue/css');
		
		/**
		 * CSS has this handy attribute of letting you override styles on the fly, so
		 * we can get our desired changes by adding more rules onto the end of the CSS
		 * file. It's marginally less efficient, but better than having to rewrite the
		 * main CSS file all over again.
		 * 
		 * This next bit is even sneakier though.
		 * 
		 * I want to take the default Elgg blue links and turn them into the depper blue
		 * we're using for this theme. Now, I *could* go through and rewrite them all,
		 * or I could search and replace.
		 * 
		 * Yep, you can search and replace output from the Elgg views at the last minute.
		 * Here's how:
		 * 
		 * Register a function to the 'display' 'view' plugin hook. Then see the oxfordblue_blue
		 * function, which will do the actual search and replace ...
		 */
		
		register_plugin_hook('display','view','oxfordblue_blue');
		
    }
    
    /**
     * Our search and replace function.
     *
     * These are the default parameters that get passed to any function triggered via
     * a plugin hook.
     */
    function oxfordblue_blue($hook, $entity_type, $returnvalue, $params) {
    	
    	/**
    	 * $returnvalue contains the output of the view. So all we have to do is perform our
    	 * modifications and then return it again. Here I'm taking the lighter blue,
    	 * #4690d6, and turning it into #002b5f, the deeper blue.
    	 */
    	
    	$returnvalue = str_replace('4690d6','002b5f',$returnvalue);
    	
    	/**
    	 * And back it goes!
    	 */
    	
    	return $returnvalue;
    	
    }
	
	// Register the init function
	register_elgg_event_handler('init','system','oxfordblue_init');
	
?>