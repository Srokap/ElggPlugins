<?php

?>

body {
	background: url(<?php echo $vars['url']; ?>mod/theme_oxfordblue/graphics/oxfordbk.jpg) repeat-x center top;
	/*background: none; */
	background-color: #002b5f;
}

#layout_header,
#page_container,
#page_wrapper {
	background: none;
	border: none;
}

#page_wrapper {
	margin-top: 160px;
	width: 1000px;
}

#layout_canvas {
	border: 0px;
	border: none;
}

#page_container {
	background: none;
}

#two_column_left_sidebar_maincontent,
#two_column_left_sidebar,
#two_column_right_sidebar_maincontent,
#two_column_right_sidebar {
	border: 1px;
	border-color: #888;
	border-style: solid;
}

#wrapper_header h1 a {
	color: #fff;
	font-family: georgia, times new roman, serif;
	text-decoration: none;
	font-size: 2em;
	font-weight: normal;
	font-style: normal;
}

#spotlight {
	display: none;
}

#layout_footer {
	background: none;
}

.messages {
    background:#bccfe6;
	border:4px solid #002b5f;
}
