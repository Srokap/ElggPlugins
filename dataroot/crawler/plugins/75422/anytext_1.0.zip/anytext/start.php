<?php
/**
 * Anytext plugin.
 * Allows users to enter any text or html into a widget
 * 
 * @package AnyText
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Brett Profitt <brett.profitt@eschoolconsultants.com>
 * @copyright Brett Profitt 2008
 * @link http://www.eschoolconsultants.com
 */

function anytext_init() {
	add_widget_type('anytext', elgg_echo('anytext:title'), elgg_echo('anytext:description'), 'all', true);
}

register_elgg_event_handler('init','system','anytext_init');
?>