<?php
/**
 * Anytext plugin.
 * Allows users to enter any text or html into a widget
 * 
 * @package AnyText
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Brett Profitt <brett.profitt@eschoolconsultants.com>
 * @copyright Brett Profitt 2008
 * @link http://www.eschoolconsultants.com
 */

$english = array(
	'anytext:title' => 'Text Box',
	'anytext:no_title' => "No Title",
	'anytext:no_body' => "No Content.",
);
				
add_translation("en",$english);