<?php
/**
 * Simple CSS
 */
?>

/* ***************************************
	SIMPLIE
*************************************** */
.simplepie-heading {
	text-align: center;
	margin-bottom: 8px;
}

.simplepie-list img {
	max-width: 100%;
}
