<?php
/*****************************************************************************
 * Phloor SocialSharePrivacy                                                 *
 *                                                                           *
 * Copyright (C) 2011, 2012 Alois Leitner                                    *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php
$base_url = elgg_get_site_url();
//$css_path = $base_url . 'mod/phloor_socialshareprivacy/vendors/socialshareprivacy/socialshareprivacy/socialshareprivacy.css';

$image_url     = $base_url  . 'mod/phloor_socialshareprivacy/vendors/socialshareprivacy/socialshareprivacy/images/';
$fb_dummy      = $image_url . 'dummy_facebook_en.png';
$twitter_dummy = $image_url . 'dummy_twitter.png';
$gplus_dummy   = $image_url . 'dummy_gplus.png';

$fb_array      = array('Facebook');
$twitter_array = array('Twitter');
$gplus_array   = array('Google+');

$fb_strings = array(
    'txt_info'        => elgg_echo('phloor_socialshareprivacy:services:txt_info', $fb_array),
    'txt_fb_off'      => elgg_echo('phloor_socialshareprivacy:services:txt_off',  $fb_array),
    'txt_fb_on'       => elgg_echo('phloor_socialshareprivacy:services:txt_on',   $fb_array),
);
$twitter_strings = array(
    'txt_info'        => elgg_echo('phloor_socialshareprivacy:services:txt_info', $twitter_array),
    'txt_twitter_off' => elgg_echo('phloor_socialshareprivacy:services:txt_off',  $twitter_array),
    'txt_twitter_on'  => elgg_echo('phloor_socialshareprivacy:services:txt_on',   $twitter_array),
);
$gplus_strings = array(
    'txt_info'        => elgg_echo('phloor_socialshareprivacy:services:txt_info', $gplus_array),
    'txt_gplus_off'   => elgg_echo('phloor_socialshareprivacy:services:txt_off',  $gplus_array),
    'txt_gplus_on'    => elgg_echo('phloor_socialshareprivacy:services:txt_on',   $gplus_array),
);

/*
 * GOOGLE+ - END
 **/
$enable_fb      = elgg_get_plugin_setting('enable_facebook', 'phloor_socialshareprivacy');
$enable_twitter = elgg_get_plugin_setting('enable_twitter',  'phloor_socialshareprivacy');
$enable_gplus   = elgg_get_plugin_setting('enable_gplus',    'phloor_socialshareprivacy');


$status_fb      = (strcmp("true", $enable_fb)      == 0) ? "on" : "off";
$status_twitter = (strcmp("true", $enable_twitter) == 0) ? "on" : "off";
$status_gplus   = (strcmp("true", $enable_gplus)   == 0) ? "on" : "off";

$services_js = <<<JS
facebook : {
	'status'     : '$status_fb',
    'dummy_img'  : '$fb_dummy',
    'txt_info'   : '{$fb_strings['txt_info']}',
    'txt_fb_off' : '{$fb_strings['txt_fb_off']}',
    'txt_fb_on'  : '{$fb_strings['txt_fb_on']}',
    'language'   : 'en',
    'action'     : 'recommend'
},
twitter : {
	'status'          : '$status_twitter',
    'dummy_img'       : '$twitter_dummy',
    'txt_info'        : '{$twitter_strings['txt_info']}',
    'txt_twitter_off' : '{$twitter_strings['txt_twitter_off']}',
    'txt_twitter_on'  : '{$twitter_strings['txt_twitter_on']}',
    'language'        : 'en'
},
gplus : {
	'status'        : '$status_gplus',
    'dummy_img'     : '$gplus_dummy',
    'txt_info'      : '{$gplus_strings['txt_info']}',
    'txt_gplus_off' : '{$gplus_strings['txt_gplus_off']}',
    'txt_gplus_on'  : '{$gplus_strings['txt_gplus_on']}',
    'language'      : 'en'
}
JS;

?>

<script type="text/javascript">
  $(function($){
    if($('#phloor-socialshareprivacy').length > 0){
      $('#phloor-socialshareprivacy').socialSharePrivacy({
	    services : {
	    	<?php echo $services_js; ?>
	    },
	    'txt_help'          : '<?php echo elgg_echo('phloor_socialshareprivacy:txt_help'); ?>',
        'settings_perma'    : '<?php echo elgg_echo('phloor_socialshareprivacy:settings_perma'); ?>'
        <?php //'css_path'        : '<php echo $css_path; >' <- loading slowly ?>
	  });
    }
  });
</script>

<?php

