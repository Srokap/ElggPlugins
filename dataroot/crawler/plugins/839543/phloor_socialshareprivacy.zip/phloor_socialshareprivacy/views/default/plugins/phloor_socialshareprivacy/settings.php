<?php
/*****************************************************************************
 * Phloor Social Share Privacy                                               *
 *                                                                           *
 * Copyright (C) 2011, 2012 Alois Leitner                                    *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php

$enable_facebook  = $vars['entity']->enable_facebook;
$enable_twitter   = $vars['entity']->enable_twitter;
$enable_gplus     = $vars['entity']->enable_gplus;


if (strcmp('true', $enable_facebook) != 0) {
	$enable_facebook = 'false';
}
if (strcmp('true', $enable_twitter) != 0) {
	$enable_twitter = 'false';
}
if (strcmp('true', $enable_gplus) != 0) {
	$enable_gplus = 'false';
}

?>
<?php

$image_url     = elgg_get_site_url()  . 'mod/phloor_socialshareprivacy/vendors/socialshareprivacy/socialshareprivacy/images/';
$fb_dummy      = $image_url . 'dummy_facebook_en.png';
$twitter_dummy = $image_url . 'dummy_twitter.png';
$gplus_dummy   = $image_url . 'dummy_gplus.png';

// hide phloor/elgg release and version metadata
echo elgg_view('phloor/input/vendors/prettycheckboxes/checklist', array(
	'options' => array(
    	'enable_facebook'  => array(
        	'name'  => 'params[enable_facebook]',
        	'value' => $enable_facebook,
            'label' => elgg_echo('Facebook'),
            'description' => '',
            'image' => "<img src=\"{$fb_dummy}\" />",
        ),
    	'enable_twitter' => array(
        	'name'  => 'params[enable_twitter]',
        	'value' => $enable_twitter,
            'label' => elgg_echo('Twitter'),
            'description' => '',
            'image' => "<img src=\"{$twitter_dummy}\" />",
        ),
    	'enable_gplus' => array(
        	'name'  => 'params[enable_gplus]',
        	'value' => $enable_gplus,
            'label' => elgg_echo('Google+'),
            'description' => '',
            'image' => "<img src=\"{$gplus_dummy}\" />",
        ),
    ),
));
