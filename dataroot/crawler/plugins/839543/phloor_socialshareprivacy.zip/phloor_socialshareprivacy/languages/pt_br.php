<?php

// Gerado pela extensão 'translationbrowser'  20120103-01:23:00 AM

$portugues_brasileiro = array(
	 'phloor_socialshareprivacy'  =>  "Compartilhamento social e privacidade" ,
	 'phloor_socialshareprivacy:settings_perma'  =>  "Autorização permanente:" ,
	 'phloor_socialshareprivacy:txt_help'  =>  "Se você ativar esses campos com um clique você permitirá o intercâmbio de informações com Facebook, Twitter ou Google que poderá armazenar dados em servidores nos Estados Unidos da América. Clique em na letra ' i ' para mais informações." ,

     'phloor_socialshareprivacy:services:txt_info' => "2 Clique para mais proteção de privacidade de dados: somente se você clicar o botão é ativado e você pode criar sua recomendação no %s. Mesmo quando apenas a informação ativada é enviado a terceiros." ,
	 'phloor_socialshareprivacy:services:txt_off'  => "não conectado ao %s" ,
	 'phloor_socialshareprivacy:services:txt_on'   =>  "conectado ao %s" ,

/*
	 'phloor_socialshareprivacy:services:facebook:txt_info'  =>  "2 Clique para mais proteção de privacidade de dados: somente se você clicar o botão é ativado e você pode criar sua recomendação no Facebook. Mesmo quando apenas a informação ativada é enviado a terceiros." ,
	 'phloor_socialshareprivacy:services:facebook:txt_fb_off'  =>  "não conectado ao Facebook" ,
	 'phloor_socialshareprivacy:services:facebook:txt_fb_on'  =>  "conectado ao Facebook" ,
	 'phloor_socialshareprivacy:services:twitter:txt_info'  =>  "2 Clique para mais proteção de privacidade de dados: somente se você clicar o botão é ativado e você pode criar sua recomendação no Twitter. Mesmo quando apenas a informação ativada é enviado a terceiros." ,
	 'phloor_socialshareprivacy:services:twitter:txt_twitter_off'  =>  "não conectado ao Twitter" ,
	 'phloor_socialshareprivacy:services:twitter:txt_twitter_on'  =>  "conectado ao Twitter" ,
	 'phloor_socialshareprivacy:services:gplus:txt_info'  =>  "2 Clique para mais proteção de privacidade de dados: somente se você clicar o botão é ativado e você pode criar sua recomendação no Google+. Mesmo quando apenas a informação ativada é enviado a terceiros." ,
	 'phloor_socialshareprivacy:services:gplus:txt_gplus_off'  =>  "não conectado ao Google+" ,
	 'phloor_socialshareprivacy:services:gplus:txt_gplus_on'  =>  "conectado ao Google+"
*/
);

add_translation('pt_br', $portugues_brasileiro);

?>