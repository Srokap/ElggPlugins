<?php

/**
 * Elgg online_mark plugin
 * 
 * @package online_mark_04 for elgg 1.5
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Dirk Pelzer 
 */


function online_mark_init() {}

function get_online_mark ($guid)
{
	global $CONFIG;	
	
     	//what do you want to display if online?
	$online = '<img class="user_mini_avatar" border="0" title="online" align="top" height="16" width="16" src="' . $CONFIG->url . 'mod/online_mark/graphics/online_mark.gif" />';

	//what do you want to display if offline?
	$offline = '<img class="user_mini_avatar" border="0" title="offline" align="top" height="16" width="16" src="' . $CONFIG->url . 'mod/online_mark/graphics/offline_mark.gif" />';

   	//get data of guid
	$options = get_data("select last_action, code from ".$CONFIG->dbprefix."users_entity WHERE guid=".$guid);
	foreach ($options as $option)
	{
   	   $last_ac .=$option->last_action;
	   $code .=$option->code;
	}

	//get online mark settings
      $timeout = get_plugin_setting('timeout','online_mark');
		
	//check if online
	$diff = time() - $last_ac;

	if (!empty($code) AND $diff <=$timeout)
	{
	    return $online;      
	}
	else
	{
	    return $offline; 
	}
}
 
 
// Make sure the plugin has been registered
register_elgg_event_handler('init','system','online_mark_init');

?>