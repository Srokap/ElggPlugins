<?php

$german = array(
/**
 * Time strings
 */
'friendlytime:weeks' => "vor etwa 2 Wochen",
'friendlytime:weeks:singular' => "letzte Woche",
'friendlytime:date' => "j F Y",

'friendlytime:month:01' => 'Januar',
'friendlytime:month:02' => 'Februar',
'friendlytime:month:03' => 'März',
'friendlytime:month:04' => 'April',
'friendlytime:month:05' => 'Mai',
'friendlytime:month:06' => 'Juni',
'friendlytime:month:07' => 'Juli',
'friendlytime:month:08' => 'August',
'friendlytime:month:09' => 'September',
'friendlytime:month:10' => 'Oktober',
'friendlytime:month:11' => 'November',
'friendlytime:month:12' => 'Dezember',
);

add_translation("de", $german);