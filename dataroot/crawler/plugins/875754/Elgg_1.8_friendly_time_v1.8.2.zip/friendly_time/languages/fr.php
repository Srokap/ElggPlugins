<?php

$french = array(
/**
 * Time strings
 */
'friendlytime:weeks' => "il y a environ 2 semaines",
'friendlytime:weeks:singular' => "la semaine dernière",
'friendlytime:date' => "j F Y",

'friendlytime:month:01' => 'Janvier',
'friendlytime:month:02' => 'Février',
'friendlytime:month:03' => 'Mars',
'friendlytime:month:04' => 'Avril',
'friendlytime:month:05' => 'Mai',
'friendlytime:month:06' => 'Juin',
'friendlytime:month:07' => 'Juillet',
'friendlytime:month:08' => 'Août',
'friendlytime:month:09' => 'Septembre',
'friendlytime:month:10' => 'Octobre',
'friendlytime:month:11' => 'Novembre',
'friendlytime:month:12' => 'Décembre',
);

add_translation("fr", $french);
