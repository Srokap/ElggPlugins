
.login-as-topbar {
	height: 18px;
}

.login-as-arrow {
	vertical-align: top;
	color: white;
	font-weight: bold;
}

.login-as-arrow:hover {
	color: white;
}
