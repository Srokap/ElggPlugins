<?php
/**
 * Tag cloud English language file
 */

$english = array(
	'tagcloud:widget:title' => 'Tag Cloud',
	'tagcloud:widget:description' => 'Tag cloud',
	'tagcloud:widget:numtags' => 'Number of tags to show',
);

add_translation('en', $english);
