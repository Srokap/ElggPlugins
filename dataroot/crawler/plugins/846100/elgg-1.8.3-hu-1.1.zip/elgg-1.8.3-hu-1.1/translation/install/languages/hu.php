<?php
/**
 * Installer Hungarian Language
 *
 * @package ElggLanguage
 * @subpackage Installer
 */

$hungarian = array(
	'install:title' => 'Elgg telepítő',
	'install:welcome' => 'Üdvözöljük!',
	'install:requirements' => 'Alapkövetelemények ellenőrzése',
	'install:database' => 'Adatbázis telepítése',
	'install:settings' => 'Honlap konfigurálása',
	'install:admin' => 'Rendszergazda létrehozása',
	'install:complete' => 'Telepítés befejezése',

	'install:welcome:instructions' => "A rendszer telepítése 6 egyszerű lépésből áll, amiből ez az első, az üdvözlőképernyő!

Ha még nem tette volna, olvassa el a mellékelt telepítési útmutatót (vagy kattintson az oldal alján található hivatkozásra).

Ha készen áll a folytatásra, kattintson a 'Tovább' gombra.",
	'install:requirements:instructions:success' => "A szerver beállításai megfelelőek.",
	'install:requirements:instructions:failure' => "A szerver beállításai nem megfelelőek. Frissítse az oldalt, miután elhárította az alábbi problémákat. Ha további segítségre lenne szüksége, használja az oldal alján találálható hivatkozásokat.",
	'install:requirements:instructions:warning' => "A szerver beállításai megfelelőek ugyan, de legalább egy figyelmeztetés keletkezett. Nézze át a telepítési hibákkal foglalkozó oldalt a gyakori hibák kiküszöböléséhez.",

	'install:require:php' => 'PHP',
	'install:require:rewrite' => 'Webszerver',
	'install:require:settings' => 'Beállítások fájl',
	'install:require:database' => 'Adatbázis',

	'install:check:root' => 'A webszerver jogosultságai nincsenek megfelelően beállítva, így a .htaccess fájl létrehozása sikertelen volt a rendszer mappájában. Ennek két lehetséges megoldása van:

		1. Állítsa át a mappa hozzáférését

		2. Hozzon létre egy .htaccess fájlt a htaccess_dist alapján',

	'install:check:php:version' => 'Minimum %s, vagy e feletti verziójú PHP szükséges. A szerverre telepített verzió jelenleg a(z) %s.',
	'install:check:php:extension' => 'Szükséges PHP kiegészítő: %s.',
	'install:check:php:extension:recommend' => 'Érdemes telepíteni a(z) %s PHP kiegészítőt.',
	'install:check:php:open_basedir' => 'Az open_basedir PHP direktíva akadályozhatja a fájlok lementését az adatkönyvtárba.',
	'install:check:php:safe_mode' => 'A PHP biztonságos módban való futtatása nem ajánlott, mert problémákat okozhat a rendszer működése során.',
	'install:check:php:arg_separator' => 'Az arg_separator.output értéke & kell hogy legyen, de ez jelenleg %s',
	'install:check:php:register_globals' => 'A register globals válzotót ki kell kapcsolni.',
	'install:check:php:session.auto_start' => "A session.auto_start változót ki kell kapcsolni a rendszer működtetéséhez. Változtassa meg a szerver beállításait, vagy adja hozzá a .htaccess fájlhoz ezt a direktívát.",

	'install:check:enginedir' => 'A webszerver jogosultságai nincsenek megfelelően beállítva, így a settings.php fájl létrehozása sikertelen volt az engine mappában. Ennek két lehetséges megoldása van:

		1. Állítsa át az engine mappa hozzáférését

		2. Hozzon létre egy settings.php fájlt a settings.example.php alapján, és kövesse a benne található utasításokat az adatbázis paramétereinek beállításához',
	'install:check:readsettings' => 'A beállítások fájl létezik ugyan az engine mappában, de a szerver nem tudja olvasni. Javasoljuk hogy törölje a fájlt vagy változtassa meg jogosultságait hogy olvasható legyen.',

	'install:check:php:success' => "A webszerver PHP beállításai megfelelőek.",
	'install:check:rewrite:success' => 'Az átírási szabály ellenőrzése sikeres volt.',
	'install:check:database' => 'Az adatbázisra vonatkozó követelmények ellenőrzése az adatbázis betöltésekor fog sor kerülni.',

	'install:database:instructions' => "Ha idáig még nem készített volna adatbázist az Elgg számára, most megteheti. Ezután töltse ki az alábbi adatokat az adatbázis beállításához.",
	'install:database:error' => 'Hiba történt az adatbázis létrehozása során. A telepítés nem folytatható, amíg a felmerüt problémák fennállnak. Amennyiben segítségre lenne szüksége, kattintson az alábbi hivatkozásra a telepítési hibákkal foglalkzó oldal megtekintéséhez, vagy kérjen segítséget a közösségi fórumon.',

	'install:database:label:dbuser' =>  'Adatbázis felhasználóneve',
	'install:database:label:dbpassword' => 'Adatbázis jelszava',
	'install:database:label:dbname' => 'Adatbázis neve',
	'install:database:label:dbhost' => 'Adabázis kiszolgálója',
	'install:database:label:dbprefix' => 'Adatbázis tábláinak előtagja',

	'install:database:help:dbuser' => 'Olyan felhasználó, aki teljeskörű hozzáféréssel rendelkezik az Elgg számára létrehozott MySQL adatbázishoz',
	'install:database:help:dbpassword' => 'A fenti adatbázis felhasználói fiókhoz tartozó jelszó',
	'install:database:help:dbname' => 'Az Elgg számára létrehozott adatbázis neve',
	'install:database:help:dbhost' => 'A MySQL szerver kiszolgálójának a neve (ez általában a localhost)',
	'install:database:help:dbprefix' => "Az Elgg tábláinak megkülönbözetésére szolgáló előtag (ez általában az elgg_)",

	'install:settings:instructions' => 'Szükségünk van néhány információra a honlappal kapcsolatban. He idáig még nem hozta létre az <a href="http://docs.elgg.org/wiki/Data_directory" target="_blank">adatok mappáját</a>, akkor kérem tegye meg most.',

	'install:settings:label:sitename' => 'Honlap neve',
	'install:settings:label:siteemail' => 'Honlap e-mail címe',
	'install:settings:label:wwwroot' => 'Honlap URL-je',
	'install:settings:label:path' => 'Rendszer mappája',
	'install:settings:label:dataroot' => 'Adatok mappája',
	'install:settings:label:language' => 'Honlap nyelve',
	'install:settings:label:siteaccess' => 'Alapértelmezett hozzáférés',
	'install:label:combo:dataroot' => 'Az adatok tárolására szolgáló mappa létrehozása',

	'install:settings:help:sitename' => 'Az új Elgg honlap neve',
	'install:settings:help:siteemail' => 'A felhasználókkal való kommunikációra használt e-mail cím',
	'install:settings:help:wwwroot' => 'A honlap webcíme (a rendszer általában helyesen állítja be)',
	'install:settings:help:path' => 'Az Elgg mappájának elérési útvonala (a rendszer általában helyesen állítja be)',
	'install:settings:help:dataroot' => 'Az a mappa, amit Ön azért hozott létre, hogy a rendszer oda menthesse a fájljait (a mappa hozzáférhetőségét a \'Tovább\' gombra való kattintáskor ellenőrzi a rendszer)',
	'install:settings:help:dataroot:apache' => 'Rábízhatja a rendszerre ennek a könyvtárnak a létrehozását, vagy begépelheti az elérési útvonalat, ha már korábban létrehozta (a mappa hozzáférhetőségét a \'Tovább\' gombra való kattintáskor ellenőrzi a rendszer)',
	'install:settings:help:language' => 'A honlapon használt alapértelmezett nyelv',
	'install:settings:help:siteaccess' => 'A felhasználók által létrehozott tartalmakhoz való alapértelmezett hozzáférés szintje',

	'install:admin:instructions' => "Itt az ideje létrehozni a rendszergazdai fiókot.",

	'install:admin:label:displayname' => 'Megjelenített név',
	'install:admin:label:email' => 'E-mail cím',
	'install:admin:label:username' => 'Felhasználónév',
	'install:admin:label:password1' => 'Jelszó',
	'install:admin:label:password2' => 'Jelszó még egyszer',

	'install:admin:help:displayname' => 'Ezzel a névvel fog szerepelni a honlapon',
	'install:admin:help:email' => '',
	'install:admin:help:username' => 'A belépéshez használt felhasználónév',
	'install:admin:help:password1' => "A jelszónak legalább %u karakter hosszúnak kell lennie",
	'install:admin:help:password2' => 'A jelszót az ellenőrzés miatt újra be kell gépelnie',

	'install:admin:password:mismatch' => 'A jelszavak nem egyeznek.',
	'install:admin:password:empty' => 'Nem lehet üres jelszót megadni.',
	'install:admin:password:tooshort' => 'A megadott jelszó túl rövid',
	'install:admin:cannot_create' => 'A rendszergazda létrehozása sikertelen.',

	'install:complete:instructions' => 'Az Ön Elgg honlapja elkészült. Kattintson az alábbi gombra a megtekintéséhez.',
	'install:complete:gotosite' => 'Honlap megtekintése',

	'InstallationException:UnknownStep' => 'Ismeretlen lépés a telepítés során: %s',

	'install:success:database' => 'Az adatbázis sikeresen telepítve lett.',
	'install:success:settings' => 'A honlap beállításai mentésre kerültek.',
	'install:success:admin' => 'A rendszergazdai fiók elkészült.',

	'install:error:htaccess' => 'A .htaccess fájl létrehozása sikertelen',
	'install:error:settings' => 'A honlap beállításait tartalmazó fájl létrehozása sikertelen',
	'install:error:databasesettings' => 'Az adatbázishoz való csatlakozás a megadott adatokkal sikertelen volt.',
	'install:error:oldmysql' => 'Minimum 5.0, vagy e feletti verziójú MySQL szükséges. A szerverre telepített verzió jelenleg a(z) %s.',
	'install:error:nodatabase' => '%s adatbázis elérése sikertelen. Lehet hogy nem is létezik?',
	'install:error:cannotloadtables' => 'Az adatbázis tábláinak betöltése sikertelen',
	'install:error:tables_exist' => 'Már vannak Elgg táblák az adatbázisban. Törölheti ezeket a táblákat, vagy indítsa újra a telepítőt, ami majd megpróbálja használni őket. A telepítő újraindításához törölje ki a \'?step=database\' részt a böngésző URL sávjából, majd nyomja meg az \'Enter\'-t.',
	'install:error:readsettingsphp' => 'Az engine/settings.example.php olvasása sikertelen',
	'install:error:writesettingphp' => 'Az engine/settings.php írása sikertelen',
	'install:error:requiredfield' => '%s szükséges',
	'install:error:datadirectoryexists' => 'Az adatok tárolására szolgáló %s nevű mappa nem létezik.',
	'install:error:writedatadirectory' => 'Az adatok tárolására szolgáló %s nevű mappa nem írható.',
	'install:error:locationdatadirectory' => 'Az adatok tárolására szolgáló %s nevű mappának biztonsági okokból a rendszer mappáján kívül kell elhelyezkednie.',
	'install:error:emailaddress' => '%s nem egy valós e-mail cím',
	'install:error:createsite' => 'A honlap létrehozása sikertelen.',
	'install:error:savesitesettings' => 'A honlap beállításainak mentése sikertelen',
	'install:error:loadadmin' => 'A rendszergazda betöltése sikertelen.',
	'install:error:adminaccess' => 'A rendszergazdai jogosultságok megadása az új felhasználónak sikertelen volt.',
	'install:error:adminlogin' => 'Az új rendszergazda beléptetése sikertelen.',
	'install:error:rewrite:apache' => 'Úgy véljük a szerverén Apache webszerver fut.',
	'install:error:rewrite:nginx' => 'Úgy véljük a szerverén Nginx webszerver fut.',
	'install:error:rewrite:lighttpd' => 'Úgy véljük a szerverén Lighttpd webszerver fut.',
	'install:error:rewrite:iis' => 'Úgy véljük a szerverén IIS webszerver fut.',
	'install:error:rewrite:allowoverride' => "Az átírási szabály ellenőrzés sikertelen, amit valószínűleg az okoz, hogy az AllowOverride nincs All állapotra állítva a rendszer mappájára vonatkozóan. Ez megakadályozza az Apache webszerverét a .htaccess fájl feldolgozásában, ami az átírási szabályokat tartalmazza.
				\n\nA másik lehetséges magyarázat az, hogy az Apache webszerveren alias van beállítva a rendszer mappájára. Ez esetben módosítani kell a RewriteBase sorát a .htaccess fájlban. További segítséget a rendszer mappájában található .htaccess fájlban talál.",
	'install:error:rewrite:htaccess:write_permission' => 'A webszerverének nincs jogosultsága létrehozni a .htaccess fájlt a rendszermappában. Hozza létre manuálisan és másolja bele a htaccess_dist tartalmát, vagy módosítsa a mappára vonatkozó jogosultságokat.',
	'install:error:rewrite:htaccess:read_permission' => 'A rendszer mappájában ugyan van egy .htaccess fájl, azonban a webszervernek nincs jogultsága az olvasásához.',
	'install:error:rewrite:htaccess:non_elgg_htaccess' => 'A rendszer mappájában van egy .htaccess fájl, ezt azonban nem a rendszer hozta létre. Kérem törölje!',
	'install:error:rewrite:htaccess:old_elgg_htaccess' => 'A rendszer mappájában van egy régebbi Elgg verzióhoz tartozó .htaccess fájl, amely nem tartalmaz átírási szabályokat.',
	'install:error:rewrite:htaccess:cannot_copy' => 'Ismeretlen hiba történt a .htaccess fájl létrehozása során file. Hozza létre manuálisan és másolja bele a htaccess_dist tartalmát.',
	'install:error:rewrite:altserver' => 'Az átírási szabályok ellenőrzése sikertelen volt. Módosítsa a webszerverén a szabályokat az Elgg átírási szabályaira és próbálja újra.',
	'install:error:rewrite:unknown' => 'Hűha! Nem sikerült beazonosítani a webszerver típusát és nem sikerült az átírási szabályok ellenőrzése sem. Sajnos tanácstalanok vagyunk. Próbálja meg a telepítési hibákkal foglalkozó oldalon az alábbi hivatkozáson.',
	'install:warning:rewrite:unknown' => 'Az Ön szervere nem támogatja az átírási szabályok automatikus ellenőrzését. Folytathatja a telepítést, de lehetséges, hogy problémák lesznek a honlapjával. Manuálisan ellenőrizheti az átírási szabályokat a következő hivatkozásra kattintva: <a href="%s" target="_blank">Teszt</a>. Ki lesz írva, hogy sikerült, ha a szabályok működnek.',
);

add_translation("hu",$hungarian);

?>
