<?php
/**
 * Core Hungarian Language
 *
 * @package Elgg.Core
 * @subpackage Languages.English
 */

$hungarian = array(
/**
 * Sites
 */

	'item:site' => 'Honlapok',

/**
 * Sessions
 */
	
	'login' => "Bejelentkezés",
	'loginok' => "Sikeres bejelentkezés.",
  'loginerror' => "Sikertelen bejelentkezés. Kérem ellenőrizze a megadott adatokat és póbálja újra!",
  'login:empty' => "Felhasználónév vagy e-mail cím, és jelszó szükséges.",
  'login:baduser' => "A felhasználói fiók betöltése sikertelen.",
  'auth:nopams' => "Belső hiba. Nincs felhasználó hitelesítő eljárás telepítve.",

	'logout' => "Kijelentkezés",
	'logoutok' => "Sikeres kijelentkezés.",
	'logouterror' => "Sikertelen kijelentkezés. Kérem, próbálja újból!",

	'loggedinrequired' => "Az oldal megtekintéséhez be kell jelentkeznie.",
	'adminrequired' => "Az oldal megtekintéséhez rendszergazdai jogokkal kell rendelkeznie.",
	'membershiprequired' => "Az oldal megtekintéséhez csoporttagnak kell lennie.",


/**
 * Errors
 */
	'exception:title' => "Végzetes hiba.",

	'actionundefined' => "A kért művelet (%s) nem értelmezett a rendszerben.",
	'actionnotfound' => "%s művelet fájlja nem található.",
	'actionloggedout' => "Kijelentkezett állapotban nem végezheti el ezt a műveletet.",
	'actionunauthorized' => 'Nincs jogosultsága a művelet végrehajására',

	'InstallationException:SiteNotInstalled' => 'A kérés nem hajtható végre. A weboldal '
		. ' nincs beállítva vagy az adatbázis nem elérhető.',
	'InstallationException:MissingLibrary' => '%s betöltése sikertelen',
	'InstallationException:CannotLoadSettings' => 'A rendszer nem tudta betölteni a beállításokat tartalmazó fájlt. Lehetséges, hogy a fájl nem létezik vagy nincsenek megfelelően beállítva a jogosultságok.',
	
	'SecurityException:Codeblock' => "A programrészlet futtatása hozzáférés hiányában sikertelen",
	'DatabaseException:WrongCredentials' => "Az adatbázishoz való csatlakozás a megadott adatokkal sikertelen volt. Kérem ellenőrizze a beállításokat tartalmazó fájlt!",
	'DatabaseException:NoConnect' => "'%s' adatbázis kiválasztása sikertelen. Kérem, ellenőrizze, hogy az adatbázis létezik-e és van-e hozzáférése!",
	'SecurityException:FunctionDenied' => "'%s' függvényhez való hozzáférés letiltva.",
	'DatabaseException:DBSetupIssues' => "Néhány gond merült fel: ",
	'DatabaseException:ScriptNotFound' => "A rendszer nem találta a(z) %s adatbázis szkriptet.",
	'DatabaseException:InvalidQuery' => "Érvénytelen lekérdezés",
	
	'IOException:FailedToLoadGUID' => "Nem sikerült az új %s betöltése innen: GUID:%d",
	'InvalidParameterException:NonElggObject' => "Nem ElggObject átadása egy ElggObject konstruktorának!",
	'InvalidParameterException:UnrecognisedValue' => "Azonosítatlan érték átadása a konstruktornak.",
	
	'InvalidClassException:NotValidElggStar' => "GUID:%d nem egy érvényes %s",

	'PluginException:MisconfiguredPlugin' => "%s (guid: %s) helytelenül beállított bővítmény, amely kikapcsolásra került. A lehetséges okokról az Elgg wiki-ben tájékozódhat (http://docs.elgg.org/wiki/).",
	'PluginException:CannotStart' => '%s (guid: %s) nem indul és kikcsolásra került. Magyarázat: %s',
	'PluginException:InvalidID' => "%s egy hibás bővítmény azonosító.",
	'PluginException:InvalidPath' => "%s egy hibás bővítmény elérési útvonal.",
	'PluginException:InvalidManifest' => '%s bővítmény hibás jegyzék fájllal rendelkezik',
	'PluginException:InvalidPlugin' => '%s egy érvénytelen bővítmény.',
	'PluginException:InvalidPlugin:Details' => '%s egy érvénytelen bővítmény: %s',
	'PluginException:NullInstantiated' => 'Az ElggPlugin nem null-példányosítható. Át kell adni egy GUID-t, bővítmény azonosítót vagy a teljes elérési útvonalat.',

	'ElggPlugin:MissingID' => 'Nincs bővítmény azonosító (guid %s)',
	'ElggPlugin:NoPluginPackagePackage' => 'Nem található az ElggPluginPackage a(z) %s azonosítóval rendelkező bővítményhez (guid %s)',

	'ElggPluginPackage:InvalidPlugin:MissingFile' => '%s fájl nem található a csomagban',
	'ElggPluginPackage:InvalidPlugin:InvalidDependency' => 'Érvénytelen típusú függőség "%s"',
	'ElggPluginPackage:InvalidPlugin:InvalidProvides' => 'Érvénytelen típusú szolgáltatás "%s"',
	'ElggPluginPackage:InvalidPlugin:CircularDep' => 'Érvénytelen %s függőség "%s" a(z) %s bővítményben. A bővítmények nem ütközhetnek és igényelhetnek olyat, amit szolgáltatnak!',

	'ElggPlugin:Exception:CannotIncludeFile' => '%s nem beépíthető a(z) %s bővítménybe (guid: %s) itt: %s.',
	'ElggPlugin:Exception:CannotRegisterViews' => 'A nézetek mappa nem nyitható meg a(z) %s bővítmény számára (guid: %s) itt: %s.',
	'ElggPlugin:Exception:CannotRegisterLanguages' => 'Nyelv hozzárendelése sikertelen a(z) %s bővítményhez (guid: %s) itt: %s.',
	'ElggPlugin:Exception:NoID' => 'A guid %s bővítménynek nincs azonosítója!',

	'PluginException:ParserError' => 'A jegyzék elemzése sikertelen volt a(z) %s verziójú API-val a(z) %s bővítményben.',
	'PluginException:NoAvailableParser' => 'A jegyzékhez nem található elemző a(z) %s verziójó API-val a(z) %s bővítményhez.',
	'PluginException:ParserErrorMissingRequiredAttribute' => "Hiányzik a szükséges '%s' tulajdonság a jegyzékben a(z) %s bővítményhez.",

	'ElggPlugin:Dependencies:Requires' => 'Igényli',
	'ElggPlugin:Dependencies:Suggests' => 'Javasolja',
	'ElggPlugin:Dependencies:Conflicts' => 'Ütközik',
	'ElggPlugin:Dependencies:Conflicted' => 'Ütközött',
	'ElggPlugin:Dependencies:Provides' => 'Szolgáltat',
	'ElggPlugin:Dependencies:Priority' => 'Prioritás',

	'ElggPlugin:Dependencies:Elgg' => 'Elgg verzió',
	'ElggPlugin:Dependencies:PhpExtension' => 'PHP kiterjesztés: %s',
	'ElggPlugin:Dependencies:PhpIni' => 'PHP ini beállítás: %s',
	'ElggPlugin:Dependencies:Plugin' => 'Bővítmény: %s',
	'ElggPlugin:Dependencies:Priority:After' => '%s után',
	'ElggPlugin:Dependencies:Priority:Before' => '%s előtt',
	'ElggPlugin:Dependencies:Priority:Uninstalled' => '%s nincs telepítve',
	'ElggPlugin:Dependencies:Suggests:Unsatisfied' => 'Hiányzik',

	'ElggPlugin:InvalidAndDeactivated' => '%s bővítmény érvénytelen és kikapcsolásra került.',
	
	'InvalidParameterException:NonElggUser' => "Nem ElggUser átadása egy ElggUser konstruktorának!",
	
	'InvalidParameterException:NonElggSite' => "Nem ElggSite átadása egy ElggSite konstruktorának!",
	
	'InvalidParameterException:NonElggGroup' => "Nem ElggGroup átadása egy ElggGroup konstruktorának!",

	'IOException:UnableToSaveNew' => "Nem sikerült az új %s mentése",
	
	'InvalidParameterException:GUIDNotForExport' => "A GUID nem lett meghatározva az exportálás alatt, ennek nem szabadna megtörténnie.",
	'InvalidParameterException:NonArrayReturnValue' => "Az entitásrendező függvény egy nem tömb típusú változóval tért vissza",
	
	'ConfigurationException:NoCachePath' => "Nincs gyorsítótár elérési útvonal megadva!",
	'IOException:NotDirectory' => "%s nem egy mappa.",
	
	'IOException:BaseEntitySaveFailed' => "Nem sikerült elmenteni az új objektum alapentitásának információit!",
	'InvalidParameterException:UnexpectedODDClass' => "import() egy váratlan ODD osztályt adott át",
	'InvalidParameterException:EntityTypeNotSet' => "Az entitás típusát kötelező beállítani.",
	
	'ClassException:ClassnameNotClass' => "%s nem egy %s.",
	'ClassNotFoundException:MissingClass' => "'%s' osztály nem található, hiányzó bővítmény?",
	'InstallationException:TypeNotSupported' => "%s típus nem támogatott. Ez egy olyan hibára utal a rendszerben, amelyet egy befejezetlen frissítés okozhatott.",

	'ImportException:ImportFailed' => "Nem sikerült %d elem importálása",
	'ImportException:ProblemSaving' => "Hiba lépett fel %s mentésekor",
	'ImportException:NoGUID' => "Új entitás létrehozva, azonban nincs azonosítója. Ennek nem szabadna megtörténnie.",
	
	'ImportException:GUIDNotFound' => "'%d' entitás nem található.",
	'ImportException:ProblemUpdatingMeta' => "Hiba lépett fel '%s' frissítésekor a '%d' entitáson.",
	
	'ExportException:NoSuchEntity' => "Nincs ilyen entitás GUID:%d", 
	
	'ImportException:NoODDElements' => "Nem található OpenDD elem az importált adatok között. Az importálás sikertelen.",
	'ImportException:NotAllImported' => "Nem sikerült az összes elem importálása.",
	
	'InvalidParameterException:UnrecognisedFileMode' => "Ismeretlen '%s' fájl mód.",
	'InvalidParameterException:MissingOwner' => "%s fájlnak nincs tulajdonosa (fájl guid:%d) (tulajdonos guid:%d)!",
	'IOException:CouldNotMake' => "%s megvalósítása sikertelen",
	'IOException:MissingFileName' => "Határozzon meg egy nevet egy fájl megnyitása előtt.",
	'ClassNotFoundException:NotFoundNotSavedWithFile' => "%s fájltároló osztály betöltése %u fájlnak sikertelen",
	'NotificationException:NoNotificationMethod' => "Nincs értesítési mód beállítva.",
	'NotificationException:NoHandlerFound' => "'%s' kezelője nem található vagy nem elérhető.",
	'NotificationException:ErrorNotifyingGuid' => "Hiba történt %d értesítéskor",
	'NotificationException:NoEmailAddress' => "Nem található a GUID:%d e-mail címe",
	'NotificationException:MissingParameter' => "Hiányzó szükséges paraméter, '%s'",
	
	'DatabaseException:WhereSetNonQuery' => "A hely lekérése egy nem WhereQueryComponent elemet tartalmaz",
	'DatabaseException:SelectFieldsMissing' => "Hiányos mezők egy többváltozós lekérdezésnél",
	'DatabaseException:UnspecifiedQueryType' => "Ismeretlen vagy meghatározatlan lekérés típus.",
	'DatabaseException:NoTablesSpecified' => "Nincs tábla erre a lekérésre.",
	'DatabaseException:NoACL' => "Nincs hozzáférés a lekérdezéshez",
	
	'InvalidParameterException:NoEntityFound' => "Az entitás nem található: vagy nem létezik, vagy nincs hozzáférése.",
	
	'InvalidParameterException:GUIDNotFound' => "GUID:%s nem található vagy nincs hozzáférése.",
	'InvalidParameterException:IdNotExistForGUID' => "Sajnos '%s' nem létezik a guid:%d azonosítóra",
	'InvalidParameterException:CanNotExportType' => "Sajnos '%s' nem exportálható",
	'InvalidParameterException:NoDataFound' => "Nincs adat.",
	'InvalidParameterException:DoesNotBelong' => "Nem tartozik entitáshoz.",
	'InvalidParameterException:DoesNotBelongOrRefer' => "Nem tartozik entitáshoz vagy nem hivatkozik rá.",
	'InvalidParameterException:MissingParameter' => "Hiányzó paraméter, szükséges a GUID megadása.",
	'InvalidParameterException:LibraryNotRegistered' => '%s könyvtár nincs nyilvántartva',
  'InvalidParameterException:LibraryNotFound' => '%s könyvtár betöltése sikertelen innen: %s',
		
	'APIException:ApiResultUnknown' => "API eredmény ismeretlen típusú, ennek nem szabadna megtörténnie.",
	'ConfigurationException:NoSiteID' => "Nincs honlap azonosító megadva.",
	'SecurityException:APIAccessDenied' => "Sajnos az API hozzáférést a rendszergazda letiltotta.",
	'SecurityException:NoAuthMethods' => "Nincs hitelesítési eljárás ami hitelesítené ez az API hívást.",
	'SecurityException:ForwardFailedToRedirect' => 'Az átirányítás meghiúsult mert a fejlécek már elküldésre kerültek. A végrehajtás biztonsági okokból megállítva. További információt a http://docs.elgg.org/ oldalon találhat.',
	'InvalidParameterException:APIMethodOrFunctionNotSet' => "Az eljárás vagy a függvény nincs beállítva itt: expose_method()",
	'InvalidParameterException:APIParametersArrayStructure' => "A paraméterek tömbszerkezete helytelen a(z) '%s' eljárás meghívásához",
	'InvalidParameterException:UnrecognisedHttpMethod' => "Ismeretlen %s http eljárás a(z) '%s' api eljárásnak",
	'APIException:MissingParameterInMethod' => "Hiányzó %s paraméter a(z) %s eljárásban",
	'APIException:ParameterNotArray' => "%s valószínűleg nem tömb.",
	'APIException:UnrecognisedTypeCast' => "Ismeretlen típus: %s a '%s' változónak a(z) '%s' eljárásban",
	'APIException:InvalidParameter' => "'%s' érvénytelen paraméterrel rendelkezik a(z) '%s' eljárásban.",
	'APIException:FunctionParseError' => "%s(%s) elemzési hibát okozott.",
	'APIException:FunctionNoReturn' => "%s(%s) nem adott visszatérési értéket.",
	'APIException:APIAuthenticationFailed' => "Az eljárás meghívása meghiúsította az API hitelesítést",
	'APIException:UserAuthenticationFailed' => "Az eljárás meghívása meghiúsította a felhasználó hitelesítést",
  'SecurityException:AuthTokenExpired' => "A hitelesítési vezérjel hiányzik, érvénytelen vagy lejárt.",
	'CallException:InvalidCallMethod' => "%s meghívásához használja '%s'-t",
	'APIException:MethodCallNotImplemented' => "'%s' eljárás nincs implementálva.",
	'APIException:FunctionDoesNotExist' => "'%s' eljárás függvénye nem hívható",
	'APIException:AlgorithmNotSupported' => "'%s' eljárás nem támogatott vagy ki lett kapcsolva.",
	'ConfigurationException:CacheDirNotSet' => "A gyorsítótár elérési útvonala ('cache_path') nincs beállítva.",
	'APIException:NotGetOrPost' => "A lekérés GET vagy POST eljárással történhet",
	'APIException:MissingAPIKey' => "Hiányzó API kulcs",
	'APIException:BadAPIKey' => "Érvénytelen API kulcs",
	'APIException:MissingHmac' => "Hiányzó X-Elgg-hmac fejléc",
	'APIException:MissingHmacAlgo' => "Hiányzó X-Elgg-hmac-algo fejléc",
	'APIException:MissingTime' => "Hiányzó X-Elgg-time fejléc",
	'APIException:MissingNonce' => "Hiányzó X-Elgg-nonce fejléc",
	'APIException:TemporalDrift' => "X-Elgg-time túlságosan távoli időt jelöl.",
	'APIException:NoQueryString' => "Nincs adat a lekérdezési sztringen",
	'APIException:MissingPOSTHash' => "Hiányzó X-Elgg-posthash fejléc",
	'APIException:MissingPOSTAlgo' => "Hiányzó X-Elgg-posthash_algo fejléc",
	'APIException:MissingContentType' => "Meghatározatlan tartalomtípus a POST adatoknál",
	'SecurityException:InvalidPostHash' => "POST adatok leképezése érvénytelen - Az elvárt %s de a kapott %s.",
	'SecurityException:DupePacket' => "A csomagazonosítás már megtörtént.",
	'SecurityException:InvalidAPIKey' => "Érvénytelen vagy hiányzó API kulcs.",
	'NotImplementedException:CallMethodNotImplemented' => "'%s' eljárás jelenleg nem támogatott.",

	'NotImplementedException:XMLRPCMethodNotImplemented' => "'%s' XML-RPC eljárás nincs implementálva.",
	'InvalidParameterException:UnexpectedReturnFormat' => "'%s' eljárás meghívása váratlan eredménnyel tért vissza.",
	'CallException:NotRPCCall' => "Érvénytelen XML-RPC eljárás meghívása",

	'PluginException:NoPluginName' => "A bővítmény neve nem található",

	'SecurityException:authenticationfailed' => "A felhasználót nem lehet azonosítani",

	'CronException:unknownperiod' => '%s nem egy ismert időszak.',

	'SecurityException:deletedisablecurrentsite' => 'A megjelenített honlap törlése vagy kikapcsolása nem lehetséges!',

	'RegistrationException:EmptyPassword' => 'A jelszó mezők üresek',
	'RegistrationException:PasswordMismatch' => 'A jelszavaknak egyezniük kell',
	'LoginException:BannedUser' => 'Kitiltották a honlapró ezért nem léphet be',
	'LoginException:UsernameFailure' => 'A belépés sikertelen. Kérem ellenőrizze a megadott felhasználónevet vagy e-mail címet, valamint a jelszót!',
	'LoginException:PasswordFailure' => 'A belépés sikertelen. Kérem ellenőrizze a megadott felhasználónevet vagy e-mail címet, valamint a jelszót!',
	'LoginException:AccountLocked' => 'A fiókját zároltuk a megengedett belépési próbálkozások számának túllépése miatt.',
	'LoginException:ChangePasswordFailure' => 'Nem ez a jelenlegi jelszó.',

	'memcache:notinstalled' => 'Nincs PHP memcache, telepítse a php5-memcache modult',
	'memcache:noservers' => 'Nincsenek memcache szerverek meghatározva, kérem állítsa be a $CONFIG->memcache_servers változót',
	'memcache:versiontoolow' => 'Legalább %s verzió kell a Memcache futtatásához, a jelenlegi verzió %s',
	'memcache:noaddserver' => 'A többszörös szervertámogatás ki van kapcsolva, valószínűleg frissítenie kell a PECL memcache könyvtárat',

	'deprecatedfunction' => 'Figyelem: A szkript nem támogatott függvényt használ (\'%s\'), ezért nem kompatibilis az Elgg jelen verziójával.',

	'pageownerunavailable' => 'Figyelem: Az oldal tulajdonosa (%d) nem hozzáférhető!',
	'viewfailure' => 'Belső hiba történt a(z) %s nézet megjelenítése során',
	'changebookmark' => 'Kérem változtassa meg a könyvjelzőjét ezen az oldalon',
	'noaccess' => 'Ezt a tartalmat törölték, hibás, vagy nincs hozzáférése.',

	'error:default' => 'Hoppá... Valami félresikerült.',
	'error:404' => 'Sajnos a keresett oldal nem található.',

/**
 * API
 */
	'system.api.list' => "Az összes API hívás listázása.",
	'auth.gettoken' => "This API call lets a user log in, returning an authentication token which can be used in lieu of a username and password for authenticating further calls.",

/**
 * User details
 */

	'name' => "Név",
	'email' => "E-mail cím",
	'username' => "Felhasználónév",
	'loginusername' => "Felhasználónév vagy e-mail", // @easy: Túl hosszú lenne és megtörne így: "Felhasználónév vagy e-mail cím"
	'password' => "Jelszó",
	'passwordagain' => "Jelszó még egyszer (ellenőrzés)",
	'admin_option' => "Kapjon rendszergazdai jogokat a felhasználó?",

/**
 * Access
 */

	'PRIVATE' => "Privát",
	'LOGGED_IN' => "Bejelentkezett felhasználók",
	'PUBLIC' => "Nyilvános",
	'access:friends:label' => "Ismerősök",
	'access' => "Hozzáférés",
	'access:limited:label' => "Korlátozott",
	'access:help' => "A hozzáférés mértéke",

/**
 * Dashboard and widgets
 */

	'dashboard' => "Vezérlőpult",
	'dashboard:nowidgets' => "A vezérlőpult segítségével azokat a tevékenységeket kísérheti figyelemmel, amelyek igazán érdeklik.",

	'widgets:add' => 'Modulok hozzáadása',
	'widgets:add:description' => "Kattintson egy modulra és adja hozzá a vezérlőpultjához.",
	'widgets:position:fixed' => '(Rögzített)',
	'widget:unavailable' => 'Ez a modul már hozzá lett adva',
	'widget:numbertodisplay' => 'Megjelenítendő elemek száma',

	'widget:delete' => '%s modul eltávolítása',
	'widget:edit' => 'Modul testreszabása',

	'widgets' => "Modulok",
	'widget' => "Modul",
	'item:object:widget' => "Modulok",
	'widgets:save:success' => "A modul sikeresen mentésre került.",
	'widgets:save:failure' => "Nem sikerült elmenteni a modult. Kérem, próbálja meg újra!",
	'widgets:add:success' => "A modult sikeresen hozzáadtuk.",
	'widgets:add:failure' => "Nem sikerült hozzáadni a modult.",
	'widgets:move:failure' => "Nem sikerült lementeni a modul helyét.",
	'widgets:remove:failure' => "Nem lehet eltávolítani a modult",

/**
 * Groups
 */

	'group' => "Csoport", 
	'item:group' => "Csoportok",

/**
 * Users
 */

	'user' => "Felhasználó",
	'item:user' => "Felhasználók",

/**
 * Friends
 */

	'friends' => "Ismerősök",
	'friends:yours' => "Ismerőseim",
	'friends:owned' => "%s ismerősei",
	'friend:add' => "Ismerősként megjelöl",
	'friend:remove' => "Ismerős eltávolítása",

	'friends:add:successful' => "%s sikeresen hozzáadva az ismerősök listájához.",
	'friends:add:failure' => "%s hozzáadása az ismerősök listájához sikertelen. Kérem, próbálja meg újra!",

	'friends:remove:successful' => "%s sikeresen törölve az ismerősök listájáról.",
	'friends:remove:failure' => "%s törlése az ismerősök listájáról sikertelen. Kérem, próbálja meg újra!",

	'friends:none' => "A felhasználó még nem jelölt be senkit ismerősként.",
	'friends:none:you' => "Még nem jelölt be senkit ismerősnek.",

	'friends:none:found' => "Nincsenek ismerősök.",

	'friends:of:none' => "Még senki sem jelölte ismerősnek a felhasználót.",
	'friends:of:none:you' => "Eddig még senki sem jelölte be ismerősnek. Kezdjen el beszélgetni másokkal, és töltse ki az adatlapját, hogy nagyobb eséllyel találják meg!",

	'friends:of:owned' => "Felhasználók, akik %st ismerősnek jelölték",

  'friends:of' => "Ismerősnek jelölte",
  'friends:collections' => "Ismerősök gyűjteménye",
	'collections:add' => "Új gyűjtemény",
  'friends:collections:add' => "Új ismerősi gyűjtemény",
  'friends:addfriends' => "Ismerősök hozzáadása",
  'friends:collectionname' => "Gyűjtemény neve",
  'friends:collectionfriends' => "Ismerősök a gyűjteményben",
  'friends:collectionedit' => "Gyűjtemény módosítása",
  'friends:nocollections' => "Még nincs egyetlen gyűjteménye sem.",
  'friends:collectiondeleted' => "Gyűjtemény sikeresen törlölve.",
  'friends:collectiondeletefailed' => "Gyűjtemény törlése sikertelen. Nincsen hozzáférése, vagy más probléma lépett fel.",
  'friends:collectionadded' => "Gyűjtemény sikeresen létrehozva.",
  'friends:nocollectionname' => "Adja meg a gyűjtemény nevét a létrehozáshoz!",
  'friends:collections:members' => "Gyűjtemény tagjai",
  'friends:collections:edit' => "Gyűjtemény szerkesztése",
	'friends:collections:edited' => "Gyűjtemény sikeresen elmentve",
	'friends:collection:edit_failed' => 'Gyűjtemény mentése sikertelen.',

	'friendspicker:chararray' => 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',

	'avatar' => 'Igazolványkép',
	'avatar:create' => 'Igazolványkép készítése',
	'avatar:edit' => 'Kép szerkesztése', // @easy: Túl hosszú lenne és megtörne az 'Igazolványkép szerkesztése' a gomb felirataként
	'avatar:preview' => 'Előnézet',
	'avatar:upload' => 'Új igazolványkép feltöltése',
	'avatar:current' => 'Jelenlegi igazolványkép',
	'avatar:revert' => 'Alapértelmezett igazolványkép visszaállítása',
	'avatar:crop:title' => 'Igazolványkép vágó eszköz',
	'avatar:upload:instructions' => "Az igazolványképe a honlap számos részén megjelenik. Bármikor megváltoztathatja, ha akarja. (A megengedett képtípusok: .GIF, .JPG vagy .PNG)",
	'avatar:create:instructions' => 'Az igazolványkép vágásához kattintson a képbe, majd tartsa lenyomva és húzza az egeret; így egy négyzetes területet jelölhet ki. A jobb oldalon ekkor megjelenik az igazolványkép előnézete. Ha elégedett az eredménnyel, kattintson az \'Igazolványkép készítése\' gombra. A rendszer az így elkészített igazolványképet fogja használni a honlap számos részén.',
	'avatar:upload:success' => 'Az igazolványkép feltölése sikerült',
	'avatar:upload:fail' => 'Az igazolványkép feltöltése sikertelen',
	'avatar:resize:fail' => 'Az igazolványkép átméretezése sikertelen',
	'avatar:crop:success' => 'Az igazolványkép vágása sikerült',
	'avatar:crop:fail' => 'Az igazolványkép vágása sikertelen',
	'avatar:revert:success' => 'Az igazolványkép viszzaállítása sikerült',
	'avatar:revert:fail' => 'Az igazolványkép viszzaállítása sikertelen',

	'profile:edit' => 'Adatlap módosítása',
	'profile:aboutme' => "Rólam", 
	'profile:description' => "Rólam",
	'profile:briefdescription' => "Rövid leírás",
	'profile:location' => "Lakhely",
	'profile:skills' => "Készségeim",  
	'profile:interests' => "Érdeklődési területeim", 
	'profile:contactemail' => "E-mail cím",
	'profile:phone' => "Telefonszám",
	'profile:mobile' => "Mobiltelefonszám",
	'profile:website' => "Weboldal",
	'profile:twitter' => "Twitter felhasználónév",
	'profile:saved' => "Sikeres adatlapmentés.",

	'profile:field:text' => 'Rövid szöveg',
	'profile:field:longtext' => 'Nagy szövegdoboz',
	'profile:field:tags' => 'Címkék',
	'profile:field:url' => 'Honlapcím',
	'profile:field:email' => 'E-mail cím',
	'profile:field:location' => 'Hely',
	'profile:field:date' => 'Dátum',

	'admin:appearance:profile_fields' => 'Adatlap szerkesztése',
	'profile:edit:default' => 'Adatlap szerkesztése',
	'profile:label' => "Mező neve",
	'profile:type' => "Mező típusa",
	'profile:editdefault:delete:fail' => 'Alapértelmezett adatlap mező törlése sikertelen',
	'profile:editdefault:delete:success' => 'Adatlap mező törölve',
	'profile:defaultprofile:reset' => 'Adatlap mezői visszaállítva az alapértelmezettekre',
	'profile:resetdefault' => 'Alapértelmezett adatlap visszaállítása',
	'profile:explainchangefields' => "Lecserélheti a jelenlegi adatlapmezőket az alábbi űrlap használatával. \n\n Adjon az új mezőnek nevet, például 'Kedvenc focicsapatom', aztán válassza ki a típusát (pl. szöveg, URL vagy címkék), és kattintson a 'Hozzáad' gombra. A sorrend beállításához használja a címkék szövege melleti vezérlőket. A mezők szerkesztéséhez kattintson egy címke szöveg részére. \n\n Bármikor visszaállíthatja az alapértelmezett adatlapot, de akkor az egyénileg beállított mezők és azok tartalma elvész.",
	'profile:editdefault:success' => 'Új adatlap mező hozzáadva',
	'profile:editdefault:fail' => 'Alapértelmezett adatlap mentése sikertelen',


/**
 * Feeds
 */
	'feed:rss' => 'Feliratkozás a hírszolgáltatásra',
/**
 * links
 **/
	'link:view' => 'hivatkozás megtekintése',
	'link:view:all' => 'Mindegyik megtekintése',


/**
 * River
 */
	'river' => "Hírfolyam",
	'river:friend:user:default' => "%s ismerősnek jelölte őt: %s",
	'river:update:user:avatar' => '%s új igazolványképet állított be',
	'river:update:user:profile' => '%s frissítette az adatlapját',
	'river:noaccess' => 'Nincs jogosultsága az elem megtekintéhez.',
	'river:posted:generic' => '%s írta',
	'riveritem:single:user' => 'felhasználó',
	'riveritem:plural:user' => 'felhasználók',
	'river:ingroup' => 'ebben a csoportban: %s',
	'river:none' => 'Nincsenek hírek',
	'river:update' => '%s frissült',

	'river:widget:title' => "Hírfolyam",
	'river:widget:description' => "A legfrissebb hírek megjelenítése",
	'river:widget:type' => "Hírek forrása",
	'river:widgets:friends' => 'Ismerősök',
	'river:widgets:all' => 'Minden hír',
	
/**
 * Notifications
 */
	'notifications:usersettings' => "Értesítés beállítások",
	'notifications:methods' => "Kérem, jelölje meg, milyen értesítési módszereket engedélyez.",
	'notification:method:email' => 'E-mail',

	'notifications:usersettings:save:ok' => "Értesítési beállításai sikeresen mentésre kerültek.",
	'notifications:usersettings:save:fail' => "Hiba lépett fel az értesítési beállítások mentésekor.",

	'user.notification.get' => 'Adott felhasználóhoz tartozó értesítések.',
	'user.notification.set' => 'Adott felhasználóhoz tartozó értesítések beállítása.',
/**
 * Search
 */

	'search' => "Keresés",
	'searchtitle' => "Keresés: %s",
	'users:searchtitle' => "Felhasználó keresése: %s",
	'groups:searchtitle' => "Csoport keresése: %s",
	'advancedsearchtitle' => "%s a következő találatokkal %s",
	'notfound' => "Nincs találat.",
	'next' => "Következő",
	'previous' => "Előző",

	'viewtype:change' => "Megjelenítés váltása",
	'viewtype:list' => "Lista nézet",
	'viewtype:gallery' => "Ikon nézet",

	'tag:search:startblurb' => "'%s' kifejezésre talált elemek listája:",

	'user:search:startblurb' => "'%s' kifejezésre talált felhasználók listája:",
	'user:search:finishblurb' => "További találatok...",

	'group:search:startblurb' => "'%s' kifejezésre talált csoportok listája:",
	'group:search:finishblurb' => "További találatok...",
	'search:go' => 'Keresés',
	'userpicker:only_friends' => 'Csak ismerősök',

/**
 * Account
 */

	'account' => "Fiók",
	'settings' => "Beállítások",
	'tools' => "Eszközök",
	'settings:edit' => "Beállítások módosítása",

	'register' => "Regisztrálás",
	'registerok' => "Sikeresen regisztrált a %s közösségi portálon.",
	'registerbad' => "A regisztáció egy ismeretlen hiba miatt sikertelen volt.",
	'registerdisabled' => "A regisztráció lehetősége le van tiltva.",
	'register:fields' => 'Minden mező kitöltése kötelező',

	'registration:notemail' => 'A megadott e-mail cím nem valós.',
	'registration:userexists' => 'A választott felhasználónév már létezik',
	'registration:usernametooshort' => 'A felhasználónév legalább %u karakterből kell álljon.',
	'registration:passwordtooshort' => 'A jelszó legalább %u karakterből kell álljon.',
	'registration:dupeemail' => 'Ez az e-mail cím már regisztrálva van.',
	'registration:invalidchars' => 'A megadott felhasználónév érvénytelen karaktert tartalmaz (%s). A következő karakterek érvénytelenek: %s',
	'registration:emailnotvalid' => 'A megadott e-mail cím érvénytelen.',
	'registration:passwordnotvalid' => 'A megadott jelszó érvénytelen.',
	'registration:usernamenotvalid' => 'A megadott felhasználónév érvénytelen.',

	'adduser' => "Felhasználó hozzáadása",
	'adduser:ok' => "Felhasználó sikeresen létrehozva.",
	'adduser:bad' => "Nem sikerült az új felhasználó létrehozása",

	'user:set:name' => "Felhasználói név beállításai",
	'user:name:label' => "Megjelenített név",
	'user:name:success' => "Sikeres névváltoztatás.",
	'user:name:fail' => "Sikertelen névváltoztatás. Bizonyosodjon meg róla, hogy a megadott név nem túl hosszú, és próbálja újra.",

	'user:set:password' => "Jelszó beállítása",
	'user:current_password:label' => 'Jelenlegi jelszó',
	'user:password:label' => "Új jelszó",
	'user:password2:label' => "Új jelszó még egyszer",
	'user:password:success' => "Jelszó sikeresen megváltoztatva",
	'user:password:fail' => "Nem sikerült megváltoztatni a jelszót.",
	'user:password:fail:notsame' => "A két megadott jelszó nem egyezik meg!",
	'user:password:fail:tooshort' => "Túl rövid jelszó!",
	'user:password:fail:incorrect_current_password' => 'Nem ez a jelelegi jelszó.',
	'user:resetpassword:unknown_user' => 'Érvénytelen felhasználó.',
	'user:resetpassword:reset_password_confirm' => 'A jelszó újraállítása miatt küldünk egy új jelszót arra az e-mail címre, amellyel regisztrált.',

	'user:set:language' => "Nyelvi beállítások",
	'user:language:label' => "Használt nyelv",
	'user:language:success' => "Nyelvi beállítások sikeresen frissítve.",
	'user:language:fail' => "Nem sikerült a nyelvi beállításokat frissíteni.",

	'user:username:notfound' => '%s nevű felhasználó nem található.',

	'user:password:lost' => 'Elvesztett jelszó',
	'user:password:resetreq:success' => 'Jelszó kérés sikeres, e-mail elküldve',
	'user:password:resetreq:fail' => 'Nem sikerült az új jelszó kérése.',

	'user:password:text' => 'Új jelszó generálásához kérjük adja meg a felhasználónevét, vagy az e-mail címét! Ezt követően kap egy e-mailt, benne egy hivatkozással, amelyre kattintva elküldjük a kért új jelszót.',

	'user:persistent' => 'Megjegyzés',

	'walled_garden:welcome' => 'Üdvözöljük',

/**
 * Administration
 */
	'menu:page:header:administer' => 'Adminisztráció',
	'menu:page:header:configure' => 'Beállítások',
	'menu:page:header:develop' => 'Fejlesztés',
	'menu:page:header:default' => 'Egyéb',

	'admin:view_site' => 'Honlap megtekintése',
	'admin:loggedin' => 'Bejelentkezve, mint %s',
	'admin:menu' => 'Menü',

	'admin:configuration:success' => "Beállításai sikeresen elmentve.",
	'admin:configuration:fail' => "Nem sikerült a beállításainak elmentése.",

	'admin:unknown_section' => 'Érvénytelen adminterület.',

	'admin' => "Adminisztráció",
	'admin:description' => "Az adminisztrációs felület a rendszer minden aspektusának kezelését teszi lehetővé a felhasználókezeléstől a bővítmények működéséig.",

	'admin:statistics' => "Statisztika",
	'admin:statistics:overview' => 'Áttekintés',
	'admin:statistics:server' => 'Szerver infó',

	'admin:appearance' => 'Megjelenítés',
	'admin:administer_utilities' => 'Eszközök',
	'admin:develop_utilities' => 'Eszközök',
	
	'admin:users' => "Felhasználók",
	'admin:users:online' => 'Jelenleg online',
	'admin:users:newest' => 'Legújabbak',
	'admin:users:add' => 'Új hozzáadása',
	'admin:users:description' => "Ez az adminisztrációs felület a felhasználói beállítások kezelését teszi lehetővé.",
	'admin:users:adduser:label' => "Kattintson ide egy új felhasználó hozzáadásához...",
	'admin:users:opt:linktext' => "Felhasználók beállításai...",
	'admin:users:opt:description' => "Felhasználók és adatlapinformációik beállításai.. ",
	'admin:users:find' => 'Keresés',
	
	'admin:settings' => 'Beállítások',
	'admin:settings:basic' => 'Alapbeállítások',
	'admin:settings:advanced' => 'Speciális beállítások',
	'admin:site:description' => "Ez az adminisztrációs felület a honlap globális beállításainak kezelését teszi lehetővé. A kezdéshez válasszon egyet az alábbiak közül.",
	'admin:site:opt:linktext' => "Honlap beállításai...",
	'admin:site:access:warning' => "A hozzáférési szint megváltoztatása csak a jövőben létrejövő tartalmakat érinti.",
	
	'admin:dashboard' => 'Vezérlőpult',
	'admin:widget:online_users' => 'Online felhasználók',
	'admin:widget:online_users:help' => 'Azon felhasználók listája akik épp a honlapon tartózkodnak',
	'admin:widget:new_users' => 'Új felhasználók',
	'admin:widget:new_users:help' => 'A legfrissebb felhasználók listája',
	'admin:widget:content_stats' => 'Statisztika a tartalmakról',
	'admin:widget:content_stats:help' => 'Itt nyomon követheti a felhasználók által létrehozott tartalmakat',
	'widget:content_stats:type' => 'Tartalom típus',
	'widget:content_stats:number' => 'Darabszám',

	'admin:widget:admin_welcome' => 'Üdvözlet',
	'admin:widget:admin_welcome:help' => "A rendszer adminisztrációs felületének rövid bemutatása",
	'admin:widget:admin_welcome:intro' =>
'Üdvözli Önt az Elgg! Ez itt az adminsztrációs felület vezérlőpultja. Innen megtudhatja, hogy mi minden történik a honlapján.',

	'admin:widget:admin_welcome:admin_overview' =>
"Az adminisztrációs felületet a jobb oldali menüből vezérelheti. Három részre"
. " van tagolva:
	<dl>
		<dt>Adminisztráció</dt><dd>Mindennapos feladatok, mint a jelentett tartalmak átvizsgálása, az online felhasználók nyomon követése, vagy a statisztikák megtekintése.</dd>
		<dt>Beállítások</dt><dd>Ritkán használt funkciók, mint a honlap nevének beállítása vagy egy bővítmény aktiválása.</dd>
		<dt>Fejlesztés</dt><dd>Fejlesztőknek, akik bővítményeket vagy új dizájnt készítenek. (Ehhez szükséges a fejlesztői bővítmény)</dd>
	</dl>
	",

	// argh, this is ugly
	'admin:widget:admin_welcome:outro' => '<br />További információt a lábléc hivatkozásain keresztül találhat. Köszönjük hogy az Elgg-et választotta!',

	'admin:widget:control_panel' => 'Irányítópult',
	'admin:widget:control_panel:help' => "Gyors hozzáférést biztosít a gyakori tevékenységekhez",

	'admin:cache:flush' => 'Gyorsítótárak kiürítése',
	'admin:cache:flushed' => "A honlap gyorsítótárai üresek",

	'admin:footer:faq' => 'Adminisztrációs GYIK',
	'admin:footer:manual' => 'Adminisztráció használati utasítása',
	'admin:footer:community_forums' => 'Elgg közösségi fórum',
	'admin:footer:blog' => 'Elgg blog',

	'admin:plugins:category:all' => 'Minden bővítmény',
	'admin:plugins:category:active' => 'Aktív bővítmények',
	'admin:plugins:category:inactive' => 'Inaktív bővítmények',
	'admin:plugins:category:admin' => 'Adminisztrációs',
	'admin:plugins:category:bundled' => 'Összefüggő',
	'admin:plugins:category:nonbundled' => 'Nem összefüggő',
	'admin:plugins:category:content' => 'Tartalom',
	'admin:plugins:category:development' => 'Fejlesztés',
	'admin:plugins:category:enhancement' => 'Továbbfejlesztés',
	'admin:plugins:category:api' => 'Szolgáltatás/API',
	'admin:plugins:category:communication' => 'Kommunikáció',
	'admin:plugins:category:security' => 'Biztonság és spam',
	'admin:plugins:category:social' => 'Közösség',
	'admin:plugins:category:multimedia' => 'Multimédia',
	'admin:plugins:category:theme' => 'Dizájn',
	'admin:plugins:category:widget' => 'Modul',
	'admin:plugins:category:utility' => 'Eszköz',

	'admin:plugins:sort:priority' => 'Prioritás szerint',
	'admin:plugins:sort:alpha' => 'Név szerint',
	'admin:plugins:sort:date' => 'Frissesség szerint',

	'admin:plugins:markdown:unknown_plugin' => 'Ismeretlen bővítmény.',
	'admin:plugins:markdown:unknown_file' => 'Ismeretlen fájl.',


	'admin:notices:could_not_delete' => 'A figyelmeztetés nem törölhető.',

	'admin:options' => 'Admin beállítások',


/**
 * Plugins
 */
	'plugins:settings:save:ok' => "A(z) %s bővítmény beállításai sikeresen mentésre kerültek.",
	'plugins:settings:save:fail' => "Hiba lépett fel a(z) %s bővítmény beállításainak mentésekor.",
	'plugins:usersettings:save:ok' => "A(z) %s bővítmény felhasználói beállításai sikeresen mentésre kerültek.",
	'plugins:usersettings:save:fail' => "Hiba lépett fel a(z) %s bővítmény felhasználói beállításainak mentésekor.",
	'item:object:plugin' => 'Bővítmények',

	'admin:plugins' => "Bővítmények kezelése",
	'admin:plugins:activate_all' => 'Mindegyik bekapcsolása',
	'admin:plugins:deactivate_all' => 'Mindegyik kikapcsolása',
	'admin:plugins:activate' => 'Bekapcsol',
	'admin:plugins:deactivate' => 'Kikapcsol',
	'admin:plugins:description' => "Ezen az adminisztréciós felületen állíthatók be és irányíthatók a telepített eszközök.",
	'admin:plugins:opt:linktext' => "Eszköz beállítása...",
	'admin:plugins:opt:description' => "A telepített eszköz beállítsa.",
	'admin:plugins:label:author' => "Szerző",
	'admin:plugins:label:copyright' => "Szerzői jog",
	'admin:plugins:label:categories' => 'Kategória',
	'admin:plugins:label:licence' => "Licensz",
	'admin:plugins:label:website' => "URL",
	'admin:plugins:label:moreinfo' => 'Bővebben...',
	'admin:plugins:label:version' => 'Verzió',
	'admin:plugins:label:location' => 'Hely',
	'admin:plugins:label:dependencies' => 'Függőségek',

	'admin:plugins:warning:elgg_version_unknown' => 'Ez a bővítmény régi leíró fájlt tartalmaz ezért nincs meghatározva kompatibilis Elgg verziószám. Valószínűleg nem fog működni!',
	'admin:plugins:warning:unmet_dependencies' => 'Ennek a bővítménynek kielégítetlen függőségei vannak, ezért nem lehet bekapcsolni. További információt a \'Bővebben\' hivatkozásra kattintva találhat.',
	'admin:plugins:warning:invalid' => '%s egy nem érvényes bővítmény. Tippek a helyreállításához <a href="http://docs.elgg.org/Invalid_Plugin">az Elgg dokumentációban</a> találhatók.',
	'admin:plugins:cannot_activate' => 'Nem kapcsolható be',

	'admin:plugins:set_priority:yes' => "%s áthelyezve.",
	'admin:plugins:set_priority:no' => "%s áthelyezése sikertelen.",
	'admin:plugins:set_priority:no_with_msg' => "%s áthelyezése sikertelen. Hiba: %s",
	'admin:plugins:deactivate:yes' => "%s kikpcsolva.",
	'admin:plugins:deactivate:no' => "%s kikapcsolása sikertelen.",
	'admin:plugins:deactivate:no_with_msg' => "%s kikapcsolása sikertelen. Hiba: %s",
	'admin:plugins:activate:yes' => "%s bekapcsolva.",
	'admin:plugins:activate:no' => "%s bekapcsolása sikertelen.",
	'admin:plugins:activate:no_with_msg' => "%s bekapcsolása sikertelen. Hiba: %s",
	'admin:plugins:categories:all' => 'Minden kategória',
	'admin:plugins:plugin_website' => 'Bővítmény weboldala',
	'admin:plugins:author' => '%s',
	'admin:plugins:version' => 'Verzió %s',
	'admin:plugin_settings' => 'Bővítmény beállításai',
	'admin:plugins:warning:unmet_dependencies_active' => 'A bővítmény be van kapcsolva de kielégítetlen függőségei vannak, ezért problémákat tapasztalhat. További információt a \'Bővebben\' hivatkozásra kattintva találhat.',

	'admin:plugins:dependencies:type' => 'Típus',
	'admin:plugins:dependencies:name' => 'Név',
	'admin:plugins:dependencies:expected_value' => 'Várt érték',
	'admin:plugins:dependencies:local_value' => 'Kapott érték',
	'admin:plugins:dependencies:comment' => 'Megjegyzés',

	'admin:statistics:description' => "Ez egy áttekintő az oldal statisztikai adatairól. Ha részletesebb statisztikát szeretne, egy professzionálisabb adminisztrációs lehetőség is igénybe vehető.",
	'admin:statistics:opt:description' => "Objektumokról és felhasználókról készült statisztikai adatok megtekintése.",
	'admin:statistics:opt:linktext' => "Statisztikák megtekintése...",
	'admin:statistics:label:basic' => "Alap weboldal statisztikák",
	'admin:statistics:label:numentities' => "Entitások az oldalon",
	'admin:statistics:label:numusers' => "Felhasználók száma",
	'admin:statistics:label:numonline' => "Online felhasználók száma",
	'admin:statistics:label:onlineusers' => "Online felhasználók",
	'admin:statistics:label:version' => "Elgg verzió",
	'admin:statistics:label:version:release' => "Kiadás",
	'admin:statistics:label:version:version' => "Verzió",

	'admin:server:label:php' => 'PHP',
	'admin:server:label:web_server' => 'Web szerver',
	'admin:server:label:server' => 'Szerver',
	'admin:server:label:log_location' => 'Naplófájl helye',
	'admin:server:label:php_version' => 'PHP verzió',
	'admin:server:label:php_ini' => 'PHP INI fájl helye',
	'admin:server:label:php_log' => 'PHP hibanapló',
	'admin:server:label:mem_avail' => 'Elérhető memória',
	'admin:server:label:mem_used' => 'Használt memória',
	'admin:server:error_log' => "Web szerver hibanaplója",

	'admin:user:label:search' => "Felhasználók keresése:",
	'admin:user:label:seachbutton' => "Keresés",

	'admin:user:ban:no' => "Nem lehetséges a felhasználó kitiltása",
	'admin:user:ban:yes' => "Felhasználó kitiltva.",
	'admin:user:self:ban:no' => "Nem tilthatja ki saját magát",
	'admin:user:unban:no' => "Nem lehetséges a felhasználó kitiltásának visszavonása",
	'admin:user:unban:yes' => "Felhasználó kitiltása visszavonva.",
	'admin:user:delete:no' => "Nem lehetséges a felhasználó törlése",
	'admin:user:delete:yes' => "Felhasználó törölve",
	'admin:user:self:delete:no' => "Nem törölheti saját magát",

	'admin:user:resetpassword:yes' => "Jelszó frissítve, felhasználó értesítve.",
	'admin:user:resetpassword:no' => "Nem sikerült a jelszó frissítése.",

	'admin:user:makeadmin:yes' => "A felhasználó mostantól rendszergazdai jogosultságokkal rendelkezik.",
	'admin:user:makeadmin:no' => "Nem sikerült a felhasználót rendszergazdává tenni.",

	'admin:user:removeadmin:yes' => "A felhasználó mostantól nem rendszergazda.",
	'admin:user:removeadmin:no' => "Nem sikerült a rendszergazdai jogok visszavonása a felhasználótól.",
	'admin:user:self:removeadmin:no' => "Nem vonhatja vissza saját magától a rendszergazdai jogosultságokat.",

	'admin:appearance:menu_items' => 'Menüpontok',
	'admin:menu_items:configure' => 'A főmenü menüpontjainak beállítása',
	'admin:menu_items:description' => 'Válassza ki melyik funkciókat akarja kiemelt menüpontokként szerepeletetni. A többi funkció a "Több" menüpont alatt lesz elérhető, a felsorolás végén.',
	'admin:menu_items:hide_toolbar_entries' => 'Valóban eltávolítja a hivatkozásokat az eszköztárából?',
	'admin:menu_items:saved' => 'Menü funkciók rögzítve.',
	'admin:add_menu_item' => 'Egyedi menüpont hozzáadása',
	'admin:add_menu_item:description' => 'Adjon nevet az egyedi menüpontnak és állítsa be az URL-jét.',

	'admin:appearance:default_widgets' => 'Alapértelmezett modulok',
	'admin:default_widgets:unknown_type' => 'Ismeretlen modultípus',
	'admin:default_widgets:instructions' => 'Itt hozzáadhatja, eltávolíthatja, mozgathatja, és beállíthatja az alapértelmezett modulokat az erre alkalmas oldalak szerint.'
		. ' Ezek a változtatások csak az új felhasználóknál lépnek érvénybe.',

/**
 * User settings
 */
	'usersettings:description' => "A felhasználó beállításai panel a személyes beállításainak kezelését teszi lehetővé a felhasználókezeléstől a bővítmények működéséig. A folytatáshoz válasszon egyet az alábbiak közül.",

	'usersettings:statistics' => "Statisztikák",
	'usersettings:statistics:opt:description' => "A honlapon lévő objektumok és felhasználók statisztikai adatainak megtekintése.",
	'usersettings:statistics:opt:linktext' => "Felhasználói statisztikák",

	'usersettings:user' => "Adatok",
	'usersettings:user:opt:description' => "Ez a felhasználói adatok kezelését teszi lehetővé.",
	'usersettings:user:opt:linktext' => "Adatok megváltoztatása",

	'usersettings:plugins' => "Eszközök",
	'usersettings:plugins:opt:description' => "Az aktivált eszközök beállításai.",
	'usersettings:plugins:opt:linktext' => "Eszközök beállítása",

	'usersettings:plugins:description' => "Ez a felület a rendszergazda által telepített eszközök személyreszabott beállítását és kezelését teszi lehetővé.",
	'usersettings:statistics:label:numentities' => "Részletes statisztika",

	'usersettings:statistics:yourdetails' => "Felhasználói fiók",
	'usersettings:statistics:label:name' => "Teljes név",
	'usersettings:statistics:label:email' => "E-mail",
	'usersettings:statistics:label:membersince' => "Tagság kezdete",
	'usersettings:statistics:label:lastlogin' => "Utolsó bejelentkezés ideje",

/**
 * Activity river
 */
	'river:all' => 'Minden hír',
	'river:mine' => 'Én híreim',
	'river:friends' => 'Ismerősök hírei',
	'river:select' => '%s megjelenítése',
	'river:comments:more' => '+ még %u',
	'river:generic_comment' => 'hozzászólt %s %s',

	'friends:widget:description' => "Megmutatja néhány ismerősét.",
	'friends:num_display' => "Megjelenített ismerősök száma",
	'friends:icon_size' => "Ikon méret",
	'friends:tiny' => "apró",
	'friends:small' => "kicsi",

/**
 * Generic action words
 */

	'save' => "Mentés",
	'reset' => 'Visszaállítás',
	'publish' => "Publikálás",
	'cancel' => "Mégsem",
	'saving' => "Mentés folyamatban...",
	'update' => "Frissítés",
	'preview' => "Előnézet",
	'edit' => "Módosítás",
	'delete' => "Törlés",
	'accept' => "Elfogad",
	'load' => "Betöltés",
	'upload' => "Feltöltés",
	'ban' => "Kitiltás",
	'unban' => "Tiltást visszavon",
	'banned' => "Kitiltva",
	'enable' => "Engedélyezés",
	'disable' => "Letiltás",
	'request' => "Igénylés",
	'complete' => "Kész",
	'open' => 'Megnyitás',
	'close' => 'Bezárás',
	'reply' => "Válasz",
	'more' => 'Egyéb',
	'comments' => 'Hozzászólások',
	'import' => 'Importálás',
	'export' => 'Exportálás',
	'untitled' => 'Névtelen',
	'help' => 'Súgó',
	'send' => 'Küldés',
	'post' => 'Küldés',
	'submit' => 'Küldés',
	'comment' => 'Hozzászólás',
	'upgrade' => 'Frissítés',
	'sort' => 'Rendezés',
	'filter' => 'Szűrő',
	'new' => 'Új',
	'add' => 'Hozzáadás',
	'create' => 'Létrehozás',
	'revert' => 'Visszaállítás',

	'site' => 'Honlap',
	'activity' => 'Hírfolyam',
	'members' => 'Felhasználók',

	'up' => 'Fel',
	'down' => 'Le',
	'top' => 'Tetejére',
	'bottom' => 'Aljára',

	'invite' => "Meghívás",

	'resetpassword' => "Jelszó visszaállítása",
	'makeadmin' => "Admin jogok megadása",
	'removeadmin' => "Admin jogok eltávolítása",
		
	'option:yes' => "Igen",
	'option:no' => "Nem",

	'unknown' => 'Ismeretlen',

	'active' => 'Aktív',
	'total' => 'Összes',

	'learnmore' => "Kattintson ide további információkért.",

	'content' => "tartalom",
	'content:latest' => 'Legfrissebb tartalmak',
	'content:latest:blurb' => 'Alternatív lehetőség: kattintson ide az oldalon megjelent legfrissebb tartalmak listázásához.',

	'link:text' => 'hivatkozás megtekintése',
/**
 * Generic questions
 */

	'question:areyousure' => 'Biztos benne?',

/**
 * Generic data words
 */

	'title' => "Cím",
	'description' => "Leírás",
	'tags' => "Címkék",
	'spotlight' => "Kiemelt",
	'all' => "Összes",
	'mine' => "Saját",

	'by' => 'által',
	'none' => 'semmi',

	'annotations' => "Kommentárok",
	'relationships' => "Kapcsolatok",
	'metadata' => "Metaadatok",
	'tagcloud' => "Címkefelhő",
	'tagcloud:allsitetags' => "Minden címke",

	'on' => 'írta erre:', // @easy: a legfrissebb hozzászólások résznél levő hiba miatt
	'off' => 'Ki',

/**
 * Entity actions
 */
	'edit:this' => 'Szerkesztés',
	'delete:this' => 'Törlés',
	'comment:this' => 'Hozzászólás',

/**
 * Input / output strings
 */

	'deleteconfirm' => "Biztosan törölni akarja?",
	'fileexists' => "Egy fájl korábban már feltöltésre került. A fájl lecseréléséhez válasszon az alábbiak közül:",

/**
 * User add
 */

	'useradd:subject' => 'Felhasználói fiók létrehozása',
	'useradd:body' => '
Kedves %s,

A megadott adatok alapján létrejött a felhasználói fiókja a(z) %s honlapon. A bejelentkezéshez kattintson ide:

%s

A bejelentkezéshez szükséges adatok:

Felhasználónév: %s
Jelszó: %s

A bejelentkezést követően kérjük változtassa meg a jelszavát.
',

/**
 * System messages
 **/

  'systemmessages:dismiss' => "Katt az eltűntetéshez",


/**
 * Import / export
 */
	'importsuccess' => "Az adatok importálása sikeres volt",
	'importfail' => "OpenDD adatimportálás nem sikerült.",

/**
 * Time
 */

	'friendlytime:justnow' => "épp most",
	'friendlytime:minutes' => "%s perce",
	'friendlytime:minutes:singular' => "egy perce",
	'friendlytime:hours' => "%s órája",
	'friendlytime:hours:singular' => "egy órája",
	'friendlytime:days' => "%s napja",
	'friendlytime:days:singular' => "tegnap",
	'friendlytime:date_format' => 'Y. n. j. - G:i',

	'date:month:01' => 'Január %s',
	'date:month:02' => 'Február %s',
	'date:month:03' => 'Március %s',
	'date:month:04' => 'Április %s',
	'date:month:05' => 'Május %s',
	'date:month:06' => 'Június %s',
	'date:month:07' => 'Július %s',
	'date:month:08' => 'Augusztus %s',
	'date:month:09' => 'Szeptember %s',
	'date:month:10' => 'Október %s',
	'date:month:11' => 'November %s',
	'date:month:12' => 'December %s',


/**
 * System settings
 */

	'installation:sitename' => "Honlap neve:",
	'installation:sitedescription' => "Rövid leírás a honlapról (nem kötelező):",
	'installation:wwwroot' => "A honlap URL-je:",
	'installation:path' => "Az Elgg rendszer teljes elérési útvonala:",
	'installation:dataroot' => "Az adatok tárolására szolgáló mappa teljes elérési útvonala:",
	'installation:dataroot:warning' => "Ezt a mappát manuálisan kell létrehozni. Érdemes az Elgg mappáján kívül létrehozni.",
	'installation:sitepermissions' => "Az alapértelemzett hozzáférés:",
	'installation:language' => "A honlap alapértelmezett nyelve:",
	'installation:debug' => "A Debug mód extra információkkal látja el, amelyek segítenek a hibák elhárításában. Ugyanakkor lassíthatják a honlap működését, ezért érdemes csak olyankor használni, ha rendellenességeket tapasztal:",
	'installation:debug:none' => 'Debug mód kikapcsolása (ajánlott)',
	'installation:debug:error' => 'Csak a kritikus hibák megjelenítése',
	'installation:debug:warning' => 'Hibák és figyelemztetések megjelenítése',
	'installation:debug:notice' => 'Hibák, figyelemztetések és értesítések megjelenítése',

	// Walled Garden support
	'installation:registration:description' => 'A fehasználók regisztrálása alapértelmezetten engedélyezve van. Kapcsolja ki, ha nem szeretné hogy a felhasználók beregisztrálhassák magukat a honlapra.',
	'installation:registration:label' => 'Új felhasználók regisztrálásának engedélyezése',
	'installation:walled_garden:description' => 'Engedélyezheti a honlap privát hálózatként való működtetését. Ekkor a be nem jelentkezett felhasználók nem láthatják az egyes oldalakat, kivéve azokat, amelyeket nyilvánossá tett.',
	'installation:walled_garden:label' => 'Csak a bejelentkezett felhasználóknak',

	'installation:httpslogin' => "A HTTPS engedélyezése a felhasználók beléptetésére. Ahhoz hogy ez a funkció működjön, szükséges a HTTPS engedélyezése a szerveren is.",
	'installation:httpslogin:label' => "HTTPS beléptetés engedélyezése",
	'installation:view' => "Adja meg hogy milyen nézetet használjon a rendszer alapjáraton, vagy hagyja üresen ezt a mezőt az alapértelemezett nézet használatához (ha nem biztos a dolgában, hagyja üresen):",

	'installation:siteemail' => "A honlap e-mail címe (a rendszerüzenetek küldéséhez):",

	'installation:disableapi' => "Az Elgg API használatával komplett webes szolgáltatásokat építhet ki, és a segítségével távoli alkalmazások is interakcióba léphetnek a weboldalával.",
	'installation:disableapi:label' => "Az Elgg webszolgáltatások API engedélyezése",

	'installation:allow_user_default_access:description' => "Ha az alábbi be van jelölve, a felhasználók beállíthatják a saját hozzáférési szintjüket, ezzel akár felülírva a rendszer által alapértelmezettet.",
	'installation:allow_user_default_access:label' => "Felhasználói hozzáférés szabályozás",

	'installation:simplecache:description' => "Az egyszerű gyorsítótár alkalmazásával jelentős teljesítménynövekedés érhető el úgy, hogy bizonyos statikus tartalmakat eltárolunk, ideértve néhány CSS és javascript fájlt. Normál esetben érdemes bekapcsolni.",
	'installation:simplecache:label' => "Egyszerű gyorsítótár használata (ajánlott)",

	'installation:viewpathcache:description' => "A nézetek fájl-útvonal gyorsítótára csökkenti a bővítmények betöltési idejét a nézetek élérési útvonalainak tárolásával.",
	'installation:viewpathcache:label' => "Fájl-útvonal gyorsítótár használata (ajánlott)",

	'upgrading' => 'Frissítés...',
	'upgrade:db' => 'Adatbázis sikeresen frissítve.',
	'upgrade:core' => 'Rendszer sikeresen frissítve.',
	'upgrade:unable_to_upgrade' => 'A frissítés meghiúsult.',
	'upgrade:unable_to_upgrade_info' =>
		'A rendszer frissítése meghiúsult, mert elavult nézetek
		találhatók a rendszer nézet mappájában. Ezek a nézetek már érvénytelenek és el kell őket
		távolítani a rendszer megfelelő működése érdekében. Ha nem módosította a rendszer központi fájljait,
		akkor egyszerűen törölje a nézetek mappáját és helyettesítse a legfrissebb Elgg csomagban találhatóval,
		amit innen tölthet le: <a href="http://elgg.org">elgg.org</a>.<br /><br />

		Ha részletes utasításokra lenne szüksége, olvassa el az <a href="http://docs.elgg.org/wiki/Upgrading_Elgg">
		Elgg frissítés dokumentációját</a>. Ha segítségre lenne szüksége, kérdését felteheti a
		<a href="http://community.elgg.org/pg/groups/discussion/">közösségi fórumokon</a>.',

	'update:twitter_api:deactivated' => 'Twitter API (előzőleg Twitter Service) kikapcsolásra került a frissítés során. Kapcsolja be manuálisan, ha szüksége van rá.',
	'update:oauth_api:deactivated' => 'OAuth API (előzőleg OAuth Lib) kikapcsolásra került a frissítés során. Kapcsolja be manuálisan, ha szüksége van rá.',

	'deprecated:function' => '%s() már elavult, használja ezt: %s()',

/**
 * Welcome
 */

	'welcome' => "Üdvözöljük",
	'welcome:user' => 'Üdvözöljük, %s!',

/**
 * Emails
 */
	'email:settings' => "E-mail beállítások",
	'email:address:label' => "E-mail cím",
	
	'email:save:success' => "Az új e-mail címet elmentettük, további megerősítés szükséges.",
	'email:save:fail' => "Az új e-mail címét nem sikerült elmenteni.",

	'friend:newfriend:subject' => "%s ismerősnek jelölte!",
	'friend:newfriend:body' => "%s ismerősnek jelölte!

Az adatlapja megtekintéséhez kattintson ide:

%s

Kérem, ne válaszoljon erre a levélre.",



	'email:resetpassword:subject' => "Jelszó frissítve!",
	'email:resetpassword:body' => "Kedves %s!
	
Jelszavát frissítettük a következőre: %s",


	'email:resetreq:subject' => "Új jelszó kérése.",
	'email:resetreq:body' => "Kedves %s!

	
Valaki (%s IP címről) új jelszót kért a fiókjához.

Ha Ön kérte, akkor kattintson az alábbi hivatkozásra, egyébként hagyja figyelmen kívül ezt az e-mailt.

%s
",

/**
 * user default access
 */

  'default_access:settings' => "Az Ön alapértelmezett hozzáférési szintje",
  'default_access:label' => "Hozzáférési szint",
  'user:default_access:success' => "Az új hozzáférési szint mentésre került.",
  'user:default_access:failure' => "Az új hozzáférési szint mentése nem sikerült.",

/**
 * XML-RPC
 */
	'xmlrpc:noinputdata'	=>	"Hiányzik a bemeneti adat",

/**
 * Comments
 */

	'comments:count' => "%s hozzászólt",
	
	'riveraction:annotation:generic_comment' => '%s hozzászólt ehhez: %s',

	'generic_comments:add' => "Hozzászólás hozzáadása",
	'generic_comments:post' => "Hozzászólás beküldése",
	'generic_comments:text' => "Hozzászólás szövege",
	'generic_comments:latest' => "Legfrissebb hozzászólások",
	'generic_comment:posted' => "Hozzászólása sikeresen elküldésre került.",
	'generic_comment:deleted' => "Hozzászólása sikeresen törölve.",
	'generic_comment:blank' => "Kérem, a mentéshez adja meg a hozzászólás szövegét.",
	'generic_comment:notfound' => "Nem található a kért elem.",
	'generic_comment:notdeleted' => "Nem sikerült a hozzászólás törlése.",
	'generic_comment:failure' => "Hiba történt a hozzászólás elküldésekor. Kérem, próbálja meg újból.",
	'generic_comment:none' => 'Nincs hozzászólás',
	'generic_comment:title' => '%s hozzászólása',

	'generic_comment:email:subject' => 'Új hozzászólás érkezett!',
	'generic_comment:email:body' => "Új hozzászólás érkezett a ehhez: \"%s\", hozzászólt: %s. Az üzenet:

	
%s


A válaszadáshoz vagy az eredeti hozzászólás megtekintéséhez kérem, kattintson ide:

%s

%s adatlapjának megtekintéséhez kattintson ide:

%s

Kérem, ne válaszoljon erre az e-mailre.",

/**
 * Entities
 */
	'byline' => '%s írta',
	'entity:default:strapline' => '%s létrehozva %s által',
	'entity:default:missingsupport:popup' => 'Ezt az elemet nem lehet helyesen megjeleníteni. Lehetséges oka, hogy olyan plugint igényel, amely nincs telepítve.',

	'entity:delete:success' => '%s sikeresen törölve',
	'entity:delete:fail' => '%s törlése sikertelen',


/**
 * Action gatekeeper
 */
	'actiongatekeeper:missingfields' => 'Az űrlapról hiányzik a __token vagy a __ts mezők',
	'actiongatekeeper:tokeninvalid' => 'Hiba lépett fel: a jelzés nem egyezik a szerver által generálttal. Lehetséges hogy lejárt az oldal, amit használt. Kérem próbálja újra.',
	'actiongatekeeper:timeerror' => 'Az úrlap lejárt, kérem, frissítse az oldalt és próbálkozzon újra.',
	'actiongatekeeper:pluginprevents' => 'Egy kiterjesztés megakadályozta, hogy az űrlap elküldésre kerüljön.',


/**
 * Word blacklists
 */
	'word:blacklist' => 'a, az, egy, és, vagy, de, is, meg, se, sem, hát, ez, az, így, úgy, itt, ott, ide, oda, ha, hogy',

/**
 * Tag labels
 */

	'tag_names:tags' => 'Címkék',
	'tags:site_cloud' => 'Honlap címkefelhő',

/**
 * Javascript
 */

	'js:security:token_refresh_failed' => 'A kapcsolat nem hozható létre ezzel: %s. Lehetséges hogy probléma lesz a tartalmak mentésénél.',
	'js:security:token_refreshed' => 'A kapcsolat helyreállt ezzel: %s!',

/**
 * Languages according to ISO 639-1
 */
	"aa" => "Afar",
	"ab" => "Abház",
	"af" => "Afrikaans",
	"am" => "Amhara",
	"ar" => "Arab",
	"as" => "Asszámi",
	"ay" => "Ajmara",
	"az" => "Azeri",
	"ba" => "Baskír",
	"be" => "Belarusz",
	"bg" => "Bolgár",
	"bh" => "Bhojpuri",
	"bi" => "Bislama",
	"bn" => "Bengáli",
	"bo" => "Tibeti",
	"br" => "Breton",
	"ca" => "Katalán",
	"co" => "Korzikai",
	"cs" => "Cseh",
	"cy" => "Wales-i",
	"da" => "Dán",
	"de" => "Német",
	"dz" => "Dzongkha",
	"el" => "Görög",
	"en" => "Angol",
	"eo" => "Eszperantó",
	"es" => "Spanyol",
	"et" => "Észt",
	"eu" => "Baszk",
	"fa" => "Perzsa",
	"fi" => "Finn",
	"fj" => "Fidzsi",
	"fo" => "Feröeri",
	"fr" => "Francia",
	"fy" => "Fríz",
	"ga" => "Ír",
	"gd" => "Skót-gael",
	"gl" => "Galíciai",
	"gn" => "Guarani",
	"gu" => "Gujarati",
	"he" => "Héber",
	"ha" => "Hausa",
	"hi" => "Hindi",
	"hr" => "Horvát",
	"hu" => "Magyar",
	"hy" => "Örmény",
	"ia" => "Interlingva",
	"id" => "Indonéz",
	"ie" => "Interlingue",
	"ik" => "Inupiak",
	//"in" => "Indonesian",
	"is" => "Izlandi",
	"it" => "Olasz",
	"iu" => "Inuktitut",
	"iw" => "Héber (elavult)",
	"ja" => "Japán",
	"ji" => "Jiddis (elavult)",
	"jw" => "Jávai",
	"ka" => "Grúz",
	"kk" => "Kazah",
	"kl" => "Grönlandi",
	"km" => "Khmer",
	"kn" => "Kannada",
	"ko" => "Koreai",
	"ks" => "Kasmiri",
	"ku" => "Kurd",
	"ky" => "Kirgiz",
	"la" => "Latin",
	"ln" => "Lingala",
	"lo" => "Laoszi",
	"lt" => "Litván",
	"lv" => "Lett",
	"mg" => "Malagasy",
	"mi" => "Maori",
	"mk" => "Macedón",
	"ml" => "Malayalam",
	"mn" => "Mongol",
	"mo" => "Moldáv",
	"mr" => "Marathi",
	"ms" => "Maláj",
	"mt" => "Máltai",
	"my" => "Birmani",
	"na" => "Naurui",
	"ne" => "Nepáli",
	"nl" => "Holland",
	"no" => "Norvég",
	"oc" => "Okcitán",
	"om" => "Oromo",
	"or" => "Oriya",
	"pa" => "Pandzsábi",
	"pl" => "Lengyel",
	"ps" => "Pastu",
	"pt" => "Portugál",
	"qu" => "Kecsua",
	"rm" => "Rétoromán",
	"rn" => "Kirundi",
	"ro" => "Román",
	"ru" => "Orosz",
	"rw" => "Kinyarwanda",
	"sa" => "Szanszkrit",
	"sd" => "Sindhi",
	"sg" => "Sangro",
	"sh" => "Szerbhorvát",
	"si" => "Szingaléz",
	"sk" => "Szlovák",
	"sl" => "Szlovén",
	"sm" => "Szamoai",
	"sn" => "Shona",
	"so" => "Szomáli",
	"sq" => "Albán",
	"sr" => "Szerb",
	"ss" => "Siswati",
	"st" => "Sesotho",
	"su" => "Szundanéz",
	"sv" => "Svéd",
	"sw" => "Szuahéli",
	"ta" => "Tamil",
	"te" => "Tegulu",
	"tg" => "Tadzsik",
	"th" => "Thaiföldi",
	"ti" => "Tigrinja",
	"tk" => "Türkmén",
	"tl" => "Tagalog",
	"tn" => "Setswana",
	"to" => "Tongai",
	"tr" => "Török",
	"ts" => "Tsonga",
	"tt" => "Tatár",
	"tw" => "Twi",
	"ug" => "Ujgur",
	"uk" => "Ukrán",
	"ur" => "Urdu",
	"uz" => "Üzbég",
	"vi" => "Vietnami",
	"vo" => "Volapük",
	"wo" => "Wolof",
	"xh" => "Xhosa",
	//"y" => "Yiddish",
	"yi" => "Jiddis",
	"yo" => "Yoruba",
	"za" => "Zuang",
	"zh" => "Kínai",
	"zu" => "Zulu",
);

add_translation("hu",$hungarian);

?>
