<?php
/**
 * Elgg garbage collector language pack.
 *
 * @package ElggGarbageCollector
 */

$hungarian = array(
	'garbagecollector:period' => 'Milyen gyakran fusson le a rendszerszintű szemétgyűjtés?',

	'garbagecollector:weekly' => 'Hetente egyszer',
	'garbagecollector:monthly' => 'Havonta egyszer',
	'garbagecollector:yearly' => 'Évente egyszer',

	'garbagecollector' => "SZEMÉTGYŰJTŐ\n",
	'garbagecollector:done' => "KÉSZ\n",
	'garbagecollector:optimize' => "%s optimalizálása ",

	'garbagecollector:error' => "HIBA",
	'garbagecollector:ok' => "RENDBEN",

	'garbagecollector:gc:metastrings' => 'Nem használt metasztringek törlése: ',
);

add_translation("hu",$hungarian);

?>
