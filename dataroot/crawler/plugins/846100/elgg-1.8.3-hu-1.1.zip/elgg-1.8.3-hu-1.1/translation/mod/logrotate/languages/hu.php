<?php
/**
 * Elgg log rotator language pack.
 *
 * @package ElggLogRotate
 */

$hungarian = array(
	'logrotate:period' => 'Milyen gyakran legyen a rendszernapló archiválva?',

	'logrotate:weekly' => 'Hetente egyszer',
	'logrotate:monthly' => 'Havonta egyszer',
	'logrotate:yearly' => 'Évente egyszer',

	'logrotate:logrotated' => "Napló sikeresen forgatva\n",
	'logrotate:lognotrotated' => "Napló forgatása sikertelen\n",
	
	'logrotate:delete' => 'Archivált naplók törlése, amelyek régebbiek mint egy',

	'logrotate:week' => 'hét',
	'logrotate:month' => 'hónap',
	'logrotate:year' => 'év',
		
	'logrotate:logdeleted' => "Napló sikeresen törölve\n",
	'logrotate:lognotdeleted' => "Napló törlése sikertelen\n",
);

add_translation("hu",$hungarian);

?>
