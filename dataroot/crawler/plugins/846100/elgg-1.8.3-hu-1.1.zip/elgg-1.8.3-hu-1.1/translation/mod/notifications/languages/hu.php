<?php

$hungarian = array(

	'friends:all' => 'Összes ismerős',

	'notifications:subscriptions:personal:description' => 'Ha szeretne értesítéseket kapni arról, hogy mi történik Önnel kapcsolatban a weboldalon, jelölje be a megfelelő rublikákat.',
	'notifications:subscriptions:personal:title' => 'Személyes értesítések',

	'notifications:subscriptions:friends:title' => 'Értesítések ismerősökről',
	'notifications:subscriptions:friends:description' => 'Az alábbi csoportban az összes ismerőse megtalálható. Ha szeretné tudni, mi történik velük, jelölje be a megfelelő rublikákat.',
	'notifications:subscriptions:collections:edit' => 'A megosztott hozzáférésű értesítések beállításához kattintson ide!',

	'notifications:subscriptions:changesettings' => 'Értesítések',
	'notifications:subscriptions:changesettings:groups' => 'Csoport értesítések',

	'notifications:subscriptions:title' => 'Értesítések felhasználók szerint',
	'notifications:subscriptions:description' => 'Ha szeretne értesítéseket kapni az egyes ismerőseiről, jelölje be a megfeleő riblikát.',

	'notifications:subscriptions:groups:description' => 'Ha szeretne értesítéseket kapni a csoportokról, amelyeknek tagja, jelölje be a megfelelő rublikákat.',

	'notifications:subscriptions:success' => 'Az értesítések beállításai sikeresen mentve.',
	
);

add_translation("hu",$hungarian);

?>
