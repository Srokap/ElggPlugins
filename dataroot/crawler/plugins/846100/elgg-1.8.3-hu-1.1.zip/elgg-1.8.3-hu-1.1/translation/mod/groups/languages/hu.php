<?php
/**
 * Elgg groups plugin language pack
 *
 * @package ElggGroups
 */

$hungarian = array(

	/**
	 * Menu items and titles
	 */
	'groups' => "Csoportok",
	'groups:owned' => "Saját csoportok",
	'groups:yours' => "Kedvenc csoportok",
	'groups:user' => "%s csoportjai",
	'groups:all' => "Összes csoport",
	'groups:add' => "Csoport létrehozása",
	'groups:edit' => "Csoport szerkesztése",
	'groups:delete' => 'Csoport törlése',
	'groups:membershiprequests' => 'Csatlakozási kérelmek elbírálása',
	'groups:invitations' => 'Csoport meghívások',

	'groups:icon' => 'Csoport ikonja (hagyja üresen ha nem akarja megváltoztatni)',
	'groups:name' => 'Csoport neve',
	'groups:username' => 'Csoport rövid neve (az URL-ben fog megjelenni, csak betűk és számok megengedettek)',
	'groups:description' => 'Leírás',
	'groups:briefdescription' => 'Rövid leírás',
	'groups:interests' => 'Címkék',
	'groups:website' => 'Weboldal',
	'groups:members' => 'Csoporttagok',
	'groups:members:title' => '%s csoport tagjai',
	'groups:members:more' => "Minden tag megtekinése",
	'groups:membership' => "Csatlakozás módja",
	'groups:access' => "Hozzáférési jogosultságok",
	'groups:owner' => "Tulajdonos",
	'groups:widget:num_display' => 'Megjelenítendő csoportok száma',
	'groups:widget:membership' => 'Csoporttagság',
	'groups:widgets:description' => 'Megmutatja hogy mely csoportoknak a tagja',
	'groups:noaccess' => 'Nincs hozzáférése a csoporthoz',
	'groups:permissions:error' => 'Nincs hozzáférése ehhez',
	'groups:ingroup' => 'ebben a csoportban',
	'groups:cantedit' => 'Nem szerkesztheti ezt a csoportot',
	'groups:saved' => 'Csoport sikeresen elmentve',
	'groups:featured' => 'Kiemelt csoportok',
	'groups:makeunfeatured' => 'Kiemelés visszavonása',
	'groups:makefeatured' => 'Kiemelés',
	'groups:featuredon' => '%s mostantól egy kiemelt csoport.',
	'groups:unfeatured' => '%s már nem kiemelt csoport többé.',
	'groups:featured_error' => 'Érvénytelen csoport.',
	'groups:joinrequest' => 'Csatlakozási kérelem benyújtása',
	'groups:join' => 'Csatlakozás a csoporthoz',
	'groups:leave' => 'Csoport elhagyása',
	'groups:invite' => 'Ismerősök meghívása',
	'groups:invite:title' => 'Imserősök meghívása a csoportba',
	'groups:inviteto' => "Ismerősök meghívása ide: '%s'",
	'groups:nofriends' => "Nincs több ismerőse, akit meghívhatna a csoportba.",
	'groups:nofriendsatall' => 'Nincsenek meghívható ismerősei!',
	'groups:viagroups' => "hozzászólt ehhez:",
	'groups:group' => "Csoport",
	'groups:search:tags' => "Címke",
	'groups:search:title' => "Csoportok keresésé erre a címkére: '%s'",
	'groups:search:none' => "Nem található ilyen csoport",
	'groups:search_in_group' => "Keresés ebben a csoportban",
	'groups:acl' => "Csoport: %s",

	'groups:activity' => "Csoport hírfolyam",
	'groups:enableactivity' => 'Csoport hírfolyam engedélyezése',
	'groups:activity:none' => "Nincsenek hírek",

	'groups:notfound' => "A csoport nem található",
	'groups:notfound:details' => "A keresett csoport nem létezik vagy nincs hozzáférése",

	'groups:requests:none' => 'Nincsenek csatlakozási kérelmek.',

	'groups:invitations:none' => 'Nincsenek meghívások.',

	'item:object:groupforumtopic' => "Fórumtémák",

	'groupforumtopic:new' => "Fórumbejegyzés hozzáadása",

	'groups:count' => "csoport készült",
	'groups:open' => "nyílt csoport",
	'groups:closed' => "zárt csoport",
	'groups:member' => "tag",
	'groups:searchtag' => "Csoport keresése címkével",

	'groups:more' => 'További csoportok',
	'groups:none' => 'Nincsenek csoportok',


	/*
	 * Access
	 */
	'groups:access:private' => 'Zárt, csak meghívó alapján',
	'groups:access:public' => 'Nyitott, bárki beléphet',
	'groups:access:group' => 'Csak csoporttagoknak',
	'groups:closedgroup' => 'Ez egy zárt csoport.',
	'groups:closedgroup:request' => 'Kattintson a "Csatlakozási kérelem benyújtása" gombra a felvételéhez.',
	'groups:visibility' => 'Ki láthatja ezt a csoportot?',

	/*
	Group tools
	*/
	'groups:enableforum' => 'Csoport fórum engedélyezése',
	'groups:yes' => 'igen',
	'groups:no' => 'nem',
	'groups:lastupdated' => 'Utolsó frissítés: %s, %s által',
	'groups:lastcomment' => 'Utolsó hozzászólás: %s, %s által',

	/*
	Group discussion
	*/
	'discussion' => 'Fórum',
	'discussion:add' => 'Fórumtéma hozzáadása',
	'discussion:latest' => 'Legfrissebb fórumtémák',
	'discussion:group' => 'Csoport fórum',
	'discussion:none' => 'Nincsenek fórumtémák',
	'discussion:reply:title' => '%s válasza',

	'discussion:topic:created' => 'Fórumtéma sikeresen létrehozva.',
	'discussion:topic:updated' => 'Fórumtéma sikeresen frissítve.',
	'discussion:topic:deleted' => 'Fórumtéma sikeresen törölve.',

	'discussion:topic:notfound' => 'Fórumtéma nem található',
	'discussion:error:notsaved' => 'Fórumtéma mentése sikertelen',
	'discussion:error:missing' => 'A címet és a törzs részt is ki kell tölteni!',
	'discussion:error:permissions' => 'Ehhez nincs jogosultsága',
	'discussion:error:notdeleted' => 'Fórumtéma törlése sikertelen',

	'discussion:reply:deleted' => 'Válasz sikeresen törölve.',
	'discussion:reply:error:notdeleted' => 'Válasz törlése sikertelen',

	'reply:this' => 'Válasz erre',

	'group:replies' => 'Válaszok',
	'groups:forum:created' => '%s elkészült %d hozzászólással',
	'groups:forum:created:single' => '%s elkészült %d válasszal',
	'groups:forum' => 'Fórum',
	'groups:addtopic' => 'Fórumtéma hozzáadása',
	'groups:forumlatest' => 'Legfrissebb fórumtémák',
	'groups:latestdiscussion' => 'Legfrissebb fórumtémák',
	'groups:newest' => 'Legfrissebb',
	'groups:popular' => 'Népszerű',
	'groupspost:success' => 'Válasz sikeresen beküldve',
	'groups:alldiscussion' => 'Legfrissebb fórumtémák',
	'groups:edittopic' => 'Fórumtéma szerkesztése',
	'groups:topicmessage' => 'Törzs',
	'groups:topicstatus' => 'Állapot',
	'groups:reply' => 'Hozzászólás beküldése',
	'groups:topic' => 'Fórumtéma',
	'groups:posts' => 'Bejegyzések',
	'groups:lastperson' => 'Legutóbbi válaszadó',
	'groups:when' => 'Mikor',
	'grouptopic:notcreated' => 'Nincsenek fórumtémák',
	'groups:topicopen' => 'Nyílt',
	'groups:topicclosed' => 'Zárt',
	'groups:topicresolved' => 'Lezárva',
	'grouptopic:created' => 'Fórumtéma sikeresen létrehozva.',
	'groupstopic:deleted' => 'Fórumtéma sikeresen törölve.',
	'groups:topicsticky' => 'Kiemelt',
	'groups:topicisclosed' => 'Ez a fórumtéma zárt.',
	'groups:topiccloseddesc' => 'Ez a fórumtéma zárt, ezért nem lehet hozzászólást beküldeni.',
	'grouptopic:error' => 'A fórumtéma létrehozása sikertelen. Próbája meg újra, vagy szóljon a rendszergazdának.',
	'groups:forumpost:edited' => "Fórumbejegyzés sikeresen módosítva.",
	'groups:forumpost:error' => "Fórumbejegyzés módosítása sikertelen.",


	'groups:privategroup' => 'Ez a csoport zárt. Csatlakozási kérelem benyújtása.',
	'groups:notitle' => 'Címet kell adni a csoportnak',
	'groups:cantjoin' => 'Nem csatlakozhat a csoporthoz',
	'groups:cantleave' => 'Csoport elhagyása sikertelen',
	'groups:removeuser' => 'Törlés a csoportból',
	'groups:cantremove' => 'Felhasználó törlése a csoportból sikertelen',
	'groups:removed' => '%s sikeresen törölve a csoportból',
	'groups:addedtogroup' => 'Felhasználó sikeresen hozzáadva a csoporthoz',
	'groups:joinrequestnotmade' => 'Kérelem benyújtása sikertelen',
	'groups:joinrequestmade' => 'Kérelem siekresen benyújtva',
	'groups:joined' => 'Sikeresen csatlakozott a csoporthoz!',
	'groups:left' => 'Sikeresen elhagyta a csoportot',
	'groups:notowner' => 'Nem az Öné ez a csoport.',
	'groups:notmember' => 'Nem tagja ennek a csoportnak.',
	'groups:alreadymember' => 'Már tagja ennek a csoportnak!',
	'groups:userinvited' => 'Felhasználó sikeresen meghívva.',
	'groups:usernotinvited' => 'Felhasználó meghívása sikertelen.',
	'groups:useralreadyinvited' => 'A felhasználó már meg volt hívva',
	'groups:invite:subject' => "%s, meghívták hogy csatlakozzon ide: %s!",
	'groups:updated' => "Utolsó választ %s írta %s",
	'groups:started' => "%s indította",
	'groups:joinrequest:remove:check' => 'Biztos hogy törli ezt a csatlakozási kérelmet?',
	'groups:invite:remove:check' => 'Biztos hogy törli ezt a meghívást?',
	'groups:invite:body' => "Kedves %s!

%s meghívta hogy csatlakozzon ehhez a csoporthoz: '%s'. Kattinson az alábbi hivatkozásra a meghívója megtekintéséhez:

%s",

	'groups:welcome:subject' => "Üdvözöljük a(z) %s csoportban!",
	'groups:welcome:body' => "Kedves %s!

Ön mostantól tagja ennek a csoportnak: '%s'! Kattintson az alábbi hivatkozásra:

%s",

	'groups:request:subject' => "%s szeretne csatlakozni ide: %s",
	'groups:request:body' => "Kedves %s!

%s csatlakozni szeretne ehhez a csoporthoz: '%s'. Kattintson az alábbi hivatkozásra az adatlapja megtekintéséhez:

%s

vagy kattinton ide a csatlakozási kérelmek megtekintéséhez:

%s",

	/*
		Forum river items
	*/

	'river:create:group:default' => '%s létrehozott egy csoportot: %s',
	'river:join:group:default' => '%s csatlakozott ehhez a csoporthoz: %s',
	'river:create:object:groupforumtopic' => '%s létrehozott egy fórumtémát: %s',
	'river:reply:object:groupforumtopic' => '%s válaszolt erre a fórumtémára: %s',
	
	'groups:nowidgets' => 'Nincsenek modulok ehhez a csoporthoz.',


	'groups:widgets:members:title' => 'Csoporttagok',
	'groups:widgets:members:description' => 'A csoport tagjainak listája.',
	'groups:widgets:members:label:displaynum' => 'Csoporttagok megjelenítése.',
	'groups:widgets:members:label:pleaseedit' => 'A modul még nincs beállítva.',

	'groups:widgets:entities:title' => "Elemek a csoportban",
	'groups:widgets:entities:description' => "A csoportba lementett elemek listája",
	'groups:widgets:entities:label:displaynum' => 'Csoportelemek megjelenítése.',
	'groups:widgets:entities:label:pleaseedit' => 'A modul még nincs beállítva.',

	'groups:forumtopic:edited' => 'Fórumtéma sikeresen módosítva.',

	'groups:allowhiddengroups' => 'Engedélyezi a privát (láthatatlan) csoportokat?',

	/**
	 * Action messages
	 */
	'group:deleted' => 'Csoport és minden tartalma sikeresen törölve',
	'group:notdeleted' => 'Csoport törlése sikertelen',

	'group:notfound' => 'A csoport nem található',
	'grouppost:deleted' => 'Csoportbejegyzések sikeresen törölve',
	'grouppost:notdeleted' => 'Csoportbejegyzések törlése sikertelen',
	'groupstopic:deleted' => 'Fórumtéma sikeresen törölve',
	'groupstopic:notdeleted' => 'Fórumtéma törlése sikertelen',
	'grouptopic:blank' => 'Nincsenek fórumtémák',
	'grouptopic:notfound' => 'Fórumtéma nem található',
	'grouppost:nopost' => 'Üres bejegyzés',
	'groups:deletewarning' => "Biztos hogy törli ezt a csoportot? Utólag nincs lehetősége visszavonni!",

	'groups:invitekilled' => 'Meghívás sikeresen törölve.',
	'groups:joinrequestkilled' => 'Csatlakozási kérelem sikeresen törölve.',

	// ecml
	'groups:ecml:discussion' => 'Csoport fórum',
	'groups:ecml:groupprofile' => 'Csoport adatlap',
	
);

add_translation("hu",$hungarian);

?>
