<?php
/**
 * Custom Index Hungarian language file
 */

$hungarian = array(
	'custom:bookmarks' => "Legújabb könyvjelzők",
	'custom:groups' => "Legújabb csoportok",
	'custom:files' => "Legújabb fájlok",
	'custom:blogs' => "Legújabb cikkek",
	'custom:members' => "Legújabb tagok",
);

add_translation("hu",$hungarian);

?>
