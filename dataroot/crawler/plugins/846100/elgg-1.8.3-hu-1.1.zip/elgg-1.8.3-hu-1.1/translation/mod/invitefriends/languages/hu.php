<?php

/**
 * Elgg invite language file
 * 
 * @package ElggInviteFriends
 */

$hungarian = array(

	'friends:invite' => 'Ismerősök meghívása',
	
	'invitefriends:registration_disabled' => 'A regisztráció ki van kapcsolva a weboldalon, így nem lehet ismerősöket meghívni.',
	
	'invitefriends:introduction' => 'Az ismerősök meghívásához a honlapra sorolja fel egymás alá az e-mail címeiket (soronént egyet):',
	'invitefriends:message' => 'Töltse ki a meghívó szövegét:',
	'invitefriends:subject' => '%s meghívó',

	'invitefriends:success' => 'A meghívókat sikeresen elküldtük.',
	'invitefriends:invitations_sent' => 'Meghívók elküldve: %s. A következő problémák adódtak:',
	'invitefriends:email_error' => 'A következő e-mail címek nem érvényesek: %s',
	'invitefriends:already_members' => 'A következő felhasználók már tagok: %s',
	'invitefriends:noemails' => 'Nem adott meg e-mail címeket.',
	
	'invitefriends:message:default' => '
Szia!

Szeretnélek meghívni ebbe a közösségbe: %s.',

	'invitefriends:email' => '
Önt meghívták hogy csatlakozzon ide: %s. A meghívót %s küldte, ezzel a szöveggel:

%s

A csatlakozáshoz kattintson az alábbi hivatkozásra:

%s

A regisztráció után az ismerősei automatikusan be lesznek jelölve Önnek a rendszerben.',
	
);

add_translation("hu",$hungarian);

?>
