<?php
/**
 * Elgg log browser plugin language pack
 *
 * @package ElggLogBrowser
 */

$hungarian = array(
	'admin:administer_utilities:logbrowser' => 'Napló böngészése',
	'logbrowser' => 'Napló böngészése',
	'logbrowser:browse' => 'Rendszernapló böngészése',
	'logbrowser:search' => 'Eredmények szűrése',
	'logbrowser:user' => 'Keresés felhasználónév alapján',
	'logbrowser:starttime' => 'Kezdete (például "last monday", vagy "1 hour ago")',
	'logbrowser:endtime' => 'Vége',

	'logbrowser:explore' => 'Napló böngészése',

	'logbrowser:date' => 'Dátum és idő',
	'logbrowser:user:name' => 'Felhasználó',
	'logbrowser:user:guid' => 'Felhasználó GUID',
	'logbrowser:object' => 'Objektum típusa',
	'logbrowser:object:guid' => 'Objektum GUID',
	'logbrowser:action' => 'Művelet',
);

add_translation("hu",$hungarian);

?>
