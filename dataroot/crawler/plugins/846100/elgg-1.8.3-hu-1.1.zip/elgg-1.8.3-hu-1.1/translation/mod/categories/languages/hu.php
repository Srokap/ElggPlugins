<?php
/**
 * Categories Hungarian language file
 */

$hungarian = array(
	'categories' => 'Kategóriák',
	'categories:settings' => 'Kategóriák meghatározása',
	'categories:explanation' => 'Az előre meghatározott, az egész honlapon átívelő kategóriák lérehozásához sorolja fel őket vesszővel elválasztva. Az erre alkalmas eszközök automatikusan megjelenítik majd, amikor a felhasználók új tartalmakat hoznak létre.',
	'categories:save:success' => 'Kategóriák sikeresen mentve.',
	'categories:results' => "Találatok erre a kategóriára: %s",
	'categories:on_activate_reminder' => "A kategóriák nem üzemelnek amíg meg nem határozza azokat. <a href=\"%s\">Kategóriák meghatározása.</a>",
);

add_translation("hu",$hungarian);

?>
