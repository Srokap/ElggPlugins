<?php
/**
 * Tag cloud Hungarian language file
 */

$hungarian = array(
	'tagcloud:widget:title' => 'Címkefelhő',
	'tagcloud:widget:description' => 'A honalpon előforduló címkék listája',
	'tagcloud:widget:numtags' => 'Megjelenítendő címkék listája',
);

add_translation("hu",$hungarian);

?>
