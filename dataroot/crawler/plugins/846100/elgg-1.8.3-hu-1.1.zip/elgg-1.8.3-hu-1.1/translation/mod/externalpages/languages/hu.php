<?php
/**
 * External pages Hungarian language file
 */

$hungarian = array(

	/**
	 * Menu items and titles
	 */
	'expages' => "Kiemelt oldalak",
	'admin:appearance:expages' => "Kiemelt oldalak",
	'expages:about' => "Rólunk",
	'expages:terms' => "Feltételek",
	'expages:privacy' => "Adatvédelem",
	'expages:contact' => "Kapcsolat",

	'expages:notset' => "Ez az oldal még nincs megfelelően beállítva.",

	/**
	 * Status messages
	 */
	'expages:posted' => "Az oldal sikeresen frissítve.",
	'expages:error' => "Az oldal mentése sikertelen.",
);

add_translation("hu",$hungarian);

?>
