<?php

$hungarian = array(
	'search:enter_term' => 'Keresett kifejezés:',
	'search:no_results' => 'Nincs találat.',
	'search:matched' => 'Találatok: ',
	'search:results' => 'Találatok erre: %s',
	'search:no_query' => 'Adja meg a keresett kifejezést a kereséshez.',
	'search:search_error' => 'Hiba',

	'search:more' => '+ még %s innen: %s',

	'search_types:tags' => 'Címkék',

	'search_types:comments' => 'Hozzászólások',
	'search:comment_on' => 'Hozzászólás erre: "%s"',
	'search:comment_by' => 'beküldte',
	'search:unavailable_entity' => 'A kért elem nem elérhető',
);

add_translation("hu",$hungarian);

?>
