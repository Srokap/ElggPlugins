<?php
/**
 * The Wire Hungarian language file
 */

$hungarian = array(

	/**
	 * Menu items and titles
	 */
	'thewire' => "Üzenőfal",
	'thewire:everyone' => "Minden bejegyzés",
	'thewire:user' => "%s bejegyzései",
	'thewire:friends' => "Ismerősök bejegyzései",
	'thewire:reply' => "Válasz",
	'thewire:replying' => "Válasz %s bejegyzésére (@%s), ami így szólt",
	'thewire:thread' => "Teljes beszélgetés",
	'thewire:charleft' => "karakter van hátra",
	'thewire:tags' => "Üzenőfal bejegyzések ilyen címkével: '%s'",
	'thewire:noposts' => "Nincsenek bejegyzések",
	'item:object:thewire' => "Bejegyzések",
	'thewire:update' => 'Frissítés',
	'thewire:by' => 'Bejegyzés %s által',

	'thewire:previous' => "Előzmény mutatása",
	'thewire:hide' => "Előzmény elrejtése",
	'thewire:previous:help' => "Az előző bejegyzés megjelenítése",
	'thewire:hide:help' => "Az előző bejegyzés elrejtése",

	/**
	 * The wire river
	 */
	'river:create:object:thewire' => "%s írt az %s",
	'thewire:wire' => 'üzenőfalra',

	/**
	 * Wire widget
	 */
	'thewire:widget:desc' => 'Megjeleníti az üzenőfalra írt legutóbbi bejegyzéseit',
	'thewire:num' => 'Megjelenítendő bejegyzések száma',
	'thewire:moreposts' => 'További bejegyzések',

	/**
	 * Status messages
	 */
	'thewire:posted' => "Bejegyzés sikeresen elküldve.",
	'thewire:deleted' => "Bejegyzés sikeresen törölve.",
	'thewire:blank' => "Nem adott meg szöveget!",
	'thewire:notfound' => "A keresett bejegyzés nem található.",
	'thewire:notdeleted' => "Bejegyzés törlése sikertelen.",

	/**
	 * Notifications
	 */
	'thewire:notify:subject' => "Új bejegyzés az üzenőfalon",
	'thewire:notify:reply' => 'A választ %s küldte %s részére az üzenőfalon:',
	'thewire:notify:post' => '%s írta az üzenőfalra:',
	
);

add_translation("hu",$hungarian);

?>
