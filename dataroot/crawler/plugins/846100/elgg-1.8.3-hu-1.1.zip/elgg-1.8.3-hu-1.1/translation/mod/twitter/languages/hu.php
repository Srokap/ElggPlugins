<?php
/**
 * Twitter widget language file
 */

$hungarian = array(

	'twitter:title' => 'Twitter',
	'twitter:info' => 'Megmutatja a legfrissebb Twitter bejegyzéseket',
	'twitter:username' => 'Twitter felhasználónev',
	'twitter:num' => 'Megjelenítendő bejegyzések száma',
	'twitter:visit' => 'Ugrás a Twitterre',
	'twitter:notset' => 'Ez a Twitter modul még nincs megfelelően beállítva. A legfrissebb Twitter bejegyzések megjelenítéséhez kattintson a \'Modul testreszabása\' gombra és adja meg az adatait',
);

add_translation("hu",$hungarian);

?>
