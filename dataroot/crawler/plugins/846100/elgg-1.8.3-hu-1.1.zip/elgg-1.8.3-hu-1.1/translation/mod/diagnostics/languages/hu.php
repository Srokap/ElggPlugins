<?php
/**
 * Elgg diagnostics language pack.
 *
 * @package ElggDiagnostics
 */

$hungarian = array(
	'admin:administer_utilities:diagnostics' => 'Rendszerdiagnosztika',
	'diagnostics' => 'Rendszerdiagnosztika',
	'diagnostics:report' => 'Diagnosztikai jelentés',
	'diagnostics:description' => 'Az alábbi dokumentum az Elgg rendszerével kapcsolatos problémák felderítésére szolgál. Az Elgg fejlesztői kérhetik Öntől hogy csatolja egy hibajelentéshez.',
	'diagnostics:download' => 'Letöltés',
	'diagnostics:header' => '========================================================================
Elgg rendszerdiagnosztikai jelentés
Készült ekkor: %s, %s által
========================================================================

',
	'diagnostics:report:basic' => '
Elgg kiadás: %s, verzió: %s

------------------------------------------------------------------------',
	'diagnostics:report:php' => '
PHP infó:
%s
------------------------------------------------------------------------',
	'diagnostics:report:plugins' => '
Telepített bővítmények részletei:

%s
------------------------------------------------------------------------',
	'diagnostics:report:md5' => '
Telepített fájlok és ellenőrző összegek:

%s
------------------------------------------------------------------------',
	'diagnostics:report:globals' => '
Globális változók:

%s
------------------------------------------------------------------------',
);

add_translation("hu",$hungarian);

?>
