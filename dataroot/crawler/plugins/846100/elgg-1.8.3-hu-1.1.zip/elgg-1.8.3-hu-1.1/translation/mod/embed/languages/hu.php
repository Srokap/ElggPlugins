<?php
/**
 * Embed Hungarian language strings
 *
 */

$hungarian = array(
	'embed:embed' => 'Beillesztés',
	'embed:media' => 'Tartalom beillesztése',
	'embed:instructions' => 'Kattintson egy fájlra a szövegbe való beillesztéshez.',
	'embed:upload' => 'Fájl feltöltése',
	'embed:upload_type' => 'Feltöltés típusa: ',

	// messages
	'embed:no_upload_content' => 'Nincs kiválasztott tartalom!',
	'embed:no_section_content' => 'Az elemek nem találhatóak.',

	'embed:no_sections' => 'Nincs támogatott bővítmény a beillesztéshez. Szóljon a honlap adminisztátorának hogy engedélyezze a beillesztésért felelős bővítményt.',
);

add_translation("hu",$hungarian);

?>
