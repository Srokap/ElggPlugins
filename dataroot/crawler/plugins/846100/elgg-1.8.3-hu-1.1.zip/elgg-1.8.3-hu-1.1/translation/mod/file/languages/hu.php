<?php
/**
 * Elgg file plugin language pack
 *
 * @package ElggFile
 */

$hungarian = array(

	/**
	 * Menu items and titles
	 */
	'file' => "Fájlok",
	'file:user' => "%s fájljai",
	'file:friends' => "Ismerősök fájljai",
	'file:all' => "Minden fájl",
	'file:edit' => "Fájl szerkesztése",
	'file:more' => "További fájlok",
	'file:list' => "lista nézet",
	'file:group' => "Csoport fájlok",
	'file:gallery' => "ikon nézet",
	'file:gallery_list' => "Ikon vagy lista nézet",
	'file:num_files' => "Megjelenítendő fájlok száma",
	'file:user:gallery'=>'%s galériájának megtekintése',
	'file:via' => 'hozzászólt ehhez:',
	'file:upload' => "Fájl feltöltése",
	'file:replace' => 'Fájl lecserélése (hagyja üresen ha nem akarja megváltoztatni)',
	'file:list:title' => "%s %s %s",
	'file:title:friends' => "Ismerősök",

	'file:add' => 'Fájl feltöltése',

	'file:file' => "Fájl",
	'file:title' => "Cím",
	'file:desc' => "Leírás",
	'file:tags' => "Címkék",

	'file:list:list' => 'Lista nézetre váltás',
	'file:list:gallery' => 'Ikon nézetre váltás',

	'file:types' => "Feltöltött fájltípusok",

	'file:type:' => 'Fájlok',
	'file:type:all' => "Minden fájl",
	'file:type:video' => "Videók",
	'file:type:document' => "Dokumentumok",
	'file:type:audio' => "Zenék",
	'file:type:image' => "Képek",
	'file:type:general' => "Egyéb",

	'file:user:type:video' => "%s videói",
	'file:user:type:document' => "%s dokumentumai",
	'file:user:type:audio' => "%s zenéi",
	'file:user:type:image' => "%s képei",
	'file:user:type:general' => "%s egyéb fájljai",

	'file:friends:type:video' => "Ismerősök videói",
	'file:friends:type:document' => "Ismerősök dokumentumai",
	'file:friends:type:audio' => "Ismerősök zenéi",
	'file:friends:type:image' => "Ismerősök képei",
	'file:friends:type:general' => "Ismerősök egyéb fájljai",

	'file:widget' => "Fájl modul",
	'file:widget:description' => "Megmutatja a legutóbb feltöltött fájljait",

	'groups:enablefiles' => 'Csoportfájlok engedélyezése',

	'file:download' => "Letöltés",

	'file:delete:confirm' => "Biztos hogy törli ezt a fájlt?",

	'file:tagcloud' => "Címkefelhő",

	'file:display:number' => "Megjelenítendő fájlok száma",

	'river:create:object:file' => '%s feltöltött egy fájlt: %s',
	'river:comment:object:file' => '%s hozzászólt ehhez a fájlhoz: %s',

	'item:object:file' => 'Fájlok',

	'file:newupload' => 'Egy új fájl feltöltésre került',

	/**
	 * Embed media
	 **/

		'file:embed' => "Tartalom beillesztése",
		'file:embedall' => "Összes",

	/**
	 * Status messages
	 */

		'file:saved' => "A fájl sikeresn feltöltve.",
		'file:deleted' => "A fájl sikeresen törlölve.",

	/**
	 * Error messages
	 */

		'file:none' => "Nincsenek fájlok",
		'file:uploadfailed' => "A fájl mentése sikertelen.",
		'file:downloadfailed' => "A fájl jelenleg nem elérhető.",
		'file:deletefailed' => "A fájl törlése sikertelen.",
		'file:noaccess' => "Nincs jogosultsága megváltoztatni a fájlt",
		'file:cannotload' => "Hiba történt a feltöltés során",
		'file:nofile' => "Válasszon ki egy fájlt",
);

add_translation("hu",$hungarian);

?>
