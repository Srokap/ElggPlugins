<?php
/**
 * Elgg reported content plugin language pack
 *
 * @package ElggReportedContent
 */

$hungarian = array(

	'item:object:reported_content' => 'Jelentett tartalmak',
	'admin:administer_utilities:reportedcontent' => 'Jelentett tartalom',
	'reportedcontent' => 'Jelentett tartalom',
	'reportedcontent:this' => 'Sértő tartalom jelentése',
	'reportedcontent:this:tooltip' => 'Oldal jelentése a rendszergazdának',
	'reportedcontent:none' => 'Nincs jelentett tartalom',
	'reportedcontent:report' => 'Jelentem a rendszergazdának',
	'reportedcontent:title' => 'Megnevezés',
	'reportedcontent:deleted' => 'Jelentés sikeresen törölve',
	'reportedcontent:notdeleted' => 'Jelentés törlése sikertelen',
	'reportedcontent:delete' => 'Jelentés törlése',
	'reportedcontent:areyousure' => 'Biztos hogy törli?',
	'reportedcontent:archive' => 'Jelentés archiválása',
	'reportedcontent:archived' => 'A jelentés sikeresen archiválva',
	'reportedcontent:visit' => 'Ugrás a tartalomra',
	'reportedcontent:by' => 'Beküldte',
	'reportedcontent:objecttitle' => 'Elem',
	'reportedcontent:objecturl' => 'URL',
	'reportedcontent:reason' => 'Indoklás',
	'reportedcontent:description' => 'Miért akarja ezt jelenteni?',
	'reportedcontent:address' => 'Webcím',
	'reportedcontent:success' => 'Jelentés sikeresen elküldve',
	'reportedcontent:failing' => 'Jelentés elküldése sikertelen',
	'reportedcontent:report' => 'Jelentés',
	'reportedcontent:moreinfo' => 'Bővebben...',
	'reportedcontent:instructions' => 'A jelentést a weboldal rendszergazdája fogja felülvizsgálni.',
	'reportedcontent:numbertodisplay' => 'Megjelenítendő jelentések száma',
	'reportedcontent:widget:description' => 'Jelentett tartalom megtekintése',
	'reportedcontent:user' => 'Sértő felhasználó jelentése',

	'reportedcontent:failed' => 'Tartalom jelentése sikertelen.',
	'reportedcontent:notarchived' => 'Jelentés archiválása sikertelen',	
);

add_translation("hu",$hungarian);

?>
