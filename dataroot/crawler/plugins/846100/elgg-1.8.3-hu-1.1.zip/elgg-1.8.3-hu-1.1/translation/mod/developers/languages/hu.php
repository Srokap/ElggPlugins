<?php
/**
 * Elgg developer tools Hungarian language file.
 *
 */

$hungarian = array(
	// menu
	'admin:develop_tools' => 'Eszközök',
	'admin:develop_tools:preview' => 'Dizájn sandbox',
	'admin:develop_tools:inspect' => 'Vizsgálat',
	'admin:develop_tools:unit_tests' => 'Egység tesztek',
	'admin:developers' => 'Fejlesztés',
	'admin:developers:settings' => 'Beállítások',

	// settings
	'elgg_dev_tools:settings:explanation' => 'Itt olyan beállításokat találhat, melyek jól jöhetnek a fejlesztés és a hibakeresés során. Néhány itteni beállítás más adminisztréciós oldalakról is elérhető.',
	'developers:label:simple_cache' => 'Egyszerű gyorsítótár használata',
	'developers:help:simple_cache' => 'Kapcsolja ki a fájlok gyorítótárát a fejlesztés során. Ha nem teszi, a nézeteken végzett változtatások - ideértve a CSS fájlokon végzett módosításokat is - nem jelennek meg.',
	'developers:label:view_path_cache' => 'Nézetek útvonal-gyorsítótárának használata',
	'developers:help:view_path_cache' => 'Kapcsolja ki a fejlesztés során. Ha nem teszi, a bővítmények új nézetei nem kerülnek regisztrálásra.',
	'developers:label:debug_level' => "Nyomkövetési szint",
	'developers:help:debug_level' => "A naplózott információ mennyiségét szabályozza. További információért lásd: elgg_log()",
	'developers:label:display_errors' => 'Végzetes PHP hibák megjelenítése',
	'developers:help:display_errors' => "Alapértelmezés szerint a rendszer .htaccess fájlja megakadályozza a végzetes hibák megjelenítését.",
	'developers:label:screen_log' => "Naplózás a képernyőre",
	'developers:help:screen_log' => "Megjeleníti az elgg_log() és az elgg_dump() kimenetét a weboldalon.",
	'developers:label:show_strings' => "Nyers fordítási szövegek megjelenítése",
	'developers:help:show_strings' => "Megjeleníti az elgg_echo() parancs által használt szövegeket.",
	'developers:label:wrap_views' => "Nézetek megjelölése",
	'developers:help:wrap_views' => "Körbejelöli a legtöbb nézetet HTML megjegyzésekkel. Ez olyankor hasznos, amikor egy nézet által létrehozott HTML kódrészletet keres.",
	'developers:label:log_events' => "Események és bővítménykampók naplózása",
	'developers:help:log_events' => "Kiírja az eseményeket és a bővítmények kampóit a naplóba. Vigyázat, oldalanként ezekből számottevő mennyiségű lehet!",

	'developers:debug:off' => 'Kikapcsolva',
	'developers:debug:error' => 'Hibák',
	'developers:debug:warning' => 'Figyelmeztetések',
	'developers:debug:notice' => 'Értesítések',
	
	// inspection
	'developers:inspect:help' => 'Az Elgg keretrendszer beállításainak kivizsgálása.',

	// event logging
	'developers:event_log_msg' => "%s: '%s, %s' ebben: %s",

	// theme preview
	'theme_preview:general' => 'Bemutatkozás',
	'theme_preview:breakout' => 'Teljes oldalra nyitás',
	'theme_preview:buttons' => 'Nyomógombok',
	'theme_preview:components' => 'Összetevők',
	'theme_preview:forms' => 'Űrapok',
	'theme_preview:grid' => 'Elrendezés',
	'theme_preview:icons' => 'Ikonok',
	'theme_preview:modules' => 'Modulok',
	'theme_preview:navigation' => 'Navigáció',
	'theme_preview:typography' => 'Tipográfia',

	// unit tests
	'developers:unit_tests:description' => 'A rendszer egység-, és integrációs teszteket is végrehajthat a központi osztályok és funkciók ellenőrzésére.',
	'developers:unit_tests:warning' => 'Vigyázat, ne futassa ezeket a teszteket éles weboldalon! Tönkretehetik az adatbázisát.',
	'developers:unit_tests:run' => 'Futtatás',

	// status messages
	'developers:settings:success' => 'Beállítások sikeresen mentve',
);

add_translation("hu",$hungarian);

?>
