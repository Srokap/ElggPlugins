<?php
/**
 * Blog Hungarian language file.
 *
 */

$hungarian = array(
	'blog' => 'Cikkek',
	'blog:blogs' => 'Cikkek',
	'blog:revisions' => 'Változatok',
	'blog:archives' => 'Archívum',
	'blog:blog' => 'Cikk',
	'item:object:blog' => 'Cikkek',

	'blog:title:user_blogs' => '%s cikkei',
	'blog:title:all_blogs' => 'Minden cikk',
	'blog:title:friends' => 'Ismerősök cikkei',

	'blog:group' => 'Csoport cikkek',
	'blog:enableblog' => 'Csoport cikkek engedélyezése',
	'blog:write' => 'Cikk írása',

	// Editing
	'blog:add' => 'Cikk írása',
	'blog:edit' => 'Cikk szerkesztése',
	'blog:excerpt' => 'Kivonat',
	'blog:body' => 'Törzs',
	'blog:save_status' => 'Utolsó mentés: ',
	'blog:never' => 'Soha',

	// Statuses
	'blog:status' => 'Állapot',
	'blog:status:draft' => 'Piszkozat',
	'blog:status:published' => 'Publikált',
	'blog:status:unsaved_draft' => 'Mentetlen piszkozat',

	'blog:revision' => 'Változat',
	'blog:auto_saved_revision' => 'Automatikusan mentett változat',

	// messages
	'blog:message:saved' => 'Cikk sikeresen elmentve.',
	'blog:error:cannot_save' => 'Cikk mentése sikertelen.',
	'blog:error:cannot_write_to_container' => 'Nincs jogosultsága a csoportba menteni a cikket.',
	'blog:error:post_not_found' => 'Ezt a cikket eltávolították, hibás, vagy nincs jogosultsága megtekinteni.',
	'blog:messages:warning:draft' => 'Még nem mentette el a piszkozatot!',
	'blog:edit_revision_notice' => '(Régi változat)',
	'blog:message:deleted_post' => 'Cikk sikeresen törölve.',
	'blog:error:cannot_delete_post' => 'Cikk mentése sikertelen.',
	'blog:none' => 'Nincsenek cikkek',
	'blog:error:missing:title' => 'Kérem adja meg a cikk címét!',
	'blog:error:missing:description' => 'Kérem töltse ki a törzs részt!',
	'blog:error:cannot_edit_post' => 'Ez a cikk nem létezik vagy nincs jogosultsága szerkeszteni.',
	'blog:error:revision_not_found' => 'Nem található ez a változat.',

	// river
	'river:create:object:blog' => '%s írt egy cikket: %s',
	'river:comment:object:blog' => '%s hozzászólt ehhez a cikkhez: %s',

	// notifications
	'blog:newpost' => 'Egy új cikk',

	// widget
	'blog:widget:description' => 'A legfrisebb cikkek megjelenítése',
	'blog:moreblogs' => 'További cikkek',
	'blog:numbertodisplay' => 'Megjelenítendő cikkek száma',
	'blog:noblogs' => 'Nincsenek cikkek'
);

add_translation("hu",$hungarian);

?>
