<?php
/**
* Elgg send a message action page
* 
* @package ElggMessages
*/

$hungarian = array(
	/**
	* Menu items and titles
	*/

	'messages' => "Üzenetek",
	'messages:unreadcount' => "%s olvasatlan",
	'messages:back' => "vissza az üzenetekhez",
	'messages:user' => "%s bejövő üzenetei",
	'messages:posttitle' => "%s üzenetei: %s",
	'messages:inbox' => "Bejövő üzenetek",
	'messages:send' => "Küldés",
	'messages:sent' => "Elküldött üzenetek",
	'messages:message' => "Üzenet",
	'messages:title' => "Tárgy",
	'messages:to' => "Címzett",
	'messages:from' => "Feladó",
	'messages:fly' => "Elküldés",
	'messages:replying' => "Válasz erre:",
	'messages:inbox' => "Bejövő üzenetek",
	'messages:sendmessage' => "Üzenet elküldése",
	'messages:compose' => "Üzenet írása",
	'messages:add' => "Üzenet írása",
	'messages:sentmessages' => "Elküldött üzenetek",
	'messages:recent' => "Legutóbbi üzenetek",
	'messages:original' => "Eredeti üzenet",
	'messages:yours' => "Az Ön üzenete",
	'messages:answer' => "Válasz",
	'messages:toggle' => 'Mindegyik bejelölése',
	'messages:markread' => 'Megjelölés olvasottként',
	'messages:recipient' => 'Válasszon recipient&hellip;',
	'messages:to_user' => 'Címzett: %s',

	'messages:new' => 'Új üzenet',

	'notification:method:site' => 'Honlap üzenet',

	'messages:error' => 'Üzenet küldése sikertelen. Próbálja újra!',

	'item:object:messages' => 'Üzenetek',

	/**
	* Status messages
	*/

	'messages:posted' => "Üzenet sikeresen elküldve.",
	'messages:success:delete:single' => 'Üzenet sikeresen törölve',
	'messages:success:delete' => 'Kijelölt üzenetek sikeresen törölve',
	'messages:success:read' => 'Üzenetek olvasottnak jelölve',
	'messages:error:messages_not_selected' => 'Nincs kiválasztott üzenet',
	'messages:error:delete:single' => 'Üzenet törlése sikertelen',

	/**
	* Email messages
	*/

	'messages:email:subject' => 'Új üzenete érkezett!',
	'messages:email:body' => "%s üzenetet küldött Önnek. Az üzenet szövege:


	%s


	Az üzenetei megtekintéséhez kattintson az alábbi hivatkozásra:

	%s

	Ha válaszoni szeretne %s üzenetére, kattinson ide:

	%s

	Kérem, ne válaszoljon erre az e-mailre.",

	/**
	* Error messages
	*/

	'messages:blank' => "Az üzenet elküldéséhez meg kell adnia az üzenet szövegét.",
	'messages:notfound' => "A kért üzenet nem található.",
	'messages:notdeleted' => "Üzenet törlése sikertelen.",
	'messages:nopermission' => "Nincs jogosultsága az üzenet módosítására.",
	'messages:nomessages' => "Nincsenek üzenetek.",
	'messages:user:nonexist' => "Az átvevő nem található a felhasználók között.",
	'messages:user:blank' => "Nem választott ki címzettet.",

	'messages:deleted_sender' => 'Törölt felhasználó',
	
);

add_translation("hu",$hungarian);

?>
