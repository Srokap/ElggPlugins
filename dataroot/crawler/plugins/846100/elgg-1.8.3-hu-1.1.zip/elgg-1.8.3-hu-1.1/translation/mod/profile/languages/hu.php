<?php
/**
 * Elgg profile plugin language pack
 */

$hungarian = array(
	'profile' => 'Adatlap',
	'profile:notfound' => 'A keresett adatlap nem található.',
	
);

add_translation("hu",$hungarian);

?>
