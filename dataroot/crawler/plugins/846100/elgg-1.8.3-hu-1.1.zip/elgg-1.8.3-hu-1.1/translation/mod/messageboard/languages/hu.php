<?php

$hungarian = array(

	/**
	 * Menu items and titles
	 */

	'messageboard:board' => "Vendégkönyv",
	'messageboard:messageboard' => "vendégkönyv",
	'messageboard:viewall' => "Összes megtekintése",
	'messageboard:postit' => "Elküldés",
	'messageboard:history:title' => "Előzmények",
	'messageboard:none' => "Nincsenek üzenetek",
	'messageboard:num_display' => "Megjelenítendő üzenetek száma",
	'messageboard:desc' => "Ez egy vendégkönyv, amit kihelyezhet az adatlapjára, és a látogatók üzeneteket hagyhatnak rajta.",

	'messageboard:user' => "%s vendégkönyve",

	'messageboard:replyon' => 'válasz erre',
	'messageboard:history' => "előzmények",

	'messageboard:owner' => '%s vendégkönyve',
	'messageboard:owner_history' => '%s üzenetet írt %s vendégkönyvébe',

	/**
	 * Message board widget river
	 */
	'river:messageboard:user:default' => "%s üzenetet írt %s vendégkönyvébe",

	/**
	 * Status messages
	 */

	'messageboard:posted' => "Bejegyzés sikeresen elmentve.",
	'messageboard:deleted' => "Bejegyzés sikeresen törölve.",

	/**
	 * Email messages
	 */

	'messageboard:email:subject' => 'Új üzenet érkezett a vendégkönyvébe!',
	'messageboard:email:body' => "%s új üzenetet írt a vendégkönyvébe. Az üzenet szövege:


%s


A vendégkönyv megjelenítéséhez kattintson az alábbi hivatkozásra:

	%s

%s adatlapjának a megtekintéséhez pedig kattintson ide:

	%s

Kérem, ne válaszoljon erre az e-mailre.",

	/**
	 * Error messages
	 */

	'messageboard:blank' => "Az üzenet elküldéséhez meg kell adnia az üzenet szövegét.",
	'messageboard:notfound' => "A kért üzenet nem található.",
	'messageboard:notdeleted' => "Üzenet törlése sikertelen.",
	'messageboard:somethingwentwrong' => "Probléma merült fel a bejegyzés mentése során. Biztos, hogy megadta az üzenet szövegét?",

	'messageboard:failure' => "Ismeretlen hiba történt az üzenet mentése során. Próbálja újra!",
	
);

add_translation("hu",$hungarian);

?>
