<?php
/**
 * Members Hungarian language file
 */

$hungarian = array(
	'members:label:newest' => 'Legújabb',
	'members:label:popular' => 'Népszerű',
	'members:label:online' => 'Online',
	'members:searchname' => 'Keresés név alapján',
	'members:searchtag' => 'Keresés címke alapján',
	'members:title:searchname' => 'Felhasználók ezzel a névvel: %s',
	'members:title:searchtag' => 'Felhasználók ezzel a címkével: %s',
);

add_translation("hu",$hungarian);

?>
