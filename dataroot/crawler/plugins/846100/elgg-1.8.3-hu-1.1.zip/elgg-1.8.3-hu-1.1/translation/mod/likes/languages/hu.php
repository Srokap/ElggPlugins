<?php
/**
 * Likes Hungarian language file
 */

$hungarian = array(
	'likes:this' => 'kedvelte ezt',
	'likes:deleted' => 'Megjelölés sikeresen törölve',
	'likes:see' => 'Kinek tetszik?',
	'likes:remove' => 'Nem tetszik',
	'likes:notdeleted' => 'Megjelölés törlése sikertelen',
	'likes:likes' => 'Megjelölés sikeresen hozzáadva',
	'likes:failure' => 'Megjelölés hozzáadása sikertelen',
	'likes:alreadyliked' => 'Már be van jelölve',
	'likes:notfound' => 'Az elem nem található',
	'likes:likethis' => 'Tetszik',
	'likes:userlikedthis' => '%s embernek tetszik',
	'likes:userslikedthis' => '%s embernek tetszik',
	'likes:river:annotate' => 'kedveli',

	'river:likes' => 'kedveli ezt: %s %s',

	// notifications. yikes.
	'likes:notifications:subject' => '%s kedveli ezt: "%s"',
	'likes:notifications:body' =>
'Kedves %1$s!

%2$s kedveli ezt: "%3$s"

Az eredeti tartalom megtekintéséhez kattintson az alábbi hivatkozásra:

%5$s

vagy tekintse meg %2$s adatlapját:

%6$s

Üdvözlettel,
%4$s
',
	
);

add_translation("hu",$hungarian);

?>
