<?php
/**
 * User dashboard languages
 */

$hungarian = array(
	'dashboard:widget:group:title' => 'Csoport hírfolyam',
	'dashboard:widget:group:desc' => 'Egy csoport tevékenységének figyelemmel követése',
	'dashboard:widget:group:select' => 'Kiválasztott csoport',
	'dashboard:widget:group:noactivity' => 'Nincsenek hírek',
	'dashboard:widget:group:noselect' => 'Határozza meg a kívánt csoportot a modul beállításainál',
);

add_translation("hu",$hungarian);

?>
