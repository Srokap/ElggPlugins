<?php
/**
 * Bookmarks Hungarian language file
 */

$hungarian = array(

	/**
	 * Menu items and titles
	 */
	'bookmarks' => "Könyvjelzők",
	'bookmarks:add' => "Könyvjelző hozzáadása",
	'bookmarks:edit' => "Könyvjelző szerkesztése",
	'bookmarks:owner' => "%s könyvjelzői",
	'bookmarks:friends' => "Ismerősök könyvjelzői",
	'bookmarks:everyone' => "Minden könyvjelző",
	'bookmarks:this' => "Oldal hozzáadása a könyvjelzőkhöz",
	'bookmarks:this:group' => "Könyvjezlő hozzáadása a(z) %s csoporthoz",
	'bookmarks:bookmarklet' => "Könyvjelzőmentő",
	'bookmarks:bookmarklet:group' => "Könyvjelzőmentő",
	'bookmarks:inbox' => "Bejövő könyvjelzők",
	'bookmarks:morebookmarks' => "További könyjelzők",
	'bookmarks:more' => "Tovább",
	'bookmarks:with' => "Megosztás",
	'bookmarks:new' => "Egy új könyvjelző",
	'bookmarks:via' => "hozzászólt ehhez:",
	'bookmarks:address' => "Könyvjelző webcíme",
	'bookmarks:none' => 'Nincsenek könyvjelzők',

	'bookmarks:delete:confirm' => "Biztosan törölni akarja?",

	'bookmarks:numbertodisplay' => 'Megjelenítendő könyvjelzők száma',

	'bookmarks:shared' => "Megosztott könyvjelzők",
	'bookmarks:visit' => "Oldal megtekintése",
	'bookmarks:recent' => "Legfrissebb könyvjelzők",

	'river:create:object:bookmarks' => '%s hozzáadta a könyvjezőkhöz: %s',
	'river:comment:object:bookmarks' => '%s hozzászólt ehhez a könyvjelzőhöz: %s',
	'bookmarks:river:annotate' => 'egy hozzászólást ehhez a könyvjelzőhöz',
	'bookmarks:river:item' => 'egy elem',

	'item:object:bookmarks' => 'Könyvjelzők',

	'bookmarks:group' => 'Csoport könyvjelzők',
	'bookmarks:enablebookmarks' => 'Csoport könyvjelzők engedélyezése',
	'bookmarks:nogroup' => 'Nincsenek könyjelzők',
	'bookmarks:more' => 'További könyvjelzők',

	'bookmarks:no_title' => 'Nincs cím',

	/**
	 * Widget and bookmarklet
	 */
	'bookmarks:widget:description' => "A legfrissebb könyvjelzők megjelenítése.",

	'bookmarks:bookmarklet:description' =>
			"A könyvjelzőmentő segítségével bármilyen oldalt megoszthat amit az interneten böngészés közben talál. Felveheti a saját könyvjelzői közé, vagy akár meg is oszthatja az ismerőseivel. A használatához egyszerűen húzza ki az alábbi beépülő emblémát a böngésző könyvjelzősávjába:",

	'bookmarks:bookmarklet:descriptionie' =>
			"Ha Internet Explorert használ, kattintson a jobb egérgombbal a beépülő emblémára, és válassza ki a 'Hozzáadás a kedvencekhez' opciót, majd adja a linkekhez.",

	'bookmarks:bookmarklet:description:conclusion' =>
			"Ezután bármilyen weboldalt elmenthet ha rákattint a kihelyezett emblémára.",

	/**
	 * Status messages
	 */

	'bookmarks:save:success' => "Oldal elmentve a könyvjezők közé.",
	'bookmarks:delete:success' => "Könyvjelző törölve.",

	/**
	 * Error messages
	 */

	'bookmarks:save:failed' => "A könyvjelző mentése sikertelen. Adja meg a könyvjelző nevét és a webcímet, azután próbálja újra.",
	'bookmarks:save:invalid' => "A könyvjelző mentése sikertelen mert a megadott webcím érvénytelen.",
	'bookmarks:delete:failed' => "A könyvjelző törlése sikertelen. Kérem próbálja újra.",
);

add_translation("hu",$hungarian);

?>
