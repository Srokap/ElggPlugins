<?php
/**
 * An english language definition file
 */

$hungarian = array(
	'twitter_api' => 'Twitter Szolgáltatás',

	'twitter_api:requires_oauth' => 'A Twitter Szolgáltatáshoz engedélyezni kell az OAuth Könytárak bővítményt.',

	'twitter_api:consumer_key' => 'Fogyasztói kulcs',
	'twitter_api:consumer_secret' => 'Fogyasztói titkok kulcs',

	'twitter_api:settings:instructions' => 'Szerezzen be egy fogysztói kulcsot és egy titkos kulcsot a <a href="https://dev.twitter.com/apps/new" target="_blank">Twitter</a> weboldaláról. Válassza az új alkalmazást, majd állítsa az alaklmazás típusát "Böngésző"-re, a hozzáférés típusát pedig "Olvasás & Írás"-ra. A visszahívási URL a %stwitter_api/authorize',

	'twitter_api:usersettings:description' => "%s fiók csatlakoztatása a Twitter fiókjához.",
	'twitter_api:usersettings:request' => "Először <a href=\"%s\">engedélyezze</a> %s számára hogy hozzáférjen a Twitter fiókjához.",
	'twitter_api:usersettings:cannot_revoke' => "Nem választhatja le a fiókját a Twitter fiókjáról mert nem adta meg az e-mail címét vagy a jelszavát. <a href=\"%s\">Hiányzó adatok megadása</a>.",
	'twitter_api:authorize:error' => 'Twitter hozzáférés biztosítása sikertelen.',
	'twitter_api:authorize:success' => 'Twitter hozzáférés biztosítva.',

	'twitter_api:usersettings:authorized' => "%s mostantól hozzáférhet a Twitter fiókjához: @%s.",
	'twitter_api:usersettings:revoke' => 'Kattintson <a href="%s">ide</a> a visszavonáshoz.',
	'twitter_api:usersettings:site_not_configured' => 'A rendszergazdának be kell állítania a Twitter modult.',

	'twitter_api:revoke:success' => 'Twitter hozzáférés sikeresen visszavonva.',

	'twitter_api:login' => 'Engedélyezi a jelenlegi felhasználóknak, akik már csatlakoztatták a Twitter fiókjukat, hogy a Twitterrel léphessenek be?',
	'twitter_api:new_users' => 'Engedélyezi az új felhasználók Twitter fiókkal való regisztrációját, még akkor is ha a regisztráció le van tiltva?',
	'twitter_api:login:success' => 'Sikeresen bejelentkezett.',
	'twitter_api:login:error' => 'Sikertelen bejelentkezés a Twitter fiókkal.',
	'twitter_api:login:email' => "%s fiókjához egy érvényes e-mail címet kell megadnia.",

	'twitter_api:invalid_page' => 'Érvénytelen oldal',

	'twitter_api:deprecated_callback_url' => 'A visszahívási URL megváltozott a Twitter API-ban erre: %s. Szóljon a rendszergazdának hogy cserélje ki.',

	'twitter_api:interstitial:settings' => 'Beállításaok',
	'twitter_api:interstitial:description' => '%s már csak néhány lépés! Szükségünk lenne az alábbi részletekere a folytatáshoz. Nem kötelező a kitöltésük, de jól jöhet, ha a Twitter éppen nem elérhető, vagy ha úgy dönt, hogy leválasztja ezt a fiókot a Twitter fiókjáról.',

	'twitter_api:interstitial:username' => 'Ez az Ön felhasználóneve. Nem lehet megváltoztatni. Ha megad egy jelszót, akkor a felhasználónevével, vagy akár az e-mail címével is be tud majd lépni.',

	'twitter_api:interstitial:name' => 'Ezt a nevet fogják más felhasználók látni.',

	'twitter_api:interstitial:email' => 'Ez az Ön e-mail címe. A felhasználók nem láthatják.',

	'twitter_api:interstitial:password' => 'Egy jelszó, amivel akkor is beléphet ha a Twitter nem elérhető, vagy ha szétválasztja a fiókokat egymástól.',
	'twitter_api:interstitial:password2' => 'Ugyanaz a jelszó, még egyszer.',

	'twitter_api:interstitial:no_thanks' => 'Nem, köszönöm',

	'twitter_api:interstitial:no_display_name' => 'Adjon meg egy megjelenítendő nevet.',
	'twitter_api:interstitial:invalid_email' => 'Adjon meg egy érvényes e-mail címet, vagy hagyja üresen.',
	'twitter_api:interstitial:existing_email' => 'Már regisztráltak ezzel az e-mail címmel a honlapra.',
	'twitter_api:interstitial:password_mismatch' => 'A megadott jelszavak nem egyeznek.',
	'twitter_api:interstitial:cannot_save' => 'Fiókadatok mentése sikertelen.',
	'twitter_api:interstitial:saved' => 'Fiókadatok sikeresen mentve!',
);

add_translation("hu",$hungarian);

?>
