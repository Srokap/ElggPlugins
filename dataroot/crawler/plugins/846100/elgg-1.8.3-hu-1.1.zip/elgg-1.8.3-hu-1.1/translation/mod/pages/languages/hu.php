<?php
/**
 * Pages languages
 *
 * @package ElggPages
 */

$hungarian = array(

	/**
	 * Menu items and titles
	 */

	'pages' => "Oldalak",
	'pages:owner' => "%s oldalai",
	'pages:friends' => "Ismerősök oldalai",
	'pages:all' => "Minden oldal",
	'pages:add' => "Oldal hozzáadása",

	'pages:group' => "Csoport oldalak",
	'groups:enablepages' => 'Csoport oldalak engedélyezése',

	'pages:edit' => "Oldal szerkesztése",
	'pages:delete' => "Oldal törlése",
	'pages:history' => "Előzmények",
	'pages:view' => "Oldal megtekintése",
	'pages:revision' => "Változatok",

	'pages:navigation' => "Navigáció",
	'pages:via' => "hozzászólt ehhez:",
	'item:object:page_top' => 'Index oldalak',
	'item:object:page' => 'Oldalak',
	'pages:nogroup' => 'Nincsenek oldalak',
	'pages:more' => 'További oldalak',
	'pages:none' => 'Nincsenek oldalak',

	/**
	* River
	**/

	'river:create:object:page' => '%s létrehozott egy oldalt: %s',
	'river:create:object:page_top' => '%s létrehozott egy oldalt: %s',
	'river:update:object:page' => '%s frissítette ezt az oldalt: %s',
	'river:update:object:page_top' => '%s frissítette ezt az oldalt: %s',
	'river:comment:object:page' => '%s hozzászólt ehhez az oldalhoz: %s',
	'river:comment:object:page_top' => '%s hozzászólt ehhez az oldalhoz: %s',

	/**
	 * Form fields
	 */

	'pages:title' => 'Oldal cím',
	'pages:description' => 'Oldal szöveg',
	'pages:tags' => 'Címkék',
	'pages:access_id' => 'Olvasási jogosultságok',
	'pages:write_access_id' => 'Írási jogosultságok',

	/**
	 * Status and error messages
	 */
	'pages:noaccess' => 'Nincs hozzáférése az oldalhoz',
	'pages:cantedit' => 'Nem szerkesztheti ezt az oldalt',
	'pages:saved' => 'Oldal sikeresen mentve',
	'pages:notsaved' => 'Oldal mentése sikertelen',
	'pages:error:no_title' => 'Adja meg az oldal címét!',
	'pages:delete:success' => 'Az oldal sikeresen törölve.',
	'pages:delete:failure' => 'Az oldal törlése sikertelen.',

	/**
	 * Page
	 */
	'pages:strapline' => 'Utoljára frissítve %s, %s által',

	/**
	 * History
	 */
	'pages:revision:subtitle' => 'Változat készült %s, %s által',

	/**
	 * Widget
	 **/

	'pages:num' => 'Megjelenítendő oldalak száma',
	'pages:widget:description' => "Az Ön oldalainak listája.",

	/**
	 * Submenu items
	 */
	'pages:label:view' => "Oldal megtekintése",
	'pages:label:edit' => "Oldal szerkesztése",
	'pages:label:history' => "Előzmények",

	/**
	 * Sidebar items
	 */
	'pages:sidebar:this' => "Ez az oldal",
	'pages:sidebar:children' => "Aloldalak",
	'pages:sidebar:parent' => "Szülő oldal",

	'pages:newchild' => "Aloldal hozzáadása",
	'pages:backtoparent' => "Vissza ehhez: '%s'",
);

add_translation("hu",$hungarian);

?>
