<?php
/**
 * Email user validation plugin language pack.
 *
 * @package Elgg.Core.Plugin
 * @subpackage ElggUserValidationByEmail
 */

$hungarian = array(
	'admin:users:unvalidated' => 'Megerősítésre várók',
	
	'email:validate:subject' => "%s e-mail címének megerősítése, %s fiók aktiválása",
	'email:validate:body' => "Kedves %s,

%s regisztrációja utolsó lépéseként kérjük erősítse meg e-mail címét!

Ehhez kattinson az alábbi hivatkozásra:

%s

Ha a hivatkozás nem reagál a kattintásra, másolja be a böngészőjébe manuálisan.

%s
%s
",
	'email:confirm:success' => "E-mail cím sikeresen megerősítve!",
	'email:confirm:fail' => "E-mail megerősítése sikertelen.",

	'uservalidationbyemail:registerok' => "A fiók aktiválásához kövesse az instrukciókat az elküldött e-mailben.",
	'uservalidationbyemail:login:fail' => "A fiókja még nincs aktiválva így a belépés sikertelen. Küldtünk egy újabb megerősítő e-mailt.",

	'uservalidationbyemail:admin:no_unvalidated_users' => 'Nincsenek megerősítésre váró felhasználók.',

	'uservalidationbyemail:admin:unvalidated' => 'Megerősítésre várók',
	'uservalidationbyemail:admin:user_created' => 'Regisztrált %s',
	'uservalidationbyemail:admin:resend_validation' => 'Megerősítő e-mail újraküldése',
	'uservalidationbyemail:admin:validate' => 'Megerősítés',
	'uservalidationbyemail:admin:delete' => 'Törlés',
	'uservalidationbyemail:confirm_validate_user' => 'Megerősíti %st?',
	'uservalidationbyemail:confirm_resend_validation' => 'Újabb megerősítő e-mailt küldése %s számára?',
	'uservalidationbyemail:confirm_delete' => 'Törli %st?',
	'uservalidationbyemail:confirm_validate_checked' => 'Megerősíti a bejelölt felhasználókat?',
	'uservalidationbyemail:confirm_resend_validation_checked' => 'Újabb megerősítő e-maileket küld a bejelölteknek?',
	'uservalidationbyemail:confirm_delete_checked' => 'Törli a bejelölt felhasználókat?',
	'uservalidationbyemail:check_all' => 'Összes',

	'uservalidationbyemail:errors:unknown_users' => 'Ismeretlen felhasználók',
	'uservalidationbyemail:errors:could_not_validate_user' => 'Felhasználó megerősítése sikertelen.',
	'uservalidationbyemail:errors:could_not_validate_users' => 'Bejelölt felhasználók megerősítése sikertelen.',
	'uservalidationbyemail:errors:could_not_delete_user' => 'Felhasználó törlése sikertelen.',
	'uservalidationbyemail:errors:could_not_delete_users' => 'Bejelölt felhasználók törlése sikertelen.',
	'uservalidationbyemail:errors:could_not_resend_validation' => 'Megerősítő e-mail újraküldése sikertelen.',
	'uservalidationbyemail:errors:could_not_resend_validations' => 'Megerősítő e-mailek újraküldése a bejelölteknek sikertelen.',

	'uservalidationbyemail:messages:validated_user' => 'Felhasználó sikeresen megerősítve.',
	'uservalidationbyemail:messages:validated_users' => 'Bejelölt felhasználók sikeresen megerősítve.',
	'uservalidationbyemail:messages:deleted_user' => 'Felhasználó sikeresen törölve.',
	'uservalidationbyemail:messages:deleted_users' => 'Bejelölt felhasználók sikeresen törölve.',
	'uservalidationbyemail:messages:resent_validation' => 'Megerősítő e-mail sikeresen újraküldve.',
	'uservalidationbyemail:messages:resent_validations' => 'Megerősítő e-mailek a bejelölteknek sikeresen újraküldve.',

);

add_translation("hu",$hungarian);

?>
