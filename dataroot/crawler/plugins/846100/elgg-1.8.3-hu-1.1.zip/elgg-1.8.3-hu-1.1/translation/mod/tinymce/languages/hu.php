<?php
/**
 * TinyMCE language pack.
 *
 * @package ElggTinyMCE
 */

$hungarian = array(
	'tinymce:remove' => "Szövegszerkesztő elrejtése",
	'tinymce:add' => "Szövegszerkesztő megjelenítése",
	'tinymce:word_count' => 'Szavak száma: ',
);

add_translation("hu",$hungarian);

?>
