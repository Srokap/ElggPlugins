<?php
/**
* people_from_the_neighborhood
*
* @author emdagon
* @link http://community.elgg.org/pg/profile/emdagon
* @copyright (c) Condiminds 2011
* @link http://www.condiminds.com/
* @license GNU General Public License (GPL) version 2
*/

function people_from_the_neighborhood_init() {

	global $CONFIG;

	extend_view('css', 'people_from_the_neighborhood/css');

	register_page_handler('pftn', 'people_from_the_neighborhood_page_handler');

	add_menu(elgg_echo('pftn:meet:new:people'), "{$CONFIG->wwwroot}pg/pftn/");

	add_widget_type('pftn_widget', elgg_echo('pftn:people:you:may:know'), elgg_echo('pftn:widget:description'), 'dashboard');

}

/*
 * People usort callback
 */
function people_from_the_neighborhood_sorter($a, $b){
	if ($a['priority'] == $b['priority']) {
		return 0;
	}
	return ($a['priority'] < $b['priority']) ? 1 : -1;
}

/**
 *
 * Returns array of people containing entity, mutuals (friends), groups (shared) and priority
 * @param Int $guid
 * @param Int $friends_limit
 * @param Int $groups_limit
 * @return Array
 */
function people_from_the_neighborhood_get_people($guid, $friends_of_friends_limit = 3, $groups_members_limit = 3) {

	global $CONFIG;

	// retrieve all users friends,
/* Facyla : Elgg >= 1.7
	$options = array(
		'type' => 'user',
		'relationship' => 'friend',
		'relationship_guid' => $guid,
		'wheres' => "u.banned = 'no'",
		'joins' => "INNER JOIN {$CONFIG->dbprefix}users_entity u USING (guid)",
		'order_by' => 'u.last_action DESC',
	);
	$count = elgg_get_entities_from_relationship(array_merge(array('count' => TRUE), $options));
	$friends = elgg_get_entities_from_relationship(array_merge(array('limit' => $count), $options));
*/
  // Facyla 20110201
	$count = get_entities_from_relationship('friend', $guid, false, 'user', '', 0, 'time_updated DESC', 10, 0, true, -1);
	$friends = get_entities_from_relationship('friend', $guid, false, 'user', '', 0, 'time_updated DESC', $count, 0, false, -1);

	// generate a guids array
	$in = array($guid);
	foreach ($friends as $friend) {
		$in[] = $friend->guid;
	}

	// Facyla : easier as an array for Elgg < 1.7
	$in_a = $in;
	$in = implode(',', $in);

	$people = array();

	/* search by friends */
	if ($friends_of_friends_limit > 0) {
		foreach ($friends as $friend) {
			// retrieve 3 friends of each friend (discarding the users friends)
/* Facyla : Elgg >= 1.7
			$fof = elgg_get_entities_from_relationship(array(
				'type' => 'user',
				'relationship' => 'friend',
				'relationship_guid' => $friend->guid,
				'wheres' => array(
					"e.guid NOT IN ($in)",
					"u.banned = 'no'"
				),
				'joins' => "INNER JOIN {$CONFIG->dbprefix}users_entity u USING (guid)",
				'order_by' => 'u.last_action DESC',
				'limit' => $friends_of_friends_limit
			));
*/
			// Facyla 20110201
			$fof = get_entities_from_relationship('friend', $friend->guid, false, 'user', '', 0, 'time_updated DESC', $friends_of_friends_limit, 0, false, -1);
			if (is_array($fof) && count($fof) > 0) {
				// populate $people
				foreach ($fof as $f) {
//					if (isset($people[$f->guid])) {
          // Facyla : don't add friends for Elgg < 1.7 (no 'wheres' clause)
          if (!in_array($f->guid, $in_a)) {
            if (isset($people[$f->guid])) {
              // if the current person is present in $people, increase the priority and attach the common friend entity
              $people[$f->guid]['mutuals'][] = $friend;
              ++$people[$f->guid]['priority'];
            } else {
              $people[$f->guid] = array(
                'entity' => $f,
                'mutuals' => array($friend),
                'groups' => array(),
                'priority' => 0
              );
            }
          }
				}
			}
		}
	}
	unset($friends);

	/* search by groups */
	if ($groups_members_limit > 0) {
		// retrieve ($groups_limit) user's groups
/* Facyla : Elgg >= 1.7
		$options = array(
			'type' => 'group',
			'relationship' => 'member',
			'relationship_guid' => $guid,
			'order_by' => 'time_created DESC'
		);
		$count = elgg_get_entities_from_relationship(array_merge(array('count' => TRUE), $options));
		$groups = elgg_get_entities_from_relationship(array_merge(array('limit' => $count), $options));
*/
    // Facyla 20110201
		$count = get_entities_from_relationship('member', $guid, false, 'group', '', 0, 'time_created DESC', 10, 0, true, -1);
		$groups = get_entities_from_relationship('member', $guid, false, 'group', '', 0, 'time_created DESC', $count, 0, false, -1);

		if (is_array($groups) && count($groups) > 0) {
			foreach ($groups as $group) {
				// retrieve 3 members of each group (discarding the users friends)
/* Facyla : Elgg >= 1.7
				$members = elgg_get_entities_from_relationship(array(
					'type' => 'user',
					'relationship' => 'member',
					'relationship_guid' => $group->guid,
					'inverse_relationship' => TRUE,
					'wheres' => array(
						"e.guid NOT IN ($in)",
						"u.banned = 'no'"
					),
					'joins' => "INNER JOIN {$CONFIG->dbprefix}users_entity u USING (guid)",
					'order_by' => 'u.last_action DESC',
					'limit' => $groups_members_limit
				));
*/
        // Facyla 20110201
        $members = get_entities_from_relationship('member', $group->guid, true, 'user', '', 0, 'time_updated DESC', $groups_members_limit, 0, false, -1);
				if (is_array($members) && count($members) > 0) {
					// populate $people
					foreach ($members as $member) {
            // Facyla : don't add friends for Elgg < 1.7 (no 'wheres' clause)
            if (!in_array($member->guid, $in_a)) {
              if (isset($people[$member->guid])) {
                // if the current person is present in $people, increase the priority and attach the common group entity
                $people[$member->guid]['groups'][] = $group;
                ++$people[$member->guid]['priority'];
              } else {
                $people[$member->guid] = array(
                  'entity' => $member,
                  'mutuals' => array(),
                  'groups' => array($group),
                  'priority' => 0
                );
              }
            }
					}
				}
			}
		}
		unset($groups);
	}

	// sort by priority
	usort($people, 'people_from_the_neighborhood_sorter');

	return $people;

}

function people_from_the_neighborhood_page_handler($page) {

	global $CONFIG;

	gatekeeper();

	set_context('pftn');

	$page_owner = get_loggedin_user();
	set_page_owner($page_owner->guid);

	add_submenu_item(elgg_echo('pftn:all'), "{$CONFIG->wwwroot}pg/pftn/");
	add_submenu_item(elgg_echo('pftn:friends:only'), "{$CONFIG->wwwroot}pg/pftn/friends/{$page_owner->username}");
	add_submenu_item(elgg_echo('pftn:groups:only'), "{$CONFIG->wwwroot}pg/pftn/groups/{$page_owner->username}");

	$friends = $groups = 0;
	switch ($page[0]) {
		case 'friends':
			$friends = 3;
			break;
		case 'groups':
			$groups = 3;
			break;
		default:
			$friends = $groups = 3;
	}

	$people = people_from_the_neighborhood_get_people($page_owner->guid, $friends, $groups);

	$body = elgg_view('people_from_the_neighborhood/pftn', array('people' => $people));

	page_draw(elgg_echo('pftn:title'), elgg_view_layout('two_column_left_sidebar', '', $body));

}

register_elgg_event_handler('init', 'system', 'people_from_the_neighborhood_init');
