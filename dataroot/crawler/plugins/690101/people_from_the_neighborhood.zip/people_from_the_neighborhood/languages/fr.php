<?php
$french = array(

	'pftn' => "Suggestions de contacts",
	'pftn:title' => "Contacts potentiels",

	'pftn:meet:new:people' => "Suggestions de contacts",

	'pftn:people:you:may:know' => "Personnes que vous connaissez peut-être",
	'pftn:widget:description' => "Ce widget vous suggère des contacts potentiels et des personnes que vous connaissez peut-être",
	'pftn:see:more' => "Plus de suggestions",
	'pftn:how:many' => "Combien de personnes ?",

	'pftn:all' => "Tous",
	'pftn:friends:only' => "Contacts de mes contacts",
	'pftn:groups:only' => "Membres des mêmes groupes",

	'pftn:is:friend:of' => "Contacts de %s",
	'pftn:mutual:friends' => "%s contacts en commun : %s",

	'pftn:is:member:of' => "Membre de %s",
	'pftn:shared:groups' => "%s groupes en commun : %s",

	'pftn:people:not:found' => "Aucune suggestion de contact",

);

add_translation('fr', $french);
