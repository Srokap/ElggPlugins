<?php

$english = array(

	'pftn:title' => 'People From The Neighborhood',

	'pftn:meet:new:people' => 'Meet new people!',

	'pftn:people:you:may:know' => 'People you may know',
	'pftn:widget:description' => 'This widget suggest you people you may know',
	'pftn:see:more' => 'See more',
	'pftn:how:many' => 'How many people?',

	'pftn:all' => 'All',
	'pftn:friends:only' => 'Friends of my friends',
	'pftn:groups:only' => 'Members of my groups',

	'pftn:is:friend:of' => 'Friend of %s',
	'pftn:mutual:friends' => '%s mutual friends: %s',

	'pftn:is:member:of' => 'Member of %s',
	'pftn:shared:groups' => '%s shared groups: %s',

	'pftn:people:not:found' => 'There are no people to suggest'

);

add_translation('en', $english);