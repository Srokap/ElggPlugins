<div class="pftn_list_title">
	<h2><?php echo elgg_echo('pftn:title'); ?></h2>
</div>
<?php echo elgg_view('people_from_the_neighborhood/people', array('people' => $vars['people'])); ?>