<p>
	<?php echo elgg_echo('pftn:friends:only'); ?>
	<select name="params[look_in_friends]">
		<option value="yes" <?php if ($vars['entity']->look_in_friends == 'yes') echo ' selected="selected"'; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if (($vars['entity']->look_in_friends == 'no')) echo ' selected="selected"'; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<p>
	<?php echo elgg_echo('pftn:groups:only'); ?>
	<select name="params[look_in_groups]">
		<option value="yes" <?php if ($vars['entity']->look_in_groups == 'yes') echo ' selected="selected"'; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if (($vars['entity']->look_in_groups == 'no')) echo ' selected="selected"'; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<p>
	<?php echo elgg_echo('pftn:how:many'); ?>
	<select name="params[num_display]">
		<?php foreach(array(2,3,4,5,6) as $num) {?>
		<option value="<?php echo $num; ?>" <?php if ($vars['entity']->num_display == $num) echo ' selected="selected"'; ?>><?php echo $num ?></option>
		<?php } ?>
	</select>
</p>