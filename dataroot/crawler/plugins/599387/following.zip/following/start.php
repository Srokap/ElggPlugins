<?php
/**
 * Following override plugin
 * @author Cash Costello
 * @license GPL2
 */

// this space intentionally left blank
