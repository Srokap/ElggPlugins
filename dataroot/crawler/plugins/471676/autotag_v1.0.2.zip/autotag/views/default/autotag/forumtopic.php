<?php
	echo elgg_view("autotag/js_form_handler", array("text_fieldname"=>"topicmessage", "tags_fieldname"=>"topictags"));
?>
