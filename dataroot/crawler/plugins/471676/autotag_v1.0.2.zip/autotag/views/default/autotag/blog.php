<?php
	echo elgg_view("autotag/js_form_handler", array("text_fieldname"=>"blogbody", "tags_fieldname"=>"blogtags"));
?>
