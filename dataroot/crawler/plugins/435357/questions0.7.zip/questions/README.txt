------------------------------------------------------------------------------------
*** FEATURES ***

v 0.7 (2010/03/04) - added by Nathan Hardwick nathan@electrosoup.co.uk

* Tidied CSS and changed some icons
* Added Elgg 1.7 Compatibility via additional security

v 0.6 (2009/03/12)

* Plugin settings added. Number of questions and answers per page available to change in admin's page.
* Rate a question as interesting or not.
* Rate an answer as helpful or not.
* Questions & Answers sorting with pagination. REALLY HARD WORK!
  Created time, Owner name, Helpful, Interesting & Number of answers are the new sorting criterias.

v 0.5 (2009/03/02)

* Questions & Answers pagination (10 answers per page).
* New widget for Questions.

v 0.4 (2008/02/26)

* Activity added to the river. (Questions and answers)
* Ability to open/close questions to question owners or admins.
* The question is shown the first time it's answered.

v 0.3 (2009/02/18)

* One answer per question changed for a list of answers.
* Redirections are more comfortable now after actions.
* River is updated when questions and answers are added.
* Direct link to answers in viewanswers' page.
* Codifications improvements.
* Question's menu not shown any more in spotlight when no user is logged in.(Thanks to Greg Marine).

v 0.2 (2009/02/17)

* Edit questions and answers
* Design and content improvements.
* Email notification to question's owner when its answered.

v 0.1 (2009/02/12)

* Create and delete questions (admins and questions' owners only).
* Answer questions.
* View answers.
* Delete answers (admins and questions' owners only).
* Manage which type of users could access and answer the questions.

------------------------------------------------------------------------------------
*** TO DO ***

* Rate Questions (1-5 or interesting or not).
* Rate Answers (1-5 or helpfull or not).
* Design improvements.
* Any suggestion of improvement or bug correction
  that come from mail or the Elgg Community.
  e-mail: juces@df-digital.com
  http://www.df-digital.com

------------------------------------------------------------------------------------
*** INSTALLATION ***

HOW TO INSTALL:
* If installed, remove Question's previous version.
* Copy questions' folder inside mod's folder located in root's elgg installation
* Activate plugin from Tools Administration.

------------------------------------------------------------------------------------