<?php
/**
    model.php, part of Online
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
*/
// define maximum amount of users request cache
define('ONLINE_MAX_USERS_CHECK_COUNT', 100);

// request cache storage
$ONLINE_USERS = array();

// function load active users in cache
function online_load_users($seconds = 600)
{
	global $ONLINE_USERS;
	$ONLINE_USERS = find_active_users($seconds, ONLINE_MAX_USERS_CHECK_COUNT);
	if ( $ONLINE_USERS === FALSE )
	    $ONLINE_USERS = array();
}

/**
 * A function check is user have done something within the last
 * $seconds seconds.
 *
 * @param Entity $user User who will be checked
 * @param int $seconds Number of seconds (default 600 = 10min)
 */
function online_is_active_user($user, $seconds = 600)
{
	global $ONLINE_USERS;
	// if online users exists
	if ( is_array($ONLINE_USERS) )
	{
		// if user online status cached
		if ( in_array($user, $ONLINE_USERS) )
		{
			return true;
		}
		// check is online users more when allowed to store and chack direct in database if so
		if ( count($ONLINE_USERS) == ONLINE_MAX_USERS_CHECK_COUNT )
		    return online_is_active_user_ex($user, $seconds);

	}
	return false;
}

/**
 * A function check directly in database is user have done something within the last
 * $seconds seconds.
 *
 * @param Entity $user User who will be checked
 * @param int $seconds Number of seconds (default 600 = 10min)
 */
function online_is_active_user_ex($user, $seconds = 600)
{
	global $CONFIG;

	$seconds = (int)$seconds;
	$time = time() - $seconds;

	// do not use accessibility check
	//$access = get_access_sql_suffix("e");

	$query = "SELECT distinct u.guid FROM {$CONFIG->dbprefix}users_entity u WHERE u.guid = {$user->guid} AND u.last_action >= {$time}";
	return get_data($query) !== false ? true : false;
}

?>