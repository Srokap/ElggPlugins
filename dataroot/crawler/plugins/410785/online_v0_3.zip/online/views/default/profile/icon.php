<?php

/**
    icon.php, part of Online
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
	 * 
	 * @uses $vars['entity'] The user entity. If none specified, the current user is assumed.
	 * @uses $vars['size'] The size - small, medium or large. If none specified, medium is assumed. 
	 *  
	 */

// This file override standart icon view from profile plugin to allow see online status
	// Get entity
		if (empty($vars['entity']))
			$vars['entity'] = $vars['user'];

		if ($vars['entity'] instanceof ElggUser) {
			
		$name = htmlentities($vars['entity']->name, null, 'UTF-8');
		$username = $vars['entity']->username;
		
		if ($icontime = $vars['entity']->icontime) {
			$icontime = "{$icontime}";
		} else {
			$icontime = "default";
		}
			
	// Get size
		if (!in_array($vars['size'],array('small','medium','large','tiny','master','topbar')))
			$vars['size'] = "medium";
			
	// Get any align and js
		if (!empty($vars['align'])) {
			$align = " align=\"{$vars['align']}\" ";
		} else {
			$align = "";
		}
	// Check is user active|online
	    $online = online_is_active_user($vars['entity']) ? '_online' : '';
	    
	// Override
		if (isset($vars['override']) && $vars['override'] == true) {
			$override = true;
		} else $override = false;
		
		if (!$override) {
		
?>
<div class="usericon">
	<div class="online_status<?php echo $online;?>"></div>
        <div class="avatar_menu_button"><img src="<?php echo $vars['url']; ?>_graphics/spacer.gif" border="0" width="15px" height="15px" /></div>

	<div class="sub_menu">
		<a href="<?php echo $vars['entity']->getURL(); ?>"><h3><?php echo $vars['entity']->name; ?></h3></a>
		<?php
			if (isloggedin()) {
				$actions = elgg_view('profile/menu/actions',$vars);
				if (!empty($actions)) {
					
					echo "<div class=\"item_line\">{$actions}</div>";
					
				}
				if ($vars['entity']->getGUID() == $vars['user']->getGUID()) {
					echo elgg_view('profile/menu/linksownpage',$vars);
				} else {
					echo elgg_view('profile/menu/links',$vars);
				}					
			} else {
				echo elgg_view('profile/menu/links',$vars);
			}
		?>
	</div>	
	<?php
		if ((isadminloggedin()) || (!$vars['entity']->isBanned())) { ?>
                      <a href="<?php echo $vars['entity']->getURL(); ?>" class="icon" >
        <?php   }		
	} 
	
	?><img src="<?php echo $vars['entity']->getIcon($vars['size']); ?>" border="0" <?php echo $align; ?> title="<?php echo htmlentities($vars['entity']->name, ENT_QUOTES, 'UTF-8'); ?>" <?php echo $vars['js']; ?> /><?php

		if (!$override) {
	
	?></a>
</div>

<?php

	}
		}

?>