/**
    README.txt, part of Online
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
    Elgg version: 1.5
    Title: Online_Users
    Intro: Makes addition to avatar to show user status (online).
    Description: adds inscription "online" on avatar. Inscription hides part of avatar.
    Plugin is developed by Web100 Net Technology Center, Ltd. http://web100.com.ua under the assignment of Lorinthe,BV.
    Dependencies: No
    Version: 0.3
    Licence: GPL v.3
 */

The Elgg 1.x online plugin show online status in users icons.

*Activating the visitors plugin*

Simply extract the visitors plugin into the mod directory and
activate it as usual using the Elgg 1.x tool administration.

After activation active members icons will be marked.


