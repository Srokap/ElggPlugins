<?php

// Generado por translationbrowser 

$spanish = array( 
	 'categories'  =>  "Categorías" , 
	 'categories:settings'  =>  "Edita las categorías del sitio" , 
	 'categories:explanation'  =>  "Para establecer algunas categorías globales para el sitio que serán usadas a través de tu sistema, introdúcelas abajo separadas por comas. Serán mostradas por las herramientas compatibles cuando el usuario cree o edite contenido." , 
	 'categories:save:success'  =>  "Las categorías del sitio se han grabado correctamente.",
	 'categories:results' => "Resultados del sitio para la categoría: %s",
	 'categories:on_activate_reminder' => "Las categorías del sitio no se encuentran disponibles hasta que agregue alguna. <a href=\"%s\">A&ntilde;adir categorías ahora.</a>",
); 

add_translation('es', $spanish); 

?>