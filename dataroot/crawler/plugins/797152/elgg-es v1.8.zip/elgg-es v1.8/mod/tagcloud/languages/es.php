<?php
/**
 * Tag cloud English language file
 */

$spanish = array(
	'tagcloud:widget:title' => 'Nube de Tags',
	'tagcloud:widget:description' => 'Nube de Tags',
	'tagcloud:widget:numtags' => 'Cantidad de tags a mostrar',
);

add_translation('es', $spanish);
