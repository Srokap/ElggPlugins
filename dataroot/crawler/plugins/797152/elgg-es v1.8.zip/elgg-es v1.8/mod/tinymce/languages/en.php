<?php
/**
 * TinyMCE language pack.
 *
 * @package ElggTinyMCE
 */

$english = array(
	'tinymce:remove' => "Remove editor",
	'tinymce:add' => "Add editor",
	'tinymce:word_count' => 'Word count: ',
);

add_translation("en", $english);