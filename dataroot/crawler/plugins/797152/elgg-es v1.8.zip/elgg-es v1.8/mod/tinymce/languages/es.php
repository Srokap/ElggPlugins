<?php
/**
 * TinyMCE language pack.
 *
 * @package ElggTinyMCE
 */

$spanish = array(
	'tinymce:remove' => "Quitar editor",
	'tinymce:add' => "Agregar editor",
	'tinymce:word_count' => 'Cantidad de palabras: ',
);

add_translation("es", $spanish);