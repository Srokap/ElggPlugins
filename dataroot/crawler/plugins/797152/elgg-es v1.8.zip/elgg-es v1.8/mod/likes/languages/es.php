<?php
/**
 * Likes Spanish language file
 */

$spanish = array(
	'likes:this' => 'le gusta esto',
	'likes:deleted' => 'Ya no te gusta esto',
	'likes:see' => 'Ver a quienes les gusta esto',
	'likes:remove' => 'Ya no me gusta',
	'likes:notdeleted' => 'Ocurri&oacute; un problema al intentar quitar el me gusta',
	'likes:likes' => 'Ahora te gusta esto',
	'likes:failure' => 'Ocurri&oacute; un problema al agregar el me gusta',
	'likes:alreadyliked' => 'Ya te gusta esto',
	'likes:notfound' => 'No se pudo encontrar el item que te gusta',
	'likes:likethis' => 'Me gusta',
	'likes:userlikedthis' => '%s me gusta',
	'likes:userslikedthis' => '%s me gusta',
	'likes:river:annotate' => 'me gusta',

	'river:likes' => 'me gustan %s %s',

	// notifications. yikes.
	'likes:notifications:subject' => '%s me gusta en tu publicaci&oacute;n "%s"',
	'likes:notifications:body' =>
'Hola %1$s,

a %2$s le gusta tu publicaci&oacute;n "%3$s" en %4$s!

Ver publicaci&oacute;n original aqu&iacute;:

%5$s

o ver el perfil de %2$s aqu&iacute;:

%6$s

Gracias,
%4$s
',
);

add_translation('es', $spanish);
