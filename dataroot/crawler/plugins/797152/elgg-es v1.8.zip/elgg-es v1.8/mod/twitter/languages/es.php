<?php
/**
 * Twitter widget language file
 */

$spanish = array(

	'twitter:title' => 'Twitter',
	'twitter:info' => 'Mostrar tus &uacute;ltimos tweets',
	'twitter:username' => 'Ingrese su nombre de usuario de twitter.',
	'twitter:num' => 'Cantidad de tweets a mostrar.',
	'twitter:visit' => 'ir a mi twitter',
	'twitter:notset' => 'El widget de Twitter no se encuentra listo para funcionar. Para mostrar los &uacute;ltimos tweets, haga click en - editar - y complete sus los datos',
);

add_translation("es", $spanish);
