<?php //ł ?><?php 
	vazco_atomic_theme::activate();
?>