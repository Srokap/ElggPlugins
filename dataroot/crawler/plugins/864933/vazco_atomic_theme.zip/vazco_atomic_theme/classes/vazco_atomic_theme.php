<?php //ł ?><?php
class vazco_atomic_theme{//this  was set automatically, you might need to change it
	
	//method launched on plugin activate, supported since Elgg 1.8
	static public function activate(){
		//content here
	}
	
	//method launched on plugin deactivate, supported since Elgg 1.8
	static public function deactivate(){
		//content here
	}
	
	//methods invoked by actions
	

}
?>