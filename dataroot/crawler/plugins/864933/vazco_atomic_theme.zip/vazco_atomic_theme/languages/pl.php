<?php //ł ?><?php
$polish = array(
	//general
	'vazco_atomohost_series_theme:menu:title'	=> '',



);

add_translation("pl",$polish);
?>