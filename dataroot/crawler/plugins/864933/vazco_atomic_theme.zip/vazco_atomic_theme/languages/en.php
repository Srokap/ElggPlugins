<?php //ł ?><?php
$english = array(
	//general
	'vazco_atomohost_series_theme:menu:title'	=> '',



);

add_translation("en",$english);
?>