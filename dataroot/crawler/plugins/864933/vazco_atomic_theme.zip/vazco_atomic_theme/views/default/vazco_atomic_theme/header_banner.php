<?php
/**
 * Elgg header logo
 */

$site = elgg_get_site_entity();
$site_name = $site->name;
$site_url = elgg_get_site_url();

	
?>

<div class="header-banner">
    
   <h2> Welcome to Your Business</h2>
   <p>
    Yourbusiness.com is a leading virtual corporate business that will help you monetize your work to the most level you could reach.

Lorem ipsum dolor sit amet, consectetur adip, Yourbusiness.com will give you a new way to look at your business and lead it to all new horizons.
      
   </p>

</div>