<?php

/**
 * Elgg acquaintancers index page - called from filter or search
 * 
 * @package ElggMembers (acquaintancers fork)
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Lorea.cc
 * @link https://lorea.cc
 */

require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

gatekeeper();
		
// get filter parameters
$limit = get_input('limit', 10);
$offset = get_input('offset', 0);
$filter = get_input("filter", "newest");

// search options
$tag = get_input('tag');


//search members
$sidebar = elgg_view("members/search");
	    
// get the correct content based on filter/search
switch ($filter) {
	case "pop":
		$filter_content = list_entities_by_relationship_count('friend', true, '', '', 0, 10, false);
	break;
	case "active":
		$filter_content = elgg_view("members/online");
	break;
	// search based on name
	case "search":
		set_context('search');
		$filter_content = list_user_search($tag);
	break;
	// search based on tags
	case "search_tags":
		$filter_content = trigger_plugin_hook('search','',$tag,"");
		$filter_content .= list_entities_from_metadata("", $tag, "user", "", "", 10, false, false);
	break;
	
	case 'friends':
		$entities = ($_SESSION['user']->getFriends("",10,$offset));
		$options =  array(
                'relationship' => "friend",
                'relationship_guid' => $_SESSION['user']->getGUID(),
                'inverse_relationship' => FALSE,
		'count' => TRUE
	        );

		$count = elgg_get_entities_from_relationship($options);

                $filter_content = elgg_view_entity_list($entities, $count, $offset, 10, FALSE, FALSE, TRUE);	
	break;
	
	case 'acqua':
		$acquas = array();
		$mygroups = get_entities_from_relationship('member', $_SESSION["user"]->getGUID(), FALSE, 'group', "", 0, "", 999, 0, FALSE, 0);
		foreach($mygroups as $group) {
			$members = $group->getMembers(999);
			foreach($members as $aqcua) {
				if ($aqcua->getGUID())
				$acquas[$aqcua->getGUID()]=(string)((int)($acquas[$aqcua->getGUID()])+1);
			}
		}
		
		unset($acquas[$_SESSION["user"]->getGUID()]);
		arsort($acquas, SORT_NUMERIC);
		foreach ($acquas as $acqua => $count) {
			$acqua=get_entity($acqua);
			if (!$acqua->isFriend()){
			$entities[]=$acqua;
		}
		}
		$entities_slice = array_slice($entities, $offset, 10);
		$filter_content = elgg_view_entity_list($entities_slice, count($entities), $offset, 10, FALSE, TRUE, TRUE);
	break;

	case "newest":
	case 'default':
		$filter_content = elgg_list_entities(array('type' => 'user', 'offset' => $offset, 'full_view' => FALSE));
	break;
}

// create the members navigation/filtering
$members = get_number_users();
$members_nav = elgg_view("members/members_sort_menu", array("count" => $members, "filter" => $filter));

$content = $members_nav . $filter_content;

// title
$main_content = elgg_view_title(elgg_echo("members:members"));

$main_content .= elgg_view('page_elements/contentwrapper', array('body' => $content, 'subclass' => 'members'));

$body = elgg_view_layout("sidebar_boxes", $sidebar, $main_content);

page_draw(elgg_echo('members:members'), $body);
