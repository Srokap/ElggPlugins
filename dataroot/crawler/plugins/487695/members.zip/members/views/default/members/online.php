<?php
/**
 * Elgg acquaintancers plugin
 * This plugin has some interesting options for users; see who friends are online, site members, acquaintancers, etc.. 
 * 
 * @package ElggMembers (acquaintancers fork)
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Lorea.cc
 * @link https://lorea.cc
 */

function get_online_friends() {
        $offset = get_input('offset', 0);
        //$count = count(find_active_users(600, 9999));
        $objects = find_active_users(600, 10, $offset);
	$active_friends=array($_SESSION['user']);
	foreach($objects as $object){
		if($object->isFriend()){
			$active_friends[]=$object;
		}
	}

        return elgg_view_entity_list($active_friends,count($active_friends),$offset,10,false);
}
?>

<?php

	/**
	 * Show friends online
	 **/
	 
	 echo "<div class=\"members_online\">";
	 echo get_online_friends();
	 echo "</div>";
	 
?>
