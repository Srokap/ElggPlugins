<?php

	$japanese = array(
			
		'members:members' => "メンバー",//"Members",
	    'members:online' => "ログイン中のユーザー",//"Users active now",
	    'members:active' => "アクティブユーザー",//"site users",
	    'members:searchtag' => "タグでユーザーを検索",//"User search via tag",
	    'members:searchname' => "名前でユーザーを検索",//"User search via name",
	   
		'members:label:newest' => '新着',//'Newest',
		'members:label:popular' => '人気',//'Popular',
		'members:label:active' => 'アクティブ',//'Active',
		'members:search:name' => 'ユーザー名',//'Users name',
		'members:search:tags' => 'タグ',//'Tags',
		
	);
					
	add_translation("ja",$japanese);

?>
