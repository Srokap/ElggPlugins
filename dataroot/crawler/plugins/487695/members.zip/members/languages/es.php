<?php

// Generado por translationbrowser 

$spanish = array( 
	 'members:members'  =>  "Usuarios registrados en la red social" , 
	 'members:online'  =>  "Usuarios online" , 
	 'members:active'  =>  "Usuarios registradxs" , 
	 'members:searchtag'  =>  "Buscar usuarios por etiquetas" , 
	 'members:searchname'  =>  "Buscar usuarios por nombre" , 
	 'members:label:newest'  =>  "Todos" , 
	 'members:label:popular'  =>  "Populares" , 
	 'members:label:active'  =>  "Conectados",
	 'members:label:acqua' => "Cercanos",
         'members:label:friends' => "Amigos",

	); 

add_translation('es', $spanish); 

?>
