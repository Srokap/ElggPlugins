<?php

// Generate By translationbrowser. 

$serbian = array( 
	 'members:members'  =>  "Korisnici sajta" , 
	 'members:online'  =>  "Trenutno aktivni korisnici" , 
	 'members:active'  =>  "korisnici sajta" , 
	 'members:searchtag'  =>  "Pretraga korisnika po tag-ovima" , 
	 'members:searchname'  =>  "Pretraga korisnika po imenu" , 
	 'members:label:newest'  =>  "Najnoviji" , 
	 'members:label:popular'  =>  "Popularni" , 
	 'members:label:active'  =>  "Aktivni"
); 

add_translation('sr', $serbian); 

?>