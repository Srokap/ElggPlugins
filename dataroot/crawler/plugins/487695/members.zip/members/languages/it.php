<?php

// Generate By translationbrowser. 

$italian = array( 
	 'members:members'  =>  "Membri sito" , 
	 'members:online'  =>  "Membri attivi al momento" , 
	 'members:active'  =>  "Membri del sito" , 
	 'members:searchtag'  =>  "Ricerca membri via tags" , 
	 'members:searchname'  =>  "Ricerca per nome" , 
	 'members:label:newest'  =>  "Novità" , 
	 'members:label:popular'  =>  "Popolari" , 
	 'members:label:active'  =>  "Attivi"
); 

add_translation('it', $italian); 

?>