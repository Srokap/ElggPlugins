<?php
	/**
	 * views/css/export_unique
	 * Exporta una calificación de un alumno
	 *
	 * @package ElggActivity
	 */

	require_once(dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "/engine/start.php");
	require_once($CONFIG->pluginspath . "/rubricas/lib/assess_functions.php");
	
	// Coger el guid
	$guid = get_input("alumno");
	$guid_envio = get_input("envio");
	$guid_act = get_input("act");
	
	// Coger parámetros de entrada
	$alumno = get_entity($guid);
	$envio = get_entity($guid_envio);
	$act = get_entity($guid_act);

	if ($alumno & $envio & $act)
	{
		$name = $alumno->name . "-".$act->title.".csv";
		// cabecera
		header("Content-type: text/csv");
		header("Content-Disposition: attachment; filename=\"$name\"");
		header("Pragma: no-cache");
		header("Expires: 0");
	
		$separator = ";";
		
		echo "Alumno/a" . $separator . utf8_decode($alumno->name) . "\n";
		if (is_plugin_enabled('datos'))
		{
			// Mostrar apellidos
			$a = get_metadata_byname($alumno->guid, 'apellidos');
			echo elgg_echo('actividad:apellidos') . $separator . utf8_decode($a->value) . "\n";
			// Mostrar email 	
			echo "Email" . $separator . $alumno->email . "\n";		
			// Mostrar dni
			$a = get_metadata_byname($alumno->guid, 'dni');
			echo "DNI" . $separator . utf8_decode($a->value) . "\n";
		}
		echo "Actividad" . $separator . utf8_decode($act->title) . "\n\n";
		
		$c = get_assessment ( $envio->guid );
				
		// Si es un rubrica
		if ($act->rubrica != "0")
		{
			$r = get_entity($act->rubrica);
			echo "Tipo de evaluacion" . $separator . " Rubrica \n"; 
									
			// Si aún no se ha evaluado
			if ($c == false)
			{
				echo "No existe ninguna evaluación \n";
			}
			// Ya se ha evaluado 
			else
			{
				echo exportar_evaluacion($c->guid, $r->guid) ."\n";
				$total = round((($c->numerica * 100) / $c->total)*100)/100;
				echo utf8_decode("Puntuación total: ") . $separator . $c->numerica ." / ". $c->total ." ( ". $total ." % ) \n";
			}		

		}
		// Si es una nota numerica
		else
		{
			echo "Tipo de evaluacion" . $separator . " Nota numerica \n"; 
					
			// No se ha evaluado
			if ($c == false)
				echo "No existe ninguna evaluación \n";

			// Ya se ha evaluado 
			else					
				echo "Nota: ". $separator . $c->numerica." / ". $c->total . "\n";				
		}

		exit; 
	}
	else
	{
		register_error(elgg_echo("actividad:failed"));
		forward();
	}
	
?>