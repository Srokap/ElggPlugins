<?php
	/**
	 * Exporta las calificaciones de un alumnos
	 * Muestra los datos si es posible
	 *
	 * @package ElggActivity
	 */

	require_once(dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "/engine/start.php");
	
	require_once($CONFIG->pluginspath . "/actividad/lib/functions.php");
	require_once($CONFIG->pluginspath . "/rubricas/lib/assess_functions.php");
	
	// Coger el guid
	$guid = get_input("alumno");

	// Coger el alumno
	$alumno = get_entity($guid);

	if ($alumno)
	{
		$name = $alumno->name . "-notas.csv";
		// cabecera
		header("Content-type: text/csv");
		header("Content-Disposition: attachment; filename=\"$name\"");
		header("Pragma: no-cache");
		header("Expires: 0");
	
		$separator = ";";
		
		echo "Notas" . $separator . utf8_decode($alumno->name) . "\n\n";
		
		// Mostrar mas datos del alumno si es posible
		if (is_plugin_enabled('datos'))
		{
			// Mostrar apellidos
			$a = get_metadata_byname($alumno->guid, 'apellidos');
			echo elgg_echo('actividad:apellidos') . $separator . utf8_decode($a->value) . "\n";
			// Mostrar email 	
			echo "Email" . $separator . $alumno->email . "\n";		
			// Mostrar dni
			$a = get_metadata_byname($alumno->guid, 'dni');
			echo "DNI" . $separator . utf8_decode($a->value) . "\n\n";
		}
				
		// Cabecera de la tabla
		echo "Actividad" . $separator . "Grupo" . $separator . utf8_decode("Calificación") . $separator . "Peso \n";

		$envios = coger_envios_por_usuario( $alumno->guid );
		
		if (is_array($envios) || $envios != "")
		{
			foreach ($envios as $env)
			{
				$e = get_entity($env);
				$a = get_entity ( $e->actividad);
				
				$evaluaciones = true;	
				
				// Grupo				
				if ( $a->grupo == 'si' )
				{
					$g = get_entity($e->grupo);
					$grupo = utf8_decode($g->name);
				}
				else
					$grupo = 'Individual';
				
				// Nota		
				if ( $c = get_assessment( $e->guid) )
				{
					$nota = mostrar_nota($c->guid);
					$peso = $c->peso;			
				}		
				else
				{
					$nota = elgg_echo('actividad:nograde');
					$peso = '1';
				}		
	
			    echo utf8_decode($a->title) . $separator . $grupo. $separator . $nota . $separator . $peso . $separator . "\n";
									
				if ($c != '0')
				{
					$final += $c->porcentaje * $peso;
					$t += $peso;
				}	
				
			} // If
		} // Foreach											

		echo "Puntuacion Total" . $separator . elgg_echo('actividad:iag') . $separator . number_format($final/$t,2) . " / 100" . $separator;
				
		exit; 
	}
	else
	{
		register_error(elgg_echo("actividad:failed"));
		forward();
	}
	
?>