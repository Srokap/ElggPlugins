<?php

/*
* views/default/actividad/calificar_alumno
*
* @package ElggActivity
*/

// Funciones
require_once($CONFIG->pluginspath . "/actividad/lib/functions.php");
require_once($CONFIG->pluginspath . "/rubricas/lib/assess_functions.php");

include_once dirname(dirname(dirname(dirname(dirname(dirname(__FILE__)))))) . "/engine/start.php";
?>



<?php
	
	$enviar = "<div class='content'>";  
	
	$enviar .= "<div class='actividad_view'>";
	$enviar .= "<div class=\"generic_comment_icon\">";
	$enviar .= elgg_view("profile/icon", array('entity' => $vars['entity'], 'size' => 'small'));
	$enviar .= "</div>";														
	$enviar .= "&nbsp;&nbsp;<a href={$vars['entity']->getURL()}>{$vars['entity']->name}</a> ";											
	
	// Cabecera de la tabla
	$cabecera .= "<div class='calificacion'><p><center><table id='selectable'><tr><td id='cabecera'>".elgg_echo('actividad:actividad')."</td><td id='cabecera'><center>".elgg_echo('actividad:group')."</center></td><td id='cabecera'><center>".elgg_echo('actividad:calificacion')."</center></td><td id='cabecera'><center>".elgg_echo('actividad:peso')."</center></td><td id='cabecera'><center>".elgg_echo('actividad:visibilidad')."</center></td></tr>";
	
	$t = 0;
	$final = 0;		
	$i = 1;
	
	$envios = coger_envios_por_usuario( $vars['entity']->guid );
	
	if (is_array($envios) || $envios != "")
	{
		foreach ($envios as $env)
		{
			$e = get_entity($env);
			$a = get_entity ( $e->actividad);
			
			// Grupo o individual			
			if ( $a->grupo == 'si' )
			{
				$g = get_entity($e->grupo);
				$grupo = $g->name;
			}
			else
				$grupo = 'Individual';
			
			// Ver si hay notas		
			if ( $c = get_assessment( $e->guid) )
			{
				$nota = mostrar_nota($c->guid);
				$peso = $c->peso;
				if ( $c->visible == 'true' )
					$v = "<img title='Editar' src=\"". $vars['url']."mod/actividad/graphics/tick.gif\"/>";
				else							
					$v = "<img src=\"". $vars['url']."mod/actividad/graphics/cross.gif\" />";				
			}		
			else
			{
				$nota = elgg_echo('actividad:nograde');
				$peso = '1';
				$v = "<img src=\"". $vars['url']."mod/actividad/graphics/cross.gif\" />";	
			}			
			
			if ($grupo != 'Individual')
				$tabla .= "<tr><td><a href='".$vars['url']."mod/actividad/pages/evaluar.php?act=".$a->guid."&user=".$e->owner_guid."'>".$a->title."</a></td><td>".$grupo."</td><td>".$nota."</td><td>".$peso."</td><td><center>".$v."</center></td></tr>";
			else
				$tabla .= "<tr><td><a href='".$vars['url']."mod/actividad/pages/evaluar.php?act=".$a->guid."&user=".$vars['entity']->guid."'>".$a->title."</a></td><td>".$grupo."</td><td>".$nota."</td><td>".$peso."</td><td><center>".$v."</center></td></tr>";
			
			// Calculo de nota final (Todas las actividades evaluadas)
			$i++;	
							
			if ($c != '0')
			{
				$final += $c->porcentaje * $peso;
				$t += $peso;
			}	
		}	// Foreach			
		
		$enviar .= $cabecera . $tabla . "<tr><td id='total'>Total</td><td id='total'>".elgg_echo('actividad:iag')."</td><td id='total'>".number_format($final/$t,2) . " / 100</td><td id='total'></td><td id='total'></td></tr>";
		$enviar .= "</table></center></p></div>";	
		$enviar .= elgg_view('input/securitytoken');       
		
	} // If
	
	else
		$enviar .= "<br><br>El usuario <b>". $vars['entity']->name ."</b> no ha realizado ningún envío";

	$enviar .= "</div>";
	
	// Boton volver
	$enviar .= "<form name='validar' action='".$vars['url']."mod/actividad/pages/calificar_alumnos.php' method='post'>";
	$enviar .= "<center><p><input type='submit' value='".elgg_echo('actividad:back')."' name='volver' title='".elgg_echo('actividad:back')."'></p></center></form>";
	
	echo $enviar;

?>
