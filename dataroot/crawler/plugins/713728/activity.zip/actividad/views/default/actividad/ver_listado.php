<div class="contentWrapper">

<?php

/* 
* views/default/listado
* Muetra un listado de las actividades del sistema.
*
* @package ElggActivity
*/
	// Vista de Widget (dashboard)
	if (get_context() == "search")
	{
		echo "<div id='act_widget'>";
		$owner = $vars['entity']->getOwnerEntity();
		$friendlytime = elgg_view_friendly_time($vars['entity']->time_created);
		$icon = elgg_view(
				"profile/icon", array(
										'entity' => $owner,
										'size' => 'small',
									  )
			);
		$info = "<p>" . elgg_echo('actividad:actividad') . ": <a href=\"{$vars['entity']->getURL()}\">{$vars['entity']->title}</a></p>";
		$info .= "<p class=\"owner_timestamp\"><a href=\"{$owner->getURL()}\">{$owner->name}</a> {$friendlytime}</p>";
		echo elgg_view_listing($icon,$info);		
		echo "</div>";
	}
	
	// Listado de actividades
	else
	{
		echo elgg_view('output/tags', array('tags' => $vars['entity']->tags));
		
		$owner = $vars['entity']->getOwnerEntity();
		$friendlytime = friendly_time($vars['entity']->time_created);
		$icon = elgg_view("profile/icon", array(
		              'entity' => $owner,
		              'size' => 'small',)
		         );
		
		// Mostramos el titulo de la actividad
		$info = "<p>" . elgg_echo('actividad:titulo') . ": <a href=\"{$vars['entity']->getURL()}?search_viewtype=gallery\">{$vars['entity']->title}</a></p>";
		
		// El propietario
		$info .= "<p class=\"owner_timestamp\"><a href=\"{$owner->getURL()}\">{$owner->name}</a> {$friendlytime}</p>";
		        
		// Visualizar por pantalla
		echo elgg_view_listing($icon,$info);
	
		if (get_loggedin_user()->isAdmin()) 
		{
			echo "<a href='". $vars['url'] ."mod/actividad/pages/editar.php?actividad=". $vars['entity']->getGUID() ."'>". elgg_echo("actividad:edit") ."</a>  &nbsp;";
		
			// Bot�n de borrar
			echo elgg_view("output/confirmlink", array(
			           'href' => $vars['url'] . "action/actividad/borrar?actividad=" . $vars['entity']->getGUID(),
			           'text' => elgg_echo('actividad:del'),
			           'confirm' => elgg_echo('deleteconfirm'),
			           ));
		}
	}

?>

</div>
