<?php
/* 
* views/default/actividad/calificar_grupos
* Listado de grupos para ser calificados
*
* @package ElggActivity
*/


	// Cargar grupos
	$query = "SELECT guid, name FROM {$CONFIG->dbprefix}groups_entity";
	$grupos = get_data($query);
	
	$content = "<div class='actividad_view'>";
	
	
	if ($grupos != "")
	{
		$content .= elgg_echo('actividad:selectgrupos').": <BR>";
	
		$content .= "<BR>";
		$content .= "<center>";
		
		$content .= "<div class='calificacion'><table><tr><td id='cabecera'><B>&nbsp Nombre </B></td><td id='cabecera'><B> ".elgg_echo('actividad:miembros')." </B></td></tr>";
			
		foreach ($grupos as $g)
		{
			
		     $content .= "<tr><td>";
		
			// Mostrar nombre de usuario
		    $content .= "<a href='".$vars['url']."mod/actividad/pages/calificar_grupo.php?grupo=".$g->guid."'>".$g->name."</a>";
			$content .= "</td><td>";
		
			// Mostrar nombre 
		    $miembros = get_group_members($g->guid);
		    foreach ($miembros as $m)
		    	$content .= $m-> name." ";
			$content .= "</td>";
		
			$content .= "</tr>";
		}
	
		$content .= "</table></div>";
	}
	else 
		$content .= elgg_echo('actividad:nogrupos')." <BR>";
		
	$content .= "</center>";
	$content .= "</td><td>&nbsp;&nbsp;&nbsp;</td><td>";
	
	$content .= "<BR>";
	$content .= "</div>";
	
	echo $content;

?>
