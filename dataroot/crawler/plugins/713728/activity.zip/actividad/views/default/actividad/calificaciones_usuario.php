<?php

/*
* views/default/actividad/calificaciones_usuario
* Muestra las calificaciones visibles de un usuario
*
* @package ElggActivity
*/

include_once dirname(dirname(dirname(dirname(dirname(dirname(__FILE__)))))) . "/engine/start.php";

// Funciones
require_once($CONFIG->pluginspath . "/actividad/lib/functions.php");
require_once($CONFIG->pluginspath . "/rubricas/lib/assess_functions.php");

	$actividades = elgg_get_entities(array("type"=>"object", "subtypes"=>"actividad"));  
	
	$usr = get_loggedin_userid();
	$user = get_entity($usr);
	
	$enviar = "<div class='content'>";  
	
	$enviar .= "<div class='actividad_view'>";

	$enviar .= "<div class=\"generic_comment_icon\">";
	$enviar .= elgg_view("profile/icon", array('entity' => $user, 'size' => 'small'));
	$enviar .= "</div>";														
	$enviar .= "&nbsp;&nbsp;<a href={$user->getURL()}>{$user->name}</a> ";											
	
	$cabecera .= "<div class='calificacion'><p><center><table id='selectable'><tr><td id='cabecera'>".elgg_echo('actividad:actividad')."</td><td id='cabecera'><center>".elgg_echo('actividad:group')."</center></td><td id='cabecera'><center>".elgg_echo('actividad:calificacion')."</center></td><td id='cabecera'><center>".elgg_echo('actividad:peso')."</center></td></tr>";
	
	$t = 0;
	$final = 0;		
	$i = 1;
	
	$evaluaciones = false;
	
	$envios = coger_envios_por_usuario( $user->guid );
	
	// Recorrer todos los envios del usuario
	if (is_array($envios) || $envios != "")
	{			
		foreach ($envios as $env)
		{
			$e = get_entity($env);
			$a = get_entity ( $e->actividad);	
			
			$c = get_assessment($e->guid);

			// Solo si es visible se muestra la nota							
			if ($c->visible == 'true')
			{
				$evaluaciones = true;	
				
				// Grupo o individual			
				if ( $a->grupo == 'si' )
				{
					$g = get_entity($e->grupo);
					$grupo = $g->name;
				}
				else
					$grupo = 'Individual';
								
				$nota = mostrar_nota($c->guid);
				$peso = $c->peso;
				
				$tabla .= "<tr><td><a href='".$vars['url']."mod/actividad/pages/visualizar_calificacion.php?act=".$a->guid."&user=".$e->owner_guid."'>".$a->title."</a></td><td>".$grupo."</td><td>".$nota."</td><td>".$peso."</td></tr>";
				
				$i++;	
								
				if ($c != "0")
				{
					$final += $c->porcentaje * $peso;
					$t += $peso;
				}	
				
			}	
		}					
	} // foreach (Envios)

	
	if ($evaluaciones)
	{
		$enviar .= $cabecera . $tabla . "<tr><td id='total'>Total</td><td id='total'>".elgg_echo('actividad:iag')."</td><td id='total'>".number_format($final/$t,2) . " / 100</td><td id='total'></td></tr>";
		$enviar .= "</table></center></p></div>";		
	}
	else
		$enviar .= "<br><br>Todavia no existen calificaciones";
	
	
	$enviar .= "</form>";
	$enviar .= "</div>";

	
	echo $enviar;

?>
