<?php

		/*
		* Gallery: Muestra una actividad y los objetos enviados
		*
		* @package ElggActivity
		*/

	  	require_once($CONFIG->pluginspath . "/actividad/lib/functions.php");

		gatekeeper();
	
		// Titulo
		echo "<div class='actividad_view'>";
		echo "<h3>" . $vars['entity']->title . "</h3>";
		
		// Descripci�n
		echo $vars['entity']->description;
		echo "<BR><BR>";
		
		// Informaci�n de la actividad
		echo "<div class='act_info'>";
		
		// Fechas de inicio y finalizaci�n
		echo "<b>" .elgg_echo('actividad:fechainicial') . "</b>: " . $vars['entity']->inicio;
		echo "<br><br>";
		echo "<b>" .elgg_echo('actividad:fechafin') . "</b>: ". $vars['entity']->fin;
		echo "<br><br>";

		// Actividad en grupo
		if ($vars['entity']->grupo == 'si')
			echo "<b>" .elgg_echo('actividad:tipoAct') . "</b>: " . elgg_echo('actividad:groupactivity');
		else
			echo "<b>" .elgg_echo('actividad:tipoAct') . "</b>: " . elgg_echo('actividad:individualactivity');
		echo "<BR><BR>";
		
		// Tipo de evaluaci�n
		echo "<b>" .elgg_echo('actividad:tipoeval') . "</b>: ";
		
		// Seleccionar rubrica
		if ($vars['entity']->rubrica == 0)
			echo elgg_echo('actividad:numerica') . "<br><br>";
		else
		{
			// Visualizar si el acceso es publico
			$rubrica = get_entity($vars['entity']->rubrica);
			if ($rubrica != "")
			{
				if ($rubrica->access_id != "0" || get_loggedin_user()->isAdmin())
				{
					echo elgg_echo('actividad:rubrica') . " ( ";
					echo "<a href=\"{$rubrica->getURL()}?search_viewtype=gallery\" target=\"_blank\">{$rubrica->title}</a> )";
					echo "<BR><BR>";
				}
			}
			else
				echo elgg_echo('actividad:rubrica');
		}

		// Informaci�n disponible solo para el administrador
		if (get_loggedin_user()->isAdmin()) 
		{			
			// Cuantos env�os hay
			echo  "<b>" .elgg_echo('actividad:numEnvios') . "</b>: ". num_envios($vars['entity']->guid);
			echo "<BR><br>";
			
			// Acceso
			echo  "<b>" .elgg_echo('actividad:acceso') . "</b>: ";
			echo get_readable_access_level($vars['entity']->access_id);
			echo "<br><br>";
			
			// Acceso del envio
			if ($vars['entity']->accesoenv == 'privado')
				$accesoenvio = elgg_echo('actividad:onlyowner');
			else
				$accesoenvio = elgg_echo('actividad:allusers');

			echo "<b>" . elgg_echo('actividad:accesoenv') . "</b>: ". $accesoenvio;
			echo "<br>";
	
			$botonBorrar = elgg_view("output/confirmlinkimg", array(
							'href' => $vars['url'] . "action/actividad/borrar?actividad=" . $vars['entity']->getGUID(),
							'title' => 'Delete',
							'img' => $vars['url']."mod/actividad/graphics/borrar.png",
							'confirm' => elgg_echo('deleteconfirm'),
						));
		}
		
		echo "</div>";
		
		if (get_loggedin_user()->isAdmin()) 
		{		
			// Tabla con botones de borrar y editar
			echo "<br><table><tr>";
			echo "<td text-align=\"center\">";
			echo "<a href=\"". $vars['url']."mod/actividad/pages/editar.php?actividad=".$vars['entity']->getGUID()."\"><img title='".elgg_echo("actividad:edit")."' src=\"". $vars['url']."mod/actividad/graphics/edit.gif\" /></a>  &nbsp;";
			echo "</td>";
			echo "<td>";
			echo $botonBorrar;
			echo "</td>";
			echo "</tr></table>";
		}
	
		echo "</div>";
		
		// Visualizar envios
		echo visualizar_envios($vars['entity']->getGUID(), $vars['entity']->accesoenv, $vars['url']);
		
		// Visualizar formulario de env�o
		echo envios_form($vars['entity']->guid, $vars['entity']->grupo, $vars['entity']->fin, $vars['url'], $vars['entity']->tipoenvio);
		

?>


