<?php
/* 
* views/default/actividad/calificar_alumnos
* Listado de alumnos para ser calificados
*
* @package ElggActivity
*/
	require_once($CONFIG->pluginspath . "/actividad/lib/functions.php");
	
	$curso = $_POST['curso'];
	if ($curso == "")	
		$curso = "todos";
	$materia = $_POST['mat'];
	if ($materia == "")	
		$materia = "todos";
		
	// Cargar nombres de usuarios
	$query = "SELECT guid, name, username, email FROM {$CONFIG->dbprefix}users_entity";
	$resultado = get_data($query);
	
	$content = "<div class='actividad_view'>";
	
	$tabla .= elgg_echo('actividad:usuarios').": <BR>";
	
	$tabla .= "<BR>";
	$tabla .= "<center>";
	
	$tabla .= "<div class='calificacion'><table>";
	
	if (is_plugin_enabled('datos'))
		$tabla .= "<tr><td id='cabecera'><B>".elgg_echo('actividad:user')." </B></td><td id='cabecera'><B> ".elgg_echo('actividad:nombre')." </B></td><td id='cabecera'><B> ".elgg_echo('actividad:apellidos')." </B></td><td id='cabecera'><B> ".elgg_echo('actividad:email')." </B></td><td id='cabecera'><B> ".elgg_echo('actividad:dni')." </B></td></tr>";
	else
		$tabla .= "<tr><td id='cabecera'><B>&nbsp Login </B></td><td id='cabecera'><B> ".elgg_echo('actividad:nombre_usuario')." </B></td></tr>";
	
	$encontrados = false;
	
	// Mostrar usuarios
	foreach ($resultado as $r)
	{

			$cursousr = get_metadata_byname($r->guid, 'curso');
			$materiausr = get_metadata_byname($r->guid, 'materia');

			if (($curso == 'todos') || ($cursousr->value == $curso) )
			{ 
				if (($materia == 'todos') || (esta_en($materia, $materiausr)) )
				{
					$encontrados = true;
					
					$tabla .= "<tr><td>";
				    
					// Mostrar nombre de usuario
				    $tabla .= "<a href='".$vars['url']."mod/actividad/pages/calificar_alumno.php?user=".$r->guid."'>".$r->username."</a>";
					$tabla .= "</td><td>";
				
					// Mostrar nombre 
				    $tabla .= $r->name;
					$tabla .= "</td>";
					
					// Si el plugin datos está activado podemos mostrar mas datos
					if (is_plugin_enabled('datos'))
					{
						// Mostrar apellidos
						$a = get_metadata_byname($r->guid, 'apellidos');
					    $tabla .= "<td>". $a->value;
						$tabla .= "</td>";
						// Mostrar email 
					    $tabla .= "<td>". $r->email;
						$tabla .= "</td>";			
						// Mostrar dni
						$a = get_metadata_byname($r->guid, 'dni');
					    $tabla .= "<td>". $a->value;
						$tabla .= "</td>";
					}
					
					$tabla .= "</tr>";
				}
			}
		
	}
	
	$tabla .= "</table></div>";
	$tabla .= "</center>";
	
	if ($encontrados)
		$content .= $tabla;
	else
		$content .= elgg_echo('actividad:nousuarios');
	
	$content .= "<BR>";
	$content .= "</div>";
	
	echo $content;
	


?>
