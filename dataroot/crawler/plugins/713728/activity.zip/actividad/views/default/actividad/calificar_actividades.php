<?php
/* 
* views/default/actividad/calificar_actividades
* Listado de actividades para ser calificadas
*
* @package ElggActivity
*/

//Mostrar las actividades disponibles
$actividades = get_entities ("object", "actividad");

if ($actividades != "")
{	
	echo "<div class='actividad_view'>";
	echo "<center><div class='calificacion'><table id='usuarios'>";
	echo "<tr><td id='cabecera'>Actividad</td><td id='cabecera'><center>Descripcion</center></td></tr>";
	
	foreach ($actividades as $a)
	{

		if ($a->title != "") 
		{			
     		 echo "<tr><td>";

	  		// Mostrar nombre de usuario
      		echo "<a href='".$vars['url']."mod/actividad/pages/calificar_actividad.php?actividad=".$a->guid."'>".$a->title."</a>";
	  		echo "</td><td>";
	  		echo $a->description;
	  		echo "</td></tr>";
		}	
	}
	
	echo "</table></div></center>";
	echo "</div>";
} 
else
	echo "No existen actividades creadas";

?>