<?php

	/**
	 * Elgg actividad/editar page
	 *
	 * @package ElggActivity
	 */
?>

<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/actividad/views/default/js/scripts.js"></script>	

<?php

	echo "<form name='val' action='". $vars['url']."action/actividad/editar' method='post'>";
	echo "<div class='actividad_form'>";
	echo "<form name='validar' action='confirm.php' method='post'>";
	
	echo "<h4>". elgg_echo('actividad:nombre') . "</h4>";
	echo "<BR>";
	echo elgg_view('input/text',array('internalname' => 'nombre', 'internalid'=>'nombre', 'value'=>$vars['entity']->title));
	echo "<BR><BR>";
	echo "<h4>". elgg_echo('actividad:descripcion') . "</h4>";
	echo "<BR>";
	echo "<textarea name='descripcion' rows='10' cols='60' id='descripcion'>".$vars['entity']->description."</textarea>";
	echo "<BR><BR>";
	echo "<h4>". elgg_echo('actividad:fechainicial') . "</h4>";
	echo "<BR>";
	echo elgg_view('input/calendar',array('internalname' => 'fechaini', 'internalid'=>'fechaini', 'value'=>$vars['entity']->inicio));
	echo "<BR><BR>";
	echo "<h4>". elgg_echo('actividad:fechafin') . "</h4>";
	echo "<BR>";
	echo elgg_view('input/calendar',array('internalname' => 'fechafin', 'internalid'=>'fechafin', 'value'=>$vars['entity']->fin));
	echo "<BR><BR>";
	
	// Tipo de evaluación
	echo elgg_view('rubricas/calificar/seleccionar_evaluacion');
	
	// Para grupos
	echo "<h4>". elgg_echo('actividad:grupos') . "</h4>";
	echo "<BR>";
	if ($vars['entity']->grupo == 'si')
		echo "<input type = 'checkbox' name='grupos' value='si' checked>".elgg_echo('actividad:groupactivity');
	else
		echo "<input type = 'checkbox' name='grupos' value='si'>".elgg_echo('actividad:groupactivity');
	echo "<BR><BR>";

	// Tipo de envio
	echo "<h4>". elgg_echo('actividad:tipoenv') . "</h4>";
	echo "<BR>";
	if ($vars['entity']->tipoenvio == 'texto')
		echo "<input type='radio' name='tipoenvio' value='texto' checked>".elgg_echo('actividad:solotexto');
	else
		echo "<input type='radio' name='tipoenvio' value='texto'>".elgg_echo('actividad:solotexto');
	echo "<BR>";
	if ($vars['entity']->tipoenvio == 'adjunto')
		echo "<input type='radio' name='tipoenvio' value='adjunto' checked>".elgg_echo('actividad:soloadjunto');
	else
		echo "<input type='radio' name='tipoenvio' value='adjunto'>".elgg_echo('actividad:soloadjunto');
	echo "<BR>";
	if ($vars['entity']->tipoenvio == 'ambos')
		echo "<input type='radio' name='tipoenvio' value='ambos' checked>".elgg_echo('actividad:ambos');
	else
		echo "<input type='radio' name='tipoenvio' value='ambos'>".elgg_echo('actividad:ambos');
	echo "<BR><BR>";	
		
	// Acceso de la actividad y de los envios
	$access_input = elgg_view('input/access', array('internalname' => 'access_id', 'value' => $vars['entity']->access_id, 'default'=>$vars['entity']->access_id));
	echo "<h4>". elgg_echo('actividad:acceso') . "</h4>";
	echo "<BR>";
	echo $access_input;
	echo "<BR><BR>";
	echo "<h4>". elgg_echo('actividad:accesoenv') . "</h4>";
	echo "<BR>";
	if ($vars['entity']->accesoenv == 'privado')
		echo "<input type = 'checkbox' name='accesoenvio' value='privado' checked>".elgg_echo('actividad:onlyowner');
	else
		echo "<input type = 'checkbox' name='accesoenvio' value='privado'>".elgg_echo('actividad:onlyowner');
	echo "<BR><BR>";

	echo "<center><input type='button' value='". elgg_echo('actividad:enviar') ."' title='". elgg_echo('actividad:enviar') ."' onclick='valida()' class='boton'></center>";

	echo elgg_view('input/securitytoken'); 
	
	if (isset($vars['entity'])) 
	{
        $entity_hidden = elgg_view('input/hidden', array('internalname' => 'actividad', 'value' => $vars['entity']->getGUID()));
        echo $entity_hidden;
	}

	echo "</form>";
	echo "</div>";
	echo "</form>";
	
?>