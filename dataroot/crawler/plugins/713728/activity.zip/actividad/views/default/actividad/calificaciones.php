<?php
/* 
* views/default/actividad/calificar_alumnos
* Listado de alumnos para ser calificados
*
* @package ElggActivity
*/

	// Funciones auxiliares
	require_once($CONFIG->pluginspath . "/actividad/lib/functions.php");
	
	// Coger parametros
	$curso = $_POST['curso'];
	if ($curso == "")	
		$curso = "todos";
	$materia = $_POST['mat'];
	if ($materia == "")	
		$materia = "todos";

	// Cargar nombres de usuarios
	$query = "SELECT guid, name, username, email FROM {$CONFIG->dbprefix}users_entity";
	$resultado = get_data($query);
	
	$content = "<div class='actividad_view'>";
	
	$tabla .= elgg_echo('actividad:usuarios_cal').": <BR>";
	
	$tabla .= "<BR>";
	$tabla .= "<center>";
	
	// Filtros (Si el plugin está activado)
	if (is_plugin_enabled('datos'))
	{
		$content .= "<fieldset class='act_info'><legend>Filtrar</legend>";
		$content .= "<form name='validar' action='".$vars['url']."pg/actividad/calificaciones/' method='post'>";
		// Materias
		$mats = get_metadata_byname(get_loggedin_userid(), 'materia');
		
		if ($mats != "")
		{
			$content .= elgg_echo('actividad:filtromateria'). ": ";
			$content .= "<select name='mat'>";
			$content .= "<option value='todos'>".elgg_echo('actividad:todas')."</option>";
			if (count($mats) == 1)
				$content .= "<option value='".$mats->value."'>".$mats->value."</option>";
			else
			{
				foreach ($mats as $am)
					$content .= "<option value='".$am->value."'>".$am->value."</option>";
			}
			$content .= "</select><br> ";
		}
		
		// Curso
		$curs = get_metadata_byname(get_loggedin_userid(), 'curso');
		
		if ($curs != "")
		{
			$content .= elgg_echo('actividad:filtrocurso'). ": ";
			$content .= "<select name='curso'>";
			$content .= "<option value='todos'>".elgg_echo('actividad:todos')."</option>";
			$actual = '2009';
			$anho = date("Y");
			$mes = date("m");
			
			while ($actual != $anho)
			{
				$c = $actual . "/" . ++$actual;
				if ($curs->value == $c)
					$content .= "<option value=$c selected>$c</option>";
				else
					$content .= "<option value=$c>$c</option>";
			}
			
			if ($mes > '08') 
			{
				$c = $anho . "/" . ++$anho;
				if ($curs->value == $c)
					$content .= "<option value=$c selected>$c</option>";
				else
					$content .= "<option value=$c>$c</option>";
			}
			$content .= "</select><br> ";
		}
		
		$content .= "<input type='submit' class='boton' value='".elgg_echo('actividad:filtro')."' name='alumnos'><p>";
		$content .= "</form>";
		$content .= "</fieldset>";
	}	

	$tabla .= "<div class='calificacion'><table>";
	
	$encontrado = false;
	
	if (is_plugin_enabled('datos'))
		$tabla .= "<tr><td id='cabecera'><B>&nbsp Login </B></td><td id='cabecera'><B> ".elgg_echo('actividad:nombre')." </B></td><td id='cabecera'><B> ".elgg_echo('actividad:apellidos')." </B></td><td id='cabecera'><B> ".elgg_echo('actividad:email')." </B></td><td id='cabecera'><B> ".elgg_echo('actividad:dni')." </B></td></tr>";
	else
		$tabla .= "<tr><td id='cabecera'><B>&nbsp Login </B></td><td id='cabecera'><B> ".elgg_echo('actividad:nombre_usuario')." </B></td></tr>";
		
	// Mostrar usuarios
	foreach ($resultado as $r)
	{		
		$cursousr = get_metadata_byname($r->guid, 'curso');
		$materiausr = get_metadata_byname($r->guid, 'materia');

		if (($curso == 'todos') || ($cursousr->value == $curso) )
		{ 
			if (($materia == 'todos') || (esta_en($materia, $materiausr)) )
			{
				$encontrado = true;
		
				$tabla .= "<tr><td>";
	
				// Mostrar nombre de usuario
	    		$tabla .= "<a href='".$vars['url']."mod/actividad/pages/calificaciones_alumno.php?user=".$r->guid."'>".$r->username."</a>";
				$tabla .= "</td><td>";
	
				// Mostrar nombre 
	    		$tabla .= $r->name;
				$tabla .= "</td>";
				
				// Si el plugin datos está activado podemos mostrar mas datos
				if (is_plugin_enabled('datos'))
				{
					// Mostrar apellidos
					$a = get_metadata_byname($r->guid, 'apellidos');
					$tabla .= "<td>". $a->value;
					$tabla .= "</td>";
					// Mostrar email 
					$tabla .= "<td>". $r->email;
					$tabla .= "</td>";			
					// Mostrar dni
					$a = get_metadata_byname($r->guid, 'dni');
					$tabla .= "<td>". $a->value;
					$tabla .= "</td>";
				}
				$tabla .= "</tr>";
			}
		}
	}
	
	$tabla .= "</table></div>";
	$tabla .= "</center>";
	
	if ($encontrado)
		$content .= $tabla;
	else 
		$content .= elgg_echo('actividad:nousuarios');
		
	$content .= "<BR>";
	$content .= "</div>";
	
	echo $content;

?>
