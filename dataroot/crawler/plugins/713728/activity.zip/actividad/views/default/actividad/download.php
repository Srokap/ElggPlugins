<?php
	/**
	 * actividad/download
	 * 
	 * Permite descargar un archivo
	 * Utiliza la clase fichero definida por elgg
	 *
	 * @package ElggActivity
	 */

	require_once(dirname(dirname(dirname(dirname(dirname(dirname(__FILE__)))))) . "/engine/start.php");

	// Coge el guid
	$guid = get_input("envio");

	// Coger el fichero
	$envio = get_entity($guid);
	$fichero = get_entity($envio->fichero);
	if ($fichero)
	{

		$mime = $fichero->getMimeType();
		if (!$mime) 
			$mime = "application/octet-stream";
		
		$filename = $fichero->getFilename();
		
		// Arreglo para IE
		header("Pragma: public"); 
		header("Content-type: $mime");
		header("Content-Disposition: attachment; filename=\"$filename\"");

		echo $fichero->grabFile();
		exit; 
	}
	else
	{
		register_error(elgg_echo("file:downloadfailed"));
		forward();
	}
	
?>