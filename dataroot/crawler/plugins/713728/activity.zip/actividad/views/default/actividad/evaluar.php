<?php

/* 
* views/default/actividad/evaluar
* Permite evaluar una actividad mediante una rúbrica
*
* @package ElggActivity
*/

if (($vars['entity'] != "") && ($vars['act'] != ""))
{

	$envios = get_entities("object", "envio", $vars['entity']->guid);
	
	// Mostrar la actividad
	$act = "<div class='actividad_view'>";
	$act .= "<h3>".$vars['act']->title."</h3>";
	$act .= $vars['act']->description;
	$act .= "<br><br>";
	
	if ($envios != "")
	{
		foreach ($envios as $e)
		{
			// Si el envio es de esa actividad
			if ($e->actividad == $vars['act']->guid)
			{
				$act .= "<form name='validar' action='".$vars['url']."action/rubrics/calificar' method='post'>";
				
				// Mostrar el envio	
				$act .= "<fieldset class='act_info'><legend><b>".elgg_echo('actividad:envios')." </b></legend>";					
				
				// Imagen archivo adjunto
				if ($e->title != "")
				{
					$act .= "<img src=\"{$vars['url']}mod/actividad/graphics/clip.png?\" border=\"0\" width='20' height='20' />";
					$act .= "<a href=\"". $vars['url'] ."mod/actividad/views/default/actividad/download.php?envio=". $e->guid ."\">$e->title</a>";
					$act .= "<br><br>";	
				}	
				// Mostrar la descripcion					
				if ($e->description != '')					
					$act .= elgg_view("output/longtext",array("value" => $e->description));		
				
				// Datos del usuario 	
				$act .= "<div class=\"generic_comment_icon\">";
				$act .= elgg_view("profile/icon", array('entity' => $vars['entity'],'size' => 'small'));
				$act .= "</div>";
			    
				$act .= "<div class=\"generic_comment_details\">";
				$act .= "<a href={$vars['entity']->getURL()}>{$vars['entity']->name}</a>";
				$act .= "<p class=\"generic_comment_owner\">";
				$act .= elgg_view_friendly_time($e->time_created);	
				$act .= "</p>";															
				$act .= "</div>";	
				$act .= "<br>";	
				
				// Mostrar mas datos del usuario si el plugin esta habilitado
				if (is_plugin_enabled('datos'))
				{
					// Mostrar apellidos
					$a = get_metadata_byname($vars['entity']->guid, 'apellidos');
					$act .= "<b>". elgg_echo('actividad:nombreapellidos') . ":</b> " . $vars['entity']->name . " ". $a->value ."<br>";
					// Mostrar email 
					$act .= "<b>". elgg_echo('actividad:email') . ":</b> " . $vars['entity']->email ."<br>";			
					// Mostrar dni
					$a = get_metadata_byname($vars['entity']->guid, 'dni');
					$act .= "<b>". elgg_echo('actividad:dni') . ":</b> " . $a->value ."<br>";
				}
				
				// Si es en grupo, mostrarlo
				if ($vars['act']->grupo == "si")
				{
					$g = get_entity($e->grupo);
					$act .= "<b>". elgg_echo('actividad:group'). ":</b> " . $g->name;
				}
																
				$act .= "</fieldset>";
				$act .= "<br>";
				
				// Mostrar opciones de evaluacion
				$act .= elgg_view('rubricas/calificar/evaluar', array('rubrica'=>$vars['act']->rubrica, 'actividad'=>$e->guid));
					
				// Datos necesarios para almacenar la calificacion	
				$act .= "<input type='hidden' id='act' name='act' value='".$vars['act']->rubrica."'>";
				$act .= "<input type='hidden' id='envio' name='envio' value='".$e->guid."'>";		
				$act .= "<input type='hidden' id='url' name='url' value='".$vars['url']."mod/actividad/pages/evaluar.php?user=".$e->owner_guid."&act=".$vars['act']->guid."'>";		
				
				$act .= $boton;
				$act .= elgg_view('input/securitytoken');    
				
				$act .= "</form>";
				$act .= "</div>";
				
				// Boton volver
				$act .= "<form name='validar' action='".$vars['url']."/pg/actividad/calificar/' method='post'>";
				$act .= "<center><p><input type='submit' value='".elgg_echo('actividad:back')."' name='volver' title='".elgg_echo('actividad:back')."'></p></center></form>";
				
			}
		}

	}

	echo $act;
}

else
{
	echo "<div class='actividad_view'>";
	echo "[ERROR] No ha seleccionado ninguna actividad";
	echo "</div>";
}

?>
