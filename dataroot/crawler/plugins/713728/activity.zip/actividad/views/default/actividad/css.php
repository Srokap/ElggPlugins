/* CSS for actividad begin */

.actividad_div {
	color: #000000;
}

/* Actividad
* Crear
*/
.actividad_form {
	margin: 10px;
	-moz-border-radius: 8px;
	background: none repeat scroll 0 0 white;
	display: block;
	padding: 10px;
}

.actividad_form h4{
	font-weight: normal;
	margin: 0px;
	font-size: 1.2em;
	color: #4690D6;
}

#select_rubric td{
	border: 1px solid #CCCCCC;	
	background: white;
	-moz-border-radius:8px 8px 8px 8px;
	padding: 10px;
}

.actividad_form hr{
	color: #dcdcdc;
	background-color: #dcdcdc;
}

/* Actividad
* Vista galería
*/

.actividad_view {
	-moz-border-radius:8px 8px 8px 8px;
	background:none repeat scroll 0 0 white;
	margin:10px 10px 10px;
	padding:10px;
}

.actividad_view h3 {
	font-size:150%;
	margin:0 0 10px;
	padding:0;
	font-weight:bold;
	color: #4690D6
}

.actividad_view h5 {
	color: #AAAAAA;
	font-style: italic;
}

.actividad_view .spratline {
	color:#AAAAAA;
	line-height:1em;
}

.act_info {
	color: #808080;
	border-style: solid;
	border-color: #dcdcdc;
	border-width: 1px;
	margin-bottom: 15px;
	padding: 10px;
	-moz-border-radius: 3px 3px 15px 15px;
}

/* ***************************************
	Vista de galería de una rúbrica
*************************************** */

.act_gallery table#evaluar{

  background: #DCDCDC;
  -moz-border-radius: 5px white;

}

.act_gallery table#celda{

  background: #ffffff;
  border: solid #DCDCDC 3px;
  width: 100%;
  height: 100%;

}



.act_gallery table#celdat{

  background: #4682B4;
  border: solid #4682B4 3px;
  color: FFFFFF;
  width: 100%;
  height: 100%;

}

.act_gallery tr#crit{

  margin: 3em;

}

.celdas{
  padding: 2px;
  height: 100%;
 vertical-align: center; 
 border:3px solid #DCDCDC;
 color: #000000;
}

.seleccionada{
	background: #FFA500;
	text-align: center; 
  	height: 100%;
  	padding: 2px;
 	vertical-align: center; 
 	padding: 2px;
 	border:3px solid #FFA500;
}

.seleccionada a{
	color: #ffffff;
}

.act_gallery td#crit{
  padding: 3px;
  height: 100%;
   border-bottom: #dcdcdc 3px;
  background:#ffffff;
}

.act_gallery td#puntos{

  border-bottom: dotted #4682B4 3px;
  background:#4682B4;
  color: #ffffff;
  font-weight:bold;

}

.act_gallery td#titul{

  border-bottom: dotted #4682B4 3px;
  background:#4682B4;
  color: #ffffff;
  font-weight:bold;

}
// Evaluar actividad
.content div{
	margin:10px 10px 10px;

}

.ui-selecting { background: #FFA500; }
.ui-selected { background: #FF8000; }

.calificacion table{
	border: solid #dcdcdc 1px;
	-moz-border-radius: 5px;
	height: 100%;
	padding: 10px;
}

.calificacion td{
	padding: 5px;
	border: solid #dcdcdc 1px;
}

.calificacion td#cabecera{
	padding: 5px;
	background: #4682B4;
	border: solid #4682B4 1px;
	color: #ffffff;
}

.calificacion td#total{
	padding: 5px;
	background: #dcdcdc;
}

legend {
	margin: 0;
	padding: 0;
	margin-left: 0.5em;
}

#selectable .ui-selected { 
	background: #F39814; 
	color: white; 
}

.send_twitter {
	color: #808080;
	border-style: solid;
	border-color: #CCCCCC;
	border-width: 1px;
	margin-bottom: 15px;
	padding: 10px;
	-moz-border-radius: 15px;
	background: url(<?php echo $vars['url']; ?>mod/actividad/graphics/twitter.gif) no-repeat #F8F8F8;
	background-position: bottom left;
	height: 150px;
	width: 300px;
}

textarea:focus, input[type="text"]:focus {
	-moz-border-radius: 5px;
	border: 1px solid #CCCCCC;
	padding: 5px;
	-moz-box-shadow: 0 0 8px rgba(82, 168, 236, 0.5);
	border-color: rgba(82, 168, 236, 0.75) !important;
	background: none repeat scroll 0 0 #FFFFFF;
}

#text {
	-moz-border-radius: 4px;
	-moz-box-shadow: 0 1px 0 #F8F8F8;
	border-color: #BBBBBB #BBBBBB; #999999;
	border-style: solid;
	border-width: 1px;
	color: #333333;
	background: url(<?php echo $vars['url']; ?>mod/actividad/views/default/actividad/images/bg-btn.gif) repeat-x scroll 0 0 #DDDDDD;
	font: 12px/15px Helvetica Neue,Arial,"Lucida Grande",Sans-serif;
	text-align: right;
}

#testTextarea {
	font-size:75%;
	color: #222222;
	font: 14px/18px "Helvetica Neue",Arial,sans-serif;
}

#twitter_p {
	text-align: right;
}
/* CSS for actividad end */
