<?php

/* views/default/actividad/calificar
* Elegir calificar por usuario o actividad
*
* @package ElggActivity
*/

	echo "<div class='actividad_view'>";
	
	// Calificar usuario
	echo "<fieldset class='act_info'><legend>".elgg_echo('actividad:calificarusuarios')."</legend>";
	echo "<form name='validar' action='' method='post'>";
	
	// Filtrar por curso y materia si el plugin esta activado
	// Solo filtra en las materias que esta registrado
	if (is_plugin_enabled('datos'))
	{
		// Materias
		$materias = get_metadata_byname(get_loggedin_userid(), 'materia');
		
		if ($materias != "")
		{
			echo elgg_echo('actividad:filtromateria'). ": ";
			echo "<select name='mat'>";
			echo "<option value='todos'>".elgg_echo('actividad:todas')."</option>";
			if (count($materias) == 1)
				echo "<option value='".$materias->value."'>".$materias->value."</option>";
			else
			{
				foreach ($materias as $am)
					echo "<option value='".$am->value."'>".$am->value."</option>";
			}
			echo "</select><br> ";
		}
		
		// Curso
		$curso = get_metadata_byname(get_loggedin_userid(), 'curso');
		
		if ($curso != "")
		{
			echo elgg_echo('actividad:filtrocurso'). ": ";
			echo "<select name='curso'>";
			echo "<option value='todos'>".elgg_echo('actividad:todos')."</option>";
			$actual = '2009';
			$anho = date("Y");
			$mes = date("m");
			
			while ($actual != $anho)
			{
				$c = $actual . "/" . ++$actual;
				if ($curso->value == $c)
					echo "<option value=$c selected>$c</option>";
				else
					echo "<option value=$c>$c</option>";
			}
			
			if ($mes > '08') 
			{
				$c = $anho . "/" . ++$anho;
				if ($curso->value == $c)
					echo "<option value=$c selected>$c</option>";
				else
					echo "<option value=$c>$c</option>";
			}
			echo "</select><br><br>";
		}
	}	

	echo "<input type='button' class='boton' value='".elgg_echo('actividad:calificar_alumnos')."' name='alumnos' onclick='this.form.action=\"".$vars['url']."mod/actividad/pages/calificar_alumnos.php\";this.form.submit();'>";

	echo "</fieldset>";
	
	// Calificar actividad
	echo "<fieldset class='act_info'><legend>".elgg_echo('actividad:calificaractividad')."</legend>";
	echo "<input type='button' class='boton' value='".elgg_echo('actividad:calificar_actividad')."' name='actividad' onclick='this.form.action=\"".$vars['url']."mod/actividad/pages/calificar_actividades.php\";this.form.submit();'><p>";
	echo "</fieldset>";
	
	// Calificar grupo
	echo "<fieldset class='act_info'><legend>".elgg_echo('actividad:calificargrupo')."</legend>";
	echo "<input type='button' class='boton' value='".elgg_echo('actividad:calificar_grupo')."' name='grupo' onclick='this.form.action=\"".$vars['url']."mod/actividad/pages/calificar_grupos.php\";this.form.submit();'><p>";
	echo "</fieldset>";
	
	echo "</form>";
	
	echo "</div>";
	
?>