<?php

/*
* views/default/actividad/calificar_alumno
*
* @package ElggActivity
*/


include_once dirname(dirname(dirname(dirname(dirname(dirname(__FILE__)))))) . "/engine/start.php";

// Funciones
require_once($CONFIG->pluginspath . "/actividad/lib/functions.php");
require_once($CONFIG->pluginspath . "/rubricas/lib/assess_functions.php");


	$actividades = elgg_get_entities(array("type"=>"object", "subtypes"=>"actividad"));  
	
	$enviar = "<div class='content'>";  
	
	$enviar .= "<div class='actividad_view'>";
	$enviar .= "<div class=\"generic_comment_icon\">";
	$enviar .= elgg_view("profile/icon", array('entity' => $vars['entity'], 'size' => 'small'));
	$enviar .= "</div>";														
	$enviar .= "&nbsp;&nbsp;<a href={$vars['entity']->getURL()}>{$vars['entity']->name}</a> ";											
	
	$cabecera .= "<div class='calificacion'><p><center><table id='selectable'><tr><td id='cabecera'>".elgg_echo('actividad:actividad')."</td><td id='cabecera'><center>".elgg_echo('actividad:group')."</center></td><td id='cabecera'><center>".elgg_echo('actividad:calificacion')."</center></td><td id='cabecera'><center>".elgg_echo('actividad:peso')."</center></td><td id='cabecera'><center>".elgg_echo('actividad:visibilidad')."</center></td></tr>";
	
	// Para el calculo de la nota final
	$t = 0;
	$final = 0;		
	$i = 1;
	
	$envios = coger_envios_por_usuario( $vars['entity']->guid );
	
	// Recorrer todos los envios del usuario
	if (is_array($envios) || $envios != "")
	{
		foreach ($envios as $env)
		{

			$e = get_entity($env);
			$a = get_entity ( $e->actividad);	
			
			// Grupo o individual			
			if ( $a->grupo == 'si' )
			{
				$g = get_entity($e->grupo);
				$grupo = $g->name;
			}
			else
				$grupo = 'Individual';
			
			// Notas				
			if ($c = get_assessment($e->guid))
			{
				$nota = mostrar_nota($c->guid);
				$peso = $c->peso;
				if ( $c->visible == 'true' )
					$v = "<img title='Editar' src=\"". $vars['url']."mod/actividad/graphics/tick.gif\"/>";
				else							
					$v = "<img src=\"". $vars['url']."mod/actividad/graphics/cross.gif\" />";				
			}		
			else
			{
				$nota = elgg_echo('actividad:nograde');
				$peso = '1';
				$v = "<img src=\"". $vars['url']."mod/actividad/graphics/cross.gif\" />";	
			}		

			// Fila de la tabla;
			$tabla .= "<tr><td><a href='".$vars['url']."mod/actividad/pages/visualizar_calificacion.php?act=".$a->guid."&user=".$e->owner_guid."'>".$a->title."</a></td><td>".$grupo."</td><td>".$nota."</td><td>".$peso."</td><td>".$v."</td></tr>";
				
			// Cálculo de la nota final
			$i++;	
								
			if ($c != '0')
			{
				$final += $c->porcentaje * $peso;
				$t += $peso;
			}	

		} // Foreach
		
		// Final de la tabla (notas totales)
		$enviar .= $cabecera . $tabla . "<tr><td id='total'>Total</td><td id='total'>".elgg_echo('actividad:iag')."</td><td id='total'>".number_format($final/$t,2) . " / 100</td><td id='total'></td><td id='total'></td></tr>";
		$enviar .= "</table></center></p></div>";	

		$enviar .= elgg_view('input/securitytoken');       

		// Exportar
		$enviar .= "<br><center><a href=\"". $vars['url']."mod/actividad/views/csv/export.php?alumno=". $vars['entity']->guid ."\" method=\"post\"><img title='Exportar' src=\"". $vars['url']."mod/actividad/graphics/csv-icon.gif\" class=\"botonExcel\" /></a></p></center>";	
		
	} // IF

	else
		$enviar .= "<br><br>El usuario <b>". $vars['entity']->name ."</b> no ha realizado ningún envío";
		
	//$enviar .= "</form>";
	$enviar .= "</div>";
	
	// Boton volver
	$enviar .= "<form name='validar' action='".$vars['url']."mod/actividad/pages/calificaciones.php' method='post'>";
	$enviar .= "<center><p><input type='submit' value='".elgg_echo('actividad:back')."' name='volver' title='".elgg_echo('actividad:back')."'></p></center></form>";
	
	echo $enviar;

?>