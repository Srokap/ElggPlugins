
// Funcion para validar el formulario de creacion de una actividad

function valida()
{
    //validar el titulo
    if (document.getElementById("nombre").value.length==0)
    {
       alert("Debe introducir un nombre");
       return 0;
    }
    
    //validar descripcion
    if (document.getElementById("descripcion").value.length==0)
    {
       alert("Debe introducir una descripcion");
       return 0;
    }
    
    //validar fecha inicial
    if (document.getElementById("fechaini").value.length==0 )
    {
       alert("Debe introducir una fecha de inicio");
       return 0;
    }
    
    //validar fecha final
    if (document.getElementById("fechafin").value.length==0)
    {
       alert("Debe introducir una fecha de finalizacion");
       return 0;
    }

	// Validar tipo de evaluacion
	if (!(document.val.tipoevaluacion[0].checked) && !(document.val.tipoevaluacion[1].checked))
	{
       alert("Debe seleccionar un tipo de evaluacion");
       return 0;		
	}
	
	// Validar tipo de envio
	if (!(document.val.tipoenvio[0].checked) && !(document.val.tipoenvio[1].checked) && !(document.val.tipoenvio[2].checked))
	{
       alert("Debe seleccionar un tipo de envio");
       return 0;		
	}	
	
    //El formulario se envia
    document.val.submit();
}

// Funcion para validar el formulario de nuevo envio

function valida_envio() 
{
	if (document.getElementById("adjunto") != null)
	{
	    //validar el fichero adjunto
	    if (document.getElementById("adjunto").value.length!=0 && document.getElementById("nombrefichero").value.length==0)
	    {    	
		 		alert("Requerido: Nombre de fichero");
		       return 0;   	    	
	    }
		else
		{
				if (document.getElementById("adjunto").value.length==0 && document.getElementById("nombrefichero").value.length!=0)
		    	{ 
				       alert("Requerido: Fichero adjunto");
				       return 0;
		    	}
		}
	}
	// Validar el texto
	if (document.getElementById("descripcion") != null)
	{
	    if (document.getElementById("descripcion").value.length==0 )
	    {    	
		 		alert("Requerido: Texto");
		       return 0;   	    	
	    }
	}		

    //El formulario se envia
    document.val.submit();
}

