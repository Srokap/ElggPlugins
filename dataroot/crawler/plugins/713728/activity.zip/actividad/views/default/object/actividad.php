<?php

	if (get_input('search_viewtype') == "gallery") 
	{
		// Visualizar la vista de galeria
	    echo elgg_view("actividad/gallery",$vars);	
	} 
	else 
	{
		echo elgg_view("actividad/ver_listado",$vars);	
	}
	
?>