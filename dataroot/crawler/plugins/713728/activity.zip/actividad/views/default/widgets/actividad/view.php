<?php

	$num = $vars['entity']->num_display;
	
	//if no number has been set, default to 4
	if (!$num) 
	{
		$num = 4;
	}
	
	set_context('search');

	// Listado de todas las actividades (Las del usuario y las publicas)
	$content = elgg_list_entities(array('types' => 'object', 'subtypes' => 'actividad', 'limit' => $num, 'full_view' => FALSE, 'pagination' => FALSE));
	
	echo $content;
	
	if ($content) 
	{
		$acturl = $vars['url'] . "pg/actividad/ver";
		echo "<div class=\"widget_more_wrapper\"><a href=\"{$acturl}\">".elgg_echo('actividad:list')."</a></div>";
	}

?>