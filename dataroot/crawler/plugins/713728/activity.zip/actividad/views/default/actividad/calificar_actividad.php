<?php

/*
* views/default/actividad/calificar_actividad
*
* @package ElggActivity
*/

// Funciones
require_once($CONFIG->pluginspath . "/actividad/lib/functions.php");
require_once($CONFIG->pluginspath . "/rubricas/lib/assess_functions.php");

echo "<script src=\"".$vars['url']."mod/actividad/views/default/js/jquery.textareaCounter.plugin.js\" type=\"text/javascript\"></script>";

?>
	
<script type="text/javascript">
	$(document).ready(function(){
		var options = {
					'maxCharacterSize': 140,
					'warningColor': '#CC3300',  
					'warningNumber': 0,
					'isCharacterCount': true,
					'isWordCount': false,
					'displayFormat': '#input'
		};
		$('#testTextarea').textareaCount(options);
	});
	
</script>

<?php

	$envios = coger_envios_por_actividad( $vars['entity']->guid );
	
	$enviar = "<div class='content'>";  								
	
	$enviar .= "<div class='actividad_view'>";
	
	// Mostrar titulo y descripcion de la actividad
	$enviar .= "<h3>".$vars['entity']->title."</h3>";
	$enviar .= $vars['entity']->description;
	$enviar .= "<br><br>";
	$enviar .= "<h3>".elgg_echo('actividad:envio')."</h3>";
	$enviar .= "<br>";
	
	$cabecera = "<div class='calificacion'><p><center><table id='selectable'><tr><td id='cabecera'>".elgg_echo('actividad:user')."</td><td id='cabecera'><center>".elgg_echo('actividad:group')."</center></td><td id='cabecera'><center>".elgg_echo('actividad:calificacion')."</center></td><td id='cabecera'><center>".elgg_echo('actividad:peso')."</center></td><td id='cabecera'><center>".elgg_echo('actividad:visibilidad')."</center></td></tr>";
	
	$t = 0;
	$final = 0;		
	$i = 1;
	
	$evaluaciones = false;
	
	// Recorrer totos los envios
	if (is_array($envios) || $envios != "")	
	{
		foreach ( $envios as $env )
		{
			$evaluaciones = true;
			
			$e = get_entity($env);
			
			// Grupo o individual		
			if ( $vars['entity']->grupo == 'si' )
			{
				$g = get_entity($e->grupo);
				$grupo = $g->name;
			}
			else
				$grupo = 'Individual';

			// Ver si hay notas		
			if ( $c = get_assessment( $e->guid) )
			{
				$nota = mostrar_nota($c->guid);
				$peso = $c->peso;
				if ( $c->visible == 'true' )
					$v = "<img title='Editar' src=\"". $vars['url']."mod/actividad/graphics/tick.gif\"/>";
				else							
					$v = "<img src=\"". $vars['url']."mod/actividad/graphics/cross.gif\" />";				
			}		
			else
			{
				$nota = elgg_echo('actividad:nograde');
				$peso = '1';
				$v = "<img src=\"". $vars['url']."mod/actividad/graphics/cross.gif\" />";	
			}				
									
			$alumno = get_user($e->owner_guid);

			$tabla .= "<tr><td><a href='".$vars['url']."mod/actividad/pages/evaluar.php?act=".$vars['entity']->guid."&user=".$alumno->guid."'>".$alumno->name."</a></td><td>".$grupo."</td><td>".$nota."</td><td>".$peso."</td><td><center>".$v."</center></td></tr>";
			$i++;
						
			if ($c != '0')
			{
				$final += $c->porcentaje * $peso;
				$t += $peso;
			}	
			
		}// Foreach		
		
		$enviar .= $cabecera . $tabla . "<tr><td id='total'>Total</td><td id='total'>".elgg_echo('actividad:iag')."</td><td id='total'>".number_format($final/$t,2) . " / 100</td><td id='total'></td><td id='total'></td></tr>";	
		$enviar .= "</table></center></p></div>";	
		$enviar .= elgg_view('input/securitytoken');       
					
	} // If	
	else
		$enviar .= "No existen envíos para la actividad <b>". $vars['entity']->title;		
	
	// Twittear si hay evaluaciones
	if ($evaluaciones)
	{
		if (is_plugin_enabled("twitterservice"))
		{
			$enviar .= "<BR>";
			$enviar .= "<center><fieldset class='send_twitter'>";
			$enviar .= "<form name='validar' action='".$vars['url']."action/actividad/twittear' method='post'>";
			$enviar .= "<textarea id='testTextarea' name='texto' cols='40' rows='4'>".$vars['entity']->title.": ".elgg_echo('actividad:publicartwitter')." (@via ".$vars['config']->sitename.")</textarea>";
			$enviar .= "<input type='hidden' id='actividad' name='actividad' value='".$vars['entity']->guid."'>";
			$enviar .= elgg_view('input/securitytoken');     
			$enviar .= "<p id='twitter_p'><input type='submit' id='text' value='".elgg_echo('actividad:publicar')."' name='send' title='".elgg_echo('actividad:publicar')."'></p></form>";
			$enviar .= "</fieldset></center>";
		}
		else
			$enviar .= "<div id='pt' style='background:#F08080; border:1px solid #FF0000; padding: 5px'><center>".elgg_echo('actividad:twitter_service'). "</center></div>";
	}
	
	$enviar .= "</div>";
	
	// Boton volver
	$enviar .= "<form name='validar' action='".$vars['url']."mod/actividad/pages/calificar_actividades.php' method='post'>";
	$enviar .= "<center><p><input type='submit' value='".elgg_echo('actividad:back')."' name='volver' title='".elgg_echo('actividad:back')."'></p></center></form>";
	
	echo $enviar;

?>