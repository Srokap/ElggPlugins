<?php

	/**
	 * Elgg actividad/crear page
	 *
	 * @package ElggActivity
	 */
	 
?>
  
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/actividad/views/default/js/scripts.js"></script>	

<?php

	echo "<form name='val' action='". $vars['url'] ."action/actividad/guardar' method='post' id='v'>";
	echo "<div class='actividad_form'>";
	echo "<form name='validar' action='confirm.php' method='post'>";
	
	echo "<BR>";
	echo "<h4>". elgg_echo('actividad:nombre') . "</h4>";
	echo "<BR>";
	echo elgg_view('input/text',array('internalname' => 'nombre', 'internalid'=>'nombre'));
	echo "<BR><BR>";
	echo "<h4>". elgg_echo('actividad:descripcion') . "</h4>";
	echo "<BR>";
	//echo elgg_view('input/longtext',array('internalname' => 'descripcion', 'internalid'=>'descripcion'));
	echo "<textarea name='descripcion' rows='10' cols='60' id='descripcion'></textarea>";
	echo "<BR><BR>";
	echo "<h4>". elgg_echo('actividad:fechainicial') . "</h4>";
	echo "<BR>";
	echo elgg_view('input/calendar',array('internalname' => 'fechaini', 'internalid'=>'fechaini'));
	echo "<BR><BR>";
	echo "<h4>". elgg_echo('actividad:fechafin') . "</h4>";
	echo "<BR>";
	echo elgg_view('input/calendar',array('internalname' => 'fechafin', 'internalid'=>'fechafin'));
	echo "<BR><BR>";
	
	// Tipo de evaluación
	echo elgg_view('rubricas/calificar/seleccionar_evaluacion');
	
	// Para grupos
	echo "<h4>". elgg_echo('actividad:grupos') . "</h4>";
	echo "<BR>";
	echo "<input type = 'checkbox' name='grupos' value='si'>".elgg_echo('actividad:groupactivity');
	echo "<BR><BR>";
	
	// Tipo de envio
	echo "<h4>". elgg_echo('actividad:tipoenv') . "</h4>";
	echo "<BR>";
	echo "<input type='radio' name='tipoenvio' value='texto'>".elgg_echo('actividad:solotexto');
	echo "<BR>";
	echo "<input type='radio' name='tipoenvio' value='adjunto'>".elgg_echo('actividad:soloadjunto');
	echo "<BR>";
	echo "<input type='radio' name='tipoenvio' value='ambos'>".elgg_echo('actividad:ambos');
	echo "<BR><BR>";	
	
	// Acceso de la actividad y de los envios
	$access_input = elgg_view('input/access', array('internalname' => 'access_id', 'value' => $access_id));
	echo "<h4>". elgg_echo('actividad:acceso') . "</h4>";
	echo "<BR>";
	echo $access_input;
	echo "<BR><BR>";
	echo "<h4>". elgg_echo('actividad:accesoenv') . "</h4>";
	echo "<BR>";
	echo "<input type = 'checkbox' name='accesoenvio' value='privado' checked>".elgg_echo('actividad:onlyowner');
	echo "<BR><BR>";
	
	echo "<center><input type='button' class='boton' value='". elgg_echo('actividad:enviar') ."' title='". elgg_echo('actividad:enviar') ."' onclick='valida()'></center>";

	echo elgg_view('input/securitytoken');

	echo "</form>";
	echo "</div>";
	echo "</form>";

?>