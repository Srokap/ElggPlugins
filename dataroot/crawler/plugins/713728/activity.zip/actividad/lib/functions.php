<?php
/*
* Funciones útiles para crear formularios de actividades
*
* @package ElggActivity
*/


// Incluir el motor de Elgg
include_once dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php"; 

/*
* Permite visuzalir los envíos de una actividad
*/
		function visualizar_envios( $actividad, $privacidad, $url )
		{
			global $CONFIG;

			$envios = get_entities("object", "envio", 0, "", 100);  
		
			if ($envios != "")
			{
			
			// Solo podemos ver nuestros envios 
			// si el acceso de los envios es privado
			// Y no es un administrador
			if ($privacidad == 'privado' & !get_loggedin_user()->isAdmin())
			{		
				foreach ($envios as $e)
				{
					// Si el envio pertenece a esa actividad
					if ($e->actividad == $actividad)
					{
						if (($e->getOwner() == get_loggedin_user()->getguid()) || (is_group_member($e->grupo, get_loggedin_userid())))
						{				
							// Datos/icono del propietario del envio
							$propietario = get_entity($e->getOwner());		
							if ($propietario != "")
							{	
								$toRet .= "<div class='actividad_view'>";
								$toRet .= "<div class=\"generic_comment_icon\">";
								$toRet .= elgg_view("profile/icon", array('entity' => $propietario,'size' => 'small'));
								$toRet .= "</div><div class=\"generic_comment_details\">";
								// Imagen archivo adjunto
								if ($e->title != "")
								{
									$toRet .= "<img src=\"{$url}mod/actividad/graphics/clip.png?\" border=\"0\" width='20' height='20' />";
									$toRet .= "<a href=\"". $url ."mod/actividad/views/default/actividad/download.php?envio=". $e->guid ."\">$e->title</a>";

								}
								if ($e->description != '')
									// Mostrar la descripcion
									$toRet .= elgg_view("output/longtext",array("value" => $e->description));
													
								$toRet .= "<p class=\"generic_comment_owner\">";
								$toRet .= "<a href={$propietario->getURL()}>{$propietario->name}</a> ";
								$toRet .= elgg_view_friendly_time($e->time_created);
								$toRet .= "</p>";
								// Mostrar boton de borrar
								if (get_loggedin_user()->isAdmin()) 
								{
									$toRet .= "<p>";
									$toRet .= elgg_view("output/confirmlinkimg", array(
											'href' => $url . "action/actividad/borrar_envio?envio=". $e->guid,
											'title' => 'Delete',
											'img' => $url . "mod/actividad/graphics/borrar.png",
											'confirm' => elgg_echo('deleteconfirm'),
										));
									$toRet .= "</p>";
								} //end of can edit if statement
																		
								$toRet .= "</div>";
								$toRet .= "</div>";

							}
						}
					} // End if
				} // END foreach
		
			} // END IF		
							
			// Si son publicos podemos ver el de todos (o si es el administrador)
			else
			{		
				foreach ($envios as $e)
				{		
					// Si el envio pertenece a esa actividad
					if ($e->actividad == $actividad)
					{			
						// Datos/icono del propietario del envio
						$propietario = get_entity($e->getOwner());

						if ($propietario != "")
						{
							$toRet .= "<div class='actividad_view'>";
							$toRet .= "<div class=\"generic_comment_icon\">";
							$toRet .= elgg_view("profile/icon", array('entity' => $propietario,'size' => 'small'));
							$toRet .= "</div><div class=\"generic_comment_details\">";
							// Imagen archivo adjunto
							if ($e->title != "")
							{
								$toRet .= "<img src=\"{$url}mod/actividad/graphics/clip.png?\" border=\"0\" width='20' height='20' />";
								$toRet .= "<a href=\"". $url ."mod/actividad/views/default/actividad/download.php?envio=". $e->guid ."\">$e->title</a>";
							}
							if ($e->description != '')
								$toRet .= elgg_view("output/longtext",array("value" => $e->description));
											
							$toRet .= "<p class=\"generic_comment_owner\">";
							$toRet .= "<a href={$propietario->getURL()}>{$propietario->name}</a> ";
							$toRet .= elgg_view_friendly_time($e->time_created);
							$toRet .= "</p>";
							// Si el usuario es administrador se muestran los mensajes de borrar
							if (get_loggedin_user()->isAdmin()) 
							{
								$toRet .= "<p>";
								$toRet .= elgg_view("output/confirmlinkimg", array(
									'href' => $url . "action/actividad/borrar_envio?envio=". $e->guid,
									'title' => 'Delete',
									'img' => $url . "mod/actividad/graphics/borrar.png",
									'confirm' => elgg_echo('deleteconfirm'),
								));
								$toRet .= "</p>";
							} 
																
							$toRet .= "</div>";
							$toRet .= "</div>";
						} 
					}
				} // END foreach
				
			} // END else
		} // END if (Envios)
		else
			$toRet = "<div class='actividad_view'>No existen Envios</div>";

		return $toRet;
		
		}

	/*
	* Formulario de envío
	*/
	function envios_form($actividad, $grupo, $fin, $url, $tipoenvio)
	{
		
		// Solo se puede enviar una actividad
		// Si la fecha de hoy es menor o igual a la actual y si la actividad es de grupo y el usuario pertenece a alguno
		$actual = date(m." ".d." ".Y); 
		
		$grupos = get_users_membership (get_loggedin_userid());
		
		if ( f1_menor_f2($actual, $fin) ) 		
		{
			if (($grupo != 'si') || (($grupo == 'si') & ($grupos != "")))
			{
			
			$toRet .= "<script type=\"text/javascript\" src=\"".$url ."mod/actividad/views/default/js/scripts.js\"></script>";
			$toRet .= "<div class='actividad_view'>";
			$toRet .= "<form name=\"val\" action=\"{$url}action/actividad/guardarenvio\" method=\"post\" enctype=\"multipart/form-data\">";
			$toRet .= "<h3>";
			$toRet .=  elgg_echo('actividad:envios');
			$toRet .= "</h3><br>";
		
			if ( $tipoenvio != 'texto' )
			{
				// Subir un fichero
				$toRet .= elgg_view('input/file',array('internalname' => 'adjunto', 'internalid' => 'adjunto'));
				$toRet .= "<BR><BR>";
				
				// Nombre del fichero
				$toRet .=  elgg_echo('actividad:nombrefichero');
				$toRet .= "<br>";
				$toRet .= elgg_view('input/text',array('internalname' => 'nombrefichero', 'internalid' => 'nombrefichero'));
				$toRet .= "<BR><BR>";
			}
			
			if ( $tipoenvio != 'adjunto' )
			{
				// Cuadro de texto
				$toRet .=  elgg_echo('actividad:texto');
				$toRet .= "<br>";
				//$toRet .= elgg_view('input/longtext',array('internalname' => 'descripcion', 'internalid'=>'descripcion'));
				$toRet .= "<textarea name='descripcion' rows='10' cols='60' id='descripcion'></textarea>";
				$toRet .= "<BR><BR>";
			}
			
			// Si es de grupos, mostrarlos
			if ($grupo == 'si')
			{
				$grupos = get_users_membership (get_loggedin_userid());
				if ($grupos != "")
				{
					$toRet .=  elgg_echo('actividad:seleccionargrupo');
					$toRet .= "<br><br>";				
					$toRet .= "<select name='grupo'>";
					foreach ($grupos as $g)
					{
						$toRet .= "<option value='".$g->guid."'>".$g->name."</option>";
					}
					$toRet .= "</select>";
					$toRet .= "<BR><BR>";
				}
			}

			$toRet .= elgg_view('input/hidden',array('internalname' => 'actividad', 'value'=>$actividad));
			$toRet .= "<input type=\"button\" class='boton' value=\"".elgg_echo('rubricas:enviar') ."\" onclick=\"valida_envio()\" title='enviar'>";
			$toRet .= elgg_view('input/securitytoken');
			$toRet .= "</form>";
			$toRet .= "</div>";
			
			}
			else
			{
				$toRet = "<div class='actividad_view'>";
				$toRet .= "Actividad en grupo: Es necesario apuntarse a un grupo para poder enviar una actividad";
				$toRet .= "</div>";				
			}
				
		} // IF
		else 
		{
			$toRet = "<div class='actividad_view'>";
			$toRet .= "No se pueden enviar mas actividades";
			$toRet .= "</div>";
		}
		
		return $toRet;
	}

	/*
	* Devuelve el número de envíos para una actividad
	*/	
	function num_envios($actividad)
	{
		$envios = get_entities("object", "envio", 0, "", 100); 
		$num = 0;
		foreach ($envios as $e)
		{
			if ($e->actividad == $actividad)
				$num++;
		}
		return $num;
	}

/* 
* function coger_envios_por_actividad
* @param guid de la actividad
* @return array con los guids de los envíos
*/	
function coger_envios_por_actividad( $actividad )
{
	global $CONFIG;
	
	$query = "SELECT guid, name, username FROM {$CONFIG->dbprefix}users_entity";
	$alumnos = get_data($query);

	$i = 0;
	foreach ($alumnos as $a)
	{
		$envios = elgg_get_entities(array("type"=>"object", "subtype"=>"envio", "owner_guid" => $a->guid));  

		if (is_array($envios) || $envios != "")	
		{

			foreach ($envios as $e)
			{

				if ( $actividad == $e->actividad )		
					$toRet[] = $e->guid;
			}
		}
	}
	return $toRet;
}

/* 
* function coger_envios_por_usuario
* @param guid del usuario
* @return array con los guids de los envíos
*/	
function coger_envios_por_usuario( $usuario )
{
	$actividades = elgg_get_entities(array("type"=>"object", "subtypes"=>"actividad"));  

	foreach ($actividades as $a)
	{
		$envios = get_entities("object", "envio", 0, "", 100);

		if (is_array($envios) || $envios != "")	
		{
			foreach ($envios as $e)
			{
				if ($e->actividad == $a->guid)
				{		
					if (($usuario == $e->owner_guid) | (is_group_member($e->grupo, $usuario)))

						$toRet[] = $e->guid;
				}
			}
		}
	}
	return $toRet;					
}

/* 
* function coger_envios_por_grupo
* @param guid del grupo
* @return array con los guids de los envíos
*/	
function coger_envios_por_grupo( $grupo )
{
	$actividades = elgg_get_entities(array("type"=>"object", "subtypes"=>"actividad"));  

	foreach ($actividades as $a)
	{
		$envios = get_entities("object", "envio", 0, "", 100);

		if (is_array($envios) || $envios != "")	
		{
			foreach ($envios as $e)
			{
				if (($e->actividad == $a->guid) & ($e->grupo == $grupo))
				{		
						$toRet[] = $e->guid;
				}
			}
		}
	}
	return $toRet;					
}

/* 
* Function esta_en
* Busca una ocurrencia de aguja en el indice del array $pajar->value
*/
function esta_en($aguja, $pajar)
{
	if (count($pajar) == 1)
	{
		if ($pajar->value == $aguja)
			return true;
		else 
			return false;
	}
	else
	{
		foreach ($pajar as $p)
		{
			if ($p->value == $aguja)
				return true;
		}
		return false;
	}
}

/* 
* Compara dos fechas
*/
function f1_menor_f2($fecha1, $fecha2)
{
	// Fecha1 -> formato m." ".d." ".Y
	list($mes, $dia, $ano) = explode (" ", $fecha1);
	list($mes2, $dia2, $ano2) = explode (" ", $fecha2);
	$dia2 = substr ($dia2, 0, strlen($dia2) - 1);
	$mes2 = determinarmes($mes2);
	if (strlen($dia2) == 1)
		$dia2 = "0".$dia2;
	if (strlen($dia) == 1)
		$dia = "0".$dia;	
		
	$f1 = $ano.$mes.$dia;
	$f2 = $ano2.$mes2.$dia2;

	if ($f1 <= $f2)
		return true;
	else return false;				
}

/* 
* Devuelve el mes en forma numérica
*/
function determinarmes($mes)
{
	
	switch ($mes) 
	{
		case "January":
			return "01";
		case "February":
			return "02";
		case "March":
			return "03";
		case "April":
			return "04";
		case "May":
			return "05";
		case "June":
			return "06";
		case "July":
			return "07";
		case "August":
			return "08";
		case "September":
			return "09";
		case "October":
			return "10";
		case "November":
			return "11";
		case "December":
			return "12";
	}
		
		return "0";
}

?>