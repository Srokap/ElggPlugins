<?php
/**
 * actividad
 *
 * @author josune
 */

/**********************************
*                INICIALIZACIÓN
**********************************/

function actividad_init() 
{
	
	global $CONFIG;

	if (is_plugin_enabled("rubricas"))
	{
		elgg_extend_view('css','actividad/css');
		elgg_extend_view('css','actividad/jquery-ui');
	
	    // Añadir al "Dashboard"
		add_widget_type('actividad', elgg_echo('actividad:actividad'), elgg_echo('actividad:widget:description'));
		
		// Añadir el menu del administrador
	    if (isadminloggedin()) 
	    {
	    	// Controladores de páginas
			register_page_handler('actividad','actividad_page_handler');
	
	    	// Menú administrador
			add_menu(elgg_echo('actividad:actividad'), $CONFIG->wwwroot . 'pg/actividad/ver');
	
			// Menú calificaciones
			add_menu(elgg_echo('actividad:calificaciones'), $CONFIG->wwwroot . 'pg/actividad/calificaciones');
			
			// Menú evaluar
			add_menu(elgg_echo('actividad:calificar'), $CONFIG->wwwroot . 'pg/actividad/calificar');
			
	    	// Controlador de páginas del menú
			register_elgg_event_handler('pagesetup','system','actividad_submenus');
			
	    }
	    
	    else 
	    {
	    	
	    	// Controladores de páginas
			register_page_handler('actividad','actividad_page_handler');
	
	    	// Menú usuario
			add_menu(elgg_echo('actividad:actividad'), $CONFIG->wwwroot . 'pg/actividad/ver');
	
	    	// Controlador de páginas del menú
			register_elgg_event_handler('pagesetup','system','actividad_submenus_usuario');
	    }   		
	
	    // Registrar acciones del sistema
		register_action('actividad/guardar', false, $CONFIG->pluginspath .'actividad/actions/guardar.php');
		register_action('actividad/editar', false, $CONFIG->pluginspath .'actividad/actions/editar.php');
		register_action('actividad/guardarenvio', false, $CONFIG->pluginspath .'actividad/actions/guardarenvio.php');
		register_action('actividad/borrar', false, $CONFIG->pluginspath .'actividad/actions/borrar.php');
		register_action('actividad/borrar_envio', false, $CONFIG->pluginspath .'actividad/actions/borrar_envio.php');
		register_action('actividad/calificar', false, $CONFIG->pluginspath .'actividad/actions/calificar.php');
		register_action('actividad/twittear', false, $CONFIG->pluginspath .'actividad/actions/twittear.php');
		
		// Acceso a twitter
		register_plugin_hook('plugin_list', 'twitter_service', 'actividad_twitter_integration');
	}
	else
	{
		register_error("[Actividad] ERROR: El plugin de rubricas debe estar activado");	
		disable_plugin("actividad");
	}
}

/********************************************
*                CONTROLADOR DE PÁGINAS
********************************************/

function actividad_page_handler($page) 
{
	global $CONFIG;

	switch ($page[0])
	{
		case 'crear':
			include $CONFIG->pluginspath . 'actividad/pages/crear.php';
			break;
		case 'editar':
			include $CONFIG->pluginspath . 'actividad/pages/editar.php';
			break;
		case 'calificar':
			include $CONFIG->pluginspath . 'actividad/pages/calificar.php';
			break;
		case 'ver':
			include $CONFIG->pluginspath . 'actividad/pages/ver.php';
			break;
		case 'calificaciones':
			include $CONFIG->pluginspath . 'actividad/pages/calificaciones.php';
			break;
		case 'calificaciones_usuario':
			include $CONFIG->pluginspath . 'actividad/pages/calificaciones_usuario.php';
			break;
	}

	return TRUE;
}

function actividad_page_handler_usuario($page) 
{
	global $CONFIG;

	switch ($page[0])
	{
		case 'ver':
			include $CONFIG->pluginspath . 'actividad/pages/ver.php';
			break;
		case 'calificaciones_usuario':
			include $CONFIG->pluginspath . 'actividad/pages/calificaciones_usuario.php';
			break;
	}

	return TRUE;
}

/**********************************
*                SUBMENÚS
**********************************/

function actividad_submenus() 
{
	global $CONFIG;

	if (get_context() == 'actividad') 
	{
		add_submenu_item(elgg_echo('actividad:crear'), $CONFIG->wwwroot . 'pg/actividad/crear/');
		add_submenu_item(elgg_echo('actividad:calificar'), $CONFIG->wwwroot . 'pg/actividad/calificar/');
		add_submenu_item(elgg_echo('actividad:ver'), $CONFIG->wwwroot . 'pg/actividad/ver/');
		add_submenu_item(elgg_echo('actividad:calificaciones'), $CONFIG->wwwroot . 'pg/actividad/calificaciones/');
	}
}

function actividad_submenus_usuario() 
{
	global $CONFIG;

	if (get_context() == 'actividad') 
	{
		add_submenu_item(elgg_echo('actividad:ver'), $CONFIG->wwwroot . 'pg/actividad/ver/');
		add_submenu_item(elgg_echo('actividad:calificaciones'), $CONFIG->wwwroot . 'pg/actividad/calificaciones_usuario/');
	}
}

// Twitter
function actividad_twitter_integration($hook, $type, $value, $params) 
{
	$value['actividad'] = array(
			'name' => elgg_echo('actividad:actividad'),
			'description' => elgg_echo('actividad:twitter') 
			);
			
	return $value;
}

/**********************************
*                CONTROLADOR
*
*     Lanza la función de inicialización
**********************************/	

register_elgg_event_handler('init', 'system', 'actividad_init');

?>