<?php

	/**
	 * Elgg actividad/actions/editar
	 *
	* @package ElggActivity
	 */
	 
	 
  // Solo usuarios registrados pueden almacenar una actividad
  gatekeeper();
  
// Parámetros
$guid = (int) get_input('actividad');

$titulo = $_POST[nombre];
$descripcion = $_POST[descripcion];
$fechaini = $_POST[fechaini];
$fechafin = $_POST[fechafin];
$rubrica = $_POST[rubrica];
$tipoenvio = $_POST[tipoenvio];

// Acceso
$acceso = $_POST[access_id];
$accesoenv = $_POST[accesoenvio];

// Cargar la actividad existente
if ( $actividad = get_entity($guid)) 
{
  $actividad->title = $titulo;
  $actividad->description = $descripcion;
  $actividad->subtype = "actividad";
  
 // Se hace publica
  $actividad->access_id = $acceso;

  // El propietario es el usuario registrado
  $actividad->owner_guid = get_loggedin_userid();

  // Almacenar la actividad antes de almacenar sus metadatos
  if (!$actividad->save()) 
  {
        register_error(elgg_echo("Error al salvar la actividad"));
        forward("mod/actividad/views/default/actividad/edit.php?actividad=" . $guid);
  }
  // Limpiar metadatos
  $actividad->clearMetadata('fechaini');
  $actividad->clearMetadata('fechafin');
  $actividad->clearMetadata('rubrica');
  $actividad->clearMetadata('accesoenv');  
  $actividad->clearMetadata('grupo');  
  
  // Se almacenan valores como metadatos
  $actividad->inicio = $fechaini;
  $actividad->fin = $fechafin;
  
  // GUID de la rubrica
  if ($_POST[tipoevaluacion] == 'numerica')	
  	  $actividad->rubrica = 0;
  else
  	$actividad->rubrica = $rubrica;
  	
 // Tipo del envio
 $actividad->tipoenvio = $tipoenvio;

  $actividad->accesoenv = $accesoenv;
  $actividad->grupo = $_POST[grupos];
  
 // Mensaje de exito
system_message(elgg_echo("actividad:success"));

  // Redireccionar al usuario al listado de actividades
  forward($CONFIG->wwwroot . 'pg/actividad/ver/');
}

else {
	register_error(elgg_echo('actividad::failure'));
  // Redireccionar al usuario al listado de actividades
  forward($CONFIG->wwwroot . 'pg/actividad/ver/');
}
?>