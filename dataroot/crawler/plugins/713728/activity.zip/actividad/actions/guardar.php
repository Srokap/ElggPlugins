<?php

	/**
	 * Elgg actividad/actions/guardar page
	 *
	* @package ElggActivity
	 */
	 
	 
  // Solo usuarios registrados pueden almacenar una actividad
  gatekeeper();

// Parámetros de entrada
$titulo = $_POST[nombre];
$descripcion = $_POST[descripcion];
$fechaini = $_POST[fechaini];
$fechafin = $_POST[fechafin];
$rubrica = $_POST[rubrica];
$tipoenvio = $_POST[tipoenvio];

// Acceso
$acceso = $_POST[access_id];
$accesoenv = $_POST[accesoenvio];

// Crear un nuevo objeto
$actividad = new ElggObject();
$actividad->title = $titulo;
$actividad->description = $descripcion;
$actividad->subtype = "actividad";
  
// Se almacenan valores como metadatos
$actividad->inicio = $fechaini;
$actividad->fin = $fechafin;
  
// Guarda el guid de la rúbrica
if ($_POST[tipoevaluacion] == 'numerica')	
  	  $actividad->rubrica = 0;
else
  	$actividad->rubrica = $rubrica;

$actividad->accesoenv = $accesoenv;
// Grupos
$actividad->grupo = $_POST[grupos];

// Tipo del envio
$actividad->tipoenvio = $tipoenvio;

// Se hace publica
$actividad->access_id = $acceso;

// El propietario es el usuario registrado
$actividad->owner_guid = get_loggedin_userid();
  
// Guardar en la BD
if ($actividad->save()) 
{
  	system_message(elgg_echo("actividad:success"));
  	
  	$params = array(
				// Enviar a twitter
				'plugin' => 'actividad',
				'message' => 'Se ha creado una nueva actividad "' . $actividad->title . ' " ',
			);
	echo trigger_plugin_hook("tweet", "twitter_services", $params);
  }
  else 
  {
	register_error(elgg_echo('actividad::failure'));
	forward();
  }

  // Redireccionar al usuario al listado de actividades
  forward($CONFIG->wwwroot . 'pg/actividad/ver/');

?>