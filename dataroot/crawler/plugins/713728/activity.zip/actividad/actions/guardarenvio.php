<?php

	/**
	 * Elgg actividad/actions/guardarenvio page
	 *
	 * @package ElggActivity	
	 */
	  
  	// Solo usuarios registrados pueden almacenar una actividad
  	gatekeeper();

	// Coger parámetros
	$param = get_input('param');
	
	$adjunto = $_POST[adjunto];
	$descripcion = $_POST[descripcion];
	$actividad = $_POST[actividad];
	$nombre = $_POST[nombrefichero];
	
	$act = get_entity($actividad);
	
	// Buscar si el usuario ya envió algo 
	$envios = get_entities("object", "envio");
	
	foreach ($envios as $e)
	{
		if (($e->getOwner() == get_loggedin_user()->getguid()) & ($e->actividad == $act->guid))
		{
			$f = get_entity($e->fichero);
			if ($f != "")
				$f->delete();
			$e->delete();
			break;
		}
	}	
	
	$envio = new ElggObject();
	
	//	Guardar el fichero, nombre y texto
	$envio->subtype = "envio";
	$envio->title = $nombre;
	$envio->description = $descripcion;
	$envio->actividad = $act->guid;
	
	// Fichero 
	if ($nombre != "")
	{
		$file = new ElggFile();
		$file->setFilename($_FILES['adjunto']['name']);
		$file->setMimeType($_FILES['adjunto']['type']);
		$file->open("write");
		$file->write(get_uploaded_file('adjunto'));
		$file->close();
		$file->save();
		$envio->fichero = $file->guid;
	}
	
	$envio->access_id = ACCESS_PUBLIC;
	$envio->time_created = time();
	
	if ($_POST[grupo] != "")
		$envio->grupo = $_POST[grupo];
		
	$envio->owner_guid = get_loggedin_userid();
	
	if ($envio->save())
		system_message(elgg_echo("Se ha almacenado el envio"));
	else
		system_message(elgg_echo("Error"));
		
	// Redireccionar al usuario al listado de actividades
	$url = $act->getURL()."?search_viewtype=gallery";
	forward($url);

?>