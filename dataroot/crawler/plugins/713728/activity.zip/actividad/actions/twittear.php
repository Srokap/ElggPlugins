<?php

/*
* actividad/actions/twittear
*
* @package ElggActivity
*/

    // Solo usuarios registrados
    gatekeeper();

    // Get input data
    $texto = get_input('texto');
	$actividad = get_input('actividad');

	// tweet
	$params = array(
			'plugin' => 'actividad',
			'message' => $texto
		);				
				
    if (trigger_plugin_hook('tweet', 'twitter_service', $params))
	{
      	// Mensaje de exito
        system_message(elgg_echo('actividad::twitterok'));
               
     } 
     else 
     {
      		register_error(elgg_echo('actividad::failure'));
     }
      
      // Redirigir al listado de actividades
      forward($CONFIG->wwwroot . 'mod/actividad/pages/calificar_actividad.php?actividad=' . $actividad);

