<?php

/*
* actividad/actions/borrar
*
* @package ElggActivity
*/

      // Solo usuarios registrados
      gatekeeper();

      // Datos de entrada
      $guid = (int) get_input('actividad');

      // Si es una actividad
      $act = get_entity($guid);
      if ($act->getSubtype() == "actividad" ) 
      {
      		// Coger el propietario
            $owner = get_entity($act->getOwner());
      		// Borrar
            $rowsaffected = $act->delete();
            if ($rowsaffected > 0) 
            {
      			// Mensaje de exito
               system_message(elgg_echo("La actividad se ha eliminado"));
               
      		} 
      		else 
      		{    			
               register_error(elgg_echo('actividad::failure'));
      		}
      
      		// Redirigir al listado de actividades
      		forward($CONFIG->wwwroot . 'pg/actividad/ver/');
      }

?>