<?php

/*
* actividad/actions/borrar
*
* @package ElggActivity
*/

      // Solo usuarios registrados
      gatekeeper();

      // Datos de entrada
      $guid = (int) get_input('envio');

      // Si es una actividad
      $env = get_entity($guid);
      if ($env->getSubtype() == "envio" ) 
      {
      		// Coger el propietario
            $owner = get_entity($env->getOwner());
            
            // Borrar el fichero asociado, si existe
            if ($fichero = get_entity($env->fichero))
            {
            	$fichero->delete();
            }
            
      		// Borrar
            $rowsaffected = $env->delete();
            if ($rowsaffected > 0) 
            {
      			// Mensaje de exito
               system_message(elgg_echo("El envio se ha eliminado"));
               
      		} 
      		else 
      		{    			
               register_error(elgg_echo('actividad::failure'));
      		}
      
      		// Redirigir al listado de actividades
      		forward($CONFIG->wwwroot . 'pg/actividad/ver/');
      }

?>