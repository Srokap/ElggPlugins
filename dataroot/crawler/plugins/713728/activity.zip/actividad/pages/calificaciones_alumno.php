<?php
/*
* actividad/pages/calificaciones_usuario
* Muestra un listado de calificaciones de un usuario
*
* @package ElggActivity
*/

	// Incluye el motor de Elgg
	include_once dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php"; 
	
	// Sólo usuarios registrados
	admin_gatekeeper();
	
	// Establecer al propietario de la página
	$page_owner = page_owner_entity();
	if (!$page_owner) 
	{
		$page_owner_guid = get_loggedin_userid();
		if ($page_owner_guid)
			set_page_owner($page_owner_guid);
	}	
	
	$title = elgg_echo('actividad:calificaciones');
	
	// Coge la actividad pasada como parametro, si existe
	$user = (int) get_input('user');
	$usuario = get_entity($user);
	
	// Crea el contenido principal
	$content = elgg_view_title($title);
	$content .= elgg_view("actividad/calificaciones_alumno", array('entity' => $usuario));
	
	// Crea las columnas
	$body = elgg_view_layout('two_column_left_sidebar', '', $content);
	
	// Envía la página
	page_draw($title, $body);

?>