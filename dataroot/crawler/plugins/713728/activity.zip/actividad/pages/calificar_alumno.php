<?php
/*
* actividad/pages/calificar_alumno
* Muestra el listado de actividades realizadas por un alumno pasado como parámetro
*
* @package ElggActivity
*/

	// Incluye el motor de Elgg
	include_once dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php"; 
	
	// Sólo administradores
	gatekeeper();
	
	// Establece al actual propietario de la página
	$page_owner = page_owner_entity();
	if (!$page_owner) 
	{
		$page_owner_guid = get_loggedin_userid();
		if ($page_owner_guid)
			set_page_owner($page_owner_guid);
	}	
	
	$title = elgg_echo('actividad:pagetitlecalificar');
	
	// Coge la actividad pasada como parametro, si existe
	$user = (int) get_input('user');
	$usuario = get_entity($user);

	// Crea al contenido de la columna principal
	$content = elgg_view_title($title);
	$content .= elgg_view("actividad/calificar_alumno", array('entity' => $usuario));
	
	// Contenido de la columna principal
	$body = elgg_view_layout('two_column_left_sidebar', '', $content);
	
	// Crea la página html con los datos pasados como parámetro
	page_draw($title, $body);

?>