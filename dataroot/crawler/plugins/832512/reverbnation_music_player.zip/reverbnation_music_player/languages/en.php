<?php

$english = array(
	'rnmpwidget:widget' => 'ReverbNation Music Player',
	'rnmpwidget:description' => 'Add a ReverbNation Music Player to your profile',
	'rnmpwidget:artist_id' => 'Artist ID',
);

add_translation("en", $english);

