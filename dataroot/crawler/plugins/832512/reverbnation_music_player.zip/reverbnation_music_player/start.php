<?php
/**
 * ReverbNation Music Player Widget
 *
 * Add the ReverbNation Music Player to your Profile page.
 */

elgg_register_event_handler('init', 'system', 'reverbnation_music_widget_init');       

function reverbnation_music_widget_init() {        
    elgg_register_widget_type(
			'rnmwidget',
			elgg_echo('rnmpwidget:widget'),
			elgg_echo('rnmpwidget:description')
			);
}
 
?>
