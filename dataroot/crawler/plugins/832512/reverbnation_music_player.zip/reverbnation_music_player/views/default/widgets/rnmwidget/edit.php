<?php
/**
 * ReverbNation Music Player widget settings
 */

$artistid_label = elgg_echo("rnmpwidget:artist_id");
$artistid_textbox = elgg_view('input/text', array(
	'name' => 'params[artistid]',
	'value' => $vars['entity']->artistid,
	'onclick' => 'this.select();',
));

echo <<<HTML

<p>
You can find your Artist ID at the top of the right hand column of your ReverbNation Control Panel.
</p>

<div>
	$artistid_label
	$artistid_textbox
</div>

<p>
If you are looking for another musician's Artist ID click Bio on their ReverbNation page. Their Artist ID will be the number following artist_ at the end of the link in your address bar.
</p>

HTML;


