<?php
$english = array(
	//Configuration form
	'poll_embedder:noid' 			=> 'Unrecognized url format'
);
add_translation("en",$english);