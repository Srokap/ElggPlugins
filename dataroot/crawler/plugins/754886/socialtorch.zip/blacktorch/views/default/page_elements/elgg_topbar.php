<?php
/**
 * Elgg top toolbar
 * The standard elgg top toolbar
 *
 * @package Elgg
 * @subpackage Core
 *
 */
?>

<?php
	if (isloggedin()) {
?>

<div id="elgg_topbar">

<div id="elgg_topbar_container_left">
	<div class="toolbarimages">
		

		

	</div>
	<div class="toolbarlinks">
		<a style="color:#01c3fe; font-size:20px; padding-top: 8px; font-weight:bold;" href="<?php echo $vars['url']; ?>pg/dashboard/" class="pagelinks"><?php echo elgg_echo('dashboard'); ?></a>
	</div>
		<?php

			echo elgg_view("navigation/topbar_tools");

		?>

		<div class="toolbarlinks2">
		<?php
		//allow people to extend this top menu
		echo elgg_view('elgg_topbar/extend', $vars);
		?>

		<a style="color:#79bd00; font-size:20px;  font-weight:bold;" href="<?php echo $vars['url']; ?>pg/settings/" class="usersettings"><?php echo elgg_echo('settings'); ?></a>

		<?php

			// The administration link is for admin or site admin users only
			if ($vars['user']->isAdmin()) {

		?>

			<a style="color:#d22020; font-size:20px; padding-top: 10px; font-weight:bold;" href="<?php echo $vars['url']; ?>pg/admin/" class="usersettings"><?php echo elgg_echo("admin"); ?></a>

		<?php

				}

		?><a style="color:orange; font-size:20px;  font-weight:bold; padding-top: 8px; padding-left:90px;" href="<?php echo get_loggedin_user()->getURL(); ?>">Profile</a>
	</div>


</div>


<div id="elgg_topbar_container_right">
		<small style="font-size:20px;  font-weight:bold;">
			<?php echo elgg_view('output/url', array('href' => "{$vars['url']}action/logout", 'text' => elgg_echo('logout'), 'is_action' => TRUE)); ?>
		</small>
</div>

<div id="elgg_topbar_container_search">
<?php echo elgg_view('page_elements/searchbox'); ?>
</div>

</div><!-- /#elgg_topbar -->

<div class="clearfloat"></div>

<?php
	}
