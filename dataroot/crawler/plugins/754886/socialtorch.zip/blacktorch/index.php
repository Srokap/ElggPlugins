<?php
if (isloggedin()) forward('pg/dashboard/');
?><!DOCTYPE html>
<html lang="en">
<head>
<title>Home</title>
<meta charset="utf-8">
<link rel="stylesheet" href="mod/blacktorch/css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="mod/blacktorch/css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="mod/blacktorch/css/style.css" type="text/css" media="all">
	<script type="text/javascript" src="mod/blacktorch/js/jquery-1.4.2.min.js"></script>

<script type="text/javascript" src="mod/blacktorch/js/Shanti_400.font.js"></script>
<script type="text/javascript" src="mod/blacktorch/js/Didact_Gothic_400.font.js"></script>
<script type="text/javascript" src="mod/blacktorch/js/jquery.jqtransform.js"></script>
 <!--[if lt IE 9]>
	<script type="text/javascript" src="mod/blacktorch/js/html5.js"></script>
	<style type="text/css">
		.button1 {behavior: url(js/PIE.htc)}
	</style>
<![endif]-->
<!--[if lt IE 7]>
	<div style=' clear: both; text-align:center; position: relative;'>
		<a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/images/upgrade.jpg" border="0" alt="" /></a>
	</div>
<![endif]-->
</head>

<script type="text/javascript">
$(document).ready(function () {
	$('.messages').animate({opacity: 1.0}, 1000);
	$('.messages').animate({opacity: 1.0}, 5000);
	$('.messages').fadeOut('slow');

	$('span.closeMessages a').click(function () {
		$(".messages").stop();
		$('.messages').fadeOut('slow');
	return false;
	});

	$('div.messages').click(function () {
		$(".messages").stop();
		$('.messages').fadeOut('slow');
	return false;
	});
});
</script>
<script type="text/javascript">
$(document).ready(function () {
	$('.messages_error').animate({opacity: 1.0}, 1000);
	$('.messages_error').animate({opacity: 1.0}, 5000);
	$('.messages_error').fadeOut('slow');

	$('span.closeMessages a').click(function () {
		$(".messages_error").stop();
		$('.messages_error').fadeOut('slow');
	return false;
	});

	$('div.messages').click(function () {
		$(".messages").stop();
		$('.messages').fadeOut('slow');
	return false;
	});
});
</script>
	
	

<?php $messages = system_messages();	
	$message = $messages['messages'];
	
	if(count($message) > 0){ 
		echo '<div class="messages">';
		echo '<span class="closeMessages"><a href="#">click to dismiss</a></span>';
			foreach($message as $message1)
					{
					echo '<p>';
					echo $message1;
					echo '</p>';
					}
		echo '</div>';
	}

	$errors = register_error();
	$error = $errors['errors'];
	if(count($error) > 0){ 
		echo '<div class="messages_error">';
		echo '<span class="closeMessages"><a href="#">click to dismiss</a></span>';
			foreach($error as $error1)
					{
					echo '<p>';
					echo $error1;
					echo '</p>';
					}
		echo '</div>';
	}


////////////////////////////////////////////////////////////////////////////////////////////////
?>
<body id="page1">
<div class="body1">
	<div class="body2">
		<div class="main">

				<div class="wrapper">
					<ul id="icons">
						<li><a href="<?php echo $vars['url']; ?>"><img src="mod/blacktorch/images/icon1.gif" alt=""></a></li>
						<li><a href="<?php echo $vars['url']; ?>pg/expages/read/Terms/"><img src="mod/blacktorch/images/icon2.gif" alt=""></a></li>
						<li><a href="<?php echo $vars['url']; ?>pg/expages/read/About/"><img src="mod/blacktorch/images/icon3.gif" alt=""></a></li>
						
					</ul><span class="call">Sign up now! <span>  <a style="color:#fff; text-decoration:none;" href="<?php echo $vars['url']; ?>pg/register/">Register here!</a></span></span>
					
	</div>
</div>
<div class="main">
<!-- content --><p>&nbsp; </p><p>&nbsp; </p><p>&nbsp; </p>
	<section id="content">
		<div class="line1">
			<div class="line2 wrapper">
				<article class="col1 pad_right1">
					<h2><strong class="color1">Login</strong><span></span></h2>
					<ul class="list1">
						<li>
	<?php
									$form_body = 
									"
										<p>
										<label>"
										.elgg_echo('username')
										."<br />"
										.elgg_view
										(
											'input/text'
											,array
											(
												'internalname' => 'username'
												,'class' => 'login-textarea'
											)
										)
										."</label><br />
									";
									$form_body .=
										"<label>"
										.elgg_echo('password')
										."<br />" 
										.elgg_view
										(
											'input/password'
											,array
											(
												'internalname' => 'password'
												,'class' => 'login-textarea'
											)
										)
										."</label><br />
									";
									$form_body .=
										elgg_view
										(
											 'input/submit'
											,array
											(
												'value' => elgg_echo('login')
											)
										)
										."</p>
									";
									echo elgg_view
									(
										'input/form'
										,array
										(
											 'body' => $form_body
											,'action' => ""
											.$vars['url']
											."action/login"
										)
									);
									?></li>
					</ul>
					
				</article>
				<article class="col1 pad_right1">
					<h2><strong class="color2">Members</strong><span></span></h2>
					<ul class="list1">
						<li><p>&nbsp; </p><?php
$users_max = 25;
        $onlyWithAvatar = "no";
if(empty($onlyWithAvatar) || $onlyWithAvatar == "no")
  {$users = get_entities('user','',null,null,$users_max,0);} 
else 
  {$users = get_entities_from_metadata('icontime', '', 'user', '', 0, $users_max);}
           $wallIconSize = "small";
shuffle($users);
foreach($users as $user){

echo elgg_view("profile/icon",array('entity' => $user, 'size' => 'small', 'override' => 'true'));

} ?><p>&nbsp; </p></li>
					</ul>
					
				</article>
				<article class="col1">
					<h2><strong>Groups</strong><span></span></h2>
					<ul class="list1">
						<li><p>&nbsp; </p><?php 
							
							
							     $groups = get_entities('group', '', 0, '', 25, 0, false, 0, null);
                if($groups){
                    foreach($groups as $group){
                          echo "<div class=\"member_icon\" style=\"padding-bottom:5px; \">" . elgg_view("profile/icon",array('entity' => $group, 'size' => 'small')) . " </div>";   
                    }
                }
							
							
							
							
							?>&nbsp;</li>
					</ul>
					
				</article>
			</div>
		</div>
	</section>
</div>
<div class="body3">
	<div class="main">
		<section id="content2">
			<div class="line2 wrapper">
				<article class="col2 pad_right1">
					<h3>Forgot your Password?</h3>
					<p class="pad_bot1">
						<strong class="color3"> <a style="color:#fff; text-decoration:none;" href="<?php echo $vars['url']; ?>account/forgotten_password.php"> Click here to reset it</a></strong><br>
						</p>
				</article>
				<article class="col1">
					<h3>Get Started!</h3>
					<p class="pad_bot1">
						<strong class="color3">Don't have an account yet?</strong><br>
						Sign up now!</p>
				</article>
			</div>
		</section>
<!-- / content  -->
	</div>
	<div style="padding-left:980px;"> <p>Designed by <a style="color:#fff; text-decoration:none;" href="http://www.swsocialweb.com">Social Web </a></p></div>
</div>
<div class="main">
<!-- / footer -->
	
<!-- / footer -->
</div>
<script type="text/javascript"> Cufon.now(); </script>
<script>
	jQuery(document).ready(function($) {
		$('#form_1').jqTransform({imgPath:'jqtransformplugin/img/'});	
	});
</script>
</body>
</html>