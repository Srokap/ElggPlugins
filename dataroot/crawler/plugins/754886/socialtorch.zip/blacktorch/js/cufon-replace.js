Cufon.replace('h2 strong', { fontFamily: 'Shanti', hover:true });
Cufon.replace('#slogan1', { fontFamily: 'Shanti', hover:true, textShadow:'rgba(0,0,0,.3) 1px 1px' });
Cufon.replace('.button_details a, .button1', { fontFamily: 'Shanti', hover:true, textShadow:'#fff 1px 1px' });
Cufon.replace('.call, #menu a, #slogan2, h2 span, h3, .list3', { fontFamily: 'Didact Gothic', hover:true });
