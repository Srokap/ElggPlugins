<?php

/*
 * english language file
 * 
 */
$english = array(
		
        'pab_theme:aboutus' => "About Us details",
        'pab_theme:facebook' => "Facebook page link",
        'pab_theme:twitter' => "Twitter account link",    
        'pab_theme:googleplus' => "Google Plus account link",        
	'pab_theme:cancel' => 'Cancel',
	'pab_theme:awaiting' => 'Not on profile',
	'pab_theme:pushed' => 'Ratings on profile',
        'pab_theme:mymess' => "My Messages",
        'pab_theme:mysets' => "My Settings",
        'pab_theme:myprof' => "My Profile",
        'pabtheme:mydashboard' => "My Dashboard",
        'pabtheme:myfriends' => "My Friends"
);
					
add_translation("en",$english);

