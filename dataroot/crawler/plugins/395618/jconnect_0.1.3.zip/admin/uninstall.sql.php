DROP TABLE IF EXISTS `#__jc_exApps`;
DROP TABLE IF EXISTS `#__jc_meta`;
DROP TABLE IF EXISTS `#__jc_syncUsers`;
DROP TABLE IF EXISTS `#__jc_externalUsers`;
DROP TABLE IF EXISTS `#__jc_groups_out`;
DROP TABLE IF EXISTS `#__jc_groups_in`; 
DROP TABLE IF EXISTS `#__jc_tokens`; 
