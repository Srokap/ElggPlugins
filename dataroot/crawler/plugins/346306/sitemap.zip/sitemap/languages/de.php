<?php

	/**
	 * Elgg Sitemap plugin
	 * 
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Matthias Sutter email@matthias-sutter.de
	 * @copyright CubeYoo.de
	 * @link http://cubeyoo.de
         * @ package modification 22-11-2009
         * @ author Carlos Luis Sánchez Bocanegra carlosl.sanchez@gmail.com
         * @ link http://redes.epesca.org
         * @ Modify: adding support for a better i18n givving all resource to a languages directory.
         */

	$german = array(
         	 'sitemap'  =>  "Sitemap" ,
		 'sitemap:start' => "",	
                 'itemap:about' => "",
                 'sitemap:terms' => "",
                 'sitemap:privacy' => "",
                 'sitemap:register' => "",
                 'sitemap:lostpassword' => "",
                 'sitemap:settings' => "",
                 'sitemap:accountstatistics' => "",
                 'sitemap:configureyourtools' => "",
                 'sitemap:notifications' => "",
                 'sitemap:groupnotifications' => "",
                 'sitemap:messages' => "",
                 'sitemap:composeamessage' => "",
                 'sitemap:sentmessages' => "",
                 'sitemap:dashboard' => "",
                 'sitemap:friendsactivity' => "",
                 'sitemap:myactivity' => "",
                 'sitemap:allsiteblogs' => "",
                 'sitemap:yourblog' => "",
                 'sitemap:friendsblog' => "",
                 'sitemap:writeablogpost' => "",
                 'sitemap:allsitegroups' => "",
                 'sitemap:populargroups' => "",
                 'sitemap:latestgroupdiscussion' => "",
                 'sitemap:groupsyouown' => "",
                 'sitemap:yourgroups' => "",
                 'sitemap:createanewgroup' => "",
                 'sitemap:allsitefiles' => "",
                 'sitemap:yourfiles' => "",
                 'sitemap:yourfriendsfiles' => "",
                 'sitemap:uploadafile' => "",
                 'sitemap:allsitepages' => "",
                 'sitemap:pagesHome' => "",
                 'sitemap:editwelcomemessage' => "",
                 'sitemap:allsitebookmarks' => "",
                 'sitemap:bookmarksinbox' => "",
                 'sitemap:mybookmarkeditems' => "",
                 'sitemap:friendsbookmarks' => "",
                 'sitemap:getbookmarklet' => "",
                 'sitemap:allsitemembers' => "",
                 'sitemap:popularmembers' => "",
                 'sitemap:activemembers' => "",

	);
					
	add_translation("de",$german);

?>
