<?php

function hypeLinkedInService_oauth_consumer_entity() {
    $consGuid = get_plugin_setting('oauthConsumer', 'hypeLinkedInService');
    $consumEnt = NULL;
    if ($consGuid) {
        $consumEnt = get_entity($consGuid);
    }

    $app_key = get_plugin_setting('app_key', 'hypeLinkedInService');
    $app_secret = get_plugin_setting('app_secret', 'hypeLinkedInService');
    if ($consumEnt == NULL && $app_key && $app_secret) {
// Create OAuth Consumer
        $consumEnt = oauth_create_consumer(
                'hypeLinkedInService', 'LinkedIn Auth', $app_key, $app_secret
        );
        set_plugin_setting('oauthConsumer', $consumEnt->getGUID(), 'hypeLinkedInService');
    }
    return $consumerEnt;
}

function buildLinkedInRequestUrl($url) {
    $consumer_key = get_plugin_setting('app_key', 'hypeLinkedInService');
    $consumEnt = oauth_lookup_consumer_entity($consumer_key);
    $consumer = oauth_consumer_from_entity($consumEnt);
    $tokEnt = oauth_get_token(get_loggedin_user(), $consumer);
    $token = oauth_token_from_entity($tokEnt);
    $params = oauth_get_params();
    $method = 'GET';

    $sha = new OAuthSignatureMethod_HMAC_SHA1();
    $req = OAuthRequest::from_consumer_and_token($consumer, $token, $method, $url, $params);
    $req->sign_request($sha, $consumer, $token);
    $reqUrl = $req->to_url();

    return $reqUrl;
}

function sendLinkedInRequest($url, $encode = NULL) {
    $header = array();
    switch ($encode) {
        case 'json' :
            $header[] = 'Content-Type:text/plain; charset=UTF-8';
            $header[] = 'x-li-format:json';
            break;
        case 'xml' :
            $header[] = 'Content-Type:text/xml; charset=UTF-8';
            break;
        default:
            $header[] = 'Content-Type:text/plain; charset=UTF-8';
            break;
    }

    $response = url_getter_getUrl($url, array('headers' => $header));
    return $response;
}

function getProfileImportOptions() {

    $options = array(
        'summary' => array(
            'label' => elgg_echo('profile:description'),
            'metamap' => 'description',
            'type' => 'longtext',
            'json_tag' => 'summary',
        ),
        'headline' => array(
            'label' => elgg_echo('profile:briefdescription'),
            'metamap' => 'briefdescription',
            'type' => 'text',
            'json_tag' => 'headline',
        ),
        'date-of-birth' => array(
            'label' => elgg_echo('profile:birthday'),
            'metamap' => 'birthday',
            'type' => 'text',
            'json_tag' => 'dateOfBirth',
            'json_fetch' => array(
                'subfields' => array('values' => array('day', 'month')),
                'sprintf' => 'hypeLinkedInService:bday'
            )
        ),
        'main-address' => array(
            'label' => elgg_echo('profile:location'),
            'metamap' => 'location',
            'type' => 'text',
            'json_tag' => 'mainAddress',
        ),
        'location' => array(
            'label' => elgg_echo('profile:country'),
            'metamap' => 'country',
            'type' => 'text',
            'json_tag' => 'location',
            'json_fetch' => array(
                'subfields' => array('values' => array('name')),
                'sprintf' => 'hypeLinkedInService:country'
            )
        ),
        'industry' => array(
            'label' => elgg_echo('profile:industry'),
            'metamap' => 'industry',
            'type' => 'tags',
            'json_tag' => 'industry',
        ),
        'specialties' => array(
            'label' => elgg_echo('profile:specialties'),
            'metamap' => 'specialties',
            'type' => 'tags',
            'json_tag' => 'specialties',
        ),
        'interests' => array(
            'label' => elgg_echo('profile:interests'),
            'metamap' => 'interests',
            'type' => 'tags',
            'json_tag' => 'interests',
        ),
        'phone-numbers' => array(
            'label' => elgg_echo('profile:phone'),
            'metamap' => 'phone',
            'type' => 'text',
            'json_tag' => 'phoneNumbers',
            'json_multi' => true,
            'json_fetch' => array(
                'subfields' => array('values' => array('phoneType', 'phoneNumber')),
                'sprintf' => 'hypeLinkedInService:phonenumbers'
            )
        ),
        'im-accounts' => array(
            'label' => elgg_echo('profile:imaccounts'),
            'metamap' => 'imaccounts',
            'type' => 'text',
            'json_tag' => 'imAccounts',
            'json_multi' => true,
            'json_fetch' => array(
                'subfields' => array('values' => array('imAccountType', 'imAccountName')),
                'sprintf' => 'hypeLinkedInService:imaccounts'
            )
        ),
        'public-profile-url' => array(
            'label' => elgg_echo('profile:linkedinprofile'),
            'metamap' => 'linkedinprofile',
            'type' => 'url',
            'json_tag' => 'publicProfileUrl',
        ),
        'honors' => array(
            'label' => elgg_echo('profile:honors'),
            'metamap' => 'honors',
            'type' => 'longtext',
            'json_tag' => 'honors',
        ),
        'associations' => array(
            'label' => elgg_echo('profile:associations'),
            'metamap' => 'associations',
            'type' => 'tags',
            'json_tag' => 'associations',
        ),
        'member-url-resources' => array(
            'label' => elgg_echo('profile:urlresources'),
            'metamap' => 'urlresources',
            'type' => 'text',
            'json_tag' => 'memberUrlResources',
            'json_multi' => true,
            'json_fetch' => array(
                'subfields' => array('values' => array('name', 'url')),
                'sprintf' => 'hypeLinkedInService:urlresources'
            )
        ),
        'picture-url' => array(
            'label' => elgg_echo('profile:picture'),
            'metamap' => 'iconurl',
            'type' => 'url',
            'json_tag' => 'pictureUrl',
        ),
    );

    $options = trigger_plugin_hook('hypeLinkedInService:defaultfieldoptions', 'all', array('current' => $options), $options);
    return $options;
}

function getCompanyImportOptions() {

    $options = array(
        'name' => array(
            'label' => elgg_echo('company:title'),
            'metamap' => 'title',
            'type' => 'text',
            'json_tag' => 'name',
        ),
        'description' => array(
            'label' => elgg_echo('company:description'),
            'metamap' => 'description',
            'type' => 'longtext',
            'json_tag' => 'description',
        ),
        'industry' => array(
            'label' => elgg_echo('company:industry'),
            'metamap' => 'industry',
            'type' => 'tags',
            'json_tag' => 'industry',
        ),
        'company-type' => array(
            'label' => elgg_echo('company:company_type'),
            'metamap' => 'company_type',
            'type' => 'text',
            'json_tag' => 'companyType',
            'json_fetch' => array(
                'subfields' => array('values' => array('name')),
            )
        ),
        'specialties' => array(
            'label' => elgg_echo('company:specialties'),
            'metamap' => 'specialties',
            'type' => 'text',
            'json_tag' => 'specialties',
        ),
        'employee-count-range' => array(
            'label' => elgg_echo('company:employees'),
            'metamap' => 'employees',
            'type' => 'text',
            'json_tag' => 'employeeCountRange',
            'json_fetch' => array(
                'subfields' => array('values' => array('name')),
            )
        ),
        'locations:(address:(street1,street2,city,state,postal-code,country-code))' => array(
            'label' => elgg_echo('company:locations'),
            'metamap' => 'branches',
            'type' => 'longtext',
            'json_tag' => 'locations',
            'json_multi' => true,
            'json_fetch' => array(
                'subfields' => array(
                    'values' => array('address', 'contactInfo')
            )),
        ),
        'website-url' => array(
            'label' => elgg_echo('company:www'),
            'metamap' => 'wwww',
            'type' => 'url',
            'json_tag' => 'websiteUrl',
        ),
        'logo-url' => array(
            'label' => elgg_echo('company:logo'),
            'metamap' => 'logo',
            'type' => 'url',
            'json_tag' => 'logoUrl',
        ),
        'blog-rss-url' => array(
            'label' => elgg_echo('company:blog'),
            'metamap' => 'company_blog',
            'type' => 'url',
            'json_tag' => 'blogRssUrl',
        ),
    );

    $options = trigger_plugin_hook('hypeLinkedInService:defaultcompanyfieldoptions', 'all', array('current' => $options), $options);
    return $options;
}

function getCompanyTypes() {
    return $companyTypes = array(
        "Public Company" => elgg_echo('company:type:publiccompany'),
        "Educational" => elgg_echo('company:type:educational'),
        "Self Employed" => elgg_echo('company:type:selfemployed'),
        "Government Agency" => elgg_echo('company:type:governmentagency'),
        "Non Profit" => elgg_echo('company:type:nonprofit'),
        "Self Owned" => elgg_echo('company:type:selfowned'),
        "Privately Held" => elgg_echo('company:type:privatelyheld'),
        "Partnership" => elgg_echo('company:type:partnership')
    );
}

function getCompanyIndustries() {
    return $companyIndustries = array(
        "Accounting" => elgg_echo("company:industry:47"),
        "Airlines/Aviation" => elgg_echo("company:industry:94"),
        "Alternative Dispute Resolution" => elgg_echo("company:industry:120"),
        "Alternative Medicine" => elgg_echo("company:industry:125"),
        "Animation" => elgg_echo("company:industry:127"),
        "Apparel & Fashion" => elgg_echo("company:industry:19"),
        "Architecture & Planning" => elgg_echo("company:industry:50"),
        "Arts and Crafts" => elgg_echo("company:industry:111"),
        "Automotive" => elgg_echo("company:industry:53"),
        "Aviation & Aerospace" => elgg_echo("company:industry:52"),
        "Banking" => elgg_echo("company:industry:41"),
        "Biotechnology" => elgg_echo("company:industry:12"),
        "Broadcast Media" => elgg_echo("company:industry:36"),
        "Building Materials" => elgg_echo("company:industry:49"),
        "Business Supplies and Equipment" => elgg_echo("company:industry:138"),
        "Capital Markets" => elgg_echo("company:industry:129"),
        "Chemicals" => elgg_echo("company:industry:54"),
        "Civic & Social Organization" => elgg_echo("company:industry:90"),
        "Civil Engineering" => elgg_echo("company:industry:51"),
        "Commercial Real Estate" => elgg_echo("company:industry:128"),
        "Computer & Network Security" => elgg_echo("company:industry:118"),
        "Computer Games" => elgg_echo("company:industry:109"),
        "Computer Hardware" => elgg_echo("company:industry:3"),
        "Computer Networking" => elgg_echo("company:industry:5"),
        "Computer Software" => elgg_echo("company:industry:4"),
        "Construction" => elgg_echo("company:industry:48"),
        "Consumer Electronics" => elgg_echo("company:industry:24"),
        "Consumer Goods" => elgg_echo("company:industry:25"),
        "Consumer Services" => elgg_echo("company:industry:91"),
        "Cosmetics" => elgg_echo("company:industry:18"),
        "Dairy" => elgg_echo("company:industry:65"),
        "Defense & Space" => elgg_echo("company:industry:1"),
        "Design" => elgg_echo("company:industry:99"),
        "Education Management" => elgg_echo("company:industry:69"),
        "E-Learning" => elgg_echo("company:industry:132"),
        "Electrical/Electronic Manufacturing" => elgg_echo("company:industry:112"),
        "Entertainment" => elgg_echo("company:industry:28"),
        "Environmental Services" => elgg_echo("company:industry:86"),
        "Events Services" => elgg_echo("company:industry:110"),
        "Executive Office" => elgg_echo("company:industry:76"),
        "Facilities Services" => elgg_echo("company:industry:122"),
        "Farming" => elgg_echo("company:industry:63"),
        "Financial Services" => elgg_echo("company:industry:43"),
        "Fine Art" => elgg_echo("company:industry:38"),
        "Fishery" => elgg_echo("company:industry:66"),
        "Food & Beverages" => elgg_echo("company:industry:34"),
        "Food Production" => elgg_echo("company:industry:23"),
        "Fund-Raising" => elgg_echo("company:industry:101"),
        "Furniture" => elgg_echo("company:industry:26"),
        "Gambling & Casinos" => elgg_echo("company:industry:29"),
        "Glass, Ceramics & Concrete" => elgg_echo("company:industry:145"),
        "Government Administration" => elgg_echo("company:industry:75"),
        "Government Relations" => elgg_echo("company:industry:148"),
        "Graphic Design" => elgg_echo("company:industry:140"),
        "Health, Wellness and Fitness" => elgg_echo("company:industry:124"),
        "Higher Education" => elgg_echo("company:industry:68"),
        "Hospital & Health Care" => elgg_echo("company:industry:14"),
        "Hospitality" => elgg_echo("company:industry:31"),
        "Human Resources" => elgg_echo("company:industry:137"),
        "Import and Export" => elgg_echo("company:industry:134"),
        "Individual & Family Services" => elgg_echo("company:industry:88"),
        "Industrial Automation" => elgg_echo("company:industry:147"),
        "Information Services" => elgg_echo("company:industry:84"),
        "Information Technology and Services" => elgg_echo("company:industry:96"),
        "Insurance" => elgg_echo("company:industry:42"),
        "International Affairs" => elgg_echo("company:industry:74"),
        "International Trade and Development" => elgg_echo("company:industry:141"),
        "Internet" => elgg_echo("company:industry:6"),
        "Investment Banking" => elgg_echo("company:industry:45"),
        "Investment Management" => elgg_echo("company:industry:46"),
        "Judiciary" => elgg_echo("company:industry:73"),
        "Law Enforcement" => elgg_echo("company:industry:77"),
        "Law Practice" => elgg_echo("company:industry:9"),
        "Legal Services" => elgg_echo("company:industry:10"),
        "Legislative Office" => elgg_echo("company:industry:72"),
        "Leisure, Travel & Tourism" => elgg_echo("company:industry:30"),
        "Libraries" => elgg_echo("company:industry:85"),
        "Logistics and Supply Chain" => elgg_echo("company:industry:116"),
        "Luxury Goods & Jewelry" => elgg_echo("company:industry:143"),
        "Machinery" => elgg_echo("company:industry:55"),
        "Management Consulting" => elgg_echo("company:industry:11"),
        "Maritime" => elgg_echo("company:industry:95"),
        "Market Research" => elgg_echo("company:industry:97"),
        "Marketing and Advertising" => elgg_echo("company:industry:80"),
        "Mechanical or Industrial Engineering" => elgg_echo("company:industry:135"),
        "Media Production" => elgg_echo("company:industry:126"),
        "Medical Devices" => elgg_echo("company:industry:17"),
        "Medical Practice" => elgg_echo("company:industry:13"),
        "Mental Health Care" => elgg_echo("company:industry:139"),
        "Military" => elgg_echo("company:industry:71"),
        "Mining & Metals" => elgg_echo("company:industry:56"),
        "Motion Pictures and Film" => elgg_echo("company:industry:35"),
        "Museums and Institutions" => elgg_echo("company:industry:37"),
        "Music" => elgg_echo("company:industry:115"),
        "Nanotechnology" => elgg_echo("company:industry:114"),
        "Newspapers" => elgg_echo("company:industry:81"),
        "Non-Profit Organization Management" => elgg_echo("company:industry:100"),
        "Oil & Energy" => elgg_echo("company:industry:57"),
        "Online Media" => elgg_echo("company:industry:113"),
        "Outsourcing/Offshoring" => elgg_echo("company:industry:123"),
        "Package/Freight Delivery" => elgg_echo("company:industry:87"),
        "Packaging and Containers" => elgg_echo("company:industry:146"),
        "Paper & Forest Products" => elgg_echo("company:industry:61"),
        "Performing Arts" => elgg_echo("company:industry:39"),
        "Pharmaceuticals" => elgg_echo("company:industry:15"),
        "Philanthropy" => elgg_echo("company:industry:131"),
        "Photography" => elgg_echo("company:industry:136"),
        "Plastics" => elgg_echo("company:industry:117"),
        "Political Organization" => elgg_echo("company:industry:107"),
        "Primary/Secondary Education" => elgg_echo("company:industry:67"),
        "Printing" => elgg_echo("company:industry:83"),
        "Professional Training & Coaching" => elgg_echo("company:industry:105"),
        "Program Development" => elgg_echo("company:industry:102"),
        "Public Policy" => elgg_echo("company:industry:79"),
        "Public Relations and Communications" => elgg_echo("company:industry:98"),
        "Public Safety" => elgg_echo("company:industry:78"),
        "Publishing" => elgg_echo("company:industry:82"),
        "Railroad Manufacture" => elgg_echo("company:industry:62"),
        "Ranching" => elgg_echo("company:industry:64"),
        "Real Estate" => elgg_echo("company:industry:44"),
        "Recreational Facilities and Services" => elgg_echo("company:industry:40"),
        "Religious Institutions" => elgg_echo("company:industry:89"),
        "Renewables & Environment" => elgg_echo("company:industry:144"),
        "Research" => elgg_echo("company:industry:70"),
        "Restaurants" => elgg_echo("company:industry:32"),
        "Retail" => elgg_echo("company:industry:27"),
        "Security and Investigations" => elgg_echo("company:industry:121"),
        "Semiconductors" => elgg_echo("company:industry:7"),
        "Shipbuilding" => elgg_echo("company:industry:58"),
        "Sporting Goods" => elgg_echo("company:industry:20"),
        "Sports" => elgg_echo("company:industry:33"),
        "Staffing and Recruiting" => elgg_echo("company:industry:104"),
        "Supermarkets" => elgg_echo("company:industry:22"),
        "Telecommunications" => elgg_echo("company:industry:8"),
        "Textiles" => elgg_echo("company:industry:60"),
        "Think Tanks" => elgg_echo("company:industry:130"),
        "Tobacco" => elgg_echo("company:industry:21"),
        "Translation and Localization" => elgg_echo("company:industry:108"),
        "Transportation/Trucking/Railroad" => elgg_echo("company:industry:92"),
        "Utilities" => elgg_echo("company:industry:59"),
        "Venture Capital & Private Equity" => elgg_echo("company:industry:106"),
        "Veterinary" => elgg_echo("company:industry:16"),
        "Warehousing" => elgg_echo("company:industry:93"),
        "Wholesale" => elgg_echo("company:industry:133"),
        "Wine and Spirits" => elgg_echo("company:industry:142"),
        "Wireless" => elgg_echo("company:industry:119"),
        "Writing and Editing" => elgg_echo("company:industry:103"),
    );
}

function interpretLICountryCode($countryCode) {

    $countryNames = array(
        "ad" => "Andorra",
        "ae" => "United Arab Emirates",
        "af" => "Afghanistan",
        "ag" => "Antigua and Barbuda",
        "ai" => "Anguilla",
        "al" => "Albania",
        "am" => "Armenia",
        "an" => "Netherlands Antilles",
        "ao" => "Angola",
        "aq" => "Antarctica",
        "ar" => "Argentina",
        "as" => "American Samoa",
        "at" => "Austria",
        "au" => "Australia",
        "aw" => "Aruba",
        "ax" => "Aland Islands",
        "az" => "Azerbaijan",
        "ba" => "Bosnia and Herzegovina",
        "bb" => "Barbados",
        "bd" => "Bangladesh",
        "be" => "Belgium",
        "bf" => "Burkina Faso",
        "bg" => "Bulgaria",
        "bh" => "Bahrain",
        "bi" => "Burundi",
        "bj" => "Benin",
        "bm" => "Bermuda",
        "bn" => "Brunei Darussalam",
        "bo" => "Bolivia",
        "br" => "Brazil",
        "bs" => "Bahamas",
        "bt" => "Bhutan",
        "bv" => "Bouvet Island",
        "bw" => "Botswana",
        "by" => "Belarus",
        "bz" => "Belize",
        "ca" => "Canada",
        "cb" => "Caribbean Nations",
        "cc" => "Cocos (Keeling) Islands",
        "cd" => "Democratic Republic of the Congo",
        "cf" => "Central African Republic",
        "cg" => "Congo",
        "ch" => "Switzerland",
        "ci" => "Cote D'Ivoire (Ivory Coast)",
        "ck" => "Cook Islands",
        "cl" => "Chile",
        "cm" => "Cameroon",
        "cn" => "China",
        "co" => "Colombia",
        "cr" => "Costa Rica",
        "cs" => "Serbia and Montenegro",
        "cu" => "Cuba",
        "cv" => "Cape Verde",
        "cx" => "Christmas Island",
        "cy" => "Cyprus",
        "cz" => "Czech Republic",
        "de" => "Germany",
        "dj" => "Djibouti",
        "dk" => "Denmark",
        "dm" => "Dominica",
        "do" => "Dominican Republic",
        "dz" => "Algeria",
        "ec" => "Ecuador",
        "ee" => "Estonia",
        "eg" => "Egypt",
        "eh" => "Western Sahara",
        "er" => "Eritrea",
        "es" => "Spain",
        "et" => "Ethiopia",
        "fi" => "Finland",
        "fj" => "Fiji",
        "fk" => "Falkland Islands (Malvinas)",
        "fm" => "Federated States of Micronesia",
        "fo" => "Faroe Islands",
        "fr" => "France",
        "fx" => "France, Metropolitan",
        "ga" => "Gabon",
        "gb" => "United Kingdom",
        "gd" => "Grenada",
        "ge" => "Georgia",
        "gf" => "French Guiana",
        "gh" => "Ghana",
        "gi" => "Gibraltar",
        "gl" => "Greenland",
        "gm" => "Gambia",
        "gn" => "Guinea",
        "gp" => "Guadeloupe",
        "gq" => "Equatorial Guinea",
        "gr" => "Greece",
        "gs" => "S. Georgia and S. Sandwich Islands",
        "gt" => "Guatemala",
        "gu" => "Guam",
        "gw" => "Guinea-Bissau",
        "gy" => "Guyana",
        "hk" => "Hong Kong",
        "hm" => "Heard Island and McDonald Islands",
        "hn" => "Honduras",
        "hr" => "Croatia",
        "ht" => "Haiti",
        "hu" => "Hungary",
        "id" => "Indonesia",
        "ie" => "Ireland",
        "il" => "Israel",
        "in" => "India",
        "io" => "British Indian Ocean Territory",
        "iq" => "Iraq",
        "ir" => "Iran",
        "is" => "Iceland",
        "it" => "Italy",
        "jm" => "Jamaica",
        "jo" => "Jordan",
        "jp" => "Japan",
        "ke" => "Kenya",
        "kg" => "Kyrgyzstan",
        "kh" => "Cambodia",
        "ki" => "Kiribati",
        "km" => "Comoros",
        "kn" => "Saint Kitts and Nevis",
        "kp" => "Korea (North)",
        "kr" => "Korea",
        "kw" => "Kuwait",
        "ky" => "Cayman Islands",
        "kz" => "Kazakhstan",
        "la" => "Laos",
        "lb" => "Lebanon",
        "lc" => "Saint Lucia",
        "li" => "Liechtenstein",
        "lk" => "Sri Lanka",
        "lr" => "Liberia",
        "ls" => "Lesotho",
        "lt" => "Lithuania",
        "lu" => "Luxembourg",
        "lv" => "Latvia",
        "ly" => "Libya",
        "ma" => "Morocco",
        "mc" => "Monaco",
        "md" => "Moldova",
        "mg" => "Madagascar",
        "mh" => "Marshall Islands",
        "mk" => "Macedonia",
        "ml" => "Mali",
        "mm" => "Myanmar",
        "mn" => "Mongolia",
        "mo" => "Macao",
        "mp" => "Northern Mariana Islands",
        "mq" => "Martinique",
        "mr" => "Mauritania",
        "ms" => "Montserrat",
        "mt" => "Malta",
        "mu" => "Mauritius",
        "mv" => "Maldives",
        "mw" => "Malawi",
        "mx" => "Mexico",
        "my" => "Malaysia",
        "mz" => "Mozambique",
        "na" => "Namibia",
        "nc" => "New Caledonia",
        "ne" => "Niger",
        "nf" => "Norfolk Island",
        "ng" => "Nigeria",
        "ni" => "Nicaragua",
        "nl" => "Netherlands",
        "no" => "Norway",
        "np" => "Nepal",
        "nr" => "Nauru",
        "nu" => "Niue",
        "nz" => "New Zealand",
        "om" => "Sultanate of Oman",
        "oo" => "Other",
        "pa" => "Panama",
        "pe" => "Peru",
        "pf" => "French Polynesia",
        "pg" => "Papua New Guinea",
        "ph" => "Philippines",
        "pk" => "Pakistan",
        "pl" => "Poland",
        "pm" => "Saint Pierre and Miquelon",
        "pn" => "Pitcairn",
        "pr" => "Puerto Rico",
        "ps" => "Palestinian Territory",
        "pt" => "Portugal",
        "pw" => "Palau",
        "py" => "Paraguay",
        "qa" => "Qatar",
        "re" => "Reunion",
        "ro" => "Romania",
        "ru" => "Russian Federation",
        "rw" => "Rwanda",
        "sa" => "Saudi Arabia",
        "sb" => "Solomon Islands",
        "sc" => "Seychelles",
        "sd" => "Sudan",
        "se" => "Sweden",
        "sg" => "Singapore",
        "sh" => "Saint Helena",
        "si" => "Slovenia",
        "sj" => "Svalbard and Jan Mayen",
        "sk" => "Slovak Republic",
        "sl" => "Sierra Leone",
        "sm" => "San Marino",
        "sn" => "Senegal",
        "so" => "Somalia",
        "sr" => "Suriname",
        "st" => "Sao Tome and Principe",
        "sv" => "El Salvador",
        "sy" => "Syria",
        "sz" => "Swaziland",
        "tc" => "Turks and Caicos Islands",
        "td" => "Chad",
        "tf" => "French Southern Territories",
        "tg" => "Togo",
        "th" => "Thailand",
        "tj" => "Tajikistan",
        "tk" => "Tokelau",
        "tl" => "Timor-Leste",
        "tm" => "Turkmenistan",
        "tn" => "Tunisia",
        "to" => "Tonga",
        "tp" => "East Timor",
        "tr" => "Turkey",
        "tt" => "Trinidad and Tobago",
        "tv" => "Tuvalu",
        "tw" => "Taiwan",
        "tz" => "Tanzania",
        "ua" => "Ukraine",
        "ug" => "Uganda",
        "us" => "United States",
        "uy" => "Uruguay",
        "uz" => "Uzbekistan",
        "va" => "Vatican City State (Holy See)",
        "vc" => "Saint Vincent and the Grenadines",
        "ve" => "Venezuela",
        "vg" => "Virgin Islands (British)",
        "vi" => "Virgin Islands (U.S.)",
        "vn" => "Viet Nam",
        "vu" => "Vanuatu",
        "wf" => "Wallis and Futuna",
        "ws" => "Samoa",
        "ye" => "Yemen",
        "yt" => "Mayotte",
        "yu" => "Yugoslavia",
        "za" => "South Africa",
        "zm" => "Zambia",
        "zw" => "Zimbabwe",
    );

    return $countryNames[$countryCode];
}

?>
