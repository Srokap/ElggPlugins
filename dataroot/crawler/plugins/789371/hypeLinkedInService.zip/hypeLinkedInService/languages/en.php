<?php

$english = array(

    'hypeLinkedInService:settings' => 'LinkedIn settings',
    'hypeLinkedInService:usersettings' => 'LinkedIn Connect and Import Settings',
    'hypeLinkedInService:connectlinkedinaccount' => 'Click this button to connect your account with LinkedIn',
    'hypeLinkedInService:disconnectlinkedinaccount' => 'Your account is connected to LinkedIn. Press the button to disconnect',
    'hypeLinkedInService:gettokentitle' => 'Manage LinkedIn Connection',
    'hypeLinkedInService:connectwithlinkedin' => 'LinkedIn',
    'hypeLinkedInService:profilemenu' => 'My LinkedIn Services',
    
    'hypeLinkedInService:importprofiledata' => 'Import profile data from LinkedIn',
    'hypeLinkedInService:fieldstoimport' => 'Please select what type of data you would like to import',
    'hypeLinkedInService:import' => 'Import',
    
    'hypeLinkedInService:bday' => '%s / %s',
    'hypeLinkedInService:phonenumbers' => '%s:  %s  <br />',
    'hypeLinkedInService:imaccounts' => '%s:  %s  <br />',
    'hypeLinkedInService:urlresources' => '%s (%s) <br />',
    
    'profile:description' => 'About me',
    'profile:birthday' => 'Birthday',
    'profile:location' => 'Location',
    'profile:country' => 'Country',
    'profile:industry' => 'Industry',
    'profile:specialties' => 'Specialties',
    'profile:interests' => 'Interests',
    'profile:phone' => 'Phone',
    'profile:imaccounts' => 'IM Accounts',
    'profile:linkedinprofile' => 'LinkedIn Public Profile',
    'profile:honors' => 'Honors',
    'profile:associations' => 'Associations',
    'profile:urlresources' => 'Links',
    'profile:picture' => 'Avatar',
    
    'hypeLinkedInService:importpositions' => 'Import job and education history from LinkedIn',
    
    'hypeportfolio:positions' => 'Job History',
    'hypeportfolio:education' => 'Education History',
    'hypeportfolio:languages' => 'Languages',
    'hypeportfolio:skills' => 'Skills',
    'hypeportfolio:certifications' => 'Certifications',
    'hypeportfolio:publications' => 'Publications',
    'hypeportfolio:patents' => 'Patents',
    
    'portfolio:display:certifications' => 'Certifications',
    'portfolio:display:publications' => 'Publications',
    'portfolio:display:patents' => 'Patents',
    
    'hypePortfolio:certifications:name' => 'Certification Name',
    'hypePortfolio:certifications:institution' => 'Certification Authority',
    'hypePortfolio:certifications:start_year' => 'Dates (valid from)',
    'hypePortfolio:certifications:end_year' => 'Dates (expiration)',
    'hypePortfolio:certifications:achievement' => 'License Number',
    
    'hypePortfolio:publications:name' => 'Publication Title',
    'hypePortfolio:publications:institutions' => 'Publisher',
    'hypePortfolio:publications:end_year' => 'Publication Date',
    'hypePortfolio:publications:description' => 'Publication Summary',
    
    'hypeLinkedInService:importcompanies' => 'Create directory records for your employers',
    'hypeLinkedInService:companiestoimport' => 'Please choose companies you would like to import from LinkedIn',
    'hypeLinkedInService:importpositionsfirst' => 'For the list of companies to become available, (re)import your job positions',
    
    'hypeLinkedInService:companybeenimportedother' => 'Another user has already imported %s into the directory. It might not be visible due to access level settings.',
    'hypeLinkedInService:importcompaniesfromlinkedin' => 'Import from LinkedIn',
    'hypeLinkedInService:companyimportpage' => 'Import companies from LinkedIn',
    'hypeLinkedInService:acquiretokenfirst' => 'In order to import companies, you first need to authorize your LinkedIn account. Go to Settings -> LinkedIn Settings.',
    'hypeLinkedInService:error:noprivileges' => 'You do not have privileges to perform this action',
    'hypeLinkedInService:companiestoimportbyname' => 'List universal names or id numbers for companies you would like to import. Comma separated. Universal names and/or ids can be found in LinkedIn urls (e.g. http://www.linkedin.com/company/hypejunction/ or http://www.linkedin.com/company/2326049',
    'hypeLinkedInService:idnumbers' => 'ID Numbers',
    'hypeLinkedInService:universalnames' => 'Universal Names',
    
    
    
    'company:title' => 'Company Name',
    'company:company_type' => 'Company Type',
    'company:description' => 'Company Description',
    'company:www' => 'Company website',
    'company:industry' => 'Industry',
    'company:logo' => 'Company Logo',
    'company:blog' => 'Company Blog URL',
    'company:employees' => 'Number of employees',
    'company:specialties' => 'Company specialties',
    'company:locations' => 'Company Offices',
    
    'hypeLinkedInService:branchnumber' => 'Branch %s',
    
    'hypeLinkedInService:defaultaccessnote' => 'Please note that all data you import from LinkedIn will be saved on this site with an access level Private. Please change it once the import is complete to allow your friends / collections / logged in users / public to see the imported data',
    'hypeLinkedInService:querydoesnotexist' => 'Search for "%s" failed',
    

    
    
    
   
    
    
);

add_translation('en', $english);
