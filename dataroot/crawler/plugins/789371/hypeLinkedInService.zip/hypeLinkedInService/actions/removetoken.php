<?php

global $CONFIG;
gatekeeper;

$token_guid = get_input('token_guid');
$request_url = get_input('request_url');

$result = sendLinkedInRequest($request_url);
$token = get_entity($token_guid);
if ($token && $token->canEdit()) {
    $token->delete();
}
forward('pg/linkedin/' . get_loggedin_user()->username);
?>