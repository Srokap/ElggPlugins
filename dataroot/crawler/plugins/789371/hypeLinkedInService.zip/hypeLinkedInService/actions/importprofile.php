<?php

gatekeeper();
global $CONFIG;

$import = get_input('fieldstoimport');
$callfields = implode(",", $import);
$callfields .= ',id';

$default_options = getProfileImportOptions();

$user = get_loggedin_user();

$url = 'http://api.linkedin.com/v1/people/~:(' . $callfields . ')';
$url = buildLinkedInRequestUrl($url);

$linkedinresponse = sendLinkedInRequest($url, 'json');
$profile = json_decode($linkedinresponse, true);

if (is_array($import)) {
    foreach ($import as $field) {
        $label = $default_options[$field]['label'];
        $shortname = $default_options[$field]['metamap'];
        $valtype = $default_options[$field]['type'];
        $json_tag = $default_options[$field]['json_tag'];
        $json_multi = $default_options[$field]['json_multi'];
        $json_fetch = $default_options[$field]['json_fetch'];

        if (!is_array($json_fetch)) {
            remove_metadata($user->guid, $shortname);
            $access_id = ACCESS_PRIVATE;
            create_metadata($user->guid, $shortname, $profile[$json_tag], $valtype, $user->guid, $access_id);
        } else {
            remove_metadata($user->guid, $shortname);
            $final_result = array();

            if ($json_multi) {
                $total = $profile[$json_tag]['_total'];
                $fields = $json_fetch['subfields']['values'];

                for ($i = 0; $i < $total; $i++) {
                    $to_scan = $profile[$json_tag]['values'][$i];
                    $result = array();
                    foreach ($fields as $field) {
                        $result[] = $to_scan[$field];
                    }
                    $final_result[] = implode(' - ', $result);
                }
            } else {
                $fields = $json_fetch['subfields']['values'];
                $to_scan = $profile[$json_tag];
                $result = array();
                foreach ($fields as $field) {
                    $result[] = $to_scan[$field];
                }
                $final_result[] = implode(' - ', $result);
            }

            create_metadata($user->guid, $shortname, implode('; ', $final_result), $valtype, $user->guid, $access_id);
        }
        if ($field == 'picture-url' && $profile[$json_tag] != '') {
            $filename = $CONFIG->dataroot . 'inavatar.jpg';
            $url = $profile[$json_tag];
            
            $ch = curl_init();
            $timeout = 5; // set to zero for no timeout
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
            $file_contents = curl_exec($ch);
            curl_close($ch);

            $file = $file_contents;
            //$file = file_get_contents("$url");
            file_put_contents($filename, $file);


            $pics['topbar'] = get_resized_image_from_existing_file($filename, 16, 16, true, 0, 0, 0, 0, true);
            $pics['tiny'] = get_resized_image_from_existing_file($filename, 25, 25, true, 0, 0, 0, 0, true);
            $pics['small'] = get_resized_image_from_existing_file($filename, 40, 40, true, 0, 0, 0, 0, true);
            $pics['medium'] = get_resized_image_from_existing_file($filename, 100, 100, true, 0, 0, 0, 0, true);
            $pics['large'] = get_resized_image_from_existing_file($filename, 200, 200);
            $pics['master'] = get_resized_image_from_existing_file($filename, 550, 550);

            $filehandler = new ElggFile();
            $filehandler->owner_guid = $user->getGUID();
            foreach ($pics as $k => $v) {
                $filehandler->setFilename('profile/' . $user->guid . $k . '.jpg');
                $filehandler->open("write");
                $filehandler->write($v);
                $filehandler->close();
            }
            unlink($filename);
            $user->icontime = time();
            trigger_elgg_event('profileiconupdate', $user->type, $user);
        }
    }
}

forward('pg/profile/' . $user->username . '/edit');
?>
