<?php

gatekeeper();

register_error('This feature is not available in the basic version. Visit www.hypeJunction.com for details');

forward();
?>
