hypeLinkedInService is part of the hypeJunction bundle

============
www.hypeJunction.com
hype is here for you to connect, innovate, integrate, collaborate and indulge.
hype is a bundle of plugins that will help you kick start your Elgg-based social network and spice it up with cool features and functionalities.
============

Requirements:
LinkedIn API Key is required to make this plugin work.
API Key request form: https://www.linkedin.com/secure/developer.

This plugin relies on:
hypeFramework (http://community.elgg.org/pg/plugins/project/739647/developer/ihayredinov/hypeframework)
oAuth (http://community.elgg.org/pg/plugins/project/385119/developer/jricher/oauth)
url_getter (http://community.elgg.org/pg/plugins/jricher/read/521642/url-getter)


Compatibility:
This plugin is capable of importing data into:
- Default Elgg Profile (all LinkedIn profile information) - basic version
- hypePortfolio (by default - positions, educations, skills, languages; extentions - publications, certifications)) - extended version
- hypeCompanies (all company information including location(s)) - extended version


Configuration:
- Acquire an API key and secret from LinkedIn and input them in plugin settings
- Users can then authorize / deauthorize their LinkedIn account and import data in Settings -> LinkedIn Settings (also available through user menu)
- hypeCompanies import available in the Director menu
