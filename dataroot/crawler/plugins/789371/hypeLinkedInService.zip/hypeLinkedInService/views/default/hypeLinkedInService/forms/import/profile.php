<?php

gatekeeper;
global $CONFIG;

$user = get_loggedin_user();
$action = $CONFIG->wwwroot . 'action/linkedin/importprofile';

$default_options = getProfileImportOptions();

if (is_array($default_options))
    foreach ($default_options as $ref => $value) {
        $options[$value['label']] = $ref;
    }

$form_body = elgg_view_title(elgg_echo('hypeLinkedInService:importprofiledata'));
$form_body .= elgg_echo('hypeLinkedInService:fieldstoimport');

$form_body .= '<div>' . elgg_view('input/checkboxes', array(
    'internalname' => 'fieldstoimport',
    'options' => $options
        )) . '</div>';

$form_body .= elgg_view('input/submit', array(
    'value' => elgg_echo('hypeLinkedInService:import')
));

$form = elgg_view('input/form', array(
    'body' => $form_body,
    'action' => $action
));

echo $form;
?>
