<?php

$msg = $vars['msg'];
$token_guid = $vars['token_guid'];
$request_url = $vars['request_url'];
$action = $CONFIG->wwwroot . 'action/oauth/removetoken';

if (!$msg) {
    $msg = elgg_echo('oauth:tokenform');
}

$submit = elgg_view('input/submit', array('value' => elgg_echo('hypeLinkedInService:connectwithlinkedin'), 'class' => 'linkedinbutton'));
$token_guid = elgg_view('input/hidden', array('value' => $token_guid, 'internalname' => 'token_guid'));
$request_url = elgg_view('input/hidden', array('value' => $request_url, 'internalname' => 'request_url'));

// wrap our message in a paragraph
$explain = $msg;
$form = elgg_view('input/form', array('action' => $action,
    'body' => $explain
    . $token_guid
    . $request_url
    . $submit));

echo $form;
?>