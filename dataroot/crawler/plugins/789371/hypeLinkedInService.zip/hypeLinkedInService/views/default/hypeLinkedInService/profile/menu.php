<?php
if ($vars['entity']->canEdit()) {
    ?>
    <p class="user_menu_profile">
        <a href="<?php echo $vars['url'] ?>pg/linkedin/<?php echo $vars['entity']->username; ?>/"><?php echo elgg_echo("hypeLinkedInService:profilemenu"); ?></a>
    </p>
    <?php
}
?>