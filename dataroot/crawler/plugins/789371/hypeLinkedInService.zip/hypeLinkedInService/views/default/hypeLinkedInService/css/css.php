input.linkedinbutton, input.linkedinbutton:hover {
width:89px;
height:21px;
background:transparent url(<?php echo $vars['url'] . 'mod/hypeLinkedInService/graphics/linkedin-small.png' ?>) no-repeat;
color:transparent;
border:none;
}
