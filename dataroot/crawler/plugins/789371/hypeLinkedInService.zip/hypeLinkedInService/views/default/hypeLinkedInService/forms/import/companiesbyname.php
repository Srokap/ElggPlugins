<?php

gatekeeper;
global $CONFIG;

$user = get_loggedin_user();
$action = $CONFIG->wwwroot . 'action/linkedin/importcompanies';

$fields = getCompanyImportOptions();
foreach ($fields as $ref => $value) {
    $field_options[$value['label']] = $ref;
}

$form_body .= elgg_echo('hypeLinkedInService:companiestoimportbyname');

$form_body .= '<div><label>' . elgg_echo('hypeLinkedInService:idnumbers') . '</label><br />' . elgg_view('input/text', array(
            'internalname' => 'companiestoimport',
        )) . '</div>';

$form_body .= '<div><label>' . elgg_echo('hypeLinkedInService:universalnames') . '</label><br />' . elgg_view('input/text', array(
            'internalname' => 'companiestoimportbyname',
        )) . '</div>';

$form_body .= elgg_echo('hypeLinkedInService:fieldstoimport');
$form_body .= '<div>' . elgg_view('input/checkboxes', array(
            'internalname' => 'fieldstoimport',
            'options' => $field_options
        )) . '</div>';


$form_body .= elgg_view('input/submit', array(
    'value' => elgg_echo('hypeLinkedInService:import')
        ));

$form = elgg_view('input/form', array(
    'body' => $form_body,
    'action' => $action
        ));

echo $form;
?>
