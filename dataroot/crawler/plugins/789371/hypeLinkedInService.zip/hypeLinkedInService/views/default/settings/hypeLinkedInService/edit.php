<?php

$app_key_label = elgg_echo('hypeLinkedInService:app_key');
$app_key_view = elgg_view('input/text', array(
	'internalname' => 'params[app_key]',
	'value' => $vars['entity']->app_key,
));

$app_secret_label = elgg_echo('hypeLinkedInService:app_secret');
$app_secret_view = elgg_view('input/text', array(
	'internalname' => 'params[app_secret]',
	'value' => $vars['entity']->app_secret,
));

$settings = <<<__HTML
<div id="hypelinkedinservice_settings">
	<div>$app_key_label <br />$app_key_view</div>
	<div>$app_secret_label <br />$app_secret_view</div>
</div>
__HTML;

echo $settings;

?>