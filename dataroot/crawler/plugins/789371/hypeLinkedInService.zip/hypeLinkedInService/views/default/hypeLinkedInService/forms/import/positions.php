<?php

gatekeeper;
global $CONFIG;

$user = get_loggedin_user();
$action = $CONFIG->wwwroot . 'action/linkedin/importpositions';

$options = array(
    elgg_echo('hypeportfolio:positions') => 'positions',
    elgg_echo('hypeportfolio:education') => 'educations',
    elgg_echo('hypeportfolio:languages') => 'languages',
    elgg_echo('hypeportfolio:skills') => 'skills',
    //elgg_echo('hypeportfolio:certifications') => 'certifications',
    //elgg_echo('hypeportfolio:publications') => 'publications',
    //elgg_echo('hypeportfolio:patents') => 'patents'
);

$form_body = elgg_view_title(elgg_echo('hypeLinkedInService:importpositions'));
$form_body .= elgg_echo('hypeLinkedInService:fieldstoimport');

$form_body .= '<div>' . elgg_view('input/checkboxes', array(
    'internalname' => 'fieldstoimport',
    'options' => $options
        )) . '</div>';

$form_body .= elgg_view('input/submit', array(
    'value' => elgg_echo('hypeLinkedInService:import')
));

$form = elgg_view('input/form', array(
    'body' => $form_body,
    'action' => $action
));

echo $form;
?>
