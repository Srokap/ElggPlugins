<?php

gatekeeper;
global $CONFIG;

$user = get_loggedin_user();
$action = $CONFIG->wwwroot . 'action/linkedin/importcompanies';

$user_employers = elgg_get_entities(array(
    'type' => 'object',
    'subtype' => 'work',
    'owner_guid' => $user->guid,
    'limit' => 9999
        ));

if (is_array($user_employers)) {
    foreach ($user_employers as $employer) {
        if ($linkedinid = $employer->institution_linkedinid) {
            $options[$employer->institution] = $linkedinid;
        }
    }
}

$fields = getCompanyImportOptions();
foreach ($fields as $ref => $value) {
    $field_options[$value['label']] = $ref;
}

$form_body = elgg_view_title(elgg_echo('hypeLinkedInService:importcompanies'));
$form_body .= elgg_echo('hypeLinkedInService:companiestoimport');

if ($options) {
$form_body .= '<div>' . elgg_view('input/checkboxes', array(
            'internalname' => 'companiestoimport',
            'options' => $options
        )) . '</div>';
} else {
    $form_body .= '<div>' . elgg_echo('hypeLinkedInService:importpositionsfirst') . '</div>';
}
$form_body .= elgg_echo('hypeLinkedInService:fieldstoimport');
$form_body .= '<div>' . elgg_view('input/checkboxes', array(
            'internalname' => 'fieldstoimport',
            'options' => $field_options
        )) . '</div>';


$form_body .= elgg_view('input/submit', array(
    'value' => elgg_echo('hypeLinkedInService:import')
        ));

$form = elgg_view('input/form', array(
    'body' => $form_body,
    'action' => $action
        ));

echo $form;
?>
