<?php

/* hypeLinkedInService
 *
 * LinkedIn Support for Elgg
 * @package hype
 * @subpackage LinkedInService
 *
 * @author Ismayil Khayredinov <ismayil.khayredinov@gmail.com>
 * @copyright Copyrigh (c) 2011, Ismayil Khayredinov
 */

global $CONFIG;
include_once $CONFIG->pluginspath . 'hypeLinkedInService/models/model.php';

function hypeLinkedInService_init() {
    global $CONFIG;

    if (!is_plugin_enabled('hypeFramework')) {
        register_error('hypeFramework is not enabled. hypeLinkedInService will not work properly. Visit www.hypeJunction.com for details');
    }

    if (is_plugin_enabled('oauth')) {
        $consumerEnt = hypeLinkedInService_oauth_consumer_entity();
    } else {
        register_error('OAuth Plugin is missing. Please install it or disable hypeLinkedInService');
    }

    if (!is_plugin_enabled('url_getter')) {
        register_error('url_getter is not enabled. hypeLinkedInService will not work properly.');
    }

    register_action('oauth/removetoken', false, $CONFIG->pluginspath . 'hypeLinkedInService/actions/removetoken.php', false);
    register_action('linkedin/importprofile', false, $CONFIG->pluginspath . 'hypeLinkedInService/actions/importprofile.php', false);
    register_action('linkedin/importpositions', false, $CONFIG->pluginspath . 'hypeLinkedInService/actions/importpositions.php', false);
    register_action('linkedin/importcompanies', false, $CONFIG->pluginspath . 'hypeLinkedInService/actions/importcompanies.php', false);

    elgg_extend_view('css', 'hypeLinkedInService/css/css');
    elgg_extend_view('profile/menu/linksownpage', 'hypeLinkedInService/profile/menu');

// Hook to append default profile fields
    register_plugin_hook('profile:fields', 'profile', 'hypeLinkedInService_profile_fields');

// Hook to overwrite hypePortfolio default fields
//register_plugin_hook('hypePortfolio:customfields', 'all', 'hypeLinkedInService_hypePortfolio_fields');
// Hook to overwrite hypeCompanies default fields
    register_plugin_hook('hypeCompanies:customfields', 'all', 'hypeLinkedInService_hypeCompanies_fields');

    register_page_handler('linkedin', 'hypeLinkedInService_settings_page_handler');
}

// Add submenu items
function hypeLinkedInService_pagesetup() {
    global $CONFIG;

    if (get_context() == "settings" && isloggedin() && page_owner_entity()->username == get_loggedin_user()->username) {
        add_submenu_item(elgg_echo('hypeLinkedInService:settings'), $CONFIG->wwwroot . "pg/linkedin/" . get_loggedin_user()->username);
    }

    if (is_plugin_enabled('hypeCompanies')) {
        if (get_context() == 'companies' && isloggedin() && canCreateCompany(get_loggedin_user())) {
            add_submenu_item(elgg_echo('hypeLinkedInService:importcompaniesfromlinkedin'), $CONFIG->wwwroot . "pg/linkedin/" . get_loggedin_user()->username . "/companyimport");
        }
    }
}

//Add a page handler for individual user settings
function hypeLinkedInService_settings_page_handler($page) {
    global $CONFIG;
    gatekeeper();

    $user = get_user_by_username($page[0]);

    if ($user != get_loggedin_user()) {
        forward('pg/linkedin/' . get_loggedin_user()->username);
    }

    if (empty($page[1])) {
        set_context('settings');
        $title = elgg_echo('hypeLinkedInService:usersettings');

        if ($user->canEdit()) {

            $consumer_key = get_plugin_setting('app_key', 'hypeLinkedInService');
            $consumEnt = oauth_lookup_consumer_entity($consumer_key);

            if ($consumEnt) {
                $consumer = oauth_consumer_from_entity($consumEnt);
                $tokEnt = oauth_get_token($user, $consumer);
                $token = oauth_token_from_entity($tokEnt);

                if (!$tokEnt) {
                    $body = elgg_view('hypeLinkedInService/forms/authenticate', array(
                        'msg' => elgg_echo('hypeLinkedInService:connectlinkedinaccount'),
                        'request_url' => 'https://api.linkedin.com/uas/oauth/requestToken',
                        'access_url' => 'https://api.linkedin.com/uas/oauth/accessToken',
                        'user_auth' => "https://www.linkedin.com/uas/oauth/authenticate?oauth_token=%s",
                        'return_to' => $CONFIG->wwwroot . 'pg/linkedin/' . $user->username,
                        'consumer_key' => $consumer_key
                            ));
                } else {
                    $body = elgg_view('hypeLinkedInService/forms/unauthenticate', array(
                        'msg' => elgg_echo('hypeLinkedInService:disconnectlinkedinaccount'),
                        'token_guid' => $tokEnt->getGUID(),
                        'return_to' => $CONFIG->wwwroot . 'pg/linkedin/' . $user->username,
                        'request_url' => buildLinkedInRequestUrl('https://api.linkedin.com/invalidateToken')
                            ));

                    $body .= '<div>' . elgg_echo('hypeLinkedInService:defaultaccessnote') . '</div>';

                    if (is_plugin_enabled('profile'))
                        $body .= elgg_view('hypeLinkedInService/forms/import/profile');

                    if (is_plugin_enabled('hypePortfolio'))
                        $body .= elgg_view('hypeLinkedInService/forms/import/positions');

                    if (is_plugin_enabled('hypeCompanies'))
                        $body .= elgg_view('hypeLinkedInService/forms/import/companies');
                }
            }
        } else {
            register_error(elgg_echo('hypeLinkedInService:error:noprivileges'));
            forward();
        }
    } elseif ($page[1] == 'companyimport') {
        set_context('companies');
        $title = elgg_echo('hypeLinkedInService:companyimportpage');
        if (canCreateCompany($user)) {

            $consumer_key = get_plugin_setting('app_key', 'hypeLinkedInService');
            $consumEnt = oauth_lookup_consumer_entity($consumer_key);

            if ($consumEnt) {
                $consumer = oauth_consumer_from_entity($consumEnt);
                $tokEnt = oauth_get_token($user, $consumer);
                $token = oauth_token_from_entity($tokEnt);

                if (!$tokEnt) {
                    $body = elgg_echo('hypeLinkedInService:acquiretokenfirst');
                } else {
                    $body .= '<div>' . elgg_echo('hypeLinkedInService:defaultaccessnote') . '</div>';
                    $body .= elgg_view('hypeLinkedInService/forms/import/companiesbyname');
                }
            }
        } else {
            register_error(elgg_echo('hypeLinkedInService:error:noprivileges'));
            forward();
        }
    }
    $header = elgg_view_title($title);
    $body = elgg_view('page_elements/contentwrapper', array('body' => $body));
    $body = elgg_view_layout('two_column_left_sidebar', '', $header . $body, '');

    page_draw($title, $body);
}

function hypeLinkedInService_profile_fields($hook, $entity_type, $returnvalue, $params) {

    $fields = $returnvalue;
    $fields_to_add = getProfileImportOptions();

    foreach ($fields_to_add as $ref => $value) {
        if ($ref !== 'picture-url' && $ref !== 'id') {
            $fields[$value['metamap']] = $value['type'];
        }
    }

    return $fields;
}

function hypeLinkedInService_hypePortfolio_fields($hook, $entity_type, $returnvalue, $params) {

    $hypePortfolio_items = $returnvalue;

    $hypePortfolio_items['achievements'] = array(
        'display_name' => elgg_echo('portfolio:display:achievements'),
        'river' => elgg_echo('portfolio:river:achievements'),
        'subtypes' => array(
//'achievements' => array(
//    'display_name' => elgg_echo('portfolio:display:honors'),
//    'fields' => array('name', 'institution', 'end_year')),
            'certifications' => array(
                'display_name' => elgg_echo('portfolio:display:certifications'),
                'fields' => array('name', 'institution', 'achievement', 'start_year', 'end_year')),
            'publications' => array(
                'display_name' => elgg_echo('portfolio:display:publications'),
                'fields' => array('name', 'institution', 'end_year', 'description')),
        //'patents' => array(
//    'display_name' => elgg_echo('portfolio:display:patents'),
//    'fields' => array('name', 'description', 'gpa', 'rank', 'institution', 'end_year', 'field'))
            ));

    return $hypePortfolio_items;
}

function hypeLinkedInService_hypeCompanies_fields($hook, $entity_type, $returnvalue, $params) {

    $hypeCompanies_fields = $returnvalue;

    $hypeCompanies_fields['industry'] = array(
        'display_name' => elgg_echo('company:industry'),
        'type' => 'pulldown',
        'options' => getCompanyIndustries(),
        'section' => 'extras'
    );
    $hypeCompanies_fields['specialties'] = array(
        'display_name' => elgg_echo('company:specialties'),
        'type' => 'tags',
        'section' => 'extras'
    );
    $hypeCompanies_fields['company_type'] = array(
        'display_name' => elgg_echo('company:company_type'),
        'type' => 'pulldown',
        'options' => getCompanyTypes(),
        'section' => 'extras'
    );
    $hypeCompanies_fields['company_blog'] = array(
        'display_name' => elgg_echo('company:blog'),
        'type' => 'url',
        'section' => 'extras'
    );
    $hypeCompanies_fields['locations'] = array(
        'display_name' => elgg_echo('company:locations'),
        'type' => 'longtext',
        'section' => 'extras'
    );


    return $hypeCompanies_fields;
}

register_elgg_event_handler('init', 'system', 'hypeLinkedInService_init');
register_elgg_event_handler('pagesetup', 'system', 'hypeLinkedInService_pagesetup');
?>