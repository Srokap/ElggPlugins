.elgg-infinite-scroll-ajax-loading {
	background-image: url("/_graphics/ajax_loader.gif");
	background-position: center center;
	background-repeat: no-repeat;
}

.elgg-infinite-scroll-bottom {
	color: #666;
	text-align: center;
	padding: 1.5em;
}

.elgg-gallery + .elgg-infinite-scroll-bottom {
	width: 100%;
	margin-top: 15px;
	border-top: dotted 1px #CCCCCC;
	border-bottom: dotted 1px #CCCCCC;
}
