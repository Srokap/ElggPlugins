<?php
elgg_load_js('jquery-waypoints');
elgg_load_js('elgg.infinite_scroll.automatic_pagination');
