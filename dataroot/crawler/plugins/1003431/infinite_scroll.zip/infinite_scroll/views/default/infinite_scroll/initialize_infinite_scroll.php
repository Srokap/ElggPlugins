<?php
elgg_load_js('elgg.infinite_scroll');
