<?php
/**
 * Copyright (C) 2011 Crestin Julien
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * @author Julien Crestin / Human Connect
 * @version 0.2
 * @link author http://juliencrestin.com
 * @link http://human-connect.com/
 * @license http://www.gnu.org/licenses/gpl-3.0.html
 * 
**/

	global $CONFIG;
	$token="";
	$token= $_GET['oauth_token'];
	$verifier = $_GET['oauth_verifier'];
	$user = get_loggedin_user();
	$avatar = $user->getIcon('medium');
	echo "<html><head></head><body>oauth_token=".$token."&oauth_verifier=".$verifier."&user_id=".$user->guid."&screen_name=".utf8_decode($user->name)."&username=".utf8_decode($user->username)."&avatar=". urlencode($avatar) ."</body></html>";

?>