<?php
/**
 * Copyright (C) 2011 Crestin Julien
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * @author Julien Crestin / Human Connect
 * @version 0.2
 * @link author http://juliencrestin.com
 * @link http://human-connect.com/
 * @license http://www.gnu.org/licenses/gpl-3.0.html
 * 
**/

$owner = $vars['entity']->guid;

//grab the user's 5 latest from the wire
$params = array(
	'types' => 'object',
	'subtypes' => 'thewire',
	'owner_guid' => $owner,
	'limit' => 5,
);
$latest_wire = elgg_get_entities($params);
echo "<profile_status>";
if ($latest_wire) {
	for ($i = 0; $i <5; $i++) {
		echo "<user_status".$i.">";
		echo "<message>".$latest_wire[$i]['description']."</message>";
		if($latest_wire[$i]['time_created']>0) 
			$time = strip_tags(elgg_view('output/friendlytime', array('time' => $latest_wire[$i]['time_created']), null, null, 'default'));
		else
			$time = "";
		echo "<time>" . $time . "</time>";
		echo "</user_status".$i.">";
	}
}
echo "</profile_status>";