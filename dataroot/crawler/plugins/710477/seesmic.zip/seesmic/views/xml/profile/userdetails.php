<?php
/**
 * Copyright (C) 2011 Crestin Julien
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * @author Julien Crestin / Human Connect
 * @version 0.2
 * @link author http://juliencrestin.com
 * @link http://human-connect.com/
 * @license http://www.gnu.org/licenses/gpl-3.0.html
 * 
**/

	echo "<avatar>".$vars['entity']->getIcon('large')."</avatar>";
				
	echo elgg_view("profile/status", array("entity" => $vars['entity']), false, false, "xml");
		
	?>
    <items>
	<?php
		$even_odd = null;
		
		if (is_array($vars['config']->profile) && sizeof($vars['config']->profile) > 0)
			foreach($vars['config']->profile as $shortname => $valtype) {
				if ($shortname != "description") {
					$value = $vars['entity']->$shortname;
					if (!empty($value)) {
						
			echo "<".$shortname.">";
		
			$options = array(
				'value' => $vars['entity']->$shortname
			);

			if ($valtype == 'tags') {
				$options['tag_names'] = $shortname;
			}
			echo elgg_view("output/{$valtype}", $options, null, null, 'default');
			
			echo "</".$shortname.">";
			
					}
				}
			}
	
	?>
	</items>