<?php
/**
 * Copyright (C) 2011 Crestin Julien
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * @author Julien Crestin / Human Connect
 * @version 0.2
 * @link author http://juliencrestin.com
 * @link http://human-connect.com/
 * @license http://www.gnu.org/licenses/gpl-3.0.html
 * 
**/

	$statement = $vars['statement'];
	$performed_by = $statement->getSubject();
	$object = $statement->getObject();

	$url = "<user>\n<avatar_uri>" . get_entity_icon_url($performed_by, 'medium') . "</avatar_uri>\n<profil_uri>".$performed_by->getURL()."</profil_uri>\n<username>".$performed_by->name."</username>\n<name>".$performed_by->username."</name>\n</user>";
	$string = $url . "<entity>\n<content>" . sprintf(elgg_echo("pages:river:updated"),'') . " " . elgg_echo("pages:river:update") . "</content>\n<entity_url>" . $object->getURL() . "</entity_url>\n<entity_title>" . $object->title . "</entity_title>\n<description></description>\n<group_name></group_name>\n<group_uri></group_uri>\n</entity>";


?>

<?php echo $string; ?>