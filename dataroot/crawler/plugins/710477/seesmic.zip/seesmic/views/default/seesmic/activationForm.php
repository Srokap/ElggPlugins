<?php
/**
 * Copyright (C) 2011 Crestin Julien
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * @author Julien Crestin / Human Connect
 * @version 0.2
 * @link author http://juliencrestin.com
 * @link http://human-connect.com/
 * @license http://www.gnu.org/licenses/gpl-3.0.html
 * 
**/
?>
<div>
<div id="oauth_newregistration">
<?php

echo elgg_view_title(elgg_echo('seesmic:register:title'));

$name = elgg_view('input/hidden', array('internalname' => 'name', 'value' => "Seesmic Desktop 2"));

$description = elgg_view('input/hidden', array('internalname' => 'desc', 'value' => "plugin to read and post comments from seesmic"));

$callback = elgg_view('input/hidden', array('internalname' => 'callback'));

$revA = '<input type="hidden" name="reva" value="on" />';


$key = elgg_view('input/hidden', array('internalname' => 'key', 'value' => "ba0154542a5d0e35d755ba698a733513"));

$secret = elgg_view('input/hidden', array('internalname' => 'secret', 'value' => "fd9de77043e28dc651013d5c224ff105"));

$submit = elgg_view('input/submit', array('value' => elgg_echo('seesmic:validate:submit')));

$formbody = $name . "\n";
$formbody .= $description . "\n";
$formbody .= $callback . "\n";
$formbody .= $revA . "\n";
$formbody .= $outbound . "\n";
$formbody .= $key . "\n";
$formbody .= $secret . "\n";
$formbody .= $submit;

$form = elgg_view('input/form', array('action' => $CONFIG->wwwroot . 'action/oauth/register', 
                      'body' => $formbody));

echo elgg_view('page_elements/contentwrapper', array('body' => $form));

?>
</div>