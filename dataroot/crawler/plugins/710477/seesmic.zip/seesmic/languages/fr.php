<?php
/**
 * Copyright (C) 2011 Crestin Julien
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * @author Julien Crestin / Human Connect
 * @version 0.2
 * @link author http://juliencrestin.com
 * @link http://human-connect.com/
 * @license http://www.gnu.org/licenses/gpl-3.0.html
 * 
**/

global $CONFIG;

$french = array(
	'seesmic:access_token' => 'access_token=%s',
	'seesmic:validate:submit' => 'Enregistrer l\'application',
	'seesmic:register:title' => 'Enregistrer Seesmic pour pouvoir l\'utiliser (obligatoire)',
	'seesmic:registered' => 'Enregistrer l\'application Seesmic Desktop',
	'seesmic:oauth:notactivated' => 'Vous devez activer le plugin OAuth!',
	'seesmic:activate:failed' => "L'application n'est pas encore enregistrée. Un problème est survenu. Contacter le développeur.",
	'seesmic:activation:success' => "Application enregistrée avec succès. Vos utilisateurs peuvent maintenant utiliser Seesmic Desktop 2",
	'seesmic:items:limit' => "Nombre maximum d'items à afficher au démarrage"
	);


add_translation('fr', $french);
	