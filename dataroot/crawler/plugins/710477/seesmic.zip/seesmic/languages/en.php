<?php
/**
 * Copyright (C) 2011 Crestin Julien
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * @author Julien Crestin / Human Connect
 * @version 0.2
 * @link author http://juliencrestin.com
 * @link http://human-connect.com/
 * @license http://www.gnu.org/licenses/gpl-3.0.html
 * 
**/

global $CONFIG;

$en = array(
	'seesmic:access_token' => 'access_token=%s',
	'seesmic:validate:submit' => 'Register the application',
	'seesmic:register:title' => 'You have to register it before using it (OAuth requirement)',
	'seesmic:registered' => 'Register Seesmic Desktop 2 plugin',
	'seesmic:oauth:notactivated' => 'Please activate OAuth plugin!',
	'seesmic:activate:failed' => "An error occurred trying to register it. Please contact the main developper.",
	'seesmic:activation:success' => "Application successfully registered. Users can now begin to use Seesmic Desktop 2",
	'seesmic:items:limit' => "Maximum number of items to display at start"
	);


add_translation('en', $en);
	
