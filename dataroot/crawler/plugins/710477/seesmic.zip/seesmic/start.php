<?php
/**
 * Copyright (C) 2011 Crestin Julien
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * @author Julien Crestin / Human Connect
 * @version 0.2
 * @link author http://juliencrestin.com
 * @link http://human-connect.com/
 * @license http://www.gnu.org/licenses/gpl-3.0.html
 * 
**/

function seesmic_init()
{			
	// Get config
	global $CONFIG;
	
	if (get_plugin_setting('key_register', 'seesmic') != 'no') {
			
		}
	register_page_handler('seesmic', 'seesmic_page_handler');	
	
	expose_function("get.user.stream", "get_river", NULL, "Retrieve user stream", "POST", true, false);
	expose_function("get.user.info", "api_xml_get_user_profile", array( 'user' => array ('type' => 'string') ), "Retrieve user information", "POST", true, false);
	expose_function("thewire.post", "rest_wire_post",
						array( 'user' => array ('type' => 'string'),
								'text' => array ('type' => 'string') ),
					"Post a status update to the wire", "POST", true, false);
					
	expose_function('auth.user', "auth_user",
						array( 'username' => array ('type' => 'string'),
								'password' => array ('type' => 'string') ),
					"Authenticate user", 'GET', false, false);	
	if(is_plugin_enabled("oauth")) { 
		if(get_plugin_setting("already_registered", "seesmic") != 'done')
		{		
			run_function_once("seesmic_registration");
		}
	}
}

function seesmic_registration()
{
	global $CONFIG;
	$consumEnt = oauth_create_consumer("Seesmic Desktop 2", "plugin to read and post comments from seesmic", 'ba0154542a5d0e35d755ba698a733513', 'fd9de77043e28dc651013d5c224ff105', TRUE, FALSE, 'oob');
	
	set_plugin_setting('already_registered', 'done' , "seesmic");	
}

function seesmic_page_handler($page)
{
	global $CONFIG;

	switch ($page[0]) {
	case 'callback':
	case 'connection':
	case 'activate':
		include($CONFIG->pluginspath . 'seesmic/pages/' . $page[0] . '.php');
		return false;
         break;
	}
}

function seesmic_pagesetup() {
	global $CONFIG;
	// add our page menus as needed
	if (get_context() == 'admin' && isadminloggedin()) {
		add_submenu_item(elgg_echo('seesmic:registered'), $CONFIG->wwwroot . 'pg/seesmic/activate');
	}
}

function auth_user($username, $password)
{
	$retour = authenticate($username, $password);
	if($retour != null)
	{
		login($retour);
		return "login success";
	}
	return "login error";
}

function get_river()
{
	$river = api_xml_view_river_items();
	return $river;
}

function get_send_messages()
{
	$messages = api_xml_view_messages();
	$posted = $messages[0]->time_created;
	$title = $messages[0]->title;
	$body = $messages[0]->description;
	$from = get_entity($messages[0]->fromId);
	print_r($from);
	$sender = $from->guid;
	$username = $from->username;
	return $messages;	
}

function api_xml_get_user_profile($user)
{
	$username = get_user_by_username($user);
	if($username instanceof ElggUser && $username->guid > 0 )
		return elgg_view('profile/userdetails',array(
            'entity' => $username
        ), false, false, 'xml');	
	return "This user doesn't exist or there was a problem retrieving his information";
}

function rest_wire_post($user, $text) {

    $usr = get_user_by_username($user);

    if (!$usr) {
        throw new InvalidParameterException("Bad username");
    }
	
    $obj = new ElggObject();
    $obj->subtype = "thewire";
    $obj->owner_guid = $usr->guid;
    $obj->access_id = ACCESS_PUBLIC;
    $obj->method = "api";
    $obj->description = elgg_substr(strip_tags($text), 0, 140);
    $guid = $obj->save();

    add_to_river('river/object/thewire/create',
                 'create',
                 $usr->guid,
                 $obj->guid
                );
	$row = get_river_items($usr->guid, $obj->guid);
    return "success=".$row[0]->id;
}

//function elgg_view_river_items
function api_xml_view_river_items($subject_guid = 0, $object_guid = 0, $subject_relationship = '', $type = '', $subtype = '', $action_type = '', $limit = 50, $posted_min = 0, $posted_max = 0, $pagination = true) {
	
 	//$limit = get_plugin_usersetting("user_entity_limit");
    // Get input from outside world and sanitise it
    $offset = (int) get_input('offset',0);

    // Get river items, if they exist
    if ($riveritems = get_river_items($subject_guid,
$object_guid, $subject_relationship, $type, $subtype, $action_type, $limit, $offset, $posted_min, $posted_max)) {

        return elgg_view('river/item/list',array(
            'limit' => $limit,
            'offset' => $offset,
            'items' => $riveritems
        ), false, false, 'xml');

    }

    return '';
}

//function elgg_view_river_item
function api_xml_view_river_item($item) {
    if (isset($item->view)) {
        $object = get_entity($item->object_guid);
        $subject = get_entity($item->subject_guid);
        if (!$object || !$subject) {
            // probably means an entity is disabled
            return false;
        } else {
			//echo $item->view."<br />";
            if (elgg_view_exists($item->view, 'xml')) {
                $body = elgg_view($item->view,array(
                    'item' => $item
                ), false, false, 'xml');
				return elgg_view('river/item/wrapper',array(
					'item' => $item,
					'body' => $body
				), false, false, 'xml');
            }
        }
        
    }
    return false;
}

function get_comment_link($string)
{
	$string = strip_tags($string, '<a>');
	$reg = '@<a href=["|\'](.*?)[\'|"].*?>(.*?)</a>@';
	$match = null;
	$retour = "";
	preg_match_all($reg, $string, $match);
	if(count($match[1]) > 0)
	{
		
		for($i = 0; $i < count($match[1]); $i++)
		{
			$string = preg_replace($reg, "~@@".$i."@@". $match[1][$i]."@@". $match[2][$i]."@@", $string);
		}
		$retour = "$@|".count($match[1])."|@$"; 
	}
	$retour .= $string;
	return $retour;
}

function api_xml_view_messages()
{
	$limit = 10;
	$page_owner = get_loggedin_user();
	set_page_owner($page_owner->getGUID());
	$messages = elgg_get_entities_from_metadata(array(
			'type' => 'object',
			'subtype' => 'messages',
			'metadata_name' => 'toId',
			'metadata_value' => $page_owner->getGUID(),
			'owner_guid' => $page_owner->guid,
			'limit' => $limit + 1,
			'offset' => $offset
		));
	return elgg_view('/messages/list', array(
            'items' => $messages
        ), false, false, 'xml');
}
/*
function rest_plugin_setup_pams() {
	// user token can also be used for user authentication
	register_pam_handler('pam_auth_usertoken');
 
	// simple API key check 
	register_pam_handler('api_auth_key', "sufficient", "api");
 
	// override the default pams
	return true;	
}

register_plugin_hook('rest', 'init', 'rest_plugin_setup_pams');*/
register_elgg_event_handler('init','system','seesmic_init');
register_elgg_event_handler('pagesetup','system','seesmic_pagesetup');
?>