Elgg 1.7 only

ELGG install
First, install OAUTH plugin from : http://community.elgg.org/pg/plugins/release/694696/developer/jricher/oauth

Then, extract and copy "seesmic" in your mod folder

activate OAUTH then SEESMIC

Please verify in the seesmic plugin admin if "Application successfully registered. 
Users can now begin to use Seesmic Desktop 2", 
otherwise click "Register Seesmic Desktop 2 plugin" from admin menu



SEESMIC install

Install Elgg plugin from the marketplace (available on April 12 2011 at the Seesmic marketplace)
fill the form with your credentials and your elgg platform URL.