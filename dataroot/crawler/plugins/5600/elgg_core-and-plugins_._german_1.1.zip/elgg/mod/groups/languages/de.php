<?php
	/**
	 * Elgg groups plugin language pack
	 * 
	 * @package ElggGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$german = array(
	
		/**
		 * Menu items and titles
		 */
			
			'groups' => "Gruppen",
			'groups:owned' => "Eigene Gruppen",
			'groups:yours' => "Deine Gruppen",
			'groups:user' => "Gruppen von %s",
			'groups:all' => "Alle Gruppen",
			'groups:new' => "Neue Gruppe anlegen",
			'groups:edit' => "Gruppe bearbeiten",
	
			'groups:icon' => 'Gruppen Bild (leer lassen, sofern nichts ge&auml;ndert werden soll)',
			'groups:name' => 'Gruppen Name',
			'groups:username' => 'Gruppen Kurzname (wird in URLs angezeigt, nur alphanumerische Zeichen erlaubt)',
			'groups:description' => 'Beschreibung',
			'groups:briefdescription' => 'Kurzbeschreibung',
			'groups:interests' => 'Interessen',
			'groups:website' => 'Webseite',
			'groups:members' => 'Gruppen Mitglieder',
			'groups:membership' => "Mitgliedschaft",
			'groups:access' => "Zugriffsbeschr&auml;nkungen",
			'groups:owner' => "Eigent&uuml;mer",
	        'groups:widget:num_display' => 'Anzahl der Gruppen die angezeigt werden sollen',
	        'groups:widget:membership' => 'Gruppen Mitgliedschaft',
	        'groups:widgets:description' => 'Gruppen bei denen ich Mitglied bin in meinem Profil anzeigen',
			'groups:noaccess' => 'Kein Zugriff zu dieser Gruppe',
			'groups:cantedit' => 'Du kannst diese Gruppe nicht bearbeiten',
			'groups:saved' => 'Gruppe gespeichert',
	
			'groups:joinrequest' => 'Mitgliedschaft beantragen',
			'groups:join' => 'Gruppe beitreten',
			'groups:leave' => 'Gruppe verlassen',
			'groups:invite' => 'Freunde einladen',
			'groups:inviteto' => "Freunde einladen zu '%s'",
			'groups:nofriends' => "Du hast bereits alle Deine Freunde zu dieser Gruppe eingeladen.",
	
			'groups:group' => "Gruppe",
			
			'item:object:groupforumtopic' => "Themen des Forums",
	
			/*
			  Group forum strings
			*/
			
			'groups:forum' => 'Gruppen Forum',
			'groups:addtopic' => 'Thema hinzuf&uuml;gen',
			'groups:forumlatest' => 'Forum latest',
			'groups:latestdiscussion' => 'Letzte Diskussionen',
			'groupspost:success' => 'Dein Kommentar wurde erfolgreich hinzugef&uuml;gt',
			'groups:alldiscussion' => 'Letzte Diskussion',
			'groups:edittopic' => 'Thema bearbeiten',
			'groups:topicmessage' => 'Topic message',
			'groups:topicstatus' => 'Themen status',
			'groups:reply' => 'Kommentar hinzuf&uuml;gen',
			'groups:topic' => 'Thema',
			'groups:posts' => 'Kommentare',
			'groups:lastperson' => 'Letzte Person',
			'groups:when' => 'Wann',
			'grouptopic:notcreated' => 'Es wurde kein Thema erstellt.',
			'groups:topicopen' => 'offen',
			'groups:topicclosed' => 'geschlossen',
			'groups:topicresolved' => 'Resolved',
			'groups:topicreplies' => 'Antworten',
			'grouptopic:created' => 'Dein Thema wurde erstellt.',
			'groupstopic:deleted' => 'Das Thema wurde gel&ouml;scht.',
			'groups:topicsticky' => 'Sticky',
			'groups:topicisclosed' => 'Das Thema ist geschlossen.',
			'groups:topiccloseddesc' => 'Das Thema wurde gerade schlossen. Kommentare sind nicht mehr erlaubt.',
			'grouptopic:error' => 'Dein Gruppen-Thema konnte nicht erstellt werden. Bitte versuche es erneut oder wende Dich an den Administrator.',
	
			'groups:privategroup' => 'Diese Gruppe ist Privat, es ist Mitgliedschaft erforderlich.',
			'groups:notitle' => 'Gruppen m&uuml;ssen einen Titel haben',
			'groups:cantjoin' => 'Der Gruppe konnte nicht beigetreten werden',
			'groups:cantleave' => 'Die Gruppe konnte nicht verlassen werden',
			'groups:addedtogroup' => 'Nutzer erfolgreich der Gruppe hinzugef&uuml;gt',
			'groups:joinrequestnotmade' => 'Anfrage zum Gruppenbeitritt konnte nicht erstellt werden',
			'groups:joinrequestmade' => 'Anfrage zum Gruppenbeitritt erfolgreich erstellt',
			'groups:joined' => 'Erfolgreich der Gruppe beigetreten!',
			'groups:left' => 'Gruppe erfolgreich verlassen',
			'groups:notowner' => 'Leider bist Du nicht der Eigent&uuml;mer der Gruppe.',
			'groups:alreadymember' => 'Du bist bereits ein Mitglied der Gruppe!',
			'groups:userinvited' => 'Nutzer wurde eingeladen.',
			'groups:usernotinvited' => 'Nutzer konnte nicht eingeladen werden.',
	
			'groups:invite:subject' => "%s Du wurdest eingeladen der Gruppe %s beizutreten!",
			'groups:invite:body' => "Hallo %s,

Du wurdest eingeladen der Gruppe '%s' beizutreten. Verwende den folgenden Link zur:

%s",

			'groups:welcome:subject' => "Wilkommen zur Gruppe %s !",
			'groups:welcome:body' => "Hallo %s!
		
Du bist nun ein Mitglied der Gruppe '%s' ! Verwende den folgenden Link um einen Eintrag zu erstellen!

%s",
	
			'groups:request:subject' => "%s m&ouml;chte gerne der Gruppe %s beitreten",
			'groups:request:body' => "Hallo %s,

%s m&ouml;chte gerne der Gruppe '%s' beitreten. �ber den folgenden Link kannst Du sein Profil aufrufen:

%s

oder Aktzeptiere den Beitritt &uuml;ber den folgenden Link:

%s",
	
			'groups:river:member' => 'ist nun ein Mitglied von ',
	
			'groups:nowidgets' => 'F&uuml;r diese Gruppe sind keine Widgets definiert.',
	
	
			'groups:widgets:members:title' => 'Mitglieder der Gruppe',
			'groups:widgets:members:description' => 'Zeigt die Mitglieder der Gruppe an.',
			'groups:widgets:members:label:displaynum' => 'Zeigt die Mitglieder einer Gruppe an.',
			'groups:widgets:members:label:pleaseedit' => 'Bitte Konfiguriere das Widget.',
	
			'groups:widgets:entities:title' => "Objekte der Gruppe",
			'groups:widgets:entities:description' => "Zeigt die gespeicherten Objekte der Gruppe an",
			'groups:widgets:entities:label:displaynum' => 'Zeigt die Objekte einer Gruppe an.',
			'groups:widgets:entities:label:pleaseedit' => 'Bitte konfiguriere das Widget.',
		
			'groups:forumtopic:edited' => 'Foren-Thema erfolgreich bearbeitet.',
	);
					
	add_translation("de",$german);
?>