<?php
	/**
	 * API Admin language pack.
	 * 
	 * @package ElggAPIAdmin
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */


	$german = array(
	
		/**
		 * Menu items and titles
		 */
	
			'apiadmin' => "API Administration",
	
	
			'apiadmin:keyrevoked' => "API Schl&uuml;ssel wiederrufen",
			'apiadmin:keynotrevoked' => "API Schl&uuml;ssel konnte nicht wiederrufen werden",
			'apiadmin:generated' => "API Schl&uuml;ssel erfolgreich generiert",
	
			'apiadmin:yourref' => "Deine Referenz",
			'apiadmin:generate' => "Neues Schl&uuml;sselpaar generieren",
	
			'apiadmin:noreference' => "Du mu&szlig;t eine Referenz f&uuml;r Deinen neuen Schl&uuml;ssel angeben",
			'apiadmin:generationfail' => "Bei generierung des neuen Schk&uuml;sselpaares ist ein Problem aufgetreten",
			'apiadmin:generated' => "Das neue Schl&uuml;sselpaar wurde erfolgreich erstellt",
	
			'apiadmin:revoke' => "Schl&uuml;ssel wiederrufen",
			'apiadmin:public' => "&Ouml;ffentlich",
			'apiadmin:private' => "Privat",

	
			'item:object:api_key' => 'API Schl&uuml;ssel',
	);
					
	add_translation("de",$german);
?>