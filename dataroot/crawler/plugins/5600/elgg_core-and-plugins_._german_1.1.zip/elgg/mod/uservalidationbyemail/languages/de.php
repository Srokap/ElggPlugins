<?php
	/**
	 * Email user validation plugin language pack.
	 * 
	 * @package ElggUserValidationByEmail
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$german = array(
	
		'email:validate:subject' => "%s Bitte best&auml;tige Deine Mail-Adresse!",
		'email:validate:body' => "Hallo %s,

Bitte best&auml;tige Deine Mail-Adresse in dem Du den folgenden Link verwendest:

%s
",
		'email:validate:success:subject' => "Email-Adresse &uuml;berpr&uuml;ft %s!",
		'email:validate:success:body' => "Hallo %s,
			
Gl&uuml;ckwunsch, Deine Mail-Adresse wurde erfolgreich &uuml;berpr&uuml;ft.",
	
		'uservalidationbyemail:registerok' => "Zur Aktivierung Deines Nutzerkontos verwende Bitte den Link den wir Dir per Mail senden."
	
	);
					
	add_translation("de",$german);
?>