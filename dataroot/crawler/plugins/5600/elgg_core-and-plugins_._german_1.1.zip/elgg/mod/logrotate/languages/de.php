<?php
	/**
	 * Elgg log rotator language pack.
	 * 
	 * @package ElggLogRotate
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$german = array(
	
		'logrotate:period' => 'Wie oft soll das Ereignissprotokoll archiviert werden?',
	
		'logrotate:weekly' => 'w&ouml;chentlich',
		'logrotate:monthly' => 'monatlich',
		'logrotate:yearly' => 'j&auml;hrlich',
	
		'logrotate:logrotated' => "Ereignissprotokoll wurde archiviert\n",
		'logrotate:lognotrotated' => "Fehler beim Archivieren des Ereignissprotokolles\n",
	);
					
	add_translation("de",$german);
?>