<?php
	/**
	 * Elgg garbage collector language pack.
	 * 
	 * @package ElggGarbageCollector
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$german = array(
	
		/**
		 * Menu items and titles
		 */
	
			'garbagecollector:period' => 'Wie oft soll die Speicheroptimierung laufen?',
	
			'garbagecollector:weekly' => 'w&ouml;chentlich',
			'garbagecollector:monthly' => 'monatlich',
			'garbagecollector:yearly' => 'j&auml;hrlich',
	
			'garbagecollector' => "SPEICHER OPTIMIERUNG\n",
			'garbagecollector:done' => "ERLEDGIT\n",
			'garbagecollector:optimize' => "Optimiere %s ",
	
			'garbagecollector:error' => "FEHLER",
			'garbagecollector:ok' => "OK",
	
			'garbagecollector:gc:metastrings' => 'Bereinige nicht verwendete Metastrings: ',
	
	);
					
	add_translation("de",$german);
?>