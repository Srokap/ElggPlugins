<?php

	/**
	 * Elgg river plugin language pack
	 * 
	 * @package ElggReportedContent
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */
	 
	$german = array(
	
		/**
		 * Manifest
		 */
		
		'river:widget:noactivity' => 'Keine Aktivit&auml;ten.',
		'river:widget:title' => "Aktivit&auml;ten",
		'river:widget:description' => "Letzte Aktivit&auml;ten anzeigen.",
		'river:widget:title:friends' => "Aktivit&auml;ten von Freunden",
		'river:widget:description:friends' => "Zeigt die Aktivit&auml;ten Deiner Freunde.",
	
		'river:widget:label:displaynum' => "Anzahl der Eintr&auml;ge, die angezeigt werden sollen:",
	);
					
	add_translation("de",$german);

?>