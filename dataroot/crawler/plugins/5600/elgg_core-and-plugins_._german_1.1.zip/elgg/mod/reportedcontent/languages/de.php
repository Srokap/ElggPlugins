<?php
	/**
	 * Elgg reported content plugin language pack
	 * 
	 * @package ElggReportedContent
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$german = array(
	
		/**
		 * Menu items and titles
		 */
	
			'item:object:reported_content' => 'gemeldete Verst&ouml;&szlig;e',
			'reportedcontent' => 'Verst&ouml;&szlig;e',
			'reportedcontent:this' => 'Versto&szlig; melden',
			'reportedcontent:none' => 'Es gibt keine gemeldeten Verst&ouml;&szlig;e',
			'reportedcontent:report' => 'An den Administrator melden',
			'reportedcontent:title' => 'Seiten Titel',
			'reportedcontent:deleted' => 'Der gemeldete Versto&szlig; wurde entfernt.',
			'reportedcontent:notdeleted' => 'Der gemeldete Versto&szlig; kann nicht entfernt werden.',
			'reportedcontent:delete' => 'Entfernen',
			'reportedcontent:areyousure' => 'Bist Du sicher, das Du diesen Versto&szlig; entfernen m&ouml;chtest?',
			'reportedcontent:archive' => 'Archivieren',
			'reportedcontent:archived' => 'Der Versto&szlig; wurde Archiviert',
			'reportedcontent:visit' => 'gemeldeten Versto&szlig; besuchen',
			'reportedcontent:by' => 'gemeldet von',
			'reportedcontent:objecttitle' => 'Objekt Titel',
			'reportedcontent:objecturl' => 'Objekt url',
			'reportedcontent:reason' => 'Grund der Meldung',
			'reportedcontent:description' => 'Warum m&ouml;chtest Du einen Versto&szlig; melden?',
			'reportedcontent:address' => 'Adresse des Verto&szlig;es',
			'reportedcontent:success' => 'Deine Meldung wurde an den Administrator gesendet',
			'reportedcontent:failing' => 'Deine Meldung konnte nicht gesendet werden',
			'reportedcontent:report' => 'Versto&szlig; melden', 
	
			'reportedcontent:failed' => 'Leider ist beim Versuch einen Verto&szlig; zu melden ein Fehler aufgetreten.',
	);
					
	add_translation("de",$german);
?>