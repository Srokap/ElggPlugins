<?php
	/**
	 * Elgg diagnostics language pack.
	 * 
	 * @package ElggDiagnostics
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$german = array(
	
			'diagnostics' => 'System Diagnose',
	
			'diagnostics:description' => 'Der folgende Diagnose-Report ist bei allen Fehler-Diagnosen in Elgg hilfreich und sollte bei Fehlermeldungen mit angeh&auml;ngt werden.',
	
			'diagnostics:download' => 'Download .txt',
	
	
			'diagnostics:header' => '========================================================================
Elgg Diagnose Report
Erstellt %s von %s
========================================================================
			
',
			'diagnostics:report:basic' => '
Elgg Release %s, version %s

------------------------------------------------------------------------',
			'diagnostics:report:php' => '
PHP informationen:
%s
------------------------------------------------------------------------',
			'diagnostics:report:plugins' => '
Installierte Erweiterungen und Details:

%s
------------------------------------------------------------------------',
			'diagnostics:report:md5' => '
Installierte Dateien mit Pr&uuml;fsummen:

%s
------------------------------------------------------------------------',
			'diagnostics:report:globals' => '
Global Variablen:

%s
------------------------------------------------------------------------',
	
	);
					
	add_translation("de",$german);
?>