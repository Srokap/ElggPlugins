<?php
/**
* Kaltura video client
* @package ElggKalturaVideo
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author Ivan Vergés - Ballo Microstudi SL <ivan@microstudi.net>
* @copyright Ballo Microstudi SL 2008
* @link http://microstudi.net/elgg/
**/




$translations = array(
	
	'item:object:kaltura_video' => 'Video',
	'kalturavideo:label:partner_id' => 'Partner ID',
	'kalturavideo:label:subp_id' => 'Sub-Partner ID',
	'kalturavideo:label:admin_secret' => 'Administrator Secret',
	'kalturavideo:label:secret' => 'Web Service Secret',
	'kalturavideo:title:video' => $CONFIG->sitename.'\  video',
	'kalturavideo:descprefix:video' => 'A video from kaltura by',
	'kalturavideo:text:loginkaltura' => 'You can get this data from Kaltura\'s site in:',
	'kalturavideo:text:buttoninfo' => '(Press the button "Account" -> "General Info")',
	'kalturavideo:text:signupkaltura' => 'You need to be a partner to login, signup here if needed:',
	'kalturavideo:label:videotitle' => 'Created video title',
	'kalturavideo:label:addvideo' => 'Add videos from Kaltura',
	'kalturavideo:label:uid_prefix' => 'Kaltura cms user prefix',
	
	'kalturavideo:error:misconfigured' => 'Misconfigured plugin or auth error width Kaltura!',
	'kalturavideo:error:notconfigured' => 'The plugin is not configured!',
	'kalturavideo:error:missingks' => 'Probably you have a mistake in the "Administrator Secret" or "Web Service Secret" configuration.',
	'kalturavideo:error:partnerid' => 'This error normaly appears if you are not a partner of Kaltura. Please read the README file and configure this plugin!',
	'kalturavideo:error:readme' => 'Please read the README file and configure this plugin!',
	
	'kalturavideo:label:closewindow' => 'Close window',
	'kalturavideo:label:select_size' => 'Select player size',
	'kalturavideo:label:large' => 'Large',
	'kalturavideo:label:small' => 'Small',
	'kalturavideo:label:insert' => 'Insert video',
	'kalturavideo:label:edit' => 'Edytuj video',
	'kalturavideo:label:edittitle' => 'Edytuj tytuł video',
	'kalturavideo:label:miniinsert' => 'Dodaj',
	'kalturavideo:label:miniedit' => 'Edytuj',
	'kalturavideo:label:cancel' => 'Cancel',
	'kalturavideo:label:publish' => 'Publikacja',
	'kalturavideo:label:gallery' => 'Galeria',
	'kalturavideo:label:next' => 'Next',
	'kalturavideo:label:prev' => 'Previous',
	'kalturavideo:label:start' => 'Start',
	'kalturavideo:label:newvideo' => 'Stwórz nowe video',
	'kalturavideo:label:toolsadmin' => 'Administration -> Tools administration (click "more info")',
	'kalturavideo:label:gotoconfig' => 'Please configure properly the Kaltura Video under ',
	'kalturavideo:label:adminvideos' => 'Video',
	'kalturavideo:label:myvideos' => 'Moje wideo',
	'kalturavideo:label:friendsvideos' => 'Video Znajomych ',
	'kalturavideo:label:length' => 'Długość:',
	'kalturavideo:label:plays' => 'Odtworzeń:',
	'kalturavideo:label:created' => 'Dodane:',
	'kalturavideo:label:details' => 'Szczegóły',
	'kalturavideo:label:view' => 'Pokaż video',
	'kalturavideo:label:editdetails' => 'Edytuj szczegóły',
	'kalturavideo:label:delete' => 'Usuń video',
	'kalturavideo:prompt:delete' => 'Czy napewno usunąć video?',
	'kalturavideo:action:deleteok' => 'Plik %ID% został usunięty.',
	'kalturavideo:action:deleteko' => 'Plik %ID% nie został usunięty!',
	'kalturavideo:action:updatedok' => 'Plik video %ID% uaktualniony.',
	'kalturavideo:action:updatedko' => 'Plik %ID% nie uaktualniony!',
	'kalturavideo:label:flv' => 'FLV video url:',
	'kalturavideo:label:thumbnail' => 'Ikonka url:',
	'kalturavideo:label:sharel' => 'HTML share code (big applet):',
	'kalturavideo:label:sharem' => 'HTML share code (little applet):',
	'kalturavideo:label:privateoptions' => 'Dostęp:',
	'kalturavideo:private:public' => 'Publiczny',
	'kalturavideo:private:me' => 'Tylko JA',
	'kalturavideo:private:friends' => 'Tylko znajomi',
	'kalturavideo:private:loggedin' => 'Zalogowani',
	'kalturavideo:text:privatestatus' => 'Opcje dostępu mają zastosowanie tylko w tym module (opcja -publiczny- znaczy że inni zarejestrowani użytkownicy bedą widzieć twoje pliki video lecz nie bedą mogli ich edytować). Jeśli udąstępnisz kod HTML wybranego pliku video wybrane opcje dostepu bedą bez znaczenia, jeśli chcesz by twój plik video był bezpieczny chroń linki udostępniania przed osobami trzecimi.',
	'kalturavideo:text:statuschanged' => 'Status video %2% zmieniono na "%1%"',
	'kalturavideo:text:statusnotchanged' => 'The privacity status for the video %1% cannot be changed!',
	'kalturavideo:label:allvideos' => 'Publiczne video',
	'kalturavideo:text:novideos' => 'Sorry, you don\'t have videos yet!',
	'kalturavideo:text:nopublicvideos' => 'Brak plików o takich parametrach!',
	'kalturavideo:label:author' => 'Autor:',
	'kalturavideo:text:nofriendsvideos' => 'Brak plików u przyjaciół!',
	'kalturavideo:text:nouservideos' => 'Brak plików video!',
	'kalturavideo:label:showvideo' => 'Pokaż video',
	'kalturavideo:text:notfound' => 'Resource not found!',
	'kalturavideo:show:advoptions' => 'Pokaż linki udostępniania',
	'kalturavideo:hide:advoptions' => 'Ukryj linki',
	'kalturavideo:label:latest' => 'Ostatnie video',
	'kalturavideo:text:widgetdesc' => 'This widget allows you to show automatically your latest public video from Kaltura video plugins.',
	'kalturavideo:error:edittitle' => 'Error! This title can not be changed!',
	'kalturavideo:label:latestfrom' => 'Show the latest video from:',
	'kalturavideo:label:anyvideos' => 'Any allowed video',
	'kalturavideo:error:objectnotavailable' => 'Object not available. Please reload the page.',
	'kalturavideo:label:recreateobjects' => 'Recreate all video objects',
	'kalturavideo:text:recreateobjects' => 'Try to do this if you are upgrading the Kaltura plugin from any older version or some videos are delete outside Elgg.\nAll Elgg video objects will be checked and recreated, this can be a slow process.\n\nIMPORTANT NOTE:\nAll the Elgg objects will be deleted and recreated. Metada, comments and ratings will not be lost but the GUID of the video object will change.\nThis means that the old url for the videos will change also (could affect other plugins like bookmarks).',
	'kalturavideo:edit:notallowed' => 'You can not edit this video!',
	
	'kalturavideo:river:created' => '%s utworzony',
	'kalturavideo:river:annotate' => '%s komentowany',
	'kalturavideo:river:item' => 'an video',
	'kalturavideo:river:updated' => '%s uakualniony',
	
	'kalturavideo:river:shared' => 'Video',
	'kalturavideo:label:videosfrom' => 'Video od %s',
	
	'kalturavideo:user:showallvideos' => 'Pokaż wszystkie pliki video tego użytkownika',
	
	'kalturavideo:strapline' => "%s",
	
	 /**
     * kaltura_video rating system
	 **/
	'kalturavideo:rating' => "Oceny",
	'kalturavideo:yourrate' => "Twoja ocena:",
	'kalturavideo:rate' => "Głos!",
	'kalturavideo:votes' => "głosów",
	'kalturavideo:ratesucces' => "Twoja ocena została zapisana.",
	'kalturavideo:rateempty' => "Zaznacz ocenę!",
	'kalturavideo:notrated' => "Już oceniałeś tą pozycję!",
	
	/**
	 * Groups
	 **/
	'kalturavideo:groupprofile' => 'Video',
	'kalturavideo:label:groupvideos' => "Video grupy",
	'kalturavideo:label:allgroupvideos' => "Video Grup",
	'kalturavideo:text:nogroupvideos' => 'Przepraszamy!brak udostępnionych plików video',
	'kalturavideo:private:thisgroup' => 'Ta grupa',
	'kalturavideo:label:collaborative' => 'Collaborative',
	'kalturavideo:text:collaborative' => 'Dopuszcza innych uzytkowników grupy do edycji pliku!',
	'kalturavideo:text:collaborativechanged' => 'Status %1% zmieniony!',
	'kalturavideo:text:collaborativenotchanged' => 'Status %1% nie zmieniony!',
	'kalturavideo:text:iscollaborative' => 'To video jest udostępnione do edycji, możesz zmieniac ustawienia tego pliku!',
	
	'kalturavideo:userprofile' => 'Video',
);

add_translation("pl", $translations);

?>
