<?php

	$english = array(
		'trackback:wrote' => "%s wrote a new blog post entitled %s on their blog %s",
		'trackback:instructions' => "To use a trackback from your external blog to add to the Activity stream, you must use this url:",

		'item:object:trackback' => 'External Blog posts',
	);
					
	add_translation("en",$english);
?>