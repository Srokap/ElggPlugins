<?php
//megaprofile v1.0
//diseñado por www.floops.com.ar
//la red social argentina
//para la comunidad elgg.org

function megaprofile_init() {
	
elgg_register_event_handler('init','system','megaprofile_init');

}
elgg_extend_view('css', 'megaprofile/css');
?>
