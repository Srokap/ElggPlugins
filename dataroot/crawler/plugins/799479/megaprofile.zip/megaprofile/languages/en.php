<?php
//megaprofile en.php
//diseñado por www.floops.com.ar
//la red social argentina
//para la comunidad elgg.org

$english = array(

	
	'megaprofile:profile:blog' => "Blog",
	'megaprofile:profile:pages' => "pages",
	'megaprofile:profile:wall' => "wall",
	'megaprofile:profile:video' => "videos",
	'megaprofile:profile:friends' => "friends",
	'megaprofile:profile:bookmarks' => "bookmarks",
	'megaprofile:profile:photo' => "photo",
	'megaprofile:profile:pages' => "pages",
	'megaprofile:profile:groups' => "groups",
	
	'megaprofile:privacy:blog' => "who can see my blogs on profile",
	'megaprofile:privacy:pages' => "who can see my pages on profile",
	'megaprofile:privacy:wall' => "who can see my wall on profile",
	'megaprofile:privacy:videos' => "who can see my blogs on profile",
	'megaprofile:privacy:friends' => "who can see my videos on profile",
	'megaprofile:privacy:bookmarks' => "who can see my bookmarks on profile",
	'megaprofile:privacy:photo' => "who can see my photo on profile",
	'megaprofile:privacy:groups' => "who can see my groups on profile",
	'megaprofile:privacy:status' => "who can see my status on profile",
);

add_translation("en", $english);