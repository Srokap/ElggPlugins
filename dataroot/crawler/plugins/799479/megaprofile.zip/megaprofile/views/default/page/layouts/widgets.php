
<?php

//megaprofile widegets.php
//diseñado por www.floops.com.ar
//la red social argentina
//para la comunidad elgg.org


$user_id = elgg_get_logged_in_user_guid();
$user = elgg_get_page_owner_entity();

?>

<table width="100%">
<tbody id="main">
<tr>
<td>
<div id="plusriver_sidebar_left" style="padding-right:5px;">
<?php
if (elgg_is_logged_in()){
?>
<?php
/**
 * Elgg user display (details)
 * @uses $vars['entity'] The user entity
 */



$profile_fields = elgg_get_config('profile_fields');

echo '<div id="profile-details" class="elgg-body pll">';
echo "<h2>{$user->name}</h2>";


echo elgg_view('profile/icon', array("entity" => $user,"size" => large));
echo "<br>";


$even_odd = null;
if (is_array($profile_fields) && sizeof($profile_fields) > 0) {
	foreach ($profile_fields as $shortname => $valtype) {
		if ($shortname == "description") {
			// skip about me and put at bottom
			continue;
		}
		$value = $user->$shortname;
		if (!empty($value)) {
			//This function controls the alternating class
			$even_odd = ( 'odd' != $even_odd ) ? 'odd' : 'even';
			?>
			<div class="<?php echo $even_odd; ?>">
				<b><?php echo elgg_echo("profile:{$shortname}"); ?>: </b>
				<?php
					echo elgg_view("output/{$valtype}", array('value' => $user->$shortname));
				?>
			</div>
			<?php
		}
	}
}

if (!elgg_get_config('profile_custom_fields')) {
	if ($user->isBanned()) {
		echo "<p class='profile-banned-user'>";
		echo elgg_echo('banned');
		echo "</p>";
	} else {
		if ($user->description) {
			echo "<p class='profile-aboutme-title'><b>" . elgg_echo("profile:aboutme") . "</b></p>";
			echo "<div class='profile-aboutme-contents'>";
			echo elgg_view('output/longtext', array('value' => $user->description, 'class' => 'mtn'));
			echo "</div>";
		}
	}
}

echo '</div>';
?>

<?php
$friends_show = false;
		$friends_shows_beta = elgg_get_plugin_user_setting("friends_shows_beta", $user->guid, "megaprofile");
		if(!empty($friends_shows_beta)) {
			if($friends_shows_beta == "none") {
			if(($user->guid == elgg_get_logged_in_user_guid())){
					$friends_show = true;	
				}
				
			}
			if($friends_shows_beta == "all") {
				$allowed = true; 
			} elseif($friends_shows_beta == "friends"){
				if(($user->guid == elgg_get_logged_in_user_guid())){
					$friends_show = true;	
				}
				elseif(user_is_friend($user->guid, elgg_get_logged_in_user_guid())){
					
					$friends_show = true;
					
				}
				
			}
			
		} else {
			$friends_show = true;
		}
		
		if($friends_show) {
		echo "<div class='widget_title'>" .elgg_echo('megaprofile:profile:friends').  "</div>";
		echo "<div class='sidebarBox'>";
		$num = (int) $vars['entity']->num_display;
        $size = $vars['entity']->icon_size;

        if (elgg_instanceof($user, 'user')) {
	    $html = $user->listFriends('', $num, array(
		'size' => $size,
		'list_type' => 'gallery',
	     ));
	    if ($html) {
		echo $html;
	    }
        }
	
		echo "<div class='clearfloat'></div>";
		echo "</div>";
		}
	
?>


<?php
if(elgg_is_active_plugin('pages'))
{ 
$paginas_show = false;
		$paginas_shows_beta = elgg_get_plugin_user_setting("paginas_shows_beta", $user->guid, "megaprofile");
		if(!empty($paginas_shows_beta)) {
			if($paginas_shows_beta == "none") {
			if(($user->guid == elgg_get_logged_in_user_guid())){
					$paginas_show = true;	
				}
				
			}
			if($paginas_shows_beta == "all") {
				$paginas_show = true; 
			} elseif($paginas_shows_beta == "friends"){
				if(($user->guid == elgg_get_logged_in_user_guid())){
					$paginas_show = true;	
				}
				elseif(user_is_friend($user->guid, elgg_get_logged_in_user_guid())){
					
					$paginas_show = true;
					
				}
				
			}
			
		} else {
			$paginas_show = true;
		}
		
		if($paginas_show) {
		echo "<div class='widget_title'>" .elgg_echo('megaprofile:profile:pages').  "</div>";
		echo "<div class='sidebarBox'>";
		echo elgg_list_entities(array('types' => 'object', 'subtypes' => 'page_top', 'container_guid' => $user->guid, 'limit' => 4,)); 
		echo "<div class='clearfloat'></div>";
		echo "</div>";
		}
}
?>



<?php
 }
?>

</div>

</td>
<td>

<div id="plusriver_sidebar_main"  style="padding-left:5px; border-left:1px solid #d2d2d2;width:500px;">


<?php
        $estado_show = false;
		$estado_shows_beta = elgg_get_plugin_user_setting("estado_shows_beta", $user->guid, "megaprofile");
		if(!empty($estado_shows_beta)) {
			if($estado_shows_beta == "none") {
			if(($user->guid == elgg_get_logged_in_user_guid())){
					$estado_show = true;	
				}
				
			}
			if($estado_shows_beta == "all") {
				$estado_show = true; 
			} elseif($estado_shows_beta == "friends"){
				if(($user->guid == elgg_get_logged_in_user_guid())){
					$estado_show = true;	
				}
				elseif(user_is_friend($user->guid, elgg_get_logged_in_user_guid())){
					
					$estado_show = true;
					
				}
				
			}
			
		} else {
			$estado_show = true;
		}
		
		if($estado_show) {
		
		echo elgg_view("profile/status", array("entity" => $user));
		
		
		}
	
?>
<?php
if(elgg_is_active_plugin('tidypics'))
{ 
$fotos_show = false;
		$fotos_shows_beta = elgg_get_plugin_user_setting("fotos_shows_beta", $user->guid, "megaprofile");
		if(!empty($fotos_shows_beta)) {
			if($fotos_shows_beta == "none") {
			if(($user->guid == elgg_get_logged_in_user_guid())){
					$fotos_show = true;	
				}
				
			}
			if($fotos_shows_beta == "all") {
				$fotos_show = true; 
			} elseif($fotos_shows_beta == "friends"){
				if(($user->guid == elgg_get_logged_in_user_guid())){
					$fotos_show = true;	
				}
				elseif(user_is_friend($user->guid, elgg_get_logged_in_user_guid())){
					
					$fotos_show = true;
					
				}
				
			}
			
		} else {
			$fotos_show = true;
		}
		
		if($fotos_show) {
		
		echo tp_get_latest_photos(4, $user->guid);
		
		
		}
}
?>
<?php
if(elgg_is_active_plugin('thewire'))
{ 
$wire_show = false;
		$wire_shows_beta = elgg_get_plugin_user_setting("wire_shows_beta", $user->guid, "megaprofile");
		if(!empty($wire_shows_beta)) {
			if($wire_shows_beta == "none") {
			if(($user->guid == elgg_get_logged_in_user_guid())){
					$wire_show = true;	
				}
				
			}
			if($wire_shows_beta == "all") {
				$wire_show = true; 
			} elseif($wire_shows_beta == "friends"){
				if(($user->guid == elgg_get_logged_in_user_guid())){
					$wire_show = true;	
				}
				elseif(user_is_friend($user->guid, elgg_get_logged_in_user_guid())){
					
					$wire_show = true;
					
				}
				
			}
			
		} else {
			$wire_show = true;
		}
		
		if($wire_show) {
        echo "<div class='widget_title'>" .elgg_echo('megaprofile:profile:wall').  "</div>";
		echo "<div class='sidebarBox'>";
		$num = 15;

$options = array(
	'limit' => $num,
	'pagination' => false,
);

if (elgg_in_context('profile')) {
	$options['subject_guid'] = elgg_get_page_owner_guid();
} else {
	if ($vars['entity']->content_type == 'friends') {
		$options['relationship_guid'] = elgg_get_logged_in_user_guid();
		$options['relationship'] = 'friend';
	}
}

$content = elgg_list_river($options);
if (!$content) {
	$content = elgg_echo('river:none');
}

echo $content;
		echo "<div class='clearfloat'></div>";
		echo "</div>";
		
		}
}
?>




</div>

</td>
<td>

<div style="float:right; width:230px;  padding-left:5px;">

<?php
if(elgg_is_active_plugin('videolist'))
{ 
$videos_show = false;
		$videos_shows_beta = elgg_get_plugin_user_setting("videos_shows_beta", $user->guid, "megaprofile");
		if(!empty($videos_shows_beta)) {
			if($videos_shows_beta == "none") {
			if(($user->guid == elgg_get_logged_in_user_guid())){
					$videos_show = true;	
				}
				
			}
			if($videos_shows_beta == "all") {
				$videos_show = true; 
			} elseif($videos_shows_beta == "friends"){
				if(($user->guid == elgg_get_logged_in_user_guid())){
					$videos_show = true;	
				}
				elseif(user_is_friend($user->guid, elgg_get_logged_in_user_guid())){
					
					$videos_show = true;
					
				}
				
			}
			
		} else {
			$videos_show = true;
		}
		
		if($videos_show) {
		 echo "<div class='widget_title'>" .elgg_echo('megaprofile:profile:video').  "</div>";
		echo "<div class='sidebarBox'>";
		echo elgg_list_entities(array('types' => 'object', 'subtypes' => 'videolist', 'container_guid' => $user->guid, 'limit' => 5, 'full_view' => FALSE, 'pagination' => FALSE));
		echo "<div class='clearfloat'></div>";
		echo "</div>";
		
		
		}
}
?>
<?php
if(elgg_is_active_plugin('blog'))
{ 
$blog_show = false;
		$blog_shows_beta = elgg_get_plugin_user_setting("blog_shows_beta", $user->guid, "megaprofile");
		if(!empty($blog_shows_beta)) {
			if($blog_shows_beta == "none") {
			if(($user->guid == elgg_get_logged_in_user_guid())){
					$blog_show = true;	
				}
				
			}
			if($blog_shows_beta == "all") {
				$blog_show = true; 
			} elseif($fotos_shows_beta == "friends"){
				if(($user->guid == elgg_get_logged_in_user_guid())){
					$blog_show = true;	
				}
				elseif(user_is_friend($user->guid, elgg_get_logged_in_user_guid())){
					
					$blog_show = true;
					
				}
				
			}
			
		} else {
			$blog_show = true;
		}
		
		if($blog_show) {
	    echo "<div class='widget_title'>" .elgg_echo('megaprofile:profile:blog').  "</div>";
		echo "<div class='sidebarBox'>";
		

        echo elgg_list_entities(array('types' => 'object', 'subtypes' => 'blog', 'container_guid' => $user->guid, 'limit' => 5, 'full_view' => FALSE, 'pagination' => FALSE));
	
		
		echo "<div class='clearfloat'></div>";
		echo "</div>";
		
		}
}
?>
<?php
if(elgg_is_active_plugin('bookmarks'))
{ 
$allowed = false;
		$marcadores_shows_beta = elgg_get_plugin_user_setting("marcadores_shows_beta", $user->guid, "megaprofile");
		if(!empty($marcadores_shows_beta)) {
			if($marcadores_shows_beta == "none") {
			if(($user->guid == elgg_get_logged_in_user_guid())){
					$allowed = true;	
				}
				
			}
			if($marcadores_shows_beta == "all") {
				$allowed = true; 
			} elseif($marcadores_shows_beta == "friends"){
				if(($user->guid == elgg_get_logged_in_user_guid())){
					$allowed = true;	
				}
				elseif(user_is_friend($user->guid, elgg_get_logged_in_user_guid())){
					
					$allowed = true;
					
				}
				
			}
			
		} else {
			$allowed = true;
		}
		
		if($allowed) {
        echo "<div class='widget_title'>" .elgg_echo('megaprofile:profile:bookmarks').  "</div>";
		echo "<div class='sidebarBox'>";
		echo elgg_list_entities(array('types' => 'object', 'subtypes' => 'bookmarks', 'container_guid' => $user->guid, 'limit' => 5, 'full_view' => FALSE, 'pagination' => FALSE));
		echo "<div class='clearfloat'></div>";
		echo "</div>";
		
		}
}
?>

<?php
if(elgg_is_active_plugin('groups'))
{ 
?>

<?php
$num = $vars['entity']->num_display;

$options = array(
	'type' => 'group',
	'relationship' => 'member',
	'relationship_guid' => $vars['entity']->owner_guid,
	'limit' => $num,
	'full_view' => FALSE,
	'pagination' => FALSE,
);
$content = elgg_list_entities_from_relationship($options);
?>

<?php
$allowed = false;
		$grupos_shows_beta = elgg_get_plugin_user_setting("grupos_shows_beta", $user->guid, "megaprofile");
		if(!empty($grupos_shows_beta)) {
			if($grupos_shows_beta == "none") {
			if(($user->guid == elgg_get_logged_in_user_guid())){
					$allowed = true;	
				}
				
			}
			if($grupos_shows_beta == "all") {
				$allowed = true; 
			} elseif($grupos_shows_beta == "friends"){
				if(($user->guid == elgg_get_logged_in_user_guid())){
					$allowed = true;	
				}
				elseif(user_is_friend($user->guid, elgg_get_logged_in_user_guid())){
					
					$allowed = true;
					
				}
				
			}
			
		} else {
			$allowed = true;
		}
		
		if($allowed) {
		echo "<div class='widget_title'>" .elgg_echo('megaprofile:profile:groups').  "</div>";
		echo "<div class='sidebarBox'>";
	
		
		echo $content;

if ($content) {
	$url = "group/member/" . $user->username;
	$more_link = elgg_view('output/url', array(
		'href' => $url,
		'text' => elgg_echo('groups:more'),
	));
	echo "<span class=\"elgg-widget-more\">$more_link</span>";
} else {
	echo elgg_echo('groups:none');
}
		}
	
?>
<?php
}
?>

</div>
</td>
</tr>
</tbody>
</table>