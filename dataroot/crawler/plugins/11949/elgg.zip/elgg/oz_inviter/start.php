<?php
/**
 * Octazen Elgg Invitation Plugin
 * 
 * @package ElggInviter
 * @license Commercial
 * @author Octazen Solutions <info@octazen.com>
 * @copyright Octazen Solutions 2008
 * @link http://octazen.com
 */

/********************************************************************************
Elgg 1.x Invite Module

You may not use, reprint or redistribute this code without permission from Octazen Solutions.

Copyright 2008 Octazen Solutions. All Rights Reserved
WWW: http://www.octazen.com
********************************************************************************/
include(dirname(__FILE__).'/octazen/abimporter/abi.php');
include(dirname(__FILE__).'/octazen/inviter/ozinviter.php');

//--------------------------------------------------
//Generate the invite message. You can modify this 
//to generate messages with personalized links, etc
//--------------------------------------------------
function oz_get_invite_message ($from_name=NULL,$from_email=NULL,$personal_message=NULL)
{
	global $CONFIG;	
	$site = get_entity($CONFIG->site_guid);
	$sitename = $site->name;
	$user = $_SESSION['user'];
	$uid = $user->username;

	if ($personal_message==NULL) $personal_message='';	
	$url = $CONFIG->wwwroot.'pg/profile/'.$uid;
	$text = "Hi!\r\n\r\n".$user->name." is inviting you to ".$sitename."\r\n\r\nGo to ".$url.'\r\n\r\n'.$personal_message;
	$html = "Hi!<br/><br/>".htmlentities($user->name,ENT_COMPAT,'UTF-8')." is inviting you to ".htmlentities($sitename,ENT_COMPAT,'UTF-8')."!<br/><br/>Go to <a href='".htmlentities($url,ENT_COMPAT,'UTF-8')."'>".htmlentities($url,ENT_COMPAT,'UTF-8').'</a><br/><br/>'.htmlentities($personal_message,ENT_COMPAT,'UTF-8');
	
	$msg = array(
		'subject'=>"You're invited to ".$sitename.' !',
		'text_body'=>$text,
		'html_body'=>$html,
		'short_msg'=>'Take a look at '.$url,
		'url'=>$url
	);
	return $msg;
}


//--------------------------------------------------
//Send email to multiple recipients. 
//--------------------------------------------------
function oz_send_emails ($from_name,$from_email,&$contacts, $personal_message)
{
	global $CONFIG;	
	$site = get_entity($CONFIG->site_guid);
	$sitename = $site->name;
	$user = $_SESSION['user'];
	$uid = $user->username;

	$from_name = $user->name;
	$from_email = 'noreply@'.get_site_domain($CONFIG->site_guid);
	//$user->name
	//$user->email
		
	$msg = oz_get_invite_message($from_name,$from_email,$personal_message);
	$subject = $msg['subject'];
	$text_body = $msg['text_body'];
	$html_body = $msg['html_body'];
	
	//Deliver email using PHP's mail() function (using HTML mail)
	$html = true;	//Set to true to send html mail, false for text mail
	if (is_callable('mb_encode_mimeheader')) $from_name = mb_encode_mimeheader($from_name,"UTF-8", "Q");
	$headers = "From: \"$from_name\" <$from_email>.\r\n";
	if ($html) $headers .= "Content-Type: text/html;charset=utf-8\r\nMIME-Version: 1.0\r\n";	//Send HTML part
	foreach ($contacts as &$c) {
		if ($html) mail($c['email'], $subject, $html_body, $headers);
		else mail($c['email'], $subject, $text_body, $headers);
	}
}



function octazen_compare_contacts(&$c1, &$c2) 
{
	//Sort by existing members first, followed by name
	if (isset($c1['member_id'])) {
		if (isset($c2['member_id'])) {
			$k1 = $c1['member_id'];
			$k2 = $c2['member_id'];
		 	return strcasecmp($k1,$k2);
		}
		else {
			return -1;
		}
	}
	else {
		if (isset($c2['member_id'])) {
			return 1;
		}
		else {
			$k1 = (isset($c1['name']) ? $c1['name'] : '').'_';
			$k2 = (isset($c2['name']) ? $c2['name'] : '').'_';
			return strcasecmp($k1,$k2);
		}
	}
}

//--------------------------------------------------
//Run through imported contacts list and perform any filtration if required.
//
//$contacts is a reference to an array of Contacts, where each Contact is an associative array containing the following associations:
//
//	'name' => Name of the contact (may be blank)
//	'email' => Email address of the contact (only for email contacts)
//	'id' => An identifier for the contact (email address or social network user ID)
//	'uid' => Social network user ID of the contact (optional)
//	'image' => Absolute url to the thumbnail image of the contact (optional)
//
//This function can then perform the following
//	1) Remove/inject contacts into $contacts
//	2) For each contact, inject special attributes, as follows
//
//		'x-nocheckbox' => If set, disables the ability for the user to select the contact. Must be set to true if hyperlinks are present in contact row.
//		'x-namehtml' => If set, this is html snippet used in place of the name for display. You may modify the html code to generate hyperlinks, etc.
//		'x-emailhtml' => If set, this is html snippet used in place of the email for display. 
//
//This is useful in cases where the contact is already a member of the website, and we would prefer to provide
//the user the option to add the contact as a friend rather than sending an invitation emai.
//--------------------------------------------------
function oz_filter_contacts (&$contacts)
{
	global $CONFIG;	

	foreach ($contacts as &$c) {
		if (isset($c['email'])) {
			$email = $c['email'];
			$users = get_user_by_email($email);
			if ($users && count($users)>0) {
				//It's an existing member!
				$user = $users[0];
				$c['member_id']=$user->username;
				$url = $CONFIG->wwwroot.'pg/profile/'.$user->username;
				$name = $user->name; //isset($c['name']) ? $c['name'] : $user->name;
				$namehtml = '<a href="'.$url.'" target="_blank">'.htmlentities($name,ENT_COMPAT,'UTF-8').'</a>';
				$c['x-namehtml']=$namehtml;
				$c['image'] = $CONFIG->wwwroot.'pg/icon/'.$user->username.'/medium';
				$c['x-nocheckbox']=true;
			}
		}
	}
	usort($contacts, "octazen_compare_contacts");	
}



define ('_OZ_SE_PAGENAME','invite');

function ozi_init() {
	
	// Grab the config file
	global $CONFIG;
	
	// Set up menu for logged in users
	if (isloggedin()) {
		add_menu('Invite Friends', $CONFIG->wwwroot . "pg/"._OZ_SE_PAGENAME); //."/" . $_SESSION['user']->username);	
	}

	register_page_handler(_OZ_SE_PAGENAME,'ozi_page_handler');
}
		
/**
 * Page handler; allows the use of fancy URLs
 *
 * @param array $page From the page_handler function
 * @return true|false Depending on success
 */
function ozi_page_handler($page) {
	
	global $CONFIG;

	//Include CSS
	$respath = $CONFIG->wwwroot.'/mod/oz_inviter/octazen/inviter/res/';
	$html = '<link type="text/css" href="'.$respath.'style.css" rel="stylesheet" />';
	$html .= '<style type="text/css">';
	//Elgg has very odd font sizes. We'll fix it to 21px.
	$html .= '#oz_inviter * {font-family:Arial, Helvetica, sans-serif;font-size: 12px; }';
	$html .= '#oz_inviter {border: solid 1px #999999;padding: 0px;margin: 0px; background-color:#FFFFFF; }';
	$html .= '.oz_contacts_table {height: 350px;}';
	$html .= '#oz_inviter a {text-decoration:none; }';
	$html .= '#oz_inviter a:hover {text-decoration:underline}';
	//$html .= '.oz_logo {border: dotted 1px #D0D0D0;}';
	$html .= '</style>';
	
	//Render the information block
	$html .= '<table border="0" width="500" align="center"><tr><td align="center">';
	$html .= '<div id="oz_callback" style="margin:10px; padding: 10px;"></div>';
	$html .= '<script>';
	$html .= 'function ozOnViewChanged(view)';
	$html .= '{';
	$html .= '	var ele = document.getElementById("oz_callback");';
	$html .= '  ele.style.display="block";';
	$html .= '	if (view=="selector") ele.innerHTML="Invite your friends to join this site! Select where your contacts are...";';
	//		$html .= '	else if (view=="upload") ele.innerHTML="";';
	//		$html .= '	else if (view=="manual") ele.innerHTML="";';
	//		$html .= '	else if (view=="login") ele.innerHTML="";';
	//		$html .= '	else if (view=="contacts") ele.innerHTML="";';
	//		$html .= '	else if (view=="captcha") ele.innerHTML="";';
	//		$html .= '	else if (view=="bookmark") ele.innerHTML="";';
	//		$html .= '	else if (view=="finished") ele.innerHTML="";';
	$html .= '	else ele.style.display="none";';
	$html .= '}';
	$html .= '</script>';
	$html .= '<div id="oz_inviter">';
	$html .= oz_render_inviter($respath);
	$html .= '<div id="oz_footer">Powered by <a href="http://www.octazen.com" target="_blank">Octazen Solutions Invite Engine</a></div>';
	$html .= '</div>';
	$html .= '</td></tr></table>';
		
	page_draw('Invite Friends', elgg_view_layout("one_column", elgg_view_title('Invite Friends') . $html));	

	return true;
	}

	
// Make sure the initialisation function is called on initialisation
register_elgg_event_handler('init','system','ozi_init');

?>