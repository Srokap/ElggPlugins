<?php
	$english = array(
		// main titles
		'avatar_wall' => "Avatar Wall",
		'avatar_wall:title' => "Avatar Wall",
		'avatar_wall:shorttitle' => "Avatar Wall",
		'avatar_wall:description' => "Avatar Wall shows all users with their avatars on one page",
		
		'avatar_wall:settings:onlywithavatar' => "Show only users with a custom avatar",
		'avatar_wall:settings:tiny' => "Tiny",
		'avatar_wall:settings:small' => "Small",
		'avatar_wall:settings:iconsize' => "Choose iconsize",
		'avatar_wall:settings:maxicons' => "Choose max icons on the wall",
		
		
	);
	
	add_translation("en", $english);
?>
