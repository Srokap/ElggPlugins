<?php
	
?>

.wall_icons{
	
	margin: 2px;
	
}