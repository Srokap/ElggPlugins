<?php
	echo $vars['url'] . "mod/black_pod_free/graphics/user_icons/defaultsmall.gif";
?>