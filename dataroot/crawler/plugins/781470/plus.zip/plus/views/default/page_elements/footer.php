<?php

	/**
	 * Elgg footer
	 * The standard HTML footer that displays across the site
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd 
	 * 
	 */
	 
	 // get the tools menu
	//$menu = get_register('menu');

?>

<div class="clearfloat"></div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p>&nbsp;
</div><!-- /#page_wrapper -->
</div><!-- /#page_container -->



<div id="layout_footer"><div align="center"><center>
<table width="958" height="10" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td width="648" height="10" align="right">
		<p class="footer_toolbar_links">
		<div id="seo" style="color:white;">Free Elgg Theme by <a href="http://www.swsocialweb.com/"><font style="color:#AAA;">SocialWeb</font></a> <a href="#"><font style="color:#AAA;">Privacy</font></a> <a href="#"><font style="color:#AAA;">About</font></a>
		</p>
		</td>
	</tr>
	
	
</table></div></center>
</div><!-- /#layout_footer -->

<div class="clearfloat"></div>
<!-- insert an analytics view to be extended -->
<?php
	echo elgg_view('footer/analytics');
?>