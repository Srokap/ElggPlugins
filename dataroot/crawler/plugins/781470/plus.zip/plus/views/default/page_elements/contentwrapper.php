<div class="contentWrapper<?php

	if (isset($vars['subclass'])) echo ' ' . $vars['subclass'];

?>">
<?php

	echo $vars['body'];

?>
</div>