<?php

/**
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2009
	 * @link http://elgg.org/

*/

	            //this displays some content when the user is logged out
			    {
                    echo "<div id=\"elgg_navo\">";
                    echo "<a href=\"http://www.cheap-bmw-parts.com/\">";
			    	echo "Cheap BMW Parts</a>";
        			echo "<a href=\"http://www.mobilenetinc.com/\">";
			    	echo "Free Cell Phones</a>";
				echo "<a href=\"http://www.skeletonkeyantique.com/\">";
			    	echo "Vintage Skeleton Keys</a>";
			    	echo "</div>";
		        }
	        ?>