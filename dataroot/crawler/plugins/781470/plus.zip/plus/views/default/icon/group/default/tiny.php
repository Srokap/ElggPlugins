<?php
	echo $vars['url'] . "mod/black_pod_free/graphics/group_icons/defaulttiny.gif";
?>