<?php

	/**
	 * Elgg thewire menu
	 * 
	 * @package Wire menu
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Shane Barron <admin@mercyspeak.com>
	 * @link http://www.mercyspeak.com
	 * 
	 */
?>


      <div style="float:right; background:white;">

       

      <p align="center"><a href="<?php echo $vars['url']; ?>pg/profile/<?php echo $_SESSION['user']->username; ?>"><img src="<?php echo $_SESSION['user']->getIcon('large'); ?>" style="border: 1px solid #cccccc;padding:3px;" /></a></p>

       

      <p align="center">

       

       

      <script>

      var timeZoneOff=((new Date()).getTimezoneOffset())/(-60);

      function setCookie( name, value, expires/*days*/, path, domain, secure )

      {

      var today = new Date();

      today.setTime( today.getTime() );

      if ( expires ){ expires = expires * 1000 * 60 * 60 * 24; }

      var expires_date = new Date( today.getTime() + (expires) );

      document.cookie = name + "=" +escape( value ) +

      ( ( expires ) ? ";expires=" + expires_date.toGMTString() : "" ) +

      ( ( path ) ? ";path=" + path : "" ) +

      ( ( domain ) ? ";domain=" + domain : "" ) +

      ( ( secure ) ? ";secure" : "" );

      }

      setCookie("tzoff",timeZoneOff,100,"/","","");

      </script>

       

      <?

      if(isset($_COOKIE['tzoff']))

      {

        echo gmdate('D F j, Y g:i A',time(0)+((double)$_COOKIE['tzoff'])*3600);

      }

      else echo "Please refresh the dashboard.";

      ?>

      </p>

      <div style="padding-left: 10px; padding-right: 10px; padding-bottom: 20px;">


      <br />
 
      <div style="background:#ffffff url(<?php echo $vars['url']; ?>mod/riverdashboard/_graphics/26.png) no-repeat center left; margin-bottom: 5px; padding-left: 20px; padding-top: 5px; padding-bottom: 5px; border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><a href="<?php echo $vars['url']; ?>mod/profile/edit.php?username=<?php echo $_SESSION['user']->username; ?>">Edit Profile</a></h3></div>

      <div style="background:#ffffff url(<?php echo $vars['url']; ?>mod/riverdashboard/_graphics/38.png) no-repeat center left; margin-bottom: 5px; padding-left: 20px; padding-top: 5px; padding-bottom: 5px; border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><a href="<?php echo $vars['url']; ?>mod/profile/editicon.php">Profile Picture</a></h3></div>

      <div style="background:#ffffff url(<?php echo $vars['url']; ?>mod/riverdashboard/_graphics/40.png) no-repeat center left; margin-bottom: 5px; padding-left: 20px; padding-top: 5px; padding-bottom: 5px; border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><a href="<?php echo $vars['url']; ?>pg/photos/owned/<?php echo $_SESSION['user']->username; ?>">Manage Photos</a></h3></div>

      <div style="background:#ffffff url(<?php echo $vars['url']; ?>mod/riverdashboard/_graphics/7.png) no-repeat center left; margin-bottom: 5px; padding-left: 20px; padding-top: 5px; padding-bottom: 5px; border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><a href="<?php echo $vars['url']; ?>pg/file/<?php echo $_SESSION['user']->username; ?>/new">Upload File</a></h3></div>

      <div style="background:#ffffff url(<?php echo $vars['url']; ?>mod/riverdashboard/_graphics/24.png) no-repeat center left; margin-bottom: 5px; padding-left: 20px; padding-top: 5px; padding-bottom: 5px; border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><a href="<?php echo $vars['url']; ?>pg/blog/<?php echo $_SESSION['user']->username; ?>">Blog</a></h3></div>

      <div style="background:#ffffff url(<?php echo $vars['url']; ?>mod/riverdashboard/_graphics/16.png) no-repeat center left; margin-bottom: 5px; padding-left: 20px; padding-top: 5px; padding-bottom: 5px; border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><a href="<?php echo $vars['url']; ?>pg/thewire/<?php echo $_SESSION['user']->username; ?>">The Wire</a></h3></div>

      <div style="background:#ffffff url(<?php echo $vars['url']; ?>mod/riverdashboard/_graphics/18.png) no-repeat center left; margin-bottom: 5px; padding-left: 20px; padding-top: 5px; padding-bottom: 5px; border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><a href="<?php echo $vars['url']; ?>pg/messageboard/<?php echo $_SESSION['user']->username; ?>">Message Board</a></h3></div>

      <div style="background:#ffffff url(<?php echo $vars['url']; ?>mod/riverdashboard/_graphics/41.png) no-repeat center left; margin-bottom: 5px; padding-left: 20px; padding-top: 5px; padding-bottom: 5px; border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><a href="<?php echo $vars['url']; ?>pg/friends/<?php echo $_SESSION['user']->username; ?>">Friends</a></h3></div>

      <div style="background:#ffffff url(<?php echo $vars['url']; ?>mod/riverdashboard/_graphics/72.png) no-repeat center left; margin-bottom: 5px; padding-left: 20px; padding-top: 5px; padding-bottom: 5px; border-bottom: 1px solid #edeff4;" id="left_menu_dashboard"><h3><a href="<?php echo $vars['url']; ?>pg/settings/user/<?php echo $_SESSION['user']->username; ?>">Settings</a></h3></div>

      </div>








</div>