<?php

    /**
     * diveXit theme
     **/
     
     /**
	 * Initialise the theme 
	 *
	 */
	function divexit_init(){
	
    }
	
	// Initialise log browser
	register_elgg_event_handler('init','system','divexit_init');
	
?>