<?php
	echo $vars['url'] . "mod/theme_blacktech/graphics/group_icons/defaulttiny.gif";
?>