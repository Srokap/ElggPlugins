<?php

	/**
	 * Elgg default spotlight
	 * The spotlight area that displays across the site
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.org/
	 * 
	 */
?>

<table id="spotlight_table" width="100%"cellspacing="0">
	<tr>
		<td align="left" valign="top">
		<!-- spotlight LHS content -->
					<table id="spotlight_table_left_area" width="90%" cellspacing="0">
						<tr>
							<td colspan="3" align="left" valign="top">
							<h2>diveXit - Skydivers Connected</h2>
							<p>Wir haben uns zum Ziel gemacht Fallschirmspringer zu vernetzen und eine Plattform zum Upload von Bildern zu Bieten. Die Anmeldung und Benutzung ist Kostenlos. Fast alle Infos die in Profilen oder Gruppen hinterlegt/ver�ffenlticht werden k�nnen unterschiedlichen Bnutzergruppen zug�nglich gemacht werden. Viel SPass!</p> 
							<!-- <p>Welcome to this Elgg spotlight area. This is a new feature introduced in Elgg v1.0 and we hope you will find it useful. Every plugin within Elgg can set its own content to be displayed in this space. This can include author infomation, help documents or tutorial videos.<p> -->
							</td>
						</tr>
						
						<tr><td width="100%" height="10" colspan="3" align="left" valign="top"></td>	</tr>
						
						<tr>
							<td width="33%" align="left" valign="top">
							<h2>More information</h2>
							
							<ul>
								<li><a href="http://www.divexit.de/">Zur Benutzung</a></li>
								<li><a href="http://www.divexit.de/">About Elgg</a></li>
							</ul>
							
							</td>
							<td width="33%" align="left" valign="top">
							<ul>
								<li><a href="http://www.divexit.de/">Import and Export</a></li>
								<li><a href="http://www.divexit.de/">Events and Auditing</li>
								<li><a href="http://www.divexit.de/">Translations and Views</li>
								<li><a href="http://www.divexit.de/">Access controls</a></li>
							</ul>
							
							
							</td>
							<td width="33%" align="left" valign="top">
							<ul>
								<li><a href="http://www.divexit.de/">Elgg news</a></li>
								<li><a href="http://www.divexit.de/">Elgg services</a></li>
								<li><a href="ttp://www.divexit.de/">Elgg support</a></li>
								<li><a href="http://www.divexit.de/">Elgg hosting</a></li>
							</ul>
							
							</td>
						</tr>
					</table>
				<!-- /spotlight LHS content -->

		</td>		
		
		
		<td width="250" align="left" valign="top">
		<!-- spotlight RHS content -->
		<h2>Tutorials</h2>
					
		<ul>
			<li><a href="http://www.divexit.de/">Packanleitung (Propack)</a></li>
			<li><a href="http://www.divexit.de/">Wingsuit Fliegen</a></li>
			<li><a href="http://www.divexit.de/">Sitfly</a></li>
			<li><a href="http://www.divexit.de/">BlaBlaBlaBla</a></li>
		</ul>
		<!-- /spotlight RHS content -->
		<!-- <a href="http://elgg.com"><img src="http://news.elgg.org/mod/standaloneblog/graphics/elgg_com_badge.gif"></a> -->
		</td>
	</tr>
</table>