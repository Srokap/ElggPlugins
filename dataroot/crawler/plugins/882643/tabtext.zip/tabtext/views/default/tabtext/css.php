
.tabtextinput {
	width: 290px;
  z-index: 9999;
}


.elgg-widget-instance-tabtext, .elgg-widget-instance-tabtext .elgg-body {
  overflow: visible;
}