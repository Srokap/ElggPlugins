<?php

$english = array(
  'tabtext' => "TabText",
  'tabtext:admin:filter' => "Allow Administrators to submit unfiltered HTML?",
  'tabtext:content:label' => "Tab %s Content",
  'tabtext:description' => "Text/HTML widget as configurable tabbed content",
  'tabtext:invalid:parameters' => "Invalid parameters or permissions",
  'tabtext:no:content' => "No content has been configured",
  'tabtext:numtabs:label' => "Number of tabs:  ",
  'tabtext:tab:label' => "Tab %s Name",
);
					
add_translation("en",$english);