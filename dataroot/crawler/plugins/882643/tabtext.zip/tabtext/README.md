Tab-Text-Widget-1.8.x
=====================

Configurable free text/html widget with tabbed content for Elgg 1.8

Plugin should reside in mod/tabtext