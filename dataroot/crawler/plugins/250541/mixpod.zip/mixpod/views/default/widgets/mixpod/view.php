<?php
	 $Playlist = $vars['entity']->playlist;
	 $swf= $vars['entity']->swf;
	 $width = $vars['entity']->width;
	 $height = $vars['entity']->height;

	 // if the mixpod id is empty, then do not show player
    if($Playlist){	 
print
	 "<style type=\"text/css\">
      #images img { 
          border:none;
      }
	  .clear {
		  clear:both;
	  }
</style>

<!-- div where the images will display -->
<center>
<div style=\"text-align: center; margin-left: auto; visibility:visible; margin-right: auto; width:$widthpx;\">
<object type=\"application/x-shockwave-flash\" data=\"http://assets.myflashfetish.com/swf/mp3/$swf\" height=\"$height\" width=\"$width\" style=\"width:$widthpx;height:$height px\">
<param name=\"movie\" value=\"http://assets.myflashfetish.com/swf/mp3/$swf\" />
<param name=\"quality\" value=\"high\" />
<param name=\"scale\" value=\"noscale\" />
<param name=\"salign\" value=\"TL\" />
<param name=\"wmode\" value=\"transparent\"/>
<param name=\"flashvars\" value=\"$Playlist\"/></object>
</div></div></center>"; ?>






<?php 

    }else{
        
        echo "Click edit to embed your <a href=\"http://www.mixpod.com\" target=\"_blank\">mixpod.com</a> playlist";
        
    }
?>