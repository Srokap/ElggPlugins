	<p>
		<?php echo elgg_echo("Mixpod.com flashvars value:"); ?>
		<input type="text" name="params[playlist]" value="<?php echo htmlentities($vars['entity']->playlist); ?>" />	
	</p>
    <p>
    Choose your skin:<br />
    <select name="params[swf]">
    <option value="mixpod.swf"><?php echo elgg_echo('mixpod'); ?></option>
    <option value="mff-txtzoom.swf"><?php echo elgg_echo('3d text'); ?></option>
    <option value="mff-touch.swf"><?php echo elgg_echo('mypod touch'); ?></option>
    <option value="fetish-mp3player.swf"><?php echo elgg_echo('jeroen wijering v2'); ?></option>
    </select>
    </p>
    <p>
    Choose the skin name from above to set the height:<br />
    <select name="params[height]">
    <option value="311"><?php echo elgg_echo('mixpod'); ?></option>
    <option value="128"><?php echo elgg_echo('3d text'); ?></option>
    <option value="390"><?php echo elgg_echo('mypod touch'); ?></option>
    <option value="270"><?php echo elgg_echo('jeroen wijering v2'); ?></option>
    </select>
    </p>
     <p>Player Width:<br />
    <select name="params[width]">
    <option value="294"><?php echo elgg_echo('Right 294'); ?></option>
    <option value="375"><?php echo elgg_echo('Middle 375'); ?></option>
    <option value="213"><?php echo elgg_echo('Left 213'); ?></option>
    </select>
    </p>
    
	<hr />
	<p><u>Mixpod.com flashvars value:</u><br/>
    Look for this line in the code:<br />
    <b><code>myid=28494561&path=2009/08/30&mycolor=222222&mycolor2=77ADD1&mycolor3=FFFFFF&autoplay=true&rand=0&f=4&vol=54&pat=0&grad=false&ow=410&oh=311</code></b><br />
    Copy everything from "myid to false" leave out the part (&ow410&oh=311) and paste in the box..</p><br />
    
    
   <hr />