<?php

/* ***********************************************************************
 * @author : Purusothaman Ramanujam
 * @link http://www.iYaffle.com/
 * Under this agreement, No one has rights to sell this script further.
 * ***********************************************************************/

	$english = array(
		
		'RSSNewsFeed:rssurl' => "RSS Feed URL:",
		'RSSNewsFeed:rsscount' => "No. of Feeds to Fetch:"
	);

	add_translation("en",$english);

?>
