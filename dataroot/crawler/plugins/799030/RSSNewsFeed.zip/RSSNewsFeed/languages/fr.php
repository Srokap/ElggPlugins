<?php
/* ***********************************************************************
 * @author : Purusothaman Ramanujam
 * @link http://www.iYaffle.com/
 * Under this agreement, No one has rights to sell this script further.
 * ***********************************************************************/

	$french = array(
		
		'RSSNewsFeed:rssurl' => "URL de RSS:",
		'RSSNewsFeed:rsscount' => "Le nombre d'Informations RSS:"
	);

	add_translation("fr",$french);

?>
