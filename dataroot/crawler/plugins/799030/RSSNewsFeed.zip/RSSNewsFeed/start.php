<?php
/* ***********************************************************************
 * @author : Purusothaman Ramanujam
 * @link http://www.iYaffle.com/
 * Under this agreement, No one has rights to sell this script further.
 * ***********************************************************************/

	register_elgg_event_handler('init','system','RSSNewsFeed_init');

	function RSSNewsFeed_init() 
	{
		global $CONFIG;
		add_menu('Live News', $CONFIG->wwwroot ."RSSNewsFeed/news");	
		register_page_handler('RSSNewsFeed','RSSNewsFeed_page_handler');	
	}


	function RSSNewsFeed_page_handler($page) 
	{

		global $CONFIG;
		if (!isset($page[0])) {
		      forward();
		}

		$base_dir = elgg_get_plugins_path() . 'RSSNewsFeed/pages/RSSNewsFeed';

		switch ($page[0]) {

			case 'RSSNewsFeed':
				include "$base_dir/news.php";
				break;
			default:
				include "$base_dir/news.php";
				break;
		}

		
	}
?>