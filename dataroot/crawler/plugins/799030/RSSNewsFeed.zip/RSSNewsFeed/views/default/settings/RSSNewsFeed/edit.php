<?php

/* ***********************************************************************
 * @author : Purusothaman Ramanujam
 * @link http://www.iYaffle.com/
 * Under this agreement, No one has rights to sell this script further.
 * ***********************************************************************/

	$rssurl = $vars['entity']->rssurl;
	$rsscount = $vars['entity']->rsscount;
?>

<br/>

<b><?php echo elgg_echo('RSSNewsFeed:rssurl'); ?></b>

<?php echo elgg_view('input/text', array(
		         'internalname' => 'params[rssurl]',
			   'value' => $rssurl)); ?>

<br/> <br/>

<b><?php echo elgg_echo('RSSNewsFeed:rsscount'); ?></b>

<?php echo elgg_view('input/text', array(
		         'internalname' => 'params[rsscount]',
			   'value' => $rsscount)); ?>