<?php
/* ***********************************************************************
 * @author : Purusothaman Ramanujam
 * @link http://www.iYaffle.com/
 * Under this agreement, No one has rights to sell this script further.
 * ***********************************************************************/

    // Load Elgg engine
    include_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
 
    // set the title
    $title = "Live News";
 
    // start building the main column of the page
    //$area2 = elgg_view_title($title);

    $area2 .= elgg_view("RSSNewsFeed/news");
    $params=array(
     'content' => $area2,
     'sidebar_alt' => $sidebar,
     );
    $body = elgg_view_layout('two_column_left_sidebar',$params);
    page_draw($title, $body); 
