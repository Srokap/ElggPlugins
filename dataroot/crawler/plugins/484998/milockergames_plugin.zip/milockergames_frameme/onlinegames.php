<?php

	include_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
		// Ensure only logged-in users can see this page
		gatekeeper();

	$title = elgg_echo('MiLocker Online Gaming Powered by Heyzap Games');
	$area2 = elgg_view_title($title);
	$area2 .= elgg_view('onlinegames/onlinegames');
	

	$body = elgg_view_layout("two_column_left_sidebar", $area1, $area2);
	

	page_draw($title, $body);
?>