<?php


	function milockergames_frameme_init() 
	{
		extend_view('css', 'onlinegames/css');
		add_menu(elgg_echo('milockergames_frameme:onlinegames'), $CONFIG->wwwroot . "mod/milockergames_frameme/onlinegames.php");
		register_page_handler('milockergames_frameme','milockergames_frameme_page_handler');
		
	}


	function milockergames_frameme_page_handler($page) 
	{
		
		if ($page[0])
		{
			switch ($page[0])
			{
				case "onlinegames":
					include(dirname(__FILE__) . "/onlinegames.php");
					break;
				default: 
					break;
			}
		}
	}
        // Show in Menu
        if (isloggedin()) {
            add_menu(elgg_echo('Online Games'), $CONFIG->wwwroot."mod/milockergames_frameme/onlinegames.php");
        }  
	register_elgg_event_handler('init','system','milockergames_frameme_plugin_init');
?>