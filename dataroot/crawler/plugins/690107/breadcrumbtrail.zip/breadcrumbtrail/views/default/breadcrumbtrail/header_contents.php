<?php
/**
 * CSS spécifique pour le fil d'Ariane (breadcrumb trail)
 * 
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Facyla
 * @link http://id.facyla.net/
 * 
 */
global $CONFIG;

$sep = " &gt; "; // = " > "

$root_string = '<a href="' . $CONFIG->url . '">' . elgg_echo('breadcrumbtrail:root') . '</a>';
$site_string = '<a href="' . $CONFIG->url . '">' . sprintf(elgg_echo('breadcrumbtrail:site'), $CONFIG->sitename) . '</a>';

//Container is a Group or User (page_owner)
$page_owner = page_owner_entity();
if ($page_owner instanceof ElggGroup) {
  $container = elgg_echo('group') . ': <a href="' . $page_owner->getURL() . '">' . sprintf(elgg_echo('breadcrumbtrail:container'), $page_owner->name) . '</a>';
} else if ($page_owner instanceof ElggUser) {
  $container = elgg_echo('user') . ': <a href="' . $page_owner->getURL() . '">' . sprintf(elgg_echo('breadcrumbtrail:container'), $page_owner->name) . '</a>';
}

// Object subtype index page (into container) - baser ça sur un test via le tableau dans les objects registered plutôt que ça
$context = get_context();
if (($context != "site") && ($context != "groups") && ($context != "user") && ($context != "multisite") && ($context != "search")) 
  $subtype = sprintf(elgg_echo('breadcrumbtrail:subtype'), elgg_echo($context));
//  $subtype = '<a href="' . $subtype . '">' . sprintf(elgg_echo('breadcrumbtrail:subtype'), elgg_echo($context)) . '</a>';

// Content title ; with URL if edited (text otherwise)
//$content = '<a href="' . $content_string . '">' . elgg_echo('breadcrumbtrail:content') . '</a>';

// Action : edit or create only, text based on URL (but not an url)
//$action = '<a href="' . $action . '">' . elgg_echo('breadcrumbtrail:action') . '</a>';

/* Structure du Fil : Accueil (site) > Container (group/user) > Subtype > Content > action
- Accueil
- Accueil > Membre Xyaz > Blog
- Accueil > Données publiques > Blog > Mon article > édition
*/
?>

<div id="breadcrumbtrail">
  <?php
  echo $site_string;
  if ($container) echo $sep . $container;
  if ($subtype) echo $sep . $subtype;
  if ($content) echo $sep . $content;
  if ($action) echo $sep . $action;
  if (!$container && !$subtype && !$content && !$action) echo $sep . elgg_echo('breadcrumbtrail:root');
  ?>
</div>
<div class="clearfloat"></div>
