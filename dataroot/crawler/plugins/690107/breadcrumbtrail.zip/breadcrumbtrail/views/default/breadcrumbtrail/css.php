<?php
/**
 * CSS spécifique pour le fil d'Ariane (breadcrumb trail)
 * 
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Facyla
 * @link http://id.facyla.net/
 * 
 */
global $CONFIG;
?>

#breadcrumbtrail { float:left; font: 12px sans-serif; color:grey; padding: 0 8px; margin:-10px 5px 10px 0; }
