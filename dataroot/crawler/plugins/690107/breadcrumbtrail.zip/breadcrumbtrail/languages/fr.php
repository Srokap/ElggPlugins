<?php
$french = array(
  'breadcrumbtrail:root' => "Accueil",
  'breadcrumbtrail:site' => "%s",
  
  'breadcrumbtrail:container' => "%s",
  
  'breadcrumbtrail:subtype' => "%s",
  
  'breadcrumbtrail:content' => "%s",
  
  'breadcrumbtrail:action' => "%s",
  'breadcrumbtrail:action:edit' => "édition",
  
  // Subtypes that did not have a proper name
  'event_calendar' => "Agenda",
  
  
);

add_translation('fr', $french);

