<?php
$english = array(
  'breadcrumbtrail:root' => "Home",
  'breadcrumbtrail:site' => "%s",
  
  'breadcrumbtrail:container' => "%s",
  
  'breadcrumbtrail:subtype' => "%s",
  
  'breadcrumbtrail:content' => "%s",
  
  'breadcrumbtrail:action' => "%s",
  'breadcrumbtrail:action:edit' => "edit",
  
  // Subtypes that did not have a proper name
  'event_calendar' => "Calendar",
  
);

add_translation('en', $english);

