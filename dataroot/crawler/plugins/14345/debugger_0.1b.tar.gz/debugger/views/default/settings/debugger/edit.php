<?php
/**
 *	DEBUGGER
 *	@package debugger
 *	@author Miguel Montes mmontesp@gmail.com
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Miguel Montes 2008
 *	@link http://community.elgg.org/pg/profile/mmontesp
 **/

$options = array(
	elgg_echo("debugger:error") => 'ERROR', 
	elgg_echo("debugger:warning") => 'WARNING',
);

$level = ($vars['entity']->debugger_level) ? $vars['entity']->debugger_level : 'ERROR';

?>

<p>
<?php echo elgg_echo('debugger:level'); ?>:<br/>
<?php
	echo elgg_view('input/radio', array('internalname' => 'params[debugger_level]', 'options' => $options,  'value' => $level));
	echo "<p>&nbsp;</p>"
?>
</p>