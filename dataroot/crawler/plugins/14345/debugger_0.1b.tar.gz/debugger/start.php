<?php
/**
 *	DEBUGGER
 *	@package debugger
 *	@author Miguel Montes mmontesp@gmail.com
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Miguel Montes 2008
 *	@link http://community.elgg.org/pg/profile/mmontesp
 **/

	function debugger_init(){
		//override error handlers
		set_error_handler('__elgg_error_debugger');
		set_exception_handler('__elgg_exception_debugger');
		//extend css
		extend_view('css', 'debugger/css');
	}
	
	function __elgg_error_debugger($errno, $errmsg, $filename, $linenum, $vars)
		{			
			$error = date("Y-m-d H:i:s (T)") . ": \"" . $errmsg . "\" in file " . $filename . " (line " . $linenum . ")";

			switch ($errno) {
				case E_USER_ERROR:
						error_log("ERROR: " . $error);
						register_error("ERROR: " . $error);
						echo "<div class='debugger_error'>$error</div>";
						// Since this is a fatal error, we want to stop any further execution but do so gracefully.
						throw new Exception($error); 
					break;

				case E_WARNING :
				case E_USER_WARNING : 
						error_log("WARNING: " . $error);
						// register_error("WARNING: " . $error);
						if (get_plugin_setting('debugger_level','debugger') == 'WARNING'){
							echo $error."<br/>";
						}
					break;

				default:
					global $CONFIG;
					if (isset($CONFIG->debug)) {
						error_log("DEBUG: " . $error); 
					}
					// register_error("DEBUG: " . $error);
					
			}
			
			return true;
		}
	
	function __elgg_exception_debugger($exception) {

			error_log("*** FATAL EXCEPTION *** : " . $exception);
			
			$body = elgg_view("messages/exceptions/exception",array('object' => $exception));
			echo page_draw(elgg_echo('exception:title'), $body);
			
		}
	
	// iniciar el theme
	register_elgg_event_handler('init','system','debugger_init');
	
	
	
?>