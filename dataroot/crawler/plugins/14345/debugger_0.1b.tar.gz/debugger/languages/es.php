<?php
/**
 *	DEBUGGER
 *	@package debugger
 *	@author Miguel Montes mmontesp@gmail.com
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Miguel Montes 2008
 *	@link http://community.elgg.org/pg/profile/mmontesp
 **/


	$spanish = array(
		'debugger:level' => "Nivel de advertencias",
		'debugger:error' => "Sólo errores",
		'debugger:warning' => "Errores y Advertencias",
	);
	
	add_translation("es",$spanish);
?>