<?php
/**
 *	DEBUGGER
 *	@package debugger
 *	@author Miguel Montes mmontesp@gmail.com
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Miguel Montes 2008
 *	@link http://community.elgg.org/pg/profile/mmontesp
 **/


	$english = array(
		'debugger:level' => "Warning level",
		'debugger:error' => "Only errors",
		'debugger:warning' => "Errors & Warnings",
	);
	
	add_translation("en",$english);
?>