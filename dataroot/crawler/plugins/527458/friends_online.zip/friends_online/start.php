<?php
	/**
	* Friends Online
	* 
	* @package friends_online
	* @author Dieter Konrad aka alfalive
	* @copyright Dieter Konrad 2009
	* @link http://community.elgg.org/pg/profile/alfalive
	*/
	
	
	function friends_online_init() {
		global $CONFIG;
		
		//Register translations
		register_translations($CONFIG->pluginspath . "friends_online/languages/");
		
		// Register a page handler, so we can have nice URLs
		register_page_handler('friends_online','friends_online_page_handler');
			
		// Extend system CSS with our own styles
		elgg_extend_view('css','friends_online/css');
		
		// Extend view on riverdashboard
		elgg_extend_view('riverdashboard/newestmembers', 'friends_online/friendson');
		
		$showProfileWidget = get_plugin_setting("showProfileWidget","friends_online");
		if(empty($showProfileWidget) || $showProfileWidget == "no"){

		} else {
		// Add a new file widget // Incompatibel mit �lteren versionen wenn user den widget activiert hat wird er trotzdem angezeigt.
		add_widget_type('fonline',elgg_echo("friends_online:friends"),elgg_echo("friends_online:online"));
		}
		
		$showToolsLink = get_plugin_setting("showToolsLink","friends_online");
		if(empty($showToolsLink) || $showToolsLink == "no"){

		} else {
		// Add menu link
		add_menu(elgg_echo('friends_online:onlineusers'), $CONFIG->wwwroot . "mod/friends_online/pages/index.php");
		}	
	}
	
	function friends_online_page_handler($page){
		global $CONFIG;
		// include($CONFIG->pluginspath . "friends_online/index.php"); 
		
	}
	
	register_elgg_event_handler('init','system','friends_online_init');
	
?>