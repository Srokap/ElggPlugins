<?php

	/**
	 * Elgg thewire view page
	 * 
	 * @package 
	 * @license 
	 * @author 
	 * @copyright 
	 * @link 
	 * 
	 */
	 
	 $showRecentWidget = get_plugin_setting("showRecentWidget","friends_online");
	if(empty($showRecentWidget) || $showRecentWidget == "no"){

	} else {

	$users_max = get_plugin_setting("maxIcons","friends_online");
	if(!$users_max) $users_max = 12;
	$newest_members = elgg_get_entities_from_metadata(array('metadata_names' => 'icontime', 'types' => 'user', 'limit' => $users_max));
	
?>

<div class="sidebarBox">
<h3><?php echo elgg_echo('riverdashboard:recentmembers') ?></h3>
<div class="easyWrapper">

			<?php
				
					$avatarsize = get_plugin_setting("wallIconSize","friends_online");
					
					if ($avatarsize == medium) {
					
					echo "<div class=\"easy_medium\">";
						foreach($newest_members as $memb){
							echo "<div class=\"friends_online\">";
							echo elgg_view("profile/icon",array('entity' => $memb, 'size' => $avatarsize));
							echo "</div>";
						}
					echo "</div>";
					
					} else if ($avatarsize == small) {
					
					echo "<div class=\"easy_small\">";
						foreach($newest_members as $memb){
							echo "<div class=\"friends_online\">";
							echo elgg_view("profile/icon",array('entity' => $memb, 'size' => $avatarsize));
							echo "</div>";
						}
					echo "</div>";					
					} else if ($avatarsize == tiny) {
					
					echo "<div class=\"easy_tiny\">";
						foreach($newest_members as $memb){
							echo "<div class=\"friends_online\">";
							echo elgg_view("profile/icon",array('entity' => $memb, 'size' => $avatarsize));
							echo "</div>";
						}
					echo "</div>";					
					}
                
			
            ?>
		
<div class="clearfloat"></div>
</div>
</div>

<?php } ?>