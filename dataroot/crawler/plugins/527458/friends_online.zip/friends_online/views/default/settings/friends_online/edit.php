<?php
	/**
	* Avatar Wall - Admin settings
	* 
	* @package avatar_wall
	* @author ColdTrick IT Solutions
	* @copyright Coldtrick IT Solutions 2009
	* @link http://www.coldtrick.com/
	*/
?>
<p>
	<p>
		<b>friends online options</b><br />
		<select name="params[showToolsLink]">
			<option value="yes" <?php if ($vars['entity']->showToolsLink == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
			<option value="no" <?php if ($vars['entity']->showToolsLink == 'no' || empty($vars['entity']->showToolsLink)) echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
		</select>
		<?php echo elgg_echo("Link Wer ist Online in Tools menu anzeigen?");?><br /><br />
	
		<select name="params[showActivityWidget]">
			<option value="yes" <?php if ($vars['entity']->showActivityWidget == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
			<option value="no" <?php if ($vars['entity']->showActivityWidget == 'no' || empty($vars['entity']->showActivityWidget)) echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
		</select>
		<?php echo elgg_echo("Freunde online an der activity seite anzeigen?");?><br /><br />
		
		<select name="params[notOnline]">
			<option value="yes" <?php if ($vars['entity']->notOnline == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
			<option value="no" <?php if ($vars['entity']->notOnline == 'no' || empty($vars['entity']->notOnline)) echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
		</select>
		<?php echo elgg_echo("Widget ausblenden wenn freunde nicht online?");?><br /><br />
		
		<select name="params[showProfileWidget]">
			<option value="yes" <?php if ($vars['entity']->showProfileWidget == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
			<option value="no" <?php if ($vars['entity']->showProfileWidget == 'no' || empty($vars['entity']->showProfileWidget)) echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
		</select>
		<?php echo elgg_echo("Freunde online in profile seite anzeigen?");?><br /><br />
		
		<b>Recent Members options</b><br />
		<select name="params[showRecentWidget]">
			<option value="yes" <?php if ($vars['entity']->showRecentWidget == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
			<option value="no" <?php if ($vars['entity']->showRecentWidget == 'no' || empty($vars['entity']->showRecentWidget)) echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
		</select>
		<?php echo elgg_echo("Recent Members an der activity seite anzeigen?");?><br /><br />
		
		
		<select name="params[wallIconSize]">
			<option value="tiny" <?php if ($vars['entity']->wallIconSize == 'tiny') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('avatar_wall:settings:tiny'); ?></option>
			<option value="small" <?php if ($vars['entity']->wallIconSize == 'small' || empty($vars['entity']->wallIconSize)) echo " selected=\"yes\" "; ?>><?php echo elgg_echo('avatar_wall:settings:small'); ?></option>
			<option value="medium" <?php if ($vars['entity']->wallIconSize == 'medium' || empty($vars['entity']->wallIconSize)) echo " selected=\"yes\" "; ?>><?php echo elgg_echo('Medium'); ?></option>
		</select>
		<?php echo elgg_echo("Show icon size for recent members");?><br /><br />
		
		<input type="text" name="params[maxIcons]" value="<?php if(!empty($vars['entity']->maxIcons)){ echo $vars['entity']->maxIcons; } else { echo "12"; }?>"/><?php echo elgg_echo("Wieviele Bilder sollen angezeigt werden? recent members"); ?>

						
	</p>
</p>
