.friends_online {
	float:left;
	margin:0 4px 4px 0;
}

.easyWrapper {
background:none repeat scroll 0 0 white;
padding:5px;
text-align:center;
}

.easy_medium{
margin:0px auto;
width:100px;
}

.easy_small{
	float:left;
	margin:4px 0 0 3px;
}

.easy_tiny{
	float:left;
	margin:4px 0 0 4px;
}
