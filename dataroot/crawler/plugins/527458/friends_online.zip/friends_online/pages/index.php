<?php
	/**
	* Friends Online
	* 
	* @package friends_online
	* @author Dieter Konrad aka alfalive
	* @copyright Dieter Konrad 2009
	* @link http://community.elgg.org/pg/profile/alfalive
	*/
	
	
	// Load Elgg engine
	include_once dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php";

    // make sure only logged in users can see this page
    gatekeeper();
	
	$title = elgg_echo('friends_online:onlineusers');

	// title at top of main column
	$content = elgg_view_title($title);

	// get the html needed to display freinds_online
    $content .= elgg_view("friends_online/usersonline");




	// layout one column
	$body = elgg_view_layout("one_column", $content);

	// render page and send to requester
	page_draw($title, $body);
?>