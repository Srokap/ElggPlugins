<?php
	/**
	* Friends Online
	* 
	* @package friends_online
	* @author Dieter Konrad aka alfalive
	* @copyright Dieter Konrad 2009
	* @link http://community.elgg.org/pg/profile/alfalive
	*/
	
	$english = array(
		// main titles
		'friends_online:friends' => "Friends Online",
		'friends_online:online' => "Friends who are Online",
		
		//menu item
		'friends_online:onlineusers' => "Who is online",
		
		//List topic
		'friends_online:list' => "List of all users who are online",
		
		'friends_online:nobodyonline' => "No friends online",
		
	);
	
	add_translation("en", $english);
?>
