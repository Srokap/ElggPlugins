<?php
	/**
	* Friends Online
	* 
	* @package friends_online
	* @author Dieter Konrad aka alfalive
	* @copyright Dieter Konrad 2009
	* @link http://community.elgg.org/pg/profile/alfalive
	*/
	
	$german = array(
		// main titles
		'friends_online:friends' => "Freunde Online",
		'friends_online:online' => "Wer ist von Freunden online",
		
		//menu item
		'friends_online:onlineusers' => "Wer ist online",
		
		//List topic
		'friends_online:list' => "Liste aller Online-Benutzer",
		
		'friends_online:nobodyonline' => "Keine Freunde online",
		
		
	);
	
	add_translation("de", $german);
?>
