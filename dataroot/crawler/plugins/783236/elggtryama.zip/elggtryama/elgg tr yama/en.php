<?php
/**
 * Core English Language
 *
 * @package Elgg.Core
 * @subpackage Languages.English
 */

$english = array(
/**
 * Sites
 */

	'item:site' => 'Sites',

/**
 * Sessions
 */

	'login' => "Giriş",
	'loginok' => "Giriş başarıyla yapıldı.",
	'loginerror' => "Girdiğin kullanıcı adı veya şifre yanlış lütfen tekrar deneyin.",
	'login:empty' => "Kullanıcı adı ve şifre gerekli.",
	'login:baduser' => "Kullanıcı hesabınız açılamıyor.",
	'auth:nopams' => "Dahili hata method yüklenemiyor..",

	'logout' => "Çıkış",
	'logoutok' => "Çıkış işlemi başarıyla gerçekleşti.",
	'logouterror' => "Çıkış işlemi başarısız lütfen tekrar deneyin",

	'loggedinrequired' => "Bu sayfayı görebilmek için giriş yapmanız gerekiyor.",
	'adminrequired' => "Bu sayfayı görebilmek için yönetici olmanız gerekiyor.",
	'membershiprequired' => "Bu sayfayı görebilmek için gruba üye olmanız gerekiyor.",


/**
 * Errors
 */
	'exception:title' => "Hata.",

	'actionundefined' => "İstenilen eylem (%s) sistemde tanımlı değil",
	'actionnotfound' => "Eylem dosyası %s bulunamadı.",
	'actionloggedout' => "Üzgünüz, çıkış yaparken bu işlemi gerçekleştiremezsiniz.",
	'actionunauthorized' => 'Bu işlemi gerçekleştirebilmek için yetkili değilsiniz.',

	'InstallationException:SiteNotInstalled' => 'Unable to handle this request. This site '
		. ' is not configured or the database is down.',
	'InstallationException:MissingLibrary' => 'Yüklenemedi %s',
	'InstallationException:CannotLoadSettings' => 'Elgg ayarları dosyası yüklenemedi,dosya yok veya dosya izinleri ayarlı değil.',

	'SecurityException:Codeblock' => "Ayrıcalıklı bir kod bloğu çalıştırmak için erişim engellendi",
	'DatabaseException:WrongCredentials' => "Verilen bilgilerle veritabanına bağlanılamıyor,lütfen tekrar deneyiniz.",
	'DatabaseException:NoConnect' => "Elgg veritabanı seçin '%s', ve lütfen erişim olup olmadığını kontrol edin.",
	'SecurityException:FunctionDenied' => "İşlemde '%s' erişim engellendi",
	'DatabaseException:DBSetupIssues' => "There were a number of issues: ",
	'DatabaseException:ScriptNotFound' => "Elgg için istenen veritabanı dosyası bulunamadı %s.",
	'DatabaseException:InvalidQuery' => "Geçersiz sorgu",

	'IOException:FailedToLoadGUID' => "Yeni yükleme başarısız %s from GUID:%d",
	'InvalidParameterException:NonElggObject' => "Passing a non-ElggObject to an ElggObject constructor!",
	'InvalidParameterException:UnrecognisedValue' => "Tanınmayan değer.",

	'InvalidClassException:NotValidElggStar' => "GUID:%d geçerli bir değildir %s",

	'PluginException:MisconfiguredPlugin' => "%s (guid: %s) is a misconfigured plugin. It has been disabled. Please search the Elgg wiki for possible causes (http://forum.elggturkiye.net/).",
	'PluginException:CannotStart' => '%s (guid: %s) Açamazsınız.  Reason: %s',
	'PluginException:InvalidID' => "%s Geçersiz bir eklenti kimliği",
	'PluginException:InvalidPath' => "%s Geçersiz bir eklenti yolu",
	'PluginException:InvalidManifest' => 'Eklenti için geçersiz bildirim dosyası %s',
	'PluginException:InvalidPlugin' => '%s Geçerli bir eklenti değil.',
	'PluginException:InvalidPlugin:Details' => '%s Geçerli bir eklenti değil: %s',

	'ElggPlugin:MissingID' => 'Eksik eklenti ID (guid %s)',
	'ElggPlugin:NoPluginPackagePackage' => 'Missing ElggPluginPackage for plugin ID %s (guid %s)',

	'ElggPluginPackage:InvalidPlugin:MissingFile' => 'Eksik dosya %s paketi',
	'ElggPluginPackage:InvalidPlugin:InvalidDependency' => 'Geçersiz bağımlılık türü "%s"',
	'ElggPluginPackage:InvalidPlugin:InvalidProvides' => 'Geçersiz sağlayıcı türü "%s"',
	'ElggPluginPackage:InvalidPlugin:CircularDep' => 'Invalid %s dependency "%s" in plugin %s.  Plugins cannot conflict with or require something they provide!',

	'ElggPlugin:Exception:CannotIncludeFile' => 'Cannot include %s for plugin %s (guid: %s) at %s.  Check permissions!',
	'ElggPlugin:Exception:CannotRegisterViews' => 'Cannot open views dir for plugin %s (guid: %s) at %s.  Check permissions!',
	'ElggPlugin:Exception:CannotRegisterLanguages' => 'Cannot register languages for plugin %s (guid: %s) at %s.  Check permissions!',
	'ElggPlugin:Exception:NoID' => 'No ID for plugin guid %s!',

	'PluginException:ParserError' => 'Error parsing manifest with API version %s in plugin %s.',
	'PluginException:NoAvailableParser' => 'Cannot find a parser for manifest API version %s in plugin %s.',
	'PluginException:ParserErrorMissingRequiredAttribute' => "Missing required '%s' attribute in manifest for plugin %s.",

	'ElggPlugin:Dependencies:Requires' => 'Requires',
	'ElggPlugin:Dependencies:Suggests' => 'Suggests',
	'ElggPlugin:Dependencies:Conflicts' => 'Conflicts',
	'ElggPlugin:Dependencies:Conflicted' => 'Conflicted',
	'ElggPlugin:Dependencies:Provides' => 'Provides',
	'ElggPlugin:Dependencies:Priority' => 'Priority',

	'ElggPlugin:Dependencies:Elgg' => 'Elgg version',
	'ElggPlugin:Dependencies:PhpExtension' => 'PHP extension: %s',
	'ElggPlugin:Dependencies:PhpIni' => 'PHP ini setting: %s',
	'ElggPlugin:Dependencies:Plugin' => 'Plugin: %s',
	'ElggPlugin:Dependencies:Priority:After' => 'After %s',
	'ElggPlugin:Dependencies:Priority:Before' => 'Before %s',
	'ElggPlugin:Dependencies:Priority:Uninstalled' => '%s is not installed',
	'ElggPlugin:Dependencies:Suggests:Unsatisfied' => 'Missing',


	'InvalidParameterException:NonElggUser' => "Passing a non-ElggUser to an ElggUser constructor!",

	'InvalidParameterException:NonElggSite' => "Passing a non-ElggSite to an ElggSite constructor!",

	'InvalidParameterException:NonElggGroup' => "Passing a non-ElggGroup to an ElggGroup constructor!",

	'IOException:UnableToSaveNew' => "Unable to save new %s",

	'InvalidParameterException:GUIDNotForExport' => "GUID has not been specified during export, this should never happen.",
	'InvalidParameterException:NonArrayReturnValue' => "Entity serialisation function passed a non-array returnvalue parameter",

	'ConfigurationException:NoCachePath' => "Cache path set to nothing!",
	'IOException:NotDirectory' => "%s is not a directory.",

	'IOException:BaseEntitySaveFailed' => "Unable to save new object's base entity information!",
	'InvalidParameterException:UnexpectedODDClass' => "import() passed an unexpected ODD class",
	'InvalidParameterException:EntityTypeNotSet' => "Entity type must be set.",

	'ClassException:ClassnameNotClass' => "%s is not a %s.",
	'ClassNotFoundException:MissingClass' => "Class '%s' was not found, missing plugin?",
	'InstallationException:TypeNotSupported' => "Type %s is not supported. This indicates an error in your installation, most likely caused by an incomplete upgrade.",

	'ImportException:ImportFailed' => "Could not import element %d",
	'ImportException:ProblemSaving' => "There was a problem saving %s",
	'ImportException:NoGUID' => "New entity created but has no GUID, this should not happen.",

	'ImportException:GUIDNotFound' => "Entity '%d' could not be found.",
	'ImportException:ProblemUpdatingMeta' => "There was a problem updating '%s' on entity '%d'",

	'ExportException:NoSuchEntity' => "No such entity GUID:%d",

	'ImportException:NoODDElements' => "No OpenDD elements found in import data, import failed.",
	'ImportException:NotAllImported' => "Not all elements were imported.",

	'InvalidParameterException:UnrecognisedFileMode' => "Unrecognised file mode '%s'",
	'InvalidParameterException:MissingOwner' => "File %s (file guid:%d) (owner guid:%d) is missing an owner!",
	'IOException:CouldNotMake' => "Could not make %s",
	'IOException:MissingFileName' => "You must specify a name before opening a file.",
	'ClassNotFoundException:NotFoundNotSavedWithFile' => "Unable to load filestore class %s for file %u",
	'NotificationException:NoNotificationMethod' => "No notification method specified.",
	'NotificationException:NoHandlerFound' => "No handler found for '%s' or it was not callable.",
	'NotificationException:ErrorNotifyingGuid' => "There was an error while notifying %d",
	'NotificationException:NoEmailAddress' => "Could not get the email address for GUID:%d",
	'NotificationException:MissingParameter' => "Missing a required parameter, '%s'",

	'DatabaseException:WhereSetNonQuery' => "Where set contains non WhereQueryComponent",
	'DatabaseException:SelectFieldsMissing' => "Fields missing on a select style query",
	'DatabaseException:UnspecifiedQueryType' => "Unrecognised or unspecified query type.",
	'DatabaseException:NoTablesSpecified' => "No tables specified for query.",
	'DatabaseException:NoACL' => "No access control was provided on query",

	'InvalidParameterException:NoEntityFound' => "No entity found, it either doesn't exist or you don't have access to it.",

	'InvalidParameterException:GUIDNotFound' => "GUID:%s could not be found, or you can not access it.",
	'InvalidParameterException:IdNotExistForGUID' => "Sorry, '%s' does not exist for guid:%d",
	'InvalidParameterException:CanNotExportType' => "Sorry, I don't know how to export '%s'",
	'InvalidParameterException:NoDataFound' => "Could not find any data.",
	'InvalidParameterException:DoesNotBelong' => "Does not belong to entity.",
	'InvalidParameterException:DoesNotBelongOrRefer' => "Does not belong to entity or refer to entity.",
	'InvalidParameterException:MissingParameter' => "Missing parameter, you need to provide a GUID.",
	'InvalidParameterException:LibraryNotRegistered' => '%s is not a registered library',

	'APIException:ApiResultUnknown' => "API Result is of an unknown type, this should never happen.",
	'ConfigurationException:NoSiteID' => "No site ID has been specified.",
	'SecurityException:APIAccessDenied' => "Sorry, API access has been disabled by the administrator.",
	'SecurityException:NoAuthMethods' => "No authentication methods were found that could authenticate this API request.",
	'SecurityException:UnexpectedOutputInGatekeeper' => 'Unexpected output in gatekeeper call. Halting execution for security. Search http://forum.elggturkiye.net/ for more information.',
	'InvalidParameterException:APIMethodOrFunctionNotSet' => "Method or function not set in call in expose_method()",
	'InvalidParameterException:APIParametersArrayStructure' => "Parameters array structure is incorrect for call to expose method '%s'",
	'InvalidParameterException:UnrecognisedHttpMethod' => "Unrecognised http method %s for api method '%s'",
	'APIException:MissingParameterInMethod' => "Missing parameter %s in method %s",
	'APIException:ParameterNotArray' => "%s does not appear to be an array.",
	'APIException:UnrecognisedTypeCast' => "Unrecognised type in cast %s for variable '%s' in method '%s'",
	'APIException:InvalidParameter' => "Invalid parameter found for '%s' in method '%s'.",
	'APIException:FunctionParseError' => "%s(%s) has a parsing error.",
	'APIException:FunctionNoReturn' => "%s(%s) returned no value.",
	'APIException:APIAuthenticationFailed' => "Method call failed the API Authentication",
	'APIException:UserAuthenticationFailed' => "Method call failed the User Authentication",
	'SecurityException:AuthTokenExpired' => "Authentication token either missing, invalid or expired.",
	'CallException:InvalidCallMethod' => "%s must be called using '%s'",
	'APIException:MethodCallNotImplemented' => "Method call '%s' has not been implemented.",
	'APIException:FunctionDoesNotExist' => "Function for method '%s' is not callable",
	'APIException:AlgorithmNotSupported' => "Algorithm '%s' is not supported or has been disabled.",
	'ConfigurationException:CacheDirNotSet' => "Cache directory 'cache_path' not set.",
	'APIException:NotGetOrPost' => "Request method must be GET or POST",
	'APIException:MissingAPIKey' => "Missing API key",
	'APIException:BadAPIKey' => "Bad API key",
	'APIException:MissingHmac' => "Missing X-Elgg-hmac header",
	'APIException:MissingHmacAlgo' => "Missing X-Elgg-hmac-algo header",
	'APIException:MissingTime' => "Missing X-Elgg-time header",
	'APIException:MissingNonce' => "Missing X-Elgg-nonce header",
	'APIException:TemporalDrift' => "X-Elgg-time is too far in the past or future. Epoch fail.",
	'APIException:NoQueryString' => "No data on the query string",
	'APIException:MissingPOSTHash' => "Missing X-Elgg-posthash header",
	'APIException:MissingPOSTAlgo' => "Missing X-Elgg-posthash_algo header",
	'APIException:MissingContentType' => "Missing content type for post data",
	'SecurityException:InvalidPostHash' => "POST data hash is invalid - Expected %s but got %s.",
	'SecurityException:DupePacket' => "Packet signature already seen.",
	'SecurityException:InvalidAPIKey' => "Invalid or missing API Key.",
	'NotImplementedException:CallMethodNotImplemented' => "Call method '%s' is currently not supported.",

	'NotImplementedException:XMLRPCMethodNotImplemented' => "XML-RPC method call '%s' not implemented.",
	'InvalidParameterException:UnexpectedReturnFormat' => "Call to method '%s' returned an unexpected result.",
	'CallException:NotRPCCall' => "Call does not appear to be a valid XML-RPC call",

	'PluginException:NoPluginName' => "The plugin name could not be found",

	'SecurityException:authenticationfailed' => "User could not be authenticated",

	'CronException:unknownperiod' => '%s is not a recognised period.',

	'SecurityException:deletedisablecurrentsite' => 'You can not delete or disable the site you are currently viewing!',

	'RegistrationException:EmptyPassword' => 'The password fields cannot be empty',
	'RegistrationException:PasswordMismatch' => 'Passwords must match',
	'LoginException:BannedUser' => 'You have been banned from this site and cannot log in',
	'LoginException:UsernameFailure' => 'We could not log you in. Please check your username and password.',
	'LoginException:PasswordFailure' => 'We could not log you in. Please check your username and password.',
	'LoginException:AccountLocked' => 'Your account has been locked for too many log in failures.',

	'memcache:notinstalled' => 'PHP memcache module not installed, you must install php5-memcache',
	'memcache:noservers' => 'No memcache servers defined, please populate the $CONFIG->memcache_servers variable',
	'memcache:versiontoolow' => 'Memcache needs at least version %s to run, you are running %s',
	'memcache:noaddserver' => 'Multiple server support disabled, you may need to upgrade your PECL memcache library',

	'deprecatedfunction' => 'Warning: This code uses the deprecated function \'%s\' and is not compatible with this version of Elgg',

	'pageownerunavailable' => 'Warning: The page owner %d is not accessible!',
	'viewfailure' => 'There was an internal failure in the view %s',
	'changebookmark' => 'Please change your bookmark for this page',
/**
 * API
 */
	'system.api.list' => "List all available API calls on the system.",
	'auth.gettoken' => "This API call lets a user obtain a user authentication token which can be used for authenticating future API calls. Pass it as the parameter auth_token",

/**
 * User details
 */

	'name' => "Görünen Isim",
	'email' => "Email Adresi",
	'username' => "Kullanıcı Adı",
	'loginusername' => "Kullanıcı adı veya email",
	'password' => "Şifre",
	'passwordagain' => "Şifre (Doğrulamak için tekrar giriniz)",
	'admin_option' => "Make this user an admin?",

/**
 * Access
 */

	'PRIVATE' => "Özel",
	'LOGGED_IN' => "Logged in users",
	'PUBLIC' => "Public",
	'access:friends:label' => "Friends",
	'access' => "Access",

/**
 * Dashboard and widgets
 */

	'dashboard' => "Kontrol Paneli",
	'dashboard:nowidgets' => "Sizin için önemli olan araçları buraya yerleştirebilirsiniz.",

	'widgets:add' => 'Yeni widgets ekle',
	'widgets:add:description' => "Sayfa eklemek için aşağıdaki herhangi bir widget butonunu tıklayın.",
	'widgets:position:fixed' => '(Sayfa sabit pozisyon)',
	'widget:unavailable' => 'Zaten bu widgets ekledin',
	'widget:numbertodisplay' => 'Gösterilecek öğe sayısı',

	'widget:delete' => 'Sil %s',
	'widget:edit' => 'Bu widgets özelleştirin',

	'widgets' => "Widgetlar",
	'widget' => "Widget",
	'item:object:widget' => "Widgets",
	'widgets:save:success' => "Widget başarılı bir şekilde kayıt edildi",
	'widgets:save:failure' => "Widget kayıt edilemedi. Lütfen tekrar deneyin.",
	'widgets:add:success' => "Widget başarıyla eklendi.",
	'widgets:add:failure' => "Widget eklenemedi.",
	'widgets:move:failure' => "widget pozisyonları saklanamadı.",
	'widgets:remove:failure' => "Widget kaldırılamıyor.",

/**
 * Groups
 */

	'group' => "Grup",
	'item:group' => "Gruplar",

/**
 * Users
 */

	'user' => "Üye",
	'item:user' => "Üyeler",

/**
 * Friends
 */

	'friends' => "Arkadaşlar",
	'friends:yours' => "Senin Arkadaşların",
	'friends:owned' => "%s's arkadaşları",
	'friend:add' => "Arkadaş olarak ekle",
	'friend:remove' => "Arkadaşlıkdan çıkar",

	'friends:add:successful' => "Başarılı bir şekilde arkadaş %s olarak eklendi",
	'friends:add:failure' => "Arkadaş olarak %seklenemiyor. Lütfen tekrar deneyin.",

	'friends:remove:successful' => "Arkadaşlık listenizden %s kaldırdınız",
	'friends:remove:failure' => "Arkadaşınız %s silinemiyor. Lütfen tekrar deneyiniz",

	'friends:none' => "Bu kullanıcıya henüz arkadaş olarak kimse yazmamış.",
	'friends:none:you' => "Bu kullanıcının henüz arkadaşı yok.",

	'friends:none:found' => "Arkadaş bulundu.",

	'friends:of:none' => "Bu kullanıcı arkadaş olarak eklendi.",
	'friends:of:none:you' => " Henüz bir arkadaşınız yok,profilinizi doldurun ve birşeyler paylaşın ",

	'friends:of:owned' => "%s Arkadaş olarak eklemiş kişiler",

	'friends:of' => "Arkadaşları",
	'friends:collections' => "Arkadaş listesi",
	'collections:add' => "Yeni liste",
	'friends:collections:add' => "Yeni arkadaş listesi",
	'friends:addfriends' => "Arkadaşlarınızı Seçin",
	'friends:collectionname' => "Liste adı",
	'friends:collectionfriends' => "Listende dostların",
	'friends:collectionedit' => "Listeni düzenle",
	'friends:nocollections' => "Henüz herhangi bir listesi yok.",
	'friends:collectiondeleted' => "Listen silindi.",
	'friends:collectiondeletefailed' => "Listeniz silinemedi,herhangi bir hata oluştu lütfen daha sonra tekrar deneyiniz.",
	'friends:collectionadded' => "Yeni liste oluşturuldu",
	'friends:nocollectionname' => "Listeyi oluşturmadan önce bir isim vermeniz gerekiyor.",
	'friends:collections:members' => "Liste üyeleri",
	'friends:collections:edit' => "Listeyi düzelt",

	'friendspicker:chararray' => 'ABCÇDEFGĞHIİJKLMNOÖPQRSŞTUVWXYZ',

	'avatar' => 'Profil',
	'avatar:create' => 'Yeni Profil oluşturma',
	'avatar:edit' => 'Profil resmini düzelt',
	'avatar:preview' => 'Önizleme',
	'avatar:upload' => 'Yeni Profil Resmi Seçin',
	'avatar:current' => 'Geçerli Profil',
	'avatar:crop:title' => 'Profil kırpma aracı',
	'avatar:upload:instructions' => "Profilinizde fotorafınız görülebilir. Daha sonra istediğiniz gibi değiştirebilirsiniz (Bu dosya formatlarını kabul etmekteyiz: GIF, JPG or PNG)",
	'avatar:create:instructions' => 'Resmin önizlemesi üzerinde istediğiniz şekilde kırpma yapabilirsiniz',
	'avatar:upload:success' => 'Profil resmi yüklendi',
	'avatar:upload:fail' => 'Profil resmi yüklenemedi',
	'avatar:resize:fail' => 'Profili boyutlandırma başarısız oldu',
	'avatar:crop:success' => 'Kırpma başarılı oldu',
	'avatar:crop:fail' => 'Kırpma başarısız oldu',

	'profile:edit' => 'Profil Bilgilerini Düzelt',
	'profile:aboutme' => "Hakkımda",
	'profile:description' => "Hakkımda",
	'profile:briefdescription' => "Kısa açıklama",
	'profile:location' => "Bulunduğun yer",
	'profile:skills' => "Becerilerin",
	'profile:interests' => "İlgi Alanların",
	'profile:contactemail' => "Email",
	'profile:phone' => "Telefon",
	'profile:mobile' => "Cep Telefonu",
	'profile:website' => "Website",
	'profile:twitter' => "Twitter kullanıcı adın",
	'profile:saved' => "Profil bilgilerin başarıyla kayıt edildi",

	'admin:appearance:profile_fields' => 'Profil bilgi alanlarını düzenle',
	'profile:edit:default' => 'Profil bilgi alanlarını düzenleyin',
	'profile:label' => "Profil Etiketi",
	'profile:type' => "Profil Tipi",
	'profile:editdefault:delete:fail' => 'Profil kaldırma başarısız oldu',
	'profile:editdefault:delete:success' => 'Profil silindi.',
	'profile:defaultprofile:reset' => 'Sistem profili yeniledi.',
	'profile:resetdefault' => 'Profili sıfırla.',
	'profile:explainchangefields' => "Aşağıdaki formu kullanarak kendi mevcut profili alanlarını değiştirebilirsiniz. \ n \ n yeni bir profil alanında bir etiket verin, örneğin, 'En sevdiğim takım', daha sonra alan türü (örneğin, metin, url, etiketler) seçin ve 'Ekle' düğmesini tıklatın. Alanları yeniden sipariş alan etiket yanındaki kolu sürükleyin. Alan etiketini düzenlemek için etiket metin düzenlenebilir yapmak için tıklayın. Herhangi bir zamanda kurmak varsayılan profil geri dönebilirsiniz \ n \ n, ama sen zaten profil sayfaları özel alanlara girilen herhangi bir bilgi kaybedersiniz.",
	'profile:editdefault:success' => 'Öğe başarılı bir şekilde profile eklendi',
	'profile:editdefault:fail' => 'Öğe kaydı başarısız oldu',


/**
 * Feeds
 */
	'feed:rss' => 'Bu sayfa için RSS beslemesi',
/**
 * Links
 */
	'link:view' => 'Bağlantıyı görüntüle',
	'link:view:all' => 'Bütün bağlantıları görüntüle',


/**
 * River
 */
	'river' => "River",
	'river:friend:user:default' => "%s şimdi arkadaş %s",
	'river:update:user:avatar' => '%s yeni profil resmi',
	'river:noaccess' => 'Bu öğeyi görebilmek için izniniz yok.',
	'river:posted:generic' => '%s Mesaj',
	'riveritem:single:user' => 'kullanıcı',
	'riveritem:plural:user' => 'bazı kullanıcılar',
	'river:ingroup' => 'Gruptaki %s',
	'river:none' => 'Bir etkinlik yok',

	'river:widget:title' => "Etkinlik",
	'river:widget:description' => "Son etkinliği görüntüle",
	'river:widget:type' => "Faaliyet türü",
	'river:widgets:friends' => 'Arkadaşların etkinlikleri',
	'river:widgets:all' => 'Sitedeki etkinlikler',

/**
 * Notifications
 */
	'notifications:usersettings' => "Bildirim ayarları",
	'notifications:methods' => "İzin vermek istediğiniz bildirimleri seçiniz.",

	'notifications:usersettings:save:ok' => "Bildirim ayarlarınız başarıyla kaydedildi.",
	'notifications:usersettings:save:fail' => "Bildirim ayarlarınızı kaydedemiyoruz.Lütfen tekrar deneyin",

	'user.notification.get' => 'Belirli bir kişi için bildirim ayarlarını düzenle',
	'user.notification.set' => 'Belirli bir kişi için bildirim ayarlarını belirleyin.',
/**
 * Search
 */

	'search' => "Arama",
	'searchtitle' => "Arama: %s",
	'users:searchtitle' => "Aranan kullanıcı: %s",
	'groups:searchtitle' => "Aranan Grup: %s",
	'advancedsearchtitle' => "%s Sonuçlarla eşleşen %s",
	'notfound' => "Sonuç bulunamadı",
	'next' => "İleri",
	'previous' => "Geri",

	'viewtype:change' => "Liste Türü Değiştir",
	'viewtype:list' => "Liste görüntüle",
	'viewtype:gallery' => "Galeri",

	'tag:search:startblurb' => "Eşleşen etiketler '%s':",

	'user:search:startblurb' => "Eşleşen kullanıcılar '%s':",
	'user:search:finishblurb' => "Daha fazlasını görmek için,burayı tıklayın",

	'group:search:startblurb' => "Eşleşen Gruplar '%s':",
	'group:search:finishblurb' => "Daha fazlasını görmek için,burayı tıklayın",
	'search:go' => 'Git',
	'userpicker:only_friends' => 'Sadece Arkadaşlar',

/**
 * Account
 */

	'account' => "Hesap",
	'settings' => "Ayarlar",
	'tools' => "Araçlar",

	'register' => "Kayıt",
	'registerok' => "Başarılı bir şekilde kayıt oldunuz %s.",
	'registerbad' => "Kaydınız bilinmeyen bir hata nedeniyle başarısız oldu",
	'registerdisabled' => "Kayıt sistem yöneticisi tarafından devre dışı bırakılmıştır",

	'registration:notemail' => 'Verdiğiniz e-posta adresi geçerli değildir.',
	'registration:userexists' => 'Bu kullanıcı adı kullanılıyor',
	'registration:usernametooshort' => 'Kullanıcı adınız en az %u karakter olmalıdır',
	'registration:passwordtooshort' => 'Şifreniz en az %u karakter olmalıdır.',
	'registration:dupeemail' => 'Bu e-posta adresi zaten kullanılıyor.',
	'registration:invalidchars' => 'Üzgünüz kullanıcı adınız geçersiz bir karater içeriyor: %s. Tüm bu karakterler geçersizdir: %s',
	'registration:emailnotvalid' => 'Üzgünüz girdiğini e-posta adresi bu sistemde geçersiz',
	'registration:passwordnotvalid' => 'Üzgünüz, girdiğiniz şifre, bu sistem üzerinde geçersiz',
	'registration:usernamenotvalid' => 'Üzgünüz,girdiğiniz kullanıcı,bu sistem üzerinde geçersiz',

	'adduser' => "Kullanıcı ekle",
	'adduser:ok' => "Yeni kullanıcı başarıyla eklendi",
	'adduser:bad' => "Yeni kullanıcı ekleme sırasında bir hata oluştu.",

	'user:set:name' => "Hesap Adı Ayarı",
	'user:name:label' => "Görünen İsim",
	'user:name:success' => "Başarıyla Adın değişti.",
	'user:name:fail' => "Adını değiştirirken sistemde bilinmeyen bir aksaklık oldu,lütfen tekrar deneyin.",

	'user:set:password' => "Hesap Şifre Değişikliği",
	'user:current_password:label' => 'Mevcut şifre',
	'user:password:label' => "Yeni Şifre",
	'user:password2:label' => "Yeni Şifreyi tekrar giriniz",
	'user:password:success' => "Parola değiştirildi",
	'user:password:fail' => "Parola değiştirmede bir hata oluştu.",
	'user:password:fail:notsame' => "İki şifre aynı değil!",
	'user:password:fail:tooshort' => "Parola çok kısa!",
	'user:password:fail:incorrect_current_password' => 'Girilen Şifre yanlış',
	'user:resetpassword:unknown_user' => 'Geçersiz Kullanıcı',
	'user:resetpassword:reset_password_confirm' => 'Şifrenizi kayıtlı olduğunuz adrese gönderdik lütfen onaylayın.',

	'user:set:language' => "Dil Ayaları",
	'user:language:label' => "Sizin Diliniz",
	'user:language:success' => "Dil ayarlarınız güncellendi",
	'user:language:fail' => "Dil ayarlarınızı kaydederken sorun oluştu..",

	'user:username:notfound' => 'Kullanıcı Adı %s bulunamadı',

	'user:password:lost' => 'Şifremi unuttum',
	'user:password:resetreq:success' => 'Başarıyla şifre e-posta adresinize gönderildi.',
	'user:password:resetreq:fail' => 'Yeni bir şifre talep edilemedi.',

	'user:password:text' => 'Yeni bir şifre istemek için, lütfen aşağıya kullanıcı adınızı girin ve İstek düğmesini tıklayın',

	'user:persistent' => 'Beni Hatırla',

	'walled_garden:welcome' => 'Hoşgeldiniz',

/**
 * Administration
 */
	'menu:page:header:administer' => 'Yönetici',
	'menu:page:header:configure' => 'Yapılandırma',
	'menu:page:header:develop' => 'Geliştirme',
	'menu:page:header:default' => 'Diğerleri',

	'admin:view_site' => 'Siteyi Görüntüle',
	'admin:loggedin' => 'Olarak oturum %s',
	'admin:menu' => 'Menü',

	'admin:configuration:success' => "Ayarlarınız kaydedildi",
	'admin:configuration:fail' => "Ayarlarınızı kaydedilemedi",

	'admin:unknown_section' => 'Geçersiz Yönetici Bölümü.',

	'admin' => "Yönetici",
	'admin:description' => "Admin Panelinde,kullanıcı yönetimi,elentileri,sistemin tüm yönlerini kontrol edebilirsin.Başlamak için aşağıdan birisini seçin",

	'admin:statistics' => "İstatistikler",
	'admin:statistics:overview' => 'Genel Bakış',

	'admin:appearance' => 'Görünüm',
	'admin:utilities' => 'Kamu Hizmetleri',

	'admin:users' => "Kullanıcılar",
	'admin:users:online' => 'Çevirimiçi Kullanıcılar',
	'admin:users:newest' => 'En Yeni',
	'admin:users:add' => 'Yeni Üye Ekle',
	'admin:users:description' => "Bu admin panelinden siteniz için kullanıcı ayarlarını kontrol etmenizi sağlar. Başlamak için aşağıda bir seçenek seçin.",
	'admin:users:adduser:label' => "Yeni bir kullanıcı eklemek için buraya tıklayın...",
	'admin:users:opt:linktext' => "Kullanıcıları yapılandırın...",
	'admin:users:opt:description' => "Kullanıcılar ve hesap bilgilerini yapılandırın. ",
	'admin:users:find' => 'Bul',

	'admin:settings' => 'Ayarlar',
	'admin:settings:basic' => 'Basit Ayarlar',
	'admin:settings:advanced' => 'Gelişmiş Ayarlar',
	'admin:site:description' => "Bu admin panelinden siteniz için genel ayarları kontrol etmenizi sağlar. Başlamak için aşağıda bir seçenek seçin.",
	'admin:site:opt:linktext' => "Siteyi yapılandırın...",
	'admin:site:access:warning' => "Erişim ayarı değiştirmek, yalnızca gelecekte oluşturulan içerik izinleri etkiler.",

	'admin:dashboard' => 'Kontrol Paneli',
	'admin:widget:online_users' => 'Çevirimiçi Kullanıcılar',
	'admin:widget:online_users:help' => 'Şuanda sitede olan kullanıcıları listele',
	'admin:widget:new_users' => 'Yeni kullanıcılar',
	'admin:widget:new_users:help' => 'En yeni kullanıcıları listele',
	'admin:widget:content_stats' => 'İçerik İstatistikleri',
	'admin:widget:content_stats:help' => 'Kullanıcılar tarafından yaratılan içerikleri takip edin',
	'widget:content_stats:type' => 'İçeri Türü',
	'widget:content_stats:number' => 'Numara',

	'admin:widget:admin_welcome' => 'Hoşgeldin',
	'admin:widget:admin_welcome:help' => "Admin alanına giriş :)",
	'admin:widget:admin_welcome:intro' =>
'Hoşgeldiniz.',

	'admin:widget:admin_welcome:admin_overview' =>
"Navigasyon için yönetim alanı sağ menü ile sağlanır."
. " Üç bölümden oluşur:
	<dl>
		<dt>Yönetmek</dt><dd>Günlük Kontroller,çevirimiçi bakımlar vb.</dd>
		<dt>Yapılandırma</dt><dd>Nadiren site adını veya bir eklenti aktive gibi görevler.</dd>
		<dt>Geliştirmek</dt><dd>Eklentileri bina veya temalar tasarımı geliştiricileri için. (Bir geliştirici eklentisi gerektirir.)</dd>
	</dl>
	",

	// argh, this is ugly
	'admin:widget:admin_welcome:outro' => '<br />Elgg Bize teşekkür ediyor :)!',

	'admin:footer:faq' => 'Yönetim SSS',
	'admin:footer:manual' => 'Yönetim Elle',
	'admin:footer:community_forums' => 'Elgg Toplum Forumu',
	'admin:footer:blog' => 'Elgg Blog',

	'admin:plugins:category:all' => 'Tüm Eklentiler',
	'admin:plugins:category:active' => 'Aktif Eklentiler',
	'admin:plugins:category:inactive' => 'İnaktif Eklentiler',
	'admin:plugins:category:admin' => 'Yönetici',
	'admin:plugins:category:bundled' => 'Hediye',
	'admin:plugins:category:content' => 'İçerik',
	'admin:plugins:category:development' => 'Gelişme',
	'admin:plugins:category:enhancement' => 'Donanımlar',
	'admin:plugins:category:api' => 'Servis / API',
	'admin:plugins:category:communication' => 'İletişim',
	'admin:plugins:category:security' => 'Güvenlik ve Spam',
	'admin:plugins:category:social' => 'Sosyal',
	'admin:plugins:category:multimedia' => 'Multimedia',
	'admin:plugins:category:theme' => 'Temalar',
	'admin:plugins:category:widget' => 'Widgets',

	'admin:plugins:sort:priority' => 'Öncelik',
	'admin:plugins:sort:alpha' => 'Alfabetik',
	'admin:plugins:sort:date' => 'En Yeni',

	'admin:plugins:markdown:unknown_plugin' => 'Bilinmeyen eklenti.',
	'admin:plugins:markdown:unknown_file' => 'Bilinmeyen dosya.',


	'admin:notices:could_not_delete' => 'Haber silinemedi.',

	'admin:options' => 'Yönetici Ayarları',


/**
 * Plugins
 */
	'plugins:settings:save:ok' => " %s eklentisi başarıyla kaydedildi",
	'plugins:settings:save:fail' => "%s eklentiyi yüklerken bilinmeyen bir problemle karşılaşıldı",
	'plugins:usersettings:save:ok' => "Kullanıcı ayarları %s eklentisi başarıyla yüklendi",
	'plugins:usersettings:save:fail' => "%s eklentiyi yüklerken bilinmeyen bir problemle karşılaşıldı",
	'item:object:plugin' => 'Eklentiler',

	'admin:plugins' => "Eklentiler",
	'admin:plugins:activate_all' => 'Hepsini Etkinleştir',
	'admin:plugins:deactivate_all' => 'Hepsini Devredışı bırak',
	'admin:plugins:activate' => 'Etkinleştir',
	'admin:plugins:deactivate' => 'Devredışı Bırak',
	'admin:plugins:description' => "Bu admin panelinde sitenizde yüklü araçları kontrol etmenizi ve yapılandırmanıza olanak sağlar..",
	'admin:plugins:opt:linktext' => "Araç yapılandırma...",
	'admin:plugins:opt:description' => "Bu sitede yüklü olan araçları yapılandırın. ",
	'admin:plugins:label:author' => "Yazar",
	'admin:plugins:label:copyright' => "Telif Hakkı",
	'admin:plugins:label:categories' => 'Kategoriler',
	'admin:plugins:label:licence' => "Lisans",
	'admin:plugins:label:website' => "URL",
	'admin:plugins:label:moreinfo' => 'Daha fazla bilgi',
	'admin:plugins:label:version' => 'Version',
	'admin:plugins:label:location' => 'Konum',
	'admin:plugins:label:dependencies' => 'Bağımlılıklar',

	'admin:plugins:warning:elgg_version_unknown' => 'This plugin uses a legacy manifest file and does not specify a compatible Elgg version. It probably will not work!',
	'admin:plugins:warning:unmet_dependencies' => 'This plugin has unmet dependencies and cannot be activated. Check dependencies under more info.',
	'admin:plugins:warning:invalid' => '%s is not a valid Elgg plugin.  Check <a href="http://forum.elggturkiye.net">the Elgg documentation</a> for troubleshooting tips.',
	'admin:plugins:cannot_activate' => 'cannot activate',

	'admin:plugins:set_priority:yes' => "Reordered %s.",
	'admin:plugins:set_priority:no' => "Could not reorder %s.",
	'admin:plugins:deactivate:yes' => "Deactivated %s.",
	'admin:plugins:deactivate:no' => "Could not deactivate %s.",
	'admin:plugins:activate:yes' => "Activated %s.",
	'admin:plugins:activate:no' => "Could not activate %s.",
	'admin:plugins:categories:all' => 'All categories',
	'admin:plugins:plugin_website' => 'Plugin website',
	'admin:plugins:author' => '%s',
	'admin:plugins:version' => 'Version %s',
	'admin:plugins:simple' => 'Simple',
	'admin:plugins:advanced' => 'Advanced',
	'admin:plugin_settings' => 'Plugin Settings',
	'admin:plugins:simple_simple_fail' => 'Could not save settings.',
	'admin:plugins:simple_simple_success' => 'Settings saved.',
	'admin:plugins:simple:cannot_activate' => 'Cannot activate this plugin. Check the advanced plugin admin area for more information.',
	'admin:plugins:warning:unmet_dependencies_active' => 'This plugin is active but has unmet dependencies. You may encounter problems. See "more info" below for details.',

	'admin:plugins:dependencies:type' => 'Type',
	'admin:plugins:dependencies:name' => 'Name',
	'admin:plugins:dependencies:expected_value' => 'Tested Value',
	'admin:plugins:dependencies:local_value' => 'Actual value',
	'admin:plugins:dependencies:comment' => 'Comment',

	'admin:statistics:description' => "This is an overview of statistics on your site. If you need more detailed statistics, a professional administration feature is available.",
	'admin:statistics:opt:description' => "View statistical information about users and objects on your site.",
	'admin:statistics:opt:linktext' => "View statistics...",
	'admin:statistics:label:basic' => "Basic site statistics",
	'admin:statistics:label:numentities' => "Entities on site",
	'admin:statistics:label:numusers' => "Number of users",
	'admin:statistics:label:numonline' => "Number of users online",
	'admin:statistics:label:onlineusers' => "Users online now",
	'admin:statistics:label:version' => "Elgg version",
	'admin:statistics:label:version:release' => "Release",
	'admin:statistics:label:version:version' => "Version",

	'admin:user:label:search' => "Find users:",
	'admin:user:label:searchbutton' => "Search",

	'admin:user:ban:no' => "Can not ban user",
	'admin:user:ban:yes' => "User banned.",
	'admin:user:self:ban:no' => "You cannot ban yourself",
	'admin:user:unban:no' => "Can not unban user",
	'admin:user:unban:yes' => "User unbanned.",
	'admin:user:delete:no' => "Can not delete user",
	'admin:user:delete:yes' => "The user %s has been deleted",
	'admin:user:self:delete:no' => "You cannot delete yourself",

	'admin:user:resetpassword:yes' => "Password reset, user notified.",
	'admin:user:resetpassword:no' => "Password could not be reset.",

	'admin:user:makeadmin:yes' => "User is now an admin.",
	'admin:user:makeadmin:no' => "We could not make this user an admin.",

	'admin:user:removeadmin:yes' => "User is no longer an admin.",
	'admin:user:removeadmin:no' => "We could not remove administrator privileges from this user.",
	'admin:user:self:removeadmin:no' => "You cannot remove your own administrator privileges.",

	'admin:appearance:menu_items' => 'Menu Items',
	'admin:menu_items:configure' => 'Configure main menu items',
	'admin:menu_items:description' => 'Select which menu items you want to show as featured links.  Unused items will be added as "More" at the end of the list.',
	'admin:menu_items:hide_toolbar_entries' => 'Remove links from tool bar menu?',
	'admin:menu_items:saved' => 'Menu items saved.',
	'admin:add_menu_item' => 'Add a custom menu item',
	'admin:add_menu_item:description' => 'Fill out the Display name and URL to add custom items to your navigation menu.',

	'admin:appearance:default_widgets' => 'Default Widgets',
	'admin:default_widgets:unknown_type' => 'Unknown widget type',
	'admin:default_widgets:instructions' => 'Add, remove, position, and configure default widgets for the selected widget page.'
		. '  These changes will only affect new users on the site.',

/**
 * User settings
 */
	'usersettings:description' => "Kullanıcı ayarları panelindeki kullanıcı yönetimi nasıl eklentileri davranırlar, tüm kişisel ayarlarınızı kontrol etmek için izin verir. Başlamak için aşağıda bir seçenek seçin.",

	'usersettings:statistics' => "İstatistikler",
	'usersettings:statistics:opt:description' => "Sitenizde kullanıcıları ve nesneler hakkında istatistiki bilgi.",
	'usersettings:statistics:opt:linktext' => "Hesap istatistikleri",

	'usersettings:user' => "Ayarlar",
	'usersettings:user:opt:description' => "Bu kullanıcı ayarlarını kontrol etmenizi sağlar.",
	'usersettings:user:opt:linktext' => "Ayarlarınızı değiştirin",

	'usersettings:plugins' => "Araçlar",
	'usersettings:plugins:opt:description' => "Aktif araçlar için ayarları yapılandırma (varsa).",
	'usersettings:plugins:opt:linktext' => "Araçları yapılandırın",

	'usersettings:plugins:description' => "Bu panel sistem yöneticisi tarafından yüklenmiş olan araçlar için kişisel ayarlarınızı kontrol etmenize ve yapılandırmanızı sağlar..",
	'usersettings:statistics:label:numentities' => "İçerik",

	'usersettings:statistics:yourdetails' => "Detaylar",
	'usersettings:statistics:label:name' => "Tam isim",
	'usersettings:statistics:label:email' => "Email",
	'usersettings:statistics:label:membersince' => "Üyelik tarihi",
	'usersettings:statistics:label:lastlogin' => "Son Giriş",

/**
 * Activity river
 */
	'river:all' => 'Tüm Site Etkinlikleri',
	'river:mine' => 'Etkinliklerim',
	'river:friends' => 'Arkadaşlarımın Etkinlikleri',
	'river:select' => 'Gösteri %s',
	'river:comments:more' => '+%u daha fazla',
	'river:generic_comment' => 'yorumladı %s %s',

	'friends:widget:description' => "Arkadaşlarınızın bazı görüntüleri.",
	'friends:num_display' => "Gösterilecek arkadaş sayısı",
	'friends:icon_size' => "Simge boyutu",
	'friends:tiny' => "minik",
	'friends:small' => "küçük",

/**
 * Generic action words
 */

	'save' => "Kaydet",
	'reset' => 'Sıfırla',
	'publish' => "Yayınla",
	'cancel' => "İptal",
	'saving' => "Kaydediliyor ...",
	'update' => "Güncelleştirme",
	'preview' => "Önizle",
	'edit' => "Düzelt",
	'delete' => "Sil",
	'accept' => "Kabul et",
	'load' => "Doluyor",
	'upload' => "Yükle",
	'ban' => "Yasak",
	'unban' => "Unban",
	'banned' => "Yasak",
	'enable' => "Etkinleştir",
	'disable' => "Devre Dışı Bırak",
	'request' => "Talep",
	'complete' => "Tamamlandı",
	'open' => 'Açık',
	'close' => 'Kapalı',
	'reply' => "Cevap",
	'more' => 'daha fazla',
	'comments' => 'Yorumlar',
	'import' => 'ifade etmek',
	'export' => 'ihraç etmek',
	'untitled' => 'Başlıksız',
	'help' => 'Yardım',
	'send' => 'Gönder',
	'post' => 'Mesaj',
	'submit' => 'Sunmak',
	'comment' => 'yorum',
	'upgrade' => 'yükseltmek',
	'sort' => 'tür',
	'filter' => 'filtre',

	'site' => 'Site',
	'activity' => 'Etkinlik',
	'members' => 'Üyeler',

	'up' => 'Yukarı',
	'down' => 'Aşağo',
	'top' => 'üst',
	'bottom' => 'alt',

	'more' => 'daha fazla',

	'invite' => "davet etmek",

	'resetpassword' => "şifrenizi sıfırlayın",
	'makeadmin' => "yönetici olun",
	'removeadmin' => "Admin çıkarın",

	'option:yes' => "Evet",
	'option:no' => "Hayır",

	'unknown' => 'Bilinmeyen',

	'active' => 'Aktif',
	'total' => 'Toplam',

	'learnmore' => "Daha fazla bilgi için buraya tıklayın.",

	'content' => "içerik",
	'content:latest' => 'Son Etkinlik',
	'content:latest:blurb' => 'Alternatif olarak, site genelinde son içeriği görmek için tıklayınız.',

	'link:text' => 'Bağlantıyı görüntüle',
/**
 * Generic questions
 */

	'question:areyousure' => 'Emin misin?',

/**
 * Generic data words
 */

	'title' => "Başlık",
	'description' => "Tanım",
	'tags' => "Etiketler",
	'spotlight' => "Sahne Işığı",
	'all' => "Hepsi",
	'mine' => "Benim",

	'by' => 'tarafından',
	'none' => 'hiçbiri',

	'annotations' => "Açıklamalar",
	'relationships' => "İlişkiler",
	'metadata' => "Metaveri",
	'tagcloud' => "Etiket Bulutu",
	'tagcloud:allsitetags' => "Tüm site etiketleri",

/**
 * Entity actions
 */
	'edit:this' => 'düzenle',
	'delete:this' => 'sil',
	'comment:this' => 'yorum yap',

/**
 * Input / output strings
 */

	'deleteconfirm' => "Bu öğeyi silmek istediğinizden emin misiniz?",
	'fileexists' => "Bir dosya zaten yüklendi. Değiştirmek için, aşağıda seçin:",

/**
 * User add
 */

	'useradd:subject' => 'Kullanıcı hesabı oluşturuldu',
	'useradd:body' => '
%s,

Sizin için kullanıcı hesabı oluşturulmuştur %s. Giriş yapmak için aşağıdaki adresi ziyaret edin:

%s

kullanıcı kimlik bilgileri ile giriş:

Kullanıcı Adı: %s
Şifre: %s

Giriş yaptıktan sonra, şifrenizi değiştirmenizi öneririz.
',

/**
 * System messages
 **/

	'systemmessages:dismiss' => "kapatmak için tıklayın",


/**
 * Import / export
 */
	'importsuccess' => "Veri gönderilmesi başarılı oldu",
	'importfail' => "Veri gönderilmesi başarısız oldu.",

/**
 * Time
 */

	'friendlytime:justnow' => "Hemen şimdi",
	'friendlytime:minutes' => "%s dakika önce",
	'friendlytime:minutes:singular' => "Bir dakika önce",
	'friendlytime:hours' => "%s saat önce",
	'friendlytime:hours:singular' => "Bir saat önce",
	'friendlytime:days' => "%s gün önce",
	'friendlytime:days:singular' => "dün",
	'friendlytime:date_format' => 'j F Y @ g:ia',

	'date:month:01' => 'Ocak %s',
	'date:month:02' => 'Şubat %s',
	'date:month:03' => 'Mart %s',
	'date:month:04' => 'Nisan %s',
	'date:month:05' => 'Mayıs %s',
	'date:month:06' => 'Haziran %s',
	'date:month:07' => 'Temmuz %s',
	'date:month:08' => 'Ağustos %s',
	'date:month:09' => 'Eylül %s',
	'date:month:10' => 'Ekim %s',
	'date:month:11' => 'Kasım %s',
	'date:month:12' => 'Aralık %s',


/**
 * System settings
 */

	'installation:sitename' => "Sitenizin adı:",
	'installation:sitedescription' => "sitenizin açıklaması (isteğe bağlı):",
	'installation:wwwroot' => "Site URL:",
	'installation:path' => "Elgg kurulumu tam yol:",
	'installation:dataroot' => "Veri dizini tam yolu:",
	'installation:dataroot:warning' => "elle dizin oluşturmanız gerekir. Elgg yükleme için farklı bir dizin olmalıdır.",
	'installation:sitepermissions' => "Varsayılan erişim izinleri:",
	'installation:language' => "Siteniz için varsayılan dil:",
	'installation:debug' => "Debug modu hataları teşhis etmek için kullanılabilir ek bilgi sağlar. Ancak, sorunlar yaşıyorsanız kullanın aksi takdirde sistemi yavaşlatır.",
	'installation:debug:none' => 'Hata ayıklama modu (önerilir) kapatın',
	'installation:debug:error' => 'Sadece kritik hatalar göster',
	'installation:debug:warning' => 'Ekran hatalar ve uyarılar',
	'installation:debug:notice' => 'tüm hatalar, uyarılar ve bildirimler',

	// Walled Garden support
	'installation:registration:description' => 'Kullanıcı kaydı varsayılan olarak etkindir. Yeni kullanıcıların kayıtlarını istemiyorsanız kapatın.',
	'installation:registration:label' => 'Yeni kullanıcılar kayıt için izin ver',
	'installation:walled_garden:description' => 'Enable the site to run as a private network. This will not allow non logged-in users to view any site pages other than those specifically marked as public.',
	'installation:walled_garden:label' => 'Oturum açan kullanıcıların sayfalarını sınırla',

	'installation:httpslogin' => "HTTPS üzerinden yapılan kullanıcı girişlerini etkinleştirin. Çalışmak için https Bunun için sunucu üzerinde etkin olması gerekir.",
	'installation:httpslogin:label' => "HTTPS oturumlar etkinleştirin",
	'installation:view' => "Siteniz için varsayılan olarak kullanılacak görünümü girin veya varsayılan görünümü için bu bölümü boş bırakın",

	'installation:siteemail' => "Site e-posta adresi (sistemi e-postaları gönderirken kullanılan):",

	'installation:disableapi' => "Uzak uygulamalar sitenizle etkileşime böylece Elgg web servisleri oluşturmak için bir API sağlar..",
	'installation:disableapi:label' => "Elgg web servisleri API etkinleştirin",

	'installation:allow_user_default_access:description' => "Eğer işaretli ise, bireysel kullanıcılar, sistem varsayılan erişim seviyesi-ride kendi varsayılan erişim seviyesini ayarlamak için izin verilecektir.",
	'installation:allow_user_default_access:label' => "Kullanıcı varsayılan erişim izin ver",

	'installation:simplecache:description' => "Statik içerik dahil olmak üzere bazı CSS ve JavaScript dosyaları önbelleğe alarak basit bir önbellek performans artışı sağlar.",
	'installation:simplecache:label' => "Basit önbellek (önerilir) kullanın.",

	'installation:viewpathcache:description' => "Görüşlerini yerini önbelleğe görünümü filepath önbellek eklentileri yükleme süreleri azalır.",
	'installation:viewpathcache:label' => "Dosyayolu önbellek (önerilir) kullanın",

	'upgrading' => 'Yükseltme ...',
	'upgrade:db' => 'Veritabanı yükseltildi.',
	'upgrade:core' => 'Elgg kurulum yükseltildi.',
	'upgrade:unable_to_upgrade' => 'Yükseltmek için.',
	'upgrade:unable_to_upgrade_info' =>
		'Elgg yükseltmek için elggturkiye.net son sürümünü indirebilirsiniz <a href="http://forum.elggturkiye.net">elggturkiye.net</a>.<br /><br />',

	'update:twitter_api:deactivated' => 'Twitter API (previously Twitter Service) was deactivated during the upgrade. Please activate it manually if required.',
	'update:oauth_api:deactivated' => 'OAuth API (previously OAuth Lib) was deactivated during the upgrade.  Please activate it manually if required.',

	'deprecated:function' => '%s() was deprecated by %s()',

/**
 * Welcome
 */

	'welcome' => "Hoşgeldiniz",
	'welcome:user' => 'Hoşgeldiniz %s',

/**
 * Emails
 */
	'email:settings' => "E-posta ayarları",
	'email:address:label' => "E-posta adresiniz",

	'email:save:success' => "Yeni E-posta adresi kaydedildi,doğrulama gönderildi.",
	'email:save:fail' => "Yeni E-posta adresi kaydedilemedi..",

	'friend:newfriend:subject' => "%s bir arkadaş yaptı!",
	'friend:newfriend:body' => "%s bir arkadaş yaptı!

Kendi profiline görmek için buraya tıklayın:

%s

Bu e-postaya cevap veremezsiniz.",



	'email:resetpassword:subject' => "Parola sıfırlama!",
	'email:resetpassword:body' => "Selam %s,

Şifrenizi sıfırlamak için: %s",


	'email:resetreq:subject' => "Yeni şifre talebi.",
	'email:resetreq:body' => "Selam %s,

Biri (IP addresi %s) yeni şifre talep etti.

Aşağıdaki linke tıklayarak değiştirebilir,aksi halde bu E-postayı görmemezlikten gelebilirsiniz.

%s
",

/**
 * user default access
 */

'default_access:settings' => "Varsayılan erişim seviyesi",
'default_access:label' => "varsayılan erişim",
'user:default_access:success' => "Yeni varsayılan erişim düzeyi kaydedildi.",
'user:default_access:failure' => "Yeni varsayılan erişim düzeyi kaydedilemedi.",

/**
 * XML-RPC
 */
	'xmlrpc:noinputdata'	=>	"Eksik veri girişi",

/**
 * Comments
 */

	'comments:count' => "%s yorum",

	'riveraction:annotation:generic_comment' => '%s yorumladı %s',

	'generic_comments:add' => "Yorum Ekleme",
	'generic_comments:post' => "Yorum Yaz",
	'generic_comments:text' => "yorum",
	'generic_comments:latest' => "Son yorumlar",
	'generic_comment:posted' => "Yorum başarıyla yayınlanmıştır.",
	'generic_comment:deleted' => "Yorum başarıyla silindi.",
	'generic_comment:blank' => "Üzgünüz, yorum gönderilemedi.",
	'generic_comment:notfound' => "Üzgünüz,belirtilen öğe bulunamadı.",
	'generic_comment:notdeleted' => "Üzgünüz,yorum silinemiyor.",
	'generic_comment:failure' => "Yorum eklerken beklenmeyen bir hata oluştu.Lütfen yeniden deneyin.",
	'generic_comment:none' => 'Yorum yok',

	'generic_comment:email:subject' => 'Yeni bir yorum var!',
	'generic_comment:email:body' => "Öğe üzerinde yeni bir yorum var \"%s\" itibaren %s. şöyledir;


%s


Özgün öğe cevap ya da görmek için buraya tıklayın:

%s

%s Adlı üyenin Profilini görmek için, buraya tıklayın:

%s

Bu e-postaya cevap veremezsiniz.",

/**
 * Entities
 */
	'byline' => 'By %s',
	'entity:default:strapline' => 'Oluşturulma %s by %s',
	'entity:default:missingsupport:popup' => 'Bu kimlik doğru olamaz. ',

	'entity:delete:success' => 'Varlık %s silinmiş',
	'entity:delete:fail' => 'Varlık %s silinemedi',


/**
 * Action gatekeeper
 */
	'actiongatekeeper:missingfields' => 'Form is missing __token or __ts fields',
	'actiongatekeeper:tokeninvalid' => "We encountered an error (token mismatch). This probably means that the page you were using expired. Please try again.",
	'actiongatekeeper:timeerror' => 'The page you were using has expired. Please refresh and try again.',
	'actiongatekeeper:pluginprevents' => 'A extension has prevented this form from being submitted.',


/**
 * Word blacklists
 */
	'word:blacklist' => 'and, the, then, but, she, his, her, him, one, not, also, about, now, hence, however, still, likewise, otherwise, therefore, conversely, rather, consequently, furthermore, nevertheless, instead, meanwhile, accordingly, this, seems, what, whom, whose, whoever, whomever',

/**
 * Tag labels
 */

	'tag_names:tags' => 'Tags',
	'tags:site_cloud' => 'Site Tag Cloud',

/**
 * Javascript
 */

	'js:security:token_refresh_failed' => 'Cannot contact %s. You may experience problems saving content.',
	'js:security:token_refreshed' => 'Connection to %s restored!',

/**
 * Languages according to ISO 639-1
 */
	"aa" => "Afar",
	"ab" => "Abkhazian",
	"af" => "Afrikaans",
	"am" => "Amharic",
	"ar" => "Arabic",
	"as" => "Assamese",
	"ay" => "Aymara",
	"az" => "Azerbaijani",
	"ba" => "Bashkir",
	"be" => "Byelorussian",
	"bg" => "Bulgarian",
	"bh" => "Bihari",
	"bi" => "Bislama",
	"bn" => "Bengali; Bangla",
	"bo" => "Tibetan",
	"br" => "Breton",
	"ca" => "Catalan",
	"co" => "Corsican",
	"cs" => "Czech",
	"cy" => "Welsh",
	"da" => "Danish",
	"de" => "German",
	"dz" => "Bhutani",
	"el" => "Greek",
	"en" => "English",
	"eo" => "Esperanto",
	"es" => "Spanish",
	"et" => "Estonian",
	"eu" => "Basque",
	"fa" => "Persian",
	"fi" => "Finnish",
	"fj" => "Fiji",
	"fo" => "Faeroese",
	"fr" => "French",
	"fy" => "Frisian",
	"ga" => "Irish",
	"gd" => "Scots / Gaelic",
	"gl" => "Galician",
	"gn" => "Guarani",
	"gu" => "Gujarati",
	"he" => "Hebrew",
	"ha" => "Hausa",
	"hi" => "Hindi",
	"hr" => "Croatian",
	"hu" => "Hungarian",
	"hy" => "Armenian",
	"ia" => "Interlingua",
	"id" => "Indonesian",
	"ie" => "Interlingue",
	"ik" => "Inupiak",
	//"in" => "Indonesian",
	"is" => "Icelandic",
	"it" => "Italian",
	"iu" => "Inuktitut",
	"iw" => "Hebrew (obsolete)",
	"ja" => "Japanese",
	"ji" => "Yiddish (obsolete)",
	"jw" => "Javanese",
	"ka" => "Georgian",
	"kk" => "Kazakh",
	"kl" => "Greenlandic",
	"km" => "Cambodian",
	"kn" => "Kannada",
	"ko" => "Korean",
	"ks" => "Kashmiri",
	"ku" => "Kurdish",
	"ky" => "Kirghiz",
	"la" => "Latin",
	"ln" => "Lingala",
	"lo" => "Laothian",
	"lt" => "Lithuanian",
	"lv" => "Latvian/Lettish",
	"mg" => "Malagasy",
	"mi" => "Maori",
	"mk" => "Macedonian",
	"ml" => "Malayalam",
	"mn" => "Mongolian",
	"mo" => "Moldavian",
	"mr" => "Marathi",
	"ms" => "Malay",
	"mt" => "Maltese",
	"my" => "Burmese",
	"na" => "Nauru",
	"ne" => "Nepali",
	"nl" => "Dutch",
	"no" => "Norwegian",
	"oc" => "Occitan",
	"om" => "(Afan) Oromo",
	"or" => "Oriya",
	"pa" => "Punjabi",
	"pl" => "Polish",
	"ps" => "Pashto / Pushto",
	"pt" => "Portuguese",
	"qu" => "Quechua",
	"rm" => "Rhaeto-Romance",
	"rn" => "Kirundi",
	"ro" => "Romanian",
	"ru" => "Russian",
	"rw" => "Kinyarwanda",
	"sa" => "Sanskrit",
	"sd" => "Sindhi",
	"sg" => "Sangro",
	"sh" => "Serbo-Croatian",
	"si" => "Singhalese",
	"sk" => "Slovak",
	"sl" => "Slovenian",
	"sm" => "Samoan",
	"sn" => "Shona",
	"so" => "Somali",
	"sq" => "Albanian",
	"sr" => "Serbian",
	"ss" => "Siswati",
	"st" => "Sesotho",
	"su" => "Sundanese",
	"sv" => "Swedish",
	"sw" => "Swahili",
	"ta" => "Tamil",
	"te" => "Tegulu",
	"tg" => "Tajik",
	"th" => "Thai",
	"ti" => "Tigrinya",
	"tk" => "Turkmen",
	"tl" => "Tagalog",
	"tn" => "Setswana",
	"to" => "Tonga",
	"tr" => "Turkiye",
	"ts" => "Tsonga",
	"tt" => "Tatar",
	"tw" => "Twi",
	"ug" => "Uigur",
	"uk" => "Ukrainian",
	"ur" => "Urdu",
	"uz" => "Uzbek",
	"vi" => "Vietnamese",
	"vo" => "Volapuk",
	"wo" => "Wolof",
	"xh" => "Xhosa",
	//"y" => "Yiddish",
	"yi" => "Yiddish",
	"yo" => "Yoruba",
	"za" => "Zuang",
	"zh" => "Chinese",
	"zu" => "Zulu",
);

add_translation("en",$english);
