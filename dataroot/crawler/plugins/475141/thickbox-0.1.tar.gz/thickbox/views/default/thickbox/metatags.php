<?php

  // Include the thickbox javascript library and associated CSS. Elgg already supplies jQuery.
  // With thanks to Alistair Young <alistair@codebrane.com>

?>
<script type="text/javascript" src="<? echo $vars['url']; ?>mod/thickbox/lib/js/thickbox.js"></script>
<style type="text/css" media="all">
@import "<? echo $vars['url']; ?>mod/thickbox/lib/js/thickbox-elgg.css";
</style>
