<?php
		function greenmaps_init() 
		{
		global $CONFIG;
		add_menu(elgg_echo('Music'), $CONFIG->wwwroot . "mod/greenmaps");
		}
		
	register_elgg_event_handler('init','system','greenmaps_init');
	// Shares widget

?>