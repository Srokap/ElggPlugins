<?php 
 
	$german = array(	
			
		'openid_client_login_title'                     => "Anmelden OpenID",
		'openid_client_login_service'                   => "Webdienst",
		'openid_client_logon'                           => "Logon",
		'openid_client_go'                              => "Anmelden",
		'openid_client_remember_login'                  => "Speichern",
		'openid_client:already_loggedin'                => "Du bist schon angemeldet.",
		'openid_client:login_success'                   => "Du bist jetzt angemeldet.",
		'openid_client:login_failure'                   => "Der Benutzername ist nicht bekannt. Das System konnte dich nicht anmelden.",
		'openid_client:disallowed'                      => "Dieser Webdienst erlaubt die von dir eingegebene OpenID nicht. "
		        ."Bitte versuche eine andere OpenID oder kontaktieren den Administrator fr weitere Informationen.",
		'openid_client:redirect_error'                  => "Kann nicht weitergeleitet werden auf Server: %s",
		'openid_client:authentication_failure'          => "OpenID Authentifikation abgebrochen: %s ist keine gltige OpenID URL.",
		'openid_client:authentication_cancelled'        => "OpenID Authentifikation abgebrochen.",
		'openid_client:authentication_failed'           => "OpenID Authentifikation abgebrochen (Status: %s, Mitteilung: %s )",
		'openid_client:banned'                          => "Du bist verbannt von diesem System!",
		'openid_client:email_in_use'                    => "Deine E-Mail Adresse %s kann nicht gendert werden, sie ist bereits in Verwendung.",
		'openid_client:email_updated'                   => "Deine E-Mail Adresse wurde upgedatet auf %s",
		'openid_client:information_title'               => "OpenID Information",
		'openid_client:activate_confirmation'           => "Eine Besttigungsmail wurde versendet an %s ."
		        ." Bitte klicke auf den Link in der Mail um deine Konto zu aktivieren."
		        ." Du kannst dann mit deinem OpenID Login einloggen.",
        'openid_client:change_confirmation'             => "Deine E-Mail Adresse hat gendert. Eine Besttigungmail wurde gesendet an"
                ." deine neue Adresse %s . Bitte klicke auf den Link im Besttigungsmail um die neue E-Mail zu besttigen. ",
        'openid_client:activate_confirmation_subject'   => "%s Konto Verifikation",
        'openid_client:activate_confirmation_body'      => "Hallo %s,\n\nDanke fr deine Registrierung bei %s.\n\n"
            ."Um deine Registrierung zu vervollstndigen, besuche folgenden Link:\n\n\t%s\n\ninnerhalb von 7 Tagen.\n\nRegards,\n\nDas %s Team.",
        'openid_client:change_confirmation_subject'     => "%s E-Mail-nderung",
        'openid_client:change_confirmation_body'        => "Hallo %s,\n\nWir haben eine Anfrage bekommen deine E-Mail-Adresse zu ndern"
            ." Registriert bei %s.\n\nUm deine E-Mail-Adresse auf {%s} zu ndern, besuche folgenden Link:\n\n\t%s\n\ninnerhalb von 7 Tagen."
            ."\n\nMit freundlichen Grssen,\n\nDas %s Team.",				
	    'openid_client:email_label'                     => "E-Mail:",
	    'openid_client:name_label'                      => "Name:",
	    'openid_client:submit_label'                    => "Absenden",
	    'openid_client:cancel_label'                    => "Abbrechen",
	    'openid_client:nosync_label'                    => "Bitte, benachrichtigen sie in Zukunft mich nicht mehr, wenn die Daten auf diesem"
	        ." System, nicht den Daten auf meinem OpenID-Server entsprechen.",
	    'openid_client:sync_instructions'               => "Die Information auf deinem Open ID Server ist nicht die selbe wie auf diesem System."
	        ." Whle die Checkbox fr die Informationen die du auf diesem System updaten mchtest und drcke absenden.",
	    'openid_client:missing_title'					=> "Bitte gib die fehlende Information an",
	    'openid_client:sync_title'						=> "Synchronisiere deine Information",
	    'openid_client:missing_email'                   => "eine gltige E-Mail-Adresse",
	    'openid_client:missing_name'                    => "dein vollstndiger Name",
	    'openid_client:and'                             => "und",
	    'openid_client:missing_info_instructions'       => "Um hier ein Konto zu erffnen bentigen wir %s."
	        ." Bitte flle diese Information unten ein.",
	    'openid_client:create_email_in_use'             => "Konto kann nicht erffnent werden mit dieser E-Mail-Adresses %s weil sie schon bentzt wird.",
	    'openid_client:missing_name_error'              => "Bitte einen Namen eingeben.",
	    'openid_client:invalid_email_error'             => "Bitte eine gltige E-Mail-Adresse eingeben.",
	    'openid_client:invalid_code_error'              => "Dein Code scheint ungltig zu sein. Codes gelten nur fr sieben Tage;"
	        ." es ist mglich, dass deiner lter ist.",
	    'openid_client:user_creation_failed'            => "Es kann kein OpenID Konto erstellt werden.",
	    'openid_client:created_openid_account'          => "OpenID-Konto erffnet, E-Mail-Adresse %s und Name %s vom OpenID-Server bernommen.",
	    'openid_client:name_updated'                    => "Dein Name wurde aktualisiert auf %s.",
	    'openid_client:missing_confirmation_code'       => "Dein Besttigungcode scheint zu fehlen.  Bitte berprfe den Link und versuche es nochmals.",
	    'openid_client:at_least_13'                     => "Bitte besttigen, dass du mindestens 13 Jahre alt bist um beizutretten.",
	    'openid_client:account_created'                 => "Dein Konto wurde erstellt! Du kannst nun mit deiner  OpenID (%s) einloggen.",
	    'openid_client:email_changed'                   => "Deine E-Mail Adresse wurde gendert zu {%s} . "
		    ."Du kannst nun mit deiner OpenID anmelden, wenn du noch nicht angemeldet bist.",
		'openid_client:thankyou'                        => "Danke fr deine Registrierung fr ein Konto bei uns %s!"
	        ." Die Registrierung ist vollstndig gratis, doch bevor du deine Details besttigst,"
	        ." nimm dir bitte einen Moment Zeit umd die folgenden Dokumente zu lesen:",
	    'openid_client:terms'                           => "Bedingungen",
	    'openid_client:privacy'                         => "Datenschutzerklrung",
	    'openid_client:acceptance'                      => "Durch das Absenden dieses Formulars, akzeptiert du die Bedingungen. "
	        ."Bitte beachte, dass du mindestens 13 Jahre alt sein must um hier beizutretten.",
	    'openid_client:correct_age'                     => "Ich bin mindestens 13 Jahre alt.",
	    'openid_client:join_button_label'               => "Beitreten",
	    'openid_client:confirmation_title'              => "OpenID Besttigung",
	    'openid_client:admin_title'                     => "OpenID Administration",
	    'openid_client:default_server_title'             => "Default-Server",
	    'openid_client:default_server_instructions1'     => "Du kannst die Anmeldeverfahren vereinfachen, indem du einen Standard-OpenID-Server festlegst."
            ." Benutzer, die einen einfachen Kontonamen (z.B. \"susan\") whrend an OpenID login verwenden knnen zu einer vollstndigen OpenID"
	        ." erweitert werden, wenn Du hier einen Standard-Server festlegst. Lege fest \"%s\" wo der Kontonamen hinzugefgt werden soll."
	        ." Zum Beispiel indem du folgendes ein gibst"

	        ." \"http://openidserver.com/%s/\" ,wenn Du willst, dass die OpenID \"http://openidserver.com/susan/\" lautet oder"
	        ." \"http://%s.openidserver.com/\" ,wenn Du willst, dass die OpenID \"http://susan.openidserver.com/\" wird.",
	    'openid_client:default_server_instructions2'    => "Punkte (\".\") werden verwendet um OpenID URLs von einfachen Kontonamen zu unterscheiden,"
	        ." , du kannst dieses feature nur verwenden fr Standard-Server die Punkte im einfachen Kontonamen nicht erlauben.",
	    'openid_client:server_sync_title'               => "Server-Synchronisation",
	    'openid_client:server_sync_instructions'        => "Whle diese Box, wenn Du automatisch diese Client-Site wenn ein siche eine"
	        ." Benutzer anmeldet und seine E-Mail-Adresse oder sein Name sich von demjenigen auf dessen OpenID-Server unterscheidet. Lass diese"
	        ." Box ungewhlt, wenn du willst, dass der Benutzer die Mglichkeit hat auf diesem System einen anderen Namen und eine andere"
	        ."  E-Mail-Adresse zu besitzen als auf dessen OpenID-Server.",
	    'openid_client:server_sync_label'               => "Automatisches Update vom OpenID Server.",
	    'openid_client:lists_title'                     => "OpenID Listen",
	    'openid_client:lists_instruction1'              => "Du kannst eine Grne-, Gelbe- oder Rote-Liste erstellen um OpenID Kunden zu akzeptieren.",
	    'openid_client:lists_instruction2'              => "Die Grne-Liste enthlt OpenIDs die zur Identifikation akzeptiert sind"
	        ." und eine gltige E-Mail-Adresse besitzen.",
	    'openid_client:lists_instruction3'              => "Die Gelbe-Liste enthlt OpenIDs die nur zur Identifikation akzeptiert sind."
	        ." Wenn sie eine E-Mail-Adresse besitzen, wird eine Nachricht zur besttigung an diese Adresse gesendet, bevor die Registrierung erlaubt wird.",
	    'openid_client:lists_instruction4'              => "Die Rote-Liste enthlt OpenIDs die abgelehnt werden.",
	    'openid_client:lists_instruction5'              => "Wenn keine Grnen-, Gelben- und Roten-Listen vorhanden sind, werden alle  OpenIDs"
	        ." ein Grner-Status gegeben (sie werden fr die Identifikation akzeptiert und die E-Mail-Adresse wird ohne Besttigung akzeptiert).",
	    'openid_client:lists_instruction6'              => "Schreibe ein OpenID Eintrag auf jede Zeile. Du kannst \"*\" als ein  Wildcard-Zeichen benutzen"
	        ." um eine Anzahl mglicher OpenIDs oder OpenID Server zu ersetzen. Jeder OpenID-Server-Adresse muss mit http:// oder https:// starten und mit einem"
	        ." Slash (\"/\") enden - z.B. http://*.myopenid.com/",
	    'openid_client:green_list_title'                => "Grne-Liste",
	    'openid_client:yellow_list_title'               => "Gelbe-Liste",
	    'openid_client:red_list_title'                  => "Rote-Liste",
	    'openid_client:ok_button_label'                 => "OK",
	    'openid_client:admin_response'                  => "OpenID-Konfiguration gespreichert."
	    
	);
					
	add_translation("de",$german);

?>