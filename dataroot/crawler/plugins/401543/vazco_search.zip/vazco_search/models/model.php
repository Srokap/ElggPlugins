<?php 
class vazco_search{
	//set the sort order based on points for the sortparameters 
	static public function updateSortOrder(){
		
		global $CONFIG;
		$points = 0;
		$username = get_input('username','');
		$user = get_user_by_username($username);
		return vazco_search::updateUser($user);
	}
	public function updateAll(){
		$members = get_entities('user','',0,'',0);
		foreach ($members as $member){
			vazco_search::massUpdateUser($member);
		}
		return true;
	}
	private function updateUser($user){
		global $CONFIG;
		if ($user){
			$points = 0;
			$sorttermsArray = vazco_search::getSortTerms();
			foreach($CONFIG->profile as $shortname => $valtype) {
					if ($shortname != "description") {
						$value = get_input($shortname,'');

						if (!empty($value)) {
							if (isset($sorttermsArray[$value])){
								$points += $sorttermsArray[$value];
							}
						}
					}
			}
			$user->sortorder = $points;
		}else{
			return false;
		}
		return true;
	}
	
	private function massUpdateUser($user){
		global $CONFIG;
		if ($user){
			$points = 0;
			$sorttermsArray = vazco_search::getSortTerms();
			foreach($CONFIG->profile as $shortname => $valtype) {
					if ($shortname != "description") {
						$valueArray = $user->$shortname;
						
						foreach ($valueArray as $key => $value){
							$value = trim($value);
							
							if (!empty($value)) {
								if (isset($sorttermsArray[$value])){
									$points += $sorttermsArray[$value];
								}
							}
						}
					}
			}
			$user->sortorder = $points;
		}else{
			return false;
		}
		return true;
	}
	//returns the table of weights for the given terms
	static public function getSortTerms(){
		$terms = get_plugin_setting('sortterms','vazco_search');
		
		$ranklines = array_filter(explode("\n", $terms), "strlen");
		$sortterms = array();
		foreach ($ranklines as &$line){
			//process line
			$line = array_unique(array_filter(explode("|", $line), "strlen"));
			foreach ($line as &$param)
				$param = trim($param);
			//check if the rank's name and points were given
			if ($line[0] != null && $line[1] != null){
				//create one rank
				$sortterms[$line[0]] = $line[1];
			}
			else{
				register_error(elgg_echo('vazco_search:exception:wrongsearchsorttermparams'));
				return false;
			}
		}
		return $sortterms;
	}
	
	//process list to array of arrays 
    private function processSearchTerms($linklist){
		//first get array of single lines
		
     }
	//returns table of terms
	static public function getTerms(){
		$list = get_plugin_setting('searchterms','vazco_search');

		if ($additionalTerms)
			$list =  merge($list,$additionalTerms);
		$terms = array();
		if ($list != ''){
			$terms = explode(',',$list);
			foreach ($terms as &$term){
				$term = trim($term);
			}
		}
		return $terms;
	}
	
	static public function getSearchTable(){
		global $CONFIG;
		//get array of searchable terms set by admin
		$terms = vazco_search::getTerms();
		
		//now add all searchable terms to search array in case they're passed to search
		$searchTable = array();
		$termsWithValues = array();
		foreach ($terms as $term){
			$encodedTerm = urlencode($term);
			$termsWithValues[urlencode($term)] = get_input("tagTable[{$encodedTerm}]",'');
		}
		$searchTable['terms'] = $termsWithValues;
		
		//now get all the categories
		$cats = $CONFIG->site->categories;
		$categoriesWithValues = array();

		foreach ($cats as $id => $cat){
			$encodedCat = urlencode($cat);
			if (get_input("catTable[{$encodedCat}]",false))
				$categoriesWithValues[$encodedCat] = $encodedCat;
		}
		$searchTable['categories'] = $categoriesWithValues;

		//now get all the categories from the second type
		$cats = $CONFIG->site->categories2;
		$categoriesWithValues = array();

		foreach ($cats as $id => $cat){
			$encodedCat = urlencode($cat);
			if (get_input("catTable2[{$encodedCat}]",false))
				$categoriesWithValues[$encodedCat] = $encodedCat;
		}
		$searchTable['categories2'] = $categoriesWithValues;		
		
		//now get all the params that were passed outside of the tagTable
		$params = trigger_plugin_hook('setsearchparams','all', array());
		$paramTable = array();
		foreach ($params as $term){
			$encodedTerm = urlencode($term);
			$paramTable[urlencode($term)] = get_input($encodedTerm,'');
		}

		$searchTable['params'] = $paramTable;
		return $searchTable;
	}
	static public function getChosenTermsTable($string = 'tagString'){
		$terms = get_input($string,'');
		$termsChosen = array();
		if ($terms != ''){
			$termsChosen = explode(',',$terms);
			foreach($termsChosen as &$chosenTerm){
				$chosenTerm = trim($chosenTerm);
			}
		}
		return $termsChosen;
	}
		
	static public function getChosenCatsTable($string = 'catString'){
		$terms = get_input($string,'');
		$termsChosen = array();
		if ($terms != ''){
			$termsChosen = explode(',',$terms);
			foreach($termsChosen as &$chosenTerm){
				$chosenTerm = trim($chosenTerm);
			}
		}
		return $termsChosen;
	}	

	static public function createSearchMetadataTable($catSearchTable, $catSearchTable2, $tagSearchTable, $md_type, $tag){
		$metaArray = array();
		if ($tag != ''){
			$tags = explode(',',$tag);
			foreach($tags as $tag){
				$metaArray []= urldecode(trim($tag));
			}
			
		}
			
		foreach($tagSearchTable as $tag => $value){
			$metaArray []= urldecode($value);
		}
		
		foreach($catSearchTable as $tag => $value){
			$element = array(
				'name' => 'universal_categories',
				'value' => urldecode($value),
				'operand' => '=',
			);
			$metaArray []= $element;
		}

		foreach($catSearchTable2 as $tag => $value){
			$element = array(
				'name' => 'universal_categories2',
				'value' => urldecode($value),
				'operand' => '=',
			);
			$metaArray []= $element;
		}
		//now add parameters
		$params = trigger_plugin_hook('setsearchparams','all', array());
		$paramTable = array();

		foreach ($params as $term){
			if ($term){
				$encodedTerm = urlencode($term);
				$value = get_input($encodedTerm,null);

				if ($value){

					$element = array(
						'name' => urlencode($term),
						'value' => get_input($encodedTerm,null),
						'operand' => '=',
					); 
					$metaArray []= $element;
				}
			}
		}
		return $metaArray;
	}
	
	static public function isInChosenTerms($termsChosen, $term){
		$found = false;
		foreach ($termsChosen as $chosen){
				if ($chosen == $term)
					$found = true;
			}
		return $found;
	}

	static public function getSearchStringFromSearchTable($searchTable){
		//change search terms taken from array to string
		$searchString = vazco_search::makeSearchStringFromArray("&tagString=", $searchTable['terms']);
		//change search categories taken from array to string
		$searchString .= vazco_search::makeSearchStringFromArray("&catString=", $searchTable['categories']);
		$searchString .= vazco_search::makeSearchStringFromArray("&catString2=", $searchTable['categories2']);

		$params = $searchTable['params'];
		
		foreach ($params as $param => $value){
			$searchString .= "&$param={$value}";
		}

		return $searchString;
	}
	function makeSearchStringFromArray($searchString, $array){
		$first = true;
		//change search terms taken from array to string
		$termsWithValues = $searchTable['terms'];
		foreach ($array as $term => $value){
			if ($value != ''){
				if ($first == false){
					$searchString .= ",";
				}else{
					$first = false;
				}
				$searchString .= "{$term}";
			}
		}
		return $searchString;
	}
	
	function list_entities_from_tags_multi($meta_array, $entity_type = "", $entity_subtype = "", $owner_guid = 0, $limit = 10, $fullview = true, $viewtypetoggle = true, $pagination = true) {
		//in case sort terms are set, sort entities by their sort value
		$order_by_column = "";

		if (get_plugin_setting('sortterms','vazco_search'))
			$order_by_column = "sortorder";
		$offset = (int) get_input('offset');
		$limit = (int) $limit;
		$order_by = "";
		$count = vazco_search::get_entities_from_tags_multi($meta_array, $entity_type, $entity_subtype, $owner_guid, $limit, $offset, $order_by, $site_guid, true);

		$entities = vazco_search::get_entities_from_tags_multi($meta_array, $entity_type, $entity_subtype, $owner_guid, $limit, $offset, $order_by, $site_guid, false, $order_by_column);

		return elgg_view_entity_list($entities, $count, $offset, $limit, $fullview, $viewtypetoggle, $pagination);
		
	}
	
/**
	 * Returns a list of entities based on the given search criteria.
	 *
	 * @param array $meta_array Array of 'name' => 'value' pairs
	 * @param string $entity_type The type of entity to look for, eg 'site' or 'object'
	 * @param string $entity_subtype The subtype of the entity.
	 * @param int $limit 
	 * @param int $offset
	 * @param string $order_by Optional ordering.
	 * @param int $site_guid The site to get entities for. Leave as 0 (default) for the current site; -1 for all sites.
	 * @param true|false $count If set to true, returns the total number of entities rather than a list. (Default: false)
	 * @return int|array List of ElggEntities, or the total number if count is set to false
	 */
	private function get_entities_from_tags_multi($meta_array, $entity_type = "", $entity_subtype = "", $owner_guid = 0, $limit = 10, $offset = 0, $order_by = "", $site_guid = 0, $count = false, $order_by_column = "")
	{
		global $CONFIG;
		update_data("SET OPTION SQL_BIG_SELECTS=1;");

		if ($entity_type == "" && (!is_array($meta_array) || sizeof($meta_array) == 0)) {
			return false;
		}
		
		$where = array();
		
		$mindex = 1;
		$join = "";

		foreach ($meta_array as $meta_value){
			if (is_array($meta_value)){
				$meta = $meta_value;

				/*
				$meta_v = get_metastring_id($meta_value['value']);
				$operation = $meta_value['operation'];
				$join .= " JOIN {$CONFIG->dbprefix}metadata m{$mindex} on e.guid = m{$mindex}.entity_guid "; 
				if ($meta_value!=="")
					$where[] = "m{$mindex}.value_id$operation'$meta_v'";
				$mindex++;
				*/
				$meta_n = get_metastring_id($meta_name);
				$meta_v = get_metastring_id($meta_value);
							
	            $join .= "JOIN {$CONFIG->dbprefix}metadata m{$mindex} on e.guid = m{$mindex}.entity_guid ";
	            $join .= "JOIN {$CONFIG->dbprefix}metastrings v{$mindex} on v{$mindex}.id = m{$mindex}.value_id ";
	
	            $meta_n = get_metastring_id($meta['name']);
	            $where[] = "m{$mindex}.name_id='$meta_n'";
	
	            if (isset($meta['integer']) && $meta['integer']){
		            if (strtolower($meta['operand']) == "<="){
		                $where[] = "v{$mindex}.string * 1 <= ".$meta['value']." ";
		            }elseif(strtolower($meta['operand']) == ">="){
		                $where[] = "v{$mindex}.string * 1 >= ".$meta['value']." ";
		            }elseif(strtolower($meta['operand']) == "<"){
		                $where[] = "v{$mindex}.string * 1 < ".$meta['value']." ";
		            }elseif(strtolower($meta['operand']) == ">"){
		                $where[] = "v{$mindex}.string * 1 > ".$meta['value']." ";
		            }elseif($meta['operand'] != ''){
		                // Simple operand search
		                $where[] = "v{$mindex}.string".$meta['operand']."'".$meta['value']."'";
		            }
	            }else{
	           		if (strtolower($meta['operand']) == "like"){
		                // "LIKE" search
		                $where[] = "v{$mindex}.string LIKE ('".$meta['value']."') ";
		            }elseif(strtolower($meta['operand']) == "in"){
		                // TO DO - "IN" search
		            }elseif(strtolower($meta['operand']) == "<="){
		                $where[] = "v{$mindex}.string <= ('".$meta['value']."') ";
		            }elseif(strtolower($meta['operand']) == ">="){
		                $where[] = "v{$mindex}.string >= ('".$meta['value']."') ";
		            }elseif(strtolower($meta['operand']) == "<"){
		                $where[] = "v{$mindex}.string < ('".$meta['value']."') ";
		            }elseif(strtolower($meta['operand']) == ">"){
		                $where[] = "v{$mindex}.string > ('".$meta['value']."') ";
		            }elseif($meta['operand'] != ''){
		                // Simple operand search
		                $where[] = "v{$mindex}.string".$meta['operand']."'".$meta['value']."'";
		            }
	            }

				// 	Add access controls
	            $mindex++;
			}else{
				$meta_v = get_metastring_id($meta_value);
				$join .= " JOIN {$CONFIG->dbprefix}metadata m{$mindex} on e.guid = m{$mindex}.entity_guid ";
				$join .= "JOIN {$CONFIG->dbprefix}objects_entity oe{$mindex} on oe{$mindex}.guid = m{$mindex}.entity_guid "; 
				if ($meta_value!=="")
					$where[] = "(m{$mindex}.value_id='$meta_v' OR oe{$mindex}.title='$meta_value')";
				$mindex++;
			}
		}
		if ($order_by_column){
			$order_by_column = get_metastring_id($order_by_column);
			$join .= " LEFT JOIN 
						(select v_orderby.string as order_col, m_orderby.entity_guid as entity_guid
						from {$CONFIG->dbprefix}metadata m_orderby
						LEFT JOIN {$CONFIG->dbprefix}metastrings v_orderby on v_orderby.id = m_orderby.value_id
						where m_orderby.name_id={$order_by_column}) as order_tbl
						ON order_tbl.entity_guid = e.guid";
		    
		    $order_by = "order_tbl.order_col desc, e.time_created desc";
		}
		$entity_type = sanitise_string($entity_type);
		$entity_subtype = get_subtype_id($entity_type, $entity_subtype);
		$limit = (int)$limit;
		$offset = (int)$offset;
		if ($order_by == "") $order_by = "e.time_created desc";
		$order_by = sanitise_string($order_by);
		$owner_guid = (int) $owner_guid;
		
		$site_guid = (int) $site_guid;
		if ($site_guid == 0)
			$site_guid = $CONFIG->site_guid;
			
		//$access = get_access_list();

		if ($entity_type!="")
			$where[] = "e.type = '{$entity_type}'";
		if ($entity_subtype)
			$where[] = "e.subtype = {$entity_subtype}";
		if ($site_guid > 0)
			$where[] = "e.site_guid = {$site_guid}";
		if ($owner_guid > 0)
			$where[] = "e.container_guid = {$owner_guid}";
		
		if ($count) {
			$query = "SELECT count(distinct e.guid) as total ";
		} else {
			$query = "SELECT distinct e.* "; 
		}
			
		$query .= " from {$CONFIG->dbprefix}entities e {$join} where";
		foreach ($where as $w)
			$query .= " $w and ";
		$query .= get_access_sql_suffix("e"); // Add access controls
	
		$mindex = 1;
		foreach($meta_array as $meta_name => $meta_value) {
			$query .= ' and ' . get_access_sql_suffix("m{$mindex}"); // Add access controls
			$mindex++;
		}
		
		if (!$count) {

			$query .= " order by $order_by limit $offset, $limit"; // Add order and limit
			//print_r($query);die();

			return get_data($query, "entity_row_to_elggstar");
				            
		} else {	
			if ($count = get_data_row($query)) {
				return $count->total;
			}
		}
		return false;
	}
}

?>