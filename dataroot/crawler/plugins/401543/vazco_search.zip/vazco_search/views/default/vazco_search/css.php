.v_search_searchterms{
	width: 650px;
	height: 200px;
}

.v_search_checkboxes{
	float: left;
	margin: 10px;
}

.v_search_terms .submit_button{
	float:right;
	margin-top:15px;
}

.v_search_terms .search_box{
	float: left;
	margin:15px 15px 0;
}
.v_search_terms .search_box div{
	float: left;
}
.v_search_terms input.v_search_box{
	width: 200px;
}