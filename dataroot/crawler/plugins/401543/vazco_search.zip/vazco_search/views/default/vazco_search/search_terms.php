<?php 
global $CONFIG;
$terms = vazco_search::getTerms();
$displayTerms = trigger_elgg_event('showsearchterms','all');

if (!empty($terms) && ($displayTerms == true)){

?>
<div class="contentWrapper v_search_terms">
<span class="v_narrow_search"><?php echo elgg_echo('vazco_search:narrow:title');?></span>
	<form action="<?php echo $CONFIG->wwwroot;?>action/vazco_search/search">
		<input type="hidden" name="subtype" value="<?php echo get_input('subtype');?>">
		<input type="hidden" name="object" value="<?php echo get_input('object');?>">
		<input type="hidden" name="tagtype" value="<?php echo get_input('tagtype');?>">
		<input type="hidden" name="owner_guid" value="<?php echo get_input('owner_guid',0);?>">
		<?php 
		$chosenTermTable = vazco_search::getChosenTermsTable();
		foreach ($terms as $term){

			$checked = "";
			if (vazco_search::isInChosenTerms($chosenTermTable, $term))
				$checked = 'checked="checked"';
			echo '<div class="v_search_checkboxes"> <input type="checkbox" name="tagTable['.urlencode($term).']" value="1" '.$checked.'/><span>'.$term.'</span></div>';
		}
		?>
		<div class="clearfloat"></div>
		<div class="search_box">
			<?php echo elgg_echo('searchbox:searchfor');?>
			<input class="v_search_box" type="text" name="tag" value="<?php echo urldecode(get_input('tag'));?>">
		</div>
		<input type="submit" class="submit_button" value="<?php echo elgg_echo("search:narrow"); ?>" />
		<div class="clearfloat"></div>
	</form>
</div>
<?php } ?>