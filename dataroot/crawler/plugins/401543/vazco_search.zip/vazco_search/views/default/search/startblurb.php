
<div class="contentWrapper">
	<?php 
	if (get_input('object') == 'user'){
		if ($vars['tag'] != ''){
			echo sprintf(elgg_echo("vazco_search:users:tag"),$vars['tag']);
		}else{
			echo elgg_echo("vazco_search:users:notag");
		}
	}else{
		if ($vars['tag'] != ''){
			echo sprintf(elgg_echo("tag:search:startblurb"),$vars['tag']);
		}else{
			echo elgg_echo("vazco_search:startblurb:notag");
		} 	
	}
	?>
</div>