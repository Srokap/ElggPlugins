<?php
global $CONFIG; 
$entity = $vars['entity'];
?>
<div class="v_search_box">
	<p>
		<?php echo elgg_echo('vazco_search:input:desc');?>
	</p>
	<p>
		<textarea class="v_search_searchterms" name="params[searchterms]"><?php echo htmlentities($entity->searchterms, ENT_QUOTES, 'UTF-8'); ?></textarea>
	</p>
	
	<p>
		<?php echo elgg_echo('vazco_search:settings:searchparams');?>
	</p>
	<p>
		<textarea class="v_search_searchterms" name="params[sortterms]"><?php echo htmlentities($entity->sortterms, ENT_QUOTES, 'UTF-8'); ?></textarea>
	</p>
	<p>
		<?php echo elgg_echo('vazco_search:settings:searchparams:desc');?>
	</p>
	<p>
		<a href="<?php echo $CONFIG->wwwroot;?>action/vazco_search/updateall"><?php echo elgg_echo('vazco_search:updateall');?></a>
	</p>
</div>