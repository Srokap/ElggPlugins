<?php

	/**
	 * Elgg vazco_topbar plugin
	 * 
	 * @author Michal Zacher [michal.zacher@gmail.com]
	 * @website www.elggdev.com
	 */
    require_once(dirname(__FILE__)."/models/model.php");

    function vazco_search_init() {
		global $CONFIG;
		extend_view('css','vazco_search/css');
		extend_view('search/narrow','vazco_search/narrow_users',1);
		extend_view('search/narrow','vazco_search/search_terms',5);
		register_action("vazco_search/search",false,$CONFIG->pluginspath . "vazco_search/actions/search.php");
		register_action("vazco_search/updateall",false,$CONFIG->pluginspath . "vazco_search/actions/updateall.php");
		
		register_plugin_hook('action','flexprofile/edit','vazco_search_flexprofile_save');
		register_plugin_hook('action','profile/edit','vazco_search_profile_save');
		
		register_plugin_hook('search','all','vazco_search_dont_list_users');
		//$newMetaArray = trigger_elgg_event('narrowsearch','all',$metaArray);
		register_plugin_hook('permissions_check:metadata', 'user', 'vazco_search_metadata_permissions',1);

	}
	function vazco_search_metadata_permissions($event, $object_type, $object, $vars){
		if ($vars['metadata']['name'] == 'sortorder')
			return true;
		return $object;
	}
	function vazco_search_dont_list_users($event, $object_type, $object,$list){
		return false;
	}
	
	function vazco_search_override_searchterms($event, $object_type, $object,$list){
		if (get_input('object') == 'user')
			return true;
		return true;
	}
	
	function vazco_search_flexprofile_save(){
		global $CONFIG;
		//new method needs to be implemented for this
	}
	function vazco_search_profile_save(){
		global $CONFIG;
		vazco_search::updateSortOrder();
	}
     // Make sure the status initialisation function is called on initialisation
	register_elgg_event_handler('init','system','vazco_search_init');
	
?>