<?php
	global $CONFIG;

	$searchTable = vazco_search::getSearchTable();
	$tagSearchString = vazco_search::getSearchStringFromSearchTable($searchTable);
	$tag = get_input('tag');

	$object_subtype = get_input('subtype','');
	$md_type = get_input('tagtype','');
	$owner_guid = get_input('owner_guid',0);
	$object_type = get_input('object','');
	$forwardString = $CONFIG->wwwroot . "search/?tag=". $tag ."&subtype=" . $object_subtype . "&object=". urlencode($object_type) ."&tagtype=" . urlencode($md_type) . "&owner_guid=" . urlencode($owner_guid).$tagSearchString;
	forward($forwardString);
?>