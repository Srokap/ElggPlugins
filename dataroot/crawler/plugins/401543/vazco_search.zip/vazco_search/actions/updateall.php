<?php 
	if (vazco_search::updateAll()){
		system_message(elgg_echo('vazco_search:updateall:success'));
		forward($_SERVER['HTTP_REFERER']);
	}
?>