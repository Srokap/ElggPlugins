<?php

	$english = array(
		
		'vazco_search:input:desc' => 'Input search terms below. Separate terms by coma:',
		'search:narrow' => 'Narrow the search',
		'search:noresults' => 'No results found',
		'search:empty' => '',
		'searchbox:searchfor' => 'Search for tag:',
		'vazco_search:narrow:title' => 'Narrow search',
		'vazco_search:startblurb:notag' => 'Items matching:',
		'vazco_search:users:tag' => 'Users with tag matching \'%s\':',
		'vazco_search:users:notag' => 'Users matching:',
		'vazco_search:exception:wrongsearchsorttermparams' => 'Sortterm parameters are wrongly set.',
		'vazco_search:settings:searchparams' => 'Please input search sort parameters in format:<br/>
		Parameter | points',
		'vazco_search:settings:searchparams:desc' => 'The more points the given parameter has, the higher the object with the given parameter will be on the search list',
		'vazco_search:updateall:success' => 'User sort order was succesfully updated',
		'vazco_search:updateall' => 'Update user sort order (run after changing and saving search sort parameters)',
	);
					
	add_translation("en",$english);
?>