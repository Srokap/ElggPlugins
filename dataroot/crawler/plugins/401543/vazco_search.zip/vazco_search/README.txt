IMPORTANT!

To make this plugin work, you have to copy the index.php file from this directory over the:

YourElggInstall/search/index.php