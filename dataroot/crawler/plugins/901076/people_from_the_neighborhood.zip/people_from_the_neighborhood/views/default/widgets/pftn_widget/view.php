<?php
/**
* people_from_the_neighborhood
*
* @author emdagon
* @link http://community.elgg.org/pg/profile/emdagon
* @copyright (c) Condiminds 2011
* @link http://www.condiminds.com/
* @license GNU General Public License (GPL) version 2
*/

gatekeeper();

$widget = $vars['entity'];

$friends = $widget->look_in_friends == 'no' ? 0 : 2;
$groups = $widget->look_in_groups == 'no' ? 0 : 2;
$num_display = $widget->num_display != null ? $widget->num_display : 2;

$people = people_from_the_neighborhood_get_people(get_loggedin_userid(), 2, $groups);

echo elgg_view('people_from_the_neighborhood/people', array('people' => $people)); ?>
<div class="clearfloat"></div>
<div class="widget_more_wrapper"><a href="<?php echo $vars['url']; ?>pg/pftn"><?php echo elgg_echo('pftn:see:more'); ?></a></div>
