<?php

        /**
         * Elgg Doodle Plugin
         * 
         * @package Doodle
         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author Cim
         * @copyright DEMYX 2009
         * @link http://demyx.com/
         * 
         */
        
                function doodle_init() {
                    
                    
                        
                    //add a widget
                            add_widget_type('doodle',elgg_echo("doodle:title"),elgg_echo("doodle:description"));
                        
                }
                
                register_elgg_event_handler('init','system','doodle_init');

?>
