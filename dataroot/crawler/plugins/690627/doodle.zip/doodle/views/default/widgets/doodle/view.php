<?php
    
        /**
         * Elgg Doodle Plugin
         *
         * @package Doodle
         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author Cim
         * @copyright DEMYX 2009
         * @link http://demyx.com/
         *
         */
         

?>

<!-- Doodle -->

<div class="contentWrapper user_settings">
<!--  <?php echo $vars['entity']->doodle; ?> -->

<?php
$input = "" . $vars['entity']->doodle;
   // below is the tags that you want to allow, i added the html basic tags to be allowed to use
   echo strip_tags($input, "<h1><h2><h3><h4><h5><h6><p><a><img><font><table><tr><td><style><ul><li><ol><div><center><form><hr><i><b><u><small><span><input><textarea><input><select><option><br><caption><th><object><strike><strong>");
   
?>

<!-- Doodle -->

</div>

