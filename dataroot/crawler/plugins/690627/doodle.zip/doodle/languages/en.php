<?php

        $english = array(
        
        /**
         * Elgg Doodle Plugin
         *
         * @package Doodle
         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author Cim
         * @copyright DEMYX 2009
         * @link http://demyx.com/
         *
         */
                
                
                'doodle:title' => "Doodle",
                'doodle:description' => "Feel free to add anything on this box. (HTML enabled)",
                
                
        );
                                        
        add_translation("en",$english);

?>
