<script src="<?php echo $vars['url']; ?>/mod/thewire/views/default/thewire/scripts/jquery.tools.min.js"></script>
	<?php
		// Get any wire notes to display
		// Get the current page's owner
		$page_owner = page_owner_entity();
		if ($page_owner === false || is_null($page_owner)) {
			$page_owner = $_SESSION['user'];
			set_page_owner($page_owner->getGUID());
		}
		
		$num = $vars['entity']->num_display;
		if(!$num)
			$num = 4;
		
		$thewire = $page_owner->getObjects('thewire', $num);
		
		echo "<div id=\"AjaxAddForm\">";
		$display = "<textarea name='note' rows='3' cols='35' value='' onKeyDown=\"textCounter('note','remLen1',140)\" onKeyUp=\"textCounter('note','remLen1',140)\">{$msg}</textarea>";
		$display .= "<div class='thewire_characters_remaining'><input readonly type=\"text\" name=\"remLen1\" size=\"3\" maxlength=\"3\" value=\"140\" class=\"thewire_characters_remaining_field\">";
		echo $display;
		echo elgg_echo("thewire:charleft") . "</div>";
		echo elgg_view('input/securitytoken');
		echo "<input type=\"hidden\" name=\"method\" value=\"site\" />";
		echo "<input type=\"button\" id=\"ajaxWireAdd\" onclick=\"DoAjaxAdd()\" value=\"Submit\" />";
		echo "</div>";
		
		// If there are any thewire to view, view them
		echo "<div id=\"thewire_currentuser\">".$page_owner->username."'s Posts</div>";
		echo "<div id=\"thewire_widget_wrapper\" >";
		if (is_array($thewire) && sizeof($thewire) > 0) {
			
			foreach($thewire as $shout) {
				
				echo elgg_view_entity($shout);
				
			}
			
		}
		echo "</div>";
		
		//get the correct size
		$size = (int) $vars['entity']->icon_size;
		if (!$size || $size == 1){
			$size_value = "small";
		}else{
			$size_value = "tiny";
		}
			
		// Get the users friends
		$friends = $page_owner->getFriends("", 0, $offset = 0);
			
		// If there are any $friend to view, view them
		if (is_array($friends) && sizeof($friends) > 0) {
			echo "<div style=\"padding: 10px;\"><a href=\"#\" onclick=\"LoadFriendWire('".$page_owner->username."')\">My Posts</a> | Add New Post</div>";
			echo "<div class=\"thewire_friends_wrapper\">";
			echo "<a class=\"prevPage browse left\"></a>";
			echo "<div id=\"thewire_widget_friends_list\">";
			echo "<div class=\"items\">";
			foreach($friends as $friend) {
				echo "<div class=\"widget_friends_singlefriend\" id=\"".$friend->username."\" >";
				echo elgg_view("profile/icon",array('entity' => get_user($friend->guid), 'size' => $size_value));
				echo "</div>";
			}
			echo "</div>";
			echo "</div>";
			echo "<a class=\"nextPage browse right\"></a>";
			echo "</div>";
			
		}
		
	?>
	<input type="hidden" id="thewire_selecteduser" value="<?php echo $page_owner->username; ?>" />
	<script> 
	// execute your scripts when the DOM is ready. this is a good habit 
	$(function() 
	{      
		// initialize scrollable     
		$("#thewire_widget_friends_list").scrollable();
		$('#thewire_widget_friends_list .avatar_menu_button').click(function() {
			var username = $(this).parent().parent().attr('id');
			LoadFriendWire(username);
		});
	}); 
	
	function LoadFriendWire(UserName)
	{
		$('#thewire_widget_wrapper').load('<?php echo $vars['url']; ?>mod/thewire/index.php?username=' + UserName + '&dnum=' + <?php echo $num ?>+ ' #shout_wrapper');
		$('#thewire_currentuser').text(UserName + "'s Posts");
		$('#thewire_selecteduser').val(UserName);
	}
	
	function textCounter(field,cntfield,maxlimit) {
		// if too long...trim it!
		var theField = $("textarea[name='" + field + "']");
		if (theField.val().length > maxlimit) {
			theField.val(theField.val().substring(0, maxlimit));
		} else {
			// otherwise, update 'characters left' counter
			$("input[name='" + cntfield + "']").val(maxlimit - theField.val().length);
		}
	}
	
	function ShowAjaxReply(id,username)
	{
		$("#AjaxReplyForm" + id + " > textarea[name='note" + id + "']").val("@" + username + " ");
		$("#AjaxReplyForm" + id).attr("style", "display: block;");
	}
	
	function DoAjaxReply(replyformguid)
	{
		var token = $("#AjaxReplyForm" + replyformguid + " > input[name='__elgg_token']").attr("value");
		var ts = $("#AjaxReplyForm" + replyformguid + " > input[name='__elgg_ts']").attr("value");
		//var method = $("#AjaxReplyForm" + replyformguid + " > input[name='method']").attr("value");
		var note = $("#AjaxReplyForm" + replyformguid + " > textarea[name='note" + replyformguid + "']").attr("value");
		
		datastr = "__elgg_token=" + token;
		datastr += "&__elgg_ts=" + ts;
		datastr += "&method=Widget";
		datastr += "&note=" + note;
		
		//alert( $("#AjaxReplyForm" + replyformguid).parent().parent().parent().attr("id"));
		$.ajax({
		  type: "POST",
		  url: "<?php echo $vars['url']; ?>action/thewire/add",
		  data: datastr,
		  success: function(msg){
				LoadFriendWire($('#thewire_selecteduser').val());
		  }
		});
	}
	
	function DoAjaxAdd()
	{
		var token = $("#AjaxAddForm > input[name='__elgg_token']").attr("value");
		var ts = $("#AjaxAddForm > input[name='__elgg_ts']").attr("value");
		//var method = $("#AjaxAddForm > input[name='method']").attr("value");
		var note = $("#AjaxAddForm > textarea[name='note']").attr("value");
		
		datastr = "__elgg_token=" + token;
		datastr += "&__elgg_ts=" + ts;
		datastr += "&method=Widget";
		datastr += "&note=" + note;
		
		//alert( $("#AjaxReplyForm" + replyformguid).parent().parent().parent().attr("id"));
		$.ajax({
		  type: "POST",
		  url: "<?php echo $vars['url']; ?>action/thewire/add",
		  data: datastr,
		  success: function(msg){
		   $("#AjaxAddForm > textarea[name='note']").val("");
		   $(".thewire_characters_remaining_field").val("140");
		   LoadFriendWire('<?php echo $page_owner->username; ?>');
		  }
		});
	}
	
	function AjaxDelete(id)
 {
		var answer = confirm("Are you sure you want to delete this post?");
		
		if(answer)
		{
			var token = $("#AjaxReplyForm" + id + " > input[name='__elgg_token']").attr("value");
			var ts = $("#AjaxReplyForm" + id + " > input[name='__elgg_ts']").attr("value");
			//var method = $("#AjaxReplyForm" + id + " > input[name='method']").attr("value");
			
			datastr = "__elgg_token=" + token;
			datastr += "&__elgg_ts=" + ts;
			datastr += "&method=Widget";
			datastr += "&thewirepost=" + id;
			
		$.ajax({
			type: "GET",
			url: "<?php echo $vars['url']; ?>action/thewire/delete",
			data: datastr,
			success: function(msg){
					 LoadFriendWire('<?php echo $page_owner->username; ?>');
			 }
		});
	}
 }
	</script>
	<style type="text/css">
	.thewire_friends_wrapper
	{
		width: 100%;
	}
	/*     root element for the scrollable.     
	when scrolling occurs this element stays still. */ 
	#thewire_widget_friends_list 
	{      
		/* required settings */     
		position:relative;     
		overflow:hidden;     
		width: 220px;     
		height:40px;
	}  
	/*     root element for scrollable items. Must be absolutely positioned     
	and it should have a extremely large width to accomodate scrollable items.     
	it's enough that you set width and height for the root element and     
	not for this element. */ 
	#thewire_widget_friends_list div.items 
	{     
		/* this cannot be too large */     
		width:20000em;     
		position:absolute; 
	}  
	/*     a single item. must be floated in horizontal scrolling.     
	typically, this element is the one that *you* will style     
	the most. */ 
	#thewire_widget_friends_list div.items div.widget_friends_singlefriend 
	{     
		float:left; 
	}  
	/* you may want to setup some decorations to active the item */ 
	#thewire_widget_friends_list div.active 
	{     
		border:2px inset #ccc;     
		background-color:#fff; 
	}
	
	
	/* this makes it possible to add next button beside scrollable */
	.scrollable {
		float:left;	
	}

	/* prev, next, prevPage and nextPage buttons */
	a.browse {
		background: url(<?php echo $vars['url']; ?>/mod/thewire/graphics/hori_large.png) no-repeat;
		display:block;
		width:30px;
		height:30px;
		float:left;
		margin:0px 0px;
		cursor:pointer;
		font-size:1px;
	}

	/* right */
	a.right 		
	{ 
			float: right; 
			display: block; 
			background-position: 0 -30px; 
			clear:right; 
			margin-right: 0px;
			margin-top: -40px;
	}
	a.right:hover 	{ background-position:-30px -30px; }
	a.right:active 	{ background-position:-60px -30px; } 


	/* left */
	a.left				{ margin-left: 0px; border-right: solid 2px white; } 
	a.left:hover  		{ background-position:-30px 0; }
	a.left:active  	{ background-position:-60px 0; }

	/* up and down */
	a.up, a.down		{ 
		background:url(vert_large.png) no-repeat; 
		float: none;
		margin: 10px 50px;
	}

	/* up */
	a.up:hover  		{ background-position:-30px 0; }
	a.up:active  		{ background-position:-60px 0; }

	/* down */
	a.down 				{ background-position: 0 -30px; }
	a.down:hover  		{ background-position:-30px -30px; }
	a.down:active  	{ background-position:-60px -30px; } 


	/* disabled navigational button */
	a.disabled {
		visibility:hidden !important;		
	} 	
	</style>