<div class="contentWrapper">
<div align="left">

<?php
echo '<IFRAME FRAMEBORDER=0 SCROLLING=auto WIDTH=680 HEIGHT=500 SRC="http://wavemobi.com/go/index.php"></IFRAME>';
?>


</div>
</div>