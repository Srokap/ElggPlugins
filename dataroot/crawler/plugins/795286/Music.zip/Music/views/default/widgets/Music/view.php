<?php
	/**
	 * Elgg Music widget plugin
	 * This is a Music plugin that will find youre favo songs. please use it Just for fun 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author wavemobi.com
	 */
	 ?>
     
	 

<?php
echo '<IFRAME FRAMEBORDER=0 SCROLLING=auto WIDTH=300 HEIGHT=500 SRC="http://wavemobi.com/go2/index.php"></IFRAME>';
?>



