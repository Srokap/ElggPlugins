<?php
		function Music_init() 
		{
		global $CONFIG;
		add_menu(elgg_echo('Music'), $CONFIG->wwwroot . "mod/Music");
		}
		
	register_elgg_event_handler('init','system','Music_init');
	// Shares widget
		add_widget_type('Music',elgg_echo("Music"),elgg_echo("This is a Music widget that will find any song for you."));

?>