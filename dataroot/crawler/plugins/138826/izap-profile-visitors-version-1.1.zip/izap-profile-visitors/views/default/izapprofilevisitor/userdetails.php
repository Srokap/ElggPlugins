<?php
	 /**
	 * iZAP izap profile visitor
	 * 
	 * @license GNU Public License version 3
	 * @author iZAP Team "<support@izap.in>"
	 * @link http://www.izap.in/
	 * @version 1.1
	 * @compatibility elgg-1.5
	 */
	// iZAP visitor marker //
	izapMarkVisitor();