<?php

/*
** Colleagues (as opposed to friends)
**
** @author Philip Hart, Centre for Learning and Performance Technology (www.c4lpt.co.uk)
** @copyright Tesserae Ltd 2009
** @link http://www.c4lpt.co.uk/ElggConsultancy.html
** @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
**
*/

$english = array(
    'friends' => "Buddies",
    'friends:yours' => "Your Buddies",
    'friends:owned' => "%s's Buddies",
    'friends:add:successful' => "You have successfully added %s as a Buddy.",
    'friends:add:failure' => "We couldn't add %s as a Buddy. Please try again.",
    'friends:remove:successful' => "You have successfully removed %s from your Buddies.",
    'friends:remove:failure' => "We couldn't remove %s from your Buddiess. Please try again.",
    'friends:none' => "This user hasn't added anyone as a Buddy yet.",
    'friends:none:you' => "You haven't added anyone as a Buddy! Search for your interests to begin finding people to follow.",
    'friends:none:found' => "No Buddies were found.",
    'friends:of:none' => "Nobody has added this user as a Buddy yet.",
    'friends:of:none:you' => "Nobody has added you as a Buddy yet. Start adding content and fill in your profile to let people find you!",
    'friends:of' => "Buddies of",
    'friends:of:owned' => "People who have made %s as a Buddy",
    'friends:num_display' => "Number of Buddies to display",
    'friends' => "Buddies",
    'friends:of' => "Buddies of",
    'friends:collections' => "Collections of Buddies",
    'friends:collections:add' => "New collection of Buddies",
    'friends:addfriends' => "Add Buddies",
    'friends:collectionname' => "Collection name",
    'friends:collectionfriends' => "Buddies in collection",
    'friends:river:created' => "%s added the Buddies widget.",
    'friends:river:updated' => "%s updated their Buddies widget.",
    'friends:river:delete' => "%s removed their Buddies widget.",
    'friends:river:add' => "%s added a new Buddy",

    'river:relationship:friend' => "is now a Buddy of",

    'friend:add' => "Add as a Buddy",
    'friend:remove' => "Remove as a Buddy",
    'friend:newfriend:subject' => "%s has added you as a Buddy!",
    'friend:newfriend:body' => "%s has added you as a Buddy!

To view their profile, click here:

%s

You cannot reply to this email.",

    'friends:all' => "All Buddies",

    'friends:invite' => 'Invite Buddies',
    'invitefriends:introduction' => 'To invite Buddies to join you on this network, enter their email addresses below (one per line):',
    'invitefriends:success' => 'Your Buddies were invited.',
    'invitefriends:failure' => 'Your Buddies could not be invited.',

    'file:yours:friends' => "Your Buddies' files",
    'file:friends' => "%s's Buddies' files",
    'file:friends:type:video' => "Your Buddies' videos",
    'file:friends:type:document' => "Your Buddies' documents",
    'file:friends:type:audio' => "Your Buddies' audio",
    'file:friends:type:image' => "Your Buddies' pictures",
    'file:friends:type:general' => "Your Buddies' general files",

    'access:friends:label' => "Buddies",

    'feeds:friends' => "Buddies feeds",
    'feeds:friendsfeeds' => 'Buddies\' feeds',
    'feeds:friendswelcome' => "This page lets you view all of the feeds your colleagues have made available to their network. If any are available, you will see a list over on the righthand side. Click on a link to read the contents",

    'river:widget:title:friends' => "Buddies' activity",
    'river:widget:description:friends' => "Show what your Buddies are up to.",

    'bookmarks:friends' => "Buddies' bookmarks",

    'river:widget:title:friends' => "Buddies' activity",
    'river:widget:description:friends' => "Show what your Buddies are up to.",
    'river:widgets:friends' => "Buddies",

    'thewire:friendsdesc' => 'This widget will show the latest from your Buddies on the wire',
    'thewire:friends' => 'Your Buddies on the wire',

    'blog:user:friends' => "%s's Buddies' blog",
    'blog:friends' => "Buddies' blogs",

    'friend_request' => "Buddy Requests",
    'friend_request:menu' => "Buddy Requests",
    'friend_request:title' => "Buddy Requests",
	
    'friend_request:new' => "New Buddy request",
		
    'friend_request:newfriend:subject' => "%s wants to be your buddy!",
    'friend_request:newfriend:body' => "%s wants to be your buddy! But they are waiting for you to approve the request.. So login now so you can approve the request!",
    'friends_of_friends' => 'Buddies of Buddies',
    'friendsoffriends' => 'Buddies of Buddies',
    'friends_of_friends:setting:hidefriendsof' => "Hide Buddies of",
    'friends_of_friends:setting:showfriendsof' => "Show Buddies of",
    'bbar:user:enableicons'		=> 'Show user icons in buddies list?',
    'bbar:bar:friends'		=> 'Buddies',
    'bbar:bar:noneonline'		=> 'No Buddy online',

    'album:yours:friends' => "Your Buddies' photo albums",
    'album:friends' => "%s's Buddies' photo albums",


);

add_translation("en", $english);

?>