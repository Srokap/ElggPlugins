<?php	

/*
** Buddies (as opposed to friends)
**
** @author Zenin Easa
** @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
**
*/

function buddies_init()
{
	global $CONFIG;
			
	register_translations($CONFIG->pluginspath . "buddies/languages/");
}

// Initialise this plugin
register_elgg_event_handler('init','system','colleagues_init');

?>
