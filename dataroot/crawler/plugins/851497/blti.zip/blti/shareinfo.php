<?php

set_context('groups');

// Must be logged in to use this page
gatekeeper();

// Get group details
$group_guid = (int) get_input('group_guid');
$group = get_entity($group_guid);
set_page_owner($group_guid);
$share_key = get_input('sharekey');

$area2 = elgg_view_title(elgg_echo('LTI:share'));
$area2 .= elgg_view('page_elements/contentwrapper', array('body' => $share_key));

$body = elgg_view_layout('two_column_left_sidebar', $area1, $area2);

// Finally draw the page
page_draw($title, $body);

?>