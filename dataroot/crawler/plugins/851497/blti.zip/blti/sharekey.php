<?php

/*-------------------------------------------------------------------
 * Elgg LTI
 *
 * Create a share key --- includes all the workflow text
 ------------------------------------------------------------------*/

global $CONIFG;

set_context('groups');

// Must be logged in to use this page
gatekeeper();

// Get group details
$group_guid = (int) get_input('group_guid');
$group = get_entity($group_guid);
set_page_owner($group_guid);

$area2 = elgg_view_title(elgg_echo('LTI:share:key'));
$area2 .= elgg_view('page_elements/contentwrapper', array('body' => elgg_echo('LTI:share:explain')));
$area2 .= elgg_view('page_elements/contentwrapper', array('body' => elgg_echo('LTI:share:workflow')));

// Is this context shared?

$consumer_instance = new LTI_Tool_Consumer_Instance(get_input('LTIconsumerguid'), $CONFIG->dbprefix);
$context = new LTI_Context($consumer_instance, $group->context_id);
$shares = $context->getShares();
if (!empty($shares)) {
    $area2 .= elgg_view('page_elements/contentwrapper', array('body' => elgg_echo('LTI:share:shared')));
} else {
    $area2 .= elgg_view('page_elements/contentwrapper', array('body' => elgg_echo('LTI:share:notshared')));
}

// Life dropdown
$formbody = '<div id="LTI_formarea"><table><tr><td>';
$formbody .= elgg_echo('LTI:share:life');
$formbody .= elgg_view('input/pulldown',
                     array('internalname' => 'life',
                           'options_values' => array( '1'   =>  '1 hr',
                                                      '2'   =>  '2 hr',
                                                     '12'   => '12 hr',
                                                     '24'   => '1 day',
                                                     '48'   => '2 day',
                                                     '72'   => '3 day',
                                                     '96'   => '4 day',
                                                     '120'  => '5 day',
                                                     '168'  => '1 week'
                                                    ),
                           'value' => '1 hr'
                          )
                     );
$formbody .= '</td><td>&nbsp;</td><td>';

// Pre-approve Checkbox
$formbody .= elgg_echo('LTI:share:preapprove');
$formbody .= '</td><td>';
$formbody .=  elgg_view('input/checkboxes',
                        array('internalname' => 'auto_approve',
                              'options' => array('' => 'yes')
                             )
                        );
// Email
$formbody .= '</td></tr><tr><td>';
$formbody .= elgg_echo('LTI:share:emailaddress');
$formbody .= elgg_view('input/text',
                        array('internalname' => 'email',
                             'value' => 'test@no-reply.com'
                             )
                      );
$formbody .= '</td></tr></table></div>';

$formbody .= elgg_view('input/hidden',
                      array('internalname' => 'consumer_guid',
                           'value' => $group->consumer_key
                           )
                      );

$formbody .= elgg_view('input/hidden',
                      array('internalname' => 'context_id',
                           'value' => $group->context_id
                           )
                      );

$user = get_loggedin_user();
$formbody .= elgg_view('input/hidden',
                      array('internalname' => 'fromemail',
                            'value' => $user->email
                           )
                      );
$form = elgg_view('input/form',
                 array('action' => $CONFIG->wwwroot . 'action/' . $CONFIG->ltiname . '/createshare',
                        'body' => $formbody
                      )
                 );

$form .= elgg_view('lti/addshare');

$area2 .= elgg_view('page_elements/contentwrapper', array('body' => $form));

$body = elgg_view_layout('two_column_left_sidebar', $area1, $area2);

// Finally draw the page
page_draw($title, $body);

?>