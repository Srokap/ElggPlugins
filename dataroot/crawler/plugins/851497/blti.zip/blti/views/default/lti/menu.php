<?php

/*-------------------------------------------------------------------
 * Elgg LTI Group menu extender
 *
 ------------------------------------------------------------------*/

global $CONFIG;

// Need to be logged in
gatekeeper();

$user = get_loggedin_user();

echo "Menu";
?>