<?php

/*-------------------------------------------------------------------
 * Elgg LTI topbar extender
 *
 ------------------------------------------------------------------*/

global $CONFIG;

// Need to be logged in to have return to consumer option
gatekeeper();

$user = get_loggedin_user();

if (!empty($_SESSION['return_url'])) {

    $url = elgg_add_action_tokens_to_url($CONFIG->wwwroot . 'action/' . $CONFIG->ltiname . '/return');
    echo '<a class="usersettings" href="' . $url . '">' . $_SESSION['return_name'] . '</a>';

}
?>