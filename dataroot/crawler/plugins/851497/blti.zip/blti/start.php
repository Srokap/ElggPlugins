<?php

/*-------------------------------------------------------------------
 * Elgg LTI
 *
 * @author Simon Booth
 * @copyright JISC ceLTIc
 * @link http://www.celtic-project.org
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Contact: s.p.booth@stir.ac.uk
 *
 * Version history:
 *   1.0 First public release -
 ------------------------------------------------------------------*/
$CONFIG->ltiname = 'blti';
$CONFIG->ltipath = $CONFIG->pluginspath . $CONFIG->ltiname . '/';
$CONFIG->wwwltipath = $CONFIG->wwwroot . 'mod/' . $CONFIG->ltiname . '/';

// include the LTI Tool Provider class
require_once($CONFIG->ltipath . 'lib/BasicLTI_Tool_Provider.php');
// include Utility library
require_once($CONFIG->ltipath . 'lib/Utility.php');
// include our LTIgroup functions (just to create the group);
require_once($CONFIG->ltipath . 'lib/LTIGroup.php');
// include our LTIUser functions (just to create the users);
require_once($CONFIG->ltipath . 'lib/LTIUser.php');

/*-------------------------------------------------------------------
 * Elgg plugin initialisation function called by:
 *
 * register_elgg_event_handler('init', 'system', 'lti_init');
 *
 ------------------------------------------------------------------*/
function lti_init() {

    // Get config
    global $CONFIG;

    // Check DB
    CheckDB();

    // Set log file
    $logfile = $CONFIG->ltipath . 'logs/LTI.log';
    set_plugin_setting('logfile', $logfile, $CONFIG->ltiname);

    // Mechanisms to register and unregister LTI actions
    register_action($CONFIG->ltiname . '/return',         false, $CONFIG->ltipath . 'actions/return.php');
    register_action($CONFIG->ltiname . '/createconsumer', false, $CONFIG->ltipath . 'actions/createconsumer.php');
    register_action($CONFIG->ltiname . '/saveconsumer',   false, $CONFIG->ltipath . 'actions/saveconsumer.php');
    register_action($CONFIG->ltiname . '/enable',         false, $CONFIG->ltipath . 'actions/enable.php');
    register_action($CONFIG->ltiname . '/createshare',    false, $CONFIG->ltipath . 'actions/createshare.php');
    register_action($CONFIG->ltiname . '/sync',           false, $CONFIG->ltipath . 'actions/sync.php');
    register_action($CONFIG->ltiname . '/dosync',         false, $CONFIG->ltipath . 'actions/dosync.php');
    register_action($CONFIG->ltiname . '/approve',        false, $CONFIG->ltipath . 'actions/approve.php');

    // Page handler
    register_page_handler($CONFIG->ltiname, 'LTI_page_handler');

    register_plugin_hook('plugin:setting', 'all', 'LTI_ValidateGroupProvision');

    // Allow instructors to have owner access
    register_plugin_hook('permissions_check', 'group', 'LTIgroup_operators_permissions_hook');
    // Allow instructors to update user details but within context of group
    register_plugin_hook('permissions_check', 'user', 'LTIgroup_operators_permissions_hook');

    // Extend the elgg topbar. See views/default/lti/topbar.php for the code run by this function
    elgg_extend_view('elgg_topbar/extend','lti/topbar');

}
/*------------------------------------------------------------------
 * Page setup called before pages are drawn by Elgg. This adds the
 * LTI options to the administrator menu and Sync to groups. Called
 * by
 *
 * register_elgg_event_handler('pagesetup','system','LTI_pagesetup');
 ------------------------------------------------------------------*/
function LTI_pagesetup() {

    global $CONFIG;

    $page_owner = page_owner_entity();

    // Add administrator's menu items
    if (get_context() == 'admin' && isadminloggedin()) {

        add_submenu_item(elgg_echo('LTI:registered'), $CONFIG->wwwroot . 'pg/' . $CONFIG->ltiname . '/displayconsumers');

    }

    // Group submenu: add the option to Sync Users
    $user = get_loggedin_user();
    if ($page_owner instanceof ElggGroup && get_context() == 'groups') {
        // LTI plugin must be enabled, Group must be LTI and current user must be instructor from module
        // Also need to add check that extensions are enabled for this consumer. Finally check that instructor
        // can create/update

        // Get status of instructors for create/update users
        $values = GetPluginSettings();
        $allowinstructor = $values['allowinstructor'];

        // Get context to allow check that membership servce is available before putting up Sync option.
        // Use the user context to ensure we check against consumer they came from
        $consumer_instance = new LTI_Tool_Consumer_Instance($user->consumer_key, $CONFIG->dbprefix);
        $context = new LTI_Context($consumer_instance, $user->context_id);

        if(is_plugin_enabled($CONFIG->ltiname) &&
           !empty($page_owner->consumer_key) &&
           ($context->hasMembershipsService()) &&
           (check_entity_relationship($user->getGUID(), 'instructor', $page_owner->getGUID())) && $allowinstructor) {

            //$page_owner->consumer_key;
            add_submenu_item(sprintf(elgg_echo('LTI:sync')), $CONFIG->wwwroot . 'pg/' . $CONFIG->ltiname . '/synctext/' . $page_owner->getGUID());
        }

        // Only display sharing options to instructors from primary context
        if(is_plugin_enabled($CONFIG->ltiname) &&
           !empty($page_owner->consumer_key) &&
           ($page_owner->consumer_key == $user->consumer_key) &&
           (check_entity_relationship($user->getGUID(), 'instructor', $page_owner->getGUID()))) {
            add_submenu_item(sprintf(elgg_echo('LTI:share:key')),    $CONFIG->wwwroot . 'pg/' . $CONFIG->ltiname . '/sharekey/' . $page_owner->consumer_key . '/' . $page_owner->getGUID() . '/');
            add_submenu_item(sprintf(elgg_echo('LTI:share:manage')), $CONFIG->wwwroot . 'pg/' . $CONFIG->ltiname . '/sharemanage/' . $page_owner->consumer_key . '/' . $page_owner->getGUID() . '/');
        }
    }
}

/*------------------------------------------------------------------
 * Check that the groups plugin is enabled when group provisioning
 * is requested. If not do  not allow group provisioning to be
 * enabled.
 ------------------------------------------------------------------*/
function LTI_ValidateGroupProvision($hook, $entity_type, $returnvalue, $params) {

    global $CONFIG;

    $plugin = $params['plugin'];
    $name = $params['name'];
    $value = $params['value'];

    if ($plugin == 'lti' && $name == 'groupprovision' && $value == 'yes') {
        if (!is_plugin_enabled('groups')) {
            register_error(elgg_echo('LTI:plugin:notenabled'));
            $returnvalue = false;
        }
    }

    return $returnvalue;
}


/*------------------------------------------------------------------
 * Set up various Elgg page handlers. We can use this to expose URLs
 * outside of Elgg that 'disappear' when the plugin is disabled. The
 * URLs are of the form:
 *
 * http://your_elgg_site/pg/plugin_name
 *
 * These main purpose of the page handler is to 'knit together output
 * from different views to form the page that the user sees'. Hence
 * the code that display the Full or Basic LTI consumers is handled
 * here.
 ------------------------------------------------------------------*/
function LTI_page_handler($page) {

    global $CONFIG;

    switch ($page[0]) {
    case '':
        require_once($CONFIG->ltipath . '/pages/register.php');
        break;
    case 'displayconsumers':
        require_once($CONFIG->ltipath . '/pages/' . $page[0] . '.php');
        break;
    // These pages exploit the parameter passing mechanism avaiable via
    // the page handler
    case 'editconsumer':
        set_input('LTIconsumerguid', $page[1]);
        require_once($CONFIG->ltipath . '/editconsumer.php');
        break;
    case 'remove':
        set_input('LTIconsumerguid', $page[1]);
        require_once($CONFIG->ltipath . '/remove.php');
        break;
    case 'delete':
        set_input('LTIconsumerguid', $page[1]);
        require_once($CONFIG->ltipath . '/delete.php');
        break;
    case 'synctext':
        set_input('group_guid', $page[1]);
        require_once($CONFIG->ltipath . '/synctext.php');
        break;
    case 'sync':
        set_input('group_guid', $page[1]);
        set_input('filter', $page[2]);
        require_once($CONFIG->ltipath . 'actions/sync.php');
        break;
    case 'sharekey':
        set_input('LTIconsumerguid', $page[1]);
        set_input('group_guid', $page[2]);
        require_once($CONFIG->ltipath . '/sharekey.php');
        break;
    case 'sharemanage':
        set_input('LTIconsumerguid', $page[1]);
        set_input('group_guid', $page[2]);
        require_once($CONFIG->ltipath . '/sharemanage.php');
        break;
    }

    return true;

}

/*-------------------------------------------------------------------
 * Based on group operators plugin. Allows users with relationship
 *'instructor' to edit a group just like the owner
 ------------------------------------------------------------------*/
function LTIgroup_operators_permissions_hook($hook, $entity_type, $returnvalue, $params) {

    return LTIgroup_operators_container_permissions_hook($hook,
                                                         $entity_type,
                                                         $returnvalue,
                                                         array('container'=>$params['entity'],
                                                               'user'=>$params['user']
                                                              )
                                                        );
}

function LTIgroup_operators_container_permissions_hook($hook, $entity_type, $returnvalue, $params) {

    if ($params['user'] && $params['container']->type == 'user') {
        $page_owner = page_owner_entity();
        $user_guid = $params['user']->getGUID();

        if (!empty($page_owner)) {
            // Any instructor can update user
            if (check_entity_relationship($user_guid, 'instructor', $page_owner->getGUID())) return true;
            // Group owner can update user
            if ($user_guid == $page_owner->getOwner()) return true;
        }
    }

    if ($params['user'] && $params['container']->type == 'group') {

        $container_guid = $params['container']->getGUID();
        $user_guid = $params['user']->getGUID();

        if (check_entity_relationship($user_guid, 'instructor', $container_guid)) return true;
    }

    return $returnvalue;
}

/*-------------------------------------------------------------------
 * Called when a group is deleted, if the group has been provisioned
 * by LTI we need to clean up some of the database tables.
 ------------------------------------------------------------------*/
function LTI_Group_Delete($event, $object_type, $group) {

    global $CONFIG;

    // Check we have LTI group (i.e. it has a context and consumer_key) and the delete
    // event is occurring
    if (!empty($group->context_id) && !empty($group->consumer_key) && $event == 'delete') {
        $consumer_instance = new LTI_Tool_Consumer_Instance($group->consumer_key, $CONFIG->dbprefix);
        $context = new LTI_Context($consumer_instance, $group->context_id);

        if (is_plugin_enabled('notifications')) {

            if ($context->hasMembershipsService()) {
                // Inform all instructors that group is being deleted using
                // membership list from consumer
                InformInstructorsViaLTIMembership($group, $context, $consumer_instance->guid);
            } else {
                // No Membership service, so use group members
                InformInstructorsViaGroupMembership($group);
            }
        }

        $context->delete();
    }

    return true;

}

register_elgg_event_handler('init', 'system', 'lti_init');
register_elgg_event_handler('pagesetup','system','LTI_pagesetup');
register_elgg_event_handler('delete', 'group', 'LTI_Group_Delete');

?>