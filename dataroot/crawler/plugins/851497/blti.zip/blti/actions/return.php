<?php

/*-------------------------------------------------------------------
 * Elgg LTI
 *
 * Return to whence we came!
 ------------------------------------------------------------------*/

$user = get_loggedin_user();

if (!empty($_SESSION['return_url'])) {
    $return_url = $_SESSION['return_url'];
    $result = logout();

    if ($result) {
        $urlencode = urlencode('You have been logged out of ' . $CONFIG->sitename);
        $url = $return_url . '&lti_msg=' . $urlencode;
        forward($url);

    } else {

        register_error('Failed to logout --- please use Log Off');

    }

}
?>