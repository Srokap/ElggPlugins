<?php

/*-------------------------------------------------------------------
 * Elgg LTI
 *
 * Approve/Suspend share
 ------------------------------------------------------------------*/
global $CONFIG;

set_context('groups');

// Must be logged in to use this page
gatekeeper();

$group_guid = (int) get_input('group');
$group = get_entity($group_guid);
set_page_owner($group_guid);

$consumer_instance = new LTI_Tool_Consumer_Instance(get_input('guid'), $CONFIG->dbprefix);
$context = new LTI_Context($consumer_instance, get_input('id'));

$approve = ($context->share_approved) ? false : true;

$primary_guid = $context->primary_consumer_instance_guid;
$consumer_instance = new LTI_Tool_Consumer_Instance($primary_guid, $CONFIG->dbprefix);
$context = new LTI_Context($consumer_instance, $context->primary_context_id);

$context->doApproveShare(get_input('guid'), get_input('id'), $approve);

forward($CONFIG->wwwroot . 'pg/' . $CONFIG->ltiname . '/sharemanage/' . $primary_guid . '/' . $group_guid);
?>