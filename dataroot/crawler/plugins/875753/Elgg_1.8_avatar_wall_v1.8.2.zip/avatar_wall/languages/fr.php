<?php
$french = array(
'avatar_wall' => "Mur des Avatars",
'avatar_wall:title' => "Le Mur des Avatars",
'avatar_wall:shorttitle' => "Mur des Avatars",
'avatar_wall:description' => "Le Mur des Avatars affiche tous les utilisateurs avec leurs avatars sur une seule page.",
'avatar_wall:today' => "Membres actifs aujourd'hui",
'avatar_wall:week' => "Membres actifs cette semaine",
'avatar_wall:all' => "Tous les membres",

'avatar_wall:settings:onlywithavatar' => "Afficher uniquement les utilisateurs avec un avatar personnalisé? ",
'avatar_wall:settings:tiny' => "Minuscule",
'avatar_wall:settings:small' => "Petite",
'avatar_wall:settings:iconsize' => "Quelle taille d'icône doit être utilisée sur le mur? ",
'avatar_wall:settings:maxicons' => "Indiquez le nombre maximum d'icônes sur le mur:",
);

add_translation("fr", $french);
