<?php
$german = array(
'avatar_wall' => "Avatar-Pinnwand",
'avatar_wall:title' => "Avatar-Pinnwand",
'avatar_wall:shorttitle' => "Avatar-Pinnwand",
'avatar_wall:description' => "Die Avatar-Pinnwand zeigt alle Mitglieder mit ihren Avataren auf einer Seite an.",
'avatar_wall:today' => "Aktive Mitglieder von heute",
'avatar_wall:week' => "Aktive Mitglieder dieser Woche",
'avatar_wall:all' => "Alle Mitglieder",

'avatar_wall:settings:onlywithavatar' => "Nur Mitglieder anzeigen, die eigene Avatare hochgeladen haben? ",
'avatar_wall:settings:tiny' => "Sehr klein",
'avatar_wall:settings:small' => "Klein",
'avatar_wall:settings:iconsize' => "Welche Bildgröße soll für die Pinnwand verwendet werden? ",
'avatar_wall:settings:maxicons' => "Gebe an, wieviele Avatare maximal auf der Pinnwand angezeigt werden sollen:",
);

add_translation("de", $german);
