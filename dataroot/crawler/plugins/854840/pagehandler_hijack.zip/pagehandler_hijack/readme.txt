**************************************************
 *                                              *
  *            Pagehandler Hijack              *
 *                                              *
**************************************************

Installation: unzip to mod directory, enable through plugin page

Usage: On the settings page enter in replacement terms for handlers that
show in the URL.  These replacement handlers will become active for inbound links,
existing links in the site will be updated to reflect this change.