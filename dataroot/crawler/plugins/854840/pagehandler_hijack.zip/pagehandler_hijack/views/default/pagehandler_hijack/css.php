
.pagehandler_hijack_thead {
	font-weight: bold;
	text-align: center;
	padding: 10px;
}

.pagehandler_hijack_element_default, .pagehandler_hijack_element_replacement {
	padding: 5px;
}

.pagehandler_hijack_form_element_wrapper {
	border: 1px solid #cecece;
	display: inline-block;
}

.phh-even {
	background-color: #cecece;
}