****************************************

 @author 	VMLab            
 @link 		http://www.vmlab.it/
 @mail 		info@vmlab.it

****************************************

Elgg version 1.7.3
Italian Language Pack v1.2

Copy the directory from .zip file in your elgg installation root.

Enjoy!!

include files it.php for

- languages

- mod

- blog - bookmarks - chapta - catagories - custom_index - defaultwidget - diagnostic - 
embed - event_calendar - externalpages - file - friends - garbagecollector - groups - invitefriends - logbrowser - 
logrotate - members - messageboard - messages - notifications - pages - profile - profile_manager
reportedcontent - riverdashboard - search - thewire - tinymce - twitter - twitterservice - 
uservalidationbymail - chat - likes - resume
