<?php
/**
 * @author VMLab
 * @link http://www.vmlab.it/
 */

	$italian = array(
		'logrotate:period' => 'Ogni quanto dovrebbe essere archiviato il system log?',
	
		'logrotate:weekly' => 'Una volta a settimana',
		'logrotate:monthly' => 'Una volta al mese',
		'logrotate:yearly' => 'Una volta ogni anno',
	
		'logrotate:logrotated' => "Log rotated\n",
		'logrotate:lognotrotated' => "Error rotating log\n",
	);
					
	add_translation("it",$italian);
?>