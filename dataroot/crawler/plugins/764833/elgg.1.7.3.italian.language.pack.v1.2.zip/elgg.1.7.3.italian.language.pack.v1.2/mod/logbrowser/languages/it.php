<?php
/**
 * @author VMLab
 * @link http://www.vmlab.it/
 */

	$italian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'logbrowser' => 'Navigatore di Resoconti',
			'logbrowser:browse' => 'Naviga il sistema dei resoconti',
			'logbrowser:search' => 'Raffina i risultati',
			'logbrowser:user' => 'Username da cercare',
			'logbrowser:starttime' => 'Tempo di partenza (per esempio "lunedi scorso", "1 ora fa").)',
			'logbrowser:endtime' => 'Fino a',
	
			'logbrowser:explore' => 'Esplora resoconto',
	
	);
					
	add_translation("it",$italian);
?>