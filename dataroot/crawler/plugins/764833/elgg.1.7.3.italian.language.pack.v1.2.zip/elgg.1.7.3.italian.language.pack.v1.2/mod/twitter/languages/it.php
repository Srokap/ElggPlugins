<?php
/**
 * @author VMLab
 * @link http://www.vmlab.it/
 */
	$italian = array(
	
		/**
		 * twitter widget details
		 */
		
	
		'twitter:username' => 'Inserisci il tuo username twitter.',
		'twitter:num' => 'Numero di tweet da visualizzare.',
		'twitter:visit' => 'seguimi su twitter',
		'twitter:notset' => 'Il gadget Twitter non &egrave; ancora configurato. Per visualizzare i tuoi ultimi tweet, clicca su - modifica - e inserisci i tuoi dettagli',
		
		
		 /**
	     * twitter widget river
	     **/
	        
	        //generic terms to use
	        'twitter:river:created' => "%s ha aggiunto il gadget twitter.",
	        'twitter:river:updated' => "%s ha aggiornato il gadget twitter.",
	        'twitter:river:delete' => "%s ha rimosso il gadget twitter.",
	        
		
	);
					
	add_translation("it",$italian);

?>