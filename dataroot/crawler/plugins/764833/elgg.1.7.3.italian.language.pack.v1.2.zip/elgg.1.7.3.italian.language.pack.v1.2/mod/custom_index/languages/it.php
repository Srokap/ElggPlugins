<?php
/**
 * @author VMLab
 * @link http://www.vmlab.it/
 */
	$italian = array(
	
			'custom:bookmarks' => "Segnalibri recenti",
			'custom:groups' => "Gruppi recenti",
			'custom:files' => "File recenti",
			'custom:blogs' => "Ultimi articoli inseriti",
			'custom:members' => "Nuovi membri",
			'custom:nofiles' => "Non sono presenti file ancora",
			'custom:nogroups' => "Non ci sono gruppi ancora",
	
	);
					
	add_translation("it",$italian);

?>