<?php
/**
 * @author VMLab
 * @link http://www.vmlab.it/
 */

	$italian = array(
	
		'captcha:entercaptcha' => 'Inserisci il testo da un\'immagine',
		'captcha:captchafail' => 'Siamo spiacenti, il testo che hai inserito non corrisponde con il testo nell\'immagine.',
	
	);
					
	add_translation("it",$italian);
?>