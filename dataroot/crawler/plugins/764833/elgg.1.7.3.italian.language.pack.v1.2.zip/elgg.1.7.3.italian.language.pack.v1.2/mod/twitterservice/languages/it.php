<?php
/**
 * @author VMLab
 * @link http://www.vmlab.it/
 */
	$italian = array(
		'twitterservice' => 'Twitter',
		'twitterservice:postwire' => 'Impostando le seguenti opzioni ogni messaggio che pubblicherai in bacheca verr&agrave; inviato al tuo account twitter. Vuoi pubblicare i tuoi messaggi in bacheca su Twitter?',
		'twitterservice:twittername' => 'Twitter username',
		'twitterservice:twitterpass' => 'Twitter password',
	);
					
	add_translation("it",$italian);
?>