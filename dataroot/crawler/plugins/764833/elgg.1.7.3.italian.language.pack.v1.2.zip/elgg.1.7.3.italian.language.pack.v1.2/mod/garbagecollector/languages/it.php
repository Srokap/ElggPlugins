<?php
	/**
 * @author VMLab
 * @link http://www.vmlab.it/
 */

	$italian = array(
	
		/**
		 * Menu items and titles   ###Argomenti del menu e titoli###
		 */
	
			'garbagecollector:period' => 'Quanto spesso vorresti far funzionare il garbage collector di Elgg?',
	
			'garbagecollector:weekly' => 'Una volta ogni settimana',
			'garbagecollector:monthly' => 'Una volta ogni mese',
			'garbagecollector:yearly' => 'Una volta ogni anno',
	
			'garbagecollector' => "Garbage collector\n",
			'garbagecollector:done' => "Fatto\n",
			'garbagecollector:optimize' => "Sto ottimizzando %s ",
	
			'garbagecollector:error' => "ERRORE",
			'garbagecollector:ok' => "OK",
	
			'garbagecollector:gc:metastrings' => 'Sto pulendo le Metastring non collegate: ',
	
	);
					
	add_translation("it",$italian);
?>