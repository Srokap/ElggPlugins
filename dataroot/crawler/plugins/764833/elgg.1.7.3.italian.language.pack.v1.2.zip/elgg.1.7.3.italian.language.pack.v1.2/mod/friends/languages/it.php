<?php
/**
 * @author VMLab
 * @link http://www.vmlab.it/
 */
	$italian = array(
	
		/**
		 * Friends widget
		 */
			'friends:widget:description' => "Visualizza alcuni dei tuoi amici.",
	        
		
	);
					
	add_translation("it",$italian);

?>