<?php
/**
 * @author VMLab
 * @link http://www.vmlab.it/
 */
	$italian = array(
	
		'email:validate:subject' => "%s per favore conferma il tuo indirizzo email!",
		'email:validate:body' => "Ciao %s,

Per favore conferma il tuo indirizzo email cliccando sul seguente link:

%s
",
		'email:validate:success:subject' => "Email convalidata %s!",
		'email:validate:success:body' => "Ciao %s,
			
Congratulazioni, hai convalidato il tuo indirizzo email con successo.",
	
		
		'email:confirm:success' => "Hai confermato il tuo indirizzo email!",
		'email:confirm:fail' => "Il tuo indirizzo email non pu&ograve; essere convalidato...",
	
		'uservalidationbyemail:registerok' => "Per attivare il tuo account, per favore apri la tua casella di posta e clicca sul link che ti abbiamo inviato."
	
	);
					
	add_translation("it",$italian);
?>