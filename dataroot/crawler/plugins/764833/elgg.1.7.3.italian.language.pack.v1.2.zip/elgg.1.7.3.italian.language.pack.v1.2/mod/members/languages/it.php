<?php
/**
 * @author VMLab
 * @link http://www.vmlab.it/
 */
	$italian = array(
			
		'members:members' => "Membri",
	    'members:online' => "Utenti on-line",
	    'members:active' => "utenti del sito",
	    'members:searchtag' => "Cerca utenti per tag",
	    'members:searchname' => "Cerca utenti per nome",
	   
		'members:label:newest' => 'Recenti',
		'members:label:popular' => 'In evidenza',
		'members:label:active' => 'On-line',
		'members:search:name' => 'Nome utente',
		'members:search:tags' => 'Tag',
		
	);
					
	add_translation("it",$italian);

?>