<?php
/**
 * @author VMLab
 * @link http://www.vmlab.it/
 */
	$italian = array(
	
		'media:insert' => 'Incorpora / carica file multimediale',
	
		'embed:instructions' => 'Clicca su un file per incorporarlo nel tuo articolo.',
	
		'embed:media' => 'Incorpora file multimediale',
		'upload:media' => 'Carica file multimediale',
	
		'embed:file:required' => 'Nessun modulo di caricamento dei file trovato. L\'amministratore di sistema pu&ograve; avere bisogno di caricare il plugin.',
	
	);
					
	add_translation("it",$italian);

?>