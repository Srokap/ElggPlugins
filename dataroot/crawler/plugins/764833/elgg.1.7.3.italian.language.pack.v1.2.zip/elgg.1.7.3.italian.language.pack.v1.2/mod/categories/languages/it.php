<?php
/**
 * @author VMLab
 * @link http://www.vmlab.it/
 */
	$italian = array(
	
		'categories' => 'Categorie',
		'categories:settings' => 'Imposta le categorie del sito',	
		'categories:explanation' => 'Per impostare alcune categorie predefinite a livello di sito, che verranno utilizzate in tutto il sistema, inserirle sotto, separate da virgole. Gli strumenti compatibili verranno poi visualizzati quando l\'utente crea o modifica il contenuto.',	
		'categories:save:success' => 'Le categorie del sito sono state salvate con successo.',
		'categories:results' => "Risultati per la categoria del sito: %s",
	
	);
					
	add_translation("it",$italian);

?>