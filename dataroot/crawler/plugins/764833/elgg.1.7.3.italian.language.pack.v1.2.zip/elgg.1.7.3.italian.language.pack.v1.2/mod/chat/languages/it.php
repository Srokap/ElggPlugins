<?php

	$italian = array(
        /**
         * Misc
         */
            'chat:open' => 'Apri chat'
	
	);
					
	add_translation("it", $italian);

?>
