<?php
/**
 * @author VMLab
 * @link http://www.vmlab.it/
 */
	$italian = array(
	
		/**
		 * Menu items and titles
		 */
	
		'tinymce:remove' => "Aggiungi/Rimuovi editor",
	
	);
					
	add_translation("it",$italian);

?>