******************************
*****PLEASE READ CAREFULLY****
******************************

This is not the plugin that you need to enable chat on your site. This only the directions 
as to how to obtain the plugin from Toksta. 


******************************
******DIRECTIONS**************
******************************

1. Go to ww2.toksta.com and register for an account
2. Choose your plan (i.e. free, or paid)
3. Now create your IM or Chat Room
4. After you have configured all of your options for your script click on 'Integration'
5. Next click on 'Create Script'
6. SCroll down to where it says "Create Plugin", select Elgg then download it
7. You need to read the installation document very carefully so you install it correctly 
on your elgg based site.