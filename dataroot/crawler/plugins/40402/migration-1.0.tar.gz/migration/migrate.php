<?php
/**
 *
 * @author Diego Andrés Ramírez Aragón
 * @copyright Corporación Somos más - 2008
 */

require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
require_once dirname(__FILE__) . "/config.php";
require_once dirname(__FILE__) . "/common.php";
require_once 'Console/CommandLine.php';

set_time_limit(0);
ini_set('memory_limit', '1024M');

global $CONFIG;

$CONFIG->debug = false;

function migrate($modules,$prefix,$verbose=true){

  foreach($modules as $module){
    error_log("\nStarting $module migration...");

    $check_function = "{$module}_check_tables";
    $count_function = "{$module}_count_items";
    $load_function = "{$module}_load_items";
    $save_function = "{$module}_save_items";

    if(function_exists($check_function)){
      if($verbose) error_log("\tChecking elgg 0.9 tables...");
      if($check_function($prefix)){
        if($verbose) error_log("\tNeed tables...\tOK");
        if(function_exists($count_function) && function_exists($load_function) && function_exists($save_function)){
          $count = $count_function($prefix);
          for($i=0;$i<$count;$i+=100){
            $items = $load_function($i,100,$prefix);
            if(!empty($items)){
              $result = $save_function($items,$prefix);
              if($verbose) error_log("\tMigrated {$result} items from {$i} to ".($i+100)."...");
            }
          }
          error_log("Finishing $module migration");
        }
        else{
          error_log("ER  ROR: $module didn't some of required functions ($count_function,$load_function,$save_function)");
        }
      }
      else{
        error_log("\tNeed tables...\tfail");
        error_log("ERROR: $module migration failed");
      }
    }
    else{
      error_log("ERROR: $module didn't provide the required functions");
    }
  }
}

/***********************************************************
 * Command line configuration and execution
 ***********************************************************/

$parser = new Console_CommandLine();
$parser->description = 'Elgg migration tool.';
$parser->version = '1.0';
$parser->addOption('prefix', array(
    'short_name'  => '-p',
    'long_name'   => '--prefix',
    'description' => 'Elgg 0.9 database prefix',
    'help_name'   => 'PREFIX',
    'default'	  => 'elgg_',
    'action'      => 'StoreString')
);

$parser->addOption('quiet', array(
    'short_name'  => '-q',
    'long_name'   => '--quiet',
    'description' => "don't print status messages to stdout",
    'action'      => 'StoreTrue')
);

$parser->addArgument("modules",array(
    'description'=> "Ordered list separated by spaces of modules to be loaded",
    'multiple'=>true,
    'optional'=>true)
);

try {
  $available_modules = migration_modules(dirname(__FILE__));
  $result = $parser->parse();
  // Authenticate admin user to grant access for all operations
  $admin = get_entity(ADMIN_GUID);
  if(login($admin,true)){
    echo "Elgg Migration tool {$parser->version}\n";
    echo "=======================\n";
    echo "Selected options\n";
    $loaded_modules = (empty($result->args["modules"]))?array("users"):$result->args["modules"];
    echo "Elgg 0.9 db prefix:\t".$result->options["prefix"]."\n";
    echo "Modules:\t\t".implode(",",$loaded_modules)."\n";

    foreach($loaded_modules as $module){
      if(!in_array($module,$available_modules)){
        error_log("ERROR:\t $module is an invalid module! Please check available modules before try again\n");
        exit;
      }
    }
    $init_time = time();
    migrate($loaded_modules,$result->options["prefix"],!$result->options["quiet"]);
    $end_time = time();
    echo "\nMigration time: ".(($end_time-$init_time))." seconds\n";

  }else{
    error_log("ERROR: ". ADMIN_GUID ." is an invalid user guid");
  }
} catch (Exception $exc) {
  $parser->displayError($exc->getMessage());
}

?>