<?php
/**
 * Elgg 0.9 to Elgg 1.0 blog functions
 *
 * @author Juan Carlos Lucero
 * @copyright Corporación Somos más - 2008
 */

$weblog_extensions= array();

if(file_exists(dirname(__FILE__)."/config.php")){
  require_once dirname(__FILE__)."/config.php";
}

/**
 * Check if the need Elgg 0.9 tables are available (weblog_posts,tags)
 *
 * @param string $prefix
 * @return boolean
 */
function blog_check_tables($prefix=""){
  global $CONFIG;
  $prefix = (empty($prefix))?$CONFIG->dbprefix:$prefix;
  $query = "show tables like '{$prefix}weblog_posts'";
  $resp = get_data($query);
  return !empty($resp);
}

/**
 * Return how many items are avaible for migrate
 *
 * @param string $prefix
 * @return integer
 */
function blog_count_items($prefix=""){
  global $CONFIG,$weblog_extensions;
  $nofilter = implode(',',array_map(create_function("\$item","return \"'\$item'\";"),$weblog_extensions));
  $prefix = (empty($prefix))?$CONFIG->dbprefix:$prefix;
  $query = "SELECT count(*) as total FROM {$prefix}weblog_posts ";
  $query.= "WHERE ident NOT IN (SELECT distinct ref FROM {$prefix}tags WHERE tagtype='weblog' AND tag in ($nofilter))";
  $total = get_data_row($query);
  if(!empty($total)){
    return $total->total;
  }
  return 0;
}

/**
 * Load Elgg 0.9 user objects from database
 *
 * @param int $offset
 * @param int $limit
 * @param string $prefix
 * @return mixed
 */
function blog_load_items($offset=0,$limit=100,$prefix=""){
  global $CONFIG,$weblog_extensions;
  $nofilter = implode(',',array_map(create_function("\$item","return \"'\$item'\";"),$weblog_extensions));
  $prefix = (empty($prefix))?$CONFIG->dbprefix:$prefix;
  $query = "SELECT * FROM {$prefix}weblog_posts ";
  $query.= "WHERE ident NOT IN (SELECT distinct ref FROM {$prefix}tags WHERE tagtype='weblog' AND tag IN ($nofilter)) ";
  $query.= "ORDER BY ident asc";
  if($limit){
    $query.=" LIMIT $offset,$limit";
  }
  $users = get_data($query,"entity_row_to_elgg_user");
  return $users;
}
/**
 * Takes a array with Elgg 0.9 weblog posts and save it as Elgg 1.0 weblog posts
 *
 * @param mixed $items Array with Elgg 0.9 weblog posts
 * @param string $prefix
 * @return integer How many items were stored
 */
function blog_save_items($items,$prefix=""){
  global $CONFIG;
  $prefix = (empty($prefix))?$CONFIG->dbprefix:$prefix;
  $count = 0;
  if(is_array($items)){
    foreach($items as $entity){
      //creating the new elgg object subtype blog
      $blog = new ElggObject();
      $blog->subtype = "blog";
      $blog->access_id= 2;
      $blog->title = utf8_encode($entity->title);
      $blog->description = utf8_encode($entity->body);
      $blog->icon = $entity->icon;
      // Looking for users content owners
      if(!defined("DEFAULT_OWNER")){
        $owner = users_legacy_owner($entity->owner,$prefix);
        if(!empty($owner)){
          $owner = users_get_entity($owner->username);
          if(!empty($owner)){
            $blog->owner_guid = $owner->getGUID();
            $blog->container_guid = $owner->getGUID();
          }
          else{
            error_log("\t\tError: Couldn't find the owner(person) form {$blog->title}");
            continue;
          }
        }
        else{
          $blog_ = blogextended_migration_group_field($blog,$entity->owner,$prefix);
          if($blog_!=null){
            $blog = $blog_;
          }
          else{
            continue;
          }
        }
      }
      else if(defined("DEFAULT_OWNER")){
        $blog->owner_guid = DEFAULT_OWNER;
        $blog->container_guid = DEFAULT_CONTAINER;
      }
      else{
        error_log("\t\tError migrating {$blog->title}. Couldn't find the owner");
      }

      try{
        if ($blog->save()) {
          $guid = $blog->guid;
          $time_created = $entity->posted;
          update_entity_time_created($guid, $time_created);

          // fetching the old tags data to insert in the new object
          $query_get_tags = "SELECT tag FROM {$prefix}tags WHERE ref=$entity->ident AND owner=$entity->owner";
          $tagsObject = get_data($query_get_tags, "entity_row_to_elgg_tags");

          // creating the new tags array for the new Elgg Object
          $tagarray = array();
          if(is_array($tagsObject)){
            foreach($tagsObject as $tagObjectrow){
              $tagarray[] = utf8_encode(trim($tagObjectrow->tag));
            }
            // Registering the tags

            $blog->tags = blogextended_migration_type_field($blog,$tagarray);
          }

          $count++;
          unset($tagarray);
        }

      }
      catch(Exception $e){
        error_log("Error creating {$entity->title}");
        error_log($e->getMessage());
        error_log($e->getTraceAsString());
      }
    }
  }
  return $count;
}

function blogextended_migration_group_field($blog,$owner,$prefix){
  set_input("content_owner",null);
  $owner = legacy_group_name($owner,$prefix);
  if(!empty($owner)){
    $group = group_by_name(utf8_encode($owner->name));
    if(!empty($group)){
      $content_owner = $group->getGUID();
      $blog->set("content_owner",$content_owner);
    }
    else{
      error_log("\tError: Couldn't find the blog owner ({$owner->name})");
      return null;
    }
  }
  else{
    error_log("\tError: Invalid blog owner ({$owner})");
    return null;
  }
  return $blog;
}

function blogextended_migration_type_field($blog,$tags){
  global $CONFIG;
  set_input("blog_type",null);
  if(!empty($tags) && is_array($CONFIG->blogextended)){
    foreach($tags as $tag){
      if( ($blog_type = array_search($tag,$CONFIG->blogextended))){
        $blog->set("blog_type",$blog_type);
        $tags = array_diff($tags,array($tag));
        break;
      }
    }
  }
  return $tags;
}
?>