<?php
/**
 *
 * @author Diego Andrés Ramírez Aragón
 * @copyright Corporación Somos más - 2008
 */

function messages_check_tables($prefix=""){
  global $CONFIG;
  $prefix = (empty($prefix))?$CONFIG->dbprefix:$prefix;
  $query = "show tables like '{$prefix}messages'";
  $resp = get_data($query);
  return !empty($resp);
}

function messages_count_items($prefix=""){
  global $CONFIG;
  $prefix = (empty($prefix))?$CONFIG->dbprefix:$prefix;
  $query = "SELECT count(*) as total FROM {$prefix}messages";
  $total = get_data_row($query);
  if(!empty($total)){
    return $total->total;
  }
  return 0;
}

function messages_load_items($offset=0,$limit=100,$prefix=""){
  global $CONFIG,$weblog_extensions;
  $query = "SELECT * FROM {$prefix}messages ";
  $query.= "ORDER BY ident asc";
  if($limit){
    $query.=" LIMIT $offset,$limit";
  }
  $items = get_data($query,"entity_row_to_elgg_user");
  return $items;
}

function messages_save_items($items,$prefix=""){
  global $CONFIG;
  $prefix = (empty($prefix))?$CONFIG->dbprefix:$prefix;
  $count = 0;
  if(is_array($items)){
    foreach($items as $entity){
      if($entity->from_id ==-1) continue; //Ignore system messages
      $from = users_legacy_owner($entity->from_id,$prefix);
      if(!empty($from)){
        $from = users_get_entity($from->username);
      }
      $to = users_legacy_owner($entity->to_id,$prefix);
      if(!empty($to)){
        $to = users_get_entity($to->username);
      }

      if(($from instanceof ElggUser) && ($to instanceof ElggUser)){
        try{
          $message = new ElggObject();
          $message->subtype = "messages";
          $message->owner_guid = $from->getGUID();
          $message->container_guid = $from->getGUID();
          $message->access_id = 2;
          $message->title = utf8_encode($entity->title);
          $message->description = utf8_encode($entity->body);

          $message->toId = $to->getGUID(); // the user receiving the message
          $message->readYet = ($entity->status=="read"); // this is a toggle between 0 / 1 (1 = read)
          $message->hiddenFrom = $entity->hidden_from; // this is used when a user deletes a message in their sentbox, it is a flag
          $message->hiddenTo = $entity->hidden_to; // this is used when a user deletes a message in their inbox

          if ($guid = $message->save()) {
            update_entity_time_created($guid, $entity->posted);
            $count++;
          }
        }
        catch(Exception $e){
          error_log("\t\tError creating the message from {$from->name} to {$to->name}");
          error_log($e->getMessage());
          error_log($e->getTraceAsString());
        }
      }
      else{
        error_log("\t\tError: Couldn't create the message from [{$entity->from_id}] to [{$entity->to_id}]");
      }
    }
  }
  return $count;
}
?>