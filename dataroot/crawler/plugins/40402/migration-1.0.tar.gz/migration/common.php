<?php
/*
 * Created on 14/01/2009
 *
 * By Juan Carlos Lucero - Corporación Somos Más
 * juancarlos@somosmas.org - www.somosmas.org
 */

/**
 * Loads all migration modules available
 *
 * @param string $dir Root dir to scan for modules
 * @return mixed
 */
function migration_modules($dir){
  static $modules;
  $dir = (empty($dir))?".":$dir;
  if(!isset($modules)){
    $modules_ = array_diff(scandir($dir),array(".",".."));

    $modules = array();
    foreach($modules_ as $module){
      if(is_dir($dir.DIRECTORY_SEPARATOR.$module) && file_exists($dir.DIRECTORY_SEPARATOR.$module.DIRECTORY_SEPARATOR."lib.php")){
        require_once($dir.DIRECTORY_SEPARATOR.$module.DIRECTORY_SEPARATOR."lib.php");
        $modules[] = $module;
      }
    }
  }
  return $modules;
}

/**
 * Updates the 'time_created' field to specified value
 *
 * @param int $guid
 * @param string $time_created
 */
function update_entity_time_created($guid, $time_created){
  global $CONFIG, $ENTITY_CACHE;
  //@todo Review this
  $entity = get_entity($guid);
  $ret = update_data("UPDATE {$CONFIG->dbprefix}entities set time_created='$time_created' WHERE guid=$guid");
  return $ret;
}

function update_annotation_entity_time_created($owner_id,$user_id,$type, $time_created){
  global $CONFIG, $ENTITY_CACHE;
  $name = add_metastring($type);
  $query= "UPDATE {$CONFIG->dbprefix}annotations set time_created='$time_created' WHERE entity_guid=$owner_id AND owner_guid=$user_id";
  $query.= " AND name_id= $name";
  $ret = update_data($query);
  return $ret;
}
function users_get_entity($username){
  $entity = null;
  if(!empty($username)){
    $entity = get_user_by_username($username);
  }
  return $entity;
}

function group_by_name($name){
  global $CONFIG;
  $entity = null;
  if(!empty($name)){
    $access = get_access_sql_suffix();
    $row = get_data_row("SELECT guid from {$CONFIG->dbprefix}groups_entity where name='$name'");
    if(!empty($row)){
      $entity = get_entity($row->guid);
    }
  }
  return $entity;
}

/***********************/
/*  Legacy functions   */
/***********************/
function users_legacy_owner($ident,$prefix="",$users=true){
  global $CONFIG;
  $prefix = (empty($prefix))?$CONFIG->dbprefix:$prefix;
  $query = "SELECT * FROM {$prefix}users WHERE active='yes'";
  if($users){
    $query.=" AND user_type='person' ";
  }
  $query.= "AND ident=$ident";
  $user = get_data_row($query,"entity_row_to_elgg_user");
  if(!empty($user)){
    return $user;
  }
  return null;

}

function legacy_group_name($ident,$prefix=""){
  global $CONFIG;
  $prefix = (empty($prefix))?$CONFIG->dbprefix:$prefix;
  $query = "SELECT name FROM {$prefix}users WHERE ident={$ident}";
  $group = get_data_row($query,"entity_row_to_elgg_user");
  if(!empty($group)){
    return $group;
  }
  return null;

}

function legacy_blog_object($ident,$prefix=""){
  global $CONFIG;
  $prefix = (empty($prefix))?$CONFIG->dbprefix:$prefix;
  $query = "SELECT * FROM {$prefix}weblog_posts WHERE ident={$ident}";
  $object = get_data_row($query,"entity_row_to_elgg_user");
  if(!empty($object)){
    return $object;
  }
  return null;
}
/*
 //copying the group icon
 $username = $entity->username;
 $icon = $entity->icon;
 $filepath = get_icon_elgg09($username, $icon);
 $owner_guid = $group->guid;
 save_icon_elggone($owner_guid, $filepath, $username);
 */

function get_icon_elgg09($username, $icon)
{
 	// getting the old icon filename in elgg 0.9x
 	$query_icon = "SELECT filename FROM elgg_icons where ident=$icon";
 	$icondata = get_data($query_icon, "entity_row_to_elgg_user");
 	$array_username = str_split($username);

 	foreach($icondata as $icon)
 	{
 	  //creating the file path for the save icon function
 	  $filepath = PATH_ICONS_FROM . "/icons/" . $array_username[0] . "/" . $username . "/" . $icon->filename;
 	}

 	return $filepath;


}

function save_icon_elggone($owner_guid, $filepath, $username)
{
 	$profileicon = file_get_contents($filepath);

 	$topbar = get_resized_image_from_uploaded_file($profileicon,16,16, true);
 	$tiny = get_resized_image_from_uploaded_file($profileicon,25,25, true);
 	$small = get_resized_image_from_uploaded_file($profileicon,40,40, true);
 	$medium = get_resized_image_from_uploaded_file($profileicon,100,100, true);
 	$large = get_resized_image_from_uploaded_file($profileicon,200,200);
 	$master = get_resized_image_from_uploaded_file($profileicon,550,550);

 	if ($small !== false && $medium !== false && $large !== false && $tiny !== false) {
 	  $filehandler = new ElggFile();
 	  $filehandler->owner_guid = $owner_guid;
 	  $filehandler->setFilename("profile/" . $username . "large.jpg");
 	  $filehandler->open("write");
 	  $filehandler->write($large);
 	  $filehandler->close();
 	  $filehandler->setFilename("profile/" . $username . "medium.jpg");
 	  $filehandler->open("write");
 	  $filehandler->write($medium);
 	  $filehandler->close();
 	  $filehandler->setFilename("profile/" . $username . "small.jpg");
 	  $filehandler->open("write");
 	  $filehandler->write($small);
 	  $filehandler->close();
 	  $filehandler->setFilename("profile/" . $username . "tiny.jpg");
 	  $filehandler->open("write");
 	  $filehandler->write($tiny);
 	  $filehandler->close();
 	  $filehandler->setFilename("profile/" . $username . "topbar.jpg");
 	  $filehandler->open("write");
 	  $filehandler->write($topbar);
 	  $filehandler->close();
 	  $filehandler->setFilename("profile/" . $username . "master.jpg");
 	  $filehandler->open("write");
 	  $filehandler->write($master);
 	  $filehandler->close();
 	}

 	error_log($filehandler);
 	error_log($filepath);

}

?>