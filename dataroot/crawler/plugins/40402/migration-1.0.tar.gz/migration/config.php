<?php
/*
 * Created on 14/01/2009
 *
 * By Juan Carlos Lucero - Corporación Somos Más
 * juancarlos@somosmas.org - www.somosmas.org
 */


define("ADMIN_GUID","205");

 // This constant defines the owner of the exported data to elgg one
// define("DEFAULT_OWNER", 147);

 // This constant defines the default password for all the users imported
 define("DEFAULT_PASSWORD", "mko09ijn");

 // This constant defines the default container guid for the blog objects
// define("DEFAULT_CONTAINER", 147);

 // This constant defines the path from old data directory of elgg 0.9x
 //define("PATH_ICONS_FROM", "icons_to_save/data_elgg09");

 // This Constant defines
 //define("PATH_ICONS_TO", "icons_to_save/data_elggone");

?>