<?php
/**
 * Elgg 0.9 to Elgg 1.0 Group functions
 *
 * @author Juan Carlos Lucero
 * @copyright Corporación Somos más - 2008
 */
/**
 * Check for Elgg 0.9 need tables (users,profile_data)
 *
 * @param string $prefix
 * @return boolean
 */
function groups_check_tables($prefix=""){
  global $CONFIG;
  $prefix = (empty($prefix))?$CONFIG->dbprefix:$prefix;
  $query = "show tables like '{$prefix}users'";
  $resp = get_data($query);
  return !empty($resp);
}

/**
 * Return how many items are available for migration
 *
 * @param string $prefix
 * @return integer
 */
function groups_count_items($prefix=""){
  global $CONFIG;
  $prefix = (empty($prefix))?$CONFIG->dbprefix:$prefix;
  $query = "SELECT count(*) as total from {$prefix}users WHERE active='yes' AND user_type='community'";
  $total = get_data_row($query);
  if(!empty($total)){
    return $total->total;
  }
  return 0;
}

/**
 * Load Elgg 0.9 items
 *
 * @param int $offset
 * @param int $limit
 * @param string $prefix
 * @return mixed
 */
function groups_load_items($offset=0,$limit=100,$prefix=""){
  global $CONFIG;
  $prefix = (empty($prefix))?$CONFIG->dbprefix:$prefix;
  $query = "SELECT * FROM {$prefix}users WHERE active='yes' AND user_type='community'";
  $query.= "ORDER BY ident asc";
  if($limit){
    $query.=" LIMIT $offset,$limit";
  }
  $users = get_data($query,"entity_row_to_elgg_user");
  return $users;
}

/**
 * Takes a array with Elgg 0.9 groups and save it as Elgg 1.0 grops
 *
 * @param mixed $items Array with Elgg 0.9 groups
 * @param string $prefix
 * @return integer How many items were stored
 */
function groups_save_items($items,$prefix=""){
  global $CONFIG;
  $prefix = (empty($prefix))?$CONFIG->dbprefix:$prefix;
  $group_data = array("descriptionextended"=>array("description","text"),
					"minibio"=>array("briefdescription","text"),
					"interests"=>array("interests","tags"),
					"personalweb"=>array("website","text"),
					"state"=>array("location","text"),
					"country"=>array("country","text"),
					"town"=>array("country","text"),
  					"homephone"=>array("phone","text"),
					"streetaddress"=>array("address","text"),
					"communitytype"=>array("group_type","group_type"),
                    "yearcreation"=>array("creation_year","text"));

  if(file_exists(dirname(__FILE__)."/config.php")){
    @require_once dirname(__FILE__)."/config.php";
  }

  groups_fields_setup();

  $count = 0;

  if(is_array($items)){
    foreach( $items as $entity ){
      $group = group_by_name(utf8_encode($entity->name));
      if(!empty($group)) continue;
      // Creating the Group in ElggOne
      $group = new ElggGroup();
      $group->name = utf8_encode($entity->name);
      $group->membership = 1;
      $group->access_id = 2;
      $group->files_enable = "no";
      $group->pages_enable = "no";
      $group->forum_enable = "no";
      $owner = users_legacy_owner($entity->owner,$prefix);
      if(!defined("DEFAULT_OWNER") && !empty($owner)){
        $owner = users_get_entity($owner->username);
        if(!empty($owner)){
          $group->owner_guid = $owner->getGUID();
          $group->container_guid = $owner->getGUID();
        }
        else{
          error_log("\t\tError migrating {$group->name}. Couldn't find the owner");
          continue;
        }
      }
      else if(defined("DEFAULT_OWNER")){
        $group->owner_guid = DEFAULT_OWNER;
        $group->container_guid = DEFAULT_OWNER;
      }
      else{
        error_log("\t\tError migrating {$group->name}. Couldn't find the owner");
        continue;
      }

      // fecthing the profile info from elgg0.9x and saving as ElggOne metadata
      $owner_of_metadata = $entity->ident;

      $keys = array_keys($group_data);
      $keys = array_map(create_function("\$item","return \"'\$item'\";"),$keys);
      $keys = implode(",",$keys);

      $query_metadata = "SELECT name, value FROM {$prefix}profile_data WHERE owner=$owner_of_metadata and NAME IN ($keys)";
      $metadata = get_data($query_metadata, "entity_row_to_elgg_user");

      $translations = get_installed_translations();

      //adding the metadata obtained from elgg0.9 in our new objetc
      if(is_array($metadata)){
        foreach($metadata as $metadata_entity){
          $newkey = $group_data[$metadata_entity->name][0];
          $type = $group_data[$metadata_entity->name][1];
          $new_value = utf8_encode($metadata_entity->value);

          switch($type){
            case "tags":
              $new_value = string_to_tag_array(utf8_encode($metadata_entity->value));
              break;
            case "group_type":
              if(array_key_exists("group_type",$CONFIG->group)){
                list($input_type,$options) = $CONFIG->group["group_type"];
                if(array_key_exists($new_value,$options)){
                  foreach($translations as $key=>$value){
                    $var = "group_type_{$key}";
                    $group->clearMetadata($var);
                    $group->set($var,elgg_echo($options[$new_value],$key));
                  }
                  $new_value = $options[$new_value];
                }
                else{
                  error_log("\tWarning:({$group->name}) $new_value is not registered as a valid group type");
                }
              }
              else{
                error_log("\tWarning: groupextended is not available some group data couldn't be loaded!");
              }
              break;
              //@todo Adds the proper manipulation function for each data type
          }
          $group->set($newkey,$new_value);
        }
      }

      //Saving the new object
      set_context("admin");
      try{
        if($group->save()){
          $group->join($owner);
          $count++;
        }
      }
      catch(Exception $e){
        error_log("Error creating {$entity->name}");
        error_log($e->getMessage());
      }
    }
  }
  return $count;
}
?>