<?php
/**
 *
 * @author Diego Andrés Ramírez Aragón
 * @copyright Corporación Somos más - 2008
 */

function relationships_check_tables($prefix=""){
  global $CONFIG;
  $prefix = (empty($prefix))?$CONFIG->dbprefix:$prefix;
  $query = "show tables like '{$prefix}friends'";
  $resp = get_data($query);
  return !empty($resp);
}
function relationships_count_items($prefix=""){
  global $CONFIG;
  $prefix = (empty($prefix))?$CONFIG->dbprefix:$prefix;
  $query = "SELECT count(*) as total FROM {$prefix}friends ";
  $total = get_data_row($query);
  if(!empty($total)){
    return $total->total;
  }
  return 0;
}
function relationships_load_items($offset=0,$limit=100,$prefix=""){
  global $CONFIG,$weblog_extensions;
  $query = "SELECT * FROM {$prefix}friends ";
  $query.= "ORDER BY ident asc";
  if($limit){
    $query.=" LIMIT $offset,$limit";
  }
  $items = get_data($query,"entity_row_to_elgg_user");
  return $items;

}
function relationships_save_items($items,$prefix=""){
  global $CONFIG;
  $prefix = (empty($prefix))?$CONFIG->dbprefix:$prefix;
  $count = 0;
  if(is_array($items)){
    foreach($items as $entity){
      $owner = users_legacy_owner($entity->owner,$prefix,false);
      if(!empty($owner)){
        $owner = users_get_entity($owner->username);
      }
      $friend = users_legacy_owner($entity->friend,$prefix,false);
      if(!empty($friend)){
        $friend = users_get_entity($friend->username);
      }
      if(empty($friend)){
        $friend = users_legacy_owner($entity->friend,$prefix,false);
        if(!empty($friend)){
          $friend = group_by_name(utf8_encode($friend->name));
        }
      }

      if(($owner instanceof ElggUser) && ($friend instanceof ElggUser)){
        try{
          if($owner->addFriend($friend->getGUID())){
            $count++;
          }
          else{
            error_log("\t\tError: Couldn't create the relationship between {$owner->name} and {$friend->name}");
          }
        }
        catch(Exception $e){
          error_log("\t\tError creating the relationship between {$owner->name} and {$friend->name}");
          error_log($e->getMessage());
          error_log($e->getTraceAsString());
        }
      }
      else if(($owner instanceof ElggUser) && ($friend instanceof ElggGroup)){
        try{
          if(!$friend->isMember($owner)){
            if( $result = $friend->join($owner)){
              $count++;
            }
            else{
              error_log("\t\tError: Couldn't add {$owner->name} as member of {$friend->name} [$result]");
            }
          }
        }
        catch(Exception $e){
          error_log("\t\tError creating the relationship between {$friend->name} and {$owner->name}");
          error_log($e->getMessage());
          error_log($e->getTraceAsString());
        }
      }
      else{
        error_log("\t\tError: There is not possible to create a relationship between [{$entity->owner}] and [{$entity->friend}]. \n\t\t\tDid you syncronize users and groups before to syncronize relationships?");
      }
    }
  }
  return $count++;
}
?>