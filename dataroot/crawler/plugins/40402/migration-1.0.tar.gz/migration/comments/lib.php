<?php
/**
 *
 * @author Diego Andrés Ramírez Aragón
 * @copyright Corporación Somos más - 2008
 */

function comments_check_tables($prefix=""){
  global $CONFIG;
  $prefix = (empty($prefix))?$CONFIG->dbprefix:$prefix;
  $query = "show tables like '{$prefix}weblog_comments'";
  $resp = get_data($query);
  return !empty($resp);
}

function comments_count_items($prefix=""){
  global $CONFIG;
  $prefix = (empty($prefix))?$CONFIG->dbprefix:$prefix;
  $query = "SELECT count(*) as total FROM {$prefix}weblog_comments";
  $total = get_data_row($query);
  if(!empty($total)){
    return $total->total;
  }
  return 0;
}

function comments_load_items($offset=0,$limit=100,$prefix=""){
  global $CONFIG,$weblog_extensions;
  $query = "SELECT * FROM {$prefix}weblog_comments ";
  $query.= "ORDER BY ident asc";
  if($limit){
    $query.=" LIMIT $offset,$limit";
  }
  $items = get_data($query,"entity_row_to_elgg_user");
  return $items;
}

function comments_save_items($items,$prefix=""){
  global $CONFIG;
  $prefix = (empty($prefix))?$CONFIG->dbprefix:$prefix;
  $count = 0;
  if(is_array($items)){
    foreach($items as $entity){
      $comment_owner = users_legacy_owner($entity->owner,$prefix);
      if(!empty($comment_owner)){
        $comment_owner = users_get_entity($comment_owner->username);
      }
      $object = legacy_blog_object($entity->post_id,$prefix);
      if(!empty($object)){
        $object = search_for_object(utf8_encode($object->title),1);
        if(!empty($object)){
          $object = $object[0];
        }
      }

      if(($object instanceof ElggEntity) && ($comment_owner instanceof ElggEntity)){
        try{
          $object->annotate("generic_comment",utf8_encode($entity->body),ACCESS_PUBLIC,$comment_owner->getGUID());
          update_annotation_entity_time_created($object->getGUID(),$comment_owner->getGUID(),"generic_comment", $entity->posted);
          $count++;
        }
        catch(Exception $e){
          error_log("\t\tError creating the annotation (comments) between {$object->title} and {$comment_owner->name}");
          error_log($e->getMessage());
          error_log($e->getTraceAsString());
        }
      }
      else{
        error_log("\t\tError: Couldn't find wall owner[{$entity->post_id}]  or comment owner [{$entity->owner}]");
      }
    }
  }
  return $count;
}
?>