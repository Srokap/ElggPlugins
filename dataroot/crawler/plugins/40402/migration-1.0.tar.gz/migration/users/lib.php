<?php
/**
 * Elgg 0.9 to Elgg 1.0 Users functions
 *
 * @author Juan Carlos Lucero
 * @copyright Corporación Somos más - 2008
 */

/**
 * Check if the need elgg classic (0.9) tables are available in the same install;
 * @param $prefix DB tables prefix
 * @return boolean
 */
function users_check_tables($prefix=""){
  global $CONFIG;
  $prefix = (empty($prefix))?$CONFIG->dbprefix:$prefix;
  $query = "show tables like '{$prefix}users'";
  $resp = get_data($query);
  return !empty($resp);
}

/**
 * Return how many items are avaible for migrate
 *
 * @param string $prefix
 * @return integer
 */
function users_count_items($prefix=""){
  global $CONFIG;
  $prefix = (empty($prefix))?$CONFIG->dbprefix:$prefix;
  $query = "SELECT count(*) as total from {$prefix}users WHERE active='yes' AND user_type='person'";
  $total = get_data_row($query);
  if(!empty($total)){
    return $total->total;
  }
  return 0;
}

/**
 * Load Elgg 0.9 user objects from database
 *
 * @param int $offset
 * @param int $limit
 * @param string $prefix
 * @return mixed
 */
function users_load_items($offset=0,$limit=100,$prefix=""){
  global $CONFIG;
  $prefix = (empty($prefix))?$CONFIG->dbprefix:$prefix;
  $query = "SELECT * FROM {$prefix}users WHERE active='yes' AND user_type='person'";
  $query.= "ORDER BY ident asc";
  if($limit){
    $query.=" LIMIT $offset,$limit";
  }
  $users = get_data($query,"entity_row_to_elgg_user");
  return $users;
}

/**
 * Takes a array with Elgg 0.9 users and save it as Elgg 1.0 users
 *
 * @param mixed $items Array with Elgg 0.9 users
 * @param string $prefix
 * @return integer How many items were stored
 */
function users_save_items($items,$prefix=""){
  global $CONFIG;
  //@todo Need to migrate users_flags
  $prefix = (empty($prefix))?$CONFIG->dbprefix:$prefix;
  $user_data = array("biography"=>array("description","text"),
		   "minibio"=>array("briefdescription","text"),
		   "country"=>array("country","text"),
  		   "town"=>array("location","text"),
		   "interests"=>array("interests","tags"),
		   "homephone"=>array("phone","text"),
		   "mobphone"=>array("mobile","text"),
		   "personalweb"=>array("website","text"),
           "gender"=>array("gender","text"),
           "Birthday"=>array("birthday","text"),
           "profession"=>array("profession","text"));

  if(file_exists(dirname(__FILE__)."/config.php")){
    @require_once dirname(__FILE__)."/config.php";
  }

  $count = 0;
  if(is_array($items)){
    foreach( $items as $entity ){
      // Creating the user in ElggOne
      $username = utf8_encode($entity->username);
      $password = DEFAULT_PASSWORD;
      $name = utf8_encode($entity->name);
      $email = utf8_encode($entity->email);
      try{
        $guid = register_user($username, $password, $name, $email, true);
      }
      catch(Exception $e){
        if(!in_array($e->getMessage(),array(elgg_echo('registration:userexists'),elgg_echo('registration:dupeemail')))){
          error_log("Error creating $name,$username,$email");
          error_log($e->getMessage());
        }
      }

      if($guid){
        $user = get_entity($guid);
        $user->admin_created = true;
        $user->enable();

        $keys = array_keys($user_data);
        $keys = array_map(create_function("\$item","return \"'\$item'\";"),$keys);
        $keys = implode(",",$keys);

        $query_metadata = "SELECT name,value FROM {$prefix}profile_data WHERE owner={$entity->ident} AND name IN ($keys)";
        $metadata = get_data($query_metadata, "entity_row_to_elgg_user");

        if(is_array($metadata)){
          foreach($metadata as $metadata_entity){
            $newkey = $user_data[$metadata_entity->name][0];
            $type = $user_data[$metadata_entity->name][1];
            $new_value = utf8_encode($metadata_entity->value);
            switch($type){
              case "tags":
                $new_value = string_to_tag_array(utf8_encode($metadata_entity->value));
                break;
                //@todo Adds the proper manipulation function for each data type
            }
            $user->$newkey = $new_value;
          }
        }
        $count++;
      }
    }
  }
  return $count;
}
?>