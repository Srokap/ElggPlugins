<?php
/*

Dirty, ugly migration script for elgg 0.9 -> 1.X
* New data dir needs to be chmod'd after migration.
* River widget goes crazy.
* Must comment out exit from blog add action.

Set sections to be migrated in migrate_sections array


*/


echo '<pre>';
include 'engine/start.php';

ini_set('display_errors', true);
ini_set('error_reporting', E_ALL);
error_reporting(E_ALL);
set_time_limit(0);
ini_set('memory_limit', '1024M');
//ini_set('xdebug.max_nesting_level', 500);
//ini_set('xdebug.collect_params', '3');

$migrate_sections = array(
    'groups',
	'blogs',
	'files',
	'pictures',
    'profile_info',
    'profile_pic',
	'default_profile',
    'wall_comments',
    'relationships',
	'messages'
);

// set old (from) and new (to) data dirs.
$old_data_dir = '';
$new_data_dir = '';

// from and to database names.
// must be on the same db host.
$from_db = '';
$to_db = '';
$db_host = '';
$db_user = '';
$db_pass = '';

echo "\n\n\n\n";

$profile_fields = array(
    'aim' => 'text',
    'biography' => 'longtext',
    'careergoals' => 'text',
    'country' => 'text',
    'dislikes' => 'text',
    'educationlevel' => 'text',
    'emailaddress' => 'text',
    'goals' => 'text',
    'highschool' => 'text',
    //'homephone' => 'text',
    'icq' => 'text',
    'industry' => 'text',
    'interests' => 'text',
    //'jabber' => 'text',
    'jobdescription' => 'text',
    'jobtitle' => 'text',
    'likes' => 'text',
    'minibio' => 'text',
    //'mobphone' => 'text',
    'msn' => 'text',
    'occupation' => 'text',
    'organisation' => 'text',
    'personalweb' => 'text',
    //'postcode' => 'text',
    //'profilephoto' => 'text',
    'skills' => 'text',
    //'skype' => 'text',
    'state' => 'text',
//    'streetaddress' => 'text',
    'town' => 'text',
    'university' => 'text',
    'universitydegree' => 'text',
    //'workphone' => 'text',
    //'workweb' => 'url'
);

foreach ($profile_fields as $field=>$type) {
    $label = ucwords($field);
    //$type = sanitise_string(get_input('type'));
    $type = $type;

    if (($label) && ($type))
    {
        $n = 0;
        while (get_plugin_setting("admin_defined_profile_$n", 'profile')) {$n++;} // find free space

        if ( (set_plugin_setting("admin_defined_profile_$n", $label, 'profile')) &&
            (set_plugin_setting("admin_defined_profile_type_$n", $type, 'profile'))) {
                print "INSERTING $label as $type\n";
        }
    }
}

// grab some metadata that we need
$req_metadata = array (
    'notification:method:email',
    '1',
    'admin',
    'messageboard',
);

$req_metadata = array_merge($req_metadata, array_keys($profile_fields));

$metastrings = array();
foreach ($req_metadata as $string) {
    $sql = "SELECT `id` FROM `{$CONFIG->dbprefix}metastrings`
        WHERE `string` = '$string'";
    $temp_str = mysql_fetch_assoc(mysql_query($sql));
    $metastrings[$string] = $temp_str['id'];
}

// new metadata to insert
$sql = "INSERT INTO `{$CONFIG->dbprefix}metastrings`
    (`string`) VALUES ('guardian')";
mysql_query($sql);
$metastrings['guardian'] = mysql_insert_id();

$sql = "INSERT INTO `{$CONFIG->dbprefix}metastrings`
    (`string`) VALUES ('ward')";
mysql_query($sql);
$metastrings['ward'] = mysql_insert_id();

/**
 *
 * START MIGRATION
 *
 */



// we need to know which

mysql_select_db($from_db);

// migrate users.
$sql = 'SELECT * FROM `elggusers`
    WHERE `user_type` = \'community\'';
$r = mysql_query($sql);
$group_list = array();
while ($row = mysql_fetch_assoc($r)) {
    $group_list[] = $row['username'];
}





// grab the proper db connection.
$from_db_con = mysql_connect($db_host, $db_user, $db_pass);
mysql_select_db($from_db, $from_db_con);

// migrate users.
$sql = 'SELECT * FROM `elggusers`
    WHERE `user_type` = \'person\'';
$r = mysql_query($sql, $from_db_con);
print mysql_error();

// set up the conversion index for old_id to new_id
$user_ids = array();
// some of the usernames were duplicated in FF.  This shouldn't happen.
$changed_usernames = array();
$count = 0;
while ($row = mysql_fetch_assoc($r)) {
    print "Looking at {$row['ident']}\n";

    // grab old flags.
    $sql = "SELECT * FROM `elgguser_flags` WHERE `user_id` = '{$row['ident']}'";
    $metadata = array();
    $r_tmp = mysql_query($sql, $from_db_con);
    while($md_row = mysql_fetch_assoc($r_tmp)) {
        $metadata[$md_row['flag']] = $md_row['value'];
    }

    mysql_select_db($to_db);

    // need to check if we have a duplicate username since that was OK in elgg 0.9
    $sql = "SELECT * FROM `{$CONFIG->dbprefix}users_entity`
        WHERE `username` = '{$row['username']}'";
    $r_tmp = mysql_query($sql);

    if (mysql_num_rows($r_tmp) > 0) {
        print "Duplicate entry for {$row['ident']}, username {$row['username']}\n";

        // get another username...
        $i = 1;
        $username = $row['username'] . $i;
        $sql = "SELECT * FROM `{$CONFIG->dbprefix}users_entity`
            WHERE `username` = '$username'";
        $username_r = mysql_query($sql);

        while (mysql_num_rows($username_r)>0) {
            $i++;
            $username = $row['username'] . $i;
            $sql = "SELECT * FROM `{$CONFIG->dbprefix}users_entity`
                WHERE `username` = '$username'";
            $username_r = mysql_query($sql);
        }

        print "Renaming to $username\n";
        $row['username'] = $username;
    }
    
    $new_user = new ElggUser();
    $new_user->type = 'user';
    $new_user->name = $row['name'];
    $new_user->username = $row['username'];
    $new_user->password = $row['password'];
    $new_user->email = $row['email'];
    $new_user->code = $row['code'];
    $new_user->active = $row['active'];
    $new_user->ownerguid = 0;
    $new_user->site_guid = 1;
    $new_user->container_guid = 0;
    $new_user->access_id = 2;
    //$new_user->old_user_id = $row['ident'];

    if (!$new_user->save()) {
        print "Error migrating old user {$row['ident']} to {$new_user->guid}.  Any errors reported below.\n";
        print 'Errors: ' . mysql_error() . "\n";
        print "####\n";
        continue;
    }
    $sql = "DELETE FROM `{$CONFIG->dbprefix}metadata`
        WHERE `entity_guid` = '{$new_user->guid}'";
    mysql_query($sql);
        
   	create_metadata($new_user->getGUID(), 'old_user_id', $row['ident'], 'integer', -1, 2);
   	
    $sql = "INSERT into {$CONFIG->dbprefix}metadata
        (entity_guid, name_id, value_id, value_type, owner_guid, time_created, access_id) VALUES
        ('{$new_user->guid}', '{$metastrings['notification:method:email']}', '{$metastrings['1']}', 'text', '0', '" . time() . "', '2')";
    mysql_query($sql);

    if (isset($metadata['admin']) && $metadata['admin'] == 1) {
        $sql = "INSERT into {$CONFIG->dbprefix}metadata
            (entity_guid, name_id, value_id, value_type, owner_guid, time_created, access_id) VALUES
            ('{$new_user->guid}', '{$metastrings['admin']}', '{$metastrings['1']}', 'text', '0', '" . time() . "', '2')";
        mysql_query($sql);
    }

    print "Migrated old user {$row['ident']} to {$new_user->guid}.  Any errors reported below.\n";
    print 'Errors: ' . mysql_error() . "\n";
    print "####\n";

    set_user_validation_status($new_user->guid, true, 'import');
    mysql_select_db($from_db);

    $user_ids[$row['ident']] = $new_user->guid;
    
//    if ($count > 50) {
//    	break;
//    }
    $count++;
}
print "End Migrate users\n";


if (in_array('default_profile', $migrate_sections)) {
	$profile_handler = array('status','messageboard', 'friends', 'river_widget_friends');
	$profile_column = array('1', '2', '3', '3');

	print "Start default profiles\n";
	foreach ($user_ids as $old => $user_guid) {
		mysql_select_db($to_db);
		
		if (!login(get_user($user_guid))) {
			continue;
		}
		//add profile widgets if any
		if (count($profile_handler) > 0) {
			foreach($profile_handler as $k => $widget_handler){
				//$profile_result = add_widget($user_guid, $widget, 'profile', ($k+1), $profile_column[$k]);
				
				$widget = new ElggWidget;
				$widget->owner_guid = $user_guid;
				$widget->access_id = 1;
				if (!$widget->save())
					print "Erroring saving default widget $widget_handler for $user_guid\n";
					
				$widget->handler = $widget_handler;
				$widget->context = 'profile';
				$widget->column = $profile_column[$k];
				$widget->order = ($k+1);
			}
		}

		// grab all the video etc widgets and make new anytext widgets
		mysql_select_db($from_db);
		print "Looking for widgets to migrate for $user_guid\n";
		$sql = "SELECT * FROM `elggwidgets` 
        	WHERE owner='{$old}'
        	AND (`type` = 'contenttoolbar::video' OR `type` = 'widget::text')";
        $widgets = mysql_query($sql);
        print mysql_error();
        while ($widget_row = mysql_fetch_assoc($widgets)) {
        	$body = null;
        	$title = null;
        	if ($widget_row['type'] == 'contenttollbar::video') {
        		
        		$body_sql = "SELECT * FROM `elggwidget_data` 
        			WHERE `widget` = {$widget_row['ident']} 
        			AND `name` = 'video_url'";
        		
        		mysql_select_db($from_db);
                $body_r = mysql_query($body_sql);
        		$body_row = mysql_fetch_assoc($body_r);
        		$body = $body_row['value'];
        		
        		$title = 'Video';
        		
        	} elseif ($widget_row['type'] == 'widget::text') {
        		$body_sql = "SELECT * FROM `elggwidget_data` 
        			WHERE `widget` = {$widget_row['ident']} 
        			AND `name` = 'widget_text_body'";
        		mysql_select_db($from_db);
        		$body_r = mysql_query($body_sql);
        		$body_row = mysql_fetch_assoc($body_r);
        		$body = $body_row['value'];

                $title_sql = "SELECT * FROM `elggwidget_data` 
        			WHERE `widget` = {$widget_row['ident']} 
        			AND `name` = 'widget_text_title'";
                mysql_select_db($from_db);
        		$title_r = mysql_query($title_sql);
        		$title_row = mysql_fetch_assoc($title_r);
        		$title = $title_row['value'];
        	}
        	
        	if (!$title || !$body) {
        		continue;
        	}
        	
        	mysql_select_db($to_db);
        	
       		if (!login(get_user($user_guid))) {
       			print "error logging in $user_guid\n";
				continue;
			}
			
			print "Migrating widget: {$widget_row['ident']}\n";
        	
        	// add a new any text widget
        	$widget = new ElggWidget;
			$widget->owner_guid = $user_guid;
			$widget->access_id = 1;
			$widget->title = $title;
			$widget->description = $body;
			
			if (!$widget->save())
				print "Erroring saving anytext widget $user_guid\n";
			
			$widget->handler = 'anytext';
			$widget->context = 'profile';
			$widget->column = 2;
			$widget->order = 0;
			
			print_r($widget);
        }
        
        print "Default profile completed for $user_guid\n";
	}
}
mysql_select_db($from_db);

print "Finish default profiles.\n";

// add friends relationships
if (in_array('relationships', $migrate_sections)) {
	print "Start relationship migrate\n";
	
    mysql_select_db($from_db);
    foreach ($user_ids as $old_id => $new_id) {

        // get friends
        $sql = "SELECT * from `elggfriends`
            WHERE `owner` = '$old_id'";
        $r = mysql_query($sql);

        while ($row = mysql_fetch_assoc($r)) {
            mysql_select_db($to_db);

            $sql = "INSERT INTO {$CONFIG->dbprefix}entity_relationships
                (`guid_one`, `relationship`, `guid_two`) VALUES
                ('$new_id', 'friend', '{$user_ids[$row['friend']]}')";
            mysql_query($sql);
            print "Friending {$user_ids[$row['friend']]} to $new_id\n";
            print mysql_error();

            mysql_select_db($from_db);
        }
    }

    print "Finish relationship migrate\n";
}

if (in_array('profile_info', $migrate_sections)) {
	print "Start profile info migrate.\n";
    // get profile field values ids
    mysql_select_db($to_db);
    $sql = "SELECT * FROM {$CONFIG->dbprefix}private_settings
        WHERE `name` LIKE 'admin_defined_profile_%' AND
        `name` NOT LIKE 'admin_defined_profile_type_%'";
    $r = mysql_query($sql);

    $profile_map = array();
    while ($row = mysql_fetch_assoc($r)) {
    	$profile_map[$row['value']] = $row['name'];
    }

    // migrate profile information
    mysql_select_db($from_db);
    $sql = 'SELECT * FROM `elggprofile_data`';
    $r = mysql_query($sql);
    while ($row = mysql_fetch_assoc($r)) {

        //	print "Migrating user info {$profile_map[ucwords($row['name'])]}={$row['value']} for {$row['owner']}: {$user_ids[$row['owner']]}\n";

        if ($row['name'] != 'biography') {
        	$value = strip_tags($row['value']);
        } else {
        	$value = $row['value'];
        }
        
        mysql_select_db($to_db);
        
        if (!create_metadata($user_ids[$row['owner']], $profile_map[ucwords($row['name'])],
            $value, 'text', $user_ids[$row['owner']], 1, true)) {
                print "Error migrating some profile data for new_user: {$user_ids[$row['owner']]}\n";
            }

        // pic migration
        if (in_array('profile_pic', $migrate_sections) && $row['name'] == 'profilephoto' && is_file($old_data_dir .  $row['value'])) {
            $user = new ElggUser($user_ids[$row['owner']]);

            // if the user didn't get imported because it was a group or so, continue.
            if (!$user->username) {
                print "continuing for weird error...\n";
                continue;
            }

            // fake a POST'd file to get the uploaded image.
            $_FILES['profileicon'] = array(
                'error' => 0,
                'tmp_name' => $old_data_dir .  $row['value']
            );

            print "Migrating profile pic $old_data_dir" .  $row['value'] . "for newid: {$user_ids[$row['owner']]}\n";
            login($user);
            include 'mod/profile/actions/iconupload.php';
            mysql_select_db($from_db);
        }
    }
    print "Finish profile info migrate\n";
}



// migrate wall comments
if (in_array('wall_comments', $migrate_sections)) {
    print "Migrating wall comments...\n";
    mysql_select_db($from_db);
    $sql = 'SELECT * FROM `elggcommentwall`';
    $r = mysql_query($sql);
    print mysql_error();
    while ($row = mysql_fetch_assoc($r)) {
        mysql_select_db($to_db);

        $sql = "INSERT INTO `{$CONFIG->dbprefix}metastrings`
            (`string`) VALUES ('" . mysql_real_escape_string($row['content']) . "')";
        mysql_query($sql);
        $metastring_id = mysql_insert_id();

        $sql = "INSERT INTO `{$CONFIG->dbprefix}annotations`
            (`entity_guid`, `name_id`,
                `value_id`, `value_type`,
                `owner_guid`, `access_id`,
                `time_created`
            ) VALUES
            ('{$user_ids[$row['wallowner']]}', '{$metastrings['messageboard']}',
                '$metastring_id', 'text',
                '{$user_ids[$row['comment_owner']]}', '" . str_to_access($row['access']) . "',
                '{$row['posted']}'
            )";

        mysql_query($sql);
        mysql_select_db($from_db);
    }
}


// migrate comments
if (in_array('messages', $migrate_sections)) {
	mysql_select_db($from_db);
	$sql = 'SELECT * FROM `elggmessages` WHERE `from_id` > 0';
	$r = mysql_query($sql);
	
	while($row = mysql_fetch_assoc($r)) {
		mysql_select_db($to_db);
		print "Migrating message # {$row['ident']}\n";
		
		$user = get_entity($user_ids[$row['from_id']]);
		$read = ($row['status'] == 'read') ? 1 : 0;
        
		$message = new ElggObject();
		$message->subtype = "messages";
		$message->owner_guid = $user->getGUID();
		$message->access_id = 2;
		$message->title = $row['title'];
		$message->description = $row['body'];
		//$message->time_created = $row['posted'];
		
		$message->toId = $user_ids[$row['to_id']]; // the user receiving the message
		$message->readYet = $read; // this is a toggle between 0 / 1 (1 = read)
		$message->hiddenFrom = $row['hidden_from']; // this is used when a user deletes a message in their sentbox, it is a flag
		$message->hiddenTo = $row['hidden_to']; // this is used when a user deletes a message in their inbox

		if ($guid = !$message->save()) {
			print "Problem migrating message!\n";
		}
		
		$sql = "UPDATE `{$CONFIG->dbprefix}entities` SET 
			`time_created` = '{$row['posted']}',
			`time_updated` = '{$row['posted']}'
			WHERE `guid` = {$message->getGUID()}";
		
		mysql_query($sql);
		print mysql_error();
		
		mysql_select_db($from_db);
	}
}

//$user = new ElggUser();
//$log_user_in = login($object);


if (in_array('groups', $migrate_sections)) {
    // migrate groups
    mysql_select_db($from_db);
    $sql = 'SELECT * FROM `elggusers`
        WHERE `user_type` = \'community\'';
    $r = mysql_query($sql);
    print mysql_error();
    while ($row = mysql_fetch_assoc($r)) {
        print "Migrating group {$row['username']}\n";
        // need to check for potential data in the profile field.
        $_REQUEST = array(
            'user_guid' => $user_ids[$row['owner']],
            'name' => $row['username'],
            'briefdescription' => '',
            'description' => '',
            'interests' => '',
            'website' => '',
            'membership' => 0,
            'access_id' => 1,
            //'briefdescription' => $row['name']
        );
        $_FILES = array();

        $in_str = "'biography', 'dislikes', 'goals', 'interests', 'likes', 'minibio', 'profilephoto', 'skills'";
        $sql = "SELECT * FROM `elggprofile_data`
            WHERE `owner` = '{$row['ident']}'
            AND `name` IN ($in_str)";
        $tmp_r = mysql_query($sql);
        while ($prof_data = mysql_fetch_assoc($tmp_r)) {
            switch($prof_data['name']) {
                case 'profilephoto':
                    $icon = $old_data_dir . $prof_data['value'];
                    if (is_file($icon)) {
                        print "Setting icon for group...<br>";
                        $_FILES['icon'] = array(
                            'type' => 'image/jpeg',
                            'error' => 0,
                            'tmp_name' => $icon
                        );
                    }
                    break;
                case 'biography':
                    $_REQUEST['description'] = $prof_data['value'];
                    break;
                case 'dislikes':
                    //$_REQUEST['description'] = $prof_data['value'];
                    break;
                case 'goals':
                    //$_REQUEST['description'] = $prof_data['value'];
                    break;
                case 'interests':
                    $_REQUEST['interests'] = $prof_data['value'];
                    break;
                case 'likes':
                    //$_REQUEST['description'] = $prof_data['value'];
                    break;
                case 'minibio':
                    $_REQUEST['briefdescription'] = $prof_data['value'];
                    break;
                case 'skills':
                    //$_REQUEST['description'] = $prof_data['value'];
                    break;
            }
        }

        mysql_select_db($to_db);
        $user = new ElggUser($user_ids[$row['owner']]);

        login($user);
        include 'mod/groups/actions/edit.php';
        
        mysql_select_db($from_db);

        $sql = 'SELECT * FROM `elggfriends` WHERE `friend` = ' . $row['ident'];
        $member_r = mysql_query($sql, $from_db_con);
        while ($member_row = mysql_fetch_assoc($member_r)) {

            // don't add the owner of the group...
            // this is handled in creation.
            if ($member_row['owner'] == $row['owner']) {
                continue;
            }

            $user_id = $user_ids[$member_row['owner']];

            mysql_select_db($to_db);
            $user = get_entity($user_id);
            if ($user->username) {
                print "Adding {$user->username} to group {$group->name}\n";
                $group->join($user);
            }
            mysql_select_db($from_db);
        }
        mysql_select_db($from_db);
    }
}


// migrate blog
if (in_array('blogs', $migrate_sections)) {
	print "Adding blogs...\n";
	
	mysql_select_db($from_db);
	$sql = "SELECT * FROM `elggweblog_posts`";
	$r = mysql_query($sql);
	
	
	if (mysql_error()) {
		print mysql_error();
	}
	
	while($row = mysql_fetch_assoc($r)) {
		mysql_select_db($to_db);
        
        $tagarray = string_to_tag_array($row['title']);
        
        if (!login(get_entity($user_ids[$row['owner']]))) {
        	print "Error loggin in user!";
        	continue;
        }
        
		// Initialise a new ElggObject
		$blog = new ElggObject();
		$blog->subtype = "blog";
		$blog->owner_guid = $user_ids[$row['owner']];
		$blog->title = $row['title'];
		$blog->description = $row['body'];
		$blog->access_id = str_to_access($row['access']);
		print_r($blog);
		if (!$blog->save()) {
			print "Error saving blog {$row['title']}\n";
		}
		if (is_array($tagarray)) {
			$blog->tags = $tagarray;
		}
		
		
		$sql = "UPDATE `{$CONFIG->dbprefix}entities` SET 
		`time_created` = '{$row['posted']}',
		`time_updated` = '{$row['posted']}'
		WHERE `guid` = {$blog->guid}";
		mysql_query($sql);
		
		
		mysql_select_db($from_db);
		$sql = "SELECT * FROM `elggweblog_comments` WHERE `post_id` = '{$row['ident']}' AND `owner` > '0'";
		$comments_r = mysql_query($sql);
		
		while ($comment = mysql_fetch_assoc($comments_r)) {
			mysql_select_db($to_db);
			$access_id = str_to_access($comment['access']);
			$name = 'generic_comment';
			$value_type = detect_extender_valuetype($comment['body']);
			$owner_guid = $user_ids[$comment['owner']];
			//@todo do we really want to do this?
			if (!$owner_guid) {
				$owner_guid = -1;
			}
			
			$time = $comment['posted'];
			
			// Add the metastring
			$value = add_metastring($comment['body']);
			$name = add_metastring($name);

			// If ok then add it
			$sql = "INSERT into {$CONFIG->dbprefix}annotations 
				(entity_guid, name_id, value_id, value_type, owner_guid, time_created, access_id) VALUES 
				({$blog->guid},'$name',$value,'$value_type', $owner_guid, $time, $access_id)";
			
			if (!mysql_query($sql)) {
				print "Error inserting comment {$comment['ident']}\n";
				print mysql_error() . "\n";
				print "$sql\n";
			}
			mysql_select_db($from_db);
		}
		
        mysql_select_db($from_db);
	}
}


if (in_array('files', $migrate_sections)) {
	print "Migrate files\n";
	
	mysql_select_db($from_db);
	$sql = "SELECT *
		FROM `elggfiles`
		WHERE `originalname` NOT LIKE '%jpg%'
		AND `originalname` NOT LIKE '%jpeg%'
		AND `originalname` NOT LIKE '%gif%'
		AND `originalname` NOT LIKE '%bmp%'
		AND `originalname` NOT LIKE '%png%'
		ORDER BY `owner`
		";
	$r = mysql_query($sql);
	
	if (mysql_error()) {
		print "Error: $sql\n";
		print mysql_error();
	}
	
	$folder_ids = array();
	$count = 0;
	while($row = mysql_fetch_assoc($r)) {
		mysql_select_db($to_db);
		if (!login(get_entity($user_ids[$row['owner']]))) {
			print "Could not login user {$row['owner']} for file {$row['ident']}\n";
			continue;
		}
		
		set_input("title", $row['title']);
		set_input("description", $row['description']);
		//set_input("tags");
		set_input("access_id", str_to_access($name_row['access']));
		
		$_FILES['upload'] = array(
			'name'	=> $row['originalname'],
			'type' => 'application/octet-stream',
			'error' => 0,
			'tmp_name' => $old_data_dir . $row['location']
		);
		
		print_r($_FILES);
		
		include('mod/file/actions/upload.php');
		
		mysql_select_db($from_db);
	}
	print "End migrate files\n";
}



if (in_array('pictures', $migrate_sections)) {
	print "Migrate pictures\n";
	
	mysql_select_db($from_db);
	$sql = "SELECT *
		FROM `elggfiles`
		WHERE `originalname` LIKE '%jpg%'
		OR `originalname` LIKE '%jpeg%'
		OR `originalname` LIKE '%gif%'
		OR `originalname` LIKE '%bmp%'
		OR `originalname` LIKE '%png%'
		ORDER BY `owner`
		";
	$r = mysql_query($sql);
	
	if (mysql_error()) {
		print "Error: $sql\n";
		print mysql_error();
	}
	
	$folders = array();
	$count = 0;
	while($row = mysql_fetch_assoc($r)) {
//		
//		if ($count==5) {
//			print_r($folder_ids);
//			exit;
//		}
		
		$count++;
		
		
		/*
		
		$folders[old_id][folder_name] = new_folder_id
		
		if the id for the folder is -1, goes to Old FuseFly Pictures.
		else do a query to get the name.
		
		if the name of the folder is __photostream__ it goes into Old FuseFly Pictures

		*/
		
		if ($row['folder'] == '-1') {
			$folder_name = 'Old FuseFly Pictures';
		} else {
			$sql = "SELECT * FROM `elggfile_folders` WHERE `ident` = {$row['folder']}";
			$folder_r = mysql_query($sql);
			$folder_row = mysql_fetch_assoc($folder_r);
			if (!$folder_row['name'] || $folder_row['name'] == '__photostream__') {
				$folder_name = 'Old Pictures';
			}
		}
		
		mysql_select_db($to_db);
        $user = new ElggUser($user_ids[$row['owner']]);
        login($user);
		
		if (!$folder_guid = $folders[$row['owner']][$folder_name]) {
	        $album = new ElggObject();
			$album->subtype = "album";
			$album->owner_guid = $user->getGUID();
			$album->access_id = str_to_access($row['access']);	// grabs the file's access id.
			$album->title = $folder_name;
			//print_r($album);
			if (!$album->save()) {
				print "Could not create album $folder_name.\n";
			} else {
				print "Created album '$folder_name' : {$album->getGUID()} for {$row['folder']}.\n";
			}
			
			$folders[$row['owner']][$folder_name] = $album->getGUID();
			$folder_guid = $album->getGUID();
		}
		
		$image = $old_data_dir . $row['location'];
		
		$_REQUEST = array(
			'title' => $row['title'],
			'description' => $row['description'],
			'tags' => $row['title'],
			'access_id' => str_to_access($row['access']),
			'container_guid' => $folder_guid,
		);
		
		$_FILES[0] = array(
			'name'	=> $row['originalname'],
			'type' => 'image/jpeg',
			'error' => 0,
			'tmp_name' => $image
		);
		
		include('mod/tidypics/actions/upload.php');
		
		$image = get_entity($file->getGUID());
		$image->description = $row['description'];
		$image->save();
		//print_r($image);
		
		mysql_select_db($from_db);
		$sql = "SELECT * FROM `elggcomments`
		 WHERE `object_type` = 'file::file' 
		 AND `object_id` = '{$row['ident']}'
		 AND `owner` > 0";
		$comments_r = mysql_query($sql);
		print mysql_error();
		while ($comment = mysql_fetch_assoc($comments_r)) {
			print "Migrating comment id {$comment['ident']} for old photo id {$row['ident']}\n";
			mysql_select_db($to_db);
			$access_id = 1;
			$name = 'generic_comment';
			$value_type = detect_extender_valuetype($comment['body']);
			if (!$owner_guid = $user_ids[$comment['owner']]) {
				continue;
			}
			
			$time = $comment['posted'];
			
			// Add the metastring
			$value = add_metastring($comment['body']);
			$name = add_metastring($name);

			// If ok then add it
			$sql = "INSERT into {$CONFIG->dbprefix}annotations 
				(entity_guid, name_id, value_id, value_type, owner_guid, time_created, access_id) VALUES 
				({$user->getGUID()},'$name',$value,'$value_type', $owner_guid, $time, $access_id)";
			
			if (!mysql_query($sql)) {
				print "Error inserting comment {$comment['ident']}\n";
				print mysql_error() . "\n";
				print "$sql\n";
			}
			mysql_select_db($from_db);
		}	
	}
	
	mysql_select_db($from_db);
}


print "DONE";

echo '</pre>';









function str_to_access($str) {
	switch ($str) {
		case 'PRIVATE':
			return 0;
		
		default: 
		case 'LOGGED_IN':
			return 1;
			
		case 'PUBLIC':
			return 2;
			
	}
}
