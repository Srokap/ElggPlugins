<?php
/**
 *	RATY RATE PLUGIN
 *	@package raty
 *	@author Adam Endvy
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Adam Endvy 2011
 *	@link http://www.codegero.com
 **/

	$english = array(
		'raty:rates' => "Rates",
		'raty:rateit' => "Rate it",
		'raty:text' => "Do you like it?",
		'raty:rated' => "You have ratyd it before.",
		'raty:badguid' => "Error, we haven't found any item to raty.",
		'raty:badrate' => "Rate must be from 0 to 5.",
		'raty:saved' => "Your raty has been saved.",
		'raty:error' => "Your raty could not be saved. Please try again.",
	);
	add_translation("en",$english);
?>