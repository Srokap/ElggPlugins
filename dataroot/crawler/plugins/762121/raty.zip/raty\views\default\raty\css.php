<?php
/**
 *	RATY RATE PLUGIN
 *	@package raty
 *	@author Adam Endvy
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Adam Endvy 2011
 *	@link http://www.codegero.com
 **/
?>

.submit_button:hover, input[type="submit"]:hover {
    background: #0054A7;
    border-color: #0054A7;
}

.submit_button:hover, input[type="submit"]:hover {
    background: #0054A7;
    border-color: #0054A7;
}

input[type="submit"]#raty_button {
    font: 10px/100% Arial, Helvetica, sans-serif;
    font-weight: bold;
    color: white;
    background: #4690D6;
    border: 1px solid #4690D6;
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    width: auto;
    height: 20px;
    padding: 2px 6px 2px 6px;
    margin: 0;
    cursor: pointer;
}