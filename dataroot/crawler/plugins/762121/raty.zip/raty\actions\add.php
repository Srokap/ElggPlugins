<?php
/**
 *	RATY RATE PLUGIN
 *	@package raty
 *	@author Adam Endvy
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Adam Endvy 2011
 *	@link http://www.codegero.com
 **/

//Make sure action is secure
	gatekeeper();
	action_gatekeeper();
	
//Get input data
	$guid = (int) get_input('guid');
	$raty = (int) get_input('raty');

//Make sure we actually have the entity
	if (!$entity = get_entity($guid)){
		register_error(elgg_echo('raty:badguid'));
		forward();
	}

// Make sure we have a correct rate
	if ($raty && ($raty >= 1 || $raty <= 6)){
		$raty; 
	}else{
		register_error(elgg_echo('raty:badrate'));
		forward($entity->getUrl());
	}

//We have rated before?	
	//if (count_annotations ($entity->guid, $entity->getType(), $entity->getSubtype(), 'generic_rate', "", "", $_SESSION['guid'])){
	if (!allow_raty($entity)){
		register_error(elgg_echo('raty:rated'));
		forward($entity->getUrl());
	}
	
//Let's go rate
	if ($entity->annotate('generic_rate', $raty, 2, $_SESSION['guid'])){
		system_message(elgg_echo('raty:saved'));
	}else{
		register_error(elgg_echo('raty:error'));
	}
	
	forward($entity->getUrl());
	

?>