<?php
/**
 *	RATY RATE PLUGIN
 *	@package raty
 *	@author Adam Endvy
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Adam Endvy 2011
 *	@link http://www.codegero.com
 **/

	// Get engine
		require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

		header("Content-type: text/javascript");
		header('Expires: ' . date('r',time() + 864000));
		header("Pragma: public");
		header("Cache-Control: public");
		echo elgg_view('raty/javascript');

?>