<?php
/**
 *	RATY RATE PLUGIN
 *	@package raty
 *	@author Adam Endvy
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Adam Endvy 2011
 *	@link http://www.codegero.com
 **/

//Start
function raty_init(){
	global $CONFIG;

	register_translations($CONFIG->pluginspath . "raty/languages/");
    elgg_extend_view('js/initialise_elgg','raty/javascript');
	extend_view('css', 'raty/css');
}

//Events
register_elgg_event_handler('init','system','raty_init');

// count_annotations dont works fine, it does anythig with the given owner_guid
// the we have a little function...
function allow_raty ($entity){
	if (isloggedin()){
		$annotations = $entity->getAnnotations('generic_rate');
		foreach ($annotations as $annotation){
			if ($annotation->owner_guid == $_SESSION['guid']){
				return false;
			}
		}
		return true;
	}else{
		return false;
	}
}

//Actions
register_action("raty/add",false,$CONFIG->pluginspath . "raty/actions/add.php");

?>