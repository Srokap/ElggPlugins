<?php
/**
 *	RATY RATE PLUGIN
 *	@package raty
 *	@author Adam Endvy
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Adam Endvy 2011
 *	@link http://www.codegero.com
 **/

    $raty = 0;
    
    // average of rate
    $raty += $vars['entity']->getAnnotationsAvg('generic_rate');
    
    //We show the form if the user is legged in and it hasn't raty yet
    gatekeeper();
    
    //if (!count_annotations($vars['entity']->guid, $vars['entity']->getType(), $vars['entity']->getSubtype(), 'generic_raty', "", "", $_SESSION['guid'])){
    if (allow_raty($vars['entity'])){
        ?>
        <script type="text/javascript">
			$(function() {
				$('#raty-<?php echo $vars['entity']->getGUID();?>').raty({
					cancel:		true,
					target:		'#rate-<?php echo $vars['entity']->getGUID();?>',
					targetKeep:	true,
					targetType:	'number',
                    half:  true,
        			start: <?php echo $raty ;?>,
				});

			});
		</script>
        <?php
        $form_body  = "<label>{$raty} -</label><span id=raty-{$vars['entity']->getGUID()}></span>";     
        $form_body .= " " . elgg_view('input/hidden', array('internalname' => 'raty', "internalid"=>"rate-{$vars['entity']->getGUID()}"));
    	$form_body .= elgg_view('input/hidden', array('internalname' => 'guid', 'value' => $vars['entity']->getGUID()));
    	$form_body .= elgg_view('input/submit', array('internalid'=>'raty_button', 'value' => elgg_echo("raty:rateit")));
    
    	echo elgg_view('input/form', array('body' => $form_body, 'action' => "{$vars['url']}action/raty/add"));	
    
    }else{
        ?>
        <script type="text/javascript">
        			$(function() {
        			 
        				$('#raty-<?php echo $vars['entity']->getGUID();?>').raty({
        					readOnly:	true,
                            half:  true,
        					start: <?php echo $raty ;?>
        				});
        
        });
        </script>
            <label><?php echo $raty;//echo elgg_echo("raty:text");?> -</label><span id="raty-<?php echo $vars['entity']->getGUID();?>"></span>
        <?php
        
    }

?>
