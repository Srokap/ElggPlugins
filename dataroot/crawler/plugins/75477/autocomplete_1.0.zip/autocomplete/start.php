<?php
/**
 *	AUTOCOMPLETE PLUGIN
 *	Autocomplete tags for ELGG, based on jquery autocomplete plugin
 *	Copyright (c) 2007 Dylan Verheul, Dan G. Switzer, Anjesh Tuladhar, Jörn Zaefferer
 *	http://bassistance.de/jquery-plugins/jquery-plugin-autocomplete/
 *	@package autocomplete
 *	@author Miguel Montes mmontesp@gmail.com
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Miguel Montes Porras 2009 
 *	@link http://mimopo.es
 **/

//Load config
global $CONFIG;

//plugin init
register_elgg_event_handler('init','system','autocomplete_init');



/**
 * Init function
 * @return void
 */
function autocomplete_init(){
	//Load config
	global $CONFIG;
	
	//Page handler
	register_page_handler('autocomplete','autocomplete_page_handler');
	
	//Extend metatags view in order to load js
	extend_view('metatags', 'autocomplete/metatags');
	
	//Extend css
	extend_view('css', 'autocomplete/jquery.autocomplete.css', 1000);
}



/**
 * Autocomplete Page Handler
 */
function autocomplete_page_handler($page){
	global $CONFIG;
	//set_input('metadata_name', $page[0]);
	@include($CONFIG->pluginspath."autocomplete/index.php");
}


 ?>