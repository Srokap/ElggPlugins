<?php
/**
 *	AUTOCOMPLETE PLUGIN
 *	Ajax end-point
 *
 *	Autocomplete tags for ELGG, based on jquery autocomplete plugin
 *	Copyright (c) 2007 Dylan Verheul, Dan G. Switzer, Anjesh Tuladhar, Jörn Zaefferer
 *	http://bassistance.de/jquery-plugins/jquery-plugin-autocomplete/
 *	@package autocomplete
 *	@author Miguel Montes mmontesp@gmail.com
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Miguel Montes Porras 2009 
 *	@link http://mimopo.es
 **/

// ELGG INIT
require_once(dirname(dirname(dirname(__FILE__))) . '/engine/start.php');
global $CONFIG;

//GET INPUT
$q = get_input('q');
	//$metadata_name = get_input('metadata_name');

//WE HAVE INPUT? GET DATA (CUSTOM CODE LIKE get_tags)
if ($q){
	
	//CONFIG
	$threshold = 1; // (must be int) return only tags with X repetitions
	$limit = 0; // (must be int, 0=no limit) return X tags maximum
	$entity_type = "object"; // (object, user, site) I want tags from objects
	$entity_subtype = ""; // I want tags from all subtypes
	$owner_guid = ""; // I want tags from all objects from all users
	$site_guid = -1; // I want tags only from the current site
	$metadata_name = 0; //0 all tags, if you wanna use only a specific metadata_name just put the string
	
	//If we have metadata convert it into metastring_id
	if ($metadata_name) {
		$metadata_name = (int) get_metastring_id($metadata_name);
	}
	
	//If we have entity_subtype convert it into subtype_id
	if ($entity_type && $entity_subtype){
		$entity_subtype = get_subtype_id($entity_type, $entity_subtype);
	}	
	
	//I little bit of security...
	$entity_type = sanitise_string($entity_type);
		
	//If we have owner_guid
	if ($owner_guid){
		if (is_array($owner_guid)) {
			foreach($owner_guid as $key => $val)
				$owner_guid[$key] = (int) $val;
		} else {
			$owner_guid = (int) $owner_guid;
		}
	}
	
	//If we have site_guid	
	if ($site_guid < 0) {
		$site_guid = $CONFIG->site_id;
	}
		
	//Query
	$query = "SELECT msvalue.string as tag, count(msvalue.id) as total ";
	$query .= "FROM {$CONFIG->dbprefix}entities e join {$CONFIG->dbprefix}metadata md on md.entity_guid = e.guid ";
	$query .= " join {$CONFIG->dbprefix}entity_subtypes subtype on subtype.id = e.subtype ";
	$query .= " join {$CONFIG->dbprefix}metastrings msvalue on msvalue.id = md.value_id ";
		
	$query .= " where msvalue.string != '' ";
		
	if ($metadata_name > 0) {
		$query .= " and md.name_id = {$metadata_name} ";
	}
	if ($site_guid > 0) {
		$query .= " and e.site_guid = {$site_guid} ";
	}
	if ($entity_subtype > 0) {
		$query .= " and e.subtype = {$entity_subtype} ";
	}
	if ($entity_type != "") {
		$query .= " and e.type = '{$entity_type}' ";
	}
	if (is_array($owner_guid)) {
		$query .= " and e.container_guid in (".implode(",",$owner_guid).")";
	} else if (is_int($owner_guid)) {
		$query .= " and e.container_guid = {$owner_guid} ";
	}
	$query .= ' and ' . get_access_sql_suffix("e"); //Get all tags even if yu can't see the entities
	$query .= " AND msvalue.string LIKE '%{$q}%' group by msvalue.string having total > {$threshold} order by tag desc";
	
	if ($limit){
		$query .= " limit {$limit}";
	}
	//Execute query
	$tags = get_data($query);
	
	//PRINT DATA
	foreach ($tags as $tag){
		echo "{$tag->tag}\n";
	}
}

?> 