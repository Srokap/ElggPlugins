<?php 
/**
 *	AUTOCOMPLETE PLUGIN
 *	Standard ELGG tag input modified
 *
 *	Autocomplete tags for ELGG, based on jquery autocomplete plugin
 *	Copyright (c) 2007 Dylan Verheul, Dan G. Switzer, Anjesh Tuladhar, Jörn Zaefferer
 *	http://bassistance.de/jquery-plugins/jquery-plugin-autocomplete/
 *	@package autocomplete
 *	@author Miguel Montes mmontesp@gmail.com
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Miguel Montes Porras 2009 
 *	@link http://mimopo.es
 **/

	$class = $vars['class'];
	if (!$class) $class = "input-tags";

    $tags = "";
    if (!empty($vars['value'])) {
    	if (is_array($vars['value'])) {
	        foreach($vars['value'] as $tag) {
	            
	            if (!empty($tags)) {
	                $tags .= ", ";
	            }
	            if (is_string($tag)) {
	            	$tags .= $tag;
	            } else {
	            	$tags .= $tag->value;
	            }
	            
	        }
    	} else {
    		$tags = $vars['value'];
    	}
    }
    
?>
<input type="text" <?php if ($vars['disabled']) echo ' disabled="yes" '; ?><?php echo $vars['js']; ?> name="<?php echo $vars['internalname']; ?>" value="<?php echo htmlentities($tags, ENT_QUOTES, 'UTF-8'); ?>" class="<?php echo $class; ?>"/> 