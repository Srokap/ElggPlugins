<?php
/**
 *	AUTOCOMPLETE PLUGIN
 *	Init autocomplete JS
 *	If you want modify the autocomplete options check the documentation at jquery.com
 *	http://docs.jquery.com/Plugins/Autocomplete
 *
 *	Autocomplete tags for ELGG, based on jquery autocomplete plugin
 *	Copyright (c) 2007 Dylan Verheul, Dan G. Switzer, Anjesh Tuladhar, Jörn Zaefferer
 *	http://bassistance.de/jquery-plugins/jquery-plugin-autocomplete/
 *	@package autocomplete
 *	@author Miguel Montes mmontesp@gmail.com
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Miguel Montes Porras 2009 
 *	@link http://mimopo.es
 **/
?>

 $(document).ready(function(){
 	$(".input-tags").autocomplete("<?php echo $vars['url'];?>pg/autocomplete", {
			cacheLength: 20,
			multiple: true
	});
 });
