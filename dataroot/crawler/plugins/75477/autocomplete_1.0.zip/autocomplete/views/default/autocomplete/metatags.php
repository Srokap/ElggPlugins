<?php
/**
 *	AUTOCOMPLETE PLUGIN
 *	Extends the site head in order to load autocomplete js and css
 *
 *	Autocomplete tags for ELGG, based on jquery autocomplete plugin
 *	Copyright (c) 2007 Dylan Verheul, Dan G. Switzer, Anjesh Tuladhar, Jörn Zaefferer
 *	http://bassistance.de/jquery-plugins/jquery-plugin-autocomplete/
 *	@package autocomplete
 *	@author Miguel Montes mmontesp@gmail.com
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Miguel Montes Porras 2009 
 *	@link http://mimopo.es
 **/
?>

<!-- AUTOCOMPLETE PLUGIN -->
<script type="text/javascript" src="<?php echo $CONFIG->wwwroot; ?>mod/autocomplete/jquery.autocomplete/jquery.autocomplete.pack.js"></script>
<script type="text/javascript" src="<?php echo $CONFIG->wwwroot; ?>pg/js/elgg.autocomplete.js"></script>
<!-- AUTOCOMPLETE PLUGIN -->
