<?php
/**
 *	AUTOCOMPLETE PLUGIN
 *	CSS Theme for jquery.autocomplete	
 *	If you are developing a theme for ELGG just override this view with your theme
 *
 *	Autocomplete tags for ELGG, based on jquery autocomplete plugin
 *	Copyright (c) 2007 Dylan Verheul, Dan G. Switzer, Anjesh Tuladhar, Jörn Zaefferer
 *	http://bassistance.de/jquery-plugins/jquery-plugin-autocomplete/
 *	@package autocomplete
 *	@author Miguel Montes mmontesp@gmail.com
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Miguel Montes Porras 2009 
 *	@link http://mimopo.es
 **/
?>

.ac_results {
	padding: 0px;
	border: 1px solid #4D94D7;
	background-color: white;
	overflow: hidden;
	z-index: 99999;
}

.ac_results ul {
	width: 100%;
	list-style-position: outside;
	list-style: none;
	padding: 0;
	margin: 0;
}

.ac_results li {
	margin: 0px;
	padding: 2px 5px;
	cursor: default;
	display: block;
	/* 
	if width will be 100% horizontal scrollbar will apear 
	when scroll mode will be used
	*/
	/*width: 100%;*/
	font: menu;
	font-size: 12px;
	/* 
	it is very important, if line-height not setted or setted 
	in relative units scroll will be broken in firefox
	*/
	line-height: 16px;
	overflow: hidden;
}

.ac_results li strong{
	font-weight: bolder;
}

/* the following !important marks must be used on ELGG*/
.ac_loading {
	background-image: url('<?php echo $vars['url'];?>_graphics/ajax_loader.gif') !important;
	background-repeat: no-repeat !important;
	background-position: right center !important;
}

.ac_odd {
	background-color: #DEDEDE;
}

.ac_over {
	background-color: #69A7E2;
	color: white;
}
