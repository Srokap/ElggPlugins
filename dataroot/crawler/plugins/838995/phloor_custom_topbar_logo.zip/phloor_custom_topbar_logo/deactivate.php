<?php

update_subtype('object', 'phloor_topbar_logo');
