<?php
/*****************************************************************************
 * Phloor Topbar Logo                                                        *
 *                                                                           *
 * Copyright (C) 2012 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php

$german = array(
	"phloor_custom_topbar_logo" => "phloorTopbarLogo",
	'admin:appearance:phloor_custom_topbar_logo' => 'Topbar Logo',

	'phloor_custom_topbar_logo:title' => "Topbar Logo Upload",

	'phloor_custom_topbar_logo:description' => "Hier können Sie Ihr eigenes Topbar Logo hochladen. Unterstütze Mimetypes sind 'image/gif', 'image/jpg', 'image/jpeg', 'image/pjpeg' und 'image/png'. ",

	'phloor_custom_topbar_logo:save:success' => 'Einstellungen erfolgreich gespeichert. ',
	'phloor_custom_topbar_logo:save:failure' => 'Einstellungen konnten nicht gespeichert werden. ',

	'phloor_custom_topbar_logo:form:section:topbar_logo' => 'Topbar Logo',

	'phloor_custom_topbar_logo:image:label' => 'Laden Sie Ihr Topbar Logo hoch',
	'phloor_custom_topbar_logo:image:description' => 'Wählen Sie die Datei die Sie als Topbar Logo einstellen wollen. Um in die Topbar der Seite zu passen, wählen Sie bitte eine geeignete Größe des Logos. ',

	'phloor_custom_topbar_logo:image_delete:label' => 'Topbar Logo entfernen',
	'phloor_custom_topbar_logo:image_delete:description' => 'Bei Aktivierung dieser Checkbox wird das momentane Topbar Logo entfernt. ',

);

add_translation("de", $german);
