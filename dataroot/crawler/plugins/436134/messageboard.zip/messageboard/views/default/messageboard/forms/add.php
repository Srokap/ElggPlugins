<?php
global $CONFIG;
echo '<script type="text/javascript" src="'.$CONFIG->url.'mod/messageboard/editor/ckeditor.js"></script>';
//add in the javascript code to fool the *hardcoded calls to tinyMCE...sigh 
?>
<script language="javascript" type="text/javascript">
var tinymce = {
		_init : function() {},
		triggerSave : function() {}
};

var tinyMCE = tinymce._init();


</script>
<div id="mb_input_wrapper">
<form action="<?php echo $vars['url']; ?>action/messageboard/add" method="post" name="messageboardForm">
   
    <!-- textarea for the contents -->
    
  <?php 

echo '<textarea name="message_content" value="" "></textarea>
			<script type="text/javascript">

		CKEDITOR.config.toolbar_Fullest=[[\'Source\',\'-\',\'Save\',\'Preview\'],[\'Cut\',\'Copy\',\'Paste\',\'Print\',\'SpellChecker\',\'Scayt\'],[\'Undo\',\'Redo\',\'-\',\'Find\',\'Replace\'],\'/\',[\'Bold\',\'Italic\',\'Underline\',\'Strike\'],[\'NumberedList\',\'BulletedList\'],[\'JustifyLeft\',\'JustifyCenter\',\'JustifyRight\',\'JustifyBlock\'],[\'Smiley\',\'SpecialChar\',\'PageBreak\'],\'/\',[\'Styles\',\'Format\',\'Font\',\'FontSize\'],[\'TextColor\',\'BGColor\',\'About\']];CKEDITOR.config.toolbar=\'Fullest\';
			
		var editor = CKEDITOR.replace( \'message_content\',  {
        toolbar : \'Fullest\',
        uiColor : \'#9AB8F3\',
        filebrowserUploadUrl : \''.$CONFIG->url.'action/CKEditor/upload\'
    } );
    
    </script>
';

?> 
    <!-- the person posting an item on the message board -->
    <input type="hidden" name="guid" value="<?php echo $_SESSION['guid']; ?>"  />
   
    <!-- the page owner, this will be the profile owner -->
    <input type="hidden" name="pageOwner" value="<?php echo page_owner(); ?>"  />
   
    <!-- submit messages input -->
    <input type="submit" id="postit" value="<?php echo elgg_echo('messageboard:postit'); ?>">
    
</form>
</div>