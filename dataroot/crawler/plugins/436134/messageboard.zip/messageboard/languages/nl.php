<?php

	$dutch = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messageboard:board' => "Reisberichten",
			'messageboard:messageboard' => "prikbord",
			'messageboard:viewall' => "Bekijk alle",
			'messageboard:postit' => "Post it",
			'messageboard:history' => "geschiedenis",
			'messageboard:none' => "hisThere is niets op dit bericht boord nog",
			'messageboard:num_display' => "Aantal berichten weer te geven",
			'messageboard:desc' => "Dit is een message board die je kunt plaatsen op je profiel waar andere gebruikers kunnen commentaar.",
	
			'messageboard:user' => "%s's prikbord",
	
			'messageboard:history' => "Geschiedenis",
			'messageboard:replyon' => 'antwoord op',
			
         /**
	     * Message board widget river
	     **/
	        
	        'messageboard:river:annotate' => "%s heeft een nieuw bericht geplaatst op hun message board.",
	        'messageboard:river:create' => "%s toegevoegd het prikbord widget.",
	        'messageboard:river:update' => "%s updated hun message board widget.",
	        'messageboard:river:added' => "%s gepost op",
		    'messageboard:river:messageboard' => "prikbord",

			
		/**
		 * Status messages
		 */
	
			'messageboard:posted' => "Je hebt met succes geplaatst op de message board.",
			'messageboard:deleted' => "Je hebt met succes verwijderd het bericht.",
	
		/**
		 * Email messages
		 */
	
			'messageboard:email:subject' => 'U hebt een nieuw bericht board commentaar!',
			'messageboard:email:body' => "U hebt een nieuw bericht board commentaar van %s.Het leest:

			
%s


Als u uw bericht boord opmerkingen, klik hier:

	%s

Om %s's profiel, klik hier:

	%s

U kunt niet reageren op deze e-mail.",
	
		/**
		 * Error messages
		 */
	
			'messageboard:blank' => "Sorry, u moet zetten om daadwerkelijk iets in het bericht gebied voordat we het kunnen redden.",
			'messageboard:notfound' => "Sorry, we niet kunnen vinden het opgegeven item.",
			'messageboard:notdeleted' => "Sorry, we niet konden verwijder dit bericht.",
			'messageboard:somethingwentwrong' => "Er is iets misgegaan bij het proberen om uw bericht op te slaan, zorg ervoor dat je eigenlijk schreef een bericht.",
	     
			'messageboard:failure' => "Er is een onverwachte fout opgetreden bij het toevoegen van uw bericht. Probeer opnieuw.",
	
	);
					
	add_translation("nl",$dutch);

?>