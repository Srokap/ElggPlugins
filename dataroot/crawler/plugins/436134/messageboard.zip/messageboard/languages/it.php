<?php

	$italian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messageboard:board' => "Asse di comunicazione",
			'messageboard:messageboard' => "Asse di comunicazione",
			'messageboard:viewall' => "Veda tutti",
			'messageboard:postit' => "L'affigga",
			'messageboard:history' => "storia",
			'messageboard:none' => "Non c'e ancora nulla a questo bordo di comunicazione",
			'messageboard:num_display' => "Numero di comunicazioni per esporre",
			'messageboard:desc' => "Questo e un asse di comunicazione che Lei puo porsi il Suo profilo dove gli altri utenti possono fare commenti.",
	
			'messageboard:user' => "%s's asse di comunicazione",
	
			'messageboard:history' => "Storia",
			'messageboard:replyon' => 'risponda su',
			
         /**
	     * Message board widget river
	     **/
	        
	        'messageboard:river:annotate' => "%s ha avuto un commento nuovo affisso sul loro asse di comunicazione.",
	        'messageboard:river:create' => "%s aggiunto il widget di asse di comunicazione.",
	        'messageboard:river:update' => "%s aggiornato il loro widget di asse di comunicazione.",
	        'messageboard:river:added' => "%s affisso su",
		    'messageboard:river:messageboard' => "asse di comunicazione",

			
		/**
		 * Status messages
		 */
	
			'messageboard:posted' => "Lei affisse con successo sull'asse di comunicazione.",
			'messageboard:deleted' => "Lei cancello con successo la comunicazione.",
	
		/**
		 * Email messages
		 */
	
			'messageboard:email:subject' => 'Lei ha un commento di asse di comunicazione nuovo!',
			'messageboard:email:body' => "Lei ha un commento di asse di comunicazione nuovo da %s. Legge:

			
%s


Vedere i Suoi commenti di asse di comunicazione, clicchi qui:

	%s

Vedere %s's profili, clicchi qui:
	%s

 Lei non puo rispondere a questo e-mail",
	
		/**
		 * Error messages
		 */
	
			'messageboard:blank' => "Spiacente; Lei ha bisogno di davvero mettere qualche cosa nell'area di comunicazione prima che noi possiamo salvarlo.",
			'messageboard:notfound' => "Spiacente; noi non potevamo trovare l'articolo specificato .",
			'messageboard:notdeleted' => "Spiacente; noi non potevamo cancellare questa comunicazione.",
			'messageboard:somethingwentwrong' => "Qualche cosa ando sbagliato quando tentando di salvare la Sua comunicazione, davvero si assicuri Lei scrisse una comunicazione.",
	     
			'messageboard:failure' => "Accadde un errore inaspettato quando aggiungendo la Sua comunicazione. Per favore tenti di nuovo.",
	
	);
					
	add_translation("it",$italian);

?>