<?php

	$german = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messageboard:board' => "Mitteilungsausschub",
			'messageboard:messageboard' => "Mitteilungsausschub",
			'messageboard:viewall' => "Sehen Sie alles an",
			'messageboard:postit' => "Schlagen Sie es an",
			'messageboard:history' => "die Geschichte",
			'messageboard:none' => "Es gibt noch nichts auf diesem Mitteilungsausschub",
			'messageboard:num_display' => "Anzahl von Mitteilungen zu Demonstration",
			'messageboard:desc' => "Dies ist ein Mitteilungsausschub, den Sie Ihr Profil anziehen konnen, wo sich andere Benutzer &auml;u&szlig;ern konnen.",
	
			'messageboard:user' => "%s's Mitteilungsausschub",
	
			'messageboard:history' => "Die Geschichte",
			'messageboard:replyon' => 'Antwort auf',
			
         /**
	     * Message board widget river
	     **/
	        
	        'messageboard:river:annotate' => "%s hat in ihrem Mitteilungsaufsichtsrat eine neue Anmerkung bekanntgeben gelassen.",
	        'messageboard:river:create' => "%s hinzugefugt der Mitteilungsausschub widget.",
	        'messageboard:river:update' => "%s aktualisiert ihr Mitteilungsausschub widget.",
	        'messageboard:river:added' => "%s angeschlagen auf",
		    'messageboard:river:messageboard' => "Mitteilungsausschub",

			
		/**
		 * Status messages
		 */
	
			'messageboard:posted' => "Sie schlugen erfolgreich im Mitteilungsaufsichtsrat an.",
			'messageboard:deleted' => "Sie loschten die Mitteilung erfolgreich.",
	
		/**
		 * Email messages
		 */
	
			'messageboard:email:subject' => 'Sie haben eine neue Mitteilungsausschub anmerkung!',
			'messageboard:email:body' => "Sie haben davon eine neue Mitteilungsausschub anmerkung %s. Es lautet:

			
%s


Ihren Mitteilungsausschub anzusehen, aubert sich, klicken Sie hier:

	%s

Zu Sicht %s's Profil klickt hier:

	%s

Sie konnen nicht zu dieser E-mail antworten.",
	
		/**
		 * Error messages
		 */
	
			'messageboard:blank' => "Traurig; Sie mussen eigentlich etwas ins Mitteilungsgebiet setzen, bevor wir es bewahren konnen.",
			'messageboard:notfound' => "Traurig; wir konnten das spezifizierte Stuck nicht finden.",
			'messageboard:notdeleted' => "Traurig; wir konnten diese Mitteilung nicht loschen.",
			'messageboard:somethingwentwrong' => "Etwas ging falsch, als das Bemuhen, Ihre Mitteilung zu bewahren, Marke sicher schrieben Sie eigentlich eine Mitteilung.",
	     
			'messageboard:failure' => "Ein unerwarteter Fehler kam vor, als er Ihre Mitteilung hinzufugte. Bitte bemuhen Sie sich wieder.",
	
	);
					
	add_translation("de",$german);

?>