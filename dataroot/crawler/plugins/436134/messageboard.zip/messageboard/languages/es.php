<?php

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messageboard:board' => "Tablon de mensajes",
			'messageboard:messageboard' => "tablon de mensajes",
			'messageboard:viewall' => "Ver todos",
			'messageboard:postit' => "Publicar",
			'messageboard:history' => "historial",
			'messageboard:none' => "Todavía no hay nada en este tablon de mensajes",
			'messageboard:num_display' => "Número de mensajes a mostrar",
			'messageboard:desc' => "Este es el tablon de mensajes que puedes poner en tu perfil y permite escribir comentarios a los demás usuarios.",
			
			'messageboard:user' => "%s's Tablon de mansajes",
	
			'messageboard:history' => "Historia",
			'messageboard:replyon' => 'Responder en',
         /**
	     * Message board widget river
	     **/
	        
	        'messageboard:river:annotate' => "%s tiene un nuevo mensaje publicado en su tablon de mensajes.",
	        'messageboard:river:create' => "%s añadio el gadget del tablon de mensajes.",
	        'messageboard:river:update' => "%s actualizo el gadget de su tablon de mensajes.",
	        'messageboard:river:added' => "%s Publico en",
		    'messageboard:river:messageboard' => "Tablon de mensajes",
			
		/**
		 * Status messages
		 */
	
			'messageboard:posted' => "Has publicado en el tablon de mensajes.",
			'messageboard:deleted' => "Has eliminado el mensaje de tablon.",
	
		/**
		 * Email messages
		 */
	
			'messageboard:email:subject' => '¡Tienes un nuevo comentario en el tablon de mensajes!',
			'messageboard:email:body' => "Tienes un nuevo comentario de %s en tu tablon de mensajes. Dice:

			
%s


Para ver los comentarios de tu tablon, haz click aquí:

	%s

Para ver el perfil de %s, haz click aquí:

	%s

No respondas a este email, ha sido generado automáticamente por el sistema.",
	
		/**
		 * Error messages
		 */
	
			'messageboard:blank' => "Debes introducir algo en el área del mensaje antes de poder guardarlo.",
			'messageboard:notfound' => "No se ha podido encontrar el elemento indicado.",
			'messageboard:notdeleted' => "No ha sido posible eliminar el mensaje.",
			'messageboard:somethingwentwrong' => "Algo salio mal al intentar guardar su mensaje, asegurese de que escribio algun mensaje.",
	     
			'messageboard:failure' => "Se ha producido un error inesperado al añadir el mensaje. Intentalo de nuevo.",
	
	);
					
	add_translation("es",$spanish);

?>