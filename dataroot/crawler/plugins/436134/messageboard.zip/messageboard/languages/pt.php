<?php

	$portugues = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messageboard:board' => "Mensagem t&aacute;bua",
			'messageboard:messageboard' => "Mensagem t&aacute;bua",
			'messageboard:viewall' => "Ver todos",
			'messageboard:postit' => "Post it",
			'messageboard:history' => "hist&oacute;ria",
			'messageboard:none' => "N&atilde;o h&aacute; nada sobre este quadro de mensagens ainda",
			'messageboard:num_display' => "N&Uacute;mero de mensagens para mostrar",
			'messageboard:desc' => "Este &eacute; um quadro de mensagens que voc&ecirc; pode colocar no seu perfil onde outros usu&aacute;rios podem comentar.",
	
			'messageboard:user' => "%s's Mensagem t&aacute;bua",
	
			'messageboard:history' => "Hist&oacute;ria",
			'messageboard:replyon' => 'Respondendo ao',
			
         /**
	     * Message board widget river
	     **/
	        
	        'messageboard:river:annotate' => "%s teve um novo coment&aacute;rio postado em seu quadro de mensagens.",
	        'messageboard:river:create' => "%s acrescentado o elemento message board.",
	        'messageboard:river:update' => "%s atualizou seu widget quadro de mensagens.",
	        'messageboard:river:added' => "%s Postado em:",
		    'messageboard:river:messageboard' => "Mensagem t&aacute;bua",

			
		/**
		 * Status messages
		 */
	
			'messageboard:posted' => "Voc&ecirc; com &ecirc;xito afixado no quadro de mensagens.",
			'messageboard:deleted' => "Est&aacute; exclu&iacute;do com sucesso a mensagem.",
	
		/**
		 * Email messages
		 */
	
			'messageboard:email:subject' => 'Voc&ecirc; tem um coment&aacute;rio novo conselho mensagem!',
			'messageboard:email:body' => "Voc&ecirc; tem um coment&aacute;rio novo conselho message from %s. L&ecirc;-se:

			
%s


Para visualizar os seus coment&aacute;rios quadro de mensagens, clique aqui:

	%s

Para visualizar %s Perfil, clique aqui:

	%s

Voc&ecirc; n&atilde;o pode responder a este email. ",
	
		/**
		 * Error messages
		 */
	
			'messageboard:blank' => "Desculpe, voc&ecirc; precisa realmente colocar algo na &aacute;rea de mensagem antes que pode salv&aacute;-lo.",
			'messageboard:notfound' => "Desculpe, n&atilde;o conseguimos encontrar o item especificado.",
			'messageboard:notdeleted' => "Desculpe, n&atilde;o foi poss&iacute;vel excluir esta mensagem.",
			'messageboard:somethingwentwrong' => "Alguma coisa correu mal ao tentar salvar a sua mensagem, certifique-se de que voc&ecirc; realmente escreveu uma mensagem.",
	     
			'messageboard:failure' => "Ocorreu um erro inesperado ao adicionar a sua mensagem. Por favor, tente novamente.",
	
	);
					
	add_translation("pt",$portugues);

?>