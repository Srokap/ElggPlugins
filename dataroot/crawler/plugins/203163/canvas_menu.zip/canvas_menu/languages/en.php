<?php

	$english = array(
	
	
			'canvasmenu:members' => "Members",
			'canvasmenu:photos' => "Photos",
			'canvasmenu:groups' => "Groups",
			'canvasmenu:videos' => "Videos",
			'canvasmenu:current' => "currently has:",
			'canvasmenu:andmore' => "and more...",
			'canvasmenu:home' => "Home",
			'canvasmenu:blogs' => "Blogs",
			'canvasmenu:bookmarks' => "Bookmarks",
			'canvasmenu:ads' => "Classifieds",
			'canvasmenu:discussions' => "Discussions",
			'canvasmenu:events' => "Events",
			'canvasmenu:wire' => "The Wire",
			'canvasmenu:public' => "publicly available.",
			'canvasmenu:register' => "Register now,",
			'canvasmenu:access' => "to access more.",

			
	);
	
	add_translation("en",$english);

?>
