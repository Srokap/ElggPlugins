<div class="canvas_menu">

<!-- insert adsense here -->
AdSense Code Goes Here
<!-- end adsense here -->
<br><br>
<div class='clearfloat'></div>
<div class='menu_content'>
<?php 
if (isloggedin()){

	echo "<ul id='nav' class='dropdown dropdown-horizontal logged-in'>

	<li><a class='top_dir' href='" . $vars['url'] . "'><img src='" . $vars['url'] . "mod/canvas_menu/images/home.png' /> Home</a>

		<ul>
		<li><a href='" . $vars['url'] . "title='" . $vars['config']->sitename . "'>" . $vars['config']->sitename . " Home Page</a></li>
		<li><a href='" . $vars['url'] . "pg/expages/read/About/' title='About the Site'>About the site</a></li>
		<li><a href='" . $vars['url'] . "contactus.php' title='Contact Us'>Contact Us</a></li>
		<li><a href='" . $vars['url'] . "pg/expages/read/Terms/' title='Terms of Service'>Terms of Service</a></li>
		<li><a href='" . $vars['url'] . "pg/expages/read/Privacy/' title='Privacy Policy'>Privacy Policy</a></li>
		<li><hr></li>
		<li><a href='" . $vars['url'] . "mod/invitefriends/' title='Invite Friends'>Invite Friends</a></li>
		</ul></li>
			
	<li><a class='top_dir' href='" . $vars['url'] . "pg/settings/'><img src='" . $vars['url'] . "mod/canvas_menu/images/settings.png' /> Settings</a>

		<ul>
		<li><a href='" . $vars['url'] . "pg/settings/' title='My Settings'>Change My Settings</a></li>
		<li><a href='" . $vars['url'] . "pg/settings/plugins/" . $_SESSION['user']->username . "/' title='Configure Your Tools'>Configure Your Tools</a></li>
		<li><a href='" . $vars['url'] . "pg/profile/" . $_SESSION['user']->username . "' title='View My Profile'>View My Profile</a></li>
		<li><a href='" . $vars['url'] . "mod/profile/edit.php?username=" . $_SESSION['user']->username . "' title='Edit My Profile'>Edit My Profile</a></li>
		<li><a href='" . $vars['url'] . "mod/profile/editicon.php' title='Change My Icon'>Change My Icon</a></li>
		<li><hr></li>
		<li><a href='" . $vars['url'] . "mod/notifications/' title='Notifications'>Notifications</a></li>
		<li><a href='" . $vars['url'] . "mod/notifications/groups.php' title='Group Notifications'>Group Notifications</a></li>
		</ul></li>

	<li><a class='top_dir' href='" . $vars['url'] . "mod/blog/everyone.php'><img src='" . $vars['url'] . "mod/canvas_menu/images/blog.png' /> Blogs</a>

		<ul>
		<li><a href='" . $vars['url'] . "mod/blog/everyone.php' title='All Blogs'>All Blogs</a></li>
		<li><a href='" . $vars['url'] . "pg/blog/" . $_SESSION['user']->username . "' title='My Blogs'>My Blogs</a></li>
		<li><a href='" . $vars['url'] . "pg/blog/" . $_SESSION['user']->username . "/friends/' title='Friends Blogs'>Friends Blogs</a></li>
		<li><hr></li>
		<li><a href='" . $vars['url'] . "mod/blog/add.php' title='Add a blog post'>Add a blog post</a></li>
		</ul></li>

	<li><a class='top_dir' href='" . $vars['url'] . "mod/bookmarks/everyone.php'><img src='" . $vars['url'] . "mod/canvas_menu/images/bookmark.png' /> Bookmarks</a>

		<ul>
		<li><a href='" . $vars['url'] . "mod/bookmarks/everyone.php' title='All Bookmarks'>All Bookmarks</a></li>
		<li><a href='" . $vars['url'] . "pg/bookmarks/" . $_SESSION['user']->username . "/items' title='My Bookmarks'>My Bookmarks</a></li>
		<li><a href='" . $vars['url'] . "pg/bookmarks/" . $_SESSION['user']->username . "/friends' title='Friends Bookmarks'>Friends Bookmarks</a></li>
		<li><hr></li>
		<li><a href='" . $vars['url'] . "mod/bookmarks/bookmarklet.php' title='Get Bookmarklet'>Get Bookmarklet</a></li>
		</ul></li>

	<li><a class='top_dir' href='" . $vars['url'] . "mod/ad/everyone.php'><img src='" . $vars['url'] . "mod/canvas_menu/images/classifieds.png' /> Classifieds</a>

		<ul>
		<li><a href='" . $vars['url'] . "mod/ad/everyone.php' title='All Classifieds'>All Classifieds</a></li>
		<li><a href='" . $vars['url'] . "pg/ad/" . $_SESSION['user']->username . "' title='My Classifieds'>My Classifieds</a></li>
		<li><a href='" . $vars['url'] . "pg/ad/" . $_SESSION['user']->username . "/friends' title='Friends Classifieds'>Friends Classifieds</a></li>
		<li><hr></li>
		<li><a href='" . $vars['url'] . "mod/ad/add.php' title='Post a Classified'>Post a Classified</a></li>
		</ul></li>

	<li><a class='top_dir' href='" . $vars['url'] . "pg/event_calendar/'><img src='" . $vars['url'] . "mod/canvas_menu/images/events.png' /> Events</a>

		<ul>
		<li><a href='" . $vars['url'] . "pg/event_calendar/' title='This Months Events'>This Months Events</a></li>
		<li><a href='" . $vars['url'] . "mod/event_calendar/show_events.php?group_guid=0&mode=&filter=mine&callback=true' title='My Events'>My Events</a></li>
		<li><a href='" . $vars['url'] . "mod/event_calendar/show_events.php?group_guid=0&mode=&filter=friends&callback=true' title='Friends Events'>Friends Events</a></li>
		<li><hr></li>
		<li><a href='" . $vars['url'] . "pg/event_calendar/new/' title='Add an Event'>Add an Event</a></li>
		</ul></li>

	<li><a class='top_dir' href='" . $vars['url'] . "pg/groups/world/?filter=active'><img src='" . $vars['url'] . "mod/canvas_menu/images/group.png' /> Groups</a>

		<ul>
		<li><a href='" . $vars['url'] . "pg/groups/world/?filter=active' title='Latest Discussion'>Latest Discussion</a></li>
			<li><hr></li>
		<li><a href='" . $vars['url'] . "pg/groups/world/?filter=newest' title='All Groups'>All Groups</a></li>
		<li><a href='" . $vars['url'] . "pg/groups/member/" . $_SESSION['user']->username . "' title='My Groups'>My Groups</a></li>
		<li><a href='" . $vars['url'] . "pg/groups/world/?filter=pop' title='Popular Groups'>Popular Groups</a></li>
		<li><hr></li>
		<li><a href='" . $vars['url'] . "pg/groups/new/' title='Create a Group'>Create a Group</a></li>
		</ul></li>

	<li><a class='top_dir' href='" . $vars['url'] . "mod/members/index.php?filter=newest'><img src='" . $vars['url'] . "mod/canvas_menu/images/members.png' /> Members</a>

		<ul>
		<li><a href='" . $vars['url'] . "mod/members/index.php?filter=newest' title='Newest'>Newest</a></li>
		<li><a href='" . $vars['url'] . "mod/members/index.php?filter=pop' title='Popular'>Popular</a></li>
		<li><a href='" . $vars['url'] . "mod/members/index.php?filter=active' title='Logged In'>Logged In</a></li>
		<li><hr></li>
		<li><a href='" . $vars['url'] . "pg/friends/" . $_SESSION['user']->username . "' title='My Friends'>My Friends</a></li>
		</ul></li>

	<li><a class='top_dir' href='" . $vars['url'] . "pg/photos/world/'><img src='" . $vars['url'] . "mod/canvas_menu/images/thumbnail.png' /> Photos</a>

		<ul>
		<li><a href='" . $vars['url'] . "pg/photos/world/' title='All Photos'>All Photos</a></li>
		<li><a href='" . $vars['url'] . "pg/photos/owned/" . $_SESSION['user']->username . "' title='My Photos'>My Photos</a></li>
		<li><a href='" . $vars['url'] . "pg/photos/friends/" . $_SESSION['user']->username . "' title='Friends Photos'>Friends Photos</a></li>
		<li><hr></li>
		<li><a href='" . $vars['url'] . "pg/photos/new/" . $_SESSION['user']->username . "' title='Create New Album'>Create New Album</a></li>
		</ul></li>

	<li><a class='top_dir' href='" . $vars['url'] . "mod/thewire/everyone.php'><img src='" . $vars['url'] . "mod/canvas_menu/images/wire.png' /> The Wire</a>

		<ul>
		<li><a href='" . $vars['url'] . "mod/thewire/everyone.php' title='All Wire Posts'>All Wire Posts</a></li>
		<li><a href='" . $vars['url'] . "pg/thewire/" . $_SESSION['user']->username . "' title='My Wire Posts'>My Wire Posts</a></li>
		<li><a href='" . $vars['url'] . "mod/thewire/replies.php?username=" . $_SESSION['user']->username . "' title='Replies to Me'>Replies to Me</a></li>
		</ul></li>

	<li><a class='top_dir' href='" . $vars['url'] . "pg/izap_videos/world/all'><img src='" . $vars['url'] . "mod/canvas_menu/images/tv.png' /> Videos</a>

		<ul>
		<li><a href='" . $vars['url'] . "pg/izap_videos/world/all' title='All Videos'>All Videos</a></li>
		<li><a href='" . $vars['url'] . "pg/izap_videos/" . $_SESSION['user']->username . "/' title='My Videos'>My Videos</a></li>
		<li><a href='" . $vars['url'] . "pg/izap_videos/" . $_SESSION['user']->username . "/frnd' title='Friends Videos'>Friends Videos</a></li>
		<li><hr></li>
		<li><a href='" . $vars['url'] . "pg/izap_videos/" . $_SESSION['user']->username . "/add' title='Add a Video'>Add a Video</a></li>
		</ul></li>
	<div class='clearfloat'></div>
	</ul>
"; 

} else {

   echo "<ul id='nav' class='dropdown dropdown-horizontal not-logged-in'>

		<li><a class='top_dir' href='" . $vars['url'] . "'><img src='" . $vars['url'] . "mod/canvas_menu/images/home.png' /> Home</a></li>
		<li><a class='top_dir' href='" . $vars['url'] . "mod/blog/everyone.php'><img src='" . $vars['url'] . "mod/canvas_menu/images/blog.png' /> Blogs</a></li>
		<li><a class='top_dir' href='" . $vars['url'] . "mod/bookmarks/everyone.php'><img src='" . $vars['url'] . "mod/canvas_menu/images/bookmark.png' /> Bookmarks</a></li>
		<li><a class='top_dir' href='" . $vars['url'] . "mod/ad/everyone.php'><img src='" . $vars['url'] . "mod/canvas_menu/images/classifieds.png' /> Classifieds</a></li>
		<li><a class='top_dir' href='" . $vars['url'] . "pg/event_calendar/'><img src='" . $vars['url'] . "mod/canvas_menu/images/events.png' /> Events</a></li>
		<li><a class='top_dir' href='" . $vars['url'] . "pg/groups/world/?filter=active'><img src='" . $vars['url'] . "mod/canvas_menu/images/group.png' /> Groups</a></li>
		<li><a class='top_dir' href='" . $vars['url'] . "mod/members/index.php?filter=newest'><img src='" . $vars['url'] . "mod/canvas_menu/images/members.png' /> Members</a></li>
		<li><a class='top_dir' href='" . $vars['url'] . "pg/photos/world/'><img src='" . $vars['url'] . "mod/canvas_menu/images/thumbnail.png' /> Photos</a></li>
		<li><a class='top_dir' href='" . $vars['url'] . "mod/thewire/everyone.php'><img src='" . $vars['url'] . "mod/canvas_menu/images/wire.png' /> The Wire</a></li>
		<li><a class='top_dir' href='" . $vars['url'] . "pg/izap_videos/world/all'><img src='" . $vars['url'] . "mod/canvas_menu/images/tv.png' /> Videos</a></li>
	<div class='clearfloat'></div>
	</ul>
";
} 
?>
<div class='clearfloat'></div>
</div><div class='clearfloat'></div>
<?php 
		$total_users = get_number_users(true);
		$groups = get_entities('group', '', 0, '', ' ', 0, true, 0, null);
		$photocount = get_entities('object','image',0,0,'', false, false);
		$videocount = get_entities('object','izap_videos', ''); 

 echo "<div class='bottomtext'>"; 

if (isloggedin()){
	echo $vars['config']->sitename . ' '; 
	echo elgg_echo("canvasmenu:current") .' '; 
	echo $total_users . ' ';
	echo elgg_echo('canvasmenu:members') . ', ';
	echo $groups . " " . elgg_echo("canvasmenu:groups") . ', '; 
	echo count($photocount) . " " . elgg_echo("canvasmenu:photos") . ', '; 
	echo count($videocount) . " " . elgg_echo("canvasmenu:videos") . ' '; 

}else{

	echo $vars['config']->sitename . ' '; 
	echo elgg_echo("canvasmenu:current") .' '; 
	echo $total_users . ' ';
	echo elgg_echo('canvasmenu:members') . ', ';
	echo $groups . " " . elgg_echo("canvasmenu:groups") . ', '; 
	echo count($photocount) . " " . elgg_echo("canvasmenu:photos") . ', '; 
	echo count($videocount) . " " . elgg_echo("canvasmenu:videos") . ' '; 
	echo elgg_echo("canvasmenu:public") . ' '; 
	echo "<a href='" . $vars['url'] . "account/register.php'>" . elgg_echo ('canvasmenu:register') . "</a>";
	echo elgg_echo ("canvasmenu:access");
	}
echo '</div>';
?>
</div>