<?php

	/**
	 * Canvas Menu with Dropdowns
	 * 
	 * @Canvas Menu
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author skotmiller <skotmiller@gmail.com>
	 * @link http://bescenepromotions.com/
	 */

	 
    function canvas_menu_init() {
    	extend_view('css','canvas_menu/css');

}

    // Make sure the
		    register_elgg_event_handler('init','system','canvas_menu_init');

?>