Chinese Community: elgg.org.cn
Support Company: cosmocommerce.com

Next Generation Web Creative Service Provider and Enterprise Solution Consultants

Installation:
Just copy the language file to your server's languages folder.

changelog:
20110919 elgg_1.8.0.1_zh_CN_v0.5
20100502 elgg_1.7.1_zh_CN_v0.4
20091122 elgg_1.6.1_zh_CN_v0.3
20090822 elgg_1.6.1_zh_CN_v0.2.1
20090722 elgg_1.6.1_zh_CN_v0.2
20090322 elgg_1.6.1_zh_CN_v0.1.1
20090222 elgg_1.6.1_zh_CN_v0.1