<?php

/**
 * This is a proof-of-concept implementation of embedding Java applets in Elgg.
 * It includes a sample applet and game.
 * (C) iionly 2012
 * GNU General Public License version 2
 */

$english = array(
        'jpatchwork:menu' => 'JPatchwork',
        'jpatchwork:title' => 'JPatchwork',
        'jpatchwork:sample_title'=> 'Sample Java Applet',
        'jpatchwork:sample_menu'=> 'Sample',
        'jpatchwork:frozenbubble_title'=> 'Frozen Bubble',
        'jpatchwork:frozenbubble_menu'=> 'Frozen Bubble',
);

add_translation('en', $english);
