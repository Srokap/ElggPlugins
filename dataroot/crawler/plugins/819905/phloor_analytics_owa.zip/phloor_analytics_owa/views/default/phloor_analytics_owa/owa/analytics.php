<?php 
/*****************************************************************************
 * Phloor Analytics OWA                                                      *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php
// get site entity
$site = elgg_get_site_entity();

// prepare variables
$vars = phloor_analytics_owa_prepare_vars($site);

// show javascript trackking code if enabled in plugin settings
if($vars['enable_tracking'] == 'true') {
	?>	
<!-- Start Open Web Analytics Tracker -->
<script type="text/javascript">
//<![CDATA[
// Set base URL
OWA.setSetting('baseUrl', '<?php echo $vars['path_to_owa']; ?>');
// Create a tracker
OWATracker = new OWA.tracker();
OWATracker.setSiteId('<?php echo $vars['site_guid']; ?>');
OWATracker.trackPageView();
OWATracker.trackClicks();
OWATracker.trackDomStream();
//]]>
</script>
<!-- End Open Web Analytics Code -->
	<?php 
}

