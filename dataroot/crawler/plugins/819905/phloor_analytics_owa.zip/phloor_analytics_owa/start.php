<?php 
/*****************************************************************************
 * Phloor Analytics OWA                                                      *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php

/**
 * 
 */
elgg_register_event_handler('init', 'system', 'phloor_analytics_owa_init');

function phloor_analytics_owa_init() {
	/**
	 * LIBRARY
	 * register a library of helper functions
	 */
	$lib_path = elgg_get_plugins_path() . 'phloor_analytics_owa/lib/';
	elgg_register_library('phloor-analytics-owa-lib', $lib_path . 'phloor_analytics_owa.lib.php');
	elgg_load_library('phloor-analytics-owa-lib');
	
	/**
	 * JS
	 */
	$site = elgg_get_site_entity();
	$vars = phloor_analytics_owa_prepare_vars($site);

	$js_url = "{$vars['path_to_owa']}modules/base/js/owa.tracker-combined-min.js";
	elgg_register_js('phloor-owa-lib', $js_url, 'head', 1);		
	
	/**
	 * Admin Menu
	 */	
	elgg_register_admin_menu_item('administer', 'phloor_analytics_owa', 'statistics');
		
	/**
	 * Actions
	 */
	$base = elgg_get_plugins_path() . 'phloor_analytics_owa/actions/phloor_analytics_owa';
	elgg_register_action('phloor_analytics_owa/save', "$base/save.php", 'admin');
	
	/**
	 * LOAD TRACKING SCRIPT
	 */
	if($vars['enable_tracking'] == 'true') {
		elgg_load_js('phloor-owa-lib'); // load owa script
		elgg_extend_view('footer/analytics', 'phloor_analytics_owa/owa/analytics', 1);
	}
	
}
