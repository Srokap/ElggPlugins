#!/usr/bin/env python

import sys, re, os
import xml.dom.minidom
import pprint

from optparse import OptionParser
from traceback import print_exc

class FileMaker(object):
    def makeDirectory( self ):
        try:
            if not self.rootDir:
                raise AttributeError, "--root-dir should contain a valid path"\
                                      " to the mod folder to create the files!"
            
            if self.optionList.update_version:
                self.updateManifestXML() 

            else:    

                for dirs in self.arguments:
                    if not os.path.exists( dirs ) : 
                        os.mkdir( dirs ) 

                self.generateElggVersion()        
                self.generateManifestXML()
                self.generateStartPHP()        
            
            return True
        except AttributeError, e:
            print "Aborting! %s" % e.message
    def generateElggVersion( self ):
        if not self.optionList.elgg_version:
            dirname = os.path.dirname
            versionphp_dir = dirname(dirname(self.optionList.rootDir))
            versionphp = os.path.join(versionphp_dir, "version.php")
            f = open(versionphp, 'r')
            for line in f:
                line = line.strip()
                if "$version" in line:
                    line = re.sub('\s', '', line)
                    elgg_version_tuple = re.split("\s|=|;", line)
                    version = elgg_version_tuple[1] 
                    break
            else:
                version = None

            self.optionList.elgg_version = version

    def updateManifestXML(self):
        xmlfile = os.path.join(self.rootDir, "manifest.xml")
        domobj = xml.dom.minidom.parse(xmlfile)
        #get the plugin manifest
        plugin_manifest = domobj.getElementsByTagName("plugin_manifest")[0]
        fields = plugin_manifest.getElementsByTagName("field")
        for n in xrange(0,fields.length):
            if fields.item(n).getAttribute("key") == "version":
                fields.item(n).setAttribute("value", self.optionList.version)
        f = open(xmlfile, 'w+')
        f.write(domobj.toxml(encoding='utf-8'))
        f.close()

    def generateManifestXML( self ):
        srcXMLFile = os.path.join( self.rootDir, "manifest.xml" )
        manifestXML = xml.dom.minidom.getDOMImplementation()
        memXMLFile = manifestXML.createDocument( None , "plugin_manifest", None )
        
        rootNode = memXMLFile.getElementsByTagName("plugin_manifest")[0]
        vdict = { "key" : ["author","version","description",
                           "website", "copyright", "license",
                           "elgg_version"],
                  "value" : [self.optionList.author,
                             self.optionList.version,
                             self.optionList.description,
                             self.optionList.website,
                             self.optionList.copyright,
                             self.optionList.license,
                             self.optionList.elgg_version] }
        for count in xrange(0,len(vdict["key"])):
            subNode = memXMLFile.createElement("field")
            for k,v in vdict.iteritems():
                subNode.setAttribute( k, v[count] )
            rootNode.appendChild( subNode )
        
        #f = open(srcXMLFile, "w+")
        #memXMLFile.writexml(f, newl='\n', 
        #                    indent="\t",
        #                    encoding='utf-8')
        #f.close()

        writerObject = open( srcXMLFile, "w+" )
        writerObject.write( memXMLFile.toprettyxml( encoding='utf-8' ) )
        writerObject.close()

    def generateStartPHP( self ):
        srcPHPFile = os.path.join( self.rootDir, "start.php" )
        phpFile = PHPFileWriter( srcPHPFile )
        phpFile.writePHPHeader()
        phpFile.writePHPHeaderComment([self.optionList.package,
                                       self.optionList.license,
                                       self.optionList.author,
                                       self.optionList.copyright,
                                       self.optionList.website])
        phpFile.writePHPFooter()
        phpFile.cleanUp()
        
class PHPFileWriter(object):
    def __init__( self, fileSource ):
        if not os.path.exists( os.path.dirname( fileSource ) ):
            raise IOError, "%s doesn't exist! " % os.path.dirname( fileSource )
        self.fileSource = fileSource
        self.fileHandle = open( fileSource, "w+" )
    def writeString( self, prettyObjectString ):
        self.fileHandle.write( prettyObjectString )
    def writePHPHeader( self ):
        self.fileHandle.write("<?php" + "\n")
    def writePHPFooter( self ):
        self.fileHandle.write("?>" + "\n")
    def writePHPHeaderComment( self, commentList, indent = "\t", newl = "\n" ):
        #TODO: This function needs to be more general to take any php comment
        #      and add it
        self.headerComment = [ indent + "/**" + newl ]
        self.headerTitles = ["@package",
                             "@license",
                             "@author",
                             "@copyright",
                             "@link"]
        self.footerComment = "*/"
        zippedCommentList = zip( self.headerTitles, commentList )
        for comment in zippedCommentList:
            self.headerComment.append( "".join( [ indent,
                                                  " * %s %s " % ( comment[0],
                                                                 comment[1] ),
                                                  newl ] ) )
        self.headerComment.append( "".join( [ indent,
                                              " ",
                                              self.footerComment,
                                              newl ] ) )
        self.writeString( "".join( self.headerComment ) )
    def cleanUp( self ):
        self.fileHandle.close()
class DoIt(object): 
    def start( self ):
        #print self.optionlist, self.arguments
        fMaker = FileMaker()
        fMaker.rootDir = self.optionlist.rootDir
        fMaker.optionList = self.optionlist
        fMaker.arguments = self.arguments
        if not fMaker.makeDirectory():
            raise IOError, "Could not generate appropriate directories."
    def add_option_parser( self, option_parser ):
        self.optionlist, self.arguments = \
            option_parser.parse_args()
        
def generate_options():
    parser = OptionParser()
    parser.add_option("-d", "--default", help="Adds default views",
                      action="store_true", default=None)
    parser.add_option("--root-dir", help="The directory to create the folders in",
                      dest="rootDir", default=None)
    parser.add_option("--author", help="Author of plugin, defaults to Curverider",
                      default="Curverider")
    parser.add_option("--version",
                      help="Version of plugin, defaults to 1.0. If "
                            "update mode is enabled, updates the version "
                            "correspondingly",
                      default="1.0")
    parser.add_option("--description", help="Description of plugin.",
                      default="None given")
    parser.add_option("--website",
                      help="Website corresponding to plugin",
                      default="http://www.elgg.org/")
    parser.add_option("--copyright",
                      help="Copyright regarding plugin",
                      default="(c) free")
    parser.add_option("--elgg-version",
                      help="Elgg version, parses version.php in the rootdir",
                      default=None)    
    parser.add_option("--license",
                      help="License type of the plugin, defaults to GPLv2",
                      default="GNU Public License version 2")    
    parser.add_option("--package",
                      help="Identification of package relationship. "
                           "Defaults to None ",
                      default="None")
    parser.add_option("--update-version",
                      action="store_true",
                      help="Updates the version stored in the XML file by "
                            "incrementing by what is set by --version",
                      default=None)

    return parser
    
if __name__ == '__main__':
    try:
        inst = DoIt()
        inst.add_option_parser( generate_options() )          
        inst.start( )
    except KeyboardInterrupt, e:
        pass
    except SystemExit, e:
        if e.code != 0:
            raise
    except:
        print_exc()

