<div class='group-layout-editor'>
<div id="customise_editpanel">
<?php
	/**
	 * Elgg vazco_mainpage plugin
	 *
	 * @author Michal Zacher [michal.zacher@gmail.com]
	 */
		// set some defaults
		$owner = page_owner_entity();
		$entity_guid = $vars['entity_guid'];
		$groupsWidgets = $_SERVER['groupsWidgets'];
		$value = $vars['value'];
		$groupsWidgets->loadFromString($value);
		
		$leftWidgets 	= $groupsWidgets->getLeftColumnWidgets();
		$rightWidgets 	= $groupsWidgets->getRightColumnWidgets();
		$middleWidgets 	= $groupsWidgets->getCenterColumnWidgets();
		$widgettypes 	= $groupsWidgets->getWidgetList();
		$htmlWidgets 	= $groupsWidgets->getHtmlWidgets();
		$allWidgets 	= $groupsWidgets->getWidgetViewArray();
		$version = get_version();
		//load colorbox libraries
		//echo elgg_view('vazco_mainpage/colorbox');
?>

<div id="customise_editpanel_rhs">
<h2><?php echo elgg_echo("vazco_groups:gallery"); ?></h2>
<div id="widget_picker_gallery_group">

<?php
	foreach($widgettypes as $widget) {
		echo elgg_view("vazco_groups/widget_table",array('widget'=>$widget));
	}
?>
</div><!-- /#customise_editpanel_rhs -->
</div><!-- /#widget_picker_gallery -->


<div class="customise_editpanel_instructions">
	<?php echo autop(elgg_echo('vazco_groups:description')); ?>
</div>


<div id="customise_page_view">
<table cellspacing="0">
		<td colspan="4" align="left" valign="top">
			<div class="topcolumn">
				<h2><?php echo elgg_echo("widgets:topcolumn"); ?></h2>
				<div id="middlecolumn_widgets_group" <?php if(get_context() == "profile")echo "class=\"long\""; ?>>
				<?php 
					$middlecolumn_widgets = "";
					foreach($middleWidgets as $widget) {
						if (!empty($middlecolumn_widgets)) {
							$middlecolumn_widgets .= "::";
						}
						$middlecolumn_widgets .= "{$widget->getName()}::0";
				
						echo elgg_view("vazco_groups/widget_table",array('widget'=>$widget));
					}
				?>
				</div>
			</div>
	    </td>
	<tr>
		<td colspan="2" align="left" valign="top">
		<h2><?php echo elgg_echo("widgets:leftcolumn"); ?></h2>
		<div id="leftcolumn_widgets_group">
		
		<?php
			$leftcolumn_widgets = "";
			foreach($leftWidgets as $widget) {
				if (!empty($leftcolumn_widgets)) {
					$leftcolumn_widgets .= "::";
				}
				$leftcolumn_widgets .= "{$widget->getName()}::0";
				echo elgg_view("vazco_groups/widget_table",array('widget'=>$widget));
			}
		?>
		</div>
		</td>
	    <td rowspan="2" align="left" valign="top">
			<h2><?php echo elgg_echo("widgets:rightcolumn"); ?></h2>
			<div id="rightcolumn_widgets_group" <?php if(get_context() == "profile")echo "class=\"long\""; ?>>
			<?php
				$rightcolumn_widgets = "";
				foreach($rightWidgets as $widget) {
					if (!empty($rightcolumn_widgets)) {
						$rightcolumn_widgets .= "::";
					}
					$rightcolumn_widgets .= "{$widget->getName()}::0";
			
					echo elgg_view("vazco_groups/widget_table",array('widget'=>$widget));
				}
			?>
			
			</div>
    	</td><!-- /rightcolumn td -->
	</tr>
	
</table>

<input type="hidden" value="<?php echo $leftcolumn_widgets; ?>"   name="debugField1" id="debugField1" />
<input type="hidden" value="<?php echo $middlecolumn_widgets; ?>" name="debugField2" id="debugField2" />
<input type="hidden" value="<?php echo $rightcolumn_widgets; ?>"  name="debugField3" id="debugField3" />
</div><!-- /customise_editpanel -->

<script type="text/javascript">
function outputWidgetListMainpage(forElement) {

	<?php
		if ($version >= 2009072201){//1.7.0 2010030101, 2009072201->1.6
			//Elgg 1.7 or newer

		?>
		return( $("input[name='handler_gle'], input[name='guid_gle']", forElement ).makeDelimitedList("value") );
		<?php
		 }else{
		 	//Elgg 1.6 or older
		?>
		return( $("input[@name='handler_gle'], input[@name='guid_gle']", forElement ).makeDelimitedList("value") );	
		<?php }?>
}

function refreshWidgetTables(){
	<?php
	//now take care of HTML content
	foreach ($htmlWidgets as $widget){
		if ($widget->isHtml()){
		?>
		content = $('#htmlContent<?php echo $widget->getId();?>').val();
		document.getElementById('htmlHandler<?php echo $widget->getId();?>').value='[html]'+content;
	<?php
		}
	}
	?>
	var widgetNamesLeft = outputWidgetListMainpage('#leftcolumn_widgets_group');
	var widgetNamesMiddle = outputWidgetListMainpage('#middlecolumn_widgets_group');
	var widgetNamesRight = outputWidgetListMainpage('#rightcolumn_widgets_group');

	document.getElementById('debugField1').value = widgetNamesLeft;
	document.getElementById('debugField2').value = widgetNamesMiddle;
	document.getElementById('debugField3').value = widgetNamesRight;
}

$(document).ready(function () {
	var els = ['#leftcolumn_widgets_group', '#middlecolumn_widgets_group', '#rightcolumn_widgets_group', '#widget_picker_gallery_group' ];
	var $els = $(els.toString());

	$els.sortable({
		items: '.draggable_widget',
		handle: '.drag_handle',
		forcePlaceholderSize: true,
		placeholder: 'ui-state-highlight',
		cursor: 'move',
		opacity: 0.9,
		appendTo: 'body',
		connectWith: els,
		start:function(e,ui) {

		},
		stop: function(e,ui) {
			// refresh list before updating hidden fields with new widget order
			$(this).sortable( "refresh" );

			var widgetNamesLeft = outputWidgetList('#leftcolumn_widgets_group');
			var widgetNamesMiddle = outputWidgetList('#middlecolumn_widgets_group');
			var widgetNamesRight = outputWidgetList('#rightcolumn_widgets_group');

			document.getElementById('debugField1').value = widgetNamesLeft;
			document.getElementById('debugField2').value = widgetNamesMiddle;
			document.getElementById('debugField3').value = widgetNamesRight;
		}
	});
	<?php 
		foreach ($allWidgets as $widget){
		?>
			$("#viewtype<?php echo $widget->getId();?>").click(function() {
			   str = $("#handler<?php echo $widget->getId();?>").val();
			   vis = $("#viewtype<?php echo $widget->getId();?>").val();
			   str = str.substring(3);
			   str = "["+vis+"]"+ str;
			   $("#handler<?php echo $widget->getId();?>").val(str);
			   refreshWidgetTables();
			   return true;
		   });
	<?php 
	}
	?>
	$("img.more_info_gle").hover(function(e) {									  
		var widgetdescription = $("input[name='description_gle']", this.parentNode.parentNode.parentNode ).attr('value');
		$("body").append("<p id='widget_moreinfo'><b>"+ widgetdescription +" </b></p>");
		
			if (e.pageX < 900) {
				$("#widget_moreinfo")
					.css("top",(e.pageY + 10) + "px")
					.css("left",(e.pageX + 10) + "px")
					.fadeIn("medium");	
			}	
			else {
				$("#widget_moreinfo")
					.css("top",(e.pageY + 10) + "px")
					.css("left",(e.pageX - 210) + "px")
					.fadeIn("medium");		
			}			
		},
		function() {
			$("#widget_moreinfo").remove();
		});	
	
		$("img.more_info_gle").mousemove(function(e) {
			// action on mousemove
		});	
	
	 $(".htmlHandler").change(function () {
		 refreshWidgetTables();
	 });
	 $(".tools-submit").click(function () {
		 refreshWidgetTables();
	 });
	 $(".submit_button").click(function () {
		 refreshWidgetTables();
	 });
	 
	<?php foreach ($htmlWidgets as $widget){?>
 	$("#htmlContent<?php echo $widget->getId();?>").change(function () {
		 $("#htmlHandler<?php echo $widget->getId();?>").val('[html]'+$("#htmlContent<?php echo $widget->getId();?>").val());
		 refreshWidgetTables();
		 return false;
	 });
	<?php }?>
	 $(".draggable_widget a").click(function () {
		 return false;
	 });
	
});
</script>
</div>
</div>
