<?php if (is_plugin_enabled('tag_cumulus')){ 
	$threshold = 1;
	$limit = 20;
	$container_guid = page_owner();
	$tags = get_tags($threshold, $limit,'tags','object','',$container_guid,'');
	if ($tags){
?>
<div class="contentWrapper">
	<h2><?php echo elgg_echo("custom:tagcloud:title"); ?></h2>
		<div class="contentWrapper tagCumulus">
		<?php echo elgg_view("output/tagcumulus",array('value' => $tags,'object' => 'object', 'subtype' => 'tags', 'width' => 145)); ?>
		<?php //echo display_tag_cumulus(0,20,'tags','object','','','');?>
	<div class="clearfloat"></div>
	</div>
</div>
<?php }else{
	?>
	<div class="contentWrapper">
	<h2><?php echo elgg_echo("custom:tagcloud:title"); ?></h2>
        <div class="contentWrapper tagCumulus">
            <?php echo elgg_echo("vazco_groups:notags"); ?>
        </div>
    </div>
	<?php 
	}
}

else{?>
    <div class="contentWrapper">
	<h2><?php echo elgg_echo("custom:tagcloud:title"); ?></h2>
        <div class="contentWrapper tagCumulus">
            <?php echo elgg_echo("vazco_groups:warning:plugin_not_enabled"); ?>
        </div>
    </div>
<?php
}
?>