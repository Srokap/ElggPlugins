<?php
/**
	 * Elgg vazco_news plugin
	 * 
	 * @author Michal Zacher [michal.zacher@gmail.com]
	 * @website www.elggdev.com
	 * @license GPL
	 */

	$performed_by = get_entity($vars['item']->subject_guid); // $statement->getSubject();
	$object = get_entity($vars['item']->object_guid);
	$url = $object->getURL();
	$url = "<a href=\"{$performed_by->getURL()}\">{$performed_by->name}</a>";
	$string = sprintf(elgg_echo("vazco_groups:river:edited"),$url) . " ";
	$string .= " <a href=\"" . $object->getURL() . "\">" .elgg_translate($object,'title'). "</a>";
	

?>

<?php echo $string; ?>