<?php

	$admin = $vars['admin'];
	$subtype = $vars['subtype'];
	$forward = $vars['forward'];
	$guid = get_input('guid');
	$obj = get_entity($guid);
	
	if (!$forward)
		$forward = $_SERVER['HTTP_REFERER'];
	//check rights	
	if ($admin){
		action_gatekeeper();
	}else{
		if ($obj->owner_guid != get_loggedin_userid() && !isadminloggedin()){
			register_error(elgg_echo('vazco_tools:delete:norights'));
			forward($forward);
		}	
	}

	if (get_subtype_from_id($obj->subtype) != $subtype){
		register_error(elgg_echo('vazco_tools:delete:wrongtype'));
		forward($forward);
	}
	
	if ( ($obj instanceof ElggObject) && ($obj->canEdit()))
	{
		if ($obj->delete())
			system_message(elgg_echo('vazco_tools:deleted'));
		else
			register_error(elgg_echo('vazco_tools:notdeleted'));
	}
	else
		register_error(elgg_echo('vazco_tools:notdeleted'));
		
	forward($forward);
	exit;
?>