<?php

	/**
	 * @uses $vars['value'] The current value, if any
	 * @uses $vars['js'] Any Javascript to enter into the input tag
	 * @uses $vars['internalname'] The name of the input field
	 */

	$value = $vars['value'];
	$selected = "";
	if ($value)
		$selected = "checked = \"checked\"";
	$label = $vars['title'];
	echo "<label><input type=\"checkbox\" {$vars['js']} name=\"{$vars['internalname']}[]\" value=\"1\" {$selected}/></label><br />";


?> 