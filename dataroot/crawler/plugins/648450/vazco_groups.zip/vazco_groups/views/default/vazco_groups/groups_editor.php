<?php
	/**
	 * Elgg vazco_mainpage plugin
	 *
	 * @author Michal Zacher [michal.zacher@gmail.com]
	 */
		// set some defaults
		$owner = page_owner_entity();
                $entity_guid = $vars['entity_guid'];
                $groupsWidgets = $_SERVER['groupsWidgets'];

                if($entity_guid){
                    $entity = get_entity($entity_guid);
                  
                    if($entity->widgets){
                        $groupsWidgets->loadFromString($entity->widgets);

                    }
                }

		$lang_id = $vars['lang_id'];
		if(empty($lang_id))
			$lang_id = get_current_language();
		set_input('lang_id', $lang_id);
		
		
		
		$leftWidgets 	= $groupsWidgets->getLeftColumnWidgets();
		$rightWidgets 	= $groupsWidgets->getRightColumnWidgets();
		$middleWidgets 	= $groupsWidgets->getCenterColumnWidgets();
		$widgettypes 	= $groupsWidgets->getWidgetList();
		$htmlWidgets 	= $groupsWidgets->getHtmlWidgets();

		//load colorbox libraries
		//echo elgg_view('vazco_mainpage/colorbox');
//print_r($rightWidgets);die();
?>
<script type="text/javascript">
$(document).ready(function () {
	$('div#customise_editpanel').slideToggle("fast");
});
</script>

<div id="customise_editpanel" style="visibility:visible;">

<div id="customise_editpanel_rhs">
<h2><?php echo elgg_echo("vazco_groups:gallery"); ?></h2>
<div id="widget_picker_gallery">

<?php
	foreach($widgettypes as $widget) {
		echo elgg_view("vazco_groups/widget_table",array('widget'=>$widget));
	}
?>

<br /><!-- bit of space at the bottom of the widget gallery -->

</div><!-- /#customise_editpanel_rhs -->
</div><!-- /#widget_picker_gallery -->


<div class="customise_editpanel_instructions">
<h2><?php echo elgg_echo('vazco_groups:title'); ?></h2>
<?php echo autop(elgg_echo('vazco_groups:description')); ?>

</div>


<div id="customise_page_view">

<table cellspacing="0">
	<tr>
		<td colspan="2" align="left" valign="top">
		<h2><?php echo elgg_echo("widgets:leftcolumn"); ?></h2>
		<div id="leftcolumn_widgets">
		
		<?php
			$leftcolumn_widgets = "";
			foreach($leftWidgets as $widget) {
				if (!empty($leftcolumn_widgets)) {
					$leftcolumn_widgets .= "::";
				}
				$leftcolumn_widgets .= "{$widget->getName()}::0";
				echo elgg_view("vazco_groups/widget_table",array('widget'=>$widget));
			}
		?>
		</div>
		</td>
	    <td rowspan="2" align="left" valign="top">
			<h2><?php echo elgg_echo("widgets:rightcolumn"); ?></h2>
			<div id="rightcolumn_widgets" <?php if(get_context() == "profile")echo "class=\"long\""; ?>>
			<?php
				$rightcolumn_widgets = "";
				foreach($rightWidgets as $widget) {
					if (!empty($rightcolumn_widgets)) {
						$rightcolumn_widgets .= "::";
					}
					$rightcolumn_widgets .= "{$widget->getName()}::0";
			
					echo elgg_view("vazco_groups/widget_table",array('widget'=>$widget));
				}
			?>
			
			</div>
    	</td><!-- /rightcolumn td -->
	</tr>
	
</table>

</div><!-- /#customise_page_view -->

<form action="<?php echo $vars['url']; ?>action/vazco_groups/update" method="post">
<?php echo elgg_view('input/securitytoken');?>
<textarea type="textarea" value="Left widgets"   style="display:none" name="debugField1" id="debugField1" /><?php echo $leftcolumn_widgets; ?></textarea>
<textarea type="textarea" value="Middle widgets" style="display:none" name="debugField2" id="debugField2" /></textarea>
<textarea type="textarea" value="Right widgets"  style="display:none" name="debugField3" id="debugField3" /><?php echo $rightcolumn_widgets; ?></textarea>
<?php
	echo elgg_view('input/hidden',array('internalname' => 'lang_id', 'value' => $lang_id));
	echo elgg_view('input/hidden',array('internalname' => '__elgg_token', 'value' => $vars['token']));
	echo elgg_view('input/hidden',array('internalname' => '__elgg_ts', 'value' => $vars['ts']));
        echo elgg_view('input/hidden', array('internalname'=>'entity_guid', 'value'=>$entity_guid));
?>
<input type="hidden" name="owner" value="<?php echo page_owner(); ?>" />
<input id="submit_widg_button" type="submit" value="<?php echo elgg_echo('save'); ?>" class="submit_button"  />

</form>
</div><!-- /customise_editpanel -->
<?php echo elgg_view('vazco_groups/tinymce');?>


<script type="text/javascript">

function outputWidgetListMainpage(forElement) {
	<?php
		if (!vazco_mainpage::newVersion()){
	?>
		return( $("input[@name='handler'], input[@name='guid']", forElement ).makeDelimitedList("value") );
	<?php
	 }else{
	?>
		return( $("input[name='handler'], input[name='guid']", forElement ).makeDelimitedList("value") );
	<?php }?>
}

function refreshWidgetTables(){
	<?php
	foreach ($htmlWidgets as $widget){
		if ($widget->isHtml()){
		?>
		content = $('#htmlContent<?php echo $widget->getId();?>').val();
		document.getElementById('htmlHandler<?php echo $widget->getId();?>').value='[html]'+content;
	<?php
		}
	}
	?>	
	var widgetNamesLeft = outputWidgetListMainpage('#leftcolumn_widgets');
	var widgetNamesMiddle = outputWidgetListMainpage('#middlecolumn_widgets');
	var widgetNamesRight = outputWidgetListMainpage('#rightcolumn_widgets');
	
	document.getElementById('debugField1').value = widgetNamesLeft;
	document.getElementById('debugField2').value = widgetNamesMiddle;
	document.getElementById('debugField3').value = widgetNamesRight;
}

$(document).ready(function () {
	 $(".htmlHandler").change(function () {
		 refreshWidgetTables();
	 });
	 $("#submit_widg_button").click(function () {
		 refreshWidgetTables();
	 });
	<?php foreach ($htmlWidgets as $widget){?>
 	$("#htmlContent<?php echo $widget->getId();?>").change(function () {
		 $("#htmlHandler<?php echo $widget->getId();?>").val('[html]'+$("#htmlContent<?php echo $widget->getId();?>").val());
		 refreshWidgetTables();
		 return false;
	 });
	<?php }?>
});
</script>

