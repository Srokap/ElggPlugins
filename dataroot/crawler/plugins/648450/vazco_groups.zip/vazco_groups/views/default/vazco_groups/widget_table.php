<?php 
$widget = $vars['widget'];
$hideBlocked = (get_plugin_setting('hideblocked','vazco_groups') == 'yes');
if (!($widget->blocked && ($hideBlocked || !isadminloggedin()))){
if ($widget->isHtml()){
	//apply inline lightbox script and div
?>
	
	
	<!-- This contains the hidden content for inline calls -->
	<div class='hidden'>
		<div id='inline_text<?php echo $widget->getId();?>' style='padding:10px; background:#fff;'>
		<?php /* if (is_plugin_enabled('tinymce')){?>
			<?php //echo elgg_view('vazco_tinymce/input/full', array('internalname' => 'context'.$widget->getId(), 'value' =>$widget->getHtml(), 'js' => 'id="context'.$widget->getId().'"'));?>
			<?php echo elgg_view('input/longtext', array('internalname' => 'context'.$widget->getId(), 'value' =>$widget->getHtml(), 'js' => 'id="context'.$widget->getId().'"'));?>
		<?php  }else{*/?>
			<textarea class="mainpage_edit" id="htmlContent<?php echo $widget->getId();?>" type="text" name="context<?php echo $widget->getId();?>"/><?php echo $widget->getHtml(); ?></textarea>
		<?php /* } */ ?>
		</div>
	</div>
<?php 
}
?>
<table class="draggable_widget<?php if ($widget->blocked){echo " not_draggable";}?>" cellspacing="0"><tr><td width="149px">
		<h3>
			<?php echo $widget->getCuteName(); ?>
			<input type="hidden" name="multiple" value="" />
			<input type="hidden" name="side" value="<?php echo $widget->isSide();?>" />
			<input type="hidden" name="main" value="<?php echo $widget->isMain();?>" />
			<?php if ($widget->isHtml()){?>
				<input class="htmlHandler" id="htmlHandler<?php echo $widget->getId();?>" type="hidden" name="handler" value = ""/></input>
			<?php }else{?>
				<input type="hidden" id="handler<?php echo $widget->getId();?>" name="handler_gle" value="<?php echo "[{$widget->getVisibility()}]{$widget->getName()}"; ?>" />
			<?php }?>
			<input type="hidden" name="description_gle" value="<?php echo $widget->getDescription(); ?>" />
			<input type="hidden" name="guid_gle" value="0" />				
		</h3>
	</td>
	<td width="17px" align="right"></td>
	<td width="17px" align="right"><a href="#"><img src="<?php echo $vars['url']; ?>_graphics/spacer.gif" width="14px" height="14px" class="more_info_gle" /></a></td>
	<td width="17px" align="right">
		<?php if (!$widget->blocked){?>
		<a href="#"><img src="<?php echo $vars['url']; ?>_graphics/spacer.gif" width="15px" height="15px" class="drag_handle" /></a>
		<?php }
		?>
		
	</td>
	</tr>
	<?php if ($widget->isHtml()){?>
	<tr><td colspan="4">
		<div class="htmlElement"><a id='inline<?php echo $widget->getId();?>' href="#"><?php echo elgg_echo('vazco_mainpage:edithtml');?></a></div>
	</td></tr>
	<?php }
		if ($widget->blocked){
			echo "<tr><td colspan='4'><div class='widgetinfo'>";
			echo $widget->getPluginInfo();
			echo "</div></td></tr>";
		}else{
	?>
		<tr><td colspan="4">
			<div class='visibility'>
				<?php
					echo elgg_echo('vazco_groups:access:visibility');
					$value = $widget->getVisibility();
					$options = array();
					$options ['0']= elgg_echo('vazco_groups:access:all');
					$options ['1']= elgg_echo('vazco_groups:access:members');
					$options ['2']= elgg_echo('vazco_groups:access:owner');
					echo elgg_view('input/pulldown', array(
						'internalid' => 'viewtype'.$widget->getId(),
						'internalname' => 'viewtype_gle',
						'options_values' => $options,
						'value' => $value,
					));
				?>
			</div>
		</td></tr>
	
	<?php 
		}
	?>
	</table>
<?php }?>