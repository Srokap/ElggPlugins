<?php
	$entity = $vars['entity'];
		
	$icon = elgg_view('vazco_groups/vazco_tools/output/icon',array('entity'=>$entity,'size'=>'small'));
	$icon = "<img src='{$icon}'>";
	if ($entity->default){
		$default = " (".elgg_echo('vazco_groups:default').")";
	}
	$info .= '<p><b><a href="'.$entity->getUrl().'">'.elgg_translate($entity,'title').'</a></b>'.$default;
	if ($brief=elgg_translate($entity,'brief_description')) {
		$info .= '<br />'.$brief;
	}
	
	$tagsarray=$entity->tags;
	$info .=  '</p>';
	
	echo elgg_view_listing($icon, $info);
	
?>