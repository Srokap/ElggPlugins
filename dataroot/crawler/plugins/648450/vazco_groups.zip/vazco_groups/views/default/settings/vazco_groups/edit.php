<?php 

?>

<p>
    <?php echo elgg_echo('vazco_groups:settings:widgetmember'); ?> 
    <?php

        $limit = get_plugin_setting('entlimit', 'vazco_groups');
        if($limit)
                $value =$limit;
       else
                $value = vazco_groups::DEFAUT_ENTLIMIT;
	echo elgg_view('input/text', array('internalname' => 'params[entlimit]', 'value' => $value));
?> 
</p>
<p>
    <?php echo elgg_echo('settings:groupoptions'); ?>
    <select name="params[groupoptions]">
        <option value="yes" <?php if ($vars['entity']->groupoptions != 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
        <option value="no" <?php if ($vars['entity']->groupoptions == 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
    </select>
</p>
<p>
    <?php echo elgg_echo('settings:hideblocked'); ?>
    <select name="params[hideblocked]">
        <option value="yes" <?php if ($vars['entity']->hideblocked == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
        <option value="no" <?php if ($vars['entity']->hideblocked != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
    </select>
</p>


<p>
    <?php echo elgg_echo('vazco_group:settings:custom'); ?> 
    <select name="params[custom]">
        <option value="yes" <?php if ($vars['entity']->custom != 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
        <option value="no" <?php if ($vars['entity']->custom == 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
    </select> 
</p>