<?php 
	$type = $vars['type'];
	$languages = vazco_tools::getLanguages();
	$counter = 0;
	
	$livequery = (get_input('livequery') == true) ? "live('click'," : "click("; //livequery use for js functionalities in lightbox depends on the set config
	$defaultLanguageValue = $vars['value_'.get_language()];
	$counter = 100 * $vars['counter'];
	foreach($languages as $language){
		$fieldName = $vars['internalname']."__".$language;
		if($counter == 0){
			echo "<div class='transfirst'>";
		}elseif ($counter == 1){
			echo "<div id='trans_".$vars['internalname']."' class='translation-list'>";
			echo '<div>'.elgg_echo($language,$language).'</div>';
		}else{
			echo '<div>'.elgg_echo($language,$language).'</div>';
		}
		$value = $vars['value_'.$language];
		$counter++;
		$js = " tabindex={$counter}";
		$counter++;
		echo elgg_view("input/{$type}",array('value' => $vars['value_'.$language], 'internalname' => $fieldName, 'js' => $js));
		if ($counter == 0){
			echo "</div><div id='transtoggle_".$vars['internalname']."' class='lang_transtoggle'><a href='#'>".elgg_echo('vazco_tools:transtoggle')."</a></div>";
		}
		$counter++;
	}
	if ($counter > 1){
		echo "</div>";
	}
?>
<script language="JavaScript">
$(document).ready(function() {
   $("#<?php echo "transtoggle_".$vars['internalname'];?>").<?php echo $livequery; ?>function() {
		$("#<?php echo "trans_".$vars['internalname'];?>").animate({ height: 'show', opacity: 'show' }, 'slow');
		$("#<?php echo "transtoggle_".$vars['internalname'];?>").animate({ height: 'hide', opacity: 'hide' }, 'slow');
		
		$("div.lang_transtoggle")
			.each(function()
				 {
						if (this.id != "<?php echo "transtoggle_".$vars['internalname'];?>"){
							
							$(this).animate({ height: 'show', opacity: 'show' }, 'slow');
						}
				 
				 });

		$("div.translation-list")
					.each(function()
						 {
								if (this.id != "<?php echo "trans_".$vars['internalname'];?>"){
									
									$(this).animate({ height: 'hide', opacity: 'hide' }, 'slow');
								}
						 
						 });
		
		return false;
   });
   $(".translation-list input").live('click',function() {
		if (this.value == '<?php echo $defaultLanguageValue;?>')
			this.value = '';
		return false;
   });
   
});
</script>