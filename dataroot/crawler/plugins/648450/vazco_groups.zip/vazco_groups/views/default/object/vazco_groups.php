<?php
//manages the view of object with subtype:  vazco_groups
//if in full view - calls the elgg_view("vazco_groups/fullview"  
//else ,depending on settings, calls 
//	elgg_view("vazco_groups/galleryview) or 
//	elgg_view("vazco_groups/listingview) 

	if ($vars['full']) {
		echo elgg_view("vazco_groups/fullview",$vars);
	} else {
		if (get_input('search_viewtype') == "gallery") {
			echo elgg_view('vazco_groups/galleryview',$vars); 				
		} else {
			echo elgg_view("vazco_groups/listingview",$vars);
		}
	}
?>