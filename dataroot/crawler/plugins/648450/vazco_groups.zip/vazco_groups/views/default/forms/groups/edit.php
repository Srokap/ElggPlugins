<?php 
if (is_plugin_enabled('profile_manager')){
	echo elgg_view('forms/groups/ver/profile_manager',$vars);
}elseif(is_plugin_enabled('flexgroupprofile')){
	echo elgg_view('forms/groups/ver/flexgroupprofile',$vars);
}else{
	echo elgg_view('forms/groups/ver/general',$vars);
}
?>