<?php
//create gallery view here
?>