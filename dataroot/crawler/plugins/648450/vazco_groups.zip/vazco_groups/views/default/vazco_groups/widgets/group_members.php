<?php
	/**
         * @author Pierre Geroudet for ElggDev  [michal.zacher@gmail.com]
         */
global $CONFIG;
$group_guid = get_input('group_guid');
$limit = get_plugin_setting('entlimit', 'vazco_groups');
if(!$limit){
    $limit = vazco_groups::DEFAUT_ENTLIMIT;
}
$offset = 0;


if ($group_guid)
{
        $group = get_entity($group_guid);
        $members = $group->getMembers($limit, $offset);

       
        $count = $group->getMembers($limit, $offset, true);

    

         if($count > $limit){
            $flag_displayButton = true;
        }


        $result = elgg_view_entity_list($members, $count, $offset, $limit, false, false, false);

}
else
{
        $result = elgg_echo('groups:widgets:members:label:pleaseedit');
}

?>




<div class="index_box">
	<h2><?php echo elgg_echo("vazco_groups:group_members"); ?></h2>
        <div class="forum_latest">
          <?php echo $result;?>
		</div>
</div>

