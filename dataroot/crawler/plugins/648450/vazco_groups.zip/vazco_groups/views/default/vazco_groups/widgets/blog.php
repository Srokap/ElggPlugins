<?php
	/**
         * @author Pierre Geroudet for ElggDev  [michal.zacher@gmail.com]
         */
global $CONFIG;
$blogs = elgg_get_entities(array('type' => 'object', 'subtype' => 'blog', 'container_guid' => page_owner(), 'limit' => 10, 'offset' => 0, 'full_view' => false, 'view_type_toggle' => false));
foreach ($blogs as $blog){
	$blogstring .= elgg_view('blog/listing', array('entity' => $blog));
}
if (!$blogstring)
	$blogstring = elgg_echo('vazco_groups:noblogs');

?>




<div class="index_box">
	<h2><?php echo elgg_echo("vazco_groups:blogs"); ?></h2>
        <div class="forum_latest">
          <?php echo $blogstring;?>
	</div>
</div>

