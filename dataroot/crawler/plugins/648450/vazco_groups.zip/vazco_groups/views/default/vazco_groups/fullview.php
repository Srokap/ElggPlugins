<?php
//show full view of a vazco_groups
	global $CONFIG;
	$entity = $vars['entity'];
	//$owner = $entity->getOwnerEntity();

	echo '<div class="contentWrapper" >';
	
//	if ($title=elgg_translate($entity,'title')) 	 
//		echo '<p><b>'.elgg_echo('vazco_groups:title').': </b> '.$title.'</p>';
	
	if ($brief=elgg_translate($entity,'brief_description')) 	 
		echo '<p><b>'.elgg_echo('vazco_groups:briefdescription').':</b> '.$brief.'</p>';
	if ($entity->active){
		echo "<p>".elgg_echo('vazco_groups:active')."</p>";
	}else{
		echo "<p>".elgg_echo('vazco_groups:inactive')."</p>";
	}
		
	$tagsarray=$entity->tags;
	$tags = elgg_view('output/tags', array('tags' => $tagsarray));
	if (!empty($tags)) {
		echo '<p class="tags">' . $tags . '</p>';
	}
	
	echo '</div>'
?>