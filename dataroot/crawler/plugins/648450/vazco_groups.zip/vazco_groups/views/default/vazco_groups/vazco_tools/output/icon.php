<?php 
	global $CONFIG;
	$size = $vars['size'];
	if (!$size)
		$size = 'small';
	$entity = $vars['entity'];
	$showdefault = $vars['showdefault'];
	if ($showdefault === null)
		$showdefault = 1;
	//size of the default icon that should be used
	$defaultIconSize = $vars['defaultIconSize'];
	if (!$defaultIconSize)
		$defaultIconSize = $size;
	if (!is_object($entity))
		$entity = get_entity($entity);
	$entity_guid = $entity->guid;
		
	if ($entity_guid){
		if (isset($vars['wrap']) && $vars['wrap']){
			$icon = "<a href='{$entity->getURL()}'><img src='{$CONFIG->wwwroot}mod/vazco_news/views/default/vazco_news/vazco_tools/output/iconImg.php?guid={$entity_guid}&size={$size}&showDefault={$showdefault}&defaultIconSize={$defaultIconSize}' alt='icon'></a>";
		}else{
			$icon = "{$CONFIG->wwwroot}mod/vazco_news/views/default/vazco_news/vazco_tools/output/iconImg.php?guid={$entity_guid}&size={$size}&showDefault={$showdefault}&defaultIconSize={$defaultIconSize}";
		}
	}else{
		$icon = "";
	}
	
	echo $icon;
?>