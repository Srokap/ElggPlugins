<?php
	/*
	 Launch this view in a file you want to use as an icon file. Use the following code:

	 require_once(dirname(dirname(__FILE__)) . "/engine/start.php"); //here use the proper path to the start file  
	 echo elgg_view($pluginName.'/tools/output/icon'); 

	 Later, invoke the icon by a link:

	 www.yoursitepath.com/pathtoyouriconfile?guid=GUIDOFICONSENTITY&size=POSSIBLESIZE

	 where possible sizes are: 'large','medium','small','tiny','master','topbar'

	 */

	require_once(dirname(dirname(dirname(dirname(dirname(dirname(dirname(dirname(__FILE__)))))))) . "/engine/start.php");
	
	global $CONFIG;
	$name = get_input('name',"image");
	$showDefault = get_input('showDefault',true);
	$guid = get_input('guid');
	$entity = get_entity($guid);
	$contents = "";
	$size = strtolower(get_input('size'));

	if (!in_array($size,array('large','medium','small','tiny','master','topbar','original')))
		$size = "medium";
	
	$success = false;
	
	$filehandler = new ElggFile();
	$nameString = "";
	if ($name){
		$nameString = "/{$name}";
	}
	$filehandler->owner_guid = $entity->owner_guid;
	if($size=="original" || $size=="master"){
		$filehandler->setFilename("tools/" . $entity->guid . $nameString  . ".jpg");
	}
	else{
		$filehandler->setFilename("tools/" . $entity->guid . $nameString . "_" . $size . ".jpg");
	}
	
	$success = false;
	if ($filehandler->open("read")) {
		if ($contents = $filehandler->read($filehandler->size())) {
			$success = true;
		} 
	}

	if ($success !== true) {
		//dumpdie("no file");
		if (!$showDefault){
			//in case no default icon is used, don't show anything
			exit();
		}
		$path = trigger_plugin_hook('vazco_tools:icon:default', $entity->getType(), array('entity' => $entity, 'viewtype' => $viewtype, 'size' => $size), false);
		if (!$path){
			$path = "{$CONFIG->path}_graphics/icons/default/{$size}.png";dumpdie($path);
		}
		$contents = file_get_contents($path);
	}
	
	header("Content-type: image/jpg");
	header('Expires: ' . date('r',time() + 864000));
	header("Pragma: public");
	header("Cache-Control: public");
	header("Content-Length: " . strlen($contents));
	echo $contents;
?>