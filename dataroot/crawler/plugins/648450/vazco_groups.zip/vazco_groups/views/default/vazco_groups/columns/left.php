<?php
/**
 * Author : Micha Zacher
 * april 2010
 */
	$_REQUEST['__gwidgets'] = 1;
	$entity = page_owner_entity();
	$groupsWidgets = $_SERVER['groupsWidgets'];
	//$groupsWidgets->loadFromString($entity->layout);
	$widgets = $groupsWidgets->displayColumnWidgets("left", false, false, $vars);
	echo $widgets; 
	$_REQUEST['__gwidgets'] = 0;
	//hide widgets that were already displayed
?>