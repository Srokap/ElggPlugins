<div class="contentWrapper">
	<h3><?php echo elgg_echo('vazco_groups:layout:temp');?></h3>
	<?php echo elgg_view('vazco_groups/layout_details', $vars);?>
</div>
