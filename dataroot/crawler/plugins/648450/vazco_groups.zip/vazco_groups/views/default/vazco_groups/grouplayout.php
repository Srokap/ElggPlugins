<?php 
	global $CONFIG;	
	$lang = "";
?>
<p>
	<label>
		<?php echo elgg_echo('vazco_groups:layout'); ?><br/>
		<?php
			$layouts = vazco_groups::getLayouts();
			//in case layotu value was passed as a parameter, don't check it. It was probably passed in callback then.
			if ($vars['vazco_groups_layout']){
				$currentLayout = $vars['vazco_groups_layout'];
			}else{
				$currentLayout = vazco_groups::getCurrentLayout(page_owner_entity());	
			}
			$defaultLayout = vazco_groups::getDefaultLayout();
			$layoutEntity = vazco_groups::getCurrentLayoutEntity();
			$customLayout = true;
			$options = array();
			if (!$currentLayout){
				$options[''] = elgg_echo('vazco_groups:no_layout');
				$customLayout = false;
			}

			$allowCustom = (get_plugin_setting('custom','vazco_groups') != 'no');
			if ($allowCustom){
				$options['customlayout'] = elgg_echo('vazco_groups:custom_layout');
			}
			foreach ($layouts as $layout){
				$options[$layout->layout] = elgg_translate($layout, 'title');
				if ($layout->layout == $currentLayout)
					$customLayout = false;  
			}
			echo elgg_view('input/pulldown', array(
					'internalname' => 'grouplayout',
					'internalid' => 'grouplayout',
					'options_values' => $options,
					'value' => $currentLayout,//$vars['vazco_groups_layout'],
				)
			); 
			foreach($layouts as $layout){
				$options[$layout->guid] = $layout->$title;
			}
		?>
		</label>
		<div id="layouteditor" <?php if (!$customLayout || !$allowCustom){echo " class='hidden'";}?>>
			<?php echo elgg_view('input/layouteditor', array('value' => $currentLayout));?>
		</div>
		<div id="layoutview"></div>
	</p>
<script language="JavaScript">
	  $(document).ready(function() {
		function changeLayout(){
			$("#layouteditor").animate({ height: 'hide', opacity: 'hide' }, 'slow');
				   guid = 0;
				   <?php foreach($layouts as $layout){?>
				   if (!guid && $('#grouplayout').val() == '<?php echo $layout->layout;?>'){
					   guid = <?php echo $layout->guid;?>;
				   }
				   <?php }?>
				   if (guid){
					$("#layoutview").html('<?php echo elgg_view('ajax/loader');?>');
					$("#layoutview").animate({ height: 'show', opacity: 'show' }, 'slow');
					$("#layoutview").load('<?php echo $CONFIG->wwwroot;?>mod/vazco_groups/layout.php?guid='+guid);
				   }
		}
		   $("#grouplayout").change(function() {
			   if ($("#grouplayout").val() == 'customlayout'){
					$("#layouteditor").animate({ height: 'show', opacity: 'show' }, 'slow');
					$("#layoutview").animate({ height: 'hide', opacity: 'hide' }, 'slow');
					$("#layoutview").html('');
			   }else{
					changeLayout();

			   }
		   });
		   <?php if (!$allowCustom){?>
				changeLayout();
		   <?php }?>
			<?php if ($layoutEntity){?>
				$("#layoutview").html('<?php echo elgg_view('ajax/loader');?>');
				$("#layoutview").animate({ height: 'show', opacity: 'show' }, 'slow');
				$("#layoutview").load('<?php echo $CONFIG->wwwroot;?>mod/vazco_groups/layout.php?guid=<?php echo $layoutEntity->guid;?>');
			<?php }?>
	  });
</script>