<?php
/*
 * Css for vazco_groups
 */
?>
.groupWidgetTemplate{
	border: 1px solid #CCCCCC;
	padding:10px;
	margin:10px 0;
}
#fullcolumn .index_box,
#right_column .index_box,
#left_column .index_box{
	-moz-border-radius:8px 8px 8px 8px;
	background:white;
	margin:0 0 20px;
	padding:0 0 5px;
}
.more_info_gle{
	background:url("<?php echo $vars['url'];?>/_graphics/icon_customise_info.gif") no-repeat scroll left top transparent;
	cursor:pointer;
	margin-top:4px;
}

#right_column .contentWrapper,
#left_column .contentWrapper{
	margin:0 0 10px 0;
}
.draggable_widget .visibility{
	padding:5px;
}

#widget_picker_gallery_group table.not_draggable{
	background: #FFCF8D !important;
}
.widgetinfo{
	font-size:10px;
	padding:0 5px 3px;
}

.centerWidgets{
	margin:10px;
}

#fullcolumn .contentWrapper{
	margin: 10px 0 !important;
}

.hidden{
	display:none;
}
.group-layout-editor{
	min-height:600px;
}

.group-layout-editor,
.group-layout-example{
	margin:10px 0;
	padding:5px;
	border:1px solid #CCCCCC;
	-moz-border-radius:4px;
	width: 661px;
}
.group-layout-editor #customise_editpanel_rhs{
	width:225px;
}
#customise_editpanel{
	display:none;
}

.group-layout-editor #widget_picker_gallery{
	height:540px;
	padding:8px;
}
.group-layout-editor #customise_editpanel{
	padding:0;
	margin:0;
	background:none;
	display:block;
}
#groups_content .wide .groupWidgetTemplate{
	width:655px;
}

#customise_page_view .topcolumn h2,
.group-layout-editor #middlecolumn_widgets_group{
	width: 424px;
	margin:0;
}

.group-layout-editor #customise_page_view{
	width:440px;
	padding:0;
}

.left .groupWidgetTemplate,
.right .groupWidgetTemplate{
	width: 300px;
}
.center .groupWidgetTemplate{
	width: 650px;
}

.groupWidgetTemplate h2{
	border-bottom:1px solid #CCCCCC;
	font-size:14px;
}

#groups_content .left,
#groups_content .right{   
	width:325px; 
	margin:0;    
	padding:0;   
}

#groups_content .left{
	float:left;
}
#groups_content .right{    
	float:right;    
}
.widget-links{
	background:none repeat scroll white;
	display:block;
	margin:0 10px 5px;
	padding:5px;
	height:15px
}
.widget-links a.more{
  float:right;
  }
  
.fullcolumn .index_box .contentWrapper,
.right_column .index_box .contentWrapper,
.left_column .index_box .contentWrapper{
  background: none repeat #DEDEDE;
}

#leftcolumn_widgets_group {
	width:200px;
	margin:0 10px 0 0;
	padding:5px 5px 40px 5px;
	min-height: 190px;
	border:1px solid #cccccc;
}
#middlecolumn_widgets_group {
	width:200px;
	margin:0 10px 0 0;
	padding:5px 5px 40px 5px;
	min-height: 190px;
	border:1px solid #cccccc;
}
#rightcolumn_widgets_group {
	width:200px;
	margin:0;
	padding:5px 5px 40px 5px;
	min-height: 190px;
	border:1px solid #cccccc;
}
#rightcolumn_widgets_group.long {
	min-height: 288px;
}
/* IE6 fix */
* html #leftcolumn_widgets_group {
	height: 190px;
}
* html #middlecolumn_widgets_group {
	height: 190px;
}
* html #rightcolumn_widgets_group {
	height: 190px;
}
* html #rightcolumn_widgets_group.long {
	height: 338px;
}
#widget_picker_gallery_group table.draggable_widget h3 {
	word-wrap:break-word;
	width:145px;
	line-height: 1.1em;
	overflow: hidden;
	padding:4px;
}
#widget_picker_gallery_group table.draggable_widget {
	width:200px;
	background: #cccccc;
	margin: 10px 0 0 0;
}
#widget_picker_gallery_group {
	border-top:1px solid #cccccc;
	background:white;
	width:210px;
	height:532px;
	padding:10px;
	overflow:scroll;
	overflow-x:hidden;
}