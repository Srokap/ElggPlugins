
<script type="text/javascript">
$(document).ready(function () {
    $('a.share_more_info').click(function () {
		$(this.parentNode).children("[class=share_desc]").slideToggle("fast");
		return false;
    });
}); /* end document ready function */
</script>

<?php
$group_guid = get_input('group_guid');
$limit = 10;

//grab the users bookmarked items
$count = get_entities("object", "bookmarks",  $group_guid, "", 0, 0, true);
$shares = get_entities('object', 'bookmarks',$group_guid, "", $limit, 0, false);
	
if($shares){
	$html = "";
	foreach($shares as $s){

		//get the owner
		$owner = $s->getOwnerEntity();
		
		//get the time
		$friendlytime = friendly_time($s->time_created);
		
		//get the user icon
		$icon = elgg_view(
			"profile/icon", array(
				'entity' => $owner,
				'size' => 'tiny',
			  )
		);

		//get the bookmark title
		$info = "<p class=\"shares_title\"><a href=\"{$s->getURL()}\">{$s->title}</a></p>";
		
		//get the user details
		$info .= "<p class=\"shares_timestamp\"><small><a href=\"{$owner->getURL()}\">{$owner->name}</a> {$friendlytime}</small></p>";
		
		//get the bookmark description
		if($s->description)
			$info .= "<a href=\"javascript:void(0);\" class=\"share_more_info\">".elgg_echo('bookmarks:more')."</a><br /><div class=\"share_desc\"><p>{$s->description}</p></div>";
			
		//display 
		$html .=  "<div class=\"shares_widget_wrapper\">";
		$html .= "<div class=\"shares_widget_icon\">" . $icon . "</div>";
		$html .="<div class=\"shares_widget_content\">" . $info . "</div>";
		$html .="</div>";

		}


	}
    else{
         $html = "<div class=\"\" >".elgg_echo("vazco_groups:nobookmarks") ."</div>";
   }

?>

<div class="index_box">
    <h2><span><?php echo elgg_echo("vazco_groups:group_bookmarks"); ?></span></h2>
    <div class="forum_latest">
		<?php echo $html;?>
	</div>
</div>