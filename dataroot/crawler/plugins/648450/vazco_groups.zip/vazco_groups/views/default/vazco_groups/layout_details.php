<?php
/**
 * Author : Pierre Geroudet [pgeroudet@akkroweb.com]
 * april 2010
 */
$entity_guid = $vars['guid'];
$entity = get_entity($entity_guid);
$groupsWidgets = $_SERVER['groupsWidgets'];
$groupsWidgets->loadFromString($entity->layout);
?>

<div id="groups_content">
	  <div class="wide">
            <?php   echo  $groupsWidgets->displayColumnWidgets("center", false, true); ?>

      </div>   
        <!-- left column content -->
        <div class="left">
            <?php   echo  $groupsWidgets->displayColumnWidgets("left", false, true); ?>

      </div>
       <!-- right hand column -->
        <div class="right">
         
            <?php  echo $groupsWidgets->displayColumnWidgets("right", false, true); ?>
        </div>
    <div class='clearfloat'></div>
</div>