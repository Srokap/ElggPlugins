<?php
	// must have security token 
	action_gatekeeper();
	
	// get parameters that were posted
	$params = array();
	$languages = vazco_tools::getLanguages();
	$entity = null;
	$entity_guid = get_input('guid',0);//takes from hidden sent from form template
	if (!$entity_guid) {
            $access = ACCESS_PUBLIC;
	}

        
	$fieldArray = vazco_groups::reviewEditFormArray($entity);
	$formName = 'vazco_groups_edit';

         //saves entity in database and triggers $entity->getUrl
	vazco_groups::setLayoutValue($fieldArray,'layout');
	elgg_view("vazco_groups/vazco_tools/actions/edit",
		array(
			'fieldArray' => $fieldArray,
			'formName' => $formName,
			'redirectUrl' => null,
			'entity' => $entity,
			'subtype' => 'vazco_groups',
			'access' => $access,
			'ajax'=>true,
		)
	);
       
	$lastEntity = get_entity(vazco_tools::getLastEntity());

       
       
	//save layout's widgets
	vazco_groups::saveLayout($lastEntity);
	vazco_groups::setAccessId($lastEntity);
	
	//if this entity has to be default one, the other must be not
	vazco_groups::clearDefaultLayouts($lastEntity);
	$redirectUrl = $lastEntity->getURL(); 

	forward($redirectUrl);
	
?>