<?php


global $CONFIG;


// validate user is an admin
gatekeeper ();

// validate action
action_gatekeeper ();

$lang_id = get_input('lang_id',0);
$leftbar = str_replace ( '::0', '', $_POST['debugField1'] );
$middlebar = str_replace ( '::0', '', $_POST['debugField2'] );
$rightbar = str_replace ( '::0', '', $_POST['debugField3'] );
$lang_id = get_input('lang_id',0);

$entity_guid = get_input('entity_guid');

$entity = get_entity($entity_guid);


// join widgets into a single string
$widgets = $leftbar . '%~~%' . $middlebar . '%~~%' . $rightbar;


$entity->widgets = $widgets;
if($entity->default){
    //if this entity has to be default one, the other must be not
    vazco_groups::setLayoutAsDefault($entity->guid);
}



// save the object or report error

        system_message ( elgg_echo ( 'vazco_mainpage:update:success' ) );
        $entity->state = "active";
        $entity->access_id = ACCESS_PUBLIC;
         $entity->save();
        



?>