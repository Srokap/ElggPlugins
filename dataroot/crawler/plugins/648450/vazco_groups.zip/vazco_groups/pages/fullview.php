<?php


 
// Load Elgg engine
require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");

// Define context
set_context('groupprofile'); //set automatically
global $CONFIG;


set_input('lang_id', get_current_language());



$entity_guid = get_input('guid',0);

if ($entity_guid && ($entity = get_entity($entity_guid))) {
	//set_page_owner($entity->container_guid);
       
	$groupsWidgets = $entity->widgets;
	//$groupsWidgets->load();

	set_page_owner(get_loggedin_userid());
	$body = elgg_view_entity($entity,true);
    $body .= elgg_view('vazco_groups/layout', array('guid'=>$entity_guid));

	$title = elgg_translate($entity,'title');
	page_draw($title,elgg_view_layout("two_column_left_sidebar", '', elgg_view_title($title) . $body));
} else {
	register_error(elgg_echo('vazco_groups:error_nosuchentity'));
	forward($_SERVER['HTTP_REFERER']);
}
?>