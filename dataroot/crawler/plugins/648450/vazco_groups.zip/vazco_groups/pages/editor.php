<?php

	// include the Elgg engine
	include_once dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php";

        // make sure only admins can view this
        gatekeeper ();
        set_context ( 'groupprofile' );

        $lang_id = get_input('lang_id');

        $entity_guid= get_input('guid',0);

        // set admin user for user block
        set_page_owner ( $_SESSION ['guid'] );

        // vars required for action gatekeeper
        $ts = time ();
        $token = generate_action_token ( $ts );
        $context = 'profile';

        // create the view
        $content = elgg_view ("vazco_groups/groups_editor", array ('token' => $token, 'ts' => $ts, 'context' => $context, 'lang_id' => $lang_id , 'entity_guid'=>$entity_guid) );

        // Display main admin menu
        page_draw ('vazco_groups:general:title', $content );




?>