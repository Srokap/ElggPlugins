    <?php

	
	set_context('groupprofile');
	$type = get_input('type');
       
	$user_guid = get_loggedin_userid();
	require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
	//set title ie. "frank's news:"
	$body = elgg_view_title(elgg_echo("vazco_groups:userlisting"));
	if ($type == 'pending'){
		$body.= list_entities_from_metadata('active', 0, 'object','vazco_groups',$user_guid,10,false);
	}else{
		$body.= list_entities('object','vazco_groups',$user_guid,10,false);
	}
	$body = elgg_view_layout('two_column_left_sidebar', '', $body, '');
	// Finally draw the page
	page_draw(elgg_echo("vazco_groups:all"), $body);
	?>