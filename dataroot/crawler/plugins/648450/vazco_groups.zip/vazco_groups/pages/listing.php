<?php

	//admin_gatekeeper(); // should listing of all entities be private?
	set_context('groupprofile');
	
	require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
	//set title ie. "frank's news:"
	set_page_owner(get_loggedin_userid());
	$body = elgg_view_title(elgg_echo("vazco_groups:all"));
	$body.= list_entities('object','vazco_groups',0,10,false);

	$body = elgg_view_layout('two_column_left_sidebar', '', $body, '');
	
	// Finally draw the page
	page_draw(elgg_echo("vazco_groups:all"), $body);

?>