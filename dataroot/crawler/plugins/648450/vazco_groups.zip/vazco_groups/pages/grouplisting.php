<?php

	
	set_context('groupprofile');
	$group_guid = get_input('guid',0);
	require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
	//set title ie. "frank's news:"
	$body = elgg_view_title(elgg_echo("vazco_groups:grouplisting"));
	
	//listing with the following parameters:
	//$owner_guid = 0 (all owners), $limit = 10, $fullview = false, $viewtypetoggle = false, $pagination = true
	$body.=elgg_list_entities(array('type'=>'object', 'subtype'=>'vazco_groups','limit'=>10,'container_guids'=>array($group_guid),'full_view'=>false));

	$body = elgg_view_layout('two_column_left_sidebar', '', $body, '');
	
	// Finally draw the page
	page_draw(elgg_echo("vazco_groups:all"), $body);

?>