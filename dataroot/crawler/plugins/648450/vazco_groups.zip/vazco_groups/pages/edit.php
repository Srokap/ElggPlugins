<?php 
	require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
	
	set_context('groupprofile');
	$entity_guid = get_input('guid',0);//from page handler
	if($entity_guid){
		$entity=get_entity($entity_guid);
                set_page_owner($entity->container_guid);
                
                gatekeeper();
        }
        else{
            admin_gatekeeper();
            set_page_owner(get_loggedin_userid());
        }
        
	$title = elgg_echo('vazco_groups:edit');
	if (!$entity_guid)
		$title = elgg_echo('vazco_groups:new');
	
	//call a view that will call a template form for editting/adding with customized array of inputs
	$body = elgg_view('vazco_groups/edit',array('guid'=>$entity_guid));
	
	page_draw($title,elgg_view_layout("two_column_left_sidebar", '', elgg_view_title($title) . $body));	
	
?>