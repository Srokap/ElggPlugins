    <?php

	
	
       
	
	require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
	
	$guid = get_input('group_guid');
	set_page_owner($guid);
    set_context("group");
	
    $entity = get_entity($guid);

           
	//set title ie. "frank's news:"
	$body = elgg_view_title(elgg_echo("vazco_groups:memberlisting")  );
	$body .= list_entities_from_relationship('member', $guid, true, 'user', "", 0,10,false);
      
	$body = elgg_view_layout('two_column_left_sidebar', '', $body, '');
	// Finally draw the page
	page_draw(elgg_echo("vazco_groups:memberlisting"), $body);
	?>