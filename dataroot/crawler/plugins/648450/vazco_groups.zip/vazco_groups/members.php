<?php
/**
 * Author : Pierre Geroudet [pgeroudet@akkroweb.com] for ElggDev [michal.zacher@gmail.com]
 * april 2010
 */
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");



$group_guid = get_input('group_guid');
$limit = get_input('limit');
$offset = 0;

FB::info("DEBUG MESSAGE AT :".__FILE__ ." LINE: ". __LINE__);
FB::error($limit);

if ($group_guid)
{
        $group = get_entity($group_guid);
        $members = $group->getMembers($limit, $offset);

        $count = $group->getMembers($limit, $offset, true);
        $countTotal = $group->getMembers(0, $offset, true);
        if($countTotal > $count){
            $flag_displayButton = true;
        }

        $result = elgg_view_entity_list($members, $count, $offset, $limit, false, false, false);

}
else
{
        $result = elgg_echo('groups:widgets:members:label:pleaseedit');
}

?>

    	
		<?php echo $result;?>
                <?php if(isset($flag_displayButton) && $flag_displayButton){
                   
                }?>
               


