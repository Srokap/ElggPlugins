<?php 
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");	
	$guid = get_input('guid');
?>
<div class="group-layout-example">
<h2><?php echo elgg_echo('vazco_groups:layoutexample');?></h2>
<?php
	echo elgg_view('vazco_groups/layout_details', array('guid' => $guid));
?>
</div>