<?php
/*******************************************************************************
 * vazco_groups
 *
 * @author Michal Zacher, Pierre Geroudet, Elggdev
 ******************************************************************************/

/********************************************
 * VAZCO_TOOLS (don't modify this code)
 *******************************************/
	//register handler for this plugin's tools library
	register_elgg_event_handler('init', 'tools', 'vazco_groups_tools_init',99999977777); //should be generated as 99999999999 - time()
	
	if (!function_exists('vazco_init_tools')){
		function vazco_init_tools($plugin, $time){
			//register handler that will invoke tools library in case it was not yet invoked
			if (!$_REQUEST['__toolshandler']){
				$_REQUEST['__toolshandler'] = 1;
				trigger_elgg_event('init','tools');
			}
		}
	}

	function vazco_groups_tools_init(){
		if (!$_REQUEST['__toolson']){
			$_REQUEST['__toolson'] = 1;
			require_once(dirname(__FILE__).'/models/tools.php');
		}
	}
	
/********************************************
 * END OF VAZCO_TOOLS
 *******************************************/

	function vazco_groups_init()
	{
		global $CONFIG;
		
		//init tools handler if it was not set before
		vazco_init_tools();
		require_once(dirname(__FILE__).'/models/model.php');
		//require_once($CONFIG->pluginspath . "vazco_groups/models/widget_list.php");
		//vazco_groups::addWidgets();
		register_elgg_event_handler('create','group','vazco_groulayout_group_created_handler',501);
		register_elgg_event_handler('update','group','vazco_groulayout_group_created_handler',501);
		extend_view('css','vazco_groups/css');
		extend_view('groups/forum_latest','vazco_groups/columns/center',1);
		extend_view('groups/right_column','vazco_groups/columns/right',1);
		extend_view('groups/left_column','vazco_groups/columns/left',1);
		
		register_page_handler('groupprofile','vazco_groups_page_handler');
		register_entity_url_handler('vazco_groups_urlhandler','object', 'vazco_groups');

		//add_menu(groupprofile, $CONFIG->wwwroot . 'pg/groupprofile/editor/');

		register_action('vazco_groups/edit', false, $CONFIG->pluginspath . 'vazco_groups/actions/edit.php');
		register_action('vazco_groups/update', false,  $CONFIG->pluginspath . 'vazco_groups/actions/update.php');
		register_action('vazco_groups/edit', false,  $CONFIG->pluginspath . 'vazco_groups/actions/edit.php');
		register_action('vazco_groups/delete', false, $CONFIG->pluginspath . 'vazco_groups/actions/delete.php');
		register_action('vazco_groups/editgroup', false, $CONFIG->pluginspath . 'vazco_groups/actions/editgroup.php');
		register_plugin_hook('vazco_tools:icon:default','object','get_default_grouplayout_icon');
		register_elgg_event_handler('pagesetup','system','vazco_groups_submenus');
		register_elgg_event_handler('pagesetup','system','vazco_groups_addwidgets');
		register_plugin_hook('groupwidgets', 'vazco_groups', 'vazco_groups_addwidgettypes',1);
		//clear views
		//register_plugin_hook('action', 'admin/plugins/enable', 'vazco_grouplayouts_createviews_handler',800);
		//register_plugin_hook('action', 'admin/plugins/reorder', 'vazco_grouplayouts_createviews_handler',800);
		return true;
	}
	/*
	function vazco_grouplayouts_createviews_handler($event, $object_type, $returnvalue, $array){
		$groupsWidgets = $_SERVER['groupsWidgets'];
		$groupsWidgets->hideOldGroupWidgets();		
	}
	*/
	function vazco_groups_addwidgets(){
		vazco_groups::addWidgets();
	}
	//add widgets. Use this method to add your own widgets
	function vazco_groups_addwidgettypes($event, $object_type, $object, $params){
		$groupsWidgets = $params['widgets'];
		$widget = new groupsWidget(
			'blog'
			,elgg_echo("vazco_groups:blogs")
			,elgg_echo("vazco_groups:blogs:desc")
			,'vazco_groups/widgets/blog'
			,null
			,'blog'
		);
		$groupsWidgets->addWidget($widget);
		
		$widget = new groupsWidget(
			'group_members'
			,elgg_echo("vazco_groups:group_members")
			,elgg_echo("vazco_groups:group_members:desc")
			,'vazco_groups/widgets/group_members'
			,null
			,'vazco_groups'
		);
        $groupsWidgets->addWidget($widget);
		$widget = new groupsWidget(
			'group_docs'
			,elgg_echo("vazco_groups:group_docs")
			,elgg_echo("vazco_groups:group_docs:desc")
			,'pages/groupprofile_pages'
			,null
			,'pages'
		);
		$bookmarkUrl = 'bookmarks/groupprofile_bookmarks';
		if (get_version() < 2010071002)
			$bookmarkUrl = 'vazco_groups/widgets/bookmarks';
		//for Elgg before 1.7 use vazco_groups/widgets/bookmarks
		/*
		if (get_version)
		*/
		$groupsWidgets->addWidget($widget);
	
	          $widget = new groupsWidget(
			'group_bookmarks'
			,elgg_echo("vazco_groups:group_bookmarks")
			,elgg_echo("vazco_groups:group_bookmarks:desc")
			,$bookmarkUrl
			,null
			,'bookmarks'
		);
	
		$groupsWidgets->addWidget($widget);
	
		$widget = new groupsWidget(
			'group_polls'
			,elgg_echo("vazco_groups:group_polls")
			,elgg_echo("vazco_groups:group_polls:desc")
			,'vazco_groups/widgets/latestpolls'
			,null
			,'poll'
		);
		$groupsWidgets->addWidget($widget);
	
	
		$widget = new groupsWidget(
			'event_calendar'
			,elgg_echo("groupprofile:event_calendar")
			,elgg_echo("groupprofile:event_calendar:desc")
			,'event_calendar/groupprofile_calendar'
			,null
			,'event_calendar'
		);
		$groupsWidgets->addWidget($widget);
	
		$widget = new groupsWidget(
			'tag_cumulus'
			,elgg_echo("groupprofile:tag_cumulus")
			,elgg_echo("groupprofile:tag_cumulus:desc")
			,'vazco_groups/widgets/tagcloud'
			,null
			,'tag_cumulus'
		);
		$groupsWidgets->addWidget($widget);
		
		$widget = new groupsWidget(
			'file'
			,elgg_echo("groupprofile:file")
			,elgg_echo("groupprofile:file:desc")
			,'file/groupprofile_files'
			,null
			,'vazco_groups'
		);
		$groupsWidgets->addWidget($widget);
	
		$widget = new groupsWidget(
			'xgadgets'
			,elgg_echo("groupprofile:xgadgets")
			,elgg_echo("groupprofile:xgadgets:desc")
			,'vazco_xgadgets/group/right'
			,'vazco_xgadgets/group/middle'//wide widget view
			,'vazco_xgadgets'
		);
		$groupsWidgets->addWidget($widget);
		
		$widget = new groupsWidget(
			'checklist'
			,elgg_echo("groupprofile:checklist")
			,elgg_echo("groupprofile:checklist:desc")
			,'vazco_checklist/widgets/vazco_checklist_for_groups'
			,null
			,'vazco_checklist'
		);
		$groupsWidgets->addWidget($widget);
		
		$widget = new groupsWidget(
			'tidypics'
			,elgg_echo("groupprofile:tidypics")
			,elgg_echo("groupprofile:tidypics:desc")
			,'tidypics/groupprofile_albums'
			,null
			,'tidypics'
		);
		$groupsWidgets->addWidget($widget);
		
		$widget = new groupsWidget(
			'socialcommerce'
			,elgg_echo("groupprofile:socialcommerce")
			,elgg_echo("groupprofile:socialcommerce:desc")
			,'stores/groupprofile_files'
			,null
			,'socialcommerce'
		);
		$groupsWidgets->addWidget($widget);
		
		$widget = new groupsWidget(
			'kaltura'
			,elgg_echo("groupprofile:kaltura")
			,elgg_echo("groupprofile:kaltura:desc")
			,'kaltura/groupprofile'
			,null
			,'kaltura'
		);
		$groupsWidgets->addWidget($widget);
		
		$widget = new groupsWidget(
			'izapvid'
			,elgg_echo("groupprofile:izapvid")
			,elgg_echo("groupprofile:izapvid:desc")
			,'izap_videos/gruopprofile_izapVideos'
			,null
			,'izap_videos'
		);
		$groupsWidgets->addWidget($widget);	
		
		$widget = new groupsWidget(
			'discussion'
			,elgg_echo("groupprofile:discussion")
			,elgg_echo("groupprofile:discussion:desc")
			,'groups/forum_latest'
			,null
			,'groups'
		);
		$groupsWidgets->addWidget($widget);	
		return $groupsWidgets;
	}

	function vazco_groulayout_group_created_handler($event, $object_type, $object){
		if (!$_REQUEST['gulaunched']){
			$_REQUEST['gulaunched'] = true;
			$group = $object;
			$layout = get_input('grouplayout');
			if ($layout == 'customlayout'){
				vazco_groups::saveLayout($group);
			}else{
				$group->layout = $layout;
			}
			$group->save();
		}
	}
		
	function get_default_grouplayout_icon($hook, $entity_type, $returnvalue, $params){
		$entity = $params['entity'];
		global $CONFIG;	
		//dumpdie($entity);
		if($entity->getSubtype()=='vazco_groups')
			return "{$CONFIG->pluginspath}vazco_groups/graphics/default.gif";
		else
			return $return_value;
	}
	
	function vazco_groups_urlhandler($entity)
	{
		global $CONFIG;

		return $CONFIG->wwwroot."pg/groupprofile/view/".$entity->guid;
	}
	function vazco_groups_page_handler($page)
	{
		global $CONFIG;
                		
		switch ($page[0])
		{
			case 'editor':
                                set_input('guid',$page[1]);
				include $CONFIG->pluginspath . 'vazco_groups/pages/editor.php';
				break;
			case 'listing':
				include $CONFIG->pluginspath . 'vazco_groups/pages/listing.php';
				break;
			case 'userlisting':
				set_input('type',$page[1]);
				include $CONFIG->pluginspath . 'vazco_groups/pages/userlisting.php';
				break;
                        case 'memberlisting':
				set_input('group_guid',$page[1]);
				include $CONFIG->pluginspath . 'vazco_groups/pages/memberlisting.php';
				break;
			case 'grouplisting':
				set_input('guid',$page[1]);//group guid
				include $CONFIG->pluginspath . 'vazco_groups/pages/grouplisting.php';
				break;
			case 'new':
				set_input('guid',$page[1]);
				include $CONFIG->pluginspath . 'vazco_groups/pages/edit.php';
				break;
			case 'edit':
				set_input('guid',$page[1]);
				include $CONFIG->pluginspath . 'vazco_groups/pages/edit.php';
				break;
			case 'view':
				set_input('guid',$page[1]);
				include $CONFIG->pluginspath . 'vazco_groups/pages/fullview.php';
				break;
		}
		
		return true;
	}


	function vazco_groups_submenus()
	{
		global $CONFIG;
		$context = get_context();
		if ($context == 'groupprofile' && isadminloggedin())
		{
                        add_submenu_item(elgg_echo('vazco_groups:pendinglisting'),$CONFIG->wwwroot."pg/groupprofile/userlisting/pending");
                        add_submenu_item(elgg_echo('vazco_groups:userlisting'),$CONFIG->wwwroot."pg/groupprofile/userlisting/");
                        add_submenu_item(elgg_echo('vazco_groups:add'),$CONFIG->wwwroot."pg/groupprofile/new/", '000vazco_groups');
			$guid = get_input('guid');
			$entity = get_entity($guid);
			if ($entity && get_subtype_from_id($entity->subtype) == "vazco_groups")//if entity from get input has the desired subtype
			{
				add_submenu_item(elgg_echo('vazco_groups:view'),$CONFIG->wwwroot."pg/groupprofile/view/".$entity->guid,'00vazco_groups');
				if($entity->canEdit())
				{
					add_submenu_item(elgg_echo('vazco_groups:edit'),$CONFIG->wwwroot."pg/groupprofile/edit/".$entity->guid,'000vazco_groups');
					$action="{$CONFIG->wwwroot}action/vazco_groups/delete".get_security_token_str()."&guid={$entity->guid}";
					add_submenu_item(elgg_echo('vazco_groups:delete_link'),$action, '000vazco_groups', true);
				}
			}
            add_submenu_item(elgg_echo('vazco_groups:listing'),$CONFIG->wwwroot."pg/groupprofile/listing");
		}
		elseif($context == 'admin'){
				add_submenu_item(elgg_echo('vazco_groups:listing'),$CONFIG->wwwroot."pg/groupprofile/listing");
		}
	}

	register_elgg_event_handler('init', 'system', 'vazco_groups_init');
?>