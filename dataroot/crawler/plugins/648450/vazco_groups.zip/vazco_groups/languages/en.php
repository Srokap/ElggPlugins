<?php
$english = array(
	//widgets
	'groupprofile:pages' => 'Pages',
	'vazco_widgets:nowidget' => 'No view for this widget exists',
	'groupprofile:pages:desc' => 'Displays latest group pages',
	'groupprofile:event_calendar' => 'Events',
	'groupprofile:event_calendar:desc' => 'Displays latest group events',
	'groupprofile:tag_cumulus' => 'Tag cumulus',
	'groupprofile:tag_cumulus:desc' => 'Displays tagclout of tags related with this group',
	'groupprofile:file' => 'Files',
	'groupprofile:file:desc' => 'Displays latest group files',
	'groupprofile:xgadgets' => 'XGadgets',
	'groupprofile:xgadgets:desc' => 'Displays google XGadgets, defined by group owner',
	'groupprofile:checklist' => 'Checklist',
	'groupprofile:checklist:desc' => 'Displays group\'s checklist',
	'groupprofile:tidypics' => 'Pictures',
	'groupprofile:tidypics:desc' => 'Displays group\'s pictures from tidypics plugin',
	'groupprofile:socialcommerce' => 'Products',
	'groupprofile:socialcommerce:desc' => 'Displays group\'s products from socialcommerce plugin',
	'groupprofile:kaltura' => 'Kaltura videos',
	'groupprofile:kaltura:desc' => 'Displays videos from kaltura plugin',
	'groupprofile:izapvid' => 'Izap videos',
	'groupprofile:izapvid:Desc' => 'Displays videos from izap_videos plugin',
	'groupprofile:discussion' => 'Latest discussions',
	'groupprofile:discussion:desc' => 'Displays latest discussions from group plugin\'s forum',
	'vazco_group:settings:custom' => 'Allow users to define custom layouts',
	'vazco_groups:layoutexample' => 'Preview:',
	'vazco_groups:memberlisting'	=> "Members list",
	"vazco_group:last_action"		=> "Last login",
	'vazco_groups:noblogs' => 'This group has no blogs yet',
	'vazco_groups:blogs' => 'Group blogs',
	'vazco_groups:blogs:desc' => 'Displays group blogs',


	//widget translations
	'custom:tagcloud:title' => 'Tags',
	'vazco_groups:warning:plugin_not_enabled' => 'Tag cumulus plugin is not enabled',
	'vazco_groups:notags' => 'This group has no associated tags',
	'vazco_groups:notenabled:elggdev' => 'You have to enable <a href="http://elggdev.com/%s">%s</a> plugin for this widget to be active.',
	'vazco_groups:notenabled' => 'You have to enable %s plugin for this widget to be active.',

	//general translations
	'vazco_groups:settings:widgetmember' => 'Number of entities to show on widgets',
	'vazco_groups:access:visibility' => 'For: ',
	'vazco_groups:access:all' => 'Everyone',
	'vazco_groups:access:members' => 'Members',
	'vazco_groups:access:owner' => 'Owner and admins',
	'settings:groupoptions' => 'Display options for group tools in group\'s edit form',
	'vazco_groups:pagetitle'	=> 'My Page Title',
	'vazco_groups:param_label'	=> 'My Parameter',
	'vazco_groups:success'	=> 'Your action was successful',
	'vazco_groups:failure'	=> 'Your action failed',
	'vazco_groups:pendinglisting' => 'Inactive layouts',
	'vazco_groups:userlistingpending' => 'Inactive layouts',
	'vazco_groups:layout:temp' => 'This screen displays layout\'s simplified view',
	'vazco_groups:next' => "Continue",
	'vazco_groups:layouteditor' => 'Layout',
	'vazco_groups:gallery' => 'Group widgets',
	'vazco_groups:general:title' => 'Layout editor',
	'vazco_groups:checkbox:default' => 'Set as default custom layout',
	'form_edit_vazco_groups:noreqfield' => 'You have to input all required fields',
	'vazco_groups:checkbox:active' => 'Active layout',
	'widgets:topcolumn' => 'Top column',	
	'vazco_groups:new' => 'New layout',
	'form_edit_vazco_groups:saved' => 'Layout saved succesfully',
	'vazco_groups:description' => 'Please place widgets on your layout by drag-and-droping them to the correct columns.',
	//these translations where set automatically, you might need to change them a bit:
	'vazco_groups:title'=>'Title', 
	'vazco_groups:image' => 'Layout\'s image (optional)',
	'vazco_groups:briefdescription'=>'Brief description', 
	'vazco_groups:tags'=>'Tags', 
	'vazco_groups:edit'=>'Edit layout',
	'vazco_groups_edit:noreqfield'=>'You have to fill in the required field: %s', 
	'vazco_groups_edit:notnumeric' => 'This field has to be numeric: %s',
	'vazco_groups_edit:saved' => 'Your  layout was successfully saved',
	'vazco_groups_edit:notsaved' => 'Your  layout couldn\'t be saved',
	'vazco_groups:error_nosuchentity' => 'There is no such entity',
	"vazco_groups:all" => 'All layouts',   //used in title in listing
	"vazco_groups:userlisting" => 'Your group layouts',   //used in title in userlisting
	'vazco_groups:delete_link' => "Delete this layout",//TODO probably you want to change plugin_name
	'vazco_groups:delete_response' => 'This layout has been deleted',//TODO probably you want to change plugin_name
	'vazco_groups:error_delete' => "This layout does not exist or you do not have the right to delete it",
	'vazco_groups:error_rights' => "This listing doesnt exist or you dont have rights to access it",
	'vazco_groups:error_nosuchentity' => "This site doesnt exist",
	'vazco_groups:active' => 'This layout is <b>active</b>',
	'vazco_groups:inactive' => 'This layout is <b>inactive</b>',
	'vazco_groups:default' => 'Default custom layout',
	'vazco_groups:custom_layout' => 'Custom',
	'vazco_groups:no_layout' => 'Choose layout',
	'vazco_groups:layout' => 'Layout',
	'vazco_groups:createcustomlayout' => 'Create custom layout',
	//%%plugin_name river%%
	'vazco_groups:river:created' => "%s added",
	'vazco_groups:river:edited' => "%s edited",
	'vazco_groups:edit' => "Edit layout",//TODO probably you want to change plugin_name
	'vazco_groups:view' => "View layout",//TODO probably you want to change plugin_name
	'vazco_groups:add' => "Add a new layout",//TODO probably you want to change plugin_name
	'vazco_groups:listing' => "All group layouts",//TODO probably you want to change plugin_name
	'settings:hideblocked' => 'Hide from admins widgets that are blocked (widget is blocked when plugin that is used for this widget is disabled). Blocked widgtes are always hidden for non-admin users.',

//all translations to this point where set automatically, you might need to change them a bit
    

        'vazco_groups:settings:widgetmemeber'   =>  'Number of users diplayed in the widget',
        'vazco_groups:group_members'            =>  "Group's members",
        'vazco_groups:group_members:desc'       =>  "Display a list or members",
        'vazco_groups:widget:listless'          =>  "Return to the limited list",
        'vazco_groups:widget:listmore'          =>  "Display all members",
        'vazco_groups:display_more'             =>  "See more",
        "vazco_groups:group_docs"                 =>  "Group's doc",
        "vazco_groups:group_docs:desc"          =>  "Display the latest docs owned by the group",
        "vazco_groups:group_bookmarks"          =>  "Bookmarks",
        "vazco_groups:group_bookmarks:desc"     =>  "Display the last bookmarks",
        "vazco_groups:nobookmarks"              =>  "No bookmarks",
        "vazco_groups:group_polls"              =>  "Latest polls",
        "vazco_groups:group_polls:desc"         =>  "Display the last polls",
        "vazco_groups:nopolls"                   => "No polls",
        "vazco_groups:invite"                   =>  "Invite a friend",
		"vazco_groups:admin"                   	=>  "Group administrator",
		"vazco_groups:mod"                   	=>  "Group moderator",
		"vazco_groups:member"                   =>  "Group member",
		"vazco_groups:owner"                   	=>  "Group owner",
		"vazco_group:isadmin"					=> 	"Portal administrator",
		"vazco_groups:invitefriend"				=>  "Invite",
		"vazco_groups:blog"						=>  "Blog",


);

add_translation("en",$english);
?>