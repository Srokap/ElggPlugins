<?php
$polish = array(
	//widgets
	'groupprofile:pages' => 'Dokumenty',
	'vazco_widgets:nowidget' => 'Brak informacji dla tego widgetu',
	'groupprofile:pages:desc' => 'Wyświetla najnowsze dokumenty grupy',
	'groupprofile:event_calendar' => 'Wydarzenia',
	'groupprofile:event_calendar:desc' => 'Wyświetla najnowsze wydarzenia grupy',
	'groupprofile:tag_cumulus' => 'Chmura tagów',
	'groupprofile:tag_cumulus:desc' => 'Wyświetla chmurę tagów grupy',
	'groupprofile:file' => 'Pliki',
	'groupprofile:file:desc' => 'Wyświetla najnowsze pliki grupy',
	'groupprofile:xgadgets' => 'XGadgets',
	'groupprofile:xgadgets:desc' => 'Displays google XGadgets, defined by group owner',
	'groupprofile:checklist' => 'Checklist',
	'groupprofile:checklist:desc' => 'Displays group\'s checklist',
	'groupprofile:tidypics' => 'Obrazy',
	'groupprofile:tidypics:desc' => 'Wyświetla najnowsze albumy grupy',
	'groupprofile:socialcommerce' => 'Produkty',
	'groupprofile:socialcommerce:desc' => 'Displays group\'s products from socialcommerce plugin',
	'groupprofile:kaltura' => 'Kaltura videos',
	'groupprofile:kaltura:desc' => 'Displays videos from kaltura plugin',
	'groupprofile:izapvid' => 'Filmy',
	'groupprofile:izapvid:Desc' => 'Wyświetla najnowsze filmy',
	'groupprofile:discussion' => 'Ostatnie dyskusje',
	'groupprofile:discussion:desc' => 'Wyświetla najnowsze wątki z forum grupy',
	'vazco_group:settings:custom' => 'Allow users to define custom layouts',
	'vazco_groups:layoutexample' => 'Podgląd:',
	'vazco_groups:memberlisting'	=> "Lista członków grupy",
	"vazco_group:last_action"		=> "Ostatnie logowanie",


	//widget translations
	'custom:tagcloud:title' => 'Tagi',
	'vazco_groups:warning:plugin_not_enabled' => 'Plugin chmury tagów jest wyłączony.',
	'vazco_groups:notags' => 'Z grupą nie powiązano jeszcze żadnych tagów',
	'vazco_groups:notenabled:elggdev' => 'You have to enable <a href="http://elggdev.com/%s">%s</a> plugin for this widget to be active.',
	'vazco_groups:notenabled' => 'You have to enable %s plugin for this widget to be active.',

	//general translations
	'vazco_groups:settings:widgetmember' => 'Number of entities to show on widgets',
	'vazco_groups:access:visibility' => 'Dla: ',
	'vazco_groups:access:all' => 'Wszyscy',
	'vazco_groups:access:members' => 'Członkowie grupy',
	'vazco_groups:access:owner' => 'Właściciel i administratorzy',
	'settings:groupoptions' => 'Display options for group tools in group\'s edit form',
	'vazco_groups:pagetitle'	=> 'My Page Title',
	'vazco_groups:param_label'	=> 'My Parameter',
	'vazco_groups:success'	=> 'Your action was successful',
	'vazco_groups:failure'	=> 'Your action failed',
	'vazco_groups:pendinglisting' => 'Inactive layouts',
	'vazco_groups:userlistingpending' => 'Inactive layouts',
	'vazco_groups:layout:temp' => 'This screen displays layout\'s simplified view',
	'vazco_groups:next' => "Continue",
	'vazco_groups:layouteditor' => 'Layout',
	'vazco_groups:gallery' => 'Group widgets',
	'vazco_groups:general:title' => 'Layout editor',
	'vazco_groups:checkbox:default' => 'Set as default custom layout',
	'form_edit_vazco_groups:noreqfield' => 'You have to input all required fields',
	'vazco_groups:checkbox:active' => 'Active layout',
	'widgets:topcolumn' => 'Top column',	
	'vazco_groups:new' => 'New layout',
	'form_edit_vazco_groups:saved' => 'Layout saved succesfully',
	'vazco_groups:description' => 'Please place widgets on your layout by drag-and-droping them to the correct columns.',
	//these translations where set automatically, you might need to change them a bit:
	'vazco_groups:title'=>'Title', 
	'vazco_groups:image' => 'Layout\'s image (optional)',
	'vazco_groups:briefdescription'=>'Brief description', 
	'vazco_groups:tags'=>'Tags', 
	'vazco_groups:edit'=>'Edit layout',
	'vazco_groups_edit:noreqfield'=>'You have to fill in the required field: %s', 
	'vazco_groups_edit:notnumeric' => 'This field has to be numeric: %s',
	'vazco_groups_edit:saved' => 'Your  layout was successfully saved',
	'vazco_groups_edit:notsaved' => 'Your  layout couldn\'t be saved',
	'vazco_groups:error_nosuchentity' => 'There is no such entity',
	"vazco_groups:all" => 'All layouts',   //used in title in listing
	"vazco_groups:userlisting" => 'Your group layouts',   //used in title in userlisting
	'vazco_groups:delete_link' => "Delete this layout",//TODO probably you want to change plugin_name
	'vazco_groups:delete_response' => 'This layout has been deleted',//TODO probably you want to change plugin_name
	'vazco_groups:error_delete' => "This layout does not exist or you do not have the right to delete it",
	'vazco_groups:error_rights' => "This listing doesnt exist or you dont have rights to access it",
	'vazco_groups:error_nosuchentity' => "This site doesnt exist",
	'vazco_groups:active' => 'This layout is <b>active</b>',
	'vazco_groups:inactive' => 'This layout is <b>inactive</b>',
	'vazco_groups:default' => 'Default custom layout',
	'vazco_groups:custom_layout' => 'Custom',
	'vazco_groups:no_layout' => 'Choose layout',
	'vazco_groups:layout' => 'Layout',
	'vazco_groups:createcustomlayout' => 'Create custom layout',
	//%%plugin_name river%%
	'vazco_groups:river:created' => "%s added",
	'vazco_groups:river:edited' => "%s edited",
	'vazco_groups:edit' => "Edit layout",//TODO probably you want to change plugin_name
	'vazco_groups:view' => "View layout",//TODO probably you want to change plugin_name
	'vazco_groups:add' => "Add a new layout",//TODO probably you want to change plugin_name
	'vazco_groups:listing' => "All group layouts",//TODO probably you want to change plugin_name
	'settings:hideblocked' => 'Hide from admins widgets that are blocked (widget is blocked when plugin that is used for this widget is disabled). Blocked widgtes are always hidden for non-admin users.',

//all translations to this point where set automatically, you might need to change them a bit
    

        'vazco_groups:settings:widgetmemeber'   =>  'Liczba użytkowników wyświetlana w widgecie',
        'vazco_groups:group_members'            =>  "Członkowie grupy",
        'vazco_groups:group_members:desc'       =>  "Wyświetla listę członków grupy",
        'vazco_groups:widget:listless'          =>  "Powróć do listy",
        'vazco_groups:widget:listmore'          =>  "Wyświetl listę wszystkich członków grupy",
        'vazco_groups:display_more'             =>  "Zobacz więcej",
        "vazco_groups:group_docs"                 =>  "Dokumenty grupy",
        "vazco_groups:group_docs:desc"          =>  "Wyświetla najnowsze dokumenty grupy",
        "vazco_groups:group_bookmarks"          =>  "Zakładki",
        "vazco_groups:group_bookmarks:desc"     =>  "Wyświetla najnowsze zakładki",
        "vazco_groups:nobookmarks"              =>  "Grupa nie ma jeszcze zakładek",
        "vazco_groups:group_polls"              =>  "Najnowsze ankiety",
        "vazco_groups:group_polls:desc"         =>  "Wyświetla najnowsze ankiety",
        "vazco_groups:nopolls"                   => "Grupa nie ma jeszcze ankiet",
        "vazco_groups:invite"                   =>  "Zaproś znajomego",
		"vazco_groups:admin"                   	=>  "Administrator grupy",
		"vazco_groups:mod"                   	=>  "Moderator grupy",
		"vazco_groups:member"                   =>  "Członek grupy",
		"vazco_groups:owner"                   	=>  "Właściciel grupy",
		"vazco_group:isadmin"					=> 	"Administrator portalu",
		"vazco_groups:invitefriend"				=>  "Zaproś",
		"vazco_groups:blog"						=>  "Blog",
	

);

add_translation("pl",$polish);
?>