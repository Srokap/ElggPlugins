Once installed this plugin performs two actions:

   1. It lets the group owner invite *any* member of the social network
      to a group.
   2. It add an option to the group settings (disabled by default) to let any
      group member send new invitations to other users.