***********************************
**PLEASE READ BEFORE INSTALLATION**
***********************************

1. To install this plugin you must go to ww2.toksta.com and register for an account
2. Next create your IM system
3. Download it for Elgg and read the instructions as to how to install it

***********************************
*************END*******************
***********************************