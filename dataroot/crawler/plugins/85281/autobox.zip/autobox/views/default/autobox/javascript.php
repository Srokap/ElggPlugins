<?php
	
		/**
	 * Autobox Friendly autocomplete for tags.
	 * 
	 * @package autobox
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Pedro Prez
	 * @copyright 2009
	 * @link http://www.pedroprez.com.ar/
 	*/
?>
	<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/autobox/vendors/jquery.templating.js"></script>
	<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/autobox/vendors/jquery.ui.autobox.js"></script>
	<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/autobox/vendors/jquery.ui.autobox.ext.js"></script>