<?php

if (elgg_is_logged_in()) forward('activity');

$network = elgg_get_plugin_setting('network1', 'velletri'); 
$about = elgg_get_plugin_setting('about1', 'velletri'); 

?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
		<link rel="stylesheet" type="text/css" href="mod/velletri/style/style.css" /> 
		<link rel="stylesheet" type="text/css" href="mod/velletri/style/scrollpath.css" /> 
		<link href="http://fonts.googleapis.com/css?family=Terminal+Dosis&subset=latin" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="mod/velletri/script/prefixfree.min.js"></script>
		<meta name="description" content="The plugin that lets you define custom scroll paths" /> 
		<title>My Network</title>
		<script type="text/javascript">
		  var _gaq = _gaq || [];
		  _gaq.push(['_setAccount', 'UA-25206568-1']);
		  _gaq.push(['_trackPageview']);

		  (function() {
		    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
		  })();
		</script>
	</head>
	<body>
	<?php 

echo elgg_view('page/elements/messages', array('object' => $_SESSION['msg']));
unset($_SESSION['msg']);

?>
		<ul class="navigation">
			<li><a href="#start">Welcome!</a></li>
			<li><a href="#login">Login</a></li>
			<li><a href="#register">Register</a></li>
			<li><a href="#about">About</a></li>

		</ul>
		<div class="settings">
			<a href="http://www.swsocialweb.com/shop" class="show-path">SW Social Web</a>
		</div>
		<div class="wrapper">
			<div class="demo">
				<h1>
				<?php 
				
					if ($network == null)
					{
				?>
				My Network!
				
				
				<?php
				 }
				else
				
				echo $network;
				
				?>
				</h1>
				<span class="arrow">&darr;</span> Welcome <span class="arrow">&darr;</span>
			</div>
			
			<div class="login">
				<span class="big">

<?php
								$form_body = "<p><label>" . elgg_echo('username') . "<br />" . elgg_view('input/text', array('internalname' => 'username', 'class' => 'login-textarea')) . "</label><br />";
								$form_body .= "<label>" . elgg_echo('password') . "<br />" . elgg_view('input/password', array('internalname' => 'password', 'class' => 'login-textarea')) . "</label><br />";
								$form_body .= elgg_view('input/submit', array('value' => elgg_echo('login'))) . "</p>";
								

								echo elgg_view('input/form', array('body' => $form_body, 'action' => "". $vars['url'] ."action/login"));

					  ?>


</span>
			</div>

			<div class="register">
				<span class="big"><?php
								
								$form_body  = "<p><label>" . elgg_echo('name') . "<br />" . elgg_view('input/text' , array('internalname' => 'name', 'class' => "general-textarea", 'value' => $name)) . "</label><br />";
								$form_body .= "<label>" . elgg_echo('email') . "<br />" . elgg_view('input/text' , array('internalname' => 'email', 'class' => "general-textarea", 'value' => $email)) . "</label><br />";
								$form_body .= "<label>" . elgg_echo('username') . "<br />" . elgg_view('input/text' , array('internalname' => 'username', 'class' => "general-textarea", 'value' => $username)) . "</label><br />";
								$form_body .= "<label>" . elgg_echo('password') . "<br />" . elgg_view('input/password' , array('internalname' => 'password', 'class' => "general-textarea")) . "</label><br />";
								$form_body .= "<label>" . elgg_echo('passwordagain') . "<br />" . elgg_view('input/password' , array('internalname' => 'password2', 'class' => "general-textarea")) . "</label><br /><br />";
								$form_body .= elgg_view('register/extend');
								$form_body .= elgg_view('input/captcha');
								if ($admin_option) {
									$form_body .= elgg_view('input/checkboxes', array('internalname' => "admin", 'options' => array(elgg_echo('admin_option'))));
								}
								$form_body .= elgg_view('input/hidden', array('internalname' => 'friend_guid', 'value' => $vars['friend_guid']));
								$form_body .= elgg_view('input/hidden', array('internalname' => 'invitecode', 'value' => $vars['invitecode']));
								$form_body .= elgg_view('input/hidden', array('internalname' => 'action', 'value' => 'register'));
								$form_body .= elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('register'))) . "</p>";
								?>
								
								<h2>
								<?php
								//echo elgg_echo('register');
								?>
								</h2>
								<?php
								// REGISTER FORM
								echo elgg_view
								(
									'input/form'
									,array
									(
										'body' => $form_body
										,'action' => "{$vars['url']}action/register"
									)
								);
								?></span>
			</div>

			<div class="about">
				<span class="big">
				<?php 
				
					if ($about == null)
					{
				?>
				Lorem Ipsum Seclorum.
				<?php
				 }
				else
				
				echo $about;
				
				?>
				</span>
			</div>

			

			

		</div>
	<script type="text/javascript" src="http://code.jquery.com/jquery-latest.pack.js"></script>
	<script type="text/javascript" src="http://gsgd.co.uk/sandbox/jquery/easing/jquery.easing.1.3.js"></script>
	<script type="text/javascript" src="mod/velletri/script/min.jquery.scrollpath.js"></script>
	<script type="text/javascript" src="mod/velletri/script/demo.js"></script>
	</body>
</html>