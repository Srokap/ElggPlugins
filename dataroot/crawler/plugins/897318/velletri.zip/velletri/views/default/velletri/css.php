<?php
/* 
 * Satheesh PM, BARC Mumbai
 * www.satheesh.anushaktinagar.net
 */

?>
/* ***************************************
	Ads
*****************************************/

#site_messages{
text-align : justify;
overflow: hidden;
border-top : 1px solid  #DEDEDE;
min-height:45px;
padding : 5px ;

}


