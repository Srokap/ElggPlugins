<?php

	/**
	* Elgg contact plugin
	* This plugin allows to send message to custom email you specify at module configuration area
	* 
	* @package ElggContact
	* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	* @author Curverider Ltd <info@elgg.com>
	* @author Tim Timalsina <info@timalsina.com>
	* @copyright Curverider Ltd 2008
	* @copyright TIMALSINA 2008
	* @link http://elgg.com/
	*/
		
		$spanish = array(
		
		/*
	    * Enconding guide
	    * Ã¡ a
	    * Ã© e
	    * Ã­ i
	    * Ã³ o
	    * Ãº u
	    * Ã± 
	    * Â¿ À
	    */
	
		/**
		* Plugin button, menu title, page title, default email
		*/
	
			'contact:plugin:name' => "Contacto",
			'contact:page:title' => "ContÃ³ctanos",			
			'contact:button:send' => "EnvÃ­a Mensaje",
			'contact:default:email' => "DirecciÃ³n de emil por defecto",
			
		/**
		* Input Form elements
		*/
			
			'contact:level:name' => "Tu Nombre",	
			'contact:level:email' => "DirecciÃ³n e-mail",
			'contact:level:subject' => "Asunto",
			'contact:level:message' => "Mensaje",	
			
		/**
		* Plugin action feedback
		*/
	
			'contact:send:successful' => "Tu mensaje se envÃ­o con Ã©xito. Nos comunicaremos contigo en las prÃ³ximas 24 horas. Gracias.",
			'contact:send:unsuccessful' => "Tu mensaje no pudo ser enviado. AsegÃºrate que todos los campos estan llenos.",
			'contact:name:invalid' => "Nombre invÃ³lido. Nombres solo pueden contener letras, nÃºmeros y guiones. Por favor trata con un nombre vÃ³lido.",
			'contact:email:invalid' => "Haz ingresado una direcciÃ³n de correo invÃ³lida. Por favor trata con una direcciÃ³n de e-mail vÃ³lida.",			
			'contact:message:invalid' => "Los mensajes no pueden tener caracteres invÃ³lidos. Por favor escribe tu mensaje en texto plano. Trata de nuevo con un mensaje vÃ³lido.",
			
	
	);
					
	add_translation("es",$spanish);

?>