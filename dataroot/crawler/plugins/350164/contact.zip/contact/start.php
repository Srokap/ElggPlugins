<?php

	/**
	 * Elgg contact plugin
	 * This plugin allows to send message to custom email you specify at module configuration area
	 * 
	 * @package ElggContact
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @author Tim Timalsina <info@timalsina.com>
	 * @copyright Curverider Ltd 2008
	 * @copyright TIMALSINA 2008
	 * @link http://elgg.com/
	 */
	 
	 global $CONFIG;
	 
	 
	//$DEFAULT_EMAIL_ADDRESS = 'email@domain.tld';
		
	 
	// Load the language file
		register_translations($CONFIG->pluginspath . "contact/languages/");
	
	// Register a page handler, so we can have nice URLs
		register_page_handler('contact','contact_page_handler');
	
	// Page handler
		function contact_page_handler($page) {
			global $CONFIG;
			include($CONFIG->pluginspath . "contact/index.php");
		}
		
	// Load menu if desired
		$toolsmenu = get_plugin_setting('toolsmenu', 'contact');
		
		if ($toolsmenu == "yes"){
			add_menu(elgg_echo('contact:plugin:name'),$CONFIG->wwwroot."pg/contact");
		}
	// Register action
	register_action('contact/send',false,$CONFIG->pluginspath . "contact/actions/send.php");
	
?>
