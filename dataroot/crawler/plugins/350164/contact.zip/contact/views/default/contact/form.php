<?php

	/**
	 * Elgg contact plugin
	 * This plugin allows to send message to site administrator
	 * 
	 * @package ElggContact
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @author Tim Timalsina <info@timalsina.com>
	 * @copyright Curverider Ltd 2008
	 * @copyright TIMALSINA 2008
	 * @link http://elgg.com/
	 */ 

	 
	 if(isloggedin()) {
	 	$name = ($_SESSION['user']->name);
	 	$email = ($_SESSION['user']->email);
	 	$message = get_input('m');
		$subject = get_input('s');
	 } else {
	  	$name = get_input('n');
		$email = get_input('e');
		$message = get_input('m');
		$subject = get_input('s');
	 }
	 
	 $contact_subjects_list = get_plugin_setting('contact_subjects', 'contact');
	 $contact_subjects = explode(",", $contact_subjects_list);
	 
	 $form_body = "<p><label>" . elgg_echo('contact:level:name') . "<br />" . elgg_view('input/text' , array('internalname' => 'name', 'class' => "general-textarea", 'value' => $name)) . "</label><br />";
	
	 $form_body .= "<label>" . elgg_echo('contact:level:email') . "<br />" . elgg_view('input/text' , array('internalname' => 'email', 'class' => "general-textarea", 'value' => $email)) . "</label><br />";
	
	  $form_body .= "<label>" . elgg_echo('contact:level:subject') . "<br />" .elgg_view('input/pulldown' , array('internalname' => "subject", 'options_values' =>$contact_subjects, 'value'=>$subject)) . "</label><br />";
	  
	//loads textarea type based on user setting
	 $htmlemail = get_plugin_setting('htmlemail', 'contact');
	 
	if ($htmlemail == "html"){
		$form_body .= "<label>" . elgg_echo('contact:level:message') . "<br />" . elgg_view('input/longtext' , array('internalname' => 'message', 'class' => "general-textarea", 'value' => $message)) . "</label><br />";
		}
	else {
	 	$form_body .= "<label>" . elgg_echo('contact:level:message') . "<br /> <textarea name='message' 'class='general-textarea' value='" . $message . "' style='width:98%; height:200px;'/></textarea> </label><br />";
	 	}
	//end textarea
	 	
	//loads captcha type based on user setting
	 $contactcaptcha = get_plugin_setting('contactcaptcha', 'contact');
	 
	 if ($contactcaptcha == "yes"){
		 $form_body .= elgg_view('input/captcha');
	 }
	//end captcha
	 
	 $form_body .= elgg_view('input/hidden', array('internalname' => 'action', 'value' => 'contact/send'));
	
	 $form_body .= elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('contact:button:send'))) . "</p>";
	 
?>
<?php echo elgg_view('input/form', array('action' => "{$vars['url']}action/contact/send", 'body' => $form_body)) ?>