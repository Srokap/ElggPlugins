<?php

	/**
	 * Elgg contact plugin
	 * This plugin allows to send message to custom email you specify at module configuration area
	 * 
	 * @package ElggContact
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @author Tim Timalsina <info@timalsina.com>
	 * @copyright Curverider Ltd 2008
	 * @copyright TIMALSINA 2008
	 * @link http://elgg.com/
	 */
	
	$DEFAULT_EMAIL_ADDRESS = "mail@domain.tld"; // Change this value at module configuration interface
	$default_subjects = "Feedback, Bug Report, Press, General";
?>	 
<p>
	<?php echo elgg_echo('contact:default:email'); ?><br />
	<?php
		$mailto = ($vars['entity']->contactemail ? $vars['entity']->contactemail : $DEFAULT_EMAIL_ADDRESS);
		echo elgg_view('input/text', array('internalname' => 'params[contactemail]', 'value' => $mailto));
	?>
</p>
<p>
	<?php echo elgg_echo('contact:setting:captcha'); ?><br />
	<select name="params[contactcaptcha]">
		<option value="yes" <?php if ($vars['entity']->contactcaptcha == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->contactcaptcha != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>

</p>
<p>
	<?php echo elgg_echo('contact:setting:htmlemail'); ?><br />
	<select name="params[htmlemail]">
		<option value="html" <?php if ($vars['entity']->htmlemail == 'html') echo " selected=\"yes\" "; ?>>HTML</option>
		<option value="plaintext" <?php if ($vars['entity']->htmlemail != 'html') echo " selected=\"yes\" "; ?>>Plaintext</option>
	</select>

</p>
<p>
	<?php echo elgg_echo('contact:setting:toolsmenu'); ?><br />
	<select name="params[toolsmenu]">
		<option value="yes" <?php if ($vars['entity']->toolsmenu == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->toolsmenu != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>

</p>
<p>
	<?php echo elgg_echo('contact:setting:subjects'); ?><br />
	<?php 
		$contact_subjects = ($vars['entity']->contact_subjects ? $vars['entity']->contact_subjects : $default_subjects);
		echo elgg_view('input/text', array('internalname' => 'params[contact_subjects]', 'value' => $contact_subjects));
    ?>
</p>