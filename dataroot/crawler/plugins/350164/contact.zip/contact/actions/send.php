<?php

	/**
	 * Elgg contact plugin
	 * This plugin allows to send message to custom email you specify at module configuration area
	 * 
	 * @package ElggContact
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @author Tim Timalsina <info@timalsina.com>
	 * @copyright Curverider Ltd 2008
	 * @copyright TIMALSINA 2008
	 * @link http://elgg.com/
	 */
	 
	 // Initialize action action_gatekeeper();
	 	action_gatekeeper();

		 
	// Get variables
		$name = get_input('name');
		$email = get_input('email');
		$subject_number = get_input('subject');		
		$message = get_input('message');		
		$mailto = get_plugin_setting('contactemail', 'contact');
		$token = get_input('captcha_token');
		$input = get_input('captcha_input');
	
	// get readable subject from array data
	 	$contact_subjects_list = get_plugin_setting('contact_subjects', 'contact');
	 	$contact_subjects = explode(",", $contact_subjects_list);
	 	$subject = $contact_subjects[$subject_number];
		
	// captcha verification
		$contactcaptcha = get_plugin_setting('contactcaptcha', 'contact');
		if ($contactcaptcha == "yes"){
			if ( !$token || !captcha_verify_captcha($input, $token) ) {
						register_error(elgg_echo("captcha:captchafail"));	
						$retry = explode('?',$_SERVER['HTTP_REFERER']);
	  					$retry = $retry[0];
		
	  					$retry .= "?n=" . urlencode($name) . "&e=" . urlencode($email) . "&m=" . urlencode($message) . "&s=" . urlencode($subject_number);

	  					forward($retry);
			}
		}
	//send email as html if desired
		$htmlemail = get_plugin_setting('htmlemail', 'contact');
	 	
		if ($htmlemail == "html"){
		$headers = "MIME-Version: 1.0" . "\r\n";
		$headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
		}
		$headers .= "From: $name<$email>";
	
	// Name cleanup
		function name_cleanup($name) {
			return ereg_replace("[^a-zA-Z0-9_.,;:]", "", $name);
    	}
		
	// Send message	
		if (ctype_print($name)) {	
	  		if (is_email_address($email)) {
	  			if ($message!="") {	  				
	  				if ( ($mailto!="") && ($name!="") && ($email!=""))  {
						mail($mailto,$subject,$message,$headers);
						system_message(elgg_echo("contact:send:successful"));			
						//if(isloggedin()) forward($_SESSION['user']->getURL()); 			
						forward('pg/contact/');
					} else {
						register_error(elgg_echo("contact:send:unsuccessful"));			
						$retry = explode('?',$_SERVER['HTTP_REFERER']);
	  					$retry = $retry[0];
		
	  					$retry .= "?n=" . urlencode($name) . "&e=" . urlencode($email) . "&m=" . urlencode($message) . "&s=" . urlencode($subject_number);

	  					forward($retry);
					}
				} else {
					register_error(elgg_echo("contact:message:invalid"));			
					$retry = explode('?',$_SERVER['HTTP_REFERER']);
	  				$retry = $retry[0];
		
	  				$retry .= "?n=" . urlencode($name) . "&e=" . urlencode($email) . "&m=" . urlencode($message);

	  				forward($retry);	  				
	  			}	  			
	  			
	  		} else {
	  			register_error(elgg_echo("contact:email:invalid"));	
	  			$retry = explode('?',$_SERVER['HTTP_REFERER']);
	  			$retry = $retry[0];
		
	  			$retry .= "?n=" . urlencode($name) . "&e=" . urlencode($email) . "&m=" . urlencode($message);

	  			forward($retry);
			}
		} else {
	  		register_error(elgg_echo("contact:name:invalid"));			
			$retry = explode('?',$_SERVER['HTTP_REFERER']);
	  		$retry = $retry[0];
		
	  		$retry .= "?n=" . urlencode($name) . "&e=" . urlencode($email) . "&m=" . urlencode($message);

	  		forward($retry);
		}	
?>