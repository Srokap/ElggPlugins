<ul class="topbardropdownmenu">
    <li class="drop">
    <a style="cursor:pointer"><?php echo(elgg_echo('basic-link-plugin:Links'));?></a>
	  <ul>
      <?php
	  	$DataLink  = $vars['config']->site->basiclink;
		$ArrayLinks = explode("\n", $DataLink);
		foreach($ArrayLinks as $item) {
			$pos1 = strpos($item, ',');
			$LinkName = substr($item, 0, $pos1);
			$LinkURL = substr($item, $pos1+1);
			if (!strpos($LinkURL, '://')) $LinkURL = "http://".$LinkURL;
			echo "<li><a href=\"$LinkURL\" target=\"_blank\">" . $LinkName . "</a></li>";
		} 
	  ?>
      </ul>
    </li>
</ul>

<script type="text/javascript">
  $(function() {
    $('ul.topbardropdownmenu').elgg_topbardropdownmenu();
  });
</script>
