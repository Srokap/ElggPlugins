<?php

	echo elgg_view_title(elgg_echo('basic-link-plugin:settings'));

?>

	<div class="contentWrapper">
		<p>
			<?php echo elgg_echo('basic-link-plugin:explanation'); ?>
		</p>
	

<?php

	echo elgg_view(
						'input/form',
						array(
							'action' => $vars['url'] . 'action/basiclink/save',
							'method' => 'post',
							'body' => elgg_view('basic-link-plugin/settingsform',$vars)
						)
					);

?>

</div>