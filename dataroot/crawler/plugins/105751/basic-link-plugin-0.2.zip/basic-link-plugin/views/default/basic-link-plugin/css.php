<?php
	/**
	 * Categories CSS extender
	 * 
	 * @package Elgg File Repository
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */
?>

ul.topbardropdownmenu ul {
	width: 150px;
	top: 24px;
	border-top:1px solid black;
}
