<?php

	echo elgg_view('input/longtext',array('value' => $vars['basiclink'],
									  'internalname' => 'basiclink'));

?>
	<input type="submit" value="<?php echo elgg_echo('save'); ?>" />