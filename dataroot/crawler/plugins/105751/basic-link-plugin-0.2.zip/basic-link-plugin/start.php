<?php
	/**
	 * Elgg customspotlight plugin
	 * This plugin substitutes the spotlight with a custom one
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Chris Hide
	 */
	function blp_init() {
		if (isloggedin()) {
			global $CONFIG;
			register_translations($CONFIG->pluginspath . "basic-link-plugin/languages/");
			extend_view('css', 'basic-link-plugin/css');
			extend_view('elgg_topbar/extend', 'basic-link-plugin/topbar');
			register_action('basiclink/save',false,$CONFIG->pluginspath . 'basic-link-plugin/actions/save.php',true);
		}
	}
	/**
	 * Set up menu items
	 *
	 */
		function blp_pagesetup()
		{
			if (get_context() == 'admin' && isadminloggedin()) {
				global $CONFIG;
				add_submenu_item(elgg_echo('basic-link-plugin:settings'), $CONFIG->wwwroot . 'mod/basic-link-plugin/settings.php');
			}
		}
		
	register_elgg_event_handler('init', 'system', 'blp_init');
	register_elgg_event_handler('pagesetup','system','blp_pagesetup');
?>
