<?php
	$spanish = array(
		'basic-link-plugin:settings' => "Enlaces externos",
		'basic-link-plugin:explanation' => "A&ntilde;ade aqui tus enlaces externos<br>Para cada enlace, escribe \"Nombre del enlace,Direcci&oacute;n del enlace\".<br>Cada enlace debe ir en una linea diferente.<br> Ejemplo:<br> &nbsp;&nbsp;&nbsp;Terra,http://www.terra.es<br>&nbsp;&nbsp;&nbsp;Google,www.google.es",
		'basic-link-plugin:save:success' => "Guardado",
		'basic-link-plugin:Links'		=> "Enlaces externos",
	);
					
	add_translation("es",$spanish);

?>
