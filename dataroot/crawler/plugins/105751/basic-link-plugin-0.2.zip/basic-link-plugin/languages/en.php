<?php
	$english = array(
		'basic-link-plugin:settings' => "External links",
		'basic-link-plugin:explanation' => "Write here your external links<br>Write each link in separate lines, type \"Link name,Link URL\".<br>Example:<br> &nbsp;&nbsp;&nbsp;Yahoo,http://www.yahoo.com<br>&nbsp;&nbsp;&nbsp;Google,www.google.com",
		'basic-link-plugin:save:success' => "Saved",
		'basic-link-plugin:Links'		=> "External links",
	);
					
	add_translation("en",$english);

?>
