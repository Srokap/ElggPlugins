/* IE6 */
* html #front_left_tbl { width:676px !important; }
* html #front_right_tbl { width:676px !important; }

#elgg_horizontal_tabbed_nav li.selected, #elgg_horizontal_tabbed_nav .selected a { background: white; color: #4690d6; font-weight:bold;  }
#elgg_horizontal_tabbed_nav li { background: #eeeeee; color: #4690d6; }
#elgg_horizontal_tabbed_nav li form input { background: transparent; font-weight:bold; height:14px; }

