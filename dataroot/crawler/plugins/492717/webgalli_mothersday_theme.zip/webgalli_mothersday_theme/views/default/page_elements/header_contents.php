<?php

	/**
	 * Mothers day theme for Elgg
	 * @package: Mothers day theme for Elgg
	 * @license: GPLV2
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com
	 */
	 
?>

<div id="page_container">
<div id="page_wrapper">

<div id="layout_header">
<div id="wrapper_header">
	<!-- display the page title -->
<img src="<?php echo $vars['url']; ?>mod/webgalli_mothersday_theme/graphics/top-mothers.png" border="0" />
</div><!-- /#wrapper_header -->
</div><!-- /#layout_header -->