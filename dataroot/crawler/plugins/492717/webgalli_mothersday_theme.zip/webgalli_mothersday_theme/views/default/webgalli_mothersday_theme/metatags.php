		<!--<?php echo $vars['config']->sitename; ?> is proudly powered by Elgg and the Theme is designed by Team Webgalli.
 		If you are looking for any custom works with Elgg, or any hosting service for elgg, drop us a mail at webgalli@gmail.com 
 		or visit us at www.webgalli.com. We will be there 24*7*365 for you.-->
        