<?php
/**
 * Source: http://paulirish.com/2009/cornify-easter-egg-with-jquery/
 *
 * Javascript keycodes: http://www.geekpedia.com/KB53_A-list-of-keys-and-the-JavaScript-char-codes-they-correspond-to.html
 *
 * Code: e l g g [up arrow]
 */
?>
<script type="text/javascript">
jQuery(function($){
	var kkeys = [], cornify_code = "69,76,71,71,38";
	$(document).keydown(function(e) {
		kkeys.push( e.keyCode );
		if ( kkeys.toString().indexOf( cornify_code ) >= 0 ){
			$(document).unbind('keydown',arguments.callee);
			$.getScript('http://www.cornify.com/js/cornify.js',function(){
				cornify_add();
				$(document).keydown(cornify_add);
			});
		}
	});
});
</script>
