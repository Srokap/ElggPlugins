<?php

/**
 * Cornify Plugin for Elgg
 *
 * Default: type the characters: e, l, g, g, [up arrow]
 *
 * To change the code, see the metatags view
 */

function cornify_init() {
	extend_view('metatags', 'cornify/metatags');
}

register_elgg_event_handler('init', 'system', 'cornify_init');