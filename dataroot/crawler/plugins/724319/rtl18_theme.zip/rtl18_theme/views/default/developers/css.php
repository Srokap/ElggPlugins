<?php
/**
 * Admin CSS for Elgg Developers plugin
 */
?>
/*** Elgg Developer Tools ***/
#developers-iframe {
	width: 100%;
	height: 600px;
	border: none;
}
#developer-settings-form label {
	margin-right: 0;margin-left: 5px;
}
