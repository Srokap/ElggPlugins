<?php

function rtl18_theme_init() {
}

elgg_register_event_handler('init', 'system', 'rtl18_theme_init');
?>