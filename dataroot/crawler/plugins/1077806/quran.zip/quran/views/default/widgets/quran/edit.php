<?php
/**
 *	Elgg - Holy Quran plugin
 *	Author : Mohammed Aqeel | Team Webgalli
 *	Team Webgalli | Elgg developers and consultants
 *	Mail : info@webgalli.com
 *	Web	: http://webgalli.com | http://plugingalaxy.com
 *	Skype : 'team.webgalli'
 *	@package Elgg -Holy Quran
 *	Licence : GNU2
 *	Copyright : Team Webgalli 2011-2015
 */
 
 $translations = get_installed_Quran_translations(); 
?>
	<p>
		<?php echo elgg_echo("quran:selecttranslation"); ?>
		<select name="params[quran_translation]">
		<?php 
			foreach ($translations as $translation) { 
				echo "<option value='{$translation}'>{$translation}</option>";
			} 
		?>
		</select>
		<br />
		<?php echo elgg_echo("quran:showaudio"); ?>
		<select name="params[show_audio]">
		<option value="yes"><?php echo elgg_echo("quran:yes"); ?></option>
		<option value="no"><?php echo elgg_echo("quran:no"); ?></option>
		</select>
	</p>