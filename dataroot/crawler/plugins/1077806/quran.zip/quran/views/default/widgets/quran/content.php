<?php
/**
 *	Elgg - Holy Quran plugin
 *	Author : Mohammed Aqeel | Team Webgalli
 *	Team Webgalli | Elgg developers and consultants
 *	Mail : info@webgalli.com
 *	Web	: http://webgalli.com | http://plugingalaxy.com
 *	Skype : 'team.webgalli'
 *	@package Elgg -Holy Quran
 *	Licence : GNU2
 *	Copyright : Team Webgalli 2011-2015
 */
 
 
$translation = $vars['entity']->quran_translation;
$audio_option = $vars['entity']->show_audio;
if ($audio_option != 'no'){
	$audio = true;
	}
echo get_Quran_verse(false, $translation, $audio);
?>