<?php
/**
 *	Elgg - Holy Quran plugin
 *	Author : Mohammed Aqeel | Team Webgalli
 *	Team Webgalli | Elgg developers and consultants
 *	Mail : info@webgalli.com
 *	Web	: http://webgalli.com | http://plugingalaxy.com
 *	Skype : 'team.webgalli'
 *	@package Elgg -Holy Quran
 *	Licence : GNU2
 *	Copyright : Team Webgalli 2011-2015
 */
 
 
	$translations = get_installed_Quran_translations(); 
	$default_quran_translation = $vars['entity']->default_quran_translation;
	$show_ayah_on_home = $vars['entity']->show_ayah_on_home;

?>

<?php
echo elgg_view_module('inline',  elgg_echo("quran:title"), get_Quran_verse(1, $default_quran_translation, true)); 

$content  = "<p>";
$content .=	elgg_echo('quran:default_translation'); 
$content .=	elgg_view('input/dropdown', array(
			'name' => 'params[default_quran_translation]',
			'options_values' => $translations,
			'value' => $default_quran_translation
		));
$content .= "</p><p>";
$content .= elgg_echo('quran:showonhome');
$content .= elgg_view('input/dropdown', array(
			'name' => 'params[show_ayah_on_home]',
			'options_values' => array(
								'no' => elgg_echo('option:no'),
								'yes' => elgg_echo('option:yes')
								),
			'value' => $show_ayah_on_home
		));
$content .= "</p>";

echo elgg_view_module('inline', elgg_echo("settings"),$content); ?>
<p>Documentation / Help / Questions ? : Visit plugin <a href="http://www.webgalli.com/blog/random-specific-daily-quran-ayah-plugins-for-elgg-and-wordpress/">home page</a> </p>
