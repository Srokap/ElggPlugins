<?php 
/**
 *	Elgg - Holy Quran plugin
 *	Author : Mohammed Aqeel | Team Webgalli
 *	Team Webgalli | Elgg developers and consultants
 *	Mail : info@webgalli.com
 *	Web	: http://webgalli.com | http://plugingalaxy.com
 *	Skype : 'team.webgalli'
 *	@package Elgg -Holy Quran
 *	Licence : GNU2
 *	Copyright : Team Webgalli 2011-2015
 */
elgg_load_js('elgg.zaudio');
$swf_url = elgg_get_site_url() . 'mod/quran/audioplayer/player.swf';
 
if($mp3_url = $vars['source']){ 
	?>
	<div style="margin:5px 0 10px 5px;">
	<script type="text/javascript">
		AudioPlayer.setup("<?php echo $swf_url; ?>", {width: 280});
	</script>
	<div class="zaudio">
		<p id="zaudioplayer"></p>
		<script type="text/javascript">
			AudioPlayer.embed("zaudioplayer", {soundFile: "<?php echo $mp3_url; ?>"});
		</script>
	</div>
	</div> 
<?php } ?>