<?php
/**
 *	Elgg - Holy Quran plugin
 *	Author : Mohammed Aqeel | Team Webgalli
 *	Team Webgalli | Elgg developers and consultants
 *	Mail : info@webgalli.com
 *	Web	: http://webgalli.com | http://plugingalaxy.com
 *	Skype : 'team.webgalli'
 *	@package Elgg -Holy Quran
 *	Licence : GNU2
 *	Copyright : Team Webgalli 2011-2015
 */
 
$ayah = get_Quran_verse(false, false, true);
echo elgg_view_module('featured',  elgg_echo("quran:title"), $ayah);	