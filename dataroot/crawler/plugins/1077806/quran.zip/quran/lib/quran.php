<?php
/**
 *	Elgg - Holy Quran plugin
 *	Author : Mohammed Aqeel | Team Webgalli
 *	Team Webgalli | Elgg developers and consultants
 *	Mail : info@webgalli.com
 *	Web	: http://webgalli.com
 *	Skype : 'team.webgalli'
 *	@package Elgg - Holy Quran
 *	Licence : GNU2
 *	Copyright : Team Webgalli 2011-2015
 */
 
 
function get_Quran_verse($ayah_line = false , $translation = false , $show_audio = true) {
	if (!$ayah_line){
		$num = rand(1,6236);
	} else {
		$num = (int) $ayah_line;
	}
	$num = $num - 1;
	if (!$translation){
		$translation = elgg_get_plugin_setting('default_quran_translation','quran');
	}
	$directory = elgg_get_plugins_path()."quran/vendors/";  
	$translation_directory = $directory."translations/"; 
	$quotefile = "quran-simple.txt";
	$translation_quotefile = $translation.".txt";
	$quotes = file($directory.$quotefile);
	$translation_quotes = file($translation_directory.$translation_quotefile);
	$quote = $quotes[$num];
	$translation_quote = $translation_quotes[$num];
	$explode_quote = explode("|",$quote);
	$surah = str_pad((int) $explode_quote[0],3,"0",STR_PAD_LEFT);
	$ayah = str_pad((int) $explode_quote[1],3,"0",STR_PAD_LEFT);
	$page = elgg_echo('quran:holyQuran',array($explode_quote[0],$explode_quote[1]));
	$verse = "<div id='holyQuran_arabic'>".$explode_quote[2]."</div>";
	$translation_verse = "<div id='holyQuran_translation'>".$translation_quote."</div>";
	$line_break = "</br>";
	$html = $page.$line_break.$verse.$translation_verse.$line_break;
	if ($show_audio){
		$mp3 = "http://www.everyayah.com/data/Menshawi_32kbps/".$surah.$ayah.".mp3";
		$html .= elgg_view("quran/player",array("source" => $mp3));
	}
	return $html;
}

function get_installed_Quran_translations(){
	$translation_directory = elgg_get_plugins_path()."quran/vendors/translations/"; 
    $path = realpath($translation_directory); 
	$translations = array();
	if($dir_handle = @opendir($path)){
		while (false !== ($file = readdir($dir_handle))){
			if ($file != "." && $file != ".." && strtolower(substr($file, strrpos($file, '.') + 1)) == 'txt'){
				$filename = explode('.txt',$file);
				$new_filename = $filename[0];
				$translations[$new_filename] = $new_filename;
			}
		}
		closedir($dir_handle);
	}	
	return $translations;
}

?>