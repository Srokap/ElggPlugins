<?php
/**
 *	Elgg - Holy Quran plugin
 *	Author : Mohammed Aqeel | Team Webgalli
 *	Team Webgalli | Elgg developers and consultants
 *	Mail : info@webgalli.com
 *	Web	: http://webgalli.com | http://plugingalaxy.com
 *	Skype : 'team.webgalli'
 *	@package Elgg -Holy Quran
 *	Licence : GNU2
 *	Copyright : Team Webgalli 2011-2015
 */
 
 

$english = array(

	'quran:title' => 'Quran Ayah',
	'quran:info' =>  'Display random Quran ayahs',
	'quran:yes' =>  'Yes',
	'quran:no' =>  'No',
	'quran:selecttranslation' =>  'Select a translation you want',
	'quran:showaudio' =>  'Show the audio player',
	'quran:holyQuran' => 'From Holy Quran (%s : %s)<br/>',
	'quran:default_translation' => 'Default Quran translation',
	'quran:showonhome' => 'Show a widget on site home page?',
);
					
add_translation("en", $english);
