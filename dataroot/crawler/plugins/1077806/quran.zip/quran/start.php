<?php
/**
 *	Elgg - Holy Quran plugin
 *	Author : Mohammed Aqeel | Team Webgalli
 *	Team Webgalli | Elgg developers and consultants
 *	Mail : info@webgalli.com
 *	Web	: http://webgalli.com | http://plugingalaxy.com
 *	Skype : 'team.webgalli'
 *	@package Elgg -Holy Quran
 *	Licence : GNU2
 *	Copyright : Team Webgalli 2011-2015
 */
 

function quran_init() {
	$base = elgg_get_plugins_path() . 'quran';
	elgg_register_library('holyQuran', "$base/lib/quran.php");
	elgg_load_library('holyQuran');
	add_widget_type('quran', elgg_echo('quran:title'), elgg_echo('quran:info'));
	if (elgg_get_plugin_setting('show_ayah_on_home', 'quran') == 'yes') {
		elgg_extend_view('index/righthandside', 'quran/Quran_widget_home');
	}
	if (!elgg_is_active_plugin('zaudio')){
		$js_url = elgg_get_site_url() . 'mod/quran/audioplayer/audio-player.js';
		elgg_register_js('elgg.zaudio', $js_url);
	}
	elgg_extend_view('css', 'quran/css');
}

register_elgg_event_handler('init', 'system', 'quran_init');

?>