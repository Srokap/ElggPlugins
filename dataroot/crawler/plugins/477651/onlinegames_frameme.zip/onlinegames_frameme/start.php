<?php


	function onlinegames_frameme_init() 
	{
		extend_view('css', 'onlinegames/css');
		add_menu(elgg_echo('onlinegames_frameme:onlinegames'), $CONFIG->wwwroot . "mod/onlinegames_frameme/onlinegames.php");
		register_page_handler('onlinegames_frameme','onlinegames_frameme_page_handler');
		
	}


	function onlinegames_frameme_page_handler($page) 
	{
		
		if ($page[0])
		{
			switch ($page[0])
			{
				case "onlinegames":
					include(dirname(__FILE__) . "/onlinegames.php");
					break;
				default: 
					break;
			}
		}
	}
        // Show in Menu
        if (isloggedin()) {
            add_menu(elgg_echo('Online Games'), $CONFIG->wwwroot."mod/onlinegames_frameme/onlinegames.php");
        }  
	register_elgg_event_handler('init','system','onlinegames_frameme_plugin_init');
?>