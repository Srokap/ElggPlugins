<?php
	/**
	 * @file automatic_doc_for_doxygen.php
	 * @brief Provides some information for doxygen
	 */

	/**
	 * @mainpage tab_navigator
	 * 
	 * Provides a tab navigator view using the tabber javascript plugin
	 * <br />
	 * <br />
	 * 
	 * <b>Author: </b>José Gomes; email: juniordesiron@gmail.com
	 * <br />
	 * <b>Elgg Version: </b>1.7.3
	 * <br />
	 * <b>Published: </b>16/10/2010
	 * <br />
	 * <b>Last update: </b>16/10/2010
	 * <br />
	 * <b>Functionality: </b><br />
	 * (version 1.00)<br />
	 * 1 - Provides a tab navigator view using the tabber javascript plugin.<br />
	 * 2 - Provides one example of how to use the tab navigator view.<br />
	 * <br />
	 */
?>