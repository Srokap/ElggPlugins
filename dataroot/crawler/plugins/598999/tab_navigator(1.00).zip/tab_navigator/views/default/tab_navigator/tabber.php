<?php 
	/**
	 * @file views/default/tab_navigator/tabber.php
	 * @brief Elgg view for tabber javascript plugin
	 */
?>

<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/tab_navigator/vendors/tabber/tabber.js"></script>

<link rel="stylesheet" href="<?php echo $vars['url']; ?>mod/tab_navigator/vendors/tabber/example.css" TYPE="text/css" MEDIA="screen">
<link rel="stylesheet" href="<?php echo $vars['url']; ?>mod/tab_navigator/vendors/tabber/example-print.css" TYPE="text/css" MEDIA="print">

<script type="text/javascript">

	/* Optional: Temporarily hide the "tabber" class so it does not "flash"
	   on the page as plain HTML. After tabber runs, the class is changed
	   to "tabberlive" and it will appear.
	   */
	document.write('<style type="text/css">.tabber{display:none;}<\/style>');
</script>

<div class="tabber">
	<?php
		// The tabs that will be displayed must to be into $vars['tab']
		if(isset($vars['tabs']))
		{
			foreach($vars['tabs'] as $title=>$body)
			{
	?>
				<div class="tabbertab">
					<h2><?php echo $title; ?></h2>
					<p><?php echo $body; ?></p>
				</div>
	<?php
			}
		}
	?>
</div>
