<?php
	/**
	 * @file start.php
	 * @brief Starts the tab_navigator plugin on elgg system
	 */

	/**
	 * Set the tab_navigator basic configs on elgg system
	 */
	function tab_navigator_init()
	{
		global $CONFIG;
		
		register_translations($CONFIG->pluginspath.'tab_navigator/languages',true);
		
		register_page_handler('tab_navigator','tab_navigator_page_handler');
	}
	
	/**
	 * Insert the tab_navigator submenu links on elgg system
	 */
	function tab_navigator_pagesetup()
	{
		if(get_context() == 'admin' && isadminloggedin())
		{
			global $CONFIG;

			add_submenu_item(sprintf(elgg_echo('tab_navigator:tabber_example'),1),$CONFIG->wwwroot.'pg/tab_navigator/tabber/1','tab_navigator');
			add_submenu_item(elgg_echo('tab_navigator:doc'),$CONFIG->wwwroot.'mod/tab_navigator/doc/index.html','tab_navigator');
		}
	}
	
	/**
	 * Handle the tab navigator pages
	 * 
	 * @param $page
	 */
	function tab_navigator_page_handler($page)
	{
		if(isset($page[0]))
		{
			global $CONFIG;
			
			switch($page[0])
			{
				case 'tabber':
					switch($page[1])
					{	
						default:
							include($CONFIG->pluginspath.'tab_navigator/tabber/example1.php');
							break;
					}
					
					break;
			}
		}
	}
	
	register_elgg_event_handler('init','system','tab_navigator_init');
	register_elgg_event_handler('pagesetup','system','tab_navigator_pagesetup');
?>