<?php
	/**
	 * @file languages/en.php
	 * @brief Insert the english translation for tab_navigator on elgg system
	 */

	$english = array(
		'tab_navigator:doc'=>'Tab navigator doc',
		'tab_navigator:tabber_example'=>'Tabber example %d',
		'tab_navigator:tabber_home'=>'Tabber home page',
		);
		
	add_translation('en',$english);
?>