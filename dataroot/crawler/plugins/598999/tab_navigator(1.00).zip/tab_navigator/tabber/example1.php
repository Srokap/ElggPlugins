<?php
	/**
	 * @file tabber/example1.php
	 * @brief Displays the example 1 for tabber javascript plugin
	 */

	admin_gatekeeper();
	set_context('admin');
	
	$title = sprintf(elgg_echo('tab_navigator:tabber_example',1));
	$area2 = '';
	
	$area2 .= '<h1>'.sprintf(elgg_echo('tab_navigator:tabber_example'),1).'</h1>';
	$area2 .= '<p>&larr; <a href="http://www.barelyfitz.com/projects/tabber/">'.elgg_echo('tab_navigator:tabber_home').'</a></p>';
	
	$tabs = array(
		'Tab 1'=>'Tab 1 body html',
		'Tab 2'=>'Tab 2 body html',
		'Tab 3'=>'Tab 3 body html',
		'Tab 4'=>'Tab 4 body html',
		);
	$area2 .= elgg_view('tab_navigator/tabber',array('tabs'=>$tabs));
	
	$page_body = elgg_view_layout('two_column_left_sidebar',$area1,$area2);
	
	page_draw($title,$page_body);
?>