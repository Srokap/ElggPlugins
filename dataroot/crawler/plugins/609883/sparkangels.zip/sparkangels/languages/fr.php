<?php

	$english = array(
	
		/**
		 * sparkangels widget details
		 */
		
	
		'sparkangels:widgetid' => '(id) dans la page <a href="http://www.spark-angels.com/rss2/visibility/services/show_preferences">G&eacute;rer mes pr&eacute;f&eacute;rences</a> :',
		'sparkangels:widgettype' => 'Type d&rsquot;apparence :',
		'sparkangels:widgettitle' => 'Titre du module:',
		'sparkangels:saurl' => 'Site SparkAngels',
		'sparkangels:wempty' => 'Cet id n\'existe pas!',
		
		 /**
	     * sparkangels widget 
	     **/
	        
	        //generic terms to use
	        'sparkangels:river:created' => "%s added the sparkangels widget.",
	        'sparkangels:river:updated' => "%s updated their sparkangels widget.",
	        'sparkangels:river:delete' => "%s removed their sparkangels widget.",
	        
		
	);
					
	add_translation("fr",$french);

?>