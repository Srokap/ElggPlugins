<?php

	$english = array(
	
		/**
		 * sparkangels widget details
		 */
		
	
		'sparkangels:widgetid' => '(id) in the <a href="http://www.spark-angels.com/rss2/visibility/services/show_preferences">G&eacute;rer mes pr&eacute;f&eacute;rences</a> page:',
		'sparkangels:widgettype' => 'Skin type :',
		'sparkangels:widgettitle' => 'Module title:',
		'sparkangels:saurl' => 'SparkAngels website',
		'sparkangels:wempty' => 'Unknown id !',
		
		
		 /**
	     * sparkangels widget 
	     **/
	        
	        //generic terms to use
	        'sparkangels:river:created' => "%s added the sparkangels widget.",
	        'sparkangels:river:updated' => "%s updated their sparkangels widget.",
	        'sparkangels:river:delete' => "%s removed their sparkangels widget.",
	        
		
	);
		
	add_translation("en",$english);

?>