<?php

	/**
	 * Elgg SparkAngels Widget support
	 * This plugin allows users to display their sparkangels widget on their profile
	 * 
	 * @package ElggSparkAngels
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Alexandre MANSOUR SPARKOM 
	 * @copyright Sparkom  2006-2010
	 * @link http://www.spark-angels.com
	 */
	
		function sparkangels_init() {
    		
    		//extend css if style is required
    		//extend_view('css','sparkangels/css');
    		
    		//add a widget
			//add_widget_type('widgettitle',$name_of_widget,$desc_of_widget)
			//   add_widget_type ($handler, $name, $description, $context="all", $multiple=false, $positions="side,main") 
			    add_widget_type("sparkangels","Instant Coaching","Configuration of your SparkAngels widget", "all", "side");
			
		}
		
		register_elgg_event_handler('init','system','sparkangels_init');

?>