<?php

    /**
	 * Elgg twitter edit page
	 *
	 * @package ElggSparkAngels
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Sparkom
	 * @copyright Sparkom  2005-2010
	 * @link http://www.spark-angels.com/
	 */

?>
	<p>
		<div style="width:100%; text-align:center; boeder:2px solid red;"><img src="<?php echo $vars['url']; ?>mod/sparkangels/graphics/sa-logo.png" alt=""/></div> <br />
		<?php echo elgg_echo("sparkangels:widgetid"); ?>
		<div style="width:100%; text-align:center;">
			<input width= "10" type="text" name="params[sparkangels_widgetid]" value="<?php echo htmlentities($vars['entity']->sparkangels_widgetid); ?>" />	
		</div>
		<br />
		<?php echo elgg_echo("sparkangels:widgettitle"); ?>
		<input type="text" name="params[sparkangels_widgettitle]" value="<?php echo htmlentities($vars['entity']->sparkangels_widgettitle); ?>" />	
		<br />
		<?php echo elgg_echo("sparkangels:widgettype"); ?>
		<select name="params[sparkangels_widgettype]">
			<option value="std" selected="true">widget 172x123</option>
			<option value="dimg" >widget 65x65</option>
			<!--<option value="imgl" >widget image link(img)</option>
			<option value="link" >widget link(link)</option> -->
		</select>
		<br />
	</p>