<?php
    
     /**
	 * Elgg sparkangels widget
	 *
	 * @package ElggSparkangels
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Alexandre MANSOUR SPARKOM www.spark-angels.com>
	 * @copyright SPARKOM 2006-2010 www.spark-angels.com
	 * @link http://www.spark-angels.com/
	 */
	 
	 //some required params
	 
	$widgetId = $vars['entity']->sparkangels_widgetid;
	$widgetType = isset ($vars['entity']->sparkangels_widgettype) ? $vars['entity']->sparkangels_widgettype : "std";
	$widgetTitle = $vars['entity']->sparkangels_widgettitle;
	$widgetLauchTarget ='_blank';
    // if the sparkangels widgetid is empty, then do not show
    if($widgetId){
?>
	<div id="sparkangels_widget-<?php echo $widgetId; ?>-<?php echo $widgetType; ?>" style="width:100%; text-align:center;">
	<div style="padding-bottom:5px;font-weight:bold;color:#39A22B; font-size:1.25em; line-height:1.2em;"><?php echo $widgetTitle; ?></div>
	<?php if ($widgetType == 'std'){ ?> <iframe src='http://www.spark-angels.com/static/widget/template-pro3/widgetpro3-iframe.html?widgetId=<?php echo $widgetId; ?>&lgCode=fr' width='172px' height='123px' frameborder='0' scrolling='no' marginheight='0' > </iframe>
	<?php } elseif ($widgetType == 'dimg'){ ?>
		<div id="div-sparkwidget-<?php echo $widgetId; ?>"></div>
		<script type="text/javascript" src="http://www.spark-angels.com/static/widget/dimg/dimg.js"></script>
		<script type="text/javascript">var spkWidget = new SparkWidgetImgDispo("div-sparkwidget-<?php echo $widgetId; ?>", <?php echo $widgetId; ?>); spkWidget.wTarget = '<?php echo $widgetLauchTarget; ?>'; spkWidget.render();</script>
	<?php } ?>
	</div>
<?php 
    } else {
      echo "<div class=\"contentWrapper\"><p>" . elgg_echo("sparkangels:wempty") . ".</p></div>";
  }
?>
