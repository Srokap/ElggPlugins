<?php

	/**
	 * Elgg profile plugin
	 * 
	 * @package ElggProfile
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Michal Zacher
	 */

	//extend the CSS class
	function vazco_profileup_init() {
			extend_view('css','vazco_profile_up/css',1);
	}
	
	register_elgg_event_handler('init','system','vazco_profileup_init',1000);

?>