<?php

	/**
	 * Elgg Profile menu
	 * 
	 * @package Profile
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Michal Zacher
	 */
	 
?>

.usericon div.sub_menu {
	z-index:999;
}

div.usericon a.icon img{
	display:block;
}