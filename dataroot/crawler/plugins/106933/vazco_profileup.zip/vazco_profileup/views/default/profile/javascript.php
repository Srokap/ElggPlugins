<?php

	/**
	 * Elgg profile image Javascript
	 * 
	 * @package ElggProfile
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 * 
	 * @uses $vars['entity'] The user entity
	 */

		header("Content-type: text/javascript");
		header("Pragma: public");
		header("Cache-Control: public");

?>
var submenuLayer_before = 10;
var submenuLayer = 1000;
var menuVisible = true;
function setup_avatar_menu() {

	// avatar image menu link
	$("div.usericon img").mouseover(function() {
		// find nested avatar_menu_button and show
		$(".sub_menu").css("display", "none");		
		$(this.parentNode.parentNode).children("[class=sub_menu]").show();
		$(this.parentNode.parentNode).css("z-index", submenuLayer);
		menuVisible = true;
	})
	.mouseout(function() { 
		if($(this).parent().parent().find("div.sub_menu").css('display')!="block") {
			$(this.parentNode.parentNode).children("[class=sub_menu]").hide();
			menuVisible = false;
		}
		else {
			$(this.parentNode.parentNode).children("[class=sub_menu]").show();
		}
	});

	// hide avatar menu if click or mouseout occurs outside of menu
	// and hide arrow button						
	$(document).mouseover(function(event) {
			var target = $(event.target);
			if (menuVisible && target.parents(".usericon").length == 0) {				
				$(".usericon").css("z-index", submenuLayer_before);
				$(".sub_menu").hide();
				menuVisible = false;
			}
	});
}

$(document).ready(function() {
	setup_avatar_menu();
});
