<?php
/**
*
* @author Diego Andrés Ramírez Aragón <diego@somosmas.org>
* @copyright Corporación Somos más - 2008
*/

$spanish = array(
  'grouplayout:completeprofileconfig'=>'¿Habilitar el manejo del perfil completo?',
  'grouplayout:completeprofile'=>'Perfil completo',
);

add_translation("es_CO",$spanish);

?>