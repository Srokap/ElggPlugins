<?php
/**
*
* @author Diego Andrés Ramírez Aragón <diego@somosmas.org>
* @copyright Corporación Somos más - 2008
*/

$english = array(
  'grouplayout:completeprofileconfig'=>'Enable complete profile handling?',
  'grouplayout:completeprofile'=>'Complete profile',
);

add_translation("en",$english);

?>