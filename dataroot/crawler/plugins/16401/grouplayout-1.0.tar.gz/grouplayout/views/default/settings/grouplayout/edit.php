<?php
/**
 * Elgg groupextended plugin configuration options
 *
 * @package ElggGroupExtended
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Diego Andrés Ramírez Aragón <diego@somosmas.org>
 * @copyright Corporación Somos más - 2008
 * @link http://www.somosmas.org
 */
?>

<p>
	<?php echo elgg_echo('grouplayout:completeprofileconfig'); ?>

	<select name="params[completeprofile]">
		<option value="yes" <?php if ($vars['entity']->completeprofile == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->completeprofile != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>

</p>