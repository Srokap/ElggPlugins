<?php
/**
 * Elgg groupextended plugin group as profile layout 
 * 
 * It try to mimic the profile layout for reorganize the group profile information
 * 
 * @package ElggGroupExtended
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Diego Andrés Ramírez Aragón <diego@somosmas.org>
 * @copyright Corporación Somos más - 2008
 * @link http://www.somosmas.org
 */

?>
<table cellspacing="0" id="widget_table" width="100%">
  <tr>
    <td colspan="2" align="left" valign="top" height="1px">
		<?php if (isset($vars['area1'])) echo $vars['area1']; ?>
	</td>
  </tr>
  <tr>
	<td align="left" valign="top" width="290px">

		<!-- left widgets -->
		<div id="group_widgets_left">
		<?php if (isset($vars['area2'])) echo $vars['area2']; ?>
		</div><!-- /#widgets_left -->

	</td>
	<td align="left" valign="top">

		<!-- widgets middle -->
		<div id="widgets_middle">
		<?php if (isset($vars['area3'])) echo $vars['area3']; ?>
		</div><!-- /#widgets_middle -->

	</td>
	</tr>
</table>
