Groups layout plugin
=======================

This plugins overwrite the default group layout for mimic the profile layout.

Install
-------

- Drop it on your mod directory and then go to the admin panel and activate it. 
- Overwrite groups/grouprofile.php with the file with the same name provided with this plugin.
- Activate it from the admin panel.

Take on mind that this plugins overwrites some groups plugins behaviors so it need 
to be loaded after it.
