<?php
/**
 *
 * @author Diego Andrés Ramírez Aragón
 * @copyright Corporación Somos más - 2008
 */
function grouplayout_init(){
  extend_view('css','grouplayout/css');
  register_page_handler('groupcomplete','grouplayout_page_handler');
}

/**
 * Group layout profile handler
 *
 * @param mixed $page
 */
function grouplayout_page_handler($page){
  global $CONFIG;

  if(isset($page[0])){
    set_context("group");
    set_input('group_guid', $page[0]);
    include($CONFIG->pluginspath . "grouplayout/groupprofilecomplete.php");
  }
}

/**
 * Group layout page setup
 *
 */
function grouplayout_pagesetup(){
  global $CONFIG;
  $page_owner = page_owner_entity();
  if($page_owner instanceof ElggGroup && get_context()=="groups"){
    if(get_plugin_setting("completeprofile","grouplayout")=="yes"){
      add_submenu_item(elgg_echo('grouplayout:completeprofile'),$CONFIG->wwwroot."pg/groupcomplete/" . $page_owner->getGUID(), '0groupsactions');
    }
  }
}

register_elgg_event_handler('init','system','grouplayout_init');
register_elgg_event_handler('pagesetup','system','grouplayout_pagesetup');
?>