<?php
/**
 * Elgg groupextended group profile view
 *
 * This view reorganize the way the group profile view elements are called. It overwrites the default layout used for this view
 *
 * @package ElggGroupExtended
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Diego Andrés Ramírez Aragón <diego@somosmas.org>
 * @copyright Corporación Somos más - 2008
 * @link http://www.somosmas.org
 */

$group_guid = get_input('group_guid');
set_context('groups');


$group = get_entity($group_guid);

set_page_owner($group_guid);

$complete = !(get_plugin_setting("completeprofile","grouplayout")=="yes");

//$area2 = elgg_view_title($group->name);
$area1 .= elgg_view('group/group', array('entity' => $group, 'user' => $_SESSION['user'], 'full' => true,'complete'=>$complete));

//group members
$area2 = elgg_view('groups/members',array('entity' => $group));

//group profile 'items' - these are not real widgets, just contents to display
$area3 .= elgg_view('groups/profileitems',array('entity' => $group));

//$body = elgg_view_layout('two_column_left_sidebar', $area1, $area2, $area3);
$body = elgg_view_layout('group_as_profile_layout', $area1, $area2, $area3);

// Finally draw the page
page_draw($group->name, $body);
?>