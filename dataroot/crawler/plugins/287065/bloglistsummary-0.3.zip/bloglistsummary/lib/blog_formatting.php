<?php


// SOURCE
// http://marketingtechblog.com/programming/php-cut-your-excerpt-off-at-the-word-using-strrpos/
// searches for space

function cutToLastFullWord($content)
{
  $pos = strrpos($content, " ");
  if ($pos>0) {
      $content = substr($content, 0, $pos);
  }
  return $content;
}


// Strip all tags from blog
// If necessary shorten to $characters length
// If shortened add link to blog

function getStartOfBlog($blogtext, $characters, $linktext, $linkurl) {
	// just use php function to strip all tags for this
	$filteredblogtext =  strip_tags($blogtext); // autop(parse_urls(filter_tags($blogtext)));
	if (strlen($filteredblogtext) > ($characters) )
	{
		$filteredblogtext = cutToLastFullWord(substr($filteredblogtext,0, $characters));
		$filteredblogtext = $filteredblogtext . " <a href=\"" . $linkurl . "\">" . $linktext . "</a>"; 
	}
	return $filteredblogtext;
}


function cleanBlogHTML($blogtext) {

	// SOURCE:
	// http://tim.mackey.ie/CleanWordHTMLUsingRegularExpressions.aspx

		$blogtext = $blogtext . "\n"; // just to make things a little easier, pad the end
		//$blogtext = preg_replace('|<br />\s*<br />|', "\n\n", $blogtext);
		// Space things out a little
		$allblocks = '(?:font|span|del|ins)';
		$blogtext = preg_replace('!(<' . $allblocks . '[^>]*>)!', "\n$1", $blogtext);
		$blogtext = preg_replace('!(</' . $allblocks . '>)!', "$1\n\n", $blogtext);
		
		//$reg = "<([^>]*)(class|lang|style|size|face)=(\"[^\"]*\"|'[^']*'|[^>]+)([^>]*)>";
		// simple bit for float left & right
		//$blogtext = str_replace("style=\"align:left;",
		
		// ok leave the style in because of the img problem
		//$blogtext = preg_replace('#style="[^"]*"#i', "", $blogtext); 
		$blogtext = preg_replace('#class="[^"]*"#i', "", $blogtext); 
		$blogtext = preg_replace('#id="[^"]*"#i', "", $blogtext); 		
		return $blogtext;

}



?>