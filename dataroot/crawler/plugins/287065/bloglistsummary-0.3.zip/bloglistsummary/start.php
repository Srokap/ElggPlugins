<?php
/*******************************************************************************
 * bloglistsummary
 *
 * @author admin
 ******************************************************************************/

	function bloglistsummary_init()
	{
		//global $CONFIG;

		//extend_view('css','bloglistsummary/css');










		
		
		return true;
	}






	
	register_elgg_event_handler('init', 'system', 'bloglistsummary_init');
?>