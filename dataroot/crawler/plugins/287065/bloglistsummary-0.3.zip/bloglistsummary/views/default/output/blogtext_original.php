<?php

	/**
	 * Elgg display long text
	 * Displays a large amount of text, with new lines converted to line breaks
	 * 
	 * @package Elgg
	 * @subpackage Core

	 * @author Curverider Ltd

	 * @link http://elgg.org/
	 * 
	 * @uses $vars['text'] The text to display
	 * 
	 */

    require_once(dirname(dirname(dirname(dirname(__FILE__)))).'/lib/blog_formatting.php');
	global $CONFIG;

   // echo "<div class=\"blogtext_original\">" . cleanHTML($vars['value']) . "</div>";
    //echo "<div id=\"blogtext_original\">" . cleanBlogHTML($vars['value']) . "</div>";
	echo "<div id=\"blogtext_original\">" . ($vars['value']) . "</div>";
	    //echo parse_urls(filter_tags($vars['value'])) ;
?>