<?php
/*
 * Css for bloglistsummary
 */
?>
P#blogtext_original {margin: 1.12em 0;}

#blogtext_original  {
vertical-align: baseline;
	font-family: inherit;
	font-weight: inherit;
	font-style: inherit;
	font-size: 100%;
	outline: 0;
	padding: 0;
	margin: 0;
	border: 0;
}

#blogtext_original P {margin: 1.12em 0; 

	font: 13px/19px "Lucida Grande","Lucida Sans Unicode",Tahoma,Verdana,sans-serif;
	padding: 0.6em;
	margin: 0;


}