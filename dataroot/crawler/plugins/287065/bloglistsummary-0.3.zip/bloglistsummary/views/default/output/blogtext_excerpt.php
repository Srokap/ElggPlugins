<?php

	/**
	 * Elgg display long text
	 * Displays a large amount of text, with new lines converted to line breaks
	 * 
	 * @package Elgg
	 * @subpackage Core

	 * @author Curverider Ltd

	 * @link http://elgg.org/
	 * 
	 * @uses $vars['text'] The text to display
	 * 
	 */

    require_once(dirname(dirname(dirname(dirname(__FILE__)))).'/lib/blog_formatting.php');
	global $CONFIG;
	
	// length of summary text in characters
	$characters = 350;
	// text to click on to go to full article
	$linktext = "... (more)";


// getStartOfBlog(Text of Blog, No of characters length, URL to full blog, Text for "...")

	echo "<div id=\"blogtext_excerpt\">";
	echo getStartOfBlog($vars['value'], $characters, $linktext, $vars['urllink']);
	echo "</div>";
	
?>