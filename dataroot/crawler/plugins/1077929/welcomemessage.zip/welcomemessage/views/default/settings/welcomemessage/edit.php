<p>
<?php 
/**
 * @package :Welcome Message
 * @name : Zander
 * @ url:http://community.elgg.org/profile/Zander1983
 * @licnnce : GPL V2
 */

//$insert_view = elgg_view('facebooksettings/extend');




$welcome_subject = elgg_echo('welcomemessage:subject');
$welcome_subject_view = elgg_view('input/text', array(
	'name' => 'params[welcome_subject]',
	'value' => $vars['entity']->welcome_subject,
	'class' => 'text_input',
));

$welcome_content = elgg_echo('welcomemessage:content');
$welcome_content_view = elgg_view('input/longtext', array(
	'name' => 'params[welcome_content]',
	'value' => $vars['entity']->welcome_content,
	'class' => 'text_input',
));

$vars['entity']->welcome_time = time();

$hidden_time = elgg_view('input/hidden',array('name'=>'params[welcome_time]','value'=>$vars['entity']->welcome_time));


$settings = <<<__HTML

<div>$welcome_subject $welcome_subject_view</div>
<div>$welcome_content $welcome_content_view</div>
    $hidden_time

__HTML;

echo $settings;
