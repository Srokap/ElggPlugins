<?php




$plugin = elgg_get_plugin_from_id('welcomemessage');

$plugin->welcome_time = time();
