<?php

	/**
	* Welcome Message
	*
	* @author Mark Kelly
	* @link http://community.elgg.org/profile/Zander1983
	* @copyright (c) Web Intelligence
	* @link http://www.webintelligence.ie
	* @license GNU General Public License (GPL) version 2
	*/

	
	function welcomemessage_init() {
		
		elgg_register_event_handler('login', 'user', 'welcomemessage_clear_user_meta');
	}

	

        
function set_user_first_login($user_id){
    $site = elgg_get_site_entity();
    if(!check_entity_relationship($site->getGUID(), 'first_log_in', $user_id)){
        add_entity_relationship($site->getGUID(), 'first_log_in', $user_id);
    }
}  

function check_user_first_login($user_id){
    $site = elgg_get_site_entity();
    if(check_entity_relationship($site->getGUID(), 'first_log_in', $user_id)){
        return true;
    }
    else{
        return false;
    }
    
}


	/**
	 * This function checks if its first time log in, sets site notifications to true and sends a welcome message
	 * @param String $event
	 * @param String $object_type
	 * @param Object $object
	 */
function welcomemessage_clear_user_meta($event, $object_type, $object) {
	
        if($event == 'login' && $object_type=='user' && $object instanceof ElggUser) {

            $time = elgg_get_plugin_setting('welcome_time','welcomemessage');
            if ($object->time_created > $time) {            

                if (!check_user_first_login($object->getGUID()))
                {

                        global $NOTIFICATION_HANDLERS;
                        foreach($NOTIFICATION_HANDLERS as $method => $foo) {
                                $personal[$method] = 1;

                            set_user_notification_setting($object->getGUID(), $method, ($personal[$method] == '1') ? true : false);
                                
                        }	
 
                       
                    
                        $admins = elgg_get_admins(array(
                                        'order_by' => 'e.time_created asc'
                        )); 
                        
                        //if admins found, send message from the first one returned
                        if(count($admins)>0){
                            //get the first administrator and send from that account
                            $from = $admins[0];
                      
                            $subject = elgg_get_plugin_setting('welcome_subject', 'welcomemessage');
                            $body = elgg_get_plugin_setting('welcome_content', 'welcomemessage');                        

                            //if admin has filled out subject and content
                            if(!empty($body) and !empty($subject)){
                                notify_user($object->getGUID(),
                                                        $from->guid,
                                                        $subject,
                                                        $body
                                                        );  

                            }
                        }
                        
                       set_user_first_login($object->getGUID());
                       
                  }

                }
        }     
    }
    
   	

	
	// Initialise setNoNotification Mod
	elgg_register_event_handler('init','system','welcomemessage_init');
