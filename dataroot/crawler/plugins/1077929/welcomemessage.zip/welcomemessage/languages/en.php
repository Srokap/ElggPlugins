<?php
	$english = array(
		'welcomemessage:subject' => 'Welcome Message Subject',
            	'welcomemessage:content' => 'Welcome Message Content',
                
	);
	
	add_translation("en",$english);