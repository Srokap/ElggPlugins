<?php

	$spanish = array(

		/**
		 * Sites
		 */
	
			'item:site' => 'Sitios',
	
		/**
		 * Sessions
		 */
			
			'login' => "Acceder",
			'loginok' => "Has iniciado sesión.",
			'loginerror' => "Error en el inicio de sesión. Esto podría deberse a que todavía no has validado tu cuenta, o la información de acceso que has proporcionado es incorrecta. Asegúrate de que los datos son correctos e inténtalo de nuevo.",
	
			'logout' => "Finalizar",
			'logoutok' => "Has finalizado la sesión.",
			'logouterror' => "Error al finalizar sesión. Inténtalo de nuevo por favor.",
	
		/**
		 * Errors
		 */
			'exception:title' => "Bienvenido a Elgg.",
	
			'InstallationException:CantCreateSite' => "Imposible crear un ElggSite por defecto con las credenciales Nombre:%s, Url: %s",
		
			'actionundefined' => "La acción solicitada (%s) no está definida en el sistema.",
			'actionloggedout' => "Lo sentimos, no puedes realizar esta acción sin haber iniciado sesión.",
	
			'notfound' => "El recurso solicitado no ha podido ser encontrado, o no tienes acceso a él.",
			
			'SecurityException:Codeblock' => "Acceso denegado para ejecutar el bloque de código privilegiado",
			'DatabaseException:WrongCredentials' => "Elgg no ha podido conectar con la base de datos usando la credenciales proporcionadas %s@%s (contraseña: %s).",
			'DatabaseException:NoConnect' => "Elgg no ha podido seleccionar la base de datos '%s', comprueba que está creada y tienes acceso a ella.",
			'SecurityException:FunctionDenied' => "El acceso a la función privilegiada '%s' ha sido denegado.",
			'DatabaseException:DBSetupIssues' => "Hubo cierta cantidad de incidencias: ",
			'DatabaseException:ScriptNotFound' => "Elgg no pudo encontrar el script de base de datos requerido en %s.",
			
			'IOException:FailedToLoadGUID' => "Fallo al cargar un nuevo %s desde el GUID:%d",
			'InvalidParameterException:NonElggObject' => "Pasando a un constructor ElggObject un parámetro que no es de tipo ElggObject",
			'InvalidParameterException:UnrecognisedValue' => "Valor no reconocido pasado al constructor.",
			
			'InvalidClassException:NotValidElggStar' => "GUID:%d no es un %s válido",
			
			'PluginException:MisconfiguredPlugin' => "%s es un plugin sin configurar.",
			
			'InvalidParameterException:NonElggUser' => "Pasando a un constructor ElggUser un parámetros que no es de tipo ElggUser",
			
			'InvalidParameterException:NonElggSite' => "Pasando a un constructor ElggSite un parámetro que no es de tipo ElggSite",
			
			'InvalidParameterException:NonElggGroup' => "Pasando a un constructor ElggGroup un parámetro que no es de tipo ElggGroup",
	
			'IOException:UnableToSaveNew' => "Imposible guardar nuevo %s",
			
			'InvalidParameterException:GUIDNotForExport' => "GUID has not been specified during export, this should never happen.",
			'InvalidParameterException:NonArrayReturnValue' => "Entity serialisation function passed a non-array returnvalue parameter",
			
			'ConfigurationException:NoCachePath' => "Ruta de la caché no especificada",
			'IOException:NotDirectory' => "%s no es un directorio.",
			
			'IOException:BaseEntitySaveFailed' => "Imposible guardar la información de la entidad base del nuevo objeto",
			'InvalidParameterException:UnexpectedODDClass' => "import() pasó una clase ODD inesperada",
			'InvalidParameterException:EntityTypeNotSet' => "El tipo de la entidad debe especificarse.",
			
			'ClassException:ClassnameNotClass' => "%s no es un %s.",
			'ClassNotFoundException:MissingClass' => "No se ha encontrado la clase '%s', ¿plugin ausente?",
			'InstallationException:TypeNotSupported' => "El tipo %s no está soportado. Esto indica un error en tu instalación, a menudo causado por una actualización incompleta.",

			'ImportException:ImportFailed' => "No se pudo importar el elemento %d",
			'ImportException:ProblemSaving' => "Hubo un probema al guardar %s",
			'ImportException:NoGUID' => "Se ha creado la nueva entidad pero no tiene GUID, esto no debería ocurrir.",
			
			'ImportException:GUIDNotFound' => "La entidad '%d' no se pudo encontrar.",
			'ImportException:ProblemUpdatingMeta' => "Hubo un problema al actualizar '%s' en la entidad '%d'",
			
			'ExportException:NoSuchEntity' => "No existe la entidad con GUID:%d", 
			
			'ImportException:NoODDElements' => "No se encontraron elementos OpenDD en los datos importados, la importación ha fallado.",
			'ImportException:NotAllImported' => "No se importaron todos los elementos.",
			
			'InvalidParameterException:UnrecognisedFileMode' => "Modo de fichero '%s' no reconocido",
			'InvalidParameterException:MissingOwner' => "Todos los ficheros deben tener un propietario",
			'IOException:CouldNotMake' => "No se ha podido hacer %s",
			'IOException:MissingFileName' => "Debes especificar un nombre antes de abrir un fichero.",
			'ClassNotFoundException:NotFoundNotSavedWithFile' => "No se ha encontrado Filestore o la clase no se guardó con el fichero",
			'NotificationException:NoNotificationMethod' => "Método de notificacion no especificado.",
			'NotificationException:NoHandlerFound' => "Manejador no encontrado para '%s' o no se le pueden hacer llamadas.",
			'NotificationException:ErrorNotifyingGuid' => "Se produjo un error al notificar %d",
			'NotificationException:NoEmailAddress' => "No se ha podido obtener la dirección de email para el GUID:%d",
			'NotificationException:MissingParameter' => "No se encuentra un parámetro requerido, '%s'",
			
			'DatabaseException:WhereSetNonQuery' => "Claúsula Where no contiene ningún WhereQueryComponent",
			'DatabaseException:SelectFieldsMissing' => "Campos no encontrados en una consulta de tipo selección",
			'DatabaseException:UnspecifiedQueryType' => "Tipo de consulta no reconocido o no especificado.",
			'DatabaseException:NoTablesSpecified' => "No se han especificado tablas en la consulta.",
			'DatabaseException:NoACL' => "En la consulta no se ha proporcionado control de acceso",
			
			'InvalidParameterException:NoEntityFound' => "No se ha encontrado entidad, o no existe o no tienes acceso a ella.",
			
			'InvalidParameterException:GUIDNotFound' => "GUID:%s no se ha podido encontrar, o no puedes acceder a él.",
			'InvalidParameterException:IdNotExistForGUID' => "Lo sentimos, '%s' no existe para el guid:%d",
			'InvalidParameterException:CanNotExportType' => "Lo sentimos, no se conoce la forma de exportar '%s'",
			'InvalidParameterException:NoDataFound' => "No se pudo encontrar ningún dato.",
			'InvalidParameterException:DoesNotBelong' => "No pertenece a la entidad.",
			'InvalidParameterException:DoesNotBelongOrRefer' => "No pertenece o se refiere a una entidad.",
			'InvalidParameterException:MissingParameter' => "Parámetro no encontrado, debes proporcionar un GUID.",
			
			'SecurityException:APIAccessDenied' => "Lo sentimos, el acceso al API ha sido desactivado por el administrador.",
			'SecurityException:NoAuthMethods' => "No se encontraron métodos de autenticación que pudieran autenticar esta petición al API.",
			'APIException:ApiResultUnknown' => "El resultado del API es de un tipo desconocido, esto no debería ocurrir nunca.", 
			
			'ConfigurationException:NoSiteID' => "No se ha especificado el ID del sitio.",
			'InvalidParameterException:UnrecognisedMethod' => "Llamada al método '%s' no reconocida",
			'APIException:MissingParameterInMethod' => "No se ha encontrado el parámetro %s en el método %s",
			'APIException:ParameterNotArray' => "%s no parece ser un array.",
			'APIException:UnrecognisedTypeCast' => "Tipo %s no reconocido en la conversión de la variable '%s' en el método '%s'",
			'APIException:InvalidParameter' => "Parámetro inválido encontrado para '%s' en el método '%s'.",
			'APIException:FunctionParseError' => "%s(%s) tiene un error de análisis.",
			'APIException:FunctionNoReturn' => "%s(%s) no devolvió ningún valor.",
			'SecurityException:AuthTokenExpired' => "Token de autenticación no existente, inváldo o ha expirado.",
			'CallException:InvalidCallMethod' => "%s debe ser llamado usando '%s'",
			'APIException:MethodCallNotImplemented' => "La llamada al método '%s' no ha sido implementada.",
			'APIException:AlgorithmNotSupported' => "El algoritmo '%s' no está soportado o ha sido desactivado.",
			'ConfigurationException:CacheDirNotSet' => "Directorio de la caché 'cache_path' no especificado.",
			'APIException:NotGetOrPost' => "El método para hacer la petición debe ser GET o POST",
			'APIException:MissingAPIKey' => "Cabecera HTTP X-Elgg-apikey no encontrada",
			'APIException:MissingHmac' => "Cabecera X-Elgg-hmac no encontrada",
			'APIException:MissingHmacAlgo' => "Cabecera X-Elgg-hmac-algo no encontrada",
			'APIException:MissingTime' => "Cabecera X-Elgg-time no encontrada",
			'APIException:TemporalDrift' => "X-Elgg-time es demasiado distante en el pasado o en el futuro. Fallo en el siglo.",
			'APIException:NoQueryString' => "Sin datos en la cadena de consulta",
			'APIException:MissingPOSTHash' => "Cabecera X-Elgg-posthash no encontrada",
			'APIException:MissingPOSTAlgo' => "Cabecera X-Elgg-posthash_algo no encontrada",
			'APIException:MissingContentType' => "Tipo de contenido no encontrado para los datos recibidos",
			'SecurityException:InvalidPostHash' => "Hash de los datos POST inválido - Se esperaba %s pero se obtuvo %s.",
			'SecurityException:DupePacket' => "La firma del paquete fue usada anteriormente.",
			'SecurityException:InvalidAPIKey' => "Clave API inválida o no existente.",
			'NotImplementedException:CallMethodNotImplemented' => "La llamada al método '%s' no está soportada actualmente.",
	
			'NotImplementedException:XMLRPCMethodNotImplemented' => "La llamada al método XML-RPC '%s' no está implementada.",
			'InvalidParameterException:UnexpectedReturnFormat' => "La llamada al método '%s' devolvió un resultado inesperado.",
			'CallException:NotRPCCall' => "La llamada no parece una llamada XML-RPC válida",
	
			'PluginException:NoPluginName' => "El nombre del plugin no se ha podido encontrar",
	
			'ConfigurationException:BadDatabaseVersion' => "El motor de base de datos que has instalado no cumple los requisitos básicos para ejecutar Elgg. Por favor consulta la documentación.",
			'ConfigurationException:BadPHPVersion' => "Necesitas como mínimo PHP versión 5.2 para ejecutar Elgg.",
			'configurationwarning:phpversion' => "Elgg necesita como mínimo PHP versión 5.2, puedes instalarlo en la 5.1.6 pero algunas características podrían no funcionar. Utilízalo bajo tu responsabilidad.",
	
	
			'InstallationException:DatarootNotWritable' => "Tu directorio de datos %s no es escribible.",
			'InstallationException:DatarootUnderPath' => "Tu directorio de datos %s debe estar fuera de tu ruta de instalación.",
			'InstallationException:DatarootBlank' => "No has especificado un directorio de datos.",
	
			'SecurityException:authenticationfailed' => "No se puede autenticar el usuario",
	
			'CronException:unknownperiod' => '%s no es un periodo reconocible.',
	
			'SecurityException:deletedisablecurrentsite' => '¡No puedes borrar o desactivar el sitio que estás viendo en este momento!',
		/**
		 * API
		 */
			'system.api.list' => "Listar todas las llamas al API disponibles en el sistema.",
			'auth.gettoken' => "Esta llamada al API permite el inicio de sesión de un usuario, devolviendo un token de autenticación que puede ser usado en lugar del nombre de usuario y la contraseña para autenticar llamadas posteriores.",
	
		/**
		 * User details
		 */

			'name' => "Nombre público",
			'email' => "Correo electrónico",
			'username' => "Usuario",
			'password' => "Contraseña",
			'passwordagain' => "Contraseña (repetir para verificación)",
			'admin_option' => "¿Hacer que este usuario sea administrador?",
	
		/**
		 * Access
		 */
	
			'ACCESS_PRIVATE' => "Privado",
			'ACCESS_LOGGED_IN' => "Usuarios registrados",
			'ACCESS_PUBLIC' => "Público",
			'PRIVATE' => "Privado",
			'LOGGED_IN' => "Usuarios registrados",
			'PUBLIC' => "Público",
			'access' => "Acceso",
	
		/**
		 * Dashboard and widgets
		 */
	
			'dashboard' => "Panel",
            'dashboard:configure' => "Modificar página",
			'dashboard:nowidgets' => "Tu panel te permite darte a conocer en todo AmigoCanino. Haz click en 'Modificar página' para añadir gadgets con los que publicar contenidos y relacionarte dentro de la comunidad virtual.",

			'widgets:add' => 'Añadir gadgets a tu página',
			'widgets:add:description' => "Selecciona las características que quieres dar a tu página arrastrándolas desde la <b>Galería de gadgets</b> situada a la derecha, a cualquiera de las tres áreas para gadgets que hay debajo, y colócalos donde quieras que aparezcan.

Para quitar un gadget arrástralo de vuelta a la <b>Galería de gadgets</b>.",
			'widgets:position:fixed' => '(Posición fija en la página)',
	
			'widgets' => "Gadgets",
			'widget' => "Gadget",
			'item:object:widget' => "Gadgets",
			'layout:customise' => "Personalizar plantilla",
			'widgets:gallery' => "Galería de Gadgets",
			'widgets:leftcolumn' => "Gadgets izquierda",
			'widgets:fixed' => "Posición fija",
			'widgets:middlecolumn' => "Gadgets centro",
			'widgets:rightcolumn' => "Gadgets derecha",
			'widgets:profilebox' => "Caja del perfil",
			'widgets:panel:save:success' => "Tus gadgets se han guardado correctamente.",
			'widgets:panel:save:failure' => "Ha habido un problema al guardar tus gadgets. Inténtalo de nuevo por favor.",
			'widgets:save:success' => "El gadget se ha guardado correctamente.",
			'widgets:save:failure' => "El gadget no ha podido ser guardado. Inténtalo de nuevo por favor.",
			
	
		/**
		 * Groups
		 */
	
			'group' => "Grupo", 
			'item:group' => "Grupos",
	
		/**
		 * Profile
		 */
	
			'profile' => "Perfil",
			'profile:edit:default' => 'Campos del perfil',
			'user' => "Usuario",
			'item:user' => "Usuarios",
			'riveritem:single:user' => 'un usuario',
			'riveritem:plural:user' => 'varios usuarios',
			'profile:country' => 'País',
			'profile:provincia' => 'Provincia',
			'profile:ciudad' => 'Ciudad',
			'profile:fechanacimiento' => 'Fecha de nacimiento',
			'profile:sexo' => 'Sexo',

		/**
		 * Profile menu items and titles
		 */
	
			'profile:yours' => "Tu perfil",
			'profile:user' => "Perfil de %s",
	
			'profile:edit' => "Modificar perfil",
			'profile:profilepictureinstructions' => "Esta es la imagen que aparece en la página de tu perfil. <br /> Puedes cambiarla siempre que te apetezca. (Formatos aceptados: GIF, JPG o PNG)",
			'profile:icon' => "Imagen del perfil",
			'profile:createicon' => "Crear tu avatar",
			'profile:currentavatar' => "Avatar actual",
			'profile:createicon:header' => "Imagen del perfil",
			'profile:profilepicturecroppingtool' => "Recortar la imagen del perfil",
			'profile:createicon:instructions' => "Haz click y arrastra un recuadro para indicar como quieres que se recorte tu imagen.  Una vista previa de la imagen recortada aparecerá en el recuadro de la derecha.  Cuando estés conforme con la vista previa, haz click en 'Crear tu avatar'. Esta imagen recortada será utilizada en todo AmigoCanino como tu avatar. ",
	
			'profile:editdetails' => "Modificar tus datos",
			'profile:editicon' => "Modificar tu avatar",
	
			'profile:aboutme' => "Sobre mi", 
			'profile:description' => "Sobre mi",
			'profile:briefdescription' => "Breve descripción",
			'profile:location' => "Lugar",
			'profile:skills' => "Habilidades",  
			'profile:interests' => "Intereses", 
			'profile:contactemail' => "Email de contacto",
			'profile:phone' => "Teléfono",
			'profile:mobile' => "Teléfono móvil",
			'profile:website' => "Sitio web",
			'profile:fecnacimiento' => "Fecha nacimiento",

			'profile:river:update' => "%s actualizó su perfil",
			'profile:river:iconupdate' => "%s actualizó el icono de su perfil",
	
			'profile:label' => "Etiqueta del campo",
			'profile:type' => "Tipo de campo",
	
			'profile:editdefault:fail' => 'No se ha podido guardar el perfil predeterminado',
			'profile:editdefault:success' => 'El elemento se ha añadido al perfil predeterminado',
	
			
			'profile:editdefault:delete:fail' => 'Ha fallado el borrado del campo del perfil predeterminado',
			'profile:editdefault:delete:success' => 'Elemento del perfil predeterminado borrado',
	
			'profile:defaultprofile:reset' => 'Recuperar el perfil predeterminado del sistema',
	
			'profile:resetdefault' => 'Recuperar campos predeterminados',
	
		/**
		 * Profile status messages
		 */
	
			'profile:saved' => "Tu perfil se ha guardado correctamente.",
			'profile:icon:uploaded' => "La imagen de tu perfil ha sido subida correctamente.",
	
		/**
		 * Profile error messages
		 */
	
			'profile:noaccess' => "No tienes permiso para acceder a este perfil.",
			'profile:notfound' => "No se ha podido encontrar el perfil especificado.",
			'profile:cantedit' => "No tienes permiso para modificar este perfil.",
			'profile:icon:notfound' => "Ha habido un problema al subir la imagen de tu perfil.",
	
		/**
		 * Friends
		 */
	
			'friends' => "Amigos",
			'friends:yours' => "Tus amigos",
			'friends:owned' => "amigos de %s",
			'friend:add' => "Hacerme su amigo",
			'friend:remove' => "Borrar amigo",
	
			'friends:add:successful' => "Has añadido a %s como tu amigo.",
			'friends:add:failure' => "No ha sido posible añadir a %s como tu amigo. Inténtalo de nuevo por favor.",
	
			'friends:remove:successful' => "Has quitado a %s de tus amigos.",
			'friends:remove:failure' => "No ha sido posible quitar a %s de tus amigos. Inténtalo de nuevo por favor.",
	
			'friends:none' => "Este usuario todavía no ha añadido a nadie como amigo.",
			'friends:none:you' => "¡Todavía no tienes ningún amigo! Busca según tus intereses para empezar a encontrar gente con la que puedas congeniar.",
	
			'friends:none:found' => "No se han encontrado amigos.",
	
			'friends:of:none' => "Nadie es amigo de este usuario todavía.",
			'friends:of:none:you' => "Nadie te ha añadido como amigo todavía. Añadir contenidos y rellenar tu perfil permitirá que la gente te pueda encontrar.",
	
			'friends:of' => "Amigos de",
			'friends:of:owned' => "Gente que ha hecho a %s su amigo",

			 'friends:num_display' => "Número de amigos a mostrar",
			 'friends:icon_size' => "Tamaño de icono",
			 'friends:tiny' => "pequeñito",
			 'friends:small' => "pequeño",
			 'friends' => "Amigos",
			 'friends:of' => "Sus amigos",
			 'friends:collections' => "Pandillas de amigos",
			 'friends:collections:add' => "Nueva pandilla",
			 'friends:addfriends' => "Añadir amigos",
			 'friends:collectionname' => "Nombre de la pandilla",
			 'friends:collectionfriends' => "Amigos en la pandilla",
			 'friends:collectionedit' => "Modificar esta pandilla",
			 'friends:nocollections' => "Todavía no tienes ninguna pandilla.",
			 'friends:collectiondeleted' => "La pandilla ha sido borrada.",
			 'friends:collectiondeletefailed' => "No se ha podido borrar la pandilla. Es posible que no tengas permiso, o quizás se haya producido algún error.",
			 'friends:collectionadded' => "La pandilla ha sido creada correctamente",
			 'friends:nocollectionname' => "Es necesario que des un nombre a la pandilla antes de que pueda ser creada.",
		
	        'friends:river:created' => "%s añadió el gadget de amigos.",
	        'friends:river:updated' => "%s actualizó su gadget de amigos.",
	        'friends:river:delete' => "%s quitó su gadget de amigos.",
	        'friends:river:add' => "%s tiene algún amigo nuevo.",
	
		/**
		 * Feeds
		 */
			'feed:rss' => 'Subscribirse al feed',
			'feed:odd' => 'Sindicación OpenDD',
			
		/**
          * links
		 **/

			'link:view' => 'ver enlace',

	
		/**
		 * River
		 */
			'river' => "River",			
			'river:relationship:friend' => 'mantiene ahora una amistad con',

		/**
		 * Plugins
		 */
			'plugins:settings:save:ok' => "Las opciones del plugin %s han sido guardadas correctamente.",
			'plugins:settings:save:fail' => "Ha ocurrido un error al guardar las opciones del plugin %s.",
			'plugins:usersettings:save:ok' => "Las opciones de usuario para el plugin %s han sido guardadas.",
			'plugins:usersettings:save:fail' => "Ha ocurrido un error al guardar las opciones de usuario para el plugin %s.",
	
			'item:object:plugin' => 'Plugins',
			
		/**
		 * Notifications
		 */
			'notifications:usersettings' => "Opciones de avisos",
			'notifications:methods' => "Indica que métodos quieres permitir:",
	
			'notifications:usersettings:save:ok' => "Se han guardado tus opciones de avisos.",
			'notifications:usersettings:save:fail' => "Ha ocurrido un error guardando tus opciones de avisos.",
	
			'user.notification.get' => 'Devolver las opciones de avisos para un usuario dado.',
			'user.notification.set' => 'Fijar las opciones de avisos para un usuario dado.',
		/**
		 * Search
		 */
	
			'search' => "Buscar",
			'searchtitle' => "Buscar: %s",
			'users:searchtitle' => "Búsqueda de usuarios: %s",
			'advancedsearchtitle' => "%s con resultados que coincidan con %s",
			'notfound' => "No se han encontrado resultados.",
			'next' => "Siguiente",
			'previous' => "Anterior",
	
			'viewtype:change' => "Cambiar el tipo de listado",
			'viewtype:list' => "Ver lista",
			'viewtype:gallery' => "Galería",
	
			'tag:search:startblurb' => "Elementos con etiquetas coincidentes con '%s':",

			'user:search:startblurb' => "Usuarios que coinciden con '%s':",
			'user:search:finishblurb' => "Para ver más, haz click aquí.",
	
		/**
		 * Account
		 */
	
			'account' => "Cuenta",
			'settings' => "Configuración",
            'tools' => "Herramientas",
            'tools:yours' => "Tus herramientas",
	
			'register' => "Nuevo usuario",
			'registerok' => "Te has registrado en %s con éxito.",
			'registerbad' => "Tu registro no se ha podido completar. El nombre de usuario quizás ya exista, tus contraseñas no coinciden, o tu nombre de usuario o contraseña son demasiado cortos.",
			'registerdisabled' => "El registro de nuevos usuarios está desactivado",
	
			'registration:notemail' => 'Has proporcionado una dirección de email que no parece ser válida.',
			'registration:userexists' => 'Ese nombre de usuario ya existe',
			'registration:usernametooshort' => 'Tu nombre de usuario debe tener un mínimo de 4 caracteres de longitud.',
			'registration:passwordtooshort' => 'La contraseña debe tener un mínimo de 6 caracteres de longitud.',
			'registration:dupeemail' => 'Esta dirección de email ya fue registrada anteriormente.',
			'registration:invalidchars' => 'El nombre de usuario contiene caracteres inválidos.',
			'registration:emailnotvalid' => 'La dirección de email introducida no es válida en este sistema',
			'registration:passwordnotvalid' => 'La contraseña introducida no es válida en este sistema',
			'registration:usernamenotvalid' => 'El nombre de usuario introducido no es válido en este sistema',
	
			'adduser' => "Añadir Usuario",
			'adduser:ok' => "Has añadido un nuevo usuario.",
			'adduser:bad' => "No se ha podido crear el nuevo usuario.",
			
			'item:object:reported_content' => "Elementos denunciados",
	
			'user:set:name' => "Opciones del nombre de la cuenta",
			'user:name:label' => "Tu nombre",
			'user:name:success' => "Tu nombre ha sido cambiado en el sistema.",
			'user:name:fail' => "No se ha podido cambiar tu nombre en el sistema.",
	
			'user:set:password' => "Contraseña de la cuenta",
			'user:password:label' => "Tu nueva contraseña",
			'user:password2:label' => "Repite tu nueva contraseña",
			'user:password:success' => "Contraseña cambiada",
			'user:password:fail' => "Could not change your password on the system.",
			'user:password:fail:notsame' => "The two passwords are not the same!",
			'user:password:fail:tooshort' => "Password is too short!",
	
			'user:set:language' => "Opciones de idioma",
			'user:language:label' => "Tu idioma",
			'user:language:success' => "Tus opciones de idioma han sido actualizadas.",
			'user:language:fail' => "Tus opciones de idioma no han podido ser guardadas.",
	
			'user:username:notfound' => 'El usuario %s no se ha encontrado.',
	
			'user:password:lost' => 'Contraseña perdida',
			'user:password:resetreq:success' => 'Solicitud de nueva contraseña realizada, se ha enviado el e-mail',
			'user:password:resetreq:fail' => 'No es posible solicitar una nueva contraseña.',
	
			'user:password:text' => 'Para generar una nueva contraseña, introduce a continuación tu nombre de usuario. Te enviaremos vía e-mail la dirección de una página de verificación única. Sólo has de hacer click en el enlace y recibirás una nueva contraseña.',
	
			'user:persistent' => 'Recordarme',
		/**
		 * Administration
		 */

			'admin:configuration:success' => "Se ha guardado tu configuración.",
			'admin:configuration:fail' => "No se ha podido guardar tu configuración.",
	
			'admin' => "Administración",
			'admin:description' => "El panel de administración te permite controlar todos los aspecto del sistema, desde la administración de usuarios a los plugins activos. Selecciona una de las siguientes opciones para comenzar.",
			
			'admin:user' => "Administrar usuarios",
			'admin:user:description' => "Este panel de administración te permite controlar las opciones de usuario para el sitio. Selecciona una de las siguientes opciones para comenzar.",
			'admin:user:adduser:label' => "Haz click aquí para añadir un nuevo usuario...",
			'admin:user:opt:linktext' => "Configurar usuarios...",
			'admin:user:opt:description' => "Configurar usuarios e información de cuenta. ",
			
			'admin:site' => "Administrar sitio",
			'admin:site:description' => "Este panel de administración te permite controlar las opciones globales de tu sitio. Selecciona una de las siguientes opciones para comenzar.",
			'admin:site:opt:linktext' => "Configurar sitio...",
			'admin:site:opt:description' => "Configurar las opciones técnicas y no técnicas del sitio. ",
			
			'admin:plugins' => "Plugins",
			'admin:plugins:description' => "Este panel de administración te permite controlar y configurar las herramientas instaladas en el sitio.",
			'admin:plugins:opt:linktext' => "Configurar herramientas...",
			'admin:plugins:opt:description' => "Configurar las herramientas instaladas en el sitio. ",
			'admin:plugins:label:author' => "Autor",
			'admin:plugins:label:copyright' => "Copyright",
			'admin:plugins:label:licence' => "Licencia",
			'admin:plugins:label:website' => "URL",
			"admin:plugins:label:moreinfo" => 'más información',
			'admin:plugins:reorder:yes' => "El plugin %s ha sido reordenado con éxito.",
			'admin:plugins:reorder:no' => "El plugin %s no se ha podido reordenar.",
			'admin:plugins:disable:yes' => "El plugin %s ha sido desactivado con éxito.",
			'admin:plugins:disable:no' => "No se ha podido desactivar el plugin %s.",
			'admin:plugins:enable:yes' => "El plugin %s ha sido activado con éxito.",
			'admin:plugins:enable:no' => "No se ha podido activar el plugin %s.",
	
			'admin:statistics' => "Estadísticas",
			'admin:statistics:description' => "Este es un resumen de las estadísticas del sitio.",
			'admin:statistics:opt:description' => "Ver información estadística sobre usuarios y objetos del sitio.",
			'admin:statistics:opt:linktext' => "Ver estadísticas...",
			'admin:statistics:label:basic' => "Estadísticas básicas del sitio",
			'admin:statistics:label:numentities' => "Entidades en el sistema",
			'admin:statistics:label:numusers' => "Número de usuarios",
			'admin:statistics:label:numonline' => "Número de usuarios conectados",
			'admin:statistics:label:onlineusers' => "Usuarios conectados ahora",
			'admin:statistics:label:version' => "Versión de Elgg",
			'admin:statistics:label:version:release' => "Release",
			'admin:statistics:label:version:version' => "Versión",
	
			'admin:user:label:search' => "Buscar usuarios:",
			'admin:user:label:seachbutton' => "Buscar", 
	
			'admin:user:ban:no' => "No se puede bloquear el usuario",
			'admin:user:ban:yes' => "Usuario bloqueado.",
			'admin:user:unban:no' => "No se puede desbloquear el usuario",
			'admin:user:unban:yes' => "Usuario desbloqueado.",
			'admin:user:delete:no' => "No se puede borrar el usuario",
			'admin:user:delete:yes' => "Usuario borrado",
	
			'admin:user:resetpassword:yes' => "Contraseña regenerada, se ha notificado al usuario.",
			'admin:user:resetpassword:no' => "No se ha podido regenerar la contraseña.",
	
			'admin:user:makeadmin:yes' => "El usuario ahora es administrador.",
			'admin:user:makeadmin:no' => "No se ha podido hacer administrador al usuario.",
			
		/**
		 * User settings
		 */
			'usersettings:description' => "El panel de opciones de usuario te permite controlar todas tus opciones personales, desde la administración de usuarios al comportamiento de los plugins. Selecciona una opción a continuación para comenzar.",
	
			'usersettings:statistics' => "Tus estadísticas",
			'usersettings:statistics:opt:description' => "Ver información estadística sobre usuarios y objetos en el sitio.",
			'usersettings:statistics:opt:linktext' => "Tus estadísticas",
	
			'usersettings:user' => "Tu configuración",
			'usersettings:user:opt:description' => "Esto te permite controlar las opciones de usuario.",
			'usersettings:user:opt:linktext' => "Cambiar tu preferencias",
	
			'usersettings:plugins' => "Herramientas",
			'usersettings:plugins:opt:description' => "Configurar las opciones de tus herramientas activas.",
			'usersettings:plugins:opt:linktext' => "Tus herramientas",
	
			'usersettings:plugins:description' => "Este panel te permite controlar y configurar las opciones personales paras las herramientas instaladas por el administrador del sistema.",
			'usersettings:statistics:label:numentities' => "Tus entidades",
	
			'usersettings:statistics:yourdetails' => "Tus datos",
			'usersettings:statistics:label:name' => "Nombre",
			'usersettings:statistics:label:email' => "Email",
			'usersettings:statistics:label:membersince' => "Miembro desde",
			'usersettings:statistics:label:lastlogin' => "Último acceso",
	
			
	
		/**
		 * Generic action words
		 */
	
			'save' => "Guardar",
			'cancel' => "Cancelar",
			'saving' => "Guardando ...",
			'update' => "Actualizar",
			'edit' => "Modificar",
			'delete' => "Eliminar",
			'load' => "Leer",
			'upload' => "Subir",
			'ban' => "Bloquear",
			'unban' => "Desbloquear",
			'enable' => "Activar",
			'disable' => "Desactivar",
			'request' => "Solicitar",
			'complete' => "Completado",
			'open' => 'Abrir',
			'close' => 'Cerrar',
			'reply' => "Responder",
	
			'up' => 'Subir',
			'down' => 'Bajar',
			'top' => 'Arriba',
			'bottom' => 'Abajo',
	
			'invite' => "Invitar",
	
			'resetpassword' => "Recuperar contraseña",
			'makeadmin' => "Hacer administrador",
	
			'option:yes' => "Si",
			'option:no' => "No",
	
			'unknown' => 'Desconocido',
	
			'active' => 'Activo',
			'total' => 'Total',
	
			'learnmore' => "Click aquí para más información.",
	
			'content' => "contenido",
			'content:latest' => 'Actividad reciente',
			'content:latest:blurb' => 'También puedes hacer click aquí para ver el contenido más reciente de toda la web.',
	
			'link:text' => 'ver enlace',
	
	
		/**
		 * Generic data words
		 */
	
			'title' => "Título",
			'description' => "Descripción",
			'tags' => "Etiquetas",
			'spotlight' => "A un click",
			'all' => "Todos",
	
			'by' => 'por',
	
			'annotations' => "Anotaciones",
			'relationships' => "Relaciones",
			'metadata' => "Metadatos",
	
		/**
		 * Input / output strings
		 */

			'deleteconfirm' => "¿Confirmas el borrado de este elemento?",
			'fileexists' => "El fichero ya existe. Para reemplazarlo, selecciónalo a continuación:",
			
			
	    /**
         * System messages
         **/

			'systemmessages:dismiss' => "click para cerrar",

	
		/**
		 * Import / export
		 */
			'importsuccess' => "Importación de datos realizada con éxito",
			'importfail' => "La importación de datos OpenDD ha fallado.",
	
		/**
		 * Time
		 */
	
			'friendlytime:justnow' => "ahora mismo",
			'friendlytime:minutes' => "hace %s minutos",
			'friendlytime:minutes:singular' => "hace un minuto",
			'friendlytime:hours' => "hace %s horas",
			'friendlytime:hours:singular' => "hace una hora",
			'friendlytime:days' => "hace %s días",
			'friendlytime:days:singular' => "ayer",
	
		/**
		 * Installation and system settings
		 */
	
			'installation:error:htaccess' => "Elgg necesita un fichero llamado .htaccess en el directorio raíz de su instalación. Se ha intentado crearlo por ti, pero Elgg no tiene permisos de escritura en dicho directorio. 

Crearlo es fácil. Copia los contenidos del siguiente cuadro de texto en un editor de texto y guárdalo como .htaccess

",
			'installation:error:settings' => "Elgg no puede encontrar su fichero de configuración. La mayoría de las opciones de Elgg se manejarán por ti, pero es necesario que proporciones las opciones de tu base de datos. Para hacerlo:

1. Renombra engine/settings.example.php a settings.php en tu instalación de Elgg.

2. Abrelo con un editor de texto e introduce los detalles de tu base de datos MySQL. Si no los conoces, pregunta al administrador de tu sistema o a soporte técnico.

Alternativamente, puedes introducir a continuación las opciones de tu base de datos e intentaremos hacerlo por ti...",
	
			'installation:error:configuration' => "Una vez hayas corregido las incidencias de configuración, presiona recargar para intentarlo de nuevo.",
	
			'installation' => "Instalación",
			'installation:success' => "Base de datos de Elgg instalada correctamente.",
			'installation:configuration:success' => "Se ha guardado tu configuración inicial. Ahora registra tu usuario inicial, que será tu primer administrador del sistema.",
	
			'installation:settings' => "Opciones del sistema",
			'installation:settings:description' => "Ahora que la base de datos de Elgg ha sido instalada correctamente, necesitas introducir algo de información para tener tu sitio web totalmente activo. Se han intentado adivinar, pero <b>deberías comprobar esta información.</b>",
	
			'installation:settings:dbwizard:prompt' => "Introduce a continuación las opciones de tu base de datos y pulsa guardar:",
			'installation:settings:dbwizard:label:user' => "Usuario de la base de datos",
			'installation:settings:dbwizard:label:pass' => "Contraseña de la base de datos",
			'installation:settings:dbwizard:label:dbname' => "Base de datos de Elgg",
			'installation:settings:dbwizard:label:host' => "Nombre del servidor de la base de datos (normalmente 'localhost')",
			'installation:settings:dbwizard:label:prefix' => "Prefijo de las tablas de la base de datos (normalmente 'elgg')",
	
			'installation:settings:dbwizard:savefail' => "Ha sido imposible guardar el nuevo settings.php. Por favor, guarda el siguiente fichero como engine/settings.php usando un editor de texto.",
	
			'installation:sitename' => "El nombre de tu sitio (ej \"Mi red social\"):",
			'installation:sitedescription' => "Descripción corta de tu sitio web (opcional)",
			'installation:wwwroot' => "La URL del sitio, terminada en una barra inclinada:",
			'installation:path' => "La ruta completa a la raíz de tu sitio en el disco, terminada en una barra inclinada:",
			'installation:dataroot' => "La ruta completa al directorio donde se guardarán los archivos que se suban, terminada en una barra inclinada:",
			'installation:dataroot:warning' => "Debes crear este directorio manualmente. Debería estar situado en un directorio distinto al de tu instalación de Elgg.",
			'installation:language' => "El idioma predeterminado para tu sitio:",
			'installation:debug' => "El modo de depuración proporciona información extra que puede utilizarse para diagnosticar fallos, sin embargo puede ralentizar tu sistema por lo que sólo debería ser usado si tienes problemas:",
			'installation:debug:label' => "Activar modo de depuración",
			'installation:usage' => "Con esta opción permites que Elgg envíe estadísticas anónimas de uso a Curverider.",
			'installation:usage:label' => "Enviar estadísticas anónimas de uso",
			'installation:view' => "Introduce la vista que se utilizará por defecto en tu sitio web o déjala en blanco para usar la vista predeterminada (en caso de duda, déjala por defecto o 'default'):",

			'installation:siteemail' => "Dirección de email del sitio (usada para enviar los emails del sistema)",
	
			'installation:disableapi' => "El API RESTful es un interface flexible y extensible que permite a las aplicaciones utilizar remotament ciertas características de Elgg.",
			'installation:disableapi:label' => "Activar el API RESTful",

			'upgrading' => 'Actualizando',
			'upgrade:db' => 'Tu base de datos ha sido actualizada.',
			'upgrade:core' => 'Tu instalación de Elgg ha sido actualizada',
	
		/**
		 * Welcome
		 */
	
			'welcome' => "Bienvenido %s",
			'welcome_message' => "Bienvenido a esta instalación de Elgg.",
	
		/**
		 * Emails
		 */
			'email:settings' => "Opciones de Email",
			'email:address:label' => "Tu dirección de email",
			
			'email:save:success' => "Se ha guardado la nueva dirección de email y ahora debes verificarla.",
			'email:save:fail' => "No se ha podido guardar tu nueva dirección de email.",
	
			'email:confirm:success' => "¡Has confirmado tu dirección de e-mail!",
			'email:confirm:fail' => "Tu dirección de e-mail no se ha podido verificar...",
	
			'friend:newfriend:subject' => "¡%s te ha añadido a sus amigos!",
			'friend:newfriend:body' => "¡%s te ha añadido a sus amigos!

Para ver su perfil, haz click aquí:

	%s

Por favor, no respondas a este email, ha sido generado automáticamente.",
	
	
	
			'email:resetpassword:subject' => "Regeneración de contraseña",
			'email:resetpassword:body' => "Hola %s,
			
Tu contraseña ha sido regenerada y es: %s",
	
	
			'email:resetreq:subject' => "Solicitud de nueva contraseña.",
			'email:resetreq:body' => "Hola %s,
			
Alguien (desde la dirección IP %s) ha solicitado una contraseña nueva para su cuenta.

Si la has solicitado tu, haz click en el siguiente enlace, en caso contrario ignora este email.

%s
",

	
		/**
		 * XML-RPC
		 */
			'xmlrpc:noinputdata'	=>	"No hay datos de entrada",
	
		/**
		 * Comments
		 */
	
			'comments:count' => "%s comentarios",
			
			'riveraction:annotation:generic_comment' => '%s comentado por %s',
	
			'generic_comments:add' => "Añadir un comentario",
			'generic_comments:text' => "Comentario",
			'generic_comment:posted' => "El comentario ha sido publicado.",
			'generic_comment:deleted' => "El comentario ha sido borrado.",
			'generic_comment:blank' => "Debes introducir algo en el comentario antes de poder guardarlo.",
			'generic_comment:notfound' => "El elemento especificado no se ha podido encontrar.",
			'generic_comment:notdeleted' => "El comentario no se ha podido borrar.",
			'generic_comment:failure' => "Ha ocurrido un error inesperado al añadir el comentario. Inténtalo de nuevo.",
	
			'generic_comment:email:subject' => '¡Tienes un comentario nuevo!',
			'generic_comment:email:body' => "Tienes un comentario nuevo en \"%s\" de %s. Dice:

			
%s


Para contestar o ver el elemento original, haz click aquí:

	%s

Para ver el perfil de %s, haz click aquí:

	%s

Por favor, no respondas a este email, ha sido generado automáticamente.",
	
		/**
		 * Entities
		 */
			'entity:default:strapline' => 'Creada %s por %s',
			'entity:default:missingsupport:popup' => 'Esta entidad no se puede mostrar correctamente. Puede ser debido a que necesite el soporte proporcionado por un plugin que ya no está instalado.',
	
			'entity:delete:success' => 'La entidad %s ha sido eliminada',
			'entity:delete:fail' => 'La entidad %s no ha podido ser borrada',
	
	
		/**
		 * Action gatekeeper
		 */
			'actiongatekeeper:missingfields' => 'Al formulario le faltan campos __token o __ts',
			'actiongatekeeper:tokeninvalid' => "Se ha encontrado un error (no coindice el token). Probablemente significa que la página a la que estabas accediendo ha expirado. Por favor, inténtalo de nuevo.",
			'actiongatekeeper:timeerror' => 'La página a la que accedías ha expirado. Recárgala e inténtalo de nuevo.',
			'actiongatekeeper:pluginprevents' => 'Una extensión ha impedido el envío de este formulario.',
	
		/**
		 * Word blacklists
		 */
			'word:blacklist' => 'y, el, entonces, pero, ella, su, suyo, suya, uno, no, también, sobre, ahora, quizás, aún, asimismo, contrario, inversa, bastante, consecuentemente, además, obstante, mientras, este, esta, esto, parece, que, quien, quienquiera, cuyo',
	
		/**
		 * Languages according to ISO 639-1
		 */
			"aa" => "Afar",
			"ab" => "Abkhazian",
			"af" => "Afrikaans",
			"am" => "Amharic",
			"ar" => "Arabic",
			"as" => "Assamese",
			"ay" => "Aymara",
			"az" => "Azerbaijani",
			"ba" => "Bashkir",
			"be" => "Byelorussian",
			"bg" => "Bulgarian",
			"bh" => "Bihari",
			"bi" => "Bislama",
			"bn" => "Bengali; Bangla",
			"bo" => "Tibetan",
			"br" => "Breton",
			"ca" => "Catalan",
			"co" => "Corsican",
			"cs" => "Czech",
			"cy" => "Welsh",
			"da" => "Danish",
			"de" => "German",
			"dz" => "Bhutani",
			"el" => "Greek",
			"en" => "English",
			"eo" => "Esperanto",
			"es" => "Español",
			"et" => "Estonian",
			"eu" => "Basque",
			"fa" => "Persian",
			"fi" => "Finnish",
			"fj" => "Fiji",
			"fo" => "Faeroese",
			"fr" => "French",
			"fy" => "Frisian",
			"ga" => "Irish",
			"gd" => "Scots / Gaelic",
			"gl" => "Galician",
			"gn" => "Guarani",
			"gu" => "Gujarati",
			"he" => "Hebrew",
			"ha" => "Hausa",
			"hi" => "Hindi",
			"hr" => "Croatian",
			"hu" => "Hungarian",
			"hy" => "Armenian",
			"ia" => "Interlingua",
			"id" => "Indonesian",
			"ie" => "Interlingue",
			"ik" => "Inupiak",
			//"in" => "Indonesian",
			"is" => "Icelandic",
			"it" => "Italian",
			"iu" => "Inuktitut",
			"iw" => "Hebrew (obsolete)",
			"ja" => "Japanese",
			"ji" => "Yiddish (obsolete)",
			"jw" => "Javanese",
			"ka" => "Georgian",
			"kk" => "Kazakh",
			"kl" => "Greenlandic",
			"km" => "Cambodian",
			"kn" => "Kannada",
			"ko" => "Korean",
			"ks" => "Kashmiri",
			"ku" => "Kurdish",
			"ky" => "Kirghiz",
			"la" => "Latin",
			"ln" => "Lingala",
			"lo" => "Laothian",
			"lt" => "Lithuanian",
			"lv" => "Latvian/Lettish",
			"mg" => "Malagasy",
			"mi" => "Maori",
			"mk" => "Macedonian",
			"ml" => "Malayalam",
			"mn" => "Mongolian",
			"mo" => "Moldavian",
			"mr" => "Marathi",
			"ms" => "Malay",
			"mt" => "Maltese",
			"my" => "Burmese",
			"na" => "Nauru",
			"ne" => "Nepali",
			"nl" => "Dutch",
			"no" => "Norwegian",
			"oc" => "Occitan",
			"om" => "(Afan) Oromo",
			"or" => "Oriya",
			"pa" => "Punjabi",
			"pl" => "Polish",
			"ps" => "Pashto / Pushto",
			"pt" => "Portuguese",
			"qu" => "Quechua",
			"rm" => "Rhaeto-Romance",
			"rn" => "Kirundi",
			"ro" => "Romanian",
			"ru" => "Russian",
			"rw" => "Kinyarwanda",
			"sa" => "Sanskrit",
			"sd" => "Sindhi",
			"sg" => "Sangro",
			"sh" => "Serbo-Croatian",
			"si" => "Singhalese",
			"sk" => "Slovak",
			"sl" => "Slovenian",
			"sm" => "Samoan",
			"sn" => "Shona",
			"so" => "Somali",
			"sq" => "Albanian",
			"sr" => "Serbian",
			"ss" => "Siswati",
			"st" => "Sesotho",
			"su" => "Sundanese",
			"sv" => "Swedish",
			"sw" => "Swahili",
			"ta" => "Tamil",
			"te" => "Tegulu",
			"tg" => "Tajik",
			"th" => "Thai",
			"ti" => "Tigrinya",
			"tk" => "Turkmen",
			"tl" => "Tagalog",
			"tn" => "Setswana",
			"to" => "Tonga",
			"tr" => "Turkish",
			"ts" => "Tsonga",
			"tt" => "Tatar",
			"tw" => "Twi",
			"ug" => "Uigur",
			"uk" => "Ukrainian",
			"ur" => "Urdu",
			"uz" => "Uzbek",
			"vi" => "Vietnamese",
			"vo" => "Volapuk",
			"wo" => "Wolof",
			"xh" => "Xhosa",
			//"y" => "Yiddish",
			"yi" => "Yiddish",
			"yo" => "Yoruba",
			"za" => "Zuang",
			"zh" => "Chinese",
			"zu" => "Zulu",
	);
	
	add_translation("es",$spanish);

?>
