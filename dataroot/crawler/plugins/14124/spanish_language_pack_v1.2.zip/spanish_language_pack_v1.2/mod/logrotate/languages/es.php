<?php
	/**
	 * Elgg log rotator language pack.
	 * 
	 * @package ElggLogRotate
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$spanish = array(
		'logrotate:period' => '¿Con qué frecuencia deberia archivarse el registro del sistema?',
	
		'logrotate:weekly' => 'Una vez por semana',
		'logrotate:monthly' => 'Una vez al mes',
		'logrotate:yearly' => 'Una vez al año',
	
		'logrotate:logrotated' => "Registro rotado\n",
		'logrotate:lognotrotated' => "Error rotando el registro\n",
	);
					
	add_translation("es",$spanish);
?>