<?php
	/**
	 * Elgg pages plugin language pack
	 * 
	 * @package ElggPages
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
			
			'pages' => "Páginas",
			'pages:yours' => "Tus páginas",
			'pages:user' => "Páginas",
			'pages:group' => "Páginas de %s",
			'pages:all' => "Todas las páginas",
			'pages:new' => "Nueva página",
			'pages:groupprofile' => "Páginas del grupo",
			'pages:edit' => "Modificar esta página",
			'pages:delete' => "Eliminar esta página",
			'pages:history' => "Historial de la página",
			'pages:view' => "Ver la página",
			'pages:welcome' => "Mensaje de bienvenida",
			'pages:welcomeerror' => "Ha ocurrido un error al guardar tu mensaje de bienvenida",
			'pages:welcomeposted' => "Tu mensaje de bienvenida ha sido publicado",
			'pages:navigation' => "Navegación",
	
			'item:object:page_top' => 'Páginas principales',
			'item:object:page' => 'Páginas',
			'item:object:pages_welcome' => 'Bloques de bienvenida',
	
	
		/**
		 * Form fields
		 */
	
			'pages:title' => 'Título',
			'pages:description' => 'Texto de la página',
			'pages:tags' => 'Etiquetas',	
			'pages:access_id' => 'Acceso',
			'pages:write_access_id' => 'Acceso de escritura',
		
		/**
		 * Status and error messages
		 */
			'pages:noaccess' => 'Sin acceso a la página',
			'pages:cantedit' => 'No puedes modificar esta página',
			'pages:saved' => 'Páginas guardadas',
			'pages:notsaved' => 'La página no ha podido ser guardada',
			'pages:notitle' => 'Debes introducir un título para tu página.',
			'pages:delete:success' => 'Tu página ha sido eliminada satisfactoriamente.',
			'pages:delete:failure' => 'La página no se ha podido eliminar.',
	
		/**
		 * Page
		 */
			'pages:strapline' => 'Última actualización %s por %s',
	
		/**
		 * History
		 */
			'pages:revision' => 'Revisión creada %s por %s',
			
		/**
		 * Wdiget
		 **/
		 
		    'pages:num' => 'Número de páginas a mostrar',
	
		/**
		 * Submenu items
		 */
			'pages:label:view' => "Ver página",
			'pages:label:edit' => "Modificar página",
			'pages:label:history' => "Historial de la página",
	
		/**
		 * Sidebar items
		 */
			'pages:sidebar:this' => "Esta página",
			'pages:sidebar:children' => "Sub-páginas",
			'pages:sidebar:parent' => "Padre",
	
			'pages:newchild' => "Crear una sub-página",
			'pages:backtoparent' => "Volver a '%s'",
	);
					
	add_translation("es",$spanish);
?>