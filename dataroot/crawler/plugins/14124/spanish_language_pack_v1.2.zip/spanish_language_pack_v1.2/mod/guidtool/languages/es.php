<?php
	/**
	 * Elgg GUID Tool
	 * 
	 * @package ElggGUIDTool
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'guidtool' => 'Herramientas GUID',
			'guidtool:browse' => 'Navegar GUIDs',
			'guidtool:import' => 'Importar',
			'guidtool:import:desc' => 'Pega los datos que quieras importar en la siguiente ventana, deben estar en formato "%s".',
	
			'guidtool:pickformat' => 'Selecciona el formato en el que quieras importar o exportar.',
	
			'guidbrowser:export' => 'Exportar',
	);
					
	add_translation("es",$spanish);
?>