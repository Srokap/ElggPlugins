<?php
	/**
	 * Elgg diagnostics language pack.
	 * 
	 * @package ElggDiagnostics
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$spanish = array(
	
			'diagnostics' => 'Diagnósticos',
	
			'diagnostics:description' => 'El siguiente informe de diagnósticos es útil para analizar posibles problemas con Elgg, y debería ser adjuntado a cualquier informe de errores que envies.',
	
			'diagnostics:download' => 'Descargar .txt',
	
	
			'diagnostics:header' => '========================================================================
Informe de Diagnósticos de Elgg
Generado %s por %s
========================================================================
			
',
			'diagnostics:report:basic' => '
Elgg Release %s, versión %s

------------------------------------------------------------------------',
			'diagnostics:report:php' => '
Información PHP:
%s
------------------------------------------------------------------------',
			'diagnostics:report:plugins' => '
Plugins instalados y detalles:

%s
------------------------------------------------------------------------',
			'diagnostics:report:md5' => '
Archivos instalados y checksums:

%s
------------------------------------------------------------------------',
			'diagnostics:report:globals' => '
Variables globales:

%s
------------------------------------------------------------------------',
	
	);
					
	add_translation("es",$spanish);
?>