<?php

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'bookmarks' => "Marcadores",
			'bookmarks:add' => "Añadir marcador",
			'bookmarks:read' => "Elementos en marcadores",
			'bookmarks:friends' => "Marcadores de amigos",
			'bookmarks:everyone' => "Todos los marcadores",
			'bookmarks:this' => "Añadir marcador",
			'bookmarks:bookmarklet' => "Extensión navegador",
			'bookmarks:inbox' => "Marcadores entrantes",
			'bookmarks:more' => "Más marcadores",
			'bookmarks:shareditem' => "Elemento en marcadores",
			'bookmarks:with' => "Compartir con",
	
			'bookmarks:address' => "Dirección del recurso a añadir a marcadores",
	
			'bookmarks:delete:confirm' => "¿Confirmas el borrado de este recurso?",
	
			'bookmarks:shared' => "Añadido a marcadores",
			'bookmarks:visit' => "Visitar recurso",
			'bookmarks:recent' => "Marcadores",
	
			'bookmarks:river:created' => 'marcador por %s',
			'bookmarks:river:annotate' => 'comentado por %s',
			'bookmarks:river:item' => 'un elemento(s)',
	
			'item:object:bookmarks' => 'Elementos en marcadores',
	
	
		/**
		 * More text
		 */
		    
		    'bookmarks:widget:description' => 
		            "Este gadget para tu panel te mostrará los últimos elementos en la bandeja de entrada de marcadores.",
	
			'bookmarks:bookmarklet:description' =>
					"Esta extensión para el navegador te permite compartir con tus amigos cualquier recurso que encuentres en la web, o simplemente guardarlo para ti. Para utilizarlo, arrastra el siguiente botón a la barra de enlaces de tu navegador:",

	        'bookmarks:bookmarklet:descriptionie' =>
					"Si utilizas Internet Explorer, tendrás que hacer click con el botón derecho en el icono, seleccionar 'Añadir a favoritos', y luego la barra de Enlaces.",

			'bookmarks:bookmarklet:description:conclusion' =>
					"Para guardar cualquier página que visites solamente tendrás que hacer click en este marcador que has añadido a tu navegador.",
	
		/**
		 * Status messages
		 */
	
			'bookmarks:save:success' => "Has guardado el elemento en marcadores.",
			'bookmarks:delete:success' => "El marcador ha sido eliminado.",
	
		/**
		 * Error messages
		 */
	
			'bookmarks:save:failed' => "No se ha podido guardar el elemento en marcadores. Inténtalo de nuevo.",
			'bookmarks:delete:failed' => "No se ha podido eliminar el marcador. Inténtalo de nuevo.",
	
	
	);
					
	add_translation("es",$spanish);

?>