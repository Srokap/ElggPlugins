<?php

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messageboard:board' => "Tablón de mensajes",
			'messageboard:messageboard' => "tablón de mensajes",
			'messageboard:viewall' => "Ver todos",
			'messageboard:postit' => "Publicar",
			'messageboard:history' => "historial",
			'messageboard:none' => "Todavía no hay nada en este tablón de mensajes",
			'messageboard:num_display' => "Número de mensajes a mostrar",
			'messageboard:desc' => "Este es el tablón de mensajes que puedes poner en tu perfil y permite escribir comentarios a los demás usuarios.",
			
         /**
	     * Message board widget river
	     **/
	        
	        'messageboard:river:annotate' => "%s tiene un nuevo mensaje publicado en su tablón de mensajes.",
	        'messageboard:river:create' => "%s añadió el gadget del tablón de mensajes.",
	        'messageboard:river:update' => "%s actualizó el gadget de su tablón de mensajes.",
			
		/**
		 * Status messages
		 */
	
			'messageboard:posted' => "Has publicado en el tablón de mensajes.",
			'messageboard:deleted' => "Has eliminado el mensaje de tablón.",
	
		/**
		 * Email messages
		 */
	
			'messageboard:email:subject' => '¡Tienes un nuevo comentario en el tablón de mensajes!',
			'messageboard:email:body' => "Tienes un nuevo comentario de %s en tu tablón de mensajes. Dice:

			
%s


Para ver los comentarios de tu tablon, haz click aquí:

	%s

Para ver el perfil de %s, haz click aquí:

	%s

No respondas a este email, ha sido generado automáticamente por el sistema.",
	
		/**
		 * Error messages
		 */
	
			'messageboard:blank' => "Debes introducir algo en el área del mensaje antes de poder guardarlo.",
			'messageboard:notfound' => "No se ha podido encontrar el elemento indicado.",
			'messageboard:notdeleted' => "No ha sido posible eliminar el mensaje.",
	     
			'messageboard:failure' => "Se ha producido un error inesperado al añadir el mensaje. Inténtalo de nuevo.",
	
	);
					
	add_translation("es",$spanish);

?>