<?php
	/**
	 * Elgg log browser plugin language pack
	 * 
	 * @package ElggLogBrowser
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'logbrowser' => 'Revisar registro',
			'logbrowser:browse' => 'Revisar registro del sistema',
			'logbrowser:search' => 'Refinar resultados',
			'logbrowser:user' => 'Buscar por usuario',
			'logbrowser:starttime' => 'Hora inicial (por ejemplo "lunes pasado", "hace 1 hora")',
			'logbrowser:endtime' => 'Hora final',
	
			'logbrowser:explore' => 'Explorar registro',
	
	);
					
	add_translation("es",$spanish);
?>