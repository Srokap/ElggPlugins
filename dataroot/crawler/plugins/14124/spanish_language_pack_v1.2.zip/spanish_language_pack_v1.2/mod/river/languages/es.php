<?php

	$spanish = array(
	
		/**
		 * Manifest
		 */
		
	
		'river:widget:noactivity' => 'No se ha encontrado actividad.',
		'river:widget:title' => "Actividad",
		'river:widget:description' => "Ver tu actividad reciente.",
		'river:widget:title:friends' => "Actividad de amigos",
		'river:widget:description:friends' => "Mostrar lo que hacen tus amigos.",
	
		'river:widget:label:displaynum' => "Número de entradas a mostrar:",
	);
					
	add_translation("es",$spanish);

?>