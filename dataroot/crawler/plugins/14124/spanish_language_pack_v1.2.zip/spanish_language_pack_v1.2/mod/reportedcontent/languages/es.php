<?php
	/**
	 * Elgg reported content plugin language pack
	 * 
	 * @package ElggReportedContent
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'item:object:reported_content' => 'Elementos denunciados',
			'reportedcontent' => 'Contenido denunciado',
			'reportedcontent:this' => 'Denunciar este contenido',
			'reportedcontent:none' => 'No hay contenido denunciado',
			'reportedcontent:report' => 'Informar al administrador',
			'reportedcontent:title' => 'Título de la página',
			'reportedcontent:deleted' => 'El contenido denunciado ha sido borrado',
			'reportedcontent:notdeleted' => 'No se ha podido borrar el informe',
			'reportedcontent:delete' => 'Borrarlo',
			'reportedcontent:areyousure' => '¿Confirmas el borrado?',
			'reportedcontent:archive' => 'Archivarlo',
			'reportedcontent:archived' => 'El informe ha sido archivado',
			'reportedcontent:visit' => 'Visitar elemento denunciado',
			'reportedcontent:by' => 'Informado por',
			'reportedcontent:objecttitle' => 'Título del objeto',
			'reportedcontent:objecturl' => 'URL del objeto',
			'reportedcontent:reason' => 'Motivo de la denuncia',
			'reportedcontent:description' => '¿Por qué estas denunciándolo?',
			'reportedcontent:address' => 'Localización del elemento',
			'reportedcontent:success' => 'La denuncia ha sido enviada al administrador de la web',
			'reportedcontent:failing' => 'La denuncia no ha podido ser enviada',
			'reportedcontent:report' => 'Denunciar este contenido', 
	
			'reportedcontent:failed' => 'Ha fallado el intento de denunciar este contenido.',
	);
					
	add_translation("es",$spanish);
?>