<?php
	/**
	 * Elgg groups plugin language pack
	 * 
	 * @package ElggGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
			
			'groups' => "Grupos",
			'groups:owned' => "Tus grupos",
			'groups:yours' => "Grupos donde estás",
			'groups:user' => "grupos de %s",
			'groups:all' => "Todos los grupos",
			'groups:new' => "Crear un nuevo grupo",
			'groups:edit' => "Modificar grupo",
	
			'groups:icon' => 'Icono del grupo (dejar en blanco para no modificarlo)',
			'groups:name' => 'Nombre del grupo',
			'groups:username' => 'Nombre corto del grupo (mostrado en URLs, sólo caracteres alfanuméricos)',
			'groups:description' => 'Descripción',
			'groups:briefdescription' => 'Descripción abreviada',
			'groups:interests' => 'Intereses',
			'groups:website' => 'Sitio web',
			'groups:members' => 'En el grupo',
			'groups:membership' => "Grupos",
			'groups:access' => "Permisos de acceso",
			'groups:owner' => "Propietario",
	        'groups:widget:num_display' => 'Número de grupos a mostrar',
	        'groups:widget:membership' => 'Grupos',
	        'groups:widgets:description' => 'Mostrar los grupos a los que perteneces en tu perfil',
			'groups:noaccess' => 'Sin acceso al grupo',
			'groups:cantedit' => 'No puedes modificar este grupo',
			'groups:saved' => 'Grupo guardado',
	
			'groups:joinrequest' => 'Solicitar pertenecer',
			'groups:join' => 'Unirme al grupo',
			'groups:leave' => 'Abandonar grupo',
			'groups:invite' => 'Invitar a amigos',
			'groups:inviteto' => "Invitar a amigos a '%s'",
			'groups:nofriends' => "No tienes más amigos a los que no hayas invitado a este grupo.",
	
			'groups:group' => "Grupo",
			
			'item:object:groupforumtopic' => "Temas del foro",
	
			/*
			  Group forum strings
			*/
			
			'groups:forum' => 'Foro del grupo',
			'groups:addtopic' => 'Añadir un tema',
			'groups:forumlatest' => 'Recientes en el foro',
			'groups:latestdiscussion' => 'Últimos temas',
			'groupspost:success' => 'Se ha publicado tu comentario',
			'groups:alldiscussion' => 'Últimos temas',
			'groups:edittopic' => 'Modificar tema',
			'groups:topicmessage' => 'Mensaje del tema',
			'groups:topicstatus' => 'Estado del tema',
			'groups:reply' => 'Publicar un comentario',
			'groups:topic' => 'Tema',
			'groups:posts' => 'Comentarios',
			'groups:lastperson' => 'Última persona',
			'groups:when' => 'Cuando',
			'grouptopic:notcreated' => 'No hay temas creados.',
			'groups:topicopen' => 'Abierto',
			'groups:topicclosed' => 'Cerrado',
			'groups:topicresolved' => 'Resuelto',
			'grouptopic:created' => 'El tema ha sido creado.',
			'groupstopic:deleted' => 'El tema ha sido borrado.',
			'groups:topicsticky' => 'Pegajoso',
			'groups:topicisclosed' => 'Este tema está cerrado.',
			'groups:topiccloseddesc' => 'Este tema está cerrado y no acepta nuevos comentarios.',
			'grouptopic:error' => 'No se ha podido crear el tema del grupo. Inténtalo de nuevo o contacta con un administrador del sistema.',
	
			'groups:privategroup' => 'Este grupo es privado, solicitando pertenecer.',
			'groups:notitle' => 'Los grupos deben tener título',
			'groups:cantjoin' => 'No es posible unirse al grupo',
			'groups:cantleave' => 'No es posible abandonar el grupo',
			'groups:addedtogroup' => 'El usuario ha sido añadido al grupo',
			'groups:joinrequestnotmade' => 'No se ha podido hacer la solicitud para pertenecer al grupo',
			'groups:joinrequestmade' => 'Se ha hecho tu solicitud para unirte al grupo',
			'groups:joined' => '¡Te has unido al grupo!',
			'groups:left' => 'Has abandonado el grupo',
			'groups:notowner' => 'Lo sentimos, pero no eres el propietario de este grupo.',
			'groups:alreadymember' => '¡Ya eres miembro de este grupo!',
			'groups:userinvited' => 'El usuario ha sido invitado.',
			'groups:usernotinvited' => 'No se ha podido invitar al usuario.',
	
			'groups:invite:subject' => "%s has sido invitado a unirte a %s!",
			'groups:invite:body' => "Hola %s,

Te han invitado a unirte al grupo '%s', haz click a continuación para confirmar:

%s",

			'groups:welcome:subject' => "¡Bienvenido/a al grupo %s!",
			'groups:welcome:body' => "¡Hola %s!
		
Ahora eres miembro del grupo '%s'. Haz click abajo para empezar a publicar.

%s",
	
			'groups:request:subject' => "%s ha solicitado unirse a %s",
			'groups:request:body' => "Hola %s,

%s ha solicitado unirse al grupo '%s', haz click a continuación para ver su perfil:

%s

o haz click a continuación para confirmar la solicitud:

%s",
	
			'groups:river:member' => 'ahora es miembro de',
	
			'groups:nowidgets' => 'No hay gadgets definidos para este grupo.',
	
	
			'groups:widgets:members:title' => 'Grupo',
			'groups:widgets:members:description' => 'Listar los miembros de un grupo.',
			'groups:widgets:members:label:displaynum' => 'Listar los objetos de un grupo.',
			'groups:widgets:members:label:pleaseedit' => 'Este gadget debe ser configurado.',
	
			'groups:widgets:entities:title' => "Objectos en el grupo",
			'groups:widgets:entities:description' => "Listar los objeto guardados en este grupo",
			'groups:widgets:entities:label:displaynum' => 'Listar los objetos de un grupo.',
			'groups:widgets:entities:label:pleaseedit' => 'Este gadget debe ser configurado.',
		
			'groups:forumtopic:edited' => 'Tema del foro modificado satisfactoriamente.',
	);
					
	add_translation("es",$spanish);
?>