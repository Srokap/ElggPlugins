<?php

	$spanish = array(
	
		/**
		 * Friends widget
		 */
			'friends:widget:description' => "Muestra algunos de tus amigos.",
	        
		
	);
					
	add_translation("es",$spanish);

?>