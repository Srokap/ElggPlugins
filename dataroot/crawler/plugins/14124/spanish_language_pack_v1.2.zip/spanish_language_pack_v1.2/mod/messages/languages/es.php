<?php

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messages' => "Mensajes",
            'messages:back' => "volver a los mensajes",
			'messages:user' => "Tu bandeja de entrada",
			'messages:sentMessages' => "Mensajes enviados",
			'messages:posttitle' => "mensajes de %s: %s",
			'messages:inbox' => "Bandeja de entrada",
			'messages:send' => "Enviar un mensaje",
			'messages:sent' => "Mensajes enviados",
			'messages:message' => "Mensaje",
			'messages:title' => "Título",
			'messages:to' => "Para",
            'messages:from' => "De",
			'messages:fly' => "Déjalo volar",
			'messages:replying' => "Mensaje respondiendo a",
			'messages:inbox' => "Bandeja de entrada",
			'messages:sendmessage' => "Enviar un mensaje",
			'messages:compose' => "Enviar un mensaje",
			'messages:sentmessages' => "Mensajes enviados",
			'messages:recent' => "Mensajes recientes",
            'messages:original' => "Mensaje original",
            'messages:yours' => "Tu mensaje",
            'messages:answer' => "Responder",
			
			'item:object:messages' => 'Mensajes',
	
		/**
		 * Status messages
		 */
	
			'messages:posted' => "El mensaje ha sido enviado.",
			'messages:deleted' => "El mensaje ha sido eliminado.",
	
		/**
		 * Email messages
		 */
	
			'messages:email:subject' => '¡Tienes un mensaje nuevo!',
			'messages:email:body' => "Tienes un mensaje nuevo de %s. Dice:

			
%s


Para ver tus mensajes, haz click aquí:

	%s

Para enviar un mensaje a %s, haz click aquí:

	%s

No respondas a este email, ha sido generado automáticamente por el sistema.",
	
		/**
		 * Error messages
		 */
	
			'messages:blank' => "Debes introducir algo en el cuerpo del mensaje antes de poder guardarlo.",
			'messages:notfound' => "No ha sido posible encontrar el mensaje especificado.",
			'messages:notdeleted' => "No ha sido posible eliminar este mensaje.",
			'messages:nopermission' => "No tienes permiso para eliminar este mensaje.",
			'messages:nomessages' => "No hay mensajes para mostrar.",
			'messages:user:nonexist' => "No ha sido posible encontrar el destinatario en la base de datos de usuarios.",
	
	);
					
	add_translation("es",$spanish);

?>