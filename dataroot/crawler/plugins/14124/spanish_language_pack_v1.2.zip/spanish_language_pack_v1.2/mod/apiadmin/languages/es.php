<?php
	/**
	 * API Admin language pack.
	 * 
	 * @package ElggAPIAdmin
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */


	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'apiadmin' => 'Administrar API',
	
	
			'apiadmin:keyrevoked' => 'Clave API revocada',
			'apiadmin:keynotrevoked' => 'La clave API no ha podido ser revocada',
			'apiadmin:generated' => 'Clave API generada correctamente',
	
			'apiadmin:yourref' => 'Tu referencia',
			'apiadmin:generate' => 'Generar un nuevo par de claves',
	
			'apiadmin:noreference' => 'Debes proporcionar una referencia para tu nueva cave.',
			'apiadmin:generationfail' => 'Ha habido un problema al generar el nuevo par de claves',
			'apiadmin:generated' => 'El nuevo par de claves API ha sido generado correctamente',
	
			'apiadmin:revoke' => 'Revocar clave',
			'apiadmin:public' => 'Pública',
			'apiadmin:private' => 'Privada',

	
			'item:object:api_key' => 'Claves API',
	);
					
	add_translation("es",$spanish);
?>