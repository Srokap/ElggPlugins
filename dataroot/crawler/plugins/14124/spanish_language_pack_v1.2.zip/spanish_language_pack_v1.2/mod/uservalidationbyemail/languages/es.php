<?php
	/**
	 * Email user validation plugin language pack.
	 * 
	 * @package ElggUserValidationByEmail
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$spanish = array(
	
		'email:validate:subject' => "¡%s por favor confirma tu dirección de email!",
		'email:validate:body' => "Hola %s,

Por favor, confirma tu dirección de email haciendo click en el siguiente enlace:

%s
",
		'email:validate:success:subject' => "¡Email validado %s!",
		'email:validate:success:body' => "Hola %s,
			
Felicidades, has validado tu dirección de email.",
	
		'uservalidationbyemail:registerok' => "Para activar tu cuenta, por favor confirma tu dirección de email haciendo click en el enlace que te hemos enviado."
	
	);
					
	add_translation("es",$spanish);
?>