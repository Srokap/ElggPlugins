<?php
	/**
	 * Elgg file plugin language pack
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'file' => "Ficheros",
			'files' => "Ficheros",
			'file:yours' => "Tus ficheros",
			'file:yours:friends' => "Ficheros de tus amigos",
			'file:user' => "Ficheros de %s",
			'file:friends' => "Ficheros de los amigos de %s",
			'file:all' => "Todos los ficheros",
			'file:edit' => "Modificar fichero",
			'file:more' => "más ficheros",
			'file:list' => "vista: lista",
			'file:group' => "Ficheros del grupo",
			'file:gallery' => "vista: galería",
			'file:gallery_list' => "Vista: galería o lista",
			'file:num_files' => "Número de ficheros a mostrar",
			'file:user:gallery'=>'Ver galería de %s', 
	
			'file:upload' => "Subir un fichero",
			
			'file:file' => "Fichero",
			'file:title' => "Título",
			'file:desc' => "Descripción",
			'file:tags' => "Etiquetas",
	
			'file:types' => "Tipos de fichero subidos",
	
			'file:type:all' => "Todos los ficheros",
			'file:type:video' => "Vídeos",
			'file:type:document' => "Documentos",
			'file:type:audio' => "Audio",
			'file:type:image' => "Imágenes",
			'file:type:general' => "General",
	
			'file:user:type:video' => "vídeos de %s",
			'file:user:type:document' => "documentos de %s",
			'file:user:type:audio' => "audio de %s",
			'file:user:type:image' => "imagenes de %s",
			'file:user:type:general' => "archivos generales de %s",
	
			'file:friends:type:video' => "Vídeos de tus amigos",
			'file:friends:type:document' => "Documentos de tus amigos",
			'file:friends:type:audio' => "Audio de tus amigos",
			'file:friends:type:image' => "Imagenes de tus amigos",
			'file:friends:type:general' => "Archivos generale de tus amigos",
	
			'file:widget' => "Gadget de ficheros",
			'file:widget:description' => "Presentación de tus ficheros más recientes",
	
			'file:download' => "Descargar esto",
	
			'file:delete:confirm' => "¿Confirmas el borrado de este fichero?",
			
			'file:tagcloud' => "Nube de etiquetas",
	
			'file:display:number' => "Número de ficheros a mostrar",
	
			'file:river:created' => "%s subido",
			'file:river:item' => "un archivo",
			'file:river:annotate' => "%s comentó el",

			'item:object:file' => 'Ficheros',
			
	    /**
		 * Embed media
		 **/
		 
		    'file:embed' => "Incrustar medios",
		    'file:embedall' => "Todos",
	
		/**
		 * Status messages
		 */
	
			'file:saved' => "El fichero se ha guardado satisfactoriamente.",
			'file:deleted' => "El fichero ha sido eliminado satisfactoriamente.",
	
		/**
		 * Error messages
		 */
	
			'file:none' => "En este momento no se ha podido encontrar ningún fichero.",
			'file:uploadfailed' => "No se ha podido guardar tu fichero.",
			'file:downloadfailed' => "Este fichero no está disponible en este momento.",
			'file:deletefailed' => "El fichero no ha podido ser eliminado en este momento.",
	
	);
					
	add_translation("es",$spanish);
?>