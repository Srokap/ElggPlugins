<?php

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'status' => "Estado",
			'status:user' => "Estado de %s",
			'status:current'=> "Estado actual",
			'status:desc'=> "Este gadget de estado muestra tu estado reciente.",
			'status:posttitle' => "estado de %s: %s",
			'status:everyone' => "Todos los usuarios",
			'status:strapline' => "%s",
			'status:addstatus' => "Definir tu estado",
		    'status:messages' => "Mensajes de estado",
			'status:text' => "Estado:",
			'status:set' => "establecido ",
			'status:clear' => "limpiar estado",
			'status:delete' => "borrar estado",
			'status:nostatus' => "No se ha establecido el estado.",
			'status:viewhistory' => "ver historial",
	
			'item:object:status' => 'Mensajes de estado',
	
	
        /**
	     * Status river
	     **/
	        
	        //generic terms to use
	        'status:river:created' => "%s actualizado",
	        
	        //these get inserted into the river links to take the user to the entity
	        'status:river:create' => "sus estados.",
	        
	        
	
		/**
		 * Status messages
		 */
	
			'status:posted' => "Se ha publicado tu nuevo estado.",
			'status:deleted' => "Se ha borrado tu estado.",
	
		/**
		 * Error messages
		 */
	
			'status:blank' => "Debes introducir un mensaje de estado antes de guardarlo.",
			'status:notfound' => "No se ha podido encontrar el mensaje de estado indicado.",
			'status:notdeleted' => "El mensaje de estado no ha podido ser borrado.",
			'status:notsaved' => "Se ha producir un error al guardar, inténtalo de nuevo o consulta con el administrador.",
			'status:problem' => "Ha habido un problema. Parece que no puedes modificar este estado.",
	
	);
					
	add_translation("es",$spanish);

?>