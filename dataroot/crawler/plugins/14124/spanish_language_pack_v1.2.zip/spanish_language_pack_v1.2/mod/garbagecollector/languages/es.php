<?php
	/**
	 * Elgg garbage collector language pack.
	 * 
	 * @package ElggGarbageCollector
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'garbagecollector:period' => '¿Con qué frecuencia deberia ejecutarse el recolector de basura de Elgg?',
	
			'garbagecollector:weekly' => 'Una vez por semana',
			'garbagecollector:monthly' => 'Una vez al mes',
			'garbagecollector:yearly' => 'Una vez al año',
	
			'garbagecollector' => "RECOLECTOR DE BASURA\n",
			'garbagecollector:done' => "FINALIZADO\n",
			'garbagecollector:optimize' => "Optimizando %s ",
	
			'garbagecollector:error' => "ERROR",
			'garbagecollector:ok' => "OK",
	
			'garbagecollector:gc:metastrings' => 'Limpiando cadenas meta no enlazadas: ',
	
	);
					
	add_translation("es",$spanish);
?>