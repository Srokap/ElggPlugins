<?php

	/**
	 * Update client language pack.
	 * 
	 * @package ElggUpdateClient
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */	

	$spanish = array(
	
		'updateclient:label:core' => 'Núcleo',
		'updateclient:label:plugins' => 'Plugins',
	
		'updateclient:settings:days' => 'Comprobar actualizaciones cada',
		'updateclient:days' => 'días',
	
		'updateclient:settings:server' => 'Servidor de actualizaciones',
	
		'updateclient:message:title' => '¡Liberada nueva versión de Elgg!',
		'updateclient:message:body' => '¡Se ha liberado una nueva versión de Elgg (%s %s) con nombre en código "%s"!
		
Puedes ir aquí para descargarla: %s

O más abajo puedes leer las notas de la versión:

%s',
	);
					
	add_translation("es", $spanish);
?>