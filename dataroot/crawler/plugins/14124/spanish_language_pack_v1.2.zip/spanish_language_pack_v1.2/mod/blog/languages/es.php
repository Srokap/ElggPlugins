<?php

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'blog' => "Blog",
			'blogs' => "Blogs",
			'blog:user' => "el blog de %s",
			'blog:user:friends' => "blog de los amigos de %s",
			'blog:your' => "Tu blog",
			'blog:posttitle' => "blog de %s: %s",
			'blog:friends' => "Blogs de tus amigos",
			'blog:yourfriends' => "Últimos blogs de tus amigos",
			'blog:everyone' => "Todos los blogs",
	
			'blog:read' => "Leer blog",
	
			'blog:addpost' => "Escribir una entrada",
			'blog:editpost' => "Modificar una entrada del blog",
	
			'blog:text' => "Texto de la entrada",
	
			'blog:strapline' => "%s",
			
			'item:object:blog' => 'Entradas del blog',
	
			
         /**
	     * Blog river
	     **/
	        
	        //generic terms to use
	        'blog:river:created' => "%s escribió",
	        'blog:river:updated' => "%s actualizó",
	        'blog:river:posted' => "%s publicó",
	        
	        //these get inserted into the river links to take the user to the entity
	        'blog:river:create' => "una nueva entrada en el blog.",
	        'blog:river:update' => "una entrada en el blog.",
	        'blog:river:annotate:create' => "un comentario en la entrada del blog.",
			
	
		/**
		 * Status messages
		 */
	
			'blog:posted' => "La entrada ha sido publicada en el blog.",
			'blog:deleted' => "La entrada ha sido eliminada del blog.",
	
		/**
		 * Error messages
		 */
	
			'blog:save:failure' => "La entrada no ha podido ser guardada en el blog. Inténtalo de nuevo.",
			'blog:blank' => "Es necesario rellenar el título y el texto para poder publicar la entrada.",
			'blog:notfound' => "No ha sido posible encontrar la entrada especificada en el blog.",
			'blog:notdeleted' => "No ha sido posible eliminar la entrada del blog.",
	
	);
					
	add_translation("es",$spanish);

?>