<?php
	echo $vars['url'] . "mod/socializeme/graphics/file_icons/pages.gif";
?>