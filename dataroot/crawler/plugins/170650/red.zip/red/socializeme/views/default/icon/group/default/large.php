<?php
	echo $vars['url'] . "mod/socializeme/graphics/group_icons/defaultlarge.gif";
?>