<?php

/**
* Oddbod edit page
*
* @package Oddbod
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author Alistair Young <alistair@codebrane.com>
* @copyright codeBrane 2009
* @link http://codebrane.com/blog/
*/

?>
	<p>
		edit Oddbod!
	</p>