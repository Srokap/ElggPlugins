<?php
/**
 * Oddbod threw a wobbly!
 * 
 * @author alistair
 *
 */
class OddbodException extends Exception {
}
?>