class Member
  attr_reader :username
  
  def initialize(username)
    @username = username
  end
end