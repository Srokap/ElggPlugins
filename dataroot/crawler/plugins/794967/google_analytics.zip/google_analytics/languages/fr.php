<?php

/* ***********************************************************************
 * @author : Purusothaman Ramanujam
 * @link http://www.iYaffle.com/
 * Under this agreement, No one has rights to sell this script further.
 * ***********************************************************************/

add_translation('fr', array(
    'google-analytics:lblID' => 'Analytics Tracker ID: ',
    'google-analytics:lblExample' => '(Par exemple: UA-1234567-8)',
    'google-analytics:lblHelp' => "Pour plus d'informations visitez "
));