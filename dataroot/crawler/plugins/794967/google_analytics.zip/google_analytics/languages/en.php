<?php

/* ***********************************************************************
 * @author : Purusothaman Ramanujam
 * @link http://www.iYaffle.com/
 * Under this agreement, No one has rights to sell this script further.
 * ***********************************************************************/

add_translation('en', array(
    'google-analytics:lblID' => 'Analytics Tracker ID: ',
    'google-analytics:lblExample' => '(looks like UA-1234567-8)',
    'google-analytics:lblHelp' => 'For more information please visit '
));