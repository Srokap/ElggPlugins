<?php

elgg_register_event_handler('init', 'system', 'thegarage');

function thegarage_init() {
        elgg_extend_view('css/elgg', 'thegarage/css');
    
		} 

?>