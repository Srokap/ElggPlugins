<?php
/**
 * Page Layout
 ************ Your Garage  ****************
 * Contains CSS for the page shell and page layout
 *
 * Default layout: 990px wide, centered. Used in default page shell
 *
 */
?>

/* ***************************************
	PAGE LAYOUT
*************************************** */
/***** DEFAULT LAYOUT ******/

body {
background: url('http://localhost/iconMx/mod/yourgarage/graphics/bkgr.gif');
background-attachment: fixed;
}



body {
background: url('http://localhost/iconMx/mod/yourgarage/graphics/bkgr.gif');
background-attachment: fixed;
}


.elgg-page-default .elgg-page-header .elgg-inner {
width: 998px;
height: 200px;
background: url('http://localhost/iconMx/mod/yourgarage/graphics/headimg.jpg');
}



.elgg-button-submit {
	color: white;
	text-shadow: 1px 1px 0px black;
	text-decoration: none;
	border: 1px solid #000;
	background: #A95E27 url(<?php echo elgg_get_site_url(); ?>_graphics/button_graduation.png) repeat-x left 10px;
}

.elgg-button-submit:hover {
	border-color: #000;
	text-decoration: none;
	color: white;
	background:  #000000 url(<?php echo elgg_get_site_url(); ?>_graphics/button_graduation.png) repeat-x left 10px;
}

.elgg-breadcrumbs > li > a:hover {
	color: #000000;
	text-decoration: underline;
}

.elgg-menu-site-more > li > a:hover {
	background: #000000; 
	color: white;
}

.elgg-menu-page a:hover {
	background-color: #000000; 
	color: white;
	text-decoration: none;
}

.elgg-menu-owner-block li a:hover {
	background-color: #000000; 
	color: white;
	text-decoration: none;
}

a {
	color: #A95E27;
}

h1, h2, h3, h4, h5, h6 {
	font-weight: bold;
	color: #035AB8; 
}

.elgg-heading-basic {
	color: #000000;
	font-size: 1.2em;
	font-weight: bold;
}

.elgg-loud {
	color: #000000; 
}



.elgg-menu-page li.elgg-state-selected > a {
	background-color: #000000; 
	color: white;
}

.elgg-heading-site, .elgg-heading-site:hover {
	font-size: 2em;
	line-height: 1.4em;
	color: #000;
	font-style: italic;
	font-family: Georgia, times, serif;
	text-shadow: 1px 2px 4px #333333;
	text-decoration: none;
   background: #fff;
	padding: 20px;
	padding-left: 15px;
}

.elgg-page-default .elgg-page-header  .elgg-inner {
	width: 998px;
	height: 200px
   background: #000000;
}

.elgg-page-default {
	width: 998px;
	margin: 0px auto; 
	border-right: 1pxwidth solid 1px;
        background: #ffffff;
        border-left: 1px width solid 1px;
	-moz-box-shadow: 0 0 10px #888;
	-webkit-box-shadow: 0 0 10px #888;
	box-shadow: 0 0 10px #181a2f;
}

.elgg-heading-site, .elgg-heading-site:hover {
	-webkit-border-bottom-right-radius: 24px;
	-moz-border-bottom-right-radius: 24px;
	border-bottom-right-radius: 24px;
	opacity: 0.6;
	-ms-filter:\"progid:DXImageTransform.Microsoft.Alpha(Opacity=60)\";
        filter: alpha(opacity=60);
}

.elgg-page-footer {
	height: 100px;
}

.elgg-page-footer {
       color: #999; 
       background: #000000;   
}
.elgg-page-footer a:link {
	color: #CCCCCC;
}
      
.elgg-page-footer a:hover {
	color: #CCCCCC;
}
#login-dropdown {
	position: absolute;
	top: 10px;
	right: 0;
	z-index: 100;  
	margin-right: 10px;          
}


.elgg-menu-item-report-this{
        margin-left: 10px;
	margin-top: 5px;
}




.elgg-page-default {
	min-width: 998px;
}

.elgg-page-default .elgg-page-body > .elgg-inner {
	width: 998px
	margin: 0 auto;        
	
}

.elgg-page-default .elgg-page-footer > .elgg-inner {
	width: 998px; 
	margin: 0 auto;
	padding: 5px 0;
	border-top: 1px solid #DEDEDE;
	
}

.elgg-page-header .elgg-search {
        margin-top: 110px;
	margin-bottom: 2px;
        margin-right: 5px;
	height: 23px;
	position: absolute;
	right: 0;
       
}

.elgg-menu-footer-default {
	float: right;
	padding-right: 10px;
}

.elgg-menu-site-default{
	background: black; 
	padding-top: 5px; 
	width: 100%;
}

.tg-module-message {	
	border: 1px solid <?php echo $etmod; ?>;
	padding: 15px;
	margin-bottom: 20px;
	min-height: 190px;
        height: auto !important; 
        height: 190px;
	-webkit-border-radius: 6px;
	-moz-border-radius: 6px;
	border-radius: 6px;
	
}

.tg-module-message h3{
	margin-bottom: 15px;
}

.tg-module-message h2{
	margin-bottom: 12px;
}
.tg-module-message p{
	margin-left: 10px;          
}

/*************************************steve test end*****************/


/***** TOPBAR ******/
.elgg-page-topbar {
	background: #333333 url(<?php echo elgg_get_site_url(); ?>_graphics/toptoolbar_background.gif) repeat-x top left;
	border-bottom: 1px solid #000000;
	position: relative;
	height: 24px;
	z-index: 9000;
}
.elgg-page-topbar > .elgg-inner {
	padding: 0 10px;
}

/***** PAGE MESSAGES ******/
.elgg-system-messages {
	position: fixed;
	top: 24px;
	right: 20px;
	max-width: 500px;
	z-index: 2000;
}
.elgg-system-messages li {
	margin-top: 10px;
}
.elgg-system-messages li p {
	margin: 0;
}

/***** PAGE HEADER ******/
.elgg-page-header {
	position: relative;
	background: #fff url(<?php echo elgg_get_site_url(); ?>_graphics/header_shadow.png) repeat-x bottom left;
}
.elgg-page-header > .elgg-inner {
	position: relative;
}

/***** PAGE BODY LAYOUT ******/
.elgg-layout {
	min-height: 360px;
}
.elgg-layout-one-sidebar {
	background: transparent url(<?php echo elgg_get_site_url(); ?>mod/yourgarage/graphics/sidebar_background.gif) repeat-y right top;
}
.elgg-layout-two-sidebar {
	background: transparent url(<?php echo elgg_get_site_url(); ?>_graphics/two_sidebar_background.gif) repeat-y right top;
}
.elgg-sidebar {
	position: relative;
	padding: 20px 10px;
	float: right;
	width: 210px;
	margin: 0 0 0 10px;
	
}
.elgg-sidebar-alt {
	position: relative;
	padding: 20px 10px;
	float: left;
	width: 160px;
	margin: 0 10px 0 0;
	
}
.elgg-main {
	position: relative;
	min-height: 360px;
	padding: 10px;
}
.elgg-main > .elgg-head {
	padding-bottom: 3px;
	border-bottom: 1px solid #CCCCCC;
	margin-bottom: 10px;
}

/***** PAGE FOOTER ******/
.elgg-page-footer {
	position: relative;
}
.elgg-page-footer {
	color: #999;
}
.elgg-page-footer a:hover {
	color: #666;
}
