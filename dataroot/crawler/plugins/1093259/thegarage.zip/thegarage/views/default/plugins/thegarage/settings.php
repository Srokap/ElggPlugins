Enter in the contents for the custom_index.php front page and click the save button.<br /><br />

<?php
$context = elgg_get_context();
$my_contents = elgg_get_plugin_setting('my_contents', 'thegarage');
    echo elgg_view('input/longtext', array(

        'name'  => 'params[my_contents]',

        'value' => $my_contents,

    ));
?>
