The Garage
**********
Updated 9-12-12 removed unused code in setting that may have been causing TinyMCE to stall.

This theme was built by Steve over at iconMatrix.com, part of the embrache team.

Note: Adding a "Site Introduction" requires the "Custom Index" plugin to be active.


What Is The Garage?

The Garage is starting point for an automotive social website. Since we are talking cars here, we over at iconMatrix thought being car enthusiasts, that we would like to hang out in The Garage rather than in a Group. This allows all of us to visit each other's garages and ooh and ahh over what is inside your garage.  Strike up discussions on or about your rides. You still can have a souped up profile too. So lets see you guys and gals put your show pieces in The Garage. Invite others to see and join your collections.

Things you should know:

	the header picture width 998px and height is 200px and is at mod/thegarage/graphics/headimg.jpg 
	
	photographer is http://www.flickr.com/photos/jreed/217095027/
	
	the background picture is located at mod/thegarage/graphics/bkgr.gif
	
	the css is controled in mod/thegarage/views/default/css/elements/layout.php
_________________________________________________________________________________________________________
               For updates  - check the elgg repo for The Garage 
********************************************************************************************************* 


