To add more links/to edit existing links go to views/default/widgets/directlinks/view.php

