<?php

	/**
	 * Elgg directlinks Plugin
	 * 
	 * @package directlinks
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Jayadeep P J
	 * @copyright Jayadeep P J 2009
	 * @link http://nezted.com/
	 * 
	 */
	
		function directlinks_init() {
    		
    		
			
    		//add a widget
			    add_widget_type('directlinks',elgg_echo("directlinks:title"),elgg_echo("directlinks:description"));
			
		}
		
		register_elgg_event_handler('init','system','directlinks_init');

?>