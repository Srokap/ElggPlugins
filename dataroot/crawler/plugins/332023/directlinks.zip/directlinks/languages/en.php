<?php

	$english = array(
	
		     
	        'directlinks:title' => "Miniprofile",
	        'directlinks:description' => "miniprofile widget"
	        
		
	);
					
	add_translation("en",$english);

?>