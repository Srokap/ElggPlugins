<?php

/*
** Contacts (as opposed to friends)
**
** @author Philip Hart, Centre for Learning and Performance Technology (www.c4lpt.co.uk)
** @copyright Tesserae Ltd 2009
** @link http://www.c4lpt.co.uk/ElggConsultancy.html
** @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
**
*/

$english = array(
    'friends' => "Contacts",
    'friends:yours' => "Your contacts",
    'friends:owned' => "%s's contacts",
    'friends:add:successful' => "You have successfully added %s as a contact.",
    'friends:add:failure' => "We couldn't add %s as a contact. Please try again.",
    'friends:remove:successful' => "You have successfully removed %s from your contacts.",
    'friends:remove:failure' => "We couldn't remove %s from your contacts. Please try again.",
    'friends:none' => "This user hasn't added anyone as a contact yet.",
    'friends:none:you' => "You haven't added anyone as a contact! Search for your interests to begin finding people to follow.",
    'friends:none:found' => "No contacts were found.",
    'friends:of:none' => "Nobody has added this user as a contact yet.",
    'friends:of:none:you' => "Nobody has added you as a contact yet. Start adding content and fill in your profile to let people find you!",
    'friends:of' => "Contacts of",
    'friends:of:owned' => "People who have made %s as a contact",
    'friends:num_display' => "Number of contacts to display",
    'friends' => "Contacts",
    'friends:of' => "Contact of",
    'friends:collections' => "Collections of contacts",
    'friends:collections:add' => "New collection of contacts",
    'friends:addfriends' => "Add contacts",
    'friends:collectionname' => "Collection name",
    'friends:collectionfriends' => "Contacts in collection",
    'friends:river:created' => "%s added the contacts widget.",
    'friends:river:updated' => "%s updated their contacts widget.",
    'friends:river:delete' => "%s removed their contacts widget.",
    'friends:river:add' => "%s added a new contact",

    'river:relationship:friend' => "is now a contact of",

    'friend:add' => "Add as a contact",
    'friend:remove' => "Remove as a contact",
    'friend:newfriend:subject' => "%s has added you as a contact!",
    'friend:newfriend:body' => "%s has added you as a contact!

To view their profile, click here:

%s

You cannot reply to this email.",

    'friends:all' => "All contacts",

    'friends:invite' => 'Invite contacts',
    'invitefriends:introduction' => 'To invite contacts to join you on this network, enter their email addresses below (one per line):',
    'invitefriends:success' => 'Your contacts were invited.',
    'invitefriends:failure' => 'Your contacts could not be invited.',

    'file:yours:friends' => "Your contacts' files",
    'file:friends' => "%s's contacts' files",
    'file:friends:type:video' => "Your contacts' videos",
    'file:friends:type:document' => "Your contacts' documents",
    'file:friends:type:audio' => "Your contacts' audio",
    'file:friends:type:image' => "Your contacts' pictures",
    'file:friends:type:general' => "Your contacts' general files",

    'access:friends:label' => "Contacts",

    'feeds:friends' => "Contacts feeds",
    'feeds:friendsfeeds' => 'Contacts\' feeds',
    'feeds:friendswelcome' => "This page lets you view all of the feeds your contacts have made available to their network. If any are available, you will see a list over on the righthand side. Click on a link to read the contents",

    'river:widget:title:friends' => "Contacts' activity",
    'river:widget:description:friends' => "Show what your contacts are up to.",

    'bookmarks:friends' => "Contacts' bookmarks",

    'river:widget:title:friends' => "Contacts' activity",
    'river:widget:description:friends' => "Show what your contacts are up to.",
    'river:widgets:friends' => "Contacts",

    'thewire:friendsdesc' => 'This widget will show the latest from your contacts on the wire',
    'thewire:friends' => 'Your contacts on the wire',

    'blog:user:friends' => "%s's contacts' blog",
    'blog:friends' => "Contacts' blogs",

    'elggchat:friendspicker:info' => "Contacts online",

);

add_translation("en", $english);

?>
