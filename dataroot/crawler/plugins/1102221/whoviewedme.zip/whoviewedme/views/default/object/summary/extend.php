<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


if(elgg_get_context()=="whoviewedme"){
    $ent = $vars['entity'];
    
    	if (!elgg_instanceof($ent, 'user', 'member')) {
            $relationship = get_relationship($ent->id);
                
          $date = elgg_view_friendly_time($relationship->time_created);
                
          echo $date;           
        }

}
