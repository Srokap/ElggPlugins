<?php
/**
 * whoviewedme plugin intialization
 */

elgg_register_event_handler('init', 'system', 'whoviewedme_init');

/**
 * Initialize page handler and site menu item
 */
function whoviewedme_init() {
	elgg_register_page_handler('whoviewedme', 'whoviewedme_page_handler');
        
        elgg_extend_view("profile/wrapper", "whoviewedme/record");

        if(elgg_is_logged_in()){
            $item = new ElggMenuItem('whoviewedme', elgg_echo('whoviewedme'), 'whoviewedme');
            elgg_register_menu_item('site', $item);
        }
}

/**
 * whoviewedme page handler
 *
 * @param array $page url segments
 * @return bool
 */
function whoviewedme_page_handler($page) {
    
    gatekeeper();
	$base = elgg_get_plugins_path() . 'whoviewedme/pages/whoviewedme';

	require_once "$base/index.php";
	
	return true;
}
