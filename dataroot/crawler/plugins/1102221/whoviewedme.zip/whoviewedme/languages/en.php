<?php
/**
 * Members English language file
 */

$english = array(
	'whoviewedme' => "Who Viewed Me",
        'whoviewedme:nobody' => "Nobody has viewed your profile recently"
);

add_translation('en', $english);
