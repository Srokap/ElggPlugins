<?php

	
	$user = get_loggedin_user();
	// Get other conversations
	$others = list_other_conversations($user->guid);
	

	// Show the content
	
	echo "<h3>" . elgg_echo('conversations:area3:title') . "</h3>";
	if($others){
		foreach($others as $other){
			
			// Get the other member
			$owner = get_entity($other->owner_guid);
			if($owner->guid == $user->guid){
				$owner = get_entity($other->receiver);
			}
			
			// Get their icon
			$icon = elgg_view("profile/icon", array("entity" => $owner, "size" => "tiny", "override" => TRUE));
			
			echo "<span class='convo_others_cover tipclass' title='{$owner->name}'><a onclick='open_convo({$other->guid});'>{$icon}</a></span>";
		}
	}
	$my_notify = get_user_notification_settings ($user->guid);
	echo $my_notify->value;
?>
