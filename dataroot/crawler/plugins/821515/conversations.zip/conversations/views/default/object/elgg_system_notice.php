<?php

/**
 * Elgg conversations/messages plugin
 * This plugin replaces the standard messages plugin with a conversation style system, 
 * 
 * @package Elggmembers
 * @author Trajan
 */


 if (isset($vars['entity'])) {
				
		// Should we show full view?
		if (isset($vars['full']) && $vars['full'] == true) {
				$fullview = true;
		}
	
		if (get_context() == "search") {
				
			//display the correct layout depending on gallery or list view
			if (get_input('search_viewtype') == "gallery") {

				//display the gallery view
       				echo elgg_view("conversations/notice_gallery",$vars);

			} else {
				
				echo elgg_view("conversations/notice_listing",$vars);

			}
				
		} else {
 
 
 
$ts = time();
$token = generate_action_token($ts);

// If unread delete the metadata to set it as read
$status = $vars['entity']->status;
if($status == "unread"){
	delete_metadata($status->id);
}


?>

<div class="conversation_object_holder">

	<!-- Show the conversation on the right -->
	<div id='conversation_object_messages'>
	
	<?php
		echo "<h3>{$vars['entity']->title}</h3><br>";
		
		echo "<p>{$vars['entity']->description}</p>";
		
		echo "<a href='{$vars['url']}action/conversations/delete_notice?notice={$vars['entity']->guid}&__elgg_token=$token&__elgg_ts=$ts'>" . elgg_echo('system:notice:delete') . "</a>";

	?>
	</div>
	
	<div class='clearfloat'></div>
	
	
	
</div>

<?php

	} // End else statement if not search
} // End if is set
?>