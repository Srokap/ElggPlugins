<?php

	/**
	 * Elgg conversations/messages plugin
	 * This plugin replaces the standard messages plugin with a conversation style system, 
	 * 
	 * @package Elggmembers
	 * @author Trajan
	 */

?>

.convo_message_list_holder {
	padding:3px;
	margin: 0 0 0 0;
	background: none;
	border-top: 1px solid #FFFFFF;
	border-left: 1px solid #FFFFFF;
	border-right: 1px solid #FFFFFF;
	border-bottom: 1px solid #E8E8E8;
	-ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)";
	filter: alpha(opacity=50);
	-moz-opacity: 0.5;
	-khtml-opacity: 0.5;
	opacity: 0.5;
}
.convo_message_list_holder_new {
	padding:3px;
	margin: 0 0 0 0;
	background: none;
	
}
.convo_message_list_holder:hover {
	-ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)";
	filter: alpha(opacity=100);
	-moz-opacity: 1.0;
	-khtml-opacity: 1.0;
	opacity: 1.0;
}
.convo_message {
	padding:0;
	margin:0;
	float:left;
	width:650px;
	background: none;
	border-bottom: 1px solid #E8E8E8;
}
.convo_message_icon {
	float:left;
	width:45px;
	padding:0;
	margin:0;
}
.convo_message_content {
	float:left;
	width: 590px;
	border-left: 2px solid #E8E8E8;
	padding: 3px;
}
.convo_message_controls {
	display:none;
}
.convo_message .convo_message_controls, .convo_message:hover convo_message_controls {
	display: block;
}
.convo_list_title {
	cursor:pointer;
	text-decoration:none;
}
.convo_others_cover {
	width:20px;
	height:20px;
	z-index: 100;
	-ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)";
	filter: alpha(opacity=50);
	-moz-opacity: 0.5;
	-khtml-opacity: 0.5;
	opacity: 0.5;
	cursor:pointer;
}
.convo_others_cover:hover {
	-ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)";
	filter: alpha(opacity=100);
	-moz-opacity: 1.0;
	-khtml-opacity: 1.0;
	opacity: 1.0;
}
.convos_inbox_bar {
	background: #F7F494;
	margin:10px 0 10px 0;
	border: 1px solid #E3AF05;
	padding:10px;
	text-align:right;
}
.convos_widget_holder {
	float:left;
}
.convo_widget_box {
	padding:0 0 0 3px;
	margin:0;
	float:left;
	width:300px;
	background: none;
	border-bottom: 1px solid #E8E8E8;
}
.convo_widget_icon {
	float:left;
	width: 20px;
	padding:0;
	margin:0;
}
.convo_widget_content {
	float:left;
	width:250px;
	border-left: 2px solid #E8E8E8;
	padding: 3px;
	margin: 0 0 0 3px;
}