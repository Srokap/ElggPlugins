<?php


$user = get_loggedin_user();
$ts = time();
$token = generate_action_token($ts);


// If unread delete the metadata to set it as read
$status = $vars['entity']->status;
if($status == "unread"){
		echo "<div class='convo_message_list_holder' id='system_message_list_holder_{$vars['entity']->guid}'>";
	}else{
		echo "<div class='convo_message_list_holder_new' id='system_message_list_holder_{$vars['entity']->guid}'>";
	}
		echo "<h3><a id='listing_open_link_{$vars['entity']->guid}' style='cursor:pointer;text-decoration:none;' onclick='open_notice({$vars['entity']->guid})'>{$vars['entity']->title}</a></h3>";
		echo "<span style='float:right;'>";
		echo "<a style='cursor:pointer;' onclick='delete_notice({$vars['entity']->guid});'>" . elgg_echo('system:notice:delete') . "</a>";
		echo "</span>";
	echo "</div>";
?>