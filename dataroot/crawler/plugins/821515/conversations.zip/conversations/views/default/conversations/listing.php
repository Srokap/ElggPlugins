<?php


$user = get_loggedin_user();
$ts = time();
$token = generate_action_token($ts);
$members = array();
$messages = get_annotations($entity_guid=$vars['entity']->guid, $entity_type="object", $entity_subtype="conversation", $name="convo_message", $value="", $owner_guid=0, $limit=20, $offset=0, $order_by="desc", $timelower=0, $timeupper=0, $entity_owner_guid=0);

// Show Status for new messages
$cur_status = false;
$status = get_annotations($entity_guid=$vars['entity']->guid, $entity_type="object", $entity_subtype="conversation", $name="convo_status", $value="", $owner_guid=$user->guid, $limit=1, $offset=0, $order_by="desc", $timelower=0, $timeupper=0, $entity_owner_guid=0);
if($status[0]->value == "updated"){
	$cur_status = true;
}

// Deal with latest message
$last_message = $messages[0];
$last_poster = get_entity($last_message->owner_guid);
$last_time = elgg_get_friendly_time($last_message->time_created);
$last_message_content = elgg_get_excerpt($last_message->value, 150);
$icon = elgg_view("profile/icon", array('entity' => $last_poster, 'size' => 'tiny', 'override' => TRUE));


	if($cur_status !== true){
		echo "<div class='convo_message_list_holder' id='convo_message_list_holder_{$vars['entity']->guid}'>";
	}else{
		echo "<div class='convo_message_list_holder_new' id='convo_message_list_holder_{$vars['entity']->guid}'>";
	}
		echo "<h3><a id='listing_open_link_{$vars['entity']->guid}' style='cursor:pointer;text-decoration:none;' onclick='open_convo({$vars['entity']->guid})'>{$vars['entity']->title}</a></h3>";
		echo "<div style='float:left;width:30px;'>";
		echo $icon;
		echo "</div><div style='float:left;width:630px;'>";
		echo $last_message_content;
		echo "</div>";
		echo "<div class='clearfloat'></div>";
		echo "<br>";
		echo sprintf(elgg_echo('conversations:listing:when'),$last_poster->name,$last_time);
	echo "</div>";
?>