<?php

/**
 * Elgg conversations/messages plugin
 * This plugin replaces the standard messages plugin with a conversation style system, 
 * 
 * @package Elggmembers
 * @author Trajan
 */

$ts = time();
$token = generate_action_token($ts);
?>



<div class="contentWrapper">
	<?php
	
		echo "<div id='inbox_top_bar' class='convos_inbox_bar'>";
			echo "<a class='submit_button' id='add_new'>" . elgg_echo('conversation:new') . "</a> ";
				$num_convos = count_unread_convos();
				if($num_convos){$num_con = $num_convos;} else {$num_con = 0;}
				$num_notices = count_unread_notices();
				if($num_notices){$num_not = $num_notices;} else {$num_not = 0;}
				echo "<a class='submit_button' id='see_notices'>" . elgg_echo('conversations:notices') . " [{$num_not}]</a> ";
				echo "<a class='submit_button' id='see_convos'>" . elgg_echo('conversations:convos') . " [{$num_con}]</a>";
		echo "</div>";

		echo "<div id='add_new_convo' style='display:none;margin-bottom:15px;'>";
		echo "<span id='add_new_convo_box'>";
		echo "To: " . elgg_view('input/autocomplete', array('internalname' => 'receiver', 'internalid' => 'receiver', 'match_on' => 'friends'));
		echo elgg_view("input/longtext",array("internalname" => "message_body", "internalid" => "message_body"));
		echo "<a class='submit_button' onclick='send_convo();'>" . elgg_echo('conversations:send:link') . "</a>";
		echo "</span>";
		echo "</div>";
		
		echo "<div id='holder_of_lists'>";
			echo "<div id='conversation_list_holder'>";
				list_latest_conversations($vars['user']->guid);
			echo "</div>";
			
			echo "<div id='system_notice_list_holder' style='display:none;'>";
				$system_notices = elgg_list_entities(array("type" => "object", "subtype" => "elgg_system_notice", "limit" => 30, "owner_guid" => $vars['user']->guid, "full_view" => FALSE, "pagination" => FALSE));
				echo $system_notices;
			echo "</div>";
		echo "</div>";
			
		echo "<div id='conversation_holder' style='width:480px;display:none;'>";
		echo "</div>";
		
		echo "<div id='system_notice_holder' style='width:480px;display:none;'>";
		echo "</div>";
		
		echo "<div id='show_loader' style='display:none;width:480px;'>";
			$loader = "<img style='margin:40px 0 0 230px;' src='{$vars['url']}mod/embed/images/loading.gif'>";
			echo $loader;
		echo "</div>";

	?>
</div>

<script type="text/javascript">
	$(document).ready(function() {
	   var refreshId = setInterval(function() {
		   if($("#conversation_list_holder").is(':visible')){
			  $("#holder_of_lists").empty();
			  $("#inbox_top_bar_refresher").empty();
			  $("#show_loader").show();
		      $("#holder_of_lists").load('<?php echo $vars['url'];?>pg/conversations/update_inbox?randval='+ Math.random(), function() {
			      $("#show_loader").hide();
			  });
		   }else{
			  $("#holder_of_lists").empty().hide();
			  $("#inbox_top_bar_refresher").empty();
			  $("#show_loader").show();
		      $("#holder_of_lists").load('<?php echo $vars['url'];?>pg/conversations/update_inbox?randval='+ Math.random(), function() {
			      $("#show_loader").hide();
			      if($("#conversation_holder").is(':visible')){
				      $("#conversation_list_holder").hide();
				      $("#holder_of_lists").fadeIn();
			      }else{
			      $("#holder_of_lists").fadeIn();
		      	  }
			  }); 
		   }
	   },60000);
	});


	$("#add_new").click(function(){
		$("#add_new_convo").slideToggle();	
	});
	
	var loader = "<img id='ajax_loader' style='width:25px;height:25px;margin:40px 5px 5px 240px;' src='<?php echo $vars['url'];?>mod/embed/images/loading.gif'>";
	
	function open_convo(id){
		var load_convo = "<?php echo $vars['url'];?>pg/conversations/read/"+id+"?randval="+ Math.random();
		if($("#conversation_list_holder").is(':visible')){
			$("#conversation_list_holder").slideToggle();
			$("#conversation_holder").empty();
			$("#conversation_holder").html(loader).load(load_convo);
			if($("#conversation_holder").is(':visible')){
			}else{
				$("#conversation_holder").fadeIn();
			}
		}else{
			$("#conversation_holder").empty();
			$("#conversation_holder").html(loader).load(load_convo);
		}
	}
	
	function open_notice(id){
		var load_notice = "<?php echo $vars['url'];?>pg/conversations/view/"+id+"?randval="+ Math.random();
		if($("#system_notice_list_holder").is(':visible')){
			$("#system_notice_list_holder").slideToggle();
			$("#system_notice_holder").empty();
			$("#system_notice_holder").html(loader).load(load_notice);
			if($("#system_notice_holder").is(':visible')){
			}else{
				$("#system_notice_holder").fadeIn();
			}
		}else{
			$("#system_notice_holder").empty();
			$("#system_notice_holder").html(loader).load(load_notice);
		}
	}
	
	$('#see_convos').click(function(){
		if($("#conversation_list_holder").is(':visible')){
		}else{
			$("#conversation_holder").hide();
			$("#conversation_holder").empty();
			$("#system_notice_list_holder").hide();
			$("#system_notice_holder").hide();
			$("#system_notice_holder").empty();
			$("#conversation_list_holder").slideToggle();
		}
	});
	
	$('#see_notices').click(function(){
		if($("#system_notice_list_holder").is(':visible')){
		}else{
			$("#conversation_holder").hide();
			$("#conversation_holder").empty();
			$("#conversation_list_holder").hide();
			$("#system_notice_holder").hide();
			$("#system_notice_holder").empty();
			$("#system_notice_list_holder").slideToggle();
		}
	});
	
	
	$.ajaxSetup ({
	cache: false
	});
	
	
	
	function send_convo(){
		var token = "<?php echo $token; ?>";
		var ts = "<?php echo $ts; ?>";
		var user = "<?php echo $vars['user']->guid;?>";
		var receiver = $('input:hidden[name=receiver]').val();
		var message_body = tinyMCE.get('message_body').getContent();
		datastr = "&receiver=" + receiver;
		datastr += "&message_body=" + message_body;
		datastr += "&user_guid=" + user;
		datastr += "&__elgg_token=" + token;
		datastr += "&__elgg_ts=" + ts;
		$("#add_new_convo_box").hide();
		$("#add_new_convo").append(loader);
		$.ajax({
			type: "POST",
			url: "<?php echo $vars['url']; ?>action/conversations/add",
			data: datastr,
			success: function(msg){
				$("#ajax_loader").remove();
				$("#add_new_convo").slideToggle();
				$("#add_new_convo_box").show();
				$("#conversation_list_holder").append(msg);
			}
		});
	}
	
	function delete_convo(id){
		var token = "<?php echo $token; ?>";
		var ts = "<?php echo $ts; ?>";
		datastr = "&conversation=" + id;
		datastr += "&__elgg_token=" + token;
		datastr += "&__elgg_ts=" + ts;
		$("#convo_message_list_holder_"+id).append(loader);
		$.ajax({
			type: "POST",
			url: "<?php echo $vars['url']; ?>action/conversations/delete",
			data: datastr,
			success: function(msg){
				$("#convo_message_list_holder_"+id).slideToggle();
				$("#convo_message_list_holder_"+id).remove();
			}
		});
	}

</script>