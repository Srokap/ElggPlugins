<?php

/**
 * Elgg conversations/messages plugin
 * This plugin replaces the standard messages plugin with a conversation style system, 
 * 
 * @package Elggmembers
 * @author Trajan
 */


 if (isset($vars['entity'])) {
				
		// Should we show full view?
		if (isset($vars['full']) && $vars['full'] == true) {
				$fullview = true;
		}
	
		if (get_context() == "search") {
				
			//display the correct layout depending on gallery or list view
			if (get_input('search_viewtype') == "gallery") {

				//display the gallery view
       				echo elgg_view("conversations/gallery",$vars);

			} else {
				
				echo elgg_view("conversations/listing",$vars);

			}
				
		} else {
 
 
 
$user = get_loggedin_user();
$ts = time();
$token = generate_action_token($ts);
$members = array();
$messages = get_annotations($entity_guid=$vars['entity']->guid, $entity_type="object", $entity_subtype="conversation", $name="convo_message", $value="", $owner_guid=0, $limit=20, $offset=0, $order_by="asc", $timelower=0, $timeupper=0, $entity_owner_guid=0);


// Deal with latest message
$last_message = $messages[0];
$last_poster = get_entity($last_message->owner_guid);
$last_time = elgg_get_friendly_time($last_message->time_created);
$last_message_content = elgg_get_excerpt($last_message->value, 100);


// Get a collection of conversation members
foreach($messages as $mes){
	if(!in_array($mes->owner_guid,$members)){
		$members[] = $mes->owner_guid;
	}
}

// Show Status for new messages
$status = get_annotations($entity_guid=$vars['entity']->guid, $entity_type="object", $entity_subtype="conversation", $name="convo_status", $value="", $owner_guid=$user->guid, $limit=1, $offset=0, $order_by="desc", $timelower=0, $timeupper=0, $entity_owner_guid=0);
if($status[0]->value == "updated"){
	update_annotation ($status[0]->id, "convo_status", "same", "text", $user->owner_guid, $access_id);
}


?>

<div class="conversation_object_holder">

	<!-- Show the conversation on the right -->
	<div id='conversation_object_messages'>
	
	<?php
		foreach($messages as $message){
			$friendlytime = elgg_view_friendly_time($message->time_created);
			echo "<div class='convo_message' id='convo_message_div_{$message->id}'>";
				echo "<div class='convo_message_icon'>";
					$mes_owner = get_entity($message->owner_guid);
					echo elgg_view("profile/icon",array('entity' => $mes_owner, 'size' => 'small', 'override' => TRUE));
				echo "</div>";
				
				echo "<div class='convo_message_content'>";
					echo $message->value;
				echo "</div>";
				
				// Clear the floating content to show extra info below
				echo "<div class='clearfloat'></div>";
				
				echo "<div class='convo_message_data'>";
				// Show the time created
				echo "<span style='float:right;'>";
					echo $friendlytime;
				echo "</span>";
				// Show controls for conversation messages if possible
				echo "<span class='convo_message_controls'>";
					if($message->canEdit()){
						
					}
				echo "</span>";
				
				echo "</div>";
			echo "</div>";
		}



	?>
	</div>
	
	<div class='clearfloat'></div>
	
	<div id='extend_convo_holder' style='float:left;width:650px;margin-top:3px;background:#E8E8E8;padding:1px;'>
		<?php
			$user_icon = elgg_view("profile/icon",array('entity' => $user, 'size' => 'small', 'override' => TRUE));
			
			echo "<div id='convo_extend_icon' style='float:left;width:40px;padding-top:4px;margin-left:3px;'>";
			echo $user_icon;
			echo "</div>";
			
			echo "<div id='convo_extend_text' style='float:left;width:605px;'>";
			echo "<textarea id='convo_extend' cols='82' rows='0'></textarea>";
			echo "<div id='loader' style='display:none;margin-left:250px;'></div>";
			echo "</div>";
			
		?>
	</div>
	
</div>

<script>
$(function(){
	$('#convo_extend').elastic();
});

$.ajaxSetup ({
	cache: false
});

var loader = "<img id='ajax_loader' style='width:25px;height:25px;margin:5px 5px 5px 0;' src='<?php echo $vars['url'];?>mod/embed/images/loading.gif'>";
var convo = "<?php echo $vars['entity']->guid;?>";
var token = "<?php echo $token; ?>";
var ts = "<?php echo $ts; ?>";
var user = "<?php echo $user->guid;?>";

$('#convo_extend').keydown(function (e){
    if(e.keyCode == 13){
	var message_body = $('#convo_extend').attr('value');
	datastr = "&convo=" + convo;
	datastr += "&message_body=" + message_body;
	datastr += "&user_guid=" + user;
	datastr += "&__elgg_token=" + token;
	datastr += "&__elgg_ts=" + ts;
	$('#convo_extend').hide();
	$('#loader').append(loader).show();
	$.ajax({
		type: "POST",
		url: "<?php echo $vars['url']; ?>action/conversations/update",
		data: datastr,
		success: function(msg){
			$('#loader').hide();
			$("#convo_extend").val('').show();
			$("#conversation_object_messages").append(msg);
		}
	});
    }
});
		


</script>

<?php

	} // End else statement if not search
} // End if is set
?>