<?php

	/**
	 * Elgg messages topbar extender
	 * 
	 * @package ElggMessages
	 */
	 
	 //need to be logged in to send a message
	 gatekeeper();

		
	// Show the number of messages and use the box for a refresh option
	echo "<span id='topbar_conversations_link' style='float:left;'>";

	$num_messages = count_unread_conversations();
	if($num_messages){
		$num = $num_messages;
	} else {
		$num = 0;
	}
	
	if($num == 0){
		echo "<a href='{$vars['url']}pg/conversations/inbox' class='privatemessages'>&nbsp;</a>";
    }else{
		echo "<a href='{$vars['url']}pg/conversations/inbox' class='privatemessages_new'>[{$num}]</a>";
    }
    
    	
    echo "</span>";
    
    

?>

<script>
$(document).ready(function() {
	   var refreshId = setInterval(function() {
       $("#topbar_conversations_link").load('<?php echo $vars['url'];?>pg/conversations/update_topbar?randval='+ Math.random());
	   },60000);
	});

</script>