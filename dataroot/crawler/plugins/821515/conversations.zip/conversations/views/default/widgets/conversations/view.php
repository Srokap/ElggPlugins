
<script type="text/javascript">

</script>

	<?php
		
		// Get inputs from settings
		$show_limit = $vars['entity']->num_display;
		$ts = time();
		$token = generate_action_token($ts);
		$has_conversation = false;
	
	    // Get the info for owner and viewer
		$owner = page_owner_entity();
		$user = get_loggedin_user();
		
		if($owner->guid !== $user->guid){
		
		echo "<div class='convos_widget_holder'>";
		// Check if there is already a conversation
		$already_one = elgg_get_entities_from_metadata(array("metadata_name" => "receiver", "metadata_value" => $owner->guid, "type" => "object", "subtype" => "conversation", "owner_guid" => $user->guid, "limit" => 1));
			if($already_one !== FALSE){ // If found then echo the view here
				$conversation = $already_one[0];
				$messages = get_annotations($entity_guid=$already_one[0]->guid, $entity_type="object", $entity_subtype="conversation", $name="convo_message", $value="", $owner_guid=0, $limit=$show_limit, $offset=0, $order_by="desc", $timelower=0, $timeupper=0, $entity_owner_guid=0);
				$final_messages = array_reverse($messages);		
			}else{ // Else run a check for the other way round
				$already_two = elgg_get_entities_from_metadata(array("metadata_name" => "receiver", "metadata_value" => $user->guid, "type" => "object", "subtype" => "conversation", "owner_guid" => $owner->guid, "limit" => 1));
				if($already_two !== FALSE){ // If found then echo the view here
					$conversation = $already_two[0];
					$messages = get_annotations($entity_guid=$already_two[0]->guid, $entity_type="object", $entity_subtype="conversation", $name="convo_message", $value="", $owner_guid=0, $limit=$show_limit, $offset=0, $order_by="desc", $timelower=0, $timeupper=0, $entity_owner_guid=0);
					$final_messages = array_reverse($messages);
				}else{
					
				}
			}
        
			// Show things if user is not profile owner
			echo "<div id='widget_comments_holder'>";
				if($final_messages){
					$has_conversation = true;
					foreach($final_messages as $message){
						$friendlytime = elgg_view_friendly_time($message->time_created);
						$mes_owner = get_entity($message->owner_guid);
						$icon = elgg_view("profile/icon",array('entity' => $mes_owner, 'size' => 'tiny', 'override' => TRUE));
						echo "<div class='convo_widget_box'>";
							echo "<div class='convo_widget_icon'>{$icon}</div>"; // Show the user's icon
							echo "<div class='convo_widget_content'>{$message->value}</div>"; // Show the message
							echo "<div class='clearfloat'></div>";
							echo "<div class='convo_widget_message_data'>";
								echo "<span style='float:right;'>{$friendlytime}</span>"; // Show the time created
								echo "<span class='convo_message_controls'>"; // Show controls for conversation messages if possible
									if($message->canEdit()){}
								echo "</span>";
							echo "</div>";
						echo "</div>";
						
					}
				}else{
				echo "<span style='padding:5px;'>" . elgg_echo('conversations:widget:no_convo') . "</span>";	
				}
			echo "</div>";
			
			// Show the expansion box
			echo "<div id='extend_convo_widget_holder' style='float:left;width:inherit;margin:3px 0 0 3px;background:#E8E8E8;padding:1px;'>";
				$user_icon = elgg_view("profile/icon",array('entity' => $user, 'size' => 'small', 'override' => TRUE));
				echo "<div id='convo_extend_icon' style='float:left;width:40px;padding-top:4px;margin-left:3px;'>{$user_icon}</div>"; // Show user's icon
				echo "<div id='convo_extend_text' style='float:left;width:inherit;'>"; // Show the textarea for adding a comment
					echo "<textarea id='convo_extend' cols='33' rows='0'></textarea>";
					echo "<div id='loader' style='display:none;margin-left:150px;'></div>";
				echo "</div>";
			echo "</div>";	
		
		echo "</div>"; // End convos_widget_holder div	
		}else{// Check to see if user is looking at own profile
			echo "<span style='margin:5px;'>" . elgg_echo('conversations:widget:own') . "</span>";
		}
		
		echo "<div class='clearfloat'></div>";
      ?>
      
<script>
$(function(){
	$('#convo_extend').elastic();
});

$.ajaxSetup ({
	cache: false
});

var loader = "<img id='ajax_loader' style='width:25px;height:25px;margin:5px 5px 5px 0;' src='<?php echo $vars['url'];?>mod/embed/images/loading.gif'>";
var token = "<?php echo $token; ?>";
var ts = "<?php echo $ts; ?>";
var user = "<?php echo $user->guid;?>";
var owner = "<?php echo $owner->guid;?>";

</script>
<?php 
	if($has_conversation == true){
?>
<script>
$('#convo_extend').keydown(function (e){
    if(e.keyCode == 13){
	var message_body = $('#convo_extend').attr('value');
	var convo = "<?php echo $conversation->guid;?>";
	datastr = "&convo=" + convo;
	datastr += "&message_body=" + message_body;
	datastr += "&user_guid=" + user;
	datastr += "&__elgg_token=" + token;
	datastr += "&__elgg_ts=" + ts;
	$('#convo_extend').hide();
	$('#loader').append(loader).show();
	$.ajax({
		type: "POST",
		url: "<?php echo $vars['url']; ?>action/conversations/widget_update",
		data: datastr,
		success: function(msg){
			$('#loader').hide();
			$("#convo_extend").val('').show();
			$("#widget_comments_holder").append(msg);
		}
	});
    }
});
</script>
<?php 
	}else{
?>
<script>
$('#convo_extend').keydown(function (e){
    if(e.keyCode == 13){
		var message_body = $('#convo_extend').attr('value');
		datastr = "&receiver=" + owner;
		datastr += "&message_body=" + message_body;
		datastr += "&user_guid=" + user;
		datastr += "&__elgg_token=" + token;
		datastr += "&__elgg_ts=" + ts;
		$('#convo_extend').hide();
		$('#loader').append(loader).show();
		$.ajax({
			type: "POST",
			url: "<?php echo $vars['url']; ?>action/conversations/widget_add",
			data: datastr,
			success: function(msg){
				$('#loader').hide();
				$("#convo_extend").val('').show();
				$("#widget_comments_holder").empty().append(msg);
			}
		});
	}
});
</script>
<?php
	}
?>