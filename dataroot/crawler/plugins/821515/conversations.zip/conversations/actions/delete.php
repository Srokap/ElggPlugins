<?php

	/**
	 * Elgg blog: delete post action
	 * 
	 * @package ElggBlog
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @copyright Curverider Ltd 2008-2010
	 * @link http://elgg.org/
	 */

	// Make sure we're logged in (send us to the front page if not)
		gatekeeper();

	// Get input data
		$guid = (int) get_input('conversation');
		
	// Make sure we actually have permission to edit
		$conversation = get_entity($guid);
		if ($conversation->getSubtype() == "conversation" && $conversation->canEdit()) {
	
		// Delete it!
				$rowsaffected = $conversation->delete();
				if ($rowsaffected > 0) {
		// Success message
				//	system_message(elgg_echo("courses_grammaticus:deleted"));
				} else {
				//	register_error(elgg_echo("courses_grammaticus:notdeleted"));
				}
		// Forward to the main blog page
				//forward($_SERVER['HTTP_REFERER']);
		
		}
		
?>