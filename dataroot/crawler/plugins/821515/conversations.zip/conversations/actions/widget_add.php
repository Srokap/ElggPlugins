<?php

	/**
	 * Elgg conversations/messages plugin
	 * This plugin replaces the standard messages plugin with a conversation style system, 
	 * 
	 * @package Elggmembers
	 * @author Trajan
	 */

		if(!isloggedin()){
			register_error(elgg_echo('conversations:not:loggedin'));
			forward($_SERVER['HTTP_REFERER']);
		}
	 	
		// Get inputs
		$receiver = get_entity(get_input('receiver'));
		$message = get_input('message_body');
		$user = get_entity(get_input('user_guid'));
		
		// Make sure the receiver / message aren't blank
		if (empty($receiver) || empty($message)) {
			echo elgg_echo("conversations:blank");
			die();
		
		}else{

			$convo = new ElggObject();
			$convo->subtype = 'conversation';
			$convo->owner_guid = $user->guid;
			$convo->title = sprintf(elgg_echo('conversations:newconvo:title'),$user->name,$receiver->name);
			$convo->description = '';
			$convo->receiver = $receiver->guid;
			$convo->access_id = ACCESS_DEFAULT;
			
			// Before we can set metadata, we need to save the market post
			if (!$convo->save()) {
				echo elgg_echo("conversations:error");
				die();
			}
			
			// Now we need to add the message body to the conversation
			$convo->annotate('convo_message', $message, $convo->access_id, $user->guid);
			
			// Set an annotation on the conversation for both users to allow for status updates
			elgg_set_ignore_access($ignore = true);
				$convo->annotate('convo_status', 'updated', $convo->access_id, $receiver->guid);
				$convo->annotate('convo_status', 'same', $convo->access_id, $user->guid);
			elgg_set_ignore_access($ignore = false);
			
			// Time to output for Ajax requests
			$new_convo = get_entity($convo->guid);
			$new_anno = get_annotations ($entity_guid=$new_convo->guid, $entity_type="object", $entity_subtype="conversation", $name="convo_message", $value="", $owner_guid=0, $limit=1, $offset=0, $order_by="desc", $timelower=0, $timeupper=0, $entity_owner_guid=0);	
			$friendlytime = elgg_view_friendly_time($new_anno[0]->time_created);
			echo "<div class='convo_widget_box' id='convo_message_div_{$new_anno[0]->id}'>";
				echo "<div class='convo_widget_icon'>";
					$mes_owner = get_entity($new_anno[0]->owner_guid);
					echo elgg_view("profile/icon",array('entity' => $mes_owner, 'size' => 'tiny', 'override' => TRUE));
				echo "</div>";
				
				echo "<div class='convo_widget_content'>";
					echo $new_anno[0]->value;
				echo "</div>";
				
				// Clear the floating content to show extra info below
				echo "<div class='clearfloat'></div>";
				
				echo "<div class='convo_widget_message_data'>";
				// Show the time created
				echo "<span style='float:right;'>";
					echo $friendlytime;
				echo "</span>";
				// Show controls for conversation messages if possible
				echo "<span class='convo_message_controls'>";
					if($new_anno[0]->canEdit()){
					}
				echo "</span>";
				
				echo "</div>";
			echo "</div>";
			
			die();
			
		}

		
		
		
?>