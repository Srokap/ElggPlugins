<?php

	/**
	 * Elgg conversations/messages plugin
	 * This plugin replaces the standard messages plugin with a conversation style system, 
	 * 
	 * @package Elggmembers
	 * @author Trajan
	 */

		if(!isloggedin()){
			register_error(elgg_echo('conversations:not:loggedin'));
			forward($_SERVER['HTTP_REFERER']);
		}
	 	
		// Get inputs
		$receiver = get_entity(get_input('receiver'));
		$message = get_input('message_body');
		$user = get_entity(get_input('user_guid'));
		
		// Make sure the receiver / message aren't blank
		if (empty($receiver) || empty($message)) {
			echo elgg_echo("conversations:blank");
			die();
		
		}else{
		
		
		// Check for previous conversations
		$already_one = elgg_get_entities_from_metadata(array("metadata_name" => "receiver", "metadata_value" => $receiver->guid, "type" => "object", "subtype" => "conversation", "owner_guid" => $user->guid, "limit" => 1));
		
			// If none from this user check other user
			if(empty($already_one) || $already_one == FALSE){
					$already_two = elgg_get_entities_from_metadata(array("metadata_name" => "receiver", "metadata_value" => $user->guid, "type" => "object", "subtype" => "conversation", "owner_guid" => $receiver->guid, "limit" => 1));
				
					// If none from receiver either it's time to create a new conversation
					if(empty($already_two) || $already_two == FALSE){
					
						$convo = new ElggObject();
						$convo->subtype = 'conversation';
						$convo->owner_guid = $user->guid;
						$convo->title = sprintf(elgg_echo('conversations:newconvo:title'),$user->name,$receiver->name);
						$convo->description = '';
						$convo->receiver = $receiver->guid;
						$convo->access_id = ACCESS_DEFAULT;
						
						// Before we can set metadata, we need to save the market post
						if (!$convo->save()) {
							echo elgg_echo("conversations:error");
							die();
						}
						
						// Now we need to add the message body to the conversation
						$convo->annotate('convo_message', $message, $convo->access_id, $user->guid);
						
						// Set an annotation on the conversation for both users to allow for status updates
						elgg_set_ignore_access($ignore = true);
							$convo->annotate('convo_status', 'updated', $convo->access_id, $receiver->guid);
							$convo->annotate('convo_status', 'same', $convo->access_id, $user->guid);
						elgg_set_ignore_access($ignore = false);
						
						// Time to output for Ajax requests
						$new_convo = get_entity($convo->guid);
						$latest_messages = get_annotations($entity_guid=$new_convo->guid, $entity_type="object", $entity_subtype="conversation", $name="convo_message", $value="", $owner_guid=0, $limit=20, $offset=0, $order_by="asc", $timelower=0, $timeupper=0, $entity_owner_guid=0);
						$last_message = $latest_messages[0];
						$last_poster = get_entity($last_message->owner_guid);
						$last_message_content = elgg_get_excerpt($last_message->value, 150);
						$last_time = elgg_get_friendly_time($last_message->time_created);
						$icon = elgg_view("profile/icon", array('entity' => $last_poster, 'size' => 'tiny', 'override' => TRUE));
						echo "<div class='convo_message_list_holder' id='convo_message_list_holder_{$new_convo->guid}'>";
							echo "<h3><a id='listing_open_link_{$new_convo->guid}' style='cursor:pointer;text-decoration:none;' onclick='open_convo({$new_convo->guid})'>{$new_convo->title}</a></h3>";
							echo "<div style='float:left;width:30px;'>";
							echo $icon;
							echo "</div><div style='float:left;width:630px;'>";
							echo $last_message_content;
							echo "</div>";
							echo "<div class='clearfloat'></div>";
							echo "<br>";
							echo sprintf(elgg_echo('conversations:listing:when'),$last_poster->name,$last_time);
						echo "</div>";
						
						die();
						
					// Looks like we found a conversation already	
					}else{
						$old_convo = $already_two[0];
						$old_convo->annotate('convo_message', $message, $old_convo->access_id, $user->guid);
						elgg_set_ignore_access($ignore = true);
							$owner_status = get_annotations ($entity_guid=$old_convo->guid, $entity_type="object", $entity_subtype="conversation", $name="convo_status", $value="", $owner_guid=$old_convo->owner_guid, $limit=1, $offset=0, $order_by="asc", $timelower=0, $timeupper=0, $entity_owner_guid=0);
							$receiver_status = get_annotations ($entity_guid=$old_convo->guid, $entity_type="object", $entity_subtype="conversation", $name="convo_status", $value="", $owner_guid=$old_convo->receiver, $limit=1, $offset=0, $order_by="asc", $timelower=0, $timeupper=0, $entity_owner_guid=0);
							
							// Set an annotation on the conversation for both users to allow for status updates
							if($user->guid == $old_convo->owner_guid){
								update_annotation ($owner_status[0]->id, "convo_status", "same", "text", $user->guid, $access_id);
								update_annotation ($receiver_status[0]->id, "convo_status", "updated", "text", $old_convo->receiver, $access_id);
							}elseif($user->guid == $old_convo->receiver){
								update_annotation ($owner_status[0]->id, "convo_status", "updated", "text", $old_convo->owner_guid, $access_id);
								update_annotation ($receiver_status[0]->id, "convo_status", "same", "text", $user->guid, $access_id);
							}
						elgg_set_ignore_access($ignore = false);
						
						echo elgg_echo('conversations:add:already:convo');
						
						die();
					}
			
			// Looks like we found a conversation already
			}else{
				$old_convo = $already_one[0];
				$old_convo->annotate('convo_message', $message, $old_convo->access_id, $user->guid);
				elgg_set_ignore_access($ignore = true);
					$owner_status = get_annotations ($entity_guid=$old_convo->guid, $entity_type="object", $entity_subtype="conversation", $name="convo_status", $value="", $owner_guid=$old_convo->owner_guid, $limit=1, $offset=0, $order_by="asc", $timelower=0, $timeupper=0, $entity_owner_guid=0);
					$receiver_status = get_annotations ($entity_guid=$old_convo->guid, $entity_type="object", $entity_subtype="conversation", $name="convo_status", $value="", $owner_guid=$old_convo->receiver, $limit=1, $offset=0, $order_by="asc", $timelower=0, $timeupper=0, $entity_owner_guid=0);
					
					// Set an annotation on the conversation for both users to allow for status updates
					if($user->guid == $old_convo->owner_guid){
						update_annotation ($owner_status[0]->id, "convo_status", "same", "text", $user->guid, $access_id);
						update_annotation ($receiver_status[0]->id, "convo_status", "updated", "text", $old_convo->receiver, $access_id);
					}elseif($user->guid == $old_convo->receiver){
						update_annotation ($owner_status[0]->id, "convo_status", "updated", "text", $old_convo->owner_guid, $access_id);
						update_annotation ($receiver_status[0]->id, "convo_status", "same", "text", $user->guid, $access_id);
					}
				elgg_set_ignore_access($ignore = false);
				
				echo elgg_echo('conversations:add:already:convo');
				
				die();
			}
		
		
		
		}// End else for check on blank content
		
?>