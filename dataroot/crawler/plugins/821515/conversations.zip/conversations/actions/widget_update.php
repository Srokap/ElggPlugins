<?php

		
		$conversation_guid = get_input('convo');
		$message = get_input('message_body');
		$user = get_input('user_guid');
		
		$conversation = get_entity($conversation_guid);
		
		if($conversation){
			
			// Annote the conversation with a reply
			$conversation->annotate('convo_message', $message, $conversation->access_id, $user);
			
			elgg_set_ignore_access($ignore = true);
					$owner_status = get_annotations ($entity_guid=$conversation->guid, $entity_type="object", $entity_subtype="conversation", $name="convo_status", $value="", $owner_guid=$conversation->owner_guid, $limit=1, $offset=0, $order_by="asc", $timelower=0, $timeupper=0, $entity_owner_guid=0);
					$receiver_status = get_annotations ($entity_guid=$conversation->guid, $entity_type="object", $entity_subtype="conversation", $name="convo_status", $value="", $owner_guid=$conversation->receiver, $limit=1, $offset=0, $order_by="asc", $timelower=0, $timeupper=0, $entity_owner_guid=0);
					
					// Set an annotation on the conversation for both users to allow for status updates
					if($user == $conversation->owner_guid){
						update_annotation ($owner_status[0]->id, "convo_status", "same", "text", $user, $access_id);
						update_annotation ($receiver_status[0]->id, "convo_status", "updated", "text", $conversation->receiver, $access_id);
					}elseif($user == $conversation->receiver){
						update_annotation ($owner_status[0]->id, "convo_status", "updated", "text", $conversation->owner_guid, $access_id);
						update_annotation ($receiver_status[0]->id, "convo_status", "same", "text", $user, $access_id);
					}
				elgg_set_ignore_access($ignore = false);
		}

		$new_anno = get_annotations ($entity_guid=$conversation_guid, $entity_type="object", $entity_subtype="conversation", $name="convo_message", $value="", $owner_guid=0, $limit=1, $offset=0, $order_by="desc", $timelower=0, $timeupper=0, $entity_owner_guid=0);	
		$friendlytime = elgg_view_friendly_time($new_anno[0]->time_created);
			echo "<div class='convo_widget_box' id='convo_message_div_{$new_anno[0]->id}'>";
				echo "<div class='convo_widget_icon'>";
					$mes_owner = get_entity($new_anno[0]->owner_guid);
					echo elgg_view("profile/icon",array('entity' => $mes_owner, 'size' => 'tiny', 'override' => TRUE));
				echo "</div>";
				
				echo "<div class='convo_widget_content'>";
					echo $new_anno[0]->value;
				echo "</div>";
				
				// Clear the floating content to show extra info below
				echo "<div class='clearfloat'></div>";
				
				echo "<div class='convo_widget_message_data'>";
				// Show the time created
				echo "<span style='float:right;'>";
					echo $friendlytime;
				echo "</span>";
				// Show controls for conversation messages if possible
				echo "<span class='convo_message_controls'>";
					if($new_anno[0]->canEdit()){
					}
				echo "</span>";
				
				echo "</div>";
			echo "</div>";
		
		
		die();
?>