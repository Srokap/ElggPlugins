<?php

/**
 * Elgg conversations/messages plugin
 * This plugin replaces the standard messages plugin with a conversation style system, 
 * 
 * @package Elggmembers
 * @author Trajan
 */


function conversations_init() {
	global $CONFIG;
	
	// Extend the elgg topbar
	elgg_extend_view('elgg_topbar/extend','conversations/topbar');
	
	elgg_extend_view('css', 'conversations/css');
	register_page_handler('conversations','conversations_page_handler');
	register_entity_url_handler('conversation_url','object','conversation');
	register_entity_url_handler('system_notice_url','object','elgg_system_notice');
	register_notification_handler("site", "message_site_notify_handler");
	
	register_plugin_hook('notify:entity:message','object','messages_notification_msg');
	if (is_callable('register_notification_object'))
	register_notification_object('object','elgg_system_notice',elgg_echo('conversations:new'));
	
	// Conversations widget
	add_widget_type('conversations',elgg_echo("conversation"),elgg_echo("conversations:widget:description"));
	
	register_action("conversations/add",false,$CONFIG->pluginspath . "conversations/actions/add.php");
	register_action("conversations/widget_add",false,$CONFIG->pluginspath . "conversations/actions/widget_add.php");
	register_action("conversations/delete",false,$CONFIG->pluginspath . "conversations/actions/delete.php");
	register_action("conversations/update",false,$CONFIG->pluginspath . "conversations/actions/update.php");
	register_action("conversations/widget_update",false,$CONFIG->pluginspath . "conversations/actions/widget_update.php");
	register_action("conversations/delete_notice",false,$CONFIG->pluginspath . "conversations/actions/delete_notice.php");
}

function conversations_page_handler($page) {
	global $CONFIG;

	switch ($page[0])
	{
		case 'inbox':
			include $CONFIG->pluginspath . 'conversations/pages/inbox.php';
			break;
		case 'read': set_input('conversation_guid',$page[1]);
			include $CONFIG->pluginspath . 'conversations/pages/read.php';
			break;
		case 'view': set_input('system_notice_guid',$page[1]);
			include $CONFIG->pluginspath . 'conversations/pages/read.php';
			break;
		case 'update_inbox':
			include $CONFIG->pluginspath . 'conversations/pages/update_inbox.php';
			break;
		case 'update_inbox_top':
			include $CONFIG->pluginspath . 'conversations/pages/update_inbox_top.php';
			break;
		case 'update_topbar':
			include $CONFIG->pluginspath . 'conversations/pages/update_topbar.php';
			break;
	}

	return TRUE;
}

function conversation_url($conversation) {
		global $CONFIG;
		return $CONFIG->url . "pg/conversations/read/" . $conversation->getGUID();
	}
	
function system_notice_url($system_notice) {
		global $CONFIG;
		return $CONFIG->url . "pg/conversations/view/" . $system_notice->getGUID();
	}
	
// This function was kindly supplied by Matt Beckett at community.elgg.org
function collect_conversations($objarray, $fieldname, $order = 'ASC'){
  $sort_func = ($order == 'ASC') ? "return (\$a->{$fieldname} == \$b->{$fieldname}) ? 0 : (\$a->{$fieldname} > \$b->{$fieldname}) ? 1 : -1;" : "return (\$a->{$fieldname} == \$b->{$fieldname}) ? 0 : (\$a->{$fieldname} > \$b->{$fieldname}) ? -1 : 1;";
  usort($objarray, create_function('$a,$b', $sort_func));
return $objarray;
}
// get a listing of the latest 20 conversations relevant to the loggedin user  
function list_latest_conversations($guid){
	set_context("search");
	$my_convos = elgg_get_entities(array("type" => "object", "subtype" => "conversation", "owner_guid" => $guid, "limit" => ""));
	$other_convos = elgg_get_entities_from_metadata(array("metadata_name" => "receiver", "metadata_value" => $guid, "type" => "object", "subtype" => "conversation", "owner_guid" => "", "limit" => ""));
	if(!is_array($my_convos)){$my_convos = array();}
	if(!is_array($other_convos)){$other_convos = array();}
	$total_convos = array_merge_recursive($my_convos,$other_convos);
	$all_convos = collect_conversations($total_convos, 'time_created', 'ASC');
	echo elgg_view_entity_list($all_convos,'','',15,false,false,false);
}

// get a listing of all other conversations relevant to the loggedin user  
function list_other_conversations($guid){
	$my_convos = elgg_get_entities(array("type" => "object", "subtype" => "conversation", "owner_guid" => $guid, "limit" => ""));
	$other_convos = elgg_get_entities_from_metadata(array("metadata_name" => "receiver", "metadata_value" => $guid, "type" => "object", "subtype" => "conversation", "owner_guid" => "", "limit" => ""));
	if(!is_array($my_convos)){$my_convos = array();}
	if(!is_array($other_convos)){$other_convos = array();}
	$total_convos = array_merge_recursive($my_convos,$other_convos);
	$all_convos = collect_conversations($total_convos, 'time_created', 'ASC');
	$final_convos = array_slice($all_convos,16);
	return $final_convos;
}

// A simple function to count the number of conversations that are unread in a user's inbox
// An expanded version of the original messages plugin's count_unread_messages()
           function count_unread_convos(){
	            //get the users inbox conversations
			    $num_messages_first = elgg_get_entities_from_annotations(array('annotation_name' => 'convo_status','annotation_value' => 'updated', 'annotation_owner_guid' => get_loggedin_userid(), 'types' => 'object','subtypes' => 'conversation','owner_guid' => get_loggedin_userid(),'count' => TRUE));
					
				$num_second = 0;
				$num_messages_second = elgg_get_entities_from_metadata(array('metadata_name' => 'receiver','metadata_value' => get_loggedin_userid(),'types' => 'object','subtypes' => 'conversation','owner_guid' => ''));
				foreach($num_messages_second as $num_mes){
					$num_count = count_annotations($entity_guid=$num_mes->guid, $entity_type="object", $entity_subtype="conversation", $name="convo_status", $value="updated", $value_type="text", $owner_guid=get_loggedin_userid(), $timelower=0, $timeupper=0);
					$num_second += $num_count;
				}
				$fin_convos = $num_messages_first + $num_second;
				return (int)$fin_convos;
			}
			
			function count_unread_notices(){
				// get the users ibox system notices
				$num_notices = elgg_get_entities_from_metadata(array('metadata_name' => 'status','metadata_value' => 'unread','types' => 'object','subtypes' => 'elgg_system_notice','owner_guid' => get_loggedin_userid(),'count' => TRUE));
				return (int)$num_notices;
			}
			
			function count_unread_conversations() {
			
			$num_con = count_unread_convos();
			$num_not = count_unread_notices();
			$fin_tot_convos = $num_con + $num_tot;
			return (int)$fin_tot_convos;
        }

// Don't notify user if notifications are set to site and a new conversation post is added
function messages_notification_msg($hook_name, $entity_type, $return_value, $parameters) {
	global $CONFIG, $messages_pm;
	if ($parameters['entity'] instanceof ElggEntity) {
		if ($parameters['entity']->getSubtype() == 'conversation') {					
			return false;
		}
	}
	return null;
}
        
// Deal with notifications as messages        
function send_system_notice($subject, $body, $send_to) {
	$system_notice = new ElggObject();
	$system_notice->subtype = "elgg_system_notice";
	$system_notice->title = $subject;
	$system_notice->description = $body;
	$system_notice->owner_guid = $send_to;
	$system_notice->access_id = ACCESS_PRIVATE;
	$system_notice->status = "unread";

	$success = $message_to->save();
	return $success;
	
}

function message_site_notify_handler(ElggEntity $from, ElggUser $to, $subject, $message, array $params = NULL){
	global $CONFIG;
	if (!$from)
		throw new NotificationException(sprintf(elgg_echo('NotificationException:MissingParameter'), 'from'));
	if (!$to)
		throw new NotificationException(sprintf(elgg_echo('NotificationException:MissingParameter'), 'to'));
	global $messages_pm;
	if (!$messages_pm)
		return send_system_notice($subject,$message,$to->guid);
	else return true;
	
}
	
register_elgg_event_handler('init', 'system', 'conversations_init');
