<?php

	$english = array(
			
		'conversations:inbox:title' => "Conversations",
		'conversation:new' => "New Conversation",
	    'conversations:notices' => "See Notifications",
		'conversations:convos' => "See Conversations",
		'conversations:send:link' => "Start Conversation",	
		'conversations:area3:title' => "Other Conversations",
		
		// Error Messages
		'conversations:not:loggedin' => "You need to be logged in",
		'conversations:blank' => "The receiver or message was blank",  
		
		// Conversation Object
		'conversations:newconvo:title' => "%s and %s's Conversation",
		'conversations:listing:when' => "from %s %s",
		
		//Ajax returns
		'conversations:add:already:convo' => "You already have a conversation running with that member. Your message has been added to that.",
		
		// System Notices
		'system:notice:delete' => "Delete Notice",
		'conversations:new' => "New Notice",
		'notification:method:site' => "Site",
		
		// Widget
		'conversation' => "Conversation",
		'conversations:widget:description' => "A widget for members to use the conversations system with you from your profile",
		'conversations:widget:own' => "You cannot start a conversation with yourself so this is empty when you view it.",
		'conversations:numbertodisplay' => "Number of comments to display",
		'conversations:widget:no_convo' => "You don't have a conversation running with this person yet",
		
		
	);
					
	add_translation("en",$english);

?>