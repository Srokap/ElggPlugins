<?php

/**
 * Elgg conversations/messages plugin
 * This plugin replaces the standard messages plugin with a conversation style system, 
 * 
 * @package Elggmembers
 * @author Trajan
 */

// include the Elgg engine
include_once dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php"; 

if(!isloggedin()){
	register_error(elgg_echo('conversations:not:loggedin'));
	forward($_SERVER['HTTP_REFERER']);
}
	$guid = get_input('conversation_guid');
	
	$conversation = get_entity($guid);
	
	$user = get_loggedin_user();
	
// if username or owner_guid was not set as input variable, we need to set page owner
// Get the current page's owner
$page_owner = page_owner_entity();
if (!$page_owner) {
	$page_owner_guid = $user->guid;
	if ($page_owner_guid)
		set_page_owner($page_owner_guid);
}	

$body = elgg_view_entity($conversation,false,true,false);

echo $body;
?>