<?php

include_once dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php"; 
global $CONFIG;
$num_messages = count_unread_conversations();
	if($num_messages){
		$num = $num_messages;
	} else {
		$num = 0;
	}
	
	if($num == 0){
		echo "<a href='{$CONFIG->url}pg/conversations/inbox/' class='privatemessages'>&nbsp;</a>";
    }else{
		echo "<a href='{$CONFIG->url}pg/conversations/inbox/' class='privatemessages_new'>[{$num}]</a>";
    }
	

?>