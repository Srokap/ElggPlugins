<?php

include_once dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php"; 

$user = get_loggedin_user();

	
	echo "<span id='inbox_top_bar_refresher'>";
		$num_convos = count_unread_convos();
		if($num_convos){$num_con = $num_convos;} else {$num_con = 0;}
		$num_notices = count_unread_notices();
		if($num_notices){$num_not = $num_notices;} else {$num_not = 0;}
		echo "<a class='submit_button' id='see_notices'>" . elgg_echo('conversations:notices') . " [{$num_not}]</a> ";
		echo "<a class='submit_button' id='see_convos'>" . elgg_echo('conversations:convos') . " [{$num_con}]</a>";
	echo "</span>";

?>