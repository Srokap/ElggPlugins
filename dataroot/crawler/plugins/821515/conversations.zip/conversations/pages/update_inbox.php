<?php

include_once dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php"; 

$user = get_loggedin_user();

	echo "<div id='holder_of_lists_a'>";
			echo "<div id='conversation_list_holder'>";
				list_latest_conversations($user->guid);
			echo "</div>";
			
			echo "<div id='system_notice_list_holder' style='display:none;'>";
				$system_notices = elgg_list_entities(array("type" => "object", "subtype" => "elgg_system_notice", "limit" => 30, "owner_guid" => $user->guid, "full_view" => FALSE, "pagination" => FALSE));
				echo $system_notices;
			echo "</div>";
		echo "</div>";

?>