<?php

/**
 * Elgg conversations/messages plugin
 * This plugin replaces the standard messages plugin with a conversation style system, 
 * 
 * @package Elggmembers
 * @author Trajan
 */

// include the Elgg engine
include_once dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php"; 

if(!isloggedin()){
	register_error(elgg_echo('conversations:not:loggedin'));
	forward($_SERVER['HTTP_REFERER']);
}

	$user = get_loggedin_user();
	
// if username or owner_guid was not set as input variable, we need to set page owner
// Get the current page's owner
$page_owner = page_owner_entity();
if (!$page_owner) {
	$page_owner_guid = $user->guid;
	if ($page_owner_guid)
		set_page_owner($page_owner_guid);
}	

$title = elgg_echo('conversations:inbox:title');

$area2 = "<h2>{$title}</h2>";
$area2 .= elgg_view('conversations/inbox',array('user' => $user));
$area3 = elgg_view('conversations/others',array('user' => $user));


// layout the sidebar and main column using the default sidebar
$body = elgg_view_layout('two_column_right_sidebar', '', $area2, $area3);

// create the complete html page and send to browser
page_draw($title, $body);
?>