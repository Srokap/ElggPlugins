<?php
admin_gatekeeper();
delete_entities('object', 'super_notify');
delete_entities('object', 'sn_current_marker');
forward();
?>