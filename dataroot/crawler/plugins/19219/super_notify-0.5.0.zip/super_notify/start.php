<?php

// Register the startup stuff.
register_elgg_event_handler('init','system','super_notify_init');

/**
 * The startup function used to handle all the initialization.
 *
 */
function super_notify_init() {
	global $CONFIG;
	// Actions
	register_action("notifications/remove",true,$CONFIG->pluginspath . "super_notify/actions/remove.php",false);

	// Extend CSS
	extend_view('css','sn_css');

	// Permissions check override
	register_plugin_hook('container_permissions_check','object','super_notify_container_permission_check');
	register_plugin_hook('permissions_check','object','super_notify_container_permission_check');
	// Extend Top Bar if needed
	extend_view('elgg_topbar/extend','notifications/top_bar');
	// Extend the 'Tools' Menu
	if(isloggedin()) {
		add_menu(elgg_echo('notifications'), $CONFIG->wwwroot ."pg/notifications");
	}

	// Register a page handler, so we can have nice URLs
	register_page_handler('notifications','sn_page_handler');

	// Register the notifications handler 'super_notify'
	register_notification_handler('super_notify', super_notify_handler);

}

/**
 * Pretty URLS!  Default to the 'view notifications' page.
 *
 * @param unknown_type $page
 * @return unknown
 */
function sn_page_handler($page) {
	global $CONFIG;
	if(isset($page[0])) {
		switch($page[0]) {
/*			case 'test':
				if(!@include_once($CONFIG->pluginspath . "super_notify/test.php")) {
					return false;
				}
				return true;
				break;*/
			case 'uninstall':
				if(!@include_once($CONFIG->pluginspath . "super_notify/uninstall.php")) {
					return false;
				}
				return true;
				break;
			case '':
				if(!@include_once($CONFIG->pluginspath . "super_notify/view.php")) {
					return false;
				}
				return true;
				break;
			case 'js':
				if(isset($page[1])) {
					header('Content-type: application/text');
					if(!@include_once($CONFIG->pluginspath . "super_notify/js/{$page[1]}.php")) {
						return false;
					}
					return true;
					break;
				}
			default:
				if(!@include_once($CONFIG->pluginspath . "super_notify/view.php")) {
					return false;
				}
				return true;
				break;
		}
	}
}


/***************************************
 *  Super Notify 'workhorse' methods (these are the ones that do all
 *  of the work :)
 ***************************************/
/**
 * Checks for the object that lets the plugin know that the user has notifications
 * they hasn't looked at yet.
 *
 * @param unknown_type $user
 * @return unknown
 */
function super_notify_hasNewNotifies($user) {
	$foo = get_entities("object","sn_current_marker",$user->guid);
	return $foo;
}

/**
 * Remove the object that lets the user know there are new notifications.
 *
 * @param unknown_type $user
 */
function super_notify_removeNewNotifies($user) {
	delete_entities("object", "sn_current_marker", $user->guid);
}

/**
 * Creates the object for a particular user that lets them know there are new notifications.
 * Used whenever a notification is created (there is a check to see if it exists, and if not
 * then call).
 * 
 *
 * @param unknown_type $user
 * @return unknown
 */
function super_notify_setNewNotifies($user) {
	if(!super_notify_hasNewNotifies($user)) {
		$o = new ElggObject();
		$o->access_id = 1;
		$o->subtype="sn_current_marker";
		$o->owner_guid = $user->guid;
		$o->container_guid = $user->guid;
		if(!super_notify_save($o)) {
			return false;
		}
	}
	return true;
}

/**
 * Care needs to be taken to make sure we ONLY delete super_notify objects,
 * because this is called via the (never trusted) client, eventually...
 * 
 * Only delete super_notify objects, and only those that we own.
 *
 * @param unknown_type $guid
 */
function super_notify_removeNotify($user, $guid) {

	$entity = get_entity($guid);
	if($entity->type == 'object' && get_subtype_from_id($entity->subtype)=='super_notify'){
		if($entity->owner_guid == $user->guid && $entity->container_guid == $user->guid) {
			return delete_entity($guid);
		}
	}
	return false;
}

/**
 * Get the notification objects for this user.
 *
 * @param unknown_type $user
 * @return unknown
 */
function super_notify_getMyNotifies($user) {
	$notifies = get_entities('object', 'super_notify', $user->guid);
	return $notifies;
}

/**
 * The handler for notifications.
 *
 * @param ElggEntity $from - Not actually used as of now, since a notification might be
 * from an app, so this doesn't really make sense.
 * @param ElggUser $to - the user who is being notified.
 * @param string $subject - String, the 'title' of the notification.
 * @param string $message - string, the 'body' of the notification.
 * @param array $params - 2, a string of 'application_name' for display, and a 
 * (possible array) of links in the following format: words|url|target . words are what
 * you want to show up on the button, url is the address to follow, and target is an optional
 * target for a new window. 
 * @return unknown
 */
function super_notify_handler(ElggEntity $from, ElggUser $to, $subject, $message, array $params = NULL) {
	$sno = new ElggObject();
	$sno->subtype = 'super_notify';
	$sno->access_id = 1;
	$sno->owner_guid = $to->guid;
	$sno->container_guid = $to->guid;
	if(!super_notify_save($sno)) {
		return false;
	}
	$sno->title = $subject;
	$sno->description = $message;
	if(!super_notify_save($sno)) {
		return false;
	}
	$sno->application_name = $params['application_name'];;
	if(!empty($params['links'])) {
		$sno->links = $params['links'];
	}

	super_notify_setNewNotifies($to);
}

/**
 * Helper function for saving the actual notification object.  Simplifies the changing
 * of the context so we can control save permissions on users who are not our own.
 *
 * @param unknown_type $o
 * @return unknown
 */
function super_notify_save($o) {
	$ctx = get_context();
	set_context('save_super_notify');
	if (!$o->save()){
		return false;
	}
	set_context($ctx);
	return true;
}

/**
 * Extend container permissions checking to extend can_write_to_container for write users.
 *
 * @param unknown_type $hook
 * @param unknown_type $entity_type
 * @param unknown_type $returnvalue
 * @param unknown_type $params
 */
function super_notify_container_permission_check($hook, $entity_type, $returnvalue, $params) {
	if(get_context() == 'save_super_notify') {
		return true;
	}
	return $returnvalue;
}

/**
 * Given the $link format from the super_notify_handler function, create the link.
 *
 * @param unknown_type $guid
 * @param unknown_type $link
 * @return unknown
 */
function super_notify_createLink($guid, $link) {
	if(!empty($link)) {
		$link = explode("|", $link);
	}
	$words = $link[0];
	$url = $link[1];
	$target = $link[2];

	$l = "<span id=\"snLink{$guid}\">";
	$l .= "<a href=\"$url\" ";
	if(!empty($target)) {
		$l .= "target=\"$target\" ";
	}
	$l .= ">" . elgg_echo($words) . "</a>";
	$l .= "</span>";
	return $l;
	//	echo "<a href=\"$link[1]\""target='sn_new'>$link[0]</a>";
}



?>