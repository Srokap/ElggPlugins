<?php
	global $CONFIG;
?>

/**
 * Notification Display (Javascript)
 *
 * @package SuperNotify
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Steve Suppe
 * @copyright Steve Suppe 2009
 * @link
 *
 */
 
 $(document).ready(function () {
 //	alert('foo');
 	$('#navlist a').click(function() {removeNotification($(this));});
 });
  
 function removeNotification(obj) {
 	var div = obj.parent().attr('id');
 	div = div.substr(6, div.length);
 	$.get("<?= $CONFIG->url ?>actions/notifications/remove",
				{ 'guid' : div, 'ajax' : 1}, function(){});
}
 
