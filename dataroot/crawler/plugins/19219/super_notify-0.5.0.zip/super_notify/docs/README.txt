SUPER_NOTIFY
------------------------------------------

Super Notify is a general purpose, inter-site notifications system.  It can be used by
any application to send any user notifications, complete with multiple links used for
user choices.

INSTALLATION
------------------
Simply copy into the mod directory and enable through the admin console.  Because it uses
Elgg's hooks into the notification system, it will auto-magically show up as a choice
on a user's notifications settings.

USAGE
-------------------
Once installed, any messages that are normally sent without a methods override in the notify_user
method will also get sent here.  However, notify_user calls that specify only particular methods
(such as 'email') will ignore this plugin.  New notify_user calls can specify this in the overrides as
'super_notify'

Here is how Super_Notify interprets the notify_user parameters:

$from - Not actually used right now, because notifications will most likely come from an
		application, and not a user.

$to - 	The user who is being notified

$subject - The title of the notification (similar to email)

$message - The body of the notification (similar to email) 

Application developers can take advantage of this plugin's advanced functions by specifying extra
parameters in the PARAM array of notify_user.  There are the following options, each as a named element
in the $params array:

'application_name'  String, =>  Used for display purposes instead of 'From.'  Can be "Friends", or "Calendar"
								or anything you deem appropriate for the application.

'links'	(array)				=>  Used to include links that offer a user choices (can be used as  'Confirm Request' 'Deny Request' etc)
								Each link to be included needs the following format:
									A pipe (|) delimited string:
										words|url|target
										
										* 'Words' are the words that show up in the link
										* 'url' is the URL that will be placed in the href
										* 'target' is optional, but can specify a named target window
										  if you want to open the link in a new window.
										  
BEHAVIOR
------------------
When a new notification is created, the user gets a notification on the top bar.  When they
click on this, the top_bar notification disappears.  Individual notifications
can be deleted manually (through the delete link on each notification), or 
are deleted when the user makes a choice of one of the links (mimicking 
Facebook behaviour, ish).

Also, a 'Notifications' menu item gets added to the user's 'Tools' menu.
										

UNINSTALLATION
-------------------
As admin, simply run '/notifications/uninstall' off your main site URL. This will clean up all
objects.

TO-DOs
-------------------
1) Any bug fixes you tell me about :)
2) Any particularly useful feature requests
3) I would like to see a way to turn this on automatically without adjustments to the core.
4) I will be adding this to the friends request plugin!