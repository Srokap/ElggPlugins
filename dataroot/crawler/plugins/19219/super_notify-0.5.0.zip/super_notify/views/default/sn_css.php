<?php

/**
 * Notifications CSS Styles
 *
 * @package SuperNotify
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Steve Suppe
 * @copyright Steve Suppe 2008
 * @link
 *
 * @uses $vars['entity'] The notify entity
 */

?>
/* ***************************************
	notify LISTINGS	
*************************************** */
.notify_listing {
	display: block;
	background-color: #eee;
	padding: 5px;
	margin-bottom: 10px;
}

.notify_listing_icon {
	float:left;
}
.notify_listing_icon img {
	width: 40px;
}
.notify_listing_icon .avatar_menu_button img {
	width: 15px;
}
	
.notify_listing {
	margin-left: 50px;
	min-height: 40px;
}
/* IE 6 fix */
* html .notify_listing {
	height:40px;
}
.notify_listing p {
	margin:0 0 3px 0;
	line-height:1.2em;
}


.notify_listing {
	margin: 5px;
}

.notify_listing p {
	margin: 5px;
	margin-bottom: 10px;
}

.notify_listing_icon {
	position: absolute;
	margin-bottom: 20px;
}

.notify_listing {
	margin: 5px;
}

.notify_listing p {
	margin: 5px;
	margin-bottom: 10px;
}

.notify_listing .notify_header p {
	display: inline;
}

.notify_listing .notify_header p#date {
float : right;}



/* ***********
* Links
* ***********/

ul#navlist
{
margin-left: 0;
padding-left: 0;
white-space: nowrap;
}

#navlist li
{
display: inline;
list-style-type: none;
padding-left: 10px;
}

#navlist a { padding: 3px 10px; }

#navlist a:link, #navlist a:visited
{
color: #fff;
background-color: #036;
text-decoration: none;
}

#navlist a:hover
{
color: #fff;
background-color: #369;
text-decoration: none;
}

/***********************
Notification Icon
************************/
/*#elgg_topbar_container_left a.notifies_new {
	background:transparent url(<?php echo $vars['url']; ?>mod/super_notify/images/bang.gif) no-repeat top;
	padding:0 0 4px 16px;
	margin:0 15px 0 5px;
	cursor:pointer;
}*/

/* IE6 */
* html #elgg_topbar_container_left a.notifies_new { background-position: left -18px; } 
/* IE7 */
*+html #elgg_topbar_container_left a.notifies_new { background-position: left -18px; } 

#elgg_topbar_container_left a.notifies_new:hover {
	text-decoration: none;
}
