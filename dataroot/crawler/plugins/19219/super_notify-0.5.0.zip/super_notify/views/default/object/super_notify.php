<?php

/**
 * Notification Display (Details)
 *
 * @package SuperNotify
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Steve Suppe
 * @copyright Steve Suppe 2008
 * @link
 *
 * @uses $vars['entity'] The notify entity
 */


// Only display if the logged in user is the same as the owner

$n = $vars['entity'];

if(get_loggedin_userid() == $n->owner_guid) {
	$links = $n->links;
	if(!empty($links) && !is_array($links)) {
		$links = array($links);
	}

	?>

<div class="notify_listing">
<div class="notify_header">
<p><b><u><?= $n->application_name ?></u></b></p>
<p id="date"><?= date("m.d.y",$n->time_created)  ?>

</div>

<p><i><?= $n->title ?> </i></p>

	<?php if(!empty($n->description)) { ?>
<p><small> <?= $n->description ?> </small></p>
	<?php }
	echo '<div id="navcontainer">';

	echo '<ul id="navlist">'';
	foreach($links as $link) {
		echo "<li>" . super_notify_createLink($n->guid, $link);
	}
	echo "</ul>";
	echo "<span id=\"notify_delete\">";
	echo "<a href=\"{$CONFIG->url}actions/notifications/remove?guid={$n->guid}\">". elgg_echo("notifications:delete:link") . "</a>";
	echo "</span>";
	echo "</div>";

	echo "</div>";
}
?>