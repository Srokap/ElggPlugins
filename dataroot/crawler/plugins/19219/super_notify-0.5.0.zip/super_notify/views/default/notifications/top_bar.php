<?php

/**
 * Notification Display (Details)
 *
 * @package SuperNotify
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Steve Suppe
 * @copyright Steve Suppe 2008
 * @link
 */

gatekeeper();

if(super_notify_hasNewNotifies($_SESSION['user'])){ ?>

<a href="<?php echo $vars['url']; ?>pg/notifications"
	class="new_notifications"
	title="<?php echo elgg_echo('notifications:new'); ?>"><?= elgg_echo('notifications:new') ?></a>

<?php } ?>