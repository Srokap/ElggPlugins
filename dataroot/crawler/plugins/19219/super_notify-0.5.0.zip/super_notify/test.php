<?php


admin_gatekeeper();
notify_user($_SESSION['user']->guid, $_SESSION['user']->guid, "This is a test subject", "This is a test message", array('links'=>array('yahoo|http://www.yahoo.com',
	 'google|http://www.google.com'),'application_name' => 'Test Application'),'super_notify');



forward();

?>