<?php

/**
 * Notification Display (Manage)
 *
 * @package SuperNotify
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Steve Suppe
 * @copyright Steve Suppe 2008
 * @link
 */

// Load Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

// You need to be logged in!
gatekeeper();

// Get the logged in user, you can't see other peoples messages so use session id
$page_owner = $_SESSION['user'];
set_page_owner($page_owner->getGUID());
global $CONFIG;

$notifications = super_notify_getMyNotifies($page_owner);

// Set the page title
$area2 = elgg_view_title(elgg_echo("notifications"));
$area2 .= "<script type=\"text/javascript\" src=\"{$CONFIG->url}pg/notifications/js/super_notify.js\"></script>";

if(!empty($notifications)) {
	foreach($notifications as $n) {
		$area2 .= elgg_view_entity($n);
	}
	super_notify_removeNewNotifies($page_owner);

}


// format
$body = elgg_view_layout("two_column_left_sidebar", '', $area2);


// Draw page
page_draw(sprintf(elgg_echo('notifications'),$page_owner->name),$body);

?>