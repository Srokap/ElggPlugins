<?php
$english = array(
				'super_notify' => "Within the site",
               'notifications:new' => 'New Notifications',
               'notifications' => 'Notifications',

				'notifications:delete:fail' => 'Unable to delete the notification.  Contact the webmaster if the problem persists.',
				'notifications:delete:link' => 'Delete'
);


add_translation("en",$english);


?>