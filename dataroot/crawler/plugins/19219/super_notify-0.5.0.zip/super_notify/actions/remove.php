<?php

/**
 * Remove Notification Object
 *
 * @package SuperNotify
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Steve Suppe
 * @copyright Steve Suppe 2008
 * @link
 *
 * @uses $vars['entity'] The notify entity
 */

gatekeeper();

$user = $_SESSION['user'];
$guid = get_input('guid');
$ajax = get_input('ajax');
if(!empty($guid)){
	if(!super_notify_removeNotify($user, $guid)) {
		system_message(elgg_echo('notifications:delete:fail'));
	}
	// Just in case, remove the new notifies object
	super_notify_removeNewNotifies($user);
}
if(empty($ajax)) {
	forward($_SERVER['HTTP_REFERER']);
}


?>