<?php
	global $CONFIG;
	$english = array(
		'vazco_levels:levels' => 'Levels of separation:',
		'vazco_levels:outofnetwork' => '%s is out of your network',
		'vazco_levels:you' => 'You',
		'vazco_levels:separator' => '<img class="levels_spacer" src="'.$CONFIG->wwwroot.'_graphics/spacer.gif">',
		'vazco_levels:settings:finishlevel' => 'Allowed level of separation (must be numeric, advised value is below 5):',
	);
					
	add_translation("en",$english);
?>