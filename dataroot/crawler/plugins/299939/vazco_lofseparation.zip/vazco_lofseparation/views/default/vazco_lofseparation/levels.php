<?php 
if ( isloggedin() && get_loggedin_userid() != page_owner()){
	$levels = vazco_lofseparation::getLevelsOfSeparationString(page_owner_entity());
?>
	<div class="levels_of_separation">
	<?php echo elgg_echo('vazco_levels:levels').' '.$levels;?>
	</div>
<?php } ?>