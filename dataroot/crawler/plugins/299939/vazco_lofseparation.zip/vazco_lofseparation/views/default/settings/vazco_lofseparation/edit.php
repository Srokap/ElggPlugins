<?php 
$entity = $vars['entity'];
?>
<p><span><?php echo elgg_echo('vazco_levels:settings:finishlevel'); ?></span>
	<?php echo elgg_view('input/text', array('internalname' => 'params[finishLevel]','class' => ' ', 'value' => $entity->finishLevel)); ?>
</p>