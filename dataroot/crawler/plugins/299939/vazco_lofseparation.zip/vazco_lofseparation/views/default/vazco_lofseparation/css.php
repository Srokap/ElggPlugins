.levels_of_separation{
	-moz-border-radius:8px;
	background:#E9E9E9;
	border-bottom:1px solid #CCCCCC;
	border-right:1px solid #CCCCCC;
	margin:0 0 20px;
	padding:10px;
}

.levels_separator{
	background: url(<?php echo $vars['url'];?>mod/vazco_lofseparation/graphics/arrow_right.gif) no-repeat left bottom;
	margin:1px;
}

.levels_spacer{
	width: 15px;
	height: 15px;
}
