<?php

	/*
  	 * @package Elgg
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Michal Zacher [michal.zacher@gmail.com]
	 * @remarks In case you need any help with this plugin, geocoding or reverse geocoding, please contact me and I may be able to help.
	*/
	require_once(dirname(__FILE__)."/models/model.php");
		
	function vazco_lofseparation_init() {
		extend_view('profile/userdetails','vazco_lofseparation/levels');
		extend_view('css','vazco_lofseparation/css');
	}
	
	register_elgg_event_handler('init','system','vazco_lofseparation_init');
?>