<?php 
class vazco_lofseparation{
	public function getLevelsOfSeparationString($user){
		$finishLevel = get_plugin_setting('finishLevel','vazco_lofseparation');
		if (!isset($finishLevel) || !is_numeric($finishLevel)){
			$finishLevel = 5;
		}

		$userTable = vazco_lofseparation::searchForUser($user,get_loggedin_user(), $finishLevel, $userTable);

		$string = "";
		for ($i = sizeof($userTable) - 2; $i>=0;$i--){
			$string.= ' <span class="levels_separator">'.elgg_echo('vazco_levels:separator').'</span> <a href="'.$userTable[$i]->getURL().'">'.$userTable[$i]->username.'</a>';
		}
		if ($string == "")
			$string = sprintf(elgg_echo('vazco_levels:outofnetwork'),$user->name);
		else{
			$string = elgg_echo('vazco_levels:you').$string;
		}
		return $string;
	}
	
	private function searchForUser($searchedUser, $currentUser, $finishLevel,  $level = 0, $alreadyChecked = array()){
		//return null if user is a logged in user, or if level is too high
		if ( $level == $finishLevel || ($currentUser->guid == get_loggedin_userid() && $level !=0) )
			return null;
		//if this is a user we search for, add him to array and return array
		if ($currentUser->guid == $searchedUser->guid){
			$userTable = array($currentUser);
			return $userTable;
		}

		//get friends and users that this user is a friend of
		$friends = $currentUser->getFriends();
		$friendOf = $currentUser->getFriendsOf();
		$friends = vazco_lofseparation::joinFriendsAndFriendsOf($friends, $friendOf);
		
		//check if there's a searched user among them
		$userStrings = array();
		$level = $level + 1;

		$smallestTable = null;
		//now search the friends 
		foreach($friends as $friend){
			//examine only users that were not examined before, to prevent unnecesary looping
			if (!vazco_lofseparation::alreadyChecked($alreadyChecked, $friend)){
				$userSubTable = vazco_lofseparation::searchForUser($searchedUser, $friend, $finishLevel, $level, $alreadyChecked);
				if ($userSubTable != null){
					if ($smallestTable  == null || sizeof($userSubTable) < sizeof($smallestTable)){
						$smallestTable = $userSubTable;
					}
				}
			}
		}
		//if this path leads to the user we search for, add current user to path
		if ($smallestTable)
			$smallestTable []= $currentUser;
			
		return $smallestTable;
	}
	
	private function alreadyChecked(&$alreadyChecked, $user){
		return false;
		//in case 
		if ($user->guid == get_loggedin_userid())
			return true;

		foreach($alreadyChecked as $checkedUser){
			if ($checkedUser == $user->guid)
				return true;
		}
		$alreadyChecked []= $user->guid;
		return false;
	}
	
	private function joinFriendsAndFriendsOf($friends, $friendOf){
	foreach($friendOf as $f){
			$found = false;
			foreach($friends as $f2){
				if ($f2->guid == $f->guid){
					$found = true;
					break;
				}
			}
			if (!$found)
				$friends []= $f;
		}
		return $friends;
	} 
	
}
?>