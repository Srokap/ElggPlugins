<?php

// Gerado pela extensão 'translationbrowser'  20111226-08:33:11 PM

$portugues_brasileiro = array( 
	 'categories'  =>  "Categorias" , 
	 'categories:settings'  =>  "Definir as categorias do Site" , 
	 'categories:explanation'  =>  "Para definir algumas categorias gerias que serão utilizadas no sistema, entre-as abaixo, separada por vírgulas. Ferramentas compatíveis exibirão as categorias quando o usuário criar ou editar conteúdos." , 
	 'categories:save:success'  =>  "Categorias foram salvas com sucesso." , 
	 'categories:results'  =>  "Resultados para a categoria do site: %s" , 
	 'categories:on_activate_reminder'  =>  "As categorias não funcionam enquanto não adicionar categorias . Adicione as categorias agora."
); 

add_translation('pt_br', $portugues_brasileiro); 

?>