<?php

// Gerado pela extensão 'translationbrowser' 

$portugues_brasileiro = array( 
	 'custom:bookmarks'  =>  "Últimos favoritos" , 
	 'custom:groups'  =>  "Últimas comunidades" , 
	 'custom:files'  =>  "Últimos arquivos" , 
	 'custom:blogs'  =>  "Últimas mensagens dos blogs" , 
	 'custom:members'  =>  "Membros mais recentes" , 
	 'custom:nofiles'  =>  "Ainda não existem arquivos" , 
	 'custom:nogroups'  =>  "Ainda não existem comunidades"
); 

add_translation('pt_br', $portugues_brasileiro); 

?>