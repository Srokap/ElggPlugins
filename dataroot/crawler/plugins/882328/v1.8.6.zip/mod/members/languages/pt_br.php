<?php

// Gerado pela extensão 'translationbrowser'  20110712-08:29:18 PM

$portugues_brasileiro = array( 
	 'members:label:newest'  =>  "Recentes" , 
	 'members:label:popular'  =>  "Populares" , 
	 'members:label:online'  =>  "Online " , 
	 'members:searchname'  =>  "Pesquisar participantes por nome" , 
	 'members:searchtag'  =>  "Pesquisar participantes por descritores (tag)" , 
	 'members:title:searchname'  =>  "Participantes pesquisados por %s" , 
	 'members:title:searchtag'  =>  "Participantes descritos (tag) com %s"
); 

add_translation('pt_br', $portugues_brasileiro); 

?>