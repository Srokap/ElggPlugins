<?php

// Gerado pela extensão 'translationbrowser'  20110712-08:08:12 PM

$portugues_brasileiro = array( 
	 'expages'  =>  "Páginas externas" , 
	 'admin:appearance:expages'  =>  "Páginas externas" , 
	 'expages:about'  =>  "Sobre" , 
	 'expages:terms'  =>  "Termos" , 
	 'expages:privacy'  =>  "Privacidade" , 
	 'expages:contact'  =>  "Contatos" , 
	 'expages:notset'  =>  "Esta página ainda não foi configurada." , 
	 'expages:posted'  =>  "Sua página foi enviada com sucesso." , 
	 'expages:error'  =>  "Ocorreu um erro, por favor tente novamente e se o problema persistir contate o administrador"
); 

add_translation('pt_br', $portugues_brasileiro); 

?>