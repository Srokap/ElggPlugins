<?php

// Gerado pela extensão 'translationbrowser'  20110711-09:43:33 PM

$portugues_brasileiro = array( 
	 'tinymce:remove'  =>  "Adicionar/Remover editor" , 
	 'tinymce:add'  =>  "Adicionar editor" , 
	 'tinymce:word_count'  =>  "Contagem de palavras:"
); 

add_translation('pt_br', $portugues_brasileiro); 

?>