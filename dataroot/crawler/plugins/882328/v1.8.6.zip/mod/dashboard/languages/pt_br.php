<?php

// Gerado pela extensão 'translationbrowser'  20111228-03:01:04 PM

$portugues_brasileiro = array( 
	 'dashboard:widget:group:title'  =>  "Atividades da comunidade" , 
	 'dashboard:widget:group:desc'  =>  "Visualizar as atividades em um de suas comunidades" , 
	 'dashboard:widget:group:select'  =>  "Selecionar a comunidade" , 
	 'dashboard:widget:group:noactivity'  =>  "Não existem atividades nesta comunidade" , 
	 'dashboard:widget:group:noselect'  =>  "Editar este dispositivo para selecionar uma comunidade"
); 

add_translation('pt_br', $portugues_brasileiro); 

?>