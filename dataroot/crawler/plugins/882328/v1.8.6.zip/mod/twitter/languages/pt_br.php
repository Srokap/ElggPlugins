<?php

// Gerado pela extensão 'translationbrowser'  20111228-02:37:30 PM

$portugues_brasileiro = array( 
	 'twitter:title'  =>  "Twitter " , 
	 'twitter:info'  =>  "Apresentar suas últimas mensagens ('tweets')" , 
	 'twitter:username'  =>  "Digite seu login no twitter <i>(twitter username)</i>" , 
	 'twitter:num'  =>  "Número de mensagens ('tweets') para apresentar" , 
	 'twitter:visit'  =>  "visitar meu twitter" , 
	 'twitter:notset'  =>  "Este dispositivo do 'twitter' não está pronto ainda para funcionar.  Para apresentar suas últimas mensagens ('tweets'), clique em - EDITAR - e preencha seus detalhes."
); 

add_translation('pt_br', $portugues_brasileiro); 

?>