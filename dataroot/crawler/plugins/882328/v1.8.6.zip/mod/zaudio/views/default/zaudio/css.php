<?php
/**
 * ZAudio CSS
 * @package ElggZAudio
 */
?>
/* ZAudio */
.zaudio {
	margin: 10px 0;
}
