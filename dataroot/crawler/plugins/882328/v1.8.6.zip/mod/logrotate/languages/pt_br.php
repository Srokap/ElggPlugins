<?php

// Gerado pela extensão 'translationbrowser'  20111228-03:35:41 PM

$portugues_brasileiro = array( 
	 'logrotate:period'  =>  "Com que frequência deve o sistema arquivar o 'log' ?" , 
	 'logrotate:weekly'  =>  "Semanalmente" , 
	 'logrotate:monthly'  =>  "Mensalmente" , 
	 'logrotate:yearly'  =>  "Anualmente" , 
	 'logrotate:logrotated'  =>  "Log arquivado
" , 
	 'logrotate:lognotrotated'  =>  "Erro ao arquivar o log
" , 
	 'logrotate:delete'  =>  "Apague os arquivos de registros mais antigos que" , 
	 'logrotate:week'  =>  "semana" , 
	 'logrotate:month'  =>  "mês" , 
	 'logrotate:year'  =>  "ano" , 
	 'logrotate:logdeleted'  =>  "Log apagado" , 
	 'logrotate:lognotdeleted'  =>  "Erro ao apagar o log"
); 

add_translation('pt_br', $portugues_brasileiro); 

?>