<?php

    register_error(elgg_echo(">>>>> dentro <<<<"));
    system_message(elgg_echo(">>>>> dentro <<<<"));
    forward("translationbrowser/");

exit;
?>