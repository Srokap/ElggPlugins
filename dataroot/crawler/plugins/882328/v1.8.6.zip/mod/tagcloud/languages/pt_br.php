<?php

// Gerado pela extensão 'translationbrowser'  20110711-09:40:24 PM

$portugues_brasileiro = array( 
	 'tagcloud:widget:title'  =>  "Nuvem de palavras" , 
	 'tagcloud:widget:description'  =>  "Nuvem de palavras" , 
	 'tagcloud:widget:numtags'  =>  "Número de palavras a demonstrar"
); 

add_translation('pt_br', $portugues_brasileiro); 

?>