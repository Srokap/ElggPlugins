<?php

// Gerado pela extensão 'translationbrowser'  20110712-08:48:32 PM

$portugues_brasileiro = array( 
	 'garbagecollector:period'  =>  "Com que frequência o coletor de lixo do Elgg deve ser executado?" , 
	 'garbagecollector:weekly'  =>  "Semanalmente" , 
	 'garbagecollector:monthly'  =>  "Mensalmente" , 
	 'garbagecollector:yearly'  =>  "Anualmente" , 
	 'garbagecollector'  =>  "Coletor de Lixo" , 
	 'garbagecollector:done'  =>  "FEITO
" , 
	 'garbagecollector:optimize'  =>  "Otimizando %s " , 
	 'garbagecollector:error'  =>  "ERRO" , 
	 'garbagecollector:ok'  =>  "OK " , 
	 'garbagecollector:gc:metastrings'  =>  "Limpando 'metastrings' desconexas: "
); 

add_translation('pt_br', $portugues_brasileiro); 

?>