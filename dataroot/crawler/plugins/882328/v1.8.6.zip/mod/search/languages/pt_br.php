<?php

// Gerado pela extensão 'translationbrowser'  20110711-09:38:20 PM

$portugues_brasileiro = array( 
	 'search:enter_term'  =>  "Insira um termo de pesquisa:" , 
	 'search:no_results'  =>  "Nenhum resultado." , 
	 'search:matched'  =>  "Combinados: " , 
	 'search:results'  =>  "Resultados para %s" , 
	 'search:no_query'  =>  "Por favor, insira uma expressão a ser pesquisada." , 
	 'search:search_error'  =>  "Erro" , 
	 'search:more'  =>  "+%s mais %s" , 
	 'search_types:tags'  =>  "Descritores (Tags)" , 
	 'search_types:comments'  =>  "Comentários" , 
	 'search:comment_on'  =>  "Comentários sobre \"%s\"" , 
	 'search:comment_by'  =>  "por" , 
	 'search:unavailable_entity'  =>  "Entidade não disponível"
); 

add_translation('pt_br', $portugues_brasileiro); 

?>