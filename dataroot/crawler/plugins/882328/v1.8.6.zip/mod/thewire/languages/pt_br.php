<?php

// Gerado pela extensão 'translationbrowser'  20111226-08:59:54 PM

$portugues_brasileiro = array( 
	 'thewire'  =>  "Micro-blog" , 
	 'thewire:everyone'  =>  "Todas mensagens do Micro-blog" , 
	 'thewire:user'  =>  "Micro-blog de %s
" , 
	 'thewire:friends'  =>  "Seus amigos no Micro-blog" , 
	 'thewire:reply'  =>  "Responder" , 
	 'thewire:replying'  =>  "Responder para %s quem escreveu" , 
	 'thewire:thread'  =>  "<i>(Thread)</i>" , 
	 'thewire:charleft'  =>  "caracteres à esquerda" , 
	 'thewire:tags'  =>  "Mensagens contendo os descritor (tag) '%s'" , 
	 'thewire:noposts'  =>  "Nenhuma mensagem  no Micro-blog ainda" , 
	 'item:object:thewire'  =>  "Mensagens do Micro-blog" , 
	 'thewire:update'  =>  "Atualizar" , 
	 'thewire:by'  =>  "Mensagens do Micro-blog enviada por %s" , 
	 'thewire:previous'  =>  "Anterior" , 
	 'thewire:hide'  =>  "Esconder" , 
	 'thewire:previous:help'  =>  "Ver mensagens anteriores" , 
	 'thewire:hide:help'  =>  "Esconder mensagens anteriores" , 
	 'river:create:object:thewire'  =>  "%s enviou mensagem para %s" , 
	 'thewire:wire'  =>  "micro-blog" , 
	 'thewire:widget:desc'  =>  "Mostra suas últimas mensagens no Micro-blog" , 
	 'thewire:num'  =>  "Número de items a serem visualizados" , 
	 'thewire:moreposts'  =>  "Mais mensagens do Micro-blog" , 
	 'thewire:posted'  =>  "Sua mensagem foi enviado com sucesso para o Micro-blog" , 
	 'thewire:deleted'  =>  "Sua mensagem no Micro-blog foi apagada com sucesso." , 
	 'thewire:blank'  =>  "Desculpe. Você precisa digitar alguma coisa na caixa de texto antes de enviar." , 
	 'thewire:notfound'  =>  "Desculpe. Não foi possível localizar a mensagem do Micro-blog definida." , 
	 'thewire:notdeleted'  =>  "Desculpe. Não foi possível apagar a mensagem no Micro-blog" , 
	 'thewire:notify:subject'  =>  "Nova mensagem postada" , 
	 'thewire:notify:reply'  =>  "%s respondeu para %s no  Micro-blog: " , 
	 'thewire:notify:post'  =>  "%s postou no  Micro-blog: "
); 

add_translation('pt_br', $portugues_brasileiro); 

?>