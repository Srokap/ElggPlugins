<?php
/**
 * Elgg TwitterService CSS
 */
?>

#twitterservice_site_settings .text_input {
	width: 350px;
}

.twitterservice_usersettings_desc {
	font-size: smaller;
}