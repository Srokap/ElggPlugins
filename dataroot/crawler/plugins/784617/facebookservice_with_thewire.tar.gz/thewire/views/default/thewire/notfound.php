<?php

	/**
	 * Elgg shout not found page
	 * 
	 * @package ElggShouts
	 */

?>

	<p>
		<?php

			echo elgg_echo("thewire:notfound");
		
		?>
	</p>