<?php

	/**
	 * Elgg hoverover extender for thewire
	 * 
	 * @package ElggThewire
	 */

?>

	<p class="user_menu_blog">
		<a href="<?php echo $vars['url']; ?>pg/thewire/owner/<?php echo $vars['entity']->username; ?>"><?php echo elgg_echo("thewire"); ?></a>
	</p>