<?php

	/**
	 * Elgg thewire edit/add page
	 * 
	 * @package ElggTheWire
	 * 
	 */

		$wire_user = get_input('wire_username');
		if (!empty($wire_user)) { $msg = '@' . $wire_user . ' '; } else { $msg = ''; }

?>
<div class="post_to_wire">
<h3><?php echo elgg_echo("thewire:doing"); ?></h3>
<script>
function textCounter(field,cntfield,maxlimit) {
    // if too long...trim it!
    if (field.value.length > maxlimit) {
        field.value = field.value.substring(0, maxlimit);
    } else {
        // otherwise, update 'characters left' counter
        cntfield.value = maxlimit - field.value.length;
    }
}
</script>
	<form action="<?php echo $vars['url']; ?>action/thewire/add" method="post" name="noteForm">
			<?php
			    $display .= "<textarea name='note' value='' onKeyDown=\"textCounter(document.noteForm.note,document.noteForm.remLen1,140)\" onKeyUp=\"textCounter(document.noteForm.note,document.noteForm.remLen1,140)\" id=\"thewire_large-textarea\">{$msg}</textarea>";
                $display .= "<div class='thewire_characters_remaining'><input readonly type=\"text\" name=\"remLen1\" size=\"3\" maxlength=\"3\" value=\"140\" class=\"thewire_characters_remaining_field\">";
                echo $display;
                echo elgg_echo("thewire:charleft") . "</div>";
				echo elgg_view('input/securitytoken');
			?>
			<input type="hidden" name="method" value="site" />
			<input type="submit" value="<?php echo elgg_echo('save'); ?>" />
                     
                      <?php
                      //Activation of twitter service shortcut 
                         
                       $user_id = get_loggedin_userid();
                       if (is_plugin_enabled('twitterservice')) {
                             ?>
                            <div style="float: right; width: 44px;margin-right: 10px">
                            <?php 
                             $consumer_key = get_plugin_setting('consumer_key', 'twitterservice');
                             $consumer_secret = get_plugin_setting('consumer_secret', 'twitterservice');
                             if ($consumer_key && $consumer_secret){                                
                                 $access_key = get_plugin_usersetting('access_key', $user_id, 'twitterservice');
                                 $access_secret = get_plugin_usersetting('access_secret', $user_id, 'twitterservice');
                                 if ($access_key && $access_secret) {
                                     $checked = (twitterservice_can_tweet('thewire', $user_guid)) ? 'checked = checked' : '';
                                     $icon_tweet_on = (twitterservice_can_tweet('thewire', $user_guid)) ? 'block' : 'none';
                                     $icon_tweet_off = (twitterservice_can_tweet('thewire', $user_guid)) ? 'none' : 'block';
                                    ?>
                                     <div id="check_twitter" style="float: left;width: 20px;margin-top: -2px">
                                        <input type="checkbox" id="twitter_on" value="1" name="params[allowed_plugin:thewire]" <?php echo $checked ?>>    
                                     </div>
                                     <div id="icon_twitter_on" style="display: <? echo $icon_tweet_on ?>;float: right ;width: 20px">
                                        <img src="<?php echo $vars['url'] ?>mod/thewire/graphics/twitter16.png" title="Servicio de Twitter activado"/>
                                     </div>
                                     <div id="icon_twitter_off" style="display: <? echo $icon_tweet_off ?>; float: right ;width: 20px">
                                        <img src="<?php echo $vars['url'] ?>mod/thewire/graphics/twitter16off.png" title="Servicio de Twitter desactivado"/>
                                    </div>
                                    <?php 
                                 }
                                 else{
                                     ?>
                                    <div id="check_twitter" style="float: left;width: 20px;margin-top: -2px">
                                        <input type="checkbox" id="twitter_off" value="0" name="twitter_off">   
                                    </div>
                                    <div id="icon_twitter_off" style="float: right ;width: 20px">
                                        <img src="<?php echo $vars['url'] ?>mod/thewire/graphics/twitter16off.png" title="Servicio de twitter desactivado"/>
                                    </div>
                                     <?php 

                                 }
                             }
                             ?>
                            </div>
                            <?php 
                         }
                        
                        ?>
                        
                         <?php
                      //Activation of facebook service shortcut                          
                         
                       $user_id = get_loggedin_userid();
                       if (is_plugin_enabled('facebookservice')) {
                             ?>
                            <div style="float: right; width: 44px;margin-right: 10px">
                            <?php 
                             $api_id = get_plugin_setting('api_id', 'facebookservice');
                             $api_secret = get_plugin_setting('api_secret', 'facebookservice');
                             if ($api_id && $api_secret){                                
                                 $facebook_uid = get_plugin_usersetting('facebook_uid', $user_id, 'facebookservice');
                                 $facebook_token = get_plugin_usersetting('facebook_token', $user_id, 'facebookservice');
                                 if ($facebook_uid && $facebook_token) {
                                     $checked = (facebookservice_can_status('thewire', $user_guid)) ? 'checked = checked' : '';
                                     $icon_fb_on = (facebookservice_can_status('thewire', $user_guid)) ? 'block' : 'none';
                                     $icon_fb_off = (facebookservice_can_status('thewire', $user_guid)) ? 'none' : 'block';
                                    ?>
                                     <div id="check_fb" style="float: left;width: 20px;margin-top: -2px">
                                        <input type="checkbox" id="fb_on" value="1" name="params[allowed_plugin:thewire]" <?php echo $checked ?>>    
                                     </div>
                                     <div id="icon_fb_on" style="display: <? echo $icon_fb_on ?>;float: right ;width: 20px">
                                        <img src="<?php echo $vars['url'] ?>mod/thewire/graphics/facebook16.png" title="Servicio de facebook activado"/>
                                     </div>
                                     <div id="icon_fb_off" style="display: <? echo $icon_fb_off ?>; float: right ;width: 20px">
                                        <img src="<?php echo $vars['url'] ?>mod/thewire/graphics/facebook16off.png" title="Servicio de facebook desactivado"/>
                                    </div>
                                    <?php 
                                 }
                                 else{
                                     ?>
                                    <div id="check_fb" style="float: left;width: 20px;margin-top: -2px">
                                        <input type="checkbox" id="fb_off" value="0" name="fb_off">   
                                    </div>
                                    <div id="icon_fb_off" style="float: right ;width: 20px">
                                        <img src="<?php echo $vars['url'] ?>mod/thewire/graphics/facebook16off.png" title="Servicio de facebook desactivado"/>
                                    </div>
                                     <?php 

                                 }
                             }
                             ?>
                            </div>
                            <?php 
                         }
                        
                        ?>
                        
	</form>
<div id="msj_service" style="display: none; color: #777777;text-align: center;margin-top: 10px; font-style: italic">
    <?php echo "Para poder compartir con esta red social, debes de configurar primero tu cuenta en: <a href=\"".$vars['url']."pg/settings/plugins\">Configuración de herramientas</a>" ?>
</div>
<script type="text/javascript">
	$.ajaxSetup ({
		cache: false
	});
	var ajax_load = "<img class='loading' src='img/load.gif' alt='espere...' />";
	
//	load() functions
	var loadUrl = "<?php echo $vars['url'] ?>action/plugins/usersettings/save";
        
        var allow_twett= 0, allow_fb= 0, 
        elgg_token = $('input[name="__elgg_token"]' ).val(),
        elgg_ts= $('input[name="__elgg_ts"]' ).val();
        
        //TWITTER
        $("#twitter_on").click(function(){
          if($(this).is(':checked')) {
            allow_twett = 1;
          }          
          $.ajax({
                type: "POST",
                url: loadUrl,
                data: "__elgg_token="+elgg_token+"&__elgg_ts="+elgg_ts+"&params[allowed_plugin:thewire]="+allow_twett+"&plugin=twitterservice",
                success: function(){
                    if(allow_twett){
                        $('#icon_twitter_on').show();
                        $('#icon_twitter_off').hide();
                    }
                    else{
                        $('#icon_twitter_on').hide();
                        $('#icon_twitter_off').show();
                    }
              }
          }); 
        });   
        
        
        $("#twitter_off").click(function(){
            $('#msj_service').show();
            $('#twitter_off').attr('checked', false);
        }); 
        
        //FACEBOOK
        $("#fb_on").click(function(){
          if($(this).is(':checked')) {
            allow_fb = 1;
          }          
          $.ajax({
                type: "POST",
                url: loadUrl,
                data: "__elgg_token="+elgg_token+"&__elgg_ts="+elgg_ts+"&params[allowed_plugin:thewire]="+allow_fb+"&plugin=facebookservice",
                success: function(){
                    if(allow_fb){
                        $('#icon_fb_on').show();
                        $('#icon_fb_off').hide();
                    }
                    else{
                        $('#icon_fb_on').hide();
                        $('#icon_fb_off').show();
                    }
              }
          }); 
        });   
        
        
        $("#fb_off").click(function(){
            $('#msj_service').show();
            $('#fb_off').attr('checked', false);
        }); 

</script>
</div>
<?php echo elgg_view('input/urlshortener'); ?>