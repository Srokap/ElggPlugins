<?php

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'thewire' => "Microblogging",
			'thewire:user' => "Red de %s",
			'thewire:posttitle' => "Notas de %s en buzzler",
			'thewire:everyone' => "Todos los mensajes de la comunidad",
	
			'thewire:read' => "Últimos mensajes enviados",
			'thewire:write' => "microblogging",
            
            'thewire:yours' => "Tus ultimos mensajes",
			'thewire:theirs' => "%s' mensajes",

			
			'thewire:strapline' => "%s",
	
			'thewire:add' => "Enviar mensaje a la comunidad",
		    'thewire:text' => "Dejar una nota en la comunidad",
			'thewire:reply' => "Responder",
			'thewire:via' => "a través de",
			'thewire:wired' => "Enviado a la comunidad",
			'thewire:charleft' => "caracteres por usar",
			'item:object:thewire' => "Microblogging",
			'thewire:notedeleted' => "nota borrada",
			'thewire:doing' => "Puedes dejar un mensaje a través del siguiente formulario:",
			'thewire:newpost' => 'Se publicó un nuevo mensaje para la comunidad',
			'thewire:addpost' => 'Enviar a la comunidad',
            'thewire:update' => ' actualizar',

	
        /**
	     * The wire river
	     **/
	        
	        //generic terms to use
	        'thewire:river:created' => "%s ha dicho",
	        
	        //these get inserted into the river links to take the user to the entity
	        'thewire:river:create' => "a la red",
	        
	    /**
	     * Wire widget
	     **/
	     
	        'thewire:sitedesc' => 'Este componente muestra las &uacute;ltimas notas enviadas a la red',
	        'thewire:yourdesc' => 'Este componente muestra la &uacute;ltimas notas enviadas a la red',
	        'thewire:friendsdesc' => 'Este componente mostrar&aacute; las &uacute;ltimas noticias de sus amigos en la red',
	        'thewire:friends' => 'Tus amigos en la red',
	        'thewire:num' => 'Número de mensajes a mostrar:',
            'thewire:moreposts' => 'Más mensajes publicados',
	        
	        
	
		/**
		 * Status messages
		 */
	
			'thewire:posted' => "El mensaje ha sido enviado a toda la red social",
			'thewire:deleted' => "El mensaje ha sido borrado del sistema",
	
		/**
		 * Error messages
		 */
	
			'thewire:blank' => "Necesitas rellenar el cuadro de texto para poder guardarlo",
			'thewire:notfound' => "No encontramos el mensaje que buscas. Intentalo de nuevo o ponte en contacto con el administrador",
			'thewire:notdeleted' => "No podemos borrar el mensaje!. Intentalo de nuevo o ponte en contacto con el administrador",
	
	
		/**
		 * Settings
		 */
			'thewire:smsnumber' => "El número SMS es diferente del número de móvil que tienes en el sistema. Recuerda que debes especificar el formato internacional (SP= +34)",
			'thewire:channelsms' => "El número para enviar mensajes SMS es <b>%s</b>",
            

			
	);
					
	add_translation("es",$spanish);

?>
