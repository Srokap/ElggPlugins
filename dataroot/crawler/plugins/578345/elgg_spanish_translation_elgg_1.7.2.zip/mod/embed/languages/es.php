<?php

	$spanish = array(
	
		'media:insert' => 'Insertar / Subir fichero',
	
		'embed:instructions' => 'Selecciona el fichero que deseas insertar en el comentario. Simplemente haz "click" sobre él',
	
		'embed:media' => 'Insertar fichero',
		'upload:media' => 'Subir fichero',
	
		'embed:file:required' => 'No tienes una aplicación para subir ficheros instalada. Ponte en contacto con el administrador para que habilite el plugin.',
	
	);
					
	add_translation("es",$spanish);

?>
