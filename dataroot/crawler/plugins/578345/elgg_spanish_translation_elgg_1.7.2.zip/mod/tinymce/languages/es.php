<?php

// Generado por translationbrowser 

$spanish = array( 
	 'tinymce:remove'  =>  "Añadir/Quitar editor"
); 

add_translation('es', $spanish); 

?>