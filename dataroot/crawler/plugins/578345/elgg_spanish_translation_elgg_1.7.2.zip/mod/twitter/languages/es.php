<?php

// Generado por translationbrowser 

$spanish = array( 
	 'twitter:username'  =>  "Entre su nombre de usuario en Twitter" , 
	 'twitter:num'  =>  "El número de tweets a mostrar" , 
	 'twitter:visit'  =>  "visite mi twitter" , 
	 'twitter:notset'  =>  "Este widget no está configurado para funcionar, para mostrar sus últimos tweets, haga click en -editar- y llene sus datos" , 
	 'twitter:river:created'  =>  "%s añadió el widget twitter" , 
	 'twitter:river:updated'  =>  "%s actualizó su widget twitter" , 
	 'twitter:river:delete'  =>  "%s eliminó su widget twitter"
); 

add_translation('es', $spanish); 

?>