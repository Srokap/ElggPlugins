<?php

// Generado por translationbrowser 

$spanish = array( 
	 'thewire'  =>  "Mensajes" , 
	 'thewire:user'  =>  "Red de %s" , 
	 'thewire:posttitle'  =>  "Notas de %s en la red: %s" , 
	 'thewire:everyone'  =>  "Todos los mensajes de la red .:ALD:." , 
	 'thewire:read'  =>  "Últimos mensajes enviados" , 
	 'thewire:write'  =>  "Mensajes" , 
	 'thewire:strapline'  =>  "%s" , 
	 'thewire:add'  =>  "Enviar mensaje a la red" , 
	 'thewire:text'  =>  "Dejar una nota en la red" , 
	 'thewire:reply'  =>  "Responder" , 
	 'thewire:via'  =>  "a través de" , 
	 'thewire:wired'  =>  "Enviado a la red .:ALD:." , 
	 'thewire:charleft'  =>  "caracteres por usar" , 
	 'item:object:thewire'  =>  "Env&iacute;os de la red" , 
	 'thewire:notedeleted'  =>  "nota borrada" , 
	 'thewire:doing'  =>  "Puedes dejar un comentario a través del siguiente formulario:" , 
	 'thewire:newpost'  =>  "Escribir comentario:" , 
	 'thewire:addpost'  =>  "Enviar a la red .:ALD:." , 
	 'thewire:river:created'  =>  "%s ha dicho" , 
	 'thewire:river:create'  =>  "a la red .:ALD:." , 
	 'thewire:sitedesc'  =>  "Este componente muestra las &uacute;ltimas notas enviadas a la red" , 
	 'thewire:yourdesc'  =>  "Este componente muestra la &uacute;ltimas notas enviadas a la red" , 
	 'thewire:friendsdesc'  =>  "Este componente mostrar&aacute; las &uacute;ltimas noticias de sus amigos en la red" , 
	 'thewire:friends'  =>  "Sus amigos en la red" , 
	 'thewire:num'  =>  "Número de mensajes a mostrar:" , 
	 'thewire:posted'  =>  "El mensaje ha sido enviado a toda la red social" , 
	 'thewire:deleted'  =>  "El mensaje ha sido borrado del sistema" , 
	 'thewire:blank'  =>  "Necesitas rellenar el cuadro de texto para poder guardarlo" , 
	 'thewire:notfound'  =>  "No encontramos el mensaje que buscas. Intentalo de nuevo o ponte en contacto con el administrador" , 
	 'thewire:notdeleted'  =>  "No podemos borrar el mensaje!. Intentalo de nuevo o ponte en contacto con el administrador" , 
	 'thewire:smsnumber'  =>  "El número SMS es diferente del número de móvil que tienes en el sistema. Recuerda que debes especificar el formato internacional (SP= +34)" , 
	 'thewire:channelsms'  =>  "El número para enviar mensajes SMS es <b>%s</b>" , 
	 'thewire:via_method'  =>  "via %s" , 
	 'thewire:by'  =>  "Post enviado por %s" , 
	 'thewire:update'  =>  "actualizar" , 
	 'thewire:moreposts'  =>  "Más post enviados"
); 

add_translation('es', $spanish); 

?>