<?php

// Generado por translationbrowser 

$spanish = array( 
	 'twitterservice'  =>  "Servicio Twitter" , 
	 'twitterservice:postwire'  =>  "Seleccionado esta opción, todos los mensajes que usted ponga en Wire serán enviados a su cuenta de twitter. Usted desea enviar sus mensajes de Wire a Twitter?" , 
	 'twitterservice:twittername'  =>  "Nombre de usuario en Twitter" , 
	 'twitterservice:twitterpass'  =>  "Password en Twitter"
); 

add_translation('es', $spanish); 

?>