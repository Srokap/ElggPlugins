<?php

// Generado por translationbrowser 

$spanish = array( 
	 'friends:widget:description'  =>  "Mostrar algunos amigos" , 
	 'friends:num_display'  =>  "Número de amigos a mostrar" , 
	 'friends:icon_size'  =>  "Tamaño de icono" , 
	 'friends:tiny'  =>  "muy pequeño" , 
	 'friends:small'  =>  "pequeño"
); 

add_translation('es', $spanish); 

?>