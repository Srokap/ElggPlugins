<?php
	/**
	 * Elgg tidypics plugin language pack
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$spanish = array(
			
		// Menu items and titles
			 
			'image' => "Imagen",
			'images' => "Imagenes",
			'caption' => "Leyenda",		
			'photos' => "Fotos",
			'images:upload' => "Subir Imagenes",
			'album' => "Álbum de Fotos",
			'albums' => "Albumes de Fotos",
			'album:yours' => "Tus albumes de fotos",
			'album:yours:friends' => "Álbumes de tus amigos",
			'album:user' => "Albumes de %s",
			'album:friends' => "Albumes de los amigos de %s",
			'album:all' => "Todos los álbumes",
			'album:group' => "Albumes del grupo",
	
		//actions
		
			'album:create' => "Nuevo álbum",
			'album:add' => "Añadir álbum de fotos",
			'album:addpix' => "Añadir fotos",		
			'album:edit' => "Modificar álbum",			
			'album:delete' => "Eliminar álbum",		

			'image:edit' => "Modificar imagen",
			'image:delete' => "Eliminar imagen",
		
		//forms
		
			'album:title' => "Título",
			'album:desc' => "Descripción",
			'album:tags' => "Etiquetas",
			'album:cover' => "¿Hacer que esta sea la portada del álbum?",
			'image:access:note' => "(los permisos de acceso se heredan del álbum)",
			
		//views 
		
			'image:total' => "Imagenes en el álbum:",
			'image:by' => "Imagen añadida por",
			'album:by' => "Album creado por",
			'image:none' => "Todavía no se han añadido imagenes.",
			'image:back' => "Anterior",
			'image:next' => "Siguiente",
		
		//widgets
		
			'album:widget' => "Albumes de Fotos",
			'album:more' => "Ver todos los albumes",
			'album:widget:description' => "Muestra tus álbumes de fotos más recientes",
			'album:display:number' => "Número de albumes a mostrar",
			'album:num_albums' => "Número de albumes a mostrar",
			
		//  river
		
			//images
			'image:river:created' => "%s subida",
			'image:river:item' => "una imagen",
			'image:river:annotate' => "%s comentada el",	
		
			//albums
			'album:river:created' => "%s creado",
			'album:river:item' => "un album",
			'album:river:annotate' => "%s comentado el",				
				
		//  Status messages
			
			'images:saved' => "La imagen ha sido guardada.",
			'images:saved' => "Todas las imágenes han sido guardadas.",
			'image:deleted' => "La imagen ha sido borrada.",			
			'image:delete:confirm' => "¿Confirmas el borrado de esta imagen?",
			
			'images:edited' => "Las imagenes han sido actualizadas.",
			'album:edited' => "El álbum ha sido actualizado.",
			'album:saved' => "El álbum ha sido guardado.",
			'album:deleted' => "El álbum ha sido borrado con éxito.",	
			'album:delete:confirm' => "¿Confirmas el borrado de este álbum?",
			'album:created' => 'El nuevo álbum ha sido creado.',
				
		//Error messages
				 
			'image:none' => "No ha sido psible encontrar ninguna imagen en este momento.",
			'image:uploadfailed' => "Ficheros no subidos:",
			'image:deletefailed' => "Tu imagen no ha podido ser borrada en este momento.",
			
			'image:notimage' => 'Sólo se aceptan imagenes jpeg, gif, o png.',
			'images:notedited' => 'No se pudieron actualizar todas las imágenes',
		 
			'album:none' => "Actualmente no hay ningún álbum de fotos.",
			'album:uploadfailed' => "No se ha podido guardar el álbum.",
			'album:deletefailed' => "En este momento no se ha podido borrar el álbum.",
	
	);
					
	add_translation("es",$spanish);
?>