﻿﻿<?php
$language = array (
  'messages:unreadcount' => '%s غیرخواندہ',
  'messages' => 'پیغامات',
  'messages:back' => 'واپس پیغامات کی طرف',
  'messages:user' => '%s کا ان باکس',
  'messages:posttitle' => '%s کے پیغامات : %s',
  'messages:inbox' => 'ان باکس',
  'messages:send' => 'ارسال کریں',
  'messages:sent' => 'ارسال',
  'messages:message' => 'پیغام',
  'messages:title' => 'عنوان',
  'messages:to' => 'بنام',
  'messages:from' => 'از',
  'messages:fly' => 'ارسال',
  'messages:replying' => 'پیغام کا جواب برائے',
  'messages:sendmessage' => 'پیغام ارسال کرین',
  'messages:compose' => 'پیغام تحریر کریں',
  'messages:add' => 'پیغام تحریر کریں',
  'messages:sentmessages' => 'ارسال کردہ پیغامات',
  'messages:recent' => 'حالیہ پیغامات',
  'messages:original' => 'اصل پیغام',
  'messages:yours' => 'آپکا پیغام',
  'messages:answer' => 'جواب',
  'messages:toggle' => 'ٹوگل کریں',
  'messages:markread' => '"خواندہ" نشان زد کریں',
  'messages:recipient' => 'وصول کنندہ منتخب کریں۔۔۔۔',
  'messages:to_user' => 'بنام : %s',
  'messages:new' => 'نیا پیغام',
  'notification:method:site' => 'سائٹ',
  'messages:error' => 'آپ کا پیغام محفوظ کرنے میں دشواری کا سامنا ہے۔ براہِ مہربانی دوبارہ کوشش کریں۔',
  'item:object:messages' => 'پیغامات',
  'messages:posted' => 'آپ کا پیغام کامیابی سے ارسال کر دیا گیا ہے۔',
  'messages:success:delete:single' => 'پیغام حزف کر دیا گیا۔',
  'messages:success:delete' => 'پیغامات حزف کر دئے گئے',
  'messages:success:read' => 'پیغامات "خواندہ" نشان زدہ کردئے گے۔',
  'messages:error:messages_not_selected' => 'کوئی پیغام منتخب نہیں ہے',
  'messages:error:delete:single' => 'پیغام حزف نہیں ہو سکتا۔',
  'messages:email:subject' => 'آپ کو ایک نیا پیغام موصول ہوا ہے !!! ',
  'messages:email:body' => 'آپ کو %s کی جانب سے ایک نیا پیغام موصول ہوا ہے۔ وہ لکھتے ہیں کہ :
%s

پیغامات دیکھنے کے لئے یہاں کلک کریں۔
%s
%s کو پیغام ارسال کرنے کے لئے یہاں کلک کریں۔
%s

آپ اس برقی خط کا جواب نہیں دے سکتے ۔۔۔۔۔',
  'messages:blank' => 'معذرت : پیغام کو محفوظ کرنے سے پہلے اس کے متن میں کچھ لکھنا لازمی ہے۔',
  'messages:notfound' => 'معذرت : ہمیں آپ کا مخصوص پیغام نہیں مل سکا۔',
  'messages:notdeleted' => 'معذرت : ہم یہ پیغال حزف نہیں کر سکتے۔',
  'messages:nopermission' => 'آپ کے پاس اس پیغام کو تبدیل کرنے کی اجازت نہیں ہے۔',
  'messages:nomessages' => 'یہاں کوئی پیغام موجود نہیں ہے۔',
  'messages:user:nonexist' => 'ہمیں صارف کے ڈیٹا بیس میں وصول کنندہ کا نام نہیں مل سکا۔',
  'messages:user:blank' => 'آپ نے یہ پیغام بھیجنے کے لئے کسی کو منتخب نہیں کیا۔',
  'messages:deleted_sender' => 'حذف شدہ رکن',
);
add_translation("ur", $language);
