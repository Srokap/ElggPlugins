﻿﻿<?php
$language = array (
  'dashboard:widget:group:title' => 'گروپ کی سرگرمی',
  'dashboard:widget:group:desc' => 'آپ کے کسی گروپ کی سرگرمی دکھائیں',
  'dashboard:widget:group:select' => 'گروپ منتخب کریں',
  'dashboard:widget:group:noactivity' => 'اس گروپ کی کوئی تازہ سرگرمی نہیں ہے۔',
  'dashboard:widget:group:noselect' => 'گروپ منتخب کرنے کے لئے اس ویجٹ کو تدوین کریں',
);
add_translation("ur", $language);
