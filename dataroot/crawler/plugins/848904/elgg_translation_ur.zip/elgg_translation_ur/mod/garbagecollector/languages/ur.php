<?php

// Generate By translationbrowser. 

$urdu = array( 
	 'garbagecollector:weekly'  =>  "ہفتے میں ایک بار" , 
	 'garbagecollector:monthly'  =>  "مہینے میں ایک بار" , 
	 'garbagecollector:yearly'  =>  "سال میں ایک بار" , 
	 'garbagecollector'  =>  "گاربیج جمع کرنے والا" , 
	 'garbagecollector:done'  =>  "ہو گیا" , 
	 'garbagecollector:error'  =>  "مسئلہ" , 
	 'garbagecollector:ok'  =>  "ٹھیک ہے" , 
); 

add_translation('ur', $urdu); 

?>