﻿﻿<?php
$language = array (
  'embed:embed' => 'نصب شدہ',
  'embed:media' => 'مواد نصب کریں',
  'embed:instructions' => 'کسی بھی فائل کو اپنے مواد میں نصب کرنے کےلئے اس پر کلک کریں۔',
  'embed:upload' => 'اپلوڈ میڈیا',
  'embed:upload_type' => 'اپلوڈ کی قسم :',
  'embed:no_upload_content' => 'کوئی مواد اپلوڈ نہیں !',
  'embed:no_section_content' => 'کوئی آئٹم نہیں موجود۔',
  'embed:no_sections' => 'کوئی تنصیبی پلگ ان نصب نہیں ہے۔ اپنے ایڈمنسٹریٹر سے اس بارےمیں رابطہ کریں۔',
);
add_translation("ur", $language);
