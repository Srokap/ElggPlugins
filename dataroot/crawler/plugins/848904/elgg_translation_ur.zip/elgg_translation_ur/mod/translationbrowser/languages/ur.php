<?php

// Generate By translationbrowser. 

$urdu = array( 
	 'translationbrowser'  =>  "مترجم براؤزر" , 
	 'translationbrowser:translate'  =>  "ترجمہ" , 
	 'translationbrowser:exporttranslations'  =>  "ترجمہ برآمد کریں " , 
	 'translationbrowser:selectlanguage'  =>  "زبان منتخب کریں" , 
	 'translationbrowser:selecttypeexport'  =>  "براہِ مہربانی برآمد کرنے کا طریقہ کار منتخب کریں۔" , 
	 'translationbrowser:languagebase'  =>  "زبان کا زخیرہ" , 
	 'translationbrowser:yourselectedlanguage'  =>  "آپ کی منتخب کردہ زبان" , 
	 'translationbrowser:youwilltranslate'  =>  "آپ ترجمہ کریں گے" , 
	 'translationbrowser:to'  =>  "سے" , 
	 'translationbrowser:languagecore'  =>  "سسٹم کی زبان" , 
	 'translationbrowser:selectmodule'  =>  "براہَ مہربانی وہ ماڈیول منتخب کریں جس کا آپ ترجمہ کرنا چاہتے ہیں پھر ترجمہ کر کلک کریں۔" , 
	 'translationbrowser:canyouedit'  =>  "آپ یہاں مواد میں ترمیم کر سکتے ہیں۔" , 
	 'translationbrowser:blanklang'  =>  "آپ ایک زبان لازمی منتخب کریں۔" , 
	 'translationbrowser:emptyfields'  =>  "آپ کم از کم ایک جملے کا ترجمہ لازمی کریں۔" , 
	 'translationbrowser:success'  =>  "ترجمہ کامیابی سے ہو گیا ہے۔" , 
	 'translationbrowser:save'  =>  "ترجمہ کرین۔" , 
	 'translationbrowser:userscanedit'  =>  "اراکین ترجمہ کرسکتے ہیں۔/" , 
	 'translationbrowser:export'  =>  "برآمد کرین"
); 

add_translation('ur', $urdu); 

?>