﻿﻿<?php
$language = array (
  'invitefriends:registration_disabled' => 'اس ویب سائٹ پر نئی رکنیت بند ہے۔ آپ کسی کو مدعو نہیں کر سکتے۔',
  'invitefriends:introduction' => 'اپنے دوست (دوستوں) کو اس نیٹورک پر لانے کے لئے ان کا برقی ربط لکھیں۔ (ایک لائن پر ایک ربط) ۔',
  'invitefriends:success' => 'آپکے دوستوں کو دعوت نامے ارسال ہو چُکے ہیں۔',
  'invitefriends:invitations_sent' => 'دعوت نامے ارسال برائے : %s
یہاں کچھ مسائل ہیں۔',
  'invitefriends:already_members' => 'مندرجہ ذیل پہلے سے صارف ہیں : %s',
  'invitefriends:message:default' => 'اسلامُ علیکم!
میں آپکو %s کا صارف بننے کی دعوت دیتا ہون۔',
  'invitefriends:email' => 'آپکو %s کا صارف بننے کے لئے %s نے دعوت دی ہے اور ساتھ میں یہ پیغام ہے:
%s
رکنیت کے لئے نیچے دیئے گئے ربط پر کلک کریں۔
%s
آپ خودکار طریقیے دونوں دوست بن جائیں گئے اگر آپ نے اوپر والے ربط سے رکنیت اختیار کی۔',
  'friends:invite' => 'دوستوں کو مدعو کریں',
  'invitefriends:message' => 'کوئی پیغام لکھیں ۔جو آپ چاہتے ہیں کے آپ کے دعوت نامہ کے ساتھ آپکے دوست کو موصول ہو۔',
  'invitefriends:subject' => 'دعوت نامہ برائے %s کی رکنیت',
  'invitefriends:email_error' => 'مندرجہ ذیل روابط درست نہیں ہیں: %s',
  'invitefriends:noemails' => 'کوئی برقی ربط داخل نہیں کیا گیا',
);
add_translation("ur", $language);
