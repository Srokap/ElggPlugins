﻿﻿<?php
$language = array (
  'expages' => 'سائٹ صفحات',
  'admin:appearance:expages' => 'سائٹ صفحات',
  'expages:about' => 'بارے من',
  'expages:terms' => 'قواعد و ضوابط',
  'expages:privacy' => 'پرائیویسی',
  'expages:contact' => 'رابطہ',
  'expages:notset' => 'یہ صفحہ ابھی بنایا نہیں گیا۔',
  'expages:posted' => 'آپ کے صفحہ کی کامیابی سے تجدید ہو گئی ہے۔',
  'expages:error' => 'صفحہ محفوظ کرنے میں مسئلہ آرہا ہے۔',
);
add_translation("ur", $language);
