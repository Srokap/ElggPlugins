<?php

// Generate By translationbrowser. 

$urdu = array( 
	 'search:enter_term'  =>  "تلاش کریں" , 
	 'search:no_results'  =>  "کوئی نتیجہ نہیں" , 
	 'search:results'  =>  "نتائج برائے %s" , 
	 'search:search_error'  =>  "مسئلہ" , 
	 'search:more'  =>  "+%s اور %s" , 
	 'search_types:tags'  =>  "ٹیگز" , 
	 'search_types:comments'  =>  "تبصرہ جات" , 
	 'search:comment_on'  =>  "\"%s\" پر تبصرہ" , 
	 'search:comment_by'  =>  "از" , 
	 'search:unavailable_entity'  =>  "غیر دستیاب مواد" , 
	 'search:matched'  =>  "ملائے گئے :" , 
	 'search:no_query'  =>  "تلاش کے لئے سوال درج کریں."
); 

add_translation('ur', $urdu); 

?>