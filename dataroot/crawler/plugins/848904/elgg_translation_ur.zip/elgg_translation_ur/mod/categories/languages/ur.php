﻿﻿<?php
$language = array (
  'categories' => 'زمرہ جات',
  'categories:settings' => 'سائٹ کے زمرہ جات مقرر کریں',
  'categories:explanation' => 'پوری سائٹ پر استعمال ہونے والے زمرہ جات بنانے کےلئے نیچے اُن کے نام لکھیں اور انہیں علیٰحدہ کرنے کے لئے کوما (،) ڈالیں ۔ جب صارفین کوئی تحریر وغیرہ لکھیں گے تو زمرہ جات کا آپشن شو ہو جائے گا۔',
  'categories:save:success' => 'سائٹ کے زمرہ جات محفوظ ہو چکے ہیں۔',
  'categories:results' => 'سائٹ زمرہ جات کے نتائج : %s',
  'categories:on_activate_reminder' => 'زمرہ جات بنانے کے بغیر سائٹ پر کام نہیں کریں گے۔. <a href="%s">زمرہ جات ابھی بنائیں۔</a>',
);
add_translation("ur", $language);
