<?php

// Generate By translationbrowser. 

$urdu = array( 
	 'tinymce:remove'  =>  "ایڈیٹر ختم کریں۔" , 
	 'tinymce:add'  =>  "ایڈیٹر شامل کریں۔" , 
	 'tinymce:word_count'  =>  "الفاظ کی گنتی"
); 

add_translation('ur', $urdu); 

?>