﻿﻿<?php
$language = array (
  'members:searchname' => 'نام کے ذریعے صارفین کی تلاش',
  'members:searchtag' => 'ٹیگ کے ذریعے صارفین کی تلاش',
  'members:title:searchname' => 'صارف کی تلاش برائے %s',
  'members:title:searchtag' => 'صارفین کو ٹیگ کیا گیا %s کے ذریعے',
  'members:label:newest' => 'تازہ ترین',
  'members:label:popular' => 'مقبول',
  'members:label:online' => 'آن لائن',
);
add_translation("ur", $language);
