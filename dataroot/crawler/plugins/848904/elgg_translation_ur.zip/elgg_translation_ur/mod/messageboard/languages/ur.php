﻿﻿<?php
$language = array (
  'messageboard:desc' => 'یہ ایک پیغام بورڈ ہے جسے آپ اپنے کوائف نامہ  پر رکھ سکتے ہیں جہاں دوسرے صارفین تبصرہ کر سکتے ہیں۔.',
  'messageboard:board' => 'پیغام بورڈ',
  'messageboard:messageboard' => 'پیغام بورڈ',
  'messageboard:viewall' => 'تمام دیکھیں',
  'messageboard:postit' => 'شائع',
  'messageboard:history:title' => 'حالیہ',
  'messageboard:none' => 'ابھی یہاں کوئی پیغام نہیں ہے۔',
  'messageboard:num_display' => 'پیغام دکھانے کی تعداد',
  'messageboard:user' => '%s کا پیغام بورڈ',
  'messageboard:replyon' => 'تبصرہ برائے',
  'messageboard:history' => 'تاریخ',
  'messageboard:owner' => '%s کا پیغام بورڈ',
  'messageboard:owner_history' => '%s نے %s کے پیغام بورڈ پر تحریر کیا',
  'river:messageboard:user:default' => '%s نے %s کے پیغام بورڈ پر تحریر کیا',
  'messageboard:posted' => 'آپ نے کامیابی کے ساتھ پیغام بورڈ پر تحریر کیا۔',
  'messageboard:deleted' => 'آپ نے کامیابی کے ساتھ پیغام حذف کر دیا۔',
  'messageboard:email:subject' => 'آپ کے پیغام بورڈ پر نیا تبصرہ کیا گیا ہے !',
  'messageboard:email:body' => '%s نے آپ کے پیغام بورڈ پر تبصرہ کیا ہے۔ وہ لکھتے ہیں کہ:

%s

اپنے پیغام بورڈ کے تبصرہ جات دیکھنے کے لئے یہاں کلک کریں:
%s

%s کا کوائف نامہ دیکھنے کے لئے یہاں کلک کریں:

%s

آپ اس برقی ڈاک کا جواب نہیں دے سکتے ۔۔۔۔',
  'messageboard:blank' => 'معذرت : آپ کا پیغام محفوظ نہیں ہو سکتا ، کیونکہ آپ نے پیغام کے خانے کو خالی چھوڑ دیا ہے۔',
  'messageboard:notfound' => 'معذرت : آپ کی مطلوبہ چیز نہیں ملی ۔',
  'messageboard:notdeleted' => 'معذرت : یہ پیغام حذف نہیں ہو سکتا۔',
  'messageboard:somethingwentwrong' => 'آپ کا پیغام محفوظ کرنے میں کچھ تکنیکی مسئلہ آرہا ہے ۔آپ یقین کر لیں کہ آپ کا پیغام لکھا گیا تھا۔',
  'messageboard:failure' => 'آپ کا پیغام شائع کرنے میں کوئی تکنیکی مسئلہ آ رہا ہے۔ براہِ مہربانی دوبارہ کوشش کریں۔',
);
add_translation("ur", $language);
