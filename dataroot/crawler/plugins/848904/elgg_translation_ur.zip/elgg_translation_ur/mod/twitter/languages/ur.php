﻿﻿<?php
$language = array (
  'twitter:title' => 'ٹویٹر',
  'twitter:info' => 'آپ کی تازہ ترین ٹیٹ دکھائیں',
  'twitter:username' => 'اپنی ٹویٹر کی رکنیت داخل کریں۔',
  'twitter:num' => 'ٹویٹ دکھانے کی تعداد',
  'twitter:visit' => 'میرے ٹویٹر کا دورہ کریں',
  'twitter:notset' => 'ٹویٹر کا ویجٹ ابھی تیار نہیں ہے۔ ٹویٹ دکھانے کے لئے تدوین پر کلک کر کے اپنے کوائف لکھیں۔',
);
add_translation("ur", $language);
