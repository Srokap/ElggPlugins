﻿﻿<?php
$language = array (
  'tagcloud:widget:title' => 'ٹیگ کلاؤڈ',
  'tagcloud:widget:description' => 'ٹیگ کلاؤڈ',
  'tagcloud:widget:numtags' => 'ٹیگ دکھانے کی تعداد',
);
add_translation("ur", $language);
