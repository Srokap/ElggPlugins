﻿﻿<?php
$language = array (
  'notifications:subscriptions:title' => 'صارف کے اطلاع نامے',
  'friends:all' => 'سارے دوست احباب',
  'notifications:subscriptions:personal:title' => 'ذاتی اطلاع نامے',
  'notifications:subscriptions:friends:title' => 'دوست احباب',
  'notifications:subscriptions:collections:edit' => 'اپنی مشترکہ رسائی کی اطلاعات میں ترمیم کرنے کے لیے یہاں کلک کریں',
  'notifications:subscriptions:changesettings' => 'اطلاعات',
  'notifications:subscriptions:changesettings:groups' => 'گروپ کے اطلاع نامے',
  'notifications:subscriptions:success' => 'آپ کے اطلاع نامے کی ترتیبات محفوظ ہو چکی ہیں۔',
  'notifications:subscriptions:personal:description' => 'اپنے مواد پر ہونے والے فعل کی اطلاع موصول کریں',
  'notifications:subscriptions:friends:description' => 'مندرجہ ذیل آپ کے دوستوں کی خودکار فہرست ہے۔ اگر آپ ان کی جانب سے اپ ڈیٹس موصول کرنا چاہتے ہیں ۔ اس سے اس صفحے کے سب سے نیثے دیئے گئے خانے میں موجود اراکین کی فہرست پر اثر پڑے گا۔ ',
  'notifications:subscriptions:description' => 'اگر آپ چاہتے ہیں کہ جب آپ کے دوست آپ کوئی نیا مواد شامل کریں تو آپ کو مطلع کیا جائے تو نیچے ان کو منتخب کرنے کے بعد اطلاع نامے کا طریقہ کار منتخب کریں۔',
  'notifications:subscriptions:groups:description' => 'اگر آپ چاہتے ہیں کہ جس گروپ کے آپ رکن ہیں اس میں کوئی نیا مواد شامل ہونے پر آپ کو مطلع کیا جائے تو اس گروپ کو نیچے منتخب کریں اور اطلاع نامے کا طریقہ کار منتخب کریں۔',
);
add_translation("ur", $language);
