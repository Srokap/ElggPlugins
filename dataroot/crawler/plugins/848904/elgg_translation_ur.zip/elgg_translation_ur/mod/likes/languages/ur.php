﻿﻿<?php
$language = array (
  'likes:notifications:body' => 'اسلامُ علیکم %1 ،
%2 نے آپ کی تحریر "%3" جوکہ %4 میں ہے کو پسند کیا ہے۔
آپ اپنی اصل تحریر یہاں دیکھ سکتے ہیں۔
%5
یا پھر %2 کا کوائف نامہ یہاں دیکھ سکتے ہیں۔
%6
شکریہ،
%4$s',
  'likes:likes' => 'آپ نے ابھی کچھ پسند کیا ہے',
  'likes:this' => 'پسند کیا',
  'likes:deleted' => 'آپ کی پسند ختم ہو گئی ہے',
  'likes:see' => 'دیکھیں کس نے پسند کیا ہے۔',
  'likes:remove' => 'ناپسند کریں',
  'likes:notdeleted' => 'آپ کی پسند ختم کرنے میں مسئلہ آ رہا ہے',
  'likes:failure' => 'اسے پسند کرنے میں مسئلہ آرہا ہے',
  'likes:alreadyliked' => 'اپ پہلے ہی اسے پسند کر چُکے ہیں',
  'likes:notfound' => 'جسے آپ پسند کرنے کی کوشش کر رہے ہیں وہ موجود نہیں ہے',
  'likes:likethis' => 'پسند کریں',
  'likes:userlikedthis' => '%s پسندیدہ',
  'likes:userslikedthis' => '%s پسندیدہ',
  'likes:river:annotate' => 'پسندیدہ',
  'river:likes' => 'پسندیدہ %s %s',
  'likes:notifications:subject' => '%s نے آپ کی تحریر "%s" کو پسند کیا',
);
add_translation("ur", $language);
