﻿﻿<?php
$language = array (
  'email:validate:body' => '%s،
%s کے باقاعدہ استعمال سے پہلے آپ کو اپنے برقی ربط کی تصدیق کروانی ہوگی
براہِ مہربانی نیچے دیئے گے ربط پر کلک کر کے اپنے برقی ربط کی تصدیق کروائیں۔
%s
اگر ربط کھل نہیں رہا تو اسے آپ کاپی اور پیسٹ کریں اپنے براؤزر میں۔
%s
%s',
  'email:confirm:success' => 'آپ کے برقی ربط کی تصدیق ہو گئی ہے۔',
  'uservalidationbyemail:admin:no_unvalidated_users' => 'کوئی غیرتصدیقی صارف نہیں ہے۔',
  'uservalidationbyemail:confirm_validate_checked' => 'منتخب صارفین کی تصدیق کریں؟',
  'uservalidationbyemail:confirm_resend_validation_checked' => 'منتخب صارفین کو تصدیقی درخواست بھیجیں؟',
  'uservalidationbyemail:confirm_delete_checked' => 'منتخب صارفین کو حذف کریں؟',
  'uservalidationbyemail:errors:unknown_users' => 'نامعلوم صارفین',
  'uservalidationbyemail:errors:could_not_validate_user' => 'صارف کی تصدیق نہیں ہو سکتی۔',
  'uservalidationbyemail:errors:could_not_validate_users' => 'منتخب صارفین کی تصدیق نہیں ہو سکتی۔',
  'uservalidationbyemail:errors:could_not_delete_user' => 'صارفین حذف نہیں ہو سکتا۔',
  'uservalidationbyemail:errors:could_not_delete_users' => 'منتخب صارفین حذف نہیں ہو سکتے۔',
  'uservalidationbyemail:errors:could_not_resend_validations' => 'تمام منتخب صارفین کو تصدیقی درخواستیں نہیں بھیجی جا سکتیں۔',
  'uservalidationbyemail:messages:validated_user' => 'صارف کی تصدیق کر دی گئی ہے۔',
  'uservalidationbyemail:messages:validated_users' => 'تمام منتخب صارف کی تصدیق کر دی گئی ہے۔',
  'uservalidationbyemail:messages:deleted_user' => 'صارف حذف کر دیا گیا ہے۔',
  'uservalidationbyemail:messages:deleted_users' => 'تمام منتخب صارفین حذف کر دئے گئے ہیں۔',
  'uservalidationbyemail:messages:resent_validations' => 'تمام منتخب صارفین کو تصدیقی درخواستیں بھیج دی گئی ہیں۔',
  'uservalidationbyemail:login:fail' => 'آپ کا اکاؤنٹ تصدیق شدہ نہیں ہے ، اس لئے آپ لاگ ان نہیں ہو سکتے۔ آپ کو ایک اور تصدیقی ڈاک بھیج دی گئی ہے۔',
  'uservalidationbyemail:admin:unvalidated' => 'غیرتصدیق شدہ',
  'uservalidationbyemail:admin:user_created' => '%s رجسٹرڈ',
  'uservalidationbyemail:admin:resend_validation' => 'تصدیقی درخواست دوبارہ بھیجیں',
  'uservalidationbyemail:admin:validate' => 'تصدیق',
  'uservalidationbyemail:admin:delete' => 'حذف',
  'uservalidationbyemail:confirm_validate_user' => '%s کی تصدیق کریں؟',
  'uservalidationbyemail:confirm_resend_validation' => '%s کو تصدیقی درخواست دوبارہ بھیجیں؟',
  'uservalidationbyemail:confirm_delete' => '%s کو حذف کریں؟',
  'uservalidationbyemail:check_all' => 'تمام',
  'uservalidationbyemail:errors:could_not_resend_validation' => 'تصدیقی درخواست بھیجی نہیں جا سکتی۔',
  'uservalidationbyemail:messages:resent_validation' => 'تصدیقی درخواست بھیج دی گئی ہے۔',
  'admin:users:unvalidated' => 'غیر تصدیق شدہ',
  'email:validate:subject' => '%s براہِ مہربانی %s کیلئے اپنے برقی ربط کی تصدیق کریں۔',
  'email:confirm:fail' => 'آپ کے برقی ربط کی تصدیق نہیں ہو سکی۔۔',
  'uservalidationbyemail:registerok' => 'اپنے کھاتے کو فعال بنانے کے لئے اس ربط پر کلک کریں جو آپ کو ابھی برقی ڈاک کے ذریعے بھیجا گیا ہے۔',
);
add_translation("ur", $language);
