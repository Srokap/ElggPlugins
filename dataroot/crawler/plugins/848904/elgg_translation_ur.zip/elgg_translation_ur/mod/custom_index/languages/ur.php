﻿﻿<?php
$language = array (
  'custom:welcome' => 'خوش آمدید',
  'custom:bookmarks' => 'حالیہ بُک مارک',
  'custom:groups' => 'حالیہ گروپ تحریریں',
  'custom:files' => 'حالیہ فائلیں',
  'custom:blogs' => 'حالیہ بلاگ تحریریں',
  'custom:members' => 'حالیہ صارفین',
);
add_translation("ur", $language);
