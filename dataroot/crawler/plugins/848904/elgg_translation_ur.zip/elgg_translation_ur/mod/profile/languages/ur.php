<?php

// Generate By translationbrowser. 

$urdu = array( 
	 'profile'  =>  "کوائف نامہ" , 
	 'profile:notfound'  =>  "معذرت ، آپ کا مطلوبہ کوائف نامہ موجود نہیں ہے۔"
); 

add_translation('ur', $urdu); 

?>