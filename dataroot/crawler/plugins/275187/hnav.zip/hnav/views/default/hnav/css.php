/* ***************************************
  HORIZONTAL ELGG TOP BAR
*************************************** */

#elgg_topbar {
	background:#333333 url(/mod/theme_ell_1/graphics/toptoolbar_background.gif) repeat-x top left;
	color:#eeeeee; border-bottom:1px solid #000000;	min-width: 974px; position:relative;
	width:100%; 	height:24px;
	z-index: 9000; /* if you have multiple position:relative elements, then IE sets up separate Z layer contexts for each one, which ignore each other */
}

#elgg_topbar {font-family: Verdana; font-size:0.8em}


#elgg_topbar_container_left { float:left;	height:24px; left:0px; top:0px; position:absolute; text-align:left;	 }

#elgg_topbar_container_right { float:right;	height:24px; 
	text-align:right; margin-left:4px; position:relative; } /* position:absolute;	right:0px;	top:0px; */ /* width:120px;*/	
	
#elgg_topbar_container_search {	float:right; height:21px; 
	text-align:right; margin:3px 0 0 0; }  /*width:280px; position:relative;	right:120px; */
	
#elgg_topbar_container_left .toolbarimages { float:left; margin-right:1px; }
#elgg_topbar_container_left .toolbarlinks { margin:0 0 1px 0;	float:left; margin-top:4px; }
#elgg_topbar_container_left a.menuitemtools { margin:0px 0 7px 0; padding-top: 8px;	float:left; }

#elgg_topbar_container_left .toolbarlinks2 { margin:4px 0 1px 0; float:left; margin-top:1px; }
#elgg_topbar_container_left a.loggedinuser { color:#eeeeee;	font-weight:bold; margin:0 0 0 5px; }
#elgg_topbar_container_left a.pagelinks { color:white;	margin:5px 15px 0 5px; display:block;	padding:3px; }
#elgg_topbar_container_left a.pagelinks:hover {	background: #4690d6; text-decoration: none; }
#elgg_topbar_container_left a.privatemessages {	
	background:transparent url(/mod/theme_ell_1/graphics/toolbar_messages_icon.gif) no-repeat left 2px;
	padding:0 0 4px 16px; margin:0 5px 0 5px;	cursor:pointer; }
#elgg_topbar_container_left a.privatemessages:hover {
	background:transparent url(/mod/theme_ell_1/graphics/toolbar_messages_icon.gif) no-repeat left -36px;
	text-decoration: none; }
#elgg_topbar_container_left a.privatemessages_new {
	background:transparent url(/mod/theme_ell_1/graphics/toolbar_messages_icon.gif) no-repeat left -17px;
	padding:0 0 0 18px;	margin:0 15px 0 5px; color:white; }
	
/* IE6 */
* html #elgg_topbar_container_left a.privatemessages_new { background-position: left -18px; } 
/* IE7 */
*+html #elgg_topbar_container_left a.privatemessages_new { background-position: left -18px; } 

#elgg_topbar_container_left a.privatemessages_new:hover { text-decoration: none; }
#elgg_topbar_container_left a.usersettings { margin:0 0 0 20px;	color:#999999; padding:3px; }
#elgg_topbar_container_left a.usersettings:hover { color:#eeeeee; }
#elgg_topbar_container_left img { margin:0 0 0 5px; }
#elgg_topbar_container_left .user_mini_avatar {	border:1px solid #eeeeee; margin:0 0 0 20px; }


#elgg_topbar_container_right { padding:3px 0 0 0; }

#elgg_topbar_container_right ul { display:inline; float:left; list-style-type: none; }
#elgg_topbar_container_right ul li { display: block; list-style: none; margin: 0;	padding: 0;	float: left; position: relative; }

#elgg_topbar_container_right a { margin:0; padding: 0;padding-right:10px; color:white; font-weight: bold; background: none;}


#elgg_topbar_container_right_bollocks_MBNO a { 
	background:transparent url(/mod/theme_ell_1/graphics/elgg_toolbar_logout.gif) no-repeat top right;
	color:#eeeeee; 	margin:0 5px 0 0; padding:0 21px 0 0; display:block; height:20px; }
/* IE6 fix */
* html #elgg_topbar_container_right_MBNO a { width: 120px; }
#elgg_topbar_container_right a:hover { background-position: right -21px; }
#elgg_topbar_panel { background:#333333; color:#eeeeee;	height:180px; width:100%; padding:10px 20px 10px 20px;
	display:none; position:relative; }
	
#searchform input.search_input { background-color:#FFFFFF; border:1px solid #BBBBBB; color:#999999; font-size:12px;
	font-weight:bold; margin:0pt; padding:2px; width:180px; height:12px;
} /*	-webkit-border-radius: 4px; -moz-border-radius: 4px; */
#searchform input.search_submit_button {
	color:#333333;	background: #cccccc; border:none; font-size:12px; font-weight:bold;
	margin:0px;	padding:2px; width:auto; height:18px; cursor:pointer;
} 	/* -webkit-border-radius: 4px; -moz-border-radius: 4px; */ 
#searchform input.search_submit_button:hover { color:#ffffff; background: #4690d6; }


/* ***************************************
	TOP BAR - TOOLS / USER-CONTENT MENU
*************************************** */

ul.topbardropdownmenu, ul.topbardropdownmenu ul 
{
font-family: Verdana; font-size:1.1em;
}



/* elgg toolbar menu setup */
ul.topbardropdownmenu, ul.topbardropdownmenu ul { margin:0; padding:0; display:inline; float:left; list-style-type: none;
	z-index: 9000; position: relative; }
ul.topbardropdownmenu {	margin:0pt 10px 0pt 5px; margin-top: -3px;}
ul.topbardropdownmenu li { display: block; list-style: none; margin: 0;	padding: 0;	float: left; position: relative; }
ul.topbardropdownmenu a { display:block; }
ul.topbardropdownmenu ul { display: none; position: absolute; left: 0;	margin: 0;	padding: 0; }
/* IE6 fix */
* html ul.topbardropdownmenu ul {	line-height: 1.1em; }
/* IE6/7 fix */
ul.topbardropdownmenu ul a { zoom: 1; } 
ul.topbardropdownmenu ul li { float: none; }

/* *** MENU STYLE */
/* *************** */
ul.topbardropdownmenu ul { width: 150px; top: 24px;	border-top:1px solid black; }
ul.topbardropdownmenu *:hover {	background-color: none; }
ul.topbardropdownmenu a { padding:3px; text-decoration:none; color:white; }
ul.topbardropdownmenu li.hover a { background-color: #333333; text-decoration: none; }
ul.topbardropdownmenu ul li.drop a { font-weight: normal; }
/* IE7 fixes */
*:first-child+html #elgg_topbar_container_left a.pagelinks { }
*:first-child+html ul.topbardropdownmenu li.drop a.menuitemtools { padding-bottom:6px; }

ul.topbardropdownmenu ul li a {	background-color: #333333;/* menu off state color */
	font-weight: bold; padding-left:6px; padding-top:4px; padding-bottom:0;	height:22px; 
	border-bottom: 1px solid white; }
ul.topbardropdownmenu ul a.hover { background-color: #0054a7; }
ul.topbardropdownmenu ul a { opacity: 0.9;	filter: alpha(opacity=90); }


/* ***************************************************************************************
                                        TABS (Navigation at the top)
    *************************************************************************************** */

#tabs ul
{
    list-style: none;
	margin-top:-12px;
}

#tabs ul li
{
    float: left;
    PADDING-RIGHT: 7px; PADDING-LEFT: 7px;
}

#tabs ul li a
{
    padding-right: 1px;
    padding-left: 1px;
    font-size: 1.2em;
    float: left;
    margin-bottom: 2px;
    padding-bottom: 0px;
    color: #ffffff;
    line-height: 25px;
    padding-top: 0px;
    text-decoration: none;
    margin-bottom: 0px;
    cursor: default;
    cursor: pointer;
}


#logoholder { padding-bottom:15px;}

ul.topbardropdownmenu li.sel  {border-bottom: #FF9393 2px solid; }

#tabs ul li.sel a
{
    padding-right: 1px;
    padding-left: 1px;
    font-size: 1.2em;
    float: left;
    margin-bottom: 2px;
    padding-bottom: 0px;
    color: #ffffff;
    line-height: 25px;
    padding-top: 0px;
    text-decoration: none;
    margin-bottom: 0px;
    cursor: default;
    cursor: pointer;
    border-bottom: #FF9393 2px solid;
}

    .ggg
    {padding-bottom: 0px;
    color: #555555;
    text-decoration: none;

    font-size: 12px;

    MARGIN-BOTTOM: 2px;
    PADDING-BOTTOM: 0px; LINE-HEIGHT: 25px; PADDING-TOP: 0px;
     vertical-align:top;
}

#tabs ul li1 a:link {color: blue;}        /* specificity = 1,1 */
#tabs ul li1 a:active {color: red;}       /* specificity = 1,1 */
#tabs ul li a:hover
{
    border-bottom: solid 2px red;
}    /* specificity = 1,1 */
#tabs ul li1 a:visited {color: purple;}   /* specificity = 1,1 */


#tabs ul li2 a:hover
{
    margin: 0 5px 0 0;
    padding: 0;
    padding-bottom:8px;
    color: #121212;
    text-decoration: none;

}


#tabs ul2 li#active a
{
    color: #333333;
}

