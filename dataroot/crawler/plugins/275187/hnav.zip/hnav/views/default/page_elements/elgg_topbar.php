<?php

	/**
	 * MODIFIED Elgg top toolbar
	 * Mark Beachill
	 * Version 0.1
	 *
	 * Horizontal nav with section highlighting
	 */
	 
	 $tbLoggedIn = false;
	 $tbUserName = "";
	 if (isloggedin()) { 
	   $tbLoggedIn = true;
	   $tbUserName = $_SESSION['user']->username;
	 }
	 


	/**
	 * START "WhereAreWe" 
	 * which first-level folder is the the page in? 
	 * ignores the pg and the mod folder starts
	 * removes letter s's at the end of folders
	 * it gives us $folder and $isgrp
	 * e.g. /mod/blogs/new/etc returns blog 
	 * and if the blog is in a group then $isgrp = true 
	 */
 
	// lowercase url	 
	$url = strtolower($_SERVER["REQUEST_URI"]);
	// chop off most common beginnings
	if (substr($url,0,3)=="/pg") {$url=substr($url,4,strlen($url)-4);}
	  else
	{
	  if (substr($url,0,4)=="/mod") {$url=substr($url,5,strlen($url)-5);}
	}
	// go away leading slashes
	if (substr($url,0,1)=="/") {$url=substr($url,1,strlen($url)-1);}
	// now let's get the folder
	$folder = "";
	$pos = strpos($url . "/", "/");  // find first slash
	if ($pos !== false) { $folder = substr($url,0,$pos); } // remove to first slash
	// chop off any s's at the end for blog/blogs etc
	if (substr($folder, -1, 1)=="s") {$folder = substr($folder,0,-1);}; 
	// the group exception
	$isgrp = false;
	if ($folder=="group") {$isgrp = true;} else
	{
  		$this_page_owner = page_owner_entity();
  		if ($this_page_owner instanceof ElggGroup) { $isgrp = true;}
	}
	/**
	 * END "WhereAreWe" 
	 */




	/**
	 * Functions to show links with optional class="sel" when selected set
	 */

	function ShowDropDownLink($link, $text, $name="")
	{
			echo "<li><a href=\"" . $link . "\" name=\"" . $name . "\">" . $text . "</a></li>";
	}


	function ShowLinkSelected($isselected, $link, $text, $name="")
	{
    	if ($isselected)
  		{
			echo "<li class=sel><a href=\"" . $link . "\" name=\"" . $name . "\">" . $text . "</a></li>";
		}
		else
		{
			echo "<li><a href=\"" . $link . "\" name=\"" . $name . "\">" . $text . "</a></li>";
		}
	}


	function ShowLink($folderextracted, $foldertotest, $link, $text, $name="")
	{
		if ($folderextracted==$foldertotest)
		{
			ShowLinkSelected(true, $link, $text, $name);
		}
		else
		{
			ShowLinkSelected(false, $link, $text, $name);
		}
  	}
	
	/**
	 * End Functions to show links with optional class="sel" when selected set
	 */
	 
	 
	 // CUSTOM 0: see put your logo and width below
	 
?>
<div style="margin: 0 auto;margin-bottom:15px;">
<div style="width: 975px;    margin: 0 auto;padding-top:5px;" >
<div id="logoholder"><a href="/"><img src="yourlogo.jpg" alt="your logo" width=975 height=50 /></a></div>
<div></div>


<div id="elgg_topbar" style="margin: 0 auto; width: 975px; padding-top: 5px;">

<div id="elgg_topbar_container_left">

<div class="toolbarlinks2">
<div id="tabs-out" class="noprint"><div id="tabs" class="noprint">
<!--<h3 class="noscreen">Navigation</h3>-->
<ul class="box">


<?php


// do something with blank folder
if ($folder=="") {$folder=".default";}; 
// set folder to group if a group object
if ($isgrp) {$folder="group";};



// CUSTOM 1: list of folders for highlighting user dropdown 
// (see CUSTOM 5)



if ($tbLoggedIn)
{
	// CUSTOM 2: logged in user links 
	
	// links when logged in 


    // check for user folder
    // change $userdropdownfolders below (remember no s's at end!)
    $userdropdownfolders = "|profile|dashboard|setting|friend|bookmark|";
    if (strpos($userdropdownfolders, "|" . $folder . "|") !== false) {$folder = ".userdropdown";}

	// check for default
	// !IMPORTANT make list include all folders where you use show link on (except default)
	$listoflinkfolders = "|blog|photo|thewire|group|event_calendar|member|izap_video|";
	if (($folder!=".userdropdown") && (strpos($listoflinkfolders, "|" . $folder . "|") === false)) {$folder = ".default";};
	
	// comment out links you dont want and cut and paste to change order
	// remember to change list of link folders above
	ShowLink($folder, ".default", "/", "Home");
 	ShowLink($folder, "blog", "/mod/blog/everyone.php", "Blogs");
	ShowLink($folder, "photo", "/pg/photos/world/", "Photos");
	ShowLink($folder, "thewire", "/mod/thewire/everyone.php", "The Wire", "Like Twitter!");
	ShowLink($folder, "group", "/pg/groups/world/", "Groups");
	ShowLink($folder, "event_calendar", "/pg/event_calendar/", "Events");
	ShowLink($folder, "member", "/mod/members/index.php", "Members");
	ShowLink($folder, "izap_video", "/pg/izap_videos", "Videos");
}
else
{

	// CUSTOM 3: not logged in user links 

	// check for default
	// !IMPORTANT make list include all folders that you use show link on except default
	$listoflinkfolders = "|blog|photo|thewire|event_calendar|izap_video|";
	if (($folder!=".userdropdown") && (strpos($listoflinkfolders, "|" . $folder . "|") === false)) {$folder = ".default";};
	
	ShowLink($folder, ".default", "/", "Home");
	ShowLink($folder, "blog", "/mod/blog/everyone.php", "Blogs");
	ShowLink($folder, "photo", "/pg/photos/world/", "Photos");
	ShowLink($folder, "thewire", "/mod/thewire/everyone.php", "The Wire", "Like Twitter!");
	//ShowLink($folder, "group", "/pg/groups/world/", "Groups");
	ShowLink($folder, "event_calendar", "/pg/event_calendar/", "Events");
	//ShowLink($folder, "member", "/mod/members/index.php", "Members");
	ShowLink($folder, "izap_video", "/pg/izap_videos", "Videos");
}
?>
</ul>
</div></div>
</div>

<?php
if ($tbLoggedIn) 
{


	// CUSTOM 4: user drop shown link
?>

	<div class="toolbarlinks">
	<ul class="topbardropdownmenu">
    <?php
	
	// see custom 1 for whether the userdropdown is shown
	if ($folder == ".userdropdown") 
	{
		echo "<li class=\"drop sel\"><a href=\"/pg/profile/" . $tbUserName . "\" class=\"menuitemtools\">My Stuff</a>";
	}
	else
	{
		echo "<li class=\"drop\"><a href=\"/pg/profile/" . $tbUserName . "\" class=\"menuitemtools\">My Stuff</a>";
	}
	
	?>
	<ul>
	
<?php
// add admin link in dropdown
if ($vars['user']->admin || $vars['user']->siteadmin) { 
?>
			<li><a href="/pg/admin/"><?php echo elgg_echo("admin"); ?></a></li>
<?php
}

	// CUSTOM 5: user drop down links
	// use the folders here as a guide to custom 1 
	// e.g. |profile|dashboard|settings| (I've added bookmarks as a 'user' value
	// but not ones shown on in the other bit of the nav or that shou;ld go to default e.g. blogs / groups
	
	ShowDropDownLink("/pg/profile/" . $tbUserName, "My Profile");
	ShowDropDownLink("/pg/dashboard/", "My Dashboard");
	ShowDropDownLink("/pg/settings/", "My Settings");
	ShowDropDownLink("/pg/blog/". $tbUserName, "My Blogs");
	ShowDropDownLink("/pg/friends/". $tbUserName, "My Friends");
	ShowDropDownLink("/pg/groups/world/", "My Groups");
	ShowDropDownLink("/pg/photos/owned/" . $tbUserName, "My Photos");	
	ShowDropDownLink("/pg/thewire/" . $tbUserName, "My Wire");
	ShowDropDownLink("/pg/bookmarks/" . $tbUserName, "My Bookmarks");			
?>
	</ul></li></ul></div>
	
<script type="text/javascript">
  $(function() {
    $('ul.topbardropdownmenu').elgg_topbardropdownmenu();
  });
</script>
	
	
<?php
			// used bit of code above so next line commented out
	        // echo elgg_view("navigation/topbar_tools"); 
			}
//	END user drop down			
?>
</div>


<div id="elgg_topbar_container_right">

<?php

//	START right hand section login/logout etc
if ($tbLoggedIn) { 
?>
		<a href="/action/logout">logout</a>
<?php
		}
		else
		{
?>
		<a href="/">login</a>
		<a href="/account/register.php">register</a>		
<?php
		}
?>
</div>
<?php


// CUSTOM 6: search box
// For search box for those not logged in just comment out next line
if ($tbLoggedIn) 
{
?>
<div id="elgg_topbar_container_search">
<form id="searchform" action="<?php echo $vars['url']; ?>pg/search/" method="get">
	<input type="text" size="21" name="tag" value="<?php echo elgg_echo('search'); ?>" onclick="if (this.value=='<?php echo elgg_echo('search'); ?>') { this.value='' }" class="search_input" />
	<input type="submit" value="<?php echo elgg_echo('search:go'); ?>" class="search_submit_button" />
</form>
</div>
<?php
}
?>
</div><!-- /#elgg_topbar -->

<div class="clearfloat"></div>

