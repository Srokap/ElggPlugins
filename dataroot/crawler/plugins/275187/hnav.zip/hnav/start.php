<?php

	/* Elgg Theme Simple Example */
	
	
	/* Initialise the theme */
	function topbar_revised(){
	
	}
	
	// Initialise log browser
	register_elgg_event_handler('init','system','hnav');
	extend_view('css','hnav/css');
?>