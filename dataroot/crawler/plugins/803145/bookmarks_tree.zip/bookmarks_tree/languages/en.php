<?php 

	$english = array(
		'bookmarks_tree' => "Bookmark Tree",
	
		// object name
		'item:object:folder' => "Bookmark Folder",
	
		// menu items
		'bookmarks_tree:menu:mine' => "Your bookmark folders",
		'bookmarks_tree:menu:user' => "%s's bookmark folders",
		'bookmarks_tree:menu:group' => "Group bookmark folders",
		
		// group tool option
		'bookmarks_tree:group_tool_option:structure_management' => "Allow management of bookmark folders by members",
		
		// views
		// admin settings
		'bookmarks_tree:settings:replace_bookmarks' => "Replace My Bookmarks/Group Bookmarks with Folder view",	
	
		// input - folder select
		'bookmarks_tree:input:folder_select:main' => "Main folder",
	
		// list
		'bookmarks_tree:list:title' => "List bookmark folders",
		
		'bookmarks_tree:list:folder:main' => "Main bookmark folder",
		'bookmarks_tree:list:bookmarks:none' => "No bookmarks found in this folder",
		
		'bookmarks_tree:list:tree:info' => "Did you know?",
		'bookmarks_tree:list:tree:info:1' => "You can drag and drop bookmarks on to the folders to organize them.",
		'bookmarks_tree:list:tree:info:2' => "You can double click on any folder to expand all of its subfolders.",
		'bookmarks_tree:list:tree:info:3' => "You can reorder folders by dragging them to their new place in the tree.",
		'bookmarks_tree:list:tree:info:4' => "You can move complete folder structures.",
		'bookmarks_tree:list:tree:info:5' => "If you delete a folder, you can optionally choose to delete all bookmarks.",
		'bookmarks_tree:list:tree:info:6' => "When you delete a folder, all subfolders will also be deleted.",
		'bookmarks_tree:list:tree:info:7' => "This message is random.",
		'bookmarks_tree:list:tree:info:8' => "When you remove a folder, but not it's bookmarks, the bookmarks will appear at the top level folder.",
		'bookmarks_tree:list:tree:info:9' => "A newly added folder can be placed directly in the correct subfolder.",
		'bookmarks_tree:list:tree:info:10' => "When uploading or editing a bookmark you can choose in which folder it should appear.",
		'bookmarks_tree:list:tree:info:11' => "Dragging of bookmarks is only available in the list view, not in the gallery view.",
		'bookmarks_tree:list:tree:info:12' => "You can update the access level on all subfolders and even (optional) on all bookmarks when editing a folder.",
		
		// new/edit
		'bookmarks_tree:new:title' => "New bookmark folder",
		'bookmarks_tree:edit:title' => "Edit bookmark folder",
		'bookmarks_tree:forms:edit:title' => "Title",
		'bookmarks_tree:forms:edit:description' => "Description",
		'bookmarks_tree:forms:edit:parent' => "Select a parent folder",
		'bookmarks_tree:forms:edit:change_children_access' => "Update access on all subfolders",
		'bookmarks_tree:forms:edit:change_bookmarks_access' => "Update access on all bookmarks in this folder (and all subfolders if selected)",
		
		'bookmarks_tree:folder:delete:confirm_bookmarks' => "Do you also wish to delete all bookmarks in the removed (sub)folders",
	
		// actions
		// edit
		'bookmarks_tree:action:edit:error:input' => "Incorrect input to create/edit a bookmark folder",
		'bookmarks_tree:action:edit:error:owner' => "Could not find the owner of the bookmark folder",
		'bookmarks_tree:action:edit:error:folder' => "No folder to create/edit",
		'bookmarks_tree:action:edit:error:save' => "Unknown error occured while saving the bookmark folder",
		'bookmarks_tree:action:edit:success' => "Bookmark folder successfully created/edited",
		
		// delete
		'bookmarks_tree:actions:delete:error:input' => "Invalid input to delete a bookmark folder",
		'bookmarks_tree:actions:delete:error:entity' => "The given GUID could not be found (please tell system admins about this - it sounds pretty technical)",
		'bookmarks_tree:actions:delete:error:subtype' => "The given GUID is not a bookmark folder (please tell system admins about this - it sounds pretty technical)",
		'bookmarks_tree:actions:delete:error:delete' => "An unknown error occured while deleting the bookmark folder. We'd love to tell you what it was, but we don't know either",
		'bookmarks_tree:actions:delete:success' => "The bookmark folder was deleted successfully",
	);

	add_translation("en", $english);
?>