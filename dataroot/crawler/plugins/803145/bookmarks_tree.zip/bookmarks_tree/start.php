<?php 

	define("BOOKMARKS_TREE_SUBTYPE", "bmfolder");
	define("BOOKMARKS_TREE_RELATIONSHIP", "folder_of");

	require_once(dirname(__FILE__) . "/lib/functions.php");
	
	function bookmarks_tree_init(){
		
		// extend CSS
		elgg_extend_view("css", "bookmarks_tree/css", 499);
		
		// extend object view of bookmarks
		elgg_extend_view("object/bookmarks", "bookmarks_tree/extend/bookmarks", 499);
		
		// register page handler for nice URL's
		register_page_handler("bookmarks_tree", "bookmarks_tree_page_handler");
		
		// register group option to allow management of bookmark tree structure
		add_group_tool_option("bookmarks_tree_structure_management", elgg_echo("bookmarks_tree:group_tool_option:structure_management"));
		
		
	}

	function bookmarks_tree_pagesetup(){
		global $CONFIG;
		
		$context = get_context();
		$page_owner = page_owner_entity();
		
		if($context == "bookmarks"){
			elgg_extend_view("input/tags", "bookmarks_tree/extend/tags");
		}
		
		if($context == "bookmarks"){
			if($page_owner->getGUID() == get_loggedin_userid()) {
				add_submenu_item(elgg_echo("bookmarks_tree:menu:mine"), $CONFIG->wwwroot . "pg/bookmarks_tree/list/" . $page_owner->getGUID());
			} else {
				add_submenu_item(sprintf(elgg_echo("bookmarks_tree:menu:user"), $page_owner->name), $CONFIG->wwwroot . "pg/bookmarks_tree/list/" . $page_owner->getGUID());
			}
		}
		
		if(($context == "groups") && ($page_owner instanceof ElggGroup) && ($page_owner->bookmarks_enable != "no")){
			if($page_owner instanceof ElggGroup){
				add_submenu_item(elgg_echo("bookmarks_tree:menu:group"), $CONFIG->wwwroot . "pg/bookmarks_tree/list/" . $page_owner->getGUID());
			}
		}
		
	}
	
	function bookmarks_tree_page_handler($page){
		
		switch($page[0]){
			case "list":
				if(!empty($page[1])){
					set_input("page_owner", $page[1]);
					
					if(get_input("folder_guid", false) !== false){
						set_input("draw_page", false);
					}
					
					if(array_key_exists(2, $page)){
						set_input("folder_guid", $page[2]);
					}
				}
				include(dirname(__FILE__) . "/pages/list.php");
				break;
			case "add":
				if(!empty($page[1])){
					set_input("page_owner", $page[1]);
				}
				include(dirname(__FILE__) . "/pages/add.php");
				break;
			case "reorder":
				include(dirname(__FILE__) . "/procedures/reorder.php");
				break;
			case "edit":
				if(!empty($page[1])){
					set_input("folder_guid", $page[1]);
					
					include(dirname(__FILE__) . "/pages/edit.php");
					break;
				}
			case "bookmark_move":
				include(dirname(__FILE__) . "/procedures/bookmark_move.php");
				break;
			default:
				forward("pg/bookmarks_tree/list/" . get_loggedin_userid());
		}
	}
	
	function bookmarks_tree_bookmark_page_handler($page){
		
		switch($page[0]){
			case "owner":
				if(!empty($page[1])){
					$username = $page[1];
					
					if(stristr($username, "group:")){
						list($dummy, $guid) = explode(":", $username);
						set_input("page_owner", $guid);
					} elseif($user = get_user_by_username($username)) {
						set_input("page_owner", $user->getGUID());
					}
					
					include(dirname(__FILE__) . "/pages/list.php");
				}
				break;
			default:
				bookmarks_tree_fallback_page_handler($page, "bookmarks");
				break;
		}
	}
	
	function bookmarks_tree_object_handler($event, $type, $object){
		
		if(!empty($object) && ($object instanceof ElggObject)){
			if($object->getSubtype() == "bookmarks"){
				$bmfolder_guid = get_input("folder_guid", false);
				
				if(!empty($bmfolder_guid)){
					if($bmfolder = get_entity($bmfolder_guid)){
						if($bmfolder->getSubtype() != BOOKMARKS_TREE_SUBTYPE){
							unset($bmfolder_guid);
						}
					} else {
						unset($bmfolder_guid);
					}
				}
				
				if($bmfolder_guid !== false){
					// remove old relationships
					remove_entity_relationships($object->getGUID(), BOOKMARKS_TREE_RELATIONSHIP, true);
					
					if(!empty($bmfolder_guid)){
						add_entity_relationship($bmfolder_guid, BOOKMARKS_TREE_RELATIONSHIP, $object->getGUID());
					}
				}
			}
		}
	}
	
	function bookmarks_tree_object_handler_delete($event, $type, $object){
		
		if(!empty($object) && ($object instanceof ElggObject)){
			if($object->getSubtype() == BOOKMARKS_TREE_SUBTYPE){
				// find subfolders
				$options = array(
					"type" => "object",
					"subtype" => BOOKMARKS_TREE_SUBTYPE,
					"owner_guid" => $object->getOwner(),
					"limit" => false,
					"metadata_name" => "parent_guid",
					"metadata_value" => $object->getGUID()
				);
				
				if($subfolders = elgg_get_entities_from_metadata($options)){
					// delete subfolders
					foreach($subfolders as $subfolder){
						$subfolder->delete();
					}
				}
				
				// should we remove bookmarks?
				if(get_input("bookmarks") == "yes"){
					// find bookmark in this folder
					$options = array(
						"type" => "object",
						"subtype" => "bookmarks",
						"container_guid" => $object->getOwner(),
						"limit" => false,
						"relationship" => BOOKMARKS_TREE_RELATIONSHIP,
						"relationship_guid" => $object->getGUID()
					);
					
					if($bookmarks = elgg_get_entities_from_relationship($options)){
						// delete bookmarks in folder
						foreach($bookmarks as $bookmark){
							$bookmark->delete();
						}
					}
				}
			}
		}
	}
	
	function bookmarks_tree_can_edit_metadata_hook($hook, $type, $returnvalue, $params){
		$result = $returnvalue;
		
		if(!empty($params) && is_array($params) && $result !== true){
			if(array_key_exists("user", $params) && array_key_exists("entity", $params)){
				$entity = $params["entity"];
				$user = $params["user"];
				
				if($entity->getSubtype() == BOOKMARKS_TREE_SUBTYPE){
					$container_entity = $entity->getContainerEntity();
					
					if(($container_entity instanceof ElggGroup) && $container_entity->isMember($user) && ($container_entity->bookmarks_tree_structure_management_enable != "no")){
						$result = true;
					}
				}
			}
		}
		
		return $result;
	}

	// register default elgg events
	register_elgg_event_handler("init", "system", "bookmarks_tree_init");
	register_elgg_event_handler("pagesetup", "system", "bookmarks_tree_pagesetup");
	
	// register events
	register_elgg_event_handler("create", "object", "bookmarks_tree_object_handler");
	register_elgg_event_handler("update", "object", "bookmarks_tree_object_handler");
	register_elgg_event_handler("delete", "object", "bookmarks_tree_object_handler_delete");
	
	// register plugin hooks
	register_plugin_hook("permissions_check:metadata", "object", "bookmarks_tree_can_edit_metadata_hook");
	
	// register actions
	register_action("bookmarks_tree/edit", false, dirname(__FILE__) . "/actions/edit.php");
	register_action("bookmarks_tree/delete", false, dirname(__FILE__) . "/actions/delete.php");
	
?>