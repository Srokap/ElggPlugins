<?php ?>

#bookmarks_tree_edit_form_access_extra label {
	font-size: 100%;
    font-weight: normal;
}

#bookmarks_tree_list_folder p{
	margin: 0px;
}

#bookmarks_tree_list_folder_actions {
	float: right;
} 

#bookmarks_tree_list_tree_container {	
	overflow: auto;
}

#bookmarks_tree_list_tree_info {
	color: grey;
}

#bookmarks_tree_list_tree_info>div {
	background: url(<?php echo $vars["url"]; ?>_graphics/icon_customise_info.gif) top left no-repeat;
	padding-left: 16px; 
	color: #333333;
	font-weight: bold;
}

/* loading overlay */

#bookmarks_tree_list_bookmarkss {
	position: relative;
	
}

#bookmarks_tree_list_bookmarkss_overlay {
	display: none;
	background: white;
	height: 100%;
	position: absolute;
	opacity: 0.6;
	filter: alpha(opacity=60);
	z-index: 100;
	background: url("<?php echo $vars["url"]; ?>_graphics/ajax_loader.gif") no-repeat scroll center center white;
	padding: auto;
	-webkit-border-radius: 8px;
	-moz-border-radius: 8px;
}

/* breadcrumb */

#bookmarks_tree_breadcrumbs_bookmarks_title {
	float: right;
}

#bookmarks_tree_breadcrumbs ul{
	border: 1px solid #DEDEDE;
    height: 2.3em;
}

#bookmarks_tree_breadcrumbs ul,
#bookmarks_tree_breadcrumbs li {
	list-style-type:none;
	padding:0;
	margin:0
}

#bookmarks_tree_breadcrumbs li {
	float:left;
	line-height:2.3em;
	padding-left:.75em;
	color:#777;
}
#bookmarks_tree_breadcrumbs li a {
	display:block;
	padding:0 15px 0 0;
	background:url(<?php echo $vars["url"]; ?>mod/bookmarks_tree/_graphics/crumbs.gif) no-repeat right center;
}

#bookmarks_tree_breadcrumbs li a:link, 
#bookmarks_tree_breadcrumbs li a:visited {
	text-decoration:none;
   	color:#777;
}

#bookmarks_tree_breadcrumbs li a:hover,
#bookmarks_tree_breadcrumbs li a:focus {
	color:#333;
}


/* extending bookmarks tree classic theme */

#bookmarks_tree_list_tree.tree li {
	line-height: 20px;
}
 
#bookmarks_tree_list_tree.tree li span {
	padding: 1px 0px;
}

#bookmarks_tree_list_tree.tree-classic li a {
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	border: 1px solid transparent;	
}

#bookmarks_tree_list_tree.tree-classic li a:hover {
	border: 1px solid #d60004;
}

#bookmarks_tree_list_tree.tree-classic li a.clicked {
	background: #DEDEDE;
    border: 1px solid #d60004;
    color: #d60004;
}

#bookmarks_tree_list_tree.tree-classic li a.clicked:hover {
	background: #d60004;
    border: 1px solid #d60004;
    color: white;
}

#bookmarks_tree_list_tree.tree-classic li a.ui-state-hover{
	background: #0054A7;
	border: 1px solid #0054A7;	
	color: white;
}