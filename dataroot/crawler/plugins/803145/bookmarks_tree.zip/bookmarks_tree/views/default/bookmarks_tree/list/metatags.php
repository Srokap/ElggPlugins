<?php ?>
<script src="<?php echo $vars["url"]; ?>mod/bookmarks_tree/vendors/jstree/jquery.tree.min.js"></script>
<script type="text/javascript">
	function bookmarks_tree_add_folder(){
		var parent_guid = $("#bookmarks_tree_list_tree a.clicked").attr("id");
		var forward_url = "<?php echo $vars["url"]; ?>pg/bookmarks_tree/add/<?php echo page_owner();?>"

		if(parent_guid){
			forward_url = forward_url + "?parent_guid=" + parent_guid;
		}
		
		document.location.href = forward_url;
	}

	function bookmarks_tree_reorder(folder_guid, parent_guid, order){
		var reorder_url = "<?php echo $vars["url"];?>pg/bookmarks_tree/reorder";
		$.post(reorder_url, {"folder_guid": folder_guid, "parent_guid": parent_guid, "order": order});		
	}

	function bookmarks_tree_load_folder(folder_guid){
		var folder_url = "<?php echo $vars["url"];?>pg/bookmarks_tree/list/<?php echo page_owner();?>?folder_guid=" + folder_guid + "&search_viewtype=<?php echo get_input("search_viewtype", "list"); ?>";
		$("#bookmarks_tree_list_bookmarks_container").load(folder_url);
	}	

	function bookmarks_tree_remove_folder_bookmarks(link){
		if(confirm("<?php echo elgg_echo("bookmarks_tree:folder:delete:confirm_bookmarks");?>")){
			var cur_href = $(link).attr("href"); 
			$(link).attr("href", cur_href + "&bookmarks=yes");
		}
		return true;
	}
</script>