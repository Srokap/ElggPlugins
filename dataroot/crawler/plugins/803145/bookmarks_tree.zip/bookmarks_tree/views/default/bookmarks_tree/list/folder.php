<?php 

	$folder = $vars["folder"];
	$delete_url = $vars["url"] . "action/bookmarks_tree/delete?bmfolder_guid=" . $folder->getGUID();
	$edit_url = $vars["url"] . "pg/bookmarks_tree/edit/" . $folder->getGUID();
?>
<div class="contentWrapper" id="bookmarks_tree_list_folder">
	<?php if($folder->canEdit()){?>
	<div id="bookmarks_tree_list_folder_actions">
		<?php echo elgg_view("output/url", array("href" => $edit_url, "text" => elgg_echo("edit")));?> |
		<?php
			$js = "onclick=\"if(confirm('". elgg_echo('question:areyousure') . "')){ bookmarks_tree_remove_folder_bookmarks(this); return true;} else { return false; }\""; 
			echo elgg_view("output/url", array("href" => $delete_url, "text" => elgg_echo("delete"), "js" => $js, "is_action" => true));
		?>
	</div>
	<?php } else {
	
		//echo "<h1>DEBUG: cannot edit</h1>";
	}
	?>
	<h3>
		<?php echo $folder->title;?>
	</h3>
	<div><?php echo $folder->description;?>
	</div>
</div>