<?php 

	$bookmark= $vars["entity"];

	if(!$vars["full"] && get_context() == "search"){
		echo elgg_view("input/hidden", array("internalname" => "bookmark_guid", "value" => $bookmark->getGUID()));
	} elseif($vars["full"]){
		echo elgg_view("bookmarks_tree/breadcrumb", array("entity" => $bookmark));
	}

?>