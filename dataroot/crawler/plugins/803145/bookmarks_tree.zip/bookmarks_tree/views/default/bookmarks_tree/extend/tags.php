<?php 

	if(get_context() == "bookmarks"){
		$page_owner = page_owner();
		// this is because of absurd ugliness in Elgg bookmark
		// that means bookmark is edited in user context
		// then sent back to group context afterwards. This
		//doesn't happen when adding bookmarks. Only needed for editing
		if($bkmk=get_input('bookmark')){
			$entity=get_entity($bkmk);
			$page_owner=$entity->container_guid;
		}	
		
		if(!empty($vars["entity"])){
			$bookmark = $vars["entity"];
			
			$options = array(
				"type" => "object",
				"subtype" => BOOKMARKS_TREE_SUBTYPE,
				"owner_guid" => $page_owner,
				"relationship" => BOOKMARKS_TREE_RELATIONSHIP,
				"relationship_guid" => $bookmark->getGUID(),
				"inverse_relationship" => true,
				"limit" => 1
			);
			
			if($folders = elgg_get_entities_from_relationship($options)){
				$parent_guid = $folders[0]->getGUID();
			}
		}
		
		if(empty($parent_guid)){
			$parent_guid = 0;
		}
		
		echo "<div><label>" . elgg_echo("bookmarks_tree:forms:edit:parent") . "</label></div>";
		echo elgg_view("input/bmfolder_select", array("owner_guid" => $page_owner, "value" => $parent_guid, "internalname" => "folder_guid"));
	}
?>