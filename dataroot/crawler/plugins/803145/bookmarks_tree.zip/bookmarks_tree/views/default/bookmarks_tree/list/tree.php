<?php 

	$folders = $vars["folders"]; 
	$folder = $vars["bmfolder"];
	
	$selected_id = "bookmarks_tree_list_tree_main";
	if($folder instanceof ElggObject){
		$selected_id = $folder->guid;
	}
	
	$page_owner = page_owner_entity();
?>
<script type="text/javascript">
	$(function () {
		$("#bookmarks_tree_list_tree").tree({ 
			"opened": ["<?php echo $selected_id; ?>"],
			"selected": ["<?php echo $selected_id; ?>"],
			"ui": {
				"theme_name": "classic"
			},
			"rules": {
				"multiple": false,
				"drag_copy": false,
				// only nodes of type root can be top level nodes
				"valid_children" : [ "root" ] 
			},
			"callback": {
				"ondblclk": function(NODE, TREE_OBJ) {
				 	 TREE_OBJ.open_branch(NODE);
					 TREE_OBJ.open_all(NODE);
				},	
				"onmove": function (NODE, REF_NODE, TYPE, TREE_OBJ, RB){
					var folder_guid = TREE_OBJ.get_node(NODE).find("a").attr("id");
					var parent_guid = TREE_OBJ.parent(NODE).find("a:first").attr("id");
					var order = TREE_OBJ.parent(NODE).children("ul").children("li").children("a").makeDelimitedList("id");
					
					bookmarks_tree_reorder(folder_guid, parent_guid, order);
				},
				"onselect": function(NODE, TREE_OBJ){
					var folder_guid = TREE_OBJ.get_node(NODE).find("a").attr("id");
					if(folder_guid){
						bookmarks_tree_load_folder(folder_guid);
					}
				}
			},
			types : {
				// all node types inherit the "default" node type
				"default" : {
					deletable : false,
					renameable : false
					<?php if(!($page_owner->canEdit() || ($page_owner instanceof ElggGroup && $page_owner->isMember() && $page_owner->bookmarks_tree_structure_management_enable != "no"))){ ?>
					,draggable : false
					<?php } ?>
				},
				"root" : {
					draggable : false
				}
			}
		});
		<?php if($page_owner->canEdit() || ($page_owner instanceof ElggGroup && $page_owner->isMember())){ ?>
		$("#bookmarks_tree_list_tree a").droppable({
			"accept": ".search_listing",
			"hoverClass": "ui-state-hover",
			"tolerance": "pointer",
			"drop": function(event, ui) {
	
				var bookmark_move_url = "<?php echo $vars["url"];?>pg/bookmarks_tree/bookmark_move";
				var bookmark_guid = $(ui.draggable).prev("input").val();
				var folder_guid = $(this).attr("id");
				var selected_folder_guid = $("#bookmarks_tree_list_tree a.clicked").attr("id");
				var overlay_width = $(ui.draggable).outerWidth();
				var margin_left = $(ui.draggable).css("margin-left");
				
				$(ui.draggable).hide();
				
				$("#bookmarks_tree_list_bookmarks_overlay").css("width", overlay_width).css("left", margin_left).show();
				$.post(bookmark_move_url, {"bookmark_guid": bookmark_guid, "folder_guid": folder_guid}, function(data){
					bookmarks_tree_load_folder(selected_folder_guid);
				});
			},
			"greedy": true
		});
		<?php } ?>
	});

</script>

<div class="contentWrapper" id="bookmarks_tree_list_tree_container">
	<div id="bookmarks_tree_list_tree">
		<ul>
			<li id="bookmarks_tree_list_tree_main" rel="root">
				<a id="0" href="#"><?php echo elgg_echo("bookmarks_tree:list:folder:main"); ?></a>
			
			<?php 
				echo bookmarks_tree_display_folders($folders);
			?>
		
			</li>
		</ul>
	</div>
	<div class="clearfloat"></div>	
	
	<?php 
		
		if($page_owner->canEdit() || ($page_owner instanceof ElggGroup && $page_owner->isMember() && $page_owner->bookmarks_tree_structure_management_enable != "no")){ ?>
	<div>
		<?php
			$js = "onclick='bookmarks_tree_add_folder()'"; 
			echo elgg_view("input/button", array("value" => elgg_echo("bookmarks_tree:new:title"), "js" => $js)); 
		?>
	</div>
	<?php } ?>
</div>

<?php if(isloggedin()){ ?>
<div class="contentWrapper">
	<div id="bookmarks_tree_list_tree_info">
		<div><?php echo elgg_echo("bookmarks_tree:list:tree:info"); ?></div>
		<?php 
			echo elgg_echo("bookmarks_tree:list:tree:info:" . rand(1,12));
		?>
	</div>
</div>
<?php } ?>
