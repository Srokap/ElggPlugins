<?php 

	$bookmark = $vars["entity"];
	
	$folder_options = array(
			"type" => "object",
			"subtype" => BOOKMARKS_TREE_SUBTYPE,
			"owner_guid" => page_owner(),
			"relationship" => BOOKMARKS_TREE_RELATIONSHIP,
			"relationship_guid" => $bookmark->getGUID(),
			"inverse_relationship" => true,
			"limit" => 1
		);
	
	$folders = elgg_get_entities_from_relationship($folder_options);
	$folder = $folders[0];
	
	if($folder){
		echo "<div id='bookmarks_tree_breadcrumbs' class='contentWrapper bookmarkrepo_bookmark'>";
		
		echo "<ul>";
		echo "<li><a href='" . $vars["url"] . "pg/bookmarks_tree/list/" . page_owner() . "'>" . elgg_echo("bookmarks_tree:list:folder:main") . "</a></li>";

		if($folder->parent_guid && get_entity($folder->parent_guid)){
			// if parent folder for folder available
			echo "<li><a href='#'>...</a></li>";
		}
		
		echo "<li><a href='" . $vars["url"] . "pg/bookmarks_tree/list/" . page_owner() . "/" . $folder->guid . "'>" . $folder->title . "</a></li>";
		
		$bookmark_title = $bookmark->title;
		if(!$bookmark_title){
			$bookmark_title = elgg_echo("untitled");
		}
		echo "<li>" . $bookmark_title . "</li>";
		echo "</ul>";
		echo "<div class='clearfloat'></div>";
		echo "</div>";
	}

?>