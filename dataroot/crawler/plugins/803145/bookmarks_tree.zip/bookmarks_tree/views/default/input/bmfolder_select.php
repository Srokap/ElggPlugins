<?php 
//this is to display a list of folders - used to select folder for a bookmark
	$owner_guid = $vars["owner_guid"];

	$name = $vars["internalname"];
	$id = $vars["internalid"];
	$js = $vars["js"];
	$class = $vars["class"];
	
	$value = $vars["value"];
	
	if(empty($owner_guid)){
		$owner_guid = page_owner();
	}

	$folders = bookmarks_tree_get_folders($owner_guid);

	$options = "<option value='0'>" . elgg_echo("bookmarks_tree:input:folder_select:main") . "</option>\n";
	
	if(!empty($folders)){
		$options .= bookmarks_tree_build_select_options($folders, $value);
	}

?>


<select name="<?php echo $name; ?>" id="<?php echo $id; ?>" class="<?php echo $class; ?>" <?php echo $js; ?>>
	<?php echo $options; ?>
</select>