<?php 

	global $CONFIG;

	$page_owner_guid = get_input("page_owner", get_loggedin_userid());
	$page_owner = get_entity($page_owner_guid);
	$folder_guid = get_input("folder_guid", false);
	$draw_page = get_input("draw_page", true);
	
	if(!empty($page_owner) && (($page_owner instanceof ElggUser) || ($page_owner instanceof ElggGroup))){
		// set page owner & context
		set_page_owner($page_owner_guid);
		set_context("bookmarks");
		
		group_gatekeeper();
		
		$wheres = array();
		$wheres[] = "NOT EXISTS (
				SELECT 1 FROM {$CONFIG->dbprefix}entity_relationships r 
				WHERE r.guid_two = e.guid AND
				r.relationship = '" . BOOKMARKS_TREE_RELATIONSHIP . "')";
		
		$bookmarks_options = array(
				"type" => "object",
				"subtype" => "bookmarks",
				"limit" => false,
				"container_guid" => $page_owner_guid
			);
		
		if($folder_guid !== false){
			if($folder_guid == 0){
				$bookmarks_options["wheres"] = $wheres;
				$bookmarks = elgg_get_entities($bookmarks_options);	
			} else {
				$folder = get_entity($folder_guid);
				
				$bookmarks_options["relationship"] = BOOKMARKS_TREE_RELATIONSHIP;
				$bookmarks_options["relationship_guid"] = $folder_guid;
				$bookmarks_options["inverse_relationship"] = false;
					
				$bookmarks = elgg_get_entities_from_relationship($bookmarks_options);	
			}	
		}
		
		if(!$draw_page){
			echo elgg_view("bookmarks_tree/list/bookmarks", array("folder" => $folder, "bookmarks" => $bookmarks));
		} else {

			// add js functionality
			elgg_extend_view("metatags", "bookmarks_tree/list/metatags");
			
			// get data for tree
			$folders = bookmarks_tree_get_folders($page_owner_guid);
			
			// default lists all unsorted bookmarks
			if($folder_guid === false){
				$bookmarks_options["wheres"] = $wheres;
				$bookmarks = elgg_get_entities($bookmarks_options);
			}
			
			// build page elements
			$tree = elgg_view("bookmarks_tree/list/tree", array("folder" => $folder, "folders" => $folders)); 
			$body = "<div id='bookmarks_tree_list_bookmarks_container'>" . elgg_view("ajax/loader") . "</div>";
			
				if(get_loggedin_userid() == $page_owner_guid){
					$title_text = elgg_echo("bookmarks_tree:menu:mine");
				} else {
					$title_text = sprintf(elgg_echo("bookmarks_tree:menu:user"), $page_owner->name);
				}
				
				// remove menu items
				unset($CONFIG->submenu);
				
				if ((page_owner() == $_SESSION['guid'] || !page_owner()) && isloggedin()) {
					add_submenu_item(sprintf(elgg_echo("bookmarks:read"),$page_owner->name), $CONFIG->wwwroot . "pg/bookmarks/owner/" . $page_owner->username);
				} else if (page_owner()) {
					add_submenu_item(sprintf(elgg_echo("bookmarks:read"),$page_owner->name), $CONFIG->wwwroot . "pg/bookmarks/owner/" . $page_owner->username);
				}
				
				if (can_write_to_container($_SESSION['guid'], page_owner()) && isloggedin()){
					
					add_submenu_item(elgg_echo('bookmarks:add'), $CONFIG->wwwroot . "pg/bookmarks/add/". $page_owner->username);
			
				}

			
			// build title
			$title = elgg_view_title($title_text);
			
			// draw page
			page_draw($title_text, elgg_view_layout("two_column_left_sidebar", "", $title . $body, $tree));
		}
	} else {
		forward();
	}

?>
