<?php 

	gatekeeper();
	
	$bmfolder_guid = get_input("bmfolder_guid");
	
	if(!empty($bmfolder_guid)){
		if($bmfolder = get_entity($bmfolder_guid)){
			if(($bmfolder->getSubtype() == BOOKMARKS_TREE_SUBTYPE) && $bmfolder->canEdit()){
				if($bmfolder->delete()){
					system_message(elgg_echo("bookmarks_tree:actions:delete:success"));
				} else {
					register_error(elgg_echo("bookmarks_tree:actions:delete:error:delete"));
				}
			} else {
				register_error(elgg_echo("bookmarks_tree:actions:delete:error:subtype"));
			}
		} else {
			register_error(elgg_echo("bookmarks_tree:actions:delete:error:entity"));
		}
	} else {
		register_error(elgg_echo("bookmarks_tree:actions:delete:error:input"));
	}

	forward(REFERER);
?>