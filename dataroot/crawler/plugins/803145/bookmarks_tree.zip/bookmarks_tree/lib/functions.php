<?php 

	function bookmarks_tree_get_folders($container_guid = 0){
		$result = false;
		
		if(empty($container_guid)){
			$container_guid = page_owner();
		}
		
		if(!empty($container_guid)){
			$options = array(
				"type" => "object",
				"subtype" => BOOKMARKS_TREE_SUBTYPE,
				"container_guid" => $container_guid,
				"limit" => false
			);
			
			if($folders = elgg_get_entities($options)){
				$parents = array();

				foreach($folders as $folder){
					$parent_guid = $folder->parent_guid; 
					
					if(!empty($parent_guid)){
						if($temp = get_entity($parent_guid)){
							if($temp->getSubtype() != BOOKMARKS_TREE_SUBTYPE){
								$parent_guid = 0;
							}
						} else {
							$parent_guid = 0;
						}
					} else {
						$parent_guid = 0;
					}
					
					if(!array_key_exists($parent_guid, $parents)){
						$parents[$parent_guid] = array();
					}
					
					$parents[$parent_guid][] = $folder;
				}
				
				$result = bookmarks_tree_sort_folders($parents, 0);
				
			}
		}
		return $result;
	}
	
	function bookmarks_tree_build_select_options($folder, $selected = 0, $niveau = 0){
		$result = "";
		
		if(is_array($folder) && !array_key_exists("children", $folder)){
			foreach($folder as $folder_item){
				$result .= bookmarks_tree_build_select_options($folder_item, $selected, $niveau);
			}
		} elseif(!empty($folder["children"])){
			$folder_item = $folder["folder"];
			
			if($selected == $folder_item->getGUID()){
				$result .= "<option value='" . $folder_item->getGUID() . "' selected='selected'>" . str_repeat("-", $niveau) . " " .  $folder_item->title . "</option>";
			} else {
				$result .= "<option value='" . $folder_item->getGUID() . "'>" . str_repeat("-", $niveau) . " " .  $folder_item->title . "</option>";
			}
			
			$result .= bookmarks_tree_build_select_options($folder["children"], $selected, $niveau + 1);
		} else {
			$folder_item = $folder["folder"];
			
			if($selected == $folder_item->getGUID()){
				$result .= "<option value='" . $folder_item->getGUID() . "' selected='selected'>" . str_repeat("-", $niveau) . " " . $folder_item->title . "</option>";
			} else {
				$result .= "<option value='" . $folder_item->getGUID() . "'>" . str_repeat("-", $niveau) . " " . $folder_item->title . "</option>";
			}
		}
		
		return $result;
	}
	
	function bookmarks_tree_sort_folders($folders, $parent_guid = 0){
		$result = false;
		
		if(array_key_exists($parent_guid, $folders)){
			$result = array();
			
			foreach($folders[$parent_guid] as $subfolder){
				
				$children = bookmarks_tree_sort_folders($folders, $subfolder->getGUID());
				
				$order = $subfolder->order;
				if(empty($order)){
					$order = 0;
				}
				
				while(array_key_exists($order, $result)){
					$order++;
				}
				
				$result[$order] = array(
					"folder" => $subfolder,
					"children" => $children
				);
			}
			
			ksort($result);
		}
		
		return $result;
	}
	
	function bookmarks_tree_display_folders($folder){
		$result = "";
		
		if(is_array($folder) && !array_key_exists("children", $folder)){
			$result .= "<ul>";
			foreach($folder as $folder_item){
				$result .= bookmarks_tree_display_folders($folder_item);
			}
			$result .= "</ul>";
		} elseif(!empty($folder["children"])){
			
			$result .= "<li><a id='" . $folder["folder"]->getGUID() . "' title='" . $folder["folder"]->title . "' href='#'>" . $folder["folder"]->title . "</a>";
			$result .= bookmarks_tree_display_folders($folder["children"]);
			$result .= "</li>";
		} elseif(array_key_exists("folder", $folder)) {
			$folder = $folder["folder"];
			$result .= "<li><a id='" . $folder->getGUID() . "' title='" . $folder->title . "' href='#'>" . $folder->title . "</a></li>";
		}
		
		return $result;
	}
	
	function bookmarks_tree_change_children_access($folder, $change_bookmarkss = false){
		
		if(!empty($folder) && ($folder instanceof ElggObject)){
			if($folder->getSubtype() == BOOKMARKS_TREE_SUBTYPE){
				// get children folders
				$options = array(
					"type" => "object",
					"subtype" => BOOKMARKS_TREE_SUBTYPE,
					"container_guid" => $folder->getContainer(),
					"limit" => false,
					"metadata_name" => "parent_guid",
					"metadata_value" => $folder->getGUID()
				);
				
				if($children = elgg_get_entities_from_metadata($options)){
					foreach($children as $child){
						$child->access_id = $folder->access_id;
						$child->save();
						
						bookmarks_tree_change_children_access($child, $change_bookmarks);
					}
				}
				
				if($change_bookmarkss){
					// change access on bookmarkss in this folder
					bookmarks_tree_change_bookmarks_access($folder);
				}
			}
		}
	}
	
	function bookmarks_tree_change_bookmarks_access($folder){
		
		if(!empty($folder) && ($folder instanceof ElggObject)){
			if($folder->getSubtype() == BOOKMARKS_TREE_SUBTYPE){
				// change access on bookmarks in this folder
				$options = array(
					"type" => "object",
					"subtype" => "bookmarks",
					"container_guid" => $folder->getContainer(),
					"limit" => false,
					"relationship" => BOOKMARKS_TREE_RELATIONSHIP,
					"relationship_guid" => $folder->getGUID()
				);
				
				if($bookmarks = elgg_get_entities_from_relationship($options)){
					foreach($bookmarks as $bookmark){
						$bookmark->access_id = $folder->access_id;
						$bookmark->save();
					}
				}
			}
		}	
	}
	
	function bookmarks_tree_replace_page_handler($handler, $function){
		global $CONFIG;
		
		if(!empty($CONFIG->pagehandler)){
			if(array_key_exists($handler, $CONFIG->pagehandler)){
				if(!isset($CONFIG->backup_pagehandler)){
					$CONFIG->backup_pagehandler = array();
				}
				
				$CONFIG->backup_pagehandler[$handler] = $CONFIG->pagehandler[$handler];
			}
		}
		
		return register_page_handler($handler, $function);
	}
	
	function bookmarks_tree_fallback_page_handler($page, $handler){
		global $CONFIG;
		
		$result = false;
		
		if(!empty($CONFIG->backup_pagehandler)){
			if(array_key_exists($handler, $CONFIG->backup_pagehandler)){
				$function = $CONFIG->backup_pagehandler[$handler];
				
				if(is_callable($function)){
					$result = $function($page, $handler);
				}
			}
		}
		
		return $result;
	}

?>