<?php 

	/**
	 * jQuery call to move a bookmark in a folder
	 */

	if(isloggedin()){
		$bookmark_guid = get_input("bookmark_guid", 0);
		$folder_guid = get_input("folder_guid", 0);
		
		if(!empty($bookmark_guid)){
			if($bookmark = get_entity($bookmark_guid)){
				$container_entity = $bookmark->getContainerEntity();
				
				if(($bookmark->getSubtype() == "bookmarks") && ($bookmark->canEdit() || ($container_entity instanceof ElggGroup && $container_entity->isMember()))){
					// check if a given guid is a folder
					if(!empty($folder_guid)){
						if($folder = get_entity($folder_guid)){
							if($folder->getSubtype() != BOOKMARKS_TREE_SUBTYPE){
								unset($folder_guid);
							}
						} else {
							unset($folder_guid);
						}
					}
					
					// remove old relationships
					remove_entity_relationships($bookmark->getGUID(), BOOKMARKS_TREE_RELATIONSHIP, true);
					
					if(!empty($folder_guid)){
						add_entity_relationship($folder_guid, BOOKMARKS_TREE_RELATIONSHIP, $bookmark_guid);
					}
				}
			}
		}
	}

?>