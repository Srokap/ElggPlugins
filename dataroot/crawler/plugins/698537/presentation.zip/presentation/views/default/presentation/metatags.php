<script type="text/javascript" src="<?php echo $vars['url'];?>mod/presentation/javascript/presentation.js"></script>
<script type="text/javscript">
var wwwroot = <?php echo $vars['url'];?>; 
</script>
