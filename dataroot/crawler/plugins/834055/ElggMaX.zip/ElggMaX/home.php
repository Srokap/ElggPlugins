<?php
if (isloggedin()) forward('activity');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="icon" 
      href="mod/ElggMaX/favicon.ico">
<title>Welcome</title>
  <style type="text/css">
	body
	{
	background-image:url('http://www.psdgraphics.com/file/dark-blue-background.jpg');
	} 
  </style>
<style>

body{
font-family:Verdana, Geneva, sans-serif;
font-size:14px;}

.slidingDiv {
	height:250px;
	width:200px;
	background-color: #000000;
	padding:20px;
	margin-top:10px;
}

.show_hide {
	display:none;
}


</style>
</head>
<body>

<font color="red">
<SPAN  color="white" style="BACKGROUND-COLOR: black">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.js" type="text/javascript"></script>
<script type="text/javascript">

$(document).ready(function(){


    $(".slidingDiv").hide();
	$(".show_hide").show();
	
	$('.show_hide').click(function(){
	$(".slidingDiv").slideToggle();
	});

});

</script>

 <a href="#" class="show_hide">Member's Area</a>
    <div class="slidingDiv"><font color="red">
<?php
/**
 * Elgg login box
 *
 * @package Elgg
 * @subpackage Core
 *
 * @uses $vars['module'] The module name. Default: aside
 */

$module = elgg_extract('module', $vars, 'aside');

$login_url = elgg_get_site_url();
if (elgg_get_config('https_login')) {
	$login_url = str_replace("http:", "https:", $login_url);
}

$title = elgg_echo('login');
$body = elgg_view_form('login', array('action' => "{$login_url}action/login"));

echo elgg_view_module($module, $title, $body);
?></font>
    </div>
</div>
<a href="#about">About Us</a>
<a href="#terms">Terms</a>

<br>
<br>
<pre><center><marquee behavior="alternate"><img src="mod/ElggMaX/elmax.png" width="800" height="200"></center></marquee>
<center><h1>Welcome!</h1></center>
<center><p>This is a little welcome message... It could be a slideshow showing 
pictures or whatever. Anyways this not the place to put about us yet...
That will be saved for later... This is default text... If you are the webmaster of this site, edit 
this with your file manager on the directory yoursite/mod/ElggMaX/home.php.</center>
<a name="about">
<center><h1>About</h1>A good place for an about us section... The about link will automaticly go to here when the page
is filled up.</center>
</a>
<a name="terms"><center><h1>Terms</h1>This is a good place for a terms section... The terms link will automaticly when the page is filled up.</center></a>
</span>
</font>
<div id="wrap">

	<div id="main">

	</div>

</div>

<div id="footer">

</div>
</body>
</html>