<?php
if (isloggedin()) forward('pg/dashboard/');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<title>Your own page title</title>

<link rel="stylesheet" type="text/css" href="mod/swtheme/css2/style2.css" />
<link rel="stylesheet" href="mod/swtheme/css2/prettyPhoto.css" type="text/css" media="screen" charset="utf-8" />

</head>



<body>
	
<!-- BEGIN YOUR CONTENT -->


<div>
<?php include("mod/swtheme/form.php"); ?>
</div>
<div id="content">

<h1>My Portfolio<br />

</h1>

<div id="slider">
	
<ul>
<li>
<div class="inner">		
<h2>Registrate</h2>
<div class="left">
<p>At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
</div>
<div class="right">
<p>At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
</div>
</div>

</li>
				
<li>

<div class="inner">	
<h2>About</h2>
<div class="left">
<p>Lorem ipsum dolor sit amet, consectetuer sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, <a class="tip"  href="sed diam voluptua">sed diam voluptua</a>. </p>
</div>
<div class="right">
<p>At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
</div>
</div>
</li>




<li>
<div class="inner">		
<h2>Services</h2>
<div class="left">
<p>Lorem ipsum dolor sit amet, consectetuer sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, <a class="tip"  href="sed diam voluptua">sed diam voluptua</a>. </p>
</div>
<div class="right">
<p>At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
</div>
</div>

</li>

<li>
<div class="inner">		
<h2>References</h2>

<p>Lorem ipsum dolor sit amet, consectetuer sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</p>

<div id="gallery">
<div class="references"><a rel="prettyPhoto[pp_gal]" title="Description" href="mod/swtheme/images/01.jpg"><img src="mod/swtheme/images/01-thumb.jpg" alt="" /><span>Description 1</span></a></div>
<div class="references"><a rel="prettyPhoto[pp_gal]" title="Description"  href="mod/swtheme/images/01.jpg"><img src="mod/swtheme/images/02-thumb.jpg" alt="" /><span>Description 2</span></a></div>
<div class="references"><a rel="prettyPhoto[pp_gal]" title="Description" href="mod/swtheme/images/01.jpg"><img src="mod/swtheme/images/01-thumb.jpg" alt="" /><span>Description 3</span></a></div>
<div class="references"><a rel="prettyPhoto[pp_gal]" title="Description"  href="mod/swtheme/images/01.jpg"><img src="mod/swtheme/images/02-thumb.jpg" alt="" /><span>Description 4</span></a></div>
<div class="references"><a rel="prettyPhoto[pp_gal]" title="Description" href="mod/swtheme/images/01.jpg"><img src="mod/swtheme/images/01-thumb.jpg" alt="" /><span>Description 5</span></a></div>
<div class="references"><a rel="prettyPhoto[pp_gal]" title="Description"  href="mod/swtheme/images/01.jpg"><img src="mod/swtheme/images/02-thumb.jpg" alt="" /><span>Description 6</span></a></div>
<div class="references"><a rel="prettyPhoto[pp_gal]" title="Description" href="mod/swtheme/images/01.jpg"><img src="mod/swtheme/images/01-thumb.jpg" alt="" /><span>Description 7</span></a></div>
<div class="references"><a rel="prettyPhoto[pp_gal]" title="Description"  href="mod/swtheme/images/01.jpg"><img src="mod/swtheme/images/02-thumb.jpg" alt="" /><span>Description 8</span></a></div>
<div class="references"><a rel="prettyPhoto[pp_gal]" title="Description" href="mod/swtheme/images/01.jpg"><img src="mod/swtheme/images/01-thumb.jpg" alt="" /><span>Description 9</span></a></div>
<div class="references"><a rel="prettyPhoto[pp_gal]" title="Description"  href="mod/swtheme/images/01.jpg"><img src="mod/swtheme/images/02-thumb.jpg" alt="" /><span>Description 10</span></a></div>
<div class="references"><a rel="prettyPhoto[pp_gal]" title="Description" href="mod/swtheme/images/01.jpg"><img src="mod/swtheme/images/01-thumb.jpg" alt="" /><span>Description 11</span></a></div>
<div class="references"><a rel="prettyPhoto[pp_gal]" title="Description"  href="mod/swtheme/images/01.jpg"><img src="mod/swtheme/images/02-thumb.jpg" alt="" /><span>Description 12</span></a></div>
<div class="references"><a rel="prettyPhoto[pp_gal]" title="Description" href="mod/swtheme/images/01.jpg"><img src="mod/swtheme/images/01-thumb.jpg" alt="" /><span>Description 13</span></a></div>
<div class="references"><a rel="prettyPhoto[pp_gal]" title="Description"  href="mod/swtheme/images/01.jpg"><img src="mod/swtheme/images/02-thumb.jpg" alt="" /><span>Description 14</span></a></div>
<div class="references"><a rel="prettyPhoto[pp_gal]" title="Description" href="mod/swtheme/images/01.jpg"><img src="mod/swtheme/images/01-thumb.jpg" alt="" /><span>Description 15</span></a></div>
<div class="references"><a rel="prettyPhoto[pp_gal]" title="Description"  href="mod/swtheme/images/01.jpg"><img src="mod/swtheme/images/02-thumb.jpg" alt="" /><span>Description 16</span></a></div>
<div class="references"><a rel="prettyPhoto[pp_gal]" title="Description" href="mod/swtheme/images/01.jpg"><img src="mod/swtheme/images/01-thumb.jpg" alt="" /><span>Description 17</span></a></div>
<div class="references"><a rel="prettyPhoto[pp_gal]" title="Description"  href="mod/swtheme/images/01.jpg"><img src="mod/swtheme/images/02-thumb.jpg" alt="" /><span>Description 18</span></a></div>
<div class="references"><a rel="prettyPhoto[pp_gal]" title="Description" href="mod/swtheme/images/01.jpg"><img src="mod/swtheme/images/01-thumb.jpg" alt="" /><span>Description 19</span></a></div>
<div class="references"><a rel="prettyPhoto[pp_gal]" title="Description"  href="mod/swtheme/images/01.jpg"><img src="mod/swtheme/images/02-thumb.jpg" alt="" /><span>Description 20</span></a></div>
</div>
<p>Click on a thumbnail for closer view!</p>
</div>
</li>

<li>
<div class="inner">		
<h2>Contact</h2>
<div class="left">

<!-- START FORM -->

<div class="form">

<form action="#" method="get">

<div class="formLeft">
Name:<br />
E-mail Address:<br />
Message:<br />
</div>

<div class="formRight">
<input type="text" name="name" /><br />
<input type="text" name="email" /><br />
<textarea rows="" cols=""></textarea><br /> 
<input class="submit" type="submit" value="Submit" /><br />
</div>
</form> 

</div><!-- END FORM -->
</div>

<div class="right">
<p><b>Your Name</b><br />
Your Road<br />
Your City<br />
PHONE: (555) 555-5555<br />

FAX: (555) 555-5555</p>

<a href="mailto:info@your-web-domain.com">info@your-web-domain.com</a>

</div>
</div>
</li>

</ul>
</div>

<div class="copyright"><a href="index.php">Home</a> | Copyright 20xx <a href="#sitename">Your Sitename</a> | Original Design by <a href="http://www.milocker.com/sitioempresa">SocialWeb</a></div>


</div>

<!-- END YOUR CONTENT -->

<script type="text/javascript" src="mod/swtheme/js/jquery.js"></script>
<script type="text/javascript" src="mod/swtheme/js/easySlider1.5.js"></script>
<script src="mod/swtheme/js/jquery.prettyPhoto.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript" charset="utf-8">
		$(document).ready(function(){
			$("a[rel^='prettyPhoto']").prettyPhoto({
			theme: 'dark_square'
});
});

$(document).ready(function(){	
	$("#slider").easySlider({
		controlsFade: true,
		continuous: true 
	});
});
</script>

</body>
<script type="text/javascript">
$(document).ready(function () {
	$('.messages').animate({opacity: 1.0}, 1000);
	$('.messages').animate({opacity: 1.0}, 1000);
	$('.messages').fadeOut('slow');

	$('span.closeMessages a').click(function () {
		$(".messages").stop();
		$('.messages').fadeOut('slow');
	return false;
	});

	$('div.messages').click(function () {
		$(".messages").stop();
		$('.messages').fadeOut('slow');
	return false;
	});
});
</script>
<script type="text/javascript">
$(document).ready(function () {
	$('.messages_error').animate({opacity: 1.0}, 1000);
	$('.messages_error').animate({opacity: 1.0}, 1000);
	$('.messages_error').fadeOut('slow');

	$('span.closeMessages a').click(function () {
		$(".messages_error").stop();
		$('.messages_error').fadeOut('slow');
	return false;
	});

	$('div.messages').click(function () {
		$(".messages").stop();
		$('.messages').fadeOut('slow');
	return false;
	});
});
</script>
	
	

<?php $messages = system_messages();	
	$message = $messages['messages'];
	
	if(count($message) > 0){ 
		echo '<div class="messages">';
		echo '<span class="closeMessages"><a href="#">click to dismiss</a></span>';
			foreach($message as $message1)
					{
					echo '<p>';
					echo $message1;
					echo '</p>';
					}
		echo '</div>';
	}

	$errors = register_error();
	$error = $errors['errors'];
	if(count($error) > 0){ 
		echo '<div class="messages_error">';
		echo '<span class="closeMessages"><a href="#">click to dismiss</a></span>';
			foreach($error as $error1)
					{
					echo '<p>';
					echo $error1;
					echo '</p>';
					}
		echo '</div>';
	}


////////////////////////////////////////////////////////////////////////////////////////////////
?>
</html>
