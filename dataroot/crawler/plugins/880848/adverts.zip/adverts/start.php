<?php
function adverts_init() {

	//extend some views
	elgg_extend_view('css/elgg', 'css/adverts/css');
	elgg_extend_view('page/elements/sidebar', 'adverts/elements/sidebar', 900);
	elgg_extend_view('page/elements/footer', 'adverts/elements/footer');
}
elgg_register_event_handler('init', 'system', 'adverts_init');
?>
