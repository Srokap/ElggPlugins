<?php
	$footer_content = elgg_get_plugin_setting('footer_content','adverts');
?>

	<textarea style="width: 980px; height:250px;" name="<?php echo $vars['name']; ?>" ><?php echo $footer_content; ?></textarea>
