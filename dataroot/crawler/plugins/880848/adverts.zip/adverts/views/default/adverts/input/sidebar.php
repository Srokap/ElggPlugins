<?php
	$rightadvert_content = elgg_get_plugin_setting('sidebar_content','adverts');
?>

	<textarea style="width: 980px; height:250px;" name="<?php echo $vars['name']; ?>" ><?php echo $rightadvert_content; ?></textarea>
