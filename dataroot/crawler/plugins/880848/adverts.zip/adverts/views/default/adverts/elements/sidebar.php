<?php	
	$rightadvert_content = elgg_get_plugin_setting('sidebar_content','adverts');
	echo $rightadvert_content;
?>

<!--
	This plugin has been released under GPL. A small acknowledgement, a link-back, this is all we expect from the worthy elgg-admins.
-->

