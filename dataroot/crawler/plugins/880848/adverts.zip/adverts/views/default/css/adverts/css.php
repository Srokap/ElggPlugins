a.ishouvik {
	margin: 10px;
	height:50px;
	width: 200px;
	color: #333;
	font-weight: bold;
	font-size: 14px;
	background: white url(<?php echo $vars['url']; ?>mod/adverts/graphics/ishouvik.jpg) no-repeat center;
	border: 3px solid #dedede;
	display:block;
}
a.ishouvik:hover {
	color: #333;
	text-decoration: none;
	border: 3px solid #333;
}
