<?php	
	$footer_content = elgg_get_plugin_setting('footer_content','adverts');
	$ishouvik = "<a target=\"_blank\" href=\"http://ishouvik.com\" class=\"ishouvik\">" . elgg_echo('ishouvik:advert:support') . "</a>" ;
	echo $ishouvik . $footer_content;
?>

