<?php
/**
 * Elgg iShouvik Adverts plugin language pack
 *
 * @package iShouvikAdverts
 */

$english = array(

	// forms
	'ishouvik:advert:sidebar' => 'Sidebar Advert',
	'ishouvik:advert:footer' => 'Footer Advert',

	// support text
	'ishouvik:advert:support' => 'Proudly supported by',


);

add_translation("en", $english);
