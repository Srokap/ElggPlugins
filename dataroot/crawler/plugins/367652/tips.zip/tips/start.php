<?php

         /**
         * Elgg tips plugin
         * Displays tips and How to in a profile widget to help your user learn your site
         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author Goofbucket
         * @copyright Open
         */
         
         global $CONFIG;
                          
        // Register a page handler, so we can have nice URLs
                register_page_handler('tips','tips_page_handler');
        
        // Page handler
                function scopes_page_handler($page) {
                        global $CONFIG;
                        include($CONFIG->pluginspath . "tips/index.php");
                }
                
        // Load menu
                if (isloggedin()) {
                //add_menu(elgg_echo('Tips'),$CONFIG->wwwroot."pg/tips");
                }
        // Shares widget
                add_widget_type('tips',elgg_echo("Tips - How 2 - Help"),elgg_echo("Tips - How 2 - Help"));
        
                
?>
