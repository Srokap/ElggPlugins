<?php
         /**
         * Elgg tips plugin
         * Displays tips and How to in a profile widget to help your user learn your site
         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author Goofbucket
         * @copyright Open
         */
?>
<div id="scope" style="text-align:center;" class="contentWrapper">
<?php
/*****
Random Tips and How 2's


HOW TO USE -
1. Edit the quotes below (Random quote 1, etc).
2. Or add in new quotes by copying the text
"Random quote 1",
and pasting it on a new line above
"Random quote 1",

Then include it on your website by using the code:
include("quotes.php");
*****/

$quotes = array(

"Settings often located in the top bar, center, is for your account configurations such as your acount name, account password, email settings, and other settings provided by the website Admin.",
"Tools in the top bar is a drop down with quick access to the sites features such as blogs, groups, files, and other features of the site.",
"When you create your group, blog, page, upload a file, a video, or post photos to your album you have the option to set as private, logged in users, or public.",
"Should you forget your password the system will send you a new password to the email you registered with",
"When creating your blogs, groups, pages, or other features, remember that the more descriptive Tags the better other users will be able to find your content",
"This site uses php to build pages, sometimes you may need to refresh a page for it to load properly",
"This site has a micro blogging feature, it is your key to other users.  You can get to your micro blog either through the Dashboard or Tools drop down menu",
"Remember to fill out your profile, Your profile is the best way for other users to meet and get to know you",
"To edit your profile click the second icon in the top bar.  At your profile page click edit in the upper right corner of the profile box",
"To edit your profile icon go to your profile, click edit in your profile box, there you will see an edit icon link under the profile image",
"Search can help you find content from other users, it is based on the tags used to create files such as blogs, groups, pages, files, videos",
"In your settings you can set your notification to email alerts when someone sends you a message to how the site will alert you to comments on your blogs, groups, pages, files, and videos",
"To create a blog click blogs in the tools drop down menu, on the left side navigation you will see the option to create a blog",
"This site is equipped with a report this option, if you feel the content or user is offensive use this option to inform the site Admin, the link is located on the left side navigation",
"Please respect other users and do not use questionable images for your profile icon",
"Letting everyone know you are here.  When you create a blog, a group, an album, upload a video or file, the site will send a system message to your followers that you have posted",
"In the left navigation you will find invite freinds link, here you can invite your friends when you create a group, blog, or other content on the site",
"This site may be equipped with user online notification icons, it is best for you to logout so your friends and followers know you are no longer online",
"Site Admin may make site announcements using the micro blog, check back with the micro blog often in case there is such an announcement",
"Contact the site Admin should you find any bugs with the site.  The site Admin wants to make your experience enjoyable and will work to fix any issues",
"Inviting you friends and family to visit you site is a sure way to get more followers and friends, you will find an invite message system by clicking the icon of an envelope",
"When your envelope turns red this means you have a message or comment, click the envelope to read your message"

);

/*****
ATTENTION -
Do not edit below this line unless you know what you are doing.
*****/

echo $quotes[rand(0, count($quotes) - 1)];

?>
</div>

