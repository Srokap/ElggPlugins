
<?php
if (isloggedin()) forward('pg/dashboard/');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
    <head>
        <title>Social Web</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
        <meta name="description" content="Awesome Bubble Navigation with jQuery" />
        <meta name="keywords" content="jquery, circular menu, navigation, round, bubble"/>
        <link rel="stylesheet" href="mod/swTheme/css/style.css" type="text/css" media="screen"/>
        
		<script type="text/javascript" src="<?php echo $vars['url']; ?>vendors/jquery/jquery-1.3.2.min.js"></script>
       <script type="text/javascript" src="<?php echo $vars['url']; ?>vendors/jquery/jquery-ui-1.7.2.custom.min.js"></script>
       <script type="text/javascript" src="<?php echo $vars['url']; ?>vendors/jquery/jquery.form.js"></script>
		
		
		
		
		
		<style>
            *{
                margin:0;
                padding:0;
            }
            body{
                font-family:Arial;
                background:#fff url(mod/swTheme/images/bg.png) no-repeat top left;
            }
            .title{
                width:548px;
                height:119px;
                position:absolute;
                top:400px;
                left:150px;
                background:transparent url(mod/swTheme/title.png) no-repeat top left;
            }
            #content{
                margin:0 auto;
            }


        </style>
		
		
    </head>

    <body>
	<!--
////////////////////////////////////////////////////////////////////////////////////////////////
-->
<!-- display any system messages -->
<!-- used to fade out the system messages after 3 seconds -->
<style>
.messages {
	background:#ccffcc;
	color:#000000;
	padding:3px 10px 3px 10px;
	z-index: 8000;
	margin:0;
	position:fixed;
	top:30px;
	width:969px;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	border:4px solid #00CC00;
	cursor: pointer;
}
.messages_error {
	border:4px solid #D3322A;
	background:#F7DAD8;
	color:#000000;
	padding:3px 10px 3px 10px;
	z-index: 8000;
	margin:0;
	position:fixed;
	top:30px;
	width:969px;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	cursor: pointer;
}
.closeMessages {
	float:right;
	margin-top:17px;
}
.closeMessages a {
	color:#666666;
	cursor: pointer;
	text-decoration: none;
	font-size: 80%;
}
.closeMessages a:hover {
	color:black;
}
</style>
<script type="text/javascript">
$(document).ready(function () {
	$('.messages').animate({opacity: 1.0}, 1000);
	$('.messages').animate({opacity: 1.0}, 1000);
	$('.messages').fadeOut('slow');

	$('span.closeMessages a').click(function () {
		$(".messages").stop();
		$('.messages').fadeOut('slow');
	return false;
	});

	$('div.messages').click(function () {
		$(".messages").stop();
		$('.messages').fadeOut('slow');
	return false;
	});
});
</script>
<script type="text/javascript">
$(document).ready(function () {
	$('.messages_error').animate({opacity: 1.0}, 1000);
	$('.messages_error').animate({opacity: 1.0}, 1000);
	$('.messages_error').fadeOut('slow');

	$('span.closeMessages a').click(function () {
		$(".messages_error").stop();
		$('.messages_error').fadeOut('slow');
	return false;
	});

	$('div.messages').click(function () {
		$(".messages").stop();
		$('.messages').fadeOut('slow');
	return false;
	});
});
</script>
	
	

<?php $messages = system_messages();	
	$message = $messages['messages'];
	
	if(count($message) > 0){ 
		echo '<div class="messages">';
		echo '<span class="closeMessages"><a href="#">click to dismiss</a></span>';
			foreach($message as $message1)
					{
					echo '<p>';
					echo $message1;
					echo '</p>';
					}
		echo '</div>';
	}

	$errors = register_error();
	$error = $errors['errors'];
	if(count($error) > 0){ 
		echo '<div class="messages_error">';
		echo '<span class="closeMessages"><a href="#">click to dismiss</a></span>';
			foreach($error as $error1)
					{
					echo '<p>';
					echo $error1;
					echo '</p>';
					}
		echo '</div>';
	}


////////////////////////////////////////////////////////////////////////////////////////////////
?>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
        <div id="content">

            <div class="title"></div>

            <div class="navigation" id="nav">
                <div class="item user">
                    <img src="mod/swTheme/images/bg_user.png" alt="" width="199" height="199" class="circle"/>
                    <a href="<?php echo $vars['url']; ?>" class="icon"></a>
                    <h2>Login</h2>
					<br/>
					<br/>
                    <center>
<div id="welcome-box">
<div id="login-box">
<?php
$form_body = "<p><label>" . elgg_echo('username') . "<br />" . elgg_view('input/text', array('internalname' => 'username', 'class' => 'login-textarea')) . "</label><br />";
$form_body .= "<label>" . elgg_echo('password') . "<br />" . elgg_view('input/password', array('internalname' => 'password', 'class' => 'login-textarea')) . "</label><br />";
$form_body .= elgg_view('input/submit', array('value' => elgg_echo('login'))) . "</p>";
echo elgg_view('input/form', array('body' => $form_body, 'action' => "". $vars['url'] ."action/login"));
?>


</center>
                </div>
                <div class="item home">
                    <img src="mod/swTheme/images/bg_home.png" alt="" width="199" height="199" class="circle"/>
                    <a href="<?php echo $vars['url']; ?>/account/register.php" class="icon"></a>
                    <h2>Register</h2>
                   
                    
                    
	
				
				</div><!-- div class="item home" -->
                <div class="item shop">
                    <img src="mod/swTheme/images/bg_shop.png" alt="" width="199" height="199" class="circle"/>
                    <a href="http://www.milocker.com/shop/" class="icon"></a>
                    <h2>Tienda</h2>
                  
                       
                    
                </div>
                
                <div class="item fav">
                   
                 </div>
            </div>
        </div>
      
        
    </body>
</html>