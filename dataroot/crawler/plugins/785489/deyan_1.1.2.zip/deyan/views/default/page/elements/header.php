<?php
/**
 * Elgg header contents
 * This file holds the header output that a user will see
 **/

// show the title bar.
echo elgg_view('deyan/window/title_bar', $vars);

