<?php
/**
 * @package Deyan
 * @author Angel Gabriel
 * @web http://angelgabriel.tk
 * @mail angel.wrt@gmail.com
 *
 * @view deyan/window/register_welcome
 * This file shows a welcome message when register
 * 
 **/ 

echo deyan_view_icon('light', 128);
echo elgg_echo('deyan:register:welcome');



?>  

