<?php
/**
 * @package Deyan
 * @author Angel Gabriel
 * @web http://angelgabriel.tk
 * @mail angel.wrt@gmail.com
 *
 * @view panel/modules/search/content
 * This file shows the user's menu
 * 
 **/

echo elgg_view('search/search_box');


?>