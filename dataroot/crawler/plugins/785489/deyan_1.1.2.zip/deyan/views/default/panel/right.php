<?php
/**
 * @package Deyan
 * @author Angel Gabriel
 * @web http://angelgabriel.tk
 * @mail angel.wrt@gmail.com
 *
 * @view panel/right
 * This file is the right-side view for the panel. It must be extended.
 *
 *
 * @see deyan_register_panel_mod();
 **/ 
?>
