<?php
/**
 * @package Deyan
 * @author Angel Gabriel
 * @web http://angelgabriel.tk
 * @mail angel.wrt@gmail.com
 *
 * @view panel/modules/register/content
 * This file echo the link to register page
 * 
 **/ 

echo deyan_view_panel_link('register', deyan_view_icon('edit-square', 32));
?> 
