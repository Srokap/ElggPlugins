<?php
/**
 * @package Deyan
 * @author Angel Gabriel
 * @web http://angelgabriel.tk
 * @mail angel.wrt@gmail.com
 *
 * @view panel/modules/dashboard/content
 * This file shows the link to the dashboard or index
 * 
 **/ 

echo deyan_view_panel_link('dashboard', deyan_view_icon('crop', 32));
?> 
