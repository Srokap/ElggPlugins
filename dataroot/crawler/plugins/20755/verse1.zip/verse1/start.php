<?php
  function hello_init() {        
    add_widget_type('helloworld', 'Daily Bible Verse', 'The daily bible verse widget');
  }
 
  register_elgg_event_handler('init','system','hello_init');       
?>