<html>

<center>
<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="300" height="190" id="votd" align="middle">
<param name="allowScriptAccess" value="sameDomain" />
<param name="movie" value="http://www.biblegateway.com/usage/votd/votd.swf" />
<param name="quality" value="high" />
<param name="bgcolor" value="#ffffff" />
<embed src="http://www.biblegateway.com/usage/votd/votd.swf" quality="high" bgcolor="#ffffff" width="275" height="190" name="votd" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
</object>

</html>