<?php
/* LiangLeeGoogle
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @package LiangLeeFramework
 * @subpackage LiangLeeGoogle
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File version.php
 */
$LiangLee_version = 7072012;
$LiangLee_release = '1.0.0'; 
?>