======================================
Liang Lee Google
======================================

Allow admin to add sitetracking and site verfication code for Google.

What is Google Analytics?
A free service to analyze the performance of a website, such as user activity and site usability, by providing statistics on the users of the website. It can be used to measure the success of online marketing campaigns.

What is Google Site Verfication code?
Google Site Verfication is code that verify you website in other words google check that the website is belong to you or not

How to Signup for Google Analytics?
By visiting website below
https://accounts.google.com/ServiceLogin?service=analytics