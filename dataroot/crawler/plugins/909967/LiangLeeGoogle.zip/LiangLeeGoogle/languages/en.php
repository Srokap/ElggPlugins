<?php
/* LiangLeeGoogle
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @Package Liang Lee Framework
 * @subpackage LiangLeeGoogle
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @file en.php
 */

$english = array(
	'llee:pname:package' => 'LiangLee Google.',
	'llee:pname:settings' => "LiangLee Google Settings Page",
	'lianglee:google:site' => "Google Site verfication code.",
	'lianglee:google:analytics' => "Google Site Analytics code.",
	'lianglee:framewrok:miss' => "LiangLeeFramewrok is Missing",
	'lianglee:framewrok:miss:code' => "Error: #LF52 , Please inform site Administrator. ",


);

add_translation('en', $english);
