<?php
/* LiangLeeGoogle
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @package LiangLeeFramework
 * @subpackage LiangLeeGoogle
 * @author Liang Lee
 * @copyright Copyright (c) 2012, Liang Lee
 * @file Liangsiteanalytics.php
 */
 
$getdomain = elgg_get_plugin_setting('lianglee_analyitcsdomain', 'LiangLeeGoogle');
$getanalytics = elgg_get_plugin_setting('lianglee_analyitcs', 'LiangLeeGoogle');
if(empty($getanalytics)) {
	return;
}
?>
<script type="text/javascript">

	var _gaq = _gaq || [];
	_gaq.push(['_setAccount', '<?php echo $getanalytics; ?>']);
	<?php if (elgg_get_plugin_setting('lianglee_analyitcsdomain', 'LiangLeeGoogle')) {
 ?>
	_gaq.push(['_setDomainName', '<?php echo $getdomain; ?>']);
	<?php } ?>
	_gaq.push(['_trackPageview']);

	(function() {
		var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	})();

</script>