<?php
/* LiangLeeGoogle
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @Package Liang Lee Framework
 * @subpackage LiangLeeGoogle
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File settings.php
 */
 
$LiangLee_version =LiangLee_version('LiangLeeGoogle');
$LiangLee_release =LiangLee_release('LiangLeeGoogle');

$liang_lee_google_copytights = elgg_echo('lianglee:copyr:12');
$liang_lee_settings = elgg_echo('llee:pname:settings');

$liang_lee_label_analytics = elgg_echo('lianglee:google:analytics');
$liang_lee_label_site = elgg_echo('lianglee:google:site');
$liang_lee_label_analyticsdomain = elgg_echo('lianglee:google:site');

$liang_lee_site= elgg_view("input/text", array(
"name" => "params[lianglee_verificationcode]", 
"value" => $vars['entity']->lianglee_verificationcode,
"placeholder" => "1234567890aBcDeFgHiJkLmNoPqRsTuVwXyZ",
));	

$liang_lee_analytics= elgg_view("input/text", array(
"name" => "params[lianglee_analyitcs]", 
"value" => $vars['entity']->lianglee_analyitcs,
"placeholder" => "UA-XXXXXX-XX",
));	

$liang_lee_analyticsdomain= elgg_view("input/text", array(
"name" => "params[lianglee_analyitcsdomain]", 
"value" => $vars['entity']->lianglee_analyitcsdomain,
"placeholder" => "mydomain.com",
));	

$settings = <<<__HTML

    <h3>$liang_lee_settings</h3>
    <div><br>
        <p><i>$liang_lee_label_site</i><br>$liang_lee_site</p>
	    <p><i>$liang_lee_label_analytics</i><br>$liang_lee_analytics</p>
	    <p><i>$liang_lee_label_analyticsdomain</i><br>$liang_lee_analyticsdomain</p>
		<hr>
		<p><i>$liang_lee_mainpage_copytights</i>
		<p>Release:$LiangLee_release</p>
		<p>Version:$LiangLee_version</p>
    </div>
    
</div>
__HTML;
echo $settings;
