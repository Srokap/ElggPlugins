<?php 
/* LiangLeeGoogle
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @package LiangLeeFramework
 * @subpackage LiangLeeGoogle
 * @author Liang Lee
 * @copyright Copyright (c) 2012, Liang Lee
 * @file Liangsiteverfication.php
 */

$getcode = elgg_get_plugin_setting('lianglee_verificationcode', 'LiangLeeGoogle');

if(empty($getcode)) {
	return;
}
?>
<meta name="google-site-verification" content="<?php echo htmlspecialchars($getcode, ENT_QUOTES, 'UTF-8'); ?>" />
