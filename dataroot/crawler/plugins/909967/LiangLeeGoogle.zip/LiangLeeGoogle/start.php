<?php
/* LiangLeeGoogle
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @Package Liang Lee Framework
 * @subpackage LiangLeeGoogle
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File start.php
 */
 
elgg_register_event_handler('init', 'system', 'LiangLeeGoogle');

function LiangLeeGoogle() {
	elgg_extend_view ('page/elements/head','LiangLeeGoogle/Liangsiteverfication');
	elgg_extend_view ('page/elements/head','LiangLeeGoogle/Liangsiteanalytics');

    if (!elgg_is_active_plugin('LiangleeFramework')) {
        if (elgg_is_admin_logged_in()) {
        register_error(elgg_echo('lianglee:framewrok:miss'));
        } else {
        register_error(elgg_echo('lianglee:framewrok:miss:code'));	
         }
    }  
}
