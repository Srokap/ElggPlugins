<?php
 
    function ThemeFarmOrkut_init()
    {
			extend_view('metatags','ThemeFarmOrkut/metatags');
			extend_view('css','ThemeFarmOrkut/css');
			extend_view('page_elements/spotlight','ThemeFarmOrkut/elgg_topbar');
			extend_view('page_elements/spotlight','ThemeFarmOrkut/footer');
    }
 
    register_elgg_event_handler('init','system','ThemeFarmOrkut_init');
 
?>