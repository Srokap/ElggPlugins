/**
 * Gmap location field Java Script library
 *
 * Displays an interactive GMap input field
 *
 * @author Oscar Lopez - somosmas.org
 * @author Diego Ramírez <diego@somosmas.org>
 * @copyright Corporación Somos más 2009
 * @link http://www.somosmas.org
 *
 *
 */
<?php
require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");

$dragable = (get_plugin_setting("dragable","gmaplocationfield")!="no")?"true":"false";
$address_zoom = get_plugin_setting("address_zoom","gmaplocationfield");
$address_zoom = (!empty($address_zoom))?$address_zoom:"15";

?>
/****************************************
 * Gmap location input related functions
 ****************************************/
var geocoder = null;

jQuery(document).ready(function() {
	var count = jQuery("#gmap-count").val();
	for(var i=0; i< count;i++){
	  gmaplocationfield_init('gmap-'+i);
	}
});

/**
 * Initializes the JS code calls
 */
function gmaplocationfield_init(id){
  jQuery("[name=country_"+id+"]").change(gmaplocationfield_load_states);
  jQuery("[name=state_"+id+"]").change(gmaplocationfield_load_cities);
  jQuery("[name=city_"+id+"]").change(gmaplocationfield_load_address);

  jQuery("#div_"+id).width(jQuery("#container_"+id).width());
  jQuery("#div_"+id).height(300);
  jQuery("#div_"+id).gmap({controls: ['GLargeMapControl'], markers: []});
  geocoder = new GClientGeocoder();
}

/**
 * Takes the selected value from [name=country] and loads states info inside
 * the [name=state] field using an AJAX call.
 *
 * @param aCountry Event object whent it is called from a JQuery Event | String with the country code
 * @param aId Undefined when it is called from a JQuery Event | DOM id from the gmap context
 * @param aGeocode Undefined when it is called from a JQuery Event | Boolean
 */
function gmaplocationfield_load_states(aCountry,aId,aGeoCode){
  var id,country,geocode;
  if(aCountry.type){
   id = jQuery(this).attr("name").split("_")[1];
   country = jQuery(this).val();
   geocode = true;
  }
  else{
  	id = aId;
  	country = aCountry;
	geocode = aGeoCode;
  }
  if(geocode){
	<?php if(get_plugin_setting("show_country","gmaplocationfield")!="no"){?>
    var country_ = jQuery("[name=country_"+id+"] :selected").text();
    <?php }else {?>
    var country_ = jQuery("[name=country_"+id+"]").val();
    <?php }?>
    gmaplocationfield_geocode(id,country_,5,true);
  }

  jQuery("[name=state_"+id+"]").empty();
  jQuery("[name=state_"+id+"]").append("<option value=\"--\">"+EMPTY_LABEL+"</option>");
  jQuery("[name=city_"+id+"]").empty();
  jQuery("[name=city_"+id+"]").append("<option value=\"--\">"+EMPTY_LABEL+"</option>");
  if(country!="--"){
	$.get(ELGG_WWWROOT+"pg/gmap/states/"+country,function(data){
	  if(data){
	  	eval(data);
		for(var i=0; i< states.length;i++){
		  var state = states[i];
		  jQuery("[name=state_"+id+"]").append("<option value=\""+state.code+"\">"+state.name+"</option>");
		}
	  }
    });
  }

}
/**
 * Takes the selected value from [name=state] and loads the cities info inside
 * the [name=city] field using an AJAX call
 *
 * @param aState Event object when it is called from a JQuery event | String witht the state code
 * @param aId Undefined when it is called from a JQuery Event | DOM id from the gmap context
 * @param aGeocode Undefined when it is called from a JQuery Event | Boolean
 */
function gmaplocationfield_load_cities(aState,aId,aGeoCode){
  var id,state,geocode;
  if(aState.type){
  	id = jQuery(this).attr("name").split("_")[1];
    state = jQuery(this).val();
	geocode=true;
  }
  else{
	id = aId;
  	state = aState;
	geocode = aGeoCode;
  }
  if(geocode){
	var address = jQuery("[name=state_"+id+"] :selected").text();
	<?php if(get_plugin_setting("show_country","gmaplocationfield")!="no"){?>
    address += ',' +  jQuery("[name=country_"+id+"] :selected").text();
    <?php }else {?>
    address += ',' +  jQuery("[name=country_"+id+"]").val();
    <?php }?>
  	gmaplocationfield_geocode(id,address,7,true);
  }

  jQuery("[name=city_"+id+"]").empty();
  jQuery("[name=city_"+id+"]").append("<option value=\"--\">"+EMPTY_LABEL+"</option>");
  if(state!="--"){
	$.get(ELGG_WWWROOT+"pg/gmap/cities/"+state,function(data){
	  if(data){
	  	eval(data);
		for(var i=0; i< cities.length;i++){
		  var city = cities[i];
		  jQuery("[name=city_"+id+"]").append("<option value=\""+city.code+"\">"+city.name+"</option>");
		}
	  }
    });
  }
}
/**
 * Zoom in the map to city, state, country
 */
function gmaplocationfield_load_address(aCity){
  var id;
  if (aCity.target) {
  	id = jQuery(this).attr("name").split("_")[1];
  }
  else{
  	id = aCity;
  }

  var address = jQuery("[name=city_"+id+"] :selected").text();
	<?php if(get_plugin_setting("show_city","gmaplocationfield")!="no"){?>
    var address = jQuery("[name=city_"+id+"] :selected").text();
    <?php }else {?>
    var address = jQuery("[name=city_"+id+"]").val();
    <?php }?>
	<?php if(get_plugin_setting("show_state","gmaplocationfield")!="no"){?>
    address += ',' +  jQuery("[name=state_"+id+"] :selected").text();
    <?php }else {?>
    address += ',' +  jQuery("[name=state_"+id+"]").val();
    <?php }?>
	<?php if(get_plugin_setting("show_country","gmaplocationfield")!="no"){?>
    address += ',' +  jQuery("[name=country_"+id+"] :selected").text();
    <?php }else {?>
    address += ',' +  jQuery("[name=country_"+id+"]").val();
    <?php }?>
  gmaplocationfield_geocode(id,address,<?php echo $address_zoom;?>,true);
}

/**
 * Look up for an address and zoom in to it with the specified zoom level.
 *
 * @param String id Field identifier
 * @param String address Address for look up
 * @param intenger zoom Zoom level
 * @param boolean showMarker Put a marker in the result address
 */
function gmaplocationfield_geocode(id,address, zoom, showMarker) {
  var map_id = "div_"+id;
  var draggable_ = <?php echo $dragable;?>;

  if (geocoder) {
	geocoder.getLatLng(address,function(point) {
       if (point) {
	   	 $.gmap.maps[map_id].setZoom(zoom);
	   	 $.gmap.maps[map_id].panTo(point);
		 if(showMarker){
		 	if(!$.gmap.markers[map_id]){
				$.gmap.markers[map_id] = new GMarker(point,{draggable:draggable_});
				$.gmap.maps[map_id].addOverlay($.gmap.markers[map_id]);
				GEvent.addListener($.gmap.markers[map_id], "dragend", function(point) {
				  jQuery("#"+id).attr('value',point.lat()+","+point.lng());
				});

			}
			$.gmap.markers[map_id].setLatLng(point);
			jQuery("#"+id).attr('value',point.lat()+","+point.lng());
			if($.gmap.markers[map_id].isHidden()){
			  $.gmap.markers[map_id].show();
			}
		 }
       }
     }
   );
 }
}
function gmaplocationfield_update_marker(id,newpoint,zoom){
  var map_id = "div_"+id;
  var draggable_ = <?php echo $dragable;?>;

  $.gmap.maps[map_id].panTo(newpoint);
  $.gmap.maps[map_id].setZoom(zoom);
  $.gmap.maps[map_id].setCenter(newpoint);
  if(!$.gmap.markers[map_id]){
    $.gmap.markers[map_id] = new GMarker(newpoint,{draggable:draggable_});
    $.gmap.maps[map_id].addOverlay($.gmap.markers[map_id]);
    GEvent.addListener($.gmap.markers[map_id], "dragend", function(point) {
      jQuery("#"+id).attr('value',point.lat()+","+point.lng());
    });
  }
  $.gmap.markers[map_id].setLatLng(newpoint);
  jQuery("#"+id).attr('value',newpoint.lat()+","+newpoint.lng());
  if($.gmap.markers[map_id].isHidden()){
    $.gmap.markers[map_id].show();
  }
}

$.gmap = {
    maps: {},
	markers: {},
    marker: function(m) {
    	if (!m) {
            return null;
        } else if (m.lat == null && m.lng == null) {
            return $.gmap.marker($.gmap.readLatLng(m));
        } else if (m.lat == '' || m.lng == '') {
            return null;
        } else {
        		var marker = new GMarker(new GLatLng(m.lat, m.lng));
            if (m.txt) {
                GEvent.addListener(marker, "click", function() {
                        marker.openInfoWindowHtml(m.txt);
                        currentMarker = marker;
                    });
            }
            return marker;
        }
    },
    readLatLng: function(elem) {
        var latElem = $(".latitude", elem)[0];
        var lngElem = $(".longitude", elem)[0];
        if (latElem && lngElem) {
            return { lat:parseFloat($(latElem).attr("title")), lng:parseFloat($(lngElem).attr("title")), txt:$(elem).attr("title") }
        } else {
            return null;
        }
    },
    mapCount: 1
};

$.fn.gmap = function(options) {

    // If we aren't supported, we're done
    if (!window.GBrowserIsCompatible || !GBrowserIsCompatible()) return this;

    // Sanitize options
    if (!options || typeof options != 'object')options = {};

	options.mapOptions = options.mapOptions || {};
    options.markers = options.markers || [];
    options.controls = options.controls || {};

    // Map all our elements
    return this.each(function() {
            // Make sure we have a valid id
            if (!this.id) this.id = "gmap" + $.gmap.mapCount++;

            // Create a map and a shortcut to it at the same time
            map = $.gmap.maps[this.id] = new GMap2(this, options.mapOptions);

            geocoder = new GClientGeocoder();
            map.setCenter(new GLatLng(0,0),0);

            // Add controls to our map
            for (var i = 0; i < options.controls.length; i++) {
                var c = options.controls[i];
                eval("map.addControl(new " + c + "());");
            }
            // Poner todos los marcadores asociados en el mapa
            var marker = null;
            var i = 0;
            for (; i < options.markers.length; i++) {
                if (marker = $.gmap.marker(options.markers[i])){
                	map.addOverlay(marker);
                	bounds.extend(marker.getPoint());
                }
            }

            // Si tenemos al menos un marcador --> actualizar los bordes y zoom
            if ( i != 0){
	            map.setZoom(map.getBoundsZoomLevel(bounds) );
	      		map.setCenter(bounds.getCenter());
	      	}

        	map.addControl(new GMapTypeControl());
        	// map.setMapType(G_HYBRID_MAP);
        });


};

/*************************/

var latlngs = new Array();
var bounds = new GLatLngBounds();

String.prototype.trim = function () {
    return this.replace(/^\s*/, "").replace(/\s*$/, "");
}

function processLocations(elementId, delete_button_txt, editable) {

  	ms = new Array();

  	for (var i = 0; i < latlngs.length; i++)
  	{
  		var splitted_array = latlngs[i].split("|");
  		m = new Object();
        m.lat = splitted_array[0];
        m.lng = splitted_array[1];

        if (editable)
        {

	        var txt = "<table id=\"maps-input-form\" >" +
	             "<tr><td><div align=\"center\" />  <small> " + unescape(splitted_array[2]) + " </small> </div></td> </tr>" +
	             "<tr><td><div align=\"center\" /> <input class=\"map-input-button\" type=\"button\" value='" + delete_button_txt + "' onclick=\"deleteMarker('" + elementId + "')\"/></div></td></tr></table>";

	        m.txt = txt;
	    }
	    else
	    {
	        var txt = "<table id=\"maps-input-form\" >" +
	             "<tr><td><div align=\"center\" />  <small> " + splitted_array[2] + " </small> </div></td> </tr></table>";

	        m.txt = txt;
	    }
	    m.add = unescape(splitted_array[2]);
        ms.push(m);
  	}

    return ms;
}

/**
 * Utility function to calculate the appropriate zoom level for a
 * given bounding box and map image size. Uses the formula described
 * in the Google Mapki (http://mapki.com/).
 * @return         zoom level.
 */
function best_zoom(width, height, max_lat, min_lat, max_lng, min_lng) {

    var dlat = Math.abs((max_lat) - (min_lat));
    var dlon = Math.abs((max_lng) - (min_lng));

    if(dlat == 0 && dlon == 0)
        return 15;

    // Center latitude in radians
    var clat = Math.PI*(min_lat + max_lat)/360.;

    var C = 0.0000107288;
    var z0 = Math.ceil(Math.log(dlat/(C*height))/Math.LN2);
    var z1 = Math.ceil(Math.log(dlon/(C*width*Math.cos(clat)))/Math.LN2);

    return (z1 > z0) ? 17 - z1 : 17 - z0;
}

/*********** Utility functions for general map ************/
/**
 * A general helper function for creating html elements. <div> as default element type
 * @author Esa 2008
 * used for infowindows and sidebar
 */
function createElem(opt_className, opt_html, opt_tagName) {
  var tag = opt_tagName||"div";
  var elem = document.createElement(tag);
  if (opt_html) elem.innerHTML = opt_html;
  if (opt_className) elem.className = opt_className;
  return elem;
}

/**
 * sidebar with categories
 * @author Esa 2008
 */
function SideBar(block_element, opt_options){
  var opts = opt_options||{};
  this.division = createElem("sidebar-contents");
  block_element.appendChild(this.division);
  this.show =  function(){this.division.style.display = "block"};
  this.hide =  function(){this.division.style.display = "none"};
  this.cats = [];

  this.addEntry = function(point,opt_options){
    var opts = opt_options||{};
    var iLabel = opts.iLabel||2;
    var label = createElem("sidebar-entry", point.textArray[iLabel], "a");
    label.href = "#";
    label.style.display = "block";
    label.onclick = function(){GEvent.trigger(point.marker,'click'); return false};//x-browser
    label.onfocus = function(){GEvent.trigger(point.marker,'click'); return false};
    this.division.appendChild(label);
    GEvent.addListener(point.marker,'click',function(){label.focus(); return false});
  }
  this.clear = function(){
    while (this.division.firstChild) {
      this.division.removeChild(this.division.firstChild);
    }
  }
}

/**
 * category to a sidebar
 * @author Esa 2008
 */
function BarCategory(sideBar, catName, opt_options){
  var me = this;
  var opts = opt_options||{};
  me.division = createElem("sidebar-cat");
  var cssClasses = "sidebar-cat-header cat-header-"+catName;
  var cat = createElem(cssClasses);
  me.pin = createElem("sidebar-cat-image",null,"img");
  me.pin.src = opts.icon.image;
  cat.appendChild(me.pin);
  var check = createElem("sidebar-cat-check",null,"input");
  me.header = cat;
  check.type = "checkbox";
  check.checked = opts.checked||false;
  cat.appendChild(check);
  var checkLabel = createElem("sidebar-cat-label",catName,"span");
  cat.appendChild(checkLabel);
  me.show =  function(){
    me.division.style.display = "block";
    me.pin.style.visibility = "visible";
  }
  me.hide =  function(){
    me.division.style.display = "none";
    me.pin.style.visibility = "hidden";
  }
  me.hilight =  function(){me.header.className = cssClasses +"  hilight-cat-header"};
  me.lolight =  function(){me.header.className = cssClasses};
  sideBar.division.appendChild(cat);
  sideBar.division.appendChild(me.division);
  sideBar.cats[catName] = me;
  me.markers = [];
  me.showMarkers = function(){
    for(var i=0;i<me.markers.length;i++){
      me.markers[i].show();
    }
  }
  me.hideMarkers = function(){
    for(var i=0;i<me.markers.length;i++){
      me.markers[i].hide();
      me.markers[i].closeInfoWindow();
    }
  }
  function update(){
  	if(check.checked){
      me.show();
      me.showMarkers();
      me.hilight();
      for(var i=0;i<me.markers.length;i++)
      {
	      bounds.extend(me.markers[i].getLatLng());
      }
      var paddings = {top:30, right:10, bottom:10, left:50};
      /*
	  if(map){
		map.showBounds(bounds,paddings);
		map.setZoom(map.getBoundsZoomLevel(bounds) );
		map.setCenter(bounds.getCenter());
      }
      */

    }else{

    	bounds = new GLatLngBounds();
    	var entra = false;
    	for (var i =0; i<allCats.length; i++)
    	{
    		if(allCats[i].check.checked){
	    		for(var j=0;j<allCats[i].markers.length;j++)
				{
					bounds.extend(allCats[i].markers[j].getLatLng());
					entra = true;
				}
    		}
    	}

    	if (entra)
    	{
    		var paddings = {top:30, right:10, bottom:10, left:50};
			if(map){
    		map.showBounds(bounds,paddings);
			map.setZoom(map.getBoundsZoomLevel(bounds) );
			map.setCenter(bounds.getCenter());
			}
		}


      me.hide();
      me.hideMarkers();
      me.lolight();
    }
  };
  check.onclick = update;
  me.update = update;
  me.check = check;

  me.addEntry = function(point,opt_options){
    var opts = opt_options||{};
    me.markers.push(point.marker);
    var iLabel = opts.iLabel||2;
    var label = createElem("sidebar-entry", point.textArray[iLabel], "a");
    label.href = "#";
    label.style.display = "block";
    label.onclick = function(){GEvent.trigger(point.marker,'click'); return false};//x-browser
    label.onfocus = function(){GEvent.trigger(point.marker,'click'); return false};
    me.division.appendChild(label);
    GEvent.addListener(point.marker,'click',function(){label.focus(); return false});
  }
  me.clear = function(){
    while (me.division.firstChild) {
      me.division.removeChild(me.division.firstChild);
    }
  }
}
/**
 * Marker icon
 */
function tinyImage(opt_color, opt_preload){
  var color = opt_color||"red";
  var src_ = "http://labs.google.com/ridefinder/images/mm_20_"+color+".png";
  if(opt_preload){
    var preImage = new Image();
    preImage.src = src_;
  }
  return  src_;
}
function tinyIcon(opt_color){
  var tiny = new GIcon();
  tiny.image = tinyImage(opt_color);
  tiny.shadow = "http://labs.google.com/ridefinder/images/mm_20_shadow.png";
  tiny.iconSize = new GSize(12, 20);
  tiny.shadowSize = new GSize(22, 20);
  tiny.iconAnchor = new GPoint(6, 20);
  tiny.infoWindowAnchor = new GPoint(5, 1);
  tiny.imageMap = [4,0,0,4,0,7,3,11,4,19,7,19,8,11,11,7,11,4,7,0];
  tiny.transparent = "http://maps.google.com/mapfiles/transparent.png";
  return tiny;
}

/**
 * parseCsv()
 * @return an array of GLatLng() objects
 * @param opt_options object {lat, lng} integers defining the csv cells of coordinates (default: {lat:1, lng:0})
 * @author Esa 2008
 */
String.prototype.parseCsv = function(opt_options){
  var results = [];
  var opts = opt_options||{};
  var iLat = opts.lat||1;
  var iLng = opts.lng||0;
  var lines = this.split("\n");
  for (var i=0; i<lines.length; i++) {
    var blocks = lines[i].split('"');
    //finding commas inside quotes. Replace them with '::::'
    for(var j=0;j<blocks.length;j++){
      if(j%2){
        blocks[j]=blocks[j].replace(/,/g,'::::');
      }
    }  //@author Esa 2008, keep this note.
    lines[i] = blocks.join("");
    var lineArray = lines[i].split(",");
    var lat = parseFloat(lineArray[iLat]);
    var lng = parseFloat(lineArray[iLng]);
    var point = new GLatLng(lat,lng);
    //after splitting by commas, we put hidden ones back
    for(var cell in lineArray){
      lineArray[cell] = lineArray[cell].replace(/::::/g,',');
    } //corrupted line step-over
    if(!isNaN(lat+lng)){
      point.textArray = lineArray;
      results.push(point);
    }
  }
  return results;
}

var bounds = new GLatLngBounds();
var allCats = [];

GMap2.prototype.populate = function(points, options){
  var opts = options||{};

  //alert('opts.extendBounds:' + opts.extendBounds+ ", opts.cat" + opts.cat);

  var noCat = true;
  if(opts.cat||opts.iCat) noCat = false;
  var catName = opts.cat||"";
  var bar = opts.sidebar;
  var myCat;
  var newCats = [];
  for (var i=0; i < points.length; i++) {
    if(opts.iCat){ // category from file contents
      catName = points[i].textArray[opts.iCat];
    }
    var theIcon = opts.icon||CAT_ICONS[catName]||CAT_ICONS["DEFAULT_ICON"];
    if(!bar.cats[catName]&&!noCat){ // create a category if not found
      myCat = new BarCategory(this,bar, catName, {icon:theIcon});
      newCats.push(myCat);
      allCats.push(myCat);
    }
    var iLabel = opts.iLabel||2;
    var label = points[i].textArray[iLabel];
    points[i].marker = new GMarker(points[i],{title:label, icon:theIcon});
    this.addOverlay(points[i].marker);
    var entra = false;
    if (opts.extendBounds)
    {
    	bounds.extend(points[i]); // this must be considered
    	entra = true;
    }

    createInfoWindow(points[i],opts);
    if(noCat){
      bar.addEntry(points[i],opts);
    }else{
      myCat.addEntry(points[i],opts);
    }
  }

  if(myCat) {
  	  myCat.check.checked = opts.checked||false;
	  myCat.update();
  }
  for(var i=0;i<newCats.length;i++){
    newCats[i].check.checked = opts.checked||false;
    newCats[i].update();
  }
  if (entra) {
  	var paddings = {top:30, right:10, bottom:10, left:50};
	this.showBounds(bounds,paddings);
  	this.setZoom(this.getBoundsZoomLevel(bounds) );
  	this.setCenter(bounds.getCenter());
  }
}

/**
 * create infowindow
 */
function createInfoWindow(point, opt_options){
  var opts = opt_options||{};
  var start = opts.iLabel||2;
  var iwNode = createElem("info-window");
  var iwRows = [];
  for(var i=start; i<point.textArray.length; i++){
  var row = createElem("iw-cell-"+i, point.textArray[i]);
  iwRows.push(row);
  iwNode.appendChild(row);
  }
  iwRows[0].className += " iw-header";
  point.marker.bindInfoWindow(iwNode,{maxWidth:300});
}

function ajaxLoad(map,bar,textFile,opt_options){
	  var opts = opt_options||{};
	  opts.sidebar = bar;
	  $.get(textFile,function(data){
		  if(data!=null){
			  var entries = data.parseCsv(opts);
			  map.populate(entries,opts);
		  }
	  });
	}

$(window).unload(function() { GUnload(); });