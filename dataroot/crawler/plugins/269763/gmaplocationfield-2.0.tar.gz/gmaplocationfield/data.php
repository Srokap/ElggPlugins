<?php
/**
 *
 * @author Diego Andrés Ramírez Aragón
 * @copyright Corporación Somos más - 2008
 */
global $CONFIG;

require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
$option = get_input("option");
if(!empty($option)){
  switch($option){
    case "people":
      //@todo Load this eficiently. This approach could break a map with more than 1000 users
      $users = get_entities('user',"",0,"",null);

      foreach ($users as $user) {
        // Check for address or data in longitude and latitude
        if (get_plugin_setting('obligatory_address', 'gmaplocationfield') == "true") {
          $check = !empty($user->location);
        } else {
          $check = ($user->getLatitude() || $user->getLongitude());
        }
        //if(isset($user->location) && ! empty($user->location))
        //if(($user->getLatitude()) && ($user->getLongitude()))
        if ($check)
        {
          $locations = explode('||', $user->location);
          $lats = explode(",",$user->getLatitude());
          $lngs = explode(",",$user->getLongitude());
          $i=0;
          foreach ($locations as $loc)
          {
            //@todo
            echo $lngs[$i] .','.  $lats[$i] . ',' .$user->name . ','.  $loc . ',<div align="right"><a href="'. $user->getUrl() .'">'. elgg_echo('gmap:watch_entity') .'</a></div>' . "\n";
            $i++;
          }
        }
      }
      break;
    default:
      if(is_plugin_enabled("groupextended")){
        if(array_key_exists("group_type",$CONFIG->group)){
          $group_options = $CONFIG->group["group_type"][1];
          if(in_array($option,$group_options)){
            $list_organizations = get_entities_from_metadata('group_type', $option, 'group', "", 0, 99999);
            foreach ($list_organizations as $org) {

              // Check for address or data in longitude and latitude
              if (get_plugin_setting('obligatory_address', 'gmaplocationfield') == "true") {
                $check = !empty($org->location);
              } else {
                $check = ($org->getLatitude() || $org->getLongitude());
              }

              if($check){
                $locations = explode('||', $org->location);
                $lats = explode(",",$org->getLatitude());
                $lngs = explode(",",$org->getLongitude());
                $i=0;
                foreach ($locations as $loc){
                  echo $lngs[$i] .','.  $lats[$i] . ',' .$org->name . ','.  $loc . ',<div align="right"><a href="'. $org->getUrl() .'">'. elgg_echo('gmap:watch_entity') .'</a></div>' . "\n";
                  $i++;
                }
              }
            }
          }
        }
      }
      echo elgg_view("gmaplocationfield/data",array("option"=>$option));
  }
}
?>