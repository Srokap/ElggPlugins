<?php
/**
 * This scripts upgrade the geographic data from gmaplocationfield-1.0 to gmaplocationfield-2.0
 *
 * @author Diego Andrés Ramírez Aragón
 * @copyright Corporación Somos más - 2008
 */
require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");

global $CONFIG;

$query = "SELECT * FROM {$CONFIG->dbprefix}metastrings WHERE string='location'";
$location_field = get_data_row($query);
if(!empty($location_field)){
  login(get_entity(2));
  $query = "SElECT count(*) as count FROM {$CONFIG->dbprefix}metastrings WHERE id IN (SELECT value_id FROM {$CONFIG->dbprefix}metadata WHERE name_id={$location_field->id})";
  $count = get_data_row($query);
  if(!empty($count)){
    for($i=0;$i<$count->count;$i+=10){
      $query = "SElECT m.entity_guid,m.value_id,s.string FROM {$CONFIG->dbprefix}metastrings s,{$CONFIG->dbprefix}metadata m ";
      $query.= "WHERE s.id=m.value_id ";
      $query.= "AND m.name_id={$location_field->id} ";
      $query.= "GROUP BY m.value_id ";
      $query.= "LIMIT $i,10";
      $items = get_data($query);
      if(!empty($items)){
        foreach($items as $item){
          $locations = explode(",",$item->string);
          $lats = $lngs = $address = array();
          foreach($locations as $location){
            $cords = explode("|",$location);
            if(count($cords)==3){
              $lats[] = $cords[0];
              $lngs[] = $cords[1];
              $address[] = $cords[2];
            }
          }
          if(count($lats)>0){
            $lats = (count($lats)>1) ? implode(",",$lats):$lats[0];
            $lngs = (count($lngs)>1) ? implode(",",$lngs):$lngs[0];
            $address = (count($address)>1)?implode(",",$address):$address[0];
            $entity = get_entity($item->entity_guid);
            if($entity){
              echo "Upgrading {$item->entity_guid} : ($lats,$lngs) $address\n";
              if(!empty($lats) && !empty($lngs)){
                echo "Setting latitude $lats, longitude $lngs\n";
                $entity->setLatLong($lats,$lngs);
              }
              $entity->setLocation($address);
              try{
                $entity->save();
                echo "{$item->entity_guid} upgraded!\n";
              }
              catch(Exception $e){
                echo "Error upgrading {$item->entity_guid} entity!\n";
              }
            }
            else{
              echo "{$item->entity_guid} entity not found!\n";
            }
          }
        }
      }
    }
  }
  logout();
}
?>