<?php

	$english = array(

			'location' => 'Location',

           'gmap' => 'Geo-Referentiation',
           'gmap:desc' => 'This plugin allows you to place Google Maps on Elgg site.',
           'gmap:nokey' => "You've installed the Google Map plugin but you still need to supply a GMap API key in the Google Map section of the admin panel.",

           'gmap:location' => 'Enter the default location. Ej. Bogota, Colombia',
           'gmap:id' => 'Enter the map element ID (optional)',
           'gmap:zoom' => 'Enter the zoom level',
           'gmap:notfound' => '%s not found',

           'gmap:submit' => 'Submit',
		   'gmap:go' => 'go',
           'gmap:modify' => 'Enter your Google Maps API Key<br /><small>You can obtain an API Key <a target="_blank" href="http://code.google.com/apis/maps/signup.html">here</a>.</small>',
           'gmap:modify:success' => 'Successfully updated the Google Maps API settings.',
           'gmap:modify:failed' => 'Failed to update the Google Maps API settings.',
           'gmap:failed:noparams' => 'Error: Incorrect or missing input.',
		   'gmap:city:search' => 'Locate in other city:',
		   'gmap:city:notfound' => 'City not found',

			'gmap:watch_entity' => 'Go',
		    'gmap:general:title' => 'Aggregated Map',
			'gmap:users' => 'Persons',
			'gmap:organizations' => 'Organizations',
			'gmap:services:needed' => 'Needed Services',
			'gmap:products:needed' => 'Needed Products',
			'gmap:services:offered' => 'Offered Services',
			'gmap:products:offered' => 'Offered Products',

           'gmap:river:created' => "%s added the map widget.",
           'gmap:river:updated' => "%s updated the map widget.",
           'gmap:river:delete' => "%s removed the map widget.",

           'gmap:noset' => "There's no GMap configured.",

           'groups:location' => "Location",

		   'item:object:' . GMAP_SUBTYPE => 'Google Maps Object',

		   'gmap:cities'=>'Enable cities field?',
	       'gmap:states'=>'Enable states field?',
	       'gmaplocationfield:choose'=>'Please choose one',
	       'gmaplocationfield:country'=>'Country',
	       'gmaplocationfield:state'=>'State',
	       'gmaplocationfield:city'=>'City',
	       'gmaplocationfield:address'=>'Address',
	       'gmap:obligatory:address'=>'The address its mandatory for show the point in the global map',
	       'gmap:settings:true'=>'Obligatory',
	       'gmap:settings:false'=>'Not Obligatory',
		   'gmap:show:country'=>'Show the country field?',	
		   'gmap:show:states'=>'Show the state field?',	
		   'gmap:show:city'=>'Show the city field?',	
		   'gmap:show:country:note'=>'NO to use the default country without let users change the value.',	
		   'gmap:show:states:note'=>"NO to use the default state without let users change the value.",	
		   'gmap:show:city:note'=>'NO to use the default city without let users change the value.',	
		   'gmap:default:country'=>'Default country',	
		   'gmap:default:states'=>'Default state',	
		   'gmap:default:cities'=>'Default city',	
		   'gmap:dragable:marker'=>'Dragable marker?',	
	);

	add_translation("en",$english);


?>