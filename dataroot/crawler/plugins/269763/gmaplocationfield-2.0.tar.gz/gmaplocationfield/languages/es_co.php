<?php

$spanish = array(

			'location' => 'Dirección',

           'gmap' => 'Geo-Referenciaci&oacute;n',
           'gmap:desc' => 'Este plugin permite agregar mapas de Google para geolocalización.',
           'gmap:nokey' => "Ha instalado el plugin de Geo-Referenciación pero aún no ha ingresado una GMap API en la sección de administración.",

           'gmap:location' => 'Ingrese la ubicaci&oacute;n por defecto para el site. Ej: Medell&iacute;n, Colombia',
           'gmap:id' => 'Ingrese el ID del mapa (opcional)',
           'gmap:zoom' => 'Ingrese el nivel de zoom',
           'gmap:notfound' => '%s no encontrado',

           'gmap:submit' => 'Aceptar',
		   'gmap:go' => 'ir',
		   'gmap:modify' => 'Ingrese la llave GMap API <br /><small>Puede obtener esta llave <a target="_blank" href="http://code.google.com/apis/maps/signup.html">aqu&iacute;</a>.</small>',
		   'gmap:delete:marker' => 'Eliminar',
           'gmap:modify:success' => 'Actualizó exitosamente las propiedades del plugin de Geo-Referenciación.',
           'gmap:modify:failed' => 'Error al actualizar las propiedades del plugin de Geo-Referenciación.',
           'gmap:failed:noparams' => 'Error: Falta entrada o es incorrecta.',
		   'gmap:city:search' => 'Si desea ubicase en otra ciudad:',
		   'gmap:city:notfound' => 'Ciudad no encontrada.',

			'gmap:watch_entity' => 'Ver',
		   'gmap:general:title' => 'Localización general',
			'gmap:users' => 'Personas',
			'gmap:organizations' => 'Organizaciones',
			'gmap:services:needed' => 'Servicios Necesitados',
			'gmap:products:needed' => 'Productos Necesitados',
			'gmap:services:offered' => 'Servicios Ofrecidos',
			'gmap:products:offered' => 'Productos Ofrecidos',


           'gmap:river:created' => "%s adicionó el widget de Geo-Referenciación.",
           'gmap:river:updated' => "%s actualizó el widget de Geo-Referenciación.",
           'gmap:river:delete' => "%s eliminó el widget de Geo-Referenciación.",

           'gmap:noset' => "No hay Geo-Referenciación configurada.",

           'groups:location' => "Ubicación",

           'item:object:' . GMAP_SUBTYPE => 'Google Maps Object',

		   'gmap:cities'=>'¿Activar el campo ciudades?',
	       'gmap:states'=>'¿Activar el campo departamentos?',
	       'gmaplocationfield:choose'=>'Seleccione uno',
	       'gmaplocationfield:country'=>'País',
	       'gmaplocationfield:state'=>'Departamento',
	       'gmaplocationfield:city'=>'Ciudad',
	       'gmaplocationfield:address'=>'Dirección',
           'gmap:obligatory:address'=>'Obligar al usuario a poner una direccion para salir en el mapa.',
           'gmap:settings:true'=>'Obligatorio',
           'gmap:settings:false'=>'No es necesario',
		   'gmap:show:country'=>'¿Mostrar el campo país?',	
		   'gmap:show:states'=>'¿Mostrar el campo departamento?',	
		   'gmap:show:city'=>'¿Mostrar el campo ciudad?',	
		   'gmap:show:country:note'=>'NO para usar el país por defecto sin que los usuarios puedan modificarlo.',	
		   'gmap:show:states:note'=>"NO para usar el depto por defecto sin que los usuarios puedan modificarlo.",	
		   'gmap:show:city:note'=>'NO para usar la ciudad por defecto sin que los usuarios puedan modificarlo.',	
		   'gmap:default:country'=>'País por defecto',	
		   'gmap:default:states'=>'Depto. por defecto',	
		   'gmap:default:cities'=>'Ciudad por defecto',	
		   'gmap:dragable:marker'=>'¿Permitir mover el marcador del punto?',	
);

           add_translation("es_CO", $spanish);


?>