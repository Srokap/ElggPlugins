<?php

admin_gatekeeper();
action_gatekeeper();
	
$gmap_key = get_input('gmap_key');
$default_location = get_input('default_location');
	
if ($gmap_key) {
  //If the Google Maps setting doesn't exist, create it.
  $entities = get_entities("object", GMAP_SUBTYPE, 0, "", 9999);
  if(!isset($entities[0])) {
    $entity = new ElggObject;
    $entity->subtype = GMAP_SUBTYPE;
    $entity->owner_guid = $_SESSION['user']->getGUID();
    $entity->gmap_key = $gmap_key;
    $entity->default_location = $default_location;
    $entity->access_id = 2;	//public
  } else {			
    $entity = $entities[0];
    $entity->gmap_key = $gmap_key;
    $entity->default_location = $default_location;
    $entity->access_id = 2; //public
  }
		
  if ($entity->save()) {
    system_message(elgg_echo('gmap:modify:success'));
    $entity->state = "active";
    forward('pg/google-map');
  } else {
    register_error(elgg_echo('gmap:modify:failed'));
    forward('pg/google-map');
  }
		
} else {
		
  register_error(elgg_echo('gmap:failed:noparams'));
  forward('pg/google-map');
	    
}

?>