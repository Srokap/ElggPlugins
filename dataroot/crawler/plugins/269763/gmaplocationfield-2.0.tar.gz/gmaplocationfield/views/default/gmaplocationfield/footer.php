<?php /* Google Maps plugin for the Elgg social network engine. */ ?>
<?php
  // Post a system message if the plugin is enabled but there is no API key 
$gmap_key = get_plugin_setting("gmap_key","gmaplocationfield");
if(($_SESSION['user']->admin || $_SESSION['user']->siteadmin) && empty($gmap_key)){
  system_message(elgg_echo("gmap:nokey"));
}
?>