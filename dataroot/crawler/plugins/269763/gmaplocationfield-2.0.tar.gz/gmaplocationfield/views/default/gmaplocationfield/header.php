<?php
global $gmapinuse;
//global $gmap_key;

?>
<script type="text/javascript">
var ELGG_WWWROOT='<?php echo $vars["url"];?>';
var EMPTY_LABEL = '<?php echo elgg_echo("gmaplocationfield:choose");?>';
</script>

<?php
if (isset($gmapinuse) && $gmapinuse == true) {
    $gmap_key = get_plugin_setting("gmap_key","gmaplocationfield");
?>

<script type="text/javascript" src="http://maps.google.com/maps?file=api&v=2&key=<?php echo $gmap_key; ?>"></script>
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/gmaplocationfield/javascript/gmap.php" ></script>


<style>
<!--

table.main th {background-color:#ccf; height:20px;}
.sidebar-entry {text-decoration:none; border-bottom:1px solid #F4F4F4;}
a.sidebar-entry {color:#000; text-decoration: none; margin-left:20px}
a.sidebar-entry:hover {background-color:#F4F4F4; text-decoration: none}
a.sidebar-entry:focus {background-color:#F4F4F4; text-decoration: none}
.sidebar-cat-header {background-color:#F4F4F4; margin:1px; font-weight:bold; color:#0054A7}
.iw-header {background-color:#F4F4F4;font-weight:bold}
#sidebar {width:180px; height:500px; overflow:auto}
#map {width:500px; height:500px;}
.sidebar-cat-label {font-size: 10px}


-->
</style>


<?php
} // google map needed
?>