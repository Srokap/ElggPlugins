<?php
/**
*
* @author Diego Andrés Ramírez Aragón <diego@somosmas.org>
* @copyright Corporación Somos más - 2008
*/

?>
#maps-input-form input.map-input-text{
	font-size:12px;
	height:12px;
	border:1px solid #BBBBBB;
}

#maps-input-form input.map-input-button{
	font-size:10px;
	height:23px;
	border:1px solid #BBBBBB;
}
#map-controls{
	border:1px solid;
	float:left;
	width:200px;
	height:500;
	overflow:auto;
	margin:0px 10px 0 20px;
}
#map-control{
	margin:10px;
}

#map-container{
	border:1px solid;
	width:700px;
}
