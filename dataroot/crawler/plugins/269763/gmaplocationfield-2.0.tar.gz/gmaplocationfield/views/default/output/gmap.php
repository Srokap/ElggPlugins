<?php

/**
 * Elgg display Google Map
 * Displays a Static Google Map with markers
 *
 * @author Oscar Lopez - somosmas.org
 * @link http://www.somosmas.org
 *
 * @uses $vars['value'] Markers to deploy. Format: <lat_1>|<lng_1>|<txt_1>, .... ,<lat_i>|<lng_i>|<txt_i>, .... ,<lat_n>|<lng_n>|<txt_n>,
 * @uses $vars['full'] True to show the map image or just the text locations, default false
 * @uses $vars['width'] Width of the image, default 300px
 * @uses $vars['height'] Height of the image, default 300px
 * @uses $vars['maptype'] Type of map, possible values = ['hybrid', 'satellite', 'terrain', 'roadmap'], default 'roadmap'
 */

//global $gmapinuse;
//$gmapinuse = true;

$show_state = (!empty($vars["show_state"]))?$vars["show_state"]:false;

$items = array();
if(!empty($vars["entity"])){
  $entity_address = explode("||",$vars["entity"]->location);
  $entity_lats = explode(",",$vars["entity"]->getLatitude());
  $entity_lngs = explode(",",$vars["entity"]->getLongitude());
  $entity_countries = explode(",",$vars["entity"]->country);
  $entity_states = explode(",",$vars["entity"]->state);
  $entity_cities = explode(",",$vars["entity"]->city);
  $fields = count($entity_lats);
  for($i=0;$i<$fields;$i++){
    $item = "";
    if(!empty($entity_address[$i])){
      $item.= htmlentities($entity_address[$i], ENT_QUOTES, 'UTF-8')."&nbsp;";
    }
    if(!empty($entity_cities[$i])){
      $item.= elgg_echo(get_city($entity_cities[$i]))."&nbsp;";
    }
    if(!empty($entity_states[$i]) && $show_state){
      $item.= elgg_echo(get_state($entity_states[$i]))."&nbsp;";
    }
    if(!empty($entity_countries[$i])){
      $item.= elgg_echo(get_country($entity_countries[$i]))."&nbsp;";
    }

    $item.=
    $items[]=$item;
  }
$items = implode("<br>",$items);
echo $items;
}
else{
  echo $vars['value'];
}
?>