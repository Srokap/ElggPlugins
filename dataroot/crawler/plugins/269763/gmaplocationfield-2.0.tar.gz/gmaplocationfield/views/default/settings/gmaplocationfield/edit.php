<?php

 $gmap_key = $vars['entity']->gmap_key;
 $states = (empty($vars['entity']->states))?'yes':$vars['entity']->states;
 $cities = (empty($vars['entity']->cities))?'yes':$vars['entity']->cities;

 $default_country = $vars['entity']->default_country;
 $default_state = $vars['entity']->default_state;
 $default_city = $vars['entity']->default_city;

 $empty_set = array("--"=>elgg_echo("gmaplocationfield:choose"));
 $default_location = $vars['entity']->default_location;

 // Option for Obligatory Address
 $obligatory_address = $vars['entity']->obligatory_address;

 // Show/don't show specific fields
 $show_country = (!empty($vars["entity"]->show_country))?$vars["entity"]->show_country:"yes";
 $show_state = (!empty($vars["entity"]->show_state))?$vars["entity"]->show_state:"yes";
 $show_city = (!empty($vars["entity"]->show_city))?$vars["entity"]->show_city:"yes";

 // Dragable marker
 $dragable = (!empty($vars["entity"]->dragable))?$vars["entity"]->dragable:"yes";
 $address_zoom = (!empty($vars["entity"]->address_zoom))?$vars["entity"]->address_zoom:"15";
?>
<p>
<?php 	echo elgg_echo('gmap:modify'); ?>
<?php	echo elgg_view('input/text',array(
                                          'internalname' => 'params[gmap_key]',
                                          'value' => $gmap_key
                                          ));
?>
</p>
<br>
<p>
<?php 	echo elgg_echo('gmap:show:country'); ?>
<?php	echo elgg_view('input/pulldown',array(
                                          'internalname' => 'params[show_country]',
                                          'value' => $show_country,
                              			  'options_values' => array('yes' => elgg_echo('option:yes'),
                              									    'no' => elgg_echo('option:no'))
                                          ));

?>
&nbsp;&nbsp;<small><?php 	echo elgg_echo('gmap:show:country:note'); ?></small>
</p>
<p>
<?php 	echo elgg_echo('gmap:default:country'); ?>
<?php	echo elgg_view('input/pulldown',array(
                                          'internalname' => 'params[default_country]',
                                          'value' => $default_country,
                                          'options_values'=>get_countries(),
                                          'js'=>' id="default_country"'
                                          ));
?>
</p>
<br>
<p>
<?php 	echo elgg_echo('gmap:states'); ?>
<?php	echo elgg_view('input/pulldown',array(
                                          'internalname' => 'params[states]',
                                          'value' => $states,
                              			  'options_values' => array('yes' => elgg_echo('option:yes'),
                              									    'no' => elgg_echo('option:no'))
                                          ));

?>
</p>
<p>
<?php 	echo elgg_echo('gmap:default:states'); ?>
<?php	echo elgg_view('input/pulldown',array(
                                          'internalname' => 'params[default_state]',
                                          'value' => $default_state,
                              			  'options_values' => $empty_set,
                                          'js'=>' id="default_state"'
));

?>
</p>
<p>
<?php 	echo elgg_echo('gmap:show:states'); ?>
<?php	echo elgg_view('input/pulldown',array(
                                          'internalname' => 'params[show_state]',
                                          'value' => $show_state,
                              			  'options_values' => array('yes' => elgg_echo('option:yes'),
                              									    'no' => elgg_echo('option:no'))
                                          ));

?>
&nbsp;&nbsp;<small><?php 	echo elgg_echo('gmap:show:states:note'); ?></small>
</p>
<br>
<p>
<?php 	echo elgg_echo('gmap:cities'); ?>
<?php	echo elgg_view('input/pulldown',array(
                                          'internalname' => 'params[cities]',
                                          'value' => $cities,
                              			  'options_values' => array('yes' => elgg_echo('option:yes'),
                              									    'no' => elgg_echo('option:no'))
                                          ));
?>
</p>
<p>
<?php 	echo elgg_echo('gmap:default:cities'); ?>
<?php	echo elgg_view('input/pulldown',array(
                                          'internalname' => 'params[default_city]',
                                          'value' => $default_city,
                              			  'options_values' =>$empty_set,
                                          'js'=>' id="default_city"'
                                        ));
?>
</p>
<p>
<?php 	echo elgg_echo('gmap:show:city'); ?>
<?php	echo elgg_view('input/pulldown',array(
                                          'internalname' => 'params[show_city]',
                                          'value' => $show_city,
                              			  'options_values' => array('yes' => elgg_echo('option:yes'),
                              									    'no' => elgg_echo('option:no'))
                                          ));

?>
&nbsp;&nbsp;<small><?php 	echo elgg_echo('gmap:show:city:note'); ?></small>

</p>
<br>
<p>
	<?php echo elgg_echo('gmap:obligatory:address');?>

	<select name="params[obligatory_address]">
		<option value="true" <?php if ($obligatory_address == "true") {echo " selected=\"yes\" "; }?>><?php echo elgg_echo('gmap:settings:true');?></option>
		<option value="false" <?php if ($obligatory_address == "false") {echo " selected=\"yes\" "; }?>><?php echo elgg_echo('gmap:settings:false');?></option>
	</select>
</p>

<br>
<p>
<?php 	echo elgg_echo('gmap:dragable:marker'); ?>
<?php	echo elgg_view('input/pulldown',array(
                                          'internalname' => 'params[dragable]',
                                          'value' => $dragable,
                              			  'options_values' => array('yes' => elgg_echo('option:yes'),
                              									    'no' => elgg_echo('option:no'))
                                          ));

?>
</p>
<br>
<p>
<?php 	echo elgg_echo('gmap:address:zoom'); ?>
<?php	echo elgg_view('input/pulldown',array(
                                          'internalname' => 'params[address_zoom]',
                                          'value' => $address_zoom,
                              			  'options_values' => array('15' => elgg_echo('gmap:street'),
                              									    '12' => elgg_echo('gmap:city'))
                                          ));

?>
</p>

<br>
<br>
<p>
<?php 	echo elgg_echo('gmap:location'); ?>
<?php	echo elgg_view('input/text',array(
                                          'internalname' => 'params[default_location]',
                                          'value' => $default_location
                                          ));
?>
</p>

<script type="text/javascript">
function load_states(event){
  if(event.target){
	country = jQuery(this).val();
  }
  else{
	country = event;
  }
  jQuery("#default_state").empty();
  jQuery("#default_state").append("<option value=\"--\">"+EMPTY_LABEL+"</option>");
  jQuery("#default_city").empty();
  jQuery("#default_city").append("<option value=\"--\">"+EMPTY_LABEL+"</option>");
  if(country!="--"){
	$.get(ELGG_WWWROOT+"pg/gmap/states/"+country,function(data){
	  if(data){
	  	eval(data);
		for(var i=0; i< states.length;i++){
		  var state = states[i];
		  jQuery("#default_state").append("<option value=\""+state.code+"\">"+state.name+"</option>");
		}
	  }
   });
  }
}
function load_cities(event){
  if(event.target){
    state = jQuery(this).val();
  }
  else{
	state = event;
  }
  jQuery("#default_city").empty();
  jQuery("#default_city").append("<option value=\"--\">"+EMPTY_LABEL+"</option>");
  if(state!="--"){
	$.get(ELGG_WWWROOT+"pg/gmap/cities/"+state,function(data){
	  if(data){
	  	eval(data);
		for(var i=0; i< cities.length;i++){
		  var city = cities[i];
		  jQuery("#default_city").append("<option value=\""+city.code+"\">"+city.name+"</option>");
		}
	  }
    });
  }
}
var statePreloaded = false;
jQuery(document).ready(function() {
  jQuery("#default_country").change(load_states);
  jQuery("#default_state").change(load_cities);
  <?php if(!empty($default_country)){?>
  jQuery("#default_country").val('<?php echo $default_country;?>');
    <?php if(!empty($default_state) && $default_state!="--"){?>
  jQuery("#default_state").ajaxComplete(function(){
	  if(jQuery("#default_state").children().size()>1 && !statePreloaded){
		  jQuery("#default_state").val('<?php echo $default_state?>');
		  load_cities('<?php echo $default_state?>');
		  statePreloaded=true;
	  }
  });
    <?php }?>
    <?php if(!empty($default_city) && $default_city!="--"){?>
    jQuery("#default_city").ajaxComplete(function(){
  	  if(jQuery("#default_city").children().size()>1){
  		  jQuery("#default_city").val('<?php echo $default_city?>');
  	  }
    });
      <?php }?>
  load_states('<?php echo $default_country;?>');
  <?php }?>
});
</script>