<?php
/**
 *
 * @author Diego Andrés Ramírez Aragón
 * @copyright Corporación Somos más - 2008
 */
global $CONFIG;

if(is_plugin_enabled("groupextended")){
  if(array_key_exists("group_type",$CONFIG->group)){
    $group_options = $CONFIG->group["group_type"][1];
    foreach($group_options as $key => $value){
      if(!in_array($value,$CONFIG->maps_ignore)){
?>
CAT_ICONS["<?php echo $key ?>"] = tinyIcon("red");
ajaxLoad(map,myBar,"<?php echo $CONFIG->wwwroot."mod/gmaplocationfield/" ?>data.php?option=<?php echo $value?>",{cat:"<?php echo $key ?>", extendBounds:false});
<?php
      }
    }
  }
}

?>