<?php
/**
*
* @author Diego Andrés Ramírez Aragón
* @copyright Corporación Somos más - 2008
*/

$state = $vars["state"];
if(!empty($state)){
  $cities = get_cities($state);
  if(!empty($cities)){
    $resp = array();
    foreach($cities as $city){
      $resp[]="{'code':'{$city->city_code}','name':'".elgg_echo($city->city_name)."'}";
    }
    echo "var cities=[";
    echo implode(",\n",$resp);
    echo "];";
  }
}
else{
  echo "var cities = [];";
}
?>