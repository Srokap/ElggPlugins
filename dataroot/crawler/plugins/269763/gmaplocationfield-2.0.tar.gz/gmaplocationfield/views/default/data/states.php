<?php
/**
*
* @author Diego Andrés Ramírez Aragón
* @copyright Corporación Somos más - 2008
*/

$country = $vars["country"];
if(!empty($country)){
  $states = get_states($country);
  if(!empty($states)){
    $resp = array();
    foreach($states as $state){
      $resp[]="{'code':'{$state->regional_code}','name':'".elgg_echo($state->name)."'}";
    }
    echo "var states=[";
    echo implode(",\n",$resp);
    echo "];";
  }
}
else{
  echo "var states = [];";
}
?>