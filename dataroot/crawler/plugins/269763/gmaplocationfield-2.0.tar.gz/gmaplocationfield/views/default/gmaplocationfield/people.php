<?php
/**
*
* @author Diego Andrés Ramírez Aragón
* @copyright Corporación Somos más - 2008
*/

?>
ajaxLoad(map,myBar,"<?php echo $CONFIG->wwwroot."mod/gmaplocationfield/" ?>data.php?option=people",{cat:"<?php echo elgg_echo('gmap:users') ?>", extendBounds:false});