<?php
/**
*
* @author Diego Andrés Ramírez Aragón
* @copyright Corporación Somos más - 2008
*/

$default_location = get_plugin_setting("default_location","gmaplocationfield");

?>
<style>
</style>
<div id="map-controls">
<?php echo elgg_view("gmaplocationfield/controls");?>
</div>
<div id="map-container" style="overflow: hidden;">
	<div id="map-detail"></div>
</div>
<script type="text/javascript">

//Electronics freaks  know the numbering scheme
var icons = ["black","brown","red","orange","yellow","green","blue","purple","gray","white"];
for(var color in icons){
  tinyImage(icons[color], true);
}

var CAT_ICONS = [];
CAT_ICONS["DEFAULT_ICON"] = tinyIcon("green");
CAT_ICONS["<?php echo elgg_echo('gmap:organizations') ?>"] = tinyIcon("red");

var bounds = new GLatLngBounds();
var allCats = [];

GMap2.prototype.populate = function(points, options){
  var opts = options||{};

  //alert('opts.extendBounds:' + opts.extendBounds+ ", opts.cat" + opts.cat);

  var noCat = true;
  if(opts.cat||opts.iCat) noCat = false;
  var catName = opts.cat||"";
  var bar = opts.sidebar;
  var myCat;
  var newCats = [];
  for (var i=0; i < points.length; i++) {
    if(opts.iCat){ // category from file contents
      catName = points[i].textArray[opts.iCat];
    }
    var theIcon = opts.icon||CAT_ICONS[catName]||CAT_ICONS["DEFAULT_ICON"];
    if(!bar.cats[catName]&&!noCat){ // create a category if not found
      myCat = new BarCategory(bar, catName, {icon:theIcon});
      newCats.push(myCat);
      allCats.push(myCat);
    }
    var iLabel = opts.iLabel||2;
    var label = points[i].textArray[iLabel];
    points[i].marker = new GMarker(points[i],{title:label, icon:theIcon});
    this.addOverlay(points[i].marker);
    var entra = false;
    if (opts.extendBounds)
    {
    	bounds.extend(points[i]); // this must be considered
    	entra = true;
    }

    createInfoWindow(points[i],opts);
    if(noCat){
      bar.addEntry(points[i],opts);
    }else{
      myCat.addEntry(points[i],opts);
    }
  }

  if(myCat) {
  	  myCat.check.checked = opts.checked||false;
	  myCat.update();
  }
  for(var i=0;i<newCats.length;i++){
    newCats[i].check.checked = opts.checked||false;
    newCats[i].update();
  }
  if (entra) {
  	var paddings = {top:30, right:10, bottom:10, left:50};
	this.showBounds(bounds,paddings);
  	this.setZoom(this.getBoundsZoomLevel(bounds) );
  	this.setCenter(bounds.getCenter());
  }
}

jQuery(document).ready(function(){

	// Map loading
	_mPreferMetric=true;                                 //to make size sure for IE too
	var map = new GMap2(document.getElementById("map-detail"), {size:new GSize(700,500)});

<?php if(!empty($default_location)){?>
	var geocoder = new GClientGeocoder();
	geocoder.getLatLng('<?php echo $default_location;?>', function(location){
			if(location){
				map.setCenter(location,12);
			}
		});
<?php }?>
	//map.setCenter(new GLatLng( 4.652598711714066,-74.08009171485901), 12);
	map.addControl(new GLargeMapControl());
	map.addControl(new GMapTypeControl());
	map.addControl(new GScaleControl());
	map.openInfoWindowHtml(map.getCenter(),"Hola.");
	map.closeInfoWindow(); //preloading infowindow
	// End map loading

	// Controls loading
	var myBar = new SideBar(document.getElementById("map-controls"));

	<?php echo elgg_view("gmaplocationfield/controls-js");?>

	// End controls loading
});
</script>