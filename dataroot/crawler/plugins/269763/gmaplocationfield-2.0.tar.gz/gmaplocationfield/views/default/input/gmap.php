<?php

	/**
	 * Elgg gmap input
	 * Displays an interactive GMap input field.
	 *
	 * @author Oscar Lopez - somosmas.org
	 * @author Diego Ramírez  <diego@somosmas.org>
	 * @link http://www.somosmas.org
	 *
	 * @uses $vars['entity'] The entity that would be geolocated
	 *
	 */

// Let everybody knows that google maps is in use
global $gmapinuse,$gmap_key;
$gmapinuse = true;

//@todo agregar la interface para permitir varios puntos
$gmap_key = get_plugin_setting("gmap_key","gmaplocationfield");
if ($gmap_key) {
  $countries = get_countries();
  $empty_set = array("--"=>elgg_echo("gmaplocationfield:choose"));
  $fields = 1;
  //$value = ",";
  if(!empty($vars["entity"])){
    $entity_address = explode("||",$vars["entity"]->location);
    $entity_lats = explode(",",$vars["entity"]->getLatitude());
    $entity_lngs = explode(",",$vars["entity"]->getLongitude());
    $entity_countries = explode(",",$vars["entity"]->country);
    $entity_states = explode(",",$vars["entity"]->state);
    $entity_cities = explode(",",$vars["entity"]->city);
    $fields = count($entity_lats);
  }

  for($i=0;$i<$fields;$i++){
    if(is_array($entity_lats)){
      $value = $entity_lats[$i].",".$entity_lngs[$i];
    }
    $country = $entity_countries[$i];
    $country = (empty($country))?get_plugin_setting("default_country","gmaplocationfield"):$country;

    $state = $entity_states[$i];
    $state = (empty($state))?get_plugin_setting("default_state","gmaplocationfield"):$state;

    $city = $entity_cities[$i];
    $city = (empty($city))?get_plugin_setting("default_city","gmaplocationfield"):$city;

?>

<div id="container_gmap-<?echo $i;?>" style="overflow:hidden;">
  <?php if(get_plugin_setting("show_country","gmaplocationfield")!="no"){?>
  <p>
  <label><?php echo elgg_echo("gmaplocationfield:country");?><br>
  <?php echo elgg_view("input/pulldown",array("internalname"=>"country_gmap-{$i}","options_values"=>$countries));?>
  </label>
  </p>
  <?php } else {
  	echo elgg_view("input/hidden",array("internalname"=>"country_gmap-{$i}","value"=>$country));
  } ?>
  
  <?php if(get_plugin_setting("states","gmaplocationfield")!="no"){?>
  <?php if(get_plugin_setting("show_state","gmaplocationfield")!="no"){?>
  <p>
  <label><?php echo elgg_echo("gmaplocationfield:state");?><br>
  <?php echo elgg_view("input/pulldown",array("internalname"=>"state_gmap-{$i}","options_values"=>$empty_set));?>
  </label>
  </p>
  <?php } else {
  	  echo elgg_view("input/hidden",array("internalname"=>"state_gmap-{$i}","value"=>$state));	
  	}
  }?>

  <?php if(get_plugin_setting("cities","gmaplocationfield")!="no"){?>
  <?php if(get_plugin_setting("show_city","gmaplocationfield")!="no"){?>
  <p>
  <label><?php echo elgg_echo("gmaplocationfield:city");?><br>
  <?php echo elgg_view("input/pulldown",array("internalname"=>"city_gmap-{$i}","options_values"=>$empty_set));?>
  </label>
  </p>
  <?php } else {
  	  echo elgg_view("input/hidden",array("internalname"=>"city_gmap-{$i}","value"=>$city));	
  	}
  }?>
  <p>
  <label><?php echo elgg_echo("gmaplocationfield:address");?><br>
  <?php echo elgg_view("input/text",array("internalname"=>"address_gmap-{$i}","value"=>$entity_address[$i]));?>
  </label>
  </p>

  <div id="div_gmap-<?echo $i;?>" ></div>
  <input type="hidden" name="gmap-<?echo $i;?>" id="gmap-<?echo $i;?>" value="<?php echo $value; ?>" />
  <script type="text/javascript">
  jQuery(document).ready(function(){
	var statesPreloaded<?php echo $i?>=false;
	var geocode<?echo $i;?> = ('<?php echo $value?>'==',' || '<?php echo $value?>'=='');
	var geocode_country<?echo $i;?> = ('<?php echo $country?>'!='' && '<?php echo $country?>'!='--' && geocode<?echo $i;?>);
	var geocode_state<?echo $i;?> = ('<?php echo $state?>'!='' && '<?php echo $state?>'!='--' && geocode<?echo $i;?>);
	var geocode_city<?echo $i;?> = ('<?php echo $city?>'!='' && '<?php echo $city?>'!='--' && geocode<?echo $i;?>);

	
	jQuery("[name=state_gmap-<?php echo $i;?>]").ajaxComplete(function(event){
	  jQuery("[name=city_gmap-<?php echo $i;?>]").val('<?php echo $city;?>');
	  if(geocode_city<?echo $i;?>){
	    gmaplocationfield_load_address('gmap-<?php echo $i;?>');
	  }
	});

    jQuery("[name=country_gmap-<?php echo $i;?>]").val('<?php echo $country;?>');
	jQuery("[name=country_gmap-<?php echo $i;?>]").ajaxComplete(function(event){
	  if(!statesPreloaded<?php echo $i?> && jQuery("[name=state_gmap-<?php echo $i;?>]").children().size()>1){
		  jQuery("[name=state_gmap-<?php echo $i;?>]").val('<?php echo $state;?>');
		  gmaplocationfield_load_cities('<?php echo $state;?>','gmap-<?php echo $i;?>',geocode_state<?echo $i;?>);
		  statesPreloaded<?php echo $i?> = true;
	  }
	});

	<?php if($value!=',' && $value!=''){?>
	gmaplocationfield_update_marker('gmap-<?php echo $i;?>',GLatLng.fromUrlValue('<?php echo $value;?>'),15);
	<?php }?>
	gmaplocationfield_load_states('<?php echo $country;?>','gmap-<?php echo $i;?>',geocode_country<?echo $i;?>);
  });
  </script>
</div>
<?php
  }
  echo "<input type=\"hidden\" name=\"gmap-count\" id=\"gmap-count\" value=\"$i\" />";

}
?>
