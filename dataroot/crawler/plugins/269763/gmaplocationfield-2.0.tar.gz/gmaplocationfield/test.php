<?php
/**
*
* @author Diego Andrés Ramírez Aragón
* @copyright Corporación Somos más - 2008
*/
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

global $gmapinuse;
$gmapinuse = true;

$area2 = elgg_view_title(elgg_echo('gmap:general:title'));

class Test{
  public $country;
  public $state;
  public $city;
  public $location;
  public $x;
  public $y;

  function getLatitude(){
    return $this->x;
  }

  function getLongitude(){
    return $this->y;
  }
}
$entity = new Test();
$entity->country = "CO,PE";
$entity->state="BOY,";
$entity->city = "15001,";
$entity->location="Algo asgaa || Algo mas";
$entity->x="4.66953842396567,";
$entity->y="-74.0735236265554,";

$area2 .= elgg_view('input/gmap',array("entity"=>$entity));

// Display them in the page
$body = elgg_view_layout("one_column", $area1 . $area2);

// Display page
page_draw(sprintf(elgg_echo('gmap:general:title'),$page_owner->name),$body);

?>