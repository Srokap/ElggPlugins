<?php
/**
 * @author Oscar Lopez - somosmas.org
 * @copyright Corporación Somos más - 2008
 */

// Load Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

global $gmapinuse;
$gmapinuse = true;

$area2 = elgg_view_title(elgg_echo('gmap:general:title'));

$area2 .= elgg_view('gmaplocationfield/general');

// Display them in the page
$body = elgg_view_layout("one_column", $area1 . $area2);

// Display page
page_draw(sprintf(elgg_echo('gmap:general:title'),$page_owner->name),$body);
?>