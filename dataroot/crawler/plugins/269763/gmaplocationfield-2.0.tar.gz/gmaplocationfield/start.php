<?php

/**
 * Google Map widget
 * This plugin allows users to display a Google Map
 *
 * @package MOVITravel
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author MOVI LLC <info@movillc.com>
 * @copyright MOVI LLC 2008
 * @link http://movillc.com/
 */

function gmaplocationfield_init() {
  global $CONFIG;

  $CONFIG->maps_ignore = array ();

  register_page_handler('gmap','gmaplocationfield_page_handler');

  extend_view('page_elements/header', 'gmaplocationfield/header');
  extend_view('page_elements/footer', 'gmaplocationfield/footer');
  extend_view('css', 'gmaplocationfield/css');

  extend_view("gmaplocationfield/controls-js", "gmaplocationfield/people", 1);
  extend_view("gmaplocationfield/controls-js", "gmaplocationfield/groups", 2);

  register_plugin_hook("profile:fields", "profile", "profile_gmap_fields");
  register_plugin_hook("profile:fields", "group", "organization_gmap_fields");

  register_elgg_event_handler("create","user","gmaplocationfield_type_handler");
  register_elgg_event_handler("update","user","gmaplocationfield_type_handler");
  register_elgg_event_handler("create","group","gmaplocationfield_type_handler");
  register_elgg_event_handler("update","group","gmaplocationfield_type_handler");
  register_elgg_event_handler("create","object","gmaplocationfield_type_handler");
  register_elgg_event_handler("update","object","gmaplocationfield_type_handler");

  //run_function_once("gmaplocationfield_update");
  gmaplocationfield_update();
}

function gmaplocationfield_update() {
  global $CONFIG;
  $version = get_plugin_setting("version", "gmaplocationfield");
  switch($version) {
    case "":
    case "1.0":
      try {
        run_sql_script(dirname( __FILE__ )."/sql/geodatabase.sql");
        $cities = scandir(dirname( __FILE__ )."/sql/countries/");
        //@todo Better filter for non accepted files
        $cities = array_diff($cities, array (".", "..", ".svn", "CVS"));
        if (is_array($cities)) {
          foreach ($cities as $city) {
            run_sql_script(dirname( __FILE__)."/sql/countries/{$city}");
          }
        }
        set_plugin_setting("version", "2.0","gmaplocationfield");
      }
      catch(DatabaseException $e) {
        register_error($e->getMessage());
      }
      break;
  }
}

function gmaplocationfield_type_handler($event, $object_type, $object){
  switch($event){
    case "update":
    case "create":
      $fields = get_input("gmap-count",0);
      if($fields>0){
        $field_types = array("country","address");
        $country= $state = $city = $address = array();
        $location  = array();
        $lats = array();
        $lngs = array();
        if(get_plugin_setting("states","gmaplocationfield")!="no"){
          array_push($field_types,"state");
        }
        if(get_plugin_setting("cities","gmaplocationfield")!="no"){
          array_push($field_types,"city");
        }
        for($i=0;$i<$fields;$i++){
          foreach($field_types as $field){
            $item = get_input("{$field}_gmap-{$i}");
            array_push($$field,$item);
          }
          $cords = explode(",",get_input("gmap-{$i}"));
          if(count($cords)==2){
            $lats[] = $cords[0];
            $lngs[] = $cords[1];
          }
        }

        foreach(array("country","state","city","lats","lngs") as $item){
          if(count($$item)>0){
            $$item = (count($$item)>1)?implode(",",$$item):array_pop($$item);
          }
        }
        if(count($address)>0){
          $address = (count($address)>1)?implode("||",$address):array_pop($address);
        }

        if(!empty($country)){
          $object->country=$country;
        }
        if(!empty($state)){
          $object->state = $state;
        }
        if(!empty($city)){
          $object->city = $city;
        }
        if(!empty($address)){
          $object->location=$address;
        }
        if(!empty($lats) && !empty($lngs)){
          $object->setLatLong($lats,$lngs);
        }
      }
      break;
  }
  return true;
}
function organization_gmap_fields($hook, $entity_type, $returnvalue, $params) {
  $fields = array_merge($returnvalue, array ('location'=>'gmap'));
  return $fields;

}
function profile_gmap_fields($hook, $entity_type, $returnvalue, $params) {
  $returnvalue["location"] = "gmap";
  return $returnvalue;
}

function gmaplocationfield_page_handler($page) {
  global $CONFIG;
  if(isset($page[0])){
    switch($page[0]){
      case "general-map":
        include $CONFIG->pluginspath."gmaplocationfield/general.php";
        exit;
        break;
      case "states":
        echo elgg_view("data/states",array("country"=>$page[1]));
        break;
      case "cities":
        echo elgg_view("data/cities",array("state"=>$page[1]));
        break;
    }
  }
  return true;
}

function gmaplocationfield_pagesetup() {
  global $CONFIG;
  if (in_array(get_context(), array ("search","service"))) {
    if (isloggedin()) {
      add_submenu_item(elgg_echo('gmap:general:title'), $CONFIG->wwwroot."pg/gmap/general-map", "a");
    }
  }

}

function get_countries($formatted=true){
  global $CONFIG;
  $query = "SELECT * FROM {$CONFIG->dbprefix}country";
  if(!formatted){
    return get_data($query);
  }
  $result = array();
  $result["--"]=elgg_echo("gmaplocationfield:choose");
  $resp = get_data($query);
  if(!empty($resp)){
    foreach($resp as $country){
      $result[$country->iso2_name] = elgg_echo($country->name);
    }
  }
  return $result;
}

function get_states($country){
  global $CONFIG;
  $query = "SELECT * FROM {$CONFIG->dbprefix}state WHERE country_code='{$country}'";
  return get_data($query);
}

function get_cities($state){
  global $CONFIG;
  $query = "SELECT * FROM {$CONFIG->dbprefix}city WHERE regional_code='{$state}'";
  return get_data($query);
}

function get_city($city_code,$obj=false){
  global $CONFIG;
  $city_code = trim($city_code);
  $query = "SELECT * FROM {$CONFIG->dbprefix}city WHERE city_code='{$city_code}'";
  $object = get_data_row($query);
  if($obj){
    return $object;
  }
  return $object->city_name;
}

function get_state($state_code,$obj=false){
  global $CONFIG;
  $city_code = trim($city_code);
  $query = "SELECT * FROM {$CONFIG->dbprefix}state WHERE regional_code='{$state_code}'";
  $object = get_data_row($query);
  if($obj){
    return $object;
  }
  return $object->name;
}

function get_country($iso2_name,$obj=false){
  global $CONFIG;
  $city_code = trim($city_code);
  $query = "SELECT * FROM {$CONFIG->dbprefix}country WHERE iso2_name='{$iso2_name}'";
  $object = get_data_row($query);
  if($obj){
    return $object;
  }
  return $object->name;
}

register_elgg_event_handler('init', 'system', 'gmaplocationfield_init');
register_elgg_event_handler('pagesetup', 'system', 'gmaplocationfield_pagesetup');
register_action('gmaplocationfield/modify', false, $CONFIG->pluginspath."gmaplocationfield/actions/modify.php");
?>
