<?php
/**
         * Elgg powered plugin
         * 
         * @package
         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author psy (lorea)
         * @copyright lorea
         * @link http://lorea.cc
         */
?>
       <br />
        <center>
                 <img src="<?php echo $vars['url']; ?>mod/powered/graphics/tsl-powered.png" border="0" />
		 <img src="<?php echo $vars['url']; ?>mod/powered/graphics/rss-powered.png" border="0" />
		 <img src="<?php echo $vars['url']; ?>mod/powered/graphics/openid-powered.png" border="0" />
		 <img src="<?php echo $vars['url']; ?>mod/powered/graphics/atom-powered.png" border="0" />
		 <img src="<?php echo $vars['url']; ?>mod/powered/graphics/pubsub-powered.png" border="0" />
		 <img src="<?php echo $vars['url']; ?>mod/powered/graphics/foaf-powered.png" border="0" />
	         <img src="<?php echo $vars['url']; ?>mod/powered/graphics/gpg-powered.png" border="0" />
		 <img src="<?php echo $vars['url']; ?>mod/powered/graphics/activitystreams-powered.png" border="0" />
		<!-- <img src="<?php echo $vars['url']; ?>mod/powered/graphics/rdf-powered.png" border="0" />-->
  		<!-- <img src="<?php echo $vars['url']; ?>mod/powered/graphics/oauth-powered.png" border="0" />-->
		<!-- <img src="<?php echo $vars['url']; ?>mod/powered/graphics/omb-powered.png" border="0" />-->
		<!-- <img src="<?php echo $vars['url']; ?>mod/powered/graphics/listserv-powered.png" border="0" />-->
  		<!-- <img src="<?php echo $vars['url']; ?>mod/powered/graphics/xmmp-powered.png" border="0" />-->
        </center>
       <br />
