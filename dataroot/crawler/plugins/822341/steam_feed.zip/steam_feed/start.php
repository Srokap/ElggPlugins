<?php
  
  error_reporting(E_ALL);
  ini_set('display_errors', 'on');
  
  // Steam User Information Plugin
  // start.php
  
  // call the init function for this plugin
  function steam_feed_init() {
      add_widget_type('steam_feed', 'Steam Feed', 'This plugin gets user information from their Steam profile.');
  }
  
  // get the xml feed from Xfire and return the object storing the xml data
  function get_steam_feed($custom_url) {
      $steam_url = 'http://steamcommunity.com/id/' . $custom_url .'/?xml=1';
      $cfile = curl_init($steam_url);
      curl_setopt($cfile, CURLOPT_HEADER, 0);
      curl_setopt($cfile, CURLOPT_RETURNTRANSFER, true);
      $xml_doc = curl_exec($cfile) ;
      curl_close($cfile);
      
      return $xml_doc;
  }
  
  // parse the xml data and check for errors (if the user doesn't have information entered for a specific feed_type')
  function parse_steam_xml($xml_doc) {
      $user_data = new SimpleXMLElement($xml_doc);
      
      if($user_data) {
          $error_data = $user_data->xpath('error');
          if($error_data) {
              echo array_pop($error_data);
              return FALSE; 
          } else {
              return $user_data; 
          }
      } else {
          echo 'There was no user data found';
          return FALSE;
      }
       
  }
  
  register_elgg_event_handler('init', 'system', 'steam_feed_init');
  