<?php
  
  error_reporting(E_ALL);
  ini_set('display_errors', 'on');
  
  // View when the user selects User Profile
  // view_user_profile.php
  
  $widget = $vars['entity'];
  $custom_url = $widget->custom_url;
  
  // if we have the username and feed_type, then get the data that the user requested
  if($custom_url) {
      $xml_doc = get_steam_feed($custom_url);
      $user_data = parse_steam_xml($xml_doc);
      
      if($user_data) {
          //create the view in the widget
          $steam_id_64 = array_pop($user_data->xpath('/profile/steamID64'));
          echo '<b>' . array_pop($user_data->xpath('/profile/steamID')) . '</b><br />';
          
          $avatar_medium = array_pop($user_data->xpath('/profile/avatarMedium'));
          echo '<img src="' . $avatar_medium . '" alt="My Avatar" /><br />';
          
          if(($real_name = array_pop($user_data->xpath('/profile/realname'))) != '') {
              echo '<u>Real Name:</u> ' . $real_name . '<br />';
          }
          if($online_state = array_pop($user_data->xpath('/profile/onlineState'))) {
              echo '<u>Online Status:</u> ' . $online_state . '<br />';
          }
          if(($steam_rating = array_pop($user_data->xpath('/profile/steamRating'))) != '') {
              echo '<u>Steam Rating:</u> ' . $steam_rating . '<br />';
          }
          if(($hours_played_this_week = array_pop($user_data->xpath('/profile/hoursPlayed2Wk'))) != '') {
              echo '<u>Hours Played This Week:</u> ' . $hours_played_this_week . '<br />';
          }
          if(($summary = array_pop($user_data->xpath('/profile/summary'))) != '') {
              echo '<u>Summary:</u> ' . $summary . '<br />';
          }
          if($weblinks = array_pop($user_data->xpath('/profile/weblinks'))) {
              echo '<br /><b>Weblinks</b>';
              $weblinks = $user_data->xpath('/profile/weblinks/weblink');
              foreach ( $weblinks as $weblink) {
                  // get the variables for the weblinks part of the view
                  $weblink_title = array_pop($weblink->xpath('title'));
                  $weblink_link = array_pop($weblink->xpath('link'));
                  // display the weblinks
                  echo '<br /><br /><a href="' . $weblink_link . '"><u>' . $weblink_title . '</u></a>';
              }
          }
      }
  } else {
      echo 'There was a problem with the widget.  Please contact the creator of the widget.';  
  }