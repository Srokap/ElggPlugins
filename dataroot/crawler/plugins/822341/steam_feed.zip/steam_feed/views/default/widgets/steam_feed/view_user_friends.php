<?php

	error_reporting(E_ALL);
	ini_set('display_errors', 'on');

	// Creates the view when the user selects the Friends option
	// view_user_friends.php
	
	$widget = $vars['entity'];
	$custom_url = $widget->custom_url;

	if($custom_url) {
		$xml_doc = get_steam_feed($custom_url);
		$user_data = parse_steam_xml($xml_doc);
		
		$total_friends = count($user_data->xpath('/profile/friends/friend'));
		$online_friends = count($user_data->xpath('/profile/friends/friend[onlineState="online"]'));
		echo '<h2>Currently ' . $online_friends . ' out of ' . $total_friends . ' friends online.</h2>';
        
		$rows = $user_data->xpath('/profile/friends/friend[onlineState="online"]');
		foreach($rows as $friend) {
            // build up the information that is passed to the elgg_view_listing() function
            $friend_avatar_icon = '<img src="' . array_pop($friend->xpath('avatarMedium')) . '" alt="Friend Avatar" />';
            $info = '';
            
			$friend_steam_id = array_pop($friend->xpath('steamID'));
			$info .= '<b>' . $friend_steam_id . '</b><br />';
            
			$friend_online_state = array_pop($friend->xpath('onlineState'));
			$info .= '<u>Online State:</u> ' . $friend_online_state;
            
            // display all of the information for a friend
            echo elgg_view_listing($friend_avatar_icon, $info);
		}
	} else {
      echo 'There was a problem with the widget.  Please contact the creator of the widget.';  
    }
