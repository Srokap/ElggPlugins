<p>Custom URL Extension: 
<?php
  
  error_reporting(E_ALL);
  ini_set('diplay_errors', 'on');
  
  // The dropdown menu of options when the user clicks 'EDIT' on the plugin
  // edit.php
  
  
  //This is an instance of the ElggWidget class that represents our widget.
    $widget = $vars['entity'];
 
    // Give the user a plain text box to input a username
    echo elgg_view('input/text', array(
        'internalname' => 'params[custom_url]', 
        'value' => $widget->custom_url,
        'class' => 'steam-input-text'
    )); 
?>
</p>
<p>Type of Feed:  
<?php
 
    // Give the user a drop down menu to set the type of feed to display
    echo elgg_view('input/pulldown', array(
        'internalname' => 'params[steam_feed_type]', 
        'value' => $widget->steam_feed_type,
        'options_values'=> array(
                'user_profile' => 'User Profile',
                'user_friends' => 'Friends',
                'user_fav_games' => 'Most Played Games',
                )
        )
    );
?>
</p>