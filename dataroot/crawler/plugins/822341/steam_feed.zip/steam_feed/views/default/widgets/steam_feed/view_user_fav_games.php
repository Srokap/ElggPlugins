<?php
  
  // View when the user selects Most Played Games
  // view_user_fav_games.php
  
  $widget = $vars['entity'];
  $custom_url = $widget->custom_url;
  
  // if we have the username and feed_type, then get the data that the user requested
  if($custom_url) {
      $xml_doc = get_steam_feed($custom_url);
      $user_data = parse_steam_xml($xml_doc);
      
      if($user_data) {
          //create the view in the widget
          echo '<h2>Most Played Games</h2>';
          if($games = $user_data->xpath('/profile/mostPlayedGames')) {
              $games = $user_data->xpath('/profile/mostPlayedGames/mostPlayedGame');
              foreach ( $games as $game) {
                  // get all of the info for the game
                  $game_title = array_pop($game->xpath('gameName'));
                  $game_link = array_pop($game->xpath('gameLink'));
                  $game_title_with_link = '<a href="' . $game_link . '">' . $game_title . '</a>';
                  
                  $game_icon = '<img src="' . array_pop($game->xpath('gameIcon')) . '" />';
                  $game_hours_played_week = array_pop($game->xpath('hoursPlayed'));
                  $game_hours_played_total = array_pop($game->xpath('hoursOnRecord'));
                  
                  $info = $game_title_with_link . '<br /><u>Hours Played This Week:</u> ' . $game_hours_played_week . '<br /><u>Total Hours Played:</u> ' . $game_hours_played_total;
                  // display the info for the game
                  echo elgg_view_listing($game_icon, $info);
              }
          } else {
              echo 'This user does not have any Most Played Games.';
          }
      }
  } else {
      echo 'There was a problem with the widget.  Please contact the creator of the widget.';
  }
