<?php
  
  error_reporting(E_ALL);
  ini_set('display_errors', 'on');
  
  // View Handler for the different views available
  // view.php
  
  
  echo '<div class="contentWrapper">';
  require(dirname(__FILE__) . '/view_' . $vars['entity']->steam_feed_type . '.php');
  echo '</div>';
