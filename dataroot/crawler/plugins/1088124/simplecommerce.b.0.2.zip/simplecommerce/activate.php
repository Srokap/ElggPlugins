<?php
/**
* Register the Elggsimplecommerce class for the object/simplecommerce subtype
*/
if(get_subtype_id('object','simplecommerce')){
	update_subtype('object','simplecommerce','simplecommerce');
}else{
	add_subtype('object','simplecommerce','simplecommerce');
}
?>