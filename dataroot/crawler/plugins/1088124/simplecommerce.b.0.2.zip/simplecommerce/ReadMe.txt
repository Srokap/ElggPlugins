- - -
# README
- - -

## Package Details:

* Package Name:
        Embrache_SimpleCommerce
* Description
		Enables Simple eCommerce for Elgg sites.
* Author:
        Dhrup Chand 
        http://Team.EmbrachE.Com
            BSc(Comp), 
            MSc(Comp), 
            Dip.Bus.Admin, 
            U.T.S. 
            Sydney, 
            Australia.
* Version:
        1.8.6.0_2012_MM_DD#B0.2
* Copyright
        (c) Dhrup Chand 2012-2012
        (c) EmbrachE.Com 2012-2012
* License:
        GNU Public License Version 2

## Features:

* Enables Simple eCommerce for Elgg sites.
* Version is Beta 0.1 !! Soo.. not production-ready..
  Provide your feedback to help evolve this into a fully-blown PlugIn.

## TODOs:

* TODO1: ..

## Dedication:

This Software is been inspired by & dedicated to the Elgg Social Networking Platform -
the team and all Third Party Developers who cause the world to evolve around the axis,
for... without all those 3rd-party plugins - Elgg would be nothing!

- - -
README::END
