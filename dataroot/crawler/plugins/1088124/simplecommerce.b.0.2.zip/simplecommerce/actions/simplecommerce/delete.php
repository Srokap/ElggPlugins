<?php
/**
* Delete simplecommerce entity
*
* @package simplecommerce
*/
$simplecommerce_guid = get_input('guid');
$simplecommerce = get_entity($simplecommerce_guid);
if (elgg_instanceof($simplecommerce, 'object', 'simplecommerce') && $simplecommerce->canEdit()) {
	$container = get_entity($simplecommerce->container_guid);
	if ($simplecommerce->delete()) {
		system_message(elgg_echo('simplecommerce:message:deleted_post'));
		if (elgg_instanceof($container, 'group')) {
			forward("simplecommerce/group/$container->guid/all");
		} else {
			forward("simplecommerce/owner/$container->username");
		}
	} else {
		register_error(elgg_echo('simplecommerce:error:cannot_delete_post'));
	}
} else {
	register_error(elgg_echo('simplecommerce:error:post_not_found'));
}
forward(REFERER);
?>