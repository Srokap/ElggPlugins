<?php
/**
 * Deregister the Elggsimplecommerce class
 */

update_subtype('object', 'simplecommerce');
