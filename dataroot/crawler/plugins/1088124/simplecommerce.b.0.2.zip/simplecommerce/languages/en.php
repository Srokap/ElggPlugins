<?php
/**
* Embrache SimpleCommerce
* English Language
*
*/
$EmbracheSimpleCommerceEnglish = array(
	'simplecommerce' => 'SimpleCommerce',
	//'simplecommerce:simplecommerces' => 'Commerce Simple',
	'simplecommerce:simplecommerces' => 'Commerce',
	'simplecommerce:revisions' => 'Revisions',
	'simplecommerce:archives' => 'Archives',
	'simplecommerce:simplecommerce' => 'Simple Commerce',
	'item:object:simplecommerce' => 'Simple Commerce',
	'simplecommerce_prodtitle' => 'Product Title',
	'simplecommerce:title:user_simplecommerces' => '%s\'s Commerce',
	'simplecommerce:title:all_simplecommerces' => 'All site Simple Commerce',
	'simplecommerce:title:friends' => 'Friends\' Simple Commerce',
	'simplecommerce:group' => 'Group Simple Commerce',
	'simplecommerce:enablesimplecommerce' => 'Enable Group Simple Commerce',
	'simplecommerce:write' => 'Write a Simple Commerce Posting',
	// Editing
	'simplecommerce:add' => 'Add Commerce Product',
	'simplecommerce:edit' => 'Edit Commerce Posting',
	'simplecommerce:category' => 'Category',
	'simplecommerce:excerpt' => 'Summary',
	'simplecommerce:body' => 'Description & Pictures',
	'simplecommerce:notes' => 'Notes',
	'simplecommerce:price' => 'Unit Price',
	'simplecommerce:shipcost' => 'Shipping',
	'simplecommerce:currency' => 'Currency',
	'simplecommerce:weight' => 'Weight',
	'simplecommerce:shippingweight' => 'Shipping Weight',

	'simplecommerce:biddable' => 'Biddable',
	'simplecommerce:reviews' => 'Reviews',
	'simplecommerce:save_status' => 'Last saved: ',
	'simplecommerce:never' => 'Never',
	'simplecommerce:bidnow' => 'Make Bid',
	'simplecommerce:buynow' => 'Buy Now',
	'simplecommerce:addcart' => 'Add to Cart',
	'simplecommerce:featured' => 'Make Featured',
	// Statuses
	'simplecommerce:status' => 'Status',
	'simplecommerce:status:draft' => 'Draft',
	'simplecommerce:status:published' => 'Published',
	'simplecommerce:status:unsaved_draft' => 'Unsaved Draft',
	'simplecommerce:revision' => 'Revision',
	'simplecommerce:auto_saved_revision' => 'Auto Saved Revision',
	// messages
	'simplecommerce:message:saved' => 'Simple Commerce Posting saved.',
	'simplecommerce:error:cannot_save' => 'Cannot save Simple Commerce Posting.',
	'simplecommerce:error:cannot_write_to_container' => 'Insufficient Permission to save Simple Commerce to Group.',
	'simplecommerce:error:posting_not_found' => 'This posting has been removed, is invalid, or you do not have permission to view it.',
	'simplecommerce:messages:warning:draft' => 'There is an unsaved draft of this posting!',
	'simplecommerce:edit_revision_notice' => '(Old version)',
	'simplecommerce:message:deleted_posting' => 'Simple Commerce posting deleted.',
	'simplecommerce:error:cannot_delete_posting' => 'Cannot delete Simple Commerce Posting.',
	'simplecommerce:none' => 'No Commerce postings',
	'simplecommerce:error:missing:title' => 'Please enter a Simple Commerce title!',
	'simplecommerce:error:missing:description' => 'Please enter the body of your Simple Commerce!',
	'simplecommerce:error:cannot_edit_posting' => 'This posting may not exist or you may not have permissions to edit it.',
	'simplecommerce:error:revision_not_found' => 'Cannot find this revision.',
	// river
	'river:create:object:simplecommerce' => '%s published a Simple Commerce posting %s',
	'river:comment:object:simplecommerce' => '%s reviewed Simple Commerce %s',
	// notifications
	'simplecommerce:newposting' => 'A new Simple Commerce posting',
	// widget
	'simplecommerce:widget:description' => 'Display your latest Simple Commerce postings',
	'simplecommerce:moresimplecommerces' => 'More Simple Commerce postings',
	'simplecommerce:numbertodisplay' => 'Number of Simple Commerce postings to display',
	'simplecommerce:nosimplecommerces' => 'No Simple Commerce postings'
);
add_translation('en', $EmbracheSimpleCommerceEnglish);
?>