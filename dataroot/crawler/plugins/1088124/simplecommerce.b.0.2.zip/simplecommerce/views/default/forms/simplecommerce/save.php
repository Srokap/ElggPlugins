<?php
/**
* Edit simplecommerce form
*
* @package simplecommerce
*/
$simplecommerce = get_entity($vars['guid']);
$vars['entity'] = $simplecommerce;
// draft warning
$draft_warning = $vars['draft_warning'];
if ($draft_warning) {
	$draft_warning = '<span class="message warning">' . $draft_warning . '</span>';
}
// action buttons
$action_buttons = '';
$delete_link = '';
$preview_button = '';
if ($vars['guid']) {
	// add a delete button if editing
	$delete_url = "action/simplecommerce/delete?guid={$vars['guid']}";
	$delete_link = elgg_view('output/confirmlink', array(
		'href' => $delete_url,
		'text' => elgg_echo('delete'),
		'class' => 'elgg-button elgg-button-delete elgg-state-disabled float-alt'
	));
}
// published simplecommerces do not get the preview button
if (!$vars['guid'] || ($simplecommerce && $simplecommerce->status != 'published')) {
	$preview_button = elgg_view('input/submit', array(
		'value' => elgg_echo('preview'),
		'name' => 'preview',
		'class' => 'mls',
	));
}
//
$save_button = elgg_view('input/submit', array(
	'value' => elgg_echo('save'),
	'name' => 'save',
));
//non-owners only
$bidnow_button = elgg_view('input/submit', array(
	'value' => elgg_echo('simplecommerce:bidnow'),
	'name' => 'bidnow',
	//'class' => 'mls',
));
$buynow_button = elgg_view('input/submit', array(
	'value' => elgg_echo('simplecommerce:buynow'),
	'name' => 'buynow',
	//'class' => 'mls',
));
$action_buttons = $save_button . $preview_button . $delete_link;// . $buynow_button;

//?$categories_input = elgg_view('input/categories', $vars);
//mod/simplecommerce/categorylist.php
// CCCCCCCC category..name..
$CatOptions=array(
	'CatSqr' => 'Simple Category 1 Square',
	'CatCir' => 'Simple Category 2 Circle',
	'CatTri' => 'Simple Category 3 Triangle',
	'CatMore' => 'Add Your Categories Here',
);
$vars['prodcateg']='CatSqr';
$prodcateg_label = 'Product '.elgg_echo('simplecommerce:category');
$prodcateg_input = elgg_view('input/dropdown', array(
	'name' => 'prodcateg',
	'id' => 'simplecommerce_prodcateg',
	'value' => $vars['prodcateg'],
	'options_values' => $CatOptions,
));
$title_label = elgg_echo('simplecommerce_prodtitle').' (Prod#=GUID) ';
$title_input = elgg_view('input/text', array(
	'name' => 'title',
	'id' => 'simplecommerce_title',
	'value' => $vars['title']
));
$excerpt_label = elgg_echo('simplecommerce:excerpt');
$excerpt_input = elgg_view('input/text', array(
	'name' => 'excerpt',
	'id' => 'simplecommerce_excerpt',
	'value' => html_entity_decode($vars['excerpt'], ENT_COMPAT, 'UTF-8')
));
$body_label = elgg_echo('simplecommerce:body');
$body_input = elgg_view('input/longtext', array(
	'name' => 'description',
	'id' => 'simplecommerce_description',
	'value' => $vars['description']
));
$notes_label = elgg_echo('simplecommerce:notes').'<style>.NotesStyle{height:45px;}</style>';
$notes_input = elgg_view('input/longtext', array(
	'class' => 'NotesStyle',
	'name' => 'notes',
	'id' => 'simplecommerce_notes',
	'value' => $vars['notes']
));
////////////////////////////////////////////////////////////////////////////////////////////////////
//table CurrencyName & CurrencySymbol
//mod/simplecommerce/currencylist.php
// CCC SYMBOL currency..name..
/**
Country	ISO	Currency	Symbol

Israel	ILS	Israeli New Sheqel	₪
United States	USD	United States dollar	$ or US$	₥ / ¢ or c
Pound Sterling	GBP	Pound Sterling	£ or p
**/
$CurrOptions=array(
	'Australia AUD Australian Dollar'=>' AUD $ ',
	'Canada CAD Canadian Dollar'=>' CAD $ ',
	'Dominican Republic DOP Dominican Peso'=>' DOP $ ',
	'Fiji FJD Fijian Dollar'=>' FJD $ ',
	'Hong Kong HKD Hong Kong Dollar'=>' HKD $ ',
	'India INR Indian Rupee'=>' INR <strike>R</strike>s ',
	'Japan JPY Japanese Yen'=>' JPY ¥ ',
	'New Zealand NZD New Zealand Dollar'=>' NZ$ ',
	'Poland PLN Polish złoty'=>' PLN zł ',
	'South Africa ZAR South African Rand'=>' ZAR R ',
	'Switzerland CHF Swiss Franc'=>' CHF ',
	'Thailand THB Thai Baht'=>' THB ฿ ',
	'Zimbabwe ZWL Zimbabwean Dollar'=>' ZWL $ ',
	'ILS Israeli New Sheqel'=>' ILS ₪ ',
	'USD United States Dollar'=>' USD $ ',
	'GBP Pound Sterling'=>' GBP £ ',
);
$vars['currency']='USD United States Dollar';
$currency_label = elgg_echo('simplecommerce:currency').'<style>.CurrFont{font-size:105%;}</style>';
$currency_input = elgg_view('input/dropdown', array(
	'class' => 'CurrFont',
	'name' => 'currency',
	'id' => 'simplecommerce_currency',
	'value' => $vars['currency'],
	'options_values' => $CurrOptions,
));
$price_label = elgg_echo('simplecommerce:price').'<style>.CurrWidth{width:150px;}</style>';
$price_input = elgg_view('input/text', array(
	'class' => 'CurrWidth',
	'name' => 'price',
	'id' => 'simplecommerce_price',
	'value' => $vars['price']
));
$shipcost_label = elgg_echo('simplecommerce:shipcost');
$shipcost_input = elgg_view('input/text', array(
	'class' => 'CurrWidth',
	'name' => 'shipcost',
	'id' => 'simplecommerce_shipcost',
	'value' => $vars['shipcost']
));

//table WeightName & WeightSymbol
//mod/simplecommerce/weightlist.php
// SYMBOL weight..name..
$WtOptions=array(
'Lb'=>'Pound',
'Kg'=>'Kilogram',
);
$weight_label = elgg_echo('simplecommerce:weight');
$weight_input = elgg_view('input/dropdown', array(
	'name' => 'weight',
	'id' => 'simplecommerce_weight',
	'value' => $vars['weight'],
	'options_values' => $WtOptions,
));
$ProdWeight_label = elgg_echo('simplecommerce:shippingweight').'<style>.ShipWidth{width:150px;}</style>';
$ProdWeight_input = elgg_view('input/text', array(
	'class' => 'ShipWidth',
	'name' => 'ProdWeight',
	'id' => 'simplecommerce_ProdWeight',
	'value' => $vars['ProdWeight']
));

////////////////////////////////////////////////////////////////////////////////////////////////////
$save_status = elgg_echo('simplecommerce:save_status');
if ($vars['guid']) {
	$entity = get_entity($vars['guid']);
	$saved = date('F j, Y @ H:i', $entity->time_created);
} else {
	$saved = elgg_echo('simplecommerce:never');
}
$status_label = elgg_echo('simplecommerce:status');
$status_input = elgg_view('input/dropdown', array(
	'name' => 'status',
	'id' => 'simplecommerce_status',
	'value' => $vars['status'],
	'options_values' => array(
		'draft' => elgg_echo('simplecommerce:status:draft'),
		'published' => elgg_echo('simplecommerce:status:published')
	)
));
$biddable_label = elgg_echo('simplecommerce:biddable');
$biddable_input = elgg_view('input/dropdown', array(
	'name' => 'biddable_on',
	'id' => 'simplecommerce_biddable_on',
	'value' => $vars['biddable_on'],
	'options_values' => array('On' => elgg_echo('on'), 'Off' => elgg_echo('off'))
));
$comments_label = elgg_echo('simplecommerce:reviews');
$comments_input = elgg_view('input/dropdown', array(
	'name' => 'comments_on',
	'id' => 'simplecommerce_comments_on',
	'value' => $vars['comments_on'],
	'options_values' => array('On' => elgg_echo('on'), 'Off' => elgg_echo('off'))
));
$tags_label = 'Search '.elgg_echo('tags');
$tags_input = elgg_view('input/tags', array(
	'name' => 'tags',
	'id' => 'simplecommerce_tags',
	'value' => $vars['tags']
));
$access_label = elgg_echo('access');
$access_input = elgg_view('input/access', array(
	'name' => 'access_id',
	'id' => 'simplecommerce_access_id',
	'value' => $vars['access_id']
));

// hidden inputs
$container_guid_input = elgg_view('input/hidden', array('name' => 'container_guid', 'value' => elgg_get_page_owner_guid()));
$guid_input = elgg_view('input/hidden', array('name' => 'guid', 'value' => $vars['guid']));
echo <<<___HTML

$draft_warning
<p><label for="simplecommerce_title">					$title_label </label>$title_input
<!--div style='width:200px;'-->
<p><label for="simplecommerce_prodcateg_label">			$prodcateg_label </label>$prodcateg_input
<!--/div-->
<p><label for="simplecommerce_excerpt">					$excerpt_label </label>$excerpt_input

<p><label for="simplecommerce_currency">				$currency_label </label>$currency_input
<label for="simplecommerce_price">						$price_label </label>$price_input
<label for="simplecommerce_shipcost">					$shipcost_label </label>$shipcost_input

<p><label for="simplecommerce_weight">					$weight_label </label>$weight_input
<label for="simplecommerce_ProdWeight">					$ProdWeight_label </label>$ProdWeight_input
<p>
<p><label for="simplecommerce_description">				$body_label </label>$body_input
<p><label for="simplecommerce_notes">					$notes_label </label>$notes_input
<br>
<p><label for="simplecommerce_status">					$status_label </label>$status_input

<p><label for="simplecommerce_tags">					$tags_label </label>$tags_input

<p><label for="simplecommerce_biddable_on">				$biddable_label </label>$biddable_input
	<label for="simplecommerce_comments_on">			$comments_label </label>$comments_input
	<label for="simplecommerce_access_id">				$access_label </label>$access_input

<div class="elgg-foot">
<div class="elgg-subtext mbm">
$guid_input
$container_guid_input
$action_buttons

<p>$save_status <span class="simplecommerce-save-status-time">$saved. </span>

</div>
</div>
___HTML;
?>