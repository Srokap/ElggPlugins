<?php
/**
* View for simplecommerce objects
*
* @package simplecommerce
*/
$full = elgg_extract('full_view', $vars, FALSE);
$simplecommerce = elgg_extract('entity', $vars, FALSE);
if (!$simplecommerce) {
	return TRUE;
}
$owner = $simplecommerce->getOwnerEntity();
$container = $simplecommerce->getContainerEntity();
$categories = elgg_view('output/categories', $vars);
$excerpt = $simplecommerce->excerpt;
$owner_icon = elgg_view_entity_icon($owner, 'tiny');
$owner_link = elgg_view('output/url', array(
	'href' => "simplecommerce/owner/$owner->username",
	'text' => $owner->name,
	'is_trusted' => true,
));
$author_text = elgg_echo('byline', array($owner_link));
$tags = elgg_view('output/tags', array('tags' => $simplecommerce->tags));
$date = elgg_view_friendly_time($simplecommerce->time_created);
// The "on" status changes for comments, so best to check for !Off
if ($simplecommerce->comments_on != 'Off') {
	$comments_count = $simplecommerce->countComments();
	//only display if there are commments
	if ($comments_count != 0) {
		$text = elgg_echo("comments") . " ($comments_count)";
		$comments_link = elgg_view('output/url', array(
			'href' => $simplecommerce->getURL() . '#simplecommerce-comments',
			'text' => $text,
			'is_trusted' => true,
		));
	} else {
		$comments_link = '';
	}
} else {
	$comments_link = '';
}
$metadata = elgg_view_menu('entity', array(
	'entity' => $vars['entity'],
	'handler' => 'simplecommerce',
	'sort_by' => 'priority',
	'class' => 'elgg-menu-hz',
));
$subtitle = "$author_text $date $comments_link $categories";
// do not show the metadata and controls in widget view
if (elgg_in_context('widgets')) {
	$metadata = '';
}
//for non-owners only
$bidnow_button = elgg_view('input/submit', array(
	'value' => elgg_echo('simplecommerce:bidnow'),
	'name' => 'bidnow',
	//'class' => 'mls',
));
$buynow_button = elgg_view('input/submit', array(
	'value' => elgg_echo('simplecommerce:buynow'),
	'name' => 'buynow',
	//'class' => 'mls',
));
$addcart_button = elgg_view('input/submit', array(
	'value' => elgg_echo('simplecommerce:addcart'),
	'name' => 'addcart',
	//'class' => 'mls',
));
$featured_button = elgg_view('input/submit', array(
	'value' => elgg_echo('simplecommerce:featured'),
	'name' => 'featured',
	//'class' => 'mls',
));
$action_buttons = $buynow_button. $addcart_button. $bidnow_button. $featured_button;
/**
[ BuyNow | AddCart ] 
[ CheckOut ] 
[ Cart ] 
**/
if ($full){
	$body = ''
	."<b>Prod Id# ".$simplecommerce->guid."</b>"
	."<input type='hidden' name='prodnum' value='".$simplecommerce->guid."' >"
	.elgg_view('output/longtext', array(
		'value' => $simplecommerce->description,
		'class' => 'simplecommerce-post',
	))
."<br clear='all'><br>"
//[Font = Courier New]
.$action_buttons
."<br>"
	."<br><pre style='background:E9E1D4; border:solid gray 1px;'>
| ``````````````````````````````````````````````````````````````````````````````````````````````` |
| PRODS TICKER ````````````````` | PAYPAL Amnt2Pay ``````````````` | Simple-Ad-Spots ```````````` |
| Latest Prods Sold, etc         | . Other Customer-related        |                              |
| .............................. |   Data from User Profile        |                              |
| .............................. | > Send to PayPal                |                              |
| .............................. | > PayPal sends back IPN         |                              |
| `````````````````````````````` | > Process IPN data returned     |                              |
| COUPON CODE [Input Goes HERE]  | SUCCESS ``````````````````````` |                              |
| CART ````````````````````````` | . Mark CartItems Prods = 'PAID' |                              |
| Prod1 Title2 Cost1 Qty1  Ext1  | . Prepp`ed @Shipping Items      |                              |
| Prod2 Title2 Cost2 Qty2  Ext2  |                                 |                              |
| . . .                          |                                 |                              |
| ProdN TitleN CostN QtyN  ExtN  |                                 |                              |
| TOTALS                   Ext   |                                 |                              |
</pre>"
;
	$params = array(
		'entity' => $simplecommerce,
		'title' => false,
		'metadata' => $metadata,
		'subtitle' => $subtitle,
		'tags' => $tags,
	);
	$params = $params + $vars;
	$summary = elgg_view('object/elements/summary', $params);
	echo elgg_view('object/elements/full', array(
		'summary' => $summary,
		'icon' => $owner_icon,
		'body' => $body,
	));
} else {
	// brief view
	$params = array(
		'entity' => $simplecommerce,
		'metadata' => $metadata,
		'subtitle' => $subtitle,
		'tags' => $tags,
		'content' => $excerpt,
	);
	$params = $params + $vars;
	$list_body = elgg_view('object/elements/summary', $params);
	echo elgg_view_image_block($owner_icon, $list_body);
}
?>