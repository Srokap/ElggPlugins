<?php
/**
* simplecommerce CSS
*
* @package simplecommerce
*/
?>
/* simplecommerce Plugin */
/* force tinymce input height for a more useful editing / simplecommerce creation area */
form#simplecommerce-post-edit #description_parent #description_ifr {
	height:400px !important;
}