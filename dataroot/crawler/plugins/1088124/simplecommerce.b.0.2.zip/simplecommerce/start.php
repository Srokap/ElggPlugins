<?php
/**
 * Simple Commerce
 *
 * @package simplecommerce
 *
 * @todo
 * - Either drop support for "publish date" or duplicate more entity getter
 * functions to work with a non-standard time_created.
 * - Pingbacks
 * - Notifications
 * - River entry for posts saved as drafts and later published
 */

elgg_register_event_handler('init', 'system', 'simplecommerce_init');

/**
 * Init simplecommerce plugin.
 */
function simplecommerce_init() {

	elgg_register_library('elgg:simplecommerce', elgg_get_plugins_path() . 'simplecommerce/lib/simplecommerce.php');

	// add a site navigation item
	$item = new ElggMenuItem('simplecommerce', elgg_echo('simplecommerce:simplecommerces'), 'simplecommerce/all');
	elgg_register_menu_item('site', $item);

	elgg_register_event_handler('upgrade', 'upgrade', 'simplecommerce_run_upgrades');

	// add to the main css
	elgg_extend_view('css/elgg', 'simplecommerce/css');

	// register the simplecommerce's JavaScript
	$simplecommerce_js = elgg_get_simplecache_url('js', 'simplecommerce/save_draft');
	elgg_register_simplecache_view('js/simplecommerce/save_draft');
	elgg_register_js('elgg.simplecommerce', $simplecommerce_js);

	// routing of urls
	elgg_register_page_handler('simplecommerce', 'simplecommerce_page_handler');

	// override the default url to view a simplecommerce object
	elgg_register_entity_url_handler('object', 'simplecommerce', 'simplecommerce_url_handler');

	// notifications
	register_notification_object('object', 'simplecommerce', elgg_echo('simplecommerce:newpost'));
	elgg_register_plugin_hook_handler('notify:entity:message', 'object', 'simplecommerce_notify_message');

	// add simplecommerce link to
	elgg_register_plugin_hook_handler('register', 'menu:owner_block', 'simplecommerce_owner_block_menu');

	// pingbacks
	//elgg_register_event_handler('create', 'object', 'simplecommerce_incoming_ping');
	//elgg_register_plugin_hook_handler('pingback:object:subtypes', 'object', 'simplecommerce_pingback_subtypes');

	// Register for search.
	elgg_register_entity_type('object', 'simplecommerce');

	// Add group option
	add_group_tool_option('simplecommerce', elgg_echo('simplecommerce:enablesimplecommerce'), true);
	elgg_extend_view('groups/tool_latest', 'simplecommerce/group_module');

	// add a simplecommerce widget
	elgg_register_widget_type('simplecommerce', elgg_echo('simplecommerce'), elgg_echo('simplecommerce:widget:description'), 'profile');

	// register actions
	$action_path = elgg_get_plugins_path() . 'simplecommerce/actions/simplecommerce';
	elgg_register_action('simplecommerce/save', "$action_path/save.php");
	elgg_register_action('simplecommerce/auto_save_revision', "$action_path/auto_save_revision.php");
	elgg_register_action('simplecommerce/delete', "$action_path/delete.php");

	// entity menu
	elgg_register_plugin_hook_handler('register', 'menu:entity', 'simplecommerce_entity_menu_setup');

	// ecml
	elgg_register_plugin_hook_handler('get_views', 'ecml', 'simplecommerce_ecml_views_hook');
}

/**
 * Dispatches simplecommerce pages.
 * URLs take the form of
 *  All simplecommerces:		simplecommerce/all
 *  User's simplecommerces:		simplecommerce/owner/<username>
 *  Friends' simplecommerce:	simplecommerce/friends/<username>
 *  User's archives:			simplecommerce/archives/<username>/<time_start>/<time_stop>
 *  simplecommerce post:		simplecommerce/view/<guid>/<title>
 *  New post:      		 		simplecommerce/add/<guid>
 *  Edit post:       			simplecommerce/edit/<guid>/<revision>
 *  Preview post:    			simplecommerce/preview/<guid>
 *  Group simplecommerce:      	simplecommerce/group/<guid>/all
 *
 * Title is ignored
 *
 * @todo no archives for all simplecommerces or friends
 *
 * @param array $page
 * @return bool
 */
function simplecommerce_page_handler($page) {

	elgg_load_library('elgg:simplecommerce');

	// @todo remove the forwarder in 1.9
	// forward to correct URL for simplecommerce pages pre-1.7.5
	simplecommerce_url_forwarder($page);

	// push all simplecommerces breadcrumb
	elgg_push_breadcrumb(elgg_echo('simplecommerce:simplecommerces'), "simplecommerce/all");

	if (!isset($page[0])) {
		$page[0] = 'all';
	}

	$page_type = $page[0];
	switch ($page_type) {
		case 'owner':
			$user = get_user_by_username($page[1]);
			$params = simplecommerce_get_page_content_list($user->guid);
			break;
		case 'friends':
			$user = get_user_by_username($page[1]);
			$params = simplecommerce_get_page_content_friends($user->guid);
			break;
		case 'archive':
			$user = get_user_by_username($page[1]);
			$params = simplecommerce_get_page_content_archive($user->guid, $page[2], $page[3]);
			break;
		case 'view':
			$params = simplecommerce_get_page_content_read($page[1]);
			break;
		case 'add':
			gatekeeper();
			$params = simplecommerce_get_page_content_edit($page_type, $page[1]);
			break;
		case 'edit':
			gatekeeper();
			$params = simplecommerce_get_page_content_edit($page_type, $page[1], $page[2]);
			break;
		case 'group':
			$params = simplecommerce_get_page_content_list($page[1]);
			break;
		case 'all':
			$params = simplecommerce_get_page_content_list();
			break;
		default:
			return false;
	}

	if (isset($params['sidebar'])) {
		$params['sidebar'] .= elgg_view('simplecommerce/sidebar', array('page' => $page_type));
	} else {
		$params['sidebar'] = elgg_view('simplecommerce/sidebar', array('page' => $page_type));
	}

	$body = elgg_view_layout('content', $params);

	echo elgg_view_page($params['title'], $body);
	return true;
}

/**
 * Format and return the URL for simplecommerces.
 *
 * @param ElggObject $entity simplecommerce object
 * @return string URL of simplecommerce.
 */
function simplecommerce_url_handler($entity) {
	if (!$entity->getOwnerEntity()) {
		// default to a standard view if no owner.
		return FALSE;
	}

	$friendly_title = elgg_get_friendly_title($entity->title);

	return "simplecommerce/view/{$entity->guid}/$friendly_title";
}

/**
 * Add a menu item to an ownerblock
 */
function simplecommerce_owner_block_menu($hook, $type, $return, $params) {
	if (elgg_instanceof($params['entity'], 'user')) {
		$url = "simplecommerce/owner/{$params['entity']->username}";
		$item = new ElggMenuItem('simplecommerce', elgg_echo('simplecommerce'), $url);
		$return[] = $item;
	} else {
		if ($params['entity']->simplecommerce_enable != "no") {
			$url = "simplecommerce/group/{$params['entity']->guid}/all";
			$item = new ElggMenuItem('simplecommerce', elgg_echo('simplecommerce:group'), $url);
			$return[] = $item;
		}
	}

	return $return;
}

/**
 * Add particular simplecommerce links/info to entity menu
 */
function simplecommerce_entity_menu_setup($hook, $type, $return, $params) {
	if (elgg_in_context('widgets')) {
		return $return;
	}

	$entity = $params['entity'];
	$handler = elgg_extract('handler', $params, false);
	if ($handler != 'simplecommerce') {
		return $return;
	}

	if ($entity->canEdit() && $entity->status != 'published') {
		$status_text = elgg_echo("simplecommerce:status:{$entity->status}");
		$options = array(
			'name' => 'published_status',
			'text' => "<span>$status_text</span>",
			'href' => false,
			'priority' => 150,
		);
		$return[] = ElggMenuItem::factory($options);
	}

	return $return;
}

/**
 * Register simplecommerces with ECML.
 */
function simplecommerce_ecml_views_hook($hook, $entity_type, $return_value, $params) {
	$return_value['object/simplecommerce'] = elgg_echo('simplecommerce:simplecommerces');

	return $return_value;
}

/**
 * Upgrade from 1.7 to 1.8.
 */
function simplecommerce_run_upgrades($event, $type, $details) {
	$simplecommerce_upgrade_version = get_plugin_setting('upgrade_version', 'simplecommerces');

	if (!$simplecommerce_upgrade_version) {
		 // When upgrading, check if the Elggsimplecommerce class has been registered as this
		 // was added in Elgg 1.8
		if (!update_subtype('object', 'simplecommerce', 'Elggsimplecommerce')) {
			add_subtype('object', 'simplecommerce', 'Elggsimplecommerce');
		}

		// only run this on the first migration to 1.8
		// add excerpt to all simplecommerces that don't have it.
		$ia = elgg_set_ignore_access(true);
		$options = array(
			'type' => 'object',
			'subtype' => 'simplecommerce'
		);

		$simplecommerces = new ElggBatch('elgg_get_entities', $options);
		foreach ($simplecommerces as $simplecommerce) {
			if (!$simplecommerce->excerpt) {
				$simplecommerce->excerpt = elgg_get_excerpt($simplecommerce->description);
			}
		}

		elgg_set_ignore_access($ia);

		elgg_set_plugin_setting('upgrade_version', 1, 'simplecommerces');
	}
}
?>