Welcomer-1.8.x
==============

Redirects new users to a customized welcome page for Elgg 1.8

Plugin should reside at mod/welcomer