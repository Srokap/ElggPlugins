.welcomer_fieldset {
  border: 2px solid black;
  padding: 10px;
}
