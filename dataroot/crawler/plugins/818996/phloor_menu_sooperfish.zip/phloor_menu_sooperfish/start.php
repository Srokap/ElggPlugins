<?php 
/*****************************************************************************
 * Phloor Menu Sooperfish                                                    *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php

elgg_register_event_handler('init',  'system', 'phloor_menu_sooperfish_init', 2);


/**
 * Phloor Menu Sooperfish Initialization
 */
function phloor_menu_sooperfish_init() {
	/**
	 * LIBRARY
	 * register a library of helper functions
	 */
	$lib_path = elgg_get_plugins_path() . 'phloor_menu_sooperfish/lib/';
	elgg_register_library('phloor-menu-sooperfish-lib', $lib_path . 'phloor_menu_sooperfish.lib.php');
	elgg_load_library('phloor-menu-sooperfish-lib');

	/**
	 * JS
	 */
	$js_url = 'mod/phloor_menu_sooperfish/vendors/SooperFish02/jquery.easing-sooper.js';
	elgg_register_js('jquery-easing-sooper', $js_url, 'head', 700);		
	$js_url = 'mod/phloor_menu_sooperfish/vendors/SooperFish02/jquery.sooperfish.min.js';
	elgg_register_js('sooperfish-lib-js', $js_url, 'head', 710);
	
	elgg_load_js('jquery-easing-sooper');
	elgg_load_js('sooperfish-lib-js');
	
	/**
	 * CSS
	 */
	$css_url = 'mod/phloor_menu_sooperfish/vendors/SooperFish02/sooperfish.css';
	elgg_register_css('sooperfish-lib-css', $css_url, 700);	
	
	$css_url = 'mod/phloor_menu_sooperfish/views/default/phloor_menu_sooperfish/css/sooperfish-default-themes.css';
	elgg_register_css('sooperfish-default-themes', $css_url, 710);
		
	elgg_load_css('sooperfish-default-themes');
	elgg_load_css('sooperfish-lib-css');
	
	// admin view css
	elgg_extend_view('css/admin', 'phloor_menu_sooperfish/css/admin', 900);
	
	/**
	 * Inline CSS
	 * @todo: get rid of it :)
	 */
	elgg_extend_view('page/elements/head', 'phloor_menu_sooperfish/head_extend/js_and_css', 700);
	
	/**
	 * Actions
	 */
	$base = elgg_get_plugins_path() . 'phloor_menu_sooperfish/actions/phloor_menu_sooperfish';
	elgg_register_action('phloor_menu_sooperfish/save', "$base/save.php", 'admin');
	
	/**
	 * Admin Menu
	 */
	elgg_register_admin_menu_item('configure', 'phloor_menu_sooperfish', 'appearance', 500);
	
	/**
	 * Plugin Hooks
	 */
	elgg_register_plugin_hook_handler('phloor_menu_sooperfish_theme_register', 'all', 'phloor_menu_sooperfish_register_standard_themes', 1);
	
	/**
	 * ELGG DEFAULT THEME CSS
	 * SHOULD NOT ALWAYS BE LOADED.
	 */	
	$css_url = 'mod/phloor_menu_sooperfish/views/default/phloor_menu_sooperfish/css/elgg-sooperfish-default-theme.css';
	elgg_register_css('elgg-sooperfish-default-theme', $css_url, 999);	
		
	elgg_load_css('elgg-sooperfish-default-theme');	
}


/**
 * Register standard themes hook
 * 
 * Here the standard themes gets registered to be
 * available for choosing from the 'theme' dropbox 
 * on the 'phloor_menu_sooperfish' settings page.
 * 
 * @param unknown_type $hook
 * @param unknown_type $entity_type
 * @param unknown_type $return_value
 * @param unknown_type $params
 */
function phloor_menu_sooperfish_register_standard_themes($hook, $entity_type, $return_value, $params) {
	$standard_themes = array(
		 "phloor-menu-sooperfish-elgg-default-theme" => elgg_echo("phloor_menu_sooperfish:theme:phloor-menu-sooperfish-elgg-default-theme"),
		 'theme1' => elgg_echo('phloor_menu_sooperfish:theme:theme1'),
		 'theme2' => elgg_echo('phloor_menu_sooperfish:theme:theme2'),
		 'theme3' => elgg_echo('phloor_menu_sooperfish:theme:theme3'),
		 'theme4' => elgg_echo('phloor_menu_sooperfish:theme:theme4'),
	);
	
	$return_value = array_merge($standard_themes, $return_value);
	
	return $return_value;
}

