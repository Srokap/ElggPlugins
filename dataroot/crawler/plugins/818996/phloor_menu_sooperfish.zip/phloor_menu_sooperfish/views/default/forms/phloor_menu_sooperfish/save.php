<?php 
/*****************************************************************************
 * Phloor Menu Sooperfish                                                    *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php
/**
 * 
 */
// get site variable
$site = elgg_get_site_entity();
// prepare variables
$vars = phloor_menu_sooperfish_prepare_vars($site);

$action_buttons = '';

$save_button = elgg_view('input/submit', array(
	'value' => elgg_echo('save'),
	'name' => 'save',
));

$action_buttons = $save_button ;

// form elements setup
$forms = array(
	'layout' => array(
		'theme' => elgg_view('input/phloor_menu_sooperfish/theme-dropdown', array(
			'id' => 'edit-sooperfish-theme',
			'name' => 'sooperfish_theme',
			'value' => $vars['theme'],
			'class' => "form-select",
		)),
		'auto_arrows' => elgg_view('input/checkboxes', array(
			'id' => 'edit-sooperfish-auto-arrows',
			'name' => 'sooperfish_auto_arrows',
			'value' => $vars['auto_arrows'],
			'default' => false,
			'options' => array(
				elgg_echo('phloor_menu_sooperfish:auto_arrows:checkbox:label') => 'true',
			),
		)),
		'dualColumn' => elgg_view('input/text', array(
			'id' => 'edit-sooperfish-dualColumn',
			'name' => 'sooperfish_dualColumn',
			'value' => $vars['dualColumn'],
			'maxlength' => '4',
			'size' => '6',
			'class' => "form-text",
		)),
		'tripleColumn' => elgg_view('input/text', array(
			'id' => 'edit-sooperfish-tripleColumn',
			'name' => 'sooperfish_tripleColumn',
			'value' => $vars['tripleColumn'],
			'maxlength' => '4',
			'size' => '6',
			'class' => "form-text",
		)),
	),
	
	'animation:show' => array(
		'speed_show' => elgg_view('input/text', array(
			'id' => 'edit-sooperfish-speed-show',
			'name' => 'sooperfish_speed_show',
			'value' => $vars['speed_show'],
			'maxlength' => '6',
			'size' => '6',
			'class' => "form-text",
		)),
		'easing_show' => elgg_view('input/phloor_menu_sooperfish/easing-dropdown', array(
			'id' => 'edit-sooperfish-easing-show',
			'name' => 'sooperfish_easing_show',
			'value' => $vars['easing_show'],
			'class' => "form-select",
		)),
		'properties_show' => elgg_view('input/checkboxes', array(
			'id' => 'edit-sooperfish-easing-show',
			'name' => 'sooperfish_properties_show',
			'value' => $vars['properties_show'],
			'default' => array('opacity'),
			'options' => array(
				elgg_echo('phloor_menu_sooperfish:properties_show:fade') => 'opacity',
				elgg_echo('phloor_menu_sooperfish:properties_show:fade:sideways') => 'width',
				elgg_echo('phloor_menu_sooperfish:properties_show:fade:vertical') => 'height',
			),
		)),
	),
	
	'animation:close' => array(
		'speed_close' => elgg_view('input/text', array(
			'id' => 'edit-sooperfish-speed-close',
			'name' => 'sooperfish_speed_close',
			'value' => $vars['speed_close'],
			'maxlength' => '6',
			'size' => '6',
			'class' => "form-text",
		)),
		'easing_close' => elgg_view('input/phloor_menu_sooperfish/easing-dropdown', array(
			'id' => 'edit-sooperfish-easing-close',
			'name' => 'sooperfish_easing_close',
			'value' => $vars['easing_close'],
			'class' => "form-select",
		)),
		'properties_close' => elgg_view('input/checkboxes', array(
			'id' => 'edit-sooperfish-easing-close',
			'name' => 'sooperfish_properties_close',
			'value' => $vars['properties_close'],
			'default' => array('opacity'),
			'options' => array(
				elgg_echo('phloor_menu_sooperfish:properties_close:fade') => 'opacity',
				elgg_echo('phloor_menu_sooperfish:properties_close:fade:sideways') => 'width',
				elgg_echo('phloor_menu_sooperfish:properties_close:fade:vertical') => 'height',
			),
		)),	
		'delay' => elgg_view('input/text', array(
			'id' => 'edit-sooperfish-delay',
			'name' => 'sooperfish_delay',
			'value' => $vars['delay'],
			'maxlength' => '4',
			'size' => '6',
			'class' => "form-text",
		)),
	),
	
);

$content = '';

// view each section
foreach($forms as $section_name => $section) {
	// display section title
	$content .= elgg_view_title(elgg_echo('phloor_menu_sooperfish:form:section:'.$section_name));
	// view each form of a section
	foreach($section as $key => $view) {
		$label = elgg_echo('phloor_menu_sooperfish:'.$key.':label');
		$description = elgg_echo('phloor_menu_sooperfish:'.$key.':description');
		$content .= <<<____HTML
<div class="form-item">
 <label>{$label}</label> {$view}
 <div class="description">{$description}</div>
</div>
____HTML;
	}
}

// display action buttons
$content .=  <<<____HTML
<div class="elgg-foot">
	$action_buttons
</div>
____HTML;

// display content
echo $content;

