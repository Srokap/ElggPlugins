<?php

?>

.phloor-menu-sooperfish-preview {
	position: relative;
	padding:10px 10px 10px 10px;
	background-color:#DDD;
	margin:10px 0 20px 0;
}

.phloor-menu-sooperfish-preview div {
	display: inline-block;
	position: relative;
	padding:10px 10px 10px 10px;
	min-height: 100px;
	width: 100%;
}

.phloor-menu-sooperfish-form {
	padding:10px 0 10px 0;
}

.phloor-menu-sooperfish-form fieldset {
width:100%;
}

.phloor-menu-sooperfish-form  p {
clear:both;
}

.phloor-menu-sooperfish-form  form {
background:#eee;
padding:20px;
float:left;
clear:both;
}

.phloor-menu-sooperfish-form  fieldset {
float:left;
margin-bottom:20px;
}

.phloor-menu-sooperfish-form div.form-item {
padding:0.3em 0;
}
