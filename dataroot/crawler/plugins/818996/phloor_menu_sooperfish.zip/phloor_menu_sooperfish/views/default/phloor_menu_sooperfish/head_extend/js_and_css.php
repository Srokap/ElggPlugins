<?php 
/*****************************************************************************
 * Phloor Menu Sooperfish                                                    *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php 
/**
 * @todo: get rid of the whole file
 * better approach is creating hidden input fields with the settings
 * and then loading it from a javascript file in the footer.
 */
//elgg_load_library('phloor-menu-sooperfish-lib');

// get site variable
$site = elgg_get_site_entity();
// prepare variables
$vars = phloor_menu_sooperfish_prepare_vars($site);

if(!isset($vars['theme']) || empty($vars['theme'])) {
	$vars['theme'] = 'phloor-menu-sooperfish-elgg-default-theme';
}
?>
<style type="text/css">
.z-index-999 { z-index:999; }
</style>
<script type="text/javascript">
$(document).ready(function() {
	<?php
		$site = elgg_get_site_entity();
		$vars = phloor_menu_sooperfish_prepare_vars($site);	
	?>
	
	<?php 
	/* the following statement removes the capability 
	 * to view icons on the 'more' section of the site 
	 * menu for the plugin 'Menuitem for 1.8' */ 
	?>
	$('.elgg-menu-site-more').removeClass('elgg-menu');
	<?php /* END */ ?>
	
	$('.elgg-menu-site-more').removeClass('elgg-menu-site');
	$('.elgg-menu-site-more').removeClass('elgg-menu-site-more');
	
	$('.elgg-menu-site').attr('id', 'elgg-menu-site');
	// remove the css classes so the layout does not override
	//$('#elgg-menu-site').removeClass('elgg-menu');
	$('#elgg-menu-site').removeClass('elgg-menu-site');
	$('#elgg-menu-site').removeClass('elgg-menu-site-default');

	$('#elgg-menu-site').addClass('z-index-999');
	$('#elgg-menu-site').addClass('sf-menu');
	
	// set class for theming
	$('ul.sf-menu').addClass('<?php echo $vars['theme']; ?>');

	// apply sooperfish
	$('ul.sf-menu').sooperfish( {
		hoverClass : 'sfHover',
		dualColumn : <? echo $vars['dualColumn']; /* if a submenu has at least this many items it will be divided in 2 columns */?>, 
		tripleColumn : <? echo $vars['tripleColumn']; /* if a submenu has at least this many items it  will be divided in 3 columns */ ?>,
		delay : <? echo $vars['delay']; /* make sure menus only disappear when intended, 500ms is advised by Jacob Nielsen */ ?>, 
		autoArrows : <? echo $vars['auto_arrows']; ?>,
		<?php 
		// @todo: quote: "thats pretty ugly.."
		if(count($vars['properties_show']) > 0) { 
			$values_string = ' ';
			foreach($vars['properties_show'] as $value) {
				$values_string .= $value." : 'show',";
			}
			
			echo 'animationShow : {';
			  echo substr($values_string, 0, -1); 
			echo '},';
		} 
		?>
		speedShow : <?php echo $vars['speed_show']; ?>,
		easingShow : '<?php echo $vars['easing_show']; ?>',
		<?php 
		// @todo: quote: "thats pretty ugly.."
		if(count($vars['properties_close']) > 0) { 
			$values_string = ' ';
			foreach($vars['properties_close'] as $value) {
				$values_string .= $value." : 'hide',";
			}

			echo 'animationHide : {';
  			echo substr($values_string, 0, -1); 
			echo '},';
		} 
		?>
		speedHide :  <?php echo $vars['speed_close']; ?>,
		easingHide : '<?php echo $vars['easing_close']; ?>'

	});
});
</script>

