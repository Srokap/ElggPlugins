<?php 
/*****************************************************************************
 * Phloor Menu Sooperfish                                                    *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php

// only admins are allowed to see this page
admin_gatekeeper();

$preview_title = elgg_view_title(elgg_echo('phloor_menu_sooperfish:preview'));
$site_menu     = elgg_view_menu('site');

$settings_title = elgg_view_title(elgg_echo('phloor_menu_sooperfish:settings'));
$menu_form      = elgg_view_form('phloor_menu_sooperfish/save', array());

$content = '';

// PREVIEW
$content .= <<<HTML
$preview_title
<div class="phloor-menu-sooperfish-preview">
	<div>$site_menu</div>
</div>
HTML;

// SETTINGS FORM
$content .= <<<HTML
$settings_title
<div class="phloor-menu-sooperfish-form">
	$menu_form
</div>
HTML;

// output content
echo $content;
