<?php 
/*****************************************************************************
 * Phloor Menu Sooperfish                                                    *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php
/**
 * Phloor Menu Sooperfish Language File
 * English
 */

$english = array(
  'admin:plugins:category:PHLOOR' => 'PHLOOR Plugins',
  'admin:appearance:phloor_menu_sooperfish' => 'Site Menu (Sooperfish)',

  'phloor_menu_sooperfish' => 'Main menu (Sooperfish)',

  'phloor_menu_sooperfish:save:success' => 'Settings successfully saved',
  'phloor_menu_sooperfish:save:failure' => 'Could not save settings',

  'phloor_menu_sooperfish:preview' => 'Preview',
  'phloor_menu_sooperfish:settings' => 'Settings',

  'phloor_menu_sooperfish:form:section:layout' => 'Layout',
  'phloor_menu_sooperfish:form:section:animation:show' => 'Show Animation',
  'phloor_menu_sooperfish:form:section:animation:close' => 'Hide Animation',

  'phloor_menu_sooperfish:theme:label' => 'Theme',
  'phloor_menu_sooperfish:theme:description' => 'Choose a suitable theme',

  'phloor_menu_sooperfish:auto_arrows:label' => 'Auto-Arrows',
  'phloor_menu_sooperfish:auto_arrows:description' => 'Should arrows appear on menu items with child items?',
  'phloor_menu_sooperfish:auto_arrows:checkbox:label' => 'Activate Auto-Arrows',

  'phloor_menu_sooperfish:dualColumn:label' => 'Submenu divide (2 column)',
  'phloor_menu_sooperfish:dualColumn:description' => 'If a submenu has at least this many items it will be divided in 2 columns.',

  'phloor_menu_sooperfish:tripleColumn:label' => 'Submenu divide (3 column)',
  'phloor_menu_sooperfish:tripleColumn:description' => 'If a submenu has at least this many items it will be divided in 3 columns.',

  'phloor_menu_sooperfish:speed_show:label' => 'Speed',
  'phloor_menu_sooperfish:speed_show:description' => 'Animation speed in milliseconds. Do not add "ms" to the number.',

  'phloor_menu_sooperfish:easing_show:label' => 'Easing',
  'phloor_menu_sooperfish:easing_show:description' => 'This determines how the animation gains speed.',

  'phloor_menu_sooperfish:properties_show:label' => 'Setup',
  'phloor_menu_sooperfish:properties_show:description' => 'Select the properties you would like to animate.',

  'phloor_menu_sooperfish:speed_close:label' => 'Speed',
  'phloor_menu_sooperfish:speed_close:description' => 'Animation speed in milliseconds. Do not add "ms" to the number.',

  'phloor_menu_sooperfish:easing_close:label' => 'Easing',
  'phloor_menu_sooperfish:easing_close:description' => 'This determines how the animation gains speed.',

  'phloor_menu_sooperfish:properties_close:label' => 'Setup',
  'phloor_menu_sooperfish:properties_close:description' => 'Select the properties you would like to animate.',

  'phloor_menu_sooperfish:delay:label' => 'Delay',
  'phloor_menu_sooperfish:delay:description' => 'Close delay in in milliseconds. Make sure menus only disappear when intended, 500ms is advised. Do not add "ms" to the number.',

  'phloor_menu_sooperfish:properties_show:fade' => 'Fade in',
  'phloor_menu_sooperfish:properties_show:fade:sideways' => 'Fade horizontal',
  'phloor_menu_sooperfish:properties_show:fade:vertical' => 'Fade vertical',

  'phloor_menu_sooperfish:properties_close:fade' => 'Fade out',
  'phloor_menu_sooperfish:properties_close:fade:sideways' => 'Fade horizontal',
  'phloor_menu_sooperfish:properties_close:fade:vertical' => 'Fade vertical',

  'phloor_menu_sooperfish:theme:phloor-menu-sooperfish-elgg-default-theme' => 'Elgg Standard Theme',
  'phloor_menu_sooperfish:theme:theme1' => 'Sooperfish Standard Theme 1',
  'phloor_menu_sooperfish:theme:theme2' => 'Sooperfish Standard Theme 2',
  'phloor_menu_sooperfish:theme:theme3' => 'Sooperfish Standard Theme 3',
  'phloor_menu_sooperfish:theme:theme4' => 'Sooperfish Standard Theme 4',
  'phloor_menu_sooperfish:theme:phloor-menu-sooperfish-phloor-default-theme' => 'Phloor Standard Theme',
);
	
add_translation("en", $english);
