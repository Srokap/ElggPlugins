<?php 
/*****************************************************************************
 * Phloor Menu Sooperfish                                                    *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php
/**
 * Phloor Menu Sooperfish Language File
 * German
 */

$german = array(
  'admin:plugins:category:PHLOOR' => 'PHLOOR Plugins',
  'admin:appearance:phloor_menu_sooperfish' => 'Hauptmenü (Sooperfish)',

  'phloor_menu_sooperfish' => 'Hauptmenü (Scooperfish)',

  'phloor_menu_sooperfish:save:success' => 'Einstellungen gespeichert',
  'phloor_menu_sooperfish:save:failure' => 'Einstellungen konnten nicht gepspeichert werden',

  'phloor_menu_sooperfish:preview' => 'Vorschau',
  'phloor_menu_sooperfish:settings' => 'Einstellungen',

  'phloor_menu_sooperfish:form:section:layout' => 'Layout',
  'phloor_menu_sooperfish:form:section:animation:show' => 'Einblenden',
  'phloor_menu_sooperfish:form:section:animation:close' => 'Ausblenden',

  'phloor_menu_sooperfish:theme:label' => 'Design',
  'phloor_menu_sooperfish:theme:description' => 'Wählen Sie ein geeignetes Design.',

  'phloor_menu_sooperfish:auto_arrows:label' => 'Auto-Arrows',
  'phloor_menu_sooperfish:auto_arrows:description' => 'Bei Aktivierung werden Pfeile bei Menüeinträge mit Kindelementen angezeigt.',
  'phloor_menu_sooperfish:auto_arrows:checkbox:label' => 'Auto-Arrows aktivieren',

  'phloor_menu_sooperfish:dualColumn:label' => '2 Spalten',
  'phloor_menu_sooperfish:dualColumn:description' => 'Wenn ein Untermenü mindestens diese Anzahl at Elementen hat, wird es auf 2 Spalten aufgeteilt.',

  'phloor_menu_sooperfish:tripleColumn:label' => '3 Spalten',
  'phloor_menu_sooperfish:tripleColumn:description' => 'Wenn ein Untermenü mindestens diese Anzahl at Elementen hat, wird es auf 3 Spalten aufgeteilt.',

  'phloor_menu_sooperfish:speed_show:label' => 'Geschwindigkeit',
  'phloor_menu_sooperfish:speed_show:description' => 'Animationsgeschwindigkeit in Millisekunden. Bitte nicht "ms" an die Zahl schreiben.',

  'phloor_menu_sooperfish:easing_show:label' => 'Animation Effekt',
  'phloor_menu_sooperfish:easing_show:description' => 'Die Art udn Weise wie die Animation an Geschwindigkeit zunimmt.',

  'phloor_menu_sooperfish:properties_show:label' => 'Animation Konfiguration',
  'phloor_menu_sooperfish:properties_show:description' => '',


  'phloor_menu_sooperfish:speed_close:label' => 'Geschwindigkeit',
  'phloor_menu_sooperfish:speed_close:description' => 'Animationsgeschwindigkeit in Millisekunden. Bitte nicht "ms" an die Zahl schreiben.',

  'phloor_menu_sooperfish:easing_close:label' => 'Animation Effekt',
  'phloor_menu_sooperfish:easing_close:description' => 'Die Art udn Weise wie die Animation an Geschwindigkeit zunimmt.',

  'phloor_menu_sooperfish:properties_close:label' => 'Animation Konfiguration',
  'phloor_menu_sooperfish:properties_close:description' => '',

  'phloor_menu_sooperfish:delay:label' => 'Verzögerung',
  'phloor_menu_sooperfish:delay:description' => 'Schließverzögerung von Untermenüs in Millisekunden. Bitte nicht "ms" an die Zahl schreiben (sollte > 400 sein).',

  'phloor_menu_sooperfish:properties_show:fade' => 'Einblenden',
  'phloor_menu_sooperfish:properties_show:fade:sideways' => 'Horizontal einblenden',
  'phloor_menu_sooperfish:properties_show:fade:vertical' => 'Vertikal einblenden',

  'phloor_menu_sooperfish:properties_close:fade' => 'Ausblenden',
  'phloor_menu_sooperfish:properties_close:fade:sideways' => 'Horizontal ausblenden',
  'phloor_menu_sooperfish:properties_close:fade:vertical' => 'Vertikal ausblenden',

  'phloor_menu_sooperfish:theme:phloor-menu-sooperfish-elgg-default-theme' => 'Elgg Standard Theme',
  'phloor_menu_sooperfish:theme:theme1' => 'Sooperfish Standard Theme 1',
  'phloor_menu_sooperfish:theme:theme2' => 'Sooperfish Standard Theme 2',
  'phloor_menu_sooperfish:theme:theme3' => 'Sooperfish Standard Theme 3',
  'phloor_menu_sooperfish:theme:theme4' => 'Sooperfish Standard Theme 4',
  'phloor_menu_sooperfish:theme:phloor-menu-sooperfish-phloor-default-theme' => 'Phloor Standard Theme',

);
					
add_translation("de", $german);
