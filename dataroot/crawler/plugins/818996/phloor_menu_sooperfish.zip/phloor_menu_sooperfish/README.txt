/**
 * Phloor Menu Sooperfish
 * 
 * @package phloor_menu_sooperfish
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author void <void@13net.at>
 * @copyright 13net
 * @link http://www.13net.at/
 */
 
Version: 1.8-11.11.21
Requires: Elgg 1.8 or higher


/**
 * Description
 */
This plugin applies the 'SooperFish' menu to the 'site'-menu and enables custom configuration for admins.
SooperFish is an easy to use dropdown-menu plugin with total configuration control and clean code.

Here is a short excerpt from 'http://plugins.jquery.com/project/SooperFish':
Automatic dual or triple columns based on number of child menu items
Optional delay before hiding menu on mouse-out
Optional automatic indicator arrows (in black or white)
Configurable show AND hide animations
Custom easing supported
Works with jQuery backlava plugin (optionally)
Works fine with Javascript disabled
Comes with several free themes to demonstrate styling
3.65kb uncompressed
2.01kb minified

/**
 * Todo:
 * currently all standard theme css rules are loaded
 * this is unnecessary overhead.
 */

/**
 * Languages
 */
English
German

/**
 * Admin Settings
 */
Numerous options for animations, effects or time settings are available.


/**
 * Extendable
 */
triggers the plugin hook 'phloor_menu_sooperfish_theme_register' in theme-dropdown
to hook into and add your own styles!

Like so:
$options_values = elgg_trigger_plugin_hook('phloor_menu_sooperfish_theme_register', 'all', array(), $standard_themes);

The only thing for you to do is to create and provide a css style sheet!
See the plugin 'phloor_menu_sooperfish_theme_theme5' for a demonstration.
