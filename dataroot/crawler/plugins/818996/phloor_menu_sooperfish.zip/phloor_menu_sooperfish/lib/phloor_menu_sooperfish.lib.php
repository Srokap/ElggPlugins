<?php 
/*****************************************************************************
 * Phloor Menu Sooperfish                                                    *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php 

/**
 * Default attributes for the sooperfish menu
 * 
 * @return array with default values
 */
function phloor_menu_sooperfish_default_vars() {
	$defaults = array(
		'auto_arrows'      => 'false',
		'delay'            => 500,
		'dualColumn'       => 6,
		'tripleColumn'     => 8,
		'theme'            => 'phloor-menu-sooperfish-elgg-default-theme',
		'speed_show'       => 500,
		'easing_show'      => 'linear',
		'properties_show'  => array(),
		'speed_close'      => 500,
		'easing_close'     => 'linear',
		'properties_close' => array(),
	);
	
	return $defaults;
}

/**
 * Load vars from post or get requests and returns them as array
 * 
 * @return array with values from the request
 */
function phloor_menu_sooperfish_get_input_vars() {
	$input_var_prefix = 'sooperfish_';
	
	// get default values
	$defaults = phloor_menu_sooperfish_default_vars();
	
	$params = array();
	foreach($defaults as $key => $default_value) {
		$var_name = $input_var_prefix . $key;
		$params[$key] = get_input($var_name, $default_value);
	}
	
	if (!is_array($params['properties_show'])) {
		$params['properties_show'] = array($params['properties_show']);
	}
	if (!is_array($params['properties_close'])) {
		$params['properties_close'] = array($params['properties_close']);
	}
	
	return $params;
}
/**
 * Load vars from given site into and returns them as array
 * 
 * @return array with stored values
 */
function phloor_menu_sooperfish_prepare_vars(ElggSite $site) {
	// get default values
	$defaults = phloor_menu_sooperfish_default_vars();

	$params = array();
	// decode settings if existing
	if(isset($site->phloor_menu_sooperfish_settings)) {
		$params = json_decode($site->phloor_menu_sooperfish_settings, true);
	}
	// merge default with given params
	$vars = array_merge($defaults,  $params);

	if(!is_array($vars['properties_show'])) {
		$vars['properties_show'] = array($vars['properties_show']);
	} 
	if (!is_array($vars['properties_close'])) {
		$vars['properties_close'] = array($vars['properties_close']);
	}
	
	return $vars;
}

/**
 * Load vars from given site into and returns them as array
 * 
 * @return array with stored values
 */
function phloor_menu_sooperfish_save_vars($site, $params = array()) {
	// get default values
	$defaults = phloor_menu_sooperfish_default_vars();
	// merge with params	
	$vars = array_merge($defaults, $params);
	// store as an  json encoded attribute of the site entity
	$site->phloor_menu_sooperfish_settings = json_encode($vars);
	// save site and return status
	return $site->save();
}
