<?php
	/**
	 * Elgg river plugin language pack
	 * 
	 * @package ElggReportedContent
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */
	 
	$german = array(
	
		/**
		 * Manifest
		 */
		
			'river:widget:description' => "Letzte Aktivitäten anzeigen.",
			'river:widget:description:friends' => "Zeigt die Aktivitäten Deiner Kontakte.",
			'river:widget:label:displaynum' => "Anzahl der Einträge, die angezeigt werden sollen:",
			'river:widget:noactivity' => "Keine Aktivitäten.",
			'river:widget:title' => "Deine Aktivitäten",
			'river:widget:title:friends' => "Aktivitäten von Kontakten",

	);
	add_translation('de', $german);

?>