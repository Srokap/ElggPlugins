<?php


$german = array( 
	 'friends:all'  =>  "Alle Kontakte" , 
	 'notifications:subscriptions:personal:description'  =>  "Erhalte Benachrichtigungen, wenn Aktionen an deinem Inhalt durchgeführt worden sind" , 
	 'notifications:subscriptions:personal:title'  =>  "Persönliche Benachrichtigungen" , 
	 'notifications:subscriptions:collections:title'  =>  "Deine Kontakte" , 
	 'notifications:subscriptions:collections:description'  =>  "Infos zu Veränderungen deiner Kontakte:" , 
	 'notifications:subscriptions:collections:edit'  =>  "Um deine Kontaktlisten zu bearbeiten, klicke hier." , 
	 'notifications:subscriptions:changesettings'  =>  "Benachrichtigungen" , 
	 'notifications:subscriptions:changesettings:groups'  =>  "Gruppen-Benachrichtigungen" , 
	 'notification:method:email'  =>  "E-mail" , 
	 'notifications:subscriptions:title'  =>  "Benachrichtigungen zu Deinen Kontakten" , 
	 'notifications:subscriptions:description'  =>  "Um Benachrichtigungen von deinen Kontakten zu erhalten, wenn sich etwas verändert hat, kannst Du hier Deine Kontakte einzeln auswählen." , 
	 'notifications:subscriptions:groups:description'  =>  "Hier kannst Du einstellen, bei welchen Neuigkeiten Deiner Gruppen Du benachrichtigt werden möchtest." , 
	 'notifications:subscriptions:success'  =>  "Deine Benachrichtigungs-Einstellungen wurden gespeichert." ,
); 

add_translation('de',$german); 

?>