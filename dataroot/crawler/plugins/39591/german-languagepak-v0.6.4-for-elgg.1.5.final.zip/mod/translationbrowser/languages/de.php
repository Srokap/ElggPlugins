<?php



$german = array( 
	 'translationbrowser'  =>  "Übersetzungsbrowser" , 
	 'translationbrowser:translate'  =>  "Übersetzen" , 
	 'translationbrowser:selectlanguage'  =>  "Sprache wählen" , 
	 'translationbrowser:selecttypeexport'  =>  "Bitte ein Exportmodus auswählen" , 
	 'translationbrowser:yourselectedlanguage'  =>  "Deine gewählte Sprache" , 
	 'translationbrowser:languagecore'  =>  "- System Sprache" , 
	 'translationbrowser:selectmodule'  =>  "Bitte wähle ein Modul, welches du übersetzen möchtest, dann klicke den \"Übersetzung\" Button." , 
	 'translationbrowser:updatefile'  =>  "Den File intern aktualisieren" , 
	 'translationbrowser:generatefile'  =>  "PHP-File erstellen" , 
	 'translationbrowser:highlight'  =>  "Nicht übersetzte Felder markieren" , 
	 'translationbrowser:canyouedit'  =>  "Du kannst diese Felderinhalte bearbeiten" , 
	 'translationbrowser:blankmodule'  =>  "Du musst wenigstens ein Modul auswählen" , 
	 'translationbrowser:languageerror'  =>  "Die gewählte Sprache ist nicht korrekt. Bitte noch mal versuchen oder eine andere Sprache wählen." , 
	 'translationbrowser:blanklang'  =>  "Du musst wenigstens eine Sprache wählen" , 
	 'translationbrowser:emptyfields'  =>  "Du musst wenigstens ein Feld ausfüllen" , 
	 'translationbrowser:error'  =>  "Interner Fehler. Bitte versuch es später noch mal" , 
	 'translationbrowser:problem:permiss'  =>  "Beim Öffnen des Ordners ist ein Fehler aufgetreten. Bitte überprüfe deine Berechtigungen" , 
	 'translationbrowser:error:filecreate'  =>  "Beim File-Erstellen ist ein Fehler aufgetreten. Bitte überprüfe deine Berechtigungen" , 
	 'translationbrowser:success'  =>  "Die Übersetzung war erfolgreich." , 
	 'translationbrowser:generatedby'  =>  "Generiere vom Übersetzungsbrowser." , 
	 'translationbrowser:save'  =>  "Übersetzen" ,
); 

add_translation('de',$german); 

?>