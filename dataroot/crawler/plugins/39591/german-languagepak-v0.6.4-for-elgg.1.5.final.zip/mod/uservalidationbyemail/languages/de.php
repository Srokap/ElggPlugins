<?php


$german = array( 
	 'email:validate:subject'  =>  "%s bestätige bitte deine E-mail Adresse!" , 
	 'email:validate:body'  =>  "Hi %s, Bitte bestätige deine E-mail Adresse, in dem du auf den folgenden Link klickst: %s" ,
	 'email:validate:success:subject'  =>  "Email ist bestätigt %s!" , 
	 'email:validate:success:body'  =>  "Hi %s, Glückwunsch, du hast deine E-mail Adresse erfolgreich bestätigt." ,
	 'email:confirm:success'  =>  "Du hast deine E-mail Adresse bestätigt!" ,
	 'email:confirm:fail'  =>  "Deine E-mail Adresse konnte nicht bestätigt werden..." , 
	 'uservalidationbyemail:registerok'  =>  "Um dein Account zu aktivieren, bestätige bitte deine E-mail Adresse, in dem du den Link anklickst, den wir dir gerade sendeten." ,
); 

add_translation('de',$german); 

?>