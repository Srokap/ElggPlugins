<?php

	$german = array(
	
		/**
		 * Friends widget
		 */
			'friends:widget:description' => "Zeigt User an die Online sind.",
	        
		
	);
					
	add_translation('de',$german);

?>