<?php

$german = array( 
	 'mine'  =>  "mein" , 
	 'filter'  =>  "Filter" , 
	 'riverdashboard:useasdashboard'  =>  "Ersetze die benutzerdefinierte Aushangtafel mit diesem Aktivitätsfluss!" , 
	 'sitemessages:announcements'  =>  "Ankündigungen der Seite" , 
	 'sitemessages:posted'  =>  "gesendet" , 
	 'sitemessages:river:created'  =>  "Seiten-Administrator, %s," , 
	 'sitemessages:river:create'  =>  "Eine neue umfassende Seiten-Nachricht wurde gesendet." , 
	 'sitemessages:add'  =>  "Füge eine umfassende Seiten-Nachricht in den Fluss der Seite" , 
	 'sitemessage:deleted'  =>  "Seiten-Nachricht wurde gelöscht" , 
	 'river:widget:noactivity'  =>  "Wir konnten keine Aktivität finden." , 
	 'river:widget:title'  =>  "Aktivität" , 
	 'river:widget:description'  =>  "Zeige Deine letzte Aktivität." , 
	 'river:widget:title:friends'  =>  "Aktivität von Kontakten" , 
	 'river:widget:description:friends'  =>  "Zeige, was Deine Kontakte machen." , 
	 'river:widgets:friends'  =>  "Kontakte" , 
	 'river:widgets:mine'  =>  "mein" , 
	 'river:widget:label:displaynum'  =>  "Anzahl der Einträge anzeigen:" , 
	 'river:widget:type'  =>  "Welche Liste möchtest du angezeigt bekommen? Diejenige, die deine Aktivität zeigt oder diejenige, die Aktivität Deiner Kontakte zeigt?" , 
	 'item:object:sitemessage'  =>  "Seiten-Nachrichten" ,
); 

add_translation('de',$german); 

?>