<?php
	/**
	 * iZAP izap profile visitor
	 * 
	 * @license GNU Public License version 3
	 * @author iZAP Team "<support@izap.in>"
	 * @link http://www.izap.in/
	 * @version 1.0
	 * @compatibility elgg-1.5
	 * �bersetzung der deutschen Sprachdatei durch elgg. Member wmage
	 */
$german = array(
		'izapProfileVisitor:Widget' => 'Letzte Profilbesucher',
		'izapProfileVisitor:WidgetDescription' => 'Dieses Widget zeigt Deine letzten Profilbesucher an.',
		'izapProfileVisitor:NumberOfVisitors' => 'Besucher anzeigen',
		'izapProfileVisitor:NoVisits' => ':( Leider keine Besuche.',
);

add_translation("de",$german);
