<?php

/**
 * Elgg newestmembers widget
 *
 * @package newestmembers
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU General Public License version 2
 * @author JBMc
 * @copyright Copyright (c) 2009 Innovative Computer Services & Soltuions
 * @link http://websites.icssinc.com
 *
 *
 * �bersetzung von wmage f�r elgg. 1.5-final - 2009-03-16
 */ 

  $german = array(	
      'newestmembers:num_display' => 'Anzahl Mitglieder anzeigen:',	
      'newestmembers:withpicsonly' => 'Nur Mitglieder mit Bild anzeigen?'
	);
 
  add_translation('de',$german);
 
?>
