<?php

/**
 * Elgg newestmembers widget
 *
 * @package newestmembers
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU General Public License version 2
 * @author JBMc
 * @copyright Copyright (c) 2009 Innovative Computer Services & Soltuions
 * @link http://websites.icssinc.com
 *
 */ 

  $english = array(	
      'newestmembers:num_display' => 'Number of members to display',	
      'newestmembers:withpicsonly' => 'Only display members with profile picture?'
	);
 
  add_translation("en",$english);
 
?>
