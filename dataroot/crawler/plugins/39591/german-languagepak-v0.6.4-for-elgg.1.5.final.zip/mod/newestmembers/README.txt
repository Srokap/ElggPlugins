newestmembers widget

Author: JBMc (elgg@icssinc.com)
Version: 0.3

Description:
This widget basically displays the newest members of your site to your dashboard or profile page.  You can also configure the number of members to display.

Installation:
1. Unzip to your mod directory.
2. Enable in Dashboard (Administration -> Tool Administration)
3. Then in dashboard or profile edit page, drag the Newest Members widget where desired and save.

Changelog:

Date		Version		Description
2009/02/01	v0.1		Initial release
2009/02/02	v0.2		Cleanup of comments.
2009/02/14	v0.3		Added option to display newest members with or without profile pics uploaded.
				Previous versions only displayed newest members with profile pics uploaded.
				
Sprachanpassung f�r DEUTSCH durch wmage f�r elgg. 1.5-final - 2009-03-16
