<?php

/**
 * Elgg newestmembers widget
 *
 * @package newestmembers
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU General Public License version 2
 * @author JBMc
 * @copyright Copyright (c) 2009 Innovative Computer Services & Soltuions
 * @link http://websites.icssinc.com
 *
 */

  function newestmembers_init() {        
    add_widget_type('newmembers', 'Neueste Mitglieder', 'Zeigt die neuesten Mitglieder');
  }
 
  register_elgg_event_handler('init','system','newestmembers_init');       
?>
