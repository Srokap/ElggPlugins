<?php

// Generate By translationbrowser. 

$german = array( 
	 'garbagecollector:period'  =>  "Wie oft soll die Müllsamler laufen" , 
	 'garbagecollector:weekly'  =>  "Einmal pro Woche" , 
	 'garbagecollector:monthly'  =>  "Einmal pro Monat" , 
	 'garbagecollector:yearly'  =>  "Einmal pro Jahr" , 
	 'garbagecollector'  =>  "Müllsamler" , 
	 'garbagecollector:done'  =>  "Fertig" , 
	 'garbagecollector:optimize'  =>  "Optimierung %s" , 
	 'garbagecollector:error'  =>  "Fehler" , 
	 'garbagecollector:ok'  =>  "OK" , 
	 'garbagecollector:gc:metastrings'  =>  "Nicht verlinkte Meta-Zeichenketten bereinigen." ,
);

add_translation('de',$german);

?>