<?php

	$german = array(
	
		/**
		 * Menu items and titles
		 */
	
			'status' => "Status",
			'status:user' => "%s's status",
			'status:current'=> "Aktueller Status",
			'status:desc'=> "Das Status Widget zeigt Deinen aktuellen Status an.",
			'status:posttitle' => "%s's status: %s",
			'status:everyone' => "All site status",
			'status:strapline' => "%s",
			'status:addstatus' => "�ndere Deinen Status",
		    'status:messages' => "Status Meldungen",
			'status:text' => "Status:",
			'status:set' => "Wann?  ",
			'status:clear' => "Status leeren",
			'status:delete' => "Status l�schen",
			'status:nostatus' => "Kein Status angegeben.",
			'status:viewhistory' => "Alles zeigen",
	
			'item:object:status' => 'Status Nachrichten',
	
	
        /**
	     * Status river
	     **/
	        
	        //generic terms to use
	        'status:river:created' => "%s updated",
	        
	        //these get inserted into the river links to take the user to the entity
	        'status:river:create' => "their status.",
	        
	        
	
		/**
		 * Status messages
		 */
	
			'status:posted' => "Dein neuer Status wurde erfolgreich gespeichert.",
			'status:deleted' => "Dein Status wurde erfolgreich gel�scht.",
	
		/**
		 * Error messages
		 */
	
			'status:blank' => "Sorry; Du musst Deinen Status aktualisieren, bevor er gespeichert werden kann.",
			'status:notfound' => "Sorry; die Statusmeldung konnte nicht in der Datenbank gefunden werden.",
			'status:notdeleted' => "Sorry; Statusmeldung konnte nicht gel�scht werden.",
			'status:notsaved' => "Beim Speichern ist ein Fehler aufgetreten. Versuche es noch einmal oder Benachrichtige den Support.",
			'status:problem' => "Up's: es scheint so, als wenn Du den Status nicht �ndern darfst.",
	
	);
					
	add_translation('de',$german);

?>