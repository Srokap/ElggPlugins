<?php

$german = array(
	 'blog'  =>  "Blog" ,
	 'blogs'  =>  "Blogs" ,
	 'blog:user'  =>  "%s's blog" ,
	 'blog:user:friends'  =>  "Blog von %s's Kontakten" ,
	 'blog:your'  =>  "Dein Blog" ,
	 'blog:posttitle'  =>  "%s's blog: %s" ,
	 'blog:friends'  =>  "Blogs Deiner Kontakte" ,
	 'blog:yourfriends'  =>  "Die letzten Blogs deiner Kontakte" ,
	 'blog:everyone'  =>  "Community Blogs" ,
	 'blog:read'  =>  "Lese den Blog" ,
	 'blog:addpost'  =>  "Beitrag verfassen" ,
	 'blog:editpost'  =>  "Bearbeite den Blog-Eintrag" ,
	 'blog:text'  =>  "Dein Blog Eintrag:" ,
	 'blog:strapline'  =>  "%s" ,
	 'item:object:blog'  =>  "Blog-Einträge" ,
	 'blog:never'  =>  "Nicht gespeichert" ,
	 'blog:preview'  =>  "Vorschau" ,
	 'blog:draft:save'  =>  "Als Entwurf speichern" ,
	 'blog:draft:saved'  =>  "Status" ,
	 'blog:comments:allow'  =>  "Erlaube Kommentare" ,
	 'blog:preview:description'  =>  "Dies ist ein nicht gespeicherter Vorschau deines Blog-Eintrages." ,
	 'blog:preview:description:link'  =>  "Um deinen Eintrag zu bearbeiten und zu speichern, klicke hier." ,
	 'blog:river:created'  =>  "%s schrieb" ,
	 'blog:river:updated'  =>  "%s aktualisiert" ,
	 'blog:river:posted'  =>  "%s" ,
	 'blog:river:create'  =>  "ein neuer Blog-Eintrag ist benannt" ,
	 'blog:river:update'  =>  "ein Blog-Eintrag ist benannt" ,
	 'blog:river:annotate'  =>  "ein Kommentar zu diesem Blog-Eintrag" ,
	 'blog:posted'  =>  "Dein Blog-Eintrag wurde erfolgreich gespeichert." ,
	 'blog:deleted'  =>  "Dein Blog-Eintrag wurde erfogreich gelöscht." ,
	 'blog:error'  =>  "Up's - Ein Fehler - Versuche es bitte noch einmal." ,
	 'blog:save:failure'  =>  "Dein Blog-Eintrag konnte nicht gespeichert werden. Versuch es bitte noch einmal." ,
	 'blog:blank'  =>  "Sorry, du musst sowohl den Titel als auch den Hauptteil benennen, bevor du einen Eintrag machen kannst." ,
     'blog:newpost'  =>  "Neuer Blog-Eintrag" ,
	 'blog:via'  =>  "per Blog" ,
	 'blog:notfound'  =>  "Sorry, wir konnten diesen Blog-Eintrag nicht finden." ,
	 'blog:notdeleted'  =>  "Sorry, wir konnten diesen Blog-Eintrag nicht löschen." ,

);

add_translation('de',$german);

?>