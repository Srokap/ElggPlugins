<?php

	$english = array(
	
		/**
		 * Site info details
		 */
		
		'members:members' => "Site members",
	    'members:online' => "Members active now",
	    'members:active' => "site members",
	    'members:searchtag' => "Member search via tag",
	    'members:searchname' => "Member search via name",
	   
		
	);
					
	add_translation("en",$english);

?>