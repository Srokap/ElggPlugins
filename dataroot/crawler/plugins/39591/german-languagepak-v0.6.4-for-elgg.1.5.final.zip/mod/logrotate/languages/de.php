<?php

// Generate By translationbrowser. 

$german = array( 
	 'logrotate:period'  =>  "Wie oft soll das Systemprotokoll archiviert werden" , 
	 'logrotate:weekly'  =>  "Einmal pro Woche" , 
	 'logrotate:monthly'  =>  "Einmal pro Monat" , 
	 'logrotate:yearly'  =>  "Einmal im Jahr" , 
	 'logrotate:logrotated'  =>  "Protokoll rotiert" , 
	 'logrotate:lognotrotated'  =>  "Fehler bei Protokollrotation" ,
); 

add_translation('de',$german);

?>