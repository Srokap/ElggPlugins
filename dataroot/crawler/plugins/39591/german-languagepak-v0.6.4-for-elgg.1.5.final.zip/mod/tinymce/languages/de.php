<?php

// Generiere vom Übersetzungsbrowser.

$german = array( 
	 'tinymce:remove'  =>  "Bearbeiten",
); 

add_translation('de',$german);

?>