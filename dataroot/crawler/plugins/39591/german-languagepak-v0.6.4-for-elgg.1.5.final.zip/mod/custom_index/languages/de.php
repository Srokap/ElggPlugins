<?php

// Generate By translationbrowser. 

$german = array( 
	 'custom:bookmarks'  =>  "Neuste Lesezeichen",
	 'custom:groups'  =>  "Neue Gruppen",
	 'custom:files'  =>  "Neue Dateien",
	 'custom:blogs'  =>  "Neue Blogbeiträge",
	 'custom:members'  =>  "Neueste Mitglieder",
	 'custom:nofiles'  =>  "Es gibt noch immer keine Dateien",
	 'custom:nogroups'  =>  "Es gibt noch immer keine Dateien",
); 

add_translation('de',$german);

?>