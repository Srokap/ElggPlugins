<?php

// Generate By translationbrowser. 

$german = array( 
	 'friends:widget:description'  =>  "Zeigt Deine Freunde an.",
); 

add_translation('de',$german);

?>