<?php

// Generate By translationbrowser. 

$german = array( 
	 'categories'  =>  "Kategorien",
	 'categories:settings'  =>  "Seiten-Kategorien einrichten",
	 'categories:explanation'  =>  "Um die vordefinierte seitenbreite Kategorien einzurichten, die überall in deinem System benutzt werden, trage sie unten ein (durch Komma getrennt).",
	 'categories:save:success'  =>  "Seiten-Kategorien wurden erfolgreich gespeichert",
); 

add_translation('de',$german);

?>