<?php
/* generate by my own hands - wmage - 2009-03-15 - elgg.1.5-final*/

	$german = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messageboard:board' => "Pinnwand",
			'messageboard:messageboard' => "pinnwand",
			'messageboard:viewall' => "Alles zeigen",
			'messageboard:postit' => "Abschicken",
			'messageboard:history' => "Historie",
			'messageboard:none' => "Bis jetzt kein Eintrag auf der Pinnwand",
			'messageboard:num_display' => "Anzahl Nachrichten",
			'messageboard:desc' => "Dies ist Deine pers�nliche Pinnwand, auf der Dir andere Nachrichten hinterlassen k�nnen.",
	
			'messageboard:user' => "%s's Pinnwand",
	
			'messageboard:history' => "Alles zeigen",
			
         /**
	     * Message board widget river
	     **/
	        
	        'messageboard:river:annotate' => "%s hat eine neue Nachricht hinterlassen.",
	        'messageboard:river:create' => "%s hat das Pinnwand Widget hinzugef�gt.",
	        'messageboard:river:update' => "%s hat das Pinnwand Widget aktualisiert.",
	        'messageboard:river:added' => "%s schrieb auf",
		    'messageboard:river:messageboard' => "pinnwand",

			
		/**
		 * Status messages
		 */
	
			'messageboard:posted' => "Nachricht erfolgreich �bermittelt.",
			'messageboard:deleted' => "Nachricht erfolgreich gel�scht.",
	
		/**
		 * Email messages
		 */
	
			'messageboard:email:subject' => 'Du hast einen neuen Pinnwand Eintrag!',
			'messageboard:email:body' => "Hallo, Du hast einen neuen Eintrag auf Deiner Pinnwand von %s erhalten. Die Nachricht:

			
%s


Um alle NAchrichten Deiner Pinnwand zu lesen, klicke bitte hier:

	%s

Um das Profil von %s anzusehen, klicke bitte hier::

	%s

Dies ist eine Systemmitteilung. Antworten auf diese eMail erreichen den Empf�nger nicht.",
	
		/**
		 * Error messages
		 */
	
			'messageboard:blank' => "Sorry; Du musst den Eintrag aktualisieren, bevor er gespeichert werden kann.",
			'messageboard:notfound' => "Sorry; we could not find the specified item.",
			'messageboard:notdeleted' => "Sorry; die L�schung war nicht erfolgreich .",
			'messageboard:somethingwentwrong' => "Speichern fehlgeschlagen. Hast Du �berhaupt eine Nachricht eingegeben?",
	     
			'messageboard:failure' => "Fehler beim speichern Deiner Nachricht. Bitte versuche es noch einmal.",
	
	);
					
	add_translation('de',$german);

?>