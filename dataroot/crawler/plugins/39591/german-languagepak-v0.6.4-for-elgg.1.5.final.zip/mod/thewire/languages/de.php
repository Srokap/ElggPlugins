<?php

// Generate By translationbrowser. 

$german = array( 
	 'thewire'  =>  "Schoutbox" , 
	 'thewire:user'  =>  "%s's Schoutbox" , 
	 'thewire:posttitle'  =>  "%s's Beiträge zu Schoutbox: %s" , 
	 'thewire:everyone'  =>  "Beiträge von allen" , 
	 'thewire:read'  =>  "Deine Beiträge" , 
	 'thewire:strapline'  =>  "%s" , 
	 'thewire:add'  =>  "Schout-Beitrag schreiben" , 
	 'thewire:text'  =>  "Ein Beitrag zu Schoutbox" , 
	 'thewire:reply'  =>  "Antworten" , 
	 'thewire:via'  =>  "per" , 
	 'thewire:wired'  =>  "Beitrag geschrieben" , 
	 'thewire:charleft'  =>  "Symbole übrig" , 
	 'item:object:thewire'  =>  "Schoutbox-Beiträge" , 
	 'thewire:notedeleted'  =>  "Beitrag gelöscht" , 
	 'thewire:doing'  =>  "Was machst du grade? Lass es jeden wissen:" , 
	 'thewire:newpost'  =>  "Schoutbox-Beitrag" , 
	 'thewire:addpost'  =>  "Schreibe einen Schoutbox-Beitrag" , 
	 'thewire:river:created'  =>  "%s schrieb" , 
	 'thewire:river:create'  =>  "im Schoutbox" , 
	 'thewire:sitedesc'  =>  "Dieses Widget zeigt die zuletzt geschriebenen Seiten-Beiträge im Schoutbox" , 
	 'thewire:yourdesc'  =>  "Dieses Widget zeigt deine zuletzt geschriebenen Seiten-Beiträge im Schoutbox" , 
	 'thewire:friendsdesc'  =>  "Dieses Widget zeigt die zuletzt geschiebenen Beiträge deiner Freunde im Schoutbox" , 
	 'thewire:friends'  =>  "Deine Freunde im Schoutbox" , 
	 'thewire:num'  =>  "Anzahl der Objekte, die angezeigt werden sollen" , 
	 'thewire:posted'  =>  "Deine Nachricht wurde erfolgreich im Schoutbox erstellt." , 
	 'thewire:deleted'  =>  "Dein Beitrag wurde erfolgreich gelöscht." , 
	 'thewire:blank'  =>  "Sorry, du solltest aber etwas ins Textfeld eintragen, bevor du es abspeichert." , 
	 'thewire:notfound'  =>  "Sorry, der gesuchte Eintrag konnte nicht gefunden werden." , 
	 'thewire:notdeleted'  =>  "Sorry, diese Meldung konnte nicht gelöscht werden." , 
	 'thewire:smsnumber'  =>  "Deine SMS-Nummer, falls nicht mit deiner Handy-Nummer übereinstimmend (Die Handynummer muss auf \"öffentlich\" für den Schoutbox eingestellt werden, damit man sie nutzen kann). Alle Tel.Nummern müssen den internationelen Standards entsprechen (Bsp. +49 ... für Deutschland)" , 
	 'thewire:channelsms'  =>  "Die Nummer für die SMS-Nachrichten ist %s" ,
); 

add_translation('de',$german);

?>
