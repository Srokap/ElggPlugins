<?php

// Generate By translationbrowser. 

$german = array( 
	 'guidtool'  =>  "GUID Werkzeug" , 
	 'guidtool:browse'  =>  "GUIDs durchsuchen" , 
	 'guidtool:import'  =>  "GUID-Datei importieren" , 
	 'guidtool:import:desc'  =>  "Datei, die importiert werden soll, in folgendes Fenster einfügen. Dies sollte im \"%s\" Format sein." , 
	 'guidtool:pickformat'  =>  "Bitte das Datei-Format auswählen" , 
	 'guidbrowser:export'  =>  "Exportieren" , 
	 'guidtool:deleted'  =>  "GUID %d gelöscht" , 
	 'guidtool:notdeleted'  =>  "GUID %d nicht gelöscht" ,
); 

add_translation('de',$german); 

?>