<?php

/**
 * Tidypics Lightbox Plugin
 * Author: Cash Costello
 * License: GPL 2
 */


/**
 * Lightbox plugin initialization
 */
function tp_lightbox_init() {
	
	// register for hook thrown for each image in album view
	register_plugin_hook('tp_thumbnail_link', 'album', 'tp_lightbox_album_wrapper');

	// register for hook thrown for image in individual view
	register_plugin_hook('tp_thumbnail_link', 'image', 'tp_lightbox_image_wrapper');
	
	// register for hook thrown on page with slideshow
	register_plugin_hook('tp_slideshow', 'album', 'tp_lightbox_slideshow');
}

/**
 * Create HTML for image in album view
 * 
 * @param $hook
 * @param $entity_type
 * @param $returnvalue
 * @param $params array with image entity
 * @return string
 */
function tp_lightbox_album_wrapper($hook, $entity_type, $returnvalue, $params) {
	global $CONFIG;
	
	if (!isset($params['image'])) {
		return $returnvalue;
	}
	
	$image = $params['image'];
	
	// change lyteshow to lytebox for manual slideshow
	$html = <<<END
<div class="tp_lightbox_wrapper">
	<div class="tidypics_album_images">
		<a href="{$CONFIG->url}pg/photos/thumbnail/{$image->guid}/large/" rel="lyteshow[album]" title="{$image->title}" >
			<img src="{$CONFIG->url}pg/photos/thumbnail/{$image->guid}/small/" alt="{$image->title}" />
		</a>
	</div>
	<div class="tp_lightbox_title">
		<a href="{$image->getURL()}">{$image->title}</a>
	</div>
</div>
END;
	
	return $html;
}


/**
 * Create HTML for image in individual image view
 * 
 * @param $hook
 * @param $entity_type
 * @param $returnvalue
 * @param $params array with image entity
 * @return string
 */
function tp_lightbox_image_wrapper($hook, $entity_type, $returnvalue, $params) {
	global $CONFIG;
	
	if (!isset($params['image'])) {
		return $returnvalue;
	}
	
	// add lytebox js and css
	extend_view('metatags', 'tp_lightbox/head');
		
	$image = $params['image'];
	
	$html = <<<END
<a href="{$CONFIG->url}pg/photos/download/{$image->guid}/inline/" rel="lytebox[album]" title="{$image->title}" >
	<img id ="tidypics_image" src="{$CONFIG->url}pg/photos/thumbnail/{$image->guid}/large/" alt="{$image->title}" />
</a>
END;
	
	return $html;
}


/**
 * Handler for page with a slideshow
 * 
 * Removes default slideshow and adds js and css for lytebox
 * 
 * @param $hook
 * @param $entity_type
 * @param $returnvalue
 * @param $params
 * @return bool
 */
function tp_lightbox_slideshow($hook, $entity_type, $returnvalue, $params) {
	
	// add lytebox js and css
	extend_view('metatags', 'tp_lightbox/head');
	
	// returning false to turn off default slideshow
	return false;
}


register_elgg_event_handler('init', 'system', 'tp_lightbox_init');
