
<script type="text/javascript" src="<?php echo $CONFIG->wwwroot . 'mod/tidypics/vendors/lytebox/lytebox.js'; ?>"></script>
<link rel="stylesheet" href="<?php echo $CONFIG->wwwroot . 'mod/tidypics/vendors/lytebox/lytebox.css'; ?>" type="text/css" />
<link rel="stylesheet" href="<?php echo $CONFIG->wwwroot . 'mod/tidypics_lightbox/lightbox.css'; ?>" type="text/css" />

