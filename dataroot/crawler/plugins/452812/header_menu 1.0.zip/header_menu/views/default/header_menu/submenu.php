<!-- Uddhava Menu-->

<?php 
//		<li><a href='" . $vars['url'] . "pg/settings/plugins/" . $_SESSION['user']->username . "/' title='Configure Your Tools'>Configure Your Tools</a></li>
//		<li><hr></li>
//		<li><a href='" . $vars['url'] . "pg/groups/new/' title='Create a Group'>Create a Group</a></li>
//   	<li><a class='top_dir' href='" . $vars['url'] . "pg/forum/siteforum'><img src='" . $vars['url'] . "mod/header_menu/images/discussions.png' /> Forum</a></li>
//  	<li><a class='top_dir' href='" . $vars['url'] . "pg/forum/siteforum'><img src='" . $vars['url'] . "mod/header_menu/images/discussions.png' /> Forum</a></li>			

if (isloggedin()){

	echo "<table width='100%' cellspacing='0' cellpadding='0'>
  <tr>
    <td width='65px'>&nbsp;</td>
    <td>
<div class='clearfloat'></div>
<div >";

	echo "<ul id='nav' class='dropdown dropdown-horizontal'>

	<li><a class='top_dir' href='" . $vars['url'] . "'><img src='" . $vars['url'] . "mod/header_menu/images/home.png' /> Home</a>

		<ul>
		<li><a href='" . $vars['url'] . "'> Home Page</a></li>
		<li><a href='" . $vars['url'] . "pg/expages/read/About/' title='About the Site'>About the site</a></li>
		<li><a href='" . $vars['url'] . "pg/expages/read/Terms/' title='Terms of Service'>Terms of Service</a></li>
		<li><a href='" . $vars['url'] . "pg/expages/read/Privacy/' title='Privacy Policy'>Privacy Policy</a></li>
		<li><hr /></li>
		<li><a href='" . $vars['url'] . "mod/invitefriends/' title='Invite Friends'>Invite Friends</a></li>
		</ul></li>

	<li><a class='top_dir' href='" . $vars['url'] . "pg/dashboard/'><img src='" . $vars['url'] . "mod/header_menu/images/dashboard.png' /> Dashboard</a></li>
						
	<li><a class='top_dir' href='" . $vars['url'] . "pg/settings/'><img src='" . $vars['url'] . "mod/header_menu/images/settings.png' /> Settings</a>

		<ul>
		<li><a href='" . $vars['url'] . "pg/settings/' title='My Settings'>Change Name & Password</a></li>
		<li><a href='" . $vars['url'] . "mod/profile/editicon.php' title='Change My Icon'>Change My Picture</a></li>
		<li><a href='" . $vars['url'] . "pg/profile/" . $_SESSION['user']->username . "' title='View My Profile'>View My Profile</a></li>
		<li><a href='" . $vars['url'] . "mod/profile/edit.php?username=" . $_SESSION['user']->username . "' title='Edit My Profile'>Edit My Profile</a></li>
		<li><hr /></li>
		<li><a href='" . $vars['url'] . "mod/notifications/' title='Notifications'>Notifications</a></li>
		<li><a href='" . $vars['url'] . "mod/notifications/groups.php' title='Group Notifications'>Group Notifications</a></li>
		</ul></li>

	<li><a class='top_dir' href='" . $vars['url'] . "mod/blog/everyone.php'><img src='" . $vars['url'] . "mod/header_menu/images/blog.png' /> Blogs</a>

		<ul>
		<li><a href='" . $vars['url'] . "mod/blog/everyone.php' title='All Blogs'>All Blogs</a></li>
		<li><a href='" . $vars['url'] . "pg/blog/" . $_SESSION['user']->username . "' title='My Blogs'>My Blogs</a></li>
		<li><a href='" . $vars['url'] . "pg/blog/" . $_SESSION['user']->username . "/friends/' title='Friends Blogs'>Friends Blogs</a></li>
		<li><hr /></li>
		<li><a href='" . $vars['url'] . "mod/blog/add.php' title='Add a blog post'>Add a blog post</a></li>
		</ul></li>

	<li><a class='top_dir' href='" . $vars['url'] . "pg/questions/allquestions?order_by=time_created&criteria=desc'><img src='" . $vars['url'] . "mod/header_menu/images/question.png' /> Questions</a>
	
		<ul>
		<li><a href='" . $vars['url'] . "pg/questions/allquestions?order_by=time_created&criteria=desc' title='All Questions'>All Questions</a></li>
		<li><a href='" . $vars['url'] . "pg/questions/yours' title='Your Questions'>Your Questions</a></li>
		<li><a href='" . $vars['url'] . "pg/questions/new' title='New Questions'>New Question</a></li>
		<li><a href='" . $vars['url'] . "pg/questions/notanswered' title='Not Answered'>Not Answered</a></li>
		</ul></li>
		
	<li><a class='top_dir' href='" . $vars['url'] . "pg/groups/world/?filter=active'><img src='" . $vars['url'] . "mod/header_menu/images/group.png' /> Groups</a>

		<ul>
		<li><a href='" . $vars['url'] . "pg/groups/world/?filter=active' title='Latest Discussion'>Latest Discussion</a></li>
			<li><hr /></li>
		<li><a href='" . $vars['url'] . "pg/groups/world/?filter=newest' title='All Groups'>All Groups</a></li>
		<li><a href='" . $vars['url'] . "pg/groups/member/" . $_SESSION['user']->username . "' title='My Groups'>My Groups</a></li>
		<li><a href='" . $vars['url'] . "pg/groups/world/?filter=pop' title='Popular Groups'>Popular Groups</a></li>
		</ul></li>

	<li><a class='top_dir' href='" . $vars['url'] . "mod/members/index.php?filter=newest'><img src='" . $vars['url'] . "mod/header_menu/images/members.png' /> Members</a>

		<ul>
		<li><a href='" . $vars['url'] . "pg/vazco_gmap/members/map/' title='Users World Map'>Users World Map</a></li>
		<li><hr /></li>		
		<li><a href='" . $vars['url'] . "pg/vazco_karma/members/extend/?filter=karma' title='Top Users'>Top Users</a></li>
		<li><a href='" . $vars['url'] . "mod/members/index.php?filter=newest' title='Newest'>Newest</a></li>
		<li><a href='" . $vars['url'] . "mod/members/index.php?filter=active' title='Logged In'>Logged In</a></li>
		<li><hr /></li>
		<li><a href='" . $vars['url'] . "pg/friends/" . $_SESSION['user']->username . "title='My Friends'>My Friends</a></li>
		</ul></li>

	<li><a class='top_dir' href='" . $vars['url'] . "pg/photos/world/'><img src='" . $vars['url'] . "mod/header_menu/images/thumbnail.png' /> Photos</a>

		<ul>
		<li><a href='" . $vars['url'] . "pg/photos/world/' title='All Photos'>All Photos</a></li>
		<li><a href='" . $vars['url'] . "pg/photos/owned/" . $_SESSION['user']->username . "' title='My Photos'>My Photos</a></li>
		<li><a href='" . $vars['url'] . "pg/photos/mostrecent' title='Most recent'>Most recent</a></li>
		<li><a href='" . $vars['url'] . "pg/photos/mostviewed' title='Most viewed'>Most viewed</a></li>
		<li><hr /></li>
		<li><a href='" . $vars['url'] . "pg/photos/new/" . $_SESSION['user']->username . "' title='Create New Album'>Create New Album</a></li>
		</ul></li>

	<li><a class='top_dir' href='" . $vars['url'] . "mod/thewire/everyone.php'><img src='" . $vars['url'] . "mod/header_menu/images/wire.png' /> The Wire</a></li>

	<li><a class='top_dir' href='" . $vars['url'] . "pg/izap_videos/world/all'><img src='" . $vars['url'] . "mod/header_menu/images/tv.png' /> Videos</a>

		<ul>
		<li><a href='" . $vars['url'] . "pg/izap_videos/world/all' title='All Videos'>All Videos</a></li>
		<li><a href='" . $vars['url'] . "pg/izap_videos/" . $_SESSION['user']->username . "/' title='My Videos'>My Videos</a></li>
		<li><a href='" . $vars['url'] . "pg/izap_videos/" . $_SESSION['user']->username . "/frnd' title='Friends Videos'>Friends Videos</a></li>
		<li><hr /></li>
		<li><a href='" . $vars['url'] . "pg/izap_videos/" . $_SESSION['user']->username . "/add' title='Add a Video'>Add a Video</a></li>
		</ul></li>	
"; 

} else {

	echo "<table width='100%' cellspacing='0' cellpadding='0'>
  <tr>
    <td width='140px'>&nbsp;</td>
    <td>
<div class='clearfloat'></div>
<div >";

   echo "<ul id='nav' class='dropdown dropdown-horizontal'>

	<li><a class='top_dir' href='" . $vars['url'] . "'><img src='" . $vars['url'] . "mod/header_menu/images/home.png' /> Home</a></li>
	<li><a class='top_dir' href='" . $vars['url'] . "pg/dashboard/'><img src='" . $vars['url'] . "mod/header_menu/images/dashboard.png' /> Dashboard</a></li>
	<li><a class='top_dir' href='" . $vars['url'] . "mod/blog/everyone.php'><img src='" . $vars['url'] . "mod/header_menu/images/blog.png' /> Blogs</a></li>
	<li><a class='top_dir' href='" . $vars['url'] . "pg/event_calendar/'><img src='" . $vars['url'] . "mod/header_menu/images/events.png' /> Events</a></li>
	<li><a class='top_dir' href='" . $vars['url'] . "pg/groups/world/?filter=active'><img src='" . $vars['url'] . "mod/header_menu/images/group.png' /> Groups</a></li>
	<li><a class='top_dir' href='" . $vars['url'] . "mod/members/index.php?filter=newest'><img src='" . $vars['url'] . "mod/header_menu/images/members.png' /> Members</a></li>
	<li><a class='top_dir' href='" . $vars['url'] . "pg/photos/world/'><img src='" . $vars['url'] . "mod/header_menu/images/thumbnail.png' /> Photos</a></li>
	<li><a class='top_dir' href='" . $vars['url'] . "mod/thewire/everyone.php'><img src='" . $vars['url'] . "mod/header_menu/images/wire.png' /> The Wire</a></li>
	<li><a class='top_dir' href='" . $vars['url'] . "pg/izap_videos/world/all'><img src='" . $vars['url'] . "mod/header_menu/images/tv.png' /> Videos</a></li>
";
} 
?>
</div><div class='clearfloat'></div>

</td>
    <td width="1px">&nbsp;</td>
  </tr>
</table>

<!-- Uddhava Menu END-->


<!-- Uddhava Menu 2nd part BEGIN-->
<?php 
		$total_users = get_number_users(true);
		$groups = elgg_get_entities(array('types' => 'group', 'subtypes' => '', 'limit' => 9999, 'count' => TRUE)); 
		$photocount = elgg_get_entities(array('types' => 'object', 'subtypes' => 'image', 'limit' => 9999, 'count' => TRUE)); 
		$videocount = elgg_get_entities(array('types' => 'object', 'subtypes' => 'izap_videos', 'limit' => 9999, 'count' => TRUE)); 

		//$photocount = elgg_get_entities('object','image',0,0,'', true, false);
		//$videocount = elgg_get_entities('object','izap_videos',0,0,'', true, false);

 echo "<div align='center' class='bottomtext'>"; 

if (isloggedin()){
	echo $vars['config']->sitename . ' '; 
	echo elgg_echo("headermenu:current") .' '; 
	echo $total_users . ' ';
	echo elgg_echo('headermenu:members') . ', ';
	echo $groups . " " . elgg_echo("headermenu:groups") . ', '; 
	echo $photocount . " " . elgg_echo("headermenu:photos") . ', '; 
	echo $videocount . " " . elgg_echo("headermenu:videos") . ' '; 
	
	//ADD User profile pictures / Users online in the last 1200 seconds
	$members = find_active_users(1200,16,0);

	if(isset($members)) {
	//display member avatars
	
	echo "<p><table class='whoisonline' border='0' cellspacing='0' cellpadding='0' bgcolor='#FFFFFF'>  <tr>";
		echo "<td style='color: black; vertical-align: middle;' width='50'><div align='center'>";
		echo "Online:";
 		echo "</div></td>";

		foreach($members as $member)
		{
		echo "<td width='30'><div align='center'>";
		echo elgg_view("profile/icon",array('entity' => $member, 'size' => 'tiny'));
		echo "</div></td>";

//For vertical bar		echo "<tr><td width='30' height='50'><div align='center'>";
// 		echo "</div></td></tr>";

		}
		echo "</tr></table>";
//END User profile pictures / Users online in the last 600 seconds

	}

}else{

	echo $vars['config']->sitename . ' '; 
	echo elgg_echo("headermenu:current") .' '; 
	echo $total_users . ' ';
	echo elgg_echo('headermenu:members') . ', ';
	echo $groups . " " . elgg_echo("headermenu:groups") . ', '; 
	echo $photocount . " " . elgg_echo("headermenu:photos") . ', '; 
	echo $videocount . " " . elgg_echo("headermenu:videos") . ' '; 
	echo elgg_echo("headermenu:public") . ' '; 
	echo "<a href='" . $vars['url'] . "account/register.php'>" . elgg_echo ('headermenu:register') . "</a> ";
	echo elgg_echo ("headermenu:access");
	}
?>
</div>
<br>
<!-- Uddhava Menu 2nd part END-->