<?php
	global $CONFIG;
	include_once($CONFIG->pluginspath . "theme_editable/helpers.php");
	include(get_css_file_path());
?>
