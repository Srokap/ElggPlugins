<?php
  $english = array(
          'theme_editable' => 'Editable Theme',
          'theme_editable:settings' => 'Edit Theme',
          'theme_editable:explanation' => 'Edit the site CSS below. PHP tags/code is allowed, but be careful as that could really mess things up.',
          'theme_editable:save:success' => 'Theme css was successfully saved.',

  );

  add_translation("en",$english);
?>