<?php
	echo $vars['url'] . "mod/socializeme/graphics/file_icons/pages_lrg.gif";
?>