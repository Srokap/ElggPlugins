<?php
	echo $vars['url'] . "mod/socializeme/graphics/group_icons/defaulttiny.gif";
?>