<?php

$english = array(
	'shib_auth:login_link_text' => 'Login with Shibboleth',
);

add_translation('en', $english);
