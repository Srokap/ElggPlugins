<?php
/**
 * Noelab Seo Theme
 * Italian Support Group for Elgg
 * @package Fast by Default and Elgg Performances and SEO
 * @author Lord55
 * @link http://www.noelab.com/
 * 
 */
?>
<div class="clearfloat"></div>
	
<div id="footer_contents">
	
        <ul id="credit">
          <li>Theme designed by <a href="http://noelab.com">Talent Creativity</a></li>
          <li>Powered by <a href="http://elgg.org">Elgg</a></li>
		  <li>Copyright &copy;&nbsp; 2010     &nbsp;<a href="<?php echo ELGG_URL ; ?>"><?php echo $vars['config']->sitename; ?></a></li>
		  <li><?php echo elgg_view('footer/links'); ?><li>
        </ul>
		
</div><!-- /#footer_contents -->

<div class="clearfloat"></div>

<div id="return_top">
 <a href="#header">&nbsp&#9650<p><?php echo elgg_echo('RETURN TOP'); ?></p></a>
</div>

<?php
	echo elgg_view('footer/analytics');
?>