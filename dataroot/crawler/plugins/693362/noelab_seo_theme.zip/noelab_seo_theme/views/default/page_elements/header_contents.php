<?php
/**
 * 
 * Noelab Seo Theme
 * Italian Support Group for Elgg
 * @package Fast by Default and Elgg Performances and SEO
 * @author Lord55
 * @link http://www.noelab.com/
 * to do: metter extend altrimenti non sa se plugin esiste a messages
*/
?>


<div id="header">

      <div id="site_logo">
        <h1><a href="<?php echo $vars['url']; ?>"><?php echo $vars['config']->sitename; ?></a></h1>
	  </div>
   
      <div id="header_noelab">
           
		   <?php if (isloggedin()) { ?>
		   
           		<a title="Friends" id="header_friends" href="<?php echo $vars['url']; ?>pg/friends/<?php echo get_loggedin_user()->username; ?>">➲<?php echo elgg_echo("friends"); ?></a>
		   
		   
		   <?php
		      if(is_plugin_enabled('messages')){
				//get unread messages
				$num_messages = count_unread_messages();
				if($num_messages){
					$num = $num_messages;
				} else {
					$num = 0;
				}

				if($num == 0){

           	 ?>
          		<a title="Messages" id="header_messages" href="<?php echo $vars['url']; ?>pg/messages/inbox/<?php echo get_loggedin_user()->username; ?>" >➲<?php echo elgg_echo("messages"); ?></a>
		   
		  	 <?php }else{ ?>

				<a title="Messages" id="header_messages" href="<?php echo $vars['url']; ?>pg/messages/inbox/<?php echo get_loggedin_user()->username; ?>" >➲<?php echo elgg_echo("messages"); ?> [<?php echo $num; ?>]</a>
	
			<?php } 
			} 
		   }?>
		   
		   <div id="search-area">
             <?php echo elgg_view('page_elements/searchbox'); ?>
           </div>
		  
		  <div class="clearfloat"></div>
		  
		   <div id="loginout">
		   <?php if (isloggedin()) { ?>
		   <a href="<?php echo get_loggedin_user()->getURL(); ?>"><img class="user_mini_avatar" src="<?php echo get_loggedin_user()->getIcon('topbar'); ?>" alt="User avatar" /> ➲<?php echo get_loggedin_user()->username; ?>  ┊ </a>
		   <?php echo elgg_view('output/url', array('href' => "{$vars['url']}action/logout", 'text' => "➲" . elgg_echo('logout'), 'is_action' => TRUE)); ?>
		   <?php }else{ ?>
		   <a href="<?php echo $vars['url']; ?>">➲<?php echo elgg_echo("login"); ?></a>
		   <?php } ?>
		   </div>
		   
       </div><!-- #header_noelab end -->

 </div>
