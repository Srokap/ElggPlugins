<?php
/**
 * NoELab Seo Theme
 * 
 * Italian Support Group for Elgg
 * @package Fast by Default - Elgg Performances and SEO by NoELAb.com 
 * @author Lord55
 * @link http://www.noelab.com/
**/
?>
html {
	margin: 0;
	padding: 0;
	background: #1B1E26;
}

body {
    width: 990px;
	margin: 0 auto;
	min-height: 300px;
	text-align:left;
	padding:0;
	font: 80%/1.4  "Lucida Grande", Verdana, sans-serif;
	color: #444;
}
a {
	color: #2F6D7A;
	text-decoration: none;
	-moz-outline-style: none;
	outline: none;
}
a:visited {

}
a:hover {
	color: #70A99A;
	text-decoration: underline;
}
#layout_canvas {
	margin:0 0 20px 0;
	padding:20px;
	min-height: 360px;
	background: #B6D051;
	border-bottom:1px solid #cccccc;
	border-right:1px solid #cccccc;
	-webkit-border-radius: 16px;
	-moz-border-radius: 16px;
	border-radius: 16px;
}
/****************************************
 * New Header
*****************************************/
#header {
	background:#1B1E26;
	height:160px;
}

#site_logo { 
	margin:50px 0 0 20px; 
	float:left; 
	display:inline;
}
#site_logo h1 a{ 
	font-size: 48px;
	color: #B6D051;
	font-weight:normal;
	text-shadow: 4px 4px 4px #70A99A;
	text-decoration:none; 
}
#site_logo h1 a:hover{ 
	text-shadow: 4px 4px 4px #B6D;
 
}
#header_noelab { 
	float:right; 
	display:inline; 
	margin:0; 
}

#header_messages { 
	font-size:20px; 
	float:left; 
	margin:70px 0 0 20px; 
	display:inline;
	color:#70A99A; 
	background:#; 
	height:25px; 
	padding:0px; 
}
#header_messages:hover { 
	background:#; 
	color:#fff; 
	text-decoration:none; 
}

#header_friends { 
	font-size:20px;
	float:left; 
	margin:70px 0 0 10px; 
	display:inline; 
	color:#70A99A; 
	background:#; 
	height:25px; 
	padding:0px; 
}
#header_friends:hover { 
	background:#; 
	color:#fff; 
	text-decoration:none; 
}

#search-area { 
	float:left; 
	display:inline; 
	width:220px; 
	height:29px; 
	margin:77px 30px 0 20px; 
	position:relative; 
}
#loginout { 
	float:right; 
	display:inline; 
	margin:20px 10px 0 0px; 
	position:relative;
	padding:0px;
}
#loginout a{
	font-size:20px;
	background:#;
	color:#2F6D7A;
}
#loginout a:hover {  
	background:#; 
	color:#fff; 
	text-decoration:none; 
}

#header_noelab .user_mini_avatar {
	border:1px solid #eeeeee;
	margin:0;
}
/****************************************
 * New Navigation
*****************************************/
#navigation{
	width:100%;
	height:52px;
	background:#1B1E26;
	border-top: 1px solid #1B1E26;
}
#navigation ul{
	margin:0px; 
	padding:0px;
}
#navigation ul li{
	display:inline;
	height:50px;
	float:left;
	list-style:none;
	margin-left:15px;
	padding:0 10px;
	position:relative;
}
#navigation li a{
    font: bold 25px/normal Arial, Helvetica, sans-serif;
	color:#F2EFBD; 
	text-decoration:none;
	line-height:48px;
}
#navigation li a:hover{
	color:#2F6D7A;
}
#navigation li ul{
	margin:0px;
	padding:0px;
	display:none;
	position:absolute;
	left:15px;
	top:50px;
	background:#1B1E26;
	-webkit-border-bottom-right-radius: 16px;
	-webkit-border-bottom-left-radius: 16px;
	-moz-border-radius-bottomright: 16px;
	-moz-border-radius-bottomleft: 16px;
	border-bottom-right-radius: 16px;
	border-bottom-left-radius: 16px;
	opacity: 0.9;
	filter: alpha(opacity=90);
	z-index: 9000;
}
#navigation li:hover ul{
	display:block;
	width:200px;
}
#navigation li li{
    height:30px;
	list-style:none;
	display:list-item;
	float: none;
	padding: 2px;
	border-bottom: 1px dotted #fff;
}
#navigation li li a{
    font: bold 15px/normal Arial, Helvetica, sans-serif;
	color:#F2EFBD; 
	text-decoration:none;
}
#navigation li li a:hover{
	color:#2F6D7A; 
}
/****************************************
 * New Footer
*****************************************/
#footer_contents {
	background: #1B1E26;
	margin:0 0 20px 0;
	padding:5px;
	height:80px;
}

#footer_contents ul#credit {
    float:right;
    margin-right:20px;
    padding:1px 0 0 8px;
    border-left:3px solid #2F6D7A;
    list-style-type:none;
    text-align:left;
	font-size:0.8em;
	color:#888;
	background: #1B1E26;
}

#footer_contents .footer_toolbar_links{
	font-size:1.2em;
}
#footer_contents #footer_seo {
	background: #fff;
}
#footer_contents p.miniseo {
    background: #222;
    color:#fff;
    float:left;
    font-size:15px;
    line-height:19px;
    margin:0 auto;
    padding: 0 auto;
    text-align:left;
	width:600px;
}

/****************************************
 * Return TOP
*****************************************/
#return_top a { 
  	position:absolute; 
	position:fixed; 
	right:0; 
	bottom:20px;
    display:block; 
	height:150px; 
	width:30px; 
	background:#70A99A; 
}
#return_top a:hover { 
	background:#2F6D7A; 
	color:#fff;
	text-decoration:none
}
#return_top p {
	color:#fff;
	border:0px solid red;
	writing-mode:tb-rl;
	-webkit-transform:rotate(90deg);
	-moz-transform:rotate(90deg);
	-o-transform: rotate(90deg);
	white-space:nowrap;
	display:block;
	bottom:0;
	width:20px;
	height:20px;
	font: normal 15px/normal ‘Trebuchet MS’, Helvetica, sans-serif;
	text-decoration:none
	text-shadow: 0px 0px 1px #333;
}
#return_top p:hover {
    color:#4690D6;
}
/****************************************
 * owner_block link
*****************************************/
#owner_block_submenu ul {
	list-style: none;
	padding: 0;
	margin: 0;
}
#owner_block_submenu ul li.selected a {
	background: #70A99A;
	color:#2F6D7A;
}
#owner_block_submenu ul li.selected a:hover {
	color:70A99A;
}
#owner_block_submenu ul li a {
	text-decoration: none;
	display: block;
	margin: 2px 0 0 0;
	color:#2F6D7A;
	padding:4px 6px 4px 10px;
	font-weight: bold;
	line-height: 1.1em;
	-webkit-border-radius: 10px;
	-moz-border-radius: 10px;
}
#owner_block_submenu ul li a:hover {
	background: #70A99A;
}