<?php
/**
 * NoELab Seo Theme
 * 
 * Italian Support Group for Elgg
 * @package Fast by Default - Elgg Performances and SEO by NoELAb.com 
 * @author Lord55
 * @link http://www.noelab.com/
 * 
**/
?>


<div id="navigation">
    <ul>
			
		    <?php if (isloggedin()) { ?>
		    <li><a href="<?php echo $vars['url']; ?>pg/dashboard/" class="pagelinks">➲<?php echo elgg_echo('dashboard'); ?></a></li>
            <?php } else { ?>  
		    <li><a href="<?php echo $vars['url']; ?>" class="pagelinks">➲<?php echo elgg_echo('Home'); ?></a></li>
		    <?php } ?>
			  	
		    <li><a href="#">➲<?php echo(elgg_echo('tools')); ?></a>
			     <ul>              
   					<?php
					 $menu = get_register('menu');

					 if (is_array($menu) && sizeof($menu) > 0) {
					    $alphamenu = array();
					 	foreach($menu as $item) {
					 	$alphamenu[$item->name] = $item;
					    }
					 
					 	ksort($alphamenu);
		             	foreach($alphamenu as $item) {
			         	echo "<li><a href=\"{$item->value}\">➲" . $item->name . "</a></li>";
		                }
					 }
	                 ?>
                </ul> 
            </li>
			
			<?php if (isloggedin()) { ?>
			 
			<li><a href="<?php echo $vars['url']; ?>pg/settings/">➲<?php echo elgg_echo('settings'); ?></a></li>
			
			<?php if ($vars['user']->isAdmin()) { ?>

			<li><a href="<?php echo $vars['url']; ?>pg/admin/">➲<?php echo elgg_echo("admin"); ?></a>
			    <ul>
                      <li><a href="<?php echo $vars['url']; ?>pg/admin/site/">➲<?php echo elgg_echo("admin:site"); ?></a></li>
                      <li><a href="<?php echo $vars['url']; ?>pg/admin/user/">➲<?php echo elgg_echo("admin:user"); ?></a></li>
                      <li><a href="<?php echo $vars['url']; ?>pg/admin/plugins/">➲<?php echo elgg_echo("admin:plugins"); ?></a></li>
                </ul>
            </li>
		     
		    <?php } 
			}?>
			
   </ul>
	
</div>

<div class="clearfloat"></div>
