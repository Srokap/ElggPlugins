<?php
/**
 * NoELab Seo Theme
 * 
 * Italian Support Group for Elgg
 * @package Fast by Default - Elgg Performances and SEO by NoELAb.com 
 * @author Lord55
 * @link http://www.noelab.com/
**/

	
	/* Initialise the noelab_seo_theme */
	function noelab_seo_theme_init(){
		
		global $CONFIG;
		
		// Extend system CSS with our own styles for noelab_seo_theme
				elgg_extend_view('css', 'noelab_seo_theme/css');		
		
	}
	
	

	/* Initialise log browser */
	register_elgg_event_handler('init','system','noelab_seo_theme_init');