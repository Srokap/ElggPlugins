# iShouvik Riverdashboard for Elgg 1.8 #
This is an elgg plugin to provide a three columned layout for the activity page.


Preferred support is given to those who have either donated $25 or keep the link to my site on either on sidebar or on footer.
Contact Shouvik Mukherjee for any customisation and/or donation: <a href="mailto:contact@ishouvik.com" title="Send mail" target="_blank">contact[at]ishouvik.com</a>

<strong><a href="http://ishouvik.com" target="_blank">iShouvik.com</a></strong> | <strong><a href="http://twitter.com/ishouvik" target="_blank">Twitter</a></strong> | <strong><a href="http://www.facebook.com/shouvikmukherjee" target="_blank">Facebook</a></strong>

## Release Notes ##
*	Installation -> Unzip the plugin and put it inside /mod directory

*	Compatibility -> If you have iShouvik Adverts plugin installed. Please place the adverts plugin below this riverdashboard

*	This is a free GPL plugin. A small acknowledgement, a small backlink at the bottom of the sidebar is all we ask for. 

*	If you have both iShouvik Adverts and iShouvik Riverdashboard installed, the backlink to ishouvik.com would be displayed on ly on the 		footer.

## Credits ##
*	DhrupDeScoop for inspiring me ... helping me debug all the time
*	@_13Net for some code snippets which made the development faster
*	Diptendra Purkayastha for letting me test the plugin on his Elgg site
