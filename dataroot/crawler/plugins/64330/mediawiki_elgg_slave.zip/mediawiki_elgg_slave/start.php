<?php


	function mediawiki_menu_init() {
		
		// Load system configuration
		global $CONFIG;
			
		// Load the language files
		//register_translations($CONFIG->pluginspath . "mediawiki_menu/languages/");
			
							
		// Set up menu for users
		if (isloggedin()) {
			add_menu("Wiki", $CONFIG->wwwroot . "w/");
		}//elgg_echo('item:object:mediawiki_menu')
		
		
	}
	
/*	function mediawiki_menu_pagesetup() {
		
		global $CONFIG;
		
				if (isloggedin()) {
//					add_submenu_item(elgg_echo('mediawiki_menu:new'), $CONFIG->url . "pg/mediawiki_menu/new/", 'eventcalendaractions');
				}
  }*/
    
  	
// Make sure the event calendar functions are called
	register_elgg_event_handler('init','system','mediawiki_menu_init');
	//register_elgg_event_handler('pagesetup','system','mediawiki_menu_pagesetup');
	

?>
