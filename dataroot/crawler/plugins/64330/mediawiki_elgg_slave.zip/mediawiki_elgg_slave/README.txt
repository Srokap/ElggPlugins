		How to integrate MediaWiki and Elgg 1.5

1) Install your wiki on the same server as Elgg
2) Open the media wiki file "include/GlobalFunctions.php"
3) Add the line "wfRunHooks( 'BeforeSetupSession');" after "function wfSetupSession() {"

include/GlobalFunctions.php

/**
 * Initialise php session
 */
function wfSetupSession() {
	wfRunHooks( 'BeforeSetupSession');
	global $wgSessionsInMemcached, $wgCookiePath, $wgCookieDomain, $wgCookieSecure, $wgCookieHttpOnly;

4) Install the plugin, blacklist (http://www.mediawiki.org/wiki/Extension:Blacklist) by copying the file blacklist.php to your wiki's extensions directory

5) Open LocalSettings.php for the wiki and add the following at the bottom:
include_once("extensions/blacklist.php");
$wgBlacklist['*']['read'] = array("Special:UserLogin", "Special:UserLogout");

function fnElggAuth($user, &$result) {
		$result=1;//Abort normal Auth process
		$ElggUser=get_loggedin_user();//Elgg (sessions.php) call
		if (!(isset($ElggUser)) || !($ElggUser->guid > 0)){
			$user->loadDefaults();
			return false;
		} else {

			//var username,name,email,lang,guid;
			$username=$ElggUser->get("username");
			$name=$ElggUser->get("name");
			$email=$ElggUser->get("email");
			$lang=$ElggUser->get("language");
			//Makeuser name in Wiki format, init cap and all lower
			$username = strtolower($username);
		    	// uppercase first letter to make mediawiki happy
			$username[0] = strtoupper($username[0]);

		$user->loadDefaults($username);         // Added as it's done this way in CentralAuth.
 
		$user->mEmail              = $email;
		$user->mName               = $username; // Redundant given use of loadDefaults...?
		$user->mRealName           = $name;
		$user->mEmailAuthenticated = wfTimestamp();

		}
	return false;
}

function fnElggInit() {
	define('externalpage',true);
        require_once("/full/path/to/elgg/engine/start.php");
        global $CONFIG;
	return true;
}
$wgHooks['UserLoadFromSession'][] = 'fnElggAuth';
$wgHooks['BeforeSetupSession'][] = 'fnElggInit';

6) Also in local settings adjust the default permissions for unregistered users, etc.
e.g. 
Adding "$wgGroupPermissions['*']['edit'] = false; " will prevent unregistered users from editing pages
Adding "$wgGroupPermissions['*']['view'] = false;" will prevent unregistred users from viewing pages, etc.

7) Hide the login/logout links. Edit the css for your wiki skin (that file by default is skins/monobook/main.css)
li#pt-anonlogin, li#pt-logout, li#pt-login, li#pt-anonlogout
{
	display: none;
}
8) To add a menu link, customise start.php to the proper path of your wiki and what the text for the link should be and then install this directory (less all other files) as a plugin in Elgg.
