<?php

	/**
	 * Elgg Emoticons
	 * 
	 * @package ElggEmoticons
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
	 * @copyright (C) Sergio De Falco 2008
	 * @link http://www.gonk.it/
	 */
	 
    function emoticons_init() {
	
        // Extend system CSS with our own styles
			extend_view('css','emoticons/css');

    }

	function add_emoticons($string) {

		$string = str_replace(":)", "<img src='" . $vars['url'] . "/mod/emoticons/graphics/emoticons/smile.gif' alt=':)' />", $string);
		$string = str_replace(":(", "<img src='" . $vars['url'] . "/mod/emoticons/graphics/emoticons/sad.gif' alt=':(' />", $string);
		$string = str_replace(":D", "<img src='" . $vars['url'] . "/mod/emoticons/graphics/emoticons/laugh.gif' alt=':D' />", $string);
		$string = str_replace(";)", "<img src='" . $vars['url'] . "/mod/emoticons/graphics/emoticons/wink.gif' alt=';)' />", $string);
		$string = str_replace(":P", "<img src='" . $vars['url'] . "/mod/emoticons/graphics/emoticons/tongue.gif' alt=':P' />", $string);
		$string = str_replace("XD", "<img src='" . $vars['url'] . "/mod/emoticons/graphics/emoticons/pinch.gif' alt='XD' />", $string);

		return $string;
	}

    // Make sure the
		    register_elgg_event_handler('init','system','emoticons_init');

?>