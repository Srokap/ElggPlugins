<?php
/**
 * 
 * @package help
 * @version 0.3.0
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author (basic version) Cash [http://community.elgg.org/pg/profile/costelloc]
 * @author (enhanced version) BogieDE [http://community.elgg.org/pg/profile/BogieDE]
 * @copyright Cach & BogieDE
 * 
 */
 
?>
<div class="contentWrapper">

<?php

// ********************************************************************************************* //
// *** here we will show all questions of the categories s link to the answer below          *** //
// ********************************************************************************************* //

// Category as written in the sidebar //
$numA = elgg_echo('help:faq:0') + 1;
$cntA = 1;
while($cntA < $numA)
{
  
  echo '<div class="overview_tool" id="faq'. $cntA .'">';
  echo '<h3><a href="#f'. $cntA .'">'. $cntA .'. '. elgg_echo('help:faq:'.$cntA.':sidebar') .'</a></h3>';
  echo '</div>';

  // Questions for the category //  
  $numB = elgg_echo('help:faq:'.$cntA.':0') + 1;
  $cntB = 1;
  while($cntB < $numB)
  {

    echo '<div class="overview_tool" id="faq'. $cntA .'_'. $cntB.'">';
    echo '<h4><a href="#f'. $cntA .'_'. $cntB.'">'.$cntA.'.'.$cntB.' '. elgg_echo('help:faq:'.$cntA.':'.$cntB.':headline') .'</a></h4>';
    echo '</div>';
    $cntB++; 
  }
  echo "<br>";
  $cntA++;
}

// Link to the top of the page
echo '<a href="#elgg_topbar" >Top</a>';
echo '<br><hr size=1><br>';  

echo '</div>';
echo '<br>';
//echo '<div class="contentWrapper">';
// ********************************************************************************************* //
// *** now all the questions and answers                                                     *** //
// ********************************************************************************************* //
// Category as written in the sidebar //
$numA = elgg_echo('help:faq:0') + 1;
$cntA = 1;
while($cntA < $numA)
{
	echo '<div class="contentWrapper">';
  echo '<div class="overview_tool" id="f'. $cntA .'">';
  echo '<h3>'. elgg_echo('help:faq:'.$cntA.':sidebar') .'</h3>';
  echo '</div>';
 
  // Questions for the category //  
  $numB = elgg_echo('help:faq:1:0') + 1;
  $cntB = 1;
  while($cntB < $numB)
  {
    echo '<div class="overview_tool" id="f'. $cntA .'_'. $cntB.'">';
    echo '<h4>'.$cntA.'.'.$cntB.' '. elgg_echo('help:faq:'.$cntA.':'.$cntB.':headline') .'</h4>';
    echo '<p>'. str_replace( "__URL__", $vars['url'], elgg_echo('help:faq:'.$cntA.':'.$cntB.':text')) .'</p>';
    echo '</div>';
    // Link to the top of the page
    echo '<a href="#elgg_topbar" >Top</a>';
    echo '<br><hr size=1><br>';  
    $cntB++; 
  }
  echo '</div>';
  echo "<br>";
  $cntA++;
  
}
// Link to the top of the page
echo '<a href="#elgg_topbar" > Top</a>';
echo '<br><hr size=1><br>';  

?>