<?php
/**
 * 
 * @package help
 * @version 0.3.0
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author (basic version) Cash [http://community.elgg.org/pg/profile/costelloc]
 * @author (enhanced version) BogieDE [http://community.elgg.org/pg/profile/BogieDE]
 * @copyright Cach & BogieDE
 * 
 */
 
?>
<div id="owner_block">
<div id="owner_block_submenu">
<div class="submenu_group">
<div class="submenu_group_a">
	<ul>
		<?php
		$num = elgg_echo('help:overview:0') + 1;
    $cnt = 1;
    while($cnt < $num)
    {
    	echo '<li ><a href="#help'. $cnt .'" >'. elgg_echo('help:overview:'.$cnt.':headline').'</a></li>';
      $cnt++;
    }
?>		
	</ul>
</div>
</div>
</div>
</div>