<?php
/**
 * 
 * @package help
 * @version 0.3.0
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author (basic version) Cash [http://community.elgg.org/pg/profile/costelloc]
 * @author (enhanced version) BogieDE [http://community.elgg.org/pg/profile/BogieDE]
 * @copyright Cach & BogieDE
 * 
 */
	$help_menu['Overview'] = $vars['url'] . 'pg/help/overview';
	$help_menu['FAQ'] = $vars['url'] . 'pg/help/faq';
?>
<ul class="topbardropdownmenu" id="helpmenu">
	<li class="drop"><a href="#" class="menuitemtools"><?php echo(elgg_echo('help')); ?></a>
		<ul>
<?php
			foreach($help_menu as $key=>$value) 
			{
				echo "<li><a href=\"{$value}\">" . elgg_echo("help:".strtolower($key)) . "</a></li>";
			} 
?>
		</ul>
	</li>
</ul>