#helpmenu {
margin-left:145px;
}
