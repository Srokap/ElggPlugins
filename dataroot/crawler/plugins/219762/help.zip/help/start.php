<?php
/**
 * 
 * @package help
 * @version 0.3.0
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author (basic version) Cash [http://community.elgg.org/pg/profile/costelloc]
 * @author (enhanced version) BogieDE [http://community.elgg.org/pg/profile/BogieDE]
 * @copyright Cach & BogieDE
 * 
 */
 
	function help_plugin_init() 
	{
		extend_view('css', 'help/css');
		
		register_page_handler('help','help_page_handler');
	}


	function help_page_handler($page) 
	{
		
		if ($page[0])
		{
			switch ($page[0])
			{
				case "overview":
					include(dirname(__FILE__) . "/overview.php");
					break;
				case "faq":
					include(dirname(__FILE__) . "/faq.php");
					break;
				default: 
					break;
			}
		}
	}

	register_elgg_event_handler('init','system','help_plugin_init');
?>