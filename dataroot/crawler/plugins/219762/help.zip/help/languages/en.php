<?php
	$english = array(
	
		'help' => "Help",
		'help:faq' => "Frequently Asked Questions",
		'help:overview' => "Overview",
		'help:gotop' => "top",
			
		'help:overview:0' => "4",              // COUNTER
		
		'help:overview:1:headline' => "Dashboard",
		'help:overview:1:text'     => "The Dashboard is your personal area to play with widgets, keep up with what you want with the widgets you choose to enable there.",
		
	  'help:overview:2:headline' => "Profile",
		'help:overview:2:text'     => "The profile is a place to express yourself, use widgets to show your interests and keep track of activity through the site, and post various things you wish to about yourself.",
		
		'help:overview:3:headline' => "Files",
		'help:overview:3:text'     => "The Files are a place to upload whatever file you wish, within legal and reasonable limits.  Please do not attempt to upload unusually large files or anything of an illegal nature which would endanger this site.",
		
		'help:overview:4:headline' => "Groups",
		'help:overview:4:text'     => "The Groups are a place to upload files, make image galleries, network with those of like mind (or who have similar interests), and even to express your interests by forming your own groups. ",
		
		
		
    // Sidebar Menu 1 //
    'help:faq:0'            => "4",        // COUNTER
    'help:faq:1:sidebar'    => "General FAQs",
    
    // Sidebar Menu 1 -> Q1
    'help:faq:1:0'          => "3",        // COUNTER
    'help:faq:1:1:headline' => "How do I edit my profile?",
    'help:faq:1:1:text'     => "First, get to your profile by clicking on the small box to the left of the dashboard link.  Then you click on edit details.  Fill out your details, save at the bottom of the page, and you're done!",
    
    // Sidebar Menu 1 -> Q2
    'help:faq:1:2:headline' => "How do I edit my icon?",
    'help:faq:1:2:text'     => "Click on edit details and then click on edit profile icon.  Upload your image, then use the handy tool to make a square icon image at the bottom of the page.  Save and you're done! Note: you can also edit your default icon through the setting link at the top of the page with pretty much the same procedure.",
    
    // Sidebar Menu 1 -> Q3
    'help:faq:1:3:headline' => "What do I do with the widgets and how do I use them?",
    'help:faq:1:3:text'     => "Click on edit page (either on your profile page or on your dashboard) and drag the widgets you want to use to the spot you want to put them in.  Save and you're good to go.  Some modules require you to enter information into them.... click on the widget in question (for instance, any of the video includers), enter the information requested, and save. Your widgets are ready to use.",
    
    
    // Sidebar Menu 2 //
    'help:faq:2:sidebar'  => "Settings FAQs",
    
    // Sidebar Menu 2 -> Q1
    'help:faq:2:0'          => "3",       // COUNTER
    'help:faq:2:1:headline' => "How do I change my name or details?",
    'help:faq:2:1:text'     => "Click on settings at the top of the page.  Enter the information you wish to update and then save at the bottom of the page.",
    
    // Sidebar Menu 2 -> Q2
    'help:faq:2:2:headline' => "What does <i>default settings</i> mean?",
    'help:faq:2:2:text'     => "The default settings are the standard settings that will be used if you don't change anything.",
    
    // Sidebar Menu 2 -> Q3          
    'help:faq:2:3:headline' => "How do I configure my tools?",
    'help:faq:2:3:text'     => "Click on configure my tools and you can configure those tools that we have found for you to use.",
    
    
    // Sidebar Menu 3 //
    'help:faq:3:sidebar'  => "Tools FAQs",
    
    // Sidebar Menu 3 -> Q1
    'help:faq:3:0'          => "3",      // COUNTER
    'help:faq:3:1:headline' => "What can I do with my toolbar?",
    'help:faq:3:1:text'     => "Try clicking on the various links as we are continuously adding new functionality to the toolbar. Most of the functions are self-explanatory.  Some are links to show you various other members of the site and to interact with them in various ways.  Some are tools we have included to either amuse you or to help you in various ways.",
    
    // Sidebar Menu 3 -> Q2
    'help:faq:3:2:headline' => "How do I upload a file or picture?",
    'help:faq:3:2:text'     => "Just like most sites, anyplace where you can upload a file or picture will have an upload form.  Use it like any other upload form, include a title (and description and/or keywords if you wish), set your access permissions and save!",
    
    // Sidebar Menu 3 -> Q3 3
    'help:faq:3:3:headline' => "What is the Pages link for and how do I use it?",
    'help:faq:3:3:text'     => "The pages link is a place for you to post whatever you want.  It will show up in the Pages area of the site.  Somewhat like a blog, but with a little more functionality.  Pages are generally available all through the site.  You can set your pages to be accessible by just you, by logged in users, or by the public.  You can also choose whether the page is editable only by you, by logged in users, or if it is open to be publically edited.  ",

    // Sidebar Menu 4 //
    'help:faq:4:sidebar'  => "Additional FAQs",
    
    // Sidebar Menu 4 -> Q1
    'help:faq:4:0'          => "3",      // COUNTER
    'help:faq:4:1:headline' => "User submitted questions will go here.",
    'help:faq:4:1:text'     => "Answers to user submitted questions will go here.",

    // Sidebar Menu 4 -> Q2
    'help:faq:4:2:headline' => "User submitted questions will go here.",
    'help:faq:4:2:text'     => "Answers to user submitted questions will go here.",
    
    // Sidebar Menu 4 -> Q3 
    'help:faq:4:3:headline' => "User submitted questions will go here.",
    'help:faq:4:3:text'     => "Answers to user submitted questions will go here.",

	);
	add_translation("en",$english);
?>