<?php
	$spanish = array(

		/**
		 * Sites
		 */
	
			'item:site' => 'Lugares',
	
		/**
		 * Sessions
		 */
			
			'login' => 'Entrar',
			'loginok' => 'Ha entrado en nuestro espacio.',
			'loginerror' => 'No puede logarse. Esto ocurre porque  no tiene aun su cuenta activada, o los detalles suministrados son incorrectos. Garantice que los datos son v&aacute;lidos e int&eacute;ntelo de nuevo.',
			'logout' => 'Salir',
			'logoutok' => 'Acaba de salir de la red, muchas gracias',
			'logouterror' => 'No podemos realizar la salida, por favor intente de nuevo',
		/**
		 * Errors
		 */
			'exception:title' => "Welcome to Elgg.",
	
			'InstallationException:CantCreateSite' => "Unable to create a default ElggSite with credentials Name:%s, Url: %s",
		
			'actionundefined' => "The requested action (%s) was not defined in the system.",
			'actionloggedout' => "Lo lamento, no puede realizar esta acci&oacute;n mientras no se haya conectado",
	
			'notfound' => "El recurso solicitado no puede ser encontrado, o no tiene acceso al mismo.",
			
			'SecurityException:Codeblock' => "Denied access to execute privileged code block",
			'DatabaseException:WrongCredentials' => "Elgg couldn't connect to the database using the given credentials %s@%s (pw: %s).",
			'DatabaseException:NoConnect' => "Elgg couldn't select the database '%s', please check that the database is created and you have access to it.",
			'SecurityException:FunctionDenied' => "Access to privileged function '%s' is denied.",
			'DatabaseException:DBSetupIssues' => "There were a number of issues: ",
			'DatabaseException:ScriptNotFound' => "Elgg couldn't find the requested database script at %s.",
			
			'IOException:FailedToLoadGUID' => "Failed to load new %s from GUID:%d",
			'InvalidParameterException:NonElggObject' => "Passing a non-ElggObject to an ElggObject constructor!",
			'InvalidParameterException:UnrecognisedValue' => "Unrecognised value passed to constuctor.",
			
			'InvalidClassException:NotValidElggStar' => "GUID:%d is not a valid %s",
			
			'PluginException:MisconfiguredPlugin' => "%s is a misconfigured plugin.",
			
			'InvalidParameterException:NonElggUser' => "Passing a non-ElggUser to an ElggUser constructor!",
			
			'InvalidParameterException:NonElggSite' => "Passing a non-ElggSite to an ElggSite constructor!",
			
			'InvalidParameterException:NonElggGroup' => "Passing a non-ElggGroup to an ElggGroup constructor!",
	
			'IOException:UnableToSaveNew' => "Unable to save new %s",
			
			'InvalidParameterException:GUIDNotForExport' => "GUID has not been specified during export, this should never happen.",
			'InvalidParameterException:NonArrayReturnValue' => "Entity serialisation function passed a non-array returnvalue parameter",
			
			'ConfigurationException:NoCachePath' => "Cache path set to nothing!",
			'IOException:NotDirectory' => "%s is not a directory.",
			
			'IOException:BaseEntitySaveFailed' => "Unable to save new object's base entity information!",
			'InvalidParameterException:UnexpectedODDClass' => "import() passed an unexpected ODD class",
			'InvalidParameterException:EntityTypeNotSet' => "Entity type must be set.",
			
			'ClassException:ClassnameNotClass' => "%s is not a %s.",
			'ClassNotFoundException:MissingClass' => "Class '%s' was not found, missing plugin?",
			'InstallationException:TypeNotSupported' => "Type %s is not supported. This indicates an error in your installation, most likely caused by an incomplete upgrade.",

			'ImportException:ImportFailed' => "Could not import element %d",
			'ImportException:ProblemSaving' => "There was a problem saving %s",
			'ImportException:NoGUID' => "New entity created but has no GUID, this should not happen.",
			
			'ImportException:GUIDNotFound' => "Entity '%d' could not be found.",
			'ImportException:ProblemUpdatingMeta' => "There was a problem updating '%s' on entity '%d'",
			
			'ExportException:NoSuchEntity' => "No such entity GUID:%d", 
			
			'ImportException:NoODDElements' => "No OpenDD elements found in import data, import failed.",
			'ImportException:NotAllImported' => "Not all elements were imported.",
			
			'InvalidParameterException:UnrecognisedFileMode' => "Unrecognised file mode '%s'",
			'InvalidParameterException:MissingOwner' => "All files must have an owner!",
			'IOException:CouldNotMake' => "Could not make %s",
			'IOException:MissingFileName' => "You must specify a name before opening a file.",
			'ClassNotFoundException:NotFoundNotSavedWithFile' => "Filestore not found or class not saved with file!",
			'NotificationException:NoNotificationMethod' => "No notification method specified.",
			'NotificationException:NoHandlerFound' => "No handler found for '%s' or it was not callable.",
			'NotificationException:ErrorNotifyingGuid' => "There was an error while notifying %d",
			'NotificationException:NoEmailAddress' => "Could not get the email address for GUID:%d",
			'NotificationException:MissingParameter' => "Missing a required parameter, '%s'",
			
			'DatabaseException:WhereSetNonQuery' => "Where set contains non WhereQueryComponent",
			'DatabaseException:SelectFieldsMissing' => "Fields missing on a select style query",
			'DatabaseException:UnspecifiedQueryType' => "Unrecognised or unspecified query type.",
			'DatabaseException:NoTablesSpecified' => "No tables specified for query.",
			'DatabaseException:NoACL' => "No access control was provided on query",
			
			'InvalidParameterException:NoEntityFound' => "No entity found, it either doesn't exist or you don't have access to it.",
			
			'InvalidParameterException:GUIDNotFound' => "GUID:%s could not be found, or you can not access it.",
			'InvalidParameterException:IdNotExistForGUID' => "Sorry, '%s' does not exist for guid:%d",
			'InvalidParameterException:CanNotExportType' => "Sorry, I don't know how to export '%s'",
			'InvalidParameterException:NoDataFound' => "Could not find any data.",
			'InvalidParameterException:DoesNotBelong' => "Does not belong to entity.",
			'InvalidParameterException:DoesNotBelongOrRefer' => "Does not belong to entity or refer to entity.",
			'InvalidParameterException:MissingParameter' => "Missing parameter, you need to provide a GUID.",
			
			'SecurityException:APIAccessDenied' => "Sorry, API access has been disabled by the administrator.",
			'SecurityException:NoAuthMethods' => "No authentication methods were found that could authenticate this API request.",
			'APIException:ApiResultUnknown' => "API Result is of an unknown type, this should never happen.", 
			
			'ConfigurationException:NoSiteID' => "No site ID has been specified.",
			'InvalidParameterException:UnrecognisedMethod' => "Unrecognised call method '%s'",
			'APIException:MissingParameterInMethod' => "Missing parameter %s in method %s",
			'APIException:ParameterNotArray' => "%s does not appear to be an array.",
			'APIException:UnrecognisedTypeCast' => "Unrecognised type in cast %s for variable '%s' in method '%s'",
			'APIException:InvalidParameter' => "Invalid parameter found for '%s' in method '%s'.",
			'APIException:FunctionParseError' => "%s(%s) has a parsing error.",
			'APIException:FunctionNoReturn' => "%s(%s) returned no value.",
			'SecurityException:AuthTokenExpired' => "Authentication token either missing, invalid or expired.",
			'CallException:InvalidCallMethod' => "%s must be called using '%s'",
			'APIException:MethodCallNotImplemented' => "Method call '%s' has not been implemented.",
			'APIException:AlgorithmNotSupported' => "Algorithm '%s' is not supported or has been disabled.",
			'ConfigurationException:CacheDirNotSet' => "Cache directory 'cache_path' not set.",
			'APIException:NotGetOrPost' => "Request method must be GET or POST",
			'APIException:MissingAPIKey' => "Missing X-Elgg-apikey HTTP header",
			'APIException:MissingHmac' => "Missing X-Elgg-hmac header",
			'APIException:MissingHmacAlgo' => "Missing X-Elgg-hmac-algo header",
			'APIException:MissingTime' => "Missing X-Elgg-time header",
			'APIException:TemporalDrift' => "X-Elgg-time is too far in the past or future. Epoch fail.",
			'APIException:NoQueryString' => "No data on the query string",
			'APIException:MissingPOSTHash' => "Missing X-Elgg-posthash header",
			'APIException:MissingPOSTAlgo' => "Missing X-Elgg-posthash_algo header",
			'APIException:MissingContentType' => "Missing content type for post data",
			'SecurityException:InvalidPostHash' => "POST data hash is invalid - Expected %s but got %s.",
			'SecurityException:DupePacket' => "Packet signature already seen.",
			'SecurityException:InvalidAPIKey' => "Invalid or missing API Key.",
			'NotImplementedException:CallMethodNotImplemented' => "Call method '%s' is currently not supported.",
	
			'NotImplementedException:XMLRPCMethodNotImplemented' => "XML-RPC method call '%s' not implemented.",
			'InvalidParameterException:UnexpectedReturnFormat' => "Call to method '%s' returned an unexpected result.",
			'CallException:NotRPCCall' => "Call does not appear to be a valid XML-RPC call",
	
			'PluginException:NoPluginName' => "The plugin name could not be found",
	
			'ConfigurationException:BadDatabaseVersion' => "The database backend you have installed doesn't meet the basic requirements to run Elgg. Please consult your documentation.",
			'ConfigurationException:BadPHPVersion' => "You need at least PHP version 5.2 to run Elgg.",
			'configurationwarning:phpversion' => "Elgg requires at least PHP version 5.2, you can install it on 5.1.6 but some features may not work. Use at your own risk.",
	
	
			'InstallationException:DatarootNotWritable' => "Your data directory %s is not writable.",
			'InstallationException:DatarootUnderPath' => "Your data directory %s must be outside of your install path.",
			'InstallationException:DatarootBlank' => "You have not specified a data directory.",
	
			'SecurityException:authenticationfailed' => "User could not be authenticated",
	
			'CronException:unknownperiod' => '%s is not a recognised period.',
	
			'SecurityException:deletedisablecurrentsite' => 'You can not delete or disable the site you are currently viewing!',
		/**
		 * API
		 */
			'system.api.list' => "List all available API calls on the system.",
			'auth.gettoken' => "This API call lets a user log in, returning an authentication token which can be used in leu of a username and password for authenticating further calls.",
	
		/**
		 * User details
		 */

			'name' => "Nombre",
			'email' => "Correo electr&oacute;nico",
			'username' => "Usuari@",
			'password' => "Clave",
			'passwordagain' => "Clave (int&eacute;ntelo de nuevo para verificar)", 
			'admin_option' => "Hacer este usuario administrador",
	
		/**
		 * Access
		 */
	
			'ACCESS_PRIVATE' => "Privado",
			'ACCESS_LOGGED_IN' => "Usuari@s logados",
			'ACCESS_PUBLIC' => "P&uacute;blico",
			'PRIVATE' => "Privado",
			'LOGGED_IN' => "Usuari@s logados",
			'PUBLIC' => "Publico",
			'access' => "Acceso",
			'access:friends:label' => "Amig@s",

		/**
		 * Dashboard and widgets
		 */
	
			'dashboard' => "Escritorio",
            'dashboard:configure' => "Editar la p&aacute;gina",
			'dashboard:nowidgets' => "Su escritorio es la pasarela a su lugar. Pulse 'Editar la p&aacute;gina para a&ntilde;adir componentes para mantener una personalización de su escritori.",

			'widgets:add' => 'A&ntilde;adir componentes a su p&aacute;gina',
			'widgets:add:description' => "Seleccione las caracter&iacute;sticas que quiere a&ntilde;adir a su p&aacute;gina arrastrando desde la <b>galer&iacute;a de componentes</b> de la dereca, a cualquier &aacute;rea de abajo, y posici&oacute;nelo en el lugar que guste.

Para elminar el componente arrastelo fuera de la <b>galer&iacute;a de componentes</b>.",
			'widgets:position:fixed' => '(Posici&oacute;n fija en la p&aacute;gina)',
	
			'widgets' => "Componentes",
			'widget' => "Componente",
			'item:object:widget' => "Componentes",
			'layout:customise' => "Personalice las capas",
			'widgets:gallery' => "Galer&iacute;a de componentes",
			'widgets:leftcolumn' => "Componentes izquierdos",
			'widgets:fixed' => "Posici&oacute;n fijada",
			'widgets:middlecolumn' => "Componentes del centro",
			'widgets:rightcolumn' => "Componentes derechos",
			'widgets:profilebox' => "Cuadro de perfiles",
			'widgets:panel:save:success' => "Sus componentes han sido exitosamente guardados.",
			'widgets:panel:save:failure' => "Existe algun problema al grabar los componentes. Int&eacute;ntelo de nuevo por favor.",
			'widgets:save:success' => "El componente ha sido guardado exitosamente.",
			'widgets:save:failure' => "No podemos guardar sus componentes. Por favor int&eacute;telo de nuevo.",
			'widgets:handlernotfound' => 'Este componente puede estar roto o ha sido deshabilitado por el administrador.',

	
		/**
		 * Groups
		 */
	
			'group' => "Grupo", 
			'item:group' => "Grupos",
	
		/**
		 * Profile
		 */
	
			'profile' => "Perfil",
			'profile:edit:default' => 'Sustituir campos del perfil',
			'user' => "Usuari@",
			'item:user' => "Ususari@s",
			'riveritem:single:user' => 'un usuari@',
			'riveritem:plural:user' => 'algunos usuari@s',

		/**
		 * Profile menu items and titles
		 */
	
			'profile:yours' => "Su perfil",
			'profile:user' => "Perfil de %s",
	
			'profile:edit' => "Editar su perfil",
			'profile:profilepictureinstructions' => "La imagen del perfil no se puede mostrar en su p&aacute;gina. <br/> Puede cambiarlo cuando guste. (El formato del fichero s&oacute;lo acepta: GIF, JPG o PNG)",
			'profile:icon' => "Imagen del perfil",
			'profile:createicon' => "Crear su avatar",
			'profile:currentavatar' => "Avatar actual",
			'profile:createicon:header' => "Imagen del perfil",
			'profile:profilepicturecroppingtool' => "Herramienta de ajuste de la imagen de su perfil",
			'profile:createicon:instructions' => "Arraste al cuadro justo de abajo para encajar la imagen al marte. Vera una vista previa en la caja de la derecha. Cuando est&eacute; satisfeco de como queda, pulse 'Crear su avatar'. Esta imagen ajustada ser&aacute mostrada. ",
	
			'profile:editdetails' => "Editar detalles",
			'profile:editicon' => "Editar el icono de su perfil",
	
			'profile:aboutme' => "Acerca de m&iacute;", 
			'profile:description' => "Acerca de m&iacute;",
			'profile:briefdescription' => "Descripci&oacute;n breve",
			'profile:location' => "Ubicaci&oacute;n",
			'profile:skills' => "Temas",  
			'profile:interests' => "Intereses", 
			'profile:contactemail' => "Email de contacto",
			'profile:phone' => "Tel&eacute;fono",
			'profile:mobile' => "M&oacute;vil",
			'profile:website' => "Sitio web",

			'profile:banned' => 'Este usuario ha sido suspendido.',

			'profile:river:update' => "%s han actualizado sus perfiles",
			'profile:river:iconupdate' => "%s han actualizado el icono de su perfil",
	
			'profile:label' => "Etiqueta del perfil",
			'profile:type' => "Tipo del perfil",
	
			'profile:editdefault:fail' => 'El perfil por defecto no puede ser guardado',
			'profile:editdefault:success' => 'Art&iacute;culo a&ntilde;adido con &eacute;xito en su perfil por defecto',
	
			
			'profile:editdefault:delete:fail' => 'Fallo en la eliminaci&oacute;n del art&iacute;culo del perfil por defecto',
			'profile:editdefault:delete:success' => 'Item del perfil por defecto eliminado!',
	
			'profile:defaultprofile:reset' => 'Perfil por defecto al del sistema reseteado',
	
			'profile:resetdefault' => 'Resetear el perfil por defecto',
	
		/**
		 * Profile status messages
		 */
	
			'profile:saved' => "Su perfil ha sido correctamente guardado.",
			'profile:icon:uploaded' => "Su imagen ha sido correctamente actualizada.",
	
		/**
		 * Profile error messages
		 */
	
			'profile:noaccess' => "No tiene permiso para editar este perfil.",
			'profile:notfound' => "Lo lamento, no puede encontrar ese perfil espec&iacute;fico.",
			'profile:cantedit' => "Lo lamento, no tiene permisos para editar este perfil.",
			'profile:icon:notfound' => "Lo lamento, hay algunos problemas en la subida de su imagen.",
	
		/**
		 * Friends
		 */
	
			'friends' => "Amigos",
			'friends:yours' => "Sus amigos",
			'friends:owned' => "Mis %s amigos",
			'friend:add' => "A&ntilde;adir amigo",
			'friend:remove' => "Eliminar amigo",	
			'friends:add:successful' => "Ha a&ntilde;adido %s amigos.",
			'friends:add:failure' => "No podemos a&ntilde;adir los %s amigos. Por favor int&eacute;ntelo.",
	
			'friends:remove:successful' => "Ha eliminado %s amigos.",
			'friends:remove:failure' => "No podemos elminar %s emigos. Por favor int&eacute;ntelo de nuevo.",
	
			'friends:none' => "Este usuario no ha sido a&ntilde;adido a ningo de sus amigos aun.",
			'friends:none:you' => "No ha a&ntilde;adido a nadie como amigo, Busque por gente que tenga su mismo inter&eacute;s y seguirle.",
	
			'friends:none:found' => "No se ha encontrado amigos.",
	
			'friends:of:none' => "Nadie ha a&ntilde;adido este usuario como amigo aun.",
			'friends:of:none:you' => "Nobody le ha a&ntilde;adido como amigo aun. Comience con a&ntilde;adir contenido y rellenar su perfil para permitir que la gente le encuentre.",
	
			'friends:of' => "Amigo de",
			'friends:of:owned' => "Gente que ha hecho %s amigos",

			 'friends:num_display' => "N&uacute;mero de amigos a mostrar",
			 'friends:icon_size' => "Tama&ntilde;o del icono",
			 'friends:tiny' => "diminuto",
			 'friends:small' => "peque&ntilde;o",
			 'friends' => "Amigos",
			 'friends:of' => "Amigos de",
			 'friends:collections' => "Lista de amigos",
			 'friends:collections:add' => "Nueva lista de amigos",
			 'friends:addfriends' => "A&ntilde;adir amigos",
			 'friends:collectionname' => "Lista de nombres",
			 'friends:collectionfriends' => "Amigos en la lista",
			 'friends:collectionedit' => "Edita esta lista",
			 'friends:nocollections' => "No tiene aun ninguna lista.",
			 'friends:collectiondeleted' => "Su lista ha sido borrada.",
			 'friends:collectiondeletefailed' => "Ha sido imposible eliminar la lista. No tiene permisos, o algun otro problema ha ocurrido.",
			 'friends:collectionadded' => "Su colecci&oacute;n se ha creado correctamente",
			 'friends:nocollectionname' => "Necesita asignar un nombre a su lista antes de ser creada.",
			 'friends:collections:members' => "Colecci&oacute;n de amigas",
			 'friends:collections:edit' => "Editar la colecci&oacute;n",


	        'friends:river:created' => "%s componentes de amigos a&ntilde;adidos",
		'friends:river:updated' => "%s componentes de sus amigos actualizados.",
	        'friends:river:delete' => "%s componentes de sus amigos eliminados.",
	        'friends:river:add' => "%s amigos a&ntilde;adidos por alguien.",
	
		/**
		 * Feeds
		 */
			'feed:rss' => 'Subscribirse al feed',
			'feed:odd' => 'Syndicarse a OpenDD',
			
		/**
          * links
		 **/

			'link:view' => 'ver enlace',

	
		/**
		 * River
		 */
			'river' => "Relaciones",//"River",			
			'river:relationship:friend' => 'en este momento es amigo de ',
			'river:noaccess' => 'No tiene permisos para ver este item.',
			'river:posted:generic' => '%s enviado',



		/**
		 * Plugins
		 */
			'plugins:settings:save:ok' => "Configuraciones por los %s plugins que han sido guardado satisfactoriamente.",
			'plugins:settings:save:fail' => "Se ha dado un problema a la hora de guardar la configuraciones de los %s plugins.",
			'plugins:usersettings:save:ok' => "La configuraci&oacute;n del usuario para los %s plugins han sido correctamente guardados.",
			'plugins:usersettings:save:fail' => "Ha habido un problema al guardas la configuraci&oacute;n de los %s plugins.",
			'admin:plugins:label:version' => "Version",
			'item:object:plugin' => 'Configuraci&oacute;n de plugins',
			
		/**
		 * Notifications
		 */
			'notifications:usersettings' => "Configuraci&oacute;n de las notificaciones",
			'notifications:methods' => "Por favor, especifique cu&aacute;les m&eacute;todos quiere permitir.",
	
			'notifications:usersettings:save:ok' => "La configuraci&oacute;n de  notificaciones han sido guardadas.",
			'notifications:usersettings:save:fail' => "No se ha podido guardar la configuraci&oacute;n de la notifiaci&oacute;n.",
	
			'user.notification.get' => 'Devolver la configuraci&oacute;n de la notificaci&oacute;n a la usuaria.',
			'user.notification.set' => 'Conjunto de notificaciones configuradas para  lausuaria.',
		/**
		 * Search
		 */
	
			'search' => "Buscar",
			'searchtitle' => "Buscar: %s",
			'users:searchtitle' => "Buscando para usuarios: %s",
			'advancedsearchtitle' => "%s con resultados coincidentes  %s",
			'notfound' => "No se ha encontrado resultados.",
			'next' => "Siguiente",
			'previous' => "Anterior",
	
			'viewtype:change' => "Cambiar el tipo de listado",
			'viewtype:list' => "Vista de la lista",
			'viewtype:gallery' => "Galer&iacute;a",
	
			'tag:search:startblurb' => "'%s' Art&iacute;culos encontrados con ese tag:",

			'user:search:startblurb' => "Usuarias coincidentes '%s':",
			'user:search:finishblurb' => "Para ver m&aacute;s, pulse aqu&iacute;.",
	
		/**
		 * Account
		 */
	
			'account' => "Cuenta",
			'settings' => "Configuraci&oacute;n",
            'tools' => "Herramientas",
            'tools:yours' => "Sus herramientas",
	
			'register' => "Registro",
			'registerok' => "Se ha registrado para %s exitosamente.",
			'registerbad' => "Su registro no ha sido v&aacute;lido. El usuario puede existir, su clave puede no coincidir, o el usuario o clave puede ser peque&ntilde;as",
			'registerdisabled' => "El registro a sido desabilitado por el administrador de sistemas",
	
			'registration:notemail' => 'El email que ha introducido no parece ser uno v&aacute;lido.',
			'registration:userexists' => 'Ese usuario aun existe',
			'registration:usernametooshort' => 'Su usuario debe tener un m&iacute;nimo de 4 caracteres.',
			'registration:passwordtooshort' => 'La clave debe tener un m&iacute;nimo de 6 caracteres',
			'registration:dupeemail' => 'Este email est&aacute; asociado a otra cuenta.',
			'registration:invalidchars' => 'Lo lamento, el usuario tiene caracteres inv&aacute;lidos.',
			'registration:emailnotvalid' => 'Lo lamento, el email que a introducido es inv&aacute;lido para el sistema',
			'registration:passwordnotvalid' => 'Lo lamento, la clave que a introducido es inv&aacute;lida para el sistema',
			'registration:usernamenotvalid' => 'Lo lamento, el usuario que a introducido es inv&aacute;lido para el sistema',
	
			'adduser' => "A&ntilde;adir usuario",
			'adduser:ok' => "Acaba de a&ntilde;adir un nuevo usuario.",
			'adduser:bad' => "El usuario nuevo no puede ser creado.",
			
			'item:object:reported_content' => "Art&iacute;culos pulbicados",
	
			'user:set:name' => "Configuraci&oacute;n de la cuenta",
			'user:name:label' => "Su nombre",
			'user:name:success' => "Se a cambiado su nombre en el sistema.",
			'user:name:fail' => "No se ha podido cambiar su nombre en el sistema.",
	
			'user:set:password' => "Clave de la cuenta",
			'user:password:label' => "Su nueva clave",
			'user:password2:label' => "Su nueva clave de nuevo",
			'user:password:success' => "Clave cambiada",
			'user:password:fail' => "No se a podido cambiar la clave del sistema.",
			'user:password:fail:notsame' => "No coinciden las claves",
			'user:password:fail:tooshort' => "Claves muy peque&ntilde;as",
	
			'user:set:language' => "Configuraci&oacute;n del idioma",
			'user:language:label' => "Su idioma",
			'user:language:success' => "Su idioma ha sido actualizado.",
			'user:language:fail' => "Su idioma no se ha podido guardar.",
	
			'user:username:notfound' => 'Usuario %s no encontrado.',
	
			'user:password:lost' => 'Clave olvidada',
			'user:password:resetreq:success' => 'La nueva clave ha sido enviada a su correo',
			'user:password:resetreq:fail' => 'No puedo generar una nueva clave.',
	
			'user:password:text' => 'Para generar una nueva clave, introduzca su usuario abajo. Le enviaremos a su email una verificación &uacute;nica cn informaci&oacute;n de la clae.',
	
			'user:persistent' => 'Recordarlo',
		/**
		 * Administration
		 */

			'admin:configuration:success' => "Su configuraci&oacute;n ha sido guardada.",
			'admin:configuration:fail' => "Su configuraci&oacute;n ha podid ser guardada.",
	
			'admin' => "Administraci&oacute;n",
			'admin:description' => "El panel de administraci&oacute;n permite el control de todos los aspectos del sistema, desde la gesti&oacute;n de usuarios hasta como se comporta los plugins. Elija la opci&oacute;n de abajo para comenzar.",
			
			'admin:user' => "Administraci&oacute;n de usuarios",
			'admin:user:description' => "Este panel de administraci&oacute;n permite el control de la configuraci&oacute;n de suario de su red social. Elija la opci&oacute;n adecuada abajo para comenzar.",
			'admin:user:adduser:label' => "Pulse aqu&iacute; para a&ntilde;adir un nueva usuaria...",
			'admin:user:opt:linktext' => "Configure las usuari@s...",
			'admin:user:opt:description' => "Informaci&oacute; de la configuraci&oacute; de usuarios y sus cuentas. ",
			
			'admin:site' => "Lugar de Administraci&oacute;n",
			'admin:site:description' => "Este panel de administraci&oacute; permite controlar la configuraci&oacute;n global de la red social. Elija una opci&oacute;n adecuada para comenzar.",
			'admin:site:opt:linktext' => "Configure el lugar...",
			'admin:site:opt:description' => "Configure t&eacute;cnicamente y no t&eacute;cnicamente del lugar. ",
			
			'admin:plugins' => "Herramientas de Administraci&oacute;n",
			'admin:plugins:description' => "Este administrador de panl permite el contro y configuraci&oacute;n de herramientas instaladas en este lugar.",
			'admin:plugins:opt:linktext' => "Configure las herramientas...",
			'admin:plugins:opt:description' => "Configure las herramientas instaladas en el lugar. ",
			'admin:plugins:label:author' => "Autor",
			'admin:plugins:label:copyright' => "Copyright",
			'admin:plugins:label:licence' => "Licencia",
			'admin:plugins:label:website' => "URL",
			"admin:plugins:label:moreinfo" => 'm&aacute;s info',
			'admin:plugins:reorder:yes' => "Plugin %s se ha reordenado correctamente.",
			'admin:plugins:reorder:no' => "Plugin %s no se a podido reordenar.",
			'admin:plugins:disable:yes' => "Plugin %s se ha deshabilitado correctamente.",
			'admin:plugins:disable:no' => "Plugin %s no puede ser deshabilitado.",
			'admin:plugins:enable:yes' => "Plugin %s ha sido habilitado correctamente.",
			'admin:plugins:enable:no' => "Plugin %s no ha podido habilitarse.",
	
			'admin:statistics' => "Estad&iacute;sticas",
			'admin:statistics:description' => "Esta es una visi&oacute;n previa de las estad&iacute;sticas de su lugar.",
			'admin:statistics:opt:description' => "Ver informaci&oacute;n estad&iacute;stica sobre los usuario sy objetos del sistema.",
			'admin:statistics:opt:linktext' => "Ver estad&iacute;sticas...",
			'admin:statistics:label:basic' => "Estad&iacute;sticas b&aacute;sicas del lugar",
			'admin:statistics:label:numentities' => "Entidades del lugar",
			'admin:statistics:label:numusers' => "N&uacute;mero de usuari@s",
			'admin:statistics:label:numonline' => "N&uacute;mero de usuari@s on line",
			'admin:statistics:label:onlineusers' => "Usuari@s online en este momento",
			'admin:statistics:label:version' => "Versi&oacute;n elgg",
			'admin:statistics:label:version:release' => "Release",
			'admin:statistics:label:version:version' => "Version",
	
			'admin:user:label:search' => "Buscar usuari@s:",
			'admin:user:label:seachbutton' => "Buscar", 
	
			'admin:user:ban:no' => "No puede prohibir al usuari@",
			'admin:user:ban:yes' => "Ususuari@s prohibidos.",
			'admin:user:unban:no' => "No puede liberar alusuari@",
			'admin:user:unban:yes' => "Usuari@ liberad@.",
			'admin:user:delete:no' => "No puede borrar usuari@",
			'admin:user:delete:yes' => "Usuari@ eliminad@",
	
			'admin:user:resetpassword:yes' => "Clave reseteada y notificado al usuari@.",
			'admin:user:resetpassword:no' => "La clave no puede ser reseteada.",
	
			'admin:user:makeadmin:yes' => "El usuario es ahora administrador.",
			'admin:user:makeadmin:no' => "No podemos hacer este usuario administrador.",
                        'admin:user:removeadmin:yes' => "El usuario ya no es administrador.",
			'admin:user:removeadmin:no' => "No podemos eliminar los privilegios de administraci&oacute;n de este usuario.",
		/**
		 * User settings
		 */
			'usersettings:description' => "La configuraci&oacute;n del panel de usuario permite el control de su espacio, desde la gesti&oacute;n de usuarios hasta c&oacute;mo se comporta los plugins. Elija una opci&oaucte;n de abajo para comenzar.",
	
			'usersettings:statistics' => "Su estad&iacute;sticas",
			'usersettings:statistics:opt:description' => "Ver la informaci&oacute;n estad&iacute;stica acerca de los usuarios y objetos del lugar.",
			'usersettings:statistics:opt:linktext' => "Estad&iacute;sticas de la cuenta",
	
			'usersettings:user' => "Su configuraci&oacute;n",
			'usersettings:user:opt:description' => "Esto le permite controlar la configuraci&oacute;n del usuario.",
			'usersettings:user:opt:linktext' => "Cambiar su configuraci&oacute;n",
	
			'usersettings:plugins' => "Herramientas",
			'usersettings:plugins:opt:description' => "Configure la configuraciones para sus herramientas activas.",
			'usersettings:plugins:opt:linktext' => "Configure sus herramientas",
	
			'usersettings:plugins:description' => "Este panel permite el control y configura la configuraci&oacute;n personal para las herramientas instaladas por el administrador de sistemas.",
			'usersettings:statistics:label:numentities' => "Sus entidades",
	
			'usersettings:statistics:yourdetails' => "Sus detalles",
			'usersettings:statistics:label:name' => "Nombre y apellidos",
			'usersettings:statistics:label:email' => "Email",
			'usersettings:statistics:label:membersince' => "Miembro desde",
			'usersettings:statistics:label:lastlogin' => "Ultimo acceso",
	
			
	
		/**
		 * Generic action words
		 */
	
			'save' => "Guardar",
			'publish' => "Publicar",
			'cancel' => "Cancelar",
			'saving' => "Guardando ...",
			'update' => "Actualizar",
			'edit' => "Editar",
			'delete' => "Eliminar",
			'load' => "Cargar",
			'upload' => "Subir",
			'ban' => "Prohibir",
			'unban' => "Liberar",
			'enable' => "Habilitar",
			'disable' => "Deshabilitar",
			'request' => "Solicitar",
			'complete' => "Completado",
			'open' => 'Abierto',
			'close' => 'Cerrado',
			'reply' => "Responder",
                        'more' => 'M&aacute;s',
			'comments' => 'Comentarios',
			'import' => 'Importar',
			'export' => 'Exportar',

			'up' => 'Arriba',
			'down' => 'Abajo',
			'top' => 'Superior',
			'bottom' => 'Inferior',
	
			'invite' => "Invitar",
	
			'resetpassword' => "Resetear clave",
			'makeadmin' => "Hacer admin",
			'removeadmin' => "Eliminar admin",

			'option:yes' => "S&iacute;",
			'option:no' => "No",
	
			'unknown' => 'Desconocido',
	
			'active' => 'Activo',
			'total' => 'Total',
	
			'learnmore' => "Pulse aqu&iacute; para aprender m&aacute;s.",
	
			'content' => "Contenido",
			'content:latest' => '&Uacute;ltimas actividades',
			'content:latest:blurb' => 'Alternativamente, pulse aqu&iacute; para ver los &uacute;ltimos contenidos del lugar.',
	
			'link:text' => 'ver enlace',
	
                        'enableall' => 'Habilitar todo',
			'disableall' => 'Deshabilitar todo',

                /**
			* Generic questions
                */

                         'question:areyousure' => 'Est&acute; segur@?',


		/**
		 * Generic data words
		 */
	
			'title' => "T&iacute;tulo",
			'description' => "Descripci&oacute;n",
			'tags' => "Etiquetas",
			'spotlight' => "Bienvenida a la Red Social de Cuidadoras",
			'all' => "Todos",
	
			'by' => 'por',
	
			'annotations' => "Anotaciones",
			'relationships' => "Relaciones",
			'metadata' => "Metadata",
	
		/**
		 * Input / output strings
		 */

			'deleteconfirm' => "Seguro que quiere eliminar este art&iacute;culo?",
			'fileexists' => "El fichero fue subido. Para reemplazarlo, seleccione abajo:",
			
			
	    /**
       		  * System messages
            **/

			'systemmessages:dismiss' => "Pulse para continuar",

	
	    /**
		 * Import / export
	    */
			'importsuccess' => "La importaci&oacute;n de datos fue correcta",
			'importfail' => "La importación OpenDD fall&oacute;.",
           /**
	         * User add
	   */
                'useradd:subject' => 'Cuenta de usuario creada',
                'useradd:body' => '
%s,
Se ha creado una cuenta de usuario en %s. Para entrar, visite:

	%s

Y para poder participar debe usar las siguientes credenciales:

	Username: %s
	Clave: %s

Una vez que se haya logado, le recomendamos que cambie su clave.
',

		/**
		 * Time
		 */
	
			'friendlytime:justnow' => "justo ahora",
			'friendlytime:minutes' => "hace %s minutos",
			'friendlytime:minutes:singular' => "hace un minuto",
			'friendlytime:hours' => "hace %s horas",
			'friendlytime:hours:singular' => "hace una hora",
			'friendlytime:days' => "hace %s dias",
			'friendlytime:days:singular' => "ayer",
	
                        'date:month:01' => '%s de Enero',
                        'date:month:02' => '%s de Febrero',
                        'date:month:03' => '%s de Marzo',
                        'date:month:04' => '%s de Abril',
                        'date:month:05' => '%s de Mayo',
                        'date:month:06' => '%s de Junio',
                        'date:month:07' => '%s de Julio',
                        'date:month:08' => '%s de Agosto',
                        'date:month:09' => '%s de Septiembre',
                        'date:month:10' => '%s de Octubre',
                        'date:month:11' => '%s de Noviembre',
                        'date:month:12' => '%s de Diciembre',


		/**
		 * Installation and system settings
		 */
	
			'installation:error:htaccess' => "Elgg requires a file called .htaccess to be set in the root directory of its installation. We tried to create it for you, but Elgg doesn't have permission to write to that directory. 

Creating this is easy. Copy the contents of the textbox below into a text editor and save it as .htaccess

",
			'installation:error:settings' => "Elgg couldn't find its settings file. Most of Elgg's settings will be handled for you, but we need you to supply your database details. To do this:

1. Rename engine/settings.example.php to settings.php in your Elgg installation.

2. Open it with a text editor and enter your MySQL database details. If you don't know these, ask your system administrator or technical support for help.

Alternatively, you can enter your database settings below and we will try and do this for you...",
	
			'installation:error:configuration' => "Once you've corrected any configuration issues, press reload to try again.",
	
			'installation' => "Installation",
			'installation:success' => "Elgg's database was installed successfully.",
			'installation:configuration:success' => "Your initial configuration settings have been saved. Now register your initial user; this will be your first system administrator.",
	
			'installation:settings' => "System settings",
			'installation:settings:description' => "Now that the Elgg database has been successfully installed, you need to enter a couple of pieces of information to get your site fully up and running. We've tried to guess where we could, but <b>you should check these details.</b>",
	
			'installation:settings:dbwizard:prompt' => "Enter your database settings below and hit save:",
			'installation:settings:dbwizard:label:user' => "Database user",
			'installation:settings:dbwizard:label:pass' => "Database password",
			'installation:settings:dbwizard:label:dbname' => "Elgg database",
			'installation:settings:dbwizard:label:host' => "Database hostname (usually 'localhost')",
			'installation:settings:dbwizard:label:prefix' => "Database table prefix (usually 'elgg')",
	
			'installation:settings:dbwizard:savefail' => "We were unable to save the new settings.php. Please save the following file as engine/settings.php using a text editor.",
	
			'installation:sitename' => "The name of your site (eg \"My social networking site\"):",
			'installation:sitedescription' => "Short description of your site (optional)",
			'installation:wwwroot' => "The site URL, followed by a trailing slash:",
			'installation:path' => "The full path to your site root on your disk, followed by a trailing slash:",
			'installation:dataroot' => "The full path to the directory where uploaded files will be stored, followed by a trailing slash:",
			'installation:dataroot:warning' => "You must create this directory manually. It should sit in a different directory to your Elgg installation.",
			'installation:language' => "The default language for your site:",
			'installation:debug' => "Debug mode provides extra information which can be used to diagnose faults, however it can slow your system down so should only be used if you are having problems:",
			'installation:debug:label' => "Turn on debug mode",
			'installation:usage' => "This option lets Elgg send anonymous usage statistics back to Curverider.",
			'installation:usage:label' => "Send anonymous usage statistics",
			'installation:view' => "Enter the view which will be used as the default for your site or leave this blank for the default view (if in doubt, leave as default):",

			'installation:siteemail' => "Site email address (used when sending system emails)",
	
			'installation:disableapi' => "The RESTful API is a flexible and extensible interface that enables applications to use certain Elgg features remotely.",
			'installation:disableapi:label' => "Enable the RESTful API",

			'upgrading' => 'Upgrading',
			'upgrade:db' => 'Your database was upgraded.',
			'upgrade:core' => 'Your elgg installation was upgraded',
	
		/**
		 * Welcome
		 */
	
			'welcome' => "Bienvenidos %s",
			'welcome_message' => "Bienvenido a la instalaci&oacute;n de elgg.",
	
		/**
		 * Emails
		 */
			'email:settings' => "Configuraci&oacute;n de email",
			'email:address:label' => "Su direcci&oacute de email",
			
			'email:save:success' => "El nuevo email se ha guardado, verifique su petici&oacute;n.",
			'email:save:fail' => "Su nuevo email no puede ser guadado.",
	
			'email:confirm:success' => "Ya tiene confirmada su cuenta",
			'email:confirm:fail' => "Su correo no puede ser verificad@...",
	
			'friend:newfriend:subject' => "%s se ha hecho amig@ suy@!",
			'friend:newfriend:body' => "%s se ha hecho amigo suyo

Para ver su perfilTo view their profile, pulse aqu&iacute;:

	%s

Por favor no conteste a este correo.",
	
	
	
			'email:resetpassword:subject' => "Clave reseteada",
			'email:resetpassword:body' => "Hola %s,
			
Su clave ha sido establecida a: %s",
	
	
			'email:resetreq:subject' => "Petici&oacute;n para una nueva clave.",
			'email:resetreq:body' => "Hola %s,
			
Alguien (desde la IP %s) ha solicitado una nueva clave para su cuenta.

Si ha sido usted quien lo ha solicitado pulse en el enlace de abajo, en otro caso ignore este email.

%s

",

                /**
	                 * user default access
	        */
                'default_access:settings' => "Su nivel de acceso por defecto",
                'default_access:label' => "Acceso por defecto",
                'user:default_access:success' => "Su nuevo nivel de acceso ha sido guardado.",
                'user:default_access:failure' => "Su nuevo nivel de acceso no puede guardarse.",

		/**
		 * XML-RPC
		 */
			'xmlrpc:noinputdata'	=>	"Datos de entrada inv&aacute;lidos",
	
		/**
		 * Comments
		 */
	
			'comments:count' => "%s commentarios",
			
			'riveraction:annotation:generic_comment' => '%s comentados en %s',
	
			'generic_comments:add' => "A&ntilde;adir un comentario",
			'generic_comments:text' => "Commentario",
			'generic_comment:posted' => "Su comentario ha sido enviado correctamente.",
			'generic_comment:deleted' => "Su comentario ha sido eliminado correctamente.",
			'generic_comment:blank' => "Lo lamento, necesita poner actuamente algo en comentario antes de guardarlo.",
			'generic_comment:notfound' => "Lo lamento, no podemos encontrar el art&iacute;culo.",
			'generic_comment:notdeleted' => "Lo lamento; no podemos eliminar este comentario.",
			'generic_comment:failure' => "Un error inesperado ha ocurrido al a&ntilde;adir su comentario, int&eacute;ntelo de nuevo por favor.",
	
			'generic_comment:email:subject' => 'Tiene un nuevo comentario',
			'generic_comment:email:body' => "Tiene un nuevo comentario de su articulo \"%s\" desde %s. que dice:

			
%s


Para contestar o ver el mensaje origitan, pulse aqui:

	%s

Para ver un perfile de %s, pulse aqui:

	%s

Por favor no responda a este correo.",
	
		/**
		 * Entities
		 */
			'entity:default:strapline' => 'Creada %s por %s',
			'entity:default:missingsupport:popup' => 'Esta entindad no puede ser desplegada correctamente. Puede ser por que requiere soporte de un plugin que no ha sido instalado.',
	
			'entity:delete:success' => '%s entidades han sido eliminadas',
			'entity:delete:fail' => '%s entidades no han podido ser eliminadas',
	
	
		/**
		 * Action gatekeeper
		 */
			'actiongatekeeper:missingfields' => 'El formulario est&aacute; campo perdido __token o __ts',
			'actiongatekeeper:tokeninvalid' => "Hemos encontrado un error (token mismatch). Problabemenet signifique que la p&aacute;gina que est&eacute; usando haya expirado.",
			'actiongatekeeper:timeerror' => 'La p&aacute; que estuvo ha expirado. Por favor refresque e int&eacute;ntelo de nuevo.',
			'actiongatekeeper:pluginprevents' => 'Una extensi&oacute;n ha sido retenida por este formulario.',	
		/**
		 * Word blacklists
		 */
			'word:blacklist' => 'y, el, entonces, pero, ella, su, uno, un, no, acerca, ahora, sin embargo, aun, de otro modo, and, the, then, but, she, his, her, him, one, not, also, about, now, hence, however, still, likewise, otherwise, therefore, conversely, rather, consequently, furthermore, nevertheless, instead, meanwhile, accordingly, this, seems, what, whom, whose, whoever, whomever',
	
		/**
		 * Languages according to ISO 639-1
		 */
			"aa" => "Afar",
			"ab" => "Abkhazian",
			"af" => "Afrikaans",
			"am" => "Amharic",
			"ar" => "Arabic",
			"as" => "Assamese",
			"ay" => "Aymara",
			"az" => "Azerbaijani",
			"ba" => "Bashkir",
			"be" => "Byelorussian",
			"bg" => "Bulgarian",
			"bh" => "Bihari",
			"bi" => "Bislama",
			"bn" => "Bengali; Bangla",
			"bo" => "Tibetan",
			"br" => "Breton",
			"ca" => "Catalan",
			"co" => "Corsican",
			"cs" => "Czech",
			"cy" => "Welsh",
			"da" => "Danish",
			"de" => "German",
			"dz" => "Bhutani",
			"el" => "Greek",
			"en" => "English",
			"eo" => "Esperanto",
			"es" => "Espa&ntilde;ol",
			"et" => "Estonian",
			"eu" => "Basque",
			"fa" => "Persian",
			"fi" => "Finnish",
			"fj" => "Fiji",
			"fo" => "Faeroese",
			"fr" => "French",
			"fy" => "Frisian",
			"ga" => "Irish",
			"gd" => "Scots / Gaelic",
			"gl" => "Galician",
			"gn" => "Guarani",
			"gu" => "Gujarati",
			"he" => "Hebrew",
			"ha" => "Hausa",
			"hi" => "Hindi",
			"hr" => "Croatian",
			"hu" => "Hungarian",
			"hy" => "Armenian",
			"ia" => "Interlingua",
			"id" => "Indonesian",
			"ie" => "Interlingue",
			"ik" => "Inupiak",
			//"in" => "Indonesian",
			"is" => "Icelandic",
			"it" => "Italian",
			"iu" => "Inuktitut",
			"iw" => "Hebrew (obsolete)",
			"ja" => "Japanese",
			"ji" => "Yiddish (obsolete)",
			"jw" => "Javanese",
			"ka" => "Georgian",
			"kk" => "Kazakh",
			"kl" => "Greenlandic",
			"km" => "Cambodian",
			"kn" => "Kannada",
			"ko" => "Korean",
			"ks" => "Kashmiri",
			"ku" => "Kurdish",
			"ky" => "Kirghiz",
			"la" => "Latin",
			"ln" => "Lingala",
			"lo" => "Laothian",
			"lt" => "Lithuanian",
			"lv" => "Latvian/Lettish",
			"mg" => "Malagasy",
			"mi" => "Maori",
			"mk" => "Macedonian",
			"ml" => "Malayalam",
			"mn" => "Mongolian",
			"mo" => "Moldavian",
			"mr" => "Marathi",
			"ms" => "Malay",
			"mt" => "Maltese",
			"my" => "Burmese",
			"na" => "Nauru",
			"ne" => "Nepali",
			"nl" => "Dutch",
			"no" => "Norwegian",
			"oc" => "Occitan",
			"om" => "(Afan) Oromo",
			"or" => "Oriya",
			"pa" => "Punjabi",
			"pl" => "Polish",
			"ps" => "Pashto / Pushto",
			"pt" => "Portuguese",
			"qu" => "Quechua",
			"rm" => "Rhaeto-Romance",
			"rn" => "Kirundi",
			"ro" => "Romanian",
			"ru" => "Russian",
			"rw" => "Kinyarwanda",
			"sa" => "Sanskrit",
			"sd" => "Sindhi",
			"sg" => "Sangro",
			"sh" => "Serbo-Croatian",
			"si" => "Singhalese",
			"sk" => "Slovak",
			"sl" => "Slovenian",
			"sm" => "Samoan",
			"sn" => "Shona",
			"so" => "Somali",
			"sq" => "Albanian",
			"sr" => "Serbian",
			"ss" => "Siswati",
			"st" => "Sesotho",
			"su" => "Sundanese",
			"sv" => "Swedish",
			"sw" => "Swahili",
			"ta" => "Tamil",
			"te" => "Tegulu",
			"tg" => "Tajik",
			"th" => "Thai",
			"ti" => "Tigrinya",
			"tk" => "Turkmen",
			"tl" => "Tagalog",
			"tn" => "Setswana",
			"to" => "Tonga",
			"tr" => "Turkish",
			"ts" => "Tsonga",
			"tt" => "Tatar",
			"tw" => "Twi",
			"ug" => "Uigur",
			"uk" => "Ukrainian",
			"ur" => "Urdu",
			"uz" => "Uzbek",
			"vi" => "Vietnamese",
			"vo" => "Volapuk",
			"wo" => "Wolof",
			"xh" => "Xhosa",
			//"y" => "Yiddish",
			"yi" => "Yiddish",
			"yo" => "Yoruba",
			"za" => "Zuang",
			"zh" => "Chinese",
			"zu" => "Zulu",
	);

////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
	add_translation("es",$spanish);
?>
