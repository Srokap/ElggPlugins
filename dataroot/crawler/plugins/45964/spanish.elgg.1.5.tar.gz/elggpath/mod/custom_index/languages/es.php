<?php

	$spanish = array(
	
			'custom:bookmarks' => "&Uacute;ltimos favoritos",
			'custom:groups' => "&Uacute;ltimos grupos",
			'custom:files' => "&Uacute;ltimos archivos",
			'custom:blogs' => "&Uacute;ltimos blogs",
			'custom:members' => "Participantes recientes",
			'custom:nofiles' => "No hay archivos",
			'custom:nogroups' => "No hay grupos definidos",	
	
	);
					
	add_translation("es",$spanish);

?>
