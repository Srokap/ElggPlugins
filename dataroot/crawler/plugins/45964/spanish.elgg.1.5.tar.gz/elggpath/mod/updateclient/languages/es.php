<?php

	/**
	 * Update client language pack.
	 * 
	 * @package ElggUpdateClient
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */	
	$spanish = array(
	
		'updateclient:label:core' => 'Core',
		'updateclient:label:plugins' => 'Plugins',
	
		'updateclient:settings:days' => 'Verificar por actualizaciones cada',
		'updateclient:days' => 'd&iacute;as',
	
		'updateclient:settings:server' => 'Actualizar el servidor',
	
		'updateclient:message:title' => 'Se ha publicado una nueva versi&oacute;n de elgg',
		'updateclient:message:body' => 'Una nueva version de elgg (%s %s) con el c&oacute;digo "%s" ha sido publicada
		
Deber&iacute;a bajarlo: %s

O verificar los cambios y novedades:

%s',
	);

	add_translation("es", $spanish);
?>
