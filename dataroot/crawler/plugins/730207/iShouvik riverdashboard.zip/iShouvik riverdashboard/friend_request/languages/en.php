<?php
	$english = array(
		'friend_request' => "Friend Request",
		'friend_request:menu' => "Friend Requests",
		'friend_request:title' => "Friend Requests",
	
		'friend_request:new' => "New friend request",
		
		'friend_request:newfriend:subject' => "%s wants to add you as friend!",
		'friend_request:newfriend:body' => "%s wants to add you as friend. But awaiting your approval. Please, login now to approve the request!

You can view your pending friend requests at (Make sure you are logged into the website before clicking on the following link otherwise you will be redirected to the login page.):

%s

(You cannot reply to this email.)",
		
		// Actions
		// Add request
		'friend_request:add:failure' => "Sorry, because of a system error we were unable to complete your request. Please try again.",
		'friend_request:add:successful' => "The friend request you have sent to %s must be approved to show up on your friend-list.",
		'friend_request:add:exists' => "You've already sent friend-request to %s.",
		
		// Approve request
		'friend_request:approve' => "Approve",
		'friend_request:approve:successful' => "You have successfully added %s as your friend.",
		'friend_request:approve:fail' => "Error while creating friend relation with %s",
	
		// Decline request
		'friend_request:decline' => "Decline",
		'friend_request:decline:subject' => "%s has declined your friend request",
		'friend_request:decline:message' => "Dear %s,

%s has declined your friend request.",
		'friend_request:decline:success' => "Friend request succesfully declined",
		'friend_request:decline:fail' => "Error while declining friend request, please try again",
		
		// Revoke request
		'friend_request:revoke' => "Revoke",
		'friend_request:revoke:success' => "Friend request succesfully revoked",
		'friend_request:revoke:fail' => "Error while revoking friend request, please try again",
	
		// Views
		// Received
		'friend_request:received:title' => "Received friend requests",
		'friend_request:received:none' => "No requests pending your approval",
	
		// Sent
		'friend_request:sent:title' => "Sent friend requests",
		'friend_request:sent:none' => "No sent requests pending approval",
	);
					
	add_translation("en", $english);
?>