<?php 
/**
 * Elgg riverdashboard newset member sidebar box
 * 
 * @package iShouvik Elgg River
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author iShouvik <contact@ishouvik.com>
 * @copyright Curverider Ltd 2008-2010
 * @link http://ishouvik.com/
 * 
 */

$newest_members = elgg_get_entities_from_metadata(array('metadata_names' => 'icontime', 'types' => 'user', 'limit' => 18));

?>

<div class="sidebarBox">
    <div class="membersWrapper"><br />
    <h3><?php echo elgg_echo('riverdashboard:recentmembers') ?></h3>
    <?php 
        foreach($newest_members as $mem) {
            echo "<div class=\"recentMember\">" . elgg_view("profile/icon", array('entity' => $mem, 'size' => 'tiny')) . "</div>";
        }
    ?>
    <div class="clearfloat"></div>
    <a href="<?php echo $vars['url']; ?>mod/members/" class="viewall"><?php echo elgg_echo('viewall') ?></a>
    </div>
</div>
