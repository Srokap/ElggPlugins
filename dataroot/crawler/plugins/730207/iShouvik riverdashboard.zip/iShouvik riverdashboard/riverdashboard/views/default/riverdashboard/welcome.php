<?php

/**
 * Elgg Riverdashboard welcome message
 * 
 * @package ElggRiverDash
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Curverider <info@elgg.com>
 * @copyright Curverider Ltd 2008-2010
 * @link http://elgg.com/
 * 
 */
 
?>
<?php if(is_plugin_enabled('thewire')){ ?>
<div id="dash_wire">
<?php
	//	$area2 = elgg_view_title(elgg_echo("thewire:everyone"));
		
		//add form
		if (isloggedin()) {
			//$area2 .= elgg_view("thewire/forms/add");
			$area2 .= elgg_view("riverdashboard/forms/wireadd");
		}

	//	$offset = (int)get_input('offset', 0);
	//	$area2 .= elgg_list_entities(array('types' => 'object', 'subtypes' => 'thewire', 'offset' => $offset));
	    echo elgg_view_layout("two_column_left_sidebar_maincontent_boxes", '', $area2);
?>
</div>
<?php } // closing thewire enable condition ?>
