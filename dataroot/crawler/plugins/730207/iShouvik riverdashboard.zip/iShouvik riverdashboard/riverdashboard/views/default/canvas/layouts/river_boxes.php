<?php
/**
 * Elgg 2 column left sidebar with boxes
 *
 * @package Elgg
 * @subpackage Core
 */
?>

<!-- right sidebar -->
<div id="two_column_right_river_boxes">

    <?php if (isset($vars['area3'])) echo $vars['area3']; ?>

</div><!-- /two_column_right_sidebar -->

<!-- left sidebar -->
<div id="two_column_left_river_boxes">

	<?php if (isset($vars['area1'])) echo $vars['area1']; ?>

</div><!-- /two_column_left_sidebar -->

<!-- main content -->
<div id="two_column_left_river_maincontent_boxes">

<?php if (isset($vars['area2'])) echo $vars['area2']; ?>

</div><!-- /two_column_left_sidebar_maincontent -->

