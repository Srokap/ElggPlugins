

1. This plugin requires the elgg private messages plugin to be enabled.

2. Please, place the plugin close to the bottom of the plugin list on your Elgg Tools Administrations page.

3. Preferred support given only to people who have either donated at least $25 to support the plugin development or have kept the link of the developer's website intact on the dashboard.

You can make a donation by sending the money via Paypal to the following email account associated with Paypal-- contact@ishouvik.com

If you would like to pay via debit/credit card, please ask the developer to send you a payment request. Email - contact@ishouvik.com








/***************************************************************************/



Contact for tailor-made development



email: contact@ishouvik.com

skype: shouvik_0106

msn: ishouvik@hotmail.com



/***************************************************************************/
