<?php

$english = array(
	'all' => 'All',
	'viewall' => 'View All',
	'mine' => 'Mine',
	'filter' => 'filter',
	'riverdashboard:useasdashboard' => "Replace the default dashboard with this activity river?",
	'activity' => 'Activity',
	'riverdashboard:recentmembers' => 'Recent members',
	'riverdashboard:recentmembersvisitors' => 'Recent Profile Visitors',

	/**
	* Yes and No
	**/
	'option:yes' => 'Yes',
	'option:no' => 'No',

	/**
	* Sidebars on Settings
	**/
	'option:leftsidebar' => 'Left Sidebar',
	'option:middlesidebar' => 'Middle Sidebar',
	'option:rightsidebar' => 'Right Sidebar',

	/**
	* Friends Box
	**/
	'option:left:friends' => 'Display friends?',
	'option:left:friends_num' => 'Number of friends to display',
	
	/**
	* iZap profile visitors
	**/
	'option:left:recentvisitors' => 'Display recent profile visitors?',
	'option:left:recentvisitors_num' => 'Number of visitors to display',
	
	/**
	* Polls
	**/
	'option:left:polls' => 'Display polls?',
	'option:left:polls_num' => 'Number of polls to display',

	/**
	* The wire
	**/
	'option:middle:thewire' => 'Display the wire?',

	/**
	* 'All' tab
	**/
	'option:middle:alltab' => 'Display the "All" activity tab to',
	'option:middle:alltab:admins' => 'Administrators only',
	'option:middle:alltab:everyone' => 'Everyone',

	/**
	* Newest members
	**/
	'option:right:newestmembers' => 'Display recent members?',
	'optiomn:right:newestmembers_num' => 'Number of recent members to display',

	/**
	* Bookmarks
	**/
	'option:right:bookmarks' => 'Display bookmarks?',
	'option:right:bookmarks_num' => 'Number of bookmarked entries to display',

	/**
	 * Site messages
	 **/

	'sitemessages:announcements' => "site announcements",
	'sitemessages:posted' => "site message posted",
	'sitemessages:river:created' => "site admin, %s,",
	'sitemessages:river:create' => "posted a new site wide message",
	'sitemessages:add' => "add a site-wide message to the river page",
	'sitemessage:deleted' => "site message deleted",
	'sitemessage:error' => "failed to save site message.",
	'sitemessages:blank' => "unable to post blank message",

	'river:widget:noactivity' => 'no activity here yet!',
	'river:widget:title' => "activity",
	'river:widget:description' => "display co-creator activity or your own latest activity.",
	'river:widgets:friends' => "co-creators",
	'river:widgets:mine' => "Mine",
	'river:widget:label:displaynum' => "number of entries to display:",
	'river:widget:type' => "which river would you like to display? one that shows your activity or one that shows your friends activity?",
	'item:object:sitemessage' => "site messages",
	'riverdashboard:avataricon' => "Would you like to use user avatars or icons on your site activity stream?",
	'option:icon' => 'Icons',
	'option:avatar' => 'Avatars',
	'option:left:siteaccountements' => 'Display site announcements?',
	
	/**
	* Right Advert Box
	**/
	
	'option:right:advertbox' => 'Display Right Advert Box?',
	'option:right:advertbox:postcode' => 'Paste your codes blow',
);

add_translation("en", $english);
