<head><link rel="stylesheet" href="style.css"></head>
<body class="phpinfo"><?php
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

admin_gatekeeper();
$site_url = elgg_get_site_url();
?>
<title>PHP Info - ElggPanel</title><center><a href="javascript: history.go(-1)">Back</a></center><?php

// Show all information, defaults to INFO_ALL
phpinfo();

// Show just the module information.
// phpinfo(8) yields identical results.
phpinfo(INFO_MODULES);
?>
</body>