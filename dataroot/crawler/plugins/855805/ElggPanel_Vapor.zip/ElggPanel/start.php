<?php
$frontpageurl = elgg_get_site_url() . "mod/ElggPanel/frontpage-enabled.txt";
$frontpagehandle = fopen($frontpageurl, "rb");
$frontpagecontents = stream_get_contents($frontpagehandle);
fclose($frontpagehandle);
?>
<?php
$widget1url = elgg_get_site_url() . "/mod/ElggPanel/widget1.txt";
$widget1handle = fopen($widget1url, "rb");
$widget1contents = stream_get_contents($widget1handle);
fclose($widget1handle);
?>
<?php
$widget1nameurl = elgg_get_site_url() . "/mod/ElggPanel/widget1name.txt";
$widget1namehandle = fopen($widget1nameurl, "rb");
$widget1namecontents = stream_get_contents($widget1namehandle);
fclose($widget1namehandle);
?>
<?php
$widget1descurl = elgg_get_site_url() . "/mod/ElggPanel/widget1desc.txt";
$widget1deschandle = fopen($widget1descurl, "rb");
$widget1desccontents = stream_get_contents($widget1deschandle);
fclose($widget1deschandle);
?>
<?php
if ($frontpagecontents == yes) {
function elggpanel_init() {
    // Replace the default index page
    elgg_register_plugin_hook_handler('index','system','new_index');
}
}
 
function new_index() {
    if (!include_once(dirname(dirname(__FILE__)) . "/ElggPanel/frontpage-home.php"))
        return false;
 
    return true;
}

if ($widget1contents == yes) {
  elgg_register_widget_type('widget1', elgg_echo($widget1namecontents), elgg_echo($widget1desccontents));
}

register_elgg_event_handler('init','system','elggpanel_init');

?>
