<?php
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

admin_gatekeeper();
$site_url = elgg_get_site_url();
?>
<?php
$allowedfile = "themeeditorallowed.txt";
$allowed = fopen($allowedfile, "r");
$allowedfinal = fread($allowed, filesize($allowedfile));
fclose($allowed);
?>
<?php
// For PHP 5 and up
$handle1 = fopen("views/default/page/elements/backgroundcolor.txt", "rb");
$contents1 = stream_get_contents($handle1);
fclose($handle1);
?>

<?php
if ($allowedfinal == "no")
  header( 'Location: theme-editor.php' ) ;
?>
<?php
//************************MAIN CONTENT***********************************
?>
<head>
<link rel="stylesheet" href="<?php echo $site_url; ?>mod/ElggPanel/style.css">
<title>ElggPanel - Background Color</title>
</head>
<body class="theme-editor-page">
<script type="text/javascript" src="jscolor/jscolor.js"></script>
<a href="index.php" class="backtoelggpanel">Back to ElggPanel</a>
<div class="elggpanel-info-1">This is where you edit the Background Color for your theme.<br>
<form action="theme-editor-backgroundcolor-process.php" method="post">
<input class="color"  name="backgroundcolor" value="<?php echo $contents1; ?>">
<input type="submit" value="Save" />
</form></div>
</body>