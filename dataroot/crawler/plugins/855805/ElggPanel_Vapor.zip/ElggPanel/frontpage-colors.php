<?php
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

admin_gatekeeper();
$site_url = elgg_get_site_url();
?>
<?php
$allowedfile = "frontpage-enabled.txt";
$allowed = fopen($allowedfile, "r");
$allowedfinal = fread($allowed, filesize($allowedfile));
fclose($allowed);
?>
<?php
$handle1 = fopen("section1color.txt", "rb");
$contents1 = stream_get_contents($handle1);
fclose($handle1);
?>
<?php
$handle2 = fopen("section2color.txt", "rb");
$contents2 = stream_get_contents($handle2);
fclose($handle2);
?>
<?php
$handle3 = fopen("section3color.txt", "rb");
$contents3 = stream_get_contents($handle3);
fclose($handle3);
?>
<?php
if ($allowedfinal == "no")
  header( 'Location: theme-editor.php' ) ;
?>
<?php
//************************MAIN CONTENT***********************************
?>
<head>
<link rel="stylesheet" href="<?php echo $site_url; ?>mod/ElggPanel/style.css">
<style type="text/css">
a:link {color:#FFFFFF;} 
a:visited {color:#FFFFFF;}
a:hover {color:#FFFFFF;}  
a:active {color:#FFFFFF;} 
</style>
<title>ElggPanel - FrontPage Colors</title>
</head>
<body class="frontpage">
<a href="index.php" class="backtoelggpanel">Back to ElggPanel</a><br>
<script type="text/javascript" src="jscolor/jscolor.js"></script>
This is where you edit the Section Color for your theme.<br>
<form action="frontpage-colors-process.php" method="post">
<h1>Section 1</h1>
<input class="color"  name="section1" value="<?php echo $contents1; ?>">
<h1>Section 2</h1>
<input class="color"  name="section2" value="<?php echo $contents2; ?>">
<h1>Section 3 (For certain layouts)</h1>
<input class="color"  name="section3" value="<?php echo $contents3; ?>"></ br>
<input type="submit" value="Save" />
</form>
</body>