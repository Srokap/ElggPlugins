<?php
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

$site_url = elgg_get_site_url();
$site_name = $site->name;
?>
<?php
$url = elgg_get_site_url() . "mod/ElggPanel/frontpage-layout.txt";
$handle = fopen($url, "rb");
$contents = stream_get_contents($handle);
fclose($handle);
?>
<?php
$urlcontentbox1 = elgg_get_site_url() . "mod/ElggPanel/frontpage-contentbox-1.html";
$getcontentbox1 = fopen($urlcontentbox1, "rb");
$contentbox1 = stream_get_contents($getcontentbox1);
fclose($getcontentbox1);
?>
<?php
$section1colorurl = elgg_get_site_url() . "mod/ElggPanel/section1color.txt";
$getsection1color = fopen($section1colorurl, "rb");
$section1colorcontents = stream_get_contents($getsection1color);
fclose($getsection1color);
?>
<?php
$section3colorurl = elgg_get_site_url() . "mod/ElggPanel/section3color.txt";
$getsection3color = fopen($section3colorurl, "rb");
$section3colorcontents = stream_get_contents($getsection3color);
fclose($getsection3color);
?>
<?php
$section2colorurl = elgg_get_site_url() . "mod/ElggPanel/section2color.txt";
$getsection2color = fopen($section2colorurl, "rb");
$section2colorcontents = stream_get_contents($getsection2color);
fclose($getsection2color);
?>
<?php
$urlcontentbox2 = elgg_get_site_url() . "mod/ElggPanel/frontpage-contentbox-2.html";
$getcontentbox2 = fopen($urlcontentbox2, "rb");
$contentbox2 = stream_get_contents($getcontentbox2);
fclose($getcontentbox2);
?>
<?php
if (isloggedin()) forward('activity');
?>
<?php
if ($contents == A) {
?>
<html>
<head>
<?php
//Title configuration below
?>
<title>Welcome</title>
    </head>
<?php $messages = system_messages();	
	$message = $messages['messages'];
	
	if(count($message) > 0){ 
		echo '<div  style="color: white;" class="messages">';
		echo '<span class="closeMessages"><a  style="color: white;" href="#">dismiss</a></span>';
			foreach($message as $message1)
					{
					echo '<p  style="color: white;">';
					echo $message1;
					echo '</p>';
					}
		echo '</div>';
	}

	$errors = register_error();
	$error = $errors['errors'];
	if(count($error) > 0){ 
		echo '<div class="messages_error">';
		echo '<span class="closeMessages"><a href="#">dismiss</a></span>';
			foreach($error as $error1)
					{
					echo '<p>';
					echo $error1;
					echo '</p>';
					}
		echo '</div>';
	}


////////////////////////////////////////////////////////////////////////////////////////////////
?>
<body style="margin: 0px; padding: 0px; font-family: 'Trebuchet MS',verdana;">

<table width="100%" style="height: 100%;" cellpadding="10" cellspacing="0" border="0"><tr>

<!-- ============ LEFT COLUMN (MENU) ============== -->
<td width="20%" valign="top" bgcolor="<?php echo $section2colorcontents; ?>">
<?php
/**
 * Elgg login box
 *
 * @package Elgg
 * @subpackage Core
 *
 * @uses $vars['module'] The module name. Default: aside
 */


$login_url = elgg_get_site_url();
if (elgg_get_config('https_login')) {
	$login_url = str_replace("http:", "https:", $login_url);
}

$title = elgg_echo('login');
$body = elgg_view_form('login', array('action' => "{$login_url}action/login"));

echo elgg_view_module($module, $title, $body);
?>
<?php echo $contentbox2; ?>
</td>
<td width="80%" valign="top" bgcolor="<?php echo $section1colorcontents; ?>">
<?php echo $contentbox1; ?>
</td></tr></table>
</body>
</html>
<?php 
}
?>
<?php
if ($contents == B) {
?>
<html>
<head>
<title>Welcome</title>
</head>
<body style="margin: 0px; padding: 0px; font-family: 'Trebuchet MS',verdana;">
<center>
<table border="1" cellpadding="5" cellspacing="0" width="100%" height="100%">

<tr><td align="left" valign="top" width="20%" bgcolor="<?php echo $section1colorcontents; ?>"><center>
<?php
/**
 * Elgg login box
 *
 * @package Elgg
 * @subpackage Core
 *
 * @uses $vars['module'] The module name. Default: aside
 */


$login_url = elgg_get_site_url();
if (elgg_get_config('https_login')) {
	$login_url = str_replace("http:", "https:", $login_url);
}

$title = elgg_echo('login');
$body = elgg_view_form('login', array('action' => "{$login_url}action/login"));

echo elgg_view_module($module, $title, $body);
?><?php echo $contentbox1; ?></center>
</td><td align="left" valign="top" width="33%" bgcolor="<?php echo $section2colorcontents; ?>">
<?php echo $contentbox2; ?>
</td><td align="left" valign="top" width="33%" bgcolor="<?php echo $section3colorcontents; ?>"><center>
<?php
/**
 * Walled garden registration
 */

$title = elgg_echo('register');
$body = elgg_view_form('register', array(), array(
	'friend_guid' => (int) get_input('friend_guid', 0),
	'invitecode' => get_input('invitecode'),
));

$content = <<<__HTML
<div class="elgg-inner">
	<h2>$title</h2>
	$body
</div>
__HTML;

echo elgg_view_module('walledgarden', '', $content, array(
	'class' => 'elgg-walledgarden-single elgg-walledgarden-register hidden',
	'header' => ' ',
	'footer' => ' ',
));
?>
</center>
</td></tr></table> 
</center>
</body>
</html>
<?php
}
?>
<?php
if ($contents == C) {
?>
<html>
<head>
<?php
//Title configuration below
?>
<title>Welcome</title>
    </head>
<?php $messages = system_messages();	
	$message = $messages['messages'];
	
	if(count($message) > 0){ 
		echo '<div  style="color: white;" class="messages">';
		echo '<span class="closeMessages"><a  style="color: white;" href="#">dismiss</a></span>';
			foreach($message as $message1)
					{
					echo '<p  style="color: white;">';
					echo $message1;
					echo '</p>';
					}
		echo '</div>';
	}

	$errors = register_error();
	$error = $errors['errors'];
	if(count($error) > 0){ 
		echo '<div class="messages_error">';
		echo '<span class="closeMessages"><a href="#">dismiss</a></span>';
			foreach($error as $error1)
					{
					echo '<p>';
					echo $error1;
					echo '</p>';
					}
		echo '</div>';
	}


////////////////////////////////////////////////////////////////////////////////////////////////
?>
<body style="margin: 0px; padding: 0px; font-family: 'Trebuchet MS',verdana;">

<table width="100%" style="height: 100%;" cellpadding="10" cellspacing="0" border="0"><tr>

<!-- ============ LEFT COLUMN (MENU) ============== -->
<td width="80%" valign="top" bgcolor="<?php echo $section1colorcontents; ?>">

<?php echo $contentbox1; ?>
</td>
<td width="20%" valign="top" bgcolor="<?php echo $section2colorcontents; ?>">
<?php
/**
 * Elgg login box
 *
 * @package Elgg
 * @subpackage Core
 *
 * @uses $vars['module'] The module name. Default: aside
 */


$login_url = elgg_get_site_url();
if (elgg_get_config('https_login')) {
	$login_url = str_replace("http:", "https:", $login_url);
}

$title = elgg_echo('login');
$body = elgg_view_form('login', array('action' => "{$login_url}action/login"));

echo elgg_view_module($module, $title, $body);
?><?php echo $contentbox2; ?>
</td></tr></table>
</body>
</html>
<?php
}
?>