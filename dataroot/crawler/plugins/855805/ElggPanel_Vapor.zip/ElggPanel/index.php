<?php
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

admin_gatekeeper();
$site_url = elgg_get_site_url();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<link rel="stylesheet" href="style.css">

	<title>ElggPanel</title>
<style>
td{font-family:Tahoma;font-size:11px;color:#000000}
a{color:#365474}
.cap{color:#CC4126;font-weight:bold;}
</style>
</head>

<body topmargin="0" leftmargin="0" bottommargin="0" rightmargin="0"><div class="elggpanel-homepage">
<table cellpadding="0" cellspacing="0" class="mainbody" border="0" width="100%" height="100%">
<tr>
	<td colspan="3">
      <div class="elggpanel-header-1">ElggPanel<sup>Air</sup></div>		
</tr>
<tr>
	<td valign="top" width="100%" height="100%">
	<table cellpadding="0" class="elggpanel-list-table" cellspacing="0" border="0" width="100%" height="100%">
		<tr>
			<td><h1 class="elggpanel-list-catagory">Options</h1><br>
<center><table class="table-settings-chooser" border="2" cellpadding="3" width="100%" height="100%" cellspacing="3">
<tr>
		<td><a href="<?php echo $site_url; ?>admin">Admin</a></td>
		<td><a href="phpinfo.php">PHP Info</a></div></td>
		<td><a href="<?php echo $site_url ?>upgrade.php">Upgrade</a></td>
		<td><a href="<?php echo $site_url ?>action/admin/site/flush_cache">Flush Caches</td>
		<td><a href="theme-editor.php">Theme Editor</a></td>
		<td><a href="frontpage.php">FrontPage</a></td>
		<td><a href="add-ons">Add-ons</a></td>
		<td><a href="widgets.php">Widgets</a></td>
	</tr>
	<tr>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
	</tr>
	<tr>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
	</tr>
	<tr>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
	</tr>
	<tr>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
	</tr>
	<tr>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
	</tr>
	<tr>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
	</tr>
	<tr>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
		<td>None</td>
	</tr>

</table></center>
</td>
		</tr>
		<tr>
			<td width="394" height="100%" valign="top" style="PADDING-RIGHT: 15px">
			
			</td> 
		</tr>
	</table>
	</td>
	<td valign="top" height="100%">
	<table cellpadding="0" cellspacing="0" border="0" height="100%">
		<tr>
			<td>
            <h1 class="elggpanel-heading-1">Site Stats</h1>Logged in as <?php echo $_SESSION['user']->username; ?> <a href="<?php echo $site_url; ?>action/logout">Logout</a><br><?php $count = find_active_users(600, 0, $offset, true); echo $count; ?>
            <?php
if ($count == 1) {
    echo "active user.";
} elseif ($count == 0) {
    echo "active users.";
} else {
    echo "active users.";
}
?>Members:
<h1 class="elggpanel-heading-1">Useful Links</h1><li><a target="_blank" href="http://www.ftplive.com/ftp.html">File Manager</a></li><li><a href="http://community.elgg.org">Elgg Community</a></li><li><a href="http://productionsx.tk">Productions X</a></td></li>
		</tr>
		<tr>
		<tr>
			<td width="193" height="100%" background="" valign="top" style="PADDING-BOTTOM: 10px">
			
			</td>
		</tr>
	</table>
	</td>
</tr>
<tr>
</tr>
<tr><td colspan="3"><div style="TEXT-ALIGN: center; FONT-FAMILY: Arial,Helvetica,Sans-Serif; COLOR: #777; FONT-SIZE: 11px" >
</td></tr>
</table>
</div>
</body>
</html>

