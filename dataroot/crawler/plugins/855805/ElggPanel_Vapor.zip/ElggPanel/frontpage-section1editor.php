<?php
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

admin_gatekeeper();
$site_url = elgg_get_site_url();
?>
<?php
// For PHP 5 and up
$handle1 = fopen("frontpage-contentbox-1.html", "rb");
$contents1 = stream_get_contents($handle1);
fclose($handle1);
?>
<?php
// For PHP 5 and up
$handle2 = fopen("frontpage-contentbox-2.html", "rb");
$contents2 = stream_get_contents($handle2);
fclose($handle2);
?>
<head>
<!-- jQuery and jQuery UI -->
	<script src="elrte-1.3/js/jquery-1.6.1.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="elrte-1.3/js/jquery-ui-1.8.13.custom.min.js" type="text/javascript" charset="utf-8"></script>
	<link rel="stylesheet" href="elrte-1.3/css/smoothness/jquery-ui-1.8.13.custom.css" type="text/css" media="screen" charset="utf-8">

	<!-- elRTE -->
	<script src="elrte-1.3/js/elrte.min.js" type="text/javascript" charset="utf-8"></script>
	<link rel="stylesheet" href="elrte-1.3/css/elrte.min.css" type="text/css" media="screen" charset="utf-8">

	<!-- elRTE translation messages -->
	<script src="elrte-1.3/js/i18n/elrte.ru.js" type="text/javascript" charset="utf-8"></script>

	<script type="text/javascript" charset="utf-8">
		$().ready(function() {
			var opts = {
				cssClass : 'el-rte',
				// lang     : 'ru',
				height   : 450,
				toolbar  : 'complete',
				cssfiles : ['elrte-1.3/css/elrte-inner.css']
			}
			$('#editor').elrte(opts);
		})
	</script>

	<style type="text/css" media="screen">
		body { padding:20px;}	</style>
<link rel="stylesheet" href="style.css">
<title>ElggPanel - Section Editor</title>
<style type="text/css">
a:link {color:#FFFFFF;} 
a:visited {color:#FFFFFF;}
a:hover {color:#FFFFFF;}  
a:active {color:#FFFFFF;} 
</style>
</head>
<body class="frontpage">
<a href="index.php" class="backtoelggpanel">Back to ElggPanel</a>
<form name="sections" action="frontpage-section1editor-process.php" method="post">
Welcome to the Section Editor. This is where you edit section 1 on the FrontPage.
<?php echo "<textarea id='editor' name='section1'>" . $contents1 . "</textarea>"; ?>
<input type="submit" value="Save" />
</form>
</body>