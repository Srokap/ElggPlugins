<?php
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

admin_gatekeeper();
$site_url = elgg_get_site_url();
?>
<?php
$file1 = fopen("widget1.txt","w");
fwrite($file1,$_POST["onoroff"]);
fclose($file1);
?> 
<?php
$file2 = fopen("views/default/widgets/widget1/content.php","w");
fwrite($file2,$_POST["content"]);
fclose($file2);
?>
<?php
$file3 = fopen("widget1name.txt","w");
fwrite($file3,$_POST["name"]);
fclose($file3);
?>
<?php
$file4 = fopen("widget1desc.txt","w");
fwrite($file4,$_POST["description"]);
fclose($file4);
?>
<META HTTP-EQUIV="refresh" CONTENT="seconds;URL=widgets.php">