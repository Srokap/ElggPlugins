<?php
$file1 = fopen("section1color.txt","w");
fwrite($file1,$_POST["section1"]);
fclose($file1);
?>
<?php
$file2 = fopen("section2color.txt","w");
fwrite($file2,$_POST["section2"]);
fclose($file2);
?>
<?php
$file2 = fopen("section3color.txt","w");
fwrite($file2,$_POST["section3"]);
fclose($file2);
?>
<?php
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

admin_gatekeeper();
$site_url = elgg_get_site_url();
?>
<?php
$allowedfile = "frontpage-enabled.txt";
$allowed = fopen($allowedfile, "r");
$allowedfinal = fread($allowed, filesize($allowedfile));
fclose($allowed);
?>
<?php
if ($allowedfinal == "no")
  header( 'Location: frontpage.php' ) ;
?>
<meta http-equiv="REFRESH" content="0;url=frontpage.php">