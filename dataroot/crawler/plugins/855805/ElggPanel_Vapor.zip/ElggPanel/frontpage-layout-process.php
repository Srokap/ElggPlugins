<?php
$file = fopen("frontpage-layout.txt","w");
fwrite($file,$_POST["layout"]);
fclose($file);
?> 
<?php
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

admin_gatekeeper();
$site_url = elgg_get_site_url();
?>
<?php
$allowedfile = "frontpage-enabled.txt";
$allowed = fopen($allowedfile, "r");
$allowedfinal = fread($allowed, filesize($allowedfile));
fclose($allowed);
?>
<?php
if ($allowedfinal == "no")
  header( 'Location: frontpage.php' ) ;
?>
<meta http-equiv="REFRESH" content="0;url=frontpage.php">