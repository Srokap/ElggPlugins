<?php
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

admin_gatekeeper();
$site_url = elgg_get_site_url();
?>
<?php
// For PHP 5 and up
$handle = fopen("frontpage-enabled.txt", "rb");
$contents = stream_get_contents($handle);
fclose($handle);
?>
<head>
<link rel="stylesheet" href="style.css">
<title>ElggPanel - FrontPage</title>
<style type="text/css">
a:link {color:#FFFFFF;} 
a:visited {color:#FFFFFF;}
a:hover {color:#FFFFFF;}  
a:active {color:#FFFFFF;} 
</style>
</head>
<body class="frontpage">
<a href="index.php" class="backtoelggpanel">Back to ElggPanel</a>
<h1 class="frontpage-intro">FrontPage</h1>
Welcome to FrontPage. This is where you can chose a FrontPage for ElggPanel and disable it if you want your current homepage.<br>
FrontPage is 
<?php
if ($contents == "yes") {
  echo "enabled. <a href='disable-frontpage.php'>Disable</a><br><a href='frontpage-layout.php'>Select Layout</a><br><a href='frontpage-section1editor.php'>Section 1 Editor</a><br><a href='frontpage-section2editor.php'>Section 2 Editor</a><br><a href='frontpage-colors.php'>Select Colors</a>";
} else {
  echo "disabled. <a href='enable-frontpage.php'>Enable</a>";
}
?>
</body>