<?php
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

admin_gatekeeper();
$site_url = elgg_get_site_url();
?>
<?php
$myFile = "themeeditorallowed.txt";
$fh = fopen($myFile, 'w') or die("can't open file");
$stringData = "yes";
fwrite($fh, $stringData);
fclose($fh);
?>
<?php header('Location: theme-editor.php'); exit; ?>