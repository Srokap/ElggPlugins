<?php
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

admin_gatekeeper();
$site_url = elgg_get_site_url();
?>
<?php
$handle = fopen("widget1.txt", "rb");
$contents = stream_get_contents($handle);
fclose($handle);
?>
<?php
$handle1 = fopen("views/default/widgets/widget1/content.php", "rb");
$contents1 = stream_get_contents($handle1);
fclose($handle1);
?>
<?php
$handle2 = fopen("widget1name.txt", "rb");
$contents2 = stream_get_contents($handle2);
fclose($handle2);
?>
<?php
$handle3 = fopen("widget1desc.txt", "rb");
$contents3 = stream_get_contents($handle3);
fclose($handle3);
?>
<head>
<link rel="stylesheet" href="style.css">
<title>ElggPanel - Widget 1</title>
<!-- jQuery and jQuery UI -->
	<script src="elrte-1.3/js/jquery-1.6.1.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="elrte-1.3/js/jquery-ui-1.8.13.custom.min.js" type="text/javascript" charset="utf-8"></script>
	<link rel="stylesheet" href="elrte-1.3/css/smoothness/jquery-ui-1.8.13.custom.css" type="text/css" media="screen" charset="utf-8">

	<!-- elRTE -->
	<script src="elrte-1.3/js/elrte.min.js" type="text/javascript" charset="utf-8"></script>
	<link rel="stylesheet" href="elrte-1.3/css/elrte.min.css" type="text/css" media="screen" charset="utf-8">

	<!-- elRTE translation messages -->
	<script src="elrte-1.3/js/i18n/elrte.ru.js" type="text/javascript" charset="utf-8"></script>

	<script type="text/javascript" charset="utf-8">
		$().ready(function() {
			var opts = {
				cssClass : 'el-rte',
				// lang     : 'ru',
				height   : 450,
				toolbar  : 'complete',
				cssfiles : ['elrte-1.3/css/elrte-inner.css']
			}
			$('#editor').elrte(opts);
		})
	</script>

	<style type="text/css" media="screen">
		body { padding:20px;}	</style>
<link rel="stylesheet" href="style.css">
<title>ElggPanel - Section Editor</title>
</head>
<body class="widgets">
<a href="index.php" class="backtoelggpanel">Back to ElggPanel</a>
<h1>Widget 1</h1>
<form name="input" action="widget1-process.php" method="post">
<h2>Enabled</h2>
<select name="onoroff">
<option name="yes">yes</option>
<option name="no" 
<?php
if ($contents == no) {
  echo "selected='yes'";
}
?>
>no</option>
</select><h2>Content</h2>
<?php echo "<textarea name='content' id='editor'>" . $contents1 . "</textarea>"; ?> 
<h2>Name</h2>
<input type="text" name="name" value="<?php echo $contents2; ?>"/><br>
<h2>Description</h2>
<input type="text" name="description" value="<?php echo $contents3; ?>"/><br>
<input type="submit" value="Save" />
</body>