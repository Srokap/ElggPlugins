<?php
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

admin_gatekeeper();
$site_url = elgg_get_site_url();
?>
<?php
$allowedfile = "themeeditorallowed.txt";
$allowed = fopen($allowedfile, "r");
$allowedfinal = fread($allowed, filesize($allowedfile));
fclose($allowed);
?>
<head>
<link rel="stylesheet" href="<?php echo $site_url; ?>mod/ElggPanel/style.css">
<title>ElggPanel - Theme Editor</title>
</head>
<body class="theme-editor-page">
<div class="elggpanel-info-1">Welcome to the Theme Editor. This is where you get to edit certain elements of your Elgg site such as background color or button color. You would want to disable this feature if you already have a theme. The theme editor is <?php
if ($allowedfinal == yes) {
  echo "enabled.<br><h2><a href='disable-theme-editor.php'>Disable</a></h2>";
} else {
  echo "disabled.<br><h2><a href='enable-theme-editor.php'>Enable</a></h2>";
}
?>
<?php
if ($allowedfinal == yes) {
?>
<a href="index.php" class="backtoelggpanel">Back to ElggPanel</a>
<div class="elggpanel-info-1">
<div id="linkmenu1"><a href="theme-editor-topbarcolor.php">Topbar Color</a>
<div class="linkmenu1"><a href="theme-editor-buttoncolor.php">Button Color</a>
<div class="linkmenu1"><a href="theme-editor-backgroundcolor.php">Background Color</a>
<div class="linkmenu1"><a href="theme-editor-headercolor.php">Header Color</a>
</div>
<?php
}
?>
</div>