<?php
// For PHP 5 and up
$handle = fopen("frontpage-enabled.txt", "rb");
$contents = stream_get_contents($handle);
fclose($handle);
?>
<link rel="stylesheet" href="style.css">
<title>ElggPanel - FrontPage Layout</title>
<style type="text/css">
a:link {color:#FFFFFF;} 
a:visited {color:#FFFFFF;}
a:hover {color:#FFFFFF;}  
a:active {color:#FFFFFF;} 
</style>
<?php
if ($contents == yes) {
}
else {
	header("Location: frontpage.php");
}
?>
<body class="frontpage">
<a href="index.php" class="backtoelggpanel">Back to ElggPanel</a><br>
This is where you chose the FrontPage layout.
<form action="frontpage-layout-process.php" method="post">
<select name="layout">
<option value="A">A</option>
<option value="B">B</option>
<option value="C">C</option>
</select>
<input type="submit" value="Choose" />
</form>
<h1>Layout A</h1>
<table width="100%" style="height: 100%;" cellpadding="10" cellspacing="0" border="0"><tr>

<!-- ============ LEFT COLUMN (MENU) ============== -->
<td width="20%" valign="top" bgcolor="blue">
LOGIN BOX
<?php echo $contentbox2; ?>This is section 2 of the FrontPage.
</td>
<td width="80%" valign="top" bgcolor="purple">
<?php echo $contentbox1; ?>This is section 1 of the FrontPage. 
</td></tr></table>
<h2>Layout B</h1>
<center>
<table border="1" cellpadding="5" cellspacing="0" width="100%" height="100%">
<tr><td align="left" valign="top" width="20%" bgcolor="yellow"><center>
<?php echo $contentbox1; ?></center>LOGIN BOX. This is section 1 of the FrontPage
</td><td align="left" valign="top" width="33%" bgcolor="blue">This is section 2 of the FrontPage.
<?php echo $contentbox2; ?>
</td><td align="left" valign="top" width="33%" bgcolor="purple">REGISTER BOX. This is section 3 for the colors only.<center>
</center>
</td></tr></table> 
<h1>Layout C</h1>
<table width="100%" style="height: 100%;" cellpadding="10" cellspacing="0" border="1"><tr>

<!-- ============ LEFT COLUMN (MENU) ============== -->
<td width="80%" valign="top" bgcolor="blue">
<?php echo $contentbox2; ?>This is section 1 of the FrontPage.
</td>
<td width="80%" valign="top" bgcolor="purple">
<?php echo $contentbox1; ?>[LOGIN BOX]<BR></br>This is section 2 of the FrontPage. 
</td></tr></table>
</body>
