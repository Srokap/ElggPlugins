<?php
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

admin_gatekeeper();
$site_url = elgg_get_site_url();
?>
<head>
<link rel="stylesheet" href="style.css">
<title>ElggPanel - FrontPage</title>
</head>
<body class="widgets">
<a href="index.php" class="backtoelggpanel">Back to ElggPanel</a>
<h1>Widgets</h1>
This is where you can add widgets to your site.
<a href="widget1.php">Widget 1</a>
</body>