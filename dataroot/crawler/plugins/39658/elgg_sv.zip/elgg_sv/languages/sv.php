<?php

	$swedish = array(

		/**
		 * Sites
		 */
	
			'item:site' => "Webbplatser",
	
		/**
		 * Sessions
		 */
			
			'login' => "Logga in",
			'loginok' => "Du har loggats in.",
			'loginerror' => "Vi kunde inte logga in dig. Detta kan bero på att du inte har bekräftat ditt konto ännu, att du angav fel inloggningsuppgifter eller att du har gjort för många felaktiga inloggningsförsök i en följd. Se till att dina uppgifter är korrekta och försök en gång till.",
	
			'logout' => "Logga ut",
			'logoutok' => "Du har loggats ut.",
			'logouterror' => "Vi kunde inte logga ut dig. Var god försök igen.",
	
		/**
		 * Errors
		 */
			'exception:title' => "Välkommen till Elgg.",
	
			'InstallationException:CantCreateSite' => "Vi kunde inte skapa en ElggSite med namnet %s och adressen %s",
		
			'actionundefined' => "Din begäran (%s) kändes inte igen av systemet.",
			'actionloggedout' => "Ledsen, du kan inte utföra denna åtgärd när du är utloggad.",
	
			'notfound' => "Det du sökte kunde inte hittas, eller så har du inte tillgång till det.",
			
			'SecurityException:Codeblock' => "Nekades tillgång till att köra privilegierade kodrader",
			'DatabaseException:WrongCredentials' => "Elgg kunde inte ansluta till databasen med angivna uppgifter.",
			'DatabaseException:NoConnect' => "Elgg kunde inte nå databasen '%s', var god kontrollera att den finns och att du har tillgång till den.",
			'SecurityException:FunctionDenied' => "Tillgång till den privilegierade funktionen '%s' nekades.",
			'DatabaseException:DBSetupIssues' => "Flera fel inträffade: ",
			'DatabaseException:ScriptNotFound' => "Elgg kunde inte hitta det sökta databasskriptet på %s.",
			
			'IOException:FailedToLoadGUID' => "Misslyckades med att ladda ny %s från GUID:%d",
			'InvalidParameterException:NonElggObject' => "Skickar ett något som inte är ett ElggObject till en ElggObject-constructor!",
			'InvalidParameterException:UnrecognisedValue' => "Ej igenkänt värde skickat till en constructor.",
			
			'InvalidClassException:NotValidElggStar' => "GUID:%d är inte ett giltligt %s",
			
			'PluginException:MisconfiguredPlugin' => "%s är en felkonfigurerad plugin.",
			
			'InvalidParameterException:NonElggUser' => "Skickade något som inte är en ElggUser till en ElggUser-constructor!",
			
			'InvalidParameterException:NonElggSite' => "Skickade något som inte är en ElggSite till en ElggSite-constructor!",
			
			'InvalidParameterException:NonElggGroup' => "Skickade något som inte är en ElggGroup till en ElggGroup-constructor!",
	
			'IOException:UnableToSaveNew' => "Vi kunde inte spara ny %s",
			
			'InvalidParameterException:GUIDNotForExport' => "GUID har inte angetts under export, detta borde inte inträffa.",
			'InvalidParameterException:NonArrayReturnValue' => "Funktion för serialisering av föremål skickade en parameter som inte var en array",
			
			'ConfigurationException:NoCachePath' => "Cache-sökväg angiven till ingenting!",
			'IOException:NotDirectory' => "%s är ingen katalog.",
			
			'IOException:BaseEntitySaveFailed' => "Vi kunde inte spara nya objektets basala föremålsinformation!",
			'InvalidParameterException:UnexpectedODDClass' => "import() skickade en oväntad ODD-klass",
			'InvalidParameterException:EntityTypeNotSet' => "Föremålstyp måste anges.",
			
			'ClassException:ClassnameNotClass' => "%s är inte en %s.",
			'ClassNotFoundException:MissingClass' => "Klassen '%s' hittades inte, plugin saknas?",
			'InstallationException:TypeNotSupported' => "Typen %s stöds inte. Detta antyder ett fel i din installation, troligen orsakad av en okomplett uppgradering.",

			'ImportException:ImportFailed' => "Vi kunde inte importera elementet %d",
			'ImportException:ProblemSaving' => "Ett problem med att spara %s uppstod",
			'ImportException:NoGUID' => "Nytt föremål skapades som saknar GUID, detta borde inte inträffa.",
			
			'ImportException:GUIDNotFound' => "Föremålet '%d' kunde inte hittas.",
			'ImportException:ProblemUpdatingMeta' => "Det uppstod ett problem med att uppdatera '%s' på föremålet '%d'",
			
			'ExportException:NoSuchEntity' => "Inget sådan föremåls-GUID:%d", 
			
			'ImportException:NoODDElements' => "Inga OpenDD-element hittades i import-datan, import misslyckades.",
			'ImportException:NotAllImported' => "Alla element importerades inte.",
			
			'InvalidParameterException:UnrecognisedFileMode' => "Ej igenkänt fil-läge '%s'",
			'InvalidParameterException:MissingOwner' => "Alla filer måste ha en ägare!",
			'IOException:CouldNotMake' => "Vi kunde inte göra %s",
			'IOException:MissingFileName' => "Du måste ange ett namne innan du öppnar en fil.",
			'ClassNotFoundException:NotFoundNotSavedWithFile' => "Filestore hittades inte eller så sparades inte klassen med filen!",
			'NotificationException:NoNotificationMethod' => "Ingen notifieringsmetod angiven.",
			'NotificationException:NoHandlerFound' => "Ingen hanterare hittades för '%s' eller så gick den inte att anropa.",
			'NotificationException:ErrorNotifyingGuid' => "Ett fel inträffade när %d skulle notifieras",
			'NotificationException:NoEmailAddress' => "Vi kunde inte hämta e-postadressen för GUID:%d",
			'NotificationException:MissingParameter' => "Saknar en obligatorisk parameter, '%s'",
			
			'DatabaseException:WhereSetNonQuery' => "Där SET innehåller en icke-WhereQueryComponent",
			'DatabaseException:SelectFieldsMissing' => "Fält saknas i en SELECT-liknande query",
			'DatabaseException:UnspecifiedQueryType' => "Okänd eller ospecifierad query-typ.",
			'DatabaseException:NoTablesSpecified' => "Inga tabeller specifierade för query.",
			'DatabaseException:NoACL' => "Ingen tillgångskontroll angavs i queryn",
			
			'InvalidParameterException:NoEntityFound' => "Inget föremål hittades, det antingen saknas eller så har du inte tillgång till det.",
			
			'InvalidParameterException:GUIDNotFound' => "GUID:%s kunde inte hittas, eller så har du inte tillgång till det.",
			'InvalidParameterException:IdNotExistForGUID' => "Ledsen, '%s' existerar inte för guid:%d",
			'InvalidParameterException:CanNotExportType' => "Ledsen, jag kan inte exportera '%s'",
			'InvalidParameterException:NoDataFound' => "Vi kunde inte hitta någon data.",
			'InvalidParameterException:DoesNotBelong' => "Tillhör inte föremålet.",
			'InvalidParameterException:DoesNotBelongOrRefer' => "Tillhör inte föremålet eller hänvisar till det.",
			'InvalidParameterException:MissingParameter' => "Parameter saknas, du måste ange ett GUID.",
			
			'SecurityException:APIAccessDenied' => "Ledsen, API-tillgång har avaktiverats av administratören.",
			'SecurityException:NoAuthMethods' => "Ingen autentiseringsmetod hittades som kunde autentisera denna API-förfrågan.",
			'APIException:ApiResultUnknown' => "API-resultatet är av en okänd typ, detta borde aldrig inträffa.", 
			
			'ConfigurationException:NoSiteID' => "Inget sajt-ID har angetts.",
			'InvalidParameterException:UnrecognisedMethod' => "Ej igenkänd anropsmetod '%s'",
			'APIException:MissingParameterInMethod' => "Parametern %s saknas för metoden %s",
			'APIException:ParameterNotArray' => "%s verkar inte vara en array.",
			'APIException:UnrecognisedTypeCast' => "Ej igenkänd typ i casten %s för variabeln '%s' i metoden '%s'",
			'APIException:InvalidParameter' => "Ogiltlig parameter hittades för '%s' i metoden '%s'.",
			'APIException:FunctionParseError' => "%s(%s) innehåller ett parsing-fel.",
			'APIException:FunctionNoReturn' => "%s(%s) returnerade inget värde.",
			'SecurityException:AuthTokenExpired' => "Autentisering-beviset antingen saknas, är ogiltligt eller har utgått.",
			'CallException:InvalidCallMethod' => "%s måste anropas med '%s'",
			'APIException:MethodCallNotImplemented' => "Metodanropet '%s' har inte implementerats.",
			'APIException:AlgorithmNotSupported' => "Algoritmen '%s' stöds inte eller har avaktiverats.",
			'ConfigurationException:CacheDirNotSet' => "Cache-katalogen 'cache_path' inte angiven.",
			'APIException:NotGetOrPost' => "Request-metod måste vara GET eller POST",
			'APIException:MissingAPIKey' => "X-Elgg-apikey HTTP-header saknas",
			'APIException:MissingHmac' => "X-Elgg-hmac-header saknas",
			'APIException:MissingHmacAlgo' => "X-Elgg-hmac-algo-header saknas",
			'APIException:MissingTime' => "X-Elgg-time-header saknas",
			'APIException:TemporalDrift' => "X-Elgg-time är för långt in i det förgångna eller i framtiden. Epoch misslyckades.",
			'APIException:NoQueryString' => "Ingen data i query-strängen",
			'APIException:MissingPOSTHash' => "X-Elgg-posthash-header saknas",
			'APIException:MissingPOSTAlgo' => "X-Elgg-posthash_algo-header saknas",
			'APIException:MissingContentType' => "Content-typ för skickad data saknas",
			'SecurityException:InvalidPostHash' => "Hashen för POST-data är ogiltlig - förväntade %s men fick %s.",
			'SecurityException:DupePacket' => "Paketsignatur redan hittad.",
			'SecurityException:InvalidAPIKey' => "Ogiltlig eller saknad API-nyckel.",
			'NotImplementedException:CallMethodNotImplemented' => "Anropsmetoden '%s' stöds för närvarande inte.",
	
			'NotImplementedException:XMLRPCMethodNotImplemented' => "XML-RPC-anropet '%s' stöds inte.",
			'InvalidParameterException:UnexpectedReturnFormat' => "Anropet till metoden '%s' returnerade ett oväntat resultat.",
			'CallException:NotRPCCall' => "Anropet verkar inte vara ett giltligt XML-RPC-anrop",
	
			'PluginException:NoPluginName' => "Plugin-namnet kunde inte hittas",
	
			'ConfigurationException:BadDatabaseVersion' => "Database-installationen du har möter inte de grundläggande krav som behövs för att köra Elgg. Var god konsultera dokumentationen.",
			'ConfigurationException:BadPHPVersion' => "Du behöver åtminstone PHP version 5.2 för att köra Elgg.",
			'configurationwarning:phpversion' => "Elgg kräver åtminstone PHP version 5.2, du kan installera det på 5.1.6 men vissa funktioner kanske inte fungerar. Använd på egen risk.",
	
	
			'InstallationException:DatarootNotWritable' => "Din data-katalog %s är inte skrivbar.",
			'InstallationException:DatarootUnderPath' => "Din data-katalog %s måste befinna sig utanför sökvägen för din Elgg-installation.",
			'InstallationException:DatarootBlank' => "Du har inte angett en data-katalog.",
	
			'SecurityException:authenticationfailed' => "Användaren kunde inte autentiseras",
	
			'CronException:unknownperiod' => "%s är inte en igenkänd period.",
	
			'SecurityException:deletedisablecurrentsite' => "Du kan inte ta bort eller avaktivera webbplatsen du för närvarande besöker!",
	
			'memcache:notinstalled' => "Modulen PHP memcache är inte installerad, du måste installera php5-memcache",
			'memcache:noservers' => "Ingen memcache-server angiven, var god fyll på variabeln $CONFIG->memcache_servers",
			'memcache:versiontoolow' => "Memcache behöver åtminstone version %s för att fungera, du kör version %s",
			'memcache:noaddserver' => "Stöd för flera servrar är avaktiverat, du kan behöva uppgradera ditt PECL memcache-bibliotek",
	
			'deprecatedfunction' => "Varning: Denna kod använder den förkastade funktionen '%s' och är inte kompatibel med denna versionen av Elgg",
		/**
		 * API
		 */
			'system.api.list' => "Lista alla tillgängliga API-anrop i systemet.",
			'auth.gettoken' => "Detta API-anrop låter en användare logga in, vilket returnerar ett autentiseringsbevis som kan användas istället för användarnamn och lösenord för att autentisera ytterligare anrop.",
	
		/**
		 * User details
		 */

			'name' => "Ditt riktiga namn",
			'email' => "E-postadress",
			'username' => "Användarnamn",
			'password' => "Lösenord",
			'passwordagain' => "Lösenord (samma igen för verifikation)",
			'admin_option' => "Gör denna användare till administratör?",
	
		/**
		 * Access
		 */
	
			'PRIVATE' => "Privat",
			'LOGGED_IN' => "Inloggade användare",
			'PUBLIC' => "Publikt",
			'access:friends:label' => "Vänner",
			'access' => "Tillgång",
	
		/**
		 * Dashboard and widgets
		 */
	
			'dashboard' => "Översikt",
			'dashboard:configure' => "Redigera sida",
			'dashboard:nowidgets' => "Din översikt är din ingång till webbplatsen. Välj 'Redigera sida' för att lägga till småapplikationer som ger inblick i innehållet och aktiviteten på webbplatsen.",

			'widgets:add' => "Lägg till småapplikationer på din sida",
			'widgets:add:description' => "Välj de funktioner du vill lägga till på din sida genom att dra dem från <strong>Småapplikationer</strong> här intill, till en av ytorna här under, och placera dem i den ordning du vill att de ska synas.

För att ta bort en applikation drar du den tillbaka till <strong>Småapplikationer</strong>.",
			'widgets:position:fixed' => "(Fast position på sidan)",
	
			'widgets' => "Småapplikationer",
			'widget' => "Applikation",
			'item:object:widget' => "Småapplikationer",
			'layout:customise' => "Anpassa layout",
			'widgets:gallery' => "Småapplikationer",
			'widgets:leftcolumn' => "Vänster",
			'widgets:fixed' => "Fast position",
			'widgets:middlecolumn' => "Mitten",
			'widgets:rightcolumn' => "Höger",
			'widgets:profilebox' => "Profil-ruta",
			'widgets:panel:save:success' => "Dina småapplikationer är nu sparade.",
			'widgets:panel:save:failure' => "Ett fel inträffade när dina småapplikationer skulle sparas. Var god försök igen.",
			'widgets:save:success' => "Applikationen är nu sparad.",
			'widgets:save:failure' => "Vi kunde inte spara din applikation. Var god försök igen.",
			'widgets:handlernotfound' => "Denna applikation är antingen trasig eller har avaktiverats av administratören.",
	
		/**
		 * Groups
		 */
	
			'group' => "Grupp", 
			'item:group' => "Grupper",
	
		/**
		 * Profile
		 */
	
			'profile' => "Profil",
			'profile:edit:default' => "Ersätt profil-fält",
			'user' => "Användare",
			'item:user' => "Användare",
			'riveritem:single:user' => "en användare",
			'riveritem:plural:user' => "några användare",
	

		/**
		 * Profile menu items and titles
		 */
	
			'profile:yours' => "Din profil",
			'profile:user' => "%ss profil",
	
			'profile:edit' => "Redigera profil",
			'profile:profilepictureinstructions' => "Profilbilden är bilden som visas på din profilsida. Du kan ändra den så ofta du vill (filformat som fungerar är GIF, JPG eller PNG).",
			'profile:icon' => "Profilbild",
			'profile:createicon' => "Skapa din avatar",
			'profile:currentavatar' => "Nuvarande avatar",
			'profile:createicon:header' => "Profilbild",
			'profile:profilepicturecroppingtool' => "Beskärverktyg för profilbild",
			'profile:createicon:instructions' => "Klicka och dra en kvadrat här nedan för att ange hur du vill ha din bild beskuren. En förhandsvisning av din beskurna bild kommer att synas i rutan här intill. När du är nöjd med förhandsvisningen, välj 'Skapa din avatar'. Denna beskurna bild kommer att användas som din avatar (liten profilbild) över hela webbplatsen.",
	
			'profile:editdetails' => "Redigera detaljer",
			'profile:editicon' => "Redigera profil-ikon",
	
			'profile:aboutme' => "Om mig", 
			'profile:description' => "Om mig",
			'profile:briefdescription' => "Kort beskrivning",
			'profile:location' => "Plats",
			'profile:skills' => "Kompetenser",  
			'profile:interests' => "Intressen", 
			'profile:contactemail' => "E-postadress",
			'profile:phone' => "Telefon",
			'profile:mobile' => "Mobiltelefon",
			'profile:website' => "Hemsida",
	
			'profile:banned' => "Detta användarkonto har upphört.",

			'profile:river:update' => "%s uppdaterade sin profil",
			'profile:river:iconupdate' => "%s uppdaterade sin profil-ikon",
	
			'profile:label' => "Profil-etikett",
			'profile:type' => "Profil-typ",
	
			'profile:editdefault:fail' => "Standardprofil kunde inte sparas",
			'profile:editdefault:success' => "Objektet lades till på standardprofilen",
	
			'profile:editdefault:delete:fail' => "Borttagning av fält på standardprofilen misslyckades",
			'profile:editdefault:delete:success' => "Fält på standardprofilen har nu tagits bort!",
	
			'profile:defaultprofile:reset' => "Systemets standardprofil nollställd",
	
			'profile:resetdefault' => "Nollställ standardprofil",
	
		/**
		 * Profile status messages
		 */
	
			'profile:saved' => "Din profil är nu sparad.",
			'profile:icon:uploaded' => "Din profilbild är nu uppladdad.",
	
		/**
		 * Profile error messages
		 */
	
			'profile:noaccess' => "Du har inte behörighet att redigera denna profil.",
			'profile:notfound' => "Ledsen, vi kunde inte hitta den sökta profilen.",
			'profile:cantedit' => "Ledsen, du har inte behörighet att redigera denna profil.",
			'profile:icon:notfound' => "Ledsen, ett fel inträffade när du skulle ladda upp din profilbild.",
	
		/**
		 * Friends
		 */
	
			'friends' => "Vänner",
			'friends:yours' => "Mina vänner",
			'friends:owned' => "%ss vänner",
			'friend:add' => "Lägg till vän",
			'friend:remove' => "Ta bort vän",
	
			'friends:add:successful' => "Du har lagt till %s som vän.",
			'friends:add:failure' => "Vi kunde inte lägga till %s som din vän. Var god försök igen.",
	
			'friends:remove:successful' => "Du har tagit bort %s från listan över dina vänner.",
			'friends:remove:failure' => "Vi kunde inte ta bort %s från listan över dina vänner. Var god försök igen.",
	
			'friends:none' => "Denna användarer har inte lagt till någon som sin vän ännu.",
			'friends:none:you' => "Du har inte lagt till någon som din vän! Sök efter dina intressen för att börja hitta likasinnade att hålla kontakten med.",
	
			'friends:none:found' => "Inga vänner hittades.",
	
			'friends:of:none' => "Ingen har lagt till denna användare som vän ännu.",
			'friends:of:none:you' => "Ingen har lagt till dig som sin vän ännu. Börja skapa lite innehåll och komplettera din profil så att fler kan hitta dig!",
	
			'friends:of:owned' => "Användare som har lagt till %s som vän",

			'friends:num_display' => "Antal vänner att visa",
			'friends:icon_size' => "Ikon-storlek",
			'friends:tiny' => "pytteliten",
			'friends:small' => "liten",
			'friends:of' => "Vänner till",
			'friends:collections' => "Bekantskapskrets",
			'friends:collections:add' => "Ny bekantskapskrets",
			'friends:addfriends' => "Lägg till vänner",
			'friends:collectionname' => "Namn på bekantskapskrets",
			'friends:collectionfriends' => "Vänner i bekantskapskrets",
			'friends:collectionedit' => "Redigera denna bekantskapskrets",
			'friends:nocollections' => "Du har ännu skapat en bekantskapskrets.",
			'friends:collectiondeleted' => "Din bekantskapskrets har tagits bort från listan.",
			'friends:collectiondeletefailed' => "Vi kunde inte ta bort bekantskapskretsen. Antingen har du inte tillgång till detta eller så gick något annat snett.",
			'friends:collectionadded' => "Din bekantskapskrets är nu skapad",
			'friends:nocollectionname' => "Du måste ge din bekantskapskrets ett namn innan den kan skapas.",
			'friends:collections:members' => "Vänner i bekantskapskretsen",
			'friends:collections:edit' => "Redigera bekantskapskrets",
		
			'friends:river:created' => "%s lade till vänner-applikationen.",
			'friends:river:updated' => "%s uppdaterade sin vänner-applikation.",
			'friends:river:delete' => "%s tog bort sin vänner-applikation.",
			'friends:river:add' => "%s är nu vän med",
	
			'friendspicker:chararray' => "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
	
		/**
		 * Feeds
		 */
			'feed:rss' => "Prenumerera på flöde",
			'feed:odd' => "Syndikera OpenDD",
			
		/**
          * links
		 **/

			'link:view' => "besök länk",

	
		/**
		 * River
		 */
			'river' => "Logg",
			'river:relationship:friend' => "är nu vän med",
			'river:noaccess' => "Du har inte behörighet att se detta.",
			'river:posted:generic' => "%s skrev",

		/**
		 * Plugins
		 */
			'plugins:settings:save:ok' => "Inställningarna för pluginen %s är nu sparade.",
			'plugins:settings:save:fail' => "Ett fel inträffade när inställningarna för pluginen %s skulle sparas.",
			'plugins:usersettings:save:ok' => "Användarinställningarna för pluginen %s är nu sparade.",
			'plugins:usersettings:save:fail' => "Ett fel inträffade när användarinställningarna för pluginen %s skulle sparas.",
			'admin:plugins:label:version' => "Version",
			'item:object:plugin' => "Plugin-inställningar",
			
		/**
		 * Notifications
		 */
			'notifications:usersettings' => "Notifierings-inställningar",
			'notifications:methods' => "Var god ange vilka metoder du vill tillåta.",
	
			'notifications:usersettings:save:ok' => "Dina notifieringsinställningar är nu sparade.",
			'notifications:usersettings:save:fail' => "Ett fel inträffade när dina notifieringsinställningar skulle sparas.",
	
			'user.notification.get' => "Hämtar notifieringsinställningarna för en viss användare.",
			'user.notification.set' => "Anger notifieringsinställningarna för en viss användare.",
		/**
		 * Search
		 */
	
			'search' => "Sök",
			'searchtitle' => "Sök: %s",
			'users:searchtitle' => "Söker efter användare: %s",
			'advancedsearchtitle' => "%s som matchar %s",
			'notfound' => "Inga sökträffar.",
			'next' => "Nästa",
			'previous' => "Föregående",
	
			'viewtype:change' => "Ändra typ av lista",
			'viewtype:list' => "Lista",
			'viewtype:gallery' => "Tabell",
	
			'tag:search:startblurb' => "Träffar med taggar som matchar '%s':",

			'user:search:startblurb' => "Användare som matchar '%s':",
			'user:search:finishblurb' => "För att se mer, klicka här.",
	
		/**
		 * Account
		 */
	
			'account' => "Konto",
			'settings' => "Inställningar",
			'tools' => "Verktyg",
			'tools:yours' => "Mina verktyg",
	
			'register' => "Registrera",
			'registerok' => "Du har nu registrets som %s.",
			'registerbad' => "Registrering misslyckades. Användarnamnet kan vara upptaget, dina angivna lösenord matchar inte eller så är användarnamnet och/eller lösenordet för kort.",
			'registerdisabled' => "Registrering har avaktiverats av administratören",
	
			'firstadminlogininstructions' => "Din Elgg-webbplats har nu installerats och ditt administratörskonto skapats. Du kan nu anpassa din webbplats ytterligare genom att aktivera diverse installerade pluginverktyg.",
	
			'registration:notemail' => "E-postadressen du angav verkar inte var en giltlig e-postadress.",
			'registration:userexists' => "Det användarnamnet används redan",
			'registration:usernametooshort' => "Ditt användarnamn måste vara minst fyra tecken lång.",
			'registration:passwordtooshort' => "Lösenordet måste vara minst sex tecken långt.",
			'registration:dupeemail' => "This email address has already been registered.",
			'registration:invalidchars' => "Ledsen, ditt användarnamn innehåller ogiltliga tecken.",
			'registration:emailnotvalid' => "Ledsen, e-postadressen du angav är ogiltlig på detta system",
			'registration:passwordnotvalid' => "Ledsen, lösenordet du angav är ogiltlig på detta system",
			'registration:usernamenotvalid' => "Ledsen, användarnamnet du angav är ogiltlig på detta system",
	
			'adduser' => "Lägg till användare",
			'adduser:ok' => "Du har nu lagt till en ny användare.",
			'adduser:bad' => "Den nya användaren kunde inte läggas till.",
			
			'item:object:reported_content' => "Anmälda objekt",
	
			'user:set:name' => "Namninställningar",
			'user:name:label' => "Ditt namn",
			'user:name:success' => "Ditt namn har nu ändrats på webbplatsen.",
			'user:name:fail' => "Vi kunde inte ändra ditt namn på webbplatsen.",
	
			'user:set:password' => "Lösenordsinställningar",
			'user:password:label' => "Ditt nya lösenord",
			'user:password2:label' => "Ditt nya lösenord igen",
			'user:password:success' => "Lösenordet ändrat",
			'user:password:fail' => "Vi kunde inte ändra ditt lösenord på webbplatsen.",
			'user:password:fail:notsame' => "Lösenorden är inte samma!",
			'user:password:fail:tooshort' => "Lösenordet är för kort!",
	
			'user:set:language' => "Språkinställningar",
			'user:language:label' => "Ditt språk",
			'user:language:success' => "Dina språkinställningar har nu uppdaterats.",
			'user:language:fail' => "Dina språkinställningar kunde inte sparat.",
	
			'user:username:notfound' => "Användarnamnet %s hittades inte.",
	
			'user:password:lost' => "Glömt ditt lösenord?",
			'user:password:resetreq:success' => "Nytt lösenord begärt, e-postmeddelande skickat",
			'user:password:resetreq:fail' => "Vi kunde inte begära ett nytt lösenord.",
	
			'user:password:text' => "För att skapa och skicka dig ett nytt lösenord, ange ditt användarnamn nedan. Vi kommer då att skicka dig ett e-postmeddelande med en länk till en bekräftelsesida som du ska gå till för att få ett nytt lösenord skickat till dig.",
	
			'user:persistent' => "Kom ihåg mig",
		/**
		 * Administration
		 */

			'admin:configuration:success' => "Dina inställningar har nu sparats.",
			'admin:configuration:fail' => "Dina inställningar kunde inte sparas.",
	
			'admin' => "Administration",
			'admin:description' => "Administrationspanelen låter dig kontrollera alla aspekter av webbplatsen, från användahantering till hur pluginverktygen beter sig. Välj ett tillval nedan för att komma igång.",
			
			'admin:user' => "Användaradministration",
			'admin:user:description' => "Denna administrationspanel låter dig kontrollera alla användarinställningar för din webbplats. Välj ett tillval nedan för att komma igång.",
			'admin:user:adduser:label' => "Lägg till ny användare...",
			'admin:user:opt:linktext' => "Ställ in användarinformation...",
			'admin:user:opt:description' => "Ställ in användare- och kontoinformation. ",
			
			'admin:site' => "Webbplatsadministration",
			'admin:site:description' => "Denna administrationspanel låter dig kontrollera alla globala inställningar för din webbplats. Välj ett tillval nedan för att komma igång.",
			'admin:site:opt:linktext' => "Ställ in webbplats...",
			'admin:site:opt:description' => "Ställ inte webbplatsens tekniska och icke-tekniska inställningar.",
			'admin:site:access:warning' => "Ändringar av tillgångsinställningar påverkar bara tillgången till innehåll som skapas från och med nu.", 
			
			'admin:plugins' => "Verktygsadministration",
			'admin:plugins:description' => "Denna administrationspanel låter dig kontrollera och ställa in de verktyg som är installerade på din webbplats.",
			'admin:plugins:opt:linktext' => "Ställ in verktyg...",
			'admin:plugins:opt:description' => "Ställ in verktyg installerade på webbplatsen ",
			'admin:plugins:label:author' => "Skapare",
			'admin:plugins:label:copyright' => "Copyright",
			'admin:plugins:label:licence' => "Licens",
			'admin:plugins:label:website' => "URL",
			'admin:plugins:label:moreinfo' => "mer information",
			'admin:plugins:label:version' => "Version",
			'admin:plugins:warning:elggversionunknown' => "Varning: Denna plugin anger inte en kompatibel Elgg-version.",
			'admin:plugins:warning:elggtoolow' => "Varning: Denna plugin kräver en senare version av Elgg!",
			'admin:plugins:reorder:yes' => "Pluginen %s är nu flyttad.",
			'admin:plugins:reorder:no' => "Pluginen %s kunde inte flyttas.",
			'admin:plugins:disable:yes' => "Pluginen %s är nu avaktiverad.",
			'admin:plugins:disable:no' => "Pluginen %s kunde inte avaktiveras.",
			'admin:plugins:enable:yes' => "Pluginen %s är nu aktiverad.",
			'admin:plugins:enable:no' => "Pluginen %s kunde inte aktiveras.",
	
			'admin:statistics' => "Statistik",
			'admin:statistics:description' => "Detta är en översikt över all statistik på din webbplats. Om du behöver mer detaljerad statistik finns det även en mer omfattande administrationsfunktion.",
			'admin:statistics:opt:description' => "Visa statistik över användare och objekt på din webbplats.",
			'admin:statistics:opt:linktext' => "Visa statistik...",
			'admin:statistics:label:basic' => "Grundläggande webbplatsstatistik",
			'admin:statistics:label:numentities' => "Föremål på webbplatsen",
			'admin:statistics:label:numusers' => "Antal användare",
			'admin:statistics:label:numonline' => "Antal inloggade användare",
			'admin:statistics:label:onlineusers' => "Användare inloggade nu",
			'admin:statistics:label:version' => "Elgg-version",
			'admin:statistics:label:version:release' => "Release",
			'admin:statistics:label:version:version' => "Version",
	
			'admin:user:label:search' => "Sök användare:",
			'admin:user:label:seachbutton' => "Sök", 
	
			'admin:user:ban:no' => "Vi kunde inte utestänga användare",
			'admin:user:ban:yes' => "Användare utestängd.",
			'admin:user:unban:no' => "Vi kunde inte släppa in användare",
			'admin:user:unban:yes' => "Användare insläppt igen.",
			'admin:user:delete:no' => "Vi kunde inte ta bort användare",
			'admin:user:delete:yes' => "Användaren har nu tagits bort",
	
			'admin:user:resetpassword:yes' => "Lösenordet nollställt, användaren meddelad.",
			'admin:user:resetpassword:no' => "Lösenordet kunde inte nollställas.",
	
			'admin:user:makeadmin:yes' => "Användaren är nu en administratör.",
			'admin:user:makeadmin:no' => "Vi kunde inte göra användaren till administratör.",
	
			'admin:user:removeadmin:yes' => "Användaren är inte längre en administratör.",
			'admin:user:removeadmin:no' => "Vi kunde inte ta bort administratörsrättigheterna för denna användare.",
			
		/**
		 * User settings
		 */
			'usersettings:description' => "Administrationspanelen för användarinställningar låter dig kontrollera alla användares personliga inställningar, från användarhantering till hur pluginverktygen beter sig. Välj ett tillval nedan för att komma igång.",
	
			'usersettings:statistics' => "Min statistik",
			'usersettings:statistics:opt:description' => "Visa statistik över alla användare och objekt på webbplatsen.",
			'usersettings:statistics:opt:linktext' => "Kontostatistik",
	
			'usersettings:user' => "Mina inställningar",
			'usersettings:user:opt:description' => "Denna administrationspanel låter dig kontrollera användarinställningar.",
			'usersettings:user:opt:linktext' => "Ändra dina inställningar",
	
			'usersettings:plugins' => "Verktyg",
			'usersettings:plugins:opt:description' => "Ställ in eventuella inställningar för dina aktiva pluginverktyg.",
			'usersettings:plugins:opt:linktext' => "Ställ in dina verktyg",
	
			'usersettings:plugins:description' => "Denna administrationspanel låter dig kontrollera och ställa in personliga inställningar för de verktyg som installerats av administratören.",
			'usersettings:statistics:label:numentities' => "Mina föremål",
	
			'usersettings:statistics:yourdetails' => "Mina kontouppgifter",
			'usersettings:statistics:label:name' => "Fullständigt namn",
			'usersettings:statistics:label:email' => "E-postadress",
			'usersettings:statistics:label:membersince' => "Registrerad sedan",
			'usersettings:statistics:label:lastlogin' => "Senast inloggad",
	
			
	
		/**
		 * Generic action words
		 */
	
			'save' => "Spara",
			'publish' => "Publicera",
			'cancel' => "Avbryt",
			'saving' => "Sparar...",
			'update' => "Uppdatera",
			'edit' => "Redigera",
			'delete' => "Ta bort",
			'accept' => "Godkänn",
			'load' => "Läs in",
			'upload' => "Ladda upp",
			'ban' => "Utestäng",
			'unban' => "Släpp in",
			'enable' => "Aktivera",
			'disable' => "Avaktivera",
			'request' => "Förfrågan",
			'complete' => "Komplett",
			'open' => "Öppna",
			'close' => "Stäng",
			'reply' => "Besvara",
			'more' => "Mer",
			'comments' => "Kommentarer",
			'import' => "Importera",
			'export' => "Exportera",
	
			'up' => "Upp",
			'down' => "Ned",
			'top' => "Överst",
			'bottom' => "Nederst",
	
			'invite' => "Bjud in",
	
			'resetpassword' => "Nollställ lösenord",
			'makeadmin' => "Gör till administratör",
			'removeadmin' => "Ta bort som administratör",
	
			'option:yes' => "Ja",
			'option:no' => "Nej",
	
			'unknown' => "Okänd",
	
			'active' => "Aktiv",
			'total' => "Totalt",
	
			'learnmore' => "Läs mer här.",
	
			'content' => "innehåll",
			'content:latest' => "Senaste aktivitet",
			'content:latest:blurb' => "Alternativt, klicka här för att se det senaste innehållet för hela webbplatsen.",
	
			'link:text' => "besök länk",
	
			'enableall' => "Aktivera alla",
			'disableall' => "Avaktivera alla",
	
		/**
		 * Generic questions
		 */
	
			'question:areyousure' => "Är du säker?",
	
		/**
		 * Generic data words
		 */
	
			'title' => "Rubrik",
			'description' => "Beskrivning",
			'tags' => "Taggar",
			'spotlight' => "I fokus",
			'all' => "Alla",
	
			'by' => "av",
	
			'annotations' => "Anteckningar",
			'relationships' => "Relationer",
			'metadata' => "Metadata",
	
		/**
		 * Input / output strings
		 */

			'deleteconfirm' => "Är du säker på att du vill ta bort detta?",
			'fileexists' => "En fil har redan laddats upp. För att ta bort den, markera den nedan:",
			
		/**
		 * User add
		 */

			'useradd:subject' => "Användarkonto skapat",
			'useradd:body' => "
Hej %s,

Ett användarkonto har nu skapats åt dig på %s. För att logga in, gå till:

	%s

...och logga in med dessa uppgifter:

	Användarnamn: %s
	Lösenord: %s
	
När du väl loggat in rekommenderar vi starkt att du ändrar ditt lösenord.
",
			
	    /**
         * System messages
         **/

			'systemmessages:dismiss' => "klicka för att dölja",

	
		/**
		 * Import / export
		 */
			'importsuccess' => "Data-import lyckades",
			'importfail' => "OpenDD-import av data misslyckades.",
	
		/**
		 * Time
		 */
	
			'friendlytime:justnow' => "alldeles nyss",
			'friendlytime:minutes' => "för %s minuter sedan",
			'friendlytime:minutes:singular' => "för en minut sedan",
			'friendlytime:hours' => "för %s timmar sedan",
			'friendlytime:hours:singular' => "för en timma sedan",
			'friendlytime:days' => "för %s dagar sedan",
			'friendlytime:days:singular' => "igår",
	
			'date:month:01' => 'januari %s',
			'date:month:02' => 'februari %s',
			'date:month:03' => 'mars %s',
			'date:month:04' => 'april %s',
			'date:month:05' => 'maj %s',
			'date:month:06' => 'juni %s',
			'date:month:07' => 'juli %s',
			'date:month:08' => 'augusti %s',
			'date:month:09' => 'september %s',
			'date:month:10' => 'oktober %s',
			'date:month:11' => 'november %s',
			'date:month:12' => 'december %s',
	
	
		/**
		 * Installation and system settings
		 */
	
			'installation:error:htaccess' => "Elgg behöver en fil som heter .htaccess i sin root-katalog. Vi försökte återskapa den åt dig men Elgg har inte skrivrättigheter för den katalogen. 

Att själv skapa denna fil är lätt. Kopiera innehållet i textrutan nedan in i en texteditor och spara filen som .htaccess

",
			'installation:error:settings' => "Elgg kunde inte hitta sin inställningsfil. De flesta av Elggs inställningar kommer att vi att ta hand om åt dig, men du behöver ge oss dina databasuppgifter. För att göra detta måste du:

1. Döpa om filen engine/settings.example.php till settings.php i din Elgg-installation.

2. Öppna filen med en texteditor och ange uppgifterna för din databas. Om du inte kan dessa, be lämplig systemadministratör eller teknisk support om hjälp.

Alternativt kan du ange dina databasuppgifter nedan, så ska vi försöka göra detta åt dig...",
	
			'installation:error:configuration' => "När du korrigerat eventuella felaktiga inställningar, ladda om sidan och försök igen.",
	
			'installation' => "Installation",
			'installation:success' => "Elggs databas är nu installerad.",
			'installation:configuration:success' => "Dina allra första inställningar är nu sparade. Registrera nu din allra första användare som också kommer att bli webbplatsens första administratör.",
	
			'installation:settings' => "Webbplatsinställningar",
			'installation:settings:description' => "Nu när Elgg-databasen har installerats behöver du ange ytterligare några saker för att få din webbplats att rulla helt och fullt. Vi försökte gissa där vi kunde, men du <strong>bör kontrollera dessa uppgifter.</strong>",
	
			'installation:settings:dbwizard:prompt' => "Ange dina databasinställningar nedan och välj Spara:",
			'installation:settings:dbwizard:label:user' => "Databasanvändare",
			'installation:settings:dbwizard:label:pass' => "Databaslösenord",
			'installation:settings:dbwizard:label:dbname' => "Elgg-databas",
			'installation:settings:dbwizard:label:host' => "Databasens värdnamn (ofta 'localhost')",
			'installation:settings:dbwizard:label:prefix' => "Databasens tabellprefix (t ex 'elgg')",
	
			'installation:settings:dbwizard:savefail' => "Vi kunde inte spara den nya filen settings.php. Var god spara följande som engine/settings.php med hjälp av en texteditor.",
	
			'installation:sitename' => "Namnet på din webbplats (t ex \"Mitt sociala nätverk\"):",
			'installation:sitedescription' => "Kort beskrivning av din webbplats (valfritt)",
			'installation:wwwroot' => "Webbplatsens URL (avsluta med ett snedstreck):",
			'installation:path' => "Fullständig sökväg till din webbplats root-katalog, följt av ett avslutande snedstreck:",
			'installation:dataroot' => "Fullständig sökväg till katalogen där uppladdade filer ska lagras, följt av ett avslutande snedstreck:",
			'installation:dataroot:warning' => "Du måste skapa denna katalog manuellt. Den får inte ligga i samma katalog som de övriga filerna i Elgg-installation ligger.",
			'installation:sitepermissions' => "Standardbehörigheter:",
			'installation:language' => "Standardspråk för din webbplats:",
			'installation:debug' => "Debug-läget erbjuder extra information som kan användas för att lokalisera fel men kan samtidigt slöa ner webbplatsen, så använd bara detta tillval om du tror dig ha problem:",
			'installation:debug:label' => "Aktivera debug-läge",
			'installation:httpslogin' => "Aktivera detta för att inloggningar ska ske över säker HTTP. Du behöver ha HTTPS aktiverat på din webbserver för att detta ska fungera.",
			'installation:httpslogin:label' => "Aktivera HTTPS-inloggning",
			'installation:usage' => "Detta tillval låter Elgg skicka anonym statistik över hur webbplatsen används till Elggs skapare, Curverider.",
			'installation:usage:label' => "Skicka anonym användningsstatistik",
			'installation:view' => "Ange vilken vy som ska användas som standard för din webbplats, eller lämna tomt för standardvyn (är du osäker, lämna detta tomt):",

			'installation:siteemail' => "E-postadress för webbplatsen (används som avsändare när webbplatsen skickar e-postmeddelanden)",
	
			'installation:disableapi' => "RESTful-APIet är ett flexibelt och utbyggbart gränssnitt som gör att applikationer på andra servrar kan komma åt vissa Elgg-funktioner.",
			'installation:disableapi:label' => "Aktivera RESTful-APIet",
			
			'installation:allow_user_default_access:description' => "Om denna aktiveras kan enskilda användare själva ange sin egen standardinställning för vem som ska kunna se deras innehåll, vilket åsidosätter webbplatsens standardinställning för detta tillval.",
			'installation:allow_user_default_access:label' => "Tillåt egen standardinställning för behörighet",
	
			'installation:simplecache:description' => "Det enkla cachet ökar prestandan genom att cacha statiskt innehåll inklusive vissa CSS- och JavaScript-filer. Normalt sett vill du ha detta aktiverat.",
			'installation:simplecache:label' => "Använd enkelt cache",
	
			'upgrading' => "Uppgraderar",
			'upgrade:db' => "Din databas är nu uppgraderad.",
			'upgrade:core' => "Din Elgg-installation är nu uppgraderad",
	
		/**
		 * Welcome
		 */
	
			'welcome' => "Välkommen",
			'welcome_message' => "Välkommen till denna Elgg-installation.",
	
		/**
		 * Emails
		 */
			'email:settings' => "E-postinställningar",
			'email:address:label' => "Din e-postadress",
			
			'email:save:success' => "Ny e-postadress sparad, bekräftelsemeddelande skickat.",
			'email:save:fail' => "Din nya e-postadress kunde inte sparas.",
	
			'friend:newfriend:subject' => "%s har lagt till dig som vän!",
			'friend:newfriend:body' => "%s har lagt till dig som vän!

För att se hennes/hans profilsida, gå till:

	%s

Observera att du inte kan besvara detta e-postmeddelande.",

			'email:resetpassword:subject' => "Lösenord nollställt!",
			'email:resetpassword:body' => "Hej %s,
			
Ditt lösenord har nollställts till: %s",
	
			'email:resetreq:subject' => "Begäran om nytt lösenord.",
			'email:resetreq:body' => "Hej %s,
			
Någon (från IP-adressen %s) har begärt ett nytt lösenord för sitt Elgg-användarkonto.

Om du begärde detta kan du följa länken nedan, annars kan du ignorera detta meddelande.

%s
",

		/**
		 * user default access
		 */
	
		'default_access:settings' => "Din standardbehörighetsnivå",
		'default_access:label' => "Standardbehörighet",
		'user:default_access:success' => "Din nya standardbehörighetsnivå är nu sparad.",
		'user:default_access:failure' => "Din nya standardbehörighetsnivå kunde inte sparas.",
	
		/**
		 * XML-RPC
		 */
			'xmlrpc:noinputdata'	=>	"Input-data saknas",
	
		/**
		 * Comments
		 */
	
			'comments:count' => "%s kommentarer",
			
			'riveraction:annotation:generic_comment' => '%s kommenterade på %s',
	
			'generic_comments:add' => "Lägg till en kommentar",
			'generic_comments:text' => "Kommentar",
			'generic_comment:posted' => "Din kommentar är nu skickad.",
			'generic_comment:deleted' => "Din kommentar har nu tagits bort.",
			'generic_comment:blank' => "Ledsen, du måste ju skriva en kommentar innan vi kan spara någon.",
			'generic_comment:notfound' => "Ledsen, vi kunde inte hitta det du sökte.",
			'generic_comment:notdeleted' => "Ledsen, vi kunde inte ta bort denna kommentar.",
			'generic_comment:failure' => "Ett oväntat fel uppstod när din kommentar skulle skickas. Var god försök igen.",
	
			'generic_comment:email:subject' => "Du har fått en ny kommentar!",
			'generic_comment:email:body' => "Du har fått en ny kommentar på \"%s\" från %s. Den lyder som följer:
			
%s


För att besvara den eller se ursprungsobjektet, gå till:

	%s

För att se %ss profilsida, gå till:

	%s

Observera att du inte kan besvara detta meddelande.",
	
		/**
		 * Entities
		 */
			'entity:default:strapline' => "Skapad %s av %s",
			'entity:default:missingsupport:popup' => "Detta föremål kan inte visas korrekt. Det kan bero på att det kräver stöd av en plugin som inte längre är installerad.",
	
			'entity:delete:success' => "Föremålet %s har tagits bort",
			'entity:delete:fail' => "Föremålet %s kunde inte tas bort",
	
	
		/**
		 * Action gatekeeper
		 */
			'actiongatekeeper:missingfields' => "Formuläret sakner fältet __token eller __ts",
			'actiongatekeeper:tokeninvalid' => "Vi stötte på ett problem (autentiseringsbevisen matchar inte). Detta innebär troligen att sidan du använde har utgått. Var god försök igen.",
			'actiongatekeeper:timeerror' => "Sidan du använde har utgått. Var god ladda om sidan och försök igen.",
			'actiongatekeeper:pluginprevents' => "Ett tillägg har hindrat detta formulär från att skickas.",
	
		/**
		 * Word blacklists
		 */
			'word:blacklist' => 'och, den, sedan, men, hon, hans, hennes, honom, en, inte, även, om, nu, därför, men, fortfarande, likaså, annorlunda, därför, omvänt, hellre, följaktligen, dessutom, trots, istället, samtidigt, enlighet, detta, verkar, vad, vem, vars, vilka, vilket',
	
		/**
		 * Languages according to ISO 639-1
		 */
			"aa" => "Afar",
			"ab" => "Abchaziska",
			"af" => "Afrikaans",
			"am" => "Amhariska",
			"ar" => "Arabiska",
			"as" => "Assamesiska",
			"ay" => "Aymara",
			"az" => "Azerbajdzjanska",
			"ba" => "Basjkiriska",
			"be" => "Vitryska",
			"bg" => "Bulgariska",
			"bh" => "Bihari",
			"bi" => "Bislama",
			"bn" => "Bengali",
			"bo" => "Tibetanska",
			"br" => "Bretonska",
			"ca" => "Katalanska",
			"co" => "Korsikanska",
			"cs" => "Tjeckiska",
			"cy" => "Kymriska",
			"da" => "Danska",
			"de" => "Tyska",
			"dz" => "Tibetanska (dzhongkha)",
			"el" => "Grekiska",
			"en" => "Engelska",
			"eo" => "Esperanto",
			"es" => "Spanska",
			"et" => "Estniska",
			"eu" => "Baskiska",
			"fa" => "Persiska (farsi)",
			"fi" => "Finska",
			"fj" => "Fiji",
			"fo" => "Färöiska",
			"fr" => "Franska",
			"fy" => "Frisiska",
			"ga" => "Iriska",
			"gd" => "Gaeliska",
			"gl" => "Galiciska",
			"gn" => "Guarani",
			"gu" => "Gujarati",
			"ha" => "Hausa",
			"he" => "Hebreiska",
			"hi" => "Hindi",
			"hr" => "Kroatiska",
			"hu" => "Ungerska",
			"hy" => "Armeniska",
			"ia" => "Interlingua",
			"id" => "Indonesiska",
			"ie" => "Interlingue",
			"ik" => "Inupiak",
			//"in" => "Indonesiska",
			"is" => "Isländska",
			"it" => "Italienska",
			"iu" => "Inuktitut",
			"iw" => "Hebreiska",
			"ja" => "Japanska",
			"ji" => "Jiddisch",
			"jv" => "Javanesiska",
			"ka" => "Georgiska",
			"kk" => "Kazakiska",
			"kl" => "Grönländska",
			"km" => "Kambodjanska",
			"kn" => "Kannada",
			"ko" => "Koreanska",
			"ks" => "Kashmiri",
			"ku" => "Kurdiska",
			"ky" => "Kirgiziska",
			"la" => "Latin",
			"ln" => "Lingala",
			"lo" => "Laotiska",
			"lt" => "Litauiska",
			"lv" => "Lettiska",
			"mg" => "Madagaskiska",
			"mi" => "Maori",
			"mk" => "Makedonska",
			"ml" => "Malayalam",
			"mn" => "Mongoliska",
			"mo" => "Moldaviska",
			"mr" => "Marathi",
			"ms" => "Malajiska",
			"mt" => "Maltesiska",
			"my" => "Burmesiska",
			"na" => "Nauriska",
			"ne" => "Nepali",
			"nl" => "Nederländska",
			"no" => "Norska",
			"oc" => "Occitanska",
			"om" => "Afan oromo",
			"or" => "Oriya",
			"pa" => "Punjabi",
			"pl" => "Polska",
			"ps" => "Pashto",
			"pt" => "Portugisiska",
			"qu" => "Quechua",
			"rm" => "Rätoromanska",
			"rn" => "Kirundi",
			"ro" => "Rumänska",
			"ru" => "Ryska",
			"rw" => "Kinyarwanda",
			"sa" => "Sanskrit",
			"sc" => "Sardiska",
			"sd" => "Sindhi",
			"sg" => "Sangho",
			"sh" => "Serbokroatiska",
			"si" => "Singalesiska",
			"sk" => "Slovakiska",
			"sl" => "Slovenska",
			"sm" => "Samoanska",
			"sn" => "Shona",
			"so" => "Somaliska",
			"sq" => "Albanska",
			"sr" => "Serbiska",
			"ss" => "Siswati",
			"st" => "Sesotho",
			"su" => "Sundanesiska",
			"sv" => "Svenska",
			"sw" => "Swahili",
			"ta" => "Tamil",
			"te" => "Telugu",
			"tg" => "Tadzjikiska",
			"th" => "Thailändska",
			"ti" => "Tigrinja",
			"tk" => "Turkmenska",
			"tl" => "Tagalog",
			"tn" => "Setswana",
			"to" => "Tonganska",
			"tr" => "Turkiska",
			"ts" => "Tsonga",
			"tt" => "Tatariska",
			"tw" => "Twi",
			"ug" => "Uiguriska",
			"uk" => "Ukrainska",
			"ur" => "Urdu",
			"uz" => "Uzbekiska",
			"vi" => "Vietnamesiska",
			"vo" => "Volapük",
			"wo" => "Wolof",
			"xh" => "Xhosa",
			//"y" => "Yiddish",
			"yi" => "Jiddisch",
			"yo" => "Yoruba",
			"za" => "Zhuang",
			"zh" => "Kinesiska",
			"zu" => "Zulu",
	);
	
	add_translation("sv",$swedish);

?>
