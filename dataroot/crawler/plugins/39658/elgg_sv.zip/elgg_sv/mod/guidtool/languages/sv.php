<?php
	/**
	 * Elgg GUID Tool
	 * 
	 * @package ElggGUIDTool
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$swedish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'guidtool' => 'GUID-verktyg',
			'guidtool:browse' => 'Bläddra bland GUIDn',
			'guidtool:import' => 'Importera',
			'guidtool:import:desc' => 'Klistra in den data du vill importera i följande fönster, detta måste vara i formatet "%s".',
	
			'guidtool:pickformat' => 'Var god välj det format du vill importera eller exportera.',
	
			'guidbrowser:export' => 'Exportera',
	);
					
	add_translation("sv",$swedish);
?>