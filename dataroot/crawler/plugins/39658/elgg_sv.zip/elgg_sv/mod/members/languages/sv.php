<?php

	$swedish = array(
	
		/**
		 * Site info details
		 */
		
		'members:members' => "Webbplatsanvändare",
	    'members:online' => "Användare aktiva nu",
	    'members:active' => "användare",
	    'members:searchtag' => "Sök användare via taggar",
	    'members:searchname' => "Sök användare via namn",
	   
		
	);
					
	add_translation("sv",$swedish);

?>