<?php

$swedish = array (

	/**
	 * Nice name for the entity (shown in admin panel)
	 */
	'item:object:moddefaultwidgets' => 'Inställningar för standardapplikationer',

	/**
	 * Menu items
	 */
	'defaultwidgets:menu:profile' => 'Standardapplikationer för profilsida',
	'defaultwidgets:menu:dashboard' => 'Standardapplikationer för översikten',

	'defaultwidgets:admin:error' => 'Fel: Du är inte inloggad som en administratör',
	'defaultwidgets:admin:notfound' => 'Fel: Sidan hittades inte',
	'defaultwidgets:admin:loginfailure' => 'Varning: Du är inte inloggad som en administratör',

	'defaultwidgets:update:success' => 'Dina applikationsinställningar har sparats',
	'defaultwidgets:update:failed' => 'Fel: inställningar har inte sparats',
	'defaultwidgets:update:noparams' => 'Fel: felaktiga formulärparametrar',

	'defaultwidgets:profile:title' => 'Ställ in standardapplikationer för nya användares profilsidor',
	'defaultwidgets:dashboard:title' => 'Ställ in standardapplikationer för nya användares översiktsidor',
);

add_translation ( "sv", $swedish );
