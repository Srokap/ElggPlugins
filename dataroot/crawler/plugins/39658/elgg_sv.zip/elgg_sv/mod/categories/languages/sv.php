<?php

	$swedish = array(
	
		'categories' => 'Kategorier',
		'categories:settings' => 'Ställ in webbplatskategorier',	
		'categories:explanation' => 'För att ställa in några globala kategorier som kan användas genom hela webbplatsen, ange dem nedan, separerade med kommatecken. Verktyg som stödjer detta kommer då att visa dem när en användare skapar eller redigerar innehåll.',	
		'categories:save:success' => 'Webbplatskategorier är nu sparade.',
	
	);
					
	add_translation("sv",$swedish);

?>