<?php

	$swedish = array(

		'form:formtrans:kevcontent:title' => "Ett formulär utanför profilsidan",
		'form:formtrans:kevcontent:description' => "Detta testar ett formulär utanför profilsidan, t ex annonser.",
		'form:formtrans:kevcontent:response_text' => "Tack för att du bidrar med detta innehåll!",
		'form:fieldtrans:kevput2:title' => "Favoritsäsong",
		'form:fieldtrans:kevput2:description' => "Vad tycker du?",
		'form:fieldtrans:bio:title' => "Om mig",
		'form:fieldtrans:bio:description' => "Berätta för alla lite grand om dig själv",
		'form:fieldtrans:pic:title' => "En bild",
		'form:fieldtrans:pic:description' => "Ladda upp en bild",
		'form:fieldtrans:kevcal:title' => "Kalender",
		'form:fieldtrans:kevcal:description' => "Välj ett datum",
		'form:sdtrans:kevcontent:classified_search_general:title' => "Sök annonser",
		'form:sdtrans:kevcontent:classified_search_general:description' => "Ange dina sökord nedan.",
		'form:sdtrans:kevcontent:testsearch1:title' => "Test-sökning",
		'form:sdtrans:kevcontent:testsearch1:description' => "Detta är bara ett sätt att se till att sökningen fungerar.",
		'form:sdtrans:kevcontent:search1:title' => "Profilsökningstest",
		'form:sdtrans:kevcontent:search1:description' => "Skriv in värden i fälten nedan för att hitta personer på denna webbplats. Om du inte anger ett värde för ett visst fält kommer sökningen inkludera personer med valfritt värde i detta fält.",
		'form:tabtrans:Basic' => "Grundläggande",
	);
					
	add_translation("sv",$swedish);
?>