<?php

	$swedish = array(
	
		/**
		 * Friends widget
		 */
			'friends:widget:description' => "Visar några av dina vänner.",
	        
		
	);
					
	add_translation("sv",$swedish);

?>