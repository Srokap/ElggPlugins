<?php

	$swedish = array(

		'mine' => 'Mina',
		'filter' => 'Filter',
		'riverdashboard:useasdashboard' => "Ersätt standardöversikten med detta aktivitetsflöde?",
		'activity' => 'Activity',
	
	    /**
	     * Site messages
           **/

		'sitemessages:announcements' => "Webbplatsmeddelanden",
		'sitemessages:posted' => "Publicerad",
		'sitemessages:river:created' => "Webbplatsadministratören, %s,",
		'sitemessages:river:create' => "publicerade ett nytt webbplatsmeddelande",
		'sitemessages:add' => "Lägg till ett webbplatsmeddelande till aktivitetsflödesidan",
		'sitemessage:deleted' => "Webbplatsmeddelandet togs bort",
		
		'river:widget:noactivity' => 'Vi kunde inte se någon aktivitet.',
		'river:widget:title' => "Aktivitet",
		'river:widget:description' => "Visa din senaste aktivitet.",
		'river:widget:title:friends' => "Vänners aktivitet",
		'river:widget:description:friends' => "Visa vad dinna vänner sysselsätter sig med.",
		'river:widgets:friends' => "Vänner",
		'river:widgets:mine' => "Mina",
		'river:widget:label:displaynum' => "Antal objekt som ska visas:",
		'river:widget:type' => "Vilket aktivitetsflöde vill du visa? En som visar din aktivitet eller en som visar dina vänners aktivitet?",
		'item:object:sitemessage' => "Webbplatsmeddelanden",
	);
					
	add_translation("sv",$swedish);

?>