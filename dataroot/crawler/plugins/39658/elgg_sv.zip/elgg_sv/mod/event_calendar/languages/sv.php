<?php

	$swedish = array(
	
	'item:object:event_calendar' => "Aktivitetskalender",
	'event_calendar:new_event' => "Ny händelse",
	'event_calendar:no_such_event_edit_error' => "Fel: Det finns ingen sådan händelse eller så har du inte behörighet att redigera den.",
	'event_calendar:add_event_title' => "Lägg till händelse",
	'event_calendar:manage_event_title' => "Redigera händelse",
	'event_calendar:manage_event_description' => "Beskriv din händelse nedan. "
		."Rubrik, plats och startdatum är obligatoriskt. "
		."Du kan använda kalenderikonerna för att ange start- och slutdatum.",
	'event_calendar:title_label' => "Rubrik",
	'event_calendar:title_description' => "Obligatoriskt. Ett till fyra ord",
	'event_calendar:brief_description_label' => "Kort beskrivning",
	'event_calendar:brief_description_description' => "Valfritt. En kort mening.",
	'event_calendar:venue_label' => "Plats",
	'event_calendar:venue_description' => "Obligatoriskt. Var kommer denna denna händelse äga rum?",
	'event_calendar:start_date_label' => "Startdatum",
	'event_calendar:start_date_description'	=> "Obligatoriskt. När kommer denna händelse börja?",
	'event_calendar:end_date_label' => "Slutdatum",
	'event_calendar:end_date_description'	=> "Valfritt. När kommer denna händelse sluta? Startdatumet kommer att "
		."användas som slutdatum om inget annat anges här.",
	'event_calendar:fees_label' => "Avgifter",
	'event_calendar:fees_description'	=> "Valfritt. Kostnaden för att delta på denna händelse, om någon sådan finns.",
	'event_calendar:contact_label' => "Kontakt",
	'event_calendar:contact_description'	=> "Valfritt. Kontaktpersonen om mer information önskas, "
			."förslagsvis med ett telefonnummer eller e-postadress.",
	'event_calendar:organiser_label' => "Arrangör",
	'event_calendar:organiser_description'	=> "Valfritt. Individen eller organisationen som ansvarar för denna händelse.",
	'event_calendar:event_tags_label' => "Taggar",
	'event_calendar:event_tags_description'	=> "Valfritt. En komma-separerar lista med taggar relevanta för denna händelse.",
	'event_calendar:long_description_label' => "Lång beskrivning",
	'event_calendar:long_description_description'	=> "Valfritt. Kan vara ett stycke eller mer om så behövs.",
	'event_calendar:manage_event_response' => "Din händelse har sparats.",
	'event_calendar:add_event_response' => "Din händelse har lagts till.",
	'event_calendar:manage_event_error' => "Fel: Ett fel inträffade när din händelse skulle sparas. "
			."Var god se till att du har fyllt i alla obligatoriska fält.",
	'event_calendar:show_events_title' => "Aktivitetskalender",
	'event_calendar:day_label' => "Dag",
	'event_calendar:week_label' => "Vecka",
	'event_calendar:month_label' => "Månad",
	'event_calendar:group' => "Gruppkalender",
	'event_calendar:new' => "Lägg till händelse",
	'event_calendar:submit' => "Skicka",
	'event_calendar:cancel' => "Avbryt",
	'event_calendar:widget_title' => "Aktivitetskalender",
	'event_calendar:widget:description' => "Visar dina händelser.",
	'event_calendar:num_display' => "Antal händelser som ska visas",
	'event_calendar:groupprofile' => "Kommande händelser",
	'event_calendar:view_calendar' => "visa kalender",
	'event_calendar:when_label' => "När",
	'event_calendar:site_wide_link' => "Visa alla händelser",
	'event_calendar:view_link' => "Visa denna händelse",
	'event_calendar:edit_link' => "Redigera denna händelse",
	'event_calendar:delete_link' => "Ta bort denna händelse",
	'event_calendar:delete_confirm_title' => "Bekräfta borttagning av händelse",
	'event_calendar:delete_confirm_description' => "Är du säker på att du vill ta bort denna händelse (\"%s\")? Detta går inte att ångra!",
	'event_calendar:delete_response' => "Denna händelse har nu tagits bort.",
	'event_calendar:error_delete' => "Denna händelse finns inte eller så har du inte behörighet att ta bort den.",
	'event_calendar:delete_cancel_response' => "Borttagning av händelse avbröts.",
	'event_calendar:add_to_my_calendar' => "Lägg i min kalender",
	'event_calendar:remove_from_my_calendar' => "Ta bort från min kalender",
	'event_calendar:add_to_my_calendar_response' => "Denna händelse har lagts till i din kalender.",
	'event_calendar:remove_from_my_calendar_response' => "Denna händelse har tagits bort från din kalender.",
	'event_calendar:users_for_event_title' => "Personer intresserade av händelsen \"%s\"'",
	'event_calendar:personal_event_calendars_link' => "Personliga kalendrar (%s)",
	'event_calendar:settings:group_profile_display:title' => "Visa gruppkalender på profilsidan (om gruppkalendrar är aktiverade)",
	'event_calendar:settings:group_profile_display_option:left' => "till vänster",
	'event_calendar:settings:group_profile_display_option:right' => "till höger",
	'event_calendar:settings:group_profile_display_option:none' => "inte alls",
	'event_calendar:settings:autopersonal:title' => "Lägg automatiskt till händelser som en användare skapar i sin egen kalender.",
	'event_calendar:settings:yes' => "ja",
	'event_calendar:settings:no' => "nej",
	'event_calendar:settings:site_calendar:title' => "Webbplatskalender",
	'event_calendar:settings:site_calendar:admin' => "ja, bara administratörer kan publicera händelser",
	'event_calendar:settings:site_calendar:loggedin' => "ja, alla inloggade användare kan publicera en händelse",	
	'event_calendar:settings:group_calendar:title' => "Gruppkalendrar",
	'event_calendar:settings:group_calendar:admin' => "ja, bara administratörer och gruppägare kan publicera händelser",
	'event_calendar:settings:group_calendar:members' => "ja, alla gruppmedlemmar kan publicera en händelse",
	'event_calendar:settings:group_default:title' => "Nya grupper ska få en gruppkalender som standard (om gruppkalendrar är aktiverade)",
	'event_calendar:settings:group_default:no' => "nej (men administratörer eller gruppägare kan aktivera en gruppkalender om så önskas)",
	'event_calendar:settings:group_default:yes' => "ja (men administratörer eller gruppägare kan ta bort en gruppkalender om så önskas)",
	'event_calendar:enable_event_calendar' => "Tillåt gruppkalendrar",
	'event_calendar:no_events_found' => "Inga händelser hittades.",
			
	/**
	 * Event kalender river
	 **/
			 
	//generic terms to use
    'event_calendar:river:created' => "%s lades till",
    'event_calendar:river:updated' => "%s uppdaterade",
    'event_calendar:river:annotated1' => "%s lade till",
	'event_calendar:river:annotated2' => "i sin kalender.",
	 
	//these get inserted into the river links to take the user to the entity
    'event_calendar:river:create' => "en ny händelse kallad",
    'event_calendar:river:the_event' => "en händelse kallad",
	);
					
	add_translation("sv",$swedish);

?>