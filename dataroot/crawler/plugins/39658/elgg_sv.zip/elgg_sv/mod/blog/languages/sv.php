<?php

	$swedish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'blog' => "Blogg",
			'blogs' => "Bloggar",
			'blog:user' => "%ss blogg",
			'blog:user:friends' => "%ss vänners blogg",
			'blog:your' => "Min blogg",
			'blog:posttitle' => "%ss blogg: %s",
			'blog:friends' => "Vänners bloggar",
			'blog:yourfriends' => "Mina vänners senaste blogginlägg",
			'blog:everyone' => "Alla blogginlägg",
			'blog:newpost' => "Nytt blogginlägg",
			'blog:via' => "via blogg",
			'blog:read' => "Läs blogg",
	
			'blog:addpost' => "Skriv ett blogginlägg",
			'blog:editpost' => "Redigera blogginlägg",
	
			'blog:text' => "Bloggtext",
	
			'blog:strapline' => "%s",
			
			'item:object:blog' => 'Blogginlägg',
	
			'blog:never' => 'aldrig',
			'blog:preview' => 'Förhandsgranska',
	
			'blog:draft:save' => 'Spara utkast',
			'blog:draft:saved' => 'Utkast senast sparat',
			'blog:comments:allow' => 'Tillåt bloggkommentarer',
	
			'blog:preview:description' => 'Detta är en osparad förhandsgranskning av ditt blogginlägg.',
			'blog:preview:description:link' => 'Fortsätt redigera eller att spara ditt inlägg.',
	
			
         /**
	     * Blog river
	     **/
	        
	        //generic terms to use
	        'blog:river:created' => "%s skrev",
	        'blog:river:updated' => "%s uppdaterade",
	        'blog:river:posted' => "%s publicerade",
	        
	        //these get inserted into the river links to take the user to the entity
	        'blog:river:create' => "ett nytt blogginlägg kallat",
	        'blog:river:update' => "ett blogginlägg kallat",
	        'blog:river:annotate' => "en kommentar på detta blogginlägg",
			
	
		/**
		 * Status messages
		 */
	
			'blog:posted' => "Ditt blogginlägg har nu publicerats.",
			'blog:deleted' => "Ditt blogginlägg är nu borttaget.",
	
		/**
		 * Error messages
		 */
	
			'blog:error' => 'Något gick snett. Var god försök igen.',
			'blog:save:failure' => "Ditt blogginlägg kunde inte sparas. Var god försök igen.",
			'blog:blank' => "Ledsen, du måste fylla i både rubrik och text innan du kan publicera ett blogginlägg.",
			'blog:notfound' => "Ledsen, vi kunde hitta blogginlägget du sökte.",
			'blog:notdeleted' => "Ledsen, vi kunde inte ta bort detta blogginlägg.",
	
	);
					
	add_translation("sv",$swedish);

?>