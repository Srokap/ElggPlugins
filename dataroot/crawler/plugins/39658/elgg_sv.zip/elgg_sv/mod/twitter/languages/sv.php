<?php

	$swedish = array(
	
		/**
		 * twitter widget details
		 */
		
	
		'twitter:username' => 'Ange ditt Twitter-användarnamn.',
		'twitter:num' => 'Antal tweets som ska visas.',
		'twitter:visit' => 'gå till min sida på Twitter',
		'twitter:notset' => 'Denna Twitter-applikation är inte redo att användas. För att visa dina senaste tweets, välj Redigera och fyll i dina uppgifter',
		
		
		 /**
	     * twitter widget river
	     **/
	        
	        //generic terms to use
	        'twitter:river:created' => "%s lade till Twitter-applikationen.",
	        'twitter:river:updated' => "%s uppdaterade sin Twitter-applikation.",
	        'twitter:river:delete' => "%s tog bort sin Twitter-applikation.",
	        
		
	);
					
	add_translation("sv",$swedish);

?>