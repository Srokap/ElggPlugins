<?php

	$swedish = array(
	
		/**
		 * Manifest
		 */
		
	
		'river:widget:noactivity' => 'Vi kunder inte se någon aktivitet.',
		'river:widget:title' => "Aktivitet",
		'river:widget:description' => "Visa din senaste aktivitet.",
		'river:widget:title:friends' => "Vänners aktivitet",
		'river:widget:description:friends' => "Visa vad dina vänner sysselsätter sig med.",
	
		'river:widget:label:displaynum' => "Antal händelser som ska visas:",
	);
					
	add_translation("sv",$swedish);

?>