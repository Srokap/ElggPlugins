<?php

	$swedish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'status' => "Status",
			'status:user' => "%ss status",
			'status:current'=> "Nuvarande status",
			'status:desc'=> "Denna applikation visar din senast angivna status.",
			'status:posttitle' => "%ss status: %s",
			'status:everyone' => "Alla användares status",
			'status:strapline' => "%s",
			'status:addstatus' => "Ange din nuvarande status",
		    'status:messages' => "Status-meddelanden",
			'status:text' => "Status:",
			'status:set' => "ange ",
			'status:clear' => "töm status",
			'status:delete' => "ta bort status",
			'status:nostatus' => "Ingen status har angetts.",
			'status:viewhistory' => "se historik",
	
			'item:object:status' => 'Status-meddelanden',
	
	
        /**
	     * Status river
	     **/
	        
	        //generic terms to use
	        'status:river:created' => "%s uppdaterade",
	        
	        //these get inserted into the river links to take the user to the entity
	        'status:river:create' => "sin status.",
	        
	        
	
		/**
		 * Status messages
		 */
	
			'status:posted' => "Din nya status är nu publicerad.",
			'status:deleted' => "Din status är nu borttagen.",
	
		/**
		 * Error messages
		 */
	
			'status:blank' => "Ledsen, du måste skriva ett status-meddelande innan vi kan spara något.",
			'status:notfound' => "Ledsen, vi kunde inte hitta status-meddelandet du sökte.",
			'status:notdeleted' => "Ledsen, vi kunde inte ta bort detta status-meddelande.",
			'status:notsaved' => "Något gick fel när vi skulle spara, var god försök igen eller kontakta adminstratören.",
			'status:problem' => "Ett fel inträffade. Det verkar som att du inte kan redigera detta status-meddelande.",
	
	);
					
	add_translation("sv",$swedish);

?>