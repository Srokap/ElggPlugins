<?php
	$swedish = array(
		'twitterservice' => 'Twitter-webbtjänst',
		'twitterservice:postwire' => 'Vill du publicera dina publika meddelanden från Löpsedeln till Twitter?',
		'twitterservice:twittername' => 'Twitter-användarnamn',
		'twitterservice:twitterpass' => 'Twitter-lösenord',
	);
					
	add_translation("sv",$swedish);
?>