<?php
	/**
	 * API Admin language pack.
	 * 
	 * @package ElggAPIAdmin
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */


	$swedish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'apiadmin' => 'API-administration',
	
	
			'apiadmin:keyrevoked' => 'API-nyckel tillbakadragen',
			'apiadmin:keynotrevoked' => 'API-nyckel kunde inte dras tillbaka',
			'apiadmin:generated' => 'API-nyckel är nu genererad',
	
			'apiadmin:yourref' => 'Din referens',
			'apiadmin:generate' => 'Generera ett nytt nyckelpar',
	
			'apiadmin:noreference' => 'Du måste tillhandahålla en referens för din nya nyckel.',
			'apiadmin:generationfail' => 'Ett fel inträffade när det nya nyckelparet skulle genereras',
			'apiadmin:generated' => 'Nytt API-nyckelpar är nu genererat',
	
			'apiadmin:revoke' => 'Dra tillbaka nyckel',
			'apiadmin:public' => 'Publik',
			'apiadmin:private' => 'Privat',

	
			'item:object:api_key' => 'API-nycklar',
	);
					
	add_translation("sv",$swedish);
?>