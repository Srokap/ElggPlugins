<?php

	$swedish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'thewire' => "Löpsedelns",
			'thewire:user' => "%ss löpsedel",
			'thewire:posttitle' => "%s noteringar på löpsedeln: %s",
			'thewire:everyone' => "Alla löpsedelsnoteringar",
	
			'thewire:read' => "Löpsedelsnoteringar",
			
			'thewire:strapline' => "%s",
	
			'thewire:add' => "Publicera på löpsedeln",
		    'thewire:text' => "En notering på löpsedeln",
			'thewire:reply' => "Besvara",
			'thewire:via' => "via",
			'thewire:wired' => "Publicerat på löpsedeln",
			'thewire:charleft' => "tecken kvar",
			'item:object:thewire' => "Löpsedelsnoteringar",
			'thewire:notedeleted' => "notering borttagen",
			'thewire:doing' => "Vad funderar du på just nu? Berätta för alla på löpsedeln:",
			'thewire:newpost' => 'Ny löpsedelsnotering',
			'thewire:addpost' => 'Publicera på löpsedeln',

	
        /**
	     * The wire river
	     **/
	        
	        //generic terms to use
	        'thewire:river:created' => "%s publicerade",
	        
	        //these get inserted into the river links to take the user to the entity
	        'thewire:river:create' => "på löpsedeln.",
	        
	    /**
	     * Wire widget
	     **/
	     
	        'thewire:sitedesc' => 'Denna applikation visar de senaste webbplatsnoteringarna som publicerats på löpsedeln',
	        'thewire:yourdesc' => 'Denna applikation visar dina senaste noteringar som publicerats på löpsedeln',
	        'thewire:friendsdesc' => 'Denna applikation visa de senaste löpsedelsnoteringarna från dina vänner',
	        'thewire:friends' => 'Dina vänner på löpsedeln',
	        'thewire:num' => 'Antal som ska visas',
	        
	        
	
		/**
		 * Status messages
		 */
	
			'thewire:posted' => "Din notering har nu publicerats på löpsedeln.",
			'thewire:deleted' => "Din notering har nu tagits bort.",
	
		/**
		 * Error messages
		 */
	
			'thewire:blank' => "Ledsen, du måste skriva något i noteringens textruta innan vi kan spara den.",
			'thewire:notfound' => "Ledsen, vi kunde inte hitta noteringen du sökte.",
			'thewire:notdeleted' => "Ledsen, vi kunde inte ta bort denna notering.",
	
	
		/**
		 * Settings
		 */
			'thewire:smsnumber' => "Ditt SMS-nummer skiljer sig från ditt mobilnummer (mobilnumret måste anges som publikt för att löpsedeln ska kunna använda det). Alla telefonnummer måste skrivas i internationellt format.",
			'thewire:channelsms' => "Numret som SMS-meddelanden ska skickas till är <b>%s</b>",
			
	);
					
	add_translation("sv",$swedish);

?>