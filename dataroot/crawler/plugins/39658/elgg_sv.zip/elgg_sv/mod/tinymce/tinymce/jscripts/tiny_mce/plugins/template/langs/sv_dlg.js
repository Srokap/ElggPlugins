tinyMCE.addI18n('sv.template_dlg',{
title:"Mallar",
label:"Mall",
desc_label:"Beskrivning",
desc:"Infoga en f\u00E4rdig mall",
select:"V\u00E4lj en mall",
preview:"F\u00F6rhandsgranska",
warning:"Varning: Uppdaterar en mall med en ny kan inneb\u00E4ra att data f\u00F6rsvinner.",
mdate_format:"%Y-%m-%d %H:%M:%S",
cdate_format:"%Y-%m-%d %H:%M:%S",
months_long:"Januari,Februari,Mars,April,Maj,Juni,Juli,Augusti,September,Oktober,November,December",
months_short:"Jan,Feb,Mar,Apr,Maj,Jun,Jul,Aug,Sep,Okt,Nov,Dec",
day_long:"S\u00F6ndag,M\u00E5ndag,Tisdag,Onsdag,Torsdag,Fredag,L\u00F6rdag,S\u00F6ndag",
day_short:"S\u00F6n,M\u00E5n,Tis,Ons,Tors,Fre,L\u00F6r,S\u00F6n"
});