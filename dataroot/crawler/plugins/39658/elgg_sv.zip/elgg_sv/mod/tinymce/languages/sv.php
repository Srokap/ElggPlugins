<?php

	$swedish = array(
	
		/**
		 * Menu items and titles
		 */
	
		'tinymce:remove' => "Visa/Göm editor",
	
	);
					
	add_translation("sv",$swedish);

?>