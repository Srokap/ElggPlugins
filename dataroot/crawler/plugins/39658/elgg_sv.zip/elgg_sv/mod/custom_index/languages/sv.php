<?php

	$swedish = array(
	
			'custom:bookmarks' => "Senaste bokmärkena",
			'custom:groups' => "Senaste grupperna",
			'custom:files' => "Senaste filerna",
			'custom:blogs' => "Senaste blogginläggen",
			'custom:members' => "Nya användare",
			'custom:nofiles' => "Det finns inga filer ännu",
			'custom:nogroups' => "Det finns inga grupper ännu",	
	
	);
					
	add_translation("sv",$swedish);

?>