<?php

	$swedish = array(
	
		'media:insert' => 'Infoga/ladda upp media',
	
		'embed:instructions' => 'Välj valfri fil för att infoga den tillsammans med din text.',
	
		'embed:media' => 'Infoga media',
		'upload:media' => 'Ladda upp media',
	
		'embed:file:required' => 'Ingen filuppladdningsmöjlighet hittades. Administratören kan behöva ladda upp filpluginen eller motsvarande.',
	
	);
					
	add_translation("sv",$swedish);

?>