.anypage-message.elgg-message {
	cursor: auto;
}