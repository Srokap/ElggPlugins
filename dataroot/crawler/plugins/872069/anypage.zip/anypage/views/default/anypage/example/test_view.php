<?php
/**
 * Test page example view
 */

echo '<h2>' . elgg_echo('anypage:test_page_view') . '</h2>';