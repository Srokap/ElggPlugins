<?php
/**
 * Added to give make the settings link next to the plugin name.
 * Just forwards to the real settings.
 */

forward('admin/appearance/anypage');