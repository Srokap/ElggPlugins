<?php
/**
 * Elgg profile plugin language pack
 *
 * @version 1.8.3
 * @update 2012-1-30
 */

$japanese = array(
	'profile' => 'プロフィール',
	'profile:notfound' => '申し訳ありません、お探しのプロフィールを見つけることができませんでした。',

);

add_translation('ja', $japanese);
