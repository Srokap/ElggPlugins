<?php
/**
 * Twitter widget language file
 *
 * @version 1.8.3
 * @update 2012-1-31
 */

$japanese = array(
	'twitter:title' => 'Twitter',
	'twitter:info' => '最新のtweetsを表示',
	'twitter:username' => 'あなたのtwitterのユーザ名を入力してください。',
	'twitter:num' => '一度に表示するtweetsの数',
	'twitter:visit' => '私のtwitterを見にいく',
	'twitter:notset' => 'この Twitter ウィジェットはまだセッティングされていません。最新のtweetsをを表示させるには、「編集」をクリックして詳細を埋めてください。',
);
					
add_translation("ja",$japanese);
