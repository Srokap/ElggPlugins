<?php
/**
 * Tag cloud 日本語 language file
 *
 * @version 1.8.3
 * @update 2012-1-31
 */

$japanese = array(
	'tagcloud:widget:title' => 'タグクラウド',
	'tagcloud:widget:description' => 'タグクラウド',
	'tagcloud:widget:numtags' => 'タグの表示数',
);

add_translation('ja', $japanese);
