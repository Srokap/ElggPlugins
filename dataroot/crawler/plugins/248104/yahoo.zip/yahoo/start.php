<?php
  function yahoo_init() {        
    add_widget_type('yahoo', 'yahoo', 'Yahoo.com');
  }
 
  register_elgg_event_handler('init','system','yahoo_init');       
?>