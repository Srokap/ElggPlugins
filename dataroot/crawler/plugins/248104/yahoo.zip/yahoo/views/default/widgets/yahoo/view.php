<?php
     $id = $vars['entity']->id;
     $pingbox = $vars['entity']->pingbox;
	 $width = $vars['entity']->width;
	 
	 if($pingbox){
		 print 
	 
	 "<style type=\"text/css\">
      #images img { 
          border:none;
      }
	  .clear {
		  clear:both;
	  }
</style>


<div align=\"center\">
	 <object id=\"pingboxj94abzogpvo00\" type=\"application/x-shockwave-flash\" data=\"http://wgweb.msg.yahoo.com/badge/Pingbox.swf\" width=\"$width\" height=\"320\"  ><param name=\"movie\" value=\"http://wgweb.msg.yahoo.com/badge/Pingbox.swf\" /> <param name=\"allowScriptAccess\" value=\"always\" /> <param name=\"wmode\" value=\"transparent\" /> <param name=\"flashvars\" value=\"$pingbox\" /> <param name=\"src\" value=\"http://wgweb.msg.yahoo.com/badge/Pingbox.swf\" /> </object>
	 </div>";
	 ?>
     <?php 
 

    }else{
        
        echo "Click <a href=\"http://messenger.yahoo.com/pingbox/\" target=\"_blank\">HERE</a> to get a yahoo messenger pingbox";
        
    }
?>