<?PHP

	/**
	 * Group Contact List - Plugin
	 * 
	 * @package Group Contact List
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Tomas Feltl
	 * @author for security protocol update Simone Aiken
	 * @copyright TFSoft 2008
	 * @link http://www.QuietlyCompetent.com
	 */

function group_contact_list_init()
{
	register_page_handler('group_contact_list','group_contact_list_page_handler');
	extend_view('css','grouplist/css');
	
	// Extend context menu with Group Manager link
	register_page_handler( 'group_contact_list_user_manager', 'group_contact_list_user_manager' );
	if ( isadminloggedin() )
	{
		 elgg_extend_view( 'profile/menu/adminlinks', 'grouplist/profileLink', 10000 );
	}
}

function group_contact_list_pagesetup()
{
	if (get_context() == 'admin' && isadminloggedin()) 
	{
		global $CONFIG;
		add_submenu_item(elgg_echo('groupclist:title'), $CONFIG->wwwroot . 'pg/group_contact_list/');
	}
}

function group_contact_list_user_manager( $page )
{
	global $CONFIG;
	
	if( isset( $page[1] ) ) 
		set_input( 'guid', $page[1] );
		
	include( $CONFIG->pluginspath . "group_contact_list/userIndex.php" ); 
}

function group_contact_list_page_handler($page) 
{
	global $CONFIG;
	if(isset($page[1])) //this allows pagination
		set_input('page', $page[1]);
	include($CONFIG->pluginspath . "group_contact_list/index.php"); 
}

register_elgg_event_handler('init','system','group_contact_list_init');
register_elgg_event_handler('pagesetup','system','group_contact_list_pagesetup');

register_action('group_contact_list/deletegroup',false,$CONFIG->pluginspath."group_contact_list/actions/admin/group/deletegroup.php");
register_action('group_contact_list/modusergroup',false,$CONFIG->pluginspath."group_contact_list/actions/admin/group/modusergroup.php");
register_action('group_contact_list/modUsersGroups',false,$CONFIG->pluginspath."group_contact_list/actions/admin/group/modUsersGroups.php");

?>