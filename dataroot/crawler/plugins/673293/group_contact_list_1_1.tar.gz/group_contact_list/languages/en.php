<?php
	/**
	 * Group Contact List - Plugin
	 * 
	 * @package Group Contact List
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Tomas Feltl
	 * @copyright TFSoft 2008
	 * @link http://www.tfsoft.cz/
	 */

$english = array(
		'groupclist:title' => 'Group Manager',
		'groupclist:title_users' => 'Manage Group Membership',
		'groupclist:lastpage' => '<< Last Page',
		'groupclist:nextpage' => 'Next Page >>',
		'groupclist:totalpages' => 'Total Groups: %d',
		'groupclist:displayingpages' => 'Displaying page %d of %d total pages.',
		'groupclist:delete:yes' => 'Group %s deleted.',
		'groupclist:delete:no' => 'Error: Group %s not deleted',
		'groupclist:manage:title' => 'Add and remove members for group ',
		'groupclist:addmember:yes' => 'Group modified',
		'groupclist:addmember:no' => 'Error modifying group',

		'groupclist:tableheader:group' => 'Group Name',
		'groupclist:tableheader:members' => 'Members',

		'groupclist:delete:confirm' => 'Are you sure?  Deletion is permanent.',
		
		'groupclist:userProfile:prompt' => 'Manage Groups',
		'groupclist:userProfile:title' => 'Manage Groups for %s',
		'groupclist:userProfile:manage:title' => 'Add and Remove User From Groups.',
		
		'groupclist:userProfile:edit:yes' => 'User modified',
		'groupclist:userProfile:edit:no' => 'Error modifying user',

		);

add_translation("en",$english);
?>