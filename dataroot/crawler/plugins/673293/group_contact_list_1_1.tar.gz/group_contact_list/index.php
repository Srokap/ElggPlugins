<?php

	/**
	 * Group Contact List - Plugin
	 * 
	 * @package Group Contact List
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Tomas Feltl
	 * @copyright TFSoft 2008
	 * @link http://www.tfsoft.cz/
	 */

require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

admin_gatekeeper();
set_context('admin');

$select_users = get_input('slct');

if ($select_users == 1) {
    $title = elgg_view_title(elgg_echo('groupclist:title_users'));
    $body = elgg_view('grouplist/addusers');
    page_draw(elgg_echo('group'),elgg_view_layout("two_column_left_sidebar", '', $title . $body));
} else {
    $title = elgg_view_title(elgg_echo('groupclist:title'));
    $body = elgg_view('grouplist/grouplist');
    page_draw(elgg_echo('group'),elgg_view_layout("two_column_left_sidebar", '', $title . $body));
}
?>