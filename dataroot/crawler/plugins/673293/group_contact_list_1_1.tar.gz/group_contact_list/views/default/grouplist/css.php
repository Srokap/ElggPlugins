<?php

	/**
	 * Group Contact List - Plugin
	 * 
	 * @package Group Contact List
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Tomas Feltl and Simone Aiken
	 * @copyright Quietly Competent Consulting 2010
	 * @link http://www.QuietlyCompetent.com
	 */
?>

.gv_navigation
{
	padding-top: 15px;
	padding-bottom: 15px;
	margin-left: auto;
	margin-right: auto;
	width: 655px;
	font-size: .7em;
	
	display: block;
}

.gv_list 
{
	margin-top: 15px;;
	margin-bottom: 10px;
	margin-left: auto;
	margin-right: auto;
	
  	border: 1px solid #333333;
	border-collapse: collapse;
	width: 655px;
}

.gv_list th
{
	border: 1px solid #333333;
	border-collapse: collapse;
	padding: 3px; 
	
	text-align: center;
	color: #ffffff;
	background-color: #000000;
	font-weight: bold;
}

.gv_list td, .gv_list tr 
{
  border: 1px solid #333333;
  border-collapse: collapse;
  padding: 3px; 
  vertical-align: middle;
}

#groupclist-grid label
{
	margin-left: 150px;
}

#gvNewGroup
{
	float: right;
	margin-right: 20px;
	margin-top: 5px;
}