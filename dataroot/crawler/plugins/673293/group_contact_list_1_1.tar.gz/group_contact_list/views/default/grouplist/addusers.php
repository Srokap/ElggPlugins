<?PHP

	/**
	 * Group Contact List - Plugin
	 * 
	 * @package Group Contact List
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Tomas Feltl and Simone Aiken
	 * @copyright Quietly Competent Consulting
	 * @link http://www.QuietlyCompetent.com/
	 */

	global $CONFIG;
	admin_gatekeeper();

	$ts = time();
	$token = generate_action_token( $ts );
	
	//
	// Get the Group 
	//
	
	$guid = get_input( 'guid' );
	$obj = get_entity( $guid );
	$g_owner = get_entity( $obj->guid )->owner_guid;
	
	if ( ( $obj instanceof ElggGroup ) && ( $obj->canEdit() ) ) 
	{
		$query = "SELECT guid, name, username FROM {$CONFIG->dbprefix}users_entity ORDER BY username"; 
		$result = get_data( $query );
		  
		$nameLink = "<a href=\"{$CONFIG->wwwroot}pg/groups/{$obj->guid}\">".$obj->name."</a>";
		
		$form_body = "<div class='contentWrapper'>\n";
		$form_body .= elgg_echo( 'groupclist:manage:title') . $nameLink . "<br /><br />\n";
		  	 
		foreach ( $result as $e_user )
		{
			// Is user a group member?
			$checked_start = 0;
			
			if ( is_group_member( $obj->guid, $e_user->guid ) )
			{
				$checked_start = 1;
			}
			
			// List everyone except the owner:
			
			if ( $g_owner != $e_user->guid )
			{
				$options[ $e_user->name ] = $e_user->guid;
				
				if ( $checked_start == 1 )
				{
					$values[] = $e_user->guid;
				}
				
				$form_body .= elgg_view( 'input/hidden', array( 'internalname' => 'cuid[' . $checked_start .  '][]', 'value' => $e_user->guid ) ) . "\n";
			}	
		}

		if ( $options )
		{
			$form_body .= elgg_view('input/checkboxes', array ( 'internalname' => 'uid', 'options' => $options, 'value' => $values ) );
		}

		$form_body .= elgg_view( 'input/hidden', array( 'internalname' => 'guid', 'value' => $obj->guid ) );
		$form_body .= elgg_view( 'input/hidden', array( 'internalname' => '__elgg_token', 'value' => $token ) );
		$form_body .= elgg_view( 'input/hidden', array( 'internalname' => '__elgg_ts', 'value' => $ts ) );
		$form_body .= elgg_view( 'input/submit', array( 'internalname' => 'submit', 'value' => 'Submit' ) );
		
		$form_body .= "</div>";
			
		echo elgg_view( 
			'input/form', 
			array( 'body' => $form_body, 'action' => "{$CONFIG->url}action/group_contact_list/modusergroup", 'internalid' => 'groupclist-grid' )
		 );
	}
?>