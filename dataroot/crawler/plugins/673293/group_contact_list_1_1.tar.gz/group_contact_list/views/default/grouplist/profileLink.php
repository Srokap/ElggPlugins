<?php

?>

<a href=" <?php echo $vars['url']; ?>pg/group_contact_list_user_manager?user_guid=<?php echo $vars['entity']->guid; ?>" >
	<?php echo elgg_echo( "groupclist:userProfile:prompt" ); ?>
</a>