<?PHP

	/**
	 * Group Contact List - Plugin
	 * 
	 * @package Group Contact List
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Tomas Feltl and Simone Aiken
	 * @copyright Quietly Competent 2010
	 * @link http://www.QuietlyCompetent.com
	 */


	$groups_per_page = 30;
	$ts = time();
	$token = generate_action_token( $ts );
	
	// This variable is not passed initiallly, but shows up if you move through the resultset.
	$page = get_input("page");
	if ( $page == "" )
	{	$page = 1;	}
		
	global $CONFIG;

	admin_gatekeeper();

	$query = "SELECT guid, name FROM {$CONFIG->dbprefix}groups_entity"; 
	$result = get_data($query);
	
	$total_groups = count( $result );
	$total_pages = ceil( floatval( $total_groups ) / floatval( $groups_per_page ) );
	$offset = ( $page-1 ) * $groups_per_page;
	
	
	//
	// Writing the Title Text For the Page.
	//
	
	
	echo "<div class=\"contentWrapper\" >\n";
	
	
	echo "<div id='gvNewGroup'>";
	$createButton = elgg_view( 'input/submit', array( 'internalname' => 'submit', 'value' => elgg_echo('groups:new') ) );
	echo elgg_view('input/form', array( 'body' => $createButton, 'action' => "{$CONFIG->url}pg/groups/new", 'css' => 'ButtonID' ) );
	echo "</div>";
	
	
	echo "<b>" . sprintf( elgg_echo( "groupclist:totalpages" ), $total_groups ) . "</b><br />";
	echo sprintf( elgg_echo( "groupclist:displayingpages" ), $page, $total_pages ) . "<br />";
	

	
	printGroupListNavigation( $page, $total_pages );

	
	//
	//  Writing the display Table for the page.
	//

	
	echo "\t<table class=\"gv_list\">\n";
	
	// Print header Row.
	printGroupListRow( '', elgg_echo( 'groupclist:tableheader:group' ), elgg_echo( 'groupclist:tableheader:members' ), "", 1 );
	
	// Print the group rows.
	for( $i = $offset; $i < $offset + $groups_per_page ; $i++ )
	{
		if ( $i < $total_groups ) 
		{
      		$row = $result[$i];
	
      		$js = "onclick=\"javascript:return confirm('" . elgg_echo( 'groupclist:delete:confirm' ) . "')\"";
      		
			$del = elgg_view( 'input/hidden', array( 'internalname' => 'guid', 'value' => $row->guid ) );
			$del .= elgg_view( 'input/hidden', array( 'internalname' => '__elgg_token', 'value' => $token ) );
			$del .= elgg_view( 'input/hidden', array( 'internalname' => '__elgg_ts', 'value' => $ts ) );
			$del .= elgg_view( 'input/submit', array( 'internalname' => 'submit', 'value' => 'Delete', 'js' => $js ) );
			
			$idValue = elgg_view('input/form', array( 'body' => $del, 'action' => "{$CONFIG->url}action/group_contact_list/deletegroup" ) );
      		$nameValue = "<a href=\"{$CONFIG->wwwroot}pg/groups/{$row->guid}\">".$row->name."</a>";
      		
      		$members = get_group_members($row->guid, $limit = 100, $offset = 0, $site_guid = 0, $count = false);
    		$members_count = count( $members );
    	 	$memberValue = "";
    	 	
			foreach ( $members as $c_member ) 
       		{
         		$memberValue .= " <a href=\"{$CONFIG->wwwroot}pg/profile/{$c_member->username}\">".$c_member->name."</a>,";
         	}	
         	
         	$edit = elgg_view( 'input/hidden', array( 'internalname' => 'guid', 'value' => $row->guid ) );
         	$edit .= elgg_view( 'input/hidden', array( 'internalname' => 'slct', 'value' => "1" ) );
			$edit .= elgg_view( 'input/hidden', array( 'internalname' => '__elgg_token', 'value' => $token ) );
			$edit .= elgg_view( 'input/hidden', array( 'internalname' => '__elgg_ts', 'value' => $ts ) );
			$edit .= elgg_view( 'input/submit', array( 'internalname' => 'submit', 'value' => 'Edit' ) );
			
			$editValue = elgg_view('input/form', array( 'body' => $edit, 'action' => "{$CONFIG->url}pg/group_contact_list" ) );
			
      		printGroupListRow( $idValue, $nameValue, $memberValue, $editValue );
		}
	}

	echo "\t</table>\n";
	
	printGroupListNavigation( $page, $total_pages );
	
	echo "</div>\n";
	
	
	//
	// Local Functions for drawing the table.
	//
	
	function printGroupListRow( $id, $name, $members, $editBtn, $header = 0 )
	{
		$beginTag = "<td>";
		$endTag = "</td>";
		
		if ( $header == 1 )
		{
			$beginTag = "<th>";
			$endTag = "</th>";
		}
		
		echo "\t\t<tr>\n";
		echo "\t\t\t" . $beginTag . "<center> $id </center>" . $endTag . "\n";
		echo "\t\t\t" . $beginTag . " $name " . $endTag . "\n";
		echo "\t\t\t" . $beginTag . " $members " . $endTag . "\n";
		echo "\t\t\t" . $beginTag . " $editBtn " . $endTag . "\n";
		echo "\t\t</tr>\n\n";
	}
	
	function printGroupListNavigation( $currentPage, $pageCount )
	{	
		echo "\n<div class=\"gv_navigation\" >";
		
		echo "\t<div style=\"float:left;\" >";
			if( $currentPage > 1 )
			{
				echo "<a href=\"".$vars['url'] . ($currentPage - 1) . "\">" . elgg_echo("groupclist:lastpage") . "</a>";
			}
		echo "\t</div>";
		
		echo "\t<div style=\"float:right;\" >";
			if( ( $pageCount - $currentPage ) > 0 )
			{	
				echo "<a href=\"".$vars['url'] . ($currentPage + 1) . "\">" . elgg_echo("groupclist:nextpage") . "</a>";
			}
		echo "\t</div>";
		
		echo "</div>";	
	}

?>