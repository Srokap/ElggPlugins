<?PHP

	/**
	 * Group Contact List - Plugin
	 * 
	 * @package Group Contact List
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Tomas Feltl and Simone Aiken
	 * @copyright Quietly Competent Consulting
	 * @link http://www.QuietlyCompetent.com/
	 */

	global $CONFIG;
	admin_gatekeeper();

	$ts = time();
	$token = generate_action_token( $ts );
	
	//
	// Get the Group 
	//
	
	$guid = get_input( 'user_guid' );
	$obj = get_entity( $guid );
	
	
	if ( ( $obj instanceof ElggUser ) && ( $obj->canEdit() ) ) 
	{
		$form_body = "<div class='contentWrapper'>\n";
		$form_body .= elgg_echo( 'groupclist:userProfile:manage:title' ) . "<br /><br />\n";

		$query = "SELECT guid, name FROM {$CONFIG->dbprefix}groups_entity Order By name"; 
		$result = get_data( $query );
	
		foreach ( $result as $e_group )
		{
			// Is user a group member?
			$checked_start = 0;
			
			if ( is_group_member( $e_group->guid, $guid ) )
			{
				$checked_start = 1;
			}
			
			$options[ $e_group->name ] = $e_group->guid;
			
			if ( $checked_start == 1 )
			{
				$values[] = $e_group->guid;
			}
			
			$form_body .= elgg_view( 'input/hidden', array( 'internalname' => 'cuid[' . $checked_start .  '][]', 'value' => $e_group->guid ) ) . "\n";
		}
	
		if ( $options )
		{
			$form_body .= elgg_view('input/checkboxes', array ( 'internalname' => 'uid', 'options' => $options, 'value' => $values ) );
		}

		$form_body .= elgg_view( 'input/hidden', array( 'internalname' => 'guid', 'value' => $guid ) );
		$form_body .= elgg_view( 'input/hidden', array( 'internalname' => '__elgg_token', 'value' => $token ) );
		$form_body .= elgg_view( 'input/hidden', array( 'internalname' => '__elgg_ts', 'value' => $ts ) );
		$form_body .= elgg_view( 'input/submit', array( 'internalname' => 'submit', 'value' => 'Submit' ) );
			
		$form_body .= "</div>";
			
		echo elgg_view(  'input/form', 
			array( 'body' => $form_body, 'action' => "{$CONFIG->url}action/group_contact_list/modUsersGroups", 'internalid' => 'groupclist-grid' )
		 );
	}
?>