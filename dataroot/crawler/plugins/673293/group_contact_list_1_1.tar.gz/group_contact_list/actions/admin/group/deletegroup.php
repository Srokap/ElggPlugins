<?php

	/**
	 * Group Contact List Actions - Plugin
	 * 
	 * @package Group Contact List
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Tomas Feltl and Simone Aiken
	 * @copyright Quietly Competent Consulting 2010
	 * @link http://www.QuietlyCompetent.com
	 */
	 
	require_once(dirname(dirname(dirname(dirname(dirname(dirname(__FILE__)))))) . "/engine/start.php");

	global $CONFIG;
	
	// block non-admin users
	admin_gatekeeper();
	
	// Get the Group 
	$guid = get_input( 'guid' );
	$obj = get_entity( $guid );
	
	if ( ( $obj instanceof ElggGroup ) && ( $obj->canEdit() ) )
	{
    	$result = delete_entity($obj->getGUID()); 		
		
		if ( $result )
		{	
			system_message( sprintf( elgg_echo( 'groupclist:delete:yes' ), $obj->name ) );
		}
		else
		{
			register_error( sprintf( elgg_echo('groupclist:delete:no'), $obj->name ) );
		}
	}
	else
	{
		register_error( sprintf( elgg_echo('groupclist:delete:no'), $obj->name ) );
	}	
	
	forward($_SERVER['HTTP_REFERER']);

?>