<?php

	/**
	 * Group Contact List Actions - Plugin
	 * 
	 * @package Group Contact List
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Tomas Feltl and Simone Aiken
	 * @copyright Quietly Competent Consulting 2010
	 * @link http://www.QuietlyCompetent.com
	 */
	 
	require_once(dirname(dirname(dirname(dirname(dirname(dirname(__FILE__)))))) . "/engine/start.php");

	global $CONFIG;
	admin_gatekeeper();
		
	// Get the User 
	$guid = get_input( 'guid' );
	$user = get_entity( $guid );
	
	// This array contains the guids of all the boxes the user checked.
	$usersGroups = get_input( 'uid' );	

	// This variable contains two arrays.
	// [0] The guids that were not checked when you pulled up the page.
	// [1] The guids that were checked when you pulled up the page.
	$cuid = get_input('cuid');
	
	
  	//
  	// Modify the User's Membership.
  	//
  	
	
	if ( ( $user instanceof ElggUser ) && ( $user->canEdit() ) )
	{
		$result = 1;
		$leave_err == 0;
      
		// Remove from the group everyone who was a member but isn't anymore.
		foreach ( $cuid[1] as $oldGroup ) 
		{
			// Try to avoid race conditions by checking that they are still a member.
        	if ( ! in_array( $oldGroup, $usersGroups ) && is_group_member( $oldGroup, $guid ) ) 
        	{
				$result = leave_group( $oldGroup, $guid );
          		
				if ( !$result ) 
				{
            		$leave_err = 1;
            		break;
          		} 
        	}   		
      	}
      	

      	if ( $leave_err == 0 ) 
      	{
      		// Add to the group everyone whose box was checked by the user.  	
			foreach ( $usersGroups as $newGroup ) 
			{
				if ( ! is_group_member( $newGroup, $guid ) ) 
				{
             		$result = join_group( $newGroup, $guid );
             		
             		if ( ! $result )
             		{ 
             			break;
             		}
           		}
			}
		}   		

		if ( $result ) 
		{
			system_message( elgg_echo( 'groupclist:userProfile:edit:yes' ) );
		} 
		else 
		{
			register_error( elgg_echo( 'groupclist:userProfile:edit:no' ) );
		}
	} 
	else 
	{
		register_error( elgg_echo( 'groupclist:userProfile:edit:no' ) );	
	}
	
	forward($_SERVER['HTTP_REFERER']);

?>