<?php

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'thewire' => "La red",
			'thewire:user' => "Red de %s",
			'thewire:posttitle' => "Notas de %s en la red: %s",
			'thewire:everyone' => "Todos los post de la red",
	
			'thewire:read' => "Envios de la red",
			
			'thewire:strapline' => "%s",
	
			'thewire:add' => "Enviar a la red",
		    'thewire:text' => "Una nota en la red",
			'thewire:reply' => "Responder",
			'thewire:via' => "via",
			'thewire:wired' => "Enviado a la red",
			'thewire:charleft' => "caracteres que quedan",
			'item:object:thewire' => "Env&iacute;os de la red",
			'thewire:notedeleted' => "nota borrada",
			'thewire:doing' => "Qu&eacute; est&aacute; haciendo? D&iacute;gaselo a cualquiera en la red:",
			'thewire:newpost' => 'Nuevo env&iacute;o en la red',
			'thewire:addpost' => 'Enviar a la red',

	
        /**
	     * The wire river
	     **/
	        
	        //generic terms to use
	        'thewire:river:created' => "%s enviados",
	        
	        //these get inserted into the river links to take the user to the entity
	        'thewire:river:create' => "en la red.",
	        
	    /**
	     * Wire widget
	     **/
	     
	        'thewire:sitedesc' => 'Este componente muestra las &uacute;ltimas notas enviadas a la red',
	        'thewire:yourdesc' => 'Este componente muestra la &uacute;ltimas notas enviadas a la red',
	        'thewire:friendsdesc' => 'Este componente mostrar&aacute; las &uacute;ltimas noticias de sus amigas en la red',
	        'thewire:friends' => 'Sus amigos en la red',
	        'thewire:num' => 'N&uacute;meros de items a mostrar',
	        
	        
	
		/**
		 * Status messages
		 */
	
			'thewire:posted' => "Su mensaje ha sido enviado a la red.",
			'thewire:deleted' => "Su nota ha sido borrada.",
	
		/**
		 * Error messages
		 */
	
			'thewire:blank' => "Lo lamento; necesita rellenar el cuadro de texto para poder guardarlo.",
			'thewire:notfound' => "Lo lamento; no podriamos encontrar la nota especificada.",
			'thewire:notdeleted' => "Lo lamento; no podriamos borrar esta nota.",
	
	
		/**
		 * Settings
		 */
			'thewire:smsnumber' => "Your SMS number if different from your mobile number (mobile number must be set to public for the wire to be able to use it). All phone numbers must be in international format.",
			'thewire:channelsms' => "The number to send SMS messages to is <b>%s</b>",
			
	);
					
	add_translation("es",$spanish);

?>
