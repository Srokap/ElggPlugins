<?php
	$english = array(
		// Title
		'profile_counter' => "Contador del perfil",
		'profile_counter:title' => "Contador del perfil",
		'profile_counter:shorttitle' => "Contador del perfil",
		
		'profile_counter:stats:title' => "Contador del perfil",
		'profile_counter:stats:currentcount' => "Su perfil ha sido visto %s veces.",
		'profile_counter:stats:reset' => "Resetear contados",
		'profile_counter:stats:confirm' => "Est&aacute; segura de resetear el contador?",
		
	);
	
	add_translation("es", $spanish);
?>
