<?php
	/**
	* ElggChat - Pure Elgg-based chat/IM
	* 
	* Builds the ElggChat Toolbar
	* 
	* @package elggchat
	* @author ColdTrick IT Solutions
	* @copyright Coldtrick IT Solutions 2009
	* @link http://www.coldtrick.com/
	* @version 0.4
	*/
	
?>
<script type='text/javascript' src='<?php echo $vars['url']; ?>/mod/elggchat/src/javascripts/jquery.tipsy.js'></script>
<link rel="stylesheet" href="<?php echo $vars['url']; ?>/mod/elggchat/src/stylesheets/tipsy.css" type="text/css" />
<!--End-->
<script type='text/javascript'> 
  $(function() {

$('#elggchat_friends2 a img').tipsy({gravity: 's'});
$('#toggle_elggchat_toolbar').tipsy({gravity: 'w'});

  });
</script>

<div id="elggchat_toolbar">
<div id="elggchat_toolbar_left">
	<!--<div id="elggchat_copyright">
		ElggChat (c) ColdTrick IT Solutions
	</div>-->
		<div id='elggchat_sessions'> 
		</div>
        <div id="icon_wrap">
        
		<div id="elggchat_friends">
			<a class="click" href="javascript:toggleFriendsPicker();"></a>
		</div>
        <div id="elggchat_friends2">
        
        <a href="<?php echo $vars['url']; ?>pg/photos/friends/<?php echo $_SESSION['user']->username; ?>"><img src="<?php echo $vars['url']; ?>mod/elggchat/_graphics/icon_image.png" title="Fotos" /></a>
        
        <a href="<?php echo $vars['url']; ?>pg/izap_videos/<?php echo $_SESSION['user']->username; ?>/frnd"><img src="<?php echo $vars['url']; ?>mod/elggchat/_graphics/icon_video.png" title="Videos" /></a>
        
        <a href="<?php echo $vars['url']; ?>pg/groups/world/<?php echo $_SESSION['user']->username; ?>"><img src="<?php echo $vars['url']; ?>mod/elggchat/_graphics/icon_group.png" title="Comunidades" /></a>
        
        <a href="<?php echo $vars['url']; ?>pg/event_calendar"><img src="<?php echo $vars['url']; ?>mod/elggchat/_graphics/icon_event.png" title="Eventos" /></a>
        
        </div>
        </div><!-- close icon wrap -->
		<div id="elggchat_friends_picker"></div>
	</div>
    
	<div id="toggle_elggchat_toolbar" class="toggle_elggchat_toolbar" onclick="toggleChatToolbar('fast')" title="<?php echo elgg_echo("elggchat:toolbar:minimize");?>"></div>

</div>
