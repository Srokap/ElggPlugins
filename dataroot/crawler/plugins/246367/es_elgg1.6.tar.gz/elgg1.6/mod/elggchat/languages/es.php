<?php
	/**
	* ElggChat - Pure Elgg-based chat/IM
	* 
	* English language file
	* 
	* @package elggchat
	* @author ColdTrick IT Solutions
	* @copyright Coldtrick IT Solutions 2009
	* @link http://www.coldtrick.com/
	* @version 0.4
	*/

	$spanish = array(
		'elggchat' => "Chat cuidatel:",
		'elggchat:title' => "Chat cuidatel:",
		'elggchat:chat:profile:invite' => "Invitar al chat",
		'elggchat:chat:send' => "Enviar",
		
		'elggchat:friendspicker:info' => "Conectadas/os",	
	
		'elggchat:chat:invite' => "Invitar",
		'elggchat:chat:minimize' => "Minimizar",
		'elggchat:chat:leave' => "Salir",
		'elggchat:chat:leave:confirm' => "Segura de dejar la charla?",
		'elggchat:chat:info' => "Info",
		
		'elggchat:action:invite' => "<b>%s</b> invitado <b>%s</b>",
		'elggchat:action:invite_friends' => "Invitar amigos",
		'elggchat:action:leave' => "<b>%s</b> dejar la charla",
		'elggchat:action:join' => "<b>%s</b> unirse a la charla",
		
		'elggchat:session_info:title' => "Informaci&oacute;n de la charla",
		'elggchat:session_info:id' => "id:",
		'elggchat:session_info:started' => "iniciada:",
		'elggchat:session_info:members' => "Miembros",
		'elggchat:session_info:invitations' => "Invitaciones extendidas",

		'elggchat:session:name:default' => "Sesiones de c (%s)",
		'elggchat:session:onlinestatus' => "Acci&oacute;n &uacute;ltima: %s",
		
		// Plugin settings
		'elggchat:admin:settings:hours' => "%s horas(s)",
	
		'elggchat:admin:settings:maxsessionage' => "Tiempo max que una sesi&oacute;n puede mantenerse sin respuesta antes de limpiarlo",
		
		'elggchat:admin:settings:chatupdateinterval' => "Intervalo de polling (segundos) de una ventana chat",
		'elggchat:admin:settings:maxchatupdateinterval' => "Cada 10 veces de polling no habrá datos a retornar y será enviados en este máximo de tiempo (segundos)",
		'elggchat:admin:settings:monitorupdateinterval' => "Intervalo de Polling (segundos) de la sesi&oacute;n de chat, el cualof the chat session monitor, which checks for new chat requests",

		'elggchat:admin:settings:online_status:active' => "Num. max de segundos antes de que el usuario esta inactivo",
		'elggchat:admin:settings:online_status:inactive' => "Num max de segundos antes de que el usuario esta inactivo",
		
		// User settings
		'elggchat:usersettings:enable_chat' => "Habilitar la barra?",
	
		// Toolbar actions
		'elggchat:toolbar:minimize' => "Minimizar/Maximizar la barra",
		'elggchat:toolbar:maximize' => "Minimizar/Maximizar la barra",
	);
					
	add_translation("es", $spanish);

?>
