<?php
	/**
	 * Elgg lastlogin plugin
	 * 
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette fabrice.collette@free.fr
	 * @copyright Fabrice Collette
	 * @link http://www.meleze-online.net
	 */




	$spanish = array(
	       'lastlogin:online' => '- online -',
	       'lastlogin:lastconnexion' => '&Uacute;ltimo acceso',
	       'lastlogin:hours' => 'horas',
	       'lastlogin:hour' => 'menos de una hora'
	       
		
	);
					
	add_translation("es",$spanish);
?>
