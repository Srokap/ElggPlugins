<?php
	/**
	 * Elgg GUID Tool
	 * 
	 * @package ElggGUIDTool
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */
	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'guidtool' => 'Herramienta Gr&acute;fica GUID',
			'guidtool:browse' => 'Explorador de GUIDs',
			'guidtool:import' => 'Importar',
			'guidtool:import:desc' => 'Pegar los datos que quiere importar al siguiente ventana.de be estar en formato  "%s".',
	
			'guidtool:pickformat' => 'Por favor seleccione el formato que desea importar o exportar.',
	
			'guidbrowser:export' => 'Exportar',
	);


	add_translation("es",$spanish);
?>
