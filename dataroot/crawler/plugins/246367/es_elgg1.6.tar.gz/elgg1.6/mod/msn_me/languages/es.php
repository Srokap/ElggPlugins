<?php

	$spanish = array(
	    		
		'msnme:widget:name' => 'H&aacute;blame por MSN',
		'msnme:widget:desc' => 'Widget de Mi MSN',
		'msnme:widget:msnusername' => 'Tu ID de MSN:<br>Para conseguir tu ID de MSN pulsa <a href="http://settings.messenger.live.com/applications/CreateHtml.aspx" target"_blank">este enlace</a> y copia el texto que encontrar&aacute;s entre invitee= y @apps.messenger..., este es tu ID de MSN.',
		'msnme:widget:usernameerror' => 'Debes configurar tu ID de MSN editando las propiedades de este widget.',
		'msnme:widget:webstatuswarning' => 'Debes asegurarte que tus opciones de privacidad de MSN permiten mostrar tu estado y ser contactado desde la web, para habilitar esto utiliza el siguiente enlace.',
		'msnme:widget:webstatuswarning2' => 'Selecciona la opcion Permitir que los usuarios de sitios web vean mi estado y me env&iacute;en mensajes y pulsa Guardar.',
		'msnme:widget:webstatuslink' => 'Mostrar tu estado de MSN en la web',
        'msnme:widget:refreshratemessage' => 'Este widget auto-refresca para actualizar tu estado. Puedes cambiar el tiempo de refresco seleccionando un valor aqui:',
        'msnme:widget:defaultrefreshrate' => 'Tiempo de refresco',
        'msnme:widget:nocontact' => 'El usuario ha deshabilitado el contacto por msn',
        'msnme:widget:contact' => 'Contacta conmigo pulsando aqui: ',
        'msnme:widget:options:norefresh' => 'No refrescar',
        'msnme:widget:options:15seconds' => '15 segundos',
        'msnme:widget:options:30seconds' => '30 segundos',
        'msnme:widget:options:60seconds' => '60 segundos',
        'msnme:widget:options:1hour' => '1 Hora',
        'msnme:widget:options:3hours' => '3 Horas',

        'msnme:widget:action:message' => 'Puedes controlar que sucede cuando se pulsa el boton "MSN" seleccionando una accion: ',        
        'msnme:widget:options:action:embed' => 'Pagina interna',
        'msnme:widget:options:action:new' => 'Pagina nueva',
        'msnme:widget:options:action:widget' => 'Widget',
        
        'msnme:widget:showmsnstatus' => 'Permitir que contacten conmigo?',
        'msnme:widget:showmsnstatus:options:yes' => 'Si',
        'msnme:widget:showmsnstatus:options:no' => 'No',
        'msnme:widget:showmsnstatus:refreshmessage' => '<b>Nota:</b> Cuando no se permite el contacto, el widget no se refresca.',
		'msnme:settings' => 'Configurar MSN Me',
		'msnme:settings:explanation' => 'Configurar MSN Me',
		'msnme:settings:configColors' => 'Configurar colores',
		'msnme:save:success' => 'Guardado',
		'msnme:settings:LanguageOption' => 'Seleccionar idioma',
		'msnme:settings:foreColor' => 'Texto',
		'msnme:settings:backColor' => 'Fondo',
		'msnme:settings:linkColor' => 'Enlaces',
		'msnme:settings:borderColor' => 'Borde',
		'msnme:settings:buttonForeColor' => 'Texto del boton',
		'msnme:settings:buttonBackColor' => 'Fondo del boton',
		'msnme:settings:buttonBorderColor' => 'Borde del boton',
		'msnme:settings:buttonDisabledColor' => 'Boton deshabilitado',
		'msnme:settings:headerForeColor' => 'Texto de cabecera',
		'msnme:settings:headerBackColor' => 'Fondo de cabecera',
		'msnme:settings:menuForeColor' => 'Texto del menu',
		'msnme:settings:menuBackColor' => 'Fondo del menu',
		'msnme:settings:chatForeColor' => 'Texto del chat',
		'msnme:settings:chatBackColor' => 'Fondo del chat',
		'msnme:settings:chatDisabledColor' => 'Chat deshabilitado',
		'msnme:settings:chatErrorColor' => 'Mensajes de error',
		'msnme:settings:chatLabelColor' => 'Etiquetas del chat',
		
	);
					
	add_translation("es",$spanish);

?>