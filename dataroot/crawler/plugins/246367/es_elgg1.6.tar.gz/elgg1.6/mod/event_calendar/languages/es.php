<?php

	$spanish = array(
	
	'item:object:event_calendar' => "Calendarios y Eventos",
	'event_calendar:new_event' => "Nuevo evento",
	'event_calendar:no_such_event_edit_error' => "Error: No hay evento o no tiene permisos para edici&oacute;n.",
	'event_calendar:add_event_title' => "A&ntilde;adir un evento",
	'event_calendar:manage_event_title' => "Editar evento",
	'event_calendar:manage_event_description' => "Introduzca los detalles de su evento. "
		."El t&iacute;tulo, origen, y otros datos que sean necesarios. "
		."Puede pulsar en los iconos del calendario para configurar el inicio y fin del evento.",
	'event_calendar:title_label' => "T&iacute;tulo",
	'event_calendar:title_description' => "Requerido. De una a 4 palabras",
	'event_calendar:brief_description_label' => "Breve descripci&oacute;n",
	'event_calendar:brief_description_description' => "Opcional. Una frase corta.",
	'event_calendar:venue_label' => "Venue",
	'event_calendar:venue_description' => "Requerido. D&oacute;nde se dar&aacute; este evento?",
	'event_calendar:start_date_label' => "Fecha de comienzo",
	'event_calendar:start_date_description'	=> "Requerido. Cu&aacute;ndo comenzar&aacute; este evento?",
	'event_calendar:end_date_label' => "Fin de fecha",
	'event_calendar:end_date_description'	=> "Opcional. Cu&aacute;ndo terminar&aacute; este evento? El inicio estará "
		."como final de fecha si no es usado este campo.",
	'event_calendar:fees_label' => "Tasas",
	'event_calendar:fees_description'	=> "Opcional. El coste de este evento si lo hubiere.",
	'event_calendar:contact_label' => "Contacto",
	'event_calendar:contact_description'	=> "Opcional. La persona de contacto para m&aacute;s informaci&oacute;n, "
			."preferably with a telephone number or email address.",
	'event_calendar:organiser_label' => "Organiser",
	'event_calendar:organiser_description'	=> "Opcional. La organizaci&oacute;n encargada del evento.",
	'event_calendar:event_tags_label' => "Etiquetas",
	'event_calendar:event_tags_description'	=> "Opcional. Una lista de etiquetas separadas por comas para este evento.",
	'event_calendar:long_description_label' => "Descripción detallada",
	'event_calendar:long_description_description'	=> "Opcional. Puede ser un p&aacuted;rrafo o m&aacute;s si lo requiere.",
	'event_calendar:manage_event_response' => "Su evento ha sido guardado.",
	'event_calendar:add_event_response' => "Su evento ha sido a&ntilde;adido.",
	'event_calendar:manage_event_error' => "Error: Ha habido un error al guardar el evento. "
			."Por favor aseg&uacute;rese de que ha completado los campos obligatorios.",
	'event_calendar:show_events_title' => "Calendario de eventos",
	'event_calendar:day_label' => "D&iacute;a",
	'event_calendar:week_label' => "Semanal",
	'event_calendar:month_label' => "Mensual",
	'event_calendar:group' => "Calendario de la comunidad",
	'event_calendar:new' => "A&ntilde;adir ",
	'event_calendar:submit' => "Enviar",
	'event_calendar:cancel' => "Cancelar",
	'event_calendar:widget_title' => "Calendarios de eventos",
	'event_calendar:widget:description' => "Mostrar sus eventos.",
	'event_calendar:num_display' => "N&uacute;mero de eventos a mostrar",
	'event_calendar:groupprofile' => "Eventos recientes",
	'event_calendar:view_calendar' => "Ver calendario",
	'event_calendar:when_label' => "Cu&aacute;ndo",
	'event_calendar:site_wide_link' => "Ver todos los eventos",
	'event_calendar:view_link' => "Ver este evento",
	'event_calendar:edit_link' => "Editar este evento",
	'event_calendar:delete_link' => "Borrar este evento.",
	'event_calendar:delete_confirm_title' => "Confirmar borrar evento",
	'event_calendar:delete_confirm_description' => "Est&aacute; seguro que quiere borrar este evento (\"%s\")?.",
	'event_calendar:delete_response' => "Evento eliminado.",
	'event_calendar:error_delete' => "Este evento no existe o no tiene permisos para borrarlo.",
	'event_calendar:delete_cancel_response' => "Cancelada la eliminaci&oacute;n.",
	'event_calendar:add_to_my_calendar' => "A&ntilde;adir a mi calendario",
	'event_calendar:remove_from_my_calendar' => "Eliminar mi calendario",
	'event_calendar:add_to_my_calendar_response' => "Este evento ha sido a&ntilde;adido a su calendario personal.",
	'event_calendar:remove_from_my_calendar_response' => "Este evento ha sido eliminado de su calendario personal.",
	'event_calendar:users_for_event_title' => "Gente interesada en este evento \"%s\"'",
	'event_calendar:personal_event_calendars_link' => "Calendario personal de (%s)",
	'event_calendar:settings:group_profile_display:title' => "Calendario de la comunidad",
	'event_calendar:settings:group_profile_display_option:left' => "columna izquierda",
	'event_calendar:settings:group_profile_display_option:right' => "columna derecha",
	'event_calendar:settings:group_profile_display_option:none' => "ninguno",
	'event_calendar:settings:autopersonal:title' => "Autom&aacute;ticamente a&ntilde;ade eventos y crea su calendario personal",
	'event_calendar:settings:yes' => "s&íacute;",
	'event_calendar:settings:no' => "no",
	'event_calendar:settings:site_calendar:title' => "Calendarios",
	'event_calendar:settings:site_calendar:admin' => "s&iacute;, s&oacute;lo los administradores puede enviar eventos",
	'event_calendar:settings:site_calendar:loggedin' => "s&iacute;, cualquier usuario logado puede enviar eventos",	
	'event_calendar:settings:group_calendar:title' => "Calendario de comunidad",
	'event_calendar:settings:group_calendar:admin' => "s&iacute;, solo administradores puede enviar eventos",
	'event_calendar:settings:group_calendar:members' => "s&iacute;, cualquier miembro puede enviar eventos",
	'event_calendar:settings:group_default:title' => "Las nuevas comunidades debería tener un calendario (si lo tiene habilitado)",
	'event_calendar:settings:group_default:no' => "no (pero los administradores o propietarios del calendario si lo desea)",
	'event_calendar:settings:group_default:yes' => "s&iacute; (pero administrador o propietarios del calendario puede cambiarlo)",
	'event_calendar:enable_event_calendar' => "Habilitar calendarios a la comunidad",
	'event_calendar:no_events_found' => "No hay eventos.",
			
	/**
	 * Event calendar river
	 **/
			 
	//generic terms to use
    'event_calendar:river:created' => "%s a&ntilde;adidos",
    'event_calendar:river:updated' => "%s actualizados",
    'event_calendar:river:annotated1' => "%s a&ntilde;adidos",
	'event_calendar:river:annotated2' => "a su calendario personal.",
	 
	//these get inserted into the river links to take the user to the entity
    'event_calendar:river:create' => "un nuevo evento marcado",
    'event_calendar:river:the_event' => "un evento marcado",
	);
					
	add_translation("es",$spanish);

?>
