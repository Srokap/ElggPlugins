<?php

	$spanish = array(
		"tagcloud:widget:title" => "Nube de Etiquetas",
		"tagcloud:widget:description" => "Nube de Etiquetas",
		"tagcloud:widget:notags" => "N&uacute;mero de etiquetas a mostrar"
	);
					
	add_translation("es",$spanish);

?>
