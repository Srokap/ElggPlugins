<?php
	/**
	* DraggableWidgets - Languages
	* 
	* @package draggable_widgets
	* @author ColdTrick IT Solutions
	* @copyright Coldtrick IT Solutions 2009
	* @link http://www.coldtrick.com/
	*/
	$spanish = array(
			'draggable_widgets:add' => "Pulse para a&ntilde;adir un nuevo componente",
			'draggable_widgets:delete' => "Segura/o de borrar este componente?",
	);
					
	add_translation("en",$spanish);

?>
