<?php
	/**
	 * Elgg log rotator language pack.
	 * 
	 * @package ElggLogRotate
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	$english = array(
		'logrotate:period' => 'Cu&aacute;n a menudo debería guardar el log el sistema?',
	
		'logrotate:weekly' => 'Una vez a la semana',
		'logrotate:monthly' => 'Una vez al mes',
		'logrotate:yearly' => 'Una vez al a&ntilde;o',
	
		'logrotate:logrotated' => "Log rotado\n",
		'logrotate:lognotrotated' => "Error en el rotado del log\n",
	);
					
	add_translation("es",$spanish);
?>
