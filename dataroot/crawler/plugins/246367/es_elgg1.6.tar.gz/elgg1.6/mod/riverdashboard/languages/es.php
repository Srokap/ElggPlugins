<?php

	$spanish = array(

		'mine' => 'Todas',
		'filter' => 'Filtro',
		'riverdashboard:useasdashboard' => "Sustituir el escritorio por defecto con el flujo de esta actividad?",
		'activity' => 'Activity',
	
	    /**
	     * Site messages
           **/

		'sitemessages:announcements' => "Anuncios del lugar",
		'sitemessages:posted' => "Enviados",
		'sitemessages:river:created' => "Lugar del administrador, %s,",
		'sitemessages:river:create' => "enviados un mensaje por la red",
		'sitemessages:add' => "A&ntilde;adir un mensaje al las p&aacute;ginas",
		'sitemessage:deleted' => "Lugar de mensajes eliminados",
		
		'river:widget:noactivity' => 'No podemos detectar ninguna actividad.',
		'river:widget:title' => "Actividad",
		'river:widget:description' => "Mostrar la &uacute;ltima actividad.",
		'river:widget:title:friends' => "Actividad de los amigos",
		'river:widget:description:friends' => "Mostrar lo que tu amigas hacen.",
		'river:widgets:friends' => "Amigas",
		'river:widgets:mine' => "Todas",
		'river:widget:label:displaynum' => "N&uacute;meor de entradas a mostrar:",
		'river:widget:type' => "Cual v&iacute;a desear&iacute;a mostrar? Una muestra su actividad y la otra la actividad de sus amigas?",
		'item:object:sitemessage' => "Lugar de mensajes",
		'welcome:user' => "Bienvenido/a", //Esto es raro raro la mierda no pone el $_SESSION['user']->user sin embargo si lo quito si lo pone pero en Welcome!. 25 Agosto 2009
	);
					
	add_translation("es",$spanish);

?>
