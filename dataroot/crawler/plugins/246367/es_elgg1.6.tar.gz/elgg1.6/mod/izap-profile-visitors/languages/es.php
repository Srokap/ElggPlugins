<?php
	/**
	 * iZAP izap profile visitor
	 * 
	 * @license GNU Public License version 3
	 * @author iZAP Team "<support@izap.in>"
	 * @link http://www.izap.in/
	 * @version 1.0
	 * @compatibility elgg-1.5
	 */
$spanish = array(
		'izapProfileVisitor:Widget' => 'Visitas recientes al perfil',
		'izapProfileVisitor:WidgetDescription' => 'Este componente permite saber qui&eacute;n ha visitado su perfil.',
		'izapProfileVisitor:NumberOfVisitors' => 'Visitantes a mostrar',
		'izapProfileVisitor:NoVisits' => ':( aun no me han visto.',
);

add_translation("es",$spanish);
