<?php

	$english = array(
			'googleanalytics' => 'Google Analytics',
			'googleanalytics:formenabled' => 'Enable?',
			'googleanalytics:description' => 'This plugin allows you to setup Google Analytics on your Elgg site.',
			'googleanalytics:modify' => 'Enter your Web Property ID: <br /><small>(This will most likely be in the form of GA-1234567-1)</small>',
			'googleanalytics:submit' => 'Submit',
			'googleanalytics:enabled' => 'Google Analytics plugin is enabled.',
			'googleanalytics:disabled' => 'Google Analytics plugin is disabled.',
			'googleanalytics:enable' => 'Enable Google Analytics plugin',
			'googleanalytics:disable' => 'Disable Google Analytics plugin',
			'googleanalytics:wantmodify' => 'Change your Analytics Web Property ID',
			
			'googleanalytics:failed:noadmin' => 'You must be an administrator to use this feature.',
			'googleanalytics:modify:success' => 'Successfully updated the Google Analytics settings.',
			'googleanalytics:modify:failed' => 'Failed to update the Google Analytics settings.',
			'googleanalytics:failed:noparams' => 'Error: Incorrect or unexpected data.',
			
			'item:object:modgoogleanalytics' => 'Google Analytics Object'
	);
					
	add_translation("en",$english);
?>
