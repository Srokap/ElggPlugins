<?php

	$spanish = array(
	
           'gmap' => 'Google Maps',
           'gmap:desc' => 'Este componente permite localizar google maps en tu red social.',
           'gmap:nokey' => "You've installed the Google Map plugin but you still need to supply a GMap API key in the <a href='%spg/admin/plugins'>Tool Administration panel</a>.",

           'gmap:location' => 'Introduzca la localizaci&oacute;n',
           'gmap:zoom' => 'Introduzca un nivel de visi&oacute;n',
           'gmap:notfound' => 'Direcci&oacute;n \'%s\' no encontrada',
           
           'gmap:submit' => 'Enviar',
           'gmap:modify' => 'Enter your Google Maps API Key<br /><small>You can obtain an API Key <a target="_blank" href="http://code.google.com/apis/maps/signup.html">here</a>.</small>',
           'gmap:modify:success' => 'Successfully updated the Google Maps API settings.',
           'gmap:modify:failed' => 'Failed to update the Google Maps API settings.',
           'gmap:failed:keyrequired' => 'You must provide an API key.',


           'gmap:river:created' => "%s a&ntilde;adido componente map.",
           'gmap:river:updated' => "%s actualizado el componente map.",
           'gmap:river:delete' => "%s eliminado el componente map.",

           'item:object:' . GMAP_SUBTYPE => 'Google Maps'
	);
					
	add_translation("es",$spanish);

?>
