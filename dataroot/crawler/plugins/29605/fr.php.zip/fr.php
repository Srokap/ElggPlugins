<?php

	$french = array(
	
	'item:object:event_calendar' => "Agenda",
	'event_calendar:new_event' => "Nouvel événement",
	'event_calendar:no_such_event_edit_error' => "Erreur: Il n'y a pas de tel événement, ou vous n'avez pas la permission de le modifier.",
	'event_calendar:add_event_title' => "Ajouter un événement",
	'event_calendar:manage_event_title' => "Modifier un événement",
"Ajouter les détails de votre événement si dessous."
		."Le titre, lieu, et la date sont obligatoires. "
		."Vous pouvez cliquer sur l'icone de l'agenda afin d'y insérer le début et la fin de l'événement.",
	'event_calendar:title_label' => "Titre",
	'event_calendar:title_description' => "Obligatoire. Un à quatre mots",
	'event_calendar:brief_description_label' => "Courte description",
	'event_calendar:brief_description_description' => "Optionnel. Une phrase courte.",
	'event_calendar:venue_label' => "Lieu",
	'event_calendar:venue_description' => "Obligatoire. Où se tiendra l'événement?",
	'event_calendar:start_date_label' => "Date de départ",
	'event_calendar:start_date_description'	=> "Obligatoire. A quelle date cet événement démarera?",
	'event_calendar:end_date_label' => "Date de fin de l'événement",
	'event_calendar:end_date_description'	=> "Optionnel. Quand c'est événement s'achèvera-t-il? La date de départ sera "
		."utilisée comme date de fin si ce champ n'est pas rempli.",
	'event_calendar:fees_label' => "Prix d'entrée",
	'event_calendar:fees_description'	=> "Optionnel. Le côut de l'événement.",
	'event_calendar:contact_label' => "Contact",
	'event_calendar:contact_description'	=> "Optionnel. La personne à contacter pour avoir plus de renseignements, "
			."préférablement avec un numéro de téléphone ou une adresse emailpreferably with a telephone number or email address.",
	'event_calendar:organiser_label' => "Organisateur",
	'event_calendar:organiser_description'	=> "Optionnel. La personne ou l'organisation responsable de l'événement.",
	'event_calendar:event_tags_label' => "Tags",
	'event_calendar:event_tags_description'	=> "Optionnel. Une liste de tags séparés par des virgules.",
	'event_calendar:long_description_label' => "Description longue",
	'event_calendar:long_description_description'	=> "Optionnel. Peut être un paragraphe ou plus si nécessaire.",
	'event_calendar:manage_event_response' => "Votre événement a été sauvegardé.",
	'event_calendar:add_event_response' => "Votre événement a été ajouté.",
	'event_calendar:manage_event_error' => "Erreur: Une erreur s'est produite lors de l'enregistrement de votre événement. "
			."Assurez-vous que les champs spécifiés ont bien été remplis.",
	'event_calendar:show_events_title' => "Agenda des événements",
	'event_calendar:day_label' => "Jour",
	'event_calendar:week_label' => "Semaine",
	'event_calendar:month_label' => "Mois",
	'event_calendar:group' => "Agenda de groupe",
	'event_calendar:new' => "Ajouter un événement",
	'event_calendar:submit' => "Ok",
	'event_calendar:cancel' => "Annuler",
	'event_calendar:widget_title' => "Agenda des événements",
	'event_calendar:widget:description' => "Afficher vos événements.",
	'event_calendar:num_display' => "Nombre d'événement à afficher",
	'event_calendar:groupprofile' => "Les prochains événements",
	'event_calendar:view_calendar' => "Voir l'agenda",
	'event_calendar:when_label' => "Quand",
	'event_calendar:site_wide_link' => "Voir tous les événements",
	'event_calendar:view_link' => "Voir cet événement",
	'event_calendar:edit_link' => "Modifier cet événement",
	'event_calendar:delete_link' => "Supprimer cet événement",
	'event_calendar:delete_confirm_title' => "Confirmer la suppression de l'événement",
	'event_calendar:delete_confirm_description' => "Etes-vous sur de vouloir supprimer cet événement (\"%s\")? Cette action est irréversible.",
	'event_calendar:delete_response' => "Cet événement a été supprimé.",
	'event_calendar:error_delete' => "Cet événement n'existe pas ou vous n'avez pas le droit de le supprimer.",
	'event_calendar:delete_cancel_response' => "Suppression de l'événement annulé.",
	'event_calendar:add_to_my_calendar' => "Ajouter à mon agenda",
	'event_calendar:remove_from_my_calendar' => "Supprimer de mon agenda",
	'event_calendar:add_to_my_calendar_response' => "Cet événement a été ajouté à votre agenda personnel.",
	'event_calendar:remove_from_my_calendar_response' => "Cet événement a été supprimé de votre agenda personnel.",
	'event_calendar:users_for_event_title' => "Membre du site intéressé par l'événement \"%s\"'",
	'event_calendar:personal_event_calendars_link' => "Agenda des événements personnels de (%s)",
	'event_calendar:settings:group_profile_display:title' => "Afficher le profil de l'agenda du groupe (Si les agendas de groupe ont été permis)",
	'event_calendar:settings:group_profile_display_option:left' => "Colonne de gauche",
	'event_calendar:settings:group_profile_display_option:right' => "Colonne de droite",
	'event_calendar:settings:group_profile_display_option:none' => "aucun",
	'event_calendar:settings:autopersonal:title' => "Ajouter automatiquement les événements d'un utilisateur à son agenda personnelA.",
	'event_calendar:settings:yes' => "oui",
	'event_calendar:settings:no' => "non",
	'event_calendar:settings:site_calendar:title' => "Side de l'agenda",
	'event_calendar:settings:site_calendar:admin' => "oui, seuls les administrateurs peuvent proposer des événements",
	'event_calendar:settings:site_calendar:loggedin' => "oui, seuls les utilisateurs identifiés peuvent publier un événement",	
	'event_calendar:settings:group_calendar:title' => "Les agendas du groupe",
	'event_calendar:settings:group_calendar:admin' => "oui seuls les administrateurs et les créateurs du groupe peuvent publier un événement",
	'event_calendar:settings:group_calendar:members' => "oui, les membres du groupe peuvent publier un événement",
	'event_calendar:settings:group_default:title' => "Les nouveaux groupes par défaut peuvent avoir leur propre agenda (Si les agendas de groupe sont permis)",
	'event_calendar:settings:group_default:no' => "non (mais les administrateurs du groupe peuvement ajouter la fonction agenda si désiré)",
	'event_calendar:settings:group_default:yes' => "oui (mais les administrateurs ou les créateurs du groupe peuvent supprimer la fonction agenda si désiré)",
	'event_calendar:enable_event_calendar' => "Ajouter la fonction agenda au groupe",
	'event_calendar:no_events_found' => "Aucun événement trouvé.",
	'mine' => "Mon agenda",
			
	/**
	 * Event calendar river
	 **/
			 
	//generic terms to use
    'event_calendar:river:created' => "%s ajouté",
    'event_calendar:river:updated' => "%s mis à jour",
    'event_calendar:river:annotated1' => "%s ajouté",
	'event_calendar:river:annotated2' => "à son agenda personnel.",
	 
	//these get inserted into the river links to take the user to the entity
    'event_calendar:river:create' => "un nouvel événement intitulé",
    'event_calendar:river:the_event' => "un événement intitulé",
	);
					
	add_translation("fr",$french);

?>