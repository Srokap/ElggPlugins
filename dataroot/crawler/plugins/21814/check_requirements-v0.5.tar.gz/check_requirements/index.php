<?php
/**
 * Index page
 *
 * @author      Rolando Espinoza La fuente (rho@prosoftpeople.com)
 * @copyright   Copyright (c) 2008-2009 Pro Soft Resources USA Inc. (http://www.prosoftpeople.com)
 * @license     GNU General Public License version 2
 * @version     $Id$
 */

require_once dirname(dirname(dirname(__FILE__))) . '/engine/start.php';

/**
 * If plugin is not enabled, force manual load
 */
if (!is_plugin_enabled('check_requirements')) {
    global $CONFIG;

    // load plugin functions
    require_once dirname(__FILE__) . '/start.php';

    // add translation
    require_once dirname(__FILE__) . '/languages/en.php';

    $elgg_layout = 'one_column.php'; // needs .php extension ¿?
} else {
    $elgg_layout = 'two_column_left_sidebar';
}

set_context('admin');

$title = elgg_echo('requirements:check');
$content = elgg_view_title($title);

/**
 * Don't use elgg views to allow plugin execution
 * on a missconfigured elgg. Ugly but works.
 */
$content .= <<< END
<style type="text/css">
.test-name {
    width: 30%;
    text-align: right;
    font-weight: bold;
}

.test-result {
    width: 40%;
}

.test-name span,
.test-result span {
    display: block;
    padding: 3px;
}

.test-success {
    background: #ccffcc;
}

.test-fail {
    background: #f7dad8;
}
</style>

<table>
END;

$tests = check_requirements_get_tests();

foreach ($tests as $test) {
    $content .= '<tr><td class="test-name"><span>';
    $content .= elgg_echo('requirements:test:' . $test);
    $content .= '</span></td><td class="test-result">';
    $content .= check_requirements_test_result($test);
    $content .= '</td></tr>';
}

$content .= '</table>'; // close table

$body = elgg_view_layout($elgg_layout, null, $content);

page_draw($title, $body);

