<?php
/**
 * Language definition
 *
 * @author      Rolando Espinoza La fuente (rho@prosoftpeople.com)
 * @copyright   Copyright (c) 2008-2009 Pro Soft Resources USA Inc. (http://www.prosoftpeople.com)
 * @license     GNU General Public License version 2
 * @version     $Id$
 */

$english = array(
    'requirements:check' => 'Check requirements',
    'requirements:test:unknown' => 'Unknown',

    // apache
    'requirements:test:apache' => 'Running PHP as Apache Module',
    'requirements:test:apache:success' => 'Yes',
    'requirements:test:apache:fail' => 'No. Running PHP as cgi/fcgi is not officially supported.',

    // mod_rewrite
    'requirements:test:mod_rewrite' => 'Apache Rewrite Module',
    'requirements:test:mod_rewrite:success' => 'Module is loaded',
    'requirements:test:mod_rewrite:fail' => 'Module is not loaded',
    'requirements:test:mod_rewrite:unknown' => 'Perhaps PHP is not running as Apache module',
    'requirements:test:mod_rewrite:check' => '(Test friendly url\'s)',
    'requirements:test:mod_rewrite:working' => 'Congratulations! mod_rewrite test successful!',

    // mysql 
    'requirements:test:mysql' => 'MySQL Server Version',
    'requirements:test:mysql:success' => 'Ok',
    'requirements:test:mysql:fail' => 'Version not supported. MySQL 5+ required.',
    'requirements:test:mysql:unknown' => 'Test failed',

    // php
    'requirements:test:php' => 'PHP Server Version',
    'requirements:test:php:success' => 'Ok',
    'requirements:test:php:fail' => 'Version not supported. PHP 5.1.4+ required.',
    'requirements:test:php:unknown' => 'Test failed',

    // php-gd
    'requirements:test:php-gd' => 'PHP GD Module',
    'requirements:test:php-gd:success' => 'Ok',
    'requirements:test:php-gd:fail' => 'Module not loaded. PHP GD module is required for graphics processing.',
    'requirements:test:php-gd:unknown' => 'Test failed',

    // php-json
    'requirements:test:php-json' => 'PHP JSON Module',
    'requirements:test:php-json:success' => 'Ok',
    'requirements:test:php-json:fail' => 'Module not loaded. PHP JSON module is required for api funcionality.',
    'requirements:test:php-json:unknown' => 'Test failed',

    // php-mbstring
    'requirements:test:php-mbstring' => 'PHP MBString Module',
    'requirements:test:php-mbstring:success' => 'Ok',
    'requirements:test:php-mbstring:fail' => 'Module not loaded. PHP MBString module is required for internationalization support.',
    'requirements:test:php-mbstring:unknown' => 'Test failed',

    // php-soap
    'requirements:test:php-soap' => 'PHP SOAP Module (Optional)',
    'requirements:test:php-soap:success' => 'Ok',
    'requirements:test:php-soap:fail' => 'Module not loaded.',
    'requirements:test:php-soap:unknown' => 'Test failed',

    // php-dom
    'requirements:test:php-dom' => 'PHP DOM Module (Optional)',
    'requirements:test:php-dom:success' => 'Ok',
    'requirements:test:php-dom:fail' => 'Module not loaded.',
    'requirements:test:php-dom:unknown' => 'Test failed',

    // php safe_mode
    'requirements:test:safe_mode' => 'PHP Safe Mode',
    'requirements:test:safe_mode:success' => 'Ok. PHP is not running on safe mode.',
    'requirements:test:safe_mode:fail' => 'PHP is running on safe mode. Elgg with not work properly with safe mode enabled.',
    'requirements:test:safe_mode:unknown' => 'Test failed',

    // php memory_limit
    'requirements:test:memory_limit' => 'PHP Memory Limit',
    'requirements:test:memory_limit:success' => 'Ok. PHP Memory limit is higher than or equal to 16M.',
    'requirements:test:memory_limit:fail' => 'PHP Memory Limit is less than 16M. Raise your php memory limit.',
    'requirements:test:memory_limit:unknown' => 'Test failed',

    // php register_globals 
    'requirements:test:register_globals' => 'PHP Register Globals',
    'requirements:test:register_globals:success' => 'Ok. PHP Register Globals is Off.',
    'requirements:test:register_globals:fail' => 'PHP Register Globals is ON. Disable Register Globals to enforce PHP Security.',
    'requirements:test:register_globals:unknown' => 'Test failed',


    // php register_globals 
    'requirements:test:register_globals' => 'PHP Register Globals',
    'requirements:test:register_globals:success' => 'Ok. PHP Register Globals is Off.',
    'requirements:test:register_globals:fail' => 'PHP Register Globals is ON. Disable Register Globals to enforce PHP Security.',
    'requirements:test:register_globals:unknown' => 'Test failed',

    // php post_max_size
    'requirements:test:post_max_size' => 'PHP Post Max Size (Optional)',
    'requirements:test:post_max_size:success' => 'Ok. Maximum post size (%s) is greater than 10M.',
    'requirements:test:post_max_size:fail' => 'Current Maximum Post Size: %s. Increase if you want to allow your users to upload big files.',
    'requirements:test:post_max_size:unknown' => 'Test failed',


    // php upload_max_filesize
    'requirements:test:upload_max_filesize' => 'PHP Upload Max Size (Optional)',
    'requirements:test:upload_max_filesize:success' => 'Ok. Maximum upload size (%s) is greater than 10M.',
    'requirements:test:upload_max_filesize:fail' => 'Current Maximum Upload Size: %s. Increase if you want to allow your users to upload big files.',
    'requirements:test:upload_max_filesize:unknown' => 'Test failed',


    // php apache_gzip
    'requirements:test:apache_gzip' => 'Apache GZip Module (Optional)',
    'requirements:test:apache_gzip:success' => 'Module Loaded.',
    'requirements:test:apache_gzip:fail' => 'Module not loaded. Required if you want pages compression. Conflicts with Deflate module.',
    'requirements:test:apache_gzip:unknown' => 'Test failed',


    // php apache_deflate
    'requirements:test:apache_deflate' => 'Apache Deflate Module (Optional)',
    'requirements:test:apache_deflate:success' => 'Module Loaded.',
    'requirements:test:apache_deflate:fail' => 'Module not loaded. Required if you want pages compression. Conflicts with GZip Module ',
    'requirements:test:apache_deflate:unknown' => 'Test failed',

    );

add_translation('en', $english);

