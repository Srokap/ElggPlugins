<?php
/**
 * Rewrite test page
 *
 * @author      Rolando Espinoza La fuente (rho@prosoftpeople.com)
 * @copyright   Copyright (c) 2008-2009 Pro Soft Resources USA Inc. (http://www.prosoftpeople.com)
 * @license     GNU General Public License version 2
 * @version     $Id$
 */

if (!function_exists('check_requirements_pagehandler')) {
    die;
}

set_context('admin');

$title = elgg_echo('requirements:test:mod_rewrite:working');
$content = elgg_view_title($title);
$body = elgg_view_layout('two_column_left_sidebar', null, $content);

page_draw($title, $body);

