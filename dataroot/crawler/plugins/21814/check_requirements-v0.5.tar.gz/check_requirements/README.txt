 * Go to http://server/elgg/mod/check_requirements/index.php
