<?php
/**
 * Requirements Checker plugin
 *
 * @author      Rolando Espinoza La fuente (rho@prosoftpeople.com)
 * @copyright   Copyright (c) 2008-2009 Pro Soft Resources USA Inc. (http://www.prosoftpeople.com)
 * @license     GNU General Public License version 2
 * @version     $Id$
 */

/**
 * Elgg hooks & events
 */
register_elgg_event_handler('pagesetup', 'system', 'check_requirements_pagesetup');
register_page_handler('check_requirements', 'check_requirements_pagehandler');

/**
 * Add admin submenu item and CSS style
 * 
 * @return void
 */
function check_requirements_pagesetup()
{
    global $CONFIG;

    if ('admin' == get_context()) {
        add_submenu_item(elgg_echo('requirements:check'), $CONFIG->url . 'mod/check_requirements/index.php');
    }

    extend_view('css', 'check_requirements/css');
}

/**
 * Plugin page handler
 * 
 * @return bool
 */
function check_requirements_pagehandler($page)
{
    global $CONFIG;

    switch ($page[0]) {
        case 'test_rewrite': // test mod_rewrite
            include $CONFIG->pluginspath . 'check_requirements/test_rewrite.php';
            break;
        default:
            include $CONFIG->pluginspath . 'check_requirements/index.php';
    }

    return true;
}

/**
 * Available tests
 * 
 * @return array
 */
function check_requirements_get_tests()
{
    $tests = array(
        'apache',
        'mod_rewrite',
        'mysql',
        'php',
        'php-gd',
        'php-json',
        'php-mbstring',
        'php-soap',
        'php-dom',
        'safe_mode',
        'memory_limit',
        'register_globals',
        'post_max_size',
        'upload_max_filesize',
        'apache_gzip',
        'apache_deflate',
        );

    return $tests;
}

/**
 * Human readable result of given test
 * 
 * @param  string $test 
 * @return string
 */
function check_requirements_test_result($test)
{
    global $CONFIG;

    $message = elgg_echo('requirements:test:unknown');

    $test_result = check_requirements_test($test);

    switch ($test) {
        case 'mod_rewrite':
            if (null === $test_result) {
                $message = elgg_echo('requirements:test:mod_rewrite:unknown');
            } elseif (true === $test_result) {
                $message = elgg_echo('requirements:test:mod_rewrite:success');

                /**
                 * allow rewrite test only if plugin is enabled
                 */
                if (is_plugin_enabled('check_requirements')) {
                    $message .= ' <a href="' 
                        . $CONFIG->url 
                        . 'pg/check_requirements/test_rewrite'  
                        . '"><small>' 
                        . elgg_echo('requirements:test:mod_rewrite:check') 
                        . '</small></a>';
                } elseif (isloggedin()) {
                    $message .= ' <a href="' 
                        . $CONFIG->url 
                        . 'pg/admin/plugins'  
                        . '"><small>' 
                        . elgg_echo('requirements:test:mod_rewrite:check') 
                        . '</small></a>';
                }
            } else {
                $message = elgg_echo('requirements:test:mod_rewrite:fail');
            }

            break;
        case 'post_max_size':
        case 'upload_max_filesize':
            if (null === $test_result) {
                $message = elgg_echo('requirements:test:' . $test . ':unknown');
            } elseif (true === $test_result) {
                $message = elgg_echo('requirements:test:' . $test . ':success');
                $message = sprintf($message, ini_get($test));
            } else {
                $message = elgg_echo('requirements:test:' . $test . ':fail');
                $message = sprintf($message, ini_get($test));
            }

            break;


        default:
            if (null === $test_result) {
                $message = elgg_echo('requirements:test:' . $test . ':unknown');
            } elseif (true === $test_result) {
                $message = elgg_echo('requirements:test:' . $test . ':success');
            } else {
                $message = elgg_echo('requirements:test:' . $test . ':fail');
            }
    }

    if ($test_result) {
        $result = '<span class="test-success">' . $message . '</span>';
    } else {
        $result = '<span class="test-fail">' . $message . '</span>';
    }

    return $result;
}

/**
 * Success or fail of given test
 * 
 * @param  string $test 
 * @return bool
 */
function check_requirements_test($test)
{
    if (0 === strpos($test, 'php-')) {
        // test: xml, SimpleXml, soap, mbstring, json, dom, curl, gd, zlib
        return extension_loaded(substr($test, strlen('php-')));
    }

    switch ($test) {
        case 'apache':
            return (0 === strpos(php_sapi_name(), 'apache'));

        case 'mod_rewrite': // check if mod_rewrite is loaded
            return check_requirements_apache_module('mod_rewrite');

        case 'php':
            return php_check_version();

        case 'mysql':
            return db_check_version();

        case 'safe_mode':
            $mode = ini_get('safe_mode');
            return empty($mode);

        case 'memory_limit':
            $limit = check_requirements_str_to_bytes(ini_get('memory_limit'));
            $recommended = check_requirements_str_to_bytes('16M');

            if ($limit < $recommended) {
                return false;
            } else {
                return true;
            }

        case 'register_globals':
            $setting = ini_get('register_globals');
            if (0 == $setting || 'off' == strtolower($setting)
                || 'false' == strtolower($setting)) {
                    return true;
                } else {
                    return false;
                }
        
        case 'post_max_size':
            $setting = check_requirements_str_to_bytes(ini_get('post_max_size'));
            $recommended = check_requirements_str_to_bytes('10M');

            if ($setting < $recommended) {
                return false;
            } else {
                return true;
            }

        case 'upload_max_filesize':
            $setting = check_requirements_str_to_bytes(ini_get('upload_max_filesize'));
            $recommended = check_requirements_str_to_bytes('10M');

            if ($setting < $recommended) {
                return false;
            } else {
                return true;
            }

        case 'apache_gzip':
            return check_requirements_apache_module('mod_gzip');

        case 'apache_deflate':
            return check_requirements_apache_module('mod_deflate');

    }

    return null;
}

/**
 * Check apache modules
 * 
 * @param  string $module 
 * @return bool
 */
function check_requirements_apache_module($module) 
{
    if (function_exists('apache_get_modules')) {
        $modules = apache_get_modules();
        if (in_array($module, $modules)) {
            return true;
        } else {
            return false;
        }
    }
    return null; // apache handler api not found
}

/**
 * Convert php ini short size into bytes
 * 
 * @param  string $val 
 * @return integer
 */
function check_requirements_str_to_bytes($val) {
    $val = trim($val);

    $last = strtolower(substr($val, strlen($val)-1));

    switch ($last) {
        case 'g':
            $val *= 1024;
        case 'm':
            $val *= 1024;
        case 'k':
            $val *= 1024;
    }

    return $val;
}
