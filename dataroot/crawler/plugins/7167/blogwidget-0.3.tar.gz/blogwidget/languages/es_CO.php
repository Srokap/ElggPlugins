<?php
$spanish = array(
/**
 * Blog widget
 */
  'blog:widget:title'=>"Contenidos",
  'blog:widget:description'=>"Este widget mustra el numero de contenidos especificado",
  'blog:widget:default_view'=>"Vista por defecto del widget",
  'blog:widget:default'=>"Por defecto",
  'blog:widget:compact'=>"Compacta"
);
add_translation("es_CO",$spanish);

?>