<?php
$english = array(
/**
 * Blog widget
 */
  'blog:widget:title'=>"Blogs",
  'blog:widget:description'=>"This widget shows the specified number of blogs",
  'blog:widget:default_view'=>"Default widget view",
  'blog:widget:default'=>"Default",
  'blog:widget:compact'=>"Compact"
);
add_translation("en",$english);

?>