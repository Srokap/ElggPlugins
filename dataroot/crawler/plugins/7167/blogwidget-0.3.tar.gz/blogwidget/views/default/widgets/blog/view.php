<?php
/**
 * Elgg blogwidget plugin
 *
 * @package ElggBlogWidget
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Diego Andrés Ramírez <diego@somosmas.org>
 * @copyright Corporación Somos más 2008
 * @link http://www.somosmas.org/
 */

$owner = page_owner_entity();
$limit = 8;

if ($vars['entity']->limit)
$limit = $vars['entity']->limit;

$objects = get_entities("object", "blog", $owner->guid,null,$limit);

$widgets = array();

$widget_view = get_plugin_setting('view','blogwidget');
if(empty($widget_view)){
  $widget_view = "create";
}
foreach($objects as $object){
  $statement = new ElggRiverStatement($owner, "create", $object,$object->time_created);
  $tam = elgg_view("river/object/blog/{$widget_view}", array(
						'statement' => $statement,
                        'time'=>$object->time_created
  ));
  if(!empty($tam)){
    $widgets[] = elgg_view("river/wrapper",array(
									'entry' => $tam,
									'time' => $object->time_created,
									'event' => "create",
									'statement' => $statement 
						));
  }
}
echo elgg_view('river/dashboard',array('river'=>$widgets));

//echo elgg_view_river($owner->guid, $limit);
?>