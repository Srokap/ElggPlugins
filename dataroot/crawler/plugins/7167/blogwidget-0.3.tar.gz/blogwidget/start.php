<?php
/**
 * Elgg blogwidget plugin
 *
 * @package ElggBlogWidget
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Diego Andrés Ramírez <diego@somosmas.org>
 * @copyright Corporación Somos más 2008
 * @link http://www.somosmas.org/
 */

/**
 * Blog initialisation
 *
 * These parameters are required for the event API, but we won't use them:
 *
 * @param unknown_type $event
 * @param unknown_type $object_type
 * @param unknown_type $object
 */
function blogwidget_init(){
  global $CONFIG;
  extend_view("css","style/css");
  
  add_widget_type('blog',elgg_echo('blog:widget:title'), elgg_echo('blog:widget:description'));
  
  register_translations($CONFIG->pluginspath . "blogwidget/languages/");
}
register_elgg_event_handler('init','system','blogwidget_init',1);

?>
