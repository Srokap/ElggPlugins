<?php
/**
 * 
 * @package help
 * @version 0.3.0
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author (basic version) Cash [http://community.elgg.org/pg/profile/costelloc]
 * @author (enhanced version) BogieDE [http://community.elgg.org/pg/profile/BogieDE]
 * @copyright Cach & BogieDE
 * 
 */
 
?>
<div class="contentWrapper">

<?php
$num = elgg_echo('help:overview:0') + 1;
$cnt = 1;

while($cnt < $num)
{
  echo '<div class="overview_tool" id="help'. $cnt .'">';
  echo '<h2>'. elgg_echo('help:overview:'.$cnt.':headline') .'</h2>';
  echo '<p>'. str_replace( "__URL__", $vars['url'], elgg_echo('help:overview:'.$cnt.':text')) .'</p>';
  echo '</div>';
  echo '<a href="#elgg_topbar" ><img src="/mod/help/images/arrow-up.gif" border=0 alt="'. elgg_echo('help:gotop') .'"></a>';
  echo '<br><hr size=1><br>';  
  $cnt++;
}

echo '</div>';
?>