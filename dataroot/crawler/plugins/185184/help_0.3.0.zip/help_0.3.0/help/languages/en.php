<?php

	$english = array(
	
		'help' => "Help",
		
		'help:faq' => "Frequenty Asked Questions",
		'help:overview' => "Overview",
		'help:gotop' => "top",
			
		'help:overview:0' => "4",              // COUNTER
		
		'help:overview:1:headline' => "Dashboard",
		'help:overview:1:text'     => "The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... The Dashboard is ... ",
		
	  'help:overview:2:headline' => "Blogs",
		'help:overview:2:text'     => "The Blogs are ... <br><center><img src='__URL__/mod/help/images/image.jpg'></center>",
		
		'help:overview:3:headline' => "Favorites",
		'help:overview:3:text'     => "The Favorites are ...",
		
		'help:overview:4:headline' => "Groups",
		'help:overview:4:text'     => "The Groups are ...",
		
		
		
    // Sidebar Menu 1 //
    'help:faq:0'            => "4",        // COUNTER
    'help:faq:1:sidebar'    => "General FAQs",
    
    // Sidebar Menu 1 -> Q1
    'help:faq:1:0'          => "3",        // COUNTER
    'help:faq:1:1:headline' => "Why are these general questions?",
    'help:faq:1:1:text'     => "It's, because General questions are important.<br><center><img src='__URL__/mod/help/images/image.jpg'></center>",
    
    // Sidebar Menu 1 -> Q2
    'help:faq:1:2:headline' => "Are these really general questions?",
    'help:faq:1:2:text'     => "Of course, these are the general questions.",
    
    // Sidebar Menu 1 -> Q3
    'help:faq:1:3:headline' => "Why are these general questions?",
    'help:faq:1:3:text'     => "It's, because General questions are important.",
    
    
    // Sidebar Menu 2 //
    'help:faq:2:sidebar'  => "Settings FAQs",
    
    // Sidebar Menu 2 -> Q1
    'help:faq:2:0'          => "3",       // QOUNTER
    'help:faq:2:1:headline' => "Are there settings to be set by the Administrator?",
    'help:faq:2:1:text'     => "Oh yes, there are many settings to be set by the Administrator.",
    
    // Sidebar Menu 2 -> Q2
    'help:faq:2:2:headline' => "What means <i>default settings</i>?",
    'help:faq:2:2:text'     => "The default settings are the standard settings that will be used if you don't change anything.",
    
    // Sidebar Menu 2 -> Q3 3          
    'help:faq:2:3:headline' => "Are there settings for the module <i>help</i>?",
    'help:faq:2:3:text'     => "Well, actually that would be great, but there are no settings existing yet.",
    
    
    // Sidebar Menu 3 //
    'help:faq:3:sidebar'  => "Permission FAQs",
    
    // Sidebar Menu 3 -> Q1
    'help:faq:3:0'          => "3",      // COUNTER
    'help:faq:3:1:headline' => "Does the Admin have special permissions?",
    'help:faq:3:1:text'     => "Oh yes, the Admin has quite a bunch of special permissions.",
    
    // Sidebar Menu 3 -> Q2
    'help:faq:3:2:headline' => "Are there permission levels??",
    'help:faq:3:2:text'     => "Yes, the most popular permission levels are friends, private and public permissions.",
    
    // Sidebar Menu 3 -> Q3 3
    'help:faq:3:3:headline' => "Shall this be the last sample question about the permissions?",
    'help:faq:3:3:text'     => "Oh yes, it is late and I don't want to write a real FAQ ;-)",

    // Sidebar Menu 4 //
    'help:faq:4:sidebar'  => "Test-menu",
    
    // Sidebar Menu 4 -> Q1
    'help:faq:4:0'          => "3",      // COUNTER
    'help:faq:4:1:headline' => "Is this test 1?",
    'help:faq:4:1:text'     => "Oh yes, this ist test one.",
    
    // Sidebar Menu 4 -> Q2
    'help:faq:4:2:headline' => "Is this test 2?",
    'help:faq:4:2:text'     => "Oh yes, this ist test two.",
    
    // Sidebar Menu 4 -> Q3 3
    'help:faq:4:3:headline' => "Is this test 3?",
    'help:faq:4:3:text'     => "Oh yes, this ist test three.",
		
		
		
	);

	add_translation("en",$english);

?>
