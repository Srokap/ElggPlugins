/**
 * 
 * @package help
 * @version 0.3.0
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author (basic version) Cash [http://community.elgg.org/pg/profile/costelloc]
 * @author (enhanced version) BogieDE [http://community.elgg.org/pg/profile/BogieDE]
 * @copyright Cach & BogieDE
 * 
 */
 
--------------------------------------------------------------------------------
* Installation *
Just extract the zip and copy the help directory to the /mod directory of your 
installation. when done, go to the administrator panem and activate the module 
help.

--------------------------------------------------------------------------------
* Konfiguration *
Well there is no real configuration.
You have to edit the language files to configure and fill this module with data.

There are two parts of help: the overview and the FAQ part.
The language file keys are like a new array and these data have to be available:

For the Overview:
	'help:overview:0' => "2",                            // this is the counter of 
	                                                        the items in the overview
	                                                        section
		
		'help:overview:1:headline' => "Dashboard",         // This is the 1st headline
		'help:overview:1:text'     => "The Dashboard is    // This is the 1st help text
		
	  'help:overview:2:headline' => "Blogs",             // This is the 2nd headline
		'help:overview:2:text'     => "The Blogs are ...", // This is the 2nd help text
		

For the FQA:
    'help:faq:0'            => "2",                    // This is the counter for 
                                                          the categories that are 
                                                          displayed on the left 
                                                          sidebar
                                                          
         'help:faq:1:sidebar'    => "FAQ category 1",       // This is the 1st category
                                                               headline
    
         'help:faq:1:0'          => "2",                    // This is the counter for
                                                               the 1st category
                                                          
              'help:faq:1:1:headline' => "question 1?",          // This is the 1st question 
                                                                    in category 1
              'help:faq:1:1:text'     => "answer 1",             // This is the answer 
                                                                    to question 1 in category 1
    
              'help:faq:1:2:headline' => "question 2?",          // This is the 2nd question
                                                                    in category 1
              'help:faq:1:2:text'     => "answer 2",             // This is the answer to 
                                                                    question 2 in category 1
    
  
         'help:faq:2:sidebar'  => "FAQ category 2",         // This is the 1st category
                                                               headline
    
         'help:faq:2:0'          => "3",                    // This is the counter for
                                                               the 1st category
                                                          
              'help:faq:2:1:headline' => "question 1?",          // This is the 1st question 
                                                                    in category 2
              'help:faq:2:1:text'     => "answer 1",             // This is the answer 
                                                                    to question 1 in category 2
    
              'help:faq:2:2:headline' => "question 2?",          // This is the 2nd question
                                                                    in category 2
              'help:faq:2:2:text'     => "answer 2.",            // This is the answer to 
                                                                    question 2 in category 2
    
              'help:faq:2:3:headline' => "question 3?",          // This is the 3rd question
                                                                    in category 2
              'help:faq:2:3:text'     => "answer 3.",            // This is the answer to 
                                                                    question 3 in category 2
    
   .... and so on .....
   
--------------------------------------------------------------------------------
* Special features *
- Images
  Insert Images to the text (FAQ-text and Overview-text) - not the headlines!
  The code for the image would be for example:
     <img src='__URL__/mod/help/images/image.jpg'>

  The __URL__ (2 times the underscore on each side) will be replaced by the content
  of the $vars['url'] variable.
  This was necessary, because the $vars variable is empty within the language files.

--------------------------------------------------------------------------------
* Layout *
Well this might not be the nicest layout, but it should work.
Maybe I'll engance the layout a little in future, but I might be the best anyway
if you adapt it to your layout and whishes.

--------------------------------------------------------------------------------
* Hints *
For me it worked best to directly edit the en.php language file and to make the
translation with the translationbrowser (available on the elgg site as community
plugin).
