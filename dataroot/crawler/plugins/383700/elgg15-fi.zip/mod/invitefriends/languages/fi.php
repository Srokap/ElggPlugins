<?php

// Luotu käännösselaimella. 

$finnish = array( 
	 'friends:invite'  =>  "Kutsu ystäviä" , 
	 'invitefriends:introduction'  =>  "Kutsuaksesi ystäviä omaan verkostoosi, kirjoita heidän sähköpostiosoitteensa alapuolelle (yksi per rivi):" , 
	 'invitefriends:message'  =>  "Kirjoita viesti, jonka ystäväsi saavat kutsun yhteydessä:" , 
	 'invitefriends:subject'  =>  "Kutsu liittyä %s-yhteisöön" , 
	 'invitefriends:success'  =>  "Ystäväsi kutsuttiin." , 
	 'invitefriends:failure'  =>  "Ystäviäsi ei voitu kutsua." , 
	 'invitefriends:message:default'  =>  "Hei,

Haluaisin kutsua sinut liittymään verkostooni %s –ympäristössä. " , 
	 'invitefriends:email'  =>  "
Hei,

Haluaisin kutsua sinut liittymään verkostooni %s –ympäristössä. Klikkaa seuraavaa linkki liittyäksesi palveluun: %s"
); 

add_translation('fi', $finnish); 

?>