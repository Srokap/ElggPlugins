<?php

// Luotu käännösselaimella. 

$finnish = array( 
	 'mine'  =>  "Minun" , 
	 'filter'  =>  "Suodatin" , 
	 'riverdashboard:useasdashboard'  =>  "Korvaa oletuskojelauta aktiivisuussyötteillä?" , 
	 'activity'  =>  "Toiminta" , 
	 'sitemessages:announcements'  =>  "Sivuston uutiset" , 
	 'sitemessages:posted'  =>  "Lähetetty" , 
	 'sitemessages:river:created'  =>  "Sivuston ylläpitäjä, %s," , 
	 'sitemessages:river:create'  =>  "lähetti uuden sivustonlaajuisen viestin" , 
	 'sitemessages:add'  =>  "Lisää sivustonlaajuinen viesti syötesivulle" , 
	 'sitemessage:deleted'  =>  "Sivuston viesti poistettu" , 
	 'river:widget:noactivity'  =>  "Ei löytynyt toimintaa." , 
	 'river:widget:title'  =>  "Toiminta" , 
	 'river:widget:description'  =>  "Näytä viimeisin toimintasi." , 
	 'river:widget:title:friends'  =>  "Ystävien toiminta" , 
	 'river:widget:description:friends'  =>  "Näytä mitä ystäväsi puuhaavat." , 
	 'river:widgets:friends'  =>  "Ystävät" , 
	 'river:widgets:mine'  =>  "Minun" , 
	 'river:widget:label:displaynum'  =>  "Näytettävien kohteiden määrä:" , 
	 'river:widget:type'  =>  "Minkä syötevirran haluat nähdä? Sen, joka näyttää oman toimintasi vai sen, joka näyttää ystäviesi toiminnan?" , 
	 'item:object:sitemessage'  =>  "Sivuston viestit"
); 

add_translation('fi', $finnish); 

?>