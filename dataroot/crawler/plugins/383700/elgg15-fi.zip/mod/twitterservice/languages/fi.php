<?php

// Luotu käännösselaimella. 

$finnish = array( 
	 'twitterservice'  =>  "Twitter-palvelu" , 
	 'twitterservice:postwire'  =>  "Haluatko lähettää julkiset viestit pikaviestimeen Twitteristä?" , 
	 'twitterservice:twittername'  =>  "Twitter-käyttäjänimi" , 
	 'twitterservice:twitterpass'  =>  "Twitter-salasana"
); 

add_translation('fi', $finnish); 

?>