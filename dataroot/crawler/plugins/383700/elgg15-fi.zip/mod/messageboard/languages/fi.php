<?php

// Luotu käännösselaimella. 

$finnish = array( 
	 'messageboard:board'  =>  "Ilmoitustaulu" , 
	 'messageboard:messageboard'  =>  "ilmoitustaulu" , 
	 'messageboard:viewall'  =>  "Näytä kaikki" , 
	 'messageboard:postit'  =>  "Lähetä " , 
	 'messageboard:history'  =>  "Historia" , 
	 'messageboard:none'  =>  "Tällä ilmoitustaululla ei ole vielä mitään" , 
	 'messageboard:num_display'  =>  "Näytettävien viestien määrä" , 
	 'messageboard:desc'  =>  "Tämä on ilmoitustaulu, jonka voit lisätä profiilisivullesi ja muut käyttäjät voivat jättää viestejä." , 
	 'messageboard:user'  =>  "%s:n ilmoitustaululle" , 
	 'messageboard:river:annotate'  =>  "%s:n ilmoitustaululla on uusi viesti." , 
	 'messageboard:river:create'  =>  "%s lisäsi ilmoitustauluvimpaimen." , 
	 'messageboard:river:update'  =>  "%s päivitti ilmoitustauluvimpaimen." , 
	 'messageboard:river:added'  =>  "%s lähetti viestin" , 
	 'messageboard:river:messageboard'  =>  "ilmoitustaululle" , 
	 'messageboard:posted'  =>  "Lähetit viestin ilmoitustaululle." , 
	 'messageboard:deleted'  =>  "Poistit viestin." , 
	 'messageboard:email:subject'  =>  "Sinulla on uusi viesti ilmoitustaulullasi." , 
	 'messageboard:email:body'  =>  "%s on jättänyt sinulle uuden viestin ilmoitustaulullesi. Siinä lukee: 

			
%s


Katsoaksesi ilmoitustaulusi viestejä napsauta linkkiä:

%s

Nähdäksesi %s:n profiilin, napsauta linkkiä:

%s

Et voi vastata tähän sähköpostiin." , 
	 'messageboard:blank'  =>  "Sinun täytyy kirjoittaa viestikenttään jotain, jotta se voidaan tallentaa." , 
	 'messageboard:notfound'  =>  "Määriteltyä kohdetta ei löytynyt." , 
	 'messageboard:notdeleted'  =>  "Viestiä ei voitu poistaa." , 
	 'messageboard:somethingwentwrong'  =>  "Jokin meni pieleen tallennettaessa viestiä, varmista että kirjoitit viestin." , 
	 'messageboard:failure'  =>  "Tapahtui odottamaton virhe lisättäessä viestiä. Yritä uudelleen."
); 

add_translation('fi', $finnish); 

?>