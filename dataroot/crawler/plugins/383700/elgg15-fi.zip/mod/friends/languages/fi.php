<?php

// Luotu käännösselaimella. 

$finnish = array( 
	 'friends:widget:description'  =>  "Näyttää joitakin ystäviäsi."
); 

add_translation('fi', $finnish); 

?>