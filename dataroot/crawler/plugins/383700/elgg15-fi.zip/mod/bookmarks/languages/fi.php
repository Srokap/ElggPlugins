<?php

// Luotu Käännösselaimella. 

$finnish = array( 
	 'bookmarks'  =>  "Kirjanmerkit" , 
	 'bookmarks:add'  =>  "Lisää kirjanmerkki" , 
	 'bookmarks:read'  =>  "Kirjanmerkityt kohteet" , 
	 'bookmarks:friends'  =>  "Kavereiden kirjanmerkit" , 
	 'bookmarks:everyone'  =>  "Kaikki sivuston kirjanmerkit" , 
	 'bookmarks:this'  =>  "Lisää kirjanmerkiksi" , 
	 'bookmarks:bookmarklet'  =>  "Lataa Bookmarklet-sovellus" , 
	 'bookmarks:inbox'  =>  "Kirjanmerkit-kansio" , 
	 'bookmarks:more'  =>  "Enemmän" , 
	 'bookmarks:shareditem'  =>  "Kirjanmerkitty kohde" , 
	 'bookmarks:with'  =>  "Jaa käyttäjille" , 
	 'bookmarks:new'  =>  "Uusi kirjanmerkki" , 
	 'bookmarks:via'  =>  "kirjanmerkkien kautta" , 
	 'bookmarks:address'  =>  "Kirjanmerkin lähteen osoite" , 
	 'bookmarks:delete:confirm'  =>  "Haluatko varmasti poistaa tämän lähteen?" , 
	 'bookmarks:numbertodisplay'  =>  "Näytettävien kirjanmerkkien määrä" , 
	 'bookmarks:shared'  =>  "Kirjanmerkitty" , 
	 'bookmarks:visit'  =>  "Avaa linkki" , 
	 'bookmarks:recent'  =>  "Viimeisimmät kirjanmerkit" , 
	 'bookmarks:river:created'  =>  "%s kirjanmerkitty" , 
	 'bookmarks:river:annotate'  =>  "kommentoi tätä kirjanmerkkiä" , 
	 'bookmarks:river:item'  =>  "Kohde" , 
	 'item:object:bookmarks'  =>  "Kirjanmerkityt kohteet" , 
	 'bookmarks:widget:description'  =>  "Tämä vimpain on suunniteltu sinun kojelautaasi ja näyttää sinulle viimeisimmät kohteesi kirjanmerkkien kansiossa." , 
	 'bookmarks:bookmarklet:description'  =>  "Boorkmarklet-sovelluksen avulla voit lisätä minkä tahansa www-sivun kirjanmerkiksi ja jakaa sen kaveriesi kanssa tai tallentaa sen ainoastaan itsellesi. Käyttääksesi sitä vedä alla oleva painike selaimesi linkkivalikkoon:" , 
	 'bookmarks:bookmarklet:descriptionie'  =>  "Jos käytät Internet Exploreria täytyy sinun klikata hiiren oikealla painikkeella Bookmarklet-sovelluksen kuvaketta ja sieltä vaihtoehto \"lisää suosikkeihin\" ja tämän jälkeen valita Linkit-palkki." , 
	 'bookmarks:bookmarklet:description:conclusion'  =>  "Silloin voit tallentaa minkä tahansa sivun, jolla vierailet vain klikkaamalla sitä. " , 
	 'bookmarks:save:success'  =>  "Kohde lisättiin kirjanmerkkeihin." , 
	 'bookmarks:delete:success'  =>  "Kirjanmerkitty kohde poistettiin." , 
	 'bookmarks:save:failed'  =>  "Kirjanmerkittyä kohdetta ei voitu tallentaa. Yritä uudelleen." , 
	 'bookmarks:delete:failed'  =>  "Kirjanmerkittyä kohdetta ei voitu poistaa. Yritä uudelleen."
); 

add_translation('fi', $finnish); 

?>