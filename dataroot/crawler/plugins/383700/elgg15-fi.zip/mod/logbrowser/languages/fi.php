<?php

// Luotu käännösselaimella. 

$finnish = array( 
	 'logbrowser'  =>  "Lokiselain" , 
	 'logbrowser:browse'  =>  "Selaa systeemilokia" , 
	 'logbrowser:search'  =>  "Suodatetut tulokset" , 
	 'logbrowser:user'  =>  "Käyttäjänimi jonka mukaan haluat selata" , 
	 'logbrowser:starttime'  =>  "Alkamisaika (esimerkiksi \"viime maanantai\", \"tunti sitten\")" , 
	 'logbrowser:endtime'  =>  "Loppumisaika" , 
	 'logbrowser:explore'  =>  "Tutki lokia"
); 

add_translation('fi', $finnish); 

?>