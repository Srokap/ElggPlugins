<?php

// Luotu käännösselaimella. 

$finnish = array( 
	 'blog'  =>  "Blogi" , 
	 'blogs'  =>  "Blogit" , 
	 'blog:user'  =>  "Käyttäjän %s blogi" , 
	 'blog:user:friends'  =>  "Käyttäjän %s kavereiden blogit" , 
	 'blog:your'  =>  "Sinun blogisi" , 
	 'blog:posttitle'  =>  "Käyttäjän %s blogi: %s" , 
	 'blog:friends'  =>  "Kavereiden blogit" , 
	 'blog:yourfriends'  =>  "Kaveriesi viimeisimmät blogit" , 
	 'blog:everyone'  =>  "Kaikki sivuston blogit" , 
	 'blog:newpost'  =>  "Uusi blogiviesti" , 
	 'blog:via'  =>  "blogista" , 
	 'blog:read'  =>  "Lue blogia" , 
	 'blog:addpost'  =>  "Kirjoita blogiviesti" , 
	 'blog:editpost'  =>  "Muokkaa blogiviestiä" , 
	 'blog:text'  =>  "Blogin teksti" , 
	 'blog:strapline'  =>  "%s" , 
	 'item:object:blog'  =>  "Blogiviestit" , 
	 'blog:never'  =>  "ei koskaan" , 
	 'blog:preview'  =>  "Esikatsele" , 
	 'blog:draft:save'  =>  "Tallenna luonnos" , 
	 'blog:draft:saved'  =>  "Luonnos viimeksi tallennettu" , 
	 'blog:comments:allow'  =>  "Salli kommentit" , 
	 'blog:preview:description'  =>  "Tämä on tallentamaton esikatselunäkymä blogiviestistä." , 
	 'blog:preview:description:link'  =>  "Jatkaaksesi muokkausta tai tallentaaksi viestin klikkaa tästä." , 
	 'blog:river:created'  =>  "%s kirjoitti" , 
	 'blog:river:updated'  =>  "%s päivitti" , 
	 'blog:river:posted'  =>  "%s lähetti" , 
	 'blog:river:create'  =>  "uuden blogiviestin otsikolla" , 
	 'blog:river:update'  =>  "blogiviestin otsikolla " , 
	 'blog:river:annotate'  =>  "kommentin blogiviestiin" , 
	 'blog:posted'  =>  "Blogiviestisi lähetettiin onnistuneesti." , 
	 'blog:deleted'  =>  "Blogiviestisi on poistettu." , 
	 'blog:error'  =>  "Jokin meni vikaan. Yritä uudelleen." , 
	 'blog:save:failure'  =>  "Blogiviestiäsi ei voitu tallentaa. Yritä uudelleen." , 
	 'blog:blank'  =>  "Sinun täytyy täyttää sekä otsikko että viestikenttä ennen kuin voit postittaa viestin." , 
	 'blog:notfound'  =>  "Haluamaasi blogiviestiä ei löydetty." , 
	 'blog:notdeleted'  =>  "Blogiviestiä ei voitu poistaa."
); 

add_translation('fi', $finnish); 

?>