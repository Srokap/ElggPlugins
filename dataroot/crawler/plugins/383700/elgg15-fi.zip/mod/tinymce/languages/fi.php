<?php

// Luotu käännösselaimella. 

$finnish = array( 
	 'tinymce:remove'  =>  "Lisää/Poista editori"
); 

add_translation('fi', $finnish); 

?>