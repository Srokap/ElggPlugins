<?php

// Luotu käännösselaimella. 

$finnish = array( 
	 'email:validate:subject'  =>  "%s, vahvista sähköpostiosoitteesi." , 
	 'email:validate:body'  =>  "Hei %s, 

Ole hyvä ja vahvista sähköpostiosoitteesi klikkaamalla alla olevaa linkkiä:

%s

" , 
	 'email:validate:success:subject'  =>  "Sähköpostiosoite vahvistettiin %s.
" , 
	 'email:validate:success:body'  =>  "Hei %s, 

Sähköpostiosoitteesi vahvistettiin onnistuneesti!" , 
	 'email:confirm:success'  =>  "Sähköpostiosoitteesi vahvistettiin." , 
	 'email:confirm:fail'  =>  "Sähköpostiosoitettasi ei voitu varmistaa..." , 
	 'uservalidationbyemail:registerok'  =>  "Ottaaksesi käyttöön tilisi, klikkaa sähköpostitse lähettämäämme linkkiä ja vahvista sähköpostiosoitteesi."
); 

add_translation('fi', $finnish); 

?>