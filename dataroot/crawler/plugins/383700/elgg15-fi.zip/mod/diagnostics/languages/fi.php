<?php

// Luotu käännösselaimella. 

$finnish = array( 
	 'diagnostics'  =>  "Järjestelmän diagnostiikka" , 
	 'diagnostics:description'  =>  "Seuraava diagnostiikkaraportti on hyödyllinen Elggin virheiden jäljityksessä ja se tulisi liittää kaikkiin lähetettäviin ongelmaraportteihin." , 
	 'diagnostics:download'  =>  "Lataa .txt" , 
	 'diagnostics:header'  =>  "========================================================================
Elggin Diagnostiikkaraportti
Luotu: %s, luonut: %s
========================================================================
			
" , 
	 'diagnostics:report:basic'  =>  "Elgg-julkaisu: %s, versio: %s

------------------------------------------------------------------------" , 
	 'diagnostics:report:php'  =>  "PHP info:
%s
------------------------------------------------------------------------" , 
	 'diagnostics:report:plugins'  =>  "Asennetut liitännäiset ja yksityiskohdat:

%s
------------------------------------------------------------------------" , 
	 'diagnostics:report:md5'  =>  "Asennetut tiedostot ja tarkistussummat:

%s
------------------------------------------------------------------------" , 
	 'diagnostics:report:globals'  =>  "Globaalit muuttujat:

%s
------------------------------------------------------------------------"
); 

add_translation('fi', $finnish); 

?>