<?php

// Luotu käännösselaimella. 

$finnish = array( 
	 'friends:all'  =>  "Kaikki ystävät" , 
	 'notifications:subscriptions:personal:description'  =>  "Vastaanota ilmoituksia kun sisältöäsi päivitetään" , 
	 'notifications:subscriptions:personal:title'  =>  "Henkilökohtaiset ilmoitukset" , 
	 'notifications:subscriptions:collections:title'  =>  "Valitse ystäväkokoelmat" , 
	 'notifications:subscriptions:collections:description'  =>  "Valitaksesi ystäväkokoelmien jäsenten asetukset käytä alla olevia kuvakkeita. Tämä vaikuttaa valittuihin käyttäjiin ilmoitusasetuksissa sivun alareunassa." , 
	 'notifications:subscriptions:collections:edit'  =>  "Muokataksesi ystäväkokoelmia napsauta tästä." , 
	 'notifications:subscriptions:changesettings'  =>  "Ilmoitukset" , 
	 'notifications:subscriptions:changesettings:groups'  =>  "Ryhmäilmoitukset" , 
	 'notification:method:email'  =>  "Sähköposti" , 
	 'notifications:subscriptions:title'  =>  "Käyttäjäkohtaiset ilmoitukset" , 
	 'notifications:subscriptions:description'  =>  "Saadaksesi ilmoituksia ystäviltäsi kun he luovat uutta sisältöä, etsi heidät listalta ja valitse haluamasi ilmoitusmenetelmä." , 
	 'notifications:subscriptions:groups:description'  =>  "Saadaksesi ilmoituksia päivityksistä ryhmissä joiden jäsenenä olet, valitse ryhmät alapuolelta sekä haluamasi ilmoitusmenetelmä." , 
	 'notifications:subscriptions:success'  =>  "Ilmoitusasetukset tallennettiin."
); 

add_translation('fi', $finnish); 

?>