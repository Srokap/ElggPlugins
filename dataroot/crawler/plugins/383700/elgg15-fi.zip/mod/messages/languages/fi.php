<?php

// Luotu käännösselaimella. 

$finnish = array( 
	 'messages'  =>  "Viestit" , 
	 'messages:back'  =>  "takaisin viesteihin" , 
	 'messages:user'  =>  "Saapuneet-kansio" , 
	 'messages:sentMessages'  =>  "Lähetetyt viestit" , 
	 'messages:posttitle'  =>  "%s:n viestit: %s" , 
	 'messages:inbox'  =>  "Saapuneet" , 
	 'messages:send'  =>  "Lähetä viesti" , 
	 'messages:sent'  =>  "Lähetetyt viestit" , 
	 'messages:message'  =>  "Viesti" , 
	 'messages:title'  =>  "Otsikko" , 
	 'messages:to'  =>  "Vastaanottaja" , 
	 'messages:from'  =>  "Lähettäjä" , 
	 'messages:fly'  =>  "Lähetä" , 
	 'messages:replying'  =>  "Viesti vastauksena" , 
	 'messages:sendmessage'  =>  "Lähetä viesti" , 
	 'messages:compose'  =>  "Lähetä viesti" , 
	 'messages:sentmessages'  =>  "Lähetetyt viestit" , 
	 'messages:recent'  =>  "Viimeisimmät viestit" , 
	 'messages:original'  =>  "Alkuperäinen viesti" , 
	 'messages:yours'  =>  "Viestisi" , 
	 'messages:answer'  =>  "Vastaa" , 
	 'messages:toggle'  =>  "Valitse kaikki" , 
	 'messages:markread'  =>  "Merkitse luetuksi" , 
	 'messages:new'  =>  "Uusi viesti" , 
	 'notification:method:site'  =>  "Sivusto" , 
	 'messages:error'  =>  "Ongelma tallennettaessa viestiä. Yritä uudelleen." , 
	 'item:object:messages'  =>  "Viestit" , 
	 'messages:posted'  =>  "Viestisi lähetettiin onnistuneesti." , 
	 'messages:deleted'  =>  "Viestisi poistettiin. " , 
	 'messages:markedread'  =>  "Viestisi merkittiin luetuiksi." , 
	 'messages:email:subject'  =>  "Sinulla on uusi viesti!" , 
	 'messages:email:body'  =>  "Sinulla on uusi viesti henkilöltä %s. Siinä lukee:

%s

Lukeaksesi viestin klikkaa tästä:

%s

Lähettääksesi %s:lle viestin, klikkaa tästä:

%s

Tähän viestiin ei voi vastata." , 
	 'messages:blank'  =>  "Sinun täytyy kirjoittaa viestiin jotain ennen kuin se voidaan tallentaa." , 
	 'messages:notfound'  =>  "Määriteltyä viestiä ei löydetty." , 
	 'messages:notdeleted'  =>  "Tätä viestiä ei voitu poistaa." , 
	 'messages:nopermission'  =>  "Sinulla ei ole oikeutta poistaa tätä viestiä." , 
	 'messages:nomessages'  =>  "Näytettäviä viestejä ei ole." , 
	 'messages:user:nonexist'  =>  "Emme löytäneet vastaanottajaa käyttäjälistalta."
); 

add_translation('fi', $finnish); 

?>