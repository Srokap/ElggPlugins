<?php

// Luotu käännösselaimella. 

$finnish = array( 
	 'thewire'  =>  "Pikaviestin" , 
	 'thewire:user'  =>  "%s:n pikaviestit" , 
	 'thewire:posttitle'  =>  "%s:n lisäämät pikaviestit: %s" , 
	 'thewire:everyone'  =>  "Kaikki pikaviestit" , 
	 'thewire:read'  =>  "Pikaviestit" , 
	 'thewire:strapline'  =>  "%s" , 
	 'thewire:add'  =>  "Lähetä pikaviesti" , 
	 'thewire:text'  =>  "Merkinnät pikaviestimessä" , 
	 'thewire:reply'  =>  "Vastaa" , 
	 'thewire:via'  =>  "kautta" , 
	 'thewire:wired'  =>  "Lähetti pikaviestimeen" , 
	 'thewire:charleft'  =>  "merkkiä jäljellä" , 
	 'item:object:thewire'  =>  "Pikaviestit" , 
	 'thewire:notedeleted'  =>  "viesti poistettu" , 
	 'thewire:doing'  =>  "Mitä teet? Kerro se kaikille pikaviestillä:" , 
	 'thewire:newpost'  =>  "Uusi pikaviesti" , 
	 'thewire:addpost'  =>  "Lähetä pikaviestimeen" , 
	 'thewire:river:created'  =>  "%s lähetti" , 
	 'thewire:river:create'  =>  "pikaviestimeen." , 
	 'thewire:sitedesc'  =>  "Tämä vimpain näyttää viimeisimmät viestit pikaviestimessä" , 
	 'thewire:yourdesc'  =>  "Tämä vimpain näyttää viimeisimmät lähettämäsi viestit pikaviestimeen" , 
	 'thewire:friendsdesc'  =>  "Tämä vimpain näyttää viimeisimmät ystäviesi lähettämät viestit pikaviestimeen" , 
	 'thewire:friends'  =>  "Ystäväsi pikaviestit" , 
	 'thewire:num'  =>  "Näytettävien viestien määrä" , 
	 'thewire:posted'  =>  "Viestisi lähetettiin onnistuneesti pikaviestimeen." , 
	 'thewire:deleted'  =>  "Viestisi poistettiin." , 
	 'thewire:blank'  =>  "Sinun pitää kirjoittaa tekstikenttään jotain ennen tallennusta." , 
	 'thewire:notfound'  =>  "Määriteltyä pikaviestiä ei löytynyt." , 
	 'thewire:notdeleted'  =>  "Pikaviestiä ei voitu poistaa." , 
	 'thewire:smsnumber'  =>  "SMS-puhelinnumerosi, jos eroaa matkapuhelinnumerostasi (matkapuhelinnumero pitää asettaa julkiseksi että sitä voidaan käyttää pikaviestimessä). Kaikki puhelinnumerot pitää olla kansainvälisessä muodossa." , 
	 'thewire:channelsms'  =>  "Numero johon SMS-viestit lähetetään on: %s"
); 

add_translation('fi', $finnish); 

?>