<?php

// Luotu käännösselaimella. 

$finnish = array( 
	 'expages'  =>  "Ulkoiset sivut" , 
	 'expages:frontpage'  =>  "Etusivu" , 
	 'expages:about'  =>  "Tietoa" , 
	 'expages:terms'  =>  "Käyttöehdot" , 
	 'expages:privacy'  =>  "Tietosuoja" , 
	 'expages:analytics'  =>  "Analytiikka" , 
	 'expages:contact'  =>  "Yhteystiedot" , 
	 'expages:nopreview'  =>  "Ei esikatselunäkymää saatavilla" , 
	 'expages:preview'  =>  "Esikatselu" , 
	 'expages:notset'  =>  "Tätä sivua ei ole vielä määritelty." , 
	 'expages:lefthand'  =>  "Vasemman reunan tietopalkki" , 
	 'expages:righthand'  =>  "Oikean reunan tietopalkki" , 
	 'expages:addcontent'  =>  "Voit lisätä tänne sisältöä ylläpitäjän työkaluilla. Etsi ulkoiset sivut -linkki ylläpitäjän käyttöliittymästä." , 
	 'item:object:front'  =>  "Etusivun elementit" , 
	 'expages:posted'  =>  "Sivu tallennettiin onnistuneesti." , 
	 'expages:deleted'  =>  "Sivu poistettiin onnistuneesti." , 
	 'expages:deleteerror'  =>  "Virhe poistettaessa vanhaa sivua" , 
	 'expages:error'  =>  "Ongelma havaittu. Yritä uudelleen ja jos ongelma jatkuu, ota yhteyttä ylläpitäjään"
); 

add_translation('fi', $finnish); 

?>