<?php

// Luotu Käännösselaimella. 

$finnish = array( 
	 'item:object:reported_content'  =>  "Raportoidut kohteet" , 
	 'reportedcontent'  =>  "Asiaton sisältö" , 
	 'reportedcontent:this'  =>  "Ilmoita asiattomasta sisällöstä" , 
	 'reportedcontent:none'  =>  "Ei raportoitua sisältöä" , 
	 'reportedcontent:report'  =>  "Ilmoita asiattomasta sisällöstä" , 
	 'reportedcontent:title'  =>  "Sivun otsikko" , 
	 'reportedcontent:deleted'  =>  "Asiaton sisältö on poistettu" , 
	 'reportedcontent:notdeleted'  =>  "Tätä raporttia ei voitu poistaa" , 
	 'reportedcontent:delete'  =>  "Poista" , 
	 'reportedcontent:areyousure'  =>  "Oletko varma, että haluat poistaa?" , 
	 'reportedcontent:archive'  =>  "Arkistoi" , 
	 'reportedcontent:archived'  =>  "Tämä raportti on arkistoitu" , 
	 'reportedcontent:visit'  =>  "Avaa raportoitu sisältö" , 
	 'reportedcontent:by'  =>  "Tämän ilmoitti " , 
	 'reportedcontent:objecttitle'  =>  "Kohteen otsikko" , 
	 'reportedcontent:objecturl'  =>  "Kohteen osoite" , 
	 'reportedcontent:reason'  =>  "Raportoinnin syy" , 
	 'reportedcontent:description'  =>  "Miksi sisältö on mielestäsi asiaton?" , 
	 'reportedcontent:address'  =>  "Kohteen sijainti" , 
	 'reportedcontent:success'  =>  "Raporttisi lähetettiin sivuston ylläpitäjälle" , 
	 'reportedcontent:failing'  =>  "Raporttiasi ei voitu lähettää" , 
	 'reportedcontent:moreinfo'  =>  "Lisää tietoa" , 
	 'reportedcontent:failed'  =>  "Sisällön raportointi epäonnistui." , 
	 'reportedcontent:notarchived'  =>  "Tätä raporttia ei voitu arkistoida"
); 

add_translation('fi', $finnish); 

?>