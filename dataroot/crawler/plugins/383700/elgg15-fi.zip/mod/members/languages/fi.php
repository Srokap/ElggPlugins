<?php

// Luotu käännösselaimella. 

$finnish = array( 
	 'members:members'  =>  "Sivuston jäsenet" , 
	 'members:online'  =>  "Jäsenet jotka ovat juuri nyt aktiivisia" , 
	 'members:active'  =>  "sivuston jäsentä" , 
	 'members:searchtag'  =>  "Jäsenten etsintä tagien perusteella" , 
	 'members:searchname'  =>  "Jäsenten etsintä nimen perusteella"
); 

add_translation('fi', $finnish); 

?>