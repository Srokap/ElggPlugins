<?php
 /**
 *	Elgg - Discus wrapper plugin
 *	This plugin allows guests to post their comments to your elgg sites, with out having an account
 *	Author : Sarath C | Team Webgalli
 *	Team Webgalli | Elgg developers and consultants
 *	Mail : info@webgalli.com
 *	Web	: http://webgalli.com | http://plugingalaxy.com
 *	Skype : 'team.webgalli'
 *	@package Elgg-webgalli_disqus
 * 	Plugin info : Disqus comments for Elgg
 *	Licence : GNU2
 *	Copyright : Team Webgalli 2011-2015
 */
	$english = array(
	
			'webgalli_disqus:shortname' => "Enter your forum shorname as you registered at Disquss",
			'webgalli_disqus:shortname_link' => "To use this service you need to register <a href='http://disqus.com' target='_blank'>here</a>",
	
	);
					
	add_translation("en",$english);

?>