<?php

 /**
 *	Elgg - Discus wrapper plugin
 *	This plugin allows guests to post their comments to your elgg sites, with out having an account
 *	Author : Sarath C | Team Webgalli
 *	Team Webgalli | Elgg developers and consultants
 *	Mail : info@webgalli.com
 *	Web	: http://webgalli.com | http://plugingalaxy.com
 *	Skype : 'team.webgalli'
 *	@package Elgg-webgalli_disqus
 * 	Plugin info : Disqus comments for Elgg
 *	Licence : GNU2
 *	Copyright : Team Webgalli 2011-2015
 */
	function webgalli_discus_init(){
	
	}
	
	// Initialise log browser
	register_elgg_event_handler('init','system','webgalli_discus_init');
?>