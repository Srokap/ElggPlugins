<?php

admin_gatekeeper();
//action_gatekeeper();

$user_guid = get_input('user');
$user = get_entity($user_guid);

$perform = get_input('perform');

if ($user instanceof ElggUser) {
    if ($perform == 'grant') {
        $user->editor = true;
        system_message(elgg_echo('hypeApprove:editorgranted'));
        $subject = elgg_echo('hypeApprove:editorgranted:notify:subject');
        $message = elgg_echo('hypeApprove:editorgranted:notify:message');
        notify_user($user->guid, get_loggedin_user()->guid, $subject, $message);
    } else if ($perform == 'revoke') {
        $user->editor = false;
        system_message(elgg_echo('hypeApprove:editorrevoked'));
        $subject = elgg_echo('hypeApprove:editorrevoked:notify:subject');
        $message = elgg_echo('hypeApprove:editorrevoked:notify:message');
        notify_user($user->guid, get_loggedin_user()->guid, $subject, $message);
    } else {
        register_error(elgg_echo('hypeApprove:actionnotdefined'));
    }
} else {
    register_error(elgg_echo('hypeApprove:actionnotdefined'));
}

forward($_SERVER['HTTP_REFERER']);
?>
