<?php

gatekeeper();
action_gatekeeper();

if (canApprove ()) {
    $access_status = access_get_show_hidden_status();
    access_show_hidden_entities(true);

    $entity_guid = get_input('id');
    $entity = get_entity($entity_guid);

    if (!$entity instanceof ElggUser) {
        global $CONFIG;
        $user = get_entity($entity->owner_guid);
        $akismet = new Akismet($CONFIG->site->url, get_plugin_setting('enable_akismet_key'));
        $akismet->setCommentAuthor($user->name);
        $akismet->setCommentAuthorEmail($user->email);
        if (!$user_url = $user->website) {
            if (!$user_url = $user->www) {
                $user_url = $user->getURL();
            }
        }
        $akismet->setCommentAuthorURL($user_url);
        $content = $object->title;
        $content .= $object->description;
        $metadata .= get_metadata_for_entity($entity->guid);
        if (!empty($metadata)) {
            foreach ($metadata as $ref => $meta) {
                if (!is_array($meta)) {
                    $content .= $meta;
                } else {
                    $content .= implode(', ', $meta);
                }
            }
        }
        $akismet->setCommentContent($content);
        $akismet->setPermalink($entity->getURL());
        $akismet->submitSpam();

        $entity->delete();

        global $CONFIG;
        $message = sprintf(elgg_echo('hypeApprove:itemdeleted:message'), $entity->title);
        notify_user($entity->owner_guid, $CONFIG->site_guid, elgg_echo('hypeApprove:itemdeleted:subject'), $message);
        $entity->delete();
    }
    access_show_hidden_entities($access_status);
} else {
    register_error(elgg_echo('hypeApprove:noprivileges'));
}

forward($_SERVER['HTTP_REFERER']);
?>
