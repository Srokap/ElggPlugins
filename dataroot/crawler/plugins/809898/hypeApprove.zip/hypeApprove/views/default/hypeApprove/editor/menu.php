<?php

admin_gatekeeper();

$ts = time();
$token = generate_action_token($ts);

if (!$vars['entity']->editor) {
    echo elgg_view("output/confirmlink", array(
        'href' => $vars['url'] . 'action/hypeApprove/geneditor?perform=grant&user=' . $vars['entity']->getGUID() . '&__elgg_token=' . $token . '&__elgg_ts=' . $ts,
        'text' => elgg_echo('hypeApprove:granteditor'),
        'confirm' => sprintf(elgg_echo('hypeApprove:granteditor:confirm'), $vars['entity']->name),
    ));
} else {
    echo elgg_view("output/confirmlink", array(
        'href' => $vars['url'] . 'action/hypeApprove/geneditor?perform=revoke&user=' . $vars['entity']->getGUID() . '&__elgg_token=' . $token . '&__elgg_ts=' . $ts,
        'text' => elgg_echo('hypeApprove:revokeeditor'),
        'confirm' => sprintf(elgg_echo('hypeApprove:revokeeditor:confirm'), $vars['entity']->name),
    ));
}
?>
