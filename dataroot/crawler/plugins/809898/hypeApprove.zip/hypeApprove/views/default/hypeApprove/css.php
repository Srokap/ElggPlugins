.admin_icon a.icon img {
padding:1px;
border:1px solid <?php echo $maincolor ?>;
}

.editor_icon a.icon img {
padding:1px;
border:1px solid <?php echo $mailcolor2 ?>;
}

.pending_value_reason {
color:<?php echo $maincolor2 ?>;
font-weight:bold;
font-size:1.1em;
}

.pending_value_title, .pending_value_name, .pending_value_container {
padding-left:10px;
font-weight:bold;
}

.pending_value_description {
font-style:italic;
}

.buttons .button {
float:left;
margin-right:10px;
}