<?php
$entity = $vars['entity'];
$view_hidden = $vars['view_hidden'];

if ($entity->subtype) {
    $entity_type = $entity->getSubtype();
} else {
    $entity_type = $entity->getType();
}

if ($entity->disable_reason)
    $details['reason'] = array('name' => elgg_echo('hypeApprove:pending:reason'), 'value' => $entity_type . ' ' . $entity->disable_reason);
if ($entity->title)
    $details['title'] = array('name' => elgg_echo('hypeApprove:pending:title'), 'value' => $entity->title);
if ($entity->name)
    $details['name'] = array('name' => elgg_echo('hypeApprove:pending:name'), 'value' => $entity->name);
//if ($entity->container_guid)
//    $details['container'] = array('name' => elgg_echo('hypeApprove:pending:container'), 'value' => get_entity($entity->container_guid)->title);
if ($entity->description)
    $details['description'] = array('name' => elgg_echo('hypeApprove:pending:description'), 'value' => elgg_get_excerpt($entity->description, 500));

$icon = elgg_view('profile/icon', array('entity' => $entity, 'size' => 'small'));

if ($icon == '')
    $icon = elgg_view('profile/icon', array('entity' => get_entity($entity->owner_guid), 'size' => 'small'));
?>

<div id="<?php echo $entity->guid ?>" class="search_listing">
    <div class="search_listing_icon right"><?php echo $icon; ?></div>
    <div class="listing_info">
        <?php
        foreach ($details as $ref => $detail) {
            echo '<div class="pending_detail">';
            echo '<span class="pending_name_' . $ref . '">' . $detail['name'] . '</span>';
            echo '<span class="pending_value_' . $ref . '">' . $detail['value'] . '</span>';
            echo '</div>';
        }
        ?>
    </div>
    <br>
    <div class="search_listing_extras">
        <div class="buttons">
            <div class="button">
                <a href="javascript:void(0)" guid="<?php echo $entity->guid ?>" class="pending_object_view">
                    <?php echo elgg_echo('hypeApprove:viewlisting') ?>
                </a>
            </div>

            <?php
                    //$url = getEditUrl($entity);
                    //if ($url !== '' && $entity->canEdit()) {
                    //    echo '<div class="button">';
                    //    echo '<a href="' . $url . '" target="_blank">' . elgg_echo('hypeApprove:editlisting') . '</a>';
                    //    echo '</div>';
                    //}
            ?>

                    <div class="button">
                <?php
                    $ts = time();
                    $token = generate_action_token($ts);
                    echo elgg_view("output/confirmlink", array(
                        'href' => $vars['url'] . 'action/hypeApprove/approve?id=' . $entity->guid . '&__elgg_token=' . $token . '&__elgg_ts=' . $ts,
                        'text' => elgg_echo('hypeApprove:approvelisting'),
                        'confirm' => elgg_echo('hypeApprove:approveconfirm'),
                    ));
                ?>
                </div>

                <div class="button">
                <?php
                    $ts = time();
                    $token = generate_action_token($ts);
                    echo elgg_view("output/confirmlink", array(
                        'href' => $vars['url'] . 'action/hypeApprove/delete?id=' . $entity->guid . '&__elgg_token=' . $token . '&__elgg_ts=' . $ts,
                        'text' => elgg_echo('hypeApprove:deletelisting'),
                        'confirm' => elgg_echo('hypeApprove:deleteconfirm'),
                    ));
                ?>
                </div>
            <?php
                    if ($entity->disable_reason !== 'suspected spam' && $entity_type !== 'user') {
            ?>
                        <div class="button">
                <?php
                        $ts = time();
                        $token = generate_action_token($ts);
                        echo elgg_view("output/confirmlink", array(
                            'href' => $vars['url'] . 'action/hypeApprove/spam?id=' . $entity->guid . '&__elgg_token=' . $token . '&__elgg_ts=' . $ts,
                            'text' => elgg_echo('hypeApprove:itsspam'),
                            'confirm' => elgg_echo('hypeApprove:itsspam'),
                        ));
                ?>
                    </div>


            <?php
                    }
            ?>

                    <div class="clearfloat"></div>
                </div>
            </div>
        </div>
        <div guid="<?php echo $entity->guid ?>" class="pending_object_hidden_view" style="display:none">
    <?php echo elgg_view_entity($entity) ?>
</div>

