<?php
global $CONFIG;

//CONTENT EDITING

$registered_entity_types = get_registered_entity_types();
?>

<div id="hypeApprove_settings_accordion">
    <h3><a href="#">Editor Accounts</a></h3>
    <div>
        <?php
        echo '<p>Enable Editor accounts (more options will appear once you enable these)</p>';

        echo elgg_view('input/pulldown', array(
            'internalname' => 'params[enable_editor_accounts]',
            'value' => $vars['entity']->enable_editor_accounts,
            'options_values' => array(
                false => 'No',
                true => 'Yes'
            )
        ));
        ?>
    </div>
    <h3><a href="#">Spam Check (Akismet Support)</a></h3>
    <div>
        <?php
        echo '<p>Include your Akistem API key if you would like the content to be checked for spam:</p>';

        echo elgg_view('input/text', array(
            'internalname' => 'params[enable_akismet_key]',
            'value' => $vars['entity']->enable_akismet_key,
        ));

        echo '<p>You can get your Akismet API Key <a href="https://akismet.com/signup/" target="_blank">here</a>.</p>';
        echo '<p>Additional settings will appear once you provide a valid API key.</p>';
        ?>
    </div>
    <?php
        foreach ($registered_entity_types as $type => $subtypes) {
            if (empty($subtypes)) {
                $subtypes = array('all');
            }
            foreach ($subtypes as $subtype) {
                echo "<h3><a href=\"#\">{$type} -> {$subtype}</a></h3><div>";
                echo '<p>Requires approval?</p>';
                $param = 'reqapproval_' . $type . '_' . $subtype;
                echo elgg_view('input/pulldown', array(
                    'internalname' => 'params[' . $param . ']',
                    'value' => $vars['entity']->$param,
                    'options_values' => array(
                        false => 'No',
                        true => 'Yes'
                    )
                ));
                if (get_plugin_setting('enable_editor_accounts', 'hypeApprove')) {
                    echo '<p>What actions can editors perform?</p>';
                    $param = 'reqeditor_' . $type . '_' . $subtype;
                    echo elgg_view('input/pulldown', array(
                        'internalname' => 'params[' . $param . ']',
                        'value' => $vars['entity']->$param,
                        'options_values' => array(
                            0 => 'No privileges',
                            1 => 'Can only edit',
                            2 => 'Can only approve',
                            3 => 'Can edit and approve'
                        )
                    ));
                }

                if (get_plugin_setting('valid_akismet_key', 'hypeApprove') && $type !== 'user') {
                    echo '<p>Does this content require spam check via Akismet?</p>';
                    $param = 'reqspamcheck_' . $type . '_' . $subtype;
                    echo elgg_view('input/pulldown', array(
                        'internalname' => 'params[' . $param . ']',
                        'value' => $vars['entity']->$param,
                        'options_values' => array(
                            0 => 'No',
                            1 => 'Yes',
                        )
                    ));
                }
                echo '</div>';
            }
        }
    ?>
</div>
<script type="text/javascript">
    $(document).ready(function() {
        $("#hypeApprove_settings").parent('div').attr('style', 'display:block');
        $("#hypeApprove_settings_accordion").accordion({fillSpace:true});
        $("#hypeApprove_settings").parent('div').attr('style', 'display:none');
    });
</script>
