<?php

global $CONFIG;

$user = get_loggedin_user();

$limit = get_input('limit', 10);
$offset = get_input('offset', 0);

if (!canApprove()) {
    register_error(elgg_echo('hypeApprove:cannotviewapprovepage'));
    forward();
} else {
    $access_status = access_get_show_hidden_status();
    access_show_hidden_entities(true);

    $value_pairs = array(
        array('name' => 'enabled', 'values' => 'no', 'operand' => '=', 'case_sensitive' => false),
            //array('name' => 'disable_reason', 'values' => 'pending approval', 'operand' => '=', 'case_sensitive' => false),
    );

    $objects = elgg_get_entities_from_metadata(array(
                'metadata_name_value_pairs' => $value_pairs,
                'limit' => $limit
            ));

    $pagination = elgg_view('navigation/pagination', array(
                'baseurl' => $vars['url'] . '/pg/approve',
                'offset' => $offset,
                'count' => false,
                'limit' => $limit,
            ));

    foreach ($objects as $object) {
        if (canApproveObject($user, $object) &&
                ($object->disable_reason == 'pending approval'
                or $object->disable_reason == 'new_user'
                or $object->disable_reason == 'suspected spam')) {
            $body .= elgg_view('hypeApprove/pending', array('entity' => $object));
        }
    }

    $js = '
<script type="text/javascript">
$(document).ready(function() {
$(".pending_object_view").each(function(){
$(this).click(function(){
$("div[guid="+$(this).attr("guid")+"]").dialog({width:450});
}); }); });
</script>';

    access_show_hidden_entities($access_status);

    $title = elgg_echo('hypeApprove:pendingapproval:admin');
    $header = elgg_view_title($title);

    $body = elgg_view_layout('two_column_left_sidebar', $area1, $header . $body . $pagination . $js, $area3);

    page_draw($title, $body);
}
?>
