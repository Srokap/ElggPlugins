<?php
if ($vars['entity'] instanceof ElggUser) {
    $role = NULL;
    if ($vars['entity']->isAdmin()) {
        $role = 'admin';
    }
    if ($vars['entity']->editor) {
        $role = 'editor';
    }
    if ($role !== NULL
            //&& ($vars['size'] == 'medium' or $vars['size'] == 'large')
            && $vars['size'] !== 'tiny'
    ) {
?>
        <script type="text/javascript">
            $('#icon_'+<?php echo $vars['entity']->guid ?>).addClass('<?php echo $role ?>_icon');
        </script>
<?php
    }
}
?>
