<?php

/* hype Approve
 *
 * Content Approval and Moderation for hype
 * Spam Check for hype
 *
 * @package hype
 * @subpackage Approve
 *
 * @author Ismayil Khayredinov <ismayil.khayredinov@gmail.com>
 * @copyright Copyrigh (c) 2011, Ismayil Khayredinov
 */

include_once(dirname(__FILE__) . '/models/model.php');
include_once(dirname(__FILE__) . '/models/Akismet.class.php');

function hypeApprove_init() {
    global $CONFIG;

    if (!is_plugin_enabled('hypeFramework')) {
        register_error('hypeFramework is not enabled. hypeApprove will not work properly. Visit www.hypeJunction.com for details');
    }

    register_action('hypeApprove/geneditor', false, $CONFIG->pluginspath . 'hypeApprove/actions/editor.php', true);
    register_action('hypeApprove/approve', false, $CONFIG->pluginspath . 'hypeApprove/actions/approve.php', false);
    register_action('hypeApprove/delete', false, $CONFIG->pluginspath . 'hypeApprove/actions/delete.php', false);
    register_action('hypeApprove/spam', false, $CONFIG->pluginspath . 'hypeApprove/actions/spam.php', false);


    if (get_plugin_setting('enable_editor_accounts', 'hypeApprove')) {
        extend_view('profile/menu/adminlinks', 'hypeApprove/editor/menu');
        register_plugin_hook('permissions_check', 'all', 'hypeApprove_editing_permissions');
    }
    extend_view('profile/icon', 'hypeApprove/extras/icon');
    elgg_extend_view('css', 'hypeApprove/css');

    register_page_handler('approve', 'hypeApprove_page_handler');

    $akismet_key = get_plugin_setting('valid_akismet_key', 'hypeApprove');
    if (!$akismet_key) {
        verifyAkismet(get_plugin_setting('enable_akismet_key', 'hypeApprove'));
    } else {
        register_elgg_event_handler('create', 'all', 'hypeApprove_create_spamcheck');
        register_elgg_event_handler('update', 'all', 'hypeApprove_create_spamcheck');
    }
    register_elgg_event_handler('create', 'all', 'hypeApprove_create');
}

function hypeApprove_page_handler($page) {
    global $CONFIG;

    if ($page[0])
        set_input('object_guid', $page[0]);

    include($CONFIG->pluginspath . 'hypeApprove/views/default/hypeApprove/pages/approve.php');
}

function hypeApprove_editing_permissions($hook, $entity_type, $returnvalue, $params) {
    if ($params['entity'] instanceof ElggEntity) {
        $entity_type = $params['entity']->getType();
        if (!$entity_subtype = $params['entity']->getSubtype())
            $entity_subtype = 'all';
        $param = 'reqeditor_' . $entity_type . '_' . $entity_subtype;
    }
    $privileges = get_plugin_setting($param, 'hypeApprove');
    $canedit = false;

    if ($privileges == 1 or $privileges == 3)
        $canedit = true;

    if ($params['user']->editor && $canedit)
        return true;
}

function hypeApprove_create($event, $object_type, $object) {
    global $CONFIG;

    $entity_type = $object_type;
    if ($object instanceof ElggEntity && !$entity_subtype = $object->getSubtype())
        $entity_subtype = 'all';
    $param = 'reqapproval_' . $entity_type . '_' . $entity_subtype;

    $needsapproval = get_plugin_setting($param, 'hypeApprove');
    $user = get_loggedin_user();

    if ($event == 'create' && $needsapproval && !isadminloggedin() && !$user->editor && $entity_type !== 'user') {
        system_message(elgg_echo('hypeApprove:needsadminapproval'));

        $to = getNotifyGuids($object);
        $from = $CONFIG->site_guid;
        $subject = elgg_echo('hypeApprove:pendingapproval');
        $approve_url = '<a href="' . $CONFIG->wwwroot . 'pg/approve">' . $CONFIG->wwwroot . 'pg/approve' . '</a>';
        $message = sprintf(elgg_echo('hypeApprove:pendingapproval:message'), elgg_view_entity($object->guid, true), $approve_url);

        notify_user($to, $from, $subject, $message);
        $object->disable('pending approval');
    }

    return true;
}

function hypeApprove_create_spamcheck($event, $object_type, $object) {
    global $CONFIG;
    $entity_type = $object_type;
    if ($object instanceof ElggEntity && !$entity_subtype = $object->getSubtype())
        $entity_subtype = 'all';
    $param = 'reqspamcheck_' . $entity_type . '_' . $entity_subtype;

    $needsspamcheck = get_plugin_setting($param, 'hypeApprove');
    $user = get_loggedin_user();

    if ($needsspamcheck && !isadminloggedin() && !$user->editor && $entity_type !== 'user') {
        $akismet = new Akismet($CONFIG->site->url, get_plugin_setting('enable_akismet_key'));
        $akismet->setCommentAuthor($user->name);
        $akismet->setCommentAuthorEmail($user->email);
        if (!$user_url = $user->website) {
            if (!$user_url = $user->www) {
                $user_url = $user->getURL();
            }
        }
        $akismet->setCommentAuthorURL($user_url);
        $content = $object->title;
        $content .= $object->description;
        $metadata .= get_metadata_for_entity($object->guid);
        if (!empty($metadata)) {
            foreach ($metadata as $ref => $meta) {
                if (!is_array($meta)) {
                    $content .= $meta;
                } else {
                    $content .= implode(', ', $meta);
                }
            }
        }
        $akismet->setCommentContent($content);
        $akismet->setPermalink($object->getURL());
        if ($akismet->isCommentSpam()) {
            $to = getNotifyGuids($object);
            $from = $CONFIG->site_guid;
            $subject = elgg_echo('hypeApprove:pendingapprovalspam');
            $approve_url = '<a href="' . $CONFIG->wwwroot . 'pg/approve">link</a>';
            $message = sprintf(elgg_echo('hypeApprove:pendingapprovalspam:message'), elgg_view_entity($object->guid, true), $approve_url);

            notify_user($to, $from, $subject, $message);
            system_message(elgg_echo('hypeApprove:markedasspam'));
            $object->disable('suspected spam');
        } else {
            return true;
        }
    } else {
        return true;
    }
}

function hypeApprove_pagesetup() {
    global $CONFIG;

    //add submenu options
    if (get_context() == "admin") {
        add_submenu_item(elgg_echo('hypeApprove:adminlink'), $CONFIG->wwwroot . "pg/approve", 'hype');
    }
}

register_elgg_event_handler('init', 'system', 'hypeApprove_init');
register_elgg_event_handler('pagesetup', 'system', 'hypeApprove_pagesetup');
?>
