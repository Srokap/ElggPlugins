hypeApprove is part of the hypeJunction bundle

hypeApprove is a powerful content approval and moderation plugin.

Main features include:
1. Grant editor privileges to registered users
2. Specify editor privileges per each registered entity type in your Elgg site
3. Specify content that requires approval before being published in the system
4. Notifications to eligible editors and admins that content requiring approval was published
5. Notifications to users that their content was approved
6. Integration with Akismet - possibly the best way in the world to protect you from spam (www.akismet.com) -- you will need to acquire an API key

INSTALLATION
1. Download and install hypeFramework from www.elgg.org or www.hypeJunction.com
2. Download and install hypeApprove
3. Customize hypeApprove settings in Tools Administration
