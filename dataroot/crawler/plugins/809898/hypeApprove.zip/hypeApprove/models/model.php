<?php

function canApprove() {

    if (!isloggedin())
        return false;
    
    $user = get_loggedin_user();

    if ($user->editor or $user->isAdmin()) {
        return true;
    } 

    return false;
}

function canApproveObject($user, $object) {

    if ($object instanceof ElggEntity) {
        $entity_type = $object->getType();
        if (!$entity_subtype = $object->getSubtype())
            $entity_subtype = 'all';
        $param = 'reqeditor_' . $entity_type . '_' . $entity_subtype;

        $privileges = get_plugin_setting($param, 'hypeApprove');
    }
    $canapprove = false;

    if ($privileges == 2 or $privileges == 3)
        $canapprove = true;

    if ($user->editor && $canapprove) {
        return true;
    }

    if ($user->isAdmin()) {
        return true;
    }
}

function getNotifyGuids($object) {

    global $CONFIG;
    $users = get_site_members($CONFIG->site_guid);

    $guids = array();

    if (!empty($users)) {
        foreach ($users as $user) {
            if (canApproveObject($user, $object)) {
                $guids[] = $user->getGUID();
            }
        }
    }
    return $guids;
}

function getEditURLs() {

    $urls = array();

    $urls['user'] = array(
        'all' => array('url' => 'pg/profile/%s/edit', 'meta' => 'username')
    );

    $urls['object'] = array(
        'company' => array('url' => 'pg/companies/edit/%s', 'meta' => 'guid'),
        'job' => array('url' => 'pg/jobs/edit/%s', 'meta' => 'guid'),
        'file' => array('url' => 'pg/file/edit/%s', 'meta' => 'guid'),
        'blog' => array('url' => 'pg/blog/edit/%s', 'meta' => 'guid'),
        'bookmark' => array('url' => 'pg/bookmarks/edit/%s', 'meta' => 'guid'),
        'page' => array('url' => 'pg/pages/edit/%s', 'meta' => 'guid'),
        'page_top' => array('url' => 'pg/pages/edit/%s', 'meta' => 'guid'),
    );

    $urls['group'] = array(
        'all' => array('url' => 'pg/groups/edit/%s', 'meta' => 'guid')
    );

    $urls = trigger_plugin_hook('hypeApprove:editurls', 'all', array('current' => $urls), $urls);

    return $urls;
}

function getEditURL($object) {
    $urls = getEditURLs();
    $url = $urls[$object->getType()][$object->getSubtype()];

    return sprintf($url['url'], $object->$url['meta']);
}

function verifyAkismet($akismet_key) {
    global $CONFIG;
    if ($akismet_key && $akismet_key !== '') {
        $akismet = new Akismet($CONFIG->site->url, $akismet_key);
        if ($akismet->isKeyValid()) {
            set_plugin_setting('valid_akismet_key', true, 'hypeApprove');
            return true;
        } else {
            register_error("You've provided an invalid Akismet API key");
            return false;
        }
    } else {
        return false;
    }
}

?>
