<?php

$english = array(
    'hypeApprove:granteditor' => 'Make editor',
    'hypeApprove:granteditor:confirm' => 'Are you sure you want to grant editor privileges to %s',
    'hypeApprove:editorgranted' => 'Editor privileges were successfully assigned',
    'hypeApprove:editorgranted:notify:subject' => 'You have been granted editor privileges',
    'hypeApprove:editorgranted:notify:message' => '
        Congratulations!

        Administrator of this site has granted you editor privileges.

        We hope that you stand up to this challenge and help us make this site a better place!
    ',
    'hypeApprove:revokeeditor' => 'Revoke editor privileges',
    'hypeApprove:revokeeditor:confirm' => 'Are you sure you want to revoke %s\'s editor privileges',
    'hypeApprove:editorrevoked' => 'Editor privileges were successfully revoked',
    'hypeApprove:editorrevoked:notify:subject' => 'Your editor privileges have been revoked',
    'hypeApprove:editorrevoked:notify:message' => '
        We are sorry, but the Administrator of the site has made a decision to revoke your editor privileges.
    ',
    'hypeApprove:role:admin' => 'Administrator',
    'hypeApprove:role:editor' => 'Editor',
    'hypeApprove:actionnotdefined' => 'We are sorry, but this action is not defined in the system',
    'hypeApprove:noprivileges' => 'You do not have priviliges to perform this action',
    'hypeApprove:needsadminapproval' => 'The item is pending approval by the administrator and will appear online shortly',
    'hypeApprove:pendingapproval' => 'New item pending approval',
    'hypeApprove:pendingapproval:message' => '

        The following item is pending approval:

            %s

        You can approve the item at %s.
    ',
    'hypeApprove:cannotviewapprovepage' => 'You can not access this page',
    'hypeApprove:pendingapproval:admin' => 'Objects pending approval',
    'hypeApprove:pending:reason' => '',
    'hypeApprove:pending:title' => 'Title:',
    'hypeApprove:pending:name' => 'Name:',
    'hypeApprove:pending:container' => 'Contained by:',
    'hypeApprove:pending:description' => 'Description:',
    'hypeApprove:viewlisting' => 'View',
    'hypeApprove:editlisting' => 'Edit',
    'hypeApprove:approvelisting' => 'Approve',
    'hypeApprove:approveconfirm' => 'Are you sure you want to approve this item?',
    'hypeApprove:link' => 'here',
    'hypeApprove:itemapproved:subject' => 'Your item was approved',
    'hypeApprove:itemapproved:message' => '
        Thank you for your patience.

        Your item titled: %s - was approved. You can now see it %s
    ',
    'hypeApprove:itemdeleted:subject' => 'Your item has not been approved',
    'hypeApprove:itemdeleted:message' => '
        We are sorry, but your item titled %s has not been approved and was deleted from the system.

        Please refrain from posting content that may be treated as spam or as inappropriate content.
        Please review our Terms and Conditions for more guidelines.
    ',
    'hypeApprove:deletelisting' => 'Delete',
    'hypeApprove:deleteconfirm' => 'Are you sure you want to delete this item? This action is irreversible.',
    'hypeApprove:pendingapprovalspam' => 'New item suspected as spam pending approval',
    'hypeApprove:pendingapprovalspam:message' => '

        The following item has been flagged as spam by Akismet and pending your approval:

            %s

        You can approve the item at %s.
    ',
    'hypeApprove:markedasspam' => 'This item has been marked as spam and requires admin approval',
    'hypeApprove:itsspam' => "Heck, it's spam",
    'hypeApprove:itsspamconfirm' => "Are you sure you want to report this item as spam and delete it?",

    'hypeApprove:adminlink' => 'Objects pending approval',
);

add_translation("en", $english);
?>
