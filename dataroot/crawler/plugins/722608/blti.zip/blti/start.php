<?php
/**
 * @name Plugin  Basic LTI
 * @abstract This plugin allows users to single sign on using Basic LTI
 * @author Antoni Bertran (antoni@tresipunt.com)
 * @copyright 2011 Universitat Oberta de Catalunya
 * @license GPL
 * @version 1.0.0
 * @package ElggBLTI
 * Date April 2011
*/
if (!class_exists("bltiUocWrapper")) {
	require_once dirname(__FILE__).'/IMSBasicLTI/uoc-blti/bltiUocWrapper.php';
	require_once dirname(__FILE__).'/IMSBasicLTI/ims-blti/blti_util.php';
	require_once dirname(__FILE__).'/IMSBasicLTI/utils/UtilsPropertiesBLTI.php';
}
register_elgg_event_handler('init', 'system', 'blti_init');
/**
 * 
 * Checks if is a BLTI call, and then do the SSO
 */
function blti_init() {

	if ( ! is_basic_lti_request() ) { return; }
    // See if we get a context, do not set session, do not redirect
    $context = new bltiUocWrapper(false, false);
    if ( ! $context->valid ) {
        register_error("BASIC LTI Authentication Failed, not valid request (make sure that consumer is authorized and secret is correct)");
        return;
    }
    
    try {
    	global $CONFIG;
	//we have a configuration file on indicates which fields are mapping
	$conf_file = (dirname(__FILE__).'/configuration/mappingFields.cfg');
	$prop = new UtilsPropertiesBLTI($conf_file);
	    //Check if user exists
	    // Set up the user...
	    $username = blti_get_username($context, $prop);
	    $name = $context->getUserName();
    	$email = $context->getUserEmail();
    	$admin = strpos(strtolower($context->info['roles']), 'administrator')!==false;
	    $user = get_user_by_username($username);
	    $guid = false;
    	
	    if (!$user) {
	    	
			$password = generate_random_cleartext_password();
	    	$guid = register_user($username, $password, $name, $email);
			if ($guid) {
				$user = get_entity($guid);
	
				system_message(sprintf(elgg_echo("registerok"),$CONFIG->sitename));
	
				//User Validation
				$user->enable();
				set_user_validation_status($guid, true);
				
			    //Login user
			    if ($user)
			    	$result = login($user);
			    //Update extra data of profile
			    blti_update_extradata($user, $context, $prop);	    
			    
			} else {
				register_error(elgg_echo("registerbad"));
				$user=false;
			}
			
	    } else {
	    	
	    	//Login because if not doesn't have permissions to save data
		    if ($user)
		    	$result = login($user);
	    	//Update user
		    $user->name = $name;
		    $user->email = $email;
			if (!$user->save()) {
				register_error(elgg_echo('user:name:fail'));
			}
	    	$guid = $user->getGUID();
	    }
	    
   		// @todo - consider removing registering admins since this is done
		// through the useradd action
		if (($guid) && ($admin) && (blti_map_as_admin($prop))) {
			// Only admins can make someone an admin
			$user->makeAdmin();
		}

	    //Check if course exists
	    //TODO manage course in groups
	    
//	    //Login user
//	    if ($user)
//	    	$result = login($user);
	    
//		// Forward on success, assume everything else is an error...
//		if ($result) {
//			forward();
//		}
    } catch (RegistrationException $r) {
			register_error($r->getMessage());
	}

}
function blti_map_as_admin($prop) {
	try {$mapping_as_admin = $prop->getProperty('mapping_as_admin');}
 	catch (Exception $e) {
		//Problem in configuration 
		$mapping_as_admin = 0;
	}
 return $mapping_as_admin;
}
function blti_get_username($context, $prop) {
	$username_no_prefix = 0;	
	try {
		$username_no_prefix = $prop->getProperty('username_no_prefix');
	} catch (Exception $e) {
		//Problem in configuration 
		$username_no_prefix = 0;
	}
	if ($username_no_prefix && $context->info['custom_username']) {
	   $username = $context->info['custom_username'];	
	} else {
	   $username = $context->getUserKey();
	}
        $username = sanitise_string(str_replace(':','_',$username));  // TO make it past sanitize_user
	return $username;
}
/**
 * Updates extradata at the moment only data of profile
 * @param ElggUser $user
 * @param BLTIContext $context
 */
function blti_update_extradata($user, $context, $prop) {
	//TODO save image
	//amb un filegetcontents....
	blti_save_user_icon($user, $context);
	blti_save_user_profile($user, $context, $prop);
	
}

/**
 * Updates data of profile of user
 * @param ElggUser $user
 * @param BLTIContext $context
 */
function blti_save_user_profile($user, $context, $prop){
	$input = array();
	try {
		//we have a configuration file on indicates which fields are mapping
		$number_of_fields = $prop->getProperty('number_of_fields');
		for ($i=1; $i<=$number_of_fields; $i++) {
			$input[$prop->getProperty('field'.$i.'_destination')] = $context->info[$prop->getProperty('field'.$i.'_source')];
		}
	} catch (Exception $e) {
		//Problem in configuration 
	}
	
	if (sizeof($input) > 0) {
		foreach($input as $shortname => $value) {
			//$user->$shortname = $value;
			remove_metadata($user->guid, $shortname);
			$access_id = ACCESS_LOGGED_IN;
			if (is_array($value)) {
				$i = 0;
				foreach($value as $interval) {
					$i++;
					if ($i == 1) { $multiple = false; } else { $multiple = true; }
					create_metadata($user->guid, $shortname, $interval, 'text', $user->guid, $access_id, $multiple);
				}
			} else {
				create_metadata($user->guid, $shortname, $value, 'text', $user->guid, $access_id);
			}
		}
		$user->save();
	}
	return $input;
}

/**
* Stores the file ico of user
* @param ElggUser $user
* @param BLTIContext $context
*/
function blti_save_user_icon($user, $context){

	$profileicon = $context->getUserImage();
	
	if ($pos = strpos($profileicon, '&size=')) {
		$profileicon = substr($profileicon, 0, $pos);
	}
	$link = curl_init($profileicon);
	curl_setopt($link, CURLOPT_HEADER, 0); 
	curl_setopt($link, CURLOPT_RETURNTRANSFER, 1); 
	curl_setopt($link, CURLOPT_BINARYTRANSFER, 1);
	
	if( ! $result = curl_exec($link)) 
    	{ 
    		register_error(curl_error($link));
		return false;
   	}  
	
	curl_close($link);
	$file_tmp = '/tmp/abb'.rand();
	if(file_exists($file_tmp)){
	 unlink($file_tmp);
	}
	$fp = fopen($file_tmp, 'x');
	fwrite($fp, $result);
	fclose($fp);
	
	if ($result) {
		
		$topbar = get_resized_image_from_existing_file($file_tmp, 16,16, true, 0, 0, 0, 0, true);
		$tiny = get_resized_image_from_existing_file($file_tmp, 25,25, true, 0, 0, 0, 0, true);
		$small = get_resized_image_from_existing_file($file_tmp, 40,40, true, 0, 0, 0, 0, true);
		$medium = get_resized_image_from_existing_file($file_tmp, 100,100, true, 0, 0, 0, 0, true);
		$large = get_resized_image_from_existing_file($file_tmp, 200,200, false, 0, 0, 0, 0, false);
		$master = get_resized_image_from_existing_file($file_tmp, 500,500, false, 0, 0, 0, 0, false);
				
		if ($small !== false
			&& $medium !== false
			&& $large !== false
			&& $tiny !== false) {
				$filehandler = new ElggFile();
				$filehandler->owner_guid = $user->getGUID();
				$filehandler->setFilename("profile/" . $user->guid . "large.jpg");
				$filehandler->open("write");
				$filehandler->write($large);
				$filehandler->close();
				$filehandler->setFilename("profile/" . $user->guid . "medium.jpg");
				$filehandler->open("write");
				$filehandler->write($medium);
				$filehandler->close();
				$filehandler->setFilename("profile/" . $user->guid . "small.jpg");
				$filehandler->open("write");
				$filehandler->write($small);
				$filehandler->close();
				$filehandler->setFilename("profile/" . $user->guid . "tiny.jpg");
				$filehandler->open("write");
				$filehandler->write($tiny);
				$filehandler->close();
				$filehandler->setFilename("profile/" . $user->guid . "topbar.jpg");
				$filehandler->open("write");
				$filehandler->write($topbar);
				$filehandler->close();
				$filehandler->setFilename("profile/" . $user->guid . "master.jpg");
				$filehandler->open("write");
                $filehandler->write($master);
				$filehandler->close();
					
				$user->icontime = time();
				
				//system_message(elgg_echo("profile:icon:uploaded"));
				
				trigger_elgg_event('profileiconupdate',$user->type,$user);
				
				//add to river
				add_to_river('river/user/default/profileiconupdate','update',$user->guid,$user->guid);
			}
			unlink($file_tmp);
	}				
}