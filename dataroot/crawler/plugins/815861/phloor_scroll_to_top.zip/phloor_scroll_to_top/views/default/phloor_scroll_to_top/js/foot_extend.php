<?php
/**
 * 
 */
?>
<script type="text/javascript">$(document).ready(function(){$(function(){$(window).scroll(function(){if($(this).scrollTop()>100){$("#phloor-scroll-to-top").fadeIn()}else{$("#phloor-scroll-to-top").fadeOut()}});$("#phloor-scroll-to-top a").click(function(){$("body,html").animate({scrollTop:0},800);return false})})})</script>