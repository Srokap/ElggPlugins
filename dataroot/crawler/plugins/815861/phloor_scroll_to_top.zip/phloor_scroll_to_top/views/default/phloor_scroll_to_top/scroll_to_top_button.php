<?php

$title = elgg_echo('phloor_scroll_to_top:link:content');

echo <<<____HTML
<p id="phloor-scroll-to-top">
	<a href="#top"><span></span>{$title}</a>
</p>
____HTML;

?>
	