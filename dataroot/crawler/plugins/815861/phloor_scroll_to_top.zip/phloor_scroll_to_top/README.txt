/**
 * Phloor Scroll To Top
 * 
 * @package phloor_scroll_to_top
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author void <void@13net.at>
 * @copyright 13net
 * @link http://www.13net.at/
 */
 
Version: 11.11.14
Requires: Elgg 1.8 or higher

/**
 * Description
 */
Displays a 'Back to Top' link on oversized pages.
According to the tutorial: http://webdesignerwall.com/tutorials/animated-scroll-to-top

/**
 * Languages
 */
English
German

