<?php
/**
 * Phloor Scroll To Top
 * English
 */

$english = array(
  'admin:plugins:category:PHLOOR' => 'PHLOOR Plugins',
  'phloor_scroll_to_top' => 'Phloor Scroll To Top',

  'phloor_scroll_to_top:link:content' => 'Back to Top',
);
	
add_translation("en", $english);
