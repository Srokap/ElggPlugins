<?php
/**
 * Phloor Scroll To Top
 * German
 */

$german = array(
  'admin:plugins:category:PHLOOR' => 'PHLOOR Plugins',
  'phloor_scroll_to_top' => 'Phloor Scroll To Top',

  'phloor_scroll_to_top:link:content' => 'nach oben',
);
	
add_translation("de", $german);