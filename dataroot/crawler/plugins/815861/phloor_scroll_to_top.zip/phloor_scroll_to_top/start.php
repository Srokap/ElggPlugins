<?php

elgg_register_event_handler('init',  'system', 'phloor_scroll_to_top_init');

/**
 * Phloor Scroll To Top Initialization
 */
function phloor_scroll_to_top_init() {	
	/**
	 * CSS
	 */
	$css_url = 'mod/phloor_scroll_to_top/views/default/phloor_scroll_to_top/css/';
	elgg_register_css('phloor-scroll-to-top-css', $css_url . 'phloor_scroll_to_top.css', 700);	

	elgg_load_css('phloor-scroll-to-top-css');
	
	/**
	 * Inline JS
	 */
	elgg_extend_view('page/elements/foot', 'phloor_scroll_to_top/js/foot_extend', 700);
	
	/**
	 * Extend Views
	 */
	elgg_extend_view('page/elements/footer', 'phloor_scroll_to_top/scroll_to_top_button', 700);
}

