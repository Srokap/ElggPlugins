Integrates geo-autocomplete jQuery plugin (http://code.google.com/p/geo-autocomplete/) to  suggests locations 
to user as they fill out the location input box . Uses Google Maps v3 API and Google Static Maps v2 API.

Place plugin below default profile and profile manager plugins.

If you are using profile manager, in the PM settings, import default fields. Delete ones you dont
want but leave location field. 



