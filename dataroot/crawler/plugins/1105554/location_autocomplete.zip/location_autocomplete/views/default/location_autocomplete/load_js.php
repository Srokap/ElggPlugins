<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


    elgg_load_js('elgg.google_map');  
    elgg_load_js('elgg.jquery_min');
    elgg_load_js('elgg.jquery_custom');         
    elgg_load_js('elgg.geo_suggests');  
    
?>
