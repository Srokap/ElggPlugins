<?php

	$english = array(
	
		/**
		 * Friends widget
		 */
			'friends:widget:description' => "Displays some of your friends.",
            'friends:invite'  =>  "Invite new friends",
            'friends:entername'  =>  "* Please enter the friend's name"
	);
					
	add_translation("en",$english);

?>