<?php

// Generat per la traducció del navegador 

$catalan = array( 
	 'categories'  =>  "Categories" , 
	 'categories:settings'  =>  "Edita les categories del lloc" , 
	 'categories:explanation'  =>  "Per establir algunes categories globals pel lloc que seran utilitzades a través del teu sistema, introdueix-les a sota separades per comes. Seran mostrades per les eines compatibles quan l'usuari cregui o editi contingut." , 
	 'categories:save:success'  =>  "Les categories del lloc s'han desat correctament." , 
	 'categories:results'  =>  "Resultats per a la categoria: %s"
); 

add_translation('ca', $catalan); 

?>