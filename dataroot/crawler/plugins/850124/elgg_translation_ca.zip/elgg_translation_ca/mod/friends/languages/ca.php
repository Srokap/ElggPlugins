<?php

// Generado por translationbrowser 

$catalan = array( 
	 'friends:widget:description'  =>  "Mostrar algunes amistats" , 
	 'friends:num_display'  =>  "Nombre d'amistats a mostrar" , 
	 'friends:icon_size'  =>  "Mida de la icona" , 
	 'friends:tiny'  =>  "molt petit" , 
	 'friends:small'  =>  "petit"
); 

add_translation('ca', $catalan); 

?>