<?php

// Generat per la traducció del navegador 

$catalan = array( 
	 'item:object:moddefaultwidgets'  =>  "Configuració per defecte dels widgets" , 
	 'defaultwidgets:menu:profile'  =>  "Perfil per defecte" , 
	 'defaultwidgets:menu:dashboard'  =>  "Escriptori per defecte" , 
	 'defaultwidgets:admin:error'  =>  "S'ha produït un error! No ets administrador/a" , 
	 'defaultwidgets:admin:notfound'  =>  "S'ha produït un error! La pàgina no existeix. Prova de nou o posa't en contacte amb l'equip administrador" , 
	 'defaultwidgets:admin:loginfailure'  =>  "No estàs registrat com administrador/a" , 
	 'defaultwidgets:update:success'  =>  "La configuració del teu widget s'ha desat correctament" , 
	 'defaultwidgets:update:failed'  =>  "Hi ha un error! la configuració no s'ha desat. Prova de nou o posat en contacte amb l'equip administrador" , 
	 'defaultwidgets:update:noparams'  =>  "Hi ha un error! paràmetres incorrectes. Prova de nou o posat en contacte amb l'equip administrador" , 
	 'defaultwidgets:profile:title'  =>  "Selecciona els widgets que vols per defecte per als perfils de les persones usuàries noves" , 
	 'defaultwidgets:dashboard:title'  =>  "Selecciona els widgets per defecte per a l'escriptori de les persones usuàries noves"
); 

add_translation('ca', $catalan); 

?>