<?php

// Generado por translationbrowser 

$catalan = array( 
	 'tinymce:remove'  =>  "Afegir/treure editor"
); 

add_translation('ca', $catalan); 

?>