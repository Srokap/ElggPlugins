<?php

// Generado por translationbrowser 

$catalan = array( 
	 'messageboard:board'  =>  "Tauler d'anuncis" , 
	 'messageboard:messageboard'  =>  "Tauler d'anuncis" , 
	 'messageboard:viewall'  =>  "Veure tots" , 
	 'messageboard:postit'  =>  "Publicar" , 
	 'messageboard:history'  =>  "història" , 
	 'messageboard:none'  =>  "No hi ha res en aquest tauler d'anuncis, encara" , 
	 'messageboard:num_display'  =>  "Nombre de missatges a veure" , 
	 'messageboard:desc'  =>  "Aquest és un tauler d'anuncis que pots posar en el teu perfil i on altres persones usuàries poden deixar un comentari." , 
	 'messageboard:user'  =>  "Tauler d'anuncis de %s" , 
	 'messageboard:replyon'  =>  "Donar resposta a" , 
	 'messageboard:river:annotate'  =>  "%s tens un comentari nou en el teu tauler d'anuncis. " , 
	 'messageboard:river:create'  =>  "%s ha afegit el widget de tauler d'anuncis." , 
	 'messageboard:river:update'  =>  "%s has actualitzat el teu widget en el tauler d'anuncis. " , 
	 'messageboard:river:added'  =>  "%s ha escrit un missatge a" , 
	 'messageboard:river:messageboard'  =>  "tauler d'anuncis" , 
	 'messageboard:posted'  =>  "El comentari ha estat publicat correctament en el tauler d'anuncis." , 
	 'messageboard:deleted'  =>  "El comentari ha estat esborrat." , 
	 'messageboard:email:subject'  =>  "Tens un missatge nou en el tauler d'anuncis!" , 
	 'messageboard:email:body'  =>  "%s t'ha deixat el següent comentari:

%s

Per veure els comentaris en el teu tauler d'anuncis, fes click en el següent link:

%s

Per consultar el perfil de %s, fes click en aquest link:

%s

No donis resposta a aquest email." , 
	 'messageboard:blank'  =>  "Necessites posar alguna cosa en l'àrea de missatge abans d'enviar-ho." , 
	 'messageboard:notfound'  =>  "No s'ha trobat l'element especificat." , 
	 'messageboard:notdeleted'  =>  "El missatge no ha pogut esborrar-se." , 
	 'messageboard:somethingwentwrong'  =>  "Alguna cosa estranya ha passat. Prova de nou o posa't en contacte amb l'equip administrador." , 
	 'messageboard:failure'  =>  "S'ha produit un error en el moment d'afegir el teu missatge. Prova de nou. " , 
	 'messageboard:history:title'  =>  "Història"
); 

add_translation('ca', $catalan); 

?>