<?php

// Generat per la traducció del navegador 

$catalan = array( 
	 'mine'  =>  "Meu" , 
	 'filter'  =>  "Filtre" , 
	 'activity'  =>  "Activitat" , 
	 'riverdashboard:recentmembers'  =>  "Persones membres recents" , 
	 'sitemessages:announcements'  =>  "Lloc d'anuncis" , 
	 'sitemessages:posted'  =>  "Lloc missatges recents" , 
	 'sitemessages:river:created'  =>  "Lloc de l'administrador/a, %s," , 
	 'sitemessages:river:create'  =>  "Posa un nou missatge de web detallat" , 
	 'river:widgets:friends'  =>  "Amistats" , 
	 'river:widgets:mine'  =>  "Meu" , 
	 'option:icon'  =>  "Icones" , 
	 'option:avatar'  =>  "Avatars"
); 

add_translation('ca', $catalan); 

?>