<?php

// Generado por translationbrowser 

$catalan = array( 
	 'logbrowser'  =>  "Navegador de registres" , 
	 'logbrowser:browse'  =>  "Explorar el sistema de registres" , 
	 'logbrowser:search'  =>  "Cercar paràmetres" , 
	 'logbrowser:user'  =>  "Persona usuària que vols cercar" , 
	 'logbrowser:starttime'  =>  "Temps de començament (per exemple \"darrer dilluns\", \"fa 1 hora\")" , 
	 'logbrowser:endtime'  =>  "Temps final" , 
	 'logbrowser:explore'  =>  "Explorar registre"
); 

add_translation('ca', $catalan); 

?>