<?php

// Generat per la traducció del navegador 

$catalan = array( 
	 'expages'  =>  "Pàgines externes" , 
	 'expages:frontpage'  =>  "Portada" , 
	 'expages:about'  =>  "Sobre" , 
	 'expages:terms'  =>  "Condicions" , 
	 'expages:privacy'  =>  "Privacitat" , 
	 'expages:analytics'  =>  "Anàlisi" , 
	 'expages:contact'  =>  "Contacte" , 
	 'expages:nopreview'  =>  "No és possible la vista prèvia de moment" , 
	 'expages:preview'  =>  "Vista prèvia" , 
	 'expages:notset'  =>  "Aquesta pàgina encara no s'ha desenvolupat." , 
	 'expages:lefthand'  =>  "La part esquerra d'informació" , 
	 'expages:righthand'  =>  "La part dreta de la informació" , 
	 'expages:addcontent'  =>  "Pots afegir continguts aquí mitjançant les eines d'administració. Cerca l'enllaç de les pàgines externes sota l'admin." , 
	 'item:object:front'  =>  "Davant els articles" , 
	 'expages:posted'  =>  "La teva pàgina s'ha actualitzat correctament." , 
	 'expages:deleted'  =>  "El teu post s'ha eliminat correctament." , 
	 'expages:deleteerror'  =>  "Hi ha problemes per eliminar l'última pàgina" , 
	 'expages:error'  =>  "Ha hagut un error. Prova de nou i si el problema continua contacta amb l'equip administrador"
); 

add_translation('ca', $catalan); 

?>