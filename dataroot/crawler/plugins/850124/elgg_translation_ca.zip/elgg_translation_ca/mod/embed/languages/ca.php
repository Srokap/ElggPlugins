<?php

// Generado por translationbrowser 

$catalan = array( 
	 'media:insert'  =>  "Inserir / Pujar fitxer" , 
	 'embed:instructions'  =>  "Selecciona el fitxer que desitgis inserir en el comentari. Simplement fes \"click\" damunt d'ell" , 
	 'embed:media'  =>  "Inserir fitxer" , 
	 'upload:media'  =>  "Pujar fitxer" , 
	 'embed:file:required'  =>  "No tens una aplicació per pujar fitxers instal·lada. Posa't en contacte amb l'equip 'administrador per a que habiliti el pluguin."
); 

add_translation('ca', $catalan); 

?>