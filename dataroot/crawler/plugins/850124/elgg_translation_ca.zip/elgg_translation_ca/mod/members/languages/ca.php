<?php

// Generado por translationbrowser 

$catalan = array( 
	 'members:label:newest'  =>  "Noves" , 
	 'members:label:popular'  =>  "Populars" , 
	 'members:members'  =>  "Persones enregistrades a la xarxa social" , 
	 'members:online'  =>  "Persones online" , 
	 'members:active'  =>  "Persones enregistrades" , 
	 'members:searchtag'  =>  "Cercar persones per etiquetes" , 
	 'members:searchname'  =>  "Cercar persones membres per nom" , 
	 'members:label:active'  =>  "Conectades" , 
	 'members:search:name'  =>  "Noms de persona usuària" , 
	 'members:search:tags'  =>  "Etiquetes"
); 

add_translation('ca', $catalan); 

?>