<?php

// Generat per la traducció del navegador 

$catalan = array( 
	 'custom:bookmarks'  =>  "Últims enllaços" , 
	 'custom:groups'  =>  "Grups" , 
	 'custom:files'  =>  "Últims arxius" , 
	 'custom:blogs'  =>  "Últims posts del bloc" , 
	 'custom:members'  =>  "Noves persones membres" , 
	 'custom:nofiles'  =>  "Encara no hi ha arxius" , 
	 'custom:nogroups'  =>  "Encara no hi ha grups"
); 

add_translation('ca', $catalan); 

?>