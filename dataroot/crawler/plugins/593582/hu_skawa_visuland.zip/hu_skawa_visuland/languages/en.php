<?php

	$english = array(

		'visuland:visuland' => 'Visuland 3D',
		'visuland:enter' => 'Enter Visuland',
		'visuland:welcome' => '
			<h3>Welcome to Visuland 3D community!</h3>
			<span>As this is your first time accessing Visuland community, we will ask you a couple of questions to...</span>
			<span>Once you enter, you\'ll be able to interact with your friends and other community members in a whole new way.</span>
			<span>Please don\'t forget to accept the licence agreement by checking the box at the bottom of the page.</span>
		',
		'visuland:register:nick' => 'Nick (this will be your display name):',
		'visuland:register:gender' => 'Gender:',
		'visuland:register:male' => 'Male',
		'visuland:register:female' => 'Female',
		'visuland:register:birthdate' => 'Date of birth (YYYY.MM.DD format):',
		'visuland:register:city' => 'City:',
		'visuland:register:country' => 'Country:',
		'visuland:register:licence' => 'Licence agreement',
		'visuland:register:licence_text' => 'See on <a href="http://visuland.biz/policies/" target="_blank">visuland.biz</a>'
		,

		'visuland:register:licence_accept' => 'Please tick this box to accept the licence agreement',
			
		'visuland:register:success' => 'You\'ve been successfully registered at the visuland server.',
		'visuland:register:failure' => 'Unable to register your account at the visuland server. Server response: ',
	
		'visuland:admin:settings' => 'Settings',
		'visuland:admin:select_world' => 'Select world',
		'visuland:admin:enable_guests' => 'Allow non-registered users to access the Visuland virtual worlds?',
		'visuland:admin:access' => 'Access level',
		'visuland:admin:private' => 'Private (locked to your Elgg installation)',
		'visuland:admin:public' => 'Public (users are accepted from 3rd party installations',
		'visuland:admin:domain_password' => 'Domain password',
		'visuland:admin:unmask' => "Don't mask",
		'visuland:admin:info' => '<ul><li>To obtain your unique domain password, please contact us at <a href="http://visuland.biz/contact-us/?domain=:domain:" target="_blank">visuland.biz</a>.</li>
			<li>The server needs the password for retrieving available locations. The locations will not appear in the list until you have set your password and
			saved.</li>
			<li>To check out our live Elgg integration, please login at <a href="http://elgg.visuland.com/" target="_blank">elgg.visuland.com</a>.</li>
			<li>This plugin requires the <a href="http://community.elgg.org/pg/plugins/project/461662/developer/jeabakker/country-selector">Country Selector</a>
			plugin to be installed.</li>
		</ul>',
	
		'visuland:browser:not_supported' => '<h3>Your browser is not supported at the moment.</h3><p>We are very sorry, but our plugin only supports MS Internet Explorer 7+ and Mozilla Firefox web browsers. We suggest to either switch to one of the aforementioned browsers to use Visuland, or check back later. We\'re continuously extending our list of supported browsers, so there is a good chance your\'s will be supported soon as well.</p>',

		'visuland:plugin:not_installed' => 'The Visuland 3D community requires the installation of a plugin. Please accept the installation request from your browser.',
		'visuland:plugin:installed' => 'The Visuland plugin has been successfully installed. Please restart Firefox to complete the install process.',
	);
					
	add_translation('en', $english);

?>