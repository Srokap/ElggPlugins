<?php

	/**
	 * Visuland 3D VR community plugin
	 * 
	 * @package None
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Andr�s Szepesh�zi
	 * @copyright Skawa Ltd 2010
	 * @link http://www.skawa.com/
	 */
	 
	require_once('server.php');

	/**
	 * Visuland initialisation
	 */
	 
    function visuland_init() {

    	global $CONFIG;
		register_page_handler('visuland','visuland_page_handler');
		add_menu(elgg_echo('visuland:visuland'), $CONFIG->wwwroot . "pg/visuland/");
	}
		
		
	/**
	 * Page handler, allows the use of fancy URLs
	 *
	 * @param array $page From the page_handler function
	 * @return true|false Depending on success
	 */
	function visuland_page_handler($page) {
		include(dirname(__FILE__) . "/index.php");
		return true;
	}

	register_elgg_event_handler('init','system','visuland_init');
	global $CONFIG;
	register_action("visuland/register",false,$CONFIG->pluginspath . "hu_skawa_visuland/actions/register.php");
	 
?>