<?php

	/**
	 * Elgg Visuland 3D community page
	 *
	 * @package None
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Andr�s Szepesh�zi
	 * @copyright Skawa Ltd 2010
	 * @link http://www.skawa.com/
	 */

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	gatekeeper();
	
	$user = get_loggedin_user();
	$area1 = elgg_view_title(elgg_echo("visuland:visuland"));
/*	
	function dumpObj($obj)
	{
		ob_start();
		print_r($obj);
		$str = ob_get_contents();
		ob_end_clean();
		return $str;
	}
	$area1 .= '<!-- '.dumpObj($user).' -->';
*/
	if (isset($user->visuland_id)) {
		$area1 .= elgg_view("visuland/visuland", array('user' => $user));
	} else {
		$area1 .= elgg_view("visuland/gate", array('user' => $user));
	}

	$body = elgg_view_layout("one_column", $area1);
	page_draw(elgg_echo("visuland:visuland"),$body);
?>