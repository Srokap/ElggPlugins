<?php

	class ServerUtil
	{
		
		public static $lastRequestInfo = null;

		public static function post($url, $params) {
			$handle = curl_init($url);
			curl_setopt($handle, CURLOPT_POST, true);
			curl_setopt($handle, CURLOPT_URL, $url);
			curl_setopt($handle, CURLOPT_POSTFIELDS, $params);
			curl_setopt($handle, CURLOPT_RETURNTRANSFER, 1);
			$reply = curl_exec($handle);
			$info = curl_getinfo($handle);

			curl_close($handle);
				
			if ($reply === false || $info['http_code'] != 200) {
				$reply = false;
			} else {
				//              echo("output1 = $output");
			}
   
			ServerUtil::$lastRequestInfo = Array('info' => $info, 'params' => explode('&', $params));
			return $reply;
		}

		public static function get($url, $params) {
			$handle = curl_init($url);
			curl_setopt($handle, CURLOPT_POST, true);
			curl_setopt($handle, CURLOPT_URL, $url.'?'.$params);
			curl_setopt($handle, CURLOPT_RETURNTRANSFER, 1);
			$reply = curl_exec($handle);
			$info = curl_getinfo($handle);
 
			curl_close($handle);

			if ($reply === false || $info['http_code'] != 200) {
				$reply = false;
			}
  
			ServerUtil::$lastRequestInfo = $info;
			return $reply;
		}

	
		public static function encodeQuery($arr)
		{
			$res = Array();
			foreach($arr as $k => $v)
			{
				$res[] = urlencode($k).'='.urlencode($v);
			}
			return implode('&', $res);
		}
	};
	
	function vlGetDomain()
	{
		$name = $_SERVER['SERVER_NAME'];
		$dom = 'http://'.$name;
		$dom = explode('/', $dom, 4);
		$dom = preg_replace('/^www\./i', '', $dom[2]);
		$dom = explode('.', $dom);
		$cut = -2;
		$second = $dom[count($dom)-2];
		if($second == 'visuland' || strlen($second) <= 3 && count($dom) > 2)
			$cut = -3;
		$dom = implode('.', array_slice($dom, $cut));
//		return 'elgg.org';
		return $dom;
	}

	function vlMakeQuery($params, $passwordOverride=null)
	{
		$params['domain_login'] = vlGetDomain();
		$params['domain_password'] = $passwordOverride == null ? get_plugin_setting('domain_password', 'hu_skawa_visuland') : $passwordOverride;
		return ServerUtil::encodeQuery($params);
	}
	
	function vlSetUser($userId, $userPassword, $domainPasswordOverride=null)
	{
		$params = Array(
			'id' => $userId,
			'password' => $userPassword
		);
		
		return ServerUtil::post('http://iframe.visuland.com/friends/setuser.php', vlMakeQuery($params, $domainPasswordOverride));
	}

     
    function vlDeleteAllFriends($id)
    {
        $params = Array(
            'login' => $id
        );
        return ServerUtil::post('http://visuland.com/servlet/deleteallfriend', vlMakeQuery($params));
    }

     
    function vlSetFriends($id, $friends)
    {
        $params = Array(
            'login' => $id,
            'friends' => implode(',', is_array($friends) ? $friends : Array())
        );
        return ServerUtil::post('http://visuland.com/servlet/setfriend', vlMakeQuery($params));
    }


	function vlPrintParam($key, $value)
	{
		echo('<input type="hidden" id="'.htmlentities($key).'" value="'.htmlentities($value).'"/>');
	}

?>