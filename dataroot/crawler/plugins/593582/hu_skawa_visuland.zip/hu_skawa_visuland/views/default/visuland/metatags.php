<?php 
	global $CONFIG;
?>

<link rel="stylesheet" type="text/css" href="<?php echo $CONFIG->wwwroot; ?>mod/hu_skawa_visuland/_css/visuland.css" />
<script type="text/javascript" src="<?php echo $CONFIG->wwwroot; ?>mod/hu_skawa_visuland/js/jquery.validate.min.js"></script>