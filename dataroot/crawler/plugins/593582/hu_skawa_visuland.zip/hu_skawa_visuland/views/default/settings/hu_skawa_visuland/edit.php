<?php 

	extend_view('metatags','visuland/metatags');

	$current_dpw = $vars['entity']->domain_password;

	$url = 'http://visuland.com/servlet/location?'.vlMakeQuery(Array('format'=>'json', 'domain_filter' => 'false'), $current_dpw);
//	echo('<!-- '.$url.' -->');
//	$url = 'http://visuland.com/servlet/location?format=json';
	$handle = curl_init($url);
	curl_setopt($handle, CURLOPT_RETURNTRANSFER, 1);
	$reply = curl_exec($handle);
	curl_close($handle);

//	echo('<!-- '.$reply.' '.json_encode($current_location).' -->');
	$locations = json_decode($reply);
	$indexed_locations = array();
	foreach ($locations as $location) {
		$indexed_locations[$location->id] = $location;
	}

	$current_location = $vars['entity']->location_id;
	if (!$current_location) $current_location = $locations[0]->id;
	$current_preview = $indexed_locations[$current_location]->thumbImageUrl;
	$current_access = $vars['entity']->access;
	if (!$current_access) $current_access = 'private';
	
	
	
	$js_locations = json_encode($indexed_locations);

?>
<script type="text/javascript">
jQuery(document).ready(function($) {

	var locations = eval('(' + '<?php echo $js_locations; ?>' + ')');
	$('#location_id').change(function() {
        var selected_id = $("option:selected", this).val();
        var src = locations[selected_id].thumbImageUrl;
        $("#worldPreview").html('<img title="World preview" alt="World Preview" src="' + src + '" />');
        $('#location_thumbnail').val(src);
    });
    
});
</script>

<div id="visuland-settings">
	<div class="settings-item">
		<span class="settings-label"><?php echo elgg_echo('visuland:admin:select_world'); ?></span>
		<span class="settings-element">
			<select name="params[location_id]" id="location_id">
			<?php 
				foreach ($indexed_locations as $location) {
					echo "<option value=\"$location->id\"".($current_location == $location->id ? " selected=\"yes\">":">")."$location->name</option>";
				}	
			?>
			</select>
			<input type="hidden" name="params[location_thumbnail]" id="location_thumbnail" value="<?php echo $current_preview; ?>"></input>
		</span>
		<span id="worldPreview">
			<img src="<?php echo $current_preview; ?>" title="World preview" alt="World Preview"></img>
		</span>
	</div>
	
<?php /* WTF? */
	if(false) {
?>
	<div class="settings-item">
		<span class="settings-label"><?php echo elgg_echo('visuland:admin:access'); ?></span>
		<span class="settings-element">
			<select name="params[access]">
			<?php 
				$access_levels = array('private','public');
				foreach ($access_levels as $access) {
					$access_text = elgg_echo('visuland:admin:' .  $access);
					echo "<option value=\"$access\"".($current_access == $access ? " selected=\"yes\">":">")."$access_text</option>";
				}	
			?>
			</select>
		</span>
	</div>
<?php
	}
?>
<div class="visuland_clear"></div>
	<div class="settings-item">
		<span class="settings-label"><?php echo elgg_echo('visuland:admin:domain_password'); ?></span>
		<span class="settings-element">
			<input type="password" name="params[domain_password]" value="<?php echo htmlentities($current_dpw); ?>"/>
			<input type="checkbox" onclick="this.parentNode.getElementsByTagName('input').item(0).type = this.checked ? 'text' : 'password'"/>
			<?php
				echo elgg_echo('visuland:admin:unmask');
			?>
		</span>
	</div>
<div class="visuland_clear"></div>
	<div class="settings-item">
			<?php
				echo str_replace(':domain:', vlGetDomain(), elgg_echo('visuland:admin:info'));
			?>
	</div>
</div>
<div class="visuland_clear"></div>
