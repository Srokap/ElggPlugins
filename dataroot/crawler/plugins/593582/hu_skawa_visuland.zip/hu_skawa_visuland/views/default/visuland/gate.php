<?php 

	/**
	 * Visuland 3D VR community plugin
	 * 
	 * @package None
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Andr�s Szepesh�zi
	 * @copyright Skawa Ltd 2010
	 * @link http://www.skawa.com/
	 */

	global $CONFIG;
	
	extend_view('metatags','visuland/metatags');
	$user = $vars['user'];
	$ts = time();
	$token = generate_action_token($ts);
	
	$location_thumbnail = get_plugin_setting('location_thumbnail');
	if (!$location_thumbnail) {
		$url = 'http://visuland.com/servlet/location?'.vlMakeQuery(Array('format'=>'json'));
		$handle = curl_init($url);
		curl_setopt($handle, CURLOPT_RETURNTRANSFER, 1);
		$reply = curl_exec($handle);
		curl_close($handle);
	
		$locations = json_decode($reply);
		$location_thumbnail = $locations[0]->thumbImageUrl;
		set_plugin_setting('location_thumbnail', $location_thumbnail);		
	}
	
?>
<script type="text/javascript">
	jQuery(document).ready(function($) {

		jQuery.validator.addMethod(
			"huDate",
			function(value, element) {
				if (value == '') return true;
				else return value.match(/^\d\d\d\d\.\d\d?.\d\d?$/);
			},
			"Please enter a date in the format YYYY.MM.DD"
		);

		$('#visuland_reg').validate({
	        rules: {
	            birthdate: {
	                huDate: true
	            }
			}
	    });
	});
</script>

<div id="visuland_header">
	<span><img src="<?php echo $location_thumbnail; ?>" alt="World preview" title="World preview"></img></span>
	<span><?php echo elgg_echo('visuland:welcome'); ?></span>
</div>
<div class="visuland_clear"></div>
<hr />
<div id="visuland_form">
	<form name="visuland_reg" id="visuland_reg" action="<?php echo $CONFIG->wwwroot; ?>action/visuland/register" method="post">
		<p>
			<label for="nick" class="label_required"><?php echo elgg_echo('visuland:register:nick'); ?></label>
			<input type="text" class="required" name="nick" id="nick" value="<?php echo $user->name; ?>"></input>
		</p>
		<p>
			<label for="gender" class="label_required"><?php echo elgg_echo('visuland:register:gender'); ?></label>
			<select  class="required" name="gender" id="gender">
				<option value="male"><?php echo elgg_echo('visuland:register:male')?></option>
				<option value="female"><?php echo elgg_echo('visuland:register:female')?></option>
			</select>
		</p>
		<p>
			<label for="birthdate"><?php echo elgg_echo('visuland:register:birthdate'); ?></label>
			<input type="text" name="birthdate" id="birthdate"></input>
		</p>
		<p>
			<label for="city"><?php echo elgg_echo('visuland:register:city'); ?></label>
			<input type="text" name="city" id="city"></input>
		</p>
		<p>
			<label for="country"><?php echo elgg_echo('visuland:register:country'); ?></label>
			<?php echo elgg_view('input/country', array('internalid' => 'country', 'internalname' => 'country')); ?>
		</p>
		<p>
			<span class="licence_label"><?php echo elgg_echo('visuland:register:licence'); ?></span>
				<?php echo elgg_echo('visuland:register:licence_text');?>
			<div style="clear: both;"></div>
		</p>
		<p class="accept">
			<label for="accept" class="accept"><?php echo elgg_echo('visuland:register:licence_accept'); ?></label>
			<input type="checkbox" class="required" name="accept" id="accept"></input>
		</p>
		<p>
			<input type="hidden" name="__elgg_ts" value="<?php echo $ts; ?>"></input>
			<input type="hidden" name="__elgg_token" value="<?php echo $token; ?>"></input>
			<input type="submit" value="<?php echo elgg_echo('visuland:enter'); ?>"></input>
		</p>		
	</form>
</div>