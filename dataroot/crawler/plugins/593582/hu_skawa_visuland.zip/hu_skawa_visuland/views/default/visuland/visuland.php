<?php 

	/**
	 * Elgg Visuland 3D community page
	 *
	 * @package None
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Andr�s Szepesh�zi
	 * @copyright Skawa Ltd 2010
	 * @link http://www.skawa.com/
	 */
	
	$user = $vars['user'];
	$location_id = get_plugin_setting('location_id');
	if (!$location_id) {
		$url = 'http://visuland.com/servlet/location?'.vlMakeQuery(Array('format' => 'json'));
		$handle = curl_init($url);
		curl_setopt($handle, CURLOPT_RETURNTRANSFER, 1);
		$reply = curl_exec($handle);
		curl_close($handle);
	
		$locations = json_decode($reply);
		$location_id = $locations[0]->id;
		set_plugin_setting('location_id', $location_id);		
	}
	
	$result = vlSetUser($user->visuland_id, $user->visuland_password);
	$result = json_decode($result);
	if($result === null)
		return;
	
	$sessionId = $result->s;
	
	$friends = get_user_friends(get_loggedin_userid());
	$ids = Array();
	for($i=0; $i<count($friends); $i++)
	{
		$obj = $friends[$i];
		if($obj->visuland_id)
		{
			$ids[] = $obj->visuland_id;
		}
	}
	$friends = null;
	echo('<!-- '.json_encode(vlDeleteAllFriends($user->visuland_id)).' -->');
	echo('<!-- '.json_encode(vlSetFriends($user->visuland_id, $ids)).' -->');
	

//	$pluginParams = '-domain="'.vlGetDomain().'" -user="'.$user->visuland_id.'" -pass="'.$user->visuland_password.'" -autojoinloc='.$location_id;
	
//	$pluginParams = htmlentities($pluginParams);

	vlPrintParam('vlLocation', $location_id);
	vlPrintParam('vlShowSelector', 0);
	vlPrintParam('vlLoginForm', 'USER');
	vlPrintParam('vlSession', $sessionId);

	echo('<iframe id="visulandView" src="http://iframe.visuland.com/empty.html" frameborder="0" marginwidth="0" marginheight="0"
		width="730" height="599" scrolling="no"
		style="display: none;"></iframe>');
	echo('<script type="text/javascript"> 
			/*Load jQuery if not already loaded*/ if(typeof jQuery == "undefined"){ document.write("<script type=\"text/javascript\"   src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js\"></"+"script>"); var __noconflict = true; } 
		</script>');
//	echo('<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>');
	echo('<script type="text/javascript" src="http://iframe.visuland.com/js/iframe.js"></script>');
	if(false) {
?>

<script type="text/javascript">
jQuery(document).ready(function($) {
	var supported = ((jQuery.browser.msie && parseInt(jQuery.browser.version) >= 7) || (jQuery.browser.mozilla)); 
	jQuery.each(jQuery.browser, function(i, val) {
		if (val == true) current_browser = i;
	});

	if (!supported)  {
		$('#visuland_content').html("<?php echo elgg_echo('visuland:browser:not_supported'); ?>");	
	} else if (current_browser == 'mozilla') {
		var pluginInstalled = false;
		$.each(navigator.plugins, function(index, item) {
			if (item.name == "VisuLand ActiveX hosting plugin for Firefox") {
				pluginInstalled = true;
			}
		});
		
		if (!pluginInstalled) {
			$('#visuland_content').html("<?php echo elgg_echo('visuland:plugin:not_installed'); ?>");
			var xpi=new Object();
			xpi['axhost-visuland'] = 'http://bagira.iit.bme.hu/~szecsi/visuland/npffaxvl.xpi';
			InstallTrigger.install(xpi,function() {
				$('#visuland_content').html("<?php echo elgg_echo('visuland:plugin:installed'); ?>");
			});
		} else {
			$('#visuland_content').html('<OBJECT type="application/x-itst-activex-visuland" id="Control" CodebaseURL="http://bagira.iit.bme.hu/~szecsi/visuland/visuland.cab" logger="logger" debugLevel="5" height="600" width="800" clsid="{122E0369-9BFA-4B26-BD7A-26E9993B9096}" ALIGN="baseline" BORDER="0" param_arguments="'+<?php echo(json_encode($pluginParams)); ?>+'"></OBJECT>');
		} 
	}
});
</script>

<div id="visuland_content">
<!--[if gte IE 7]>
<OBJECT ID="VisuLandActiveXControlWindowed" CLASSID="CLSID:122E0369-9BFA-4B26-BD7A-26E9993B9096" WIDTH="800" HEIGHT="600" CodeBase="visuland.cab"><param name="arguments" value="<?php echo($pluginParams); ?>></OBJECT>
<![endif]-->
</div>

<?php
	} /* if(false) { */
?>