<?php 

	global $CONFIG;
	
	gatekeeper();
	
	$user = get_loggedin_user();

	// Auto-register if this is the first time entry for the user
	if (!isset($user->visuland_id)) {
		// Create personal properties for visuland as metadata
/*		$siteroot = $CONFIG->wwwroot;
		$siteroot = str_replace('http://','',$siteroot);
		$siteroot = rtrim($siteroot, '/');
*/		$user->visuland_id = $user->username;
		$visuland_password = md5(mt_rand());
		$user->visuland_password = substr($visuland_password,0,8);
		$user->nick = get_input('nick', $user->name);
		$user->gender = get_input('gender', 'male');
		if ($birthdate = get_input('birthdate', null)) {
			$user->birthdate = $birthdate;
		}
		if ($city = get_input('city', null)) {
			$user->city = $city;
		}
		if ($country = get_input('country', null)) {
			$user->country = $country;
		}
		$user->save();
		
		// Now register the user with the visuland server using curl
		$data = array(
			'login' => $user->visuland_id,
			'password' => $user->visuland_password,
			'name' => $user->nick,
			'gender' => ($user->gender == 'male' ? 'M' : 'F'),
			// 'domainkey' => $CONFIG->wwwroot
		);
		if (isset($user->birthdate)) $data['born'] = $user->birthdate;
		if (isset($user->city)) $data['city'] = $user->city;
		if (isset($user->country)) $data['country'] = $user->country;
		
		$reg_url = 'http://visuland.com/servlet/registeruser';
		// $reg_url = 'http://visuland.skawa.tld/posttest.php';
		
/*		$params = '';
		foreach ($data as $key => $value) {
			//$params .= urlencode($key) . '=' . urlencode($value) . '&';
			$params .= $key . '=' . $value . '&';
		}
		$params = rtrim($params, '&');
*/
		$params = vlMakeQuery($data);
		$handle = curl_init($reg_url);
		curl_setopt($handle, CURLOPT_POST, true);
		curl_setopt($handle, CURLOPT_POSTFIELDS, $params);
		curl_setopt($handle, CURLOPT_RETURNTRANSFER, 1);
		$reply = curl_exec($handle);
		if ($reply == 'OK') {
			system_message(elgg_echo('visuland:register:success'));
		} else {
			error_log('Request url: '. $req_url);
			error_log('Request params: '. $params);
			error_log('Server reply: ' . $reply);
			error_log('curl getinfo: ' . print_r(curl_getinfo($handle),1));
			error_log('curl error: ' . print_r(curl_error($handle),1));
			// Remove visuland properties upon unsuccessful registration
			unset($user->visuland_id);
			unset($user->visuland_password);
			unset($user->gender);
			unset($user->nick);
			unset($user->birthdate);
			unset($user->city);
			unset($user->country);
			$user->save();
			system_message(elgg_echo('visuland:register:failure'). ' ' . $reply.' ('.vlGetDomain().')');
		}
		curl_close($handle);
	}
	
	forward($_SERVER['HTTP_REFERER']);
?>