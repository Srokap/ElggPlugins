<?php
/* LiangLee Zhuye
 * FrameWork for Liang Lee Plugins
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @package LiangLeeFramework( LEFW )
 * @subpackage LiangLee Zhuye
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File settings.php
 */
/**
* Get Veersion
**/
$plug_ver = LiangLee_version('LiangLeeZhuye');
$plug_rel = LiangLee_release('LiangLeeZhuye');


/**
* Load Languages
**/
$liang_lee_Zhuye_copytights = elgg_echo('lianglee:copyr:12');
$title = elgg_echo('llee:zhuye:settings');
$lleesettings = elgg_echo('llee:zhuye:settings');
$liang_lee_Zhuye_label = elgg_echo('llee:zhuye:h1');
$liang_lee_Zhuye__html_label = elgg_echo('llee:html:label');
$liang_lee_Zhuye__cmi_label = elgg_echo('llee:cmi:label');
/**
* Save settings
**/
$liang_lee_Zhuye = elgg_view('input/dropdown', array(
    'name' => 'params[liang_lee_zh]',
    'value' => $vars['entity']->liang_lee_zh,
    'options_values' => array('limage' => 'Default image', 'customhtml' => 'Custom Html code', 'cmi' => 'Custom image url')
        ));		
$liang_lee_Zhuye_1 = elgg_view("input/longtext", array(
"name" => "params[LiangLeeZhuye_html]", 
"value" => $vars['entity']->LiangLeeZhuye_html));

$liang_lee_Zhuye_2 = elgg_view("input/text", array(
"name" => "params[LiangLeeZhuye_cmi]", 
"value" => $vars['entity']->LiangLeeZhuye_cmi));	
		
/**
* Setting Page
**/
$settings = <<<__HTML

    <h3>$lleesettings</h3>
    <div>
	
        <p><i>$liang_lee_Zhuye_label</i><br>$liang_lee_Zhuye</p>
		<p><i>$liang_lee_Zhuye__html_label</i><br>$liang_lee_Zhuye_1</p>
		<p><i>$liang_lee_Zhuye__cmi_label</i><br>$liang_lee_Zhuye_2</p>
		<hr>
		<p><i>$liang_lee_Zhuye_copytights</i>

		<p>Release: $plug_rel</p>
		<p>Version: $plug_ver</p>
    </div>
    
</div>
__HTML;
echo $settings;