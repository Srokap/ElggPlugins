<?php
/* LiangLee zhuye
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @package LiangLeeFramework
 * @subpackage LiangLee Zhuye
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File custom_index.php 
 */

/**
* Setting up global Varables.
* @global $Le_Zhuye_htmlcode,$Le_Zhuye_cmi
* @ascess public
**/
global 	$Le_Zhuye_htmlcode;
global $Le_Zhuye_cmi;

/**
* include custom images, html etc.
**/
LiangLee_include('LiangLeeZhuye','lib/LiangLeeZhuye');
LiangLeeZhuye_lib();


echo "<table width=\"976\" border=\"0\">\n"; 
echo "  <tr>\n"; 
echo "    <td width=\"257\" height=\"114\" background=\"\n";
echo elgg_get_site_url();
echo "mod/LiangLeeZhuye/media/rg.jpg\">\n";?>
<?php 
/**
* Load login mod
**/
LiangLee_view('LiangleeFramework', 'forms/login');
?>
<?php
echo "  <p>&nbsp;</p></td>\n"; 
echo "    <td width=\"8\">&nbsp;</td>\n"; 
echo "    <th width=\"399\">\n";

/**
* Get settings 
**/
if (!elgg_get_plugin_setting('liang_lee_zh', 'LiangLeeZhuye')) {
LiangLee_img('LiangLeeZhuye','LiangLeeZhuye-1.jpg');
}
if (elgg_get_plugin_setting('liang_lee_zh', 'LiangLeeZhuye') == 'limage') {
LiangLee_img('LiangLeeZhuye','LiangLeeZhuye-1.jpg');
}
if (elgg_get_plugin_setting('liang_lee_zh', 'LiangLeeZhuye') == 'customhtml') {
echo $Le_Zhuye_htmlcode
?>
<?php } ?>
<?php if (elgg_get_plugin_setting('liang_lee_zh', 'LiangLeeZhuye') == 'cmi') {
echo "    <img src=\"\n";
echo $Le_Zhuye_cmi?>
<?php echo "\" width=\"408\" height=\"390\"/>\n";
?>
<?php } ?><?php
echo "&nbsp;</p>    </th>\n"; 
echo "    <td width=\"284\" background=\"\n";
echo elgg_get_site_url();
echo "mod/LiangLeeZhuye/media/rg.jpg\">\n";
LiangLee_view('LiangleeFramework', 'forms/reg');
echo "</td>\n"; 
echo "  </tr>\n"; 
echo "</table>\n";
/**
* End of settings
**/
?>
<!-- Author:Liang Lee Zhuye !-->