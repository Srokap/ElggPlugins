<?php
/* LiangLee Zhuye
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @package LiangLeeFramework
 * @subpackage LiangLee Zhuye
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File start.php 
 */

elgg_register_event_handler('init', 'system', 'LiangLeeZhuye');

function LiangLeeZhuye() {

if (!elgg_is_active_plugin('LiangleeFramework')) {
 if (elgg_is_admin_logged_in()) {
 register_error(elgg_echo('lianglee:framewrok:miss'));
 } else {
 register_error(elgg_echo('lianglee:framewrok:miss:code'));	
     }
    }  
  }
?>