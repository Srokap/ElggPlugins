<?php
if($LiangLeeZhuye_html = elgg_get_plugin_setting("LiangLeeZhuye_html", "LiangLeeZhuye")){
	$Le_Zhuye_htmlcode = $LiangLeeZhuye_html;
}
if($LiangLeeZhuye_cmi = elgg_get_plugin_setting("LiangLeeZhuye_cmi", "LiangLeeZhuye")){
	$Le_Zhuye_cmi = $LiangLeeZhuye_cmi;
}

?>