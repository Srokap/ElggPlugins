<?php
/* LiangLee Zhuye
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @package Liang Lee Zhuye
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File LiangLeeZhuye.php 
 */
 

function LiangLeeZhuye_lib(){

global 	$Le_Zhuye_htmlcode;
global $LiangLeeZhuye_html;
global $LiangLeeZhuye_cmi;
global $Le_Zhuye_cmi;

if($LiangLeeZhuye_html = elgg_get_plugin_setting("LiangLeeZhuye_html", "LiangLeeZhuye")){
	$Le_Zhuye_htmlcode = $LiangLeeZhuye_html;
}
if($LiangLeeZhuye_cmi = elgg_get_plugin_setting("LiangLeeZhuye_cmi", "LiangLeeZhuye")){
	$Le_Zhuye_cmi = $LiangLeeZhuye_cmi;
  }
}