<?php
/* LiangLee Zhuye
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @package Liang Lee Framework
 * @subpackage LiangLee Zhuye
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File version.php 
 */

$LiangLee_version = 28062012;
$LiangLee_release = '1.1.0';
?>
