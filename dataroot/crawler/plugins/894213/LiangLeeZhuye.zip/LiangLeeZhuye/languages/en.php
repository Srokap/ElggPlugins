<?php
/* LiangLee Zhuye
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @package Liang Lee Framework
 * @subpackage LiangLee Zhuye
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File en.php 
 */

$english = array(
	'llee:zhuye:settings' => 'Liang Lee Zhuye Settings.',
	'llee:zhuye:h1' => 'What you want on middle of page Custom html. custom image url or default image? select below:',
	'llee:Zhuye:package' => 'Liang Lee Zhuye.',
	'llee:zhuye:leecopy' => 'All right reserved Liang Lee 2012.',
	'llee:html:label' => 'You can enter You text here below:',
	'llee:cmi:label' => 'If you want a custom image enter url below and the image width=408 height=390 example http://www.youwebsite.com/image.jpg:',


);

add_translation('en', $english);
