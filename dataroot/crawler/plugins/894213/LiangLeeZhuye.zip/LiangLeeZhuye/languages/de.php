<?php
/* LiangLee Zhuye
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @package Liang Lee Framework
 * @subpackage LiangLee Zhuye
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File de.php German Language by Nudeler2 http://community.elgg.org/pg/profile/Nudeler2
 */

$german = array(
	'llee:zhuye:settings' => 'Liang Lee Zhuye Einstellungen.',
	'llee:zhuye:h1' => 'Was Sie wollen, in der Mitte der Seite Benutzerdefinierte HTML. benutzerdefiniertes Bild URL oder Standard-Image? Wählen Sie unten:',
	'llee:Zhuye:package' => 'Liang Lee Zhuye.',
	'llee:zhuye:leecopy' => 'Alle Rechte vorbehalten Liang Lee 2012.',
	'llee:html:label' => 'Sie können Sie Text hier unten ein:',
	'llee:cmi:label' => 'Wenn Sie möchten, geben Sie ein benutzerdefiniertes Bild URL und das Bild width = 408 height = 390 http://www.youwebsite.com/image.jpg Beispiel:',

);

add_translation('de', $german);
