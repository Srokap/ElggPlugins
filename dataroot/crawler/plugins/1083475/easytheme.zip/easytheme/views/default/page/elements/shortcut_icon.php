<link rel="SHORTCUT ICON" href="<?php echo $vars['url']; ?>mod/easytheme/graphics/favicon.ico" />
                 

