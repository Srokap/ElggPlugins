<?php
/**
 * EasyTheme
 *
 * Contains CSS for EasyTheme
 *
 */
include_once elgg_get_data_path() . "easytheme/cssinc.php";


