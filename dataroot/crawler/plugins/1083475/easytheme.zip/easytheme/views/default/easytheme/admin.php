<?php
/**
 * EasyTheme
 *
 * Contains CSS for EasyTheme Admin section
 *
 */
?>

em{
	color: #999;
}
	

.et-admin-red{
 	color: red;
}
	

