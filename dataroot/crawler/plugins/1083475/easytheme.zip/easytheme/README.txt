Easy Theme
**********

!Important: This theme cannot be used 'out of the box'. Fill in the 'settings' form, SAVE, and the theme will now work.  

Note: Adding a "Site Introduction" requires the "Custom Index" plugin.

This theme is intended as a starting point, I don't expect you to use the design as it is. It is easy to change each section of the theme to match an existing website design, or to create a new design. However, you can start by using the default values and work from there. (Enable the default settings by going to the settings page and saving.)

_________________________________________________________________________________________________________
To be informed of updates - and new themes - please subscribe to my blog at http://www.jubo.co.uk/blog/.
********************************************************************************************************* 


