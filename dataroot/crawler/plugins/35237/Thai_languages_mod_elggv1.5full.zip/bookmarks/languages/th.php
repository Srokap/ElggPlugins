﻿<?php
                 /**
	         * @package languages For Bookmarks
	         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	         * @author Laithai Team <webmaster@lungkao.com.com>
	         * @copyright Laithai Team 2008-2009
	         * @link http://elgg.in.th/
                 */  

	$thai = array(

		/**
		 * Menu items and titles
		 */

			'bookmarks' => "บุ๊คมาร์ค",
			'bookmarks:add' => "บางส่วนที่บุ๊คมาร์คไว้",
			'bookmarks:read' => "รายการบุ๊คมาร์ค",
			'bookmarks:friends' => "บุ๊คมาร์คของเพื่อน",
			'bookmarks:everyone' => "บุ๊คมาร์คทั้งหมด",
			'bookmarks:this' => "บุ๊คมาร์ค",
			'bookmarks:bookmarklet' => "รับบุ๊คมาร์ค",
			'bookmarks:inbox' => "รายการบุ๊คมาร์ค",
			'bookmarks:more' => "รายการบุ๊คมาร์คอื่นๆ",
			'bookmarks:shareditem' => "รายการบุ๊คมาร์ค",
			'bookmarks:with' => "แบ่งปันโดย",
			'bookmarks:new' => "บุ๊คมาร์คใหม่",
			'bookmarks:via' => "บุ๊คมาร์คเก่า",
			'bookmarks:address' => "ที่อยู่ของบุ๊คมาร์ค",

			'bookmarks:delete:confirm' => "แน่ใจไหมที่จะลบ?",

			'bookmarks:numbertodisplay' => 'จำนวนของบุ๊คมาร์คที่ต้องการแสดง',

			'bookmarks:shared' => "บุ๊คมาร์ค",
			'bookmarks:visit' => "ไปดูข้อมูล",
			'bookmarks:recent' => "บุ๊คมาร์คล่าสุด",

			'bookmarks:river:created' => '%s บุ๊คมาร์ค',
			'bookmarks:river:annotate' => '%s แสดงความคิดเห็นใน',
			'bookmarks:river:item' => 'รายการ',

			'item:object:bookmarks' => 'รายการบุ๊คมาร์ค',


		/**
		 * More text
		 */

		    'bookmarks:widget:description' =>
		            "เครื่องมือนี้ได้รับการออกแบบเพื่อกระดานข้อมูลของคุณและจะแสดงรายการล่าสุดในบุ๊คมาร์คของคุณ",

			'bookmarks:bookmarklet:description' =>
					"บุ๊คมาร์คช่วยให้คุณสามารถแบ่งปันทรัพยากรใดๆที่คุณพบในเว็บกับเพื่อนของคุณ:",

	        'bookmarks:bookmarklet:descriptionie' =>
					"ถ้าคุณใช้ Internet Explorer, คุณต้องคลิ๊กขวาทไอคอนบุ๊คมาร์ค, เลือก'add to favorites",

			'bookmarks:bookmarklet:description:conclusion' =>
					"คุณสามารถบันทึกหน้าใดก็ได้ที่คุณแวะไปชมโดยการคลิกนั้นเมื่อใดก็ได้.",

		/**
		 * Status messages
		 */

			'bookmarks:save:success' => "รายการนี้ได้บุ๊คมาร์คแล้ว",
			'bookmarks:delete:success' => "บุ๊คมาร์คถูกลบแล้ว",

		/**
		 * Error messages
		 */

			'bookmarks:save:failed' => "บุ๊คมาร์คของคุณ ไม่สามารถบันทึก โปรดลองอีกครั้ง",
			'bookmarks:delete:failed' => "บุ๊คมาร์คของคุณ ไม่สามารถลบ โปรดลองอีกครั้ง",


	);

	add_translation("th",$thai);

?>
