﻿<?php
                 /**
	         * @package languages For log browser 
	         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	         * @author Laithai Team <webmaster@lungkao.com.com>
	         * @copyright Laithai Team 2008-2009
	         * @link http://elgg.in.th/
                 */  

	$thai = array(

			/**
		 * Menu items and titles
		 */

			'logbrowser' => 'ระบบ LOG',
			'logbrowser:browse' => 'เบราส์ระบบ log',
			'logbrowser:search' => 'ตั้งค้าการค้นหา',
			'logbrowser:user' => 'ชื่อสมาชิกค้นหาโดย',
			'logbrowser:starttime' => 'เวลา (เช่น "last monday", "1 ที่แล้ว")',
			'logbrowser:endtime' => 'เวลาสิ้นสุด',

			'logbrowser:explore' => 'สำรวจ log',

	);

	add_translation("th",$thai);

?>
