﻿<?php
                 /**
	         * @package languages For Custom Index 
	         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	         * @author Laithai Team <webmaster@lungkao.com.com>
	         * @copyright Laithai Team 2008-2009
	         * @link http://elgg.in.th/
                 */  

$thai = array(
	
			'custom:bookmarks' => "บุ๊คมาร์คล่าสุด",
		    'custom:groups' => "กลุ่มล่าสุด",
			'custom:files' => "ไฟล์ล่าสุด",
			'custom:blogs' => "บล๊อกล่าสุด",
			'custom:members' => "สมาชิกใหม่",
			'custom:nofiles' => "ยังไม่มีไฟล์",
			'custom:nogroups' => "ยังไม่มีไฟล์",	
	
	);
					
	add_translation("th",$thai);

?>
