﻿<?php
                 /**
	         * @package languages For ฌroups 
	         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	         * @author Laithai Team <webmaster@lungkao.com.com>
	         * @copyright Laithai Team 2008-2009
	         * @link http://elgg.in.th/
                 */  

	$thai = array(

		/**
		 * Menu items and titles
		 */

                        'groups' => "กลุ่ม",
			'groups:owned' => "กลุ่มที่คุณเป็นเจ้าของ",
			'groups:yours' => "กลุ่มที่สังกัด",
			'groups:user' => "กลุ่ม %s",
			'groups:all' => "กลุ่มทั้งหมด",
			'groups:new' => "สร้างกลุ่มใหม่",
			'groups:edit' => "แก้ไข รายละเอียด",
			'groups:delete' => 'ลบกลุ่ม',
			'groups:membershiprequests' => 'จัดการคำขอเข้าร่วม',
	
			'groups:icon' => 'รูปของกลุ่ม (ว่างไว้ได้หากไม่มี)',
			'groups:name' => 'ชื่อกลุ่ม',
			'groups:username' => 'ชื่อสั้นๆของกลุ่ม (ใช้แสดงใน url ควรใช้ภาษาอังกฤษ)',
			'groups:description' => 'รายละเอียด',
			'groups:briefdescription' => 'รายละเอียดย่อ',
			'groups:interests' => 'ความสนใจ',
			'groups:website' => 'เว็บไซต์',
			'groups:members' => 'สมาชิกของกลุ่ม',
			'groups:membership' => "สมาชิก",
			'groups:access' => "การเข้าถึง",
			'groups:owner' => "เจ้าของ",
	        'groups:widget:num_display' => 'หมายเลขของกลุ่มที่จะแสดง',
	        'groups:widget:membership' => 'สมาชิกของกลุ่ม',
	        'groups:widgets:description' => 'แสดงกลุ่มและสมาชิกในหน้าโปรไฟลื',
			'groups:noaccess' => 'คุณไม่มีสิทธิเข้าถึงกลุ่มนี้',
			'groups:cantedit' => 'คุณไม่สามารถแก้ไขกลุ่มได้',
			'groups:saved' => 'บันทึกกลุ่ม',
			'groups:featured' => 'กลุ่มที่เราแนะนำ',
			'groups:makeunfeatured' => 'ยกเลิกการแนะนำ',
			'groups:makefeatured' => 'เพิ่มเป็นกลุ่มแนะนำ',
			'groups:featuredon' => 'คุณได้ทำให้กลุ่มนี้เป็นกลุ่มแนะนำ',
			'groups:unfeature' => 'กลุ่มถูกกลบออกจากกลุ่มแนะนำ',
			'groups:joinrequest' => 'ขอเป็นสมาชิก',
			'groups:join' => 'สมัครเข้ากลุ่ม',
			'groups:leave' => 'ออกจากกลุ่ม',
			'groups:invite' => 'ชวนเพื่อน',
			'groups:inviteto' => "ชวนเพื่อน '%s'",
			'groups:nofriends' => "คุณยังไม่มีเพื่อน",
			'groups:viagroups' => "กลุ่มอื่นๆ",
			'groups:group' => "กลุ่ม",

			'groups:notfound' => "ไม่พบกลุ่มนี้",
			'groups:notfound:details' => "กลุ่มที่ขอเป็นสมาชิกไม่มีหรือคุณไม่สามารถเข้าถึงมัน",
			
			'groups:requests:none' => 'ไม่มีสมาชิกที่ค้างคำขอได้ในขณะนี้',
	
			'item:object:groupforumtopic' => "หัวข้อสนทนา",
	
			'groupforumtopic:new' => "หัวข้อสนทนาบันทึกแล้ว",
			
			'groups:count' => "สร้างกลุ่มแล้ว",
			'groups:open' => "กลุ่มเปิด",
			'groups:closed' => "กลุ่มปิด",
			'groups:member' => "สมาชิก",
			'groups:searchtag' => "ค้นหากลุ่มโดบแท็ก",
	
			
			/*
			 * Access
			 */
			'groups:access:private' => 'ปิด - ผู้ใช้จะต้องได้รับเชิญ',
			'groups:access:public' => 'เปิด- ทุกคนเข้าร่วมได้',
			'groups:closedgroup' => 'กลุ่มนี้มีปิดเข้าได้เฉพาะสมาชิก ในการขอเข้ากลุ่มให้คลิกที่ "ขอเป็นสมาชิก" ',
	
			/*
			   Group tools
			*/
			'groups:enablepages' => 'เปิดการใช้งานเนื้อหา',
			'groups:enableforum' => 'เปิดการใช้ระบบสนทนา',
			'groups:enablefiles' => 'เปิดการใช้ไฟล์',
			'groups:yes' => 'ใช่',
			'groups:no' => 'ไม่',
	
			'group:created' => 'สร้าง %s โดย %d ',
			'groups:lastupdated' => 'อัพเดตล่าสุด %s โดย %s',
			'groups:pages' => 'เนื้อหาของกลุ่ม',
			'groups:files' => 'ไฟล์ของกลุ่ม',
			/*
			  Group forum strings
			*/

			'group:replies' => 'ตอบกลัับ',			
                        'groups:forum' => 'ห้องสนทนาของกลุ่ม',
			'groups:addtopic' => 'เพิ่มหัวข้อ',
			'groups:forumlatest' => 'ล่าสุดในห้องสนทนา',
			'groups:latestdiscussion' => 'การสนทนาล่าสุด',
			'groups:newest' => 'ใหม่สุด',
			'groups:popular' => 'ได้รับความนิยม',
			'groupspost:success' => 'ความคิดเห็นของคุณบันทึกแล้ว',
			'groups:alldiscussion' => 'การสนทนาล่าสุด',
			'groups:edittopic' => 'แก้ไขหัวข้อ',
			'groups:topicmessage' => 'หัวข้อของข้อความ',
			'groups:topicstatus' => 'สถานะของข้อความ',
			'groups:reply' => 'เขียนความคิดเห็น',
			'groups:topic' => 'หัวข้อ',
			'groups:posts' => 'เขียน',
			'groups:lastperson' => 'ผู้เขียนล่าสุด',
			'groups:when' => 'ที่',
			'grouptopic:notcreated' => 'ยังไม่มีหัวข้อ',
			'groups:topicopen' => 'เปิด',
			'groups:topicclosed' => 'ปิด',
			'groups:topicresolved' => 'ตัดสินแล้ว',
			'grouptopic:created' => 'หัวข้อของคุณสร้างแล้ว',
			'groupstopic:deleted' => 'หัวข้อของคุณลบแล้ว',
			'groups:topicsticky' => 'ยึดหัวข้อ',
			'groups:topicisclosed' => 'หัวข้อนี้ปิดแล้วแล้ว',
			'groups:topiccloseddesc' => 'หัวข้อนี้ปิดแล้วแล้วไม่สามารถแสดงความคิดเห็นได้',
			'grouptopic:error' => 'ไม่สามารถเพิ่มกระทู้ได้กรุณาติดต่อผู้ดูแล',
			'groups:privategroup' => 'กลุ่มนี้เป็นกลุ่มส่วนตัว, คุณต้องส่งคำขอเพื่อเข้ากลุ่ม',
			'groups:notitle' => 'กลุ่มไม่มีชื่อ',
			'groups:cantjoin' => 'ไม่สามารถเข้าร่วมกลุ่มได้',
			'groups:cantleave' => 'ไม่สามารถออกจากกลุ่มได้',
			'groups:addedtogroup' => 'สมาชิกเข้ากลุ่มเรียบร้อยแล้ว',
			'groups:joinrequestnotmade' => 'การร้องขอไม่สามารถทำได้',
			'groups:joinrequestmade' => 'เข้ากลุ่มแล้ว',
			'groups:joined' => 'เข้ากลุ่มแล้ว!',
			'groups:left' => 'ออกจากกลุ่มแล้ว',
			'groups:notowner' => 'เสียใจ, คุณไม่ใช่เจ้าของกลุ่ม',
			'groups:alreadymember' => 'คุณเป็นสมาชิกของกลุ่มแล้ว!',
			'groups:userinvited' => 'สมาชิกส่งคำขอมา',
			'groups:usernotinvited' => 'สมาชิกไม่สามารถส่งคำขอได้',
			'groups:updated' => "ความคิดเห็นล่าสุด",
			'groups:invite:subject' => "%s คุณได้รับคำเชิญเพื่อเข้ากลุ่ม %s!",
			'groups:started' => "เริ่มโดย",
			'groups:invite:body' => "สวัสดี %s,

คุณได้รับคำเชิญเพื่อเข้ากลุ่ม '%s' คลิ๊กลิ้งค์ด้านล่างเพื่อตอบรับ:

%s",

			'groups:welcome:subject' => "ยินดีต้อนรับสู่กลุ่ม  %s !",
			'groups:welcome:body' => "สวัสดี %s!

ตอนนี้คุณเป็นสมาชิกของกลุ่ม '%s' แล้ว! คลิ๊กลิ้งค์ด้านล่างเพื่อโพส!

%s",

			'groups:request:subject' => "%s ต้องการเข้ากลุ่ม %s",
			'groups:request:body' => "สวัสดี %s,

%s ต้องการเข้ากลุ่ม '%s' ,คลิ๊กลิ้งค์ด้านล่างเพื่อดูโปรไฟล์:

%s

หรือคลิ๊กลิ้งค์ด้านล่างเพื่อยอมรับเข้ากลุ่ม:

%s",

           /*
				Forum river items
			*/

			'groups:river:member' => 'ตอนนี้เป็นสมาชิกของ',
			'groupforum:river:updated' => '%s อัพเดต',
			'groupforum:river:update' => 'การสนทนานี้หัวข้อ',
			'groupforum:river:created' => '%s สร้างแล้ว',
			'groupforum:river:create' => 'หัวข้อการสนทนาใหม่',
			'groupforum:river:posted' => '%s เขียนความคิดเห็นใหม่',
			'groupforum:river:annotate:create' => 'ในการสนทนาหัวข้อ',
			'groupforum:river:postedtopic' => '%s เริ่มหัวข้อสนทนาใหม่',
			'groups:river:member' => '%s เป็นสมาชิกของ',

			'groups:nowidgets' => 'ไม่มีวิดเจ็ตของกลุ่ม',


			'groups:widgets:members:title' => 'สมาชิกกลุ่ม',
			'groups:widgets:members:description' => 'รายการของสมาชิกกลุ่ม',
			'groups:widgets:members:label:displaynum' => 'รายการของสมาชิกกลุ่ม',
			'groups:widgets:members:label:pleaseedit' => 'กรุณาตั้งค่าวิดเจ็ต',

			'groups:widgets:entities:title' => "ออฟเจ็คในกลุ่ม",
			'groups:widgets:entities:description' => "รายการออฟเจ็คในกลุ่ม",
			'groups:widgets:entities:label:displaynum' => 'รายการออฟเจ็คในกลุ่ม',
			'groups:widgets:entities:label:pleaseedit' => 'กรุณาตั้งค่าวิดเจ็ต',

			'groups:forumtopic:edited' => 'แก้ไขหัวข้อของฟอรั่มสำเร็จ',

			/**
			 * Action messages
			 */
			'group:deleted' => 'กลุ่มและเนื้อหาในกลุ่มถูกลบ',
			'group:notdeleted' => 'ไม่สามารถลบกลุ่มได้',
	
			'grouppost:deleted' => 'ลบกลุ่มแล้ว',
			'grouppost:notdeleted' => 'กลุ่มไม่สามารถลบได้',
			'groupstopic:deleted' => 'กัวข้อถูกลบแล้ว',
			'groupstopic:notdeleted' => 'ไม่สามารถลบหัวข้อนี้ได้',
			'grouptopic:blank' => 'ยงไม่มีหัวข้อ',
			'groups:deletewarning' => "แน่ใจหรือไม่ที่จะลบกลุ่มนี้? เพราะมันไม่สามารถเรียกคืนได้นะ!",
	
			'groups:joinrequestkilled' => 'การขอเป็นสมาชิกถูกลบ',
	);
	
	add_translation("th",$thai);

?>
