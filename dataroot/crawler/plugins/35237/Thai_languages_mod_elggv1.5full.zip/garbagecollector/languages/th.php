﻿<?php
                 /**
	         * @package languages For ฌarbagecollector
	         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	         * @author Laithai Team <webmaster@lungkao.com.com>
	         * @copyright Laithai Team 2008-2009
	         * @link http://elgg.in.th/
                 */  

	$thai = array(

			/**
		 * Menu items and titles
		 */

			'garbagecollector:period' => 'คุณต้องการตั้งค่าการเก็บข้อมูลไว้นานเท่าใด?',

			'garbagecollector:weekly' => 'หนึ่งสัปดาห์',
			'garbagecollector:monthly' => 'หนึ่งเดือน',
			'garbagecollector:yearly' => 'หนึงปี',

			'garbagecollector' => "GARBAGE COLLECTOR\n",
			'garbagecollector:done' => "DONE\n",
			'garbagecollector:optimize' => "Optimizing %s ",

			'garbagecollector:error' => "ERROR",
			'garbagecollector:ok' => "OK",

			'garbagecollector:gc:metastrings' => 'Cleaning up unlinked metastrings: ',
	
	);
	add_translation("th",$thai);
?>
