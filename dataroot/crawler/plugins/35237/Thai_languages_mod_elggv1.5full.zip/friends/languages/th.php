﻿<?php
                 /**
	         * @package languages For Friends
	         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	         * @author Laithai Team <webmaster@lungkao.com.com>
	         * @copyright Laithai Team 2008-2009
	         * @link http://elgg.in.th/
                 */  

	$thai = array(

			/**
		 * Friends widget
		 */
			'friends:widget:description' => "แสดงเพื่อนที่คุณมี",


	);

	add_translation("th",$thai);

?>
