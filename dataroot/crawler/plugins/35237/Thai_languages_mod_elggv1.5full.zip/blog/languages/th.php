﻿<?php
                 /**
	         * @package languages For Blog 
	         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	         * @author Laithai Team <webmaster@lungkao.com.com>
	         * @copyright Laithai Team 2008-2009
	         * @link http://elgg.in.th/
                 */  

	$thai = array(

		/**
		 * Menu items and titles
		 */

			'blog' => "บล็อก",
			'blogs' => "บล็อก",
			'blog:user' => "บล็อกของ %s",
			'blog:user:friends' => "บล็อกเพื่อนของ %s",
			'blog:your' => "บล็อกของคุณ",
			'blog:posttitle' => "บล็อกของ %s : %s",
			'blog:friends' => "บล็อกของเพื่อน",
			'blog:yourfriends' => "บล็อกล่าสุดของเพื่อน",
			'blog:everyone' => "บล๊อกทั้งหมด",
			'blog:newpost' => "เขียนบล๊ิอกใหม่",
			'blog:via' => "บล๊อกเก่า",
			'blog:read' => "อ่านบล๊อก",

			'blog:addpost' => "เขียนบล็อก",
			'blog:editpost' => "แก้ไขบล็อก",

			'blog:text' => "ข้อความบล็อก",

			'blog:strapline' => "%s",

			'item:object:blog' => 'เขียนบล็อก',
	
			'blog:never' => 'ยังไม่เคย',
			'blog:preview' => 'แสดงตัวอย่าง',
	
			'blog:draft:save' => 'บันทึกร่าง',
			'blog:draft:saved' => 'บันทึกร่างล่าสุด',
			'blog:comments:allow' => 'เปิดให้แสดงความคิดเห็น',
	
			'blog:preview:description' => 'ส่วนนี้ยังไม่ได้บันทึก เป็นเพียงตัวอย่างของเนื้อหาบล็อก',
			'blog:preview:description:link' => 'หากต้องการแก้ไขต่อหรือบันทึกคลิ๊ก',
	

         /**
	     * Blog river
	     **/

	        //generic terms to use
	        'blog:river:created' => "%s เขียน",
	        'blog:river:updated' => "%s อัปเดต",
	        'blog:river:posted' => "%s เขียน",

	        //these get inserted into the river links to take the user to the entity
	        'blog:river:create' => "เขียนบล๊อกใหม่",
	        'blog:river:update' => "เขียนบล๊อก",
	        'blog:river:annotate:create' => "ความคิดเห็นในบล๊อก",


		/**
		 * Status messages
		 */

			'blog:posted' => "บทความในบล็อกของคุณได้โพสต์เรียบร้อยแล้ว.",
			'blog:deleted' => "บทความในบล็อกของคุณได้ลบเรียบร้อยแล้ว",

		/**
		 * Error messages
		 */

			'blog:error' => 'มีบางอย่างผิดพลาด โปรดลองอีกครั้ง',
			'blog:save:failure' => "บทความบล็อกของคุณไม่สามารถบันทึก. โปรดลองอีกครั้ง.",
			'blog:blank' => "ขออภัยคุณต้องใส่ชื่อ และข้อความลงไปก่อน",
			'blog:notfound' => "ขออภัย เราไม่พบบทความในบล็อกที่ระบุ",
			'blog:notdeleted' => "ขออภัยเราไม่สามารถลบ บล็อกนี้ได้",

	);

	add_translation("th",$thai);

?>
