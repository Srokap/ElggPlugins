﻿<?php
                 /**
	         * @package languages For Default Widgets
	         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	         * @author Laithai Team <webmaster@lungkao.com.com>
	         * @copyright Laithai Team 2008-2009
	         * @link http://elgg.in.th/
                 */  

$thai = array (

	/**
	 * Nice name for the entity (shown in admin panel)
	 */
	'item:object:moddefaultwidgets' => 'ตั้งค่าเริ่มต้นของวิดเก็ต',

	/**
	 * Menu items
	 */
	'defaultwidgets:menu:profile' => 'ค่าวิดเก็ตของโปรไฟล์',
    'defaultwidgets:menu:dashboard' => 'ค่าวิดเก็ตของกระดานข้อมูล',

    'defaultwidgets:admin:error' => 'ข้อผิดพลาด: คุณไม่ได้เข้าสู่ระบบในฐานะผู้ดูแลระบบ',
	'defaultwidgets:admin:notfound' => 'ข้อผิดพลาด: ไม่พบหน้าเว็บ',
	'defaultwidgets:admin:loginfailure' => 'คําเตือน: ขณะนี้ท่านไม่ได้ล็อกอินเป็นผู้ดูแลระบบ',

	'defaultwidgets:update:success' => 'การตั้งค่าวิดเก็ตถูกบันทึกแล้ว',
	'defaultwidgets:update:failed' => 'ข้อผิดพลาด: การตั้งค่าไม่ได้บันทึก',
	'defaultwidgets:update:noparams' => 'ข้อผิดพลาด: รูปแบบพารามิเตอร์ไม่ถูกต้อง',

	'defaultwidgets:profile:title' => 'การกำหนดค่าเริ่มต้นของวิดเก็ตของหน้าโปรไฟล์',
	'defaultwidgets:dashboard:title' => 'การกำหนดค่าเริ่มต้นของวิดเก็ตของหน้ากระดานข้อมูล',
);

add_translation ( "th", $thai );

?>
