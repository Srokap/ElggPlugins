﻿<?php
                 /**
	         * @package languages For Notifications
	         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	         * @author Laithai Team <webmaster@lungkao.com.com>
	         * @copyright Laithai Team 2008-2009
	         * @link http://elgg.in.th/
                 */  

	$thai = array(
	
			'friends:all' => 'ของเพื่อนทั้งหมด',
	
		'notifications:subscriptions:personal:description' => 'รับการแจ้งเตือนเมื่อการกระทำที่ในเนื้อหาของคุณ',
		'notifications:subscriptions:personal:title' => 'การเตือนส่วนบุคคล',
	
		'notifications:subscriptions:collections:title' => 'เพื่อนทั้งหมด',
		'notifications:subscriptions:collections:description' => 'เลือกไอคอนด้านล่างเพื่อเลือกทั้งหมด ',
		'notifications:subscriptions:collections:edit' => 'แก้ไขประเภทของเพื่อนคลิ๊ก.',
	
		'notifications:subscriptions:changesettings' => 'ระบบเตือน',
		'notifications:subscriptions:changesettings:groups' => 'ระบบเตือนของกลุ่ม',
		'notification:method:email' => 'อีเมล',	
	
		'notifications:subscriptions:title' => 'การเตือนสมาชิก',
		'notifications:subscriptions:description' => 'การรับการแจ้งจากเพื่อนของคุณ เทื่อเพื่นคุณทำสิ่งใดบนเว็บจะมีการเตือนไปยังคุณ',
	
		'notifications:subscriptions:groups:description' => 'เลือกไอคอนด้านล่างเพื่อเลือกรับการเตือนว่าจะรับอะไรบ้าง',
	
		'notifications:subscriptions:success' => 'บันทึกการเตือนแล้ว',

	);

	add_translation("th",$thai);

?>
