﻿<?php
                 /**
	         * @package languages For Messages
	         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	         * @author Laithai Team <webmaster@lungkao.com.com>
	         * @copyright Laithai Team 2008-2009
	         * @link http://elgg.in.th/
                 */  

	$thai = array(
	/**
		 * Menu items and titles
		 */

			'messages' => "จดหมาย",
            'messages:back' => "กลับไปยังจดหมาย",
			'messages:user' => "กล่องจดหมาย",
			'messages:sentMessages' => "ส่งจดหมาย",
			'messages:posttitle' => "จดหมายของ %s: %s",
			'messages:inbox' => "กล่องจดหมาย",
			'messages:send' => "ส่งจดหมาย",
			'messages:sent' => "ส่งจดหมาย",
			'messages:message' => "ข้อความ",
			'messages:title' => "เรื่อง",
			'messages:to' => "ถึง",
            'messages:from' => "จาก",
			'messages:fly' => "ส่งไปเลย",
			'messages:replying' => "จดหมายตอบกลับถึง",
			'messages:inbox' => "กล่องจดหมาย",
			'messages:sendmessage' => "ส่งจดหมาย",
			'messages:compose' => "ส่งจดหมาย",
			'messages:sentmessages' => "ส่งจดหมาย",
			'messages:recent' => "จดหมายล่าสุด",
            'messages:original' => "ข้อความต้นฉบับ",
            'messages:yours' => "ข้อความของคุณ",
            'messages:answer' => "ตอบกลับ",
                        'messages:toggle' => 'เลือกทั้งหมด',
			'messages:markread' => 'ทำให้เป็นจดหมายที่อ่านแล้ว',
			
			'messages:new' => 'จดหมายใหม่',
	
			'notification:method:site' => 'เว็บไซต์',
	
			'messages:error' => 'ไม่สามารถบันทึกจดหมายได้ลองอีกครั้ง',

			'item:object:messages' => 'ข้อความ',

		/**
		 * Status messages
		 */

			'messages:posted' => "จดหมายของคุณถูกส่งแล้ว",
			'messages:deleted' => "จดหมายของคุณถูกลบแล้ว",

		/**
		 * Email messages
		 */

			'messages:email:subject' => 'คุณมีจดหมายของใหม่!',
			'messages:email:body' => "คุณมีจดหมายใหม่จาก %s. อ่าน:


%s


หากต้อการอ่านคลิ๊ก:

	%s

ส่งจดหมายไปหา %s คลิ๊ก:

	%s

คุณไม่จำเป็นต้องตอบกลับอีเมลฉบับนี้",

		/**
		 * Error messages
		 */

'messages:blank' => "เสียใจด้วย; คุณต้องใส่ขอความลงไปก่อน",
			'messages:notfound' => "เสียใจด้วย; เราไม่สามารถหาจดหมายได้",
			'messages:notdeleted' => "เสียใจด้วย; เราไม่สามารถลบจดหมายได้",
			'messages:nopermission' => "คุณไม่มีสิทธิลบจดหมายนี้",
			'messages:nomessages' => "ไม่มีจดหมายให้แสดง",
			'messages:user:nonexist' => "เราไม่สามารถหาสมาชิกผู้นี้เจอ",

	);

	add_translation("th",$thai);

?>
