﻿<?php
                 /**
	         * @package languages For Twitter Service
	         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	         * @author Laithai Team <webmaster@lungkao.com.com>
	         * @copyright Laithai Team 2008-2009
	         * @link http://elgg.in.th/
                 */  

	$thai = array(

		/**
		 * Menu items and titles
		 */
	
		'twitterservice' => 'Twitter Service',
		'twitterservice:postwire' => 'คุณต้องการให้ส่งบันทึกไปที่ Twitter ด้วยหรือไม่?',
		'twitterservice:twittername' => 'Twitter username',
		'twitterservice:twitterpass' => 'Twitter password',
		
		
		 /**
	     * twitter widget river
	     **/
	        
	        //generic terms to use
	        'twitter:river:created' => "%s เพิ่ม twitter วิดเก็ต",
	        'twitter:river:updated' => "%s อัพเดต twitter วิดเก็ต",
	        'twitter:river:delete' => "%s ลบ twitter วิดเก็ต",

	
        /**
	     * The wire river
	     **/
	        
	        //generic terms to use
	        'thewire:river:created' => "%s โพสต์",
	        
	        //these get inserted into the river links to take the user to the entity
	        'thewire:river:create' => "ในบันทึก.",
	        
	    /**
	     * Wire widget
	     **/
	     
	        'thewire:sitedesc' => 'วิตเก็ตนี้จะแสดงบันทึกล่าสุดของคุณ',
	        'thewire:yourdesc' => 'วิตเก็ตนี้จะแสดงบันทึกล่าสุดของคุณ',
	        'thewire:friendsdesc' => 'วิตเก็ตนี้จะแสดงบันทึกล่าสุดของเพื่อนคุณ',
	        'thewire:friends' => 'บันทึกของเพื่อนคุณ',
	        'thewire:num' => 'จำนวนที่ต้องการแสดง',
	        
	        
	
		/**
		 * Status messages
		 */
	
			'thewire:posted' => "บันทึกแล้ว",
			'thewire:deleted' => "ลบบันทึกแล้ว",
	
		/**
		 * Error messages
		 */
	
			'thewire:blank' => "เสียใจด้วย; คุณต้องใส่ข้อความลงไปก่อนบันทึก.",
			'thewire:notfound' => "เสียใจด้วย; ไม่สามารถหาบันทึกของคุณได้",
			'thewire:notdeleted' => "เสียใจด้วย; ไม่สามารถลบได้",
	
	
		/**
		 * Settings
		 */
			'thewire:smsnumber' => "หมายเลข SMS ถ้าต่างกับเบอร์มือถือของคุณ (",
			'thewire:channelsms' => "จำนวนที่จะส่ง ข้อความ SMS คือ<b>%s</b>",
	);

	add_translation("th",$thai);

?>
