﻿<?php
                 /**
	         * @package languages For File
	         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	         * @author Laithai Team <webmaster@lungkao.com.com>
	         * @copyright Laithai Team 2008-2009
	         * @link http://elgg.in.th/
                 */  

	$thai = array(

				/**
		 * Menu items and titles
		 */

			'file' => "ไฟล์",
			'files' => "ไฟล์",
			'file:yours' => "ไฟล์ของคุณ",
			'file:yours:friends' => "ไฟล์ของเพื่อนคุณ",
			'file:user' => "ไฟล์ของ %s",
			'file:friends' => "ไฟล์เพื่อนของ %s",
			'file:all' => "ไฟล์ทั้งหมด",
			'file:edit' => "แก้ไขไฟล์",
			'file:more' => "ไฟลือื่นๆ",
			'file:list' => "ดูแบบรายการ",
			'file:group' => "ไฟล์ของกลุ่ม",
			'file:gallery' => "ดูแบบแกลลอรี่",
			'file:gallery_list' => "ดูแบบแกลลรี่หรือรายการ",
			'file:num_files' => "จำนวนไฟล์ที่ต้องการแสดง",
			'file:user:gallery'=>'ดู %s แกลลอรี่',
	        'file:via' => 'ไฟล์เก่า',
			'file:upload' => "อัปโหลดไฟล์",

			'file:newupload' => 'ไฟล์ใหม่ได้อัพโหลดแล้ว',

			'file:file' => "ไฟล์",
			'file:title' => "ชื่อ",
			'file:desc' => "รายละเอียด",
			'file:tags' => "แท็ก",

			'file:types' => "ชนิดของไฟล์ที่อัปโหลด",

			'file:type:all' => "ทุกไฟล์",
			'file:type:video' => "ภาพเคลือนไหว",
			'file:type:document' => "เอกสาร",
			'file:type:audio' => "ไฟล์เสียง",
			'file:type:image' => "รูปภาพ",
			'file:type:general' => "ทั่วไป",

			'file:user:type:video' => "ภาพเคลือนไหวของ%s",
			'file:user:type:document' => "เอกสารของ %s",
			'file:user:type:audio' => "ไฟล์เสียงของ %s",
			'file:user:type:image' => "รูปภาพของ %s",
			'file:user:type:general' => "ไฟล์ทั้งไปของ %s",

			'file:friends:type:video' => "ภาพเคลื่อนไหวของเพื่อน",
			'file:friends:type:document' => "เอกสารของพื่อน",
			'file:friends:type:audio' => "ไฟล์เสียงของเพื่อน",
			'file:friends:type:image' => "รูปภาพของ เพื่อน",
			'file:friends:type:general' => "ไฟล์ทั้งไปของ เพื่อน",

			'file:widget' => "ไฟล์ล่าสุด",
			'file:widget:description' => "แสดงไฟล์ล่าสุด",

			'file:download' => "ดาวน์โหลด",

			'file:delete:confirm' => "คุณแน่ใจหรือไม่ว่าต้องการลบไฟล์นี้?",

			'file:tagcloud' => "Tag cloud",

			'file:display:number' => "จำนวนไฟล์ที่ต้องการแสดง",

			'file:river:created' => "%s อัพโหลด",
			'file:river:item' => "ไฟล์",
			'file:river:annotate' => "%s เขียนความคิดเห็นใน",

			'item:object:file' => 'ไฟล์',

	    /**
		 * Embed media
		 **/

		    'file:embed' => "เอ็มเบ็ต มีเดีย",
		    'file:embedall' => "ทั้งหมด",

		/**
		 * Status messages
		 */

			'file:saved' => "ไฟล์ของคุณถูกบันทึกแล้ว",
			'file:deleted' => "ไฟล์ของคุณถูกลบแล้ว",

		/**
		 * Error messages
		 */

			'file:none' => "เราไม่พบแฟ้มใดๆในขณะนี้",
			'file:uploadfailed' => "ขออภัย เราไม่สามารถบันทึกไฟล์ของคุณ",
			'file:downloadfailed' => "ขออภัย ไฟล์นี้ไม่สามารถใช้ได้ในขณะนี้",
			'file:deletefailed' => "ไฟล์ของคุณไม่สามารถลบออกได้ในขณะนี้",

	);

	add_translation("th",$thai);
?>
