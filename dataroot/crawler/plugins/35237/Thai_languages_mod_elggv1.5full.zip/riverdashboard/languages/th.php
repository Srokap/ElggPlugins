﻿<?php
                 /**
	         * @package languages For Riverdashboard
	         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	         * @author Laithai Team <webmaster@lungkao.com.com>
	         * @copyright Laithai Team 2008-2009
	         * @link http://elgg.in.th/
                 */  

	$thai = array(

		'mine' => 'ที่มา',
		'filter' => 'กรอง',
		'riverdashboard:useasdashboard' => "แทนที่ค่าเริ่มต้นกระดานข้อมูลกับกิจกรรมนี้?",
		'activity' => 'กิจกรรม',
	
	    /**
	     * Site messages
           **/

		'sitemessages:announcements' => "ประกาศ",
		'sitemessages:posted' => "โพสต์",
		'sitemessages:river:created' => "ผู้ดูแลเว็บ, %s,",
		'sitemessages:river:create' => "เขียนประกาศ",
		'sitemessages:add' => "เขียนประกาศ",
		'sitemessage:deleted' => "ลบข้อความ",
		
		'river:widget:noactivity' => 'ไม่สามารถหากิจกรรมที่เกิดขึ้นได้',
		'river:widget:title' => "กิจกรรม",
		'river:widget:description' => "แสดงกิจกรรมล่าสุดของคุณ",
		'river:widget:title:friends' => "กิจกรรมของเพื่อน",
		'river:widget:description:friends' => "แสดงสิ่งที่เพื่อนคุณทำ",
		'river:widgets:friends' => "เพื่อน",
		'river:widgets:mine' => "ที่มา",
		'river:widget:label:displaynum' => "จำนวนที่ต้องการแสดง:",
		'river:widget:type' => "เลือกสิ่งที่คุณต้องการแสดง?",
		'item:object:sitemessage' => "ข้อความประกาศ",
	);

	add_translation("th",$thai);

?>
