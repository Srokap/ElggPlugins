﻿<?php
                 /**
	         * @package languages For Message board
	         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	         * @author Laithai Team <webmaster@lungkao.com.com>
	         * @copyright Laithai Team 2008-2009
	         * @link http://elgg.in.th/
                 */  

	$thai = array(

	/**
		 * Menu items and titles
		 */
	
			'messageboard:board' => "กระดานข้อความ",
			'messageboard:messageboard' => "กระดานข้อความ",
			'messageboard:viewall' => "ดูทั้งหมด",
			'messageboard:postit' => "เขียนข้อความ",
			'messageboard:history' => "ข้อความเก่า",
			'messageboard:none' => "ม่มีข้อความ",
			'messageboard:num_display' => "จำนวนข้อความที่ต้องการแสดง",
			'messageboard:desc' => "กระดานข้อความนี้จะสามารถเปิดให้ผู้อ่นมาแสดงความคิดเห็นได้",
	
			'messageboard:user' => "กระดานข้อความของ %s",
	
			'messageboard:history' => "ข้อความเก่า",
			
         /**
	     * Message board widget river
	     **/
	        
	        'messageboard:river:annotate' => "%s ได้เขียนความคิดเห็นใหม่บนกระดานข้อความ",
	        'messageboard:river:create' => "%s เพิ่มกระดานข้อความ",
	        'messageboard:river:update' => "%s อัพเดตกระดานข้อความ",
	        'messageboard:river:added' => "%s เขียนใน",
		    'messageboard:river:messageboard' => "กระดานข้อความ",

			
		/**
		 * Status messages
		 */
	
			'messageboard:posted' => "เขียนข้อความเสร็จแล้ว",
			'messageboard:deleted' => "ลบข้อความแล้ว",
	
		/**
		 * Email messages
		 */
	
			'messageboard:email:subject' => 'คุณมีความคิดเห็นใหม่ในกระดานข้อความ!',
			'messageboard:email:body' => "%s เขียนถึงคุณในกระดานข้อความ ไปอ่าน:

			
%s


อ่านข้อความคลิ๊ก:

	%s

ไปดูโปรไฟล์ของ %s, คลิ๊ก:

	%s

ไม่จำเป็นต้องตอบกลับเมลนี้",
	
		/**
		 * Error messages
		 */
	
			'messageboard:blank' => "ขออภัย; คุณต้องใส่ข้อความลงไปก่อนถึงจะสามารถบันทึก",
			'messageboard:notfound' => "ขออภัย; เราไม่พบรายการที่คุณระบุ",
			'messageboard:notdeleted' => "ขออภัย; เราไม่สามารถลบข้อความได้",
			'messageboard:somethingwentwrong' => "มีข้อผิดพลาดในขณะที่พยายามบันทึกข้อความของท่านให้แน่ใจว่าคุณได้เขียนข้อความแล้ว",
	     
			'messageboard:failure' => "เกิดข้อผิดพลาดที่คาดไม่ถึงในการเพิ่มข้อความของคุณ. โปรดลองอีกครั้ง.",
	
	);

	add_translation("th",$thai);

?>
