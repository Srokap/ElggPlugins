﻿<?php
                 /**
	         * @package languages For Member
	         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	         * @author Laithai Team <webmaster@lungkao.com.com>
	         * @copyright Laithai Team 2008-2009
	         * @link http://elgg.in.th/
                 */  

	$thai = array(

		'members:members' => "สมาชิกบนเว็บ",
	    'members:online' => "สมาชิกทเข้าี่ใช้งานขณะนี้",
	    'members:active' => "สมาชิกบนเว็บ",
	    'members:searchtag' => "ค้นหาสมาชิกโดยแ็ท๊ก",
	    'members:searchname' => "ค้นหาสมาชิกโดยชื่อ",

	);

	add_translation("th",$thai);

?>
