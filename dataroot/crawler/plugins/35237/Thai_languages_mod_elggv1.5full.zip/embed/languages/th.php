﻿<?php
                 /**
	         * @package languages For Embed
	         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	         * @author Laithai Team <webmaster@lungkao.com.com>
	         * @copyright Laithai Team 2008-2009
	         * @link http://elgg.in.th/
                 */  

	$english = array(
	
		'media:insert' => 'เพิ่มมีเดีย / อัพโหลดมีเดีย',
	
		'embed:instructions' => 'คลิ๊กที่ไฟล์เพือ่เพิ่มไปยังเนื้อหา',
	
		'embed:media' => 'เพิ่มมีเดีย',
		'upload:media' => 'อัพโหลดมีเดีย',
	
		'embed:file:required' => 'ไม่มีไฟล์',
	
	);
					
	add_translation("en",$english);
?>
