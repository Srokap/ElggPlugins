﻿<?php
                 /**
	         * @package languages For log rotator
	         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	         * @author Laithai Team <webmaster@lungkao.com.com>
	         * @copyright Laithai Team 2008-2009
	         * @link http://elgg.in.th/
                 */  

	$thai = array(

			'logrotate:period' => 'นานเท่าไหรที่คุณจะเก็บ log?',

		'logrotate:weekly' => 'หนึ่งสัปดาห์',
		'logrotate:monthly' => 'หนึ่งเดือน',
		'logrotate:yearly' => 'หนึ่งปี',

		'logrotate:logrotated' => "Log rotated\n",
		'logrotate:lognotrotated' => "Error rotating log\n",

	);

	add_translation("th",$thai);

?>
