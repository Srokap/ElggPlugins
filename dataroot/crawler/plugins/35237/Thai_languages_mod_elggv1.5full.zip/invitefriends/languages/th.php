﻿<?php
                 /**
	         * @package languages For Invitefriends
	         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	         * @author Laithai Team <webmaster@lungkao.com.com>
	         * @copyright Laithai Team 2008-2009
	         * @link http://elgg.in.th/
                 */  

	$thai = array(

		'friends:invite' => 'เชิญเพื่อน',
		'invitefriends:introduction' => 'การชวนเพื่อนของคุณเข้ามาร่้วมเว็บนี้ ให้ใส่อีเมลลงไปด้านล่าง (หนึ่งอีเมลต่อหนึ่งบันทัด):',
		'invitefriends:message' => 'ใส่คำเชิยชวนลงไปด้านล่าง:',
		'invitefriends:subject' => 'คำเชิญให้เข้าร่วม %s',
	
		'invitefriends:success' => 'เพื่อนๆของคุณได้รับเชิญ',
		'invitefriends:failure' => 'เพื่อนๆของคุณไม่ได้รับเชิญ',
	
		'invitefriends:message:default' => '
สวัสดี,

ฉันต้องการจะเชิญคุณเข้าร่วมเครือข่ายของฉันที่ %s.',
		'invitefriends:email' => '
คุณได้รับเชิญให้เข้าร่วม %s โดย %s. และมีข้อความถึงคุณด้วยคือ:

%s

เข้าร่วม, คลิ๊ก:

	%s

คุณจะได้เพื่นอนทันทีที่เข้าร่วม',
	
	);
	
	add_translation("th",$thai);

?>
