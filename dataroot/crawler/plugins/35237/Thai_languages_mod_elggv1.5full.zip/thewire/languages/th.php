﻿<?php
                 /**
	         * @package languages For The Wire
	         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	         * @author Laithai Team <webmaster@lungkao.com.com>
	         * @copyright Laithai Team 2008-2009
	         * @link http://elgg.in.th/
                 */  

	$thai = array(

		/**
		 * Menu items and titles
		 */
	
			'thewire' => "บันทึก",
			'thewire:user' => "บันทึกของ %s",
			'thewire:posttitle' => "%s เขียนในบันทึก: %s",
			'thewire:everyone' => "บันทึกทั้งหมด",
	
			'thewire:read' => "บันทึก",
			
			'thewire:strapline' => "%s",
	
			'thewire:add' => "เขียนในบันทึก",
		    'thewire:text' => "บันทึก",
			'thewire:reply' => "ตอบกลับ",
			'thewire:via' => "ที่ผ่านมา",
			'thewire:wired' => "เขียนในบันทึก",
			'thewire:charleft' => "ตัวอักษรที่เหลือ",
			'item:object:thewire' => "เขียนบันทึก",
			'thewire:notedeleted' => "ตลบบันทึก",
			'thewire:doing' => "คุณกำลังทำอะไร? บอกทุกคนในบันทึก:",
			'thewire:newpost' => 'บันทึกมาใหม่',
			'thewire:addpost' => 'เขียนในบันทึก',

	
        /**
	     * The wire river
	     **/
	        
	        //generic terms to use
	        'thewire:river:created' => "%s โพสต์",
	        
	        //these get inserted into the river links to take the user to the entity
	        'thewire:river:create' => "ในบันทึก.",
	        
	    /**
	     * Wire widget
	     **/
	     
	        'thewire:sitedesc' => 'วิตเก็ตนี้จะแสดงบันทึกล่าสุดของคุณ',
	        'thewire:yourdesc' => 'วิตเก็ตนี้จะแสดงบันทึกล่าสุดของคุณ',
	        'thewire:friendsdesc' => 'วิตเก็ตนี้จะแสดงบันทึกล่าสุดของเพื่อนคุณ',
	        'thewire:friends' => 'บันทึกของเพื่อนคุณ',
	        'thewire:num' => 'จำนวนที่ต้องการแสดง',
	        
	        
	
		/**
		 * Status messages
		 */
	
			'thewire:posted' => "บันทึกแล้ว",
			'thewire:deleted' => "ลบบันทึกแล้ว",
	
		/**
		 * Error messages
		 */
	
			'thewire:blank' => "เสียใจด้วย; คุณต้องใส่ข้อความลงไปก่อนบันทึก.",
			'thewire:notfound' => "เสียใจด้วย; ไม่สามารถหาบันทึกของคุณได้",
			'thewire:notdeleted' => "เสียใจด้วย; ไม่สามารถลบได้",
	
	
		/**
		 * Settings
		 */
			'thewire:smsnumber' => "หมายเลข SMS ถ้าต่างกับเบอร์มือถือของคุณ (",
			'thewire:channelsms' => "จำนวนที่จะส่ง ข้อความ SMS คือ<b>%s</b>",
	);

	add_translation("th",$thai);

?>
