﻿<?php
                 /**
	         * @package languages For UserValidationByEmail
	         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	         * @author Laithai Team <webmaster@lungkao.com.com>
	         * @copyright Laithai Team 2008-2009
	         * @link http://elgg.in.th/
                 */  

	$thai = array(

		'email:validate:subject' => "%s กรุณายืนยันที่อยู่อีเมลของคุณ!",
		'email:validate:body' => "สวัสดี %s,

กรุณายืนยันที่อยู่อีเมลของคุณโดยการคลิกลิ้งค์ด้านล่าง:

%s
",
		'email:validate:success:subject' => "ตรวจสอบอีเมล %s!",
		'email:validate:success:body' => "สวัสดี %s,

ขอแสดงความยินดีคุณได้ยืนยันที่อยู่อีเมลของคุณแล้ว",

		'email:confirm:success' => "คุณได้ยืนยันอีเมลของคุณแล้ว!",
		'email:confirm:fail' => "อีเมลของคุณไม่ผ่านการยืนยัน...",
	
		'uservalidationbyemail:registerok' => "หากต้องการเปิดใช้งานบัญชีของคุณโปรดยืนยันที่อยู่อีเมลของคุณโดยคลิกที่ลิงค์ที่เราส่งให้."

	);
	add_translation("th",$thai);

?>
