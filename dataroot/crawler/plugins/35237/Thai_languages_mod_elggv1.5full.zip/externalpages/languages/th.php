﻿<?php
                 /**
	         * @package languages For Externalpages
	         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	         * @author Laithai Team <webmaster@lungkao.com.com>
	         * @copyright Laithai Team 2008-2009
	         * @link http://elgg.in.th/
                 */  

	$thai = array(
	
		/**
		 * Menu items and titles
		 */
	
			'expages' => "หน้่าพิเศษ",
			'expages:frontpage' => "หน้าแรก",
			'expages:about' => "เกี่ยวกับเรา",
			'expages:terms' => "ข้อตกลง",
			'expages:privacy' => "นโยบายความเป็นส่วนตัว",
			'expages:analytics' => "วิเคราะห์",
			'expages:contact' => "ติดต่อเา",
			'expages:nopreview' => "ไม่มีข้อมูลตัวอย่าง",
			'expages:preview' => "ดูตัวอย่าง",
			'expages:notset' => "หน้านี้ยังไม่ได้รับการติดตั้ง",
			'expages:lefthand' => "ข้อมูลด้านซ้ายมือ",
			'expages:righthand' => "ข้อมูลด้านขวามือ",
			'expages:addcontent' => "คุณสามารถเพิ่มเนื้อหาouhโดยผู้ดูแลระบบ  มองหาหน้าที่เชื่อมโยงภายนอกภายใต้การดูแลระบบ",
			'item:object:front' => 'น้าแรก',
	
		/**
		 * Status messages
		 */
	
			'expages:posted' => "หน้าเว็บของคุณได้บันทึกเรียบร้อยแล้ว",
			'expages:deleted' => "หน้าเว็บของคุณได้บันทึกเรียบร้อยแล้ว.",
	
		/**
		 * Error messages
		 */
	
			'expages:deleteerror' => "เกิดปัญหาในการลบหน้าเก่า",
			'expages:error' => "มีข้อผิดพลาดโปรดลองอีกครั้งและหากยังมีปัญหาให้ติดต่อผู้ดูแลระบบ",
			
	);
					
	add_translation("th",$thai);
?>
