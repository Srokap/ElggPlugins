<?php 


?>
#group_multiple_admins_group_admins {
	margin:10px;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	background: white;	
}

#group_multiple_admins_group_admins h2 {
	margin:0 0 10px 0;
	padding:5px;
	color:#0054A7;
	font-size:1.25em;
	line-height:1.2em;
}