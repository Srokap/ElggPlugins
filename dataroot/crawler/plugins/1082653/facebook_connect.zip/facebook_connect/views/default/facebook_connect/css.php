<?php
/**
 * Elgg Facebook API CSS
 */
?>

#facebook_connect_site_settings .text_input 
{
	width: 350px;
}
#login_with_facebook 
{
	padding: 10px 0 0 0;
}