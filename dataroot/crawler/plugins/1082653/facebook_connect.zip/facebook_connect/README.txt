Please follow these steps to use facebook connect with your elgg site
/* Only for elgg 1.8 */
1. Go to facebook.com and login with your account
2. Create an application and get api key and secret no.
3. Make sure you have entered your web site url in application for connect login functionality with your site.
	for example enter url http://ektasoftwares.com
4. Copy faceook connect in mod folder and make sure plugin folder name is facebook_connect
5. Login with your admin account and activate facebook connect plugin
6. Now Click on Setting and enter your facebook application api key and secret no
7. You can set other setting also
8. Now you can see facebook login button on login page



If Facebook user is already registered on your network then this pluging will associate site account with facebook account 
otherwise this plugin will auto register the facebook user and send login details to user email address.



Plugin version 1.2
Please feel free to contact me @ chetanvarshney@gmail.com if you have any problem.



Fixes-
@ version 1.1
1. Plugin sends login details to facebook user's email address.



@ version 1.2
1. update email ids of old facebook connect users(before this plugin)
2. If site page are restricted to logged in users then facebook connect plugin works in this version
3. facebook permission requests are decreased now plugin requests for needed permissions to facebook