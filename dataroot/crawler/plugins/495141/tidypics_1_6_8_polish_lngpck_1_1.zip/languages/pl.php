<?php

	/**
	 * Tidy Pics polish language pack.
	 * 
	 * @author Tomasz Kowalski
	 * @link http://isbjoern.dk
	 */

  $english = array(
		// hack for core bug
			'untitled' => "bez tytułu",

		// Menu items and titles

			'image' => "Obraz",
			'images' => "Obrazy",
			'caption' => "Podpis",
			'photos' => "Zdjęcia",
			'images:upload' => "Wyślij zdjęcia",
			'images:multiupload' => "Flash Multi Upload Tool",
			'images:multiupload:todo' => "Wybierz jedno lub więcej plików do wysłania.",
			'album' => "Album zdjęć",
			'albums' => "Albumy zdjęć",
			'album:slideshow' => "Pokaż slideshow",
			'album:yours' => "Twoje albumy",
			'album:yours:friends' => "Albumy Twoich przyjaciół",
			'album:user' => "Albumy użytkownika %s",
			'album:friends' => "Albumy przyjaciół użytkownika %s",
			'album:all' => "Wszystkie albumy",
			'album:group' => "Albumy grupy",
			'item:object:image' => "Zdjęcia",
			'item:object:album' => "Albumy",
			'tidypics:uploading:images' => "Proszę czekać. Wysyłanie zdjęć.",
			'tidypics:enablephotos' => 'Włącz albumy dla grup',
			'tidypics:editprops' => 'Edytuj właściwości zdjęcia',
			'tidypics:mostcommented' => 'Najczęściej komentowane zdjęcia',
			'tidypics:mostcommentedthismonth' => 'Najczęściej komentowane w tym miesiącu',
			'tidypics:mostcommentedtoday' => 'Najczęściej komentowane dziś',
			'tidypics:mostviewed' => 'Najczęściej oglądane zdjęcia',
			'tidypics:mostvieweddashboard' => 'Najczęściej oglądane tablice',
			'tidypics:mostviewedthisyear' => 'Najczęściej oglądane w tym roku',
			'tidypics:mostviewedthismonth' => 'Najczęściej oglądane w tym miesiącu',
			'tidypics:mostviewedlastmonth' => 'Najczęściej oglądane w poprzednim miesiącu',
			'tidypics:mostviewedtoday' => 'Najczęściej oglądane dziś',
			'tidypics:recentlyviewed' => 'Ostatnio oglądane zdjęcia',
			'tidypics:recentlycommented' => 'Ostatnio komentowane obrazy',
			'tidypics:mostrecent' => 'Ostatnio dodane obrazy',
			'tidypics:yourmostviewed' => 'Twoje najczęściej oglądane obrazy',
			'tidypics:yourmostrecent' => 'Twoje ostatnio dodane obrazy',
			'tidypics:friendmostviewed' => "Najczęściej oglądane obrazy użytkownika %s",
			'tidypics:friendmostrecent' => "Ostatnio dodane obrazy użytkownika %s",
			'tidypics:highestrated' => "Najwyżej oceniane obrazy",
			'tidypics:views' => "Odsłon: %s",
			'tidypics:viewsbyowner' => "przez %s użytkowników (wyłączając Ciebie)",
			'tidypics:viewsbyothers' => "(%s przez Ciebie)",
			'tidypics:administration' => 'Tidypics Administration',
			'tidypics:stats' => 'Statystyki',
			'tidypics:nophotosingroup' => 'Te grupy nie mają jeszcze żadnych zdjęć',

			'flickr:setup' => 'Flickr Setup',
			'flickr:usernamesetup' => 'Podaj nazwę użytkownika na Flickr:',
			'flickr:selectalbum' => 'Wybierz album, do którego zaimportować zdjęcia',
			'flickr:albumdesc' => 'Album, do którego zaimportować zdjęcia:',
			'flickr:importmanager' => 'Photoset Import Manager',
			'flickr:desc' => 'Kliknij na zbiorze, który chesz zaimportować do tej strony.<br />Zostaną utworzone kopie zdjęć i przechowywane na tej stronie, gdzie będą mogły być oglądane i komentowane.',
			'flickr:intro' => 'Flickr Integration pozwala na import zdjęć z konta Flickr. Aby rozpocząć proces, wpisz swoją nazwę użytkownika i wybierz album, do którego zaimportować zdjęcia. <br />Kiedy już zapiszesz te dane, kliknij na link Import Flickr Photos po lewej, aby wybrać który zestaw zdjęć z Flicker chcesz zaimportować.',
			'flickr:menusetup' => 'Flickr Setup',
			'flickr:menuimport' => 'Import Flickr Photos',
			
		//settings
			'tidypics:settings' => 'Ustawienia',
			'tidypics:admin:instructions' => 'To są podstawowe ustawienia Tidypics. Zmień je według własnych upodobań i kliknij Zapisz.',
			'tidypics:settings:image_lib' => "Biblioteka Obrazów",
			'tidypics:settings:thumbnail' => "Tworzenie Miniatur",
			'tidypics:settings:help' => "Pomoc",
			'tidypics:settings:download_link' => "Pokaż link do pobierania zdjęcia",
			'tidypics:settings:tagging' => "Włącz otagowywanie zdjęć",
			'tidypics:settings:photo_ratings' => "Włącz ocenianie zdjęć (wymagany plugin  Miguela Montesa lub kompatybilny)",
			'tidypics:settings:exif' => "Pokaż dane EXIF",
			'tidypics:settings:view_count' => "Pokaż licznik",
			'tidypics:settings:grp_perm_override' => "Pozwól uczestnikom grup na pełny dostęp do albumów grupy",
			'tidypics:settings:maxfilesize' => "Maksymalny rozmiar obrazka w megabajtach (MB):",
			'tidypics:settings:quota' => "User/Group Quota (MB) - 0 equals no quota",
			'tidypics:settings:watermark' => "Wpisz tekst pokazywany w znaku wodnym",
			'tidypics:settings:im_path' => "Podaj ścieżkę do komend ImageMagick (with trailing slash)",
			'tidypics:settings:img_river_view' => "How many entries in activity river for each batch of uploaded images",
			'tidypics:settings:album_river_view' => "Pokazuj okładkę albumu lub zbioru zdjęć dla nowego albumu",
			'tidypics:settings:largesize' => "Podstawowy rozmiar zdjęć",
			'tidypics:settings:smallsize' => "Rozmiar zdjęcia w widoku albumu",
			'tidypics:settings:thumbsize' => "Rozmiar miniatury",
			'tidypics:settings:im_id' => "ID obrazu",

			'tidypics:settings:heading:img_lib' => "Image Library Settings",
			'tidypics:settings:heading:main' => "Major Settings",
			'tidypics:settings:heading:river' => "Activity Integration Options",
			'tidypics:settings:heading:sizes' => "Thumbnail Size",
			'tidypics:settings:heading:groups' => "Group Settings",
	
		//actions

			'album:create' => "Utwórz nowy album",
			'album:add' => "Dodaj album",
			'album:addpix' => "Dodaj zdjęcia do albumu",
			'album:edit' => "Edytuj album",
			'album:delete' => "Usuń album",

			'image:edit' => "Edytuj obraz",
			'image:delete' => "Usuń obraz",
			'image:download' => "Pobierz obraz",

		//forms

			'album:title' => "Tytuł",
			'album:desc' => "Opis",
			'album:tags' => "Tagi",
			'album:cover' => "Utworzyć okładkę z tego obrazu?",
			'tidypics:quota' => "Miejsce wykorzystane:",

		//views

			'image:total' => "Zdjęć w albumie:",
			'image:by' => "Obraz dodany przez",
			'album:by' => "Album utworzony przez",
			'album:created:on' => "Utworzony",
			'image:none' => "Nie dodano jeszcze obrazów.",
			'image:back' => "Poprzedni",
			'image:next' => "Następny",

		// tagging
			'tidypics:taginstruct' => 'Wybierz obszar, który chcesz otagować',
			'tidypics:deltag_title' => 'Wybierz tagi, które chcesz usunąć',
			'tidypics:finish_tagging' => 'Zatrzymaj otagowywanie',
			'tidypics:tagthisphoto' => 'Otaguj to zdjęcie',
			'tidypics:deletetag' => 'Usuń tag zdjęcia',
			'tidypics:actiontag' => 'Tag',
			'tidypics:actiondelete' => 'Usuń',
			'tidypics:actioncancel' => 'Anuluj',
			'tidypics:inthisphoto' => 'W tym zdjęciu',
			'tidypics:usertag' => "Zdjęcia otagowane z użytkownikiem %s",
			'tidypics:phototagging:success' => 'Tag zdjęcia został dodany',
			'tidypics:phototagging:error' => 'Wystąpił bład podcza dodawania taga',
			'tidypics:deletetag:success' => 'Wybrane tagi zostały usunięte',
			
			'tidypics:tag:subject' => "Zostałeś dodany jako tag do zdjęcia",
			'tidypics:tag:body' => "Zostałeś dodany jako tag do zdjęcia %s przez %s.			
			
Zdjęcie możesz obejrzeć tutaj: %s",


		//rss
			'tidypics:posted' => 'wysłał zdjęcie:',

		//widgets

			'tidypics:widget:albums' => "Albumy zdjęć",
			'tidypics:widget:album_descr' => "Pokaz Twoich albumów zdjęć",
			'tidypics:widget:num_albums' => "Liczba albumów do pokazania",
			'tidypics:widget:latest' => "Najnowsze zdjęcia",
			'tidypics:widget:latest_descr' => "Wyświetl Twoje najnowsze zdjęcia",
			'tidypics:widget:num_latest' => "Liczba zdjęć do pokazania",
			'album:more' => "Pokaż wszystkie albumy",

		//  river

			//images
			'image:river:created' => "%s dodał zdjęcie %s do albumu %s",
			'image:river:item' => "zdjęcie",
			'image:river:annotate' => "komentarz do zdjęcia",
			'image:river:tagged' => "został wtagowany w zdjęcie",

			//albums
			'album:river:created' => "%s utworzył nowy album zdjęć",
			'album:river:group' => "w grupie",
			'album:river:item' => "album",
			'album:river:annotate' => "komentarz do albumu",

		// notifications
			'tidypics:newalbum' => 'Nowy album zdjęć',


		//  Status messages

			'tidypics:upl_success' => "Zdjęcia zostały pomyślnie wysłane.",
			'image:saved' => "Zdjęcia zostały pomyślnie zapisane.",
			'images:saved' => "Wszystke zdjęcia zostały pomyślnie zapisane.",
			'image:deleted' => "Zdjęcia zostały usunięte.",
			'image:delete:confirm' => "Czy na pewno usunąć to zdjęcie?",

			'images:edited' => "Twoje zdjęcia zostały zaktualizowane.",
			'album:edited' => "Album został zaktualizowany.",
			'album:saved' => "Album został zapisany.",
			'album:deleted' => "Album został usunięty.",
			'album:delete:confirm' => "Czy na pewno usunąć ten album?",
			'album:created' => "Nowy album został utworzony.",
			'tidypics:settings:save:ok' => 'Successfully saved the Tidypics plugin settings',

			'tidypics:upgrade:success' => 'Upgrade of Tidypics a success',
			
			'flickr:enterusername' => 'Musisz podać nazwę użytkownika Flickr',
			'flickr:savedusername' => 'Zapisano nazwę użytkownika: %s',
			'flickr:saveduserid' => 'Zapisano ID użytkownika: %s',
			'flickr:savedalbum' => 'Album zapisany - %s',

		//Error messages

			'tidypics:baduploadform' => "Wystąpił błąd na formularzy do wysyłania",
			'tidypics:partialuploadfailure' => "Wystąpiły błędy podczas wysyłania obrazów (%s z %s).",
			'tidypics:completeuploadfailure' => "Wysyłanie zdjęć nie powiodło się.",
			'tidypics:exceedpostlimit' => "Za dużo wielkich obrazów - spróbuj wysyłać mniej lub mniejsze obrazy.",
			'tidypics:noimages' => "Nie wybrano obrazów.",
			'tidypics:image_mem' => "Obraz jest za duży - za dużo bajtów",
			'tidypics:image_pixels' => "Obraz ma za dużą rozdzielczość",
			'tidypics:unk_error' => "Nieznany błąd wysyłania",
			'tidypics:save_error' => "Nieznany błąd podczas zapisu zdjęcia na serwerze",
			'tidypics:not_image' => "To jest nierozpoznawalny format obrazu",
			'tidypics:deletefailed' => "Nie udało się usuwanie.",
			'tidypics:deleted' => "Usuwanie pomyślne.",
			'image:downloadfailed' => "Ten obraz nie jest teraz dostępny.",
			'tidypics:nosettings' => "Administrator tej strony nie ustawił ustawień albumów zdjęć.",
			'tidypics:exceed_quota' => "Osiągnąłeś maksymalny rozmiar miejsca przydzielonego przez administratora",
			'images:notedited' => "Nie wszystkie zdjęcia zostały pomyślnie zaktualizowane",

			'album:none' => "Nie utworzono żadnych albumów.",
			'album:uploadfailed' => "Nie udało się zapisanie albumu.",
			'album:deletefailed' => "Nie udało się usunięcie albumu.",
			'album:blank' => "Nadaj temu albumowi tytuł i opis.",

			'tidypics:upgrade:failed' => "The upgrade of Tidypics failed",
			
			'flickr:errorusername' => 'Nazwa użytkownika %s nie została znaleziona na Flickr',
			'flickr:errorusername2' => 'Musisz podać nazwę użytkownika',
			'flickr:errorimageimport' => 'Ten obraz został już zaimportowany',
			'flickr:errornoalbum' => "Nie wybrano albumu. Wybierz i zapisz album: %s" 
	);

	add_translation("en",$english);
?>
