Microthemes for elgg.
------------------------

Allows very simple themes to be created by users.

Themes can be set for each user (appears in their profile and dashboard), for each group (themes the groups pages) or for the site (all of the rest).

Note this is not a theme in itself. It needs to work over some other theme, and some themes can interact better or worse with this. Standard elgg theme is tested, and the theme_loreahub theme is specially recommended (http://community.elgg.org/mod/plugins/read.php?guid=477603).

Installation: Put inside your mod/ folder and enjoy!!

Tickets and source repository:
	http://bitbucket.org/rhizomatik/elgg_microthemes/

License: See COPYING (GPLv2)

Includes the colorpicker from http://www.eyecon.ro/colorpicker/#download under the vendors directory which is not covered by our license.

--
devel@lorea.cc
