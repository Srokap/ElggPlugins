<?php
/**
 * Simple CHAT plugin created by JesusPrieto.net
 */

elgg_register_event_handler('init', 'system', 'chat');

function chat() {
	
elgg_register_page_handler('chat', 'chat_page_handler');

	$item = new ElggMenuItem('chat', elgg_echo('Chat Room'), 'chat');
	elgg_register_menu_item('site', $item);
	
}

function chat_page_handler($page) {
	$base = elgg_get_plugins_path() . 'chat/pages';
        require_once "$base/index.php";
	
	return true;
}
