<?php
/**
 * Chat Room Index
 *
 */

// Load Elgg engine
    include_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

// set the title
    $title = "Chat Room";
 
// start building the main column of the page
    $area2 = elgg_view_title($title);

    $area2 .= '

<iframe
height="500"
width="800"
src="http://baptistfellowshipnetwork.org/members/mod/chat/microchat/">
</iframe>




';
    $params=array(
     'content' => $area2,
     'sidebar_alt' => $sidebar,
     );
    $body = elgg_view_layout('two_column_left_sidebar',$params);
    page_draw($title, $body); 
