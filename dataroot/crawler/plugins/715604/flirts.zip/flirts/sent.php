<?php
	/**
	 * Elgg Gifts plugin
	 * Send gifts to you friends
	 *
	 * @package Gifts
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Christian Heckelmann
	 * @copyright Christian Heckelmann
	 * @link http://www.heckelmann.info
	 */

	// Show your sent flirts

	// Start engine
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	$area2 = elgg_view_title(elgg_echo('flirts:sent'));

       	$user_guid = get_loggedin_userid();

        $area2 .= elgg_list_entities(array('types' => 'object', 'subtypes' => 'flirt', 'owner_guids' => $user_guid));

	set_context('flirts');

	// Format page
	$body = elgg_view_layout('two_column_left_sidebar', $area1, $area2);

	// Draw it
	echo page_draw(elgg_echo('flirts:yourflirts'),$body);
?>