<?php
	/**
	 * Elgg Gifts plugin
	 * Send gifts to you friends
	 *
	 * @package Gifts
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Christian Heckelmann
	 * @copyright Christian Heckelmann
	 * @link http://www.heckelmann.info
	 */

	// only logged in users
	gatekeeper();
        action_gatekeeper();

	// get the form input
	$receiver = get_input('send_to');
	$flirt_id = get_input('flirt_id');
	$body = get_input('body');
	$cost = get_input('flirtcost');
        $access = get_input('access');

	$sender = get_entity(get_loggedin_userid());

	// Userpoints
	$useuserpoints  = get_plugin_setting('useuserpoints', 'flirts');
	if($useuserpoints == 1 && function_exists('userpoints_subtract')) {
		$pTemp = userpoints_get(get_loggedin_userid());
		$points = $pTemp['approved'];

		// Set new Point Value
		if(userpoints_subtract(get_loggedin_userid(), $cost, 'flirts')) {
			system_message(elgg_echo('flirts:pointsuccess'));
		}else{
			system_message(elgg_echo('flirts:pointfail'));
		}
	}

	// No Friend selected?
	if (empty($receiver) || empty($flirt_id)) {
		register_error(elgg_echo("flirts:blank"));
		forward("pg/flirts/".$sender->name."/sendflirt");
	}

	// create a flirts object
	$flirt = new ElggObject();
	$flirt->description = $body;
	$flirt->receiver = $receiver;
	$flirt->flirt_id = $flirt_id;
	$flirt->subtype = "flirt";

        $flirt->access_id = $access;

	$flirt->owner_guid = get_loggedin_userid();

	// save to database
	$flirt->save();

	$sender = get_entity(get_loggedin_userid());
	$msgto = get_entity($receiver);

	// send mail notification
	global $CONFIG;
	notify_user($msgto->getGUID(), $sender->getGUID(), elgg_echo('flirts:mail:subject'),
		sprintf(
					elgg_echo('flirts:mail:body'),
					$sender->name,
					$CONFIG->wwwroot . "pg/flirts/" . $msgto->username . "/index"
				)
	);


	// Add to river
	add_to_river('river/object/flirts/create','flirts',$flirt->owner_guid,$flirt->receiver);
        system_message(elgg_echo('flirts:sendok'));
	// display flirt
	forward($flirt->getURL());
?>