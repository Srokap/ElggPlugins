<?php

	/**
	 * Save flirts settings
	 * Thanks for the Userpoint Api where i got this pice of code from
	 */
        gatekeeper();
        action_gatekeeper();

	global $CONFIG;

	// Params array (text boxes and drop downs)
	$params = get_input('params');
	$result = false;
	foreach ($params as $k => $v) {
		if (!set_plugin_setting($k, $v, 'flirts')) {
			register_error(sprintf(elgg_echo('flirts:settings:savefail'), 'userpoints'));
			forward($_SERVER['HTTP_REFERER']);
		}
	}

	system_message(elgg_echo('flirts:settings:saveok'));

	forward($_SERVER['HTTP_REFERER']);
?>
