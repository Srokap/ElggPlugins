<?php

	/**
	 * Elgg Gifts plugin
	 * Send gifts to you friends
	 * 
	 * @package Gifts
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Christian Heckelmann
	 * @copyright Christian Heckelmann
	 * @link http://www.heckelmann.info
	 */


$english = array( 
	 'flirts:menu'  =>  "flirts" , 
	 'flirts:yourflirts'  =>  "My flirts",
     'flirts:allflirts'  =>  "All flirts",
	 'flirts:sent'  =>  "sent flirts",
     'flirts:sendflirts' => "flirt with a friend",
     'flirts:friend' => "Friend",
	 'flirts:message' => "Message",
     'flirts:selectflirt' => "choose how you want to flirt",
     'flirts:flirt' => "flirted",
     'flirts:send' => "flirt",     
	 'flirts:sendok' => "flirt sent successful",
     'flirts:object' => "%s has %s %s",
     'flirts:river' => "%s has %s with ",
     'flirts:blank' => "Please select a friend!",

	 'flirts:widget' => "flirts Widget",
     'flirts:widget:num_display' => "Number of flirts",
     'flirts:widget:description' => "Show your flirts",

	 'flirts:pointssum' => "You have %s points left to flirt",	 
	 'flirts:notenoughpoints' => "You do not have enough Points to flirt!",
	 'flirts:pointscost' => "Price ",
	 'flirts:pointfail' => "An error occured within the userpoints api!",
	 'flirts:pointsuccess' => "flirt paid!",

     'item:object:flirt' => 'flirts',
     'flirts:settings:number' => "How many flirts do you want to make",
     'flirts:settings:title' =>  "flirt",
	 'flirts:settings:globalsettings' =>  "Settings",
     'flirts:settings:flirtsettings' =>  "flirts",
	 'flirts:settings:useuserpoints' =>  "Use Userpoints",
     'flirts:settings:userpoints' =>  "Points",
	 'flirts:settings:image' =>  "Image",
	 'flirts:settings:showallyes' =>  "Yes",
	 'flirts:settings:showallno' =>  "No",
	 'flirts:settings:showallflirts' =>  "Show All flirts",
	 'flirts:settings:saveok' =>  "Settings saved successfull",
	 'flirts:settings:savefail' =>  "Could not save settings!",

	 'flirts:mail:subject' => "%s has flirted with you!",
	 'flirts:mail:body' => "%s has flirted with you. 
     
To view your flirt click the link below: %s 

You cannot reply to this email."
); 
	
	add_translation("en",$english);
?>