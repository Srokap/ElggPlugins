<?php

	/**
	 * Elgg hoverover extender for gifts
	 *
	 * @package Gifts
	 */
if (isloggedin()) {
?>

	<p class="user_menu_flirt">
		<a href="<?php echo $vars['url']; ?>mod/flirts/sendflirt.php?send_to=<?php echo $vars['entity']->guid; ?>"><?php echo elgg_echo("flirts:send"); ?></a>
	</p>
<?php
}
?>
