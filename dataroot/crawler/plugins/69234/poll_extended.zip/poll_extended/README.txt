Poll extended plugin
=======================
Features:
- Extend the edit poll view to support before and after description fields.
- Add support for poll types
- Add support for assigning poll 'ownership' to a group
- Widget for show poll posts in the profile
- Overwrite post icon with the group icon (if it is associated to a group)

Install
-------

Just drop it on your mod directory and then go to the admin panel and activate it. 
Keep in mind that this plugins overwrites some poll plugin behaviors so it needs
to be loaded after it.

the order in Tool Admin should look like:

	poll
	poll_extended
	....

NOTES:
======

This Plugin REQUIRES the latest version of the Simple Poll Plugin (1.3.2 or better)
to function properly.

If you have an earlier version you must add the following lines of code to mod/poll/index.php
(starting at line 32)

	// Get a poll posts
		
		if(!$polls = $page_owner->getObjects('poll',50,0))
		{
			//if we didn't get any polls, try to get them from metadata
			$polls = get_entities_from_metadata("content_owner",page_owner(), "object","poll",0, 5, false,false,false);
		}
		
		//if there are still no polls, show a friendly message
		if(empty($polls))
		{
			$area2 .= sprintf(elgg_echo("polls:nonefound"),$page_owner->name);
		}
			
		foreach($polls as $poll)
		{
			$area2 .= elgg_view("poll/listing", array('entity' => $poll));
		}
 
	// code continues-->

You will also need to add the following to the poll/languages/en.php file:

	'polls:nonefound' => "No Polls were found from %s",


How works the poll post group 'ownership' works?
------------------------------------------------

This plugin lets the user specify whether a poll is published to their profile or a 
group they belong to. The user continues being the post owner, however the Poll is 
published in their profile AND in the group profile.

At this moment the group owner couldn't edit or deny poll posts content but its a 
planed feature to support some kind of pre-approval process to let group owners 
accept/deny contents for their group.