<?php
/**
 * Elgg poll_extended plugin
 *
 * @package Elggpoll_extended
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author John Mellberg <big_lizard_clyde@hotmail.com>
 * @copyright John Mellberg - 2009
 */

/**
 * poll extended initialization
 *
 * Register css extensions, contentes view for groups, widgets and event handlers
 */
function poll_extended_init(){
  global $CONFIG;
  extend_view("css","pollextended/css");

  extend_view("poll/fields_before","poll/forms/type");
  extend_view("poll/fields_after","groups/groupselector");

  extend_view('groups/left_column', 'groups/grouppolls',1);

  //add_widget_type('poll',elgg_echo('poll:widget:title'), elgg_echo('poll:widget:description'));

  
  if(is_plugin_enabled("itemicon")){
  	if(!isset($CONFIG->itemicon)){
  	  $CONFIG->itemicon[]=array();
  	}
  	$CONFIG->itemicon[] = "poll";
    extend_view("poll/fields_after","itemicon/add");
  }

  $options = array(
  				"--"=>elgg_echo("poll:type:other"),
  				"poll:type:news"=>elgg_echo("poll:type:news"),
  				"poll:type:goodpractice"=>elgg_echo("poll:type:goodpractice"),
  				"poll:type:event"=>elgg_echo("poll:type:event"),
  );

  if(file_exists(dirname(__FILE__)."/config.php")){
    @require_once dirname(__FILE__)."/config.php";
  }

  $CONFIG->poll_extended = $options;
}

function poll_submenus() {
		
	global $CONFIG;
		
	$page_owner = page_owner_entity();
		
	// Group submenu option	
	if ($page_owner instanceof ElggGroup && get_context() == 'groups') {
		add_submenu_item(sprintf(elgg_echo("polls:user"),$page_owner->name), $CONFIG->wwwroot . "pg/poll/" . $page_owner->username);
	}
}

//Register Event handlers
register_elgg_event_handler('pagesetup','system','poll_submenus');
register_elgg_event_handler('init','system','poll_extended_init');

// - new JMM
// Register actions
global $CONFIG;
register_action("poll/add",false,$CONFIG->pluginspath . "poll_extended/actions/add.php");
register_action("poll/edit",false,$CONFIG->pluginspath . "poll_extended/actions/edit.php");

?>