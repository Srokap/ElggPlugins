<?php
/**
 * poll owner selector view
 *
 *
 * @package ElggpollExtended
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author John Mellberg <big_lizard_clyde@hotmail.com>
 * @copyright John Mellberg - 2009
 *
 */

if(get_plugin_setting("grouppolls","poll_extended")=="yes"){

  $field_label = elgg_echo("content:owner");
  if(isset($vars["label"])){
    $field_label = $vars["label"];
  }

  $value = "";
  if(isset($vars["entity"])){
    $value = $vars["entity"]->content_owner;
  }

  $options = array(
  ""=>elgg_echo("my:profile"),
  );

  $objects = get_entities_from_relationship("member",page_owner(),false,"group");
  if(!empty($objects)){
    foreach($objects as $object){
      $options["{$object->guid}"]=$object->name;
    }
  }

  ?>

<p><label><?php echo $field_label; ?></label><br />
  <?php echo elgg_view("input/pulldown",array("internalname"=>"content_owner","options_values"=>$options,"value"=>$value)); ?>
</p>
<?php
}
?>