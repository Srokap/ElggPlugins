<?php
/**
 * poll type selector view
 *
 * @package Elggpoll_extended
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author John Mellberg <big_lizard_clyde@hotmail.com>
 * @copyright John Mellberg - 2009
 *
 *
 */
global $CONFIG;

if(get_plugin_setting("extra_types","poll_extended")=="yes"){

  $value = "";
  if(isset($vars["entity"])){
    $value = $vars["entity"]->poll_type;
  }

  $options = $CONFIG->poll_extended;
  ?>
<p><label><?php echo elgg_echo("poll:type"); ?></label><br />
  <?php echo elgg_view("input/pulldown",array("internalname"=>"poll_type","options_values"=>$options,"value"=>$value)); ?>
</p>
<?php
}
?>