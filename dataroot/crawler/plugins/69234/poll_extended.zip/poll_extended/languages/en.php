<?php
$english = array(
/**
 * poll types translations
 */
  'poll:type'=>"Content type",
  'poll:type:other'=>"Other",
  'poll:type:news'=>"News",
  'poll:type:goodpractice'=>"Good practice",
  'poll:type:event'=>"Event",

/**
 * poll widget
 */
  'poll:widget:title'=>"polls",
  'poll:widget:description'=>"This widget shows the specified number of polls",
  'poll:widget:default_view'=>"Default widget view",
  'poll:widget:default'=>"Default",
  'poll:widget:compact'=>"Compact",

  'polls:empty'=>"There is no Polls posted at the moment",

  'poll:extratypes:enable'=> "Enable poll type support?",
  'poll:group:polls'=> "Enable group post publishing?",
  'poll:group:iconoverwrite'=>"Enable icon overwrite when content is associated to a group?",

// Group related translations
  'group:polls'=>"Polls",
  'group:polls:empty'=>"This Group hasn't posted any polls yet.",

//
  'content:owner'=>"Assign to",
  'my:profile'=>"My profile",
  'publish:for'=>"published in %s",

);
add_translation("en",$english);

?>