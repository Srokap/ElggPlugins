   <b>RiverView</b>
   <select name="params[mobileriverview]">
      <option value="friend" <?php if ($vars['entity']->mobileriverview == 'friend') echo " selected=\"yes\" "; ?>><?php echo elgg_echo("mobile:friend"); ?></option>
      <option value="" <?php if ($vars['entity']->mobileriverview != 'friend') echo " selected=\"yes\" "; ?>><?php echo elgg_echo("mobile:everyone"); ?></option>
   </select>
</p>
<p>
   <b><?php echo elgg_echo("mobile:ans:disphotab"); ?>?</b>
   <select name="params[photostab]">
      <option value="no" <?php if ($vars['entity']->photostab == 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo("mobile:no"); ?></option>
      <option value="" <?php if ($vars['entity']->photostab != 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo("mobile:yes"); ?></option>
   </select>
</p>