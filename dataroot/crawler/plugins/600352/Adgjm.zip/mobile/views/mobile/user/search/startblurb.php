
<div class="contentWrapper">
	<?php 
	
		echo sprintf(elgg_echo("user:search:startblurb"),$vars['tag']); 
	
	?>
</div>