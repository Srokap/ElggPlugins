<?php
	echo elgg_view_title($vars['title']);
?>
<div class="gallerywrap">
<div class="clearfloat"></div>
<?php
	echo $vars['content'];
?>
<div class="clearfloat"></div>
</div>