
<div class="contentWrapper">
	<?php 
	
		echo sprintf(elgg_echo("tag:search:startblurb"),$vars['tag']); 
	
	?>
</div>