<?php

	/**
	 * Elgg default widget view
	 * 
	 * @package Elgg
	 * @subpackage Core

	 * @author Curverider Ltd

	 * @link http://elgg.org/
	 */

		echo elgg_view('widgets/wrapper',$vars);

?>