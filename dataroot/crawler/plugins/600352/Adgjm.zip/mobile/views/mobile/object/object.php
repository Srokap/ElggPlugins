<?php
	/**
	 * Elgg default object view.
	 * This is a placeholder.
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @author Curverider Ltd
	 * @link http://elgg.org/
	 */

	$entity = $vars['entity'];

?>
<div>
	<p><?php echo $entity->title; ?></p>
	<p><?php echo $entity->description; ?></p>
</div>