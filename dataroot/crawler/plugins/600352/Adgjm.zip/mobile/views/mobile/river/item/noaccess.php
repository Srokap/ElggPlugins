<?php

	echo elgg_echo('river:noaccess');

?>