<?php
/**
 * Elgg Mobile
 * A Mobile Client For Elgg
 *
 * @package Elgg
 * @subpackage Core
 * @author Mark Harding
 * @link http://maestrozone.com
 *
 */
?>


<div class="messages">
    <h3><?php elgg_echo('mobile:acstream'); ?></h3>
    
<?php
/**
 * Elgg river for dashboard.
 *
 * @package Elgg
 * @author Curverider Ltd
 * @link http://elgg.com/
 */

/// Extract the river
$river = $vars['river'];
?>
<div id="river">
<?php
$type = get_plugin_setting('mobileriverview', 'mobile');
$subtype = '';
$relationship_type = "";
$subject_guid = 0;
if (empty($type)){
echo elgg_view_river_items(0, 0, $type, $content[0], $content[1], '', 10 ,0,0,true);}
if ($type == "friend") {
echo elgg_view_river_items($_SESSION['user']->getGuid(), 0, $type, $content[0], $content[1], '', 10 ,0,0,true);}
?>
</div></div>