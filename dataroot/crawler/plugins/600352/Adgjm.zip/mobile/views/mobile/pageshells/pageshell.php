<?php
// Set title
if (empty($vars['title'])) {
$title = $vars['config']->sitename;
} else if (empty($vars['config']->sitename)) {
$title = $vars['title'];
} else {
$title = $vars['config']->sitename . ": " . $vars['title'];
}
echo elgg_view('page_elements/header', $vars);
echo elgg_view('page_elements/header_contents', $vars); ?>
<div id="layout_canvas">

<div id="messages">
<?php echo elgg_view('messages/list', array('object' => $vars['sysmessages']));
echo $vars['body']; ?>
</div>
</div><!-- /#layout_canvas -->
<div class="mobilecopy">
</div><?php echo elgg_view('page_elements/footer', $vars); ?>