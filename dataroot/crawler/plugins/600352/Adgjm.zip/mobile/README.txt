Installation   

Extract into the mod folder. Enable in plugin tools and then run upgrade.php.   

Donations

Donating to this plugin will improve development.   
