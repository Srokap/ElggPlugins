<?php

   $english = array(
   
      /**
       * Menu items and titles
       */
   
         'mobile:river:what' => "What do you think?",
         'mobile:river:title' => "Activity",
         'mobile:profile:activity' => "Activities",
         'mobile:profile:info' => "Info",
         'mobile:needaccount' => "Need an account?",
         'mobile:signup' => "Signup now.",
         'mobile:full' => "Desktop",
         'mobile:mobile' => "Mobile",
         'mobile:profile:photos' => 'Photos',
         'Share!' => "Share!"
         'mobile:friend' => 'Friends',
         'mobile:everyone' => 'Everyone',
         'mobile:yes' => 'Yes',
         'mobile:no' => 'No',
         'mobile:ans:diphotab' => 'Display the photos tab',  
         'mobile:acstream' => 'My activities',
   );
               
   add_translation("en",$english);

?>