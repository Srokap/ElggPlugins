<?php

   $indonesian = array(
   
      /**
       * Item menu dan judul
       */
   
         'mobile:river:what' => "Apa yang Anda pikirkan?",
         'mobile:river:title' => "Aktivitas",
         'mobile:profile:activity' => "Aktivitas",
         'mobile:profile:info' => "Info",
         'mobile:needaccount' => "Butuh akun baru?",
         'mobile:signup' => "Daftar disini.",
         'mobile:full' => "Desktop",
         'mobile:mobile' => "Mobile",
         'mobile:profile:photos' => 'Foto',
         'Share!' => "Bagi!"
         'mobile:friend' => 'Teman',
         'mobile:everyone' => 'Apapun',
         'mobile:yes' => 'Ya',
         'mobile:no' => 'Tidak',
         'mobile:ans:diphotab' => 'Apakah Tampilkan tab foto?',  
         'mobile:acstream' => 'Aktivitas saya',
   );
               
   add_translation("id",$indonesian);

?>