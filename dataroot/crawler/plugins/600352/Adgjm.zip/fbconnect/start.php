<?php

/**
 * Elgg Facebook Connect plugin
 *
 * @package fbconnect
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine
 * @copyright Curverider 2009
 * @link http://elgg.org/
 */

// load plugin model
require_once(dirname(__FILE__)."/models/model.php");

/**
 * fbconnect initialisation
 *
 * These parameters are required for the event API, but we won't use them:
 *
 * @param unknown_type $event
 * @param unknown_type $object_type
 * @param unknown_type $object
 */

function fbconnect_init() {

	// Load system configuration
	global $CONFIG;

	// Load the language files
	register_translations($CONFIG->pluginspath . "fbconnect/languages/");

	extend_view("account/forms/login", "fbconnect/login");

	// Extend system CSS with our own styles
	extend_view('css','fbconnect/css');

	register_plugin_hook('usersettings:save','user','fbconnect_user_settings_save');

}

function fbconnect_pagesetup() {
	// make profile edit links invisible for Facebook accounts
	// that do not have Facebook control explicitly turned off
	if ((get_context() == 'profile')
	&& ($page_owner_entity = page_owner_entity())
	&& ($page_owner_entity->getSubtype() == "facebook")
	&& ($page_owner_entity->facebook_controlled_profile != 'no')
	) {
		extend_view('metatags','fbconnect/hide_profile_embed');
	}

	extend_elgg_settings_page('fbconnect/settings/usersettings', 'usersettings/user');
}

/**
 * Cron job
 * Every 12 hours we need to update the Facebook information
 *
 */
function fbconnect_cron($hook, $entity_type, $returnvalue, $params) {
	$i = 0;
	$twelve_hours = 60*60*12;
	set_context('fbconnect');
	// get the Facebook users
	$user_count = get_entities('user','facebook',0,'',10,0,true);
	if ($user_count) {
		$users = get_entities('user','facebook',0,'',$user_count,0,false);
		foreach ($users as $user) {
			// sync the user data with Facebook if the data is older than
			// twelve hours
			if(($user->facebook_controlled_profile != 'no') && ((time()-$user->facebook_sync_time) > $twelve_hours)) {
				fbconnect_update_profile($user,FALSE);
				$i += 1;
			}
		}
	}

	echo sprintf(elgg_echo('fbconnect:cron_report'),$i);
}

// allows cron job to update Facebook users

function fbconnect_can_edit($hook_name, $entity_type, $return_value, $parameters) {
	 
	$entity = $parameters['entity'];
	$context = get_context();
	if ($context == 'fbconnect' && $entity->getSubtype() == "facebook") {
		// should be able to update Facebook user data
		return true;
	}
	return null;
}

function fbconnect_icon_url($hook_name,$entity_type, $return_value, $parameters) {
	$entity = $parameters['entity'];
	if (($entity->getSubtype() == "facebook") && ($entity->facebook_controlled_profile != 'no')) {
		if (in_array($parameters['size'],array('tiny','small','topbar'))) {
			return $entity->facebook_icon_url_mini;
		} else {
			return $entity->facebook_icon_url_normal;
		}
	}
}

//register_plugin_hook('entity:icon:url','user','fbconnect_icon_url');
register_plugin_hook('permissions_check','user','fbconnect_can_edit');
register_plugin_hook('cron', 'hourly', 'fbconnect_cron');
register_elgg_event_handler('init','system','fbconnect_init');
register_elgg_event_handler('pagesetup','system','fbconnect_pagesetup');

?>