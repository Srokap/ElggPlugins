Facebook Connect Readme

Please note: If Facebook shutdown FBConnect for any reason, users on your site who have 
logged in with FBConnect will no longer have access to your site until Facebook bring their service back online.

To use:

1) Go to Facebook and register your site as an app to obtain an API key and secret - http://www.facebook.com/developers/createapp.php

2) Once you have created your app, under 'connect' you need to enter a Connect URL and Account preview URL - these will both be your Elgg site URL

3) Enable the plugin, enter your api key and secret and you are ready to go