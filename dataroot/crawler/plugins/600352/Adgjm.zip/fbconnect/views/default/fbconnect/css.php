#facebook_connect {
	padding: 10px 0 0 0;
}