	<link rel="stylesheet" href="<?php echo $vars['url']; ?>mod/fbconnect/hide_profile_css.css?lastcache=<?php echo $vars['config']->lastcache; ?>" type="text/css" />
