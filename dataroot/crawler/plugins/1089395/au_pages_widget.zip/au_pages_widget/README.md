AU-Pages-Widget-1.8.x
=====================

Allows additional configuration for the pages widget in Elgg 1.8

plugin should reside in mod/au_pages_widget