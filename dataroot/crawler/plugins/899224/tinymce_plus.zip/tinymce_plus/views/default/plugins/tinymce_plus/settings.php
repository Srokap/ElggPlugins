<?php
/**
 * TinyMCE plugin settings.
 * 
 */
 
$mode = $vars['entity']->mode;
if (!$mode) {
	$mode = 'rich';
} 
?>
<div>
	<?php
		echo elgg_echo('tinymce:initial_status') . ' ';
		echo elgg_view('input/dropdown', array(
			  'name' => 'params[mode]',
			  'options_values' => array(
				'rich' => elgg_echo('tinymce:rich_text'),
				'plain' => elgg_echo('tinymce:plain_text'),
			),
			'value' => $mode,
		));
	?>
</div>

