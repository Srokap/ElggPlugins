<?php
/**
 * TinyMCE wysiwyg editor
 *
 * @package ElggTinyMCE
 *
 * TinyMCE plugin extended with configuration option to set default mode to rich text or plain text.
 *
 * Version 1.0
 */

elgg_register_event_handler('init', 'system', 'tinymce_plus_init');

function tinymce_plus_init() {
	elgg_extend_view('css/elgg', 'tinymce_plus/css');
	elgg_extend_view('css/admin', 'tinymce_plus/css');

	elgg_register_js('tinymce', 'mod/tinymce_plus/vendor/tinymce/jscripts/tiny_mce/tiny_mce.js');
	elgg_register_js('elgg.tinymce', elgg_get_simplecache_url('js', 'tinymce'));
	elgg_register_simplecache_view('js/tinymce');
	
	elgg_extend_view('input/longtext', 'tinymce_plus/init');
	
	elgg_extend_view('embed/custom_insert_js', 'tinymce_plus/embed_custom_insert_js');
	
	elgg_register_plugin_hook_handler('register', 'menu:longtext', 'tinymce_longtext_menu');
}

function tinymce_longtext_menu($hook, $type, $items, $vars) {
	$toggle_label = elgg_echo('tinymce:remove');
	$mode = elgg_get_plugin_setting('mode', 'tinymce_plus');

  if ($mode=='plain')
		 $toggle_label = elgg_echo('tinymce:add');
		
	$items[] = ElggMenuItem::factory(array(
		'name' => 'tinymce_toggler',
		'link_class' => 'tinymce-toggle-editor elgg-longtext-control',
		'href' => "#{$vars['id']}",
		'text' => $toggle_label,
	));
	
	return $items;
}


