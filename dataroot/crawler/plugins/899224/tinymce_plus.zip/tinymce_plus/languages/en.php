<?php
/**
 * TinyMCE language pack.
 *
 * @package ElggTinyMCE
 */

$english = array(
	'tinymce:remove' => "Remove editor",
	'tinymce:add' => "Add editor",
	'tinymce:word_count' => 'Word count: ',
	
	'tinymce:initial_status' => "Initial mode",
	'tinymce:rich_text' =>	"Rich text",
	'tinymce:plain_text' =>  "Plain text"
	
);

add_translation("en", $english);