##  Important instruction

1. Read install.txt before installation.
2. Izap-elgg-bridge must be acvtivated and the same can be get from > [Pluginlotto](http://www.pluginlotto.com).

 