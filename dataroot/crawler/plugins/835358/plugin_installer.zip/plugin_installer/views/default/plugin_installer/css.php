<?php
	/**
	* Plugin Installer
	* 
	* @package plugin_installer
	* @author ColdTrick IT Solutions
	* @copyright Coldtrick IT Solutions 2009
	* @link http://www.coldtrick.com/
	*/
?>
.plugin_active {
	color:green;
}

.plugin_inactive {
	color:red;
}