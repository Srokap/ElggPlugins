<?php
	$spanish = array(
		// Main title
		'plugin_installer' => "Instalador de Plugin",
		'plugin_installer:title' => "Instalador de Plugin",
		'plugin_installer:shorttitle' => "Instalador de Plugin",
		
		'plugin_installer:install' => "Instalar",
		'plugin_installer:uninstall' => "Desinstalar",
		
		'plugin_installer:export' => "Exportar el Plugin a Zip",
		
		// Upload
		'plugin_installer:upload' => "Actualizar",
		'plugin_installer:upload:overwrite' => "Sobreescribir el plugin actual.",
		'plugin_installer:upload:success' => "Plugin instalado correctamente",
		'plugin_installer:upload:missing' => "No ha habido plugin subido. Selecciones uno",
		'plugin_installer:upload:error' => "Error al instalar el nuevo plugin",
		'plugin_installer:upload:error:nomanifest' => "El plugin no contiene el file manifest",
		'plugin_installer:upload:error:nostart' => "El plugin no contiene un fichero de inicio",
		'plugin_installer:upload:error:unzip' => "Error mientras descomprime el plugin",
		'plugin_installer:upload:error:pluginexists' => "El plugin aun existe y no permite su sobrescritura",
	
		// uninstall
		'plugin_installer:uninstall:noplugin' => "Error en la desinstalaci&oacute;n. Plugin no seleccionado.",
		'plugin_installer:uninstall:error' => "Error en la desinstalaci&oacute;n. Fallo al eliminar el plugin. Probablemente no tiene permisos.",
		'plugin_installer:uninstall:success' => "Plugin eliminado correctamente.",
		
		// export
		'plugin_installer:export:error' => "Error al exportar. Fichero zip no puede ser creado.",
		'plugin_installer:export:noplugin' => "Error al exportar. No hay plugin seleccionado.",
	);
	
	add_translation("es", $spanish);
?>
