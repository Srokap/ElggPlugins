<?php

	$spanish = array(
	
		/**
		 * youtube widget details
		 */
		
	
		'youtube:id' => 'Introduzca el video url de youtube.',
		'youtube:whatisid' => 'Si no sabe que poner, busque por el c&oacute;igo despues de la barra invertida.',
		
		 /**
	     * youtube widget river
	     **/
	        
	        //generic terms to use
	        'youtube:river:created' => "%s a&ntilde;dido al componente youtube.",
	        'youtube:river:updated' => "%s componente actualizado desde youtube.",
	        'youtube:river:delete' => "%s componente eliminado.",
	        
		
	);
					
	add_translation("es",$spanish);

?>
