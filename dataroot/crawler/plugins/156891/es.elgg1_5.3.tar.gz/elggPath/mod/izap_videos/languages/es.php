<?php
/**
* iZAP izap_videos
*
* @package youtube, vimeo, veoh and onserver uploading
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.5-1.0
*/

	$spanish = array (
		
		'izap_videos' => "V&iacute;deos",
		'videos' => "V&iacute;deos",
		'izap_videos:videos' => "Mis v&iacute;deos",
		'izap_videos:add' => "A&ntilde;adir el nuevo v&iacute;deo",
		'izap_videos:addgroup' => "A&ntilde;adir el video del grupo",
		'izap_videos:user' => "v&iacute;deo de %s",
		'izap_videos:addurl' => "Introduzca una url del v&iacute;deo. (Permite Youtube, Vimeo, Veoh)",
		'izap_videos:title' => "Introduzca el t&iacute;tulo",
		'izap_videos:getvideo' => "Consiga el v&iacute;deo",
		'izap_videos:access' => "Acceso",
		'izap_videos:tags' => "Etiquetas para el Video",
		'izap_videos:blank' => "Por favor introduzca una url v&aacute;lida",
		'izap_videos:blanktitle' => "Por favor, introduzca el t&iacute;tulo",
		'izap_videos:saveerror' => "Lo lamento, el v&iacute;deo no puede ser guardado",
		'izap_videos:saved' => "Su v&iacute;deo ha sido guardado",
		'izap_videos:everyone' => "Todos los v&iacute;deos",
		'izap_videos:time' => "A&ntilde;adido en %s",
		'izap_videos:remove' => "Quiere eliminar este v&iacute;deo ?",
		'izap_videos:deleted' => "El v&iacute;deo ha sido eliminado correctamente",
		'izap_videos:notdeleted' => "El v&iacute;deo no ha sido eliminado",
		'izap_videos:wrongid' => "Lo lamento, el v&iacute;deo ha sido eliminado o tiene un id incorrecto",
		'izap_videos:frnd' => "V&iacute;deos de mis amig@s",
		'izap_videos:userfrnd' => "V&iacute;deos %s de mis amigos",
		'izap_videos:all' => "Todos los v&iacute;deos",
		'izap_videos:river:added' => "A&ntilde;adido un nuevo %s ",
		'izap_videos:river:video' => "V&iacute;deo",
		'izap_videos:river:annotate' => " un comentario en ",
		'izap_videos:widget' => "Lista de los &uacute;ltimos v&iacute;deos a&ntilde;adidos por usuari@s",
		'item:object:izap_videos' => "V&iacute;deos",
		'izap_videos:numbertodisplay' => "N&uacute;mero de v&iacute;deos a mostrar.",
		'izap_videos:play' => "Reproducir el v&iacute;deo seleccionado",
		'izap_videos:play:widget' => "Este componente no puede reproducir el v&iacute;deo elegido.",
		'izap_videos:chosevideo' => "Elija el v&iacute;deo a reproducir",
		'izap_videos:notfound' => "A&uacute;n no hay v&iacute;deos.",
		'izap_videos:error' => "Error al traer el v&iacute;deo desde la url. O es una url incorrecta o no hay v&iacute;deo.",
		'izap_videos:addtoyour' => "A&ntilde;adir este v&iacute;deo a mis v&iacute;deos.",
		'izap_videos:condition' => "* Arriba, el t&iacute;tulo, etiquetas y descripci&oacute;n no sobrescribir&aacute;n la informaci&oacute;n original.<br>* La fuente del v&iacute;deo es requerida (URL o subida).",
		'izap_videos:geterror' => "No puedo conseguir el v&iacute;deo desde ese lugar. El lugar no responde",
		'izap_videos:description' => "Descripci&oacute;n",
		'izap_videos:edit' => "Editar",
		'izap_videos:blank:title' => "El t&iacute;tulo no puede ir en blanco",
		'izap_videos:save' => "Guardar",
		'izap_videos:missingfields' => "Los campos requRequired fields are missing.",
		'izap_videos:autoplay' => "Hacer autoplay",
		'izap_videos:views' => "Vistas totales",
		'izap_videos:tagcloud' => "V&iacute;deos m&aacute;s vistos",
		'izap_videos:top' => "V&iacute;deos m&aacute;s vistos",
		'izap_videos:fopenerror' => "Pida a su administrador poner <b>'allow_url_fopen = On'</b> en su fichero php.ini.",
		'izap_videos:errorCode' => "Error al traerse datos desde la url. O la url est&aacute; mal o no hay v&iacute;deo",
		'izap_videos:errorCode101' => "No puedo conseguir el v&iacute;deo del lugar. El lugar no responde.",
		'izap_videos:errorCode102' => "Este v&iacute;deo no pertenece a veoh, porfavor, copie el v&iacute;deo original veoh.",
        'izap_videos:errorCodeArray' => "Error la buscar datos desde la url. La url est&aaucte; mal o no hay v&iacute;deo",
		'izap_videos:groups' => "V&iacute;deos de %s",
        'izap_videos:group:enablevideo' => "Habilitar v&iacute;deos de comunidades",
		'izap_videos:groupvideos' => "V&iacute;deo de comunidades",
		'izap_videos:izapUploadOption' => "Tipo de v&iacute;deo:",
		'izap_videos:upload' => "Actualizar el v&iacute;deo (Permite 3gp, avi, mp4, flv)",
		'izap_videos:unsupported' => "Formato de fichero no soportado.",
		'izap_videos:converterror' => "Error al convertir el v&iacute;deo.",
		'izap_videos:izapBorderColor1' => "Introduzca el border color1 para el reproductor: (el c&oacute;digo de color sin '#')",
		'izap_videos:izapBorderColor2' => "Introduzca el borde color2 para el reproductor: (el c&oacute;digo del color sin '#')",
		'izap_videos:izapBarColor' => "Enter bar color for the player: (color code without '#')",
		'izap_videos:river:titled' => '%s a&ntilde;adidos nuevo v&iacute;deo con t&iacute;tulo %s',
        'izap_videos:latestvideos' => "&Uacute;ltimos",
        'izap_videos:topViewed' => "M&aacute;s vistos",
        'izap_videos:topCommented' => "M&aacute;s comentados",
        'izap_videos:embedCode' => "incrustar",
        'izap_videos:videoGal' => "Galer&iacute;a de videos",
	'izap_videos:noTagVideo' => "No hay v&iacute;deos para esta etiqueta.",
		
	);
	add_translation("es",$spanish);
?>
