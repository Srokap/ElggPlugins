<?php

$spanish = array (

	/**
	 * Nice name for the entity (shown in admin panel)
	 */
	'item:object:moddefaultwidgets' => 'Configuración de Widget por defecto',

	/**
	 * Menu items
	 */
	'defaultwidgets:menu:profile' => 'Perfil por defecto',
    'defaultwidgets:menu:dashboard' => 'Escritorio por defecto',

    'defaultwidgets:admin:error' => 'Error: No esta logado como un administrador',
	'defaultwidgets:admin:notfound' => 'Error: P&aacute;gina no encontrada',
	'defaultwidgets:admin:loginfailure' => 'Precauci&oacute;n: No se ha logado como administrador',

	'defaultwidgets:update:success' => 'La configuraci&oacute;n de su componente se ha guardado',
	'defaultwidgets:update:failed' => 'Error: Configuraci&oacute;n no guardada',
	'defaultwidgets:update:noparams' => 'Error: Par&aacute;metros incorrectos',

	'defaultwidgets:profile:title' => 'Define los componentes por defecto para usuarios nuevos',
	'defaultwidgets:dashboard:title' => 'Define los componentes por defecto para el escritorio',
);

add_translation ( "es", $spanish );
