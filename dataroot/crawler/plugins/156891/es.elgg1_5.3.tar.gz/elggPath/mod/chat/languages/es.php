<?php

	$spanish = array(
        /**
         * Misc
         */
            'chat:open' => 'Abrir chat'
	
	);
					
	add_translation("es", $spanish);

?>
