<?php

	$spanish = array(	
	
		'item:user:facebook' => "Usuarios Facebook",			
		'fbconnect:settings:api_key:title' => "API Key",
		'fbconnect:settings:api_secret:title' => "API Secret",
		'fbconnect:account_create' => "Error: No se puede crear su cuenta. "
			."Por favor contacte con el administrador o int&eacute;ntelo de nuevo m&aacute;s tarde.",
		'fbconnect:inactive' => "Error: no puedo activar la cuenta elgg.",
		'fbconnect:banned' => "Error: no puedo logarme. "
           		 ."Por favor contacte con el administrador o int&eacute;ntelo de nuevo m&aacute;s tarde.",
		'fbconnect:fail' => "Error: no puedo logarme. "
         		 ."Por favor contacte con el administrador o int&eacute;ntelo de nuevo m&aacute;s tarde.",
		'fbconnect:facebookerror' => "Error: Facebook ha devuelto el siguiente mensage: %s",
		'fbconnect:account_duplicate' => "Error: no es una cuenta FaceBook con "
			."el mismo usuario (%s) que todav&iacute;a existe en la red.",
		'fbconnect:settings:yes' => "si",
		'fbconnect:settings:no' => "no",
		'fbconnect:user_settings_title' => "Perfil Facebook",
		'fbconnect:user_settings_description' => "Permitir el control de Facebook de mi perfil cuando inicie sesi&oacute;n desde redes.epesca.org. "
			."Si contesta  \"no\", será posible editar el perfil elgg y no se sincronizaría con el de facebook.",
		'fbconnect:user_settings:save:ok' => "Su perfil de facebook ha sido guardado.",
		'fbconnect:facebook_login_settings:save:ok' => "Su facebook ha sido guardado.",
		'fbconnect:facebook_login_title' => "Inicio de sesi&oacute;n en facebook",
		'fbconnect:facebook_login_description' => "Si quiere entrar en sesión desde redes.epesca.org a facebook, introduca el Facebook uid (Es un n&uacute;mero que apaarece en la url de su perfil en la página de facebook).",
		'fbconnect:cron_report' => "Sincronizadas %s cuentas de facebook."	
	);
					
	add_translation("es",$spanish);

?>
