<?php

	/**
	 * Elgg invite page
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @link http://elgg.org/
	 */

	$spanish = array(

		'friends:invite' => 'Invitar amigas',
		'invitefriends:introduction' => 'Para invitar a unirse a esta red, debe introducir el correo electr&oacute;nico m&aacute;s abajo(una por l&iacute;nea):',
		'invitefriends:message' => 'Introduzca un mensaje que recibir&aaucte; de su invitaci&oacute;n:',
		'invitefriends:subject' => 'Invitacion a unirse a %s',
	
		'invitefriends:success' => 'Su amiga le ha invitado.',
		'invitefriends:failure' => 'Su amigas no pueden ser invitadas.',
	
		'invitefriends:message:default' => '
Hola,

Quiero invitarla a unirse a la red social en %s.',
		'invitefriends:email' => '
Ha sido invitada a unirse a %s por %s. Incluyendo el siguiente mensaje:

%s

Para unirse, debe pulsar el siguiente link:

	%s

Será adminitido automáticamente como un acmigo cuando haya creado una cuenta.',
	
	);
					
	add_translation("es",$spanish);
?>
