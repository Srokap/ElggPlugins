<?php

	$spanish = array(

		'worldview' => 'En la web',
		'worldview:settings' => 'Introduzca los t&eacute;rminos que le gustar&iacute;a mostrar, separado por comas.',
		'worldview:searchterms' => ' Actualmente: %s',
		'worldview:see' => 'Visitar su p&aacute;gina personalizada.',
		'worldview:refresh' => 'Actualizar',
		'worldview:overview' => 'Esta herramienta le permite personalizar los contenicos de <a href="http://twitter.com">Twitter</a>, <a href="http://news.google.com/nwshp?hl=en&tab=wn">Google news</a> y <a href="http://blogsearch.google.com/blogsearch?client=news&pz=1&hl=en">Google blog search</a>. S&oacute;lo introduzca los t&eacute;rminos/tags que desee buscar y que le gustar&iacute;a mostrar para estar listo.<br />',
		'worldview:noterms' => 'P&uacute;lseme aqu&iacute; para empezar a ver lo que hay por la web.',
			
	);
					
	add_translation("es",$spanish);

?>
