<?php
	/**
	 * Quote of the Day - Plugin
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Michael T Jones
	 * @copyright Michael T Jones 2008
	 * @link http://www.facebake.com/
	 *
	 * English translation
	 */

$spanish = array(
	
		//submenu items
		'quoteoftheday:menu:home' => 'Inicio',
		'quoteoftheday:menu:the_quote:day' => 'Citas de hoy',
		'quoteoftheday:menu:the_quote:week' => 'Citas de la semana',
		'quoteoftheday:menu:the_quote:month' => 'Citas del mes',
		'quoteoftheday:menu:new_quotes' => 'Subidas recientemente',
		'quoteoftheday:menu:top_quotes' => 'Citas m&aacute;s puntuadas',
		'quoteoftheday:menu:own_quotes' => 'Mis Citas',
		'quoteoftheday:menu:src_quotes' => 'Buscar citas',
		'quoteoftheday:menu:archive' => 'Archivo',
		'quoteoftheday:menu:admin' => 'Administrador',
			
		//page titles
		'quoteoftheday:title:home:day' => 'Citas del d&iacute;a',
		'quoteoftheday:title:home:week' => 'Citas de la semana',
		'quoteoftheday:title:home:month' => 'Citas del mes',
		'quoteoftheday:title:the_quote:day' => 'Citas del d&iacute;a',
		'quoteoftheday:title:the_quote:week' => 'Citas de la semana',
		'quoteoftheday:title:the_quote:month' => 'Citas del mes',
		'quoteoftheday:title:sub_quote' => 'Valorarla',
		'quoteoftheday:title:top_quotes' => 'Citas m&aacute;s valoradas',
		'quoteoftheday:title:own_quotes' => 'Mis citas',
		'quoteoftheday:title:new_quotes' => 'Citas recientes',
		'quoteoftheday:title:src_quotes' => 'Buscar citas',
		'quoteoftheday:title:archive' => 'Guardar citas',
		'quoteoftheday:title:admin' => 'Administrador de opciones',
		
		//messages
		'quoteoftheday:submitted' => 'Cita insertada correctamente. Gracias.',
		'quoteoftheday:deleted' => 'Cita eliminada.',
		'quoteoftheday:rated' => 'Su valoraci&oacute;n ha sido realizada.  Gracias.',
		'quoteoftheday:error' => 'Hay un error al guardar su cita.  Por favor int&eacute;ntelo de nuevo.',
		'quoteoftheday:rateerror' => 'Hay un error en la valoraci&oacute;n de la cita. Por favor int&eacute;ntelo de nuevo.',
		'quoteoftheday:ownerror' => 'No puede valorar sus propias citas.',
		'quoteoftheday:twicerateerror' => 'Bonito intento.....ya valoró esta cita :-',
		'quoteoftheday:quoteblank' => 'Introduzca una cita antes de darle a enviar.',
		'quoteoftheday:disagree' => 'Lo lamentamos, pero debe estar de acuerdo con los t&eacute;rminos y licencias.',
		'quoteoftheday:deleteerror' => 'Ha ocurrido un error inesperado al borrar la cita. Por favor int&eacute;ntelo m&aacute;s tarde.',
		'quoteoftheday:emptyset' => 'No hay citas',
		'quoteoftheday:updateerr' => 'Error al actualizar la cita.',
		
		//listing controls
		'quoteoftheday:strapline' => '%s citas por %s',
		'quoteoftheday:rating:popup' => 'Valorar esta cita',
		'quoteoftheday:rating' => 'Valoraci&oacute;n',
		'quoteoftheday:deleteconfirm' => 'Est&aacute; segura de borrar esta cita?',
		'quoteoftheday:delete' => 'Eliminar cita',
		
		//object names
		'item:object:quoteoftheday' => 'Citas del d&iacute;a',
		
		//river stuff
		'quoteoftheday:river:created' => "%s citas",
		'quoteoftheday:river:create' => 'una nueva cita',
		
		//settings form
		'quoteoftheday:settings:perpage' => 'Citas a mostrar por p&acute;ginas: ',
		'quoteoftheday:settings:update_freq' => 'Frecuencia de actualizaci&oacute;n de citas ',
		
		//Widget Text
		'quoteoftheday:widget:title:day' => 'Citas del d&iacute;a',
		'quoteoftheday:widget:title:week' => 'Citas de la semana',
		'quoteoftheday:widget:title:month' => 'Citas del mes',
		'quoteoftheday:widget:description' => 'Mostrar las citas mas recientes',
		
		//misc
		'quoteoftheday:search' => 'Buscar citas: ',
		'quoteoftheday:submit' => 'Buscar',
		'quoteoftheday:submityourown' => "A&ntilde;adir su propia cita",
		'quoteoftheday:yourquote' => "Su cita",
		'quoteoftheday:maxinput' => "(max. 250 caracteres)",
		'quoteoftheday:agreement' => 'Estoy de acuerdo con que esta cita no es ofensiva y no <br /> viola los t&eacute;rminos del uso y servicio.',
		'quoteoftheday:description' => 'Bienvenido a la secci&oacute;n de citas. Aqu&iacute; puede incorporar sus propias citas y ver/valorar la de otros amig@s. Las citas m&aacute;s valoradas ser&aacute;n seleccionadas y mostradas por nuestra red social.'
		);
		
add_translation("es",$spanish);
?>
