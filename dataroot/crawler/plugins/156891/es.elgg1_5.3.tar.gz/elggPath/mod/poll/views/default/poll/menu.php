<?php

	/**
	 * Elgg Poll plugin
	 * @package Elggpoll
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @Original author John Mellberg
	 * website http://www.syslogicinc.com
	 * @Modified By Team Webgalli to work with ElggV1.5
	 * www.webgalli.com or www.m4medicine.com
	 */
	 
	 
?>

	<p class="user_menu_poll">
		<a href="<?php echo $vars['url']; ?>pg/poll/<?php echo $vars['entity']->username; ?>"><?php echo elgg_echo("poll"); ?></a>	
	</p>