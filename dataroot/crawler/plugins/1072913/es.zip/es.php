<?php
	$spanish = array(
 			
 		//  Highslide show by Dr. Sanu P Moideen @ Team Webgalli
 			
 			// High slide settings and others
			'tidypics:clicktoenlarge' => "Click para agrandar",
			'tidypics:leavecomment' => "Comentar, etiquetar y más...",
			'highslide:settings:slideshowstyle' => "Selecciona el estilo de borde para las diapositivas:",
			'highslide:slide:slidetime' => "Tiempo entre cada imagen de la diapositiva",
			'highslide:settings:slideshow' => "Diapositiva",
			'highslide:slide:credit' => "El texto de crédito a mostrra como marca de agua en las imágenes:",
 			'highslide:slide:creditsTitle' => "El t&iacute;tulo de los cr&eacute;ditos al poner el cursor sobre la imagen:",
			'highslide:slide:creditsLink' => "Enlace a la página de créditos:",
 		//Highslide translations
 			'highslide:cssDirection' => "ltr",
			'highslide:loadingText' => "Cargando...",
			'highslide:loadingTitle' => "Click para cancelar",
			'highslide:focusTitle' => "Click para traer al frente",
			'highslide:fullExpandTitle' => "Expandir al tamaño real (f)",
 			'highslide:creditsText' => "Powered by <i>Highslide JS</i>",
			'highslide:creditsTitle' => "Ir al sitio Web de Highslide JS",
			'highslide:previousText' => "Previo",
			'highslide:nextText' => "Siguiente",
			'highslide:moveText' => "Mover",
			'highslide:closeText' => "Cerrar",
			'highslide:closeTitle' => "Cerrar (esc)",
			'highslide:resizeTitle' => "Redimensionar",
			'highslide:playText' => "Reporducir",
			'highslide:playTitle' => "Reproducir diapositivas (barra espaciadora)",
			'highslide:pauseText' => "Pausa",
			'highslide:pauseTitle' => "pausar diapositiva (barra espaciadora)",
			'highslide:previousTitle' => "Previo (flecha izquierda)",
			'highslide:nextTitle' => "Siguiente (flecha derecha)",
			'highslide:moveTitle' => "Mover",
 			'highslide:fullExpandText' => "1:1",
			'highslide:number' => "Imagen %1 of %2",
			'highslide:restoreTitle' => "Click para cerrar, click y arrastrar para mover. Usa las teclas de dirección izquierda y derecha para navegar entre las imágenes.",
 			'highslide:creditsLink' => "http://highslide.com/",
 		// Highslide 			
 	);
 
add_translation("es",$spanish);