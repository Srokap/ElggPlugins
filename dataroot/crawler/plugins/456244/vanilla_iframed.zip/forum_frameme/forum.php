<?php

	include_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
		// Ensure only logged-in users can see this page
		gatekeeper();

	$title = elgg_echo('forum_frameme:forum');
	$area2 = elgg_view_title($title);
	$area2 .= elgg_view('forum/forum');
	

	$body = elgg_view_layout("one_column", $area2);

	page_draw($title, $body);
?>