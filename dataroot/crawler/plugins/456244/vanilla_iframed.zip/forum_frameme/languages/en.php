<?php

	$english = array(
	
		'help' => "Discussiom Forum",
		
		'forum_frameme:forum' => "Forum",
	);

	add_translation("en",$english);

?>
