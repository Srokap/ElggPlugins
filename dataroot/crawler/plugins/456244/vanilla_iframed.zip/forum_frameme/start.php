<?php


	function forum_frameme_init() 
	{
		extend_view('css', 'forum/css');
		
		register_page_handler('forum_frameme','forum_frameme_page_handler');
	}


	function forum_frameme_page_handler($page) 
	{
		
		if ($page[0])
		{
			switch ($page[0])
			{
				case "forum":
					include(dirname(__FILE__) . "/forum.php");
					break;
				default: 
					break;
			}
		}
	}

	register_elgg_event_handler('init','system','forum_frameme_plugin_init');
?>