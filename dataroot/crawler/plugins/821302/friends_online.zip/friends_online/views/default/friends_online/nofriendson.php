<?php
	/**
	* Friends Online
	* 
	* @package friends_online
	* @author Dieter Konrad aka alfalive
	* @copyright Dieter Konrad 2009
	* @link http://community.elgg.org/pg/profile/alfalive
	*/
	
$showActivityWidget = get_plugin_setting("showActivityWidget","friends_online");
if(empty($showActivityWidget) || $showActivityWidget == "no"){

} else {

// HTML elements open
echo "<div class=\"sidebarBox\">\n"; 
echo "<h3>\n";
echo elgg_echo('friends_online:friends');
echo "</h3>\n"; 
echo "<div class=\"membersWrapper\"><br />\n";

$friends = $_SESSION['user']->getFriends("",1000);

$friends_online = 0;
	if (count($friends) > 0) 
	{
		foreach ($friends as $friend) 
		{
			if ($friend->last_action > time() - 200) 
			{		
				$icon = elgg_view("profile/icon", array('entity' => get_user($friend->guid), 'size' => 'tiny'));
				echo "<div class=\"friends_online\">\n";     
				echo $icon;
				echo "</div>\n";
				$friends_online++;
			} 
		} 
	}
	if ($friends_online == 0) 
	{
    //No friends online
    echo elgg_echo('friends_online:nobodyonline');
	}

// HTML elements close

echo "<div class=\"clearfloat\"></div>\n"; 
echo "</div>\n"; 
echo "</div>\n";
}
?>