<?php
	/**
	* Avatar Wall - Admin settings
	* 
	* @package avatar_wall
	* @author ColdTrick IT Solutions
	* @copyright Coldtrick IT Solutions 2009
	* @link http://www.coldtrick.com/
	*/
?>
<p>
	<p>
		<b>friends online options</b><br />
		<select name="params[showToolsLink]">
			<option value="yes" <?php if ($vars['entity']->showToolsLink == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
			<option value="no" <?php if ($vars['entity']->showToolsLink == 'no' || empty($vars['entity']->showToolsLink)) echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
		</select>
		<?php echo elgg_echo("Show who's online link in Tools menu?");?><br /><br />
	
		<select name="params[showActivityWidget]">
			<option value="yes" <?php if ($vars['entity']->showActivityWidget == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
			<option value="no" <?php if ($vars['entity']->showActivityWidget == 'no' || empty($vars['entity']->showActivityWidget)) echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
		</select>
		<?php echo elgg_echo("Show activity page of the online friends?");?><br /><br />
		
		<select name="params[notOnline]">
			<option value="yes" <?php if ($vars['entity']->notOnline == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
			<option value="no" <?php if ($vars['entity']->notOnline == 'no' || empty($vars['entity']->notOnline)) echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
		</select>
		<?php echo elgg_echo("Hide widget when no friends online?");?><br /><br />
		
		<select name="params[showProfileWidget]">
			<option value="yes" <?php if ($vars['entity']->showProfileWidget == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
			<option value="no" <?php if ($vars['entity']->showProfileWidget == 'no' || empty($vars['entity']->showProfileWidget)) echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
		</select>
		<?php echo elgg_echo("View profile page of online Friends?");?><br /><br />
		
		<b>Recent Members options</b><br />
		<select name="params[showRecentWidget]">
			<option value="yes" <?php if ($vars['entity']->showRecentWidget == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
			<option value="no" <?php if ($vars['entity']->showRecentWidget == 'no' || empty($vars['entity']->showRecentWidget)) echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
		</select>
		<?php echo elgg_echo("Show Recent Members  at the activity page?");?><br /><br />
		
		
		<select name="params[wallIconSize]">
			<option value="tiny" <?php if ($vars['entity']->wallIconSize == 'tiny') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('avatar_wall:settings:tiny'); ?></option>
			<option value="small" <?php if ($vars['entity']->wallIconSize == 'small' || empty($vars['entity']->wallIconSize)) echo " selected=\"yes\" "; ?>><?php echo elgg_echo('avatar_wall:settings:small'); ?></option>
			<option value="medium" <?php if ($vars['entity']->wallIconSize == 'medium' || empty($vars['entity']->wallIconSize)) echo " selected=\"yes\" "; ?>><?php echo elgg_echo('Medium'); ?></option>
		</select>
		<?php echo elgg_echo("Show icon size for recent members");?><br /><br />
		
		<input type="text" name="params[maxIcons]" value="<?php if(!empty($vars['entity']->maxIcons)){ echo $vars['entity']->maxIcons; } else { echo "12"; }?>"/><?php echo elgg_echo("How many  images to be displayed? recent members"); ?>

						
	</p>
</p>
