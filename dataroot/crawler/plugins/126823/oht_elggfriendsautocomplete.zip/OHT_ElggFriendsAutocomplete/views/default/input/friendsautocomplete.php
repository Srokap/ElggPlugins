<?php
/*******************************************************************************
 * Friends Autocomplete view
 * 
 * This view creates another input box to be used by the autocomplete javascript
 * if the 'OHT_ElggFriendsAutocomplete' class has been used in the input/pulldown
 * declaration
 * 
 * @package OHT
 * @subpackage ElggFriendsAutocomplete
 * @author Aaron Saray (102degrees.com) 
 ******************************************************************************/

if (stripos($vars['class'], 'OHT_ElggFriendsAutocomplete') !== FALSE) {
    $autoname = $vars['internalname'] . 'autocomplete'; //this might be used later
    echo "<input name=\"{$autoname}\" type=\"text\" class=\"OHT_ElggFriendsAutocomplete_input\" />";
}
