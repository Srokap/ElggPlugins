<?php 
/*******************************************************************************
 * Javascript for the friends Autocomplete 
 * 
 * This specific javascript is used to grab each instance of the autocomplete
 * inputs and generate the autocomplete js functionality.  Additionally, it 
 * assigns the value to the pulldown that was originally extended.
 * 
 * @package OHT
 * @subpackage ElggFriendsAutocomplete
 * @author Aaron Saray (102degrees.com) 
 ******************************************************************************/
?>
$(function() {
    $(".OHT_ElggFriendsAutocomplete_input").each(function(){
        var replaceable = $(this).prev('select');
        
        var data = new Array();
        var values = {};
        
        $(replaceable).children('option').each(function(c) {
            data[c] = $(this).text();
            values[data[c]] = $(this).val();
        });
        
        $(this).autocomplete(data,
                                    {
                                        mustMatch: true
                                    }
        ).result(function(event, data, formatted) {
            $(replaceable).val(values[data]);
            $(this).blur();
        });
    });
});  