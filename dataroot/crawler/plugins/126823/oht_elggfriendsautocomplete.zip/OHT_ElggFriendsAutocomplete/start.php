<?php
/*******************************************************************************
 * Friends Autocomplete Box
 * 
 * This is the launching script for the friends autocomplete box.  
 * 
 * @package OHT
 * @subpackage ElggFriendsAutocomplete
 * @author Aaron Saray (102degrees.com)
 ******************************************************************************/

/**
 * The Initial Plugin launcher
 */
function OHT_ElggFriendsAutocomplete_init()
{
    /** add to pull down **/
    extend_view('input/pulldown', 'input/friendsautocomplete');
    
    /** add the js **/
    extend_view('js/initialise_elgg', 'js/jquery.autocomplete.pack.js');
    extend_view('js/initialise_elgg', 'js/OHT_ElggFriendsAutocomplete');
    
    /** add the css **/
    extend_view('css', 'css/jquery.autocomplete.css');
}

/** register event handlers **/
register_elgg_event_handler('init', 'system', 'OHT_ElggFriendsAutocomplete_init', 1);