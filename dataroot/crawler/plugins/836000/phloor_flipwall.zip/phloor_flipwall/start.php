<?php 
/*****************************************************************************
 * Phloor Flipwall                                                           *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php
/**
 * Phloor Flipwall
 */

elgg_register_event_handler('init', 'system', 'phloor_flipwall_init', 1);

function phloor_flipwall_init() {	
	/**
	 * External JS
	 */
	$js_url = 'mod/phloor_flipwall/vendors/flip-wall/';
	elgg_register_js('flipwall-jquery-flip-min-js', $js_url.'jquery.flip.min.js', 'footer', 800);
	elgg_register_js('flipwall-script-js', $js_url.'script.js', 'footer', 810);
	
	/**
	 * External CSS
	 */
	$css_url = 'mod/phloor_flipwall/vendors/flip-wall/';
	elgg_register_css('flipwall-css', $css_url . 'styles.css');
		
	$css_url = 'mod/phloor_flipwall/views/default/phloor_flipwall/';
	elgg_register_css('phloor-flipwall-example-css', $css_url . 'example.css');	
	
	/**
	 * Example page handler
	 * REMOVE THIS WHEN YOU ARE USING THE PLUGIN LIVE
	 */
	elgg_register_page_handler('flipwall-example', 'phloor_flipwall_example_page_handler');
}

/**
 * the example flipwall page handler
 * REMOVE THIS WHEN YOU ARE USING THE PLUGIN LIVE
 * 
 * @param unknown_type $page
 */
function phloor_flipwall_example_page_handler($page) {
	// includes the example file
	$dir = elgg_get_plugins_path() . 'phloor_flipwall/pages/phloor_flipwall';
	include "$dir/example.php";
	
	return true;
}