<?php 
/*****************************************************************************
 * Phloor Flipwall                                                           *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php
/**
 * A Flipwall
 *
 * @uses $vars['values']      an array of arrays with 2 values (front, back)
 * @uses $vars['shuffle']     whether the array should be shuffled
 */
$values  = elgg_extract('values',  $vars, '');
$shuffle = elgg_extract('shuffle', $vars, false);

unset($vars['values']);

if(!is_array($values) || empty($values)) {
	return true;
}

// shuffle values if requested
if($shuffle == true) {
	shuffle($values);
}

$content = '';
foreach($values as $entry) {
	$content .= elgg_view('output/flipwall-entry', array(
		'front' => $entry['front'],
		'back'  => $entry['back'],
	));
}

// output the view
if(!empty($content)) {
	$content =  <<<HTML
<div class="flipwall-entry-list-holder">
	$content	
	<div class="clear"></div>
</div>
HTML;

}

echo $content;
 
