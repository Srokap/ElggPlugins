<?php 
/*****************************************************************************
 * Phloor Flipwall                                                           *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php 

/**
 * EXAMPLE FILE back.php
 * 
 * displaying a user related information
 */

$content = '';
// get user entity
$user = $vars['entity'];

// check for user entity
if(elgg_instanceof($user, 'user')) {
	$username = $user->username; // get username
	$website = $user->getURL(); // get url to profile
	
	// append to content
	$content = <<<HTML
	<div class="phloor-flipwall-example-name">$username</div>
	<div class="phloor-flipwall-example-website">
		<a href="$website" title="$username">$website</a>
	</div>
HTML;
}

// display content
echo  $content;