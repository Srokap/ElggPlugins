/**
 * Phloor Flipwall
 * 
 * @package phloor_flipwall
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author void <void@13net.at>
 * @copyright 13net
 * @link http://www.13net.at/
 */


/**
 * Description
 */
This plugin provides a view called 'output/flipwall'.
Take a look at 'pages/phloor_flipwall/example.php' to
see how its used.

You can specify the 'front' and the 'back'..
so you can use it for anything you want to display.
I have already coded and adapted the 'Phloor Sponsor Flipwall'
plugin which requires this plugin and shows how it could work.
Also in the example.php you can see how you display users.

Example: yoursite.com/flipwall-example

It's recommended that you disable/delete the handler of the
example page when you are enabling it on a live system.


This plugin has been made by with the help of the tutorial found here:
http://tutorialzine.com/2010/03/sponsor-wall-flip-jquery-css/

/**
 * Languages
 */
English
German



