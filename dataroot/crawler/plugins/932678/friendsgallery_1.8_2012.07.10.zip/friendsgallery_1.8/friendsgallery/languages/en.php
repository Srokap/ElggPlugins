<?php
/**
 * Friends Gallery language file
 */

$english = array(

	'friends:gallery' => 'Friends gallery',
	
);
add_translation('en', $english);
