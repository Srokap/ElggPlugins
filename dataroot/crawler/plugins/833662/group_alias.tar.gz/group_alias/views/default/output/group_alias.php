<?php

echo "<code>{$vars['value']}</code>";
