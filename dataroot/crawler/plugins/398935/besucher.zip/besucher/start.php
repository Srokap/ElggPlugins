<?php

	/**
	 * Elgg Besucher Modul
	 * Zeigt die Besucher einer Profilseite
	 * 
	 * @package naweko
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author naweko / Frank Franz <kontakt@naweko.de>
	 * @copyright naweko / Frank Franz 2010
	 * @link 
	 */
	
	function besucher_init() {
		
		//System-Konfiguration
		global $CONFIG;
		
		//Besucherregistrierung irgendwo in Profilseite aufrufen
		extend_view('profile/userdetails','besucher/besucher',999);

		//Modul einbinden
		add_widget_type('besucher',elgg_echo("besucher"),elgg_echo('besucher:modul:beschreibung'));
		
	}
	
	register_elgg_event_handler('init','system','besucher_init');
		
?>