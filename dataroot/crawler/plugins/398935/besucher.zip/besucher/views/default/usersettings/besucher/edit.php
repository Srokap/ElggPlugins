<p>
<?php echo elgg_echo('besucher:einstellungen:beschreibung'); ?>
<select name="params[besucher_aktiviert]">
	<option value="true" <?php if (!$vars['entity']->besucher_aktiviert || $vars['entity']->besucher_aktiviert == "true") echo "selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
	<option value="false" <?php if ($vars['entity']->besucher_aktiviert == "false") echo "selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
</select>
</p>