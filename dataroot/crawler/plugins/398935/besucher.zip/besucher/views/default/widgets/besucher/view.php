<?php

	/**
	 * Elgg Besucher Modul
	 * Zeigt die Besucher einer Profilseite
	 * 
	 * @package naweko
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author naweko / Frank Franz <kontakt@naweko.de>
	 * @copyright naweko / Frank Franz 2010
	 * @link 
	 */

	//Datenbank-Tabelle anlegen, falls noch nicht vorhanden
	$besucherdb = $CONFIG->dbname;
	$besuchertabelle = $CONFIG->dbprefix."besuchermodul";
	
	//Wenn die Tabelle noch nicht vorhanden ist -> in die DB schreiben
	$query = "CREATE TABLE IF NOT EXISTS $besucherdb.$besuchertabelle (
	`id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`besuchterid` INT(11) NOT NULL,
	`besucherid` INT(11) NOT NULL,
	`zeitstempel` INT(11) NOT NULL
	);";
	mysql_query($query) or die (mysql_error());

    //the number of files to display
	$num = (int) $vars['entity']->num_display;
	if (!$num)
		$num = 8;
		
	//get the correct size
	$size = (int) $vars['entity']->icon_size;
	if (!$size || $size == 1){
		$size_value = "small";
	}else{
    	$size_value = "tiny";
	}
	
	$page_owner = page_owner_entity();
	$besuchterid = $page_owner->getGUID();	
	
	//Besucher nach Datum ausgeben
	$besuchers = get_data("SELECT id,besuchterid,besucherid,zeitstempel FROM ".$besuchertabelle." WHERE besuchterid='".$besuchterid."' ORDER BY zeitstempel DESC LIMIT 0,".$num."");
	
	echo "<div id=\"widget_friends_list\">";
	
	if (!$besuchers) {
		echo elgg_echo("besucher:keinebesucher");
	}
	else {
			
		foreach($besuchers as $besucher) {
			echo "<div class=\"widget_friends_singlefriend\" >";
			echo elgg_view("profile/icon",array('entity' => get_user($besucher->besucherid), 'size' => $size_value));
			echo "</div>";
		}
	}
	
	echo "</div>";
	
?>