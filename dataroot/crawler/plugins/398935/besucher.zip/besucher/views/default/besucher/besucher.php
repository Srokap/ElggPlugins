<?php

	/**
	 * Elgg Besucher Modul
	 * Zeigt die Besucher einer Profilseite
	 * 
	 * @package naweko
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author naweko / Frank Franz <kontakt@naweko.de>
	 * @copyright naweko / Frank Franz 2010
	 * @link 
	 */
	 
	//Datenbank-Tabelle anlegen, falls noch nicht vorhanden
	$besucherdb = $CONFIG->dbname;
	$besuchertabelle = $CONFIG->dbprefix."besuchermodul";
	
	//Wenn die Tabelle noch nicht vorhanden ist -> in die DB schreiben
	$query = "CREATE TABLE IF NOT EXISTS $besucherdb.$besuchertabelle (
	`id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`besuchterid` INT(11) NOT NULL,
	`besucherid` INT(11) NOT NULL,
	`zeitstempel` INT(11) NOT NULL
	);";
	mysql_query($query) or die (mysql_error());
		
	//Besuch der Profilseite registrieren
	$page_owner = page_owner_entity();
	//ID des besuchten Profils
	$besuchterid = $page_owner->getGUID();
    //ID des Besuchers
	$besucherid = $_SESSION['user']->guid;
	//Zeit des Besuchs
	$zeitstempel = time();
	
	//Einstellung auslesen
	$anonym = (get_plugin_usersetting("besucher_aktiviert", $_SESSION['user']->guid, "besucher") == 'true' || !get_plugin_usersetting("besucher_aktiviert", $_SESSION['user']->guid, "besucher")) ? 'true' : 'false'; 

	//Nur ausführen, wenn der Nutzer nicht sein eigenes Profil besucht und wenn er nicht anonym bleiben möchte
	if (($besuchterid != $besucherid) && $anonym == 'true') {
		
		//Prüfen, ob der Besucher dieses Profil schon einmal besucht hat
		$pruefen = get_data_row("SELECT id,besuchterid,besucherid,zeitstempel FROM ".$besuchertabelle." WHERE besuchterid='".$besuchterid."' AND besucherid='".$besucherid."'");
		if ($pruefen) {
			//Besucher war schon einmal auf diesem Profil -> Zeitstempel aktualisieren
			update_data("UPDATE ".$besuchertabelle." SET zeitstempel='".$zeitstempel."' WHERE id='".$pruefen->id."'");
		}
		else {
			//Besucher ist zum ersten Mal auf diesem Profil -> Eintragen
			insert_data("INSERT INTO ".$besuchertabelle." SET besuchterid='".$besuchterid."', besucherid='".$besucherid."', zeitstempel='".$zeitstempel."'");
		}
	
	}

?>