<?php

	$german = array(
	
		/**
		 * Besucher Modul
		 */
			'besucher' => "Besucher",
			
			'besucher:modul:beschreibung' => "Dieses Modul zeigt Dir, wer zuletzt Deine Profil-Seite besucht hat.",
			'besucher:einstellungen:beschreibung' => "Hier kannst Du einstellen, ob Deine Besuche auf anderen Profilseiten angezeigt werden soll, oder ob Du andere Profilseiten anonym besuchen m&ouml;chtest.<br><br>Meine Besuche auf anderen Profilseiten anzeigen: ",
			
	        'besucher:num_display' => "Anzahl anzuzeigender Besucher",
			'besucher:icon_size' => "Gr&ouml;&szlig;e der Vorschaubilder",
			'besucher:small' => "klein",
			'besucher:tiny' => "winzig",
			'besucher:keinebesucher' => "Bisher hat niemand Deine Profilseite besucht",
	);
					
	add_translation("de",$german);

?>