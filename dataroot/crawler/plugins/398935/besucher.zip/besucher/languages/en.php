<?php

	$english = array(
	
		/**
		 * Besucher Modul
		 */
			'besucher' => "Visitors",
			
			'besucher:modul:beschreibung' => "This widget shows you who has recently visited your profile page.",
			'besucher:einstellungen:beschreibung' => "Here you can specify whether your visit is to be displayed on other profile sites, or if you want to visit other anonymous profile pages show.<br><br>Display my visits to other profile pages: ",
			
	        'besucher:num_display' => "Number of visitors to Display",
			'besucher:icon_size' => "Icon size",
			'besucher:small' => "small",
			'besucher:tiny' => "tiny",
			'besucher:keinebesucher' => "So far no one has visited your profile page",
	        
		
	);
					
	add_translation("en",$english);

?>