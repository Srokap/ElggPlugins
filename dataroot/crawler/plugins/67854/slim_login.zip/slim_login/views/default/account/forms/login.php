<?php

	global $CONFIG;
	
	$form_body = "<div><label>" . elgg_view('input/text', array('value' => 'username', 'internalname' => 'username', 'class' => 'login-textarea')) . "</label><br>";
	$form_body .= "<label>" . elgg_view('input/password', array('value' => 'password', 'internalname' => 'password', 'class' => 'login-textarea')) . "</label>";

	$form_body .= elgg_view('siteaccess/login');
	if (extension_loaded("gd") AND ($_SESSION['login_error_count'] >= 3))
	    $form_body .= elgg_view('siteaccess/code');

	$form_body .= elgg_view('input/submit', array('value' => elgg_echo('login'))) . "<br><label><input type=\"checkbox\" name=\"persistent\" value=\"true\" />".elgg_echo('user:persistent')." </label><div>";
	$form_body .= (!isset($CONFIG->disable_registration) || !($CONFIG->disable_registration)) ? "<a href=\"{$vars['url']}account/register.php\">" . elgg_echo( 'register') . "</a> | " : "";
	$form_body .= "<a href=\"{$vars['url']}account/forgotten_password.php\">" . elgg_echo('user:password:lost') . "</a></div></div>";  
	
	
	$login_url = $vars['url'];
	if ((isset($CONFIG->https_login)) && ($CONFIG->https_login))
		$login_url = str_replace("http", "https", $vars['url']);
?>
	
	<div id="login-box">
		<?php 
			echo elgg_view('input/form', array('body' => $form_body, 'action' => "{$login_url}action/login"));
		?>
		
	</div>
