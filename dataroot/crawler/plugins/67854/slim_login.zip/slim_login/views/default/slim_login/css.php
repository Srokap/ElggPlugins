<?php

	/**
	 * Elgg v1.5 Default Theme
	 * core CSS file
	 * 
	 * Updated 10 March 09
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.org/
	 * 
	 * @uses $vars['wwwroot'] The site URL
	 */

?>

#login-box {
	padding:0 0 10px 0;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	width: 442px;
    text-align:left;
	margin-bottom: 10px;
	margin-left: 0;
	margin-right: 0;
	border: 1px solid silver;
}
#login-box .login-textarea {
	width: 150px;
	height: 15px;
}
#login-box p.loginbox {
	margin:0;
	background-color: transparent;
}
#login-box form {
	padding: 10px 10px 4px;
	background: transparent;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	width: 98%;
	margin-bottom: 0;
	margin-left: 10px;
	margin-right: 10px;
}