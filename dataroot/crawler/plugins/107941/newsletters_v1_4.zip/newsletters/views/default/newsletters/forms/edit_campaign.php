<?php

/**
    edit_campaign.php, part of Newsletters
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
*/

	// get id of modified newsletter entity and redirect if not present
	$comapign_id = (int)get_input('id');
	if ( ! $comapign_id ){
        system_message(elgg_echo("campaigns:invalid_campaign"));
        forward("pg/newsletters/campaigns");
	}
	// loading newsletter entity for modification
	$campaign = get_entity($comapign_id);
	//get the full page owner entity
	$entity = get_entity(page_owner());

	// loading registerd groups
	$groups = get_entities('group', '', 0, '', 1000);
	$aGroups = array('0' => elgg_echo('newsletters:manage:all_members'));
	foreach ($groups as $group)
	{
        $aGroups[$group->guid] = $group->name;
	}
	// set delivery type hash
	$aDeliveryType =  get_campaign_delivery_options();
	// set activity type hash
	$aActivityType = array (
	    elgg_echo('campaigns:publication:state:active') 	=> 1,
	    elgg_echo('campaigns:publication:state:inactive') 	=> 0,
	);
	// load list of newsletters for select element
	$newsletters = newsletters_get_entities();
	$aNewsletters = array();
	foreach ( $newsletters as $newsletter ){
		$aNewsletters[$newsletter->guid] = str_replace(' ', '&nbsp;', $newsletter->title); // replace all spaces for nbsp;
	}
	// building edit form
	$form_body = '';
	$form_body .= elgg_echo('campaigns:manage:title');
	$form_body .= elgg_view('input/text', array('internalname' => 'title', 'value' => $campaign->title));

	$form_body .= elgg_echo('campaigns:manage:date:start');
	$form_body .= elgg_view('input/calendar', array('internalname' => 'date_start', 'value' => $campaign->date_start ));

	$form_body .= '<br />';
	$form_body .= elgg_echo('campaigns:manage:time:start');
	$form_body .= elgg_view('input/time', array('internalname' => 'time_start', 'value' => convert_time_for_human($campaign->time_start) ));

	$form_body .= '<br />';

	$form_body .= elgg_echo('campaigns:manage:date:end');
	$form_body .= elgg_view('input/calendar', array('internalname' => 'date_end', 'value' => $campaign->date_end ));

	$form_body .= '<br />';

	$form_body .= elgg_echo('campaigns:manage:time:end');
	$form_body .= elgg_view('input/time', array('internalname' => 'time_end', 'value' => convert_time_for_human($campaign->time_end) ));

	$form_body .= '<br />';
	
	$form_body .= elgg_echo('campaigns:manage:delivery_group');
	$form_body .= elgg_view('input/pulldown', array('internalname' => 'delivery_group', 'value' => $campaign->delivery_group , 'options_values' => $aGroups));
	$form_body .= '<br />';

	$form_body .= elgg_echo('campaigns:publication:delivery');
	$form_body .= '<br />';
	$form_body .= elgg_view('input/radio', array('internalname' => 'delivery_type', 'value' => $campaign->delivery_type, 'options' => $aDeliveryType));

	$form_body .= elgg_echo('campaigns:publication:activity');
	$form_body .= '<br />';
	$form_body .= elgg_view('input/radio', array('internalname' => 'activity', 'value' => intval($campaign->activity), 'options' => $aActivityType));
	
	$form_body .= elgg_echo('campaigns:publication:newsletters_list');
	$form_body .= elgg_view('input/select', array('internalname' => 'newsletters', 'value' => $campaign->newsletters_list, 'options' => $aNewsletters));
	
	$form_body .= elgg_view('input/submit', array('value' => elgg_echo('newsletters:manage:update')));
	$form_body .= elgg_view('input/hidden', array('internalname' => 'guid', 'value' => $campaign->guid));

	echo elgg_view('input/form', array('body' => $form_body, 'action' => $CONFIG->url . "action/newsletters/edit_campaign"));
	
?>
