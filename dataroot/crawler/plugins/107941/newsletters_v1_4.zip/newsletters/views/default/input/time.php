<?php

/**
    time.php, part of Newsletters
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	

	 * 
	 * @uses $vars['value'] The current value, if any
	 * @uses $vars['js'] Any Javascript to enter into the input tag
	 * @uses $vars['internalname'] The name of the input field
	 * @uses $vars['class'] Class override
	 */

	$class = $vars['class'];
	if (!$class) $class = "input-time";
	
	if ( $vars['value'] == 0 )
	    $vars['value'] = '00:00';
?>
<?php   
		if ( !isset($input_time_check) ){
			$input_time_check = true;
?>
<script type="text/javascript" src="<?php echo $vars['url'] . "mod/newsletters/js/input_time.js"?>"></script>

<?php	} ?>
<input type="text" <?php if ($vars['disabled']) echo ' disabled="yes" '; ?> name="<?php echo $vars['internalname']; ?>" value="<?php echo htmlentities($vars['value'], null, 'UTF-8'); ?>" class="<?php echo $class; ?>" OnKeyDown="return checkTimeFieldDown(event, this);" OnKeyUp="return checkTimeFieldUp(event, this);" onBlur="return checkTime(this);"/>