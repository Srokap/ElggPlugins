<?php

/**
    css.php, part of Newsletters
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
*/

?>

.input-textarea-short{
	height: 50px;
	width: 98%;
}

#newsletters_manage_main{
	padding: 10px;
	background-color: #F5F5F5;
	margin: 1px;
}

#newsletters_main, #newsletters_spotlight_main{
	border-bottom: 1px solid #838383;
	margin: 1px;
}
	
.newsletters_manage_date, .newsletters_date{
	font-style:italic;
}

.newsletters_manage_title, .newsletters_title{
	font-weight: bold;
}

.newsletters_spotlight_desc{
	padding: 10px;
	background-color: #F5F5F5;
	margin: 1px;
}
	
.newsletter{
	color: green;
}

.newsletters_widget_date, .newsletters_spotlight_date{
    font-style: italic;
	font-weight: bold;
}

.newsletters_widget_title, .newsletters_spotlight_title{
    font-weight: bold;
}

.newsletters_manage_introduction, .newsletters_manage_description{
	border: 1px solid grey;
}

.input-time{
	width: 40px;
}


.select_box{
	background-color: transparent;
	width: 400px;
	height: 200px;
}

.select_panel_left, .select_panel_right{
	background-color: #F5F5F5;
}

.select_panel_controls{
	float: left;
	width:  40px;
}

.select_control_button_add, .select_control_button_rem{
	cursor: pointer;
	margin-top: 2px;
	margin-bottom: 2px;
	width:40px;
	height: 40px;
}

.select_control_button_add{
	background: transparent url(<?php echo $vars['url'] . 'mod/newsletters/graphics/arr_right.gif'; ?>) no-repeat;
}

.select_control_button_rem{
	background: transparent url(<?php echo $vars['url'] . 'mod/newsletters/graphics/arr_left.gif'; ?>) no-repeat;
}

.select_panel_left {
	float:left;
	width:45%;
	height:100%;
	overflow: auto;
}

.select_panel_right {
	float: right;
	width:45%;
	height:100%;
	overflow: auto;
}

.select_lp_element, .select_rp_element{
	cursor:pointer;
	width:100%;
}
