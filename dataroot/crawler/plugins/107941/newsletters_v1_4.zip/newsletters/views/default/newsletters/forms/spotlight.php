<?php

/**
    spotlight.php, part of Newsletters
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
*/

	//get the full page owner entity
	$entity = get_entity(page_owner());

	// creating form body
	$form_body = '';
	$form_body .= '<a href="' . $CONFIG->url . 'action/newsletters/showSpotlight">'. elgg_echo('spotlight:show') .'</a>';
	$form_body .= '<br />';
	$form_body .= '<a href="' . $CONFIG->url . 'action/newsletters/hideSpotlight">'. elgg_echo('spotlight:hide') .'</a>';
	$form_body .= '<br />';

	$form_body .= '<a href="' . $CONFIG->url . 'action/newsletters/showSpotlightTop">'. elgg_echo('spotlight:show:top') .'</a>';
	$form_body .= '<br />';
	$form_body .= '<a href="' . $CONFIG->url . 'action/newsletters/hideSpotlighTop">'. elgg_echo('spotlight:hide:top') .'</a>';
	$form_body .= '<br />';

	echo $form_body;
?>
