<?php

/**
    campaign.php, part of Newsletters
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
*/

$entity = isset($vars['entity']) ? $vars['entity'] : null;
$context = isset($vars['context']) ? $vars['context'] : get_context();

	if ( $entity ) {
		if ( $context == 'admin'){
			// show item for admin
?>
<div id="newsletters_manage_main">
	<div class="newsletters_manage_commands">
	<?php if ( ! $entity->date_executed ) { ?>
	<a href="<?php echo $vars['url'];?>mod/newsletters/edit_campaign.php?id=<?php echo $entity->guid;?>" class="newsletters_link"><?php echo elgg_echo('newsletters:command:edit'); ?></a>
	<?php }  ?>
	<a href="<?php echo $vars['url'];?>mod/newsletters/delete_campaign.php?id=<?php echo $entity->guid;?>" class="newsletters_link" onclick="return confirm('<?php echo elgg_echo('newsletters:are_you_sure_delete')?>');"><?php echo elgg_echo('newsletters:command:delete'); ?></a>
	<a href="<?php echo $vars['url'];?>mod/newsletters/duplicate_campaign.php?id=<?php echo $entity->guid;?>" class="newsletters_link"><?php echo elgg_echo('newsletters:command:duplicate'); ?></a>
	&nbsp;&nbsp;
	Delivery : <?php echo get_campaign_delivery_string($entity->delivery_type); ?>
	Activity : <?php echo $entity->activity; ?>
	<?php if ( $entity->date_executed ) echo 'Executed at ' . date('r', intval($entity->date_executed)); ?>
	</div>
	<div class="newsletters_manage_date">From: <?php echo convert_time_for_human($entity->time_start);?> | <?php echo convert_date_for_human($entity->date_start);?> </div>
	<div class="newsletters_manage_date">To:  <?php echo convert_time_for_human($entity->time_end);?> | <?php echo convert_date_for_human($entity->date_end);?></div>
	
	<div class="newsletters_manage_title"><?php echo $entity->title; ?></div>
</div>
<?php
		} else {
			// show item for other
?>
<div id="newsletters_main">
	<div class="newsletters_date"><?php echo $entity->date_start;?></div>
	<div class="newsletters_title"><a href="<?php echo $vars['url'];?>mod/newsletters/view.php?id=<?php echo $entity->guid;?>" class="newsletter"><?php echo $entity->title; ?></a></div>
</div>
<?php
		}
	}
?>