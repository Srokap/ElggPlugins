<?php 

/**
    select.php, part of Newsletters
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
*/

    static $selectjs;
    if (empty($selectjs)) {
        
        echo <<< END
        
<script language="JavaScript" src="{$vars['url']}mod/newsletters/js/input_select.js"></script>
        
END;
        $selectjs = 1;
    }
    $strippedname = sanitise_string($vars['internalname']);
    $prefix = $strippedname;

    $val = $vars['value'];
    
?>
	<div id="<?php echo $prefix . 'box'; ?>" class="select_box">
	<div id="<?php echo $prefix . 'panel_left'; ?>" class="select_panel_left" ></div>
	<div id="<?php echo $prefix . 'panel_controls';?>" class="select_panel_controls" >
	    <div id="<?php echo $prefix . 'button_add';?>" class="select_control_button_add" onclick="return execute_add('<?php echo $prefix; ?>');"></div>
	    <div id="<?php echo $prefix . 'button_rem';?>" class="select_control_button_rem" onclick="return execute_rem('<?php echo  $prefix;?>');"></div>
	</div>
	<div id="<?php echo $prefix .'panel_right';?>" class="select_panel_right"></div>
	</div>
	<input type="hidden" id="<?php echo $prefix;?>" name="<?php echo $prefix;?>" value="">
<script language="JavaScript">
	createSelectObject('<?php echo $prefix; ?>');
<?php
	if ( is_array($vars['options']) ){
		foreach( $vars['options'] as $id => $title )
		{ ?>
	register_select_element('<?php echo $prefix; ?>', <?php echo $id;?>, '<?php echo $title;?>');
<?php		}
	}
?>
	startSelectObject('<?php echo $prefix; ?>', '<?php echo $vars['value']; ?>');
</script>
