<?php

/**
    newsletter.php, part of Newsletters
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
*/

$entity = isset($vars['entity']) ? $vars['entity'] : null;
$context = isset($vars['context']) ? $vars['context'] : get_context();

	if ( $entity ) {
		$content = $entity->content;
		$introduction = $entity->introduction;
		// strip content if necessary
		if ( strlen($content) > NEWSLETTERS_SHORT_DESCRIPTION_LEN ){

			$pos = NEWSLETTERS_SHORT_DESCRIPTION_LEN;
			while ( $content[$pos] != ' ') $pos--;
			$content = substr($content, 0, $pos) . ' ...';
		}
		if ( $context == 'admin'){
			// show item for admin
?>
<div id="newsletters_manage_main">
	<div class="newsletters_manage_commands">
	<a href="<?php echo $vars['url'];?>mod/newsletters/edit.php?id=<?php echo $entity->guid;?>" class="newsletters_link"><?php echo elgg_echo('newsletters:command:edit'); ?></a>
	<a href="<?php echo $vars['url'];?>mod/newsletters/delete.php?id=<?php echo $entity->guid;?>" class="newsletters_link" onclick="return confirm('<?php echo elgg_echo('newsletters:are_you_sure_delete')?>');"><?php echo elgg_echo('newsletters:command:delete'); ?></a>
	<a href="<?php echo $vars['url'];?>mod/newsletters/duplicate.php?id=<?php echo $entity->guid;?>" class="newsletters_link"><?php echo elgg_echo('newsletters:command:duplicate'); ?></a>
	&nbsp;&nbsp;
	<?php if ( $is_for_show ) { ?>
	<img src="<?php echo $vars['url'] . 'mod/newsletters/graphics/message.gif' ?>"/>
	<?php } ?>
	<?php if ( $is_for_email ) { ?>
	<img src="<?php echo $vars['url'] . 'mod/newsletters/graphics/email.gif' ?>"/>
	<?php } ?>
	</div>
	<div class="newsletters_manage_date"><?php echo $entity->date;?></div>
	<div class="newsletters_manage_title"><?php echo $entity->title; ?></div>
	<div class="newsletters_manage_introduction"><?php echo nl2br($introduction); ?></div>
	<div class="newsletters_manage_description"><?php echo nl2br($content); ?></div>
</div>
<?php
		} else {
			// show item for other
?>
<div id="newsletters_main">
	<div class="newsletters_date"><?php echo $entity->date;?></div>
	<div class="newsletters_title"><a href="<?php echo $vars['url'];?>mod/newsletters/view.php?id=<?php echo $entity->guid;?>" class="newsletter"><?php echo $entity->title; ?></a></div>
	<div class="newsletters_description"><?php echo nl2br($content); ?></div>
</div>
<?php
		}
	}
?>