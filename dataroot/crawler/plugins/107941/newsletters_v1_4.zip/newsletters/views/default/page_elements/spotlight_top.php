<?php

/**
    spotlight_top.php, part of Newsletters
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
*/
	$spotlighttop = false;
	if ($_SESSION['user'] instanceof ElggUser) {
		if ($_SESSION['user']->spotlighttop) {
			
			$spotlighttop = true;
			
		}
	}

?>

<div id="layout_spotlight">
<div id="wrapper_spotlight" <?php if (!$spotlighttop) echo "style=\"display:none\"" ?>>
	
<div class="collapsable_box no_space_after">
	<div class="collapsable_box_header">
<?php

	$closed = false;
	if ($_SESSION['user'] instanceof ElggUser) {
		if ($_SESSION['user']->spotlightclosed) {
			
			$closed = true;
			
		}
	}
	if ($closed) {
?>
		<a href="javascript:void(0);" class="toggle_box_contents" onClick="$.post('<?php echo $vars['url']; ?>action/user/spotlight?closed=false')">+</a>
<?php			
		} else {
?>
		<a href="javascript:void(0);" class="toggle_box_contents" onClick="$.post('<?php echo $vars['url']; ?>action/user/spotlight?closed=true')">-</a>
<?php

		}

?>
		<h1><?php echo elgg_echo("spotlight"); ?> top</h1>
	</div>
	<div class="collapsable_box_content" <?php if ($closed) echo "style=\"display:none\"" ?>>
<?php

	$context = get_context();
	if (!empty($context) && elgg_view_exists("spotlight/{$context}")) {
		echo elgg_view("spotlight/{$context}");
	} else {
		echo elgg_view("spotlight/default");
	}
	
	
	

?>
	</div><!-- /.collapsable_box_content -->
</div><!-- /.collapsable_box -->
	
</div><!-- /#wrapper_spotlight -->
</div><!-- /#layout_spotlight -->