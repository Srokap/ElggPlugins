<?php

/**
    default.php, part of Newsletters
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
*/
?>
<div id="spotlight_table" >
	<div id="spotlight_left_column">
	</div>
	<div id="spotlight_right_column">
	</div>
</div>
<div class="clearfloat"></div>

<?php
	// load number of members to display
    $display_count = get_plugin_setting('display_count', 'newsletters');
	// set default values if settings absent
	if ( !$display_count )
		$display_count = 10;
?>
<div id="newsletters_list">
<?php

$ng = array(0);
foreach ( get_entities_from_relationship('member', page_owner(), false, 'group') as $group ){
	$ng[] = (int)($group->getGUID());
}

//$newsletters = newsletters_get_entities($ng, $display_count);
$newsletters = newsletters_get_spotlight_newsletters($ng);

if( $newsletters ){
	// if newsletters list not empty
    foreach($newsletters as $newsletter){
	// Show member icon from profile plugin for each member
	    echo elgg_view('newsletters/newsletter_spotlight', array('entity' => $newsletter));
    }

}
?>
</div>
<div class="clearfloat"></div>
