<?php

/**
    edit.php, part of Newsletters
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
*/

	// get id of modified newsletter entity and redirect if not present
	$newsletter_id = (int)get_input('id');
	if ( ! $newsletter_id ){
        system_message(elgg_echo("newsletters:invalid_newsletter"));
        forward("pg/newsletters/");
	}
	// loading newsletter entity for modification
	$newsletter = get_entity($newsletter_id);
	//get the full page owner entity
	$entity = get_entity(page_owner());

	// building edit form
	$form_body = '';
	$form_body .= elgg_echo('newsletters:manage:date');
	$form_body .= elgg_view('input/calendar', array('internalname' => 'date', 'value' => $newsletter->date ));
	$form_body .= '<br />';
	$form_body .= elgg_echo('newsletters:manage:title');
	$form_body .= elgg_view('input/text', array('internalname' => 'title', 'value' => $newsletter->title));
	$form_body .= elgg_echo('newsletters:manage:introduction');
	$form_body .= elgg_view('input/longtext', array('internalname' => 'introduction', 'value' => $newsletter->introduction, 'class' => 'input-textarea-short'));
	$form_body .= elgg_echo('newsletters:manage:content');
	$form_body .= elgg_view('input/longtext', array('internalname' => 'content', 'value' => $newsletter->content));
    $form_body .= elgg_echo('newsletters:manage:signature');
	$form_body .= elgg_view('input/text', array('internalname' => 'signature', 'value' => $newsletter->signature));
	
	$form_body .= elgg_echo('newsletters:manage:tags');
	$form_body .= elgg_view('input/text', array('internalname' => 'tags', 'value' => $newsletter->tags));
	
	$form_body .= elgg_view('input/submit', array('value' => elgg_echo('newsletters:manage:update')));
	$form_body .= elgg_view('input/hidden', array('internalname' => 'guid', 'value' => $newsletter->guid));

	echo elgg_view('input/form', array('body' => $form_body, 'action' => $CONFIG->url . "action/newsletters/edit"));
	
?>
