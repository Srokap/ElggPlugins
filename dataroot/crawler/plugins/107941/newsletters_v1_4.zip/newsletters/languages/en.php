<?php
/**
    en.php, part of Newsletters
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
*/

$language_array_en = array(
    'newsletters' => 'NewsLetters',
    'newsletters:description' => 'Newsletters',
    'newsletters:manage' => 'Manage newsletters',
    'newsletters:show' => 'Newsletter',
    'newsletters:edit' => 'Edit newsletter',
    'newsletters:manage:title' => 'Title',
    'newsletters:manage:introduction' => 'Introduction',
    'newsletters:manage:content' => 'Description',
    'newsletters:manage:date' => 'Date',
    'newsletters:manage:save' => 'Save',
    'newsletters:manage:update' => 'Update',
    'newsletters:manage:signature' => 'Author',
	'newsletters:manage:delivery_group' => 'Delivery group',
	'newsletters:manage:all_members' => 'All members',
	'newsletters:manage:delivery_type' => 'Delivery type',
	'newsletters:manage:delivery_email' => 'Email only',
	'newsletters:manage:delivery_widget' => 'Widget only',
	'newsletters:manage:delivery_email_widget' => 'Email + Widget',
	'newsletters:manage:tags' => 'Tags',
	'newsletters:blank' => 'Fields can not be empty',
 	'newsletters:save_error' => 'Unable save newsletter',
    'newsletters:posted' => 'Newsletter inserted',
    'newsletters:are_you_sure_delete' => 'Are you sure whant delete it ?',
    'newsletters:deleted' => 'Newsletter was successfully deleted',
    'newsletters:notdeleted' => 'Unable to delete newsletter',
    'newsletters:updated' => 'Newsletter updated',
    'newsletters:duplicated' => 'Newsletter duplicated',
    'newsletters:notduplicated' => 'Newsletter was not duplicated',
    'newsletters:sended' => 'Sended %u emails',
    'newsletters:display_count' => 'Newsletters count for display in widget',
    'newsletters:widget:title' => 'Newsletters',
    'newsletters:widget:description' => 'Showing latest newsletters',
    'newsletters:command:edit' => 'Edit',
    'newsletters:command:delete' => 'Delete',
    'newsletters:command:duplicate' => 'Duplicate',
    'campaigns' => 'campaigns',
    'campaigns:updated' => 'Campaigns updated successful',
	'campaigns:manage' => 'Manage campaigns',
	'campaigns:manage:title' => 'Title',
    'campaigns:manage:date:start' => 'Start date',
    'campaigns:manage:time:start' => 'Start time',
    'campaigns:manage:date:end' => 'End date',
    'campaigns:manage:time:end' => 'End time',
    'campaigns:manage:delivery_group' => 'Delivery group',
    'campaigns:publication:newsletters_list' => 'Newsletters in campaign',
    'campaigns:publication:delivery' => 'Delivery type ',
	'campaigns:publication:widget'	=> '... by widget',
	'campaigns:publication:spotlight'	=> '... by Spotlight',
	'campaigns:publication:message'	=> '... by internal message',
	'campaigns:publication:email'		=> '... by email',
	
	'campaigns:publication:activity'    => 'Activity type',
	'campaigns:publication:state:active'		=> 'Active',
	'campaigns:publication:state:inactive'	=> 'Inactive',
 	'campaign:deleted' => 'campaign deleted',
 	'campaign:notdeleted' => 'Unable delete',
 	'campaign:edit' => 'Edit campaign',
 	
 	'spotlight:manage' 	=> 'Manage spotlight',
 	'spotlight:show'    => 'Open spotlight for all (in bottom)',
 	'spotlight:hide'    => 'Close spotlight for all (in bottom)',
 	'spotlight:opened' 	=> 'Spotlight for users is opened',
 	'spotlight:closed' 	=> 'Spotlight for users is closed',
 	'spotlight:show:top'    => 'Open spotlight for all (in top)',
 	'spotlight:hide:top'    => 'Close spotlight for all (in top)',

);

// register constants for english version of elgg site
add_translation('en', $language_array_en);

?>