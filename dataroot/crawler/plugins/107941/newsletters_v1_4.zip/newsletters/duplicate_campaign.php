<?php
/**
    duplicate_campaign.php, part of Newsletters
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
*/
// Loading Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

// Load newsletters model
require_once(dirname(__FILE__) . "/models/model.php");

// Define context
set_context('admin');
// only for admin user
admin_gatekeeper();

global $CONFIG;

$campaign_id = (int) get_input('id',0);

// Make sure we actually have permission to edit
$campaign = get_entity($campaign_id);

if ($campaign->getSubtype() == "campaign" && $campaign->canEdit()) {

	// Initialise a new ElggObject
	$duplicate = new ElggObject();
	// Tell the system it's a blog post
	$duplicate->subtype = "campaign";
	// Set its owner to the current user
	$duplicate->owner_guid = $_SESSION['user']->getGUID();
	// Set the current container (group guid)
	$duplicate->container_guid = $campaign->container_guid;
	// Set its access according to delivery group (public or loged in)
	$duplicate->access_id = $campaign->access_id;
	// Set its information appropriately
	$duplicate->title = $campaign->title;
	$duplicate->date_start = $campaign->date_start;
	$duplicate->time_start = $campaign->time_start;
	$duplicate->date_end = $campaign->date_end;
	$duplicate->time_end = $campaign->time_end;

	$duplicate->delivery_type = $campaign->delivery_type;
	$duplicate->delivery_group = $campaign->delivery_group;
	$duplicate->activity = 0;
	$duplicate->newsletters_list = $campaign->newsletters_list;

	if ( $duplicate->save() ) {
		// Success message
		system_message(elgg_echo("campaigns:duplicated"));
	} else {
		// show error
		register_error(elgg_echo("campaigns:notduplicated"));
	}
}

// Forward to the manage page
forward("pg/newsletters/campaigns");

?>
