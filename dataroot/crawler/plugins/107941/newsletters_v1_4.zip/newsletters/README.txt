/**
    README.txt, part of Newsletters
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
	
    					    	
    Elgg version: 1.5
    Title: Newsletters
    Intro: Set of tools to make advertisement campaigns

    Description:
    Specialized plugin, indeed is a set of tools to manage news, campaigns, spotlight element and user notification delivery
    News elements are created in admin part. Those elements can be used in different campaigns. Then Campaigns are created. 
    Campaigns include News elements and are configured to deliver information to user in predefined time by predefined mean (show in widget, show in spotlight, email)
    Also plugin customizes spotlight to show active campaigns and provides interface to forced opening/closing spotlight panel for users.
    Made for advertisement campaigns.
    Plugin is developed by Web100 Net Technology Center, Ltd. http://web100.com.ua under the assignment of Lorinthe,BV.

    Dependencies: No
    Version: 1.4
    Licence: GPL v.3
 */

The Elgg 1.x newsletters plugin allows to add newsletters for groups or all members and provide access to this via widget and/or email notification.


*Activating the newsletters plugin*

Simply extract the newsletters plugin into the mod directory and
activate it as usual using the Elgg 1.x tool administration.

This creates a "newsletters" widget item in widgets list and menu item in user and administration area.
Newsletters must be groupped into campaigns for execution in ...

*Plugin settings*
Administrator user can use menu to open plugin setup page.
This page allow setup default number fo latest newsletters to show in widget.

*Newsletters administration*
Administrator can use "Manage newsletters" menu item in administrative area to add new newsletters or edit/delete exists.
When administrator insert new newsletter or saving modified item users will be notified regards settings for delivery type, delivery group and setting in user profile named "notification_newsletters".

*User settings*
User can set on it's profile page "notification_newsletters" parameter for allow or disallow notification by email


Changelog:

1.4
- fixed bug with huge logs generation
