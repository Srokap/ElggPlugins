<?php
/**
    start.php, part of Newsletters
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
*/

include_once(dirname(dirname(__FILE__))) . '/newsletters/models/model.php';

// define constant for using in other parts
define('NEWSLETTERS_SHORT_DESCRIPTION_LEN', 20);

// unique function for plugin initialization
function newsletters_init(){
    global $CONFIG;
    // registering languages translation constants
    register_translations($CONFIG->pluginspath . "newsletters/languages/");
    // register handler for newsletters list page
    register_page_handler('newsletters', 'newsletters_list_handler');
    // registering action for add news
    register_action('newsletters/add', false, $CONFIG->pluginspath . 'newsletters/actions/add.php');
    // registering action for edit news
    register_action('newsletters/edit', false, $CONFIG->pluginspath . 'newsletters/actions/edit.php');
    // registering action for news duplication news
    register_action('newsletters/duplicate', false, $CONFIG->pluginspath . 'newsletters/actions/duplicate.php');
    // registering action for add campaign
    register_action('newsletters/add_campaign', false, $CONFIG->pluginspath . 'newsletters/actions/add_campaign.php');
    // registering action for edit campaign
    register_action('newsletters/edit_campaign', false, $CONFIG->pluginspath . 'newsletters/actions/edit_campaign.php');
    // registering action for show spotlight
    register_action('newsletters/showSpotlight', false, $CONFIG->pluginspath . 'newsletters/actions/show_spotlight.php');
    // registering action for hide spotlight
    register_action('newsletters/hideSpotlight', false, $CONFIG->pluginspath . 'newsletters/actions/hide_spotlight.php');
    // registering action for show spotlight
    register_action('newsletters/showSpotlightTop', false, $CONFIG->pluginspath . 'newsletters/actions/show_spotlight_top.php');
    // registering action for hide spotlight
    register_action('newsletters/hideSpotlighTop', false, $CONFIG->pluginspath . 'newsletters/actions/hide_spotlight_top.php');

    // register plugin widget
    add_widget_type('newsletters', elgg_echo('newsletters:widget:title'), elgg_echo('newsletters:widget:description'));
	// registering css styles
	extend_view('css','newsletters/css');
	
	//extend_view('input/time', 'input/time');
	
	// Register entity type
	register_entity_type('object', 'newsletter');
	register_entity_type('object', 'campaign');
	
	// register cron avaery minute task
	register_plugin_hook('cron', 'minute', 'newsleters_cron_handler');

}

// handler for page setup, registered to add menu items for page menu
function newsletters_pagesetup(){
	global $CONFIG;
	// if requested admin area by logged admin
	if ( get_context() == 'admin' && isadminloggedin() ){
		add_submenu_item( elgg_echo('newsletters:manage'), $CONFIG->wwwroot . 'pg/newsletters/manage/');
		add_submenu_item( elgg_echo('campaigns:manage'), $CONFIG->wwwroot . 'pg/newsletters/campaigns/');
		add_submenu_item( elgg_echo('spotlight:manage'), $CONFIG->wwwroot . 'pg/newsletters/spotlight/');
	} else {
//		if ( isloggedin() ) // only for logged in users
//			add_submenu_item( elgg_echo('newsletters:show'), $CONFIG->wwwroot . 'pg/newsletters/');
	}
}

// handler for list page
function newsletters_list_handler($page){
	global $CONFIG;
	// if requested newsletters/manage url include admin area script
	if ( isset($page[0]) && $page[0] == 'manage' )
		include($CONFIG->pluginspath . 'newsletters/manage.php');
	elseif ( isset($page[0]) && $page[0] == 'campaigns' )
		include($CONFIG->pluginspath . 'newsletters/campaigns.php');
	elseif ( isset($page[0]) && $page[0] == 'spotlight')
		include($CONFIG->pluginspath . 'newsletters/spotlight.php');
	else    // else include index page for news
		include($CONFIG->pluginspath . 'newsletters/index.php');
}

function newsleters_cron_handler($hook, $entity_type, $returnvalue, $params){
	$return = $returnvalue;
	$campaigns = newsletters_get_active_campaigns();
    $return .= 'Active campaigns - ' . count($campaigns) . "\r\n";
    foreach ($campaigns as $campaign)
    {
		if ( newsletters_execute_campaign($campaign) )
		{
			$return .= 'Campaign ' . $campaign->guid . ' for ' . $campaign->delivery_type . " executed \r\n";
		}
    }
	return $return;
}

// register plugin event handler for plugin initialization
register_elgg_event_handler('init', 'system', 'newsletters_init');
// register plugin event handler for page setup
register_elgg_event_handler('pagesetup', 'system', 'newsletters_pagesetup');


?>
