/**
    input_select.js, part of Newsletters
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
*/

var arrSelectObjects = new Array();


function init_select_component(pref){
	arrSelectObjects[pref] = new Array();
	arrSelectObjects[pref]['arrElements'] = new Array();
	arrSelectObjects[pref]['selElements'] = new Array();
	arrSelectObjects[pref]['name_lp'] = pref + 'panel_left';
	arrSelectObjects[pref]['name_rp'] = pref + 'panel_right';
	arrSelectObjects[pref]['currElementLP'] = null;
	arrSelectObjects[pref]['currElementRP'] = null;
	arrSelectObjects[pref]['currElementLID'] = 0;
	arrSelectObjects[pref]['currElementRID'] = 0;

}

function register_select_element(pref, id, title){
	if ( arrSelectObjects[pref] ){
    	arrSelectObjects[pref]['arrElements'].push(new Array(id, title));
	}
}

function _highlightElement(element, currElement){
	if ( currElement ){
		currElement.style.color = element.style.color;
		currElement.style.backgroundColor = element.style.backgroundColor;
		currElement.style.fontWeight = element.style.fontWeight;
	}
	element.style.fontWeight = 'bold';
}

function _unhighlightElement(element){
	if ( element ){
		element.style.fontWeight = 'normal';
	}
}

function _hideElement(element){
	if ( element ){
		element.style.display = 'none';
	}
}

function _showElement(element){
	if (element){
		element.style.display = 'block';
	}
}

function _getElementPosition(arr, elementId){
		for(i = 0; i < arr.length; i++){
			if ( arr[i][0] == elementId )
				return i;
		}
		return -1;
}

function _highlightButton(buttonID){
	btn = document.getElementById(buttonID);
	if ( btn ){
		btn.style.backgroundColor = '#9acd32';
	}
}

function _unhighlightButton(buttonID){
	btn = document.getElementById(buttonID);
	if ( btn ){
		btn.style.backgroundColor = 'transparent';
	}
}

function lpOneClick(pref, elementId){
	elementGUID = pref + 'lpe_' + elementId;
	el = document.getElementById(elementGUID);
	if ( el ){
   		_highlightElement(el, arrSelectObjects[pref]['currElementLP']);
   		arrSelectObjects[pref]['currElementLP'] = el;
    	arrSelectObjects[pref]['currElementLID'] = elementId;
    	_highlightButton(pref + 'button_add');
	}
}

function rpOneClick(pref, elementId){
	elementGUID = pref + 'rpe_' + elementId;
	el = document.getElementById(elementGUID);
	if ( el ){
   		_highlightElement(el, arrSelectObjects[pref]['currElementRP']);
		arrSelectObjects[pref]['currElementRP'] = el;
    	arrSelectObjects[pref]['currElementRID'] = elementId;
    	_highlightButton(pref + 'button_rem');
	}
}


function execute_add(pref){
	if (arrSelectObjects[pref]['currElementLP']){
    	_unhighlightElement(arrSelectObjects[pref]['currElementLP']);
		_hideElement(arrSelectObjects[pref]['currElementLP']);
		var pos = _getElementPosition(arrSelectObjects[pref]['arrElements'], arrSelectObjects[pref]['currElementLID']);
		if (  pos >= 0 ){
			arrSelectObjects[pref]['selElements'].push(arrSelectObjects[pref]['arrElements'][pos]);
			draw_right_panel(pref);
		}
		arrSelectObjects[pref]['currElementLP'] = null;
		arrSelectObjects[pref]['currElementLID'] = 0;
		update_select_value(pref);
    	_unhighlightButton(pref + 'button_add');
	}
}

function update_select_value(pref){
	var sValue = '';
	for(i = 0; i < arrSelectObjects[pref]['selElements'].length; i++){
		sValue += arrSelectObjects[pref]['selElements'][i][0] + ',';
	}
	el = document.getElementById(pref);
	if ( el ){
		el.value = sValue;
 	} else {
		alert(pref + ' not found');
 	}

}

function execute_rem(pref){
	if (arrSelectObjects[pref]['currElementRP']){
		_hideElement(arrSelectObjects[pref]['currElementRP']);
		var pos = _getElementPosition(arrSelectObjects[pref]['selElements'], arrSelectObjects[pref]['currElementRID']);
		if (  pos >= 0 ){
			elementGUID = pref + 'lpe_' + arrSelectObjects[pref]['selElements'][pos][0];
			element = document.getElementById(elementGUID);
			if ( element )
			    _showElement(element);
			arrSelectObjects[pref]['selElements'].splice(pos, 1);
			draw_right_panel(pref);
		}
		arrSelectObjects[pref]['currElementRP'] = null;
		arrSelectObjects[pref]['currElementRID'] = 0;
		update_select_value(pref);
    	_unhighlightButton(pref + 'button_rem');
	}
}

function _getElementSrc(pref, arr){
	return '<div id="' + pref + 'lpe_' + arr[0] + '" class="select_lp_element" onclick="return lpOneClick(\''+ pref +'\', ' + arr[0] + ');" >' + arr[1] + '</div>';
}

function _getElementSrcRight(pref, arr){
	return '<div id="' + pref + 'rpe_' + arr[0] + '" class="select_rp_element" onclick="return rpOneClick(\''+ pref +'\', ' + arr[0] + ');">' + arr[1] + '</div>';
}

function init_left_panel(pref){
	lp = document.getElementById(arrSelectObjects[pref]['name_lp']);
	if ( lp ){
		drawSrc = '';
		for(i = 0; i < arrSelectObjects[pref]['arrElements'].length; i++){
			drawSrc += _getElementSrc(pref, arrSelectObjects[pref]['arrElements'][i]);
		}
		lp.innerHTML = drawSrc;
	}
}

function draw_right_panel(pref){
	rp = document.getElementById(arrSelectObjects[pref]['name_rp']);
	if ( rp ){
		drawSrc = '';
		for(i = 0; i < arrSelectObjects[pref]['selElements'].length; i++){
			drawSrc += _getElementSrcRight(pref, arrSelectObjects[pref]['selElements'][i]);
		}
		rp.innerHTML = drawSrc;
		if ( arrSelectObjects[pref]['currElementRP'] ){
			_highlightElement(arrSelectObjects[pref]['currElementRP'], arrSelectObjects[pref]['currElementRP']);
		}
	}

}

function createSelectObject(pref){
    init_select_component(pref);
}

function startSelectObject(pref, init_string){
    init_left_panel(pref);
    if ( init_string ){
    	var aElements = new Array();
		aElements = init_string.split(',');
    	for(var i = 0; i < aElements.length; i++){
			var id = parseInt(aElements[i]);
			if ( id ){
				elementGUID = pref + 'lpe_' + id;
				el = document.getElementById(elementGUID);
				if ( el ){
					_hideElement(el);
					var pos = _getElementPosition(arrSelectObjects[pref]['arrElements'], id);
					if (  pos >= 0 ){
						arrSelectObjects[pref]['selElements'].push(arrSelectObjects[pref]['arrElements'][pos]);
					}
				}
			}
    	}
		draw_right_panel(pref);
		update_select_value(pref);
    }
}