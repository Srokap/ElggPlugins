/**
    input_time.js, part of Newsletters
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
*/

var value_saved = '';
var reg=/^(\d{0,2})\:(\d{0,2})$/;
var reg_strong=/^\d{2}\:\d{2}$/;
var blnTimeCheckCanWork = true;
var intCaretPosition;

function checkTimeFieldDown(e, obj){
	if ( !blnTimeCheckCanWork )
	    return false;
 	blnTimeCheckCanWork = false;
	if ( checkTimeIsOk(obj.value) )
	{
		value_saved = obj.value;
		intCaretPosition = getCaretPosition(obj);
	}
	return true;
}

function checkTimeFieldUp(e, obj){
	if ( !checkTimeIsOk(obj.value) )
	{
		obj.value = value_saved;
		setCaretPosition(obj, intCaretPosition);
	}
	blnTimeCheckCanWork = true;
	return true;
}

function checkTimeIsOk(time_value){
	var res = reg.exec(time_value);
	if ( ! res || parseInt(res[1]) > 23 || parseInt(res[2]) > 59 )
	    return false;
	return true;
}

function checkTime(obj){
	if ( reg_strong.test(obj.value) )
	    return true;
	obj.focus();
	return false;
}

function getCaretPosition(obj) {
	var CaretPos = 0;
	// IE Support
	if (document.selection) {
		obj.focus ();
		var Sel = document.selection.createRange();
		var SelLength = document.selection.createRange().text.length;
		Sel.moveStart ('character', -obj.value.length);
		CaretPos = Sel.text.length - SelLength;
	}
	// Firefox support
	else if (obj.selectionStart || obj.selectionStart == '0')
		CaretPos = obj.selectionStart;
	return (CaretPos);
}

function setCaretPosition(obj, pos) {
    	// IE Support
    if(obj.createTextRange) {
        var range = obj.createTextRange();
        range.move("character", pos);
        range.select();
    }
    // Firefox support
	else if(obj.selectionStart) {
        obj.focus();
        obj.setSelectionRange(pos, pos);
    }
}

