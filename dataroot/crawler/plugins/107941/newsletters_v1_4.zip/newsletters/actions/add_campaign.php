<?php

/**
    add_campaign.php, part of Newsletters
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
*/

	// Make sure we're logged in (send us to the front page if not)
	admin_gatekeeper();

	// Load newsletters model
	require_once(dirname(__FILE__) . "/../models/model.php");
	
	$title = get_input('title');
	$date_start = get_input('date_start');
	$time_start = get_input('time_start');
	$date_end = get_input('date_end');
	$time_end = get_input('time_end');

	$delivery_group = get_input('delivery_group');
	$delivery_type = get_input('delivery_type');
	$activity = get_input('activity');
	
	$newsletters_list = get_input('newsletters_list');
	
	$access = 1; // for logged in user
	if ( $delivery_group == 0 ) // if delivery group = all
	    $access = 2; // public access
	

	// Cache to the session
	$_SESSION['campaign_title'] = $title;
	$_SESSION['campaign_date_start'] = $date_start;
	$_SESSION['campaign_time_start'] = $time_start;
	$_SESSION['campaign_date_end'] = $date_end;
	$_SESSION['campaign_time_end'] = $time_end;
 	$_SESSION['campaign_delivery_group'] = $delivery_group;
 	$_SESSION['campaign_delivery_type'] = $delivery_type;
 	$_SESSION['activity'] = $activity;
 	$_SESSION['newsletters_list'] = $newsletters_list;

	// Check for empty fields
	if ( empty($title) || empty($date_start) || empty($time_start) || empty($date_end) || empty($time_end) || empty($delivery_type) ) {
		register_error(elgg_echo("campaign:blank"));
		forward("pg/newsletters/campaigns");

	// Otherwise, save the newsletter post
	} else {
			
	// Initialise a new ElggObject
			$campaign = new ElggObject();
	// Tell the system it's a blog post
			$campaign->subtype = 'campaign';
	// Set its owner to the current user
			$campaign->owner_guid = $_SESSION['user']->getGUID();
	// Set the current container (group guid)
			$campaign->container_guid = $delivery_group;
	// Set its access according to delivery group (public or loged in)
			$campaign->access_id = $access;
	// Set its information appropriately
			$campaign->title = $title;
			$campaign->date_start = $date_start;
			$campaign->time_start = $time_start;
			$campaign->date_end = $date_end;
			$campaign->time_end = $time_end;
 			$campaign->delivery_type = $delivery_type;
 			$campaign->delivery_group = $delivery_group;
 			$campaign->activity = $activity;
 			$campaign->newsletters_list = $newsletters_list;

			campaign_prepare_for_save($campaign);
	// Save the newsletter post
			if (!$campaign->save()) {
				register_error(elgg_echo("campaign:save_error"));
				forward("pg/newsletters/campaigns");
			}
	// Success message
			system_message(elgg_echo("newsletters:posted"));

	// Remove the campaign post cache
			unset($_SESSION['campaign_title']);
			unset($_SESSION['campaign_date_start']);
			unset($_SESSION['campaign_time_start']);
			unset($_SESSION['campaign_date_end']);
			unset($_SESSION['campaign_time_end']);
 			unset($_SESSION['campaign_delivery_group']);
 			unset($_SESSION['campaign_delivery_type']);
 			unset($_SESSION['activity']);
 			unset($_SESSION['newsletters_list']);


	// Forward to the main newsletters page
			forward("pg/newsletters/campaigns");
		}
		
?>
