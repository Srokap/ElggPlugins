<?php

/**
    edit.php, part of Newsletters
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
*/

	// Make sure we're logged in (send us to the front page if not) and admin
	admin_gatekeeper();

	// Load newsletters model
	require_once(dirname(__FILE__) . "/../models/model.php");

	// get input fields
	$newsletter_id = (int)get_input('guid');
	$date = get_input('date');
	$title = get_input('title');
	$introduction = get_input('introduction');
	$content = get_input('content');
	$signature = get_input('signature');
	$tags = get_input('tags');
	
	if ( !$newsletter_id){
		// redirect if newsletter id not present
        register_error(elgg_echo("newsletters:invalid"));
        forward("pg/newsletters/");
	}
	$newsletter = get_entity($newsletter_id);
	if ( !$newsletter){
		// redirect if newsletter not exists
        register_error(elgg_echo("newsletters:invalid"));
        forward("pg/newsletters/");
	}
	
	// if entity is newsletter and we can edit it
	if ($newsletter->getSubtype() == 'newsletter' && $newsletter->canEdit()) {

		$access = 1; // for logged in user
	
		// Convert title to string of tags into a preformatted array
		$tagarray = string_to_tag_array($tags);

		// Check for empty fields and redirect if required field empty
		if (empty($date) || empty($title) || empty($introduction) || empty($content) || empty($signature) ) {
			register_error(elgg_echo("newsletters:blank"));
			forward("pg/newsletters/");

		// Otherwise, update the newsletter 
		} else {
			
			// Set its access according to delivery group (public or loged in)
			$newsletter->access_id = $access;

			// Set its information appropriately
			$newsletter->date = $date;
			$newsletter->title = $title;
			$newsletter->introduction = $introduction;
			$newsletter->content = $content;
			$newsletter->signature = $signature;

			// Save the newsletter post
			if (!$newsletter->save()) {
				register_error(elgg_echo("newsletters:save_error"));
				forward("pg/newsletters/manage");
			}

			// Now let's add tags. We can pass an array directly to the object property! Easy.
			$newsletter->clearMetadata('tags');
			if (is_array($tagarray)) {
				$newsletter->tags = $tagarray;
			}

	// Success message
			system_message(elgg_echo("newsletters:updated"));

	// Forward to the main newsletters page
			forward("pg/newsletters/manage");
		}
	}
		
?>
