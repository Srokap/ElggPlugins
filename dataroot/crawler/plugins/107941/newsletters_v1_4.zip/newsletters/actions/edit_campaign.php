<?php

/**
    edit_campaign.php, part of Newsletters
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
*/
	// Make sure we're logged in (send us to the front page if not) and admin
	admin_gatekeeper();

	// Load newsletters model
	require_once(dirname(__FILE__) . "/../models/model.php");

	// get input fields
	$campaign_id = (int)get_input('guid');
	$title = get_input('title');
	$date_start = get_input('date_start');
	$time_start = get_input('time_start');
	$date_end = get_input('date_end');
	$time_end = get_input('time_end');

	$delivery_group = get_input('delivery_group');
	$delivery_type = get_input('delivery_type');
	$activity = get_input('activity');
	$newsletters_list = get_input('newsletters');

	
	if ( !$campaign_id){
		// redirect if newsletter id not present
        register_error(elgg_echo("campaigns:invalid:id"));
        forward("pg/newsletters/campaigns");
	}
	$campaign = get_entity($campaign_id);
	if ( !$campaign ){
		// redirect if newsletter not exists
        register_error(elgg_echo("campaigns:invalid:object"));
        forward("pg/newsletters/campaigns");
	}
	
	// if entity is newsletter and we can edit it
	if ($campaign->getSubtype() == 'campaign' && $campaign->canEdit()) {

		$access = 1; // for logged in user
		if ( $delivery_group == 0 ) // if delivery group = all
	    	$access = 2; // public access
	

		// Check for empty fields and redirect if required field empty
		if ( empty($title) || empty($date_start) || empty($time_start) || empty($date_end) || empty($time_end) || empty($delivery_type) ) {
			register_error(elgg_echo("campaigns:blank"));
			forward("pg/newsletters/campaigns");

		// Otherwise, update the newsletter 
		} else {
			
			// Set the current container (group guid)
			$campaign->container_guid = $delivery_group;
			// Set its access according to delivery group (public or loged in)
			$campaign->access_id = $access;
			// Set its information appropriately
			$campaign->title = $title;
			$campaign->date_start = $date_start;
			$campaign->time_start = $time_start;
			$campaign->date_end = $date_end;
			$campaign->time_end = $time_end;
 			$campaign->delivery_type = $delivery_type;
 			$campaign->delivery_group = $delivery_group;
 			$campaign->activity = $activity;
 			$campaign->newsletters_list = $newsletters_list;
 			// prepare for saving
			campaign_prepare_for_save($campaign);
 			
			// Save the campaign post
			if (!$campaign->save()) {
				register_error(elgg_echo("campaigns:save_error"));
				forward("pg/newsletters/campaigns");
			}

	// Success message
			system_message(elgg_echo("campaigns:updated"));
	// Forward to the main newsletters page
			forward("pg/newsletters/campaigns");
		}
	}
		
?>
