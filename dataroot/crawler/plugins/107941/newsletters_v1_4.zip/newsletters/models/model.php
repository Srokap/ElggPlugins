<?php
/**
    model.php, part of Newsletters
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
*/


define('NEWSLETTERS_PUBLICATION_WIDGET', 'widget');
define('NEWSLETTERS_PUBLICATION_SPOTLIGHT', 'spotlight');
define('NEWSLETTERS_PUBLICATION_MESSAGE', 'message');
define('NEWSLETTERS_PUBLICATION_EMAIL', 'email');

function get_campaign_delivery_options()
{
	$aOut = array(
	     	elgg_echo('campaigns:publication:widget')	=> NEWSLETTERS_PUBLICATION_WIDGET,
	     	elgg_echo('campaigns:publication:spotlight')=> NEWSLETTERS_PUBLICATION_SPOTLIGHT,
	     	elgg_echo('campaigns:publication:message')	=> NEWSLETTERS_PUBLICATION_MESSAGE,
	     	elgg_echo('campaigns:publication:email')	=> NEWSLETTERS_PUBLICATION_EMAIL
	);
	return $aOut;
}

function get_campaign_delivery_string($delivery_type)
{
	return elgg_echo('campaigns:publication:' . $delivery_type);
}


function newsletters_get_entities($group_guid = 0, $limit = 0, $offset = 0){
	$entities = get_entities('object', 'newsletter', 0, '', $limit, $offset);
	// get list of newsletter entities
	if ( isadminloggedin() )
	    return $entities; // return all list for admin
	$result = array();
	// check parameter and convert to array if necessary
	if ( !is_array($group_guid) )
	    $group_guid = array((int) $group_guid);
	// filter newsletter for groups
	if ( is_array($entities) )
	{
	    while( count($entities) ){
    		$entity = array_shift($entities);
		if ( in_array($entity->delivery_group, $group_guid) && strpos($entity->delivery_type, 'widget') !== false ){
			array_push($result, $entity);
		}
	    }
	}
	return $result;
}


// get list of all entities 
function newsletters_get_campaigns($group_guid = 0, $limit = 0, $offset = 0){
	$entities = get_entities('object', 'campaign', 0, '', $limit, $offset);
	// get list of campaigns entities
	if ( isadminloggedin() )
	    return $entities; // return all list for admin
	$result = array();
	// check parameter and convert to array if necessary
	if ( !is_array($group_guid) )
	    $group_guid = array((int) $group_guid);
	// filter newsletter for groups
	if ( is_array($entities) )
	{
	    while( count($entities) ){
    		$entity = array_shift($entities);
		if ( in_array($entity->delivery_group, $group_guid) ){
			array_push($result, $entity);
		}
	    }
	}
	return $result;
}

function newsletters_get_active_campaigns($group_guid = 0, $delivery_type = ''){
	// load all campaigns list
	$campaigns = newsletters_get_campaigns($group_guid, 0, 0);
	$result = array();
	if ( $campaigns )
	{
		while ( count($campaigns) )
		{
			$campaign = array_shift($campaigns);
			// check publication type
			if ( $delivery_type != '' && $campaign->delivery_type != $delivery_type ) continue;
			// skip if already executed or not active
			if ( $campaign->date_executed || !$campaign->activity ) continue;
			$now = time();
			$campaign_start = $campaign->date_start + $campaign->time_start;
			// skip if early
			if ( $campaign_start > $now ) continue;
			$campaign_end = $campaign->date_end + $campaign->time_end;
			// skip if later
			if ( $campaign_end < $now ) continue;
			// else save for output
			array_push($result, $campaign);
		}
	}
	return $result;
}

// get newsletters for delivery type 
function newsletters_get_delivery_newsletters($delivery_type, $group_guid = 0){
	// load all campaigns list
	$campaigns = newsletters_get_active_campaigns($group_guid, $delivery_type);
	$result = array();
	foreach ( $campaigns as $campaign )
	{
		// skip if no attached newsletters for campaign
		if ( !$campaign->newsletters_list ) continue;
		// get all IDs for attached newsletters
		$aNewsletters = explode(',', $campaign->newsletters_list);
		foreach ( $aNewsletters as $id )
		{
			if ( ! $id ) continue; // skip for potential empty elements
			$newsletter = get_entity($id);
			if ( $newsletter )
			    array_push($result, $newsletter);
		}
	}
	return $result;
}

function newsletters_execute_campaign($campaign){
	$countExecuted = 0;
	if ( $campaign ){
		if ( $campaign->delivery_type == NEWSLETTERS_PUBLICATION_MESSAGE || $campaign->delivery_type == NEWSLETTERS_PUBLICATION_EMAIL) {
			if ( $campaign->newsletters_list ){
				$aNewsletters = explode(',', $campaign->newsletters_list);
				foreach ( $aNewsletters as $id )
				{
					if ( ! $id ) continue; // skip for potential empty elements
					$newsletter = get_entity($id);
					if ( $newsletter ){
					    newsletters_send_entity($newsletter, $campaign->delivery_type, $campaign->delivery_group);
						$countExecuted++;
					}
				}
				// mark as executed and save state
				$campaign->date_executed = time();
				$campaign->save();
			}
		}
		return $countExecuted;
	}
	return false;
}

// get newsletters for widget ( newsletter for active campaigns)
function newsletters_get_widget_newsletters($group_guid = 0){
	// load all campaigns list
	return newsletters_get_delivery_newsletters(NEWSLETTERS_PUBLICATION_WIDGET, $group_guid);
}

// get newsletters for widget ( newsletter for active campaigns)
function newsletters_get_spotlight_newsletters($group_guid = 0){
	// load all campaigns list
	return newsletters_get_delivery_newsletters(NEWSLETTERS_PUBLICATION_SPOTLIGHT, $group_guid);
}

// show list of entities
function newsletters_list_entities($group_guid = 0, $limit = 0, $offset = 0){
	$entities = newsletters_get_entities($group_guid, $limit, $offset);
	return elgg_view('newsletters/newsletters', array(
				'entities' => $entities,
				'context' => get_context(),
		));
}

// show list of campaigns
function newsletters_list_campaigns($group_guid = 0, $limit = 0, $offset = 0){
	$entities = newsletters_get_campaigns($group_guid, $limit, $offset);
	return elgg_view('newsletters/campaigns', array(
				'entities' => $entities,
				'context' => get_context(),
		));
}

// sending notification is necessary
function newsletters_send_entity($newsletter, $type, $group_guid = 0){
	$count = 0;
	if ( $group_guid == 0 ) // send to all members
		$users = get_entities('user', '', 0, '', 0);
	else // select group members
	    $users = get_group_members($group_guid);
	foreach ( $users as $user){
		if ( $type == NEWSLETTERS_PUBLICATION_EMAIL ){
			if ( newsletters_notify_user_by_email($user, $newsletter) ) // sending notifications and calculate sucessfull
				$count++;
		}
		if ( $type == NEWSLETTERS_PUBLICATION_MESSAGE ){
			if ( newsletters_notify_user_by_message($user, $newsletter) ) // sending notifications and calculate sucessfull
				$count++;
		}
	}
	return $count;
}

// send email for user
function newsletters_notify_user_by_email($user, $newsletter){
	// build title from view
	$metadata = get_metadata_byname($user->getGUID(), 'notification_newsletters');
	if ( !$metadata || $metadata->value != 'yes' )
	    return false;
	$title = elgg_view('newsletters/email_subject', 	array( 'user' => $user, 'newsletter' => $newsletter));
	// build email body from view
	$body = elgg_view('newsletters/email_body', 		array( 'user' => $user, 'newsletter' => $newsletter));
	return newsletters_send_email( $user->email, $title, $body);
}

function newsletters_notify_user_by_message($user, $newsletter){
	// build title from view
//	$metadata = get_metadata_byname($user->getGUID(), 'notification_messages');
//	if ( !$metadata || $metadata->value != 'yes' )
//	    return false;
	$title = elgg_view('newsletters/email_subject', 	array( 'user' => $user, 'newsletter' => $newsletter));
	// build email body from view
	$body = elgg_view('newsletters/email_body', 		array( 'user' => $user, 'newsletter' => $newsletter));
	return newsletters_send_message($user, $title, $body );
}


function newsletters_send_email($email, $subject, $body, $add_headers = ''){
	return mail($email, $subject, $body, $add_headers);
}

function newsletters_send_message($userTo, $title, $message){
	if ( $userTo && $title && $message ){
		$message = new ElggObject();
		$message->subtype = "messages";
		$message->owner_guid = 0; // Owner of the message !!!
		$message->access_id = 2; // public message for version elgg 1.2
		$message->title = $title;
		$message->description = $message;
		$message->toId = $userTo->guid;
		$message->readYet = 0; // not readed
		$message->hiddenFrom = 0; //
		$message->hiddenTo = 0;
		// saving without reply relation
		if ( $message->save() )
		    return true;
	}
	return false;
}

function campaign_prepare_for_save(&$campaign){
	$campaign->date_start 	= strtotime($campaign->date_start);
	$campaign->date_end 	= strtotime($campaign->date_end);
	$campaign->time_start 	= campaign_convert_time_to_int($campaign->time_start);
	$campaign->time_end 	= campaign_convert_time_to_int($campaign->time_end);
}
/*
function campaign_prepare_for_human(&$campaign){
	$campaign->date_start 	= date('F j, Y', $campaign->date_start);
	$campaign->date_end 	= date('F j, Y', $campaign->date_end);
	$campaign->time_start 	= campaign_convert_int_to_time($campaign->time_start);
	$campaign->time_end 	= campaign_convert_int_to_time($campaign->time_end);
}
*/

function convert_date_for_human($val){
	return date('F j, Y', intval($val));
}

function convert_time_for_human($val){
	return campaign_convert_int_to_time($val);
}

function campaign_convert_time_to_int($val){
	$parts = explode(':', $val);
	return intval(intval($parts[0]) * 60 + intval($parts[1]));
}

function campaign_convert_int_to_time($val){
	$val = intval($val);
	return sprintf("%02d:%02d", (int)$val / 60, $val % 60);
}

?>