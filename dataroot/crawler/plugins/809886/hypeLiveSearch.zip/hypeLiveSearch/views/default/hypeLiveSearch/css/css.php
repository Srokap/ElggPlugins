.ac_results li {
font-size:0.9em;
line-height:12px;
padding:7px;
cursor:pointer;
}

.ac_res_subtype {
padding:3px;
}