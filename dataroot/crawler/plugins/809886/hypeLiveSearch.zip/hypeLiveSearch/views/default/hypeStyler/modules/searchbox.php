<?php
/* * * styler Theme for Elgg
 * (c) Ismayil Khayredinov (ismayil.khayredinov@gmail.com)
 *
 * SEARCHBOX WITHOUT A BUTTON
 */

if (array_key_exists('value', $vars)) {
    $value = $vars['value'];
} elseif ($value = get_input('q', get_input('tag', NULL))) {
    $value = $value;
} else {
    $value = elgg_echo('search');
}

$value = stripslashes($value);

$form_body = elgg_view('input/hypeAutocomplete', array(
            'internalname' => 'q',
            'internalvalue' => $display_query,
            'extra_class' => 'search_input',
        ));

//$form_body .= elgg_view('input/submit', array('value' => elgg_echo('search')));

$form_body = elgg_view('input/form', array(
            'body' => $form_body,
            'internalid' => 'searchform',
            'action' => $vars['url'] . 'pg/search',
            'method' => GET,
        ));
?>

<span>
    <?php echo $form_body ?>
</span>
