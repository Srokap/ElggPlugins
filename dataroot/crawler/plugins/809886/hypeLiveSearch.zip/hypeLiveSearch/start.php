<?php

/* hype Portfolio
 *
 * User Portfolio for hype
 * @package hype
 * @subpackage Portfolio
 *
 * @author Ismayil Khayredinov <ismayil.khayredinov@gmail.com>
 * @copyright Copyrigh (c) 2011, Ismayil Khayredinov
 */

function hypeLiveSearch_init() {
    register_page_handler('hypesearch', 'hypeLiveSearch_call');
    elgg_extend_view('css', 'hypeLiveSearch/css/css');
}

function hypeLiveSearch_call($page) {
    global $CONFIG;
    // only return results to logged in users.
    if (!$user = get_loggedin_user()) {
        exit;
    }

    if (!$q = get_input('q')) {
        exit;
    }

    $q = sanitise_string($q);

    // replace mysql vars with escaped strings
    $q = str_replace(array('_', '%'), array('\_', '\%'), $q);

    $match_on = get_registered_entity_types();

    if (get_input('match_owner', false)) {
        $owner_guid = $user->getGUID();
        $owner_where = 'AND e.owner_guid = ' . $user->getGUID();
    } else {
        $owner_guid = null;
        $owner_where = '';
    }

    //$limit = get_input('limit', 3);
    $limit = 50;
    
    // grab a list of entities and send them in json.
    $results = array();

    foreach ($match_on as $type => $subtypes) {

        switch ($type) {
            //case 'all':
            // only need to pull up title from objects.
            //if (!$entities = elgg_get_entities(array('owner_guid' => $owner_guid, 'limit' => $limit)) AND is_array($entities)) {
            //    $results = array_merge($results, $entities);
            //}
            //break;

            case 'user':
                $query = "SELECT * FROM {$CONFIG->dbprefix}users_entity as ue, {$CONFIG->dbprefix}entities as e
					WHERE e.guid = ue.guid
						AND e.enabled = 'yes'
						AND ue.banned = 'no'
						AND (ue.name LIKE '$q%' OR ue.username LIKE '$q%')
					LIMIT $limit
				";

                if ($entities = get_data($query)) {
                    foreach ($entities as $entity) {
                        $json = json_encode(array(
                                    'type' => 'user',
                                    'name' => $entity->name,
                                    'desc' => $entity->username,
                                    'icon' => '<img class="livesearch_icon" src="' . get_entity($entity->guid)->getIcon('tiny') . '" />',
                                    'guid' => $entity->guid,
                                    'url' => get_entity($entity->guid)->getURL()
                                ));
                        $results[$entity->name . rand(1, 100)] = $json;
                    }
                }
                break;

            case 'group':
                // don't return results if groups aren't enabled.
                if (!is_plugin_enabled('groups')) {
                    continue;
                }
                $query = "SELECT * FROM {$CONFIG->dbprefix}groups_entity as ge, {$CONFIG->dbprefix}entities as e
					WHERE e.guid = ge.guid
						AND e.enabled = 'yes'
						$owner_where
						AND (ge.name LIKE '$q%' OR ge.description LIKE '%$q%')
					LIMIT $limit
				";
                if ($entities = get_data($query)) {
                    foreach ($entities as $entity) {
                        $json = json_encode(array(
                                    'type' => 'group',
                                    'name' => $entity->name,
                                    'desc' => strip_tags($entity->description),
                                    'icon' => '<img class="livesearch_icon" src="' . get_entity($entity->guid)->getIcon('tiny') . '" />',
                                    'guid' => $entity->guid,
                                    'url' => get_entity($entity->guid)->getURL()
                                ));
                        //$results[$entity->name . rand(1,100)] = "$json|{$entity->guid}";
                        $results[$entity->name . rand(1, 100)] = $json;
                    }
                }
                break;

            case 'friends':
                $access = get_access_sql_suffix();
                $query = "SELECT * FROM {$CONFIG->dbprefix}users_entity as ue, {$CONFIG->dbprefix}entity_relationships as er, {$CONFIG->dbprefix}entities as e
					WHERE er.relationship = 'friend'
						AND er.guid_one = {$user->getGUID()}
						AND er.guid_two = ue.guid
						AND e.guid = ue.guid
						AND e.enabled = 'yes'
						AND ue.banned = 'no'
						AND (ue.name LIKE '$q%' OR ue.username LIKE '$q%')
					LIMIT $limit
				";

                if ($entities = get_data($query)) {
                    foreach ($entities as $entity) {
                        $json = json_encode(array(
                                    'type' => 'user',
                                    'name' => $entity->name,
                                    'desc' => $entity->username,
                                    'icon' => '<img class="livesearch_icon" src="' . get_entity($entity->guid)->getIcon('tiny') . '" />',
                                    'guid' => $entity->guid,
                                    'url' => get_entity($entity->guid)->getURL()
                                ));
                        $results[$entity->name . rand(1, 100)] = $json;
                    }
                }
                break;

            case 'object':
                foreach ($subtypes as $subtype) {
                    $subtype_id = get_subtype_id($type, $subtype);
                    $query = "SELECT * FROM {$CONFIG->dbprefix}objects_entity as oe, {$CONFIG->dbprefix}entities as e
					WHERE e.guid = oe.guid
						AND e.enabled = 'yes'
						$owner_where
                                                AND e.subtype = '$subtype_id'
						AND (oe.title LIKE '$q%' OR oe.description LIKE '%$q%')
					LIMIT $limit
				";
                    if ($entities = get_data($query)) {
                        foreach ($entities as $entity) {
                            $json = json_encode(array(
                                        'type' => $type,
                                        'subtype' => '<span class="ac_res_subtype">' . $subtype . '</span>',
                                        'name' => $entity->title,
                                        'desc' => elgg_get_excerpt(strip_tags($entity->description), 30),
                                        'icon' => '<img class="livesearch_icon" src="' . get_entity($entity->guid)->getIcon('tiny') . '" />',
                                        'guid' => $entity->guid,
                                        'url' => get_entity($entity->guid)->getURL()
                                    ));
                            //$results[$entity->name . rand(1,100)] = "$json|{$entity->guid}";
                            $results[$entity->name . rand(1, 100)] = $json;
                        }
                    }
                }
                break;

            default:
                // arbitrary subtype.
                //@todo you cannot specify a subtype without a type.
                // did this ever work?
                //elgg_get_entities(array('subtype' => $type, 'owner_guid' => $owner_guid));
                break;
        }
    }

    ksort($results);
    echo implode($results, "\n");
    exit;
}

register_elgg_event_handler('init', 'system', 'hypeLiveSearch_init');
?>