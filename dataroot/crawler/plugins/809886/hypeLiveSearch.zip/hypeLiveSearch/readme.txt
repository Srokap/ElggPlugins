LiveSearch is part of the hypeJunction bundle

============
www.hypeJunction.com
hype is here for you to connect, innovate, integrate, collaborate and indulge.
hype is a bundle of plugins that will help you kick start your Elgg-based social network and spice it up with cool features and functionalities.
============

hypeLiveSearch is an extention of Elgg's native search / autocomplete functionality. It allows for quick clickable search results (similar to Facebook).

