<?php

/**
 * This is view file for plugineditor
 *
 * PHP version 5
 *
 * @category   JFusion
 * @package    ViewsAdmin
 * @subpackage Plugineditor
 * @author     JFusion Team <webmaster@jfusion.org>
 * @copyright  2008 JFusion. All rights reserved.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link       http://www.jfusion.org
 */
// no direct access
defined('_JEXEC') or die('Restricted access');
//display the paypal donation button
JFusionFunction::displayDonate();
?>

<form method="post" action="index2.php" name="adminForm">
<input type="hidden" name="option" value="com_jfusion" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="action" value="" />
<input type="hidden" name="customcommand" value="" />

<?php echo $this->toolbar;
?>
<a name="top"/>
<table><tr><td width="100px">
<img src="components/com_jfusion/images/jfusion_large.png" height="75px" width="75px">
</td><td width="100px">
<img src="components/com_jfusion/images/editor.png" height="75px" width="75px">
<td><h2><?php echo $this->jname . ' ' . JText::_('PLUGIN_EDITOR');
?></h2></td></tr></table><br/>

<?php
//output the parameters
$inbox = 0;
foreach ($this->params as $param) {
    if ($param[5] == 'jfusionbox') {
        if (!empty($inbox)) {
            echo '<tr><td colspan=2 style="text-align:right"><a href="#top">Top</a></td></tr>' . "\n";
            echo '</table></div><br/><br/>';
        } else {
            $inbox = 1;
        }
        echo "\n" . '<div class="contentbox"><h2>' . JText::_($param[3]) . '</h2><table>';
    } else if (!empty($param[0]) && $param[3] != ' ' && $param[3][0] != '@') {
        echo '<tr><td class="contentbox_label">' . $param[0] . '</td><td class="contentbox_param">' . $param[1] . '</td></tr>';
    } else {
        echo '<tr><td colspan=2>' . $param[1] . '</td></tr>';
    }
}
echo '<tr><td colspan=2 style="text-align:right"><a href="#top">Top</a></td></tr>' . "\n";
echo '</table></div>' . "\n";
?>


<input type="hidden" name="jname" value="<?php echo $this->jname; ?>"/>
</form>