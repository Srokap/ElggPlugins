<?php

/**
 * This is view file for logoutcheckerresult
 *
 * PHP version 5
 *
 * @category   JFusion
 * @package    ViewsAdmin
 * @subpackage Logoutcheckerresults
 * @author     JFusion Team <webmaster@jfusion.org>
 * @copyright  2008 JFusion. All rights reserved.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link       http://www.jfusion.org
 */
// no direct access
defined('_JEXEC') or die('Restricted access');
//use an output buffer, in order for cookies to be passed onto the header
ob_start();
JFusionFunction::displayDonate();
/**
 *     Load debug library
 */
require_once JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_jfusion' . DS . 'models' . DS . 'model.debug.php';
/**
 * Output information about the server for future support queries
 */
?>
<table><tr><td width="100px">
<img src="components/com_jfusion/images/jfusion_large.png" height="75px" width="75px">
</td><td width="100px">
<img src="components/com_jfusion/images/login_checker2.png" height="75px" width="75px">
<td><h2><?php echo JText::_('LOGOUT_CHECKER_RESULT'); ?></h2></td>
</tr></table>

<div style="border: 0pt none ; margin: 0pt; padding: 0pt 5px; width: 800px; float: left;">

<?php
//get the joomla id
$joomlaid = JRequest::getVar('joomlaid');
$user = (array)JFactory::getUser($joomlaid);
$options['group'] = 'USERS';
//prevent current jooomla session from being destroyed
global $JFusionActivePlugin, $jfusionDebug;
$jfusionDebug = array();
$JFusionActivePlugin = 'joomla_int';
$jfusion_user = array('type' => 'user', 'name' => 'jfusion', 'params' => '');
$plugin = (object)$jfusion_user;
JPluginHelper::_import($plugin);
$plugin_name = $plugin->name;
$className = 'plg' . $plugin->type . $plugin->name;
if (class_exists($className)) {
    $plugin = new $className($this, (array)$plugin);
}
if (method_exists($plugin, 'onLogoutUser')) {
    $response = $plugin->onLogoutUser($user, $options);
}
debug::show($jfusionDebug, JText::_('LOGOUT') . ' ' . JText::_('DEBUG'), 1);
echo '</div>';
ob_end_flush();
return;
