<?php

/**
 * This is view file for syncstatus
 *
 * PHP version 5
 *
 * @category   JFusion
 * @package    ViewsAdmin
 * @subpackage Syncstatus
 * @author     JFusion Team <webmaster@jfusion.org>
 * @copyright  2008 JFusion. All rights reserved.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link       http://www.jfusion.org
 */
// no direct access
defined('_JEXEC') or die('Restricted access');
$inline = (!empty($this->sync_completed)) ? true : false;

//check to see if there is anything to output
if (!$this->syncdata['slave_data']) {
    echo JText::_('SYNC_NODATA');
    return;
} elseif (!empty($this->syncdata['completed'])) {
    echo '<br/>';
    //check to see if there were any errors
    if (!empty($this->syncdata['log']['errors'])) {
        //redirect to resolve errors
        if (!$inline) {
            //in a modal window so redirect parent
            echo '<h2><a href="javascript:void(0);" onclick="window.parent.location=\'index.php?option=com_jfusion&task=syncError&syncid=' . $this->syncdata['syncid'] . '\';">' . JText::_('SYNC_CONFLICT') . '</a></h2>';
        } else {
            echo '<h2><a href="index.php?option=com_jfusion&task=syncError&syncid=' . $this->syncdata['syncid'] . '">' . JText::_('SYNC_CONFLICT') . '</a></h2>';
        }
    } else {
        //inform about the success
        echo '<h2>' . JText::_('SYNC_SUCCESS') . '</h2>';
    }
} else {
    echo '<br/>';
    //sync did not finish so let's give the option to resume it
    if (!$inline) {
        echo '<h2><a href="javascript:void(0);" onclick="window.parent.location=\'index.php?option=com_jfusion&task=syncoptions&syncid=' . $this->syncdata['syncid'] . '\';">' . JText::_('SYNC_INCOMPLETE') . '</a></h2>';
    } else {
        echo '<h2><a href="index.php?option=com_jfusion&task=syncoptions&syncid=' . $this->syncdata['syncid'] . '">' . JText::_('SYNC_INCOMPLETE') . '</a></h2>';
    }
}
?>
<h2><?php echo JText::_('SYNC_STATUS'); ?></h2>

<table class="adminlist" cellspacing="1"><thead><tr><th width="50px">
<?php echo JText::_('PLUGIN') . ' ' . JText::_('NAME');
?>
</th><th align="center" class="title">
<?php echo JText::_('SYNC_USERS_TODO');
?>
</th><th align="center" class="title">
<?php echo JText::_('USERS') . ' ' . JText::_('UNCHANGED');
?>
</th><th align="center" class="title">
<?php echo JText::_('USERS') . ' ' . JText::_('UPDATED');
?>
</th><th align="center" class="title">
<?php echo JText::_('USERS') . ' ' . JText::_('CREATED');
?>
</th><th align="center" class="title">
<?php echo JText::_('USERS') . ' ' . JText::_('DELETED');
?>
</th><th align="center" class="title">
<?php echo JText::_('USER') . ' ' . JText::_('CONFLICTS');
?>
</th></tr></thead>
<?php
$row_count = 0;
foreach ($this->syncdata['slave_data'] as $slave) {
    echo '<tr class="row' . $row_count . '">';
    if ($row_count == 1) {
        $row_count = 0;
    } else {
        $row_count = 1;
    }
    ?>
    <td><?php echo $slave['jname']; ?></td>
    <td><?php echo $slave['total']; ?></td>
    <td><?php echo $slave['unchanged']; ?></td>
    <td><?php echo $slave['updated']; ?></td>
    <td><?php echo $slave['created']; ?></td>
    <td><?php echo $slave['deleted']; ?></td>
    <td><?php echo $slave['error']; ?></td></tr>

    <?php
} ?>
</table>

<?php
if (!empty($this->syncdata['log']['usersync'])) {
    global $mainframe, $option;
    $limitstart = JRequest::getVar('limitstart', 0);
    $limit = JRequest::getVar('limit', 5);
    $sort = JRequest::getVar('log_sort', 'num');
    $dir = JRequest::getVar('log_dir', '');
    if ($sort != 'num' && !empty($sort)) {
        uasort($this->syncdata['log']['usersync'], 'sortLog');
    }
    if (empty($limit) && empty($limistart)) {
        //show all of the log
        $log =& $this->syncdata['log']['usersync'];
    } else {
        $log = & array_slice($this->syncdata['log']['usersync'], $limitstart, $limit, true);
    }
    jimport('joomla.html.pagination');
    $pageNav = new JPagination(count($this->syncdata['log']['usersync']), $limitstart, $limit);
    echo "<br/><h2>" . JText::_('SYNC_LOG') . "</h2><br/>";?>

    <form action="index.php" method="post" name="adminForm">
    <table class="adminlist">
        <thead>
            <tr>
                <th width="20"><a href="javascript:void(0);" onclick="setSort('num');"><?php echo '#'; ?></a></th>
                <th><a href="javascript:void(0);" onclick="setSort('jname');"><?php echo JText::_('PLUGIN'); ?></a></th>
                <th><a href="javascript:void(0);" onclick="setSort('username');"><?php echo JText::_('USERNAME'); ?></a></th>
                <th><a href="javascript:void(0);" onclick="setSort('action');"><?php echo JText::_('ACTION'); ?></a></th>
                <th><?php echo JText::_('MESSAGE'); ?></th>
            </tr>
        </thead>
        <tbody>
        <?php
    foreach ($log as $k => $data) { ?>
            <tr><td><?php echo ($k + 1); ?></td>
            <td><?php echo $log[$k]->jname; ?></td>
            <td><?php echo $log[$k]->username; ?></td>
            <td><img src="components/com_jfusion/images/<?php echo $log[$k]->action; ?>.png" style="margin-right:5px;"><?php echo ucfirst($log[$k]->action); ?></td>
            <td><?php echo $log[$k]->message; ?></td></tr>
            <?php
    } ?>
        </tbody>
        <tfoot>
        <td colspan="5"><?php echo $pageNav->getListFooter(); ?></td>
        </tfoot>
    </table>
    <input type="hidden" name="option" value="<?php echo $option; ?>" />
    <input type="hidden" name="task" value="syncstatus" />
    <input type="hidden" name="syncid" value="<?php echo $this->syncid; ?>" />
    <?php
    if (!$inline) {
        ?><input type="hidden" name="tmpl" value="component" />
        <?php
    } ?>
    <input type="hidden" name="log_sort" value="<?php echo $sort; ?>" />
    <input type="hidden" name="log_dir" value="<?php echo $dir; ?>" />
    </form>
    <?php
}
/**
 * Display the results of the wizard set-up
 *
 * @param string &$a something
 * @param string &$b something
 *
 * @return string sorted log
 */
function sortLog(&$a, &$b)
{
    $sort = JRequest::getVar('log_sort', 'num');
    $dir = JRequest::getVar('log_dir', '');
    if ($a->$sort > $b->$sort) {
        return $dir;
    }
    if ($a->$sort < $b->$sort) {
        return -1 * $dir;
    }
    return 0;
}
