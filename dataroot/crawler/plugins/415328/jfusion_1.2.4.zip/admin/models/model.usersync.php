<?php

/**
 * Model that handles the usersync
 * 
 * PHP version 5
 * 
 * @category  JFusion
 * @package   Models
 * @author    JFusion Team <webmaster@jfusion.org>
 * @copyright 2008 JFusion. All rights reserved.
 * @license   http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link      http://www.jfusion.org
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

/**
 * Prevent time-outs
 */
@set_time_limit(0);
@ini_set('memory_limit', '256M');
@ini_set('upload_max_filesize', '128M');
@ini_set('post_max_size', '256M');
@ini_set('max_input_time', '7200');
@ini_set('max_execution_time', '0');
@ini_set('expect.timeout', '7200');
@ini_set('default_socket_timeout', '7200');

/**
 * Class for usersync JFusion functions
 * 
 * @category  JFusion
 * @package   Models
 * @author    JFusion Team <webmaster@jfusion.org>
 * @copyright 2008 JFusion. All rights reserved.
 * @license   http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link      http://www.jfusion.org
 */
class JFusionUsersync
{
    /**
     * Save log data
     * 
     * @param string $syncid   the usersync id
     * @param string &$synclog the actual syncdata
     * 
     * @return string nothing
     */    
    function saveLogData($syncid, &$synclog)
    {
        //serialize the $syncdata to allow storage in a file
        $serialized = serialize($synclog);
        //set file path
        $file = JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_jfusion' . DS . 'usersync' . DS . $syncid;
        jimport('joomla.filesystem.file');
        JFile::write($file, $serialized);
    }

    /**
     * Retrieve log data
     * 
     * @param string $syncid the usersync id
     * 
     * @return string nothing
     */        
    function getLogData($syncid)
    {
        //set file path
        $file = JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_jfusion' . DS . 'usersync' . DS . $syncid;
        jimport('joomla.filesystem.file');
        if (file_exists($file)) {
            $serialized = JFile::read($file);
            $synclog = unserialize($serialized);
            return $synclog;
        }
    }
    
    /**
     * Save sync data
     * 
     * @param string &$syncdata the actual syncdata
     * 
     * @return string nothing
     */        
    function saveSyncdata(&$syncdata)
    {
        //serialize the $syncdata to allow storage in a SQL field
        $serialized = base64_encode(serialize($syncdata));
        $db = & JFactory::getDBO();
        $query = 'INSERT INTO #__jfusion_sync (syncdata, syncid, time_start, action) VALUES (' . $db->Quote($serialized) . ', ' . $db->Quote($syncdata['syncid']) . ', ' . $db->Quote(time()) . ', ' . $db->Quote($syncdata['action']) . ')';
        $db->setQuery($query);
        $db->query();
    }
    
    /**
     * Update syncdata
     * 
     * @param string &$syncdata the actual syncdata
     * 
     * @return string nothing
     */        
    function updateSyncdata(&$syncdata)
    {
        //serialize the $syncdata to allow storage in a SQL field
        $serialized = base64_encode(serialize($syncdata));
        //find out if the syncid already exists
        $db = & JFactory::getDBO();
        $query = 'UPDATE #__jfusion_sync SET syncdata = ' . $db->Quote($serialized) . ' WHERE syncid =' . $db->Quote($syncdata['syncid']);
        $db->setQuery($query);
        $db->query();
    }

    /**
     * Get syncdata
     * 
     * @param string $syncid the usersync id
     * 
     * @return string nothing
     */        
    function getSyncdata($syncid)
    {
        $db = & JFactory::getDBO();
        $query = 'SELECT syncdata FROM #__jfusion_sync WHERE syncid =' . $db->Quote($syncid);
        $db->setQuery($query);
        $serialized = $db->loadResult();
        $syncdata = unserialize(base64_decode($serialized));
        //note we do not want to append the errors as then it gets saved to the database as well in syncExecute
        //get the errors and append it
        //$syncdata['errors'] = JFusionUsersync::getLogData($syncid);
        return $syncdata;
    }

    /**
     * Fix sync errors
     * 
     * @param string $syncid    the usersync id
     * @param string $syncError the actual syncError data
     * 
     * @return string nothing
     */        
    function syncError($syncid, $syncError)
    {
        //Load debug library
        include_once JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_jfusion' . DS . 'models' . DS . 'model.debug.php';
        ?><div style="border: 0pt none ; margin: 0pt; padding: 0pt 5px; width: 800px;">
        <?php
        $synclog = JFusionUsersync::getLogData($syncid);
        foreach ($syncError as $id => $error) {
            if ($error['action'] == '1') {
                //update the first entity
                echo '<h2>' . $synclog['errors'][$id]['user']['jname'] . ' ' . JText::_('USER') . ' ' . JText::_('UPDATE') . '</h2>';
                $JFusionPlugin = & JFusionFactory::getUser($synclog['errors'][$id]['user']['jname']);
                debug::show($synclog['errors'][$id]['conflict']['userinfo'], $synclog['errors'][$id]['conflict']['jname'] . ' ' . JText::_('USER') . ' ' . JText::_('INFORMATION'), 1);
                $status = $JFusionPlugin->updateUser($synclog['errors'][$id]['conflict']['userinfo'], 1);
                if ($status['error']) {
                    debug::show($status['error'], $synclog['errors'][$id]['user']['jname'] . ' ' . JText::_('USER') . ' ' . JText::_('UPDATE') . ' ' . JText::_('ERROR'), 0);
                    debug::show($status['debug'], $synclog['errors'][$id]['user']['jname'] . ' ' . JText::_('USER') . ' ' . JText::_('UPDATE') . ' ' . JText::_('DEBUG'), 0);
                } else {
                    debug::show($status['debug'], $synclog['errors'][$id]['user']['jname'] . ' ' . JText::_('USER') . ' ' . JText::_('UPDATE') . ' ' . JText::_('DEBUG'), 0);
                    JFusionFunction::updateLookup($synclog['errors'][$id]['user']['userinfo'], 0, $synclog['errors'][$id]['user']['jname']);
                }
            } elseif ($error['action'] == '2') {
                //update the second entity (conflicting plugin)
                echo '<h2>' . $synclog['errors'][$id]['conflict']['jname'] . ' ' . JText::_('USER') . ' ' . JText::_('UPDATE') . '</h2>';
                $JFusionPlugin = & JFusionFactory::getUser($synclog['errors'][$id]['conflict']['jname']);
                debug::show($synclog['errors'][$id]['user']['userinfo'], $synclog['errors'][$id]['user']['jname'] . ' ' . JText::_('USER') . ' ' . JText::_('INFORMATION'), 1);
                $status = $JFusionPlugin->updateUser($synclog['errors'][$id]['user']['userinfo'], 1);
                if ($status['error']) {
                    debug::show($status['error'], $synclog['errors'][$id]['conflict']['jname'] . ' ' . JText::_('USER') . ' ' . JText::_('UPDATE') . ' ' . JText::_('ERROR'), 0);
                    debug::show($status['debug'], $synclog['errors'][$id]['conflict']['jname'] . ' ' . JText::_('USER') . ' ' . JText::_('UPDATE') . ' ' . JText::_('DEBUG'), 0);
                } else {
                    debug::show($status['debug'], $synclog['errors'][$id]['conflict']['jname'] . ' ' . JText::_('USER') . ' ' . JText::_('UPDATE') . ' ' . JText::_('DEBUG'), 0);
                    JFusionFunction::updateLookup($synclog['errors'][$id]['user']['userinfo'], 0, $synclog['errors'][$id]['user']['jname']);
                }
            } elseif ($error['action'] == '3') {
                //delete the first entity
                //prevent Joomla from deleting all the slaves via the user plugin if it is set as master
                global $JFusionActive;
                $JFusionActive = 1;
                $JFusionPlugin = & JFusionFactory::getUser($error['user_jname']);
                $status = $JFusionPlugin->deleteUser($synclog['errors'][$id]['user']['userinfo']);
                if ($status['error']) {
                    //delete error
                    echo '<img src="components/com_jfusion/images/error.png" width="32" height="32">' . JText::_('ERROR') . ' ' . JText::_('DELETING') . ' ' . $error['user_jname'] . ' ' . JText::_('USER') . ' ' . $error['user_username'] . '<br/>';
                } else {
                    //delete success
                    echo '<img src="components/com_jfusion/images/updated.png" width="32" height="32">' . JText::_('SUCCESS') . ' ' . JText::_('DELETING') . ' ' . $error['user_jname'] . ' ' . JText::_('USER') . ' ' . $error['user_username'] . '<br/>';
                    JFusionFunction::updateLookup($synclog['errors'][$id]['user']['userinfo'], 0, $error['conflict_jname'], true);
                }
            } elseif ($error['action'] == '4') {
                //delete the second entity (conflicting plugin)
                //prevent Joomla from deleting all the slaves via the user plugin if it is set as master
                global $JFusionActive;
                $JFusionActive = 1;
                $JFusionPlugin = & JFusionFactory::getUser($error['conflict_jname']);
                $status = $JFusionPlugin->deleteUser($synclog['errors'][$id]['conflict']['userinfo']);
                if ($status['error']) {
                    //delete error
                    echo '<img src="components/com_jfusion/images/error.png" width="32" height="32">' . JText::_('ERROR') . ' ' . JText::_('DELETING') . ' ' . $error['conflict_jname'] . ' ' . JText::_('USER') . ' ' . $error['conflict_username'] . '<br/>';
                } else {
                    //delete success
                    echo '<img src="components/com_jfusion/images/updated.png" width="32" height="32">' . JText::_('SUCCESS') . ' ' . JText::_('DELETING') . ' ' . $error['conflict_jname'] . ' ' . JText::_('USER') . ' ' . $error['conflict_username'] . '<br/>';
                    JFusionFunction::updateLookup($synclog['errors'][$id]['conflict']['userinfo'], 0, $error['conflict_jname'], true);
                }
            }
        }
        echo '</div>';
        echo "<h2>" . JText::_('CONFLICT_RESOLUTION_COMPLETE') . "</h2>";
    }

    /**
     * Save log data
     * 
     * @param string &$syncdata     the actual syncdata
     * @param string $action        the type of sync action required
     * @param int    $plugin_offset the plugin offset
     * @param int    $user_offset   the user offset
     * 
     * @return string nothing
     */        
    function syncExecute(&$syncdata, $action, $plugin_offset, $user_offset)
    {
        if (empty($syncdata['completed'])) {
            //setup some variables
            $MasterPlugin = & JFusionFactory::getAdmin($syncdata['master']);
            $MasterUser = & JFusionFactory::getUser($syncdata['master']);
            $synclog = JFusionUsersync::getLogData($syncdata['syncid']);
            $session = & JFactory::getSession();
            if (!$session->get('jfusionSyncInProgress', 0)) {
                //tell JFusion a sync is in progress
                $session->set('jfusionSyncInProgress', 1);
                //only store syncdata every 20 users for better performance
                $store_interval = 20;
                $user_count = 1;
                //going to die every x users so that apache doesn't time out
                $user_batch = (isset($syncdata['userbatch'])) ? $syncdata['userbatch'] : 100;
                //we should start with the import of slave users into the master
                if ($syncdata['slave_data']) {
                    $lognum = (isset($synclog['usersync'])) ? count($synclog['usersync']) : 0;
                    $errnum = (isset($synclog['errors'])) ? count($synclog['errors']) : 0;
                    for ($i = $plugin_offset;$i < count($syncdata['slave_data']);$i++) {
                        $syncdata['plugin_offset'] = $i;
                        //get a list of users
                        $jname = $syncdata['slave_data'][$i]['jname'];
                        if ($jname) {
                            $SlavePlugin = & JFusionFactory::getAdmin($jname);
                            $SlaveUser = & JFusionFactory::getUser($jname);
                            if ($action == 'master') {
                                $userlist = $SlavePlugin->getUserList();
                                $action_name = $jname;
                                $action_reverse_name = $syncdata['master'];
                            } else {
                                $userlist = $MasterPlugin->getUserList();
                                $action_name = $syncdata['master'];
                                $action_reverse_name = $jname;
                            }
                            //perform the actual sync
                            for ($j = $user_offset;$j < count($userlist);$j++) {
                                $syncdata['user_offset'] = $j;
                                if ($action == 'master') {
                                    $userinfo = $SlaveUser->getUser($userlist[$j]);
                                    $status = $MasterUser->updateUser($userinfo, 0);
                                } else {
                                    $userinfo = $MasterUser->getUser($userlist[$j]);
                                    $status = $SlaveUser->updateUser($userinfo, 0);
                                }
                                $synclog['usersync'][$lognum] = new stdClass();
                                if ($status['error']) {
                                    $sync_error = array();
                                    $sync_error['conflict']['userinfo'] = $status['userinfo'];
                                    $sync_error['conflict']['error'] = $status['error'];
                                    $sync_error['conflict']['debug'] = $status['debug'];
                                    $sync_error['conflict']['jname'] = $action_reverse_name;
                                    $sync_error['user']['jname'] = $action_name;
                                    $sync_error['user']['userinfo'] = $userinfo;
                                    $sync_error['user']['userlist'] = $userlist[$j];
                                    //save the error for later
                                    $synclog['errors'][$errnum] = $sync_error;
                                    $status['action'] = 'error';
                                    $errnum++;
                                    //archive log
                                    $synclog['usersync'][$lognum]->action = $status['action'];
                                    $synclog['usersync'][$lognum]->username = $userlist[$j]->username;
                                    if (isset($status['userinfo'])) {
                                        $synclog['usersync'][$lognum]->message = JText::_('CONFLICT') . ':  ' . $syncdata['master'] . ' ' . $userlist[$j]->username . ' / ' . $userlist[$j]->email . ' <--->  ' . $jname . ' ' . $status['userinfo']->username . ' / ' . $status['userinfo']->email;
                                    } else {
                                        $error_msg = JText::_('ERROR') . ': ';
                                        if (is_array($status['error'])) {
                                            for ($e = 0;$e < count($status['error']);$e++) {
                                                $error_msg.= $status['error'][$e];
                                                if ($e != (count($status['error']) - 1)) {
                                                    $error_msg.= "; ";
                                                }
                                            }
                                        } else {
                                            $error_msg.= $status['error'];
                                        }
                                        $synclog['usersync'][$lognum]->message = $error_msg;
                                        unset($error_msg);
                                    }
                                    $synclog['usersync'][$lognum]->jname = $jname;
                                } else {
                                    //output results for extended view
                                    $synclog['usersync'][$lognum]->action = $status['action'];
                                    $synclog['usersync'][$lognum]->username = $userlist[$j]->username;
                                    if ($status['action'] == 'unchanged') {
                                        $synclog['usersync'][$lognum]->message = JText::_('SYNC_MSG_USER_DATA_IN_SYNC');
                                    } elseif ($status['action'] == 'updated') {
                                        $synclog['usersync'][$lognum]->message = JText::_('SYNC_MSG_USER_DATA_UPDATED');
                                    } elseif ($status['action'] == 'created') {
                                        $synclog['usersync'][$lognum]->message = JText::_('SYNC_MSG_USER_CREATED');
                                    } else {
                                        $synclog['usersync'][$lognum]->message = '';
                                    }
                                    $synclog['usersync'][$lognum]->jname = $jname;
                                    //update the lookup table
                                    if ($action == "master") {
                                        JFusionFunction::updateLookup($userinfo, 0, $jname);
                                    } else {
                                        JFusionFunction::updateLookup($SlaveUser->getUser($userlist[$j]), 0, $jname);
                                    }
                                }
                                //update the counters
                                $syncdata['slave_data'][$i][$status['action']]+= 1;
                                $syncdata['slave_data'][$i]['total']-= 1;
                                $syncdata['synced_users']+= 1;
                                $lognum++;
                                //update the database
                                if ($user_count >= $store_interval) {
                                    if ($syncdata['slave_data'][$i]['total'] == 0) {
                                        //will force  the net plugin and first user of that plugin on resume
                                        $syncdata['plugin_offset'] = $i + 1;
                                        $syncdata['user_offset'] = - 1;
                                    }
                                    JFusionUsersync::updateSyncdata($syncdata);
                                    JFusionUsersync::saveLogData($syncdata['syncid'], $synclog);
                                    //update counters
                                    $user_count = 1;
                                } else {
                                    if ($syncdata['slave_data'][$i]['total'] == 0) {
                                        break;
                                    }
                                    $user_count++;
                                    $user_batch--;
                                }
                                if ($user_batch == 0) {
                                    //exit the process to prevent an apache timeout; it will resume on the next ajax call
                                    //tell Joomla the batch has completed
                                    $session->set('jfusionSyncInProgress', 0);
                                    $percent = ($syncdata['synced_users'] / $syncdata['total_to_sync']) * 100;
                                    if ($percent == '100') {
                                        break;
                                    } else {
                                        //save the syncdata before exiting
                                        if ($syncdata['slave_data'][$i]['total'] == 0) {
                                            //will force  the net plugin and first user of that plugin on resume
                                            $syncdata['plugin_offset'] = $i + 1;
                                            $syncdata['user_offset'] = - 1;
                                        }
                                        JFusionUsersync::updateSyncdata($syncdata);
                                        JFusionUsersync::saveLogData($syncdata['syncid'], $synclog);
                                        exit();
                                    }
                                }
                            }
                        }
                    }
                    //end of sync, save the final data
                    $syncdata['completed'] = 'true';
                    $session->clear('jfusionSyncInProgress');
                    JFusionUsersync::updateSyncdata($syncdata);
                    JFusionUsersync::saveLogData($syncdata['syncid'], $synclog);
                    //update the finish time
                    $db = & JFactory::getDBO();
                    $query = 'UPDATE #__jfusion_sync SET time_end = ' . $db->Quote(time()) . ' WHERE syncid =' . $db->Quote($syncdata['syncid']);
                    $db->setQuery($query);
                    $db->query();
                }
            } else {
                exit();
            }
        }
    }
}
