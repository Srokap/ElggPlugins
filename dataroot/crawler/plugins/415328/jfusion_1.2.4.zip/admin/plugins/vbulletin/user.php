<?php

/**
 *
 * PHP version 5
 *
 * @category   JFusion
 * @package    JFusionPlugins
 * @subpackage vBulletin
 * @author     JFusion Team <webmaster@jfusion.org>
 * @copyright  2008 JFusion. All rights reserved.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link       http://www.jfusion.org
*/

// no direct access
defined('_JEXEC' ) or die('Restricted access' );

/**
 * JFusion Admin Class for vBulletin
 * For detailed descriptions on these functions please check the model.abstractadmin.php
 *
 * @category   JFusion
 * @package    JFusionPlugins
 * @subpackage vBulletin
 * @author     JFusion Team <webmaster@jfusion.org>
 * @copyright  2008 JFusion. All rights reserved.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link       http://www.jfusion.org
*/
class JFusionUser_vbulletin extends JFusionUser
{
    var $params;
    var $helper;

    function JFusionUser_vbulletin()
    {
        //get the params object
        $this->params =& JFusionFactory::getParams($this->getJname());
        //get the helper object
        $this->helper = & JFusionFactory::getHelper($this->getJname());
    }

    function &getUser($userinfo, $identifier_type = 'auto', $ignore_id = 0)
    {
    	if($identifier_type == 'auto') {
        	//get the identifier
        	list($identifier_type,$identifier) = $this->getUserIdentifier($userinfo,'u.username','u.email');
    	} else {
    		$identifier_type = 'u.' . $identifier_type;
    		$identifier = $userinfo;
    	}

        // Get user info from database
        $db =& JFusionFactory::getDatabase($this->getJname());

        $name_field = $this->params->get('name_field');

        $query = "SELECT u.userid, u.username, u.email, u.usergroupid AS group_id, g.title AS group_name, u.membergroupids, u.displaygroupid, u.password, u.salt as password_salt, u.usertitle, u.customtitle, u.posts";
        $query.= (!empty($name_field)) ? ", CASE WHEN f.$name_field IS NULL OR f.$name_field = '' THEN u.username ELSE f.$name_field END AS name FROM #__userfield as f INNER JOIN #__user AS u ON f.userid = u.userid" : ", u.username as name FROM #__user AS u";
        $query.= " INNER JOIN #__usergroup AS g ON u.usergroupid = g.usergroupid WHERE " . $identifier_type . ' = ' . $db->Quote($identifier);
        $query.= ($ignore_id) ? " AND u.userid != $ignore_id" : "";

        $db->setQuery($query );
        $result = $db->loadObject();

        if ($result) {
            //Check to see if they are banned
            $query = 'SELECT userid FROM #__userban WHERE userid='. $result->userid;
            $db->setQuery($query);
            if ($db->loadObject()) {
                $result->block = 1;
            } else {
                $result->block = 0;
            }

            //check to see if the user is awaiting activation
            $activationgroup = $this->params->get('activationgroup');

            if ($activationgroup == $result->group_id) {
                jimport('joomla.user.helper');
                $result->activation = JUserHelper::genRandomPassword(32);
            } else {
                $result->activation = '';
            }
        }
        return $result;
    }

    /**
     * returns the name of this JFusion plugin
     * @return string name of current JFusion plugin
     */
    function getJname()
    {
        return 'vbulletin';
    }

    function getTablename()
    {
        return 'user';
    }

    function deleteUser($userinfo)
    {
        //setup status array to hold debug info and errors
        $status = array();
        $status['debug'] = array();
        $status['error'] = array();

        //backup Joomla's global scope
        $this->helper->backupJoomla();

        //initialize vb framework
        if (!$this->helper->vBulletinInit()) {
            return null;
        }

        //setup the existing user
        $userdm =& datamanager_init('User', $this->helper->vb_data, ERRTYPE_SILENT);
        $existinguser = $this->helper->convertUserData($userinfo);
        $userdm->set_existing($existinguser);

        //delete the user
        $userdm->delete();
        if (!empty($userdm->errors)) {
            foreach ($userdm->errors AS $index => $error)
            {
                $status['error'][] = JText::_('USER_DELETION_ERROR') . ' ' . $error;
            }
        } else {
            $status['error'] = false;
            $status['debug'][] = JText::_('USER_DELETION'). ' ' . $existinguser->userid;
        }
        unset($userdm);

        //restore Joomla's global scope
        $this->helper->restoreJoomla();

        return $status;
    }

    function destroySession($userinfo, $options)
    {
        //If blocking a user in Joomla's User Manager, Joomla will initiate a logout.
        //Thus, prevent a logout of the currently logged in user if a user has been blocked:
        if (!defined('VBULLETIN_BLOCKUSER_CALLED')) {
            require_once JPATH_ADMINISTRATOR .DS.'components'.DS.'com_jfusion'.DS.'models'.DS.'model.jplugin.php';
            $status = JFusionJplugin::destroySession($userinfo, $options, $this->getJname());

            global $ch;
            global $cookiearr;
            global $cookies_to_set;
            global $cookies_to_set_index;
            $cookiearr = array();
            $cookies_to_set = array();
            $cookies = array();
            $cookie = array();
            $curl_options = array();
            $status = array();
            $status['error'] = array();
            $status['debug'] = array();
            $cookies_to_set_index = 0;

            $curl_options['post_url'] = $this->params->get('source_url') . 'login.php?do=logout';
            $curl_options['cookiedomain'] = $this->params->get('cookie_domain');
            $curl_options['cookiepath'] = $this->params->get('cookie_path');
            $curl_options['leavealone'] = $this->params->get('leavealone');
            $curl_options['secure'] = $this->params->get('secure');
            $curl_options['httponly'] = $this->params->get('httponly');
            $curl_options['verifyhost'] = 0;
            $curl_options['httpauth'] = $this->params->get('httpauth');
            $curl_options['httpauth_username'] = $this->params->get('curl_username');
            $curl_options['httpauth_password'] = $this->params->get('curl_password');

            $cookie_prefix = $this->params->get('cookie_prefix');
            $cookie_domain = $this->params->get('cookie_domain');
            $cookie_path = $this->params->get('cookie_path');
            $cookie_salt = $this->params->get('cookie_salt');
            $secure = $this->params->get('secure',false);
            $httponly = $this->params->get('httponly',true);
            $timenow = time();

            //add on vBulletin's logouthash to the url
            $securitytoken = sha1($userinfo->userid . sha1($userinfo->salt) . sha1($cookie_salt));
            $logouthash = $timenow . '-' . sha1($timenow . $securitytoken);
            $curl_options['post_url'] .= '&logouthash=' . $logouthash;

            $my_ID = rtrim(parse_url(JURI::root(), PHP_URL_HOST).parse_url(JURI::root(), PHP_URL_PATH), '/');
            $curl_options['jnodeid'] = $my_ID;

            $status = JFusionCurl::RemoteLogoutUrl($curl_options);
            $status['debug'][] = JText::sprintf('LOGOUT_PERFORMED_VIA',$curl_options['post_url']);

            //just for good measure
            JFusionCurl::addCookie($cookie_prefix.'userid' , 0, $timenow, $cookie_path, $cookie_domain, $secure, $httponly);
            JFusionCurl::addCookie($cookie_prefix.'password' , 0, $timenow, $cookie_path, $cookie_domain, $secure, $httponly);
            JFusionCurl::addCookie($cookie_prefix.'sessionhash' , 0, $timenow, $cookie_path, $cookie_domain, $secure, $httponly);

            return $status;
        } else {
            $status = array();
            $status['debug'] = 'Joomla initiated a logout of a blocked user thus skipped vBulletin destroySession() to prevent current user from getting logged out.';
        }
    }

    function createSession(&$userinfo, $options)
    {
        require_once JPATH_ADMINISTRATOR .DS.'components'.DS.'com_jfusion'.DS.'models'.DS.'model.curl.php';

         $status = array();
         $status['error'] = array();
         $status['debug'] = array();

        //do not create sessions for blocked users
        if (!empty($userinfo->block) || !empty($userinfo->activation)) {
            $status['error'][] = JText::_('FUSION_BLOCKED_USER');
            return $status;
        }

        //first check to see if striking is enabled to prevent further strikes
        $db =& JFusionFactory::getDatabase($this->getJname());
        $query = "SELECT value FROM #__setting WHERE varname = 'usestrikesystem'";
        $db->setQuery($query);
        $strikeEnabled = $db->loadResult();

        if ($strikeEnabled) {
            $ip = $_SERVER['REMOTE_ADDR'];
            $time = strtotime("-15 minutes");
            $query = "SELECT COUNT(*) FROM #__strikes WHERE strikeip = '$ip' AND striketime >= $time";
            $db->setQuery($query);
            $strikes = $db->loadResult();

            if ($strikes >= 5) {
                $status = array();
                $status['error'] = JText::_('VB_TOO_MANY_STRIKES');
                return $status;
            }
        }

        //make sure a session is not already active for this user
        $cookie_prefix = $this->params->get('cookie_prefix');
        $cookie_salt = $this->params->get('cookie_salt');
        $passwordhash = md5($userinfo->password.$cookie_salt);

        $query = "SELECT sessionhash FROM #__session WHERE userid = " . $userinfo->userid;
        $db->setQuery($query);
        $sessionhash = $db->loadResult();

        $cookie_sessionhash = JRequest::getVar($cookie_prefix . "sessionhash", '', 'cookie');
        $cookie_userid = JRequest::getVar($cookie_prefix . "userid", '', 'cookie');
        $cookie_password = JRequest::getVar($cookie_prefix . "password", '', 'cookie');

        if (!empty($cookie_userid) && $cookie_userid == $userinfo->userid && !empty($cookie_password) && $cookie_password == $passwordhash) {
            $vbcookieuser = true;
        } else {
            $vbcookieuser = false;
        }

        if (!$vbcookieuser && (empty($cookie_sessionhash) || $sessionhash != $cookie_sessionhash)) {

            $cookie_domain = $this->params->get('cookie_domain');
            $cookie_path = $this->params->get('cookie_path');
            $cookie_expires  = ($options['remember']) ? 0 : $this->params->get('cookie_expires');
            $secure = $this->params->get('secure', false);
            $httponly = $this->params->get('httponly', true);

            //before we make the login, let's create a couple cookies to make sure vb recognizes the user
            if ($cookie_expires == 0) {
                $expires_time = 0;
                $debug_expiration = JText::_('SESSION');
            } else {
                $expires_time = time() + ( 60 * $cookie_expires );
                $debug_expiration = date("Y-m-d H:i:s", $expires_time);
            }

            JFusionCurl::addCookie($cookie_prefix.'userid' , $userinfo->userid, $expires_time,  $cookie_path, $cookie_domain, $secure, $httponly);
            JFusionCurl::addCookie($cookie_prefix.'password' , $passwordhash, $expires_time, $cookie_path, $cookie_domain, $secure, $httponly);

            $status['debug'][JText::_('CREATED') . ' ' . JText::_('COOKIES')][] = array(JText::_('NAME') => $cookie_prefix.'userid', JText::_('VALUE') => $userinfo->userid, JText::_('EXPIRES') => $debug_expiration, JText::_('COOKIE_PATH') => $cookie_path, JText::_('COOKIE_DOMAIN') => $cookie_domain);
            $status['debug'][JText::_('CREATED') . ' ' . JText::_('COOKIES')][] = array(JText::_('NAME') => $cookie_prefix.'password', JText::_('VALUE') => substr($passwordhash, 0, 6) . '********, ', JText::_('EXPIRES') => $debug_expiration, JText::_('COOKIE_PATH') => $cookie_path, JText::_('COOKIE_DOMAIN') => $cookie_domain);

        } else {
            $status['debug'][] = JText::_('VB_SESSION_ALREADY_ACTIVE');
        }

        return $status;
    }

    function filterUsername($username)
    {
        //no username filtering implemented yet
        return $username;

    }

    function updatePassword($userinfo, &$existinguser, &$status)
    {
        jimport('joomla.user.helper');
        $existinguser->password_salt = JUserHelper::genRandomPassword(3);
        $existinguser->password = md5(md5($userinfo->password_clear).$existinguser->password_salt);

        $date = date('Y-m-d');

        $db =& JFusionFactory::getDatabase($this->getJname());
        $query = 'UPDATE #__user SET passworddate = ' . $db->Quote($date) . ', password = ' . $db->Quote($existinguser->password). ', salt = ' . $db->Quote($existinguser->password_salt). ' WHERE userid  = ' . $existinguser->userid;
        $db->setQuery($query );
        if (!$db->query()) {
            $status['error'][] = JText::_('PASSWORD_UPDATE_ERROR')  . ': ' . $db->stderr();
        } else {
            $status['debug'][] = JText::_('PASSWORD_UPDATE') . ' ' . substr($existinguser->password,0,6) . '********';
        }
    }

    function updateEmail($userinfo, &$existinguser, &$status)
    {
		//backup Joomla's global scope
		$this->helper->backupJoomla();

    	//initialize vb framework
		if(!$this->helper->vBulletinInit()) return null;

		//setup the existing user
		$userdm =& datamanager_init('User', $this->helper->vb_data, ERRTYPE_SILENT);
		$userdm->set_existing($this->helper->convertUserData($existinguser));

		$userdm->set('email', $userinfo->email);

		//performs some final VB checks before saving
		$userdm->pre_save();
	    if(empty($userdm->errors)){
			$userdm->save();
		    $status['debug'][] = JText::_('EMAIL_UPDATE'). ': ' . $existinguser->email . ' -> ' . $userinfo->email;
        } else {
    		foreach ($userdm->errors AS $index => $error) {
        		$status['error'][] = JText::_('EMAIL_UPDATE_ERROR') . ' ' . $error;
        }
    }

	    unset($userdm);

		//restore Joomla's global scope
		$this->helper->restoreJoomla();
    }

    function blockUser (&$userinfo, &$existinguser, &$status)
    {
        //backup Joomla's global scope
        $this->helper->backupJoomla();

        //initialize vb framework
        if (!$this->helper->vBulletinInit()) {
            return null;
        }

        $db =& JFusionFactory::getDatabase($this->getJname());

        //get the id of the banned group
        $bannedgroup = $this->params->get('bannedgroup');

        //update the usergroup to banned
        $query = 'UPDATE #__user SET usergroupid = ' . $bannedgroup . ' WHERE userid  = ' . $existinguser->userid;
        $db->setQuery($query);

        if (!$db->query()) {
            $status['error'][] = JText::_('BLOCK_UPDATE_ERROR') . ': ' . $db->stderr();
        } else {

            //add a banned user catch to vbulletin's database
            $ban = new stdClass;
            $ban->userid = $existinguser->userid;
            $ban->usergroupid = $existinguser->group_id;
            $ban->displaygroupid = $existinguser->displaygroupid;
            $ban->customtitle = $existinguser->customtitle;
            $ban->usertitle = $existinguser->usertitle;
            $ban->adminid = 1;
            $ban->bandate = time();
            $ban->liftdate = 0;
            $ban->reason = $this->params->get('blockmessage');

            //now append the new user data
            if (!$db->insertObject('#__userban', $ban, 'userid' )) {
                $status['error'][] = JText::_('BLOCK_UPDATE_ERROR') . ': ' . $db->stderr();
            } else {
                $status['debug'][] = JText::_('BLOCK_UPDATE'). ': ' . $existinguser->block . ' -> ' . $userinfo->block;
            }
        }

        //backup Joomla's global scope
        $this->helper->restoreJoomla();

        //note that blockUser has been called
        define('VBULLETIN_BLOCKUSER_CALLED',1);
    }

    function unblockUser($userinfo, &$existinguser, &$status)
    {
        //backup Joomla's global scope
        $this->helper->backupJoomla();

        //initialize vb framework
        if (!$this->helper->vBulletinInit()) {
            return null;
        }

        //found out what usergroup should be used
        $usergroups = (substr($this->params->get('usergroup'), 0, 2) == 'a:') ? unserialize($this->params->get('usergroup')) : $this->params->get('usergroup');
        if (is_array($usergroups)) {
            $defaultgroup = $usergroups[$userinfo->group_id]['defaultgroup'];
            $displaygroup = $usergroups[$userinfo->group_id]['displaygroup'];
        } else {
            $defaultgroup = $usergroups;
            $displaygroup = $usergroups;
        }
        $bannedgroup = $this->params->get('bannedgroup');

        //setup the existing user
        $userdm =& datamanager_init('User', $this->helper->vb_data, ERRTYPE_SILENT);
        $userinfo = $this->helper->convertUserData($existinguser);

        $userdm->set_existing($userinfo);

        //first check to see if user is banned and if so, retrieve the prebanned fields
        //must be something other than $db because it conflicts with vbulletin's global variables
        $jdb =& JFusionFactory::getDatabase($this->getJname());
        $query = 'SELECT b.*, g.usertitle AS bantitle FROM #__userban AS b INNER JOIN #__user AS u ON b.userid = u.userid INNER JOIN #__usergroup AS g ON u.usergroupid = g.usergroupid WHERE b.userid = ' . $existinguser->userid;
        $jdb->setQuery($query );
        $result = $jdb->loadObject();

        if ($result) {
            //set the user title
            if ($result->customtitle && $result->usertitle!=$result->bantitle) {
                $usertitle = $result->usertitle;
            } else if (!empty($result->usertitle)) {
                $usertitle = $result->usertitle;
            } else {
                $usertitle = $this->getDefaultUserTitle($defaultgroup, $existinguser->posts);
            }

            $userdm->set('usertitle', $usertitle);
            $userdm->set('posts', $existinguser->posts);
            // This will activate the rank update

            //keep user from getting stuck as banned
            if ($result->usergroupid==$bannedgroup) {
                $usergroupid = $defaultgroup;
            } else {
                $usergroupid = $result->group_id;
            }
            if ($result->displaygroupid==$bannedgroup) {
                $displaygroupid = $displaygroup;
            } else {
                $displaygroupid = $result->displaygroupid;
            }

            $userdm->set('usergroupid', $usergroupid);
            $userdm->set('displaygroupid', $displaygroupid);
            $userdm->set('customtitle', $result->customtitle);

            //remove any banned user catches from vbulletin's database
            $query = 'DELETE FROM #__userban WHERE userid='. $existinguser->userid;
            $jdb->setQuery($query);
            if (!$jdb->Query()) {
                $status['error'][] = JText::_('BLOCK_UPDATE_ERROR') . ': ' . $jdb->stderr();
            }
        } else {
            $userdm->set('usergroupid', $defaultgroup);
            $userdm->set('displaygroupid', $displaygroup);
        }

        //performs some final VB checks before saving
        $userdm->pre_save();
        if (empty($userdm->errors)) {

            $userdm->save();

            $status['debug'][] = JText::_('BLOCK_UPDATE'). ': ' . $existinguser->block . ' -> ' . $userinfo->block;
        } else {
            foreach ($userdm->errors AS $index => $error) {
                $status['error'][] = JText::_('BLOCK_UPDATE_ERROR') . ' ' . $error;
            }
        }

        unset($userdm);

        //backup Joomla's global scope
        $this->helper->restoreJoomla();
    }

    function activateUser($userinfo, &$existinguser, &$status)
    {
        //found out what usergroup should be used
        $usergroups = (substr($this->params->get('usergroup'), 0, 2) == 'a:') ? unserialize($this->params->get('usergroup')) : $this->params->get('usergroup');
        $usergroup = (is_array($usergroups)) ? $usergroups[$userinfo->group_id]['defaultgroup'] : $usergroups;

        //update the usergroup to default group
        $db =& JFusionFactory::getDatabase($this->getJname());
        $query = 'UPDATE #__user SET usergroupid = ' . $usergroup . ' WHERE userid  = ' . $existinguser->userid;
        $db->setQuery($query );

        if ($db->query()) {
            //remove any activation catches from vbulletins database
            $query = 'DELETE FROM #__useractivation WHERE userid = ' . $existinguser->userid;
            $db->setQuery($query);

            if (!$db->Query()) {
                $status['error'][] = JText::_('ACTIVATION_UPDATE_ERROR') . ': ' . $db->stderr();
            } else {
                $status['debug'][] = JText::_('ACTIVATION_UPDATE'). ': ' . $existinguser->activation . ' -> ' . $userinfo->activation;
            }
        } else {
            $status['error'][] = JText::_('ACTIVATION_UPDATE_ERROR') . ': ' . $db->stderr();
        }
    }

    function inactivateUser($userinfo, &$existinguser, &$status)
    {
        //found out what usergroup should be used
        $usergroup = $this->params->get('activationgroup');

        //update the usergroup to awaiting activation
        $db =& JFusionFactory::getDatabase($this->getJname());
        $query = 'UPDATE #__user SET usergroupid = ' . $usergroup . ' WHERE userid  = ' . $existinguser->userid;
        $db->setQuery($query );

        if ($db->Query()) {
            //update the activation status
            //check to see if the user is already inactivated
            $query = 'SELECT COUNT(*) FROM #__useractivation WHERE userid = ' . $existinguser->userid;
            $db->setQuery($query);
            $count = $db->loadResult();
            if (empty($count)) {
                //if not, then add an activation catch to vbulletin's database
                $useractivation = new stdClass;
                $useractivation->userid = $existinguser->userid;
                $useractivation->dateline = time();
                jimport('joomla.user.helper');
                $useractivation->activationid = JUserHelper::genRandomPassword(40);

                $usergroups = (substr($this->params->get('usergroup'), 0, 2) == 'a:') ? unserialize($this->params->get('usergroup')) : $this->params->get('usergroup');
                $usergroup = (is_array($usergroups)) ? $usergroups[$userinfo->group_id]['defaultgroup'] : $usergroups;
                $useractivation->usergroupid = $usergroup;

                if ($db->insertObject('#__useractivation', $useractivation, 'useractivationid' )) {

                    //backup Joomla's global scope
                    $this->helper->backupJoomla();

                    //initialize vb framework
                    if ($this->helper->vBulletinInit()) {
                        //setup the existing user
                        $userdm =& datamanager_init('User', $this->helper->vb_data, ERRTYPE_SILENT);
                        $vbuser = $this->helper->convertUserData($existinguser);
                        $userdm->set_existing($vbuser);
                        $userdm->set_bitfield('options', 'noactivationmails', 0);
                        $userdm->save();
                    }

                    //restore Joomla's global scope
                    $this->helper->restoreJoomla();

                    $status['debug'][] = JText::_('ACTIVATION_UPDATE'). ': ' . $existinguser->activation . ' -> ' . $userinfo->activation;
                } else {
                    $status['error'][] = JText::_('ACTIVATION_UPDATE_ERROR') . ': ' . $db->stderr();
                }
            } else {
                $status['debug'][] = JText::_('ACTIVATION_UPDATE'). ': ' . $existinguser->activation . ' -> ' . $userinfo->activation;
            }
        } else {
            $status['error'][] = JText::_('ACTIVATION_UPDATE_ERROR') . ': ' . $db->stderr();
        }
    }

    function createUser($userinfo, &$status)
    {
        //get the default user group and determine if we are using simple or advanced
        $usergroups = (substr($this->params->get('usergroup'), 0, 2) == 'a:') ? unserialize($this->params->get('usergroup')) : $this->params->get('usergroup');

        //return if we are in advanced user group mode but the master did not pass in a group_id
        if (is_array($usergroups) && !isset($userinfo->group_id)) {
            $status['error'][] = JText::_('GROUP_UPDATE_ERROR'). ": " . JText::_('ADVANCED_GROUPMODE_MASTER_NOT_HAVE_GROUPID');
            return null;
        }

        //backup Joomla's global scope
        $this->helper->backupJoomla();

        //initialize vb framework
        if (!$this->helper->vBulletinInit()) {
            return null;
        }

        if (empty($userinfo->activation)) {
            $defaultgroup = (is_array($usergroups)) ? $usergroups[$userinfo->group_id]['defaultgroup'] : $usergroups;
            $setAsNeedsActivation = false;
        } else {
            $defaultgroup = $this->params->get('activationgroup');
            $setAsNeedsActivation = true;
        }

        //create the new user
        $userdm =& datamanager_init('User', $this->helper->vb_data, ERRTYPE_SILENT);
        $userdm->set('username', $userinfo->username);
        $userdm->set('email', $userinfo->email);

        if (is_array($usergroups)) {
            $userdm->set('usergroupid', $defaultgroup);
            $userdm->set('displaygroupid', $usergroups[$userinfo->group_id]['displaygroup']);
            $userdm->set('membergroupids', $usergroups[$userinfo->group_id]['membergroups']);
        } else {
            $userdm->set('usergroupid', $defaultgroup);
            $userdm->set('displaygroupid', 0);
        }

        $usertitle = $this->getDefaultUserTitle($defaultgroup);

        $userdm->set('usertitle',$usertitle);

        if (isset($userinfo->password_clear)) {
            $userdm->set('password', $userinfo->password_clear);
        } else {
            //clear password is not available, set a random password for now
            jimport('joomla.user.helper');
            $random_password = JUtility::getHash(JUserHelper::genRandomPassword(10));
            $userdm->set('password', $random_password);
        }

        //set the timezone
        if (isset($userinfo->timezone)) {
            $timezone = $userinfo->timezone;
        } else {
            $config =& JFactory::getConfig();
            $timezone = $config->getValue('config.offset',0);
        }
        $userdm->set('timezoneoffset', $timezone);

        //performs some final VB checks before saving
        $userdm->pre_save();
        if (empty($userdm->errors)) {
            $userdmid = $userdm->save();

            //if we set a temp password, we need to move the hashed password over
            if (!isset($userinfo->password_clear)) {
                $db =& JFusionFactory::getDatabase($this->getJname());
                $query = 'UPDATE #__user SET password = ' . $db->Quote($userinfo->password). ' WHERE userid  = ' . $userdmid;
                if (!$db->query()) {
                    $status['debug'][] = JText::_('USER_CREATION_ERROR') .'. '. JText::_('USERID') . ' ' . $userdmid . ': '.JText::_('MASTER_PASSWORD_NOT_COPIED');
                }
            }

            //save the new user
            $status['userinfo'] = $this->getUser($userinfo);

            //does the user still need to be activated?
            if ($setAsNeedsActivation) {
                $this->inactivateUser($userinfo, $status['userinfo'], $status);
            }

            //return the good news
            $status['debug'][] = JText::_('USER_CREATION') .'. '. JText::_('USERID') . ' ' . $userdmid;
        } else {
            foreach ($userdm->errors AS $index => $error)
            {
                $status['error'][] = JText::_('USER_CREATION_ERROR') . ' ' . $error;
            }
        }

        unset($userdm);
        //backup Joomla's global scope
        $this->helper->restoreJoomla();
    }

    function executeUpdateUsergroup(&$userinfo, &$existinguser, &$usergroups, &$status)
    {
        $update_groups = false;
        $usergroupid =& $usergroups[$userinfo->group_id]['defaultgroup'];
        $displaygroupid =& $usergroups[$userinfo->group_id]['displaygroup'];
        $membergroupids = (isset($usergroups[$userinfo->group_id]['membergroups'])) ? $usergroups[$userinfo->group_id]['membergroups'] : array();

        //check to see if the default groups are different
        if ($usergroupid != $existinguser->group_id ) {
            $update_groups = true;
        }

        //check to see if the display groups are different
        if (!empty($usergroups['options']['compare_displaygroups']) && $displaygroupid != $existinguser->displaygroupid ) {
            $update_groups = true;
        }

        //check to see if member groups are different
        if (!empty($usergroups['options']['compare_membergroups'])) {
            $current_membergroups = explode(',', $existinguser->membergroupids);
            foreach ($membergroupids as $gid) {
                if (!in_array($gid, $current_membergroups)) {
                    $update_groups = true;
                    break;
                }
            }
        }

        if ($update_groups) {
            $this->updateUsergroup($userinfo, $existinguser, $status);
        }

        return $update_groups;
    }

    function updateUsergroup($userinfo, &$existinguser, &$status)
    {
        //check to see if we have a group_id in the $userinfo, if not return
        if (!isset($userinfo->group_id)) {
            $status['error'][] = JText::_('GROUP_UPDATE_ERROR'). ": " . JText::_('ADVANCED_GROUPMODE_MASTER_NOT_HAVE_GROUPID');
            return null;
        }

        $usergroups = unserialize($this->params->get('usergroup'));
        if (isset($usergroups[$userinfo->group_id])) {
            //backup Joomla's global scope
            $this->helper->backupJoomla();

            //initialize vb framework
            if (!$this->helper->vBulletinInit()) {
                return null;
            }

            //setup the existing user
            $userdm =& datamanager_init('User', $this->helper->vb_data, ERRTYPE_SILENT);
            $vbuserinfo = $this->helper->convertUserData($existinguser);
            $userdm->set_existing($vbuserinfo);

            $defaultgroup =& $usergroups[$userinfo->group_id]['defaultgroup'];
            $displaygroup =& $usergroups[$userinfo->group_id]['displaygroup'];
            $membergroups =& $usergroups[$userinfo->group_id]['membergroups'];

            $userdm->set('usergroupid', $defaultgroup);
            $userdm->set('membergroupids', $membergroups);

            $titlegroupid = (!empty($displaygroup)) ? $displaygroup : $defaultgroup;
            $usertitle = $this->getDefaultUserTitle($titlegroupid);
            $userdm->set('usertitle',$usertitle);

            //performs some final VB checks before saving
            $userdm->pre_save();
            if (empty($userdm->errors)) {
                $userdm->save();

                //now save the displaygroup
                if (!empty($displaygroup)) {
                    unset($userdm);
                    $userdm =& datamanager_init('User', $this->helper->vb_data, ERRTYPE_SILENT);
                    $userdm->set_existing($vbuserinfo);
                    $userdm->set('displaygroupid', $displaygroup);
                    $userdm->pre_save();
                    if (empty($userdm->errors)) {
                        $userdm->save();
                    } else {
                        foreach ($userdm->errors AS $index => $error) {
                            $status['error'][] = JText::_('GROUP_UPDATE_ERROR') . ' ' . $error;
                        }
                    }
                }

                $status['debug'][] = JText::_('GROUP_UPDATE'). ': ' . $existinguser->group_id . ' -> ' . $usergroups[$userinfo->group_id]['defaultgroup'];
            } else {
                foreach ($userdm->errors AS $index => $error) {
                    $status['error'][] = JText::_('GROUP_UPDATE_ERROR') . ' ' . $error;
                }
            }

            unset($userdm);

            //restore Joomla's global scope
            $this->helper->restoreJoomla();

        } else {
            $status['error'][] = JText::_('GROUP_UPDATE_ERROR') . ' ' . JText::_('ADVANCED_GROUPMODE_MASTERGROUP_NOTEXIST');
        }

    }

    //returns the user's title based on number of posts
    function getDefaultUserTitle($groupid, $posts = 0)
    {
        $db =& JFusionFactory::getDatabase($this->getJname());
        $query = "SELECT usertitle FROM #__usergroup WHERE usergroupid = $groupid";
        $db->setQuery($query);
        $title = $db->loadResult();

        if (empty($title)) {
            $query = 'SELECT title FROM #__usertitle WHERE minposts <= ' . $posts . ' ORDER BY minposts DESC LIMIT 1';
            $db->setQuery($query);
            $title = $db->loadResult();
        }

        return $title;
    }

    function keepAlive()
    {
        $debug = 0;
        if ($debug) {
            JError::raiseNotice('500', 'vbulletin keep alive called');
        }

        //retrieve the values for vb's cookies
        $cookie_prefix = $this->params->get('cookie_prefix');
        $cookie_sessionhash = JRequest::getVar($cookie_prefix . 'sessionhash', '', 'cookie');
        $cookie_userid = JRequest::getVar($cookie_prefix . 'userid', '', 'cookie');
        $cookie_password = JRequest::getVar($cookie_prefix . 'password', '', 'cookie');
        $JUser = & JFactory::getUser();

        $db =& JFusionFactory::getDatabase($this->getJname());
        $query = "SELECT userid FROM #__session WHERE sessionhash = " . $db->Quote($cookie_sessionhash);
        $db->setQuery($query);
        $session_userid = $db->loadResult();

        if (!$JUser->get('guest', true)) {
            if ($debug) {
                JError::raiseNotice('500', 'joomla logged in');
            }
            //user logged into Joomla so let's check for an active vb session

            //find the userid attached to Joomla's userid
            $joomla_userid = $JUser->get('id');
            $userlookup = JFusionFunction::lookupUser($this->getJname(), $joomla_userid);
            $vb_userid = (!empty($userlookup)) ? $userlookup->userid : 0;

            //check to see if the userid/password cookies are empty or if the session userid does not match an existing user in vB
            if ((empty($cookie_userid) && empty($cookie_password)) || (!empty($session_userid) && $session_userid != $vb_userid)) {
                if ($debug) {
                    JError::raiseNotice('500', 'vbulletin guest');
                    JError::raiseNotice('500', "cookie_sessionhash = $cookie_sessionhash");
                    JError::raiseNotice('500', "session_userid = $session_userid");
                    JError::raiseNotice('500', "vb_userid = $vb_userid");
                }
                //enable remember me as this is a keep alive function anyway
                $options = array();
                $options['remember'] = 1;
                //get the user's info
                $query = "SELECT username, email FROM #__user WHERE userid = {$userlookup->userid}";
                $db->setQuery($query);
                $user_identifiers = $db->loadObject();
                $userinfo = $this->getUser($user_identifiers);
                //create a new session
                $this->createSession($userinfo, $options);
                if ($debug) {
                    JError::raiseNotice('500', 'created vbulletin session');
                }
                //signal that session was changed
                return 1;
            }
        } elseif (!empty($session_userid)) {
            //the user is not logged into Joomla and we have an active vB session

            //find the Joomla user id attached to the vB user
            $userlookup = JFusionFunction::lookupUser($this->getJname(), $session_userid, false);
            if (!empty($userlookup)) {
                //enable remember me as this is a keep alive function anyway
                $options = array();
                $options['remember'] = 1;
                //get the user's info
                $db = & JFactory::getDBO();
                $query = "SELECT username, email FROM #__users WHERE id = {$userlookup->id}";
                $db->setQuery($query);
                $user_identifiers = $db->loadObject();
                $JoomlaUser = JFusionFactory::getUser('joomla_int');
                $userinfo = $JoomlaUser->getUser($user_identifiers);
                if (!empty($userinfo)) {
                    global $JFusionActivePlugin;
                    $JFusionActivePlugin = $this->getJname();
                    $JoomlaUser->createSession($userinfo, $options);
                    //signal that session was changed
                    return 1;
                }
            }
        }
    }
}
