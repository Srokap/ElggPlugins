<?php

/**
 *
 * PHP version 5
 *
 * @category   JFusion
 * @package    JFusionPlugins
 * @subpackage vBulletin
 * @author     JFusion Team <webmaster@jfusion.org>
 * @copyright  2008 JFusion. All rights reserved.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link       http://www.jfusion.org
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

/**
 * JFusion Helper Class for vBulletin
 *
 * @category   JFusion
 * @package    JFusionPlugins
 * @subpackage vBulletin
 * @author     JFusion Team <webmaster@jfusion.org>
 * @copyright  2008 JFusion. All rights reserved.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link       http://www.jfusion.org
 */
class JFusionHelper_vbulletin
{
    var $vb_data;
    var $backup;

    /**
     *
     * @return unknown_type
     */
    function JFusionHelper_vbulletin()
    {
        $this->params = & JFusionFactory::getParams($this->getJname());
    }

    /**
     * Returns the name for this plugin
     *
     * @return string
     */
    function getJname()
    {
        return 'vbulletin';
    }

    /**
     * Initializes the vBulletin framework
     *
     * @return boolean true on successful initialization
     */
    function vBulletinInit()
    {
        //only initialize the vb framework if it has not already been done
        if (!defined('VB_AREA')) {
            //load the vbulletin framework
            define('VB_AREA', 'JFusion');
            define('VB_ENTRY', 'JFusion');
            define('SKIP_SESSIONCREATE', 1);
            define('SKIP_USERINFO', 1);
            define('NOPMPOPUP', 1);
            define('CWD', $this->params->get('source_path'));
            if (file_exists(CWD)) {
                require_once CWD . '/includes/init.php';
                $this->vb_data  = $vbulletin;
                //force into global scope
                $GLOBALS["vbulletin"] = $vbulletin;
                $GLOBALS["db"] = $vbulletin->db;
            } else {
                JError::raiseWarning(500, JText::_('SOURCE_PATH_NOT_FOUND'));
                return false;
            }
        } elseif (defined('VB_AREA') && VB_AREA == 'JFusion') {
            if (empty($GLOBALS['vbulletin'])) {
                $GLOBALS['vbulletin'] = $this->vb_data;
            }
            if (empty($GLOBALS['db'])) {
                $GLOBALS['db'] = $this->vb_data->db;
            }
        }
        return true;
    }

    /**
     * Convert the existinguser variable into something vbulletin understands
     *
     * @param $existinguser object with existing vb userinfo
     *
     * @return array
     */
    function convertUserData($existinguser)
    {
        $userinfo = array('userid' => $existinguser->userid, 'username' => $existinguser->username, 'email' => $existinguser->email, 'password' => $existinguser->password);
        return $userinfo;
    }

    /**
     * Backs up Joomla's various Joomla variables before calling vBulletin's data managers
     */
    function backupJoomla()
    {
        $this->backup['globals'] = $GLOBALS;
        //let's take special precautions for Itemid
        $this->backup['itemid'] = JRequest::getInt('Itemid', 0);
    }

    /**
     * Restores Joomla's various Joomla variables after calling vBulletin's data managers
     */
    function restoreJoomla()
    {
        //restore Joomla's autoload function
        spl_autoload_register('__autoload');

        if (isset($this->backup['globals'])) {
            $GLOBALS = $this->backup['globals'];
        }
        if (isset($this->backup['itemid'])) {
            JRequest::setVar('Itemid', $this->backup['itemid']);
            global $Itemid;
            $Itemid = $this->backup['itemid'];
        }
        $this->backup = array();
        //make sure Joomla's db object is still connected
        JFusionFunction::reconnectJoomlaDb();
    }

    /**
     * Obtains the version of the integrated vbulletin
     *
     * @return string Version number
     */
    function getVersion()
    {
        static $jfusion_vb_version;
        if(empty($jfusion_vb_version)) {
            $db =& JFusionFactory::getDatabase($this->getJname());
            $q = "SELECT value FROM #__setting WHERE varname = 'templateversion'";
            $db->setQuery($q);
            $jfusion_vb_version = $db->loadResult();
        }
        return $jfusion_vb_version;
    }
}