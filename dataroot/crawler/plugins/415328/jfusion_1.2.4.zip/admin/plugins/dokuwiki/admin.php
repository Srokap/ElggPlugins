<?php

/**
 * file containing administrator function for the jfusion plugin
 *
 * PHP version 5
 *
 * @category   JFusion
 * @package    JFusionPlugins
 * @subpackage DokuWiki
 * @author     JFusion Team <webmaster@jfusion.org>
 * @copyright  2008 JFusion. All rights reserved.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link       http://www.jfusion.org
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

/**
 * load the DokuWiki framework
 */
require_once dirname(__FILE__) . DS . 'dokuwiki.php';

/**
 * JFusion admin class for DokuWiki
 *
 * @category   JFusion
 * @package    JFusionPlugins
 * @subpackage DokuWiki
 * @author     JFusion Team <webmaster@jfusion.org>
 * @copyright  2008 JFusion. All rights reserved.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link       http://www.jfusion.org
 */

class JFusionAdmin_dokuwiki extends JFusionAdmin
{
    /**
     * returns the name of this JFusion plugin
     *
     * @return string name of current JFusion plugin
     */
    function getJname()
    {
        return 'dokuwiki';
    }

    /**
     * check config
     *
     * @return array status message
     */
    function checkConfig()
    {
        $status = array();
        $params = JFusionFactory::getParams($this->getJname());
        $share = Dokuwiki::getInstance();
        $source_path = $params->get('source_path');
        $config = $share->getConf($source_path);
        if (is_array($config)) {
            $status['config'] = 1;
            $status['message'] = JText::_('GOOD_CONFIG');
            return $status;
        } else {
            $status['config'] = 0;
            $status['message'] = JText::_('WIZARD_FAILURE');
            return $status;
        }
    }

    /**
     * setup plugin from path
     *
     * @param string $Path Source path user to find config files
     *
     * @return mixed return false on failor and array if sucess
     */
    function setupFromPath($Path)
    {
        $share = Dokuwiki::getInstance();
        //try to open the file
        if ($config = $share->getConf($Path) === false) {
            JError::raiseWarning(500, JText::_('WIZARD_FAILURE') . ": $Path " . JText::_('WIZARD_MANUAL'));
            return false;
        } else {
            $params = array();
            $params['cookie_name'] = $config['cookie_name'];
            $params['cookie_path'] = $config['cookie_path'];
            $params['cookie_domain'] = $config['cookie_domain'];
            $params['cookie_seed'] = $config['cookie_seed'];
            $params['cookie_secure'] = $config['cookie_secure'];
            $params['source_path'] = $Path;
            return $params;
        }
    }

    /**
     * returns avetar
     *
     * @param string $userid userd used to find avatar
     *
     * @return string
     */
    function getAvatar($userid)
    {
        return 0;
    }

    /**
     * Get a list of users
     *
     * @return object with list of users
     */
    function getUserList()
    {
        $share = Dokuwiki::getInstance();
        return $share->getUserList();
    }

    /**
     * returns user count
     *
     * @return int user count
     */
    function getUserCount()
    {
        $share = Dokuwiki::getInstance();
        //        $userlist = $this->getUserList();
        return $share->auth->getUserCount();
    }

    /**
     * get default user group list
     *
     * @return object with default user group list
     */
    function getUsergroupList()
    {
        $default_group = new stdClass;
        $default_group->name = $default_group->id = JFusionAdmin_dokuwiki::getDefaultUsergroup();
        $UsergroupList[] = $default_group;
        return $UsergroupList;
    }

    /**
     * get default user group
     *
     * @return object with default user group
     */
    function getDefaultUsergroup()
    {
        $share = Dokuwiki::getInstance();
        return $share->getDefaultUsergroup();
    }

    /**
     * function  return if user can register or not
     *
     * @return boolean true can register
     */
    function allowRegistration()
    {
        $share = Dokuwiki::getInstance();
        $conf = $share->getConf();
        if (strpos($conf['disableactions'], 'register') !== false) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * debug configure
     *
     * @return void
     */
    function debugConfig()
    {
        $jname = $this->getJname();
        //get registration status
        $new_registration = $this->allowRegistration();
        //get the data about the JFusion plugins
        $db = & JFactory::getDBO();
        $query = 'SELECT * from #__jfusion WHERE name = ' . $db->Quote($jname);
        $db->setQuery($query);
        $plugin = $db->loadObject();
        //output a warning to the administrator if the allowRegistration setting is wrong
        if ($new_registration && $plugin->slave == '1') {
            JError::raiseNotice(0, $jname . ': ' . JText::_('DISABLE_REGISTRATION'));
        }
        if (!$new_registration && $plugin->master == '1') {
            JError::raiseNotice(0, $jname . ': ' . JText::_('ENABLE_REGISTRATION'));
        }
    }

    /**
     * renerate redirect code
     *
     * @return string output php redirect code
     */
    function generateRedirectCode()
    {
        $params = JFusionFactory::getParams($this->getJname());
        $joomla_params = JFusionFactory::getParams('joomla_int');
        $joomla_url = $joomla_params->get('source_url');
        $joomla_itemid = $params->get('redirect_itemid');
        //create the new redirection code
        $redirect_code = '
//JFUSION REDIRECT START
//SET SOME VARS
$joomla_url = \'' . $joomla_url . '\';
$joomla_itemid = ' . $joomla_itemid . ';
    ';
        $redirect_code.= '
if (!defined(\'_JEXEC\'))';
        $redirect_code.= '
{
    $QUERY_STRING = array_merge( $_GET,$_POST );
    if (!isset($QUERY_STRING[\'id\'])) $QUERY_STRING[\'id\'] = $ID;
    $QUERY_STRING = http_build_query($QUERY_STRING);
    $order = array(\'%3A\', \':\', \'/\');
    $QUERY_STRING = str_replace($order,\';\',$QUERY_STRING);
    $pattern = \'#do=(admin|login|logout)#\';
    if ( !preg_match( $pattern , $QUERY_STRING )) {
        $file = $_SERVER["SCRIPT_NAME"];
        $break = explode(\'/\', $file);
        $pfile = $break[count($break) - 1];
        $jfusion_url = $joomla_url . \'index.php?option=com_jfusion&Itemid=\' . $joomla_itemid . \'&jfile=\'.$pfile. \'&\' . $QUERY_STRING;
        header(\'Location: \' . $jfusion_url);
        exit;
    }
}
//JFUSION REDIRECT END
';
        return $redirect_code;
    }

    /**
     * Disable redirect mod
     *
     * @return void
     */
    function enableRedirectMod()
    {
        $error = 0;
        $error = 0;
        $reason = '';
        $mod_file = $this->getModFile('doku.php', $error, $reason);
        if ($error == 0) {
            //get the joomla path from the file
            jimport('joomla.filesystem.file');
            $file_data = JFile::read($mod_file);
            preg_match_all('/\/\/JFUSION REDIRECT START(.*)\/\/JFUSION REDIRECT END/ms', $file_data, $matches);
            //remove any old code
            if (!empty($matches[1][0])) {
                $search = '/\/\/JFUSION REDIRECT START(.*)\/\/JFUSION REDIRECT END/ms';
                $file_data = preg_replace($search, '', $file_data);
            }
            $redirect_code = $this->generateRedirectCode();
            $search = '/getID\(\)\;/si';
            $replace = 'getID();' . $redirect_code;
            $file_data = preg_replace($search, $replace, $file_data);
            JFile::write($mod_file, $file_data);
        }
    }

    /**
     * Disable redirect mod
     *
     * @return void
     */
    function disableRedirectMod()
    {
        $error = 0;
        $reason = '';
        $mod_file = $this->getModFile('doku.php', $error, $reason);
        if ($error == 0) {
            //get the joomla path from the file
            jimport('joomla.filesystem.file');
            $file_data = JFile::read($mod_file);
            $search = '/\/\/JFUSION REDIRECT START(.*)\/\/JFUSION REDIRECT END/si';
            $file_data = preg_replace($search, '', $file_data);
            JFile::write($mod_file, $file_data);
        }
    }

    /**
     * Output javascript
     *
     * @return void
     */
    function outputJavascript()
    {
        ?><script language="javascript" type="text/javascript">
        <!--
        function auth_mod(action) {
            var form = document.adminForm;
            form.customcommand.value = action;
            form.action.value = 'apply';
            submitform('saveconfig');
            return;
        }
        //-->
        </script><?php
    }

    /**
     * Used to display and conofigure the redirect mod
     *
     * @param string $name         name of element
     * @param string $value        value of element
     * @param string $node         node
     * @param string $control_name name of controler
     *
     * @return string html
     */
    function showRedirectMod($name, $value, $node, $control_name)
    {
        $error = 0;
        $reason = '';
        $mod_file = $this->getModFile('doku.php', $error, $reason);
        if ($error == 0) {
            //get the joomla path from the file
            jimport('joomla.filesystem.file');
            $file_data = JFile::read($mod_file);
            preg_match_all('/\/\/JFUSION REDIRECT START(.*)\/\/JFUSION REDIRECT END/ms', $file_data, $matches);
            //compare it with our joomla path
            if (empty($matches[1][0])) {
                $error = 1;
                $reason = JText::_('MOD_NOT_ENABLED');
            }
        }
        //add the javascript to enable buttons
        $this->outputJavascript();
        if ($error == 0) {
            //return success
            $output = '<img src="components/com_jfusion/images/check_good.png" height="20px" width="20px">' . JText::_('REDIRECTION_MOD') . ' ' . JText::_('ENABLED');
            $output.= ' <a href="javascript:void(0);" onclick="return auth_mod(\'disableRedirectMod\')">' . JText::_('MOD_DISABLE') . '</a>';
            $output.= ' <a href="javascript:void(0);" onclick="return auth_mod(\'enableRedirectMod\')">' . JText::_('MOD_UPDATE') . '</a>';
            return $output;
        } else {
            $output = '<img src="components/com_jfusion/images/check_bad.png" height="20px" width="20px">' . JText::_('REDIRECTION_MOD') . ' ' . JText::_('DISABLED') . ': ' . $reason;
            $output.= ' <a href="javascript:void(0);" onclick="return auth_mod(\'enableRedirectMod\')">' . JText::_('MOD_ENABLE') . '</a>';
            return $output;
        }
    }

    /**
     * Called by Framework user for displaying and configuring usergroups
     *
     * @param string $name         name of element
     * @param string $value        value of element
     * @param string $node         node
     * @param string $control_name name of controler
     *
     * @return string html
     */
    function usergroup($name, $value, $node, $control_name)
    {
        $jname = $this->getJname();
        //get the master plugin to be throughout
        $master = JFusionFunction::getMaster();
        $advanced = 0;
        //detect is value is a serialized array
        if (substr($value, 0, 2) == 'a:') {
            $value = unserialize($value);
            //use advanced only if this plugin is not set as master
            if ($master->name != $this->getJname()) {
                $advanced = 1;
            }
        }
        if (JFusionFunction::validPlugin($this->getJname())) {
            $usergroups = $this->getUsergroupList();
            foreach ($usergroups as $group) {
                $g[] = $group->name;
            }
            $comma_separated = implode(",", $g);
            $simple_value = $value;
            if (is_array($simple_value)) {
                $simple_value = $comma_separated;
            }
            if (!empty($usergroups)) {
                $simple_usergroup = "<table style=\"width:100%; border:0\">";
                $simple_usergroup.= '<tr><td>' . JText::_('DEFAULT_USERGROUP') . '</td><td><input type="text" name="' . $control_name . '[' . $name . ']" value="' . $simple_value . '" class="inputbox" /></td></tr>';
                $simple_usergroup.= "</table>";
            } else {
                $simple_usergroup = '';
            }
        } else {
            return JText::_('SAVE_CONFIG_FIRST');
        }
        //check to see if current plugin is a slave
        $db = & JFactory::getDBO();
        $query = 'SELECT slave FROM #__jfusion WHERE name = ' . $db->Quote($jname);
        $db->setQuery($query);
        $slave = $db->loadResult();
        $list_box = '<select onchange="usergroupSelect(this.selectedIndex);">';
        if ($advanced == 1) {
            $list_box.= '<option value="0" selected="selected">Simple</option>';
        } else {
            $list_box.= '<option value="0">Simple</option>';
        }
        if ($slave == 1) {
            //allow usergroup sync
            if ($advanced == 1) {
                $list_box.= '<option selected="selected" value="1">Avanced</option>';
            } else {
                $list_box.= '<option value="1">Avanced</option>';
            }
            //prepare the advanced options
            $JFusionMaster = JFusionFactory::getAdmin($master->name);
            $master_usergroups = $JFusionMaster->getUsergroupList();
            $advanced_usergroup = "<table class=\"usergroups\">";
            if ($advanced == 1) {
                foreach ($master_usergroups as $master_usergroup) {
                    $advanced_usergroup.= "<tr><td>" . $master_usergroup->name . '</td>';
                    $advanced_usergroup.= '<td><input type="text" name="' . $control_name . '[' . $name . '][' . $master_usergroup->id . ']" value="' . $value[$master_usergroup->id] . '" class="inputbox" /></td></tr>';
                }
            } else {
                foreach ($master_usergroups as $master_usergroup) {
                    $advanced_usergroup.= "<tr><td>" . $master_usergroup->name . '</td>';
                    $advanced_usergroup.= '<td><input type="text" name="' . $control_name . '[' . $name . '][' . $master_usergroup->id . ']" value="' . $comma_separated . '" class="inputbox" /></td></tr>';
                }
            }
            $advanced_usergroup.= "</table>";
        } else {
            $advanced_usergroup = '';
        }
        $list_box.= '</select>';
        ?><script Language="JavaScript">
        function usergroupSelect(option)
        {
            var myArray = new Array();
            myArray[0] = '<?php echo $simple_usergroup; ?>';
            myArray[1] = '<?php echo $advanced_usergroup; ?>';
            document.getElementById("JFusionUsergroup").innerHTML = myArray[option];
            }
        </script><?php

        if ($advanced == 1) {
            return JText::_('USERGROUP') . ' ' . JText::_('MODE') . ': ' . $list_box . '<br/><div id="JFusionUsergroup">' . $advanced_usergroup . '</div>';
        } else {
            return JText::_('USERGROUP') . ' ' . JText::_('MODE') . ': ' . $list_box . '<br/><div id="JFusionUsergroup">' . $simple_usergroup . '</div>';
        }
    }
}
