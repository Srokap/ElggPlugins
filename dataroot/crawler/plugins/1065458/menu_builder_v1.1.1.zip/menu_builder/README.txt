= Features =

- Build your custom site menu (admin only)
- drag and drop reordering
- Set access on menu items for public, logged in, logged out or admin only
- hides admin page for editing site menu because menu is managed on site

= TODO = 

- Replace appearance:menu_items page with a notice or forward
- setSelected on submenu and parent + partial selection + or subitem selected state.